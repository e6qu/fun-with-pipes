
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x220>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913700a5 	add	x5, x5, #0xdc0
    2aa0:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x220>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91372084 	add	x4, x4, #0xdc8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000590 	bl	4110 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe2e8>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9006420 	str	x0, [x1, #200]
    2b2c:	94000799 	bl	4990 <fwp_now_ns>
    2b30:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2b34:	91036000 	add	x0, x0, #0xd8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1890>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91378042 	add	x2, x2, #0xde0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435aa0 	ldr	w0, [x21, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2c4c:	91042000 	add	x0, x0, #0x108
    2c50:	94000530 	bl	4110 <fwp_trap>
    2c54:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2c58:	9103a000 	add	x0, x0, #0xe8
    2c5c:	9400052d 	bl	4110 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2ca0:	91058000 	add	x0, x0, #0x160
    2ca4:	9400051b 	bl	4110 <fwp_trap>
    2ca8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2cac:	9104c000 	add	x0, x0, #0x130
    2cb0:	94000518 	bl	4110 <fwp_trap>
    2cb4:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    2cb8:	91062000 	add	x0, x0, #0x188
    2cbc:	94000515 	bl	4110 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    2eb4:	911fc021 	add	x1, x1, #0x7f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3050:	91292000 	add	x0, x0, #0xa48
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    3118:	911f4021 	add	x1, x1, #0x7d0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3150:	91298000 	add	x0, x0, #0xa60
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x220>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <fwp_main_thread+0x220>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	f0000058 	adrp	x24, e000 <_IO_stdin_used+0x5c0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	912aa042 	add	x2, x2, #0xaa8
    31e0:	912c02d6 	add	x22, x22, #0xb00
    31e4:	91156318 	add	x24, x24, #0x558
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x220>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	912be323 	add	x3, x25, #0xaf8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	912c4000 	add	x0, x0, #0xb10
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3570:	91292000 	add	x0, x0, #0xa48
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x220>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	912c6021 	add	x1, x1, #0xb18
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x220>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	912c8021 	add	x1, x1, #0xb20
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x220>
    37e0:	912ca021 	add	x1, x1, #0xb28
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x220>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	912cc084 	add	x4, x4, #0xb30
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe3 	bl	27f0 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc3c 	bl	2960 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc27 	bl	2920 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb70 	bl	26d0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffba8 	bl	27d0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb99 	bl	27d0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb51 	bl	26d0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb5d 	bl	2710 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbed 	bl	2960 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x220>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	912d2084 	add	x4, x4, #0xb48
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb6e 	bl	27f0 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb5d 	bl	27d0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbbd 	bl	2960 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x220>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	912ce084 	add	x4, x4, #0xb38
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb46 	bl	27f0 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb30 	bl	27d0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb04 	bl	27d0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb20 	bl	2880 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c0c:	91174042 	add	x2, x2, #0x5d0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x220>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	912d4021 	add	x1, x1, #0xb50
    3c68:	912d6000 	add	x0, x0, #0xb58
    3c6c:	97fffae9 	bl	2810 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb13 	bl	2920 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac3 	bl	2800 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x220>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	912de042 	add	x2, x2, #0xb78
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffae6 	b	28f0 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffac6 	bl	2880 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3d78:	91134061 	add	x1, x3, #0x4d0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3d88:	91174262 	add	x2, x19, #0x5d0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x5c0>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3dbc:	91144021 	add	x1, x1, #0x510
    3dc0:	3dc20043 	ldr	q3, [x2, #2048]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3dec:	91134063 	add	x3, x3, #0x4d0
    3df0:	9115c084 	add	x4, x4, #0x570
    3df4:	91174266 	add	x6, x19, #0x5d0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaa9 	bl	2910 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91174275 	add	x21, x19, #0x5d0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa93 	bl	2910 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    3ed8:	91300000 	add	x0, x0, #0xc00
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffacc 	bl	2a10 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91174273 	add	x19, x19, #0x5d0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9401400 	ldr	x0, [x0, #40]
    4004:	b7f80760 	tbnz	x0, #63, 40f0 <fwp_tape_buffers_release+0x100>
    4008:	f9401a61 	ldr	x1, [x19, #48]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    403c:	91304000 	add	x0, x0, #0xc10
    4040:	97fffa74 	bl	2a10 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	91304000 	add	x0, x0, #0xc10
    4078:	97fffa66 	bl	2a10 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400a61 	ldp	q1, q2, [x19]
    40b8:	f90062d4 	str	x20, [x22, #192]
    40bc:	4f000400 	movi	v0.4s, #0x0
    40c0:	ad000aa1 	stp	q1, q2, [x21]
    40c4:	3dc00a61 	ldr	q1, [x19, #32]
    40c8:	3d800aa1 	str	q1, [x21, #32]
    40cc:	f9401a60 	ldr	x0, [x19, #48]
    40d0:	f9001aa0 	str	x0, [x21, #48]
    40d4:	f9001a7f 	str	xzr, [x19, #48]
    40d8:	ad000260 	stp	q0, q0, [x19]
    40dc:	3d800a60 	str	q0, [x19, #32]
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40ec:	d65f03c0 	ret
    40f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    40f4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f8:	91304000 	add	x0, x0, #0xc10
    40fc:	97fffa45 	bl	2a10 <getenv@plt>
    4100:	b5fffa40 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    4104:	17ffffd6 	b	405c <fwp_tape_buffers_release+0x6c>
    4108:	d503201f 	nop
    410c:	d503201f 	nop

0000000000004110 <fwp_trap>:
    4110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4114:	900000e2 	adrp	x2, 20000 <__data_start>
    4118:	d53bd041 	mrs	x1, tpidr_el0
    411c:	910003fd 	mov	x29, sp
    4120:	f9403c42 	ldr	x2, [x2, #120]
    4124:	91400021 	add	x1, x1, #0x0, lsl #12
    4128:	91004021 	add	x1, x1, #0x10
    412c:	a90153f3 	stp	x19, x20, [sp, #16]
    4130:	aa0003f3 	mov	x19, x0
    4134:	f9400034 	ldr	x20, [x1]
    4138:	b4000062 	cbz	x2, 4144 <fwp_trap+0x34>
    413c:	aa0203e0 	mov	x0, x2
    4140:	97fffa1c 	bl	29b0 <fflush@plt>
    4144:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4148:	f947ec00 	ldr	x0, [x0, #4056]
    414c:	f9400000 	ldr	x0, [x0]
    4150:	97fffa18 	bl	29b0 <fflush@plt>
    4154:	aa1303e3 	mov	x3, x19
    4158:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x220>
    415c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    4160:	f947ea73 	ldr	x19, [x19, #4048]
    4164:	9130a042 	add	x2, x2, #0xc28
    4168:	52800041 	mov	w1, #0x2                   	// #2
    416c:	f9400260 	ldr	x0, [x19]
    4170:	97fff9e0 	bl	28f0 <__fprintf_chk@plt>
    4174:	b40000b4 	cbz	x20, 4188 <fwp_trap+0x78>
    4178:	f9400260 	ldr	x0, [x19]
    417c:	97fffa0d 	bl	29b0 <fflush@plt>
    4180:	52800ca0 	mov	w0, #0x65                  	// #101
    4184:	97fffa1b 	bl	29f0 <_Exit@plt>
    4188:	52800ca0 	mov	w0, #0x65                  	// #101
    418c:	97fff969 	bl	2730 <exit@plt>

0000000000004190 <fwp_rc_forget_slot.part.0>:
    4190:	ca404401 	eor	x1, x0, x0, lsr #17
    4194:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4198:	ca412421 	eor	x1, x1, x1, lsr #9
    419c:	910003fd 	mov	x29, sp
    41a0:	92401c21 	and	x1, x1, #0xff
    41a4:	f9000bf3 	str	x19, [sp, #16]
    41a8:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    41ac:	91174262 	add	x2, x19, #0x5d0
    41b0:	910a2423 	add	x3, x1, #0x289
    41b4:	8b010c41 	add	x1, x2, x1, lsl #3
    41b8:	8b030c43 	add	x3, x2, x3, lsl #3
    41bc:	f94a2421 	ldr	x1, [x1, #5192]
    41c0:	b50000a1 	cbnz	x1, 41d4 <fwp_rc_forget_slot.part.0+0x44>
    41c4:	14000012 	b	420c <fwp_rc_forget_slot.part.0+0x7c>
    41c8:	91004023 	add	x3, x1, #0x10
    41cc:	f9400821 	ldr	x1, [x1, #16]
    41d0:	b40001e1 	cbz	x1, 420c <fwp_rc_forget_slot.part.0+0x7c>
    41d4:	f9400022 	ldr	x2, [x1]
    41d8:	eb02001f 	cmp	x0, x2
    41dc:	54ffff61 	b.ne	41c8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41e0:	f9400060 	ldr	x0, [x3]
    41e4:	91174273 	add	x19, x19, #0x5d0
    41e8:	f9400801 	ldr	x1, [x0, #16]
    41ec:	f9000061 	str	x1, [x3]
    41f0:	97fff9d4 	bl	2940 <free@plt>
    41f4:	f94e2660 	ldr	x0, [x19, #7240]
    41f8:	d1000400 	sub	x0, x0, #0x1
    41fc:	f90e2660 	str	x0, [x19, #7240]
    4200:	f9400bf3 	ldr	x19, [sp, #16]
    4204:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4208:	d65f03c0 	ret
    420c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4210:	9130e000 	add	x0, x0, #0xc38
    4214:	97ffffbf 	bl	4110 <fwp_trap>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_rc_prepare_chunk>:
    4220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4224:	910003fd 	mov	x29, sp
    4228:	a9025bf5 	stp	x21, x22, [sp, #32]
    422c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4230:	911742c2 	add	x2, x22, #0x5d0
    4234:	b9401c03 	ldr	w3, [x0, #28]
    4238:	aa0103f5 	mov	x21, x1
    423c:	a90153f3 	stp	x19, x20, [sp, #16]
    4240:	aa0003f4 	mov	x20, x0
    4244:	f94e2440 	ldr	x0, [x2, #7240]
    4248:	b4000440 	cbz	x0, 42d0 <fwp_rc_prepare_chunk+0xb0>
    424c:	d2800013 	mov	x19, #0x0                   	// #0
    4250:	35000203 	cbnz	w3, 4290 <fwp_rc_prepare_chunk+0x70>
    4254:	b4000361 	cbz	x1, 42c0 <fwp_rc_prepare_chunk+0xa0>
    4258:	f9401280 	ldr	x0, [x20, #32]
    425c:	97fff9b9 	bl	2940 <free@plt>
    4260:	aa1503e0 	mov	x0, x21
    4264:	d2800021 	mov	x1, #0x1                   	// #1
    4268:	97fff97e 	bl	2860 <calloc@plt>
    426c:	f9001280 	str	x0, [x20, #32]
    4270:	b5000460 	cbnz	x0, 42fc <fwp_rc_prepare_chunk+0xdc>
    4274:	97fffb6f 	bl	3030 <fwp_heap_oom>
    4278:	97ffffc6 	bl	4190 <fwp_rc_forget_slot.part.0>
    427c:	91000673 	add	x19, x19, #0x1
    4280:	b9401e83 	ldr	w3, [x20, #28]
    4284:	eb13007f 	cmp	x3, x19
    4288:	54000169 	b.ls	42b4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    428c:	d503201f 	nop
    4290:	f9401283 	ldr	x3, [x20, #32]
    4294:	8b130060 	add	x0, x3, x19
    4298:	38736863 	ldrb	w3, [x3, x19]
    429c:	7103fc7f 	cmp	w3, #0xff
    42a0:	54fffec0 	b.eq	4278 <fwp_rc_prepare_chunk+0x58>  // b.none
    42a4:	b9401e83 	ldr	w3, [x20, #28]
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb13007f 	cmp	x3, x19
    42b0:	54ffff08 	b.hi	4290 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42b4:	eb0302bf 	cmp	x21, x3
    42b8:	54000121 	b.ne	42dc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42bc:	b5000335 	cbnz	x21, 4320 <fwp_rc_prepare_chunk+0x100>
    42c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42cc:	d65f03c0 	ret
    42d0:	2a0303e3 	mov	w3, w3
    42d4:	eb0302bf 	cmp	x21, x3
    42d8:	54ffff20 	b.eq	42bc <fwp_rc_prepare_chunk+0x9c>  // b.none
    42dc:	911742c2 	add	x2, x22, #0x5d0
    42e0:	f9401280 	ldr	x0, [x20, #32]
    42e4:	f94e2841 	ldr	x1, [x2, #7248]
    42e8:	cb030021 	sub	x1, x1, x3
    42ec:	f90e2841 	str	x1, [x2, #7248]
    42f0:	97fff994 	bl	2940 <free@plt>
    42f4:	b5fffb75 	cbnz	x21, 4260 <fwp_rc_prepare_chunk+0x40>
    42f8:	f900129f 	str	xzr, [x20, #32]
    42fc:	911742d6 	add	x22, x22, #0x5d0
    4300:	f94e2ac0 	ldr	x0, [x22, #7248]
    4304:	b9001e95 	str	w21, [x20, #28]
    4308:	a94153f3 	ldp	x19, x20, [sp, #16]
    430c:	8b150000 	add	x0, x0, x21
    4310:	f90e2ac0 	str	x0, [x22, #7248]
    4314:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4318:	a8c37bfd 	ldp	x29, x30, [sp], #48
    431c:	d65f03c0 	ret
    4320:	f9401280 	ldr	x0, [x20, #32]
    4324:	aa1503e2 	mov	x2, x21
    4328:	a94153f3 	ldp	x19, x20, [sp, #16]
    432c:	52800001 	mov	w1, #0x0                   	// #0
    4330:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4334:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4338:	17fff946 	b	2850 <memset@plt>
    433c:	d503201f 	nop

0000000000004340 <fwp_heap_refill>:
    4340:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4344:	910003fd 	mov	x29, sp
    4348:	a9025bf5 	stp	x21, x22, [sp, #32]
    434c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4350:	911742b5 	add	x21, x21, #0x5d0
    4354:	aa0003f6 	mov	x22, x0
    4358:	d2800020 	mov	x0, #0x1                   	// #1
    435c:	a90153f3 	stp	x19, x20, [sp, #16]
    4360:	a90363f7 	stp	x23, x24, [sp, #48]
    4364:	2a0103f7 	mov	w23, w1
    4368:	2a0203f8 	mov	w24, w2
    436c:	97fffbd1 	bl	32b0 <fwp_heap_chunks>
    4370:	aa0003f3 	mov	x19, x0
    4374:	f949fea2 	ldr	x2, [x21, #5112]
    4378:	8b000800 	add	x0, x0, x0, lsl #2
    437c:	2a1703e1 	mov	w1, w23
    4380:	52800025 	mov	w5, #0x1                   	// #1
    4384:	d37df000 	lsl	x0, x0, #3
    4388:	910f0021 	add	x1, x1, #0x3c0
    438c:	8b000054 	add	x20, x2, x0
    4390:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4394:	52a00024 	mov	w4, #0x10000               	// #65536
    4398:	38206845 	strb	w5, [x2, x0]
    439c:	aa1403e0 	mov	x0, x20
    43a0:	39000698 	strb	w24, [x20, #1]
    43a4:	39000a97 	strb	w23, [x20, #2]
    43a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    43ac:	b9000681 	str	w1, [x20, #4]
    43b0:	2a0103e5 	mov	w5, w1
    43b4:	8b0300a2 	add	x2, x5, x3
    43b8:	1ac10881 	udiv	w1, w4, w1
    43bc:	9ac50842 	udiv	x2, x2, x5
    43c0:	b9000a81 	str	w1, [x20, #8]
    43c4:	92404021 	and	x1, x1, #0x1ffff
    43c8:	b9001a82 	str	w2, [x20, #24]
    43cc:	97ffff95 	bl	4220 <fwp_rc_prepare_chunk>
    43d0:	f949daa0 	ldr	x0, [x21, #5040]
    43d4:	29408a81 	ldp	w1, w2, [x20, #4]
    43d8:	8b134000 	add	x0, x0, x19, lsl #16
    43dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e0:	8b214003 	add	x3, x0, w1, uxtw
    43e4:	9ba20021 	umaddl	x1, w1, w2, x0
    43e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43ec:	a90086c3 	stp	x3, x1, [x22, #8]
    43f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43f8:	d65f03c0 	ret
    43fc:	d503201f 	nop

0000000000004400 <fwp_mem_free>:
    4400:	b40003c0 	cbz	x0, 4478 <fwp_mem_free+0x78>
    4404:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4408:	910003fd 	mov	x29, sp
    440c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4410:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4414:	911742a1 	add	x1, x21, #0x5d0
    4418:	a90153f3 	stp	x19, x20, [sp, #16]
    441c:	aa0003f3 	mov	x19, x0
    4420:	f949d823 	ldr	x3, [x1, #5040]
    4424:	f949ec22 	ldr	x2, [x1, #5080]
    4428:	cb030000 	sub	x0, x0, x3
    442c:	eb02401f 	cmp	x0, x2, lsl #16
    4430:	540001c2 	b.cs	4468 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4434:	d350fc16 	lsr	x22, x0, #16
    4438:	a90363f7 	stp	x23, x24, [sp, #48]
    443c:	f949fc22 	ldr	x2, [x1, #5112]
    4440:	8b160ad4 	add	x20, x22, x22, lsl #2
    4444:	d37df294 	lsl	x20, x20, #3
    4448:	ab140057 	adds	x23, x2, x20
    444c:	540000c0 	b.eq	4464 <fwp_mem_free+0x64>  // b.none
    4450:	38746842 	ldrb	w2, [x2, x20]
    4454:	7100045f 	cmp	w2, #0x1
    4458:	54000120 	b.eq	447c <fwp_mem_free+0x7c>  // b.none
    445c:	7100085f 	cmp	w2, #0x2
    4460:	540005e0 	b.eq	451c <fwp_mem_free+0x11c>  // b.none
    4464:	a94363f7 	ldp	x23, x24, [sp, #48]
    4468:	a94153f3 	ldp	x19, x20, [sp, #16]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4474:	d65f03c0 	ret
    4478:	d65f03c0 	ret
    447c:	f94012f8 	ldr	x24, [x23, #32]
    4480:	b94006e1 	ldr	w1, [x23, #4]
    4484:	f90023f9 	str	x25, [sp, #64]
    4488:	2a0103e2 	mov	w2, w1
    448c:	394006f9 	ldrb	w25, [x23, #1]
    4490:	39400af4 	ldrb	w20, [x23, #2]
    4494:	b4000158 	cbz	x24, 44bc <fwp_mem_free+0xbc>
    4498:	92403e76 	and	x22, x19, #0xffff
    449c:	9ac20ad6 	udiv	x22, x22, x2
    44a0:	38766b01 	ldrb	w1, [x24, x22]
    44a4:	8b160300 	add	x0, x24, x22
    44a8:	7103fc3f 	cmp	w1, #0xff
    44ac:	54000980 	b.eq	45dc <fwp_mem_free+0x1dc>  // b.none
    44b0:	38366b1f 	strb	wzr, [x24, x22]
    44b4:	b94006e1 	ldr	w1, [x23, #4]
    44b8:	2a0103e2 	mov	w2, w1
    44bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44c4:	cb390000 	sub	x0, x0, w25, uxtb
    44c8:	8b340074 	add	x20, x3, w20, uxtb
    44cc:	911742b5 	add	x21, x21, #0x5d0
    44d0:	1e630021 	ucvtf	d1, w1
    44d4:	d37ae400 	lsl	x0, x0, #6
    44d8:	8b140c14 	add	x20, x0, x20, lsl #3
    44dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e0:	f8746aa0 	ldr	x0, [x21, x20]
    44e4:	f94023f9 	ldr	x25, [sp, #64]
    44e8:	aa2003e0 	mvn	x0, x0
    44ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    44f0:	f9000260 	str	x0, [x19]
    44f4:	f8346ab3 	str	x19, [x21, x20]
    44f8:	f94a12a0 	ldr	x0, [x21, #5152]
    44fc:	1e612800 	fadd	d0, d0, d1
    4500:	a94153f3 	ldp	x19, x20, [sp, #16]
    4504:	cb020000 	sub	x0, x0, x2
    4508:	f90a12a0 	str	x0, [x21, #5152]
    450c:	fd0a22a0 	str	d0, [x21, #5184]
    4510:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4514:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4518:	d65f03c0 	ret
    451c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4520:	8b000063 	add	x3, x3, x0
    4524:	eb03027f 	cmp	x19, x3
    4528:	54fff9e1 	b.ne	4464 <fwp_mem_free+0x64>  // b.any
    452c:	fd400ae1 	ldr	d1, [x23, #16]
    4530:	fd4a2020 	ldr	d0, [x1, #5184]
    4534:	f9400ae0 	ldr	x0, [x23, #16]
    4538:	7e61d821 	ucvtf	d1, d1
    453c:	f94a1022 	ldr	x2, [x1, #5152]
    4540:	f94012f3 	ldr	x19, [x23, #32]
    4544:	1e612800 	fadd	d0, d0, d1
    4548:	cb000042 	sub	x2, x2, x0
    454c:	f90a1022 	str	x2, [x1, #5152]
    4550:	fd0a2020 	str	d0, [x1, #5184]
    4554:	b40000b3 	cbz	x19, 4568 <fwp_mem_free+0x168>
    4558:	39400260 	ldrb	w0, [x19]
    455c:	7103fc1f 	cmp	w0, #0xff
    4560:	54000380 	b.eq	45d0 <fwp_mem_free+0x1d0>  // b.none
    4564:	3900027f 	strb	wzr, [x19]
    4568:	b9400ee2 	ldr	w2, [x23, #12]
    456c:	b4000142 	cbz	x2, 4594 <fwp_mem_free+0x194>
    4570:	911742a1 	add	x1, x21, #0x5d0
    4574:	8b160040 	add	x0, x2, x22
    4578:	8b000800 	add	x0, x0, x0, lsl #2
    457c:	f949fc21 	ldr	x1, [x1, #5112]
    4580:	8b140034 	add	x20, x1, x20
    4584:	8b000c20 	add	x0, x1, x0, lsl #3
    4588:	3802869f 	strb	wzr, [x20], #40
    458c:	eb00029f 	cmp	x20, x0
    4590:	54ffffc1 	b.ne	4588 <fwp_mem_free+0x188>  // b.any
    4594:	911742a0 	add	x0, x21, #0x5d0
    4598:	f94a1801 	ldr	x1, [x0, #5168]
    459c:	f949f803 	ldr	x3, [x0, #5104]
    45a0:	8b020021 	add	x1, x1, x2
    45a4:	f90a1801 	str	x1, [x0, #5168]
    45a8:	eb16007f 	cmp	x3, x22
    45ac:	54000049 	b.ls	45b4 <fwp_mem_free+0x1b4>  // b.plast
    45b0:	f909f816 	str	x22, [x0, #5104]
    45b4:	911742b5 	add	x21, x21, #0x5d0
    45b8:	f949f6a0 	ldr	x0, [x21, #5096]
    45bc:	eb16001f 	cmp	x0, x22
    45c0:	54fff529 	b.ls	4464 <fwp_mem_free+0x64>  // b.plast
    45c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45c8:	f909f6b6 	str	x22, [x21, #5096]
    45cc:	17ffffa7 	b	4468 <fwp_mem_free+0x68>
    45d0:	aa1303e0 	mov	x0, x19
    45d4:	97fffeef 	bl	4190 <fwp_rc_forget_slot.part.0>
    45d8:	17ffffe3 	b	4564 <fwp_mem_free+0x164>
    45dc:	97fffeed 	bl	4190 <fwp_rc_forget_slot.part.0>
    45e0:	17ffffb4 	b	44b0 <fwp_mem_free+0xb0>

00000000000045e4 <fwp_rc_wide_dup>:
    45e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45e8:	910003fd 	mov	x29, sp
    45ec:	a90153f3 	stp	x19, x20, [sp, #16]
    45f0:	aa0003f3 	mov	x19, x0
    45f4:	ca404400 	eor	x0, x0, x0, lsr #17
    45f8:	f90013f5 	str	x21, [sp, #32]
    45fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4600:	ca402400 	eor	x0, x0, x0, lsr #9
    4604:	911742a2 	add	x2, x21, #0x5d0
    4608:	92401c00 	and	x0, x0, #0xff
    460c:	910a2403 	add	x3, x0, #0x289
    4610:	8b000c40 	add	x0, x2, x0, lsl #3
    4614:	8b030c54 	add	x20, x2, x3, lsl #3
    4618:	f94a2401 	ldr	x1, [x0, #5192]
    461c:	b50000a1 	cbnz	x1, 4630 <fwp_rc_wide_dup+0x4c>
    4620:	14000033 	b	46ec <fwp_rc_wide_dup+0x108>
    4624:	91004034 	add	x20, x1, #0x10
    4628:	f9400821 	ldr	x1, [x1, #16]
    462c:	b4000241 	cbz	x1, 4674 <fwp_rc_wide_dup+0x90>
    4630:	f9400022 	ldr	x2, [x1]
    4634:	eb02027f 	cmp	x19, x2
    4638:	54ffff61 	b.ne	4624 <fwp_rc_wide_dup+0x40>  // b.any
    463c:	f9400281 	ldr	x1, [x20]
    4640:	39400260 	ldrb	w0, [x19]
    4644:	7103f81f 	cmp	w0, #0xfe
    4648:	54000220 	b.eq	468c <fwp_rc_wide_dup+0xa8>  // b.none
    464c:	b40001a1 	cbz	x1, 4680 <fwp_rc_wide_dup+0x9c>
    4650:	f9400420 	ldr	x0, [x1, #8]
    4654:	b100041f 	cmn	x0, #0x1
    4658:	54000440 	b.eq	46e0 <fwp_rc_wide_dup+0xfc>  // b.none
    465c:	91000400 	add	x0, x0, #0x1
    4660:	f9000420 	str	x0, [x1, #8]
    4664:	a94153f3 	ldp	x19, x20, [sp, #16]
    4668:	f94013f5 	ldr	x21, [sp, #32]
    466c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4670:	d65f03c0 	ret
    4674:	39400260 	ldrb	w0, [x19]
    4678:	7103f81f 	cmp	w0, #0xfe
    467c:	54000100 	b.eq	469c <fwp_rc_wide_dup+0xb8>  // b.none
    4680:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4684:	9130e000 	add	x0, x0, #0xc38
    4688:	97fffea2 	bl	4110 <fwp_trap>
    468c:	b4000081 	cbz	x1, 469c <fwp_rc_wide_dup+0xb8>
    4690:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4694:	91318000 	add	x0, x0, #0xc60
    4698:	97fffe9e 	bl	4110 <fwp_trap>
    469c:	d2800300 	mov	x0, #0x18                  	// #24
    46a0:	97fff860 	bl	2820 <malloc@plt>
    46a4:	b4000280 	cbz	x0, 46f4 <fwp_rc_wide_dup+0x110>
    46a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    46ac:	a9000413 	stp	x19, x1, [x0]
    46b0:	911742b5 	add	x21, x21, #0x5d0
    46b4:	f900081f 	str	xzr, [x0, #16]
    46b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46bc:	f9000280 	str	x0, [x20]
    46c0:	39000261 	strb	w1, [x19]
    46c4:	f94e26a0 	ldr	x0, [x21, #7240]
    46c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46cc:	91000400 	add	x0, x0, #0x1
    46d0:	f90e26a0 	str	x0, [x21, #7240]
    46d4:	f94013f5 	ldr	x21, [sp, #32]
    46d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46dc:	d65f03c0 	ret
    46e0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    46e4:	91322000 	add	x0, x0, #0xc88
    46e8:	97fffe8a 	bl	4110 <fwp_trap>
    46ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46f0:	17ffffd4 	b	4640 <fwp_rc_wide_dup+0x5c>
    46f4:	97fffa4f 	bl	3030 <fwp_heap_oom>
    46f8:	d503201f 	nop
    46fc:	d503201f 	nop

0000000000004700 <fwp_closure_drop_push>:
    4700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4704:	910003fd 	mov	x29, sp
    4708:	a90153f3 	stp	x19, x20, [sp, #16]
    470c:	aa0003f3 	mov	x19, x0
    4710:	a9408014 	ldp	x20, x0, [x0, #8]
    4714:	a9025bf5 	stp	x21, x22, [sp, #32]
    4718:	aa0103f5 	mov	x21, x1
    471c:	a90363f7 	stp	x23, x24, [sp, #48]
    4720:	eb00029f 	cmp	x20, x0
    4724:	54000160 	b.eq	4750 <fwp_closure_drop_push+0x50>  // b.none
    4728:	f9400276 	ldr	x22, [x19]
    472c:	d37df297 	lsl	x23, x20, #3
    4730:	91000694 	add	x20, x20, #0x1
    4734:	f9000674 	str	x20, [x19, #8]
    4738:	a94153f3 	ldp	x19, x20, [sp, #16]
    473c:	f8376ad5 	str	x21, [x22, x23]
    4740:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4744:	a94363f7 	ldp	x23, x24, [sp, #48]
    4748:	a8c57bfd 	ldp	x29, x30, [sp], #80
    474c:	d65f03c0 	ret
    4750:	a9046bf9 	stp	x25, x26, [sp, #64]
    4754:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4758:	eb00029f 	cmp	x20, x0
    475c:	540003e8 	b.hi	47d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4760:	d37cee99 	lsl	x25, x20, #4
    4764:	d37ffa9a 	lsl	x26, x20, #1
    4768:	aa1903e0 	mov	x0, x25
    476c:	97fff82d 	bl	2820 <malloc@plt>
    4770:	aa0003f6 	mov	x22, x0
    4774:	b4000380 	cbz	x0, 47e4 <fwp_closure_drop_push+0xe4>
    4778:	aa1303f8 	mov	x24, x19
    477c:	aa1903e3 	mov	x3, x25
    4780:	d37df297 	lsl	x23, x20, #3
    4784:	aa1703e2 	mov	x2, x23
    4788:	f8418719 	ldr	x25, [x24], #24
    478c:	aa1903e1 	mov	x1, x25
    4790:	97fff810 	bl	27d0 <__memcpy_chk@plt>
    4794:	eb18033f 	cmp	x25, x24
    4798:	540000a0 	b.eq	47ac <fwp_closure_drop_push+0xac>  // b.none
    479c:	aa1903e0 	mov	x0, x25
    47a0:	97fff868 	bl	2940 <free@plt>
    47a4:	f9400674 	ldr	x20, [x19, #8]
    47a8:	d37df297 	lsl	x23, x20, #3
    47ac:	91000694 	add	x20, x20, #0x1
    47b0:	f9000276 	str	x22, [x19]
    47b4:	f9000a7a 	str	x26, [x19, #16]
    47b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47bc:	f9000674 	str	x20, [x19, #8]
    47c0:	f8376ad5 	str	x21, [x22, x23]
    47c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47d4:	d65f03c0 	ret
    47d8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    47dc:	9132a000 	add	x0, x0, #0xca8
    47e0:	97fffe4c 	bl	4110 <fwp_trap>
    47e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    47e8:	f947e863 	ldr	x3, [x3, #4048]
    47ec:	d2800262 	mov	x2, #0x13                  	// #19
    47f0:	d2800021 	mov	x1, #0x1                   	// #1
    47f4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    47f8:	91292000 	add	x0, x0, #0xa48
    47fc:	f9400063 	ldr	x3, [x3]
    4800:	97fff860 	bl	2980 <fwrite@plt>
    4804:	d2800000 	mov	x0, #0x0                   	// #0
    4808:	97fff86a 	bl	29b0 <fflush@plt>
    480c:	52800cc0 	mov	w0, #0x66                  	// #102
    4810:	97fff878 	bl	29f0 <_Exit@plt>

0000000000004814 <fwp_closure_drop.part.0>:
    4814:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4818:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    481c:	910003fd 	mov	x29, sp
    4820:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4824:	f947f463 	ldr	x3, [x3, #4072]
    4828:	a90153f3 	stp	x19, x20, [sp, #16]
    482c:	d10883ff 	sub	sp, sp, #0x220
    4830:	910003e2 	mov	x2, sp
    4834:	d53bd053 	mrs	x19, tpidr_el0
    4838:	910063f4 	add	x20, sp, #0x18
    483c:	3dc20420 	ldr	q0, [x1, #2064]
    4840:	91400264 	add	x4, x19, #0x0, lsl #12
    4844:	91004084 	add	x4, x4, #0x10
    4848:	aa0003e1 	mov	x1, x0
    484c:	aa0203e0 	mov	x0, x2
    4850:	f9400062 	ldr	x2, [x3]
    4854:	f9010fe2 	str	x2, [sp, #536]
    4858:	d2800002 	mov	x2, #0x0                   	// #0
    485c:	f90003f4 	str	x20, [sp]
    4860:	f9000080 	str	x0, [x4]
    4864:	3c8083e0 	stur	q0, [sp, #8]
    4868:	97ffffa6 	bl	4700 <fwp_closure_drop_push>
    486c:	f94007e0 	ldr	x0, [sp, #8]
    4870:	b40002e0 	cbz	x0, 48cc <fwp_closure_drop.part.0+0xb8>
    4874:	f90123f5 	str	x21, [sp, #576]
    4878:	900000f5 	adrp	x21, 20000 <__data_start>
    487c:	9101c2b5 	add	x21, x21, #0x70
    4880:	14000006 	b	4898 <fwp_closure_drop.part.0+0x84>
    4884:	f9400422 	ldr	x2, [x1, #8]
    4888:	52800001 	mov	w1, #0x0                   	// #0
    488c:	d63f0040 	blr	x2
    4890:	f94007e0 	ldr	x0, [sp, #8]
    4894:	b40001a0 	cbz	x0, 48c8 <fwp_closure_drop.part.0+0xb4>
    4898:	f94003e1 	ldr	x1, [sp]
    489c:	d1000400 	sub	x0, x0, #0x1
    48a0:	f90007e0 	str	x0, [sp, #8]
    48a4:	f94066a2 	ldr	x2, [x21, #200]
    48a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    48ac:	b9400001 	ldr	w1, [x0]
    48b0:	8b011441 	add	x1, x2, x1, lsl #5
    48b4:	f9400c21 	ldr	x1, [x1, #24]
    48b8:	b5fffe61 	cbnz	x1, 4884 <fwp_closure_drop.part.0+0x70>
    48bc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    48c0:	91332000 	add	x0, x0, #0xcc8
    48c4:	97fffe13 	bl	4110 <fwp_trap>
    48c8:	f94123f5 	ldr	x21, [sp, #576]
    48cc:	91400273 	add	x19, x19, #0x0, lsl #12
    48d0:	91004273 	add	x19, x19, #0x10
    48d4:	f94003e0 	ldr	x0, [sp]
    48d8:	f900027f 	str	xzr, [x19]
    48dc:	eb14001f 	cmp	x0, x20
    48e0:	54000040 	b.eq	48e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48e4:	97fff817 	bl	2940 <free@plt>
    48e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48ec:	f947f400 	ldr	x0, [x0, #4072]
    48f0:	f9410fe2 	ldr	x2, [sp, #536]
    48f4:	f9400001 	ldr	x1, [x0]
    48f8:	eb010042 	subs	x2, x2, x1
    48fc:	d2800001 	mov	x1, #0x0                   	// #0
    4900:	540000a1 	b.ne	4914 <fwp_closure_drop.part.0+0x100>  // b.any
    4904:	910883ff 	add	sp, sp, #0x220
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4910:	d65f03c0 	ret
    4914:	f90123f5 	str	x21, [sp, #576]
    4918:	97fff7da 	bl	2880 <__stack_chk_fail@plt>
    491c:	d503201f 	nop

0000000000004920 <fwp_tape_of>:
    4920:	aa0003e1 	mov	x1, x0
    4924:	92403c00 	and	x0, x0, #0xffff
    4928:	b40000e0 	cbz	x0, 4944 <fwp_tape_of+0x24>
    492c:	d1000402 	sub	x2, x0, #0x1
    4930:	900000e3 	adrp	x3, 20000 <__data_start>
    4934:	9101c060 	add	x0, x3, #0x70
    4938:	f9406800 	ldr	x0, [x0, #208]
    493c:	eb02001f 	cmp	x0, x2
    4940:	540000cc 	b.gt	4958 <fwp_tape_of+0x38>
    4944:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4948:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    494c:	9133e000 	add	x0, x0, #0xcf8
    4950:	910003fd 	mov	x29, sp
    4954:	97fffdef 	bl	4110 <fwp_trap>
    4958:	8b020440 	add	x0, x2, x2, lsl #1
    495c:	f9403863 	ldr	x3, [x3, #112]
    4960:	8b000842 	add	x2, x2, x0, lsl #2
    4964:	d37df042 	lsl	x2, x2, #3
    4968:	8b020060 	add	x0, x3, x2
    496c:	b9400404 	ldr	w4, [x0, #4]
    4970:	34fffea4 	cbz	w4, 4944 <fwp_tape_of+0x24>
    4974:	b8626862 	ldr	w2, [x3, x2]
    4978:	9350fc21 	asr	x1, x1, #16
    497c:	6b01005f 	cmp	w2, w1
    4980:	54fffe21 	b.ne	4944 <fwp_tape_of+0x24>  // b.any
    4984:	d65f03c0 	ret
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_now_ns>:
    4990:	d100c3ff 	sub	sp, sp, #0x30
    4994:	52800020 	mov	w0, #0x1                   	// #1
    4998:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    499c:	f947f442 	ldr	x2, [x2, #4072]
    49a0:	910023e1 	add	x1, sp, #0x8
    49a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    49a8:	910083fd 	add	x29, sp, #0x20
    49ac:	f9400043 	ldr	x3, [x2]
    49b0:	f9000fe3 	str	x3, [sp, #24]
    49b4:	d2800003 	mov	x3, #0x0                   	// #0
    49b8:	97fff77e 	bl	27b0 <clock_gettime@plt>
    49bc:	350002c0 	cbnz	w0, 4a14 <fwp_now_ns+0x84>
    49c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49c4:	d2994003 	mov	x3, #0xca00                	// #51712
    49c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49cc:	9b037c20 	mul	x0, x1, x3
    49d0:	9b437c21 	smulh	x1, x1, x3
    49d4:	ab020000 	adds	x0, x0, x2
    49d8:	937ffc42 	asr	x2, x2, #63
    49dc:	9a020021 	adc	x1, x1, x2
    49e0:	f100001f 	cmp	x0, #0x0
    49e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49e8:	b50001c1 	cbnz	x1, 4a20 <fwp_now_ns+0x90>
    49ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    49f0:	f947f421 	ldr	x1, [x1, #4072]
    49f4:	f9400fe3 	ldr	x3, [sp, #24]
    49f8:	f9400022 	ldr	x2, [x1]
    49fc:	eb020063 	subs	x3, x3, x2
    4a00:	d2800002 	mov	x2, #0x0                   	// #0
    4a04:	54000141 	b.ne	4a2c <fwp_now_ns+0x9c>  // b.any
    4a08:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a0c:	9100c3ff 	add	sp, sp, #0x30
    4a10:	d65f03c0 	ret
    4a14:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4a18:	91352000 	add	x0, x0, #0xd48
    4a1c:	97fffdbd 	bl	4110 <fwp_trap>
    4a20:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4a24:	9135a000 	add	x0, x0, #0xd68
    4a28:	97fffdba 	bl	4110 <fwp_trap>
    4a2c:	97fff795 	bl	2880 <__stack_chk_fail@plt>

0000000000004a30 <fwp_poll_events>:
    4a30:	d10103ff 	sub	sp, sp, #0x40
    4a34:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4a38:	f947f400 	ldr	x0, [x0, #4072]
    4a3c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a40:	910083fd 	add	x29, sp, #0x20
    4a44:	f9001bf3 	str	x19, [sp, #48]
    4a48:	900000f3 	adrp	x19, 20000 <__data_start>
    4a4c:	f9400001 	ldr	x1, [x0]
    4a50:	f9000fe1 	str	x1, [sp, #24]
    4a54:	d2800001 	mov	x1, #0x0                   	// #0
    4a58:	97ffffce 	bl	4990 <fwp_now_ns>
    4a5c:	9101c261 	add	x1, x19, #0x70
    4a60:	f9406c21 	ldr	x1, [x1, #216]
    4a64:	b4000e01 	cbz	x1, 4c24 <fwp_poll_events+0x1f4>
    4a68:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a6c:	14000005 	b	4a80 <fwp_poll_events+0x50>
    4a70:	f9408821 	ldr	x1, [x1, #272]
    4a74:	eb03005f 	cmp	x2, x3
    4a78:	9a83d042 	csel	x2, x2, x3, le
    4a7c:	b40000c1 	cbz	x1, 4a94 <fwp_poll_events+0x64>
    4a80:	f9403423 	ldr	x3, [x1, #104]
    4a84:	b6ffff62 	tbz	x2, #63, 4a70 <fwp_poll_events+0x40>
    4a88:	f9408821 	ldr	x1, [x1, #272]
    4a8c:	aa0303e2 	mov	x2, x3
    4a90:	b5ffff81 	cbnz	x1, 4a80 <fwp_poll_events+0x50>
    4a94:	b7f80c82 	tbnz	x2, #63, 4c24 <fwp_poll_events+0x1f4>
    4a98:	cb000042 	sub	x2, x2, x0
    4a9c:	f100005f 	cmp	x2, #0x0
    4aa0:	540003ad 	b.le	4b14 <fwp_poll_events+0xe4>
    4aa4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4aa8:	d2884804 	mov	x4, #0x4240                	// #16960
    4aac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4ab0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4ab4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4ab8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4abc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ac0:	9b407c40 	smulh	x0, x2, x0
    4ac4:	9352fc00 	asr	x0, x0, #18
    4ac8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4acc:	9b048802 	msub	x2, x0, x4, x2
    4ad0:	f100005f 	cmp	x2, #0x0
    4ad4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ad8:	eb01001f 	cmp	x0, x1
    4adc:	5400098c 	b.gt	4c0c <fwp_poll_events+0x1dc>
    4ae0:	340001a0 	cbz	w0, 4b14 <fwp_poll_events+0xe4>
    4ae4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ae8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4aec:	72a20c41 	movk	w1, #0x1062, lsl #16
    4af0:	9ba17c01 	umull	x1, w0, w1
    4af4:	d366fc23 	lsr	x3, x1, #38
    4af8:	aa0303e2 	mov	x2, x3
    4afc:	1b058063 	msub	w3, w3, w5, w0
    4b00:	9b247c63 	smull	x3, w3, w4
    4b04:	910023e0 	add	x0, sp, #0x8
    4b08:	d2800001 	mov	x1, #0x0                   	// #0
    4b0c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b10:	97fff790 	bl	2950 <nanosleep@plt>
    4b14:	97ffff9f 	bl	4990 <fwp_now_ns>
    4b18:	9101c268 	add	x8, x19, #0x70
    4b1c:	aa0003e7 	mov	x7, x0
    4b20:	4f000400 	movi	v0.4s, #0x0
    4b24:	52800029 	mov	w9, #0x1                   	// #1
    4b28:	f9406d06 	ldr	x6, [x8, #216]
    4b2c:	d503201f 	nop
    4b30:	b40003e6 	cbz	x6, 4bac <fwp_poll_events+0x17c>
    4b34:	f94034c1 	ldr	x1, [x6, #104]
    4b38:	aa0603e5 	mov	x5, x6
    4b3c:	f94088c6 	ldr	x6, [x6, #272]
    4b40:	eb07003f 	cmp	x1, x7
    4b44:	54ffff6c 	b.gt	4b30 <fwp_poll_events+0x100>
    4b48:	394154a0 	ldrb	w0, [x5, #85]
    4b4c:	36000120 	tbz	w0, #0, 4b70 <fwp_poll_events+0x140>
    4b50:	f94084a0 	ldr	x0, [x5, #264]
    4b54:	b4000560 	cbz	x0, 4c00 <fwp_poll_events+0x1d0>
    4b58:	f9008806 	str	x6, [x0, #272]
    4b5c:	b4000046 	cbz	x6, 4b64 <fwp_poll_events+0x134>
    4b60:	f90084c0 	str	x0, [x6, #264]
    4b64:	910800a0 	add	x0, x5, #0x200
    4b68:	390154bf 	strb	wzr, [x5, #85]
    4b6c:	3c908000 	stur	q0, [x0, #-248]
    4b70:	f94030a0 	ldr	x0, [x5, #96]
    4b74:	390158a9 	strb	w9, [x5, #86]
    4b78:	f100001f 	cmp	x0, #0x0
    4b7c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b80:	540002cd 	b.le	4bd8 <fwp_poll_events+0x1a8>
    4b84:	f94028a0 	ldr	x0, [x5, #80]
    4b88:	f2001c1f 	tst	x0, #0xff000000ff
    4b8c:	54fffd21 	b.ne	4b30 <fwp_poll_events+0x100>  // b.any
    4b90:	f9403d00 	ldr	x0, [x8, #120]
    4b94:	390150a9 	strb	w9, [x5, #84]
    4b98:	f90080bf 	str	xzr, [x5, #256]
    4b9c:	b40002c0 	cbz	x0, 4bf4 <fwp_poll_events+0x1c4>
    4ba0:	f9003d05 	str	x5, [x8, #120]
    4ba4:	f9008005 	str	x5, [x0, #256]
    4ba8:	b5fffc66 	cbnz	x6, 4b34 <fwp_poll_events+0x104>
    4bac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4bb0:	f947f400 	ldr	x0, [x0, #4072]
    4bb4:	f9400fe2 	ldr	x2, [sp, #24]
    4bb8:	f9400001 	ldr	x1, [x0]
    4bbc:	eb010042 	subs	x2, x2, x1
    4bc0:	d2800001 	mov	x1, #0x0                   	// #0
    4bc4:	540002e1 	b.ne	4c20 <fwp_poll_events+0x1f0>  // b.any
    4bc8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bcc:	f9401bf3 	ldr	x19, [sp, #48]
    4bd0:	910103ff 	add	sp, sp, #0x40
    4bd4:	d65f03c0 	ret
    4bd8:	394144a0 	ldrb	w0, [x5, #81]
    4bdc:	3707fd40 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be0:	394140a0 	ldrb	w0, [x5, #80]
    4be4:	3707fd00 	tbnz	w0, #0, 4b84 <fwp_poll_events+0x154>
    4be8:	aa0503e0 	mov	x0, x5
    4bec:	97fffac1 	bl	36f0 <fwp_cancel_tree.part.0>
    4bf0:	17ffffe5 	b	4b84 <fwp_poll_events+0x154>
    4bf4:	f9003d05 	str	x5, [x8, #120]
    4bf8:	f9004105 	str	x5, [x8, #128]
    4bfc:	17ffffeb 	b	4ba8 <fwp_poll_events+0x178>
    4c00:	9101c261 	add	x1, x19, #0x70
    4c04:	f9006c26 	str	x6, [x1, #216]
    4c08:	17ffffd5 	b	4b5c <fwp_poll_events+0x12c>
    4c0c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c10:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c14:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c18:	f2a00402 	movk	x2, #0x20, lsl #16
    4c1c:	17ffffba 	b	4b04 <fwp_poll_events+0xd4>
    4c20:	97fff718 	bl	2880 <__stack_chk_fail@plt>
    4c24:	97fff8f3 	bl	2ff0 <fwp_flush>
    4c28:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4c2c:	f947e863 	ldr	x3, [x3, #4048]
    4c30:	d2800562 	mov	x2, #0x2b                  	// #43
    4c34:	d2800021 	mov	x1, #0x1                   	// #1
    4c38:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    4c3c:	91364000 	add	x0, x0, #0xd90
    4c40:	f9400063 	ldr	x3, [x3]
    4c44:	97fff74f 	bl	2980 <fwrite@plt>
    4c48:	52800ca0 	mov	w0, #0x65                  	// #101
    4c4c:	97fff6b9 	bl	2730 <exit@plt>

0000000000004c50 <fwp_heap_alloc_big>:
    4c50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c54:	910003fd 	mov	x29, sp
    4c58:	a90153f3 	stp	x19, x20, [sp, #16]
    4c5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c60:	a90363f7 	stp	x23, x24, [sp, #48]
    4c64:	aa0003f7 	mov	x23, x0
    4c68:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c70:	eb0002ff 	cmp	x23, x0
    4c74:	540008a8 	b.hi	4d88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c78:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c7c:	8b0002f4 	add	x20, x23, x0
    4c80:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c84:	91174359 	add	x25, x26, #0x5d0
    4c88:	d350fe94 	lsr	x20, x20, #16
    4c8c:	2a0103f5 	mov	w21, w1
    4c90:	aa1403e0 	mov	x0, x20
    4c94:	97fff987 	bl	32b0 <fwp_heap_chunks>
    4c98:	f949ff22 	ldr	x2, [x25, #5112]
    4c9c:	8b000813 	add	x19, x0, x0, lsl #2
    4ca0:	aa0003f8 	mov	x24, x0
    4ca4:	52800043 	mov	w3, #0x2                   	// #2
    4ca8:	d37df273 	lsl	x19, x19, #3
    4cac:	d2800021 	mov	x1, #0x1                   	// #1
    4cb0:	8b130040 	add	x0, x2, x19
    4cb4:	38336843 	strb	w3, [x2, x19]
    4cb8:	39000415 	strb	w21, [x0, #1]
    4cbc:	b9000c14 	str	w20, [x0, #12]
    4cc0:	f9000817 	str	x23, [x0, #16]
    4cc4:	97fffd57 	bl	4220 <fwp_rc_prepare_chunk>
    4cc8:	f100069f 	cmp	x20, #0x1
    4ccc:	54000289 	b.ls	4d1c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cd0:	8b180294 	add	x20, x20, x24
    4cd4:	9100a273 	add	x19, x19, #0x28
    4cd8:	a90573fb 	stp	x27, x28, [sp, #80]
    4cdc:	5280007b 	mov	w27, #0x3                   	// #3
    4ce0:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce4:	2a1803fc 	mov	w28, w24
    4ce8:	9adb2296 	lsl	x22, x20, x27
    4cec:	d503201f 	nop
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffd48 	bl	4220 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x108>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffbbf 	bl	3d70 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff6f 	b	4c50 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffd19 	bl	4340 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94066e0 	ldr	x0, [x23, #200]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_tape_reserve>:
    5224:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5228:	910003fd 	mov	x29, sp
    522c:	a90153f3 	stp	x19, x20, [sp, #16]
    5230:	aa0003f3 	mov	x19, x0
    5234:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5238:	eb00003f 	cmp	x1, x0
    523c:	54000868 	b.hi	5348 <fwp_tape_reserve+0x124>  // b.pmore
    5240:	f9400e74 	ldr	x20, [x19, #24]
    5244:	eb01029f 	cmp	x20, x1
    5248:	5400076a 	b.ge	5334 <fwp_tape_reserve+0x110>  // b.tcont
    524c:	f100029f 	cmp	x20, #0x0
    5250:	d2800802 	mov	x2, #0x40                  	// #64
    5254:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5258:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    525c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5260:	a90363f7 	stp	x23, x24, [sp, #48]
    5264:	eb01029f 	cmp	x20, x1
    5268:	5400008a 	b.ge	5278 <fwp_tape_reserve+0x54>  // b.tcont
    526c:	eb00029f 	cmp	x20, x0
    5270:	5400068d 	b.le	5340 <fwp_tape_reserve+0x11c>
    5274:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5278:	a940d662 	ldp	x2, x21, [x19, #8]
    527c:	d37df297 	lsl	x23, x20, #3
    5280:	f9401260 	ldr	x0, [x19, #32]
    5284:	aa1703e1 	mov	x1, x23
    5288:	f9403276 	ldr	x22, [x19, #96]
    528c:	cb0202b5 	sub	x21, x21, x2
    5290:	97fff578 	bl	2870 <realloc@plt>
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_tape_reserve+0x1d0>
    5298:	f9400e61 	ldr	x1, [x19, #24]
    529c:	8b010801 	add	x1, x0, x1, lsl #2
    52a0:	a9020660 	stp	x0, x1, [x19, #32]
    52a4:	b40008b6 	cbz	x22, 53b8 <fwp_tape_reserve+0x194>
    52a8:	f94032d7 	ldr	x23, [x22, #96]
    52ac:	eb17029f 	cmp	x20, x23
    52b0:	5400034d 	b.le	5318 <fwp_tape_reserve+0xf4>
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	d37cee9a 	lsl	x26, x20, #4
    52bc:	aa1a03e0 	mov	x0, x26
    52c0:	f94022d9 	ldr	x25, [x22, #64]
    52c4:	52800041 	mov	w1, #0x2                   	// #2
    52c8:	97ffff0a 	bl	4ef0 <fwp_heap_alloc>
    52cc:	aa0003f8 	mov	x24, x0
    52d0:	b4000119 	cbz	x25, 52f0 <fwp_tape_reserve+0xcc>
    52d4:	d37ceef7 	lsl	x23, x23, #4
    52d8:	aa1903e1 	mov	x1, x25
    52dc:	eb1a02ff 	cmp	x23, x26
    52e0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    52e4:	97fff4fb 	bl	26d0 <memcpy@plt>
    52e8:	aa1903e0 	mov	x0, x25
    52ec:	97fffc45 	bl	4400 <fwp_mem_free>
    52f0:	f94032c0 	ldr	x0, [x22, #96]
    52f4:	52800001 	mov	w1, #0x0                   	// #0
    52f8:	cb000282 	sub	x2, x20, x0
    52fc:	8b001300 	add	x0, x24, x0, lsl #4
    5300:	d37cec42 	lsl	x2, x2, #4
    5304:	97fff553 	bl	2850 <memset@plt>
    5308:	f9401260 	ldr	x0, [x19, #32]
    530c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5310:	f90022d8 	str	x24, [x22, #64]
    5314:	f90032d4 	str	x20, [x22, #96]
    5318:	d37ef696 	lsl	x22, x20, #2
    531c:	b5000375 	cbnz	x21, 5388 <fwp_tape_reserve+0x164>
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	8b160000 	add	x0, x0, x22
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000e74 	str	x20, [x19, #24]
    5330:	f9001660 	str	x0, [x19, #40]
    5334:	a94153f3 	ldp	x19, x20, [sp, #16]
    5338:	a8c57bfd 	ldp	x29, x30, [sp], #80
    533c:	d65f03c0 	ret
    5340:	d37ffa94 	lsl	x20, x20, #1
    5344:	17ffffc8 	b	5264 <fwp_tape_reserve+0x40>
    5348:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    534c:	9137a000 	add	x0, x0, #0xde8
    5350:	a9025bf5 	stp	x21, x22, [sp, #32]
    5354:	a90363f7 	stp	x23, x24, [sp, #48]
    5358:	a9046bf9 	stp	x25, x26, [sp, #64]
    535c:	97fffb6d 	bl	4110 <fwp_trap>
    5360:	eb1602ff 	cmp	x23, x22
    5364:	aa0403e0 	mov	x0, x4
    5368:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    536c:	d37df2a2 	lsl	x2, x21, #3
    5370:	cb170063 	sub	x3, x3, x23
    5374:	97fff5ab 	bl	2a20 <__memmove_chk@plt>
    5378:	f9401a61 	ldr	x1, [x19, #48]
    537c:	f9401260 	ldr	x0, [x19, #32]
    5380:	8b170021 	add	x1, x1, x23
    5384:	f9001e61 	str	x1, [x19, #56]
    5388:	f9401661 	ldr	x1, [x19, #40]
    538c:	d37ef696 	lsl	x22, x20, #2
    5390:	d37ef6a2 	lsl	x2, x21, #2
    5394:	8b160000 	add	x0, x0, x22
    5398:	97fff4d6 	bl	26f0 <memmove@plt>
    539c:	f9401260 	ldr	x0, [x19, #32]
    53a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53a4:	8b160000 	add	x0, x0, x22
    53a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ac:	f9000e74 	str	x20, [x19, #24]
    53b0:	f9001660 	str	x0, [x19, #40]
    53b4:	17ffffe0 	b	5334 <fwp_tape_reserve+0x110>
    53b8:	f9401a60 	ldr	x0, [x19, #48]
    53bc:	d37cee96 	lsl	x22, x20, #4
    53c0:	aa1603e1 	mov	x1, x22
    53c4:	97fff52b 	bl	2870 <realloc@plt>
    53c8:	b4000160 	cbz	x0, 53f4 <fwp_tape_reserve+0x1d0>
    53cc:	f9400e62 	ldr	x2, [x19, #24]
    53d0:	f9001a60 	str	x0, [x19, #48]
    53d4:	8b170004 	add	x4, x0, x23
    53d8:	8b020c01 	add	x1, x0, x2, lsl #3
    53dc:	f9001e61 	str	x1, [x19, #56]
    53e0:	b5fffc15 	cbnz	x21, 5360 <fwp_tape_reserve+0x13c>
    53e4:	f9401260 	ldr	x0, [x19, #32]
    53e8:	d37ef696 	lsl	x22, x20, #2
    53ec:	f9001e64 	str	x4, [x19, #56]
    53f0:	17ffffcc 	b	5320 <fwp_tape_reserve+0xfc>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53fc:	97fff6e5 	bl	2f90 <fwp_tape_unlink_scope>
    5400:	f9401260 	ldr	x0, [x19, #32]
    5404:	97fff54f 	bl	2940 <free@plt>
    5408:	f9401a60 	ldr	x0, [x19, #48]
    540c:	97fff54d 	bl	2940 <free@plt>
    5410:	f9402260 	ldr	x0, [x19, #64]
    5414:	97fff54b 	bl	2940 <free@plt>
    5418:	f9000e7f 	str	xzr, [x19, #24]
    541c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5420:	f947e821 	ldr	x1, [x1, #4048]
    5424:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5428:	d2800262 	mov	x2, #0x13                  	// #19
    542c:	4f000400 	movi	v0.4s, #0x0
    5430:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5434:	f9400023 	ldr	x3, [x1]
    5438:	b900067f 	str	wzr, [x19, #4]
    543c:	d2800021 	mov	x1, #0x1                   	// #1
    5440:	91292000 	add	x0, x0, #0xa48
    5444:	3c808260 	stur	q0, [x19, #8]
    5448:	ad010260 	stp	q0, q0, [x19, #32]
    544c:	97fff54d 	bl	2980 <fwrite@plt>
    5450:	d2800000 	mov	x0, #0x0                   	// #0
    5454:	97fff557 	bl	29b0 <fflush@plt>
    5458:	52800cc0 	mov	w0, #0x66                  	// #102
    545c:	97fff565 	bl	29f0 <_Exit@plt>

0000000000005460 <f128.constprop.0>:
    5460:	f100001f 	cmp	x0, #0x0
    5464:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5468:	5400094b 	b.lt	5590 <f128.constprop.0+0x130>  // b.tstop
    546c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5470:	aa0003e2 	mov	x2, x0
    5474:	910003fd 	mov	x29, sp
    5478:	a90153f3 	stp	x19, x20, [sp, #16]
    547c:	aa0003f4 	mov	x20, x0
    5480:	aa010000 	orr	x0, x0, x1
    5484:	a9025bf5 	stp	x21, x22, [sp, #32]
    5488:	aa0103f6 	mov	x22, x1
    548c:	f9001bf7 	str	x23, [sp, #48]
    5490:	fd001fe8 	str	d8, [sp, #56]
    5494:	b7f80180 	tbnz	x0, #63, 54c4 <f128.constprop.0+0x64>
    5498:	9360fc20 	asr	x0, x1, #32
    549c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54a0:	eb82801f 	cmp	x0, x2, asr #32
    54a4:	540007a1 	b.ne	5598 <f128.constprop.0+0x138>  // b.any
    54a8:	97fffd1e 	bl	4920 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b40001e0 	cbz	x0, 54f0 <f128.constprop.0+0x90>
    54b8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    54bc:	91394000 	add	x0, x0, #0xe50
    54c0:	97fffb14 	bl	4110 <fwp_trap>
    54c4:	9360fc40 	asr	x0, x2, #32
    54c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    54cc:	b6fffee2 	tbz	x2, #63, 54a8 <f128.constprop.0+0x48>
    54d0:	2f00e408 	movi	d8, #0x0
    54d4:	9360fc20 	asr	x0, x1, #32
    54d8:	aa0103f4 	mov	x20, x1
    54dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    54e0:	97fffd10 	bl	4920 <fwp_tape_of>
    54e4:	aa0003f3 	mov	x19, x0
    54e8:	f9403000 	ldr	x0, [x0, #96]
    54ec:	b5fffe60 	cbnz	x0, 54b8 <f128.constprop.0+0x58>
    54f0:	f9400a77 	ldr	x23, [x19, #16]
    54f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54f8:	eb0002ff 	cmp	x23, x0
    54fc:	5400044c 	b.gt	5584 <f128.constprop.0+0x124>
    5500:	eb3442ff 	cmp	x23, w20, uxtw
    5504:	5400008d 	b.le	5514 <f128.constprop.0+0xb4>
    5508:	b7f800d6 	tbnz	x22, #63, 5520 <f128.constprop.0+0xc0>
    550c:	eb3642ff 	cmp	x23, w22, uxtw
    5510:	5400008c 	b.gt	5520 <f128.constprop.0+0xc0>
    5514:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5518:	913a0000 	add	x0, x0, #0xe80
    551c:	97fffafd 	bl	4110 <fwp_trap>
    5520:	f9400675 	ldr	x21, [x19, #8]
    5524:	aa1303e0 	mov	x0, x19
    5528:	cb1502f5 	sub	x21, x23, x21
    552c:	910006a1 	add	x1, x21, #0x1
    5530:	97ffff3d 	bl	5224 <fwp_tape_reserve>
    5534:	a9420262 	ldp	x2, x0, [x19, #32]
    5538:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    553c:	f9401a61 	ldr	x1, [x19, #48]
    5540:	b8357854 	str	w20, [x2, x21, lsl #2]
    5544:	f9401e62 	ldr	x2, [x19, #56]
    5548:	f10002df 	cmp	x22, #0x0
    554c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5550:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5554:	b8357816 	str	w22, [x0, x21, lsl #2]
    5558:	92607e80 	and	x0, x20, #0xffffffff00000000
    555c:	910006e1 	add	x1, x23, #0x1
    5560:	aa170000 	orr	x0, x0, x23
    5564:	fc357848 	str	d8, [x2, x21, lsl #3]
    5568:	a9425bf5 	ldp	x21, x22, [sp, #32]
    556c:	f9401bf7 	ldr	x23, [sp, #48]
    5570:	fd401fe8 	ldr	d8, [sp, #56]
    5574:	f9000a61 	str	x1, [x19, #16]
    5578:	a94153f3 	ldp	x19, x20, [sp, #16]
    557c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5580:	d65f03c0 	ret
    5584:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5588:	9137a000 	add	x0, x0, #0xde8
    558c:	97fffae1 	bl	4110 <fwp_trap>
    5590:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5594:	d65f03c0 	ret
    5598:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    559c:	91382000 	add	x0, x0, #0xe08
    55a0:	97fffadc 	bl	4110 <fwp_trap>

00000000000055a4 <w107>:
    55a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    55a8:	910003fd 	mov	x29, sp
    55ac:	a90153f3 	stp	x19, x20, [sp, #16]
    55b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    55b4:	aa0003f5 	mov	x21, x0
    55b8:	a90363f7 	stp	x23, x24, [sp, #48]
    55bc:	aa0103f7 	mov	x23, x1
    55c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    55c4:	f9002bfb 	str	x27, [sp, #80]
    55c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    55cc:	1e604028 	fmov	d8, d1
    55d0:	1e600809 	fmul	d9, d0, d0
    55d4:	6d072fea 	stp	d10, d11, [sp, #112]
    55d8:	1e60400b 	fmov	d11, d0
    55dc:	b7f81c80 	tbnz	x0, #63, 596c <w107+0x3c8>
    55e0:	9360fc19 	asr	x25, x0, #32
    55e4:	aa1903e0 	mov	x0, x25
    55e8:	97fffcce 	bl	4920 <fwp_tape_of>
    55ec:	f9403001 	ldr	x1, [x0, #96]
    55f0:	aa0003f3 	mov	x19, x0
    55f4:	b4000081 	cbz	x1, 5604 <w107+0x60>
    55f8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    55fc:	91394000 	add	x0, x0, #0xe50
    5600:	97fffac4 	bl	4110 <fwp_trap>
    5604:	f9400818 	ldr	x24, [x0, #16]
    5608:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    560c:	eb01031f 	cmp	x24, x1
    5610:	54001a8c 	b.gt	5960 <w107+0x3bc>
    5614:	eb35431f 	cmp	x24, w21, uxtw
    5618:	540019ed 	b.le	5954 <w107+0x3b0>
    561c:	f9400416 	ldr	x22, [x0, #8]
    5620:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5624:	aa180294 	orr	x20, x20, x24
    5628:	cb160316 	sub	x22, x24, x22
    562c:	910006c1 	add	x1, x22, #0x1
    5630:	97fffefd 	bl	5224 <fwp_tape_reserve>
    5634:	a9420a61 	ldp	x1, x2, [x19, #32]
    5638:	91000700 	add	x0, x24, #0x1
    563c:	f9401a63 	ldr	x3, [x19, #48]
    5640:	b8367835 	str	w21, [x1, x22, lsl #2]
    5644:	f9401e61 	ldr	x1, [x19, #56]
    5648:	1e693908 	fsub	d8, d8, d9
    564c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5650:	9360fe9a 	asr	x26, x20, #32
    5654:	b8367855 	str	w21, [x2, x22, lsl #2]
    5658:	fc36782b 	str	d11, [x1, x22, lsl #3]
    565c:	f9000a60 	str	x0, [x19, #16]
    5660:	b7f80077 	tbnz	x23, #63, 566c <w107+0xc8>
    5664:	eb97835f 	cmp	x26, x23, asr #32
    5668:	540019a1 	b.ne	599c <w107+0x3f8>  // b.any
    566c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5670:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5674:	eb19035f 	cmp	x26, x25
    5678:	540000c0 	b.eq	5690 <w107+0xec>  // b.none
    567c:	aa1a03e0 	mov	x0, x26
    5680:	97fffca8 	bl	4920 <fwp_tape_of>
    5684:	aa0003f3 	mov	x19, x0
    5688:	f9403000 	ldr	x0, [x0, #96]
    568c:	b5fffb60 	cbnz	x0, 55f8 <w107+0x54>
    5690:	f9400a79 	ldr	x25, [x19, #16]
    5694:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5698:	eb00033f 	cmp	x25, x0
    569c:	5400162c 	b.gt	5960 <w107+0x3bc>
    56a0:	eb34433f 	cmp	x25, w20, uxtw
    56a4:	5400158d 	b.le	5954 <w107+0x3b0>
    56a8:	b7f80077 	tbnz	x23, #63, 56b4 <w107+0x110>
    56ac:	eb37433f 	cmp	x25, w23, uxtw
    56b0:	5400152d 	b.le	5954 <w107+0x3b0>
    56b4:	f9400676 	ldr	x22, [x19, #8]
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	cb160336 	sub	x22, x25, x22
    56c0:	910006c1 	add	x1, x22, #0x1
    56c4:	97fffed8 	bl	5224 <fwp_tape_reserve>
    56c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    56cc:	f10002ff 	cmp	x23, #0x0
    56d0:	f9401a61 	ldr	x1, [x19, #48]
    56d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    56d8:	f9401e62 	ldr	x2, [x19, #56]
    56dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    56e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    56e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    56ec:	91000737 	add	x23, x25, #0x1
    56f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    56f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    56fc:	aa190294 	orr	x20, x20, x25
    5700:	f9000a77 	str	x23, [x19, #16]
    5704:	1e6b3929 	fsub	d9, d9, d11
    5708:	b7f81675 	tbnz	x21, #63, 59d4 <w107+0x430>
    570c:	9360febb 	asr	x27, x21, #32
    5710:	eb1a037f 	cmp	x27, x26
    5714:	540000e0 	b.eq	5730 <w107+0x18c>  // b.none
    5718:	aa1b03e0 	mov	x0, x27
    571c:	97fffc81 	bl	4920 <fwp_tape_of>
    5720:	aa0003f3 	mov	x19, x0
    5724:	f9403000 	ldr	x0, [x0, #96]
    5728:	b5fff680 	cbnz	x0, 55f8 <w107+0x54>
    572c:	f9400a77 	ldr	x23, [x19, #16]
    5730:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5734:	eb0002ff 	cmp	x23, x0
    5738:	5400114c 	b.gt	5960 <w107+0x3bc>
    573c:	eb3542ff 	cmp	x23, w21, uxtw
    5740:	540010ad 	b.le	5954 <w107+0x3b0>
    5744:	f9400676 	ldr	x22, [x19, #8]
    5748:	aa1303e0 	mov	x0, x19
    574c:	cb1602f6 	sub	x22, x23, x22
    5750:	910006c1 	add	x1, x22, #0x1
    5754:	97fffeb4 	bl	5224 <fwp_tape_reserve>
    5758:	a9420261 	ldp	x1, x0, [x19, #32]
    575c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5760:	f9401a63 	ldr	x3, [x19, #48]
    5764:	b8367835 	str	w21, [x1, x22, lsl #2]
    5768:	f9401e61 	ldr	x1, [x19, #56]
    576c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5770:	fc367860 	str	d0, [x3, x22, lsl #3]
    5774:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5778:	b8367802 	str	w2, [x0, x22, lsl #2]
    577c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5780:	910006e0 	add	x0, x23, #0x1
    5784:	aa1702b7 	orr	x23, x21, x23
    5788:	fc367820 	str	d0, [x1, x22, lsl #3]
    578c:	f9000a60 	str	x0, [x19, #16]
    5790:	9360fe99 	asr	x25, x20, #32
    5794:	1e68090a 	fmul	d10, d8, d8
    5798:	eb1b033f 	cmp	x25, x27
    579c:	540000c0 	b.eq	57b4 <w107+0x210>  // b.none
    57a0:	aa1903e0 	mov	x0, x25
    57a4:	97fffc5f 	bl	4920 <fwp_tape_of>
    57a8:	aa0003f3 	mov	x19, x0
    57ac:	f9403000 	ldr	x0, [x0, #96]
    57b0:	b5fff240 	cbnz	x0, 55f8 <w107+0x54>
    57b4:	f9400a75 	ldr	x21, [x19, #16]
    57b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57bc:	eb0002bf 	cmp	x21, x0
    57c0:	54000d0c 	b.gt	5960 <w107+0x3bc>
    57c4:	eb3442bf 	cmp	x21, w20, uxtw
    57c8:	54000c6d 	b.le	5954 <w107+0x3b0>
    57cc:	f9400678 	ldr	x24, [x19, #8]
    57d0:	aa1303e0 	mov	x0, x19
    57d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    57d8:	cb1802b8 	sub	x24, x21, x24
    57dc:	aa1502d6 	orr	x22, x22, x21
    57e0:	91000701 	add	x1, x24, #0x1
    57e4:	97fffe90 	bl	5224 <fwp_tape_reserve>
    57e8:	a9420261 	ldp	x1, x0, [x19, #32]
    57ec:	f9401a62 	ldr	x2, [x19, #48]
    57f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    57f4:	f9401e61 	ldr	x1, [x19, #56]
    57f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    57fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5800:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5804:	9e670000 	fmov	d0, x0
    5808:	910006b4 	add	x20, x21, #0x1
    580c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5810:	9360fed8 	asr	x24, x22, #32
    5814:	f9000a74 	str	x20, [x19, #16]
    5818:	1e60094a 	fmul	d10, d10, d0
    581c:	eb19031f 	cmp	x24, x25
    5820:	540000e0 	b.eq	583c <w107+0x298>  // b.none
    5824:	aa1803e0 	mov	x0, x24
    5828:	97fffc3e 	bl	4920 <fwp_tape_of>
    582c:	aa0003f3 	mov	x19, x0
    5830:	f9403000 	ldr	x0, [x0, #96]
    5834:	b5ffee20 	cbnz	x0, 55f8 <w107+0x54>
    5838:	f9400a74 	ldr	x20, [x19, #16]
    583c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5840:	eb00029f 	cmp	x20, x0
    5844:	540008ec 	b.gt	5960 <w107+0x3bc>
    5848:	eb36429f 	cmp	x20, w22, uxtw
    584c:	5400084d 	b.le	5954 <w107+0x3b0>
    5850:	f9400675 	ldr	x21, [x19, #8]
    5854:	aa1303e0 	mov	x0, x19
    5858:	cb150295 	sub	x21, x20, x21
    585c:	910006a1 	add	x1, x21, #0x1
    5860:	97fffe71 	bl	5224 <fwp_tape_reserve>
    5864:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5868:	9e670000 	fmov	d0, x0
    586c:	a9420261 	ldp	x1, x0, [x19, #32]
    5870:	1e690928 	fmul	d8, d9, d9
    5874:	f9401a62 	ldr	x2, [x19, #48]
    5878:	b8357836 	str	w22, [x1, x21, lsl #2]
    587c:	f9401e61 	ldr	x1, [x19, #56]
    5880:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5884:	fc357840 	str	d0, [x2, x21, lsl #3]
    5888:	12800002 	mov	w2, #0xffffffff            	// #-1
    588c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5890:	91000680 	add	x0, x20, #0x1
    5894:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5898:	aa1402d6 	orr	x22, x22, x20
    589c:	f9000a60 	str	x0, [x19, #16]
    58a0:	b10006ff 	cmn	x23, #0x1
    58a4:	540009e0 	b.eq	59e0 <w107+0x43c>  // b.none
    58a8:	9360fee0 	asr	x0, x23, #32
    58ac:	eb18001f 	cmp	x0, x24
    58b0:	540000a0 	b.eq	58c4 <w107+0x320>  // b.none
    58b4:	97fffc1b 	bl	4920 <fwp_tape_of>
    58b8:	aa0003f3 	mov	x19, x0
    58bc:	f9403000 	ldr	x0, [x0, #96]
    58c0:	b5ffe9c0 	cbnz	x0, 55f8 <w107+0x54>
    58c4:	f9400a74 	ldr	x20, [x19, #16]
    58c8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58cc:	eb00029f 	cmp	x20, x0
    58d0:	5400048c 	b.gt	5960 <w107+0x3bc>
    58d4:	eb37429f 	cmp	x20, w23, uxtw
    58d8:	540003ed 	b.le	5954 <w107+0x3b0>
    58dc:	f9400675 	ldr	x21, [x19, #8]
    58e0:	aa1303e0 	mov	x0, x19
    58e4:	cb150295 	sub	x21, x20, x21
    58e8:	910006a1 	add	x1, x21, #0x1
    58ec:	97fffe4e 	bl	5224 <fwp_tape_reserve>
    58f0:	a9420a61 	ldp	x1, x2, [x19, #32]
    58f4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    58f8:	f9401a63 	ldr	x3, [x19, #48]
    58fc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5900:	f9401e61 	ldr	x1, [x19, #56]
    5904:	aa140000 	orr	x0, x0, x20
    5908:	fc357869 	str	d9, [x3, x21, lsl #3]
    590c:	91000694 	add	x20, x20, #0x1
    5910:	b8357857 	str	w23, [x2, x21, lsl #2]
    5914:	fc357829 	str	d9, [x1, x21, lsl #3]
    5918:	f9000a74 	str	x20, [x19, #16]
    591c:	1e6a2908 	fadd	d8, d8, d10
    5920:	aa1603e1 	mov	x1, x22
    5924:	97fffecf 	bl	5460 <f128.constprop.0>
    5928:	aa0003e1 	mov	x1, x0
    592c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5930:	9e660100 	fmov	x0, d8
    5934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5938:	a94363f7 	ldp	x23, x24, [sp, #48]
    593c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5940:	f9402bfb 	ldr	x27, [sp, #80]
    5944:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5948:	6d472fea 	ldp	d10, d11, [sp, #112]
    594c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5950:	d65f03c0 	ret
    5954:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5958:	913a0000 	add	x0, x0, #0xe80
    595c:	97fff9ed 	bl	4110 <fwp_trap>
    5960:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5964:	9137a000 	add	x0, x0, #0xde8
    5968:	97fff9ea 	bl	4110 <fwp_trap>
    596c:	1e693828 	fsub	d8, d1, d9
    5970:	b6f801c1 	tbz	x1, #63, 59a8 <w107+0x404>
    5974:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5978:	1e68090a 	fmul	d10, d8, d8
    597c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5980:	9e670000 	fmov	d0, x0
    5984:	1e6b3828 	fsub	d8, d1, d11
    5988:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    598c:	aa1603e0 	mov	x0, x22
    5990:	1e60094a 	fmul	d10, d10, d0
    5994:	1e680908 	fmul	d8, d8, d8
    5998:	17ffffe1 	b	591c <w107+0x378>
    599c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    59a0:	91382000 	add	x0, x0, #0xe08
    59a4:	97fff9db 	bl	4110 <fwp_trap>
    59a8:	2f00e40a 	movi	d10, #0x0
    59ac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    59b0:	9360fc3a 	asr	x26, x1, #32
    59b4:	aa0103f4 	mov	x20, x1
    59b8:	aa1a03e0 	mov	x0, x26
    59bc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    59c0:	97fffbd8 	bl	4920 <fwp_tape_of>
    59c4:	aa0003f3 	mov	x19, x0
    59c8:	f9403000 	ldr	x0, [x0, #96]
    59cc:	b5ffe160 	cbnz	x0, 55f8 <w107+0x54>
    59d0:	17ffff30 	b	5690 <w107+0xec>
    59d4:	aa1a03fb 	mov	x27, x26
    59d8:	aa0003f7 	mov	x23, x0
    59dc:	17ffff6d 	b	5790 <w107+0x1ec>
    59e0:	aa1703e0 	mov	x0, x23
    59e4:	17ffffce 	b	591c <w107+0x378>
    59e8:	d503201f 	nop
    59ec:	d503201f 	nop

00000000000059f0 <fwp_data.part.0.constprop.0>:
    59f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    59f4:	910003fd 	mov	x29, sp
    59f8:	a90153f3 	stp	x19, x20, [sp, #16]
    59fc:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5a00:	91174283 	add	x3, x20, #0x5d0
    5a04:	a9025bf5 	stp	x21, x22, [sp, #32]
    5a08:	aa0103f5 	mov	x21, x1
    5a0c:	b953a461 	ldr	w1, [x3, #5028]
    5a10:	a90363f7 	stp	x23, x24, [sp, #48]
    5a14:	2a0003f8 	mov	w24, w0
    5a18:	34000701 	cbz	w1, 5af8 <fwp_data.part.0.constprop.0+0x108>
    5a1c:	397e8862 	ldrb	w2, [x3, #4002]
    5a20:	910f0040 	add	x0, x2, #0x3c0
    5a24:	8b020442 	add	x2, x2, x2, lsl #1
    5a28:	d37df042 	lsl	x2, x2, #3
    5a2c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5a30:	2a1703f6 	mov	w22, w23
    5a34:	f8626873 	ldr	x19, [x3, x2]
    5a38:	b40004d3 	cbz	x19, 5ad0 <fwp_data.part.0.constprop.0+0xe0>
    5a3c:	f9400260 	ldr	x0, [x19]
    5a40:	aa2003e0 	mvn	x0, x0
    5a44:	f8226860 	str	x0, [x3, x2]
    5a48:	f10062df 	cmp	x22, #0x18
    5a4c:	540000e9 	b.ls	5a68 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5a50:	d10066c2 	sub	x2, x22, #0x19
    5a54:	91006260 	add	x0, x19, #0x18
    5a58:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5a5c:	52800001 	mov	w1, #0x0                   	// #0
    5a60:	91002042 	add	x2, x2, #0x8
    5a64:	97fff37b 	bl	2850 <memset@plt>
    5a68:	91174282 	add	x2, x20, #0x5d0
    5a6c:	f94a1041 	ldr	x1, [x2, #5152]
    5a70:	ab160021 	adds	x1, x1, x22
    5a74:	540004c2 	b.cs	5b0c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5a78:	f94a1440 	ldr	x0, [x2, #5160]
    5a7c:	f90a1041 	str	x1, [x2, #5152]
    5a80:	eb00003f 	cmp	x1, x0
    5a84:	54000049 	b.ls	5a8c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5a88:	f90a1441 	str	x1, [x2, #5160]
    5a8c:	91174294 	add	x20, x20, #0x5d0
    5a90:	1e6302e1 	ucvtf	d1, w23
    5a94:	fd4a1e80 	ldr	d0, [x20, #5176]
    5a98:	1e612800 	fadd	d0, d0, d1
    5a9c:	fd0a1e80 	str	d0, [x20, #5176]
    5aa0:	52800041 	mov	w1, #0x2                   	// #2
    5aa4:	29000678 	stp	w24, w1, [x19]
    5aa8:	aa1303e0 	mov	x0, x19
    5aac:	f94002a1 	ldr	x1, [x21]
    5ab0:	f9000661 	str	x1, [x19, #8]
    5ab4:	f94006a1 	ldr	x1, [x21, #8]
    5ab8:	f9000a61 	str	x1, [x19, #16]
    5abc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ac0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5ac4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5ac8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5acc:	d65f03c0 	ret
    5ad0:	8b020063 	add	x3, x3, x2
    5ad4:	f9400473 	ldr	x19, [x3, #8]
    5ad8:	b4000113 	cbz	x19, 5af8 <fwp_data.part.0.constprop.0+0x108>
    5adc:	f9400860 	ldr	x0, [x3, #16]
    5ae0:	cb130000 	sub	x0, x0, x19
    5ae4:	eb0002df 	cmp	x22, x0
    5ae8:	54000088 	b.hi	5af8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5aec:	8b160260 	add	x0, x19, x22
    5af0:	f9000460 	str	x0, [x3, #8]
    5af4:	17ffffd5 	b	5a48 <fwp_data.part.0.constprop.0+0x58>
    5af8:	52800001 	mov	w1, #0x0                   	// #0
    5afc:	d2800300 	mov	x0, #0x18                  	// #24
    5b00:	97fffcfc 	bl	4ef0 <fwp_heap_alloc>
    5b04:	aa0003f3 	mov	x19, x0
    5b08:	17ffffe6 	b	5aa0 <fwp_data.part.0.constprop.0+0xb0>
    5b0c:	97fff549 	bl	3030 <fwp_heap_oom>

0000000000005b10 <fwp_rc_share>:
    5b10:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5b14:	91174042 	add	x2, x2, #0x5d0
    5b18:	f949d843 	ldr	x3, [x2, #5040]
    5b1c:	f949ec41 	ldr	x1, [x2, #5080]
    5b20:	cb030000 	sub	x0, x0, x3
    5b24:	eb01401f 	cmp	x0, x1, lsl #16
    5b28:	540003a2 	b.cs	5b9c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5b2c:	d350fc01 	lsr	x1, x0, #16
    5b30:	f949fc44 	ldr	x4, [x2, #5112]
    5b34:	8b010821 	add	x1, x1, x1, lsl #2
    5b38:	d37df021 	lsl	x1, x1, #3
    5b3c:	8b010083 	add	x3, x4, x1
    5b40:	f9401062 	ldr	x2, [x3, #32]
    5b44:	b40002c2 	cbz	x2, 5b9c <fwp_rc_share+0x8c>
    5b48:	38616881 	ldrb	w1, [x4, x1]
    5b4c:	7100083f 	cmp	w1, #0x2
    5b50:	54000220 	b.eq	5b94 <fwp_rc_share+0x84>  // b.none
    5b54:	7100043f 	cmp	w1, #0x1
    5b58:	54000221 	b.ne	5b9c <fwp_rc_share+0x8c>  // b.any
    5b5c:	29430464 	ldp	w4, w1, [x3, #24]
    5b60:	92403c00 	and	x0, x0, #0xffff
    5b64:	9b047c00 	mul	x0, x0, x4
    5b68:	d360fc00 	lsr	x0, x0, #32
    5b6c:	eb01001f 	cmp	x0, x1
    5b70:	54000162 	b.cs	5b9c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5b74:	8b000042 	add	x2, x2, x0
    5b78:	39400040 	ldrb	w0, [x2]
    5b7c:	34000100 	cbz	w0, 5b9c <fwp_rc_share+0x8c>
    5b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5b84:	90000040 	adrp	x0, d000 <fwp_main_thread+0x220>
    5b88:	913a8000 	add	x0, x0, #0xea0
    5b8c:	910003fd 	mov	x29, sp
    5b90:	97fff960 	bl	4110 <fwp_trap>
    5b94:	72003c1f 	tst	w0, #0xffff
    5b98:	54ffff00 	b.eq	5b78 <fwp_rc_share+0x68>  // b.none
    5b9c:	d65f03c0 	ret

0000000000005ba0 <fwp_rc_fresh>:
    5ba0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ba4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5ba8:	91174063 	add	x3, x3, #0x5d0
    5bac:	910003fd 	mov	x29, sp
    5bb0:	a90153f3 	stp	x19, x20, [sp, #16]
    5bb4:	aa0003f3 	mov	x19, x0
    5bb8:	f949d861 	ldr	x1, [x3, #5040]
    5bbc:	f949ec60 	ldr	x0, [x3, #5080]
    5bc0:	cb010261 	sub	x1, x19, x1
    5bc4:	eb00403f 	cmp	x1, x0, lsl #16
    5bc8:	54000322 	b.cs	5c2c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5bcc:	d350fc22 	lsr	x2, x1, #16
    5bd0:	f949fc63 	ldr	x3, [x3, #5112]
    5bd4:	8b020842 	add	x2, x2, x2, lsl #2
    5bd8:	d37df042 	lsl	x2, x2, #3
    5bdc:	8b020060 	add	x0, x3, x2
    5be0:	f9401014 	ldr	x20, [x0, #32]
    5be4:	b4000254 	cbz	x20, 5c2c <fwp_rc_fresh+0x8c>
    5be8:	38626862 	ldrb	w2, [x3, x2]
    5bec:	7100085f 	cmp	w2, #0x2
    5bf0:	54000260 	b.eq	5c3c <fwp_rc_fresh+0x9c>  // b.none
    5bf4:	7100045f 	cmp	w2, #0x1
    5bf8:	540001a1 	b.ne	5c2c <fwp_rc_fresh+0x8c>  // b.any
    5bfc:	29430002 	ldp	w2, w0, [x0, #24]
    5c00:	92403c21 	and	x1, x1, #0xffff
    5c04:	9b027c21 	mul	x1, x1, x2
    5c08:	d360fc21 	lsr	x1, x1, #32
    5c0c:	eb00003f 	cmp	x1, x0
    5c10:	540000e2 	b.cs	5c2c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5c14:	8b010294 	add	x20, x20, x1
    5c18:	39400280 	ldrb	w0, [x20]
    5c1c:	7103fc1f 	cmp	w0, #0xff
    5c20:	540001a0 	b.eq	5c54 <fwp_rc_fresh+0xb4>  // b.none
    5c24:	52800020 	mov	w0, #0x1                   	// #1
    5c28:	39000280 	strb	w0, [x20]
    5c2c:	aa1303e0 	mov	x0, x19
    5c30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c34:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c38:	d65f03c0 	ret
    5c3c:	72003c3f 	tst	w1, #0xffff
    5c40:	54fffec0 	b.eq	5c18 <fwp_rc_fresh+0x78>  // b.none
    5c44:	aa1303e0 	mov	x0, x19
    5c48:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c50:	d65f03c0 	ret
    5c54:	aa1403e0 	mov	x0, x20
    5c58:	97fff94e 	bl	4190 <fwp_rc_forget_slot.part.0>
    5c5c:	17fffff2 	b	5c24 <fwp_rc_fresh+0x84>

0000000000005c60 <fwp_rc_free_arr>:
    5c60:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5c64:	91174063 	add	x3, x3, #0x5d0
    5c68:	f949d861 	ldr	x1, [x3, #5040]
    5c6c:	f949ec62 	ldr	x2, [x3, #5080]
    5c70:	cb010001 	sub	x1, x0, x1
    5c74:	eb02403f 	cmp	x1, x2, lsl #16
    5c78:	54000342 	b.cs	5ce0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c7c:	d350fc22 	lsr	x2, x1, #16
    5c80:	f949fc65 	ldr	x5, [x3, #5112]
    5c84:	8b020842 	add	x2, x2, x2, lsl #2
    5c88:	d37df042 	lsl	x2, x2, #3
    5c8c:	8b0200a4 	add	x4, x5, x2
    5c90:	f9401083 	ldr	x3, [x4, #32]
    5c94:	b4000263 	cbz	x3, 5ce0 <fwp_rc_free_arr+0x80>
    5c98:	386268a2 	ldrb	w2, [x5, x2]
    5c9c:	7100085f 	cmp	w2, #0x2
    5ca0:	540001c0 	b.eq	5cd8 <fwp_rc_free_arr+0x78>  // b.none
    5ca4:	7100045f 	cmp	w2, #0x1
    5ca8:	540001c1 	b.ne	5ce0 <fwp_rc_free_arr+0x80>  // b.any
    5cac:	29430885 	ldp	w5, w2, [x4, #24]
    5cb0:	92403c21 	and	x1, x1, #0xffff
    5cb4:	9b057c21 	mul	x1, x1, x5
    5cb8:	d360fc21 	lsr	x1, x1, #32
    5cbc:	eb02003f 	cmp	x1, x2
    5cc0:	54000102 	b.cs	5ce0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5cc4:	8b010063 	add	x3, x3, x1
    5cc8:	39400061 	ldrb	w1, [x3]
    5ccc:	7100043f 	cmp	w1, #0x1
    5cd0:	54000081 	b.ne	5ce0 <fwp_rc_free_arr+0x80>  // b.any
    5cd4:	17fff9cb 	b	4400 <fwp_mem_free>
    5cd8:	72003c3f 	tst	w1, #0xffff
    5cdc:	54ffff60 	b.eq	5cc8 <fwp_rc_free_arr+0x68>  // b.none
    5ce0:	d65f03c0 	ret

0000000000005ce4 <fwp_rc_dup>:
    5ce4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5ce8:	91174042 	add	x2, x2, #0x5d0
    5cec:	f949d841 	ldr	x1, [x2, #5040]
    5cf0:	f949ec43 	ldr	x3, [x2, #5080]
    5cf4:	cb010001 	sub	x1, x0, x1
    5cf8:	eb03403f 	cmp	x1, x3, lsl #16
    5cfc:	54000342 	b.cs	5d64 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5d00:	d350fc20 	lsr	x0, x1, #16
    5d04:	f949fc44 	ldr	x4, [x2, #5112]
    5d08:	8b000800 	add	x0, x0, x0, lsl #2
    5d0c:	d37df002 	lsl	x2, x0, #3
    5d10:	8b020083 	add	x3, x4, x2
    5d14:	f9401060 	ldr	x0, [x3, #32]
    5d18:	b4000260 	cbz	x0, 5d64 <fwp_rc_dup+0x80>
    5d1c:	38626882 	ldrb	w2, [x4, x2]
    5d20:	7100085f 	cmp	w2, #0x2
    5d24:	54000220 	b.eq	5d68 <fwp_rc_dup+0x84>  // b.none
    5d28:	7100045f 	cmp	w2, #0x1
    5d2c:	540001c1 	b.ne	5d64 <fwp_rc_dup+0x80>  // b.any
    5d30:	29430864 	ldp	w4, w2, [x3, #24]
    5d34:	92403c21 	and	x1, x1, #0xffff
    5d38:	9b047c21 	mul	x1, x1, x4
    5d3c:	d360fc21 	lsr	x1, x1, #32
    5d40:	eb02003f 	cmp	x1, x2
    5d44:	54000102 	b.cs	5d64 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5d48:	8b010000 	add	x0, x0, x1
    5d4c:	39400001 	ldrb	w1, [x0]
    5d50:	340000a1 	cbz	w1, 5d64 <fwp_rc_dup+0x80>
    5d54:	7103f43f 	cmp	w1, #0xfd
    5d58:	540000e8 	b.hi	5d74 <fwp_rc_dup+0x90>  // b.pmore
    5d5c:	11000421 	add	w1, w1, #0x1
    5d60:	39000001 	strb	w1, [x0]
    5d64:	d65f03c0 	ret
    5d68:	72003c3f 	tst	w1, #0xffff
    5d6c:	54ffff00 	b.eq	5d4c <fwp_rc_dup+0x68>  // b.none
    5d70:	d65f03c0 	ret
    5d74:	17fffa1c 	b	45e4 <fwp_rc_wide_dup>
    5d78:	d503201f 	nop
    5d7c:	d503201f 	nop

0000000000005d80 <fwp_owned_entry161>:
    5d80:	d10103ff 	sub	sp, sp, #0x40
    5d84:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5d88:	f947f442 	ldr	x2, [x2, #4072]
    5d8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d90:	910083fd 	add	x29, sp, #0x20
    5d94:	a90353f3 	stp	x19, x20, [sp, #48]
    5d98:	f9400043 	ldr	x3, [x2]
    5d9c:	f9000fe3 	str	x3, [sp, #24]
    5da0:	d2800003 	mov	x3, #0x0                   	// #0
    5da4:	a9400c01 	ldp	x1, x3, [x0]
    5da8:	f9400802 	ldr	x2, [x0, #16]
    5dac:	ab020022 	adds	x2, x1, x2
    5db0:	540006e6 	b.vs	5e8c <fwp_owned_entry161+0x10c>
    5db4:	910023e1 	add	x1, sp, #0x8
    5db8:	52800000 	mov	w0, #0x0                   	// #0
    5dbc:	a9008be3 	stp	x3, x2, [sp, #8]
    5dc0:	97ffff0c 	bl	59f0 <fwp_data.part.0.constprop.0>
    5dc4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5dc8:	91174063 	add	x3, x3, #0x5d0
    5dcc:	aa0003f3 	mov	x19, x0
    5dd0:	f949d861 	ldr	x1, [x3, #5040]
    5dd4:	f949ec60 	ldr	x0, [x3, #5080]
    5dd8:	cb010261 	sub	x1, x19, x1
    5ddc:	eb00403f 	cmp	x1, x0, lsl #16
    5de0:	54000322 	b.cs	5e44 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5de4:	d350fc22 	lsr	x2, x1, #16
    5de8:	f949fc63 	ldr	x3, [x3, #5112]
    5dec:	8b020842 	add	x2, x2, x2, lsl #2
    5df0:	d37df042 	lsl	x2, x2, #3
    5df4:	8b020060 	add	x0, x3, x2
    5df8:	f9401014 	ldr	x20, [x0, #32]
    5dfc:	b4000254 	cbz	x20, 5e44 <fwp_owned_entry161+0xc4>
    5e00:	38626862 	ldrb	w2, [x3, x2]
    5e04:	7100085f 	cmp	w2, #0x2
    5e08:	54000360 	b.eq	5e74 <fwp_owned_entry161+0xf4>  // b.none
    5e0c:	7100045f 	cmp	w2, #0x1
    5e10:	540001a1 	b.ne	5e44 <fwp_owned_entry161+0xc4>  // b.any
    5e14:	29430002 	ldp	w2, w0, [x0, #24]
    5e18:	92403c21 	and	x1, x1, #0xffff
    5e1c:	9b027c21 	mul	x1, x1, x2
    5e20:	d360fc21 	lsr	x1, x1, #32
    5e24:	eb00003f 	cmp	x1, x0
    5e28:	540000e2 	b.cs	5e44 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5e2c:	8b010294 	add	x20, x20, x1
    5e30:	39400280 	ldrb	w0, [x20]
    5e34:	7103fc1f 	cmp	w0, #0xff
    5e38:	54000240 	b.eq	5e80 <fwp_owned_entry161+0x100>  // b.none
    5e3c:	52800020 	mov	w0, #0x1                   	// #1
    5e40:	39000280 	strb	w0, [x20]
    5e44:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5e48:	f947f400 	ldr	x0, [x0, #4072]
    5e4c:	f9400fe2 	ldr	x2, [sp, #24]
    5e50:	f9400001 	ldr	x1, [x0]
    5e54:	eb010042 	subs	x2, x2, x1
    5e58:	d2800001 	mov	x1, #0x0                   	// #0
    5e5c:	540001a1 	b.ne	5e90 <fwp_owned_entry161+0x110>  // b.any
    5e60:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e64:	aa1303e0 	mov	x0, x19
    5e68:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e6c:	910103ff 	add	sp, sp, #0x40
    5e70:	d65f03c0 	ret
    5e74:	72003c3f 	tst	w1, #0xffff
    5e78:	54fffe61 	b.ne	5e44 <fwp_owned_entry161+0xc4>  // b.any
    5e7c:	17ffffed 	b	5e30 <fwp_owned_entry161+0xb0>
    5e80:	aa1403e0 	mov	x0, x20
    5e84:	97fff8c3 	bl	4190 <fwp_rc_forget_slot.part.0>
    5e88:	17ffffed 	b	5e3c <fwp_owned_entry161+0xbc>
    5e8c:	97fff2fd 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5e90:	97fff27c 	bl	2880 <__stack_chk_fail@plt>

0000000000005e94 <e161>:
    5e94:	d10103ff 	sub	sp, sp, #0x40
    5e98:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5e9c:	f947f442 	ldr	x2, [x2, #4072]
    5ea0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ea4:	910083fd 	add	x29, sp, #0x20
    5ea8:	a90353f3 	stp	x19, x20, [sp, #48]
    5eac:	f9400043 	ldr	x3, [x2]
    5eb0:	f9000fe3 	str	x3, [sp, #24]
    5eb4:	d2800003 	mov	x3, #0x0                   	// #0
    5eb8:	a9400c01 	ldp	x1, x3, [x0]
    5ebc:	f9400802 	ldr	x2, [x0, #16]
    5ec0:	ab020022 	adds	x2, x1, x2
    5ec4:	54000726 	b.vs	5fa8 <e161+0x114>
    5ec8:	910023e1 	add	x1, sp, #0x8
    5ecc:	52800000 	mov	w0, #0x0                   	// #0
    5ed0:	a9008be3 	stp	x3, x2, [sp, #8]
    5ed4:	97fffec7 	bl	59f0 <fwp_data.part.0.constprop.0>
    5ed8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5edc:	91174063 	add	x3, x3, #0x5d0
    5ee0:	aa0003f3 	mov	x19, x0
    5ee4:	f949d861 	ldr	x1, [x3, #5040]
    5ee8:	f949ec60 	ldr	x0, [x3, #5080]
    5eec:	cb010261 	sub	x1, x19, x1
    5ef0:	eb00403f 	cmp	x1, x0, lsl #16
    5ef4:	54000322 	b.cs	5f58 <e161+0xc4>  // b.hs, b.nlast
    5ef8:	d350fc22 	lsr	x2, x1, #16
    5efc:	f949fc63 	ldr	x3, [x3, #5112]
    5f00:	8b020842 	add	x2, x2, x2, lsl #2
    5f04:	d37df042 	lsl	x2, x2, #3
    5f08:	8b020060 	add	x0, x3, x2
    5f0c:	f9401014 	ldr	x20, [x0, #32]
    5f10:	b4000254 	cbz	x20, 5f58 <e161+0xc4>
    5f14:	38626862 	ldrb	w2, [x3, x2]
    5f18:	7100085f 	cmp	w2, #0x2
    5f1c:	540003a0 	b.eq	5f90 <e161+0xfc>  // b.none
    5f20:	7100045f 	cmp	w2, #0x1
    5f24:	540001a1 	b.ne	5f58 <e161+0xc4>  // b.any
    5f28:	29430002 	ldp	w2, w0, [x0, #24]
    5f2c:	92403c21 	and	x1, x1, #0xffff
    5f30:	9b027c21 	mul	x1, x1, x2
    5f34:	d360fc21 	lsr	x1, x1, #32
    5f38:	eb00003f 	cmp	x1, x0
    5f3c:	540000e2 	b.cs	5f58 <e161+0xc4>  // b.hs, b.nlast
    5f40:	8b010294 	add	x20, x20, x1
    5f44:	39400280 	ldrb	w0, [x20]
    5f48:	7103fc1f 	cmp	w0, #0xff
    5f4c:	54000280 	b.eq	5f9c <e161+0x108>  // b.none
    5f50:	52800020 	mov	w0, #0x1                   	// #1
    5f54:	39000280 	strb	w0, [x20]
    5f58:	aa1303e0 	mov	x0, x19
    5f5c:	97fffeed 	bl	5b10 <fwp_rc_share>
    5f60:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f64:	f947f400 	ldr	x0, [x0, #4072]
    5f68:	f9400fe2 	ldr	x2, [sp, #24]
    5f6c:	f9400001 	ldr	x1, [x0]
    5f70:	eb010042 	subs	x2, x2, x1
    5f74:	d2800001 	mov	x1, #0x0                   	// #0
    5f78:	540001a1 	b.ne	5fac <e161+0x118>  // b.any
    5f7c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f80:	aa1303e0 	mov	x0, x19
    5f84:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f88:	910103ff 	add	sp, sp, #0x40
    5f8c:	d65f03c0 	ret
    5f90:	72003c3f 	tst	w1, #0xffff
    5f94:	54fffe21 	b.ne	5f58 <e161+0xc4>  // b.any
    5f98:	17ffffeb 	b	5f44 <e161+0xb0>
    5f9c:	aa1403e0 	mov	x0, x20
    5fa0:	97fff87c 	bl	4190 <fwp_rc_forget_slot.part.0>
    5fa4:	17ffffeb 	b	5f50 <e161+0xbc>
    5fa8:	97fff2b6 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5fac:	97fff235 	bl	2880 <__stack_chk_fail@plt>

0000000000005fb0 <fwp_drop1>:
    5fb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fb4:	910003fd 	mov	x29, sp
    5fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fbc:	f90013f5 	str	x21, [sp, #32]
    5fc0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5fc4:	911742b4 	add	x20, x21, #0x5d0
    5fc8:	f949da81 	ldr	x1, [x20, #5040]
    5fcc:	f949ee82 	ldr	x2, [x20, #5080]
    5fd0:	cb010001 	sub	x1, x0, x1
    5fd4:	eb02403f 	cmp	x1, x2, lsl #16
    5fd8:	54000382 	b.cs	6048 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fdc:	d350fc22 	lsr	x2, x1, #16
    5fe0:	f949fe84 	ldr	x4, [x20, #5112]
    5fe4:	8b020842 	add	x2, x2, x2, lsl #2
    5fe8:	d37df042 	lsl	x2, x2, #3
    5fec:	8b020083 	add	x3, x4, x2
    5ff0:	f9401073 	ldr	x19, [x3, #32]
    5ff4:	b40002b3 	cbz	x19, 6048 <fwp_drop1+0x98>
    5ff8:	38626882 	ldrb	w2, [x4, x2]
    5ffc:	7100085f 	cmp	w2, #0x2
    6000:	540002c0 	b.eq	6058 <fwp_drop1+0xa8>  // b.none
    6004:	7100045f 	cmp	w2, #0x1
    6008:	54000201 	b.ne	6048 <fwp_drop1+0x98>  // b.any
    600c:	29430864 	ldp	w4, w2, [x3, #24]
    6010:	92403c21 	and	x1, x1, #0xffff
    6014:	9b047c21 	mul	x1, x1, x4
    6018:	d360fc21 	lsr	x1, x1, #32
    601c:	eb02003f 	cmp	x1, x2
    6020:	54000142 	b.cs	6048 <fwp_drop1+0x98>  // b.hs, b.nlast
    6024:	8b010273 	add	x19, x19, x1
    6028:	39400261 	ldrb	w1, [x19]
    602c:	340000e1 	cbz	w1, 6048 <fwp_drop1+0x98>
    6030:	7100043f 	cmp	w1, #0x1
    6034:	540001e0 	b.eq	6070 <fwp_drop1+0xc0>  // b.none
    6038:	7103fc3f 	cmp	w1, #0xff
    603c:	540002e0 	b.eq	6098 <fwp_drop1+0xe8>  // b.none
    6040:	51000421 	sub	w1, w1, #0x1
    6044:	39000261 	strb	w1, [x19]
    6048:	a94153f3 	ldp	x19, x20, [sp, #16]
    604c:	f94013f5 	ldr	x21, [sp, #32]
    6050:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6054:	d65f03c0 	ret
    6058:	72003c3f 	tst	w1, #0xffff
    605c:	54fffe60 	b.eq	6028 <fwp_drop1+0x78>  // b.none
    6060:	a94153f3 	ldp	x19, x20, [sp, #16]
    6064:	f94013f5 	ldr	x21, [sp, #32]
    6068:	a8c37bfd 	ldp	x29, x30, [sp], #48
    606c:	d65f03c0 	ret
    6070:	f9400813 	ldr	x19, [x0, #16]
    6074:	97fffefb 	bl	5c60 <fwp_rc_free_arr>
    6078:	911742a0 	add	x0, x21, #0x5d0
    607c:	f949d801 	ldr	x1, [x0, #5040]
    6080:	f949ec00 	ldr	x0, [x0, #5080]
    6084:	cb010261 	sub	x1, x19, x1
    6088:	eb00403f 	cmp	x1, x0, lsl #16
    608c:	54fffde2 	b.cs	6048 <fwp_drop1+0x98>  // b.hs, b.nlast
    6090:	aa1303e0 	mov	x0, x19
    6094:	17ffffd2 	b	5fdc <fwp_drop1+0x2c>
    6098:	ca534660 	eor	x0, x19, x19, lsr #17
    609c:	911742b5 	add	x21, x21, #0x5d0
    60a0:	ca402400 	eor	x0, x0, x0, lsr #9
    60a4:	92401c00 	and	x0, x0, #0xff
    60a8:	910a2402 	add	x2, x0, #0x289
    60ac:	8b000ea0 	add	x0, x21, x0, lsl #3
    60b0:	8b020ea2 	add	x2, x21, x2, lsl #3
    60b4:	f94a2400 	ldr	x0, [x0, #5192]
    60b8:	b50000a0 	cbnz	x0, 60cc <fwp_drop1+0x11c>
    60bc:	14000013 	b	6108 <fwp_drop1+0x158>
    60c0:	91004002 	add	x2, x0, #0x10
    60c4:	f9400800 	ldr	x0, [x0, #16]
    60c8:	b4000200 	cbz	x0, 6108 <fwp_drop1+0x158>
    60cc:	f9400001 	ldr	x1, [x0]
    60d0:	eb13003f 	cmp	x1, x19
    60d4:	54ffff61 	b.ne	60c0 <fwp_drop1+0x110>  // b.any
    60d8:	f9400041 	ldr	x1, [x2]
    60dc:	f9400420 	ldr	x0, [x1, #8]
    60e0:	d1000400 	sub	x0, x0, #0x1
    60e4:	f9000420 	str	x0, [x1, #8]
    60e8:	f103f81f 	cmp	x0, #0xfe
    60ec:	54fffae1 	b.ne	6048 <fwp_drop1+0x98>  // b.any
    60f0:	39400260 	ldrb	w0, [x19]
    60f4:	7103fc1f 	cmp	w0, #0xff
    60f8:	540000e0 	b.eq	6114 <fwp_drop1+0x164>  // b.none
    60fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6100:	39000260 	strb	w0, [x19]
    6104:	17ffffd1 	b	6048 <fwp_drop1+0x98>
    6108:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    610c:	9130e000 	add	x0, x0, #0xc38
    6110:	97fff800 	bl	4110 <fwp_trap>
    6114:	aa1303e0 	mov	x0, x19
    6118:	97fff81e 	bl	4190 <fwp_rc_forget_slot.part.0>
    611c:	17fffff8 	b	60fc <fwp_drop1+0x14c>

0000000000006120 <fwp_drop0>:
    6120:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6124:	910003fd 	mov	x29, sp
    6128:	a90153f3 	stp	x19, x20, [sp, #16]
    612c:	f90013f5 	str	x21, [sp, #32]
    6130:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    6134:	911742b4 	add	x20, x21, #0x5d0
    6138:	f949da81 	ldr	x1, [x20, #5040]
    613c:	f949ee82 	ldr	x2, [x20, #5080]
    6140:	cb010001 	sub	x1, x0, x1
    6144:	eb02403f 	cmp	x1, x2, lsl #16
    6148:	54000382 	b.cs	61b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    614c:	d350fc22 	lsr	x2, x1, #16
    6150:	f949fe84 	ldr	x4, [x20, #5112]
    6154:	8b020842 	add	x2, x2, x2, lsl #2
    6158:	d37df042 	lsl	x2, x2, #3
    615c:	8b020083 	add	x3, x4, x2
    6160:	f9401073 	ldr	x19, [x3, #32]
    6164:	b40002b3 	cbz	x19, 61b8 <fwp_drop0+0x98>
    6168:	38626882 	ldrb	w2, [x4, x2]
    616c:	7100085f 	cmp	w2, #0x2
    6170:	540002c0 	b.eq	61c8 <fwp_drop0+0xa8>  // b.none
    6174:	7100045f 	cmp	w2, #0x1
    6178:	54000201 	b.ne	61b8 <fwp_drop0+0x98>  // b.any
    617c:	29430864 	ldp	w4, w2, [x3, #24]
    6180:	92403c21 	and	x1, x1, #0xffff
    6184:	9b047c21 	mul	x1, x1, x4
    6188:	d360fc21 	lsr	x1, x1, #32
    618c:	eb02003f 	cmp	x1, x2
    6190:	54000142 	b.cs	61b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6194:	8b010273 	add	x19, x19, x1
    6198:	39400261 	ldrb	w1, [x19]
    619c:	340000e1 	cbz	w1, 61b8 <fwp_drop0+0x98>
    61a0:	7100043f 	cmp	w1, #0x1
    61a4:	540001e0 	b.eq	61e0 <fwp_drop0+0xc0>  // b.none
    61a8:	7103fc3f 	cmp	w1, #0xff
    61ac:	540002e0 	b.eq	6208 <fwp_drop0+0xe8>  // b.none
    61b0:	51000421 	sub	w1, w1, #0x1
    61b4:	39000261 	strb	w1, [x19]
    61b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    61bc:	f94013f5 	ldr	x21, [sp, #32]
    61c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61c4:	d65f03c0 	ret
    61c8:	72003c3f 	tst	w1, #0xffff
    61cc:	54fffe60 	b.eq	6198 <fwp_drop0+0x78>  // b.none
    61d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    61d4:	f94013f5 	ldr	x21, [sp, #32]
    61d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61dc:	d65f03c0 	ret
    61e0:	f9400813 	ldr	x19, [x0, #16]
    61e4:	97fffe9f 	bl	5c60 <fwp_rc_free_arr>
    61e8:	911742a0 	add	x0, x21, #0x5d0
    61ec:	f949d801 	ldr	x1, [x0, #5040]
    61f0:	f949ec00 	ldr	x0, [x0, #5080]
    61f4:	cb010261 	sub	x1, x19, x1
    61f8:	eb00403f 	cmp	x1, x0, lsl #16
    61fc:	54fffde2 	b.cs	61b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6200:	aa1303e0 	mov	x0, x19
    6204:	17ffffd2 	b	614c <fwp_drop0+0x2c>
    6208:	ca534660 	eor	x0, x19, x19, lsr #17
    620c:	911742b5 	add	x21, x21, #0x5d0
    6210:	ca402400 	eor	x0, x0, x0, lsr #9
    6214:	92401c00 	and	x0, x0, #0xff
    6218:	910a2402 	add	x2, x0, #0x289
    621c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6220:	8b020ea2 	add	x2, x21, x2, lsl #3
    6224:	f94a2400 	ldr	x0, [x0, #5192]
    6228:	b50000a0 	cbnz	x0, 623c <fwp_drop0+0x11c>
    622c:	14000013 	b	6278 <fwp_drop0+0x158>
    6230:	91004002 	add	x2, x0, #0x10
    6234:	f9400800 	ldr	x0, [x0, #16]
    6238:	b4000200 	cbz	x0, 6278 <fwp_drop0+0x158>
    623c:	f9400001 	ldr	x1, [x0]
    6240:	eb13003f 	cmp	x1, x19
    6244:	54ffff61 	b.ne	6230 <fwp_drop0+0x110>  // b.any
    6248:	f9400041 	ldr	x1, [x2]
    624c:	f9400420 	ldr	x0, [x1, #8]
    6250:	d1000400 	sub	x0, x0, #0x1
    6254:	f9000420 	str	x0, [x1, #8]
    6258:	f103f81f 	cmp	x0, #0xfe
    625c:	54fffae1 	b.ne	61b8 <fwp_drop0+0x98>  // b.any
    6260:	39400260 	ldrb	w0, [x19]
    6264:	7103fc1f 	cmp	w0, #0xff
    6268:	540000e0 	b.eq	6284 <fwp_drop0+0x164>  // b.none
    626c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6270:	39000260 	strb	w0, [x19]
    6274:	17ffffd1 	b	61b8 <fwp_drop0+0x98>
    6278:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    627c:	9130e000 	add	x0, x0, #0xc38
    6280:	97fff7a4 	bl	4110 <fwp_trap>
    6284:	aa1303e0 	mov	x0, x19
    6288:	97fff7c2 	bl	4190 <fwp_rc_forget_slot.part.0>
    628c:	17fffff8 	b	626c <fwp_drop0+0x14c>

0000000000006290 <fwp_arg_drop12>:
    6290:	7100003f 	cmp	w1, #0x0
    6294:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6298:	54000041 	b.ne	62a0 <fwp_arg_drop12+0x10>  // b.any
    629c:	d65f03c0 	ret
    62a0:	f9400000 	ldr	x0, [x0]
    62a4:	17ffff9f 	b	6120 <fwp_drop0>
    62a8:	d503201f 	nop
    62ac:	d503201f 	nop

00000000000062b0 <fwp_closure_drop>:
    62b0:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    62b4:	911740a4 	add	x4, x5, #0x5d0
    62b8:	aa0003e1 	mov	x1, x0
    62bc:	f949d882 	ldr	x2, [x4, #5040]
    62c0:	f949ec80 	ldr	x0, [x4, #5080]
    62c4:	cb020022 	sub	x2, x1, x2
    62c8:	eb00405f 	cmp	x2, x0, lsl #16
    62cc:	54000662 	b.cs	6398 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    62d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62d4:	d350fc43 	lsr	x3, x2, #16
    62d8:	910003fd 	mov	x29, sp
    62dc:	8b030863 	add	x3, x3, x3, lsl #2
    62e0:	f949fc84 	ldr	x4, [x4, #5112]
    62e4:	d37df063 	lsl	x3, x3, #3
    62e8:	f9000bf3 	str	x19, [sp, #16]
    62ec:	8b030080 	add	x0, x4, x3
    62f0:	f9401013 	ldr	x19, [x0, #32]
    62f4:	b40002b3 	cbz	x19, 6348 <fwp_closure_drop+0x98>
    62f8:	38636883 	ldrb	w3, [x4, x3]
    62fc:	7100087f 	cmp	w3, #0x2
    6300:	54000420 	b.eq	6384 <fwp_closure_drop+0xd4>  // b.none
    6304:	7100047f 	cmp	w3, #0x1
    6308:	54000201 	b.ne	6348 <fwp_closure_drop+0x98>  // b.any
    630c:	29430003 	ldp	w3, w0, [x0, #24]
    6310:	92403c42 	and	x2, x2, #0xffff
    6314:	9b037c42 	mul	x2, x2, x3
    6318:	d360fc42 	lsr	x2, x2, #32
    631c:	eb00005f 	cmp	x2, x0
    6320:	54000142 	b.cs	6348 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6324:	8b020273 	add	x19, x19, x2
    6328:	39400260 	ldrb	w0, [x19]
    632c:	340000e0 	cbz	w0, 6348 <fwp_closure_drop+0x98>
    6330:	7100041f 	cmp	w0, #0x1
    6334:	54000100 	b.eq	6354 <fwp_closure_drop+0xa4>  // b.none
    6338:	7103fc1f 	cmp	w0, #0xff
    633c:	54000300 	b.eq	639c <fwp_closure_drop+0xec>  // b.none
    6340:	51000400 	sub	w0, w0, #0x1
    6344:	39000260 	strb	w0, [x19]
    6348:	f9400bf3 	ldr	x19, [sp, #16]
    634c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6350:	d65f03c0 	ret
    6354:	d53bd040 	mrs	x0, tpidr_el0
    6358:	91400000 	add	x0, x0, #0x0, lsl #12
    635c:	91004000 	add	x0, x0, #0x10
    6360:	f9400000 	ldr	x0, [x0]
    6364:	b4000080 	cbz	x0, 6374 <fwp_closure_drop+0xc4>
    6368:	f9400bf3 	ldr	x19, [sp, #16]
    636c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6370:	17fff8e4 	b	4700 <fwp_closure_drop_push>
    6374:	f9400bf3 	ldr	x19, [sp, #16]
    6378:	aa0103e0 	mov	x0, x1
    637c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6380:	17fff925 	b	4814 <fwp_closure_drop.part.0>
    6384:	72003c5f 	tst	w2, #0xffff
    6388:	54fffd00 	b.eq	6328 <fwp_closure_drop+0x78>  // b.none
    638c:	f9400bf3 	ldr	x19, [sp, #16]
    6390:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6394:	d65f03c0 	ret
    6398:	d65f03c0 	ret
    639c:	ca534660 	eor	x0, x19, x19, lsr #17
    63a0:	911740a5 	add	x5, x5, #0x5d0
    63a4:	ca402400 	eor	x0, x0, x0, lsr #9
    63a8:	92401c00 	and	x0, x0, #0xff
    63ac:	910a2402 	add	x2, x0, #0x289
    63b0:	8b000ca0 	add	x0, x5, x0, lsl #3
    63b4:	8b020ca2 	add	x2, x5, x2, lsl #3
    63b8:	f94a2400 	ldr	x0, [x0, #5192]
    63bc:	b50000a0 	cbnz	x0, 63d0 <fwp_closure_drop+0x120>
    63c0:	14000013 	b	640c <fwp_closure_drop+0x15c>
    63c4:	91004002 	add	x2, x0, #0x10
    63c8:	f9400800 	ldr	x0, [x0, #16]
    63cc:	b4000200 	cbz	x0, 640c <fwp_closure_drop+0x15c>
    63d0:	f9400001 	ldr	x1, [x0]
    63d4:	eb13003f 	cmp	x1, x19
    63d8:	54ffff61 	b.ne	63c4 <fwp_closure_drop+0x114>  // b.any
    63dc:	f9400041 	ldr	x1, [x2]
    63e0:	f9400420 	ldr	x0, [x1, #8]
    63e4:	d1000400 	sub	x0, x0, #0x1
    63e8:	f9000420 	str	x0, [x1, #8]
    63ec:	f103f81f 	cmp	x0, #0xfe
    63f0:	54fffac1 	b.ne	6348 <fwp_closure_drop+0x98>  // b.any
    63f4:	39400260 	ldrb	w0, [x19]
    63f8:	7103fc1f 	cmp	w0, #0xff
    63fc:	540000e0 	b.eq	6418 <fwp_closure_drop+0x168>  // b.none
    6400:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6404:	39000260 	strb	w0, [x19]
    6408:	17ffffd0 	b	6348 <fwp_closure_drop+0x98>
    640c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    6410:	9130e000 	add	x0, x0, #0xc38
    6414:	97fff73f 	bl	4110 <fwp_trap>
    6418:	aa1303e0 	mov	x0, x19
    641c:	97fff75d 	bl	4190 <fwp_rc_forget_slot.part.0>
    6420:	17fffff8 	b	6400 <fwp_closure_drop+0x150>

0000000000006424 <fwp_owned_tape_release>:
    6424:	b4000920 	cbz	x0, 6548 <fwp_owned_tape_release+0x124>
    6428:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    642c:	910003fd 	mov	x29, sp
    6430:	a90153f3 	stp	x19, x20, [sp, #16]
    6434:	aa0003f3 	mov	x19, x0
    6438:	f9400000 	ldr	x0, [x0]
    643c:	b4000060 	cbz	x0, 6448 <fwp_owned_tape_release+0x24>
    6440:	f9400661 	ldr	x1, [x19, #8]
    6444:	f9000401 	str	x1, [x0, #8]
    6448:	f9400661 	ldr	x1, [x19, #8]
    644c:	b4000041 	cbz	x1, 6454 <fwp_owned_tape_release+0x30>
    6450:	f9000020 	str	x0, [x1]
    6454:	f9400a60 	ldr	x0, [x19, #16]
    6458:	f9403401 	ldr	x1, [x0, #104]
    645c:	b40005a1 	cbz	x1, 6510 <fwp_owned_tape_release+0xec>
    6460:	a9450a60 	ldp	x0, x2, [x19, #80]
    6464:	eb00005f 	cmp	x2, x0
    6468:	540002cd 	b.le	64c0 <fwp_owned_tape_release+0x9c>
    646c:	d2800014 	mov	x20, #0x0                   	// #0
    6470:	f90013f5 	str	x21, [sp, #32]
    6474:	d2800015 	mov	x21, #0x0                   	// #0
    6478:	f9402260 	ldr	x0, [x19, #64]
    647c:	910006b5 	add	x21, x21, #0x1
    6480:	f8746800 	ldr	x0, [x0, x20]
    6484:	d63f0020 	blr	x1
    6488:	f9402260 	ldr	x0, [x19, #64]
    648c:	f9400a61 	ldr	x1, [x19, #16]
    6490:	8b140000 	add	x0, x0, x20
    6494:	91004294 	add	x20, x20, #0x10
    6498:	f9400400 	ldr	x0, [x0, #8]
    649c:	f9403421 	ldr	x1, [x1, #104]
    64a0:	d63f0020 	blr	x1
    64a4:	a9450261 	ldp	x1, x0, [x19, #80]
    64a8:	cb010000 	sub	x0, x0, x1
    64ac:	eb15001f 	cmp	x0, x21
    64b0:	f9400a60 	ldr	x0, [x19, #16]
    64b4:	f9403401 	ldr	x1, [x0, #104]
    64b8:	54fffe0c 	b.gt	6478 <fwp_owned_tape_release+0x54>
    64bc:	f94013f5 	ldr	x21, [sp, #32]
    64c0:	f9403663 	ldr	x3, [x19, #104]
    64c4:	f9401262 	ldr	x2, [x19, #32]
    64c8:	f100007f 	cmp	x3, #0x0
    64cc:	540001ed 	b.le	6508 <fwp_owned_tape_release+0xe4>
    64d0:	d2800014 	mov	x20, #0x0                   	// #0
    64d4:	d503201f 	nop
    64d8:	f9402660 	ldr	x0, [x19, #72]
    64dc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    64e0:	eb02001f 	cmp	x0, x2
    64e4:	540000c0 	b.eq	64fc <fwp_owned_tape_release+0xd8>  // b.none
    64e8:	d63f0020 	blr	x1
    64ec:	f9400a60 	ldr	x0, [x19, #16]
    64f0:	f9401262 	ldr	x2, [x19, #32]
    64f4:	f9403663 	ldr	x3, [x19, #104]
    64f8:	f9403401 	ldr	x1, [x0, #104]
    64fc:	91000694 	add	x20, x20, #0x1
    6500:	eb14007f 	cmp	x3, x20
    6504:	54fffeac 	b.gt	64d8 <fwp_owned_tape_release+0xb4>
    6508:	aa0203e0 	mov	x0, x2
    650c:	d63f0020 	blr	x1
    6510:	f9401660 	ldr	x0, [x19, #40]
    6514:	97ffff67 	bl	62b0 <fwp_closure_drop>
    6518:	f9401a60 	ldr	x0, [x19, #48]
    651c:	97ffff65 	bl	62b0 <fwp_closure_drop>
    6520:	f9401e60 	ldr	x0, [x19, #56]
    6524:	97ffff63 	bl	62b0 <fwp_closure_drop>
    6528:	f9402260 	ldr	x0, [x19, #64]
    652c:	97fff7b5 	bl	4400 <fwp_mem_free>
    6530:	f9402660 	ldr	x0, [x19, #72]
    6534:	97fff7b3 	bl	4400 <fwp_mem_free>
    6538:	aa1303e0 	mov	x0, x19
    653c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6540:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6544:	17fff7af 	b	4400 <fwp_mem_free>
    6548:	d65f03c0 	ret
    654c:	d503201f 	nop

0000000000006550 <fwp_tape_finish>:
    6550:	d10203ff 	sub	sp, sp, #0x80
    6554:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6558:	f947f421 	ldr	x1, [x1, #4072]
    655c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6560:	910103fd 	add	x29, sp, #0x40
    6564:	a90553f3 	stp	x19, x20, [sp, #80]
    6568:	a9065bf5 	stp	x21, x22, [sp, #96]
    656c:	a90763f7 	stp	x23, x24, [sp, #112]
    6570:	d00000d8 	adrp	x24, 20000 <__data_start>
    6574:	9101c316 	add	x22, x24, #0x70
    6578:	f9400022 	ldr	x2, [x1]
    657c:	f9001fe2 	str	x2, [sp, #56]
    6580:	d2800002 	mov	x2, #0x0                   	// #0
    6584:	910222c0 	add	x0, x22, #0x88
    6588:	97fff3be 	bl	3480 <fwp_tape_buffers_dispose>
    658c:	f90062df 	str	xzr, [x22, #192]
    6590:	f9406ac0 	ldr	x0, [x22, #208]
    6594:	f100001f 	cmp	x0, #0x0
    6598:	5400030d 	b.le	65f8 <fwp_tape_finish+0xa8>
    659c:	910003f7 	mov	x23, sp
    65a0:	d2800015 	mov	x21, #0x0                   	// #0
    65a4:	d2800014 	mov	x20, #0x0                   	// #0
    65a8:	f94002d3 	ldr	x19, [x22]
    65ac:	91000694 	add	x20, x20, #0x1
    65b0:	8b150273 	add	x19, x19, x21
    65b4:	9101a2b5 	add	x21, x21, #0x68
    65b8:	aa1303e0 	mov	x0, x19
    65bc:	97fff275 	bl	2f90 <fwp_tape_unlink_scope>
    65c0:	aa1703e0 	mov	x0, x23
    65c4:	f9401261 	ldr	x1, [x19, #32]
    65c8:	f90003e1 	str	x1, [sp]
    65cc:	f9401a62 	ldr	x2, [x19, #48]
    65d0:	f9000be2 	str	x2, [sp, #16]
    65d4:	f9402261 	ldr	x1, [x19, #64]
    65d8:	f90013e1 	str	x1, [sp, #32]
    65dc:	97fff3a9 	bl	3480 <fwp_tape_buffers_dispose>
    65e0:	f9403260 	ldr	x0, [x19, #96]
    65e4:	97ffff90 	bl	6424 <fwp_owned_tape_release>
    65e8:	f900327f 	str	xzr, [x19, #96]
    65ec:	f9406ac0 	ldr	x0, [x22, #208]
    65f0:	eb14001f 	cmp	x0, x20
    65f4:	54fffdac 	b.gt	65a8 <fwp_tape_finish+0x58>
    65f8:	f9403b00 	ldr	x0, [x24, #112]
    65fc:	9101c313 	add	x19, x24, #0x70
    6600:	97fff0d0 	bl	2940 <free@plt>
    6604:	f9003b1f 	str	xzr, [x24, #112]
    6608:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    660c:	f947f400 	ldr	x0, [x0, #4072]
    6610:	f9006a7f 	str	xzr, [x19, #208]
    6614:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6618:	f9401fe2 	ldr	x2, [sp, #56]
    661c:	f9400001 	ldr	x1, [x0]
    6620:	eb010042 	subs	x2, x2, x1
    6624:	d2800001 	mov	x1, #0x0                   	// #0
    6628:	540000e1 	b.ne	6644 <fwp_tape_finish+0xf4>  // b.any
    662c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6630:	a94553f3 	ldp	x19, x20, [sp, #80]
    6634:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6638:	a94763f7 	ldp	x23, x24, [sp, #112]
    663c:	910203ff 	add	sp, sp, #0x80
    6640:	d65f03c0 	ret
    6644:	97fff08f 	bl	2880 <__stack_chk_fail@plt>
    6648:	d503201f 	nop
    664c:	d503201f 	nop

0000000000006650 <fwp_tape_scope_release>:
    6650:	d10243ff 	sub	sp, sp, #0x90
    6654:	a9047bfd 	stp	x29, x30, [sp, #64]
    6658:	910103fd 	add	x29, sp, #0x40
    665c:	a90553f3 	stp	x19, x20, [sp, #80]
    6660:	aa0003f4 	mov	x20, x0
    6664:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6668:	f947f400 	ldr	x0, [x0, #4072]
    666c:	b9400285 	ldr	w5, [x20]
    6670:	f9400001 	ldr	x1, [x0]
    6674:	f9001fe1 	str	x1, [sp, #56]
    6678:	d2800001 	mov	x1, #0x0                   	// #0
    667c:	37f806c5 	tbnz	w5, #31, 6754 <fwp_tape_scope_release+0x104>
    6680:	a90763f7 	stp	x23, x24, [sp, #112]
    6684:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6688:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    668c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6690:	d00000d3 	adrp	x19, 20000 <__data_start>
    6694:	910003f7 	mov	x23, sp
    6698:	9101c273 	add	x19, x19, #0x70
    669c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    66a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66a4:	52800d16 	mov	w22, #0x68                  	// #104
    66a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    66ac:	f90043f9 	str	x25, [sp, #128]
    66b0:	14000006 	b	66c8 <fwp_tape_scope_release+0x78>
    66b4:	97fff373 	bl	3480 <fwp_tape_buffers_dispose>
    66b8:	aa1903e0 	mov	x0, x25
    66bc:	97ffff5a 	bl	6424 <fwp_owned_tape_release>
    66c0:	b9400285 	ldr	w5, [x20]
    66c4:	37f80425 	tbnz	w5, #31, 6748 <fwp_tape_scope_release+0xf8>
    66c8:	f9400266 	ldr	x6, [x19]
    66cc:	9b367ca5 	smull	x5, w5, w22
    66d0:	8b0500c0 	add	x0, x6, x5
    66d4:	97fff22f 	bl	2f90 <fwp_tape_unlink_scope>
    66d8:	ad410001 	ldp	q1, q0, [x0, #32]
    66dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    66e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    66e4:	f9400c03 	ldr	x3, [x0, #24]
    66e8:	ad0003e1 	stp	q1, q0, [sp]
    66ec:	b86568c1 	ldr	w1, [x6, x5]
    66f0:	a9440804 	ldp	x4, x2, [x0, #64]
    66f4:	b900041f 	str	wzr, [x0, #4]
    66f8:	f9403019 	ldr	x25, [x0, #96]
    66fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6700:	f9000c1f 	str	xzr, [x0, #24]
    6704:	a9020fe4 	stp	x4, x3, [sp, #32]
    6708:	f9001be2 	str	x2, [sp, #48]
    670c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6710:	f900301f 	str	xzr, [x0, #96]
    6714:	6b15003f 	cmp	w1, w21
    6718:	540000e8 	b.hi	6734 <fwp_tape_scope_release+0xe4>  // b.pmore
    671c:	9343fca5 	asr	x5, x5, #3
    6720:	f9407660 	ldr	x0, [x19, #232]
    6724:	9b187ca5 	mul	x5, x5, x24
    6728:	eb0000bf 	cmp	x5, x0
    672c:	5400004a 	b.ge	6734 <fwp_tape_scope_release+0xe4>  // b.tcont
    6730:	f9007665 	str	x5, [x19, #232]
    6734:	aa1703e0 	mov	x0, x23
    6738:	b5fffbf9 	cbnz	x25, 66b4 <fwp_tape_scope_release+0x64>
    673c:	97fff62d 	bl	3ff0 <fwp_tape_buffers_release>
    6740:	b9400285 	ldr	w5, [x20]
    6744:	36fffc25 	tbz	w5, #31, 66c8 <fwp_tape_scope_release+0x78>
    6748:	a9465bf5 	ldp	x21, x22, [sp, #96]
    674c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6750:	f94043f9 	ldr	x25, [sp, #128]
    6754:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6758:	f947f400 	ldr	x0, [x0, #4072]
    675c:	f9401fe2 	ldr	x2, [sp, #56]
    6760:	f9400001 	ldr	x1, [x0]
    6764:	eb010042 	subs	x2, x2, x1
    6768:	d2800001 	mov	x1, #0x0                   	// #0
    676c:	540000a1 	b.ne	6780 <fwp_tape_scope_release+0x130>  // b.any
    6770:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6774:	a94553f3 	ldp	x19, x20, [sp, #80]
    6778:	910243ff 	add	sp, sp, #0x90
    677c:	d65f03c0 	ret
    6780:	a9065bf5 	stp	x21, x22, [sp, #96]
    6784:	a90763f7 	stp	x23, x24, [sp, #112]
    6788:	f90043f9 	str	x25, [sp, #128]
    678c:	97fff03d 	bl	2880 <__stack_chk_fail@plt>

0000000000006790 <fwp_task_dispose>:
    6790:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6794:	910003fd 	mov	x29, sp
    6798:	f9000bf3 	str	x19, [sp, #16]
    679c:	aa0003f3 	mov	x19, x0
    67a0:	39414000 	ldrb	w0, [x0, #80]
    67a4:	36000720 	tbz	w0, #0, 6888 <fwp_task_dispose+0xf8>
    67a8:	f9400a60 	ldr	x0, [x19, #16]
    67ac:	b50006e0 	cbnz	x0, 6888 <fwp_task_dispose+0xf8>
    67b0:	a9478660 	ldp	x0, x1, [x19, #120]
    67b4:	39014e7f 	strb	wzr, [x19, #83]
    67b8:	f9003e7f 	str	xzr, [x19, #120]
    67bc:	f100003f 	cmp	x1, #0x0
    67c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67c4:	54000040 	b.eq	67cc <fwp_task_dispose+0x3c>  // b.none
    67c8:	d63f0020 	blr	x1
    67cc:	f9405660 	ldr	x0, [x19, #168]
    67d0:	97fff70c 	bl	4400 <fwp_mem_free>
    67d4:	f900567f 	str	xzr, [x19, #168]
    67d8:	b9405e60 	ldr	w0, [x19, #92]
    67dc:	7100041f 	cmp	w0, #0x1
    67e0:	54000420 	b.eq	6864 <fwp_task_dispose+0xd4>  // b.none
    67e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    67e8:	91174042 	add	x2, x2, #0x5d0
    67ec:	f949d840 	ldr	x0, [x2, #5040]
    67f0:	f949ec41 	ldr	x1, [x2, #5080]
    67f4:	cb000260 	sub	x0, x19, x0
    67f8:	eb01401f 	cmp	x0, x1, lsl #16
    67fc:	540002e2 	b.cs	6858 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6800:	d350fc01 	lsr	x1, x0, #16
    6804:	f949fc44 	ldr	x4, [x2, #5112]
    6808:	8b010821 	add	x1, x1, x1, lsl #2
    680c:	d37df021 	lsl	x1, x1, #3
    6810:	8b010083 	add	x3, x4, x1
    6814:	f9401062 	ldr	x2, [x3, #32]
    6818:	b4000202 	cbz	x2, 6858 <fwp_task_dispose+0xc8>
    681c:	38616881 	ldrb	w1, [x4, x1]
    6820:	7100083f 	cmp	w1, #0x2
    6824:	54000280 	b.eq	6874 <fwp_task_dispose+0xe4>  // b.none
    6828:	7100043f 	cmp	w1, #0x1
    682c:	54000161 	b.ne	6858 <fwp_task_dispose+0xc8>  // b.any
    6830:	29430464 	ldp	w4, w1, [x3, #24]
    6834:	92403c00 	and	x0, x0, #0xffff
    6838:	9b047c00 	mul	x0, x0, x4
    683c:	d360fc00 	lsr	x0, x0, #32
    6840:	eb01001f 	cmp	x0, x1
    6844:	540000a2 	b.cs	6858 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6848:	8b000042 	add	x2, x2, x0
    684c:	39400040 	ldrb	w0, [x2]
    6850:	7100041f 	cmp	w0, #0x1
    6854:	54000080 	b.eq	6864 <fwp_task_dispose+0xd4>  // b.none
    6858:	f9400bf3 	ldr	x19, [sp, #16]
    685c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6860:	d65f03c0 	ret
    6864:	aa1303e0 	mov	x0, x19
    6868:	f9400bf3 	ldr	x19, [sp, #16]
    686c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6870:	17fff6e4 	b	4400 <fwp_mem_free>
    6874:	72003c1f 	tst	w0, #0xffff
    6878:	54fffea0 	b.eq	684c <fwp_task_dispose+0xbc>  // b.none
    687c:	f9400bf3 	ldr	x19, [sp, #16]
    6880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6884:	d65f03c0 	ret
    6888:	97fff012 	bl	28d0 <abort@plt>
    688c:	d503201f 	nop

0000000000006890 <fwp_free_zombie>:
    6890:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6894:	910003fd 	mov	x29, sp
    6898:	a90153f3 	stp	x19, x20, [sp, #16]
    689c:	d00000d4 	adrp	x20, 20000 <__data_start>
    68a0:	9101c281 	add	x1, x20, #0x70
    68a4:	f9407833 	ldr	x19, [x1, #240]
    68a8:	b4000333 	cbz	x19, 690c <fwp_free_zombie+0x7c>
    68ac:	f9400820 	ldr	x0, [x1, #16]
    68b0:	eb00027f 	cmp	x19, x0
    68b4:	540002c0 	b.eq	690c <fwp_free_zombie+0x7c>  // b.none
    68b8:	b940f822 	ldr	w2, [x1, #248]
    68bc:	f9400a60 	ldr	x0, [x19, #16]
    68c0:	7100fc5f 	cmp	w2, #0x3f
    68c4:	5400078c 	b.gt	69b4 <fwp_free_zombie+0x124>
    68c8:	91040023 	add	x3, x1, #0x100
    68cc:	11000444 	add	w4, w2, #0x1
    68d0:	b900f824 	str	w4, [x1, #248]
    68d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    68dc:	a9530261 	ldp	x1, x0, [x19, #304]
    68e0:	b4000741 	cbz	x1, 69c8 <fwp_free_zombie+0x138>
    68e4:	f9009c20 	str	x0, [x1, #312]
    68e8:	b4000040 	cbz	x0, 68f0 <fwp_free_zombie+0x60>
    68ec:	f9009801 	str	x1, [x0, #304]
    68f0:	9101c294 	add	x20, x20, #0x70
    68f4:	b9405e60 	ldr	w0, [x19, #92]
    68f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    68fc:	f9007a9f 	str	xzr, [x20, #240]
    6900:	34000140 	cbz	w0, 6928 <fwp_free_zombie+0x98>
    6904:	7100041f 	cmp	w0, #0x1
    6908:	54000080 	b.eq	6918 <fwp_free_zombie+0x88>  // b.none
    690c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6910:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6914:	d65f03c0 	ret
    6918:	aa1303e0 	mov	x0, x19
    691c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6920:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6924:	17ffff9b 	b	6790 <fwp_task_dispose>
    6928:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    692c:	91174082 	add	x2, x4, #0x5d0
    6930:	f949d841 	ldr	x1, [x2, #5040]
    6934:	f949ec40 	ldr	x0, [x2, #5080]
    6938:	cb010261 	sub	x1, x19, x1
    693c:	eb00403f 	cmp	x1, x0, lsl #16
    6940:	54fffe62 	b.cs	690c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6944:	d350fc20 	lsr	x0, x1, #16
    6948:	f949fc43 	ldr	x3, [x2, #5112]
    694c:	8b000800 	add	x0, x0, x0, lsl #2
    6950:	d37df000 	lsl	x0, x0, #3
    6954:	8b000062 	add	x2, x3, x0
    6958:	f9401054 	ldr	x20, [x2, #32]
    695c:	b4fffd94 	cbz	x20, 690c <fwp_free_zombie+0x7c>
    6960:	38606860 	ldrb	w0, [x3, x0]
    6964:	7100081f 	cmp	w0, #0x2
    6968:	54000360 	b.eq	69d4 <fwp_free_zombie+0x144>  // b.none
    696c:	7100041f 	cmp	w0, #0x1
    6970:	54fffce1 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    6974:	29430043 	ldp	w3, w0, [x2, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b037c21 	mul	x1, x1, x3
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb00003f 	cmp	x1, x0
    6988:	54fffc22 	b.cs	690c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    698c:	8b010294 	add	x20, x20, x1
    6990:	39400280 	ldrb	w0, [x20]
    6994:	34fffbc0 	cbz	w0, 690c <fwp_free_zombie+0x7c>
    6998:	7100041f 	cmp	w0, #0x1
    699c:	54fffbe0 	b.eq	6918 <fwp_free_zombie+0x88>  // b.none
    69a0:	7103fc1f 	cmp	w0, #0xff
    69a4:	540001e0 	b.eq	69e0 <fwp_free_zombie+0x150>  // b.none
    69a8:	51000400 	sub	w0, w0, #0x1
    69ac:	39000280 	strb	w0, [x20]
    69b0:	17ffffd7 	b	690c <fwp_free_zombie+0x7c>
    69b4:	f9400e61 	ldr	x1, [x19, #24]
    69b8:	97ffeffa 	bl	29a0 <munmap@plt>
    69bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69c0:	a9530261 	ldp	x1, x0, [x19, #304]
    69c4:	b5fff901 	cbnz	x1, 68e4 <fwp_free_zombie+0x54>
    69c8:	9101c282 	add	x2, x20, #0x70
    69cc:	f9018040 	str	x0, [x2, #768]
    69d0:	17ffffc6 	b	68e8 <fwp_free_zombie+0x58>
    69d4:	72003c3f 	tst	w1, #0xffff
    69d8:	54fff9a1 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    69dc:	17ffffed 	b	6990 <fwp_free_zombie+0x100>
    69e0:	ca544680 	eor	x0, x20, x20, lsr #17
    69e4:	91174084 	add	x4, x4, #0x5d0
    69e8:	ca402400 	eor	x0, x0, x0, lsr #9
    69ec:	92401c00 	and	x0, x0, #0xff
    69f0:	910a2402 	add	x2, x0, #0x289
    69f4:	8b000c80 	add	x0, x4, x0, lsl #3
    69f8:	8b020c82 	add	x2, x4, x2, lsl #3
    69fc:	f94a2400 	ldr	x0, [x0, #5192]
    6a00:	b50000a0 	cbnz	x0, 6a14 <fwp_free_zombie+0x184>
    6a04:	14000013 	b	6a50 <fwp_free_zombie+0x1c0>
    6a08:	91004002 	add	x2, x0, #0x10
    6a0c:	f9400800 	ldr	x0, [x0, #16]
    6a10:	b4000200 	cbz	x0, 6a50 <fwp_free_zombie+0x1c0>
    6a14:	f9400001 	ldr	x1, [x0]
    6a18:	eb14003f 	cmp	x1, x20
    6a1c:	54ffff61 	b.ne	6a08 <fwp_free_zombie+0x178>  // b.any
    6a20:	f9400041 	ldr	x1, [x2]
    6a24:	f9400420 	ldr	x0, [x1, #8]
    6a28:	d1000400 	sub	x0, x0, #0x1
    6a2c:	f9000420 	str	x0, [x1, #8]
    6a30:	f103f81f 	cmp	x0, #0xfe
    6a34:	54fff6c1 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    6a38:	39400280 	ldrb	w0, [x20]
    6a3c:	7103fc1f 	cmp	w0, #0xff
    6a40:	540000e0 	b.eq	6a5c <fwp_free_zombie+0x1cc>  // b.none
    6a44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a48:	39000280 	strb	w0, [x20]
    6a4c:	17ffffb0 	b	690c <fwp_free_zombie+0x7c>
    6a50:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    6a54:	9130e000 	add	x0, x0, #0xc38
    6a58:	97fff5ae 	bl	4110 <fwp_trap>
    6a5c:	aa1403e0 	mov	x0, x20
    6a60:	97fff5cc 	bl	4190 <fwp_rc_forget_slot.part.0>
    6a64:	17fffff8 	b	6a44 <fwp_free_zombie+0x1b4>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_block>:
    6a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	a90153f3 	stp	x19, x20, [sp, #16]
    6a7c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6a80:	9101c274 	add	x20, x19, #0x70
    6a84:	f9404282 	ldr	x2, [x20, #128]
    6a88:	b4000642 	cbz	x2, 6b50 <fwp_block+0xe0>
    6a8c:	9101c261 	add	x1, x19, #0x70
    6a90:	f9408040 	ldr	x0, [x2, #256]
    6a94:	f9004020 	str	x0, [x1, #128]
    6a98:	b40006a0 	cbz	x0, 6b6c <fwp_block+0xfc>
    6a9c:	d503201f 	nop
    6aa0:	9101c263 	add	x3, x19, #0x70
    6aa4:	3901505f 	strb	wzr, [x2, #84]
    6aa8:	f9400864 	ldr	x4, [x3, #16]
    6aac:	eb02009f 	cmp	x4, x2
    6ab0:	54000440 	b.eq	6b38 <fwp_block+0xc8>  // b.none
    6ab4:	f9418465 	ldr	x5, [x3, #776]
    6ab8:	f9000862 	str	x2, [x3, #16]
    6abc:	f9400441 	ldr	x1, [x2, #8]
    6ac0:	f9004885 	str	x5, [x4, #144]
    6ac4:	f9418865 	ldr	x5, [x3, #784]
    6ac8:	f9004c85 	str	x5, [x4, #152]
    6acc:	f9418c65 	ldr	x5, [x3, #792]
    6ad0:	f9005085 	str	x5, [x4, #160]
    6ad4:	f9419065 	ldr	x5, [x3, #800]
    6ad8:	f9005485 	str	x5, [x4, #168]
    6adc:	f9419465 	ldr	x5, [x3, #808]
    6ae0:	f9005885 	str	x5, [x4, #176]
    6ae4:	f9419865 	ldr	x5, [x3, #816]
    6ae8:	f9005c85 	str	x5, [x4, #184]
    6aec:	f9419c65 	ldr	x5, [x3, #824]
    6af0:	f9006085 	str	x5, [x4, #192]
    6af4:	f9400480 	ldr	x0, [x4, #8]
    6af8:	f9404844 	ldr	x4, [x2, #144]
    6afc:	f9018464 	str	x4, [x3, #776]
    6b00:	f9404c44 	ldr	x4, [x2, #152]
    6b04:	f9018864 	str	x4, [x3, #784]
    6b08:	f9405044 	ldr	x4, [x2, #160]
    6b0c:	f9018c64 	str	x4, [x3, #792]
    6b10:	f9405444 	ldr	x4, [x2, #168]
    6b14:	f9019064 	str	x4, [x3, #800]
    6b18:	f9405844 	ldr	x4, [x2, #176]
    6b1c:	f9019464 	str	x4, [x3, #808]
    6b20:	a94b8844 	ldp	x4, x2, [x2, #184]
    6b24:	f9019864 	str	x4, [x3, #816]
    6b28:	f9019c62 	str	x2, [x3, #824]
    6b2c:	97ffef6d 	bl	28e0 <swapcontext@plt>
    6b30:	97ffff58 	bl	6890 <fwp_free_zombie>
    6b34:	d503201f 	nop
    6b38:	9101c260 	add	x0, x19, #0x70
    6b3c:	b9434000 	ldr	w0, [x0, #832]
    6b40:	340001a0 	cbz	w0, 6b74 <fwp_block+0x104>
    6b44:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b48:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b4c:	d65f03c0 	ret
    6b50:	97fff7b8 	bl	4a30 <fwp_poll_events>
    6b54:	f9404282 	ldr	x2, [x20, #128]
    6b58:	b4ffffc2 	cbz	x2, 6b50 <fwp_block+0xe0>
    6b5c:	9101c261 	add	x1, x19, #0x70
    6b60:	f9408040 	ldr	x0, [x2, #256]
    6b64:	f9004020 	str	x0, [x1, #128]
    6b68:	b5fff9c0 	cbnz	x0, 6aa0 <fwp_block+0x30>
    6b6c:	f9003c3f 	str	xzr, [x1, #120]
    6b70:	17ffffcc 	b	6aa0 <fwp_block+0x30>
    6b74:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    6b78:	913b4000 	add	x0, x0, #0xed0
    6b7c:	97ffefa5 	bl	2a10 <getenv@plt>
    6b80:	5284e202 	mov	w2, #0x2710                	// #10000
    6b84:	b4000060 	cbz	x0, 6b90 <fwp_block+0x120>
    6b88:	39400001 	ldrb	w1, [x0]
    6b8c:	350000c1 	cbnz	w1, 6ba4 <fwp_block+0x134>
    6b90:	9101c273 	add	x19, x19, #0x70
    6b94:	b9034262 	str	w2, [x19, #832]
    6b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ba0:	d65f03c0 	ret
    6ba4:	52800142 	mov	w2, #0xa                   	// #10
    6ba8:	d2800001 	mov	x1, #0x0                   	// #0
    6bac:	97ffeee9 	bl	2750 <strtoll@plt>
    6bb0:	d1000403 	sub	x3, x0, #0x1
    6bb4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6bb8:	eb02007f 	cmp	x3, x2
    6bbc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6bc0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6bc4:	17fffff3 	b	6b90 <fwp_block+0x120>
    6bc8:	d503201f 	nop
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_drop4>:
    6bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6bd4:	910003fd 	mov	x29, sp
    6bd8:	a90153f3 	stp	x19, x20, [sp, #16]
    6bdc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6be0:	f90013f5 	str	x21, [sp, #32]
    6be4:	91174275 	add	x21, x19, #0x5d0
    6be8:	f949daa1 	ldr	x1, [x21, #5040]
    6bec:	f949eea2 	ldr	x2, [x21, #5080]
    6bf0:	cb010001 	sub	x1, x0, x1
    6bf4:	eb02403f 	cmp	x1, x2, lsl #16
    6bf8:	54000382 	b.cs	6c68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bfc:	d350fc22 	lsr	x2, x1, #16
    6c00:	f949fea3 	ldr	x3, [x21, #5112]
    6c04:	8b020842 	add	x2, x2, x2, lsl #2
    6c08:	d37df042 	lsl	x2, x2, #3
    6c0c:	8b020064 	add	x4, x3, x2
    6c10:	f9401094 	ldr	x20, [x4, #32]
    6c14:	b40002b4 	cbz	x20, 6c68 <fwp_drop4+0x98>
    6c18:	38626862 	ldrb	w2, [x3, x2]
    6c1c:	7100085f 	cmp	w2, #0x2
    6c20:	540007a0 	b.eq	6d14 <fwp_drop4+0x144>  // b.none
    6c24:	7100045f 	cmp	w2, #0x1
    6c28:	54000201 	b.ne	6c68 <fwp_drop4+0x98>  // b.any
    6c2c:	29430885 	ldp	w5, w2, [x4, #24]
    6c30:	92403c21 	and	x1, x1, #0xffff
    6c34:	9b057c21 	mul	x1, x1, x5
    6c38:	d360fc21 	lsr	x1, x1, #32
    6c3c:	eb02003f 	cmp	x1, x2
    6c40:	54000142 	b.cs	6c68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c44:	8b010294 	add	x20, x20, x1
    6c48:	39400281 	ldrb	w1, [x20]
    6c4c:	340000e1 	cbz	w1, 6c68 <fwp_drop4+0x98>
    6c50:	7100043f 	cmp	w1, #0x1
    6c54:	54000120 	b.eq	6c78 <fwp_drop4+0xa8>  // b.none
    6c58:	7103fc3f 	cmp	w1, #0xff
    6c5c:	540007c0 	b.eq	6d54 <fwp_drop4+0x184>  // b.none
    6c60:	51000421 	sub	w1, w1, #0x1
    6c64:	39000281 	strb	w1, [x20]
    6c68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c6c:	f94013f5 	ldr	x21, [sp, #32]
    6c70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c74:	d65f03c0 	ret
    6c78:	f9400001 	ldr	x1, [x0]
    6c7c:	b7f80581 	tbnz	x1, #63, 6d2c <fwp_drop4+0x15c>
    6c80:	91174273 	add	x19, x19, #0x5d0
    6c84:	f949da61 	ldr	x1, [x19, #5040]
    6c88:	f949ee62 	ldr	x2, [x19, #5080]
    6c8c:	cb010001 	sub	x1, x0, x1
    6c90:	eb02403f 	cmp	x1, x2, lsl #16
    6c94:	54fffea2 	b.cs	6c68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c98:	d350fc22 	lsr	x2, x1, #16
    6c9c:	8b020842 	add	x2, x2, x2, lsl #2
    6ca0:	d37df042 	lsl	x2, x2, #3
    6ca4:	8b020065 	add	x5, x3, x2
    6ca8:	f94010a4 	ldr	x4, [x5, #32]
    6cac:	b4fffde4 	cbz	x4, 6c68 <fwp_drop4+0x98>
    6cb0:	38626862 	ldrb	w2, [x3, x2]
    6cb4:	7100085f 	cmp	w2, #0x2
    6cb8:	54000220 	b.eq	6cfc <fwp_drop4+0x12c>  // b.none
    6cbc:	7100045f 	cmp	w2, #0x1
    6cc0:	54fffd41 	b.ne	6c68 <fwp_drop4+0x98>  // b.any
    6cc4:	294308a3 	ldp	w3, w2, [x5, #24]
    6cc8:	92403c21 	and	x1, x1, #0xffff
    6ccc:	9b037c21 	mul	x1, x1, x3
    6cd0:	d360fc21 	lsr	x1, x1, #32
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54fffc82 	b.cs	6c68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6cdc:	8b010084 	add	x4, x4, x1
    6ce0:	39400081 	ldrb	w1, [x4]
    6ce4:	7100043f 	cmp	w1, #0x1
    6ce8:	54fffc01 	b.ne	6c68 <fwp_drop4+0x98>  // b.any
    6cec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cf0:	f94013f5 	ldr	x21, [sp, #32]
    6cf4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6cf8:	17fff5c2 	b	4400 <fwp_mem_free>
    6cfc:	72003c3f 	tst	w1, #0xffff
    6d00:	54ffff00 	b.eq	6ce0 <fwp_drop4+0x110>  // b.none
    6d04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d08:	f94013f5 	ldr	x21, [sp, #32]
    6d0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d10:	d65f03c0 	ret
    6d14:	72003c3f 	tst	w1, #0xffff
    6d18:	54fff980 	b.eq	6c48 <fwp_drop4+0x78>  // b.none
    6d1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d20:	f94013f5 	ldr	x21, [sp, #32]
    6d24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d28:	d65f03c0 	ret
    6d2c:	f9400414 	ldr	x20, [x0, #8]
    6d30:	97fffbcc 	bl	5c60 <fwp_rc_free_arr>
    6d34:	91174260 	add	x0, x19, #0x5d0
    6d38:	f949d801 	ldr	x1, [x0, #5040]
    6d3c:	f949ec00 	ldr	x0, [x0, #5080]
    6d40:	cb010281 	sub	x1, x20, x1
    6d44:	eb00403f 	cmp	x1, x0, lsl #16
    6d48:	54fff902 	b.cs	6c68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d4c:	aa1403e0 	mov	x0, x20
    6d50:	17ffffab 	b	6bfc <fwp_drop4+0x2c>
    6d54:	ca544680 	eor	x0, x20, x20, lsr #17
    6d58:	91174273 	add	x19, x19, #0x5d0
    6d5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d60:	92401c00 	and	x0, x0, #0xff
    6d64:	910a2402 	add	x2, x0, #0x289
    6d68:	8b000e60 	add	x0, x19, x0, lsl #3
    6d6c:	8b020e62 	add	x2, x19, x2, lsl #3
    6d70:	f94a2400 	ldr	x0, [x0, #5192]
    6d74:	b50000a0 	cbnz	x0, 6d88 <fwp_drop4+0x1b8>
    6d78:	14000013 	b	6dc4 <fwp_drop4+0x1f4>
    6d7c:	91004002 	add	x2, x0, #0x10
    6d80:	f9400800 	ldr	x0, [x0, #16]
    6d84:	b4000200 	cbz	x0, 6dc4 <fwp_drop4+0x1f4>
    6d88:	f9400001 	ldr	x1, [x0]
    6d8c:	eb14003f 	cmp	x1, x20
    6d90:	54ffff61 	b.ne	6d7c <fwp_drop4+0x1ac>  // b.any
    6d94:	f9400041 	ldr	x1, [x2]
    6d98:	f9400420 	ldr	x0, [x1, #8]
    6d9c:	d1000400 	sub	x0, x0, #0x1
    6da0:	f9000420 	str	x0, [x1, #8]
    6da4:	f103f81f 	cmp	x0, #0xfe
    6da8:	54fff601 	b.ne	6c68 <fwp_drop4+0x98>  // b.any
    6dac:	39400280 	ldrb	w0, [x20]
    6db0:	7103fc1f 	cmp	w0, #0xff
    6db4:	540000e0 	b.eq	6dd0 <fwp_drop4+0x200>  // b.none
    6db8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6dbc:	39000280 	strb	w0, [x20]
    6dc0:	17ffffaa 	b	6c68 <fwp_drop4+0x98>
    6dc4:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    6dc8:	9130e000 	add	x0, x0, #0xc38
    6dcc:	97fff4d1 	bl	4110 <fwp_trap>
    6dd0:	aa1403e0 	mov	x0, x20
    6dd4:	97fff4ef 	bl	4190 <fwp_rc_forget_slot.part.0>
    6dd8:	17fffff8 	b	6db8 <fwp_drop4+0x1e8>
    6ddc:	d503201f 	nop

0000000000006de0 <fwp_caps161>:
    6de0:	34000041 	cbz	w1, 6de8 <fwp_caps161+0x8>
    6de4:	d65f03c0 	ret
    6de8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6dec:	91174063 	add	x3, x3, #0x5d0
    6df0:	f949d861 	ldr	x1, [x3, #5040]
    6df4:	f949ec62 	ldr	x2, [x3, #5080]
    6df8:	cb010001 	sub	x1, x0, x1
    6dfc:	eb02403f 	cmp	x1, x2, lsl #16
    6e00:	54ffff22 	b.cs	6de4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6e04:	d350fc22 	lsr	x2, x1, #16
    6e08:	f949fc65 	ldr	x5, [x3, #5112]
    6e0c:	8b020842 	add	x2, x2, x2, lsl #2
    6e10:	d37df042 	lsl	x2, x2, #3
    6e14:	8b0200a4 	add	x4, x5, x2
    6e18:	f9401083 	ldr	x3, [x4, #32]
    6e1c:	b4fffe43 	cbz	x3, 6de4 <fwp_caps161+0x4>
    6e20:	386268a2 	ldrb	w2, [x5, x2]
    6e24:	7100085f 	cmp	w2, #0x2
    6e28:	540001c0 	b.eq	6e60 <fwp_caps161+0x80>  // b.none
    6e2c:	7100045f 	cmp	w2, #0x1
    6e30:	54fffda1 	b.ne	6de4 <fwp_caps161+0x4>  // b.any
    6e34:	29430885 	ldp	w5, w2, [x4, #24]
    6e38:	92403c21 	and	x1, x1, #0xffff
    6e3c:	9b057c21 	mul	x1, x1, x5
    6e40:	d360fc21 	lsr	x1, x1, #32
    6e44:	eb02003f 	cmp	x1, x2
    6e48:	54fffce2 	b.cs	6de4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6e4c:	8b010063 	add	x3, x3, x1
    6e50:	39400061 	ldrb	w1, [x3]
    6e54:	7100043f 	cmp	w1, #0x1
    6e58:	54fffc61 	b.ne	6de4 <fwp_caps161+0x4>  // b.any
    6e5c:	17fff569 	b	4400 <fwp_mem_free>
    6e60:	72003c3f 	tst	w1, #0xffff
    6e64:	54ffff60 	b.eq	6e50 <fwp_caps161+0x70>  // b.none
    6e68:	d65f03c0 	ret
    6e6c:	d503201f 	nop

0000000000006e70 <fwp_args23>:
    6e70:	7100003f 	cmp	w1, #0x0
    6e74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6e78:	54000041 	b.ne	6e80 <fwp_args23+0x10>  // b.any
    6e7c:	d65f03c0 	ret
    6e80:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6e84:	91174042 	add	x2, x2, #0x5d0
    6e88:	f9400001 	ldr	x1, [x0]
    6e8c:	f949d843 	ldr	x3, [x2, #5040]
    6e90:	f949ec40 	ldr	x0, [x2, #5080]
    6e94:	cb030021 	sub	x1, x1, x3
    6e98:	eb00403f 	cmp	x1, x0, lsl #16
    6e9c:	54ffff02 	b.cs	6e7c <fwp_args23+0xc>  // b.hs, b.nlast
    6ea0:	d350fc20 	lsr	x0, x1, #16
    6ea4:	f949fc44 	ldr	x4, [x2, #5112]
    6ea8:	8b000800 	add	x0, x0, x0, lsl #2
    6eac:	d37df002 	lsl	x2, x0, #3
    6eb0:	8b020083 	add	x3, x4, x2
    6eb4:	f9401060 	ldr	x0, [x3, #32]
    6eb8:	b4fffe20 	cbz	x0, 6e7c <fwp_args23+0xc>
    6ebc:	38626882 	ldrb	w2, [x4, x2]
    6ec0:	7100085f 	cmp	w2, #0x2
    6ec4:	54000220 	b.eq	6f08 <fwp_args23+0x98>  // b.none
    6ec8:	7100045f 	cmp	w2, #0x1
    6ecc:	54fffd81 	b.ne	6e7c <fwp_args23+0xc>  // b.any
    6ed0:	29430864 	ldp	w4, w2, [x3, #24]
    6ed4:	92403c21 	and	x1, x1, #0xffff
    6ed8:	9b047c21 	mul	x1, x1, x4
    6edc:	d360fc21 	lsr	x1, x1, #32
    6ee0:	eb02003f 	cmp	x1, x2
    6ee4:	54fffcc2 	b.cs	6e7c <fwp_args23+0xc>  // b.hs, b.nlast
    6ee8:	8b010000 	add	x0, x0, x1
    6eec:	39400001 	ldrb	w1, [x0]
    6ef0:	34fffc61 	cbz	w1, 6e7c <fwp_args23+0xc>
    6ef4:	7103f43f 	cmp	w1, #0xfd
    6ef8:	540000e8 	b.hi	6f14 <fwp_args23+0xa4>  // b.pmore
    6efc:	11000421 	add	w1, w1, #0x1
    6f00:	39000001 	strb	w1, [x0]
    6f04:	d65f03c0 	ret
    6f08:	72003c3f 	tst	w1, #0xffff
    6f0c:	54ffff00 	b.eq	6eec <fwp_args23+0x7c>  // b.none
    6f10:	d65f03c0 	ret
    6f14:	17fff5b4 	b	45e4 <fwp_rc_wide_dup>
    6f18:	d503201f 	nop
    6f1c:	d503201f 	nop

0000000000006f20 <fwp_args12>:
    6f20:	7100003f 	cmp	w1, #0x0
    6f24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f28:	54000041 	b.ne	6f30 <fwp_args12+0x10>  // b.any
    6f2c:	d65f03c0 	ret
    6f30:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f34:	91174042 	add	x2, x2, #0x5d0
    6f38:	f9400001 	ldr	x1, [x0]
    6f3c:	f949d843 	ldr	x3, [x2, #5040]
    6f40:	f949ec40 	ldr	x0, [x2, #5080]
    6f44:	cb030021 	sub	x1, x1, x3
    6f48:	eb00403f 	cmp	x1, x0, lsl #16
    6f4c:	54ffff02 	b.cs	6f2c <fwp_args12+0xc>  // b.hs, b.nlast
    6f50:	d350fc20 	lsr	x0, x1, #16
    6f54:	f949fc44 	ldr	x4, [x2, #5112]
    6f58:	8b000800 	add	x0, x0, x0, lsl #2
    6f5c:	d37df002 	lsl	x2, x0, #3
    6f60:	8b020083 	add	x3, x4, x2
    6f64:	f9401060 	ldr	x0, [x3, #32]
    6f68:	b4fffe20 	cbz	x0, 6f2c <fwp_args12+0xc>
    6f6c:	38626882 	ldrb	w2, [x4, x2]
    6f70:	7100085f 	cmp	w2, #0x2
    6f74:	54000220 	b.eq	6fb8 <fwp_args12+0x98>  // b.none
    6f78:	7100045f 	cmp	w2, #0x1
    6f7c:	54fffd81 	b.ne	6f2c <fwp_args12+0xc>  // b.any
    6f80:	29430864 	ldp	w4, w2, [x3, #24]
    6f84:	92403c21 	and	x1, x1, #0xffff
    6f88:	9b047c21 	mul	x1, x1, x4
    6f8c:	d360fc21 	lsr	x1, x1, #32
    6f90:	eb02003f 	cmp	x1, x2
    6f94:	54fffcc2 	b.cs	6f2c <fwp_args12+0xc>  // b.hs, b.nlast
    6f98:	8b010000 	add	x0, x0, x1
    6f9c:	39400001 	ldrb	w1, [x0]
    6fa0:	34fffc61 	cbz	w1, 6f2c <fwp_args12+0xc>
    6fa4:	7103f43f 	cmp	w1, #0xfd
    6fa8:	540000e8 	b.hi	6fc4 <fwp_args12+0xa4>  // b.pmore
    6fac:	11000421 	add	w1, w1, #0x1
    6fb0:	39000001 	strb	w1, [x0]
    6fb4:	d65f03c0 	ret
    6fb8:	72003c3f 	tst	w1, #0xffff
    6fbc:	54ffff00 	b.eq	6f9c <fwp_args12+0x7c>  // b.none
    6fc0:	d65f03c0 	ret
    6fc4:	17fff588 	b	45e4 <fwp_rc_wide_dup>
    6fc8:	d503201f 	nop
    6fcc:	d503201f 	nop

0000000000006fd0 <fwp_caps12>:
    6fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6fd4:	910003fd 	mov	x29, sp
    6fd8:	f9000bf3 	str	x19, [sp, #16]
    6fdc:	aa0003f3 	mov	x19, x0
    6fe0:	b9400400 	ldr	w0, [x0, #4]
    6fe4:	340004a0 	cbz	w0, 7078 <fwp_caps12+0xa8>
    6fe8:	f9400660 	ldr	x0, [x19, #8]
    6fec:	350004e1 	cbnz	w1, 7088 <fwp_caps12+0xb8>
    6ff0:	97fffc4c 	bl	6120 <fwp_drop0>
    6ff4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6ff8:	91174042 	add	x2, x2, #0x5d0
    6ffc:	f949d840 	ldr	x0, [x2, #5040]
    7000:	f949ec41 	ldr	x1, [x2, #5080]
    7004:	cb000260 	sub	x0, x19, x0
    7008:	eb01401f 	cmp	x0, x1, lsl #16
    700c:	54000382 	b.cs	707c <fwp_caps12+0xac>  // b.hs, b.nlast
    7010:	d350fc01 	lsr	x1, x0, #16
    7014:	f949fc44 	ldr	x4, [x2, #5112]
    7018:	8b010821 	add	x1, x1, x1, lsl #2
    701c:	d37df021 	lsl	x1, x1, #3
    7020:	8b010083 	add	x3, x4, x1
    7024:	f9401062 	ldr	x2, [x3, #32]
    7028:	b40002a2 	cbz	x2, 707c <fwp_caps12+0xac>
    702c:	38616881 	ldrb	w1, [x4, x1]
    7030:	7100083f 	cmp	w1, #0x2
    7034:	540006c0 	b.eq	710c <fwp_caps12+0x13c>  // b.none
    7038:	7100043f 	cmp	w1, #0x1
    703c:	54000201 	b.ne	707c <fwp_caps12+0xac>  // b.any
    7040:	29430464 	ldp	w4, w1, [x3, #24]
    7044:	92403c00 	and	x0, x0, #0xffff
    7048:	9b047c00 	mul	x0, x0, x4
    704c:	d360fc00 	lsr	x0, x0, #32
    7050:	eb01001f 	cmp	x0, x1
    7054:	54000142 	b.cs	707c <fwp_caps12+0xac>  // b.hs, b.nlast
    7058:	8b000042 	add	x2, x2, x0
    705c:	39400040 	ldrb	w0, [x2]
    7060:	7100041f 	cmp	w0, #0x1
    7064:	540000c1 	b.ne	707c <fwp_caps12+0xac>  // b.any
    7068:	aa1303e0 	mov	x0, x19
    706c:	f9400bf3 	ldr	x19, [sp, #16]
    7070:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7074:	17fff4e3 	b	4400 <fwp_mem_free>
    7078:	34fffbe1 	cbz	w1, 6ff4 <fwp_caps12+0x24>
    707c:	f9400bf3 	ldr	x19, [sp, #16]
    7080:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7084:	d65f03c0 	ret
    7088:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    708c:	91174042 	add	x2, x2, #0x5d0
    7090:	f949d843 	ldr	x3, [x2, #5040]
    7094:	f949ec41 	ldr	x1, [x2, #5080]
    7098:	cb030000 	sub	x0, x0, x3
    709c:	eb01401f 	cmp	x0, x1, lsl #16
    70a0:	54fffee2 	b.cs	707c <fwp_caps12+0xac>  // b.hs, b.nlast
    70a4:	d350fc01 	lsr	x1, x0, #16
    70a8:	f949fc44 	ldr	x4, [x2, #5112]
    70ac:	8b010821 	add	x1, x1, x1, lsl #2
    70b0:	d37df021 	lsl	x1, x1, #3
    70b4:	8b010083 	add	x3, x4, x1
    70b8:	f9401062 	ldr	x2, [x3, #32]
    70bc:	b4fffe02 	cbz	x2, 707c <fwp_caps12+0xac>
    70c0:	38616881 	ldrb	w1, [x4, x1]
    70c4:	7100083f 	cmp	w1, #0x2
    70c8:	54000280 	b.eq	7118 <fwp_caps12+0x148>  // b.none
    70cc:	7100043f 	cmp	w1, #0x1
    70d0:	54fffd61 	b.ne	707c <fwp_caps12+0xac>  // b.any
    70d4:	92403c01 	and	x1, x0, #0xffff
    70d8:	29430064 	ldp	w4, w0, [x3, #24]
    70dc:	9b047c21 	mul	x1, x1, x4
    70e0:	d360fc21 	lsr	x1, x1, #32
    70e4:	eb00003f 	cmp	x1, x0
    70e8:	54fffca2 	b.cs	707c <fwp_caps12+0xac>  // b.hs, b.nlast
    70ec:	8b010042 	add	x2, x2, x1
    70f0:	39400040 	ldrb	w0, [x2]
    70f4:	34fffc40 	cbz	w0, 707c <fwp_caps12+0xac>
    70f8:	7103f41f 	cmp	w0, #0xfd
    70fc:	54000148 	b.hi	7124 <fwp_caps12+0x154>  // b.pmore
    7100:	11000400 	add	w0, w0, #0x1
    7104:	39000040 	strb	w0, [x2]
    7108:	17ffffdd 	b	707c <fwp_caps12+0xac>
    710c:	72003c1f 	tst	w0, #0xffff
    7110:	54fffb61 	b.ne	707c <fwp_caps12+0xac>  // b.any
    7114:	17ffffd2 	b	705c <fwp_caps12+0x8c>
    7118:	72003c1f 	tst	w0, #0xffff
    711c:	54fffb01 	b.ne	707c <fwp_caps12+0xac>  // b.any
    7120:	17fffff4 	b	70f0 <fwp_caps12+0x120>
    7124:	f9400bf3 	ldr	x19, [sp, #16]
    7128:	aa0203e0 	mov	x0, x2
    712c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7130:	17fff52d 	b	45e4 <fwp_rc_wide_dup>

0000000000007134 <fwp_drop2>:
    7134:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7138:	910003fd 	mov	x29, sp
    713c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7140:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    7144:	911742d5 	add	x21, x22, #0x5d0
    7148:	a90153f3 	stp	x19, x20, [sp, #16]
    714c:	aa0003f3 	mov	x19, x0
    7150:	f949daa1 	ldr	x1, [x21, #5040]
    7154:	f949eea0 	ldr	x0, [x21, #5080]
    7158:	cb010261 	sub	x1, x19, x1
    715c:	eb00403f 	cmp	x1, x0, lsl #16
    7160:	54000382 	b.cs	71d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7164:	d350fc22 	lsr	x2, x1, #16
    7168:	f949fea3 	ldr	x3, [x21, #5112]
    716c:	8b020842 	add	x2, x2, x2, lsl #2
    7170:	d37df042 	lsl	x2, x2, #3
    7174:	8b020060 	add	x0, x3, x2
    7178:	f9401014 	ldr	x20, [x0, #32]
    717c:	b40002b4 	cbz	x20, 71d0 <fwp_drop2+0x9c>
    7180:	38626862 	ldrb	w2, [x3, x2]
    7184:	7100085f 	cmp	w2, #0x2
    7188:	540002c0 	b.eq	71e0 <fwp_drop2+0xac>  // b.none
    718c:	7100045f 	cmp	w2, #0x1
    7190:	54000201 	b.ne	71d0 <fwp_drop2+0x9c>  // b.any
    7194:	29430002 	ldp	w2, w0, [x0, #24]
    7198:	92403c21 	and	x1, x1, #0xffff
    719c:	9b027c21 	mul	x1, x1, x2
    71a0:	d360fc21 	lsr	x1, x1, #32
    71a4:	eb00003f 	cmp	x1, x0
    71a8:	54000142 	b.cs	71d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    71ac:	8b010294 	add	x20, x20, x1
    71b0:	39400280 	ldrb	w0, [x20]
    71b4:	340000e0 	cbz	w0, 71d0 <fwp_drop2+0x9c>
    71b8:	7100041f 	cmp	w0, #0x1
    71bc:	540001e0 	b.eq	71f8 <fwp_drop2+0xc4>  // b.none
    71c0:	7103fc1f 	cmp	w0, #0xff
    71c4:	540007e0 	b.eq	72c0 <fwp_drop2+0x18c>  // b.none
    71c8:	51000400 	sub	w0, w0, #0x1
    71cc:	39000280 	strb	w0, [x20]
    71d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    71d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    71d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    71dc:	d65f03c0 	ret
    71e0:	72003c3f 	tst	w1, #0xffff
    71e4:	54fffe60 	b.eq	71b0 <fwp_drop2+0x7c>  // b.none
    71e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    71ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    71f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    71f4:	d65f03c0 	ret
    71f8:	911742c2 	add	x2, x22, #0x5d0
    71fc:	f9400660 	ldr	x0, [x19, #8]
    7200:	f949d841 	ldr	x1, [x2, #5040]
    7204:	f949ec42 	ldr	x2, [x2, #5080]
    7208:	cb010001 	sub	x1, x0, x1
    720c:	eb02403f 	cmp	x1, x2, lsl #16
    7210:	54000382 	b.cs	7280 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7214:	d350fc22 	lsr	x2, x1, #16
    7218:	8b020842 	add	x2, x2, x2, lsl #2
    721c:	d37df042 	lsl	x2, x2, #3
    7220:	8b020064 	add	x4, x3, x2
    7224:	f9401094 	ldr	x20, [x4, #32]
    7228:	b40002d4 	cbz	x20, 7280 <fwp_drop2+0x14c>
    722c:	38626862 	ldrb	w2, [x3, x2]
    7230:	7100085f 	cmp	w2, #0x2
    7234:	54000400 	b.eq	72b4 <fwp_drop2+0x180>  // b.none
    7238:	7100045f 	cmp	w2, #0x1
    723c:	54000221 	b.ne	7280 <fwp_drop2+0x14c>  // b.any
    7240:	29430883 	ldp	w3, w2, [x4, #24]
    7244:	92403c21 	and	x1, x1, #0xffff
    7248:	9b037c21 	mul	x1, x1, x3
    724c:	d360fc21 	lsr	x1, x1, #32
    7250:	eb02003f 	cmp	x1, x2
    7254:	54000162 	b.cs	7280 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7258:	8b010294 	add	x20, x20, x1
    725c:	39400281 	ldrb	w1, [x20]
    7260:	34000101 	cbz	w1, 7280 <fwp_drop2+0x14c>
    7264:	7100043f 	cmp	w1, #0x1
    7268:	54000220 	b.eq	72ac <fwp_drop2+0x178>  // b.none
    726c:	7103fc3f 	cmp	w1, #0xff
    7270:	54000660 	b.eq	733c <fwp_drop2+0x208>  // b.none
    7274:	51000421 	sub	w1, w1, #0x1
    7278:	39000281 	strb	w1, [x20]
    727c:	d503201f 	nop
    7280:	f9400a74 	ldr	x20, [x19, #16]
    7284:	aa1303e0 	mov	x0, x19
    7288:	97fffa76 	bl	5c60 <fwp_rc_free_arr>
    728c:	911742c0 	add	x0, x22, #0x5d0
    7290:	f949d801 	ldr	x1, [x0, #5040]
    7294:	f949ec00 	ldr	x0, [x0, #5080]
    7298:	cb010281 	sub	x1, x20, x1
    729c:	eb00403f 	cmp	x1, x0, lsl #16
    72a0:	54fff982 	b.cs	71d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    72a4:	aa1403f3 	mov	x19, x20
    72a8:	17ffffaf 	b	7164 <fwp_drop2+0x30>
    72ac:	97fffa6d 	bl	5c60 <fwp_rc_free_arr>
    72b0:	17fffff4 	b	7280 <fwp_drop2+0x14c>
    72b4:	72003c3f 	tst	w1, #0xffff
    72b8:	54fffe41 	b.ne	7280 <fwp_drop2+0x14c>  // b.any
    72bc:	17ffffe8 	b	725c <fwp_drop2+0x128>
    72c0:	ca544681 	eor	x1, x20, x20, lsr #17
    72c4:	911742c0 	add	x0, x22, #0x5d0
    72c8:	ca412421 	eor	x1, x1, x1, lsr #9
    72cc:	92401c21 	and	x1, x1, #0xff
    72d0:	910a2422 	add	x2, x1, #0x289
    72d4:	8b010c01 	add	x1, x0, x1, lsl #3
    72d8:	8b020c02 	add	x2, x0, x2, lsl #3
    72dc:	f94a2420 	ldr	x0, [x1, #5192]
    72e0:	b50000a0 	cbnz	x0, 72f4 <fwp_drop2+0x1c0>
    72e4:	14000013 	b	7330 <fwp_drop2+0x1fc>
    72e8:	91004002 	add	x2, x0, #0x10
    72ec:	f9400800 	ldr	x0, [x0, #16]
    72f0:	b4000200 	cbz	x0, 7330 <fwp_drop2+0x1fc>
    72f4:	f9400001 	ldr	x1, [x0]
    72f8:	eb14003f 	cmp	x1, x20
    72fc:	54ffff61 	b.ne	72e8 <fwp_drop2+0x1b4>  // b.any
    7300:	f9400041 	ldr	x1, [x2]
    7304:	f9400420 	ldr	x0, [x1, #8]
    7308:	d1000400 	sub	x0, x0, #0x1
    730c:	f9000420 	str	x0, [x1, #8]
    7310:	f103f81f 	cmp	x0, #0xfe
    7314:	54fff5e1 	b.ne	71d0 <fwp_drop2+0x9c>  // b.any
    7318:	39400280 	ldrb	w0, [x20]
    731c:	7103fc1f 	cmp	w0, #0xff
    7320:	54000460 	b.eq	73ac <fwp_drop2+0x278>  // b.none
    7324:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7328:	39000280 	strb	w0, [x20]
    732c:	17ffffa9 	b	71d0 <fwp_drop2+0x9c>
    7330:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7334:	9130e000 	add	x0, x0, #0xc38
    7338:	97fff376 	bl	4110 <fwp_trap>
    733c:	ca544680 	eor	x0, x20, x20, lsr #17
    7340:	911742c1 	add	x1, x22, #0x5d0
    7344:	ca402400 	eor	x0, x0, x0, lsr #9
    7348:	92401c00 	and	x0, x0, #0xff
    734c:	910a2402 	add	x2, x0, #0x289
    7350:	8b000c20 	add	x0, x1, x0, lsl #3
    7354:	8b020c22 	add	x2, x1, x2, lsl #3
    7358:	f94a2400 	ldr	x0, [x0, #5192]
    735c:	b50000a0 	cbnz	x0, 7370 <fwp_drop2+0x23c>
    7360:	17fffff4 	b	7330 <fwp_drop2+0x1fc>
    7364:	91004002 	add	x2, x0, #0x10
    7368:	f9400800 	ldr	x0, [x0, #16]
    736c:	b4fffe20 	cbz	x0, 7330 <fwp_drop2+0x1fc>
    7370:	f9400001 	ldr	x1, [x0]
    7374:	eb14003f 	cmp	x1, x20
    7378:	54ffff61 	b.ne	7364 <fwp_drop2+0x230>  // b.any
    737c:	f9400041 	ldr	x1, [x2]
    7380:	f9400420 	ldr	x0, [x1, #8]
    7384:	d1000400 	sub	x0, x0, #0x1
    7388:	f9000420 	str	x0, [x1, #8]
    738c:	f103f81f 	cmp	x0, #0xfe
    7390:	54fff781 	b.ne	7280 <fwp_drop2+0x14c>  // b.any
    7394:	39400280 	ldrb	w0, [x20]
    7398:	7103fc1f 	cmp	w0, #0xff
    739c:	540000e0 	b.eq	73b8 <fwp_drop2+0x284>  // b.none
    73a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    73a4:	39000280 	strb	w0, [x20]
    73a8:	17ffffb6 	b	7280 <fwp_drop2+0x14c>
    73ac:	aa1403e0 	mov	x0, x20
    73b0:	97fff378 	bl	4190 <fwp_rc_forget_slot.part.0>
    73b4:	17ffffdc 	b	7324 <fwp_drop2+0x1f0>
    73b8:	aa1403e0 	mov	x0, x20
    73bc:	97fff375 	bl	4190 <fwp_rc_forget_slot.part.0>
    73c0:	17fffff8 	b	73a0 <fwp_drop2+0x26c>

00000000000073c4 <fwp_arg_drop23>:
    73c4:	7100003f 	cmp	w1, #0x0
    73c8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    73cc:	54000041 	b.ne	73d4 <fwp_arg_drop23+0x10>  // b.any
    73d0:	d65f03c0 	ret
    73d4:	f9400000 	ldr	x0, [x0]
    73d8:	17ffff57 	b	7134 <fwp_drop2>
    73dc:	d503201f 	nop

00000000000073e0 <fwp_caps23>:
    73e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    73e4:	910003fd 	mov	x29, sp
    73e8:	f9000bf3 	str	x19, [sp, #16]
    73ec:	aa0003f3 	mov	x19, x0
    73f0:	b9400400 	ldr	w0, [x0, #4]
    73f4:	340004a0 	cbz	w0, 7488 <fwp_caps23+0xa8>
    73f8:	f9400660 	ldr	x0, [x19, #8]
    73fc:	350004e1 	cbnz	w1, 7498 <fwp_caps23+0xb8>
    7400:	97ffff4d 	bl	7134 <fwp_drop2>
    7404:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7408:	91174042 	add	x2, x2, #0x5d0
    740c:	f949d840 	ldr	x0, [x2, #5040]
    7410:	f949ec41 	ldr	x1, [x2, #5080]
    7414:	cb000260 	sub	x0, x19, x0
    7418:	eb01401f 	cmp	x0, x1, lsl #16
    741c:	54000382 	b.cs	748c <fwp_caps23+0xac>  // b.hs, b.nlast
    7420:	d350fc01 	lsr	x1, x0, #16
    7424:	f949fc44 	ldr	x4, [x2, #5112]
    7428:	8b010821 	add	x1, x1, x1, lsl #2
    742c:	d37df021 	lsl	x1, x1, #3
    7430:	8b010083 	add	x3, x4, x1
    7434:	f9401062 	ldr	x2, [x3, #32]
    7438:	b40002a2 	cbz	x2, 748c <fwp_caps23+0xac>
    743c:	38616881 	ldrb	w1, [x4, x1]
    7440:	7100083f 	cmp	w1, #0x2
    7444:	540006c0 	b.eq	751c <fwp_caps23+0x13c>  // b.none
    7448:	7100043f 	cmp	w1, #0x1
    744c:	54000201 	b.ne	748c <fwp_caps23+0xac>  // b.any
    7450:	29430464 	ldp	w4, w1, [x3, #24]
    7454:	92403c00 	and	x0, x0, #0xffff
    7458:	9b047c00 	mul	x0, x0, x4
    745c:	d360fc00 	lsr	x0, x0, #32
    7460:	eb01001f 	cmp	x0, x1
    7464:	54000142 	b.cs	748c <fwp_caps23+0xac>  // b.hs, b.nlast
    7468:	8b000042 	add	x2, x2, x0
    746c:	39400040 	ldrb	w0, [x2]
    7470:	7100041f 	cmp	w0, #0x1
    7474:	540000c1 	b.ne	748c <fwp_caps23+0xac>  // b.any
    7478:	aa1303e0 	mov	x0, x19
    747c:	f9400bf3 	ldr	x19, [sp, #16]
    7480:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7484:	17fff3df 	b	4400 <fwp_mem_free>
    7488:	34fffbe1 	cbz	w1, 7404 <fwp_caps23+0x24>
    748c:	f9400bf3 	ldr	x19, [sp, #16]
    7490:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7494:	d65f03c0 	ret
    7498:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    749c:	91174042 	add	x2, x2, #0x5d0
    74a0:	f949d843 	ldr	x3, [x2, #5040]
    74a4:	f949ec41 	ldr	x1, [x2, #5080]
    74a8:	cb030000 	sub	x0, x0, x3
    74ac:	eb01401f 	cmp	x0, x1, lsl #16
    74b0:	54fffee2 	b.cs	748c <fwp_caps23+0xac>  // b.hs, b.nlast
    74b4:	d350fc01 	lsr	x1, x0, #16
    74b8:	f949fc44 	ldr	x4, [x2, #5112]
    74bc:	8b010821 	add	x1, x1, x1, lsl #2
    74c0:	d37df021 	lsl	x1, x1, #3
    74c4:	8b010083 	add	x3, x4, x1
    74c8:	f9401062 	ldr	x2, [x3, #32]
    74cc:	b4fffe02 	cbz	x2, 748c <fwp_caps23+0xac>
    74d0:	38616881 	ldrb	w1, [x4, x1]
    74d4:	7100083f 	cmp	w1, #0x2
    74d8:	54000280 	b.eq	7528 <fwp_caps23+0x148>  // b.none
    74dc:	7100043f 	cmp	w1, #0x1
    74e0:	54fffd61 	b.ne	748c <fwp_caps23+0xac>  // b.any
    74e4:	92403c01 	and	x1, x0, #0xffff
    74e8:	29430064 	ldp	w4, w0, [x3, #24]
    74ec:	9b047c21 	mul	x1, x1, x4
    74f0:	d360fc21 	lsr	x1, x1, #32
    74f4:	eb00003f 	cmp	x1, x0
    74f8:	54fffca2 	b.cs	748c <fwp_caps23+0xac>  // b.hs, b.nlast
    74fc:	8b010042 	add	x2, x2, x1
    7500:	39400040 	ldrb	w0, [x2]
    7504:	34fffc40 	cbz	w0, 748c <fwp_caps23+0xac>
    7508:	7103f41f 	cmp	w0, #0xfd
    750c:	54000148 	b.hi	7534 <fwp_caps23+0x154>  // b.pmore
    7510:	11000400 	add	w0, w0, #0x1
    7514:	39000040 	strb	w0, [x2]
    7518:	17ffffdd 	b	748c <fwp_caps23+0xac>
    751c:	72003c1f 	tst	w0, #0xffff
    7520:	54fffb61 	b.ne	748c <fwp_caps23+0xac>  // b.any
    7524:	17ffffd2 	b	746c <fwp_caps23+0x8c>
    7528:	72003c1f 	tst	w0, #0xffff
    752c:	54fffb01 	b.ne	748c <fwp_caps23+0xac>  // b.any
    7530:	17fffff4 	b	7500 <fwp_caps23+0x120>
    7534:	f9400bf3 	ldr	x19, [sp, #16]
    7538:	aa0203e0 	mov	x0, x2
    753c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7540:	17fff429 	b	45e4 <fwp_rc_wide_dup>

0000000000007544 <f23>:
    7544:	d10203ff 	sub	sp, sp, #0x80
    7548:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    754c:	f947f421 	ldr	x1, [x1, #4072]
    7550:	a9027bfd 	stp	x29, x30, [sp, #32]
    7554:	910083fd 	add	x29, sp, #0x20
    7558:	a9045bf5 	stp	x21, x22, [sp, #64]
    755c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    7560:	911742a3 	add	x3, x21, #0x5d0
    7564:	a90353f3 	stp	x19, x20, [sp, #48]
    7568:	aa0003f6 	mov	x22, x0
    756c:	a90563f7 	stp	x23, x24, [sp, #80]
    7570:	a9066bf9 	stp	x25, x26, [sp, #96]
    7574:	f949ec62 	ldr	x2, [x3, #5080]
    7578:	f9400024 	ldr	x4, [x1]
    757c:	f9000fe4 	str	x4, [sp, #24]
    7580:	d2800004 	mov	x4, #0x0                   	// #0
    7584:	f949d861 	ldr	x1, [x3, #5040]
    7588:	d370bc42 	lsl	x2, x2, #16
    758c:	b4001800 	cbz	x0, 788c <f23+0x348>
    7590:	f9400817 	ldr	x23, [x0, #16]
    7594:	cb0102e1 	sub	x1, x23, x1
    7598:	eb02003f 	cmp	x1, x2
    759c:	54000362 	b.cs	7608 <f23+0xc4>  // b.hs, b.nlast
    75a0:	f949fc60 	ldr	x0, [x3, #5112]
    75a4:	d350fc22 	lsr	x2, x1, #16
    75a8:	8b020842 	add	x2, x2, x2, lsl #2
    75ac:	8b020c02 	add	x2, x0, x2, lsl #3
    75b0:	f9401040 	ldr	x0, [x2, #32]
    75b4:	b40002a0 	cbz	x0, 7608 <f23+0xc4>
    75b8:	39400043 	ldrb	w3, [x2]
    75bc:	7100087f 	cmp	w3, #0x2
    75c0:	54001540 	b.eq	7868 <f23+0x324>  // b.none
    75c4:	7100047f 	cmp	w3, #0x1
    75c8:	540001c1 	b.ne	7600 <f23+0xbc>  // b.any
    75cc:	29430843 	ldp	w3, w2, [x2, #24]
    75d0:	92403c21 	and	x1, x1, #0xffff
    75d4:	9b037c21 	mul	x1, x1, x3
    75d8:	d360fc21 	lsr	x1, x1, #32
    75dc:	eb02003f 	cmp	x1, x2
    75e0:	54000102 	b.cs	7600 <f23+0xbc>  // b.hs, b.nlast
    75e4:	8b010000 	add	x0, x0, x1
    75e8:	39400001 	ldrb	w1, [x0]
    75ec:	340000a1 	cbz	w1, 7600 <f23+0xbc>
    75f0:	7103f43f 	cmp	w1, #0xfd
    75f4:	540017e8 	b.hi	78f0 <f23+0x3ac>  // b.pmore
    75f8:	11000421 	add	w1, w1, #0x1
    75fc:	39000001 	strb	w1, [x0]
    7600:	d2800002 	mov	x2, #0x0                   	// #0
    7604:	b40000d6 	cbz	x22, 761c <f23+0xd8>
    7608:	aa1603e1 	mov	x1, x22
    760c:	d2800002 	mov	x2, #0x0                   	// #0
    7610:	f9400821 	ldr	x1, [x1, #16]
    7614:	91000442 	add	x2, x2, #0x1
    7618:	b5ffffc1 	cbnz	x1, 7610 <f23+0xcc>
    761c:	b40013f7 	cbz	x23, 7898 <f23+0x354>
    7620:	aa1703e1 	mov	x1, x23
    7624:	d2800003 	mov	x3, #0x0                   	// #0
    7628:	f9400821 	ldr	x1, [x1, #16]
    762c:	91000463 	add	x3, x3, #0x1
    7630:	b5ffffc1 	cbnz	x1, 7628 <f23+0xe4>
    7634:	eb02007f 	cmp	x3, x2
    7638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    763c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7640:	eb00027f 	cmp	x19, x0
    7644:	540010a8 	b.hi	7858 <f23+0x314>  // b.pmore
    7648:	d37ffa74 	lsl	x20, x19, #1
    764c:	52800041 	mov	w1, #0x2                   	// #2
    7650:	91000680 	add	x0, x20, #0x1
    7654:	d37df000 	lsl	x0, x0, #3
    7658:	97fff626 	bl	4ef0 <fwp_heap_alloc>
    765c:	aa0003f8 	mov	x24, x0
    7660:	911742a1 	add	x1, x21, #0x5d0
    7664:	aa0103e0 	mov	x0, x1
    7668:	f9000314 	str	x20, [x24]
    766c:	f949d821 	ldr	x1, [x1, #5040]
    7670:	f949ec00 	ldr	x0, [x0, #5080]
    7674:	cb010301 	sub	x1, x24, x1
    7678:	eb00403f 	cmp	x1, x0, lsl #16
    767c:	54000342 	b.cs	76e4 <f23+0x1a0>  // b.hs, b.nlast
    7680:	911742a2 	add	x2, x21, #0x5d0
    7684:	d350fc20 	lsr	x0, x1, #16
    7688:	8b000800 	add	x0, x0, x0, lsl #2
    768c:	f949fc43 	ldr	x3, [x2, #5112]
    7690:	d37df002 	lsl	x2, x0, #3
    7694:	8b020060 	add	x0, x3, x2
    7698:	f9401014 	ldr	x20, [x0, #32]
    769c:	b4000254 	cbz	x20, 76e4 <f23+0x1a0>
    76a0:	38626862 	ldrb	w2, [x3, x2]
    76a4:	7100085f 	cmp	w2, #0x2
    76a8:	54000ec0 	b.eq	7880 <f23+0x33c>  // b.none
    76ac:	7100045f 	cmp	w2, #0x1
    76b0:	540001a1 	b.ne	76e4 <f23+0x1a0>  // b.any
    76b4:	29430002 	ldp	w2, w0, [x0, #24]
    76b8:	92403c21 	and	x1, x1, #0xffff
    76bc:	9b027c21 	mul	x1, x1, x2
    76c0:	d360fc21 	lsr	x1, x1, #32
    76c4:	eb00003f 	cmp	x1, x0
    76c8:	540000e2 	b.cs	76e4 <f23+0x1a0>  // b.hs, b.nlast
    76cc:	8b010294 	add	x20, x20, x1
    76d0:	39400280 	ldrb	w0, [x20]
    76d4:	7103fc1f 	cmp	w0, #0xff
    76d8:	54001100 	b.eq	78f8 <f23+0x3b4>  // b.none
    76dc:	52800020 	mov	w0, #0x1                   	// #1
    76e0:	39000280 	strb	w0, [x20]
    76e4:	b4000253 	cbz	x19, 772c <f23+0x1e8>
    76e8:	8b131313 	add	x19, x24, x19, lsl #4
    76ec:	aa1803f4 	mov	x20, x24
    76f0:	aa1603fa 	mov	x26, x22
    76f4:	aa1703f9 	mov	x25, x23
    76f8:	f9400723 	ldr	x3, [x25, #8]
    76fc:	f9400742 	ldr	x2, [x26, #8]
    7700:	f9400861 	ldr	x1, [x3, #16]
    7704:	f9400840 	ldr	x0, [x2, #16]
    7708:	fd400461 	ldr	d1, [x3, #8]
    770c:	fd400440 	ldr	d0, [x2, #8]
    7710:	97fff7a5 	bl	55a4 <w107>
    7714:	f9000680 	str	x0, [x20, #8]
    7718:	f8010e81 	str	x1, [x20, #16]!
    771c:	f9400b39 	ldr	x25, [x25, #16]
    7720:	f9400b5a 	ldr	x26, [x26, #16]
    7724:	eb14027f 	cmp	x19, x20
    7728:	54fffe81 	b.ne	76f8 <f23+0x1b4>  // b.any
    772c:	aa1703e0 	mov	x0, x23
    7730:	97fffe81 	bl	7134 <fwp_drop2>
    7734:	aa1603e0 	mov	x0, x22
    7738:	97fffe7f 	bl	7134 <fwp_drop2>
    773c:	f9400316 	ldr	x22, [x24]
    7740:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7744:	b4000236 	cbz	x22, 7788 <f23+0x244>
    7748:	fd003be8 	str	d8, [sp, #112]
    774c:	2f00e408 	movi	d8, #0x0
    7750:	91002319 	add	x25, x24, #0x8
    7754:	91004317 	add	x23, x24, #0x10
    7758:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    775c:	d2800013 	mov	x19, #0x0                   	// #0
    7760:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7764:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7768:	91000a73 	add	x19, x19, #0x2
    776c:	1e602908 	fadd	d8, d8, d0
    7770:	97fff73c 	bl	5460 <f128.constprop.0>
    7774:	aa0003f4 	mov	x20, x0
    7778:	eb1302df 	cmp	x22, x19
    777c:	54ffff28 	b.hi	7760 <f23+0x21c>  // b.pmore
    7780:	9e660116 	fmov	x22, d8
    7784:	fd403be8 	ldr	d8, [sp, #112]
    7788:	911742b5 	add	x21, x21, #0x5d0
    778c:	aa1803e0 	mov	x0, x24
    7790:	97fffd10 	bl	6bd0 <fwp_drop4>
    7794:	a900d3f6 	stp	x22, x20, [sp, #8]
    7798:	910023e1 	add	x1, sp, #0x8
    779c:	52800000 	mov	w0, #0x0                   	// #0
    77a0:	97fff894 	bl	59f0 <fwp_data.part.0.constprop.0>
    77a4:	f949daa1 	ldr	x1, [x21, #5040]
    77a8:	aa0003f3 	mov	x19, x0
    77ac:	f949eea0 	ldr	x0, [x21, #5080]
    77b0:	cb010261 	sub	x1, x19, x1
    77b4:	eb00403f 	cmp	x1, x0, lsl #16
    77b8:	54000322 	b.cs	781c <f23+0x2d8>  // b.hs, b.nlast
    77bc:	d350fc22 	lsr	x2, x1, #16
    77c0:	f949fea3 	ldr	x3, [x21, #5112]
    77c4:	8b020842 	add	x2, x2, x2, lsl #2
    77c8:	d37df042 	lsl	x2, x2, #3
    77cc:	8b020060 	add	x0, x3, x2
    77d0:	f9401014 	ldr	x20, [x0, #32]
    77d4:	b4000254 	cbz	x20, 781c <f23+0x2d8>
    77d8:	38626862 	ldrb	w2, [x3, x2]
    77dc:	7100085f 	cmp	w2, #0x2
    77e0:	540004a0 	b.eq	7874 <f23+0x330>  // b.none
    77e4:	7100045f 	cmp	w2, #0x1
    77e8:	540001a1 	b.ne	781c <f23+0x2d8>  // b.any
    77ec:	29430002 	ldp	w2, w0, [x0, #24]
    77f0:	92403c21 	and	x1, x1, #0xffff
    77f4:	9b027c21 	mul	x1, x1, x2
    77f8:	d360fc21 	lsr	x1, x1, #32
    77fc:	eb00003f 	cmp	x1, x0
    7800:	540000e2 	b.cs	781c <f23+0x2d8>  // b.hs, b.nlast
    7804:	8b010294 	add	x20, x20, x1
    7808:	39400280 	ldrb	w0, [x20]
    780c:	7103fc1f 	cmp	w0, #0xff
    7810:	540007a0 	b.eq	7904 <f23+0x3c0>  // b.none
    7814:	52800020 	mov	w0, #0x1                   	// #1
    7818:	39000280 	strb	w0, [x20]
    781c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7820:	f947f400 	ldr	x0, [x0, #4072]
    7824:	f9400fe2 	ldr	x2, [sp, #24]
    7828:	f9400001 	ldr	x1, [x0]
    782c:	eb010042 	subs	x2, x2, x1
    7830:	d2800001 	mov	x1, #0x0                   	// #0
    7834:	54000721 	b.ne	7918 <f23+0x3d4>  // b.any
    7838:	a9427bfd 	ldp	x29, x30, [sp, #32]
    783c:	aa1303e0 	mov	x0, x19
    7840:	a94353f3 	ldp	x19, x20, [sp, #48]
    7844:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7848:	a94563f7 	ldp	x23, x24, [sp, #80]
    784c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7850:	910203ff 	add	sp, sp, #0x80
    7854:	d65f03c0 	ret
    7858:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    785c:	913b8000 	add	x0, x0, #0xee0
    7860:	fd003be8 	str	d8, [sp, #112]
    7864:	97fff22b 	bl	4110 <fwp_trap>
    7868:	72003c3f 	tst	w1, #0xffff
    786c:	54ffeca1 	b.ne	7600 <f23+0xbc>  // b.any
    7870:	17ffff5e 	b	75e8 <f23+0xa4>
    7874:	72003c3f 	tst	w1, #0xffff
    7878:	54fffd21 	b.ne	781c <f23+0x2d8>  // b.any
    787c:	17ffffe3 	b	7808 <f23+0x2c4>
    7880:	72003c3f 	tst	w1, #0xffff
    7884:	54fff301 	b.ne	76e4 <f23+0x1a0>  // b.any
    7888:	17ffff92 	b	76d0 <f23+0x18c>
    788c:	cb0103e1 	neg	x1, x1
    7890:	eb02003f 	cmp	x1, x2
    7894:	540001e3 	b.cc	78d0 <f23+0x38c>  // b.lo, b.ul, b.last
    7898:	52800041 	mov	w1, #0x2                   	// #2
    789c:	d2800100 	mov	x0, #0x8                   	// #8
    78a0:	97fff594 	bl	4ef0 <fwp_heap_alloc>
    78a4:	aa0003f8 	mov	x24, x0
    78a8:	911742a0 	add	x0, x21, #0x5d0
    78ac:	f900031f 	str	xzr, [x24]
    78b0:	f949d801 	ldr	x1, [x0, #5040]
    78b4:	f949ec00 	ldr	x0, [x0, #5080]
    78b8:	cb010301 	sub	x1, x24, x1
    78bc:	eb00403f 	cmp	x1, x0, lsl #16
    78c0:	54000282 	b.cs	7910 <f23+0x3cc>  // b.hs, b.nlast
    78c4:	d2800013 	mov	x19, #0x0                   	// #0
    78c8:	d2800017 	mov	x23, #0x0                   	// #0
    78cc:	17ffff6d 	b	7680 <f23+0x13c>
    78d0:	f949fc62 	ldr	x2, [x3, #5112]
    78d4:	d350fc20 	lsr	x0, x1, #16
    78d8:	8b000800 	add	x0, x0, x0, lsl #2
    78dc:	8b000c42 	add	x2, x2, x0, lsl #3
    78e0:	f9401040 	ldr	x0, [x2, #32]
    78e4:	b4fffda0 	cbz	x0, 7898 <f23+0x354>
    78e8:	d2800017 	mov	x23, #0x0                   	// #0
    78ec:	17ffff33 	b	75b8 <f23+0x74>
    78f0:	97fff33d 	bl	45e4 <fwp_rc_wide_dup>
    78f4:	17ffff43 	b	7600 <f23+0xbc>
    78f8:	aa1403e0 	mov	x0, x20
    78fc:	97fff225 	bl	4190 <fwp_rc_forget_slot.part.0>
    7900:	17ffff77 	b	76dc <f23+0x198>
    7904:	aa1403e0 	mov	x0, x20
    7908:	97fff222 	bl	4190 <fwp_rc_forget_slot.part.0>
    790c:	17ffffc2 	b	7814 <f23+0x2d0>
    7910:	d2800017 	mov	x23, #0x0                   	// #0
    7914:	17ffff86 	b	772c <f23+0x1e8>
    7918:	fd003be8 	str	d8, [sp, #112]
    791c:	97ffebd9 	bl	2880 <__stack_chk_fail@plt>

0000000000007920 <fwp_owned_entry23>:
    7920:	f9400000 	ldr	x0, [x0]
    7924:	17ffff08 	b	7544 <f23>
    7928:	d503201f 	nop
    792c:	d503201f 	nop

0000000000007930 <e23>:
    7930:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7934:	910003fd 	mov	x29, sp
    7938:	f9000bf3 	str	x19, [sp, #16]
    793c:	f9400013 	ldr	x19, [x0]
    7940:	aa1303e0 	mov	x0, x19
    7944:	97fff873 	bl	5b10 <fwp_rc_share>
    7948:	aa1303e0 	mov	x0, x19
    794c:	97fffefe 	bl	7544 <f23>
    7950:	aa0003f3 	mov	x19, x0
    7954:	97fff86f 	bl	5b10 <fwp_rc_share>
    7958:	aa1303e0 	mov	x0, x19
    795c:	f9400bf3 	ldr	x19, [sp, #16]
    7960:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7964:	d65f03c0 	ret
    7968:	d503201f 	nop
    796c:	d503201f 	nop

0000000000007970 <f12>:
    7970:	d10483ff 	sub	sp, sp, #0x120
    7974:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7978:	f947f442 	ldr	x2, [x2, #4072]
    797c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7980:	910303fd 	add	x29, sp, #0xc0
    7984:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7988:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    798c:	911742a3 	add	x3, x21, #0x5d0
    7990:	a90d53f3 	stp	x19, x20, [sp, #208]
    7994:	b00000d4 	adrp	x20, 20000 <__data_start>
    7998:	9101c284 	add	x4, x20, #0x70
    799c:	f949d861 	ldr	x1, [x3, #5040]
    79a0:	a90f63f7 	stp	x23, x24, [sp, #240]
    79a4:	b00000d8 	adrp	x24, 20000 <__data_start>
    79a8:	f949ec65 	ldr	x5, [x3, #5080]
    79ac:	a9106bf9 	stp	x25, x26, [sp, #256]
    79b0:	91004318 	add	x24, x24, #0x10
    79b4:	a91173fb 	stp	x27, x28, [sp, #272]
    79b8:	9100e318 	add	x24, x24, #0x38
    79bc:	910103f7 	add	x23, sp, #0x40
    79c0:	f9418886 	ldr	x6, [x4, #784]
    79c4:	f9400047 	ldr	x7, [x2]
    79c8:	f9005fe7 	str	x7, [sp, #184]
    79cc:	d2800007 	mov	x7, #0x0                   	// #0
    79d0:	9100e3f6 	add	x22, sp, #0x38
    79d4:	f0fffff9 	adrp	x25, 6000 <fwp_drop1+0x50>
    79d8:	12800007 	mov	w7, #0xffffffff            	// #-1
    79dc:	91194322 	add	x2, x25, #0x650
    79e0:	cb010301 	sub	x1, x24, x1
    79e4:	b9003be7 	str	w7, [sp, #56]
    79e8:	a9040be6 	stp	x6, x2, [sp, #64]
    79ec:	aa0003f3 	mov	x19, x0
    79f0:	f9002bf6 	str	x22, [sp, #80]
    79f4:	f9018897 	str	x23, [x4, #784]
    79f8:	eb05403f 	cmp	x1, x5, lsl #16
    79fc:	54000342 	b.cs	7a64 <f12+0xf4>  // b.hs, b.nlast
    7a00:	d350fc20 	lsr	x0, x1, #16
    7a04:	f949fc64 	ldr	x4, [x3, #5112]
    7a08:	8b000800 	add	x0, x0, x0, lsl #2
    7a0c:	d37df002 	lsl	x2, x0, #3
    7a10:	8b020083 	add	x3, x4, x2
    7a14:	f9401060 	ldr	x0, [x3, #32]
    7a18:	b4000260 	cbz	x0, 7a64 <f12+0xf4>
    7a1c:	38626882 	ldrb	w2, [x4, x2]
    7a20:	7100085f 	cmp	w2, #0x2
    7a24:	54000b20 	b.eq	7b88 <f12+0x218>  // b.none
    7a28:	7100045f 	cmp	w2, #0x1
    7a2c:	540001c1 	b.ne	7a64 <f12+0xf4>  // b.any
    7a30:	29430864 	ldp	w4, w2, [x3, #24]
    7a34:	92403c21 	and	x1, x1, #0xffff
    7a38:	9b047c21 	mul	x1, x1, x4
    7a3c:	d360fc21 	lsr	x1, x1, #32
    7a40:	eb02003f 	cmp	x1, x2
    7a44:	54000102 	b.cs	7a64 <f12+0xf4>  // b.hs, b.nlast
    7a48:	8b010000 	add	x0, x0, x1
    7a4c:	39400001 	ldrb	w1, [x0]
    7a50:	340000a1 	cbz	w1, 7a64 <f12+0xf4>
    7a54:	7103f43f 	cmp	w1, #0xfd
    7a58:	54002828 	b.hi	7f5c <f12+0x5ec>  // b.pmore
    7a5c:	11000421 	add	w1, w1, #0x1
    7a60:	39000001 	strb	w1, [x0]
    7a64:	aa1803e0 	mov	x0, x24
    7a68:	97fffa12 	bl	62b0 <fwp_closure_drop>
    7a6c:	b40001d3 	cbz	x19, 7aa4 <f12+0x134>
    7a70:	aa1303e0 	mov	x0, x19
    7a74:	d2800018 	mov	x24, #0x0                   	// #0
    7a78:	f9400800 	ldr	x0, [x0, #16]
    7a7c:	91000718 	add	x24, x24, #0x1
    7a80:	b5ffffc0 	cbnz	x0, 7a78 <f12+0x108>
    7a84:	52800000 	mov	w0, #0x0                   	// #0
    7a88:	97ffeeda 	bl	35f0 <descent_phase_step>
    7a8c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7a90:	eb00031f 	cmp	x24, x0
    7a94:	540000e9 	b.ls	7ab0 <f12+0x140>  // b.plast
    7a98:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7a9c:	913bc000 	add	x0, x0, #0xef0
    7aa0:	97fff19c 	bl	4110 <fwp_trap>
    7aa4:	d2800018 	mov	x24, #0x0                   	// #0
    7aa8:	52800000 	mov	w0, #0x0                   	// #0
    7aac:	97ffeed1 	bl	35f0 <descent_phase_step>
    7ab0:	9101c29a 	add	x26, x20, #0x70
    7ab4:	b9434740 	ldr	w0, [x26, #836]
    7ab8:	34001280 	cbz	w0, 7d08 <f12+0x398>
    7abc:	9101c280 	add	x0, x20, #0x70
    7ac0:	f940681b 	ldr	x27, [x0, #208]
    7ac4:	f940741a 	ldr	x26, [x0, #232]
    7ac8:	eb1b035f 	cmp	x26, x27
    7acc:	5400064a 	b.ge	7b94 <f12+0x224>  // b.tcont
    7ad0:	f9403a81 	ldr	x1, [x20, #112]
    7ad4:	8b1a0740 	add	x0, x26, x26, lsl #1
    7ad8:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7adc:	8b000b40 	add	x0, x26, x0, lsl #2
    7ae0:	8b000c20 	add	x0, x1, x0, lsl #3
    7ae4:	d503201f 	nop
    7ae8:	b9400401 	ldr	w1, [x0, #4]
    7aec:	35000081 	cbnz	w1, 7afc <f12+0x18c>
    7af0:	b9400001 	ldr	w1, [x0]
    7af4:	6b02003f 	cmp	w1, w2
    7af8:	540004e9 	b.ls	7b94 <f12+0x224>  // b.plast
    7afc:	9100075a 	add	x26, x26, #0x1
    7b00:	9101a000 	add	x0, x0, #0x68
    7b04:	eb1b035f 	cmp	x26, x27
    7b08:	54ffff01 	b.ne	7ae8 <f12+0x178>  // b.any
    7b0c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7b10:	eb00037f 	cmp	x27, x0
    7b14:	54001dac 	b.gt	7ec8 <f12+0x558>
    7b18:	9101c280 	add	x0, x20, #0x70
    7b1c:	f9403a9c 	ldr	x28, [x20, #112]
    7b20:	f9407000 	ldr	x0, [x0, #224]
    7b24:	eb1b001f 	cmp	x0, x27
    7b28:	54000161 	b.ne	7b54 <f12+0x1e4>  // b.any
    7b2c:	b5001dbb 	cbnz	x27, 7ee0 <f12+0x570>
    7b30:	d2800d01 	mov	x1, #0x68                  	// #104
    7b34:	d280003a 	mov	x26, #0x1                   	// #1
    7b38:	aa1c03e0 	mov	x0, x28
    7b3c:	97ffeb4d 	bl	2870 <realloc@plt>
    7b40:	aa0003fc 	mov	x28, x0
    7b44:	b4004a00 	cbz	x0, 8484 <f12+0xb14>
    7b48:	9101c280 	add	x0, x20, #0x70
    7b4c:	f9003a9c 	str	x28, [x20, #112]
    7b50:	f900701a 	str	x26, [x0, #224]
    7b54:	8b1b0761 	add	x1, x27, x27, lsl #1
    7b58:	9101c280 	add	x0, x20, #0x70
    7b5c:	4f000400 	movi	v0.4s, #0x0
    7b60:	aa1b03fa 	mov	x26, x27
    7b64:	8b010b61 	add	x1, x27, x1, lsl #2
    7b68:	9100077b 	add	x27, x27, #0x1
    7b6c:	f900681b 	str	x27, [x0, #208]
    7b70:	8b010f81 	add	x1, x28, x1, lsl #3
    7b74:	ad000020 	stp	q0, q0, [x1]
    7b78:	ad010020 	stp	q0, q0, [x1, #32]
    7b7c:	ad020020 	stp	q0, q0, [x1, #64]
    7b80:	f900303f 	str	xzr, [x1, #96]
    7b84:	14000007 	b	7ba0 <f12+0x230>
    7b88:	72003c3f 	tst	w1, #0xffff
    7b8c:	54fff6c1 	b.ne	7a64 <f12+0xf4>  // b.any
    7b90:	17ffffaf 	b	7a4c <f12+0xdc>
    7b94:	eb1a037f 	cmp	x27, x26
    7b98:	54fffba0 	b.eq	7b0c <f12+0x19c>  // b.none
    7b9c:	f9403a9c 	ldr	x28, [x20, #112]
    7ba0:	8b1a075b 	add	x27, x26, x26, lsl #1
    7ba4:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7ba8:	91304000 	add	x0, x0, #0xc10
    7bac:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7bb0:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7bb4:	f900337f 	str	xzr, [x27, #96]
    7bb8:	97ffeb96 	bl	2a10 <getenv@plt>
    7bbc:	b4000820 	cbz	x0, 7cc0 <f12+0x350>
    7bc0:	39400001 	ldrb	w1, [x0]
    7bc4:	7100c03f 	cmp	w1, #0x30
    7bc8:	540007c1 	b.ne	7cc0 <f12+0x350>  // b.any
    7bcc:	39400400 	ldrb	w0, [x0, #1]
    7bd0:	35000780 	cbnz	w0, 7cc0 <f12+0x350>
    7bd4:	9101c282 	add	x2, x20, #0x70
    7bd8:	2f000400 	mvni	v0.2s, #0x0
    7bdc:	b9400360 	ldr	w0, [x27]
    7be0:	52800025 	mov	w5, #0x1                   	// #1
    7be4:	91000744 	add	x4, x26, #0x1
    7be8:	a900e378 	stp	x24, x24, [x27, #8]
    7bec:	0b050003 	add	w3, w0, w5
    7bf0:	f9418841 	ldr	x1, [x2, #784]
    7bf4:	29001763 	stp	w3, w5, [x27]
    7bf8:	f9002b7f 	str	xzr, [x27, #80]
    7bfc:	f9007444 	str	x4, [x2, #232]
    7c00:	fd002f60 	str	d0, [x27, #88]
    7c04:	b4001681 	cbz	x1, 7ed4 <f12+0x564>
    7c08:	91194339 	add	x25, x25, #0x650
    7c0c:	14000003 	b	7c18 <f12+0x2a8>
    7c10:	f9400021 	ldr	x1, [x1]
    7c14:	b4001601 	cbz	x1, 7ed4 <f12+0x564>
    7c18:	f9400422 	ldr	x2, [x1, #8]
    7c1c:	eb19005f 	cmp	x2, x25
    7c20:	54ffff81 	b.ne	7c10 <f12+0x2a0>  // b.any
    7c24:	f9400820 	ldr	x0, [x1, #16]
    7c28:	2a1a03e2 	mov	w2, w26
    7c2c:	b9400001 	ldr	w1, [x0]
    7c30:	f9002b60 	str	x0, [x27, #80]
    7c34:	b9005f61 	str	w1, [x27, #92]
    7c38:	37f80081 	tbnz	w1, #31, 7c48 <f12+0x2d8>
    7c3c:	52800d05 	mov	w5, #0x68                  	// #104
    7c40:	9b257021 	smaddl	x1, w1, w5, x28
    7c44:	b900583a 	str	w26, [x1, #88]
    7c48:	b9000002 	str	w2, [x0]
    7c4c:	52800020 	mov	w0, #0x1                   	// #1
    7c50:	b90003e3 	str	w3, [sp]
    7c54:	f90007e4 	str	x4, [sp, #8]
    7c58:	97ffee66 	bl	35f0 <descent_phase_step>
    7c5c:	f94007e4 	ldr	x4, [sp, #8]
    7c60:	aa1303e0 	mov	x0, x19
    7c64:	b94003e3 	ldr	w3, [sp]
    7c68:	d2800002 	mov	x2, #0x0                   	// #0
    7c6c:	b40005d3 	cbz	x19, 7d24 <f12+0x3b4>
    7c70:	f9400800 	ldr	x0, [x0, #16]
    7c74:	91000442 	add	x2, x2, #0x1
    7c78:	b5ffffc0 	cbnz	x0, 7c70 <f12+0x300>
    7c7c:	aa1303e1 	mov	x1, x19
    7c80:	f9400821 	ldr	x1, [x1, #16]
    7c84:	91000400 	add	x0, x0, #0x1
    7c88:	b5ffffc1 	cbnz	x1, 7c80 <f12+0x310>
    7c8c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7c90:	eb01001f 	cmp	x0, x1
    7c94:	54000108 	b.hi	7cb4 <f12+0x344>  // b.pmore
    7c98:	f100005f 	cmp	x2, #0x0
    7c9c:	5400044d 	b.le	7d24 <f12+0x3b4>
    7ca0:	eb00005f 	cmp	x2, x0
    7ca4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7ca8:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7cac:	eb01033f 	cmp	x25, x1
    7cb0:	54001289 	b.ls	7f00 <f12+0x590>  // b.plast
    7cb4:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7cb8:	913b8000 	add	x0, x0, #0xee0
    7cbc:	97fff115 	bl	4110 <fwp_trap>
    7cc0:	9101c280 	add	x0, x20, #0x70
    7cc4:	f9406001 	ldr	x1, [x0, #192]
    7cc8:	b4fff861 	cbz	x1, 7bd4 <f12+0x264>
    7ccc:	3cc88002 	ldur	q2, [x0, #136]
    7cd0:	91022001 	add	x1, x0, #0x88
    7cd4:	3cc98001 	ldur	q1, [x0, #152]
    7cd8:	f900601f 	str	xzr, [x0, #192]
    7cdc:	4f000400 	movi	v0.4s, #0x0
    7ce0:	ad010762 	stp	q2, q1, [x27, #32]
    7ce4:	a94a8002 	ldp	x2, x0, [x0, #168]
    7ce8:	f9000f60 	str	x0, [x27, #24]
    7cec:	f9401820 	ldr	x0, [x1, #48]
    7cf0:	f9002362 	str	x2, [x27, #64]
    7cf4:	f9002760 	str	x0, [x27, #72]
    7cf8:	ad000020 	stp	q0, q0, [x1]
    7cfc:	3d800820 	str	q0, [x1, #32]
    7d00:	f900183f 	str	xzr, [x1, #48]
    7d04:	17ffffb4 	b	7bd4 <f12+0x264>
    7d08:	f0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x50>
    7d0c:	91154000 	add	x0, x0, #0x550
    7d10:	94001740 	bl	da10 <atexit>
    7d14:	35003b80 	cbnz	w0, 8484 <f12+0xb14>
    7d18:	52800020 	mov	w0, #0x1                   	// #1
    7d1c:	b9034740 	str	w0, [x26, #836]
    7d20:	17ffff67 	b	7abc <f12+0x14c>
    7d24:	d3707c60 	ubfiz	x0, x3, #16, #32
    7d28:	52800041 	mov	w1, #0x2                   	// #2
    7d2c:	aa040018 	orr	x24, x0, x4
    7d30:	d2800100 	mov	x0, #0x8                   	// #8
    7d34:	97fff46f 	bl	4ef0 <fwp_heap_alloc>
    7d38:	aa0003fa 	mov	x26, x0
    7d3c:	911742a0 	add	x0, x21, #0x5d0
    7d40:	f900035f 	str	xzr, [x26]
    7d44:	f949d801 	ldr	x1, [x0, #5040]
    7d48:	f949ec00 	ldr	x0, [x0, #5080]
    7d4c:	cb010341 	sub	x1, x26, x1
    7d50:	eb00403f 	cmp	x1, x0, lsl #16
    7d54:	54000f82 	b.cs	7f44 <f12+0x5d4>  // b.hs, b.nlast
    7d58:	d2800019 	mov	x25, #0x0                   	// #0
    7d5c:	911742a2 	add	x2, x21, #0x5d0
    7d60:	d350fc20 	lsr	x0, x1, #16
    7d64:	8b000800 	add	x0, x0, x0, lsl #2
    7d68:	f949fc43 	ldr	x3, [x2, #5112]
    7d6c:	d37df002 	lsl	x2, x0, #3
    7d70:	8b020060 	add	x0, x3, x2
    7d74:	f940101b 	ldr	x27, [x0, #32]
    7d78:	b400025b 	cbz	x27, 7dc0 <f12+0x450>
    7d7c:	38626862 	ldrb	w2, [x3, x2]
    7d80:	7100085f 	cmp	w2, #0x2
    7d84:	54000e60 	b.eq	7f50 <f12+0x5e0>  // b.none
    7d88:	7100045f 	cmp	w2, #0x1
    7d8c:	540001a1 	b.ne	7dc0 <f12+0x450>  // b.any
    7d90:	29430002 	ldp	w2, w0, [x0, #24]
    7d94:	92403c21 	and	x1, x1, #0xffff
    7d98:	9b027c21 	mul	x1, x1, x2
    7d9c:	d360fc21 	lsr	x1, x1, #32
    7da0:	eb00003f 	cmp	x1, x0
    7da4:	540000e2 	b.cs	7dc0 <f12+0x450>  // b.hs, b.nlast
    7da8:	8b01037b 	add	x27, x27, x1
    7dac:	39400360 	ldrb	w0, [x27]
    7db0:	7103fc1f 	cmp	w0, #0xff
    7db4:	540034c0 	b.eq	844c <f12+0xadc>  // b.none
    7db8:	52800020 	mov	w0, #0x1                   	// #1
    7dbc:	39000360 	strb	w0, [x27]
    7dc0:	b4000239 	cbz	x25, 7e04 <f12+0x494>
    7dc4:	d3607f04 	lsl	x4, x24, #32
    7dc8:	aa1303e0 	mov	x0, x19
    7dcc:	f9400665 	ldr	x5, [x19, #8]
    7dd0:	aa0403e3 	mov	x3, x4
    7dd4:	91002342 	add	x2, x26, #0x8
    7dd8:	d2800001 	mov	x1, #0x0                   	// #0
    7ddc:	14000005 	b	7df0 <f12+0x480>
    7de0:	f9400405 	ldr	x5, [x0, #8]
    7de4:	ab010083 	adds	x3, x4, x1
    7de8:	91004042 	add	x2, x2, #0x10
    7dec:	54005c06 	b.vs	896c <f12+0xffc>
    7df0:	a9000c45 	stp	x5, x3, [x2]
    7df4:	91000421 	add	x1, x1, #0x1
    7df8:	f9400800 	ldr	x0, [x0, #16]
    7dfc:	eb19003f 	cmp	x1, x25
    7e00:	54ffff03 	b.cc	7de0 <f12+0x470>  // b.lo, b.ul, b.last
    7e04:	f9400340 	ldr	x0, [x26]
    7e08:	f100041f 	cmp	x0, #0x1
    7e0c:	540009c9 	b.ls	7f44 <f12+0x5d4>  // b.plast
    7e10:	d341fc00 	lsr	x0, x0, #1
    7e14:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7e18:	d100041c 	sub	x28, x0, #0x1
    7e1c:	eb01039f 	cmp	x28, x1
    7e20:	54fff4a8 	b.hi	7cb4 <f12+0x344>  // b.pmore
    7e24:	b400091c 	cbz	x28, 7f44 <f12+0x5d4>
    7e28:	d1002341 	sub	x1, x26, #0x8
    7e2c:	91002359 	add	x25, x26, #0x8
    7e30:	8b00103b 	add	x27, x1, x0, lsl #4
    7e34:	d503201f 	nop
    7e38:	f9400720 	ldr	x0, [x25, #8]
    7e3c:	f9400f21 	ldr	x1, [x25, #24]
    7e40:	fd400320 	ldr	d0, [x25]
    7e44:	fd400b21 	ldr	d1, [x25, #16]
    7e48:	97fff5d7 	bl	55a4 <w107>
    7e4c:	a9000720 	stp	x0, x1, [x25]
    7e50:	91004339 	add	x25, x25, #0x10
    7e54:	eb1b033f 	cmp	x25, x27
    7e58:	54ffff01 	b.ne	7e38 <f12+0x4c8>  // b.any
    7e5c:	aa1a03fb 	mov	x27, x26
    7e60:	d37ffb99 	lsl	x25, x28, #1
    7e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7e68:	d280001c 	mov	x28, #0x0                   	// #0
    7e6c:	f8010779 	str	x25, [x27], #16
    7e70:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    7e74:	aa0303e0 	mov	x0, x3
    7e78:	91000b9c 	add	x28, x28, #0x2
    7e7c:	97fff579 	bl	5460 <f128.constprop.0>
    7e80:	aa0003e3 	mov	x3, x0
    7e84:	eb19039f 	cmp	x28, x25
    7e88:	54ffff43 	b.cc	7e70 <f12+0x500>  // b.lo, b.ul, b.last
    7e8c:	aa1a03e0 	mov	x0, x26
    7e90:	f90003e3 	str	x3, [sp]
    7e94:	97fffb4f 	bl	6bd0 <fwp_drop4>
    7e98:	93407f18 	sxtw	x24, w24
    7e9c:	52800040 	mov	w0, #0x2                   	// #2
    7ea0:	97ffedd4 	bl	35f0 <descent_phase_step>
    7ea4:	aa1803e0 	mov	x0, x24
    7ea8:	97fff29e 	bl	4920 <fwp_tape_of>
    7eac:	f9403019 	ldr	x25, [x0, #96]
    7eb0:	aa0003e5 	mov	x5, x0
    7eb4:	f94003e3 	ldr	x3, [sp]
    7eb8:	b4000579 	cbz	x25, 7f64 <f12+0x5f4>
    7ebc:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7ec0:	91394000 	add	x0, x0, #0xe50
    7ec4:	97fff093 	bl	4110 <fwp_trap>
    7ec8:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7ecc:	913c4000 	add	x0, x0, #0xf10
    7ed0:	97fff090 	bl	4110 <fwp_trap>
    7ed4:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    7ed8:	913d0000 	add	x0, x0, #0xf40
    7edc:	97fff08d 	bl	4110 <fwp_trap>
    7ee0:	d37ffb7a 	lsl	x26, x27, #1
    7ee4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7ee8:	eb00035f 	cmp	x26, x0
    7eec:	9a80d35a 	csel	x26, x26, x0, le
    7ef0:	8b1a0741 	add	x1, x26, x26, lsl #1
    7ef4:	8b010b41 	add	x1, x26, x1, lsl #2
    7ef8:	d37df021 	lsl	x1, x1, #3
    7efc:	17ffff0f 	b	7b38 <f12+0x1c8>
    7f00:	d37ffb3b 	lsl	x27, x25, #1
    7f04:	d3707c63 	ubfiz	x3, x3, #16, #32
    7f08:	91000760 	add	x0, x27, #0x1
    7f0c:	52800041 	mov	w1, #0x2                   	// #2
    7f10:	aa040078 	orr	x24, x3, x4
    7f14:	d37df000 	lsl	x0, x0, #3
    7f18:	97fff3f6 	bl	4ef0 <fwp_heap_alloc>
    7f1c:	aa0003fa 	mov	x26, x0
    7f20:	911742a1 	add	x1, x21, #0x5d0
    7f24:	aa0103e0 	mov	x0, x1
    7f28:	f900035b 	str	x27, [x26]
    7f2c:	f949d821 	ldr	x1, [x1, #5040]
    7f30:	f949ec00 	ldr	x0, [x0, #5080]
    7f34:	cb010341 	sub	x1, x26, x1
    7f38:	eb00403f 	cmp	x1, x0, lsl #16
    7f3c:	54fff103 	b.cc	7d5c <f12+0x3ec>  // b.lo, b.ul, b.last
    7f40:	b5fff439 	cbnz	x25, 7dc4 <f12+0x454>
    7f44:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7f48:	f900035f 	str	xzr, [x26]
    7f4c:	17ffffd0 	b	7e8c <f12+0x51c>
    7f50:	72003c3f 	tst	w1, #0xffff
    7f54:	54fff361 	b.ne	7dc0 <f12+0x450>  // b.any
    7f58:	17ffff95 	b	7dac <f12+0x43c>
    7f5c:	97fff1a2 	bl	45e4 <fwp_rc_wide_dup>
    7f60:	17fffec1 	b	7a64 <f12+0xf4>
    7f64:	f9000be3 	str	x3, [sp, #16]
    7f68:	97ffec0a 	bl	2f90 <fwp_tape_unlink_scope>
    7f6c:	a94288bb 	ldp	x27, x2, [x5, #40]
    7f70:	f90003e2 	str	x2, [sp]
    7f74:	f9401ca2 	ldr	x2, [x5, #56]
    7f78:	b90004bf 	str	wzr, [x5, #4]
    7f7c:	b94000a1 	ldr	w1, [x5]
    7f80:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7f84:	f90007e2 	str	x2, [sp, #8]
    7f88:	a940a4bc 	ldp	x28, x9, [x5, #8]
    7f8c:	6b00003f 	cmp	w1, w0
    7f90:	f9400be3 	ldr	x3, [sp, #16]
    7f94:	a941e8a7 	ldp	x7, x26, [x5, #24]
    7f98:	f94020b9 	ldr	x25, [x5, #64]
    7f9c:	f94024a2 	ldr	x2, [x5, #72]
    7fa0:	54000108 	b.hi	7fc0 <f12+0x650>  // b.pmore
    7fa4:	9101c281 	add	x1, x20, #0x70
    7fa8:	92403f00 	and	x0, x24, #0xffff
    7fac:	d1000400 	sub	x0, x0, #0x1
    7fb0:	f9407428 	ldr	x8, [x1, #232]
    7fb4:	eb08001f 	cmp	x0, x8
    7fb8:	5400004a 	b.ge	7fc0 <f12+0x650>  // b.tcont
    7fbc:	f9007420 	str	x0, [x1, #232]
    7fc0:	4f000400 	movi	v0.4s, #0x0
    7fc4:	9101c281 	add	x1, x20, #0x70
    7fc8:	90ffffe0 	adrp	x0, 3000 <fwp_flush+0x10>
    7fcc:	913fc000 	add	x0, x0, #0xff0
    7fd0:	f9000cbf 	str	xzr, [x5, #24]
    7fd4:	910163e4 	add	x4, sp, #0x58
    7fd8:	f9418828 	ldr	x8, [x1, #784]
    7fdc:	3c8080a0 	stur	q0, [x5, #8]
    7fe0:	9101c3e6 	add	x6, sp, #0x70
    7fe4:	a90583e8 	stp	x8, x0, [sp, #88]
    7fe8:	f94003e0 	ldr	x0, [sp]
    7fec:	ad0100a0 	stp	q0, q0, [x5, #32]
    7ff0:	f90043e0 	str	x0, [sp, #128]
    7ff4:	f94007e0 	ldr	x0, [sp, #8]
    7ff8:	a90113e6 	stp	x6, x4, [sp, #16]
    7ffc:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    8000:	a906ebe6 	stp	x6, x26, [sp, #104]
    8004:	f9003ffb 	str	x27, [sp, #120]
    8008:	f90047e0 	str	x0, [sp, #136]
    800c:	a9091ff9 	stp	x25, x7, [sp, #144]
    8010:	f90053e2 	str	x2, [sp, #160]
    8014:	f9018824 	str	x4, [x1, #784]
    8018:	b7f82163 	tbnz	x3, #63, 8444 <f12+0xad4>
    801c:	eb83831f 	cmp	x24, x3, asr #32
    8020:	54000080 	b.eq	8030 <f12+0x6c0>  // b.none
    8024:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    8028:	91382000 	add	x0, x0, #0xe08
    802c:	97fff039 	bl	4110 <fwp_trap>
    8030:	92407c60 	and	x0, x3, #0xffffffff
    8034:	eb00039f 	cmp	x28, x0
    8038:	9a80c798 	csinc	x24, x28, x0, gt
    803c:	eb23413f 	cmp	x9, w3, uxtw
    8040:	540020cd 	b.le	8458 <f12+0xae8>
    8044:	eb18005f 	cmp	x2, x24
    8048:	540020ea 	b.ge	8464 <f12+0xaf4>  // b.tcont
    804c:	f100005f 	cmp	x2, #0x0
    8050:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    8054:	9a981042 	csel	x2, x2, x24, ne	// ne = any
    8058:	14000004 	b	8068 <f12+0x6f8>
    805c:	eb01005f 	cmp	x2, x1
    8060:	d37ff842 	lsl	x2, x2, #1
    8064:	9a98d042 	csel	x2, x2, x24, le
    8068:	eb18005f 	cmp	x2, x24
    806c:	54ffff8b 	b.lt	805c <f12+0x6ec>  // b.tstop
    8070:	f90017e3 	str	x3, [sp, #40]
    8074:	b40036d9 	cbz	x25, 874c <f12+0xddc>
    8078:	aa1903e0 	mov	x0, x25
    807c:	d37df041 	lsl	x1, x2, #3
    8080:	f90013e2 	str	x2, [sp, #32]
    8084:	97ffe9fb 	bl	2870 <realloc@plt>
    8088:	a9420fe2 	ldp	x2, x3, [sp, #32]
    808c:	aa0003f9 	mov	x25, x0
    8090:	b4001eb9 	cbz	x25, 8464 <f12+0xaf4>
    8094:	f9004bf9 	str	x25, [sp, #144]
    8098:	f90053e2 	str	x2, [sp, #160]
    809c:	b5001c78 	cbnz	x24, 8428 <f12+0xab8>
    80a0:	b7f800c3 	tbnz	x3, #63, 80b8 <f12+0x748>
    80a4:	92407c63 	and	x3, x3, #0xffffffff
    80a8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    80ac:	fc637b20 	ldr	d0, [x25, x3, lsl #3]
    80b0:	1e612800 	fadd	d0, d0, d1
    80b4:	fc237b20 	str	d0, [x25, x3, lsl #3]
    80b8:	9101c281 	add	x1, x20, #0x70
    80bc:	cb1c0303 	sub	x3, x24, x28
    80c0:	52800060 	mov	w0, #0x3                   	// #3
    80c4:	a9428825 	ldp	x5, x2, [x1, #40]
    80c8:	8b1c0042 	add	x2, x2, x28
    80cc:	8b050063 	add	x3, x3, x5
    80d0:	a9028823 	stp	x3, x2, [x1, #40]
    80d4:	97ffed47 	bl	35f0 <descent_phase_step>
    80d8:	d1000700 	sub	x0, x24, #0x1
    80dc:	d1000782 	sub	x2, x28, #0x1
    80e0:	eb00039f 	cmp	x28, x0
    80e4:	540003ec 	b.gt	8160 <f12+0x7f0>
    80e8:	fc607b20 	ldr	d0, [x25, x0, lsl #3]
    80ec:	1e602008 	fcmp	d0, #0.0
    80f0:	54000320 	b.eq	8154 <f12+0x7e4>  // b.none
    80f4:	cb1c0be1 	neg	x1, x28, lsl #2
    80f8:	cb1c03e5 	neg	x5, x28
    80fc:	8b010343 	add	x3, x26, x1
    8100:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    8104:	37f80123 	tbnz	w3, #31, 8128 <f12+0x7b8>
    8108:	f94003e4 	ldr	x4, [sp]
    810c:	93407c63 	sxtw	x3, w3
    8110:	8b050c87 	add	x7, x4, x5, lsl #3
    8114:	fc637b21 	ldr	d1, [x25, x3, lsl #3]
    8118:	fc6078e2 	ldr	d2, [x7, x0, lsl #3]
    811c:	1e620802 	fmul	d2, d0, d2
    8120:	1e622821 	fadd	d1, d1, d2
    8124:	fc237b21 	str	d1, [x25, x3, lsl #3]
    8128:	8b010361 	add	x1, x27, x1
    812c:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    8130:	37f80121 	tbnz	w1, #31, 8154 <f12+0x7e4>
    8134:	f94007e3 	ldr	x3, [sp, #8]
    8138:	93407c21 	sxtw	x1, w1
    813c:	8b050c65 	add	x5, x3, x5, lsl #3
    8140:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    8144:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    8148:	1e620800 	fmul	d0, d0, d2
    814c:	1e602820 	fadd	d0, d1, d0
    8150:	fc217b20 	str	d0, [x25, x1, lsl #3]
    8154:	d1000400 	sub	x0, x0, #0x1
    8158:	eb00005f 	cmp	x2, x0
    815c:	54fffc61 	b.ne	80e8 <f12+0x778>  // b.any
    8160:	52800080 	mov	w0, #0x4                   	// #4
    8164:	97ffed23 	bl	35f0 <descent_phase_step>
    8168:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    816c:	eb00039f 	cmp	x28, x0
    8170:	54001a28 	b.hi	84b4 <f12+0xb44>  // b.pmore
    8174:	91000780 	add	x0, x28, #0x1
    8178:	52800041 	mov	w1, #0x2                   	// #2
    817c:	d37df000 	lsl	x0, x0, #3
    8180:	97fff35c 	bl	4ef0 <fwp_heap_alloc>
    8184:	aa0003f8 	mov	x24, x0
    8188:	f800841c 	str	x28, [x0], #8
    818c:	d2800001 	mov	x1, #0x0                   	// #0
    8190:	b40000dc 	cbz	x28, 81a8 <f12+0x838>
    8194:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    8198:	f8217802 	str	x2, [x0, x1, lsl #3]
    819c:	91000421 	add	x1, x1, #0x1
    81a0:	eb01039f 	cmp	x28, x1
    81a4:	54ffff81 	b.ne	8194 <f12+0x824>  // b.any
    81a8:	528000a0 	mov	w0, #0x5                   	// #5
    81ac:	97ffed11 	bl	35f0 <descent_phase_step>
    81b0:	9101c281 	add	x1, x20, #0x70
    81b4:	f9400fe2 	ldr	x2, [sp, #24]
    81b8:	f9418820 	ldr	x0, [x1, #784]
    81bc:	eb02001f 	cmp	x0, x2
    81c0:	54003d81 	b.ne	8970 <f12+0x1000>  // b.any
    81c4:	f9400be0 	ldr	x0, [sp, #16]
    81c8:	f9402ffa 	ldr	x26, [sp, #88]
    81cc:	f901883a 	str	x26, [x1, #784]
    81d0:	97ffef88 	bl	3ff0 <fwp_tape_buffers_release>
    81d4:	528000c0 	mov	w0, #0x6                   	// #6
    81d8:	97ffed06 	bl	35f0 <descent_phase_step>
    81dc:	911742a2 	add	x2, x21, #0x5d0
    81e0:	f949d841 	ldr	x1, [x2, #5040]
    81e4:	f949ec40 	ldr	x0, [x2, #5080]
    81e8:	cb010301 	sub	x1, x24, x1
    81ec:	eb00403f 	cmp	x1, x0, lsl #16
    81f0:	54000322 	b.cs	8254 <f12+0x8e4>  // b.hs, b.nlast
    81f4:	d350fc20 	lsr	x0, x1, #16
    81f8:	f949fc43 	ldr	x3, [x2, #5112]
    81fc:	8b000800 	add	x0, x0, x0, lsl #2
    8200:	d37df002 	lsl	x2, x0, #3
    8204:	8b020060 	add	x0, x3, x2
    8208:	f9401019 	ldr	x25, [x0, #32]
    820c:	b4000259 	cbz	x25, 8254 <f12+0x8e4>
    8210:	38626862 	ldrb	w2, [x3, x2]
    8214:	7100085f 	cmp	w2, #0x2
    8218:	54002ae0 	b.eq	8774 <f12+0xe04>  // b.none
    821c:	7100045f 	cmp	w2, #0x1
    8220:	540001a1 	b.ne	8254 <f12+0x8e4>  // b.any
    8224:	29430002 	ldp	w2, w0, [x0, #24]
    8228:	92403c21 	and	x1, x1, #0xffff
    822c:	9b027c21 	mul	x1, x1, x2
    8230:	d360fc21 	lsr	x1, x1, #32
    8234:	eb00003f 	cmp	x1, x0
    8238:	540000e2 	b.cs	8254 <f12+0x8e4>  // b.hs, b.nlast
    823c:	8b010339 	add	x25, x25, x1
    8240:	39400320 	ldrb	w0, [x25]
    8244:	7103fc1f 	cmp	w0, #0xff
    8248:	54002b40 	b.eq	87b0 <f12+0xe40>  // b.none
    824c:	52800020 	mov	w0, #0x1                   	// #1
    8250:	39000320 	strb	w0, [x25]
    8254:	eb17035f 	cmp	x26, x23
    8258:	540038c1 	b.ne	8970 <f12+0x1000>  // b.any
    825c:	f94023e1 	ldr	x1, [sp, #64]
    8260:	9101c294 	add	x20, x20, #0x70
    8264:	aa1603e0 	mov	x0, x22
    8268:	f9018a81 	str	x1, [x20, #784]
    826c:	97fff8f9 	bl	6650 <fwp_tape_scope_release>
    8270:	f9400300 	ldr	x0, [x24]
    8274:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8278:	b7f812c0 	tbnz	x0, #63, 84d0 <f12+0xb60>
    827c:	911742a2 	add	x2, x21, #0x5d0
    8280:	f949d840 	ldr	x0, [x2, #5040]
    8284:	f949ec41 	ldr	x1, [x2, #5080]
    8288:	cb000300 	sub	x0, x24, x0
    828c:	eb01401f 	cmp	x0, x1, lsl #16
    8290:	54001202 	b.cs	84d0 <f12+0xb60>  // b.hs, b.nlast
    8294:	d350fc01 	lsr	x1, x0, #16
    8298:	f949fc44 	ldr	x4, [x2, #5112]
    829c:	8b010821 	add	x1, x1, x1, lsl #2
    82a0:	d37df021 	lsl	x1, x1, #3
    82a4:	8b010083 	add	x3, x4, x1
    82a8:	f9401062 	ldr	x2, [x3, #32]
    82ac:	b4001122 	cbz	x2, 84d0 <f12+0xb60>
    82b0:	38616881 	ldrb	w1, [x4, x1]
    82b4:	7100083f 	cmp	w1, #0x2
    82b8:	54001080 	b.eq	84c8 <f12+0xb58>  // b.none
    82bc:	7100043f 	cmp	w1, #0x1
    82c0:	54001081 	b.ne	84d0 <f12+0xb60>  // b.any
    82c4:	29430464 	ldp	w4, w1, [x3, #24]
    82c8:	92403c00 	and	x0, x0, #0xffff
    82cc:	9b047c00 	mul	x0, x0, x4
    82d0:	d360fc00 	lsr	x0, x0, #32
    82d4:	eb01001f 	cmp	x0, x1
    82d8:	54000fc2 	b.cs	84d0 <f12+0xb60>  // b.hs, b.nlast
    82dc:	8b000042 	add	x2, x2, x0
    82e0:	39400040 	ldrb	w0, [x2]
    82e4:	7100041f 	cmp	w0, #0x1
    82e8:	54000f41 	b.ne	84d0 <f12+0xb60>  // b.any
    82ec:	aa1803f6 	mov	x22, x24
    82f0:	d2800000 	mov	x0, #0x0                   	// #0
    82f4:	910022c2 	add	x2, x22, #0x8
    82f8:	d2800001 	mov	x1, #0x0                   	// #0
    82fc:	b40001f7 	cbz	x23, 8338 <f12+0x9c8>
    8300:	d0000023 	adrp	x3, e000 <_IO_stdin_used+0x5c0>
    8304:	91002304 	add	x4, x24, #0x8
    8308:	fd441861 	ldr	d1, [x3, #2096]
    830c:	f9400305 	ldr	x5, [x24]
    8310:	aa0403e3 	mov	x3, x4
    8314:	b7f80d65 	tbnz	x5, #63, 84c0 <f12+0xb50>
    8318:	f94002c5 	ldr	x5, [x22]
    831c:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    8320:	b7f82245 	tbnz	x5, #63, 8768 <f12+0xdf8>
    8324:	1e600820 	fmul	d0, d1, d0
    8328:	91000421 	add	x1, x1, #0x1
    832c:	fc008440 	str	d0, [x2], #8
    8330:	eb0102ff 	cmp	x23, x1
    8334:	54fffec1 	b.ne	830c <f12+0x99c>  // b.any
    8338:	97fffa26 	bl	6bd0 <fwp_drop4>
    833c:	b4002313 	cbz	x19, 879c <f12+0xe2c>
    8340:	aa1303e0 	mov	x0, x19
    8344:	d2800014 	mov	x20, #0x0                   	// #0
    8348:	f9400800 	ldr	x0, [x0, #16]
    834c:	91000694 	add	x20, x20, #0x1
    8350:	b5ffffc0 	cbnz	x0, 8348 <f12+0x9d8>
    8354:	f94002c0 	ldr	x0, [x22]
    8358:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    835c:	b7f81120 	tbnz	x0, #63, 8580 <f12+0xc10>
    8360:	911742a1 	add	x1, x21, #0x5d0
    8364:	f949d820 	ldr	x0, [x1, #5040]
    8368:	f949ec22 	ldr	x2, [x1, #5080]
    836c:	cb0002c0 	sub	x0, x22, x0
    8370:	eb02401f 	cmp	x0, x2, lsl #16
    8374:	54001042 	b.cs	857c <f12+0xc0c>  // b.hs, b.nlast
    8378:	d350fc02 	lsr	x2, x0, #16
    837c:	d2800503 	mov	x3, #0x28                  	// #40
    8380:	f949fc24 	ldr	x4, [x1, #5112]
    8384:	9b037c42 	mul	x2, x2, x3
    8388:	8b020083 	add	x3, x4, x2
    838c:	f9401061 	ldr	x1, [x3, #32]
    8390:	b4000f61 	cbz	x1, 857c <f12+0xc0c>
    8394:	38626882 	ldrb	w2, [x4, x2]
    8398:	7100085f 	cmp	w2, #0x2
    839c:	54000ec0 	b.eq	8574 <f12+0xc04>  // b.none
    83a0:	7100045f 	cmp	w2, #0x1
    83a4:	54000ec1 	b.ne	857c <f12+0xc0c>  // b.any
    83a8:	29430864 	ldp	w4, w2, [x3, #24]
    83ac:	92403c00 	and	x0, x0, #0xffff
    83b0:	9b047c00 	mul	x0, x0, x4
    83b4:	d360fc00 	lsr	x0, x0, #32
    83b8:	eb02001f 	cmp	x0, x2
    83bc:	54000e02 	b.cs	857c <f12+0xc0c>  // b.hs, b.nlast
    83c0:	8b000021 	add	x1, x1, x0
    83c4:	3940003c 	ldrb	w28, [x1]
    83c8:	7100079f 	cmp	w28, #0x1
    83cc:	54000d81 	b.ne	857c <f12+0xc0c>  // b.any
    83d0:	910022d9 	add	x25, x22, #0x8
    83d4:	eb14031f 	cmp	x24, x20
    83d8:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    83dc:	b4001ff8 	cbz	x24, 87d8 <f12+0xe68>
    83e0:	d37df304 	lsl	x4, x24, #3
    83e4:	aa1303e1 	mov	x1, x19
    83e8:	910022c3 	add	x3, x22, #0x8
    83ec:	d2800000 	mov	x0, #0x0                   	// #0
    83f0:	14000009 	b	8414 <f12+0xaa4>
    83f4:	fc606841 	ldr	d1, [x2, x0]
    83f8:	fd400420 	ldr	d0, [x1, #8]
    83fc:	1e613800 	fsub	d0, d0, d1
    8400:	fc206b20 	str	d0, [x25, x0]
    8404:	91002000 	add	x0, x0, #0x8
    8408:	f9400821 	ldr	x1, [x1, #16]
    840c:	eb04001f 	cmp	x0, x4
    8410:	54000e40 	b.eq	85d8 <f12+0xc68>  // b.none
    8414:	f94002c5 	ldr	x5, [x22]
    8418:	aa0303e2 	mov	x2, x3
    841c:	b6fffec5 	tbz	x5, #63, 83f4 <f12+0xa84>
    8420:	f9400ac2 	ldr	x2, [x22, #16]
    8424:	17fffff4 	b	83f4 <f12+0xa84>
    8428:	d37df302 	lsl	x2, x24, #3
    842c:	aa1903e0 	mov	x0, x25
    8430:	52800001 	mov	w1, #0x0                   	// #0
    8434:	f90013e3 	str	x3, [sp, #32]
    8438:	97ffe906 	bl	2850 <memset@plt>
    843c:	f94013e3 	ldr	x3, [sp, #32]
    8440:	17ffff18 	b	80a0 <f12+0x730>
    8444:	aa1c03f8 	mov	x24, x28
    8448:	17fffeff 	b	8044 <f12+0x6d4>
    844c:	aa1b03e0 	mov	x0, x27
    8450:	97ffef50 	bl	4190 <fwp_rc_forget_slot.part.0>
    8454:	17fffe59 	b	7db8 <f12+0x448>
    8458:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    845c:	913a0000 	add	x0, x0, #0xe80
    8460:	97ffef2c 	bl	4110 <fwp_trap>
    8464:	f100031f 	cmp	x24, #0x0
    8468:	fa401b20 	ccmp	x25, #0x0, #0x0, ne	// ne = any
    846c:	54ffe181 	b.ne	809c <f12+0x72c>  // b.any
    8470:	f9400be0 	ldr	x0, [sp, #16]
    8474:	9101c294 	add	x20, x20, #0x70
    8478:	f9402fe1 	ldr	x1, [sp, #88]
    847c:	f9018a81 	str	x1, [x20, #784]
    8480:	97ffeedc 	bl	3ff0 <fwp_tape_buffers_release>
    8484:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8488:	f947e863 	ldr	x3, [x3, #4048]
    848c:	d2800262 	mov	x2, #0x13                  	// #19
    8490:	d2800021 	mov	x1, #0x1                   	// #1
    8494:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    8498:	91292000 	add	x0, x0, #0xa48
    849c:	f9400063 	ldr	x3, [x3]
    84a0:	97ffe938 	bl	2980 <fwrite@plt>
    84a4:	d2800000 	mov	x0, #0x0                   	// #0
    84a8:	97ffe942 	bl	29b0 <fflush@plt>
    84ac:	52800cc0 	mov	w0, #0x66                  	// #102
    84b0:	97ffe950 	bl	29f0 <_Exit@plt>
    84b4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    84b8:	913dc000 	add	x0, x0, #0xf70
    84bc:	97ffef15 	bl	4110 <fwp_trap>
    84c0:	f9400b03 	ldr	x3, [x24, #16]
    84c4:	17ffff95 	b	8318 <f12+0x9a8>
    84c8:	72003c1f 	tst	w0, #0xffff
    84cc:	54fff0a0 	b.eq	82e0 <f12+0x970>  // b.none
    84d0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    84d4:	eb0002ff 	cmp	x23, x0
    84d8:	54fffee8 	b.hi	84b4 <f12+0xb44>  // b.pmore
    84dc:	910006e0 	add	x0, x23, #0x1
    84e0:	52800021 	mov	w1, #0x1                   	// #1
    84e4:	d37df000 	lsl	x0, x0, #3
    84e8:	97fff282 	bl	4ef0 <fwp_heap_alloc>
    84ec:	911742a2 	add	x2, x21, #0x5d0
    84f0:	f9000017 	str	x23, [x0]
    84f4:	aa0003f6 	mov	x22, x0
    84f8:	f949d841 	ldr	x1, [x2, #5040]
    84fc:	f949ec40 	ldr	x0, [x2, #5080]
    8500:	cb0102c1 	sub	x1, x22, x1
    8504:	eb00403f 	cmp	x1, x0, lsl #16
    8508:	54000322 	b.cs	856c <f12+0xbfc>  // b.hs, b.nlast
    850c:	d350fc20 	lsr	x0, x1, #16
    8510:	d2800504 	mov	x4, #0x28                  	// #40
    8514:	f949fc43 	ldr	x3, [x2, #5112]
    8518:	9b047c00 	mul	x0, x0, x4
    851c:	8b000062 	add	x2, x3, x0
    8520:	f9401054 	ldr	x20, [x2, #32]
    8524:	b4000254 	cbz	x20, 856c <f12+0xbfc>
    8528:	38606860 	ldrb	w0, [x3, x0]
    852c:	7100081f 	cmp	w0, #0x2
    8530:	540012e0 	b.eq	878c <f12+0xe1c>  // b.none
    8534:	7100041f 	cmp	w0, #0x1
    8538:	540001a1 	b.ne	856c <f12+0xbfc>  // b.any
    853c:	29430043 	ldp	w3, w0, [x2, #24]
    8540:	92403c21 	and	x1, x1, #0xffff
    8544:	9b037c21 	mul	x1, x1, x3
    8548:	d360fc21 	lsr	x1, x1, #32
    854c:	eb00003f 	cmp	x1, x0
    8550:	540000e2 	b.cs	856c <f12+0xbfc>  // b.hs, b.nlast
    8554:	8b010294 	add	x20, x20, x1
    8558:	39400280 	ldrb	w0, [x20]
    855c:	7103fc1f 	cmp	w0, #0xff
    8560:	54001100 	b.eq	8780 <f12+0xe10>  // b.none
    8564:	52800020 	mov	w0, #0x1                   	// #1
    8568:	39000280 	strb	w0, [x20]
    856c:	aa1803e0 	mov	x0, x24
    8570:	17ffff61 	b	82f4 <f12+0x984>
    8574:	72003c1f 	tst	w0, #0xffff
    8578:	54fff260 	b.eq	83c4 <f12+0xa54>  // b.none
    857c:	b4001253 	cbz	x19, 87c4 <f12+0xe54>
    8580:	aa1303f7 	mov	x23, x19
    8584:	d2800014 	mov	x20, #0x0                   	// #0
    8588:	f9400af7 	ldr	x23, [x23, #16]
    858c:	aa1403e0 	mov	x0, x20
    8590:	91000694 	add	x20, x20, #0x1
    8594:	b5ffffb7 	cbnz	x23, 8588 <f12+0xc18>
    8598:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    859c:	eb01029f 	cmp	x20, x1
    85a0:	54ffb8a8 	b.hi	7cb4 <f12+0x344>  // b.pmore
    85a4:	91000800 	add	x0, x0, #0x2
    85a8:	52800041 	mov	w1, #0x2                   	// #2
    85ac:	d37df000 	lsl	x0, x0, #3
    85b0:	97fff250 	bl	4ef0 <fwp_heap_alloc>
    85b4:	aa1303e1 	mov	x1, x19
    85b8:	aa0003f9 	mov	x25, x0
    85bc:	f9400420 	ldr	x0, [x1, #8]
    85c0:	f8377b20 	str	x0, [x25, x23, lsl #3]
    85c4:	910006f7 	add	x23, x23, #0x1
    85c8:	f9400821 	ldr	x1, [x1, #16]
    85cc:	b5ffff81 	cbnz	x1, 85bc <f12+0xc4c>
    85d0:	5280001c 	mov	w28, #0x0                   	// #0
    85d4:	17ffff80 	b	83d4 <f12+0xa64>
    85d8:	b4001c73 	cbz	x19, 8964 <f12+0xff4>
    85dc:	911742a0 	add	x0, x21, #0x5d0
    85e0:	aa1303e2 	mov	x2, x19
    85e4:	d280001b 	mov	x27, #0x0                   	// #0
    85e8:	f949ec04 	ldr	x4, [x0, #5080]
    85ec:	f949d807 	ldr	x7, [x0, #5040]
    85f0:	f949fc06 	ldr	x6, [x0, #5112]
    85f4:	d370bc84 	lsl	x4, x4, #16
    85f8:	14000006 	b	8610 <f12+0xca0>
    85fc:	f9400842 	ldr	x2, [x2, #16]
    8600:	9100077b 	add	x27, x27, #0x1
    8604:	f100005f 	cmp	x2, #0x0
    8608:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    860c:	54000322 	b.cs	8670 <f12+0xd00>  // b.hs, b.nlast
    8610:	cb070040 	sub	x0, x2, x7
    8614:	eb04001f 	cmp	x0, x4
    8618:	540002c2 	b.cs	8670 <f12+0xd00>  // b.hs, b.nlast
    861c:	d350fc01 	lsr	x1, x0, #16
    8620:	8b010821 	add	x1, x1, x1, lsl #2
    8624:	d37df021 	lsl	x1, x1, #3
    8628:	8b0100c5 	add	x5, x6, x1
    862c:	f94010a3 	ldr	x3, [x5, #32]
    8630:	b4000203 	cbz	x3, 8670 <f12+0xd00>
    8634:	386168c1 	ldrb	w1, [x6, x1]
    8638:	7100083f 	cmp	w1, #0x2
    863c:	54000820 	b.eq	8740 <f12+0xdd0>  // b.none
    8640:	7100043f 	cmp	w1, #0x1
    8644:	54000161 	b.ne	8670 <f12+0xd00>  // b.any
    8648:	294304a8 	ldp	w8, w1, [x5, #24]
    864c:	92403c00 	and	x0, x0, #0xffff
    8650:	9b087c00 	mul	x0, x0, x8
    8654:	d360fc00 	lsr	x0, x0, #32
    8658:	eb01001f 	cmp	x0, x1
    865c:	540000a2 	b.cs	8670 <f12+0xd00>  // b.hs, b.nlast
    8660:	8b000063 	add	x3, x3, x0
    8664:	39400060 	ldrb	w0, [x3]
    8668:	7100041f 	cmp	w0, #0x1
    866c:	54fffc80 	b.eq	85fc <f12+0xc8c>  // b.none
    8670:	d280001a 	mov	x26, #0x0                   	// #0
    8674:	eb18037f 	cmp	x27, x24
    8678:	540015c2 	b.cs	8930 <f12+0xfc0>  // b.hs, b.nlast
    867c:	d1002320 	sub	x0, x25, #0x8
    8680:	aa1803f4 	mov	x20, x24
    8684:	911742b7 	add	x23, x21, #0x5d0
    8688:	d280001a 	mov	x26, #0x0                   	// #0
    868c:	f90007e0 	str	x0, [sp, #8]
    8690:	9102a3e0 	add	x0, sp, #0xa8
    8694:	f90003e0 	str	x0, [sp]
    8698:	14000012 	b	86e0 <f12+0xd70>
    869c:	7100045f 	cmp	w2, #0x1
    86a0:	540001a1 	b.ne	86d4 <f12+0xd64>  // b.any
    86a4:	294308a6 	ldp	w6, w2, [x5, #24]
    86a8:	92403c21 	and	x1, x1, #0xffff
    86ac:	9b067c21 	mul	x1, x1, x6
    86b0:	d360fc21 	lsr	x1, x1, #32
    86b4:	eb02003f 	cmp	x1, x2
    86b8:	540000e2 	b.cs	86d4 <f12+0xd64>  // b.hs, b.nlast
    86bc:	8b010000 	add	x0, x0, x1
    86c0:	39400001 	ldrb	w1, [x0]
    86c4:	7103fc3f 	cmp	w1, #0xff
    86c8:	54000900 	b.eq	87e8 <f12+0xe78>  // b.none
    86cc:	52800021 	mov	w1, #0x1                   	// #1
    86d0:	39000001 	strb	w1, [x0]
    86d4:	d1000694 	sub	x20, x20, #0x1
    86d8:	eb14037f 	cmp	x27, x20
    86dc:	540008e2 	b.cs	87f8 <f12+0xe88>  // b.hs, b.nlast
    86e0:	a94003e1 	ldp	x1, x0, [sp]
    86e4:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    86e8:	52800020 	mov	w0, #0x1                   	// #1
    86ec:	a90aebe2 	stp	x2, x26, [sp, #168]
    86f0:	97fff4c0 	bl	59f0 <fwp_data.part.0.constprop.0>
    86f4:	aa0003fa 	mov	x26, x0
    86f8:	f949dae1 	ldr	x1, [x23, #5040]
    86fc:	f949eee0 	ldr	x0, [x23, #5080]
    8700:	cb010341 	sub	x1, x26, x1
    8704:	eb00403f 	cmp	x1, x0, lsl #16
    8708:	54fffe62 	b.cs	86d4 <f12+0xd64>  // b.hs, b.nlast
    870c:	d350fc20 	lsr	x0, x1, #16
    8710:	f949fee6 	ldr	x6, [x23, #5112]
    8714:	8b000800 	add	x0, x0, x0, lsl #2
    8718:	d37df002 	lsl	x2, x0, #3
    871c:	8b0200c5 	add	x5, x6, x2
    8720:	f94010a0 	ldr	x0, [x5, #32]
    8724:	b4fffd80 	cbz	x0, 86d4 <f12+0xd64>
    8728:	386268c2 	ldrb	w2, [x6, x2]
    872c:	7100085f 	cmp	w2, #0x2
    8730:	54fffb61 	b.ne	869c <f12+0xd2c>  // b.any
    8734:	72003c3f 	tst	w1, #0xffff
    8738:	54fffce1 	b.ne	86d4 <f12+0xd64>  // b.any
    873c:	17ffffe1 	b	86c0 <f12+0xd50>
    8740:	72003c1f 	tst	w0, #0xffff
    8744:	54fff961 	b.ne	8670 <f12+0xd00>  // b.any
    8748:	17ffffc7 	b	8664 <f12+0xcf4>
    874c:	aa0203e0 	mov	x0, x2
    8750:	d2800101 	mov	x1, #0x8                   	// #8
    8754:	f90013e2 	str	x2, [sp, #32]
    8758:	97ffe842 	bl	2860 <calloc@plt>
    875c:	a9420fe2 	ldp	x2, x3, [sp, #32]
    8760:	aa0003f9 	mov	x25, x0
    8764:	17fffe4b 	b	8090 <f12+0x720>
    8768:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    876c:	913e0000 	add	x0, x0, #0xf80
    8770:	97ffee68 	bl	4110 <fwp_trap>
    8774:	72003c3f 	tst	w1, #0xffff
    8778:	54ffd6e1 	b.ne	8254 <f12+0x8e4>  // b.any
    877c:	17fffeb1 	b	8240 <f12+0x8d0>
    8780:	aa1403e0 	mov	x0, x20
    8784:	97ffee83 	bl	4190 <fwp_rc_forget_slot.part.0>
    8788:	17ffff77 	b	8564 <f12+0xbf4>
    878c:	72003c3f 	tst	w1, #0xffff
    8790:	54ffee40 	b.eq	8558 <f12+0xbe8>  // b.none
    8794:	aa1803e0 	mov	x0, x24
    8798:	17fffed7 	b	82f4 <f12+0x984>
    879c:	f94002d8 	ldr	x24, [x22]
    87a0:	b7f80138 	tbnz	x24, #63, 87c4 <f12+0xe54>
    87a4:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    87a8:	d2800014 	mov	x20, #0x0                   	// #0
    87ac:	17fffeed 	b	8360 <f12+0x9f0>
    87b0:	aa1903e0 	mov	x0, x25
    87b4:	97ffee77 	bl	4190 <fwp_rc_forget_slot.part.0>
    87b8:	9101c280 	add	x0, x20, #0x70
    87bc:	f941881a 	ldr	x26, [x0, #784]
    87c0:	17fffea3 	b	824c <f12+0x8dc>
    87c4:	52800041 	mov	w1, #0x2                   	// #2
    87c8:	d2800100 	mov	x0, #0x8                   	// #8
    87cc:	97fff1c9 	bl	4ef0 <fwp_heap_alloc>
    87d0:	aa0003f9 	mov	x25, x0
    87d4:	5280001c 	mov	w28, #0x0                   	// #0
    87d8:	d280001a 	mov	x26, #0x0                   	// #0
    87dc:	7100039f 	cmp	w28, #0x0
    87e0:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    87e4:	14000036 	b	88bc <f12+0xf4c>
    87e8:	f9000be0 	str	x0, [sp, #16]
    87ec:	97ffee69 	bl	4190 <fwp_rc_forget_slot.part.0>
    87f0:	f9400be0 	ldr	x0, [sp, #16]
    87f4:	17ffffb6 	b	86cc <f12+0xd5c>
    87f8:	d1000701 	sub	x1, x24, #0x1
    87fc:	cb180360 	sub	x0, x27, x24
    8800:	eb01037f 	cmp	x27, x1
    8804:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8808:	8b010000 	add	x0, x0, x1
    880c:	b500093b 	cbnz	x27, 8930 <f12+0xfc0>
    8810:	7100039f 	cmp	w28, #0x0
    8814:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8818:	b4000520 	cbz	x0, 88bc <f12+0xf4c>
    881c:	d1000414 	sub	x20, x0, #0x1
    8820:	911742b5 	add	x21, x21, #0x5d0
    8824:	52800038 	mov	w24, #0x1                   	// #1
    8828:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    882c:	52800020 	mov	w0, #0x1                   	// #1
    8830:	f94003e1 	ldr	x1, [sp]
    8834:	a90aebe2 	stp	x2, x26, [sp, #168]
    8838:	97fff46e 	bl	59f0 <fwp_data.part.0.constprop.0>
    883c:	aa0003fa 	mov	x26, x0
    8840:	f949daa1 	ldr	x1, [x21, #5040]
    8844:	f949eea0 	ldr	x0, [x21, #5080]
    8848:	cb010341 	sub	x1, x26, x1
    884c:	eb00403f 	cmp	x1, x0, lsl #16
    8850:	54000302 	b.cs	88b0 <f12+0xf40>  // b.hs, b.nlast
    8854:	d350fc20 	lsr	x0, x1, #16
    8858:	f949fea3 	ldr	x3, [x21, #5112]
    885c:	8b000800 	add	x0, x0, x0, lsl #2
    8860:	d37df002 	lsl	x2, x0, #3
    8864:	8b020060 	add	x0, x3, x2
    8868:	f940101b 	ldr	x27, [x0, #32]
    886c:	b400023b 	cbz	x27, 88b0 <f12+0xf40>
    8870:	38626862 	ldrb	w2, [x3, x2]
    8874:	7100085f 	cmp	w2, #0x2
    8878:	540004e0 	b.eq	8914 <f12+0xfa4>  // b.none
    887c:	7100045f 	cmp	w2, #0x1
    8880:	54000181 	b.ne	88b0 <f12+0xf40>  // b.any
    8884:	29430002 	ldp	w2, w0, [x0, #24]
    8888:	92403c21 	and	x1, x1, #0xffff
    888c:	9b027c21 	mul	x1, x1, x2
    8890:	d360fc21 	lsr	x1, x1, #32
    8894:	eb00003f 	cmp	x1, x0
    8898:	540000c2 	b.cs	88b0 <f12+0xf40>  // b.hs, b.nlast
    889c:	8b01037b 	add	x27, x27, x1
    88a0:	39400360 	ldrb	w0, [x27]
    88a4:	7103fc1f 	cmp	w0, #0xff
    88a8:	540003c0 	b.eq	8920 <f12+0xfb0>  // b.none
    88ac:	39000378 	strb	w24, [x27]
    88b0:	d1000694 	sub	x20, x20, #0x1
    88b4:	b100069f 	cmn	x20, #0x1
    88b8:	54fffb81 	b.ne	8828 <f12+0xeb8>  // b.any
    88bc:	aa1903e0 	mov	x0, x25
    88c0:	97ffeed0 	bl	4400 <fwp_mem_free>
    88c4:	aa1603e0 	mov	x0, x22
    88c8:	97fff8c2 	bl	6bd0 <fwp_drop4>
    88cc:	aa1303e0 	mov	x0, x19
    88d0:	97fff614 	bl	6120 <fwp_drop0>
    88d4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    88d8:	f947f400 	ldr	x0, [x0, #4072]
    88dc:	f9405fe2 	ldr	x2, [sp, #184]
    88e0:	f9400001 	ldr	x1, [x0]
    88e4:	eb010042 	subs	x2, x2, x1
    88e8:	d2800001 	mov	x1, #0x0                   	// #0
    88ec:	54000201 	b.ne	892c <f12+0xfbc>  // b.any
    88f0:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    88f4:	aa1a03e0 	mov	x0, x26
    88f8:	a94d53f3 	ldp	x19, x20, [sp, #208]
    88fc:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8900:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8904:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8908:	a95173fb 	ldp	x27, x28, [sp, #272]
    890c:	910483ff 	add	sp, sp, #0x120
    8910:	d65f03c0 	ret
    8914:	72003c3f 	tst	w1, #0xffff
    8918:	54fffcc1 	b.ne	88b0 <f12+0xf40>  // b.any
    891c:	17ffffe1 	b	88a0 <f12+0xf30>
    8920:	aa1b03e0 	mov	x0, x27
    8924:	97ffee1b 	bl	4190 <fwp_rc_forget_slot.part.0>
    8928:	17ffffe1 	b	88ac <f12+0xf3c>
    892c:	97ffe7d5 	bl	2880 <__stack_chk_fail@plt>
    8930:	aa1303e0 	mov	x0, x19
    8934:	d2800001 	mov	x1, #0x0                   	// #0
    8938:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    893c:	91000421 	add	x1, x1, #0x1
    8940:	f9000402 	str	x2, [x0, #8]
    8944:	aa0003e2 	mov	x2, x0
    8948:	f9400800 	ldr	x0, [x0, #16]
    894c:	eb01037f 	cmp	x27, x1
    8950:	54ffff48 	b.hi	8938 <f12+0xfc8>  // b.pmore
    8954:	f900085a 	str	x26, [x2, #16]
    8958:	aa1303fa 	mov	x26, x19
    895c:	aa0003f3 	mov	x19, x0
    8960:	17ffff9f 	b	87dc <f12+0xe6c>
    8964:	d280001b 	mov	x27, #0x0                   	// #0
    8968:	17ffff45 	b	867c <f12+0xd0c>
    896c:	97ffe845 	bl	2a80 <fwp_trap_overflow.constprop.0>
    8970:	97ffe7d8 	bl	28d0 <abort@plt>

0000000000008974 <fwp_owned_entry12>:
    8974:	f9400000 	ldr	x0, [x0]
    8978:	17fffbfe 	b	7970 <f12>
    897c:	d503201f 	nop

0000000000008980 <e12>:
    8980:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8984:	910003fd 	mov	x29, sp
    8988:	f9000bf3 	str	x19, [sp, #16]
    898c:	f9400013 	ldr	x19, [x0]
    8990:	aa1303e0 	mov	x0, x19
    8994:	97fff45f 	bl	5b10 <fwp_rc_share>
    8998:	aa1303e0 	mov	x0, x19
    899c:	97fffbf5 	bl	7970 <f12>
    89a0:	aa0003f3 	mov	x19, x0
    89a4:	97fff45b 	bl	5b10 <fwp_rc_share>
    89a8:	aa1303e0 	mov	x0, x19
    89ac:	f9400bf3 	ldr	x19, [sp, #16]
    89b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    89b4:	d65f03c0 	ret
    89b8:	d503201f 	nop
    89bc:	d503201f 	nop

00000000000089c0 <fwp_write>:
    89c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    89c4:	910003fd 	mov	x29, sp
    89c8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    89cc:	f947f484 	ldr	x4, [x4, #4072]
    89d0:	a90153f3 	stp	x19, x20, [sp, #16]
    89d4:	d10943ff 	sub	sp, sp, #0x250
    89d8:	b9400045 	ldr	w5, [x2]
    89dc:	aa0003f4 	mov	x20, x0
    89e0:	f9400080 	ldr	x0, [x4]
    89e4:	f90127e0 	str	x0, [sp, #584]
    89e8:	d2800000 	mov	x0, #0x0                   	// #0
    89ec:	710064bf 	cmp	w5, #0x19
    89f0:	54000408 	b.hi	8a70 <fwp_write+0xb0>  // b.pmore
    89f4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    89f8:	aa0103f3 	mov	x19, x1
    89fc:	911e4000 	add	x0, x0, #0x790
    8a00:	f9013bf5 	str	x21, [sp, #624]
    8a04:	f9013ff6 	str	x22, [sp, #632]
    8a08:	f90153fb 	str	x27, [sp, #672]
    8a0c:	f90157fc 	str	x28, [sp, #680]
    8a10:	aa0203fc 	mov	x28, x2
    8a14:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8a18:	10000061 	adr	x1, 8a24 <fwp_write+0x64>
    8a1c:	8b20a820 	add	x0, x1, w0, sxth #2
    8a20:	d61f0000 	br	x0
    8a24:	910123e0 	add	x0, sp, #0x48
    8a28:	aa1303e5 	mov	x5, x19
    8a2c:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x220>
    8a30:	aa0003f3 	mov	x19, x0
    8a34:	913f8084 	add	x4, x4, #0xfe0
    8a38:	d2804003 	mov	x3, #0x200                 	// #512
    8a3c:	aa0303e1 	mov	x1, x3
    8a40:	52800042 	mov	w2, #0x2                   	// #2
    8a44:	97ffe76b 	bl	27f0 <__snprintf_chk@plt>
    8a48:	aa1303e0 	mov	x0, x19
    8a4c:	97ffe731 	bl	2710 <strlen@plt>
    8a50:	aa1303e1 	mov	x1, x19
    8a54:	aa0003e2 	mov	x2, x0
    8a58:	aa1403e0 	mov	x0, x20
    8a5c:	97ffeacd 	bl	3590 <buf_put>
    8a60:	f9413bf5 	ldr	x21, [sp, #624]
    8a64:	f9413ff6 	ldr	x22, [sp, #632]
    8a68:	f94153fb 	ldr	x27, [sp, #672]
    8a6c:	f94157fc 	ldr	x28, [sp, #680]
    8a70:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a74:	f947f400 	ldr	x0, [x0, #4072]
    8a78:	f94127e2 	ldr	x2, [sp, #584]
    8a7c:	f9400001 	ldr	x1, [x0]
    8a80:	eb010042 	subs	x2, x2, x1
    8a84:	d2800001 	mov	x1, #0x0                   	// #0
    8a88:	540077c1 	b.ne	9980 <fwp_write+0xfc0>  // b.any
    8a8c:	910943ff 	add	sp, sp, #0x250
    8a90:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a94:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a98:	d65f03c0 	ret
    8a9c:	910123e0 	add	x0, sp, #0x48
    8aa0:	aa1303e5 	mov	x5, x19
    8aa4:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x220>
    8aa8:	aa0003f3 	mov	x19, x0
    8aac:	913f6084 	add	x4, x4, #0xfd8
    8ab0:	d2804003 	mov	x3, #0x200                 	// #512
    8ab4:	17ffffe2 	b	8a3c <fwp_write+0x7c>
    8ab8:	71004cbf 	cmp	w5, #0x13
    8abc:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x220>
    8ac0:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    8ac4:	913f2000 	add	x0, x0, #0xfc8
    8ac8:	913f4021 	add	x1, x1, #0xfd0
    8acc:	d2800082 	mov	x2, #0x4                   	// #4
    8ad0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	f90143f7 	str	x23, [sp, #640]
    8adc:	d2800016 	mov	x22, #0x0                   	// #0
    8ae0:	f90147f8 	str	x24, [sp, #648]
    8ae4:	97ffeaab 	bl	3590 <buf_put>
    8ae8:	f9400260 	ldr	x0, [x19]
    8aec:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x5c0>
    8af0:	d2800015 	mov	x21, #0x0                   	// #0
    8af4:	910142f7 	add	x23, x23, #0x50
    8af8:	b40047a0 	cbz	x0, 93ec <fwp_write+0xa2c>
    8afc:	b9400380 	ldr	w0, [x28]
    8b00:	52800003 	mov	w3, #0x0                   	// #0
    8b04:	f9401f82 	ldr	x2, [x28, #56]
    8b08:	71004c1f 	cmp	w0, #0x13
    8b0c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8b10:	aa1403e0 	mov	x0, x20
    8b14:	8b010e61 	add	x1, x19, x1, lsl #3
    8b18:	f9400421 	ldr	x1, [x1, #8]
    8b1c:	97ffffa9 	bl	89c0 <fwp_write>
    8b20:	b9400380 	ldr	w0, [x28]
    8b24:	7100481f 	cmp	w0, #0x12
    8b28:	54004b40 	b.eq	9490 <fwp_write+0xad0>  // b.none
    8b2c:	f9400260 	ldr	x0, [x19]
    8b30:	910006b5 	add	x21, x21, #0x1
    8b34:	91000ad6 	add	x22, x22, #0x2
    8b38:	eb15001f 	cmp	x0, x21
    8b3c:	54004589 	b.ls	93ec <fwp_write+0xa2c>  // b.plast
    8b40:	aa1703e1 	mov	x1, x23
    8b44:	aa1403e0 	mov	x0, x20
    8b48:	d2800042 	mov	x2, #0x2                   	// #2
    8b4c:	97ffea91 	bl	3590 <buf_put>
    8b50:	17ffffeb 	b	8afc <fwp_write+0x13c>
    8b54:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    8b58:	91002021 	add	x1, x1, #0x8
    8b5c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b60:	aa1403e0 	mov	x0, x20
    8b64:	91004273 	add	x19, x19, #0x10
    8b68:	97ffea8a 	bl	3590 <buf_put>
    8b6c:	aa1303e0 	mov	x0, x19
    8b70:	97ffe6e8 	bl	2710 <strlen@plt>
    8b74:	aa1303e1 	mov	x1, x19
    8b78:	aa0003e2 	mov	x2, x0
    8b7c:	aa1403e0 	mov	x0, x20
    8b80:	97ffea84 	bl	3590 <buf_put>
    8b84:	528007c3 	mov	w3, #0x3e                  	// #62
    8b88:	aa1403e0 	mov	x0, x20
    8b8c:	91001fe1 	add	x1, sp, #0x7
    8b90:	d2800022 	mov	x2, #0x1                   	// #1
    8b94:	39001fe3 	strb	w3, [sp, #7]
    8b98:	17ffffb1 	b	8a5c <fwp_write+0x9c>
    8b9c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ba0:	f947f400 	ldr	x0, [x0, #4072]
    8ba4:	f94127e2 	ldr	x2, [sp, #584]
    8ba8:	f9400001 	ldr	x1, [x0]
    8bac:	eb010042 	subs	x2, x2, x1
    8bb0:	d2800001 	mov	x1, #0x0                   	// #0
    8bb4:	540034e1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8bb8:	f9413bf5 	ldr	x21, [sp, #624]
    8bbc:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    8bc0:	f9413ff6 	ldr	x22, [sp, #632]
    8bc4:	aa1403e0 	mov	x0, x20
    8bc8:	913fa021 	add	x1, x1, #0xfe8
    8bcc:	d2800142 	mov	x2, #0xa                   	// #10
    8bd0:	f94153fb 	ldr	x27, [sp, #672]
    8bd4:	f94157fc 	ldr	x28, [sp, #680]
    8bd8:	910943ff 	add	sp, sp, #0x250
    8bdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8be0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8be4:	17ffea6b 	b	3590 <buf_put>
    8be8:	f9400456 	ldr	x22, [x2, #8]
    8bec:	f90143f7 	str	x23, [sp, #640]
    8bf0:	f90147f8 	str	x24, [sp, #648]
    8bf4:	b4005b16 	cbz	x22, 9754 <fwp_write+0xd94>
    8bf8:	aa1603e0 	mov	x0, x22
    8bfc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    8c00:	9101a021 	add	x1, x1, #0x68
    8c04:	97ffe73f 	bl	2900 <strcmp@plt>
    8c08:	2a0003f5 	mov	w21, w0
    8c0c:	34005fe0 	cbz	w0, 9808 <fwp_write+0xe48>
    8c10:	aa1603e0 	mov	x0, x22
    8c14:	97ffe6bf 	bl	2710 <strlen@plt>
    8c18:	aa1603e1 	mov	x1, x22
    8c1c:	aa0003e2 	mov	x2, x0
    8c20:	aa1403e0 	mov	x0, x20
    8c24:	97ffea5b 	bl	3590 <buf_put>
    8c28:	52800403 	mov	w3, #0x20                  	// #32
    8c2c:	91001ff5 	add	x21, sp, #0x7
    8c30:	aa1503e1 	mov	x1, x21
    8c34:	aa1403e0 	mov	x0, x20
    8c38:	d2800022 	mov	x2, #0x1                   	// #1
    8c3c:	39001fe3 	strb	w3, [sp, #7]
    8c40:	97ffea54 	bl	3590 <buf_put>
    8c44:	52800f63 	mov	w3, #0x7b                  	// #123
    8c48:	aa1403e0 	mov	x0, x20
    8c4c:	aa1503e1 	mov	x1, x21
    8c50:	d2800022 	mov	x2, #0x1                   	// #1
    8c54:	39001fe3 	strb	w3, [sp, #7]
    8c58:	97ffea4e 	bl	3590 <buf_put>
    8c5c:	b9401380 	ldr	w0, [x28, #16]
    8c60:	52800018 	mov	w24, #0x0                   	// #0
    8c64:	7100001f 	cmp	w0, #0x0
    8c68:	54003aad 	b.le	93bc <fwp_write+0x9fc>
    8c6c:	f9014bf9 	str	x25, [sp, #656]
    8c70:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x5c0>
    8c74:	91024339 	add	x25, x25, #0x90
    8c78:	f9014ffa 	str	x26, [sp, #664]
    8c7c:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x5c0>
    8c80:	9101435a 	add	x26, x26, #0x50
    8c84:	91002276 	add	x22, x19, #0x8
    8c88:	d2800013 	mov	x19, #0x0                   	// #0
    8c8c:	b5003e93 	cbnz	x19, 945c <fwp_write+0xa9c>
    8c90:	d37df277 	lsl	x23, x19, #3
    8c94:	34003cb8 	cbz	w24, 9428 <fwp_write+0xa68>
    8c98:	f9401382 	ldr	x2, [x28, #32]
    8c9c:	aa1403e0 	mov	x0, x20
    8ca0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8ca4:	52800003 	mov	w3, #0x0                   	// #0
    8ca8:	f8776842 	ldr	x2, [x2, x23]
    8cac:	91000673 	add	x19, x19, #0x1
    8cb0:	97ffff44 	bl	89c0 <fwp_write>
    8cb4:	b9401380 	ldr	w0, [x28, #16]
    8cb8:	6b13001f 	cmp	w0, w19
    8cbc:	54fffe8c 	b.gt	8c8c <fwp_write+0x2cc>
    8cc0:	f9414bf9 	ldr	x25, [sp, #656]
    8cc4:	f9414ffa 	ldr	x26, [sp, #664]
    8cc8:	340037b8 	cbz	w24, 93bc <fwp_write+0x9fc>
    8ccc:	52800523 	mov	w3, #0x29                  	// #41
    8cd0:	aa1503e1 	mov	x1, x21
    8cd4:	aa1403e0 	mov	x0, x20
    8cd8:	d2800022 	mov	x2, #0x1                   	// #1
    8cdc:	39001fe3 	strb	w3, [sp, #7]
    8ce0:	97ffea2c 	bl	3590 <buf_put>
    8ce4:	f9413bf5 	ldr	x21, [sp, #624]
    8ce8:	f9413ff6 	ldr	x22, [sp, #632]
    8cec:	f94143f7 	ldr	x23, [sp, #640]
    8cf0:	f94147f8 	ldr	x24, [sp, #648]
    8cf4:	f94153fb 	ldr	x27, [sp, #672]
    8cf8:	f94157fc 	ldr	x28, [sp, #680]
    8cfc:	17ffff5d 	b	8a70 <fwp_write+0xb0>
    8d00:	b9404855 	ldr	w21, [x2, #72]
    8d04:	aa1403e0 	mov	x0, x20
    8d08:	93407eb6 	sxtw	x22, w21
    8d0c:	91000ac1 	add	x1, x22, #0x2
    8d10:	97ffe9ed 	bl	34c4 <buf_grow>
    8d14:	a9400281 	ldp	x1, x0, [x20]
    8d18:	528e8603 	mov	w3, #0x7430                	// #29744
    8d1c:	78206823 	strh	w3, [x1, x0]
    8d20:	8b000022 	add	x2, x1, x0
    8d24:	710002bf 	cmp	w21, #0x0
    8d28:	540036cd 	b.le	9400 <fwp_write+0xa40>
    8d2c:	110006a3 	add	w3, w21, #0x1
    8d30:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8d34:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8d38:	91000449 	add	x9, x2, #0x1
    8d3c:	8b23c043 	add	x3, x2, w3, sxtw
    8d40:	f28aaac6 	movk	x6, #0x5556
    8d44:	f2955568 	movk	x8, #0xaaab
    8d48:	1400000d 	b	8d7c <fwp_write+0x3bc>
    8d4c:	d2800021 	mov	x1, #0x1                   	// #1
    8d50:	528005a5 	mov	w5, #0x2d                  	// #45
    8d54:	f100001f 	cmp	x0, #0x0
    8d58:	9b467e60 	smulh	x0, x19, x6
    8d5c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8d60:	381ff465 	strb	w5, [x3], #-1
    8d64:	cb040000 	sub	x0, x0, x4
    8d68:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8d6c:	cb020000 	sub	x0, x0, x2
    8d70:	8b010013 	add	x19, x0, x1
    8d74:	eb03013f 	cmp	x9, x3
    8d78:	54003440 	b.eq	9400 <fwp_write+0xa40>  // b.none
    8d7c:	9b467e60 	smulh	x0, x19, x6
    8d80:	937ffe64 	asr	x4, x19, #63
    8d84:	52800605 	mov	w5, #0x30                  	// #48
    8d88:	cb040000 	sub	x0, x0, x4
    8d8c:	8b000400 	add	x0, x0, x0, lsl #1
    8d90:	cb000260 	sub	x0, x19, x0
    8d94:	91000c01 	add	x1, x0, #0x3
    8d98:	9bc87c22 	umulh	x2, x1, x8
    8d9c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8da0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8da4:	eb020021 	subs	x1, x1, x2
    8da8:	54fffd60 	b.eq	8d54 <fwp_write+0x394>  // b.none
    8dac:	f100043f 	cmp	x1, #0x1
    8db0:	54fffce1 	b.ne	8d4c <fwp_write+0x38c>  // b.any
    8db4:	d2800001 	mov	x1, #0x0                   	// #0
    8db8:	52800565 	mov	w5, #0x2b                  	// #43
    8dbc:	17ffffe6 	b	8d54 <fwp_write+0x394>
    8dc0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8dc4:	f947f400 	ldr	x0, [x0, #4072]
    8dc8:	f94127e2 	ldr	x2, [sp, #584]
    8dcc:	f9400001 	ldr	x1, [x0]
    8dd0:	eb010042 	subs	x2, x2, x1
    8dd4:	d2800001 	mov	x1, #0x0                   	// #0
    8dd8:	540023c1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8ddc:	f9413bf5 	ldr	x21, [sp, #624]
    8de0:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    8de4:	f9413ff6 	ldr	x22, [sp, #632]
    8de8:	aa1403e0 	mov	x0, x20
    8dec:	913fe021 	add	x1, x1, #0xff8
    8df0:	d2800102 	mov	x2, #0x8                   	// #8
    8df4:	17ffff77 	b	8bd0 <fwp_write+0x210>
    8df8:	aa1403e0 	mov	x0, x20
    8dfc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    8e00:	d28000c2 	mov	x2, #0x6                   	// #6
    8e04:	91016021 	add	x1, x1, #0x58
    8e08:	97ffe9e2 	bl	3590 <buf_put>
    8e0c:	d2800015 	mov	x21, #0x0                   	// #0
    8e10:	f9400263 	ldr	x3, [x19]
    8e14:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8e18:	54002c60 	b.eq	93a4 <fwp_write+0x9e4>  // b.none
    8e1c:	f9401f82 	ldr	x2, [x28, #56]
    8e20:	f90143f7 	str	x23, [sp, #640]
    8e24:	f90147f8 	str	x24, [sp, #648]
    8e28:	d2800857 	mov	x23, #0x42                  	// #66
    8e2c:	f9014bf9 	str	x25, [sp, #656]
    8e30:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x5c0>
    8e34:	f9014ffa 	str	x26, [sp, #664]
    8e38:	910142d6 	add	x22, x22, #0x50
    8e3c:	d2800038 	mov	x24, #0x1                   	// #1
    8e40:	f2a18017 	movk	x23, #0xc00, lsl #16
    8e44:	d2809099 	mov	x25, #0x484                 	// #1156
    8e48:	b40004a2 	cbz	x2, 8edc <fwp_write+0x51c>
    8e4c:	b9400040 	ldr	w0, [x2]
    8e50:	7100701f 	cmp	w0, #0x1c
    8e54:	540042c0 	b.eq	96ac <fwp_write+0xcec>  // b.none
    8e58:	71006c1f 	cmp	w0, #0x1b
    8e5c:	54000408 	b.hi	8edc <fwp_write+0x51c>  // b.pmore
    8e60:	9ac02301 	lsl	x1, x24, x0
    8e64:	ea17003f 	tst	x1, x23
    8e68:	540036a1 	b.ne	953c <fwp_write+0xb7c>  // b.any
    8e6c:	ea19003f 	tst	x1, x25
    8e70:	54003521 	b.ne	9514 <fwp_write+0xb54>  // b.any
    8e74:	d2800424 	mov	x4, #0x21                  	// #33
    8e78:	ea04003f 	tst	x1, x4
    8e7c:	54000300 	b.eq	8edc <fwp_write+0x51c>  // b.none
    8e80:	b7f849c3 	tbnz	x3, #63, 97b8 <fwp_write+0xdf8>
    8e84:	91002261 	add	x1, x19, #0x8
    8e88:	8b150021 	add	x1, x1, x21
    8e8c:	39400021 	ldrb	w1, [x1]
    8e90:	7100001f 	cmp	w0, #0x0
    8e94:	93401c23 	sxtb	x3, w1
    8e98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e9c:	d503201f 	nop
    8ea0:	aa1403e0 	mov	x0, x20
    8ea4:	52800003 	mov	w3, #0x0                   	// #0
    8ea8:	97fffec6 	bl	89c0 <fwp_write>
    8eac:	910006b5 	add	x21, x21, #0x1
    8eb0:	f9400260 	ldr	x0, [x19]
    8eb4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8eb8:	eb0002bf 	cmp	x21, x0
    8ebc:	540026c2 	b.cs	9394 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ec0:	d2800042 	mov	x2, #0x2                   	// #2
    8ec4:	aa1603e1 	mov	x1, x22
    8ec8:	aa1403e0 	mov	x0, x20
    8ecc:	97ffe9b1 	bl	3590 <buf_put>
    8ed0:	f9401f82 	ldr	x2, [x28, #56]
    8ed4:	f9400263 	ldr	x3, [x19]
    8ed8:	b5fffba2 	cbnz	x2, 8e4c <fwp_write+0x48c>
    8edc:	d37df2a0 	lsl	x0, x21, #3
    8ee0:	b7f83f03 	tbnz	x3, #63, 96c0 <fwp_write+0xd00>
    8ee4:	91002261 	add	x1, x19, #0x8
    8ee8:	8b000020 	add	x0, x1, x0
    8eec:	f9400001 	ldr	x1, [x0]
    8ef0:	17ffffec 	b	8ea0 <fwp_write+0x4e0>
    8ef4:	a9400e62 	ldp	x2, x3, [x19]
    8ef8:	b7f83ca3 	tbnz	x3, #63, 968c <fwp_write+0xccc>
    8efc:	910123f5 	add	x21, sp, #0x48
    8f00:	aa1503e0 	mov	x0, x21
    8f04:	97ffe7c7 	bl	2e20 <fwp_fmt_u128>
    8f08:	aa1503e0 	mov	x0, x21
    8f0c:	97ffe601 	bl	2710 <strlen@plt>
    8f10:	aa1503e1 	mov	x1, x21
    8f14:	aa0003e2 	mov	x2, x0
    8f18:	17fffed0 	b	8a58 <fwp_write+0x98>
    8f1c:	fd015be8 	str	d8, [sp, #688]
    8f20:	1e270268 	fmov	s8, w19
    8f24:	fd015fe9 	str	d9, [sp, #696]
    8f28:	1e282100 	fcmp	s8, s8
    8f2c:	54004d26 	b.vs	98d0 <fwp_write+0xf10>
    8f30:	1e20c101 	fabs	s1, s8
    8f34:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8f38:	1e270000 	fmov	s0, w0
    8f3c:	1e202020 	fcmp	s1, s0
    8f40:	54002c0d 	b.le	94c0 <fwp_write+0xb00>
    8f44:	1e202118 	fcmpe	s8, #0.0
    8f48:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x220>
    8f4c:	912c6042 	add	x2, x2, #0xb18
    8f50:	910123f5 	add	x21, sp, #0x48
    8f54:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    8f58:	913ea021 	add	x1, x1, #0xfa8
    8f5c:	aa1503e0 	mov	x0, x21
    8f60:	9a81c041 	csel	x1, x2, x1, gt
    8f64:	97ffe697 	bl	29c0 <strcpy@plt>
    8f68:	aa1503e0 	mov	x0, x21
    8f6c:	97ffe5e9 	bl	2710 <strlen@plt>
    8f70:	aa1503e1 	mov	x1, x21
    8f74:	aa0003e2 	mov	x2, x0
    8f78:	aa1403e0 	mov	x0, x20
    8f7c:	97ffe985 	bl	3590 <buf_put>
    8f80:	f9413bf5 	ldr	x21, [sp, #624]
    8f84:	f9413ff6 	ldr	x22, [sp, #632]
    8f88:	f94153fb 	ldr	x27, [sp, #672]
    8f8c:	f94157fc 	ldr	x28, [sp, #680]
    8f90:	fd415be8 	ldr	d8, [sp, #688]
    8f94:	fd415fe9 	ldr	d9, [sp, #696]
    8f98:	17fffeb6 	b	8a70 <fwp_write+0xb0>
    8f9c:	f9400276 	ldr	x22, [x19]
    8fa0:	34002e03 	cbz	w3, 9560 <fwp_write+0xba0>
    8fa4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8fa8:	f947f400 	ldr	x0, [x0, #4072]
    8fac:	f94127e2 	ldr	x2, [sp, #584]
    8fb0:	f9400001 	ldr	x1, [x0]
    8fb4:	eb010042 	subs	x2, x2, x1
    8fb8:	d2800001 	mov	x1, #0x0                   	// #0
    8fbc:	540014a1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8fc0:	aa1603e2 	mov	x2, x22
    8fc4:	91002261 	add	x1, x19, #0x8
    8fc8:	f9413bf5 	ldr	x21, [sp, #624]
    8fcc:	aa1403e0 	mov	x0, x20
    8fd0:	f9413ff6 	ldr	x22, [sp, #632]
    8fd4:	17fffeff 	b	8bd0 <fwp_write+0x210>
    8fd8:	fd015be8 	str	d8, [sp, #688]
    8fdc:	9e670268 	fmov	d8, x19
    8fe0:	fd015fe9 	str	d9, [sp, #696]
    8fe4:	1e682100 	fcmp	d8, d8
    8fe8:	54004746 	b.vs	98d0 <fwp_write+0xf10>
    8fec:	1e60c101 	fabs	d1, d8
    8ff0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8ff4:	9e670000 	fmov	d0, x0
    8ff8:	910123f5 	add	x21, sp, #0x48
    8ffc:	52800033 	mov	w19, #0x1                   	// #1
    9000:	1e602020 	fcmp	d1, d0
    9004:	540001ad 	b.le	9038 <fwp_write+0x678>
    9008:	1e602118 	fcmpe	d8, #0.0
    900c:	90000022 	adrp	x2, d000 <fwp_main_thread+0x220>
    9010:	912c6042 	add	x2, x2, #0xb18
    9014:	90000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    9018:	913ea021 	add	x1, x1, #0xfa8
    901c:	aa1503e0 	mov	x0, x21
    9020:	9a81c041 	csel	x1, x2, x1, gt
    9024:	97ffe667 	bl	29c0 <strcpy@plt>
    9028:	17ffffd0 	b	8f68 <fwp_write+0x5a8>
    902c:	11000673 	add	w19, w19, #0x1
    9030:	71004a7f 	cmp	w19, #0x12
    9034:	54003860 	b.eq	9740 <fwp_write+0xd80>  // b.none
    9038:	1e604100 	fmov	d0, d8
    903c:	2a1303e1 	mov	w1, w19
    9040:	aa1503e0 	mov	x0, x21
    9044:	97ffe9ef 	bl	3800 <fwp_format_g.constprop.0>
    9048:	aa1503e0 	mov	x0, x21
    904c:	d2800001 	mov	x1, #0x0                   	// #0
    9050:	97ffe5c4 	bl	2760 <strtod@plt>
    9054:	1e602100 	fcmp	d8, d0
    9058:	54fffea1 	b.ne	902c <fwp_write+0x66c>  // b.any
    905c:	aa1503e0 	mov	x0, x21
    9060:	97ffe9c5 	bl	3774 <fwp_finish_float>
    9064:	17ffffc1 	b	8f68 <fwp_write+0x5a8>
    9068:	a9400e62 	ldp	x2, x3, [x19]
    906c:	910123f3 	add	x19, sp, #0x48
    9070:	aa1303e0 	mov	x0, x19
    9074:	97ffe76b 	bl	2e20 <fwp_fmt_u128>
    9078:	17fffe74 	b	8a48 <fwp_write+0x88>
    907c:	f90143f7 	str	x23, [sp, #640]
    9080:	f90147f8 	str	x24, [sp, #648]
    9084:	2a1303f8 	mov	w24, w19
    9088:	f9014bf9 	str	x25, [sp, #656]
    908c:	f9014ffa 	str	x26, [sp, #664]
    9090:	f13ffe7f 	cmp	x19, #0xfff
    9094:	54000049 	b.ls	909c <fwp_write+0x6dc>  // b.plast
    9098:	b9400278 	ldr	w24, [x19]
    909c:	f9400f80 	ldr	x0, [x28, #24]
    90a0:	2a1803f5 	mov	w21, w24
    90a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    90a8:	d37ef6b9 	lsl	x25, x21, #2
    90ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    90b0:	aa1603e0 	mov	x0, x22
    90b4:	97ffe597 	bl	2710 <strlen@plt>
    90b8:	aa1603e1 	mov	x1, x22
    90bc:	aa0003e2 	mov	x2, x0
    90c0:	aa1403e0 	mov	x0, x20
    90c4:	97ffe933 	bl	3590 <buf_put>
    90c8:	f9401780 	ldr	x0, [x28, #40]
    90cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    90d0:	7100001f 	cmp	w0, #0x0
    90d4:	5400068d 	b.le	91a4 <fwp_write+0x7e4>
    90d8:	91002276 	add	x22, x19, #0x8
    90dc:	91001ff5 	add	x21, sp, #0x7
    90e0:	d280001b 	mov	x27, #0x0                   	// #0
    90e4:	5280041a 	mov	w26, #0x20                  	// #32
    90e8:	f9401b80 	ldr	x0, [x28, #48]
    90ec:	aa1503e1 	mov	x1, x21
    90f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    90f4:	d2800022 	mov	x2, #0x1                   	// #1
    90f8:	f8786803 	ldr	x3, [x0, x24]
    90fc:	aa1403e0 	mov	x0, x20
    9100:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9104:	39001ffa 	strb	w26, [sp, #7]
    9108:	97ffe922 	bl	3590 <buf_put>
    910c:	f13ffeff 	cmp	x23, #0xfff
    9110:	b9400261 	ldr	w1, [x19]
    9114:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9118:	7100383f 	cmp	w1, #0xe
    911c:	54000160 	b.eq	9148 <fwp_write+0x788>  // b.none
    9120:	7100403f 	cmp	w1, #0x10
    9124:	54001a60 	b.eq	9470 <fwp_write+0xab0>  // b.none
    9128:	7100283f 	cmp	w1, #0xa
    912c:	54002aa0 	b.eq	9680 <fwp_write+0xcc0>  // b.none
    9130:	540014ac 	b.gt	93c4 <fwp_write+0xa04>
    9134:	71000c3f 	cmp	w1, #0x3
    9138:	540029ac 	b.gt	966c <fwp_write+0xcac>
    913c:	d37ffee0 	lsr	x0, x23, #63
    9140:	37f814a1 	tbnz	w1, #31, 93d4 <fwp_write+0xa14>
    9144:	d503201f 	nop
    9148:	34001460 	cbz	w0, 93d4 <fwp_write+0xa14>
    914c:	52800503 	mov	w3, #0x28                  	// #40
    9150:	aa1503e1 	mov	x1, x21
    9154:	aa1403e0 	mov	x0, x20
    9158:	d2800022 	mov	x2, #0x1                   	// #1
    915c:	39001fe3 	strb	w3, [sp, #7]
    9160:	97ffe90c 	bl	3590 <buf_put>
    9164:	aa1303e2 	mov	x2, x19
    9168:	aa1703e1 	mov	x1, x23
    916c:	aa1403e0 	mov	x0, x20
    9170:	52800003 	mov	w3, #0x0                   	// #0
    9174:	97fffe13 	bl	89c0 <fwp_write>
    9178:	52800523 	mov	w3, #0x29                  	// #41
    917c:	aa1503e1 	mov	x1, x21
    9180:	aa1403e0 	mov	x0, x20
    9184:	d2800022 	mov	x2, #0x1                   	// #1
    9188:	39001fe3 	strb	w3, [sp, #7]
    918c:	97ffe901 	bl	3590 <buf_put>
    9190:	f9401780 	ldr	x0, [x28, #40]
    9194:	9100077b 	add	x27, x27, #0x1
    9198:	b8796800 	ldr	w0, [x0, x25]
    919c:	6b1b001f 	cmp	w0, w27
    91a0:	54fffa4c 	b.gt	90e8 <fwp_write+0x728>
    91a4:	f9413bf5 	ldr	x21, [sp, #624]
    91a8:	f9413ff6 	ldr	x22, [sp, #632]
    91ac:	f94143f7 	ldr	x23, [sp, #640]
    91b0:	f94147f8 	ldr	x24, [sp, #648]
    91b4:	f9414bf9 	ldr	x25, [sp, #656]
    91b8:	f9414ffa 	ldr	x26, [sp, #664]
    91bc:	f94153fb 	ldr	x27, [sp, #672]
    91c0:	f94157fc 	ldr	x28, [sp, #680]
    91c4:	17fffe2b 	b	8a70 <fwp_write+0xb0>
    91c8:	52800783 	mov	w3, #0x3c                  	// #60
    91cc:	91001ff3 	add	x19, sp, #0x7
    91d0:	aa1303e1 	mov	x1, x19
    91d4:	d2800022 	mov	x2, #0x1                   	// #1
    91d8:	aa1403e0 	mov	x0, x20
    91dc:	39001fe3 	strb	w3, [sp, #7]
    91e0:	97ffe8ec 	bl	3590 <buf_put>
    91e4:	f9400795 	ldr	x21, [x28, #8]
    91e8:	aa1503e0 	mov	x0, x21
    91ec:	97ffe549 	bl	2710 <strlen@plt>
    91f0:	aa1503e1 	mov	x1, x21
    91f4:	aa0003e2 	mov	x2, x0
    91f8:	aa1403e0 	mov	x0, x20
    91fc:	97ffe8e5 	bl	3590 <buf_put>
    9200:	528007c3 	mov	w3, #0x3e                  	// #62
    9204:	aa1303e1 	mov	x1, x19
    9208:	aa1403e0 	mov	x0, x20
    920c:	d2800022 	mov	x2, #0x1                   	// #1
    9210:	39001fe3 	strb	w3, [sp, #7]
    9214:	17fffe12 	b	8a5c <fwp_write+0x9c>
    9218:	f100067f 	cmp	x19, #0x1
    921c:	540025a0 	b.eq	96d0 <fwp_write+0xd10>  // b.none
    9220:	b100067f 	cmn	x19, #0x1
    9224:	54002bc0 	b.eq	979c <fwp_write+0xddc>  // b.none
    9228:	90000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    922c:	913ec021 	add	x1, x1, #0xfb0
    9230:	d2800022 	mov	x2, #0x1                   	// #1
    9234:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9238:	f947f400 	ldr	x0, [x0, #4072]
    923c:	f94127e4 	ldr	x4, [sp, #584]
    9240:	f9400003 	ldr	x3, [x0]
    9244:	eb030084 	subs	x4, x4, x3
    9248:	d2800003 	mov	x3, #0x0                   	// #0
    924c:	54ffebe0 	b.eq	8fc8 <fwp_write+0x608>  // b.none
    9250:	f90143f7 	str	x23, [sp, #640]
    9254:	f90147f8 	str	x24, [sp, #648]
    9258:	f9014bf9 	str	x25, [sp, #656]
    925c:	f9014ffa 	str	x26, [sp, #664]
    9260:	fd015be8 	str	d8, [sp, #688]
    9264:	fd015fe9 	str	d9, [sp, #696]
    9268:	97ffe586 	bl	2880 <__stack_chk_fail@plt>
    926c:	52800b63 	mov	w3, #0x5b                  	// #91
    9270:	91001ff5 	add	x21, sp, #0x7
    9274:	aa1503e1 	mov	x1, x21
    9278:	aa1403e0 	mov	x0, x20
    927c:	d2800022 	mov	x2, #0x1                   	// #1
    9280:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x5c0>
    9284:	910142d6 	add	x22, x22, #0x50
    9288:	39001fe3 	strb	w3, [sp, #7]
    928c:	97ffe8c1 	bl	3590 <buf_put>
    9290:	b4000273 	cbz	x19, 92dc <fwp_write+0x91c>
    9294:	f9400661 	ldr	x1, [x19, #8]
    9298:	aa1403e0 	mov	x0, x20
    929c:	f9401f82 	ldr	x2, [x28, #56]
    92a0:	52800003 	mov	w3, #0x0                   	// #0
    92a4:	97fffdc7 	bl	89c0 <fwp_write>
    92a8:	f9400a73 	ldr	x19, [x19, #16]
    92ac:	b4000193 	cbz	x19, 92dc <fwp_write+0x91c>
    92b0:	aa1603e1 	mov	x1, x22
    92b4:	aa1403e0 	mov	x0, x20
    92b8:	d2800042 	mov	x2, #0x2                   	// #2
    92bc:	97ffe8b5 	bl	3590 <buf_put>
    92c0:	f9400661 	ldr	x1, [x19, #8]
    92c4:	aa1403e0 	mov	x0, x20
    92c8:	f9401f82 	ldr	x2, [x28, #56]
    92cc:	52800003 	mov	w3, #0x0                   	// #0
    92d0:	97fffdbc 	bl	89c0 <fwp_write>
    92d4:	f9400a73 	ldr	x19, [x19, #16]
    92d8:	b5fffed3 	cbnz	x19, 92b0 <fwp_write+0x8f0>
    92dc:	52800ba3 	mov	w3, #0x5d                  	// #93
    92e0:	aa1503e1 	mov	x1, x21
    92e4:	aa1403e0 	mov	x0, x20
    92e8:	d2800022 	mov	x2, #0x1                   	// #1
    92ec:	39001fe3 	strb	w3, [sp, #7]
    92f0:	17fffddb 	b	8a5c <fwp_write+0x9c>
    92f4:	aa1403e0 	mov	x0, x20
    92f8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    92fc:	d28000c2 	mov	x2, #0x6                   	// #6
    9300:	91010021 	add	x1, x1, #0x40
    9304:	97ffe8a3 	bl	3590 <buf_put>
    9308:	f9400260 	ldr	x0, [x19]
    930c:	b40004c0 	cbz	x0, 93a4 <fwp_write+0x9e4>
    9310:	910123f5 	add	x21, sp, #0x48
    9314:	91002276 	add	x22, x19, #0x8
    9318:	f90143f7 	str	x23, [sp, #640]
    931c:	d2800017 	mov	x23, #0x0                   	// #0
    9320:	f90147f8 	str	x24, [sp, #648]
    9324:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x5c0>
    9328:	91012318 	add	x24, x24, #0x48
    932c:	f9014bf9 	str	x25, [sp, #656]
    9330:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x5c0>
    9334:	91014339 	add	x25, x25, #0x50
    9338:	f9014ffa 	str	x26, [sp, #664]
    933c:	14000005 	b	9350 <fwp_write+0x990>
    9340:	aa1903e1 	mov	x1, x25
    9344:	aa1403e0 	mov	x0, x20
    9348:	d2800042 	mov	x2, #0x2                   	// #2
    934c:	97ffe891 	bl	3590 <buf_put>
    9350:	38776ac5 	ldrb	w5, [x22, x23]
    9354:	d2804003 	mov	x3, #0x200                 	// #512
    9358:	aa1803e4 	mov	x4, x24
    935c:	aa0303e1 	mov	x1, x3
    9360:	52800042 	mov	w2, #0x2                   	// #2
    9364:	aa1503e0 	mov	x0, x21
    9368:	910006f7 	add	x23, x23, #0x1
    936c:	97ffe521 	bl	27f0 <__snprintf_chk@plt>
    9370:	aa1503e0 	mov	x0, x21
    9374:	97ffe4e7 	bl	2710 <strlen@plt>
    9378:	aa1503e1 	mov	x1, x21
    937c:	aa0003e2 	mov	x2, x0
    9380:	aa1403e0 	mov	x0, x20
    9384:	97ffe883 	bl	3590 <buf_put>
    9388:	f9400260 	ldr	x0, [x19]
    938c:	eb17001f 	cmp	x0, x23
    9390:	54fffd88 	b.hi	9340 <fwp_write+0x980>  // b.pmore
    9394:	f94143f7 	ldr	x23, [sp, #640]
    9398:	f94147f8 	ldr	x24, [sp, #648]
    939c:	f9414bf9 	ldr	x25, [sp, #656]
    93a0:	f9414ffa 	ldr	x26, [sp, #664]
    93a4:	52800ba3 	mov	w3, #0x5d                  	// #93
    93a8:	aa1403e0 	mov	x0, x20
    93ac:	91001fe1 	add	x1, sp, #0x7
    93b0:	d2800022 	mov	x2, #0x1                   	// #1
    93b4:	39001fe3 	strb	w3, [sp, #7]
    93b8:	17fffda9 	b	8a5c <fwp_write+0x9c>
    93bc:	52800fa3 	mov	w3, #0x7d                  	// #125
    93c0:	17fffe44 	b	8cd0 <fwp_write+0x310>
    93c4:	f10002ff 	cmp	x23, #0x0
    93c8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    93cc:	71002c3f 	cmp	w1, #0xb
    93d0:	54ffebc0 	b.eq	9148 <fwp_write+0x788>  // b.none
    93d4:	aa1303e2 	mov	x2, x19
    93d8:	aa1703e1 	mov	x1, x23
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	52800003 	mov	w3, #0x0                   	// #0
    93e4:	97fffd77 	bl	89c0 <fwp_write>
    93e8:	17ffff6a 	b	9190 <fwp_write+0x7d0>
    93ec:	aa1403e0 	mov	x0, x20
    93f0:	91001fe1 	add	x1, sp, #0x7
    93f4:	52800fa3 	mov	w3, #0x7d                  	// #125
    93f8:	d2800022 	mov	x2, #0x1                   	// #1
    93fc:	17fffe38 	b	8cdc <fwp_write+0x31c>
    9400:	a9400281 	ldp	x1, x0, [x20]
    9404:	91000800 	add	x0, x0, #0x2
    9408:	8b160000 	add	x0, x0, x22
    940c:	f9000680 	str	x0, [x20, #8]
    9410:	3820683f 	strb	wzr, [x1, x0]
    9414:	f9413bf5 	ldr	x21, [sp, #624]
    9418:	f9413ff6 	ldr	x22, [sp, #632]
    941c:	f94153fb 	ldr	x27, [sp, #672]
    9420:	f94157fc 	ldr	x28, [sp, #680]
    9424:	17fffd93 	b	8a70 <fwp_write+0xb0>
    9428:	f9400f80 	ldr	x0, [x28, #24]
    942c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9430:	aa1b03e0 	mov	x0, x27
    9434:	97ffe4b7 	bl	2710 <strlen@plt>
    9438:	aa1b03e1 	mov	x1, x27
    943c:	aa0003e2 	mov	x2, x0
    9440:	aa1403e0 	mov	x0, x20
    9444:	97ffe853 	bl	3590 <buf_put>
    9448:	aa1903e1 	mov	x1, x25
    944c:	aa1403e0 	mov	x0, x20
    9450:	d2800062 	mov	x2, #0x3                   	// #3
    9454:	97ffe84f 	bl	3590 <buf_put>
    9458:	17fffe10 	b	8c98 <fwp_write+0x2d8>
    945c:	aa1a03e1 	mov	x1, x26
    9460:	aa1403e0 	mov	x0, x20
    9464:	d2800042 	mov	x2, #0x2                   	// #2
    9468:	97ffe84a 	bl	3590 <buf_put>
    946c:	17fffe09 	b	8c90 <fwp_write+0x2d0>
    9470:	f9400660 	ldr	x0, [x19, #8]
    9474:	b4fffb00 	cbz	x0, 93d4 <fwp_write+0xa14>
    9478:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    947c:	9101a021 	add	x1, x1, #0x68
    9480:	97ffe520 	bl	2900 <strcmp@plt>
    9484:	7100001f 	cmp	w0, #0x0
    9488:	1a9f07e0 	cset	w0, ne	// ne = any
    948c:	17ffff2f 	b	9148 <fwp_write+0x788>
    9490:	aa1403e0 	mov	x0, x20
    9494:	d2800042 	mov	x2, #0x2                   	// #2
    9498:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    949c:	91018021 	add	x1, x1, #0x60
    94a0:	97ffe83c 	bl	3590 <buf_put>
    94a4:	91004261 	add	x1, x19, #0x10
    94a8:	aa1403e0 	mov	x0, x20
    94ac:	f9402382 	ldr	x2, [x28, #64]
    94b0:	52800003 	mov	w3, #0x0                   	// #0
    94b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    94b8:	97fffd42 	bl	89c0 <fwp_write>
    94bc:	17fffd9c 	b	8b2c <fwp_write+0x16c>
    94c0:	1e22c109 	fcvt	d9, s8
    94c4:	910123f5 	add	x21, sp, #0x48
    94c8:	52800033 	mov	w19, #0x1                   	// #1
    94cc:	d503201f 	nop
    94d0:	1e604120 	fmov	d0, d9
    94d4:	2a1303e1 	mov	w1, w19
    94d8:	aa1503e0 	mov	x0, x21
    94dc:	97ffe8c9 	bl	3800 <fwp_format_g.constprop.0>
    94e0:	aa1503e0 	mov	x0, x21
    94e4:	d2800001 	mov	x1, #0x0                   	// #0
    94e8:	97ffe512 	bl	2930 <strtof@plt>
    94ec:	1e202100 	fcmp	s8, s0
    94f0:	54ffdb60 	b.eq	905c <fwp_write+0x69c>  // b.none
    94f4:	11000673 	add	w19, w19, #0x1
    94f8:	71002a7f 	cmp	w19, #0xa
    94fc:	54fffea1 	b.ne	94d0 <fwp_write+0xb10>  // b.any
    9500:	1e604120 	fmov	d0, d9
    9504:	aa1503e0 	mov	x0, x21
    9508:	52800121 	mov	w1, #0x9                   	// #9
    950c:	97ffe8bd 	bl	3800 <fwp_format_g.constprop.0>
    9510:	17fffed3 	b	905c <fwp_write+0x69c>
    9514:	d37ef6a1 	lsl	x1, x21, #2
    9518:	b7f81563 	tbnz	x3, #63, 97c4 <fwp_write+0xe04>
    951c:	91002263 	add	x3, x19, #0x8
    9520:	8b010061 	add	x1, x3, x1
    9524:	b9400023 	ldr	w3, [x1]
    9528:	7100081f 	cmp	w0, #0x2
    952c:	2a0303e1 	mov	w1, w3
    9530:	93407c63 	sxtw	x3, w3
    9534:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9538:	17fffe5a 	b	8ea0 <fwp_write+0x4e0>
    953c:	d37ffaa1 	lsl	x1, x21, #1
    9540:	b7f81363 	tbnz	x3, #63, 97ac <fwp_write+0xdec>
    9544:	91002263 	add	x3, x19, #0x8
    9548:	8b010061 	add	x1, x3, x1
    954c:	79400021 	ldrh	w1, [x1]
    9550:	7100041f 	cmp	w0, #0x1
    9554:	93403c23 	sxth	x3, w1
    9558:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    955c:	17fffe51 	b	8ea0 <fwp_write+0x4e0>
    9560:	52800443 	mov	w3, #0x22                  	// #34
    9564:	91001ff5 	add	x21, sp, #0x7
    9568:	91002273 	add	x19, x19, #0x8
    956c:	aa1503e1 	mov	x1, x21
    9570:	aa1403e0 	mov	x0, x20
    9574:	d2800022 	mov	x2, #0x1                   	// #1
    9578:	39001fe3 	strb	w3, [sp, #7]
    957c:	f90143f7 	str	x23, [sp, #640]
    9580:	8b160277 	add	x23, x19, x22
    9584:	f90147f8 	str	x24, [sp, #648]
    9588:	97ffe802 	bl	3590 <buf_put>
    958c:	b4000696 	cbz	x22, 965c <fwp_write+0xc9c>
    9590:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x5c0>
    9594:	91004318 	add	x24, x24, #0x10
    9598:	f9014bf9 	str	x25, [sp, #656]
    959c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x5c0>
    95a0:	9100c339 	add	x25, x25, #0x30
    95a4:	f9014ffa 	str	x26, [sp, #664]
    95a8:	1400000d 	b	95dc <fwp_write+0xc1c>
    95ac:	710024bf 	cmp	w5, #0x9
    95b0:	54000460 	b.eq	963c <fwp_write+0xc7c>  // b.none
    95b4:	710028bf 	cmp	w5, #0xa
    95b8:	54000a61 	b.ne	9704 <fwp_write+0xd44>  // b.any
    95bc:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    95c0:	aa1403e0 	mov	x0, x20
    95c4:	91008021 	add	x1, x1, #0x20
    95c8:	d2800042 	mov	x2, #0x2                   	// #2
    95cc:	97ffe7f1 	bl	3590 <buf_put>
    95d0:	91000673 	add	x19, x19, #0x1
    95d4:	eb17027f 	cmp	x19, x23
    95d8:	540003e0 	b.eq	9654 <fwp_write+0xc94>  // b.none
    95dc:	39400265 	ldrb	w5, [x19]
    95e0:	710034bf 	cmp	w5, #0xd
    95e4:	54000180 	b.eq	9614 <fwp_write+0xc54>  // b.none
    95e8:	54fffe29 	b.ls	95ac <fwp_write+0xbec>  // b.plast
    95ec:	710088bf 	cmp	w5, #0x22
    95f0:	540001c0 	b.eq	9628 <fwp_write+0xc68>  // b.none
    95f4:	710170bf 	cmp	w5, #0x5c
    95f8:	54000741 	b.ne	96e0 <fwp_write+0xd20>  // b.any
    95fc:	aa1403e0 	mov	x0, x20
    9600:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    9604:	d2800042 	mov	x2, #0x2                   	// #2
    9608:	91006021 	add	x1, x1, #0x18
    960c:	97ffe7e1 	bl	3590 <buf_put>
    9610:	17fffff0 	b	95d0 <fwp_write+0xc10>
    9614:	aa1903e1 	mov	x1, x25
    9618:	aa1403e0 	mov	x0, x20
    961c:	d2800042 	mov	x2, #0x2                   	// #2
    9620:	97ffe7dc 	bl	3590 <buf_put>
    9624:	17ffffeb 	b	95d0 <fwp_write+0xc10>
    9628:	aa1803e1 	mov	x1, x24
    962c:	aa1403e0 	mov	x0, x20
    9630:	d2800042 	mov	x2, #0x2                   	// #2
    9634:	97ffe7d7 	bl	3590 <buf_put>
    9638:	17ffffe6 	b	95d0 <fwp_write+0xc10>
    963c:	aa1403e0 	mov	x0, x20
    9640:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    9644:	d2800042 	mov	x2, #0x2                   	// #2
    9648:	9100a021 	add	x1, x1, #0x28
    964c:	97ffe7d1 	bl	3590 <buf_put>
    9650:	17ffffe0 	b	95d0 <fwp_write+0xc10>
    9654:	f9414bf9 	ldr	x25, [sp, #656]
    9658:	f9414ffa 	ldr	x26, [sp, #664]
    965c:	aa1503e1 	mov	x1, x21
    9660:	aa1403e0 	mov	x0, x20
    9664:	52800443 	mov	w3, #0x22                  	// #34
    9668:	17fffd9c 	b	8cd8 <fwp_write+0x318>
    966c:	7100103f 	cmp	w1, #0x4
    9670:	54ffeb21 	b.ne	93d4 <fwp_write+0xa14>  // b.any
    9674:	f94006e0 	ldr	x0, [x23, #8]
    9678:	d37ffc00 	lsr	x0, x0, #63
    967c:	17fffeb3 	b	9148 <fwp_write+0x788>
    9680:	710002ff 	cmp	w23, #0x0
    9684:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9688:	17fffeb0 	b	9148 <fwp_write+0x788>
    968c:	528005a1 	mov	w1, #0x2d                  	// #45
    9690:	eb0203e2 	negs	x2, x2
    9694:	da0303e3 	ngc	x3, x3
    9698:	910127e0 	add	x0, sp, #0x49
    969c:	910123f5 	add	x21, sp, #0x48
    96a0:	390123e1 	strb	w1, [sp, #72]
    96a4:	97ffe5df 	bl	2e20 <fwp_fmt_u128>
    96a8:	17fffe18 	b	8f08 <fwp_write+0x548>
    96ac:	d37ceea1 	lsl	x1, x21, #4
    96b0:	b7f810a3 	tbnz	x3, #63, 98c4 <fwp_write+0xf04>
    96b4:	91002260 	add	x0, x19, #0x8
    96b8:	8b010001 	add	x1, x0, x1
    96bc:	17fffdf9 	b	8ea0 <fwp_write+0x4e0>
    96c0:	f9400a61 	ldr	x1, [x19, #16]
    96c4:	8b010000 	add	x0, x0, x1
    96c8:	f9400001 	ldr	x1, [x0]
    96cc:	17fffdf5 	b	8ea0 <fwp_write+0x4e0>
    96d0:	90000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    96d4:	d2800042 	mov	x2, #0x2                   	// #2
    96d8:	913ee021 	add	x1, x1, #0xfb8
    96dc:	17fffed6 	b	9234 <fwp_write+0x874>
    96e0:	7101fcbf 	cmp	w5, #0x7f
    96e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    96e8:	540000e9 	b.ls	9704 <fwp_write+0xd44>  // b.plast
    96ec:	aa1503e1 	mov	x1, x21
    96f0:	aa1403e0 	mov	x0, x20
    96f4:	d2800022 	mov	x2, #0x1                   	// #1
    96f8:	39001fe5 	strb	w5, [sp, #7]
    96fc:	97ffe7a5 	bl	3590 <buf_put>
    9700:	17ffffb4 	b	95d0 <fwp_write+0xc10>
    9704:	d2800203 	mov	x3, #0x10                  	// #16
    9708:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x5c0>
    970c:	aa0303e1 	mov	x1, x3
    9710:	9100e084 	add	x4, x4, #0x38
    9714:	910123f6 	add	x22, sp, #0x48
    9718:	52800042 	mov	w2, #0x2                   	// #2
    971c:	aa1603e0 	mov	x0, x22
    9720:	97ffe434 	bl	27f0 <__snprintf_chk@plt>
    9724:	aa1603e0 	mov	x0, x22
    9728:	97ffe3fa 	bl	2710 <strlen@plt>
    972c:	aa1603e1 	mov	x1, x22
    9730:	aa0003e2 	mov	x2, x0
    9734:	aa1403e0 	mov	x0, x20
    9738:	97ffe796 	bl	3590 <buf_put>
    973c:	17ffffa5 	b	95d0 <fwp_write+0xc10>
    9740:	1e604100 	fmov	d0, d8
    9744:	aa1503e0 	mov	x0, x21
    9748:	52800221 	mov	w1, #0x11                  	// #17
    974c:	97ffe82d 	bl	3800 <fwp_format_g.constprop.0>
    9750:	17fffe43 	b	905c <fwp_write+0x69c>
    9754:	b9401040 	ldr	w0, [x2, #16]
    9758:	350003c0 	cbnz	w0, 97d0 <fwp_write+0xe10>
    975c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9760:	f947f400 	ldr	x0, [x0, #4072]
    9764:	f94127e2 	ldr	x2, [sp, #584]
    9768:	f9400001 	ldr	x1, [x0]
    976c:	eb010042 	subs	x2, x2, x1
    9770:	d2800001 	mov	x1, #0x0                   	// #0
    9774:	54ffd721 	b.ne	9258 <fwp_write+0x898>  // b.any
    9778:	f9413bf5 	ldr	x21, [sp, #624]
    977c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5c0>
    9780:	f9413ff6 	ldr	x22, [sp, #632]
    9784:	aa1403e0 	mov	x0, x20
    9788:	f94143f7 	ldr	x23, [sp, #640]
    978c:	91022021 	add	x1, x1, #0x88
    9790:	f94147f8 	ldr	x24, [sp, #648]
    9794:	d2800042 	mov	x2, #0x2                   	// #2
    9798:	17fffd0e 	b	8bd0 <fwp_write+0x210>
    979c:	90000021 	adrp	x1, d000 <fwp_main_thread+0x220>
    97a0:	d2800042 	mov	x2, #0x2                   	// #2
    97a4:	913f0021 	add	x1, x1, #0xfc0
    97a8:	17fffea3 	b	9234 <fwp_write+0x874>
    97ac:	f9400a63 	ldr	x3, [x19, #16]
    97b0:	8b030021 	add	x1, x1, x3
    97b4:	17ffff66 	b	954c <fwp_write+0xb8c>
    97b8:	f9400a61 	ldr	x1, [x19, #16]
    97bc:	8b0102a1 	add	x1, x21, x1
    97c0:	17fffdb3 	b	8e8c <fwp_write+0x4cc>
    97c4:	f9400a63 	ldr	x3, [x19, #16]
    97c8:	8b030021 	add	x1, x1, x3
    97cc:	17ffff56 	b	9524 <fwp_write+0xb64>
    97d0:	b9404840 	ldr	w0, [x2, #72]
    97d4:	91001ff5 	add	x21, sp, #0x7
    97d8:	34ffa360 	cbz	w0, 8c44 <fwp_write+0x284>
    97dc:	52800503 	mov	w3, #0x28                  	// #40
    97e0:	aa1403e0 	mov	x0, x20
    97e4:	aa1503e1 	mov	x1, x21
    97e8:	d2800022 	mov	x2, #0x1                   	// #1
    97ec:	39001fe3 	strb	w3, [sp, #7]
    97f0:	97ffe768 	bl	3590 <buf_put>
    97f4:	b9401380 	ldr	w0, [x28, #16]
    97f8:	52800038 	mov	w24, #0x1                   	// #1
    97fc:	7100001f 	cmp	w0, #0x0
    9800:	54ffa36c 	b.gt	8c6c <fwp_write+0x2ac>
    9804:	17fffd32 	b	8ccc <fwp_write+0x30c>
    9808:	f9014bf9 	str	x25, [sp, #656]
    980c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe2e8>
    9810:	f9014ffa 	str	x26, [sp, #664]
    9814:	f9400676 	ldr	x22, [x19, #8]
    9818:	91102333 	add	x19, x25, #0x408
    981c:	91002273 	add	x19, x19, #0x8
    9820:	937ffed8 	asr	x24, x22, #63
    9824:	aa1802c0 	orr	x0, x22, x24
    9828:	b5000320 	cbnz	x0, 988c <fwp_write+0xecc>
    982c:	110006b5 	add	w21, w21, #0x1
    9830:	710016bf 	cmp	w21, #0x5
    9834:	54ffffc1 	b.ne	982c <fwp_write+0xe6c>  // b.any
    9838:	b7f80578 	tbnz	x24, #63, 98e4 <fwp_write+0xf24>
    983c:	910023f3 	add	x19, sp, #0x8
    9840:	aa1603e2 	mov	x2, x22
    9844:	aa1303e0 	mov	x0, x19
    9848:	d2800003 	mov	x3, #0x0                   	// #0
    984c:	97ffe575 	bl	2e20 <fwp_fmt_u128>
    9850:	910123f5 	add	x21, sp, #0x48
    9854:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x5c0>
    9858:	aa1303e4 	mov	x4, x19
    985c:	aa1503e0 	mov	x0, x21
    9860:	91020063 	add	x3, x3, #0x80
    9864:	d2804002 	mov	x2, #0x200                 	// #512
    9868:	52800041 	mov	w1, #0x2                   	// #2
    986c:	97ffe3ad 	bl	2720 <__sprintf_chk@plt>
    9870:	aa1503e0 	mov	x0, x21
    9874:	97ffe3a7 	bl	2710 <strlen@plt>
    9878:	aa1503e1 	mov	x1, x21
    987c:	aa0003e2 	mov	x2, x0
    9880:	aa1403e0 	mov	x0, x20
    9884:	97ffe743 	bl	3590 <buf_put>
    9888:	17fffe47 	b	91a4 <fwp_write+0x7e4>
    988c:	f9400277 	ldr	x23, [x19]
    9890:	aa1603e0 	mov	x0, x22
    9894:	aa1803e1 	mov	x1, x24
    9898:	aa1703e2 	mov	x2, x23
    989c:	937ffefa 	asr	x26, x23, #63
    98a0:	aa1a03e3 	mov	x3, x26
    98a4:	94000f7f 	bl	d6a0 <__modti3>
    98a8:	aa010000 	orr	x0, x0, x1
    98ac:	b40002c0 	cbz	x0, 9904 <fwp_write+0xf44>
    98b0:	110006b5 	add	w21, w21, #0x1
    98b4:	91004273 	add	x19, x19, #0x10
    98b8:	710016bf 	cmp	w21, #0x5
    98bc:	54fffe81 	b.ne	988c <fwp_write+0xecc>  // b.any
    98c0:	17ffffde 	b	9838 <fwp_write+0xe78>
    98c4:	f9400a60 	ldr	x0, [x19, #16]
    98c8:	8b000021 	add	x1, x1, x0
    98cc:	17fffd75 	b	8ea0 <fwp_write+0x4e0>
    98d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    98d4:	910123f5 	add	x21, sp, #0x48
    98d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    98dc:	b9004be0 	str	w0, [sp, #72]
    98e0:	17fffda2 	b	8f68 <fwp_write+0x5a8>
    98e4:	528005a1 	mov	w1, #0x2d                  	// #45
    98e8:	eb1603e2 	negs	x2, x22
    98ec:	da1803e3 	ngc	x3, x24
    98f0:	910027e0 	add	x0, sp, #0x9
    98f4:	910023f3 	add	x19, sp, #0x8
    98f8:	390023e1 	strb	w1, [sp, #8]
    98fc:	97ffe549 	bl	2e20 <fwp_fmt_u128>
    9900:	17ffffd4 	b	9850 <fwp_write+0xe90>
    9904:	aa1703e2 	mov	x2, x23
    9908:	aa1a03e3 	mov	x3, x26
    990c:	aa1603e0 	mov	x0, x22
    9910:	aa1803e1 	mov	x1, x24
    9914:	94000e83 	bl	d320 <__divti3>
    9918:	aa0003e2 	mov	x2, x0
    991c:	aa0103e3 	mov	x3, x1
    9920:	b7f80201 	tbnz	x1, #63, 9960 <fwp_write+0xfa0>
    9924:	910023f3 	add	x19, sp, #0x8
    9928:	aa1303e0 	mov	x0, x19
    992c:	97ffe53d 	bl	2e20 <fwp_fmt_u128>
    9930:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9934:	91102339 	add	x25, x25, #0x408
    9938:	910123f5 	add	x21, sp, #0x48
    993c:	aa1303e4 	mov	x4, x19
    9940:	aa1503e0 	mov	x0, x21
    9944:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x5c0>
    9948:	f8616b25 	ldr	x5, [x25, x1]
    994c:	9101e063 	add	x3, x3, #0x78
    9950:	d2804002 	mov	x2, #0x200                 	// #512
    9954:	52800041 	mov	w1, #0x2                   	// #2
    9958:	97ffe372 	bl	2720 <__sprintf_chk@plt>
    995c:	17ffffc5 	b	9870 <fwp_write+0xeb0>
    9960:	528005a4 	mov	w4, #0x2d                  	// #45
    9964:	eb0003e2 	negs	x2, x0
    9968:	da0103e3 	ngc	x3, x1
    996c:	910027e0 	add	x0, sp, #0x9
    9970:	910023f3 	add	x19, sp, #0x8
    9974:	390023e4 	strb	w4, [sp, #8]
    9978:	97ffe52a 	bl	2e20 <fwp_fmt_u128>
    997c:	17ffffed 	b	9930 <fwp_write+0xf70>
    9980:	f9013bf5 	str	x21, [sp, #624]
    9984:	f9013ff6 	str	x22, [sp, #632]
    9988:	f90143f7 	str	x23, [sp, #640]
    998c:	f90147f8 	str	x24, [sp, #648]
    9990:	f9014bf9 	str	x25, [sp, #656]
    9994:	f9014ffa 	str	x26, [sp, #664]
    9998:	f90153fb 	str	x27, [sp, #672]
    999c:	f90157fc 	str	x28, [sp, #680]
    99a0:	fd015be8 	str	d8, [sp, #688]
    99a4:	fd015fe9 	str	d9, [sp, #696]
    99a8:	97ffe3b6 	bl	2880 <__stack_chk_fail@plt>
    99ac:	d503201f 	nop

00000000000099b0 <fwp_hof0.constprop.0>:
    99b0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    99b4:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    99b8:	f947f442 	ldr	x2, [x2, #4072]
    99bc:	910003fd 	mov	x29, sp
    99c0:	a90153f3 	stp	x19, x20, [sp, #16]
    99c4:	a9025bf5 	stp	x21, x22, [sp, #32]
    99c8:	a90363f7 	stp	x23, x24, [sp, #48]
    99cc:	aa0003f7 	mov	x23, x0
    99d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    99d4:	a90573fb 	stp	x27, x28, [sp, #80]
    99d8:	d10203ff 	sub	sp, sp, #0x80
    99dc:	f9400040 	ldr	x0, [x2]
    99e0:	f81f83a0 	stur	x0, [x29, #-8]
    99e4:	d2800000 	mov	x0, #0x0                   	// #0
    99e8:	b40039a1 	cbz	x1, a11c <fwp_hof0.constprop.0+0x76c>
    99ec:	f00000a0 	adrp	x0, 20000 <__data_start>
    99f0:	9100401c 	add	x28, x0, #0x10
    99f4:	aa1703fa 	mov	x26, x23
    99f8:	f00000a0 	adrp	x0, 20000 <__data_start>
    99fc:	9101039c 	add	x28, x28, #0x40
    9a00:	d10083b4 	sub	x20, x29, #0x20
    9a04:	9101c015 	add	x21, x0, #0x70
    9a08:	aa0103f7 	mov	x23, x1
    9a0c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9a10:	91174001 	add	x1, x0, #0x5d0
    9a14:	f949d822 	ldr	x2, [x1, #5040]
    9a18:	f949ec20 	ldr	x0, [x1, #5080]
    9a1c:	cb020342 	sub	x2, x26, x2
    9a20:	eb00405f 	cmp	x2, x0, lsl #16
    9a24:	54000342 	b.cs	9a8c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9a28:	d350fc40 	lsr	x0, x2, #16
    9a2c:	f949fc24 	ldr	x4, [x1, #5112]
    9a30:	8b000800 	add	x0, x0, x0, lsl #2
    9a34:	d37df001 	lsl	x1, x0, #3
    9a38:	8b010083 	add	x3, x4, x1
    9a3c:	f9401060 	ldr	x0, [x3, #32]
    9a40:	b4000260 	cbz	x0, 9a8c <fwp_hof0.constprop.0+0xdc>
    9a44:	38616881 	ldrb	w1, [x4, x1]
    9a48:	7100083f 	cmp	w1, #0x2
    9a4c:	540055c0 	b.eq	a504 <fwp_hof0.constprop.0+0xb54>  // b.none
    9a50:	7100043f 	cmp	w1, #0x1
    9a54:	540001c1 	b.ne	9a8c <fwp_hof0.constprop.0+0xdc>  // b.any
    9a58:	92403c41 	and	x1, x2, #0xffff
    9a5c:	29430864 	ldp	w4, w2, [x3, #24]
    9a60:	9b047c21 	mul	x1, x1, x4
    9a64:	d360fc21 	lsr	x1, x1, #32
    9a68:	eb02003f 	cmp	x1, x2
    9a6c:	54000102 	b.cs	9a8c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9a70:	8b010000 	add	x0, x0, x1
    9a74:	39400001 	ldrb	w1, [x0]
    9a78:	340000a1 	cbz	w1, 9a8c <fwp_hof0.constprop.0+0xdc>
    9a7c:	7103f43f 	cmp	w1, #0xfd
    9a80:	540056c8 	b.hi	a558 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9a84:	11000421 	add	w1, w1, #0x1
    9a88:	39000001 	strb	w1, [x0]
    9a8c:	aa1a03f8 	mov	x24, x26
    9a90:	aa1c03f9 	mov	x25, x28
    9a94:	d28018f3 	mov	x19, #0xc7                  	// #199
    9a98:	a9396bb7 	stp	x23, x26, [x29, #-112]
    9a9c:	f81a03b3 	stur	x19, [x29, #-96]
    9aa0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9aa4:	91004000 	add	x0, x0, #0x10
    9aa8:	f94066a3 	ldr	x3, [x21, #200]
    9aac:	91010006 	add	x6, x0, #0x40
    9ab0:	b9404002 	ldr	w2, [x0, #64]
    9ab4:	d37be842 	lsl	x2, x2, #5
    9ab8:	8b020064 	add	x4, x3, x2
    9abc:	f9400c81 	ldr	x1, [x4, #24]
    9ac0:	f81e03b8 	stur	x24, [x29, #-32]
    9ac4:	b40052e1 	cbz	x1, a520 <fwp_hof0.constprop.0+0xb70>
    9ac8:	f9400c20 	ldr	x0, [x1, #24]
    9acc:	b40046a0 	cbz	x0, a3a0 <fwp_hof0.constprop.0+0x9f0>
    9ad0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ad4:	91174002 	add	x2, x0, #0x5d0
    9ad8:	f949d841 	ldr	x1, [x2, #5040]
    9adc:	f949ec40 	ldr	x0, [x2, #5080]
    9ae0:	cb010321 	sub	x1, x25, x1
    9ae4:	eb00403f 	cmp	x1, x0, lsl #16
    9ae8:	54000342 	b.cs	9b50 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9aec:	d350fc20 	lsr	x0, x1, #16
    9af0:	f949fc45 	ldr	x5, [x2, #5112]
    9af4:	8b000800 	add	x0, x0, x0, lsl #2
    9af8:	d37df002 	lsl	x2, x0, #3
    9afc:	8b0200a3 	add	x3, x5, x2
    9b00:	f9401060 	ldr	x0, [x3, #32]
    9b04:	b4000260 	cbz	x0, 9b50 <fwp_hof0.constprop.0+0x1a0>
    9b08:	386268a2 	ldrb	w2, [x5, x2]
    9b0c:	7100085f 	cmp	w2, #0x2
    9b10:	54004b40 	b.eq	a478 <fwp_hof0.constprop.0+0xac8>  // b.none
    9b14:	7100045f 	cmp	w2, #0x1
    9b18:	540001c1 	b.ne	9b50 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9b1c:	29430865 	ldp	w5, w2, [x3, #24]
    9b20:	92403c21 	and	x1, x1, #0xffff
    9b24:	9b057c21 	mul	x1, x1, x5
    9b28:	d360fc21 	lsr	x1, x1, #32
    9b2c:	eb02003f 	cmp	x1, x2
    9b30:	54000102 	b.cs	9b50 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9b34:	8b010000 	add	x0, x0, x1
    9b38:	39400001 	ldrb	w1, [x0]
    9b3c:	340000a1 	cbz	w1, 9b50 <fwp_hof0.constprop.0+0x1a0>
    9b40:	7103f43f 	cmp	w1, #0xfd
    9b44:	54004e68 	b.hi	a510 <fwp_hof0.constprop.0+0xb60>  // b.pmore
    9b48:	11000421 	add	w1, w1, #0x1
    9b4c:	39000001 	strb	w1, [x0]
    9b50:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9b54:	aa1903f8 	mov	x24, x25
    9b58:	aa1903e0 	mov	x0, x25
    9b5c:	91174036 	add	x22, x1, #0x5d0
    9b60:	52800037 	mov	w23, #0x1                   	// #1
    9b64:	a93ae7b4 	stp	x20, x25, [x29, #-88]
    9b68:	b81cc3b7 	stur	w23, [x29, #-52]
    9b6c:	f81d03b4 	stur	x20, [x29, #-48]
    9b70:	b9400401 	ldr	w1, [x0, #4]
    9b74:	b9400099 	ldr	w25, [x4]
    9b78:	b85cc3a0 	ldur	w0, [x29, #-52]
    9b7c:	4b010339 	sub	w25, w25, w1
    9b80:	6b17033f 	cmp	w25, w23
    9b84:	1a979326 	csel	w6, w25, w23, ls	// ls = plast
    9b88:	6b0000df 	cmp	w6, w0
    9b8c:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    9b90:	b81c83a0 	stur	w0, [x29, #-56]
    9b94:	6b0000c2 	subs	w2, w6, w0
    9b98:	54000120 	b.eq	9bbc <fwp_hof0.constprop.0+0x20c>  // b.none
    9b9c:	f9400c83 	ldr	x3, [x4, #24]
    9ba0:	0b000021 	add	w1, w1, w0
    9ba4:	f85d03a4 	ldur	x4, [x29, #-48]
    9ba8:	b81d83a6 	stur	w6, [x29, #-40]
    9bac:	f9400863 	ldr	x3, [x3, #16]
    9bb0:	8b204c80 	add	x0, x4, w0, uxtw #3
    9bb4:	d63f0060 	blr	x3
    9bb8:	b85d83a6 	ldur	w6, [x29, #-40]
    9bbc:	f94066a0 	ldr	x0, [x21, #200]
    9bc0:	aa1803e9 	mov	x9, x24
    9bc4:	b9400304 	ldr	w4, [x24]
    9bc8:	2a0603f4 	mov	w20, w6
    9bcc:	f85d03bb 	ldur	x27, [x29, #-48]
    9bd0:	aa1803fa 	mov	x26, x24
    9bd4:	8b041404 	add	x4, x0, x4, lsl #5
    9bd8:	f9400c8a 	ldr	x10, [x4, #24]
    9bdc:	b400106a 	cbz	x10, 9de8 <fwp_hof0.constprop.0+0x438>
    9be0:	29371bb7 	stp	w23, w6, [x29, #-72]
    9be4:	aa0403f7 	mov	x23, x4
    9be8:	b81c03b9 	stur	w25, [x29, #-64]
    9bec:	aa1b03f9 	mov	x25, x27
    9bf0:	14000012 	b	9c38 <fwp_hof0.constprop.0+0x288>
    9bf4:	f9400141 	ldr	x1, [x10]
    9bf8:	aa1903e0 	mov	x0, x25
    9bfc:	d63f0020 	blr	x1
    9c00:	aa0003fb 	mov	x27, x0
    9c04:	aa1803e0 	mov	x0, x24
    9c08:	97fff1aa 	bl	62b0 <fwp_closure_drop>
    9c0c:	6b14027f 	cmp	w19, w20
    9c10:	54000cc0 	b.eq	9da8 <fwp_hof0.constprop.0+0x3f8>  // b.none
    9c14:	f94066a0 	ldr	x0, [x21, #200]
    9c18:	8b334f39 	add	x25, x25, w19, uxtw #3
    9c1c:	b9400364 	ldr	w4, [x27]
    9c20:	4b1a0394 	sub	w20, w28, w26
    9c24:	aa1b03e9 	mov	x9, x27
    9c28:	8b041417 	add	x23, x0, x4, lsl #5
    9c2c:	f9400eea 	ldr	x10, [x23, #24]
    9c30:	b4000d4a 	cbz	x10, 9dd8 <fwp_hof0.constprop.0+0x428>
    9c34:	aa1b03f8 	mov	x24, x27
    9c38:	b9400521 	ldr	w1, [x9, #4]
    9c3c:	b94002fa 	ldr	w26, [x23]
    9c40:	0b14003c 	add	w28, w1, w20
    9c44:	6b1c035f 	cmp	w26, w28
    9c48:	540028a8 	b.hi	a15c <fwp_hof0.constprop.0+0x7ac>  // b.pmore
    9c4c:	7100003f 	cmp	w1, #0x0
    9c50:	4b010353 	sub	w19, w26, w1
    9c54:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9c58:	54fffce1 	b.ne	9bf4 <fwp_hof0.constprop.0+0x244>  // b.any
    9c5c:	910003e0 	mov	x0, sp
    9c60:	7100035f 	cmp	w26, #0x0
    9c64:	f81d83a0 	stur	x0, [x29, #-40]
    9c68:	1a9f1740 	csinc	w0, w26, wzr, ne	// ne = any
    9c6c:	d37df000 	lsl	x0, x0, #3
    9c70:	91003c00 	add	x0, x0, #0xf
    9c74:	92704c05 	and	x5, x0, #0xfffff0000
    9c78:	927c7c00 	and	x0, x0, #0xffffffff0
    9c7c:	cb2563e5 	sub	x5, sp, x5
    9c80:	eb2563ff 	cmp	sp, x5
    9c84:	540000a0 	b.eq	9c98 <fwp_hof0.constprop.0+0x2e8>  // b.none
    9c88:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9c8c:	f90203ff 	str	xzr, [sp, #1024]
    9c90:	eb2563ff 	cmp	sp, x5
    9c94:	54ffffa1 	b.ne	9c88 <fwp_hof0.constprop.0+0x2d8>  // b.any
    9c98:	92403c00 	and	x0, x0, #0xffff
    9c9c:	cb2063ff 	sub	sp, sp, x0
    9ca0:	f90003ff 	str	xzr, [sp]
    9ca4:	f110001f 	cmp	x0, #0x400
    9ca8:	54000043 	b.cc	9cb0 <fwp_hof0.constprop.0+0x300>  // b.lo, b.ul, b.last
    9cac:	f90203ff 	str	xzr, [sp, #1024]
    9cb0:	910043fb 	add	x27, sp, #0x10
    9cb4:	d37d7c28 	ubfiz	x8, x1, #3, #32
    9cb8:	91002127 	add	x7, x9, #0x8
    9cbc:	d2800000 	mov	x0, #0x0                   	// #0
    9cc0:	340000e1 	cbz	w1, 9cdc <fwp_hof0.constprop.0+0x32c>
    9cc4:	d503201f 	nop
    9cc8:	f86068e2 	ldr	x2, [x7, x0]
    9ccc:	f8206b62 	str	x2, [x27, x0]
    9cd0:	91002000 	add	x0, x0, #0x8
    9cd4:	eb00011f 	cmp	x8, x0
    9cd8:	54ffff81 	b.ne	9cc8 <fwp_hof0.constprop.0+0x318>  // b.any
    9cdc:	2a1303e8 	mov	w8, w19
    9ce0:	d2800000 	mov	x0, #0x0                   	// #0
    9ce4:	340000f3 	cbz	w19, 9d00 <fwp_hof0.constprop.0+0x350>
    9ce8:	0b000022 	add	w2, w1, w0
    9cec:	f8607b23 	ldr	x3, [x25, x0, lsl #3]
    9cf0:	91000400 	add	x0, x0, #0x1
    9cf4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9cf8:	eb00011f 	cmp	x8, x0
    9cfc:	54ffff61 	b.ne	9ce8 <fwp_hof0.constprop.0+0x338>  // b.any
    9d00:	f949dac0 	ldr	x0, [x22, #5040]
    9d04:	f949eec1 	ldr	x1, [x22, #5080]
    9d08:	cb000300 	sub	x0, x24, x0
    9d0c:	eb01401f 	cmp	x0, x1, lsl #16
    9d10:	540002e2 	b.cs	9d6c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9d14:	d350fc01 	lsr	x1, x0, #16
    9d18:	f949fec8 	ldr	x8, [x22, #5112]
    9d1c:	8b010821 	add	x1, x1, x1, lsl #2
    9d20:	d37df021 	lsl	x1, x1, #3
    9d24:	8b010107 	add	x7, x8, x1
    9d28:	f94010e6 	ldr	x6, [x7, #32]
    9d2c:	b4000206 	cbz	x6, 9d6c <fwp_hof0.constprop.0+0x3bc>
    9d30:	38616901 	ldrb	w1, [x8, x1]
    9d34:	7100083f 	cmp	w1, #0x2
    9d38:	540004a0 	b.eq	9dcc <fwp_hof0.constprop.0+0x41c>  // b.none
    9d3c:	7100043f 	cmp	w1, #0x1
    9d40:	54000161 	b.ne	9d6c <fwp_hof0.constprop.0+0x3bc>  // b.any
    9d44:	294304e8 	ldp	w8, w1, [x7, #24]
    9d48:	92403c00 	and	x0, x0, #0xffff
    9d4c:	9b087c00 	mul	x0, x0, x8
    9d50:	d360fc00 	lsr	x0, x0, #32
    9d54:	eb01001f 	cmp	x0, x1
    9d58:	540000a2 	b.cs	9d6c <fwp_hof0.constprop.0+0x3bc>  // b.hs, b.nlast
    9d5c:	8b0000c6 	add	x6, x6, x0
    9d60:	394000c0 	ldrb	w0, [x6]
    9d64:	7100041f 	cmp	w0, #0x1
    9d68:	540002e0 	b.eq	9dc4 <fwp_hof0.constprop.0+0x414>  // b.none
    9d6c:	f9400546 	ldr	x6, [x10, #8]
    9d70:	aa1803e0 	mov	x0, x24
    9d74:	52800021 	mov	w1, #0x1                   	// #1
    9d78:	d63f00c0 	blr	x6
    9d7c:	f9400ee1 	ldr	x1, [x23, #24]
    9d80:	aa1b03e0 	mov	x0, x27
    9d84:	f9400021 	ldr	x1, [x1]
    9d88:	d63f0020 	blr	x1
    9d8c:	aa0003fb 	mov	x27, x0
    9d90:	f85d83a0 	ldur	x0, [x29, #-40]
    9d94:	9100001f 	mov	sp, x0
    9d98:	aa1803e0 	mov	x0, x24
    9d9c:	97fff145 	bl	62b0 <fwp_closure_drop>
    9da0:	6b14027f 	cmp	w19, w20
    9da4:	54fff381 	b.ne	9c14 <fwp_hof0.constprop.0+0x264>  // b.any
    9da8:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9dac:	aa1b03f8 	mov	x24, x27
    9db0:	b85c03b9 	ldur	w25, [x29, #-64]
    9db4:	6b17033f 	cmp	w25, w23
    9db8:	54000443 	b.cc	9e40 <fwp_hof0.constprop.0+0x490>  // b.lo, b.ul, b.last
    9dbc:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9dc0:	1400003e 	b	9eb8 <fwp_hof0.constprop.0+0x508>
    9dc4:	b900053f 	str	wzr, [x9, #4]
    9dc8:	17ffffed 	b	9d7c <fwp_hof0.constprop.0+0x3cc>
    9dcc:	72003c1f 	tst	w0, #0xffff
    9dd0:	54fffce1 	b.ne	9d6c <fwp_hof0.constprop.0+0x3bc>  // b.any
    9dd4:	17ffffe3 	b	9d60 <fwp_hof0.constprop.0+0x3b0>
    9dd8:	aa1b03fa 	mov	x26, x27
    9ddc:	aa1903fb 	mov	x27, x25
    9de0:	29771bb7 	ldp	w23, w6, [x29, #-72]
    9de4:	b85c03b9 	ldur	w25, [x29, #-64]
    9de8:	aa1a03e0 	mov	x0, x26
    9dec:	b81d83a6 	stur	w6, [x29, #-40]
    9df0:	97ffef48 	bl	5b10 <fwp_rc_share>
    9df4:	b85d83a6 	ldur	w6, [x29, #-40]
    9df8:	34000134 	cbz	w20, 9e1c <fwp_hof0.constprop.0+0x46c>
    9dfc:	aa1b03f8 	mov	x24, x27
    9e00:	8b344f73 	add	x19, x27, w20, uxtw #3
    9e04:	2a0603fc 	mov	w28, w6
    9e08:	f8408700 	ldr	x0, [x24], #8
    9e0c:	97ffef41 	bl	5b10 <fwp_rc_share>
    9e10:	eb18027f 	cmp	x19, x24
    9e14:	54ffffa1 	b.ne	9e08 <fwp_hof0.constprop.0+0x458>  // b.any
    9e18:	2a1c03e6 	mov	w6, w28
    9e1c:	aa1b03e2 	mov	x2, x27
    9e20:	2a1403e1 	mov	w1, w20
    9e24:	aa1a03e0 	mov	x0, x26
    9e28:	b81d83a6 	stur	w6, [x29, #-40]
    9e2c:	97ffec76 	bl	5004 <fwp_apply>
    9e30:	aa0003f8 	mov	x24, x0
    9e34:	b85d83a6 	ldur	w6, [x29, #-40]
    9e38:	6b17033f 	cmp	w25, w23
    9e3c:	54fffc02 	b.cs	9dbc <fwp_hof0.constprop.0+0x40c>  // b.hs, b.nlast
    9e40:	f94066a1 	ldr	x1, [x21, #200]
    9e44:	4b0602f7 	sub	w23, w23, w6
    9e48:	b9400304 	ldr	w4, [x24]
    9e4c:	f85d03a0 	ldur	x0, [x29, #-48]
    9e50:	8b041424 	add	x4, x1, x4, lsl #5
    9e54:	b85c83a2 	ldur	w2, [x29, #-56]
    9e58:	8b264c00 	add	x0, x0, w6, uxtw #3
    9e5c:	f81d03a0 	stur	x0, [x29, #-48]
    9e60:	f9400c81 	ldr	x1, [x4, #24]
    9e64:	b85cc3a0 	ldur	w0, [x29, #-52]
    9e68:	4b020000 	sub	w0, w0, w2
    9e6c:	b81cc3a0 	stur	w0, [x29, #-52]
    9e70:	aa1803e0 	mov	x0, x24
    9e74:	b5ffe7e1 	cbnz	x1, 9b70 <fwp_hof0.constprop.0+0x1c0>
    9e78:	a97ae7b4 	ldp	x20, x25, [x29, #-88]
    9e7c:	aa1803e0 	mov	x0, x24
    9e80:	97ffef24 	bl	5b10 <fwp_rc_share>
    9e84:	34000117 	cbz	w23, 9ea4 <fwp_hof0.constprop.0+0x4f4>
    9e88:	f85d03ba 	ldur	x26, [x29, #-48]
    9e8c:	d2800016 	mov	x22, #0x0                   	// #0
    9e90:	f8767b40 	ldr	x0, [x26, x22, lsl #3]
    9e94:	910006d6 	add	x22, x22, #0x1
    9e98:	97ffef1e 	bl	5b10 <fwp_rc_share>
    9e9c:	6b1602ff 	cmp	w23, w22
    9ea0:	54ffff88 	b.hi	9e90 <fwp_hof0.constprop.0+0x4e0>  // b.pmore
    9ea4:	f85d03a2 	ldur	x2, [x29, #-48]
    9ea8:	aa1803e0 	mov	x0, x24
    9eac:	2a1703e1 	mov	w1, w23
    9eb0:	97ffec55 	bl	5004 <fwp_apply>
    9eb4:	aa0003f8 	mov	x24, x0
    9eb8:	f85a03a0 	ldur	x0, [x29, #-96]
    9ebc:	f1000400 	subs	x0, x0, #0x1
    9ec0:	f81a03a0 	stur	x0, [x29, #-96]
    9ec4:	54ffdee1 	b.ne	9aa0 <fwp_hof0.constprop.0+0xf0>  // b.any
    9ec8:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe2e8>
    9ecc:	91102042 	add	x2, x2, #0x408
    9ed0:	a9796bb7 	ldp	x23, x26, [x29, #-112]
    9ed4:	aa1803e1 	mov	x1, x24
    9ed8:	aa1403e0 	mov	x0, x20
    9edc:	aa1803fb 	mov	x27, x24
    9ee0:	91014042 	add	x2, x2, #0x50
    9ee4:	52800023 	mov	w3, #0x1                   	// #1
    9ee8:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9eec:	aa1903fc 	mov	x28, x25
    9ef0:	f81f03bf 	stur	xzr, [x29, #-16]
    9ef4:	97fffab3 	bl	89c0 <fwp_write>
    9ef8:	a97e63b6 	ldp	x22, x24, [x29, #-32]
    9efc:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    9f00:	91156000 	add	x0, x0, #0x558
    9f04:	f10002df 	cmp	x22, #0x0
    9f08:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9f0c:	b1002b1f 	cmn	x24, #0xa
    9f10:	54003288 	b.hi	a560 <fwp_hof0.constprop.0+0xbb0>  // b.pmore
    9f14:	91002700 	add	x0, x24, #0x9
    9f18:	52800021 	mov	w1, #0x1                   	// #1
    9f1c:	97ffebf5 	bl	4ef0 <fwp_heap_alloc>
    9f20:	aa0003f3 	mov	x19, x0
    9f24:	aa1603e1 	mov	x1, x22
    9f28:	aa0003f6 	mov	x22, x0
    9f2c:	aa1803e2 	mov	x2, x24
    9f30:	f80086d8 	str	x24, [x22], #8
    9f34:	8b180278 	add	x24, x19, x24
    9f38:	aa1603e0 	mov	x0, x22
    9f3c:	97ffe1e5 	bl	26d0 <memcpy@plt>
    9f40:	3900231f 	strb	wzr, [x24, #8]
    9f44:	f85e03a0 	ldur	x0, [x29, #-32]
    9f48:	97ffe27e 	bl	2940 <free@plt>
    9f4c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9f50:	91174003 	add	x3, x0, #0x5d0
    9f54:	f949ec64 	ldr	x4, [x3, #5080]
    9f58:	f949d861 	ldr	x1, [x3, #5040]
    9f5c:	d370bc84 	lsl	x4, x4, #16
    9f60:	cb010262 	sub	x2, x19, x1
    9f64:	eb04005f 	cmp	x2, x4
    9f68:	540003c2 	b.cs	9fe0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9f6c:	d350fc40 	lsr	x0, x2, #16
    9f70:	f949fc66 	ldr	x6, [x3, #5112]
    9f74:	8b000800 	add	x0, x0, x0, lsl #2
    9f78:	d37df003 	lsl	x3, x0, #3
    9f7c:	8b0300c0 	add	x0, x6, x3
    9f80:	f9401018 	ldr	x24, [x0, #32]
    9f84:	b40002f8 	cbz	x24, 9fe0 <fwp_hof0.constprop.0+0x630>
    9f88:	386368c3 	ldrb	w3, [x6, x3]
    9f8c:	7100087f 	cmp	w3, #0x2
    9f90:	54002ee0 	b.eq	a56c <fwp_hof0.constprop.0+0xbbc>  // b.none
    9f94:	7100047f 	cmp	w3, #0x1
    9f98:	54000241 	b.ne	9fe0 <fwp_hof0.constprop.0+0x630>  // b.any
    9f9c:	29430003 	ldp	w3, w0, [x0, #24]
    9fa0:	92403c42 	and	x2, x2, #0xffff
    9fa4:	9b037c42 	mul	x2, x2, x3
    9fa8:	d360fc42 	lsr	x2, x2, #32
    9fac:	eb00005f 	cmp	x2, x0
    9fb0:	54000182 	b.cs	9fe0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    9fb4:	8b020318 	add	x24, x24, x2
    9fb8:	39400300 	ldrb	w0, [x24]
    9fbc:	7103fc1f 	cmp	w0, #0xff
    9fc0:	54003cc0 	b.eq	a758 <fwp_hof0.constprop.0+0xda8>  // b.none
    9fc4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9fc8:	91174000 	add	x0, x0, #0x5d0
    9fcc:	52800021 	mov	w1, #0x1                   	// #1
    9fd0:	39000301 	strb	w1, [x24]
    9fd4:	f949ec04 	ldr	x4, [x0, #5080]
    9fd8:	f949d801 	ldr	x1, [x0, #5040]
    9fdc:	d370bc84 	lsl	x4, x4, #16
    9fe0:	cb010361 	sub	x1, x27, x1
    9fe4:	eb01009f 	cmp	x4, x1
    9fe8:	540003c9 	b.ls	a060 <fwp_hof0.constprop.0+0x6b0>  // b.plast
    9fec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ff0:	91174019 	add	x25, x0, #0x5d0
    9ff4:	d350fc22 	lsr	x2, x1, #16
    9ff8:	f949ff26 	ldr	x6, [x25, #5112]
    9ffc:	8b020842 	add	x2, x2, x2, lsl #2
    a000:	d37df042 	lsl	x2, x2, #3
    a004:	8b0200c0 	add	x0, x6, x2
    a008:	f9401018 	ldr	x24, [x0, #32]
    a00c:	b40002b8 	cbz	x24, a060 <fwp_hof0.constprop.0+0x6b0>
    a010:	386268c2 	ldrb	w2, [x6, x2]
    a014:	7100085f 	cmp	w2, #0x2
    a018:	540030a0 	b.eq	a62c <fwp_hof0.constprop.0+0xc7c>  // b.none
    a01c:	7100045f 	cmp	w2, #0x1
    a020:	54000201 	b.ne	a060 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a024:	29430002 	ldp	w2, w0, [x0, #24]
    a028:	92403c21 	and	x1, x1, #0xffff
    a02c:	9b027c21 	mul	x1, x1, x2
    a030:	d360fc21 	lsr	x1, x1, #32
    a034:	eb00003f 	cmp	x1, x0
    a038:	54000142 	b.cs	a060 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a03c:	8b010318 	add	x24, x24, x1
    a040:	39400300 	ldrb	w0, [x24]
    a044:	340000e0 	cbz	w0, a060 <fwp_hof0.constprop.0+0x6b0>
    a048:	7100041f 	cmp	w0, #0x1
    a04c:	540029c0 	b.eq	a584 <fwp_hof0.constprop.0+0xbd4>  // b.none
    a050:	7103fc1f 	cmp	w0, #0xff
    a054:	54002fa0 	b.eq	a648 <fwp_hof0.constprop.0+0xc98>  // b.none
    a058:	51000400 	sub	w0, w0, #0x1
    a05c:	39000300 	strb	w0, [x24]
    a060:	d00000a0 	adrp	x0, 20000 <__data_start>
    a064:	9101c003 	add	x3, x0, #0x70
    a068:	f9400262 	ldr	x2, [x19]
    a06c:	aa1603e0 	mov	x0, x22
    a070:	aa0303f6 	mov	x22, x3
    a074:	d2800021 	mov	x1, #0x1                   	// #1
    a078:	f9400463 	ldr	x3, [x3, #8]
    a07c:	97ffe241 	bl	2980 <fwrite@plt>
    a080:	f94006c1 	ldr	x1, [x22, #8]
    a084:	52800140 	mov	w0, #0xa                   	// #10
    a088:	97ffe1c6 	bl	27a0 <fputc@plt>
    a08c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a090:	91174002 	add	x2, x0, #0x5d0
    a094:	f949d841 	ldr	x1, [x2, #5040]
    a098:	f949ec40 	ldr	x0, [x2, #5080]
    a09c:	cb010261 	sub	x1, x19, x1
    a0a0:	eb00403f 	cmp	x1, x0, lsl #16
    a0a4:	54000382 	b.cs	a114 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    a0a8:	d350fc20 	lsr	x0, x1, #16
    a0ac:	f949fc43 	ldr	x3, [x2, #5112]
    a0b0:	8b000800 	add	x0, x0, x0, lsl #2
    a0b4:	d37df000 	lsl	x0, x0, #3
    a0b8:	8b000062 	add	x2, x3, x0
    a0bc:	f9401056 	ldr	x22, [x2, #32]
    a0c0:	b40002b6 	cbz	x22, a114 <fwp_hof0.constprop.0+0x764>
    a0c4:	38606860 	ldrb	w0, [x3, x0]
    a0c8:	7100081f 	cmp	w0, #0x2
    a0cc:	54002560 	b.eq	a578 <fwp_hof0.constprop.0+0xbc8>  // b.none
    a0d0:	7100041f 	cmp	w0, #0x1
    a0d4:	54000201 	b.ne	a114 <fwp_hof0.constprop.0+0x764>  // b.any
    a0d8:	29430043 	ldp	w3, w0, [x2, #24]
    a0dc:	92403c21 	and	x1, x1, #0xffff
    a0e0:	9b037c21 	mul	x1, x1, x3
    a0e4:	d360fc21 	lsr	x1, x1, #32
    a0e8:	eb00003f 	cmp	x1, x0
    a0ec:	54000142 	b.cs	a114 <fwp_hof0.constprop.0+0x764>  // b.hs, b.nlast
    a0f0:	8b0102d6 	add	x22, x22, x1
    a0f4:	394002c0 	ldrb	w0, [x22]
    a0f8:	340000e0 	cbz	w0, a114 <fwp_hof0.constprop.0+0x764>
    a0fc:	7100041f 	cmp	w0, #0x1
    a100:	54002de0 	b.eq	a6bc <fwp_hof0.constprop.0+0xd0c>  // b.none
    a104:	7103fc1f 	cmp	w0, #0xff
    a108:	54002e00 	b.eq	a6c8 <fwp_hof0.constprop.0+0xd18>  // b.none
    a10c:	51000400 	sub	w0, w0, #0x1
    a110:	390002c0 	strb	w0, [x22]
    a114:	f9400af7 	ldr	x23, [x23, #16]
    a118:	b5ffc7b7 	cbnz	x23, 9a0c <fwp_hof0.constprop.0+0x5c>
    a11c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a120:	f947f400 	ldr	x0, [x0, #4072]
    a124:	f85f83a2 	ldur	x2, [x29, #-8]
    a128:	f9400001 	ldr	x1, [x0]
    a12c:	eb010042 	subs	x2, x2, x1
    a130:	d2800001 	mov	x1, #0x0                   	// #0
    a134:	54002821 	b.ne	a638 <fwp_hof0.constprop.0+0xc88>  // b.any
    a138:	910003bf 	mov	sp, x29
    a13c:	d2800000 	mov	x0, #0x0                   	// #0
    a140:	a94153f3 	ldp	x19, x20, [sp, #16]
    a144:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a148:	a94363f7 	ldp	x23, x24, [sp, #48]
    a14c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a150:	a94573fb 	ldp	x27, x28, [sp, #80]
    a154:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a158:	d65f03c0 	ret
    a15c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a160:	9117400a 	add	x10, x0, #0x5d0
    a164:	2a0103fa 	mov	w26, w1
    a168:	11000780 	add	w0, w28, #0x1
    a16c:	f120001f 	cmp	x0, #0x800
    a170:	aa1703e4 	mov	x4, x23
    a174:	b953a541 	ldr	w1, [x10, #5028]
    a178:	aa1903fb 	mov	x27, x25
    a17c:	29771bb7 	ldp	w23, w6, [x29, #-72]
    a180:	d37df000 	lsl	x0, x0, #3
    a184:	b85c03b9 	ldur	w25, [x29, #-64]
    a188:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a18c:	540018e0 	b.eq	a4a8 <fwp_hof0.constprop.0+0xaf8>  // b.none
    a190:	91003c01 	add	x1, x0, #0xf
    a194:	8b411141 	add	x1, x10, x1, lsr #4
    a198:	397e8021 	ldrb	w1, [x1, #4000]
    a19c:	910f002b 	add	x11, x1, #0x3c0
    a1a0:	8b010422 	add	x2, x1, x1, lsl #1
    a1a4:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a1a8:	8b020d4c 	add	x12, x10, x2, lsl #3
    a1ac:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    a1b0:	2a0b03e1 	mov	w1, w11
    a1b4:	b4001693 	cbz	x19, a484 <fwp_hof0.constprop.0+0xad4>
    a1b8:	f940026c 	ldr	x12, [x19]
    a1bc:	aa2c03ec 	mvn	x12, x12
    a1c0:	f822794c 	str	x12, [x10, x2, lsl #3]
    a1c4:	eb01001f 	cmp	x0, x1
    a1c8:	540000c2 	b.cs	a1e0 <fwp_hof0.constprop.0+0x830>  // b.hs, b.nlast
    a1cc:	d503201f 	nop
    a1d0:	f8206a7f 	str	xzr, [x19, x0]
    a1d4:	91002000 	add	x0, x0, #0x8
    a1d8:	eb00003f 	cmp	x1, x0
    a1dc:	54ffffa8 	b.hi	a1d0 <fwp_hof0.constprop.0+0x820>  // b.pmore
    a1e0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a1e4:	91174002 	add	x2, x0, #0x5d0
    a1e8:	f94a1040 	ldr	x0, [x2, #5152]
    a1ec:	ab010000 	adds	x0, x0, x1
    a1f0:	54002a62 	b.cs	a73c <fwp_hof0.constprop.0+0xd8c>  // b.hs, b.nlast
    a1f4:	f94a1441 	ldr	x1, [x2, #5160]
    a1f8:	f90a1040 	str	x0, [x2, #5152]
    a1fc:	eb01001f 	cmp	x0, x1
    a200:	54000049 	b.ls	a208 <fwp_hof0.constprop.0+0x858>  // b.plast
    a204:	f90a1440 	str	x0, [x2, #5160]
    a208:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a20c:	91174000 	add	x0, x0, #0x5d0
    a210:	1e630161 	ucvtf	d1, w11
    a214:	fd4a1c00 	ldr	d0, [x0, #5176]
    a218:	1e612800 	fadd	d0, d0, d1
    a21c:	fd0a1c00 	str	d0, [x0, #5176]
    a220:	b9400120 	ldr	w0, [x9]
    a224:	29007260 	stp	w0, w28, [x19]
    a228:	3400017a 	cbz	w26, a254 <fwp_hof0.constprop.0+0x8a4>
    a22c:	91002121 	add	x1, x9, #0x8
    a230:	d37d7f42 	ubfiz	x2, x26, #3, #32
    a234:	91002260 	add	x0, x19, #0x8
    a238:	b81bc3a6 	stur	w6, [x29, #-68]
    a23c:	f81c03a4 	stur	x4, [x29, #-64]
    a240:	f81d83a9 	stur	x9, [x29, #-40]
    a244:	97ffe12b 	bl	26f0 <memmove@plt>
    a248:	f85c03a4 	ldur	x4, [x29, #-64]
    a24c:	f85d83a9 	ldur	x9, [x29, #-40]
    a250:	b85bc3a6 	ldur	w6, [x29, #-68]
    a254:	2a1403e8 	mov	w8, w20
    a258:	d2800001 	mov	x1, #0x0                   	// #0
    a25c:	34000114 	cbz	w20, a27c <fwp_hof0.constprop.0+0x8cc>
    a260:	0b010340 	add	w0, w26, w1
    a264:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a268:	8b000e60 	add	x0, x19, x0, lsl #3
    a26c:	91000421 	add	x1, x1, #0x1
    a270:	f9000402 	str	x2, [x0, #8]
    a274:	eb01011f 	cmp	x8, x1
    a278:	54ffff41 	b.ne	a260 <fwp_hof0.constprop.0+0x8b0>  // b.any
    a27c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a280:	91174002 	add	x2, x0, #0x5d0
    a284:	f949d840 	ldr	x0, [x2, #5040]
    a288:	f949ec41 	ldr	x1, [x2, #5080]
    a28c:	cb000300 	sub	x0, x24, x0
    a290:	eb01401f 	cmp	x0, x1, lsl #16
    a294:	540002e2 	b.cs	a2f0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a298:	d350fc01 	lsr	x1, x0, #16
    a29c:	f949fc45 	ldr	x5, [x2, #5112]
    a2a0:	8b010821 	add	x1, x1, x1, lsl #2
    a2a4:	d37df021 	lsl	x1, x1, #3
    a2a8:	8b0100a3 	add	x3, x5, x1
    a2ac:	f9401062 	ldr	x2, [x3, #32]
    a2b0:	b4000202 	cbz	x2, a2f0 <fwp_hof0.constprop.0+0x940>
    a2b4:	386168a1 	ldrb	w1, [x5, x1]
    a2b8:	7100083f 	cmp	w1, #0x2
    a2bc:	540010a0 	b.eq	a4d0 <fwp_hof0.constprop.0+0xb20>  // b.none
    a2c0:	7100043f 	cmp	w1, #0x1
    a2c4:	54000161 	b.ne	a2f0 <fwp_hof0.constprop.0+0x940>  // b.any
    a2c8:	29430465 	ldp	w5, w1, [x3, #24]
    a2cc:	92403c00 	and	x0, x0, #0xffff
    a2d0:	9b057c00 	mul	x0, x0, x5
    a2d4:	d360fc00 	lsr	x0, x0, #32
    a2d8:	eb01001f 	cmp	x0, x1
    a2dc:	540000a2 	b.cs	a2f0 <fwp_hof0.constprop.0+0x940>  // b.hs, b.nlast
    a2e0:	8b000042 	add	x2, x2, x0
    a2e4:	39400040 	ldrb	w0, [x2]
    a2e8:	7100041f 	cmp	w0, #0x1
    a2ec:	54000c20 	b.eq	a470 <fwp_hof0.constprop.0+0xac0>  // b.none
    a2f0:	f9400c82 	ldr	x2, [x4, #24]
    a2f4:	aa1803e0 	mov	x0, x24
    a2f8:	52800021 	mov	w1, #0x1                   	// #1
    a2fc:	b81d83a6 	stur	w6, [x29, #-40]
    a300:	f9400442 	ldr	x2, [x2, #8]
    a304:	d63f0040 	blr	x2
    a308:	b85d83a6 	ldur	w6, [x29, #-40]
    a30c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a310:	91174002 	add	x2, x0, #0x5d0
    a314:	f949d841 	ldr	x1, [x2, #5040]
    a318:	f949ec40 	ldr	x0, [x2, #5080]
    a31c:	cb010261 	sub	x1, x19, x1
    a320:	eb00403f 	cmp	x1, x0, lsl #16
    a324:	54000322 	b.cs	a388 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a328:	d350fc20 	lsr	x0, x1, #16
    a32c:	f949fc43 	ldr	x3, [x2, #5112]
    a330:	8b000800 	add	x0, x0, x0, lsl #2
    a334:	d37df002 	lsl	x2, x0, #3
    a338:	8b020060 	add	x0, x3, x2
    a33c:	f9401014 	ldr	x20, [x0, #32]
    a340:	b4000254 	cbz	x20, a388 <fwp_hof0.constprop.0+0x9d8>
    a344:	38626862 	ldrb	w2, [x3, x2]
    a348:	7100085f 	cmp	w2, #0x2
    a34c:	54000c80 	b.eq	a4dc <fwp_hof0.constprop.0+0xb2c>  // b.none
    a350:	7100045f 	cmp	w2, #0x1
    a354:	540001a1 	b.ne	a388 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a358:	29430002 	ldp	w2, w0, [x0, #24]
    a35c:	92403c21 	and	x1, x1, #0xffff
    a360:	9b027c21 	mul	x1, x1, x2
    a364:	d360fc21 	lsr	x1, x1, #32
    a368:	eb00003f 	cmp	x1, x0
    a36c:	540000e2 	b.cs	a388 <fwp_hof0.constprop.0+0x9d8>  // b.hs, b.nlast
    a370:	8b010294 	add	x20, x20, x1
    a374:	39400280 	ldrb	w0, [x20]
    a378:	7103fc1f 	cmp	w0, #0xff
    a37c:	54000ba0 	b.eq	a4f0 <fwp_hof0.constprop.0+0xb40>  // b.none
    a380:	52800020 	mov	w0, #0x1                   	// #1
    a384:	39000280 	strb	w0, [x20]
    a388:	aa1803e0 	mov	x0, x24
    a38c:	b81d83a6 	stur	w6, [x29, #-40]
    a390:	97ffefc8 	bl	62b0 <fwp_closure_drop>
    a394:	aa1303f8 	mov	x24, x19
    a398:	b85d83a6 	ldur	w6, [x29, #-40]
    a39c:	17fffea7 	b	9e38 <fwp_hof0.constprop.0+0x488>
    a3a0:	b8626860 	ldr	w0, [x3, x2]
    a3a4:	b94004c2 	ldr	w2, [x6, #4]
    a3a8:	4b020003 	sub	w3, w0, w2
    a3ac:	7100047f 	cmp	w3, #0x1
    a3b0:	54ffb901 	b.ne	9ad0 <fwp_hof0.constprop.0+0x120>  // b.any
    a3b4:	910003f6 	mov	x22, sp
    a3b8:	34000c42 	cbz	w2, a540 <fwp_hof0.constprop.0+0xb90>
    a3bc:	7100001f 	cmp	w0, #0x0
    a3c0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a3c4:	d2800101 	mov	x1, #0x8                   	// #8
    a3c8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a3cc:	91003ee0 	add	x0, x23, #0xf
    a3d0:	92704c01 	and	x1, x0, #0xfffff0000
    a3d4:	927c7c00 	and	x0, x0, #0xffffffff0
    a3d8:	cb2163e1 	sub	x1, sp, x1
    a3dc:	eb2163ff 	cmp	sp, x1
    a3e0:	540000a0 	b.eq	a3f4 <fwp_hof0.constprop.0+0xa44>  // b.none
    a3e4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a3e8:	f90203ff 	str	xzr, [sp, #1024]
    a3ec:	eb2163ff 	cmp	sp, x1
    a3f0:	54ffffa1 	b.ne	a3e4 <fwp_hof0.constprop.0+0xa34>  // b.any
    a3f4:	92403c00 	and	x0, x0, #0xffff
    a3f8:	cb2063ff 	sub	sp, sp, x0
    a3fc:	f90003ff 	str	xzr, [sp]
    a400:	f110001f 	cmp	x0, #0x400
    a404:	54000043 	b.cc	a40c <fwp_hof0.constprop.0+0xa5c>  // b.lo, b.ul, b.last
    a408:	f90203ff 	str	xzr, [sp, #1024]
    a40c:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    a410:	910043fa 	add	x26, sp, #0x10
    a414:	d00000a0 	adrp	x0, 20000 <__data_start>
    a418:	91004001 	add	x1, x0, #0x10
    a41c:	aa1b03e2 	mov	x2, x27
    a420:	91012021 	add	x1, x1, #0x48
    a424:	aa1703e3 	mov	x3, x23
    a428:	aa1a03e0 	mov	x0, x26
    a42c:	f81d83a4 	stur	x4, [x29, #-40]
    a430:	97ffe0e8 	bl	27d0 <__memcpy_chk@plt>
    a434:	eb1b02ff 	cmp	x23, x27
    a438:	aa1403e1 	mov	x1, x20
    a43c:	9a9b22e3 	csel	x3, x23, x27, cs	// cs = hs, nlast
    a440:	d2800102 	mov	x2, #0x8                   	// #8
    a444:	cb1b0063 	sub	x3, x3, x27
    a448:	8b1b0340 	add	x0, x26, x27
    a44c:	97ffe0e1 	bl	27d0 <__memcpy_chk@plt>
    a450:	f85d83a4 	ldur	x4, [x29, #-40]
    a454:	aa1a03e0 	mov	x0, x26
    a458:	f9400c81 	ldr	x1, [x4, #24]
    a45c:	f9400021 	ldr	x1, [x1]
    a460:	d63f0020 	blr	x1
    a464:	aa0003f8 	mov	x24, x0
    a468:	910002df 	mov	sp, x22
    a46c:	17fffe93 	b	9eb8 <fwp_hof0.constprop.0+0x508>
    a470:	b900053f 	str	wzr, [x9, #4]
    a474:	17ffffa6 	b	a30c <fwp_hof0.constprop.0+0x95c>
    a478:	72003c3f 	tst	w1, #0xffff
    a47c:	54ffb6a1 	b.ne	9b50 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a480:	17fffdae 	b	9b38 <fwp_hof0.constprop.0+0x188>
    a484:	f9400593 	ldr	x19, [x12, #8]
    a488:	b4000113 	cbz	x19, a4a8 <fwp_hof0.constprop.0+0xaf8>
    a48c:	f9400982 	ldr	x2, [x12, #16]
    a490:	cb130042 	sub	x2, x2, x19
    a494:	eb02003f 	cmp	x1, x2
    a498:	54000088 	b.hi	a4a8 <fwp_hof0.constprop.0+0xaf8>  // b.pmore
    a49c:	8b010262 	add	x2, x19, x1
    a4a0:	f9000582 	str	x2, [x12, #8]
    a4a4:	17ffff48 	b	a1c4 <fwp_hof0.constprop.0+0x814>
    a4a8:	52800001 	mov	w1, #0x0                   	// #0
    a4ac:	b81bc3a6 	stur	w6, [x29, #-68]
    a4b0:	f81c03a4 	stur	x4, [x29, #-64]
    a4b4:	f81d83a9 	stur	x9, [x29, #-40]
    a4b8:	97ffea8e 	bl	4ef0 <fwp_heap_alloc>
    a4bc:	f85c03a4 	ldur	x4, [x29, #-64]
    a4c0:	aa0003f3 	mov	x19, x0
    a4c4:	f85d83a9 	ldur	x9, [x29, #-40]
    a4c8:	b85bc3a6 	ldur	w6, [x29, #-68]
    a4cc:	17ffff55 	b	a220 <fwp_hof0.constprop.0+0x870>
    a4d0:	72003c1f 	tst	w0, #0xffff
    a4d4:	54fff0e1 	b.ne	a2f0 <fwp_hof0.constprop.0+0x940>  // b.any
    a4d8:	17ffff83 	b	a2e4 <fwp_hof0.constprop.0+0x934>
    a4dc:	72003c3f 	tst	w1, #0xffff
    a4e0:	54fff541 	b.ne	a388 <fwp_hof0.constprop.0+0x9d8>  // b.any
    a4e4:	39400280 	ldrb	w0, [x20]
    a4e8:	7103fc1f 	cmp	w0, #0xff
    a4ec:	54fff4a1 	b.ne	a380 <fwp_hof0.constprop.0+0x9d0>  // b.any
    a4f0:	aa1403e0 	mov	x0, x20
    a4f4:	b81d83a6 	stur	w6, [x29, #-40]
    a4f8:	97ffe726 	bl	4190 <fwp_rc_forget_slot.part.0>
    a4fc:	b85d83a6 	ldur	w6, [x29, #-40]
    a500:	17ffffa0 	b	a380 <fwp_hof0.constprop.0+0x9d0>
    a504:	72003c5f 	tst	w2, #0xffff
    a508:	54ffac21 	b.ne	9a8c <fwp_hof0.constprop.0+0xdc>  // b.any
    a50c:	17fffd5a 	b	9a74 <fwp_hof0.constprop.0+0xc4>
    a510:	f81d83a4 	stur	x4, [x29, #-40]
    a514:	97ffe834 	bl	45e4 <fwp_rc_wide_dup>
    a518:	f85d83a4 	ldur	x4, [x29, #-40]
    a51c:	17fffd8d 	b	9b50 <fwp_hof0.constprop.0+0x1a0>
    a520:	aa1903e0 	mov	x0, x25
    a524:	97ffed7b 	bl	5b10 <fwp_rc_share>
    a528:	aa1803e0 	mov	x0, x24
    a52c:	52800037 	mov	w23, #0x1                   	// #1
    a530:	97ffed78 	bl	5b10 <fwp_rc_share>
    a534:	aa1903f8 	mov	x24, x25
    a538:	f81d03b4 	stur	x20, [x29, #-48]
    a53c:	17fffe5a 	b	9ea4 <fwp_hof0.constprop.0+0x4f4>
    a540:	f9400021 	ldr	x1, [x1]
    a544:	aa1403e0 	mov	x0, x20
    a548:	d63f0020 	blr	x1
    a54c:	aa0003f8 	mov	x24, x0
    a550:	910002df 	mov	sp, x22
    a554:	17fffe59 	b	9eb8 <fwp_hof0.constprop.0+0x508>
    a558:	97ffe823 	bl	45e4 <fwp_rc_wide_dup>
    a55c:	17fffd4c 	b	9a8c <fwp_hof0.constprop.0+0xdc>
    a560:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    a564:	91026000 	add	x0, x0, #0x98
    a568:	97ffe6ea 	bl	4110 <fwp_trap>
    a56c:	72003c5f 	tst	w2, #0xffff
    a570:	54ffd381 	b.ne	9fe0 <fwp_hof0.constprop.0+0x630>  // b.any
    a574:	17fffe91 	b	9fb8 <fwp_hof0.constprop.0+0x608>
    a578:	72003c3f 	tst	w1, #0xffff
    a57c:	54ffdcc1 	b.ne	a114 <fwp_hof0.constprop.0+0x764>  // b.any
    a580:	17fffedd 	b	a0f4 <fwp_hof0.constprop.0+0x744>
    a584:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a588:	91174000 	add	x0, x0, #0x5d0
    a58c:	f9400b78 	ldr	x24, [x27, #16]
    a590:	f949ec03 	ldr	x3, [x0, #5080]
    a594:	f949d801 	ldr	x1, [x0, #5040]
    a598:	d370bc63 	lsl	x3, x3, #16
    a59c:	cb010362 	sub	x2, x27, x1
    a5a0:	eb03005f 	cmp	x2, x3
    a5a4:	540003a2 	b.cs	a618 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a5a8:	d350fc44 	lsr	x4, x2, #16
    a5ac:	8b040884 	add	x4, x4, x4, lsl #2
    a5b0:	d37df084 	lsl	x4, x4, #3
    a5b4:	8b0400c0 	add	x0, x6, x4
    a5b8:	f9401005 	ldr	x5, [x0, #32]
    a5bc:	b40002e5 	cbz	x5, a618 <fwp_hof0.constprop.0+0xc68>
    a5c0:	386468c4 	ldrb	w4, [x6, x4]
    a5c4:	7100089f 	cmp	w4, #0x2
    a5c8:	540003a0 	b.eq	a63c <fwp_hof0.constprop.0+0xc8c>  // b.none
    a5cc:	7100049f 	cmp	w4, #0x1
    a5d0:	54000241 	b.ne	a618 <fwp_hof0.constprop.0+0xc68>  // b.any
    a5d4:	29430004 	ldp	w4, w0, [x0, #24]
    a5d8:	92403c42 	and	x2, x2, #0xffff
    a5dc:	9b047c42 	mul	x2, x2, x4
    a5e0:	d360fc42 	lsr	x2, x2, #32
    a5e4:	eb00005f 	cmp	x2, x0
    a5e8:	54000182 	b.cs	a618 <fwp_hof0.constprop.0+0xc68>  // b.hs, b.nlast
    a5ec:	8b0200a5 	add	x5, x5, x2
    a5f0:	394000a0 	ldrb	w0, [x5]
    a5f4:	7100041f 	cmp	w0, #0x1
    a5f8:	54000101 	b.ne	a618 <fwp_hof0.constprop.0+0xc68>  // b.any
    a5fc:	aa1b03e0 	mov	x0, x27
    a600:	97ffe780 	bl	4400 <fwp_mem_free>
    a604:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a608:	91174000 	add	x0, x0, #0x5d0
    a60c:	f949ec03 	ldr	x3, [x0, #5080]
    a610:	f949d801 	ldr	x1, [x0, #5040]
    a614:	d370bc63 	lsl	x3, x3, #16
    a618:	cb010301 	sub	x1, x24, x1
    a61c:	eb03003f 	cmp	x1, x3
    a620:	54ffd202 	b.cs	a060 <fwp_hof0.constprop.0+0x6b0>  // b.hs, b.nlast
    a624:	aa1803fb 	mov	x27, x24
    a628:	17fffe73 	b	9ff4 <fwp_hof0.constprop.0+0x644>
    a62c:	72003c3f 	tst	w1, #0xffff
    a630:	54ffd181 	b.ne	a060 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a634:	17fffe83 	b	a040 <fwp_hof0.constprop.0+0x690>
    a638:	97ffe092 	bl	2880 <__stack_chk_fail@plt>
    a63c:	72003c5f 	tst	w2, #0xffff
    a640:	54fffec1 	b.ne	a618 <fwp_hof0.constprop.0+0xc68>  // b.any
    a644:	17ffffeb 	b	a5f0 <fwp_hof0.constprop.0+0xc40>
    a648:	ca584700 	eor	x0, x24, x24, lsr #17
    a64c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a650:	91174022 	add	x2, x1, #0x5d0
    a654:	ca402400 	eor	x0, x0, x0, lsr #9
    a658:	92401c00 	and	x0, x0, #0xff
    a65c:	910a2401 	add	x1, x0, #0x289
    a660:	8b000c40 	add	x0, x2, x0, lsl #3
    a664:	8b010c41 	add	x1, x2, x1, lsl #3
    a668:	f94a2400 	ldr	x0, [x0, #5192]
    a66c:	b50000a0 	cbnz	x0, a680 <fwp_hof0.constprop.0+0xcd0>
    a670:	14000034 	b	a740 <fwp_hof0.constprop.0+0xd90>
    a674:	91004001 	add	x1, x0, #0x10
    a678:	f9400800 	ldr	x0, [x0, #16]
    a67c:	b4000620 	cbz	x0, a740 <fwp_hof0.constprop.0+0xd90>
    a680:	f9400002 	ldr	x2, [x0]
    a684:	eb02031f 	cmp	x24, x2
    a688:	54ffff61 	b.ne	a674 <fwp_hof0.constprop.0+0xcc4>  // b.any
    a68c:	f9400021 	ldr	x1, [x1]
    a690:	f9400420 	ldr	x0, [x1, #8]
    a694:	d1000400 	sub	x0, x0, #0x1
    a698:	f9000420 	str	x0, [x1, #8]
    a69c:	f103f81f 	cmp	x0, #0xfe
    a6a0:	54ffce01 	b.ne	a060 <fwp_hof0.constprop.0+0x6b0>  // b.any
    a6a4:	39400300 	ldrb	w0, [x24]
    a6a8:	7103fc1f 	cmp	w0, #0xff
    a6ac:	54000500 	b.eq	a74c <fwp_hof0.constprop.0+0xd9c>  // b.none
    a6b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a6b4:	39000300 	strb	w0, [x24]
    a6b8:	17fffe6a 	b	a060 <fwp_hof0.constprop.0+0x6b0>
    a6bc:	aa1303e0 	mov	x0, x19
    a6c0:	97ffe750 	bl	4400 <fwp_mem_free>
    a6c4:	17fffe94 	b	a114 <fwp_hof0.constprop.0+0x764>
    a6c8:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a6cc:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a6d0:	91174022 	add	x2, x1, #0x5d0
    a6d4:	ca402400 	eor	x0, x0, x0, lsr #9
    a6d8:	92401c00 	and	x0, x0, #0xff
    a6dc:	910a2401 	add	x1, x0, #0x289
    a6e0:	8b000c40 	add	x0, x2, x0, lsl #3
    a6e4:	8b010c41 	add	x1, x2, x1, lsl #3
    a6e8:	f94a2400 	ldr	x0, [x0, #5192]
    a6ec:	b50000a0 	cbnz	x0, a700 <fwp_hof0.constprop.0+0xd50>
    a6f0:	14000014 	b	a740 <fwp_hof0.constprop.0+0xd90>
    a6f4:	91004001 	add	x1, x0, #0x10
    a6f8:	f9400800 	ldr	x0, [x0, #16]
    a6fc:	b4000220 	cbz	x0, a740 <fwp_hof0.constprop.0+0xd90>
    a700:	f9400002 	ldr	x2, [x0]
    a704:	eb16005f 	cmp	x2, x22
    a708:	54ffff61 	b.ne	a6f4 <fwp_hof0.constprop.0+0xd44>  // b.any
    a70c:	f9400021 	ldr	x1, [x1]
    a710:	f9400420 	ldr	x0, [x1, #8]
    a714:	d1000400 	sub	x0, x0, #0x1
    a718:	f9000420 	str	x0, [x1, #8]
    a71c:	f103f81f 	cmp	x0, #0xfe
    a720:	54ffcfa1 	b.ne	a114 <fwp_hof0.constprop.0+0x764>  // b.any
    a724:	394002c0 	ldrb	w0, [x22]
    a728:	7103fc1f 	cmp	w0, #0xff
    a72c:	540001c0 	b.eq	a764 <fwp_hof0.constprop.0+0xdb4>  // b.none
    a730:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a734:	390002c0 	strb	w0, [x22]
    a738:	17fffe77 	b	a114 <fwp_hof0.constprop.0+0x764>
    a73c:	97ffe23d 	bl	3030 <fwp_heap_oom>
    a740:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x220>
    a744:	9130e000 	add	x0, x0, #0xc38
    a748:	97ffe672 	bl	4110 <fwp_trap>
    a74c:	aa1803e0 	mov	x0, x24
    a750:	97ffe690 	bl	4190 <fwp_rc_forget_slot.part.0>
    a754:	17ffffd7 	b	a6b0 <fwp_hof0.constprop.0+0xd00>
    a758:	aa1803e0 	mov	x0, x24
    a75c:	97ffe68d 	bl	4190 <fwp_rc_forget_slot.part.0>
    a760:	17fffe19 	b	9fc4 <fwp_hof0.constprop.0+0x614>
    a764:	aa1603e0 	mov	x0, x22
    a768:	97ffe68a 	bl	4190 <fwp_rc_forget_slot.part.0>
    a76c:	17fffff1 	b	a730 <fwp_hof0.constprop.0+0xd80>

000000000000a770 <f0>:
    a770:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a774:	910003fd 	mov	x29, sp
    a778:	a90153f3 	stp	x19, x20, [sp, #16]
    a77c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a780:	a90363f7 	stp	x23, x24, [sp, #48]
    a784:	a9046bf9 	stp	x25, x26, [sp, #64]
    a788:	a90573fb 	stp	x27, x28, [sp, #80]
    a78c:	d121c3ff 	sub	sp, sp, #0x870
    a790:	f90203ff 	str	xzr, [sp, #1024]
    a794:	d00000a0 	adrp	x0, 20000 <__data_start>
    a798:	9101c003 	add	x3, x0, #0x70
    a79c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a7a0:	f947f400 	ldr	x0, [x0, #4072]
    a7a4:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a7a8:	f9418865 	ldr	x5, [x3, #784]
    a7ac:	f9400001 	ldr	x1, [x0]
    a7b0:	f90437e1 	str	x1, [sp, #2152]
    a7b4:	d2800001 	mov	x1, #0x0                   	// #0
    a7b8:	91174299 	add	x25, x20, #0x5d0
    a7bc:	912163f6 	add	x22, sp, #0x858
    a7c0:	910063e4 	add	x4, sp, #0x18
    a7c4:	9100c3e1 	add	x1, sp, #0x30
    a7c8:	f0ffffc0 	adrp	x0, 5000 <fwp_heap_alloc+0x110>
    a7cc:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a7d0:	913ec000 	add	x0, x0, #0xfb0
    a7d4:	913d4042 	add	x2, x2, #0xf50
    a7d8:	d2800013 	mov	x19, #0x0                   	// #0
    a7dc:	d280011a 	mov	x26, #0x8                   	// #8
    a7e0:	d2800015 	mov	x21, #0x0                   	// #0
    a7e4:	52800037 	mov	w23, #0x1                   	// #1
    a7e8:	f90007e4 	str	x4, [sp, #8]
    a7ec:	a9018be5 	stp	x5, x2, [sp, #24]
    a7f0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a7f4:	a90403ff 	stp	xzr, x0, [sp, #64]
    a7f8:	f9018864 	str	x4, [x3, #784]
    a7fc:	d503201f 	nop
    a800:	f100075b 	subs	x27, x26, #0x1
    a804:	aa1603e1 	mov	x1, x22
    a808:	da1f02b8 	sbc	x24, x21, xzr
    a80c:	52800020 	mov	w0, #0x1                   	// #1
    a810:	f9001ffb 	str	x27, [sp, #56]
    a814:	aa1b03fa 	mov	x26, x27
    a818:	f9042ffb 	str	x27, [sp, #2136]
    a81c:	aa1803f5 	mov	x21, x24
    a820:	f90433f3 	str	x19, [sp, #2144]
    a824:	97ffec73 	bl	59f0 <fwp_data.part.0.constprop.0>
    a828:	f949db22 	ldr	x2, [x25, #5040]
    a82c:	aa0003f3 	mov	x19, x0
    a830:	f949ef20 	ldr	x0, [x25, #5080]
    a834:	cb020262 	sub	x2, x19, x2
    a838:	eb00405f 	cmp	x2, x0, lsl #16
    a83c:	54000302 	b.cs	a89c <f0+0x12c>  // b.hs, b.nlast
    a840:	d350fc40 	lsr	x0, x2, #16
    a844:	f949ff25 	ldr	x5, [x25, #5112]
    a848:	8b000800 	add	x0, x0, x0, lsl #2
    a84c:	d37df001 	lsl	x1, x0, #3
    a850:	8b0100a0 	add	x0, x5, x1
    a854:	f940101c 	ldr	x28, [x0, #32]
    a858:	b400023c 	cbz	x28, a89c <f0+0x12c>
    a85c:	386168a1 	ldrb	w1, [x5, x1]
    a860:	7100083f 	cmp	w1, #0x2
    a864:	54010de0 	b.eq	ca20 <f0+0x22b0>  // b.none
    a868:	7100043f 	cmp	w1, #0x1
    a86c:	54000181 	b.ne	a89c <f0+0x12c>  // b.any
    a870:	29430001 	ldp	w1, w0, [x0, #24]
    a874:	92403c42 	and	x2, x2, #0xffff
    a878:	9b017c42 	mul	x2, x2, x1
    a87c:	d360fc42 	lsr	x2, x2, #32
    a880:	eb00005f 	cmp	x2, x0
    a884:	540000c2 	b.cs	a89c <f0+0x12c>  // b.hs, b.nlast
    a888:	8b02039c 	add	x28, x28, x2
    a88c:	39400380 	ldrb	w0, [x28]
    a890:	7103fc1f 	cmp	w0, #0xff
    a894:	54010c00 	b.eq	ca14 <f0+0x22a4>  // b.none
    a898:	39000397 	strb	w23, [x28]
    a89c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a8a0:	aa18037b 	orr	x27, x27, x24
    a8a4:	b5fffafb 	cbnz	x27, a800 <f0+0x90>
    a8a8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a8ac:	9101c018 	add	x24, x0, #0x70
    a8b0:	f94007e1 	ldr	x1, [sp, #8]
    a8b4:	f9001bff 	str	xzr, [sp, #48]
    a8b8:	f9418b00 	ldr	x0, [x24, #784]
    a8bc:	eb01001f 	cmp	x0, x1
    a8c0:	540128c1 	b.ne	cdd8 <f0+0x2668>  // b.any
    a8c4:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x5c0>
    a8c8:	910143e1 	add	x1, sp, #0x50
    a8cc:	f9400fe2 	ldr	x2, [sp, #24]
    a8d0:	52800020 	mov	w0, #0x1                   	// #1
    a8d4:	3dc20860 	ldr	q0, [x3, #2080]
    a8d8:	f9018b02 	str	x2, [x24, #784]
    a8dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a8e0:	3d8017e0 	str	q0, [sp, #80]
    a8e4:	97ffec43 	bl	59f0 <fwp_data.part.0.constprop.0>
    a8e8:	97ffecae 	bl	5ba0 <fwp_rc_fresh>
    a8ec:	9101a3e1 	add	x1, sp, #0x68
    a8f0:	aa0003e2 	mov	x2, x0
    a8f4:	52800020 	mov	w0, #0x1                   	// #1
    a8f8:	a9068bf5 	stp	x21, x2, [sp, #104]
    a8fc:	97ffec3d 	bl	59f0 <fwp_data.part.0.constprop.0>
    a900:	97ffeca8 	bl	5ba0 <fwp_rc_fresh>
    a904:	aa0003e2 	mov	x2, x0
    a908:	9101e3e1 	add	x1, sp, #0x78
    a90c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a910:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	a9078be3 	stp	x3, x2, [sp, #120]
    a91c:	97ffec35 	bl	59f0 <fwp_data.part.0.constprop.0>
    a920:	97ffeca0 	bl	5ba0 <fwp_rc_fresh>
    a924:	aa0003e2 	mov	x2, x0
    a928:	910223e1 	add	x1, sp, #0x88
    a92c:	52800020 	mov	w0, #0x1                   	// #1
    a930:	a9088bf5 	stp	x21, x2, [sp, #136]
    a934:	97ffec2f 	bl	59f0 <fwp_data.part.0.constprop.0>
    a938:	97ffec9a 	bl	5ba0 <fwp_rc_fresh>
    a93c:	aa0003e2 	mov	x2, x0
    a940:	910263e1 	add	x1, sp, #0x98
    a944:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a948:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a94c:	52800020 	mov	w0, #0x1                   	// #1
    a950:	a9098be3 	stp	x3, x2, [sp, #152]
    a954:	97ffec27 	bl	59f0 <fwp_data.part.0.constprop.0>
    a958:	97ffec92 	bl	5ba0 <fwp_rc_fresh>
    a95c:	aa0003e2 	mov	x2, x0
    a960:	9102a3e1 	add	x1, sp, #0xa8
    a964:	52800020 	mov	w0, #0x1                   	// #1
    a968:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a96c:	97ffec21 	bl	59f0 <fwp_data.part.0.constprop.0>
    a970:	97ffec8c 	bl	5ba0 <fwp_rc_fresh>
    a974:	aa0003e2 	mov	x2, x0
    a978:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a97c:	9102e3e1 	add	x1, sp, #0xb8
    a980:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a984:	52800020 	mov	w0, #0x1                   	// #1
    a988:	a90b8be3 	stp	x3, x2, [sp, #184]
    a98c:	97ffec19 	bl	59f0 <fwp_data.part.0.constprop.0>
    a990:	97ffec84 	bl	5ba0 <fwp_rc_fresh>
    a994:	aa0003e2 	mov	x2, x0
    a998:	910323e1 	add	x1, sp, #0xc8
    a99c:	52800020 	mov	w0, #0x1                   	// #1
    a9a0:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a9a4:	97ffec13 	bl	59f0 <fwp_data.part.0.constprop.0>
    a9a8:	91174283 	add	x3, x20, #0x5d0
    a9ac:	aa0003f5 	mov	x21, x0
    a9b0:	f949d861 	ldr	x1, [x3, #5040]
    a9b4:	f949ec60 	ldr	x0, [x3, #5080]
    a9b8:	cb0102a1 	sub	x1, x21, x1
    a9bc:	eb00403f 	cmp	x1, x0, lsl #16
    a9c0:	54000322 	b.cs	aa24 <f0+0x2b4>  // b.hs, b.nlast
    a9c4:	d350fc22 	lsr	x2, x1, #16
    a9c8:	f949fc63 	ldr	x3, [x3, #5112]
    a9cc:	8b020842 	add	x2, x2, x2, lsl #2
    a9d0:	d37df042 	lsl	x2, x2, #3
    a9d4:	8b020060 	add	x0, x3, x2
    a9d8:	f9401017 	ldr	x23, [x0, #32]
    a9dc:	b4000257 	cbz	x23, aa24 <f0+0x2b4>
    a9e0:	38626862 	ldrb	w2, [x3, x2]
    a9e4:	7100085f 	cmp	w2, #0x2
    a9e8:	54010220 	b.eq	ca2c <f0+0x22bc>  // b.none
    a9ec:	7100045f 	cmp	w2, #0x1
    a9f0:	540001a1 	b.ne	aa24 <f0+0x2b4>  // b.any
    a9f4:	29430002 	ldp	w2, w0, [x0, #24]
    a9f8:	92403c21 	and	x1, x1, #0xffff
    a9fc:	9b027c21 	mul	x1, x1, x2
    aa00:	d360fc21 	lsr	x1, x1, #32
    aa04:	eb00003f 	cmp	x1, x0
    aa08:	540000e2 	b.cs	aa24 <f0+0x2b4>  // b.hs, b.nlast
    aa0c:	8b0102f7 	add	x23, x23, x1
    aa10:	394002e0 	ldrb	w0, [x23]
    aa14:	7103fc1f 	cmp	w0, #0xff
    aa18:	54010fa0 	b.eq	cc0c <f0+0x249c>  // b.none
    aa1c:	52800020 	mov	w0, #0x1                   	// #1
    aa20:	390002e0 	strb	w0, [x23]
    aa24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa28:	910363e1 	add	x1, sp, #0xd8
    aa2c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa30:	52800020 	mov	w0, #0x1                   	// #1
    aa34:	a90dd7e2 	stp	x2, x21, [sp, #216]
    aa38:	97ffebee 	bl	59f0 <fwp_data.part.0.constprop.0>
    aa3c:	91174283 	add	x3, x20, #0x5d0
    aa40:	aa0003f7 	mov	x23, x0
    aa44:	f949d861 	ldr	x1, [x3, #5040]
    aa48:	f949ec60 	ldr	x0, [x3, #5080]
    aa4c:	cb0102e1 	sub	x1, x23, x1
    aa50:	eb00403f 	cmp	x1, x0, lsl #16
    aa54:	54000322 	b.cs	aab8 <f0+0x348>  // b.hs, b.nlast
    aa58:	d350fc22 	lsr	x2, x1, #16
    aa5c:	f949fc63 	ldr	x3, [x3, #5112]
    aa60:	8b020842 	add	x2, x2, x2, lsl #2
    aa64:	d37df042 	lsl	x2, x2, #3
    aa68:	8b020060 	add	x0, x3, x2
    aa6c:	f9401015 	ldr	x21, [x0, #32]
    aa70:	b4000255 	cbz	x21, aab8 <f0+0x348>
    aa74:	38626862 	ldrb	w2, [x3, x2]
    aa78:	7100085f 	cmp	w2, #0x2
    aa7c:	5400fe40 	b.eq	ca44 <f0+0x22d4>  // b.none
    aa80:	7100045f 	cmp	w2, #0x1
    aa84:	540001a1 	b.ne	aab8 <f0+0x348>  // b.any
    aa88:	29430002 	ldp	w2, w0, [x0, #24]
    aa8c:	92403c21 	and	x1, x1, #0xffff
    aa90:	9b027c21 	mul	x1, x1, x2
    aa94:	d360fc21 	lsr	x1, x1, #32
    aa98:	eb00003f 	cmp	x1, x0
    aa9c:	540000e2 	b.cs	aab8 <f0+0x348>  // b.hs, b.nlast
    aaa0:	8b0102b5 	add	x21, x21, x1
    aaa4:	394002a0 	ldrb	w0, [x21]
    aaa8:	7103fc1f 	cmp	w0, #0xff
    aaac:	54010b60 	b.eq	cc18 <f0+0x24a8>  // b.none
    aab0:	52800020 	mov	w0, #0x1                   	// #1
    aab4:	390002a0 	strb	w0, [x21]
    aab8:	9103a3e1 	add	x1, sp, #0xe8
    aabc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aac0:	52800020 	mov	w0, #0x1                   	// #1
    aac4:	a90edff5 	stp	x21, x23, [sp, #232]
    aac8:	97ffebca 	bl	59f0 <fwp_data.part.0.constprop.0>
    aacc:	97ffec35 	bl	5ba0 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	9103e3e1 	add	x1, sp, #0xf8
    aad8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aadc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aae0:	52800020 	mov	w0, #0x1                   	// #1
    aae4:	a90f8bf7 	stp	x23, x2, [sp, #248]
    aae8:	97ffebc2 	bl	59f0 <fwp_data.part.0.constprop.0>
    aaec:	97ffec2d 	bl	5ba0 <fwp_rc_fresh>
    aaf0:	aa0003e2 	mov	x2, x0
    aaf4:	910423e1 	add	x1, sp, #0x108
    aaf8:	52800020 	mov	w0, #0x1                   	// #1
    aafc:	a9108bf5 	stp	x21, x2, [sp, #264]
    ab00:	97ffebbc 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab04:	97ffec27 	bl	5ba0 <fwp_rc_fresh>
    ab08:	aa0003e2 	mov	x2, x0
    ab0c:	910463e1 	add	x1, sp, #0x118
    ab10:	52800020 	mov	w0, #0x1                   	// #1
    ab14:	a9118bf7 	stp	x23, x2, [sp, #280]
    ab18:	97ffebb6 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab1c:	97ffec21 	bl	5ba0 <fwp_rc_fresh>
    ab20:	aa0003e2 	mov	x2, x0
    ab24:	9104a3e1 	add	x1, sp, #0x128
    ab28:	52800020 	mov	w0, #0x1                   	// #1
    ab2c:	a9128bf5 	stp	x21, x2, [sp, #296]
    ab30:	97ffebb0 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab34:	97ffec1b 	bl	5ba0 <fwp_rc_fresh>
    ab38:	aa0003e2 	mov	x2, x0
    ab3c:	9104e3e1 	add	x1, sp, #0x138
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	a9138bf7 	stp	x23, x2, [sp, #312]
    ab48:	97ffebaa 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab4c:	97ffec15 	bl	5ba0 <fwp_rc_fresh>
    ab50:	aa0003e2 	mov	x2, x0
    ab54:	910523e1 	add	x1, sp, #0x148
    ab58:	52800020 	mov	w0, #0x1                   	// #1
    ab5c:	a9148bf5 	stp	x21, x2, [sp, #328]
    ab60:	97ffeba4 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab64:	97ffec0f 	bl	5ba0 <fwp_rc_fresh>
    ab68:	aa0003e2 	mov	x2, x0
    ab6c:	910563e1 	add	x1, sp, #0x158
    ab70:	52800020 	mov	w0, #0x1                   	// #1
    ab74:	a9158bf7 	stp	x23, x2, [sp, #344]
    ab78:	97ffeb9e 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab7c:	97ffec09 	bl	5ba0 <fwp_rc_fresh>
    ab80:	aa0003e2 	mov	x2, x0
    ab84:	9105a3e1 	add	x1, sp, #0x168
    ab88:	52800020 	mov	w0, #0x1                   	// #1
    ab8c:	a9168bf5 	stp	x21, x2, [sp, #360]
    ab90:	97ffeb98 	bl	59f0 <fwp_data.part.0.constprop.0>
    ab94:	91174283 	add	x3, x20, #0x5d0
    ab98:	aa0003f5 	mov	x21, x0
    ab9c:	f949d861 	ldr	x1, [x3, #5040]
    aba0:	f949ec60 	ldr	x0, [x3, #5080]
    aba4:	cb0102a1 	sub	x1, x21, x1
    aba8:	eb00403f 	cmp	x1, x0, lsl #16
    abac:	54000322 	b.cs	ac10 <f0+0x4a0>  // b.hs, b.nlast
    abb0:	d350fc22 	lsr	x2, x1, #16
    abb4:	f949fc63 	ldr	x3, [x3, #5112]
    abb8:	8b020842 	add	x2, x2, x2, lsl #2
    abbc:	d37df042 	lsl	x2, x2, #3
    abc0:	8b020060 	add	x0, x3, x2
    abc4:	f9401017 	ldr	x23, [x0, #32]
    abc8:	b4000257 	cbz	x23, ac10 <f0+0x4a0>
    abcc:	38626862 	ldrb	w2, [x3, x2]
    abd0:	7100085f 	cmp	w2, #0x2
    abd4:	5400f320 	b.eq	ca38 <f0+0x22c8>  // b.none
    abd8:	7100045f 	cmp	w2, #0x1
    abdc:	540001a1 	b.ne	ac10 <f0+0x4a0>  // b.any
    abe0:	29430002 	ldp	w2, w0, [x0, #24]
    abe4:	92403c21 	and	x1, x1, #0xffff
    abe8:	9b027c21 	mul	x1, x1, x2
    abec:	d360fc21 	lsr	x1, x1, #32
    abf0:	eb00003f 	cmp	x1, x0
    abf4:	540000e2 	b.cs	ac10 <f0+0x4a0>  // b.hs, b.nlast
    abf8:	8b0102f7 	add	x23, x23, x1
    abfc:	394002e0 	ldrb	w0, [x23]
    ac00:	7103fc1f 	cmp	w0, #0xff
    ac04:	54010100 	b.eq	cc24 <f0+0x24b4>  // b.none
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	390002e0 	strb	w0, [x23]
    ac10:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac14:	9105e3e1 	add	x1, sp, #0x178
    ac18:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ac1c:	52800020 	mov	w0, #0x1                   	// #1
    ac20:	a917d7e2 	stp	x2, x21, [sp, #376]
    ac24:	97ffeb73 	bl	59f0 <fwp_data.part.0.constprop.0>
    ac28:	91174283 	add	x3, x20, #0x5d0
    ac2c:	aa0003f5 	mov	x21, x0
    ac30:	f949d861 	ldr	x1, [x3, #5040]
    ac34:	f949ec60 	ldr	x0, [x3, #5080]
    ac38:	cb0102a1 	sub	x1, x21, x1
    ac3c:	eb00403f 	cmp	x1, x0, lsl #16
    ac40:	54000322 	b.cs	aca4 <f0+0x534>  // b.hs, b.nlast
    ac44:	d350fc22 	lsr	x2, x1, #16
    ac48:	f949fc63 	ldr	x3, [x3, #5112]
    ac4c:	8b020842 	add	x2, x2, x2, lsl #2
    ac50:	d37df042 	lsl	x2, x2, #3
    ac54:	8b020060 	add	x0, x3, x2
    ac58:	f9401017 	ldr	x23, [x0, #32]
    ac5c:	b4000257 	cbz	x23, aca4 <f0+0x534>
    ac60:	38626862 	ldrb	w2, [x3, x2]
    ac64:	7100085f 	cmp	w2, #0x2
    ac68:	5400efa0 	b.eq	ca5c <f0+0x22ec>  // b.none
    ac6c:	7100045f 	cmp	w2, #0x1
    ac70:	540001a1 	b.ne	aca4 <f0+0x534>  // b.any
    ac74:	29430002 	ldp	w2, w0, [x0, #24]
    ac78:	92403c21 	and	x1, x1, #0xffff
    ac7c:	9b027c21 	mul	x1, x1, x2
    ac80:	d360fc21 	lsr	x1, x1, #32
    ac84:	eb00003f 	cmp	x1, x0
    ac88:	540000e2 	b.cs	aca4 <f0+0x534>  // b.hs, b.nlast
    ac8c:	8b0102f7 	add	x23, x23, x1
    ac90:	394002e0 	ldrb	w0, [x23]
    ac94:	7103fc1f 	cmp	w0, #0xff
    ac98:	5400fcc0 	b.eq	cc30 <f0+0x24c0>  // b.none
    ac9c:	52800020 	mov	w0, #0x1                   	// #1
    aca0:	390002e0 	strb	w0, [x23]
    aca4:	910623e1 	add	x1, sp, #0x188
    aca8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acac:	52800020 	mov	w0, #0x1                   	// #1
    acb0:	a918d7e2 	stp	x2, x21, [sp, #392]
    acb4:	97ffeb4f 	bl	59f0 <fwp_data.part.0.constprop.0>
    acb8:	97ffebba 	bl	5ba0 <fwp_rc_fresh>
    acbc:	aa0003e2 	mov	x2, x0
    acc0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    acc4:	910663e1 	add	x1, sp, #0x198
    acc8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    accc:	52800020 	mov	w0, #0x1                   	// #1
    acd0:	a9198be3 	stp	x3, x2, [sp, #408]
    acd4:	97ffeb47 	bl	59f0 <fwp_data.part.0.constprop.0>
    acd8:	91174283 	add	x3, x20, #0x5d0
    acdc:	aa0003f5 	mov	x21, x0
    ace0:	f949d861 	ldr	x1, [x3, #5040]
    ace4:	f949ec60 	ldr	x0, [x3, #5080]
    ace8:	cb0102a1 	sub	x1, x21, x1
    acec:	eb00403f 	cmp	x1, x0, lsl #16
    acf0:	54000322 	b.cs	ad54 <f0+0x5e4>  // b.hs, b.nlast
    acf4:	d350fc22 	lsr	x2, x1, #16
    acf8:	f949fc63 	ldr	x3, [x3, #5112]
    acfc:	8b020842 	add	x2, x2, x2, lsl #2
    ad00:	d37df042 	lsl	x2, x2, #3
    ad04:	8b020060 	add	x0, x3, x2
    ad08:	f9401017 	ldr	x23, [x0, #32]
    ad0c:	b4000257 	cbz	x23, ad54 <f0+0x5e4>
    ad10:	38626862 	ldrb	w2, [x3, x2]
    ad14:	7100085f 	cmp	w2, #0x2
    ad18:	5400e9c0 	b.eq	ca50 <f0+0x22e0>  // b.none
    ad1c:	7100045f 	cmp	w2, #0x1
    ad20:	540001a1 	b.ne	ad54 <f0+0x5e4>  // b.any
    ad24:	29430002 	ldp	w2, w0, [x0, #24]
    ad28:	92403c21 	and	x1, x1, #0xffff
    ad2c:	9b027c21 	mul	x1, x1, x2
    ad30:	d360fc21 	lsr	x1, x1, #32
    ad34:	eb00003f 	cmp	x1, x0
    ad38:	540000e2 	b.cs	ad54 <f0+0x5e4>  // b.hs, b.nlast
    ad3c:	8b0102f7 	add	x23, x23, x1
    ad40:	394002e0 	ldrb	w0, [x23]
    ad44:	7103fc1f 	cmp	w0, #0xff
    ad48:	5400f7a0 	b.eq	cc3c <f0+0x24cc>  // b.none
    ad4c:	52800020 	mov	w0, #0x1                   	// #1
    ad50:	390002e0 	strb	w0, [x23]
    ad54:	9106a3e1 	add	x1, sp, #0x1a8
    ad58:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad5c:	52800020 	mov	w0, #0x1                   	// #1
    ad60:	a91ad7f7 	stp	x23, x21, [sp, #424]
    ad64:	97ffeb23 	bl	59f0 <fwp_data.part.0.constprop.0>
    ad68:	97ffeb8e 	bl	5ba0 <fwp_rc_fresh>
    ad6c:	aa0003e2 	mov	x2, x0
    ad70:	9106e3e1 	add	x1, sp, #0x1b8
    ad74:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ad78:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	a91b8bf5 	stp	x21, x2, [sp, #440]
    ad84:	97ffeb1b 	bl	59f0 <fwp_data.part.0.constprop.0>
    ad88:	97ffeb86 	bl	5ba0 <fwp_rc_fresh>
    ad8c:	aa0003e2 	mov	x2, x0
    ad90:	910723e1 	add	x1, sp, #0x1c8
    ad94:	52800020 	mov	w0, #0x1                   	// #1
    ad98:	a91c8bf7 	stp	x23, x2, [sp, #456]
    ad9c:	97ffeb15 	bl	59f0 <fwp_data.part.0.constprop.0>
    ada0:	97ffeb80 	bl	5ba0 <fwp_rc_fresh>
    ada4:	aa0003e2 	mov	x2, x0
    ada8:	910763e1 	add	x1, sp, #0x1d8
    adac:	52800020 	mov	w0, #0x1                   	// #1
    adb0:	a91d8bf5 	stp	x21, x2, [sp, #472]
    adb4:	97ffeb0f 	bl	59f0 <fwp_data.part.0.constprop.0>
    adb8:	91174283 	add	x3, x20, #0x5d0
    adbc:	aa0003f5 	mov	x21, x0
    adc0:	f949d861 	ldr	x1, [x3, #5040]
    adc4:	f949ec60 	ldr	x0, [x3, #5080]
    adc8:	cb0102a1 	sub	x1, x21, x1
    adcc:	eb00403f 	cmp	x1, x0, lsl #16
    add0:	54000322 	b.cs	ae34 <f0+0x6c4>  // b.hs, b.nlast
    add4:	d350fc22 	lsr	x2, x1, #16
    add8:	f949fc63 	ldr	x3, [x3, #5112]
    addc:	8b020842 	add	x2, x2, x2, lsl #2
    ade0:	d37df042 	lsl	x2, x2, #3
    ade4:	8b020060 	add	x0, x3, x2
    ade8:	f9401017 	ldr	x23, [x0, #32]
    adec:	b4000257 	cbz	x23, ae34 <f0+0x6c4>
    adf0:	38626862 	ldrb	w2, [x3, x2]
    adf4:	7100085f 	cmp	w2, #0x2
    adf8:	5400e3e0 	b.eq	ca74 <f0+0x2304>  // b.none
    adfc:	7100045f 	cmp	w2, #0x1
    ae00:	540001a1 	b.ne	ae34 <f0+0x6c4>  // b.any
    ae04:	29430002 	ldp	w2, w0, [x0, #24]
    ae08:	92403c21 	and	x1, x1, #0xffff
    ae0c:	9b027c21 	mul	x1, x1, x2
    ae10:	d360fc21 	lsr	x1, x1, #32
    ae14:	eb00003f 	cmp	x1, x0
    ae18:	540000e2 	b.cs	ae34 <f0+0x6c4>  // b.hs, b.nlast
    ae1c:	8b0102f7 	add	x23, x23, x1
    ae20:	394002e0 	ldrb	w0, [x23]
    ae24:	7103fc1f 	cmp	w0, #0xff
    ae28:	5400f100 	b.eq	cc48 <f0+0x24d8>  // b.none
    ae2c:	52800020 	mov	w0, #0x1                   	// #1
    ae30:	390002e0 	strb	w0, [x23]
    ae34:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae38:	9107a3e1 	add	x1, sp, #0x1e8
    ae3c:	52800020 	mov	w0, #0x1                   	// #1
    ae40:	a91ed7e2 	stp	x2, x21, [sp, #488]
    ae44:	97ffeaeb 	bl	59f0 <fwp_data.part.0.constprop.0>
    ae48:	91174283 	add	x3, x20, #0x5d0
    ae4c:	aa0003f5 	mov	x21, x0
    ae50:	f949d861 	ldr	x1, [x3, #5040]
    ae54:	f949ec60 	ldr	x0, [x3, #5080]
    ae58:	cb0102a1 	sub	x1, x21, x1
    ae5c:	eb00403f 	cmp	x1, x0, lsl #16
    ae60:	54000322 	b.cs	aec4 <f0+0x754>  // b.hs, b.nlast
    ae64:	d350fc22 	lsr	x2, x1, #16
    ae68:	f949fc63 	ldr	x3, [x3, #5112]
    ae6c:	8b020842 	add	x2, x2, x2, lsl #2
    ae70:	d37df042 	lsl	x2, x2, #3
    ae74:	8b020060 	add	x0, x3, x2
    ae78:	f9401017 	ldr	x23, [x0, #32]
    ae7c:	b4000257 	cbz	x23, aec4 <f0+0x754>
    ae80:	38626862 	ldrb	w2, [x3, x2]
    ae84:	7100085f 	cmp	w2, #0x2
    ae88:	5400df00 	b.eq	ca68 <f0+0x22f8>  // b.none
    ae8c:	7100045f 	cmp	w2, #0x1
    ae90:	540001a1 	b.ne	aec4 <f0+0x754>  // b.any
    ae94:	29430002 	ldp	w2, w0, [x0, #24]
    ae98:	92403c21 	and	x1, x1, #0xffff
    ae9c:	9b027c21 	mul	x1, x1, x2
    aea0:	d360fc21 	lsr	x1, x1, #32
    aea4:	eb00003f 	cmp	x1, x0
    aea8:	540000e2 	b.cs	aec4 <f0+0x754>  // b.hs, b.nlast
    aeac:	8b0102f7 	add	x23, x23, x1
    aeb0:	394002e0 	ldrb	w0, [x23]
    aeb4:	7103fc1f 	cmp	w0, #0xff
    aeb8:	5400ece0 	b.eq	cc54 <f0+0x24e4>  // b.none
    aebc:	52800020 	mov	w0, #0x1                   	// #1
    aec0:	390002e0 	strb	w0, [x23]
    aec4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aec8:	9107e3e1 	add	x1, sp, #0x1f8
    aecc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aed0:	52800020 	mov	w0, #0x1                   	// #1
    aed4:	a91fd7e2 	stp	x2, x21, [sp, #504]
    aed8:	97ffeac6 	bl	59f0 <fwp_data.part.0.constprop.0>
    aedc:	91174283 	add	x3, x20, #0x5d0
    aee0:	aa0003f5 	mov	x21, x0
    aee4:	f949d861 	ldr	x1, [x3, #5040]
    aee8:	f949ec60 	ldr	x0, [x3, #5080]
    aeec:	cb0102a1 	sub	x1, x21, x1
    aef0:	eb00403f 	cmp	x1, x0, lsl #16
    aef4:	54000322 	b.cs	af58 <f0+0x7e8>  // b.hs, b.nlast
    aef8:	d350fc22 	lsr	x2, x1, #16
    aefc:	f949fc63 	ldr	x3, [x3, #5112]
    af00:	8b020842 	add	x2, x2, x2, lsl #2
    af04:	d37df042 	lsl	x2, x2, #3
    af08:	8b020060 	add	x0, x3, x2
    af0c:	f9401017 	ldr	x23, [x0, #32]
    af10:	b4000257 	cbz	x23, af58 <f0+0x7e8>
    af14:	38626862 	ldrb	w2, [x3, x2]
    af18:	7100085f 	cmp	w2, #0x2
    af1c:	5400e180 	b.eq	cb4c <f0+0x23dc>  // b.none
    af20:	7100045f 	cmp	w2, #0x1
    af24:	540001a1 	b.ne	af58 <f0+0x7e8>  // b.any
    af28:	29430002 	ldp	w2, w0, [x0, #24]
    af2c:	92403c21 	and	x1, x1, #0xffff
    af30:	9b027c21 	mul	x1, x1, x2
    af34:	d360fc21 	lsr	x1, x1, #32
    af38:	eb00003f 	cmp	x1, x0
    af3c:	540000e2 	b.cs	af58 <f0+0x7e8>  // b.hs, b.nlast
    af40:	8b0102f7 	add	x23, x23, x1
    af44:	394002e0 	ldrb	w0, [x23]
    af48:	7103fc1f 	cmp	w0, #0xff
    af4c:	5400e8a0 	b.eq	cc60 <f0+0x24f0>  // b.none
    af50:	52800020 	mov	w0, #0x1                   	// #1
    af54:	390002e0 	strb	w0, [x23]
    af58:	910823e1 	add	x1, sp, #0x208
    af5c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	f90107f7 	str	x23, [sp, #520]
    af68:	f9010bf5 	str	x21, [sp, #528]
    af6c:	97ffeaa1 	bl	59f0 <fwp_data.part.0.constprop.0>
    af70:	97ffeb0c 	bl	5ba0 <fwp_rc_fresh>
    af74:	aa0003e2 	mov	x2, x0
    af78:	910863e1 	add	x1, sp, #0x218
    af7c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    af80:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af84:	52800020 	mov	w0, #0x1                   	// #1
    af88:	f9010ff5 	str	x21, [sp, #536]
    af8c:	f90113e2 	str	x2, [sp, #544]
    af90:	97ffea98 	bl	59f0 <fwp_data.part.0.constprop.0>
    af94:	97ffeb03 	bl	5ba0 <fwp_rc_fresh>
    af98:	aa0003e2 	mov	x2, x0
    af9c:	9108a3e1 	add	x1, sp, #0x228
    afa0:	52800020 	mov	w0, #0x1                   	// #1
    afa4:	f90117f7 	str	x23, [sp, #552]
    afa8:	f9011be2 	str	x2, [sp, #560]
    afac:	97ffea91 	bl	59f0 <fwp_data.part.0.constprop.0>
    afb0:	97ffeafc 	bl	5ba0 <fwp_rc_fresh>
    afb4:	aa0003e2 	mov	x2, x0
    afb8:	9108e3e1 	add	x1, sp, #0x238
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	f9011ff5 	str	x21, [sp, #568]
    afc4:	f90123e2 	str	x2, [sp, #576]
    afc8:	97ffea8a 	bl	59f0 <fwp_data.part.0.constprop.0>
    afcc:	97ffeaf5 	bl	5ba0 <fwp_rc_fresh>
    afd0:	aa0003e2 	mov	x2, x0
    afd4:	910923e1 	add	x1, sp, #0x248
    afd8:	52800020 	mov	w0, #0x1                   	// #1
    afdc:	f90127f7 	str	x23, [sp, #584]
    afe0:	f9012be2 	str	x2, [sp, #592]
    afe4:	97ffea83 	bl	59f0 <fwp_data.part.0.constprop.0>
    afe8:	97ffeaee 	bl	5ba0 <fwp_rc_fresh>
    afec:	aa0003e2 	mov	x2, x0
    aff0:	910963e1 	add	x1, sp, #0x258
    aff4:	52800020 	mov	w0, #0x1                   	// #1
    aff8:	f9012ff5 	str	x21, [sp, #600]
    affc:	f90133e2 	str	x2, [sp, #608]
    b000:	97ffea7c 	bl	59f0 <fwp_data.part.0.constprop.0>
    b004:	91174283 	add	x3, x20, #0x5d0
    b008:	aa0003f5 	mov	x21, x0
    b00c:	f949d861 	ldr	x1, [x3, #5040]
    b010:	f949ec60 	ldr	x0, [x3, #5080]
    b014:	cb0102a1 	sub	x1, x21, x1
    b018:	eb00403f 	cmp	x1, x0, lsl #16
    b01c:	54000322 	b.cs	b080 <f0+0x910>  // b.hs, b.nlast
    b020:	d350fc22 	lsr	x2, x1, #16
    b024:	f949fc63 	ldr	x3, [x3, #5112]
    b028:	8b020842 	add	x2, x2, x2, lsl #2
    b02c:	d37df042 	lsl	x2, x2, #3
    b030:	8b020060 	add	x0, x3, x2
    b034:	f9401017 	ldr	x23, [x0, #32]
    b038:	b4000257 	cbz	x23, b080 <f0+0x910>
    b03c:	38626862 	ldrb	w2, [x3, x2]
    b040:	7100085f 	cmp	w2, #0x2
    b044:	5400d7e0 	b.eq	cb40 <f0+0x23d0>  // b.none
    b048:	7100045f 	cmp	w2, #0x1
    b04c:	540001a1 	b.ne	b080 <f0+0x910>  // b.any
    b050:	29430002 	ldp	w2, w0, [x0, #24]
    b054:	92403c21 	and	x1, x1, #0xffff
    b058:	9b027c21 	mul	x1, x1, x2
    b05c:	d360fc21 	lsr	x1, x1, #32
    b060:	eb00003f 	cmp	x1, x0
    b064:	540000e2 	b.cs	b080 <f0+0x910>  // b.hs, b.nlast
    b068:	8b0102f7 	add	x23, x23, x1
    b06c:	394002e0 	ldrb	w0, [x23]
    b070:	7103fc1f 	cmp	w0, #0xff
    b074:	5400dfc0 	b.eq	cc6c <f0+0x24fc>  // b.none
    b078:	52800020 	mov	w0, #0x1                   	// #1
    b07c:	390002e0 	strb	w0, [x23]
    b080:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b084:	9109a3e1 	add	x1, sp, #0x268
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	f90137e2 	str	x2, [sp, #616]
    b090:	f9013bf5 	str	x21, [sp, #624]
    b094:	97ffea57 	bl	59f0 <fwp_data.part.0.constprop.0>
    b098:	91174283 	add	x3, x20, #0x5d0
    b09c:	aa0003f5 	mov	x21, x0
    b0a0:	f949d861 	ldr	x1, [x3, #5040]
    b0a4:	f949ec60 	ldr	x0, [x3, #5080]
    b0a8:	cb0102a1 	sub	x1, x21, x1
    b0ac:	eb00403f 	cmp	x1, x0, lsl #16
    b0b0:	54000322 	b.cs	b114 <f0+0x9a4>  // b.hs, b.nlast
    b0b4:	d350fc22 	lsr	x2, x1, #16
    b0b8:	f949fc63 	ldr	x3, [x3, #5112]
    b0bc:	8b020842 	add	x2, x2, x2, lsl #2
    b0c0:	d37df042 	lsl	x2, x2, #3
    b0c4:	8b020060 	add	x0, x3, x2
    b0c8:	f9401017 	ldr	x23, [x0, #32]
    b0cc:	b4000257 	cbz	x23, b114 <f0+0x9a4>
    b0d0:	38626862 	ldrb	w2, [x3, x2]
    b0d4:	7100085f 	cmp	w2, #0x2
    b0d8:	5400d460 	b.eq	cb64 <f0+0x23f4>  // b.none
    b0dc:	7100045f 	cmp	w2, #0x1
    b0e0:	540001a1 	b.ne	b114 <f0+0x9a4>  // b.any
    b0e4:	29430002 	ldp	w2, w0, [x0, #24]
    b0e8:	92403c21 	and	x1, x1, #0xffff
    b0ec:	9b027c21 	mul	x1, x1, x2
    b0f0:	d360fc21 	lsr	x1, x1, #32
    b0f4:	eb00003f 	cmp	x1, x0
    b0f8:	540000e2 	b.cs	b114 <f0+0x9a4>  // b.hs, b.nlast
    b0fc:	8b0102f7 	add	x23, x23, x1
    b100:	394002e0 	ldrb	w0, [x23]
    b104:	7103fc1f 	cmp	w0, #0xff
    b108:	5400db80 	b.eq	cc78 <f0+0x2508>  // b.none
    b10c:	52800020 	mov	w0, #0x1                   	// #1
    b110:	390002e0 	strb	w0, [x23]
    b114:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b118:	9109e3e1 	add	x1, sp, #0x278
    b11c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b120:	52800020 	mov	w0, #0x1                   	// #1
    b124:	f9013fe2 	str	x2, [sp, #632]
    b128:	f90143f5 	str	x21, [sp, #640]
    b12c:	97ffea31 	bl	59f0 <fwp_data.part.0.constprop.0>
    b130:	91174283 	add	x3, x20, #0x5d0
    b134:	aa0003f5 	mov	x21, x0
    b138:	f949d861 	ldr	x1, [x3, #5040]
    b13c:	f949ec60 	ldr	x0, [x3, #5080]
    b140:	cb0102a1 	sub	x1, x21, x1
    b144:	eb00403f 	cmp	x1, x0, lsl #16
    b148:	54000322 	b.cs	b1ac <f0+0xa3c>  // b.hs, b.nlast
    b14c:	d350fc22 	lsr	x2, x1, #16
    b150:	f949fc63 	ldr	x3, [x3, #5112]
    b154:	8b020842 	add	x2, x2, x2, lsl #2
    b158:	d37df042 	lsl	x2, x2, #3
    b15c:	8b020060 	add	x0, x3, x2
    b160:	f9401017 	ldr	x23, [x0, #32]
    b164:	b4000257 	cbz	x23, b1ac <f0+0xa3c>
    b168:	38626862 	ldrb	w2, [x3, x2]
    b16c:	7100085f 	cmp	w2, #0x2
    b170:	5400cf40 	b.eq	cb58 <f0+0x23e8>  // b.none
    b174:	7100045f 	cmp	w2, #0x1
    b178:	540001a1 	b.ne	b1ac <f0+0xa3c>  // b.any
    b17c:	29430002 	ldp	w2, w0, [x0, #24]
    b180:	92403c21 	and	x1, x1, #0xffff
    b184:	9b027c21 	mul	x1, x1, x2
    b188:	d360fc21 	lsr	x1, x1, #32
    b18c:	eb00003f 	cmp	x1, x0
    b190:	540000e2 	b.cs	b1ac <f0+0xa3c>  // b.hs, b.nlast
    b194:	8b0102f7 	add	x23, x23, x1
    b198:	394002e0 	ldrb	w0, [x23]
    b19c:	7103fc1f 	cmp	w0, #0xff
    b1a0:	5400d720 	b.eq	cc84 <f0+0x2514>  // b.none
    b1a4:	52800020 	mov	w0, #0x1                   	// #1
    b1a8:	390002e0 	strb	w0, [x23]
    b1ac:	910a23e1 	add	x1, sp, #0x288
    b1b0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1b4:	52800020 	mov	w0, #0x1                   	// #1
    b1b8:	f90147e2 	str	x2, [sp, #648]
    b1bc:	f9014bf5 	str	x21, [sp, #656]
    b1c0:	97ffea0c 	bl	59f0 <fwp_data.part.0.constprop.0>
    b1c4:	97ffea77 	bl	5ba0 <fwp_rc_fresh>
    b1c8:	aa0003e2 	mov	x2, x0
    b1cc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b1d0:	910a63e1 	add	x1, sp, #0x298
    b1d4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b1d8:	52800020 	mov	w0, #0x1                   	// #1
    b1dc:	f9014fe3 	str	x3, [sp, #664]
    b1e0:	f90153e2 	str	x2, [sp, #672]
    b1e4:	97ffea03 	bl	59f0 <fwp_data.part.0.constprop.0>
    b1e8:	91174283 	add	x3, x20, #0x5d0
    b1ec:	aa0003f5 	mov	x21, x0
    b1f0:	f949d861 	ldr	x1, [x3, #5040]
    b1f4:	f949ec60 	ldr	x0, [x3, #5080]
    b1f8:	cb0102a1 	sub	x1, x21, x1
    b1fc:	eb00403f 	cmp	x1, x0, lsl #16
    b200:	54000322 	b.cs	b264 <f0+0xaf4>  // b.hs, b.nlast
    b204:	d350fc22 	lsr	x2, x1, #16
    b208:	f949fc63 	ldr	x3, [x3, #5112]
    b20c:	8b020842 	add	x2, x2, x2, lsl #2
    b210:	d37df042 	lsl	x2, x2, #3
    b214:	8b020060 	add	x0, x3, x2
    b218:	f9401017 	ldr	x23, [x0, #32]
    b21c:	b4000257 	cbz	x23, b264 <f0+0xaf4>
    b220:	38626862 	ldrb	w2, [x3, x2]
    b224:	7100085f 	cmp	w2, #0x2
    b228:	5400caa0 	b.eq	cb7c <f0+0x240c>  // b.none
    b22c:	7100045f 	cmp	w2, #0x1
    b230:	540001a1 	b.ne	b264 <f0+0xaf4>  // b.any
    b234:	29430002 	ldp	w2, w0, [x0, #24]
    b238:	92403c21 	and	x1, x1, #0xffff
    b23c:	9b027c21 	mul	x1, x1, x2
    b240:	d360fc21 	lsr	x1, x1, #32
    b244:	eb00003f 	cmp	x1, x0
    b248:	540000e2 	b.cs	b264 <f0+0xaf4>  // b.hs, b.nlast
    b24c:	8b0102f7 	add	x23, x23, x1
    b250:	394002e0 	ldrb	w0, [x23]
    b254:	7103fc1f 	cmp	w0, #0xff
    b258:	5400d1c0 	b.eq	cc90 <f0+0x2520>  // b.none
    b25c:	52800020 	mov	w0, #0x1                   	// #1
    b260:	390002e0 	strb	w0, [x23]
    b264:	910aa3e1 	add	x1, sp, #0x2a8
    b268:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b26c:	52800020 	mov	w0, #0x1                   	// #1
    b270:	f90157f7 	str	x23, [sp, #680]
    b274:	f9015bf5 	str	x21, [sp, #688]
    b278:	97ffe9de 	bl	59f0 <fwp_data.part.0.constprop.0>
    b27c:	97ffea49 	bl	5ba0 <fwp_rc_fresh>
    b280:	aa0003e2 	mov	x2, x0
    b284:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b288:	910ae3e1 	add	x1, sp, #0x2b8
    b28c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b290:	52800020 	mov	w0, #0x1                   	// #1
    b294:	f9015fe3 	str	x3, [sp, #696]
    b298:	f90163e2 	str	x2, [sp, #704]
    b29c:	97ffe9d5 	bl	59f0 <fwp_data.part.0.constprop.0>
    b2a0:	97ffea40 	bl	5ba0 <fwp_rc_fresh>
    b2a4:	aa0003e2 	mov	x2, x0
    b2a8:	910b23e1 	add	x1, sp, #0x2c8
    b2ac:	52800020 	mov	w0, #0x1                   	// #1
    b2b0:	f90167f7 	str	x23, [sp, #712]
    b2b4:	f9016be2 	str	x2, [sp, #720]
    b2b8:	97ffe9ce 	bl	59f0 <fwp_data.part.0.constprop.0>
    b2bc:	91174283 	add	x3, x20, #0x5d0
    b2c0:	aa0003f5 	mov	x21, x0
    b2c4:	f949d861 	ldr	x1, [x3, #5040]
    b2c8:	f949ec60 	ldr	x0, [x3, #5080]
    b2cc:	cb0102a1 	sub	x1, x21, x1
    b2d0:	eb00403f 	cmp	x1, x0, lsl #16
    b2d4:	54000322 	b.cs	b338 <f0+0xbc8>  // b.hs, b.nlast
    b2d8:	d350fc22 	lsr	x2, x1, #16
    b2dc:	f949fc63 	ldr	x3, [x3, #5112]
    b2e0:	8b020842 	add	x2, x2, x2, lsl #2
    b2e4:	d37df042 	lsl	x2, x2, #3
    b2e8:	8b020060 	add	x0, x3, x2
    b2ec:	f9401017 	ldr	x23, [x0, #32]
    b2f0:	b4000257 	cbz	x23, b338 <f0+0xbc8>
    b2f4:	38626862 	ldrb	w2, [x3, x2]
    b2f8:	7100085f 	cmp	w2, #0x2
    b2fc:	5400c3a0 	b.eq	cb70 <f0+0x2400>  // b.none
    b300:	7100045f 	cmp	w2, #0x1
    b304:	540001a1 	b.ne	b338 <f0+0xbc8>  // b.any
    b308:	29430002 	ldp	w2, w0, [x0, #24]
    b30c:	92403c21 	and	x1, x1, #0xffff
    b310:	9b027c21 	mul	x1, x1, x2
    b314:	d360fc21 	lsr	x1, x1, #32
    b318:	eb00003f 	cmp	x1, x0
    b31c:	540000e2 	b.cs	b338 <f0+0xbc8>  // b.hs, b.nlast
    b320:	8b0102f7 	add	x23, x23, x1
    b324:	394002e0 	ldrb	w0, [x23]
    b328:	7103fc1f 	cmp	w0, #0xff
    b32c:	5400cb80 	b.eq	cc9c <f0+0x252c>  // b.none
    b330:	52800020 	mov	w0, #0x1                   	// #1
    b334:	390002e0 	strb	w0, [x23]
    b338:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b33c:	910b63e1 	add	x1, sp, #0x2d8
    b340:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	f9016fe2 	str	x2, [sp, #728]
    b34c:	f90173f5 	str	x21, [sp, #736]
    b350:	97ffe9a8 	bl	59f0 <fwp_data.part.0.constprop.0>
    b354:	91174283 	add	x3, x20, #0x5d0
    b358:	aa0003f5 	mov	x21, x0
    b35c:	f949d861 	ldr	x1, [x3, #5040]
    b360:	f949ec60 	ldr	x0, [x3, #5080]
    b364:	cb0102a1 	sub	x1, x21, x1
    b368:	eb00403f 	cmp	x1, x0, lsl #16
    b36c:	54000322 	b.cs	b3d0 <f0+0xc60>  // b.hs, b.nlast
    b370:	d350fc22 	lsr	x2, x1, #16
    b374:	f949fc63 	ldr	x3, [x3, #5112]
    b378:	8b020842 	add	x2, x2, x2, lsl #2
    b37c:	d37df042 	lsl	x2, x2, #3
    b380:	8b020060 	add	x0, x3, x2
    b384:	f9401017 	ldr	x23, [x0, #32]
    b388:	b4000257 	cbz	x23, b3d0 <f0+0xc60>
    b38c:	38626862 	ldrb	w2, [x3, x2]
    b390:	7100085f 	cmp	w2, #0x2
    b394:	5400c000 	b.eq	cb94 <f0+0x2424>  // b.none
    b398:	7100045f 	cmp	w2, #0x1
    b39c:	540001a1 	b.ne	b3d0 <f0+0xc60>  // b.any
    b3a0:	29430002 	ldp	w2, w0, [x0, #24]
    b3a4:	92403c21 	and	x1, x1, #0xffff
    b3a8:	9b027c21 	mul	x1, x1, x2
    b3ac:	d360fc21 	lsr	x1, x1, #32
    b3b0:	eb00003f 	cmp	x1, x0
    b3b4:	540000e2 	b.cs	b3d0 <f0+0xc60>  // b.hs, b.nlast
    b3b8:	8b0102f7 	add	x23, x23, x1
    b3bc:	394002e0 	ldrb	w0, [x23]
    b3c0:	7103fc1f 	cmp	w0, #0xff
    b3c4:	5400c720 	b.eq	cca8 <f0+0x2538>  // b.none
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	390002e0 	strb	w0, [x23]
    b3d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b3d4:	910ba3e1 	add	x1, sp, #0x2e8
    b3d8:	52800020 	mov	w0, #0x1                   	// #1
    b3dc:	f90177e2 	str	x2, [sp, #744]
    b3e0:	f9017bf5 	str	x21, [sp, #752]
    b3e4:	97ffe983 	bl	59f0 <fwp_data.part.0.constprop.0>
    b3e8:	91174283 	add	x3, x20, #0x5d0
    b3ec:	aa0003f7 	mov	x23, x0
    b3f0:	f949d861 	ldr	x1, [x3, #5040]
    b3f4:	f949ec60 	ldr	x0, [x3, #5080]
    b3f8:	cb0102e1 	sub	x1, x23, x1
    b3fc:	eb00403f 	cmp	x1, x0, lsl #16
    b400:	54000322 	b.cs	b464 <f0+0xcf4>  // b.hs, b.nlast
    b404:	d350fc22 	lsr	x2, x1, #16
    b408:	f949fc63 	ldr	x3, [x3, #5112]
    b40c:	8b020842 	add	x2, x2, x2, lsl #2
    b410:	d37df042 	lsl	x2, x2, #3
    b414:	8b020060 	add	x0, x3, x2
    b418:	f9401015 	ldr	x21, [x0, #32]
    b41c:	b4000255 	cbz	x21, b464 <f0+0xcf4>
    b420:	38626862 	ldrb	w2, [x3, x2]
    b424:	7100085f 	cmp	w2, #0x2
    b428:	5400bb00 	b.eq	cb88 <f0+0x2418>  // b.none
    b42c:	7100045f 	cmp	w2, #0x1
    b430:	540001a1 	b.ne	b464 <f0+0xcf4>  // b.any
    b434:	29430002 	ldp	w2, w0, [x0, #24]
    b438:	92403c21 	and	x1, x1, #0xffff
    b43c:	9b027c21 	mul	x1, x1, x2
    b440:	d360fc21 	lsr	x1, x1, #32
    b444:	eb00003f 	cmp	x1, x0
    b448:	540000e2 	b.cs	b464 <f0+0xcf4>  // b.hs, b.nlast
    b44c:	8b0102b5 	add	x21, x21, x1
    b450:	394002a0 	ldrb	w0, [x21]
    b454:	7103fc1f 	cmp	w0, #0xff
    b458:	5400c2e0 	b.eq	ccb4 <f0+0x2544>  // b.none
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	390002a0 	strb	w0, [x21]
    b464:	910be3e1 	add	x1, sp, #0x2f8
    b468:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b46c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b470:	52800020 	mov	w0, #0x1                   	// #1
    b474:	f9017ff5 	str	x21, [sp, #760]
    b478:	f90183f7 	str	x23, [sp, #768]
    b47c:	97ffe95d 	bl	59f0 <fwp_data.part.0.constprop.0>
    b480:	97ffe9c8 	bl	5ba0 <fwp_rc_fresh>
    b484:	aa0003e2 	mov	x2, x0
    b488:	910c23e1 	add	x1, sp, #0x308
    b48c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b490:	52800020 	mov	w0, #0x1                   	// #1
    b494:	f90187f7 	str	x23, [sp, #776]
    b498:	f9018be2 	str	x2, [sp, #784]
    b49c:	97ffe955 	bl	59f0 <fwp_data.part.0.constprop.0>
    b4a0:	97ffe9c0 	bl	5ba0 <fwp_rc_fresh>
    b4a4:	aa0003e2 	mov	x2, x0
    b4a8:	910c63e1 	add	x1, sp, #0x318
    b4ac:	52800020 	mov	w0, #0x1                   	// #1
    b4b0:	f9018ff5 	str	x21, [sp, #792]
    b4b4:	f90193e2 	str	x2, [sp, #800]
    b4b8:	97ffe94e 	bl	59f0 <fwp_data.part.0.constprop.0>
    b4bc:	97ffe9b9 	bl	5ba0 <fwp_rc_fresh>
    b4c0:	aa0003e2 	mov	x2, x0
    b4c4:	910ca3e1 	add	x1, sp, #0x328
    b4c8:	52800020 	mov	w0, #0x1                   	// #1
    b4cc:	f90197f7 	str	x23, [sp, #808]
    b4d0:	f9019be2 	str	x2, [sp, #816]
    b4d4:	97ffe947 	bl	59f0 <fwp_data.part.0.constprop.0>
    b4d8:	97ffe9b2 	bl	5ba0 <fwp_rc_fresh>
    b4dc:	aa0003e2 	mov	x2, x0
    b4e0:	910ce3e1 	add	x1, sp, #0x338
    b4e4:	52800020 	mov	w0, #0x1                   	// #1
    b4e8:	f9019ff5 	str	x21, [sp, #824]
    b4ec:	f901a3e2 	str	x2, [sp, #832]
    b4f0:	97ffe940 	bl	59f0 <fwp_data.part.0.constprop.0>
    b4f4:	97ffe9ab 	bl	5ba0 <fwp_rc_fresh>
    b4f8:	aa0003e2 	mov	x2, x0
    b4fc:	910d23e1 	add	x1, sp, #0x348
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	f901a7f7 	str	x23, [sp, #840]
    b508:	f901abe2 	str	x2, [sp, #848]
    b50c:	97ffe939 	bl	59f0 <fwp_data.part.0.constprop.0>
    b510:	97ffe9a4 	bl	5ba0 <fwp_rc_fresh>
    b514:	aa0003e2 	mov	x2, x0
    b518:	910d63e1 	add	x1, sp, #0x358
    b51c:	52800020 	mov	w0, #0x1                   	// #1
    b520:	f901aff5 	str	x21, [sp, #856]
    b524:	f901b3e2 	str	x2, [sp, #864]
    b528:	97ffe932 	bl	59f0 <fwp_data.part.0.constprop.0>
    b52c:	97ffe99d 	bl	5ba0 <fwp_rc_fresh>
    b530:	aa0003e2 	mov	x2, x0
    b534:	910da3e1 	add	x1, sp, #0x368
    b538:	52800020 	mov	w0, #0x1                   	// #1
    b53c:	f901b7f7 	str	x23, [sp, #872]
    b540:	f901bbe2 	str	x2, [sp, #880]
    b544:	97ffe92b 	bl	59f0 <fwp_data.part.0.constprop.0>
    b548:	97ffe996 	bl	5ba0 <fwp_rc_fresh>
    b54c:	aa0003e2 	mov	x2, x0
    b550:	910de3e1 	add	x1, sp, #0x378
    b554:	52800020 	mov	w0, #0x1                   	// #1
    b558:	f901bff5 	str	x21, [sp, #888]
    b55c:	f901c3e2 	str	x2, [sp, #896]
    b560:	97ffe924 	bl	59f0 <fwp_data.part.0.constprop.0>
    b564:	97ffe98f 	bl	5ba0 <fwp_rc_fresh>
    b568:	aa0003e2 	mov	x2, x0
    b56c:	910e23e1 	add	x1, sp, #0x388
    b570:	52800020 	mov	w0, #0x1                   	// #1
    b574:	f901c7f7 	str	x23, [sp, #904]
    b578:	f901cbe2 	str	x2, [sp, #912]
    b57c:	97ffe91d 	bl	59f0 <fwp_data.part.0.constprop.0>
    b580:	97ffe988 	bl	5ba0 <fwp_rc_fresh>
    b584:	aa0003e2 	mov	x2, x0
    b588:	910e63e1 	add	x1, sp, #0x398
    b58c:	52800020 	mov	w0, #0x1                   	// #1
    b590:	f901cff5 	str	x21, [sp, #920]
    b594:	f901d3e2 	str	x2, [sp, #928]
    b598:	97ffe916 	bl	59f0 <fwp_data.part.0.constprop.0>
    b59c:	97ffe981 	bl	5ba0 <fwp_rc_fresh>
    b5a0:	aa0003e2 	mov	x2, x0
    b5a4:	910ea3e1 	add	x1, sp, #0x3a8
    b5a8:	52800020 	mov	w0, #0x1                   	// #1
    b5ac:	f901d7f7 	str	x23, [sp, #936]
    b5b0:	f901dbe2 	str	x2, [sp, #944]
    b5b4:	97ffe90f 	bl	59f0 <fwp_data.part.0.constprop.0>
    b5b8:	97ffe97a 	bl	5ba0 <fwp_rc_fresh>
    b5bc:	aa0003e2 	mov	x2, x0
    b5c0:	910ee3e1 	add	x1, sp, #0x3b8
    b5c4:	52800020 	mov	w0, #0x1                   	// #1
    b5c8:	f901dff5 	str	x21, [sp, #952]
    b5cc:	f901e3e2 	str	x2, [sp, #960]
    b5d0:	97ffe908 	bl	59f0 <fwp_data.part.0.constprop.0>
    b5d4:	91174283 	add	x3, x20, #0x5d0
    b5d8:	aa0003f5 	mov	x21, x0
    b5dc:	f949d861 	ldr	x1, [x3, #5040]
    b5e0:	f949ec60 	ldr	x0, [x3, #5080]
    b5e4:	cb0102a1 	sub	x1, x21, x1
    b5e8:	eb00403f 	cmp	x1, x0, lsl #16
    b5ec:	54000322 	b.cs	b650 <f0+0xee0>  // b.hs, b.nlast
    b5f0:	d350fc22 	lsr	x2, x1, #16
    b5f4:	f949fc63 	ldr	x3, [x3, #5112]
    b5f8:	8b020842 	add	x2, x2, x2, lsl #2
    b5fc:	d37df042 	lsl	x2, x2, #3
    b600:	8b020060 	add	x0, x3, x2
    b604:	f9401017 	ldr	x23, [x0, #32]
    b608:	b4000257 	cbz	x23, b650 <f0+0xee0>
    b60c:	38626862 	ldrb	w2, [x3, x2]
    b610:	7100085f 	cmp	w2, #0x2
    b614:	5400acc0 	b.eq	cbac <f0+0x243c>  // b.none
    b618:	7100045f 	cmp	w2, #0x1
    b61c:	540001a1 	b.ne	b650 <f0+0xee0>  // b.any
    b620:	29430002 	ldp	w2, w0, [x0, #24]
    b624:	92403c21 	and	x1, x1, #0xffff
    b628:	9b027c21 	mul	x1, x1, x2
    b62c:	d360fc21 	lsr	x1, x1, #32
    b630:	eb00003f 	cmp	x1, x0
    b634:	540000e2 	b.cs	b650 <f0+0xee0>  // b.hs, b.nlast
    b638:	8b0102f7 	add	x23, x23, x1
    b63c:	394002e0 	ldrb	w0, [x23]
    b640:	7103fc1f 	cmp	w0, #0xff
    b644:	5400b3e0 	b.eq	ccc0 <f0+0x2550>  // b.none
    b648:	52800020 	mov	w0, #0x1                   	// #1
    b64c:	390002e0 	strb	w0, [x23]
    b650:	910f23e1 	add	x1, sp, #0x3c8
    b654:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b658:	52800020 	mov	w0, #0x1                   	// #1
    b65c:	f901e7f7 	str	x23, [sp, #968]
    b660:	f901ebf5 	str	x21, [sp, #976]
    b664:	97ffe8e3 	bl	59f0 <fwp_data.part.0.constprop.0>
    b668:	97ffe94e 	bl	5ba0 <fwp_rc_fresh>
    b66c:	aa0003e2 	mov	x2, x0
    b670:	910f63e1 	add	x1, sp, #0x3d8
    b674:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b678:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b67c:	52800020 	mov	w0, #0x1                   	// #1
    b680:	f901eff5 	str	x21, [sp, #984]
    b684:	f901f3e2 	str	x2, [sp, #992]
    b688:	97ffe8da 	bl	59f0 <fwp_data.part.0.constprop.0>
    b68c:	97ffe945 	bl	5ba0 <fwp_rc_fresh>
    b690:	aa0003e2 	mov	x2, x0
    b694:	910fa3e1 	add	x1, sp, #0x3e8
    b698:	52800020 	mov	w0, #0x1                   	// #1
    b69c:	f901f7f7 	str	x23, [sp, #1000]
    b6a0:	f901fbe2 	str	x2, [sp, #1008]
    b6a4:	97ffe8d3 	bl	59f0 <fwp_data.part.0.constprop.0>
    b6a8:	97ffe93e 	bl	5ba0 <fwp_rc_fresh>
    b6ac:	aa0003e2 	mov	x2, x0
    b6b0:	910fe3e1 	add	x1, sp, #0x3f8
    b6b4:	52800020 	mov	w0, #0x1                   	// #1
    b6b8:	f901fff5 	str	x21, [sp, #1016]
    b6bc:	f90203e2 	str	x2, [sp, #1024]
    b6c0:	97ffe8cc 	bl	59f0 <fwp_data.part.0.constprop.0>
    b6c4:	91174283 	add	x3, x20, #0x5d0
    b6c8:	aa0003f5 	mov	x21, x0
    b6cc:	f949d861 	ldr	x1, [x3, #5040]
    b6d0:	f949ec60 	ldr	x0, [x3, #5080]
    b6d4:	cb0102a1 	sub	x1, x21, x1
    b6d8:	eb00403f 	cmp	x1, x0, lsl #16
    b6dc:	54000322 	b.cs	b740 <f0+0xfd0>  // b.hs, b.nlast
    b6e0:	d350fc22 	lsr	x2, x1, #16
    b6e4:	f949fc63 	ldr	x3, [x3, #5112]
    b6e8:	8b020842 	add	x2, x2, x2, lsl #2
    b6ec:	d37df042 	lsl	x2, x2, #3
    b6f0:	8b020060 	add	x0, x3, x2
    b6f4:	f9401017 	ldr	x23, [x0, #32]
    b6f8:	b4000257 	cbz	x23, b740 <f0+0xfd0>
    b6fc:	38626862 	ldrb	w2, [x3, x2]
    b700:	7100085f 	cmp	w2, #0x2
    b704:	5400a4e0 	b.eq	cba0 <f0+0x2430>  // b.none
    b708:	7100045f 	cmp	w2, #0x1
    b70c:	540001a1 	b.ne	b740 <f0+0xfd0>  // b.any
    b710:	29430002 	ldp	w2, w0, [x0, #24]
    b714:	92403c21 	and	x1, x1, #0xffff
    b718:	9b027c21 	mul	x1, x1, x2
    b71c:	d360fc21 	lsr	x1, x1, #32
    b720:	eb00003f 	cmp	x1, x0
    b724:	540000e2 	b.cs	b740 <f0+0xfd0>  // b.hs, b.nlast
    b728:	8b0102f7 	add	x23, x23, x1
    b72c:	394002e0 	ldrb	w0, [x23]
    b730:	7103fc1f 	cmp	w0, #0xff
    b734:	5400acc0 	b.eq	cccc <f0+0x255c>  // b.none
    b738:	52800020 	mov	w0, #0x1                   	// #1
    b73c:	390002e0 	strb	w0, [x23]
    b740:	911023e1 	add	x1, sp, #0x408
    b744:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b748:	52800020 	mov	w0, #0x1                   	// #1
    b74c:	f90207f7 	str	x23, [sp, #1032]
    b750:	f9020bf5 	str	x21, [sp, #1040]
    b754:	97ffe8a7 	bl	59f0 <fwp_data.part.0.constprop.0>
    b758:	97ffe912 	bl	5ba0 <fwp_rc_fresh>
    b75c:	aa0003e2 	mov	x2, x0
    b760:	911063e1 	add	x1, sp, #0x418
    b764:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b768:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b76c:	52800020 	mov	w0, #0x1                   	// #1
    b770:	f9020ff5 	str	x21, [sp, #1048]
    b774:	f90213e2 	str	x2, [sp, #1056]
    b778:	97ffe89e 	bl	59f0 <fwp_data.part.0.constprop.0>
    b77c:	97ffe909 	bl	5ba0 <fwp_rc_fresh>
    b780:	aa0003e2 	mov	x2, x0
    b784:	9110a3e1 	add	x1, sp, #0x428
    b788:	52800020 	mov	w0, #0x1                   	// #1
    b78c:	f90217f7 	str	x23, [sp, #1064]
    b790:	f9021be2 	str	x2, [sp, #1072]
    b794:	97ffe897 	bl	59f0 <fwp_data.part.0.constprop.0>
    b798:	97ffe902 	bl	5ba0 <fwp_rc_fresh>
    b79c:	aa0003e2 	mov	x2, x0
    b7a0:	9110e3e1 	add	x1, sp, #0x438
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	f9021ff5 	str	x21, [sp, #1080]
    b7ac:	f90223e2 	str	x2, [sp, #1088]
    b7b0:	97ffe890 	bl	59f0 <fwp_data.part.0.constprop.0>
    b7b4:	97ffe8fb 	bl	5ba0 <fwp_rc_fresh>
    b7b8:	aa0003e2 	mov	x2, x0
    b7bc:	911123e1 	add	x1, sp, #0x448
    b7c0:	52800020 	mov	w0, #0x1                   	// #1
    b7c4:	f90227f7 	str	x23, [sp, #1096]
    b7c8:	f9022be2 	str	x2, [sp, #1104]
    b7cc:	97ffe889 	bl	59f0 <fwp_data.part.0.constprop.0>
    b7d0:	97ffe8f4 	bl	5ba0 <fwp_rc_fresh>
    b7d4:	aa0003e2 	mov	x2, x0
    b7d8:	911163e1 	add	x1, sp, #0x458
    b7dc:	52800020 	mov	w0, #0x1                   	// #1
    b7e0:	f9022ff5 	str	x21, [sp, #1112]
    b7e4:	f90233e2 	str	x2, [sp, #1120]
    b7e8:	97ffe882 	bl	59f0 <fwp_data.part.0.constprop.0>
    b7ec:	97ffe8ed 	bl	5ba0 <fwp_rc_fresh>
    b7f0:	aa0003e2 	mov	x2, x0
    b7f4:	9111a3e1 	add	x1, sp, #0x468
    b7f8:	52800020 	mov	w0, #0x1                   	// #1
    b7fc:	f90237f7 	str	x23, [sp, #1128]
    b800:	f9023be2 	str	x2, [sp, #1136]
    b804:	97ffe87b 	bl	59f0 <fwp_data.part.0.constprop.0>
    b808:	97ffe8e6 	bl	5ba0 <fwp_rc_fresh>
    b80c:	aa0003e2 	mov	x2, x0
    b810:	9111e3e1 	add	x1, sp, #0x478
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	f9023ff5 	str	x21, [sp, #1144]
    b81c:	f90243e2 	str	x2, [sp, #1152]
    b820:	97ffe874 	bl	59f0 <fwp_data.part.0.constprop.0>
    b824:	91174283 	add	x3, x20, #0x5d0
    b828:	aa0003f5 	mov	x21, x0
    b82c:	f949d861 	ldr	x1, [x3, #5040]
    b830:	f949ec60 	ldr	x0, [x3, #5080]
    b834:	cb0102a1 	sub	x1, x21, x1
    b838:	eb00403f 	cmp	x1, x0, lsl #16
    b83c:	54000322 	b.cs	b8a0 <f0+0x1130>  // b.hs, b.nlast
    b840:	d350fc22 	lsr	x2, x1, #16
    b844:	f949fc63 	ldr	x3, [x3, #5112]
    b848:	8b020842 	add	x2, x2, x2, lsl #2
    b84c:	d37df042 	lsl	x2, x2, #3
    b850:	8b020060 	add	x0, x3, x2
    b854:	f9401017 	ldr	x23, [x0, #32]
    b858:	b4000257 	cbz	x23, b8a0 <f0+0x1130>
    b85c:	38626862 	ldrb	w2, [x3, x2]
    b860:	7100085f 	cmp	w2, #0x2
    b864:	54009b00 	b.eq	cbc4 <f0+0x2454>  // b.none
    b868:	7100045f 	cmp	w2, #0x1
    b86c:	540001a1 	b.ne	b8a0 <f0+0x1130>  // b.any
    b870:	29430002 	ldp	w2, w0, [x0, #24]
    b874:	92403c21 	and	x1, x1, #0xffff
    b878:	9b027c21 	mul	x1, x1, x2
    b87c:	d360fc21 	lsr	x1, x1, #32
    b880:	eb00003f 	cmp	x1, x0
    b884:	540000e2 	b.cs	b8a0 <f0+0x1130>  // b.hs, b.nlast
    b888:	8b0102f7 	add	x23, x23, x1
    b88c:	394002e0 	ldrb	w0, [x23]
    b890:	7103fc1f 	cmp	w0, #0xff
    b894:	5400a220 	b.eq	ccd8 <f0+0x2568>  // b.none
    b898:	52800020 	mov	w0, #0x1                   	// #1
    b89c:	390002e0 	strb	w0, [x23]
    b8a0:	911223e1 	add	x1, sp, #0x488
    b8a4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b8a8:	52800020 	mov	w0, #0x1                   	// #1
    b8ac:	f90247f7 	str	x23, [sp, #1160]
    b8b0:	f9024bf5 	str	x21, [sp, #1168]
    b8b4:	97ffe84f 	bl	59f0 <fwp_data.part.0.constprop.0>
    b8b8:	97ffe8ba 	bl	5ba0 <fwp_rc_fresh>
    b8bc:	aa0003e2 	mov	x2, x0
    b8c0:	911263e1 	add	x1, sp, #0x498
    b8c4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b8c8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	f9024ff5 	str	x21, [sp, #1176]
    b8d4:	f90253e2 	str	x2, [sp, #1184]
    b8d8:	97ffe846 	bl	59f0 <fwp_data.part.0.constprop.0>
    b8dc:	97ffe8b1 	bl	5ba0 <fwp_rc_fresh>
    b8e0:	aa0003e2 	mov	x2, x0
    b8e4:	9112a3e1 	add	x1, sp, #0x4a8
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f90257f7 	str	x23, [sp, #1192]
    b8f0:	f9025be2 	str	x2, [sp, #1200]
    b8f4:	97ffe83f 	bl	59f0 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe8aa 	bl	5ba0 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	9112e3e1 	add	x1, sp, #0x4b8
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f9025ff5 	str	x21, [sp, #1208]
    b90c:	f90263e2 	str	x2, [sp, #1216]
    b910:	97ffe838 	bl	59f0 <fwp_data.part.0.constprop.0>
    b914:	91174283 	add	x3, x20, #0x5d0
    b918:	aa0003f5 	mov	x21, x0
    b91c:	f949d861 	ldr	x1, [x3, #5040]
    b920:	f949ec60 	ldr	x0, [x3, #5080]
    b924:	cb0102a1 	sub	x1, x21, x1
    b928:	eb00403f 	cmp	x1, x0, lsl #16
    b92c:	54000322 	b.cs	b990 <f0+0x1220>  // b.hs, b.nlast
    b930:	d350fc22 	lsr	x2, x1, #16
    b934:	f949fc63 	ldr	x3, [x3, #5112]
    b938:	8b020842 	add	x2, x2, x2, lsl #2
    b93c:	d37df042 	lsl	x2, x2, #3
    b940:	8b020060 	add	x0, x3, x2
    b944:	f9401017 	ldr	x23, [x0, #32]
    b948:	b4000257 	cbz	x23, b990 <f0+0x1220>
    b94c:	38626862 	ldrb	w2, [x3, x2]
    b950:	7100085f 	cmp	w2, #0x2
    b954:	54009320 	b.eq	cbb8 <f0+0x2448>  // b.none
    b958:	7100045f 	cmp	w2, #0x1
    b95c:	540001a1 	b.ne	b990 <f0+0x1220>  // b.any
    b960:	29430002 	ldp	w2, w0, [x0, #24]
    b964:	92403c21 	and	x1, x1, #0xffff
    b968:	9b027c21 	mul	x1, x1, x2
    b96c:	d360fc21 	lsr	x1, x1, #32
    b970:	eb00003f 	cmp	x1, x0
    b974:	540000e2 	b.cs	b990 <f0+0x1220>  // b.hs, b.nlast
    b978:	8b0102f7 	add	x23, x23, x1
    b97c:	394002e0 	ldrb	w0, [x23]
    b980:	7103fc1f 	cmp	w0, #0xff
    b984:	54009b00 	b.eq	cce4 <f0+0x2574>  // b.none
    b988:	52800020 	mov	w0, #0x1                   	// #1
    b98c:	390002e0 	strb	w0, [x23]
    b990:	911323e1 	add	x1, sp, #0x4c8
    b994:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b998:	52800020 	mov	w0, #0x1                   	// #1
    b99c:	f90267e2 	str	x2, [sp, #1224]
    b9a0:	f9026bf5 	str	x21, [sp, #1232]
    b9a4:	97ffe813 	bl	59f0 <fwp_data.part.0.constprop.0>
    b9a8:	97ffe87e 	bl	5ba0 <fwp_rc_fresh>
    b9ac:	aa0003e2 	mov	x2, x0
    b9b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b9b4:	911363e1 	add	x1, sp, #0x4d8
    b9b8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b9bc:	52800020 	mov	w0, #0x1                   	// #1
    b9c0:	f9026fe3 	str	x3, [sp, #1240]
    b9c4:	f90273e2 	str	x2, [sp, #1248]
    b9c8:	97ffe80a 	bl	59f0 <fwp_data.part.0.constprop.0>
    b9cc:	91174283 	add	x3, x20, #0x5d0
    b9d0:	aa0003f5 	mov	x21, x0
    b9d4:	f949d861 	ldr	x1, [x3, #5040]
    b9d8:	f949ec60 	ldr	x0, [x3, #5080]
    b9dc:	cb0102a1 	sub	x1, x21, x1
    b9e0:	eb00403f 	cmp	x1, x0, lsl #16
    b9e4:	54000322 	b.cs	ba48 <f0+0x12d8>  // b.hs, b.nlast
    b9e8:	d350fc22 	lsr	x2, x1, #16
    b9ec:	f949fc63 	ldr	x3, [x3, #5112]
    b9f0:	8b020842 	add	x2, x2, x2, lsl #2
    b9f4:	d37df042 	lsl	x2, x2, #3
    b9f8:	8b020060 	add	x0, x3, x2
    b9fc:	f9401017 	ldr	x23, [x0, #32]
    ba00:	b4000257 	cbz	x23, ba48 <f0+0x12d8>
    ba04:	38626862 	ldrb	w2, [x3, x2]
    ba08:	7100085f 	cmp	w2, #0x2
    ba0c:	54008e80 	b.eq	cbdc <f0+0x246c>  // b.none
    ba10:	7100045f 	cmp	w2, #0x1
    ba14:	540001a1 	b.ne	ba48 <f0+0x12d8>  // b.any
    ba18:	29430002 	ldp	w2, w0, [x0, #24]
    ba1c:	92403c21 	and	x1, x1, #0xffff
    ba20:	9b027c21 	mul	x1, x1, x2
    ba24:	d360fc21 	lsr	x1, x1, #32
    ba28:	eb00003f 	cmp	x1, x0
    ba2c:	540000e2 	b.cs	ba48 <f0+0x12d8>  // b.hs, b.nlast
    ba30:	8b0102f7 	add	x23, x23, x1
    ba34:	394002e0 	ldrb	w0, [x23]
    ba38:	7103fc1f 	cmp	w0, #0xff
    ba3c:	540095a0 	b.eq	ccf0 <f0+0x2580>  // b.none
    ba40:	52800020 	mov	w0, #0x1                   	// #1
    ba44:	390002e0 	strb	w0, [x23]
    ba48:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba4c:	9113a3e1 	add	x1, sp, #0x4e8
    ba50:	52800020 	mov	w0, #0x1                   	// #1
    ba54:	f90277e2 	str	x2, [sp, #1256]
    ba58:	f9027bf5 	str	x21, [sp, #1264]
    ba5c:	97ffe7e5 	bl	59f0 <fwp_data.part.0.constprop.0>
    ba60:	91174283 	add	x3, x20, #0x5d0
    ba64:	aa0003f5 	mov	x21, x0
    ba68:	f949d861 	ldr	x1, [x3, #5040]
    ba6c:	f949ec60 	ldr	x0, [x3, #5080]
    ba70:	cb0102a1 	sub	x1, x21, x1
    ba74:	eb00403f 	cmp	x1, x0, lsl #16
    ba78:	54000322 	b.cs	badc <f0+0x136c>  // b.hs, b.nlast
    ba7c:	d350fc22 	lsr	x2, x1, #16
    ba80:	f949fc63 	ldr	x3, [x3, #5112]
    ba84:	8b020842 	add	x2, x2, x2, lsl #2
    ba88:	d37df042 	lsl	x2, x2, #3
    ba8c:	8b020060 	add	x0, x3, x2
    ba90:	f9401017 	ldr	x23, [x0, #32]
    ba94:	b4000257 	cbz	x23, badc <f0+0x136c>
    ba98:	38626862 	ldrb	w2, [x3, x2]
    ba9c:	7100085f 	cmp	w2, #0x2
    baa0:	54008980 	b.eq	cbd0 <f0+0x2460>  // b.none
    baa4:	7100045f 	cmp	w2, #0x1
    baa8:	540001a1 	b.ne	badc <f0+0x136c>  // b.any
    baac:	29430002 	ldp	w2, w0, [x0, #24]
    bab0:	92403c21 	and	x1, x1, #0xffff
    bab4:	9b027c21 	mul	x1, x1, x2
    bab8:	d360fc21 	lsr	x1, x1, #32
    babc:	eb00003f 	cmp	x1, x0
    bac0:	540000e2 	b.cs	badc <f0+0x136c>  // b.hs, b.nlast
    bac4:	8b0102f7 	add	x23, x23, x1
    bac8:	394002e0 	ldrb	w0, [x23]
    bacc:	7103fc1f 	cmp	w0, #0xff
    bad0:	54009160 	b.eq	ccfc <f0+0x258c>  // b.none
    bad4:	52800020 	mov	w0, #0x1                   	// #1
    bad8:	390002e0 	strb	w0, [x23]
    badc:	9113e3e1 	add	x1, sp, #0x4f8
    bae0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bae4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bae8:	52800020 	mov	w0, #0x1                   	// #1
    baec:	f9027ff7 	str	x23, [sp, #1272]
    baf0:	f90283f5 	str	x21, [sp, #1280]
    baf4:	97ffe7bf 	bl	59f0 <fwp_data.part.0.constprop.0>
    baf8:	97ffe82a 	bl	5ba0 <fwp_rc_fresh>
    bafc:	aa0003e2 	mov	x2, x0
    bb00:	911423e1 	add	x1, sp, #0x508
    bb04:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bb08:	52800020 	mov	w0, #0x1                   	// #1
    bb0c:	f90287f5 	str	x21, [sp, #1288]
    bb10:	f9028be2 	str	x2, [sp, #1296]
    bb14:	97ffe7b7 	bl	59f0 <fwp_data.part.0.constprop.0>
    bb18:	97ffe822 	bl	5ba0 <fwp_rc_fresh>
    bb1c:	aa0003e2 	mov	x2, x0
    bb20:	911463e1 	add	x1, sp, #0x518
    bb24:	52800020 	mov	w0, #0x1                   	// #1
    bb28:	f9028ff7 	str	x23, [sp, #1304]
    bb2c:	f90293e2 	str	x2, [sp, #1312]
    bb30:	97ffe7b0 	bl	59f0 <fwp_data.part.0.constprop.0>
    bb34:	97ffe81b 	bl	5ba0 <fwp_rc_fresh>
    bb38:	aa0003e2 	mov	x2, x0
    bb3c:	9114a3e1 	add	x1, sp, #0x528
    bb40:	52800020 	mov	w0, #0x1                   	// #1
    bb44:	f90297f5 	str	x21, [sp, #1320]
    bb48:	f9029be2 	str	x2, [sp, #1328]
    bb4c:	97ffe7a9 	bl	59f0 <fwp_data.part.0.constprop.0>
    bb50:	97ffe814 	bl	5ba0 <fwp_rc_fresh>
    bb54:	aa0003e2 	mov	x2, x0
    bb58:	9114e3e1 	add	x1, sp, #0x538
    bb5c:	52800020 	mov	w0, #0x1                   	// #1
    bb60:	f9029ff7 	str	x23, [sp, #1336]
    bb64:	f902a3e2 	str	x2, [sp, #1344]
    bb68:	97ffe7a2 	bl	59f0 <fwp_data.part.0.constprop.0>
    bb6c:	91174283 	add	x3, x20, #0x5d0
    bb70:	aa0003f5 	mov	x21, x0
    bb74:	f949d861 	ldr	x1, [x3, #5040]
    bb78:	f949ec60 	ldr	x0, [x3, #5080]
    bb7c:	cb0102a1 	sub	x1, x21, x1
    bb80:	eb00403f 	cmp	x1, x0, lsl #16
    bb84:	54000322 	b.cs	bbe8 <f0+0x1478>  // b.hs, b.nlast
    bb88:	d350fc22 	lsr	x2, x1, #16
    bb8c:	f949fc63 	ldr	x3, [x3, #5112]
    bb90:	8b020842 	add	x2, x2, x2, lsl #2
    bb94:	d37df042 	lsl	x2, x2, #3
    bb98:	8b020060 	add	x0, x3, x2
    bb9c:	f9401017 	ldr	x23, [x0, #32]
    bba0:	b4000257 	cbz	x23, bbe8 <f0+0x1478>
    bba4:	38626862 	ldrb	w2, [x3, x2]
    bba8:	7100085f 	cmp	w2, #0x2
    bbac:	54008240 	b.eq	cbf4 <f0+0x2484>  // b.none
    bbb0:	7100045f 	cmp	w2, #0x1
    bbb4:	540001a1 	b.ne	bbe8 <f0+0x1478>  // b.any
    bbb8:	29430002 	ldp	w2, w0, [x0, #24]
    bbbc:	92403c21 	and	x1, x1, #0xffff
    bbc0:	9b027c21 	mul	x1, x1, x2
    bbc4:	d360fc21 	lsr	x1, x1, #32
    bbc8:	eb00003f 	cmp	x1, x0
    bbcc:	540000e2 	b.cs	bbe8 <f0+0x1478>  // b.hs, b.nlast
    bbd0:	8b0102f7 	add	x23, x23, x1
    bbd4:	394002e0 	ldrb	w0, [x23]
    bbd8:	7103fc1f 	cmp	w0, #0xff
    bbdc:	54008960 	b.eq	cd08 <f0+0x2598>  // b.none
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	390002e0 	strb	w0, [x23]
    bbe8:	911523e1 	add	x1, sp, #0x548
    bbec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bbf0:	52800020 	mov	w0, #0x1                   	// #1
    bbf4:	f902a7f7 	str	x23, [sp, #1352]
    bbf8:	f902abf5 	str	x21, [sp, #1360]
    bbfc:	97ffe77d 	bl	59f0 <fwp_data.part.0.constprop.0>
    bc00:	97ffe7e8 	bl	5ba0 <fwp_rc_fresh>
    bc04:	aa0003e2 	mov	x2, x0
    bc08:	911563e1 	add	x1, sp, #0x558
    bc0c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bc10:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bc14:	52800020 	mov	w0, #0x1                   	// #1
    bc18:	f902aff5 	str	x21, [sp, #1368]
    bc1c:	f902b3e2 	str	x2, [sp, #1376]
    bc20:	97ffe774 	bl	59f0 <fwp_data.part.0.constprop.0>
    bc24:	97ffe7df 	bl	5ba0 <fwp_rc_fresh>
    bc28:	aa0003e2 	mov	x2, x0
    bc2c:	9115a3e1 	add	x1, sp, #0x568
    bc30:	52800020 	mov	w0, #0x1                   	// #1
    bc34:	f902b7f7 	str	x23, [sp, #1384]
    bc38:	f902bbe2 	str	x2, [sp, #1392]
    bc3c:	97ffe76d 	bl	59f0 <fwp_data.part.0.constprop.0>
    bc40:	97ffe7d8 	bl	5ba0 <fwp_rc_fresh>
    bc44:	aa0003e2 	mov	x2, x0
    bc48:	9115e3e1 	add	x1, sp, #0x578
    bc4c:	52800020 	mov	w0, #0x1                   	// #1
    bc50:	f902bff5 	str	x21, [sp, #1400]
    bc54:	f902c3e2 	str	x2, [sp, #1408]
    bc58:	97ffe766 	bl	59f0 <fwp_data.part.0.constprop.0>
    bc5c:	91174283 	add	x3, x20, #0x5d0
    bc60:	aa0003f5 	mov	x21, x0
    bc64:	f949d861 	ldr	x1, [x3, #5040]
    bc68:	f949ec60 	ldr	x0, [x3, #5080]
    bc6c:	cb0102a1 	sub	x1, x21, x1
    bc70:	eb00403f 	cmp	x1, x0, lsl #16
    bc74:	54000322 	b.cs	bcd8 <f0+0x1568>  // b.hs, b.nlast
    bc78:	d350fc22 	lsr	x2, x1, #16
    bc7c:	f949fc63 	ldr	x3, [x3, #5112]
    bc80:	8b020842 	add	x2, x2, x2, lsl #2
    bc84:	d37df042 	lsl	x2, x2, #3
    bc88:	8b020060 	add	x0, x3, x2
    bc8c:	f9401017 	ldr	x23, [x0, #32]
    bc90:	b4000257 	cbz	x23, bcd8 <f0+0x1568>
    bc94:	38626862 	ldrb	w2, [x3, x2]
    bc98:	7100085f 	cmp	w2, #0x2
    bc9c:	54007a60 	b.eq	cbe8 <f0+0x2478>  // b.none
    bca0:	7100045f 	cmp	w2, #0x1
    bca4:	540001a1 	b.ne	bcd8 <f0+0x1568>  // b.any
    bca8:	29430002 	ldp	w2, w0, [x0, #24]
    bcac:	92403c21 	and	x1, x1, #0xffff
    bcb0:	9b027c21 	mul	x1, x1, x2
    bcb4:	d360fc21 	lsr	x1, x1, #32
    bcb8:	eb00003f 	cmp	x1, x0
    bcbc:	540000e2 	b.cs	bcd8 <f0+0x1568>  // b.hs, b.nlast
    bcc0:	8b0102f7 	add	x23, x23, x1
    bcc4:	394002e0 	ldrb	w0, [x23]
    bcc8:	7103fc1f 	cmp	w0, #0xff
    bccc:	54008240 	b.eq	cd14 <f0+0x25a4>  // b.none
    bcd0:	52800020 	mov	w0, #0x1                   	// #1
    bcd4:	390002e0 	strb	w0, [x23]
    bcd8:	911623e1 	add	x1, sp, #0x588
    bcdc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bce0:	52800020 	mov	w0, #0x1                   	// #1
    bce4:	f902c7f7 	str	x23, [sp, #1416]
    bce8:	f902cbf5 	str	x21, [sp, #1424]
    bcec:	97ffe741 	bl	59f0 <fwp_data.part.0.constprop.0>
    bcf0:	97ffe7ac 	bl	5ba0 <fwp_rc_fresh>
    bcf4:	aa0003e2 	mov	x2, x0
    bcf8:	911663e1 	add	x1, sp, #0x598
    bcfc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bd00:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bd04:	52800020 	mov	w0, #0x1                   	// #1
    bd08:	f902cff5 	str	x21, [sp, #1432]
    bd0c:	f902d3e2 	str	x2, [sp, #1440]
    bd10:	97ffe738 	bl	59f0 <fwp_data.part.0.constprop.0>
    bd14:	97ffe7a3 	bl	5ba0 <fwp_rc_fresh>
    bd18:	aa0003e2 	mov	x2, x0
    bd1c:	9116a3e1 	add	x1, sp, #0x5a8
    bd20:	52800020 	mov	w0, #0x1                   	// #1
    bd24:	f902d7f7 	str	x23, [sp, #1448]
    bd28:	f902dbe2 	str	x2, [sp, #1456]
    bd2c:	97ffe731 	bl	59f0 <fwp_data.part.0.constprop.0>
    bd30:	97ffe79c 	bl	5ba0 <fwp_rc_fresh>
    bd34:	aa0003e2 	mov	x2, x0
    bd38:	9116e3e1 	add	x1, sp, #0x5b8
    bd3c:	52800020 	mov	w0, #0x1                   	// #1
    bd40:	f902dff5 	str	x21, [sp, #1464]
    bd44:	f902e3e2 	str	x2, [sp, #1472]
    bd48:	97ffe72a 	bl	59f0 <fwp_data.part.0.constprop.0>
    bd4c:	91174283 	add	x3, x20, #0x5d0
    bd50:	aa0003f5 	mov	x21, x0
    bd54:	f949d861 	ldr	x1, [x3, #5040]
    bd58:	f949ec60 	ldr	x0, [x3, #5080]
    bd5c:	cb0102a1 	sub	x1, x21, x1
    bd60:	eb00403f 	cmp	x1, x0, lsl #16
    bd64:	54000322 	b.cs	bdc8 <f0+0x1658>  // b.hs, b.nlast
    bd68:	d350fc22 	lsr	x2, x1, #16
    bd6c:	f949fc63 	ldr	x3, [x3, #5112]
    bd70:	8b020842 	add	x2, x2, x2, lsl #2
    bd74:	d37df042 	lsl	x2, x2, #3
    bd78:	8b020060 	add	x0, x3, x2
    bd7c:	f9401017 	ldr	x23, [x0, #32]
    bd80:	b4000257 	cbz	x23, bdc8 <f0+0x1658>
    bd84:	38626862 	ldrb	w2, [x3, x2]
    bd88:	7100085f 	cmp	w2, #0x2
    bd8c:	54006800 	b.eq	ca8c <f0+0x231c>  // b.none
    bd90:	7100045f 	cmp	w2, #0x1
    bd94:	540001a1 	b.ne	bdc8 <f0+0x1658>  // b.any
    bd98:	29430002 	ldp	w2, w0, [x0, #24]
    bd9c:	92403c21 	and	x1, x1, #0xffff
    bda0:	9b027c21 	mul	x1, x1, x2
    bda4:	d360fc21 	lsr	x1, x1, #32
    bda8:	eb00003f 	cmp	x1, x0
    bdac:	540000e2 	b.cs	bdc8 <f0+0x1658>  // b.hs, b.nlast
    bdb0:	8b0102f7 	add	x23, x23, x1
    bdb4:	394002e0 	ldrb	w0, [x23]
    bdb8:	7103fc1f 	cmp	w0, #0xff
    bdbc:	54007b20 	b.eq	cd20 <f0+0x25b0>  // b.none
    bdc0:	52800020 	mov	w0, #0x1                   	// #1
    bdc4:	390002e0 	strb	w0, [x23]
    bdc8:	911723e1 	add	x1, sp, #0x5c8
    bdcc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bdd0:	52800020 	mov	w0, #0x1                   	// #1
    bdd4:	f902e7e2 	str	x2, [sp, #1480]
    bdd8:	f902ebf5 	str	x21, [sp, #1488]
    bddc:	97ffe705 	bl	59f0 <fwp_data.part.0.constprop.0>
    bde0:	97ffe770 	bl	5ba0 <fwp_rc_fresh>
    bde4:	aa0003e2 	mov	x2, x0
    bde8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bdec:	911763e1 	add	x1, sp, #0x5d8
    bdf0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bdf4:	52800020 	mov	w0, #0x1                   	// #1
    bdf8:	f902efe3 	str	x3, [sp, #1496]
    bdfc:	f902f3e2 	str	x2, [sp, #1504]
    be00:	97ffe6fc 	bl	59f0 <fwp_data.part.0.constprop.0>
    be04:	91174283 	add	x3, x20, #0x5d0
    be08:	aa0003f5 	mov	x21, x0
    be0c:	f949d861 	ldr	x1, [x3, #5040]
    be10:	f949ec60 	ldr	x0, [x3, #5080]
    be14:	cb0102a1 	sub	x1, x21, x1
    be18:	eb00403f 	cmp	x1, x0, lsl #16
    be1c:	54000322 	b.cs	be80 <f0+0x1710>  // b.hs, b.nlast
    be20:	d350fc22 	lsr	x2, x1, #16
    be24:	f949fc63 	ldr	x3, [x3, #5112]
    be28:	8b020842 	add	x2, x2, x2, lsl #2
    be2c:	d37df042 	lsl	x2, x2, #3
    be30:	8b020060 	add	x0, x3, x2
    be34:	f9401017 	ldr	x23, [x0, #32]
    be38:	b4000257 	cbz	x23, be80 <f0+0x1710>
    be3c:	38626862 	ldrb	w2, [x3, x2]
    be40:	7100085f 	cmp	w2, #0x2
    be44:	540061e0 	b.eq	ca80 <f0+0x2310>  // b.none
    be48:	7100045f 	cmp	w2, #0x1
    be4c:	540001a1 	b.ne	be80 <f0+0x1710>  // b.any
    be50:	29430002 	ldp	w2, w0, [x0, #24]
    be54:	92403c21 	and	x1, x1, #0xffff
    be58:	9b027c21 	mul	x1, x1, x2
    be5c:	d360fc21 	lsr	x1, x1, #32
    be60:	eb00003f 	cmp	x1, x0
    be64:	540000e2 	b.cs	be80 <f0+0x1710>  // b.hs, b.nlast
    be68:	8b0102f7 	add	x23, x23, x1
    be6c:	394002e0 	ldrb	w0, [x23]
    be70:	7103fc1f 	cmp	w0, #0xff
    be74:	540075c0 	b.eq	cd2c <f0+0x25bc>  // b.none
    be78:	52800020 	mov	w0, #0x1                   	// #1
    be7c:	390002e0 	strb	w0, [x23]
    be80:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    be84:	9117a3e1 	add	x1, sp, #0x5e8
    be88:	52800020 	mov	w0, #0x1                   	// #1
    be8c:	f902f7e2 	str	x2, [sp, #1512]
    be90:	f902fbf5 	str	x21, [sp, #1520]
    be94:	97ffe6d7 	bl	59f0 <fwp_data.part.0.constprop.0>
    be98:	91174283 	add	x3, x20, #0x5d0
    be9c:	aa0003f5 	mov	x21, x0
    bea0:	f949d861 	ldr	x1, [x3, #5040]
    bea4:	f949ec60 	ldr	x0, [x3, #5080]
    bea8:	cb0102a1 	sub	x1, x21, x1
    beac:	eb00403f 	cmp	x1, x0, lsl #16
    beb0:	54000322 	b.cs	bf14 <f0+0x17a4>  // b.hs, b.nlast
    beb4:	d350fc22 	lsr	x2, x1, #16
    beb8:	f949fc63 	ldr	x3, [x3, #5112]
    bebc:	8b020842 	add	x2, x2, x2, lsl #2
    bec0:	d37df042 	lsl	x2, x2, #3
    bec4:	8b020060 	add	x0, x3, x2
    bec8:	f9401017 	ldr	x23, [x0, #32]
    becc:	b4000257 	cbz	x23, bf14 <f0+0x17a4>
    bed0:	38626862 	ldrb	w2, [x3, x2]
    bed4:	7100085f 	cmp	w2, #0x2
    bed8:	54005e60 	b.eq	caa4 <f0+0x2334>  // b.none
    bedc:	7100045f 	cmp	w2, #0x1
    bee0:	540001a1 	b.ne	bf14 <f0+0x17a4>  // b.any
    bee4:	29430002 	ldp	w2, w0, [x0, #24]
    bee8:	92403c21 	and	x1, x1, #0xffff
    beec:	9b027c21 	mul	x1, x1, x2
    bef0:	d360fc21 	lsr	x1, x1, #32
    bef4:	eb00003f 	cmp	x1, x0
    bef8:	540000e2 	b.cs	bf14 <f0+0x17a4>  // b.hs, b.nlast
    befc:	8b0102f7 	add	x23, x23, x1
    bf00:	394002e0 	ldrb	w0, [x23]
    bf04:	7103fc1f 	cmp	w0, #0xff
    bf08:	54007180 	b.eq	cd38 <f0+0x25c8>  // b.none
    bf0c:	52800020 	mov	w0, #0x1                   	// #1
    bf10:	390002e0 	strb	w0, [x23]
    bf14:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf18:	9117e3e1 	add	x1, sp, #0x5f8
    bf1c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf20:	52800020 	mov	w0, #0x1                   	// #1
    bf24:	f902ffe2 	str	x2, [sp, #1528]
    bf28:	f90303f5 	str	x21, [sp, #1536]
    bf2c:	97ffe6b1 	bl	59f0 <fwp_data.part.0.constprop.0>
    bf30:	91174283 	add	x3, x20, #0x5d0
    bf34:	aa0003f5 	mov	x21, x0
    bf38:	f949d861 	ldr	x1, [x3, #5040]
    bf3c:	f949ec60 	ldr	x0, [x3, #5080]
    bf40:	cb0102a1 	sub	x1, x21, x1
    bf44:	eb00403f 	cmp	x1, x0, lsl #16
    bf48:	54000322 	b.cs	bfac <f0+0x183c>  // b.hs, b.nlast
    bf4c:	d350fc22 	lsr	x2, x1, #16
    bf50:	f949fc63 	ldr	x3, [x3, #5112]
    bf54:	8b020842 	add	x2, x2, x2, lsl #2
    bf58:	d37df042 	lsl	x2, x2, #3
    bf5c:	8b020060 	add	x0, x3, x2
    bf60:	f9401017 	ldr	x23, [x0, #32]
    bf64:	b4000257 	cbz	x23, bfac <f0+0x183c>
    bf68:	38626862 	ldrb	w2, [x3, x2]
    bf6c:	7100085f 	cmp	w2, #0x2
    bf70:	54005940 	b.eq	ca98 <f0+0x2328>  // b.none
    bf74:	7100045f 	cmp	w2, #0x1
    bf78:	540001a1 	b.ne	bfac <f0+0x183c>  // b.any
    bf7c:	29430002 	ldp	w2, w0, [x0, #24]
    bf80:	92403c21 	and	x1, x1, #0xffff
    bf84:	9b027c21 	mul	x1, x1, x2
    bf88:	d360fc21 	lsr	x1, x1, #32
    bf8c:	eb00003f 	cmp	x1, x0
    bf90:	540000e2 	b.cs	bfac <f0+0x183c>  // b.hs, b.nlast
    bf94:	8b0102f7 	add	x23, x23, x1
    bf98:	394002e0 	ldrb	w0, [x23]
    bf9c:	7103fc1f 	cmp	w0, #0xff
    bfa0:	54006d20 	b.eq	cd44 <f0+0x25d4>  // b.none
    bfa4:	52800020 	mov	w0, #0x1                   	// #1
    bfa8:	390002e0 	strb	w0, [x23]
    bfac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bfb0:	911823e1 	add	x1, sp, #0x608
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	f90307e2 	str	x2, [sp, #1544]
    bfbc:	f9030bf5 	str	x21, [sp, #1552]
    bfc0:	97ffe68c 	bl	59f0 <fwp_data.part.0.constprop.0>
    bfc4:	91174283 	add	x3, x20, #0x5d0
    bfc8:	aa0003f5 	mov	x21, x0
    bfcc:	f949d861 	ldr	x1, [x3, #5040]
    bfd0:	f949ec60 	ldr	x0, [x3, #5080]
    bfd4:	cb0102a1 	sub	x1, x21, x1
    bfd8:	eb00403f 	cmp	x1, x0, lsl #16
    bfdc:	54000322 	b.cs	c040 <f0+0x18d0>  // b.hs, b.nlast
    bfe0:	d350fc22 	lsr	x2, x1, #16
    bfe4:	f949fc63 	ldr	x3, [x3, #5112]
    bfe8:	8b020842 	add	x2, x2, x2, lsl #2
    bfec:	d37df042 	lsl	x2, x2, #3
    bff0:	8b020060 	add	x0, x3, x2
    bff4:	f9401017 	ldr	x23, [x0, #32]
    bff8:	b4000257 	cbz	x23, c040 <f0+0x18d0>
    bffc:	38626862 	ldrb	w2, [x3, x2]
    c000:	7100085f 	cmp	w2, #0x2
    c004:	540055c0 	b.eq	cabc <f0+0x234c>  // b.none
    c008:	7100045f 	cmp	w2, #0x1
    c00c:	540001a1 	b.ne	c040 <f0+0x18d0>  // b.any
    c010:	29430002 	ldp	w2, w0, [x0, #24]
    c014:	92403c21 	and	x1, x1, #0xffff
    c018:	9b027c21 	mul	x1, x1, x2
    c01c:	d360fc21 	lsr	x1, x1, #32
    c020:	eb00003f 	cmp	x1, x0
    c024:	540000e2 	b.cs	c040 <f0+0x18d0>  // b.hs, b.nlast
    c028:	8b0102f7 	add	x23, x23, x1
    c02c:	394002e0 	ldrb	w0, [x23]
    c030:	7103fc1f 	cmp	w0, #0xff
    c034:	540068e0 	b.eq	cd50 <f0+0x25e0>  // b.none
    c038:	52800020 	mov	w0, #0x1                   	// #1
    c03c:	390002e0 	strb	w0, [x23]
    c040:	911863e1 	add	x1, sp, #0x618
    c044:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c048:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c04c:	52800020 	mov	w0, #0x1                   	// #1
    c050:	f9030ff7 	str	x23, [sp, #1560]
    c054:	f90313f5 	str	x21, [sp, #1568]
    c058:	97ffe666 	bl	59f0 <fwp_data.part.0.constprop.0>
    c05c:	97ffe6d1 	bl	5ba0 <fwp_rc_fresh>
    c060:	aa0003e2 	mov	x2, x0
    c064:	9118a3e1 	add	x1, sp, #0x628
    c068:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c06c:	52800020 	mov	w0, #0x1                   	// #1
    c070:	f90317f5 	str	x21, [sp, #1576]
    c074:	f9031be2 	str	x2, [sp, #1584]
    c078:	97ffe65e 	bl	59f0 <fwp_data.part.0.constprop.0>
    c07c:	97ffe6c9 	bl	5ba0 <fwp_rc_fresh>
    c080:	aa0003e2 	mov	x2, x0
    c084:	9118e3e1 	add	x1, sp, #0x638
    c088:	52800020 	mov	w0, #0x1                   	// #1
    c08c:	f9031ff7 	str	x23, [sp, #1592]
    c090:	f90323e2 	str	x2, [sp, #1600]
    c094:	97ffe657 	bl	59f0 <fwp_data.part.0.constprop.0>
    c098:	97ffe6c2 	bl	5ba0 <fwp_rc_fresh>
    c09c:	aa0003e2 	mov	x2, x0
    c0a0:	911923e1 	add	x1, sp, #0x648
    c0a4:	52800020 	mov	w0, #0x1                   	// #1
    c0a8:	f90327f5 	str	x21, [sp, #1608]
    c0ac:	f9032be2 	str	x2, [sp, #1616]
    c0b0:	97ffe650 	bl	59f0 <fwp_data.part.0.constprop.0>
    c0b4:	97ffe6bb 	bl	5ba0 <fwp_rc_fresh>
    c0b8:	aa0003e2 	mov	x2, x0
    c0bc:	911963e1 	add	x1, sp, #0x658
    c0c0:	52800020 	mov	w0, #0x1                   	// #1
    c0c4:	f9032ff7 	str	x23, [sp, #1624]
    c0c8:	f90333e2 	str	x2, [sp, #1632]
    c0cc:	97ffe649 	bl	59f0 <fwp_data.part.0.constprop.0>
    c0d0:	97ffe6b4 	bl	5ba0 <fwp_rc_fresh>
    c0d4:	aa0003e2 	mov	x2, x0
    c0d8:	9119a3e1 	add	x1, sp, #0x668
    c0dc:	52800020 	mov	w0, #0x1                   	// #1
    c0e0:	f90337f5 	str	x21, [sp, #1640]
    c0e4:	f9033be2 	str	x2, [sp, #1648]
    c0e8:	97ffe642 	bl	59f0 <fwp_data.part.0.constprop.0>
    c0ec:	91174283 	add	x3, x20, #0x5d0
    c0f0:	aa0003f5 	mov	x21, x0
    c0f4:	f949d861 	ldr	x1, [x3, #5040]
    c0f8:	f949ec60 	ldr	x0, [x3, #5080]
    c0fc:	cb0102a1 	sub	x1, x21, x1
    c100:	eb00403f 	cmp	x1, x0, lsl #16
    c104:	54000322 	b.cs	c168 <f0+0x19f8>  // b.hs, b.nlast
    c108:	d350fc22 	lsr	x2, x1, #16
    c10c:	f949fc63 	ldr	x3, [x3, #5112]
    c110:	8b020842 	add	x2, x2, x2, lsl #2
    c114:	d37df042 	lsl	x2, x2, #3
    c118:	8b020060 	add	x0, x3, x2
    c11c:	f9401017 	ldr	x23, [x0, #32]
    c120:	b4000257 	cbz	x23, c168 <f0+0x19f8>
    c124:	38626862 	ldrb	w2, [x3, x2]
    c128:	7100085f 	cmp	w2, #0x2
    c12c:	54004c20 	b.eq	cab0 <f0+0x2340>  // b.none
    c130:	7100045f 	cmp	w2, #0x1
    c134:	540001a1 	b.ne	c168 <f0+0x19f8>  // b.any
    c138:	29430002 	ldp	w2, w0, [x0, #24]
    c13c:	92403c21 	and	x1, x1, #0xffff
    c140:	9b027c21 	mul	x1, x1, x2
    c144:	d360fc21 	lsr	x1, x1, #32
    c148:	eb00003f 	cmp	x1, x0
    c14c:	540000e2 	b.cs	c168 <f0+0x19f8>  // b.hs, b.nlast
    c150:	8b0102f7 	add	x23, x23, x1
    c154:	394002e0 	ldrb	w0, [x23]
    c158:	7103fc1f 	cmp	w0, #0xff
    c15c:	54006000 	b.eq	cd5c <f0+0x25ec>  // b.none
    c160:	52800020 	mov	w0, #0x1                   	// #1
    c164:	390002e0 	strb	w0, [x23]
    c168:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c16c:	9119e3e1 	add	x1, sp, #0x678
    c170:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c174:	52800020 	mov	w0, #0x1                   	// #1
    c178:	f9033fe2 	str	x2, [sp, #1656]
    c17c:	f90343f5 	str	x21, [sp, #1664]
    c180:	97ffe61c 	bl	59f0 <fwp_data.part.0.constprop.0>
    c184:	91174283 	add	x3, x20, #0x5d0
    c188:	aa0003f5 	mov	x21, x0
    c18c:	f949d861 	ldr	x1, [x3, #5040]
    c190:	f949ec60 	ldr	x0, [x3, #5080]
    c194:	cb0102a1 	sub	x1, x21, x1
    c198:	eb00403f 	cmp	x1, x0, lsl #16
    c19c:	54000322 	b.cs	c200 <f0+0x1a90>  // b.hs, b.nlast
    c1a0:	d350fc22 	lsr	x2, x1, #16
    c1a4:	f949fc63 	ldr	x3, [x3, #5112]
    c1a8:	8b020842 	add	x2, x2, x2, lsl #2
    c1ac:	d37df042 	lsl	x2, x2, #3
    c1b0:	8b020060 	add	x0, x3, x2
    c1b4:	f9401017 	ldr	x23, [x0, #32]
    c1b8:	b4000257 	cbz	x23, c200 <f0+0x1a90>
    c1bc:	38626862 	ldrb	w2, [x3, x2]
    c1c0:	7100085f 	cmp	w2, #0x2
    c1c4:	54004880 	b.eq	cad4 <f0+0x2364>  // b.none
    c1c8:	7100045f 	cmp	w2, #0x1
    c1cc:	540001a1 	b.ne	c200 <f0+0x1a90>  // b.any
    c1d0:	29430002 	ldp	w2, w0, [x0, #24]
    c1d4:	92403c21 	and	x1, x1, #0xffff
    c1d8:	9b027c21 	mul	x1, x1, x2
    c1dc:	d360fc21 	lsr	x1, x1, #32
    c1e0:	eb00003f 	cmp	x1, x0
    c1e4:	540000e2 	b.cs	c200 <f0+0x1a90>  // b.hs, b.nlast
    c1e8:	8b0102f7 	add	x23, x23, x1
    c1ec:	394002e0 	ldrb	w0, [x23]
    c1f0:	7103fc1f 	cmp	w0, #0xff
    c1f4:	54005ba0 	b.eq	cd68 <f0+0x25f8>  // b.none
    c1f8:	52800020 	mov	w0, #0x1                   	// #1
    c1fc:	390002e0 	strb	w0, [x23]
    c200:	911a23e1 	add	x1, sp, #0x688
    c204:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c208:	52800020 	mov	w0, #0x1                   	// #1
    c20c:	f90347f7 	str	x23, [sp, #1672]
    c210:	f9034bf5 	str	x21, [sp, #1680]
    c214:	97ffe5f7 	bl	59f0 <fwp_data.part.0.constprop.0>
    c218:	97ffe662 	bl	5ba0 <fwp_rc_fresh>
    c21c:	aa0003e2 	mov	x2, x0
    c220:	911a63e1 	add	x1, sp, #0x698
    c224:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c228:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c22c:	52800020 	mov	w0, #0x1                   	// #1
    c230:	f9034ff5 	str	x21, [sp, #1688]
    c234:	f90353e2 	str	x2, [sp, #1696]
    c238:	97ffe5ee 	bl	59f0 <fwp_data.part.0.constprop.0>
    c23c:	97ffe659 	bl	5ba0 <fwp_rc_fresh>
    c240:	aa0003e2 	mov	x2, x0
    c244:	911aa3e1 	add	x1, sp, #0x6a8
    c248:	52800020 	mov	w0, #0x1                   	// #1
    c24c:	f90357f7 	str	x23, [sp, #1704]
    c250:	f9035be2 	str	x2, [sp, #1712]
    c254:	97ffe5e7 	bl	59f0 <fwp_data.part.0.constprop.0>
    c258:	97ffe652 	bl	5ba0 <fwp_rc_fresh>
    c25c:	aa0003e2 	mov	x2, x0
    c260:	911ae3e1 	add	x1, sp, #0x6b8
    c264:	52800020 	mov	w0, #0x1                   	// #1
    c268:	f9035ff5 	str	x21, [sp, #1720]
    c26c:	f90363e2 	str	x2, [sp, #1728]
    c270:	97ffe5e0 	bl	59f0 <fwp_data.part.0.constprop.0>
    c274:	91174283 	add	x3, x20, #0x5d0
    c278:	aa0003f5 	mov	x21, x0
    c27c:	f949d861 	ldr	x1, [x3, #5040]
    c280:	f949ec60 	ldr	x0, [x3, #5080]
    c284:	cb0102a1 	sub	x1, x21, x1
    c288:	eb00403f 	cmp	x1, x0, lsl #16
    c28c:	54000322 	b.cs	c2f0 <f0+0x1b80>  // b.hs, b.nlast
    c290:	d350fc22 	lsr	x2, x1, #16
    c294:	f949fc63 	ldr	x3, [x3, #5112]
    c298:	8b020842 	add	x2, x2, x2, lsl #2
    c29c:	d37df042 	lsl	x2, x2, #3
    c2a0:	8b020060 	add	x0, x3, x2
    c2a4:	f9401017 	ldr	x23, [x0, #32]
    c2a8:	b4000257 	cbz	x23, c2f0 <f0+0x1b80>
    c2ac:	38626862 	ldrb	w2, [x3, x2]
    c2b0:	7100085f 	cmp	w2, #0x2
    c2b4:	540040a0 	b.eq	cac8 <f0+0x2358>  // b.none
    c2b8:	7100045f 	cmp	w2, #0x1
    c2bc:	540001a1 	b.ne	c2f0 <f0+0x1b80>  // b.any
    c2c0:	29430002 	ldp	w2, w0, [x0, #24]
    c2c4:	92403c21 	and	x1, x1, #0xffff
    c2c8:	9b027c21 	mul	x1, x1, x2
    c2cc:	d360fc21 	lsr	x1, x1, #32
    c2d0:	eb00003f 	cmp	x1, x0
    c2d4:	540000e2 	b.cs	c2f0 <f0+0x1b80>  // b.hs, b.nlast
    c2d8:	8b0102f7 	add	x23, x23, x1
    c2dc:	394002e0 	ldrb	w0, [x23]
    c2e0:	7103fc1f 	cmp	w0, #0xff
    c2e4:	54005480 	b.eq	cd74 <f0+0x2604>  // b.none
    c2e8:	52800020 	mov	w0, #0x1                   	// #1
    c2ec:	390002e0 	strb	w0, [x23]
    c2f0:	911b23e1 	add	x1, sp, #0x6c8
    c2f4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c2f8:	52800020 	mov	w0, #0x1                   	// #1
    c2fc:	f90367e2 	str	x2, [sp, #1736]
    c300:	f9036bf5 	str	x21, [sp, #1744]
    c304:	97ffe5bb 	bl	59f0 <fwp_data.part.0.constprop.0>
    c308:	97ffe626 	bl	5ba0 <fwp_rc_fresh>
    c30c:	aa0003e2 	mov	x2, x0
    c310:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c314:	911b63e1 	add	x1, sp, #0x6d8
    c318:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c31c:	52800020 	mov	w0, #0x1                   	// #1
    c320:	f9036fe3 	str	x3, [sp, #1752]
    c324:	f90373e2 	str	x2, [sp, #1760]
    c328:	97ffe5b2 	bl	59f0 <fwp_data.part.0.constprop.0>
    c32c:	91174283 	add	x3, x20, #0x5d0
    c330:	aa0003f5 	mov	x21, x0
    c334:	f949d861 	ldr	x1, [x3, #5040]
    c338:	f949ec60 	ldr	x0, [x3, #5080]
    c33c:	cb0102a1 	sub	x1, x21, x1
    c340:	eb00403f 	cmp	x1, x0, lsl #16
    c344:	54000322 	b.cs	c3a8 <f0+0x1c38>  // b.hs, b.nlast
    c348:	d350fc22 	lsr	x2, x1, #16
    c34c:	f949fc63 	ldr	x3, [x3, #5112]
    c350:	8b020842 	add	x2, x2, x2, lsl #2
    c354:	d37df042 	lsl	x2, x2, #3
    c358:	8b020060 	add	x0, x3, x2
    c35c:	f9401017 	ldr	x23, [x0, #32]
    c360:	b4000257 	cbz	x23, c3a8 <f0+0x1c38>
    c364:	38626862 	ldrb	w2, [x3, x2]
    c368:	7100085f 	cmp	w2, #0x2
    c36c:	54003c00 	b.eq	caec <f0+0x237c>  // b.none
    c370:	7100045f 	cmp	w2, #0x1
    c374:	540001a1 	b.ne	c3a8 <f0+0x1c38>  // b.any
    c378:	29430002 	ldp	w2, w0, [x0, #24]
    c37c:	92403c21 	and	x1, x1, #0xffff
    c380:	9b027c21 	mul	x1, x1, x2
    c384:	d360fc21 	lsr	x1, x1, #32
    c388:	eb00003f 	cmp	x1, x0
    c38c:	540000e2 	b.cs	c3a8 <f0+0x1c38>  // b.hs, b.nlast
    c390:	8b0102f7 	add	x23, x23, x1
    c394:	394002e0 	ldrb	w0, [x23]
    c398:	7103fc1f 	cmp	w0, #0xff
    c39c:	54004f20 	b.eq	cd80 <f0+0x2610>  // b.none
    c3a0:	52800020 	mov	w0, #0x1                   	// #1
    c3a4:	390002e0 	strb	w0, [x23]
    c3a8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c3ac:	911ba3e1 	add	x1, sp, #0x6e8
    c3b0:	52800020 	mov	w0, #0x1                   	// #1
    c3b4:	f90377e2 	str	x2, [sp, #1768]
    c3b8:	f9037bf5 	str	x21, [sp, #1776]
    c3bc:	97ffe58d 	bl	59f0 <fwp_data.part.0.constprop.0>
    c3c0:	91174283 	add	x3, x20, #0x5d0
    c3c4:	aa0003f5 	mov	x21, x0
    c3c8:	f949d861 	ldr	x1, [x3, #5040]
    c3cc:	f949ec60 	ldr	x0, [x3, #5080]
    c3d0:	cb0102a1 	sub	x1, x21, x1
    c3d4:	eb00403f 	cmp	x1, x0, lsl #16
    c3d8:	54000322 	b.cs	c43c <f0+0x1ccc>  // b.hs, b.nlast
    c3dc:	d350fc22 	lsr	x2, x1, #16
    c3e0:	f949fc63 	ldr	x3, [x3, #5112]
    c3e4:	8b020842 	add	x2, x2, x2, lsl #2
    c3e8:	d37df042 	lsl	x2, x2, #3
    c3ec:	8b020060 	add	x0, x3, x2
    c3f0:	f9401017 	ldr	x23, [x0, #32]
    c3f4:	b4000257 	cbz	x23, c43c <f0+0x1ccc>
    c3f8:	38626862 	ldrb	w2, [x3, x2]
    c3fc:	7100085f 	cmp	w2, #0x2
    c400:	54003700 	b.eq	cae0 <f0+0x2370>  // b.none
    c404:	7100045f 	cmp	w2, #0x1
    c408:	540001a1 	b.ne	c43c <f0+0x1ccc>  // b.any
    c40c:	29430002 	ldp	w2, w0, [x0, #24]
    c410:	92403c21 	and	x1, x1, #0xffff
    c414:	9b027c21 	mul	x1, x1, x2
    c418:	d360fc21 	lsr	x1, x1, #32
    c41c:	eb00003f 	cmp	x1, x0
    c420:	540000e2 	b.cs	c43c <f0+0x1ccc>  // b.hs, b.nlast
    c424:	8b0102f7 	add	x23, x23, x1
    c428:	394002e0 	ldrb	w0, [x23]
    c42c:	7103fc1f 	cmp	w0, #0xff
    c430:	54004ae0 	b.eq	cd8c <f0+0x261c>  // b.none
    c434:	52800020 	mov	w0, #0x1                   	// #1
    c438:	390002e0 	strb	w0, [x23]
    c43c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c440:	911be3e1 	add	x1, sp, #0x6f8
    c444:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c448:	52800020 	mov	w0, #0x1                   	// #1
    c44c:	f9037fe2 	str	x2, [sp, #1784]
    c450:	f90383f5 	str	x21, [sp, #1792]
    c454:	97ffe567 	bl	59f0 <fwp_data.part.0.constprop.0>
    c458:	91174283 	add	x3, x20, #0x5d0
    c45c:	aa0003f5 	mov	x21, x0
    c460:	f949d861 	ldr	x1, [x3, #5040]
    c464:	f949ec60 	ldr	x0, [x3, #5080]
    c468:	cb0102a1 	sub	x1, x21, x1
    c46c:	eb00403f 	cmp	x1, x0, lsl #16
    c470:	54000322 	b.cs	c4d4 <f0+0x1d64>  // b.hs, b.nlast
    c474:	d350fc22 	lsr	x2, x1, #16
    c478:	f949fc63 	ldr	x3, [x3, #5112]
    c47c:	8b020842 	add	x2, x2, x2, lsl #2
    c480:	d37df042 	lsl	x2, x2, #3
    c484:	8b020060 	add	x0, x3, x2
    c488:	f9401017 	ldr	x23, [x0, #32]
    c48c:	b4000257 	cbz	x23, c4d4 <f0+0x1d64>
    c490:	38626862 	ldrb	w2, [x3, x2]
    c494:	7100085f 	cmp	w2, #0x2
    c498:	54003360 	b.eq	cb04 <f0+0x2394>  // b.none
    c49c:	7100045f 	cmp	w2, #0x1
    c4a0:	540001a1 	b.ne	c4d4 <f0+0x1d64>  // b.any
    c4a4:	29430002 	ldp	w2, w0, [x0, #24]
    c4a8:	92403c21 	and	x1, x1, #0xffff
    c4ac:	9b027c21 	mul	x1, x1, x2
    c4b0:	d360fc21 	lsr	x1, x1, #32
    c4b4:	eb00003f 	cmp	x1, x0
    c4b8:	540000e2 	b.cs	c4d4 <f0+0x1d64>  // b.hs, b.nlast
    c4bc:	8b0102f7 	add	x23, x23, x1
    c4c0:	394002e0 	ldrb	w0, [x23]
    c4c4:	7103fc1f 	cmp	w0, #0xff
    c4c8:	54004680 	b.eq	cd98 <f0+0x2628>  // b.none
    c4cc:	52800020 	mov	w0, #0x1                   	// #1
    c4d0:	390002e0 	strb	w0, [x23]
    c4d4:	911c23e1 	add	x1, sp, #0x708
    c4d8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c4dc:	52800020 	mov	w0, #0x1                   	// #1
    c4e0:	f90387f7 	str	x23, [sp, #1800]
    c4e4:	f9038bf5 	str	x21, [sp, #1808]
    c4e8:	97ffe542 	bl	59f0 <fwp_data.part.0.constprop.0>
    c4ec:	97ffe5ad 	bl	5ba0 <fwp_rc_fresh>
    c4f0:	aa0003e2 	mov	x2, x0
    c4f4:	911c63e1 	add	x1, sp, #0x718
    c4f8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c4fc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c500:	52800020 	mov	w0, #0x1                   	// #1
    c504:	f9038ff5 	str	x21, [sp, #1816]
    c508:	f90393e2 	str	x2, [sp, #1824]
    c50c:	97ffe539 	bl	59f0 <fwp_data.part.0.constprop.0>
    c510:	97ffe5a4 	bl	5ba0 <fwp_rc_fresh>
    c514:	aa0003e2 	mov	x2, x0
    c518:	911ca3e1 	add	x1, sp, #0x728
    c51c:	52800020 	mov	w0, #0x1                   	// #1
    c520:	f90397f7 	str	x23, [sp, #1832]
    c524:	f9039be2 	str	x2, [sp, #1840]
    c528:	97ffe532 	bl	59f0 <fwp_data.part.0.constprop.0>
    c52c:	97ffe59d 	bl	5ba0 <fwp_rc_fresh>
    c530:	aa0003e2 	mov	x2, x0
    c534:	911ce3e1 	add	x1, sp, #0x738
    c538:	52800020 	mov	w0, #0x1                   	// #1
    c53c:	f9039ff5 	str	x21, [sp, #1848]
    c540:	f903a3e2 	str	x2, [sp, #1856]
    c544:	97ffe52b 	bl	59f0 <fwp_data.part.0.constprop.0>
    c548:	91174283 	add	x3, x20, #0x5d0
    c54c:	aa0003f5 	mov	x21, x0
    c550:	f949d861 	ldr	x1, [x3, #5040]
    c554:	f949ec60 	ldr	x0, [x3, #5080]
    c558:	cb0102a1 	sub	x1, x21, x1
    c55c:	eb00403f 	cmp	x1, x0, lsl #16
    c560:	54000322 	b.cs	c5c4 <f0+0x1e54>  // b.hs, b.nlast
    c564:	d350fc22 	lsr	x2, x1, #16
    c568:	f949fc63 	ldr	x3, [x3, #5112]
    c56c:	8b020842 	add	x2, x2, x2, lsl #2
    c570:	d37df042 	lsl	x2, x2, #3
    c574:	8b020060 	add	x0, x3, x2
    c578:	f9401017 	ldr	x23, [x0, #32]
    c57c:	b4000257 	cbz	x23, c5c4 <f0+0x1e54>
    c580:	38626862 	ldrb	w2, [x3, x2]
    c584:	7100085f 	cmp	w2, #0x2
    c588:	54002b80 	b.eq	caf8 <f0+0x2388>  // b.none
    c58c:	7100045f 	cmp	w2, #0x1
    c590:	540001a1 	b.ne	c5c4 <f0+0x1e54>  // b.any
    c594:	29430002 	ldp	w2, w0, [x0, #24]
    c598:	92403c21 	and	x1, x1, #0xffff
    c59c:	9b027c21 	mul	x1, x1, x2
    c5a0:	d360fc21 	lsr	x1, x1, #32
    c5a4:	eb00003f 	cmp	x1, x0
    c5a8:	540000e2 	b.cs	c5c4 <f0+0x1e54>  // b.hs, b.nlast
    c5ac:	8b0102f7 	add	x23, x23, x1
    c5b0:	394002e0 	ldrb	w0, [x23]
    c5b4:	7103fc1f 	cmp	w0, #0xff
    c5b8:	54003f60 	b.eq	cda4 <f0+0x2634>  // b.none
    c5bc:	52800020 	mov	w0, #0x1                   	// #1
    c5c0:	390002e0 	strb	w0, [x23]
    c5c4:	911d23e1 	add	x1, sp, #0x748
    c5c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c5cc:	52800020 	mov	w0, #0x1                   	// #1
    c5d0:	f903a7f7 	str	x23, [sp, #1864]
    c5d4:	f903abf5 	str	x21, [sp, #1872]
    c5d8:	97ffe506 	bl	59f0 <fwp_data.part.0.constprop.0>
    c5dc:	97ffe571 	bl	5ba0 <fwp_rc_fresh>
    c5e0:	aa0003e2 	mov	x2, x0
    c5e4:	911d63e1 	add	x1, sp, #0x758
    c5e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c5ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c5f0:	52800020 	mov	w0, #0x1                   	// #1
    c5f4:	f903aff5 	str	x21, [sp, #1880]
    c5f8:	f903b3e2 	str	x2, [sp, #1888]
    c5fc:	97ffe4fd 	bl	59f0 <fwp_data.part.0.constprop.0>
    c600:	97ffe568 	bl	5ba0 <fwp_rc_fresh>
    c604:	aa0003e2 	mov	x2, x0
    c608:	911da3e1 	add	x1, sp, #0x768
    c60c:	52800020 	mov	w0, #0x1                   	// #1
    c610:	f903b7f7 	str	x23, [sp, #1896]
    c614:	f903bbe2 	str	x2, [sp, #1904]
    c618:	97ffe4f6 	bl	59f0 <fwp_data.part.0.constprop.0>
    c61c:	97ffe561 	bl	5ba0 <fwp_rc_fresh>
    c620:	aa0003e2 	mov	x2, x0
    c624:	911de3e1 	add	x1, sp, #0x778
    c628:	52800020 	mov	w0, #0x1                   	// #1
    c62c:	f903bff5 	str	x21, [sp, #1912]
    c630:	f903c3e2 	str	x2, [sp, #1920]
    c634:	97ffe4ef 	bl	59f0 <fwp_data.part.0.constprop.0>
    c638:	91174283 	add	x3, x20, #0x5d0
    c63c:	aa0003f5 	mov	x21, x0
    c640:	f949d861 	ldr	x1, [x3, #5040]
    c644:	f949ec60 	ldr	x0, [x3, #5080]
    c648:	cb0102a1 	sub	x1, x21, x1
    c64c:	eb00403f 	cmp	x1, x0, lsl #16
    c650:	54000322 	b.cs	c6b4 <f0+0x1f44>  // b.hs, b.nlast
    c654:	d350fc22 	lsr	x2, x1, #16
    c658:	f949fc63 	ldr	x3, [x3, #5112]
    c65c:	8b020842 	add	x2, x2, x2, lsl #2
    c660:	d37df042 	lsl	x2, x2, #3
    c664:	8b020060 	add	x0, x3, x2
    c668:	f9401017 	ldr	x23, [x0, #32]
    c66c:	b4000257 	cbz	x23, c6b4 <f0+0x1f44>
    c670:	38626862 	ldrb	w2, [x3, x2]
    c674:	7100085f 	cmp	w2, #0x2
    c678:	54002520 	b.eq	cb1c <f0+0x23ac>  // b.none
    c67c:	7100045f 	cmp	w2, #0x1
    c680:	540001a1 	b.ne	c6b4 <f0+0x1f44>  // b.any
    c684:	29430002 	ldp	w2, w0, [x0, #24]
    c688:	92403c21 	and	x1, x1, #0xffff
    c68c:	9b027c21 	mul	x1, x1, x2
    c690:	d360fc21 	lsr	x1, x1, #32
    c694:	eb00003f 	cmp	x1, x0
    c698:	540000e2 	b.cs	c6b4 <f0+0x1f44>  // b.hs, b.nlast
    c69c:	8b0102f7 	add	x23, x23, x1
    c6a0:	394002e0 	ldrb	w0, [x23]
    c6a4:	7103fc1f 	cmp	w0, #0xff
    c6a8:	54003840 	b.eq	cdb0 <f0+0x2640>  // b.none
    c6ac:	52800020 	mov	w0, #0x1                   	// #1
    c6b0:	390002e0 	strb	w0, [x23]
    c6b4:	911e23e1 	add	x1, sp, #0x788
    c6b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c6bc:	52800020 	mov	w0, #0x1                   	// #1
    c6c0:	f903c7f7 	str	x23, [sp, #1928]
    c6c4:	f903cbf5 	str	x21, [sp, #1936]
    c6c8:	97ffe4ca 	bl	59f0 <fwp_data.part.0.constprop.0>
    c6cc:	97ffe535 	bl	5ba0 <fwp_rc_fresh>
    c6d0:	aa0003e2 	mov	x2, x0
    c6d4:	911e63e1 	add	x1, sp, #0x798
    c6d8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c6dc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c6e0:	52800020 	mov	w0, #0x1                   	// #1
    c6e4:	f903cff5 	str	x21, [sp, #1944]
    c6e8:	f903d3e2 	str	x2, [sp, #1952]
    c6ec:	97ffe4c1 	bl	59f0 <fwp_data.part.0.constprop.0>
    c6f0:	97ffe52c 	bl	5ba0 <fwp_rc_fresh>
    c6f4:	aa0003e2 	mov	x2, x0
    c6f8:	911ea3e1 	add	x1, sp, #0x7a8
    c6fc:	52800020 	mov	w0, #0x1                   	// #1
    c700:	f903d7f7 	str	x23, [sp, #1960]
    c704:	f903dbe2 	str	x2, [sp, #1968]
    c708:	97ffe4ba 	bl	59f0 <fwp_data.part.0.constprop.0>
    c70c:	97ffe525 	bl	5ba0 <fwp_rc_fresh>
    c710:	aa0003e2 	mov	x2, x0
    c714:	911ee3e1 	add	x1, sp, #0x7b8
    c718:	52800020 	mov	w0, #0x1                   	// #1
    c71c:	f903dff5 	str	x21, [sp, #1976]
    c720:	f903e3e2 	str	x2, [sp, #1984]
    c724:	97ffe4b3 	bl	59f0 <fwp_data.part.0.constprop.0>
    c728:	97ffe51e 	bl	5ba0 <fwp_rc_fresh>
    c72c:	aa0003e2 	mov	x2, x0
    c730:	911f23e1 	add	x1, sp, #0x7c8
    c734:	52800020 	mov	w0, #0x1                   	// #1
    c738:	f903e7f7 	str	x23, [sp, #1992]
    c73c:	f903ebe2 	str	x2, [sp, #2000]
    c740:	97ffe4ac 	bl	59f0 <fwp_data.part.0.constprop.0>
    c744:	97ffe517 	bl	5ba0 <fwp_rc_fresh>
    c748:	aa0003e2 	mov	x2, x0
    c74c:	911f63e1 	add	x1, sp, #0x7d8
    c750:	52800020 	mov	w0, #0x1                   	// #1
    c754:	f903eff5 	str	x21, [sp, #2008]
    c758:	f903f3e2 	str	x2, [sp, #2016]
    c75c:	97ffe4a5 	bl	59f0 <fwp_data.part.0.constprop.0>
    c760:	91174283 	add	x3, x20, #0x5d0
    c764:	aa0003f5 	mov	x21, x0
    c768:	f949d861 	ldr	x1, [x3, #5040]
    c76c:	f949ec60 	ldr	x0, [x3, #5080]
    c770:	cb0102a1 	sub	x1, x21, x1
    c774:	eb00403f 	cmp	x1, x0, lsl #16
    c778:	54000322 	b.cs	c7dc <f0+0x206c>  // b.hs, b.nlast
    c77c:	d350fc22 	lsr	x2, x1, #16
    c780:	f949fc63 	ldr	x3, [x3, #5112]
    c784:	8b020842 	add	x2, x2, x2, lsl #2
    c788:	d37df042 	lsl	x2, x2, #3
    c78c:	8b020060 	add	x0, x3, x2
    c790:	f9401017 	ldr	x23, [x0, #32]
    c794:	b4000257 	cbz	x23, c7dc <f0+0x206c>
    c798:	38626862 	ldrb	w2, [x3, x2]
    c79c:	7100085f 	cmp	w2, #0x2
    c7a0:	54001b80 	b.eq	cb10 <f0+0x23a0>  // b.none
    c7a4:	7100045f 	cmp	w2, #0x1
    c7a8:	540001a1 	b.ne	c7dc <f0+0x206c>  // b.any
    c7ac:	29430002 	ldp	w2, w0, [x0, #24]
    c7b0:	92403c21 	and	x1, x1, #0xffff
    c7b4:	9b027c21 	mul	x1, x1, x2
    c7b8:	d360fc21 	lsr	x1, x1, #32
    c7bc:	eb00003f 	cmp	x1, x0
    c7c0:	540000e2 	b.cs	c7dc <f0+0x206c>  // b.hs, b.nlast
    c7c4:	8b0102f7 	add	x23, x23, x1
    c7c8:	394002e0 	ldrb	w0, [x23]
    c7cc:	7103fc1f 	cmp	w0, #0xff
    c7d0:	54002f60 	b.eq	cdbc <f0+0x264c>  // b.none
    c7d4:	52800020 	mov	w0, #0x1                   	// #1
    c7d8:	390002e0 	strb	w0, [x23]
    c7dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c7e0:	911fa3e1 	add	x1, sp, #0x7e8
    c7e4:	52800020 	mov	w0, #0x1                   	// #1
    c7e8:	f903f7e2 	str	x2, [sp, #2024]
    c7ec:	f903fbf5 	str	x21, [sp, #2032]
    c7f0:	97ffe480 	bl	59f0 <fwp_data.part.0.constprop.0>
    c7f4:	91174283 	add	x3, x20, #0x5d0
    c7f8:	aa0003f7 	mov	x23, x0
    c7fc:	f949d861 	ldr	x1, [x3, #5040]
    c800:	f949ec60 	ldr	x0, [x3, #5080]
    c804:	cb0102e1 	sub	x1, x23, x1
    c808:	eb00403f 	cmp	x1, x0, lsl #16
    c80c:	54000322 	b.cs	c870 <f0+0x2100>  // b.hs, b.nlast
    c810:	d350fc22 	lsr	x2, x1, #16
    c814:	f949fc63 	ldr	x3, [x3, #5112]
    c818:	8b020842 	add	x2, x2, x2, lsl #2
    c81c:	d37df042 	lsl	x2, x2, #3
    c820:	8b020060 	add	x0, x3, x2
    c824:	f9401015 	ldr	x21, [x0, #32]
    c828:	b4000255 	cbz	x21, c870 <f0+0x2100>
    c82c:	38626862 	ldrb	w2, [x3, x2]
    c830:	7100085f 	cmp	w2, #0x2
    c834:	54001800 	b.eq	cb34 <f0+0x23c4>  // b.none
    c838:	7100045f 	cmp	w2, #0x1
    c83c:	540001a1 	b.ne	c870 <f0+0x2100>  // b.any
    c840:	29430002 	ldp	w2, w0, [x0, #24]
    c844:	92403c21 	and	x1, x1, #0xffff
    c848:	9b027c21 	mul	x1, x1, x2
    c84c:	d360fc21 	lsr	x1, x1, #32
    c850:	eb00003f 	cmp	x1, x0
    c854:	540000e2 	b.cs	c870 <f0+0x2100>  // b.hs, b.nlast
    c858:	8b0102b5 	add	x21, x21, x1
    c85c:	394002a0 	ldrb	w0, [x21]
    c860:	7103fc1f 	cmp	w0, #0xff
    c864:	54002b20 	b.eq	cdc8 <f0+0x2658>  // b.none
    c868:	52800020 	mov	w0, #0x1                   	// #1
    c86c:	390002a0 	strb	w0, [x21]
    c870:	911fe3e1 	add	x1, sp, #0x7f8
    c874:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c878:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c87c:	52800020 	mov	w0, #0x1                   	// #1
    c880:	f903fff5 	str	x21, [sp, #2040]
    c884:	91174294 	add	x20, x20, #0x5d0
    c888:	f90403f7 	str	x23, [sp, #2048]
    c88c:	97ffe459 	bl	59f0 <fwp_data.part.0.constprop.0>
    c890:	97ffe4c4 	bl	5ba0 <fwp_rc_fresh>
    c894:	aa0003e2 	mov	x2, x0
    c898:	912023e1 	add	x1, sp, #0x808
    c89c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c8a0:	52800020 	mov	w0, #0x1                   	// #1
    c8a4:	f90407f7 	str	x23, [sp, #2056]
    c8a8:	f9040be2 	str	x2, [sp, #2064]
    c8ac:	97ffe451 	bl	59f0 <fwp_data.part.0.constprop.0>
    c8b0:	97ffe4bc 	bl	5ba0 <fwp_rc_fresh>
    c8b4:	aa0003e2 	mov	x2, x0
    c8b8:	912063e1 	add	x1, sp, #0x818
    c8bc:	52800020 	mov	w0, #0x1                   	// #1
    c8c0:	f9040ff5 	str	x21, [sp, #2072]
    c8c4:	f90413e2 	str	x2, [sp, #2080]
    c8c8:	97ffe44a 	bl	59f0 <fwp_data.part.0.constprop.0>
    c8cc:	97ffe4b5 	bl	5ba0 <fwp_rc_fresh>
    c8d0:	aa0003e2 	mov	x2, x0
    c8d4:	9120a3e1 	add	x1, sp, #0x828
    c8d8:	52800020 	mov	w0, #0x1                   	// #1
    c8dc:	f90417f7 	str	x23, [sp, #2088]
    c8e0:	f9041be2 	str	x2, [sp, #2096]
    c8e4:	97ffe443 	bl	59f0 <fwp_data.part.0.constprop.0>
    c8e8:	97ffe4ae 	bl	5ba0 <fwp_rc_fresh>
    c8ec:	aa0003e2 	mov	x2, x0
    c8f0:	9120e3e1 	add	x1, sp, #0x838
    c8f4:	52800020 	mov	w0, #0x1                   	// #1
    c8f8:	f9041ff5 	str	x21, [sp, #2104]
    c8fc:	f90423e2 	str	x2, [sp, #2112]
    c900:	97ffe43c 	bl	59f0 <fwp_data.part.0.constprop.0>
    c904:	97ffe4a7 	bl	5ba0 <fwp_rc_fresh>
    c908:	aa0003e2 	mov	x2, x0
    c90c:	912123e1 	add	x1, sp, #0x848
    c910:	52800020 	mov	w0, #0x1                   	// #1
    c914:	f90427f7 	str	x23, [sp, #2120]
    c918:	f9042be2 	str	x2, [sp, #2128]
    c91c:	97ffe435 	bl	59f0 <fwp_data.part.0.constprop.0>
    c920:	97ffe4a0 	bl	5ba0 <fwp_rc_fresh>
    c924:	aa0003e2 	mov	x2, x0
    c928:	aa1603e1 	mov	x1, x22
    c92c:	52800020 	mov	w0, #0x1                   	// #1
    c930:	f9042ff5 	str	x21, [sp, #2136]
    c934:	f90433e2 	str	x2, [sp, #2144]
    c938:	97ffe42e 	bl	59f0 <fwp_data.part.0.constprop.0>
    c93c:	f949da81 	ldr	x1, [x20, #5040]
    c940:	aa0003f5 	mov	x21, x0
    c944:	f949ee80 	ldr	x0, [x20, #5080]
    c948:	cb0102a1 	sub	x1, x21, x1
    c94c:	eb00403f 	cmp	x1, x0, lsl #16
    c950:	54000322 	b.cs	c9b4 <f0+0x2244>  // b.hs, b.nlast
    c954:	d350fc22 	lsr	x2, x1, #16
    c958:	f949fe83 	ldr	x3, [x20, #5112]
    c95c:	8b020842 	add	x2, x2, x2, lsl #2
    c960:	d37df042 	lsl	x2, x2, #3
    c964:	8b020060 	add	x0, x3, x2
    c968:	f9401014 	ldr	x20, [x0, #32]
    c96c:	b4000254 	cbz	x20, c9b4 <f0+0x2244>
    c970:	38626862 	ldrb	w2, [x3, x2]
    c974:	7100085f 	cmp	w2, #0x2
    c978:	54000d80 	b.eq	cb28 <f0+0x23b8>  // b.none
    c97c:	7100045f 	cmp	w2, #0x1
    c980:	540001a1 	b.ne	c9b4 <f0+0x2244>  // b.any
    c984:	29430002 	ldp	w2, w0, [x0, #24]
    c988:	92403c21 	and	x1, x1, #0xffff
    c98c:	9b027c21 	mul	x1, x1, x2
    c990:	d360fc21 	lsr	x1, x1, #32
    c994:	eb00003f 	cmp	x1, x0
    c998:	540000e2 	b.cs	c9b4 <f0+0x2244>  // b.hs, b.nlast
    c99c:	8b010294 	add	x20, x20, x1
    c9a0:	39400280 	ldrb	w0, [x20]
    c9a4:	7103fc1f 	cmp	w0, #0xff
    c9a8:	540012c0 	b.eq	cc00 <f0+0x2490>  // b.none
    c9ac:	52800020 	mov	w0, #0x1                   	// #1
    c9b0:	39000280 	strb	w0, [x20]
    c9b4:	aa1303e1 	mov	x1, x19
    c9b8:	aa1503e0 	mov	x0, x21
    c9bc:	97fff3fd 	bl	99b0 <fwp_hof0.constprop.0>
    c9c0:	aa0003f4 	mov	x20, x0
    c9c4:	aa1503e0 	mov	x0, x21
    c9c8:	97ffe5d6 	bl	6120 <fwp_drop0>
    c9cc:	aa1303e0 	mov	x0, x19
    c9d0:	97ffe5d4 	bl	6120 <fwp_drop0>
    c9d4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c9d8:	f947f400 	ldr	x0, [x0, #4072]
    c9dc:	f94437e2 	ldr	x2, [sp, #2152]
    c9e0:	f9400001 	ldr	x1, [x0]
    c9e4:	eb010042 	subs	x2, x2, x1
    c9e8:	d2800001 	mov	x1, #0x0                   	// #0
    c9ec:	54001f41 	b.ne	cdd4 <f0+0x2664>  // b.any
    c9f0:	9121c3ff 	add	sp, sp, #0x870
    c9f4:	aa1403e0 	mov	x0, x20
    c9f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    c9fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    ca00:	a94363f7 	ldp	x23, x24, [sp, #48]
    ca04:	a9446bf9 	ldp	x25, x26, [sp, #64]
    ca08:	a94573fb 	ldp	x27, x28, [sp, #80]
    ca0c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    ca10:	d65f03c0 	ret
    ca14:	aa1c03e0 	mov	x0, x28
    ca18:	97ffddde 	bl	4190 <fwp_rc_forget_slot.part.0>
    ca1c:	17fff79f 	b	a898 <f0+0x128>
    ca20:	72003c5f 	tst	w2, #0xffff
    ca24:	54fef3c1 	b.ne	a89c <f0+0x12c>  // b.any
    ca28:	17fff799 	b	a88c <f0+0x11c>
    ca2c:	72003c3f 	tst	w1, #0xffff
    ca30:	54feffa1 	b.ne	aa24 <f0+0x2b4>  // b.any
    ca34:	17fff7f7 	b	aa10 <f0+0x2a0>
    ca38:	72003c3f 	tst	w1, #0xffff
    ca3c:	54ff0ea1 	b.ne	ac10 <f0+0x4a0>  // b.any
    ca40:	17fff86f 	b	abfc <f0+0x48c>
    ca44:	72003c3f 	tst	w1, #0xffff
    ca48:	54ff0381 	b.ne	aab8 <f0+0x348>  // b.any
    ca4c:	17fff816 	b	aaa4 <f0+0x334>
    ca50:	72003c3f 	tst	w1, #0xffff
    ca54:	54ff1801 	b.ne	ad54 <f0+0x5e4>  // b.any
    ca58:	17fff8ba 	b	ad40 <f0+0x5d0>
    ca5c:	72003c3f 	tst	w1, #0xffff
    ca60:	54ff1221 	b.ne	aca4 <f0+0x534>  // b.any
    ca64:	17fff88b 	b	ac90 <f0+0x520>
    ca68:	72003c3f 	tst	w1, #0xffff
    ca6c:	54ff22c1 	b.ne	aec4 <f0+0x754>  // b.any
    ca70:	17fff910 	b	aeb0 <f0+0x740>
    ca74:	72003c3f 	tst	w1, #0xffff
    ca78:	54ff1de1 	b.ne	ae34 <f0+0x6c4>  // b.any
    ca7c:	17fff8e9 	b	ae20 <f0+0x6b0>
    ca80:	72003c3f 	tst	w1, #0xffff
    ca84:	54ff9fe1 	b.ne	be80 <f0+0x1710>  // b.any
    ca88:	17fffcf9 	b	be6c <f0+0x16fc>
    ca8c:	72003c3f 	tst	w1, #0xffff
    ca90:	54ff99c1 	b.ne	bdc8 <f0+0x1658>  // b.any
    ca94:	17fffcc8 	b	bdb4 <f0+0x1644>
    ca98:	72003c3f 	tst	w1, #0xffff
    ca9c:	54ffa881 	b.ne	bfac <f0+0x183c>  // b.any
    caa0:	17fffd3e 	b	bf98 <f0+0x1828>
    caa4:	72003c3f 	tst	w1, #0xffff
    caa8:	54ffa361 	b.ne	bf14 <f0+0x17a4>  // b.any
    caac:	17fffd15 	b	bf00 <f0+0x1790>
    cab0:	72003c3f 	tst	w1, #0xffff
    cab4:	54ffb5a1 	b.ne	c168 <f0+0x19f8>  // b.any
    cab8:	17fffda7 	b	c154 <f0+0x19e4>
    cabc:	72003c3f 	tst	w1, #0xffff
    cac0:	54ffac01 	b.ne	c040 <f0+0x18d0>  // b.any
    cac4:	17fffd5a 	b	c02c <f0+0x18bc>
    cac8:	72003c3f 	tst	w1, #0xffff
    cacc:	54ffc121 	b.ne	c2f0 <f0+0x1b80>  // b.any
    cad0:	17fffe03 	b	c2dc <f0+0x1b6c>
    cad4:	72003c3f 	tst	w1, #0xffff
    cad8:	54ffb941 	b.ne	c200 <f0+0x1a90>  // b.any
    cadc:	17fffdc4 	b	c1ec <f0+0x1a7c>
    cae0:	72003c3f 	tst	w1, #0xffff
    cae4:	54ffcac1 	b.ne	c43c <f0+0x1ccc>  // b.any
    cae8:	17fffe50 	b	c428 <f0+0x1cb8>
    caec:	72003c3f 	tst	w1, #0xffff
    caf0:	54ffc5c1 	b.ne	c3a8 <f0+0x1c38>  // b.any
    caf4:	17fffe28 	b	c394 <f0+0x1c24>
    caf8:	72003c3f 	tst	w1, #0xffff
    cafc:	54ffd641 	b.ne	c5c4 <f0+0x1e54>  // b.any
    cb00:	17fffeac 	b	c5b0 <f0+0x1e40>
    cb04:	72003c3f 	tst	w1, #0xffff
    cb08:	54ffce61 	b.ne	c4d4 <f0+0x1d64>  // b.any
    cb0c:	17fffe6d 	b	c4c0 <f0+0x1d50>
    cb10:	72003c3f 	tst	w1, #0xffff
    cb14:	54ffe641 	b.ne	c7dc <f0+0x206c>  // b.any
    cb18:	17ffff2c 	b	c7c8 <f0+0x2058>
    cb1c:	72003c3f 	tst	w1, #0xffff
    cb20:	54ffdca1 	b.ne	c6b4 <f0+0x1f44>  // b.any
    cb24:	17fffedf 	b	c6a0 <f0+0x1f30>
    cb28:	72003c3f 	tst	w1, #0xffff
    cb2c:	54fff441 	b.ne	c9b4 <f0+0x2244>  // b.any
    cb30:	17ffff9c 	b	c9a0 <f0+0x2230>
    cb34:	72003c3f 	tst	w1, #0xffff
    cb38:	54ffe9c1 	b.ne	c870 <f0+0x2100>  // b.any
    cb3c:	17ffff48 	b	c85c <f0+0x20ec>
    cb40:	72003c3f 	tst	w1, #0xffff
    cb44:	54ff29e1 	b.ne	b080 <f0+0x910>  // b.any
    cb48:	17fff949 	b	b06c <f0+0x8fc>
    cb4c:	72003c3f 	tst	w1, #0xffff
    cb50:	54ff2041 	b.ne	af58 <f0+0x7e8>  // b.any
    cb54:	17fff8fc 	b	af44 <f0+0x7d4>
    cb58:	72003c3f 	tst	w1, #0xffff
    cb5c:	54ff3281 	b.ne	b1ac <f0+0xa3c>  // b.any
    cb60:	17fff98e 	b	b198 <f0+0xa28>
    cb64:	72003c3f 	tst	w1, #0xffff
    cb68:	54ff2d61 	b.ne	b114 <f0+0x9a4>  // b.any
    cb6c:	17fff965 	b	b100 <f0+0x990>
    cb70:	72003c3f 	tst	w1, #0xffff
    cb74:	54ff3e21 	b.ne	b338 <f0+0xbc8>  // b.any
    cb78:	17fff9eb 	b	b324 <f0+0xbb4>
    cb7c:	72003c3f 	tst	w1, #0xffff
    cb80:	54ff3721 	b.ne	b264 <f0+0xaf4>  // b.any
    cb84:	17fff9b3 	b	b250 <f0+0xae0>
    cb88:	72003c3f 	tst	w1, #0xffff
    cb8c:	54ff46c1 	b.ne	b464 <f0+0xcf4>  // b.any
    cb90:	17fffa30 	b	b450 <f0+0xce0>
    cb94:	72003c3f 	tst	w1, #0xffff
    cb98:	54ff41c1 	b.ne	b3d0 <f0+0xc60>  // b.any
    cb9c:	17fffa08 	b	b3bc <f0+0xc4c>
    cba0:	72003c3f 	tst	w1, #0xffff
    cba4:	54ff5ce1 	b.ne	b740 <f0+0xfd0>  // b.any
    cba8:	17fffae1 	b	b72c <f0+0xfbc>
    cbac:	72003c3f 	tst	w1, #0xffff
    cbb0:	54ff5501 	b.ne	b650 <f0+0xee0>  // b.any
    cbb4:	17fffaa2 	b	b63c <f0+0xecc>
    cbb8:	72003c3f 	tst	w1, #0xffff
    cbbc:	54ff6ea1 	b.ne	b990 <f0+0x1220>  // b.any
    cbc0:	17fffb6f 	b	b97c <f0+0x120c>
    cbc4:	72003c3f 	tst	w1, #0xffff
    cbc8:	54ff66c1 	b.ne	b8a0 <f0+0x1130>  // b.any
    cbcc:	17fffb30 	b	b88c <f0+0x111c>
    cbd0:	72003c3f 	tst	w1, #0xffff
    cbd4:	54ff7841 	b.ne	badc <f0+0x136c>  // b.any
    cbd8:	17fffbbc 	b	bac8 <f0+0x1358>
    cbdc:	72003c3f 	tst	w1, #0xffff
    cbe0:	54ff7341 	b.ne	ba48 <f0+0x12d8>  // b.any
    cbe4:	17fffb94 	b	ba34 <f0+0x12c4>
    cbe8:	72003c3f 	tst	w1, #0xffff
    cbec:	54ff8761 	b.ne	bcd8 <f0+0x1568>  // b.any
    cbf0:	17fffc35 	b	bcc4 <f0+0x1554>
    cbf4:	72003c3f 	tst	w1, #0xffff
    cbf8:	54ff7f81 	b.ne	bbe8 <f0+0x1478>  // b.any
    cbfc:	17fffbf6 	b	bbd4 <f0+0x1464>
    cc00:	aa1403e0 	mov	x0, x20
    cc04:	97ffdd63 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc08:	17ffff69 	b	c9ac <f0+0x223c>
    cc0c:	aa1703e0 	mov	x0, x23
    cc10:	97ffdd60 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc14:	17fff782 	b	aa1c <f0+0x2ac>
    cc18:	aa1503e0 	mov	x0, x21
    cc1c:	97ffdd5d 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc20:	17fff7a4 	b	aab0 <f0+0x340>
    cc24:	aa1703e0 	mov	x0, x23
    cc28:	97ffdd5a 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc2c:	17fff7f7 	b	ac08 <f0+0x498>
    cc30:	aa1703e0 	mov	x0, x23
    cc34:	97ffdd57 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc38:	17fff819 	b	ac9c <f0+0x52c>
    cc3c:	aa1703e0 	mov	x0, x23
    cc40:	97ffdd54 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc44:	17fff842 	b	ad4c <f0+0x5dc>
    cc48:	aa1703e0 	mov	x0, x23
    cc4c:	97ffdd51 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc50:	17fff877 	b	ae2c <f0+0x6bc>
    cc54:	aa1703e0 	mov	x0, x23
    cc58:	97ffdd4e 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc5c:	17fff898 	b	aebc <f0+0x74c>
    cc60:	aa1703e0 	mov	x0, x23
    cc64:	97ffdd4b 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc68:	17fff8ba 	b	af50 <f0+0x7e0>
    cc6c:	aa1703e0 	mov	x0, x23
    cc70:	97ffdd48 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc74:	17fff901 	b	b078 <f0+0x908>
    cc78:	aa1703e0 	mov	x0, x23
    cc7c:	97ffdd45 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc80:	17fff923 	b	b10c <f0+0x99c>
    cc84:	aa1703e0 	mov	x0, x23
    cc88:	97ffdd42 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc8c:	17fff946 	b	b1a4 <f0+0xa34>
    cc90:	aa1703e0 	mov	x0, x23
    cc94:	97ffdd3f 	bl	4190 <fwp_rc_forget_slot.part.0>
    cc98:	17fff971 	b	b25c <f0+0xaec>
    cc9c:	aa1703e0 	mov	x0, x23
    cca0:	97ffdd3c 	bl	4190 <fwp_rc_forget_slot.part.0>
    cca4:	17fff9a3 	b	b330 <f0+0xbc0>
    cca8:	aa1703e0 	mov	x0, x23
    ccac:	97ffdd39 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccb0:	17fff9c6 	b	b3c8 <f0+0xc58>
    ccb4:	aa1503e0 	mov	x0, x21
    ccb8:	97ffdd36 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccbc:	17fff9e8 	b	b45c <f0+0xcec>
    ccc0:	aa1703e0 	mov	x0, x23
    ccc4:	97ffdd33 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccc8:	17fffa60 	b	b648 <f0+0xed8>
    cccc:	aa1703e0 	mov	x0, x23
    ccd0:	97ffdd30 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccd4:	17fffa99 	b	b738 <f0+0xfc8>
    ccd8:	aa1703e0 	mov	x0, x23
    ccdc:	97ffdd2d 	bl	4190 <fwp_rc_forget_slot.part.0>
    cce0:	17fffaee 	b	b898 <f0+0x1128>
    cce4:	aa1703e0 	mov	x0, x23
    cce8:	97ffdd2a 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccec:	17fffb27 	b	b988 <f0+0x1218>
    ccf0:	aa1703e0 	mov	x0, x23
    ccf4:	97ffdd27 	bl	4190 <fwp_rc_forget_slot.part.0>
    ccf8:	17fffb52 	b	ba40 <f0+0x12d0>
    ccfc:	aa1703e0 	mov	x0, x23
    cd00:	97ffdd24 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd04:	17fffb74 	b	bad4 <f0+0x1364>
    cd08:	aa1703e0 	mov	x0, x23
    cd0c:	97ffdd21 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd10:	17fffbb4 	b	bbe0 <f0+0x1470>
    cd14:	aa1703e0 	mov	x0, x23
    cd18:	97ffdd1e 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd1c:	17fffbed 	b	bcd0 <f0+0x1560>
    cd20:	aa1703e0 	mov	x0, x23
    cd24:	97ffdd1b 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd28:	17fffc26 	b	bdc0 <f0+0x1650>
    cd2c:	aa1703e0 	mov	x0, x23
    cd30:	97ffdd18 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd34:	17fffc51 	b	be78 <f0+0x1708>
    cd38:	aa1703e0 	mov	x0, x23
    cd3c:	97ffdd15 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd40:	17fffc73 	b	bf0c <f0+0x179c>
    cd44:	aa1703e0 	mov	x0, x23
    cd48:	97ffdd12 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd4c:	17fffc96 	b	bfa4 <f0+0x1834>
    cd50:	aa1703e0 	mov	x0, x23
    cd54:	97ffdd0f 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd58:	17fffcb8 	b	c038 <f0+0x18c8>
    cd5c:	aa1703e0 	mov	x0, x23
    cd60:	97ffdd0c 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd64:	17fffcff 	b	c160 <f0+0x19f0>
    cd68:	aa1703e0 	mov	x0, x23
    cd6c:	97ffdd09 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd70:	17fffd22 	b	c1f8 <f0+0x1a88>
    cd74:	aa1703e0 	mov	x0, x23
    cd78:	97ffdd06 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd7c:	17fffd5b 	b	c2e8 <f0+0x1b78>
    cd80:	aa1703e0 	mov	x0, x23
    cd84:	97ffdd03 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd88:	17fffd86 	b	c3a0 <f0+0x1c30>
    cd8c:	aa1703e0 	mov	x0, x23
    cd90:	97ffdd00 	bl	4190 <fwp_rc_forget_slot.part.0>
    cd94:	17fffda8 	b	c434 <f0+0x1cc4>
    cd98:	aa1703e0 	mov	x0, x23
    cd9c:	97ffdcfd 	bl	4190 <fwp_rc_forget_slot.part.0>
    cda0:	17fffdcb 	b	c4cc <f0+0x1d5c>
    cda4:	aa1703e0 	mov	x0, x23
    cda8:	97ffdcfa 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdac:	17fffe04 	b	c5bc <f0+0x1e4c>
    cdb0:	aa1703e0 	mov	x0, x23
    cdb4:	97ffdcf7 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdb8:	17fffe3d 	b	c6ac <f0+0x1f3c>
    cdbc:	aa1703e0 	mov	x0, x23
    cdc0:	97ffdcf4 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdc4:	17fffe84 	b	c7d4 <f0+0x2064>
    cdc8:	aa1503e0 	mov	x0, x21
    cdcc:	97ffdcf1 	bl	4190 <fwp_rc_forget_slot.part.0>
    cdd0:	17fffea6 	b	c868 <f0+0x20f8>
    cdd4:	97ffd6ab 	bl	2880 <__stack_chk_fail@plt>
    cdd8:	97ffd6be 	bl	28d0 <abort@plt>
    cddc:	d503201f 	nop

000000000000cde0 <fwp_main_thread>:
    cde0:	d10443ff 	sub	sp, sp, #0x110
    cde4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cde8:	f947f400 	ldr	x0, [x0, #4072]
    cdec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cdf0:	910303fd 	add	x29, sp, #0xc0
    cdf4:	a90d53f3 	stp	x19, x20, [sp, #208]
    cdf8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    cdfc:	91174261 	add	x1, x19, #0x5d0
    ce00:	a90e5bf5 	stp	x21, x22, [sp, #224]
    ce04:	b953a421 	ldr	w1, [x1, #5028]
    ce08:	f9400002 	ldr	x2, [x0]
    ce0c:	f9005fe2 	str	x2, [sp, #184]
    ce10:	d2800002 	mov	x2, #0x0                   	// #0
    ce14:	34000ea1 	cbz	w1, cfe8 <fwp_main_thread+0x208>
    ce18:	91174273 	add	x19, x19, #0x5d0
    ce1c:	b953aa60 	ldr	w0, [x19, #5032]
    ce20:	35000dc0 	cbnz	w0, cfd8 <fwp_main_thread+0x1f8>
    ce24:	91001fe2 	add	x2, sp, #0x7
    ce28:	900000b4 	adrp	x20, 20000 <__data_start>
    ce2c:	900000a3 	adrp	x3, 20000 <__data_start>
    ce30:	9101c293 	add	x19, x20, #0x70
    ce34:	910fc063 	add	x3, x3, #0x3f0
    ce38:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    ce3c:	d2a00025 	mov	x5, #0x10000               	// #65536
    ce40:	910023e0 	add	x0, sp, #0x8
    ce44:	d2800001 	mov	x1, #0x0                   	// #0
    ce48:	f90007e3 	str	x3, [sp, #8]
    ce4c:	b90013ff 	str	wzr, [sp, #16]
    ce50:	a9019262 	stp	x2, x4, [x19, #24]
    ce54:	f9000fe5 	str	x5, [sp, #24]
    ce58:	97ffd622 	bl	26e0 <sigaltstack@plt>
    ce5c:	35000220 	cbnz	w0, cea0 <fwp_main_thread+0xc0>
    ce60:	4f000400 	movi	v0.4s, #0x0
    ce64:	9100a3e0 	add	x0, sp, #0x28
    ce68:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    ce6c:	52800082 	mov	w2, #0x4                   	// #4
    ce70:	9101c021 	add	x1, x1, #0x70
    ce74:	72a10002 	movk	w2, #0x800, lsl #16
    ce78:	910083f5 	add	x21, sp, #0x20
    ce7c:	f90013e1 	str	x1, [sp, #32]
    ce80:	3d802000 	str	q0, [x0, #128]
    ce84:	b900abe2 	str	w2, [sp, #168]
    ce88:	ad000000 	stp	q0, q0, [x0]
    ce8c:	ad010000 	stp	q0, q0, [x0, #32]
    ce90:	ad020000 	stp	q0, q0, [x0, #64]
    ce94:	ad030000 	stp	q0, q0, [x0, #96]
    ce98:	97ffd66a 	bl	2840 <sigemptyset@plt>
    ce9c:	340000c0 	cbz	w0, ceb4 <fwp_main_thread+0xd4>
    cea0:	d0000000 	adrp	x0, e000 <_IO_stdin_used+0x5c0>
    cea4:	9102c000 	add	x0, x0, #0xb0
    cea8:	a90f63f7 	stp	x23, x24, [sp, #240]
    ceac:	f90083f9 	str	x25, [sp, #256]
    ceb0:	97ffdc98 	bl	4110 <fwp_trap>
    ceb4:	aa1503e1 	mov	x1, x21
    ceb8:	d2800002 	mov	x2, #0x0                   	// #0
    cebc:	52800160 	mov	w0, #0xb                   	// #11
    cec0:	97ffd678 	bl	28a0 <sigaction@plt>
    cec4:	35fffee0 	cbnz	w0, cea0 <fwp_main_thread+0xc0>
    cec8:	aa1503e1 	mov	x1, x21
    cecc:	d2800002 	mov	x2, #0x0                   	// #0
    ced0:	528000e0 	mov	w0, #0x7                   	// #7
    ced4:	97ffd673 	bl	28a0 <sigaction@plt>
    ced8:	35fffe40 	cbnz	w0, cea0 <fwp_main_thread+0xc0>
    cedc:	b9434a60 	ldr	w0, [x19, #840]
    cee0:	34000880 	cbz	w0, cff0 <fwp_main_thread+0x210>
    cee4:	a90f63f7 	stp	x23, x24, [sp, #240]
    cee8:	9101c293 	add	x19, x20, #0x70
    ceec:	b9434e60 	ldr	w0, [x19, #844]
    cef0:	34001e80 	cbz	w0, d2c0 <fwp_main_thread+0x4e0>
    cef4:	9101c296 	add	x22, x20, #0x70
    cef8:	f9400ad5 	ldr	x21, [x22, #16]
    cefc:	b4000d95 	cbz	x21, d0ac <fwp_main_thread+0x2cc>
    cf00:	910102b7 	add	x23, x21, #0x40
    cf04:	f90083f9 	str	x25, [sp, #256]
    cf08:	52800038 	mov	w24, #0x1                   	// #1
    cf0c:	39414ab9 	ldrb	w25, [x21, #82]
    cf10:	39014ab8 	strb	w24, [x21, #82]
    cf14:	d503201f 	nop
    cf18:	f94016a0 	ldr	x0, [x21, #40]
    cf1c:	b4000c40 	cbz	x0, d0a4 <fwp_main_thread+0x2c4>
    cf20:	f94032a1 	ldr	x1, [x21, #96]
    cf24:	394146a0 	ldrb	w0, [x21, #81]
    cf28:	b4000861 	cbz	x1, d034 <fwp_main_thread+0x254>
    cf2c:	36000720 	tbz	w0, #0, d010 <fwp_main_thread+0x230>
    cf30:	f9400ad3 	ldr	x19, [x22, #16]
    cf34:	f94022a0 	ldr	x0, [x21, #64]
    cf38:	39414a61 	ldrb	w1, [x19, #82]
    cf3c:	37000a41 	tbnz	w1, #0, d084 <fwp_main_thread+0x2a4>
    cf40:	f9403261 	ldr	x1, [x19, #96]
    cf44:	a911fe77 	stp	x23, xzr, [x19, #280]
    cf48:	f9009660 	str	x0, [x19, #296]
    cf4c:	b4000040 	cbz	x0, cf54 <fwp_main_thread+0x174>
    cf50:	f9009013 	str	x19, [x0, #288]
    cf54:	f90022b3 	str	x19, [x21, #64]
    cf58:	b4000101 	cbz	x1, cf78 <fwp_main_thread+0x198>
    cf5c:	f9406ec0 	ldr	x0, [x22, #216]
    cf60:	39015678 	strb	w24, [x19, #85]
    cf64:	f9003661 	str	x1, [x19, #104]
    cf68:	a910827f 	stp	xzr, x0, [x19, #264]
    cf6c:	b4000040 	cbz	x0, cf74 <fwp_main_thread+0x194>
    cf70:	f9008413 	str	x19, [x0, #264]
    cf74:	f9006ed3 	str	x19, [x22, #216]
    cf78:	39015a7f 	strb	wzr, [x19, #86]
    cf7c:	97ffe6bd 	bl	6a70 <fwp_block>
    cf80:	f9408e62 	ldr	x2, [x19, #280]
    cf84:	b4000142 	cbz	x2, cfac <fwp_main_thread+0x1cc>
    cf88:	a9520261 	ldp	x1, x0, [x19, #288]
    cf8c:	b4000881 	cbz	x1, d09c <fwp_main_thread+0x2bc>
    cf90:	f9009420 	str	x0, [x1, #296]
    cf94:	f9409660 	ldr	x0, [x19, #296]
    cf98:	b4000040 	cbz	x0, cfa0 <fwp_main_thread+0x1c0>
    cf9c:	f9009001 	str	x1, [x0, #288]
    cfa0:	91080260 	add	x0, x19, #0x200
    cfa4:	f900967f 	str	xzr, [x19, #296]
    cfa8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cfac:	39415660 	ldrb	w0, [x19, #85]
    cfb0:	3607fb40 	tbz	w0, #0, cf18 <fwp_main_thread+0x138>
    cfb4:	a9508261 	ldp	x1, x0, [x19, #264]
    cfb8:	b4001801 	cbz	x1, d2b8 <fwp_main_thread+0x4d8>
    cfbc:	f9008820 	str	x0, [x1, #272]
    cfc0:	b4000040 	cbz	x0, cfc8 <fwp_main_thread+0x1e8>
    cfc4:	f9008401 	str	x1, [x0, #264]
    cfc8:	91080260 	add	x0, x19, #0x200
    cfcc:	3901567f 	strb	wzr, [x19, #85]
    cfd0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cfd4:	17ffffd1 	b	cf18 <fwp_main_thread+0x138>
    cfd8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cfdc:	91301000 	add	x0, x0, #0xc04
    cfe0:	9400028c 	bl	da10 <atexit>
    cfe4:	17ffff90 	b	ce24 <fwp_main_thread+0x44>
    cfe8:	97ffdb62 	bl	3d70 <fwp_heap_init>
    cfec:	17ffff8b 	b	ce18 <fwp_main_thread+0x38>
    cff0:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cff4:	91058000 	add	x0, x0, #0x160
    cff8:	94000286 	bl	da10 <atexit>
    cffc:	a90f63f7 	stp	x23, x24, [sp, #240]
    d000:	35001860 	cbnz	w0, d30c <fwp_main_thread+0x52c>
    d004:	52800020 	mov	w0, #0x1                   	// #1
    d008:	b9034a60 	str	w0, [x19, #840]
    d00c:	17ffffb7 	b	cee8 <fwp_main_thread+0x108>
    d010:	97ffde60 	bl	4990 <fwp_now_ns>
    d014:	f94032a1 	ldr	x1, [x21, #96]
    d018:	eb01001f 	cmp	x0, x1
    d01c:	540000ab 	b.lt	d030 <fwp_main_thread+0x250>  // b.tstop
    d020:	394142a0 	ldrb	w0, [x21, #80]
    d024:	37000060 	tbnz	w0, #0, d030 <fwp_main_thread+0x250>
    d028:	aa1503e0 	mov	x0, x21
    d02c:	97ffd9b1 	bl	36f0 <fwp_cancel_tree.part.0>
    d030:	394146a0 	ldrb	w0, [x21, #81]
    d034:	f9400ad3 	ldr	x19, [x22, #16]
    d038:	39414a62 	ldrb	w2, [x19, #82]
    d03c:	3707f7a0 	tbnz	w0, #0, cf30 <fwp_main_thread+0x150>
    d040:	f94032a1 	ldr	x1, [x21, #96]
    d044:	370001c2 	tbnz	w2, #0, d07c <fwp_main_thread+0x29c>
    d048:	f9403260 	ldr	x0, [x19, #96]
    d04c:	b4000180 	cbz	x0, d07c <fwp_main_thread+0x29c>
    d050:	b4000061 	cbz	x1, d05c <fwp_main_thread+0x27c>
    d054:	eb01001f 	cmp	x0, x1
    d058:	9a81d000 	csel	x0, x0, x1, le
    d05c:	f94022a1 	ldr	x1, [x21, #64]
    d060:	a911fe77 	stp	x23, xzr, [x19, #280]
    d064:	f9009661 	str	x1, [x19, #296]
    d068:	b4001361 	cbz	x1, d2d4 <fwp_main_thread+0x4f4>
    d06c:	f9009033 	str	x19, [x1, #288]
    d070:	aa0003e1 	mov	x1, x0
    d074:	f90022b3 	str	x19, [x21, #64]
    d078:	17ffffb9 	b	cf5c <fwp_main_thread+0x17c>
    d07c:	f94022a0 	ldr	x0, [x21, #64]
    d080:	17ffffb1 	b	cf44 <fwp_main_thread+0x164>
    d084:	a911fe77 	stp	x23, xzr, [x19, #280]
    d088:	f9009660 	str	x0, [x19, #296]
    d08c:	b4000040 	cbz	x0, d094 <fwp_main_thread+0x2b4>
    d090:	f9009013 	str	x19, [x0, #288]
    d094:	f90022b3 	str	x19, [x21, #64]
    d098:	17ffffb8 	b	cf78 <fwp_main_thread+0x198>
    d09c:	f9000040 	str	x0, [x2]
    d0a0:	17ffffbe 	b	cf98 <fwp_main_thread+0x1b8>
    d0a4:	39014ab9 	strb	w25, [x21, #82]
    d0a8:	f94083f9 	ldr	x25, [sp, #256]
    d0ac:	9101c293 	add	x19, x20, #0x70
    d0b0:	f9419660 	ldr	x0, [x19, #808]
    d0b4:	b5000060 	cbnz	x0, d0c0 <fwp_main_thread+0x2e0>
    d0b8:	f9419e60 	ldr	x0, [x19, #824]
    d0bc:	b4001120 	cbz	x0, d2e0 <fwp_main_thread+0x500>
    d0c0:	9101c280 	add	x0, x20, #0x70
    d0c4:	f9400800 	ldr	x0, [x0, #16]
    d0c8:	9101c281 	add	x1, x20, #0x70
    d0cc:	f941b026 	ldr	x6, [x1, #864]
    d0d0:	b903583f 	str	wzr, [x1, #856]
    d0d4:	eb0000df 	cmp	x6, x0
    d0d8:	540011e1 	b.ne	d314 <fwp_main_thread+0x534>  // b.any
    d0dc:	b40003c0 	cbz	x0, d154 <fwp_main_thread+0x374>
    d0e0:	f9418025 	ldr	x5, [x1, #768]
    d0e4:	52800021 	mov	w1, #0x1                   	// #1
    d0e8:	39014801 	strb	w1, [x0, #82]
    d0ec:	b4000345 	cbz	x5, d154 <fwp_main_thread+0x374>
    d0f0:	394140a0 	ldrb	w0, [x5, #80]
    d0f4:	37000060 	tbnz	w0, #0, d100 <fwp_main_thread+0x320>
    d0f8:	aa0503e0 	mov	x0, x5
    d0fc:	97ffd97d 	bl	36f0 <fwp_cancel_tree.part.0>
    d100:	f9409ca5 	ldr	x5, [x5, #312]
    d104:	b5ffff65 	cbnz	x5, d0f0 <fwp_main_thread+0x310>
    d108:	9101c293 	add	x19, x20, #0x70
    d10c:	52800035 	mov	w21, #0x1                   	// #1
    d110:	f94028c0 	ldr	x0, [x6, #80]
    d114:	f2001c1f 	tst	x0, #0xff000000ff
    d118:	540000e1 	b.ne	d134 <fwp_main_thread+0x354>  // b.any
    d11c:	f9403e60 	ldr	x0, [x19, #120]
    d120:	390150d5 	strb	w21, [x6, #84]
    d124:	f90080df 	str	xzr, [x6, #256]
    d128:	b4000120 	cbz	x0, d14c <fwp_main_thread+0x36c>
    d12c:	f9008006 	str	x6, [x0, #256]
    d130:	f9003e66 	str	x6, [x19, #120]
    d134:	97ffe64f 	bl	6a70 <fwp_block>
    d138:	97ffe5d6 	bl	6890 <fwp_free_zombie>
    d13c:	f9418260 	ldr	x0, [x19, #768]
    d140:	b40000a0 	cbz	x0, d154 <fwp_main_thread+0x374>
    d144:	f941b266 	ldr	x6, [x19, #864]
    d148:	17fffff2 	b	d110 <fwp_main_thread+0x330>
    d14c:	f9004266 	str	x6, [x19, #128]
    d150:	17fffff8 	b	d130 <fwp_main_thread+0x350>
    d154:	9101c295 	add	x21, x20, #0x70
    d158:	97ffe5ce 	bl	6890 <fwp_free_zombie>
    d15c:	f94042a0 	ldr	x0, [x21, #128]
    d160:	b5000da0 	cbnz	x0, d314 <fwp_main_thread+0x534>
    d164:	f9406ea0 	ldr	x0, [x21, #216]
    d168:	b5000d60 	cbnz	x0, d314 <fwp_main_thread+0x534>
    d16c:	b940fab3 	ldr	w19, [x21, #248]
    d170:	340001f3 	cbz	w19, d1ac <fwp_main_thread+0x3cc>
    d174:	93407e76 	sxtw	x22, w19
    d178:	51000673 	sub	w19, w19, #0x1
    d17c:	d1000ad6 	sub	x22, x22, #0x2
    d180:	910402b7 	add	x23, x21, #0x100
    d184:	cb3342d6 	sub	x22, x22, w19, uxtw
    d188:	93407e73 	sxtw	x19, w19
    d18c:	d503201f 	nop
    d190:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    d194:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d198:	b900fab3 	str	w19, [x21, #248]
    d19c:	d1000673 	sub	x19, x19, #0x1
    d1a0:	97ffd600 	bl	29a0 <munmap@plt>
    d1a4:	eb1302df 	cmp	x22, x19
    d1a8:	54ffff41 	b.ne	d190 <fwp_main_thread+0x3b0>  // b.any
    d1ac:	f0000093 	adrp	x19, 20000 <__data_start>
    d1b0:	91004260 	add	x0, x19, #0x10
    d1b4:	b9404800 	ldr	w0, [x0, #72]
    d1b8:	37f80040 	tbnz	w0, #31, d1c0 <fwp_main_thread+0x3e0>
    d1bc:	97ffd5b5 	bl	2890 <close@plt>
    d1c0:	9101c295 	add	x21, x20, #0x70
    d1c4:	91004273 	add	x19, x19, #0x10
    d1c8:	12800001 	mov	w1, #0xffffffff            	// #-1
    d1cc:	f941baa0 	ldr	x0, [x21, #880]
    d1d0:	b9004a61 	str	w1, [x19, #72]
    d1d4:	f941b6a1 	ldr	x1, [x21, #872]
    d1d8:	b40001c0 	cbz	x0, d210 <fwp_main_thread+0x430>
    d1dc:	d2800013 	mov	x19, #0x0                   	// #0
    d1e0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    d1e4:	b40000e0 	cbz	x0, d200 <fwp_main_thread+0x420>
    d1e8:	f9400001 	ldr	x1, [x0]
    d1ec:	b5000941 	cbnz	x1, d314 <fwp_main_thread+0x534>
    d1f0:	f9400401 	ldr	x1, [x0, #8]
    d1f4:	b5000901 	cbnz	x1, d314 <fwp_main_thread+0x534>
    d1f8:	97ffdc82 	bl	4400 <fwp_mem_free>
    d1fc:	f941b6a1 	ldr	x1, [x21, #872]
    d200:	91000673 	add	x19, x19, #0x1
    d204:	f941baa0 	ldr	x0, [x21, #880]
    d208:	eb00027f 	cmp	x19, x0
    d20c:	54fffea3 	b.cc	d1e0 <fwp_main_thread+0x400>  // b.lo, b.ul, b.last
    d210:	aa0103e0 	mov	x0, x1
    d214:	97ffdc7b 	bl	4400 <fwp_mem_free>
    d218:	9101c280 	add	x0, x20, #0x70
    d21c:	f941b013 	ldr	x19, [x0, #864]
    d220:	f901b41f 	str	xzr, [x0, #872]
    d224:	f901b81f 	str	xzr, [x0, #880]
    d228:	b40001f3 	cbz	x19, d264 <fwp_main_thread+0x484>
    d22c:	f9401661 	ldr	x1, [x19, #40]
    d230:	b5000721 	cbnz	x1, d314 <fwp_main_thread+0x534>
    d234:	f9405661 	ldr	x1, [x19, #168]
    d238:	b50006e1 	cbnz	x1, d314 <fwp_main_thread+0x534>
    d23c:	f9419401 	ldr	x1, [x0, #808]
    d240:	b50006a1 	cbnz	x1, d314 <fwp_main_thread+0x534>
    d244:	f9419c00 	ldr	x0, [x0, #824]
    d248:	b5000660 	cbnz	x0, d314 <fwp_main_thread+0x534>
    d24c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d250:	f0000100 	adrp	x0, 30000 <alt.5+0xfc10>
    d254:	910fc000 	add	x0, x0, #0x3f0
    d258:	97ffd57e 	bl	2850 <memset@plt>
    d25c:	aa1303e0 	mov	x0, x19
    d260:	97ffdc68 	bl	4400 <fwp_mem_free>
    d264:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    d268:	f947ec00 	ldr	x0, [x0, #4056]
    d26c:	9101c294 	add	x20, x20, #0x70
    d270:	f9400000 	ldr	x0, [x0]
    d274:	f9000a9f 	str	xzr, [x20, #16]
    d278:	f901b29f 	str	xzr, [x20, #864]
    d27c:	97ffd5cd 	bl	29b0 <fflush@plt>
    d280:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    d284:	f947f400 	ldr	x0, [x0, #4072]
    d288:	f9405fe2 	ldr	x2, [sp, #184]
    d28c:	f9400001 	ldr	x1, [x0]
    d290:	eb010042 	subs	x2, x2, x1
    d294:	d2800001 	mov	x1, #0x0                   	// #0
    d298:	54000361 	b.ne	d304 <fwp_main_thread+0x524>  // b.any
    d29c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d2a0:	d2800000 	mov	x0, #0x0                   	// #0
    d2a4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d2a8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d2ac:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d2b0:	910443ff 	add	sp, sp, #0x110
    d2b4:	d65f03c0 	ret
    d2b8:	f9006ec0 	str	x0, [x22, #216]
    d2bc:	17ffff41 	b	cfc0 <fwp_main_thread+0x1e0>
    d2c0:	97fff52c 	bl	a770 <f0>
    d2c4:	f901aa60 	str	x0, [x19, #848]
    d2c8:	52800021 	mov	w1, #0x1                   	// #1
    d2cc:	b9034e61 	str	w1, [x19, #844]
    d2d0:	17ffff09 	b	cef4 <fwp_main_thread+0x114>
    d2d4:	aa0003e1 	mov	x1, x0
    d2d8:	f90022b3 	str	x19, [x21, #64]
    d2dc:	17ffff20 	b	cf5c <fwp_main_thread+0x17c>
    d2e0:	f9419260 	ldr	x0, [x19, #800]
    d2e4:	97ffdc47 	bl	4400 <fwp_mem_free>
    d2e8:	f901927f 	str	xzr, [x19, #800]
    d2ec:	f9400a60 	ldr	x0, [x19, #16]
    d2f0:	f9019a7f 	str	xzr, [x19, #816]
    d2f4:	b4ffeea0 	cbz	x0, d0c8 <fwp_main_thread+0x2e8>
    d2f8:	f900541f 	str	xzr, [x0, #168]
    d2fc:	f9005c1f 	str	xzr, [x0, #184]
    d300:	17ffff72 	b	d0c8 <fwp_main_thread+0x2e8>
    d304:	f90083f9 	str	x25, [sp, #256]
    d308:	97ffd55e 	bl	2880 <__stack_chk_fail@plt>
    d30c:	f90083f9 	str	x25, [sp, #256]
    d310:	97ffd788 	bl	3130 <descent_phase_fail>
    d314:	f90083f9 	str	x25, [sp, #256]
    d318:	97ffd56e 	bl	28d0 <abort@plt>
    d31c:	d503201f 	nop

000000000000d320 <__divti3>:
    d320:	d503245f 	bti	c
    d324:	d2800004 	mov	x4, #0x0                   	// #0
    d328:	b7f80721 	tbnz	x1, #63, d40c <__divti3+0xec>
    d32c:	b6f80083 	tbz	x3, #63, d33c <__divti3+0x1c>
    d330:	eb0203e2 	negs	x2, x2
    d334:	aa2403e4 	mvn	x4, x4
    d338:	da0303e3 	ngc	x3, x3
    d33c:	aa0203e6 	mov	x6, x2
    d340:	aa0003e7 	mov	x7, x0
    d344:	aa0103e5 	mov	x5, x1
    d348:	b5000583 	cbnz	x3, d3f8 <__divti3+0xd8>
    d34c:	eb01005f 	cmp	x2, x1
    d350:	54000e69 	b.ls	d51c <__divti3+0x1fc>  // b.plast
    d354:	dac01040 	clz	x0, x2
    d358:	b40000e0 	cbz	x0, d374 <__divti3+0x54>
    d35c:	4b0003e1 	neg	w1, w0
    d360:	9ac020a5 	lsl	x5, x5, x0
    d364:	9ac02046 	lsl	x6, x2, x0
    d368:	9ac124e1 	lsr	x1, x7, x1
    d36c:	aa050025 	orr	x5, x1, x5
    d370:	9ac020e7 	lsl	x7, x7, x0
    d374:	d360fcc8 	lsr	x8, x6, #32
    d378:	92407cc2 	and	x2, x6, #0xffffffff
    d37c:	9ac808a3 	udiv	x3, x5, x8
    d380:	9b089465 	msub	x5, x3, x8, x5
    d384:	aa0303e0 	mov	x0, x3
    d388:	9b037c41 	mul	x1, x2, x3
    d38c:	93c780a5 	extr	x5, x5, x7, #32
    d390:	eb05003f 	cmp	x1, x5
    d394:	540000a9 	b.ls	d3a8 <__divti3+0x88>  // b.plast
    d398:	ab0500c5 	adds	x5, x6, x5
    d39c:	d1000460 	sub	x0, x3, #0x1
    d3a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d3a4:	540015a8 	b.hi	d658 <__divti3+0x338>  // b.pmore
    d3a8:	cb0100a5 	sub	x5, x5, x1
    d3ac:	9ac808a3 	udiv	x3, x5, x8
    d3b0:	9b089465 	msub	x5, x3, x8, x5
    d3b4:	aa0303e1 	mov	x1, x3
    d3b8:	9b037c42 	mul	x2, x2, x3
    d3bc:	aa0703e3 	mov	x3, x7
    d3c0:	b3607ca3 	bfi	x3, x5, #32, #32
    d3c4:	eb03005f 	cmp	x2, x3
    d3c8:	540000c9 	b.ls	d3e0 <__divti3+0xc0>  // b.plast
    d3cc:	ab0300c3 	adds	x3, x6, x3
    d3d0:	d1000425 	sub	x5, x1, #0x1
    d3d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d3d8:	d1000821 	sub	x1, x1, #0x2
    d3dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d3e0:	aa008020 	orr	x0, x1, x0, lsl #32
    d3e4:	d2800001 	mov	x1, #0x0                   	// #0
    d3e8:	b4000064 	cbz	x4, d3f4 <__divti3+0xd4>
    d3ec:	eb0003e0 	negs	x0, x0
    d3f0:	da0103e1 	ngc	x1, x1
    d3f4:	d65f03c0 	ret
    d3f8:	eb01007f 	cmp	x3, x1
    d3fc:	54000109 	b.ls	d41c <__divti3+0xfc>  // b.plast
    d400:	d2800001 	mov	x1, #0x0                   	// #0
    d404:	d2800000 	mov	x0, #0x0                   	// #0
    d408:	17fffff8 	b	d3e8 <__divti3+0xc8>
    d40c:	eb0003e0 	negs	x0, x0
    d410:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d414:	da0103e1 	ngc	x1, x1
    d418:	17ffffc5 	b	d32c <__divti3+0xc>
    d41c:	dac01067 	clz	x7, x3
    d420:	b40010e7 	cbz	x7, d63c <__divti3+0x31c>
    d424:	d2800805 	mov	x5, #0x40                  	// #64
    d428:	cb0700a5 	sub	x5, x5, x7
    d42c:	9ac72063 	lsl	x3, x3, x7
    d430:	9ac52448 	lsr	x8, x2, x5
    d434:	aa030108 	orr	x8, x8, x3
    d438:	9ac52426 	lsr	x6, x1, x5
    d43c:	92407d0a 	and	x10, x8, #0xffffffff
    d440:	d360fd09 	lsr	x9, x8, #32
    d444:	9ac52403 	lsr	x3, x0, x5
    d448:	9ac72021 	lsl	x1, x1, x7
    d44c:	aa010063 	orr	x3, x3, x1
    d450:	9ac72042 	lsl	x2, x2, x7
    d454:	9ac908cb 	udiv	x11, x6, x9
    d458:	9b099965 	msub	x5, x11, x9, x6
    d45c:	aa0b03e1 	mov	x1, x11
    d460:	9b0b7d46 	mul	x6, x10, x11
    d464:	93c380a5 	extr	x5, x5, x3, #32
    d468:	eb0500df 	cmp	x6, x5
    d46c:	540000a9 	b.ls	d480 <__divti3+0x160>  // b.plast
    d470:	ab050105 	adds	x5, x8, x5
    d474:	d1000561 	sub	x1, x11, #0x1
    d478:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d47c:	54000f48 	b.hi	d664 <__divti3+0x344>  // b.pmore
    d480:	cb0600a6 	sub	x6, x5, x6
    d484:	9ac908cb 	udiv	x11, x6, x9
    d488:	9b099969 	msub	x9, x11, x9, x6
    d48c:	aa0b03e5 	mov	x5, x11
    d490:	9b0b7d4a 	mul	x10, x10, x11
    d494:	b3607d23 	bfi	x3, x9, #32, #32
    d498:	eb03015f 	cmp	x10, x3
    d49c:	540000a9 	b.ls	d4b0 <__divti3+0x190>  // b.plast
    d4a0:	ab030103 	adds	x3, x8, x3
    d4a4:	d1000565 	sub	x5, x11, #0x1
    d4a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d4ac:	54000e28 	b.hi	d670 <__divti3+0x350>  // b.pmore
    d4b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d4b4:	92407c48 	and	x8, x2, #0xffffffff
    d4b8:	2a0503e5 	mov	w5, w5
    d4bc:	d360fc42 	lsr	x2, x2, #32
    d4c0:	d360fc26 	lsr	x6, x1, #32
    d4c4:	cb0a0063 	sub	x3, x3, x10
    d4c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d4cc:	9b087caa 	mul	x10, x5, x8
    d4d0:	9b087cc8 	mul	x8, x6, x8
    d4d4:	9b0220a5 	madd	x5, x5, x2, x8
    d4d8:	9b027cc6 	mul	x6, x6, x2
    d4dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d4e0:	8b0900c5 	add	x5, x6, x9
    d4e4:	eb02011f 	cmp	x8, x2
    d4e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d4ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    d4f0:	eb06007f 	cmp	x3, x6
    d4f4:	540000e3 	b.cc	d510 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d4f8:	92407d4a 	and	x10, x10, #0xffffffff
    d4fc:	9ac72000 	lsl	x0, x0, x7
    d500:	8b028142 	add	x2, x10, x2, lsl #32
    d504:	eb02001f 	cmp	x0, x2
    d508:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d50c:	54000a01 	b.ne	d64c <__divti3+0x32c>  // b.any
    d510:	d1000420 	sub	x0, x1, #0x1
    d514:	d2800001 	mov	x1, #0x0                   	// #0
    d518:	17ffffb4 	b	d3e8 <__divti3+0xc8>
    d51c:	b5000062 	cbnz	x2, d528 <__divti3+0x208>
    d520:	d2800022 	mov	x2, #0x1                   	// #1
    d524:	9ac30846 	udiv	x6, x2, x3
    d528:	dac010c8 	clz	x8, x6
    d52c:	b5000408 	cbnz	x8, d5ac <__divti3+0x28c>
    d530:	d360fcc9 	lsr	x9, x6, #32
    d534:	92407cc5 	and	x5, x6, #0xffffffff
    d538:	cb060023 	sub	x3, x1, x6
    d53c:	d2800021 	mov	x1, #0x1                   	// #1
    d540:	9ac90868 	udiv	x8, x3, x9
    d544:	9b098d03 	msub	x3, x8, x9, x3
    d548:	aa0803e0 	mov	x0, x8
    d54c:	9b057d02 	mul	x2, x8, x5
    d550:	93c78063 	extr	x3, x3, x7, #32
    d554:	eb03005f 	cmp	x2, x3
    d558:	540000a9 	b.ls	d56c <__divti3+0x24c>  // b.plast
    d55c:	ab0300c3 	adds	x3, x6, x3
    d560:	d1000500 	sub	x0, x8, #0x1
    d564:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d568:	54000968 	b.hi	d694 <__divti3+0x374>  // b.pmore
    d56c:	cb020063 	sub	x3, x3, x2
    d570:	9ac90862 	udiv	x2, x3, x9
    d574:	aa0203e8 	mov	x8, x2
    d578:	9b098c42 	msub	x2, x2, x9, x3
    d57c:	aa0703e3 	mov	x3, x7
    d580:	9b057d05 	mul	x5, x8, x5
    d584:	b3607c43 	bfi	x3, x2, #32, #32
    d588:	eb0300bf 	cmp	x5, x3
    d58c:	540000c9 	b.ls	d5a4 <__divti3+0x284>  // b.plast
    d590:	ab0300c2 	adds	x2, x6, x3
    d594:	d1000503 	sub	x3, x8, #0x1
    d598:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d59c:	d1000908 	sub	x8, x8, #0x2
    d5a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d5a4:	aa008100 	orr	x0, x8, x0, lsl #32
    d5a8:	17ffff90 	b	d3e8 <__divti3+0xc8>
    d5ac:	9ac820c6 	lsl	x6, x6, x8
    d5b0:	d2800803 	mov	x3, #0x40                  	// #64
    d5b4:	cb080063 	sub	x3, x3, x8
    d5b8:	d360fcc9 	lsr	x9, x6, #32
    d5bc:	9ac82027 	lsl	x7, x1, x8
    d5c0:	92407cc5 	and	x5, x6, #0xffffffff
    d5c4:	9ac32422 	lsr	x2, x1, x3
    d5c8:	9ac32403 	lsr	x3, x0, x3
    d5cc:	aa070063 	orr	x3, x3, x7
    d5d0:	9ac9084a 	udiv	x10, x2, x9
    d5d4:	9ac82007 	lsl	x7, x0, x8
    d5d8:	9b098940 	msub	x0, x10, x9, x2
    d5dc:	aa0a03e1 	mov	x1, x10
    d5e0:	9b0a7ca2 	mul	x2, x5, x10
    d5e4:	93c38000 	extr	x0, x0, x3, #32
    d5e8:	eb00005f 	cmp	x2, x0
    d5ec:	540000a9 	b.ls	d600 <__divti3+0x2e0>  // b.plast
    d5f0:	ab0000c0 	adds	x0, x6, x0
    d5f4:	d1000541 	sub	x1, x10, #0x1
    d5f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d5fc:	54000468 	b.hi	d688 <__divti3+0x368>  // b.pmore
    d600:	cb020000 	sub	x0, x0, x2
    d604:	9ac9080a 	udiv	x10, x0, x9
    d608:	9b098140 	msub	x0, x10, x9, x0
    d60c:	aa0a03e2 	mov	x2, x10
    d610:	9b0a7ca8 	mul	x8, x5, x10
    d614:	b3607c03 	bfi	x3, x0, #32, #32
    d618:	eb03011f 	cmp	x8, x3
    d61c:	540000a9 	b.ls	d630 <__divti3+0x310>  // b.plast
    d620:	ab0300c3 	adds	x3, x6, x3
    d624:	d1000542 	sub	x2, x10, #0x1
    d628:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d62c:	54000288 	b.hi	d67c <__divti3+0x35c>  // b.pmore
    d630:	cb080063 	sub	x3, x3, x8
    d634:	aa018041 	orr	x1, x2, x1, lsl #32
    d638:	17ffffc2 	b	d540 <__divti3+0x220>
    d63c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d640:	d2800001 	mov	x1, #0x0                   	// #0
    d644:	9a9f87e0 	cset	x0, ls	// ls = plast
    d648:	17ffff68 	b	d3e8 <__divti3+0xc8>
    d64c:	aa0103e0 	mov	x0, x1
    d650:	d2800001 	mov	x1, #0x0                   	// #0
    d654:	17ffff65 	b	d3e8 <__divti3+0xc8>
    d658:	d1000860 	sub	x0, x3, #0x2
    d65c:	8b0600a5 	add	x5, x5, x6
    d660:	17ffff52 	b	d3a8 <__divti3+0x88>
    d664:	d1000961 	sub	x1, x11, #0x2
    d668:	8b0800a5 	add	x5, x5, x8
    d66c:	17ffff85 	b	d480 <__divti3+0x160>
    d670:	d1000965 	sub	x5, x11, #0x2
    d674:	8b080063 	add	x3, x3, x8
    d678:	17ffff8e 	b	d4b0 <__divti3+0x190>
    d67c:	d1000942 	sub	x2, x10, #0x2
    d680:	8b060063 	add	x3, x3, x6
    d684:	17ffffeb 	b	d630 <__divti3+0x310>
    d688:	d1000941 	sub	x1, x10, #0x2
    d68c:	8b060000 	add	x0, x0, x6
    d690:	17ffffdc 	b	d600 <__divti3+0x2e0>
    d694:	d1000900 	sub	x0, x8, #0x2
    d698:	8b060063 	add	x3, x3, x6
    d69c:	17ffffb4 	b	d56c <__divti3+0x24c>

000000000000d6a0 <__modti3>:
    d6a0:	d503245f 	bti	c
    d6a4:	d2800004 	mov	x4, #0x0                   	// #0
    d6a8:	b6f80081 	tbz	x1, #63, d6b8 <__modti3+0x18>
    d6ac:	eb0003e0 	negs	x0, x0
    d6b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d6b4:	da0103e1 	ngc	x1, x1
    d6b8:	f100007f 	cmp	x3, #0x0
    d6bc:	5400128b 	b.lt	d90c <__modti3+0x26c>  // b.tstop
    d6c0:	aa0003e7 	mov	x7, x0
    d6c4:	aa0103e6 	mov	x6, x1
    d6c8:	540004e1 	b.ne	d764 <__modti3+0xc4>  // b.any
    d6cc:	eb02003f 	cmp	x1, x2
    d6d0:	54000dc2 	b.cs	d888 <__modti3+0x1e8>  // b.hs, b.nlast
    d6d4:	dac01043 	clz	x3, x2
    d6d8:	aa0303e5 	mov	x5, x3
    d6dc:	b40000e3 	cbz	x3, d6f8 <__modti3+0x58>
    d6e0:	4b0303e6 	neg	w6, w3
    d6e4:	9ac32021 	lsl	x1, x1, x3
    d6e8:	9ac32042 	lsl	x2, x2, x3
    d6ec:	9ac62406 	lsr	x6, x0, x6
    d6f0:	aa0100c6 	orr	x6, x6, x1
    d6f4:	9ac32007 	lsl	x7, x0, x3
    d6f8:	d360fc40 	lsr	x0, x2, #32
    d6fc:	92407c43 	and	x3, x2, #0xffffffff
    d700:	9ac008c1 	udiv	x1, x6, x0
    d704:	9b009826 	msub	x6, x1, x0, x6
    d708:	9b017c61 	mul	x1, x3, x1
    d70c:	93c780c6 	extr	x6, x6, x7, #32
    d710:	eb06003f 	cmp	x1, x6
    d714:	540000a9 	b.ls	d728 <__modti3+0x88>  // b.plast
    d718:	ab060046 	adds	x6, x2, x6
    d71c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d720:	8b0200c8 	add	x8, x6, x2
    d724:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d728:	cb0100c6 	sub	x6, x6, x1
    d72c:	9ac008c8 	udiv	x8, x6, x0
    d730:	9b009901 	msub	x1, x8, x0, x6
    d734:	aa0703e0 	mov	x0, x7
    d738:	9b087c63 	mul	x3, x3, x8
    d73c:	b3607c20 	bfi	x0, x1, #32, #32
    d740:	eb00007f 	cmp	x3, x0
    d744:	54001088 	b.hi	d954 <__modti3+0x2b4>  // b.pmore
    d748:	cb030000 	sub	x0, x0, x3
    d74c:	9ac52400 	lsr	x0, x0, x5
    d750:	d2800001 	mov	x1, #0x0                   	// #0
    d754:	b4000064 	cbz	x4, d760 <__modti3+0xc0>
    d758:	eb0003e0 	negs	x0, x0
    d75c:	da0103e1 	ngc	x1, x1
    d760:	d65f03c0 	ret
    d764:	dac01066 	clz	x6, x3
    d768:	eb03003f 	cmp	x1, x3
    d76c:	54ffff43 	b.cc	d754 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d770:	93407cc5 	sxtw	x5, w6
    d774:	d2800808 	mov	x8, #0x40                  	// #64
    d778:	cb050108 	sub	x8, x8, x5
    d77c:	9ac62063 	lsl	x3, x3, x6
    d780:	9ac62025 	lsl	x5, x1, x6
    d784:	9ac82447 	lsr	x7, x2, x8
    d788:	aa0300e7 	orr	x7, x7, x3
    d78c:	9ac82423 	lsr	x3, x1, x8
    d790:	92407cec 	and	x12, x7, #0xffffffff
    d794:	d360fcea 	lsr	x10, x7, #32
    d798:	9ac82401 	lsr	x1, x0, x8
    d79c:	aa050021 	orr	x1, x1, x5
    d7a0:	9ac62042 	lsl	x2, x2, x6
    d7a4:	9ac62000 	lsl	x0, x0, x6
    d7a8:	9aca086b 	udiv	x11, x3, x10
    d7ac:	9b0a8d63 	msub	x3, x11, x10, x3
    d7b0:	aa0b03e5 	mov	x5, x11
    d7b4:	9b0b7d89 	mul	x9, x12, x11
    d7b8:	93c18063 	extr	x3, x3, x1, #32
    d7bc:	eb03013f 	cmp	x9, x3
    d7c0:	540000a9 	b.ls	d7d4 <__modti3+0x134>  // b.plast
    d7c4:	ab0300e3 	adds	x3, x7, x3
    d7c8:	d1000565 	sub	x5, x11, #0x1
    d7cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d7d0:	54001168 	b.hi	d9fc <__modti3+0x35c>  // b.pmore
    d7d4:	cb090063 	sub	x3, x3, x9
    d7d8:	9aca086b 	udiv	x11, x3, x10
    d7dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    d7e0:	aa0b03e9 	mov	x9, x11
    d7e4:	9b0b7d8c 	mul	x12, x12, x11
    d7e8:	b3607d41 	bfi	x1, x10, #32, #32
    d7ec:	eb01019f 	cmp	x12, x1
    d7f0:	540000a9 	b.ls	d804 <__modti3+0x164>  // b.plast
    d7f4:	ab0100e1 	adds	x1, x7, x1
    d7f8:	d1000569 	sub	x9, x11, #0x1
    d7fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d800:	54000f88 	b.hi	d9f0 <__modti3+0x350>  // b.pmore
    d804:	aa058123 	orr	x3, x9, x5, lsl #32
    d808:	92407c4b 	and	x11, x2, #0xffffffff
    d80c:	2a0903e9 	mov	w9, w9
    d810:	d360fc4a 	lsr	x10, x2, #32
    d814:	d360fc63 	lsr	x3, x3, #32
    d818:	cb0c0021 	sub	x1, x1, x12
    d81c:	aa0a03ec 	mov	x12, x10
    d820:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d824:	9b0b7d25 	mul	x5, x9, x11
    d828:	9b0b7c6b 	mul	x11, x3, x11
    d82c:	9b0a2d29 	madd	x9, x9, x10, x11
    d830:	92407caa 	and	x10, x5, #0xffffffff
    d834:	9b0c7c63 	mul	x3, x3, x12
    d838:	8b458125 	add	x5, x9, x5, lsr #32
    d83c:	8b0d0069 	add	x9, x3, x13
    d840:	eb05017f 	cmp	x11, x5
    d844:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d848:	8b058149 	add	x9, x10, x5, lsl #32
    d84c:	8b458063 	add	x3, x3, x5, lsr #32
    d850:	eb03003f 	cmp	x1, x3
    d854:	54000063 	b.cc	d860 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d858:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d85c:	54000082 	b.cs	d86c <__modti3+0x1cc>  // b.hs, b.nlast
    d860:	eb020129 	subs	x9, x9, x2
    d864:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d868:	cb070063 	sub	x3, x3, x7
    d86c:	eb090000 	subs	x0, x0, x9
    d870:	da030021 	sbc	x1, x1, x3
    d874:	9ac62400 	lsr	x0, x0, x6
    d878:	9ac82028 	lsl	x8, x1, x8
    d87c:	aa000100 	orr	x0, x8, x0
    d880:	9ac62421 	lsr	x1, x1, x6
    d884:	17ffffb4 	b	d754 <__modti3+0xb4>
    d888:	b5000062 	cbnz	x2, d894 <__modti3+0x1f4>
    d88c:	d2800023 	mov	x3, #0x1                   	// #1
    d890:	9ac20862 	udiv	x2, x3, x2
    d894:	dac01048 	clz	x8, x2
    d898:	aa0803e5 	mov	x5, x8
    d89c:	b5000668 	cbnz	x8, d968 <__modti3+0x2c8>
    d8a0:	cb020020 	sub	x0, x1, x2
    d8a4:	d360fc49 	lsr	x9, x2, #32
    d8a8:	92407c4a 	and	x10, x2, #0xffffffff
    d8ac:	9ac90801 	udiv	x1, x0, x9
    d8b0:	9b098020 	msub	x0, x1, x9, x0
    d8b4:	9b0a7c21 	mul	x1, x1, x10
    d8b8:	93c78000 	extr	x0, x0, x7, #32
    d8bc:	eb00003f 	cmp	x1, x0
    d8c0:	540000a9 	b.ls	d8d4 <__modti3+0x234>  // b.plast
    d8c4:	ab000040 	adds	x0, x2, x0
    d8c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d8cc:	8b020003 	add	x3, x0, x2
    d8d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d8d4:	cb010001 	sub	x1, x0, x1
    d8d8:	9ac90820 	udiv	x0, x1, x9
    d8dc:	9b098403 	msub	x3, x0, x9, x1
    d8e0:	aa0703e1 	mov	x1, x7
    d8e4:	9b0a7c00 	mul	x0, x0, x10
    d8e8:	b3607c61 	bfi	x1, x3, #32, #32
    d8ec:	eb01001f 	cmp	x0, x1
    d8f0:	540000a9 	b.ls	d904 <__modti3+0x264>  // b.plast
    d8f4:	ab010041 	adds	x1, x2, x1
    d8f8:	8b020022 	add	x2, x1, x2
    d8fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d900:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d904:	cb000020 	sub	x0, x1, x0
    d908:	17ffff91 	b	d74c <__modti3+0xac>
    d90c:	eb0203e5 	negs	x5, x2
    d910:	aa0003e7 	mov	x7, x0
    d914:	da0303e8 	ngc	x8, x3
    d918:	aa0503e2 	mov	x2, x5
    d91c:	aa0803e3 	mov	x3, x8
    d920:	aa0103e6 	mov	x6, x1
    d924:	b4ffed48 	cbz	x8, d6cc <__modti3+0x2c>
    d928:	eb01011f 	cmp	x8, x1
    d92c:	54fff148 	b.hi	d754 <__modti3+0xb4>  // b.pmore
    d930:	dac01109 	clz	x9, x8
    d934:	2a0903e6 	mov	w6, w9
    d938:	b5fff1c9 	cbnz	x9, d770 <__modti3+0xd0>
    d93c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d940:	54000068 	b.hi	d94c <__modti3+0x2ac>  // b.pmore
    d944:	eb050007 	subs	x7, x0, x5
    d948:	da080021 	sbc	x1, x1, x8
    d94c:	aa0703e0 	mov	x0, x7
    d950:	17ffff81 	b	d754 <__modti3+0xb4>
    d954:	ab000040 	adds	x0, x2, x0
    d958:	8b020002 	add	x2, x0, x2
    d95c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d960:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d964:	17ffff79 	b	d748 <__modti3+0xa8>
    d968:	9ac82042 	lsl	x2, x2, x8
    d96c:	d2800803 	mov	x3, #0x40                  	// #64
    d970:	cb080063 	sub	x3, x3, x8
    d974:	d360fc49 	lsr	x9, x2, #32
    d978:	9ac82027 	lsl	x7, x1, x8
    d97c:	92407c4a 	and	x10, x2, #0xffffffff
    d980:	9ac32426 	lsr	x6, x1, x3
    d984:	9ac32403 	lsr	x3, x0, x3
    d988:	aa070063 	orr	x3, x3, x7
    d98c:	9ac908c1 	udiv	x1, x6, x9
    d990:	9ac82007 	lsl	x7, x0, x8
    d994:	9b099820 	msub	x0, x1, x9, x6
    d998:	9b017d41 	mul	x1, x10, x1
    d99c:	93c38000 	extr	x0, x0, x3, #32
    d9a0:	eb00003f 	cmp	x1, x0
    d9a4:	540000a9 	b.ls	d9b8 <__modti3+0x318>  // b.plast
    d9a8:	ab000040 	adds	x0, x2, x0
    d9ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d9b0:	8b020006 	add	x6, x0, x2
    d9b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d9b8:	cb010000 	sub	x0, x0, x1
    d9bc:	9ac90801 	udiv	x1, x0, x9
    d9c0:	9b098026 	msub	x6, x1, x9, x0
    d9c4:	aa0303e0 	mov	x0, x3
    d9c8:	9b017d41 	mul	x1, x10, x1
    d9cc:	b3607cc0 	bfi	x0, x6, #32, #32
    d9d0:	eb00003f 	cmp	x1, x0
    d9d4:	540000a9 	b.ls	d9e8 <__modti3+0x348>  // b.plast
    d9d8:	ab000040 	adds	x0, x2, x0
    d9dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d9e0:	8b020003 	add	x3, x0, x2
    d9e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d9e8:	cb010000 	sub	x0, x0, x1
    d9ec:	17ffffb0 	b	d8ac <__modti3+0x20c>
    d9f0:	d1000969 	sub	x9, x11, #0x2
    d9f4:	8b070021 	add	x1, x1, x7
    d9f8:	17ffff83 	b	d804 <__modti3+0x164>
    d9fc:	d1000965 	sub	x5, x11, #0x2
    da00:	8b070063 	add	x3, x3, x7
    da04:	17ffff74 	b	d7d4 <__modti3+0x134>
    da08:	d503201f 	nop
    da0c:	d503201f 	nop

000000000000da10 <atexit>:
    da10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    da14:	f0000082 	adrp	x2, 20000 <__data_start>
    da18:	d2800001 	mov	x1, #0x0                   	// #0
    da1c:	910003fd 	mov	x29, sp
    da20:	a8c17bfd 	ldp	x29, x30, [sp], #16
    da24:	f9400442 	ldr	x2, [x2, #8]
    da28:	17ffd356 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000da2c <_fini>:
    da2c:	d503201f 	nop
    da30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    da34:	910003fd 	mov	x29, sp
    da38:	a8c17bfd 	ldp	x29, x30, [sp], #16
    da3c:	d65f03c0 	ret
