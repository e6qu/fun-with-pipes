
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-199/fwp-ad-history-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	d0000045 	adrp	x5, c000 <_IO_stdin_used+0x460>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910200a5 	add	x5, x5, #0x80
    2a20:	d0000044 	adrp	x4, c000 <_IO_stdin_used+0x460>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91022084 	add	x4, x4, #0x88
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	94000619 	bl	42b4 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	910182a1 	add	x1, x21, #0x60
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10060>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9008c20 	str	x0, [x1, #280]
    2aac:	94000821 	bl	4b30 <fwp_now_ns>
    2ab0:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2ab4:	91112000 	add	x0, x0, #0x448
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x280>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9135c042 	add	x2, x2, #0xd70
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910182b5 	add	x21, x21, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943daa0 	ldr	w0, [x21, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2bcc:	9111e000 	add	x0, x0, #0x478
    2bd0:	940005b9 	bl	42b4 <fwp_trap>
    2bd4:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2bd8:	91116000 	add	x0, x0, #0x458
    2bdc:	940005b6 	bl	42b4 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff46 	bl	2900 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffeeb 	bl	27c0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2c20:	91134000 	add	x0, x0, #0x4d0
    2c24:	940005a4 	bl	42b4 <fwp_trap>
    2c28:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2c2c:	91128000 	add	x0, x0, #0x4a0
    2c30:	940005a1 	bl	42b4 <fwp_trap>
    2c34:	d0000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    2c38:	9113e000 	add	x0, x0, #0x4f8
    2c3c:	9400059e 	bl	42b4 <fwp_trap>
    2c40:	97fffef4 	bl	2810 <__stack_chk_fail@plt>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0x460>
    2e34:	912cc021 	add	x1, x1, #0xb30
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x460>
    30d8:	912c4021 	add	x1, x1, #0xb10
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    3110:	912ea000 	add	x0, x0, #0xba8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	90000042 	adrp	x2, b000 <fwp_main_thread+0x1290>
    331c:	912f0042 	add	x2, x2, #0xbc0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	90000042 	adrp	x2, b000 <fwp_main_thread+0x1290>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	91306042 	add	x2, x2, #0xc18
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	90000059 	adrp	x25, b000 <fwp_main_thread+0x1290>
    33a8:	9000005a 	adrp	x26, b000 <fwp_main_thread+0x1290>
    33ac:	9131e339 	add	x25, x25, #0xc78
    33b0:	912f835a 	add	x26, x26, #0xbe0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	9000005b 	adrp	x27, b000 <fwp_main_thread+0x1290>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	912fa377 	add	x23, x27, #0xbe8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	9132e000 	add	x0, x0, #0xcb8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	90000043 	adrp	x3, b000 <fwp_main_thread+0x1290>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	90000055 	adrp	x21, b000 <fwp_main_thread+0x1290>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	912f8063 	add	x3, x3, #0xbe0
    34a0:	913342b5 	add	x21, x21, #0xcd0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91344000 	add	x0, x0, #0xd10
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    352c:	912fc000 	add	x0, x0, #0xbf0
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    35ec:	912ea000 	add	x0, x0, #0xba8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1290>
    3730:	aa1303e0 	mov	x0, x19
    3734:	91346021 	add	x1, x1, #0xd18
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1290>
    3744:	aa1303e0 	mov	x0, x19
    3748:	91348021 	add	x1, x1, #0xd20
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1290>
    3760:	9134a021 	add	x1, x1, #0xd28
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_format_g.constprop.0>:
    3780:	d10483ff 	sub	sp, sp, #0x120
    3784:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1290>
    3788:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    378c:	f947f442 	ldr	x2, [x2, #4072]
    3790:	9134c084 	add	x4, x4, #0xd30
    3794:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3798:	9102c3fd 	add	x29, sp, #0xb0
    379c:	d2800803 	mov	x3, #0x40                  	// #64
    37a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37a4:	93407c38 	sxtw	x24, w1
    37a8:	aa0303e1 	mov	x1, x3
    37ac:	fd008be8 	str	d8, [sp, #272]
    37b0:	1e604008 	fmov	d8, d0
    37b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37b8:	910083f4 	add	x20, sp, #0x20
    37bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    37c0:	aa0003f5 	mov	x21, x0
    37c4:	a91073fb 	stp	x27, x28, [sp, #256]
    37c8:	5100071c 	sub	w28, w24, #0x1
    37cc:	2a1c03e5 	mov	w5, w28
    37d0:	f9400040 	ldr	x0, [x2]
    37d4:	f90057e0 	str	x0, [sp, #168]
    37d8:	d2800000 	mov	x0, #0x0                   	// #0
    37dc:	52800042 	mov	w2, #0x2                   	// #2
    37e0:	aa1403e0 	mov	x0, x20
    37e4:	97fffbe7 	bl	2780 <__snprintf_chk@plt>
    37e8:	52800ca1 	mov	w1, #0x65                  	// #101
    37ec:	aa1403e0 	mov	x0, x20
    37f0:	97fffc40 	bl	28f0 <strchr@plt>
    37f4:	aa0003f3 	mov	x19, x0
    37f8:	52800142 	mov	w2, #0xa                   	// #10
    37fc:	91000400 	add	x0, x0, #0x1
    3800:	d2800001 	mov	x1, #0x0                   	// #0
    3804:	97fffc2b 	bl	28b0 <strtol@plt>
    3808:	aa0003f7 	mov	x23, x0
    380c:	11001400 	add	w0, w0, #0x5
    3810:	7100541f 	cmp	w0, #0x15
    3814:	54000d68 	b.hi	39c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3818:	4b170385 	sub	w5, w28, w23
    381c:	710000bf 	cmp	w5, #0x0
    3820:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3824:	54000b80 	b.eq	3994 <fwp_format_g.constprop.0+0x214>  // b.none
    3828:	394083e0 	ldrb	w0, [sp, #32]
    382c:	cb180273 	sub	x19, x19, x24
    3830:	91000673 	add	x19, x19, #0x1
    3834:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3838:	7100b41f 	cmp	w0, #0x2d
    383c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3840:	1a9f17e4 	cset	w4, eq	// eq = none
    3844:	cb010266 	sub	x6, x19, x1
    3848:	d10004da 	sub	x26, x6, #0x1
    384c:	540018a0 	b.eq	3b60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3850:	910183f9 	add	x25, sp, #0x60
    3854:	d280091b 	mov	x27, #0x48                  	// #72
    3858:	aa1903e7 	mov	x7, x25
    385c:	91000423 	add	x3, x1, #0x1
    3860:	91011cc6 	add	x6, x6, #0x47
    3864:	910004f6 	add	x22, x7, #0x1
    3868:	37f80ff7 	tbnz	w23, #31, 3a64 <fwp_format_g.constprop.0+0x2e4>
    386c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3870:	93407ef7 	sxtw	x23, w23
    3874:	390000e4 	strb	w4, [x7]
    3878:	aa1303e1 	mov	x1, x19
    387c:	aa1703e2 	mov	x2, x23
    3880:	aa1603e0 	mov	x0, x22
    3884:	b9000be5 	str	w5, [sp, #8]
    3888:	cb170374 	sub	x20, x27, x23
    388c:	a9011be3 	stp	x3, x6, [sp, #16]
    3890:	97fffb74 	bl	2660 <memcpy@plt>
    3894:	d1000694 	sub	x20, x20, #0x1
    3898:	f9400be3 	ldr	x3, [sp, #16]
    389c:	8b1702d6 	add	x22, x22, x23
    38a0:	aa1603e0 	mov	x0, x22
    38a4:	aa1a03e2 	mov	x2, x26
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	aa1403e3 	mov	x3, x20
    38b0:	97fffbac 	bl	2760 <__memcpy_chk@plt>
    38b4:	8b1a02d6 	add	x22, x22, x26
    38b8:	f9400fe6 	ldr	x6, [sp, #24]
    38bc:	d2800900 	mov	x0, #0x48                  	// #72
    38c0:	b9400be5 	ldr	w5, [sp, #8]
    38c4:	8b170261 	add	x1, x19, x23
    38c8:	cb1400c3 	sub	x3, x6, x20
    38cc:	cb060294 	sub	x20, x20, x6
    38d0:	f101207f 	cmp	x3, #0x48
    38d4:	93407cb8 	sxtw	x24, w5
    38d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38dc:	aa1803e2 	mov	x2, x24
    38e0:	8b1802d3 	add	x19, x22, x24
    38e4:	8b140063 	add	x3, x3, x20
    38e8:	aa1603e0 	mov	x0, x22
    38ec:	97fffb9d 	bl	2760 <__memcpy_chk@plt>
    38f0:	cb190273 	sub	x19, x19, x25
    38f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    38f8:	eb00027f 	cmp	x19, x0
    38fc:	aa1903e1 	mov	x1, x25
    3900:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3904:	aa1503e0 	mov	x0, x21
    3908:	aa1303e2 	mov	x2, x19
    390c:	97fffb55 	bl	2660 <memcpy@plt>
    3910:	38336abf 	strb	wzr, [x21, x19]
    3914:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3918:	aa1503e0 	mov	x0, x21
    391c:	97fffb61 	bl	26a0 <strlen@plt>
    3920:	aa0003f3 	mov	x19, x0
    3924:	528005c1 	mov	w1, #0x2e                  	// #46
    3928:	aa1503e0 	mov	x0, x21
    392c:	97fffbf1 	bl	28f0 <strchr@plt>
    3930:	b4000140 	cbz	x0, 3958 <fwp_format_g.constprop.0+0x1d8>
    3934:	b4000133 	cbz	x19, 3958 <fwp_format_g.constprop.0+0x1d8>
    3938:	aa1303e1 	mov	x1, x19
    393c:	d1000673 	sub	x19, x19, #0x1
    3940:	38736aa0 	ldrb	w0, [x21, x19]
    3944:	7100c01f 	cmp	w0, #0x30
    3948:	54001001 	b.ne	3b48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    394c:	38336abf 	strb	wzr, [x21, x19]
    3950:	b5ffff53 	cbnz	x19, 3938 <fwp_format_g.constprop.0+0x1b8>
    3954:	d503201f 	nop
    3958:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    395c:	f947f400 	ldr	x0, [x0, #4072]
    3960:	f94057e2 	ldr	x2, [sp, #168]
    3964:	f9400001 	ldr	x1, [x0]
    3968:	eb010042 	subs	x2, x2, x1
    396c:	d2800001 	mov	x1, #0x0                   	// #0
    3970:	54001061 	b.ne	3b7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3974:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3978:	a94c53f3 	ldp	x19, x20, [sp, #192]
    397c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3980:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3984:	a95073fb 	ldp	x27, x28, [sp, #256]
    3988:	fd408be8 	ldr	d8, [sp, #272]
    398c:	910483ff 	add	sp, sp, #0x120
    3990:	d65f03c0 	ret
    3994:	1e604100 	fmov	d0, d8
    3998:	710000bf 	cmp	w5, #0x0
    399c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39a0:	aa1503e0 	mov	x0, x21
    39a4:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1290>
    39a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ac:	91352084 	add	x4, x4, #0xd48
    39b0:	52800042 	mov	w2, #0x2                   	// #2
    39b4:	d2803201 	mov	x1, #0x190                 	// #400
    39b8:	97fffb72 	bl	2780 <__snprintf_chk@plt>
    39bc:	17ffffd7 	b	3918 <fwp_format_g.constprop.0+0x198>
    39c0:	cb140273 	sub	x19, x19, x20
    39c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39c8:	910183f9 	add	x25, sp, #0x60
    39cc:	aa1303e2 	mov	x2, x19
    39d0:	aa1403e1 	mov	x1, x20
    39d4:	aa1903e0 	mov	x0, x25
    39d8:	d2800803 	mov	x3, #0x40                  	// #64
    39dc:	97fffb61 	bl	2760 <__memcpy_chk@plt>
    39e0:	38336b3f 	strb	wzr, [x25, x19]
    39e4:	aa1903e0 	mov	x0, x25
    39e8:	528005c1 	mov	w1, #0x2e                  	// #46
    39ec:	97fffbc1 	bl	28f0 <strchr@plt>
    39f0:	b40001c0 	cbz	x0, 3a28 <fwp_format_g.constprop.0+0x2a8>
    39f4:	b50000b3 	cbnz	x19, 3a08 <fwp_format_g.constprop.0+0x288>
    39f8:	1400000c 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    39fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3a00:	f1000673 	subs	x19, x19, #0x1
    3a04:	54000120 	b.eq	3a28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a08:	8b130320 	add	x0, x25, x19
    3a0c:	385ff001 	ldurb	w1, [x0, #-1]
    3a10:	7100c03f 	cmp	w1, #0x30
    3a14:	54ffff40 	b.eq	39fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3a18:	d1000673 	sub	x19, x19, #0x1
    3a1c:	38736b20 	ldrb	w0, [x25, x19]
    3a20:	7100b81f 	cmp	w0, #0x2e
    3a24:	54000a80 	b.eq	3b74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a28:	710002ff 	cmp	w23, #0x0
    3a2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a30:	aa1903e5 	mov	x5, x25
    3a34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a38:	aa1503e0 	mov	x0, x21
    3a3c:	52800566 	mov	w6, #0x2b                  	// #43
    3a40:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1290>
    3a44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a48:	9134e084 	add	x4, x4, #0xd38
    3a4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a50:	52800042 	mov	w2, #0x2                   	// #2
    3a54:	d2803201 	mov	x1, #0x190                 	// #400
    3a58:	97fffb4a 	bl	2780 <__snprintf_chk@plt>
    3a5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a60:	17ffffbe 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3a64:	52800605 	mov	w5, #0x30                  	// #48
    3a68:	390000e5 	strb	w5, [x7]
    3a6c:	d100077b 	sub	x27, x27, #0x1
    3a70:	aa0303e1 	mov	x1, x3
    3a74:	aa1603e0 	mov	x0, x22
    3a78:	aa1b03e3 	mov	x3, x27
    3a7c:	aa1a03e2 	mov	x2, x26
    3a80:	f90007e6 	str	x6, [sp, #8]
    3a84:	b90013e4 	str	w4, [sp, #16]
    3a88:	8b1a02d6 	add	x22, x22, x26
    3a8c:	b9001be5 	str	w5, [sp, #24]
    3a90:	97fffb34 	bl	2760 <__memcpy_chk@plt>
    3a94:	f94007e6 	ldr	x6, [sp, #8]
    3a98:	2a3703e7 	mvn	w7, w23
    3a9c:	b94013e4 	ldr	w4, [sp, #16]
    3aa0:	cb1b00c1 	sub	x1, x6, x27
    3aa4:	cb06037b 	sub	x27, x27, x6
    3aa8:	f101203f 	cmp	x1, #0x48
    3aac:	d2800906 	mov	x6, #0x48                  	// #72
    3ab0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ab4:	8b1b0023 	add	x3, x1, x27
    3ab8:	310006ff 	cmn	w23, #0x1
    3abc:	54000220 	b.eq	3b00 <fwp_format_g.constprop.0+0x380>  // b.none
    3ac0:	b9401be5 	ldr	w5, [sp, #24]
    3ac4:	d2800001 	mov	x1, #0x0                   	// #0
    3ac8:	f101207f 	cmp	x3, #0x48
    3acc:	d1000462 	sub	x2, x3, #0x1
    3ad0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3ad4:	38216ac5 	strb	w5, [x22, x1]
    3ad8:	cb030003 	sub	x3, x0, x3
    3adc:	91000421 	add	x1, x1, #0x1
    3ae0:	91000463 	add	x3, x3, #0x1
    3ae4:	eb00007f 	cmp	x3, x0
    3ae8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3aec:	cb000063 	sub	x3, x3, x0
    3af0:	8b020063 	add	x3, x3, x2
    3af4:	6b0100ff 	cmp	w7, w1
    3af8:	54fffe8c 	b.gt	3ac8 <fwp_format_g.constprop.0+0x348>
    3afc:	8b2742d6 	add	x22, x22, w7, uxtw
    3b00:	f101207f 	cmp	x3, #0x48
    3b04:	d2800905 	mov	x5, #0x48                  	// #72
    3b08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b0c:	aa1603e0 	mov	x0, x22
    3b10:	cb0300a1 	sub	x1, x5, x3
    3b14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b18:	91000421 	add	x1, x1, #0x1
    3b1c:	d1000463 	sub	x3, x3, #0x1
    3b20:	eb05003f 	cmp	x1, x5
    3b24:	38001402 	strb	w2, [x0], #1
    3b28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b2c:	93407f82 	sxtw	x2, w28
    3b30:	cb050025 	sub	x5, x1, x5
    3b34:	aa1303e1 	mov	x1, x19
    3b38:	8b0300a3 	add	x3, x5, x3
    3b3c:	8b1802d3 	add	x19, x22, x24
    3b40:	97fffb08 	bl	2760 <__memcpy_chk@plt>
    3b44:	17ffff6b 	b	38f0 <fwp_format_g.constprop.0+0x170>
    3b48:	d1000421 	sub	x1, x1, #0x1
    3b4c:	38616aa0 	ldrb	w0, [x21, x1]
    3b50:	7100b81f 	cmp	w0, #0x2e
    3b54:	54fff021 	b.ne	3958 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b58:	38216abf 	strb	wzr, [x21, x1]
    3b5c:	17ffff7f 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3b60:	910187e7 	add	x7, sp, #0x61
    3b64:	910183f9 	add	x25, sp, #0x60
    3b68:	d28008fb 	mov	x27, #0x47                  	// #71
    3b6c:	390183e0 	strb	w0, [sp, #96]
    3b70:	17ffff3b 	b	385c <fwp_format_g.constprop.0+0xdc>
    3b74:	38336b3f 	strb	wzr, [x25, x19]
    3b78:	17ffffac 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    3b7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b80:	97fffb24 	bl	2810 <__stack_chk_fail@plt>

0000000000003b84 <fwp_heap_report>:
    3b84:	d105c3ff 	sub	sp, sp, #0x170
    3b88:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3b8c:	91190042 	add	x2, x2, #0x640
    3b90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3b94:	f947e821 	ldr	x1, [x1, #4048]
    3b98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3b9c:	910443fd 	add	x29, sp, #0x110
    3ba0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3ba4:	f947f400 	ldr	x0, [x0, #4072]
    3ba8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bac:	a91463f7 	stp	x23, x24, [sp, #320]
    3bb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3bc0:	f9400036 	ldr	x22, [x1]
    3bc4:	f9400001 	ldr	x1, [x0]
    3bc8:	f90087e1 	str	x1, [sp, #264]
    3bcc:	d2800001 	mov	x1, #0x0                   	// #0
    3bd0:	f949e459 	ldr	x25, [x2, #5064]
    3bd4:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1290>
    3bd8:	f94a1057 	ldr	x23, [x2, #5152]
    3bdc:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    3be0:	f94a1458 	ldr	x24, [x2, #5160]
    3be4:	91354021 	add	x1, x1, #0xd50
    3be8:	91356000 	add	x0, x0, #0xd58
    3bec:	97fffaed 	bl	27a0 <fopen@plt>
    3bf0:	b4000760 	cbz	x0, 3cdc <fwp_heap_report+0x158>
    3bf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3bf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3bfc:	aa0003f4 	mov	x20, x0
    3c00:	910023f3 	add	x19, sp, #0x8
    3c04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c08:	72aae915 	movk	w21, #0x5748, lsl #16
    3c0c:	d503201f 	nop
    3c10:	aa1403e2 	mov	x2, x20
    3c14:	aa1303e0 	mov	x0, x19
    3c18:	52802001 	mov	w1, #0x100                 	// #256
    3c1c:	97fffb69 	bl	29c0 <fgets@plt>
    3c20:	b4000280 	cbz	x0, 3c70 <fwp_heap_report+0xec>
    3c24:	b9400261 	ldr	w1, [x19]
    3c28:	6b15003f 	cmp	w1, w21
    3c2c:	54ffff21 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c30:	39401260 	ldrb	w0, [x19, #4]
    3c34:	7101341f 	cmp	w0, #0x4d
    3c38:	54fffec1 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c3c:	394037e0 	ldrb	w0, [sp, #13]
    3c40:	7100e81f 	cmp	w0, #0x3a
    3c44:	54fffe61 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c48:	52800142 	mov	w2, #0xa                   	// #10
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	91003be0 	add	x0, sp, #0xe
    3c54:	97fffb17 	bl	28b0 <strtol@plt>
    3c58:	aa1403e2 	mov	x2, x20
    3c5c:	aa0003fa 	mov	x26, x0
    3c60:	52802001 	mov	w1, #0x100                 	// #256
    3c64:	aa1303e0 	mov	x0, x19
    3c68:	97fffb56 	bl	29c0 <fgets@plt>
    3c6c:	b5fffdc0 	cbnz	x0, 3c24 <fwp_heap_report+0xa0>
    3c70:	aa1403e0 	mov	x0, x20
    3c74:	97fffac7 	bl	2790 <fclose@plt>
    3c78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3c7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3c80:	f947f400 	ldr	x0, [x0, #4072]
    3c84:	f94087e2 	ldr	x2, [sp, #264]
    3c88:	f9400001 	ldr	x1, [x0]
    3c8c:	eb010042 	subs	x2, x2, x1
    3c90:	d2800001 	mov	x1, #0x0                   	// #0
    3c94:	54000281 	b.ne	3ce4 <fwp_heap_report+0x160>  // b.any
    3c98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3c9c:	aa1a03e6 	mov	x6, x26
    3ca0:	aa1903e5 	mov	x5, x25
    3ca4:	aa1803e4 	mov	x4, x24
    3ca8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cac:	aa1703e3 	mov	x3, x23
    3cb0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cbc:	1e604121 	fmov	d1, d9
    3cc0:	1e604100 	fmov	d0, d8
    3cc4:	90000042 	adrp	x2, b000 <fwp_main_thread+0x1290>
    3cc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3ccc:	9135e042 	add	x2, x2, #0xd78
    3cd0:	9105c3ff 	add	sp, sp, #0x170
    3cd4:	52800041 	mov	w1, #0x2                   	// #2
    3cd8:	17fffaea 	b	2880 <__fprintf_chk@plt>
    3cdc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ce0:	17ffffe7 	b	3c7c <fwp_heap_report+0xf8>
    3ce4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ce8:	97fffaca 	bl	2810 <__stack_chk_fail@plt>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_heap_init>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    3cf8:	91150061 	add	x1, x3, #0x540
    3cfc:	910003fd 	mov	x29, sp
    3d00:	a90153f3 	stp	x19, x20, [sp, #16]
    3d04:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    3d08:	91190262 	add	x2, x19, #0x640
    3d0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d10:	52800024 	mov	w4, #0x1                   	// #1
    3d14:	52800200 	mov	w0, #0x10                  	// #16
    3d18:	b913a444 	str	w4, [x2, #5028]
    3d1c:	d503201f 	nop
    3d20:	b8004420 	str	w0, [x1], #4
    3d24:	11004000 	add	w0, w0, #0x10
    3d28:	7104401f 	cmp	w0, #0x110
    3d2c:	54ffffa1 	b.ne	3d20 <fwp_heap_init+0x30>  // b.any
    3d30:	b0000042 	adrp	x2, c000 <_IO_stdin_used+0x460>
    3d34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d38:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    3d3c:	91160021 	add	x1, x1, #0x580
    3d40:	3dc2d043 	ldr	q3, [x2, #2880]
    3d44:	d2800000 	mov	x0, #0x0                   	// #0
    3d48:	4e040401 	dup	v1.4s, v0.s[0]
    3d4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d50:	0f215400 	shl	v0.2s, v0.2s, #1
    3d54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d58:	3ca06821 	str	q1, [x1, x0]
    3d5c:	91004000 	add	x0, x0, #0x10
    3d60:	f101801f 	cmp	x0, #0x60
    3d64:	54ffff21 	b.ne	3d48 <fwp_heap_init+0x58>  // b.any
    3d68:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    3d6c:	91150063 	add	x3, x3, #0x540
    3d70:	91178084 	add	x4, x4, #0x5e0
    3d74:	91190266 	add	x6, x19, #0x640
    3d78:	d2800002 	mov	x2, #0x0                   	// #0
    3d7c:	d2800000 	mov	x0, #0x0                   	// #0
    3d80:	d2880205 	mov	x5, #0x4010                	// #16400
    3d84:	d503201f 	nop
    3d88:	910f0001 	add	x1, x0, #0x3c0
    3d8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3d90:	eb02003f 	cmp	x1, x2
    3d94:	540000a2 	b.cs	3da8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3d98:	91000400 	add	x0, x0, #0x1
    3d9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3da0:	eb02003f 	cmp	x1, x2
    3da4:	54ffffa3 	b.cc	3d98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3da8:	91004042 	add	x2, x2, #0x10
    3dac:	38001480 	strb	w0, [x4], #1
    3db0:	eb05005f 	cmp	x2, x5
    3db4:	54fffea1 	b.ne	3d88 <fwp_heap_init+0x98>  // b.any
    3db8:	528000b5 	mov	w21, #0x5                   	// #5
    3dbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3dc0:	14000004 	b	3dd0 <fwp_heap_init+0xe0>
    3dc4:	d342fe94 	lsr	x20, x20, #2
    3dc8:	710006b5 	subs	w21, w21, #0x1
    3dcc:	54000720 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3dd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3dd4:	d2800005 	mov	x5, #0x0                   	// #0
    3dd8:	aa1603e1 	mov	x1, x22
    3ddc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3de0:	52880443 	mov	w3, #0x4022                	// #16418
    3de4:	52800002 	mov	w2, #0x0                   	// #0
    3de8:	d2800000 	mov	x0, #0x0                   	// #0
    3dec:	97fffaad 	bl	28a0 <mmap@plt>
    3df0:	aa0003e6 	mov	x6, x0
    3df4:	b100041f 	cmn	x0, #0x1
    3df8:	54fffe60 	b.eq	3dc4 <fwp_heap_init+0xd4>  // b.none
    3dfc:	b40005a0 	cbz	x0, 3eb0 <fwp_heap_init+0x1c0>
    3e00:	d350fe94 	lsr	x20, x20, #16
    3e04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e08:	8b0000c7 	add	x7, x6, x0
    3e0c:	91190275 	add	x21, x19, #0x640
    3e10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e14:	8b140a81 	add	x1, x20, x20, lsl #2
    3e18:	d2800005 	mov	x5, #0x0                   	// #0
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	d37df021 	lsl	x1, x1, #3
    3e24:	52880443 	mov	w3, #0x4022                	// #16418
    3e28:	52800002 	mov	w2, #0x0                   	// #0
    3e2c:	d2800000 	mov	x0, #0x0                   	// #0
    3e30:	f909daa7 	str	x7, [x21, #5040]
    3e34:	f909dea6 	str	x6, [x21, #5048]
    3e38:	f909e2b6 	str	x22, [x21, #5056]
    3e3c:	f909eab4 	str	x20, [x21, #5072]
    3e40:	f90a02a1 	str	x1, [x21, #5120]
    3e44:	97fffa97 	bl	28a0 <mmap@plt>
    3e48:	aa0003e1 	mov	x1, x0
    3e4c:	b100041f 	cmn	x0, #0x1
    3e50:	54000300 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3e54:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    3e58:	91380000 	add	x0, x0, #0xe00
    3e5c:	f909fea1 	str	x1, [x21, #5112]
    3e60:	97fffad0 	bl	29a0 <getenv@plt>
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	aa0003e1 	mov	x1, x0
    3e6c:	b40000e0 	cbz	x0, 3e88 <fwp_heap_init+0x198>
    3e70:	39400000 	ldrb	w0, [x0]
    3e74:	340000a0 	cbz	w0, 3e88 <fwp_heap_init+0x198>
    3e78:	7100c000 	subs	w0, w0, #0x30
    3e7c:	54000120 	b.eq	3ea0 <fwp_heap_init+0x1b0>  // b.none
    3e80:	7100001f 	cmp	w0, #0x0
    3e84:	1a9f07e2 	cset	w2, ne	// ne = any
    3e88:	91190273 	add	x19, x19, #0x640
    3e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e90:	b913aa62 	str	w2, [x19, #5032]
    3e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e9c:	d65f03c0 	ret
    3ea0:	39400420 	ldrb	w0, [x1, #1]
    3ea4:	7100001f 	cmp	w0, #0x0
    3ea8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eac:	17fffff7 	b	3e88 <fwp_heap_init+0x198>
    3eb0:	97fffc90 	bl	30f0 <fwp_heap_oom>

0000000000003eb4 <fwp_wake_io>:
    3eb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3eb8:	91018122 	add	x2, x9, #0x60
    3ebc:	f9400001 	ldr	x1, [x0]
    3ec0:	5280000a 	mov	w10, #0x0                   	// #0
    3ec4:	f9406046 	ldr	x6, [x2, #192]
    3ec8:	52800008 	mov	w8, #0x0                   	// #0
    3ecc:	4f000400 	movi	v0.4s, #0x0
    3ed0:	52800027 	mov	w7, #0x1                   	// #1
    3ed4:	aa0103e2 	mov	x2, x1
    3ed8:	b4000321 	cbz	x1, 3f3c <fwp_wake_io+0x88>
    3edc:	f9408c25 	ldr	x5, [x1, #280]
    3ee0:	39015c27 	strb	w7, [x1, #87]
    3ee4:	b4000165 	cbz	x5, 3f10 <fwp_wake_io+0x5c>
    3ee8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3eec:	b4000364 	cbz	x4, 3f58 <fwp_wake_io+0xa4>
    3ef0:	f9009483 	str	x3, [x4, #296]
    3ef4:	f9409423 	ldr	x3, [x1, #296]
    3ef8:	b4000043 	cbz	x3, 3f00 <fwp_wake_io+0x4c>
    3efc:	f9009064 	str	x4, [x3, #288]
    3f00:	91080023 	add	x3, x1, #0x200
    3f04:	f900943f 	str	xzr, [x1, #296]
    3f08:	3c918060 	stur	q0, [x3, #-232]
    3f0c:	f9400001 	ldr	x1, [x0]
    3f10:	f9402843 	ldr	x3, [x2, #80]
    3f14:	f2001c7f 	tst	x3, #0xff000000ff
    3f18:	54fffde1 	b.ne	3ed4 <fwp_wake_io+0x20>  // b.any
    3f1c:	39015047 	strb	w7, [x2, #84]
    3f20:	f900805f 	str	xzr, [x2, #256]
    3f24:	b40001e6 	cbz	x6, 3f60 <fwp_wake_io+0xac>
    3f28:	f90080c2 	str	x2, [x6, #256]
    3f2c:	aa0203e6 	mov	x6, x2
    3f30:	52800028 	mov	w8, #0x1                   	// #1
    3f34:	aa0103e2 	mov	x2, x1
    3f38:	b5fffd21 	cbnz	x1, 3edc <fwp_wake_io+0x28>
    3f3c:	3400006a 	cbz	w10, 3f48 <fwp_wake_io+0x94>
    3f40:	91018120 	add	x0, x9, #0x60
    3f44:	f900640b 	str	x11, [x0, #200]
    3f48:	34000068 	cbz	w8, 3f54 <fwp_wake_io+0xa0>
    3f4c:	91018129 	add	x9, x9, #0x60
    3f50:	f9006126 	str	x6, [x9, #192]
    3f54:	d65f03c0 	ret
    3f58:	f90000a3 	str	x3, [x5]
    3f5c:	17ffffe7 	b	3ef8 <fwp_wake_io+0x44>
    3f60:	aa0203eb 	mov	x11, x2
    3f64:	5280002a 	mov	w10, #0x1                   	// #1
    3f68:	17fffff1 	b	3f2c <fwp_wake_io+0x78>
    3f6c:	d503201f 	nop

0000000000003f70 <ad_raw_free.part.0>:
    3f70:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    3f74:	d2800001 	mov	x1, #0x0                   	// #0
    3f78:	91118082 	add	x2, x4, #0x460
    3f7c:	14000005 	b	3f90 <ad_raw_free.part.0+0x20>
    3f80:	91000421 	add	x1, x1, #0x1
    3f84:	91006042 	add	x2, x2, #0x18
    3f88:	f140043f 	cmp	x1, #0x1, lsl #12
    3f8c:	54000220 	b.eq	3fd0 <ad_raw_free.part.0+0x60>  // b.none
    3f90:	f9400043 	ldr	x3, [x2]
    3f94:	eb03001f 	cmp	x0, x3
    3f98:	54ffff41 	b.ne	3f80 <ad_raw_free.part.0+0x10>  // b.any
    3f9c:	8b010421 	add	x1, x1, x1, lsl #1
    3fa0:	91118084 	add	x4, x4, #0x460
    3fa4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fa8:	91018042 	add	x2, x2, #0x60
    3fac:	8b010c81 	add	x1, x4, x1, lsl #3
    3fb0:	b9401024 	ldr	w4, [x1, #16]
    3fb4:	f9400425 	ldr	x5, [x1, #8]
    3fb8:	a9007c3f 	stp	xzr, xzr, [x1]
    3fbc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    3fc0:	f900083f 	str	xzr, [x1, #16]
    3fc4:	cb050061 	sub	x1, x3, x5
    3fc8:	f8247841 	str	x1, [x2, x4, lsl #3]
    3fcc:	17fffa41 	b	28d0 <free@plt>
    3fd0:	f100001f 	cmp	x0, #0x0
    3fd4:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1290>
    3fd8:	9138a021 	add	x1, x1, #0xe28
    3fdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3fe0:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1290>
    3fe4:	91384000 	add	x0, x0, #0xe10
    3fe8:	910003fd 	mov	x29, sp
    3fec:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    3ff0:	97fffcc4 	bl	3300 <ad_raw_fail>

0000000000003ff4 <fwp_tape_buffers_dispose>:
    3ff4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ff8:	910003fd 	mov	x29, sp
    3ffc:	f9000bf3 	str	x19, [sp, #16]
    4000:	aa0003f3 	mov	x19, x0
    4004:	f9400000 	ldr	x0, [x0]
    4008:	b4000040 	cbz	x0, 4010 <fwp_tape_buffers_dispose+0x1c>
    400c:	97ffffd9 	bl	3f70 <ad_raw_free.part.0>
    4010:	f9400a60 	ldr	x0, [x19, #16]
    4014:	b4000040 	cbz	x0, 401c <fwp_tape_buffers_dispose+0x28>
    4018:	97ffffd6 	bl	3f70 <ad_raw_free.part.0>
    401c:	f9401260 	ldr	x0, [x19, #32]
    4020:	b4000040 	cbz	x0, 4028 <fwp_tape_buffers_dispose+0x34>
    4024:	97ffffd3 	bl	3f70 <ad_raw_free.part.0>
    4028:	4f000400 	movi	v0.4s, #0x0
    402c:	f9001a7f 	str	xzr, [x19, #48]
    4030:	ad000260 	stp	q0, q0, [x19]
    4034:	3d800a60 	str	q0, [x19, #32]
    4038:	f9400bf3 	ldr	x19, [sp, #16]
    403c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4040:	d65f03c0 	ret

0000000000004044 <ad_raw_realloc>:
    4044:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4048:	910003fd 	mov	x29, sp
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	f90013f5 	str	x21, [sp, #32]
    4054:	b40005a1 	cbz	x1, 4108 <ad_raw_realloc+0xc4>
    4058:	aa0103f4 	mov	x20, x1
    405c:	2a0203f5 	mov	w21, w2
    4060:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    4064:	d2800004 	mov	x4, #0x0                   	// #0
    4068:	91118025 	add	x5, x1, #0x460
    406c:	14000005 	b	4080 <ad_raw_realloc+0x3c>
    4070:	91000484 	add	x4, x4, #0x1
    4074:	910060a5 	add	x5, x5, #0x18
    4078:	f140049f 	cmp	x4, #0x1, lsl #12
    407c:	54000320 	b.eq	40e0 <ad_raw_realloc+0x9c>  // b.none
    4080:	f94000a6 	ldr	x6, [x5]
    4084:	eb06001f 	cmp	x0, x6
    4088:	54ffff41 	b.ne	4070 <ad_raw_realloc+0x2c>  // b.any
    408c:	8b040484 	add	x4, x4, x4, lsl #1
    4090:	91118021 	add	x1, x1, #0x460
    4094:	8b040c33 	add	x19, x1, x4, lsl #3
    4098:	b4000080 	cbz	x0, 40a8 <ad_raw_realloc+0x64>
    409c:	b9401261 	ldr	w1, [x19, #16]
    40a0:	6b15003f 	cmp	w1, w21
    40a4:	540002c1 	b.ne	40fc <ad_raw_realloc+0xb8>  // b.any
    40a8:	aa1403e1 	mov	x1, x20
    40ac:	97fff9d5 	bl	2800 <realloc@plt>
    40b0:	aa0003ed 	mov	x13, x0
    40b4:	b40000c0 	cbz	x0, 40cc <ad_raw_realloc+0x88>
    40b8:	2a1503e3 	mov	w3, w21
    40bc:	aa1403e2 	mov	x2, x20
    40c0:	aa1303e0 	mov	x0, x19
    40c4:	aa0d03e1 	mov	x1, x13
    40c8:	97fffb92 	bl	2f10 <ad_raw_record>
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	aa0d03e0 	mov	x0, x13
    40d4:	f94013f5 	ldr	x21, [sp, #32]
    40d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40dc:	d65f03c0 	ret
    40e0:	f100001f 	cmp	x0, #0x0
    40e4:	f0000021 	adrp	x1, b000 <fwp_main_thread+0x1290>
    40e8:	9138a021 	add	x1, x1, #0xe28
    40ec:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    40f0:	91384000 	add	x0, x0, #0xe10
    40f4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    40f8:	97fffc82 	bl	3300 <ad_raw_fail>
    40fc:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4100:	9139a000 	add	x0, x0, #0xe68
    4104:	97fffc7f 	bl	3300 <ad_raw_fail>
    4108:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    410c:	91392000 	add	x0, x0, #0xe48
    4110:	97fffc7c 	bl	3300 <ad_raw_fail>

0000000000004114 <fwp_tape_buffers_release>:
    4114:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4118:	910003fd 	mov	x29, sp
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f4 	mov	x20, x0
    4124:	f9401400 	ldr	x0, [x0, #40]
    4128:	a9025bf5 	stp	x21, x22, [sp, #32]
    412c:	b7f80560 	tbnz	x0, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4130:	f9401a93 	ldr	x19, [x20, #48]
    4134:	b7f80533 	tbnz	x19, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4138:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    413c:	eb01001f 	cmp	x0, x1
    4140:	540004c8 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4144:	8b000400 	add	x0, x0, x0, lsl #1
    4148:	d2a00101 	mov	x1, #0x80000               	// #524288
    414c:	d37df000 	lsl	x0, x0, #3
    4150:	cb000021 	sub	x1, x1, x0
    4154:	eb410e7f 	cmp	x19, x1, lsr #3
    4158:	54000408 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    415c:	8b130c13 	add	x19, x0, x19, lsl #3
    4160:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4164:	913a0000 	add	x0, x0, #0xe80
    4168:	97fffa0e 	bl	29a0 <getenv@plt>
    416c:	b4000080 	cbz	x0, 417c <fwp_tape_buffers_release+0x68>
    4170:	39400001 	ldrb	w1, [x0]
    4174:	7100c03f 	cmp	w1, #0x30
    4178:	54000880 	b.eq	4288 <fwp_tape_buffers_release+0x174>  // b.none
    417c:	d1000661 	sub	x1, x19, #0x1
    4180:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4184:	eb00003f 	cmp	x1, x0
    4188:	54000328 	b.hi	41ec <fwp_tape_buffers_release+0xd8>  // b.pmore
    418c:	900000f5 	adrp	x21, 20000 <__data_start>
    4190:	f9001bf7 	str	x23, [sp, #48]
    4194:	910182b7 	add	x23, x21, #0x60
    4198:	910342f6 	add	x22, x23, #0xd0
    419c:	aa1603e0 	mov	x0, x22
    41a0:	97ffff95 	bl	3ff4 <fwp_tape_buffers_dispose>
    41a4:	ad400a81 	ldp	q1, q2, [x20]
    41a8:	f90086f3 	str	x19, [x23, #264]
    41ac:	4f000400 	movi	v0.4s, #0x0
    41b0:	ad000ac1 	stp	q1, q2, [x22]
    41b4:	3dc00a81 	ldr	q1, [x20, #32]
    41b8:	3d800ac1 	str	q1, [x22, #32]
    41bc:	f9401a80 	ldr	x0, [x20, #48]
    41c0:	f9001ac0 	str	x0, [x22, #48]
    41c4:	f9001a9f 	str	xzr, [x20, #48]
    41c8:	ad000280 	stp	q0, q0, [x20]
    41cc:	3d800a80 	str	q0, [x20, #32]
    41d0:	f9401bf7 	ldr	x23, [sp, #48]
    41d4:	1400000b 	b	4200 <fwp_tape_buffers_release+0xec>
    41d8:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    41dc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    41e0:	913a0000 	add	x0, x0, #0xe80
    41e4:	97fff9ef 	bl	29a0 <getenv@plt>
    41e8:	b5fffc40 	cbnz	x0, 4170 <fwp_tape_buffers_release+0x5c>
    41ec:	aa1403e0 	mov	x0, x20
    41f0:	97ffff81 	bl	3ff4 <fwp_tape_buffers_dispose>
    41f4:	900000f5 	adrp	x21, 20000 <__data_start>
    41f8:	910182a0 	add	x0, x21, #0x60
    41fc:	f9408413 	ldr	x19, [x0, #264]
    4200:	910182a2 	add	x2, x21, #0x60
    4204:	f9408844 	ldr	x4, [x2, #272]
    4208:	a9400c45 	ldp	x5, x3, [x2]
    420c:	8b040481 	add	x1, x4, x4, lsl #1
    4210:	f9400840 	ldr	x0, [x2, #16]
    4214:	8b010881 	add	x1, x4, x1, lsl #2
    4218:	f9400c44 	ldr	x4, [x2, #24]
    421c:	8b0300a3 	add	x3, x5, x3
    4220:	d37df021 	lsl	x1, x1, #3
    4224:	8b040000 	add	x0, x0, x4
    4228:	8b030000 	add	x0, x0, x3
    422c:	eb05003f 	cmp	x1, x5
    4230:	54000321 	b.ne	4294 <fwp_tape_buffers_release+0x180>  // b.any
    4234:	8b130023 	add	x3, x1, x19
    4238:	eb00007f 	cmp	x3, x0
    423c:	540002c8 	b.hi	4294 <fwp_tape_buffers_release+0x180>  // b.pmore
    4240:	f9405c43 	ldr	x3, [x2, #184]
    4244:	f140087f 	cmp	x3, #0x2, lsl #12
    4248:	540002e0 	b.eq	42a4 <fwp_tape_buffers_release+0x190>  // b.none
    424c:	8b030464 	add	x4, x3, x3, lsl #1
    4250:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    4254:	911180a5 	add	x5, x5, #0x460
    4258:	cb010000 	sub	x0, x0, x1
    425c:	d37df084 	lsl	x4, x4, #3
    4260:	cb130000 	sub	x0, x0, x19
    4264:	8b0400a6 	add	x6, x5, x4
    4268:	91000463 	add	x3, x3, #0x1
    426c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4270:	f82468a1 	str	x1, [x5, x4]
    4274:	a90080d3 	stp	x19, x0, [x6, #8]
    4278:	f9005c43 	str	x3, [x2, #184]
    427c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4280:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4284:	d65f03c0 	ret
    4288:	39400400 	ldrb	w0, [x0, #1]
    428c:	34fffb00 	cbz	w0, 41ec <fwp_tape_buffers_release+0xd8>
    4290:	17ffffbb 	b	417c <fwp_tape_buffers_release+0x68>
    4294:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4298:	913a6000 	add	x0, x0, #0xe98
    429c:	f9001bf7 	str	x23, [sp, #48]
    42a0:	97fffc18 	bl	3300 <ad_raw_fail>
    42a4:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    42a8:	913b2000 	add	x0, x0, #0xec8
    42ac:	f9001bf7 	str	x23, [sp, #48]
    42b0:	97fffc14 	bl	3300 <ad_raw_fail>

00000000000042b4 <fwp_trap>:
    42b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42b8:	900000e2 	adrp	x2, 20000 <__data_start>
    42bc:	d53bd041 	mrs	x1, tpidr_el0
    42c0:	910003fd 	mov	x29, sp
    42c4:	f9407842 	ldr	x2, [x2, #240]
    42c8:	91400021 	add	x1, x1, #0x0, lsl #12
    42cc:	91004021 	add	x1, x1, #0x10
    42d0:	a90153f3 	stp	x19, x20, [sp, #16]
    42d4:	aa0003f3 	mov	x19, x0
    42d8:	f9400034 	ldr	x20, [x1]
    42dc:	b4000062 	cbz	x2, 42e8 <fwp_trap+0x34>
    42e0:	aa0203e0 	mov	x0, x2
    42e4:	97fff997 	bl	2940 <fflush@plt>
    42e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    42ec:	f947ec00 	ldr	x0, [x0, #4056]
    42f0:	f9400000 	ldr	x0, [x0]
    42f4:	97fff993 	bl	2940 <fflush@plt>
    42f8:	aa1303e3 	mov	x3, x19
    42fc:	f0000022 	adrp	x2, b000 <fwp_main_thread+0x1290>
    4300:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb30>
    4304:	f947ea73 	ldr	x19, [x19, #4048]
    4308:	913ba042 	add	x2, x2, #0xee8
    430c:	52800041 	mov	w1, #0x2                   	// #2
    4310:	f9400260 	ldr	x0, [x19]
    4314:	97fff95b 	bl	2880 <__fprintf_chk@plt>
    4318:	b40000b4 	cbz	x20, 432c <fwp_trap+0x78>
    431c:	f9400260 	ldr	x0, [x19]
    4320:	97fff988 	bl	2940 <fflush@plt>
    4324:	52800ca0 	mov	w0, #0x65                  	// #101
    4328:	97fff996 	bl	2980 <_Exit@plt>
    432c:	52800ca0 	mov	w0, #0x65                  	// #101
    4330:	97fff8e4 	bl	26c0 <exit@plt>

0000000000004334 <fwp_rc_forget_slot.part.0>:
    4334:	ca404401 	eor	x1, x0, x0, lsr #17
    4338:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    433c:	ca412421 	eor	x1, x1, x1, lsr #9
    4340:	910003fd 	mov	x29, sp
    4344:	92401c21 	and	x1, x1, #0xff
    4348:	f9000bf3 	str	x19, [sp, #16]
    434c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4350:	91190262 	add	x2, x19, #0x640
    4354:	910a2423 	add	x3, x1, #0x289
    4358:	8b010c41 	add	x1, x2, x1, lsl #3
    435c:	8b030c43 	add	x3, x2, x3, lsl #3
    4360:	f94a2421 	ldr	x1, [x1, #5192]
    4364:	b50000a1 	cbnz	x1, 4378 <fwp_rc_forget_slot.part.0+0x44>
    4368:	14000012 	b	43b0 <fwp_rc_forget_slot.part.0+0x7c>
    436c:	91004023 	add	x3, x1, #0x10
    4370:	f9400821 	ldr	x1, [x1, #16]
    4374:	b40001e1 	cbz	x1, 43b0 <fwp_rc_forget_slot.part.0+0x7c>
    4378:	f9400022 	ldr	x2, [x1]
    437c:	eb02001f 	cmp	x0, x2
    4380:	54ffff61 	b.ne	436c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4384:	f9400060 	ldr	x0, [x3]
    4388:	91190273 	add	x19, x19, #0x640
    438c:	f9400801 	ldr	x1, [x0, #16]
    4390:	f9000061 	str	x1, [x3]
    4394:	97fff94f 	bl	28d0 <free@plt>
    4398:	f94e2660 	ldr	x0, [x19, #7240]
    439c:	d1000400 	sub	x0, x0, #0x1
    43a0:	f90e2660 	str	x0, [x19, #7240]
    43a4:	f9400bf3 	ldr	x19, [sp, #16]
    43a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43ac:	d65f03c0 	ret
    43b0:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    43b4:	913be000 	add	x0, x0, #0xef8
    43b8:	97ffffbf 	bl	42b4 <fwp_trap>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_rc_prepare_chunk>:
    43c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    43d0:	911902c2 	add	x2, x22, #0x640
    43d4:	b9401c03 	ldr	w3, [x0, #28]
    43d8:	aa0103f5 	mov	x21, x1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f4 	mov	x20, x0
    43e4:	f94e2440 	ldr	x0, [x2, #7240]
    43e8:	b4000440 	cbz	x0, 4470 <fwp_rc_prepare_chunk+0xb0>
    43ec:	d2800013 	mov	x19, #0x0                   	// #0
    43f0:	35000203 	cbnz	w3, 4430 <fwp_rc_prepare_chunk+0x70>
    43f4:	b4000361 	cbz	x1, 4460 <fwp_rc_prepare_chunk+0xa0>
    43f8:	f9401280 	ldr	x0, [x20, #32]
    43fc:	97fff935 	bl	28d0 <free@plt>
    4400:	aa1503e0 	mov	x0, x21
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	97fff8fa 	bl	27f0 <calloc@plt>
    440c:	f9001280 	str	x0, [x20, #32]
    4410:	b5000460 	cbnz	x0, 449c <fwp_rc_prepare_chunk+0xdc>
    4414:	97fffb37 	bl	30f0 <fwp_heap_oom>
    4418:	97ffffc7 	bl	4334 <fwp_rc_forget_slot.part.0>
    441c:	91000673 	add	x19, x19, #0x1
    4420:	b9401e83 	ldr	w3, [x20, #28]
    4424:	eb13007f 	cmp	x3, x19
    4428:	54000169 	b.ls	4454 <fwp_rc_prepare_chunk+0x94>  // b.plast
    442c:	d503201f 	nop
    4430:	f9401283 	ldr	x3, [x20, #32]
    4434:	8b130060 	add	x0, x3, x19
    4438:	38736863 	ldrb	w3, [x3, x19]
    443c:	7103fc7f 	cmp	w3, #0xff
    4440:	54fffec0 	b.eq	4418 <fwp_rc_prepare_chunk+0x58>  // b.none
    4444:	b9401e83 	ldr	w3, [x20, #28]
    4448:	91000673 	add	x19, x19, #0x1
    444c:	eb13007f 	cmp	x3, x19
    4450:	54ffff08 	b.hi	4430 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4454:	eb0302bf 	cmp	x21, x3
    4458:	54000121 	b.ne	447c <fwp_rc_prepare_chunk+0xbc>  // b.any
    445c:	b5000335 	cbnz	x21, 44c0 <fwp_rc_prepare_chunk+0x100>
    4460:	a94153f3 	ldp	x19, x20, [sp, #16]
    4464:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	2a0303e3 	mov	w3, w3
    4474:	eb0302bf 	cmp	x21, x3
    4478:	54ffff20 	b.eq	445c <fwp_rc_prepare_chunk+0x9c>  // b.none
    447c:	911902c2 	add	x2, x22, #0x640
    4480:	f9401280 	ldr	x0, [x20, #32]
    4484:	f94e2841 	ldr	x1, [x2, #7248]
    4488:	cb030021 	sub	x1, x1, x3
    448c:	f90e2841 	str	x1, [x2, #7248]
    4490:	97fff910 	bl	28d0 <free@plt>
    4494:	b5fffb75 	cbnz	x21, 4400 <fwp_rc_prepare_chunk+0x40>
    4498:	f900129f 	str	xzr, [x20, #32]
    449c:	911902d6 	add	x22, x22, #0x640
    44a0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44a4:	b9001e95 	str	w21, [x20, #28]
    44a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ac:	8b150000 	add	x0, x0, x21
    44b0:	f90e2ac0 	str	x0, [x22, #7248]
    44b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f9401280 	ldr	x0, [x20, #32]
    44c4:	aa1503e2 	mov	x2, x21
    44c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44cc:	52800001 	mov	w1, #0x0                   	// #0
    44d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44d8:	17fff8c2 	b	27e0 <memset@plt>
    44dc:	d503201f 	nop

00000000000044e0 <fwp_heap_refill>:
    44e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44e4:	910003fd 	mov	x29, sp
    44e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44ec:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    44f0:	911902b5 	add	x21, x21, #0x640
    44f4:	aa0003f6 	mov	x22, x0
    44f8:	d2800020 	mov	x0, #0x1                   	// #1
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	a90363f7 	stp	x23, x24, [sp, #48]
    4504:	2a0103f7 	mov	w23, w1
    4508:	2a0203f8 	mov	w24, w2
    450c:	97fffb09 	bl	3130 <fwp_heap_chunks>
    4510:	aa0003f3 	mov	x19, x0
    4514:	f949fea2 	ldr	x2, [x21, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	2a1703e1 	mov	w1, w23
    4520:	52800025 	mov	w5, #0x1                   	// #1
    4524:	d37df000 	lsl	x0, x0, #3
    4528:	910f0021 	add	x1, x1, #0x3c0
    452c:	8b000054 	add	x20, x2, x0
    4530:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4534:	52a00024 	mov	w4, #0x10000               	// #65536
    4538:	38206845 	strb	w5, [x2, x0]
    453c:	aa1403e0 	mov	x0, x20
    4540:	39000698 	strb	w24, [x20, #1]
    4544:	39000a97 	strb	w23, [x20, #2]
    4548:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    454c:	b9000681 	str	w1, [x20, #4]
    4550:	2a0103e5 	mov	w5, w1
    4554:	8b0300a2 	add	x2, x5, x3
    4558:	1ac10881 	udiv	w1, w4, w1
    455c:	9ac50842 	udiv	x2, x2, x5
    4560:	b9000a81 	str	w1, [x20, #8]
    4564:	92404021 	and	x1, x1, #0x1ffff
    4568:	b9001a82 	str	w2, [x20, #24]
    456c:	97ffff95 	bl	43c0 <fwp_rc_prepare_chunk>
    4570:	f949daa0 	ldr	x0, [x21, #5040]
    4574:	29408a81 	ldp	w1, w2, [x20, #4]
    4578:	8b134000 	add	x0, x0, x19, lsl #16
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	8b214003 	add	x3, x0, w1, uxtw
    4584:	9ba20021 	umaddl	x1, w1, w2, x0
    4588:	a94363f7 	ldp	x23, x24, [sp, #48]
    458c:	a90086c3 	stp	x3, x1, [x22, #8]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4598:	d65f03c0 	ret
    459c:	d503201f 	nop

00000000000045a0 <fwp_mem_free>:
    45a0:	b40003c0 	cbz	x0, 4618 <fwp_mem_free+0x78>
    45a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45a8:	910003fd 	mov	x29, sp
    45ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    45b0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    45b4:	911902a1 	add	x1, x21, #0x640
    45b8:	a90153f3 	stp	x19, x20, [sp, #16]
    45bc:	aa0003f3 	mov	x19, x0
    45c0:	f949d823 	ldr	x3, [x1, #5040]
    45c4:	f949ec22 	ldr	x2, [x1, #5080]
    45c8:	cb030000 	sub	x0, x0, x3
    45cc:	eb02401f 	cmp	x0, x2, lsl #16
    45d0:	540001c2 	b.cs	4608 <fwp_mem_free+0x68>  // b.hs, b.nlast
    45d4:	d350fc16 	lsr	x22, x0, #16
    45d8:	a90363f7 	stp	x23, x24, [sp, #48]
    45dc:	f949fc22 	ldr	x2, [x1, #5112]
    45e0:	8b160ad4 	add	x20, x22, x22, lsl #2
    45e4:	d37df294 	lsl	x20, x20, #3
    45e8:	ab140057 	adds	x23, x2, x20
    45ec:	540000c0 	b.eq	4604 <fwp_mem_free+0x64>  // b.none
    45f0:	38746842 	ldrb	w2, [x2, x20]
    45f4:	7100045f 	cmp	w2, #0x1
    45f8:	54000120 	b.eq	461c <fwp_mem_free+0x7c>  // b.none
    45fc:	7100085f 	cmp	w2, #0x2
    4600:	540005e0 	b.eq	46bc <fwp_mem_free+0x11c>  // b.none
    4604:	a94363f7 	ldp	x23, x24, [sp, #48]
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4614:	d65f03c0 	ret
    4618:	d65f03c0 	ret
    461c:	f94012f8 	ldr	x24, [x23, #32]
    4620:	b94006e1 	ldr	w1, [x23, #4]
    4624:	f90023f9 	str	x25, [sp, #64]
    4628:	2a0103e2 	mov	w2, w1
    462c:	394006f9 	ldrb	w25, [x23, #1]
    4630:	39400af4 	ldrb	w20, [x23, #2]
    4634:	b4000158 	cbz	x24, 465c <fwp_mem_free+0xbc>
    4638:	92403e76 	and	x22, x19, #0xffff
    463c:	9ac20ad6 	udiv	x22, x22, x2
    4640:	38766b01 	ldrb	w1, [x24, x22]
    4644:	8b160300 	add	x0, x24, x22
    4648:	7103fc3f 	cmp	w1, #0xff
    464c:	54000980 	b.eq	477c <fwp_mem_free+0x1dc>  // b.none
    4650:	38366b1f 	strb	wzr, [x24, x22]
    4654:	b94006e1 	ldr	w1, [x23, #4]
    4658:	2a0103e2 	mov	w2, w1
    465c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4660:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4664:	cb390000 	sub	x0, x0, w25, uxtb
    4668:	8b340074 	add	x20, x3, w20, uxtb
    466c:	911902b5 	add	x21, x21, #0x640
    4670:	1e630021 	ucvtf	d1, w1
    4674:	d37ae400 	lsl	x0, x0, #6
    4678:	8b140c14 	add	x20, x0, x20, lsl #3
    467c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4680:	f8746aa0 	ldr	x0, [x21, x20]
    4684:	f94023f9 	ldr	x25, [sp, #64]
    4688:	aa2003e0 	mvn	x0, x0
    468c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4690:	f9000260 	str	x0, [x19]
    4694:	f8346ab3 	str	x19, [x21, x20]
    4698:	f94a12a0 	ldr	x0, [x21, #5152]
    469c:	1e612800 	fadd	d0, d0, d1
    46a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46a4:	cb020000 	sub	x0, x0, x2
    46a8:	f90a12a0 	str	x0, [x21, #5152]
    46ac:	fd0a22a0 	str	d0, [x21, #5184]
    46b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46b8:	d65f03c0 	ret
    46bc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46c0:	8b000063 	add	x3, x3, x0
    46c4:	eb03027f 	cmp	x19, x3
    46c8:	54fff9e1 	b.ne	4604 <fwp_mem_free+0x64>  // b.any
    46cc:	fd400ae1 	ldr	d1, [x23, #16]
    46d0:	fd4a2020 	ldr	d0, [x1, #5184]
    46d4:	f9400ae0 	ldr	x0, [x23, #16]
    46d8:	7e61d821 	ucvtf	d1, d1
    46dc:	f94a1022 	ldr	x2, [x1, #5152]
    46e0:	f94012f3 	ldr	x19, [x23, #32]
    46e4:	1e612800 	fadd	d0, d0, d1
    46e8:	cb000042 	sub	x2, x2, x0
    46ec:	f90a1022 	str	x2, [x1, #5152]
    46f0:	fd0a2020 	str	d0, [x1, #5184]
    46f4:	b40000b3 	cbz	x19, 4708 <fwp_mem_free+0x168>
    46f8:	39400260 	ldrb	w0, [x19]
    46fc:	7103fc1f 	cmp	w0, #0xff
    4700:	54000380 	b.eq	4770 <fwp_mem_free+0x1d0>  // b.none
    4704:	3900027f 	strb	wzr, [x19]
    4708:	b9400ee2 	ldr	w2, [x23, #12]
    470c:	b4000142 	cbz	x2, 4734 <fwp_mem_free+0x194>
    4710:	911902a1 	add	x1, x21, #0x640
    4714:	8b160040 	add	x0, x2, x22
    4718:	8b000800 	add	x0, x0, x0, lsl #2
    471c:	f949fc21 	ldr	x1, [x1, #5112]
    4720:	8b140034 	add	x20, x1, x20
    4724:	8b000c20 	add	x0, x1, x0, lsl #3
    4728:	3802869f 	strb	wzr, [x20], #40
    472c:	eb00029f 	cmp	x20, x0
    4730:	54ffffc1 	b.ne	4728 <fwp_mem_free+0x188>  // b.any
    4734:	911902a0 	add	x0, x21, #0x640
    4738:	f94a1801 	ldr	x1, [x0, #5168]
    473c:	f949f803 	ldr	x3, [x0, #5104]
    4740:	8b020021 	add	x1, x1, x2
    4744:	f90a1801 	str	x1, [x0, #5168]
    4748:	eb16007f 	cmp	x3, x22
    474c:	54000049 	b.ls	4754 <fwp_mem_free+0x1b4>  // b.plast
    4750:	f909f816 	str	x22, [x0, #5104]
    4754:	911902b5 	add	x21, x21, #0x640
    4758:	f949f6a0 	ldr	x0, [x21, #5096]
    475c:	eb16001f 	cmp	x0, x22
    4760:	54fff529 	b.ls	4604 <fwp_mem_free+0x64>  // b.plast
    4764:	a94363f7 	ldp	x23, x24, [sp, #48]
    4768:	f909f6b6 	str	x22, [x21, #5096]
    476c:	17ffffa7 	b	4608 <fwp_mem_free+0x68>
    4770:	aa1303e0 	mov	x0, x19
    4774:	97fffef0 	bl	4334 <fwp_rc_forget_slot.part.0>
    4778:	17ffffe3 	b	4704 <fwp_mem_free+0x164>
    477c:	97fffeee 	bl	4334 <fwp_rc_forget_slot.part.0>
    4780:	17ffffb4 	b	4650 <fwp_mem_free+0xb0>

0000000000004784 <fwp_rc_wide_dup>:
    4784:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4788:	910003fd 	mov	x29, sp
    478c:	a90153f3 	stp	x19, x20, [sp, #16]
    4790:	aa0003f3 	mov	x19, x0
    4794:	ca404400 	eor	x0, x0, x0, lsr #17
    4798:	f90013f5 	str	x21, [sp, #32]
    479c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    47a0:	ca402400 	eor	x0, x0, x0, lsr #9
    47a4:	911902a2 	add	x2, x21, #0x640
    47a8:	92401c00 	and	x0, x0, #0xff
    47ac:	910a2403 	add	x3, x0, #0x289
    47b0:	8b000c40 	add	x0, x2, x0, lsl #3
    47b4:	8b030c54 	add	x20, x2, x3, lsl #3
    47b8:	f94a2401 	ldr	x1, [x0, #5192]
    47bc:	b50000a1 	cbnz	x1, 47d0 <fwp_rc_wide_dup+0x4c>
    47c0:	14000033 	b	488c <fwp_rc_wide_dup+0x108>
    47c4:	91004034 	add	x20, x1, #0x10
    47c8:	f9400821 	ldr	x1, [x1, #16]
    47cc:	b4000241 	cbz	x1, 4814 <fwp_rc_wide_dup+0x90>
    47d0:	f9400022 	ldr	x2, [x1]
    47d4:	eb02027f 	cmp	x19, x2
    47d8:	54ffff61 	b.ne	47c4 <fwp_rc_wide_dup+0x40>  // b.any
    47dc:	f9400281 	ldr	x1, [x20]
    47e0:	39400260 	ldrb	w0, [x19]
    47e4:	7103f81f 	cmp	w0, #0xfe
    47e8:	54000220 	b.eq	482c <fwp_rc_wide_dup+0xa8>  // b.none
    47ec:	b40001a1 	cbz	x1, 4820 <fwp_rc_wide_dup+0x9c>
    47f0:	f9400420 	ldr	x0, [x1, #8]
    47f4:	b100041f 	cmn	x0, #0x1
    47f8:	54000440 	b.eq	4880 <fwp_rc_wide_dup+0xfc>  // b.none
    47fc:	91000400 	add	x0, x0, #0x1
    4800:	f9000420 	str	x0, [x1, #8]
    4804:	a94153f3 	ldp	x19, x20, [sp, #16]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	39400260 	ldrb	w0, [x19]
    4818:	7103f81f 	cmp	w0, #0xfe
    481c:	54000100 	b.eq	483c <fwp_rc_wide_dup+0xb8>  // b.none
    4820:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4824:	913be000 	add	x0, x0, #0xef8
    4828:	97fffea3 	bl	42b4 <fwp_trap>
    482c:	b4000081 	cbz	x1, 483c <fwp_rc_wide_dup+0xb8>
    4830:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4834:	913c8000 	add	x0, x0, #0xf20
    4838:	97fffe9f 	bl	42b4 <fwp_trap>
    483c:	d2800300 	mov	x0, #0x18                  	// #24
    4840:	97fff7dc 	bl	27b0 <malloc@plt>
    4844:	b4000280 	cbz	x0, 4894 <fwp_rc_wide_dup+0x110>
    4848:	d2801fe1 	mov	x1, #0xff                  	// #255
    484c:	a9000413 	stp	x19, x1, [x0]
    4850:	911902b5 	add	x21, x21, #0x640
    4854:	f900081f 	str	xzr, [x0, #16]
    4858:	12800001 	mov	w1, #0xffffffff            	// #-1
    485c:	f9000280 	str	x0, [x20]
    4860:	39000261 	strb	w1, [x19]
    4864:	f94e26a0 	ldr	x0, [x21, #7240]
    4868:	a94153f3 	ldp	x19, x20, [sp, #16]
    486c:	91000400 	add	x0, x0, #0x1
    4870:	f90e26a0 	str	x0, [x21, #7240]
    4874:	f94013f5 	ldr	x21, [sp, #32]
    4878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    487c:	d65f03c0 	ret
    4880:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4884:	913d2000 	add	x0, x0, #0xf48
    4888:	97fffe8b 	bl	42b4 <fwp_trap>
    488c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4890:	17ffffd4 	b	47e0 <fwp_rc_wide_dup+0x5c>
    4894:	97fffa17 	bl	30f0 <fwp_heap_oom>
    4898:	d503201f 	nop
    489c:	d503201f 	nop

00000000000048a0 <fwp_closure_drop_push>:
    48a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48a4:	910003fd 	mov	x29, sp
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	aa0003f3 	mov	x19, x0
    48b0:	a9408014 	ldp	x20, x0, [x0, #8]
    48b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48b8:	aa0103f5 	mov	x21, x1
    48bc:	a90363f7 	stp	x23, x24, [sp, #48]
    48c0:	eb00029f 	cmp	x20, x0
    48c4:	54000160 	b.eq	48f0 <fwp_closure_drop_push+0x50>  // b.none
    48c8:	f9400276 	ldr	x22, [x19]
    48cc:	d37df297 	lsl	x23, x20, #3
    48d0:	91000694 	add	x20, x20, #0x1
    48d4:	f9000674 	str	x20, [x19, #8]
    48d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48dc:	f8376ad5 	str	x21, [x22, x23]
    48e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48e8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48ec:	d65f03c0 	ret
    48f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    48f4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    48f8:	eb00029f 	cmp	x20, x0
    48fc:	540003e8 	b.hi	4978 <fwp_closure_drop_push+0xd8>  // b.pmore
    4900:	d37cee99 	lsl	x25, x20, #4
    4904:	d37ffa9a 	lsl	x26, x20, #1
    4908:	aa1903e0 	mov	x0, x25
    490c:	97fff7a9 	bl	27b0 <malloc@plt>
    4910:	aa0003f6 	mov	x22, x0
    4914:	b4000380 	cbz	x0, 4984 <fwp_closure_drop_push+0xe4>
    4918:	aa1303f8 	mov	x24, x19
    491c:	aa1903e3 	mov	x3, x25
    4920:	d37df297 	lsl	x23, x20, #3
    4924:	aa1703e2 	mov	x2, x23
    4928:	f8418719 	ldr	x25, [x24], #24
    492c:	aa1903e1 	mov	x1, x25
    4930:	97fff78c 	bl	2760 <__memcpy_chk@plt>
    4934:	eb18033f 	cmp	x25, x24
    4938:	540000a0 	b.eq	494c <fwp_closure_drop_push+0xac>  // b.none
    493c:	aa1903e0 	mov	x0, x25
    4940:	97fff7e4 	bl	28d0 <free@plt>
    4944:	f9400674 	ldr	x20, [x19, #8]
    4948:	d37df297 	lsl	x23, x20, #3
    494c:	91000694 	add	x20, x20, #0x1
    4950:	f9000276 	str	x22, [x19]
    4954:	f9000a7a 	str	x26, [x19, #16]
    4958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    495c:	f9000674 	str	x20, [x19, #8]
    4960:	f8376ad5 	str	x21, [x22, x23]
    4964:	a94153f3 	ldp	x19, x20, [sp, #16]
    4968:	a9425bf5 	ldp	x21, x22, [sp, #32]
    496c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4970:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4974:	d65f03c0 	ret
    4978:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    497c:	913da000 	add	x0, x0, #0xf68
    4980:	97fffe4d 	bl	42b4 <fwp_trap>
    4984:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    4988:	f947e863 	ldr	x3, [x3, #4048]
    498c:	d2800262 	mov	x2, #0x13                  	// #19
    4990:	d2800021 	mov	x1, #0x1                   	// #1
    4994:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4998:	912ea000 	add	x0, x0, #0xba8
    499c:	f9400063 	ldr	x3, [x3]
    49a0:	97fff7dc 	bl	2910 <fwrite@plt>
    49a4:	d2800000 	mov	x0, #0x0                   	// #0
    49a8:	97fff7e6 	bl	2940 <fflush@plt>
    49ac:	52800cc0 	mov	w0, #0x66                  	// #102
    49b0:	97fff7f4 	bl	2980 <_Exit@plt>

00000000000049b4 <fwp_closure_drop.part.0>:
    49b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49b8:	90000041 	adrp	x1, c000 <_IO_stdin_used+0x460>
    49bc:	910003fd 	mov	x29, sp
    49c0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    49c4:	f947f463 	ldr	x3, [x3, #4072]
    49c8:	a90153f3 	stp	x19, x20, [sp, #16]
    49cc:	d10883ff 	sub	sp, sp, #0x220
    49d0:	910003e2 	mov	x2, sp
    49d4:	d53bd053 	mrs	x19, tpidr_el0
    49d8:	910063f4 	add	x20, sp, #0x18
    49dc:	3dc2d420 	ldr	q0, [x1, #2896]
    49e0:	91400264 	add	x4, x19, #0x0, lsl #12
    49e4:	91004084 	add	x4, x4, #0x10
    49e8:	aa0003e1 	mov	x1, x0
    49ec:	aa0203e0 	mov	x0, x2
    49f0:	f9400062 	ldr	x2, [x3]
    49f4:	f9010fe2 	str	x2, [sp, #536]
    49f8:	d2800002 	mov	x2, #0x0                   	// #0
    49fc:	f90003f4 	str	x20, [sp]
    4a00:	f9000080 	str	x0, [x4]
    4a04:	3c8083e0 	stur	q0, [sp, #8]
    4a08:	97ffffa6 	bl	48a0 <fwp_closure_drop_push>
    4a0c:	f94007e0 	ldr	x0, [sp, #8]
    4a10:	b40002e0 	cbz	x0, 4a6c <fwp_closure_drop.part.0+0xb8>
    4a14:	f90123f5 	str	x21, [sp, #576]
    4a18:	900000f5 	adrp	x21, 20000 <__data_start>
    4a1c:	910182b5 	add	x21, x21, #0x60
    4a20:	14000006 	b	4a38 <fwp_closure_drop.part.0+0x84>
    4a24:	f9400422 	ldr	x2, [x1, #8]
    4a28:	52800001 	mov	w1, #0x0                   	// #0
    4a2c:	d63f0040 	blr	x2
    4a30:	f94007e0 	ldr	x0, [sp, #8]
    4a34:	b40001a0 	cbz	x0, 4a68 <fwp_closure_drop.part.0+0xb4>
    4a38:	f94003e1 	ldr	x1, [sp]
    4a3c:	d1000400 	sub	x0, x0, #0x1
    4a40:	f90007e0 	str	x0, [sp, #8]
    4a44:	f9408ea2 	ldr	x2, [x21, #280]
    4a48:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a4c:	b9400001 	ldr	w1, [x0]
    4a50:	8b011441 	add	x1, x2, x1, lsl #5
    4a54:	f9400c21 	ldr	x1, [x1, #24]
    4a58:	b5fffe61 	cbnz	x1, 4a24 <fwp_closure_drop.part.0+0x70>
    4a5c:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4a60:	913e2000 	add	x0, x0, #0xf88
    4a64:	97fffe14 	bl	42b4 <fwp_trap>
    4a68:	f94123f5 	ldr	x21, [sp, #576]
    4a6c:	91400273 	add	x19, x19, #0x0, lsl #12
    4a70:	91004273 	add	x19, x19, #0x10
    4a74:	f94003e0 	ldr	x0, [sp]
    4a78:	f900027f 	str	xzr, [x19]
    4a7c:	eb14001f 	cmp	x0, x20
    4a80:	54000040 	b.eq	4a88 <fwp_closure_drop.part.0+0xd4>  // b.none
    4a84:	97fff793 	bl	28d0 <free@plt>
    4a88:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4a8c:	f947f400 	ldr	x0, [x0, #4072]
    4a90:	f9410fe2 	ldr	x2, [sp, #536]
    4a94:	f9400001 	ldr	x1, [x0]
    4a98:	eb010042 	subs	x2, x2, x1
    4a9c:	d2800001 	mov	x1, #0x0                   	// #0
    4aa0:	540000a1 	b.ne	4ab4 <fwp_closure_drop.part.0+0x100>  // b.any
    4aa4:	910883ff 	add	sp, sp, #0x220
    4aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ab0:	d65f03c0 	ret
    4ab4:	f90123f5 	str	x21, [sp, #576]
    4ab8:	97fff756 	bl	2810 <__stack_chk_fail@plt>
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_tape_of>:
    4ac0:	aa0003e1 	mov	x1, x0
    4ac4:	92403c00 	and	x0, x0, #0xffff
    4ac8:	b40000e0 	cbz	x0, 4ae4 <fwp_tape_of+0x24>
    4acc:	d1000402 	sub	x2, x0, #0x1
    4ad0:	900000e0 	adrp	x0, 20000 <__data_start>
    4ad4:	91018000 	add	x0, x0, #0x60
    4ad8:	f9409003 	ldr	x3, [x0, #288]
    4adc:	eb02007f 	cmp	x3, x2
    4ae0:	540000cc 	b.gt	4af8 <fwp_tape_of+0x38>
    4ae4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4ae8:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    4aec:	913ee000 	add	x0, x0, #0xfb8
    4af0:	910003fd 	mov	x29, sp
    4af4:	97fffdf0 	bl	42b4 <fwp_trap>
    4af8:	8b020443 	add	x3, x2, x2, lsl #1
    4afc:	f9404404 	ldr	x4, [x0, #136]
    4b00:	8b030842 	add	x2, x2, x3, lsl #2
    4b04:	d37df042 	lsl	x2, x2, #3
    4b08:	8b020080 	add	x0, x4, x2
    4b0c:	b9400403 	ldr	w3, [x0, #4]
    4b10:	34fffea3 	cbz	w3, 4ae4 <fwp_tape_of+0x24>
    4b14:	b8626882 	ldr	w2, [x4, x2]
    4b18:	9350fc21 	asr	x1, x1, #16
    4b1c:	6b01005f 	cmp	w2, w1
    4b20:	54fffe21 	b.ne	4ae4 <fwp_tape_of+0x24>  // b.any
    4b24:	d65f03c0 	ret
    4b28:	d503201f 	nop
    4b2c:	d503201f 	nop

0000000000004b30 <fwp_now_ns>:
    4b30:	d100c3ff 	sub	sp, sp, #0x30
    4b34:	52800020 	mov	w0, #0x1                   	// #1
    4b38:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    4b3c:	f947f442 	ldr	x2, [x2, #4072]
    4b40:	910023e1 	add	x1, sp, #0x8
    4b44:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b48:	910083fd 	add	x29, sp, #0x20
    4b4c:	f9400043 	ldr	x3, [x2]
    4b50:	f9000fe3 	str	x3, [sp, #24]
    4b54:	d2800003 	mov	x3, #0x0                   	// #0
    4b58:	97fff6fa 	bl	2740 <clock_gettime@plt>
    4b5c:	350002c0 	cbnz	w0, 4bb4 <fwp_now_ns+0x84>
    4b60:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b64:	d2994003 	mov	x3, #0xca00                	// #51712
    4b68:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b6c:	9b037c20 	mul	x0, x1, x3
    4b70:	9b437c21 	smulh	x1, x1, x3
    4b74:	ab020000 	adds	x0, x0, x2
    4b78:	937ffc42 	asr	x2, x2, #63
    4b7c:	9a020021 	adc	x1, x1, x2
    4b80:	f100001f 	cmp	x0, #0x0
    4b84:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4b88:	b50001c1 	cbnz	x1, 4bc0 <fwp_now_ns+0x90>
    4b8c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    4b90:	f947f421 	ldr	x1, [x1, #4072]
    4b94:	f9400fe3 	ldr	x3, [sp, #24]
    4b98:	f9400022 	ldr	x2, [x1]
    4b9c:	eb020063 	subs	x3, x3, x2
    4ba0:	d2800002 	mov	x2, #0x0                   	// #0
    4ba4:	54000141 	b.ne	4bcc <fwp_now_ns+0x9c>  // b.any
    4ba8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bac:	9100c3ff 	add	sp, sp, #0x30
    4bb0:	d65f03c0 	ret
    4bb4:	90000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    4bb8:	91002000 	add	x0, x0, #0x8
    4bbc:	97fffdbe 	bl	42b4 <fwp_trap>
    4bc0:	90000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    4bc4:	9100a000 	add	x0, x0, #0x28
    4bc8:	97fffdbb 	bl	42b4 <fwp_trap>
    4bcc:	97fff711 	bl	2810 <__stack_chk_fail@plt>

0000000000004bd0 <fwp_poll_events>:
    4bd0:	d10103ff 	sub	sp, sp, #0x40
    4bd4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4bd8:	f947f400 	ldr	x0, [x0, #4072]
    4bdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4be0:	910083fd 	add	x29, sp, #0x20
    4be4:	f9001bf3 	str	x19, [sp, #48]
    4be8:	900000f3 	adrp	x19, 20000 <__data_start>
    4bec:	f9400001 	ldr	x1, [x0]
    4bf0:	f9000fe1 	str	x1, [sp, #24]
    4bf4:	d2800001 	mov	x1, #0x0                   	// #0
    4bf8:	97ffffce 	bl	4b30 <fwp_now_ns>
    4bfc:	91018261 	add	x1, x19, #0x60
    4c00:	f9409421 	ldr	x1, [x1, #296]
    4c04:	b4000e01 	cbz	x1, 4dc4 <fwp_poll_events+0x1f4>
    4c08:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c0c:	14000005 	b	4c20 <fwp_poll_events+0x50>
    4c10:	f9408821 	ldr	x1, [x1, #272]
    4c14:	eb03005f 	cmp	x2, x3
    4c18:	9a83d042 	csel	x2, x2, x3, le
    4c1c:	b40000c1 	cbz	x1, 4c34 <fwp_poll_events+0x64>
    4c20:	f9403423 	ldr	x3, [x1, #104]
    4c24:	b6ffff62 	tbz	x2, #63, 4c10 <fwp_poll_events+0x40>
    4c28:	f9408821 	ldr	x1, [x1, #272]
    4c2c:	aa0303e2 	mov	x2, x3
    4c30:	b5ffff81 	cbnz	x1, 4c20 <fwp_poll_events+0x50>
    4c34:	b7f80c82 	tbnz	x2, #63, 4dc4 <fwp_poll_events+0x1f4>
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f100005f 	cmp	x2, #0x0
    4c40:	540003ad 	b.le	4cb4 <fwp_poll_events+0xe4>
    4c44:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c48:	d2884804 	mov	x4, #0x4240                	// #16960
    4c4c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c50:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c54:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c58:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c5c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c60:	9b407c40 	smulh	x0, x2, x0
    4c64:	9352fc00 	asr	x0, x0, #18
    4c68:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c6c:	9b048802 	msub	x2, x0, x4, x2
    4c70:	f100005f 	cmp	x2, #0x0
    4c74:	9a800400 	cinc	x0, x0, ne	// ne = any
    4c78:	eb01001f 	cmp	x0, x1
    4c7c:	5400098c 	b.gt	4dac <fwp_poll_events+0x1dc>
    4c80:	340001a0 	cbz	w0, 4cb4 <fwp_poll_events+0xe4>
    4c84:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4c88:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4c8c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4c90:	9ba17c01 	umull	x1, w0, w1
    4c94:	d366fc23 	lsr	x3, x1, #38
    4c98:	aa0303e2 	mov	x2, x3
    4c9c:	1b058063 	msub	w3, w3, w5, w0
    4ca0:	9b247c63 	smull	x3, w3, w4
    4ca4:	910023e0 	add	x0, sp, #0x8
    4ca8:	d2800001 	mov	x1, #0x0                   	// #0
    4cac:	a9008fe2 	stp	x2, x3, [sp, #8]
    4cb0:	97fff70c 	bl	28e0 <nanosleep@plt>
    4cb4:	97ffff9f 	bl	4b30 <fwp_now_ns>
    4cb8:	91018268 	add	x8, x19, #0x60
    4cbc:	aa0003e7 	mov	x7, x0
    4cc0:	4f000400 	movi	v0.4s, #0x0
    4cc4:	52800029 	mov	w9, #0x1                   	// #1
    4cc8:	f9409506 	ldr	x6, [x8, #296]
    4ccc:	d503201f 	nop
    4cd0:	b40003e6 	cbz	x6, 4d4c <fwp_poll_events+0x17c>
    4cd4:	f94034c1 	ldr	x1, [x6, #104]
    4cd8:	aa0603e5 	mov	x5, x6
    4cdc:	f94088c6 	ldr	x6, [x6, #272]
    4ce0:	eb07003f 	cmp	x1, x7
    4ce4:	54ffff6c 	b.gt	4cd0 <fwp_poll_events+0x100>
    4ce8:	394154a0 	ldrb	w0, [x5, #85]
    4cec:	36000120 	tbz	w0, #0, 4d10 <fwp_poll_events+0x140>
    4cf0:	f94084a0 	ldr	x0, [x5, #264]
    4cf4:	b4000560 	cbz	x0, 4da0 <fwp_poll_events+0x1d0>
    4cf8:	f9008806 	str	x6, [x0, #272]
    4cfc:	b4000046 	cbz	x6, 4d04 <fwp_poll_events+0x134>
    4d00:	f90084c0 	str	x0, [x6, #264]
    4d04:	910800a0 	add	x0, x5, #0x200
    4d08:	390154bf 	strb	wzr, [x5, #85]
    4d0c:	3c908000 	stur	q0, [x0, #-248]
    4d10:	f94030a0 	ldr	x0, [x5, #96]
    4d14:	390158a9 	strb	w9, [x5, #86]
    4d18:	f100001f 	cmp	x0, #0x0
    4d1c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d20:	540002cd 	b.le	4d78 <fwp_poll_events+0x1a8>
    4d24:	f94028a0 	ldr	x0, [x5, #80]
    4d28:	f2001c1f 	tst	x0, #0xff000000ff
    4d2c:	54fffd21 	b.ne	4cd0 <fwp_poll_events+0x100>  // b.any
    4d30:	f9406100 	ldr	x0, [x8, #192]
    4d34:	390150a9 	strb	w9, [x5, #84]
    4d38:	f90080bf 	str	xzr, [x5, #256]
    4d3c:	b40002c0 	cbz	x0, 4d94 <fwp_poll_events+0x1c4>
    4d40:	f9006105 	str	x5, [x8, #192]
    4d44:	f9008005 	str	x5, [x0, #256]
    4d48:	b5fffc66 	cbnz	x6, 4cd4 <fwp_poll_events+0x104>
    4d4c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4d50:	f947f400 	ldr	x0, [x0, #4072]
    4d54:	f9400fe2 	ldr	x2, [sp, #24]
    4d58:	f9400001 	ldr	x1, [x0]
    4d5c:	eb010042 	subs	x2, x2, x1
    4d60:	d2800001 	mov	x1, #0x0                   	// #0
    4d64:	540002e1 	b.ne	4dc0 <fwp_poll_events+0x1f0>  // b.any
    4d68:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d6c:	f9401bf3 	ldr	x19, [sp, #48]
    4d70:	910103ff 	add	sp, sp, #0x40
    4d74:	d65f03c0 	ret
    4d78:	394144a0 	ldrb	w0, [x5, #81]
    4d7c:	3707fd40 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d80:	394140a0 	ldrb	w0, [x5, #80]
    4d84:	3707fd00 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d88:	aa0503e0 	mov	x0, x5
    4d8c:	97fffa39 	bl	3670 <fwp_cancel_tree.part.0>
    4d90:	17ffffe5 	b	4d24 <fwp_poll_events+0x154>
    4d94:	f9006105 	str	x5, [x8, #192]
    4d98:	f9006505 	str	x5, [x8, #200]
    4d9c:	17ffffeb 	b	4d48 <fwp_poll_events+0x178>
    4da0:	91018261 	add	x1, x19, #0x60
    4da4:	f9009426 	str	x6, [x1, #296]
    4da8:	17ffffd5 	b	4cfc <fwp_poll_events+0x12c>
    4dac:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4db0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4db4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4db8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dbc:	17ffffba 	b	4ca4 <fwp_poll_events+0xd4>
    4dc0:	97fff694 	bl	2810 <__stack_chk_fail@plt>
    4dc4:	97fff88c 	bl	2ff4 <fwp_flush>
    4dc8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    4dcc:	f947e863 	ldr	x3, [x3, #4048]
    4dd0:	d2800562 	mov	x2, #0x2b                  	// #43
    4dd4:	d2800021 	mov	x1, #0x1                   	// #1
    4dd8:	90000040 	adrp	x0, c000 <_IO_stdin_used+0x460>
    4ddc:	91014000 	add	x0, x0, #0x50
    4de0:	f9400063 	ldr	x3, [x3]
    4de4:	97fff6cb 	bl	2910 <fwrite@plt>
    4de8:	52800ca0 	mov	w0, #0x65                  	// #101
    4dec:	97fff635 	bl	26c0 <exit@plt>

0000000000004df0 <fwp_heap_alloc_big>:
    4df0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df4:	910003fd 	mov	x29, sp
    4df8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e00:	a90363f7 	stp	x23, x24, [sp, #48]
    4e04:	aa0003f7 	mov	x23, x0
    4e08:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e0c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e10:	eb0002ff 	cmp	x23, x0
    4e14:	540008a8 	b.hi	4f28 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e18:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e1c:	8b0002f4 	add	x20, x23, x0
    4e20:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e24:	91190359 	add	x25, x26, #0x640
    4e28:	d350fe94 	lsr	x20, x20, #16
    4e2c:	2a0103f5 	mov	w21, w1
    4e30:	aa1403e0 	mov	x0, x20
    4e34:	97fff8bf 	bl	3130 <fwp_heap_chunks>
    4e38:	f949ff22 	ldr	x2, [x25, #5112]
    4e3c:	8b000813 	add	x19, x0, x0, lsl #2
    4e40:	aa0003f8 	mov	x24, x0
    4e44:	52800043 	mov	w3, #0x2                   	// #2
    4e48:	d37df273 	lsl	x19, x19, #3
    4e4c:	d2800021 	mov	x1, #0x1                   	// #1
    4e50:	8b130040 	add	x0, x2, x19
    4e54:	38336843 	strb	w3, [x2, x19]
    4e58:	39000415 	strb	w21, [x0, #1]
    4e5c:	b9000c14 	str	w20, [x0, #12]
    4e60:	f9000817 	str	x23, [x0, #16]
    4e64:	97fffd57 	bl	43c0 <fwp_rc_prepare_chunk>
    4e68:	f100069f 	cmp	x20, #0x1
    4e6c:	54000289 	b.ls	4ebc <fwp_heap_alloc_big+0xcc>  // b.plast
    4e70:	8b180294 	add	x20, x20, x24
    4e74:	9100a273 	add	x19, x19, #0x28
    4e78:	a90573fb 	stp	x27, x28, [sp, #80]
    4e7c:	5280007b 	mov	w27, #0x3                   	// #3
    4e80:	8b140a94 	add	x20, x20, x20, lsl #2
    4e84:	2a1803fc 	mov	w28, w24
    4e88:	9adb2296 	lsl	x22, x20, x27
    4e8c:	d503201f 	nop
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffd48 	bl	43c0 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0xa0>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffb37 	bl	3cf0 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff6f 	b	4df0 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffd19 	bl	44e0 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	540008a1 	b.ne	51cc <fwp_heap_alloc+0x13c>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	54000722 	b.cs	5218 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	5400030c 	b.gt	51e0 <fwp_heap_alloc+0x150>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000249 	b.ls	51fc <fwp_heap_alloc+0x16c>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	910182c1 	add	x1, x22, #0x60
    51c4:	b9413038 	ldr	w24, [x1, #304]
    51c8:	17ffffe6 	b	5160 <fwp_heap_alloc+0xd0>
    51cc:	a9538c44 	ldp	x4, x3, [x2, #312]
    51d0:	91000484 	add	x4, x4, #0x1
    51d4:	8b000063 	add	x3, x3, x0
    51d8:	a9138c44 	stp	x4, x3, [x2, #312]
    51dc:	17ffffb8 	b	50bc <fwp_heap_alloc+0x2c>
    51e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51e4:	fd00a800 	str	d0, [x0, #336]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	aa0403e0 	mov	x0, x4
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f8:	d65f03c0 	ret
    51fc:	7100043f 	cmp	w1, #0x1
    5200:	8b140085 	add	x5, x4, x20
    5204:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5208:	52800001 	mov	w1, #0x0                   	// #0
    520c:	aa0403e0 	mov	x0, x4
    5210:	f9000465 	str	x5, [x3, #8]
    5214:	17ffffc4 	b	5124 <fwp_heap_alloc+0x94>
    5218:	97fff7b6 	bl	30f0 <fwp_heap_oom>
    521c:	d503201f 	nop

0000000000005220 <fwp_apply>:
    5220:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5224:	aa0003e6 	mov	x6, x0
    5228:	910003fd 	mov	x29, sp
    522c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5230:	f947f463 	ldr	x3, [x3, #4072]
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	aa0203f4 	mov	x20, x2
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	2a0103f5 	mov	w21, w1
    5244:	52800033 	mov	w19, #0x1                   	// #1
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	f00000d7 	adrp	x23, 20000 <__data_start>
    5250:	910182f7 	add	x23, x23, #0x60
    5254:	a9046bf9 	stp	x25, x26, [sp, #64]
    5258:	d100c3ff 	sub	sp, sp, #0x30
    525c:	f9400060 	ldr	x0, [x3]
    5260:	f81f83a0 	stur	x0, [x29, #-8]
    5264:	d2800000 	mov	x0, #0x0                   	// #0
    5268:	294058c3 	ldp	w3, w22, [x6]
    526c:	910003f8 	mov	x24, sp
    5270:	f9408ee0 	ldr	x0, [x23, #280]
    5274:	710002df 	cmp	w22, #0x0
    5278:	d37be863 	lsl	x3, x3, #5
    527c:	8b030007 	add	x7, x0, x3
    5280:	b8636819 	ldr	w25, [x0, x3]
    5284:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    5288:	54000163 	b.cc	52b4 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    528c:	f94004e3 	ldr	x3, [x7, #8]
    5290:	34000bb9 	cbz	w25, 5404 <fwp_apply+0x1e4>
    5294:	aa1403e0 	mov	x0, x20
    5298:	d63f0060 	blr	x3
    529c:	aa0003e6 	mov	x6, x0
    52a0:	6b1902bf 	cmp	w21, w25
    52a4:	54000920 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    52a8:	8b394e94 	add	x20, x20, w25, uxtw #3
    52ac:	4b1902b5 	sub	w21, w21, w25
    52b0:	17ffffee 	b	5268 <fwp_apply+0x48>
    52b4:	0b1602ba 	add	w26, w21, w22
    52b8:	6b19035f 	cmp	w26, w25
    52bc:	54000523 	b.cc	5360 <fwp_apply+0x140>  // b.lo, b.ul, b.last
    52c0:	7100033f 	cmp	w25, #0x0
    52c4:	4b16033a 	sub	w26, w25, w22
    52c8:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52cc:	d37df000 	lsl	x0, x0, #3
    52d0:	91003c00 	add	x0, x0, #0xf
    52d4:	92704c01 	and	x1, x0, #0xfffff0000
    52d8:	927c7c00 	and	x0, x0, #0xffffffff0
    52dc:	cb2163e1 	sub	x1, sp, x1
    52e0:	eb2163ff 	cmp	sp, x1
    52e4:	540000a0 	b.eq	52f8 <fwp_apply+0xd8>  // b.none
    52e8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52ec:	f90203ff 	str	xzr, [sp, #1024]
    52f0:	eb2163ff 	cmp	sp, x1
    52f4:	54ffffa1 	b.ne	52e8 <fwp_apply+0xc8>  // b.any
    52f8:	92403c00 	and	x0, x0, #0xffff
    52fc:	cb2063ff 	sub	sp, sp, x0
    5300:	f90003ff 	str	xzr, [sp]
    5304:	f110001f 	cmp	x0, #0x400
    5308:	54000942 	b.cs	5430 <fwp_apply+0x210>  // b.hs, b.nlast
    530c:	910020c6 	add	x6, x6, #0x8
    5310:	910043e0 	add	x0, sp, #0x10
    5314:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    5318:	d2800003 	mov	x3, #0x0                   	// #0
    531c:	340000d6 	cbz	w22, 5334 <fwp_apply+0x114>
    5320:	f86368c4 	ldr	x4, [x6, x3]
    5324:	f8236804 	str	x4, [x0, x3]
    5328:	91002063 	add	x3, x3, #0x8
    532c:	eb0300bf 	cmp	x5, x3
    5330:	54ffff81 	b.ne	5320 <fwp_apply+0x100>  // b.any
    5334:	3400013a 	cbz	w26, 5358 <fwp_apply+0x138>
    5338:	2a1a03e6 	mov	w6, w26
    533c:	d2800003 	mov	x3, #0x0                   	// #0
    5340:	0b0302c4 	add	w4, w22, w3
    5344:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5348:	91000463 	add	x3, x3, #0x1
    534c:	f8247805 	str	x5, [x0, x4, lsl #3]
    5350:	eb0300df 	cmp	x6, x3
    5354:	54ffff61 	b.ne	5340 <fwp_apply+0x120>  // b.any
    5358:	f94004e3 	ldr	x3, [x7, #8]
    535c:	1400002c 	b	540c <fwp_apply+0x1ec>
    5360:	11000740 	add	w0, w26, #0x1
    5364:	52800041 	mov	w1, #0x2                   	// #2
    5368:	f81e83a6 	stur	x6, [x29, #-24]
    536c:	d37df000 	lsl	x0, x0, #3
    5370:	97ffff48 	bl	5090 <fwp_heap_alloc>
    5374:	f85e83a6 	ldur	x6, [x29, #-24]
    5378:	aa0003f3 	mov	x19, x0
    537c:	b94000c1 	ldr	w1, [x6]
    5380:	29006801 	stp	w1, w26, [x0]
    5384:	340000b6 	cbz	w22, 5398 <fwp_apply+0x178>
    5388:	910020c1 	add	x1, x6, #0x8
    538c:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5390:	91002000 	add	x0, x0, #0x8
    5394:	97fff4bb 	bl	2680 <memmove@plt>
    5398:	2a1503e3 	mov	w3, w21
    539c:	d2800000 	mov	x0, #0x0                   	// #0
    53a0:	34000135 	cbz	w21, 53c4 <fwp_apply+0x1a4>
    53a4:	d503201f 	nop
    53a8:	0b0002c1 	add	w1, w22, w0
    53ac:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53b0:	8b010e61 	add	x1, x19, x1, lsl #3
    53b4:	91000400 	add	x0, x0, #0x1
    53b8:	f9000422 	str	x2, [x1, #8]
    53bc:	eb00007f 	cmp	x3, x0
    53c0:	54ffff41 	b.ne	53a8 <fwp_apply+0x188>  // b.any
    53c4:	aa1303e6 	mov	x6, x19
    53c8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53cc:	f947f400 	ldr	x0, [x0, #4072]
    53d0:	f85f83a2 	ldur	x2, [x29, #-8]
    53d4:	f9400001 	ldr	x1, [x0]
    53d8:	eb010042 	subs	x2, x2, x1
    53dc:	d2800001 	mov	x1, #0x0                   	// #0
    53e0:	540002c1 	b.ne	5438 <fwp_apply+0x218>  // b.any
    53e4:	910003bf 	mov	sp, x29
    53e8:	aa0603e0 	mov	x0, x6
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	d10043a0 	sub	x0, x29, #0x10
    5408:	5280001a 	mov	w26, #0x0                   	// #0
    540c:	d63f0060 	blr	x3
    5410:	aa0003e6 	mov	x6, x0
    5414:	6b1a02bf 	cmp	w21, w26
    5418:	54fffd80 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    541c:	0b1602b6 	add	w22, w21, w22
    5420:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    5424:	4b1902d5 	sub	w21, w22, w25
    5428:	9100031f 	mov	sp, x24
    542c:	17ffff8f 	b	5268 <fwp_apply+0x48>
    5430:	f90203ff 	str	xzr, [sp, #1024]
    5434:	17ffffb6 	b	530c <fwp_apply+0xec>
    5438:	97fff4f6 	bl	2810 <__stack_chk_fail@plt>
    543c:	d503201f 	nop

0000000000005440 <fwp_tape_grow.constprop.0>:
    5440:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5444:	d2800803 	mov	x3, #0x40                  	// #64
    5448:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    544c:	910003fd 	mov	x29, sp
    5450:	a90153f3 	stp	x19, x20, [sp, #16]
    5454:	f9400c13 	ldr	x19, [x0, #24]
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0003f7 	mov	x23, x0
    5460:	f100027f 	cmp	x19, #0x0
    5464:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    5468:	eb13003f 	cmp	x1, x19
    546c:	540000ed 	b.le	5488 <fwp_tape_grow.constprop.0+0x48>
    5470:	eb02027f 	cmp	x19, x2
    5474:	5400078d 	b.le	5564 <fwp_tape_grow.constprop.0+0x124>
    5478:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    547c:	eb13003f 	cmp	x1, x19
    5480:	5400004d 	b.le	5488 <fwp_tape_grow.constprop.0+0x48>
    5484:	14000000 	b	5484 <fwp_tape_grow.constprop.0+0x44>
    5488:	a940d2e3 	ldp	x3, x20, [x23, #8]
    548c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5490:	d37df276 	lsl	x22, x19, #3
    5494:	f94012e0 	ldr	x0, [x23, #32]
    5498:	aa1603e1 	mov	x1, x22
    549c:	f94032f5 	ldr	x21, [x23, #96]
    54a0:	cb030294 	sub	x20, x20, x3
    54a4:	52800022 	mov	w2, #0x1                   	// #1
    54a8:	97fffae7 	bl	4044 <ad_raw_realloc>
    54ac:	b4000bc0 	cbz	x0, 5624 <fwp_tape_grow.constprop.0+0x1e4>
    54b0:	f9400ee1 	ldr	x1, [x23, #24]
    54b4:	8b010801 	add	x1, x0, x1, lsl #2
    54b8:	a90206e0 	stp	x0, x1, [x23, #32]
    54bc:	b4000835 	cbz	x21, 55c0 <fwp_tape_grow.constprop.0+0x180>
    54c0:	f94032b6 	ldr	x22, [x21, #96]
    54c4:	eb1302df 	cmp	x22, x19
    54c8:	540003aa 	b.ge	553c <fwp_tape_grow.constprop.0+0xfc>  // b.tcont
    54cc:	a9046bf9 	stp	x25, x26, [sp, #64]
    54d0:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    54d4:	eb00027f 	cmp	x19, x0
    54d8:	54000a08 	b.hi	5618 <fwp_tape_grow.constprop.0+0x1d8>  // b.pmore
    54dc:	f94022b9 	ldr	x25, [x21, #64]
    54e0:	d37cee7a 	lsl	x26, x19, #4
    54e4:	aa1a03e0 	mov	x0, x26
    54e8:	52800041 	mov	w1, #0x2                   	// #2
    54ec:	97fffee9 	bl	5090 <fwp_heap_alloc>
    54f0:	aa0003f8 	mov	x24, x0
    54f4:	b4000119 	cbz	x25, 5514 <fwp_tape_grow.constprop.0+0xd4>
    54f8:	d37ceed6 	lsl	x22, x22, #4
    54fc:	aa1903e1 	mov	x1, x25
    5500:	eb1a02df 	cmp	x22, x26
    5504:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    5508:	97fff456 	bl	2660 <memcpy@plt>
    550c:	aa1903e0 	mov	x0, x25
    5510:	97fffc24 	bl	45a0 <fwp_mem_free>
    5514:	f94032a0 	ldr	x0, [x21, #96]
    5518:	52800001 	mov	w1, #0x0                   	// #0
    551c:	cb000262 	sub	x2, x19, x0
    5520:	8b001300 	add	x0, x24, x0, lsl #4
    5524:	d37cec42 	lsl	x2, x2, #4
    5528:	97fff4ae 	bl	27e0 <memset@plt>
    552c:	f94012e0 	ldr	x0, [x23, #32]
    5530:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5534:	f90022b8 	str	x24, [x21, #64]
    5538:	f90032b3 	str	x19, [x21, #96]
    553c:	d37ef675 	lsl	x21, x19, #2
    5540:	b5000254 	cbnz	x20, 5588 <fwp_tape_grow.constprop.0+0x148>
    5544:	8b150001 	add	x1, x0, x21
    5548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    554c:	f9000ef3 	str	x19, [x23, #24]
    5550:	f90016e1 	str	x1, [x23, #40]
    5554:	a94153f3 	ldp	x19, x20, [sp, #16]
    5558:	a94363f7 	ldp	x23, x24, [sp, #48]
    555c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5560:	d65f03c0 	ret
    5564:	d37ffa73 	lsl	x19, x19, #1
    5568:	17ffffc0 	b	5468 <fwp_tape_grow.constprop.0+0x28>
    556c:	aa0303e0 	mov	x0, x3
    5570:	d37df282 	lsl	x2, x20, #3
    5574:	97fff443 	bl	2680 <memmove@plt>
    5578:	f9401ae1 	ldr	x1, [x23, #48]
    557c:	f94012e0 	ldr	x0, [x23, #32]
    5580:	8b160021 	add	x1, x1, x22
    5584:	f9001ee1 	str	x1, [x23, #56]
    5588:	f94016e1 	ldr	x1, [x23, #40]
    558c:	d37ef675 	lsl	x21, x19, #2
    5590:	d37ef682 	lsl	x2, x20, #2
    5594:	8b150000 	add	x0, x0, x21
    5598:	97fff43a 	bl	2680 <memmove@plt>
    559c:	f94012e0 	ldr	x0, [x23, #32]
    55a0:	8b150001 	add	x1, x0, x21
    55a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55a8:	f9000ef3 	str	x19, [x23, #24]
    55ac:	f90016e1 	str	x1, [x23, #40]
    55b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    55b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    55b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55bc:	d65f03c0 	ret
    55c0:	f9401ae0 	ldr	x0, [x23, #48]
    55c4:	d37cee61 	lsl	x1, x19, #4
    55c8:	52800042 	mov	w2, #0x2                   	// #2
    55cc:	97fffa9e 	bl	4044 <ad_raw_realloc>
    55d0:	b40002a0 	cbz	x0, 5624 <fwp_tape_grow.constprop.0+0x1e4>
    55d4:	f9400ee2 	ldr	x2, [x23, #24]
    55d8:	f9001ae0 	str	x0, [x23, #48]
    55dc:	8b160003 	add	x3, x0, x22
    55e0:	8b020c01 	add	x1, x0, x2, lsl #3
    55e4:	f9001ee1 	str	x1, [x23, #56]
    55e8:	b5fffc34 	cbnz	x20, 556c <fwp_tape_grow.constprop.0+0x12c>
    55ec:	f94012e0 	ldr	x0, [x23, #32]
    55f0:	d37ef675 	lsl	x21, x19, #2
    55f4:	f9001ee3 	str	x3, [x23, #56]
    55f8:	8b150001 	add	x1, x0, x21
    55fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5600:	f9000ef3 	str	x19, [x23, #24]
    5604:	f90016e1 	str	x1, [x23, #40]
    5608:	a94153f3 	ldp	x19, x20, [sp, #16]
    560c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5614:	d65f03c0 	ret
    5618:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    561c:	9102a000 	add	x0, x0, #0xa8
    5620:	97fffb25 	bl	42b4 <fwp_trap>
    5624:	aa1703e0 	mov	x0, x23
    5628:	a9046bf9 	stp	x25, x26, [sp, #64]
    562c:	97fff65a 	bl	2f94 <fwp_tape_unlink_scope>
    5630:	f94012e0 	ldr	x0, [x23, #32]
    5634:	b4000040 	cbz	x0, 563c <fwp_tape_grow.constprop.0+0x1fc>
    5638:	97fffa4e 	bl	3f70 <ad_raw_free.part.0>
    563c:	f9401ae0 	ldr	x0, [x23, #48]
    5640:	b4000040 	cbz	x0, 5648 <fwp_tape_grow.constprop.0+0x208>
    5644:	97fffa4b 	bl	3f70 <ad_raw_free.part.0>
    5648:	f94022e0 	ldr	x0, [x23, #64]
    564c:	b4000040 	cbz	x0, 5654 <fwp_tape_grow.constprop.0+0x214>
    5650:	97fffa48 	bl	3f70 <ad_raw_free.part.0>
    5654:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    5658:	f947e821 	ldr	x1, [x1, #4048]
    565c:	f9000eff 	str	xzr, [x23, #24]
    5660:	4f000400 	movi	v0.4s, #0x0
    5664:	a9047eff 	stp	xzr, xzr, [x23, #64]
    5668:	d2800262 	mov	x2, #0x13                  	// #19
    566c:	f9400023 	ldr	x3, [x1]
    5670:	b90006ff 	str	wzr, [x23, #4]
    5674:	d2800021 	mov	x1, #0x1                   	// #1
    5678:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    567c:	912ea000 	add	x0, x0, #0xba8
    5680:	3c8082e0 	stur	q0, [x23, #8]
    5684:	ad0102e0 	stp	q0, q0, [x23, #32]
    5688:	97fff4a2 	bl	2910 <fwrite@plt>
    568c:	d2800000 	mov	x0, #0x0                   	// #0
    5690:	97fff4ac 	bl	2940 <fflush@plt>
    5694:	52800cc0 	mov	w0, #0x66                  	// #102
    5698:	97fff4ba 	bl	2980 <_Exit@plt>
    569c:	d503201f 	nop

00000000000056a0 <f128.constprop.0>:
    56a0:	f100001f 	cmp	x0, #0x0
    56a4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    56a8:	54000a2b 	b.lt	57ec <f128.constprop.0+0x14c>  // b.tstop
    56ac:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56b0:	aa0003e2 	mov	x2, x0
    56b4:	910003fd 	mov	x29, sp
    56b8:	a90153f3 	stp	x19, x20, [sp, #16]
    56bc:	aa0003f4 	mov	x20, x0
    56c0:	aa010000 	orr	x0, x0, x1
    56c4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56c8:	aa0103f6 	mov	x22, x1
    56cc:	f9001bf7 	str	x23, [sp, #48]
    56d0:	fd001fe8 	str	d8, [sp, #56]
    56d4:	b7f80180 	tbnz	x0, #63, 5704 <f128.constprop.0+0x64>
    56d8:	9360fc20 	asr	x0, x1, #32
    56dc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56e0:	eb82801f 	cmp	x0, x2, asr #32
    56e4:	54000881 	b.ne	57f4 <f128.constprop.0+0x154>  // b.any
    56e8:	97fffcf6 	bl	4ac0 <fwp_tape_of>
    56ec:	aa0003f3 	mov	x19, x0
    56f0:	f9403000 	ldr	x0, [x0, #96]
    56f4:	b40001e0 	cbz	x0, 5730 <f128.constprop.0+0x90>
    56f8:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    56fc:	91044000 	add	x0, x0, #0x110
    5700:	97fffaed 	bl	42b4 <fwp_trap>
    5704:	9360fc40 	asr	x0, x2, #32
    5708:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    570c:	b6fffee2 	tbz	x2, #63, 56e8 <f128.constprop.0+0x48>
    5710:	2f00e408 	movi	d8, #0x0
    5714:	9360fc20 	asr	x0, x1, #32
    5718:	aa0103f4 	mov	x20, x1
    571c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5720:	97fffce8 	bl	4ac0 <fwp_tape_of>
    5724:	aa0003f3 	mov	x19, x0
    5728:	f9403000 	ldr	x0, [x0, #96]
    572c:	b5fffe60 	cbnz	x0, 56f8 <f128.constprop.0+0x58>
    5730:	f9400a77 	ldr	x23, [x19, #16]
    5734:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5738:	eb0002ff 	cmp	x23, x0
    573c:	5400046c 	b.gt	57c8 <f128.constprop.0+0x128>
    5740:	eb3442ff 	cmp	x23, w20, uxtw
    5744:	540004ed 	b.le	57e0 <f128.constprop.0+0x140>
    5748:	b7f80076 	tbnz	x22, #63, 5754 <f128.constprop.0+0xb4>
    574c:	eb3642ff 	cmp	x23, w22, uxtw
    5750:	5400048d 	b.le	57e0 <f128.constprop.0+0x140>
    5754:	f9400675 	ldr	x21, [x19, #8]
    5758:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    575c:	cb1502f5 	sub	x21, x23, x21
    5760:	910006a1 	add	x1, x21, #0x1
    5764:	eb00003f 	cmp	x1, x0
    5768:	54000308 	b.hi	57c8 <f128.constprop.0+0x128>  // b.pmore
    576c:	f9400e60 	ldr	x0, [x19, #24]
    5770:	eb00003f 	cmp	x1, x0
    5774:	5400030c 	b.gt	57d4 <f128.constprop.0+0x134>
    5778:	a9420262 	ldp	x2, x0, [x19, #32]
    577c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5780:	f9401a61 	ldr	x1, [x19, #48]
    5784:	b8357854 	str	w20, [x2, x21, lsl #2]
    5788:	f9401e62 	ldr	x2, [x19, #56]
    578c:	f10002df 	cmp	x22, #0x0
    5790:	fc357820 	str	d0, [x1, x21, lsl #3]
    5794:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5798:	b8357816 	str	w22, [x0, x21, lsl #2]
    579c:	92607e80 	and	x0, x20, #0xffffffff00000000
    57a0:	910006e1 	add	x1, x23, #0x1
    57a4:	aa170000 	orr	x0, x0, x23
    57a8:	fc357848 	str	d8, [x2, x21, lsl #3]
    57ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57b0:	f9401bf7 	ldr	x23, [sp, #48]
    57b4:	fd401fe8 	ldr	d8, [sp, #56]
    57b8:	f9000a61 	str	x1, [x19, #16]
    57bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57c4:	d65f03c0 	ret
    57c8:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    57cc:	9102a000 	add	x0, x0, #0xa8
    57d0:	97fffab9 	bl	42b4 <fwp_trap>
    57d4:	aa1303e0 	mov	x0, x19
    57d8:	97ffff1a 	bl	5440 <fwp_tape_grow.constprop.0>
    57dc:	17ffffe7 	b	5778 <f128.constprop.0+0xd8>
    57e0:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    57e4:	91050000 	add	x0, x0, #0x140
    57e8:	97fffab3 	bl	42b4 <fwp_trap>
    57ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57f0:	d65f03c0 	ret
    57f4:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    57f8:	91032000 	add	x0, x0, #0xc8
    57fc:	97fffaae 	bl	42b4 <fwp_trap>

0000000000005800 <w107>:
    5800:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5804:	910003fd 	mov	x29, sp
    5808:	a90153f3 	stp	x19, x20, [sp, #16]
    580c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5810:	a90363f7 	stp	x23, x24, [sp, #48]
    5814:	aa0003f8 	mov	x24, x0
    5818:	a9046bf9 	stp	x25, x26, [sp, #64]
    581c:	aa0103f9 	mov	x25, x1
    5820:	6d0527e8 	stp	d8, d9, [sp, #80]
    5824:	1e604008 	fmov	d8, d0
    5828:	1e604029 	fmov	d9, d1
    582c:	6d062fea 	stp	d10, d11, [sp, #96]
    5830:	1e60080a 	fmul	d10, d0, d0
    5834:	b7f821a0 	tbnz	x0, #63, 5c68 <w107+0x468>
    5838:	9360fc17 	asr	x23, x0, #32
    583c:	aa1703e0 	mov	x0, x23
    5840:	97fffca0 	bl	4ac0 <fwp_tape_of>
    5844:	f9403001 	ldr	x1, [x0, #96]
    5848:	aa0003f3 	mov	x19, x0
    584c:	b4000081 	cbz	x1, 585c <w107+0x5c>
    5850:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    5854:	91044000 	add	x0, x0, #0x110
    5858:	97fffa97 	bl	42b4 <fwp_trap>
    585c:	f9400815 	ldr	x21, [x0, #16]
    5860:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    5864:	eb0102bf 	cmp	x21, x1
    5868:	54001d8c 	b.gt	5c18 <w107+0x418>
    586c:	eb3842bf 	cmp	x21, w24, uxtw
    5870:	54001ced 	b.le	5c0c <w107+0x40c>
    5874:	f9400416 	ldr	x22, [x0, #8]
    5878:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    587c:	cb1602b6 	sub	x22, x21, x22
    5880:	910006c1 	add	x1, x22, #0x1
    5884:	eb02003f 	cmp	x1, x2
    5888:	54001c88 	b.hi	5c18 <w107+0x418>  // b.pmore
    588c:	f9400c02 	ldr	x2, [x0, #24]
    5890:	eb02003f 	cmp	x1, x2
    5894:	54001c8c 	b.gt	5c24 <w107+0x424>
    5898:	a9420660 	ldp	x0, x1, [x19, #32]
    589c:	92607f14 	and	x20, x24, #0xffffffff00000000
    58a0:	f9401a62 	ldr	x2, [x19, #48]
    58a4:	b8367818 	str	w24, [x0, x22, lsl #2]
    58a8:	f9401e60 	ldr	x0, [x19, #56]
    58ac:	aa150294 	orr	x20, x20, x21
    58b0:	fc367848 	str	d8, [x2, x22, lsl #3]
    58b4:	910006b5 	add	x21, x21, #0x1
    58b8:	b8367838 	str	w24, [x1, x22, lsl #2]
    58bc:	1e6a392a 	fsub	d10, d9, d10
    58c0:	9360fe9a 	asr	x26, x20, #32
    58c4:	fc367808 	str	d8, [x0, x22, lsl #3]
    58c8:	f9000a75 	str	x21, [x19, #16]
    58cc:	b7f80079 	tbnz	x25, #63, 58d8 <w107+0xd8>
    58d0:	eb99835f 	cmp	x26, x25, asr #32
    58d4:	54001e21 	b.ne	5c98 <w107+0x498>  // b.any
    58d8:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58dc:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    58e0:	eb1a02ff 	cmp	x23, x26
    58e4:	540000c0 	b.eq	58fc <w107+0xfc>  // b.none
    58e8:	aa1a03e0 	mov	x0, x26
    58ec:	97fffc75 	bl	4ac0 <fwp_tape_of>
    58f0:	aa0003f3 	mov	x19, x0
    58f4:	f9403000 	ldr	x0, [x0, #96]
    58f8:	b5fffac0 	cbnz	x0, 5850 <w107+0x50>
    58fc:	f9400a77 	ldr	x23, [x19, #16]
    5900:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5904:	eb0002ff 	cmp	x23, x0
    5908:	5400188c 	b.gt	5c18 <w107+0x418>
    590c:	eb3442ff 	cmp	x23, w20, uxtw
    5910:	540017ed 	b.le	5c0c <w107+0x40c>
    5914:	b7f80079 	tbnz	x25, #63, 5920 <w107+0x120>
    5918:	eb3942ff 	cmp	x23, w25, uxtw
    591c:	5400178d 	b.le	5c0c <w107+0x40c>
    5920:	f9400675 	ldr	x21, [x19, #8]
    5924:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5928:	cb1502f5 	sub	x21, x23, x21
    592c:	910006a1 	add	x1, x21, #0x1
    5930:	eb00003f 	cmp	x1, x0
    5934:	54001728 	b.hi	5c18 <w107+0x418>  // b.pmore
    5938:	f9400e60 	ldr	x0, [x19, #24]
    593c:	eb00003f 	cmp	x1, x0
    5940:	540018ec 	b.gt	5c5c <w107+0x45c>
    5944:	a9420e62 	ldp	x2, x3, [x19, #32]
    5948:	f100033f 	cmp	x25, #0x0
    594c:	f9401a61 	ldr	x1, [x19, #48]
    5950:	b8357854 	str	w20, [x2, x21, lsl #2]
    5954:	f9401e62 	ldr	x2, [x19, #56]
    5958:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    595c:	fc35782b 	str	d11, [x1, x21, lsl #3]
    5960:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    5964:	b8357861 	str	w1, [x3, x21, lsl #2]
    5968:	910006f6 	add	x22, x23, #0x1
    596c:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5970:	92607e94 	and	x20, x20, #0xffffffff00000000
    5974:	fc357849 	str	d9, [x2, x21, lsl #3]
    5978:	aa170294 	orr	x20, x20, x23
    597c:	f9000a76 	str	x22, [x19, #16]
    5980:	1e68396b 	fsub	d11, d11, d8
    5984:	b7f81a78 	tbnz	x24, #63, 5cd0 <w107+0x4d0>
    5988:	9360ff17 	asr	x23, x24, #32
    598c:	eb1a02ff 	cmp	x23, x26
    5990:	540000e0 	b.eq	59ac <w107+0x1ac>  // b.none
    5994:	aa1703e0 	mov	x0, x23
    5998:	97fffc4a 	bl	4ac0 <fwp_tape_of>
    599c:	aa0003f3 	mov	x19, x0
    59a0:	f9403000 	ldr	x0, [x0, #96]
    59a4:	b5fff560 	cbnz	x0, 5850 <w107+0x50>
    59a8:	f9400a76 	ldr	x22, [x19, #16]
    59ac:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59b0:	eb0002df 	cmp	x22, x0
    59b4:	5400132c 	b.gt	5c18 <w107+0x418>
    59b8:	eb3842df 	cmp	x22, w24, uxtw
    59bc:	5400128d 	b.le	5c0c <w107+0x40c>
    59c0:	f9400675 	ldr	x21, [x19, #8]
    59c4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59c8:	cb1502d5 	sub	x21, x22, x21
    59cc:	910006a1 	add	x1, x21, #0x1
    59d0:	eb00003f 	cmp	x1, x0
    59d4:	54001228 	b.hi	5c18 <w107+0x418>  // b.pmore
    59d8:	f9400e60 	ldr	x0, [x19, #24]
    59dc:	eb00003f 	cmp	x1, x0
    59e0:	5400138c 	b.gt	5c50 <w107+0x450>
    59e4:	a9420262 	ldp	x2, x0, [x19, #32]
    59e8:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    59ec:	f9401a63 	ldr	x3, [x19, #48]
    59f0:	b8357858 	str	w24, [x2, x21, lsl #2]
    59f4:	f9401e62 	ldr	x2, [x19, #56]
    59f8:	12800001 	mov	w1, #0xffffffff            	// #-1
    59fc:	fc357860 	str	d0, [x3, x21, lsl #3]
    5a00:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5a04:	b8357801 	str	w1, [x0, x21, lsl #2]
    5a08:	92607f00 	and	x0, x24, #0xffffffff00000000
    5a0c:	aa160018 	orr	x24, x0, x22
    5a10:	910006c1 	add	x1, x22, #0x1
    5a14:	fc357840 	str	d0, [x2, x21, lsl #3]
    5a18:	f9000a61 	str	x1, [x19, #16]
    5a1c:	9360fe99 	asr	x25, x20, #32
    5a20:	1e6a0949 	fmul	d9, d10, d10
    5a24:	eb17033f 	cmp	x25, x23
    5a28:	540000c0 	b.eq	5a40 <w107+0x240>  // b.none
    5a2c:	aa1903e0 	mov	x0, x25
    5a30:	97fffc24 	bl	4ac0 <fwp_tape_of>
    5a34:	aa0003f3 	mov	x19, x0
    5a38:	f9403000 	ldr	x0, [x0, #96]
    5a3c:	b5fff0a0 	cbnz	x0, 5850 <w107+0x50>
    5a40:	f9400a75 	ldr	x21, [x19, #16]
    5a44:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a48:	eb0002bf 	cmp	x21, x0
    5a4c:	54000e6c 	b.gt	5c18 <w107+0x418>
    5a50:	eb3442bf 	cmp	x21, w20, uxtw
    5a54:	54000dcd 	b.le	5c0c <w107+0x40c>
    5a58:	f9400676 	ldr	x22, [x19, #8]
    5a5c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a60:	cb1602b6 	sub	x22, x21, x22
    5a64:	910006c1 	add	x1, x22, #0x1
    5a68:	eb00003f 	cmp	x1, x0
    5a6c:	54000d68 	b.hi	5c18 <w107+0x418>  // b.pmore
    5a70:	f9400e60 	ldr	x0, [x19, #24]
    5a74:	eb00003f 	cmp	x1, x0
    5a78:	54000e6c 	b.gt	5c44 <w107+0x444>
    5a7c:	92607e80 	and	x0, x20, #0xffffffff00000000
    5a80:	aa150017 	orr	x23, x0, x21
    5a84:	a9420261 	ldp	x1, x0, [x19, #32]
    5a88:	f9401a62 	ldr	x2, [x19, #48]
    5a8c:	b8367834 	str	w20, [x1, x22, lsl #2]
    5a90:	f9401e61 	ldr	x1, [x19, #56]
    5a94:	fc36784a 	str	d10, [x2, x22, lsl #3]
    5a98:	b8367814 	str	w20, [x0, x22, lsl #2]
    5a9c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5aa0:	9e670000 	fmov	d0, x0
    5aa4:	910006b4 	add	x20, x21, #0x1
    5aa8:	fc36782a 	str	d10, [x1, x22, lsl #3]
    5aac:	9360fef6 	asr	x22, x23, #32
    5ab0:	f9000a74 	str	x20, [x19, #16]
    5ab4:	1e600929 	fmul	d9, d9, d0
    5ab8:	eb1902df 	cmp	x22, x25
    5abc:	540000e0 	b.eq	5ad8 <w107+0x2d8>  // b.none
    5ac0:	aa1603e0 	mov	x0, x22
    5ac4:	97fffbff 	bl	4ac0 <fwp_tape_of>
    5ac8:	aa0003f3 	mov	x19, x0
    5acc:	f9403000 	ldr	x0, [x0, #96]
    5ad0:	b5ffec00 	cbnz	x0, 5850 <w107+0x50>
    5ad4:	f9400a74 	ldr	x20, [x19, #16]
    5ad8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5adc:	eb00029f 	cmp	x20, x0
    5ae0:	540009cc 	b.gt	5c18 <w107+0x418>
    5ae4:	eb37429f 	cmp	x20, w23, uxtw
    5ae8:	5400092d 	b.le	5c0c <w107+0x40c>
    5aec:	f9400675 	ldr	x21, [x19, #8]
    5af0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5af4:	cb150295 	sub	x21, x20, x21
    5af8:	910006a1 	add	x1, x21, #0x1
    5afc:	eb00003f 	cmp	x1, x0
    5b00:	540008c8 	b.hi	5c18 <w107+0x418>  // b.pmore
    5b04:	f9400e60 	ldr	x0, [x19, #24]
    5b08:	eb00003f 	cmp	x1, x0
    5b0c:	5400096c 	b.gt	5c38 <w107+0x438>
    5b10:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5b14:	9e670000 	fmov	d0, x0
    5b18:	a9420262 	ldp	x2, x0, [x19, #32]
    5b1c:	1e6b0968 	fmul	d8, d11, d11
    5b20:	f9401a61 	ldr	x1, [x19, #48]
    5b24:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b28:	f9401e62 	ldr	x2, [x19, #56]
    5b2c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5b30:	12800001 	mov	w1, #0xffffffff            	// #-1
    5b34:	b8357801 	str	w1, [x0, x21, lsl #2]
    5b38:	91000681 	add	x1, x20, #0x1
    5b3c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    5b40:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b44:	f9000a61 	str	x1, [x19, #16]
    5b48:	aa140014 	orr	x20, x0, x20
    5b4c:	b100071f 	cmn	x24, #0x1
    5b50:	54000c60 	b.eq	5cdc <w107+0x4dc>  // b.none
    5b54:	9360ff00 	asr	x0, x24, #32
    5b58:	eb16001f 	cmp	x0, x22
    5b5c:	540000a0 	b.eq	5b70 <w107+0x370>  // b.none
    5b60:	97fffbd8 	bl	4ac0 <fwp_tape_of>
    5b64:	aa0003f3 	mov	x19, x0
    5b68:	f9403000 	ldr	x0, [x0, #96]
    5b6c:	b5ffe720 	cbnz	x0, 5850 <w107+0x50>
    5b70:	f9400a75 	ldr	x21, [x19, #16]
    5b74:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b78:	eb0002bf 	cmp	x21, x0
    5b7c:	540004ec 	b.gt	5c18 <w107+0x418>
    5b80:	eb3842bf 	cmp	x21, w24, uxtw
    5b84:	5400044d 	b.le	5c0c <w107+0x40c>
    5b88:	f9400676 	ldr	x22, [x19, #8]
    5b8c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b90:	cb1602b6 	sub	x22, x21, x22
    5b94:	910006c1 	add	x1, x22, #0x1
    5b98:	eb00003f 	cmp	x1, x0
    5b9c:	540003e8 	b.hi	5c18 <w107+0x418>  // b.pmore
    5ba0:	f9400e60 	ldr	x0, [x19, #24]
    5ba4:	eb00003f 	cmp	x1, x0
    5ba8:	5400042c 	b.gt	5c2c <w107+0x42c>
    5bac:	a9420a61 	ldp	x1, x2, [x19, #32]
    5bb0:	92607f00 	and	x0, x24, #0xffffffff00000000
    5bb4:	f9401a63 	ldr	x3, [x19, #48]
    5bb8:	b8367838 	str	w24, [x1, x22, lsl #2]
    5bbc:	f9401e61 	ldr	x1, [x19, #56]
    5bc0:	aa150000 	orr	x0, x0, x21
    5bc4:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5bc8:	910006b5 	add	x21, x21, #0x1
    5bcc:	b8367858 	str	w24, [x2, x22, lsl #2]
    5bd0:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5bd4:	f9000a75 	str	x21, [x19, #16]
    5bd8:	1e692908 	fadd	d8, d8, d9
    5bdc:	aa1403e1 	mov	x1, x20
    5be0:	97fffeb0 	bl	56a0 <f128.constprop.0>
    5be4:	aa0003e1 	mov	x1, x0
    5be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bec:	9e660100 	fmov	x0, d8
    5bf0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5bf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bf8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5bfc:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5c00:	6d462fea 	ldp	d10, d11, [sp, #96]
    5c04:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5c08:	d65f03c0 	ret
    5c0c:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    5c10:	91050000 	add	x0, x0, #0x140
    5c14:	97fff9a8 	bl	42b4 <fwp_trap>
    5c18:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    5c1c:	9102a000 	add	x0, x0, #0xa8
    5c20:	97fff9a5 	bl	42b4 <fwp_trap>
    5c24:	97fffe07 	bl	5440 <fwp_tape_grow.constprop.0>
    5c28:	17ffff1c 	b	5898 <w107+0x98>
    5c2c:	aa1303e0 	mov	x0, x19
    5c30:	97fffe04 	bl	5440 <fwp_tape_grow.constprop.0>
    5c34:	17ffffde 	b	5bac <w107+0x3ac>
    5c38:	aa1303e0 	mov	x0, x19
    5c3c:	97fffe01 	bl	5440 <fwp_tape_grow.constprop.0>
    5c40:	17ffffb4 	b	5b10 <w107+0x310>
    5c44:	aa1303e0 	mov	x0, x19
    5c48:	97fffdfe 	bl	5440 <fwp_tape_grow.constprop.0>
    5c4c:	17ffff8c 	b	5a7c <w107+0x27c>
    5c50:	aa1303e0 	mov	x0, x19
    5c54:	97fffdfb 	bl	5440 <fwp_tape_grow.constprop.0>
    5c58:	17ffff63 	b	59e4 <w107+0x1e4>
    5c5c:	aa1303e0 	mov	x0, x19
    5c60:	97fffdf8 	bl	5440 <fwp_tape_grow.constprop.0>
    5c64:	17ffff38 	b	5944 <w107+0x144>
    5c68:	1e6a382a 	fsub	d10, d1, d10
    5c6c:	b6f801c1 	tbz	x1, #63, 5ca4 <w107+0x4a4>
    5c70:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c74:	1e6a0949 	fmul	d9, d10, d10
    5c78:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c7c:	9e670001 	fmov	d1, x0
    5c80:	1e683808 	fsub	d8, d0, d8
    5c84:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    5c88:	aa1403e0 	mov	x0, x20
    5c8c:	1e610929 	fmul	d9, d9, d1
    5c90:	1e680908 	fmul	d8, d8, d8
    5c94:	17ffffd1 	b	5bd8 <w107+0x3d8>
    5c98:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    5c9c:	91032000 	add	x0, x0, #0xc8
    5ca0:	97fff985 	bl	42b4 <fwp_trap>
    5ca4:	2f00e409 	movi	d9, #0x0
    5ca8:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    5cac:	9360fc3a 	asr	x26, x1, #32
    5cb0:	aa0103f4 	mov	x20, x1
    5cb4:	aa1a03e0 	mov	x0, x26
    5cb8:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    5cbc:	97fffb81 	bl	4ac0 <fwp_tape_of>
    5cc0:	aa0003f3 	mov	x19, x0
    5cc4:	f9403000 	ldr	x0, [x0, #96]
    5cc8:	b5ffdc40 	cbnz	x0, 5850 <w107+0x50>
    5ccc:	17ffff0c 	b	58fc <w107+0xfc>
    5cd0:	aa1a03f7 	mov	x23, x26
    5cd4:	aa0003f8 	mov	x24, x0
    5cd8:	17ffff51 	b	5a1c <w107+0x21c>
    5cdc:	aa1803e0 	mov	x0, x24
    5ce0:	17ffffbe 	b	5bd8 <w107+0x3d8>

0000000000005ce4 <fwp_data.part.0.constprop.0>:
    5ce4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5ce8:	910003fd 	mov	x29, sp
    5cec:	a9025bf5 	stp	x21, x22, [sp, #32]
    5cf0:	f00000d6 	adrp	x22, 20000 <__data_start>
    5cf4:	910182c2 	add	x2, x22, #0x60
    5cf8:	a9046bf9 	stp	x25, x26, [sp, #64]
    5cfc:	b9413059 	ldr	w25, [x2, #304]
    5d00:	a90153f3 	stp	x19, x20, [sp, #16]
    5d04:	aa0103f4 	mov	x20, x1
    5d08:	a90363f7 	stp	x23, x24, [sp, #48]
    5d0c:	2a0003f7 	mov	w23, w0
    5d10:	340000b9 	cbz	w25, 5d24 <fwp_data.part.0.constprop.0+0x40>
    5d14:	a9538041 	ldp	x1, x0, [x2, #312]
    5d18:	91000421 	add	x1, x1, #0x1
    5d1c:	91006000 	add	x0, x0, #0x18
    5d20:	a9138041 	stp	x1, x0, [x2, #312]
    5d24:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5d28:	911902a3 	add	x3, x21, #0x640
    5d2c:	b953a460 	ldr	w0, [x3, #5028]
    5d30:	34000840 	cbz	w0, 5e38 <fwp_data.part.0.constprop.0+0x154>
    5d34:	397e8862 	ldrb	w2, [x3, #4002]
    5d38:	910f0040 	add	x0, x2, #0x3c0
    5d3c:	8b020442 	add	x2, x2, x2, lsl #1
    5d40:	d37df042 	lsl	x2, x2, #3
    5d44:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5d48:	2a1a03f8 	mov	w24, w26
    5d4c:	f8626873 	ldr	x19, [x3, x2]
    5d50:	b4000613 	cbz	x19, 5e10 <fwp_data.part.0.constprop.0+0x12c>
    5d54:	f9400260 	ldr	x0, [x19]
    5d58:	aa2003e0 	mvn	x0, x0
    5d5c:	f8226860 	str	x0, [x3, x2]
    5d60:	f100631f 	cmp	x24, #0x18
    5d64:	540000e9 	b.ls	5d80 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5d68:	d1006702 	sub	x2, x24, #0x19
    5d6c:	91006260 	add	x0, x19, #0x18
    5d70:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5d74:	52800001 	mov	w1, #0x0                   	// #0
    5d78:	91002042 	add	x2, x2, #0x8
    5d7c:	97fff299 	bl	27e0 <memset@plt>
    5d80:	911902a0 	add	x0, x21, #0x640
    5d84:	f94a1001 	ldr	x1, [x0, #5152]
    5d88:	ab180021 	adds	x1, x1, x24
    5d8c:	54000682 	b.cs	5e5c <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    5d90:	f94a1402 	ldr	x2, [x0, #5160]
    5d94:	f90a1001 	str	x1, [x0, #5152]
    5d98:	eb02003f 	cmp	x1, x2
    5d9c:	54000049 	b.ls	5da4 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5da0:	f90a1401 	str	x1, [x0, #5160]
    5da4:	911902a0 	add	x0, x21, #0x640
    5da8:	1e630341 	ucvtf	d1, w26
    5dac:	fd4a1c00 	ldr	d0, [x0, #5176]
    5db0:	1e612800 	fadd	d0, d0, d1
    5db4:	fd0a1c00 	str	d0, [x0, #5176]
    5db8:	34000139 	cbz	w25, 5ddc <fwp_data.part.0.constprop.0+0xf8>
    5dbc:	911902b5 	add	x21, x21, #0x640
    5dc0:	910182d6 	add	x22, x22, #0x60
    5dc4:	fd4a12a0 	ldr	d0, [x21, #5152]
    5dc8:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5dcc:	7e61d800 	ucvtf	d0, d0
    5dd0:	1e623800 	fsub	d0, d0, d2
    5dd4:	1e612010 	fcmpe	d0, d1
    5dd8:	540003ec 	b.gt	5e54 <fwp_data.part.0.constprop.0+0x170>
    5ddc:	52800040 	mov	w0, #0x2                   	// #2
    5de0:	29000277 	stp	w23, w0, [x19]
    5de4:	aa1303e0 	mov	x0, x19
    5de8:	f9400281 	ldr	x1, [x20]
    5dec:	f9000661 	str	x1, [x19, #8]
    5df0:	f9400681 	ldr	x1, [x20, #8]
    5df4:	f9000a61 	str	x1, [x19, #16]
    5df8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5e00:	a94363f7 	ldp	x23, x24, [sp, #48]
    5e04:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5e08:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5e0c:	d65f03c0 	ret
    5e10:	8b020063 	add	x3, x3, x2
    5e14:	f9400473 	ldr	x19, [x3, #8]
    5e18:	b4000113 	cbz	x19, 5e38 <fwp_data.part.0.constprop.0+0x154>
    5e1c:	f9400860 	ldr	x0, [x3, #16]
    5e20:	cb130000 	sub	x0, x0, x19
    5e24:	eb00031f 	cmp	x24, x0
    5e28:	54000088 	b.hi	5e38 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5e2c:	8b180260 	add	x0, x19, x24
    5e30:	f9000460 	str	x0, [x3, #8]
    5e34:	17ffffcb 	b	5d60 <fwp_data.part.0.constprop.0+0x7c>
    5e38:	52800001 	mov	w1, #0x0                   	// #0
    5e3c:	d2800300 	mov	x0, #0x18                  	// #24
    5e40:	97fffc94 	bl	5090 <fwp_heap_alloc>
    5e44:	aa0003f3 	mov	x19, x0
    5e48:	910182c1 	add	x1, x22, #0x60
    5e4c:	b9413039 	ldr	w25, [x1, #304]
    5e50:	17ffffda 	b	5db8 <fwp_data.part.0.constprop.0+0xd4>
    5e54:	fd00aac0 	str	d0, [x22, #336]
    5e58:	17ffffe1 	b	5ddc <fwp_data.part.0.constprop.0+0xf8>
    5e5c:	97fff4a5 	bl	30f0 <fwp_heap_oom>

0000000000005e60 <fwp_rc_share>:
    5e60:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5e64:	91190042 	add	x2, x2, #0x640
    5e68:	f949d843 	ldr	x3, [x2, #5040]
    5e6c:	f949ec41 	ldr	x1, [x2, #5080]
    5e70:	cb030000 	sub	x0, x0, x3
    5e74:	eb01401f 	cmp	x0, x1, lsl #16
    5e78:	540003a2 	b.cs	5eec <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5e7c:	d350fc01 	lsr	x1, x0, #16
    5e80:	f949fc44 	ldr	x4, [x2, #5112]
    5e84:	8b010821 	add	x1, x1, x1, lsl #2
    5e88:	d37df021 	lsl	x1, x1, #3
    5e8c:	8b010083 	add	x3, x4, x1
    5e90:	f9401062 	ldr	x2, [x3, #32]
    5e94:	b40002c2 	cbz	x2, 5eec <fwp_rc_share+0x8c>
    5e98:	38616881 	ldrb	w1, [x4, x1]
    5e9c:	7100083f 	cmp	w1, #0x2
    5ea0:	54000220 	b.eq	5ee4 <fwp_rc_share+0x84>  // b.none
    5ea4:	7100043f 	cmp	w1, #0x1
    5ea8:	54000221 	b.ne	5eec <fwp_rc_share+0x8c>  // b.any
    5eac:	29430464 	ldp	w4, w1, [x3, #24]
    5eb0:	92403c00 	and	x0, x0, #0xffff
    5eb4:	9b047c00 	mul	x0, x0, x4
    5eb8:	d360fc00 	lsr	x0, x0, #32
    5ebc:	eb01001f 	cmp	x0, x1
    5ec0:	54000162 	b.cs	5eec <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ec4:	8b000042 	add	x2, x2, x0
    5ec8:	39400040 	ldrb	w0, [x2]
    5ecc:	34000100 	cbz	w0, 5eec <fwp_rc_share+0x8c>
    5ed0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ed4:	f0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    5ed8:	91058000 	add	x0, x0, #0x160
    5edc:	910003fd 	mov	x29, sp
    5ee0:	97fff8f5 	bl	42b4 <fwp_trap>
    5ee4:	72003c1f 	tst	w0, #0xffff
    5ee8:	54ffff00 	b.eq	5ec8 <fwp_rc_share+0x68>  // b.none
    5eec:	d65f03c0 	ret

0000000000005ef0 <fwp_rc_free_arr>:
    5ef0:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ef4:	91190063 	add	x3, x3, #0x640
    5ef8:	f949d861 	ldr	x1, [x3, #5040]
    5efc:	f949ec62 	ldr	x2, [x3, #5080]
    5f00:	cb010001 	sub	x1, x0, x1
    5f04:	eb02403f 	cmp	x1, x2, lsl #16
    5f08:	54000342 	b.cs	5f70 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5f0c:	d350fc22 	lsr	x2, x1, #16
    5f10:	f949fc65 	ldr	x5, [x3, #5112]
    5f14:	8b020842 	add	x2, x2, x2, lsl #2
    5f18:	d37df042 	lsl	x2, x2, #3
    5f1c:	8b0200a4 	add	x4, x5, x2
    5f20:	f9401083 	ldr	x3, [x4, #32]
    5f24:	b4000263 	cbz	x3, 5f70 <fwp_rc_free_arr+0x80>
    5f28:	386268a2 	ldrb	w2, [x5, x2]
    5f2c:	7100085f 	cmp	w2, #0x2
    5f30:	540001c0 	b.eq	5f68 <fwp_rc_free_arr+0x78>  // b.none
    5f34:	7100045f 	cmp	w2, #0x1
    5f38:	540001c1 	b.ne	5f70 <fwp_rc_free_arr+0x80>  // b.any
    5f3c:	29430885 	ldp	w5, w2, [x4, #24]
    5f40:	92403c21 	and	x1, x1, #0xffff
    5f44:	9b057c21 	mul	x1, x1, x5
    5f48:	d360fc21 	lsr	x1, x1, #32
    5f4c:	eb02003f 	cmp	x1, x2
    5f50:	54000102 	b.cs	5f70 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5f54:	8b010063 	add	x3, x3, x1
    5f58:	39400061 	ldrb	w1, [x3]
    5f5c:	7100043f 	cmp	w1, #0x1
    5f60:	54000081 	b.ne	5f70 <fwp_rc_free_arr+0x80>  // b.any
    5f64:	17fff98f 	b	45a0 <fwp_mem_free>
    5f68:	72003c3f 	tst	w1, #0xffff
    5f6c:	54ffff60 	b.eq	5f58 <fwp_rc_free_arr+0x68>  // b.none
    5f70:	d65f03c0 	ret

0000000000005f74 <fwp_rc_dup>:
    5f74:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5f78:	91190042 	add	x2, x2, #0x640
    5f7c:	f949d841 	ldr	x1, [x2, #5040]
    5f80:	f949ec43 	ldr	x3, [x2, #5080]
    5f84:	cb010001 	sub	x1, x0, x1
    5f88:	eb03403f 	cmp	x1, x3, lsl #16
    5f8c:	540003c2 	b.cs	6004 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f90:	d350fc20 	lsr	x0, x1, #16
    5f94:	f949fc44 	ldr	x4, [x2, #5112]
    5f98:	8b000800 	add	x0, x0, x0, lsl #2
    5f9c:	d37df002 	lsl	x2, x0, #3
    5fa0:	8b020083 	add	x3, x4, x2
    5fa4:	f9401060 	ldr	x0, [x3, #32]
    5fa8:	b40002e0 	cbz	x0, 6004 <fwp_rc_dup+0x90>
    5fac:	38626882 	ldrb	w2, [x4, x2]
    5fb0:	7100085f 	cmp	w2, #0x2
    5fb4:	540002a0 	b.eq	6008 <fwp_rc_dup+0x94>  // b.none
    5fb8:	7100045f 	cmp	w2, #0x1
    5fbc:	54000241 	b.ne	6004 <fwp_rc_dup+0x90>  // b.any
    5fc0:	29430864 	ldp	w4, w2, [x3, #24]
    5fc4:	92403c21 	and	x1, x1, #0xffff
    5fc8:	9b047c21 	mul	x1, x1, x4
    5fcc:	d360fc21 	lsr	x1, x1, #32
    5fd0:	eb02003f 	cmp	x1, x2
    5fd4:	54000182 	b.cs	6004 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5fd8:	8b010000 	add	x0, x0, x1
    5fdc:	39400001 	ldrb	w1, [x0]
    5fe0:	34000121 	cbz	w1, 6004 <fwp_rc_dup+0x90>
    5fe4:	f00000c2 	adrp	x2, 20000 <__data_start>
    5fe8:	91018042 	add	x2, x2, #0x60
    5fec:	b9413043 	ldr	w3, [x2, #304]
    5ff0:	35000123 	cbnz	w3, 6014 <fwp_rc_dup+0xa0>
    5ff4:	7103f43f 	cmp	w1, #0xfd
    5ff8:	54000168 	b.hi	6024 <fwp_rc_dup+0xb0>  // b.pmore
    5ffc:	11000421 	add	w1, w1, #0x1
    6000:	39000001 	strb	w1, [x0]
    6004:	d65f03c0 	ret
    6008:	72003c3f 	tst	w1, #0xffff
    600c:	54fffe80 	b.eq	5fdc <fwp_rc_dup+0x68>  // b.none
    6010:	d65f03c0 	ret
    6014:	f940ac43 	ldr	x3, [x2, #344]
    6018:	91000463 	add	x3, x3, #0x1
    601c:	f900ac43 	str	x3, [x2, #344]
    6020:	17fffff5 	b	5ff4 <fwp_rc_dup+0x80>
    6024:	17fff9d8 	b	4784 <fwp_rc_wide_dup>
    6028:	d503201f 	nop
    602c:	d503201f 	nop

0000000000006030 <fwp_owned_entry161>:
    6030:	d10103ff 	sub	sp, sp, #0x40
    6034:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    6038:	f947f442 	ldr	x2, [x2, #4072]
    603c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6040:	910083fd 	add	x29, sp, #0x20
    6044:	a90353f3 	stp	x19, x20, [sp, #48]
    6048:	f9400043 	ldr	x3, [x2]
    604c:	f9000fe3 	str	x3, [sp, #24]
    6050:	d2800003 	mov	x3, #0x0                   	// #0
    6054:	a9400c01 	ldp	x1, x3, [x0]
    6058:	f9400802 	ldr	x2, [x0, #16]
    605c:	ab020022 	adds	x2, x1, x2
    6060:	540006e6 	b.vs	613c <fwp_owned_entry161+0x10c>
    6064:	910023e1 	add	x1, sp, #0x8
    6068:	52800000 	mov	w0, #0x0                   	// #0
    606c:	a9008be3 	stp	x3, x2, [sp, #8]
    6070:	97ffff1d 	bl	5ce4 <fwp_data.part.0.constprop.0>
    6074:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6078:	91190063 	add	x3, x3, #0x640
    607c:	aa0003f3 	mov	x19, x0
    6080:	f949d861 	ldr	x1, [x3, #5040]
    6084:	f949ec60 	ldr	x0, [x3, #5080]
    6088:	cb010261 	sub	x1, x19, x1
    608c:	eb00403f 	cmp	x1, x0, lsl #16
    6090:	54000322 	b.cs	60f4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    6094:	d350fc22 	lsr	x2, x1, #16
    6098:	f949fc63 	ldr	x3, [x3, #5112]
    609c:	8b020842 	add	x2, x2, x2, lsl #2
    60a0:	d37df042 	lsl	x2, x2, #3
    60a4:	8b020060 	add	x0, x3, x2
    60a8:	f9401014 	ldr	x20, [x0, #32]
    60ac:	b4000254 	cbz	x20, 60f4 <fwp_owned_entry161+0xc4>
    60b0:	38626862 	ldrb	w2, [x3, x2]
    60b4:	7100085f 	cmp	w2, #0x2
    60b8:	54000360 	b.eq	6124 <fwp_owned_entry161+0xf4>  // b.none
    60bc:	7100045f 	cmp	w2, #0x1
    60c0:	540001a1 	b.ne	60f4 <fwp_owned_entry161+0xc4>  // b.any
    60c4:	29430002 	ldp	w2, w0, [x0, #24]
    60c8:	92403c21 	and	x1, x1, #0xffff
    60cc:	9b027c21 	mul	x1, x1, x2
    60d0:	d360fc21 	lsr	x1, x1, #32
    60d4:	eb00003f 	cmp	x1, x0
    60d8:	540000e2 	b.cs	60f4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    60dc:	8b010294 	add	x20, x20, x1
    60e0:	39400280 	ldrb	w0, [x20]
    60e4:	7103fc1f 	cmp	w0, #0xff
    60e8:	54000240 	b.eq	6130 <fwp_owned_entry161+0x100>  // b.none
    60ec:	52800020 	mov	w0, #0x1                   	// #1
    60f0:	39000280 	strb	w0, [x20]
    60f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    60f8:	f947f400 	ldr	x0, [x0, #4072]
    60fc:	f9400fe2 	ldr	x2, [sp, #24]
    6100:	f9400001 	ldr	x1, [x0]
    6104:	eb010042 	subs	x2, x2, x1
    6108:	d2800001 	mov	x1, #0x0                   	// #0
    610c:	540001a1 	b.ne	6140 <fwp_owned_entry161+0x110>  // b.any
    6110:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6114:	aa1303e0 	mov	x0, x19
    6118:	a94353f3 	ldp	x19, x20, [sp, #48]
    611c:	910103ff 	add	sp, sp, #0x40
    6120:	d65f03c0 	ret
    6124:	72003c3f 	tst	w1, #0xffff
    6128:	54fffe61 	b.ne	60f4 <fwp_owned_entry161+0xc4>  // b.any
    612c:	17ffffed 	b	60e0 <fwp_owned_entry161+0xb0>
    6130:	aa1403e0 	mov	x0, x20
    6134:	97fff880 	bl	4334 <fwp_rc_forget_slot.part.0>
    6138:	17ffffed 	b	60ec <fwp_owned_entry161+0xbc>
    613c:	97fff231 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6140:	97fff1b4 	bl	2810 <__stack_chk_fail@plt>

0000000000006144 <e161>:
    6144:	d10103ff 	sub	sp, sp, #0x40
    6148:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    614c:	f947f442 	ldr	x2, [x2, #4072]
    6150:	a9027bfd 	stp	x29, x30, [sp, #32]
    6154:	910083fd 	add	x29, sp, #0x20
    6158:	a90353f3 	stp	x19, x20, [sp, #48]
    615c:	f9400043 	ldr	x3, [x2]
    6160:	f9000fe3 	str	x3, [sp, #24]
    6164:	d2800003 	mov	x3, #0x0                   	// #0
    6168:	a9400c01 	ldp	x1, x3, [x0]
    616c:	f9400802 	ldr	x2, [x0, #16]
    6170:	ab020022 	adds	x2, x1, x2
    6174:	54000726 	b.vs	6258 <e161+0x114>
    6178:	910023e1 	add	x1, sp, #0x8
    617c:	52800000 	mov	w0, #0x0                   	// #0
    6180:	a9008be3 	stp	x3, x2, [sp, #8]
    6184:	97fffed8 	bl	5ce4 <fwp_data.part.0.constprop.0>
    6188:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    618c:	91190063 	add	x3, x3, #0x640
    6190:	aa0003f3 	mov	x19, x0
    6194:	f949d861 	ldr	x1, [x3, #5040]
    6198:	f949ec60 	ldr	x0, [x3, #5080]
    619c:	cb010261 	sub	x1, x19, x1
    61a0:	eb00403f 	cmp	x1, x0, lsl #16
    61a4:	54000322 	b.cs	6208 <e161+0xc4>  // b.hs, b.nlast
    61a8:	d350fc22 	lsr	x2, x1, #16
    61ac:	f949fc63 	ldr	x3, [x3, #5112]
    61b0:	8b020842 	add	x2, x2, x2, lsl #2
    61b4:	d37df042 	lsl	x2, x2, #3
    61b8:	8b020060 	add	x0, x3, x2
    61bc:	f9401014 	ldr	x20, [x0, #32]
    61c0:	b4000254 	cbz	x20, 6208 <e161+0xc4>
    61c4:	38626862 	ldrb	w2, [x3, x2]
    61c8:	7100085f 	cmp	w2, #0x2
    61cc:	540003a0 	b.eq	6240 <e161+0xfc>  // b.none
    61d0:	7100045f 	cmp	w2, #0x1
    61d4:	540001a1 	b.ne	6208 <e161+0xc4>  // b.any
    61d8:	29430002 	ldp	w2, w0, [x0, #24]
    61dc:	92403c21 	and	x1, x1, #0xffff
    61e0:	9b027c21 	mul	x1, x1, x2
    61e4:	d360fc21 	lsr	x1, x1, #32
    61e8:	eb00003f 	cmp	x1, x0
    61ec:	540000e2 	b.cs	6208 <e161+0xc4>  // b.hs, b.nlast
    61f0:	8b010294 	add	x20, x20, x1
    61f4:	39400280 	ldrb	w0, [x20]
    61f8:	7103fc1f 	cmp	w0, #0xff
    61fc:	54000280 	b.eq	624c <e161+0x108>  // b.none
    6200:	52800020 	mov	w0, #0x1                   	// #1
    6204:	39000280 	strb	w0, [x20]
    6208:	aa1303e0 	mov	x0, x19
    620c:	97ffff15 	bl	5e60 <fwp_rc_share>
    6210:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6214:	f947f400 	ldr	x0, [x0, #4072]
    6218:	f9400fe2 	ldr	x2, [sp, #24]
    621c:	f9400001 	ldr	x1, [x0]
    6220:	eb010042 	subs	x2, x2, x1
    6224:	d2800001 	mov	x1, #0x0                   	// #0
    6228:	540001a1 	b.ne	625c <e161+0x118>  // b.any
    622c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6230:	aa1303e0 	mov	x0, x19
    6234:	a94353f3 	ldp	x19, x20, [sp, #48]
    6238:	910103ff 	add	sp, sp, #0x40
    623c:	d65f03c0 	ret
    6240:	72003c3f 	tst	w1, #0xffff
    6244:	54fffe21 	b.ne	6208 <e161+0xc4>  // b.any
    6248:	17ffffeb 	b	61f4 <e161+0xb0>
    624c:	aa1403e0 	mov	x0, x20
    6250:	97fff839 	bl	4334 <fwp_rc_forget_slot.part.0>
    6254:	17ffffeb 	b	6200 <e161+0xbc>
    6258:	97fff1ea 	bl	2a00 <fwp_trap_overflow.constprop.0>
    625c:	97fff16d 	bl	2810 <__stack_chk_fail@plt>

0000000000006260 <fwp_drop1>:
    6260:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6264:	910003fd 	mov	x29, sp
    6268:	a90153f3 	stp	x19, x20, [sp, #16]
    626c:	f90013f5 	str	x21, [sp, #32]
    6270:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    6274:	911902b4 	add	x20, x21, #0x640
    6278:	f949da81 	ldr	x1, [x20, #5040]
    627c:	f949ee82 	ldr	x2, [x20, #5080]
    6280:	cb010001 	sub	x1, x0, x1
    6284:	eb02403f 	cmp	x1, x2, lsl #16
    6288:	54000382 	b.cs	62f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    628c:	d350fc22 	lsr	x2, x1, #16
    6290:	f949fe84 	ldr	x4, [x20, #5112]
    6294:	8b020842 	add	x2, x2, x2, lsl #2
    6298:	d37df042 	lsl	x2, x2, #3
    629c:	8b020083 	add	x3, x4, x2
    62a0:	f9401073 	ldr	x19, [x3, #32]
    62a4:	b40002b3 	cbz	x19, 62f8 <fwp_drop1+0x98>
    62a8:	38626882 	ldrb	w2, [x4, x2]
    62ac:	7100085f 	cmp	w2, #0x2
    62b0:	540002c0 	b.eq	6308 <fwp_drop1+0xa8>  // b.none
    62b4:	7100045f 	cmp	w2, #0x1
    62b8:	54000201 	b.ne	62f8 <fwp_drop1+0x98>  // b.any
    62bc:	29430864 	ldp	w4, w2, [x3, #24]
    62c0:	92403c21 	and	x1, x1, #0xffff
    62c4:	9b047c21 	mul	x1, x1, x4
    62c8:	d360fc21 	lsr	x1, x1, #32
    62cc:	eb02003f 	cmp	x1, x2
    62d0:	54000142 	b.cs	62f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    62d4:	8b010273 	add	x19, x19, x1
    62d8:	39400261 	ldrb	w1, [x19]
    62dc:	340000e1 	cbz	w1, 62f8 <fwp_drop1+0x98>
    62e0:	7100043f 	cmp	w1, #0x1
    62e4:	540001e0 	b.eq	6320 <fwp_drop1+0xc0>  // b.none
    62e8:	7103fc3f 	cmp	w1, #0xff
    62ec:	540002e0 	b.eq	6348 <fwp_drop1+0xe8>  // b.none
    62f0:	51000421 	sub	w1, w1, #0x1
    62f4:	39000261 	strb	w1, [x19]
    62f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62fc:	f94013f5 	ldr	x21, [sp, #32]
    6300:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6304:	d65f03c0 	ret
    6308:	72003c3f 	tst	w1, #0xffff
    630c:	54fffe60 	b.eq	62d8 <fwp_drop1+0x78>  // b.none
    6310:	a94153f3 	ldp	x19, x20, [sp, #16]
    6314:	f94013f5 	ldr	x21, [sp, #32]
    6318:	a8c37bfd 	ldp	x29, x30, [sp], #48
    631c:	d65f03c0 	ret
    6320:	f9400813 	ldr	x19, [x0, #16]
    6324:	97fffef3 	bl	5ef0 <fwp_rc_free_arr>
    6328:	911902a0 	add	x0, x21, #0x640
    632c:	f949d801 	ldr	x1, [x0, #5040]
    6330:	f949ec00 	ldr	x0, [x0, #5080]
    6334:	cb010261 	sub	x1, x19, x1
    6338:	eb00403f 	cmp	x1, x0, lsl #16
    633c:	54fffde2 	b.cs	62f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6340:	aa1303e0 	mov	x0, x19
    6344:	17ffffd2 	b	628c <fwp_drop1+0x2c>
    6348:	ca534660 	eor	x0, x19, x19, lsr #17
    634c:	911902b5 	add	x21, x21, #0x640
    6350:	ca402400 	eor	x0, x0, x0, lsr #9
    6354:	92401c00 	and	x0, x0, #0xff
    6358:	910a2402 	add	x2, x0, #0x289
    635c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6360:	8b020ea2 	add	x2, x21, x2, lsl #3
    6364:	f94a2400 	ldr	x0, [x0, #5192]
    6368:	b50000a0 	cbnz	x0, 637c <fwp_drop1+0x11c>
    636c:	14000013 	b	63b8 <fwp_drop1+0x158>
    6370:	91004002 	add	x2, x0, #0x10
    6374:	f9400800 	ldr	x0, [x0, #16]
    6378:	b4000200 	cbz	x0, 63b8 <fwp_drop1+0x158>
    637c:	f9400001 	ldr	x1, [x0]
    6380:	eb13003f 	cmp	x1, x19
    6384:	54ffff61 	b.ne	6370 <fwp_drop1+0x110>  // b.any
    6388:	f9400041 	ldr	x1, [x2]
    638c:	f9400420 	ldr	x0, [x1, #8]
    6390:	d1000400 	sub	x0, x0, #0x1
    6394:	f9000420 	str	x0, [x1, #8]
    6398:	f103f81f 	cmp	x0, #0xfe
    639c:	54fffae1 	b.ne	62f8 <fwp_drop1+0x98>  // b.any
    63a0:	39400260 	ldrb	w0, [x19]
    63a4:	7103fc1f 	cmp	w0, #0xff
    63a8:	540000e0 	b.eq	63c4 <fwp_drop1+0x164>  // b.none
    63ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63b0:	39000260 	strb	w0, [x19]
    63b4:	17ffffd1 	b	62f8 <fwp_drop1+0x98>
    63b8:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    63bc:	913be000 	add	x0, x0, #0xef8
    63c0:	97fff7bd 	bl	42b4 <fwp_trap>
    63c4:	aa1303e0 	mov	x0, x19
    63c8:	97fff7db 	bl	4334 <fwp_rc_forget_slot.part.0>
    63cc:	17fffff8 	b	63ac <fwp_drop1+0x14c>

00000000000063d0 <fwp_drop0>:
    63d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    63d4:	910003fd 	mov	x29, sp
    63d8:	a90153f3 	stp	x19, x20, [sp, #16]
    63dc:	f90013f5 	str	x21, [sp, #32]
    63e0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    63e4:	911902b4 	add	x20, x21, #0x640
    63e8:	f949da81 	ldr	x1, [x20, #5040]
    63ec:	f949ee82 	ldr	x2, [x20, #5080]
    63f0:	cb010001 	sub	x1, x0, x1
    63f4:	eb02403f 	cmp	x1, x2, lsl #16
    63f8:	54000382 	b.cs	6468 <fwp_drop0+0x98>  // b.hs, b.nlast
    63fc:	d350fc22 	lsr	x2, x1, #16
    6400:	f949fe84 	ldr	x4, [x20, #5112]
    6404:	8b020842 	add	x2, x2, x2, lsl #2
    6408:	d37df042 	lsl	x2, x2, #3
    640c:	8b020083 	add	x3, x4, x2
    6410:	f9401073 	ldr	x19, [x3, #32]
    6414:	b40002b3 	cbz	x19, 6468 <fwp_drop0+0x98>
    6418:	38626882 	ldrb	w2, [x4, x2]
    641c:	7100085f 	cmp	w2, #0x2
    6420:	540002c0 	b.eq	6478 <fwp_drop0+0xa8>  // b.none
    6424:	7100045f 	cmp	w2, #0x1
    6428:	54000201 	b.ne	6468 <fwp_drop0+0x98>  // b.any
    642c:	29430864 	ldp	w4, w2, [x3, #24]
    6430:	92403c21 	and	x1, x1, #0xffff
    6434:	9b047c21 	mul	x1, x1, x4
    6438:	d360fc21 	lsr	x1, x1, #32
    643c:	eb02003f 	cmp	x1, x2
    6440:	54000142 	b.cs	6468 <fwp_drop0+0x98>  // b.hs, b.nlast
    6444:	8b010273 	add	x19, x19, x1
    6448:	39400261 	ldrb	w1, [x19]
    644c:	340000e1 	cbz	w1, 6468 <fwp_drop0+0x98>
    6450:	7100043f 	cmp	w1, #0x1
    6454:	540001e0 	b.eq	6490 <fwp_drop0+0xc0>  // b.none
    6458:	7103fc3f 	cmp	w1, #0xff
    645c:	540002e0 	b.eq	64b8 <fwp_drop0+0xe8>  // b.none
    6460:	51000421 	sub	w1, w1, #0x1
    6464:	39000261 	strb	w1, [x19]
    6468:	a94153f3 	ldp	x19, x20, [sp, #16]
    646c:	f94013f5 	ldr	x21, [sp, #32]
    6470:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6474:	d65f03c0 	ret
    6478:	72003c3f 	tst	w1, #0xffff
    647c:	54fffe60 	b.eq	6448 <fwp_drop0+0x78>  // b.none
    6480:	a94153f3 	ldp	x19, x20, [sp, #16]
    6484:	f94013f5 	ldr	x21, [sp, #32]
    6488:	a8c37bfd 	ldp	x29, x30, [sp], #48
    648c:	d65f03c0 	ret
    6490:	f9400813 	ldr	x19, [x0, #16]
    6494:	97fffe97 	bl	5ef0 <fwp_rc_free_arr>
    6498:	911902a0 	add	x0, x21, #0x640
    649c:	f949d801 	ldr	x1, [x0, #5040]
    64a0:	f949ec00 	ldr	x0, [x0, #5080]
    64a4:	cb010261 	sub	x1, x19, x1
    64a8:	eb00403f 	cmp	x1, x0, lsl #16
    64ac:	54fffde2 	b.cs	6468 <fwp_drop0+0x98>  // b.hs, b.nlast
    64b0:	aa1303e0 	mov	x0, x19
    64b4:	17ffffd2 	b	63fc <fwp_drop0+0x2c>
    64b8:	ca534660 	eor	x0, x19, x19, lsr #17
    64bc:	911902b5 	add	x21, x21, #0x640
    64c0:	ca402400 	eor	x0, x0, x0, lsr #9
    64c4:	92401c00 	and	x0, x0, #0xff
    64c8:	910a2402 	add	x2, x0, #0x289
    64cc:	8b000ea0 	add	x0, x21, x0, lsl #3
    64d0:	8b020ea2 	add	x2, x21, x2, lsl #3
    64d4:	f94a2400 	ldr	x0, [x0, #5192]
    64d8:	b50000a0 	cbnz	x0, 64ec <fwp_drop0+0x11c>
    64dc:	14000013 	b	6528 <fwp_drop0+0x158>
    64e0:	91004002 	add	x2, x0, #0x10
    64e4:	f9400800 	ldr	x0, [x0, #16]
    64e8:	b4000200 	cbz	x0, 6528 <fwp_drop0+0x158>
    64ec:	f9400001 	ldr	x1, [x0]
    64f0:	eb13003f 	cmp	x1, x19
    64f4:	54ffff61 	b.ne	64e0 <fwp_drop0+0x110>  // b.any
    64f8:	f9400041 	ldr	x1, [x2]
    64fc:	f9400420 	ldr	x0, [x1, #8]
    6500:	d1000400 	sub	x0, x0, #0x1
    6504:	f9000420 	str	x0, [x1, #8]
    6508:	f103f81f 	cmp	x0, #0xfe
    650c:	54fffae1 	b.ne	6468 <fwp_drop0+0x98>  // b.any
    6510:	39400260 	ldrb	w0, [x19]
    6514:	7103fc1f 	cmp	w0, #0xff
    6518:	540000e0 	b.eq	6534 <fwp_drop0+0x164>  // b.none
    651c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6520:	39000260 	strb	w0, [x19]
    6524:	17ffffd1 	b	6468 <fwp_drop0+0x98>
    6528:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    652c:	913be000 	add	x0, x0, #0xef8
    6530:	97fff761 	bl	42b4 <fwp_trap>
    6534:	aa1303e0 	mov	x0, x19
    6538:	97fff77f 	bl	4334 <fwp_rc_forget_slot.part.0>
    653c:	17fffff8 	b	651c <fwp_drop0+0x14c>

0000000000006540 <fwp_arg_drop12>:
    6540:	7100003f 	cmp	w1, #0x0
    6544:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6548:	54000041 	b.ne	6550 <fwp_arg_drop12+0x10>  // b.any
    654c:	d65f03c0 	ret
    6550:	f9400000 	ldr	x0, [x0]
    6554:	17ffff9f 	b	63d0 <fwp_drop0>
    6558:	d503201f 	nop
    655c:	d503201f 	nop

0000000000006560 <fwp_closure_drop>:
    6560:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    6564:	911900a4 	add	x4, x5, #0x640
    6568:	aa0003e1 	mov	x1, x0
    656c:	f949d882 	ldr	x2, [x4, #5040]
    6570:	f949ec80 	ldr	x0, [x4, #5080]
    6574:	cb020022 	sub	x2, x1, x2
    6578:	eb00405f 	cmp	x2, x0, lsl #16
    657c:	54000662 	b.cs	6648 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6584:	d350fc43 	lsr	x3, x2, #16
    6588:	910003fd 	mov	x29, sp
    658c:	8b030863 	add	x3, x3, x3, lsl #2
    6590:	f949fc84 	ldr	x4, [x4, #5112]
    6594:	d37df063 	lsl	x3, x3, #3
    6598:	f9000bf3 	str	x19, [sp, #16]
    659c:	8b030080 	add	x0, x4, x3
    65a0:	f9401013 	ldr	x19, [x0, #32]
    65a4:	b40002b3 	cbz	x19, 65f8 <fwp_closure_drop+0x98>
    65a8:	38636883 	ldrb	w3, [x4, x3]
    65ac:	7100087f 	cmp	w3, #0x2
    65b0:	54000420 	b.eq	6634 <fwp_closure_drop+0xd4>  // b.none
    65b4:	7100047f 	cmp	w3, #0x1
    65b8:	54000201 	b.ne	65f8 <fwp_closure_drop+0x98>  // b.any
    65bc:	29430003 	ldp	w3, w0, [x0, #24]
    65c0:	92403c42 	and	x2, x2, #0xffff
    65c4:	9b037c42 	mul	x2, x2, x3
    65c8:	d360fc42 	lsr	x2, x2, #32
    65cc:	eb00005f 	cmp	x2, x0
    65d0:	54000142 	b.cs	65f8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    65d4:	8b020273 	add	x19, x19, x2
    65d8:	39400260 	ldrb	w0, [x19]
    65dc:	340000e0 	cbz	w0, 65f8 <fwp_closure_drop+0x98>
    65e0:	7100041f 	cmp	w0, #0x1
    65e4:	54000100 	b.eq	6604 <fwp_closure_drop+0xa4>  // b.none
    65e8:	7103fc1f 	cmp	w0, #0xff
    65ec:	54000300 	b.eq	664c <fwp_closure_drop+0xec>  // b.none
    65f0:	51000400 	sub	w0, w0, #0x1
    65f4:	39000260 	strb	w0, [x19]
    65f8:	f9400bf3 	ldr	x19, [sp, #16]
    65fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6600:	d65f03c0 	ret
    6604:	d53bd040 	mrs	x0, tpidr_el0
    6608:	91400000 	add	x0, x0, #0x0, lsl #12
    660c:	91004000 	add	x0, x0, #0x10
    6610:	f9400000 	ldr	x0, [x0]
    6614:	b4000080 	cbz	x0, 6624 <fwp_closure_drop+0xc4>
    6618:	f9400bf3 	ldr	x19, [sp, #16]
    661c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6620:	17fff8a0 	b	48a0 <fwp_closure_drop_push>
    6624:	f9400bf3 	ldr	x19, [sp, #16]
    6628:	aa0103e0 	mov	x0, x1
    662c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6630:	17fff8e1 	b	49b4 <fwp_closure_drop.part.0>
    6634:	72003c5f 	tst	w2, #0xffff
    6638:	54fffd00 	b.eq	65d8 <fwp_closure_drop+0x78>  // b.none
    663c:	f9400bf3 	ldr	x19, [sp, #16]
    6640:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6644:	d65f03c0 	ret
    6648:	d65f03c0 	ret
    664c:	ca534660 	eor	x0, x19, x19, lsr #17
    6650:	911900a5 	add	x5, x5, #0x640
    6654:	ca402400 	eor	x0, x0, x0, lsr #9
    6658:	92401c00 	and	x0, x0, #0xff
    665c:	910a2402 	add	x2, x0, #0x289
    6660:	8b000ca0 	add	x0, x5, x0, lsl #3
    6664:	8b020ca2 	add	x2, x5, x2, lsl #3
    6668:	f94a2400 	ldr	x0, [x0, #5192]
    666c:	b50000a0 	cbnz	x0, 6680 <fwp_closure_drop+0x120>
    6670:	14000013 	b	66bc <fwp_closure_drop+0x15c>
    6674:	91004002 	add	x2, x0, #0x10
    6678:	f9400800 	ldr	x0, [x0, #16]
    667c:	b4000200 	cbz	x0, 66bc <fwp_closure_drop+0x15c>
    6680:	f9400001 	ldr	x1, [x0]
    6684:	eb13003f 	cmp	x1, x19
    6688:	54ffff61 	b.ne	6674 <fwp_closure_drop+0x114>  // b.any
    668c:	f9400041 	ldr	x1, [x2]
    6690:	f9400420 	ldr	x0, [x1, #8]
    6694:	d1000400 	sub	x0, x0, #0x1
    6698:	f9000420 	str	x0, [x1, #8]
    669c:	f103f81f 	cmp	x0, #0xfe
    66a0:	54fffac1 	b.ne	65f8 <fwp_closure_drop+0x98>  // b.any
    66a4:	39400260 	ldrb	w0, [x19]
    66a8:	7103fc1f 	cmp	w0, #0xff
    66ac:	540000e0 	b.eq	66c8 <fwp_closure_drop+0x168>  // b.none
    66b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66b4:	39000260 	strb	w0, [x19]
    66b8:	17ffffd0 	b	65f8 <fwp_closure_drop+0x98>
    66bc:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    66c0:	913be000 	add	x0, x0, #0xef8
    66c4:	97fff6fc 	bl	42b4 <fwp_trap>
    66c8:	aa1303e0 	mov	x0, x19
    66cc:	97fff71a 	bl	4334 <fwp_rc_forget_slot.part.0>
    66d0:	17fffff8 	b	66b0 <fwp_closure_drop+0x150>

00000000000066d4 <fwp_owned_tape_release>:
    66d4:	b4000920 	cbz	x0, 67f8 <fwp_owned_tape_release+0x124>
    66d8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66dc:	910003fd 	mov	x29, sp
    66e0:	a90153f3 	stp	x19, x20, [sp, #16]
    66e4:	aa0003f3 	mov	x19, x0
    66e8:	f9400000 	ldr	x0, [x0]
    66ec:	b4000060 	cbz	x0, 66f8 <fwp_owned_tape_release+0x24>
    66f0:	f9400661 	ldr	x1, [x19, #8]
    66f4:	f9000401 	str	x1, [x0, #8]
    66f8:	f9400661 	ldr	x1, [x19, #8]
    66fc:	b4000041 	cbz	x1, 6704 <fwp_owned_tape_release+0x30>
    6700:	f9000020 	str	x0, [x1]
    6704:	f9400a60 	ldr	x0, [x19, #16]
    6708:	f9403401 	ldr	x1, [x0, #104]
    670c:	b40005a1 	cbz	x1, 67c0 <fwp_owned_tape_release+0xec>
    6710:	a9450a60 	ldp	x0, x2, [x19, #80]
    6714:	eb00005f 	cmp	x2, x0
    6718:	540002cd 	b.le	6770 <fwp_owned_tape_release+0x9c>
    671c:	d2800014 	mov	x20, #0x0                   	// #0
    6720:	f90013f5 	str	x21, [sp, #32]
    6724:	d2800015 	mov	x21, #0x0                   	// #0
    6728:	f9402260 	ldr	x0, [x19, #64]
    672c:	910006b5 	add	x21, x21, #0x1
    6730:	f8746800 	ldr	x0, [x0, x20]
    6734:	d63f0020 	blr	x1
    6738:	f9402260 	ldr	x0, [x19, #64]
    673c:	f9400a61 	ldr	x1, [x19, #16]
    6740:	8b140000 	add	x0, x0, x20
    6744:	91004294 	add	x20, x20, #0x10
    6748:	f9400400 	ldr	x0, [x0, #8]
    674c:	f9403421 	ldr	x1, [x1, #104]
    6750:	d63f0020 	blr	x1
    6754:	a9450261 	ldp	x1, x0, [x19, #80]
    6758:	cb010000 	sub	x0, x0, x1
    675c:	eb15001f 	cmp	x0, x21
    6760:	f9400a60 	ldr	x0, [x19, #16]
    6764:	f9403401 	ldr	x1, [x0, #104]
    6768:	54fffe0c 	b.gt	6728 <fwp_owned_tape_release+0x54>
    676c:	f94013f5 	ldr	x21, [sp, #32]
    6770:	f9403663 	ldr	x3, [x19, #104]
    6774:	f9401262 	ldr	x2, [x19, #32]
    6778:	f100007f 	cmp	x3, #0x0
    677c:	540001ed 	b.le	67b8 <fwp_owned_tape_release+0xe4>
    6780:	d2800014 	mov	x20, #0x0                   	// #0
    6784:	d503201f 	nop
    6788:	f9402660 	ldr	x0, [x19, #72]
    678c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6790:	eb02001f 	cmp	x0, x2
    6794:	540000c0 	b.eq	67ac <fwp_owned_tape_release+0xd8>  // b.none
    6798:	d63f0020 	blr	x1
    679c:	f9400a60 	ldr	x0, [x19, #16]
    67a0:	f9401262 	ldr	x2, [x19, #32]
    67a4:	f9403663 	ldr	x3, [x19, #104]
    67a8:	f9403401 	ldr	x1, [x0, #104]
    67ac:	91000694 	add	x20, x20, #0x1
    67b0:	eb14007f 	cmp	x3, x20
    67b4:	54fffeac 	b.gt	6788 <fwp_owned_tape_release+0xb4>
    67b8:	aa0203e0 	mov	x0, x2
    67bc:	d63f0020 	blr	x1
    67c0:	f9401660 	ldr	x0, [x19, #40]
    67c4:	97ffff67 	bl	6560 <fwp_closure_drop>
    67c8:	f9401a60 	ldr	x0, [x19, #48]
    67cc:	97ffff65 	bl	6560 <fwp_closure_drop>
    67d0:	f9401e60 	ldr	x0, [x19, #56]
    67d4:	97ffff63 	bl	6560 <fwp_closure_drop>
    67d8:	f9402260 	ldr	x0, [x19, #64]
    67dc:	97fff771 	bl	45a0 <fwp_mem_free>
    67e0:	f9402660 	ldr	x0, [x19, #72]
    67e4:	97fff76f 	bl	45a0 <fwp_mem_free>
    67e8:	aa1303e0 	mov	x0, x19
    67ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67f4:	17fff76b 	b	45a0 <fwp_mem_free>
    67f8:	d65f03c0 	ret
    67fc:	d503201f 	nop

0000000000006800 <fwp_tape_finish>:
    6800:	d10203ff 	sub	sp, sp, #0x80
    6804:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6808:	f947f421 	ldr	x1, [x1, #4072]
    680c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6810:	910103fd 	add	x29, sp, #0x40
    6814:	a9065bf5 	stp	x21, x22, [sp, #96]
    6818:	a90763f7 	stp	x23, x24, [sp, #112]
    681c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6820:	910182f6 	add	x22, x23, #0x60
    6824:	f9400022 	ldr	x2, [x1]
    6828:	f9001fe2 	str	x2, [sp, #56]
    682c:	d2800002 	mov	x2, #0x0                   	// #0
    6830:	910342c0 	add	x0, x22, #0xd0
    6834:	97fff5f0 	bl	3ff4 <fwp_tape_buffers_dispose>
    6838:	f90086df 	str	xzr, [x22, #264]
    683c:	f94092c0 	ldr	x0, [x22, #288]
    6840:	f100001f 	cmp	x0, #0x0
    6844:	5400034d 	b.le	68ac <fwp_tape_finish+0xac>
    6848:	910003f8 	mov	x24, sp
    684c:	d2800015 	mov	x21, #0x0                   	// #0
    6850:	a90553f3 	stp	x19, x20, [sp, #80]
    6854:	d2800014 	mov	x20, #0x0                   	// #0
    6858:	91000694 	add	x20, x20, #0x1
    685c:	f94046d3 	ldr	x19, [x22, #136]
    6860:	8b150273 	add	x19, x19, x21
    6864:	9101a2b5 	add	x21, x21, #0x68
    6868:	aa1303e0 	mov	x0, x19
    686c:	97fff1ca 	bl	2f94 <fwp_tape_unlink_scope>
    6870:	aa1803e0 	mov	x0, x24
    6874:	a9440663 	ldp	x3, x1, [x19, #64]
    6878:	f9001be1 	str	x1, [sp, #48]
    687c:	f9400e62 	ldr	x2, [x19, #24]
    6880:	a9020be3 	stp	x3, x2, [sp, #32]
    6884:	ad410261 	ldp	q1, q0, [x19, #32]
    6888:	ad0003e1 	stp	q1, q0, [sp]
    688c:	97fff5da 	bl	3ff4 <fwp_tape_buffers_dispose>
    6890:	f9403260 	ldr	x0, [x19, #96]
    6894:	97ffff90 	bl	66d4 <fwp_owned_tape_release>
    6898:	f900327f 	str	xzr, [x19, #96]
    689c:	f94092c0 	ldr	x0, [x22, #288]
    68a0:	eb14001f 	cmp	x0, x20
    68a4:	54fffdac 	b.gt	6858 <fwp_tape_finish+0x58>
    68a8:	a94553f3 	ldp	x19, x20, [sp, #80]
    68ac:	910182e0 	add	x0, x23, #0x60
    68b0:	f9404400 	ldr	x0, [x0, #136]
    68b4:	b4000040 	cbz	x0, 68bc <fwp_tape_finish+0xbc>
    68b8:	97fff5ae 	bl	3f70 <ad_raw_free.part.0>
    68bc:	910182f7 	add	x23, x23, #0x60
    68c0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    68c4:	f947f400 	ldr	x0, [x0, #4072]
    68c8:	f90046ff 	str	xzr, [x23, #136]
    68cc:	f9008aff 	str	xzr, [x23, #272]
    68d0:	f90092ff 	str	xzr, [x23, #288]
    68d4:	f900b2ff 	str	xzr, [x23, #352]
    68d8:	f9401fe2 	ldr	x2, [sp, #56]
    68dc:	f9400001 	ldr	x1, [x0]
    68e0:	eb010042 	subs	x2, x2, x1
    68e4:	d2800001 	mov	x1, #0x0                   	// #0
    68e8:	540000c1 	b.ne	6900 <fwp_tape_finish+0x100>  // b.any
    68ec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    68f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    68f4:	a94763f7 	ldp	x23, x24, [sp, #112]
    68f8:	910203ff 	add	sp, sp, #0x80
    68fc:	d65f03c0 	ret
    6900:	a90553f3 	stp	x19, x20, [sp, #80]
    6904:	97ffefc3 	bl	2810 <__stack_chk_fail@plt>
    6908:	d503201f 	nop
    690c:	d503201f 	nop

0000000000006910 <fwp_tape_scope_release>:
    6910:	d10243ff 	sub	sp, sp, #0x90
    6914:	a9047bfd 	stp	x29, x30, [sp, #64]
    6918:	910103fd 	add	x29, sp, #0x40
    691c:	a90553f3 	stp	x19, x20, [sp, #80]
    6920:	aa0003f4 	mov	x20, x0
    6924:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6928:	f947f400 	ldr	x0, [x0, #4072]
    692c:	b9400285 	ldr	w5, [x20]
    6930:	f9400001 	ldr	x1, [x0]
    6934:	f9001fe1 	str	x1, [sp, #56]
    6938:	d2800001 	mov	x1, #0x0                   	// #0
    693c:	37f806c5 	tbnz	w5, #31, 6a14 <fwp_tape_scope_release+0x104>
    6940:	a90763f7 	stp	x23, x24, [sp, #112]
    6944:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6948:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    694c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6950:	d00000d3 	adrp	x19, 20000 <__data_start>
    6954:	910003f7 	mov	x23, sp
    6958:	91018273 	add	x19, x19, #0x60
    695c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6960:	a9065bf5 	stp	x21, x22, [sp, #96]
    6964:	52800d16 	mov	w22, #0x68                  	// #104
    6968:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    696c:	f90043f9 	str	x25, [sp, #128]
    6970:	14000006 	b	6988 <fwp_tape_scope_release+0x78>
    6974:	97fff5a0 	bl	3ff4 <fwp_tape_buffers_dispose>
    6978:	aa1903e0 	mov	x0, x25
    697c:	97ffff56 	bl	66d4 <fwp_owned_tape_release>
    6980:	b9400285 	ldr	w5, [x20]
    6984:	37f80425 	tbnz	w5, #31, 6a08 <fwp_tape_scope_release+0xf8>
    6988:	f9404666 	ldr	x6, [x19, #136]
    698c:	9b367ca5 	smull	x5, w5, w22
    6990:	8b0500c0 	add	x0, x6, x5
    6994:	97fff180 	bl	2f94 <fwp_tape_unlink_scope>
    6998:	ad410001 	ldp	q1, q0, [x0, #32]
    699c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    69a0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    69a4:	f9400c03 	ldr	x3, [x0, #24]
    69a8:	ad0003e1 	stp	q1, q0, [sp]
    69ac:	b86568c1 	ldr	w1, [x6, x5]
    69b0:	a9440804 	ldp	x4, x2, [x0, #64]
    69b4:	b900041f 	str	wzr, [x0, #4]
    69b8:	f9403019 	ldr	x25, [x0, #96]
    69bc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    69c0:	f9000c1f 	str	xzr, [x0, #24]
    69c4:	a9020fe4 	stp	x4, x3, [sp, #32]
    69c8:	f9001be2 	str	x2, [sp, #48]
    69cc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    69d0:	f900301f 	str	xzr, [x0, #96]
    69d4:	6b15003f 	cmp	w1, w21
    69d8:	540000e8 	b.hi	69f4 <fwp_tape_scope_release+0xe4>  // b.pmore
    69dc:	9343fca5 	asr	x5, x5, #3
    69e0:	f940b260 	ldr	x0, [x19, #352]
    69e4:	9b187ca5 	mul	x5, x5, x24
    69e8:	eb0000bf 	cmp	x5, x0
    69ec:	5400004a 	b.ge	69f4 <fwp_tape_scope_release+0xe4>  // b.tcont
    69f0:	f900b265 	str	x5, [x19, #352]
    69f4:	aa1703e0 	mov	x0, x23
    69f8:	b5fffbf9 	cbnz	x25, 6974 <fwp_tape_scope_release+0x64>
    69fc:	97fff5c6 	bl	4114 <fwp_tape_buffers_release>
    6a00:	b9400285 	ldr	w5, [x20]
    6a04:	36fffc25 	tbz	w5, #31, 6988 <fwp_tape_scope_release+0x78>
    6a08:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6a0c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6a10:	f94043f9 	ldr	x25, [sp, #128]
    6a14:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6a18:	f947f400 	ldr	x0, [x0, #4072]
    6a1c:	f9401fe2 	ldr	x2, [sp, #56]
    6a20:	f9400001 	ldr	x1, [x0]
    6a24:	eb010042 	subs	x2, x2, x1
    6a28:	d2800001 	mov	x1, #0x0                   	// #0
    6a2c:	540000a1 	b.ne	6a40 <fwp_tape_scope_release+0x130>  // b.any
    6a30:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6a34:	a94553f3 	ldp	x19, x20, [sp, #80]
    6a38:	910243ff 	add	sp, sp, #0x90
    6a3c:	d65f03c0 	ret
    6a40:	a9065bf5 	stp	x21, x22, [sp, #96]
    6a44:	a90763f7 	stp	x23, x24, [sp, #112]
    6a48:	f90043f9 	str	x25, [sp, #128]
    6a4c:	97ffef71 	bl	2810 <__stack_chk_fail@plt>

0000000000006a50 <fwp_task_dispose>:
    6a50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a54:	910003fd 	mov	x29, sp
    6a58:	f9000bf3 	str	x19, [sp, #16]
    6a5c:	aa0003f3 	mov	x19, x0
    6a60:	39414000 	ldrb	w0, [x0, #80]
    6a64:	36000720 	tbz	w0, #0, 6b48 <fwp_task_dispose+0xf8>
    6a68:	f9400a60 	ldr	x0, [x19, #16]
    6a6c:	b50006e0 	cbnz	x0, 6b48 <fwp_task_dispose+0xf8>
    6a70:	a9478660 	ldp	x0, x1, [x19, #120]
    6a74:	39014e7f 	strb	wzr, [x19, #83]
    6a78:	f9003e7f 	str	xzr, [x19, #120]
    6a7c:	f100003f 	cmp	x1, #0x0
    6a80:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6a84:	54000040 	b.eq	6a8c <fwp_task_dispose+0x3c>  // b.none
    6a88:	d63f0020 	blr	x1
    6a8c:	f9405660 	ldr	x0, [x19, #168]
    6a90:	97fff6c4 	bl	45a0 <fwp_mem_free>
    6a94:	f900567f 	str	xzr, [x19, #168]
    6a98:	b9405e60 	ldr	w0, [x19, #92]
    6a9c:	7100041f 	cmp	w0, #0x1
    6aa0:	54000420 	b.eq	6b24 <fwp_task_dispose+0xd4>  // b.none
    6aa4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6aa8:	91190042 	add	x2, x2, #0x640
    6aac:	f949d840 	ldr	x0, [x2, #5040]
    6ab0:	f949ec41 	ldr	x1, [x2, #5080]
    6ab4:	cb000260 	sub	x0, x19, x0
    6ab8:	eb01401f 	cmp	x0, x1, lsl #16
    6abc:	540002e2 	b.cs	6b18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6ac0:	d350fc01 	lsr	x1, x0, #16
    6ac4:	f949fc44 	ldr	x4, [x2, #5112]
    6ac8:	8b010821 	add	x1, x1, x1, lsl #2
    6acc:	d37df021 	lsl	x1, x1, #3
    6ad0:	8b010083 	add	x3, x4, x1
    6ad4:	f9401062 	ldr	x2, [x3, #32]
    6ad8:	b4000202 	cbz	x2, 6b18 <fwp_task_dispose+0xc8>
    6adc:	38616881 	ldrb	w1, [x4, x1]
    6ae0:	7100083f 	cmp	w1, #0x2
    6ae4:	54000280 	b.eq	6b34 <fwp_task_dispose+0xe4>  // b.none
    6ae8:	7100043f 	cmp	w1, #0x1
    6aec:	54000161 	b.ne	6b18 <fwp_task_dispose+0xc8>  // b.any
    6af0:	29430464 	ldp	w4, w1, [x3, #24]
    6af4:	92403c00 	and	x0, x0, #0xffff
    6af8:	9b047c00 	mul	x0, x0, x4
    6afc:	d360fc00 	lsr	x0, x0, #32
    6b00:	eb01001f 	cmp	x0, x1
    6b04:	540000a2 	b.cs	6b18 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6b08:	8b000042 	add	x2, x2, x0
    6b0c:	39400040 	ldrb	w0, [x2]
    6b10:	7100041f 	cmp	w0, #0x1
    6b14:	54000080 	b.eq	6b24 <fwp_task_dispose+0xd4>  // b.none
    6b18:	f9400bf3 	ldr	x19, [sp, #16]
    6b1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b20:	d65f03c0 	ret
    6b24:	aa1303e0 	mov	x0, x19
    6b28:	f9400bf3 	ldr	x19, [sp, #16]
    6b2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b30:	17fff69c 	b	45a0 <fwp_mem_free>
    6b34:	72003c1f 	tst	w0, #0xffff
    6b38:	54fffea0 	b.eq	6b0c <fwp_task_dispose+0xbc>  // b.none
    6b3c:	f9400bf3 	ldr	x19, [sp, #16]
    6b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b44:	d65f03c0 	ret
    6b48:	97ffef46 	bl	2860 <abort@plt>
    6b4c:	d503201f 	nop

0000000000006b50 <fwp_free_zombie>:
    6b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b54:	910003fd 	mov	x29, sp
    6b58:	a90153f3 	stp	x19, x20, [sp, #16]
    6b5c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6b60:	91018281 	add	x1, x20, #0x60
    6b64:	f940b433 	ldr	x19, [x1, #360]
    6b68:	b4000333 	cbz	x19, 6bcc <fwp_free_zombie+0x7c>
    6b6c:	f9404c20 	ldr	x0, [x1, #152]
    6b70:	eb00027f 	cmp	x19, x0
    6b74:	540002c0 	b.eq	6bcc <fwp_free_zombie+0x7c>  // b.none
    6b78:	b9417022 	ldr	w2, [x1, #368]
    6b7c:	f9400a60 	ldr	x0, [x19, #16]
    6b80:	7100fc5f 	cmp	w2, #0x3f
    6b84:	5400078c 	b.gt	6c74 <fwp_free_zombie+0x124>
    6b88:	91060023 	add	x3, x1, #0x180
    6b8c:	11000444 	add	w4, w2, #0x1
    6b90:	b9017024 	str	w4, [x1, #368]
    6b94:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6b98:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6b9c:	a9530261 	ldp	x1, x0, [x19, #304]
    6ba0:	b4000741 	cbz	x1, 6c88 <fwp_free_zombie+0x138>
    6ba4:	f9009c20 	str	x0, [x1, #312]
    6ba8:	b4000040 	cbz	x0, 6bb0 <fwp_free_zombie+0x60>
    6bac:	f9009801 	str	x1, [x0, #304]
    6bb0:	91018294 	add	x20, x20, #0x60
    6bb4:	b9405e60 	ldr	w0, [x19, #92]
    6bb8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6bbc:	f900b69f 	str	xzr, [x20, #360]
    6bc0:	34000140 	cbz	w0, 6be8 <fwp_free_zombie+0x98>
    6bc4:	7100041f 	cmp	w0, #0x1
    6bc8:	54000080 	b.eq	6bd8 <fwp_free_zombie+0x88>  // b.none
    6bcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bd4:	d65f03c0 	ret
    6bd8:	aa1303e0 	mov	x0, x19
    6bdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6be0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6be4:	17ffff9b 	b	6a50 <fwp_task_dispose>
    6be8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    6bec:	91190082 	add	x2, x4, #0x640
    6bf0:	f949d841 	ldr	x1, [x2, #5040]
    6bf4:	f949ec40 	ldr	x0, [x2, #5080]
    6bf8:	cb010261 	sub	x1, x19, x1
    6bfc:	eb00403f 	cmp	x1, x0, lsl #16
    6c00:	54fffe62 	b.cs	6bcc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c04:	d350fc20 	lsr	x0, x1, #16
    6c08:	f949fc43 	ldr	x3, [x2, #5112]
    6c0c:	8b000800 	add	x0, x0, x0, lsl #2
    6c10:	d37df000 	lsl	x0, x0, #3
    6c14:	8b000062 	add	x2, x3, x0
    6c18:	f9401054 	ldr	x20, [x2, #32]
    6c1c:	b4fffd94 	cbz	x20, 6bcc <fwp_free_zombie+0x7c>
    6c20:	38606860 	ldrb	w0, [x3, x0]
    6c24:	7100081f 	cmp	w0, #0x2
    6c28:	54000360 	b.eq	6c94 <fwp_free_zombie+0x144>  // b.none
    6c2c:	7100041f 	cmp	w0, #0x1
    6c30:	54fffce1 	b.ne	6bcc <fwp_free_zombie+0x7c>  // b.any
    6c34:	29430043 	ldp	w3, w0, [x2, #24]
    6c38:	92403c21 	and	x1, x1, #0xffff
    6c3c:	9b037c21 	mul	x1, x1, x3
    6c40:	d360fc21 	lsr	x1, x1, #32
    6c44:	eb00003f 	cmp	x1, x0
    6c48:	54fffc22 	b.cs	6bcc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c4c:	8b010294 	add	x20, x20, x1
    6c50:	39400280 	ldrb	w0, [x20]
    6c54:	34fffbc0 	cbz	w0, 6bcc <fwp_free_zombie+0x7c>
    6c58:	7100041f 	cmp	w0, #0x1
    6c5c:	54fffbe0 	b.eq	6bd8 <fwp_free_zombie+0x88>  // b.none
    6c60:	7103fc1f 	cmp	w0, #0xff
    6c64:	540001e0 	b.eq	6ca0 <fwp_free_zombie+0x150>  // b.none
    6c68:	51000400 	sub	w0, w0, #0x1
    6c6c:	39000280 	strb	w0, [x20]
    6c70:	17ffffd7 	b	6bcc <fwp_free_zombie+0x7c>
    6c74:	f9400e61 	ldr	x1, [x19, #24]
    6c78:	97ffef2e 	bl	2930 <munmap@plt>
    6c7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6c80:	a9530261 	ldp	x1, x0, [x19, #304]
    6c84:	b5fff901 	cbnz	x1, 6ba4 <fwp_free_zombie+0x54>
    6c88:	91018282 	add	x2, x20, #0x60
    6c8c:	f901c040 	str	x0, [x2, #896]
    6c90:	17ffffc6 	b	6ba8 <fwp_free_zombie+0x58>
    6c94:	72003c3f 	tst	w1, #0xffff
    6c98:	54fff9a1 	b.ne	6bcc <fwp_free_zombie+0x7c>  // b.any
    6c9c:	17ffffed 	b	6c50 <fwp_free_zombie+0x100>
    6ca0:	ca544680 	eor	x0, x20, x20, lsr #17
    6ca4:	91190084 	add	x4, x4, #0x640
    6ca8:	ca402400 	eor	x0, x0, x0, lsr #9
    6cac:	92401c00 	and	x0, x0, #0xff
    6cb0:	910a2402 	add	x2, x0, #0x289
    6cb4:	8b000c80 	add	x0, x4, x0, lsl #3
    6cb8:	8b020c82 	add	x2, x4, x2, lsl #3
    6cbc:	f94a2400 	ldr	x0, [x0, #5192]
    6cc0:	b50000a0 	cbnz	x0, 6cd4 <fwp_free_zombie+0x184>
    6cc4:	14000013 	b	6d10 <fwp_free_zombie+0x1c0>
    6cc8:	91004002 	add	x2, x0, #0x10
    6ccc:	f9400800 	ldr	x0, [x0, #16]
    6cd0:	b4000200 	cbz	x0, 6d10 <fwp_free_zombie+0x1c0>
    6cd4:	f9400001 	ldr	x1, [x0]
    6cd8:	eb14003f 	cmp	x1, x20
    6cdc:	54ffff61 	b.ne	6cc8 <fwp_free_zombie+0x178>  // b.any
    6ce0:	f9400041 	ldr	x1, [x2]
    6ce4:	f9400420 	ldr	x0, [x1, #8]
    6ce8:	d1000400 	sub	x0, x0, #0x1
    6cec:	f9000420 	str	x0, [x1, #8]
    6cf0:	f103f81f 	cmp	x0, #0xfe
    6cf4:	54fff6c1 	b.ne	6bcc <fwp_free_zombie+0x7c>  // b.any
    6cf8:	39400280 	ldrb	w0, [x20]
    6cfc:	7103fc1f 	cmp	w0, #0xff
    6d00:	540000e0 	b.eq	6d1c <fwp_free_zombie+0x1cc>  // b.none
    6d04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d08:	39000280 	strb	w0, [x20]
    6d0c:	17ffffb0 	b	6bcc <fwp_free_zombie+0x7c>
    6d10:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    6d14:	913be000 	add	x0, x0, #0xef8
    6d18:	97fff567 	bl	42b4 <fwp_trap>
    6d1c:	aa1403e0 	mov	x0, x20
    6d20:	97fff585 	bl	4334 <fwp_rc_forget_slot.part.0>
    6d24:	17fffff8 	b	6d04 <fwp_free_zombie+0x1b4>
    6d28:	d503201f 	nop
    6d2c:	d503201f 	nop

0000000000006d30 <fwp_block>:
    6d30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d34:	910003fd 	mov	x29, sp
    6d38:	a90153f3 	stp	x19, x20, [sp, #16]
    6d3c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6d40:	91018274 	add	x20, x19, #0x60
    6d44:	f9406682 	ldr	x2, [x20, #200]
    6d48:	b4000642 	cbz	x2, 6e10 <fwp_block+0xe0>
    6d4c:	91018261 	add	x1, x19, #0x60
    6d50:	f9408040 	ldr	x0, [x2, #256]
    6d54:	f9006420 	str	x0, [x1, #200]
    6d58:	b40006a0 	cbz	x0, 6e2c <fwp_block+0xfc>
    6d5c:	d503201f 	nop
    6d60:	91018263 	add	x3, x19, #0x60
    6d64:	3901505f 	strb	wzr, [x2, #84]
    6d68:	f9404c64 	ldr	x4, [x3, #152]
    6d6c:	eb02009f 	cmp	x4, x2
    6d70:	54000440 	b.eq	6df8 <fwp_block+0xc8>  // b.none
    6d74:	f941c465 	ldr	x5, [x3, #904]
    6d78:	f9004c62 	str	x2, [x3, #152]
    6d7c:	f9400441 	ldr	x1, [x2, #8]
    6d80:	f9004885 	str	x5, [x4, #144]
    6d84:	f941c865 	ldr	x5, [x3, #912]
    6d88:	f9004c85 	str	x5, [x4, #152]
    6d8c:	f941cc65 	ldr	x5, [x3, #920]
    6d90:	f9005085 	str	x5, [x4, #160]
    6d94:	f941d065 	ldr	x5, [x3, #928]
    6d98:	f9005485 	str	x5, [x4, #168]
    6d9c:	f941d465 	ldr	x5, [x3, #936]
    6da0:	f9005885 	str	x5, [x4, #176]
    6da4:	f941d865 	ldr	x5, [x3, #944]
    6da8:	f9005c85 	str	x5, [x4, #184]
    6dac:	f941dc65 	ldr	x5, [x3, #952]
    6db0:	f9006085 	str	x5, [x4, #192]
    6db4:	f9400480 	ldr	x0, [x4, #8]
    6db8:	f9404844 	ldr	x4, [x2, #144]
    6dbc:	f901c464 	str	x4, [x3, #904]
    6dc0:	f9404c44 	ldr	x4, [x2, #152]
    6dc4:	f901c864 	str	x4, [x3, #912]
    6dc8:	f9405044 	ldr	x4, [x2, #160]
    6dcc:	f901cc64 	str	x4, [x3, #920]
    6dd0:	f9405444 	ldr	x4, [x2, #168]
    6dd4:	f901d064 	str	x4, [x3, #928]
    6dd8:	f9405844 	ldr	x4, [x2, #176]
    6ddc:	f901d464 	str	x4, [x3, #936]
    6de0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6de4:	f901d864 	str	x4, [x3, #944]
    6de8:	f901dc62 	str	x2, [x3, #952]
    6dec:	97ffeea1 	bl	2870 <swapcontext@plt>
    6df0:	97ffff58 	bl	6b50 <fwp_free_zombie>
    6df4:	d503201f 	nop
    6df8:	91018260 	add	x0, x19, #0x60
    6dfc:	b943c000 	ldr	w0, [x0, #960]
    6e00:	340001a0 	cbz	w0, 6e34 <fwp_block+0x104>
    6e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e0c:	d65f03c0 	ret
    6e10:	97fff770 	bl	4bd0 <fwp_poll_events>
    6e14:	f9406682 	ldr	x2, [x20, #200]
    6e18:	b4ffffc2 	cbz	x2, 6e10 <fwp_block+0xe0>
    6e1c:	91018261 	add	x1, x19, #0x60
    6e20:	f9408040 	ldr	x0, [x2, #256]
    6e24:	f9006420 	str	x0, [x1, #200]
    6e28:	b5fff9c0 	cbnz	x0, 6d60 <fwp_block+0x30>
    6e2c:	f900603f 	str	xzr, [x1, #192]
    6e30:	17ffffcc 	b	6d60 <fwp_block+0x30>
    6e34:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    6e38:	91064000 	add	x0, x0, #0x190
    6e3c:	97ffeed9 	bl	29a0 <getenv@plt>
    6e40:	5284e202 	mov	w2, #0x2710                	// #10000
    6e44:	b4000060 	cbz	x0, 6e50 <fwp_block+0x120>
    6e48:	39400001 	ldrb	w1, [x0]
    6e4c:	350000c1 	cbnz	w1, 6e64 <fwp_block+0x134>
    6e50:	91018273 	add	x19, x19, #0x60
    6e54:	b903c262 	str	w2, [x19, #960]
    6e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e60:	d65f03c0 	ret
    6e64:	52800142 	mov	w2, #0xa                   	// #10
    6e68:	d2800001 	mov	x1, #0x0                   	// #0
    6e6c:	97ffee1d 	bl	26e0 <strtoll@plt>
    6e70:	d1000403 	sub	x3, x0, #0x1
    6e74:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6e78:	eb02007f 	cmp	x3, x2
    6e7c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6e80:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6e84:	17fffff3 	b	6e50 <fwp_block+0x120>
    6e88:	d503201f 	nop
    6e8c:	d503201f 	nop

0000000000006e90 <fwp_drop4>:
    6e90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6e94:	910003fd 	mov	x29, sp
    6e98:	a90153f3 	stp	x19, x20, [sp, #16]
    6e9c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6ea0:	f90013f5 	str	x21, [sp, #32]
    6ea4:	91190275 	add	x21, x19, #0x640
    6ea8:	f949daa1 	ldr	x1, [x21, #5040]
    6eac:	f949eea2 	ldr	x2, [x21, #5080]
    6eb0:	cb010001 	sub	x1, x0, x1
    6eb4:	eb02403f 	cmp	x1, x2, lsl #16
    6eb8:	54000382 	b.cs	6f28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ebc:	d350fc22 	lsr	x2, x1, #16
    6ec0:	f949fea3 	ldr	x3, [x21, #5112]
    6ec4:	8b020842 	add	x2, x2, x2, lsl #2
    6ec8:	d37df042 	lsl	x2, x2, #3
    6ecc:	8b020064 	add	x4, x3, x2
    6ed0:	f9401094 	ldr	x20, [x4, #32]
    6ed4:	b40002b4 	cbz	x20, 6f28 <fwp_drop4+0x98>
    6ed8:	38626862 	ldrb	w2, [x3, x2]
    6edc:	7100085f 	cmp	w2, #0x2
    6ee0:	540007a0 	b.eq	6fd4 <fwp_drop4+0x144>  // b.none
    6ee4:	7100045f 	cmp	w2, #0x1
    6ee8:	54000201 	b.ne	6f28 <fwp_drop4+0x98>  // b.any
    6eec:	29430885 	ldp	w5, w2, [x4, #24]
    6ef0:	92403c21 	and	x1, x1, #0xffff
    6ef4:	9b057c21 	mul	x1, x1, x5
    6ef8:	d360fc21 	lsr	x1, x1, #32
    6efc:	eb02003f 	cmp	x1, x2
    6f00:	54000142 	b.cs	6f28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f04:	8b010294 	add	x20, x20, x1
    6f08:	39400281 	ldrb	w1, [x20]
    6f0c:	340000e1 	cbz	w1, 6f28 <fwp_drop4+0x98>
    6f10:	7100043f 	cmp	w1, #0x1
    6f14:	54000120 	b.eq	6f38 <fwp_drop4+0xa8>  // b.none
    6f18:	7103fc3f 	cmp	w1, #0xff
    6f1c:	540007c0 	b.eq	7014 <fwp_drop4+0x184>  // b.none
    6f20:	51000421 	sub	w1, w1, #0x1
    6f24:	39000281 	strb	w1, [x20]
    6f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f2c:	f94013f5 	ldr	x21, [sp, #32]
    6f30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f34:	d65f03c0 	ret
    6f38:	f9400001 	ldr	x1, [x0]
    6f3c:	b7f80581 	tbnz	x1, #63, 6fec <fwp_drop4+0x15c>
    6f40:	91190273 	add	x19, x19, #0x640
    6f44:	f949da61 	ldr	x1, [x19, #5040]
    6f48:	f949ee62 	ldr	x2, [x19, #5080]
    6f4c:	cb010001 	sub	x1, x0, x1
    6f50:	eb02403f 	cmp	x1, x2, lsl #16
    6f54:	54fffea2 	b.cs	6f28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f58:	d350fc22 	lsr	x2, x1, #16
    6f5c:	8b020842 	add	x2, x2, x2, lsl #2
    6f60:	d37df042 	lsl	x2, x2, #3
    6f64:	8b020065 	add	x5, x3, x2
    6f68:	f94010a4 	ldr	x4, [x5, #32]
    6f6c:	b4fffde4 	cbz	x4, 6f28 <fwp_drop4+0x98>
    6f70:	38626862 	ldrb	w2, [x3, x2]
    6f74:	7100085f 	cmp	w2, #0x2
    6f78:	54000220 	b.eq	6fbc <fwp_drop4+0x12c>  // b.none
    6f7c:	7100045f 	cmp	w2, #0x1
    6f80:	54fffd41 	b.ne	6f28 <fwp_drop4+0x98>  // b.any
    6f84:	294308a3 	ldp	w3, w2, [x5, #24]
    6f88:	92403c21 	and	x1, x1, #0xffff
    6f8c:	9b037c21 	mul	x1, x1, x3
    6f90:	d360fc21 	lsr	x1, x1, #32
    6f94:	eb02003f 	cmp	x1, x2
    6f98:	54fffc82 	b.cs	6f28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f9c:	8b010084 	add	x4, x4, x1
    6fa0:	39400081 	ldrb	w1, [x4]
    6fa4:	7100043f 	cmp	w1, #0x1
    6fa8:	54fffc01 	b.ne	6f28 <fwp_drop4+0x98>  // b.any
    6fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fb0:	f94013f5 	ldr	x21, [sp, #32]
    6fb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fb8:	17fff57a 	b	45a0 <fwp_mem_free>
    6fbc:	72003c3f 	tst	w1, #0xffff
    6fc0:	54ffff00 	b.eq	6fa0 <fwp_drop4+0x110>  // b.none
    6fc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fc8:	f94013f5 	ldr	x21, [sp, #32]
    6fcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fd0:	d65f03c0 	ret
    6fd4:	72003c3f 	tst	w1, #0xffff
    6fd8:	54fff980 	b.eq	6f08 <fwp_drop4+0x78>  // b.none
    6fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fe0:	f94013f5 	ldr	x21, [sp, #32]
    6fe4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fe8:	d65f03c0 	ret
    6fec:	f9400414 	ldr	x20, [x0, #8]
    6ff0:	97fffbc0 	bl	5ef0 <fwp_rc_free_arr>
    6ff4:	91190260 	add	x0, x19, #0x640
    6ff8:	f949d801 	ldr	x1, [x0, #5040]
    6ffc:	f949ec00 	ldr	x0, [x0, #5080]
    7000:	cb010281 	sub	x1, x20, x1
    7004:	eb00403f 	cmp	x1, x0, lsl #16
    7008:	54fff902 	b.cs	6f28 <fwp_drop4+0x98>  // b.hs, b.nlast
    700c:	aa1403e0 	mov	x0, x20
    7010:	17ffffab 	b	6ebc <fwp_drop4+0x2c>
    7014:	ca544680 	eor	x0, x20, x20, lsr #17
    7018:	91190273 	add	x19, x19, #0x640
    701c:	ca402400 	eor	x0, x0, x0, lsr #9
    7020:	92401c00 	and	x0, x0, #0xff
    7024:	910a2402 	add	x2, x0, #0x289
    7028:	8b000e60 	add	x0, x19, x0, lsl #3
    702c:	8b020e62 	add	x2, x19, x2, lsl #3
    7030:	f94a2400 	ldr	x0, [x0, #5192]
    7034:	b50000a0 	cbnz	x0, 7048 <fwp_drop4+0x1b8>
    7038:	14000013 	b	7084 <fwp_drop4+0x1f4>
    703c:	91004002 	add	x2, x0, #0x10
    7040:	f9400800 	ldr	x0, [x0, #16]
    7044:	b4000200 	cbz	x0, 7084 <fwp_drop4+0x1f4>
    7048:	f9400001 	ldr	x1, [x0]
    704c:	eb14003f 	cmp	x1, x20
    7050:	54ffff61 	b.ne	703c <fwp_drop4+0x1ac>  // b.any
    7054:	f9400041 	ldr	x1, [x2]
    7058:	f9400420 	ldr	x0, [x1, #8]
    705c:	d1000400 	sub	x0, x0, #0x1
    7060:	f9000420 	str	x0, [x1, #8]
    7064:	f103f81f 	cmp	x0, #0xfe
    7068:	54fff601 	b.ne	6f28 <fwp_drop4+0x98>  // b.any
    706c:	39400280 	ldrb	w0, [x20]
    7070:	7103fc1f 	cmp	w0, #0xff
    7074:	540000e0 	b.eq	7090 <fwp_drop4+0x200>  // b.none
    7078:	12800020 	mov	w0, #0xfffffffe            	// #-2
    707c:	39000280 	strb	w0, [x20]
    7080:	17ffffaa 	b	6f28 <fwp_drop4+0x98>
    7084:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    7088:	913be000 	add	x0, x0, #0xef8
    708c:	97fff48a 	bl	42b4 <fwp_trap>
    7090:	aa1403e0 	mov	x0, x20
    7094:	97fff4a8 	bl	4334 <fwp_rc_forget_slot.part.0>
    7098:	17fffff8 	b	7078 <fwp_drop4+0x1e8>
    709c:	d503201f 	nop

00000000000070a0 <fwp_caps161>:
    70a0:	34000041 	cbz	w1, 70a8 <fwp_caps161+0x8>
    70a4:	d65f03c0 	ret
    70a8:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    70ac:	91190063 	add	x3, x3, #0x640
    70b0:	f949d861 	ldr	x1, [x3, #5040]
    70b4:	f949ec62 	ldr	x2, [x3, #5080]
    70b8:	cb010001 	sub	x1, x0, x1
    70bc:	eb02403f 	cmp	x1, x2, lsl #16
    70c0:	54ffff22 	b.cs	70a4 <fwp_caps161+0x4>  // b.hs, b.nlast
    70c4:	d350fc22 	lsr	x2, x1, #16
    70c8:	f949fc65 	ldr	x5, [x3, #5112]
    70cc:	8b020842 	add	x2, x2, x2, lsl #2
    70d0:	d37df042 	lsl	x2, x2, #3
    70d4:	8b0200a4 	add	x4, x5, x2
    70d8:	f9401083 	ldr	x3, [x4, #32]
    70dc:	b4fffe43 	cbz	x3, 70a4 <fwp_caps161+0x4>
    70e0:	386268a2 	ldrb	w2, [x5, x2]
    70e4:	7100085f 	cmp	w2, #0x2
    70e8:	540001c0 	b.eq	7120 <fwp_caps161+0x80>  // b.none
    70ec:	7100045f 	cmp	w2, #0x1
    70f0:	54fffda1 	b.ne	70a4 <fwp_caps161+0x4>  // b.any
    70f4:	29430885 	ldp	w5, w2, [x4, #24]
    70f8:	92403c21 	and	x1, x1, #0xffff
    70fc:	9b057c21 	mul	x1, x1, x5
    7100:	d360fc21 	lsr	x1, x1, #32
    7104:	eb02003f 	cmp	x1, x2
    7108:	54fffce2 	b.cs	70a4 <fwp_caps161+0x4>  // b.hs, b.nlast
    710c:	8b010063 	add	x3, x3, x1
    7110:	39400061 	ldrb	w1, [x3]
    7114:	7100043f 	cmp	w1, #0x1
    7118:	54fffc61 	b.ne	70a4 <fwp_caps161+0x4>  // b.any
    711c:	17fff521 	b	45a0 <fwp_mem_free>
    7120:	72003c3f 	tst	w1, #0xffff
    7124:	54ffff60 	b.eq	7110 <fwp_caps161+0x70>  // b.none
    7128:	d65f03c0 	ret
    712c:	d503201f 	nop

0000000000007130 <f12>:
    7130:	d104c3ff 	sub	sp, sp, #0x130
    7134:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    7138:	f947f442 	ldr	x2, [x2, #4072]
    713c:	a90d7bfd 	stp	x29, x30, [sp, #208]
    7140:	910343fd 	add	x29, sp, #0xd0
    7144:	a90f5bf5 	stp	x21, x22, [sp, #240]
    7148:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    714c:	911902a3 	add	x3, x21, #0x640
    7150:	a90e53f3 	stp	x19, x20, [sp, #224]
    7154:	b00000d4 	adrp	x20, 20000 <__data_start>
    7158:	91018284 	add	x4, x20, #0x60
    715c:	f949d861 	ldr	x1, [x3, #5040]
    7160:	a91063f7 	stp	x23, x24, [sp, #256]
    7164:	b00000d8 	adrp	x24, 20000 <__data_start>
    7168:	f949ec65 	ldr	x5, [x3, #5080]
    716c:	a9116bf9 	stp	x25, x26, [sp, #272]
    7170:	91004318 	add	x24, x24, #0x10
    7174:	a91273fb 	stp	x27, x28, [sp, #288]
    7178:	91008318 	add	x24, x24, #0x20
    717c:	910143f7 	add	x23, sp, #0x50
    7180:	f941c886 	ldr	x6, [x4, #912]
    7184:	f9400047 	ldr	x7, [x2]
    7188:	f90067e7 	str	x7, [sp, #200]
    718c:	d2800007 	mov	x7, #0x0                   	// #0
    7190:	910123f6 	add	x22, sp, #0x48
    7194:	f0fffff9 	adrp	x25, 6000 <fwp_rc_dup+0x8c>
    7198:	12800007 	mov	w7, #0xffffffff            	// #-1
    719c:	91244322 	add	x2, x25, #0x910
    71a0:	cb010301 	sub	x1, x24, x1
    71a4:	b9004be7 	str	w7, [sp, #72]
    71a8:	a9050be6 	stp	x6, x2, [sp, #80]
    71ac:	aa0003f3 	mov	x19, x0
    71b0:	f90033f6 	str	x22, [sp, #96]
    71b4:	f901c897 	str	x23, [x4, #912]
    71b8:	eb05403f 	cmp	x1, x5, lsl #16
    71bc:	540003a2 	b.cs	7230 <f12+0x100>  // b.hs, b.nlast
    71c0:	d350fc20 	lsr	x0, x1, #16
    71c4:	f949fc64 	ldr	x4, [x3, #5112]
    71c8:	8b000800 	add	x0, x0, x0, lsl #2
    71cc:	d37df002 	lsl	x2, x0, #3
    71d0:	8b020083 	add	x3, x4, x2
    71d4:	f9401060 	ldr	x0, [x3, #32]
    71d8:	b40002c0 	cbz	x0, 7230 <f12+0x100>
    71dc:	38626882 	ldrb	w2, [x4, x2]
    71e0:	7100085f 	cmp	w2, #0x2
    71e4:	54000c00 	b.eq	7364 <f12+0x234>  // b.none
    71e8:	7100045f 	cmp	w2, #0x1
    71ec:	54000221 	b.ne	7230 <f12+0x100>  // b.any
    71f0:	29430864 	ldp	w4, w2, [x3, #24]
    71f4:	92403c21 	and	x1, x1, #0xffff
    71f8:	9b047c21 	mul	x1, x1, x4
    71fc:	d360fc21 	lsr	x1, x1, #32
    7200:	eb02003f 	cmp	x1, x2
    7204:	54000162 	b.cs	7230 <f12+0x100>  // b.hs, b.nlast
    7208:	8b010000 	add	x0, x0, x1
    720c:	39400001 	ldrb	w1, [x0]
    7210:	34000101 	cbz	w1, 7230 <f12+0x100>
    7214:	91018282 	add	x2, x20, #0x60
    7218:	b9413043 	ldr	w3, [x2, #304]
    721c:	350013a3 	cbnz	w3, 7490 <f12+0x360>
    7220:	7103f43f 	cmp	w1, #0xfd
    7224:	54002748 	b.hi	770c <f12+0x5dc>  // b.pmore
    7228:	11000421 	add	w1, w1, #0x1
    722c:	39000001 	strb	w1, [x0]
    7230:	aa1803e0 	mov	x0, x24
    7234:	97fffccb 	bl	6560 <fwp_closure_drop>
    7238:	b40001d3 	cbz	x19, 7270 <f12+0x140>
    723c:	aa1303e0 	mov	x0, x19
    7240:	d2800001 	mov	x1, #0x0                   	// #0
    7244:	d503201f 	nop
    7248:	f9400800 	ldr	x0, [x0, #16]
    724c:	91000421 	add	x1, x1, #0x1
    7250:	b5ffffc0 	cbnz	x0, 7248 <f12+0x118>
    7254:	aa0103f8 	mov	x24, x1
    7258:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    725c:	eb00003f 	cmp	x1, x0
    7260:	540000a9 	b.ls	7274 <f12+0x144>  // b.plast
    7264:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7268:	91068000 	add	x0, x0, #0x1a0
    726c:	97fff412 	bl	42b4 <fwp_trap>
    7270:	d2800018 	mov	x24, #0x0                   	// #0
    7274:	9101829a 	add	x26, x20, #0x60
    7278:	b943c740 	ldr	w0, [x26, #964]
    727c:	34001340 	cbz	w0, 74e4 <f12+0x3b4>
    7280:	91018280 	add	x0, x20, #0x60
    7284:	f940901b 	ldr	x27, [x0, #288]
    7288:	f940b01a 	ldr	x26, [x0, #352]
    728c:	eb1b035f 	cmp	x26, x27
    7290:	5400070a 	b.ge	7370 <f12+0x240>  // b.tcont
    7294:	f9404401 	ldr	x1, [x0, #136]
    7298:	8b1a0740 	add	x0, x26, x26, lsl #1
    729c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    72a0:	8b000b40 	add	x0, x26, x0, lsl #2
    72a4:	8b000c20 	add	x0, x1, x0, lsl #3
    72a8:	b9400401 	ldr	w1, [x0, #4]
    72ac:	35000081 	cbnz	w1, 72bc <f12+0x18c>
    72b0:	b9400001 	ldr	w1, [x0]
    72b4:	6b02003f 	cmp	w1, w2
    72b8:	540005c9 	b.ls	7370 <f12+0x240>  // b.plast
    72bc:	9100075a 	add	x26, x26, #0x1
    72c0:	9101a000 	add	x0, x0, #0x68
    72c4:	eb1b035f 	cmp	x26, x27
    72c8:	54ffff01 	b.ne	72a8 <f12+0x178>  // b.any
    72cc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    72d0:	eb00037f 	cmp	x27, x0
    72d4:	54001eec 	b.gt	76b0 <f12+0x580>
    72d8:	91018280 	add	x0, x20, #0x60
    72dc:	f9408801 	ldr	x1, [x0, #272]
    72e0:	f940441c 	ldr	x28, [x0, #136]
    72e4:	eb1b003f 	cmp	x1, x27
    72e8:	54000261 	b.ne	7334 <f12+0x204>  // b.any
    72ec:	b40027bb 	cbz	x27, 77e0 <f12+0x6b0>
    72f0:	d37ffb63 	lsl	x3, x27, #1
    72f4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    72f8:	eb00007f 	cmp	x3, x0
    72fc:	9a80d063 	csel	x3, x3, x0, le
    7300:	8b030461 	add	x1, x3, x3, lsl #1
    7304:	8b010861 	add	x1, x3, x1, lsl #2
    7308:	d37df021 	lsl	x1, x1, #3
    730c:	aa1c03e0 	mov	x0, x28
    7310:	52800002 	mov	w2, #0x0                   	// #0
    7314:	f90007e3 	str	x3, [sp, #8]
    7318:	97fff34b 	bl	4044 <ad_raw_realloc>
    731c:	f94007e3 	ldr	x3, [sp, #8]
    7320:	aa0003fc 	mov	x28, x0
    7324:	b4004760 	cbz	x0, 7c10 <f12+0xae0>
    7328:	91018280 	add	x0, x20, #0x60
    732c:	f900441c 	str	x28, [x0, #136]
    7330:	f9008803 	str	x3, [x0, #272]
    7334:	8b1b0760 	add	x0, x27, x27, lsl #1
    7338:	91018281 	add	x1, x20, #0x60
    733c:	4f000400 	movi	v0.4s, #0x0
    7340:	91000762 	add	x2, x27, #0x1
    7344:	8b000b60 	add	x0, x27, x0, lsl #2
    7348:	f9009022 	str	x2, [x1, #288]
    734c:	8b000f80 	add	x0, x28, x0, lsl #3
    7350:	ad000000 	stp	q0, q0, [x0]
    7354:	ad010000 	stp	q0, q0, [x0, #32]
    7358:	ad020000 	stp	q0, q0, [x0, #64]
    735c:	f900301f 	str	xzr, [x0, #96]
    7360:	14000008 	b	7380 <f12+0x250>
    7364:	72003c3f 	tst	w1, #0xffff
    7368:	54fff641 	b.ne	7230 <f12+0x100>  // b.any
    736c:	17ffffa8 	b	720c <f12+0xdc>
    7370:	eb1b035f 	cmp	x26, x27
    7374:	54fffac0 	b.eq	72cc <f12+0x19c>  // b.none
    7378:	91018280 	add	x0, x20, #0x60
    737c:	f940441c 	ldr	x28, [x0, #136]
    7380:	8b1a075b 	add	x27, x26, x26, lsl #1
    7384:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    7388:	913a0000 	add	x0, x0, #0xe80
    738c:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    7390:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7394:	f900337f 	str	xzr, [x27, #96]
    7398:	97ffed82 	bl	29a0 <getenv@plt>
    739c:	b4000080 	cbz	x0, 73ac <f12+0x27c>
    73a0:	39400001 	ldrb	w1, [x0]
    73a4:	7100c03f 	cmp	w1, #0x30
    73a8:	540007c0 	b.eq	74a0 <f12+0x370>  // b.none
    73ac:	91018280 	add	x0, x20, #0x60
    73b0:	f9408401 	ldr	x1, [x0, #264]
    73b4:	b50007c1 	cbnz	x1, 74ac <f12+0x37c>
    73b8:	91018282 	add	x2, x20, #0x60
    73bc:	2f000400 	mvni	v0.2s, #0x0
    73c0:	b9400363 	ldr	w3, [x27]
    73c4:	52800020 	mov	w0, #0x1                   	// #1
    73c8:	91000744 	add	x4, x26, #0x1
    73cc:	a900e378 	stp	x24, x24, [x27, #8]
    73d0:	0b000063 	add	w3, w3, w0
    73d4:	f941c841 	ldr	x1, [x2, #912]
    73d8:	29000363 	stp	w3, w0, [x27]
    73dc:	f9002b7f 	str	xzr, [x27, #80]
    73e0:	f900b044 	str	x4, [x2, #352]
    73e4:	fd002f60 	str	d0, [x27, #88]
    73e8:	b4001581 	cbz	x1, 7698 <f12+0x568>
    73ec:	91244339 	add	x25, x25, #0x910
    73f0:	14000003 	b	73fc <f12+0x2cc>
    73f4:	f9400021 	ldr	x1, [x1]
    73f8:	b4001501 	cbz	x1, 7698 <f12+0x568>
    73fc:	f9400422 	ldr	x2, [x1, #8]
    7400:	eb19005f 	cmp	x2, x25
    7404:	54ffff81 	b.ne	73f4 <f12+0x2c4>  // b.any
    7408:	f9400820 	ldr	x0, [x1, #16]
    740c:	2a1a03e2 	mov	w2, w26
    7410:	b9400001 	ldr	w1, [x0]
    7414:	f9002b60 	str	x0, [x27, #80]
    7418:	b9005f61 	str	w1, [x27, #92]
    741c:	37f80081 	tbnz	w1, #31, 742c <f12+0x2fc>
    7420:	52800d05 	mov	w5, #0x68                  	// #104
    7424:	9b257021 	smaddl	x1, w1, w5, x28
    7428:	b900583a 	str	w26, [x1, #88]
    742c:	b9000002 	str	w2, [x0]
    7430:	aa1303e0 	mov	x0, x19
    7434:	d2800002 	mov	x2, #0x0                   	// #0
    7438:	b4000653 	cbz	x19, 7500 <f12+0x3d0>
    743c:	d503201f 	nop
    7440:	f9400800 	ldr	x0, [x0, #16]
    7444:	91000442 	add	x2, x2, #0x1
    7448:	b5ffffc0 	cbnz	x0, 7440 <f12+0x310>
    744c:	aa1303e1 	mov	x1, x19
    7450:	f9400821 	ldr	x1, [x1, #16]
    7454:	91000400 	add	x0, x0, #0x1
    7458:	b5ffffc1 	cbnz	x1, 7450 <f12+0x320>
    745c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7460:	eb01001f 	cmp	x0, x1
    7464:	54000108 	b.hi	7484 <f12+0x354>  // b.pmore
    7468:	f100005f 	cmp	x2, #0x0
    746c:	540004ad 	b.le	7500 <f12+0x3d0>
    7470:	eb00005f 	cmp	x2, x0
    7474:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7478:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    747c:	eb01033f 	cmp	x25, x1
    7480:	540011e9 	b.ls	76bc <f12+0x58c>  // b.plast
    7484:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7488:	91088000 	add	x0, x0, #0x220
    748c:	97fff38a 	bl	42b4 <fwp_trap>
    7490:	f940ac43 	ldr	x3, [x2, #344]
    7494:	91000463 	add	x3, x3, #0x1
    7498:	f900ac43 	str	x3, [x2, #344]
    749c:	17ffff61 	b	7220 <f12+0xf0>
    74a0:	39400400 	ldrb	w0, [x0, #1]
    74a4:	34fff8a0 	cbz	w0, 73b8 <f12+0x288>
    74a8:	17ffffc1 	b	73ac <f12+0x27c>
    74ac:	ad468402 	ldp	q2, q1, [x0, #208]
    74b0:	91034001 	add	x1, x0, #0xd0
    74b4:	4f000400 	movi	v0.4s, #0x0
    74b8:	f900841f 	str	xzr, [x0, #264]
    74bc:	ad010762 	stp	q2, q1, [x27, #32]
    74c0:	a94f0002 	ldp	x2, x0, [x0, #240]
    74c4:	f9000f60 	str	x0, [x27, #24]
    74c8:	f9401820 	ldr	x0, [x1, #48]
    74cc:	f9002362 	str	x2, [x27, #64]
    74d0:	f9002760 	str	x0, [x27, #72]
    74d4:	ad000020 	stp	q0, q0, [x1]
    74d8:	3d800820 	str	q0, [x1, #32]
    74dc:	f900183f 	str	xzr, [x1, #48]
    74e0:	17ffffb6 	b	73b8 <f12+0x288>
    74e4:	f0ffffe0 	adrp	x0, 6000 <fwp_rc_dup+0x8c>
    74e8:	91200000 	add	x0, x0, #0x800
    74ec:	940011a1 	bl	bb70 <atexit>
    74f0:	35003900 	cbnz	w0, 7c10 <f12+0xae0>
    74f4:	52800020 	mov	w0, #0x1                   	// #1
    74f8:	b903c740 	str	w0, [x26, #964]
    74fc:	17ffff61 	b	7280 <f12+0x150>
    7500:	d3707c63 	ubfiz	x3, x3, #16, #32
    7504:	52800041 	mov	w1, #0x2                   	// #2
    7508:	aa040078 	orr	x24, x3, x4
    750c:	d2800100 	mov	x0, #0x8                   	// #8
    7510:	97fff6e0 	bl	5090 <fwp_heap_alloc>
    7514:	aa0003fa 	mov	x26, x0
    7518:	911902a0 	add	x0, x21, #0x640
    751c:	f900035f 	str	xzr, [x26]
    7520:	f949d801 	ldr	x1, [x0, #5040]
    7524:	f949ec00 	ldr	x0, [x0, #5080]
    7528:	cb010341 	sub	x1, x26, x1
    752c:	eb00403f 	cmp	x1, x0, lsl #16
    7530:	54000e82 	b.cs	7700 <f12+0x5d0>  // b.hs, b.nlast
    7534:	d2800019 	mov	x25, #0x0                   	// #0
    7538:	911902a2 	add	x2, x21, #0x640
    753c:	d350fc20 	lsr	x0, x1, #16
    7540:	8b000800 	add	x0, x0, x0, lsl #2
    7544:	f949fc43 	ldr	x3, [x2, #5112]
    7548:	d37df002 	lsl	x2, x0, #3
    754c:	8b020060 	add	x0, x3, x2
    7550:	f940101b 	ldr	x27, [x0, #32]
    7554:	b400025b 	cbz	x27, 759c <f12+0x46c>
    7558:	38626862 	ldrb	w2, [x3, x2]
    755c:	7100085f 	cmp	w2, #0x2
    7560:	54000a20 	b.eq	76a4 <f12+0x574>  // b.none
    7564:	7100045f 	cmp	w2, #0x1
    7568:	540001a1 	b.ne	759c <f12+0x46c>  // b.any
    756c:	29430002 	ldp	w2, w0, [x0, #24]
    7570:	92403c21 	and	x1, x1, #0xffff
    7574:	9b027c21 	mul	x1, x1, x2
    7578:	d360fc21 	lsr	x1, x1, #32
    757c:	eb00003f 	cmp	x1, x0
    7580:	540000e2 	b.cs	759c <f12+0x46c>  // b.hs, b.nlast
    7584:	8b01037b 	add	x27, x27, x1
    7588:	39400360 	ldrb	w0, [x27]
    758c:	7103fc1f 	cmp	w0, #0xff
    7590:	54003220 	b.eq	7bd4 <f12+0xaa4>  // b.none
    7594:	52800020 	mov	w0, #0x1                   	// #1
    7598:	39000360 	strb	w0, [x27]
    759c:	b4000239 	cbz	x25, 75e0 <f12+0x4b0>
    75a0:	d3607f04 	lsl	x4, x24, #32
    75a4:	aa1303e0 	mov	x0, x19
    75a8:	f9400665 	ldr	x5, [x19, #8]
    75ac:	aa0403e3 	mov	x3, x4
    75b0:	91002342 	add	x2, x26, #0x8
    75b4:	d2800001 	mov	x1, #0x0                   	// #0
    75b8:	14000005 	b	75cc <f12+0x49c>
    75bc:	f9400405 	ldr	x5, [x0, #8]
    75c0:	ab040023 	adds	x3, x1, x4
    75c4:	91004042 	add	x2, x2, #0x10
    75c8:	54005da6 	b.vs	817c <f12+0x104c>
    75cc:	a9000c45 	stp	x5, x3, [x2]
    75d0:	91000421 	add	x1, x1, #0x1
    75d4:	f9400800 	ldr	x0, [x0, #16]
    75d8:	eb19003f 	cmp	x1, x25
    75dc:	54ffff03 	b.cc	75bc <f12+0x48c>  // b.lo, b.ul, b.last
    75e0:	f9400340 	ldr	x0, [x26]
    75e4:	f100041f 	cmp	x0, #0x1
    75e8:	540008c9 	b.ls	7700 <f12+0x5d0>  // b.plast
    75ec:	d341fc00 	lsr	x0, x0, #1
    75f0:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    75f4:	d100041c 	sub	x28, x0, #0x1
    75f8:	eb01039f 	cmp	x28, x1
    75fc:	54fff448 	b.hi	7484 <f12+0x354>  // b.pmore
    7600:	b400081c 	cbz	x28, 7700 <f12+0x5d0>
    7604:	d1002341 	sub	x1, x26, #0x8
    7608:	91002359 	add	x25, x26, #0x8
    760c:	8b00103b 	add	x27, x1, x0, lsl #4
    7610:	f9400720 	ldr	x0, [x25, #8]
    7614:	f9400f21 	ldr	x1, [x25, #24]
    7618:	fd400320 	ldr	d0, [x25]
    761c:	fd400b21 	ldr	d1, [x25, #16]
    7620:	97fff878 	bl	5800 <w107>
    7624:	a9000720 	stp	x0, x1, [x25]
    7628:	91004339 	add	x25, x25, #0x10
    762c:	eb1b033f 	cmp	x25, x27
    7630:	54ffff01 	b.ne	7610 <f12+0x4e0>  // b.any
    7634:	aa1a03fb 	mov	x27, x26
    7638:	d37ffb99 	lsl	x25, x28, #1
    763c:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7640:	d280001c 	mov	x28, #0x0                   	// #0
    7644:	f8010779 	str	x25, [x27], #16
    7648:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    764c:	aa0403e0 	mov	x0, x4
    7650:	91000b9c 	add	x28, x28, #0x2
    7654:	97fff813 	bl	56a0 <f128.constprop.0>
    7658:	aa0003e4 	mov	x4, x0
    765c:	eb19039f 	cmp	x28, x25
    7660:	54ffff43 	b.cc	7648 <f12+0x518>  // b.lo, b.ul, b.last
    7664:	aa1a03e0 	mov	x0, x26
    7668:	93407f18 	sxtw	x24, w24
    766c:	f90007e4 	str	x4, [sp, #8]
    7670:	97fffe08 	bl	6e90 <fwp_drop4>
    7674:	aa1803e0 	mov	x0, x24
    7678:	97fff512 	bl	4ac0 <fwp_tape_of>
    767c:	f9403019 	ldr	x25, [x0, #96]
    7680:	aa0003e5 	mov	x5, x0
    7684:	f94007e4 	ldr	x4, [sp, #8]
    7688:	b4000479 	cbz	x25, 7714 <f12+0x5e4>
    768c:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7690:	91044000 	add	x0, x0, #0x110
    7694:	97fff308 	bl	42b4 <fwp_trap>
    7698:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    769c:	9107c000 	add	x0, x0, #0x1f0
    76a0:	97fff305 	bl	42b4 <fwp_trap>
    76a4:	72003c3f 	tst	w1, #0xffff
    76a8:	54fff7a1 	b.ne	759c <f12+0x46c>  // b.any
    76ac:	17ffffb7 	b	7588 <f12+0x458>
    76b0:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    76b4:	91070000 	add	x0, x0, #0x1c0
    76b8:	97fff2ff 	bl	42b4 <fwp_trap>
    76bc:	d37ffb3b 	lsl	x27, x25, #1
    76c0:	d3707c63 	ubfiz	x3, x3, #16, #32
    76c4:	91000760 	add	x0, x27, #0x1
    76c8:	52800041 	mov	w1, #0x2                   	// #2
    76cc:	aa040078 	orr	x24, x3, x4
    76d0:	d37df000 	lsl	x0, x0, #3
    76d4:	97fff66f 	bl	5090 <fwp_heap_alloc>
    76d8:	aa0003fa 	mov	x26, x0
    76dc:	911902a1 	add	x1, x21, #0x640
    76e0:	aa0103e0 	mov	x0, x1
    76e4:	f900035b 	str	x27, [x26]
    76e8:	f949d821 	ldr	x1, [x1, #5040]
    76ec:	f949ec00 	ldr	x0, [x0, #5080]
    76f0:	cb010341 	sub	x1, x26, x1
    76f4:	eb00403f 	cmp	x1, x0, lsl #16
    76f8:	54fff203 	b.cc	7538 <f12+0x408>  // b.lo, b.ul, b.last
    76fc:	b5fff539 	cbnz	x25, 75a0 <f12+0x470>
    7700:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7704:	f900035f 	str	xzr, [x26]
    7708:	17ffffd7 	b	7664 <f12+0x534>
    770c:	97fff41e 	bl	4784 <fwp_rc_wide_dup>
    7710:	17fffec8 	b	7230 <f12+0x100>
    7714:	f9000fe4 	str	x4, [sp, #24]
    7718:	97ffee1f 	bl	2f94 <fwp_tape_unlink_scope>
    771c:	a9428cba 	ldp	x26, x3, [x5, #40]
    7720:	f90007e3 	str	x3, [sp, #8]
    7724:	f9401ca3 	ldr	x3, [x5, #56]
    7728:	b90004bf 	str	wzr, [x5, #4]
    772c:	b94000a1 	ldr	w1, [x5]
    7730:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7734:	f9000be3 	str	x3, [sp, #16]
    7738:	a940a4bc 	ldp	x28, x9, [x5, #8]
    773c:	6b00003f 	cmp	w1, w0
    7740:	a941e4a2 	ldp	x2, x25, [x5, #24]
    7744:	f9400fe4 	ldr	x4, [sp, #24]
    7748:	a94418bb 	ldp	x27, x6, [x5, #64]
    774c:	54000108 	b.hi	776c <f12+0x63c>  // b.pmore
    7750:	91018281 	add	x1, x20, #0x60
    7754:	92403f00 	and	x0, x24, #0xffff
    7758:	d1000400 	sub	x0, x0, #0x1
    775c:	f940b023 	ldr	x3, [x1, #352]
    7760:	eb03001f 	cmp	x0, x3
    7764:	5400004a 	b.ge	776c <f12+0x63c>  // b.tcont
    7768:	f900b020 	str	x0, [x1, #352]
    776c:	4f000400 	movi	v0.4s, #0x0
    7770:	91018281 	add	x1, x20, #0x60
    7774:	b0ffffe0 	adrp	x0, 4000 <fwp_tape_buffers_dispose+0xc>
    7778:	91045000 	add	x0, x0, #0x114
    777c:	f9000cbf 	str	xzr, [x5, #24]
    7780:	9101a3e7 	add	x7, sp, #0x68
    7784:	f941c823 	ldr	x3, [x1, #912]
    7788:	3c8080a0 	stur	q0, [x5, #8]
    778c:	a90683e3 	stp	x3, x0, [sp, #104]
    7790:	910203e3 	add	x3, sp, #0x80
    7794:	f94007e0 	ldr	x0, [sp, #8]
    7798:	ad0100a0 	stp	q0, q0, [x5, #32]
    779c:	f9004be0 	str	x0, [sp, #144]
    77a0:	f9400be0 	ldr	x0, [sp, #16]
    77a4:	f9000fe3 	str	x3, [sp, #24]
    77a8:	f90013e7 	str	x7, [sp, #32]
    77ac:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    77b0:	f9003fe3 	str	x3, [sp, #120]
    77b4:	a9086bf9 	stp	x25, x26, [sp, #128]
    77b8:	f9004fe0 	str	x0, [sp, #152]
    77bc:	a90a0bfb 	stp	x27, x2, [sp, #160]
    77c0:	f9005be6 	str	x6, [sp, #176]
    77c4:	f901c827 	str	x7, [x1, #912]
    77c8:	b7f82024 	tbnz	x4, #63, 7bcc <f12+0xa9c>
    77cc:	eb84831f 	cmp	x24, x4, asr #32
    77d0:	540000e0 	b.eq	77ec <f12+0x6bc>  // b.none
    77d4:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    77d8:	91032000 	add	x0, x0, #0xc8
    77dc:	97fff2b6 	bl	42b4 <fwp_trap>
    77e0:	d2800d01 	mov	x1, #0x68                  	// #104
    77e4:	d2800023 	mov	x3, #0x1                   	// #1
    77e8:	17fffec9 	b	730c <f12+0x1dc>
    77ec:	92407c80 	and	x0, x4, #0xffffffff
    77f0:	eb00039f 	cmp	x28, x0
    77f4:	9a80c798 	csinc	x24, x28, x0, gt
    77f8:	eb24413f 	cmp	x9, w4, uxtw
    77fc:	54001f2d 	b.le	7be0 <f12+0xab0>
    7800:	eb1800df 	cmp	x6, x24
    7804:	54001f6a 	b.ge	7bf0 <f12+0xac0>  // b.tcont
    7808:	f10000df 	cmp	x6, #0x0
    780c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7810:	9a9810c6 	csel	x6, x6, x24, ne	// ne = any
    7814:	14000004 	b	7824 <f12+0x6f4>
    7818:	eb0100df 	cmp	x6, x1
    781c:	d37ff8c6 	lsl	x6, x6, #1
    7820:	9a98d0c6 	csel	x6, x6, x24, le
    7824:	eb1800df 	cmp	x6, x24
    7828:	54ffff8b 	b.lt	7818 <f12+0x6e8>  // b.tstop
    782c:	b400365b 	cbz	x27, 7ef4 <f12+0xdc4>
    7830:	aa1b03e0 	mov	x0, x27
    7834:	d37df0c1 	lsl	x1, x6, #3
    7838:	52800062 	mov	w2, #0x3                   	// #3
    783c:	a90293e6 	stp	x6, x4, [sp, #40]
    7840:	97fff201 	bl	4044 <ad_raw_realloc>
    7844:	a94293e6 	ldp	x6, x4, [sp, #40]
    7848:	aa0003fb 	mov	x27, x0
    784c:	b4001d00 	cbz	x0, 7bec <f12+0xabc>
    7850:	f90053fb 	str	x27, [sp, #160]
    7854:	f9005be6 	str	x6, [sp, #176]
    7858:	b5001ad8 	cbnz	x24, 7bb0 <f12+0xa80>
    785c:	b7f800c4 	tbnz	x4, #63, 7874 <f12+0x744>
    7860:	92407c84 	and	x4, x4, #0xffffffff
    7864:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7868:	fc647b60 	ldr	d0, [x27, x4, lsl #3]
    786c:	1e612800 	fadd	d0, d0, d1
    7870:	fc247b60 	str	d0, [x27, x4, lsl #3]
    7874:	d1000700 	sub	x0, x24, #0x1
    7878:	d1000783 	sub	x3, x28, #0x1
    787c:	eb00039f 	cmp	x28, x0
    7880:	540003ec 	b.gt	78fc <f12+0x7cc>
    7884:	fc607b60 	ldr	d0, [x27, x0, lsl #3]
    7888:	1e602008 	fcmp	d0, #0.0
    788c:	54000320 	b.eq	78f0 <f12+0x7c0>  // b.none
    7890:	cb1c0be1 	neg	x1, x28, lsl #2
    7894:	cb1c03e4 	neg	x4, x28
    7898:	8b010322 	add	x2, x25, x1
    789c:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    78a0:	37f80122 	tbnz	w2, #31, 78c4 <f12+0x794>
    78a4:	f94007e5 	ldr	x5, [sp, #8]
    78a8:	93407c42 	sxtw	x2, w2
    78ac:	8b040ca5 	add	x5, x5, x4, lsl #3
    78b0:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    78b4:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    78b8:	1e620802 	fmul	d2, d0, d2
    78bc:	1e622821 	fadd	d1, d1, d2
    78c0:	fc227b61 	str	d1, [x27, x2, lsl #3]
    78c4:	8b010341 	add	x1, x26, x1
    78c8:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    78cc:	37f80121 	tbnz	w1, #31, 78f0 <f12+0x7c0>
    78d0:	f9400be2 	ldr	x2, [sp, #16]
    78d4:	93407c21 	sxtw	x1, w1
    78d8:	8b040c44 	add	x4, x2, x4, lsl #3
    78dc:	fc617b61 	ldr	d1, [x27, x1, lsl #3]
    78e0:	fc607882 	ldr	d2, [x4, x0, lsl #3]
    78e4:	1e620800 	fmul	d0, d0, d2
    78e8:	1e602820 	fadd	d0, d1, d0
    78ec:	fc217b60 	str	d0, [x27, x1, lsl #3]
    78f0:	d1000400 	sub	x0, x0, #0x1
    78f4:	eb00007f 	cmp	x3, x0
    78f8:	54fffc61 	b.ne	7884 <f12+0x754>  // b.any
    78fc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7900:	eb00039f 	cmp	x28, x0
    7904:	540019e8 	b.hi	7c40 <f12+0xb10>  // b.pmore
    7908:	91000780 	add	x0, x28, #0x1
    790c:	52800041 	mov	w1, #0x2                   	// #2
    7910:	d37df000 	lsl	x0, x0, #3
    7914:	97fff5df 	bl	5090 <fwp_heap_alloc>
    7918:	aa0003f8 	mov	x24, x0
    791c:	f800841c 	str	x28, [x0], #8
    7920:	d2800001 	mov	x1, #0x0                   	// #0
    7924:	b40000dc 	cbz	x28, 793c <f12+0x80c>
    7928:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    792c:	f8217802 	str	x2, [x0, x1, lsl #3]
    7930:	91000421 	add	x1, x1, #0x1
    7934:	eb01039f 	cmp	x28, x1
    7938:	54ffff81 	b.ne	7928 <f12+0x7f8>  // b.any
    793c:	91018281 	add	x1, x20, #0x60
    7940:	f94013e2 	ldr	x2, [sp, #32]
    7944:	f941c820 	ldr	x0, [x1, #912]
    7948:	eb02001f 	cmp	x0, x2
    794c:	540041a1 	b.ne	8180 <f12+0x1050>  // b.any
    7950:	f9400fe0 	ldr	x0, [sp, #24]
    7954:	f94037fa 	ldr	x26, [sp, #104]
    7958:	f901c83a 	str	x26, [x1, #912]
    795c:	97fff1ee 	bl	4114 <fwp_tape_buffers_release>
    7960:	911902a2 	add	x2, x21, #0x640
    7964:	f949d841 	ldr	x1, [x2, #5040]
    7968:	f949ec40 	ldr	x0, [x2, #5080]
    796c:	cb010301 	sub	x1, x24, x1
    7970:	eb00403f 	cmp	x1, x0, lsl #16
    7974:	54000322 	b.cs	79d8 <f12+0x8a8>  // b.hs, b.nlast
    7978:	d350fc20 	lsr	x0, x1, #16
    797c:	f949fc43 	ldr	x3, [x2, #5112]
    7980:	8b000800 	add	x0, x0, x0, lsl #2
    7984:	d37df002 	lsl	x2, x0, #3
    7988:	8b020060 	add	x0, x3, x2
    798c:	f9401019 	ldr	x25, [x0, #32]
    7990:	b4000259 	cbz	x25, 79d8 <f12+0x8a8>
    7994:	38626862 	ldrb	w2, [x3, x2]
    7998:	7100085f 	cmp	w2, #0x2
    799c:	54002a00 	b.eq	7edc <f12+0xdac>  // b.none
    79a0:	7100045f 	cmp	w2, #0x1
    79a4:	540001a1 	b.ne	79d8 <f12+0x8a8>  // b.any
    79a8:	29430002 	ldp	w2, w0, [x0, #24]
    79ac:	92403c21 	and	x1, x1, #0xffff
    79b0:	9b027c21 	mul	x1, x1, x2
    79b4:	d360fc21 	lsr	x1, x1, #32
    79b8:	eb00003f 	cmp	x1, x0
    79bc:	540000e2 	b.cs	79d8 <f12+0x8a8>  // b.hs, b.nlast
    79c0:	8b010339 	add	x25, x25, x1
    79c4:	39400320 	ldrb	w0, [x25]
    79c8:	7103fc1f 	cmp	w0, #0xff
    79cc:	54003a80 	b.eq	811c <f12+0xfec>  // b.none
    79d0:	52800020 	mov	w0, #0x1                   	// #1
    79d4:	39000320 	strb	w0, [x25]
    79d8:	eb17035f 	cmp	x26, x23
    79dc:	54003d21 	b.ne	8180 <f12+0x1050>  // b.any
    79e0:	f9402be1 	ldr	x1, [sp, #80]
    79e4:	91018294 	add	x20, x20, #0x60
    79e8:	aa1603e0 	mov	x0, x22
    79ec:	f901ca81 	str	x1, [x20, #912]
    79f0:	97fffbc8 	bl	6910 <fwp_tape_scope_release>
    79f4:	f9400300 	ldr	x0, [x24]
    79f8:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    79fc:	b7f81360 	tbnz	x0, #63, 7c68 <f12+0xb38>
    7a00:	911902a2 	add	x2, x21, #0x640
    7a04:	f949d840 	ldr	x0, [x2, #5040]
    7a08:	f949ec41 	ldr	x1, [x2, #5080]
    7a0c:	cb000300 	sub	x0, x24, x0
    7a10:	eb01401f 	cmp	x0, x1, lsl #16
    7a14:	540012a2 	b.cs	7c68 <f12+0xb38>  // b.hs, b.nlast
    7a18:	d350fc01 	lsr	x1, x0, #16
    7a1c:	f949fc44 	ldr	x4, [x2, #5112]
    7a20:	8b010821 	add	x1, x1, x1, lsl #2
    7a24:	d37df021 	lsl	x1, x1, #3
    7a28:	8b010083 	add	x3, x4, x1
    7a2c:	f9401062 	ldr	x2, [x3, #32]
    7a30:	b40011c2 	cbz	x2, 7c68 <f12+0xb38>
    7a34:	38616881 	ldrb	w1, [x4, x1]
    7a38:	7100083f 	cmp	w1, #0x2
    7a3c:	54001120 	b.eq	7c60 <f12+0xb30>  // b.none
    7a40:	7100043f 	cmp	w1, #0x1
    7a44:	54001121 	b.ne	7c68 <f12+0xb38>  // b.any
    7a48:	29430464 	ldp	w4, w1, [x3, #24]
    7a4c:	92403c00 	and	x0, x0, #0xffff
    7a50:	9b047c00 	mul	x0, x0, x4
    7a54:	d360fc00 	lsr	x0, x0, #32
    7a58:	eb01001f 	cmp	x0, x1
    7a5c:	54001062 	b.cs	7c68 <f12+0xb38>  // b.hs, b.nlast
    7a60:	8b000042 	add	x2, x2, x0
    7a64:	39400040 	ldrb	w0, [x2]
    7a68:	7100041f 	cmp	w0, #0x1
    7a6c:	54000fe1 	b.ne	7c68 <f12+0xb38>  // b.any
    7a70:	aa1803f7 	mov	x23, x24
    7a74:	aa1803f6 	mov	x22, x24
    7a78:	d2800000 	mov	x0, #0x0                   	// #0
    7a7c:	910022c2 	add	x2, x22, #0x8
    7a80:	d2800001 	mov	x1, #0x0                   	// #0
    7a84:	b40001f9 	cbz	x25, 7ac0 <f12+0x990>
    7a88:	b0000023 	adrp	x3, c000 <_IO_stdin_used+0x460>
    7a8c:	91002304 	add	x4, x24, #0x8
    7a90:	fd45b861 	ldr	d1, [x3, #2928]
    7a94:	f9400305 	ldr	x5, [x24]
    7a98:	aa0403e3 	mov	x3, x4
    7a9c:	b7f80de5 	tbnz	x5, #63, 7c58 <f12+0xb28>
    7aa0:	f94002e5 	ldr	x5, [x23]
    7aa4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    7aa8:	b7f80d25 	tbnz	x5, #63, 7c4c <f12+0xb1c>
    7aac:	1e600820 	fmul	d0, d1, d0
    7ab0:	91000421 	add	x1, x1, #0x1
    7ab4:	fc008440 	str	d0, [x2], #8
    7ab8:	eb01033f 	cmp	x25, x1
    7abc:	54fffec1 	b.ne	7a94 <f12+0x964>  // b.any
    7ac0:	97fffcf4 	bl	6e90 <fwp_drop4>
    7ac4:	b4002a53 	cbz	x19, 800c <f12+0xedc>
    7ac8:	aa1303e0 	mov	x0, x19
    7acc:	d2800014 	mov	x20, #0x0                   	// #0
    7ad0:	f9400800 	ldr	x0, [x0, #16]
    7ad4:	91000694 	add	x20, x20, #0x1
    7ad8:	b5ffffc0 	cbnz	x0, 7ad0 <f12+0x9a0>
    7adc:	f94002e0 	ldr	x0, [x23]
    7ae0:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7ae4:	b7f811c0 	tbnz	x0, #63, 7d1c <f12+0xbec>
    7ae8:	911902a1 	add	x1, x21, #0x640
    7aec:	f949d820 	ldr	x0, [x1, #5040]
    7af0:	f949ec22 	ldr	x2, [x1, #5080]
    7af4:	cb0002c0 	sub	x0, x22, x0
    7af8:	eb02401f 	cmp	x0, x2, lsl #16
    7afc:	540010e2 	b.cs	7d18 <f12+0xbe8>  // b.hs, b.nlast
    7b00:	d350fc02 	lsr	x2, x0, #16
    7b04:	d2800503 	mov	x3, #0x28                  	// #40
    7b08:	f949fc24 	ldr	x4, [x1, #5112]
    7b0c:	9b037c42 	mul	x2, x2, x3
    7b10:	8b020083 	add	x3, x4, x2
    7b14:	f9401061 	ldr	x1, [x3, #32]
    7b18:	b4001001 	cbz	x1, 7d18 <f12+0xbe8>
    7b1c:	38626882 	ldrb	w2, [x4, x2]
    7b20:	7100085f 	cmp	w2, #0x2
    7b24:	54000f60 	b.eq	7d10 <f12+0xbe0>  // b.none
    7b28:	7100045f 	cmp	w2, #0x1
    7b2c:	54000f61 	b.ne	7d18 <f12+0xbe8>  // b.any
    7b30:	29430864 	ldp	w4, w2, [x3, #24]
    7b34:	92403c00 	and	x0, x0, #0xffff
    7b38:	9b047c00 	mul	x0, x0, x4
    7b3c:	d360fc00 	lsr	x0, x0, #32
    7b40:	eb02001f 	cmp	x0, x2
    7b44:	54000ea2 	b.cs	7d18 <f12+0xbe8>  // b.hs, b.nlast
    7b48:	8b000021 	add	x1, x1, x0
    7b4c:	3940003c 	ldrb	w28, [x1]
    7b50:	7100079f 	cmp	w28, #0x1
    7b54:	54000e21 	b.ne	7d18 <f12+0xbe8>  // b.any
    7b58:	910022f9 	add	x25, x23, #0x8
    7b5c:	eb14031f 	cmp	x24, x20
    7b60:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    7b64:	b4002218 	cbz	x24, 7fa4 <f12+0xe74>
    7b68:	d37df304 	lsl	x4, x24, #3
    7b6c:	aa1303e1 	mov	x1, x19
    7b70:	910022c3 	add	x3, x22, #0x8
    7b74:	d2800000 	mov	x0, #0x0                   	// #0
    7b78:	14000009 	b	7b9c <f12+0xa6c>
    7b7c:	fc606841 	ldr	d1, [x2, x0]
    7b80:	fd400420 	ldr	d0, [x1, #8]
    7b84:	1e613800 	fsub	d0, d0, d1
    7b88:	fc206b20 	str	d0, [x25, x0]
    7b8c:	91002000 	add	x0, x0, #0x8
    7b90:	f9400821 	ldr	x1, [x1, #16]
    7b94:	eb00009f 	cmp	x4, x0
    7b98:	54000ee0 	b.eq	7d74 <f12+0xc44>  // b.none
    7b9c:	f94002e5 	ldr	x5, [x23]
    7ba0:	aa0303e2 	mov	x2, x3
    7ba4:	b6fffec5 	tbz	x5, #63, 7b7c <f12+0xa4c>
    7ba8:	f9400ac2 	ldr	x2, [x22, #16]
    7bac:	17fffff4 	b	7b7c <f12+0xa4c>
    7bb0:	d37df302 	lsl	x2, x24, #3
    7bb4:	aa1b03e0 	mov	x0, x27
    7bb8:	52800001 	mov	w1, #0x0                   	// #0
    7bbc:	f90017e4 	str	x4, [sp, #40]
    7bc0:	97ffeb08 	bl	27e0 <memset@plt>
    7bc4:	f94017e4 	ldr	x4, [sp, #40]
    7bc8:	17ffff25 	b	785c <f12+0x72c>
    7bcc:	aa1c03f8 	mov	x24, x28
    7bd0:	17ffff0c 	b	7800 <f12+0x6d0>
    7bd4:	aa1b03e0 	mov	x0, x27
    7bd8:	97fff1d7 	bl	4334 <fwp_rc_forget_slot.part.0>
    7bdc:	17fffe6e 	b	7594 <f12+0x464>
    7be0:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7be4:	91050000 	add	x0, x0, #0x140
    7be8:	97fff1b3 	bl	42b4 <fwp_trap>
    7bec:	d280001b 	mov	x27, #0x0                   	// #0
    7bf0:	f100031f 	cmp	x24, #0x0
    7bf4:	fa401b60 	ccmp	x27, #0x0, #0x0, ne	// ne = any
    7bf8:	54ffe301 	b.ne	7858 <f12+0x728>  // b.any
    7bfc:	f9400fe0 	ldr	x0, [sp, #24]
    7c00:	91018294 	add	x20, x20, #0x60
    7c04:	f94037e1 	ldr	x1, [sp, #104]
    7c08:	f901ca81 	str	x1, [x20, #912]
    7c0c:	97fff142 	bl	4114 <fwp_tape_buffers_release>
    7c10:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    7c14:	f947e863 	ldr	x3, [x3, #4048]
    7c18:	d2800262 	mov	x2, #0x13                  	// #19
    7c1c:	d2800021 	mov	x1, #0x1                   	// #1
    7c20:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    7c24:	912ea000 	add	x0, x0, #0xba8
    7c28:	f9400063 	ldr	x3, [x3]
    7c2c:	97ffeb39 	bl	2910 <fwrite@plt>
    7c30:	d2800000 	mov	x0, #0x0                   	// #0
    7c34:	97ffeb43 	bl	2940 <fflush@plt>
    7c38:	52800cc0 	mov	w0, #0x66                  	// #102
    7c3c:	97ffeb51 	bl	2980 <_Exit@plt>
    7c40:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7c44:	91094000 	add	x0, x0, #0x250
    7c48:	97fff19b 	bl	42b4 <fwp_trap>
    7c4c:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7c50:	91098000 	add	x0, x0, #0x260
    7c54:	97fff198 	bl	42b4 <fwp_trap>
    7c58:	f9400b03 	ldr	x3, [x24, #16]
    7c5c:	17ffff91 	b	7aa0 <f12+0x970>
    7c60:	72003c1f 	tst	w0, #0xffff
    7c64:	54fff000 	b.eq	7a64 <f12+0x934>  // b.none
    7c68:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7c6c:	eb00033f 	cmp	x25, x0
    7c70:	54fffe88 	b.hi	7c40 <f12+0xb10>  // b.pmore
    7c74:	91000720 	add	x0, x25, #0x1
    7c78:	52800021 	mov	w1, #0x1                   	// #1
    7c7c:	d37df000 	lsl	x0, x0, #3
    7c80:	97fff504 	bl	5090 <fwp_heap_alloc>
    7c84:	911902a2 	add	x2, x21, #0x640
    7c88:	f9000019 	str	x25, [x0]
    7c8c:	aa0003f7 	mov	x23, x0
    7c90:	aa0003f6 	mov	x22, x0
    7c94:	f949d841 	ldr	x1, [x2, #5040]
    7c98:	f949ec40 	ldr	x0, [x2, #5080]
    7c9c:	cb0102e1 	sub	x1, x23, x1
    7ca0:	eb00403f 	cmp	x1, x0, lsl #16
    7ca4:	54000322 	b.cs	7d08 <f12+0xbd8>  // b.hs, b.nlast
    7ca8:	d350fc20 	lsr	x0, x1, #16
    7cac:	d2800504 	mov	x4, #0x28                  	// #40
    7cb0:	f949fc43 	ldr	x3, [x2, #5112]
    7cb4:	9b047c00 	mul	x0, x0, x4
    7cb8:	8b000062 	add	x2, x3, x0
    7cbc:	f9401054 	ldr	x20, [x2, #32]
    7cc0:	b4000254 	cbz	x20, 7d08 <f12+0xbd8>
    7cc4:	38606860 	ldrb	w0, [x3, x0]
    7cc8:	7100081f 	cmp	w0, #0x2
    7ccc:	54002200 	b.eq	810c <f12+0xfdc>  // b.none
    7cd0:	7100041f 	cmp	w0, #0x1
    7cd4:	540001a1 	b.ne	7d08 <f12+0xbd8>  // b.any
    7cd8:	29430043 	ldp	w3, w0, [x2, #24]
    7cdc:	92403c21 	and	x1, x1, #0xffff
    7ce0:	9b037c21 	mul	x1, x1, x3
    7ce4:	d360fc21 	lsr	x1, x1, #32
    7ce8:	eb00003f 	cmp	x1, x0
    7cec:	540000e2 	b.cs	7d08 <f12+0xbd8>  // b.hs, b.nlast
    7cf0:	8b010294 	add	x20, x20, x1
    7cf4:	39400280 	ldrb	w0, [x20]
    7cf8:	7103fc1f 	cmp	w0, #0xff
    7cfc:	54002020 	b.eq	8100 <f12+0xfd0>  // b.none
    7d00:	52800020 	mov	w0, #0x1                   	// #1
    7d04:	39000280 	strb	w0, [x20]
    7d08:	aa1803e0 	mov	x0, x24
    7d0c:	17ffff5c 	b	7a7c <f12+0x94c>
    7d10:	72003c1f 	tst	w0, #0xffff
    7d14:	54fff1c0 	b.eq	7b4c <f12+0xa1c>  // b.none
    7d18:	b40013d3 	cbz	x19, 7f90 <f12+0xe60>
    7d1c:	aa1303fa 	mov	x26, x19
    7d20:	d2800014 	mov	x20, #0x0                   	// #0
    7d24:	f9400b5a 	ldr	x26, [x26, #16]
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	91000694 	add	x20, x20, #0x1
    7d30:	b5ffffba 	cbnz	x26, 7d24 <f12+0xbf4>
    7d34:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7d38:	eb01029f 	cmp	x20, x1
    7d3c:	54ffba48 	b.hi	7484 <f12+0x354>  // b.pmore
    7d40:	91000800 	add	x0, x0, #0x2
    7d44:	52800041 	mov	w1, #0x2                   	// #2
    7d48:	d37df000 	lsl	x0, x0, #3
    7d4c:	97fff4d1 	bl	5090 <fwp_heap_alloc>
    7d50:	aa1303e1 	mov	x1, x19
    7d54:	aa0003f9 	mov	x25, x0
    7d58:	f9400420 	ldr	x0, [x1, #8]
    7d5c:	f83a7b20 	str	x0, [x25, x26, lsl #3]
    7d60:	9100075a 	add	x26, x26, #0x1
    7d64:	f9400821 	ldr	x1, [x1, #16]
    7d68:	b5ffff81 	cbnz	x1, 7d58 <f12+0xc28>
    7d6c:	5280001c 	mov	w28, #0x0                   	// #0
    7d70:	17ffff7b 	b	7b5c <f12+0xa2c>
    7d74:	b4001f93 	cbz	x19, 8164 <f12+0x1034>
    7d78:	911902a0 	add	x0, x21, #0x640
    7d7c:	aa1303e2 	mov	x2, x19
    7d80:	d280001b 	mov	x27, #0x0                   	// #0
    7d84:	f949ec04 	ldr	x4, [x0, #5080]
    7d88:	f949d807 	ldr	x7, [x0, #5040]
    7d8c:	f949fc06 	ldr	x6, [x0, #5112]
    7d90:	d370bc84 	lsl	x4, x4, #16
    7d94:	14000006 	b	7dac <f12+0xc7c>
    7d98:	f9400842 	ldr	x2, [x2, #16]
    7d9c:	9100077b 	add	x27, x27, #0x1
    7da0:	f100005f 	cmp	x2, #0x0
    7da4:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    7da8:	54000322 	b.cs	7e0c <f12+0xcdc>  // b.hs, b.nlast
    7dac:	cb070040 	sub	x0, x2, x7
    7db0:	eb04001f 	cmp	x0, x4
    7db4:	540002c2 	b.cs	7e0c <f12+0xcdc>  // b.hs, b.nlast
    7db8:	d350fc01 	lsr	x1, x0, #16
    7dbc:	8b010821 	add	x1, x1, x1, lsl #2
    7dc0:	d37df021 	lsl	x1, x1, #3
    7dc4:	8b0100c5 	add	x5, x6, x1
    7dc8:	f94010a3 	ldr	x3, [x5, #32]
    7dcc:	b4000203 	cbz	x3, 7e0c <f12+0xcdc>
    7dd0:	386168c1 	ldrb	w1, [x6, x1]
    7dd4:	7100083f 	cmp	w1, #0x2
    7dd8:	54000880 	b.eq	7ee8 <f12+0xdb8>  // b.none
    7ddc:	7100043f 	cmp	w1, #0x1
    7de0:	54000161 	b.ne	7e0c <f12+0xcdc>  // b.any
    7de4:	294304a8 	ldp	w8, w1, [x5, #24]
    7de8:	92403c00 	and	x0, x0, #0xffff
    7dec:	9b087c00 	mul	x0, x0, x8
    7df0:	d360fc00 	lsr	x0, x0, #32
    7df4:	eb01001f 	cmp	x0, x1
    7df8:	540000a2 	b.cs	7e0c <f12+0xcdc>  // b.hs, b.nlast
    7dfc:	8b000063 	add	x3, x3, x0
    7e00:	39400060 	ldrb	w0, [x3]
    7e04:	7100041f 	cmp	w0, #0x1
    7e08:	54fffc80 	b.eq	7d98 <f12+0xc68>  // b.none
    7e0c:	d280001a 	mov	x26, #0x0                   	// #0
    7e10:	eb1b031f 	cmp	x24, x27
    7e14:	540018e9 	b.ls	8130 <f12+0x1000>  // b.plast
    7e18:	d1002320 	sub	x0, x25, #0x8
    7e1c:	aa1803f4 	mov	x20, x24
    7e20:	911902b7 	add	x23, x21, #0x640
    7e24:	d280001a 	mov	x26, #0x0                   	// #0
    7e28:	f9000be0 	str	x0, [sp, #16]
    7e2c:	9102e3e0 	add	x0, sp, #0xb8
    7e30:	f90007e0 	str	x0, [sp, #8]
    7e34:	14000012 	b	7e7c <f12+0xd4c>
    7e38:	7100045f 	cmp	w2, #0x1
    7e3c:	540001a1 	b.ne	7e70 <f12+0xd40>  // b.any
    7e40:	294308a6 	ldp	w6, w2, [x5, #24]
    7e44:	92403c21 	and	x1, x1, #0xffff
    7e48:	9b067c21 	mul	x1, x1, x6
    7e4c:	d360fc21 	lsr	x1, x1, #32
    7e50:	eb02003f 	cmp	x1, x2
    7e54:	540000e2 	b.cs	7e70 <f12+0xd40>  // b.hs, b.nlast
    7e58:	8b010000 	add	x0, x0, x1
    7e5c:	39400001 	ldrb	w1, [x0]
    7e60:	7103fc3f 	cmp	w1, #0xff
    7e64:	54001840 	b.eq	816c <f12+0x103c>  // b.none
    7e68:	52800021 	mov	w1, #0x1                   	// #1
    7e6c:	39000001 	strb	w1, [x0]
    7e70:	d1000694 	sub	x20, x20, #0x1
    7e74:	eb14037f 	cmp	x27, x20
    7e78:	54000d42 	b.cs	8020 <f12+0xef0>  // b.hs, b.nlast
    7e7c:	a94083e1 	ldp	x1, x0, [sp, #8]
    7e80:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    7e84:	52800020 	mov	w0, #0x1                   	// #1
    7e88:	a90bebe2 	stp	x2, x26, [sp, #184]
    7e8c:	97fff796 	bl	5ce4 <fwp_data.part.0.constprop.0>
    7e90:	aa0003fa 	mov	x26, x0
    7e94:	f949dae1 	ldr	x1, [x23, #5040]
    7e98:	f949eee0 	ldr	x0, [x23, #5080]
    7e9c:	cb010341 	sub	x1, x26, x1
    7ea0:	eb00403f 	cmp	x1, x0, lsl #16
    7ea4:	54fffe62 	b.cs	7e70 <f12+0xd40>  // b.hs, b.nlast
    7ea8:	d350fc20 	lsr	x0, x1, #16
    7eac:	f949fee6 	ldr	x6, [x23, #5112]
    7eb0:	8b000800 	add	x0, x0, x0, lsl #2
    7eb4:	d37df002 	lsl	x2, x0, #3
    7eb8:	8b0200c5 	add	x5, x6, x2
    7ebc:	f94010a0 	ldr	x0, [x5, #32]
    7ec0:	b4fffd80 	cbz	x0, 7e70 <f12+0xd40>
    7ec4:	386268c2 	ldrb	w2, [x6, x2]
    7ec8:	7100085f 	cmp	w2, #0x2
    7ecc:	54fffb61 	b.ne	7e38 <f12+0xd08>  // b.any
    7ed0:	72003c3f 	tst	w1, #0xffff
    7ed4:	54fffce1 	b.ne	7e70 <f12+0xd40>  // b.any
    7ed8:	17ffffe1 	b	7e5c <f12+0xd2c>
    7edc:	72003c3f 	tst	w1, #0xffff
    7ee0:	54ffd7c1 	b.ne	79d8 <f12+0x8a8>  // b.any
    7ee4:	17fffeb8 	b	79c4 <f12+0x894>
    7ee8:	72003c1f 	tst	w0, #0xffff
    7eec:	54fff901 	b.ne	7e0c <f12+0xcdc>  // b.any
    7ef0:	17ffffc4 	b	7e00 <f12+0xcd0>
    7ef4:	d10004c1 	sub	x1, x6, #0x1
    7ef8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7efc:	eb00003f 	cmp	x1, x0
    7f00:	540003c8 	b.hi	7f78 <f12+0xe48>  // b.pmore
    7f04:	b00002c0 	adrp	x0, 60000 <ad_raw_checkpoints+0x2fba0>
    7f08:	d2800003 	mov	x3, #0x0                   	// #0
    7f0c:	91118001 	add	x1, x0, #0x460
    7f10:	14000005 	b	7f24 <f12+0xdf4>
    7f14:	91000463 	add	x3, x3, #0x1
    7f18:	91006021 	add	x1, x1, #0x18
    7f1c:	f140047f 	cmp	x3, #0x1, lsl #12
    7f20:	54000320 	b.eq	7f84 <f12+0xe54>  // b.none
    7f24:	f9400022 	ldr	x2, [x1]
    7f28:	b5ffff62 	cbnz	x2, 7f14 <f12+0xde4>
    7f2c:	91118002 	add	x2, x0, #0x460
    7f30:	d2800307 	mov	x7, #0x18                  	// #24
    7f34:	aa0603e0 	mov	x0, x6
    7f38:	d2800101 	mov	x1, #0x8                   	// #8
    7f3c:	f9001fe4 	str	x4, [sp, #56]
    7f40:	9b070862 	madd	x2, x3, x7, x2
    7f44:	a9029be2 	stp	x2, x6, [sp, #40]
    7f48:	97ffea2a 	bl	27f0 <calloc@plt>
    7f4c:	aa0003fb 	mov	x27, x0
    7f50:	a94313e6 	ldp	x6, x4, [sp, #48]
    7f54:	b4ffe4c0 	cbz	x0, 7bec <f12+0xabc>
    7f58:	aa0003e1 	mov	x1, x0
    7f5c:	d37df0c2 	lsl	x2, x6, #3
    7f60:	f94017e0 	ldr	x0, [sp, #40]
    7f64:	52800063 	mov	w3, #0x3                   	// #3
    7f68:	a90293e6 	stp	x6, x4, [sp, #40]
    7f6c:	97ffebe9 	bl	2f10 <ad_raw_record>
    7f70:	a94293e6 	ldp	x6, x4, [sp, #40]
    7f74:	17fffe37 	b	7850 <f12+0x720>
    7f78:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    7f7c:	9108c000 	add	x0, x0, #0x230
    7f80:	97ffece0 	bl	3300 <ad_raw_fail>
    7f84:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1290>
    7f88:	9138a000 	add	x0, x0, #0xe28
    7f8c:	97ffecdd 	bl	3300 <ad_raw_fail>
    7f90:	52800041 	mov	w1, #0x2                   	// #2
    7f94:	d2800100 	mov	x0, #0x8                   	// #8
    7f98:	97fff43e 	bl	5090 <fwp_heap_alloc>
    7f9c:	aa0003f9 	mov	x25, x0
    7fa0:	5280001c 	mov	w28, #0x0                   	// #0
    7fa4:	d280001a 	mov	x26, #0x0                   	// #0
    7fa8:	7100039f 	cmp	w28, #0x0
    7fac:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    7fb0:	aa1903e0 	mov	x0, x25
    7fb4:	97fff17b 	bl	45a0 <fwp_mem_free>
    7fb8:	aa1603e0 	mov	x0, x22
    7fbc:	97fffbb5 	bl	6e90 <fwp_drop4>
    7fc0:	aa1303e0 	mov	x0, x19
    7fc4:	97fff903 	bl	63d0 <fwp_drop0>
    7fc8:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7fcc:	f947f400 	ldr	x0, [x0, #4072]
    7fd0:	f94067e2 	ldr	x2, [sp, #200]
    7fd4:	f9400001 	ldr	x1, [x0]
    7fd8:	eb010042 	subs	x2, x2, x1
    7fdc:	d2800001 	mov	x1, #0x0                   	// #0
    7fe0:	54000141 	b.ne	8008 <f12+0xed8>  // b.any
    7fe4:	a94d7bfd 	ldp	x29, x30, [sp, #208]
    7fe8:	aa1a03e0 	mov	x0, x26
    7fec:	a94e53f3 	ldp	x19, x20, [sp, #224]
    7ff0:	a94f5bf5 	ldp	x21, x22, [sp, #240]
    7ff4:	a95063f7 	ldp	x23, x24, [sp, #256]
    7ff8:	a9516bf9 	ldp	x25, x26, [sp, #272]
    7ffc:	a95273fb 	ldp	x27, x28, [sp, #288]
    8000:	9104c3ff 	add	sp, sp, #0x130
    8004:	d65f03c0 	ret
    8008:	97ffea02 	bl	2810 <__stack_chk_fail@plt>
    800c:	f94002f8 	ldr	x24, [x23]
    8010:	b7fffc18 	tbnz	x24, #63, 7f90 <f12+0xe60>
    8014:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    8018:	d2800014 	mov	x20, #0x0                   	// #0
    801c:	17fffeb3 	b	7ae8 <f12+0x9b8>
    8020:	d1000701 	sub	x1, x24, #0x1
    8024:	cb180360 	sub	x0, x27, x24
    8028:	eb01037f 	cmp	x27, x1
    802c:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    8030:	8b010000 	add	x0, x0, x1
    8034:	b50007fb 	cbnz	x27, 8130 <f12+0x1000>
    8038:	7100039f 	cmp	w28, #0x0
    803c:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    8040:	b4fffb80 	cbz	x0, 7fb0 <f12+0xe80>
    8044:	d1000414 	sub	x20, x0, #0x1
    8048:	911902b5 	add	x21, x21, #0x640
    804c:	52800038 	mov	w24, #0x1                   	// #1
    8050:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    8054:	52800020 	mov	w0, #0x1                   	// #1
    8058:	f94007e1 	ldr	x1, [sp, #8]
    805c:	a90bebe2 	stp	x2, x26, [sp, #184]
    8060:	97fff721 	bl	5ce4 <fwp_data.part.0.constprop.0>
    8064:	aa0003fa 	mov	x26, x0
    8068:	f949daa1 	ldr	x1, [x21, #5040]
    806c:	f949eea0 	ldr	x0, [x21, #5080]
    8070:	cb010341 	sub	x1, x26, x1
    8074:	eb00403f 	cmp	x1, x0, lsl #16
    8078:	54000302 	b.cs	80d8 <f12+0xfa8>  // b.hs, b.nlast
    807c:	d350fc20 	lsr	x0, x1, #16
    8080:	f949fea3 	ldr	x3, [x21, #5112]
    8084:	8b000800 	add	x0, x0, x0, lsl #2
    8088:	d37df002 	lsl	x2, x0, #3
    808c:	8b020060 	add	x0, x3, x2
    8090:	f940101b 	ldr	x27, [x0, #32]
    8094:	b400023b 	cbz	x27, 80d8 <f12+0xfa8>
    8098:	38626862 	ldrb	w2, [x3, x2]
    809c:	7100085f 	cmp	w2, #0x2
    80a0:	54000240 	b.eq	80e8 <f12+0xfb8>  // b.none
    80a4:	7100045f 	cmp	w2, #0x1
    80a8:	54000181 	b.ne	80d8 <f12+0xfa8>  // b.any
    80ac:	29430002 	ldp	w2, w0, [x0, #24]
    80b0:	92403c21 	and	x1, x1, #0xffff
    80b4:	9b027c21 	mul	x1, x1, x2
    80b8:	d360fc21 	lsr	x1, x1, #32
    80bc:	eb00003f 	cmp	x1, x0
    80c0:	540000c2 	b.cs	80d8 <f12+0xfa8>  // b.hs, b.nlast
    80c4:	8b01037b 	add	x27, x27, x1
    80c8:	39400360 	ldrb	w0, [x27]
    80cc:	7103fc1f 	cmp	w0, #0xff
    80d0:	54000120 	b.eq	80f4 <f12+0xfc4>  // b.none
    80d4:	39000378 	strb	w24, [x27]
    80d8:	d1000694 	sub	x20, x20, #0x1
    80dc:	b100069f 	cmn	x20, #0x1
    80e0:	54fffb81 	b.ne	8050 <f12+0xf20>  // b.any
    80e4:	17ffffb3 	b	7fb0 <f12+0xe80>
    80e8:	72003c3f 	tst	w1, #0xffff
    80ec:	54ffff61 	b.ne	80d8 <f12+0xfa8>  // b.any
    80f0:	17fffff6 	b	80c8 <f12+0xf98>
    80f4:	aa1b03e0 	mov	x0, x27
    80f8:	97fff08f 	bl	4334 <fwp_rc_forget_slot.part.0>
    80fc:	17fffff6 	b	80d4 <f12+0xfa4>
    8100:	aa1403e0 	mov	x0, x20
    8104:	97fff08c 	bl	4334 <fwp_rc_forget_slot.part.0>
    8108:	17fffefe 	b	7d00 <f12+0xbd0>
    810c:	72003c3f 	tst	w1, #0xffff
    8110:	54ffdf20 	b.eq	7cf4 <f12+0xbc4>  // b.none
    8114:	aa1803e0 	mov	x0, x24
    8118:	17fffe59 	b	7a7c <f12+0x94c>
    811c:	aa1903e0 	mov	x0, x25
    8120:	97fff085 	bl	4334 <fwp_rc_forget_slot.part.0>
    8124:	91018280 	add	x0, x20, #0x60
    8128:	f941c81a 	ldr	x26, [x0, #912]
    812c:	17fffe29 	b	79d0 <f12+0x8a0>
    8130:	aa1303e0 	mov	x0, x19
    8134:	d2800001 	mov	x1, #0x0                   	// #0
    8138:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    813c:	91000421 	add	x1, x1, #0x1
    8140:	f9000402 	str	x2, [x0, #8]
    8144:	aa0003e2 	mov	x2, x0
    8148:	f9400800 	ldr	x0, [x0, #16]
    814c:	eb1b003f 	cmp	x1, x27
    8150:	54ffff43 	b.cc	8138 <f12+0x1008>  // b.lo, b.ul, b.last
    8154:	f900085a 	str	x26, [x2, #16]
    8158:	aa1303fa 	mov	x26, x19
    815c:	aa0003f3 	mov	x19, x0
    8160:	17ffff92 	b	7fa8 <f12+0xe78>
    8164:	d280001b 	mov	x27, #0x0                   	// #0
    8168:	17ffff2c 	b	7e18 <f12+0xce8>
    816c:	f9000fe0 	str	x0, [sp, #24]
    8170:	97fff071 	bl	4334 <fwp_rc_forget_slot.part.0>
    8174:	f9400fe0 	ldr	x0, [sp, #24]
    8178:	17ffff3c 	b	7e68 <f12+0xd38>
    817c:	97ffea21 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8180:	97ffe9b8 	bl	2860 <abort@plt>

0000000000008184 <fwp_owned_entry12>:
    8184:	f9400000 	ldr	x0, [x0]
    8188:	17fffbea 	b	7130 <f12>
    818c:	d503201f 	nop

0000000000008190 <e12>:
    8190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8194:	910003fd 	mov	x29, sp
    8198:	f9000bf3 	str	x19, [sp, #16]
    819c:	f9400013 	ldr	x19, [x0]
    81a0:	aa1303e0 	mov	x0, x19
    81a4:	97fff72f 	bl	5e60 <fwp_rc_share>
    81a8:	aa1303e0 	mov	x0, x19
    81ac:	97fffbe1 	bl	7130 <f12>
    81b0:	aa0003f3 	mov	x19, x0
    81b4:	97fff72b 	bl	5e60 <fwp_rc_share>
    81b8:	aa1303e0 	mov	x0, x19
    81bc:	f9400bf3 	ldr	x19, [sp, #16]
    81c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    81c4:	d65f03c0 	ret
    81c8:	d503201f 	nop
    81cc:	d503201f 	nop

00000000000081d0 <fwp_args23>:
    81d0:	7100003f 	cmp	w1, #0x0
    81d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    81d8:	54000041 	b.ne	81e0 <fwp_args23+0x10>  // b.any
    81dc:	d65f03c0 	ret
    81e0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    81e4:	91190042 	add	x2, x2, #0x640
    81e8:	f9400001 	ldr	x1, [x0]
    81ec:	f949d843 	ldr	x3, [x2, #5040]
    81f0:	f949ec40 	ldr	x0, [x2, #5080]
    81f4:	cb030021 	sub	x1, x1, x3
    81f8:	eb00403f 	cmp	x1, x0, lsl #16
    81fc:	54ffff02 	b.cs	81dc <fwp_args23+0xc>  // b.hs, b.nlast
    8200:	d350fc20 	lsr	x0, x1, #16
    8204:	f949fc44 	ldr	x4, [x2, #5112]
    8208:	8b000800 	add	x0, x0, x0, lsl #2
    820c:	d37df002 	lsl	x2, x0, #3
    8210:	8b020083 	add	x3, x4, x2
    8214:	f9401060 	ldr	x0, [x3, #32]
    8218:	b4fffe20 	cbz	x0, 81dc <fwp_args23+0xc>
    821c:	38626882 	ldrb	w2, [x4, x2]
    8220:	7100085f 	cmp	w2, #0x2
    8224:	54000320 	b.eq	8288 <fwp_args23+0xb8>  // b.none
    8228:	7100045f 	cmp	w2, #0x1
    822c:	54fffd81 	b.ne	81dc <fwp_args23+0xc>  // b.any
    8230:	29430864 	ldp	w4, w2, [x3, #24]
    8234:	92403c21 	and	x1, x1, #0xffff
    8238:	9b047c21 	mul	x1, x1, x4
    823c:	d360fc21 	lsr	x1, x1, #32
    8240:	eb02003f 	cmp	x1, x2
    8244:	54fffcc2 	b.cs	81dc <fwp_args23+0xc>  // b.hs, b.nlast
    8248:	8b010000 	add	x0, x0, x1
    824c:	39400001 	ldrb	w1, [x0]
    8250:	34fffc61 	cbz	w1, 81dc <fwp_args23+0xc>
    8254:	900000c2 	adrp	x2, 20000 <__data_start>
    8258:	91018042 	add	x2, x2, #0x60
    825c:	b9413043 	ldr	w3, [x2, #304]
    8260:	350000c3 	cbnz	w3, 8278 <fwp_args23+0xa8>
    8264:	7103f43f 	cmp	w1, #0xfd
    8268:	54000168 	b.hi	8294 <fwp_args23+0xc4>  // b.pmore
    826c:	11000421 	add	w1, w1, #0x1
    8270:	39000001 	strb	w1, [x0]
    8274:	d65f03c0 	ret
    8278:	f940ac43 	ldr	x3, [x2, #344]
    827c:	91000463 	add	x3, x3, #0x1
    8280:	f900ac43 	str	x3, [x2, #344]
    8284:	17fffff8 	b	8264 <fwp_args23+0x94>
    8288:	72003c3f 	tst	w1, #0xffff
    828c:	54fffe00 	b.eq	824c <fwp_args23+0x7c>  // b.none
    8290:	d65f03c0 	ret
    8294:	17fff13c 	b	4784 <fwp_rc_wide_dup>
    8298:	d503201f 	nop
    829c:	d503201f 	nop

00000000000082a0 <fwp_args12>:
    82a0:	7100003f 	cmp	w1, #0x0
    82a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    82a8:	54000041 	b.ne	82b0 <fwp_args12+0x10>  // b.any
    82ac:	d65f03c0 	ret
    82b0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    82b4:	91190042 	add	x2, x2, #0x640
    82b8:	f9400001 	ldr	x1, [x0]
    82bc:	f949d843 	ldr	x3, [x2, #5040]
    82c0:	f949ec40 	ldr	x0, [x2, #5080]
    82c4:	cb030021 	sub	x1, x1, x3
    82c8:	eb00403f 	cmp	x1, x0, lsl #16
    82cc:	54ffff02 	b.cs	82ac <fwp_args12+0xc>  // b.hs, b.nlast
    82d0:	d350fc20 	lsr	x0, x1, #16
    82d4:	f949fc44 	ldr	x4, [x2, #5112]
    82d8:	8b000800 	add	x0, x0, x0, lsl #2
    82dc:	d37df002 	lsl	x2, x0, #3
    82e0:	8b020083 	add	x3, x4, x2
    82e4:	f9401060 	ldr	x0, [x3, #32]
    82e8:	b4fffe20 	cbz	x0, 82ac <fwp_args12+0xc>
    82ec:	38626882 	ldrb	w2, [x4, x2]
    82f0:	7100085f 	cmp	w2, #0x2
    82f4:	54000320 	b.eq	8358 <fwp_args12+0xb8>  // b.none
    82f8:	7100045f 	cmp	w2, #0x1
    82fc:	54fffd81 	b.ne	82ac <fwp_args12+0xc>  // b.any
    8300:	29430864 	ldp	w4, w2, [x3, #24]
    8304:	92403c21 	and	x1, x1, #0xffff
    8308:	9b047c21 	mul	x1, x1, x4
    830c:	d360fc21 	lsr	x1, x1, #32
    8310:	eb02003f 	cmp	x1, x2
    8314:	54fffcc2 	b.cs	82ac <fwp_args12+0xc>  // b.hs, b.nlast
    8318:	8b010000 	add	x0, x0, x1
    831c:	39400001 	ldrb	w1, [x0]
    8320:	34fffc61 	cbz	w1, 82ac <fwp_args12+0xc>
    8324:	900000c2 	adrp	x2, 20000 <__data_start>
    8328:	91018042 	add	x2, x2, #0x60
    832c:	b9413043 	ldr	w3, [x2, #304]
    8330:	350000c3 	cbnz	w3, 8348 <fwp_args12+0xa8>
    8334:	7103f43f 	cmp	w1, #0xfd
    8338:	54000168 	b.hi	8364 <fwp_args12+0xc4>  // b.pmore
    833c:	11000421 	add	w1, w1, #0x1
    8340:	39000001 	strb	w1, [x0]
    8344:	d65f03c0 	ret
    8348:	f940ac43 	ldr	x3, [x2, #344]
    834c:	91000463 	add	x3, x3, #0x1
    8350:	f900ac43 	str	x3, [x2, #344]
    8354:	17fffff8 	b	8334 <fwp_args12+0x94>
    8358:	72003c3f 	tst	w1, #0xffff
    835c:	54fffe00 	b.eq	831c <fwp_args12+0x7c>  // b.none
    8360:	d65f03c0 	ret
    8364:	17fff108 	b	4784 <fwp_rc_wide_dup>
    8368:	d503201f 	nop
    836c:	d503201f 	nop

0000000000008370 <fwp_drop2>:
    8370:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    8374:	910003fd 	mov	x29, sp
    8378:	a9025bf5 	stp	x21, x22, [sp, #32]
    837c:	b0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    8380:	911902d5 	add	x21, x22, #0x640
    8384:	a90153f3 	stp	x19, x20, [sp, #16]
    8388:	aa0003f3 	mov	x19, x0
    838c:	f949daa1 	ldr	x1, [x21, #5040]
    8390:	f949eea0 	ldr	x0, [x21, #5080]
    8394:	cb010261 	sub	x1, x19, x1
    8398:	eb00403f 	cmp	x1, x0, lsl #16
    839c:	54000382 	b.cs	840c <fwp_drop2+0x9c>  // b.hs, b.nlast
    83a0:	d350fc22 	lsr	x2, x1, #16
    83a4:	f949fea3 	ldr	x3, [x21, #5112]
    83a8:	8b020842 	add	x2, x2, x2, lsl #2
    83ac:	d37df042 	lsl	x2, x2, #3
    83b0:	8b020060 	add	x0, x3, x2
    83b4:	f9401014 	ldr	x20, [x0, #32]
    83b8:	b40002b4 	cbz	x20, 840c <fwp_drop2+0x9c>
    83bc:	38626862 	ldrb	w2, [x3, x2]
    83c0:	7100085f 	cmp	w2, #0x2
    83c4:	540002c0 	b.eq	841c <fwp_drop2+0xac>  // b.none
    83c8:	7100045f 	cmp	w2, #0x1
    83cc:	54000201 	b.ne	840c <fwp_drop2+0x9c>  // b.any
    83d0:	29430002 	ldp	w2, w0, [x0, #24]
    83d4:	92403c21 	and	x1, x1, #0xffff
    83d8:	9b027c21 	mul	x1, x1, x2
    83dc:	d360fc21 	lsr	x1, x1, #32
    83e0:	eb00003f 	cmp	x1, x0
    83e4:	54000142 	b.cs	840c <fwp_drop2+0x9c>  // b.hs, b.nlast
    83e8:	8b010294 	add	x20, x20, x1
    83ec:	39400280 	ldrb	w0, [x20]
    83f0:	340000e0 	cbz	w0, 840c <fwp_drop2+0x9c>
    83f4:	7100041f 	cmp	w0, #0x1
    83f8:	540001e0 	b.eq	8434 <fwp_drop2+0xc4>  // b.none
    83fc:	7103fc1f 	cmp	w0, #0xff
    8400:	540007c0 	b.eq	84f8 <fwp_drop2+0x188>  // b.none
    8404:	51000400 	sub	w0, w0, #0x1
    8408:	39000280 	strb	w0, [x20]
    840c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8410:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8414:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8418:	d65f03c0 	ret
    841c:	72003c3f 	tst	w1, #0xffff
    8420:	54fffe60 	b.eq	83ec <fwp_drop2+0x7c>  // b.none
    8424:	a94153f3 	ldp	x19, x20, [sp, #16]
    8428:	a9425bf5 	ldp	x21, x22, [sp, #32]
    842c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8430:	d65f03c0 	ret
    8434:	911902c2 	add	x2, x22, #0x640
    8438:	f9400660 	ldr	x0, [x19, #8]
    843c:	f949d841 	ldr	x1, [x2, #5040]
    8440:	f949ec42 	ldr	x2, [x2, #5080]
    8444:	cb010001 	sub	x1, x0, x1
    8448:	eb02403f 	cmp	x1, x2, lsl #16
    844c:	54000362 	b.cs	84b8 <fwp_drop2+0x148>  // b.hs, b.nlast
    8450:	d350fc22 	lsr	x2, x1, #16
    8454:	8b020842 	add	x2, x2, x2, lsl #2
    8458:	d37df042 	lsl	x2, x2, #3
    845c:	8b020064 	add	x4, x3, x2
    8460:	f9401094 	ldr	x20, [x4, #32]
    8464:	b40002b4 	cbz	x20, 84b8 <fwp_drop2+0x148>
    8468:	38626862 	ldrb	w2, [x3, x2]
    846c:	7100085f 	cmp	w2, #0x2
    8470:	540003e0 	b.eq	84ec <fwp_drop2+0x17c>  // b.none
    8474:	7100045f 	cmp	w2, #0x1
    8478:	54000201 	b.ne	84b8 <fwp_drop2+0x148>  // b.any
    847c:	29430883 	ldp	w3, w2, [x4, #24]
    8480:	92403c21 	and	x1, x1, #0xffff
    8484:	9b037c21 	mul	x1, x1, x3
    8488:	d360fc21 	lsr	x1, x1, #32
    848c:	eb02003f 	cmp	x1, x2
    8490:	54000142 	b.cs	84b8 <fwp_drop2+0x148>  // b.hs, b.nlast
    8494:	8b010294 	add	x20, x20, x1
    8498:	39400281 	ldrb	w1, [x20]
    849c:	340000e1 	cbz	w1, 84b8 <fwp_drop2+0x148>
    84a0:	7100043f 	cmp	w1, #0x1
    84a4:	54000200 	b.eq	84e4 <fwp_drop2+0x174>  // b.none
    84a8:	7103fc3f 	cmp	w1, #0xff
    84ac:	54000640 	b.eq	8574 <fwp_drop2+0x204>  // b.none
    84b0:	51000421 	sub	w1, w1, #0x1
    84b4:	39000281 	strb	w1, [x20]
    84b8:	f9400a74 	ldr	x20, [x19, #16]
    84bc:	aa1303e0 	mov	x0, x19
    84c0:	97fff68c 	bl	5ef0 <fwp_rc_free_arr>
    84c4:	911902c0 	add	x0, x22, #0x640
    84c8:	f949d801 	ldr	x1, [x0, #5040]
    84cc:	f949ec00 	ldr	x0, [x0, #5080]
    84d0:	cb010281 	sub	x1, x20, x1
    84d4:	eb00403f 	cmp	x1, x0, lsl #16
    84d8:	54fff9a2 	b.cs	840c <fwp_drop2+0x9c>  // b.hs, b.nlast
    84dc:	aa1403f3 	mov	x19, x20
    84e0:	17ffffb0 	b	83a0 <fwp_drop2+0x30>
    84e4:	97fff683 	bl	5ef0 <fwp_rc_free_arr>
    84e8:	17fffff4 	b	84b8 <fwp_drop2+0x148>
    84ec:	72003c3f 	tst	w1, #0xffff
    84f0:	54fffe41 	b.ne	84b8 <fwp_drop2+0x148>  // b.any
    84f4:	17ffffe9 	b	8498 <fwp_drop2+0x128>
    84f8:	ca544681 	eor	x1, x20, x20, lsr #17
    84fc:	911902c0 	add	x0, x22, #0x640
    8500:	ca412421 	eor	x1, x1, x1, lsr #9
    8504:	92401c21 	and	x1, x1, #0xff
    8508:	910a2422 	add	x2, x1, #0x289
    850c:	8b010c01 	add	x1, x0, x1, lsl #3
    8510:	8b020c02 	add	x2, x0, x2, lsl #3
    8514:	f94a2420 	ldr	x0, [x1, #5192]
    8518:	b50000a0 	cbnz	x0, 852c <fwp_drop2+0x1bc>
    851c:	14000013 	b	8568 <fwp_drop2+0x1f8>
    8520:	91004002 	add	x2, x0, #0x10
    8524:	f9400800 	ldr	x0, [x0, #16]
    8528:	b4000200 	cbz	x0, 8568 <fwp_drop2+0x1f8>
    852c:	f9400001 	ldr	x1, [x0]
    8530:	eb14003f 	cmp	x1, x20
    8534:	54ffff61 	b.ne	8520 <fwp_drop2+0x1b0>  // b.any
    8538:	f9400041 	ldr	x1, [x2]
    853c:	f9400420 	ldr	x0, [x1, #8]
    8540:	d1000400 	sub	x0, x0, #0x1
    8544:	f9000420 	str	x0, [x1, #8]
    8548:	f103f81f 	cmp	x0, #0xfe
    854c:	54fff601 	b.ne	840c <fwp_drop2+0x9c>  // b.any
    8550:	39400280 	ldrb	w0, [x20]
    8554:	7103fc1f 	cmp	w0, #0xff
    8558:	54000460 	b.eq	85e4 <fwp_drop2+0x274>  // b.none
    855c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8560:	39000280 	strb	w0, [x20]
    8564:	17ffffaa 	b	840c <fwp_drop2+0x9c>
    8568:	f0000000 	adrp	x0, b000 <fwp_main_thread+0x1290>
    856c:	913be000 	add	x0, x0, #0xef8
    8570:	97ffef51 	bl	42b4 <fwp_trap>
    8574:	ca544680 	eor	x0, x20, x20, lsr #17
    8578:	911902c1 	add	x1, x22, #0x640
    857c:	ca402400 	eor	x0, x0, x0, lsr #9
    8580:	92401c00 	and	x0, x0, #0xff
    8584:	910a2402 	add	x2, x0, #0x289
    8588:	8b000c20 	add	x0, x1, x0, lsl #3
    858c:	8b020c22 	add	x2, x1, x2, lsl #3
    8590:	f94a2400 	ldr	x0, [x0, #5192]
    8594:	b50000a0 	cbnz	x0, 85a8 <fwp_drop2+0x238>
    8598:	17fffff4 	b	8568 <fwp_drop2+0x1f8>
    859c:	91004002 	add	x2, x0, #0x10
    85a0:	f9400800 	ldr	x0, [x0, #16]
    85a4:	b4fffe20 	cbz	x0, 8568 <fwp_drop2+0x1f8>
    85a8:	f9400001 	ldr	x1, [x0]
    85ac:	eb14003f 	cmp	x1, x20
    85b0:	54ffff61 	b.ne	859c <fwp_drop2+0x22c>  // b.any
    85b4:	f9400041 	ldr	x1, [x2]
    85b8:	f9400420 	ldr	x0, [x1, #8]
    85bc:	d1000400 	sub	x0, x0, #0x1
    85c0:	f9000420 	str	x0, [x1, #8]
    85c4:	f103f81f 	cmp	x0, #0xfe
    85c8:	54fff781 	b.ne	84b8 <fwp_drop2+0x148>  // b.any
    85cc:	39400280 	ldrb	w0, [x20]
    85d0:	7103fc1f 	cmp	w0, #0xff
    85d4:	540000e0 	b.eq	85f0 <fwp_drop2+0x280>  // b.none
    85d8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    85dc:	39000280 	strb	w0, [x20]
    85e0:	17ffffb6 	b	84b8 <fwp_drop2+0x148>
    85e4:	aa1403e0 	mov	x0, x20
    85e8:	97ffef53 	bl	4334 <fwp_rc_forget_slot.part.0>
    85ec:	17ffffdc 	b	855c <fwp_drop2+0x1ec>
    85f0:	aa1403e0 	mov	x0, x20
    85f4:	97ffef50 	bl	4334 <fwp_rc_forget_slot.part.0>
    85f8:	17fffff8 	b	85d8 <fwp_drop2+0x268>
    85fc:	d503201f 	nop

0000000000008600 <fwp_arg_drop23>:
    8600:	7100003f 	cmp	w1, #0x0
    8604:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8608:	54000041 	b.ne	8610 <fwp_arg_drop23+0x10>  // b.any
    860c:	d65f03c0 	ret
    8610:	f9400000 	ldr	x0, [x0]
    8614:	17ffff57 	b	8370 <fwp_drop2>
    8618:	d503201f 	nop
    861c:	d503201f 	nop

0000000000008620 <f23>:
    8620:	d10203ff 	sub	sp, sp, #0x80
    8624:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    8628:	f947f421 	ldr	x1, [x1, #4072]
    862c:	a9027bfd 	stp	x29, x30, [sp, #32]
    8630:	910083fd 	add	x29, sp, #0x20
    8634:	a9045bf5 	stp	x21, x22, [sp, #64]
    8638:	b0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    863c:	911902a3 	add	x3, x21, #0x640
    8640:	a90353f3 	stp	x19, x20, [sp, #48]
    8644:	aa0003f6 	mov	x22, x0
    8648:	a90563f7 	stp	x23, x24, [sp, #80]
    864c:	a9066bf9 	stp	x25, x26, [sp, #96]
    8650:	f949ec62 	ldr	x2, [x3, #5080]
    8654:	f9400024 	ldr	x4, [x1]
    8658:	f9000fe4 	str	x4, [sp, #24]
    865c:	d2800004 	mov	x4, #0x0                   	// #0
    8660:	f949d861 	ldr	x1, [x3, #5040]
    8664:	d370bc42 	lsl	x2, x2, #16
    8668:	b4001920 	cbz	x0, 898c <f23+0x36c>
    866c:	f9400817 	ldr	x23, [x0, #16]
    8670:	cb0102e1 	sub	x1, x23, x1
    8674:	eb02003f 	cmp	x1, x2
    8678:	540003e2 	b.cs	86f4 <f23+0xd4>  // b.hs, b.nlast
    867c:	f949fc60 	ldr	x0, [x3, #5112]
    8680:	d350fc22 	lsr	x2, x1, #16
    8684:	8b020842 	add	x2, x2, x2, lsl #2
    8688:	8b020c02 	add	x2, x0, x2, lsl #3
    868c:	f9401040 	ldr	x0, [x2, #32]
    8690:	b4000320 	cbz	x0, 86f4 <f23+0xd4>
    8694:	39400043 	ldrb	w3, [x2]
    8698:	7100087f 	cmp	w3, #0x2
    869c:	540015e0 	b.eq	8958 <f23+0x338>  // b.none
    86a0:	7100047f 	cmp	w3, #0x1
    86a4:	54000241 	b.ne	86ec <f23+0xcc>  // b.any
    86a8:	29430843 	ldp	w3, w2, [x2, #24]
    86ac:	92403c21 	and	x1, x1, #0xffff
    86b0:	9b037c21 	mul	x1, x1, x3
    86b4:	d360fc21 	lsr	x1, x1, #32
    86b8:	eb02003f 	cmp	x1, x2
    86bc:	54000182 	b.cs	86ec <f23+0xcc>  // b.hs, b.nlast
    86c0:	8b010000 	add	x0, x0, x1
    86c4:	39400001 	ldrb	w1, [x0]
    86c8:	34000121 	cbz	w1, 86ec <f23+0xcc>
    86cc:	900000c2 	adrp	x2, 20000 <__data_start>
    86d0:	91018042 	add	x2, x2, #0x60
    86d4:	b9413043 	ldr	w3, [x2, #304]
    86d8:	35001463 	cbnz	w3, 8964 <f23+0x344>
    86dc:	7103f43f 	cmp	w1, #0xfd
    86e0:	54001888 	b.hi	89f0 <f23+0x3d0>  // b.pmore
    86e4:	11000421 	add	w1, w1, #0x1
    86e8:	39000001 	strb	w1, [x0]
    86ec:	d2800002 	mov	x2, #0x0                   	// #0
    86f0:	b40000f6 	cbz	x22, 870c <f23+0xec>
    86f4:	aa1603e1 	mov	x1, x22
    86f8:	d2800002 	mov	x2, #0x0                   	// #0
    86fc:	d503201f 	nop
    8700:	f9400821 	ldr	x1, [x1, #16]
    8704:	91000442 	add	x2, x2, #0x1
    8708:	b5ffffc1 	cbnz	x1, 8700 <f23+0xe0>
    870c:	b4001477 	cbz	x23, 8998 <f23+0x378>
    8710:	aa1703e1 	mov	x1, x23
    8714:	d2800003 	mov	x3, #0x0                   	// #0
    8718:	f9400821 	ldr	x1, [x1, #16]
    871c:	91000463 	add	x3, x3, #0x1
    8720:	b5ffffc1 	cbnz	x1, 8718 <f23+0xf8>
    8724:	eb02007f 	cmp	x3, x2
    8728:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    872c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    8730:	eb00027f 	cmp	x19, x0
    8734:	540010a8 	b.hi	8948 <f23+0x328>  // b.pmore
    8738:	d37ffa74 	lsl	x20, x19, #1
    873c:	52800041 	mov	w1, #0x2                   	// #2
    8740:	91000680 	add	x0, x20, #0x1
    8744:	d37df000 	lsl	x0, x0, #3
    8748:	97fff252 	bl	5090 <fwp_heap_alloc>
    874c:	aa0003f8 	mov	x24, x0
    8750:	911902a1 	add	x1, x21, #0x640
    8754:	aa0103e0 	mov	x0, x1
    8758:	f9000314 	str	x20, [x24]
    875c:	f949d821 	ldr	x1, [x1, #5040]
    8760:	f949ec00 	ldr	x0, [x0, #5080]
    8764:	cb010301 	sub	x1, x24, x1
    8768:	eb00403f 	cmp	x1, x0, lsl #16
    876c:	54000342 	b.cs	87d4 <f23+0x1b4>  // b.hs, b.nlast
    8770:	911902a2 	add	x2, x21, #0x640
    8774:	d350fc20 	lsr	x0, x1, #16
    8778:	8b000800 	add	x0, x0, x0, lsl #2
    877c:	f949fc43 	ldr	x3, [x2, #5112]
    8780:	d37df002 	lsl	x2, x0, #3
    8784:	8b020060 	add	x0, x3, x2
    8788:	f9401014 	ldr	x20, [x0, #32]
    878c:	b4000254 	cbz	x20, 87d4 <f23+0x1b4>
    8790:	38626862 	ldrb	w2, [x3, x2]
    8794:	7100085f 	cmp	w2, #0x2
    8798:	54000ee0 	b.eq	8974 <f23+0x354>  // b.none
    879c:	7100045f 	cmp	w2, #0x1
    87a0:	540001a1 	b.ne	87d4 <f23+0x1b4>  // b.any
    87a4:	29430002 	ldp	w2, w0, [x0, #24]
    87a8:	92403c21 	and	x1, x1, #0xffff
    87ac:	9b027c21 	mul	x1, x1, x2
    87b0:	d360fc21 	lsr	x1, x1, #32
    87b4:	eb00003f 	cmp	x1, x0
    87b8:	540000e2 	b.cs	87d4 <f23+0x1b4>  // b.hs, b.nlast
    87bc:	8b010294 	add	x20, x20, x1
    87c0:	39400280 	ldrb	w0, [x20]
    87c4:	7103fc1f 	cmp	w0, #0xff
    87c8:	54001180 	b.eq	89f8 <f23+0x3d8>  // b.none
    87cc:	52800020 	mov	w0, #0x1                   	// #1
    87d0:	39000280 	strb	w0, [x20]
    87d4:	b4000253 	cbz	x19, 881c <f23+0x1fc>
    87d8:	8b131313 	add	x19, x24, x19, lsl #4
    87dc:	aa1803f4 	mov	x20, x24
    87e0:	aa1603fa 	mov	x26, x22
    87e4:	aa1703f9 	mov	x25, x23
    87e8:	f9400723 	ldr	x3, [x25, #8]
    87ec:	f9400742 	ldr	x2, [x26, #8]
    87f0:	f9400861 	ldr	x1, [x3, #16]
    87f4:	f9400840 	ldr	x0, [x2, #16]
    87f8:	fd400461 	ldr	d1, [x3, #8]
    87fc:	fd400440 	ldr	d0, [x2, #8]
    8800:	97fff400 	bl	5800 <w107>
    8804:	f9000680 	str	x0, [x20, #8]
    8808:	f8010e81 	str	x1, [x20, #16]!
    880c:	f9400b39 	ldr	x25, [x25, #16]
    8810:	f9400b5a 	ldr	x26, [x26, #16]
    8814:	eb14027f 	cmp	x19, x20
    8818:	54fffe81 	b.ne	87e8 <f23+0x1c8>  // b.any
    881c:	aa1703e0 	mov	x0, x23
    8820:	97fffed4 	bl	8370 <fwp_drop2>
    8824:	aa1603e0 	mov	x0, x22
    8828:	97fffed2 	bl	8370 <fwp_drop2>
    882c:	f9400316 	ldr	x22, [x24]
    8830:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8834:	b4000236 	cbz	x22, 8878 <f23+0x258>
    8838:	fd003be8 	str	d8, [sp, #112]
    883c:	2f00e408 	movi	d8, #0x0
    8840:	91002319 	add	x25, x24, #0x8
    8844:	91004317 	add	x23, x24, #0x10
    8848:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    884c:	d2800013 	mov	x19, #0x0                   	// #0
    8850:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8854:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    8858:	91000a73 	add	x19, x19, #0x2
    885c:	1e602908 	fadd	d8, d8, d0
    8860:	97fff390 	bl	56a0 <f128.constprop.0>
    8864:	aa0003f4 	mov	x20, x0
    8868:	eb1302df 	cmp	x22, x19
    886c:	54ffff28 	b.hi	8850 <f23+0x230>  // b.pmore
    8870:	9e660116 	fmov	x22, d8
    8874:	fd403be8 	ldr	d8, [sp, #112]
    8878:	911902b5 	add	x21, x21, #0x640
    887c:	aa1803e0 	mov	x0, x24
    8880:	97fff984 	bl	6e90 <fwp_drop4>
    8884:	a900d3f6 	stp	x22, x20, [sp, #8]
    8888:	910023e1 	add	x1, sp, #0x8
    888c:	52800000 	mov	w0, #0x0                   	// #0
    8890:	97fff515 	bl	5ce4 <fwp_data.part.0.constprop.0>
    8894:	f949daa1 	ldr	x1, [x21, #5040]
    8898:	aa0003f3 	mov	x19, x0
    889c:	f949eea0 	ldr	x0, [x21, #5080]
    88a0:	cb010261 	sub	x1, x19, x1
    88a4:	eb00403f 	cmp	x1, x0, lsl #16
    88a8:	54000322 	b.cs	890c <f23+0x2ec>  // b.hs, b.nlast
    88ac:	d350fc22 	lsr	x2, x1, #16
    88b0:	f949fea3 	ldr	x3, [x21, #5112]
    88b4:	8b020842 	add	x2, x2, x2, lsl #2
    88b8:	d37df042 	lsl	x2, x2, #3
    88bc:	8b020060 	add	x0, x3, x2
    88c0:	f9401014 	ldr	x20, [x0, #32]
    88c4:	b4000254 	cbz	x20, 890c <f23+0x2ec>
    88c8:	38626862 	ldrb	w2, [x3, x2]
    88cc:	7100085f 	cmp	w2, #0x2
    88d0:	54000580 	b.eq	8980 <f23+0x360>  // b.none
    88d4:	7100045f 	cmp	w2, #0x1
    88d8:	540001a1 	b.ne	890c <f23+0x2ec>  // b.any
    88dc:	29430002 	ldp	w2, w0, [x0, #24]
    88e0:	92403c21 	and	x1, x1, #0xffff
    88e4:	9b027c21 	mul	x1, x1, x2
    88e8:	d360fc21 	lsr	x1, x1, #32
    88ec:	eb00003f 	cmp	x1, x0
    88f0:	540000e2 	b.cs	890c <f23+0x2ec>  // b.hs, b.nlast
    88f4:	8b010294 	add	x20, x20, x1
    88f8:	39400280 	ldrb	w0, [x20]
    88fc:	7103fc1f 	cmp	w0, #0xff
    8900:	54000820 	b.eq	8a04 <f23+0x3e4>  // b.none
    8904:	52800020 	mov	w0, #0x1                   	// #1
    8908:	39000280 	strb	w0, [x20]
    890c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8910:	f947f400 	ldr	x0, [x0, #4072]
    8914:	f9400fe2 	ldr	x2, [sp, #24]
    8918:	f9400001 	ldr	x1, [x0]
    891c:	eb010042 	subs	x2, x2, x1
    8920:	d2800001 	mov	x1, #0x0                   	// #0
    8924:	540007a1 	b.ne	8a18 <f23+0x3f8>  // b.any
    8928:	a9427bfd 	ldp	x29, x30, [sp, #32]
    892c:	aa1303e0 	mov	x0, x19
    8930:	a94353f3 	ldp	x19, x20, [sp, #48]
    8934:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8938:	a94563f7 	ldp	x23, x24, [sp, #80]
    893c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8940:	910203ff 	add	sp, sp, #0x80
    8944:	d65f03c0 	ret
    8948:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    894c:	91088000 	add	x0, x0, #0x220
    8950:	fd003be8 	str	d8, [sp, #112]
    8954:	97ffee58 	bl	42b4 <fwp_trap>
    8958:	72003c3f 	tst	w1, #0xffff
    895c:	54ffec81 	b.ne	86ec <f23+0xcc>  // b.any
    8960:	17ffff59 	b	86c4 <f23+0xa4>
    8964:	f940ac43 	ldr	x3, [x2, #344]
    8968:	91000463 	add	x3, x3, #0x1
    896c:	f900ac43 	str	x3, [x2, #344]
    8970:	17ffff5b 	b	86dc <f23+0xbc>
    8974:	72003c3f 	tst	w1, #0xffff
    8978:	54fff2e1 	b.ne	87d4 <f23+0x1b4>  // b.any
    897c:	17ffff91 	b	87c0 <f23+0x1a0>
    8980:	72003c3f 	tst	w1, #0xffff
    8984:	54fffc41 	b.ne	890c <f23+0x2ec>  // b.any
    8988:	17ffffdc 	b	88f8 <f23+0x2d8>
    898c:	cb0103e1 	neg	x1, x1
    8990:	eb02003f 	cmp	x1, x2
    8994:	540001e3 	b.cc	89d0 <f23+0x3b0>  // b.lo, b.ul, b.last
    8998:	52800041 	mov	w1, #0x2                   	// #2
    899c:	d2800100 	mov	x0, #0x8                   	// #8
    89a0:	97fff1bc 	bl	5090 <fwp_heap_alloc>
    89a4:	aa0003f8 	mov	x24, x0
    89a8:	911902a0 	add	x0, x21, #0x640
    89ac:	f900031f 	str	xzr, [x24]
    89b0:	f949d801 	ldr	x1, [x0, #5040]
    89b4:	f949ec00 	ldr	x0, [x0, #5080]
    89b8:	cb010301 	sub	x1, x24, x1
    89bc:	eb00403f 	cmp	x1, x0, lsl #16
    89c0:	54000282 	b.cs	8a10 <f23+0x3f0>  // b.hs, b.nlast
    89c4:	d2800013 	mov	x19, #0x0                   	// #0
    89c8:	d2800017 	mov	x23, #0x0                   	// #0
    89cc:	17ffff69 	b	8770 <f23+0x150>
    89d0:	f949fc62 	ldr	x2, [x3, #5112]
    89d4:	d350fc20 	lsr	x0, x1, #16
    89d8:	8b000800 	add	x0, x0, x0, lsl #2
    89dc:	8b000c42 	add	x2, x2, x0, lsl #3
    89e0:	f9401040 	ldr	x0, [x2, #32]
    89e4:	b4fffda0 	cbz	x0, 8998 <f23+0x378>
    89e8:	d2800017 	mov	x23, #0x0                   	// #0
    89ec:	17ffff2a 	b	8694 <f23+0x74>
    89f0:	97ffef65 	bl	4784 <fwp_rc_wide_dup>
    89f4:	17ffff3e 	b	86ec <f23+0xcc>
    89f8:	aa1403e0 	mov	x0, x20
    89fc:	97ffee4e 	bl	4334 <fwp_rc_forget_slot.part.0>
    8a00:	17ffff73 	b	87cc <f23+0x1ac>
    8a04:	aa1403e0 	mov	x0, x20
    8a08:	97ffee4b 	bl	4334 <fwp_rc_forget_slot.part.0>
    8a0c:	17ffffbe 	b	8904 <f23+0x2e4>
    8a10:	d2800017 	mov	x23, #0x0                   	// #0
    8a14:	17ffff82 	b	881c <f23+0x1fc>
    8a18:	fd003be8 	str	d8, [sp, #112]
    8a1c:	97ffe77d 	bl	2810 <__stack_chk_fail@plt>

0000000000008a20 <fwp_owned_entry23>:
    8a20:	f9400000 	ldr	x0, [x0]
    8a24:	17fffeff 	b	8620 <f23>
    8a28:	d503201f 	nop
    8a2c:	d503201f 	nop

0000000000008a30 <e23>:
    8a30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8a34:	910003fd 	mov	x29, sp
    8a38:	f9000bf3 	str	x19, [sp, #16]
    8a3c:	f9400013 	ldr	x19, [x0]
    8a40:	aa1303e0 	mov	x0, x19
    8a44:	97fff507 	bl	5e60 <fwp_rc_share>
    8a48:	aa1303e0 	mov	x0, x19
    8a4c:	97fffef5 	bl	8620 <f23>
    8a50:	aa0003f3 	mov	x19, x0
    8a54:	97fff503 	bl	5e60 <fwp_rc_share>
    8a58:	aa1303e0 	mov	x0, x19
    8a5c:	f9400bf3 	ldr	x19, [sp, #16]
    8a60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8a64:	d65f03c0 	ret
    8a68:	d503201f 	nop
    8a6c:	d503201f 	nop

0000000000008a70 <fwp_caps12>:
    8a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8a74:	910003fd 	mov	x29, sp
    8a78:	f9000bf3 	str	x19, [sp, #16]
    8a7c:	aa0003f3 	mov	x19, x0
    8a80:	b9400400 	ldr	w0, [x0, #4]
    8a84:	340004a0 	cbz	w0, 8b18 <fwp_caps12+0xa8>
    8a88:	f9400660 	ldr	x0, [x19, #8]
    8a8c:	350004e1 	cbnz	w1, 8b28 <fwp_caps12+0xb8>
    8a90:	97fff650 	bl	63d0 <fwp_drop0>
    8a94:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8a98:	91190042 	add	x2, x2, #0x640
    8a9c:	f949d840 	ldr	x0, [x2, #5040]
    8aa0:	f949ec41 	ldr	x1, [x2, #5080]
    8aa4:	cb000260 	sub	x0, x19, x0
    8aa8:	eb01401f 	cmp	x0, x1, lsl #16
    8aac:	54000382 	b.cs	8b1c <fwp_caps12+0xac>  // b.hs, b.nlast
    8ab0:	d350fc01 	lsr	x1, x0, #16
    8ab4:	f949fc44 	ldr	x4, [x2, #5112]
    8ab8:	8b010821 	add	x1, x1, x1, lsl #2
    8abc:	d37df021 	lsl	x1, x1, #3
    8ac0:	8b010083 	add	x3, x4, x1
    8ac4:	f9401062 	ldr	x2, [x3, #32]
    8ac8:	b40002a2 	cbz	x2, 8b1c <fwp_caps12+0xac>
    8acc:	38616881 	ldrb	w1, [x4, x1]
    8ad0:	7100083f 	cmp	w1, #0x2
    8ad4:	54000740 	b.eq	8bbc <fwp_caps12+0x14c>  // b.none
    8ad8:	7100043f 	cmp	w1, #0x1
    8adc:	54000201 	b.ne	8b1c <fwp_caps12+0xac>  // b.any
    8ae0:	29430464 	ldp	w4, w1, [x3, #24]
    8ae4:	92403c00 	and	x0, x0, #0xffff
    8ae8:	9b047c00 	mul	x0, x0, x4
    8aec:	d360fc00 	lsr	x0, x0, #32
    8af0:	eb01001f 	cmp	x0, x1
    8af4:	54000142 	b.cs	8b1c <fwp_caps12+0xac>  // b.hs, b.nlast
    8af8:	8b000042 	add	x2, x2, x0
    8afc:	39400040 	ldrb	w0, [x2]
    8b00:	7100041f 	cmp	w0, #0x1
    8b04:	540000c1 	b.ne	8b1c <fwp_caps12+0xac>  // b.any
    8b08:	aa1303e0 	mov	x0, x19
    8b0c:	f9400bf3 	ldr	x19, [sp, #16]
    8b10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8b14:	17ffeea3 	b	45a0 <fwp_mem_free>
    8b18:	34fffbe1 	cbz	w1, 8a94 <fwp_caps12+0x24>
    8b1c:	f9400bf3 	ldr	x19, [sp, #16]
    8b20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8b24:	d65f03c0 	ret
    8b28:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8b2c:	91190042 	add	x2, x2, #0x640
    8b30:	f949d843 	ldr	x3, [x2, #5040]
    8b34:	f949ec41 	ldr	x1, [x2, #5080]
    8b38:	cb030000 	sub	x0, x0, x3
    8b3c:	eb01401f 	cmp	x0, x1, lsl #16
    8b40:	54fffee2 	b.cs	8b1c <fwp_caps12+0xac>  // b.hs, b.nlast
    8b44:	d350fc01 	lsr	x1, x0, #16
    8b48:	f949fc44 	ldr	x4, [x2, #5112]
    8b4c:	8b010821 	add	x1, x1, x1, lsl #2
    8b50:	d37df021 	lsl	x1, x1, #3
    8b54:	8b010083 	add	x3, x4, x1
    8b58:	f9401062 	ldr	x2, [x3, #32]
    8b5c:	b4fffe02 	cbz	x2, 8b1c <fwp_caps12+0xac>
    8b60:	38616881 	ldrb	w1, [x4, x1]
    8b64:	7100083f 	cmp	w1, #0x2
    8b68:	54000300 	b.eq	8bc8 <fwp_caps12+0x158>  // b.none
    8b6c:	7100043f 	cmp	w1, #0x1
    8b70:	54fffd61 	b.ne	8b1c <fwp_caps12+0xac>  // b.any
    8b74:	92403c01 	and	x1, x0, #0xffff
    8b78:	29430064 	ldp	w4, w0, [x3, #24]
    8b7c:	9b047c21 	mul	x1, x1, x4
    8b80:	d360fc21 	lsr	x1, x1, #32
    8b84:	eb00003f 	cmp	x1, x0
    8b88:	54fffca2 	b.cs	8b1c <fwp_caps12+0xac>  // b.hs, b.nlast
    8b8c:	8b010042 	add	x2, x2, x1
    8b90:	39400040 	ldrb	w0, [x2]
    8b94:	34fffc40 	cbz	w0, 8b1c <fwp_caps12+0xac>
    8b98:	900000c1 	adrp	x1, 20000 <__data_start>
    8b9c:	91018021 	add	x1, x1, #0x60
    8ba0:	b9413023 	ldr	w3, [x1, #304]
    8ba4:	35000183 	cbnz	w3, 8bd4 <fwp_caps12+0x164>
    8ba8:	7103f41f 	cmp	w0, #0xfd
    8bac:	540001c8 	b.hi	8be4 <fwp_caps12+0x174>  // b.pmore
    8bb0:	11000400 	add	w0, w0, #0x1
    8bb4:	39000040 	strb	w0, [x2]
    8bb8:	17ffffd9 	b	8b1c <fwp_caps12+0xac>
    8bbc:	72003c1f 	tst	w0, #0xffff
    8bc0:	54fffae1 	b.ne	8b1c <fwp_caps12+0xac>  // b.any
    8bc4:	17ffffce 	b	8afc <fwp_caps12+0x8c>
    8bc8:	72003c1f 	tst	w0, #0xffff
    8bcc:	54fffa81 	b.ne	8b1c <fwp_caps12+0xac>  // b.any
    8bd0:	17fffff0 	b	8b90 <fwp_caps12+0x120>
    8bd4:	f940ac23 	ldr	x3, [x1, #344]
    8bd8:	91000463 	add	x3, x3, #0x1
    8bdc:	f900ac23 	str	x3, [x1, #344]
    8be0:	17fffff2 	b	8ba8 <fwp_caps12+0x138>
    8be4:	f9400bf3 	ldr	x19, [sp, #16]
    8be8:	aa0203e0 	mov	x0, x2
    8bec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8bf0:	17ffeee5 	b	4784 <fwp_rc_wide_dup>

0000000000008bf4 <fwp_caps23>:
    8bf4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8bf8:	910003fd 	mov	x29, sp
    8bfc:	f9000bf3 	str	x19, [sp, #16]
    8c00:	aa0003f3 	mov	x19, x0
    8c04:	b9400400 	ldr	w0, [x0, #4]
    8c08:	340004a0 	cbz	w0, 8c9c <fwp_caps23+0xa8>
    8c0c:	f9400660 	ldr	x0, [x19, #8]
    8c10:	350004e1 	cbnz	w1, 8cac <fwp_caps23+0xb8>
    8c14:	97fffdd7 	bl	8370 <fwp_drop2>
    8c18:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8c1c:	91190042 	add	x2, x2, #0x640
    8c20:	f949d840 	ldr	x0, [x2, #5040]
    8c24:	f949ec41 	ldr	x1, [x2, #5080]
    8c28:	cb000260 	sub	x0, x19, x0
    8c2c:	eb01401f 	cmp	x0, x1, lsl #16
    8c30:	54000382 	b.cs	8ca0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8c34:	d350fc01 	lsr	x1, x0, #16
    8c38:	f949fc44 	ldr	x4, [x2, #5112]
    8c3c:	8b010821 	add	x1, x1, x1, lsl #2
    8c40:	d37df021 	lsl	x1, x1, #3
    8c44:	8b010083 	add	x3, x4, x1
    8c48:	f9401062 	ldr	x2, [x3, #32]
    8c4c:	b40002a2 	cbz	x2, 8ca0 <fwp_caps23+0xac>
    8c50:	38616881 	ldrb	w1, [x4, x1]
    8c54:	7100083f 	cmp	w1, #0x2
    8c58:	54000740 	b.eq	8d40 <fwp_caps23+0x14c>  // b.none
    8c5c:	7100043f 	cmp	w1, #0x1
    8c60:	54000201 	b.ne	8ca0 <fwp_caps23+0xac>  // b.any
    8c64:	29430464 	ldp	w4, w1, [x3, #24]
    8c68:	92403c00 	and	x0, x0, #0xffff
    8c6c:	9b047c00 	mul	x0, x0, x4
    8c70:	d360fc00 	lsr	x0, x0, #32
    8c74:	eb01001f 	cmp	x0, x1
    8c78:	54000142 	b.cs	8ca0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8c7c:	8b000042 	add	x2, x2, x0
    8c80:	39400040 	ldrb	w0, [x2]
    8c84:	7100041f 	cmp	w0, #0x1
    8c88:	540000c1 	b.ne	8ca0 <fwp_caps23+0xac>  // b.any
    8c8c:	aa1303e0 	mov	x0, x19
    8c90:	f9400bf3 	ldr	x19, [sp, #16]
    8c94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8c98:	17ffee42 	b	45a0 <fwp_mem_free>
    8c9c:	34fffbe1 	cbz	w1, 8c18 <fwp_caps23+0x24>
    8ca0:	f9400bf3 	ldr	x19, [sp, #16]
    8ca4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8ca8:	d65f03c0 	ret
    8cac:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    8cb0:	91190042 	add	x2, x2, #0x640
    8cb4:	f949d843 	ldr	x3, [x2, #5040]
    8cb8:	f949ec41 	ldr	x1, [x2, #5080]
    8cbc:	cb030000 	sub	x0, x0, x3
    8cc0:	eb01401f 	cmp	x0, x1, lsl #16
    8cc4:	54fffee2 	b.cs	8ca0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8cc8:	d350fc01 	lsr	x1, x0, #16
    8ccc:	f949fc44 	ldr	x4, [x2, #5112]
    8cd0:	8b010821 	add	x1, x1, x1, lsl #2
    8cd4:	d37df021 	lsl	x1, x1, #3
    8cd8:	8b010083 	add	x3, x4, x1
    8cdc:	f9401062 	ldr	x2, [x3, #32]
    8ce0:	b4fffe02 	cbz	x2, 8ca0 <fwp_caps23+0xac>
    8ce4:	38616881 	ldrb	w1, [x4, x1]
    8ce8:	7100083f 	cmp	w1, #0x2
    8cec:	54000300 	b.eq	8d4c <fwp_caps23+0x158>  // b.none
    8cf0:	7100043f 	cmp	w1, #0x1
    8cf4:	54fffd61 	b.ne	8ca0 <fwp_caps23+0xac>  // b.any
    8cf8:	92403c01 	and	x1, x0, #0xffff
    8cfc:	29430064 	ldp	w4, w0, [x3, #24]
    8d00:	9b047c21 	mul	x1, x1, x4
    8d04:	d360fc21 	lsr	x1, x1, #32
    8d08:	eb00003f 	cmp	x1, x0
    8d0c:	54fffca2 	b.cs	8ca0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8d10:	8b010042 	add	x2, x2, x1
    8d14:	39400040 	ldrb	w0, [x2]
    8d18:	34fffc40 	cbz	w0, 8ca0 <fwp_caps23+0xac>
    8d1c:	900000c1 	adrp	x1, 20000 <__data_start>
    8d20:	91018021 	add	x1, x1, #0x60
    8d24:	b9413023 	ldr	w3, [x1, #304]
    8d28:	35000183 	cbnz	w3, 8d58 <fwp_caps23+0x164>
    8d2c:	7103f41f 	cmp	w0, #0xfd
    8d30:	540001c8 	b.hi	8d68 <fwp_caps23+0x174>  // b.pmore
    8d34:	11000400 	add	w0, w0, #0x1
    8d38:	39000040 	strb	w0, [x2]
    8d3c:	17ffffd9 	b	8ca0 <fwp_caps23+0xac>
    8d40:	72003c1f 	tst	w0, #0xffff
    8d44:	54fffae1 	b.ne	8ca0 <fwp_caps23+0xac>  // b.any
    8d48:	17ffffce 	b	8c80 <fwp_caps23+0x8c>
    8d4c:	72003c1f 	tst	w0, #0xffff
    8d50:	54fffa81 	b.ne	8ca0 <fwp_caps23+0xac>  // b.any
    8d54:	17fffff0 	b	8d14 <fwp_caps23+0x120>
    8d58:	f940ac23 	ldr	x3, [x1, #344]
    8d5c:	91000463 	add	x3, x3, #0x1
    8d60:	f900ac23 	str	x3, [x1, #344]
    8d64:	17fffff2 	b	8d2c <fwp_caps23+0x138>
    8d68:	f9400bf3 	ldr	x19, [sp, #16]
    8d6c:	aa0203e0 	mov	x0, x2
    8d70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8d74:	17ffee84 	b	4784 <fwp_rc_wide_dup>
    8d78:	d503201f 	nop
    8d7c:	d503201f 	nop

0000000000008d80 <fwp_write>:
    8d80:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8d84:	910003fd 	mov	x29, sp
    8d88:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    8d8c:	f947f484 	ldr	x4, [x4, #4072]
    8d90:	a90153f3 	stp	x19, x20, [sp, #16]
    8d94:	d10943ff 	sub	sp, sp, #0x250
    8d98:	b9400045 	ldr	w5, [x2]
    8d9c:	aa0003f4 	mov	x20, x0
    8da0:	f9400080 	ldr	x0, [x4]
    8da4:	f90127e0 	str	x0, [sp, #584]
    8da8:	d2800000 	mov	x0, #0x0                   	// #0
    8dac:	710064bf 	cmp	w5, #0x19
    8db0:	54000408 	b.hi	8e30 <fwp_write+0xb0>  // b.pmore
    8db4:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    8db8:	aa0103f3 	mov	x19, x1
    8dbc:	912b4000 	add	x0, x0, #0xad0
    8dc0:	f9013bf5 	str	x21, [sp, #624]
    8dc4:	f9013ff6 	str	x22, [sp, #632]
    8dc8:	f90153fb 	str	x27, [sp, #672]
    8dcc:	f90157fc 	str	x28, [sp, #680]
    8dd0:	aa0203fc 	mov	x28, x2
    8dd4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8dd8:	10000061 	adr	x1, 8de4 <fwp_write+0x64>
    8ddc:	8b20a820 	add	x0, x1, w0, sxth #2
    8de0:	d61f0000 	br	x0
    8de4:	910123e0 	add	x0, sp, #0x48
    8de8:	aa1303e5 	mov	x5, x19
    8dec:	90000024 	adrp	x4, c000 <_IO_stdin_used+0x460>
    8df0:	aa0003f3 	mov	x19, x0
    8df4:	910b0084 	add	x4, x4, #0x2c0
    8df8:	d2804003 	mov	x3, #0x200                 	// #512
    8dfc:	aa0303e1 	mov	x1, x3
    8e00:	52800042 	mov	w2, #0x2                   	// #2
    8e04:	97ffe65f 	bl	2780 <__snprintf_chk@plt>
    8e08:	aa1303e0 	mov	x0, x19
    8e0c:	97ffe625 	bl	26a0 <strlen@plt>
    8e10:	aa1303e1 	mov	x1, x19
    8e14:	aa0003e2 	mov	x2, x0
    8e18:	aa1403e0 	mov	x0, x20
    8e1c:	97ffe9fd 	bl	3610 <buf_put>
    8e20:	f9413bf5 	ldr	x21, [sp, #624]
    8e24:	f9413ff6 	ldr	x22, [sp, #632]
    8e28:	f94153fb 	ldr	x27, [sp, #672]
    8e2c:	f94157fc 	ldr	x28, [sp, #680]
    8e30:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8e34:	f947f400 	ldr	x0, [x0, #4072]
    8e38:	f94127e2 	ldr	x2, [sp, #584]
    8e3c:	f9400001 	ldr	x1, [x0]
    8e40:	eb010042 	subs	x2, x2, x1
    8e44:	d2800001 	mov	x1, #0x0                   	// #0
    8e48:	540077c1 	b.ne	9d40 <fwp_write+0xfc0>  // b.any
    8e4c:	910943ff 	add	sp, sp, #0x250
    8e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    8e54:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8e58:	d65f03c0 	ret
    8e5c:	910123e0 	add	x0, sp, #0x48
    8e60:	aa1303e5 	mov	x5, x19
    8e64:	90000024 	adrp	x4, c000 <_IO_stdin_used+0x460>
    8e68:	aa0003f3 	mov	x19, x0
    8e6c:	910ae084 	add	x4, x4, #0x2b8
    8e70:	d2804003 	mov	x3, #0x200                 	// #512
    8e74:	17ffffe2 	b	8dfc <fwp_write+0x7c>
    8e78:	71004cbf 	cmp	w5, #0x13
    8e7c:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x460>
    8e80:	90000021 	adrp	x1, c000 <_IO_stdin_used+0x460>
    8e84:	910aa000 	add	x0, x0, #0x2a8
    8e88:	910ac021 	add	x1, x1, #0x2b0
    8e8c:	d2800082 	mov	x2, #0x4                   	// #4
    8e90:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8e94:	aa1403e0 	mov	x0, x20
    8e98:	f90143f7 	str	x23, [sp, #640]
    8e9c:	d2800016 	mov	x22, #0x0                   	// #0
    8ea0:	f90147f8 	str	x24, [sp, #648]
    8ea4:	97ffe9db 	bl	3610 <buf_put>
    8ea8:	f9400260 	ldr	x0, [x19]
    8eac:	90000037 	adrp	x23, c000 <_IO_stdin_used+0x460>
    8eb0:	d2800015 	mov	x21, #0x0                   	// #0
    8eb4:	910cc2f7 	add	x23, x23, #0x330
    8eb8:	b40047a0 	cbz	x0, 97ac <fwp_write+0xa2c>
    8ebc:	b9400380 	ldr	w0, [x28]
    8ec0:	52800003 	mov	w3, #0x0                   	// #0
    8ec4:	f9401f82 	ldr	x2, [x28, #56]
    8ec8:	71004c1f 	cmp	w0, #0x13
    8ecc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8ed0:	aa1403e0 	mov	x0, x20
    8ed4:	8b010e61 	add	x1, x19, x1, lsl #3
    8ed8:	f9400421 	ldr	x1, [x1, #8]
    8edc:	97ffffa9 	bl	8d80 <fwp_write>
    8ee0:	b9400380 	ldr	w0, [x28]
    8ee4:	7100481f 	cmp	w0, #0x12
    8ee8:	54004b40 	b.eq	9850 <fwp_write+0xad0>  // b.none
    8eec:	f9400260 	ldr	x0, [x19]
    8ef0:	910006b5 	add	x21, x21, #0x1
    8ef4:	91000ad6 	add	x22, x22, #0x2
    8ef8:	eb15001f 	cmp	x0, x21
    8efc:	54004589 	b.ls	97ac <fwp_write+0xa2c>  // b.plast
    8f00:	aa1703e1 	mov	x1, x23
    8f04:	aa1403e0 	mov	x0, x20
    8f08:	d2800042 	mov	x2, #0x2                   	// #2
    8f0c:	97ffe9c1 	bl	3610 <buf_put>
    8f10:	17ffffeb 	b	8ebc <fwp_write+0x13c>
    8f14:	90000021 	adrp	x1, c000 <_IO_stdin_used+0x460>
    8f18:	910ba021 	add	x1, x1, #0x2e8
    8f1c:	d28000c2 	mov	x2, #0x6                   	// #6
    8f20:	aa1403e0 	mov	x0, x20
    8f24:	91004273 	add	x19, x19, #0x10
    8f28:	97ffe9ba 	bl	3610 <buf_put>
    8f2c:	aa1303e0 	mov	x0, x19
    8f30:	97ffe5dc 	bl	26a0 <strlen@plt>
    8f34:	aa1303e1 	mov	x1, x19
    8f38:	aa0003e2 	mov	x2, x0
    8f3c:	aa1403e0 	mov	x0, x20
    8f40:	97ffe9b4 	bl	3610 <buf_put>
    8f44:	528007c3 	mov	w3, #0x3e                  	// #62
    8f48:	aa1403e0 	mov	x0, x20
    8f4c:	91001fe1 	add	x1, sp, #0x7
    8f50:	d2800022 	mov	x2, #0x1                   	// #1
    8f54:	39001fe3 	strb	w3, [sp, #7]
    8f58:	17ffffb1 	b	8e1c <fwp_write+0x9c>
    8f5c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8f60:	f947f400 	ldr	x0, [x0, #4072]
    8f64:	f94127e2 	ldr	x2, [sp, #584]
    8f68:	f9400001 	ldr	x1, [x0]
    8f6c:	eb010042 	subs	x2, x2, x1
    8f70:	d2800001 	mov	x1, #0x0                   	// #0
    8f74:	540034e1 	b.ne	9610 <fwp_write+0x890>  // b.any
    8f78:	f9413bf5 	ldr	x21, [sp, #624]
    8f7c:	90000021 	adrp	x1, c000 <_IO_stdin_used+0x460>
    8f80:	f9413ff6 	ldr	x22, [sp, #632]
    8f84:	aa1403e0 	mov	x0, x20
    8f88:	910b2021 	add	x1, x1, #0x2c8
    8f8c:	d2800142 	mov	x2, #0xa                   	// #10
    8f90:	f94153fb 	ldr	x27, [sp, #672]
    8f94:	f94157fc 	ldr	x28, [sp, #680]
    8f98:	910943ff 	add	sp, sp, #0x250
    8f9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8fa0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8fa4:	17ffe99b 	b	3610 <buf_put>
    8fa8:	f9400456 	ldr	x22, [x2, #8]
    8fac:	f90143f7 	str	x23, [sp, #640]
    8fb0:	f90147f8 	str	x24, [sp, #648]
    8fb4:	b4005b16 	cbz	x22, 9b14 <fwp_write+0xd94>
    8fb8:	aa1603e0 	mov	x0, x22
    8fbc:	90000021 	adrp	x1, c000 <_IO_stdin_used+0x460>
    8fc0:	910d2021 	add	x1, x1, #0x348
    8fc4:	97ffe633 	bl	2890 <strcmp@plt>
    8fc8:	2a0003f5 	mov	w21, w0
    8fcc:	34005fe0 	cbz	w0, 9bc8 <fwp_write+0xe48>
    8fd0:	aa1603e0 	mov	x0, x22
    8fd4:	97ffe5b3 	bl	26a0 <strlen@plt>
    8fd8:	aa1603e1 	mov	x1, x22
    8fdc:	aa0003e2 	mov	x2, x0
    8fe0:	aa1403e0 	mov	x0, x20
    8fe4:	97ffe98b 	bl	3610 <buf_put>
    8fe8:	52800403 	mov	w3, #0x20                  	// #32
    8fec:	91001ff5 	add	x21, sp, #0x7
    8ff0:	aa1503e1 	mov	x1, x21
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	d2800022 	mov	x2, #0x1                   	// #1
    8ffc:	39001fe3 	strb	w3, [sp, #7]
    9000:	97ffe984 	bl	3610 <buf_put>
    9004:	52800f63 	mov	w3, #0x7b                  	// #123
    9008:	aa1403e0 	mov	x0, x20
    900c:	aa1503e1 	mov	x1, x21
    9010:	d2800022 	mov	x2, #0x1                   	// #1
    9014:	39001fe3 	strb	w3, [sp, #7]
    9018:	97ffe97e 	bl	3610 <buf_put>
    901c:	b9401380 	ldr	w0, [x28, #16]
    9020:	52800018 	mov	w24, #0x0                   	// #0
    9024:	7100001f 	cmp	w0, #0x0
    9028:	54003aad 	b.le	977c <fwp_write+0x9fc>
    902c:	f9014bf9 	str	x25, [sp, #656]
    9030:	f0000019 	adrp	x25, c000 <_IO_stdin_used+0x460>
    9034:	910dc339 	add	x25, x25, #0x370
    9038:	f9014ffa 	str	x26, [sp, #664]
    903c:	f000001a 	adrp	x26, c000 <_IO_stdin_used+0x460>
    9040:	910cc35a 	add	x26, x26, #0x330
    9044:	91002276 	add	x22, x19, #0x8
    9048:	d2800013 	mov	x19, #0x0                   	// #0
    904c:	b5003e93 	cbnz	x19, 981c <fwp_write+0xa9c>
    9050:	d37df277 	lsl	x23, x19, #3
    9054:	34003cb8 	cbz	w24, 97e8 <fwp_write+0xa68>
    9058:	f9401382 	ldr	x2, [x28, #32]
    905c:	aa1403e0 	mov	x0, x20
    9060:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    9064:	52800003 	mov	w3, #0x0                   	// #0
    9068:	f8776842 	ldr	x2, [x2, x23]
    906c:	91000673 	add	x19, x19, #0x1
    9070:	97ffff44 	bl	8d80 <fwp_write>
    9074:	b9401380 	ldr	w0, [x28, #16]
    9078:	6b13001f 	cmp	w0, w19
    907c:	54fffe8c 	b.gt	904c <fwp_write+0x2cc>
    9080:	f9414bf9 	ldr	x25, [sp, #656]
    9084:	f9414ffa 	ldr	x26, [sp, #664]
    9088:	340037b8 	cbz	w24, 977c <fwp_write+0x9fc>
    908c:	52800523 	mov	w3, #0x29                  	// #41
    9090:	aa1503e1 	mov	x1, x21
    9094:	aa1403e0 	mov	x0, x20
    9098:	d2800022 	mov	x2, #0x1                   	// #1
    909c:	39001fe3 	strb	w3, [sp, #7]
    90a0:	97ffe95c 	bl	3610 <buf_put>
    90a4:	f9413bf5 	ldr	x21, [sp, #624]
    90a8:	f9413ff6 	ldr	x22, [sp, #632]
    90ac:	f94143f7 	ldr	x23, [sp, #640]
    90b0:	f94147f8 	ldr	x24, [sp, #648]
    90b4:	f94153fb 	ldr	x27, [sp, #672]
    90b8:	f94157fc 	ldr	x28, [sp, #680]
    90bc:	17ffff5d 	b	8e30 <fwp_write+0xb0>
    90c0:	b9404855 	ldr	w21, [x2, #72]
    90c4:	aa1403e0 	mov	x0, x20
    90c8:	93407eb6 	sxtw	x22, w21
    90cc:	91000ac1 	add	x1, x22, #0x2
    90d0:	97ffe91c 	bl	3540 <buf_grow>
    90d4:	a9400281 	ldp	x1, x0, [x20]
    90d8:	528e8603 	mov	w3, #0x7430                	// #29744
    90dc:	78206823 	strh	w3, [x1, x0]
    90e0:	8b000022 	add	x2, x1, x0
    90e4:	710002bf 	cmp	w21, #0x0
    90e8:	540036cd 	b.le	97c0 <fwp_write+0xa40>
    90ec:	110006a3 	add	w3, w21, #0x1
    90f0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    90f4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    90f8:	91000449 	add	x9, x2, #0x1
    90fc:	8b23c043 	add	x3, x2, w3, sxtw
    9100:	f28aaac6 	movk	x6, #0x5556
    9104:	f2955568 	movk	x8, #0xaaab
    9108:	1400000d 	b	913c <fwp_write+0x3bc>
    910c:	d2800021 	mov	x1, #0x1                   	// #1
    9110:	528005a5 	mov	w5, #0x2d                  	// #45
    9114:	f100001f 	cmp	x0, #0x0
    9118:	9b467e60 	smulh	x0, x19, x6
    911c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    9120:	381ff465 	strb	w5, [x3], #-1
    9124:	cb040000 	sub	x0, x0, x4
    9128:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    912c:	cb020000 	sub	x0, x0, x2
    9130:	8b010013 	add	x19, x0, x1
    9134:	eb03013f 	cmp	x9, x3
    9138:	54003440 	b.eq	97c0 <fwp_write+0xa40>  // b.none
    913c:	9b467e60 	smulh	x0, x19, x6
    9140:	937ffe64 	asr	x4, x19, #63
    9144:	52800605 	mov	w5, #0x30                  	// #48
    9148:	cb040000 	sub	x0, x0, x4
    914c:	8b000400 	add	x0, x0, x0, lsl #1
    9150:	cb000260 	sub	x0, x19, x0
    9154:	91000c01 	add	x1, x0, #0x3
    9158:	9bc87c22 	umulh	x2, x1, x8
    915c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    9160:	8b4204e2 	add	x2, x7, x2, lsr #1
    9164:	eb020021 	subs	x1, x1, x2
    9168:	54fffd60 	b.eq	9114 <fwp_write+0x394>  // b.none
    916c:	f100043f 	cmp	x1, #0x1
    9170:	54fffce1 	b.ne	910c <fwp_write+0x38c>  // b.any
    9174:	d2800001 	mov	x1, #0x0                   	// #0
    9178:	52800565 	mov	w5, #0x2b                  	// #43
    917c:	17ffffe6 	b	9114 <fwp_write+0x394>
    9180:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9184:	f947f400 	ldr	x0, [x0, #4072]
    9188:	f94127e2 	ldr	x2, [sp, #584]
    918c:	f9400001 	ldr	x1, [x0]
    9190:	eb010042 	subs	x2, x2, x1
    9194:	d2800001 	mov	x1, #0x0                   	// #0
    9198:	540023c1 	b.ne	9610 <fwp_write+0x890>  // b.any
    919c:	f9413bf5 	ldr	x21, [sp, #624]
    91a0:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    91a4:	f9413ff6 	ldr	x22, [sp, #632]
    91a8:	aa1403e0 	mov	x0, x20
    91ac:	910b6021 	add	x1, x1, #0x2d8
    91b0:	d2800102 	mov	x2, #0x8                   	// #8
    91b4:	17ffff77 	b	8f90 <fwp_write+0x210>
    91b8:	aa1403e0 	mov	x0, x20
    91bc:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    91c0:	d28000c2 	mov	x2, #0x6                   	// #6
    91c4:	910ce021 	add	x1, x1, #0x338
    91c8:	97ffe912 	bl	3610 <buf_put>
    91cc:	d2800015 	mov	x21, #0x0                   	// #0
    91d0:	f9400263 	ldr	x3, [x19]
    91d4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    91d8:	54002c60 	b.eq	9764 <fwp_write+0x9e4>  // b.none
    91dc:	f9401f82 	ldr	x2, [x28, #56]
    91e0:	f90143f7 	str	x23, [sp, #640]
    91e4:	f90147f8 	str	x24, [sp, #648]
    91e8:	d2800857 	mov	x23, #0x42                  	// #66
    91ec:	f9014bf9 	str	x25, [sp, #656]
    91f0:	f0000016 	adrp	x22, c000 <_IO_stdin_used+0x460>
    91f4:	f9014ffa 	str	x26, [sp, #664]
    91f8:	910cc2d6 	add	x22, x22, #0x330
    91fc:	d2800038 	mov	x24, #0x1                   	// #1
    9200:	f2a18017 	movk	x23, #0xc00, lsl #16
    9204:	d2809099 	mov	x25, #0x484                 	// #1156
    9208:	b40004a2 	cbz	x2, 929c <fwp_write+0x51c>
    920c:	b9400040 	ldr	w0, [x2]
    9210:	7100701f 	cmp	w0, #0x1c
    9214:	540042c0 	b.eq	9a6c <fwp_write+0xcec>  // b.none
    9218:	71006c1f 	cmp	w0, #0x1b
    921c:	54000408 	b.hi	929c <fwp_write+0x51c>  // b.pmore
    9220:	9ac02301 	lsl	x1, x24, x0
    9224:	ea17003f 	tst	x1, x23
    9228:	540036a1 	b.ne	98fc <fwp_write+0xb7c>  // b.any
    922c:	ea19003f 	tst	x1, x25
    9230:	54003521 	b.ne	98d4 <fwp_write+0xb54>  // b.any
    9234:	d2800424 	mov	x4, #0x21                  	// #33
    9238:	ea04003f 	tst	x1, x4
    923c:	54000300 	b.eq	929c <fwp_write+0x51c>  // b.none
    9240:	b7f849c3 	tbnz	x3, #63, 9b78 <fwp_write+0xdf8>
    9244:	91002261 	add	x1, x19, #0x8
    9248:	8b150021 	add	x1, x1, x21
    924c:	39400021 	ldrb	w1, [x1]
    9250:	7100001f 	cmp	w0, #0x0
    9254:	93401c23 	sxtb	x3, w1
    9258:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    925c:	d503201f 	nop
    9260:	aa1403e0 	mov	x0, x20
    9264:	52800003 	mov	w3, #0x0                   	// #0
    9268:	97fffec6 	bl	8d80 <fwp_write>
    926c:	910006b5 	add	x21, x21, #0x1
    9270:	f9400260 	ldr	x0, [x19]
    9274:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    9278:	eb0002bf 	cmp	x21, x0
    927c:	540026c2 	b.cs	9754 <fwp_write+0x9d4>  // b.hs, b.nlast
    9280:	d2800042 	mov	x2, #0x2                   	// #2
    9284:	aa1603e1 	mov	x1, x22
    9288:	aa1403e0 	mov	x0, x20
    928c:	97ffe8e1 	bl	3610 <buf_put>
    9290:	f9401f82 	ldr	x2, [x28, #56]
    9294:	f9400263 	ldr	x3, [x19]
    9298:	b5fffba2 	cbnz	x2, 920c <fwp_write+0x48c>
    929c:	d37df2a0 	lsl	x0, x21, #3
    92a0:	b7f83f03 	tbnz	x3, #63, 9a80 <fwp_write+0xd00>
    92a4:	91002261 	add	x1, x19, #0x8
    92a8:	8b000020 	add	x0, x1, x0
    92ac:	f9400001 	ldr	x1, [x0]
    92b0:	17ffffec 	b	9260 <fwp_write+0x4e0>
    92b4:	a9400e62 	ldp	x2, x3, [x19]
    92b8:	b7f83ca3 	tbnz	x3, #63, 9a4c <fwp_write+0xccc>
    92bc:	910123f5 	add	x21, sp, #0x48
    92c0:	aa1503e0 	mov	x0, x21
    92c4:	97ffe6b7 	bl	2da0 <fwp_fmt_u128>
    92c8:	aa1503e0 	mov	x0, x21
    92cc:	97ffe4f5 	bl	26a0 <strlen@plt>
    92d0:	aa1503e1 	mov	x1, x21
    92d4:	aa0003e2 	mov	x2, x0
    92d8:	17fffed0 	b	8e18 <fwp_write+0x98>
    92dc:	fd015be8 	str	d8, [sp, #688]
    92e0:	1e270268 	fmov	s8, w19
    92e4:	fd015fe9 	str	d9, [sp, #696]
    92e8:	1e282100 	fcmp	s8, s8
    92ec:	54004d26 	b.vs	9c90 <fwp_write+0xf10>
    92f0:	1e20c101 	fabs	s1, s8
    92f4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    92f8:	1e270000 	fmov	s0, w0
    92fc:	1e202020 	fcmp	s1, s0
    9300:	54002c0d 	b.le	9880 <fwp_write+0xb00>
    9304:	1e202118 	fcmpe	s8, #0.0
    9308:	d0000002 	adrp	x2, b000 <fwp_main_thread+0x1290>
    930c:	91346042 	add	x2, x2, #0xd18
    9310:	910123f5 	add	x21, sp, #0x48
    9314:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9318:	910a2021 	add	x1, x1, #0x288
    931c:	aa1503e0 	mov	x0, x21
    9320:	9a81c041 	csel	x1, x2, x1, gt
    9324:	97ffe58b 	bl	2950 <strcpy@plt>
    9328:	aa1503e0 	mov	x0, x21
    932c:	97ffe4dd 	bl	26a0 <strlen@plt>
    9330:	aa1503e1 	mov	x1, x21
    9334:	aa0003e2 	mov	x2, x0
    9338:	aa1403e0 	mov	x0, x20
    933c:	97ffe8b5 	bl	3610 <buf_put>
    9340:	f9413bf5 	ldr	x21, [sp, #624]
    9344:	f9413ff6 	ldr	x22, [sp, #632]
    9348:	f94153fb 	ldr	x27, [sp, #672]
    934c:	f94157fc 	ldr	x28, [sp, #680]
    9350:	fd415be8 	ldr	d8, [sp, #688]
    9354:	fd415fe9 	ldr	d9, [sp, #696]
    9358:	17fffeb6 	b	8e30 <fwp_write+0xb0>
    935c:	f9400276 	ldr	x22, [x19]
    9360:	34002e03 	cbz	w3, 9920 <fwp_write+0xba0>
    9364:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9368:	f947f400 	ldr	x0, [x0, #4072]
    936c:	f94127e2 	ldr	x2, [sp, #584]
    9370:	f9400001 	ldr	x1, [x0]
    9374:	eb010042 	subs	x2, x2, x1
    9378:	d2800001 	mov	x1, #0x0                   	// #0
    937c:	540014a1 	b.ne	9610 <fwp_write+0x890>  // b.any
    9380:	aa1603e2 	mov	x2, x22
    9384:	91002261 	add	x1, x19, #0x8
    9388:	f9413bf5 	ldr	x21, [sp, #624]
    938c:	aa1403e0 	mov	x0, x20
    9390:	f9413ff6 	ldr	x22, [sp, #632]
    9394:	17fffeff 	b	8f90 <fwp_write+0x210>
    9398:	fd015be8 	str	d8, [sp, #688]
    939c:	9e670268 	fmov	d8, x19
    93a0:	fd015fe9 	str	d9, [sp, #696]
    93a4:	1e682100 	fcmp	d8, d8
    93a8:	54004746 	b.vs	9c90 <fwp_write+0xf10>
    93ac:	1e60c101 	fabs	d1, d8
    93b0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    93b4:	9e670000 	fmov	d0, x0
    93b8:	910123f5 	add	x21, sp, #0x48
    93bc:	52800033 	mov	w19, #0x1                   	// #1
    93c0:	1e602020 	fcmp	d1, d0
    93c4:	540001ad 	b.le	93f8 <fwp_write+0x678>
    93c8:	1e602118 	fcmpe	d8, #0.0
    93cc:	d0000002 	adrp	x2, b000 <fwp_main_thread+0x1290>
    93d0:	91346042 	add	x2, x2, #0xd18
    93d4:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    93d8:	910a2021 	add	x1, x1, #0x288
    93dc:	aa1503e0 	mov	x0, x21
    93e0:	9a81c041 	csel	x1, x2, x1, gt
    93e4:	97ffe55b 	bl	2950 <strcpy@plt>
    93e8:	17ffffd0 	b	9328 <fwp_write+0x5a8>
    93ec:	11000673 	add	w19, w19, #0x1
    93f0:	71004a7f 	cmp	w19, #0x12
    93f4:	54003860 	b.eq	9b00 <fwp_write+0xd80>  // b.none
    93f8:	1e604100 	fmov	d0, d8
    93fc:	2a1303e1 	mov	w1, w19
    9400:	aa1503e0 	mov	x0, x21
    9404:	97ffe8df 	bl	3780 <fwp_format_g.constprop.0>
    9408:	aa1503e0 	mov	x0, x21
    940c:	d2800001 	mov	x1, #0x0                   	// #0
    9410:	97ffe4b8 	bl	26f0 <strtod@plt>
    9414:	1e602100 	fcmp	d8, d0
    9418:	54fffea1 	b.ne	93ec <fwp_write+0x66c>  // b.any
    941c:	aa1503e0 	mov	x0, x21
    9420:	97ffe8b5 	bl	36f4 <fwp_finish_float>
    9424:	17ffffc1 	b	9328 <fwp_write+0x5a8>
    9428:	a9400e62 	ldp	x2, x3, [x19]
    942c:	910123f3 	add	x19, sp, #0x48
    9430:	aa1303e0 	mov	x0, x19
    9434:	97ffe65b 	bl	2da0 <fwp_fmt_u128>
    9438:	17fffe74 	b	8e08 <fwp_write+0x88>
    943c:	f90143f7 	str	x23, [sp, #640]
    9440:	f90147f8 	str	x24, [sp, #648]
    9444:	2a1303f8 	mov	w24, w19
    9448:	f9014bf9 	str	x25, [sp, #656]
    944c:	f9014ffa 	str	x26, [sp, #664]
    9450:	f13ffe7f 	cmp	x19, #0xfff
    9454:	54000049 	b.ls	945c <fwp_write+0x6dc>  // b.plast
    9458:	b9400278 	ldr	w24, [x19]
    945c:	f9400f80 	ldr	x0, [x28, #24]
    9460:	2a1803f5 	mov	w21, w24
    9464:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9468:	d37ef6b9 	lsl	x25, x21, #2
    946c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9470:	aa1603e0 	mov	x0, x22
    9474:	97ffe48b 	bl	26a0 <strlen@plt>
    9478:	aa1603e1 	mov	x1, x22
    947c:	aa0003e2 	mov	x2, x0
    9480:	aa1403e0 	mov	x0, x20
    9484:	97ffe863 	bl	3610 <buf_put>
    9488:	f9401780 	ldr	x0, [x28, #40]
    948c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9490:	7100001f 	cmp	w0, #0x0
    9494:	5400068d 	b.le	9564 <fwp_write+0x7e4>
    9498:	91002276 	add	x22, x19, #0x8
    949c:	91001ff5 	add	x21, sp, #0x7
    94a0:	d280001b 	mov	x27, #0x0                   	// #0
    94a4:	5280041a 	mov	w26, #0x20                  	// #32
    94a8:	f9401b80 	ldr	x0, [x28, #48]
    94ac:	aa1503e1 	mov	x1, x21
    94b0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    94b4:	d2800022 	mov	x2, #0x1                   	// #1
    94b8:	f8786803 	ldr	x3, [x0, x24]
    94bc:	aa1403e0 	mov	x0, x20
    94c0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    94c4:	39001ffa 	strb	w26, [sp, #7]
    94c8:	97ffe852 	bl	3610 <buf_put>
    94cc:	f13ffeff 	cmp	x23, #0xfff
    94d0:	b9400261 	ldr	w1, [x19]
    94d4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    94d8:	7100383f 	cmp	w1, #0xe
    94dc:	54000160 	b.eq	9508 <fwp_write+0x788>  // b.none
    94e0:	7100403f 	cmp	w1, #0x10
    94e4:	54001a60 	b.eq	9830 <fwp_write+0xab0>  // b.none
    94e8:	7100283f 	cmp	w1, #0xa
    94ec:	54002aa0 	b.eq	9a40 <fwp_write+0xcc0>  // b.none
    94f0:	540014ac 	b.gt	9784 <fwp_write+0xa04>
    94f4:	71000c3f 	cmp	w1, #0x3
    94f8:	540029ac 	b.gt	9a2c <fwp_write+0xcac>
    94fc:	d37ffee0 	lsr	x0, x23, #63
    9500:	37f814a1 	tbnz	w1, #31, 9794 <fwp_write+0xa14>
    9504:	d503201f 	nop
    9508:	34001460 	cbz	w0, 9794 <fwp_write+0xa14>
    950c:	52800503 	mov	w3, #0x28                  	// #40
    9510:	aa1503e1 	mov	x1, x21
    9514:	aa1403e0 	mov	x0, x20
    9518:	d2800022 	mov	x2, #0x1                   	// #1
    951c:	39001fe3 	strb	w3, [sp, #7]
    9520:	97ffe83c 	bl	3610 <buf_put>
    9524:	aa1303e2 	mov	x2, x19
    9528:	aa1703e1 	mov	x1, x23
    952c:	aa1403e0 	mov	x0, x20
    9530:	52800003 	mov	w3, #0x0                   	// #0
    9534:	97fffe13 	bl	8d80 <fwp_write>
    9538:	52800523 	mov	w3, #0x29                  	// #41
    953c:	aa1503e1 	mov	x1, x21
    9540:	aa1403e0 	mov	x0, x20
    9544:	d2800022 	mov	x2, #0x1                   	// #1
    9548:	39001fe3 	strb	w3, [sp, #7]
    954c:	97ffe831 	bl	3610 <buf_put>
    9550:	f9401780 	ldr	x0, [x28, #40]
    9554:	9100077b 	add	x27, x27, #0x1
    9558:	b8796800 	ldr	w0, [x0, x25]
    955c:	6b1b001f 	cmp	w0, w27
    9560:	54fffa4c 	b.gt	94a8 <fwp_write+0x728>
    9564:	f9413bf5 	ldr	x21, [sp, #624]
    9568:	f9413ff6 	ldr	x22, [sp, #632]
    956c:	f94143f7 	ldr	x23, [sp, #640]
    9570:	f94147f8 	ldr	x24, [sp, #648]
    9574:	f9414bf9 	ldr	x25, [sp, #656]
    9578:	f9414ffa 	ldr	x26, [sp, #664]
    957c:	f94153fb 	ldr	x27, [sp, #672]
    9580:	f94157fc 	ldr	x28, [sp, #680]
    9584:	17fffe2b 	b	8e30 <fwp_write+0xb0>
    9588:	52800783 	mov	w3, #0x3c                  	// #60
    958c:	91001ff3 	add	x19, sp, #0x7
    9590:	aa1303e1 	mov	x1, x19
    9594:	d2800022 	mov	x2, #0x1                   	// #1
    9598:	aa1403e0 	mov	x0, x20
    959c:	39001fe3 	strb	w3, [sp, #7]
    95a0:	97ffe81c 	bl	3610 <buf_put>
    95a4:	f9400795 	ldr	x21, [x28, #8]
    95a8:	aa1503e0 	mov	x0, x21
    95ac:	97ffe43d 	bl	26a0 <strlen@plt>
    95b0:	aa1503e1 	mov	x1, x21
    95b4:	aa0003e2 	mov	x2, x0
    95b8:	aa1403e0 	mov	x0, x20
    95bc:	97ffe815 	bl	3610 <buf_put>
    95c0:	528007c3 	mov	w3, #0x3e                  	// #62
    95c4:	aa1303e1 	mov	x1, x19
    95c8:	aa1403e0 	mov	x0, x20
    95cc:	d2800022 	mov	x2, #0x1                   	// #1
    95d0:	39001fe3 	strb	w3, [sp, #7]
    95d4:	17fffe12 	b	8e1c <fwp_write+0x9c>
    95d8:	f100067f 	cmp	x19, #0x1
    95dc:	540025a0 	b.eq	9a90 <fwp_write+0xd10>  // b.none
    95e0:	b100067f 	cmn	x19, #0x1
    95e4:	54002bc0 	b.eq	9b5c <fwp_write+0xddc>  // b.none
    95e8:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    95ec:	910a4021 	add	x1, x1, #0x290
    95f0:	d2800022 	mov	x2, #0x1                   	// #1
    95f4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    95f8:	f947f400 	ldr	x0, [x0, #4072]
    95fc:	f94127e4 	ldr	x4, [sp, #584]
    9600:	f9400003 	ldr	x3, [x0]
    9604:	eb030084 	subs	x4, x4, x3
    9608:	d2800003 	mov	x3, #0x0                   	// #0
    960c:	54ffebe0 	b.eq	9388 <fwp_write+0x608>  // b.none
    9610:	f90143f7 	str	x23, [sp, #640]
    9614:	f90147f8 	str	x24, [sp, #648]
    9618:	f9014bf9 	str	x25, [sp, #656]
    961c:	f9014ffa 	str	x26, [sp, #664]
    9620:	fd015be8 	str	d8, [sp, #688]
    9624:	fd015fe9 	str	d9, [sp, #696]
    9628:	97ffe47a 	bl	2810 <__stack_chk_fail@plt>
    962c:	52800b63 	mov	w3, #0x5b                  	// #91
    9630:	91001ff5 	add	x21, sp, #0x7
    9634:	aa1503e1 	mov	x1, x21
    9638:	aa1403e0 	mov	x0, x20
    963c:	d2800022 	mov	x2, #0x1                   	// #1
    9640:	f0000016 	adrp	x22, c000 <_IO_stdin_used+0x460>
    9644:	910cc2d6 	add	x22, x22, #0x330
    9648:	39001fe3 	strb	w3, [sp, #7]
    964c:	97ffe7f1 	bl	3610 <buf_put>
    9650:	b4000273 	cbz	x19, 969c <fwp_write+0x91c>
    9654:	f9400661 	ldr	x1, [x19, #8]
    9658:	aa1403e0 	mov	x0, x20
    965c:	f9401f82 	ldr	x2, [x28, #56]
    9660:	52800003 	mov	w3, #0x0                   	// #0
    9664:	97fffdc7 	bl	8d80 <fwp_write>
    9668:	f9400a73 	ldr	x19, [x19, #16]
    966c:	b4000193 	cbz	x19, 969c <fwp_write+0x91c>
    9670:	aa1603e1 	mov	x1, x22
    9674:	aa1403e0 	mov	x0, x20
    9678:	d2800042 	mov	x2, #0x2                   	// #2
    967c:	97ffe7e5 	bl	3610 <buf_put>
    9680:	f9400661 	ldr	x1, [x19, #8]
    9684:	aa1403e0 	mov	x0, x20
    9688:	f9401f82 	ldr	x2, [x28, #56]
    968c:	52800003 	mov	w3, #0x0                   	// #0
    9690:	97fffdbc 	bl	8d80 <fwp_write>
    9694:	f9400a73 	ldr	x19, [x19, #16]
    9698:	b5fffed3 	cbnz	x19, 9670 <fwp_write+0x8f0>
    969c:	52800ba3 	mov	w3, #0x5d                  	// #93
    96a0:	aa1503e1 	mov	x1, x21
    96a4:	aa1403e0 	mov	x0, x20
    96a8:	d2800022 	mov	x2, #0x1                   	// #1
    96ac:	39001fe3 	strb	w3, [sp, #7]
    96b0:	17fffddb 	b	8e1c <fwp_write+0x9c>
    96b4:	aa1403e0 	mov	x0, x20
    96b8:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    96bc:	d28000c2 	mov	x2, #0x6                   	// #6
    96c0:	910c8021 	add	x1, x1, #0x320
    96c4:	97ffe7d3 	bl	3610 <buf_put>
    96c8:	f9400260 	ldr	x0, [x19]
    96cc:	b40004c0 	cbz	x0, 9764 <fwp_write+0x9e4>
    96d0:	910123f5 	add	x21, sp, #0x48
    96d4:	91002276 	add	x22, x19, #0x8
    96d8:	f90143f7 	str	x23, [sp, #640]
    96dc:	d2800017 	mov	x23, #0x0                   	// #0
    96e0:	f90147f8 	str	x24, [sp, #648]
    96e4:	f0000018 	adrp	x24, c000 <_IO_stdin_used+0x460>
    96e8:	910ca318 	add	x24, x24, #0x328
    96ec:	f9014bf9 	str	x25, [sp, #656]
    96f0:	f0000019 	adrp	x25, c000 <_IO_stdin_used+0x460>
    96f4:	910cc339 	add	x25, x25, #0x330
    96f8:	f9014ffa 	str	x26, [sp, #664]
    96fc:	14000005 	b	9710 <fwp_write+0x990>
    9700:	aa1903e1 	mov	x1, x25
    9704:	aa1403e0 	mov	x0, x20
    9708:	d2800042 	mov	x2, #0x2                   	// #2
    970c:	97ffe7c1 	bl	3610 <buf_put>
    9710:	38776ac5 	ldrb	w5, [x22, x23]
    9714:	d2804003 	mov	x3, #0x200                 	// #512
    9718:	aa1803e4 	mov	x4, x24
    971c:	aa0303e1 	mov	x1, x3
    9720:	52800042 	mov	w2, #0x2                   	// #2
    9724:	aa1503e0 	mov	x0, x21
    9728:	910006f7 	add	x23, x23, #0x1
    972c:	97ffe415 	bl	2780 <__snprintf_chk@plt>
    9730:	aa1503e0 	mov	x0, x21
    9734:	97ffe3db 	bl	26a0 <strlen@plt>
    9738:	aa1503e1 	mov	x1, x21
    973c:	aa0003e2 	mov	x2, x0
    9740:	aa1403e0 	mov	x0, x20
    9744:	97ffe7b3 	bl	3610 <buf_put>
    9748:	f9400260 	ldr	x0, [x19]
    974c:	eb17001f 	cmp	x0, x23
    9750:	54fffd88 	b.hi	9700 <fwp_write+0x980>  // b.pmore
    9754:	f94143f7 	ldr	x23, [sp, #640]
    9758:	f94147f8 	ldr	x24, [sp, #648]
    975c:	f9414bf9 	ldr	x25, [sp, #656]
    9760:	f9414ffa 	ldr	x26, [sp, #664]
    9764:	52800ba3 	mov	w3, #0x5d                  	// #93
    9768:	aa1403e0 	mov	x0, x20
    976c:	91001fe1 	add	x1, sp, #0x7
    9770:	d2800022 	mov	x2, #0x1                   	// #1
    9774:	39001fe3 	strb	w3, [sp, #7]
    9778:	17fffda9 	b	8e1c <fwp_write+0x9c>
    977c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9780:	17fffe44 	b	9090 <fwp_write+0x310>
    9784:	f10002ff 	cmp	x23, #0x0
    9788:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    978c:	71002c3f 	cmp	w1, #0xb
    9790:	54ffebc0 	b.eq	9508 <fwp_write+0x788>  // b.none
    9794:	aa1303e2 	mov	x2, x19
    9798:	aa1703e1 	mov	x1, x23
    979c:	aa1403e0 	mov	x0, x20
    97a0:	52800003 	mov	w3, #0x0                   	// #0
    97a4:	97fffd77 	bl	8d80 <fwp_write>
    97a8:	17ffff6a 	b	9550 <fwp_write+0x7d0>
    97ac:	aa1403e0 	mov	x0, x20
    97b0:	91001fe1 	add	x1, sp, #0x7
    97b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    97b8:	d2800022 	mov	x2, #0x1                   	// #1
    97bc:	17fffe38 	b	909c <fwp_write+0x31c>
    97c0:	a9400281 	ldp	x1, x0, [x20]
    97c4:	91000800 	add	x0, x0, #0x2
    97c8:	8b160000 	add	x0, x0, x22
    97cc:	f9000680 	str	x0, [x20, #8]
    97d0:	3820683f 	strb	wzr, [x1, x0]
    97d4:	f9413bf5 	ldr	x21, [sp, #624]
    97d8:	f9413ff6 	ldr	x22, [sp, #632]
    97dc:	f94153fb 	ldr	x27, [sp, #672]
    97e0:	f94157fc 	ldr	x28, [sp, #680]
    97e4:	17fffd93 	b	8e30 <fwp_write+0xb0>
    97e8:	f9400f80 	ldr	x0, [x28, #24]
    97ec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    97f0:	aa1b03e0 	mov	x0, x27
    97f4:	97ffe3ab 	bl	26a0 <strlen@plt>
    97f8:	aa1b03e1 	mov	x1, x27
    97fc:	aa0003e2 	mov	x2, x0
    9800:	aa1403e0 	mov	x0, x20
    9804:	97ffe783 	bl	3610 <buf_put>
    9808:	aa1903e1 	mov	x1, x25
    980c:	aa1403e0 	mov	x0, x20
    9810:	d2800062 	mov	x2, #0x3                   	// #3
    9814:	97ffe77f 	bl	3610 <buf_put>
    9818:	17fffe10 	b	9058 <fwp_write+0x2d8>
    981c:	aa1a03e1 	mov	x1, x26
    9820:	aa1403e0 	mov	x0, x20
    9824:	d2800042 	mov	x2, #0x2                   	// #2
    9828:	97ffe77a 	bl	3610 <buf_put>
    982c:	17fffe09 	b	9050 <fwp_write+0x2d0>
    9830:	f9400660 	ldr	x0, [x19, #8]
    9834:	b4fffb00 	cbz	x0, 9794 <fwp_write+0xa14>
    9838:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    983c:	910d2021 	add	x1, x1, #0x348
    9840:	97ffe414 	bl	2890 <strcmp@plt>
    9844:	7100001f 	cmp	w0, #0x0
    9848:	1a9f07e0 	cset	w0, ne	// ne = any
    984c:	17ffff2f 	b	9508 <fwp_write+0x788>
    9850:	aa1403e0 	mov	x0, x20
    9854:	d2800042 	mov	x2, #0x2                   	// #2
    9858:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    985c:	910d0021 	add	x1, x1, #0x340
    9860:	97ffe76c 	bl	3610 <buf_put>
    9864:	91004261 	add	x1, x19, #0x10
    9868:	aa1403e0 	mov	x0, x20
    986c:	f9402382 	ldr	x2, [x28, #64]
    9870:	52800003 	mov	w3, #0x0                   	// #0
    9874:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9878:	97fffd42 	bl	8d80 <fwp_write>
    987c:	17fffd9c 	b	8eec <fwp_write+0x16c>
    9880:	1e22c109 	fcvt	d9, s8
    9884:	910123f5 	add	x21, sp, #0x48
    9888:	52800033 	mov	w19, #0x1                   	// #1
    988c:	d503201f 	nop
    9890:	1e604120 	fmov	d0, d9
    9894:	2a1303e1 	mov	w1, w19
    9898:	aa1503e0 	mov	x0, x21
    989c:	97ffe7b9 	bl	3780 <fwp_format_g.constprop.0>
    98a0:	aa1503e0 	mov	x0, x21
    98a4:	d2800001 	mov	x1, #0x0                   	// #0
    98a8:	97ffe406 	bl	28c0 <strtof@plt>
    98ac:	1e202100 	fcmp	s8, s0
    98b0:	54ffdb60 	b.eq	941c <fwp_write+0x69c>  // b.none
    98b4:	11000673 	add	w19, w19, #0x1
    98b8:	71002a7f 	cmp	w19, #0xa
    98bc:	54fffea1 	b.ne	9890 <fwp_write+0xb10>  // b.any
    98c0:	1e604120 	fmov	d0, d9
    98c4:	aa1503e0 	mov	x0, x21
    98c8:	52800121 	mov	w1, #0x9                   	// #9
    98cc:	97ffe7ad 	bl	3780 <fwp_format_g.constprop.0>
    98d0:	17fffed3 	b	941c <fwp_write+0x69c>
    98d4:	d37ef6a1 	lsl	x1, x21, #2
    98d8:	b7f81563 	tbnz	x3, #63, 9b84 <fwp_write+0xe04>
    98dc:	91002263 	add	x3, x19, #0x8
    98e0:	8b010061 	add	x1, x3, x1
    98e4:	b9400023 	ldr	w3, [x1]
    98e8:	7100081f 	cmp	w0, #0x2
    98ec:	2a0303e1 	mov	w1, w3
    98f0:	93407c63 	sxtw	x3, w3
    98f4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    98f8:	17fffe5a 	b	9260 <fwp_write+0x4e0>
    98fc:	d37ffaa1 	lsl	x1, x21, #1
    9900:	b7f81363 	tbnz	x3, #63, 9b6c <fwp_write+0xdec>
    9904:	91002263 	add	x3, x19, #0x8
    9908:	8b010061 	add	x1, x3, x1
    990c:	79400021 	ldrh	w1, [x1]
    9910:	7100041f 	cmp	w0, #0x1
    9914:	93403c23 	sxth	x3, w1
    9918:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    991c:	17fffe51 	b	9260 <fwp_write+0x4e0>
    9920:	52800443 	mov	w3, #0x22                  	// #34
    9924:	91001ff5 	add	x21, sp, #0x7
    9928:	91002273 	add	x19, x19, #0x8
    992c:	aa1503e1 	mov	x1, x21
    9930:	aa1403e0 	mov	x0, x20
    9934:	d2800022 	mov	x2, #0x1                   	// #1
    9938:	39001fe3 	strb	w3, [sp, #7]
    993c:	f90143f7 	str	x23, [sp, #640]
    9940:	8b160277 	add	x23, x19, x22
    9944:	f90147f8 	str	x24, [sp, #648]
    9948:	97ffe732 	bl	3610 <buf_put>
    994c:	b4000696 	cbz	x22, 9a1c <fwp_write+0xc9c>
    9950:	f0000018 	adrp	x24, c000 <_IO_stdin_used+0x460>
    9954:	910bc318 	add	x24, x24, #0x2f0
    9958:	f9014bf9 	str	x25, [sp, #656]
    995c:	f0000019 	adrp	x25, c000 <_IO_stdin_used+0x460>
    9960:	910c4339 	add	x25, x25, #0x310
    9964:	f9014ffa 	str	x26, [sp, #664]
    9968:	1400000d 	b	999c <fwp_write+0xc1c>
    996c:	710024bf 	cmp	w5, #0x9
    9970:	54000460 	b.eq	99fc <fwp_write+0xc7c>  // b.none
    9974:	710028bf 	cmp	w5, #0xa
    9978:	54000a61 	b.ne	9ac4 <fwp_write+0xd44>  // b.any
    997c:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9980:	aa1403e0 	mov	x0, x20
    9984:	910c0021 	add	x1, x1, #0x300
    9988:	d2800042 	mov	x2, #0x2                   	// #2
    998c:	97ffe721 	bl	3610 <buf_put>
    9990:	91000673 	add	x19, x19, #0x1
    9994:	eb17027f 	cmp	x19, x23
    9998:	540003e0 	b.eq	9a14 <fwp_write+0xc94>  // b.none
    999c:	39400265 	ldrb	w5, [x19]
    99a0:	710034bf 	cmp	w5, #0xd
    99a4:	54000180 	b.eq	99d4 <fwp_write+0xc54>  // b.none
    99a8:	54fffe29 	b.ls	996c <fwp_write+0xbec>  // b.plast
    99ac:	710088bf 	cmp	w5, #0x22
    99b0:	540001c0 	b.eq	99e8 <fwp_write+0xc68>  // b.none
    99b4:	710170bf 	cmp	w5, #0x5c
    99b8:	54000741 	b.ne	9aa0 <fwp_write+0xd20>  // b.any
    99bc:	aa1403e0 	mov	x0, x20
    99c0:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    99c4:	d2800042 	mov	x2, #0x2                   	// #2
    99c8:	910be021 	add	x1, x1, #0x2f8
    99cc:	97ffe711 	bl	3610 <buf_put>
    99d0:	17fffff0 	b	9990 <fwp_write+0xc10>
    99d4:	aa1903e1 	mov	x1, x25
    99d8:	aa1403e0 	mov	x0, x20
    99dc:	d2800042 	mov	x2, #0x2                   	// #2
    99e0:	97ffe70c 	bl	3610 <buf_put>
    99e4:	17ffffeb 	b	9990 <fwp_write+0xc10>
    99e8:	aa1803e1 	mov	x1, x24
    99ec:	aa1403e0 	mov	x0, x20
    99f0:	d2800042 	mov	x2, #0x2                   	// #2
    99f4:	97ffe707 	bl	3610 <buf_put>
    99f8:	17ffffe6 	b	9990 <fwp_write+0xc10>
    99fc:	aa1403e0 	mov	x0, x20
    9a00:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9a04:	d2800042 	mov	x2, #0x2                   	// #2
    9a08:	910c2021 	add	x1, x1, #0x308
    9a0c:	97ffe701 	bl	3610 <buf_put>
    9a10:	17ffffe0 	b	9990 <fwp_write+0xc10>
    9a14:	f9414bf9 	ldr	x25, [sp, #656]
    9a18:	f9414ffa 	ldr	x26, [sp, #664]
    9a1c:	aa1503e1 	mov	x1, x21
    9a20:	aa1403e0 	mov	x0, x20
    9a24:	52800443 	mov	w3, #0x22                  	// #34
    9a28:	17fffd9c 	b	9098 <fwp_write+0x318>
    9a2c:	7100103f 	cmp	w1, #0x4
    9a30:	54ffeb21 	b.ne	9794 <fwp_write+0xa14>  // b.any
    9a34:	f94006e0 	ldr	x0, [x23, #8]
    9a38:	d37ffc00 	lsr	x0, x0, #63
    9a3c:	17fffeb3 	b	9508 <fwp_write+0x788>
    9a40:	710002ff 	cmp	w23, #0x0
    9a44:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9a48:	17fffeb0 	b	9508 <fwp_write+0x788>
    9a4c:	528005a1 	mov	w1, #0x2d                  	// #45
    9a50:	eb0203e2 	negs	x2, x2
    9a54:	da0303e3 	ngc	x3, x3
    9a58:	910127e0 	add	x0, sp, #0x49
    9a5c:	910123f5 	add	x21, sp, #0x48
    9a60:	390123e1 	strb	w1, [sp, #72]
    9a64:	97ffe4cf 	bl	2da0 <fwp_fmt_u128>
    9a68:	17fffe18 	b	92c8 <fwp_write+0x548>
    9a6c:	d37ceea1 	lsl	x1, x21, #4
    9a70:	b7f810a3 	tbnz	x3, #63, 9c84 <fwp_write+0xf04>
    9a74:	91002260 	add	x0, x19, #0x8
    9a78:	8b010001 	add	x1, x0, x1
    9a7c:	17fffdf9 	b	9260 <fwp_write+0x4e0>
    9a80:	f9400a61 	ldr	x1, [x19, #16]
    9a84:	8b010000 	add	x0, x0, x1
    9a88:	f9400001 	ldr	x1, [x0]
    9a8c:	17fffdf5 	b	9260 <fwp_write+0x4e0>
    9a90:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9a94:	d2800042 	mov	x2, #0x2                   	// #2
    9a98:	910a6021 	add	x1, x1, #0x298
    9a9c:	17fffed6 	b	95f4 <fwp_write+0x874>
    9aa0:	7101fcbf 	cmp	w5, #0x7f
    9aa4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9aa8:	540000e9 	b.ls	9ac4 <fwp_write+0xd44>  // b.plast
    9aac:	aa1503e1 	mov	x1, x21
    9ab0:	aa1403e0 	mov	x0, x20
    9ab4:	d2800022 	mov	x2, #0x1                   	// #1
    9ab8:	39001fe5 	strb	w5, [sp, #7]
    9abc:	97ffe6d5 	bl	3610 <buf_put>
    9ac0:	17ffffb4 	b	9990 <fwp_write+0xc10>
    9ac4:	d2800203 	mov	x3, #0x10                  	// #16
    9ac8:	f0000004 	adrp	x4, c000 <_IO_stdin_used+0x460>
    9acc:	aa0303e1 	mov	x1, x3
    9ad0:	910c6084 	add	x4, x4, #0x318
    9ad4:	910123f6 	add	x22, sp, #0x48
    9ad8:	52800042 	mov	w2, #0x2                   	// #2
    9adc:	aa1603e0 	mov	x0, x22
    9ae0:	97ffe328 	bl	2780 <__snprintf_chk@plt>
    9ae4:	aa1603e0 	mov	x0, x22
    9ae8:	97ffe2ee 	bl	26a0 <strlen@plt>
    9aec:	aa1603e1 	mov	x1, x22
    9af0:	aa0003e2 	mov	x2, x0
    9af4:	aa1403e0 	mov	x0, x20
    9af8:	97ffe6c6 	bl	3610 <buf_put>
    9afc:	17ffffa5 	b	9990 <fwp_write+0xc10>
    9b00:	1e604100 	fmov	d0, d8
    9b04:	aa1503e0 	mov	x0, x21
    9b08:	52800221 	mov	w1, #0x11                  	// #17
    9b0c:	97ffe71d 	bl	3780 <fwp_format_g.constprop.0>
    9b10:	17fffe43 	b	941c <fwp_write+0x69c>
    9b14:	b9401040 	ldr	w0, [x2, #16]
    9b18:	350003c0 	cbnz	w0, 9b90 <fwp_write+0xe10>
    9b1c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9b20:	f947f400 	ldr	x0, [x0, #4072]
    9b24:	f94127e2 	ldr	x2, [sp, #584]
    9b28:	f9400001 	ldr	x1, [x0]
    9b2c:	eb010042 	subs	x2, x2, x1
    9b30:	d2800001 	mov	x1, #0x0                   	// #0
    9b34:	54ffd721 	b.ne	9618 <fwp_write+0x898>  // b.any
    9b38:	f9413bf5 	ldr	x21, [sp, #624]
    9b3c:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9b40:	f9413ff6 	ldr	x22, [sp, #632]
    9b44:	aa1403e0 	mov	x0, x20
    9b48:	f94143f7 	ldr	x23, [sp, #640]
    9b4c:	910da021 	add	x1, x1, #0x368
    9b50:	f94147f8 	ldr	x24, [sp, #648]
    9b54:	d2800042 	mov	x2, #0x2                   	// #2
    9b58:	17fffd0e 	b	8f90 <fwp_write+0x210>
    9b5c:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x460>
    9b60:	d2800042 	mov	x2, #0x2                   	// #2
    9b64:	910a8021 	add	x1, x1, #0x2a0
    9b68:	17fffea3 	b	95f4 <fwp_write+0x874>
    9b6c:	f9400a63 	ldr	x3, [x19, #16]
    9b70:	8b030021 	add	x1, x1, x3
    9b74:	17ffff66 	b	990c <fwp_write+0xb8c>
    9b78:	f9400a61 	ldr	x1, [x19, #16]
    9b7c:	8b0102a1 	add	x1, x21, x1
    9b80:	17fffdb3 	b	924c <fwp_write+0x4cc>
    9b84:	f9400a63 	ldr	x3, [x19, #16]
    9b88:	8b030021 	add	x1, x1, x3
    9b8c:	17ffff56 	b	98e4 <fwp_write+0xb64>
    9b90:	b9404840 	ldr	w0, [x2, #72]
    9b94:	91001ff5 	add	x21, sp, #0x7
    9b98:	34ffa360 	cbz	w0, 9004 <fwp_write+0x284>
    9b9c:	52800503 	mov	w3, #0x28                  	// #40
    9ba0:	aa1403e0 	mov	x0, x20
    9ba4:	aa1503e1 	mov	x1, x21
    9ba8:	d2800022 	mov	x2, #0x1                   	// #1
    9bac:	39001fe3 	strb	w3, [sp, #7]
    9bb0:	97ffe698 	bl	3610 <buf_put>
    9bb4:	b9401380 	ldr	w0, [x28, #16]
    9bb8:	52800038 	mov	w24, #0x1                   	// #1
    9bbc:	7100001f 	cmp	w0, #0x0
    9bc0:	54ffa36c 	b.gt	902c <fwp_write+0x2ac>
    9bc4:	17fffd32 	b	908c <fwp_write+0x30c>
    9bc8:	f9014bf9 	str	x25, [sp, #656]
    9bcc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10060>
    9bd0:	f9014ffa 	str	x26, [sp, #664]
    9bd4:	f9400676 	ldr	x22, [x19, #8]
    9bd8:	91104333 	add	x19, x25, #0x410
    9bdc:	91002273 	add	x19, x19, #0x8
    9be0:	937ffed8 	asr	x24, x22, #63
    9be4:	aa1802c0 	orr	x0, x22, x24
    9be8:	b5000320 	cbnz	x0, 9c4c <fwp_write+0xecc>
    9bec:	110006b5 	add	w21, w21, #0x1
    9bf0:	710016bf 	cmp	w21, #0x5
    9bf4:	54ffffc1 	b.ne	9bec <fwp_write+0xe6c>  // b.any
    9bf8:	b7f80578 	tbnz	x24, #63, 9ca4 <fwp_write+0xf24>
    9bfc:	910023f3 	add	x19, sp, #0x8
    9c00:	aa1603e2 	mov	x2, x22
    9c04:	aa1303e0 	mov	x0, x19
    9c08:	d2800003 	mov	x3, #0x0                   	// #0
    9c0c:	97ffe465 	bl	2da0 <fwp_fmt_u128>
    9c10:	910123f5 	add	x21, sp, #0x48
    9c14:	f0000003 	adrp	x3, c000 <_IO_stdin_used+0x460>
    9c18:	aa1303e4 	mov	x4, x19
    9c1c:	aa1503e0 	mov	x0, x21
    9c20:	910d8063 	add	x3, x3, #0x360
    9c24:	d2804002 	mov	x2, #0x200                 	// #512
    9c28:	52800041 	mov	w1, #0x2                   	// #2
    9c2c:	97ffe2a1 	bl	26b0 <__sprintf_chk@plt>
    9c30:	aa1503e0 	mov	x0, x21
    9c34:	97ffe29b 	bl	26a0 <strlen@plt>
    9c38:	aa1503e1 	mov	x1, x21
    9c3c:	aa0003e2 	mov	x2, x0
    9c40:	aa1403e0 	mov	x0, x20
    9c44:	97ffe673 	bl	3610 <buf_put>
    9c48:	17fffe47 	b	9564 <fwp_write+0x7e4>
    9c4c:	f9400277 	ldr	x23, [x19]
    9c50:	aa1603e0 	mov	x0, x22
    9c54:	aa1803e1 	mov	x1, x24
    9c58:	aa1703e2 	mov	x2, x23
    9c5c:	937ffefa 	asr	x26, x23, #63
    9c60:	aa1a03e3 	mov	x3, x26
    9c64:	940006e7 	bl	b800 <__modti3>
    9c68:	aa010000 	orr	x0, x0, x1
    9c6c:	b40002c0 	cbz	x0, 9cc4 <fwp_write+0xf44>
    9c70:	110006b5 	add	w21, w21, #0x1
    9c74:	91004273 	add	x19, x19, #0x10
    9c78:	710016bf 	cmp	w21, #0x5
    9c7c:	54fffe81 	b.ne	9c4c <fwp_write+0xecc>  // b.any
    9c80:	17ffffde 	b	9bf8 <fwp_write+0xe78>
    9c84:	f9400a60 	ldr	x0, [x19, #16]
    9c88:	8b000021 	add	x1, x1, x0
    9c8c:	17fffd75 	b	9260 <fwp_write+0x4e0>
    9c90:	528c29c0 	mov	w0, #0x614e                	// #24910
    9c94:	910123f5 	add	x21, sp, #0x48
    9c98:	72a009c0 	movk	w0, #0x4e, lsl #16
    9c9c:	b9004be0 	str	w0, [sp, #72]
    9ca0:	17fffda2 	b	9328 <fwp_write+0x5a8>
    9ca4:	528005a1 	mov	w1, #0x2d                  	// #45
    9ca8:	eb1603e2 	negs	x2, x22
    9cac:	da1803e3 	ngc	x3, x24
    9cb0:	910027e0 	add	x0, sp, #0x9
    9cb4:	910023f3 	add	x19, sp, #0x8
    9cb8:	390023e1 	strb	w1, [sp, #8]
    9cbc:	97ffe439 	bl	2da0 <fwp_fmt_u128>
    9cc0:	17ffffd4 	b	9c10 <fwp_write+0xe90>
    9cc4:	aa1703e2 	mov	x2, x23
    9cc8:	aa1a03e3 	mov	x3, x26
    9ccc:	aa1603e0 	mov	x0, x22
    9cd0:	aa1803e1 	mov	x1, x24
    9cd4:	940005eb 	bl	b480 <__divti3>
    9cd8:	aa0003e2 	mov	x2, x0
    9cdc:	aa0103e3 	mov	x3, x1
    9ce0:	b7f80201 	tbnz	x1, #63, 9d20 <fwp_write+0xfa0>
    9ce4:	910023f3 	add	x19, sp, #0x8
    9ce8:	aa1303e0 	mov	x0, x19
    9cec:	97ffe42d 	bl	2da0 <fwp_fmt_u128>
    9cf0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9cf4:	91104339 	add	x25, x25, #0x410
    9cf8:	910123f5 	add	x21, sp, #0x48
    9cfc:	aa1303e4 	mov	x4, x19
    9d00:	aa1503e0 	mov	x0, x21
    9d04:	f0000003 	adrp	x3, c000 <_IO_stdin_used+0x460>
    9d08:	f8616b25 	ldr	x5, [x25, x1]
    9d0c:	910d6063 	add	x3, x3, #0x358
    9d10:	d2804002 	mov	x2, #0x200                 	// #512
    9d14:	52800041 	mov	w1, #0x2                   	// #2
    9d18:	97ffe266 	bl	26b0 <__sprintf_chk@plt>
    9d1c:	17ffffc5 	b	9c30 <fwp_write+0xeb0>
    9d20:	528005a4 	mov	w4, #0x2d                  	// #45
    9d24:	eb0003e2 	negs	x2, x0
    9d28:	da0103e3 	ngc	x3, x1
    9d2c:	910027e0 	add	x0, sp, #0x9
    9d30:	910023f3 	add	x19, sp, #0x8
    9d34:	390023e4 	strb	w4, [sp, #8]
    9d38:	97ffe41a 	bl	2da0 <fwp_fmt_u128>
    9d3c:	17ffffed 	b	9cf0 <fwp_write+0xf70>
    9d40:	f9013bf5 	str	x21, [sp, #624]
    9d44:	f9013ff6 	str	x22, [sp, #632]
    9d48:	f90143f7 	str	x23, [sp, #640]
    9d4c:	f90147f8 	str	x24, [sp, #648]
    9d50:	f9014bf9 	str	x25, [sp, #656]
    9d54:	f9014ffa 	str	x26, [sp, #664]
    9d58:	f90153fb 	str	x27, [sp, #672]
    9d5c:	f90157fc 	str	x28, [sp, #680]
    9d60:	fd015be8 	str	d8, [sp, #688]
    9d64:	fd015fe9 	str	d9, [sp, #696]
    9d68:	97ffe2aa 	bl	2810 <__stack_chk_fail@plt>
    9d6c:	d503201f 	nop

0000000000009d70 <fwp_main_thread>:
    9d70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9d74:	910003fd 	mov	x29, sp
    9d78:	a9046bf9 	stp	x25, x26, [sp, #64]
    9d7c:	90000399 	adrp	x25, 79000 <fwp_root_context+0xba0>
    9d80:	91190321 	add	x1, x25, #0x640
    9d84:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9d88:	f947f400 	ldr	x0, [x0, #4072]
    9d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    9d90:	a9025bf5 	stp	x21, x22, [sp, #32]
    9d94:	a90363f7 	stp	x23, x24, [sp, #48]
    9d98:	a90573fb 	stp	x27, x28, [sp, #80]
    9d9c:	d10643ff 	sub	sp, sp, #0x190
    9da0:	b953a421 	ldr	w1, [x1, #5028]
    9da4:	f9400002 	ldr	x2, [x0]
    9da8:	f81f83a2 	stur	x2, [x29, #-8]
    9dac:	d2800002 	mov	x2, #0x0                   	// #0
    9db0:	34000f41 	cbz	w1, 9f98 <fwp_main_thread+0x228>
    9db4:	91190320 	add	x0, x25, #0x640
    9db8:	b953a800 	ldr	w0, [x0, #5032]
    9dbc:	35000e60 	cbnz	w0, 9f88 <fwp_main_thread+0x218>
    9dc0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9dc4:	f00000a2 	adrp	x2, 20000 <__data_start>
    9dc8:	91018015 	add	x21, x0, #0x60
    9dcc:	91118042 	add	x2, x2, #0x460
    9dd0:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9dd4:	d2a00024 	mov	x4, #0x10000               	// #65536
    9dd8:	d10383b4 	sub	x20, x29, #0xe0
    9ddc:	d103e3b6 	sub	x22, x29, #0xf8
    9de0:	aa1403e0 	mov	x0, x20
    9de4:	d2800001 	mov	x1, #0x0                   	// #0
    9de8:	f81203a2 	stur	x2, [x29, #-224]
    9dec:	b81283bf 	stur	wzr, [x29, #-216]
    9df0:	f81303a4 	stur	x4, [x29, #-208]
    9df4:	a90a0eb6 	stp	x22, x3, [x21, #160]
    9df8:	97ffe21e 	bl	2670 <sigaltstack@plt>
    9dfc:	35000220 	cbnz	w0, 9e40 <fwp_main_thread+0xd0>
    9e00:	4f000400 	movi	v0.4s, #0x0
    9e04:	d10263a0 	sub	x0, x29, #0x98
    9e08:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    9e0c:	9100c021 	add	x1, x1, #0x30
    9e10:	f81603a1 	stur	x1, [x29, #-160]
    9e14:	52800082 	mov	w2, #0x4                   	// #4
    9e18:	72a10002 	movk	w2, #0x800, lsl #16
    9e1c:	d10283b7 	sub	x23, x29, #0xa0
    9e20:	3d802000 	str	q0, [x0, #128]
    9e24:	b81e83a2 	stur	w2, [x29, #-24]
    9e28:	ad000000 	stp	q0, q0, [x0]
    9e2c:	ad010000 	stp	q0, q0, [x0, #32]
    9e30:	ad020000 	stp	q0, q0, [x0, #64]
    9e34:	ad030000 	stp	q0, q0, [x0, #96]
    9e38:	97ffe266 	bl	27d0 <sigemptyset@plt>
    9e3c:	34000080 	cbz	w0, 9e4c <fwp_main_thread+0xdc>
    9e40:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x460>
    9e44:	910de000 	add	x0, x0, #0x378
    9e48:	97ffe91b 	bl	42b4 <fwp_trap>
    9e4c:	aa1703e1 	mov	x1, x23
    9e50:	d2800002 	mov	x2, #0x0                   	// #0
    9e54:	52800160 	mov	w0, #0xb                   	// #11
    9e58:	97ffe276 	bl	2830 <sigaction@plt>
    9e5c:	35ffff20 	cbnz	w0, 9e40 <fwp_main_thread+0xd0>
    9e60:	aa1703e1 	mov	x1, x23
    9e64:	d2800002 	mov	x2, #0x0                   	// #0
    9e68:	528000e0 	mov	w0, #0x7                   	// #7
    9e6c:	97ffe271 	bl	2830 <sigaction@plt>
    9e70:	35fffe80 	cbnz	w0, 9e40 <fwp_main_thread+0xd0>
    9e74:	9119033c 	add	x28, x25, #0x640
    9e78:	52800033 	mov	w19, #0x1                   	// #1
    9e7c:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9e80:	910cc000 	add	x0, x0, #0x330
    9e84:	b90132b3 	str	w19, [x21, #304]
    9e88:	fd4a1380 	ldr	d0, [x28, #5152]
    9e8c:	7e61d800 	ucvtf	d0, d0
    9e90:	fd00a6a0 	str	d0, [x21, #328]
    9e94:	94000737 	bl	bb70 <atexit>
    9e98:	3500a840 	cbnz	w0, b3a0 <fwp_main_thread+0x1630>
    9e9c:	b943caa0 	ldr	w0, [x21, #968]
    9ea0:	34000800 	cbz	w0, 9fa0 <fwp_main_thread+0x230>
    9ea4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ea8:	91018018 	add	x24, x0, #0x60
    9eac:	f9404f14 	ldr	x20, [x24, #152]
    9eb0:	b4007854 	cbz	x20, adb8 <fwp_main_thread+0x1048>
    9eb4:	91010295 	add	x21, x20, #0x40
    9eb8:	39414a97 	ldrb	w23, [x20, #82]
    9ebc:	52800036 	mov	w22, #0x1                   	// #1
    9ec0:	39014a96 	strb	w22, [x20, #82]
    9ec4:	d503201f 	nop
    9ec8:	f9401680 	ldr	x0, [x20, #40]
    9ecc:	b4007740 	cbz	x0, adb4 <fwp_main_thread+0x1044>
    9ed0:	f9403281 	ldr	x1, [x20, #96]
    9ed4:	39414680 	ldrb	w0, [x20, #81]
    9ed8:	b4004001 	cbz	x1, a6d8 <fwp_main_thread+0x968>
    9edc:	36003ec0 	tbz	w0, #0, a6b4 <fwp_main_thread+0x944>
    9ee0:	f9404f13 	ldr	x19, [x24, #152]
    9ee4:	f9402280 	ldr	x0, [x20, #64]
    9ee8:	39414a61 	ldrb	w1, [x19, #82]
    9eec:	37007541 	tbnz	w1, #0, ad94 <fwp_main_thread+0x1024>
    9ef0:	f9403261 	ldr	x1, [x19, #96]
    9ef4:	a911fe75 	stp	x21, xzr, [x19, #280]
    9ef8:	f9009660 	str	x0, [x19, #296]
    9efc:	b4000040 	cbz	x0, 9f04 <fwp_main_thread+0x194>
    9f00:	f9009013 	str	x19, [x0, #288]
    9f04:	f9002293 	str	x19, [x20, #64]
    9f08:	b4000101 	cbz	x1, 9f28 <fwp_main_thread+0x1b8>
    9f0c:	f9409700 	ldr	x0, [x24, #296]
    9f10:	39015676 	strb	w22, [x19, #85]
    9f14:	f9003661 	str	x1, [x19, #104]
    9f18:	a910827f 	stp	xzr, x0, [x19, #264]
    9f1c:	b4000040 	cbz	x0, 9f24 <fwp_main_thread+0x1b4>
    9f20:	f9008413 	str	x19, [x0, #264]
    9f24:	f9009713 	str	x19, [x24, #296]
    9f28:	39015a7f 	strb	wzr, [x19, #86]
    9f2c:	97fff381 	bl	6d30 <fwp_block>
    9f30:	f9408e62 	ldr	x2, [x19, #280]
    9f34:	b4000142 	cbz	x2, 9f5c <fwp_main_thread+0x1ec>
    9f38:	a9520261 	ldp	x1, x0, [x19, #288]
    9f3c:	b4007381 	cbz	x1, adac <fwp_main_thread+0x103c>
    9f40:	f9009420 	str	x0, [x1, #296]
    9f44:	f9409660 	ldr	x0, [x19, #296]
    9f48:	b4000040 	cbz	x0, 9f50 <fwp_main_thread+0x1e0>
    9f4c:	f9009001 	str	x1, [x0, #288]
    9f50:	91080260 	add	x0, x19, #0x200
    9f54:	f900967f 	str	xzr, [x19, #296]
    9f58:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9f5c:	39415660 	ldrb	w0, [x19, #85]
    9f60:	3607fb40 	tbz	w0, #0, 9ec8 <fwp_main_thread+0x158>
    9f64:	a9508261 	ldp	x1, x0, [x19, #264]
    9f68:	b4008961 	cbz	x1, b094 <fwp_main_thread+0x1324>
    9f6c:	f9008820 	str	x0, [x1, #272]
    9f70:	b4000040 	cbz	x0, 9f78 <fwp_main_thread+0x208>
    9f74:	f9008401 	str	x1, [x0, #264]
    9f78:	91080260 	add	x0, x19, #0x200
    9f7c:	3901567f 	strb	wzr, [x19, #85]
    9f80:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9f84:	17ffffd1 	b	9ec8 <fwp_main_thread+0x158>
    9f88:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9f8c:	912e1000 	add	x0, x0, #0xb84
    9f90:	940006f8 	bl	bb70 <atexit>
    9f94:	17ffff8b 	b	9dc0 <fwp_main_thread+0x50>
    9f98:	97ffe756 	bl	3cf0 <fwp_heap_init>
    9f9c:	17ffff86 	b	9db4 <fwp_main_thread+0x44>
    9fa0:	b0ffffe0 	adrp	x0, 6000 <fwp_rc_dup+0x8c>
    9fa4:	91098000 	add	x0, x0, #0x260
    9fa8:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9fac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9fb0:	d2800018 	mov	x24, #0x0                   	// #0
    9fb4:	f941caa2 	ldr	x2, [x21, #912]
    9fb8:	a931ffb4 	stp	x20, xzr, [x29, #-232]
    9fbc:	2a1303fb 	mov	w27, w19
    9fc0:	f901cab6 	str	x22, [x21, #912]
    9fc4:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9fc8:	f91f7814 	str	x20, [x0, #16112]
    9fcc:	aa1c03f4 	mov	x20, x28
    9fd0:	f91f7c16 	str	x22, [x0, #16120]
    9fd4:	aa1803f6 	mov	x22, x24
    9fd8:	913b4021 	add	x1, x1, #0xed0
    9fdc:	d2800013 	mov	x19, #0x0                   	// #0
    9fe0:	d280041a 	mov	x26, #0x20                  	// #32
    9fe4:	a93087a2 	stp	x2, x1, [x29, #-248]
    9fe8:	f1000755 	subs	x21, x26, #0x1
    9fec:	aa1703e1 	mov	x1, x23
    9ff0:	da1f02dc 	sbc	x28, x22, xzr
    9ff4:	52800020 	mov	w0, #0x1                   	// #1
    9ff8:	f81283b5 	stur	x21, [x29, #-216]
    9ffc:	a9364fb5 	stp	x21, x19, [x29, #-160]
    a000:	97ffef39 	bl	5ce4 <fwp_data.part.0.constprop.0>
    a004:	aa0003f3 	mov	x19, x0
    a008:	f949da81 	ldr	x1, [x20, #5040]
    a00c:	aa1503fa 	mov	x26, x21
    a010:	f949ee80 	ldr	x0, [x20, #5080]
    a014:	cb010261 	sub	x1, x19, x1
    a018:	aa1c03f6 	mov	x22, x28
    a01c:	eb00403f 	cmp	x1, x0, lsl #16
    a020:	54000302 	b.cs	a080 <fwp_main_thread+0x310>  // b.hs, b.nlast
    a024:	d350fc22 	lsr	x2, x1, #16
    a028:	f949fe84 	ldr	x4, [x20, #5112]
    a02c:	8b020842 	add	x2, x2, x2, lsl #2
    a030:	d37df042 	lsl	x2, x2, #3
    a034:	8b020080 	add	x0, x4, x2
    a038:	f9401018 	ldr	x24, [x0, #32]
    a03c:	b4000238 	cbz	x24, a080 <fwp_main_thread+0x310>
    a040:	38626882 	ldrb	w2, [x4, x2]
    a044:	7100085f 	cmp	w2, #0x2
    a048:	54008060 	b.eq	b054 <fwp_main_thread+0x12e4>  // b.none
    a04c:	7100045f 	cmp	w2, #0x1
    a050:	54000181 	b.ne	a080 <fwp_main_thread+0x310>  // b.any
    a054:	29430002 	ldp	w2, w0, [x0, #24]
    a058:	92403c21 	and	x1, x1, #0xffff
    a05c:	9b027c21 	mul	x1, x1, x2
    a060:	d360fc21 	lsr	x1, x1, #32
    a064:	eb00003f 	cmp	x1, x0
    a068:	540000c2 	b.cs	a080 <fwp_main_thread+0x310>  // b.hs, b.nlast
    a06c:	8b010318 	add	x24, x24, x1
    a070:	39400300 	ldrb	w0, [x24]
    a074:	7103fc1f 	cmp	w0, #0xff
    a078:	54003140 	b.eq	a6a0 <fwp_main_thread+0x930>  // b.none
    a07c:	3900031b 	strb	w27, [x24]
    a080:	a9327fb3 	stp	x19, xzr, [x29, #-224]
    a084:	aa1c02b5 	orr	x21, x21, x28
    a088:	b5fffb15 	cbnz	x21, 9fe8 <fwp_main_thread+0x278>
    a08c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a090:	f81203bf 	stur	xzr, [x29, #-224]
    a094:	f95f7814 	ldr	x20, [x0, #16112]
    a098:	f95f7c16 	ldr	x22, [x0, #16120]
    a09c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0a0:	91018002 	add	x2, x0, #0x60
    a0a4:	f941c840 	ldr	x0, [x2, #912]
    a0a8:	eb16001f 	cmp	x0, x22
    a0ac:	54009e21 	b.ne	b470 <fwp_main_thread+0x1700>  // b.any
    a0b0:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0x460>
    a0b4:	d10303a1 	sub	x1, x29, #0xc0
    a0b8:	f85083a3 	ldur	x3, [x29, #-248]
    a0bc:	f901c843 	str	x3, [x2, #912]
    a0c0:	3dc2d800 	ldr	q0, [x0, #2912]
    a0c4:	52800020 	mov	w0, #0x1                   	// #1
    a0c8:	3c9403a0 	stur	q0, [x29, #-192]
    a0cc:	97ffef06 	bl	5ce4 <fwp_data.part.0.constprop.0>
    a0d0:	91190323 	add	x3, x25, #0x640
    a0d4:	aa0003f5 	mov	x21, x0
    a0d8:	f949d861 	ldr	x1, [x3, #5040]
    a0dc:	f949ec60 	ldr	x0, [x3, #5080]
    a0e0:	cb0102a1 	sub	x1, x21, x1
    a0e4:	eb00403f 	cmp	x1, x0, lsl #16
    a0e8:	54000322 	b.cs	a14c <fwp_main_thread+0x3dc>  // b.hs, b.nlast
    a0ec:	d350fc22 	lsr	x2, x1, #16
    a0f0:	f949fc63 	ldr	x3, [x3, #5112]
    a0f4:	8b020842 	add	x2, x2, x2, lsl #2
    a0f8:	d37df042 	lsl	x2, x2, #3
    a0fc:	8b020060 	add	x0, x3, x2
    a100:	f9401016 	ldr	x22, [x0, #32]
    a104:	b4000256 	cbz	x22, a14c <fwp_main_thread+0x3dc>
    a108:	38626862 	ldrb	w2, [x3, x2]
    a10c:	7100085f 	cmp	w2, #0x2
    a110:	540081e0 	b.eq	b14c <fwp_main_thread+0x13dc>  // b.none
    a114:	7100045f 	cmp	w2, #0x1
    a118:	540001a1 	b.ne	a14c <fwp_main_thread+0x3dc>  // b.any
    a11c:	29430002 	ldp	w2, w0, [x0, #24]
    a120:	92403c21 	and	x1, x1, #0xffff
    a124:	9b027c21 	mul	x1, x1, x2
    a128:	d360fc21 	lsr	x1, x1, #32
    a12c:	eb00003f 	cmp	x1, x0
    a130:	540000e2 	b.cs	a14c <fwp_main_thread+0x3dc>  // b.hs, b.nlast
    a134:	8b0102d6 	add	x22, x22, x1
    a138:	394002c0 	ldrb	w0, [x22]
    a13c:	7103fc1f 	cmp	w0, #0xff
    a140:	540084a0 	b.eq	b1d4 <fwp_main_thread+0x1464>  // b.none
    a144:	52800020 	mov	w0, #0x1                   	// #1
    a148:	390002c0 	strb	w0, [x22]
    a14c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a150:	aa1703e1 	mov	x1, x23
    a154:	52800020 	mov	w0, #0x1                   	// #1
    a158:	a93657a2 	stp	x2, x21, [x29, #-160]
    a15c:	97ffeee2 	bl	5ce4 <fwp_data.part.0.constprop.0>
    a160:	91190323 	add	x3, x25, #0x640
    a164:	aa0003f5 	mov	x21, x0
    a168:	f949d861 	ldr	x1, [x3, #5040]
    a16c:	f949ec60 	ldr	x0, [x3, #5080]
    a170:	cb0102a1 	sub	x1, x21, x1
    a174:	eb00403f 	cmp	x1, x0, lsl #16
    a178:	54000322 	b.cs	a1dc <fwp_main_thread+0x46c>  // b.hs, b.nlast
    a17c:	d350fc22 	lsr	x2, x1, #16
    a180:	f949fc63 	ldr	x3, [x3, #5112]
    a184:	8b020842 	add	x2, x2, x2, lsl #2
    a188:	d37df042 	lsl	x2, x2, #3
    a18c:	8b020060 	add	x0, x3, x2
    a190:	f9401016 	ldr	x22, [x0, #32]
    a194:	b4000256 	cbz	x22, a1dc <fwp_main_thread+0x46c>
    a198:	38626862 	ldrb	w2, [x3, x2]
    a19c:	7100085f 	cmp	w2, #0x2
    a1a0:	54007dc0 	b.eq	b158 <fwp_main_thread+0x13e8>  // b.none
    a1a4:	7100045f 	cmp	w2, #0x1
    a1a8:	540001a1 	b.ne	a1dc <fwp_main_thread+0x46c>  // b.any
    a1ac:	29430002 	ldp	w2, w0, [x0, #24]
    a1b0:	92403c21 	and	x1, x1, #0xffff
    a1b4:	9b027c21 	mul	x1, x1, x2
    a1b8:	d360fc21 	lsr	x1, x1, #32
    a1bc:	eb00003f 	cmp	x1, x0
    a1c0:	540000e2 	b.cs	a1dc <fwp_main_thread+0x46c>  // b.hs, b.nlast
    a1c4:	8b0102d6 	add	x22, x22, x1
    a1c8:	394002c0 	ldrb	w0, [x22]
    a1cc:	7103fc1f 	cmp	w0, #0xff
    a1d0:	54008080 	b.eq	b1e0 <fwp_main_thread+0x1470>  // b.none
    a1d4:	52800020 	mov	w0, #0x1                   	// #1
    a1d8:	390002c0 	strb	w0, [x22]
    a1dc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a1e0:	d102c3a1 	sub	x1, x29, #0xb0
    a1e4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a1e8:	52800020 	mov	w0, #0x1                   	// #1
    a1ec:	a93557a2 	stp	x2, x21, [x29, #-176]
    a1f0:	97ffeebd 	bl	5ce4 <fwp_data.part.0.constprop.0>
    a1f4:	91190322 	add	x2, x25, #0x640
    a1f8:	aa0003f7 	mov	x23, x0
    a1fc:	f949d841 	ldr	x1, [x2, #5040]
    a200:	f949ec40 	ldr	x0, [x2, #5080]
    a204:	cb0102e1 	sub	x1, x23, x1
    a208:	eb00403f 	cmp	x1, x0, lsl #16
    a20c:	54000322 	b.cs	a270 <fwp_main_thread+0x500>  // b.hs, b.nlast
    a210:	d350fc20 	lsr	x0, x1, #16
    a214:	f949fc43 	ldr	x3, [x2, #5112]
    a218:	8b000800 	add	x0, x0, x0, lsl #2
    a21c:	d37df002 	lsl	x2, x0, #3
    a220:	8b020060 	add	x0, x3, x2
    a224:	f9401015 	ldr	x21, [x0, #32]
    a228:	b4000255 	cbz	x21, a270 <fwp_main_thread+0x500>
    a22c:	38626862 	ldrb	w2, [x3, x2]
    a230:	7100085f 	cmp	w2, #0x2
    a234:	54007980 	b.eq	b164 <fwp_main_thread+0x13f4>  // b.none
    a238:	7100045f 	cmp	w2, #0x1
    a23c:	540001a1 	b.ne	a270 <fwp_main_thread+0x500>  // b.any
    a240:	29430002 	ldp	w2, w0, [x0, #24]
    a244:	92403c21 	and	x1, x1, #0xffff
    a248:	9b027c21 	mul	x1, x1, x2
    a24c:	d360fc21 	lsr	x1, x1, #32
    a250:	eb00003f 	cmp	x1, x0
    a254:	540000e2 	b.cs	a270 <fwp_main_thread+0x500>  // b.hs, b.nlast
    a258:	8b0102b5 	add	x21, x21, x1
    a25c:	394002a0 	ldrb	w0, [x21]
    a260:	7103fc1f 	cmp	w0, #0xff
    a264:	54007c40 	b.eq	b1ec <fwp_main_thread+0x147c>  // b.none
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	390002a0 	strb	w0, [x21]
    a270:	d00000a4 	adrp	x4, 20000 <__data_start>
    a274:	9100409c 	add	x28, x4, #0x10
    a278:	d00000a0 	adrp	x0, 20000 <__data_start>
    a27c:	9100a387 	add	x7, x28, #0x28
    a280:	aa1303e6 	mov	x6, x19
    a284:	91018018 	add	x24, x0, #0x60
    a288:	b4004273 	cbz	x19, aad4 <fwp_main_thread+0xd64>
    a28c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a290:	aa1803fc 	mov	x28, x24
    a294:	aa1303f8 	mov	x24, x19
    a298:	aa0403f3 	mov	x19, x4
    a29c:	f91f5006 	str	x6, [x0, #16032]
    a2a0:	f91f5407 	str	x7, [x0, #16040]
    a2a4:	91190321 	add	x1, x25, #0x640
    a2a8:	f949d822 	ldr	x2, [x1, #5040]
    a2ac:	f949ec20 	ldr	x0, [x1, #5080]
    a2b0:	cb0202e2 	sub	x2, x23, x2
    a2b4:	eb00405f 	cmp	x2, x0, lsl #16
    a2b8:	54000422 	b.cs	a33c <fwp_main_thread+0x5cc>  // b.hs, b.nlast
    a2bc:	d350fc40 	lsr	x0, x2, #16
    a2c0:	f949fc24 	ldr	x4, [x1, #5112]
    a2c4:	8b000800 	add	x0, x0, x0, lsl #2
    a2c8:	d37df001 	lsl	x1, x0, #3
    a2cc:	8b010083 	add	x3, x4, x1
    a2d0:	f9401060 	ldr	x0, [x3, #32]
    a2d4:	b4000340 	cbz	x0, a33c <fwp_main_thread+0x5cc>
    a2d8:	38616881 	ldrb	w1, [x4, x1]
    a2dc:	7100083f 	cmp	w1, #0x2
    a2e0:	54007480 	b.eq	b170 <fwp_main_thread+0x1400>  // b.none
    a2e4:	7100043f 	cmp	w1, #0x1
    a2e8:	540002a1 	b.ne	a33c <fwp_main_thread+0x5cc>  // b.any
    a2ec:	92403c41 	and	x1, x2, #0xffff
    a2f0:	29430864 	ldp	w4, w2, [x3, #24]
    a2f4:	9b047c21 	mul	x1, x1, x4
    a2f8:	d360fc21 	lsr	x1, x1, #32
    a2fc:	eb02003f 	cmp	x1, x2
    a300:	540001e2 	b.cs	a33c <fwp_main_thread+0x5cc>  // b.hs, b.nlast
    a304:	8b010000 	add	x0, x0, x1
    a308:	39400001 	ldrb	w1, [x0]
    a30c:	34000181 	cbz	w1, a33c <fwp_main_thread+0x5cc>
    a310:	d00000a2 	adrp	x2, 20000 <__data_start>
    a314:	91018042 	add	x2, x2, #0x60
    a318:	b9413043 	ldr	w3, [x2, #304]
    a31c:	34000083 	cbz	w3, a32c <fwp_main_thread+0x5bc>
    a320:	f940ac43 	ldr	x3, [x2, #344]
    a324:	91000463 	add	x3, x3, #0x1
    a328:	f900ac43 	str	x3, [x2, #344]
    a32c:	7103f43f 	cmp	w1, #0xfd
    a330:	54007768 	b.hi	b21c <fwp_main_thread+0x14ac>  // b.pmore
    a334:	11000421 	add	w1, w1, #0x1
    a338:	39000001 	strb	w1, [x0]
    a33c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a340:	d28018e0 	mov	x0, #0xc7                  	// #199
    a344:	f95f543b 	ldr	x27, [x1, #16040]
    a348:	f91f4438 	str	x24, [x1, #16008]
    a34c:	f91f4837 	str	x23, [x1, #16016]
    a350:	f91f4c33 	str	x19, [x1, #16024]
    a354:	f91f5820 	str	x0, [x1, #16048]
    a358:	b9400362 	ldr	w2, [x27]
    a35c:	f9408f83 	ldr	x3, [x28, #280]
    a360:	d37be842 	lsl	x2, x2, #5
    a364:	8b020064 	add	x4, x3, x2
    a368:	f9400c81 	ldr	x1, [x4, #24]
    a36c:	f81203b7 	stur	x23, [x29, #-224]
    a370:	b4007441 	cbz	x1, b1f8 <fwp_main_thread+0x1488>
    a374:	f9400c20 	ldr	x0, [x1, #24]
    a378:	b4006740 	cbz	x0, b060 <fwp_main_thread+0x12f0>
    a37c:	91190322 	add	x2, x25, #0x640
    a380:	f949d841 	ldr	x1, [x2, #5040]
    a384:	f949ec40 	ldr	x0, [x2, #5080]
    a388:	cb010361 	sub	x1, x27, x1
    a38c:	eb00403f 	cmp	x1, x0, lsl #16
    a390:	540003e2 	b.cs	a40c <fwp_main_thread+0x69c>  // b.hs, b.nlast
    a394:	d350fc20 	lsr	x0, x1, #16
    a398:	f949fc45 	ldr	x5, [x2, #5112]
    a39c:	8b000800 	add	x0, x0, x0, lsl #2
    a3a0:	d37df002 	lsl	x2, x0, #3
    a3a4:	8b0200a3 	add	x3, x5, x2
    a3a8:	f9401060 	ldr	x0, [x3, #32]
    a3ac:	b4000300 	cbz	x0, a40c <fwp_main_thread+0x69c>
    a3b0:	386268a2 	ldrb	w2, [x5, x2]
    a3b4:	7100085f 	cmp	w2, #0x2
    a3b8:	54006760 	b.eq	b0a4 <fwp_main_thread+0x1334>  // b.none
    a3bc:	7100045f 	cmp	w2, #0x1
    a3c0:	54000261 	b.ne	a40c <fwp_main_thread+0x69c>  // b.any
    a3c4:	29430865 	ldp	w5, w2, [x3, #24]
    a3c8:	92403c21 	and	x1, x1, #0xffff
    a3cc:	9b057c21 	mul	x1, x1, x5
    a3d0:	d360fc21 	lsr	x1, x1, #32
    a3d4:	eb02003f 	cmp	x1, x2
    a3d8:	540001a2 	b.cs	a40c <fwp_main_thread+0x69c>  // b.hs, b.nlast
    a3dc:	8b010000 	add	x0, x0, x1
    a3e0:	39400001 	ldrb	w1, [x0]
    a3e4:	34000141 	cbz	w1, a40c <fwp_main_thread+0x69c>
    a3e8:	b9413382 	ldr	w2, [x28, #304]
    a3ec:	34000082 	cbz	w2, a3fc <fwp_main_thread+0x68c>
    a3f0:	f940af82 	ldr	x2, [x28, #344]
    a3f4:	91000442 	add	x2, x2, #0x1
    a3f8:	f900af82 	str	x2, [x28, #344]
    a3fc:	7103f43f 	cmp	w1, #0xfd
    a400:	54006de8 	b.hi	b1bc <fwp_main_thread+0x144c>  // b.pmore
    a404:	11000421 	add	w1, w1, #0x1
    a408:	39000001 	strb	w1, [x0]
    a40c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a410:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a414:	aa1b03f7 	mov	x23, x27
    a418:	5280003a 	mov	w26, #0x1                   	// #1
    a41c:	91190321 	add	x1, x25, #0x640
    a420:	f91f7414 	str	x20, [x0, #16104]
    a424:	aa1b03e0 	mov	x0, x27
    a428:	f91f6054 	str	x20, [x2, #16064]
    a42c:	f91f645b 	str	x27, [x2, #16072]
    a430:	b93ee05a 	str	w26, [x2, #16096]
    a434:	b93ee45a 	str	w26, [x2, #16100]
    a438:	f91f7c41 	str	x1, [x2, #16120]
    a43c:	b9400401 	ldr	w1, [x0, #4]
    a440:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a444:	b9400096 	ldr	w22, [x4]
    a448:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a44c:	b97ee400 	ldr	w0, [x0, #16100]
    a450:	4b0102d6 	sub	w22, w22, w1
    a454:	6b0002df 	cmp	w22, w0
    a458:	1a8092c6 	csel	w6, w22, w0, ls	// ls = plast
    a45c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a460:	b97ee000 	ldr	w0, [x0, #16096]
    a464:	6b0000df 	cmp	w6, w0
    a468:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    a46c:	b93edc40 	str	w0, [x2, #16092]
    a470:	6b0000c2 	subs	w2, w6, w0
    a474:	54000180 	b.eq	a4a4 <fwp_main_thread+0x734>  // b.none
    a478:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a47c:	0b000021 	add	w1, w1, w0
    a480:	b93ef066 	str	w6, [x3, #16112]
    a484:	f9400c83 	ldr	x3, [x4, #24]
    a488:	d14013a4 	sub	x4, x29, #0x4, lsl #12
    a48c:	f9400863 	ldr	x3, [x3, #16]
    a490:	f95f7484 	ldr	x4, [x4, #16104]
    a494:	8b204c80 	add	x0, x4, w0, uxtw #3
    a498:	d63f0060 	blr	x3
    a49c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4a0:	b97ef006 	ldr	w6, [x0, #16112]
    a4a4:	f9408f80 	ldr	x0, [x28, #280]
    a4a8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a4ac:	b94002e4 	ldr	w4, [x23]
    a4b0:	aa1703e9 	mov	x9, x23
    a4b4:	2a0603f4 	mov	w20, w6
    a4b8:	aa1703f8 	mov	x24, x23
    a4bc:	f95f743b 	ldr	x27, [x1, #16104]
    a4c0:	8b041404 	add	x4, x0, x4, lsl #5
    a4c4:	f9400c8a 	ldr	x10, [x4, #24]
    a4c8:	b40013ea 	cbz	x10, a744 <fwp_main_thread+0x9d4>
    a4cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4d0:	b93ed006 	str	w6, [x0, #16080]
    a4d4:	b93ed816 	str	w22, [x0, #16088]
    a4d8:	aa1b03f6 	mov	x22, x27
    a4dc:	aa0403fb 	mov	x27, x4
    a4e0:	14000012 	b	a528 <fwp_main_thread+0x7b8>
    a4e4:	f9400141 	ldr	x1, [x10]
    a4e8:	aa1603e0 	mov	x0, x22
    a4ec:	d63f0020 	blr	x1
    a4f0:	aa0003f8 	mov	x24, x0
    a4f4:	aa1703e0 	mov	x0, x23
    a4f8:	97fff01a 	bl	6560 <fwp_closure_drop>
    a4fc:	6b14027f 	cmp	w19, w20
    a500:	54004400 	b.eq	ad80 <fwp_main_thread+0x1010>  // b.none
    a504:	f9408f80 	ldr	x0, [x28, #280]
    a508:	8b334ed6 	add	x22, x22, w19, uxtw #3
    a50c:	b9400304 	ldr	w4, [x24]
    a510:	4b150354 	sub	w20, w26, w21
    a514:	aa1803e9 	mov	x9, x24
    a518:	8b04141b 	add	x27, x0, x4, lsl #5
    a51c:	f9400f6a 	ldr	x10, [x27, #24]
    a520:	b40010aa 	cbz	x10, a734 <fwp_main_thread+0x9c4>
    a524:	aa1803f7 	mov	x23, x24
    a528:	b9400523 	ldr	w3, [x9, #4]
    a52c:	b9400375 	ldr	w21, [x27]
    a530:	0b14007a 	add	w26, w3, w20
    a534:	6b1a02bf 	cmp	w21, w26
    a538:	54002e28 	b.hi	aafc <fwp_main_thread+0xd8c>  // b.pmore
    a53c:	7100007f 	cmp	w3, #0x0
    a540:	4b0302b3 	sub	w19, w21, w3
    a544:	7a400aa4 	ccmp	w21, #0x0, #0x4, eq	// eq = none
    a548:	54fffce1 	b.ne	a4e4 <fwp_main_thread+0x774>  // b.any
    a54c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a550:	910003e0 	mov	x0, sp
    a554:	710002bf 	cmp	w21, #0x0
    a558:	f91f7820 	str	x0, [x1, #16112]
    a55c:	1a9f16a0 	csinc	w0, w21, wzr, ne	// ne = any
    a560:	d37df000 	lsl	x0, x0, #3
    a564:	91003c00 	add	x0, x0, #0xf
    a568:	92704c01 	and	x1, x0, #0xfffff0000
    a56c:	927c7c00 	and	x0, x0, #0xffffffff0
    a570:	cb2163e1 	sub	x1, sp, x1
    a574:	eb2163ff 	cmp	sp, x1
    a578:	540000a0 	b.eq	a58c <fwp_main_thread+0x81c>  // b.none
    a57c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a580:	f90203ff 	str	xzr, [sp, #1024]
    a584:	eb2163ff 	cmp	sp, x1
    a588:	54ffffa1 	b.ne	a57c <fwp_main_thread+0x80c>  // b.any
    a58c:	92403c00 	and	x0, x0, #0xffff
    a590:	cb2063ff 	sub	sp, sp, x0
    a594:	f90003ff 	str	xzr, [sp]
    a598:	f110001f 	cmp	x0, #0x400
    a59c:	54000043 	b.cc	a5a4 <fwp_main_thread+0x834>  // b.lo, b.ul, b.last
    a5a0:	f90203ff 	str	xzr, [sp, #1024]
    a5a4:	910043f8 	add	x24, sp, #0x10
    a5a8:	d37d7c68 	ubfiz	x8, x3, #3, #32
    a5ac:	91002127 	add	x7, x9, #0x8
    a5b0:	d2800000 	mov	x0, #0x0                   	// #0
    a5b4:	340000c3 	cbz	w3, a5cc <fwp_main_thread+0x85c>
    a5b8:	f86068e1 	ldr	x1, [x7, x0]
    a5bc:	f8206b01 	str	x1, [x24, x0]
    a5c0:	91002000 	add	x0, x0, #0x8
    a5c4:	eb08001f 	cmp	x0, x8
    a5c8:	54ffff81 	b.ne	a5b8 <fwp_main_thread+0x848>  // b.any
    a5cc:	2a1303e8 	mov	w8, w19
    a5d0:	d2800000 	mov	x0, #0x0                   	// #0
    a5d4:	340000f3 	cbz	w19, a5f0 <fwp_main_thread+0x880>
    a5d8:	0b000061 	add	w1, w3, w0
    a5dc:	f8607ac2 	ldr	x2, [x22, x0, lsl #3]
    a5e0:	91000400 	add	x0, x0, #0x1
    a5e4:	f8217b02 	str	x2, [x24, x1, lsl #3]
    a5e8:	eb08001f 	cmp	x0, x8
    a5ec:	54ffff61 	b.ne	a5d8 <fwp_main_thread+0x868>  // b.any
    a5f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5f4:	f95f7c01 	ldr	x1, [x0, #16120]
    a5f8:	f949d820 	ldr	x0, [x1, #5040]
    a5fc:	f949ec21 	ldr	x1, [x1, #5080]
    a600:	cb0002e0 	sub	x0, x23, x0
    a604:	eb01401f 	cmp	x0, x1, lsl #16
    a608:	54000322 	b.cs	a66c <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    a60c:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a610:	d350fc01 	lsr	x1, x0, #16
    a614:	8b010821 	add	x1, x1, x1, lsl #2
    a618:	f95f7c42 	ldr	x2, [x2, #16120]
    a61c:	d37df021 	lsl	x1, x1, #3
    a620:	f949fc48 	ldr	x8, [x2, #5112]
    a624:	8b010107 	add	x7, x8, x1
    a628:	f94010e3 	ldr	x3, [x7, #32]
    a62c:	b4000203 	cbz	x3, a66c <fwp_main_thread+0x8fc>
    a630:	38616901 	ldrb	w1, [x8, x1]
    a634:	7100083f 	cmp	w1, #0x2
    a638:	54000740 	b.eq	a720 <fwp_main_thread+0x9b0>  // b.none
    a63c:	7100043f 	cmp	w1, #0x1
    a640:	54000161 	b.ne	a66c <fwp_main_thread+0x8fc>  // b.any
    a644:	294304e8 	ldp	w8, w1, [x7, #24]
    a648:	92403c00 	and	x0, x0, #0xffff
    a64c:	9b087c00 	mul	x0, x0, x8
    a650:	d360fc00 	lsr	x0, x0, #32
    a654:	eb01001f 	cmp	x0, x1
    a658:	540000a2 	b.cs	a66c <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    a65c:	8b000063 	add	x3, x3, x0
    a660:	39400060 	ldrb	w0, [x3]
    a664:	7100041f 	cmp	w0, #0x1
    a668:	54000220 	b.eq	a6ac <fwp_main_thread+0x93c>  // b.none
    a66c:	f9400543 	ldr	x3, [x10, #8]
    a670:	aa1703e0 	mov	x0, x23
    a674:	52800021 	mov	w1, #0x1                   	// #1
    a678:	d63f0060 	blr	x3
    a67c:	f9400f61 	ldr	x1, [x27, #24]
    a680:	aa1803e0 	mov	x0, x24
    a684:	f9400021 	ldr	x1, [x1]
    a688:	d63f0020 	blr	x1
    a68c:	aa0003f8 	mov	x24, x0
    a690:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a694:	f95f7800 	ldr	x0, [x0, #16112]
    a698:	9100001f 	mov	sp, x0
    a69c:	17ffff96 	b	a4f4 <fwp_main_thread+0x784>
    a6a0:	aa1803e0 	mov	x0, x24
    a6a4:	97ffe724 	bl	4334 <fwp_rc_forget_slot.part.0>
    a6a8:	17fffe75 	b	a07c <fwp_main_thread+0x30c>
    a6ac:	b900053f 	str	wzr, [x9, #4]
    a6b0:	17fffff3 	b	a67c <fwp_main_thread+0x90c>
    a6b4:	97ffe91f 	bl	4b30 <fwp_now_ns>
    a6b8:	f9403281 	ldr	x1, [x20, #96]
    a6bc:	eb01001f 	cmp	x0, x1
    a6c0:	540000ab 	b.lt	a6d4 <fwp_main_thread+0x964>  // b.tstop
    a6c4:	39414280 	ldrb	w0, [x20, #80]
    a6c8:	37000060 	tbnz	w0, #0, a6d4 <fwp_main_thread+0x964>
    a6cc:	aa1403e0 	mov	x0, x20
    a6d0:	97ffe3e8 	bl	3670 <fwp_cancel_tree.part.0>
    a6d4:	39414680 	ldrb	w0, [x20, #81]
    a6d8:	f9404f13 	ldr	x19, [x24, #152]
    a6dc:	39414a62 	ldrb	w2, [x19, #82]
    a6e0:	3707c000 	tbnz	w0, #0, 9ee0 <fwp_main_thread+0x170>
    a6e4:	f9403281 	ldr	x1, [x20, #96]
    a6e8:	37000222 	tbnz	w2, #0, a72c <fwp_main_thread+0x9bc>
    a6ec:	f9403260 	ldr	x0, [x19, #96]
    a6f0:	b40001e0 	cbz	x0, a72c <fwp_main_thread+0x9bc>
    a6f4:	b4000061 	cbz	x1, a700 <fwp_main_thread+0x990>
    a6f8:	eb01001f 	cmp	x0, x1
    a6fc:	9a81d000 	csel	x0, x0, x1, le
    a700:	f9402281 	ldr	x1, [x20, #64]
    a704:	a911fe75 	stp	x21, xzr, [x19, #280]
    a708:	f9009661 	str	x1, [x19, #296]
    a70c:	b4005121 	cbz	x1, b130 <fwp_main_thread+0x13c0>
    a710:	f9009033 	str	x19, [x1, #288]
    a714:	aa0003e1 	mov	x1, x0
    a718:	f9002293 	str	x19, [x20, #64]
    a71c:	17fffdfc 	b	9f0c <fwp_main_thread+0x19c>
    a720:	72003c1f 	tst	w0, #0xffff
    a724:	54fffa41 	b.ne	a66c <fwp_main_thread+0x8fc>  // b.any
    a728:	17ffffce 	b	a660 <fwp_main_thread+0x8f0>
    a72c:	f9402280 	ldr	x0, [x20, #64]
    a730:	17fffdf1 	b	9ef4 <fwp_main_thread+0x184>
    a734:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a738:	aa1603fb 	mov	x27, x22
    a73c:	b97ed006 	ldr	w6, [x0, #16080]
    a740:	b97ed816 	ldr	w22, [x0, #16088]
    a744:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a748:	b93ef006 	str	w6, [x0, #16112]
    a74c:	aa1803e0 	mov	x0, x24
    a750:	97ffedc4 	bl	5e60 <fwp_rc_share>
    a754:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a758:	b97ef006 	ldr	w6, [x0, #16112]
    a75c:	34000154 	cbz	w20, a784 <fwp_main_thread+0xa14>
    a760:	aa1b03f7 	mov	x23, x27
    a764:	8b344f73 	add	x19, x27, w20, uxtw #3
    a768:	2a0603fa 	mov	w26, w6
    a76c:	d503201f 	nop
    a770:	f84086e0 	ldr	x0, [x23], #8
    a774:	97ffedbb 	bl	5e60 <fwp_rc_share>
    a778:	eb1302ff 	cmp	x23, x19
    a77c:	54ffffa1 	b.ne	a770 <fwp_main_thread+0xa00>  // b.any
    a780:	2a1a03e6 	mov	w6, w26
    a784:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a788:	aa1b03e2 	mov	x2, x27
    a78c:	2a1403e1 	mov	w1, w20
    a790:	b93ef006 	str	w6, [x0, #16112]
    a794:	aa1803e0 	mov	x0, x24
    a798:	97ffeaa2 	bl	5220 <fwp_apply>
    a79c:	aa0003f7 	mov	x23, x0
    a7a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7a4:	b97ef006 	ldr	w6, [x0, #16112]
    a7a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7ac:	b97ee400 	ldr	w0, [x0, #16100]
    a7b0:	6b0002df 	cmp	w22, w0
    a7b4:	54004c42 	b.cs	b13c <fwp_main_thread+0x13cc>  // b.hs, b.nlast
    a7b8:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a7bc:	b94002e4 	ldr	w4, [x23]
    a7c0:	f9408f81 	ldr	x1, [x28, #280]
    a7c4:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a7c8:	f95f7442 	ldr	x2, [x2, #16104]
    a7cc:	4b060000 	sub	w0, w0, w6
    a7d0:	8b041424 	add	x4, x1, x4, lsl #5
    a7d4:	b93ee460 	str	w0, [x3, #16100]
    a7d8:	b97ee060 	ldr	w0, [x3, #16096]
    a7dc:	8b264c42 	add	x2, x2, w6, uxtw #3
    a7e0:	f91f7462 	str	x2, [x3, #16104]
    a7e4:	f9400c81 	ldr	x1, [x4, #24]
    a7e8:	b97edc62 	ldr	w2, [x3, #16092]
    a7ec:	4b020000 	sub	w0, w0, w2
    a7f0:	b93ee060 	str	w0, [x3, #16096]
    a7f4:	aa1703e0 	mov	x0, x23
    a7f8:	b5ffe221 	cbnz	x1, a43c <fwp_main_thread+0x6cc>
    a7fc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a800:	b97ee418 	ldr	w24, [x0, #16100]
    a804:	f95f6014 	ldr	x20, [x0, #16064]
    a808:	f95f641b 	ldr	x27, [x0, #16072]
    a80c:	aa1703e0 	mov	x0, x23
    a810:	97ffed94 	bl	5e60 <fwp_rc_share>
    a814:	34000158 	cbz	w24, a83c <fwp_main_thread+0xacc>
    a818:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a81c:	d2800015 	mov	x21, #0x0                   	// #0
    a820:	f95f7416 	ldr	x22, [x0, #16104]
    a824:	d503201f 	nop
    a828:	f8757ac0 	ldr	x0, [x22, x21, lsl #3]
    a82c:	910006b5 	add	x21, x21, #0x1
    a830:	97ffed8c 	bl	5e60 <fwp_rc_share>
    a834:	6b15031f 	cmp	w24, w21
    a838:	54ffff88 	b.hi	a828 <fwp_main_thread+0xab8>  // b.pmore
    a83c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a840:	2a1803e1 	mov	w1, w24
    a844:	f95f7402 	ldr	x2, [x0, #16104]
    a848:	aa1703e0 	mov	x0, x23
    a84c:	97ffea75 	bl	5220 <fwp_apply>
    a850:	aa0003f7 	mov	x23, x0
    a854:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a858:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a85c:	f95f5800 	ldr	x0, [x0, #16048]
    a860:	f1000400 	subs	x0, x0, #0x1
    a864:	f91f5820 	str	x0, [x1, #16048]
    a868:	54ffd781 	b.ne	a358 <fwp_main_thread+0x5e8>  // b.any
    a86c:	aa0103e0 	mov	x0, x1
    a870:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10060>
    a874:	91104042 	add	x2, x2, #0x410
    a878:	aa1703e1 	mov	x1, x23
    a87c:	aa1703f6 	mov	x22, x23
    a880:	91014042 	add	x2, x2, #0x50
    a884:	f95f4418 	ldr	x24, [x0, #16008]
    a888:	52800023 	mov	w3, #0x1                   	// #1
    a88c:	f95f4817 	ldr	x23, [x0, #16016]
    a890:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a894:	f95f4c13 	ldr	x19, [x0, #16024]
    a898:	aa1403e0 	mov	x0, x20
    a89c:	f81303bf 	stur	xzr, [x29, #-208]
    a8a0:	97fff938 	bl	8d80 <fwp_write>
    a8a4:	a9726fba 	ldp	x26, x27, [x29, #-224]
    a8a8:	b0000000 	adrp	x0, b000 <fwp_main_thread+0x1290>
    a8ac:	912f8000 	add	x0, x0, #0xbe0
    a8b0:	f100035f 	cmp	x26, #0x0
    a8b4:	9a9a001a 	csel	x26, x0, x26, eq	// eq = none
    a8b8:	b1002b7f 	cmn	x27, #0xa
    a8bc:	54005248 	b.hi	b304 <fwp_main_thread+0x1594>  // b.pmore
    a8c0:	91002760 	add	x0, x27, #0x9
    a8c4:	52800021 	mov	w1, #0x1                   	// #1
    a8c8:	97ffe9f2 	bl	5090 <fwp_heap_alloc>
    a8cc:	aa0003f5 	mov	x21, x0
    a8d0:	aa1a03e1 	mov	x1, x26
    a8d4:	aa0003fa 	mov	x26, x0
    a8d8:	aa1b03e2 	mov	x2, x27
    a8dc:	f800875b 	str	x27, [x26], #8
    a8e0:	8b1b02bb 	add	x27, x21, x27
    a8e4:	aa1a03e0 	mov	x0, x26
    a8e8:	97ffdf5e 	bl	2660 <memcpy@plt>
    a8ec:	3900237f 	strb	wzr, [x27, #8]
    a8f0:	f85203a0 	ldur	x0, [x29, #-224]
    a8f4:	97ffdff7 	bl	28d0 <free@plt>
    a8f8:	91190322 	add	x2, x25, #0x640
    a8fc:	f949d841 	ldr	x1, [x2, #5040]
    a900:	f949ec40 	ldr	x0, [x2, #5080]
    a904:	cb0102a1 	sub	x1, x21, x1
    a908:	eb00403f 	cmp	x1, x0, lsl #16
    a90c:	54000322 	b.cs	a970 <fwp_main_thread+0xc00>  // b.hs, b.nlast
    a910:	d350fc20 	lsr	x0, x1, #16
    a914:	d2800504 	mov	x4, #0x28                  	// #40
    a918:	f949fc43 	ldr	x3, [x2, #5112]
    a91c:	9b047c00 	mul	x0, x0, x4
    a920:	8b000062 	add	x2, x3, x0
    a924:	f940105b 	ldr	x27, [x2, #32]
    a928:	b400025b 	cbz	x27, a970 <fwp_main_thread+0xc00>
    a92c:	38606860 	ldrb	w0, [x3, x0]
    a930:	7100081f 	cmp	w0, #0x2
    a934:	54005060 	b.eq	b340 <fwp_main_thread+0x15d0>  // b.none
    a938:	7100041f 	cmp	w0, #0x1
    a93c:	540001a1 	b.ne	a970 <fwp_main_thread+0xc00>  // b.any
    a940:	29430043 	ldp	w3, w0, [x2, #24]
    a944:	92403c21 	and	x1, x1, #0xffff
    a948:	9b037c21 	mul	x1, x1, x3
    a94c:	d360fc21 	lsr	x1, x1, #32
    a950:	eb00003f 	cmp	x1, x0
    a954:	540000e2 	b.cs	a970 <fwp_main_thread+0xc00>  // b.hs, b.nlast
    a958:	8b01037b 	add	x27, x27, x1
    a95c:	39400360 	ldrb	w0, [x27]
    a960:	7103fc1f 	cmp	w0, #0xff
    a964:	54004f80 	b.eq	b354 <fwp_main_thread+0x15e4>  // b.none
    a968:	52800020 	mov	w0, #0x1                   	// #1
    a96c:	39000360 	strb	w0, [x27]
    a970:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a974:	91190322 	add	x2, x25, #0x640
    a978:	f91f7c13 	str	x19, [x0, #16120]
    a97c:	aa0203f3 	mov	x19, x2
    a980:	f949da61 	ldr	x1, [x19, #5040]
    a984:	f949ee60 	ldr	x0, [x19, #5080]
    a988:	cb0102c1 	sub	x1, x22, x1
    a98c:	eb00403f 	cmp	x1, x0, lsl #16
    a990:	54004682 	b.cs	b260 <fwp_main_thread+0x14f0>  // b.hs, b.nlast
    a994:	d350fc23 	lsr	x3, x1, #16
    a998:	d2800500 	mov	x0, #0x28                  	// #40
    a99c:	f949fe62 	ldr	x2, [x19, #5112]
    a9a0:	9b007c63 	mul	x3, x3, x0
    a9a4:	8b030040 	add	x0, x2, x3
    a9a8:	f940101b 	ldr	x27, [x0, #32]
    a9ac:	b40045bb 	cbz	x27, b260 <fwp_main_thread+0x14f0>
    a9b0:	38636842 	ldrb	w2, [x2, x3]
    a9b4:	7100085f 	cmp	w2, #0x2
    a9b8:	54004500 	b.eq	b258 <fwp_main_thread+0x14e8>  // b.none
    a9bc:	7100045f 	cmp	w2, #0x1
    a9c0:	54004501 	b.ne	b260 <fwp_main_thread+0x14f0>  // b.any
    a9c4:	29430002 	ldp	w2, w0, [x0, #24]
    a9c8:	92403c21 	and	x1, x1, #0xffff
    a9cc:	9b027c21 	mul	x1, x1, x2
    a9d0:	d360fc21 	lsr	x1, x1, #32
    a9d4:	eb00003f 	cmp	x1, x0
    a9d8:	54004442 	b.cs	b260 <fwp_main_thread+0x14f0>  // b.hs, b.nlast
    a9dc:	8b01037b 	add	x27, x27, x1
    a9e0:	39400360 	ldrb	w0, [x27]
    a9e4:	340043e0 	cbz	w0, b260 <fwp_main_thread+0x14f0>
    a9e8:	7100041f 	cmp	w0, #0x1
    a9ec:	54004400 	b.eq	b26c <fwp_main_thread+0x14fc>  // b.none
    a9f0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a9f4:	f95f7c33 	ldr	x19, [x1, #16120]
    a9f8:	7103fc1f 	cmp	w0, #0xff
    a9fc:	54004b20 	b.eq	b360 <fwp_main_thread+0x15f0>  // b.none
    aa00:	51000400 	sub	w0, w0, #0x1
    aa04:	39000360 	strb	w0, [x27]
    aa08:	d00000a0 	adrp	x0, 20000 <__data_start>
    aa0c:	91018003 	add	x3, x0, #0x60
    aa10:	f94002a2 	ldr	x2, [x21]
    aa14:	aa1a03e0 	mov	x0, x26
    aa18:	aa0303fa 	mov	x26, x3
    aa1c:	d2800021 	mov	x1, #0x1                   	// #1
    aa20:	f9404863 	ldr	x3, [x3, #144]
    aa24:	97ffdfbb 	bl	2910 <fwrite@plt>
    aa28:	f9404b41 	ldr	x1, [x26, #144]
    aa2c:	52800140 	mov	w0, #0xa                   	// #10
    aa30:	97ffdf40 	bl	2730 <fputc@plt>
    aa34:	91190322 	add	x2, x25, #0x640
    aa38:	f949d841 	ldr	x1, [x2, #5040]
    aa3c:	f949ec40 	ldr	x0, [x2, #5080]
    aa40:	cb0102a1 	sub	x1, x21, x1
    aa44:	eb00403f 	cmp	x1, x0, lsl #16
    aa48:	54000382 	b.cs	aab8 <fwp_main_thread+0xd48>  // b.hs, b.nlast
    aa4c:	d350fc20 	lsr	x0, x1, #16
    aa50:	d2800504 	mov	x4, #0x28                  	// #40
    aa54:	f949fc43 	ldr	x3, [x2, #5112]
    aa58:	9b047c00 	mul	x0, x0, x4
    aa5c:	8b000062 	add	x2, x3, x0
    aa60:	f940105a 	ldr	x26, [x2, #32]
    aa64:	b40002ba 	cbz	x26, aab8 <fwp_main_thread+0xd48>
    aa68:	38606863 	ldrb	w3, [x3, x0]
    aa6c:	7100087f 	cmp	w3, #0x2
    aa70:	54004620 	b.eq	b334 <fwp_main_thread+0x15c4>  // b.none
    aa74:	7100047f 	cmp	w3, #0x1
    aa78:	54000201 	b.ne	aab8 <fwp_main_thread+0xd48>  // b.any
    aa7c:	29431040 	ldp	w0, w4, [x2, #24]
    aa80:	92403c21 	and	x1, x1, #0xffff
    aa84:	9b007c20 	mul	x0, x1, x0
    aa88:	d360fc00 	lsr	x0, x0, #32
    aa8c:	eb04001f 	cmp	x0, x4
    aa90:	54000142 	b.cs	aab8 <fwp_main_thread+0xd48>  // b.hs, b.nlast
    aa94:	8b00035a 	add	x26, x26, x0
    aa98:	39400340 	ldrb	w0, [x26]
    aa9c:	340000e0 	cbz	w0, aab8 <fwp_main_thread+0xd48>
    aaa0:	7100041f 	cmp	w0, #0x1
    aaa4:	54004360 	b.eq	b310 <fwp_main_thread+0x15a0>  // b.none
    aaa8:	7103fc1f 	cmp	w0, #0xff
    aaac:	54004800 	b.eq	b3ac <fwp_main_thread+0x163c>  // b.none
    aab0:	51000400 	sub	w0, w0, #0x1
    aab4:	39000340 	strb	w0, [x26]
    aab8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aabc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aac0:	f95f5000 	ldr	x0, [x0, #16032]
    aac4:	f9400800 	ldr	x0, [x0, #16]
    aac8:	f91f5020 	str	x0, [x1, #16032]
    aacc:	b5ffbec0 	cbnz	x0, a2a4 <fwp_main_thread+0x534>
    aad0:	aa1803f3 	mov	x19, x24
    aad4:	aa1703e0 	mov	x0, x23
    aad8:	97ffee3e 	bl	63d0 <fwp_drop0>
    aadc:	aa1303e0 	mov	x0, x19
    aae0:	97ffee3c 	bl	63d0 <fwp_drop0>
    aae4:	d00000a0 	adrp	x0, 20000 <__data_start>
    aae8:	91018000 	add	x0, x0, #0x60
    aaec:	52800021 	mov	w1, #0x1                   	// #1
    aaf0:	b903c801 	str	w1, [x0, #968]
    aaf4:	f901e81f 	str	xzr, [x0, #976]
    aaf8:	17fffceb 	b	9ea4 <fwp_main_thread+0x134>
    aafc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab00:	b941338b 	ldr	w11, [x28, #304]
    ab04:	aa1b03e4 	mov	x4, x27
    ab08:	aa1603fb 	mov	x27, x22
    ab0c:	b97ed006 	ldr	w6, [x0, #16080]
    ab10:	b97ed816 	ldr	w22, [x0, #16088]
    ab14:	11000740 	add	w0, w26, #0x1
    ab18:	d37df000 	lsl	x0, x0, #3
    ab1c:	340000ab 	cbz	w11, ab30 <fwp_main_thread+0xdc0>
    ab20:	a9538782 	ldp	x2, x1, [x28, #312]
    ab24:	91000442 	add	x2, x2, #0x1
    ab28:	8b000021 	add	x1, x1, x0
    ab2c:	a9138782 	stp	x2, x1, [x28, #312]
    ab30:	9119032a 	add	x10, x25, #0x640
    ab34:	f140101f 	cmp	x0, #0x4, lsl #12
    ab38:	b953a541 	ldr	w1, [x10, #5028]
    ab3c:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    ab40:	54002ca0 	b.eq	b0d4 <fwp_main_thread+0x1364>  // b.none
    ab44:	91003c01 	add	x1, x0, #0xf
    ab48:	8b411141 	add	x1, x10, x1, lsr #4
    ab4c:	397e8021 	ldrb	w1, [x1, #4000]
    ab50:	910f002c 	add	x12, x1, #0x3c0
    ab54:	8b010422 	add	x2, x1, x1, lsl #1
    ab58:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    ab5c:	8b020d4d 	add	x13, x10, x2, lsl #3
    ab60:	f8627953 	ldr	x19, [x10, x2, lsl #3]
    ab64:	2a0c03e1 	mov	w1, w12
    ab68:	b4002a53 	cbz	x19, b0b0 <fwp_main_thread+0x1340>
    ab6c:	f940026d 	ldr	x13, [x19]
    ab70:	aa2d03ed 	mvn	x13, x13
    ab74:	f822794d 	str	x13, [x10, x2, lsl #3]
    ab78:	eb01001f 	cmp	x0, x1
    ab7c:	540000a2 	b.cs	ab90 <fwp_main_thread+0xe20>  // b.hs, b.nlast
    ab80:	f8206a7f 	str	xzr, [x19, x0]
    ab84:	91002000 	add	x0, x0, #0x8
    ab88:	eb00003f 	cmp	x1, x0
    ab8c:	54ffffa8 	b.hi	ab80 <fwp_main_thread+0xe10>  // b.pmore
    ab90:	91190322 	add	x2, x25, #0x640
    ab94:	f94a1040 	ldr	x0, [x2, #5152]
    ab98:	ab010000 	adds	x0, x0, x1
    ab9c:	54004002 	b.cs	b39c <fwp_main_thread+0x162c>  // b.hs, b.nlast
    aba0:	f94a1441 	ldr	x1, [x2, #5160]
    aba4:	f90a1040 	str	x0, [x2, #5152]
    aba8:	eb01001f 	cmp	x0, x1
    abac:	54000049 	b.ls	abb4 <fwp_main_thread+0xe44>  // b.plast
    abb0:	f90a1440 	str	x0, [x2, #5160]
    abb4:	91190320 	add	x0, x25, #0x640
    abb8:	1e630181 	ucvtf	d1, w12
    abbc:	fd4a1c00 	ldr	d0, [x0, #5176]
    abc0:	1e612800 	fadd	d0, d0, d1
    abc4:	fd0a1c00 	str	d0, [x0, #5176]
    abc8:	3400010b 	cbz	w11, abe8 <fwp_main_thread+0xe78>
    abcc:	91190320 	add	x0, x25, #0x640
    abd0:	6d548782 	ldp	d2, d1, [x28, #328]
    abd4:	fd4a1000 	ldr	d0, [x0, #5152]
    abd8:	7e61d800 	ucvtf	d0, d0
    abdc:	1e623800 	fsub	d0, d0, d2
    abe0:	1e612010 	fcmpe	d0, d1
    abe4:	54002a2c 	b.gt	b128 <fwp_main_thread+0x13b8>
    abe8:	b9400120 	ldr	w0, [x9]
    abec:	29006a60 	stp	w0, w26, [x19]
    abf0:	340001e3 	cbz	w3, ac2c <fwp_main_thread+0xebc>
    abf4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abf8:	d37d7c62 	ubfiz	x2, x3, #3, #32
    abfc:	91002121 	add	x1, x9, #0x8
    ac00:	f91f5c04 	str	x4, [x0, #16056]
    ac04:	b93ed006 	str	w6, [x0, #16080]
    ac08:	b93ed803 	str	w3, [x0, #16088]
    ac0c:	f91f7809 	str	x9, [x0, #16112]
    ac10:	91002260 	add	x0, x19, #0x8
    ac14:	97ffde9b 	bl	2680 <memmove@plt>
    ac18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac1c:	f95f5c04 	ldr	x4, [x0, #16056]
    ac20:	f95f7809 	ldr	x9, [x0, #16112]
    ac24:	b97ed006 	ldr	w6, [x0, #16080]
    ac28:	b97ed803 	ldr	w3, [x0, #16088]
    ac2c:	2a1403e8 	mov	w8, w20
    ac30:	d2800001 	mov	x1, #0x0                   	// #0
    ac34:	34000114 	cbz	w20, ac54 <fwp_main_thread+0xee4>
    ac38:	0b010060 	add	w0, w3, w1
    ac3c:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    ac40:	8b000e60 	add	x0, x19, x0, lsl #3
    ac44:	91000421 	add	x1, x1, #0x1
    ac48:	f9000402 	str	x2, [x0, #8]
    ac4c:	eb08003f 	cmp	x1, x8
    ac50:	54ffff41 	b.ne	ac38 <fwp_main_thread+0xec8>  // b.any
    ac54:	91190322 	add	x2, x25, #0x640
    ac58:	f949d840 	ldr	x0, [x2, #5040]
    ac5c:	f949ec41 	ldr	x1, [x2, #5080]
    ac60:	cb0002e0 	sub	x0, x23, x0
    ac64:	eb01401f 	cmp	x0, x1, lsl #16
    ac68:	540002e2 	b.cs	acc4 <fwp_main_thread+0xf54>  // b.hs, b.nlast
    ac6c:	d350fc01 	lsr	x1, x0, #16
    ac70:	f949fc45 	ldr	x5, [x2, #5112]
    ac74:	8b010821 	add	x1, x1, x1, lsl #2
    ac78:	d37df021 	lsl	x1, x1, #3
    ac7c:	8b0100a3 	add	x3, x5, x1
    ac80:	f9401062 	ldr	x2, [x3, #32]
    ac84:	b4000202 	cbz	x2, acc4 <fwp_main_thread+0xf54>
    ac88:	386168a1 	ldrb	w1, [x5, x1]
    ac8c:	7100083f 	cmp	w1, #0x2
    ac90:	54002400 	b.eq	b110 <fwp_main_thread+0x13a0>  // b.none
    ac94:	7100043f 	cmp	w1, #0x1
    ac98:	54000161 	b.ne	acc4 <fwp_main_thread+0xf54>  // b.any
    ac9c:	29430465 	ldp	w5, w1, [x3, #24]
    aca0:	92403c00 	and	x0, x0, #0xffff
    aca4:	9b057c00 	mul	x0, x0, x5
    aca8:	d360fc00 	lsr	x0, x0, #32
    acac:	eb01001f 	cmp	x0, x1
    acb0:	540000a2 	b.cs	acc4 <fwp_main_thread+0xf54>  // b.hs, b.nlast
    acb4:	8b000042 	add	x2, x2, x0
    acb8:	39400040 	ldrb	w0, [x2]
    acbc:	7100041f 	cmp	w0, #0x1
    acc0:	54001ee0 	b.eq	b09c <fwp_main_thread+0x132c>  // b.none
    acc4:	f9400c82 	ldr	x2, [x4, #24]
    acc8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    accc:	52800021 	mov	w1, #0x1                   	// #1
    acd0:	f9400442 	ldr	x2, [x2, #8]
    acd4:	b93ef006 	str	w6, [x0, #16112]
    acd8:	aa1703e0 	mov	x0, x23
    acdc:	d63f0040 	blr	x2
    ace0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ace4:	b97ef006 	ldr	w6, [x0, #16112]
    ace8:	91190322 	add	x2, x25, #0x640
    acec:	f949d841 	ldr	x1, [x2, #5040]
    acf0:	f949ec40 	ldr	x0, [x2, #5080]
    acf4:	cb010261 	sub	x1, x19, x1
    acf8:	eb00403f 	cmp	x1, x0, lsl #16
    acfc:	54000322 	b.cs	ad60 <fwp_main_thread+0xff0>  // b.hs, b.nlast
    ad00:	d350fc20 	lsr	x0, x1, #16
    ad04:	f949fc43 	ldr	x3, [x2, #5112]
    ad08:	8b000800 	add	x0, x0, x0, lsl #2
    ad0c:	d37df002 	lsl	x2, x0, #3
    ad10:	8b020060 	add	x0, x3, x2
    ad14:	f9401014 	ldr	x20, [x0, #32]
    ad18:	b4000254 	cbz	x20, ad60 <fwp_main_thread+0xff0>
    ad1c:	38626862 	ldrb	w2, [x3, x2]
    ad20:	7100085f 	cmp	w2, #0x2
    ad24:	54001fc0 	b.eq	b11c <fwp_main_thread+0x13ac>  // b.none
    ad28:	7100045f 	cmp	w2, #0x1
    ad2c:	540001a1 	b.ne	ad60 <fwp_main_thread+0xff0>  // b.any
    ad30:	29430002 	ldp	w2, w0, [x0, #24]
    ad34:	92403c21 	and	x1, x1, #0xffff
    ad38:	9b027c21 	mul	x1, x1, x2
    ad3c:	d360fc21 	lsr	x1, x1, #32
    ad40:	eb00003f 	cmp	x1, x0
    ad44:	540000e2 	b.cs	ad60 <fwp_main_thread+0xff0>  // b.hs, b.nlast
    ad48:	8b010294 	add	x20, x20, x1
    ad4c:	39400280 	ldrb	w0, [x20]
    ad50:	7103fc1f 	cmp	w0, #0xff
    ad54:	54002140 	b.eq	b17c <fwp_main_thread+0x140c>  // b.none
    ad58:	52800020 	mov	w0, #0x1                   	// #1
    ad5c:	39000280 	strb	w0, [x20]
    ad60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad64:	b93ef006 	str	w6, [x0, #16112]
    ad68:	aa1703e0 	mov	x0, x23
    ad6c:	97ffedfd 	bl	6560 <fwp_closure_drop>
    ad70:	aa1303f7 	mov	x23, x19
    ad74:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad78:	b97ef006 	ldr	w6, [x0, #16112]
    ad7c:	17fffe8b 	b	a7a8 <fwp_main_thread+0xa38>
    ad80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad84:	aa1803f7 	mov	x23, x24
    ad88:	b97ed006 	ldr	w6, [x0, #16080]
    ad8c:	b97ed816 	ldr	w22, [x0, #16088]
    ad90:	17fffe86 	b	a7a8 <fwp_main_thread+0xa38>
    ad94:	a911fe75 	stp	x21, xzr, [x19, #280]
    ad98:	f9009660 	str	x0, [x19, #296]
    ad9c:	b4000040 	cbz	x0, ada4 <fwp_main_thread+0x1034>
    ada0:	f9009013 	str	x19, [x0, #288]
    ada4:	f9002293 	str	x19, [x20, #64]
    ada8:	17fffc60 	b	9f28 <fwp_main_thread+0x1b8>
    adac:	f9000040 	str	x0, [x2]
    adb0:	17fffc66 	b	9f48 <fwp_main_thread+0x1d8>
    adb4:	39014a97 	strb	w23, [x20, #82]
    adb8:	d00000a0 	adrp	x0, 20000 <__data_start>
    adbc:	91018013 	add	x19, x0, #0x60
    adc0:	f941d660 	ldr	x0, [x19, #936]
    adc4:	b5000060 	cbnz	x0, add0 <fwp_main_thread+0x1060>
    adc8:	f941de60 	ldr	x0, [x19, #952]
    adcc:	b4001e60 	cbz	x0, b198 <fwp_main_thread+0x1428>
    add0:	d00000a0 	adrp	x0, 20000 <__data_start>
    add4:	91018000 	add	x0, x0, #0x60
    add8:	f9404c00 	ldr	x0, [x0, #152]
    addc:	d00000a1 	adrp	x1, 20000 <__data_start>
    ade0:	91018021 	add	x1, x1, #0x60
    ade4:	f941f026 	ldr	x6, [x1, #992]
    ade8:	b903d83f 	str	wzr, [x1, #984]
    adec:	eb0000df 	cmp	x6, x0
    adf0:	54003401 	b.ne	b470 <fwp_main_thread+0x1700>  // b.any
    adf4:	b4000400 	cbz	x0, ae74 <fwp_main_thread+0x1104>
    adf8:	f941c025 	ldr	x5, [x1, #896]
    adfc:	52800021 	mov	w1, #0x1                   	// #1
    ae00:	39014801 	strb	w1, [x0, #82]
    ae04:	b4000385 	cbz	x5, ae74 <fwp_main_thread+0x1104>
    ae08:	394140a0 	ldrb	w0, [x5, #80]
    ae0c:	37000060 	tbnz	w0, #0, ae18 <fwp_main_thread+0x10a8>
    ae10:	aa0503e0 	mov	x0, x5
    ae14:	97ffe217 	bl	3670 <fwp_cancel_tree.part.0>
    ae18:	f9409ca5 	ldr	x5, [x5, #312]
    ae1c:	b5ffff65 	cbnz	x5, ae08 <fwp_main_thread+0x1098>
    ae20:	d00000a0 	adrp	x0, 20000 <__data_start>
    ae24:	91018013 	add	x19, x0, #0x60
    ae28:	52800034 	mov	w20, #0x1                   	// #1
    ae2c:	d503201f 	nop
    ae30:	f94028c0 	ldr	x0, [x6, #80]
    ae34:	f2001c1f 	tst	x0, #0xff000000ff
    ae38:	540000e1 	b.ne	ae54 <fwp_main_thread+0x10e4>  // b.any
    ae3c:	f9406260 	ldr	x0, [x19, #192]
    ae40:	390150d4 	strb	w20, [x6, #84]
    ae44:	f90080df 	str	xzr, [x6, #256]
    ae48:	b4000120 	cbz	x0, ae6c <fwp_main_thread+0x10fc>
    ae4c:	f9008006 	str	x6, [x0, #256]
    ae50:	f9006266 	str	x6, [x19, #192]
    ae54:	97ffefb7 	bl	6d30 <fwp_block>
    ae58:	97ffef3e 	bl	6b50 <fwp_free_zombie>
    ae5c:	f941c260 	ldr	x0, [x19, #896]
    ae60:	b40000a0 	cbz	x0, ae74 <fwp_main_thread+0x1104>
    ae64:	f941f266 	ldr	x6, [x19, #992]
    ae68:	17fffff2 	b	ae30 <fwp_main_thread+0x10c0>
    ae6c:	f9006666 	str	x6, [x19, #200]
    ae70:	17fffff8 	b	ae50 <fwp_main_thread+0x10e0>
    ae74:	97ffef37 	bl	6b50 <fwp_free_zombie>
    ae78:	d00000a0 	adrp	x0, 20000 <__data_start>
    ae7c:	91018014 	add	x20, x0, #0x60
    ae80:	f9406680 	ldr	x0, [x20, #200]
    ae84:	b5002f60 	cbnz	x0, b470 <fwp_main_thread+0x1700>
    ae88:	f9409680 	ldr	x0, [x20, #296]
    ae8c:	b5002f20 	cbnz	x0, b470 <fwp_main_thread+0x1700>
    ae90:	b9417280 	ldr	w0, [x20, #368]
    ae94:	340001c0 	cbz	w0, aecc <fwp_main_thread+0x115c>
    ae98:	93407c15 	sxtw	x21, w0
    ae9c:	51000400 	sub	w0, w0, #0x1
    aea0:	d1000ab5 	sub	x21, x21, #0x2
    aea4:	91060296 	add	x22, x20, #0x180
    aea8:	cb2042b5 	sub	x21, x21, w0, uxtw
    aeac:	93407c13 	sxtw	x19, w0
    aeb0:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    aeb4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    aeb8:	b9017293 	str	w19, [x20, #368]
    aebc:	d1000673 	sub	x19, x19, #0x1
    aec0:	97ffde9c 	bl	2930 <munmap@plt>
    aec4:	eb15027f 	cmp	x19, x21
    aec8:	54ffff41 	b.ne	aeb0 <fwp_main_thread+0x1140>  // b.any
    aecc:	d00000a4 	adrp	x4, 20000 <__data_start>
    aed0:	91004080 	add	x0, x4, #0x10
    aed4:	b9403000 	ldr	w0, [x0, #48]
    aed8:	37f800c0 	tbnz	w0, #31, aef0 <fwp_main_thread+0x1180>
    aedc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aee0:	f91f7c24 	str	x4, [x1, #16120]
    aee4:	97ffde4f 	bl	2820 <close@plt>
    aee8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aeec:	f95f7c04 	ldr	x4, [x0, #16120]
    aef0:	d00000a0 	adrp	x0, 20000 <__data_start>
    aef4:	91018014 	add	x20, x0, #0x60
    aef8:	91004084 	add	x4, x4, #0x10
    aefc:	12800001 	mov	w1, #0xffffffff            	// #-1
    af00:	f941fa80 	ldr	x0, [x20, #1008]
    af04:	b9003081 	str	w1, [x4, #48]
    af08:	f941f681 	ldr	x1, [x20, #1000]
    af0c:	b40001e0 	cbz	x0, af48 <fwp_main_thread+0x11d8>
    af10:	d2800013 	mov	x19, #0x0                   	// #0
    af14:	d503201f 	nop
    af18:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    af1c:	b40000e0 	cbz	x0, af38 <fwp_main_thread+0x11c8>
    af20:	f9400001 	ldr	x1, [x0]
    af24:	b5002a61 	cbnz	x1, b470 <fwp_main_thread+0x1700>
    af28:	f9400401 	ldr	x1, [x0, #8]
    af2c:	b5002a21 	cbnz	x1, b470 <fwp_main_thread+0x1700>
    af30:	97ffe59c 	bl	45a0 <fwp_mem_free>
    af34:	f941f681 	ldr	x1, [x20, #1000]
    af38:	91000673 	add	x19, x19, #0x1
    af3c:	f941fa80 	ldr	x0, [x20, #1008]
    af40:	eb00027f 	cmp	x19, x0
    af44:	54fffea3 	b.cc	af18 <fwp_main_thread+0x11a8>  // b.lo, b.ul, b.last
    af48:	aa0103e0 	mov	x0, x1
    af4c:	97ffe595 	bl	45a0 <fwp_mem_free>
    af50:	d00000a0 	adrp	x0, 20000 <__data_start>
    af54:	91018000 	add	x0, x0, #0x60
    af58:	f941f013 	ldr	x19, [x0, #992]
    af5c:	f901f41f 	str	xzr, [x0, #1000]
    af60:	f901f81f 	str	xzr, [x0, #1008]
    af64:	b40001f3 	cbz	x19, afa0 <fwp_main_thread+0x1230>
    af68:	f9401661 	ldr	x1, [x19, #40]
    af6c:	b5002821 	cbnz	x1, b470 <fwp_main_thread+0x1700>
    af70:	f9405661 	ldr	x1, [x19, #168]
    af74:	b50027e1 	cbnz	x1, b470 <fwp_main_thread+0x1700>
    af78:	f941d401 	ldr	x1, [x0, #936]
    af7c:	b50027a1 	cbnz	x1, b470 <fwp_main_thread+0x1700>
    af80:	f941dc00 	ldr	x0, [x0, #952]
    af84:	b5002760 	cbnz	x0, b470 <fwp_main_thread+0x1700>
    af88:	d2823a02 	mov	x2, #0x11d0                	// #4560
    af8c:	d0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    af90:	91118000 	add	x0, x0, #0x460
    af94:	97ffde13 	bl	27e0 <memset@plt>
    af98:	aa1303e0 	mov	x0, x19
    af9c:	97ffe581 	bl	45a0 <fwp_mem_free>
    afa0:	d00000a1 	adrp	x1, 20000 <__data_start>
    afa4:	91190320 	add	x0, x25, #0x640
    afa8:	91018026 	add	x6, x1, #0x60
    afac:	d0000002 	adrp	x2, c000 <_IO_stdin_used+0x460>
    afb0:	3dc01821 	ldr	q1, [x1, #96]
    afb4:	910f6042 	add	x2, x2, #0x3d8
    afb8:	3dc004c2 	ldr	q2, [x6, #16]
    afbc:	52800041 	mov	w1, #0x2                   	// #2
    afc0:	fd4a1000 	ldr	d0, [x0, #5152]
    afc4:	f9004cdf 	str	xzr, [x6, #152]
    afc8:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    afcc:	fd40a4c1 	ldr	d1, [x6, #328]
    afd0:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    afd4:	f947e800 	ldr	x0, [x0, #4048]
    afd8:	7e61d800 	ucvtf	d0, d0
    afdc:	a95390c3 	ldp	x3, x4, [x6, #312]
    afe0:	b90130df 	str	wzr, [x6, #304]
    afe4:	f9400000 	ldr	x0, [x0]
    afe8:	1e613801 	fsub	d1, d0, d1
    afec:	f940acc5 	ldr	x5, [x6, #344]
    aff0:	f901f0df 	str	xzr, [x6, #992]
    aff4:	5ef1b842 	addp	d2, v2.2d
    aff8:	fd40a8c0 	ldr	d0, [x6, #336]
    affc:	fd0058c2 	str	d2, [x6, #176]
    b000:	97ffde20 	bl	2880 <__fprintf_chk@plt>
    b004:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    b008:	f947ec00 	ldr	x0, [x0, #4056]
    b00c:	f9400000 	ldr	x0, [x0]
    b010:	97ffde4c 	bl	2940 <fflush@plt>
    b014:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    b018:	f947f400 	ldr	x0, [x0, #4072]
    b01c:	f85f83a2 	ldur	x2, [x29, #-8]
    b020:	f9400001 	ldr	x1, [x0]
    b024:	eb010042 	subs	x2, x2, x1
    b028:	d2800001 	mov	x1, #0x0                   	// #0
    b02c:	54001de1 	b.ne	b3e8 <fwp_main_thread+0x1678>  // b.any
    b030:	910003bf 	mov	sp, x29
    b034:	d2800000 	mov	x0, #0x0                   	// #0
    b038:	a94153f3 	ldp	x19, x20, [sp, #16]
    b03c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    b040:	a94363f7 	ldp	x23, x24, [sp, #48]
    b044:	a9446bf9 	ldp	x25, x26, [sp, #64]
    b048:	a94573fb 	ldp	x27, x28, [sp, #80]
    b04c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    b050:	d65f03c0 	ret
    b054:	72003c3f 	tst	w1, #0xffff
    b058:	54ff8141 	b.ne	a080 <fwp_main_thread+0x310>  // b.any
    b05c:	17fffc05 	b	a070 <fwp_main_thread+0x300>
    b060:	b8626860 	ldr	w0, [x3, x2]
    b064:	b9400762 	ldr	w2, [x27, #4]
    b068:	4b020003 	sub	w3, w0, w2
    b06c:	7100047f 	cmp	w3, #0x1
    b070:	54ff9861 	b.ne	a37c <fwp_main_thread+0x60c>  // b.any
    b074:	910003f5 	mov	x21, sp
    b078:	35000d62 	cbnz	w2, b224 <fwp_main_thread+0x14b4>
    b07c:	f9400021 	ldr	x1, [x1]
    b080:	aa1403e0 	mov	x0, x20
    b084:	d63f0020 	blr	x1
    b088:	aa0003f7 	mov	x23, x0
    b08c:	910002bf 	mov	sp, x21
    b090:	17fffdf1 	b	a854 <fwp_main_thread+0xae4>
    b094:	f9009700 	str	x0, [x24, #296]
    b098:	17fffbb6 	b	9f70 <fwp_main_thread+0x200>
    b09c:	b900053f 	str	wzr, [x9, #4]
    b0a0:	17ffff12 	b	ace8 <fwp_main_thread+0xf78>
    b0a4:	72003c3f 	tst	w1, #0xffff
    b0a8:	54ff9b21 	b.ne	a40c <fwp_main_thread+0x69c>  // b.any
    b0ac:	17fffccd 	b	a3e0 <fwp_main_thread+0x670>
    b0b0:	f94005b3 	ldr	x19, [x13, #8]
    b0b4:	b4000113 	cbz	x19, b0d4 <fwp_main_thread+0x1364>
    b0b8:	f94009a2 	ldr	x2, [x13, #16]
    b0bc:	cb130042 	sub	x2, x2, x19
    b0c0:	eb02003f 	cmp	x1, x2
    b0c4:	54000088 	b.hi	b0d4 <fwp_main_thread+0x1364>  // b.pmore
    b0c8:	8b010262 	add	x2, x19, x1
    b0cc:	f90005a2 	str	x2, [x13, #8]
    b0d0:	17fffeaa 	b	ab78 <fwp_main_thread+0xe08>
    b0d4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    b0d8:	b93eb823 	str	w3, [x1, #16056]
    b0dc:	f91f6824 	str	x4, [x1, #16080]
    b0e0:	b93ed826 	str	w6, [x1, #16088]
    b0e4:	f91f7829 	str	x9, [x1, #16112]
    b0e8:	52800001 	mov	w1, #0x0                   	// #0
    b0ec:	97ffe7e9 	bl	5090 <fwp_heap_alloc>
    b0f0:	aa0003f3 	mov	x19, x0
    b0f4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b0f8:	b941338b 	ldr	w11, [x28, #304]
    b0fc:	f95f6804 	ldr	x4, [x0, #16080]
    b100:	f95f7809 	ldr	x9, [x0, #16112]
    b104:	b97eb803 	ldr	w3, [x0, #16056]
    b108:	b97ed806 	ldr	w6, [x0, #16088]
    b10c:	17fffeaf 	b	abc8 <fwp_main_thread+0xe58>
    b110:	72003c1f 	tst	w0, #0xffff
    b114:	54ffdd81 	b.ne	acc4 <fwp_main_thread+0xf54>  // b.any
    b118:	17fffee8 	b	acb8 <fwp_main_thread+0xf48>
    b11c:	72003c3f 	tst	w1, #0xffff
    b120:	54ffe201 	b.ne	ad60 <fwp_main_thread+0xff0>  // b.any
    b124:	17ffff0a 	b	ad4c <fwp_main_thread+0xfdc>
    b128:	fd00ab80 	str	d0, [x28, #336]
    b12c:	17fffeaf 	b	abe8 <fwp_main_thread+0xe78>
    b130:	aa0003e1 	mov	x1, x0
    b134:	f9002293 	str	x19, [x20, #64]
    b138:	17fffb75 	b	9f0c <fwp_main_thread+0x19c>
    b13c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b140:	f95f6014 	ldr	x20, [x0, #16064]
    b144:	f95f641b 	ldr	x27, [x0, #16072]
    b148:	17fffdc3 	b	a854 <fwp_main_thread+0xae4>
    b14c:	72003c3f 	tst	w1, #0xffff
    b150:	54ff7fe1 	b.ne	a14c <fwp_main_thread+0x3dc>  // b.any
    b154:	17fffbf9 	b	a138 <fwp_main_thread+0x3c8>
    b158:	72003c3f 	tst	w1, #0xffff
    b15c:	54ff8401 	b.ne	a1dc <fwp_main_thread+0x46c>  // b.any
    b160:	17fffc1a 	b	a1c8 <fwp_main_thread+0x458>
    b164:	72003c3f 	tst	w1, #0xffff
    b168:	54ff8841 	b.ne	a270 <fwp_main_thread+0x500>  // b.any
    b16c:	17fffc3c 	b	a25c <fwp_main_thread+0x4ec>
    b170:	72003c5f 	tst	w2, #0xffff
    b174:	54ff8e41 	b.ne	a33c <fwp_main_thread+0x5cc>  // b.any
    b178:	17fffc64 	b	a308 <fwp_main_thread+0x598>
    b17c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b180:	b93ef006 	str	w6, [x0, #16112]
    b184:	aa1403e0 	mov	x0, x20
    b188:	97ffe46b 	bl	4334 <fwp_rc_forget_slot.part.0>
    b18c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b190:	b97ef006 	ldr	w6, [x0, #16112]
    b194:	17fffef1 	b	ad58 <fwp_main_thread+0xfe8>
    b198:	f941d260 	ldr	x0, [x19, #928]
    b19c:	97ffe501 	bl	45a0 <fwp_mem_free>
    b1a0:	f901d27f 	str	xzr, [x19, #928]
    b1a4:	f9404e60 	ldr	x0, [x19, #152]
    b1a8:	f901da7f 	str	xzr, [x19, #944]
    b1ac:	b4ffe180 	cbz	x0, addc <fwp_main_thread+0x106c>
    b1b0:	f900541f 	str	xzr, [x0, #168]
    b1b4:	f9005c1f 	str	xzr, [x0, #184]
    b1b8:	17ffff09 	b	addc <fwp_main_thread+0x106c>
    b1bc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    b1c0:	f91f7c24 	str	x4, [x1, #16120]
    b1c4:	97ffe570 	bl	4784 <fwp_rc_wide_dup>
    b1c8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b1cc:	f95f7c04 	ldr	x4, [x0, #16120]
    b1d0:	17fffc8f 	b	a40c <fwp_main_thread+0x69c>
    b1d4:	aa1603e0 	mov	x0, x22
    b1d8:	97ffe457 	bl	4334 <fwp_rc_forget_slot.part.0>
    b1dc:	17fffbda 	b	a144 <fwp_main_thread+0x3d4>
    b1e0:	aa1603e0 	mov	x0, x22
    b1e4:	97ffe454 	bl	4334 <fwp_rc_forget_slot.part.0>
    b1e8:	17fffbfb 	b	a1d4 <fwp_main_thread+0x464>
    b1ec:	aa1503e0 	mov	x0, x21
    b1f0:	97ffe451 	bl	4334 <fwp_rc_forget_slot.part.0>
    b1f4:	17fffc1d 	b	a268 <fwp_main_thread+0x4f8>
    b1f8:	aa1b03e0 	mov	x0, x27
    b1fc:	97ffeb19 	bl	5e60 <fwp_rc_share>
    b200:	aa1703e0 	mov	x0, x23
    b204:	97ffeb17 	bl	5e60 <fwp_rc_share>
    b208:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b20c:	aa1b03f7 	mov	x23, x27
    b210:	52800038 	mov	w24, #0x1                   	// #1
    b214:	f91f7414 	str	x20, [x0, #16104]
    b218:	17fffd89 	b	a83c <fwp_main_thread+0xacc>
    b21c:	97ffe55a 	bl	4784 <fwp_rc_wide_dup>
    b220:	17fffc47 	b	a33c <fwp_main_thread+0x5cc>
    b224:	7100001f 	cmp	w0, #0x0
    b228:	d37d7c00 	ubfiz	x0, x0, #3, #32
    b22c:	d2800101 	mov	x1, #0x8                   	// #8
    b230:	9a811018 	csel	x24, x0, x1, ne	// ne = any
    b234:	91003f00 	add	x0, x24, #0xf
    b238:	92704c01 	and	x1, x0, #0xfffff0000
    b23c:	927c7c00 	and	x0, x0, #0xffffffff0
    b240:	cb2163e1 	sub	x1, sp, x1
    b244:	eb2163ff 	cmp	sp, x1
    b248:	540001c0 	b.eq	b280 <fwp_main_thread+0x1510>  // b.none
    b24c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    b250:	f90203ff 	str	xzr, [sp, #1024]
    b254:	17fffffc 	b	b244 <fwp_main_thread+0x14d4>
    b258:	72003c3f 	tst	w1, #0xffff
    b25c:	54ffbc20 	b.eq	a9e0 <fwp_main_thread+0xc70>  // b.none
    b260:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b264:	f95f7c13 	ldr	x19, [x0, #16120]
    b268:	17fffde8 	b	aa08 <fwp_main_thread+0xc98>
    b26c:	f9400adb 	ldr	x27, [x22, #16]
    b270:	aa1603e0 	mov	x0, x22
    b274:	97ffeb1f 	bl	5ef0 <fwp_rc_free_arr>
    b278:	aa1b03f6 	mov	x22, x27
    b27c:	17fffdc1 	b	a980 <fwp_main_thread+0xc10>
    b280:	92403c00 	and	x0, x0, #0xffff
    b284:	cb2063ff 	sub	sp, sp, x0
    b288:	f90003ff 	str	xzr, [sp]
    b28c:	f110001f 	cmp	x0, #0x400
    b290:	54000043 	b.cc	b298 <fwp_main_thread+0x1528>  // b.lo, b.ul, b.last
    b294:	f90203ff 	str	xzr, [sp, #1024]
    b298:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b29c:	d37d7c5a 	ubfiz	x26, x2, #3, #32
    b2a0:	910043f6 	add	x22, sp, #0x10
    b2a4:	aa1a03e2 	mov	x2, x26
    b2a8:	aa1803e3 	mov	x3, x24
    b2ac:	f91f7c04 	str	x4, [x0, #16120]
    b2b0:	f95f4c00 	ldr	x0, [x0, #16024]
    b2b4:	91004001 	add	x1, x0, #0x10
    b2b8:	aa1603e0 	mov	x0, x22
    b2bc:	9100c021 	add	x1, x1, #0x30
    b2c0:	97ffdd28 	bl	2760 <__memcpy_chk@plt>
    b2c4:	eb1a031f 	cmp	x24, x26
    b2c8:	aa1403e1 	mov	x1, x20
    b2cc:	9a9a2303 	csel	x3, x24, x26, cs	// cs = hs, nlast
    b2d0:	d2800102 	mov	x2, #0x8                   	// #8
    b2d4:	cb1a0063 	sub	x3, x3, x26
    b2d8:	8b1a02c0 	add	x0, x22, x26
    b2dc:	97ffdd21 	bl	2760 <__memcpy_chk@plt>
    b2e0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    b2e4:	aa1603e0 	mov	x0, x22
    b2e8:	f95f7c24 	ldr	x4, [x1, #16120]
    b2ec:	f9400c81 	ldr	x1, [x4, #24]
    b2f0:	f9400021 	ldr	x1, [x1]
    b2f4:	d63f0020 	blr	x1
    b2f8:	aa0003f7 	mov	x23, x0
    b2fc:	910002bf 	mov	sp, x21
    b300:	17fffd55 	b	a854 <fwp_main_thread+0xae4>
    b304:	b0000000 	adrp	x0, c000 <_IO_stdin_used+0x460>
    b308:	910f0000 	add	x0, x0, #0x3c0
    b30c:	97ffe3ea 	bl	42b4 <fwp_trap>
    b310:	7100087f 	cmp	w3, #0x2
    b314:	540001c0 	b.eq	b34c <fwp_main_thread+0x15dc>  // b.none
    b318:	29430043 	ldp	w3, w0, [x2, #24]
    b31c:	9b037c21 	mul	x1, x1, x3
    b320:	eb41801f 	cmp	x0, x1, lsr #32
    b324:	54ffbca9 	b.ls	aab8 <fwp_main_thread+0xd48>  // b.plast
    b328:	aa1503e0 	mov	x0, x21
    b32c:	97ffe49d 	bl	45a0 <fwp_mem_free>
    b330:	17fffde2 	b	aab8 <fwp_main_thread+0xd48>
    b334:	f2403c21 	ands	x1, x1, #0xffff
    b338:	54ffbc01 	b.ne	aab8 <fwp_main_thread+0xd48>  // b.any
    b33c:	17fffdd7 	b	aa98 <fwp_main_thread+0xd28>
    b340:	72003c3f 	tst	w1, #0xffff
    b344:	54ffb161 	b.ne	a970 <fwp_main_thread+0xc00>  // b.any
    b348:	17fffd85 	b	a95c <fwp_main_thread+0xbec>
    b34c:	b5ffbb61 	cbnz	x1, aab8 <fwp_main_thread+0xd48>
    b350:	17fffff6 	b	b328 <fwp_main_thread+0x15b8>
    b354:	aa1b03e0 	mov	x0, x27
    b358:	97ffe3f7 	bl	4334 <fwp_rc_forget_slot.part.0>
    b35c:	17fffd83 	b	a968 <fwp_main_thread+0xbf8>
    b360:	ca5b4760 	eor	x0, x27, x27, lsr #17
    b364:	91190322 	add	x2, x25, #0x640
    b368:	ca402400 	eor	x0, x0, x0, lsr #9
    b36c:	92401c00 	and	x0, x0, #0xff
    b370:	910a2401 	add	x1, x0, #0x289
    b374:	8b000c40 	add	x0, x2, x0, lsl #3
    b378:	8b010c41 	add	x1, x2, x1, lsl #3
    b37c:	f94a2400 	ldr	x0, [x0, #5192]
    b380:	b40004e0 	cbz	x0, b41c <fwp_main_thread+0x16ac>
    b384:	f9400002 	ldr	x2, [x0]
    b388:	eb1b005f 	cmp	x2, x27
    b38c:	54000300 	b.eq	b3ec <fwp_main_thread+0x167c>  // b.none
    b390:	91004001 	add	x1, x0, #0x10
    b394:	f9400800 	ldr	x0, [x0, #16]
    b398:	17fffffa 	b	b380 <fwp_main_thread+0x1610>
    b39c:	97ffdf55 	bl	30f0 <fwp_heap_oom>
    b3a0:	b0000000 	adrp	x0, c000 <_IO_stdin_used+0x460>
    b3a4:	910e8000 	add	x0, x0, #0x3a0
    b3a8:	97ffdfd6 	bl	3300 <ad_raw_fail>
    b3ac:	ca5a4740 	eor	x0, x26, x26, lsr #17
    b3b0:	91190322 	add	x2, x25, #0x640
    b3b4:	ca402400 	eor	x0, x0, x0, lsr #9
    b3b8:	92401c00 	and	x0, x0, #0xff
    b3bc:	910a2401 	add	x1, x0, #0x289
    b3c0:	8b000c40 	add	x0, x2, x0, lsl #3
    b3c4:	8b010c41 	add	x1, x2, x1, lsl #3
    b3c8:	f94a2400 	ldr	x0, [x0, #5192]
    b3cc:	b4000280 	cbz	x0, b41c <fwp_main_thread+0x16ac>
    b3d0:	f9400002 	ldr	x2, [x0]
    b3d4:	eb02035f 	cmp	x26, x2
    b3d8:	540002e0 	b.eq	b434 <fwp_main_thread+0x16c4>  // b.none
    b3dc:	91004001 	add	x1, x0, #0x10
    b3e0:	f9400800 	ldr	x0, [x0, #16]
    b3e4:	17fffffa 	b	b3cc <fwp_main_thread+0x165c>
    b3e8:	97ffdd0a 	bl	2810 <__stack_chk_fail@plt>
    b3ec:	f9400021 	ldr	x1, [x1]
    b3f0:	f9400420 	ldr	x0, [x1, #8]
    b3f4:	d1000400 	sub	x0, x0, #0x1
    b3f8:	f9000420 	str	x0, [x1, #8]
    b3fc:	f103f81f 	cmp	x0, #0xfe
    b400:	54ffb041 	b.ne	aa08 <fwp_main_thread+0xc98>  // b.any
    b404:	39400360 	ldrb	w0, [x27]
    b408:	7103fc1f 	cmp	w0, #0xff
    b40c:	540000e0 	b.eq	b428 <fwp_main_thread+0x16b8>  // b.none
    b410:	12800020 	mov	w0, #0xfffffffe            	// #-2
    b414:	39000360 	strb	w0, [x27]
    b418:	17fffd7c 	b	aa08 <fwp_main_thread+0xc98>
    b41c:	90000000 	adrp	x0, b000 <fwp_main_thread+0x1290>
    b420:	913be000 	add	x0, x0, #0xef8
    b424:	97ffe3a4 	bl	42b4 <fwp_trap>
    b428:	aa1b03e0 	mov	x0, x27
    b42c:	97ffe3c2 	bl	4334 <fwp_rc_forget_slot.part.0>
    b430:	17fffff8 	b	b410 <fwp_main_thread+0x16a0>
    b434:	f9400021 	ldr	x1, [x1]
    b438:	f9400420 	ldr	x0, [x1, #8]
    b43c:	d1000400 	sub	x0, x0, #0x1
    b440:	f9000420 	str	x0, [x1, #8]
    b444:	f103f81f 	cmp	x0, #0xfe
    b448:	54ffb381 	b.ne	aab8 <fwp_main_thread+0xd48>  // b.any
    b44c:	39400340 	ldrb	w0, [x26]
    b450:	7103fc1f 	cmp	w0, #0xff
    b454:	54000080 	b.eq	b464 <fwp_main_thread+0x16f4>  // b.none
    b458:	12800020 	mov	w0, #0xfffffffe            	// #-2
    b45c:	39000340 	strb	w0, [x26]
    b460:	17fffd96 	b	aab8 <fwp_main_thread+0xd48>
    b464:	aa1a03e0 	mov	x0, x26
    b468:	97ffe3b3 	bl	4334 <fwp_rc_forget_slot.part.0>
    b46c:	17fffffb 	b	b458 <fwp_main_thread+0x16e8>
    b470:	97ffdcfc 	bl	2860 <abort@plt>
    b474:	d503201f 	nop
    b478:	d503201f 	nop
    b47c:	d503201f 	nop

000000000000b480 <__divti3>:
    b480:	d503245f 	bti	c
    b484:	d2800004 	mov	x4, #0x0                   	// #0
    b488:	b7f80721 	tbnz	x1, #63, b56c <__divti3+0xec>
    b48c:	b6f80083 	tbz	x3, #63, b49c <__divti3+0x1c>
    b490:	eb0203e2 	negs	x2, x2
    b494:	aa2403e4 	mvn	x4, x4
    b498:	da0303e3 	ngc	x3, x3
    b49c:	aa0203e6 	mov	x6, x2
    b4a0:	aa0003e7 	mov	x7, x0
    b4a4:	aa0103e5 	mov	x5, x1
    b4a8:	b5000583 	cbnz	x3, b558 <__divti3+0xd8>
    b4ac:	eb01005f 	cmp	x2, x1
    b4b0:	54000e69 	b.ls	b67c <__divti3+0x1fc>  // b.plast
    b4b4:	dac01040 	clz	x0, x2
    b4b8:	b40000e0 	cbz	x0, b4d4 <__divti3+0x54>
    b4bc:	4b0003e1 	neg	w1, w0
    b4c0:	9ac020a5 	lsl	x5, x5, x0
    b4c4:	9ac02046 	lsl	x6, x2, x0
    b4c8:	9ac124e1 	lsr	x1, x7, x1
    b4cc:	aa050025 	orr	x5, x1, x5
    b4d0:	9ac020e7 	lsl	x7, x7, x0
    b4d4:	d360fcc8 	lsr	x8, x6, #32
    b4d8:	92407cc2 	and	x2, x6, #0xffffffff
    b4dc:	9ac808a3 	udiv	x3, x5, x8
    b4e0:	9b089465 	msub	x5, x3, x8, x5
    b4e4:	aa0303e0 	mov	x0, x3
    b4e8:	9b037c41 	mul	x1, x2, x3
    b4ec:	93c780a5 	extr	x5, x5, x7, #32
    b4f0:	eb05003f 	cmp	x1, x5
    b4f4:	540000a9 	b.ls	b508 <__divti3+0x88>  // b.plast
    b4f8:	ab0500c5 	adds	x5, x6, x5
    b4fc:	d1000460 	sub	x0, x3, #0x1
    b500:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    b504:	540015a8 	b.hi	b7b8 <__divti3+0x338>  // b.pmore
    b508:	cb0100a5 	sub	x5, x5, x1
    b50c:	9ac808a3 	udiv	x3, x5, x8
    b510:	9b089465 	msub	x5, x3, x8, x5
    b514:	aa0303e1 	mov	x1, x3
    b518:	9b037c42 	mul	x2, x2, x3
    b51c:	aa0703e3 	mov	x3, x7
    b520:	b3607ca3 	bfi	x3, x5, #32, #32
    b524:	eb03005f 	cmp	x2, x3
    b528:	540000c9 	b.ls	b540 <__divti3+0xc0>  // b.plast
    b52c:	ab0300c3 	adds	x3, x6, x3
    b530:	d1000425 	sub	x5, x1, #0x1
    b534:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b538:	d1000821 	sub	x1, x1, #0x2
    b53c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    b540:	aa008020 	orr	x0, x1, x0, lsl #32
    b544:	d2800001 	mov	x1, #0x0                   	// #0
    b548:	b4000064 	cbz	x4, b554 <__divti3+0xd4>
    b54c:	eb0003e0 	negs	x0, x0
    b550:	da0103e1 	ngc	x1, x1
    b554:	d65f03c0 	ret
    b558:	eb01007f 	cmp	x3, x1
    b55c:	54000109 	b.ls	b57c <__divti3+0xfc>  // b.plast
    b560:	d2800001 	mov	x1, #0x0                   	// #0
    b564:	d2800000 	mov	x0, #0x0                   	// #0
    b568:	17fffff8 	b	b548 <__divti3+0xc8>
    b56c:	eb0003e0 	negs	x0, x0
    b570:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b574:	da0103e1 	ngc	x1, x1
    b578:	17ffffc5 	b	b48c <__divti3+0xc>
    b57c:	dac01067 	clz	x7, x3
    b580:	b40010e7 	cbz	x7, b79c <__divti3+0x31c>
    b584:	d2800805 	mov	x5, #0x40                  	// #64
    b588:	cb0700a5 	sub	x5, x5, x7
    b58c:	9ac72063 	lsl	x3, x3, x7
    b590:	9ac52448 	lsr	x8, x2, x5
    b594:	aa030108 	orr	x8, x8, x3
    b598:	9ac52426 	lsr	x6, x1, x5
    b59c:	92407d0a 	and	x10, x8, #0xffffffff
    b5a0:	d360fd09 	lsr	x9, x8, #32
    b5a4:	9ac52403 	lsr	x3, x0, x5
    b5a8:	9ac72021 	lsl	x1, x1, x7
    b5ac:	aa010063 	orr	x3, x3, x1
    b5b0:	9ac72042 	lsl	x2, x2, x7
    b5b4:	9ac908cb 	udiv	x11, x6, x9
    b5b8:	9b099965 	msub	x5, x11, x9, x6
    b5bc:	aa0b03e1 	mov	x1, x11
    b5c0:	9b0b7d46 	mul	x6, x10, x11
    b5c4:	93c380a5 	extr	x5, x5, x3, #32
    b5c8:	eb0500df 	cmp	x6, x5
    b5cc:	540000a9 	b.ls	b5e0 <__divti3+0x160>  // b.plast
    b5d0:	ab050105 	adds	x5, x8, x5
    b5d4:	d1000561 	sub	x1, x11, #0x1
    b5d8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    b5dc:	54000f48 	b.hi	b7c4 <__divti3+0x344>  // b.pmore
    b5e0:	cb0600a6 	sub	x6, x5, x6
    b5e4:	9ac908cb 	udiv	x11, x6, x9
    b5e8:	9b099969 	msub	x9, x11, x9, x6
    b5ec:	aa0b03e5 	mov	x5, x11
    b5f0:	9b0b7d4a 	mul	x10, x10, x11
    b5f4:	b3607d23 	bfi	x3, x9, #32, #32
    b5f8:	eb03015f 	cmp	x10, x3
    b5fc:	540000a9 	b.ls	b610 <__divti3+0x190>  // b.plast
    b600:	ab030103 	adds	x3, x8, x3
    b604:	d1000565 	sub	x5, x11, #0x1
    b608:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b60c:	54000e28 	b.hi	b7d0 <__divti3+0x350>  // b.pmore
    b610:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b614:	92407c48 	and	x8, x2, #0xffffffff
    b618:	2a0503e5 	mov	w5, w5
    b61c:	d360fc42 	lsr	x2, x2, #32
    b620:	d360fc26 	lsr	x6, x1, #32
    b624:	cb0a0063 	sub	x3, x3, x10
    b628:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b62c:	9b087caa 	mul	x10, x5, x8
    b630:	9b087cc8 	mul	x8, x6, x8
    b634:	9b0220a5 	madd	x5, x5, x2, x8
    b638:	9b027cc6 	mul	x6, x6, x2
    b63c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b640:	8b0900c5 	add	x5, x6, x9
    b644:	eb02011f 	cmp	x8, x2
    b648:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b64c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b650:	eb06007f 	cmp	x3, x6
    b654:	540000e3 	b.cc	b670 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b658:	92407d4a 	and	x10, x10, #0xffffffff
    b65c:	9ac72000 	lsl	x0, x0, x7
    b660:	8b028142 	add	x2, x10, x2, lsl #32
    b664:	eb02001f 	cmp	x0, x2
    b668:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b66c:	54000a01 	b.ne	b7ac <__divti3+0x32c>  // b.any
    b670:	d1000420 	sub	x0, x1, #0x1
    b674:	d2800001 	mov	x1, #0x0                   	// #0
    b678:	17ffffb4 	b	b548 <__divti3+0xc8>
    b67c:	b5000062 	cbnz	x2, b688 <__divti3+0x208>
    b680:	d2800022 	mov	x2, #0x1                   	// #1
    b684:	9ac30846 	udiv	x6, x2, x3
    b688:	dac010c8 	clz	x8, x6
    b68c:	b5000408 	cbnz	x8, b70c <__divti3+0x28c>
    b690:	d360fcc9 	lsr	x9, x6, #32
    b694:	92407cc5 	and	x5, x6, #0xffffffff
    b698:	cb060023 	sub	x3, x1, x6
    b69c:	d2800021 	mov	x1, #0x1                   	// #1
    b6a0:	9ac90868 	udiv	x8, x3, x9
    b6a4:	9b098d03 	msub	x3, x8, x9, x3
    b6a8:	aa0803e0 	mov	x0, x8
    b6ac:	9b057d02 	mul	x2, x8, x5
    b6b0:	93c78063 	extr	x3, x3, x7, #32
    b6b4:	eb03005f 	cmp	x2, x3
    b6b8:	540000a9 	b.ls	b6cc <__divti3+0x24c>  // b.plast
    b6bc:	ab0300c3 	adds	x3, x6, x3
    b6c0:	d1000500 	sub	x0, x8, #0x1
    b6c4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b6c8:	54000968 	b.hi	b7f4 <__divti3+0x374>  // b.pmore
    b6cc:	cb020063 	sub	x3, x3, x2
    b6d0:	9ac90862 	udiv	x2, x3, x9
    b6d4:	aa0203e8 	mov	x8, x2
    b6d8:	9b098c42 	msub	x2, x2, x9, x3
    b6dc:	aa0703e3 	mov	x3, x7
    b6e0:	9b057d05 	mul	x5, x8, x5
    b6e4:	b3607c43 	bfi	x3, x2, #32, #32
    b6e8:	eb0300bf 	cmp	x5, x3
    b6ec:	540000c9 	b.ls	b704 <__divti3+0x284>  // b.plast
    b6f0:	ab0300c2 	adds	x2, x6, x3
    b6f4:	d1000503 	sub	x3, x8, #0x1
    b6f8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b6fc:	d1000908 	sub	x8, x8, #0x2
    b700:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b704:	aa008100 	orr	x0, x8, x0, lsl #32
    b708:	17ffff90 	b	b548 <__divti3+0xc8>
    b70c:	9ac820c6 	lsl	x6, x6, x8
    b710:	d2800803 	mov	x3, #0x40                  	// #64
    b714:	cb080063 	sub	x3, x3, x8
    b718:	d360fcc9 	lsr	x9, x6, #32
    b71c:	9ac82027 	lsl	x7, x1, x8
    b720:	92407cc5 	and	x5, x6, #0xffffffff
    b724:	9ac32422 	lsr	x2, x1, x3
    b728:	9ac32403 	lsr	x3, x0, x3
    b72c:	aa070063 	orr	x3, x3, x7
    b730:	9ac9084a 	udiv	x10, x2, x9
    b734:	9ac82007 	lsl	x7, x0, x8
    b738:	9b098940 	msub	x0, x10, x9, x2
    b73c:	aa0a03e1 	mov	x1, x10
    b740:	9b0a7ca2 	mul	x2, x5, x10
    b744:	93c38000 	extr	x0, x0, x3, #32
    b748:	eb00005f 	cmp	x2, x0
    b74c:	540000a9 	b.ls	b760 <__divti3+0x2e0>  // b.plast
    b750:	ab0000c0 	adds	x0, x6, x0
    b754:	d1000541 	sub	x1, x10, #0x1
    b758:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b75c:	54000468 	b.hi	b7e8 <__divti3+0x368>  // b.pmore
    b760:	cb020000 	sub	x0, x0, x2
    b764:	9ac9080a 	udiv	x10, x0, x9
    b768:	9b098140 	msub	x0, x10, x9, x0
    b76c:	aa0a03e2 	mov	x2, x10
    b770:	9b0a7ca8 	mul	x8, x5, x10
    b774:	b3607c03 	bfi	x3, x0, #32, #32
    b778:	eb03011f 	cmp	x8, x3
    b77c:	540000a9 	b.ls	b790 <__divti3+0x310>  // b.plast
    b780:	ab0300c3 	adds	x3, x6, x3
    b784:	d1000542 	sub	x2, x10, #0x1
    b788:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b78c:	54000288 	b.hi	b7dc <__divti3+0x35c>  // b.pmore
    b790:	cb080063 	sub	x3, x3, x8
    b794:	aa018041 	orr	x1, x2, x1, lsl #32
    b798:	17ffffc2 	b	b6a0 <__divti3+0x220>
    b79c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b7a0:	d2800001 	mov	x1, #0x0                   	// #0
    b7a4:	9a9f87e0 	cset	x0, ls	// ls = plast
    b7a8:	17ffff68 	b	b548 <__divti3+0xc8>
    b7ac:	aa0103e0 	mov	x0, x1
    b7b0:	d2800001 	mov	x1, #0x0                   	// #0
    b7b4:	17ffff65 	b	b548 <__divti3+0xc8>
    b7b8:	d1000860 	sub	x0, x3, #0x2
    b7bc:	8b0600a5 	add	x5, x5, x6
    b7c0:	17ffff52 	b	b508 <__divti3+0x88>
    b7c4:	d1000961 	sub	x1, x11, #0x2
    b7c8:	8b0800a5 	add	x5, x5, x8
    b7cc:	17ffff85 	b	b5e0 <__divti3+0x160>
    b7d0:	d1000965 	sub	x5, x11, #0x2
    b7d4:	8b080063 	add	x3, x3, x8
    b7d8:	17ffff8e 	b	b610 <__divti3+0x190>
    b7dc:	d1000942 	sub	x2, x10, #0x2
    b7e0:	8b060063 	add	x3, x3, x6
    b7e4:	17ffffeb 	b	b790 <__divti3+0x310>
    b7e8:	d1000941 	sub	x1, x10, #0x2
    b7ec:	8b060000 	add	x0, x0, x6
    b7f0:	17ffffdc 	b	b760 <__divti3+0x2e0>
    b7f4:	d1000900 	sub	x0, x8, #0x2
    b7f8:	8b060063 	add	x3, x3, x6
    b7fc:	17ffffb4 	b	b6cc <__divti3+0x24c>

000000000000b800 <__modti3>:
    b800:	d503245f 	bti	c
    b804:	d2800004 	mov	x4, #0x0                   	// #0
    b808:	b6f80081 	tbz	x1, #63, b818 <__modti3+0x18>
    b80c:	eb0003e0 	negs	x0, x0
    b810:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b814:	da0103e1 	ngc	x1, x1
    b818:	f100007f 	cmp	x3, #0x0
    b81c:	5400128b 	b.lt	ba6c <__modti3+0x26c>  // b.tstop
    b820:	aa0003e7 	mov	x7, x0
    b824:	aa0103e6 	mov	x6, x1
    b828:	540004e1 	b.ne	b8c4 <__modti3+0xc4>  // b.any
    b82c:	eb02003f 	cmp	x1, x2
    b830:	54000dc2 	b.cs	b9e8 <__modti3+0x1e8>  // b.hs, b.nlast
    b834:	dac01043 	clz	x3, x2
    b838:	aa0303e5 	mov	x5, x3
    b83c:	b40000e3 	cbz	x3, b858 <__modti3+0x58>
    b840:	4b0303e6 	neg	w6, w3
    b844:	9ac32021 	lsl	x1, x1, x3
    b848:	9ac32042 	lsl	x2, x2, x3
    b84c:	9ac62406 	lsr	x6, x0, x6
    b850:	aa0100c6 	orr	x6, x6, x1
    b854:	9ac32007 	lsl	x7, x0, x3
    b858:	d360fc40 	lsr	x0, x2, #32
    b85c:	92407c43 	and	x3, x2, #0xffffffff
    b860:	9ac008c1 	udiv	x1, x6, x0
    b864:	9b009826 	msub	x6, x1, x0, x6
    b868:	9b017c61 	mul	x1, x3, x1
    b86c:	93c780c6 	extr	x6, x6, x7, #32
    b870:	eb06003f 	cmp	x1, x6
    b874:	540000a9 	b.ls	b888 <__modti3+0x88>  // b.plast
    b878:	ab060046 	adds	x6, x2, x6
    b87c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b880:	8b0200c8 	add	x8, x6, x2
    b884:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b888:	cb0100c6 	sub	x6, x6, x1
    b88c:	9ac008c8 	udiv	x8, x6, x0
    b890:	9b009901 	msub	x1, x8, x0, x6
    b894:	aa0703e0 	mov	x0, x7
    b898:	9b087c63 	mul	x3, x3, x8
    b89c:	b3607c20 	bfi	x0, x1, #32, #32
    b8a0:	eb00007f 	cmp	x3, x0
    b8a4:	54001088 	b.hi	bab4 <__modti3+0x2b4>  // b.pmore
    b8a8:	cb030000 	sub	x0, x0, x3
    b8ac:	9ac52400 	lsr	x0, x0, x5
    b8b0:	d2800001 	mov	x1, #0x0                   	// #0
    b8b4:	b4000064 	cbz	x4, b8c0 <__modti3+0xc0>
    b8b8:	eb0003e0 	negs	x0, x0
    b8bc:	da0103e1 	ngc	x1, x1
    b8c0:	d65f03c0 	ret
    b8c4:	dac01066 	clz	x6, x3
    b8c8:	eb03003f 	cmp	x1, x3
    b8cc:	54ffff43 	b.cc	b8b4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b8d0:	93407cc5 	sxtw	x5, w6
    b8d4:	d2800808 	mov	x8, #0x40                  	// #64
    b8d8:	cb050108 	sub	x8, x8, x5
    b8dc:	9ac62063 	lsl	x3, x3, x6
    b8e0:	9ac62025 	lsl	x5, x1, x6
    b8e4:	9ac82447 	lsr	x7, x2, x8
    b8e8:	aa0300e7 	orr	x7, x7, x3
    b8ec:	9ac82423 	lsr	x3, x1, x8
    b8f0:	92407cec 	and	x12, x7, #0xffffffff
    b8f4:	d360fcea 	lsr	x10, x7, #32
    b8f8:	9ac82401 	lsr	x1, x0, x8
    b8fc:	aa050021 	orr	x1, x1, x5
    b900:	9ac62042 	lsl	x2, x2, x6
    b904:	9ac62000 	lsl	x0, x0, x6
    b908:	9aca086b 	udiv	x11, x3, x10
    b90c:	9b0a8d63 	msub	x3, x11, x10, x3
    b910:	aa0b03e5 	mov	x5, x11
    b914:	9b0b7d89 	mul	x9, x12, x11
    b918:	93c18063 	extr	x3, x3, x1, #32
    b91c:	eb03013f 	cmp	x9, x3
    b920:	540000a9 	b.ls	b934 <__modti3+0x134>  // b.plast
    b924:	ab0300e3 	adds	x3, x7, x3
    b928:	d1000565 	sub	x5, x11, #0x1
    b92c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b930:	54001168 	b.hi	bb5c <__modti3+0x35c>  // b.pmore
    b934:	cb090063 	sub	x3, x3, x9
    b938:	9aca086b 	udiv	x11, x3, x10
    b93c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b940:	aa0b03e9 	mov	x9, x11
    b944:	9b0b7d8c 	mul	x12, x12, x11
    b948:	b3607d41 	bfi	x1, x10, #32, #32
    b94c:	eb01019f 	cmp	x12, x1
    b950:	540000a9 	b.ls	b964 <__modti3+0x164>  // b.plast
    b954:	ab0100e1 	adds	x1, x7, x1
    b958:	d1000569 	sub	x9, x11, #0x1
    b95c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b960:	54000f88 	b.hi	bb50 <__modti3+0x350>  // b.pmore
    b964:	aa058123 	orr	x3, x9, x5, lsl #32
    b968:	92407c4b 	and	x11, x2, #0xffffffff
    b96c:	2a0903e9 	mov	w9, w9
    b970:	d360fc4a 	lsr	x10, x2, #32
    b974:	d360fc63 	lsr	x3, x3, #32
    b978:	cb0c0021 	sub	x1, x1, x12
    b97c:	aa0a03ec 	mov	x12, x10
    b980:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b984:	9b0b7d25 	mul	x5, x9, x11
    b988:	9b0b7c6b 	mul	x11, x3, x11
    b98c:	9b0a2d29 	madd	x9, x9, x10, x11
    b990:	92407caa 	and	x10, x5, #0xffffffff
    b994:	9b0c7c63 	mul	x3, x3, x12
    b998:	8b458125 	add	x5, x9, x5, lsr #32
    b99c:	8b0d0069 	add	x9, x3, x13
    b9a0:	eb05017f 	cmp	x11, x5
    b9a4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b9a8:	8b058149 	add	x9, x10, x5, lsl #32
    b9ac:	8b458063 	add	x3, x3, x5, lsr #32
    b9b0:	eb03003f 	cmp	x1, x3
    b9b4:	54000063 	b.cc	b9c0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b9b8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b9bc:	54000082 	b.cs	b9cc <__modti3+0x1cc>  // b.hs, b.nlast
    b9c0:	eb020129 	subs	x9, x9, x2
    b9c4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b9c8:	cb070063 	sub	x3, x3, x7
    b9cc:	eb090000 	subs	x0, x0, x9
    b9d0:	da030021 	sbc	x1, x1, x3
    b9d4:	9ac62400 	lsr	x0, x0, x6
    b9d8:	9ac82028 	lsl	x8, x1, x8
    b9dc:	aa000100 	orr	x0, x8, x0
    b9e0:	9ac62421 	lsr	x1, x1, x6
    b9e4:	17ffffb4 	b	b8b4 <__modti3+0xb4>
    b9e8:	b5000062 	cbnz	x2, b9f4 <__modti3+0x1f4>
    b9ec:	d2800023 	mov	x3, #0x1                   	// #1
    b9f0:	9ac20862 	udiv	x2, x3, x2
    b9f4:	dac01048 	clz	x8, x2
    b9f8:	aa0803e5 	mov	x5, x8
    b9fc:	b5000668 	cbnz	x8, bac8 <__modti3+0x2c8>
    ba00:	cb020020 	sub	x0, x1, x2
    ba04:	d360fc49 	lsr	x9, x2, #32
    ba08:	92407c4a 	and	x10, x2, #0xffffffff
    ba0c:	9ac90801 	udiv	x1, x0, x9
    ba10:	9b098020 	msub	x0, x1, x9, x0
    ba14:	9b0a7c21 	mul	x1, x1, x10
    ba18:	93c78000 	extr	x0, x0, x7, #32
    ba1c:	eb00003f 	cmp	x1, x0
    ba20:	540000a9 	b.ls	ba34 <__modti3+0x234>  // b.plast
    ba24:	ab000040 	adds	x0, x2, x0
    ba28:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ba2c:	8b020003 	add	x3, x0, x2
    ba30:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ba34:	cb010001 	sub	x1, x0, x1
    ba38:	9ac90820 	udiv	x0, x1, x9
    ba3c:	9b098403 	msub	x3, x0, x9, x1
    ba40:	aa0703e1 	mov	x1, x7
    ba44:	9b0a7c00 	mul	x0, x0, x10
    ba48:	b3607c61 	bfi	x1, x3, #32, #32
    ba4c:	eb01001f 	cmp	x0, x1
    ba50:	540000a9 	b.ls	ba64 <__modti3+0x264>  // b.plast
    ba54:	ab010041 	adds	x1, x2, x1
    ba58:	8b020022 	add	x2, x1, x2
    ba5c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ba60:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ba64:	cb000020 	sub	x0, x1, x0
    ba68:	17ffff91 	b	b8ac <__modti3+0xac>
    ba6c:	eb0203e5 	negs	x5, x2
    ba70:	aa0003e7 	mov	x7, x0
    ba74:	da0303e8 	ngc	x8, x3
    ba78:	aa0503e2 	mov	x2, x5
    ba7c:	aa0803e3 	mov	x3, x8
    ba80:	aa0103e6 	mov	x6, x1
    ba84:	b4ffed48 	cbz	x8, b82c <__modti3+0x2c>
    ba88:	eb01011f 	cmp	x8, x1
    ba8c:	54fff148 	b.hi	b8b4 <__modti3+0xb4>  // b.pmore
    ba90:	dac01109 	clz	x9, x8
    ba94:	2a0903e6 	mov	w6, w9
    ba98:	b5fff1c9 	cbnz	x9, b8d0 <__modti3+0xd0>
    ba9c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    baa0:	54000068 	b.hi	baac <__modti3+0x2ac>  // b.pmore
    baa4:	eb050007 	subs	x7, x0, x5
    baa8:	da080021 	sbc	x1, x1, x8
    baac:	aa0703e0 	mov	x0, x7
    bab0:	17ffff81 	b	b8b4 <__modti3+0xb4>
    bab4:	ab000040 	adds	x0, x2, x0
    bab8:	8b020002 	add	x2, x0, x2
    babc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    bac0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    bac4:	17ffff79 	b	b8a8 <__modti3+0xa8>
    bac8:	9ac82042 	lsl	x2, x2, x8
    bacc:	d2800803 	mov	x3, #0x40                  	// #64
    bad0:	cb080063 	sub	x3, x3, x8
    bad4:	d360fc49 	lsr	x9, x2, #32
    bad8:	9ac82027 	lsl	x7, x1, x8
    badc:	92407c4a 	and	x10, x2, #0xffffffff
    bae0:	9ac32426 	lsr	x6, x1, x3
    bae4:	9ac32403 	lsr	x3, x0, x3
    bae8:	aa070063 	orr	x3, x3, x7
    baec:	9ac908c1 	udiv	x1, x6, x9
    baf0:	9ac82007 	lsl	x7, x0, x8
    baf4:	9b099820 	msub	x0, x1, x9, x6
    baf8:	9b017d41 	mul	x1, x10, x1
    bafc:	93c38000 	extr	x0, x0, x3, #32
    bb00:	eb00003f 	cmp	x1, x0
    bb04:	540000a9 	b.ls	bb18 <__modti3+0x318>  // b.plast
    bb08:	ab000040 	adds	x0, x2, x0
    bb0c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    bb10:	8b020006 	add	x6, x0, x2
    bb14:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    bb18:	cb010000 	sub	x0, x0, x1
    bb1c:	9ac90801 	udiv	x1, x0, x9
    bb20:	9b098026 	msub	x6, x1, x9, x0
    bb24:	aa0303e0 	mov	x0, x3
    bb28:	9b017d41 	mul	x1, x10, x1
    bb2c:	b3607cc0 	bfi	x0, x6, #32, #32
    bb30:	eb00003f 	cmp	x1, x0
    bb34:	540000a9 	b.ls	bb48 <__modti3+0x348>  // b.plast
    bb38:	ab000040 	adds	x0, x2, x0
    bb3c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    bb40:	8b020003 	add	x3, x0, x2
    bb44:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    bb48:	cb010000 	sub	x0, x0, x1
    bb4c:	17ffffb0 	b	ba0c <__modti3+0x20c>
    bb50:	d1000969 	sub	x9, x11, #0x2
    bb54:	8b070021 	add	x1, x1, x7
    bb58:	17ffff83 	b	b964 <__modti3+0x164>
    bb5c:	d1000965 	sub	x5, x11, #0x2
    bb60:	8b070063 	add	x3, x3, x7
    bb64:	17ffff74 	b	b934 <__modti3+0x134>
    bb68:	d503201f 	nop
    bb6c:	d503201f 	nop

000000000000bb70 <atexit>:
    bb70:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    bb74:	b00000a2 	adrp	x2, 20000 <__data_start>
    bb78:	d2800001 	mov	x1, #0x0                   	// #0
    bb7c:	910003fd 	mov	x29, sp
    bb80:	a8c17bfd 	ldp	x29, x30, [sp], #16
    bb84:	f9400442 	ldr	x2, [x2, #8]
    bb88:	17ffdae2 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bb8c <_fini>:
    bb8c:	d503201f 	nop
    bb90:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    bb94:	910003fd 	mov	x29, sp
    bb98:	a8c17bfd 	ldp	x29, x30, [sp], #16
    bb9c:	d65f03c0 	ret
