
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-identical:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	90000045 	adrp	x5, a000 <fwp_main_thread+0x1d50>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913a60a5 	add	x5, x5, #0xe98
    2aa0:	90000044 	adrp	x4, a000 <fwp_main_thread+0x1d50>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	913a8084 	add	x4, x4, #0xea0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940004f0 	bl	3e90 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9100c2a1 	add	x1, x21, #0x30
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x114c0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9003c20 	str	x0, [x1, #120]
    2b2c:	940006f9 	bl	4710 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2b34:	9106c000 	add	x0, x0, #0x1b0
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xd3c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910ac042 	add	x2, x2, #0x2b0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c2b5 	add	x21, x21, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430aa0 	ldr	w0, [x21, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2c4c:	91078000 	add	x0, x0, #0x1e0
    2c50:	94000490 	bl	3e90 <fwp_trap>
    2c54:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2c58:	91070000 	add	x0, x0, #0x1c0
    2c5c:	9400048d 	bl	3e90 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2ca0:	9108e000 	add	x0, x0, #0x238
    2ca4:	9400047b 	bl	3e90 <fwp_trap>
    2ca8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2cac:	91082000 	add	x0, x0, #0x208
    2cb0:	94000478 	bl	3e90 <fwp_trap>
    2cb4:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x430>
    2cb8:	91098000 	add	x0, x0, #0x260
    2cbc:	94000475 	bl	3e90 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x430>
    2eb4:	91220021 	add	x1, x1, #0x880
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3050:	912f6000 	add	x0, x0, #0xbd8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x430>
    3118:	91218021 	add	x1, x1, #0x860
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    33f0:	912f6000 	add	x0, x0, #0xbd8
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    3530:	aa1303e0 	mov	x0, x19
    3534:	912fc021 	add	x1, x1, #0xbf0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    3544:	aa1303e0 	mov	x0, x19
    3548:	912fe021 	add	x1, x1, #0xbf8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    3560:	91300021 	add	x1, x1, #0xc00
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_format_g.constprop.0>:
    3580:	d10483ff 	sub	sp, sp, #0x120
    3584:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d50>
    3588:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    358c:	f947f442 	ldr	x2, [x2, #4072]
    3590:	91302084 	add	x4, x4, #0xc08
    3594:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3598:	9102c3fd 	add	x29, sp, #0xb0
    359c:	d2800803 	mov	x3, #0x40                  	// #64
    35a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    35a4:	93407c38 	sxtw	x24, w1
    35a8:	aa0303e1 	mov	x1, x3
    35ac:	fd008be8 	str	d8, [sp, #272]
    35b0:	1e604008 	fmov	d8, d0
    35b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    35b8:	910083f4 	add	x20, sp, #0x20
    35bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    35c0:	aa0003f5 	mov	x21, x0
    35c4:	a91073fb 	stp	x27, x28, [sp, #256]
    35c8:	5100071c 	sub	w28, w24, #0x1
    35cc:	2a1c03e5 	mov	w5, w28
    35d0:	f9400040 	ldr	x0, [x2]
    35d4:	f90057e0 	str	x0, [sp, #168]
    35d8:	d2800000 	mov	x0, #0x0                   	// #0
    35dc:	52800042 	mov	w2, #0x2                   	// #2
    35e0:	aa1403e0 	mov	x0, x20
    35e4:	97fffc83 	bl	27f0 <__snprintf_chk@plt>
    35e8:	52800ca1 	mov	w1, #0x65                  	// #101
    35ec:	aa1403e0 	mov	x0, x20
    35f0:	97fffcdc 	bl	2960 <strchr@plt>
    35f4:	aa0003f3 	mov	x19, x0
    35f8:	52800142 	mov	w2, #0xa                   	// #10
    35fc:	91000400 	add	x0, x0, #0x1
    3600:	d2800001 	mov	x1, #0x0                   	// #0
    3604:	97fffcc7 	bl	2920 <strtol@plt>
    3608:	aa0003f7 	mov	x23, x0
    360c:	11001400 	add	w0, w0, #0x5
    3610:	7100541f 	cmp	w0, #0x15
    3614:	54000d68 	b.hi	37c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3618:	4b170385 	sub	w5, w28, w23
    361c:	710000bf 	cmp	w5, #0x0
    3620:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3624:	54000b80 	b.eq	3794 <fwp_format_g.constprop.0+0x214>  // b.none
    3628:	394083e0 	ldrb	w0, [sp, #32]
    362c:	cb180273 	sub	x19, x19, x24
    3630:	91000673 	add	x19, x19, #0x1
    3634:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3638:	7100b41f 	cmp	w0, #0x2d
    363c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3640:	1a9f17e4 	cset	w4, eq	// eq = none
    3644:	cb010266 	sub	x6, x19, x1
    3648:	d10004da 	sub	x26, x6, #0x1
    364c:	540018a0 	b.eq	3960 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3650:	910183f9 	add	x25, sp, #0x60
    3654:	d280091b 	mov	x27, #0x48                  	// #72
    3658:	aa1903e7 	mov	x7, x25
    365c:	91000423 	add	x3, x1, #0x1
    3660:	91011cc6 	add	x6, x6, #0x47
    3664:	910004f6 	add	x22, x7, #0x1
    3668:	37f80ff7 	tbnz	w23, #31, 3864 <fwp_format_g.constprop.0+0x2e4>
    366c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3670:	93407ef7 	sxtw	x23, w23
    3674:	390000e4 	strb	w4, [x7]
    3678:	aa1303e1 	mov	x1, x19
    367c:	aa1703e2 	mov	x2, x23
    3680:	aa1603e0 	mov	x0, x22
    3684:	b9000be5 	str	w5, [sp, #8]
    3688:	cb170374 	sub	x20, x27, x23
    368c:	a9011be3 	stp	x3, x6, [sp, #16]
    3690:	97fffc10 	bl	26d0 <memcpy@plt>
    3694:	d1000694 	sub	x20, x20, #0x1
    3698:	f9400be3 	ldr	x3, [sp, #16]
    369c:	8b1702d6 	add	x22, x22, x23
    36a0:	aa1603e0 	mov	x0, x22
    36a4:	aa1a03e2 	mov	x2, x26
    36a8:	aa0303e1 	mov	x1, x3
    36ac:	aa1403e3 	mov	x3, x20
    36b0:	97fffc48 	bl	27d0 <__memcpy_chk@plt>
    36b4:	8b1a02d6 	add	x22, x22, x26
    36b8:	f9400fe6 	ldr	x6, [sp, #24]
    36bc:	d2800900 	mov	x0, #0x48                  	// #72
    36c0:	b9400be5 	ldr	w5, [sp, #8]
    36c4:	8b170261 	add	x1, x19, x23
    36c8:	cb1400c3 	sub	x3, x6, x20
    36cc:	cb060294 	sub	x20, x20, x6
    36d0:	f101207f 	cmp	x3, #0x48
    36d4:	93407cb8 	sxtw	x24, w5
    36d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    36dc:	aa1803e2 	mov	x2, x24
    36e0:	8b1802d3 	add	x19, x22, x24
    36e4:	8b140063 	add	x3, x3, x20
    36e8:	aa1603e0 	mov	x0, x22
    36ec:	97fffc39 	bl	27d0 <__memcpy_chk@plt>
    36f0:	cb190273 	sub	x19, x19, x25
    36f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    36f8:	eb00027f 	cmp	x19, x0
    36fc:	aa1903e1 	mov	x1, x25
    3700:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3704:	aa1503e0 	mov	x0, x21
    3708:	aa1303e2 	mov	x2, x19
    370c:	97fffbf1 	bl	26d0 <memcpy@plt>
    3710:	38336abf 	strb	wzr, [x21, x19]
    3714:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3718:	aa1503e0 	mov	x0, x21
    371c:	97fffbfd 	bl	2710 <strlen@plt>
    3720:	aa0003f3 	mov	x19, x0
    3724:	528005c1 	mov	w1, #0x2e                  	// #46
    3728:	aa1503e0 	mov	x0, x21
    372c:	97fffc8d 	bl	2960 <strchr@plt>
    3730:	b4000140 	cbz	x0, 3758 <fwp_format_g.constprop.0+0x1d8>
    3734:	b4000133 	cbz	x19, 3758 <fwp_format_g.constprop.0+0x1d8>
    3738:	aa1303e1 	mov	x1, x19
    373c:	d1000673 	sub	x19, x19, #0x1
    3740:	38736aa0 	ldrb	w0, [x21, x19]
    3744:	7100c01f 	cmp	w0, #0x30
    3748:	54001001 	b.ne	3948 <fwp_format_g.constprop.0+0x3c8>  // b.any
    374c:	38336abf 	strb	wzr, [x21, x19]
    3750:	b5ffff53 	cbnz	x19, 3738 <fwp_format_g.constprop.0+0x1b8>
    3754:	d503201f 	nop
    3758:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    375c:	f947f400 	ldr	x0, [x0, #4072]
    3760:	f94057e2 	ldr	x2, [sp, #168]
    3764:	f9400001 	ldr	x1, [x0]
    3768:	eb010042 	subs	x2, x2, x1
    376c:	d2800001 	mov	x1, #0x0                   	// #0
    3770:	54001061 	b.ne	397c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3774:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3778:	a94c53f3 	ldp	x19, x20, [sp, #192]
    377c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3780:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3784:	a95073fb 	ldp	x27, x28, [sp, #256]
    3788:	fd408be8 	ldr	d8, [sp, #272]
    378c:	910483ff 	add	sp, sp, #0x120
    3790:	d65f03c0 	ret
    3794:	1e604100 	fmov	d0, d8
    3798:	710000bf 	cmp	w5, #0x0
    379c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    37a0:	aa1503e0 	mov	x0, x21
    37a4:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d50>
    37a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37ac:	91308084 	add	x4, x4, #0xc20
    37b0:	52800042 	mov	w2, #0x2                   	// #2
    37b4:	d2803201 	mov	x1, #0x190                 	// #400
    37b8:	97fffc0e 	bl	27f0 <__snprintf_chk@plt>
    37bc:	17ffffd7 	b	3718 <fwp_format_g.constprop.0+0x198>
    37c0:	cb140273 	sub	x19, x19, x20
    37c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    37c8:	910183f9 	add	x25, sp, #0x60
    37cc:	aa1303e2 	mov	x2, x19
    37d0:	aa1403e1 	mov	x1, x20
    37d4:	aa1903e0 	mov	x0, x25
    37d8:	d2800803 	mov	x3, #0x40                  	// #64
    37dc:	97fffbfd 	bl	27d0 <__memcpy_chk@plt>
    37e0:	38336b3f 	strb	wzr, [x25, x19]
    37e4:	aa1903e0 	mov	x0, x25
    37e8:	528005c1 	mov	w1, #0x2e                  	// #46
    37ec:	97fffc5d 	bl	2960 <strchr@plt>
    37f0:	b40001c0 	cbz	x0, 3828 <fwp_format_g.constprop.0+0x2a8>
    37f4:	b50000b3 	cbnz	x19, 3808 <fwp_format_g.constprop.0+0x288>
    37f8:	1400000c 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    37fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3800:	f1000673 	subs	x19, x19, #0x1
    3804:	54000120 	b.eq	3828 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3808:	8b130320 	add	x0, x25, x19
    380c:	385ff001 	ldurb	w1, [x0, #-1]
    3810:	7100c03f 	cmp	w1, #0x30
    3814:	54ffff40 	b.eq	37fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3818:	d1000673 	sub	x19, x19, #0x1
    381c:	38736b20 	ldrb	w0, [x25, x19]
    3820:	7100b81f 	cmp	w0, #0x2e
    3824:	54000a80 	b.eq	3974 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3828:	710002ff 	cmp	w23, #0x0
    382c:	528005a1 	mov	w1, #0x2d                  	// #45
    3830:	aa1903e5 	mov	x5, x25
    3834:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3838:	aa1503e0 	mov	x0, x21
    383c:	52800566 	mov	w6, #0x2b                  	// #43
    3840:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d50>
    3844:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3848:	91304084 	add	x4, x4, #0xc10
    384c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3850:	52800042 	mov	w2, #0x2                   	// #2
    3854:	d2803201 	mov	x1, #0x190                 	// #400
    3858:	97fffbe6 	bl	27f0 <__snprintf_chk@plt>
    385c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3860:	17ffffbe 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3864:	52800605 	mov	w5, #0x30                  	// #48
    3868:	390000e5 	strb	w5, [x7]
    386c:	d100077b 	sub	x27, x27, #0x1
    3870:	aa0303e1 	mov	x1, x3
    3874:	aa1603e0 	mov	x0, x22
    3878:	aa1b03e3 	mov	x3, x27
    387c:	aa1a03e2 	mov	x2, x26
    3880:	f90007e6 	str	x6, [sp, #8]
    3884:	b90013e4 	str	w4, [sp, #16]
    3888:	8b1a02d6 	add	x22, x22, x26
    388c:	b9001be5 	str	w5, [sp, #24]
    3890:	97fffbd0 	bl	27d0 <__memcpy_chk@plt>
    3894:	f94007e6 	ldr	x6, [sp, #8]
    3898:	2a3703e7 	mvn	w7, w23
    389c:	b94013e4 	ldr	w4, [sp, #16]
    38a0:	cb1b00c1 	sub	x1, x6, x27
    38a4:	cb06037b 	sub	x27, x27, x6
    38a8:	f101203f 	cmp	x1, #0x48
    38ac:	d2800906 	mov	x6, #0x48                  	// #72
    38b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    38b4:	8b1b0023 	add	x3, x1, x27
    38b8:	310006ff 	cmn	w23, #0x1
    38bc:	54000220 	b.eq	3900 <fwp_format_g.constprop.0+0x380>  // b.none
    38c0:	b9401be5 	ldr	w5, [sp, #24]
    38c4:	d2800001 	mov	x1, #0x0                   	// #0
    38c8:	f101207f 	cmp	x3, #0x48
    38cc:	d1000462 	sub	x2, x3, #0x1
    38d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    38d4:	38216ac5 	strb	w5, [x22, x1]
    38d8:	cb030003 	sub	x3, x0, x3
    38dc:	91000421 	add	x1, x1, #0x1
    38e0:	91000463 	add	x3, x3, #0x1
    38e4:	eb00007f 	cmp	x3, x0
    38e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38ec:	cb000063 	sub	x3, x3, x0
    38f0:	8b020063 	add	x3, x3, x2
    38f4:	6b0100ff 	cmp	w7, w1
    38f8:	54fffe8c 	b.gt	38c8 <fwp_format_g.constprop.0+0x348>
    38fc:	8b2742d6 	add	x22, x22, w7, uxtw
    3900:	f101207f 	cmp	x3, #0x48
    3904:	d2800905 	mov	x5, #0x48                  	// #72
    3908:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    390c:	aa1603e0 	mov	x0, x22
    3910:	cb0300a1 	sub	x1, x5, x3
    3914:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3918:	91000421 	add	x1, x1, #0x1
    391c:	d1000463 	sub	x3, x3, #0x1
    3920:	eb05003f 	cmp	x1, x5
    3924:	38001402 	strb	w2, [x0], #1
    3928:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    392c:	93407f82 	sxtw	x2, w28
    3930:	cb050025 	sub	x5, x1, x5
    3934:	aa1303e1 	mov	x1, x19
    3938:	8b0300a3 	add	x3, x5, x3
    393c:	8b1802d3 	add	x19, x22, x24
    3940:	97fffba4 	bl	27d0 <__memcpy_chk@plt>
    3944:	17ffff6b 	b	36f0 <fwp_format_g.constprop.0+0x170>
    3948:	d1000421 	sub	x1, x1, #0x1
    394c:	38616aa0 	ldrb	w0, [x21, x1]
    3950:	7100b81f 	cmp	w0, #0x2e
    3954:	54fff021 	b.ne	3758 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3958:	38216abf 	strb	wzr, [x21, x1]
    395c:	17ffff7f 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3960:	910187e7 	add	x7, sp, #0x61
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d28008fb 	mov	x27, #0x47                  	// #71
    396c:	390183e0 	strb	w0, [sp, #96]
    3970:	17ffff3b 	b	365c <fwp_format_g.constprop.0+0xdc>
    3974:	38336b3f 	strb	wzr, [x25, x19]
    3978:	17ffffac 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    397c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3980:	97fffbc0 	bl	2880 <__stack_chk_fail@plt>

0000000000003984 <fwp_heap_report>:
    3984:	d105c3ff 	sub	sp, sp, #0x170
    3988:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    398c:	91150042 	add	x2, x2, #0x540
    3990:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3994:	f947e821 	ldr	x1, [x1, #4048]
    3998:	a9117bfd 	stp	x29, x30, [sp, #272]
    399c:	910443fd 	add	x29, sp, #0x110
    39a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    39a4:	f947f400 	ldr	x0, [x0, #4072]
    39a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    39ac:	a91463f7 	stp	x23, x24, [sp, #320]
    39b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    39b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    39b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    39bc:	fd4a2049 	ldr	d9, [x2, #5184]
    39c0:	f9400036 	ldr	x22, [x1]
    39c4:	f9400001 	ldr	x1, [x0]
    39c8:	f90087e1 	str	x1, [sp, #264]
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	f949e459 	ldr	x25, [x2, #5064]
    39d4:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    39d8:	f94a1057 	ldr	x23, [x2, #5152]
    39dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    39e0:	f94a1458 	ldr	x24, [x2, #5160]
    39e4:	9130a021 	add	x1, x1, #0xc28
    39e8:	9130c000 	add	x0, x0, #0xc30
    39ec:	97fffb89 	bl	2810 <fopen@plt>
    39f0:	b4000760 	cbz	x0, 3adc <fwp_heap_report+0x158>
    39f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    39f8:	a91253f3 	stp	x19, x20, [sp, #288]
    39fc:	aa0003f4 	mov	x20, x0
    3a00:	910023f3 	add	x19, sp, #0x8
    3a04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a08:	72aae915 	movk	w21, #0x5748, lsl #16
    3a0c:	d503201f 	nop
    3a10:	aa1403e2 	mov	x2, x20
    3a14:	aa1303e0 	mov	x0, x19
    3a18:	52802001 	mov	w1, #0x100                 	// #256
    3a1c:	97fffc09 	bl	2a40 <fgets@plt>
    3a20:	b4000280 	cbz	x0, 3a70 <fwp_heap_report+0xec>
    3a24:	b9400261 	ldr	w1, [x19]
    3a28:	6b15003f 	cmp	w1, w21
    3a2c:	54ffff21 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a30:	39401260 	ldrb	w0, [x19, #4]
    3a34:	7101341f 	cmp	w0, #0x4d
    3a38:	54fffec1 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a3c:	394037e0 	ldrb	w0, [sp, #13]
    3a40:	7100e81f 	cmp	w0, #0x3a
    3a44:	54fffe61 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a48:	52800142 	mov	w2, #0xa                   	// #10
    3a4c:	d2800001 	mov	x1, #0x0                   	// #0
    3a50:	91003be0 	add	x0, sp, #0xe
    3a54:	97fffbb3 	bl	2920 <strtol@plt>
    3a58:	aa1403e2 	mov	x2, x20
    3a5c:	aa0003fa 	mov	x26, x0
    3a60:	52802001 	mov	w1, #0x100                 	// #256
    3a64:	aa1303e0 	mov	x0, x19
    3a68:	97fffbf6 	bl	2a40 <fgets@plt>
    3a6c:	b5fffdc0 	cbnz	x0, 3a24 <fwp_heap_report+0xa0>
    3a70:	aa1403e0 	mov	x0, x20
    3a74:	97fffb63 	bl	2800 <fclose@plt>
    3a78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3a7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a80:	f947f400 	ldr	x0, [x0, #4072]
    3a84:	f94087e2 	ldr	x2, [sp, #264]
    3a88:	f9400001 	ldr	x1, [x0]
    3a8c:	eb010042 	subs	x2, x2, x1
    3a90:	d2800001 	mov	x1, #0x0                   	// #0
    3a94:	54000281 	b.ne	3ae4 <fwp_heap_report+0x160>  // b.any
    3a98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a9c:	aa1a03e6 	mov	x6, x26
    3aa0:	aa1903e5 	mov	x5, x25
    3aa4:	aa1803e4 	mov	x4, x24
    3aa8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3aac:	aa1703e3 	mov	x3, x23
    3ab0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3abc:	1e604121 	fmov	d1, d9
    3ac0:	1e604100 	fmov	d0, d8
    3ac4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1d50>
    3ac8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3acc:	91314042 	add	x2, x2, #0xc50
    3ad0:	9105c3ff 	add	sp, sp, #0x170
    3ad4:	52800041 	mov	w1, #0x2                   	// #2
    3ad8:	17fffb86 	b	28f0 <__fprintf_chk@plt>
    3adc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ae0:	17ffffe7 	b	3a7c <fwp_heap_report+0xf8>
    3ae4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ae8:	97fffb66 	bl	2880 <__stack_chk_fail@plt>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_heap_init>:
    3af0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3af4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3af8:	91110061 	add	x1, x3, #0x440
    3afc:	910003fd 	mov	x29, sp
    3b00:	a90153f3 	stp	x19, x20, [sp, #16]
    3b04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3b08:	91150262 	add	x2, x19, #0x540
    3b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b10:	52800024 	mov	w4, #0x1                   	// #1
    3b14:	52800200 	mov	w0, #0x10                  	// #16
    3b18:	b913a444 	str	w4, [x2, #5028]
    3b1c:	d503201f 	nop
    3b20:	b8004420 	str	w0, [x1], #4
    3b24:	11004000 	add	w0, w0, #0x10
    3b28:	7104401f 	cmp	w0, #0x110
    3b2c:	54ffffa1 	b.ne	3b20 <fwp_heap_init+0x30>  // b.any
    3b30:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x430>
    3b34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3b38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3b3c:	91120021 	add	x1, x1, #0x480
    3b40:	3dc22443 	ldr	q3, [x2, #2192]
    3b44:	d2800000 	mov	x0, #0x0                   	// #0
    3b48:	4e040401 	dup	v1.4s, v0.s[0]
    3b4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3b50:	0f215400 	shl	v0.2s, v0.2s, #1
    3b54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3b58:	3ca06821 	str	q1, [x1, x0]
    3b5c:	91004000 	add	x0, x0, #0x10
    3b60:	f101801f 	cmp	x0, #0x60
    3b64:	54ffff21 	b.ne	3b48 <fwp_heap_init+0x58>  // b.any
    3b68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3b6c:	91110063 	add	x3, x3, #0x440
    3b70:	91138084 	add	x4, x4, #0x4e0
    3b74:	91150266 	add	x6, x19, #0x540
    3b78:	d2800002 	mov	x2, #0x0                   	// #0
    3b7c:	d2800000 	mov	x0, #0x0                   	// #0
    3b80:	d2880205 	mov	x5, #0x4010                	// #16400
    3b84:	d503201f 	nop
    3b88:	910f0001 	add	x1, x0, #0x3c0
    3b8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b90:	eb02003f 	cmp	x1, x2
    3b94:	540000a2 	b.cs	3ba8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b98:	91000400 	add	x0, x0, #0x1
    3b9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ba0:	eb02003f 	cmp	x1, x2
    3ba4:	54ffffa3 	b.cc	3b98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ba8:	91004042 	add	x2, x2, #0x10
    3bac:	38001480 	strb	w0, [x4], #1
    3bb0:	eb05005f 	cmp	x2, x5
    3bb4:	54fffea1 	b.ne	3b88 <fwp_heap_init+0x98>  // b.any
    3bb8:	528000b5 	mov	w21, #0x5                   	// #5
    3bbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3bc0:	14000004 	b	3bd0 <fwp_heap_init+0xe0>
    3bc4:	d342fe94 	lsr	x20, x20, #2
    3bc8:	710006b5 	subs	w21, w21, #0x1
    3bcc:	54000720 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3bd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3bd4:	d2800005 	mov	x5, #0x0                   	// #0
    3bd8:	aa1603e1 	mov	x1, x22
    3bdc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3be0:	52880443 	mov	w3, #0x4022                	// #16418
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	d2800000 	mov	x0, #0x0                   	// #0
    3bec:	97fffb49 	bl	2910 <mmap@plt>
    3bf0:	aa0003e6 	mov	x6, x0
    3bf4:	b100041f 	cmn	x0, #0x1
    3bf8:	54fffe60 	b.eq	3bc4 <fwp_heap_init+0xd4>  // b.none
    3bfc:	b40005a0 	cbz	x0, 3cb0 <fwp_heap_init+0x1c0>
    3c00:	d350fe94 	lsr	x20, x20, #16
    3c04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3c08:	8b0000c7 	add	x7, x6, x0
    3c0c:	91150275 	add	x21, x19, #0x540
    3c10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3c14:	8b140a81 	add	x1, x20, x20, lsl #2
    3c18:	d2800005 	mov	x5, #0x0                   	// #0
    3c1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3c20:	d37df021 	lsl	x1, x1, #3
    3c24:	52880443 	mov	w3, #0x4022                	// #16418
    3c28:	52800002 	mov	w2, #0x0                   	// #0
    3c2c:	d2800000 	mov	x0, #0x0                   	// #0
    3c30:	f909daa7 	str	x7, [x21, #5040]
    3c34:	f909dea6 	str	x6, [x21, #5048]
    3c38:	f909e2b6 	str	x22, [x21, #5056]
    3c3c:	f909eab4 	str	x20, [x21, #5072]
    3c40:	f90a02a1 	str	x1, [x21, #5120]
    3c44:	97fffb33 	bl	2910 <mmap@plt>
    3c48:	aa0003e1 	mov	x1, x0
    3c4c:	b100041f 	cmn	x0, #0x1
    3c50:	54000300 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3c54:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3c58:	91336000 	add	x0, x0, #0xcd8
    3c5c:	f909fea1 	str	x1, [x21, #5112]
    3c60:	97fffb6c 	bl	2a10 <getenv@plt>
    3c64:	52800002 	mov	w2, #0x0                   	// #0
    3c68:	aa0003e1 	mov	x1, x0
    3c6c:	b40000e0 	cbz	x0, 3c88 <fwp_heap_init+0x198>
    3c70:	39400000 	ldrb	w0, [x0]
    3c74:	340000a0 	cbz	w0, 3c88 <fwp_heap_init+0x198>
    3c78:	7100c000 	subs	w0, w0, #0x30
    3c7c:	54000120 	b.eq	3ca0 <fwp_heap_init+0x1b0>  // b.none
    3c80:	7100001f 	cmp	w0, #0x0
    3c84:	1a9f07e2 	cset	w2, ne	// ne = any
    3c88:	91150273 	add	x19, x19, #0x540
    3c8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c90:	b913aa62 	str	w2, [x19, #5032]
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c9c:	d65f03c0 	ret
    3ca0:	39400420 	ldrb	w0, [x1, #1]
    3ca4:	7100001f 	cmp	w0, #0x0
    3ca8:	1a9f07e2 	cset	w2, ne	// ne = any
    3cac:	17fffff7 	b	3c88 <fwp_heap_init+0x198>
    3cb0:	97fffce0 	bl	3030 <fwp_heap_oom>

0000000000003cb4 <fwp_wake_io>:
    3cb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3cb8:	9100c122 	add	x2, x9, #0x30
    3cbc:	f9400001 	ldr	x1, [x0]
    3cc0:	5280000a 	mov	w10, #0x0                   	// #0
    3cc4:	f9401446 	ldr	x6, [x2, #40]
    3cc8:	52800008 	mov	w8, #0x0                   	// #0
    3ccc:	4f000400 	movi	v0.4s, #0x0
    3cd0:	52800027 	mov	w7, #0x1                   	// #1
    3cd4:	aa0103e2 	mov	x2, x1
    3cd8:	b4000321 	cbz	x1, 3d3c <fwp_wake_io+0x88>
    3cdc:	f9408c25 	ldr	x5, [x1, #280]
    3ce0:	39015c27 	strb	w7, [x1, #87]
    3ce4:	b4000165 	cbz	x5, 3d10 <fwp_wake_io+0x5c>
    3ce8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3cec:	b4000364 	cbz	x4, 3d58 <fwp_wake_io+0xa4>
    3cf0:	f9009483 	str	x3, [x4, #296]
    3cf4:	f9409423 	ldr	x3, [x1, #296]
    3cf8:	b4000043 	cbz	x3, 3d00 <fwp_wake_io+0x4c>
    3cfc:	f9009064 	str	x4, [x3, #288]
    3d00:	91080023 	add	x3, x1, #0x200
    3d04:	f900943f 	str	xzr, [x1, #296]
    3d08:	3c918060 	stur	q0, [x3, #-232]
    3d0c:	f9400001 	ldr	x1, [x0]
    3d10:	f9402843 	ldr	x3, [x2, #80]
    3d14:	f2001c7f 	tst	x3, #0xff000000ff
    3d18:	54fffde1 	b.ne	3cd4 <fwp_wake_io+0x20>  // b.any
    3d1c:	39015047 	strb	w7, [x2, #84]
    3d20:	f900805f 	str	xzr, [x2, #256]
    3d24:	b40001e6 	cbz	x6, 3d60 <fwp_wake_io+0xac>
    3d28:	f90080c2 	str	x2, [x6, #256]
    3d2c:	aa0203e6 	mov	x6, x2
    3d30:	52800028 	mov	w8, #0x1                   	// #1
    3d34:	aa0103e2 	mov	x2, x1
    3d38:	b5fffd21 	cbnz	x1, 3cdc <fwp_wake_io+0x28>
    3d3c:	3400006a 	cbz	w10, 3d48 <fwp_wake_io+0x94>
    3d40:	9100c120 	add	x0, x9, #0x30
    3d44:	f900180b 	str	x11, [x0, #48]
    3d48:	34000068 	cbz	w8, 3d54 <fwp_wake_io+0xa0>
    3d4c:	9100c129 	add	x9, x9, #0x30
    3d50:	f9001526 	str	x6, [x9, #40]
    3d54:	d65f03c0 	ret
    3d58:	f90000a3 	str	x3, [x5]
    3d5c:	17ffffe7 	b	3cf8 <fwp_wake_io+0x44>
    3d60:	aa0203eb 	mov	x11, x2
    3d64:	5280002a 	mov	w10, #0x1                   	// #1
    3d68:	17fffff1 	b	3d2c <fwp_wake_io+0x78>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_tape_buffers_release>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	910003fd 	mov	x29, sp
    3d78:	a90153f3 	stp	x19, x20, [sp, #16]
    3d7c:	aa0003f3 	mov	x19, x0
    3d80:	f9401400 	ldr	x0, [x0, #40]
    3d84:	b7f80760 	tbnz	x0, #63, 3e70 <fwp_tape_buffers_release+0x100>
    3d88:	f9401a61 	ldr	x1, [x19, #48]
    3d8c:	b7f80301 	tbnz	x1, #63, 3dec <fwp_tape_buffers_release+0x7c>
    3d90:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d94:	eb02001f 	cmp	x0, x2
    3d98:	540002a8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d9c:	8b000400 	add	x0, x0, x0, lsl #1
    3da0:	d2a00102 	mov	x2, #0x80000               	// #524288
    3da4:	d37df000 	lsl	x0, x0, #3
    3da8:	cb000042 	sub	x2, x2, x0
    3dac:	eb420c3f 	cmp	x1, x2, lsr #3
    3db0:	540001e8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3db4:	8b010c14 	add	x20, x0, x1, lsl #3
    3db8:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3dbc:	9133a000 	add	x0, x0, #0xce8
    3dc0:	97fffb14 	bl	2a10 <getenv@plt>
    3dc4:	b4000240 	cbz	x0, 3e0c <fwp_tape_buffers_release+0x9c>
    3dc8:	39400001 	ldrb	w1, [x0]
    3dcc:	7100c03f 	cmp	w1, #0x30
    3dd0:	540001e1 	b.ne	3e0c <fwp_tape_buffers_release+0x9c>  // b.any
    3dd4:	39400400 	ldrb	w0, [x0, #1]
    3dd8:	350001a0 	cbnz	w0, 3e0c <fwp_tape_buffers_release+0x9c>
    3ddc:	aa1303e0 	mov	x0, x19
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de8:	17fffd46 	b	3300 <fwp_tape_buffers_dispose>
    3dec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3df0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df4:	9133a000 	add	x0, x0, #0xce8
    3df8:	97fffb06 	bl	2a10 <getenv@plt>
    3dfc:	b4ffff00 	cbz	x0, 3ddc <fwp_tape_buffers_release+0x6c>
    3e00:	39400001 	ldrb	w1, [x0]
    3e04:	7100c03f 	cmp	w1, #0x30
    3e08:	54fffe60 	b.eq	3dd4 <fwp_tape_buffers_release+0x64>  // b.none
    3e0c:	d1000681 	sub	x1, x20, #0x1
    3e10:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3e14:	eb00003f 	cmp	x1, x0
    3e18:	54fffe28 	b.hi	3ddc <fwp_tape_buffers_release+0x6c>  // b.pmore
    3e1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e20:	b00000f6 	adrp	x22, 20000 <__data_start>
    3e24:	9100c2d6 	add	x22, x22, #0x30
    3e28:	9100e2d5 	add	x21, x22, #0x38
    3e2c:	aa1503e0 	mov	x0, x21
    3e30:	97fffd34 	bl	3300 <fwp_tape_buffers_dispose>
    3e34:	ad400a61 	ldp	q1, q2, [x19]
    3e38:	f9003ad4 	str	x20, [x22, #112]
    3e3c:	4f000400 	movi	v0.4s, #0x0
    3e40:	ad000aa1 	stp	q1, q2, [x21]
    3e44:	3dc00a61 	ldr	q1, [x19, #32]
    3e48:	3d800aa1 	str	q1, [x21, #32]
    3e4c:	f9401a60 	ldr	x0, [x19, #48]
    3e50:	f9001aa0 	str	x0, [x21, #48]
    3e54:	f9001a7f 	str	xzr, [x19, #48]
    3e58:	ad000260 	stp	q0, q0, [x19]
    3e5c:	3d800a60 	str	q0, [x19, #32]
    3e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e6c:	d65f03c0 	ret
    3e70:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3e74:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3e78:	9133a000 	add	x0, x0, #0xce8
    3e7c:	97fffae5 	bl	2a10 <getenv@plt>
    3e80:	b5fffa40 	cbnz	x0, 3dc8 <fwp_tape_buffers_release+0x58>
    3e84:	17ffffd6 	b	3ddc <fwp_tape_buffers_release+0x6c>
    3e88:	d503201f 	nop
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_trap>:
    3e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e94:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e98:	d53bd041 	mrs	x1, tpidr_el0
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	f9401c42 	ldr	x2, [x2, #56]
    3ea4:	91400021 	add	x1, x1, #0x0, lsl #12
    3ea8:	91004021 	add	x1, x1, #0x10
    3eac:	a90153f3 	stp	x19, x20, [sp, #16]
    3eb0:	aa0003f3 	mov	x19, x0
    3eb4:	f9400034 	ldr	x20, [x1]
    3eb8:	b4000062 	cbz	x2, 3ec4 <fwp_trap+0x34>
    3ebc:	aa0203e0 	mov	x0, x2
    3ec0:	97fffabc 	bl	29b0 <fflush@plt>
    3ec4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ec8:	f947ec00 	ldr	x0, [x0, #4056]
    3ecc:	f9400000 	ldr	x0, [x0]
    3ed0:	97fffab8 	bl	29b0 <fflush@plt>
    3ed4:	aa1303e3 	mov	x3, x19
    3ed8:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1d50>
    3edc:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    3ee0:	f947ea73 	ldr	x19, [x19, #4048]
    3ee4:	91340042 	add	x2, x2, #0xd00
    3ee8:	52800041 	mov	w1, #0x2                   	// #2
    3eec:	f9400260 	ldr	x0, [x19]
    3ef0:	97fffa80 	bl	28f0 <__fprintf_chk@plt>
    3ef4:	b40000b4 	cbz	x20, 3f08 <fwp_trap+0x78>
    3ef8:	f9400260 	ldr	x0, [x19]
    3efc:	97fffaad 	bl	29b0 <fflush@plt>
    3f00:	52800ca0 	mov	w0, #0x65                  	// #101
    3f04:	97fffabb 	bl	29f0 <_Exit@plt>
    3f08:	52800ca0 	mov	w0, #0x65                  	// #101
    3f0c:	97fffa09 	bl	2730 <exit@plt>

0000000000003f10 <fwp_rc_forget_slot.part.0>:
    3f10:	ca404401 	eor	x1, x0, x0, lsr #17
    3f14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3f18:	ca412421 	eor	x1, x1, x1, lsr #9
    3f1c:	910003fd 	mov	x29, sp
    3f20:	92401c21 	and	x1, x1, #0xff
    3f24:	f9000bf3 	str	x19, [sp, #16]
    3f28:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3f2c:	91150262 	add	x2, x19, #0x540
    3f30:	910a2423 	add	x3, x1, #0x289
    3f34:	8b010c41 	add	x1, x2, x1, lsl #3
    3f38:	8b030c43 	add	x3, x2, x3, lsl #3
    3f3c:	f94a2421 	ldr	x1, [x1, #5192]
    3f40:	b50000a1 	cbnz	x1, 3f54 <fwp_rc_forget_slot.part.0+0x44>
    3f44:	14000012 	b	3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f48:	91004023 	add	x3, x1, #0x10
    3f4c:	f9400821 	ldr	x1, [x1, #16]
    3f50:	b40001e1 	cbz	x1, 3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f54:	f9400022 	ldr	x2, [x1]
    3f58:	eb02001f 	cmp	x0, x2
    3f5c:	54ffff61 	b.ne	3f48 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3f60:	f9400060 	ldr	x0, [x3]
    3f64:	91150273 	add	x19, x19, #0x540
    3f68:	f9400801 	ldr	x1, [x0, #16]
    3f6c:	f9000061 	str	x1, [x3]
    3f70:	97fffa74 	bl	2940 <free@plt>
    3f74:	f94e2660 	ldr	x0, [x19, #7240]
    3f78:	d1000400 	sub	x0, x0, #0x1
    3f7c:	f90e2660 	str	x0, [x19, #7240]
    3f80:	f9400bf3 	ldr	x19, [sp, #16]
    3f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f88:	d65f03c0 	ret
    3f8c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    3f90:	91344000 	add	x0, x0, #0xd10
    3f94:	97ffffbf 	bl	3e90 <fwp_trap>
    3f98:	d503201f 	nop
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_rc_prepare_chunk>:
    3fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3fa4:	910003fd 	mov	x29, sp
    3fa8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fac:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    3fb0:	911502c2 	add	x2, x22, #0x540
    3fb4:	b9401c03 	ldr	w3, [x0, #28]
    3fb8:	aa0103f5 	mov	x21, x1
    3fbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fc0:	aa0003f4 	mov	x20, x0
    3fc4:	f94e2440 	ldr	x0, [x2, #7240]
    3fc8:	b4000440 	cbz	x0, 4050 <fwp_rc_prepare_chunk+0xb0>
    3fcc:	d2800013 	mov	x19, #0x0                   	// #0
    3fd0:	35000203 	cbnz	w3, 4010 <fwp_rc_prepare_chunk+0x70>
    3fd4:	b4000361 	cbz	x1, 4040 <fwp_rc_prepare_chunk+0xa0>
    3fd8:	f9401280 	ldr	x0, [x20, #32]
    3fdc:	97fffa59 	bl	2940 <free@plt>
    3fe0:	aa1503e0 	mov	x0, x21
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	97fffa1e 	bl	2860 <calloc@plt>
    3fec:	f9001280 	str	x0, [x20, #32]
    3ff0:	b5000460 	cbnz	x0, 407c <fwp_rc_prepare_chunk+0xdc>
    3ff4:	97fffc0f 	bl	3030 <fwp_heap_oom>
    3ff8:	97ffffc6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    3ffc:	91000673 	add	x19, x19, #0x1
    4000:	b9401e83 	ldr	w3, [x20, #28]
    4004:	eb13007f 	cmp	x3, x19
    4008:	54000169 	b.ls	4034 <fwp_rc_prepare_chunk+0x94>  // b.plast
    400c:	d503201f 	nop
    4010:	f9401283 	ldr	x3, [x20, #32]
    4014:	8b130060 	add	x0, x3, x19
    4018:	38736863 	ldrb	w3, [x3, x19]
    401c:	7103fc7f 	cmp	w3, #0xff
    4020:	54fffec0 	b.eq	3ff8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4024:	b9401e83 	ldr	w3, [x20, #28]
    4028:	91000673 	add	x19, x19, #0x1
    402c:	eb13007f 	cmp	x3, x19
    4030:	54ffff08 	b.hi	4010 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4034:	eb0302bf 	cmp	x21, x3
    4038:	54000121 	b.ne	405c <fwp_rc_prepare_chunk+0xbc>  // b.any
    403c:	b5000335 	cbnz	x21, 40a0 <fwp_rc_prepare_chunk+0x100>
    4040:	a94153f3 	ldp	x19, x20, [sp, #16]
    4044:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    404c:	d65f03c0 	ret
    4050:	2a0303e3 	mov	w3, w3
    4054:	eb0302bf 	cmp	x21, x3
    4058:	54ffff20 	b.eq	403c <fwp_rc_prepare_chunk+0x9c>  // b.none
    405c:	911502c2 	add	x2, x22, #0x540
    4060:	f9401280 	ldr	x0, [x20, #32]
    4064:	f94e2841 	ldr	x1, [x2, #7248]
    4068:	cb030021 	sub	x1, x1, x3
    406c:	f90e2841 	str	x1, [x2, #7248]
    4070:	97fffa34 	bl	2940 <free@plt>
    4074:	b5fffb75 	cbnz	x21, 3fe0 <fwp_rc_prepare_chunk+0x40>
    4078:	f900129f 	str	xzr, [x20, #32]
    407c:	911502d6 	add	x22, x22, #0x540
    4080:	f94e2ac0 	ldr	x0, [x22, #7248]
    4084:	b9001e95 	str	w21, [x20, #28]
    4088:	a94153f3 	ldp	x19, x20, [sp, #16]
    408c:	8b150000 	add	x0, x0, x21
    4090:	f90e2ac0 	str	x0, [x22, #7248]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    409c:	d65f03c0 	ret
    40a0:	f9401280 	ldr	x0, [x20, #32]
    40a4:	aa1503e2 	mov	x2, x21
    40a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    40ac:	52800001 	mov	w1, #0x0                   	// #0
    40b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40b8:	17fff9e6 	b	2850 <memset@plt>
    40bc:	d503201f 	nop

00000000000040c0 <fwp_heap_refill>:
    40c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    40c4:	910003fd 	mov	x29, sp
    40c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    40cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    40d0:	911502b5 	add	x21, x21, #0x540
    40d4:	aa0003f6 	mov	x22, x0
    40d8:	d2800020 	mov	x0, #0x1                   	// #1
    40dc:	a90153f3 	stp	x19, x20, [sp, #16]
    40e0:	a90363f7 	stp	x23, x24, [sp, #48]
    40e4:	2a0103f7 	mov	w23, w1
    40e8:	2a0203f8 	mov	w24, w2
    40ec:	97fffc11 	bl	3130 <fwp_heap_chunks>
    40f0:	aa0003f3 	mov	x19, x0
    40f4:	f949fea2 	ldr	x2, [x21, #5112]
    40f8:	8b000800 	add	x0, x0, x0, lsl #2
    40fc:	2a1703e1 	mov	w1, w23
    4100:	52800025 	mov	w5, #0x1                   	// #1
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	910f0021 	add	x1, x1, #0x3c0
    410c:	8b000054 	add	x20, x2, x0
    4110:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4114:	52a00024 	mov	w4, #0x10000               	// #65536
    4118:	38206845 	strb	w5, [x2, x0]
    411c:	aa1403e0 	mov	x0, x20
    4120:	39000698 	strb	w24, [x20, #1]
    4124:	39000a97 	strb	w23, [x20, #2]
    4128:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    412c:	b9000681 	str	w1, [x20, #4]
    4130:	2a0103e5 	mov	w5, w1
    4134:	8b0300a2 	add	x2, x5, x3
    4138:	1ac10881 	udiv	w1, w4, w1
    413c:	9ac50842 	udiv	x2, x2, x5
    4140:	b9000a81 	str	w1, [x20, #8]
    4144:	92404021 	and	x1, x1, #0x1ffff
    4148:	b9001a82 	str	w2, [x20, #24]
    414c:	97ffff95 	bl	3fa0 <fwp_rc_prepare_chunk>
    4150:	f949daa0 	ldr	x0, [x21, #5040]
    4154:	29408a81 	ldp	w1, w2, [x20, #4]
    4158:	8b134000 	add	x0, x0, x19, lsl #16
    415c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4160:	8b214003 	add	x3, x0, w1, uxtw
    4164:	9ba20021 	umaddl	x1, w1, w2, x0
    4168:	a94363f7 	ldp	x23, x24, [sp, #48]
    416c:	a90086c3 	stp	x3, x1, [x22, #8]
    4170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4174:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4178:	d65f03c0 	ret
    417c:	d503201f 	nop

0000000000004180 <fwp_mem_free>:
    4180:	b40003c0 	cbz	x0, 41f8 <fwp_mem_free+0x78>
    4184:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4188:	910003fd 	mov	x29, sp
    418c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4190:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4194:	911502a1 	add	x1, x21, #0x540
    4198:	a90153f3 	stp	x19, x20, [sp, #16]
    419c:	aa0003f3 	mov	x19, x0
    41a0:	f949d823 	ldr	x3, [x1, #5040]
    41a4:	f949ec22 	ldr	x2, [x1, #5080]
    41a8:	cb030000 	sub	x0, x0, x3
    41ac:	eb02401f 	cmp	x0, x2, lsl #16
    41b0:	540001c2 	b.cs	41e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    41b4:	d350fc16 	lsr	x22, x0, #16
    41b8:	a90363f7 	stp	x23, x24, [sp, #48]
    41bc:	f949fc22 	ldr	x2, [x1, #5112]
    41c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    41c4:	d37df294 	lsl	x20, x20, #3
    41c8:	ab140057 	adds	x23, x2, x20
    41cc:	540000c0 	b.eq	41e4 <fwp_mem_free+0x64>  // b.none
    41d0:	38746842 	ldrb	w2, [x2, x20]
    41d4:	7100045f 	cmp	w2, #0x1
    41d8:	54000120 	b.eq	41fc <fwp_mem_free+0x7c>  // b.none
    41dc:	7100085f 	cmp	w2, #0x2
    41e0:	540005e0 	b.eq	429c <fwp_mem_free+0x11c>  // b.none
    41e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    41f4:	d65f03c0 	ret
    41f8:	d65f03c0 	ret
    41fc:	f94012f8 	ldr	x24, [x23, #32]
    4200:	b94006e1 	ldr	w1, [x23, #4]
    4204:	f90023f9 	str	x25, [sp, #64]
    4208:	2a0103e2 	mov	w2, w1
    420c:	394006f9 	ldrb	w25, [x23, #1]
    4210:	39400af4 	ldrb	w20, [x23, #2]
    4214:	b4000158 	cbz	x24, 423c <fwp_mem_free+0xbc>
    4218:	92403e76 	and	x22, x19, #0xffff
    421c:	9ac20ad6 	udiv	x22, x22, x2
    4220:	38766b01 	ldrb	w1, [x24, x22]
    4224:	8b160300 	add	x0, x24, x22
    4228:	7103fc3f 	cmp	w1, #0xff
    422c:	54000980 	b.eq	435c <fwp_mem_free+0x1dc>  // b.none
    4230:	38366b1f 	strb	wzr, [x24, x22]
    4234:	b94006e1 	ldr	w1, [x23, #4]
    4238:	2a0103e2 	mov	w2, w1
    423c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4240:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4244:	cb390000 	sub	x0, x0, w25, uxtb
    4248:	8b340074 	add	x20, x3, w20, uxtb
    424c:	911502b5 	add	x21, x21, #0x540
    4250:	1e630021 	ucvtf	d1, w1
    4254:	d37ae400 	lsl	x0, x0, #6
    4258:	8b140c14 	add	x20, x0, x20, lsl #3
    425c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4260:	f8746aa0 	ldr	x0, [x21, x20]
    4264:	f94023f9 	ldr	x25, [sp, #64]
    4268:	aa2003e0 	mvn	x0, x0
    426c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4270:	f9000260 	str	x0, [x19]
    4274:	f8346ab3 	str	x19, [x21, x20]
    4278:	f94a12a0 	ldr	x0, [x21, #5152]
    427c:	1e612800 	fadd	d0, d0, d1
    4280:	a94153f3 	ldp	x19, x20, [sp, #16]
    4284:	cb020000 	sub	x0, x0, x2
    4288:	f90a12a0 	str	x0, [x21, #5152]
    428c:	fd0a22a0 	str	d0, [x21, #5184]
    4290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4294:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4298:	d65f03c0 	ret
    429c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    42a0:	8b000063 	add	x3, x3, x0
    42a4:	eb03027f 	cmp	x19, x3
    42a8:	54fff9e1 	b.ne	41e4 <fwp_mem_free+0x64>  // b.any
    42ac:	fd400ae1 	ldr	d1, [x23, #16]
    42b0:	fd4a2020 	ldr	d0, [x1, #5184]
    42b4:	f9400ae0 	ldr	x0, [x23, #16]
    42b8:	7e61d821 	ucvtf	d1, d1
    42bc:	f94a1022 	ldr	x2, [x1, #5152]
    42c0:	f94012f3 	ldr	x19, [x23, #32]
    42c4:	1e612800 	fadd	d0, d0, d1
    42c8:	cb000042 	sub	x2, x2, x0
    42cc:	f90a1022 	str	x2, [x1, #5152]
    42d0:	fd0a2020 	str	d0, [x1, #5184]
    42d4:	b40000b3 	cbz	x19, 42e8 <fwp_mem_free+0x168>
    42d8:	39400260 	ldrb	w0, [x19]
    42dc:	7103fc1f 	cmp	w0, #0xff
    42e0:	54000380 	b.eq	4350 <fwp_mem_free+0x1d0>  // b.none
    42e4:	3900027f 	strb	wzr, [x19]
    42e8:	b9400ee2 	ldr	w2, [x23, #12]
    42ec:	b4000142 	cbz	x2, 4314 <fwp_mem_free+0x194>
    42f0:	911502a1 	add	x1, x21, #0x540
    42f4:	8b160040 	add	x0, x2, x22
    42f8:	8b000800 	add	x0, x0, x0, lsl #2
    42fc:	f949fc21 	ldr	x1, [x1, #5112]
    4300:	8b140034 	add	x20, x1, x20
    4304:	8b000c20 	add	x0, x1, x0, lsl #3
    4308:	3802869f 	strb	wzr, [x20], #40
    430c:	eb00029f 	cmp	x20, x0
    4310:	54ffffc1 	b.ne	4308 <fwp_mem_free+0x188>  // b.any
    4314:	911502a0 	add	x0, x21, #0x540
    4318:	f94a1801 	ldr	x1, [x0, #5168]
    431c:	f949f803 	ldr	x3, [x0, #5104]
    4320:	8b020021 	add	x1, x1, x2
    4324:	f90a1801 	str	x1, [x0, #5168]
    4328:	eb16007f 	cmp	x3, x22
    432c:	54000049 	b.ls	4334 <fwp_mem_free+0x1b4>  // b.plast
    4330:	f909f816 	str	x22, [x0, #5104]
    4334:	911502b5 	add	x21, x21, #0x540
    4338:	f949f6a0 	ldr	x0, [x21, #5096]
    433c:	eb16001f 	cmp	x0, x22
    4340:	54fff529 	b.ls	41e4 <fwp_mem_free+0x64>  // b.plast
    4344:	a94363f7 	ldp	x23, x24, [sp, #48]
    4348:	f909f6b6 	str	x22, [x21, #5096]
    434c:	17ffffa7 	b	41e8 <fwp_mem_free+0x68>
    4350:	aa1303e0 	mov	x0, x19
    4354:	97fffeef 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4358:	17ffffe3 	b	42e4 <fwp_mem_free+0x164>
    435c:	97fffeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4360:	17ffffb4 	b	4230 <fwp_mem_free+0xb0>

0000000000004364 <fwp_rc_wide_dup>:
    4364:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4368:	910003fd 	mov	x29, sp
    436c:	a90153f3 	stp	x19, x20, [sp, #16]
    4370:	aa0003f3 	mov	x19, x0
    4374:	ca404400 	eor	x0, x0, x0, lsr #17
    4378:	f90013f5 	str	x21, [sp, #32]
    437c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4380:	ca402400 	eor	x0, x0, x0, lsr #9
    4384:	911502a2 	add	x2, x21, #0x540
    4388:	92401c00 	and	x0, x0, #0xff
    438c:	910a2403 	add	x3, x0, #0x289
    4390:	8b000c40 	add	x0, x2, x0, lsl #3
    4394:	8b030c54 	add	x20, x2, x3, lsl #3
    4398:	f94a2401 	ldr	x1, [x0, #5192]
    439c:	b50000a1 	cbnz	x1, 43b0 <fwp_rc_wide_dup+0x4c>
    43a0:	14000033 	b	446c <fwp_rc_wide_dup+0x108>
    43a4:	91004034 	add	x20, x1, #0x10
    43a8:	f9400821 	ldr	x1, [x1, #16]
    43ac:	b4000241 	cbz	x1, 43f4 <fwp_rc_wide_dup+0x90>
    43b0:	f9400022 	ldr	x2, [x1]
    43b4:	eb02027f 	cmp	x19, x2
    43b8:	54ffff61 	b.ne	43a4 <fwp_rc_wide_dup+0x40>  // b.any
    43bc:	f9400281 	ldr	x1, [x20]
    43c0:	39400260 	ldrb	w0, [x19]
    43c4:	7103f81f 	cmp	w0, #0xfe
    43c8:	54000220 	b.eq	440c <fwp_rc_wide_dup+0xa8>  // b.none
    43cc:	b40001a1 	cbz	x1, 4400 <fwp_rc_wide_dup+0x9c>
    43d0:	f9400420 	ldr	x0, [x1, #8]
    43d4:	b100041f 	cmn	x0, #0x1
    43d8:	54000440 	b.eq	4460 <fwp_rc_wide_dup+0xfc>  // b.none
    43dc:	91000400 	add	x0, x0, #0x1
    43e0:	f9000420 	str	x0, [x1, #8]
    43e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e8:	f94013f5 	ldr	x21, [sp, #32]
    43ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f0:	d65f03c0 	ret
    43f4:	39400260 	ldrb	w0, [x19]
    43f8:	7103f81f 	cmp	w0, #0xfe
    43fc:	54000100 	b.eq	441c <fwp_rc_wide_dup+0xb8>  // b.none
    4400:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4404:	91344000 	add	x0, x0, #0xd10
    4408:	97fffea2 	bl	3e90 <fwp_trap>
    440c:	b4000081 	cbz	x1, 441c <fwp_rc_wide_dup+0xb8>
    4410:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4414:	9134e000 	add	x0, x0, #0xd38
    4418:	97fffe9e 	bl	3e90 <fwp_trap>
    441c:	d2800300 	mov	x0, #0x18                  	// #24
    4420:	97fff900 	bl	2820 <malloc@plt>
    4424:	b4000280 	cbz	x0, 4474 <fwp_rc_wide_dup+0x110>
    4428:	d2801fe1 	mov	x1, #0xff                  	// #255
    442c:	a9000413 	stp	x19, x1, [x0]
    4430:	911502b5 	add	x21, x21, #0x540
    4434:	f900081f 	str	xzr, [x0, #16]
    4438:	12800001 	mov	w1, #0xffffffff            	// #-1
    443c:	f9000280 	str	x0, [x20]
    4440:	39000261 	strb	w1, [x19]
    4444:	f94e26a0 	ldr	x0, [x21, #7240]
    4448:	a94153f3 	ldp	x19, x20, [sp, #16]
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f90e26a0 	str	x0, [x21, #7240]
    4454:	f94013f5 	ldr	x21, [sp, #32]
    4458:	a8c37bfd 	ldp	x29, x30, [sp], #48
    445c:	d65f03c0 	ret
    4460:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4464:	91358000 	add	x0, x0, #0xd60
    4468:	97fffe8a 	bl	3e90 <fwp_trap>
    446c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4470:	17ffffd4 	b	43c0 <fwp_rc_wide_dup+0x5c>
    4474:	97fffaef 	bl	3030 <fwp_heap_oom>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_closure_drop_push>:
    4480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4484:	910003fd 	mov	x29, sp
    4488:	a90153f3 	stp	x19, x20, [sp, #16]
    448c:	aa0003f3 	mov	x19, x0
    4490:	a9408014 	ldp	x20, x0, [x0, #8]
    4494:	a9025bf5 	stp	x21, x22, [sp, #32]
    4498:	aa0103f5 	mov	x21, x1
    449c:	a90363f7 	stp	x23, x24, [sp, #48]
    44a0:	eb00029f 	cmp	x20, x0
    44a4:	54000160 	b.eq	44d0 <fwp_closure_drop_push+0x50>  // b.none
    44a8:	f9400276 	ldr	x22, [x19]
    44ac:	d37df297 	lsl	x23, x20, #3
    44b0:	91000694 	add	x20, x20, #0x1
    44b4:	f9000674 	str	x20, [x19, #8]
    44b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44bc:	f8376ad5 	str	x21, [x22, x23]
    44c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44cc:	d65f03c0 	ret
    44d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    44d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    44d8:	eb00029f 	cmp	x20, x0
    44dc:	540003e8 	b.hi	4558 <fwp_closure_drop_push+0xd8>  // b.pmore
    44e0:	d37cee99 	lsl	x25, x20, #4
    44e4:	d37ffa9a 	lsl	x26, x20, #1
    44e8:	aa1903e0 	mov	x0, x25
    44ec:	97fff8cd 	bl	2820 <malloc@plt>
    44f0:	aa0003f6 	mov	x22, x0
    44f4:	b4000380 	cbz	x0, 4564 <fwp_closure_drop_push+0xe4>
    44f8:	aa1303f8 	mov	x24, x19
    44fc:	aa1903e3 	mov	x3, x25
    4500:	d37df297 	lsl	x23, x20, #3
    4504:	aa1703e2 	mov	x2, x23
    4508:	f8418719 	ldr	x25, [x24], #24
    450c:	aa1903e1 	mov	x1, x25
    4510:	97fff8b0 	bl	27d0 <__memcpy_chk@plt>
    4514:	eb18033f 	cmp	x25, x24
    4518:	540000a0 	b.eq	452c <fwp_closure_drop_push+0xac>  // b.none
    451c:	aa1903e0 	mov	x0, x25
    4520:	97fff908 	bl	2940 <free@plt>
    4524:	f9400674 	ldr	x20, [x19, #8]
    4528:	d37df297 	lsl	x23, x20, #3
    452c:	91000694 	add	x20, x20, #0x1
    4530:	f9000276 	str	x22, [x19]
    4534:	f9000a7a 	str	x26, [x19, #16]
    4538:	a9446bf9 	ldp	x25, x26, [sp, #64]
    453c:	f9000674 	str	x20, [x19, #8]
    4540:	f8376ad5 	str	x21, [x22, x23]
    4544:	a94153f3 	ldp	x19, x20, [sp, #16]
    4548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    454c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4550:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4554:	d65f03c0 	ret
    4558:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    455c:	91360000 	add	x0, x0, #0xd80
    4560:	97fffe4c 	bl	3e90 <fwp_trap>
    4564:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4568:	f947e863 	ldr	x3, [x3, #4048]
    456c:	d2800262 	mov	x2, #0x13                  	// #19
    4570:	d2800021 	mov	x1, #0x1                   	// #1
    4574:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4578:	912f6000 	add	x0, x0, #0xbd8
    457c:	f9400063 	ldr	x3, [x3]
    4580:	97fff900 	bl	2980 <fwrite@plt>
    4584:	d2800000 	mov	x0, #0x0                   	// #0
    4588:	97fff90a 	bl	29b0 <fflush@plt>
    458c:	52800cc0 	mov	w0, #0x66                  	// #102
    4590:	97fff918 	bl	29f0 <_Exit@plt>

0000000000004594 <fwp_closure_drop.part.0>:
    4594:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4598:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    459c:	910003fd 	mov	x29, sp
    45a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    45a4:	f947f463 	ldr	x3, [x3, #4072]
    45a8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ac:	d10883ff 	sub	sp, sp, #0x220
    45b0:	910003e2 	mov	x2, sp
    45b4:	d53bd053 	mrs	x19, tpidr_el0
    45b8:	910063f4 	add	x20, sp, #0x18
    45bc:	3dc22820 	ldr	q0, [x1, #2208]
    45c0:	91400264 	add	x4, x19, #0x0, lsl #12
    45c4:	91004084 	add	x4, x4, #0x10
    45c8:	aa0003e1 	mov	x1, x0
    45cc:	aa0203e0 	mov	x0, x2
    45d0:	f9400062 	ldr	x2, [x3]
    45d4:	f9010fe2 	str	x2, [sp, #536]
    45d8:	d2800002 	mov	x2, #0x0                   	// #0
    45dc:	f90003f4 	str	x20, [sp]
    45e0:	f9000080 	str	x0, [x4]
    45e4:	3c8083e0 	stur	q0, [sp, #8]
    45e8:	97ffffa6 	bl	4480 <fwp_closure_drop_push>
    45ec:	f94007e0 	ldr	x0, [sp, #8]
    45f0:	b40002e0 	cbz	x0, 464c <fwp_closure_drop.part.0+0xb8>
    45f4:	f90123f5 	str	x21, [sp, #576]
    45f8:	900000f5 	adrp	x21, 20000 <__data_start>
    45fc:	9100c2b5 	add	x21, x21, #0x30
    4600:	14000006 	b	4618 <fwp_closure_drop.part.0+0x84>
    4604:	f9400422 	ldr	x2, [x1, #8]
    4608:	52800001 	mov	w1, #0x0                   	// #0
    460c:	d63f0040 	blr	x2
    4610:	f94007e0 	ldr	x0, [sp, #8]
    4614:	b40001a0 	cbz	x0, 4648 <fwp_closure_drop.part.0+0xb4>
    4618:	f94003e1 	ldr	x1, [sp]
    461c:	d1000400 	sub	x0, x0, #0x1
    4620:	f90007e0 	str	x0, [sp, #8]
    4624:	f9403ea2 	ldr	x2, [x21, #120]
    4628:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    462c:	b9400001 	ldr	w1, [x0]
    4630:	8b011441 	add	x1, x2, x1, lsl #5
    4634:	f9400c21 	ldr	x1, [x1, #24]
    4638:	b5fffe61 	cbnz	x1, 4604 <fwp_closure_drop.part.0+0x70>
    463c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4640:	91368000 	add	x0, x0, #0xda0
    4644:	97fffe13 	bl	3e90 <fwp_trap>
    4648:	f94123f5 	ldr	x21, [sp, #576]
    464c:	91400273 	add	x19, x19, #0x0, lsl #12
    4650:	91004273 	add	x19, x19, #0x10
    4654:	f94003e0 	ldr	x0, [sp]
    4658:	f900027f 	str	xzr, [x19]
    465c:	eb14001f 	cmp	x0, x20
    4660:	54000040 	b.eq	4668 <fwp_closure_drop.part.0+0xd4>  // b.none
    4664:	97fff8b7 	bl	2940 <free@plt>
    4668:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    466c:	f947f400 	ldr	x0, [x0, #4072]
    4670:	f9410fe2 	ldr	x2, [sp, #536]
    4674:	f9400001 	ldr	x1, [x0]
    4678:	eb010042 	subs	x2, x2, x1
    467c:	d2800001 	mov	x1, #0x0                   	// #0
    4680:	540000a1 	b.ne	4694 <fwp_closure_drop.part.0+0x100>  // b.any
    4684:	910883ff 	add	sp, sp, #0x220
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4690:	d65f03c0 	ret
    4694:	f90123f5 	str	x21, [sp, #576]
    4698:	97fff87a 	bl	2880 <__stack_chk_fail@plt>
    469c:	d503201f 	nop

00000000000046a0 <fwp_tape_of>:
    46a0:	aa0003e1 	mov	x1, x0
    46a4:	92403c00 	and	x0, x0, #0xffff
    46a8:	b40000e0 	cbz	x0, 46c4 <fwp_tape_of+0x24>
    46ac:	d1000402 	sub	x2, x0, #0x1
    46b0:	900000e3 	adrp	x3, 20000 <__data_start>
    46b4:	9100c060 	add	x0, x3, #0x30
    46b8:	f9404000 	ldr	x0, [x0, #128]
    46bc:	eb02001f 	cmp	x0, x2
    46c0:	540000cc 	b.gt	46d8 <fwp_tape_of+0x38>
    46c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    46c8:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    46cc:	91374000 	add	x0, x0, #0xdd0
    46d0:	910003fd 	mov	x29, sp
    46d4:	97fffdef 	bl	3e90 <fwp_trap>
    46d8:	8b020440 	add	x0, x2, x2, lsl #1
    46dc:	f9401863 	ldr	x3, [x3, #48]
    46e0:	8b000842 	add	x2, x2, x0, lsl #2
    46e4:	d37df042 	lsl	x2, x2, #3
    46e8:	8b020060 	add	x0, x3, x2
    46ec:	b9400404 	ldr	w4, [x0, #4]
    46f0:	34fffea4 	cbz	w4, 46c4 <fwp_tape_of+0x24>
    46f4:	b8626862 	ldr	w2, [x3, x2]
    46f8:	9350fc21 	asr	x1, x1, #16
    46fc:	6b01005f 	cmp	w2, w1
    4700:	54fffe21 	b.ne	46c4 <fwp_tape_of+0x24>  // b.any
    4704:	d65f03c0 	ret
    4708:	d503201f 	nop
    470c:	d503201f 	nop

0000000000004710 <fwp_now_ns>:
    4710:	d100c3ff 	sub	sp, sp, #0x30
    4714:	52800020 	mov	w0, #0x1                   	// #1
    4718:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    471c:	f947f442 	ldr	x2, [x2, #4072]
    4720:	910023e1 	add	x1, sp, #0x8
    4724:	a9027bfd 	stp	x29, x30, [sp, #32]
    4728:	910083fd 	add	x29, sp, #0x20
    472c:	f9400043 	ldr	x3, [x2]
    4730:	f9000fe3 	str	x3, [sp, #24]
    4734:	d2800003 	mov	x3, #0x0                   	// #0
    4738:	97fff81e 	bl	27b0 <clock_gettime@plt>
    473c:	350002c0 	cbnz	w0, 4794 <fwp_now_ns+0x84>
    4740:	a9408be1 	ldp	x1, x2, [sp, #8]
    4744:	d2994003 	mov	x3, #0xca00                	// #51712
    4748:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    474c:	9b037c20 	mul	x0, x1, x3
    4750:	9b437c21 	smulh	x1, x1, x3
    4754:	ab020000 	adds	x0, x0, x2
    4758:	937ffc42 	asr	x2, x2, #63
    475c:	9a020021 	adc	x1, x1, x2
    4760:	f100001f 	cmp	x0, #0x0
    4764:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4768:	b50001c1 	cbnz	x1, 47a0 <fwp_now_ns+0x90>
    476c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4770:	f947f421 	ldr	x1, [x1, #4072]
    4774:	f9400fe3 	ldr	x3, [sp, #24]
    4778:	f9400022 	ldr	x2, [x1]
    477c:	eb020063 	subs	x3, x3, x2
    4780:	d2800002 	mov	x2, #0x0                   	// #0
    4784:	54000141 	b.ne	47ac <fwp_now_ns+0x9c>  // b.any
    4788:	a9427bfd 	ldp	x29, x30, [sp, #32]
    478c:	9100c3ff 	add	sp, sp, #0x30
    4790:	d65f03c0 	ret
    4794:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    4798:	91388000 	add	x0, x0, #0xe20
    479c:	97fffdbd 	bl	3e90 <fwp_trap>
    47a0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    47a4:	91390000 	add	x0, x0, #0xe40
    47a8:	97fffdba 	bl	3e90 <fwp_trap>
    47ac:	97fff835 	bl	2880 <__stack_chk_fail@plt>

00000000000047b0 <fwp_poll_events>:
    47b0:	d10103ff 	sub	sp, sp, #0x40
    47b4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    47b8:	f947f400 	ldr	x0, [x0, #4072]
    47bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    47c0:	910083fd 	add	x29, sp, #0x20
    47c4:	f9001bf3 	str	x19, [sp, #48]
    47c8:	900000f3 	adrp	x19, 20000 <__data_start>
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	f9000fe1 	str	x1, [sp, #24]
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	97ffffce 	bl	4710 <fwp_now_ns>
    47dc:	9100c261 	add	x1, x19, #0x30
    47e0:	f9404421 	ldr	x1, [x1, #136]
    47e4:	b4000e01 	cbz	x1, 49a4 <fwp_poll_events+0x1f4>
    47e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    47ec:	14000005 	b	4800 <fwp_poll_events+0x50>
    47f0:	f9408821 	ldr	x1, [x1, #272]
    47f4:	eb03005f 	cmp	x2, x3
    47f8:	9a83d042 	csel	x2, x2, x3, le
    47fc:	b40000c1 	cbz	x1, 4814 <fwp_poll_events+0x64>
    4800:	f9403423 	ldr	x3, [x1, #104]
    4804:	b6ffff62 	tbz	x2, #63, 47f0 <fwp_poll_events+0x40>
    4808:	f9408821 	ldr	x1, [x1, #272]
    480c:	aa0303e2 	mov	x2, x3
    4810:	b5ffff81 	cbnz	x1, 4800 <fwp_poll_events+0x50>
    4814:	b7f80c82 	tbnz	x2, #63, 49a4 <fwp_poll_events+0x1f4>
    4818:	cb000042 	sub	x2, x2, x0
    481c:	f100005f 	cmp	x2, #0x0
    4820:	540003ad 	b.le	4894 <fwp_poll_events+0xe4>
    4824:	d2869b60 	mov	x0, #0x34db                	// #13531
    4828:	d2884804 	mov	x4, #0x4240                	// #16960
    482c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4830:	f2a001e4 	movk	x4, #0xf, lsl #16
    4834:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4838:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    483c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4840:	9b407c40 	smulh	x0, x2, x0
    4844:	9352fc00 	asr	x0, x0, #18
    4848:	cb82fc00 	sub	x0, x0, x2, asr #63
    484c:	9b048802 	msub	x2, x0, x4, x2
    4850:	f100005f 	cmp	x2, #0x0
    4854:	9a800400 	cinc	x0, x0, ne	// ne = any
    4858:	eb01001f 	cmp	x0, x1
    485c:	5400098c 	b.gt	498c <fwp_poll_events+0x1dc>
    4860:	340001a0 	cbz	w0, 4894 <fwp_poll_events+0xe4>
    4864:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4868:	52807d05 	mov	w5, #0x3e8                 	// #1000
    486c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4870:	9ba17c01 	umull	x1, w0, w1
    4874:	d366fc23 	lsr	x3, x1, #38
    4878:	aa0303e2 	mov	x2, x3
    487c:	1b058063 	msub	w3, w3, w5, w0
    4880:	9b247c63 	smull	x3, w3, w4
    4884:	910023e0 	add	x0, sp, #0x8
    4888:	d2800001 	mov	x1, #0x0                   	// #0
    488c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4890:	97fff830 	bl	2950 <nanosleep@plt>
    4894:	97ffff9f 	bl	4710 <fwp_now_ns>
    4898:	9100c268 	add	x8, x19, #0x30
    489c:	aa0003e7 	mov	x7, x0
    48a0:	4f000400 	movi	v0.4s, #0x0
    48a4:	52800029 	mov	w9, #0x1                   	// #1
    48a8:	f9404506 	ldr	x6, [x8, #136]
    48ac:	d503201f 	nop
    48b0:	b40003e6 	cbz	x6, 492c <fwp_poll_events+0x17c>
    48b4:	f94034c1 	ldr	x1, [x6, #104]
    48b8:	aa0603e5 	mov	x5, x6
    48bc:	f94088c6 	ldr	x6, [x6, #272]
    48c0:	eb07003f 	cmp	x1, x7
    48c4:	54ffff6c 	b.gt	48b0 <fwp_poll_events+0x100>
    48c8:	394154a0 	ldrb	w0, [x5, #85]
    48cc:	36000120 	tbz	w0, #0, 48f0 <fwp_poll_events+0x140>
    48d0:	f94084a0 	ldr	x0, [x5, #264]
    48d4:	b4000560 	cbz	x0, 4980 <fwp_poll_events+0x1d0>
    48d8:	f9008806 	str	x6, [x0, #272]
    48dc:	b4000046 	cbz	x6, 48e4 <fwp_poll_events+0x134>
    48e0:	f90084c0 	str	x0, [x6, #264]
    48e4:	910800a0 	add	x0, x5, #0x200
    48e8:	390154bf 	strb	wzr, [x5, #85]
    48ec:	3c908000 	stur	q0, [x0, #-248]
    48f0:	f94030a0 	ldr	x0, [x5, #96]
    48f4:	390158a9 	strb	w9, [x5, #86]
    48f8:	f100001f 	cmp	x0, #0x0
    48fc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4900:	540002cd 	b.le	4958 <fwp_poll_events+0x1a8>
    4904:	f94028a0 	ldr	x0, [x5, #80]
    4908:	f2001c1f 	tst	x0, #0xff000000ff
    490c:	54fffd21 	b.ne	48b0 <fwp_poll_events+0x100>  // b.any
    4910:	f9401500 	ldr	x0, [x8, #40]
    4914:	390150a9 	strb	w9, [x5, #84]
    4918:	f90080bf 	str	xzr, [x5, #256]
    491c:	b40002c0 	cbz	x0, 4974 <fwp_poll_events+0x1c4>
    4920:	f9001505 	str	x5, [x8, #40]
    4924:	f9008005 	str	x5, [x0, #256]
    4928:	b5fffc66 	cbnz	x6, 48b4 <fwp_poll_events+0x104>
    492c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4930:	f947f400 	ldr	x0, [x0, #4072]
    4934:	f9400fe2 	ldr	x2, [sp, #24]
    4938:	f9400001 	ldr	x1, [x0]
    493c:	eb010042 	subs	x2, x2, x1
    4940:	d2800001 	mov	x1, #0x0                   	// #0
    4944:	540002e1 	b.ne	49a0 <fwp_poll_events+0x1f0>  // b.any
    4948:	a9427bfd 	ldp	x29, x30, [sp, #32]
    494c:	f9401bf3 	ldr	x19, [sp, #48]
    4950:	910103ff 	add	sp, sp, #0x40
    4954:	d65f03c0 	ret
    4958:	394144a0 	ldrb	w0, [x5, #81]
    495c:	3707fd40 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4960:	394140a0 	ldrb	w0, [x5, #80]
    4964:	3707fd00 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4968:	aa0503e0 	mov	x0, x5
    496c:	97fffac1 	bl	3470 <fwp_cancel_tree.part.0>
    4970:	17ffffe5 	b	4904 <fwp_poll_events+0x154>
    4974:	f9001505 	str	x5, [x8, #40]
    4978:	f9001905 	str	x5, [x8, #48]
    497c:	17ffffeb 	b	4928 <fwp_poll_events+0x178>
    4980:	9100c261 	add	x1, x19, #0x30
    4984:	f9004426 	str	x6, [x1, #136]
    4988:	17ffffd5 	b	48dc <fwp_poll_events+0x12c>
    498c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4990:	d2989362 	mov	x2, #0xc49b                	// #50331
    4994:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4998:	f2a00402 	movk	x2, #0x20, lsl #16
    499c:	17ffffba 	b	4884 <fwp_poll_events+0xd4>
    49a0:	97fff7b8 	bl	2880 <__stack_chk_fail@plt>
    49a4:	97fff993 	bl	2ff0 <fwp_flush>
    49a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    49ac:	f947e863 	ldr	x3, [x3, #4048]
    49b0:	d2800562 	mov	x2, #0x2b                  	// #43
    49b4:	d2800021 	mov	x1, #0x1                   	// #1
    49b8:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    49bc:	9139a000 	add	x0, x0, #0xe68
    49c0:	f9400063 	ldr	x3, [x3]
    49c4:	97fff7ef 	bl	2980 <fwrite@plt>
    49c8:	52800ca0 	mov	w0, #0x65                  	// #101
    49cc:	97fff759 	bl	2730 <exit@plt>

00000000000049d0 <fwp_heap_alloc_big>:
    49d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d4:	910003fd 	mov	x29, sp
    49d8:	a90153f3 	stp	x19, x20, [sp, #16]
    49dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e0:	a90363f7 	stp	x23, x24, [sp, #48]
    49e4:	aa0003f7 	mov	x23, x0
    49e8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f0:	eb0002ff 	cmp	x23, x0
    49f4:	540008a8 	b.hi	4b08 <fwp_heap_alloc_big+0x138>  // b.pmore
    49f8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49fc:	8b0002f4 	add	x20, x23, x0
    4a00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a04:	91150359 	add	x25, x26, #0x540
    4a08:	d350fe94 	lsr	x20, x20, #16
    4a0c:	2a0103f5 	mov	w21, w1
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	97fff9c7 	bl	3130 <fwp_heap_chunks>
    4a18:	f949ff22 	ldr	x2, [x25, #5112]
    4a1c:	8b000813 	add	x19, x0, x0, lsl #2
    4a20:	aa0003f8 	mov	x24, x0
    4a24:	52800043 	mov	w3, #0x2                   	// #2
    4a28:	d37df273 	lsl	x19, x19, #3
    4a2c:	d2800021 	mov	x1, #0x1                   	// #1
    4a30:	8b130040 	add	x0, x2, x19
    4a34:	38336843 	strb	w3, [x2, x19]
    4a38:	39000415 	strb	w21, [x0, #1]
    4a3c:	b9000c14 	str	w20, [x0, #12]
    4a40:	f9000817 	str	x23, [x0, #16]
    4a44:	97fffd57 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a48:	f100069f 	cmp	x20, #0x1
    4a4c:	54000289 	b.ls	4a9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4a50:	8b180294 	add	x20, x20, x24
    4a54:	9100a273 	add	x19, x19, #0x28
    4a58:	a90573fb 	stp	x27, x28, [sp, #80]
    4a5c:	5280007b 	mov	w27, #0x3                   	// #3
    4a60:	8b140a94 	add	x20, x20, x20, lsl #2
    4a64:	2a1803fc 	mov	w28, w24
    4a68:	9adb2296 	lsl	x22, x20, x27
    4a6c:	d503201f 	nop
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffd48 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0xa0>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffbbf 	bl	3af0 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff6f 	b	49d0 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffd19 	bl	40c0 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_tape_grow.constprop.0>:
    4ea4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ea8:	d2800803 	mov	x3, #0x40                  	// #64
    4eac:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4eb0:	910003fd 	mov	x29, sp
    4eb4:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb8:	f9400c13 	ldr	x19, [x0, #24]
    4ebc:	a90363f7 	stp	x23, x24, [sp, #48]
    4ec0:	aa0003f7 	mov	x23, x0
    4ec4:	f100027f 	cmp	x19, #0x0
    4ec8:	9a831273 	csel	x19, x19, x3, ne	// ne = any
    4ecc:	eb13003f 	cmp	x1, x19
    4ed0:	540000ed 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ed4:	eb02027f 	cmp	x19, x2
    4ed8:	5400076d 	b.le	4fc4 <fwp_tape_grow.constprop.0+0x120>
    4edc:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4ee0:	eb13003f 	cmp	x1, x19
    4ee4:	5400004d 	b.le	4eec <fwp_tape_grow.constprop.0+0x48>
    4ee8:	14000000 	b	4ee8 <fwp_tape_grow.constprop.0+0x44>
    4eec:	a940d2e2 	ldp	x2, x20, [x23, #8]
    4ef0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ef4:	d37df276 	lsl	x22, x19, #3
    4ef8:	f94012e0 	ldr	x0, [x23, #32]
    4efc:	aa1603e1 	mov	x1, x22
    4f00:	f94032f5 	ldr	x21, [x23, #96]
    4f04:	cb020294 	sub	x20, x20, x2
    4f08:	97fff65a 	bl	2870 <realloc@plt>
    4f0c:	b4000c20 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    4f10:	f9400ee1 	ldr	x1, [x23, #24]
    4f14:	8b010801 	add	x1, x0, x1, lsl #2
    4f18:	a90206e0 	stp	x0, x1, [x23, #32]
    4f1c:	b4000895 	cbz	x21, 502c <fwp_tape_grow.constprop.0+0x188>
    4f20:	f94032b6 	ldr	x22, [x21, #96]
    4f24:	eb1302df 	cmp	x22, x19
    4f28:	540003aa 	b.ge	4f9c <fwp_tape_grow.constprop.0+0xf8>  // b.tcont
    4f2c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f30:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4f34:	eb00027f 	cmp	x19, x0
    4f38:	54000a68 	b.hi	5084 <fwp_tape_grow.constprop.0+0x1e0>  // b.pmore
    4f3c:	f94022b9 	ldr	x25, [x21, #64]
    4f40:	d37cee7a 	lsl	x26, x19, #4
    4f44:	aa1a03e0 	mov	x0, x26
    4f48:	52800041 	mov	w1, #0x2                   	// #2
    4f4c:	97ffff49 	bl	4c70 <fwp_heap_alloc>
    4f50:	aa0003f8 	mov	x24, x0
    4f54:	b4000119 	cbz	x25, 4f74 <fwp_tape_grow.constprop.0+0xd0>
    4f58:	d37ceed6 	lsl	x22, x22, #4
    4f5c:	aa1903e1 	mov	x1, x25
    4f60:	eb1a02df 	cmp	x22, x26
    4f64:	9a9a92c2 	csel	x2, x22, x26, ls	// ls = plast
    4f68:	97fff5da 	bl	26d0 <memcpy@plt>
    4f6c:	aa1903e0 	mov	x0, x25
    4f70:	97fffc84 	bl	4180 <fwp_mem_free>
    4f74:	f94032a0 	ldr	x0, [x21, #96]
    4f78:	52800001 	mov	w1, #0x0                   	// #0
    4f7c:	cb000262 	sub	x2, x19, x0
    4f80:	8b001300 	add	x0, x24, x0, lsl #4
    4f84:	d37cec42 	lsl	x2, x2, #4
    4f88:	97fff632 	bl	2850 <memset@plt>
    4f8c:	f94012e0 	ldr	x0, [x23, #32]
    4f90:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f94:	f90022b8 	str	x24, [x21, #64]
    4f98:	f90032b3 	str	x19, [x21, #96]
    4f9c:	d37ef675 	lsl	x21, x19, #2
    4fa0:	b50002b4 	cbnz	x20, 4ff4 <fwp_tape_grow.constprop.0+0x150>
    4fa4:	8b150001 	add	x1, x0, x21
    4fa8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fac:	f9000ef3 	str	x19, [x23, #24]
    4fb0:	f90016e1 	str	x1, [x23, #40]
    4fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fbc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4fc0:	d65f03c0 	ret
    4fc4:	d37ffa73 	lsl	x19, x19, #1
    4fc8:	17ffffc1 	b	4ecc <fwp_tape_grow.constprop.0+0x28>
    4fcc:	eb1502df 	cmp	x22, x21
    4fd0:	aa0403e0 	mov	x0, x4
    4fd4:	9a9522c3 	csel	x3, x22, x21, cs	// cs = hs, nlast
    4fd8:	d37df282 	lsl	x2, x20, #3
    4fdc:	cb160063 	sub	x3, x3, x22
    4fe0:	97fff690 	bl	2a20 <__memmove_chk@plt>
    4fe4:	f9401ae1 	ldr	x1, [x23, #48]
    4fe8:	f94012e0 	ldr	x0, [x23, #32]
    4fec:	8b160021 	add	x1, x1, x22
    4ff0:	f9001ee1 	str	x1, [x23, #56]
    4ff4:	f94016e1 	ldr	x1, [x23, #40]
    4ff8:	d37ef675 	lsl	x21, x19, #2
    4ffc:	d37ef682 	lsl	x2, x20, #2
    5000:	8b150000 	add	x0, x0, x21
    5004:	97fff5bb 	bl	26f0 <memmove@plt>
    5008:	f94012e0 	ldr	x0, [x23, #32]
    500c:	8b150001 	add	x1, x0, x21
    5010:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5014:	f9000ef3 	str	x19, [x23, #24]
    5018:	f90016e1 	str	x1, [x23, #40]
    501c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5028:	d65f03c0 	ret
    502c:	f9401ae0 	ldr	x0, [x23, #48]
    5030:	d37cee75 	lsl	x21, x19, #4
    5034:	aa1503e1 	mov	x1, x21
    5038:	97fff60e 	bl	2870 <realloc@plt>
    503c:	b40002a0 	cbz	x0, 5090 <fwp_tape_grow.constprop.0+0x1ec>
    5040:	f9400ee2 	ldr	x2, [x23, #24]
    5044:	f9001ae0 	str	x0, [x23, #48]
    5048:	8b160004 	add	x4, x0, x22
    504c:	8b020c01 	add	x1, x0, x2, lsl #3
    5050:	f9001ee1 	str	x1, [x23, #56]
    5054:	b5fffbd4 	cbnz	x20, 4fcc <fwp_tape_grow.constprop.0+0x128>
    5058:	f94012e0 	ldr	x0, [x23, #32]
    505c:	d37ef675 	lsl	x21, x19, #2
    5060:	f9001ee4 	str	x4, [x23, #56]
    5064:	8b150001 	add	x1, x0, x21
    5068:	a9425bf5 	ldp	x21, x22, [sp, #32]
    506c:	f9000ef3 	str	x19, [x23, #24]
    5070:	f90016e1 	str	x1, [x23, #40]
    5074:	a94153f3 	ldp	x19, x20, [sp, #16]
    5078:	a94363f7 	ldp	x23, x24, [sp, #48]
    507c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5080:	d65f03c0 	ret
    5084:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5088:	913b0000 	add	x0, x0, #0xec0
    508c:	97fffb81 	bl	3e90 <fwp_trap>
    5090:	aa1703e0 	mov	x0, x23
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	97fff7be 	bl	2f90 <fwp_tape_unlink_scope>
    509c:	f94012e0 	ldr	x0, [x23, #32]
    50a0:	97fff628 	bl	2940 <free@plt>
    50a4:	f9401ae0 	ldr	x0, [x23, #48]
    50a8:	97fff626 	bl	2940 <free@plt>
    50ac:	f94022e0 	ldr	x0, [x23, #64]
    50b0:	97fff624 	bl	2940 <free@plt>
    50b4:	f9000eff 	str	xzr, [x23, #24]
    50b8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    50bc:	f947e821 	ldr	x1, [x1, #4048]
    50c0:	a9047eff 	stp	xzr, xzr, [x23, #64]
    50c4:	d2800262 	mov	x2, #0x13                  	// #19
    50c8:	4f000400 	movi	v0.4s, #0x0
    50cc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    50d0:	f9400023 	ldr	x3, [x1]
    50d4:	b90006ff 	str	wzr, [x23, #4]
    50d8:	d2800021 	mov	x1, #0x1                   	// #1
    50dc:	912f6000 	add	x0, x0, #0xbd8
    50e0:	3c8082e0 	stur	q0, [x23, #8]
    50e4:	ad0102e0 	stp	q0, q0, [x23, #32]
    50e8:	97fff626 	bl	2980 <fwrite@plt>
    50ec:	d2800000 	mov	x0, #0x0                   	// #0
    50f0:	97fff630 	bl	29b0 <fflush@plt>
    50f4:	52800cc0 	mov	w0, #0x66                  	// #102
    50f8:	97fff63e 	bl	29f0 <_Exit@plt>
    50fc:	d503201f 	nop

0000000000005100 <f141.constprop.0>:
    5100:	f100001f 	cmp	x0, #0x0
    5104:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5108:	54000a2b 	b.lt	524c <f141.constprop.0+0x14c>  // b.tstop
    510c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5110:	aa0003e2 	mov	x2, x0
    5114:	910003fd 	mov	x29, sp
    5118:	a90153f3 	stp	x19, x20, [sp, #16]
    511c:	aa0003f4 	mov	x20, x0
    5120:	aa010000 	orr	x0, x0, x1
    5124:	a9025bf5 	stp	x21, x22, [sp, #32]
    5128:	aa0103f6 	mov	x22, x1
    512c:	f9001bf7 	str	x23, [sp, #48]
    5130:	fd001fe8 	str	d8, [sp, #56]
    5134:	b7f80180 	tbnz	x0, #63, 5164 <f141.constprop.0+0x64>
    5138:	9360fc20 	asr	x0, x1, #32
    513c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5140:	eb82801f 	cmp	x0, x2, asr #32
    5144:	54000881 	b.ne	5254 <f141.constprop.0+0x154>  // b.any
    5148:	97fffd56 	bl	46a0 <fwp_tape_of>
    514c:	aa0003f3 	mov	x19, x0
    5150:	f9403000 	ldr	x0, [x0, #96]
    5154:	b40001e0 	cbz	x0, 5190 <f141.constprop.0+0x90>
    5158:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    515c:	913ca000 	add	x0, x0, #0xf28
    5160:	97fffb4c 	bl	3e90 <fwp_trap>
    5164:	9360fc40 	asr	x0, x2, #32
    5168:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    516c:	b6fffee2 	tbz	x2, #63, 5148 <f141.constprop.0+0x48>
    5170:	2f00e408 	movi	d8, #0x0
    5174:	9360fc20 	asr	x0, x1, #32
    5178:	aa0103f4 	mov	x20, x1
    517c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5180:	97fffd48 	bl	46a0 <fwp_tape_of>
    5184:	aa0003f3 	mov	x19, x0
    5188:	f9403000 	ldr	x0, [x0, #96]
    518c:	b5fffe60 	cbnz	x0, 5158 <f141.constprop.0+0x58>
    5190:	f9400a77 	ldr	x23, [x19, #16]
    5194:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5198:	eb0002ff 	cmp	x23, x0
    519c:	5400046c 	b.gt	5228 <f141.constprop.0+0x128>
    51a0:	eb3442ff 	cmp	x23, w20, uxtw
    51a4:	540004ed 	b.le	5240 <f141.constprop.0+0x140>
    51a8:	b7f80076 	tbnz	x22, #63, 51b4 <f141.constprop.0+0xb4>
    51ac:	eb3642ff 	cmp	x23, w22, uxtw
    51b0:	5400048d 	b.le	5240 <f141.constprop.0+0x140>
    51b4:	f9400675 	ldr	x21, [x19, #8]
    51b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51bc:	cb1502f5 	sub	x21, x23, x21
    51c0:	910006a1 	add	x1, x21, #0x1
    51c4:	eb00003f 	cmp	x1, x0
    51c8:	54000308 	b.hi	5228 <f141.constprop.0+0x128>  // b.pmore
    51cc:	f9400e60 	ldr	x0, [x19, #24]
    51d0:	eb00003f 	cmp	x1, x0
    51d4:	5400030c 	b.gt	5234 <f141.constprop.0+0x134>
    51d8:	a9420262 	ldp	x2, x0, [x19, #32]
    51dc:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    51e0:	f9401a61 	ldr	x1, [x19, #48]
    51e4:	b8357854 	str	w20, [x2, x21, lsl #2]
    51e8:	f9401e62 	ldr	x2, [x19, #56]
    51ec:	f10002df 	cmp	x22, #0x0
    51f0:	fc357820 	str	d0, [x1, x21, lsl #3]
    51f4:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    51f8:	b8357816 	str	w22, [x0, x21, lsl #2]
    51fc:	92607e80 	and	x0, x20, #0xffffffff00000000
    5200:	910006e1 	add	x1, x23, #0x1
    5204:	aa170000 	orr	x0, x0, x23
    5208:	fc357848 	str	d8, [x2, x21, lsl #3]
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	f9401bf7 	ldr	x23, [sp, #48]
    5214:	fd401fe8 	ldr	d8, [sp, #56]
    5218:	f9000a61 	str	x1, [x19, #16]
    521c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5220:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5224:	d65f03c0 	ret
    5228:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    522c:	913b0000 	add	x0, x0, #0xec0
    5230:	97fffb18 	bl	3e90 <fwp_trap>
    5234:	aa1303e0 	mov	x0, x19
    5238:	97ffff1b 	bl	4ea4 <fwp_tape_grow.constprop.0>
    523c:	17ffffe7 	b	51d8 <f141.constprop.0+0xd8>
    5240:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5244:	913d6000 	add	x0, x0, #0xf58
    5248:	97fffb12 	bl	3e90 <fwp_trap>
    524c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5250:	d65f03c0 	ret
    5254:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5258:	913b8000 	add	x0, x0, #0xee0
    525c:	97fffb0d 	bl	3e90 <fwp_trap>

0000000000005260 <w120>:
    5260:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5264:	910003fd 	mov	x29, sp
    5268:	a90153f3 	stp	x19, x20, [sp, #16]
    526c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5270:	a90363f7 	stp	x23, x24, [sp, #48]
    5274:	aa0003f8 	mov	x24, x0
    5278:	a9046bf9 	stp	x25, x26, [sp, #64]
    527c:	aa0103f9 	mov	x25, x1
    5280:	6d0527e8 	stp	d8, d9, [sp, #80]
    5284:	1e604008 	fmov	d8, d0
    5288:	1e604029 	fmov	d9, d1
    528c:	6d062fea 	stp	d10, d11, [sp, #96]
    5290:	1e60080a 	fmul	d10, d0, d0
    5294:	b7f821a0 	tbnz	x0, #63, 56c8 <w120+0x468>
    5298:	9360fc17 	asr	x23, x0, #32
    529c:	aa1703e0 	mov	x0, x23
    52a0:	97fffd00 	bl	46a0 <fwp_tape_of>
    52a4:	f9403001 	ldr	x1, [x0, #96]
    52a8:	aa0003f3 	mov	x19, x0
    52ac:	b4000081 	cbz	x1, 52bc <w120+0x5c>
    52b0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    52b4:	913ca000 	add	x0, x0, #0xf28
    52b8:	97fffaf6 	bl	3e90 <fwp_trap>
    52bc:	f9400815 	ldr	x21, [x0, #16]
    52c0:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    52c4:	eb0102bf 	cmp	x21, x1
    52c8:	54001d8c 	b.gt	5678 <w120+0x418>
    52cc:	eb3842bf 	cmp	x21, w24, uxtw
    52d0:	54001ced 	b.le	566c <w120+0x40c>
    52d4:	f9400416 	ldr	x22, [x0, #8]
    52d8:	b2407be2 	mov	x2, #0x7fffffff            	// #2147483647
    52dc:	cb1602b6 	sub	x22, x21, x22
    52e0:	910006c1 	add	x1, x22, #0x1
    52e4:	eb02003f 	cmp	x1, x2
    52e8:	54001c88 	b.hi	5678 <w120+0x418>  // b.pmore
    52ec:	f9400c02 	ldr	x2, [x0, #24]
    52f0:	eb02003f 	cmp	x1, x2
    52f4:	54001c8c 	b.gt	5684 <w120+0x424>
    52f8:	a9420660 	ldp	x0, x1, [x19, #32]
    52fc:	92607f14 	and	x20, x24, #0xffffffff00000000
    5300:	f9401a62 	ldr	x2, [x19, #48]
    5304:	b8367818 	str	w24, [x0, x22, lsl #2]
    5308:	f9401e60 	ldr	x0, [x19, #56]
    530c:	aa150294 	orr	x20, x20, x21
    5310:	fc367848 	str	d8, [x2, x22, lsl #3]
    5314:	910006b5 	add	x21, x21, #0x1
    5318:	b8367838 	str	w24, [x1, x22, lsl #2]
    531c:	1e6a392a 	fsub	d10, d9, d10
    5320:	9360fe9a 	asr	x26, x20, #32
    5324:	fc367808 	str	d8, [x0, x22, lsl #3]
    5328:	f9000a75 	str	x21, [x19, #16]
    532c:	b7f80079 	tbnz	x25, #63, 5338 <w120+0xd8>
    5330:	eb99835f 	cmp	x26, x25, asr #32
    5334:	54001e21 	b.ne	56f8 <w120+0x498>  // b.any
    5338:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    533c:	1e7e100b 	fmov	d11, #-1.000000000000000000e+00
    5340:	eb1a02ff 	cmp	x23, x26
    5344:	540000c0 	b.eq	535c <w120+0xfc>  // b.none
    5348:	aa1a03e0 	mov	x0, x26
    534c:	97fffcd5 	bl	46a0 <fwp_tape_of>
    5350:	aa0003f3 	mov	x19, x0
    5354:	f9403000 	ldr	x0, [x0, #96]
    5358:	b5fffac0 	cbnz	x0, 52b0 <w120+0x50>
    535c:	f9400a77 	ldr	x23, [x19, #16]
    5360:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5364:	eb0002ff 	cmp	x23, x0
    5368:	5400188c 	b.gt	5678 <w120+0x418>
    536c:	eb3442ff 	cmp	x23, w20, uxtw
    5370:	540017ed 	b.le	566c <w120+0x40c>
    5374:	b7f80079 	tbnz	x25, #63, 5380 <w120+0x120>
    5378:	eb3942ff 	cmp	x23, w25, uxtw
    537c:	5400178d 	b.le	566c <w120+0x40c>
    5380:	f9400675 	ldr	x21, [x19, #8]
    5384:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5388:	cb1502f5 	sub	x21, x23, x21
    538c:	910006a1 	add	x1, x21, #0x1
    5390:	eb00003f 	cmp	x1, x0
    5394:	54001728 	b.hi	5678 <w120+0x418>  // b.pmore
    5398:	f9400e60 	ldr	x0, [x19, #24]
    539c:	eb00003f 	cmp	x1, x0
    53a0:	540018ec 	b.gt	56bc <w120+0x45c>
    53a4:	a9420e62 	ldp	x2, x3, [x19, #32]
    53a8:	f100033f 	cmp	x25, #0x0
    53ac:	f9401a61 	ldr	x1, [x19, #48]
    53b0:	b8357854 	str	w20, [x2, x21, lsl #2]
    53b4:	f9401e62 	ldr	x2, [x19, #56]
    53b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53bc:	fc35782b 	str	d11, [x1, x21, lsl #3]
    53c0:	9a80a321 	csel	x1, x25, x0, ge	// ge = tcont
    53c4:	b8357861 	str	w1, [x3, x21, lsl #2]
    53c8:	910006f6 	add	x22, x23, #0x1
    53cc:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    53d0:	92607e94 	and	x20, x20, #0xffffffff00000000
    53d4:	fc357849 	str	d9, [x2, x21, lsl #3]
    53d8:	aa170294 	orr	x20, x20, x23
    53dc:	f9000a76 	str	x22, [x19, #16]
    53e0:	1e68396b 	fsub	d11, d11, d8
    53e4:	b7f81a78 	tbnz	x24, #63, 5730 <w120+0x4d0>
    53e8:	9360ff17 	asr	x23, x24, #32
    53ec:	eb1a02ff 	cmp	x23, x26
    53f0:	540000e0 	b.eq	540c <w120+0x1ac>  // b.none
    53f4:	aa1703e0 	mov	x0, x23
    53f8:	97fffcaa 	bl	46a0 <fwp_tape_of>
    53fc:	aa0003f3 	mov	x19, x0
    5400:	f9403000 	ldr	x0, [x0, #96]
    5404:	b5fff560 	cbnz	x0, 52b0 <w120+0x50>
    5408:	f9400a76 	ldr	x22, [x19, #16]
    540c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5410:	eb0002df 	cmp	x22, x0
    5414:	5400132c 	b.gt	5678 <w120+0x418>
    5418:	eb3842df 	cmp	x22, w24, uxtw
    541c:	5400128d 	b.le	566c <w120+0x40c>
    5420:	f9400675 	ldr	x21, [x19, #8]
    5424:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5428:	cb1502d5 	sub	x21, x22, x21
    542c:	910006a1 	add	x1, x21, #0x1
    5430:	eb00003f 	cmp	x1, x0
    5434:	54001228 	b.hi	5678 <w120+0x418>  // b.pmore
    5438:	f9400e60 	ldr	x0, [x19, #24]
    543c:	eb00003f 	cmp	x1, x0
    5440:	5400138c 	b.gt	56b0 <w120+0x450>
    5444:	a9420262 	ldp	x2, x0, [x19, #32]
    5448:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    544c:	f9401a63 	ldr	x3, [x19, #48]
    5450:	b8357858 	str	w24, [x2, x21, lsl #2]
    5454:	f9401e62 	ldr	x2, [x19, #56]
    5458:	12800001 	mov	w1, #0xffffffff            	// #-1
    545c:	fc357860 	str	d0, [x3, x21, lsl #3]
    5460:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5464:	b8357801 	str	w1, [x0, x21, lsl #2]
    5468:	92607f00 	and	x0, x24, #0xffffffff00000000
    546c:	aa160018 	orr	x24, x0, x22
    5470:	910006c1 	add	x1, x22, #0x1
    5474:	fc357840 	str	d0, [x2, x21, lsl #3]
    5478:	f9000a61 	str	x1, [x19, #16]
    547c:	9360fe99 	asr	x25, x20, #32
    5480:	1e6a0949 	fmul	d9, d10, d10
    5484:	eb17033f 	cmp	x25, x23
    5488:	540000c0 	b.eq	54a0 <w120+0x240>  // b.none
    548c:	aa1903e0 	mov	x0, x25
    5490:	97fffc84 	bl	46a0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5fff0a0 	cbnz	x0, 52b0 <w120+0x50>
    54a0:	f9400a75 	ldr	x21, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002bf 	cmp	x21, x0
    54ac:	54000e6c 	b.gt	5678 <w120+0x418>
    54b0:	eb3442bf 	cmp	x21, w20, uxtw
    54b4:	54000dcd 	b.le	566c <w120+0x40c>
    54b8:	f9400676 	ldr	x22, [x19, #8]
    54bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54c0:	cb1602b6 	sub	x22, x21, x22
    54c4:	910006c1 	add	x1, x22, #0x1
    54c8:	eb00003f 	cmp	x1, x0
    54cc:	54000d68 	b.hi	5678 <w120+0x418>  // b.pmore
    54d0:	f9400e60 	ldr	x0, [x19, #24]
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000e6c 	b.gt	56a4 <w120+0x444>
    54dc:	92607e80 	and	x0, x20, #0xffffffff00000000
    54e0:	aa150017 	orr	x23, x0, x21
    54e4:	a9420261 	ldp	x1, x0, [x19, #32]
    54e8:	f9401a62 	ldr	x2, [x19, #48]
    54ec:	b8367834 	str	w20, [x1, x22, lsl #2]
    54f0:	f9401e61 	ldr	x1, [x19, #56]
    54f4:	fc36784a 	str	d10, [x2, x22, lsl #3]
    54f8:	b8367814 	str	w20, [x0, x22, lsl #2]
    54fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5500:	9e670000 	fmov	d0, x0
    5504:	910006b4 	add	x20, x21, #0x1
    5508:	fc36782a 	str	d10, [x1, x22, lsl #3]
    550c:	9360fef6 	asr	x22, x23, #32
    5510:	f9000a74 	str	x20, [x19, #16]
    5514:	1e600929 	fmul	d9, d9, d0
    5518:	eb1902df 	cmp	x22, x25
    551c:	540000e0 	b.eq	5538 <w120+0x2d8>  // b.none
    5520:	aa1603e0 	mov	x0, x22
    5524:	97fffc5f 	bl	46a0 <fwp_tape_of>
    5528:	aa0003f3 	mov	x19, x0
    552c:	f9403000 	ldr	x0, [x0, #96]
    5530:	b5ffec00 	cbnz	x0, 52b0 <w120+0x50>
    5534:	f9400a74 	ldr	x20, [x19, #16]
    5538:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    553c:	eb00029f 	cmp	x20, x0
    5540:	540009cc 	b.gt	5678 <w120+0x418>
    5544:	eb37429f 	cmp	x20, w23, uxtw
    5548:	5400092d 	b.le	566c <w120+0x40c>
    554c:	f9400675 	ldr	x21, [x19, #8]
    5550:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5554:	cb150295 	sub	x21, x20, x21
    5558:	910006a1 	add	x1, x21, #0x1
    555c:	eb00003f 	cmp	x1, x0
    5560:	540008c8 	b.hi	5678 <w120+0x418>  // b.pmore
    5564:	f9400e60 	ldr	x0, [x19, #24]
    5568:	eb00003f 	cmp	x1, x0
    556c:	5400096c 	b.gt	5698 <w120+0x438>
    5570:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5574:	9e670000 	fmov	d0, x0
    5578:	a9420262 	ldp	x2, x0, [x19, #32]
    557c:	1e6b0968 	fmul	d8, d11, d11
    5580:	f9401a61 	ldr	x1, [x19, #48]
    5584:	b8357857 	str	w23, [x2, x21, lsl #2]
    5588:	f9401e62 	ldr	x2, [x19, #56]
    558c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5590:	12800001 	mov	w1, #0xffffffff            	// #-1
    5594:	b8357801 	str	w1, [x0, x21, lsl #2]
    5598:	91000681 	add	x1, x20, #0x1
    559c:	f835785f 	str	xzr, [x2, x21, lsl #3]
    55a0:	92607ee0 	and	x0, x23, #0xffffffff00000000
    55a4:	f9000a61 	str	x1, [x19, #16]
    55a8:	aa140014 	orr	x20, x0, x20
    55ac:	b100071f 	cmn	x24, #0x1
    55b0:	54000c60 	b.eq	573c <w120+0x4dc>  // b.none
    55b4:	9360ff00 	asr	x0, x24, #32
    55b8:	eb16001f 	cmp	x0, x22
    55bc:	540000a0 	b.eq	55d0 <w120+0x370>  // b.none
    55c0:	97fffc38 	bl	46a0 <fwp_tape_of>
    55c4:	aa0003f3 	mov	x19, x0
    55c8:	f9403000 	ldr	x0, [x0, #96]
    55cc:	b5ffe720 	cbnz	x0, 52b0 <w120+0x50>
    55d0:	f9400a75 	ldr	x21, [x19, #16]
    55d4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55d8:	eb0002bf 	cmp	x21, x0
    55dc:	540004ec 	b.gt	5678 <w120+0x418>
    55e0:	eb3842bf 	cmp	x21, w24, uxtw
    55e4:	5400044d 	b.le	566c <w120+0x40c>
    55e8:	f9400676 	ldr	x22, [x19, #8]
    55ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55f0:	cb1602b6 	sub	x22, x21, x22
    55f4:	910006c1 	add	x1, x22, #0x1
    55f8:	eb00003f 	cmp	x1, x0
    55fc:	540003e8 	b.hi	5678 <w120+0x418>  // b.pmore
    5600:	f9400e60 	ldr	x0, [x19, #24]
    5604:	eb00003f 	cmp	x1, x0
    5608:	5400042c 	b.gt	568c <w120+0x42c>
    560c:	a9420a61 	ldp	x1, x2, [x19, #32]
    5610:	92607f00 	and	x0, x24, #0xffffffff00000000
    5614:	f9401a63 	ldr	x3, [x19, #48]
    5618:	b8367838 	str	w24, [x1, x22, lsl #2]
    561c:	f9401e61 	ldr	x1, [x19, #56]
    5620:	aa150000 	orr	x0, x0, x21
    5624:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5628:	910006b5 	add	x21, x21, #0x1
    562c:	b8367858 	str	w24, [x2, x22, lsl #2]
    5630:	fc36782b 	str	d11, [x1, x22, lsl #3]
    5634:	f9000a75 	str	x21, [x19, #16]
    5638:	1e692908 	fadd	d8, d8, d9
    563c:	aa1403e1 	mov	x1, x20
    5640:	97fffeb0 	bl	5100 <f141.constprop.0>
    5644:	aa0003e1 	mov	x1, x0
    5648:	a94153f3 	ldp	x19, x20, [sp, #16]
    564c:	9e660100 	fmov	x0, d8
    5650:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5654:	a94363f7 	ldp	x23, x24, [sp, #48]
    5658:	a9446bf9 	ldp	x25, x26, [sp, #64]
    565c:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5660:	6d462fea 	ldp	d10, d11, [sp, #96]
    5664:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5668:	d65f03c0 	ret
    566c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5670:	913d6000 	add	x0, x0, #0xf58
    5674:	97fffa07 	bl	3e90 <fwp_trap>
    5678:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    567c:	913b0000 	add	x0, x0, #0xec0
    5680:	97fffa04 	bl	3e90 <fwp_trap>
    5684:	97fffe08 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5688:	17ffff1c 	b	52f8 <w120+0x98>
    568c:	aa1303e0 	mov	x0, x19
    5690:	97fffe05 	bl	4ea4 <fwp_tape_grow.constprop.0>
    5694:	17ffffde 	b	560c <w120+0x3ac>
    5698:	aa1303e0 	mov	x0, x19
    569c:	97fffe02 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56a0:	17ffffb4 	b	5570 <w120+0x310>
    56a4:	aa1303e0 	mov	x0, x19
    56a8:	97fffdff 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56ac:	17ffff8c 	b	54dc <w120+0x27c>
    56b0:	aa1303e0 	mov	x0, x19
    56b4:	97fffdfc 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56b8:	17ffff63 	b	5444 <w120+0x1e4>
    56bc:	aa1303e0 	mov	x0, x19
    56c0:	97fffdf9 	bl	4ea4 <fwp_tape_grow.constprop.0>
    56c4:	17ffff38 	b	53a4 <w120+0x144>
    56c8:	1e6a382a 	fsub	d10, d1, d10
    56cc:	b6f801c1 	tbz	x1, #63, 5704 <w120+0x4a4>
    56d0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56d4:	1e6a0949 	fmul	d9, d10, d10
    56d8:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    56dc:	9e670001 	fmov	d1, x0
    56e0:	1e683808 	fsub	d8, d0, d8
    56e4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    56e8:	aa1403e0 	mov	x0, x20
    56ec:	1e610929 	fmul	d9, d9, d1
    56f0:	1e680908 	fmul	d8, d8, d8
    56f4:	17ffffd1 	b	5638 <w120+0x3d8>
    56f8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    56fc:	913b8000 	add	x0, x0, #0xee0
    5700:	97fff9e4 	bl	3e90 <fwp_trap>
    5704:	2f00e409 	movi	d9, #0x0
    5708:	1e6e100b 	fmov	d11, #1.000000000000000000e+00
    570c:	9360fc3a 	asr	x26, x1, #32
    5710:	aa0103f4 	mov	x20, x1
    5714:	aa1a03e0 	mov	x0, x26
    5718:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
    571c:	97fffbe1 	bl	46a0 <fwp_tape_of>
    5720:	aa0003f3 	mov	x19, x0
    5724:	f9403000 	ldr	x0, [x0, #96]
    5728:	b5ffdc40 	cbnz	x0, 52b0 <w120+0x50>
    572c:	17ffff0c 	b	535c <w120+0xfc>
    5730:	aa1a03f7 	mov	x23, x26
    5734:	aa0003f8 	mov	x24, x0
    5738:	17ffff51 	b	547c <w120+0x21c>
    573c:	aa1803e0 	mov	x0, x24
    5740:	17ffffbe 	b	5638 <w120+0x3d8>

0000000000005744 <fwp_rc_share>:
    5744:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5748:	91150042 	add	x2, x2, #0x540
    574c:	f949d843 	ldr	x3, [x2, #5040]
    5750:	f949ec41 	ldr	x1, [x2, #5080]
    5754:	cb030000 	sub	x0, x0, x3
    5758:	eb01401f 	cmp	x0, x1, lsl #16
    575c:	540003a2 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5760:	d350fc01 	lsr	x1, x0, #16
    5764:	f949fc44 	ldr	x4, [x2, #5112]
    5768:	8b010821 	add	x1, x1, x1, lsl #2
    576c:	d37df021 	lsl	x1, x1, #3
    5770:	8b010083 	add	x3, x4, x1
    5774:	f9401062 	ldr	x2, [x3, #32]
    5778:	b40002c2 	cbz	x2, 57d0 <fwp_rc_share+0x8c>
    577c:	38616881 	ldrb	w1, [x4, x1]
    5780:	7100083f 	cmp	w1, #0x2
    5784:	54000220 	b.eq	57c8 <fwp_rc_share+0x84>  // b.none
    5788:	7100043f 	cmp	w1, #0x1
    578c:	54000221 	b.ne	57d0 <fwp_rc_share+0x8c>  // b.any
    5790:	29430464 	ldp	w4, w1, [x3, #24]
    5794:	92403c00 	and	x0, x0, #0xffff
    5798:	9b047c00 	mul	x0, x0, x4
    579c:	d360fc00 	lsr	x0, x0, #32
    57a0:	eb01001f 	cmp	x0, x1
    57a4:	54000162 	b.cs	57d0 <fwp_rc_share+0x8c>  // b.hs, b.nlast
    57a8:	8b000042 	add	x2, x2, x0
    57ac:	39400040 	ldrb	w0, [x2]
    57b0:	34000100 	cbz	w0, 57d0 <fwp_rc_share+0x8c>
    57b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57b8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    57bc:	913de000 	add	x0, x0, #0xf78
    57c0:	910003fd 	mov	x29, sp
    57c4:	97fff9b3 	bl	3e90 <fwp_trap>
    57c8:	72003c1f 	tst	w0, #0xffff
    57cc:	54ffff00 	b.eq	57ac <fwp_rc_share+0x68>  // b.none
    57d0:	d65f03c0 	ret

00000000000057d4 <fwp_rc_free_arr>:
    57d4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    57d8:	91150063 	add	x3, x3, #0x540
    57dc:	f949d861 	ldr	x1, [x3, #5040]
    57e0:	f949ec62 	ldr	x2, [x3, #5080]
    57e4:	cb010001 	sub	x1, x0, x1
    57e8:	eb02403f 	cmp	x1, x2, lsl #16
    57ec:	54000342 	b.cs	5854 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57f0:	d350fc22 	lsr	x2, x1, #16
    57f4:	f949fc65 	ldr	x5, [x3, #5112]
    57f8:	8b020842 	add	x2, x2, x2, lsl #2
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	8b0200a4 	add	x4, x5, x2
    5804:	f9401083 	ldr	x3, [x4, #32]
    5808:	b4000263 	cbz	x3, 5854 <fwp_rc_free_arr+0x80>
    580c:	386268a2 	ldrb	w2, [x5, x2]
    5810:	7100085f 	cmp	w2, #0x2
    5814:	540001c0 	b.eq	584c <fwp_rc_free_arr+0x78>  // b.none
    5818:	7100045f 	cmp	w2, #0x1
    581c:	540001c1 	b.ne	5854 <fwp_rc_free_arr+0x80>  // b.any
    5820:	29430885 	ldp	w5, w2, [x4, #24]
    5824:	92403c21 	and	x1, x1, #0xffff
    5828:	9b057c21 	mul	x1, x1, x5
    582c:	d360fc21 	lsr	x1, x1, #32
    5830:	eb02003f 	cmp	x1, x2
    5834:	54000102 	b.cs	5854 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5838:	8b010063 	add	x3, x3, x1
    583c:	39400061 	ldrb	w1, [x3]
    5840:	7100043f 	cmp	w1, #0x1
    5844:	54000081 	b.ne	5854 <fwp_rc_free_arr+0x80>  // b.any
    5848:	17fffa4e 	b	4180 <fwp_mem_free>
    584c:	72003c3f 	tst	w1, #0xffff
    5850:	54ffff60 	b.eq	583c <fwp_rc_free_arr+0x68>  // b.none
    5854:	d65f03c0 	ret
    5858:	d503201f 	nop
    585c:	d503201f 	nop

0000000000005860 <fwp_rc_dup>:
    5860:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5864:	91150042 	add	x2, x2, #0x540
    5868:	f949d841 	ldr	x1, [x2, #5040]
    586c:	f949ec43 	ldr	x3, [x2, #5080]
    5870:	cb010001 	sub	x1, x0, x1
    5874:	eb03403f 	cmp	x1, x3, lsl #16
    5878:	54000342 	b.cs	58e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    587c:	d350fc20 	lsr	x0, x1, #16
    5880:	f949fc44 	ldr	x4, [x2, #5112]
    5884:	8b000800 	add	x0, x0, x0, lsl #2
    5888:	d37df002 	lsl	x2, x0, #3
    588c:	8b020083 	add	x3, x4, x2
    5890:	f9401060 	ldr	x0, [x3, #32]
    5894:	b4000260 	cbz	x0, 58e0 <fwp_rc_dup+0x80>
    5898:	38626882 	ldrb	w2, [x4, x2]
    589c:	7100085f 	cmp	w2, #0x2
    58a0:	54000220 	b.eq	58e4 <fwp_rc_dup+0x84>  // b.none
    58a4:	7100045f 	cmp	w2, #0x1
    58a8:	540001c1 	b.ne	58e0 <fwp_rc_dup+0x80>  // b.any
    58ac:	29430864 	ldp	w4, w2, [x3, #24]
    58b0:	92403c21 	and	x1, x1, #0xffff
    58b4:	9b047c21 	mul	x1, x1, x4
    58b8:	d360fc21 	lsr	x1, x1, #32
    58bc:	eb02003f 	cmp	x1, x2
    58c0:	54000102 	b.cs	58e0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58c4:	8b010000 	add	x0, x0, x1
    58c8:	39400001 	ldrb	w1, [x0]
    58cc:	340000a1 	cbz	w1, 58e0 <fwp_rc_dup+0x80>
    58d0:	7103f43f 	cmp	w1, #0xfd
    58d4:	540000e8 	b.hi	58f0 <fwp_rc_dup+0x90>  // b.pmore
    58d8:	11000421 	add	w1, w1, #0x1
    58dc:	39000001 	strb	w1, [x0]
    58e0:	d65f03c0 	ret
    58e4:	72003c3f 	tst	w1, #0xffff
    58e8:	54ffff00 	b.eq	58c8 <fwp_rc_dup+0x68>  // b.none
    58ec:	d65f03c0 	ret
    58f0:	17fffa9d 	b	4364 <fwp_rc_wide_dup>

00000000000058f4 <fwp_owned_entry173>:
    58f4:	d10103ff 	sub	sp, sp, #0x40
    58f8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    58fc:	f947f442 	ldr	x2, [x2, #4072]
    5900:	a9027bfd 	stp	x29, x30, [sp, #32]
    5904:	910083fd 	add	x29, sp, #0x20
    5908:	a90353f3 	stp	x19, x20, [sp, #48]
    590c:	f9400043 	ldr	x3, [x2]
    5910:	f9000fe3 	str	x3, [sp, #24]
    5914:	d2800003 	mov	x3, #0x0                   	// #0
    5918:	a9400c01 	ldp	x1, x3, [x0]
    591c:	f9400802 	ldr	x2, [x0, #16]
    5920:	ab020022 	adds	x2, x1, x2
    5924:	540006e6 	b.vs	5a00 <fwp_owned_entry173+0x10c>
    5928:	910023e1 	add	x1, sp, #0x8
    592c:	52800000 	mov	w0, #0x0                   	// #0
    5930:	a9008be3 	stp	x3, x2, [sp, #8]
    5934:	97fffd14 	bl	4d84 <fwp_data.part.0.constprop.0>
    5938:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    593c:	91150063 	add	x3, x3, #0x540
    5940:	aa0003f3 	mov	x19, x0
    5944:	f949d861 	ldr	x1, [x3, #5040]
    5948:	f949ec60 	ldr	x0, [x3, #5080]
    594c:	cb010261 	sub	x1, x19, x1
    5950:	eb00403f 	cmp	x1, x0, lsl #16
    5954:	54000322 	b.cs	59b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5958:	d350fc22 	lsr	x2, x1, #16
    595c:	f949fc63 	ldr	x3, [x3, #5112]
    5960:	8b020842 	add	x2, x2, x2, lsl #2
    5964:	d37df042 	lsl	x2, x2, #3
    5968:	8b020060 	add	x0, x3, x2
    596c:	f9401014 	ldr	x20, [x0, #32]
    5970:	b4000254 	cbz	x20, 59b8 <fwp_owned_entry173+0xc4>
    5974:	38626862 	ldrb	w2, [x3, x2]
    5978:	7100085f 	cmp	w2, #0x2
    597c:	54000360 	b.eq	59e8 <fwp_owned_entry173+0xf4>  // b.none
    5980:	7100045f 	cmp	w2, #0x1
    5984:	540001a1 	b.ne	59b8 <fwp_owned_entry173+0xc4>  // b.any
    5988:	29430002 	ldp	w2, w0, [x0, #24]
    598c:	92403c21 	and	x1, x1, #0xffff
    5990:	9b027c21 	mul	x1, x1, x2
    5994:	d360fc21 	lsr	x1, x1, #32
    5998:	eb00003f 	cmp	x1, x0
    599c:	540000e2 	b.cs	59b8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    59a0:	8b010294 	add	x20, x20, x1
    59a4:	39400280 	ldrb	w0, [x20]
    59a8:	7103fc1f 	cmp	w0, #0xff
    59ac:	54000240 	b.eq	59f4 <fwp_owned_entry173+0x100>  // b.none
    59b0:	52800020 	mov	w0, #0x1                   	// #1
    59b4:	39000280 	strb	w0, [x20]
    59b8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59bc:	f947f400 	ldr	x0, [x0, #4072]
    59c0:	f9400fe2 	ldr	x2, [sp, #24]
    59c4:	f9400001 	ldr	x1, [x0]
    59c8:	eb010042 	subs	x2, x2, x1
    59cc:	d2800001 	mov	x1, #0x0                   	// #0
    59d0:	540001a1 	b.ne	5a04 <fwp_owned_entry173+0x110>  // b.any
    59d4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59d8:	aa1303e0 	mov	x0, x19
    59dc:	a94353f3 	ldp	x19, x20, [sp, #48]
    59e0:	910103ff 	add	sp, sp, #0x40
    59e4:	d65f03c0 	ret
    59e8:	72003c3f 	tst	w1, #0xffff
    59ec:	54fffe61 	b.ne	59b8 <fwp_owned_entry173+0xc4>  // b.any
    59f0:	17ffffed 	b	59a4 <fwp_owned_entry173+0xb0>
    59f4:	aa1403e0 	mov	x0, x20
    59f8:	97fff946 	bl	3f10 <fwp_rc_forget_slot.part.0>
    59fc:	17ffffed 	b	59b0 <fwp_owned_entry173+0xbc>
    5a00:	97fff420 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5a04:	97fff39f 	bl	2880 <__stack_chk_fail@plt>
    5a08:	d503201f 	nop
    5a0c:	d503201f 	nop

0000000000005a10 <e173>:
    5a10:	d10103ff 	sub	sp, sp, #0x40
    5a14:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5a18:	f947f442 	ldr	x2, [x2, #4072]
    5a1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a20:	910083fd 	add	x29, sp, #0x20
    5a24:	a90353f3 	stp	x19, x20, [sp, #48]
    5a28:	f9400043 	ldr	x3, [x2]
    5a2c:	f9000fe3 	str	x3, [sp, #24]
    5a30:	d2800003 	mov	x3, #0x0                   	// #0
    5a34:	a9400c01 	ldp	x1, x3, [x0]
    5a38:	f9400802 	ldr	x2, [x0, #16]
    5a3c:	ab020022 	adds	x2, x1, x2
    5a40:	54000726 	b.vs	5b24 <e173+0x114>
    5a44:	910023e1 	add	x1, sp, #0x8
    5a48:	52800000 	mov	w0, #0x0                   	// #0
    5a4c:	a9008be3 	stp	x3, x2, [sp, #8]
    5a50:	97fffccd 	bl	4d84 <fwp_data.part.0.constprop.0>
    5a54:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5a58:	91150063 	add	x3, x3, #0x540
    5a5c:	aa0003f3 	mov	x19, x0
    5a60:	f949d861 	ldr	x1, [x3, #5040]
    5a64:	f949ec60 	ldr	x0, [x3, #5080]
    5a68:	cb010261 	sub	x1, x19, x1
    5a6c:	eb00403f 	cmp	x1, x0, lsl #16
    5a70:	54000322 	b.cs	5ad4 <e173+0xc4>  // b.hs, b.nlast
    5a74:	d350fc22 	lsr	x2, x1, #16
    5a78:	f949fc63 	ldr	x3, [x3, #5112]
    5a7c:	8b020842 	add	x2, x2, x2, lsl #2
    5a80:	d37df042 	lsl	x2, x2, #3
    5a84:	8b020060 	add	x0, x3, x2
    5a88:	f9401014 	ldr	x20, [x0, #32]
    5a8c:	b4000254 	cbz	x20, 5ad4 <e173+0xc4>
    5a90:	38626862 	ldrb	w2, [x3, x2]
    5a94:	7100085f 	cmp	w2, #0x2
    5a98:	540003a0 	b.eq	5b0c <e173+0xfc>  // b.none
    5a9c:	7100045f 	cmp	w2, #0x1
    5aa0:	540001a1 	b.ne	5ad4 <e173+0xc4>  // b.any
    5aa4:	29430002 	ldp	w2, w0, [x0, #24]
    5aa8:	92403c21 	and	x1, x1, #0xffff
    5aac:	9b027c21 	mul	x1, x1, x2
    5ab0:	d360fc21 	lsr	x1, x1, #32
    5ab4:	eb00003f 	cmp	x1, x0
    5ab8:	540000e2 	b.cs	5ad4 <e173+0xc4>  // b.hs, b.nlast
    5abc:	8b010294 	add	x20, x20, x1
    5ac0:	39400280 	ldrb	w0, [x20]
    5ac4:	7103fc1f 	cmp	w0, #0xff
    5ac8:	54000280 	b.eq	5b18 <e173+0x108>  // b.none
    5acc:	52800020 	mov	w0, #0x1                   	// #1
    5ad0:	39000280 	strb	w0, [x20]
    5ad4:	aa1303e0 	mov	x0, x19
    5ad8:	97ffff1b 	bl	5744 <fwp_rc_share>
    5adc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ae0:	f947f400 	ldr	x0, [x0, #4072]
    5ae4:	f9400fe2 	ldr	x2, [sp, #24]
    5ae8:	f9400001 	ldr	x1, [x0]
    5aec:	eb010042 	subs	x2, x2, x1
    5af0:	d2800001 	mov	x1, #0x0                   	// #0
    5af4:	540001a1 	b.ne	5b28 <e173+0x118>  // b.any
    5af8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5afc:	aa1303e0 	mov	x0, x19
    5b00:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b04:	910103ff 	add	sp, sp, #0x40
    5b08:	d65f03c0 	ret
    5b0c:	72003c3f 	tst	w1, #0xffff
    5b10:	54fffe21 	b.ne	5ad4 <e173+0xc4>  // b.any
    5b14:	17ffffeb 	b	5ac0 <e173+0xb0>
    5b18:	aa1403e0 	mov	x0, x20
    5b1c:	97fff8fd 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5b20:	17ffffeb 	b	5acc <e173+0xbc>
    5b24:	97fff3d7 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b28:	97fff356 	bl	2880 <__stack_chk_fail@plt>
    5b2c:	d503201f 	nop

0000000000005b30 <fwp_drop1>:
    5b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b34:	910003fd 	mov	x29, sp
    5b38:	a90153f3 	stp	x19, x20, [sp, #16]
    5b3c:	f90013f5 	str	x21, [sp, #32]
    5b40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5b44:	911502b4 	add	x20, x21, #0x540
    5b48:	f949da81 	ldr	x1, [x20, #5040]
    5b4c:	f949ee82 	ldr	x2, [x20, #5080]
    5b50:	cb010001 	sub	x1, x0, x1
    5b54:	eb02403f 	cmp	x1, x2, lsl #16
    5b58:	54000382 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b5c:	d350fc22 	lsr	x2, x1, #16
    5b60:	f949fe84 	ldr	x4, [x20, #5112]
    5b64:	8b020842 	add	x2, x2, x2, lsl #2
    5b68:	d37df042 	lsl	x2, x2, #3
    5b6c:	8b020083 	add	x3, x4, x2
    5b70:	f9401073 	ldr	x19, [x3, #32]
    5b74:	b40002b3 	cbz	x19, 5bc8 <fwp_drop1+0x98>
    5b78:	38626882 	ldrb	w2, [x4, x2]
    5b7c:	7100085f 	cmp	w2, #0x2
    5b80:	540002c0 	b.eq	5bd8 <fwp_drop1+0xa8>  // b.none
    5b84:	7100045f 	cmp	w2, #0x1
    5b88:	54000201 	b.ne	5bc8 <fwp_drop1+0x98>  // b.any
    5b8c:	29430864 	ldp	w4, w2, [x3, #24]
    5b90:	92403c21 	and	x1, x1, #0xffff
    5b94:	9b047c21 	mul	x1, x1, x4
    5b98:	d360fc21 	lsr	x1, x1, #32
    5b9c:	eb02003f 	cmp	x1, x2
    5ba0:	54000142 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ba4:	8b010273 	add	x19, x19, x1
    5ba8:	39400261 	ldrb	w1, [x19]
    5bac:	340000e1 	cbz	w1, 5bc8 <fwp_drop1+0x98>
    5bb0:	7100043f 	cmp	w1, #0x1
    5bb4:	540001e0 	b.eq	5bf0 <fwp_drop1+0xc0>  // b.none
    5bb8:	7103fc3f 	cmp	w1, #0xff
    5bbc:	540002e0 	b.eq	5c18 <fwp_drop1+0xe8>  // b.none
    5bc0:	51000421 	sub	w1, w1, #0x1
    5bc4:	39000261 	strb	w1, [x19]
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	f94013f5 	ldr	x21, [sp, #32]
    5bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bd4:	d65f03c0 	ret
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54fffe60 	b.eq	5ba8 <fwp_drop1+0x78>  // b.none
    5be0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5be4:	f94013f5 	ldr	x21, [sp, #32]
    5be8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bec:	d65f03c0 	ret
    5bf0:	f9400813 	ldr	x19, [x0, #16]
    5bf4:	97fffef8 	bl	57d4 <fwp_rc_free_arr>
    5bf8:	911502a0 	add	x0, x21, #0x540
    5bfc:	f949d801 	ldr	x1, [x0, #5040]
    5c00:	f949ec00 	ldr	x0, [x0, #5080]
    5c04:	cb010261 	sub	x1, x19, x1
    5c08:	eb00403f 	cmp	x1, x0, lsl #16
    5c0c:	54fffde2 	b.cs	5bc8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c10:	aa1303e0 	mov	x0, x19
    5c14:	17ffffd2 	b	5b5c <fwp_drop1+0x2c>
    5c18:	ca534660 	eor	x0, x19, x19, lsr #17
    5c1c:	911502b5 	add	x21, x21, #0x540
    5c20:	ca402400 	eor	x0, x0, x0, lsr #9
    5c24:	92401c00 	and	x0, x0, #0xff
    5c28:	910a2402 	add	x2, x0, #0x289
    5c2c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5c30:	8b020ea2 	add	x2, x21, x2, lsl #3
    5c34:	f94a2400 	ldr	x0, [x0, #5192]
    5c38:	b50000a0 	cbnz	x0, 5c4c <fwp_drop1+0x11c>
    5c3c:	14000013 	b	5c88 <fwp_drop1+0x158>
    5c40:	91004002 	add	x2, x0, #0x10
    5c44:	f9400800 	ldr	x0, [x0, #16]
    5c48:	b4000200 	cbz	x0, 5c88 <fwp_drop1+0x158>
    5c4c:	f9400001 	ldr	x1, [x0]
    5c50:	eb13003f 	cmp	x1, x19
    5c54:	54ffff61 	b.ne	5c40 <fwp_drop1+0x110>  // b.any
    5c58:	f9400041 	ldr	x1, [x2]
    5c5c:	f9400420 	ldr	x0, [x1, #8]
    5c60:	d1000400 	sub	x0, x0, #0x1
    5c64:	f9000420 	str	x0, [x1, #8]
    5c68:	f103f81f 	cmp	x0, #0xfe
    5c6c:	54fffae1 	b.ne	5bc8 <fwp_drop1+0x98>  // b.any
    5c70:	39400260 	ldrb	w0, [x19]
    5c74:	7103fc1f 	cmp	w0, #0xff
    5c78:	540000e0 	b.eq	5c94 <fwp_drop1+0x164>  // b.none
    5c7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c80:	39000260 	strb	w0, [x19]
    5c84:	17ffffd1 	b	5bc8 <fwp_drop1+0x98>
    5c88:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5c8c:	91344000 	add	x0, x0, #0xd10
    5c90:	97fff880 	bl	3e90 <fwp_trap>
    5c94:	aa1303e0 	mov	x0, x19
    5c98:	97fff89e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5c9c:	17fffff8 	b	5c7c <fwp_drop1+0x14c>

0000000000005ca0 <fwp_drop0>:
    5ca0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ca4:	910003fd 	mov	x29, sp
    5ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    5cac:	f90013f5 	str	x21, [sp, #32]
    5cb0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5cb4:	911502b4 	add	x20, x21, #0x540
    5cb8:	f949da81 	ldr	x1, [x20, #5040]
    5cbc:	f949ee82 	ldr	x2, [x20, #5080]
    5cc0:	cb010001 	sub	x1, x0, x1
    5cc4:	eb02403f 	cmp	x1, x2, lsl #16
    5cc8:	54000382 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ccc:	d350fc22 	lsr	x2, x1, #16
    5cd0:	f949fe84 	ldr	x4, [x20, #5112]
    5cd4:	8b020842 	add	x2, x2, x2, lsl #2
    5cd8:	d37df042 	lsl	x2, x2, #3
    5cdc:	8b020083 	add	x3, x4, x2
    5ce0:	f9401073 	ldr	x19, [x3, #32]
    5ce4:	b40002b3 	cbz	x19, 5d38 <fwp_drop0+0x98>
    5ce8:	38626882 	ldrb	w2, [x4, x2]
    5cec:	7100085f 	cmp	w2, #0x2
    5cf0:	540002c0 	b.eq	5d48 <fwp_drop0+0xa8>  // b.none
    5cf4:	7100045f 	cmp	w2, #0x1
    5cf8:	54000201 	b.ne	5d38 <fwp_drop0+0x98>  // b.any
    5cfc:	29430864 	ldp	w4, w2, [x3, #24]
    5d00:	92403c21 	and	x1, x1, #0xffff
    5d04:	9b047c21 	mul	x1, x1, x4
    5d08:	d360fc21 	lsr	x1, x1, #32
    5d0c:	eb02003f 	cmp	x1, x2
    5d10:	54000142 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d14:	8b010273 	add	x19, x19, x1
    5d18:	39400261 	ldrb	w1, [x19]
    5d1c:	340000e1 	cbz	w1, 5d38 <fwp_drop0+0x98>
    5d20:	7100043f 	cmp	w1, #0x1
    5d24:	540001e0 	b.eq	5d60 <fwp_drop0+0xc0>  // b.none
    5d28:	7103fc3f 	cmp	w1, #0xff
    5d2c:	540002e0 	b.eq	5d88 <fwp_drop0+0xe8>  // b.none
    5d30:	51000421 	sub	w1, w1, #0x1
    5d34:	39000261 	strb	w1, [x19]
    5d38:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d3c:	f94013f5 	ldr	x21, [sp, #32]
    5d40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d44:	d65f03c0 	ret
    5d48:	72003c3f 	tst	w1, #0xffff
    5d4c:	54fffe60 	b.eq	5d18 <fwp_drop0+0x78>  // b.none
    5d50:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d54:	f94013f5 	ldr	x21, [sp, #32]
    5d58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d5c:	d65f03c0 	ret
    5d60:	f9400813 	ldr	x19, [x0, #16]
    5d64:	97fffe9c 	bl	57d4 <fwp_rc_free_arr>
    5d68:	911502a0 	add	x0, x21, #0x540
    5d6c:	f949d801 	ldr	x1, [x0, #5040]
    5d70:	f949ec00 	ldr	x0, [x0, #5080]
    5d74:	cb010261 	sub	x1, x19, x1
    5d78:	eb00403f 	cmp	x1, x0, lsl #16
    5d7c:	54fffde2 	b.cs	5d38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d80:	aa1303e0 	mov	x0, x19
    5d84:	17ffffd2 	b	5ccc <fwp_drop0+0x2c>
    5d88:	ca534660 	eor	x0, x19, x19, lsr #17
    5d8c:	911502b5 	add	x21, x21, #0x540
    5d90:	ca402400 	eor	x0, x0, x0, lsr #9
    5d94:	92401c00 	and	x0, x0, #0xff
    5d98:	910a2402 	add	x2, x0, #0x289
    5d9c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5da0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5da4:	f94a2400 	ldr	x0, [x0, #5192]
    5da8:	b50000a0 	cbnz	x0, 5dbc <fwp_drop0+0x11c>
    5dac:	14000013 	b	5df8 <fwp_drop0+0x158>
    5db0:	91004002 	add	x2, x0, #0x10
    5db4:	f9400800 	ldr	x0, [x0, #16]
    5db8:	b4000200 	cbz	x0, 5df8 <fwp_drop0+0x158>
    5dbc:	f9400001 	ldr	x1, [x0]
    5dc0:	eb13003f 	cmp	x1, x19
    5dc4:	54ffff61 	b.ne	5db0 <fwp_drop0+0x110>  // b.any
    5dc8:	f9400041 	ldr	x1, [x2]
    5dcc:	f9400420 	ldr	x0, [x1, #8]
    5dd0:	d1000400 	sub	x0, x0, #0x1
    5dd4:	f9000420 	str	x0, [x1, #8]
    5dd8:	f103f81f 	cmp	x0, #0xfe
    5ddc:	54fffae1 	b.ne	5d38 <fwp_drop0+0x98>  // b.any
    5de0:	39400260 	ldrb	w0, [x19]
    5de4:	7103fc1f 	cmp	w0, #0xff
    5de8:	540000e0 	b.eq	5e04 <fwp_drop0+0x164>  // b.none
    5dec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5df0:	39000260 	strb	w0, [x19]
    5df4:	17ffffd1 	b	5d38 <fwp_drop0+0x98>
    5df8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5dfc:	91344000 	add	x0, x0, #0xd10
    5e00:	97fff824 	bl	3e90 <fwp_trap>
    5e04:	aa1303e0 	mov	x0, x19
    5e08:	97fff842 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5e0c:	17fffff8 	b	5dec <fwp_drop0+0x14c>

0000000000005e10 <fwp_closure_drop>:
    5e10:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5e14:	911500a4 	add	x4, x5, #0x540
    5e18:	aa0003e1 	mov	x1, x0
    5e1c:	f949d882 	ldr	x2, [x4, #5040]
    5e20:	f949ec80 	ldr	x0, [x4, #5080]
    5e24:	cb020022 	sub	x2, x1, x2
    5e28:	eb00405f 	cmp	x2, x0, lsl #16
    5e2c:	54000662 	b.cs	5ef8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e34:	d350fc43 	lsr	x3, x2, #16
    5e38:	910003fd 	mov	x29, sp
    5e3c:	8b030863 	add	x3, x3, x3, lsl #2
    5e40:	f949fc84 	ldr	x4, [x4, #5112]
    5e44:	d37df063 	lsl	x3, x3, #3
    5e48:	f9000bf3 	str	x19, [sp, #16]
    5e4c:	8b030080 	add	x0, x4, x3
    5e50:	f9401013 	ldr	x19, [x0, #32]
    5e54:	b40002b3 	cbz	x19, 5ea8 <fwp_closure_drop+0x98>
    5e58:	38636883 	ldrb	w3, [x4, x3]
    5e5c:	7100087f 	cmp	w3, #0x2
    5e60:	54000420 	b.eq	5ee4 <fwp_closure_drop+0xd4>  // b.none
    5e64:	7100047f 	cmp	w3, #0x1
    5e68:	54000201 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5e6c:	29430003 	ldp	w3, w0, [x0, #24]
    5e70:	92403c42 	and	x2, x2, #0xffff
    5e74:	9b037c42 	mul	x2, x2, x3
    5e78:	d360fc42 	lsr	x2, x2, #32
    5e7c:	eb00005f 	cmp	x2, x0
    5e80:	54000142 	b.cs	5ea8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e84:	8b020273 	add	x19, x19, x2
    5e88:	39400260 	ldrb	w0, [x19]
    5e8c:	340000e0 	cbz	w0, 5ea8 <fwp_closure_drop+0x98>
    5e90:	7100041f 	cmp	w0, #0x1
    5e94:	54000100 	b.eq	5eb4 <fwp_closure_drop+0xa4>  // b.none
    5e98:	7103fc1f 	cmp	w0, #0xff
    5e9c:	54000300 	b.eq	5efc <fwp_closure_drop+0xec>  // b.none
    5ea0:	51000400 	sub	w0, w0, #0x1
    5ea4:	39000260 	strb	w0, [x19]
    5ea8:	f9400bf3 	ldr	x19, [sp, #16]
    5eac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb0:	d65f03c0 	ret
    5eb4:	d53bd040 	mrs	x0, tpidr_el0
    5eb8:	91400000 	add	x0, x0, #0x0, lsl #12
    5ebc:	91004000 	add	x0, x0, #0x10
    5ec0:	f9400000 	ldr	x0, [x0]
    5ec4:	b4000080 	cbz	x0, 5ed4 <fwp_closure_drop+0xc4>
    5ec8:	f9400bf3 	ldr	x19, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	17fff96c 	b	4480 <fwp_closure_drop_push>
    5ed4:	f9400bf3 	ldr	x19, [sp, #16]
    5ed8:	aa0103e0 	mov	x0, x1
    5edc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ee0:	17fff9ad 	b	4594 <fwp_closure_drop.part.0>
    5ee4:	72003c5f 	tst	w2, #0xffff
    5ee8:	54fffd00 	b.eq	5e88 <fwp_closure_drop+0x78>  // b.none
    5eec:	f9400bf3 	ldr	x19, [sp, #16]
    5ef0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ef4:	d65f03c0 	ret
    5ef8:	d65f03c0 	ret
    5efc:	ca534660 	eor	x0, x19, x19, lsr #17
    5f00:	911500a5 	add	x5, x5, #0x540
    5f04:	ca402400 	eor	x0, x0, x0, lsr #9
    5f08:	92401c00 	and	x0, x0, #0xff
    5f0c:	910a2402 	add	x2, x0, #0x289
    5f10:	8b000ca0 	add	x0, x5, x0, lsl #3
    5f14:	8b020ca2 	add	x2, x5, x2, lsl #3
    5f18:	f94a2400 	ldr	x0, [x0, #5192]
    5f1c:	b50000a0 	cbnz	x0, 5f30 <fwp_closure_drop+0x120>
    5f20:	14000013 	b	5f6c <fwp_closure_drop+0x15c>
    5f24:	91004002 	add	x2, x0, #0x10
    5f28:	f9400800 	ldr	x0, [x0, #16]
    5f2c:	b4000200 	cbz	x0, 5f6c <fwp_closure_drop+0x15c>
    5f30:	f9400001 	ldr	x1, [x0]
    5f34:	eb13003f 	cmp	x1, x19
    5f38:	54ffff61 	b.ne	5f24 <fwp_closure_drop+0x114>  // b.any
    5f3c:	f9400041 	ldr	x1, [x2]
    5f40:	f9400420 	ldr	x0, [x1, #8]
    5f44:	d1000400 	sub	x0, x0, #0x1
    5f48:	f9000420 	str	x0, [x1, #8]
    5f4c:	f103f81f 	cmp	x0, #0xfe
    5f50:	54fffac1 	b.ne	5ea8 <fwp_closure_drop+0x98>  // b.any
    5f54:	39400260 	ldrb	w0, [x19]
    5f58:	7103fc1f 	cmp	w0, #0xff
    5f5c:	540000e0 	b.eq	5f78 <fwp_closure_drop+0x168>  // b.none
    5f60:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f64:	39000260 	strb	w0, [x19]
    5f68:	17ffffd0 	b	5ea8 <fwp_closure_drop+0x98>
    5f6c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    5f70:	91344000 	add	x0, x0, #0xd10
    5f74:	97fff7c7 	bl	3e90 <fwp_trap>
    5f78:	aa1303e0 	mov	x0, x19
    5f7c:	97fff7e5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5f80:	17fffff8 	b	5f60 <fwp_closure_drop+0x150>

0000000000005f84 <fwp_owned_tape_release>:
    5f84:	b4000920 	cbz	x0, 60a8 <fwp_owned_tape_release+0x124>
    5f88:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f8c:	910003fd 	mov	x29, sp
    5f90:	a90153f3 	stp	x19, x20, [sp, #16]
    5f94:	aa0003f3 	mov	x19, x0
    5f98:	f9400000 	ldr	x0, [x0]
    5f9c:	b4000060 	cbz	x0, 5fa8 <fwp_owned_tape_release+0x24>
    5fa0:	f9400661 	ldr	x1, [x19, #8]
    5fa4:	f9000401 	str	x1, [x0, #8]
    5fa8:	f9400661 	ldr	x1, [x19, #8]
    5fac:	b4000041 	cbz	x1, 5fb4 <fwp_owned_tape_release+0x30>
    5fb0:	f9000020 	str	x0, [x1]
    5fb4:	f9400a60 	ldr	x0, [x19, #16]
    5fb8:	f9403401 	ldr	x1, [x0, #104]
    5fbc:	b40005a1 	cbz	x1, 6070 <fwp_owned_tape_release+0xec>
    5fc0:	a9450a60 	ldp	x0, x2, [x19, #80]
    5fc4:	eb00005f 	cmp	x2, x0
    5fc8:	540002cd 	b.le	6020 <fwp_owned_tape_release+0x9c>
    5fcc:	d2800014 	mov	x20, #0x0                   	// #0
    5fd0:	f90013f5 	str	x21, [sp, #32]
    5fd4:	d2800015 	mov	x21, #0x0                   	// #0
    5fd8:	f9402260 	ldr	x0, [x19, #64]
    5fdc:	910006b5 	add	x21, x21, #0x1
    5fe0:	f8746800 	ldr	x0, [x0, x20]
    5fe4:	d63f0020 	blr	x1
    5fe8:	f9402260 	ldr	x0, [x19, #64]
    5fec:	f9400a61 	ldr	x1, [x19, #16]
    5ff0:	8b140000 	add	x0, x0, x20
    5ff4:	91004294 	add	x20, x20, #0x10
    5ff8:	f9400400 	ldr	x0, [x0, #8]
    5ffc:	f9403421 	ldr	x1, [x1, #104]
    6000:	d63f0020 	blr	x1
    6004:	a9450261 	ldp	x1, x0, [x19, #80]
    6008:	cb010000 	sub	x0, x0, x1
    600c:	eb15001f 	cmp	x0, x21
    6010:	f9400a60 	ldr	x0, [x19, #16]
    6014:	f9403401 	ldr	x1, [x0, #104]
    6018:	54fffe0c 	b.gt	5fd8 <fwp_owned_tape_release+0x54>
    601c:	f94013f5 	ldr	x21, [sp, #32]
    6020:	f9403663 	ldr	x3, [x19, #104]
    6024:	f9401262 	ldr	x2, [x19, #32]
    6028:	f100007f 	cmp	x3, #0x0
    602c:	540001ed 	b.le	6068 <fwp_owned_tape_release+0xe4>
    6030:	d2800014 	mov	x20, #0x0                   	// #0
    6034:	d503201f 	nop
    6038:	f9402660 	ldr	x0, [x19, #72]
    603c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6040:	eb02001f 	cmp	x0, x2
    6044:	540000c0 	b.eq	605c <fwp_owned_tape_release+0xd8>  // b.none
    6048:	d63f0020 	blr	x1
    604c:	f9400a60 	ldr	x0, [x19, #16]
    6050:	f9401262 	ldr	x2, [x19, #32]
    6054:	f9403663 	ldr	x3, [x19, #104]
    6058:	f9403401 	ldr	x1, [x0, #104]
    605c:	91000694 	add	x20, x20, #0x1
    6060:	eb14007f 	cmp	x3, x20
    6064:	54fffeac 	b.gt	6038 <fwp_owned_tape_release+0xb4>
    6068:	aa0203e0 	mov	x0, x2
    606c:	d63f0020 	blr	x1
    6070:	f9401660 	ldr	x0, [x19, #40]
    6074:	97ffff67 	bl	5e10 <fwp_closure_drop>
    6078:	f9401a60 	ldr	x0, [x19, #48]
    607c:	97ffff65 	bl	5e10 <fwp_closure_drop>
    6080:	f9401e60 	ldr	x0, [x19, #56]
    6084:	97ffff63 	bl	5e10 <fwp_closure_drop>
    6088:	f9402260 	ldr	x0, [x19, #64]
    608c:	97fff83d 	bl	4180 <fwp_mem_free>
    6090:	f9402660 	ldr	x0, [x19, #72]
    6094:	97fff83b 	bl	4180 <fwp_mem_free>
    6098:	aa1303e0 	mov	x0, x19
    609c:	a94153f3 	ldp	x19, x20, [sp, #16]
    60a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60a4:	17fff837 	b	4180 <fwp_mem_free>
    60a8:	d65f03c0 	ret
    60ac:	d503201f 	nop

00000000000060b0 <fwp_tape_finish>:
    60b0:	d10203ff 	sub	sp, sp, #0x80
    60b4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    60b8:	f947f421 	ldr	x1, [x1, #4072]
    60bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    60c0:	910103fd 	add	x29, sp, #0x40
    60c4:	a90553f3 	stp	x19, x20, [sp, #80]
    60c8:	a9065bf5 	stp	x21, x22, [sp, #96]
    60cc:	a90763f7 	stp	x23, x24, [sp, #112]
    60d0:	d00000d8 	adrp	x24, 20000 <__data_start>
    60d4:	9100c316 	add	x22, x24, #0x30
    60d8:	f9400022 	ldr	x2, [x1]
    60dc:	f9001fe2 	str	x2, [sp, #56]
    60e0:	d2800002 	mov	x2, #0x0                   	// #0
    60e4:	9100e2c0 	add	x0, x22, #0x38
    60e8:	97fff486 	bl	3300 <fwp_tape_buffers_dispose>
    60ec:	f9003adf 	str	xzr, [x22, #112]
    60f0:	f94042c0 	ldr	x0, [x22, #128]
    60f4:	f100001f 	cmp	x0, #0x0
    60f8:	5400030d 	b.le	6158 <fwp_tape_finish+0xa8>
    60fc:	910003f7 	mov	x23, sp
    6100:	d2800015 	mov	x21, #0x0                   	// #0
    6104:	d2800014 	mov	x20, #0x0                   	// #0
    6108:	f94002d3 	ldr	x19, [x22]
    610c:	91000694 	add	x20, x20, #0x1
    6110:	8b150273 	add	x19, x19, x21
    6114:	9101a2b5 	add	x21, x21, #0x68
    6118:	aa1303e0 	mov	x0, x19
    611c:	97fff39d 	bl	2f90 <fwp_tape_unlink_scope>
    6120:	aa1703e0 	mov	x0, x23
    6124:	f9401261 	ldr	x1, [x19, #32]
    6128:	f90003e1 	str	x1, [sp]
    612c:	f9401a62 	ldr	x2, [x19, #48]
    6130:	f9000be2 	str	x2, [sp, #16]
    6134:	f9402261 	ldr	x1, [x19, #64]
    6138:	f90013e1 	str	x1, [sp, #32]
    613c:	97fff471 	bl	3300 <fwp_tape_buffers_dispose>
    6140:	f9403260 	ldr	x0, [x19, #96]
    6144:	97ffff90 	bl	5f84 <fwp_owned_tape_release>
    6148:	f900327f 	str	xzr, [x19, #96]
    614c:	f94042c0 	ldr	x0, [x22, #128]
    6150:	eb14001f 	cmp	x0, x20
    6154:	54fffdac 	b.gt	6108 <fwp_tape_finish+0x58>
    6158:	f9401b00 	ldr	x0, [x24, #48]
    615c:	9100c313 	add	x19, x24, #0x30
    6160:	97fff1f8 	bl	2940 <free@plt>
    6164:	f9001b1f 	str	xzr, [x24, #48]
    6168:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    616c:	f947f400 	ldr	x0, [x0, #4072]
    6170:	f900427f 	str	xzr, [x19, #128]
    6174:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6178:	f9401fe2 	ldr	x2, [sp, #56]
    617c:	f9400001 	ldr	x1, [x0]
    6180:	eb010042 	subs	x2, x2, x1
    6184:	d2800001 	mov	x1, #0x0                   	// #0
    6188:	540000e1 	b.ne	61a4 <fwp_tape_finish+0xf4>  // b.any
    618c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6190:	a94553f3 	ldp	x19, x20, [sp, #80]
    6194:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6198:	a94763f7 	ldp	x23, x24, [sp, #112]
    619c:	910203ff 	add	sp, sp, #0x80
    61a0:	d65f03c0 	ret
    61a4:	97fff1b7 	bl	2880 <__stack_chk_fail@plt>
    61a8:	d503201f 	nop
    61ac:	d503201f 	nop

00000000000061b0 <fwp_tape_scope_release>:
    61b0:	d10243ff 	sub	sp, sp, #0x90
    61b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    61b8:	910103fd 	add	x29, sp, #0x40
    61bc:	a90553f3 	stp	x19, x20, [sp, #80]
    61c0:	aa0003f4 	mov	x20, x0
    61c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61c8:	f947f400 	ldr	x0, [x0, #4072]
    61cc:	b9400285 	ldr	w5, [x20]
    61d0:	f9400001 	ldr	x1, [x0]
    61d4:	f9001fe1 	str	x1, [sp, #56]
    61d8:	d2800001 	mov	x1, #0x0                   	// #0
    61dc:	37f806c5 	tbnz	w5, #31, 62b4 <fwp_tape_scope_release+0x104>
    61e0:	a90763f7 	stp	x23, x24, [sp, #112]
    61e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    61e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    61ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    61f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    61f4:	910003f7 	mov	x23, sp
    61f8:	9100c273 	add	x19, x19, #0x30
    61fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	52800d16 	mov	w22, #0x68                  	// #104
    6208:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    620c:	f90043f9 	str	x25, [sp, #128]
    6210:	14000006 	b	6228 <fwp_tape_scope_release+0x78>
    6214:	97fff43b 	bl	3300 <fwp_tape_buffers_dispose>
    6218:	aa1903e0 	mov	x0, x25
    621c:	97ffff5a 	bl	5f84 <fwp_owned_tape_release>
    6220:	b9400285 	ldr	w5, [x20]
    6224:	37f80425 	tbnz	w5, #31, 62a8 <fwp_tape_scope_release+0xf8>
    6228:	f9400266 	ldr	x6, [x19]
    622c:	9b367ca5 	smull	x5, w5, w22
    6230:	8b0500c0 	add	x0, x6, x5
    6234:	97fff357 	bl	2f90 <fwp_tape_unlink_scope>
    6238:	ad410001 	ldp	q1, q0, [x0, #32]
    623c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6240:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6244:	f9400c03 	ldr	x3, [x0, #24]
    6248:	ad0003e1 	stp	q1, q0, [sp]
    624c:	b86568c1 	ldr	w1, [x6, x5]
    6250:	a9440804 	ldp	x4, x2, [x0, #64]
    6254:	b900041f 	str	wzr, [x0, #4]
    6258:	f9403019 	ldr	x25, [x0, #96]
    625c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6260:	f9000c1f 	str	xzr, [x0, #24]
    6264:	a9020fe4 	stp	x4, x3, [sp, #32]
    6268:	f9001be2 	str	x2, [sp, #48]
    626c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6270:	f900301f 	str	xzr, [x0, #96]
    6274:	6b15003f 	cmp	w1, w21
    6278:	540000e8 	b.hi	6294 <fwp_tape_scope_release+0xe4>  // b.pmore
    627c:	9343fca5 	asr	x5, x5, #3
    6280:	f9404e60 	ldr	x0, [x19, #152]
    6284:	9b187ca5 	mul	x5, x5, x24
    6288:	eb0000bf 	cmp	x5, x0
    628c:	5400004a 	b.ge	6294 <fwp_tape_scope_release+0xe4>  // b.tcont
    6290:	f9004e65 	str	x5, [x19, #152]
    6294:	aa1703e0 	mov	x0, x23
    6298:	b5fffbf9 	cbnz	x25, 6214 <fwp_tape_scope_release+0x64>
    629c:	97fff6b5 	bl	3d70 <fwp_tape_buffers_release>
    62a0:	b9400285 	ldr	w5, [x20]
    62a4:	36fffc25 	tbz	w5, #31, 6228 <fwp_tape_scope_release+0x78>
    62a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    62ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    62b0:	f94043f9 	ldr	x25, [sp, #128]
    62b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    62b8:	f947f400 	ldr	x0, [x0, #4072]
    62bc:	f9401fe2 	ldr	x2, [sp, #56]
    62c0:	f9400001 	ldr	x1, [x0]
    62c4:	eb010042 	subs	x2, x2, x1
    62c8:	d2800001 	mov	x1, #0x0                   	// #0
    62cc:	540000a1 	b.ne	62e0 <fwp_tape_scope_release+0x130>  // b.any
    62d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    62d8:	910243ff 	add	sp, sp, #0x90
    62dc:	d65f03c0 	ret
    62e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    62e4:	a90763f7 	stp	x23, x24, [sp, #112]
    62e8:	f90043f9 	str	x25, [sp, #128]
    62ec:	97fff165 	bl	2880 <__stack_chk_fail@plt>

00000000000062f0 <fwp_drop4>:
    62f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62f4:	910003fd 	mov	x29, sp
    62f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    62fc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    6300:	911502d5 	add	x21, x22, #0x540
    6304:	a90153f3 	stp	x19, x20, [sp, #16]
    6308:	aa0003f3 	mov	x19, x0
    630c:	f949daa1 	ldr	x1, [x21, #5040]
    6310:	f949eea0 	ldr	x0, [x21, #5080]
    6314:	cb010261 	sub	x1, x19, x1
    6318:	eb00403f 	cmp	x1, x0, lsl #16
    631c:	54000382 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6320:	d350fc22 	lsr	x2, x1, #16
    6324:	f949fea3 	ldr	x3, [x21, #5112]
    6328:	8b020842 	add	x2, x2, x2, lsl #2
    632c:	d37df042 	lsl	x2, x2, #3
    6330:	8b020060 	add	x0, x3, x2
    6334:	f9401014 	ldr	x20, [x0, #32]
    6338:	b40002b4 	cbz	x20, 638c <fwp_drop4+0x9c>
    633c:	38626862 	ldrb	w2, [x3, x2]
    6340:	7100085f 	cmp	w2, #0x2
    6344:	540002c0 	b.eq	639c <fwp_drop4+0xac>  // b.none
    6348:	7100045f 	cmp	w2, #0x1
    634c:	54000201 	b.ne	638c <fwp_drop4+0x9c>  // b.any
    6350:	29430002 	ldp	w2, w0, [x0, #24]
    6354:	92403c21 	and	x1, x1, #0xffff
    6358:	9b027c21 	mul	x1, x1, x2
    635c:	d360fc21 	lsr	x1, x1, #32
    6360:	eb00003f 	cmp	x1, x0
    6364:	54000142 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6368:	8b010294 	add	x20, x20, x1
    636c:	39400280 	ldrb	w0, [x20]
    6370:	340000e0 	cbz	w0, 638c <fwp_drop4+0x9c>
    6374:	7100041f 	cmp	w0, #0x1
    6378:	540001e0 	b.eq	63b4 <fwp_drop4+0xc4>  // b.none
    637c:	7103fc1f 	cmp	w0, #0xff
    6380:	540007c0 	b.eq	6478 <fwp_drop4+0x188>  // b.none
    6384:	51000400 	sub	w0, w0, #0x1
    6388:	39000280 	strb	w0, [x20]
    638c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6390:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6394:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6398:	d65f03c0 	ret
    639c:	72003c3f 	tst	w1, #0xffff
    63a0:	54fffe60 	b.eq	636c <fwp_drop4+0x7c>  // b.none
    63a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63b0:	d65f03c0 	ret
    63b4:	911502c2 	add	x2, x22, #0x540
    63b8:	f9400660 	ldr	x0, [x19, #8]
    63bc:	f949d841 	ldr	x1, [x2, #5040]
    63c0:	f949ec42 	ldr	x2, [x2, #5080]
    63c4:	cb010001 	sub	x1, x0, x1
    63c8:	eb02403f 	cmp	x1, x2, lsl #16
    63cc:	54000362 	b.cs	6438 <fwp_drop4+0x148>  // b.hs, b.nlast
    63d0:	d350fc22 	lsr	x2, x1, #16
    63d4:	8b020842 	add	x2, x2, x2, lsl #2
    63d8:	d37df042 	lsl	x2, x2, #3
    63dc:	8b020064 	add	x4, x3, x2
    63e0:	f9401094 	ldr	x20, [x4, #32]
    63e4:	b40002b4 	cbz	x20, 6438 <fwp_drop4+0x148>
    63e8:	38626862 	ldrb	w2, [x3, x2]
    63ec:	7100085f 	cmp	w2, #0x2
    63f0:	540003e0 	b.eq	646c <fwp_drop4+0x17c>  // b.none
    63f4:	7100045f 	cmp	w2, #0x1
    63f8:	54000201 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    63fc:	29430883 	ldp	w3, w2, [x4, #24]
    6400:	92403c21 	and	x1, x1, #0xffff
    6404:	9b037c21 	mul	x1, x1, x3
    6408:	d360fc21 	lsr	x1, x1, #32
    640c:	eb02003f 	cmp	x1, x2
    6410:	54000142 	b.cs	6438 <fwp_drop4+0x148>  // b.hs, b.nlast
    6414:	8b010294 	add	x20, x20, x1
    6418:	39400281 	ldrb	w1, [x20]
    641c:	340000e1 	cbz	w1, 6438 <fwp_drop4+0x148>
    6420:	7100043f 	cmp	w1, #0x1
    6424:	54000200 	b.eq	6464 <fwp_drop4+0x174>  // b.none
    6428:	7103fc3f 	cmp	w1, #0xff
    642c:	54000640 	b.eq	64f4 <fwp_drop4+0x204>  // b.none
    6430:	51000421 	sub	w1, w1, #0x1
    6434:	39000281 	strb	w1, [x20]
    6438:	f9400a74 	ldr	x20, [x19, #16]
    643c:	aa1303e0 	mov	x0, x19
    6440:	97fffce5 	bl	57d4 <fwp_rc_free_arr>
    6444:	911502c0 	add	x0, x22, #0x540
    6448:	f949d801 	ldr	x1, [x0, #5040]
    644c:	f949ec00 	ldr	x0, [x0, #5080]
    6450:	cb010281 	sub	x1, x20, x1
    6454:	eb00403f 	cmp	x1, x0, lsl #16
    6458:	54fff9a2 	b.cs	638c <fwp_drop4+0x9c>  // b.hs, b.nlast
    645c:	aa1403f3 	mov	x19, x20
    6460:	17ffffb0 	b	6320 <fwp_drop4+0x30>
    6464:	97fffcdc 	bl	57d4 <fwp_rc_free_arr>
    6468:	17fffff4 	b	6438 <fwp_drop4+0x148>
    646c:	72003c3f 	tst	w1, #0xffff
    6470:	54fffe41 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    6474:	17ffffe9 	b	6418 <fwp_drop4+0x128>
    6478:	ca544681 	eor	x1, x20, x20, lsr #17
    647c:	911502c0 	add	x0, x22, #0x540
    6480:	ca412421 	eor	x1, x1, x1, lsr #9
    6484:	92401c21 	and	x1, x1, #0xff
    6488:	910a2422 	add	x2, x1, #0x289
    648c:	8b010c01 	add	x1, x0, x1, lsl #3
    6490:	8b020c02 	add	x2, x0, x2, lsl #3
    6494:	f94a2420 	ldr	x0, [x1, #5192]
    6498:	b50000a0 	cbnz	x0, 64ac <fwp_drop4+0x1bc>
    649c:	14000013 	b	64e8 <fwp_drop4+0x1f8>
    64a0:	91004002 	add	x2, x0, #0x10
    64a4:	f9400800 	ldr	x0, [x0, #16]
    64a8:	b4000200 	cbz	x0, 64e8 <fwp_drop4+0x1f8>
    64ac:	f9400001 	ldr	x1, [x0]
    64b0:	eb14003f 	cmp	x1, x20
    64b4:	54ffff61 	b.ne	64a0 <fwp_drop4+0x1b0>  // b.any
    64b8:	f9400041 	ldr	x1, [x2]
    64bc:	f9400420 	ldr	x0, [x1, #8]
    64c0:	d1000400 	sub	x0, x0, #0x1
    64c4:	f9000420 	str	x0, [x1, #8]
    64c8:	f103f81f 	cmp	x0, #0xfe
    64cc:	54fff601 	b.ne	638c <fwp_drop4+0x9c>  // b.any
    64d0:	39400280 	ldrb	w0, [x20]
    64d4:	7103fc1f 	cmp	w0, #0xff
    64d8:	54000460 	b.eq	6564 <fwp_drop4+0x274>  // b.none
    64dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64e0:	39000280 	strb	w0, [x20]
    64e4:	17ffffaa 	b	638c <fwp_drop4+0x9c>
    64e8:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    64ec:	91344000 	add	x0, x0, #0xd10
    64f0:	97fff668 	bl	3e90 <fwp_trap>
    64f4:	ca544680 	eor	x0, x20, x20, lsr #17
    64f8:	911502c1 	add	x1, x22, #0x540
    64fc:	ca402400 	eor	x0, x0, x0, lsr #9
    6500:	92401c00 	and	x0, x0, #0xff
    6504:	910a2402 	add	x2, x0, #0x289
    6508:	8b000c20 	add	x0, x1, x0, lsl #3
    650c:	8b020c22 	add	x2, x1, x2, lsl #3
    6510:	f94a2400 	ldr	x0, [x0, #5192]
    6514:	b50000a0 	cbnz	x0, 6528 <fwp_drop4+0x238>
    6518:	17fffff4 	b	64e8 <fwp_drop4+0x1f8>
    651c:	91004002 	add	x2, x0, #0x10
    6520:	f9400800 	ldr	x0, [x0, #16]
    6524:	b4fffe20 	cbz	x0, 64e8 <fwp_drop4+0x1f8>
    6528:	f9400001 	ldr	x1, [x0]
    652c:	eb14003f 	cmp	x1, x20
    6530:	54ffff61 	b.ne	651c <fwp_drop4+0x22c>  // b.any
    6534:	f9400041 	ldr	x1, [x2]
    6538:	f9400420 	ldr	x0, [x1, #8]
    653c:	d1000400 	sub	x0, x0, #0x1
    6540:	f9000420 	str	x0, [x1, #8]
    6544:	f103f81f 	cmp	x0, #0xfe
    6548:	54fff781 	b.ne	6438 <fwp_drop4+0x148>  // b.any
    654c:	39400280 	ldrb	w0, [x20]
    6550:	7103fc1f 	cmp	w0, #0xff
    6554:	540000e0 	b.eq	6570 <fwp_drop4+0x280>  // b.none
    6558:	12800020 	mov	w0, #0xfffffffe            	// #-2
    655c:	39000280 	strb	w0, [x20]
    6560:	17ffffb6 	b	6438 <fwp_drop4+0x148>
    6564:	aa1403e0 	mov	x0, x20
    6568:	97fff66a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    656c:	17ffffdc 	b	64dc <fwp_drop4+0x1ec>
    6570:	aa1403e0 	mov	x0, x20
    6574:	97fff667 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6578:	17fffff8 	b	6558 <fwp_drop4+0x268>
    657c:	d503201f 	nop

0000000000006580 <fwp_arg_drop37>:
    6580:	7100003f 	cmp	w1, #0x0
    6584:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6588:	54000041 	b.ne	6590 <fwp_arg_drop37+0x10>  // b.any
    658c:	d65f03c0 	ret
    6590:	f9400000 	ldr	x0, [x0]
    6594:	17ffff57 	b	62f0 <fwp_drop4>
    6598:	d503201f 	nop
    659c:	d503201f 	nop

00000000000065a0 <fwp_task_dispose>:
    65a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	f9000bf3 	str	x19, [sp, #16]
    65ac:	aa0003f3 	mov	x19, x0
    65b0:	39414000 	ldrb	w0, [x0, #80]
    65b4:	36000720 	tbz	w0, #0, 6698 <fwp_task_dispose+0xf8>
    65b8:	f9400a60 	ldr	x0, [x19, #16]
    65bc:	b50006e0 	cbnz	x0, 6698 <fwp_task_dispose+0xf8>
    65c0:	a9478660 	ldp	x0, x1, [x19, #120]
    65c4:	39014e7f 	strb	wzr, [x19, #83]
    65c8:	f9003e7f 	str	xzr, [x19, #120]
    65cc:	f100003f 	cmp	x1, #0x0
    65d0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65d4:	54000040 	b.eq	65dc <fwp_task_dispose+0x3c>  // b.none
    65d8:	d63f0020 	blr	x1
    65dc:	f9405660 	ldr	x0, [x19, #168]
    65e0:	97fff6e8 	bl	4180 <fwp_mem_free>
    65e4:	f900567f 	str	xzr, [x19, #168]
    65e8:	b9405e60 	ldr	w0, [x19, #92]
    65ec:	7100041f 	cmp	w0, #0x1
    65f0:	54000420 	b.eq	6674 <fwp_task_dispose+0xd4>  // b.none
    65f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    65f8:	91150042 	add	x2, x2, #0x540
    65fc:	f949d840 	ldr	x0, [x2, #5040]
    6600:	f949ec41 	ldr	x1, [x2, #5080]
    6604:	cb000260 	sub	x0, x19, x0
    6608:	eb01401f 	cmp	x0, x1, lsl #16
    660c:	540002e2 	b.cs	6668 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6610:	d350fc01 	lsr	x1, x0, #16
    6614:	f949fc44 	ldr	x4, [x2, #5112]
    6618:	8b010821 	add	x1, x1, x1, lsl #2
    661c:	d37df021 	lsl	x1, x1, #3
    6620:	8b010083 	add	x3, x4, x1
    6624:	f9401062 	ldr	x2, [x3, #32]
    6628:	b4000202 	cbz	x2, 6668 <fwp_task_dispose+0xc8>
    662c:	38616881 	ldrb	w1, [x4, x1]
    6630:	7100083f 	cmp	w1, #0x2
    6634:	54000280 	b.eq	6684 <fwp_task_dispose+0xe4>  // b.none
    6638:	7100043f 	cmp	w1, #0x1
    663c:	54000161 	b.ne	6668 <fwp_task_dispose+0xc8>  // b.any
    6640:	29430464 	ldp	w4, w1, [x3, #24]
    6644:	92403c00 	and	x0, x0, #0xffff
    6648:	9b047c00 	mul	x0, x0, x4
    664c:	d360fc00 	lsr	x0, x0, #32
    6650:	eb01001f 	cmp	x0, x1
    6654:	540000a2 	b.cs	6668 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6658:	8b000042 	add	x2, x2, x0
    665c:	39400040 	ldrb	w0, [x2]
    6660:	7100041f 	cmp	w0, #0x1
    6664:	54000080 	b.eq	6674 <fwp_task_dispose+0xd4>  // b.none
    6668:	f9400bf3 	ldr	x19, [sp, #16]
    666c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6670:	d65f03c0 	ret
    6674:	aa1303e0 	mov	x0, x19
    6678:	f9400bf3 	ldr	x19, [sp, #16]
    667c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6680:	17fff6c0 	b	4180 <fwp_mem_free>
    6684:	72003c1f 	tst	w0, #0xffff
    6688:	54fffea0 	b.eq	665c <fwp_task_dispose+0xbc>  // b.none
    668c:	f9400bf3 	ldr	x19, [sp, #16]
    6690:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6694:	d65f03c0 	ret
    6698:	97fff08e 	bl	28d0 <abort@plt>
    669c:	d503201f 	nop

00000000000066a0 <fwp_free_zombie>:
    66a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66a4:	910003fd 	mov	x29, sp
    66a8:	a90153f3 	stp	x19, x20, [sp, #16]
    66ac:	d00000d4 	adrp	x20, 20000 <__data_start>
    66b0:	9100c281 	add	x1, x20, #0x30
    66b4:	f9405033 	ldr	x19, [x1, #160]
    66b8:	b4000333 	cbz	x19, 671c <fwp_free_zombie+0x7c>
    66bc:	f9400820 	ldr	x0, [x1, #16]
    66c0:	eb00027f 	cmp	x19, x0
    66c4:	540002c0 	b.eq	671c <fwp_free_zombie+0x7c>  // b.none
    66c8:	b940a822 	ldr	w2, [x1, #168]
    66cc:	f9400a60 	ldr	x0, [x19, #16]
    66d0:	7100fc5f 	cmp	w2, #0x3f
    66d4:	5400078c 	b.gt	67c4 <fwp_free_zombie+0x124>
    66d8:	9102c023 	add	x3, x1, #0xb0
    66dc:	11000444 	add	w4, w2, #0x1
    66e0:	b900a824 	str	w4, [x1, #168]
    66e4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66e8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66ec:	a9530261 	ldp	x1, x0, [x19, #304]
    66f0:	b4000741 	cbz	x1, 67d8 <fwp_free_zombie+0x138>
    66f4:	f9009c20 	str	x0, [x1, #312]
    66f8:	b4000040 	cbz	x0, 6700 <fwp_free_zombie+0x60>
    66fc:	f9009801 	str	x1, [x0, #304]
    6700:	9100c294 	add	x20, x20, #0x30
    6704:	b9405e60 	ldr	w0, [x19, #92]
    6708:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    670c:	f900529f 	str	xzr, [x20, #160]
    6710:	34000140 	cbz	w0, 6738 <fwp_free_zombie+0x98>
    6714:	7100041f 	cmp	w0, #0x1
    6718:	54000080 	b.eq	6728 <fwp_free_zombie+0x88>  // b.none
    671c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6720:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6724:	d65f03c0 	ret
    6728:	aa1303e0 	mov	x0, x19
    672c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6730:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6734:	17ffff9b 	b	65a0 <fwp_task_dispose>
    6738:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    673c:	91150082 	add	x2, x4, #0x540
    6740:	f949d841 	ldr	x1, [x2, #5040]
    6744:	f949ec40 	ldr	x0, [x2, #5080]
    6748:	cb010261 	sub	x1, x19, x1
    674c:	eb00403f 	cmp	x1, x0, lsl #16
    6750:	54fffe62 	b.cs	671c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6754:	d350fc20 	lsr	x0, x1, #16
    6758:	f949fc43 	ldr	x3, [x2, #5112]
    675c:	8b000800 	add	x0, x0, x0, lsl #2
    6760:	d37df000 	lsl	x0, x0, #3
    6764:	8b000062 	add	x2, x3, x0
    6768:	f9401054 	ldr	x20, [x2, #32]
    676c:	b4fffd94 	cbz	x20, 671c <fwp_free_zombie+0x7c>
    6770:	38606860 	ldrb	w0, [x3, x0]
    6774:	7100081f 	cmp	w0, #0x2
    6778:	54000360 	b.eq	67e4 <fwp_free_zombie+0x144>  // b.none
    677c:	7100041f 	cmp	w0, #0x1
    6780:	54fffce1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    6784:	29430043 	ldp	w3, w0, [x2, #24]
    6788:	92403c21 	and	x1, x1, #0xffff
    678c:	9b037c21 	mul	x1, x1, x3
    6790:	d360fc21 	lsr	x1, x1, #32
    6794:	eb00003f 	cmp	x1, x0
    6798:	54fffc22 	b.cs	671c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    679c:	8b010294 	add	x20, x20, x1
    67a0:	39400280 	ldrb	w0, [x20]
    67a4:	34fffbc0 	cbz	w0, 671c <fwp_free_zombie+0x7c>
    67a8:	7100041f 	cmp	w0, #0x1
    67ac:	54fffbe0 	b.eq	6728 <fwp_free_zombie+0x88>  // b.none
    67b0:	7103fc1f 	cmp	w0, #0xff
    67b4:	540001e0 	b.eq	67f0 <fwp_free_zombie+0x150>  // b.none
    67b8:	51000400 	sub	w0, w0, #0x1
    67bc:	39000280 	strb	w0, [x20]
    67c0:	17ffffd7 	b	671c <fwp_free_zombie+0x7c>
    67c4:	f9400e61 	ldr	x1, [x19, #24]
    67c8:	97fff076 	bl	29a0 <munmap@plt>
    67cc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67d0:	a9530261 	ldp	x1, x0, [x19, #304]
    67d4:	b5fff901 	cbnz	x1, 66f4 <fwp_free_zombie+0x54>
    67d8:	9100c282 	add	x2, x20, #0x30
    67dc:	f9015840 	str	x0, [x2, #688]
    67e0:	17ffffc6 	b	66f8 <fwp_free_zombie+0x58>
    67e4:	72003c3f 	tst	w1, #0xffff
    67e8:	54fff9a1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    67ec:	17ffffed 	b	67a0 <fwp_free_zombie+0x100>
    67f0:	ca544680 	eor	x0, x20, x20, lsr #17
    67f4:	91150084 	add	x4, x4, #0x540
    67f8:	ca402400 	eor	x0, x0, x0, lsr #9
    67fc:	92401c00 	and	x0, x0, #0xff
    6800:	910a2402 	add	x2, x0, #0x289
    6804:	8b000c80 	add	x0, x4, x0, lsl #3
    6808:	8b020c82 	add	x2, x4, x2, lsl #3
    680c:	f94a2400 	ldr	x0, [x0, #5192]
    6810:	b50000a0 	cbnz	x0, 6824 <fwp_free_zombie+0x184>
    6814:	14000013 	b	6860 <fwp_free_zombie+0x1c0>
    6818:	91004002 	add	x2, x0, #0x10
    681c:	f9400800 	ldr	x0, [x0, #16]
    6820:	b4000200 	cbz	x0, 6860 <fwp_free_zombie+0x1c0>
    6824:	f9400001 	ldr	x1, [x0]
    6828:	eb14003f 	cmp	x1, x20
    682c:	54ffff61 	b.ne	6818 <fwp_free_zombie+0x178>  // b.any
    6830:	f9400041 	ldr	x1, [x2]
    6834:	f9400420 	ldr	x0, [x1, #8]
    6838:	d1000400 	sub	x0, x0, #0x1
    683c:	f9000420 	str	x0, [x1, #8]
    6840:	f103f81f 	cmp	x0, #0xfe
    6844:	54fff6c1 	b.ne	671c <fwp_free_zombie+0x7c>  // b.any
    6848:	39400280 	ldrb	w0, [x20]
    684c:	7103fc1f 	cmp	w0, #0xff
    6850:	540000e0 	b.eq	686c <fwp_free_zombie+0x1cc>  // b.none
    6854:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6858:	39000280 	strb	w0, [x20]
    685c:	17ffffb0 	b	671c <fwp_free_zombie+0x7c>
    6860:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    6864:	91344000 	add	x0, x0, #0xd10
    6868:	97fff58a 	bl	3e90 <fwp_trap>
    686c:	aa1403e0 	mov	x0, x20
    6870:	97fff5a8 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6874:	17fffff8 	b	6854 <fwp_free_zombie+0x1b4>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <fwp_block>:
    6880:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6884:	910003fd 	mov	x29, sp
    6888:	a90153f3 	stp	x19, x20, [sp, #16]
    688c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6890:	9100c274 	add	x20, x19, #0x30
    6894:	f9401a82 	ldr	x2, [x20, #48]
    6898:	b4000642 	cbz	x2, 6960 <fwp_block+0xe0>
    689c:	9100c261 	add	x1, x19, #0x30
    68a0:	f9408040 	ldr	x0, [x2, #256]
    68a4:	f9001820 	str	x0, [x1, #48]
    68a8:	b40006a0 	cbz	x0, 697c <fwp_block+0xfc>
    68ac:	d503201f 	nop
    68b0:	9100c263 	add	x3, x19, #0x30
    68b4:	3901505f 	strb	wzr, [x2, #84]
    68b8:	f9400864 	ldr	x4, [x3, #16]
    68bc:	eb02009f 	cmp	x4, x2
    68c0:	54000440 	b.eq	6948 <fwp_block+0xc8>  // b.none
    68c4:	f9415c65 	ldr	x5, [x3, #696]
    68c8:	f9000862 	str	x2, [x3, #16]
    68cc:	f9400441 	ldr	x1, [x2, #8]
    68d0:	f9004885 	str	x5, [x4, #144]
    68d4:	f9416065 	ldr	x5, [x3, #704]
    68d8:	f9004c85 	str	x5, [x4, #152]
    68dc:	f9416465 	ldr	x5, [x3, #712]
    68e0:	f9005085 	str	x5, [x4, #160]
    68e4:	f9416865 	ldr	x5, [x3, #720]
    68e8:	f9005485 	str	x5, [x4, #168]
    68ec:	f9416c65 	ldr	x5, [x3, #728]
    68f0:	f9005885 	str	x5, [x4, #176]
    68f4:	f9417065 	ldr	x5, [x3, #736]
    68f8:	f9005c85 	str	x5, [x4, #184]
    68fc:	f9417465 	ldr	x5, [x3, #744]
    6900:	f9006085 	str	x5, [x4, #192]
    6904:	f9400480 	ldr	x0, [x4, #8]
    6908:	f9404844 	ldr	x4, [x2, #144]
    690c:	f9015c64 	str	x4, [x3, #696]
    6910:	f9404c44 	ldr	x4, [x2, #152]
    6914:	f9016064 	str	x4, [x3, #704]
    6918:	f9405044 	ldr	x4, [x2, #160]
    691c:	f9016464 	str	x4, [x3, #712]
    6920:	f9405444 	ldr	x4, [x2, #168]
    6924:	f9016864 	str	x4, [x3, #720]
    6928:	f9405844 	ldr	x4, [x2, #176]
    692c:	f9016c64 	str	x4, [x3, #728]
    6930:	a94b8844 	ldp	x4, x2, [x2, #184]
    6934:	f9017064 	str	x4, [x3, #736]
    6938:	f9017462 	str	x2, [x3, #744]
    693c:	97ffefe9 	bl	28e0 <swapcontext@plt>
    6940:	97ffff58 	bl	66a0 <fwp_free_zombie>
    6944:	d503201f 	nop
    6948:	9100c260 	add	x0, x19, #0x30
    694c:	b942f000 	ldr	w0, [x0, #752]
    6950:	340001a0 	cbz	w0, 6984 <fwp_block+0x104>
    6954:	a94153f3 	ldp	x19, x20, [sp, #16]
    6958:	a8c27bfd 	ldp	x29, x30, [sp], #32
    695c:	d65f03c0 	ret
    6960:	97fff794 	bl	47b0 <fwp_poll_events>
    6964:	f9401a82 	ldr	x2, [x20, #48]
    6968:	b4ffffc2 	cbz	x2, 6960 <fwp_block+0xe0>
    696c:	9100c261 	add	x1, x19, #0x30
    6970:	f9408040 	ldr	x0, [x2, #256]
    6974:	f9001820 	str	x0, [x1, #48]
    6978:	b5fff9c0 	cbnz	x0, 68b0 <fwp_block+0x30>
    697c:	f900143f 	str	xzr, [x1, #40]
    6980:	17ffffcc 	b	68b0 <fwp_block+0x30>
    6984:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    6988:	913ea000 	add	x0, x0, #0xfa8
    698c:	97fff021 	bl	2a10 <getenv@plt>
    6990:	5284e202 	mov	w2, #0x2710                	// #10000
    6994:	b4000060 	cbz	x0, 69a0 <fwp_block+0x120>
    6998:	39400001 	ldrb	w1, [x0]
    699c:	350000c1 	cbnz	w1, 69b4 <fwp_block+0x134>
    69a0:	9100c273 	add	x19, x19, #0x30
    69a4:	b902f262 	str	w2, [x19, #752]
    69a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69b0:	d65f03c0 	ret
    69b4:	52800142 	mov	w2, #0xa                   	// #10
    69b8:	d2800001 	mov	x1, #0x0                   	// #0
    69bc:	97ffef65 	bl	2750 <strtoll@plt>
    69c0:	d1000403 	sub	x3, x0, #0x1
    69c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69c8:	eb02007f 	cmp	x3, x2
    69cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69d4:	17fffff3 	b	69a0 <fwp_block+0x120>
    69d8:	d503201f 	nop
    69dc:	d503201f 	nop

00000000000069e0 <fwp_drop10>:
    69e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69e4:	910003fd 	mov	x29, sp
    69e8:	a90153f3 	stp	x19, x20, [sp, #16]
    69ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    69f0:	f90013f5 	str	x21, [sp, #32]
    69f4:	91150275 	add	x21, x19, #0x540
    69f8:	f949daa1 	ldr	x1, [x21, #5040]
    69fc:	f949eea2 	ldr	x2, [x21, #5080]
    6a00:	cb010001 	sub	x1, x0, x1
    6a04:	eb02403f 	cmp	x1, x2, lsl #16
    6a08:	54000382 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a0c:	d350fc22 	lsr	x2, x1, #16
    6a10:	f949fea3 	ldr	x3, [x21, #5112]
    6a14:	8b020842 	add	x2, x2, x2, lsl #2
    6a18:	d37df042 	lsl	x2, x2, #3
    6a1c:	8b020064 	add	x4, x3, x2
    6a20:	f9401094 	ldr	x20, [x4, #32]
    6a24:	b40002b4 	cbz	x20, 6a78 <fwp_drop10+0x98>
    6a28:	38626862 	ldrb	w2, [x3, x2]
    6a2c:	7100085f 	cmp	w2, #0x2
    6a30:	540007a0 	b.eq	6b24 <fwp_drop10+0x144>  // b.none
    6a34:	7100045f 	cmp	w2, #0x1
    6a38:	54000201 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6a3c:	29430885 	ldp	w5, w2, [x4, #24]
    6a40:	92403c21 	and	x1, x1, #0xffff
    6a44:	9b057c21 	mul	x1, x1, x5
    6a48:	d360fc21 	lsr	x1, x1, #32
    6a4c:	eb02003f 	cmp	x1, x2
    6a50:	54000142 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a54:	8b010294 	add	x20, x20, x1
    6a58:	39400281 	ldrb	w1, [x20]
    6a5c:	340000e1 	cbz	w1, 6a78 <fwp_drop10+0x98>
    6a60:	7100043f 	cmp	w1, #0x1
    6a64:	54000120 	b.eq	6a88 <fwp_drop10+0xa8>  // b.none
    6a68:	7103fc3f 	cmp	w1, #0xff
    6a6c:	540007c0 	b.eq	6b64 <fwp_drop10+0x184>  // b.none
    6a70:	51000421 	sub	w1, w1, #0x1
    6a74:	39000281 	strb	w1, [x20]
    6a78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a7c:	f94013f5 	ldr	x21, [sp, #32]
    6a80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a84:	d65f03c0 	ret
    6a88:	f9400001 	ldr	x1, [x0]
    6a8c:	b7f80581 	tbnz	x1, #63, 6b3c <fwp_drop10+0x15c>
    6a90:	91150273 	add	x19, x19, #0x540
    6a94:	f949da61 	ldr	x1, [x19, #5040]
    6a98:	f949ee62 	ldr	x2, [x19, #5080]
    6a9c:	cb010001 	sub	x1, x0, x1
    6aa0:	eb02403f 	cmp	x1, x2, lsl #16
    6aa4:	54fffea2 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6aa8:	d350fc22 	lsr	x2, x1, #16
    6aac:	8b020842 	add	x2, x2, x2, lsl #2
    6ab0:	d37df042 	lsl	x2, x2, #3
    6ab4:	8b020065 	add	x5, x3, x2
    6ab8:	f94010a4 	ldr	x4, [x5, #32]
    6abc:	b4fffde4 	cbz	x4, 6a78 <fwp_drop10+0x98>
    6ac0:	38626862 	ldrb	w2, [x3, x2]
    6ac4:	7100085f 	cmp	w2, #0x2
    6ac8:	54000220 	b.eq	6b0c <fwp_drop10+0x12c>  // b.none
    6acc:	7100045f 	cmp	w2, #0x1
    6ad0:	54fffd41 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6ad4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ad8:	92403c21 	and	x1, x1, #0xffff
    6adc:	9b037c21 	mul	x1, x1, x3
    6ae0:	d360fc21 	lsr	x1, x1, #32
    6ae4:	eb02003f 	cmp	x1, x2
    6ae8:	54fffc82 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6aec:	8b010084 	add	x4, x4, x1
    6af0:	39400081 	ldrb	w1, [x4]
    6af4:	7100043f 	cmp	w1, #0x1
    6af8:	54fffc01 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	f94013f5 	ldr	x21, [sp, #32]
    6b04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b08:	17fff59e 	b	4180 <fwp_mem_free>
    6b0c:	72003c3f 	tst	w1, #0xffff
    6b10:	54ffff00 	b.eq	6af0 <fwp_drop10+0x110>  // b.none
    6b14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b18:	f94013f5 	ldr	x21, [sp, #32]
    6b1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b20:	d65f03c0 	ret
    6b24:	72003c3f 	tst	w1, #0xffff
    6b28:	54fff980 	b.eq	6a58 <fwp_drop10+0x78>  // b.none
    6b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b30:	f94013f5 	ldr	x21, [sp, #32]
    6b34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b38:	d65f03c0 	ret
    6b3c:	f9400414 	ldr	x20, [x0, #8]
    6b40:	97fffb25 	bl	57d4 <fwp_rc_free_arr>
    6b44:	91150260 	add	x0, x19, #0x540
    6b48:	f949d801 	ldr	x1, [x0, #5040]
    6b4c:	f949ec00 	ldr	x0, [x0, #5080]
    6b50:	cb010281 	sub	x1, x20, x1
    6b54:	eb00403f 	cmp	x1, x0, lsl #16
    6b58:	54fff902 	b.cs	6a78 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b5c:	aa1403e0 	mov	x0, x20
    6b60:	17ffffab 	b	6a0c <fwp_drop10+0x2c>
    6b64:	ca544680 	eor	x0, x20, x20, lsr #17
    6b68:	91150273 	add	x19, x19, #0x540
    6b6c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b70:	92401c00 	and	x0, x0, #0xff
    6b74:	910a2402 	add	x2, x0, #0x289
    6b78:	8b000e60 	add	x0, x19, x0, lsl #3
    6b7c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b80:	f94a2400 	ldr	x0, [x0, #5192]
    6b84:	b50000a0 	cbnz	x0, 6b98 <fwp_drop10+0x1b8>
    6b88:	14000013 	b	6bd4 <fwp_drop10+0x1f4>
    6b8c:	91004002 	add	x2, x0, #0x10
    6b90:	f9400800 	ldr	x0, [x0, #16]
    6b94:	b4000200 	cbz	x0, 6bd4 <fwp_drop10+0x1f4>
    6b98:	f9400001 	ldr	x1, [x0]
    6b9c:	eb14003f 	cmp	x1, x20
    6ba0:	54ffff61 	b.ne	6b8c <fwp_drop10+0x1ac>  // b.any
    6ba4:	f9400041 	ldr	x1, [x2]
    6ba8:	f9400420 	ldr	x0, [x1, #8]
    6bac:	d1000400 	sub	x0, x0, #0x1
    6bb0:	f9000420 	str	x0, [x1, #8]
    6bb4:	f103f81f 	cmp	x0, #0xfe
    6bb8:	54fff601 	b.ne	6a78 <fwp_drop10+0x98>  // b.any
    6bbc:	39400280 	ldrb	w0, [x20]
    6bc0:	7103fc1f 	cmp	w0, #0xff
    6bc4:	540000e0 	b.eq	6be0 <fwp_drop10+0x200>  // b.none
    6bc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bcc:	39000280 	strb	w0, [x20]
    6bd0:	17ffffaa 	b	6a78 <fwp_drop10+0x98>
    6bd4:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    6bd8:	91344000 	add	x0, x0, #0xd10
    6bdc:	97fff4ad 	bl	3e90 <fwp_trap>
    6be0:	aa1403e0 	mov	x0, x20
    6be4:	97fff4cb 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6be8:	17fffff8 	b	6bc8 <fwp_drop10+0x1e8>
    6bec:	d503201f 	nop

0000000000006bf0 <fwp_caps173>:
    6bf0:	34000041 	cbz	w1, 6bf8 <fwp_caps173+0x8>
    6bf4:	d65f03c0 	ret
    6bf8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    6bfc:	91150063 	add	x3, x3, #0x540
    6c00:	f949d861 	ldr	x1, [x3, #5040]
    6c04:	f949ec62 	ldr	x2, [x3, #5080]
    6c08:	cb010001 	sub	x1, x0, x1
    6c0c:	eb02403f 	cmp	x1, x2, lsl #16
    6c10:	54ffff22 	b.cs	6bf4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c14:	d350fc22 	lsr	x2, x1, #16
    6c18:	f949fc65 	ldr	x5, [x3, #5112]
    6c1c:	8b020842 	add	x2, x2, x2, lsl #2
    6c20:	d37df042 	lsl	x2, x2, #3
    6c24:	8b0200a4 	add	x4, x5, x2
    6c28:	f9401083 	ldr	x3, [x4, #32]
    6c2c:	b4fffe43 	cbz	x3, 6bf4 <fwp_caps173+0x4>
    6c30:	386268a2 	ldrb	w2, [x5, x2]
    6c34:	7100085f 	cmp	w2, #0x2
    6c38:	540001c0 	b.eq	6c70 <fwp_caps173+0x80>  // b.none
    6c3c:	7100045f 	cmp	w2, #0x1
    6c40:	54fffda1 	b.ne	6bf4 <fwp_caps173+0x4>  // b.any
    6c44:	29430885 	ldp	w5, w2, [x4, #24]
    6c48:	92403c21 	and	x1, x1, #0xffff
    6c4c:	9b057c21 	mul	x1, x1, x5
    6c50:	d360fc21 	lsr	x1, x1, #32
    6c54:	eb02003f 	cmp	x1, x2
    6c58:	54fffce2 	b.cs	6bf4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c5c:	8b010063 	add	x3, x3, x1
    6c60:	39400061 	ldrb	w1, [x3]
    6c64:	7100043f 	cmp	w1, #0x1
    6c68:	54fffc61 	b.ne	6bf4 <fwp_caps173+0x4>  // b.any
    6c6c:	17fff545 	b	4180 <fwp_mem_free>
    6c70:	72003c3f 	tst	w1, #0xffff
    6c74:	54ffff60 	b.eq	6c60 <fwp_caps173+0x70>  // b.none
    6c78:	d65f03c0 	ret
    6c7c:	d503201f 	nop

0000000000006c80 <f37>:
    6c80:	d10203ff 	sub	sp, sp, #0x80
    6c84:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6c88:	f947f421 	ldr	x1, [x1, #4072]
    6c8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6c90:	910083fd 	add	x29, sp, #0x20
    6c94:	a9045bf5 	stp	x21, x22, [sp, #64]
    6c98:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xca0>
    6c9c:	911502a3 	add	x3, x21, #0x540
    6ca0:	a90353f3 	stp	x19, x20, [sp, #48]
    6ca4:	aa0003f6 	mov	x22, x0
    6ca8:	a90563f7 	stp	x23, x24, [sp, #80]
    6cac:	a9066bf9 	stp	x25, x26, [sp, #96]
    6cb0:	f949ec62 	ldr	x2, [x3, #5080]
    6cb4:	f9400024 	ldr	x4, [x1]
    6cb8:	f9000fe4 	str	x4, [sp, #24]
    6cbc:	d2800004 	mov	x4, #0x0                   	// #0
    6cc0:	f949d861 	ldr	x1, [x3, #5040]
    6cc4:	d370bc42 	lsl	x2, x2, #16
    6cc8:	b4001820 	cbz	x0, 6fcc <f37+0x34c>
    6ccc:	f9400817 	ldr	x23, [x0, #16]
    6cd0:	cb0102e1 	sub	x1, x23, x1
    6cd4:	eb02003f 	cmp	x1, x2
    6cd8:	54000362 	b.cs	6d44 <f37+0xc4>  // b.hs, b.nlast
    6cdc:	f949fc60 	ldr	x0, [x3, #5112]
    6ce0:	d350fc22 	lsr	x2, x1, #16
    6ce4:	8b020842 	add	x2, x2, x2, lsl #2
    6ce8:	8b020c02 	add	x2, x0, x2, lsl #3
    6cec:	f9401040 	ldr	x0, [x2, #32]
    6cf0:	b40002a0 	cbz	x0, 6d44 <f37+0xc4>
    6cf4:	39400043 	ldrb	w3, [x2]
    6cf8:	7100087f 	cmp	w3, #0x2
    6cfc:	54001560 	b.eq	6fa8 <f37+0x328>  // b.none
    6d00:	7100047f 	cmp	w3, #0x1
    6d04:	540001c1 	b.ne	6d3c <f37+0xbc>  // b.any
    6d08:	29430843 	ldp	w3, w2, [x2, #24]
    6d0c:	92403c21 	and	x1, x1, #0xffff
    6d10:	9b037c21 	mul	x1, x1, x3
    6d14:	d360fc21 	lsr	x1, x1, #32
    6d18:	eb02003f 	cmp	x1, x2
    6d1c:	54000102 	b.cs	6d3c <f37+0xbc>  // b.hs, b.nlast
    6d20:	8b010000 	add	x0, x0, x1
    6d24:	39400001 	ldrb	w1, [x0]
    6d28:	340000a1 	cbz	w1, 6d3c <f37+0xbc>
    6d2c:	7103f43f 	cmp	w1, #0xfd
    6d30:	54001808 	b.hi	7030 <f37+0x3b0>  // b.pmore
    6d34:	11000421 	add	w1, w1, #0x1
    6d38:	39000001 	strb	w1, [x0]
    6d3c:	d2800002 	mov	x2, #0x0                   	// #0
    6d40:	b40000f6 	cbz	x22, 6d5c <f37+0xdc>
    6d44:	aa1603e1 	mov	x1, x22
    6d48:	d2800002 	mov	x2, #0x0                   	// #0
    6d4c:	d503201f 	nop
    6d50:	f9400821 	ldr	x1, [x1, #16]
    6d54:	91000442 	add	x2, x2, #0x1
    6d58:	b5ffffc1 	cbnz	x1, 6d50 <f37+0xd0>
    6d5c:	b40013f7 	cbz	x23, 6fd8 <f37+0x358>
    6d60:	aa1703e1 	mov	x1, x23
    6d64:	d2800003 	mov	x3, #0x0                   	// #0
    6d68:	f9400821 	ldr	x1, [x1, #16]
    6d6c:	91000463 	add	x3, x3, #0x1
    6d70:	b5ffffc1 	cbnz	x1, 6d68 <f37+0xe8>
    6d74:	eb02007f 	cmp	x3, x2
    6d78:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6d7c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6d80:	eb00027f 	cmp	x19, x0
    6d84:	540010a8 	b.hi	6f98 <f37+0x318>  // b.pmore
    6d88:	d37ffa74 	lsl	x20, x19, #1
    6d8c:	52800041 	mov	w1, #0x2                   	// #2
    6d90:	91000680 	add	x0, x20, #0x1
    6d94:	d37df000 	lsl	x0, x0, #3
    6d98:	97fff7b6 	bl	4c70 <fwp_heap_alloc>
    6d9c:	aa0003f8 	mov	x24, x0
    6da0:	911502a1 	add	x1, x21, #0x540
    6da4:	aa0103e0 	mov	x0, x1
    6da8:	f9000314 	str	x20, [x24]
    6dac:	f949d821 	ldr	x1, [x1, #5040]
    6db0:	f949ec00 	ldr	x0, [x0, #5080]
    6db4:	cb010301 	sub	x1, x24, x1
    6db8:	eb00403f 	cmp	x1, x0, lsl #16
    6dbc:	54000342 	b.cs	6e24 <f37+0x1a4>  // b.hs, b.nlast
    6dc0:	911502a2 	add	x2, x21, #0x540
    6dc4:	d350fc20 	lsr	x0, x1, #16
    6dc8:	8b000800 	add	x0, x0, x0, lsl #2
    6dcc:	f949fc43 	ldr	x3, [x2, #5112]
    6dd0:	d37df002 	lsl	x2, x0, #3
    6dd4:	8b020060 	add	x0, x3, x2
    6dd8:	f9401014 	ldr	x20, [x0, #32]
    6ddc:	b4000254 	cbz	x20, 6e24 <f37+0x1a4>
    6de0:	38626862 	ldrb	w2, [x3, x2]
    6de4:	7100085f 	cmp	w2, #0x2
    6de8:	54000ec0 	b.eq	6fc0 <f37+0x340>  // b.none
    6dec:	7100045f 	cmp	w2, #0x1
    6df0:	540001a1 	b.ne	6e24 <f37+0x1a4>  // b.any
    6df4:	29430002 	ldp	w2, w0, [x0, #24]
    6df8:	92403c21 	and	x1, x1, #0xffff
    6dfc:	9b027c21 	mul	x1, x1, x2
    6e00:	d360fc21 	lsr	x1, x1, #32
    6e04:	eb00003f 	cmp	x1, x0
    6e08:	540000e2 	b.cs	6e24 <f37+0x1a4>  // b.hs, b.nlast
    6e0c:	8b010294 	add	x20, x20, x1
    6e10:	39400280 	ldrb	w0, [x20]
    6e14:	7103fc1f 	cmp	w0, #0xff
    6e18:	54001100 	b.eq	7038 <f37+0x3b8>  // b.none
    6e1c:	52800020 	mov	w0, #0x1                   	// #1
    6e20:	39000280 	strb	w0, [x20]
    6e24:	b4000253 	cbz	x19, 6e6c <f37+0x1ec>
    6e28:	8b131313 	add	x19, x24, x19, lsl #4
    6e2c:	aa1803f4 	mov	x20, x24
    6e30:	aa1603fa 	mov	x26, x22
    6e34:	aa1703f9 	mov	x25, x23
    6e38:	f9400723 	ldr	x3, [x25, #8]
    6e3c:	f9400742 	ldr	x2, [x26, #8]
    6e40:	f9400861 	ldr	x1, [x3, #16]
    6e44:	f9400840 	ldr	x0, [x2, #16]
    6e48:	fd400461 	ldr	d1, [x3, #8]
    6e4c:	fd400440 	ldr	d0, [x2, #8]
    6e50:	97fff904 	bl	5260 <w120>
    6e54:	f9000680 	str	x0, [x20, #8]
    6e58:	f8010e81 	str	x1, [x20, #16]!
    6e5c:	f9400b39 	ldr	x25, [x25, #16]
    6e60:	f9400b5a 	ldr	x26, [x26, #16]
    6e64:	eb14027f 	cmp	x19, x20
    6e68:	54fffe81 	b.ne	6e38 <f37+0x1b8>  // b.any
    6e6c:	aa1703e0 	mov	x0, x23
    6e70:	97fffd20 	bl	62f0 <fwp_drop4>
    6e74:	aa1603e0 	mov	x0, x22
    6e78:	97fffd1e 	bl	62f0 <fwp_drop4>
    6e7c:	f9400316 	ldr	x22, [x24]
    6e80:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6e84:	b4000236 	cbz	x22, 6ec8 <f37+0x248>
    6e88:	fd003be8 	str	d8, [sp, #112]
    6e8c:	2f00e408 	movi	d8, #0x0
    6e90:	91002319 	add	x25, x24, #0x8
    6e94:	91004317 	add	x23, x24, #0x10
    6e98:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6e9c:	d2800013 	mov	x19, #0x0                   	// #0
    6ea0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6ea4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    6ea8:	91000a73 	add	x19, x19, #0x2
    6eac:	1e602908 	fadd	d8, d8, d0
    6eb0:	97fff894 	bl	5100 <f141.constprop.0>
    6eb4:	aa0003f4 	mov	x20, x0
    6eb8:	eb1302df 	cmp	x22, x19
    6ebc:	54ffff28 	b.hi	6ea0 <f37+0x220>  // b.pmore
    6ec0:	9e660116 	fmov	x22, d8
    6ec4:	fd403be8 	ldr	d8, [sp, #112]
    6ec8:	911502b5 	add	x21, x21, #0x540
    6ecc:	aa1803e0 	mov	x0, x24
    6ed0:	97fffec4 	bl	69e0 <fwp_drop10>
    6ed4:	a900d3f6 	stp	x22, x20, [sp, #8]
    6ed8:	910023e1 	add	x1, sp, #0x8
    6edc:	52800000 	mov	w0, #0x0                   	// #0
    6ee0:	97fff7a9 	bl	4d84 <fwp_data.part.0.constprop.0>
    6ee4:	f949daa1 	ldr	x1, [x21, #5040]
    6ee8:	aa0003f3 	mov	x19, x0
    6eec:	f949eea0 	ldr	x0, [x21, #5080]
    6ef0:	cb010261 	sub	x1, x19, x1
    6ef4:	eb00403f 	cmp	x1, x0, lsl #16
    6ef8:	54000322 	b.cs	6f5c <f37+0x2dc>  // b.hs, b.nlast
    6efc:	d350fc22 	lsr	x2, x1, #16
    6f00:	f949fea3 	ldr	x3, [x21, #5112]
    6f04:	8b020842 	add	x2, x2, x2, lsl #2
    6f08:	d37df042 	lsl	x2, x2, #3
    6f0c:	8b020060 	add	x0, x3, x2
    6f10:	f9401014 	ldr	x20, [x0, #32]
    6f14:	b4000254 	cbz	x20, 6f5c <f37+0x2dc>
    6f18:	38626862 	ldrb	w2, [x3, x2]
    6f1c:	7100085f 	cmp	w2, #0x2
    6f20:	540004a0 	b.eq	6fb4 <f37+0x334>  // b.none
    6f24:	7100045f 	cmp	w2, #0x1
    6f28:	540001a1 	b.ne	6f5c <f37+0x2dc>  // b.any
    6f2c:	29430002 	ldp	w2, w0, [x0, #24]
    6f30:	92403c21 	and	x1, x1, #0xffff
    6f34:	9b027c21 	mul	x1, x1, x2
    6f38:	d360fc21 	lsr	x1, x1, #32
    6f3c:	eb00003f 	cmp	x1, x0
    6f40:	540000e2 	b.cs	6f5c <f37+0x2dc>  // b.hs, b.nlast
    6f44:	8b010294 	add	x20, x20, x1
    6f48:	39400280 	ldrb	w0, [x20]
    6f4c:	7103fc1f 	cmp	w0, #0xff
    6f50:	540007a0 	b.eq	7044 <f37+0x3c4>  // b.none
    6f54:	52800020 	mov	w0, #0x1                   	// #1
    6f58:	39000280 	strb	w0, [x20]
    6f5c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f60:	f947f400 	ldr	x0, [x0, #4072]
    6f64:	f9400fe2 	ldr	x2, [sp, #24]
    6f68:	f9400001 	ldr	x1, [x0]
    6f6c:	eb010042 	subs	x2, x2, x1
    6f70:	d2800001 	mov	x1, #0x0                   	// #0
    6f74:	54000721 	b.ne	7058 <f37+0x3d8>  // b.any
    6f78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6f7c:	aa1303e0 	mov	x0, x19
    6f80:	a94353f3 	ldp	x19, x20, [sp, #48]
    6f84:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6f88:	a94563f7 	ldp	x23, x24, [sp, #80]
    6f8c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6f90:	910203ff 	add	sp, sp, #0x80
    6f94:	d65f03c0 	ret
    6f98:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    6f9c:	913ee000 	add	x0, x0, #0xfb8
    6fa0:	fd003be8 	str	d8, [sp, #112]
    6fa4:	97fff3bb 	bl	3e90 <fwp_trap>
    6fa8:	72003c3f 	tst	w1, #0xffff
    6fac:	54ffec81 	b.ne	6d3c <f37+0xbc>  // b.any
    6fb0:	17ffff5d 	b	6d24 <f37+0xa4>
    6fb4:	72003c3f 	tst	w1, #0xffff
    6fb8:	54fffd21 	b.ne	6f5c <f37+0x2dc>  // b.any
    6fbc:	17ffffe3 	b	6f48 <f37+0x2c8>
    6fc0:	72003c3f 	tst	w1, #0xffff
    6fc4:	54fff301 	b.ne	6e24 <f37+0x1a4>  // b.any
    6fc8:	17ffff92 	b	6e10 <f37+0x190>
    6fcc:	cb0103e1 	neg	x1, x1
    6fd0:	eb02003f 	cmp	x1, x2
    6fd4:	540001e3 	b.cc	7010 <f37+0x390>  // b.lo, b.ul, b.last
    6fd8:	52800041 	mov	w1, #0x2                   	// #2
    6fdc:	d2800100 	mov	x0, #0x8                   	// #8
    6fe0:	97fff724 	bl	4c70 <fwp_heap_alloc>
    6fe4:	aa0003f8 	mov	x24, x0
    6fe8:	911502a0 	add	x0, x21, #0x540
    6fec:	f900031f 	str	xzr, [x24]
    6ff0:	f949d801 	ldr	x1, [x0, #5040]
    6ff4:	f949ec00 	ldr	x0, [x0, #5080]
    6ff8:	cb010301 	sub	x1, x24, x1
    6ffc:	eb00403f 	cmp	x1, x0, lsl #16
    7000:	54000282 	b.cs	7050 <f37+0x3d0>  // b.hs, b.nlast
    7004:	d2800013 	mov	x19, #0x0                   	// #0
    7008:	d2800017 	mov	x23, #0x0                   	// #0
    700c:	17ffff6d 	b	6dc0 <f37+0x140>
    7010:	f949fc62 	ldr	x2, [x3, #5112]
    7014:	d350fc20 	lsr	x0, x1, #16
    7018:	8b000800 	add	x0, x0, x0, lsl #2
    701c:	8b000c42 	add	x2, x2, x0, lsl #3
    7020:	f9401040 	ldr	x0, [x2, #32]
    7024:	b4fffda0 	cbz	x0, 6fd8 <f37+0x358>
    7028:	d2800017 	mov	x23, #0x0                   	// #0
    702c:	17ffff32 	b	6cf4 <f37+0x74>
    7030:	97fff4cd 	bl	4364 <fwp_rc_wide_dup>
    7034:	17ffff42 	b	6d3c <f37+0xbc>
    7038:	aa1403e0 	mov	x0, x20
    703c:	97fff3b5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    7040:	17ffff77 	b	6e1c <f37+0x19c>
    7044:	aa1403e0 	mov	x0, x20
    7048:	97fff3b2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    704c:	17ffffc2 	b	6f54 <f37+0x2d4>
    7050:	d2800017 	mov	x23, #0x0                   	// #0
    7054:	17ffff86 	b	6e6c <f37+0x1ec>
    7058:	fd003be8 	str	d8, [sp, #112]
    705c:	97ffee09 	bl	2880 <__stack_chk_fail@plt>

0000000000007060 <fwp_owned_entry37>:
    7060:	f9400000 	ldr	x0, [x0]
    7064:	17ffff07 	b	6c80 <f37>
    7068:	d503201f 	nop
    706c:	d503201f 	nop

0000000000007070 <e37>:
    7070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7074:	910003fd 	mov	x29, sp
    7078:	f9000bf3 	str	x19, [sp, #16]
    707c:	f9400013 	ldr	x19, [x0]
    7080:	aa1303e0 	mov	x0, x19
    7084:	97fff9b0 	bl	5744 <fwp_rc_share>
    7088:	aa1303e0 	mov	x0, x19
    708c:	97fffefd 	bl	6c80 <f37>
    7090:	aa0003f3 	mov	x19, x0
    7094:	97fff9ac 	bl	5744 <fwp_rc_share>
    7098:	aa1303e0 	mov	x0, x19
    709c:	f9400bf3 	ldr	x19, [sp, #16]
    70a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70a4:	d65f03c0 	ret
    70a8:	d503201f 	nop
    70ac:	d503201f 	nop

00000000000070b0 <fwp_args37>:
    70b0:	7100003f 	cmp	w1, #0x0
    70b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70b8:	54000041 	b.ne	70c0 <fwp_args37+0x10>  // b.any
    70bc:	d65f03c0 	ret
    70c0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    70c4:	91150042 	add	x2, x2, #0x540
    70c8:	f9400001 	ldr	x1, [x0]
    70cc:	f949d843 	ldr	x3, [x2, #5040]
    70d0:	f949ec40 	ldr	x0, [x2, #5080]
    70d4:	cb030021 	sub	x1, x1, x3
    70d8:	eb00403f 	cmp	x1, x0, lsl #16
    70dc:	54ffff02 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    70e0:	d350fc20 	lsr	x0, x1, #16
    70e4:	f949fc44 	ldr	x4, [x2, #5112]
    70e8:	8b000800 	add	x0, x0, x0, lsl #2
    70ec:	d37df002 	lsl	x2, x0, #3
    70f0:	8b020083 	add	x3, x4, x2
    70f4:	f9401060 	ldr	x0, [x3, #32]
    70f8:	b4fffe20 	cbz	x0, 70bc <fwp_args37+0xc>
    70fc:	38626882 	ldrb	w2, [x4, x2]
    7100:	7100085f 	cmp	w2, #0x2
    7104:	54000220 	b.eq	7148 <fwp_args37+0x98>  // b.none
    7108:	7100045f 	cmp	w2, #0x1
    710c:	54fffd81 	b.ne	70bc <fwp_args37+0xc>  // b.any
    7110:	29430864 	ldp	w4, w2, [x3, #24]
    7114:	92403c21 	and	x1, x1, #0xffff
    7118:	9b047c21 	mul	x1, x1, x4
    711c:	d360fc21 	lsr	x1, x1, #32
    7120:	eb02003f 	cmp	x1, x2
    7124:	54fffcc2 	b.cs	70bc <fwp_args37+0xc>  // b.hs, b.nlast
    7128:	8b010000 	add	x0, x0, x1
    712c:	39400001 	ldrb	w1, [x0]
    7130:	34fffc61 	cbz	w1, 70bc <fwp_args37+0xc>
    7134:	7103f43f 	cmp	w1, #0xfd
    7138:	540000e8 	b.hi	7154 <fwp_args37+0xa4>  // b.pmore
    713c:	11000421 	add	w1, w1, #0x1
    7140:	39000001 	strb	w1, [x0]
    7144:	d65f03c0 	ret
    7148:	72003c3f 	tst	w1, #0xffff
    714c:	54ffff00 	b.eq	712c <fwp_args37+0x7c>  // b.none
    7150:	d65f03c0 	ret
    7154:	17fff484 	b	4364 <fwp_rc_wide_dup>
    7158:	d503201f 	nop
    715c:	d503201f 	nop

0000000000007160 <fwp_caps37>:
    7160:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7164:	910003fd 	mov	x29, sp
    7168:	f9000bf3 	str	x19, [sp, #16]
    716c:	aa0003f3 	mov	x19, x0
    7170:	b9400400 	ldr	w0, [x0, #4]
    7174:	340004a0 	cbz	w0, 7208 <fwp_caps37+0xa8>
    7178:	f9400660 	ldr	x0, [x19, #8]
    717c:	350004e1 	cbnz	w1, 7218 <fwp_caps37+0xb8>
    7180:	97fffc5c 	bl	62f0 <fwp_drop4>
    7184:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7188:	91150042 	add	x2, x2, #0x540
    718c:	f949d840 	ldr	x0, [x2, #5040]
    7190:	f949ec41 	ldr	x1, [x2, #5080]
    7194:	cb000260 	sub	x0, x19, x0
    7198:	eb01401f 	cmp	x0, x1, lsl #16
    719c:	54000382 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    71a0:	d350fc01 	lsr	x1, x0, #16
    71a4:	f949fc44 	ldr	x4, [x2, #5112]
    71a8:	8b010821 	add	x1, x1, x1, lsl #2
    71ac:	d37df021 	lsl	x1, x1, #3
    71b0:	8b010083 	add	x3, x4, x1
    71b4:	f9401062 	ldr	x2, [x3, #32]
    71b8:	b40002a2 	cbz	x2, 720c <fwp_caps37+0xac>
    71bc:	38616881 	ldrb	w1, [x4, x1]
    71c0:	7100083f 	cmp	w1, #0x2
    71c4:	540006c0 	b.eq	729c <fwp_caps37+0x13c>  // b.none
    71c8:	7100043f 	cmp	w1, #0x1
    71cc:	54000201 	b.ne	720c <fwp_caps37+0xac>  // b.any
    71d0:	29430464 	ldp	w4, w1, [x3, #24]
    71d4:	92403c00 	and	x0, x0, #0xffff
    71d8:	9b047c00 	mul	x0, x0, x4
    71dc:	d360fc00 	lsr	x0, x0, #32
    71e0:	eb01001f 	cmp	x0, x1
    71e4:	54000142 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    71e8:	8b000042 	add	x2, x2, x0
    71ec:	39400040 	ldrb	w0, [x2]
    71f0:	7100041f 	cmp	w0, #0x1
    71f4:	540000c1 	b.ne	720c <fwp_caps37+0xac>  // b.any
    71f8:	aa1303e0 	mov	x0, x19
    71fc:	f9400bf3 	ldr	x19, [sp, #16]
    7200:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7204:	17fff3df 	b	4180 <fwp_mem_free>
    7208:	34fffbe1 	cbz	w1, 7184 <fwp_caps37+0x24>
    720c:	f9400bf3 	ldr	x19, [sp, #16]
    7210:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7214:	d65f03c0 	ret
    7218:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    721c:	91150042 	add	x2, x2, #0x540
    7220:	f949d843 	ldr	x3, [x2, #5040]
    7224:	f949ec41 	ldr	x1, [x2, #5080]
    7228:	cb030000 	sub	x0, x0, x3
    722c:	eb01401f 	cmp	x0, x1, lsl #16
    7230:	54fffee2 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    7234:	d350fc01 	lsr	x1, x0, #16
    7238:	f949fc44 	ldr	x4, [x2, #5112]
    723c:	8b010821 	add	x1, x1, x1, lsl #2
    7240:	d37df021 	lsl	x1, x1, #3
    7244:	8b010083 	add	x3, x4, x1
    7248:	f9401062 	ldr	x2, [x3, #32]
    724c:	b4fffe02 	cbz	x2, 720c <fwp_caps37+0xac>
    7250:	38616881 	ldrb	w1, [x4, x1]
    7254:	7100083f 	cmp	w1, #0x2
    7258:	54000280 	b.eq	72a8 <fwp_caps37+0x148>  // b.none
    725c:	7100043f 	cmp	w1, #0x1
    7260:	54fffd61 	b.ne	720c <fwp_caps37+0xac>  // b.any
    7264:	92403c01 	and	x1, x0, #0xffff
    7268:	29430064 	ldp	w4, w0, [x3, #24]
    726c:	9b047c21 	mul	x1, x1, x4
    7270:	d360fc21 	lsr	x1, x1, #32
    7274:	eb00003f 	cmp	x1, x0
    7278:	54fffca2 	b.cs	720c <fwp_caps37+0xac>  // b.hs, b.nlast
    727c:	8b010042 	add	x2, x2, x1
    7280:	39400040 	ldrb	w0, [x2]
    7284:	34fffc40 	cbz	w0, 720c <fwp_caps37+0xac>
    7288:	7103f41f 	cmp	w0, #0xfd
    728c:	54000148 	b.hi	72b4 <fwp_caps37+0x154>  // b.pmore
    7290:	11000400 	add	w0, w0, #0x1
    7294:	39000040 	strb	w0, [x2]
    7298:	17ffffdd 	b	720c <fwp_caps37+0xac>
    729c:	72003c1f 	tst	w0, #0xffff
    72a0:	54fffb61 	b.ne	720c <fwp_caps37+0xac>  // b.any
    72a4:	17ffffd2 	b	71ec <fwp_caps37+0x8c>
    72a8:	72003c1f 	tst	w0, #0xffff
    72ac:	54fffb01 	b.ne	720c <fwp_caps37+0xac>  // b.any
    72b0:	17fffff4 	b	7280 <fwp_caps37+0x120>
    72b4:	f9400bf3 	ldr	x19, [sp, #16]
    72b8:	aa0203e0 	mov	x0, x2
    72bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72c0:	17fff429 	b	4364 <fwp_rc_wide_dup>

00000000000072c4 <fwp_write>:
    72c4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    72c8:	910003fd 	mov	x29, sp
    72cc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    72d0:	f947f484 	ldr	x4, [x4, #4072]
    72d4:	a90153f3 	stp	x19, x20, [sp, #16]
    72d8:	d10943ff 	sub	sp, sp, #0x250
    72dc:	b9400045 	ldr	w5, [x2]
    72e0:	aa0003f4 	mov	x20, x0
    72e4:	f9400080 	ldr	x0, [x4]
    72e8:	f90127e0 	str	x0, [sp, #584]
    72ec:	d2800000 	mov	x0, #0x0                   	// #0
    72f0:	710064bf 	cmp	w5, #0x19
    72f4:	54000408 	b.hi	7374 <fwp_write+0xb0>  // b.pmore
    72f8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x430>
    72fc:	aa0103f3 	mov	x19, x1
    7300:	91208000 	add	x0, x0, #0x820
    7304:	f9013bf5 	str	x21, [sp, #624]
    7308:	f9013ff6 	str	x22, [sp, #632]
    730c:	f90153fb 	str	x27, [sp, #672]
    7310:	f90157fc 	str	x28, [sp, #680]
    7314:	aa0203fc 	mov	x28, x2
    7318:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    731c:	10000061 	adr	x1, 7328 <fwp_write+0x64>
    7320:	8b20a820 	add	x0, x1, w0, sxth #2
    7324:	d61f0000 	br	x0
    7328:	910123e0 	add	x0, sp, #0x48
    732c:	aa1303e5 	mov	x5, x19
    7330:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x430>
    7334:	aa0003f3 	mov	x19, x0
    7338:	91000084 	add	x4, x4, #0x0
    733c:	d2804003 	mov	x3, #0x200                 	// #512
    7340:	aa0303e1 	mov	x1, x3
    7344:	52800042 	mov	w2, #0x2                   	// #2
    7348:	97ffed2a 	bl	27f0 <__snprintf_chk@plt>
    734c:	aa1303e0 	mov	x0, x19
    7350:	97ffecf0 	bl	2710 <strlen@plt>
    7354:	aa1303e1 	mov	x1, x19
    7358:	aa0003e2 	mov	x2, x0
    735c:	aa1403e0 	mov	x0, x20
    7360:	97fff02c 	bl	3410 <buf_put>
    7364:	f9413bf5 	ldr	x21, [sp, #624]
    7368:	f9413ff6 	ldr	x22, [sp, #632]
    736c:	f94153fb 	ldr	x27, [sp, #672]
    7370:	f94157fc 	ldr	x28, [sp, #680]
    7374:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7378:	f947f400 	ldr	x0, [x0, #4072]
    737c:	f94127e2 	ldr	x2, [sp, #584]
    7380:	f9400001 	ldr	x1, [x0]
    7384:	eb010042 	subs	x2, x2, x1
    7388:	d2800001 	mov	x1, #0x0                   	// #0
    738c:	540077a1 	b.ne	8280 <fwp_write+0xfbc>  // b.any
    7390:	910943ff 	add	sp, sp, #0x250
    7394:	a94153f3 	ldp	x19, x20, [sp, #16]
    7398:	a8c77bfd 	ldp	x29, x30, [sp], #112
    739c:	d65f03c0 	ret
    73a0:	910123e0 	add	x0, sp, #0x48
    73a4:	aa1303e5 	mov	x5, x19
    73a8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1d50>
    73ac:	aa0003f3 	mov	x19, x0
    73b0:	913fe084 	add	x4, x4, #0xff8
    73b4:	d2804003 	mov	x3, #0x200                 	// #512
    73b8:	17ffffe2 	b	7340 <fwp_write+0x7c>
    73bc:	71004cbf 	cmp	w5, #0x13
    73c0:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    73c4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    73c8:	913fa000 	add	x0, x0, #0xfe8
    73cc:	913fc021 	add	x1, x1, #0xff0
    73d0:	d2800082 	mov	x2, #0x4                   	// #4
    73d4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    73d8:	aa1403e0 	mov	x0, x20
    73dc:	f90143f7 	str	x23, [sp, #640]
    73e0:	d2800016 	mov	x22, #0x0                   	// #0
    73e4:	f90147f8 	str	x24, [sp, #648]
    73e8:	97fff00a 	bl	3410 <buf_put>
    73ec:	f9400260 	ldr	x0, [x19]
    73f0:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x430>
    73f4:	d2800015 	mov	x21, #0x0                   	// #0
    73f8:	9101c2f7 	add	x23, x23, #0x70
    73fc:	b4004780 	cbz	x0, 7cec <fwp_write+0xa28>
    7400:	b9400380 	ldr	w0, [x28]
    7404:	52800003 	mov	w3, #0x0                   	// #0
    7408:	f9401f82 	ldr	x2, [x28, #56]
    740c:	71004c1f 	cmp	w0, #0x13
    7410:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7414:	aa1403e0 	mov	x0, x20
    7418:	8b010e61 	add	x1, x19, x1, lsl #3
    741c:	f9400421 	ldr	x1, [x1, #8]
    7420:	97ffffa9 	bl	72c4 <fwp_write>
    7424:	b9400380 	ldr	w0, [x28]
    7428:	7100481f 	cmp	w0, #0x12
    742c:	54004b20 	b.eq	7d90 <fwp_write+0xacc>  // b.none
    7430:	f9400260 	ldr	x0, [x19]
    7434:	910006b5 	add	x21, x21, #0x1
    7438:	91000ad6 	add	x22, x22, #0x2
    743c:	eb15001f 	cmp	x0, x21
    7440:	54004569 	b.ls	7cec <fwp_write+0xa28>  // b.plast
    7444:	aa1703e1 	mov	x1, x23
    7448:	aa1403e0 	mov	x0, x20
    744c:	d2800042 	mov	x2, #0x2                   	// #2
    7450:	97ffeff0 	bl	3410 <buf_put>
    7454:	17ffffeb 	b	7400 <fwp_write+0x13c>
    7458:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    745c:	9100a021 	add	x1, x1, #0x28
    7460:	d28000c2 	mov	x2, #0x6                   	// #6
    7464:	aa1403e0 	mov	x0, x20
    7468:	91004273 	add	x19, x19, #0x10
    746c:	97ffefe9 	bl	3410 <buf_put>
    7470:	aa1303e0 	mov	x0, x19
    7474:	97ffeca7 	bl	2710 <strlen@plt>
    7478:	aa1303e1 	mov	x1, x19
    747c:	aa0003e2 	mov	x2, x0
    7480:	aa1403e0 	mov	x0, x20
    7484:	97ffefe3 	bl	3410 <buf_put>
    7488:	528007c3 	mov	w3, #0x3e                  	// #62
    748c:	aa1403e0 	mov	x0, x20
    7490:	91001fe1 	add	x1, sp, #0x7
    7494:	d2800022 	mov	x2, #0x1                   	// #1
    7498:	39001fe3 	strb	w3, [sp, #7]
    749c:	17ffffb1 	b	7360 <fwp_write+0x9c>
    74a0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    74a4:	f947f400 	ldr	x0, [x0, #4072]
    74a8:	f94127e2 	ldr	x2, [sp, #584]
    74ac:	f9400001 	ldr	x1, [x0]
    74b0:	eb010042 	subs	x2, x2, x1
    74b4:	d2800001 	mov	x1, #0x0                   	// #0
    74b8:	540034c1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    74bc:	f9413bf5 	ldr	x21, [sp, #624]
    74c0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    74c4:	f9413ff6 	ldr	x22, [sp, #632]
    74c8:	aa1403e0 	mov	x0, x20
    74cc:	91002021 	add	x1, x1, #0x8
    74d0:	d2800142 	mov	x2, #0xa                   	// #10
    74d4:	f94153fb 	ldr	x27, [sp, #672]
    74d8:	f94157fc 	ldr	x28, [sp, #680]
    74dc:	910943ff 	add	sp, sp, #0x250
    74e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    74e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74e8:	17ffefca 	b	3410 <buf_put>
    74ec:	f9400456 	ldr	x22, [x2, #8]
    74f0:	f90143f7 	str	x23, [sp, #640]
    74f4:	f90147f8 	str	x24, [sp, #648]
    74f8:	b4005af6 	cbz	x22, 8054 <fwp_write+0xd90>
    74fc:	aa1603e0 	mov	x0, x22
    7500:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7504:	91022021 	add	x1, x1, #0x88
    7508:	97ffecfe 	bl	2900 <strcmp@plt>
    750c:	2a0003f5 	mov	w21, w0
    7510:	34005fc0 	cbz	w0, 8108 <fwp_write+0xe44>
    7514:	aa1603e0 	mov	x0, x22
    7518:	97ffec7e 	bl	2710 <strlen@plt>
    751c:	aa1603e1 	mov	x1, x22
    7520:	aa0003e2 	mov	x2, x0
    7524:	aa1403e0 	mov	x0, x20
    7528:	97ffefba 	bl	3410 <buf_put>
    752c:	52800403 	mov	w3, #0x20                  	// #32
    7530:	91001ff5 	add	x21, sp, #0x7
    7534:	aa1503e1 	mov	x1, x21
    7538:	aa1403e0 	mov	x0, x20
    753c:	d2800022 	mov	x2, #0x1                   	// #1
    7540:	39001fe3 	strb	w3, [sp, #7]
    7544:	97ffefb3 	bl	3410 <buf_put>
    7548:	52800f63 	mov	w3, #0x7b                  	// #123
    754c:	aa1403e0 	mov	x0, x20
    7550:	aa1503e1 	mov	x1, x21
    7554:	d2800022 	mov	x2, #0x1                   	// #1
    7558:	39001fe3 	strb	w3, [sp, #7]
    755c:	97ffefad 	bl	3410 <buf_put>
    7560:	b9401380 	ldr	w0, [x28, #16]
    7564:	52800018 	mov	w24, #0x0                   	// #0
    7568:	7100001f 	cmp	w0, #0x0
    756c:	54003a8d 	b.le	7cbc <fwp_write+0x9f8>
    7570:	f9014bf9 	str	x25, [sp, #656]
    7574:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x430>
    7578:	9102c339 	add	x25, x25, #0xb0
    757c:	f9014ffa 	str	x26, [sp, #664]
    7580:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x430>
    7584:	9101c35a 	add	x26, x26, #0x70
    7588:	91002276 	add	x22, x19, #0x8
    758c:	d2800013 	mov	x19, #0x0                   	// #0
    7590:	b5003e73 	cbnz	x19, 7d5c <fwp_write+0xa98>
    7594:	d37df277 	lsl	x23, x19, #3
    7598:	34003c98 	cbz	w24, 7d28 <fwp_write+0xa64>
    759c:	f9401382 	ldr	x2, [x28, #32]
    75a0:	aa1403e0 	mov	x0, x20
    75a4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    75a8:	52800003 	mov	w3, #0x0                   	// #0
    75ac:	f8776842 	ldr	x2, [x2, x23]
    75b0:	91000673 	add	x19, x19, #0x1
    75b4:	97ffff44 	bl	72c4 <fwp_write>
    75b8:	b9401380 	ldr	w0, [x28, #16]
    75bc:	6b13001f 	cmp	w0, w19
    75c0:	54fffe8c 	b.gt	7590 <fwp_write+0x2cc>
    75c4:	f9414bf9 	ldr	x25, [sp, #656]
    75c8:	f9414ffa 	ldr	x26, [sp, #664]
    75cc:	34003798 	cbz	w24, 7cbc <fwp_write+0x9f8>
    75d0:	52800523 	mov	w3, #0x29                  	// #41
    75d4:	aa1503e1 	mov	x1, x21
    75d8:	aa1403e0 	mov	x0, x20
    75dc:	d2800022 	mov	x2, #0x1                   	// #1
    75e0:	39001fe3 	strb	w3, [sp, #7]
    75e4:	97ffef8b 	bl	3410 <buf_put>
    75e8:	f9413bf5 	ldr	x21, [sp, #624]
    75ec:	f9413ff6 	ldr	x22, [sp, #632]
    75f0:	f94143f7 	ldr	x23, [sp, #640]
    75f4:	f94147f8 	ldr	x24, [sp, #648]
    75f8:	f94153fb 	ldr	x27, [sp, #672]
    75fc:	f94157fc 	ldr	x28, [sp, #680]
    7600:	17ffff5d 	b	7374 <fwp_write+0xb0>
    7604:	b9404855 	ldr	w21, [x2, #72]
    7608:	aa1403e0 	mov	x0, x20
    760c:	93407eb6 	sxtw	x22, w21
    7610:	91000ac1 	add	x1, x22, #0x2
    7614:	97ffef4c 	bl	3344 <buf_grow>
    7618:	a9400281 	ldp	x1, x0, [x20]
    761c:	528e8603 	mov	w3, #0x7430                	// #29744
    7620:	78206823 	strh	w3, [x1, x0]
    7624:	8b000022 	add	x2, x1, x0
    7628:	710002bf 	cmp	w21, #0x0
    762c:	540036ad 	b.le	7d00 <fwp_write+0xa3c>
    7630:	110006a3 	add	w3, w21, #0x1
    7634:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7638:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    763c:	91000449 	add	x9, x2, #0x1
    7640:	8b23c043 	add	x3, x2, w3, sxtw
    7644:	f28aaac6 	movk	x6, #0x5556
    7648:	f2955568 	movk	x8, #0xaaab
    764c:	1400000d 	b	7680 <fwp_write+0x3bc>
    7650:	d2800021 	mov	x1, #0x1                   	// #1
    7654:	528005a5 	mov	w5, #0x2d                  	// #45
    7658:	f100001f 	cmp	x0, #0x0
    765c:	9b467e60 	smulh	x0, x19, x6
    7660:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7664:	381ff465 	strb	w5, [x3], #-1
    7668:	cb040000 	sub	x0, x0, x4
    766c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7670:	cb020000 	sub	x0, x0, x2
    7674:	8b010013 	add	x19, x0, x1
    7678:	eb03013f 	cmp	x9, x3
    767c:	54003420 	b.eq	7d00 <fwp_write+0xa3c>  // b.none
    7680:	9b467e60 	smulh	x0, x19, x6
    7684:	937ffe64 	asr	x4, x19, #63
    7688:	52800605 	mov	w5, #0x30                  	// #48
    768c:	cb040000 	sub	x0, x0, x4
    7690:	8b000400 	add	x0, x0, x0, lsl #1
    7694:	cb000260 	sub	x0, x19, x0
    7698:	91000c01 	add	x1, x0, #0x3
    769c:	9bc87c22 	umulh	x2, x1, x8
    76a0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    76a4:	8b4204e2 	add	x2, x7, x2, lsr #1
    76a8:	eb020021 	subs	x1, x1, x2
    76ac:	54fffd60 	b.eq	7658 <fwp_write+0x394>  // b.none
    76b0:	f100043f 	cmp	x1, #0x1
    76b4:	54fffce1 	b.ne	7650 <fwp_write+0x38c>  // b.any
    76b8:	d2800001 	mov	x1, #0x0                   	// #0
    76bc:	52800565 	mov	w5, #0x2b                  	// #43
    76c0:	17ffffe6 	b	7658 <fwp_write+0x394>
    76c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76c8:	f947f400 	ldr	x0, [x0, #4072]
    76cc:	f94127e2 	ldr	x2, [sp, #584]
    76d0:	f9400001 	ldr	x1, [x0]
    76d4:	eb010042 	subs	x2, x2, x1
    76d8:	d2800001 	mov	x1, #0x0                   	// #0
    76dc:	540023a1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    76e0:	f9413bf5 	ldr	x21, [sp, #624]
    76e4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    76e8:	f9413ff6 	ldr	x22, [sp, #632]
    76ec:	aa1403e0 	mov	x0, x20
    76f0:	91006021 	add	x1, x1, #0x18
    76f4:	d2800102 	mov	x2, #0x8                   	// #8
    76f8:	17ffff77 	b	74d4 <fwp_write+0x210>
    76fc:	aa1403e0 	mov	x0, x20
    7700:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7704:	d28000c2 	mov	x2, #0x6                   	// #6
    7708:	9101e021 	add	x1, x1, #0x78
    770c:	97ffef41 	bl	3410 <buf_put>
    7710:	d2800015 	mov	x21, #0x0                   	// #0
    7714:	f9400263 	ldr	x3, [x19]
    7718:	f240f87f 	tst	x3, #0x7fffffffffffffff
    771c:	54002c40 	b.eq	7ca4 <fwp_write+0x9e0>  // b.none
    7720:	f9401f82 	ldr	x2, [x28, #56]
    7724:	f90143f7 	str	x23, [sp, #640]
    7728:	f90147f8 	str	x24, [sp, #648]
    772c:	d2800857 	mov	x23, #0x42                  	// #66
    7730:	f9014bf9 	str	x25, [sp, #656]
    7734:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x430>
    7738:	f9014ffa 	str	x26, [sp, #664]
    773c:	9101c2d6 	add	x22, x22, #0x70
    7740:	d2800038 	mov	x24, #0x1                   	// #1
    7744:	f2a18017 	movk	x23, #0xc00, lsl #16
    7748:	d2809099 	mov	x25, #0x484                 	// #1156
    774c:	b4000482 	cbz	x2, 77dc <fwp_write+0x518>
    7750:	b9400040 	ldr	w0, [x2]
    7754:	7100701f 	cmp	w0, #0x1c
    7758:	540042a0 	b.eq	7fac <fwp_write+0xce8>  // b.none
    775c:	71006c1f 	cmp	w0, #0x1b
    7760:	540003e8 	b.hi	77dc <fwp_write+0x518>  // b.pmore
    7764:	9ac02301 	lsl	x1, x24, x0
    7768:	ea17003f 	tst	x1, x23
    776c:	54003681 	b.ne	7e3c <fwp_write+0xb78>  // b.any
    7770:	ea19003f 	tst	x1, x25
    7774:	54003501 	b.ne	7e14 <fwp_write+0xb50>  // b.any
    7778:	d2800424 	mov	x4, #0x21                  	// #33
    777c:	ea04003f 	tst	x1, x4
    7780:	540002e0 	b.eq	77dc <fwp_write+0x518>  // b.none
    7784:	b7f849a3 	tbnz	x3, #63, 80b8 <fwp_write+0xdf4>
    7788:	91002261 	add	x1, x19, #0x8
    778c:	8b150021 	add	x1, x1, x21
    7790:	39400021 	ldrb	w1, [x1]
    7794:	7100001f 	cmp	w0, #0x0
    7798:	93401c23 	sxtb	x3, w1
    779c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    77a0:	aa1403e0 	mov	x0, x20
    77a4:	52800003 	mov	w3, #0x0                   	// #0
    77a8:	97fffec7 	bl	72c4 <fwp_write>
    77ac:	910006b5 	add	x21, x21, #0x1
    77b0:	f9400260 	ldr	x0, [x19]
    77b4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    77b8:	eb0002bf 	cmp	x21, x0
    77bc:	540026c2 	b.cs	7c94 <fwp_write+0x9d0>  // b.hs, b.nlast
    77c0:	d2800042 	mov	x2, #0x2                   	// #2
    77c4:	aa1603e1 	mov	x1, x22
    77c8:	aa1403e0 	mov	x0, x20
    77cc:	97ffef11 	bl	3410 <buf_put>
    77d0:	f9401f82 	ldr	x2, [x28, #56]
    77d4:	f9400263 	ldr	x3, [x19]
    77d8:	b5fffbc2 	cbnz	x2, 7750 <fwp_write+0x48c>
    77dc:	d37df2a0 	lsl	x0, x21, #3
    77e0:	b7f83f03 	tbnz	x3, #63, 7fc0 <fwp_write+0xcfc>
    77e4:	91002261 	add	x1, x19, #0x8
    77e8:	8b000020 	add	x0, x1, x0
    77ec:	f9400001 	ldr	x1, [x0]
    77f0:	17ffffec 	b	77a0 <fwp_write+0x4dc>
    77f4:	a9400e62 	ldp	x2, x3, [x19]
    77f8:	b7f83ca3 	tbnz	x3, #63, 7f8c <fwp_write+0xcc8>
    77fc:	910123f5 	add	x21, sp, #0x48
    7800:	aa1503e0 	mov	x0, x21
    7804:	97ffed87 	bl	2e20 <fwp_fmt_u128>
    7808:	aa1503e0 	mov	x0, x21
    780c:	97ffebc1 	bl	2710 <strlen@plt>
    7810:	aa1503e1 	mov	x1, x21
    7814:	aa0003e2 	mov	x2, x0
    7818:	17fffed1 	b	735c <fwp_write+0x98>
    781c:	fd015be8 	str	d8, [sp, #688]
    7820:	1e270268 	fmov	s8, w19
    7824:	fd015fe9 	str	d9, [sp, #696]
    7828:	1e282100 	fcmp	s8, s8
    782c:	54004d26 	b.vs	81d0 <fwp_write+0xf0c>
    7830:	1e20c101 	fabs	s1, s8
    7834:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7838:	1e270000 	fmov	s0, w0
    783c:	1e202020 	fcmp	s1, s0
    7840:	54002c0d 	b.le	7dc0 <fwp_write+0xafc>
    7844:	1e202118 	fcmpe	s8, #0.0
    7848:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1d50>
    784c:	912fc042 	add	x2, x2, #0xbf0
    7850:	910123f5 	add	x21, sp, #0x48
    7854:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    7858:	913f2021 	add	x1, x1, #0xfc8
    785c:	aa1503e0 	mov	x0, x21
    7860:	9a81c041 	csel	x1, x2, x1, gt
    7864:	97ffec57 	bl	29c0 <strcpy@plt>
    7868:	aa1503e0 	mov	x0, x21
    786c:	97ffeba9 	bl	2710 <strlen@plt>
    7870:	aa1503e1 	mov	x1, x21
    7874:	aa0003e2 	mov	x2, x0
    7878:	aa1403e0 	mov	x0, x20
    787c:	97ffeee5 	bl	3410 <buf_put>
    7880:	f9413bf5 	ldr	x21, [sp, #624]
    7884:	f9413ff6 	ldr	x22, [sp, #632]
    7888:	f94153fb 	ldr	x27, [sp, #672]
    788c:	f94157fc 	ldr	x28, [sp, #680]
    7890:	fd415be8 	ldr	d8, [sp, #688]
    7894:	fd415fe9 	ldr	d9, [sp, #696]
    7898:	17fffeb7 	b	7374 <fwp_write+0xb0>
    789c:	f9400276 	ldr	x22, [x19]
    78a0:	34002e03 	cbz	w3, 7e60 <fwp_write+0xb9c>
    78a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    78a8:	f947f400 	ldr	x0, [x0, #4072]
    78ac:	f94127e2 	ldr	x2, [sp, #584]
    78b0:	f9400001 	ldr	x1, [x0]
    78b4:	eb010042 	subs	x2, x2, x1
    78b8:	d2800001 	mov	x1, #0x0                   	// #0
    78bc:	540014a1 	b.ne	7b50 <fwp_write+0x88c>  // b.any
    78c0:	aa1603e2 	mov	x2, x22
    78c4:	91002261 	add	x1, x19, #0x8
    78c8:	f9413bf5 	ldr	x21, [sp, #624]
    78cc:	aa1403e0 	mov	x0, x20
    78d0:	f9413ff6 	ldr	x22, [sp, #632]
    78d4:	17ffff00 	b	74d4 <fwp_write+0x210>
    78d8:	fd015be8 	str	d8, [sp, #688]
    78dc:	9e670268 	fmov	d8, x19
    78e0:	fd015fe9 	str	d9, [sp, #696]
    78e4:	1e682100 	fcmp	d8, d8
    78e8:	54004746 	b.vs	81d0 <fwp_write+0xf0c>
    78ec:	1e60c101 	fabs	d1, d8
    78f0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    78f4:	9e670000 	fmov	d0, x0
    78f8:	910123f5 	add	x21, sp, #0x48
    78fc:	52800033 	mov	w19, #0x1                   	// #1
    7900:	1e602020 	fcmp	d1, d0
    7904:	540001ad 	b.le	7938 <fwp_write+0x674>
    7908:	1e602118 	fcmpe	d8, #0.0
    790c:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1d50>
    7910:	912fc042 	add	x2, x2, #0xbf0
    7914:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    7918:	913f2021 	add	x1, x1, #0xfc8
    791c:	aa1503e0 	mov	x0, x21
    7920:	9a81c041 	csel	x1, x2, x1, gt
    7924:	97ffec27 	bl	29c0 <strcpy@plt>
    7928:	17ffffd0 	b	7868 <fwp_write+0x5a4>
    792c:	11000673 	add	w19, w19, #0x1
    7930:	71004a7f 	cmp	w19, #0x12
    7934:	54003860 	b.eq	8040 <fwp_write+0xd7c>  // b.none
    7938:	1e604100 	fmov	d0, d8
    793c:	2a1303e1 	mov	w1, w19
    7940:	aa1503e0 	mov	x0, x21
    7944:	97ffef0f 	bl	3580 <fwp_format_g.constprop.0>
    7948:	aa1503e0 	mov	x0, x21
    794c:	d2800001 	mov	x1, #0x0                   	// #0
    7950:	97ffeb84 	bl	2760 <strtod@plt>
    7954:	1e602100 	fcmp	d8, d0
    7958:	54fffea1 	b.ne	792c <fwp_write+0x668>  // b.any
    795c:	aa1503e0 	mov	x0, x21
    7960:	97ffeee5 	bl	34f4 <fwp_finish_float>
    7964:	17ffffc1 	b	7868 <fwp_write+0x5a4>
    7968:	a9400e62 	ldp	x2, x3, [x19]
    796c:	910123f3 	add	x19, sp, #0x48
    7970:	aa1303e0 	mov	x0, x19
    7974:	97ffed2b 	bl	2e20 <fwp_fmt_u128>
    7978:	17fffe75 	b	734c <fwp_write+0x88>
    797c:	f90143f7 	str	x23, [sp, #640]
    7980:	f90147f8 	str	x24, [sp, #648]
    7984:	2a1303f8 	mov	w24, w19
    7988:	f9014bf9 	str	x25, [sp, #656]
    798c:	f9014ffa 	str	x26, [sp, #664]
    7990:	f13ffe7f 	cmp	x19, #0xfff
    7994:	54000049 	b.ls	799c <fwp_write+0x6d8>  // b.plast
    7998:	b9400278 	ldr	w24, [x19]
    799c:	f9400f80 	ldr	x0, [x28, #24]
    79a0:	2a1803f5 	mov	w21, w24
    79a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    79a8:	d37ef6b9 	lsl	x25, x21, #2
    79ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    79b0:	aa1603e0 	mov	x0, x22
    79b4:	97ffeb57 	bl	2710 <strlen@plt>
    79b8:	aa1603e1 	mov	x1, x22
    79bc:	aa0003e2 	mov	x2, x0
    79c0:	aa1403e0 	mov	x0, x20
    79c4:	97ffee93 	bl	3410 <buf_put>
    79c8:	f9401780 	ldr	x0, [x28, #40]
    79cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    79d0:	7100001f 	cmp	w0, #0x0
    79d4:	5400068d 	b.le	7aa4 <fwp_write+0x7e0>
    79d8:	91002276 	add	x22, x19, #0x8
    79dc:	91001ff5 	add	x21, sp, #0x7
    79e0:	d280001b 	mov	x27, #0x0                   	// #0
    79e4:	5280041a 	mov	w26, #0x20                  	// #32
    79e8:	f9401b80 	ldr	x0, [x28, #48]
    79ec:	aa1503e1 	mov	x1, x21
    79f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    79f4:	d2800022 	mov	x2, #0x1                   	// #1
    79f8:	f8786803 	ldr	x3, [x0, x24]
    79fc:	aa1403e0 	mov	x0, x20
    7a00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7a04:	39001ffa 	strb	w26, [sp, #7]
    7a08:	97ffee82 	bl	3410 <buf_put>
    7a0c:	f13ffeff 	cmp	x23, #0xfff
    7a10:	b9400261 	ldr	w1, [x19]
    7a14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7a18:	7100383f 	cmp	w1, #0xe
    7a1c:	54000160 	b.eq	7a48 <fwp_write+0x784>  // b.none
    7a20:	7100403f 	cmp	w1, #0x10
    7a24:	54001a60 	b.eq	7d70 <fwp_write+0xaac>  // b.none
    7a28:	7100283f 	cmp	w1, #0xa
    7a2c:	54002aa0 	b.eq	7f80 <fwp_write+0xcbc>  // b.none
    7a30:	540014ac 	b.gt	7cc4 <fwp_write+0xa00>
    7a34:	71000c3f 	cmp	w1, #0x3
    7a38:	540029ac 	b.gt	7f6c <fwp_write+0xca8>
    7a3c:	d37ffee0 	lsr	x0, x23, #63
    7a40:	37f814a1 	tbnz	w1, #31, 7cd4 <fwp_write+0xa10>
    7a44:	d503201f 	nop
    7a48:	34001460 	cbz	w0, 7cd4 <fwp_write+0xa10>
    7a4c:	52800503 	mov	w3, #0x28                  	// #40
    7a50:	aa1503e1 	mov	x1, x21
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	d2800022 	mov	x2, #0x1                   	// #1
    7a5c:	39001fe3 	strb	w3, [sp, #7]
    7a60:	97ffee6c 	bl	3410 <buf_put>
    7a64:	aa1303e2 	mov	x2, x19
    7a68:	aa1703e1 	mov	x1, x23
    7a6c:	aa1403e0 	mov	x0, x20
    7a70:	52800003 	mov	w3, #0x0                   	// #0
    7a74:	97fffe14 	bl	72c4 <fwp_write>
    7a78:	52800523 	mov	w3, #0x29                  	// #41
    7a7c:	aa1503e1 	mov	x1, x21
    7a80:	aa1403e0 	mov	x0, x20
    7a84:	d2800022 	mov	x2, #0x1                   	// #1
    7a88:	39001fe3 	strb	w3, [sp, #7]
    7a8c:	97ffee61 	bl	3410 <buf_put>
    7a90:	f9401780 	ldr	x0, [x28, #40]
    7a94:	9100077b 	add	x27, x27, #0x1
    7a98:	b8796800 	ldr	w0, [x0, x25]
    7a9c:	6b1b001f 	cmp	w0, w27
    7aa0:	54fffa4c 	b.gt	79e8 <fwp_write+0x724>
    7aa4:	f9413bf5 	ldr	x21, [sp, #624]
    7aa8:	f9413ff6 	ldr	x22, [sp, #632]
    7aac:	f94143f7 	ldr	x23, [sp, #640]
    7ab0:	f94147f8 	ldr	x24, [sp, #648]
    7ab4:	f9414bf9 	ldr	x25, [sp, #656]
    7ab8:	f9414ffa 	ldr	x26, [sp, #664]
    7abc:	f94153fb 	ldr	x27, [sp, #672]
    7ac0:	f94157fc 	ldr	x28, [sp, #680]
    7ac4:	17fffe2c 	b	7374 <fwp_write+0xb0>
    7ac8:	52800783 	mov	w3, #0x3c                  	// #60
    7acc:	91001ff3 	add	x19, sp, #0x7
    7ad0:	aa1303e1 	mov	x1, x19
    7ad4:	d2800022 	mov	x2, #0x1                   	// #1
    7ad8:	aa1403e0 	mov	x0, x20
    7adc:	39001fe3 	strb	w3, [sp, #7]
    7ae0:	97ffee4c 	bl	3410 <buf_put>
    7ae4:	f9400795 	ldr	x21, [x28, #8]
    7ae8:	aa1503e0 	mov	x0, x21
    7aec:	97ffeb09 	bl	2710 <strlen@plt>
    7af0:	aa1503e1 	mov	x1, x21
    7af4:	aa0003e2 	mov	x2, x0
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	97ffee45 	bl	3410 <buf_put>
    7b00:	528007c3 	mov	w3, #0x3e                  	// #62
    7b04:	aa1303e1 	mov	x1, x19
    7b08:	aa1403e0 	mov	x0, x20
    7b0c:	d2800022 	mov	x2, #0x1                   	// #1
    7b10:	39001fe3 	strb	w3, [sp, #7]
    7b14:	17fffe13 	b	7360 <fwp_write+0x9c>
    7b18:	f100067f 	cmp	x19, #0x1
    7b1c:	540025a0 	b.eq	7fd0 <fwp_write+0xd0c>  // b.none
    7b20:	b100067f 	cmn	x19, #0x1
    7b24:	54002bc0 	b.eq	809c <fwp_write+0xdd8>  // b.none
    7b28:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    7b2c:	913f4021 	add	x1, x1, #0xfd0
    7b30:	d2800022 	mov	x2, #0x1                   	// #1
    7b34:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b38:	f947f400 	ldr	x0, [x0, #4072]
    7b3c:	f94127e4 	ldr	x4, [sp, #584]
    7b40:	f9400003 	ldr	x3, [x0]
    7b44:	eb030084 	subs	x4, x4, x3
    7b48:	d2800003 	mov	x3, #0x0                   	// #0
    7b4c:	54ffebe0 	b.eq	78c8 <fwp_write+0x604>  // b.none
    7b50:	f90143f7 	str	x23, [sp, #640]
    7b54:	f90147f8 	str	x24, [sp, #648]
    7b58:	f9014bf9 	str	x25, [sp, #656]
    7b5c:	f9014ffa 	str	x26, [sp, #664]
    7b60:	fd015be8 	str	d8, [sp, #688]
    7b64:	fd015fe9 	str	d9, [sp, #696]
    7b68:	97ffeb46 	bl	2880 <__stack_chk_fail@plt>
    7b6c:	52800b63 	mov	w3, #0x5b                  	// #91
    7b70:	91001ff5 	add	x21, sp, #0x7
    7b74:	aa1503e1 	mov	x1, x21
    7b78:	aa1403e0 	mov	x0, x20
    7b7c:	d2800022 	mov	x2, #0x1                   	// #1
    7b80:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x430>
    7b84:	9101c2d6 	add	x22, x22, #0x70
    7b88:	39001fe3 	strb	w3, [sp, #7]
    7b8c:	97ffee21 	bl	3410 <buf_put>
    7b90:	b4000273 	cbz	x19, 7bdc <fwp_write+0x918>
    7b94:	f9400661 	ldr	x1, [x19, #8]
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	f9401f82 	ldr	x2, [x28, #56]
    7ba0:	52800003 	mov	w3, #0x0                   	// #0
    7ba4:	97fffdc8 	bl	72c4 <fwp_write>
    7ba8:	f9400a73 	ldr	x19, [x19, #16]
    7bac:	b4000193 	cbz	x19, 7bdc <fwp_write+0x918>
    7bb0:	aa1603e1 	mov	x1, x22
    7bb4:	aa1403e0 	mov	x0, x20
    7bb8:	d2800042 	mov	x2, #0x2                   	// #2
    7bbc:	97ffee15 	bl	3410 <buf_put>
    7bc0:	f9400661 	ldr	x1, [x19, #8]
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	f9401f82 	ldr	x2, [x28, #56]
    7bcc:	52800003 	mov	w3, #0x0                   	// #0
    7bd0:	97fffdbd 	bl	72c4 <fwp_write>
    7bd4:	f9400a73 	ldr	x19, [x19, #16]
    7bd8:	b5fffed3 	cbnz	x19, 7bb0 <fwp_write+0x8ec>
    7bdc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7be0:	aa1503e1 	mov	x1, x21
    7be4:	aa1403e0 	mov	x0, x20
    7be8:	d2800022 	mov	x2, #0x1                   	// #1
    7bec:	39001fe3 	strb	w3, [sp, #7]
    7bf0:	17fffddc 	b	7360 <fwp_write+0x9c>
    7bf4:	aa1403e0 	mov	x0, x20
    7bf8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7bfc:	d28000c2 	mov	x2, #0x6                   	// #6
    7c00:	91018021 	add	x1, x1, #0x60
    7c04:	97ffee03 	bl	3410 <buf_put>
    7c08:	f9400260 	ldr	x0, [x19]
    7c0c:	b40004c0 	cbz	x0, 7ca4 <fwp_write+0x9e0>
    7c10:	910123f5 	add	x21, sp, #0x48
    7c14:	91002276 	add	x22, x19, #0x8
    7c18:	f90143f7 	str	x23, [sp, #640]
    7c1c:	d2800017 	mov	x23, #0x0                   	// #0
    7c20:	f90147f8 	str	x24, [sp, #648]
    7c24:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x430>
    7c28:	9101a318 	add	x24, x24, #0x68
    7c2c:	f9014bf9 	str	x25, [sp, #656]
    7c30:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x430>
    7c34:	9101c339 	add	x25, x25, #0x70
    7c38:	f9014ffa 	str	x26, [sp, #664]
    7c3c:	14000005 	b	7c50 <fwp_write+0x98c>
    7c40:	aa1903e1 	mov	x1, x25
    7c44:	aa1403e0 	mov	x0, x20
    7c48:	d2800042 	mov	x2, #0x2                   	// #2
    7c4c:	97ffedf1 	bl	3410 <buf_put>
    7c50:	38776ac5 	ldrb	w5, [x22, x23]
    7c54:	d2804003 	mov	x3, #0x200                 	// #512
    7c58:	aa1803e4 	mov	x4, x24
    7c5c:	aa0303e1 	mov	x1, x3
    7c60:	52800042 	mov	w2, #0x2                   	// #2
    7c64:	aa1503e0 	mov	x0, x21
    7c68:	910006f7 	add	x23, x23, #0x1
    7c6c:	97ffeae1 	bl	27f0 <__snprintf_chk@plt>
    7c70:	aa1503e0 	mov	x0, x21
    7c74:	97ffeaa7 	bl	2710 <strlen@plt>
    7c78:	aa1503e1 	mov	x1, x21
    7c7c:	aa0003e2 	mov	x2, x0
    7c80:	aa1403e0 	mov	x0, x20
    7c84:	97ffede3 	bl	3410 <buf_put>
    7c88:	f9400260 	ldr	x0, [x19]
    7c8c:	eb17001f 	cmp	x0, x23
    7c90:	54fffd88 	b.hi	7c40 <fwp_write+0x97c>  // b.pmore
    7c94:	f94143f7 	ldr	x23, [sp, #640]
    7c98:	f94147f8 	ldr	x24, [sp, #648]
    7c9c:	f9414bf9 	ldr	x25, [sp, #656]
    7ca0:	f9414ffa 	ldr	x26, [sp, #664]
    7ca4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ca8:	aa1403e0 	mov	x0, x20
    7cac:	91001fe1 	add	x1, sp, #0x7
    7cb0:	d2800022 	mov	x2, #0x1                   	// #1
    7cb4:	39001fe3 	strb	w3, [sp, #7]
    7cb8:	17fffdaa 	b	7360 <fwp_write+0x9c>
    7cbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cc0:	17fffe45 	b	75d4 <fwp_write+0x310>
    7cc4:	f10002ff 	cmp	x23, #0x0
    7cc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ccc:	71002c3f 	cmp	w1, #0xb
    7cd0:	54ffebc0 	b.eq	7a48 <fwp_write+0x784>  // b.none
    7cd4:	aa1303e2 	mov	x2, x19
    7cd8:	aa1703e1 	mov	x1, x23
    7cdc:	aa1403e0 	mov	x0, x20
    7ce0:	52800003 	mov	w3, #0x0                   	// #0
    7ce4:	97fffd78 	bl	72c4 <fwp_write>
    7ce8:	17ffff6a 	b	7a90 <fwp_write+0x7cc>
    7cec:	aa1403e0 	mov	x0, x20
    7cf0:	91001fe1 	add	x1, sp, #0x7
    7cf4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cf8:	d2800022 	mov	x2, #0x1                   	// #1
    7cfc:	17fffe39 	b	75e0 <fwp_write+0x31c>
    7d00:	a9400281 	ldp	x1, x0, [x20]
    7d04:	91000800 	add	x0, x0, #0x2
    7d08:	8b160000 	add	x0, x0, x22
    7d0c:	f9000680 	str	x0, [x20, #8]
    7d10:	3820683f 	strb	wzr, [x1, x0]
    7d14:	f9413bf5 	ldr	x21, [sp, #624]
    7d18:	f9413ff6 	ldr	x22, [sp, #632]
    7d1c:	f94153fb 	ldr	x27, [sp, #672]
    7d20:	f94157fc 	ldr	x28, [sp, #680]
    7d24:	17fffd94 	b	7374 <fwp_write+0xb0>
    7d28:	f9400f80 	ldr	x0, [x28, #24]
    7d2c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7d30:	aa1b03e0 	mov	x0, x27
    7d34:	97ffea77 	bl	2710 <strlen@plt>
    7d38:	aa1b03e1 	mov	x1, x27
    7d3c:	aa0003e2 	mov	x2, x0
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	97ffedb3 	bl	3410 <buf_put>
    7d48:	aa1903e1 	mov	x1, x25
    7d4c:	aa1403e0 	mov	x0, x20
    7d50:	d2800062 	mov	x2, #0x3                   	// #3
    7d54:	97ffedaf 	bl	3410 <buf_put>
    7d58:	17fffe11 	b	759c <fwp_write+0x2d8>
    7d5c:	aa1a03e1 	mov	x1, x26
    7d60:	aa1403e0 	mov	x0, x20
    7d64:	d2800042 	mov	x2, #0x2                   	// #2
    7d68:	97ffedaa 	bl	3410 <buf_put>
    7d6c:	17fffe0a 	b	7594 <fwp_write+0x2d0>
    7d70:	f9400660 	ldr	x0, [x19, #8]
    7d74:	b4fffb00 	cbz	x0, 7cd4 <fwp_write+0xa10>
    7d78:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7d7c:	91022021 	add	x1, x1, #0x88
    7d80:	97ffeae0 	bl	2900 <strcmp@plt>
    7d84:	7100001f 	cmp	w0, #0x0
    7d88:	1a9f07e0 	cset	w0, ne	// ne = any
    7d8c:	17ffff2f 	b	7a48 <fwp_write+0x784>
    7d90:	aa1403e0 	mov	x0, x20
    7d94:	d2800042 	mov	x2, #0x2                   	// #2
    7d98:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7d9c:	91020021 	add	x1, x1, #0x80
    7da0:	97ffed9c 	bl	3410 <buf_put>
    7da4:	91004261 	add	x1, x19, #0x10
    7da8:	aa1403e0 	mov	x0, x20
    7dac:	f9402382 	ldr	x2, [x28, #64]
    7db0:	52800003 	mov	w3, #0x0                   	// #0
    7db4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7db8:	97fffd43 	bl	72c4 <fwp_write>
    7dbc:	17fffd9d 	b	7430 <fwp_write+0x16c>
    7dc0:	1e22c109 	fcvt	d9, s8
    7dc4:	910123f5 	add	x21, sp, #0x48
    7dc8:	52800033 	mov	w19, #0x1                   	// #1
    7dcc:	d503201f 	nop
    7dd0:	1e604120 	fmov	d0, d9
    7dd4:	2a1303e1 	mov	w1, w19
    7dd8:	aa1503e0 	mov	x0, x21
    7ddc:	97ffede9 	bl	3580 <fwp_format_g.constprop.0>
    7de0:	aa1503e0 	mov	x0, x21
    7de4:	d2800001 	mov	x1, #0x0                   	// #0
    7de8:	97ffead2 	bl	2930 <strtof@plt>
    7dec:	1e202100 	fcmp	s8, s0
    7df0:	54ffdb60 	b.eq	795c <fwp_write+0x698>  // b.none
    7df4:	11000673 	add	w19, w19, #0x1
    7df8:	71002a7f 	cmp	w19, #0xa
    7dfc:	54fffea1 	b.ne	7dd0 <fwp_write+0xb0c>  // b.any
    7e00:	1e604120 	fmov	d0, d9
    7e04:	aa1503e0 	mov	x0, x21
    7e08:	52800121 	mov	w1, #0x9                   	// #9
    7e0c:	97ffeddd 	bl	3580 <fwp_format_g.constprop.0>
    7e10:	17fffed3 	b	795c <fwp_write+0x698>
    7e14:	d37ef6a1 	lsl	x1, x21, #2
    7e18:	b7f81563 	tbnz	x3, #63, 80c4 <fwp_write+0xe00>
    7e1c:	91002263 	add	x3, x19, #0x8
    7e20:	8b010061 	add	x1, x3, x1
    7e24:	b9400023 	ldr	w3, [x1]
    7e28:	7100081f 	cmp	w0, #0x2
    7e2c:	2a0303e1 	mov	w1, w3
    7e30:	93407c63 	sxtw	x3, w3
    7e34:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e38:	17fffe5a 	b	77a0 <fwp_write+0x4dc>
    7e3c:	d37ffaa1 	lsl	x1, x21, #1
    7e40:	b7f81363 	tbnz	x3, #63, 80ac <fwp_write+0xde8>
    7e44:	91002263 	add	x3, x19, #0x8
    7e48:	8b010061 	add	x1, x3, x1
    7e4c:	79400021 	ldrh	w1, [x1]
    7e50:	7100041f 	cmp	w0, #0x1
    7e54:	93403c23 	sxth	x3, w1
    7e58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e5c:	17fffe51 	b	77a0 <fwp_write+0x4dc>
    7e60:	52800443 	mov	w3, #0x22                  	// #34
    7e64:	91001ff5 	add	x21, sp, #0x7
    7e68:	91002273 	add	x19, x19, #0x8
    7e6c:	aa1503e1 	mov	x1, x21
    7e70:	aa1403e0 	mov	x0, x20
    7e74:	d2800022 	mov	x2, #0x1                   	// #1
    7e78:	39001fe3 	strb	w3, [sp, #7]
    7e7c:	f90143f7 	str	x23, [sp, #640]
    7e80:	8b160277 	add	x23, x19, x22
    7e84:	f90147f8 	str	x24, [sp, #648]
    7e88:	97ffed62 	bl	3410 <buf_put>
    7e8c:	b4000696 	cbz	x22, 7f5c <fwp_write+0xc98>
    7e90:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x430>
    7e94:	9100c318 	add	x24, x24, #0x30
    7e98:	f9014bf9 	str	x25, [sp, #656]
    7e9c:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x430>
    7ea0:	91014339 	add	x25, x25, #0x50
    7ea4:	f9014ffa 	str	x26, [sp, #664]
    7ea8:	1400000d 	b	7edc <fwp_write+0xc18>
    7eac:	710024bf 	cmp	w5, #0x9
    7eb0:	54000460 	b.eq	7f3c <fwp_write+0xc78>  // b.none
    7eb4:	710028bf 	cmp	w5, #0xa
    7eb8:	54000a61 	b.ne	8004 <fwp_write+0xd40>  // b.any
    7ebc:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7ec0:	aa1403e0 	mov	x0, x20
    7ec4:	91010021 	add	x1, x1, #0x40
    7ec8:	d2800042 	mov	x2, #0x2                   	// #2
    7ecc:	97ffed51 	bl	3410 <buf_put>
    7ed0:	91000673 	add	x19, x19, #0x1
    7ed4:	eb17027f 	cmp	x19, x23
    7ed8:	540003e0 	b.eq	7f54 <fwp_write+0xc90>  // b.none
    7edc:	39400265 	ldrb	w5, [x19]
    7ee0:	710034bf 	cmp	w5, #0xd
    7ee4:	54000180 	b.eq	7f14 <fwp_write+0xc50>  // b.none
    7ee8:	54fffe29 	b.ls	7eac <fwp_write+0xbe8>  // b.plast
    7eec:	710088bf 	cmp	w5, #0x22
    7ef0:	540001c0 	b.eq	7f28 <fwp_write+0xc64>  // b.none
    7ef4:	710170bf 	cmp	w5, #0x5c
    7ef8:	54000741 	b.ne	7fe0 <fwp_write+0xd1c>  // b.any
    7efc:	aa1403e0 	mov	x0, x20
    7f00:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7f04:	d2800042 	mov	x2, #0x2                   	// #2
    7f08:	9100e021 	add	x1, x1, #0x38
    7f0c:	97ffed41 	bl	3410 <buf_put>
    7f10:	17fffff0 	b	7ed0 <fwp_write+0xc0c>
    7f14:	aa1903e1 	mov	x1, x25
    7f18:	aa1403e0 	mov	x0, x20
    7f1c:	d2800042 	mov	x2, #0x2                   	// #2
    7f20:	97ffed3c 	bl	3410 <buf_put>
    7f24:	17ffffeb 	b	7ed0 <fwp_write+0xc0c>
    7f28:	aa1803e1 	mov	x1, x24
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	d2800042 	mov	x2, #0x2                   	// #2
    7f34:	97ffed37 	bl	3410 <buf_put>
    7f38:	17ffffe6 	b	7ed0 <fwp_write+0xc0c>
    7f3c:	aa1403e0 	mov	x0, x20
    7f40:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x430>
    7f44:	d2800042 	mov	x2, #0x2                   	// #2
    7f48:	91012021 	add	x1, x1, #0x48
    7f4c:	97ffed31 	bl	3410 <buf_put>
    7f50:	17ffffe0 	b	7ed0 <fwp_write+0xc0c>
    7f54:	f9414bf9 	ldr	x25, [sp, #656]
    7f58:	f9414ffa 	ldr	x26, [sp, #664]
    7f5c:	aa1503e1 	mov	x1, x21
    7f60:	aa1403e0 	mov	x0, x20
    7f64:	52800443 	mov	w3, #0x22                  	// #34
    7f68:	17fffd9d 	b	75dc <fwp_write+0x318>
    7f6c:	7100103f 	cmp	w1, #0x4
    7f70:	54ffeb21 	b.ne	7cd4 <fwp_write+0xa10>  // b.any
    7f74:	f94006e0 	ldr	x0, [x23, #8]
    7f78:	d37ffc00 	lsr	x0, x0, #63
    7f7c:	17fffeb3 	b	7a48 <fwp_write+0x784>
    7f80:	710002ff 	cmp	w23, #0x0
    7f84:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f88:	17fffeb0 	b	7a48 <fwp_write+0x784>
    7f8c:	528005a1 	mov	w1, #0x2d                  	// #45
    7f90:	eb0203e2 	negs	x2, x2
    7f94:	da0303e3 	ngc	x3, x3
    7f98:	910127e0 	add	x0, sp, #0x49
    7f9c:	910123f5 	add	x21, sp, #0x48
    7fa0:	390123e1 	strb	w1, [sp, #72]
    7fa4:	97ffeb9f 	bl	2e20 <fwp_fmt_u128>
    7fa8:	17fffe18 	b	7808 <fwp_write+0x544>
    7fac:	d37ceea1 	lsl	x1, x21, #4
    7fb0:	b7f810a3 	tbnz	x3, #63, 81c4 <fwp_write+0xf00>
    7fb4:	91002260 	add	x0, x19, #0x8
    7fb8:	8b010001 	add	x1, x0, x1
    7fbc:	17fffdf9 	b	77a0 <fwp_write+0x4dc>
    7fc0:	f9400a61 	ldr	x1, [x19, #16]
    7fc4:	8b010000 	add	x0, x0, x1
    7fc8:	f9400001 	ldr	x1, [x0]
    7fcc:	17fffdf5 	b	77a0 <fwp_write+0x4dc>
    7fd0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    7fd4:	d2800042 	mov	x2, #0x2                   	// #2
    7fd8:	913f6021 	add	x1, x1, #0xfd8
    7fdc:	17fffed6 	b	7b34 <fwp_write+0x870>
    7fe0:	7101fcbf 	cmp	w5, #0x7f
    7fe4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7fe8:	540000e9 	b.ls	8004 <fwp_write+0xd40>  // b.plast
    7fec:	aa1503e1 	mov	x1, x21
    7ff0:	aa1403e0 	mov	x0, x20
    7ff4:	d2800022 	mov	x2, #0x1                   	// #1
    7ff8:	39001fe5 	strb	w5, [sp, #7]
    7ffc:	97ffed05 	bl	3410 <buf_put>
    8000:	17ffffb4 	b	7ed0 <fwp_write+0xc0c>
    8004:	d2800203 	mov	x3, #0x10                  	// #16
    8008:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x430>
    800c:	aa0303e1 	mov	x1, x3
    8010:	91016084 	add	x4, x4, #0x58
    8014:	910123f6 	add	x22, sp, #0x48
    8018:	52800042 	mov	w2, #0x2                   	// #2
    801c:	aa1603e0 	mov	x0, x22
    8020:	97ffe9f4 	bl	27f0 <__snprintf_chk@plt>
    8024:	aa1603e0 	mov	x0, x22
    8028:	97ffe9ba 	bl	2710 <strlen@plt>
    802c:	aa1603e1 	mov	x1, x22
    8030:	aa0003e2 	mov	x2, x0
    8034:	aa1403e0 	mov	x0, x20
    8038:	97ffecf6 	bl	3410 <buf_put>
    803c:	17ffffa5 	b	7ed0 <fwp_write+0xc0c>
    8040:	1e604100 	fmov	d0, d8
    8044:	aa1503e0 	mov	x0, x21
    8048:	52800221 	mov	w1, #0x11                  	// #17
    804c:	97ffed4d 	bl	3580 <fwp_format_g.constprop.0>
    8050:	17fffe43 	b	795c <fwp_write+0x698>
    8054:	b9401040 	ldr	w0, [x2, #16]
    8058:	350003c0 	cbnz	w0, 80d0 <fwp_write+0xe0c>
    805c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8060:	f947f400 	ldr	x0, [x0, #4072]
    8064:	f94127e2 	ldr	x2, [sp, #584]
    8068:	f9400001 	ldr	x1, [x0]
    806c:	eb010042 	subs	x2, x2, x1
    8070:	d2800001 	mov	x1, #0x0                   	// #0
    8074:	54ffd721 	b.ne	7b58 <fwp_write+0x894>  // b.any
    8078:	f9413bf5 	ldr	x21, [sp, #624]
    807c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x430>
    8080:	f9413ff6 	ldr	x22, [sp, #632]
    8084:	aa1403e0 	mov	x0, x20
    8088:	f94143f7 	ldr	x23, [sp, #640]
    808c:	9102a021 	add	x1, x1, #0xa8
    8090:	f94147f8 	ldr	x24, [sp, #648]
    8094:	d2800042 	mov	x2, #0x2                   	// #2
    8098:	17fffd0f 	b	74d4 <fwp_write+0x210>
    809c:	d0000001 	adrp	x1, a000 <fwp_main_thread+0x1d50>
    80a0:	d2800042 	mov	x2, #0x2                   	// #2
    80a4:	913f8021 	add	x1, x1, #0xfe0
    80a8:	17fffea3 	b	7b34 <fwp_write+0x870>
    80ac:	f9400a63 	ldr	x3, [x19, #16]
    80b0:	8b030021 	add	x1, x1, x3
    80b4:	17ffff66 	b	7e4c <fwp_write+0xb88>
    80b8:	f9400a61 	ldr	x1, [x19, #16]
    80bc:	8b0102a1 	add	x1, x21, x1
    80c0:	17fffdb4 	b	7790 <fwp_write+0x4cc>
    80c4:	f9400a63 	ldr	x3, [x19, #16]
    80c8:	8b030021 	add	x1, x1, x3
    80cc:	17ffff56 	b	7e24 <fwp_write+0xb60>
    80d0:	b9404840 	ldr	w0, [x2, #72]
    80d4:	91001ff5 	add	x21, sp, #0x7
    80d8:	34ffa380 	cbz	w0, 7548 <fwp_write+0x284>
    80dc:	52800503 	mov	w3, #0x28                  	// #40
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	aa1503e1 	mov	x1, x21
    80e8:	d2800022 	mov	x2, #0x1                   	// #1
    80ec:	39001fe3 	strb	w3, [sp, #7]
    80f0:	97ffecc8 	bl	3410 <buf_put>
    80f4:	b9401380 	ldr	w0, [x28, #16]
    80f8:	52800038 	mov	w24, #0x1                   	// #1
    80fc:	7100001f 	cmp	w0, #0x0
    8100:	54ffa38c 	b.gt	7570 <fwp_write+0x2ac>
    8104:	17fffd33 	b	75d0 <fwp_write+0x30c>
    8108:	f9014bf9 	str	x25, [sp, #656]
    810c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x114c0>
    8110:	f9014ffa 	str	x26, [sp, #664]
    8114:	f9400676 	ldr	x22, [x19, #8]
    8118:	910aa333 	add	x19, x25, #0x2a8
    811c:	91002273 	add	x19, x19, #0x8
    8120:	937ffed8 	asr	x24, x22, #63
    8124:	aa1802c0 	orr	x0, x22, x24
    8128:	b5000320 	cbnz	x0, 818c <fwp_write+0xec8>
    812c:	110006b5 	add	w21, w21, #0x1
    8130:	710016bf 	cmp	w21, #0x5
    8134:	54ffffc1 	b.ne	812c <fwp_write+0xe68>  // b.any
    8138:	b7f80578 	tbnz	x24, #63, 81e4 <fwp_write+0xf20>
    813c:	910023f3 	add	x19, sp, #0x8
    8140:	aa1603e2 	mov	x2, x22
    8144:	aa1303e0 	mov	x0, x19
    8148:	d2800003 	mov	x3, #0x0                   	// #0
    814c:	97ffeb35 	bl	2e20 <fwp_fmt_u128>
    8150:	910123f5 	add	x21, sp, #0x48
    8154:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x430>
    8158:	aa1303e4 	mov	x4, x19
    815c:	aa1503e0 	mov	x0, x21
    8160:	91028063 	add	x3, x3, #0xa0
    8164:	d2804002 	mov	x2, #0x200                 	// #512
    8168:	52800041 	mov	w1, #0x2                   	// #2
    816c:	97ffe96d 	bl	2720 <__sprintf_chk@plt>
    8170:	aa1503e0 	mov	x0, x21
    8174:	97ffe967 	bl	2710 <strlen@plt>
    8178:	aa1503e1 	mov	x1, x21
    817c:	aa0003e2 	mov	x2, x0
    8180:	aa1403e0 	mov	x0, x20
    8184:	97ffeca3 	bl	3410 <buf_put>
    8188:	17fffe47 	b	7aa4 <fwp_write+0x7e0>
    818c:	f9400277 	ldr	x23, [x19]
    8190:	aa1603e0 	mov	x0, x22
    8194:	aa1803e1 	mov	x1, x24
    8198:	aa1703e2 	mov	x2, x23
    819c:	937ffefa 	asr	x26, x23, #63
    81a0:	aa1a03e3 	mov	x3, x26
    81a4:	940009a3 	bl	a830 <__modti3>
    81a8:	aa010000 	orr	x0, x0, x1
    81ac:	b40002c0 	cbz	x0, 8204 <fwp_write+0xf40>
    81b0:	110006b5 	add	w21, w21, #0x1
    81b4:	91004273 	add	x19, x19, #0x10
    81b8:	710016bf 	cmp	w21, #0x5
    81bc:	54fffe81 	b.ne	818c <fwp_write+0xec8>  // b.any
    81c0:	17ffffde 	b	8138 <fwp_write+0xe74>
    81c4:	f9400a60 	ldr	x0, [x19, #16]
    81c8:	8b000021 	add	x1, x1, x0
    81cc:	17fffd75 	b	77a0 <fwp_write+0x4dc>
    81d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    81d4:	910123f5 	add	x21, sp, #0x48
    81d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    81dc:	b9004be0 	str	w0, [sp, #72]
    81e0:	17fffda2 	b	7868 <fwp_write+0x5a4>
    81e4:	528005a1 	mov	w1, #0x2d                  	// #45
    81e8:	eb1603e2 	negs	x2, x22
    81ec:	da1803e3 	ngc	x3, x24
    81f0:	910027e0 	add	x0, sp, #0x9
    81f4:	910023f3 	add	x19, sp, #0x8
    81f8:	390023e1 	strb	w1, [sp, #8]
    81fc:	97ffeb09 	bl	2e20 <fwp_fmt_u128>
    8200:	17ffffd4 	b	8150 <fwp_write+0xe8c>
    8204:	aa1703e2 	mov	x2, x23
    8208:	aa1a03e3 	mov	x3, x26
    820c:	aa1603e0 	mov	x0, x22
    8210:	aa1803e1 	mov	x1, x24
    8214:	940008a7 	bl	a4b0 <__divti3>
    8218:	aa0003e2 	mov	x2, x0
    821c:	aa0103e3 	mov	x3, x1
    8220:	b7f80201 	tbnz	x1, #63, 8260 <fwp_write+0xf9c>
    8224:	910023f3 	add	x19, sp, #0x8
    8228:	aa1303e0 	mov	x0, x19
    822c:	97ffeafd 	bl	2e20 <fwp_fmt_u128>
    8230:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8234:	910aa339 	add	x25, x25, #0x2a8
    8238:	910123f5 	add	x21, sp, #0x48
    823c:	aa1303e4 	mov	x4, x19
    8240:	aa1503e0 	mov	x0, x21
    8244:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x430>
    8248:	f8616b25 	ldr	x5, [x25, x1]
    824c:	91026063 	add	x3, x3, #0x98
    8250:	d2804002 	mov	x2, #0x200                 	// #512
    8254:	52800041 	mov	w1, #0x2                   	// #2
    8258:	97ffe932 	bl	2720 <__sprintf_chk@plt>
    825c:	17ffffc5 	b	8170 <fwp_write+0xeac>
    8260:	528005a4 	mov	w4, #0x2d                  	// #45
    8264:	eb0003e2 	negs	x2, x0
    8268:	da0103e3 	ngc	x3, x1
    826c:	910027e0 	add	x0, sp, #0x9
    8270:	910023f3 	add	x19, sp, #0x8
    8274:	390023e4 	strb	w4, [sp, #8]
    8278:	97ffeaea 	bl	2e20 <fwp_fmt_u128>
    827c:	17ffffed 	b	8230 <fwp_write+0xf6c>
    8280:	f9013bf5 	str	x21, [sp, #624]
    8284:	f9013ff6 	str	x22, [sp, #632]
    8288:	f90143f7 	str	x23, [sp, #640]
    828c:	f90147f8 	str	x24, [sp, #648]
    8290:	f9014bf9 	str	x25, [sp, #656]
    8294:	f9014ffa 	str	x26, [sp, #664]
    8298:	f90153fb 	str	x27, [sp, #672]
    829c:	f90157fc 	str	x28, [sp, #680]
    82a0:	fd015be8 	str	d8, [sp, #688]
    82a4:	fd015fe9 	str	d9, [sp, #696]
    82a8:	97ffe976 	bl	2880 <__stack_chk_fail@plt>
    82ac:	d503201f 	nop

00000000000082b0 <fwp_main_thread>:
    82b0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    82b4:	910003fd 	mov	x29, sp
    82b8:	a90153f3 	stp	x19, x20, [sp, #16]
    82bc:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    82c0:	91150261 	add	x1, x19, #0x540
    82c4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    82c8:	f947f400 	ldr	x0, [x0, #4072]
    82cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    82d0:	a90363f7 	stp	x23, x24, [sp, #48]
    82d4:	d10783ff 	sub	sp, sp, #0x1e0
    82d8:	b953a421 	ldr	w1, [x1, #5028]
    82dc:	f9400002 	ldr	x2, [x0]
    82e0:	f900efe2 	str	x2, [sp, #472]
    82e4:	d2800002 	mov	x2, #0x0                   	// #0
    82e8:	34000e81 	cbz	w1, 84b8 <fwp_main_thread+0x208>
    82ec:	91150260 	add	x0, x19, #0x540
    82f0:	b953a800 	ldr	w0, [x0, #5032]
    82f4:	35000da0 	cbnz	w0, 84a8 <fwp_main_thread+0x1f8>
    82f8:	900000d4 	adrp	x20, 20000 <__data_start>
    82fc:	900000c2 	adrp	x2, 20000 <__data_start>
    8300:	9100c297 	add	x23, x20, #0x30
    8304:	910d8042 	add	x2, x2, #0x360
    8308:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    830c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8310:	910363f5 	add	x21, sp, #0xd8
    8314:	9102e3f8 	add	x24, sp, #0xb8
    8318:	aa1503e0 	mov	x0, x21
    831c:	d2800001 	mov	x1, #0x0                   	// #0
    8320:	a9018ef8 	stp	x24, x3, [x23, #24]
    8324:	f9006fe2 	str	x2, [sp, #216]
    8328:	b900e3ff 	str	wzr, [sp, #224]
    832c:	f90077e4 	str	x4, [sp, #232]
    8330:	97ffe8ec 	bl	26e0 <sigaltstack@plt>
    8334:	35000220 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    8338:	4f000400 	movi	v0.4s, #0x0
    833c:	910523e0 	add	x0, sp, #0x148
    8340:	f0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    8344:	9101c021 	add	x1, x1, #0x70
    8348:	f900a3e1 	str	x1, [sp, #320]
    834c:	52800082 	mov	w2, #0x4                   	// #4
    8350:	72a10002 	movk	w2, #0x800, lsl #16
    8354:	910503f6 	add	x22, sp, #0x140
    8358:	3d802000 	str	q0, [x0, #128]
    835c:	b901cbe2 	str	w2, [sp, #456]
    8360:	ad000000 	stp	q0, q0, [x0]
    8364:	ad010000 	stp	q0, q0, [x0, #32]
    8368:	ad020000 	stp	q0, q0, [x0, #64]
    836c:	ad030000 	stp	q0, q0, [x0, #96]
    8370:	97ffe934 	bl	2840 <sigemptyset@plt>
    8374:	34000100 	cbz	w0, 8394 <fwp_main_thread+0xe4>
    8378:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    837c:	9102e000 	add	x0, x0, #0xb8
    8380:	f90113f9 	str	x25, [sp, #544]
    8384:	f90117fa 	str	x26, [sp, #552]
    8388:	f9011bfb 	str	x27, [sp, #560]
    838c:	f9011ffc 	str	x28, [sp, #568]
    8390:	97ffeec0 	bl	3e90 <fwp_trap>
    8394:	aa1603e1 	mov	x1, x22
    8398:	d2800002 	mov	x2, #0x0                   	// #0
    839c:	52800160 	mov	w0, #0xb                   	// #11
    83a0:	97ffe940 	bl	28a0 <sigaction@plt>
    83a4:	35fffea0 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    83a8:	aa1603e1 	mov	x1, x22
    83ac:	d2800002 	mov	x2, #0x0                   	// #0
    83b0:	528000e0 	mov	w0, #0x7                   	// #7
    83b4:	97ffe93b 	bl	28a0 <sigaction@plt>
    83b8:	35fffe00 	cbnz	w0, 8378 <fwp_main_thread+0xc8>
    83bc:	b942f6e0 	ldr	w0, [x23, #756]
    83c0:	34000800 	cbz	w0, 84c0 <fwp_main_thread+0x210>
    83c4:	9100c296 	add	x22, x20, #0x30
    83c8:	f9400ad5 	ldr	x21, [x22, #16]
    83cc:	b40014f5 	cbz	x21, 8668 <fwp_main_thread+0x3b8>
    83d0:	910102b7 	add	x23, x21, #0x40
    83d4:	f90113f9 	str	x25, [sp, #544]
    83d8:	f90117fa 	str	x26, [sp, #552]
    83dc:	52800038 	mov	w24, #0x1                   	// #1
    83e0:	39414ab9 	ldrb	w25, [x21, #82]
    83e4:	39014ab8 	strb	w24, [x21, #82]
    83e8:	f94016a0 	ldr	x0, [x21, #40]
    83ec:	b4001380 	cbz	x0, 865c <fwp_main_thread+0x3ac>
    83f0:	f94032a1 	ldr	x1, [x21, #96]
    83f4:	394146a0 	ldrb	w0, [x21, #81]
    83f8:	b4000fa1 	cbz	x1, 85ec <fwp_main_thread+0x33c>
    83fc:	36000e60 	tbz	w0, #0, 85c8 <fwp_main_thread+0x318>
    8400:	f9400ad3 	ldr	x19, [x22, #16]
    8404:	f94022a0 	ldr	x0, [x21, #64]
    8408:	39414a61 	ldrb	w1, [x19, #82]
    840c:	37001181 	tbnz	w1, #0, 863c <fwp_main_thread+0x38c>
    8410:	f9403261 	ldr	x1, [x19, #96]
    8414:	a911fe77 	stp	x23, xzr, [x19, #280]
    8418:	f9009660 	str	x0, [x19, #296]
    841c:	b4000040 	cbz	x0, 8424 <fwp_main_thread+0x174>
    8420:	f9009013 	str	x19, [x0, #288]
    8424:	f90022b3 	str	x19, [x21, #64]
    8428:	b4000101 	cbz	x1, 8448 <fwp_main_thread+0x198>
    842c:	f94046c0 	ldr	x0, [x22, #136]
    8430:	39015678 	strb	w24, [x19, #85]
    8434:	f9003661 	str	x1, [x19, #104]
    8438:	a910827f 	stp	xzr, x0, [x19, #264]
    843c:	b4000040 	cbz	x0, 8444 <fwp_main_thread+0x194>
    8440:	f9008413 	str	x19, [x0, #264]
    8444:	f90046d3 	str	x19, [x22, #136]
    8448:	39015a7f 	strb	wzr, [x19, #86]
    844c:	97fff90d 	bl	6880 <fwp_block>
    8450:	f9408e62 	ldr	x2, [x19, #280]
    8454:	b4000142 	cbz	x2, 847c <fwp_main_thread+0x1cc>
    8458:	a9520261 	ldp	x1, x0, [x19, #288]
    845c:	b4000fc1 	cbz	x1, 8654 <fwp_main_thread+0x3a4>
    8460:	f9009420 	str	x0, [x1, #296]
    8464:	f9409660 	ldr	x0, [x19, #296]
    8468:	b4000040 	cbz	x0, 8470 <fwp_main_thread+0x1c0>
    846c:	f9009001 	str	x1, [x0, #288]
    8470:	91080260 	add	x0, x19, #0x200
    8474:	f900967f 	str	xzr, [x19, #296]
    8478:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    847c:	39415660 	ldrb	w0, [x19, #85]
    8480:	3607fb40 	tbz	w0, #0, 83e8 <fwp_main_thread+0x138>
    8484:	a9508261 	ldp	x1, x0, [x19, #264]
    8488:	b4001f81 	cbz	x1, 8878 <fwp_main_thread+0x5c8>
    848c:	f9008820 	str	x0, [x1, #272]
    8490:	b4000040 	cbz	x0, 8498 <fwp_main_thread+0x1e8>
    8494:	f9008401 	str	x1, [x0, #264]
    8498:	91080260 	add	x0, x19, #0x200
    849c:	3901567f 	strb	wzr, [x19, #85]
    84a0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    84a4:	17ffffd1 	b	83e8 <fwp_main_thread+0x138>
    84a8:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    84ac:	91261000 	add	x0, x0, #0x984
    84b0:	940009bc 	bl	aba0 <atexit>
    84b4:	17ffff91 	b	82f8 <fwp_main_thread+0x48>
    84b8:	97ffed8e 	bl	3af0 <fwp_heap_init>
    84bc:	17ffff8c 	b	82ec <fwp_main_thread+0x3c>
    84c0:	f94162e2 	ldr	x2, [x23, #704]
    84c4:	f90113f9 	str	x25, [sp, #544]
    84c8:	f90117fa 	str	x26, [sp, #552]
    84cc:	9101c3e3 	add	x3, sp, #0x70
    84d0:	f9011bfb 	str	x27, [sp, #560]
    84d4:	b0ffffe0 	adrp	x0, 5000 <fwp_tape_grow.constprop.0+0x15c>
    84d8:	f9011ffc 	str	x28, [sp, #568]
    84dc:	912cc000 	add	x0, x0, #0xb30
    84e0:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    84e4:	9115027a 	add	x26, x19, #0x540
    84e8:	913d4021 	add	x1, x1, #0xf50
    84ec:	d280001b 	mov	x27, #0x0                   	// #0
    84f0:	d280401c 	mov	x28, #0x200                 	// #512
    84f4:	a9000fff 	stp	xzr, x3, [sp]
    84f8:	a90707e2 	stp	x2, x1, [sp, #112]
    84fc:	f90043f8 	str	x24, [sp, #128]
    8500:	f9005fff 	str	xzr, [sp, #184]
    8504:	a90c83ff 	stp	xzr, x0, [sp, #200]
    8508:	f90162e3 	str	x3, [x23, #704]
    850c:	14000012 	b	8554 <fwp_main_thread+0x2a4>
    8510:	7100045f 	cmp	w2, #0x1
    8514:	540001a1 	b.ne	8548 <fwp_main_thread+0x298>  // b.any
    8518:	29430002 	ldp	w2, w0, [x0, #24]
    851c:	92403c21 	and	x1, x1, #0xffff
    8520:	9b027c21 	mul	x1, x1, x2
    8524:	d360fc21 	lsr	x1, x1, #32
    8528:	eb00003f 	cmp	x1, x0
    852c:	540000e2 	b.cs	8548 <fwp_main_thread+0x298>  // b.hs, b.nlast
    8530:	8b010318 	add	x24, x24, x1
    8534:	39400300 	ldrb	w0, [x24]
    8538:	7103fc1f 	cmp	w0, #0xff
    853c:	54003a80 	b.eq	8c8c <fwp_main_thread+0x9dc>  // b.none
    8540:	52800020 	mov	w0, #0x1                   	// #1
    8544:	39000300 	strb	w0, [x24]
    8548:	a90bfffb 	stp	x27, xzr, [sp, #184]
    854c:	aa1902f7 	orr	x23, x23, x25
    8550:	b4001997 	cbz	x23, 8880 <fwp_main_thread+0x5d0>
    8554:	f94003e0 	ldr	x0, [sp]
    8558:	f1000797 	subs	x23, x28, #0x1
    855c:	aa1603e1 	mov	x1, x22
    8560:	f90063f7 	str	x23, [sp, #192]
    8564:	da1f0019 	sbc	x25, x0, xzr
    8568:	52800020 	mov	w0, #0x1                   	// #1
    856c:	f90003f9 	str	x25, [sp]
    8570:	aa1703fc 	mov	x28, x23
    8574:	a9146ff7 	stp	x23, x27, [sp, #320]
    8578:	97fff203 	bl	4d84 <fwp_data.part.0.constprop.0>
    857c:	aa0003fb 	mov	x27, x0
    8580:	f949db41 	ldr	x1, [x26, #5040]
    8584:	f949ef40 	ldr	x0, [x26, #5080]
    8588:	cb010361 	sub	x1, x27, x1
    858c:	eb00403f 	cmp	x1, x0, lsl #16
    8590:	54fffdc2 	b.cs	8548 <fwp_main_thread+0x298>  // b.hs, b.nlast
    8594:	d350fc22 	lsr	x2, x1, #16
    8598:	f949ff46 	ldr	x6, [x26, #5112]
    859c:	8b020842 	add	x2, x2, x2, lsl #2
    85a0:	d37df042 	lsl	x2, x2, #3
    85a4:	8b0200c0 	add	x0, x6, x2
    85a8:	f9401018 	ldr	x24, [x0, #32]
    85ac:	b4fffcf8 	cbz	x24, 8548 <fwp_main_thread+0x298>
    85b0:	386268c2 	ldrb	w2, [x6, x2]
    85b4:	7100085f 	cmp	w2, #0x2
    85b8:	54fffac1 	b.ne	8510 <fwp_main_thread+0x260>  // b.any
    85bc:	72003c3f 	tst	w1, #0xffff
    85c0:	54fffc41 	b.ne	8548 <fwp_main_thread+0x298>  // b.any
    85c4:	17ffffdc 	b	8534 <fwp_main_thread+0x284>
    85c8:	97fff052 	bl	4710 <fwp_now_ns>
    85cc:	f94032a1 	ldr	x1, [x21, #96]
    85d0:	eb01001f 	cmp	x0, x1
    85d4:	540000ab 	b.lt	85e8 <fwp_main_thread+0x338>  // b.tstop
    85d8:	394142a0 	ldrb	w0, [x21, #80]
    85dc:	37000060 	tbnz	w0, #0, 85e8 <fwp_main_thread+0x338>
    85e0:	aa1503e0 	mov	x0, x21
    85e4:	97ffeba3 	bl	3470 <fwp_cancel_tree.part.0>
    85e8:	394146a0 	ldrb	w0, [x21, #81]
    85ec:	f9400ad3 	ldr	x19, [x22, #16]
    85f0:	39414a62 	ldrb	w2, [x19, #82]
    85f4:	3707f060 	tbnz	w0, #0, 8400 <fwp_main_thread+0x150>
    85f8:	f94032a1 	ldr	x1, [x21, #96]
    85fc:	370001c2 	tbnz	w2, #0, 8634 <fwp_main_thread+0x384>
    8600:	f9403260 	ldr	x0, [x19, #96]
    8604:	b4000180 	cbz	x0, 8634 <fwp_main_thread+0x384>
    8608:	b4000061 	cbz	x1, 8614 <fwp_main_thread+0x364>
    860c:	eb01001f 	cmp	x0, x1
    8610:	9a81d000 	csel	x0, x0, x1, le
    8614:	f94022a1 	ldr	x1, [x21, #64]
    8618:	a911fe77 	stp	x23, xzr, [x19, #280]
    861c:	f9009661 	str	x1, [x19, #296]
    8620:	b40033c1 	cbz	x1, 8c98 <fwp_main_thread+0x9e8>
    8624:	f9009033 	str	x19, [x1, #288]
    8628:	aa0003e1 	mov	x1, x0
    862c:	f90022b3 	str	x19, [x21, #64]
    8630:	17ffff7f 	b	842c <fwp_main_thread+0x17c>
    8634:	f94022a0 	ldr	x0, [x21, #64]
    8638:	17ffff77 	b	8414 <fwp_main_thread+0x164>
    863c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8640:	f9009660 	str	x0, [x19, #296]
    8644:	b4000040 	cbz	x0, 864c <fwp_main_thread+0x39c>
    8648:	f9009013 	str	x19, [x0, #288]
    864c:	f90022b3 	str	x19, [x21, #64]
    8650:	17ffff7e 	b	8448 <fwp_main_thread+0x198>
    8654:	f9000040 	str	x0, [x2]
    8658:	17ffff84 	b	8468 <fwp_main_thread+0x1b8>
    865c:	f94117fa 	ldr	x26, [sp, #552]
    8660:	39014ab9 	strb	w25, [x21, #82]
    8664:	f94113f9 	ldr	x25, [sp, #544]
    8668:	9100c293 	add	x19, x20, #0x30
    866c:	f9416e60 	ldr	x0, [x19, #728]
    8670:	b5000060 	cbnz	x0, 867c <fwp_main_thread+0x3cc>
    8674:	f9417660 	ldr	x0, [x19, #744]
    8678:	b40047a0 	cbz	x0, 8f6c <fwp_main_thread+0xcbc>
    867c:	9100c280 	add	x0, x20, #0x30
    8680:	f9400800 	ldr	x0, [x0, #16]
    8684:	9100c281 	add	x1, x20, #0x30
    8688:	f9418826 	ldr	x6, [x1, #784]
    868c:	b903083f 	str	wzr, [x1, #776]
    8690:	eb0000df 	cmp	x6, x0
    8694:	5400f021 	b.ne	a498 <fwp_main_thread+0x21e8>  // b.any
    8698:	b40003e0 	cbz	x0, 8714 <fwp_main_thread+0x464>
    869c:	f9415825 	ldr	x5, [x1, #688]
    86a0:	52800021 	mov	w1, #0x1                   	// #1
    86a4:	39014801 	strb	w1, [x0, #82]
    86a8:	b4000365 	cbz	x5, 8714 <fwp_main_thread+0x464>
    86ac:	d503201f 	nop
    86b0:	394140a0 	ldrb	w0, [x5, #80]
    86b4:	37000060 	tbnz	w0, #0, 86c0 <fwp_main_thread+0x410>
    86b8:	aa0503e0 	mov	x0, x5
    86bc:	97ffeb6d 	bl	3470 <fwp_cancel_tree.part.0>
    86c0:	f9409ca5 	ldr	x5, [x5, #312]
    86c4:	b5ffff65 	cbnz	x5, 86b0 <fwp_main_thread+0x400>
    86c8:	9100c293 	add	x19, x20, #0x30
    86cc:	52800035 	mov	w21, #0x1                   	// #1
    86d0:	f94028c0 	ldr	x0, [x6, #80]
    86d4:	f2001c1f 	tst	x0, #0xff000000ff
    86d8:	540000e1 	b.ne	86f4 <fwp_main_thread+0x444>  // b.any
    86dc:	f9401660 	ldr	x0, [x19, #40]
    86e0:	390150d5 	strb	w21, [x6, #84]
    86e4:	f90080df 	str	xzr, [x6, #256]
    86e8:	b4000120 	cbz	x0, 870c <fwp_main_thread+0x45c>
    86ec:	f9008006 	str	x6, [x0, #256]
    86f0:	f9001666 	str	x6, [x19, #40]
    86f4:	97fff863 	bl	6880 <fwp_block>
    86f8:	97fff7ea 	bl	66a0 <fwp_free_zombie>
    86fc:	f9415a60 	ldr	x0, [x19, #688]
    8700:	b40000a0 	cbz	x0, 8714 <fwp_main_thread+0x464>
    8704:	f9418a66 	ldr	x6, [x19, #784]
    8708:	17fffff2 	b	86d0 <fwp_main_thread+0x420>
    870c:	f9001a66 	str	x6, [x19, #48]
    8710:	17fffff8 	b	86f0 <fwp_main_thread+0x440>
    8714:	9100c295 	add	x21, x20, #0x30
    8718:	97fff7e2 	bl	66a0 <fwp_free_zombie>
    871c:	f9401aa0 	ldr	x0, [x21, #48]
    8720:	b500ebc0 	cbnz	x0, a498 <fwp_main_thread+0x21e8>
    8724:	f94046a0 	ldr	x0, [x21, #136]
    8728:	b500eb80 	cbnz	x0, a498 <fwp_main_thread+0x21e8>
    872c:	b940aab3 	ldr	w19, [x21, #168]
    8730:	340001f3 	cbz	w19, 876c <fwp_main_thread+0x4bc>
    8734:	93407e76 	sxtw	x22, w19
    8738:	51000673 	sub	w19, w19, #0x1
    873c:	d1000ad6 	sub	x22, x22, #0x2
    8740:	9102c2b7 	add	x23, x21, #0xb0
    8744:	cb3342d6 	sub	x22, x22, w19, uxtw
    8748:	93407e73 	sxtw	x19, w19
    874c:	d503201f 	nop
    8750:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8754:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8758:	b900aab3 	str	w19, [x21, #168]
    875c:	d1000673 	sub	x19, x19, #0x1
    8760:	97ffe890 	bl	29a0 <munmap@plt>
    8764:	eb16027f 	cmp	x19, x22
    8768:	54ffff41 	b.ne	8750 <fwp_main_thread+0x4a0>  // b.any
    876c:	900000d7 	adrp	x23, 20000 <__data_start>
    8770:	910042e0 	add	x0, x23, #0x10
    8774:	b9400800 	ldr	w0, [x0, #8]
    8778:	37f80040 	tbnz	w0, #31, 8780 <fwp_main_thread+0x4d0>
    877c:	97ffe845 	bl	2890 <close@plt>
    8780:	9100c295 	add	x21, x20, #0x30
    8784:	910042f7 	add	x23, x23, #0x10
    8788:	12800001 	mov	w1, #0xffffffff            	// #-1
    878c:	f94192a0 	ldr	x0, [x21, #800]
    8790:	b9000ae1 	str	w1, [x23, #8]
    8794:	f9418ea1 	ldr	x1, [x21, #792]
    8798:	b40001c0 	cbz	x0, 87d0 <fwp_main_thread+0x520>
    879c:	d2800013 	mov	x19, #0x0                   	// #0
    87a0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    87a4:	b40000e0 	cbz	x0, 87c0 <fwp_main_thread+0x510>
    87a8:	f9400001 	ldr	x1, [x0]
    87ac:	b500e761 	cbnz	x1, a498 <fwp_main_thread+0x21e8>
    87b0:	f9400401 	ldr	x1, [x0, #8]
    87b4:	b500e721 	cbnz	x1, a498 <fwp_main_thread+0x21e8>
    87b8:	97ffee72 	bl	4180 <fwp_mem_free>
    87bc:	f9418ea1 	ldr	x1, [x21, #792]
    87c0:	91000673 	add	x19, x19, #0x1
    87c4:	f94192a0 	ldr	x0, [x21, #800]
    87c8:	eb00027f 	cmp	x19, x0
    87cc:	54fffea3 	b.cc	87a0 <fwp_main_thread+0x4f0>  // b.lo, b.ul, b.last
    87d0:	aa0103e0 	mov	x0, x1
    87d4:	97ffee6b 	bl	4180 <fwp_mem_free>
    87d8:	9100c280 	add	x0, x20, #0x30
    87dc:	f9418813 	ldr	x19, [x0, #784]
    87e0:	f9018c1f 	str	xzr, [x0, #792]
    87e4:	f901901f 	str	xzr, [x0, #800]
    87e8:	b40001f3 	cbz	x19, 8824 <fwp_main_thread+0x574>
    87ec:	f9401661 	ldr	x1, [x19, #40]
    87f0:	b500e541 	cbnz	x1, a498 <fwp_main_thread+0x21e8>
    87f4:	f9405661 	ldr	x1, [x19, #168]
    87f8:	b500e501 	cbnz	x1, a498 <fwp_main_thread+0x21e8>
    87fc:	f9416c01 	ldr	x1, [x0, #728]
    8800:	b500e4c1 	cbnz	x1, a498 <fwp_main_thread+0x21e8>
    8804:	f9417400 	ldr	x0, [x0, #744]
    8808:	b500e480 	cbnz	x0, a498 <fwp_main_thread+0x21e8>
    880c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8810:	90000140 	adrp	x0, 30000 <alt.5+0xfca0>
    8814:	910d8000 	add	x0, x0, #0x360
    8818:	97ffe80e 	bl	2850 <memset@plt>
    881c:	aa1303e0 	mov	x0, x19
    8820:	97ffee58 	bl	4180 <fwp_mem_free>
    8824:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8828:	f947ec00 	ldr	x0, [x0, #4056]
    882c:	9100c294 	add	x20, x20, #0x30
    8830:	f9400000 	ldr	x0, [x0]
    8834:	f9000a9f 	str	xzr, [x20, #16]
    8838:	f9018a9f 	str	xzr, [x20, #784]
    883c:	97ffe85d 	bl	29b0 <fflush@plt>
    8840:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8844:	f947f400 	ldr	x0, [x0, #4072]
    8848:	f940efe2 	ldr	x2, [sp, #472]
    884c:	f9400001 	ldr	x1, [x0]
    8850:	eb010042 	subs	x2, x2, x1
    8854:	d2800001 	mov	x1, #0x0                   	// #0
    8858:	5400dde1 	b.ne	a414 <fwp_main_thread+0x2164>  // b.any
    885c:	910783ff 	add	sp, sp, #0x1e0
    8860:	d2800000 	mov	x0, #0x0                   	// #0
    8864:	a94153f3 	ldp	x19, x20, [sp, #16]
    8868:	a9425bf5 	ldp	x21, x22, [sp, #32]
    886c:	a94363f7 	ldp	x23, x24, [sp, #48]
    8870:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8874:	d65f03c0 	ret
    8878:	f90046c0 	str	x0, [x22, #136]
    887c:	17ffff05 	b	8490 <fwp_main_thread+0x1e0>
    8880:	9100c282 	add	x2, x20, #0x30
    8884:	f9005fff 	str	xzr, [sp, #184]
    8888:	f94007e1 	ldr	x1, [sp, #8]
    888c:	f9416040 	ldr	x0, [x2, #704]
    8890:	eb01001f 	cmp	x0, x1
    8894:	5400e0a1 	b.ne	a4a8 <fwp_main_thread+0x21f8>  // b.any
    8898:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    889c:	910443e1 	add	x1, sp, #0x110
    88a0:	f9403be3 	ldr	x3, [sp, #112]
    88a4:	f9016043 	str	x3, [x2, #704]
    88a8:	3dc22c00 	ldr	q0, [x0, #2224]
    88ac:	52800020 	mov	w0, #0x1                   	// #1
    88b0:	3d8047e0 	str	q0, [sp, #272]
    88b4:	97fff134 	bl	4d84 <fwp_data.part.0.constprop.0>
    88b8:	91150263 	add	x3, x19, #0x540
    88bc:	aa0003f7 	mov	x23, x0
    88c0:	f949d861 	ldr	x1, [x3, #5040]
    88c4:	f949ec60 	ldr	x0, [x3, #5080]
    88c8:	cb0102e1 	sub	x1, x23, x1
    88cc:	eb00403f 	cmp	x1, x0, lsl #16
    88d0:	54000322 	b.cs	8934 <fwp_main_thread+0x684>  // b.hs, b.nlast
    88d4:	d350fc22 	lsr	x2, x1, #16
    88d8:	f949fc63 	ldr	x3, [x3, #5112]
    88dc:	8b020842 	add	x2, x2, x2, lsl #2
    88e0:	d37df042 	lsl	x2, x2, #3
    88e4:	8b020060 	add	x0, x3, x2
    88e8:	f9401018 	ldr	x24, [x0, #32]
    88ec:	b4000258 	cbz	x24, 8934 <fwp_main_thread+0x684>
    88f0:	38626862 	ldrb	w2, [x3, x2]
    88f4:	7100085f 	cmp	w2, #0x2
    88f8:	54001d60 	b.eq	8ca4 <fwp_main_thread+0x9f4>  // b.none
    88fc:	7100045f 	cmp	w2, #0x1
    8900:	540001a1 	b.ne	8934 <fwp_main_thread+0x684>  // b.any
    8904:	29430002 	ldp	w2, w0, [x0, #24]
    8908:	92403c21 	and	x1, x1, #0xffff
    890c:	9b027c21 	mul	x1, x1, x2
    8910:	d360fc21 	lsr	x1, x1, #32
    8914:	eb00003f 	cmp	x1, x0
    8918:	540000e2 	b.cs	8934 <fwp_main_thread+0x684>  // b.hs, b.nlast
    891c:	8b010318 	add	x24, x24, x1
    8920:	39400300 	ldrb	w0, [x24]
    8924:	7103fc1f 	cmp	w0, #0xff
    8928:	54005fc0 	b.eq	9520 <fwp_main_thread+0x1270>  // b.none
    892c:	52800020 	mov	w0, #0x1                   	// #1
    8930:	39000300 	strb	w0, [x24]
    8934:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8938:	9104c3e1 	add	x1, sp, #0x130
    893c:	52800020 	mov	w0, #0x1                   	// #1
    8940:	a9135fe2 	stp	x2, x23, [sp, #304]
    8944:	97fff110 	bl	4d84 <fwp_data.part.0.constprop.0>
    8948:	91150263 	add	x3, x19, #0x540
    894c:	aa0003f7 	mov	x23, x0
    8950:	f949d861 	ldr	x1, [x3, #5040]
    8954:	f949ec60 	ldr	x0, [x3, #5080]
    8958:	cb0102e1 	sub	x1, x23, x1
    895c:	eb00403f 	cmp	x1, x0, lsl #16
    8960:	54000322 	b.cs	89c4 <fwp_main_thread+0x714>  // b.hs, b.nlast
    8964:	d350fc22 	lsr	x2, x1, #16
    8968:	f949fc63 	ldr	x3, [x3, #5112]
    896c:	8b020842 	add	x2, x2, x2, lsl #2
    8970:	d37df042 	lsl	x2, x2, #3
    8974:	8b020060 	add	x0, x3, x2
    8978:	f9401018 	ldr	x24, [x0, #32]
    897c:	b4000258 	cbz	x24, 89c4 <fwp_main_thread+0x714>
    8980:	38626862 	ldrb	w2, [x3, x2]
    8984:	7100085f 	cmp	w2, #0x2
    8988:	540019a0 	b.eq	8cbc <fwp_main_thread+0xa0c>  // b.none
    898c:	7100045f 	cmp	w2, #0x1
    8990:	540001a1 	b.ne	89c4 <fwp_main_thread+0x714>  // b.any
    8994:	29430002 	ldp	w2, w0, [x0, #24]
    8998:	92403c21 	and	x1, x1, #0xffff
    899c:	9b027c21 	mul	x1, x1, x2
    89a0:	d360fc21 	lsr	x1, x1, #32
    89a4:	eb00003f 	cmp	x1, x0
    89a8:	540000e2 	b.cs	89c4 <fwp_main_thread+0x714>  // b.hs, b.nlast
    89ac:	8b010318 	add	x24, x24, x1
    89b0:	39400300 	ldrb	w0, [x24]
    89b4:	7103fc1f 	cmp	w0, #0xff
    89b8:	54005ba0 	b.eq	952c <fwp_main_thread+0x127c>  // b.none
    89bc:	52800020 	mov	w0, #0x1                   	// #1
    89c0:	39000300 	strb	w0, [x24]
    89c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    89c8:	910483e1 	add	x1, sp, #0x120
    89cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    89d0:	52800020 	mov	w0, #0x1                   	// #1
    89d4:	a9125fe2 	stp	x2, x23, [sp, #288]
    89d8:	97fff0eb 	bl	4d84 <fwp_data.part.0.constprop.0>
    89dc:	91150262 	add	x2, x19, #0x540
    89e0:	aa0003f8 	mov	x24, x0
    89e4:	f949d841 	ldr	x1, [x2, #5040]
    89e8:	f949ec40 	ldr	x0, [x2, #5080]
    89ec:	cb010301 	sub	x1, x24, x1
    89f0:	eb00403f 	cmp	x1, x0, lsl #16
    89f4:	54000322 	b.cs	8a58 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    89f8:	d350fc20 	lsr	x0, x1, #16
    89fc:	f949fc43 	ldr	x3, [x2, #5112]
    8a00:	8b000800 	add	x0, x0, x0, lsl #2
    8a04:	d37df002 	lsl	x2, x0, #3
    8a08:	8b020060 	add	x0, x3, x2
    8a0c:	f9401017 	ldr	x23, [x0, #32]
    8a10:	b4000257 	cbz	x23, 8a58 <fwp_main_thread+0x7a8>
    8a14:	38626862 	ldrb	w2, [x3, x2]
    8a18:	7100085f 	cmp	w2, #0x2
    8a1c:	54001560 	b.eq	8cc8 <fwp_main_thread+0xa18>  // b.none
    8a20:	7100045f 	cmp	w2, #0x1
    8a24:	540001a1 	b.ne	8a58 <fwp_main_thread+0x7a8>  // b.any
    8a28:	29430002 	ldp	w2, w0, [x0, #24]
    8a2c:	92403c21 	and	x1, x1, #0xffff
    8a30:	9b027c21 	mul	x1, x1, x2
    8a34:	d360fc21 	lsr	x1, x1, #32
    8a38:	eb00003f 	cmp	x1, x0
    8a3c:	540000e2 	b.cs	8a58 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    8a40:	8b0102f7 	add	x23, x23, x1
    8a44:	394002e0 	ldrb	w0, [x23]
    8a48:	7103fc1f 	cmp	w0, #0xff
    8a4c:	54005760 	b.eq	9538 <fwp_main_thread+0x1288>  // b.none
    8a50:	52800020 	mov	w0, #0x1                   	// #1
    8a54:	390002e0 	strb	w0, [x23]
    8a58:	b40040db 	cbz	x27, 9270 <fwp_main_thread+0xfc0>
    8a5c:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x7c>
    8a60:	9106c000 	add	x0, x0, #0x1b0
    8a64:	900000d7 	adrp	x23, 20000 <__data_start>
    8a68:	91150279 	add	x25, x19, #0x540
    8a6c:	910042f7 	add	x23, x23, #0x10
    8a70:	9100c29a 	add	x26, x20, #0x30
    8a74:	a9016fe0 	stp	x0, x27, [sp, #16]
    8a78:	9101a3e0 	add	x0, sp, #0x68
    8a7c:	f90007e0 	str	x0, [sp, #8]
    8a80:	910223e0 	add	x0, sp, #0x88
    8a84:	f90003e0 	str	x0, [sp]
    8a88:	f949ef25 	ldr	x5, [x25, #5080]
    8a8c:	f949db21 	ldr	x1, [x25, #5040]
    8a90:	d370bca5 	lsl	x5, x5, #16
    8a94:	cb010303 	sub	x3, x24, x1
    8a98:	eb05007f 	cmp	x3, x5
    8a9c:	540003e2 	b.cs	8b18 <fwp_main_thread+0x868>  // b.hs, b.nlast
    8aa0:	d350fc60 	lsr	x0, x3, #16
    8aa4:	f949ff27 	ldr	x7, [x25, #5112]
    8aa8:	8b000800 	add	x0, x0, x0, lsl #2
    8aac:	d37df002 	lsl	x2, x0, #3
    8ab0:	8b0200e6 	add	x6, x7, x2
    8ab4:	f94010c0 	ldr	x0, [x6, #32]
    8ab8:	b4000300 	cbz	x0, 8b18 <fwp_main_thread+0x868>
    8abc:	386268e2 	ldrb	w2, [x7, x2]
    8ac0:	7100085f 	cmp	w2, #0x2
    8ac4:	54001080 	b.eq	8cd4 <fwp_main_thread+0xa24>  // b.none
    8ac8:	7100045f 	cmp	w2, #0x1
    8acc:	54000261 	b.ne	8b18 <fwp_main_thread+0x868>  // b.any
    8ad0:	92403c62 	and	x2, x3, #0xffff
    8ad4:	29430cc7 	ldp	w7, w3, [x6, #24]
    8ad8:	9b077c42 	mul	x2, x2, x7
    8adc:	d360fc42 	lsr	x2, x2, #32
    8ae0:	eb03005f 	cmp	x2, x3
    8ae4:	540001a2 	b.cs	8b18 <fwp_main_thread+0x868>  // b.hs, b.nlast
    8ae8:	8b020000 	add	x0, x0, x2
    8aec:	39400002 	ldrb	w2, [x0]
    8af0:	34000142 	cbz	w2, 8b18 <fwp_main_thread+0x868>
    8af4:	7103f45f 	cmp	w2, #0xfd
    8af8:	540057a8 	b.hi	95ec <fwp_main_thread+0x133c>  // b.pmore
    8afc:	91150261 	add	x1, x19, #0x540
    8b00:	11000442 	add	w2, w2, #0x1
    8b04:	39000002 	strb	w2, [x0]
    8b08:	aa0103e0 	mov	x0, x1
    8b0c:	f949d821 	ldr	x1, [x1, #5040]
    8b10:	f949ec05 	ldr	x5, [x0, #5080]
    8b14:	d370bca5 	lsl	x5, x5, #16
    8b18:	f9416340 	ldr	x0, [x26, #704]
    8b1c:	f90047e0 	str	x0, [sp, #136]
    8b20:	f9400be0 	ldr	x0, [sp, #16]
    8b24:	f9004be0 	str	x0, [sp, #144]
    8b28:	f94007e0 	ldr	x0, [sp, #8]
    8b2c:	f9004fe0 	str	x0, [sp, #152]
    8b30:	f94003e0 	ldr	x0, [sp]
    8b34:	12800002 	mov	w2, #0xffffffff            	// #-1
    8b38:	cb0102e1 	sub	x1, x23, x1
    8b3c:	b9006be2 	str	w2, [sp, #104]
    8b40:	f9016340 	str	x0, [x26, #704]
    8b44:	eb05003f 	cmp	x1, x5
    8b48:	54000782 	b.cs	8c38 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8b4c:	91150262 	add	x2, x19, #0x540
    8b50:	d350fc20 	lsr	x0, x1, #16
    8b54:	8b000800 	add	x0, x0, x0, lsl #2
    8b58:	f949fc45 	ldr	x5, [x2, #5112]
    8b5c:	d37df003 	lsl	x3, x0, #3
    8b60:	8b0300a2 	add	x2, x5, x3
    8b64:	f940105c 	ldr	x28, [x2, #32]
    8b68:	b400069c 	cbz	x28, 8c38 <fwp_main_thread+0x988>
    8b6c:	386368a0 	ldrb	w0, [x5, x3]
    8b70:	7100081f 	cmp	w0, #0x2
    8b74:	54000b60 	b.eq	8ce0 <fwp_main_thread+0xa30>  // b.none
    8b78:	7100041f 	cmp	w0, #0x1
    8b7c:	540005e1 	b.ne	8c38 <fwp_main_thread+0x988>  // b.any
    8b80:	29430c45 	ldp	w5, w3, [x2, #24]
    8b84:	92403c20 	and	x0, x1, #0xffff
    8b88:	9b057c00 	mul	x0, x0, x5
    8b8c:	d360fc00 	lsr	x0, x0, #32
    8b90:	eb03001f 	cmp	x0, x3
    8b94:	54000282 	b.cs	8be4 <fwp_main_thread+0x934>  // b.hs, b.nlast
    8b98:	8b000380 	add	x0, x28, x0
    8b9c:	39400003 	ldrb	w3, [x0]
    8ba0:	34000223 	cbz	w3, 8be4 <fwp_main_thread+0x934>
    8ba4:	7103f47f 	cmp	w3, #0xfd
    8ba8:	54005668 	b.hi	9674 <fwp_main_thread+0x13c4>  // b.pmore
    8bac:	11000463 	add	w3, w3, #0x1
    8bb0:	39000003 	strb	w3, [x0]
    8bb4:	91150260 	add	x0, x19, #0x540
    8bb8:	f949d801 	ldr	x1, [x0, #5040]
    8bbc:	f949ec02 	ldr	x2, [x0, #5080]
    8bc0:	cb0102e1 	sub	x1, x23, x1
    8bc4:	eb02403f 	cmp	x1, x2, lsl #16
    8bc8:	54000382 	b.cs	8c38 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8bcc:	f949fc02 	ldr	x2, [x0, #5112]
    8bd0:	d350fc20 	lsr	x0, x1, #16
    8bd4:	8b000800 	add	x0, x0, x0, lsl #2
    8bd8:	8b000c42 	add	x2, x2, x0, lsl #3
    8bdc:	f940105c 	ldr	x28, [x2, #32]
    8be0:	b40002dc 	cbz	x28, 8c38 <fwp_main_thread+0x988>
    8be4:	39400040 	ldrb	w0, [x2]
    8be8:	7100081f 	cmp	w0, #0x2
    8bec:	54000820 	b.eq	8cf0 <fwp_main_thread+0xa40>  // b.none
    8bf0:	7100041f 	cmp	w0, #0x1
    8bf4:	54000221 	b.ne	8c38 <fwp_main_thread+0x988>  // b.any
    8bf8:	29430043 	ldp	w3, w0, [x2, #24]
    8bfc:	92403c21 	and	x1, x1, #0xffff
    8c00:	9b037c21 	mul	x1, x1, x3
    8c04:	d360fc21 	lsr	x1, x1, #32
    8c08:	eb00003f 	cmp	x1, x0
    8c0c:	54000162 	b.cs	8c38 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8c10:	8b01039c 	add	x28, x28, x1
    8c14:	39400380 	ldrb	w0, [x28]
    8c18:	34000100 	cbz	w0, 8c38 <fwp_main_thread+0x988>
    8c1c:	7100041f 	cmp	w0, #0x1
    8c20:	54000260 	b.eq	8c6c <fwp_main_thread+0x9bc>  // b.none
    8c24:	7103fc1f 	cmp	w0, #0xff
    8c28:	54004ee0 	b.eq	9604 <fwp_main_thread+0x1354>  // b.none
    8c2c:	51000400 	sub	w0, w0, #0x1
    8c30:	39000380 	strb	w0, [x28]
    8c34:	d503201f 	nop
    8c38:	b4004718 	cbz	x24, 9518 <fwp_main_thread+0x1268>
    8c3c:	aa1803e0 	mov	x0, x24
    8c40:	d2800001 	mov	x1, #0x0                   	// #0
    8c44:	d503201f 	nop
    8c48:	f9400800 	ldr	x0, [x0, #16]
    8c4c:	91000421 	add	x1, x1, #0x1
    8c50:	b5ffffc0 	cbnz	x0, 8c48 <fwp_main_thread+0x998>
    8c54:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8c58:	eb00003f 	cmp	x1, x0
    8c5c:	54000509 	b.ls	8cfc <fwp_main_thread+0xa4c>  // b.plast
    8c60:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    8c64:	91038000 	add	x0, x0, #0xe0
    8c68:	97ffec8a 	bl	3e90 <fwp_trap>
    8c6c:	d53bd040 	mrs	x0, tpidr_el0
    8c70:	91400000 	add	x0, x0, #0x0, lsl #12
    8c74:	91004000 	add	x0, x0, #0x10
    8c78:	f9400000 	ldr	x0, [x0]
    8c7c:	b40001a0 	cbz	x0, 8cb0 <fwp_main_thread+0xa00>
    8c80:	aa1703e1 	mov	x1, x23
    8c84:	97ffedff 	bl	4480 <fwp_closure_drop_push>
    8c88:	17ffffec 	b	8c38 <fwp_main_thread+0x988>
    8c8c:	aa1803e0 	mov	x0, x24
    8c90:	97ffeca0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8c94:	17fffe2b 	b	8540 <fwp_main_thread+0x290>
    8c98:	aa0003e1 	mov	x1, x0
    8c9c:	f90022b3 	str	x19, [x21, #64]
    8ca0:	17fffde3 	b	842c <fwp_main_thread+0x17c>
    8ca4:	72003c3f 	tst	w1, #0xffff
    8ca8:	54ffe461 	b.ne	8934 <fwp_main_thread+0x684>  // b.any
    8cac:	17ffff1d 	b	8920 <fwp_main_thread+0x670>
    8cb0:	aa1703e0 	mov	x0, x23
    8cb4:	97ffee38 	bl	4594 <fwp_closure_drop.part.0>
    8cb8:	17ffffe0 	b	8c38 <fwp_main_thread+0x988>
    8cbc:	72003c3f 	tst	w1, #0xffff
    8cc0:	54ffe821 	b.ne	89c4 <fwp_main_thread+0x714>  // b.any
    8cc4:	17ffff3b 	b	89b0 <fwp_main_thread+0x700>
    8cc8:	72003c3f 	tst	w1, #0xffff
    8ccc:	54ffec61 	b.ne	8a58 <fwp_main_thread+0x7a8>  // b.any
    8cd0:	17ffff5d 	b	8a44 <fwp_main_thread+0x794>
    8cd4:	72003c7f 	tst	w3, #0xffff
    8cd8:	54fff201 	b.ne	8b18 <fwp_main_thread+0x868>  // b.any
    8cdc:	17ffff84 	b	8aec <fwp_main_thread+0x83c>
    8ce0:	72003c3f 	tst	w1, #0xffff
    8ce4:	54fff801 	b.ne	8be4 <fwp_main_thread+0x934>  // b.any
    8ce8:	aa1c03e0 	mov	x0, x28
    8cec:	17ffffac 	b	8b9c <fwp_main_thread+0x8ec>
    8cf0:	72003c3f 	tst	w1, #0xffff
    8cf4:	54fffa21 	b.ne	8c38 <fwp_main_thread+0x988>  // b.any
    8cf8:	17ffffc7 	b	8c14 <fwp_main_thread+0x964>
    8cfc:	aa0103fc 	mov	x28, x1
    8d00:	9100c281 	add	x1, x20, #0x30
    8d04:	b942f820 	ldr	w0, [x1, #760]
    8d08:	34002ce0 	cbz	w0, 92a4 <fwp_main_thread+0xff4>
    8d0c:	9100c280 	add	x0, x20, #0x30
    8d10:	f9404003 	ldr	x3, [x0, #128]
    8d14:	f9404c01 	ldr	x1, [x0, #152]
    8d18:	eb03003f 	cmp	x1, x3
    8d1c:	54000faa 	b.ge	8f10 <fwp_main_thread+0xc60>  // b.tcont
    8d20:	f9401a82 	ldr	x2, [x20, #48]
    8d24:	8b010420 	add	x0, x1, x1, lsl #1
    8d28:	528fffc5 	mov	w5, #0x7ffe                	// #32766
    8d2c:	8b000820 	add	x0, x1, x0, lsl #2
    8d30:	8b000c40 	add	x0, x2, x0, lsl #3
    8d34:	d503201f 	nop
    8d38:	b9400402 	ldr	w2, [x0, #4]
    8d3c:	35000082 	cbnz	w2, 8d4c <fwp_main_thread+0xa9c>
    8d40:	b9400002 	ldr	w2, [x0]
    8d44:	6b05005f 	cmp	w2, w5
    8d48:	54000e49 	b.ls	8f10 <fwp_main_thread+0xc60>  // b.plast
    8d4c:	91000421 	add	x1, x1, #0x1
    8d50:	9101a000 	add	x0, x0, #0x68
    8d54:	eb03003f 	cmp	x1, x3
    8d58:	54ffff01 	b.ne	8d38 <fwp_main_thread+0xa88>  // b.any
    8d5c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8d60:	eb00007f 	cmp	x3, x0
    8d64:	540043ec 	b.gt	95e0 <fwp_main_thread+0x1330>
    8d68:	9100c280 	add	x0, x20, #0x30
    8d6c:	f9404800 	ldr	x0, [x0, #144]
    8d70:	eb03001f 	cmp	x0, x3
    8d74:	54000241 	b.ne	8dbc <fwp_main_thread+0xb0c>  // b.any
    8d78:	b40057e3 	cbz	x3, 9874 <fwp_main_thread+0x15c4>
    8d7c:	d37ff862 	lsl	x2, x3, #1
    8d80:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8d84:	eb00005f 	cmp	x2, x0
    8d88:	9a80d042 	csel	x2, x2, x0, le
    8d8c:	d2800d01 	mov	x1, #0x68                  	// #104
    8d90:	9100c285 	add	x5, x20, #0x30
    8d94:	f9401a80 	ldr	x0, [x20, #48]
    8d98:	9b017c41 	mul	x1, x2, x1
    8d9c:	a90217e2 	stp	x2, x5, [sp, #32]
    8da0:	f9001be3 	str	x3, [sp, #48]
    8da4:	97ffe6b3 	bl	2870 <realloc@plt>
    8da8:	a94217e2 	ldp	x2, x5, [sp, #32]
    8dac:	f9401be3 	ldr	x3, [sp, #48]
    8db0:	b400afc0 	cbz	x0, a3a8 <fwp_main_thread+0x20f8>
    8db4:	f9001a80 	str	x0, [x20, #48]
    8db8:	f90048a2 	str	x2, [x5, #144]
    8dbc:	8b030460 	add	x0, x3, x3, lsl #1
    8dc0:	9100c282 	add	x2, x20, #0x30
    8dc4:	f9401a87 	ldr	x7, [x20, #48]
    8dc8:	8b000860 	add	x0, x3, x0, lsl #2
    8dcc:	4f000400 	movi	v0.4s, #0x0
    8dd0:	aa0303e1 	mov	x1, x3
    8dd4:	91000463 	add	x3, x3, #0x1
    8dd8:	f9004043 	str	x3, [x2, #128]
    8ddc:	8b000ce0 	add	x0, x7, x0, lsl #3
    8de0:	f900301f 	str	xzr, [x0, #96]
    8de4:	ad000000 	stp	q0, q0, [x0]
    8de8:	ad010000 	stp	q0, q0, [x0, #32]
    8dec:	ad020000 	stp	q0, q0, [x0, #64]
    8df0:	8b010422 	add	x2, x1, x1, lsl #1
    8df4:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    8df8:	9133a000 	add	x0, x0, #0xce8
    8dfc:	8b020823 	add	x3, x1, x2, lsl #2
    8e00:	f9001be1 	str	x1, [sp, #48]
    8e04:	8b030ce3 	add	x3, x7, x3, lsl #3
    8e08:	a9021fe3 	stp	x3, x7, [sp, #32]
    8e0c:	f900307f 	str	xzr, [x3, #96]
    8e10:	97ffe700 	bl	2a10 <getenv@plt>
    8e14:	a9421fe3 	ldp	x3, x7, [sp, #32]
    8e18:	f9401be1 	ldr	x1, [sp, #48]
    8e1c:	b4000820 	cbz	x0, 8f20 <fwp_main_thread+0xc70>
    8e20:	39400002 	ldrb	w2, [x0]
    8e24:	7100c05f 	cmp	w2, #0x30
    8e28:	540007c1 	b.ne	8f20 <fwp_main_thread+0xc70>  // b.any
    8e2c:	39400400 	ldrb	w0, [x0, #1]
    8e30:	35000780 	cbnz	w0, 8f20 <fwp_main_thread+0xc70>
    8e34:	9100c282 	add	x2, x20, #0x30
    8e38:	2f000400 	mvni	v0.2s, #0x0
    8e3c:	b9400066 	ldr	w6, [x3]
    8e40:	91000428 	add	x8, x1, #0x1
    8e44:	52800025 	mov	w5, #0x1                   	// #1
    8e48:	a900f07c 	stp	x28, x28, [x3, #8]
    8e4c:	110004c6 	add	w6, w6, #0x1
    8e50:	f9416040 	ldr	x0, [x2, #704]
    8e54:	29001466 	stp	w6, w5, [x3]
    8e58:	f900287f 	str	xzr, [x3, #80]
    8e5c:	f9004c48 	str	x8, [x2, #152]
    8e60:	fd002c60 	str	d0, [x3, #88]
    8e64:	b4003b80 	cbz	x0, 95d4 <fwp_main_thread+0x1324>
    8e68:	d0ffffe2 	adrp	x2, 6000 <fwp_owned_tape_release+0x7c>
    8e6c:	9106c045 	add	x5, x2, #0x1b0
    8e70:	14000003 	b	8e7c <fwp_main_thread+0xbcc>
    8e74:	f9400000 	ldr	x0, [x0]
    8e78:	b4003ae0 	cbz	x0, 95d4 <fwp_main_thread+0x1324>
    8e7c:	f9400402 	ldr	x2, [x0, #8]
    8e80:	eb05005f 	cmp	x2, x5
    8e84:	54ffff81 	b.ne	8e74 <fwp_main_thread+0xbc4>  // b.any
    8e88:	f9400800 	ldr	x0, [x0, #16]
    8e8c:	2a0103e5 	mov	w5, w1
    8e90:	b9400002 	ldr	w2, [x0]
    8e94:	f9002860 	str	x0, [x3, #80]
    8e98:	b9005c62 	str	w2, [x3, #92]
    8e9c:	37f80082 	tbnz	w2, #31, 8eac <fwp_main_thread+0xbfc>
    8ea0:	52800d03 	mov	w3, #0x68                  	// #104
    8ea4:	9b231c42 	smaddl	x2, w2, w3, x7
    8ea8:	b9005841 	str	w1, [x2, #88]
    8eac:	b9000005 	str	w5, [x0]
    8eb0:	d2800002 	mov	x2, #0x0                   	// #0
    8eb4:	aa1803e0 	mov	x0, x24
    8eb8:	b4002098 	cbz	x24, 92c8 <fwp_main_thread+0x1018>
    8ebc:	d503201f 	nop
    8ec0:	f9400800 	ldr	x0, [x0, #16]
    8ec4:	91000442 	add	x2, x2, #0x1
    8ec8:	b5ffffc0 	cbnz	x0, 8ec0 <fwp_main_thread+0xc10>
    8ecc:	aa1803e1 	mov	x1, x24
    8ed0:	f9400821 	ldr	x1, [x1, #16]
    8ed4:	91000400 	add	x0, x0, #0x1
    8ed8:	b5ffffc1 	cbnz	x1, 8ed0 <fwp_main_thread+0xc20>
    8edc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8ee0:	eb01001f 	cmp	x0, x1
    8ee4:	54000108 	b.hi	8f04 <fwp_main_thread+0xc54>  // b.pmore
    8ee8:	f100005f 	cmp	x2, #0x0
    8eec:	54001eed 	b.le	92c8 <fwp_main_thread+0x1018>
    8ef0:	eb00005f 	cmp	x2, x0
    8ef4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8ef8:	9a80905c 	csel	x28, x2, x0, ls	// ls = plast
    8efc:	eb01039f 	cmp	x28, x1
    8f00:	54003be9 	b.ls	967c <fwp_main_thread+0x13cc>  // b.plast
    8f04:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    8f08:	913ee000 	add	x0, x0, #0xfb8
    8f0c:	97ffebe1 	bl	3e90 <fwp_trap>
    8f10:	eb01007f 	cmp	x3, x1
    8f14:	54fff240 	b.eq	8d5c <fwp_main_thread+0xaac>  // b.none
    8f18:	f9401a87 	ldr	x7, [x20, #48]
    8f1c:	17ffffb5 	b	8df0 <fwp_main_thread+0xb40>
    8f20:	9100c282 	add	x2, x20, #0x30
    8f24:	f9403840 	ldr	x0, [x2, #112]
    8f28:	b4fff860 	cbz	x0, 8e34 <fwp_main_thread+0xb84>
    8f2c:	3cc38042 	ldur	q2, [x2, #56]
    8f30:	9100e040 	add	x0, x2, #0x38
    8f34:	3cc48041 	ldur	q1, [x2, #72]
    8f38:	f900385f 	str	xzr, [x2, #112]
    8f3c:	4f000400 	movi	v0.4s, #0x0
    8f40:	ad010462 	stp	q2, q1, [x3, #32]
    8f44:	f9403442 	ldr	x2, [x2, #104]
    8f48:	f9002462 	str	x2, [x3, #72]
    8f4c:	f9401002 	ldr	x2, [x0, #32]
    8f50:	f9002062 	str	x2, [x3, #64]
    8f54:	f9401402 	ldr	x2, [x0, #40]
    8f58:	f9000c62 	str	x2, [x3, #24]
    8f5c:	f900181f 	str	xzr, [x0, #48]
    8f60:	ad000000 	stp	q0, q0, [x0]
    8f64:	3d800800 	str	q0, [x0, #32]
    8f68:	17ffffb3 	b	8e34 <fwp_main_thread+0xb84>
    8f6c:	f9416a60 	ldr	x0, [x19, #720]
    8f70:	97ffec84 	bl	4180 <fwp_mem_free>
    8f74:	f9016a7f 	str	xzr, [x19, #720]
    8f78:	f9400a60 	ldr	x0, [x19, #16]
    8f7c:	f901727f 	str	xzr, [x19, #736]
    8f80:	b4ffb820 	cbz	x0, 8684 <fwp_main_thread+0x3d4>
    8f84:	f900541f 	str	xzr, [x0, #168]
    8f88:	f9005c1f 	str	xzr, [x0, #184]
    8f8c:	17fffdbe 	b	8684 <fwp_main_thread+0x3d4>
    8f90:	aa0303e0 	mov	x0, x3
    8f94:	f90017e2 	str	x2, [sp, #40]
    8f98:	97ffec7a 	bl	4180 <fwp_mem_free>
    8f9c:	f94017e2 	ldr	x2, [sp, #40]
    8fa0:	91150267 	add	x7, x19, #0x540
    8fa4:	d2800508 	mov	x8, #0x28                  	// #40
    8fa8:	f949d8e1 	ldr	x1, [x7, #5040]
    8fac:	f949ece0 	ldr	x0, [x7, #5080]
    8fb0:	cb010041 	sub	x1, x2, x1
    8fb4:	eb00403f 	cmp	x1, x0, lsl #16
    8fb8:	54000362 	b.cs	9024 <fwp_main_thread+0xd74>  // b.hs, b.nlast
    8fbc:	d350fc25 	lsr	x5, x1, #16
    8fc0:	f949fce6 	ldr	x6, [x7, #5112]
    8fc4:	9b087ca5 	mul	x5, x5, x8
    8fc8:	8b0500c3 	add	x3, x6, x5
    8fcc:	f9401060 	ldr	x0, [x3, #32]
    8fd0:	b40002a0 	cbz	x0, 9024 <fwp_main_thread+0xd74>
    8fd4:	386568c6 	ldrb	w6, [x6, x5]
    8fd8:	710008df 	cmp	w6, #0x2
    8fdc:	54008920 	b.eq	a100 <fwp_main_thread+0x1e50>  // b.none
    8fe0:	710004df 	cmp	w6, #0x1
    8fe4:	54000201 	b.ne	9024 <fwp_main_thread+0xd74>  // b.any
    8fe8:	29432465 	ldp	w5, w9, [x3, #24]
    8fec:	92403c21 	and	x1, x1, #0xffff
    8ff0:	9b057c25 	mul	x5, x1, x5
    8ff4:	d360fca5 	lsr	x5, x5, #32
    8ff8:	eb0900bf 	cmp	x5, x9
    8ffc:	54000142 	b.cs	9024 <fwp_main_thread+0xd74>  // b.hs, b.nlast
    9000:	8b050000 	add	x0, x0, x5
    9004:	39400005 	ldrb	w5, [x0]
    9008:	340000e5 	cbz	w5, 9024 <fwp_main_thread+0xd74>
    900c:	710004bf 	cmp	w5, #0x1
    9010:	54008600 	b.eq	a0d0 <fwp_main_thread+0x1e20>  // b.none
    9014:	7103fcbf 	cmp	w5, #0xff
    9018:	54008ac0 	b.eq	a170 <fwp_main_thread+0x1ec0>  // b.none
    901c:	510004a5 	sub	w5, w5, #0x1
    9020:	39000005 	strb	w5, [x0]
    9024:	91150265 	add	x5, x19, #0x540
    9028:	d2800507 	mov	x7, #0x28                  	// #40
    902c:	f94013e2 	ldr	x2, [sp, #32]
    9030:	f949d8a1 	ldr	x1, [x5, #5040]
    9034:	f949eca0 	ldr	x0, [x5, #5080]
    9038:	cb010041 	sub	x1, x2, x1
    903c:	eb00403f 	cmp	x1, x0, lsl #16
    9040:	54000362 	b.cs	90ac <fwp_main_thread+0xdfc>  // b.hs, b.nlast
    9044:	d350fc22 	lsr	x2, x1, #16
    9048:	f949fca6 	ldr	x6, [x5, #5112]
    904c:	9b077c42 	mul	x2, x2, x7
    9050:	8b0200c3 	add	x3, x6, x2
    9054:	f9401060 	ldr	x0, [x3, #32]
    9058:	b40002a0 	cbz	x0, 90ac <fwp_main_thread+0xdfc>
    905c:	386268c6 	ldrb	w6, [x6, x2]
    9060:	710008df 	cmp	w6, #0x2
    9064:	540091e0 	b.eq	a2a0 <fwp_main_thread+0x1ff0>  // b.none
    9068:	710004df 	cmp	w6, #0x1
    906c:	54000201 	b.ne	90ac <fwp_main_thread+0xdfc>  // b.any
    9070:	29432062 	ldp	w2, w8, [x3, #24]
    9074:	92403c21 	and	x1, x1, #0xffff
    9078:	9b027c22 	mul	x2, x1, x2
    907c:	d360fc42 	lsr	x2, x2, #32
    9080:	eb08005f 	cmp	x2, x8
    9084:	54000142 	b.cs	90ac <fwp_main_thread+0xdfc>  // b.hs, b.nlast
    9088:	8b020000 	add	x0, x0, x2
    908c:	39400002 	ldrb	w2, [x0]
    9090:	340000e2 	cbz	w2, 90ac <fwp_main_thread+0xdfc>
    9094:	7100045f 	cmp	w2, #0x1
    9098:	54008e60 	b.eq	a264 <fwp_main_thread+0x1fb4>  // b.none
    909c:	7103fc5f 	cmp	w2, #0xff
    90a0:	54008860 	b.eq	a1ac <fwp_main_thread+0x1efc>  // b.none
    90a4:	51000442 	sub	w2, w2, #0x1
    90a8:	39000002 	strb	w2, [x0]
    90ac:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x114c0>
    90b0:	910aa042 	add	x2, x2, #0x2a8
    90b4:	91014042 	add	x2, x2, #0x50
    90b8:	aa1503e0 	mov	x0, x21
    90bc:	52800023 	mov	w3, #0x1                   	// #1
    90c0:	aa1c03e1 	mov	x1, x28
    90c4:	a90dffff 	stp	xzr, xzr, [sp, #216]
    90c8:	f90077ff 	str	xzr, [sp, #232]
    90cc:	97fff87e 	bl	72c4 <fwp_write>
    90d0:	a94d8be3 	ldp	x3, x2, [sp, #216]
    90d4:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    90d8:	91180000 	add	x0, x0, #0x600
    90dc:	f100007f 	cmp	x3, #0x0
    90e0:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    90e4:	b100285f 	cmn	x2, #0xa
    90e8:	540079e8 	b.hi	a024 <fwp_main_thread+0x1d74>  // b.pmore
    90ec:	91002440 	add	x0, x2, #0x9
    90f0:	52800021 	mov	w1, #0x1                   	// #1
    90f4:	a9020be3 	stp	x3, x2, [sp, #32]
    90f8:	97ffeede 	bl	4c70 <fwp_heap_alloc>
    90fc:	a9420be3 	ldp	x3, x2, [sp, #32]
    9100:	f90013e0 	str	x0, [sp, #32]
    9104:	f8008402 	str	x2, [x0], #8
    9108:	f9001be2 	str	x2, [sp, #48]
    910c:	f90017e0 	str	x0, [sp, #40]
    9110:	aa0303e1 	mov	x1, x3
    9114:	97ffe56f 	bl	26d0 <memcpy@plt>
    9118:	f94013e0 	ldr	x0, [sp, #32]
    911c:	f9401be2 	ldr	x2, [sp, #48]
    9120:	8b020002 	add	x2, x0, x2
    9124:	3900205f 	strb	wzr, [x2, #8]
    9128:	f9406fe0 	ldr	x0, [sp, #216]
    912c:	97ffe605 	bl	2940 <free@plt>
    9130:	91150260 	add	x0, x19, #0x540
    9134:	f94013e3 	ldr	x3, [sp, #32]
    9138:	f949d801 	ldr	x1, [x0, #5040]
    913c:	f949ec02 	ldr	x2, [x0, #5080]
    9140:	cb010061 	sub	x1, x3, x1
    9144:	eb02403f 	cmp	x1, x2, lsl #16
    9148:	54000322 	b.cs	91ac <fwp_main_thread+0xefc>  // b.hs, b.nlast
    914c:	d350fc22 	lsr	x2, x1, #16
    9150:	d2800503 	mov	x3, #0x28                  	// #40
    9154:	f949fc05 	ldr	x5, [x0, #5112]
    9158:	9b037c42 	mul	x2, x2, x3
    915c:	8b0200a3 	add	x3, x5, x2
    9160:	f9401060 	ldr	x0, [x3, #32]
    9164:	b4000240 	cbz	x0, 91ac <fwp_main_thread+0xefc>
    9168:	386268a2 	ldrb	w2, [x5, x2]
    916c:	7100085f 	cmp	w2, #0x2
    9170:	540076c0 	b.eq	a048 <fwp_main_thread+0x1d98>  // b.none
    9174:	7100045f 	cmp	w2, #0x1
    9178:	540001a1 	b.ne	91ac <fwp_main_thread+0xefc>  // b.any
    917c:	29430865 	ldp	w5, w2, [x3, #24]
    9180:	92403c21 	and	x1, x1, #0xffff
    9184:	9b057c21 	mul	x1, x1, x5
    9188:	d360fc21 	lsr	x1, x1, #32
    918c:	eb02003f 	cmp	x1, x2
    9190:	540000e2 	b.cs	91ac <fwp_main_thread+0xefc>  // b.hs, b.nlast
    9194:	8b010000 	add	x0, x0, x1
    9198:	39400001 	ldrb	w1, [x0]
    919c:	7103fc3f 	cmp	w1, #0xff
    91a0:	54007780 	b.eq	a090 <fwp_main_thread+0x1de0>  // b.none
    91a4:	52800021 	mov	w1, #0x1                   	// #1
    91a8:	39000001 	strb	w1, [x0]
    91ac:	aa1c03e0 	mov	x0, x28
    91b0:	97fff2bc 	bl	5ca0 <fwp_drop0>
    91b4:	a94203e1 	ldp	x1, x0, [sp, #32]
    91b8:	9100c29c 	add	x28, x20, #0x30
    91bc:	f9400783 	ldr	x3, [x28, #8]
    91c0:	f9400022 	ldr	x2, [x1]
    91c4:	d2800021 	mov	x1, #0x1                   	// #1
    91c8:	97ffe5ee 	bl	2980 <fwrite@plt>
    91cc:	f9400781 	ldr	x1, [x28, #8]
    91d0:	52800140 	mov	w0, #0xa                   	// #10
    91d4:	97ffe573 	bl	27a0 <fputc@plt>
    91d8:	91150262 	add	x2, x19, #0x540
    91dc:	f94013e3 	ldr	x3, [sp, #32]
    91e0:	f949d841 	ldr	x1, [x2, #5040]
    91e4:	f949ec40 	ldr	x0, [x2, #5080]
    91e8:	cb010061 	sub	x1, x3, x1
    91ec:	eb00403f 	cmp	x1, x0, lsl #16
    91f0:	54000382 	b.cs	9260 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    91f4:	d350fc20 	lsr	x0, x1, #16
    91f8:	d2800505 	mov	x5, #0x28                  	// #40
    91fc:	f949fc43 	ldr	x3, [x2, #5112]
    9200:	9b057c00 	mul	x0, x0, x5
    9204:	8b000062 	add	x2, x3, x0
    9208:	f940105c 	ldr	x28, [x2, #32]
    920c:	b40002bc 	cbz	x28, 9260 <fwp_main_thread+0xfb0>
    9210:	38606860 	ldrb	w0, [x3, x0]
    9214:	7100081f 	cmp	w0, #0x2
    9218:	54007120 	b.eq	a03c <fwp_main_thread+0x1d8c>  // b.none
    921c:	7100041f 	cmp	w0, #0x1
    9220:	54000201 	b.ne	9260 <fwp_main_thread+0xfb0>  // b.any
    9224:	29430043 	ldp	w3, w0, [x2, #24]
    9228:	92403c21 	and	x1, x1, #0xffff
    922c:	9b037c21 	mul	x1, x1, x3
    9230:	d360fc21 	lsr	x1, x1, #32
    9234:	eb00003f 	cmp	x1, x0
    9238:	54000142 	b.cs	9260 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    923c:	8b01039c 	add	x28, x28, x1
    9240:	39400381 	ldrb	w1, [x28]
    9244:	340000e1 	cbz	w1, 9260 <fwp_main_thread+0xfb0>
    9248:	7100043f 	cmp	w1, #0x1
    924c:	54006f20 	b.eq	a030 <fwp_main_thread+0x1d80>  // b.none
    9250:	7103fc3f 	cmp	w1, #0xff
    9254:	54007000 	b.eq	a054 <fwp_main_thread+0x1da4>  // b.none
    9258:	51000421 	sub	w1, w1, #0x1
    925c:	39000381 	strb	w1, [x28]
    9260:	f9400fe0 	ldr	x0, [sp, #24]
    9264:	f9400800 	ldr	x0, [x0, #16]
    9268:	f9000fe0 	str	x0, [sp, #24]
    926c:	b5ffc0e0 	cbnz	x0, 8a88 <fwp_main_thread+0x7d8>
    9270:	aa1803e0 	mov	x0, x24
    9274:	97fff28b 	bl	5ca0 <fwp_drop0>
    9278:	aa1b03e0 	mov	x0, x27
    927c:	97fff289 	bl	5ca0 <fwp_drop0>
    9280:	9100c280 	add	x0, x20, #0x30
    9284:	52800021 	mov	w1, #0x1                   	// #1
    9288:	f94113f9 	ldr	x25, [sp, #544]
    928c:	f94117fa 	ldr	x26, [sp, #552]
    9290:	f9411bfb 	ldr	x27, [sp, #560]
    9294:	f9411ffc 	ldr	x28, [sp, #568]
    9298:	b902f401 	str	w1, [x0, #756]
    929c:	f901801f 	str	xzr, [x0, #768]
    92a0:	17fffc49 	b	83c4 <fwp_main_thread+0x114>
    92a4:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x7c>
    92a8:	9102c000 	add	x0, x0, #0xb0
    92ac:	f90013e1 	str	x1, [sp, #32]
    92b0:	9400063c 	bl	aba0 <atexit>
    92b4:	f94013e1 	ldr	x1, [sp, #32]
    92b8:	35008780 	cbnz	w0, a3a8 <fwp_main_thread+0x20f8>
    92bc:	52800020 	mov	w0, #0x1                   	// #1
    92c0:	b902f820 	str	w0, [x1, #760]
    92c4:	17fffe92 	b	8d0c <fwp_main_thread+0xa5c>
    92c8:	d3707cc6 	ubfiz	x6, x6, #16, #32
    92cc:	52800041 	mov	w1, #0x2                   	// #2
    92d0:	aa0800c0 	orr	x0, x6, x8
    92d4:	f90023e0 	str	x0, [sp, #64]
    92d8:	d2800100 	mov	x0, #0x8                   	// #8
    92dc:	97ffee65 	bl	4c70 <fwp_heap_alloc>
    92e0:	aa0003e2 	mov	x2, x0
    92e4:	91150260 	add	x0, x19, #0x540
    92e8:	f90017e2 	str	x2, [sp, #40]
    92ec:	f9001fe2 	str	x2, [sp, #56]
    92f0:	f900005f 	str	xzr, [x2]
    92f4:	f949d801 	ldr	x1, [x0, #5040]
    92f8:	f949ec00 	ldr	x0, [x0, #5080]
    92fc:	cb010041 	sub	x1, x2, x1
    9300:	eb00403f 	cmp	x1, x0, lsl #16
    9304:	54001e82 	b.cs	96d4 <fwp_main_thread+0x1424>  // b.hs, b.nlast
    9308:	d280001c 	mov	x28, #0x0                   	// #0
    930c:	91150262 	add	x2, x19, #0x540
    9310:	d350fc20 	lsr	x0, x1, #16
    9314:	8b000800 	add	x0, x0, x0, lsl #2
    9318:	f949fc45 	ldr	x5, [x2, #5112]
    931c:	d37df002 	lsl	x2, x0, #3
    9320:	8b0200a3 	add	x3, x5, x2
    9324:	f9401060 	ldr	x0, [x3, #32]
    9328:	b4000240 	cbz	x0, 9370 <fwp_main_thread+0x10c0>
    932c:	386268a2 	ldrb	w2, [x5, x2]
    9330:	7100085f 	cmp	w2, #0x2
    9334:	540024a0 	b.eq	97c8 <fwp_main_thread+0x1518>  // b.none
    9338:	7100045f 	cmp	w2, #0x1
    933c:	540001a1 	b.ne	9370 <fwp_main_thread+0x10c0>  // b.any
    9340:	29430865 	ldp	w5, w2, [x3, #24]
    9344:	92403c21 	and	x1, x1, #0xffff
    9348:	9b057c21 	mul	x1, x1, x5
    934c:	d360fc21 	lsr	x1, x1, #32
    9350:	eb02003f 	cmp	x1, x2
    9354:	540000e2 	b.cs	9370 <fwp_main_thread+0x10c0>  // b.hs, b.nlast
    9358:	8b010000 	add	x0, x0, x1
    935c:	39400001 	ldrb	w1, [x0]
    9360:	7103fc3f 	cmp	w1, #0xff
    9364:	54003280 	b.eq	99b4 <fwp_main_thread+0x1704>  // b.none
    9368:	52800021 	mov	w1, #0x1                   	// #1
    936c:	39000001 	strb	w1, [x0]
    9370:	b400027c 	cbz	x28, 93bc <fwp_main_thread+0x110c>
    9374:	f94023e0 	ldr	x0, [sp, #64]
    9378:	aa1803e1 	mov	x1, x24
    937c:	f9400706 	ldr	x6, [x24, #8]
    9380:	d3607c05 	lsl	x5, x0, #32
    9384:	f94017e0 	ldr	x0, [sp, #40]
    9388:	aa0503e3 	mov	x3, x5
    938c:	91002002 	add	x2, x0, #0x8
    9390:	d2800000 	mov	x0, #0x0                   	// #0
    9394:	14000005 	b	93a8 <fwp_main_thread+0x10f8>
    9398:	f9400426 	ldr	x6, [x1, #8]
    939c:	ab050003 	adds	x3, x0, x5
    93a0:	91004042 	add	x2, x2, #0x10
    93a4:	54008786 	b.vs	a494 <fwp_main_thread+0x21e4>
    93a8:	a9000c46 	stp	x6, x3, [x2]
    93ac:	91000400 	add	x0, x0, #0x1
    93b0:	f9400821 	ldr	x1, [x1, #16]
    93b4:	eb1c001f 	cmp	x0, x28
    93b8:	54ffff03 	b.cc	9398 <fwp_main_thread+0x10e8>  // b.lo, b.ul, b.last
    93bc:	f94017e0 	ldr	x0, [sp, #40]
    93c0:	f940001c 	ldr	x28, [x0]
    93c4:	f100079f 	cmp	x28, #0x1
    93c8:	54001869 	b.ls	96d4 <fwp_main_thread+0x1424>  // b.plast
    93cc:	d341ff81 	lsr	x1, x28, #1
    93d0:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    93d4:	d1000422 	sub	x2, x1, #0x1
    93d8:	f9001be2 	str	x2, [sp, #48]
    93dc:	eb00005f 	cmp	x2, x0
    93e0:	54ffd928 	b.hi	8f04 <fwp_main_thread+0xc54>  // b.pmore
    93e4:	b4001782 	cbz	x2, 96d4 <fwp_main_thread+0x1424>
    93e8:	f94017e2 	ldr	x2, [sp, #40]
    93ec:	d1002040 	sub	x0, x2, #0x8
    93f0:	9100205c 	add	x28, x2, #0x8
    93f4:	8b011000 	add	x0, x0, x1, lsl #4
    93f8:	f90013e0 	str	x0, [sp, #32]
    93fc:	f9400780 	ldr	x0, [x28, #8]
    9400:	f9400f81 	ldr	x1, [x28, #24]
    9404:	fd400380 	ldr	d0, [x28]
    9408:	fd400b81 	ldr	d1, [x28, #16]
    940c:	97ffef95 	bl	5260 <w120>
    9410:	a9000780 	stp	x0, x1, [x28]
    9414:	9100439c 	add	x28, x28, #0x10
    9418:	f94013e0 	ldr	x0, [sp, #32]
    941c:	eb00039f 	cmp	x28, x0
    9420:	54fffee1 	b.ne	93fc <fwp_main_thread+0x114c>  // b.any
    9424:	a94287e0 	ldp	x0, x1, [sp, #40]
    9428:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    942c:	d280001c 	mov	x28, #0x0                   	// #0
    9430:	d37ff821 	lsl	x1, x1, #1
    9434:	f8010401 	str	x1, [x0], #16
    9438:	f90013e1 	str	x1, [sp, #32]
    943c:	f9001be0 	str	x0, [sp, #48]
    9440:	f9401be0 	ldr	x0, [sp, #48]
    9444:	f87c7801 	ldr	x1, [x0, x28, lsl #3]
    9448:	aa0303e0 	mov	x0, x3
    944c:	91000b9c 	add	x28, x28, #0x2
    9450:	97ffef2c 	bl	5100 <f141.constprop.0>
    9454:	aa0003e3 	mov	x3, x0
    9458:	f94013e0 	ldr	x0, [sp, #32]
    945c:	eb00039f 	cmp	x28, x0
    9460:	54ffff03 	b.cc	9440 <fwp_main_thread+0x1190>  // b.lo, b.ul, b.last
    9464:	91150265 	add	x5, x19, #0x540
    9468:	f94017e2 	ldr	x2, [sp, #40]
    946c:	f949d8a1 	ldr	x1, [x5, #5040]
    9470:	f949eca0 	ldr	x0, [x5, #5080]
    9474:	cb010041 	sub	x1, x2, x1
    9478:	eb00403f 	cmp	x1, x0, lsl #16
    947c:	54000382 	b.cs	94ec <fwp_main_thread+0x123c>  // b.hs, b.nlast
    9480:	d2800506 	mov	x6, #0x28                  	// #40
    9484:	d350fc20 	lsr	x0, x1, #16
    9488:	f949fca2 	ldr	x2, [x5, #5112]
    948c:	9b067c00 	mul	x0, x0, x6
    9490:	8b000047 	add	x7, x2, x0
    9494:	f94010fc 	ldr	x28, [x7, #32]
    9498:	b40002bc 	cbz	x28, 94ec <fwp_main_thread+0x123c>
    949c:	38606840 	ldrb	w0, [x2, x0]
    94a0:	7100081f 	cmp	w0, #0x2
    94a4:	54001e20 	b.eq	9868 <fwp_main_thread+0x15b8>  // b.none
    94a8:	7100041f 	cmp	w0, #0x1
    94ac:	54000201 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    94b0:	294300e8 	ldp	w8, w0, [x7, #24]
    94b4:	92403c21 	and	x1, x1, #0xffff
    94b8:	9b087c21 	mul	x1, x1, x8
    94bc:	d360fc21 	lsr	x1, x1, #32
    94c0:	eb00003f 	cmp	x1, x0
    94c4:	54000142 	b.cs	94ec <fwp_main_thread+0x123c>  // b.hs, b.nlast
    94c8:	8b01039c 	add	x28, x28, x1
    94cc:	39400381 	ldrb	w1, [x28]
    94d0:	340000e1 	cbz	w1, 94ec <fwp_main_thread+0x123c>
    94d4:	7100043f 	cmp	w1, #0x1
    94d8:	54000360 	b.eq	9544 <fwp_main_thread+0x1294>  // b.none
    94dc:	7103fc3f 	cmp	w1, #0xff
    94e0:	540077c0 	b.eq	a3d8 <fwp_main_thread+0x2128>  // b.none
    94e4:	51000421 	sub	w1, w1, #0x1
    94e8:	39000381 	strb	w1, [x28]
    94ec:	b98043fc 	ldrsw	x28, [sp, #64]
    94f0:	f90013e3 	str	x3, [sp, #32]
    94f4:	aa1c03e0 	mov	x0, x28
    94f8:	97ffec6a 	bl	46a0 <fwp_tape_of>
    94fc:	f9403001 	ldr	x1, [x0, #96]
    9500:	aa0003e5 	mov	x5, x0
    9504:	f94013e3 	ldr	x3, [sp, #32]
    9508:	b4000ee1 	cbz	x1, 96e4 <fwp_main_thread+0x1434>
    950c:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    9510:	913ca000 	add	x0, x0, #0xf28
    9514:	97ffea5f 	bl	3e90 <fwp_trap>
    9518:	d280001c 	mov	x28, #0x0                   	// #0
    951c:	17fffdf9 	b	8d00 <fwp_main_thread+0xa50>
    9520:	aa1803e0 	mov	x0, x24
    9524:	97ffea7b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9528:	17fffd01 	b	892c <fwp_main_thread+0x67c>
    952c:	aa1803e0 	mov	x0, x24
    9530:	97ffea78 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9534:	17fffd22 	b	89bc <fwp_main_thread+0x70c>
    9538:	aa1703e0 	mov	x0, x23
    953c:	97ffea75 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9540:	17fffd44 	b	8a50 <fwp_main_thread+0x7a0>
    9544:	f9401fe4 	ldr	x4, [sp, #56]
    9548:	f949eca7 	ldr	x7, [x5, #5080]
    954c:	aa0403e0 	mov	x0, x4
    9550:	f9400088 	ldr	x8, [x4]
    9554:	f949d8a1 	ldr	x1, [x5, #5040]
    9558:	d370bce7 	lsl	x7, x7, #16
    955c:	cb010081 	sub	x1, x4, x1
    9560:	b7f813a8 	tbnz	x8, #63, 97d4 <fwp_main_thread+0x1524>
    9564:	eb07003f 	cmp	x1, x7
    9568:	54fffc22 	b.cs	94ec <fwp_main_thread+0x123c>  // b.hs, b.nlast
    956c:	d350fc20 	lsr	x0, x1, #16
    9570:	d2800505 	mov	x5, #0x28                  	// #40
    9574:	9b057c00 	mul	x0, x0, x5
    9578:	8b000046 	add	x6, x2, x0
    957c:	f94010c5 	ldr	x5, [x6, #32]
    9580:	b4fffb65 	cbz	x5, 94ec <fwp_main_thread+0x123c>
    9584:	38606840 	ldrb	w0, [x2, x0]
    9588:	7100081f 	cmp	w0, #0x2
    958c:	54001780 	b.eq	987c <fwp_main_thread+0x15cc>  // b.none
    9590:	7100041f 	cmp	w0, #0x1
    9594:	54fffac1 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    9598:	92403c20 	and	x0, x1, #0xffff
    959c:	294304c2 	ldp	w2, w1, [x6, #24]
    95a0:	9b027c00 	mul	x0, x0, x2
    95a4:	d360fc00 	lsr	x0, x0, #32
    95a8:	eb01001f 	cmp	x0, x1
    95ac:	54fffa02 	b.cs	94ec <fwp_main_thread+0x123c>  // b.hs, b.nlast
    95b0:	8b0000a5 	add	x5, x5, x0
    95b4:	394000a0 	ldrb	w0, [x5]
    95b8:	7100041f 	cmp	w0, #0x1
    95bc:	54fff981 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    95c0:	f9401fe0 	ldr	x0, [sp, #56]
    95c4:	f90013e3 	str	x3, [sp, #32]
    95c8:	97ffeaee 	bl	4180 <fwp_mem_free>
    95cc:	f94013e3 	ldr	x3, [sp, #32]
    95d0:	17ffffc7 	b	94ec <fwp_main_thread+0x123c>
    95d4:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    95d8:	91060000 	add	x0, x0, #0x180
    95dc:	97ffea2d 	bl	3e90 <fwp_trap>
    95e0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    95e4:	91040000 	add	x0, x0, #0x100
    95e8:	97ffea2a 	bl	3e90 <fwp_trap>
    95ec:	97ffeb5e 	bl	4364 <fwp_rc_wide_dup>
    95f0:	91150260 	add	x0, x19, #0x540
    95f4:	f949ec05 	ldr	x5, [x0, #5080]
    95f8:	f949d801 	ldr	x1, [x0, #5040]
    95fc:	d370bca5 	lsl	x5, x5, #16
    9600:	17fffd46 	b	8b18 <fwp_main_thread+0x868>
    9604:	ca5c4780 	eor	x0, x28, x28, lsr #17
    9608:	91150262 	add	x2, x19, #0x540
    960c:	ca402400 	eor	x0, x0, x0, lsr #9
    9610:	92401c00 	and	x0, x0, #0xff
    9614:	910a2401 	add	x1, x0, #0x289
    9618:	8b000c40 	add	x0, x2, x0, lsl #3
    961c:	8b010c41 	add	x1, x2, x1, lsl #3
    9620:	f94a2400 	ldr	x0, [x0, #5192]
    9624:	b50000a0 	cbnz	x0, 9638 <fwp_main_thread+0x1388>
    9628:	140000ed 	b	99dc <fwp_main_thread+0x172c>
    962c:	91004001 	add	x1, x0, #0x10
    9630:	f9400800 	ldr	x0, [x0, #16]
    9634:	b4001d40 	cbz	x0, 99dc <fwp_main_thread+0x172c>
    9638:	f9400002 	ldr	x2, [x0]
    963c:	eb1c005f 	cmp	x2, x28
    9640:	54ffff61 	b.ne	962c <fwp_main_thread+0x137c>  // b.any
    9644:	f9400021 	ldr	x1, [x1]
    9648:	f9400420 	ldr	x0, [x1, #8]
    964c:	d1000400 	sub	x0, x0, #0x1
    9650:	f9000420 	str	x0, [x1, #8]
    9654:	f103f81f 	cmp	x0, #0xfe
    9658:	54ffaf01 	b.ne	8c38 <fwp_main_thread+0x988>  // b.any
    965c:	39400380 	ldrb	w0, [x28]
    9660:	7103fc1f 	cmp	w0, #0xff
    9664:	54001b00 	b.eq	99c4 <fwp_main_thread+0x1714>  // b.none
    9668:	12800020 	mov	w0, #0xfffffffe            	// #-2
    966c:	39000380 	strb	w0, [x28]
    9670:	17fffd72 	b	8c38 <fwp_main_thread+0x988>
    9674:	97ffeb3c 	bl	4364 <fwp_rc_wide_dup>
    9678:	17fffd4f 	b	8bb4 <fwp_main_thread+0x904>
    967c:	d37ffb82 	lsl	x2, x28, #1
    9680:	d3707cc6 	ubfiz	x6, x6, #16, #32
    9684:	91000440 	add	x0, x2, #0x1
    9688:	aa0800c1 	orr	x1, x6, x8
    968c:	f90013e2 	str	x2, [sp, #32]
    9690:	d37df000 	lsl	x0, x0, #3
    9694:	f90023e1 	str	x1, [sp, #64]
    9698:	52800041 	mov	w1, #0x2                   	// #2
    969c:	97ffed75 	bl	4c70 <fwp_heap_alloc>
    96a0:	aa0003e3 	mov	x3, x0
    96a4:	91150261 	add	x1, x19, #0x540
    96a8:	f94013e2 	ldr	x2, [sp, #32]
    96ac:	aa0103e0 	mov	x0, x1
    96b0:	f9000062 	str	x2, [x3]
    96b4:	f90017e3 	str	x3, [sp, #40]
    96b8:	f949d821 	ldr	x1, [x1, #5040]
    96bc:	f9001fe3 	str	x3, [sp, #56]
    96c0:	f949ec00 	ldr	x0, [x0, #5080]
    96c4:	cb010061 	sub	x1, x3, x1
    96c8:	eb00403f 	cmp	x1, x0, lsl #16
    96cc:	54ffe203 	b.cc	930c <fwp_main_thread+0x105c>  // b.lo, b.ul, b.last
    96d0:	b5ffe53c 	cbnz	x28, 9374 <fwp_main_thread+0x10c4>
    96d4:	f94017e0 	ldr	x0, [sp, #40]
    96d8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    96dc:	f900001f 	str	xzr, [x0]
    96e0:	17ffff61 	b	9464 <fwp_main_thread+0x11b4>
    96e4:	f90023e3 	str	x3, [sp, #64]
    96e8:	97ffe62a 	bl	2f90 <fwp_tape_unlink_scope>
    96ec:	a94188a9 	ldp	x9, x2, [x5, #24]
    96f0:	f90013e2 	str	x2, [sp, #32]
    96f4:	f94014a2 	ldr	x2, [x5, #40]
    96f8:	f90017e2 	str	x2, [sp, #40]
    96fc:	f94018a2 	ldr	x2, [x5, #48]
    9700:	f9001be2 	str	x2, [sp, #48]
    9704:	f9401ca2 	ldr	x2, [x5, #56]
    9708:	b90004bf 	str	wzr, [x5, #4]
    970c:	b94000a1 	ldr	w1, [x5]
    9710:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    9714:	f9001fe2 	str	x2, [sp, #56]
    9718:	a940a0a7 	ldp	x7, x8, [x5, #8]
    971c:	6b00003f 	cmp	w1, w0
    9720:	f94020a6 	ldr	x6, [x5, #64]
    9724:	f94023e3 	ldr	x3, [sp, #64]
    9728:	f94024a2 	ldr	x2, [x5, #72]
    972c:	54000108 	b.hi	974c <fwp_main_thread+0x149c>  // b.pmore
    9730:	9100c281 	add	x1, x20, #0x30
    9734:	92403f80 	and	x0, x28, #0xffff
    9738:	d1000400 	sub	x0, x0, #0x1
    973c:	f9404c2a 	ldr	x10, [x1, #152]
    9740:	eb0a001f 	cmp	x0, x10
    9744:	5400004a 	b.ge	974c <fwp_main_thread+0x149c>  // b.tcont
    9748:	f9004c20 	str	x0, [x1, #152]
    974c:	4f000400 	movi	v0.4s, #0x0
    9750:	f9000cbf 	str	xzr, [x5, #24]
    9754:	f94013e0 	ldr	x0, [sp, #32]
    9758:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    975c:	9100c281 	add	x1, x20, #0x30
    9760:	3c8080a0 	stur	q0, [x5, #8]
    9764:	910283e4 	add	x4, sp, #0xa0
    9768:	ad0100a0 	stp	q0, q0, [x5, #32]
    976c:	f9006fe0 	str	x0, [sp, #216]
    9770:	f94017e0 	ldr	x0, [sp, #40]
    9774:	f90073e0 	str	x0, [sp, #224]
    9778:	f9401be0 	ldr	x0, [sp, #48]
    977c:	f90077e0 	str	x0, [sp, #232]
    9780:	f9401fe0 	ldr	x0, [sp, #56]
    9784:	f9007be0 	str	x0, [sp, #240]
    9788:	f9416020 	ldr	x0, [x1, #704]
    978c:	f90023e4 	str	x4, [sp, #64]
    9790:	f90053e0 	str	x0, [sp, #160]
    9794:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9798:	9135c000 	add	x0, x0, #0xd70
    979c:	f90057e0 	str	x0, [sp, #168]
    97a0:	f9005bf5 	str	x21, [sp, #176]
    97a4:	a90fa7e6 	stp	x6, x9, [sp, #248]
    97a8:	f90087e2 	str	x2, [sp, #264]
    97ac:	f9016024 	str	x4, [x1, #704]
    97b0:	b7f80f83 	tbnz	x3, #63, 99a0 <fwp_main_thread+0x16f0>
    97b4:	eb83839f 	cmp	x28, x3, asr #32
    97b8:	54000680 	b.eq	9888 <fwp_main_thread+0x15d8>  // b.none
    97bc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    97c0:	913b8000 	add	x0, x0, #0xee0
    97c4:	97ffe9b3 	bl	3e90 <fwp_trap>
    97c8:	72003c3f 	tst	w1, #0xffff
    97cc:	54ffdd21 	b.ne	9370 <fwp_main_thread+0x10c0>  // b.any
    97d0:	17fffee3 	b	935c <fwp_main_thread+0x10ac>
    97d4:	f9400484 	ldr	x4, [x4, #8]
    97d8:	f9001fe4 	str	x4, [sp, #56]
    97dc:	eb07003f 	cmp	x1, x7
    97e0:	54000342 	b.cs	9848 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    97e4:	d350fc28 	lsr	x8, x1, #16
    97e8:	d2800507 	mov	x7, #0x28                  	// #40
    97ec:	9b077d08 	mul	x8, x8, x7
    97f0:	8b080049 	add	x9, x2, x8
    97f4:	f9401127 	ldr	x7, [x9, #32]
    97f8:	b4000287 	cbz	x7, 9848 <fwp_main_thread+0x1598>
    97fc:	38686842 	ldrb	w2, [x2, x8]
    9800:	7100085f 	cmp	w2, #0x2
    9804:	54000e60 	b.eq	99d0 <fwp_main_thread+0x1720>  // b.none
    9808:	7100045f 	cmp	w2, #0x1
    980c:	540001e1 	b.ne	9848 <fwp_main_thread+0x1598>  // b.any
    9810:	29430928 	ldp	w8, w2, [x9, #24]
    9814:	92403c21 	and	x1, x1, #0xffff
    9818:	9b087c21 	mul	x1, x1, x8
    981c:	d360fc21 	lsr	x1, x1, #32
    9820:	eb02003f 	cmp	x1, x2
    9824:	54000122 	b.cs	9848 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    9828:	8b0100e7 	add	x7, x7, x1
    982c:	394000e1 	ldrb	w1, [x7]
    9830:	7100043f 	cmp	w1, #0x1
    9834:	540000a1 	b.ne	9848 <fwp_main_thread+0x1598>  // b.any
    9838:	a90217e3 	stp	x3, x5, [sp, #32]
    983c:	97ffea51 	bl	4180 <fwp_mem_free>
    9840:	d2800506 	mov	x6, #0x28                  	// #40
    9844:	a94217e3 	ldp	x3, x5, [sp, #32]
    9848:	91150260 	add	x0, x19, #0x540
    984c:	f9401fe2 	ldr	x2, [sp, #56]
    9850:	f949d801 	ldr	x1, [x0, #5040]
    9854:	f949ec00 	ldr	x0, [x0, #5080]
    9858:	cb010041 	sub	x1, x2, x1
    985c:	eb00403f 	cmp	x1, x0, lsl #16
    9860:	54ffe123 	b.cc	9484 <fwp_main_thread+0x11d4>  // b.lo, b.ul, b.last
    9864:	17ffff22 	b	94ec <fwp_main_thread+0x123c>
    9868:	72003c3f 	tst	w1, #0xffff
    986c:	54ffe401 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    9870:	17ffff17 	b	94cc <fwp_main_thread+0x121c>
    9874:	d2800022 	mov	x2, #0x1                   	// #1
    9878:	17fffd45 	b	8d8c <fwp_main_thread+0xadc>
    987c:	72003c3f 	tst	w1, #0xffff
    9880:	54ffe361 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    9884:	17ffff4c 	b	95b4 <fwp_main_thread+0x1304>
    9888:	92407c7c 	and	x28, x3, #0xffffffff
    988c:	eb23411f 	cmp	x8, w3, uxtw
    9890:	540008cd 	b.le	99a8 <fwp_main_thread+0x16f8>
    9894:	eb07039f 	cmp	x28, x7
    9898:	9a9cb4fc 	csinc	x28, x7, x28, lt	// lt = tstop
    989c:	eb1c005f 	cmp	x2, x28
    98a0:	54000a4a 	b.ge	99e8 <fwp_main_thread+0x1738>  // b.tcont
    98a4:	f100005f 	cmp	x2, #0x0
    98a8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    98ac:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    98b0:	14000004 	b	98c0 <fwp_main_thread+0x1610>
    98b4:	eb00005f 	cmp	x2, x0
    98b8:	d37ff842 	lsl	x2, x2, #1
    98bc:	9a9cd042 	csel	x2, x2, x28, le
    98c0:	eb1c005f 	cmp	x2, x28
    98c4:	54ffff8b 	b.lt	98b4 <fwp_main_thread+0x1604>  // b.tstop
    98c8:	a9051fe3 	stp	x3, x7, [sp, #80]
    98cc:	b4005c66 	cbz	x6, a458 <fwp_main_thread+0x21a8>
    98d0:	aa0603e0 	mov	x0, x6
    98d4:	d37df041 	lsl	x1, x2, #3
    98d8:	f90027e2 	str	x2, [sp, #72]
    98dc:	97ffe3e5 	bl	2870 <realloc@plt>
    98e0:	a9448fe2 	ldp	x2, x3, [sp, #72]
    98e4:	aa0003e6 	mov	x6, x0
    98e8:	f9402fe7 	ldr	x7, [sp, #88]
    98ec:	b40007e6 	cbz	x6, 99e8 <fwp_main_thread+0x1738>
    98f0:	f9007fe6 	str	x6, [sp, #248]
    98f4:	f90087e2 	str	x2, [sp, #264]
    98f8:	b500081c 	cbnz	x28, 99f8 <fwp_main_thread+0x1748>
    98fc:	b7f800c3 	tbnz	x3, #63, 9914 <fwp_main_thread+0x1664>
    9900:	d37d7c63 	ubfiz	x3, x3, #3, #32
    9904:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9908:	fc6368c0 	ldr	d0, [x6, x3]
    990c:	1e612800 	fadd	d0, d0, d1
    9910:	fc2368c0 	str	d0, [x6, x3]
    9914:	d100079c 	sub	x28, x28, #0x1
    9918:	eb1c00ff 	cmp	x7, x28
    991c:	540007ec 	b.gt	9a18 <fwp_main_thread+0x1768>
    9920:	fc7c78c0 	ldr	d0, [x6, x28, lsl #3]
    9924:	1e602008 	fcmp	d0, #0.0
    9928:	54ffff60 	b.eq	9914 <fwp_main_thread+0x1664>  // b.none
    992c:	92800060 	mov	x0, #0xfffffffffffffffc    	// #-4
    9930:	f94013e1 	ldr	x1, [sp, #32]
    9934:	9b007ce0 	mul	x0, x7, x0
    9938:	8b000021 	add	x1, x1, x0
    993c:	b87c7821 	ldr	w1, [x1, x28, lsl #2]
    9940:	37f80141 	tbnz	w1, #31, 9968 <fwp_main_thread+0x16b8>
    9944:	f9401be3 	ldr	x3, [sp, #48]
    9948:	928000e2 	mov	x2, #0xfffffffffffffff8    	// #-8
    994c:	937d7c21 	sbfiz	x1, x1, #3, #32
    9950:	9b020ce2 	madd	x2, x7, x2, x3
    9954:	fc6168c1 	ldr	d1, [x6, x1]
    9958:	fc7c7842 	ldr	d2, [x2, x28, lsl #3]
    995c:	1e620802 	fmul	d2, d0, d2
    9960:	1e622821 	fadd	d1, d1, d2
    9964:	fc2168c1 	str	d1, [x6, x1]
    9968:	f94017e1 	ldr	x1, [sp, #40]
    996c:	8b000020 	add	x0, x1, x0
    9970:	b87c7800 	ldr	w0, [x0, x28, lsl #2]
    9974:	37fffd00 	tbnz	w0, #31, 9914 <fwp_main_thread+0x1664>
    9978:	f9401fe2 	ldr	x2, [sp, #56]
    997c:	928000e1 	mov	x1, #0xfffffffffffffff8    	// #-8
    9980:	937d7c00 	sbfiz	x0, x0, #3, #32
    9984:	9b0108e1 	madd	x1, x7, x1, x2
    9988:	fc6068c1 	ldr	d1, [x6, x0]
    998c:	fc7c7822 	ldr	d2, [x1, x28, lsl #3]
    9990:	1e620800 	fmul	d0, d0, d2
    9994:	1e602820 	fadd	d0, d1, d0
    9998:	fc2068c0 	str	d0, [x6, x0]
    999c:	17ffffde 	b	9914 <fwp_main_thread+0x1664>
    99a0:	aa0703fc 	mov	x28, x7
    99a4:	17ffffbe 	b	989c <fwp_main_thread+0x15ec>
    99a8:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    99ac:	913d6000 	add	x0, x0, #0xf58
    99b0:	97ffe938 	bl	3e90 <fwp_trap>
    99b4:	f90013e0 	str	x0, [sp, #32]
    99b8:	97ffe956 	bl	3f10 <fwp_rc_forget_slot.part.0>
    99bc:	f94013e0 	ldr	x0, [sp, #32]
    99c0:	17fffe6a 	b	9368 <fwp_main_thread+0x10b8>
    99c4:	aa1c03e0 	mov	x0, x28
    99c8:	97ffe952 	bl	3f10 <fwp_rc_forget_slot.part.0>
    99cc:	17ffff27 	b	9668 <fwp_main_thread+0x13b8>
    99d0:	72003c3f 	tst	w1, #0xffff
    99d4:	54fff3a1 	b.ne	9848 <fwp_main_thread+0x1598>  // b.any
    99d8:	17ffff95 	b	982c <fwp_main_thread+0x157c>
    99dc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    99e0:	91344000 	add	x0, x0, #0xd10
    99e4:	97ffe92b 	bl	3e90 <fwp_trap>
    99e8:	f100039f 	cmp	x28, #0x0
    99ec:	fa4018c0 	ccmp	x6, #0x0, #0x0, ne	// ne = any
    99f0:	54004d20 	b.eq	a394 <fwp_main_thread+0x20e4>  // b.none
    99f4:	b4fff85c 	cbz	x28, 98fc <fwp_main_thread+0x164c>
    99f8:	aa0603e0 	mov	x0, x6
    99fc:	d37df382 	lsl	x2, x28, #3
    9a00:	52800001 	mov	w1, #0x0                   	// #0
    9a04:	a9049fe3 	stp	x3, x7, [sp, #72]
    9a08:	97ffe392 	bl	2850 <memset@plt>
    9a0c:	a9449fe3 	ldp	x3, x7, [sp, #72]
    9a10:	aa0003e6 	mov	x6, x0
    9a14:	17ffffba 	b	98fc <fwp_main_thread+0x164c>
    9a18:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9a1c:	eb0000ff 	cmp	x7, x0
    9a20:	54000e68 	b.hi	9bec <fwp_main_thread+0x193c>  // b.pmore
    9a24:	910004e0 	add	x0, x7, #0x1
    9a28:	52800041 	mov	w1, #0x2                   	// #2
    9a2c:	a9021be7 	stp	x7, x6, [sp, #32]
    9a30:	d37df000 	lsl	x0, x0, #3
    9a34:	97ffec8f 	bl	4c70 <fwp_heap_alloc>
    9a38:	aa0003fc 	mov	x28, x0
    9a3c:	a9421be7 	ldp	x7, x6, [sp, #32]
    9a40:	d2800001 	mov	x1, #0x0                   	// #0
    9a44:	f8008407 	str	x7, [x0], #8
    9a48:	14000004 	b	9a58 <fwp_main_thread+0x17a8>
    9a4c:	f86178c2 	ldr	x2, [x6, x1, lsl #3]
    9a50:	f8217802 	str	x2, [x0, x1, lsl #3]
    9a54:	91000421 	add	x1, x1, #0x1
    9a58:	eb0100ff 	cmp	x7, x1
    9a5c:	54ffff81 	b.ne	9a4c <fwp_main_thread+0x179c>  // b.any
    9a60:	9100c281 	add	x1, x20, #0x30
    9a64:	f94023e2 	ldr	x2, [sp, #64]
    9a68:	f9416020 	ldr	x0, [x1, #704]
    9a6c:	eb02001f 	cmp	x0, x2
    9a70:	540051c1 	b.ne	a4a8 <fwp_main_thread+0x21f8>  // b.any
    9a74:	f94053e2 	ldr	x2, [sp, #160]
    9a78:	aa1503e0 	mov	x0, x21
    9a7c:	f9016022 	str	x2, [x1, #704]
    9a80:	97ffe8bc 	bl	3d70 <fwp_tape_buffers_release>
    9a84:	91150260 	add	x0, x19, #0x540
    9a88:	f949d801 	ldr	x1, [x0, #5040]
    9a8c:	f949ec02 	ldr	x2, [x0, #5080]
    9a90:	cb010381 	sub	x1, x28, x1
    9a94:	eb02403f 	cmp	x1, x2, lsl #16
    9a98:	54000322 	b.cs	9afc <fwp_main_thread+0x184c>  // b.hs, b.nlast
    9a9c:	d350fc22 	lsr	x2, x1, #16
    9aa0:	d2800503 	mov	x3, #0x28                  	// #40
    9aa4:	f949fc05 	ldr	x5, [x0, #5112]
    9aa8:	9b037c42 	mul	x2, x2, x3
    9aac:	8b0200a3 	add	x3, x5, x2
    9ab0:	f9401060 	ldr	x0, [x3, #32]
    9ab4:	b4000240 	cbz	x0, 9afc <fwp_main_thread+0x184c>
    9ab8:	386268a2 	ldrb	w2, [x5, x2]
    9abc:	7100085f 	cmp	w2, #0x2
    9ac0:	54004640 	b.eq	a388 <fwp_main_thread+0x20d8>  // b.none
    9ac4:	7100045f 	cmp	w2, #0x1
    9ac8:	540001a1 	b.ne	9afc <fwp_main_thread+0x184c>  // b.any
    9acc:	29430865 	ldp	w5, w2, [x3, #24]
    9ad0:	92403c21 	and	x1, x1, #0xffff
    9ad4:	9b057c21 	mul	x1, x1, x5
    9ad8:	d360fc21 	lsr	x1, x1, #32
    9adc:	eb02003f 	cmp	x1, x2
    9ae0:	540000e2 	b.cs	9afc <fwp_main_thread+0x184c>  // b.hs, b.nlast
    9ae4:	8b010000 	add	x0, x0, x1
    9ae8:	39400001 	ldrb	w1, [x0]
    9aec:	7103fc3f 	cmp	w1, #0xff
    9af0:	54004440 	b.eq	a378 <fwp_main_thread+0x20c8>  // b.none
    9af4:	52800021 	mov	w1, #0x1                   	// #1
    9af8:	39000001 	strb	w1, [x0]
    9afc:	9100c281 	add	x1, x20, #0x30
    9b00:	f94003e2 	ldr	x2, [sp]
    9b04:	f9416020 	ldr	x0, [x1, #704]
    9b08:	eb02001f 	cmp	x0, x2
    9b0c:	54004ce1 	b.ne	a4a8 <fwp_main_thread+0x21f8>  // b.any
    9b10:	f94007e0 	ldr	x0, [sp, #8]
    9b14:	f94047e2 	ldr	x2, [sp, #136]
    9b18:	f9016022 	str	x2, [x1, #704]
    9b1c:	97fff1a5 	bl	61b0 <fwp_tape_scope_release>
    9b20:	f9400380 	ldr	x0, [x28]
    9b24:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    9b28:	b7f80880 	tbnz	x0, #63, 9c38 <fwp_main_thread+0x1988>
    9b2c:	91150261 	add	x1, x19, #0x540
    9b30:	f949d820 	ldr	x0, [x1, #5040]
    9b34:	f949ec22 	ldr	x2, [x1, #5080]
    9b38:	cb000380 	sub	x0, x28, x0
    9b3c:	eb02401f 	cmp	x0, x2, lsl #16
    9b40:	540007c2 	b.cs	9c38 <fwp_main_thread+0x1988>  // b.hs, b.nlast
    9b44:	d350fc02 	lsr	x2, x0, #16
    9b48:	d2800505 	mov	x5, #0x28                  	// #40
    9b4c:	f949fc26 	ldr	x6, [x1, #5112]
    9b50:	9b057c42 	mul	x2, x2, x5
    9b54:	8b0200c5 	add	x5, x6, x2
    9b58:	f94010a1 	ldr	x1, [x5, #32]
    9b5c:	b40006e1 	cbz	x1, 9c38 <fwp_main_thread+0x1988>
    9b60:	386268c2 	ldrb	w2, [x6, x2]
    9b64:	7100085f 	cmp	w2, #0x2
    9b68:	54000640 	b.eq	9c30 <fwp_main_thread+0x1980>  // b.none
    9b6c:	7100045f 	cmp	w2, #0x1
    9b70:	54000641 	b.ne	9c38 <fwp_main_thread+0x1988>  // b.any
    9b74:	294308a6 	ldp	w6, w2, [x5, #24]
    9b78:	92403c00 	and	x0, x0, #0xffff
    9b7c:	9b067c00 	mul	x0, x0, x6
    9b80:	d360fc00 	lsr	x0, x0, #32
    9b84:	eb02001f 	cmp	x0, x2
    9b88:	54000582 	b.cs	9c38 <fwp_main_thread+0x1988>  // b.hs, b.nlast
    9b8c:	8b000021 	add	x1, x1, x0
    9b90:	39400020 	ldrb	w0, [x1]
    9b94:	7100041f 	cmp	w0, #0x1
    9b98:	54000501 	b.ne	9c38 <fwp_main_thread+0x1988>  // b.any
    9b9c:	aa1c03e2 	mov	x2, x28
    9ba0:	d2800000 	mov	x0, #0x0                   	// #0
    9ba4:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x430>
    9ba8:	91002387 	add	x7, x28, #0x8
    9bac:	d2800001 	mov	x1, #0x0                   	// #0
    9bb0:	fd446081 	ldr	d1, [x4, #2240]
    9bb4:	eb01007f 	cmp	x3, x1
    9bb8:	540002a0 	b.eq	9c0c <fwp_main_thread+0x195c>  // b.none
    9bbc:	f9400385 	ldr	x5, [x28]
    9bc0:	b7f80225 	tbnz	x5, #63, 9c04 <fwp_main_thread+0x1954>
    9bc4:	aa0703e6 	mov	x6, x7
    9bc8:	f9400048 	ldr	x8, [x2]
    9bcc:	d37df025 	lsl	x5, x1, #3
    9bd0:	fc6568c0 	ldr	d0, [x6, x5]
    9bd4:	b7f80128 	tbnz	x8, #63, 9bf8 <fwp_main_thread+0x1948>
    9bd8:	1e600820 	fmul	d0, d1, d0
    9bdc:	8b0200a5 	add	x5, x5, x2
    9be0:	91000421 	add	x1, x1, #0x1
    9be4:	fd0004a0 	str	d0, [x5, #8]
    9be8:	17fffff3 	b	9bb4 <fwp_main_thread+0x1904>
    9bec:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    9bf0:	9104c000 	add	x0, x0, #0x130
    9bf4:	97ffe8a7 	bl	3e90 <fwp_trap>
    9bf8:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    9bfc:	91050000 	add	x0, x0, #0x140
    9c00:	97ffe8a4 	bl	3e90 <fwp_trap>
    9c04:	f9400b86 	ldr	x6, [x28, #16]
    9c08:	17fffff0 	b	9bc8 <fwp_main_thread+0x1918>
    9c0c:	f90013e2 	str	x2, [sp, #32]
    9c10:	97fff374 	bl	69e0 <fwp_drop10>
    9c14:	f94013e2 	ldr	x2, [sp, #32]
    9c18:	aa1803e0 	mov	x0, x24
    9c1c:	d2800006 	mov	x6, #0x0                   	// #0
    9c20:	b4000620 	cbz	x0, 9ce4 <fwp_main_thread+0x1a34>
    9c24:	f9400800 	ldr	x0, [x0, #16]
    9c28:	910004c6 	add	x6, x6, #0x1
    9c2c:	17fffffd 	b	9c20 <fwp_main_thread+0x1970>
    9c30:	72003c1f 	tst	w0, #0xffff
    9c34:	54fffae0 	b.eq	9b90 <fwp_main_thread+0x18e0>  // b.none
    9c38:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9c3c:	eb00007f 	cmp	x3, x0
    9c40:	54fffd68 	b.hi	9bec <fwp_main_thread+0x193c>  // b.pmore
    9c44:	91000460 	add	x0, x3, #0x1
    9c48:	52800021 	mov	w1, #0x1                   	// #1
    9c4c:	f90013e3 	str	x3, [sp, #32]
    9c50:	d37df000 	lsl	x0, x0, #3
    9c54:	97ffec07 	bl	4c70 <fwp_heap_alloc>
    9c58:	f94013e3 	ldr	x3, [sp, #32]
    9c5c:	91150266 	add	x6, x19, #0x540
    9c60:	f9000003 	str	x3, [x0]
    9c64:	aa0003e2 	mov	x2, x0
    9c68:	f949d8c1 	ldr	x1, [x6, #5040]
    9c6c:	f949ecc0 	ldr	x0, [x6, #5080]
    9c70:	cb010041 	sub	x1, x2, x1
    9c74:	eb00403f 	cmp	x1, x0, lsl #16
    9c78:	54000322 	b.cs	9cdc <fwp_main_thread+0x1a2c>  // b.hs, b.nlast
    9c7c:	d350fc25 	lsr	x5, x1, #16
    9c80:	d2800500 	mov	x0, #0x28                  	// #40
    9c84:	f949fcc7 	ldr	x7, [x6, #5112]
    9c88:	9b007ca5 	mul	x5, x5, x0
    9c8c:	8b0500e6 	add	x6, x7, x5
    9c90:	f94010c0 	ldr	x0, [x6, #32]
    9c94:	b4000240 	cbz	x0, 9cdc <fwp_main_thread+0x1a2c>
    9c98:	386568e5 	ldrb	w5, [x7, x5]
    9c9c:	710008bf 	cmp	w5, #0x2
    9ca0:	540033e0 	b.eq	a31c <fwp_main_thread+0x206c>  // b.none
    9ca4:	710004bf 	cmp	w5, #0x1
    9ca8:	540001a1 	b.ne	9cdc <fwp_main_thread+0x1a2c>  // b.any
    9cac:	294314c7 	ldp	w7, w5, [x6, #24]
    9cb0:	92403c21 	and	x1, x1, #0xffff
    9cb4:	9b077c21 	mul	x1, x1, x7
    9cb8:	d360fc21 	lsr	x1, x1, #32
    9cbc:	eb05003f 	cmp	x1, x5
    9cc0:	540000e2 	b.cs	9cdc <fwp_main_thread+0x1a2c>  // b.hs, b.nlast
    9cc4:	8b010000 	add	x0, x0, x1
    9cc8:	39400001 	ldrb	w1, [x0]
    9ccc:	7103fc3f 	cmp	w1, #0xff
    9cd0:	54000720 	b.eq	9db4 <fwp_main_thread+0x1b04>  // b.none
    9cd4:	52800021 	mov	w1, #0x1                   	// #1
    9cd8:	39000001 	strb	w1, [x0]
    9cdc:	aa1c03e0 	mov	x0, x28
    9ce0:	17ffffb1 	b	9ba4 <fwp_main_thread+0x18f4>
    9ce4:	f9400040 	ldr	x0, [x2]
    9ce8:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    9cec:	b7f830c0 	tbnz	x0, #63, a304 <fwp_main_thread+0x2054>
    9cf0:	91150261 	add	x1, x19, #0x540
    9cf4:	f949d820 	ldr	x0, [x1, #5040]
    9cf8:	f949ec23 	ldr	x3, [x1, #5080]
    9cfc:	cb000040 	sub	x0, x2, x0
    9d00:	eb03401f 	cmp	x0, x3, lsl #16
    9d04:	54003002 	b.cs	a304 <fwp_main_thread+0x2054>  // b.hs, b.nlast
    9d08:	d350fc03 	lsr	x3, x0, #16
    9d0c:	d2800507 	mov	x7, #0x28                  	// #40
    9d10:	f949fc28 	ldr	x8, [x1, #5112]
    9d14:	9b077c63 	mul	x3, x3, x7
    9d18:	8b030107 	add	x7, x8, x3
    9d1c:	f94010e1 	ldr	x1, [x7, #32]
    9d20:	b4002f21 	cbz	x1, a304 <fwp_main_thread+0x2054>
    9d24:	38636903 	ldrb	w3, [x8, x3]
    9d28:	7100087f 	cmp	w3, #0x2
    9d2c:	54002e80 	b.eq	a2fc <fwp_main_thread+0x204c>  // b.none
    9d30:	7100047f 	cmp	w3, #0x1
    9d34:	54002e81 	b.ne	a304 <fwp_main_thread+0x2054>  // b.any
    9d38:	29430ce8 	ldp	w8, w3, [x7, #24]
    9d3c:	92403c00 	and	x0, x0, #0xffff
    9d40:	9b087c00 	mul	x0, x0, x8
    9d44:	d360fc00 	lsr	x0, x0, #32
    9d48:	eb03001f 	cmp	x0, x3
    9d4c:	54002dc2 	b.cs	a304 <fwp_main_thread+0x2054>  // b.hs, b.nlast
    9d50:	8b000021 	add	x1, x1, x0
    9d54:	39400020 	ldrb	w0, [x1]
    9d58:	7100041f 	cmp	w0, #0x1
    9d5c:	54002d41 	b.ne	a304 <fwp_main_thread+0x2054>  // b.any
    9d60:	91002043 	add	x3, x2, #0x8
    9d64:	b9002be0 	str	w0, [sp, #40]
    9d68:	eb0600bf 	cmp	x5, x6
    9d6c:	aa1803e1 	mov	x1, x24
    9d70:	9a8690a5 	csel	x5, x5, x6, ls	// ls = plast
    9d74:	91002047 	add	x7, x2, #0x8
    9d78:	d2800000 	mov	x0, #0x0                   	// #0
    9d7c:	14000008 	b	9d9c <fwp_main_thread+0x1aec>
    9d80:	aa0703e6 	mov	x6, x7
    9d84:	fc6078c1 	ldr	d1, [x6, x0, lsl #3]
    9d88:	fd400420 	ldr	d0, [x1, #8]
    9d8c:	1e613800 	fsub	d0, d0, d1
    9d90:	fc207860 	str	d0, [x3, x0, lsl #3]
    9d94:	91000400 	add	x0, x0, #0x1
    9d98:	f9400821 	ldr	x1, [x1, #16]
    9d9c:	eb05001f 	cmp	x0, x5
    9da0:	54000160 	b.eq	9dcc <fwp_main_thread+0x1b1c>  // b.none
    9da4:	f9400046 	ldr	x6, [x2]
    9da8:	b6fffec6 	tbz	x6, #63, 9d80 <fwp_main_thread+0x1ad0>
    9dac:	f9400846 	ldr	x6, [x2, #16]
    9db0:	17fffff5 	b	9d84 <fwp_main_thread+0x1ad4>
    9db4:	a9020fe0 	stp	x0, x3, [sp, #32]
    9db8:	f9001be2 	str	x2, [sp, #48]
    9dbc:	97ffe855 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9dc0:	a9420fe0 	ldp	x0, x3, [sp, #32]
    9dc4:	f9401be2 	ldr	x2, [sp, #48]
    9dc8:	17ffffc3 	b	9cd4 <fwp_main_thread+0x1a24>
    9dcc:	91150260 	add	x0, x19, #0x540
    9dd0:	aa1803e1 	mov	x1, x24
    9dd4:	d2800006 	mov	x6, #0x0                   	// #0
    9dd8:	d280050b 	mov	x11, #0x28                  	// #40
    9ddc:	f949ec09 	ldr	x9, [x0, #5080]
    9de0:	f949d80c 	ldr	x12, [x0, #5040]
    9de4:	f949fc0d 	ldr	x13, [x0, #5112]
    9de8:	d370bd29 	lsl	x9, x9, #16
    9dec:	14000003 	b	9df8 <fwp_main_thread+0x1b48>
    9df0:	f9400821 	ldr	x1, [x1, #16]
    9df4:	910004c6 	add	x6, x6, #0x1
    9df8:	f100003f 	cmp	x1, #0x0
    9dfc:	fa4510c2 	ccmp	x6, x5, #0x2, ne	// ne = any
    9e00:	54000302 	b.cs	9e60 <fwp_main_thread+0x1bb0>  // b.hs, b.nlast
    9e04:	cb0c0020 	sub	x0, x1, x12
    9e08:	eb09001f 	cmp	x0, x9
    9e0c:	540002a2 	b.cs	9e60 <fwp_main_thread+0x1bb0>  // b.hs, b.nlast
    9e10:	d350fc08 	lsr	x8, x0, #16
    9e14:	9b0b7d08 	mul	x8, x8, x11
    9e18:	8b0801aa 	add	x10, x13, x8
    9e1c:	f9401147 	ldr	x7, [x10, #32]
    9e20:	b4000207 	cbz	x7, 9e60 <fwp_main_thread+0x1bb0>
    9e24:	386869a8 	ldrb	w8, [x13, x8]
    9e28:	7100091f 	cmp	w8, #0x2
    9e2c:	54000f60 	b.eq	a018 <fwp_main_thread+0x1d68>  // b.none
    9e30:	7100051f 	cmp	w8, #0x1
    9e34:	54000161 	b.ne	9e60 <fwp_main_thread+0x1bb0>  // b.any
    9e38:	2943214e 	ldp	w14, w8, [x10, #24]
    9e3c:	92403c00 	and	x0, x0, #0xffff
    9e40:	9b0e7c00 	mul	x0, x0, x14
    9e44:	d360fc00 	lsr	x0, x0, #32
    9e48:	eb08001f 	cmp	x0, x8
    9e4c:	540000a2 	b.cs	9e60 <fwp_main_thread+0x1bb0>  // b.hs, b.nlast
    9e50:	8b0000e7 	add	x7, x7, x0
    9e54:	394000e0 	ldrb	w0, [x7]
    9e58:	7100041f 	cmp	w0, #0x1
    9e5c:	54fffca0 	b.eq	9df0 <fwp_main_thread+0x1b40>  // b.none
    9e60:	d280001c 	mov	x28, #0x0                   	// #0
    9e64:	eb0500df 	cmp	x6, x5
    9e68:	540005c2 	b.cs	9f20 <fwp_main_thread+0x1c70>  // b.hs, b.nlast
    9e6c:	d1002067 	sub	x7, x3, #0x8
    9e70:	aa1603e1 	mov	x1, x22
    9e74:	52800020 	mov	w0, #0x1                   	// #1
    9e78:	f90013e5 	str	x5, [sp, #32]
    9e7c:	a9030be3 	stp	x3, x2, [sp, #48]
    9e80:	f86578e7 	ldr	x7, [x7, x5, lsl #3]
    9e84:	f90023e6 	str	x6, [sp, #64]
    9e88:	a91473e7 	stp	x7, x28, [sp, #320]
    9e8c:	97ffebbe 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e90:	aa0003fc 	mov	x28, x0
    9e94:	91150268 	add	x8, x19, #0x540
    9e98:	f94013e5 	ldr	x5, [sp, #32]
    9e9c:	f949d901 	ldr	x1, [x8, #5040]
    9ea0:	f949ed00 	ldr	x0, [x8, #5080]
    9ea4:	cb010381 	sub	x1, x28, x1
    9ea8:	a9430be3 	ldp	x3, x2, [sp, #48]
    9eac:	f94023e6 	ldr	x6, [sp, #64]
    9eb0:	eb00403f 	cmp	x1, x0, lsl #16
    9eb4:	54000322 	b.cs	9f18 <fwp_main_thread+0x1c68>  // b.hs, b.nlast
    9eb8:	d350fc27 	lsr	x7, x1, #16
    9ebc:	d2800500 	mov	x0, #0x28                  	// #40
    9ec0:	f949fd09 	ldr	x9, [x8, #5112]
    9ec4:	9b007ce7 	mul	x7, x7, x0
    9ec8:	8b070128 	add	x8, x9, x7
    9ecc:	f9401100 	ldr	x0, [x8, #32]
    9ed0:	b4000240 	cbz	x0, 9f18 <fwp_main_thread+0x1c68>
    9ed4:	38676927 	ldrb	w7, [x9, x7]
    9ed8:	710008ff 	cmp	w7, #0x2
    9edc:	54002040 	b.eq	a2e4 <fwp_main_thread+0x2034>  // b.none
    9ee0:	710004ff 	cmp	w7, #0x1
    9ee4:	540001a1 	b.ne	9f18 <fwp_main_thread+0x1c68>  // b.any
    9ee8:	29431d09 	ldp	w9, w7, [x8, #24]
    9eec:	92403c21 	and	x1, x1, #0xffff
    9ef0:	9b097c21 	mul	x1, x1, x9
    9ef4:	d360fc21 	lsr	x1, x1, #32
    9ef8:	eb07003f 	cmp	x1, x7
    9efc:	540000e2 	b.cs	9f18 <fwp_main_thread+0x1c68>  // b.hs, b.nlast
    9f00:	8b010000 	add	x0, x0, x1
    9f04:	39400001 	ldrb	w1, [x0]
    9f08:	7103fc3f 	cmp	w1, #0xff
    9f0c:	54001220 	b.eq	a150 <fwp_main_thread+0x1ea0>  // b.none
    9f10:	52800021 	mov	w1, #0x1                   	// #1
    9f14:	39000001 	strb	w1, [x0]
    9f18:	d10004a5 	sub	x5, x5, #0x1
    9f1c:	17ffffd2 	b	9e64 <fwp_main_thread+0x1bb4>
    9f20:	f90013f8 	str	x24, [sp, #32]
    9f24:	b40001a6 	cbz	x6, 9f58 <fwp_main_thread+0x1ca8>
    9f28:	d2800000 	mov	x0, #0x0                   	// #0
    9f2c:	f94013e4 	ldr	x4, [sp, #32]
    9f30:	f8607861 	ldr	x1, [x3, x0, lsl #3]
    9f34:	91000400 	add	x0, x0, #0x1
    9f38:	f9000481 	str	x1, [x4, #8]
    9f3c:	aa0403e1 	mov	x1, x4
    9f40:	f9400884 	ldr	x4, [x4, #16]
    9f44:	f90013e4 	str	x4, [sp, #32]
    9f48:	eb0000df 	cmp	x6, x0
    9f4c:	54ffff01 	b.ne	9f2c <fwp_main_thread+0x1c7c>  // b.any
    9f50:	f900083c 	str	x28, [x1, #16]
    9f54:	aa1803fc 	mov	x28, x24
    9f58:	b9402be0 	ldr	w0, [sp, #40]
    9f5c:	91150267 	add	x7, x19, #0x540
    9f60:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    9f64:	7100001f 	cmp	w0, #0x0
    9f68:	9a9f0063 	csel	x3, x3, xzr, eq	// eq = none
    9f6c:	b10004bf 	cmn	x5, #0x1
    9f70:	54ff8100 	b.eq	8f90 <fwp_main_thread+0xce0>  // b.none
    9f74:	f8657860 	ldr	x0, [x3, x5, lsl #3]
    9f78:	aa1603e1 	mov	x1, x22
    9f7c:	a9028fe5 	stp	x5, x3, [sp, #40]
    9f80:	a9039fe2 	stp	x2, x7, [sp, #56]
    9f84:	a91473e0 	stp	x0, x28, [sp, #320]
    9f88:	52800020 	mov	w0, #0x1                   	// #1
    9f8c:	97ffeb7e 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f90:	a9439fe2 	ldp	x2, x7, [sp, #56]
    9f94:	aa0003fc 	mov	x28, x0
    9f98:	a9428fe5 	ldp	x5, x3, [sp, #40]
    9f9c:	f949d8e1 	ldr	x1, [x7, #5040]
    9fa0:	f949ece0 	ldr	x0, [x7, #5080]
    9fa4:	cb010381 	sub	x1, x28, x1
    9fa8:	eb00403f 	cmp	x1, x0, lsl #16
    9fac:	54000322 	b.cs	a010 <fwp_main_thread+0x1d60>  // b.hs, b.nlast
    9fb0:	d350fc26 	lsr	x6, x1, #16
    9fb4:	d2800500 	mov	x0, #0x28                  	// #40
    9fb8:	f949fce9 	ldr	x9, [x7, #5112]
    9fbc:	9b007cc6 	mul	x6, x6, x0
    9fc0:	8b060128 	add	x8, x9, x6
    9fc4:	f9401100 	ldr	x0, [x8, #32]
    9fc8:	b4000240 	cbz	x0, a010 <fwp_main_thread+0x1d60>
    9fcc:	38666926 	ldrb	w6, [x9, x6]
    9fd0:	710008df 	cmp	w6, #0x2
    9fd4:	54001800 	b.eq	a2d4 <fwp_main_thread+0x2024>  // b.none
    9fd8:	710004df 	cmp	w6, #0x1
    9fdc:	540001a1 	b.ne	a010 <fwp_main_thread+0x1d60>  // b.any
    9fe0:	29431909 	ldp	w9, w6, [x8, #24]
    9fe4:	92403c21 	and	x1, x1, #0xffff
    9fe8:	9b097c21 	mul	x1, x1, x9
    9fec:	d360fc21 	lsr	x1, x1, #32
    9ff0:	eb06003f 	cmp	x1, x6
    9ff4:	540000e2 	b.cs	a010 <fwp_main_thread+0x1d60>  // b.hs, b.nlast
    9ff8:	8b010000 	add	x0, x0, x1
    9ffc:	39400001 	ldrb	w1, [x0]
    a000:	7103fc3f 	cmp	w1, #0xff
    a004:	54001580 	b.eq	a2b4 <fwp_main_thread+0x2004>  // b.none
    a008:	52800021 	mov	w1, #0x1                   	// #1
    a00c:	39000001 	strb	w1, [x0]
    a010:	d10004a5 	sub	x5, x5, #0x1
    a014:	17ffffd6 	b	9f6c <fwp_main_thread+0x1cbc>
    a018:	72003c1f 	tst	w0, #0xffff
    a01c:	54fff221 	b.ne	9e60 <fwp_main_thread+0x1bb0>  // b.any
    a020:	17ffff8d 	b	9e54 <fwp_main_thread+0x1ba4>
    a024:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x430>
    a028:	9105a000 	add	x0, x0, #0x168
    a02c:	97ffe799 	bl	3e90 <fwp_trap>
    a030:	f94013e0 	ldr	x0, [sp, #32]
    a034:	97ffede8 	bl	57d4 <fwp_rc_free_arr>
    a038:	17fffc8a 	b	9260 <fwp_main_thread+0xfb0>
    a03c:	72003c3f 	tst	w1, #0xffff
    a040:	54ff9101 	b.ne	9260 <fwp_main_thread+0xfb0>  // b.any
    a044:	17fffc7f 	b	9240 <fwp_main_thread+0xf90>
    a048:	72003c3f 	tst	w1, #0xffff
    a04c:	54ff8b01 	b.ne	91ac <fwp_main_thread+0xefc>  // b.any
    a050:	17fffc52 	b	9198 <fwp_main_thread+0xee8>
    a054:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a058:	91150260 	add	x0, x19, #0x540
    a05c:	ca412421 	eor	x1, x1, x1, lsr #9
    a060:	92401c21 	and	x1, x1, #0xff
    a064:	910a2422 	add	x2, x1, #0x289
    a068:	8b010c01 	add	x1, x0, x1, lsl #3
    a06c:	8b020c02 	add	x2, x0, x2, lsl #3
    a070:	f94a2420 	ldr	x0, [x1, #5192]
    a074:	b4ffcb40 	cbz	x0, 99dc <fwp_main_thread+0x172c>
    a078:	f9400001 	ldr	x1, [x0]
    a07c:	eb01039f 	cmp	x28, x1
    a080:	54000100 	b.eq	a0a0 <fwp_main_thread+0x1df0>  // b.none
    a084:	91004002 	add	x2, x0, #0x10
    a088:	f9400800 	ldr	x0, [x0, #16]
    a08c:	17fffffa 	b	a074 <fwp_main_thread+0x1dc4>
    a090:	f9001be0 	str	x0, [sp, #48]
    a094:	97ffe79f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a098:	f9401be0 	ldr	x0, [sp, #48]
    a09c:	17fffc42 	b	91a4 <fwp_main_thread+0xef4>
    a0a0:	f9400041 	ldr	x1, [x2]
    a0a4:	f9400420 	ldr	x0, [x1, #8]
    a0a8:	d1000400 	sub	x0, x0, #0x1
    a0ac:	f9000420 	str	x0, [x1, #8]
    a0b0:	f103f81f 	cmp	x0, #0xfe
    a0b4:	54ff8d61 	b.ne	9260 <fwp_main_thread+0xfb0>  // b.any
    a0b8:	39400380 	ldrb	w0, [x28]
    a0bc:	7103fc1f 	cmp	w0, #0xff
    a0c0:	54000260 	b.eq	a10c <fwp_main_thread+0x1e5c>  // b.none
    a0c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0c8:	39000380 	strb	w0, [x28]
    a0cc:	17fffc65 	b	9260 <fwp_main_thread+0xfb0>
    a0d0:	f9400045 	ldr	x5, [x2]
    a0d4:	aa0203e0 	mov	x0, x2
    a0d8:	b7f80245 	tbnz	x5, #63, a120 <fwp_main_thread+0x1e70>
    a0dc:	710008df 	cmp	w6, #0x2
    a0e0:	540001c0 	b.eq	a118 <fwp_main_thread+0x1e68>  // b.none
    a0e4:	29430065 	ldp	w5, w0, [x3, #24]
    a0e8:	9b057c21 	mul	x1, x1, x5
    a0ec:	eb41801f 	cmp	x0, x1, lsr #32
    a0f0:	54ff79a9 	b.ls	9024 <fwp_main_thread+0xd74>  // b.plast
    a0f4:	aa0203e0 	mov	x0, x2
    a0f8:	97ffe822 	bl	4180 <fwp_mem_free>
    a0fc:	17fffbca 	b	9024 <fwp_main_thread+0xd74>
    a100:	f2403c21 	ands	x1, x1, #0xffff
    a104:	54ff7901 	b.ne	9024 <fwp_main_thread+0xd74>  // b.any
    a108:	17fffbbf 	b	9004 <fwp_main_thread+0xd54>
    a10c:	aa1c03e0 	mov	x0, x28
    a110:	97ffe780 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a114:	17ffffec 	b	a0c4 <fwp_main_thread+0x1e14>
    a118:	b5ff7861 	cbnz	x1, 9024 <fwp_main_thread+0xd74>
    a11c:	17fffff6 	b	a0f4 <fwp_main_thread+0x1e44>
    a120:	f9400442 	ldr	x2, [x2, #8]
    a124:	710008df 	cmp	w6, #0x2
    a128:	54000e60 	b.eq	a2f4 <fwp_main_thread+0x2044>  // b.none
    a12c:	29430c65 	ldp	w5, w3, [x3, #24]
    a130:	9b057c21 	mul	x1, x1, x5
    a134:	eb41807f 	cmp	x3, x1, lsr #32
    a138:	54ff7389 	b.ls	8fa8 <fwp_main_thread+0xcf8>  // b.plast
    a13c:	a9029fe2 	stp	x2, x7, [sp, #40]
    a140:	97ffe810 	bl	4180 <fwp_mem_free>
    a144:	d2800508 	mov	x8, #0x28                  	// #40
    a148:	a9429fe2 	ldp	x2, x7, [sp, #40]
    a14c:	17fffb97 	b	8fa8 <fwp_main_thread+0xcf8>
    a150:	f90013e0 	str	x0, [sp, #32]
    a154:	a9030be3 	stp	x3, x2, [sp, #48]
    a158:	a90417e6 	stp	x6, x5, [sp, #64]
    a15c:	97ffe76d 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a160:	f94013e0 	ldr	x0, [sp, #32]
    a164:	a9430be3 	ldp	x3, x2, [sp, #48]
    a168:	a94417e6 	ldp	x6, x5, [sp, #64]
    a16c:	17ffff69 	b	9f10 <fwp_main_thread+0x1c60>
    a170:	ca404401 	eor	x1, x0, x0, lsr #17
    a174:	91150263 	add	x3, x19, #0x540
    a178:	ca412421 	eor	x1, x1, x1, lsr #9
    a17c:	92401c21 	and	x1, x1, #0xff
    a180:	910a2422 	add	x2, x1, #0x289
    a184:	8b010c61 	add	x1, x3, x1, lsl #3
    a188:	8b020c62 	add	x2, x3, x2, lsl #3
    a18c:	f94a2421 	ldr	x1, [x1, #5192]
    a190:	b4ffc261 	cbz	x1, 99dc <fwp_main_thread+0x172c>
    a194:	f9400023 	ldr	x3, [x1]
    a198:	eb00007f 	cmp	x3, x0
    a19c:	54000260 	b.eq	a1e8 <fwp_main_thread+0x1f38>  // b.none
    a1a0:	91004022 	add	x2, x1, #0x10
    a1a4:	f9400821 	ldr	x1, [x1, #16]
    a1a8:	17fffffa 	b	a190 <fwp_main_thread+0x1ee0>
    a1ac:	ca404401 	eor	x1, x0, x0, lsr #17
    a1b0:	91150263 	add	x3, x19, #0x540
    a1b4:	ca412421 	eor	x1, x1, x1, lsr #9
    a1b8:	92401c21 	and	x1, x1, #0xff
    a1bc:	910a2422 	add	x2, x1, #0x289
    a1c0:	8b010c61 	add	x1, x3, x1, lsl #3
    a1c4:	8b020c62 	add	x2, x3, x2, lsl #3
    a1c8:	f94a2421 	ldr	x1, [x1, #5192]
    a1cc:	b4ffc081 	cbz	x1, 99dc <fwp_main_thread+0x172c>
    a1d0:	f9400023 	ldr	x3, [x1]
    a1d4:	eb00007f 	cmp	x3, x0
    a1d8:	54000200 	b.eq	a218 <fwp_main_thread+0x1f68>  // b.none
    a1dc:	91004022 	add	x2, x1, #0x10
    a1e0:	f9400821 	ldr	x1, [x1, #16]
    a1e4:	17fffffa 	b	a1cc <fwp_main_thread+0x1f1c>
    a1e8:	f9400042 	ldr	x2, [x2]
    a1ec:	f9400441 	ldr	x1, [x2, #8]
    a1f0:	d1000421 	sub	x1, x1, #0x1
    a1f4:	f9000441 	str	x1, [x2, #8]
    a1f8:	f103f83f 	cmp	x1, #0xfe
    a1fc:	54ff7141 	b.ne	9024 <fwp_main_thread+0xd74>  // b.any
    a200:	39400001 	ldrb	w1, [x0]
    a204:	7103fc3f 	cmp	w1, #0xff
    a208:	54000260 	b.eq	a254 <fwp_main_thread+0x1fa4>  // b.none
    a20c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a210:	39000001 	strb	w1, [x0]
    a214:	17fffb84 	b	9024 <fwp_main_thread+0xd74>
    a218:	f9400042 	ldr	x2, [x2]
    a21c:	f9400441 	ldr	x1, [x2, #8]
    a220:	d1000421 	sub	x1, x1, #0x1
    a224:	f9000441 	str	x1, [x2, #8]
    a228:	f103f83f 	cmp	x1, #0xfe
    a22c:	54ff7401 	b.ne	90ac <fwp_main_thread+0xdfc>  // b.any
    a230:	39400001 	ldrb	w1, [x0]
    a234:	7103fc3f 	cmp	w1, #0xff
    a238:	54000081 	b.ne	a248 <fwp_main_thread+0x1f98>  // b.any
    a23c:	f90013e0 	str	x0, [sp, #32]
    a240:	97ffe734 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a244:	f94013e0 	ldr	x0, [sp, #32]
    a248:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a24c:	39000001 	strb	w1, [x0]
    a250:	17fffb97 	b	90ac <fwp_main_thread+0xdfc>
    a254:	f90017e0 	str	x0, [sp, #40]
    a258:	97ffe72e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a25c:	f94017e0 	ldr	x0, [sp, #40]
    a260:	17ffffeb 	b	a20c <fwp_main_thread+0x1f5c>
    a264:	f94013e2 	ldr	x2, [sp, #32]
    a268:	aa0203e0 	mov	x0, x2
    a26c:	f9400842 	ldr	x2, [x2, #16]
    a270:	f90013e2 	str	x2, [sp, #32]
    a274:	710008df 	cmp	w6, #0x2
    a278:	540001a0 	b.eq	a2ac <fwp_main_thread+0x1ffc>  // b.none
    a27c:	29430866 	ldp	w6, w2, [x3, #24]
    a280:	9b067c21 	mul	x1, x1, x6
    a284:	eb41805f 	cmp	x2, x1, lsr #32
    a288:	54ff6d29 	b.ls	902c <fwp_main_thread+0xd7c>  // b.plast
    a28c:	f90017e5 	str	x5, [sp, #40]
    a290:	97ffe7bc 	bl	4180 <fwp_mem_free>
    a294:	f94017e5 	ldr	x5, [sp, #40]
    a298:	d2800507 	mov	x7, #0x28                  	// #40
    a29c:	17fffb64 	b	902c <fwp_main_thread+0xd7c>
    a2a0:	f2403c21 	ands	x1, x1, #0xffff
    a2a4:	54ff7041 	b.ne	90ac <fwp_main_thread+0xdfc>  // b.any
    a2a8:	17fffb79 	b	908c <fwp_main_thread+0xddc>
    a2ac:	b5ff6c01 	cbnz	x1, 902c <fwp_main_thread+0xd7c>
    a2b0:	17fffff7 	b	a28c <fwp_main_thread+0x1fdc>
    a2b4:	a9028fe0 	stp	x0, x3, [sp, #40]
    a2b8:	a90397e2 	stp	x2, x5, [sp, #56]
    a2bc:	f90027e7 	str	x7, [sp, #72]
    a2c0:	97ffe714 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a2c4:	a9428fe0 	ldp	x0, x3, [sp, #40]
    a2c8:	a94397e2 	ldp	x2, x5, [sp, #56]
    a2cc:	f94027e7 	ldr	x7, [sp, #72]
    a2d0:	17ffff4e 	b	a008 <fwp_main_thread+0x1d58>
    a2d4:	72003c3f 	tst	w1, #0xffff
    a2d8:	54ffe920 	b.eq	9ffc <fwp_main_thread+0x1d4c>  // b.none
    a2dc:	d10004a5 	sub	x5, x5, #0x1
    a2e0:	17ffff23 	b	9f6c <fwp_main_thread+0x1cbc>
    a2e4:	72003c3f 	tst	w1, #0xffff
    a2e8:	54ffe0e0 	b.eq	9f04 <fwp_main_thread+0x1c54>  // b.none
    a2ec:	d10004a5 	sub	x5, x5, #0x1
    a2f0:	17fffedd 	b	9e64 <fwp_main_thread+0x1bb4>
    a2f4:	b5ff65a1 	cbnz	x1, 8fa8 <fwp_main_thread+0xcf8>
    a2f8:	17ffff91 	b	a13c <fwp_main_thread+0x1e8c>
    a2fc:	72003c1f 	tst	w0, #0xffff
    a300:	54ffd2a0 	b.eq	9d54 <fwp_main_thread+0x1aa4>  // b.none
    a304:	aa1803fc 	mov	x28, x24
    a308:	d2800006 	mov	x6, #0x0                   	// #0
    a30c:	b400011c 	cbz	x28, a32c <fwp_main_thread+0x207c>
    a310:	f9400b9c 	ldr	x28, [x28, #16]
    a314:	910004c6 	add	x6, x6, #0x1
    a318:	17fffffd 	b	a30c <fwp_main_thread+0x205c>
    a31c:	72003c3f 	tst	w1, #0xffff
    a320:	54ffcd40 	b.eq	9cc8 <fwp_main_thread+0x1a18>  // b.none
    a324:	aa1c03e0 	mov	x0, x28
    a328:	17fffe1f 	b	9ba4 <fwp_main_thread+0x18f4>
    a32c:	a9028be5 	stp	x5, x2, [sp, #40]
    a330:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a334:	eb0000df 	cmp	x6, x0
    a338:	54ff5e68 	b.hi	8f04 <fwp_main_thread+0xc54>  // b.pmore
    a33c:	910004c0 	add	x0, x6, #0x1
    a340:	52800041 	mov	w1, #0x2                   	// #2
    a344:	f90013e6 	str	x6, [sp, #32]
    a348:	d37df000 	lsl	x0, x0, #3
    a34c:	97ffea49 	bl	4c70 <fwp_heap_alloc>
    a350:	a94217e6 	ldp	x6, x5, [sp, #32]
    a354:	aa1803e1 	mov	x1, x24
    a358:	f9401be2 	ldr	x2, [sp, #48]
    a35c:	aa0003e3 	mov	x3, x0
    a360:	b40008c1 	cbz	x1, a478 <fwp_main_thread+0x21c8>
    a364:	f9400420 	ldr	x0, [x1, #8]
    a368:	f83c7860 	str	x0, [x3, x28, lsl #3]
    a36c:	9100079c 	add	x28, x28, #0x1
    a370:	f9400821 	ldr	x1, [x1, #16]
    a374:	17fffffb 	b	a360 <fwp_main_thread+0x20b0>
    a378:	f90013e0 	str	x0, [sp, #32]
    a37c:	97ffe6e5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a380:	f94013e0 	ldr	x0, [sp, #32]
    a384:	17fffddc 	b	9af4 <fwp_main_thread+0x1844>
    a388:	72003c3f 	tst	w1, #0xffff
    a38c:	54ffbb81 	b.ne	9afc <fwp_main_thread+0x184c>  // b.any
    a390:	17fffdd6 	b	9ae8 <fwp_main_thread+0x1838>
    a394:	f94053e1 	ldr	x1, [sp, #160]
    a398:	9100c294 	add	x20, x20, #0x30
    a39c:	aa1503e0 	mov	x0, x21
    a3a0:	f9016281 	str	x1, [x20, #704]
    a3a4:	97ffe673 	bl	3d70 <fwp_tape_buffers_release>
    a3a8:	b00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    a3ac:	f947e863 	ldr	x3, [x3, #4048]
    a3b0:	d2800262 	mov	x2, #0x13                  	// #19
    a3b4:	d2800021 	mov	x1, #0x1                   	// #1
    a3b8:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1d50>
    a3bc:	912f6000 	add	x0, x0, #0xbd8
    a3c0:	f9400063 	ldr	x3, [x3]
    a3c4:	97ffe16f 	bl	2980 <fwrite@plt>
    a3c8:	d2800000 	mov	x0, #0x0                   	// #0
    a3cc:	97ffe179 	bl	29b0 <fflush@plt>
    a3d0:	52800cc0 	mov	w0, #0x66                  	// #102
    a3d4:	97ffe187 	bl	29f0 <_Exit@plt>
    a3d8:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a3dc:	91150260 	add	x0, x19, #0x540
    a3e0:	ca412421 	eor	x1, x1, x1, lsr #9
    a3e4:	92401c21 	and	x1, x1, #0xff
    a3e8:	910a2422 	add	x2, x1, #0x289
    a3ec:	8b010c01 	add	x1, x0, x1, lsl #3
    a3f0:	8b020c02 	add	x2, x0, x2, lsl #3
    a3f4:	f94a2420 	ldr	x0, [x1, #5192]
    a3f8:	b4ffaf20 	cbz	x0, 99dc <fwp_main_thread+0x172c>
    a3fc:	f9400001 	ldr	x1, [x0]
    a400:	eb01039f 	cmp	x28, x1
    a404:	54000120 	b.eq	a428 <fwp_main_thread+0x2178>  // b.none
    a408:	91004002 	add	x2, x0, #0x10
    a40c:	f9400800 	ldr	x0, [x0, #16]
    a410:	17fffffa 	b	a3f8 <fwp_main_thread+0x2148>
    a414:	f90113f9 	str	x25, [sp, #544]
    a418:	f90117fa 	str	x26, [sp, #552]
    a41c:	f9011bfb 	str	x27, [sp, #560]
    a420:	f9011ffc 	str	x28, [sp, #568]
    a424:	97ffe117 	bl	2880 <__stack_chk_fail@plt>
    a428:	f9400041 	ldr	x1, [x2]
    a42c:	f9400420 	ldr	x0, [x1, #8]
    a430:	d1000400 	sub	x0, x0, #0x1
    a434:	f9000420 	str	x0, [x1, #8]
    a438:	f103f81f 	cmp	x0, #0xfe
    a43c:	54ff8581 	b.ne	94ec <fwp_main_thread+0x123c>  // b.any
    a440:	39400380 	ldrb	w0, [x28]
    a444:	7103fc1f 	cmp	w0, #0xff
    a448:	540001c0 	b.eq	a480 <fwp_main_thread+0x21d0>  // b.none
    a44c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a450:	39000380 	strb	w0, [x28]
    a454:	17fffc26 	b	94ec <fwp_main_thread+0x123c>
    a458:	aa0203e0 	mov	x0, x2
    a45c:	d2800101 	mov	x1, #0x8                   	// #8
    a460:	f90027e2 	str	x2, [sp, #72]
    a464:	97ffe0ff 	bl	2860 <calloc@plt>
    a468:	a9448fe2 	ldp	x2, x3, [sp, #72]
    a46c:	aa0003e6 	mov	x6, x0
    a470:	f9402fe7 	ldr	x7, [sp, #88]
    a474:	17fffd1e 	b	98ec <fwp_main_thread+0x163c>
    a478:	b9002bff 	str	wzr, [sp, #40]
    a47c:	17fffe3b 	b	9d68 <fwp_main_thread+0x1ab8>
    a480:	aa1c03e0 	mov	x0, x28
    a484:	f90013e3 	str	x3, [sp, #32]
    a488:	97ffe6a2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    a48c:	f94013e3 	ldr	x3, [sp, #32]
    a490:	17ffffef 	b	a44c <fwp_main_thread+0x219c>
    a494:	97ffe17b 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a498:	f90113f9 	str	x25, [sp, #544]
    a49c:	f90117fa 	str	x26, [sp, #552]
    a4a0:	f9011bfb 	str	x27, [sp, #560]
    a4a4:	f9011ffc 	str	x28, [sp, #568]
    a4a8:	97ffe10a 	bl	28d0 <abort@plt>
    a4ac:	d503201f 	nop

000000000000a4b0 <__divti3>:
    a4b0:	d503245f 	bti	c
    a4b4:	d2800004 	mov	x4, #0x0                   	// #0
    a4b8:	b7f80721 	tbnz	x1, #63, a59c <__divti3+0xec>
    a4bc:	b6f80083 	tbz	x3, #63, a4cc <__divti3+0x1c>
    a4c0:	eb0203e2 	negs	x2, x2
    a4c4:	aa2403e4 	mvn	x4, x4
    a4c8:	da0303e3 	ngc	x3, x3
    a4cc:	aa0203e6 	mov	x6, x2
    a4d0:	aa0003e7 	mov	x7, x0
    a4d4:	aa0103e5 	mov	x5, x1
    a4d8:	b5000583 	cbnz	x3, a588 <__divti3+0xd8>
    a4dc:	eb01005f 	cmp	x2, x1
    a4e0:	54000e69 	b.ls	a6ac <__divti3+0x1fc>  // b.plast
    a4e4:	dac01040 	clz	x0, x2
    a4e8:	b40000e0 	cbz	x0, a504 <__divti3+0x54>
    a4ec:	4b0003e1 	neg	w1, w0
    a4f0:	9ac020a5 	lsl	x5, x5, x0
    a4f4:	9ac02046 	lsl	x6, x2, x0
    a4f8:	9ac124e1 	lsr	x1, x7, x1
    a4fc:	aa050025 	orr	x5, x1, x5
    a500:	9ac020e7 	lsl	x7, x7, x0
    a504:	d360fcc8 	lsr	x8, x6, #32
    a508:	92407cc2 	and	x2, x6, #0xffffffff
    a50c:	9ac808a3 	udiv	x3, x5, x8
    a510:	9b089465 	msub	x5, x3, x8, x5
    a514:	aa0303e0 	mov	x0, x3
    a518:	9b037c41 	mul	x1, x2, x3
    a51c:	93c780a5 	extr	x5, x5, x7, #32
    a520:	eb05003f 	cmp	x1, x5
    a524:	540000a9 	b.ls	a538 <__divti3+0x88>  // b.plast
    a528:	ab0500c5 	adds	x5, x6, x5
    a52c:	d1000460 	sub	x0, x3, #0x1
    a530:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a534:	540015a8 	b.hi	a7e8 <__divti3+0x338>  // b.pmore
    a538:	cb0100a5 	sub	x5, x5, x1
    a53c:	9ac808a3 	udiv	x3, x5, x8
    a540:	9b089465 	msub	x5, x3, x8, x5
    a544:	aa0303e1 	mov	x1, x3
    a548:	9b037c42 	mul	x2, x2, x3
    a54c:	aa0703e3 	mov	x3, x7
    a550:	b3607ca3 	bfi	x3, x5, #32, #32
    a554:	eb03005f 	cmp	x2, x3
    a558:	540000c9 	b.ls	a570 <__divti3+0xc0>  // b.plast
    a55c:	ab0300c3 	adds	x3, x6, x3
    a560:	d1000425 	sub	x5, x1, #0x1
    a564:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a568:	d1000821 	sub	x1, x1, #0x2
    a56c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a570:	aa008020 	orr	x0, x1, x0, lsl #32
    a574:	d2800001 	mov	x1, #0x0                   	// #0
    a578:	b4000064 	cbz	x4, a584 <__divti3+0xd4>
    a57c:	eb0003e0 	negs	x0, x0
    a580:	da0103e1 	ngc	x1, x1
    a584:	d65f03c0 	ret
    a588:	eb01007f 	cmp	x3, x1
    a58c:	54000109 	b.ls	a5ac <__divti3+0xfc>  // b.plast
    a590:	d2800001 	mov	x1, #0x0                   	// #0
    a594:	d2800000 	mov	x0, #0x0                   	// #0
    a598:	17fffff8 	b	a578 <__divti3+0xc8>
    a59c:	eb0003e0 	negs	x0, x0
    a5a0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a5a4:	da0103e1 	ngc	x1, x1
    a5a8:	17ffffc5 	b	a4bc <__divti3+0xc>
    a5ac:	dac01067 	clz	x7, x3
    a5b0:	b40010e7 	cbz	x7, a7cc <__divti3+0x31c>
    a5b4:	d2800805 	mov	x5, #0x40                  	// #64
    a5b8:	cb0700a5 	sub	x5, x5, x7
    a5bc:	9ac72063 	lsl	x3, x3, x7
    a5c0:	9ac52448 	lsr	x8, x2, x5
    a5c4:	aa030108 	orr	x8, x8, x3
    a5c8:	9ac52426 	lsr	x6, x1, x5
    a5cc:	92407d0a 	and	x10, x8, #0xffffffff
    a5d0:	d360fd09 	lsr	x9, x8, #32
    a5d4:	9ac52403 	lsr	x3, x0, x5
    a5d8:	9ac72021 	lsl	x1, x1, x7
    a5dc:	aa010063 	orr	x3, x3, x1
    a5e0:	9ac72042 	lsl	x2, x2, x7
    a5e4:	9ac908cb 	udiv	x11, x6, x9
    a5e8:	9b099965 	msub	x5, x11, x9, x6
    a5ec:	aa0b03e1 	mov	x1, x11
    a5f0:	9b0b7d46 	mul	x6, x10, x11
    a5f4:	93c380a5 	extr	x5, x5, x3, #32
    a5f8:	eb0500df 	cmp	x6, x5
    a5fc:	540000a9 	b.ls	a610 <__divti3+0x160>  // b.plast
    a600:	ab050105 	adds	x5, x8, x5
    a604:	d1000561 	sub	x1, x11, #0x1
    a608:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a60c:	54000f48 	b.hi	a7f4 <__divti3+0x344>  // b.pmore
    a610:	cb0600a6 	sub	x6, x5, x6
    a614:	9ac908cb 	udiv	x11, x6, x9
    a618:	9b099969 	msub	x9, x11, x9, x6
    a61c:	aa0b03e5 	mov	x5, x11
    a620:	9b0b7d4a 	mul	x10, x10, x11
    a624:	b3607d23 	bfi	x3, x9, #32, #32
    a628:	eb03015f 	cmp	x10, x3
    a62c:	540000a9 	b.ls	a640 <__divti3+0x190>  // b.plast
    a630:	ab030103 	adds	x3, x8, x3
    a634:	d1000565 	sub	x5, x11, #0x1
    a638:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a63c:	54000e28 	b.hi	a800 <__divti3+0x350>  // b.pmore
    a640:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a644:	92407c48 	and	x8, x2, #0xffffffff
    a648:	2a0503e5 	mov	w5, w5
    a64c:	d360fc42 	lsr	x2, x2, #32
    a650:	d360fc26 	lsr	x6, x1, #32
    a654:	cb0a0063 	sub	x3, x3, x10
    a658:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a65c:	9b087caa 	mul	x10, x5, x8
    a660:	9b087cc8 	mul	x8, x6, x8
    a664:	9b0220a5 	madd	x5, x5, x2, x8
    a668:	9b027cc6 	mul	x6, x6, x2
    a66c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a670:	8b0900c5 	add	x5, x6, x9
    a674:	eb02011f 	cmp	x8, x2
    a678:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a67c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a680:	eb06007f 	cmp	x3, x6
    a684:	540000e3 	b.cc	a6a0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a688:	92407d4a 	and	x10, x10, #0xffffffff
    a68c:	9ac72000 	lsl	x0, x0, x7
    a690:	8b028142 	add	x2, x10, x2, lsl #32
    a694:	eb02001f 	cmp	x0, x2
    a698:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a69c:	54000a01 	b.ne	a7dc <__divti3+0x32c>  // b.any
    a6a0:	d1000420 	sub	x0, x1, #0x1
    a6a4:	d2800001 	mov	x1, #0x0                   	// #0
    a6a8:	17ffffb4 	b	a578 <__divti3+0xc8>
    a6ac:	b5000062 	cbnz	x2, a6b8 <__divti3+0x208>
    a6b0:	d2800022 	mov	x2, #0x1                   	// #1
    a6b4:	9ac30846 	udiv	x6, x2, x3
    a6b8:	dac010c8 	clz	x8, x6
    a6bc:	b5000408 	cbnz	x8, a73c <__divti3+0x28c>
    a6c0:	d360fcc9 	lsr	x9, x6, #32
    a6c4:	92407cc5 	and	x5, x6, #0xffffffff
    a6c8:	cb060023 	sub	x3, x1, x6
    a6cc:	d2800021 	mov	x1, #0x1                   	// #1
    a6d0:	9ac90868 	udiv	x8, x3, x9
    a6d4:	9b098d03 	msub	x3, x8, x9, x3
    a6d8:	aa0803e0 	mov	x0, x8
    a6dc:	9b057d02 	mul	x2, x8, x5
    a6e0:	93c78063 	extr	x3, x3, x7, #32
    a6e4:	eb03005f 	cmp	x2, x3
    a6e8:	540000a9 	b.ls	a6fc <__divti3+0x24c>  // b.plast
    a6ec:	ab0300c3 	adds	x3, x6, x3
    a6f0:	d1000500 	sub	x0, x8, #0x1
    a6f4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a6f8:	54000968 	b.hi	a824 <__divti3+0x374>  // b.pmore
    a6fc:	cb020063 	sub	x3, x3, x2
    a700:	9ac90862 	udiv	x2, x3, x9
    a704:	aa0203e8 	mov	x8, x2
    a708:	9b098c42 	msub	x2, x2, x9, x3
    a70c:	aa0703e3 	mov	x3, x7
    a710:	9b057d05 	mul	x5, x8, x5
    a714:	b3607c43 	bfi	x3, x2, #32, #32
    a718:	eb0300bf 	cmp	x5, x3
    a71c:	540000c9 	b.ls	a734 <__divti3+0x284>  // b.plast
    a720:	ab0300c2 	adds	x2, x6, x3
    a724:	d1000503 	sub	x3, x8, #0x1
    a728:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a72c:	d1000908 	sub	x8, x8, #0x2
    a730:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a734:	aa008100 	orr	x0, x8, x0, lsl #32
    a738:	17ffff90 	b	a578 <__divti3+0xc8>
    a73c:	9ac820c6 	lsl	x6, x6, x8
    a740:	d2800803 	mov	x3, #0x40                  	// #64
    a744:	cb080063 	sub	x3, x3, x8
    a748:	d360fcc9 	lsr	x9, x6, #32
    a74c:	9ac82027 	lsl	x7, x1, x8
    a750:	92407cc5 	and	x5, x6, #0xffffffff
    a754:	9ac32422 	lsr	x2, x1, x3
    a758:	9ac32403 	lsr	x3, x0, x3
    a75c:	aa070063 	orr	x3, x3, x7
    a760:	9ac9084a 	udiv	x10, x2, x9
    a764:	9ac82007 	lsl	x7, x0, x8
    a768:	9b098940 	msub	x0, x10, x9, x2
    a76c:	aa0a03e1 	mov	x1, x10
    a770:	9b0a7ca2 	mul	x2, x5, x10
    a774:	93c38000 	extr	x0, x0, x3, #32
    a778:	eb00005f 	cmp	x2, x0
    a77c:	540000a9 	b.ls	a790 <__divti3+0x2e0>  // b.plast
    a780:	ab0000c0 	adds	x0, x6, x0
    a784:	d1000541 	sub	x1, x10, #0x1
    a788:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a78c:	54000468 	b.hi	a818 <__divti3+0x368>  // b.pmore
    a790:	cb020000 	sub	x0, x0, x2
    a794:	9ac9080a 	udiv	x10, x0, x9
    a798:	9b098140 	msub	x0, x10, x9, x0
    a79c:	aa0a03e2 	mov	x2, x10
    a7a0:	9b0a7ca8 	mul	x8, x5, x10
    a7a4:	b3607c03 	bfi	x3, x0, #32, #32
    a7a8:	eb03011f 	cmp	x8, x3
    a7ac:	540000a9 	b.ls	a7c0 <__divti3+0x310>  // b.plast
    a7b0:	ab0300c3 	adds	x3, x6, x3
    a7b4:	d1000542 	sub	x2, x10, #0x1
    a7b8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a7bc:	54000288 	b.hi	a80c <__divti3+0x35c>  // b.pmore
    a7c0:	cb080063 	sub	x3, x3, x8
    a7c4:	aa018041 	orr	x1, x2, x1, lsl #32
    a7c8:	17ffffc2 	b	a6d0 <__divti3+0x220>
    a7cc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a7d0:	d2800001 	mov	x1, #0x0                   	// #0
    a7d4:	9a9f87e0 	cset	x0, ls	// ls = plast
    a7d8:	17ffff68 	b	a578 <__divti3+0xc8>
    a7dc:	aa0103e0 	mov	x0, x1
    a7e0:	d2800001 	mov	x1, #0x0                   	// #0
    a7e4:	17ffff65 	b	a578 <__divti3+0xc8>
    a7e8:	d1000860 	sub	x0, x3, #0x2
    a7ec:	8b0600a5 	add	x5, x5, x6
    a7f0:	17ffff52 	b	a538 <__divti3+0x88>
    a7f4:	d1000961 	sub	x1, x11, #0x2
    a7f8:	8b0800a5 	add	x5, x5, x8
    a7fc:	17ffff85 	b	a610 <__divti3+0x160>
    a800:	d1000965 	sub	x5, x11, #0x2
    a804:	8b080063 	add	x3, x3, x8
    a808:	17ffff8e 	b	a640 <__divti3+0x190>
    a80c:	d1000942 	sub	x2, x10, #0x2
    a810:	8b060063 	add	x3, x3, x6
    a814:	17ffffeb 	b	a7c0 <__divti3+0x310>
    a818:	d1000941 	sub	x1, x10, #0x2
    a81c:	8b060000 	add	x0, x0, x6
    a820:	17ffffdc 	b	a790 <__divti3+0x2e0>
    a824:	d1000900 	sub	x0, x8, #0x2
    a828:	8b060063 	add	x3, x3, x6
    a82c:	17ffffb4 	b	a6fc <__divti3+0x24c>

000000000000a830 <__modti3>:
    a830:	d503245f 	bti	c
    a834:	d2800004 	mov	x4, #0x0                   	// #0
    a838:	b6f80081 	tbz	x1, #63, a848 <__modti3+0x18>
    a83c:	eb0003e0 	negs	x0, x0
    a840:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a844:	da0103e1 	ngc	x1, x1
    a848:	f100007f 	cmp	x3, #0x0
    a84c:	5400128b 	b.lt	aa9c <__modti3+0x26c>  // b.tstop
    a850:	aa0003e7 	mov	x7, x0
    a854:	aa0103e6 	mov	x6, x1
    a858:	540004e1 	b.ne	a8f4 <__modti3+0xc4>  // b.any
    a85c:	eb02003f 	cmp	x1, x2
    a860:	54000dc2 	b.cs	aa18 <__modti3+0x1e8>  // b.hs, b.nlast
    a864:	dac01043 	clz	x3, x2
    a868:	aa0303e5 	mov	x5, x3
    a86c:	b40000e3 	cbz	x3, a888 <__modti3+0x58>
    a870:	4b0303e6 	neg	w6, w3
    a874:	9ac32021 	lsl	x1, x1, x3
    a878:	9ac32042 	lsl	x2, x2, x3
    a87c:	9ac62406 	lsr	x6, x0, x6
    a880:	aa0100c6 	orr	x6, x6, x1
    a884:	9ac32007 	lsl	x7, x0, x3
    a888:	d360fc40 	lsr	x0, x2, #32
    a88c:	92407c43 	and	x3, x2, #0xffffffff
    a890:	9ac008c1 	udiv	x1, x6, x0
    a894:	9b009826 	msub	x6, x1, x0, x6
    a898:	9b017c61 	mul	x1, x3, x1
    a89c:	93c780c6 	extr	x6, x6, x7, #32
    a8a0:	eb06003f 	cmp	x1, x6
    a8a4:	540000a9 	b.ls	a8b8 <__modti3+0x88>  // b.plast
    a8a8:	ab060046 	adds	x6, x2, x6
    a8ac:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a8b0:	8b0200c8 	add	x8, x6, x2
    a8b4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a8b8:	cb0100c6 	sub	x6, x6, x1
    a8bc:	9ac008c8 	udiv	x8, x6, x0
    a8c0:	9b009901 	msub	x1, x8, x0, x6
    a8c4:	aa0703e0 	mov	x0, x7
    a8c8:	9b087c63 	mul	x3, x3, x8
    a8cc:	b3607c20 	bfi	x0, x1, #32, #32
    a8d0:	eb00007f 	cmp	x3, x0
    a8d4:	54001088 	b.hi	aae4 <__modti3+0x2b4>  // b.pmore
    a8d8:	cb030000 	sub	x0, x0, x3
    a8dc:	9ac52400 	lsr	x0, x0, x5
    a8e0:	d2800001 	mov	x1, #0x0                   	// #0
    a8e4:	b4000064 	cbz	x4, a8f0 <__modti3+0xc0>
    a8e8:	eb0003e0 	negs	x0, x0
    a8ec:	da0103e1 	ngc	x1, x1
    a8f0:	d65f03c0 	ret
    a8f4:	dac01066 	clz	x6, x3
    a8f8:	eb03003f 	cmp	x1, x3
    a8fc:	54ffff43 	b.cc	a8e4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a900:	93407cc5 	sxtw	x5, w6
    a904:	d2800808 	mov	x8, #0x40                  	// #64
    a908:	cb050108 	sub	x8, x8, x5
    a90c:	9ac62063 	lsl	x3, x3, x6
    a910:	9ac62025 	lsl	x5, x1, x6
    a914:	9ac82447 	lsr	x7, x2, x8
    a918:	aa0300e7 	orr	x7, x7, x3
    a91c:	9ac82423 	lsr	x3, x1, x8
    a920:	92407cec 	and	x12, x7, #0xffffffff
    a924:	d360fcea 	lsr	x10, x7, #32
    a928:	9ac82401 	lsr	x1, x0, x8
    a92c:	aa050021 	orr	x1, x1, x5
    a930:	9ac62042 	lsl	x2, x2, x6
    a934:	9ac62000 	lsl	x0, x0, x6
    a938:	9aca086b 	udiv	x11, x3, x10
    a93c:	9b0a8d63 	msub	x3, x11, x10, x3
    a940:	aa0b03e5 	mov	x5, x11
    a944:	9b0b7d89 	mul	x9, x12, x11
    a948:	93c18063 	extr	x3, x3, x1, #32
    a94c:	eb03013f 	cmp	x9, x3
    a950:	540000a9 	b.ls	a964 <__modti3+0x134>  // b.plast
    a954:	ab0300e3 	adds	x3, x7, x3
    a958:	d1000565 	sub	x5, x11, #0x1
    a95c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a960:	54001168 	b.hi	ab8c <__modti3+0x35c>  // b.pmore
    a964:	cb090063 	sub	x3, x3, x9
    a968:	9aca086b 	udiv	x11, x3, x10
    a96c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a970:	aa0b03e9 	mov	x9, x11
    a974:	9b0b7d8c 	mul	x12, x12, x11
    a978:	b3607d41 	bfi	x1, x10, #32, #32
    a97c:	eb01019f 	cmp	x12, x1
    a980:	540000a9 	b.ls	a994 <__modti3+0x164>  // b.plast
    a984:	ab0100e1 	adds	x1, x7, x1
    a988:	d1000569 	sub	x9, x11, #0x1
    a98c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a990:	54000f88 	b.hi	ab80 <__modti3+0x350>  // b.pmore
    a994:	aa058123 	orr	x3, x9, x5, lsl #32
    a998:	92407c4b 	and	x11, x2, #0xffffffff
    a99c:	2a0903e9 	mov	w9, w9
    a9a0:	d360fc4a 	lsr	x10, x2, #32
    a9a4:	d360fc63 	lsr	x3, x3, #32
    a9a8:	cb0c0021 	sub	x1, x1, x12
    a9ac:	aa0a03ec 	mov	x12, x10
    a9b0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a9b4:	9b0b7d25 	mul	x5, x9, x11
    a9b8:	9b0b7c6b 	mul	x11, x3, x11
    a9bc:	9b0a2d29 	madd	x9, x9, x10, x11
    a9c0:	92407caa 	and	x10, x5, #0xffffffff
    a9c4:	9b0c7c63 	mul	x3, x3, x12
    a9c8:	8b458125 	add	x5, x9, x5, lsr #32
    a9cc:	8b0d0069 	add	x9, x3, x13
    a9d0:	eb05017f 	cmp	x11, x5
    a9d4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a9d8:	8b058149 	add	x9, x10, x5, lsl #32
    a9dc:	8b458063 	add	x3, x3, x5, lsr #32
    a9e0:	eb03003f 	cmp	x1, x3
    a9e4:	54000063 	b.cc	a9f0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a9e8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a9ec:	54000082 	b.cs	a9fc <__modti3+0x1cc>  // b.hs, b.nlast
    a9f0:	eb020129 	subs	x9, x9, x2
    a9f4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a9f8:	cb070063 	sub	x3, x3, x7
    a9fc:	eb090000 	subs	x0, x0, x9
    aa00:	da030021 	sbc	x1, x1, x3
    aa04:	9ac62400 	lsr	x0, x0, x6
    aa08:	9ac82028 	lsl	x8, x1, x8
    aa0c:	aa000100 	orr	x0, x8, x0
    aa10:	9ac62421 	lsr	x1, x1, x6
    aa14:	17ffffb4 	b	a8e4 <__modti3+0xb4>
    aa18:	b5000062 	cbnz	x2, aa24 <__modti3+0x1f4>
    aa1c:	d2800023 	mov	x3, #0x1                   	// #1
    aa20:	9ac20862 	udiv	x2, x3, x2
    aa24:	dac01048 	clz	x8, x2
    aa28:	aa0803e5 	mov	x5, x8
    aa2c:	b5000668 	cbnz	x8, aaf8 <__modti3+0x2c8>
    aa30:	cb020020 	sub	x0, x1, x2
    aa34:	d360fc49 	lsr	x9, x2, #32
    aa38:	92407c4a 	and	x10, x2, #0xffffffff
    aa3c:	9ac90801 	udiv	x1, x0, x9
    aa40:	9b098020 	msub	x0, x1, x9, x0
    aa44:	9b0a7c21 	mul	x1, x1, x10
    aa48:	93c78000 	extr	x0, x0, x7, #32
    aa4c:	eb00003f 	cmp	x1, x0
    aa50:	540000a9 	b.ls	aa64 <__modti3+0x234>  // b.plast
    aa54:	ab000040 	adds	x0, x2, x0
    aa58:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aa5c:	8b020003 	add	x3, x0, x2
    aa60:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aa64:	cb010001 	sub	x1, x0, x1
    aa68:	9ac90820 	udiv	x0, x1, x9
    aa6c:	9b098403 	msub	x3, x0, x9, x1
    aa70:	aa0703e1 	mov	x1, x7
    aa74:	9b0a7c00 	mul	x0, x0, x10
    aa78:	b3607c61 	bfi	x1, x3, #32, #32
    aa7c:	eb01001f 	cmp	x0, x1
    aa80:	540000a9 	b.ls	aa94 <__modti3+0x264>  // b.plast
    aa84:	ab010041 	adds	x1, x2, x1
    aa88:	8b020022 	add	x2, x1, x2
    aa8c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    aa90:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    aa94:	cb000020 	sub	x0, x1, x0
    aa98:	17ffff91 	b	a8dc <__modti3+0xac>
    aa9c:	eb0203e5 	negs	x5, x2
    aaa0:	aa0003e7 	mov	x7, x0
    aaa4:	da0303e8 	ngc	x8, x3
    aaa8:	aa0503e2 	mov	x2, x5
    aaac:	aa0803e3 	mov	x3, x8
    aab0:	aa0103e6 	mov	x6, x1
    aab4:	b4ffed48 	cbz	x8, a85c <__modti3+0x2c>
    aab8:	eb01011f 	cmp	x8, x1
    aabc:	54fff148 	b.hi	a8e4 <__modti3+0xb4>  // b.pmore
    aac0:	dac01109 	clz	x9, x8
    aac4:	2a0903e6 	mov	w6, w9
    aac8:	b5fff1c9 	cbnz	x9, a900 <__modti3+0xd0>
    aacc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    aad0:	54000068 	b.hi	aadc <__modti3+0x2ac>  // b.pmore
    aad4:	eb050007 	subs	x7, x0, x5
    aad8:	da080021 	sbc	x1, x1, x8
    aadc:	aa0703e0 	mov	x0, x7
    aae0:	17ffff81 	b	a8e4 <__modti3+0xb4>
    aae4:	ab000040 	adds	x0, x2, x0
    aae8:	8b020002 	add	x2, x0, x2
    aaec:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    aaf0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    aaf4:	17ffff79 	b	a8d8 <__modti3+0xa8>
    aaf8:	9ac82042 	lsl	x2, x2, x8
    aafc:	d2800803 	mov	x3, #0x40                  	// #64
    ab00:	cb080063 	sub	x3, x3, x8
    ab04:	d360fc49 	lsr	x9, x2, #32
    ab08:	9ac82027 	lsl	x7, x1, x8
    ab0c:	92407c4a 	and	x10, x2, #0xffffffff
    ab10:	9ac32426 	lsr	x6, x1, x3
    ab14:	9ac32403 	lsr	x3, x0, x3
    ab18:	aa070063 	orr	x3, x3, x7
    ab1c:	9ac908c1 	udiv	x1, x6, x9
    ab20:	9ac82007 	lsl	x7, x0, x8
    ab24:	9b099820 	msub	x0, x1, x9, x6
    ab28:	9b017d41 	mul	x1, x10, x1
    ab2c:	93c38000 	extr	x0, x0, x3, #32
    ab30:	eb00003f 	cmp	x1, x0
    ab34:	540000a9 	b.ls	ab48 <__modti3+0x318>  // b.plast
    ab38:	ab000040 	adds	x0, x2, x0
    ab3c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ab40:	8b020006 	add	x6, x0, x2
    ab44:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ab48:	cb010000 	sub	x0, x0, x1
    ab4c:	9ac90801 	udiv	x1, x0, x9
    ab50:	9b098026 	msub	x6, x1, x9, x0
    ab54:	aa0303e0 	mov	x0, x3
    ab58:	9b017d41 	mul	x1, x10, x1
    ab5c:	b3607cc0 	bfi	x0, x6, #32, #32
    ab60:	eb00003f 	cmp	x1, x0
    ab64:	540000a9 	b.ls	ab78 <__modti3+0x348>  // b.plast
    ab68:	ab000040 	adds	x0, x2, x0
    ab6c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ab70:	8b020003 	add	x3, x0, x2
    ab74:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ab78:	cb010000 	sub	x0, x0, x1
    ab7c:	17ffffb0 	b	aa3c <__modti3+0x20c>
    ab80:	d1000969 	sub	x9, x11, #0x2
    ab84:	8b070021 	add	x1, x1, x7
    ab88:	17ffff83 	b	a994 <__modti3+0x164>
    ab8c:	d1000965 	sub	x5, x11, #0x2
    ab90:	8b070063 	add	x3, x3, x7
    ab94:	17ffff74 	b	a964 <__modti3+0x134>
    ab98:	d503201f 	nop
    ab9c:	d503201f 	nop

000000000000aba0 <atexit>:
    aba0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aba4:	d00000a2 	adrp	x2, 20000 <__data_start>
    aba8:	d2800001 	mov	x1, #0x0                   	// #0
    abac:	910003fd 	mov	x29, sp
    abb0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    abb4:	f9400442 	ldr	x2, [x2, #8]
    abb8:	17ffdef2 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000abbc <_fini>:
    abbc:	d503201f 	nop
    abc0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    abc4:	910003fd 	mov	x29, sp
    abc8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    abcc:	d65f03c0 	ret
