
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__modti3+0xc0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911f00a5 	add	x5, x5, #0x7c0
    2aa0:	b0000044 	adrp	x4, b000 <__modti3+0xc0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911f2084 	add	x4, x4, #0x7c8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000619 	bl	4334 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	910142a1 	add	x1, x21, #0x50
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10a10>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9008c20 	str	x0, [x1, #280]
    2b2c:	94000821 	bl	4bb0 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2b34:	912e2000 	add	x0, x0, #0xb88
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0x80c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911f8042 	add	x2, x2, #0x7e0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	910142b5 	add	x21, x21, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943daa0 	ldr	w0, [x21, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c4c:	912ee000 	add	x0, x0, #0xbb8
    2c50:	940005b9 	bl	4334 <fwp_trap>
    2c54:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2c58:	912e6000 	add	x0, x0, #0xb98
    2c5c:	940005b6 	bl	4334 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff4a 	bl	2990 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeef 	bl	2850 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2ca0:	91304000 	add	x0, x0, #0xc10
    2ca4:	940005a4 	bl	4334 <fwp_trap>
    2ca8:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2cac:	912f8000 	add	x0, x0, #0xbe0
    2cb0:	940005a1 	bl	4334 <fwp_trap>
    2cb4:	b0000040 	adrp	x0, b000 <__modti3+0xc0>
    2cb8:	9130e000 	add	x0, x0, #0xc38
    2cbc:	9400059e 	bl	4334 <fwp_trap>
    2cc0:	97fffef8 	bl	28a0 <__stack_chk_fail@plt>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xd20>
    2eb4:	910a4021 	add	x1, x1, #0x290
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xd20>
    3158:	9109c021 	add	x1, x1, #0x270
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3190:	910ba000 	add	x0, x0, #0x2e8
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    339c:	910c0042 	add	x2, x2, #0x300
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	910d6042 	add	x2, x2, #0x358
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	90000059 	adrp	x25, b000 <__modti3+0xc0>
    3428:	9000005a 	adrp	x26, b000 <__modti3+0xc0>
    342c:	910ee339 	add	x25, x25, #0x3b8
    3430:	910c835a 	add	x26, x26, #0x320
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	9000005b 	adrp	x27, b000 <__modti3+0xc0>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	910ca377 	add	x23, x27, #0x328
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	910fe000 	add	x0, x0, #0x3f8
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	90000043 	adrp	x3, b000 <__modti3+0xc0>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	90000055 	adrp	x21, b000 <__modti3+0xc0>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	910c8063 	add	x3, x3, #0x320
    3520:	911042b5 	add	x21, x21, #0x410
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91114000 	add	x0, x0, #0x450
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    35ac:	910cc000 	add	x0, x0, #0x330
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    366c:	910ba000 	add	x0, x0, #0x2e8
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91116021 	add	x1, x1, #0x458
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91118021 	add	x1, x1, #0x460
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    37e0:	9111a021 	add	x1, x1, #0x468
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	9111c084 	add	x4, x4, #0x470
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbeb 	bl	2810 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc44 	bl	2980 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2f 	bl	2940 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbb0 	bl	27f0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffba1 	bl	27f0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb65 	bl	2730 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf5 	bl	2980 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	91122084 	add	x4, x4, #0x488
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb76 	bl	2810 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb65 	bl	27f0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc5 	bl	2980 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	90000044 	adrp	x4, b000 <__modti3+0xc0>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	9111e084 	add	x4, x4, #0x478
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4e 	bl	2810 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb38 	bl	27f0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb0c 	bl	27f0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb28 	bl	28a0 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3c0c:	9118c042 	add	x2, x2, #0x630
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	90000041 	adrp	x1, b000 <__modti3+0xc0>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91124021 	add	x1, x1, #0x490
    3c68:	91126000 	add	x0, x0, #0x498
    3c6c:	97fffaf1 	bl	2830 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb6d 	bl	2a50 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb1b 	bl	2940 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb5a 	bl	2a50 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffacb 	bl	2820 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	90000042 	adrp	x2, b000 <__modti3+0xc0>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9112e042 	add	x2, x2, #0x4b8
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaee 	b	2910 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97ffface 	bl	28a0 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    3d78:	9114c061 	add	x1, x3, #0x530
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    3d88:	9118c262 	add	x2, x19, #0x630
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	b0000042 	adrp	x2, c000 <_IO_stdin_used+0xd20>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    3dbc:	9115c021 	add	x1, x1, #0x570
    3dc0:	3dc0a843 	ldr	q3, [x2, #672]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    3dec:	9114c063 	add	x3, x3, #0x530
    3df0:	91174084 	add	x4, x4, #0x5d0
    3df4:	9118c266 	add	x6, x19, #0x630
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffab1 	bl	2930 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	9118c275 	add	x21, x19, #0x630
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa9b 	bl	2930 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	90000040 	adrp	x0, b000 <__modti3+0xc0>
    3ed8:	91150000 	add	x0, x0, #0x540
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad4 	bl	2a30 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	9118c273 	add	x19, x19, #0x630
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc90 	bl	3170 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	91014122 	add	x2, x9, #0x50
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9406046 	ldr	x6, [x2, #192]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	91014120 	add	x0, x9, #0x50
    3fc4:	f900640b 	str	x11, [x0, #200]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	91014129 	add	x9, x9, #0x50
    3fd0:	f9006126 	str	x6, [x9, #192]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <ad_raw_free.part.0>:
    3ff0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    3ff4:	d2800001 	mov	x1, #0x0                   	// #0
    3ff8:	91114082 	add	x2, x4, #0x450
    3ffc:	14000005 	b	4010 <ad_raw_free.part.0+0x20>
    4000:	91000421 	add	x1, x1, #0x1
    4004:	91006042 	add	x2, x2, #0x18
    4008:	f140043f 	cmp	x1, #0x1, lsl #12
    400c:	54000220 	b.eq	4050 <ad_raw_free.part.0+0x60>  // b.none
    4010:	f9400043 	ldr	x3, [x2]
    4014:	eb03001f 	cmp	x0, x3
    4018:	54ffff41 	b.ne	4000 <ad_raw_free.part.0+0x10>  // b.any
    401c:	8b010421 	add	x1, x1, x1, lsl #1
    4020:	91114084 	add	x4, x4, #0x450
    4024:	900000e2 	adrp	x2, 20000 <__data_start>
    4028:	91014042 	add	x2, x2, #0x50
    402c:	8b010c81 	add	x1, x4, x1, lsl #3
    4030:	b9401024 	ldr	w4, [x1, #16]
    4034:	f9400425 	ldr	x5, [x1, #8]
    4038:	a9007c3f 	stp	xzr, xzr, [x1]
    403c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4040:	f900083f 	str	xzr, [x1, #16]
    4044:	cb050061 	sub	x1, x3, x5
    4048:	f8247841 	str	x1, [x2, x4, lsl #3]
    404c:	17fffa45 	b	2960 <free@plt>
    4050:	f100001f 	cmp	x0, #0x0
    4054:	f0000021 	adrp	x1, b000 <__modti3+0xc0>
    4058:	9115a021 	add	x1, x1, #0x568
    405c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4060:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4064:	91154000 	add	x0, x0, #0x550
    4068:	910003fd 	mov	x29, sp
    406c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4070:	97fffcc4 	bl	3380 <ad_raw_fail>

0000000000004074 <fwp_tape_buffers_dispose>:
    4074:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4078:	910003fd 	mov	x29, sp
    407c:	f9000bf3 	str	x19, [sp, #16]
    4080:	aa0003f3 	mov	x19, x0
    4084:	f9400000 	ldr	x0, [x0]
    4088:	b4000040 	cbz	x0, 4090 <fwp_tape_buffers_dispose+0x1c>
    408c:	97ffffd9 	bl	3ff0 <ad_raw_free.part.0>
    4090:	f9400a60 	ldr	x0, [x19, #16]
    4094:	b4000040 	cbz	x0, 409c <fwp_tape_buffers_dispose+0x28>
    4098:	97ffffd6 	bl	3ff0 <ad_raw_free.part.0>
    409c:	f9401260 	ldr	x0, [x19, #32]
    40a0:	b4000040 	cbz	x0, 40a8 <fwp_tape_buffers_dispose+0x34>
    40a4:	97ffffd3 	bl	3ff0 <ad_raw_free.part.0>
    40a8:	4f000400 	movi	v0.4s, #0x0
    40ac:	f9001a7f 	str	xzr, [x19, #48]
    40b0:	ad000260 	stp	q0, q0, [x19]
    40b4:	3d800a60 	str	q0, [x19, #32]
    40b8:	f9400bf3 	ldr	x19, [sp, #16]
    40bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40c0:	d65f03c0 	ret

00000000000040c4 <ad_raw_realloc>:
    40c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	f90013f5 	str	x21, [sp, #32]
    40d4:	b40005a1 	cbz	x1, 4188 <ad_raw_realloc+0xc4>
    40d8:	aa0103f4 	mov	x20, x1
    40dc:	2a0203f5 	mov	w21, w2
    40e0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    40e4:	d2800004 	mov	x4, #0x0                   	// #0
    40e8:	91114025 	add	x5, x1, #0x450
    40ec:	14000005 	b	4100 <ad_raw_realloc+0x3c>
    40f0:	91000484 	add	x4, x4, #0x1
    40f4:	910060a5 	add	x5, x5, #0x18
    40f8:	f140049f 	cmp	x4, #0x1, lsl #12
    40fc:	54000320 	b.eq	4160 <ad_raw_realloc+0x9c>  // b.none
    4100:	f94000a6 	ldr	x6, [x5]
    4104:	eb06001f 	cmp	x0, x6
    4108:	54ffff41 	b.ne	40f0 <ad_raw_realloc+0x2c>  // b.any
    410c:	8b040484 	add	x4, x4, x4, lsl #1
    4110:	91114021 	add	x1, x1, #0x450
    4114:	8b040c33 	add	x19, x1, x4, lsl #3
    4118:	b4000080 	cbz	x0, 4128 <ad_raw_realloc+0x64>
    411c:	b9401261 	ldr	w1, [x19, #16]
    4120:	6b15003f 	cmp	w1, w21
    4124:	540002c1 	b.ne	417c <ad_raw_realloc+0xb8>  // b.any
    4128:	aa1403e1 	mov	x1, x20
    412c:	97fff9d9 	bl	2890 <realloc@plt>
    4130:	aa0003ed 	mov	x13, x0
    4134:	b40000c0 	cbz	x0, 414c <ad_raw_realloc+0x88>
    4138:	2a1503e3 	mov	w3, w21
    413c:	aa1403e2 	mov	x2, x20
    4140:	aa1303e0 	mov	x0, x19
    4144:	aa0d03e1 	mov	x1, x13
    4148:	97fffb92 	bl	2f90 <ad_raw_record>
    414c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4150:	aa0d03e0 	mov	x0, x13
    4154:	f94013f5 	ldr	x21, [sp, #32]
    4158:	a8c37bfd 	ldp	x29, x30, [sp], #48
    415c:	d65f03c0 	ret
    4160:	f100001f 	cmp	x0, #0x0
    4164:	f0000021 	adrp	x1, b000 <__modti3+0xc0>
    4168:	9115a021 	add	x1, x1, #0x568
    416c:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4170:	91154000 	add	x0, x0, #0x550
    4174:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4178:	97fffc82 	bl	3380 <ad_raw_fail>
    417c:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4180:	9116a000 	add	x0, x0, #0x5a8
    4184:	97fffc7f 	bl	3380 <ad_raw_fail>
    4188:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    418c:	91162000 	add	x0, x0, #0x588
    4190:	97fffc7c 	bl	3380 <ad_raw_fail>

0000000000004194 <fwp_tape_buffers_release>:
    4194:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4198:	910003fd 	mov	x29, sp
    419c:	a90153f3 	stp	x19, x20, [sp, #16]
    41a0:	aa0003f4 	mov	x20, x0
    41a4:	f9401400 	ldr	x0, [x0, #40]
    41a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    41ac:	b7f80560 	tbnz	x0, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b0:	f9401a93 	ldr	x19, [x20, #48]
    41b4:	b7f80533 	tbnz	x19, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    41bc:	eb01001f 	cmp	x0, x1
    41c0:	540004c8 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41c4:	8b000400 	add	x0, x0, x0, lsl #1
    41c8:	d2a00101 	mov	x1, #0x80000               	// #524288
    41cc:	d37df000 	lsl	x0, x0, #3
    41d0:	cb000021 	sub	x1, x1, x0
    41d4:	eb410e7f 	cmp	x19, x1, lsr #3
    41d8:	54000408 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41dc:	8b130c13 	add	x19, x0, x19, lsl #3
    41e0:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    41e4:	91170000 	add	x0, x0, #0x5c0
    41e8:	97fffa12 	bl	2a30 <getenv@plt>
    41ec:	b4000080 	cbz	x0, 41fc <fwp_tape_buffers_release+0x68>
    41f0:	39400001 	ldrb	w1, [x0]
    41f4:	7100c03f 	cmp	w1, #0x30
    41f8:	54000880 	b.eq	4308 <fwp_tape_buffers_release+0x174>  // b.none
    41fc:	d1000661 	sub	x1, x19, #0x1
    4200:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4204:	eb00003f 	cmp	x1, x0
    4208:	54000328 	b.hi	426c <fwp_tape_buffers_release+0xd8>  // b.pmore
    420c:	900000f5 	adrp	x21, 20000 <__data_start>
    4210:	f9001bf7 	str	x23, [sp, #48]
    4214:	910142b7 	add	x23, x21, #0x50
    4218:	910342f6 	add	x22, x23, #0xd0
    421c:	aa1603e0 	mov	x0, x22
    4220:	97ffff95 	bl	4074 <fwp_tape_buffers_dispose>
    4224:	ad400a81 	ldp	q1, q2, [x20]
    4228:	f90086f3 	str	x19, [x23, #264]
    422c:	4f000400 	movi	v0.4s, #0x0
    4230:	ad000ac1 	stp	q1, q2, [x22]
    4234:	3dc00a81 	ldr	q1, [x20, #32]
    4238:	3d800ac1 	str	q1, [x22, #32]
    423c:	f9401a80 	ldr	x0, [x20, #48]
    4240:	f9001ac0 	str	x0, [x22, #48]
    4244:	f9001a9f 	str	xzr, [x20, #48]
    4248:	ad000280 	stp	q0, q0, [x20]
    424c:	3d800a80 	str	q0, [x20, #32]
    4250:	f9401bf7 	ldr	x23, [sp, #48]
    4254:	1400000b 	b	4280 <fwp_tape_buffers_release+0xec>
    4258:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    425c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4260:	91170000 	add	x0, x0, #0x5c0
    4264:	97fff9f3 	bl	2a30 <getenv@plt>
    4268:	b5fffc40 	cbnz	x0, 41f0 <fwp_tape_buffers_release+0x5c>
    426c:	aa1403e0 	mov	x0, x20
    4270:	97ffff81 	bl	4074 <fwp_tape_buffers_dispose>
    4274:	900000f5 	adrp	x21, 20000 <__data_start>
    4278:	910142a0 	add	x0, x21, #0x50
    427c:	f9408413 	ldr	x19, [x0, #264]
    4280:	910142a2 	add	x2, x21, #0x50
    4284:	f9408844 	ldr	x4, [x2, #272]
    4288:	a9400c45 	ldp	x5, x3, [x2]
    428c:	8b040481 	add	x1, x4, x4, lsl #1
    4290:	f9400840 	ldr	x0, [x2, #16]
    4294:	8b010881 	add	x1, x4, x1, lsl #2
    4298:	f9400c44 	ldr	x4, [x2, #24]
    429c:	8b0300a3 	add	x3, x5, x3
    42a0:	d37df021 	lsl	x1, x1, #3
    42a4:	8b040000 	add	x0, x0, x4
    42a8:	8b030000 	add	x0, x0, x3
    42ac:	eb05003f 	cmp	x1, x5
    42b0:	54000321 	b.ne	4314 <fwp_tape_buffers_release+0x180>  // b.any
    42b4:	8b130023 	add	x3, x1, x19
    42b8:	eb00007f 	cmp	x3, x0
    42bc:	540002c8 	b.hi	4314 <fwp_tape_buffers_release+0x180>  // b.pmore
    42c0:	f9405c43 	ldr	x3, [x2, #184]
    42c4:	f140087f 	cmp	x3, #0x2, lsl #12
    42c8:	540002e0 	b.eq	4324 <fwp_tape_buffers_release+0x190>  // b.none
    42cc:	8b030464 	add	x4, x3, x3, lsl #1
    42d0:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    42d4:	911140a5 	add	x5, x5, #0x450
    42d8:	cb010000 	sub	x0, x0, x1
    42dc:	d37df084 	lsl	x4, x4, #3
    42e0:	cb130000 	sub	x0, x0, x19
    42e4:	8b0400a6 	add	x6, x5, x4
    42e8:	91000463 	add	x3, x3, #0x1
    42ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42f0:	f82468a1 	str	x1, [x5, x4]
    42f4:	a90080d3 	stp	x19, x0, [x6, #8]
    42f8:	f9005c43 	str	x3, [x2, #184]
    42fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4300:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4304:	d65f03c0 	ret
    4308:	39400400 	ldrb	w0, [x0, #1]
    430c:	34fffb00 	cbz	w0, 426c <fwp_tape_buffers_release+0xd8>
    4310:	17ffffbb 	b	41fc <fwp_tape_buffers_release+0x68>
    4314:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4318:	91176000 	add	x0, x0, #0x5d8
    431c:	f9001bf7 	str	x23, [sp, #48]
    4320:	97fffc18 	bl	3380 <ad_raw_fail>
    4324:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4328:	91182000 	add	x0, x0, #0x608
    432c:	f9001bf7 	str	x23, [sp, #48]
    4330:	97fffc14 	bl	3380 <ad_raw_fail>

0000000000004334 <fwp_trap>:
    4334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4338:	900000e2 	adrp	x2, 20000 <__data_start>
    433c:	d53bd041 	mrs	x1, tpidr_el0
    4340:	910003fd 	mov	x29, sp
    4344:	f9407042 	ldr	x2, [x2, #224]
    4348:	91400021 	add	x1, x1, #0x0, lsl #12
    434c:	91004021 	add	x1, x1, #0x10
    4350:	a90153f3 	stp	x19, x20, [sp, #16]
    4354:	aa0003f3 	mov	x19, x0
    4358:	f9400034 	ldr	x20, [x1]
    435c:	b4000062 	cbz	x2, 4368 <fwp_trap+0x34>
    4360:	aa0203e0 	mov	x0, x2
    4364:	97fff99b 	bl	29d0 <fflush@plt>
    4368:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    436c:	f947ec00 	ldr	x0, [x0, #4056]
    4370:	f9400000 	ldr	x0, [x0]
    4374:	97fff997 	bl	29d0 <fflush@plt>
    4378:	aa1303e3 	mov	x3, x19
    437c:	f0000022 	adrp	x2, b000 <__modti3+0xc0>
    4380:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc90>
    4384:	f947ea73 	ldr	x19, [x19, #4048]
    4388:	9118a042 	add	x2, x2, #0x628
    438c:	52800041 	mov	w1, #0x2                   	// #2
    4390:	f9400260 	ldr	x0, [x19]
    4394:	97fff95f 	bl	2910 <__fprintf_chk@plt>
    4398:	b40000b4 	cbz	x20, 43ac <fwp_trap+0x78>
    439c:	f9400260 	ldr	x0, [x19]
    43a0:	97fff98c 	bl	29d0 <fflush@plt>
    43a4:	52800ca0 	mov	w0, #0x65                  	// #101
    43a8:	97fff99a 	bl	2a10 <_Exit@plt>
    43ac:	52800ca0 	mov	w0, #0x65                  	// #101
    43b0:	97fff8e8 	bl	2750 <exit@plt>

00000000000043b4 <fwp_rc_forget_slot.part.0>:
    43b4:	ca404401 	eor	x1, x0, x0, lsr #17
    43b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43bc:	ca412421 	eor	x1, x1, x1, lsr #9
    43c0:	910003fd 	mov	x29, sp
    43c4:	92401c21 	and	x1, x1, #0xff
    43c8:	f9000bf3 	str	x19, [sp, #16]
    43cc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    43d0:	9118c262 	add	x2, x19, #0x630
    43d4:	910a2423 	add	x3, x1, #0x289
    43d8:	8b010c41 	add	x1, x2, x1, lsl #3
    43dc:	8b030c43 	add	x3, x2, x3, lsl #3
    43e0:	f94a2421 	ldr	x1, [x1, #5192]
    43e4:	b50000a1 	cbnz	x1, 43f8 <fwp_rc_forget_slot.part.0+0x44>
    43e8:	14000012 	b	4430 <fwp_rc_forget_slot.part.0+0x7c>
    43ec:	91004023 	add	x3, x1, #0x10
    43f0:	f9400821 	ldr	x1, [x1, #16]
    43f4:	b40001e1 	cbz	x1, 4430 <fwp_rc_forget_slot.part.0+0x7c>
    43f8:	f9400022 	ldr	x2, [x1]
    43fc:	eb02001f 	cmp	x0, x2
    4400:	54ffff61 	b.ne	43ec <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4404:	f9400060 	ldr	x0, [x3]
    4408:	9118c273 	add	x19, x19, #0x630
    440c:	f9400801 	ldr	x1, [x0, #16]
    4410:	f9000061 	str	x1, [x3]
    4414:	97fff953 	bl	2960 <free@plt>
    4418:	f94e2660 	ldr	x0, [x19, #7240]
    441c:	d1000400 	sub	x0, x0, #0x1
    4420:	f90e2660 	str	x0, [x19, #7240]
    4424:	f9400bf3 	ldr	x19, [sp, #16]
    4428:	a8c27bfd 	ldp	x29, x30, [sp], #32
    442c:	d65f03c0 	ret
    4430:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4434:	9118e000 	add	x0, x0, #0x638
    4438:	97ffffbf 	bl	4334 <fwp_trap>
    443c:	d503201f 	nop

0000000000004440 <fwp_rc_prepare_chunk>:
    4440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4444:	910003fd 	mov	x29, sp
    4448:	a9025bf5 	stp	x21, x22, [sp, #32]
    444c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4450:	9118c2c2 	add	x2, x22, #0x630
    4454:	b9401c03 	ldr	w3, [x0, #28]
    4458:	aa0103f5 	mov	x21, x1
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f4 	mov	x20, x0
    4464:	f94e2440 	ldr	x0, [x2, #7240]
    4468:	b4000440 	cbz	x0, 44f0 <fwp_rc_prepare_chunk+0xb0>
    446c:	d2800013 	mov	x19, #0x0                   	// #0
    4470:	35000203 	cbnz	w3, 44b0 <fwp_rc_prepare_chunk+0x70>
    4474:	b4000361 	cbz	x1, 44e0 <fwp_rc_prepare_chunk+0xa0>
    4478:	f9401280 	ldr	x0, [x20, #32]
    447c:	97fff939 	bl	2960 <free@plt>
    4480:	aa1503e0 	mov	x0, x21
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	97fff8fe 	bl	2880 <calloc@plt>
    448c:	f9001280 	str	x0, [x20, #32]
    4490:	b5000460 	cbnz	x0, 451c <fwp_rc_prepare_chunk+0xdc>
    4494:	97fffb37 	bl	3170 <fwp_heap_oom>
    4498:	97ffffc7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    449c:	91000673 	add	x19, x19, #0x1
    44a0:	b9401e83 	ldr	w3, [x20, #28]
    44a4:	eb13007f 	cmp	x3, x19
    44a8:	54000169 	b.ls	44d4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    44ac:	d503201f 	nop
    44b0:	f9401283 	ldr	x3, [x20, #32]
    44b4:	8b130060 	add	x0, x3, x19
    44b8:	38736863 	ldrb	w3, [x3, x19]
    44bc:	7103fc7f 	cmp	w3, #0xff
    44c0:	54fffec0 	b.eq	4498 <fwp_rc_prepare_chunk+0x58>  // b.none
    44c4:	b9401e83 	ldr	w3, [x20, #28]
    44c8:	91000673 	add	x19, x19, #0x1
    44cc:	eb13007f 	cmp	x3, x19
    44d0:	54ffff08 	b.hi	44b0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    44d4:	eb0302bf 	cmp	x21, x3
    44d8:	54000121 	b.ne	44fc <fwp_rc_prepare_chunk+0xbc>  // b.any
    44dc:	b5000335 	cbnz	x21, 4540 <fwp_rc_prepare_chunk+0x100>
    44e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	2a0303e3 	mov	w3, w3
    44f4:	eb0302bf 	cmp	x21, x3
    44f8:	54ffff20 	b.eq	44dc <fwp_rc_prepare_chunk+0x9c>  // b.none
    44fc:	9118c2c2 	add	x2, x22, #0x630
    4500:	f9401280 	ldr	x0, [x20, #32]
    4504:	f94e2841 	ldr	x1, [x2, #7248]
    4508:	cb030021 	sub	x1, x1, x3
    450c:	f90e2841 	str	x1, [x2, #7248]
    4510:	97fff914 	bl	2960 <free@plt>
    4514:	b5fffb75 	cbnz	x21, 4480 <fwp_rc_prepare_chunk+0x40>
    4518:	f900129f 	str	xzr, [x20, #32]
    451c:	9118c2d6 	add	x22, x22, #0x630
    4520:	f94e2ac0 	ldr	x0, [x22, #7248]
    4524:	b9001e95 	str	w21, [x20, #28]
    4528:	a94153f3 	ldp	x19, x20, [sp, #16]
    452c:	8b150000 	add	x0, x0, x21
    4530:	f90e2ac0 	str	x0, [x22, #7248]
    4534:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f9401280 	ldr	x0, [x20, #32]
    4544:	aa1503e2 	mov	x2, x21
    4548:	a94153f3 	ldp	x19, x20, [sp, #16]
    454c:	52800001 	mov	w1, #0x0                   	// #0
    4550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4558:	17fff8c6 	b	2870 <memset@plt>
    455c:	d503201f 	nop

0000000000004560 <fwp_heap_refill>:
    4560:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4564:	910003fd 	mov	x29, sp
    4568:	a9025bf5 	stp	x21, x22, [sp, #32]
    456c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4570:	9118c2b5 	add	x21, x21, #0x630
    4574:	aa0003f6 	mov	x22, x0
    4578:	d2800020 	mov	x0, #0x1                   	// #1
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	a90363f7 	stp	x23, x24, [sp, #48]
    4584:	2a0103f7 	mov	w23, w1
    4588:	2a0203f8 	mov	w24, w2
    458c:	97fffb09 	bl	31b0 <fwp_heap_chunks>
    4590:	aa0003f3 	mov	x19, x0
    4594:	f949fea2 	ldr	x2, [x21, #5112]
    4598:	8b000800 	add	x0, x0, x0, lsl #2
    459c:	2a1703e1 	mov	w1, w23
    45a0:	52800025 	mov	w5, #0x1                   	// #1
    45a4:	d37df000 	lsl	x0, x0, #3
    45a8:	910f0021 	add	x1, x1, #0x3c0
    45ac:	8b000054 	add	x20, x2, x0
    45b0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    45b4:	52a00024 	mov	w4, #0x10000               	// #65536
    45b8:	38206845 	strb	w5, [x2, x0]
    45bc:	aa1403e0 	mov	x0, x20
    45c0:	39000698 	strb	w24, [x20, #1]
    45c4:	39000a97 	strb	w23, [x20, #2]
    45c8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    45cc:	b9000681 	str	w1, [x20, #4]
    45d0:	2a0103e5 	mov	w5, w1
    45d4:	8b0300a2 	add	x2, x5, x3
    45d8:	1ac10881 	udiv	w1, w4, w1
    45dc:	9ac50842 	udiv	x2, x2, x5
    45e0:	b9000a81 	str	w1, [x20, #8]
    45e4:	92404021 	and	x1, x1, #0x1ffff
    45e8:	b9001a82 	str	w2, [x20, #24]
    45ec:	97ffff95 	bl	4440 <fwp_rc_prepare_chunk>
    45f0:	f949daa0 	ldr	x0, [x21, #5040]
    45f4:	29408a81 	ldp	w1, w2, [x20, #4]
    45f8:	8b134000 	add	x0, x0, x19, lsl #16
    45fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4600:	8b214003 	add	x3, x0, w1, uxtw
    4604:	9ba20021 	umaddl	x1, w1, w2, x0
    4608:	a94363f7 	ldp	x23, x24, [sp, #48]
    460c:	a90086c3 	stp	x3, x1, [x22, #8]
    4610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4614:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4618:	d65f03c0 	ret
    461c:	d503201f 	nop

0000000000004620 <fwp_mem_free>:
    4620:	b40003c0 	cbz	x0, 4698 <fwp_mem_free+0x78>
    4624:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4628:	910003fd 	mov	x29, sp
    462c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4630:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4634:	9118c2a1 	add	x1, x21, #0x630
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	aa0003f3 	mov	x19, x0
    4640:	f949d823 	ldr	x3, [x1, #5040]
    4644:	f949ec22 	ldr	x2, [x1, #5080]
    4648:	cb030000 	sub	x0, x0, x3
    464c:	eb02401f 	cmp	x0, x2, lsl #16
    4650:	540001c2 	b.cs	4688 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4654:	d350fc16 	lsr	x22, x0, #16
    4658:	a90363f7 	stp	x23, x24, [sp, #48]
    465c:	f949fc22 	ldr	x2, [x1, #5112]
    4660:	8b160ad4 	add	x20, x22, x22, lsl #2
    4664:	d37df294 	lsl	x20, x20, #3
    4668:	ab140057 	adds	x23, x2, x20
    466c:	540000c0 	b.eq	4684 <fwp_mem_free+0x64>  // b.none
    4670:	38746842 	ldrb	w2, [x2, x20]
    4674:	7100045f 	cmp	w2, #0x1
    4678:	54000120 	b.eq	469c <fwp_mem_free+0x7c>  // b.none
    467c:	7100085f 	cmp	w2, #0x2
    4680:	540005e0 	b.eq	473c <fwp_mem_free+0x11c>  // b.none
    4684:	a94363f7 	ldp	x23, x24, [sp, #48]
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4690:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4694:	d65f03c0 	ret
    4698:	d65f03c0 	ret
    469c:	f94012f8 	ldr	x24, [x23, #32]
    46a0:	b94006e1 	ldr	w1, [x23, #4]
    46a4:	f90023f9 	str	x25, [sp, #64]
    46a8:	2a0103e2 	mov	w2, w1
    46ac:	394006f9 	ldrb	w25, [x23, #1]
    46b0:	39400af4 	ldrb	w20, [x23, #2]
    46b4:	b4000158 	cbz	x24, 46dc <fwp_mem_free+0xbc>
    46b8:	92403e76 	and	x22, x19, #0xffff
    46bc:	9ac20ad6 	udiv	x22, x22, x2
    46c0:	38766b01 	ldrb	w1, [x24, x22]
    46c4:	8b160300 	add	x0, x24, x22
    46c8:	7103fc3f 	cmp	w1, #0xff
    46cc:	54000980 	b.eq	47fc <fwp_mem_free+0x1dc>  // b.none
    46d0:	38366b1f 	strb	wzr, [x24, x22]
    46d4:	b94006e1 	ldr	w1, [x23, #4]
    46d8:	2a0103e2 	mov	w2, w1
    46dc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    46e0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    46e4:	cb390000 	sub	x0, x0, w25, uxtb
    46e8:	8b340074 	add	x20, x3, w20, uxtb
    46ec:	9118c2b5 	add	x21, x21, #0x630
    46f0:	1e630021 	ucvtf	d1, w1
    46f4:	d37ae400 	lsl	x0, x0, #6
    46f8:	8b140c14 	add	x20, x0, x20, lsl #3
    46fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4700:	f8746aa0 	ldr	x0, [x21, x20]
    4704:	f94023f9 	ldr	x25, [sp, #64]
    4708:	aa2003e0 	mvn	x0, x0
    470c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4710:	f9000260 	str	x0, [x19]
    4714:	f8346ab3 	str	x19, [x21, x20]
    4718:	f94a12a0 	ldr	x0, [x21, #5152]
    471c:	1e612800 	fadd	d0, d0, d1
    4720:	a94153f3 	ldp	x19, x20, [sp, #16]
    4724:	cb020000 	sub	x0, x0, x2
    4728:	f90a12a0 	str	x0, [x21, #5152]
    472c:	fd0a22a0 	str	d0, [x21, #5184]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4738:	d65f03c0 	ret
    473c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4740:	8b000063 	add	x3, x3, x0
    4744:	eb03027f 	cmp	x19, x3
    4748:	54fff9e1 	b.ne	4684 <fwp_mem_free+0x64>  // b.any
    474c:	fd400ae1 	ldr	d1, [x23, #16]
    4750:	fd4a2020 	ldr	d0, [x1, #5184]
    4754:	f9400ae0 	ldr	x0, [x23, #16]
    4758:	7e61d821 	ucvtf	d1, d1
    475c:	f94a1022 	ldr	x2, [x1, #5152]
    4760:	f94012f3 	ldr	x19, [x23, #32]
    4764:	1e612800 	fadd	d0, d0, d1
    4768:	cb000042 	sub	x2, x2, x0
    476c:	f90a1022 	str	x2, [x1, #5152]
    4770:	fd0a2020 	str	d0, [x1, #5184]
    4774:	b40000b3 	cbz	x19, 4788 <fwp_mem_free+0x168>
    4778:	39400260 	ldrb	w0, [x19]
    477c:	7103fc1f 	cmp	w0, #0xff
    4780:	54000380 	b.eq	47f0 <fwp_mem_free+0x1d0>  // b.none
    4784:	3900027f 	strb	wzr, [x19]
    4788:	b9400ee2 	ldr	w2, [x23, #12]
    478c:	b4000142 	cbz	x2, 47b4 <fwp_mem_free+0x194>
    4790:	9118c2a1 	add	x1, x21, #0x630
    4794:	8b160040 	add	x0, x2, x22
    4798:	8b000800 	add	x0, x0, x0, lsl #2
    479c:	f949fc21 	ldr	x1, [x1, #5112]
    47a0:	8b140034 	add	x20, x1, x20
    47a4:	8b000c20 	add	x0, x1, x0, lsl #3
    47a8:	3802869f 	strb	wzr, [x20], #40
    47ac:	eb00029f 	cmp	x20, x0
    47b0:	54ffffc1 	b.ne	47a8 <fwp_mem_free+0x188>  // b.any
    47b4:	9118c2a0 	add	x0, x21, #0x630
    47b8:	f94a1801 	ldr	x1, [x0, #5168]
    47bc:	f949f803 	ldr	x3, [x0, #5104]
    47c0:	8b020021 	add	x1, x1, x2
    47c4:	f90a1801 	str	x1, [x0, #5168]
    47c8:	eb16007f 	cmp	x3, x22
    47cc:	54000049 	b.ls	47d4 <fwp_mem_free+0x1b4>  // b.plast
    47d0:	f909f816 	str	x22, [x0, #5104]
    47d4:	9118c2b5 	add	x21, x21, #0x630
    47d8:	f949f6a0 	ldr	x0, [x21, #5096]
    47dc:	eb16001f 	cmp	x0, x22
    47e0:	54fff529 	b.ls	4684 <fwp_mem_free+0x64>  // b.plast
    47e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47e8:	f909f6b6 	str	x22, [x21, #5096]
    47ec:	17ffffa7 	b	4688 <fwp_mem_free+0x68>
    47f0:	aa1303e0 	mov	x0, x19
    47f4:	97fffef0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    47f8:	17ffffe3 	b	4784 <fwp_mem_free+0x164>
    47fc:	97fffeee 	bl	43b4 <fwp_rc_forget_slot.part.0>
    4800:	17ffffb4 	b	46d0 <fwp_mem_free+0xb0>

0000000000004804 <fwp_rc_wide_dup>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	910003fd 	mov	x29, sp
    480c:	a90153f3 	stp	x19, x20, [sp, #16]
    4810:	aa0003f3 	mov	x19, x0
    4814:	ca404400 	eor	x0, x0, x0, lsr #17
    4818:	f90013f5 	str	x21, [sp, #32]
    481c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4820:	ca402400 	eor	x0, x0, x0, lsr #9
    4824:	9118c2a2 	add	x2, x21, #0x630
    4828:	92401c00 	and	x0, x0, #0xff
    482c:	910a2403 	add	x3, x0, #0x289
    4830:	8b000c40 	add	x0, x2, x0, lsl #3
    4834:	8b030c54 	add	x20, x2, x3, lsl #3
    4838:	f94a2401 	ldr	x1, [x0, #5192]
    483c:	b50000a1 	cbnz	x1, 4850 <fwp_rc_wide_dup+0x4c>
    4840:	14000033 	b	490c <fwp_rc_wide_dup+0x108>
    4844:	91004034 	add	x20, x1, #0x10
    4848:	f9400821 	ldr	x1, [x1, #16]
    484c:	b4000241 	cbz	x1, 4894 <fwp_rc_wide_dup+0x90>
    4850:	f9400022 	ldr	x2, [x1]
    4854:	eb02027f 	cmp	x19, x2
    4858:	54ffff61 	b.ne	4844 <fwp_rc_wide_dup+0x40>  // b.any
    485c:	f9400281 	ldr	x1, [x20]
    4860:	39400260 	ldrb	w0, [x19]
    4864:	7103f81f 	cmp	w0, #0xfe
    4868:	54000220 	b.eq	48ac <fwp_rc_wide_dup+0xa8>  // b.none
    486c:	b40001a1 	cbz	x1, 48a0 <fwp_rc_wide_dup+0x9c>
    4870:	f9400420 	ldr	x0, [x1, #8]
    4874:	b100041f 	cmn	x0, #0x1
    4878:	54000440 	b.eq	4900 <fwp_rc_wide_dup+0xfc>  // b.none
    487c:	91000400 	add	x0, x0, #0x1
    4880:	f9000420 	str	x0, [x1, #8]
    4884:	a94153f3 	ldp	x19, x20, [sp, #16]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	39400260 	ldrb	w0, [x19]
    4898:	7103f81f 	cmp	w0, #0xfe
    489c:	54000100 	b.eq	48bc <fwp_rc_wide_dup+0xb8>  // b.none
    48a0:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    48a4:	9118e000 	add	x0, x0, #0x638
    48a8:	97fffea3 	bl	4334 <fwp_trap>
    48ac:	b4000081 	cbz	x1, 48bc <fwp_rc_wide_dup+0xb8>
    48b0:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    48b4:	91198000 	add	x0, x0, #0x660
    48b8:	97fffe9f 	bl	4334 <fwp_trap>
    48bc:	d2800300 	mov	x0, #0x18                  	// #24
    48c0:	97fff7e0 	bl	2840 <malloc@plt>
    48c4:	b4000280 	cbz	x0, 4914 <fwp_rc_wide_dup+0x110>
    48c8:	d2801fe1 	mov	x1, #0xff                  	// #255
    48cc:	a9000413 	stp	x19, x1, [x0]
    48d0:	9118c2b5 	add	x21, x21, #0x630
    48d4:	f900081f 	str	xzr, [x0, #16]
    48d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    48dc:	f9000280 	str	x0, [x20]
    48e0:	39000261 	strb	w1, [x19]
    48e4:	f94e26a0 	ldr	x0, [x21, #7240]
    48e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f90e26a0 	str	x0, [x21, #7240]
    48f4:	f94013f5 	ldr	x21, [sp, #32]
    48f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48fc:	d65f03c0 	ret
    4900:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4904:	911a2000 	add	x0, x0, #0x688
    4908:	97fffe8b 	bl	4334 <fwp_trap>
    490c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4910:	17ffffd4 	b	4860 <fwp_rc_wide_dup+0x5c>
    4914:	97fffa17 	bl	3170 <fwp_heap_oom>
    4918:	d503201f 	nop
    491c:	d503201f 	nop

0000000000004920 <fwp_closure_drop_push>:
    4920:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4924:	910003fd 	mov	x29, sp
    4928:	a90153f3 	stp	x19, x20, [sp, #16]
    492c:	aa0003f3 	mov	x19, x0
    4930:	a9408014 	ldp	x20, x0, [x0, #8]
    4934:	a9025bf5 	stp	x21, x22, [sp, #32]
    4938:	aa0103f5 	mov	x21, x1
    493c:	a90363f7 	stp	x23, x24, [sp, #48]
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000160 	b.eq	4970 <fwp_closure_drop_push+0x50>  // b.none
    4948:	f9400276 	ldr	x22, [x19]
    494c:	d37df297 	lsl	x23, x20, #3
    4950:	91000694 	add	x20, x20, #0x1
    4954:	f9000674 	str	x20, [x19, #8]
    4958:	a94153f3 	ldp	x19, x20, [sp, #16]
    495c:	f8376ad5 	str	x21, [x22, x23]
    4960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4964:	a94363f7 	ldp	x23, x24, [sp, #48]
    4968:	a8c57bfd 	ldp	x29, x30, [sp], #80
    496c:	d65f03c0 	ret
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4978:	eb00029f 	cmp	x20, x0
    497c:	540003e8 	b.hi	49f8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4980:	d37cee99 	lsl	x25, x20, #4
    4984:	d37ffa9a 	lsl	x26, x20, #1
    4988:	aa1903e0 	mov	x0, x25
    498c:	97fff7ad 	bl	2840 <malloc@plt>
    4990:	aa0003f6 	mov	x22, x0
    4994:	b4000380 	cbz	x0, 4a04 <fwp_closure_drop_push+0xe4>
    4998:	aa1303f8 	mov	x24, x19
    499c:	aa1903e3 	mov	x3, x25
    49a0:	d37df297 	lsl	x23, x20, #3
    49a4:	aa1703e2 	mov	x2, x23
    49a8:	f8418719 	ldr	x25, [x24], #24
    49ac:	aa1903e1 	mov	x1, x25
    49b0:	97fff790 	bl	27f0 <__memcpy_chk@plt>
    49b4:	eb18033f 	cmp	x25, x24
    49b8:	540000a0 	b.eq	49cc <fwp_closure_drop_push+0xac>  // b.none
    49bc:	aa1903e0 	mov	x0, x25
    49c0:	97fff7e8 	bl	2960 <free@plt>
    49c4:	f9400674 	ldr	x20, [x19, #8]
    49c8:	d37df297 	lsl	x23, x20, #3
    49cc:	91000694 	add	x20, x20, #0x1
    49d0:	f9000276 	str	x22, [x19]
    49d4:	f9000a7a 	str	x26, [x19, #16]
    49d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    49dc:	f9000674 	str	x20, [x19, #8]
    49e0:	f8376ad5 	str	x21, [x22, x23]
    49e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    49f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49f4:	d65f03c0 	ret
    49f8:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    49fc:	911aa000 	add	x0, x0, #0x6a8
    4a00:	97fffe4d 	bl	4334 <fwp_trap>
    4a04:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a08:	f947e863 	ldr	x3, [x3, #4048]
    4a0c:	d2800262 	mov	x2, #0x13                  	// #19
    4a10:	d2800021 	mov	x1, #0x1                   	// #1
    4a14:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4a18:	910ba000 	add	x0, x0, #0x2e8
    4a1c:	f9400063 	ldr	x3, [x3]
    4a20:	97fff7e0 	bl	29a0 <fwrite@plt>
    4a24:	d2800000 	mov	x0, #0x0                   	// #0
    4a28:	97fff7ea 	bl	29d0 <fflush@plt>
    4a2c:	52800cc0 	mov	w0, #0x66                  	// #102
    4a30:	97fff7f8 	bl	2a10 <_Exit@plt>

0000000000004a34 <fwp_closure_drop.part.0>:
    4a34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a38:	90000041 	adrp	x1, c000 <_IO_stdin_used+0xd20>
    4a3c:	910003fd 	mov	x29, sp
    4a40:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a44:	f947f463 	ldr	x3, [x3, #4072]
    4a48:	a90153f3 	stp	x19, x20, [sp, #16]
    4a4c:	d10883ff 	sub	sp, sp, #0x220
    4a50:	910003e2 	mov	x2, sp
    4a54:	d53bd053 	mrs	x19, tpidr_el0
    4a58:	910063f4 	add	x20, sp, #0x18
    4a5c:	3dc0ac20 	ldr	q0, [x1, #688]
    4a60:	91400264 	add	x4, x19, #0x0, lsl #12
    4a64:	91004084 	add	x4, x4, #0x10
    4a68:	aa0003e1 	mov	x1, x0
    4a6c:	aa0203e0 	mov	x0, x2
    4a70:	f9400062 	ldr	x2, [x3]
    4a74:	f9010fe2 	str	x2, [sp, #536]
    4a78:	d2800002 	mov	x2, #0x0                   	// #0
    4a7c:	f90003f4 	str	x20, [sp]
    4a80:	f9000080 	str	x0, [x4]
    4a84:	3c8083e0 	stur	q0, [sp, #8]
    4a88:	97ffffa6 	bl	4920 <fwp_closure_drop_push>
    4a8c:	f94007e0 	ldr	x0, [sp, #8]
    4a90:	b40002e0 	cbz	x0, 4aec <fwp_closure_drop.part.0+0xb8>
    4a94:	f90123f5 	str	x21, [sp, #576]
    4a98:	900000f5 	adrp	x21, 20000 <__data_start>
    4a9c:	910142b5 	add	x21, x21, #0x50
    4aa0:	14000006 	b	4ab8 <fwp_closure_drop.part.0+0x84>
    4aa4:	f9400422 	ldr	x2, [x1, #8]
    4aa8:	52800001 	mov	w1, #0x0                   	// #0
    4aac:	d63f0040 	blr	x2
    4ab0:	f94007e0 	ldr	x0, [sp, #8]
    4ab4:	b40001a0 	cbz	x0, 4ae8 <fwp_closure_drop.part.0+0xb4>
    4ab8:	f94003e1 	ldr	x1, [sp]
    4abc:	d1000400 	sub	x0, x0, #0x1
    4ac0:	f90007e0 	str	x0, [sp, #8]
    4ac4:	f9408ea2 	ldr	x2, [x21, #280]
    4ac8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4acc:	b9400001 	ldr	w1, [x0]
    4ad0:	8b011441 	add	x1, x2, x1, lsl #5
    4ad4:	f9400c21 	ldr	x1, [x1, #24]
    4ad8:	b5fffe61 	cbnz	x1, 4aa4 <fwp_closure_drop.part.0+0x70>
    4adc:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4ae0:	911b2000 	add	x0, x0, #0x6c8
    4ae4:	97fffe14 	bl	4334 <fwp_trap>
    4ae8:	f94123f5 	ldr	x21, [sp, #576]
    4aec:	91400273 	add	x19, x19, #0x0, lsl #12
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	f94003e0 	ldr	x0, [sp]
    4af8:	f900027f 	str	xzr, [x19]
    4afc:	eb14001f 	cmp	x0, x20
    4b00:	54000040 	b.eq	4b08 <fwp_closure_drop.part.0+0xd4>  // b.none
    4b04:	97fff797 	bl	2960 <free@plt>
    4b08:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4b0c:	f947f400 	ldr	x0, [x0, #4072]
    4b10:	f9410fe2 	ldr	x2, [sp, #536]
    4b14:	f9400001 	ldr	x1, [x0]
    4b18:	eb010042 	subs	x2, x2, x1
    4b1c:	d2800001 	mov	x1, #0x0                   	// #0
    4b20:	540000a1 	b.ne	4b34 <fwp_closure_drop.part.0+0x100>  // b.any
    4b24:	910883ff 	add	sp, sp, #0x220
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b30:	d65f03c0 	ret
    4b34:	f90123f5 	str	x21, [sp, #576]
    4b38:	97fff75a 	bl	28a0 <__stack_chk_fail@plt>
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_tape_of>:
    4b40:	aa0003e1 	mov	x1, x0
    4b44:	92403c00 	and	x0, x0, #0xffff
    4b48:	b40000e0 	cbz	x0, 4b64 <fwp_tape_of+0x24>
    4b4c:	d1000402 	sub	x2, x0, #0x1
    4b50:	900000e0 	adrp	x0, 20000 <__data_start>
    4b54:	91014000 	add	x0, x0, #0x50
    4b58:	f9409003 	ldr	x3, [x0, #288]
    4b5c:	eb02007f 	cmp	x3, x2
    4b60:	540000cc 	b.gt	4b78 <fwp_tape_of+0x38>
    4b64:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b68:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4b6c:	911be000 	add	x0, x0, #0x6f8
    4b70:	910003fd 	mov	x29, sp
    4b74:	97fffdf0 	bl	4334 <fwp_trap>
    4b78:	8b020443 	add	x3, x2, x2, lsl #1
    4b7c:	f9404404 	ldr	x4, [x0, #136]
    4b80:	8b030842 	add	x2, x2, x3, lsl #2
    4b84:	d37df042 	lsl	x2, x2, #3
    4b88:	8b020080 	add	x0, x4, x2
    4b8c:	b9400403 	ldr	w3, [x0, #4]
    4b90:	34fffea3 	cbz	w3, 4b64 <fwp_tape_of+0x24>
    4b94:	b8626882 	ldr	w2, [x4, x2]
    4b98:	9350fc21 	asr	x1, x1, #16
    4b9c:	6b01005f 	cmp	w2, w1
    4ba0:	54fffe21 	b.ne	4b64 <fwp_tape_of+0x24>  // b.any
    4ba4:	d65f03c0 	ret
    4ba8:	d503201f 	nop
    4bac:	d503201f 	nop

0000000000004bb0 <fwp_now_ns>:
    4bb0:	d100c3ff 	sub	sp, sp, #0x30
    4bb4:	52800020 	mov	w0, #0x1                   	// #1
    4bb8:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    4bbc:	f947f442 	ldr	x2, [x2, #4072]
    4bc0:	910023e1 	add	x1, sp, #0x8
    4bc4:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bc8:	910083fd 	add	x29, sp, #0x20
    4bcc:	f9400043 	ldr	x3, [x2]
    4bd0:	f9000fe3 	str	x3, [sp, #24]
    4bd4:	d2800003 	mov	x3, #0x0                   	// #0
    4bd8:	97fff6fe 	bl	27d0 <clock_gettime@plt>
    4bdc:	350002c0 	cbnz	w0, 4c34 <fwp_now_ns+0x84>
    4be0:	a9408be1 	ldp	x1, x2, [sp, #8]
    4be4:	d2994003 	mov	x3, #0xca00                	// #51712
    4be8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4bec:	9b037c20 	mul	x0, x1, x3
    4bf0:	9b437c21 	smulh	x1, x1, x3
    4bf4:	ab020000 	adds	x0, x0, x2
    4bf8:	937ffc42 	asr	x2, x2, #63
    4bfc:	9a020021 	adc	x1, x1, x2
    4c00:	f100001f 	cmp	x0, #0x0
    4c04:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4c08:	b50001c1 	cbnz	x1, 4c40 <fwp_now_ns+0x90>
    4c0c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    4c10:	f947f421 	ldr	x1, [x1, #4072]
    4c14:	f9400fe3 	ldr	x3, [sp, #24]
    4c18:	f9400022 	ldr	x2, [x1]
    4c1c:	eb020063 	subs	x3, x3, x2
    4c20:	d2800002 	mov	x2, #0x0                   	// #0
    4c24:	54000141 	b.ne	4c4c <fwp_now_ns+0x9c>  // b.any
    4c28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c2c:	9100c3ff 	add	sp, sp, #0x30
    4c30:	d65f03c0 	ret
    4c34:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4c38:	911d2000 	add	x0, x0, #0x748
    4c3c:	97fffdbe 	bl	4334 <fwp_trap>
    4c40:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4c44:	911da000 	add	x0, x0, #0x768
    4c48:	97fffdbb 	bl	4334 <fwp_trap>
    4c4c:	97fff715 	bl	28a0 <__stack_chk_fail@plt>

0000000000004c50 <fwp_poll_events>:
    4c50:	d10103ff 	sub	sp, sp, #0x40
    4c54:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4c58:	f947f400 	ldr	x0, [x0, #4072]
    4c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c60:	910083fd 	add	x29, sp, #0x20
    4c64:	f9001bf3 	str	x19, [sp, #48]
    4c68:	900000f3 	adrp	x19, 20000 <__data_start>
    4c6c:	f9400001 	ldr	x1, [x0]
    4c70:	f9000fe1 	str	x1, [sp, #24]
    4c74:	d2800001 	mov	x1, #0x0                   	// #0
    4c78:	97ffffce 	bl	4bb0 <fwp_now_ns>
    4c7c:	91014261 	add	x1, x19, #0x50
    4c80:	f9409421 	ldr	x1, [x1, #296]
    4c84:	b4000e01 	cbz	x1, 4e44 <fwp_poll_events+0x1f4>
    4c88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c8c:	14000005 	b	4ca0 <fwp_poll_events+0x50>
    4c90:	f9408821 	ldr	x1, [x1, #272]
    4c94:	eb03005f 	cmp	x2, x3
    4c98:	9a83d042 	csel	x2, x2, x3, le
    4c9c:	b40000c1 	cbz	x1, 4cb4 <fwp_poll_events+0x64>
    4ca0:	f9403423 	ldr	x3, [x1, #104]
    4ca4:	b6ffff62 	tbz	x2, #63, 4c90 <fwp_poll_events+0x40>
    4ca8:	f9408821 	ldr	x1, [x1, #272]
    4cac:	aa0303e2 	mov	x2, x3
    4cb0:	b5ffff81 	cbnz	x1, 4ca0 <fwp_poll_events+0x50>
    4cb4:	b7f80c82 	tbnz	x2, #63, 4e44 <fwp_poll_events+0x1f4>
    4cb8:	cb000042 	sub	x2, x2, x0
    4cbc:	f100005f 	cmp	x2, #0x0
    4cc0:	540003ad 	b.le	4d34 <fwp_poll_events+0xe4>
    4cc4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4cc8:	d2884804 	mov	x4, #0x4240                	// #16960
    4ccc:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4cd0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4cd4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4cd8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4cdc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ce0:	9b407c40 	smulh	x0, x2, x0
    4ce4:	9352fc00 	asr	x0, x0, #18
    4ce8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4cec:	9b048802 	msub	x2, x0, x4, x2
    4cf0:	f100005f 	cmp	x2, #0x0
    4cf4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4cf8:	eb01001f 	cmp	x0, x1
    4cfc:	5400098c 	b.gt	4e2c <fwp_poll_events+0x1dc>
    4d00:	340001a0 	cbz	w0, 4d34 <fwp_poll_events+0xe4>
    4d04:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4d08:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4d0c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4d10:	9ba17c01 	umull	x1, w0, w1
    4d14:	d366fc23 	lsr	x3, x1, #38
    4d18:	aa0303e2 	mov	x2, x3
    4d1c:	1b058063 	msub	w3, w3, w5, w0
    4d20:	9b247c63 	smull	x3, w3, w4
    4d24:	910023e0 	add	x0, sp, #0x8
    4d28:	d2800001 	mov	x1, #0x0                   	// #0
    4d2c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4d30:	97fff710 	bl	2970 <nanosleep@plt>
    4d34:	97ffff9f 	bl	4bb0 <fwp_now_ns>
    4d38:	91014268 	add	x8, x19, #0x50
    4d3c:	aa0003e7 	mov	x7, x0
    4d40:	4f000400 	movi	v0.4s, #0x0
    4d44:	52800029 	mov	w9, #0x1                   	// #1
    4d48:	f9409506 	ldr	x6, [x8, #296]
    4d4c:	d503201f 	nop
    4d50:	b40003e6 	cbz	x6, 4dcc <fwp_poll_events+0x17c>
    4d54:	f94034c1 	ldr	x1, [x6, #104]
    4d58:	aa0603e5 	mov	x5, x6
    4d5c:	f94088c6 	ldr	x6, [x6, #272]
    4d60:	eb07003f 	cmp	x1, x7
    4d64:	54ffff6c 	b.gt	4d50 <fwp_poll_events+0x100>
    4d68:	394154a0 	ldrb	w0, [x5, #85]
    4d6c:	36000120 	tbz	w0, #0, 4d90 <fwp_poll_events+0x140>
    4d70:	f94084a0 	ldr	x0, [x5, #264]
    4d74:	b4000560 	cbz	x0, 4e20 <fwp_poll_events+0x1d0>
    4d78:	f9008806 	str	x6, [x0, #272]
    4d7c:	b4000046 	cbz	x6, 4d84 <fwp_poll_events+0x134>
    4d80:	f90084c0 	str	x0, [x6, #264]
    4d84:	910800a0 	add	x0, x5, #0x200
    4d88:	390154bf 	strb	wzr, [x5, #85]
    4d8c:	3c908000 	stur	q0, [x0, #-248]
    4d90:	f94030a0 	ldr	x0, [x5, #96]
    4d94:	390158a9 	strb	w9, [x5, #86]
    4d98:	f100001f 	cmp	x0, #0x0
    4d9c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4da0:	540002cd 	b.le	4df8 <fwp_poll_events+0x1a8>
    4da4:	f94028a0 	ldr	x0, [x5, #80]
    4da8:	f2001c1f 	tst	x0, #0xff000000ff
    4dac:	54fffd21 	b.ne	4d50 <fwp_poll_events+0x100>  // b.any
    4db0:	f9406100 	ldr	x0, [x8, #192]
    4db4:	390150a9 	strb	w9, [x5, #84]
    4db8:	f90080bf 	str	xzr, [x5, #256]
    4dbc:	b40002c0 	cbz	x0, 4e14 <fwp_poll_events+0x1c4>
    4dc0:	f9006105 	str	x5, [x8, #192]
    4dc4:	f9008005 	str	x5, [x0, #256]
    4dc8:	b5fffc66 	cbnz	x6, 4d54 <fwp_poll_events+0x104>
    4dcc:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4dd0:	f947f400 	ldr	x0, [x0, #4072]
    4dd4:	f9400fe2 	ldr	x2, [sp, #24]
    4dd8:	f9400001 	ldr	x1, [x0]
    4ddc:	eb010042 	subs	x2, x2, x1
    4de0:	d2800001 	mov	x1, #0x0                   	// #0
    4de4:	540002e1 	b.ne	4e40 <fwp_poll_events+0x1f0>  // b.any
    4de8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4dec:	f9401bf3 	ldr	x19, [sp, #48]
    4df0:	910103ff 	add	sp, sp, #0x40
    4df4:	d65f03c0 	ret
    4df8:	394144a0 	ldrb	w0, [x5, #81]
    4dfc:	3707fd40 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e00:	394140a0 	ldrb	w0, [x5, #80]
    4e04:	3707fd00 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e08:	aa0503e0 	mov	x0, x5
    4e0c:	97fffa39 	bl	36f0 <fwp_cancel_tree.part.0>
    4e10:	17ffffe5 	b	4da4 <fwp_poll_events+0x154>
    4e14:	f9006105 	str	x5, [x8, #192]
    4e18:	f9006505 	str	x5, [x8, #200]
    4e1c:	17ffffeb 	b	4dc8 <fwp_poll_events+0x178>
    4e20:	91014261 	add	x1, x19, #0x50
    4e24:	f9009426 	str	x6, [x1, #296]
    4e28:	17ffffd5 	b	4d7c <fwp_poll_events+0x12c>
    4e2c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4e30:	d2989362 	mov	x2, #0xc49b                	// #50331
    4e34:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4e38:	f2a00402 	movk	x2, #0x20, lsl #16
    4e3c:	17ffffba 	b	4d24 <fwp_poll_events+0xd4>
    4e40:	97fff698 	bl	28a0 <__stack_chk_fail@plt>
    4e44:	97fff88c 	bl	3074 <fwp_flush>
    4e48:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4e4c:	f947e863 	ldr	x3, [x3, #4048]
    4e50:	d2800562 	mov	x2, #0x2b                  	// #43
    4e54:	d2800021 	mov	x1, #0x1                   	// #1
    4e58:	f0000020 	adrp	x0, b000 <__modti3+0xc0>
    4e5c:	911e4000 	add	x0, x0, #0x790
    4e60:	f9400063 	ldr	x3, [x3]
    4e64:	97fff6cf 	bl	29a0 <fwrite@plt>
    4e68:	52800ca0 	mov	w0, #0x65                  	// #101
    4e6c:	97fff639 	bl	2750 <exit@plt>

0000000000004e70 <fwp_heap_alloc_big>:
    4e70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	a90153f3 	stp	x19, x20, [sp, #16]
    4e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e80:	a90363f7 	stp	x23, x24, [sp, #48]
    4e84:	aa0003f7 	mov	x23, x0
    4e88:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e8c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e90:	eb0002ff 	cmp	x23, x0
    4e94:	540008a8 	b.hi	4fa8 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e9c:	8b0002f4 	add	x20, x23, x0
    4ea0:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea4:	9118c359 	add	x25, x26, #0x630
    4ea8:	d350fe94 	lsr	x20, x20, #16
    4eac:	2a0103f5 	mov	w21, w1
    4eb0:	aa1403e0 	mov	x0, x20
    4eb4:	97fff8bf 	bl	31b0 <fwp_heap_chunks>
    4eb8:	f949ff22 	ldr	x2, [x25, #5112]
    4ebc:	8b000813 	add	x19, x0, x0, lsl #2
    4ec0:	aa0003f8 	mov	x24, x0
    4ec4:	52800043 	mov	w3, #0x2                   	// #2
    4ec8:	d37df273 	lsl	x19, x19, #3
    4ecc:	d2800021 	mov	x1, #0x1                   	// #1
    4ed0:	8b130040 	add	x0, x2, x19
    4ed4:	38336843 	strb	w3, [x2, x19]
    4ed8:	39000415 	strb	w21, [x0, #1]
    4edc:	b9000c14 	str	w20, [x0, #12]
    4ee0:	f9000817 	str	x23, [x0, #16]
    4ee4:	97fffd57 	bl	4440 <fwp_rc_prepare_chunk>
    4ee8:	f100069f 	cmp	x20, #0x1
    4eec:	54000289 	b.ls	4f3c <fwp_heap_alloc_big+0xcc>  // b.plast
    4ef0:	8b180294 	add	x20, x20, x24
    4ef4:	9100a273 	add	x19, x19, #0x28
    4ef8:	a90573fb 	stp	x27, x28, [sp, #80]
    4efc:	5280007b 	mov	w27, #0x3                   	// #3
    4f00:	8b140a94 	add	x20, x20, x20, lsl #2
    4f04:	2a1803fc 	mov	w28, w24
    4f08:	9adb2296 	lsl	x22, x20, x27
    4f0c:	d503201f 	nop
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffd48 	bl	4440 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0xa0>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x108>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffb37 	bl	3d70 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff6f 	b	4e70 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffd19 	bl	4560 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	540008a1 	b.ne	524c <fwp_heap_alloc+0x13c>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	54000722 	b.cs	5298 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	5400030c 	b.gt	5260 <fwp_heap_alloc+0x150>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000249 	b.ls	527c <fwp_heap_alloc+0x16c>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	910142c1 	add	x1, x22, #0x50
    5244:	b9413038 	ldr	w24, [x1, #304]
    5248:	17ffffe6 	b	51e0 <fwp_heap_alloc+0xd0>
    524c:	a9538c44 	ldp	x4, x3, [x2, #312]
    5250:	91000484 	add	x4, x4, #0x1
    5254:	8b000063 	add	x3, x3, x0
    5258:	a9138c44 	stp	x4, x3, [x2, #312]
    525c:	17ffffb8 	b	513c <fwp_heap_alloc+0x2c>
    5260:	a94153f3 	ldp	x19, x20, [sp, #16]
    5264:	fd00a800 	str	d0, [x0, #336]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	aa0403e0 	mov	x0, x4
    5270:	a94363f7 	ldp	x23, x24, [sp, #48]
    5274:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5278:	d65f03c0 	ret
    527c:	7100043f 	cmp	w1, #0x1
    5280:	8b140085 	add	x5, x4, x20
    5284:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5288:	52800001 	mov	w1, #0x0                   	// #0
    528c:	aa0403e0 	mov	x0, x4
    5290:	f9000465 	str	x5, [x3, #8]
    5294:	17ffffc4 	b	51a4 <fwp_heap_alloc+0x94>
    5298:	97fff7b6 	bl	3170 <fwp_heap_oom>
    529c:	d503201f 	nop

00000000000052a0 <fwp_data.part.0.constprop.0>:
    52a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52a4:	910003fd 	mov	x29, sp
    52a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    52ac:	f00000d6 	adrp	x22, 20000 <__data_start>
    52b0:	910142c2 	add	x2, x22, #0x50
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	b9413059 	ldr	w25, [x2, #304]
    52bc:	a90153f3 	stp	x19, x20, [sp, #16]
    52c0:	aa0103f4 	mov	x20, x1
    52c4:	a90363f7 	stp	x23, x24, [sp, #48]
    52c8:	2a0003f7 	mov	w23, w0
    52cc:	340000b9 	cbz	w25, 52e0 <fwp_data.part.0.constprop.0+0x40>
    52d0:	a9538041 	ldp	x1, x0, [x2, #312]
    52d4:	91000421 	add	x1, x1, #0x1
    52d8:	91006000 	add	x0, x0, #0x18
    52dc:	a9138041 	stp	x1, x0, [x2, #312]
    52e0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52e4:	9118c2a3 	add	x3, x21, #0x630
    52e8:	b953a460 	ldr	w0, [x3, #5028]
    52ec:	34000840 	cbz	w0, 53f4 <fwp_data.part.0.constprop.0+0x154>
    52f0:	397e8862 	ldrb	w2, [x3, #4002]
    52f4:	910f0040 	add	x0, x2, #0x3c0
    52f8:	8b020442 	add	x2, x2, x2, lsl #1
    52fc:	d37df042 	lsl	x2, x2, #3
    5300:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5304:	2a1a03f8 	mov	w24, w26
    5308:	f8626873 	ldr	x19, [x3, x2]
    530c:	b4000613 	cbz	x19, 53cc <fwp_data.part.0.constprop.0+0x12c>
    5310:	f9400260 	ldr	x0, [x19]
    5314:	aa2003e0 	mvn	x0, x0
    5318:	f8226860 	str	x0, [x3, x2]
    531c:	f100631f 	cmp	x24, #0x18
    5320:	540000e9 	b.ls	533c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5324:	d1006702 	sub	x2, x24, #0x19
    5328:	91006260 	add	x0, x19, #0x18
    532c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5330:	52800001 	mov	w1, #0x0                   	// #0
    5334:	91002042 	add	x2, x2, #0x8
    5338:	97fff54e 	bl	2870 <memset@plt>
    533c:	9118c2a0 	add	x0, x21, #0x630
    5340:	f94a1001 	ldr	x1, [x0, #5152]
    5344:	ab180021 	adds	x1, x1, x24
    5348:	54000682 	b.cs	5418 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    534c:	f94a1402 	ldr	x2, [x0, #5160]
    5350:	f90a1001 	str	x1, [x0, #5152]
    5354:	eb02003f 	cmp	x1, x2
    5358:	54000049 	b.ls	5360 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    535c:	f90a1401 	str	x1, [x0, #5160]
    5360:	9118c2a0 	add	x0, x21, #0x630
    5364:	1e630341 	ucvtf	d1, w26
    5368:	fd4a1c00 	ldr	d0, [x0, #5176]
    536c:	1e612800 	fadd	d0, d0, d1
    5370:	fd0a1c00 	str	d0, [x0, #5176]
    5374:	34000139 	cbz	w25, 5398 <fwp_data.part.0.constprop.0+0xf8>
    5378:	9118c2b5 	add	x21, x21, #0x630
    537c:	910142d6 	add	x22, x22, #0x50
    5380:	fd4a12a0 	ldr	d0, [x21, #5152]
    5384:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5388:	7e61d800 	ucvtf	d0, d0
    538c:	1e623800 	fsub	d0, d0, d2
    5390:	1e612010 	fcmpe	d0, d1
    5394:	540003ec 	b.gt	5410 <fwp_data.part.0.constprop.0+0x170>
    5398:	52800040 	mov	w0, #0x2                   	// #2
    539c:	29000277 	stp	w23, w0, [x19]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	f9400281 	ldr	x1, [x20]
    53a8:	f9000661 	str	x1, [x19, #8]
    53ac:	f9400681 	ldr	x1, [x20, #8]
    53b0:	f9000a61 	str	x1, [x19, #16]
    53b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    53c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53c8:	d65f03c0 	ret
    53cc:	8b020063 	add	x3, x3, x2
    53d0:	f9400473 	ldr	x19, [x3, #8]
    53d4:	b4000113 	cbz	x19, 53f4 <fwp_data.part.0.constprop.0+0x154>
    53d8:	f9400860 	ldr	x0, [x3, #16]
    53dc:	cb130000 	sub	x0, x0, x19
    53e0:	eb00031f 	cmp	x24, x0
    53e4:	54000088 	b.hi	53f4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53e8:	8b180260 	add	x0, x19, x24
    53ec:	f9000460 	str	x0, [x3, #8]
    53f0:	17ffffcb 	b	531c <fwp_data.part.0.constprop.0+0x7c>
    53f4:	52800001 	mov	w1, #0x0                   	// #0
    53f8:	d2800300 	mov	x0, #0x18                  	// #24
    53fc:	97ffff45 	bl	5110 <fwp_heap_alloc>
    5400:	aa0003f3 	mov	x19, x0
    5404:	910142c1 	add	x1, x22, #0x50
    5408:	b9413039 	ldr	w25, [x1, #304]
    540c:	17ffffda 	b	5374 <fwp_data.part.0.constprop.0+0xd4>
    5410:	fd00aac0 	str	d0, [x22, #336]
    5414:	17ffffe1 	b	5398 <fwp_data.part.0.constprop.0+0xf8>
    5418:	97fff756 	bl	3170 <fwp_heap_oom>
    541c:	d503201f 	nop

0000000000005420 <fwp_tape_reserve>:
    5420:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5424:	910003fd 	mov	x29, sp
    5428:	a90153f3 	stp	x19, x20, [sp, #16]
    542c:	aa0003f3 	mov	x19, x0
    5430:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5434:	eb00003f 	cmp	x1, x0
    5438:	54000888 	b.hi	5548 <fwp_tape_reserve+0x128>  // b.pmore
    543c:	f9400e74 	ldr	x20, [x19, #24]
    5440:	eb01029f 	cmp	x20, x1
    5444:	5400078a 	b.ge	5534 <fwp_tape_reserve+0x114>  // b.tcont
    5448:	f100029f 	cmp	x20, #0x0
    544c:	d2800802 	mov	x2, #0x40                  	// #64
    5450:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5454:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    5458:	a9025bf5 	stp	x21, x22, [sp, #32]
    545c:	a90363f7 	stp	x23, x24, [sp, #48]
    5460:	eb01029f 	cmp	x20, x1
    5464:	5400008a 	b.ge	5474 <fwp_tape_reserve+0x54>  // b.tcont
    5468:	eb00029f 	cmp	x20, x0
    546c:	540006ad 	b.le	5540 <fwp_tape_reserve+0x120>
    5470:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5474:	a940d663 	ldp	x3, x21, [x19, #8]
    5478:	d37df297 	lsl	x23, x20, #3
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	aa1703e1 	mov	x1, x23
    5484:	f9403276 	ldr	x22, [x19, #96]
    5488:	52800022 	mov	w2, #0x1                   	// #1
    548c:	cb0302b5 	sub	x21, x21, x3
    5490:	97fffb0d 	bl	40c4 <ad_raw_realloc>
    5494:	b4000aa0 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    5498:	f9400e61 	ldr	x1, [x19, #24]
    549c:	8b010801 	add	x1, x0, x1, lsl #2
    54a0:	a9020660 	stp	x0, x1, [x19, #32]
    54a4:	b4000856 	cbz	x22, 55ac <fwp_tape_reserve+0x18c>
    54a8:	f94032d7 	ldr	x23, [x22, #96]
    54ac:	eb17029f 	cmp	x20, x23
    54b0:	5400034d 	b.le	5518 <fwp_tape_reserve+0xf8>
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	d37cee9a 	lsl	x26, x20, #4
    54bc:	aa1a03e0 	mov	x0, x26
    54c0:	f94022d9 	ldr	x25, [x22, #64]
    54c4:	52800041 	mov	w1, #0x2                   	// #2
    54c8:	97ffff12 	bl	5110 <fwp_heap_alloc>
    54cc:	aa0003f8 	mov	x24, x0
    54d0:	b4000119 	cbz	x25, 54f0 <fwp_tape_reserve+0xd0>
    54d4:	d37ceef7 	lsl	x23, x23, #4
    54d8:	aa1903e1 	mov	x1, x25
    54dc:	eb1a02ff 	cmp	x23, x26
    54e0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    54e4:	97fff483 	bl	26f0 <memcpy@plt>
    54e8:	aa1903e0 	mov	x0, x25
    54ec:	97fffc4d 	bl	4620 <fwp_mem_free>
    54f0:	f94032c0 	ldr	x0, [x22, #96]
    54f4:	52800001 	mov	w1, #0x0                   	// #0
    54f8:	cb000282 	sub	x2, x20, x0
    54fc:	8b001300 	add	x0, x24, x0, lsl #4
    5500:	d37cec42 	lsl	x2, x2, #4
    5504:	97fff4db 	bl	2870 <memset@plt>
    5508:	f9401260 	ldr	x0, [x19, #32]
    550c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5510:	f90022d8 	str	x24, [x22, #64]
    5514:	f90032d4 	str	x20, [x22, #96]
    5518:	d37ef696 	lsl	x22, x20, #2
    551c:	b5000315 	cbnz	x21, 557c <fwp_tape_reserve+0x15c>
    5520:	a94363f7 	ldp	x23, x24, [sp, #48]
    5524:	8b160000 	add	x0, x0, x22
    5528:	a9425bf5 	ldp	x21, x22, [sp, #32]
    552c:	f9000e74 	str	x20, [x19, #24]
    5530:	f9001660 	str	x0, [x19, #40]
    5534:	a94153f3 	ldp	x19, x20, [sp, #16]
    5538:	a8c57bfd 	ldp	x29, x30, [sp], #80
    553c:	d65f03c0 	ret
    5540:	d37ffa94 	lsl	x20, x20, #1
    5544:	17ffffc7 	b	5460 <fwp_tape_reserve+0x40>
    5548:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    554c:	911fa000 	add	x0, x0, #0x7e8
    5550:	a9025bf5 	stp	x21, x22, [sp, #32]
    5554:	a90363f7 	stp	x23, x24, [sp, #48]
    5558:	a9046bf9 	stp	x25, x26, [sp, #64]
    555c:	97fffb76 	bl	4334 <fwp_trap>
    5560:	aa0303e0 	mov	x0, x3
    5564:	d37df2a2 	lsl	x2, x21, #3
    5568:	97fff46a 	bl	2710 <memmove@plt>
    556c:	f9401a61 	ldr	x1, [x19, #48]
    5570:	f9401260 	ldr	x0, [x19, #32]
    5574:	8b170021 	add	x1, x1, x23
    5578:	f9001e61 	str	x1, [x19, #56]
    557c:	f9401661 	ldr	x1, [x19, #40]
    5580:	d37ef696 	lsl	x22, x20, #2
    5584:	d37ef6a2 	lsl	x2, x21, #2
    5588:	8b160000 	add	x0, x0, x22
    558c:	97fff461 	bl	2710 <memmove@plt>
    5590:	f9401260 	ldr	x0, [x19, #32]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	8b160000 	add	x0, x0, x22
    559c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55a0:	f9000e74 	str	x20, [x19, #24]
    55a4:	f9001660 	str	x0, [x19, #40]
    55a8:	17ffffe3 	b	5534 <fwp_tape_reserve+0x114>
    55ac:	f9401a60 	ldr	x0, [x19, #48]
    55b0:	d37cee81 	lsl	x1, x20, #4
    55b4:	52800042 	mov	w2, #0x2                   	// #2
    55b8:	97fffac3 	bl	40c4 <ad_raw_realloc>
    55bc:	b4000160 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    55c0:	f9400e62 	ldr	x2, [x19, #24]
    55c4:	f9001a60 	str	x0, [x19, #48]
    55c8:	8b170003 	add	x3, x0, x23
    55cc:	8b020c01 	add	x1, x0, x2, lsl #3
    55d0:	f9001e61 	str	x1, [x19, #56]
    55d4:	b5fffc75 	cbnz	x21, 5560 <fwp_tape_reserve+0x140>
    55d8:	f9401260 	ldr	x0, [x19, #32]
    55dc:	d37ef696 	lsl	x22, x20, #2
    55e0:	f9001e63 	str	x3, [x19, #56]
    55e4:	17ffffcf 	b	5520 <fwp_tape_reserve+0x100>
    55e8:	aa1303e0 	mov	x0, x19
    55ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    55f0:	97fff689 	bl	3014 <fwp_tape_unlink_scope>
    55f4:	f9401260 	ldr	x0, [x19, #32]
    55f8:	b4000040 	cbz	x0, 5600 <fwp_tape_reserve+0x1e0>
    55fc:	97fffa7d 	bl	3ff0 <ad_raw_free.part.0>
    5600:	f9401a60 	ldr	x0, [x19, #48]
    5604:	b4000040 	cbz	x0, 560c <fwp_tape_reserve+0x1ec>
    5608:	97fffa7a 	bl	3ff0 <ad_raw_free.part.0>
    560c:	f9402260 	ldr	x0, [x19, #64]
    5610:	b4000040 	cbz	x0, 5618 <fwp_tape_reserve+0x1f8>
    5614:	97fffa77 	bl	3ff0 <ad_raw_free.part.0>
    5618:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    561c:	f947e821 	ldr	x1, [x1, #4048]
    5620:	f9000e7f 	str	xzr, [x19, #24]
    5624:	4f000400 	movi	v0.4s, #0x0
    5628:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    562c:	d2800262 	mov	x2, #0x13                  	// #19
    5630:	f9400023 	ldr	x3, [x1]
    5634:	b900067f 	str	wzr, [x19, #4]
    5638:	d2800021 	mov	x1, #0x1                   	// #1
    563c:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5640:	910ba000 	add	x0, x0, #0x2e8
    5644:	3c808260 	stur	q0, [x19, #8]
    5648:	ad010260 	stp	q0, q0, [x19, #32]
    564c:	97fff4d5 	bl	29a0 <fwrite@plt>
    5650:	d2800000 	mov	x0, #0x0                   	// #0
    5654:	97fff4df 	bl	29d0 <fflush@plt>
    5658:	52800cc0 	mov	w0, #0x66                  	// #102
    565c:	97fff4ed 	bl	2a10 <_Exit@plt>

0000000000005660 <f141.constprop.0>:
    5660:	f100001f 	cmp	x0, #0x0
    5664:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5668:	5400094b 	b.lt	5790 <f141.constprop.0+0x130>  // b.tstop
    566c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5670:	aa0003e2 	mov	x2, x0
    5674:	910003fd 	mov	x29, sp
    5678:	a90153f3 	stp	x19, x20, [sp, #16]
    567c:	aa0003f4 	mov	x20, x0
    5680:	aa010000 	orr	x0, x0, x1
    5684:	a9025bf5 	stp	x21, x22, [sp, #32]
    5688:	aa0103f6 	mov	x22, x1
    568c:	f9001bf7 	str	x23, [sp, #48]
    5690:	fd001fe8 	str	d8, [sp, #56]
    5694:	b7f80180 	tbnz	x0, #63, 56c4 <f141.constprop.0+0x64>
    5698:	9360fc20 	asr	x0, x1, #32
    569c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56a0:	eb82801f 	cmp	x0, x2, asr #32
    56a4:	540007a1 	b.ne	5798 <f141.constprop.0+0x138>  // b.any
    56a8:	97fffd26 	bl	4b40 <fwp_tape_of>
    56ac:	aa0003f3 	mov	x19, x0
    56b0:	f9403000 	ldr	x0, [x0, #96]
    56b4:	b40001e0 	cbz	x0, 56f0 <f141.constprop.0+0x90>
    56b8:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    56bc:	91214000 	add	x0, x0, #0x850
    56c0:	97fffb1d 	bl	4334 <fwp_trap>
    56c4:	9360fc40 	asr	x0, x2, #32
    56c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56cc:	b6fffee2 	tbz	x2, #63, 56a8 <f141.constprop.0+0x48>
    56d0:	2f00e408 	movi	d8, #0x0
    56d4:	9360fc20 	asr	x0, x1, #32
    56d8:	aa0103f4 	mov	x20, x1
    56dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    56e0:	97fffd18 	bl	4b40 <fwp_tape_of>
    56e4:	aa0003f3 	mov	x19, x0
    56e8:	f9403000 	ldr	x0, [x0, #96]
    56ec:	b5fffe60 	cbnz	x0, 56b8 <f141.constprop.0+0x58>
    56f0:	f9400a77 	ldr	x23, [x19, #16]
    56f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56f8:	eb0002ff 	cmp	x23, x0
    56fc:	5400044c 	b.gt	5784 <f141.constprop.0+0x124>
    5700:	eb3442ff 	cmp	x23, w20, uxtw
    5704:	5400008d 	b.le	5714 <f141.constprop.0+0xb4>
    5708:	b7f800d6 	tbnz	x22, #63, 5720 <f141.constprop.0+0xc0>
    570c:	eb3642ff 	cmp	x23, w22, uxtw
    5710:	5400008c 	b.gt	5720 <f141.constprop.0+0xc0>
    5714:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5718:	91220000 	add	x0, x0, #0x880
    571c:	97fffb06 	bl	4334 <fwp_trap>
    5720:	f9400675 	ldr	x21, [x19, #8]
    5724:	aa1303e0 	mov	x0, x19
    5728:	cb1502f5 	sub	x21, x23, x21
    572c:	910006a1 	add	x1, x21, #0x1
    5730:	97ffff3c 	bl	5420 <fwp_tape_reserve>
    5734:	a9420262 	ldp	x2, x0, [x19, #32]
    5738:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    573c:	f9401a61 	ldr	x1, [x19, #48]
    5740:	b8357854 	str	w20, [x2, x21, lsl #2]
    5744:	f9401e62 	ldr	x2, [x19, #56]
    5748:	f10002df 	cmp	x22, #0x0
    574c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5750:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5754:	b8357816 	str	w22, [x0, x21, lsl #2]
    5758:	92607e80 	and	x0, x20, #0xffffffff00000000
    575c:	910006e1 	add	x1, x23, #0x1
    5760:	aa170000 	orr	x0, x0, x23
    5764:	fc357848 	str	d8, [x2, x21, lsl #3]
    5768:	a9425bf5 	ldp	x21, x22, [sp, #32]
    576c:	f9401bf7 	ldr	x23, [sp, #48]
    5770:	fd401fe8 	ldr	d8, [sp, #56]
    5774:	f9000a61 	str	x1, [x19, #16]
    5778:	a94153f3 	ldp	x19, x20, [sp, #16]
    577c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5780:	d65f03c0 	ret
    5784:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5788:	911fa000 	add	x0, x0, #0x7e8
    578c:	97fffaea 	bl	4334 <fwp_trap>
    5790:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5794:	d65f03c0 	ret
    5798:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    579c:	91202000 	add	x0, x0, #0x808
    57a0:	97fffae5 	bl	4334 <fwp_trap>

00000000000057a4 <w120>:
    57a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    57a8:	910003fd 	mov	x29, sp
    57ac:	a90153f3 	stp	x19, x20, [sp, #16]
    57b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    57b4:	aa0003f5 	mov	x21, x0
    57b8:	a90363f7 	stp	x23, x24, [sp, #48]
    57bc:	aa0103f7 	mov	x23, x1
    57c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    57c4:	f9002bfb 	str	x27, [sp, #80]
    57c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57cc:	1e604028 	fmov	d8, d1
    57d0:	1e600809 	fmul	d9, d0, d0
    57d4:	6d072fea 	stp	d10, d11, [sp, #112]
    57d8:	1e60400b 	fmov	d11, d0
    57dc:	b7f81c80 	tbnz	x0, #63, 5b6c <w120+0x3c8>
    57e0:	9360fc19 	asr	x25, x0, #32
    57e4:	aa1903e0 	mov	x0, x25
    57e8:	97fffcd6 	bl	4b40 <fwp_tape_of>
    57ec:	f9403001 	ldr	x1, [x0, #96]
    57f0:	aa0003f3 	mov	x19, x0
    57f4:	b4000081 	cbz	x1, 5804 <w120+0x60>
    57f8:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    57fc:	91214000 	add	x0, x0, #0x850
    5800:	97fffacd 	bl	4334 <fwp_trap>
    5804:	f9400818 	ldr	x24, [x0, #16]
    5808:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    580c:	eb01031f 	cmp	x24, x1
    5810:	54001a8c 	b.gt	5b60 <w120+0x3bc>
    5814:	eb35431f 	cmp	x24, w21, uxtw
    5818:	540019ed 	b.le	5b54 <w120+0x3b0>
    581c:	f9400416 	ldr	x22, [x0, #8]
    5820:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5824:	aa180294 	orr	x20, x20, x24
    5828:	cb160316 	sub	x22, x24, x22
    582c:	910006c1 	add	x1, x22, #0x1
    5830:	97fffefc 	bl	5420 <fwp_tape_reserve>
    5834:	a9420a61 	ldp	x1, x2, [x19, #32]
    5838:	91000700 	add	x0, x24, #0x1
    583c:	f9401a63 	ldr	x3, [x19, #48]
    5840:	b8367835 	str	w21, [x1, x22, lsl #2]
    5844:	f9401e61 	ldr	x1, [x19, #56]
    5848:	1e693908 	fsub	d8, d8, d9
    584c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5850:	9360fe9a 	asr	x26, x20, #32
    5854:	b8367855 	str	w21, [x2, x22, lsl #2]
    5858:	fc36782b 	str	d11, [x1, x22, lsl #3]
    585c:	f9000a60 	str	x0, [x19, #16]
    5860:	b7f80077 	tbnz	x23, #63, 586c <w120+0xc8>
    5864:	eb97835f 	cmp	x26, x23, asr #32
    5868:	540019a1 	b.ne	5b9c <w120+0x3f8>  // b.any
    586c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5870:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5874:	eb19035f 	cmp	x26, x25
    5878:	540000c0 	b.eq	5890 <w120+0xec>  // b.none
    587c:	aa1a03e0 	mov	x0, x26
    5880:	97fffcb0 	bl	4b40 <fwp_tape_of>
    5884:	aa0003f3 	mov	x19, x0
    5888:	f9403000 	ldr	x0, [x0, #96]
    588c:	b5fffb60 	cbnz	x0, 57f8 <w120+0x54>
    5890:	f9400a79 	ldr	x25, [x19, #16]
    5894:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5898:	eb00033f 	cmp	x25, x0
    589c:	5400162c 	b.gt	5b60 <w120+0x3bc>
    58a0:	eb34433f 	cmp	x25, w20, uxtw
    58a4:	5400158d 	b.le	5b54 <w120+0x3b0>
    58a8:	b7f80077 	tbnz	x23, #63, 58b4 <w120+0x110>
    58ac:	eb37433f 	cmp	x25, w23, uxtw
    58b0:	5400152d 	b.le	5b54 <w120+0x3b0>
    58b4:	f9400676 	ldr	x22, [x19, #8]
    58b8:	aa1303e0 	mov	x0, x19
    58bc:	cb160336 	sub	x22, x25, x22
    58c0:	910006c1 	add	x1, x22, #0x1
    58c4:	97fffed7 	bl	5420 <fwp_tape_reserve>
    58c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    58cc:	f10002ff 	cmp	x23, #0x0
    58d0:	f9401a61 	ldr	x1, [x19, #48]
    58d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    58d8:	f9401e62 	ldr	x2, [x19, #56]
    58dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    58e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    58e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    58e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    58ec:	91000737 	add	x23, x25, #0x1
    58f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    58f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    58fc:	aa190294 	orr	x20, x20, x25
    5900:	f9000a77 	str	x23, [x19, #16]
    5904:	1e6b3929 	fsub	d9, d9, d11
    5908:	b7f81675 	tbnz	x21, #63, 5bd4 <w120+0x430>
    590c:	9360febb 	asr	x27, x21, #32
    5910:	eb1a037f 	cmp	x27, x26
    5914:	540000e0 	b.eq	5930 <w120+0x18c>  // b.none
    5918:	aa1b03e0 	mov	x0, x27
    591c:	97fffc89 	bl	4b40 <fwp_tape_of>
    5920:	aa0003f3 	mov	x19, x0
    5924:	f9403000 	ldr	x0, [x0, #96]
    5928:	b5fff680 	cbnz	x0, 57f8 <w120+0x54>
    592c:	f9400a77 	ldr	x23, [x19, #16]
    5930:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5934:	eb0002ff 	cmp	x23, x0
    5938:	5400114c 	b.gt	5b60 <w120+0x3bc>
    593c:	eb3542ff 	cmp	x23, w21, uxtw
    5940:	540010ad 	b.le	5b54 <w120+0x3b0>
    5944:	f9400676 	ldr	x22, [x19, #8]
    5948:	aa1303e0 	mov	x0, x19
    594c:	cb1602f6 	sub	x22, x23, x22
    5950:	910006c1 	add	x1, x22, #0x1
    5954:	97fffeb3 	bl	5420 <fwp_tape_reserve>
    5958:	a9420261 	ldp	x1, x0, [x19, #32]
    595c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5960:	f9401a63 	ldr	x3, [x19, #48]
    5964:	b8367835 	str	w21, [x1, x22, lsl #2]
    5968:	f9401e61 	ldr	x1, [x19, #56]
    596c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5970:	fc367860 	str	d0, [x3, x22, lsl #3]
    5974:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5978:	b8367802 	str	w2, [x0, x22, lsl #2]
    597c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5980:	910006e0 	add	x0, x23, #0x1
    5984:	aa1702b7 	orr	x23, x21, x23
    5988:	fc367820 	str	d0, [x1, x22, lsl #3]
    598c:	f9000a60 	str	x0, [x19, #16]
    5990:	9360fe99 	asr	x25, x20, #32
    5994:	1e68090a 	fmul	d10, d8, d8
    5998:	eb1b033f 	cmp	x25, x27
    599c:	540000c0 	b.eq	59b4 <w120+0x210>  // b.none
    59a0:	aa1903e0 	mov	x0, x25
    59a4:	97fffc67 	bl	4b40 <fwp_tape_of>
    59a8:	aa0003f3 	mov	x19, x0
    59ac:	f9403000 	ldr	x0, [x0, #96]
    59b0:	b5fff240 	cbnz	x0, 57f8 <w120+0x54>
    59b4:	f9400a75 	ldr	x21, [x19, #16]
    59b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59bc:	eb0002bf 	cmp	x21, x0
    59c0:	54000d0c 	b.gt	5b60 <w120+0x3bc>
    59c4:	eb3442bf 	cmp	x21, w20, uxtw
    59c8:	54000c6d 	b.le	5b54 <w120+0x3b0>
    59cc:	f9400678 	ldr	x24, [x19, #8]
    59d0:	aa1303e0 	mov	x0, x19
    59d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    59d8:	cb1802b8 	sub	x24, x21, x24
    59dc:	aa1502d6 	orr	x22, x22, x21
    59e0:	91000701 	add	x1, x24, #0x1
    59e4:	97fffe8f 	bl	5420 <fwp_tape_reserve>
    59e8:	a9420261 	ldp	x1, x0, [x19, #32]
    59ec:	f9401a62 	ldr	x2, [x19, #48]
    59f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    59f4:	f9401e61 	ldr	x1, [x19, #56]
    59f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    59fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5a00:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a04:	9e670000 	fmov	d0, x0
    5a08:	910006b4 	add	x20, x21, #0x1
    5a0c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5a10:	9360fed8 	asr	x24, x22, #32
    5a14:	f9000a74 	str	x20, [x19, #16]
    5a18:	1e60094a 	fmul	d10, d10, d0
    5a1c:	eb19031f 	cmp	x24, x25
    5a20:	540000e0 	b.eq	5a3c <w120+0x298>  // b.none
    5a24:	aa1803e0 	mov	x0, x24
    5a28:	97fffc46 	bl	4b40 <fwp_tape_of>
    5a2c:	aa0003f3 	mov	x19, x0
    5a30:	f9403000 	ldr	x0, [x0, #96]
    5a34:	b5ffee20 	cbnz	x0, 57f8 <w120+0x54>
    5a38:	f9400a74 	ldr	x20, [x19, #16]
    5a3c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a40:	eb00029f 	cmp	x20, x0
    5a44:	540008ec 	b.gt	5b60 <w120+0x3bc>
    5a48:	eb36429f 	cmp	x20, w22, uxtw
    5a4c:	5400084d 	b.le	5b54 <w120+0x3b0>
    5a50:	f9400675 	ldr	x21, [x19, #8]
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	cb150295 	sub	x21, x20, x21
    5a5c:	910006a1 	add	x1, x21, #0x1
    5a60:	97fffe70 	bl	5420 <fwp_tape_reserve>
    5a64:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a68:	9e670000 	fmov	d0, x0
    5a6c:	a9420261 	ldp	x1, x0, [x19, #32]
    5a70:	1e690928 	fmul	d8, d9, d9
    5a74:	f9401a62 	ldr	x2, [x19, #48]
    5a78:	b8357836 	str	w22, [x1, x21, lsl #2]
    5a7c:	f9401e61 	ldr	x1, [x19, #56]
    5a80:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5a84:	fc357840 	str	d0, [x2, x21, lsl #3]
    5a88:	12800002 	mov	w2, #0xffffffff            	// #-1
    5a8c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5a90:	91000680 	add	x0, x20, #0x1
    5a94:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5a98:	aa1402d6 	orr	x22, x22, x20
    5a9c:	f9000a60 	str	x0, [x19, #16]
    5aa0:	b10006ff 	cmn	x23, #0x1
    5aa4:	540009e0 	b.eq	5be0 <w120+0x43c>  // b.none
    5aa8:	9360fee0 	asr	x0, x23, #32
    5aac:	eb18001f 	cmp	x0, x24
    5ab0:	540000a0 	b.eq	5ac4 <w120+0x320>  // b.none
    5ab4:	97fffc23 	bl	4b40 <fwp_tape_of>
    5ab8:	aa0003f3 	mov	x19, x0
    5abc:	f9403000 	ldr	x0, [x0, #96]
    5ac0:	b5ffe9c0 	cbnz	x0, 57f8 <w120+0x54>
    5ac4:	f9400a74 	ldr	x20, [x19, #16]
    5ac8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5acc:	eb00029f 	cmp	x20, x0
    5ad0:	5400048c 	b.gt	5b60 <w120+0x3bc>
    5ad4:	eb37429f 	cmp	x20, w23, uxtw
    5ad8:	540003ed 	b.le	5b54 <w120+0x3b0>
    5adc:	f9400675 	ldr	x21, [x19, #8]
    5ae0:	aa1303e0 	mov	x0, x19
    5ae4:	cb150295 	sub	x21, x20, x21
    5ae8:	910006a1 	add	x1, x21, #0x1
    5aec:	97fffe4d 	bl	5420 <fwp_tape_reserve>
    5af0:	a9420a61 	ldp	x1, x2, [x19, #32]
    5af4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5af8:	f9401a63 	ldr	x3, [x19, #48]
    5afc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5b00:	f9401e61 	ldr	x1, [x19, #56]
    5b04:	aa140000 	orr	x0, x0, x20
    5b08:	fc357869 	str	d9, [x3, x21, lsl #3]
    5b0c:	91000694 	add	x20, x20, #0x1
    5b10:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b14:	fc357829 	str	d9, [x1, x21, lsl #3]
    5b18:	f9000a74 	str	x20, [x19, #16]
    5b1c:	1e6a2908 	fadd	d8, d8, d10
    5b20:	aa1603e1 	mov	x1, x22
    5b24:	97fffecf 	bl	5660 <f141.constprop.0>
    5b28:	aa0003e1 	mov	x1, x0
    5b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b30:	9e660100 	fmov	x0, d8
    5b34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b38:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b3c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5b40:	f9402bfb 	ldr	x27, [sp, #80]
    5b44:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5b48:	6d472fea 	ldp	d10, d11, [sp, #112]
    5b4c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5b50:	d65f03c0 	ret
    5b54:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5b58:	91220000 	add	x0, x0, #0x880
    5b5c:	97fff9f6 	bl	4334 <fwp_trap>
    5b60:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5b64:	911fa000 	add	x0, x0, #0x7e8
    5b68:	97fff9f3 	bl	4334 <fwp_trap>
    5b6c:	1e693828 	fsub	d8, d1, d9
    5b70:	b6f801c1 	tbz	x1, #63, 5ba8 <w120+0x404>
    5b74:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5b78:	1e68090a 	fmul	d10, d8, d8
    5b7c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5b80:	9e670000 	fmov	d0, x0
    5b84:	1e6b3828 	fsub	d8, d1, d11
    5b88:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5b8c:	aa1603e0 	mov	x0, x22
    5b90:	1e60094a 	fmul	d10, d10, d0
    5b94:	1e680908 	fmul	d8, d8, d8
    5b98:	17ffffe1 	b	5b1c <w120+0x378>
    5b9c:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5ba0:	91202000 	add	x0, x0, #0x808
    5ba4:	97fff9e4 	bl	4334 <fwp_trap>
    5ba8:	2f00e40a 	movi	d10, #0x0
    5bac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5bb0:	9360fc3a 	asr	x26, x1, #32
    5bb4:	aa0103f4 	mov	x20, x1
    5bb8:	aa1a03e0 	mov	x0, x26
    5bbc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5bc0:	97fffbe0 	bl	4b40 <fwp_tape_of>
    5bc4:	aa0003f3 	mov	x19, x0
    5bc8:	f9403000 	ldr	x0, [x0, #96]
    5bcc:	b5ffe160 	cbnz	x0, 57f8 <w120+0x54>
    5bd0:	17ffff30 	b	5890 <w120+0xec>
    5bd4:	aa1a03fb 	mov	x27, x26
    5bd8:	aa0003f7 	mov	x23, x0
    5bdc:	17ffff6d 	b	5990 <w120+0x1ec>
    5be0:	aa1703e0 	mov	x0, x23
    5be4:	17ffffce 	b	5b1c <w120+0x378>
    5be8:	d503201f 	nop
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_rc_share>:
    5bf0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5bf4:	9118c042 	add	x2, x2, #0x630
    5bf8:	f949d843 	ldr	x3, [x2, #5040]
    5bfc:	f949ec41 	ldr	x1, [x2, #5080]
    5c00:	cb030000 	sub	x0, x0, x3
    5c04:	eb01401f 	cmp	x0, x1, lsl #16
    5c08:	540003a2 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c0c:	d350fc01 	lsr	x1, x0, #16
    5c10:	f949fc44 	ldr	x4, [x2, #5112]
    5c14:	8b010821 	add	x1, x1, x1, lsl #2
    5c18:	d37df021 	lsl	x1, x1, #3
    5c1c:	8b010083 	add	x3, x4, x1
    5c20:	f9401062 	ldr	x2, [x3, #32]
    5c24:	b40002c2 	cbz	x2, 5c7c <fwp_rc_share+0x8c>
    5c28:	38616881 	ldrb	w1, [x4, x1]
    5c2c:	7100083f 	cmp	w1, #0x2
    5c30:	54000220 	b.eq	5c74 <fwp_rc_share+0x84>  // b.none
    5c34:	7100043f 	cmp	w1, #0x1
    5c38:	54000221 	b.ne	5c7c <fwp_rc_share+0x8c>  // b.any
    5c3c:	29430464 	ldp	w4, w1, [x3, #24]
    5c40:	92403c00 	and	x0, x0, #0xffff
    5c44:	9b047c00 	mul	x0, x0, x4
    5c48:	d360fc00 	lsr	x0, x0, #32
    5c4c:	eb01001f 	cmp	x0, x1
    5c50:	54000162 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c54:	8b000042 	add	x2, x2, x0
    5c58:	39400040 	ldrb	w0, [x2]
    5c5c:	34000100 	cbz	w0, 5c7c <fwp_rc_share+0x8c>
    5c60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5c64:	d0000020 	adrp	x0, b000 <__modti3+0xc0>
    5c68:	91228000 	add	x0, x0, #0x8a0
    5c6c:	910003fd 	mov	x29, sp
    5c70:	97fff9b1 	bl	4334 <fwp_trap>
    5c74:	72003c1f 	tst	w0, #0xffff
    5c78:	54ffff00 	b.eq	5c58 <fwp_rc_share+0x68>  // b.none
    5c7c:	d65f03c0 	ret

0000000000005c80 <fwp_rc_free_arr>:
    5c80:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5c84:	9118c063 	add	x3, x3, #0x630
    5c88:	f949d861 	ldr	x1, [x3, #5040]
    5c8c:	f949ec62 	ldr	x2, [x3, #5080]
    5c90:	cb010001 	sub	x1, x0, x1
    5c94:	eb02403f 	cmp	x1, x2, lsl #16
    5c98:	54000342 	b.cs	5d00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c9c:	d350fc22 	lsr	x2, x1, #16
    5ca0:	f949fc65 	ldr	x5, [x3, #5112]
    5ca4:	8b020842 	add	x2, x2, x2, lsl #2
    5ca8:	d37df042 	lsl	x2, x2, #3
    5cac:	8b0200a4 	add	x4, x5, x2
    5cb0:	f9401083 	ldr	x3, [x4, #32]
    5cb4:	b4000263 	cbz	x3, 5d00 <fwp_rc_free_arr+0x80>
    5cb8:	386268a2 	ldrb	w2, [x5, x2]
    5cbc:	7100085f 	cmp	w2, #0x2
    5cc0:	540001c0 	b.eq	5cf8 <fwp_rc_free_arr+0x78>  // b.none
    5cc4:	7100045f 	cmp	w2, #0x1
    5cc8:	540001c1 	b.ne	5d00 <fwp_rc_free_arr+0x80>  // b.any
    5ccc:	29430885 	ldp	w5, w2, [x4, #24]
    5cd0:	92403c21 	and	x1, x1, #0xffff
    5cd4:	9b057c21 	mul	x1, x1, x5
    5cd8:	d360fc21 	lsr	x1, x1, #32
    5cdc:	eb02003f 	cmp	x1, x2
    5ce0:	54000102 	b.cs	5d00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5ce4:	8b010063 	add	x3, x3, x1
    5ce8:	39400061 	ldrb	w1, [x3]
    5cec:	7100043f 	cmp	w1, #0x1
    5cf0:	54000081 	b.ne	5d00 <fwp_rc_free_arr+0x80>  // b.any
    5cf4:	17fffa4b 	b	4620 <fwp_mem_free>
    5cf8:	72003c3f 	tst	w1, #0xffff
    5cfc:	54ffff60 	b.eq	5ce8 <fwp_rc_free_arr+0x68>  // b.none
    5d00:	d65f03c0 	ret

0000000000005d04 <fwp_rc_dup>:
    5d04:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5d08:	9118c042 	add	x2, x2, #0x630
    5d0c:	f949d841 	ldr	x1, [x2, #5040]
    5d10:	f949ec43 	ldr	x3, [x2, #5080]
    5d14:	cb010001 	sub	x1, x0, x1
    5d18:	eb03403f 	cmp	x1, x3, lsl #16
    5d1c:	540003c2 	b.cs	5d94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d20:	d350fc20 	lsr	x0, x1, #16
    5d24:	f949fc44 	ldr	x4, [x2, #5112]
    5d28:	8b000800 	add	x0, x0, x0, lsl #2
    5d2c:	d37df002 	lsl	x2, x0, #3
    5d30:	8b020083 	add	x3, x4, x2
    5d34:	f9401060 	ldr	x0, [x3, #32]
    5d38:	b40002e0 	cbz	x0, 5d94 <fwp_rc_dup+0x90>
    5d3c:	38626882 	ldrb	w2, [x4, x2]
    5d40:	7100085f 	cmp	w2, #0x2
    5d44:	540002a0 	b.eq	5d98 <fwp_rc_dup+0x94>  // b.none
    5d48:	7100045f 	cmp	w2, #0x1
    5d4c:	54000241 	b.ne	5d94 <fwp_rc_dup+0x90>  // b.any
    5d50:	29430864 	ldp	w4, w2, [x3, #24]
    5d54:	92403c21 	and	x1, x1, #0xffff
    5d58:	9b047c21 	mul	x1, x1, x4
    5d5c:	d360fc21 	lsr	x1, x1, #32
    5d60:	eb02003f 	cmp	x1, x2
    5d64:	54000182 	b.cs	5d94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d68:	8b010000 	add	x0, x0, x1
    5d6c:	39400001 	ldrb	w1, [x0]
    5d70:	34000121 	cbz	w1, 5d94 <fwp_rc_dup+0x90>
    5d74:	f00000c2 	adrp	x2, 20000 <__data_start>
    5d78:	91014042 	add	x2, x2, #0x50
    5d7c:	b9413043 	ldr	w3, [x2, #304]
    5d80:	35000123 	cbnz	w3, 5da4 <fwp_rc_dup+0xa0>
    5d84:	7103f43f 	cmp	w1, #0xfd
    5d88:	54000168 	b.hi	5db4 <fwp_rc_dup+0xb0>  // b.pmore
    5d8c:	11000421 	add	w1, w1, #0x1
    5d90:	39000001 	strb	w1, [x0]
    5d94:	d65f03c0 	ret
    5d98:	72003c3f 	tst	w1, #0xffff
    5d9c:	54fffe80 	b.eq	5d6c <fwp_rc_dup+0x68>  // b.none
    5da0:	d65f03c0 	ret
    5da4:	f940ac43 	ldr	x3, [x2, #344]
    5da8:	91000463 	add	x3, x3, #0x1
    5dac:	f900ac43 	str	x3, [x2, #344]
    5db0:	17fffff5 	b	5d84 <fwp_rc_dup+0x80>
    5db4:	17fffa94 	b	4804 <fwp_rc_wide_dup>
    5db8:	d503201f 	nop
    5dbc:	d503201f 	nop

0000000000005dc0 <fwp_owned_entry173>:
    5dc0:	d10103ff 	sub	sp, sp, #0x40
    5dc4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5dc8:	f947f442 	ldr	x2, [x2, #4072]
    5dcc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5dd0:	910083fd 	add	x29, sp, #0x20
    5dd4:	a90353f3 	stp	x19, x20, [sp, #48]
    5dd8:	f9400043 	ldr	x3, [x2]
    5ddc:	f9000fe3 	str	x3, [sp, #24]
    5de0:	d2800003 	mov	x3, #0x0                   	// #0
    5de4:	a9400c01 	ldp	x1, x3, [x0]
    5de8:	f9400802 	ldr	x2, [x0, #16]
    5dec:	ab020022 	adds	x2, x1, x2
    5df0:	540006e6 	b.vs	5ecc <fwp_owned_entry173+0x10c>
    5df4:	910023e1 	add	x1, sp, #0x8
    5df8:	52800000 	mov	w0, #0x0                   	// #0
    5dfc:	a9008be3 	stp	x3, x2, [sp, #8]
    5e00:	97fffd28 	bl	52a0 <fwp_data.part.0.constprop.0>
    5e04:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5e08:	9118c063 	add	x3, x3, #0x630
    5e0c:	aa0003f3 	mov	x19, x0
    5e10:	f949d861 	ldr	x1, [x3, #5040]
    5e14:	f949ec60 	ldr	x0, [x3, #5080]
    5e18:	cb010261 	sub	x1, x19, x1
    5e1c:	eb00403f 	cmp	x1, x0, lsl #16
    5e20:	54000322 	b.cs	5e84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5e24:	d350fc22 	lsr	x2, x1, #16
    5e28:	f949fc63 	ldr	x3, [x3, #5112]
    5e2c:	8b020842 	add	x2, x2, x2, lsl #2
    5e30:	d37df042 	lsl	x2, x2, #3
    5e34:	8b020060 	add	x0, x3, x2
    5e38:	f9401014 	ldr	x20, [x0, #32]
    5e3c:	b4000254 	cbz	x20, 5e84 <fwp_owned_entry173+0xc4>
    5e40:	38626862 	ldrb	w2, [x3, x2]
    5e44:	7100085f 	cmp	w2, #0x2
    5e48:	54000360 	b.eq	5eb4 <fwp_owned_entry173+0xf4>  // b.none
    5e4c:	7100045f 	cmp	w2, #0x1
    5e50:	540001a1 	b.ne	5e84 <fwp_owned_entry173+0xc4>  // b.any
    5e54:	29430002 	ldp	w2, w0, [x0, #24]
    5e58:	92403c21 	and	x1, x1, #0xffff
    5e5c:	9b027c21 	mul	x1, x1, x2
    5e60:	d360fc21 	lsr	x1, x1, #32
    5e64:	eb00003f 	cmp	x1, x0
    5e68:	540000e2 	b.cs	5e84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5e6c:	8b010294 	add	x20, x20, x1
    5e70:	39400280 	ldrb	w0, [x20]
    5e74:	7103fc1f 	cmp	w0, #0xff
    5e78:	54000240 	b.eq	5ec0 <fwp_owned_entry173+0x100>  // b.none
    5e7c:	52800020 	mov	w0, #0x1                   	// #1
    5e80:	39000280 	strb	w0, [x20]
    5e84:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5e88:	f947f400 	ldr	x0, [x0, #4072]
    5e8c:	f9400fe2 	ldr	x2, [sp, #24]
    5e90:	f9400001 	ldr	x1, [x0]
    5e94:	eb010042 	subs	x2, x2, x1
    5e98:	d2800001 	mov	x1, #0x0                   	// #0
    5e9c:	540001a1 	b.ne	5ed0 <fwp_owned_entry173+0x110>  // b.any
    5ea0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ea4:	aa1303e0 	mov	x0, x19
    5ea8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5eac:	910103ff 	add	sp, sp, #0x40
    5eb0:	d65f03c0 	ret
    5eb4:	72003c3f 	tst	w1, #0xffff
    5eb8:	54fffe61 	b.ne	5e84 <fwp_owned_entry173+0xc4>  // b.any
    5ebc:	17ffffed 	b	5e70 <fwp_owned_entry173+0xb0>
    5ec0:	aa1403e0 	mov	x0, x20
    5ec4:	97fff93c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5ec8:	17ffffed 	b	5e7c <fwp_owned_entry173+0xbc>
    5ecc:	97fff2ed 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ed0:	97fff274 	bl	28a0 <__stack_chk_fail@plt>

0000000000005ed4 <e173>:
    5ed4:	d10103ff 	sub	sp, sp, #0x40
    5ed8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5edc:	f947f442 	ldr	x2, [x2, #4072]
    5ee0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ee4:	910083fd 	add	x29, sp, #0x20
    5ee8:	a90353f3 	stp	x19, x20, [sp, #48]
    5eec:	f9400043 	ldr	x3, [x2]
    5ef0:	f9000fe3 	str	x3, [sp, #24]
    5ef4:	d2800003 	mov	x3, #0x0                   	// #0
    5ef8:	a9400c01 	ldp	x1, x3, [x0]
    5efc:	f9400802 	ldr	x2, [x0, #16]
    5f00:	ab020022 	adds	x2, x1, x2
    5f04:	54000726 	b.vs	5fe8 <e173+0x114>
    5f08:	910023e1 	add	x1, sp, #0x8
    5f0c:	52800000 	mov	w0, #0x0                   	// #0
    5f10:	a9008be3 	stp	x3, x2, [sp, #8]
    5f14:	97fffce3 	bl	52a0 <fwp_data.part.0.constprop.0>
    5f18:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5f1c:	9118c063 	add	x3, x3, #0x630
    5f20:	aa0003f3 	mov	x19, x0
    5f24:	f949d861 	ldr	x1, [x3, #5040]
    5f28:	f949ec60 	ldr	x0, [x3, #5080]
    5f2c:	cb010261 	sub	x1, x19, x1
    5f30:	eb00403f 	cmp	x1, x0, lsl #16
    5f34:	54000322 	b.cs	5f98 <e173+0xc4>  // b.hs, b.nlast
    5f38:	d350fc22 	lsr	x2, x1, #16
    5f3c:	f949fc63 	ldr	x3, [x3, #5112]
    5f40:	8b020842 	add	x2, x2, x2, lsl #2
    5f44:	d37df042 	lsl	x2, x2, #3
    5f48:	8b020060 	add	x0, x3, x2
    5f4c:	f9401014 	ldr	x20, [x0, #32]
    5f50:	b4000254 	cbz	x20, 5f98 <e173+0xc4>
    5f54:	38626862 	ldrb	w2, [x3, x2]
    5f58:	7100085f 	cmp	w2, #0x2
    5f5c:	540003a0 	b.eq	5fd0 <e173+0xfc>  // b.none
    5f60:	7100045f 	cmp	w2, #0x1
    5f64:	540001a1 	b.ne	5f98 <e173+0xc4>  // b.any
    5f68:	29430002 	ldp	w2, w0, [x0, #24]
    5f6c:	92403c21 	and	x1, x1, #0xffff
    5f70:	9b027c21 	mul	x1, x1, x2
    5f74:	d360fc21 	lsr	x1, x1, #32
    5f78:	eb00003f 	cmp	x1, x0
    5f7c:	540000e2 	b.cs	5f98 <e173+0xc4>  // b.hs, b.nlast
    5f80:	8b010294 	add	x20, x20, x1
    5f84:	39400280 	ldrb	w0, [x20]
    5f88:	7103fc1f 	cmp	w0, #0xff
    5f8c:	54000280 	b.eq	5fdc <e173+0x108>  // b.none
    5f90:	52800020 	mov	w0, #0x1                   	// #1
    5f94:	39000280 	strb	w0, [x20]
    5f98:	aa1303e0 	mov	x0, x19
    5f9c:	97ffff15 	bl	5bf0 <fwp_rc_share>
    5fa0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5fa4:	f947f400 	ldr	x0, [x0, #4072]
    5fa8:	f9400fe2 	ldr	x2, [sp, #24]
    5fac:	f9400001 	ldr	x1, [x0]
    5fb0:	eb010042 	subs	x2, x2, x1
    5fb4:	d2800001 	mov	x1, #0x0                   	// #0
    5fb8:	540001a1 	b.ne	5fec <e173+0x118>  // b.any
    5fbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5fc8:	910103ff 	add	sp, sp, #0x40
    5fcc:	d65f03c0 	ret
    5fd0:	72003c3f 	tst	w1, #0xffff
    5fd4:	54fffe21 	b.ne	5f98 <e173+0xc4>  // b.any
    5fd8:	17ffffeb 	b	5f84 <e173+0xb0>
    5fdc:	aa1403e0 	mov	x0, x20
    5fe0:	97fff8f5 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5fe4:	17ffffeb 	b	5f90 <e173+0xbc>
    5fe8:	97fff2a6 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5fec:	97fff22d 	bl	28a0 <__stack_chk_fail@plt>

0000000000005ff0 <fwp_drop1>:
    5ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ff4:	910003fd 	mov	x29, sp
    5ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ffc:	f90013f5 	str	x21, [sp, #32]
    6000:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    6004:	9118c2b4 	add	x20, x21, #0x630
    6008:	f949da81 	ldr	x1, [x20, #5040]
    600c:	f949ee82 	ldr	x2, [x20, #5080]
    6010:	cb010001 	sub	x1, x0, x1
    6014:	eb02403f 	cmp	x1, x2, lsl #16
    6018:	54000382 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    601c:	d350fc22 	lsr	x2, x1, #16
    6020:	f949fe84 	ldr	x4, [x20, #5112]
    6024:	8b020842 	add	x2, x2, x2, lsl #2
    6028:	d37df042 	lsl	x2, x2, #3
    602c:	8b020083 	add	x3, x4, x2
    6030:	f9401073 	ldr	x19, [x3, #32]
    6034:	b40002b3 	cbz	x19, 6088 <fwp_drop1+0x98>
    6038:	38626882 	ldrb	w2, [x4, x2]
    603c:	7100085f 	cmp	w2, #0x2
    6040:	540002c0 	b.eq	6098 <fwp_drop1+0xa8>  // b.none
    6044:	7100045f 	cmp	w2, #0x1
    6048:	54000201 	b.ne	6088 <fwp_drop1+0x98>  // b.any
    604c:	29430864 	ldp	w4, w2, [x3, #24]
    6050:	92403c21 	and	x1, x1, #0xffff
    6054:	9b047c21 	mul	x1, x1, x4
    6058:	d360fc21 	lsr	x1, x1, #32
    605c:	eb02003f 	cmp	x1, x2
    6060:	54000142 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    6064:	8b010273 	add	x19, x19, x1
    6068:	39400261 	ldrb	w1, [x19]
    606c:	340000e1 	cbz	w1, 6088 <fwp_drop1+0x98>
    6070:	7100043f 	cmp	w1, #0x1
    6074:	540001e0 	b.eq	60b0 <fwp_drop1+0xc0>  // b.none
    6078:	7103fc3f 	cmp	w1, #0xff
    607c:	540002e0 	b.eq	60d8 <fwp_drop1+0xe8>  // b.none
    6080:	51000421 	sub	w1, w1, #0x1
    6084:	39000261 	strb	w1, [x19]
    6088:	a94153f3 	ldp	x19, x20, [sp, #16]
    608c:	f94013f5 	ldr	x21, [sp, #32]
    6090:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6094:	d65f03c0 	ret
    6098:	72003c3f 	tst	w1, #0xffff
    609c:	54fffe60 	b.eq	6068 <fwp_drop1+0x78>  // b.none
    60a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    60a4:	f94013f5 	ldr	x21, [sp, #32]
    60a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60ac:	d65f03c0 	ret
    60b0:	f9400813 	ldr	x19, [x0, #16]
    60b4:	97fffef3 	bl	5c80 <fwp_rc_free_arr>
    60b8:	9118c2a0 	add	x0, x21, #0x630
    60bc:	f949d801 	ldr	x1, [x0, #5040]
    60c0:	f949ec00 	ldr	x0, [x0, #5080]
    60c4:	cb010261 	sub	x1, x19, x1
    60c8:	eb00403f 	cmp	x1, x0, lsl #16
    60cc:	54fffde2 	b.cs	6088 <fwp_drop1+0x98>  // b.hs, b.nlast
    60d0:	aa1303e0 	mov	x0, x19
    60d4:	17ffffd2 	b	601c <fwp_drop1+0x2c>
    60d8:	ca534660 	eor	x0, x19, x19, lsr #17
    60dc:	9118c2b5 	add	x21, x21, #0x630
    60e0:	ca402400 	eor	x0, x0, x0, lsr #9
    60e4:	92401c00 	and	x0, x0, #0xff
    60e8:	910a2402 	add	x2, x0, #0x289
    60ec:	8b000ea0 	add	x0, x21, x0, lsl #3
    60f0:	8b020ea2 	add	x2, x21, x2, lsl #3
    60f4:	f94a2400 	ldr	x0, [x0, #5192]
    60f8:	b50000a0 	cbnz	x0, 610c <fwp_drop1+0x11c>
    60fc:	14000013 	b	6148 <fwp_drop1+0x158>
    6100:	91004002 	add	x2, x0, #0x10
    6104:	f9400800 	ldr	x0, [x0, #16]
    6108:	b4000200 	cbz	x0, 6148 <fwp_drop1+0x158>
    610c:	f9400001 	ldr	x1, [x0]
    6110:	eb13003f 	cmp	x1, x19
    6114:	54ffff61 	b.ne	6100 <fwp_drop1+0x110>  // b.any
    6118:	f9400041 	ldr	x1, [x2]
    611c:	f9400420 	ldr	x0, [x1, #8]
    6120:	d1000400 	sub	x0, x0, #0x1
    6124:	f9000420 	str	x0, [x1, #8]
    6128:	f103f81f 	cmp	x0, #0xfe
    612c:	54fffae1 	b.ne	6088 <fwp_drop1+0x98>  // b.any
    6130:	39400260 	ldrb	w0, [x19]
    6134:	7103fc1f 	cmp	w0, #0xff
    6138:	540000e0 	b.eq	6154 <fwp_drop1+0x164>  // b.none
    613c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6140:	39000260 	strb	w0, [x19]
    6144:	17ffffd1 	b	6088 <fwp_drop1+0x98>
    6148:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    614c:	9118e000 	add	x0, x0, #0x638
    6150:	97fff879 	bl	4334 <fwp_trap>
    6154:	aa1303e0 	mov	x0, x19
    6158:	97fff897 	bl	43b4 <fwp_rc_forget_slot.part.0>
    615c:	17fffff8 	b	613c <fwp_drop1+0x14c>

0000000000006160 <fwp_drop0>:
    6160:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6164:	910003fd 	mov	x29, sp
    6168:	a90153f3 	stp	x19, x20, [sp, #16]
    616c:	f90013f5 	str	x21, [sp, #32]
    6170:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    6174:	9118c2b4 	add	x20, x21, #0x630
    6178:	f949da81 	ldr	x1, [x20, #5040]
    617c:	f949ee82 	ldr	x2, [x20, #5080]
    6180:	cb010001 	sub	x1, x0, x1
    6184:	eb02403f 	cmp	x1, x2, lsl #16
    6188:	54000382 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    618c:	d350fc22 	lsr	x2, x1, #16
    6190:	f949fe84 	ldr	x4, [x20, #5112]
    6194:	8b020842 	add	x2, x2, x2, lsl #2
    6198:	d37df042 	lsl	x2, x2, #3
    619c:	8b020083 	add	x3, x4, x2
    61a0:	f9401073 	ldr	x19, [x3, #32]
    61a4:	b40002b3 	cbz	x19, 61f8 <fwp_drop0+0x98>
    61a8:	38626882 	ldrb	w2, [x4, x2]
    61ac:	7100085f 	cmp	w2, #0x2
    61b0:	540002c0 	b.eq	6208 <fwp_drop0+0xa8>  // b.none
    61b4:	7100045f 	cmp	w2, #0x1
    61b8:	54000201 	b.ne	61f8 <fwp_drop0+0x98>  // b.any
    61bc:	29430864 	ldp	w4, w2, [x3, #24]
    61c0:	92403c21 	and	x1, x1, #0xffff
    61c4:	9b047c21 	mul	x1, x1, x4
    61c8:	d360fc21 	lsr	x1, x1, #32
    61cc:	eb02003f 	cmp	x1, x2
    61d0:	54000142 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    61d4:	8b010273 	add	x19, x19, x1
    61d8:	39400261 	ldrb	w1, [x19]
    61dc:	340000e1 	cbz	w1, 61f8 <fwp_drop0+0x98>
    61e0:	7100043f 	cmp	w1, #0x1
    61e4:	540001e0 	b.eq	6220 <fwp_drop0+0xc0>  // b.none
    61e8:	7103fc3f 	cmp	w1, #0xff
    61ec:	540002e0 	b.eq	6248 <fwp_drop0+0xe8>  // b.none
    61f0:	51000421 	sub	w1, w1, #0x1
    61f4:	39000261 	strb	w1, [x19]
    61f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    61fc:	f94013f5 	ldr	x21, [sp, #32]
    6200:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6204:	d65f03c0 	ret
    6208:	72003c3f 	tst	w1, #0xffff
    620c:	54fffe60 	b.eq	61d8 <fwp_drop0+0x78>  // b.none
    6210:	a94153f3 	ldp	x19, x20, [sp, #16]
    6214:	f94013f5 	ldr	x21, [sp, #32]
    6218:	a8c37bfd 	ldp	x29, x30, [sp], #48
    621c:	d65f03c0 	ret
    6220:	f9400813 	ldr	x19, [x0, #16]
    6224:	97fffe97 	bl	5c80 <fwp_rc_free_arr>
    6228:	9118c2a0 	add	x0, x21, #0x630
    622c:	f949d801 	ldr	x1, [x0, #5040]
    6230:	f949ec00 	ldr	x0, [x0, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54fffde2 	b.cs	61f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6240:	aa1303e0 	mov	x0, x19
    6244:	17ffffd2 	b	618c <fwp_drop0+0x2c>
    6248:	ca534660 	eor	x0, x19, x19, lsr #17
    624c:	9118c2b5 	add	x21, x21, #0x630
    6250:	ca402400 	eor	x0, x0, x0, lsr #9
    6254:	92401c00 	and	x0, x0, #0xff
    6258:	910a2402 	add	x2, x0, #0x289
    625c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6260:	8b020ea2 	add	x2, x21, x2, lsl #3
    6264:	f94a2400 	ldr	x0, [x0, #5192]
    6268:	b50000a0 	cbnz	x0, 627c <fwp_drop0+0x11c>
    626c:	14000013 	b	62b8 <fwp_drop0+0x158>
    6270:	91004002 	add	x2, x0, #0x10
    6274:	f9400800 	ldr	x0, [x0, #16]
    6278:	b4000200 	cbz	x0, 62b8 <fwp_drop0+0x158>
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb13003f 	cmp	x1, x19
    6284:	54ffff61 	b.ne	6270 <fwp_drop0+0x110>  // b.any
    6288:	f9400041 	ldr	x1, [x2]
    628c:	f9400420 	ldr	x0, [x1, #8]
    6290:	d1000400 	sub	x0, x0, #0x1
    6294:	f9000420 	str	x0, [x1, #8]
    6298:	f103f81f 	cmp	x0, #0xfe
    629c:	54fffae1 	b.ne	61f8 <fwp_drop0+0x98>  // b.any
    62a0:	39400260 	ldrb	w0, [x19]
    62a4:	7103fc1f 	cmp	w0, #0xff
    62a8:	540000e0 	b.eq	62c4 <fwp_drop0+0x164>  // b.none
    62ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62b0:	39000260 	strb	w0, [x19]
    62b4:	17ffffd1 	b	61f8 <fwp_drop0+0x98>
    62b8:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    62bc:	9118e000 	add	x0, x0, #0x638
    62c0:	97fff81d 	bl	4334 <fwp_trap>
    62c4:	aa1303e0 	mov	x0, x19
    62c8:	97fff83b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    62cc:	17fffff8 	b	62ac <fwp_drop0+0x14c>

00000000000062d0 <fwp_closure_drop>:
    62d0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    62d4:	9118c0a4 	add	x4, x5, #0x630
    62d8:	aa0003e1 	mov	x1, x0
    62dc:	f949d882 	ldr	x2, [x4, #5040]
    62e0:	f949ec80 	ldr	x0, [x4, #5080]
    62e4:	cb020022 	sub	x2, x1, x2
    62e8:	eb00405f 	cmp	x2, x0, lsl #16
    62ec:	54000662 	b.cs	63b8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    62f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62f4:	d350fc43 	lsr	x3, x2, #16
    62f8:	910003fd 	mov	x29, sp
    62fc:	8b030863 	add	x3, x3, x3, lsl #2
    6300:	f949fc84 	ldr	x4, [x4, #5112]
    6304:	d37df063 	lsl	x3, x3, #3
    6308:	f9000bf3 	str	x19, [sp, #16]
    630c:	8b030080 	add	x0, x4, x3
    6310:	f9401013 	ldr	x19, [x0, #32]
    6314:	b40002b3 	cbz	x19, 6368 <fwp_closure_drop+0x98>
    6318:	38636883 	ldrb	w3, [x4, x3]
    631c:	7100087f 	cmp	w3, #0x2
    6320:	54000420 	b.eq	63a4 <fwp_closure_drop+0xd4>  // b.none
    6324:	7100047f 	cmp	w3, #0x1
    6328:	54000201 	b.ne	6368 <fwp_closure_drop+0x98>  // b.any
    632c:	29430003 	ldp	w3, w0, [x0, #24]
    6330:	92403c42 	and	x2, x2, #0xffff
    6334:	9b037c42 	mul	x2, x2, x3
    6338:	d360fc42 	lsr	x2, x2, #32
    633c:	eb00005f 	cmp	x2, x0
    6340:	54000142 	b.cs	6368 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6344:	8b020273 	add	x19, x19, x2
    6348:	39400260 	ldrb	w0, [x19]
    634c:	340000e0 	cbz	w0, 6368 <fwp_closure_drop+0x98>
    6350:	7100041f 	cmp	w0, #0x1
    6354:	54000100 	b.eq	6374 <fwp_closure_drop+0xa4>  // b.none
    6358:	7103fc1f 	cmp	w0, #0xff
    635c:	54000300 	b.eq	63bc <fwp_closure_drop+0xec>  // b.none
    6360:	51000400 	sub	w0, w0, #0x1
    6364:	39000260 	strb	w0, [x19]
    6368:	f9400bf3 	ldr	x19, [sp, #16]
    636c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6370:	d65f03c0 	ret
    6374:	d53bd040 	mrs	x0, tpidr_el0
    6378:	91400000 	add	x0, x0, #0x0, lsl #12
    637c:	91004000 	add	x0, x0, #0x10
    6380:	f9400000 	ldr	x0, [x0]
    6384:	b4000080 	cbz	x0, 6394 <fwp_closure_drop+0xc4>
    6388:	f9400bf3 	ldr	x19, [sp, #16]
    638c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6390:	17fff964 	b	4920 <fwp_closure_drop_push>
    6394:	f9400bf3 	ldr	x19, [sp, #16]
    6398:	aa0103e0 	mov	x0, x1
    639c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a0:	17fff9a5 	b	4a34 <fwp_closure_drop.part.0>
    63a4:	72003c5f 	tst	w2, #0xffff
    63a8:	54fffd00 	b.eq	6348 <fwp_closure_drop+0x78>  // b.none
    63ac:	f9400bf3 	ldr	x19, [sp, #16]
    63b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63b4:	d65f03c0 	ret
    63b8:	d65f03c0 	ret
    63bc:	ca534660 	eor	x0, x19, x19, lsr #17
    63c0:	9118c0a5 	add	x5, x5, #0x630
    63c4:	ca402400 	eor	x0, x0, x0, lsr #9
    63c8:	92401c00 	and	x0, x0, #0xff
    63cc:	910a2402 	add	x2, x0, #0x289
    63d0:	8b000ca0 	add	x0, x5, x0, lsl #3
    63d4:	8b020ca2 	add	x2, x5, x2, lsl #3
    63d8:	f94a2400 	ldr	x0, [x0, #5192]
    63dc:	b50000a0 	cbnz	x0, 63f0 <fwp_closure_drop+0x120>
    63e0:	14000013 	b	642c <fwp_closure_drop+0x15c>
    63e4:	91004002 	add	x2, x0, #0x10
    63e8:	f9400800 	ldr	x0, [x0, #16]
    63ec:	b4000200 	cbz	x0, 642c <fwp_closure_drop+0x15c>
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	eb13003f 	cmp	x1, x19
    63f8:	54ffff61 	b.ne	63e4 <fwp_closure_drop+0x114>  // b.any
    63fc:	f9400041 	ldr	x1, [x2]
    6400:	f9400420 	ldr	x0, [x1, #8]
    6404:	d1000400 	sub	x0, x0, #0x1
    6408:	f9000420 	str	x0, [x1, #8]
    640c:	f103f81f 	cmp	x0, #0xfe
    6410:	54fffac1 	b.ne	6368 <fwp_closure_drop+0x98>  // b.any
    6414:	39400260 	ldrb	w0, [x19]
    6418:	7103fc1f 	cmp	w0, #0xff
    641c:	540000e0 	b.eq	6438 <fwp_closure_drop+0x168>  // b.none
    6420:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6424:	39000260 	strb	w0, [x19]
    6428:	17ffffd0 	b	6368 <fwp_closure_drop+0x98>
    642c:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6430:	9118e000 	add	x0, x0, #0x638
    6434:	97fff7c0 	bl	4334 <fwp_trap>
    6438:	aa1303e0 	mov	x0, x19
    643c:	97fff7de 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6440:	17fffff8 	b	6420 <fwp_closure_drop+0x150>

0000000000006444 <fwp_owned_tape_release>:
    6444:	b4000920 	cbz	x0, 6568 <fwp_owned_tape_release+0x124>
    6448:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    644c:	910003fd 	mov	x29, sp
    6450:	a90153f3 	stp	x19, x20, [sp, #16]
    6454:	aa0003f3 	mov	x19, x0
    6458:	f9400000 	ldr	x0, [x0]
    645c:	b4000060 	cbz	x0, 6468 <fwp_owned_tape_release+0x24>
    6460:	f9400661 	ldr	x1, [x19, #8]
    6464:	f9000401 	str	x1, [x0, #8]
    6468:	f9400661 	ldr	x1, [x19, #8]
    646c:	b4000041 	cbz	x1, 6474 <fwp_owned_tape_release+0x30>
    6470:	f9000020 	str	x0, [x1]
    6474:	f9400a60 	ldr	x0, [x19, #16]
    6478:	f9403401 	ldr	x1, [x0, #104]
    647c:	b40005a1 	cbz	x1, 6530 <fwp_owned_tape_release+0xec>
    6480:	a9450a60 	ldp	x0, x2, [x19, #80]
    6484:	eb00005f 	cmp	x2, x0
    6488:	540002cd 	b.le	64e0 <fwp_owned_tape_release+0x9c>
    648c:	d2800014 	mov	x20, #0x0                   	// #0
    6490:	f90013f5 	str	x21, [sp, #32]
    6494:	d2800015 	mov	x21, #0x0                   	// #0
    6498:	f9402260 	ldr	x0, [x19, #64]
    649c:	910006b5 	add	x21, x21, #0x1
    64a0:	f8746800 	ldr	x0, [x0, x20]
    64a4:	d63f0020 	blr	x1
    64a8:	f9402260 	ldr	x0, [x19, #64]
    64ac:	f9400a61 	ldr	x1, [x19, #16]
    64b0:	8b140000 	add	x0, x0, x20
    64b4:	91004294 	add	x20, x20, #0x10
    64b8:	f9400400 	ldr	x0, [x0, #8]
    64bc:	f9403421 	ldr	x1, [x1, #104]
    64c0:	d63f0020 	blr	x1
    64c4:	a9450261 	ldp	x1, x0, [x19, #80]
    64c8:	cb010000 	sub	x0, x0, x1
    64cc:	eb15001f 	cmp	x0, x21
    64d0:	f9400a60 	ldr	x0, [x19, #16]
    64d4:	f9403401 	ldr	x1, [x0, #104]
    64d8:	54fffe0c 	b.gt	6498 <fwp_owned_tape_release+0x54>
    64dc:	f94013f5 	ldr	x21, [sp, #32]
    64e0:	f9403663 	ldr	x3, [x19, #104]
    64e4:	f9401262 	ldr	x2, [x19, #32]
    64e8:	f100007f 	cmp	x3, #0x0
    64ec:	540001ed 	b.le	6528 <fwp_owned_tape_release+0xe4>
    64f0:	d2800014 	mov	x20, #0x0                   	// #0
    64f4:	d503201f 	nop
    64f8:	f9402660 	ldr	x0, [x19, #72]
    64fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6500:	eb02001f 	cmp	x0, x2
    6504:	540000c0 	b.eq	651c <fwp_owned_tape_release+0xd8>  // b.none
    6508:	d63f0020 	blr	x1
    650c:	f9400a60 	ldr	x0, [x19, #16]
    6510:	f9401262 	ldr	x2, [x19, #32]
    6514:	f9403663 	ldr	x3, [x19, #104]
    6518:	f9403401 	ldr	x1, [x0, #104]
    651c:	91000694 	add	x20, x20, #0x1
    6520:	eb14007f 	cmp	x3, x20
    6524:	54fffeac 	b.gt	64f8 <fwp_owned_tape_release+0xb4>
    6528:	aa0203e0 	mov	x0, x2
    652c:	d63f0020 	blr	x1
    6530:	f9401660 	ldr	x0, [x19, #40]
    6534:	97ffff67 	bl	62d0 <fwp_closure_drop>
    6538:	f9401a60 	ldr	x0, [x19, #48]
    653c:	97ffff65 	bl	62d0 <fwp_closure_drop>
    6540:	f9401e60 	ldr	x0, [x19, #56]
    6544:	97ffff63 	bl	62d0 <fwp_closure_drop>
    6548:	f9402260 	ldr	x0, [x19, #64]
    654c:	97fff835 	bl	4620 <fwp_mem_free>
    6550:	f9402660 	ldr	x0, [x19, #72]
    6554:	97fff833 	bl	4620 <fwp_mem_free>
    6558:	aa1303e0 	mov	x0, x19
    655c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6560:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6564:	17fff82f 	b	4620 <fwp_mem_free>
    6568:	d65f03c0 	ret
    656c:	d503201f 	nop

0000000000006570 <fwp_tape_finish>:
    6570:	d10203ff 	sub	sp, sp, #0x80
    6574:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6578:	f947f421 	ldr	x1, [x1, #4072]
    657c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6580:	910103fd 	add	x29, sp, #0x40
    6584:	a9065bf5 	stp	x21, x22, [sp, #96]
    6588:	a90763f7 	stp	x23, x24, [sp, #112]
    658c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6590:	910142f6 	add	x22, x23, #0x50
    6594:	f9400022 	ldr	x2, [x1]
    6598:	f9001fe2 	str	x2, [sp, #56]
    659c:	d2800002 	mov	x2, #0x0                   	// #0
    65a0:	910342c0 	add	x0, x22, #0xd0
    65a4:	97fff6b4 	bl	4074 <fwp_tape_buffers_dispose>
    65a8:	f90086df 	str	xzr, [x22, #264]
    65ac:	f94092c0 	ldr	x0, [x22, #288]
    65b0:	f100001f 	cmp	x0, #0x0
    65b4:	5400034d 	b.le	661c <fwp_tape_finish+0xac>
    65b8:	910003f8 	mov	x24, sp
    65bc:	d2800015 	mov	x21, #0x0                   	// #0
    65c0:	a90553f3 	stp	x19, x20, [sp, #80]
    65c4:	d2800014 	mov	x20, #0x0                   	// #0
    65c8:	91000694 	add	x20, x20, #0x1
    65cc:	f94046d3 	ldr	x19, [x22, #136]
    65d0:	8b150273 	add	x19, x19, x21
    65d4:	9101a2b5 	add	x21, x21, #0x68
    65d8:	aa1303e0 	mov	x0, x19
    65dc:	97fff28e 	bl	3014 <fwp_tape_unlink_scope>
    65e0:	aa1803e0 	mov	x0, x24
    65e4:	a9440663 	ldp	x3, x1, [x19, #64]
    65e8:	f9001be1 	str	x1, [sp, #48]
    65ec:	f9400e62 	ldr	x2, [x19, #24]
    65f0:	a9020be3 	stp	x3, x2, [sp, #32]
    65f4:	ad410261 	ldp	q1, q0, [x19, #32]
    65f8:	ad0003e1 	stp	q1, q0, [sp]
    65fc:	97fff69e 	bl	4074 <fwp_tape_buffers_dispose>
    6600:	f9403260 	ldr	x0, [x19, #96]
    6604:	97ffff90 	bl	6444 <fwp_owned_tape_release>
    6608:	f900327f 	str	xzr, [x19, #96]
    660c:	f94092c0 	ldr	x0, [x22, #288]
    6610:	eb14001f 	cmp	x0, x20
    6614:	54fffdac 	b.gt	65c8 <fwp_tape_finish+0x58>
    6618:	a94553f3 	ldp	x19, x20, [sp, #80]
    661c:	910142e0 	add	x0, x23, #0x50
    6620:	f9404400 	ldr	x0, [x0, #136]
    6624:	b4000040 	cbz	x0, 662c <fwp_tape_finish+0xbc>
    6628:	97fff672 	bl	3ff0 <ad_raw_free.part.0>
    662c:	910142f7 	add	x23, x23, #0x50
    6630:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6634:	f947f400 	ldr	x0, [x0, #4072]
    6638:	f90046ff 	str	xzr, [x23, #136]
    663c:	f9008aff 	str	xzr, [x23, #272]
    6640:	f90092ff 	str	xzr, [x23, #288]
    6644:	f900b2ff 	str	xzr, [x23, #352]
    6648:	f9401fe2 	ldr	x2, [sp, #56]
    664c:	f9400001 	ldr	x1, [x0]
    6650:	eb010042 	subs	x2, x2, x1
    6654:	d2800001 	mov	x1, #0x0                   	// #0
    6658:	540000c1 	b.ne	6670 <fwp_tape_finish+0x100>  // b.any
    665c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6660:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6664:	a94763f7 	ldp	x23, x24, [sp, #112]
    6668:	910203ff 	add	sp, sp, #0x80
    666c:	d65f03c0 	ret
    6670:	a90553f3 	stp	x19, x20, [sp, #80]
    6674:	97fff08b 	bl	28a0 <__stack_chk_fail@plt>
    6678:	d503201f 	nop
    667c:	d503201f 	nop

0000000000006680 <fwp_tape_scope_release>:
    6680:	d10243ff 	sub	sp, sp, #0x90
    6684:	a9047bfd 	stp	x29, x30, [sp, #64]
    6688:	910103fd 	add	x29, sp, #0x40
    668c:	a90553f3 	stp	x19, x20, [sp, #80]
    6690:	aa0003f4 	mov	x20, x0
    6694:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6698:	f947f400 	ldr	x0, [x0, #4072]
    669c:	b9400285 	ldr	w5, [x20]
    66a0:	f9400001 	ldr	x1, [x0]
    66a4:	f9001fe1 	str	x1, [sp, #56]
    66a8:	d2800001 	mov	x1, #0x0                   	// #0
    66ac:	37f806c5 	tbnz	w5, #31, 6784 <fwp_tape_scope_release+0x104>
    66b0:	a90763f7 	stp	x23, x24, [sp, #112]
    66b4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    66b8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    66bc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    66c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    66c4:	910003f7 	mov	x23, sp
    66c8:	91014273 	add	x19, x19, #0x50
    66cc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    66d0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66d4:	52800d16 	mov	w22, #0x68                  	// #104
    66d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    66dc:	f90043f9 	str	x25, [sp, #128]
    66e0:	14000006 	b	66f8 <fwp_tape_scope_release+0x78>
    66e4:	97fff664 	bl	4074 <fwp_tape_buffers_dispose>
    66e8:	aa1903e0 	mov	x0, x25
    66ec:	97ffff56 	bl	6444 <fwp_owned_tape_release>
    66f0:	b9400285 	ldr	w5, [x20]
    66f4:	37f80425 	tbnz	w5, #31, 6778 <fwp_tape_scope_release+0xf8>
    66f8:	f9404666 	ldr	x6, [x19, #136]
    66fc:	9b367ca5 	smull	x5, w5, w22
    6700:	8b0500c0 	add	x0, x6, x5
    6704:	97fff244 	bl	3014 <fwp_tape_unlink_scope>
    6708:	ad410001 	ldp	q1, q0, [x0, #32]
    670c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6710:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6714:	f9400c03 	ldr	x3, [x0, #24]
    6718:	ad0003e1 	stp	q1, q0, [sp]
    671c:	b86568c1 	ldr	w1, [x6, x5]
    6720:	a9440804 	ldp	x4, x2, [x0, #64]
    6724:	b900041f 	str	wzr, [x0, #4]
    6728:	f9403019 	ldr	x25, [x0, #96]
    672c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6730:	f9000c1f 	str	xzr, [x0, #24]
    6734:	a9020fe4 	stp	x4, x3, [sp, #32]
    6738:	f9001be2 	str	x2, [sp, #48]
    673c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6740:	f900301f 	str	xzr, [x0, #96]
    6744:	6b15003f 	cmp	w1, w21
    6748:	540000e8 	b.hi	6764 <fwp_tape_scope_release+0xe4>  // b.pmore
    674c:	9343fca5 	asr	x5, x5, #3
    6750:	f940b260 	ldr	x0, [x19, #352]
    6754:	9b187ca5 	mul	x5, x5, x24
    6758:	eb0000bf 	cmp	x5, x0
    675c:	5400004a 	b.ge	6764 <fwp_tape_scope_release+0xe4>  // b.tcont
    6760:	f900b265 	str	x5, [x19, #352]
    6764:	aa1703e0 	mov	x0, x23
    6768:	b5fffbf9 	cbnz	x25, 66e4 <fwp_tape_scope_release+0x64>
    676c:	97fff68a 	bl	4194 <fwp_tape_buffers_release>
    6770:	b9400285 	ldr	w5, [x20]
    6774:	36fffc25 	tbz	w5, #31, 66f8 <fwp_tape_scope_release+0x78>
    6778:	a9465bf5 	ldp	x21, x22, [sp, #96]
    677c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6780:	f94043f9 	ldr	x25, [sp, #128]
    6784:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6788:	f947f400 	ldr	x0, [x0, #4072]
    678c:	f9401fe2 	ldr	x2, [sp, #56]
    6790:	f9400001 	ldr	x1, [x0]
    6794:	eb010042 	subs	x2, x2, x1
    6798:	d2800001 	mov	x1, #0x0                   	// #0
    679c:	540000a1 	b.ne	67b0 <fwp_tape_scope_release+0x130>  // b.any
    67a0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    67a4:	a94553f3 	ldp	x19, x20, [sp, #80]
    67a8:	910243ff 	add	sp, sp, #0x90
    67ac:	d65f03c0 	ret
    67b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    67b4:	a90763f7 	stp	x23, x24, [sp, #112]
    67b8:	f90043f9 	str	x25, [sp, #128]
    67bc:	97fff039 	bl	28a0 <__stack_chk_fail@plt>

00000000000067c0 <fwp_drop4>:
    67c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    67c4:	910003fd 	mov	x29, sp
    67c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    67cc:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    67d0:	9118c2d5 	add	x21, x22, #0x630
    67d4:	a90153f3 	stp	x19, x20, [sp, #16]
    67d8:	aa0003f3 	mov	x19, x0
    67dc:	f949daa1 	ldr	x1, [x21, #5040]
    67e0:	f949eea0 	ldr	x0, [x21, #5080]
    67e4:	cb010261 	sub	x1, x19, x1
    67e8:	eb00403f 	cmp	x1, x0, lsl #16
    67ec:	54000382 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    67f0:	d350fc22 	lsr	x2, x1, #16
    67f4:	f949fea3 	ldr	x3, [x21, #5112]
    67f8:	8b020842 	add	x2, x2, x2, lsl #2
    67fc:	d37df042 	lsl	x2, x2, #3
    6800:	8b020060 	add	x0, x3, x2
    6804:	f9401014 	ldr	x20, [x0, #32]
    6808:	b40002b4 	cbz	x20, 685c <fwp_drop4+0x9c>
    680c:	38626862 	ldrb	w2, [x3, x2]
    6810:	7100085f 	cmp	w2, #0x2
    6814:	540002c0 	b.eq	686c <fwp_drop4+0xac>  // b.none
    6818:	7100045f 	cmp	w2, #0x1
    681c:	54000201 	b.ne	685c <fwp_drop4+0x9c>  // b.any
    6820:	29430002 	ldp	w2, w0, [x0, #24]
    6824:	92403c21 	and	x1, x1, #0xffff
    6828:	9b027c21 	mul	x1, x1, x2
    682c:	d360fc21 	lsr	x1, x1, #32
    6830:	eb00003f 	cmp	x1, x0
    6834:	54000142 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6838:	8b010294 	add	x20, x20, x1
    683c:	39400280 	ldrb	w0, [x20]
    6840:	340000e0 	cbz	w0, 685c <fwp_drop4+0x9c>
    6844:	7100041f 	cmp	w0, #0x1
    6848:	540001e0 	b.eq	6884 <fwp_drop4+0xc4>  // b.none
    684c:	7103fc1f 	cmp	w0, #0xff
    6850:	540007c0 	b.eq	6948 <fwp_drop4+0x188>  // b.none
    6854:	51000400 	sub	w0, w0, #0x1
    6858:	39000280 	strb	w0, [x20]
    685c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6860:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6864:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6868:	d65f03c0 	ret
    686c:	72003c3f 	tst	w1, #0xffff
    6870:	54fffe60 	b.eq	683c <fwp_drop4+0x7c>  // b.none
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	a9425bf5 	ldp	x21, x22, [sp, #32]
    687c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6880:	d65f03c0 	ret
    6884:	9118c2c2 	add	x2, x22, #0x630
    6888:	f9400660 	ldr	x0, [x19, #8]
    688c:	f949d841 	ldr	x1, [x2, #5040]
    6890:	f949ec42 	ldr	x2, [x2, #5080]
    6894:	cb010001 	sub	x1, x0, x1
    6898:	eb02403f 	cmp	x1, x2, lsl #16
    689c:	54000362 	b.cs	6908 <fwp_drop4+0x148>  // b.hs, b.nlast
    68a0:	d350fc22 	lsr	x2, x1, #16
    68a4:	8b020842 	add	x2, x2, x2, lsl #2
    68a8:	d37df042 	lsl	x2, x2, #3
    68ac:	8b020064 	add	x4, x3, x2
    68b0:	f9401094 	ldr	x20, [x4, #32]
    68b4:	b40002b4 	cbz	x20, 6908 <fwp_drop4+0x148>
    68b8:	38626862 	ldrb	w2, [x3, x2]
    68bc:	7100085f 	cmp	w2, #0x2
    68c0:	540003e0 	b.eq	693c <fwp_drop4+0x17c>  // b.none
    68c4:	7100045f 	cmp	w2, #0x1
    68c8:	54000201 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    68cc:	29430883 	ldp	w3, w2, [x4, #24]
    68d0:	92403c21 	and	x1, x1, #0xffff
    68d4:	9b037c21 	mul	x1, x1, x3
    68d8:	d360fc21 	lsr	x1, x1, #32
    68dc:	eb02003f 	cmp	x1, x2
    68e0:	54000142 	b.cs	6908 <fwp_drop4+0x148>  // b.hs, b.nlast
    68e4:	8b010294 	add	x20, x20, x1
    68e8:	39400281 	ldrb	w1, [x20]
    68ec:	340000e1 	cbz	w1, 6908 <fwp_drop4+0x148>
    68f0:	7100043f 	cmp	w1, #0x1
    68f4:	54000200 	b.eq	6934 <fwp_drop4+0x174>  // b.none
    68f8:	7103fc3f 	cmp	w1, #0xff
    68fc:	54000640 	b.eq	69c4 <fwp_drop4+0x204>  // b.none
    6900:	51000421 	sub	w1, w1, #0x1
    6904:	39000281 	strb	w1, [x20]
    6908:	f9400a74 	ldr	x20, [x19, #16]
    690c:	aa1303e0 	mov	x0, x19
    6910:	97fffcdc 	bl	5c80 <fwp_rc_free_arr>
    6914:	9118c2c0 	add	x0, x22, #0x630
    6918:	f949d801 	ldr	x1, [x0, #5040]
    691c:	f949ec00 	ldr	x0, [x0, #5080]
    6920:	cb010281 	sub	x1, x20, x1
    6924:	eb00403f 	cmp	x1, x0, lsl #16
    6928:	54fff9a2 	b.cs	685c <fwp_drop4+0x9c>  // b.hs, b.nlast
    692c:	aa1403f3 	mov	x19, x20
    6930:	17ffffb0 	b	67f0 <fwp_drop4+0x30>
    6934:	97fffcd3 	bl	5c80 <fwp_rc_free_arr>
    6938:	17fffff4 	b	6908 <fwp_drop4+0x148>
    693c:	72003c3f 	tst	w1, #0xffff
    6940:	54fffe41 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    6944:	17ffffe9 	b	68e8 <fwp_drop4+0x128>
    6948:	ca544681 	eor	x1, x20, x20, lsr #17
    694c:	9118c2c0 	add	x0, x22, #0x630
    6950:	ca412421 	eor	x1, x1, x1, lsr #9
    6954:	92401c21 	and	x1, x1, #0xff
    6958:	910a2422 	add	x2, x1, #0x289
    695c:	8b010c01 	add	x1, x0, x1, lsl #3
    6960:	8b020c02 	add	x2, x0, x2, lsl #3
    6964:	f94a2420 	ldr	x0, [x1, #5192]
    6968:	b50000a0 	cbnz	x0, 697c <fwp_drop4+0x1bc>
    696c:	14000013 	b	69b8 <fwp_drop4+0x1f8>
    6970:	91004002 	add	x2, x0, #0x10
    6974:	f9400800 	ldr	x0, [x0, #16]
    6978:	b4000200 	cbz	x0, 69b8 <fwp_drop4+0x1f8>
    697c:	f9400001 	ldr	x1, [x0]
    6980:	eb14003f 	cmp	x1, x20
    6984:	54ffff61 	b.ne	6970 <fwp_drop4+0x1b0>  // b.any
    6988:	f9400041 	ldr	x1, [x2]
    698c:	f9400420 	ldr	x0, [x1, #8]
    6990:	d1000400 	sub	x0, x0, #0x1
    6994:	f9000420 	str	x0, [x1, #8]
    6998:	f103f81f 	cmp	x0, #0xfe
    699c:	54fff601 	b.ne	685c <fwp_drop4+0x9c>  // b.any
    69a0:	39400280 	ldrb	w0, [x20]
    69a4:	7103fc1f 	cmp	w0, #0xff
    69a8:	54000460 	b.eq	6a34 <fwp_drop4+0x274>  // b.none
    69ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69b0:	39000280 	strb	w0, [x20]
    69b4:	17ffffaa 	b	685c <fwp_drop4+0x9c>
    69b8:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    69bc:	9118e000 	add	x0, x0, #0x638
    69c0:	97fff65d 	bl	4334 <fwp_trap>
    69c4:	ca544680 	eor	x0, x20, x20, lsr #17
    69c8:	9118c2c1 	add	x1, x22, #0x630
    69cc:	ca402400 	eor	x0, x0, x0, lsr #9
    69d0:	92401c00 	and	x0, x0, #0xff
    69d4:	910a2402 	add	x2, x0, #0x289
    69d8:	8b000c20 	add	x0, x1, x0, lsl #3
    69dc:	8b020c22 	add	x2, x1, x2, lsl #3
    69e0:	f94a2400 	ldr	x0, [x0, #5192]
    69e4:	b50000a0 	cbnz	x0, 69f8 <fwp_drop4+0x238>
    69e8:	17fffff4 	b	69b8 <fwp_drop4+0x1f8>
    69ec:	91004002 	add	x2, x0, #0x10
    69f0:	f9400800 	ldr	x0, [x0, #16]
    69f4:	b4fffe20 	cbz	x0, 69b8 <fwp_drop4+0x1f8>
    69f8:	f9400001 	ldr	x1, [x0]
    69fc:	eb14003f 	cmp	x1, x20
    6a00:	54ffff61 	b.ne	69ec <fwp_drop4+0x22c>  // b.any
    6a04:	f9400041 	ldr	x1, [x2]
    6a08:	f9400420 	ldr	x0, [x1, #8]
    6a0c:	d1000400 	sub	x0, x0, #0x1
    6a10:	f9000420 	str	x0, [x1, #8]
    6a14:	f103f81f 	cmp	x0, #0xfe
    6a18:	54fff781 	b.ne	6908 <fwp_drop4+0x148>  // b.any
    6a1c:	39400280 	ldrb	w0, [x20]
    6a20:	7103fc1f 	cmp	w0, #0xff
    6a24:	540000e0 	b.eq	6a40 <fwp_drop4+0x280>  // b.none
    6a28:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a2c:	39000280 	strb	w0, [x20]
    6a30:	17ffffb6 	b	6908 <fwp_drop4+0x148>
    6a34:	aa1403e0 	mov	x0, x20
    6a38:	97fff65f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6a3c:	17ffffdc 	b	69ac <fwp_drop4+0x1ec>
    6a40:	aa1403e0 	mov	x0, x20
    6a44:	97fff65c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6a48:	17fffff8 	b	6a28 <fwp_drop4+0x268>
    6a4c:	d503201f 	nop

0000000000006a50 <fwp_arg_drop37>:
    6a50:	7100003f 	cmp	w1, #0x0
    6a54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6a58:	54000041 	b.ne	6a60 <fwp_arg_drop37+0x10>  // b.any
    6a5c:	d65f03c0 	ret
    6a60:	f9400000 	ldr	x0, [x0]
    6a64:	17ffff57 	b	67c0 <fwp_drop4>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_task_dispose>:
    6a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	f9000bf3 	str	x19, [sp, #16]
    6a7c:	aa0003f3 	mov	x19, x0
    6a80:	39414000 	ldrb	w0, [x0, #80]
    6a84:	36000720 	tbz	w0, #0, 6b68 <fwp_task_dispose+0xf8>
    6a88:	f9400a60 	ldr	x0, [x19, #16]
    6a8c:	b50006e0 	cbnz	x0, 6b68 <fwp_task_dispose+0xf8>
    6a90:	a9478660 	ldp	x0, x1, [x19, #120]
    6a94:	39014e7f 	strb	wzr, [x19, #83]
    6a98:	f9003e7f 	str	xzr, [x19, #120]
    6a9c:	f100003f 	cmp	x1, #0x0
    6aa0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6aa4:	54000040 	b.eq	6aac <fwp_task_dispose+0x3c>  // b.none
    6aa8:	d63f0020 	blr	x1
    6aac:	f9405660 	ldr	x0, [x19, #168]
    6ab0:	97fff6dc 	bl	4620 <fwp_mem_free>
    6ab4:	f900567f 	str	xzr, [x19, #168]
    6ab8:	b9405e60 	ldr	w0, [x19, #92]
    6abc:	7100041f 	cmp	w0, #0x1
    6ac0:	54000420 	b.eq	6b44 <fwp_task_dispose+0xd4>  // b.none
    6ac4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6ac8:	9118c042 	add	x2, x2, #0x630
    6acc:	f949d840 	ldr	x0, [x2, #5040]
    6ad0:	f949ec41 	ldr	x1, [x2, #5080]
    6ad4:	cb000260 	sub	x0, x19, x0
    6ad8:	eb01401f 	cmp	x0, x1, lsl #16
    6adc:	540002e2 	b.cs	6b38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6ae0:	d350fc01 	lsr	x1, x0, #16
    6ae4:	f949fc44 	ldr	x4, [x2, #5112]
    6ae8:	8b010821 	add	x1, x1, x1, lsl #2
    6aec:	d37df021 	lsl	x1, x1, #3
    6af0:	8b010083 	add	x3, x4, x1
    6af4:	f9401062 	ldr	x2, [x3, #32]
    6af8:	b4000202 	cbz	x2, 6b38 <fwp_task_dispose+0xc8>
    6afc:	38616881 	ldrb	w1, [x4, x1]
    6b00:	7100083f 	cmp	w1, #0x2
    6b04:	54000280 	b.eq	6b54 <fwp_task_dispose+0xe4>  // b.none
    6b08:	7100043f 	cmp	w1, #0x1
    6b0c:	54000161 	b.ne	6b38 <fwp_task_dispose+0xc8>  // b.any
    6b10:	29430464 	ldp	w4, w1, [x3, #24]
    6b14:	92403c00 	and	x0, x0, #0xffff
    6b18:	9b047c00 	mul	x0, x0, x4
    6b1c:	d360fc00 	lsr	x0, x0, #32
    6b20:	eb01001f 	cmp	x0, x1
    6b24:	540000a2 	b.cs	6b38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6b28:	8b000042 	add	x2, x2, x0
    6b2c:	39400040 	ldrb	w0, [x2]
    6b30:	7100041f 	cmp	w0, #0x1
    6b34:	54000080 	b.eq	6b44 <fwp_task_dispose+0xd4>  // b.none
    6b38:	f9400bf3 	ldr	x19, [sp, #16]
    6b3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b40:	d65f03c0 	ret
    6b44:	aa1303e0 	mov	x0, x19
    6b48:	f9400bf3 	ldr	x19, [sp, #16]
    6b4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b50:	17fff6b4 	b	4620 <fwp_mem_free>
    6b54:	72003c1f 	tst	w0, #0xffff
    6b58:	54fffea0 	b.eq	6b2c <fwp_task_dispose+0xbc>  // b.none
    6b5c:	f9400bf3 	ldr	x19, [sp, #16]
    6b60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b64:	d65f03c0 	ret
    6b68:	97ffef62 	bl	28f0 <abort@plt>
    6b6c:	d503201f 	nop

0000000000006b70 <fwp_free_zombie>:
    6b70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b74:	910003fd 	mov	x29, sp
    6b78:	a90153f3 	stp	x19, x20, [sp, #16]
    6b7c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6b80:	91014281 	add	x1, x20, #0x50
    6b84:	f940b433 	ldr	x19, [x1, #360]
    6b88:	b4000333 	cbz	x19, 6bec <fwp_free_zombie+0x7c>
    6b8c:	f9404c20 	ldr	x0, [x1, #152]
    6b90:	eb00027f 	cmp	x19, x0
    6b94:	540002c0 	b.eq	6bec <fwp_free_zombie+0x7c>  // b.none
    6b98:	b9417022 	ldr	w2, [x1, #368]
    6b9c:	f9400a60 	ldr	x0, [x19, #16]
    6ba0:	7100fc5f 	cmp	w2, #0x3f
    6ba4:	5400078c 	b.gt	6c94 <fwp_free_zombie+0x124>
    6ba8:	91060023 	add	x3, x1, #0x180
    6bac:	11000444 	add	w4, w2, #0x1
    6bb0:	b9017024 	str	w4, [x1, #368]
    6bb4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6bb8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6bbc:	a9530261 	ldp	x1, x0, [x19, #304]
    6bc0:	b4000741 	cbz	x1, 6ca8 <fwp_free_zombie+0x138>
    6bc4:	f9009c20 	str	x0, [x1, #312]
    6bc8:	b4000040 	cbz	x0, 6bd0 <fwp_free_zombie+0x60>
    6bcc:	f9009801 	str	x1, [x0, #304]
    6bd0:	91014294 	add	x20, x20, #0x50
    6bd4:	b9405e60 	ldr	w0, [x19, #92]
    6bd8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6bdc:	f900b69f 	str	xzr, [x20, #360]
    6be0:	34000140 	cbz	w0, 6c08 <fwp_free_zombie+0x98>
    6be4:	7100041f 	cmp	w0, #0x1
    6be8:	54000080 	b.eq	6bf8 <fwp_free_zombie+0x88>  // b.none
    6bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bf4:	d65f03c0 	ret
    6bf8:	aa1303e0 	mov	x0, x19
    6bfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c04:	17ffff9b 	b	6a70 <fwp_task_dispose>
    6c08:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    6c0c:	9118c082 	add	x2, x4, #0x630
    6c10:	f949d841 	ldr	x1, [x2, #5040]
    6c14:	f949ec40 	ldr	x0, [x2, #5080]
    6c18:	cb010261 	sub	x1, x19, x1
    6c1c:	eb00403f 	cmp	x1, x0, lsl #16
    6c20:	54fffe62 	b.cs	6bec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c24:	d350fc20 	lsr	x0, x1, #16
    6c28:	f949fc43 	ldr	x3, [x2, #5112]
    6c2c:	8b000800 	add	x0, x0, x0, lsl #2
    6c30:	d37df000 	lsl	x0, x0, #3
    6c34:	8b000062 	add	x2, x3, x0
    6c38:	f9401054 	ldr	x20, [x2, #32]
    6c3c:	b4fffd94 	cbz	x20, 6bec <fwp_free_zombie+0x7c>
    6c40:	38606860 	ldrb	w0, [x3, x0]
    6c44:	7100081f 	cmp	w0, #0x2
    6c48:	54000360 	b.eq	6cb4 <fwp_free_zombie+0x144>  // b.none
    6c4c:	7100041f 	cmp	w0, #0x1
    6c50:	54fffce1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6c54:	29430043 	ldp	w3, w0, [x2, #24]
    6c58:	92403c21 	and	x1, x1, #0xffff
    6c5c:	9b037c21 	mul	x1, x1, x3
    6c60:	d360fc21 	lsr	x1, x1, #32
    6c64:	eb00003f 	cmp	x1, x0
    6c68:	54fffc22 	b.cs	6bec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6c6c:	8b010294 	add	x20, x20, x1
    6c70:	39400280 	ldrb	w0, [x20]
    6c74:	34fffbc0 	cbz	w0, 6bec <fwp_free_zombie+0x7c>
    6c78:	7100041f 	cmp	w0, #0x1
    6c7c:	54fffbe0 	b.eq	6bf8 <fwp_free_zombie+0x88>  // b.none
    6c80:	7103fc1f 	cmp	w0, #0xff
    6c84:	540001e0 	b.eq	6cc0 <fwp_free_zombie+0x150>  // b.none
    6c88:	51000400 	sub	w0, w0, #0x1
    6c8c:	39000280 	strb	w0, [x20]
    6c90:	17ffffd7 	b	6bec <fwp_free_zombie+0x7c>
    6c94:	f9400e61 	ldr	x1, [x19, #24]
    6c98:	97ffef4a 	bl	29c0 <munmap@plt>
    6c9c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ca0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ca4:	b5fff901 	cbnz	x1, 6bc4 <fwp_free_zombie+0x54>
    6ca8:	91014282 	add	x2, x20, #0x50
    6cac:	f901c040 	str	x0, [x2, #896]
    6cb0:	17ffffc6 	b	6bc8 <fwp_free_zombie+0x58>
    6cb4:	72003c3f 	tst	w1, #0xffff
    6cb8:	54fff9a1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6cbc:	17ffffed 	b	6c70 <fwp_free_zombie+0x100>
    6cc0:	ca544680 	eor	x0, x20, x20, lsr #17
    6cc4:	9118c084 	add	x4, x4, #0x630
    6cc8:	ca402400 	eor	x0, x0, x0, lsr #9
    6ccc:	92401c00 	and	x0, x0, #0xff
    6cd0:	910a2402 	add	x2, x0, #0x289
    6cd4:	8b000c80 	add	x0, x4, x0, lsl #3
    6cd8:	8b020c82 	add	x2, x4, x2, lsl #3
    6cdc:	f94a2400 	ldr	x0, [x0, #5192]
    6ce0:	b50000a0 	cbnz	x0, 6cf4 <fwp_free_zombie+0x184>
    6ce4:	14000013 	b	6d30 <fwp_free_zombie+0x1c0>
    6ce8:	91004002 	add	x2, x0, #0x10
    6cec:	f9400800 	ldr	x0, [x0, #16]
    6cf0:	b4000200 	cbz	x0, 6d30 <fwp_free_zombie+0x1c0>
    6cf4:	f9400001 	ldr	x1, [x0]
    6cf8:	eb14003f 	cmp	x1, x20
    6cfc:	54ffff61 	b.ne	6ce8 <fwp_free_zombie+0x178>  // b.any
    6d00:	f9400041 	ldr	x1, [x2]
    6d04:	f9400420 	ldr	x0, [x1, #8]
    6d08:	d1000400 	sub	x0, x0, #0x1
    6d0c:	f9000420 	str	x0, [x1, #8]
    6d10:	f103f81f 	cmp	x0, #0xfe
    6d14:	54fff6c1 	b.ne	6bec <fwp_free_zombie+0x7c>  // b.any
    6d18:	39400280 	ldrb	w0, [x20]
    6d1c:	7103fc1f 	cmp	w0, #0xff
    6d20:	540000e0 	b.eq	6d3c <fwp_free_zombie+0x1cc>  // b.none
    6d24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d28:	39000280 	strb	w0, [x20]
    6d2c:	17ffffb0 	b	6bec <fwp_free_zombie+0x7c>
    6d30:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6d34:	9118e000 	add	x0, x0, #0x638
    6d38:	97fff57f 	bl	4334 <fwp_trap>
    6d3c:	aa1403e0 	mov	x0, x20
    6d40:	97fff59d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6d44:	17fffff8 	b	6d24 <fwp_free_zombie+0x1b4>
    6d48:	d503201f 	nop
    6d4c:	d503201f 	nop

0000000000006d50 <fwp_block>:
    6d50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d54:	910003fd 	mov	x29, sp
    6d58:	a90153f3 	stp	x19, x20, [sp, #16]
    6d5c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6d60:	91014274 	add	x20, x19, #0x50
    6d64:	f9406682 	ldr	x2, [x20, #200]
    6d68:	b4000642 	cbz	x2, 6e30 <fwp_block+0xe0>
    6d6c:	91014261 	add	x1, x19, #0x50
    6d70:	f9408040 	ldr	x0, [x2, #256]
    6d74:	f9006420 	str	x0, [x1, #200]
    6d78:	b40006a0 	cbz	x0, 6e4c <fwp_block+0xfc>
    6d7c:	d503201f 	nop
    6d80:	91014263 	add	x3, x19, #0x50
    6d84:	3901505f 	strb	wzr, [x2, #84]
    6d88:	f9404c64 	ldr	x4, [x3, #152]
    6d8c:	eb02009f 	cmp	x4, x2
    6d90:	54000440 	b.eq	6e18 <fwp_block+0xc8>  // b.none
    6d94:	f941c465 	ldr	x5, [x3, #904]
    6d98:	f9004c62 	str	x2, [x3, #152]
    6d9c:	f9400441 	ldr	x1, [x2, #8]
    6da0:	f9004885 	str	x5, [x4, #144]
    6da4:	f941c865 	ldr	x5, [x3, #912]
    6da8:	f9004c85 	str	x5, [x4, #152]
    6dac:	f941cc65 	ldr	x5, [x3, #920]
    6db0:	f9005085 	str	x5, [x4, #160]
    6db4:	f941d065 	ldr	x5, [x3, #928]
    6db8:	f9005485 	str	x5, [x4, #168]
    6dbc:	f941d465 	ldr	x5, [x3, #936]
    6dc0:	f9005885 	str	x5, [x4, #176]
    6dc4:	f941d865 	ldr	x5, [x3, #944]
    6dc8:	f9005c85 	str	x5, [x4, #184]
    6dcc:	f941dc65 	ldr	x5, [x3, #952]
    6dd0:	f9006085 	str	x5, [x4, #192]
    6dd4:	f9400480 	ldr	x0, [x4, #8]
    6dd8:	f9404844 	ldr	x4, [x2, #144]
    6ddc:	f901c464 	str	x4, [x3, #904]
    6de0:	f9404c44 	ldr	x4, [x2, #152]
    6de4:	f901c864 	str	x4, [x3, #912]
    6de8:	f9405044 	ldr	x4, [x2, #160]
    6dec:	f901cc64 	str	x4, [x3, #920]
    6df0:	f9405444 	ldr	x4, [x2, #168]
    6df4:	f901d064 	str	x4, [x3, #928]
    6df8:	f9405844 	ldr	x4, [x2, #176]
    6dfc:	f901d464 	str	x4, [x3, #936]
    6e00:	a94b8844 	ldp	x4, x2, [x2, #184]
    6e04:	f901d864 	str	x4, [x3, #944]
    6e08:	f901dc62 	str	x2, [x3, #952]
    6e0c:	97ffeebd 	bl	2900 <swapcontext@plt>
    6e10:	97ffff58 	bl	6b70 <fwp_free_zombie>
    6e14:	d503201f 	nop
    6e18:	91014260 	add	x0, x19, #0x50
    6e1c:	b943c000 	ldr	w0, [x0, #960]
    6e20:	340001a0 	cbz	w0, 6e54 <fwp_block+0x104>
    6e24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e2c:	d65f03c0 	ret
    6e30:	97fff788 	bl	4c50 <fwp_poll_events>
    6e34:	f9406682 	ldr	x2, [x20, #200]
    6e38:	b4ffffc2 	cbz	x2, 6e30 <fwp_block+0xe0>
    6e3c:	91014261 	add	x1, x19, #0x50
    6e40:	f9408040 	ldr	x0, [x2, #256]
    6e44:	f9006420 	str	x0, [x1, #200]
    6e48:	b5fff9c0 	cbnz	x0, 6d80 <fwp_block+0x30>
    6e4c:	f900603f 	str	xzr, [x1, #192]
    6e50:	17ffffcc 	b	6d80 <fwp_block+0x30>
    6e54:	b0000020 	adrp	x0, b000 <__modti3+0xc0>
    6e58:	91234000 	add	x0, x0, #0x8d0
    6e5c:	97ffeef5 	bl	2a30 <getenv@plt>
    6e60:	5284e202 	mov	w2, #0x2710                	// #10000
    6e64:	b4000060 	cbz	x0, 6e70 <fwp_block+0x120>
    6e68:	39400001 	ldrb	w1, [x0]
    6e6c:	350000c1 	cbnz	w1, 6e84 <fwp_block+0x134>
    6e70:	91014273 	add	x19, x19, #0x50
    6e74:	b903c262 	str	w2, [x19, #960]
    6e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e80:	d65f03c0 	ret
    6e84:	52800142 	mov	w2, #0xa                   	// #10
    6e88:	d2800001 	mov	x1, #0x0                   	// #0
    6e8c:	97ffee39 	bl	2770 <strtoll@plt>
    6e90:	d1000403 	sub	x3, x0, #0x1
    6e94:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6e98:	eb02007f 	cmp	x3, x2
    6e9c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6ea0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6ea4:	17fffff3 	b	6e70 <fwp_block+0x120>
    6ea8:	d503201f 	nop
    6eac:	d503201f 	nop

0000000000006eb0 <fwp_drop10>:
    6eb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	a90153f3 	stp	x19, x20, [sp, #16]
    6ebc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6ec0:	f90013f5 	str	x21, [sp, #32]
    6ec4:	9118c275 	add	x21, x19, #0x630
    6ec8:	f949daa1 	ldr	x1, [x21, #5040]
    6ecc:	f949eea2 	ldr	x2, [x21, #5080]
    6ed0:	cb010001 	sub	x1, x0, x1
    6ed4:	eb02403f 	cmp	x1, x2, lsl #16
    6ed8:	54000382 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6edc:	d350fc22 	lsr	x2, x1, #16
    6ee0:	f949fea3 	ldr	x3, [x21, #5112]
    6ee4:	8b020842 	add	x2, x2, x2, lsl #2
    6ee8:	d37df042 	lsl	x2, x2, #3
    6eec:	8b020064 	add	x4, x3, x2
    6ef0:	f9401094 	ldr	x20, [x4, #32]
    6ef4:	b40002b4 	cbz	x20, 6f48 <fwp_drop10+0x98>
    6ef8:	38626862 	ldrb	w2, [x3, x2]
    6efc:	7100085f 	cmp	w2, #0x2
    6f00:	540007a0 	b.eq	6ff4 <fwp_drop10+0x144>  // b.none
    6f04:	7100045f 	cmp	w2, #0x1
    6f08:	54000201 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6f0c:	29430885 	ldp	w5, w2, [x4, #24]
    6f10:	92403c21 	and	x1, x1, #0xffff
    6f14:	9b057c21 	mul	x1, x1, x5
    6f18:	d360fc21 	lsr	x1, x1, #32
    6f1c:	eb02003f 	cmp	x1, x2
    6f20:	54000142 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f24:	8b010294 	add	x20, x20, x1
    6f28:	39400281 	ldrb	w1, [x20]
    6f2c:	340000e1 	cbz	w1, 6f48 <fwp_drop10+0x98>
    6f30:	7100043f 	cmp	w1, #0x1
    6f34:	54000120 	b.eq	6f58 <fwp_drop10+0xa8>  // b.none
    6f38:	7103fc3f 	cmp	w1, #0xff
    6f3c:	540007c0 	b.eq	7034 <fwp_drop10+0x184>  // b.none
    6f40:	51000421 	sub	w1, w1, #0x1
    6f44:	39000281 	strb	w1, [x20]
    6f48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f4c:	f94013f5 	ldr	x21, [sp, #32]
    6f50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f54:	d65f03c0 	ret
    6f58:	f9400001 	ldr	x1, [x0]
    6f5c:	b7f80581 	tbnz	x1, #63, 700c <fwp_drop10+0x15c>
    6f60:	9118c273 	add	x19, x19, #0x630
    6f64:	f949da61 	ldr	x1, [x19, #5040]
    6f68:	f949ee62 	ldr	x2, [x19, #5080]
    6f6c:	cb010001 	sub	x1, x0, x1
    6f70:	eb02403f 	cmp	x1, x2, lsl #16
    6f74:	54fffea2 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f78:	d350fc22 	lsr	x2, x1, #16
    6f7c:	8b020842 	add	x2, x2, x2, lsl #2
    6f80:	d37df042 	lsl	x2, x2, #3
    6f84:	8b020065 	add	x5, x3, x2
    6f88:	f94010a4 	ldr	x4, [x5, #32]
    6f8c:	b4fffde4 	cbz	x4, 6f48 <fwp_drop10+0x98>
    6f90:	38626862 	ldrb	w2, [x3, x2]
    6f94:	7100085f 	cmp	w2, #0x2
    6f98:	54000220 	b.eq	6fdc <fwp_drop10+0x12c>  // b.none
    6f9c:	7100045f 	cmp	w2, #0x1
    6fa0:	54fffd41 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6fa4:	294308a3 	ldp	w3, w2, [x5, #24]
    6fa8:	92403c21 	and	x1, x1, #0xffff
    6fac:	9b037c21 	mul	x1, x1, x3
    6fb0:	d360fc21 	lsr	x1, x1, #32
    6fb4:	eb02003f 	cmp	x1, x2
    6fb8:	54fffc82 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6fbc:	8b010084 	add	x4, x4, x1
    6fc0:	39400081 	ldrb	w1, [x4]
    6fc4:	7100043f 	cmp	w1, #0x1
    6fc8:	54fffc01 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    6fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fd0:	f94013f5 	ldr	x21, [sp, #32]
    6fd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6fd8:	17fff592 	b	4620 <fwp_mem_free>
    6fdc:	72003c3f 	tst	w1, #0xffff
    6fe0:	54ffff00 	b.eq	6fc0 <fwp_drop10+0x110>  // b.none
    6fe4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fe8:	f94013f5 	ldr	x21, [sp, #32]
    6fec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ff0:	d65f03c0 	ret
    6ff4:	72003c3f 	tst	w1, #0xffff
    6ff8:	54fff980 	b.eq	6f28 <fwp_drop10+0x78>  // b.none
    6ffc:	a94153f3 	ldp	x19, x20, [sp, #16]
    7000:	f94013f5 	ldr	x21, [sp, #32]
    7004:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7008:	d65f03c0 	ret
    700c:	f9400414 	ldr	x20, [x0, #8]
    7010:	97fffb1c 	bl	5c80 <fwp_rc_free_arr>
    7014:	9118c260 	add	x0, x19, #0x630
    7018:	f949d801 	ldr	x1, [x0, #5040]
    701c:	f949ec00 	ldr	x0, [x0, #5080]
    7020:	cb010281 	sub	x1, x20, x1
    7024:	eb00403f 	cmp	x1, x0, lsl #16
    7028:	54fff902 	b.cs	6f48 <fwp_drop10+0x98>  // b.hs, b.nlast
    702c:	aa1403e0 	mov	x0, x20
    7030:	17ffffab 	b	6edc <fwp_drop10+0x2c>
    7034:	ca544680 	eor	x0, x20, x20, lsr #17
    7038:	9118c273 	add	x19, x19, #0x630
    703c:	ca402400 	eor	x0, x0, x0, lsr #9
    7040:	92401c00 	and	x0, x0, #0xff
    7044:	910a2402 	add	x2, x0, #0x289
    7048:	8b000e60 	add	x0, x19, x0, lsl #3
    704c:	8b020e62 	add	x2, x19, x2, lsl #3
    7050:	f94a2400 	ldr	x0, [x0, #5192]
    7054:	b50000a0 	cbnz	x0, 7068 <fwp_drop10+0x1b8>
    7058:	14000013 	b	70a4 <fwp_drop10+0x1f4>
    705c:	91004002 	add	x2, x0, #0x10
    7060:	f9400800 	ldr	x0, [x0, #16]
    7064:	b4000200 	cbz	x0, 70a4 <fwp_drop10+0x1f4>
    7068:	f9400001 	ldr	x1, [x0]
    706c:	eb14003f 	cmp	x1, x20
    7070:	54ffff61 	b.ne	705c <fwp_drop10+0x1ac>  // b.any
    7074:	f9400041 	ldr	x1, [x2]
    7078:	f9400420 	ldr	x0, [x1, #8]
    707c:	d1000400 	sub	x0, x0, #0x1
    7080:	f9000420 	str	x0, [x1, #8]
    7084:	f103f81f 	cmp	x0, #0xfe
    7088:	54fff601 	b.ne	6f48 <fwp_drop10+0x98>  // b.any
    708c:	39400280 	ldrb	w0, [x20]
    7090:	7103fc1f 	cmp	w0, #0xff
    7094:	540000e0 	b.eq	70b0 <fwp_drop10+0x200>  // b.none
    7098:	12800020 	mov	w0, #0xfffffffe            	// #-2
    709c:	39000280 	strb	w0, [x20]
    70a0:	17ffffaa 	b	6f48 <fwp_drop10+0x98>
    70a4:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    70a8:	9118e000 	add	x0, x0, #0x638
    70ac:	97fff4a2 	bl	4334 <fwp_trap>
    70b0:	aa1403e0 	mov	x0, x20
    70b4:	97fff4c0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    70b8:	17fffff8 	b	7098 <fwp_drop10+0x1e8>
    70bc:	d503201f 	nop

00000000000070c0 <fwp_caps173>:
    70c0:	34000041 	cbz	w1, 70c8 <fwp_caps173+0x8>
    70c4:	d65f03c0 	ret
    70c8:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    70cc:	9118c063 	add	x3, x3, #0x630
    70d0:	f949d861 	ldr	x1, [x3, #5040]
    70d4:	f949ec62 	ldr	x2, [x3, #5080]
    70d8:	cb010001 	sub	x1, x0, x1
    70dc:	eb02403f 	cmp	x1, x2, lsl #16
    70e0:	54ffff22 	b.cs	70c4 <fwp_caps173+0x4>  // b.hs, b.nlast
    70e4:	d350fc22 	lsr	x2, x1, #16
    70e8:	f949fc65 	ldr	x5, [x3, #5112]
    70ec:	8b020842 	add	x2, x2, x2, lsl #2
    70f0:	d37df042 	lsl	x2, x2, #3
    70f4:	8b0200a4 	add	x4, x5, x2
    70f8:	f9401083 	ldr	x3, [x4, #32]
    70fc:	b4fffe43 	cbz	x3, 70c4 <fwp_caps173+0x4>
    7100:	386268a2 	ldrb	w2, [x5, x2]
    7104:	7100085f 	cmp	w2, #0x2
    7108:	540001c0 	b.eq	7140 <fwp_caps173+0x80>  // b.none
    710c:	7100045f 	cmp	w2, #0x1
    7110:	54fffda1 	b.ne	70c4 <fwp_caps173+0x4>  // b.any
    7114:	29430885 	ldp	w5, w2, [x4, #24]
    7118:	92403c21 	and	x1, x1, #0xffff
    711c:	9b057c21 	mul	x1, x1, x5
    7120:	d360fc21 	lsr	x1, x1, #32
    7124:	eb02003f 	cmp	x1, x2
    7128:	54fffce2 	b.cs	70c4 <fwp_caps173+0x4>  // b.hs, b.nlast
    712c:	8b010063 	add	x3, x3, x1
    7130:	39400061 	ldrb	w1, [x3]
    7134:	7100043f 	cmp	w1, #0x1
    7138:	54fffc61 	b.ne	70c4 <fwp_caps173+0x4>  // b.any
    713c:	17fff539 	b	4620 <fwp_mem_free>
    7140:	72003c3f 	tst	w1, #0xffff
    7144:	54ffff60 	b.eq	7130 <fwp_caps173+0x70>  // b.none
    7148:	d65f03c0 	ret
    714c:	d503201f 	nop

0000000000007150 <f37>:
    7150:	d10203ff 	sub	sp, sp, #0x80
    7154:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    7158:	f947f421 	ldr	x1, [x1, #4072]
    715c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7160:	910083fd 	add	x29, sp, #0x20
    7164:	a9045bf5 	stp	x21, x22, [sp, #64]
    7168:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    716c:	9118c2a3 	add	x3, x21, #0x630
    7170:	a90353f3 	stp	x19, x20, [sp, #48]
    7174:	aa0003f6 	mov	x22, x0
    7178:	a90563f7 	stp	x23, x24, [sp, #80]
    717c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7180:	f949ec62 	ldr	x2, [x3, #5080]
    7184:	f9400024 	ldr	x4, [x1]
    7188:	f9000fe4 	str	x4, [sp, #24]
    718c:	d2800004 	mov	x4, #0x0                   	// #0
    7190:	f949d861 	ldr	x1, [x3, #5040]
    7194:	d370bc42 	lsl	x2, x2, #16
    7198:	b4001920 	cbz	x0, 74bc <f37+0x36c>
    719c:	f9400817 	ldr	x23, [x0, #16]
    71a0:	cb0102e1 	sub	x1, x23, x1
    71a4:	eb02003f 	cmp	x1, x2
    71a8:	540003e2 	b.cs	7224 <f37+0xd4>  // b.hs, b.nlast
    71ac:	f949fc60 	ldr	x0, [x3, #5112]
    71b0:	d350fc22 	lsr	x2, x1, #16
    71b4:	8b020842 	add	x2, x2, x2, lsl #2
    71b8:	8b020c02 	add	x2, x0, x2, lsl #3
    71bc:	f9401040 	ldr	x0, [x2, #32]
    71c0:	b4000320 	cbz	x0, 7224 <f37+0xd4>
    71c4:	39400043 	ldrb	w3, [x2]
    71c8:	7100087f 	cmp	w3, #0x2
    71cc:	540015e0 	b.eq	7488 <f37+0x338>  // b.none
    71d0:	7100047f 	cmp	w3, #0x1
    71d4:	54000241 	b.ne	721c <f37+0xcc>  // b.any
    71d8:	29430843 	ldp	w3, w2, [x2, #24]
    71dc:	92403c21 	and	x1, x1, #0xffff
    71e0:	9b037c21 	mul	x1, x1, x3
    71e4:	d360fc21 	lsr	x1, x1, #32
    71e8:	eb02003f 	cmp	x1, x2
    71ec:	54000182 	b.cs	721c <f37+0xcc>  // b.hs, b.nlast
    71f0:	8b010000 	add	x0, x0, x1
    71f4:	39400001 	ldrb	w1, [x0]
    71f8:	34000121 	cbz	w1, 721c <f37+0xcc>
    71fc:	b00000c2 	adrp	x2, 20000 <__data_start>
    7200:	91014042 	add	x2, x2, #0x50
    7204:	b9413043 	ldr	w3, [x2, #304]
    7208:	35001463 	cbnz	w3, 7494 <f37+0x344>
    720c:	7103f43f 	cmp	w1, #0xfd
    7210:	54001888 	b.hi	7520 <f37+0x3d0>  // b.pmore
    7214:	11000421 	add	w1, w1, #0x1
    7218:	39000001 	strb	w1, [x0]
    721c:	d2800002 	mov	x2, #0x0                   	// #0
    7220:	b40000f6 	cbz	x22, 723c <f37+0xec>
    7224:	aa1603e1 	mov	x1, x22
    7228:	d2800002 	mov	x2, #0x0                   	// #0
    722c:	d503201f 	nop
    7230:	f9400821 	ldr	x1, [x1, #16]
    7234:	91000442 	add	x2, x2, #0x1
    7238:	b5ffffc1 	cbnz	x1, 7230 <f37+0xe0>
    723c:	b4001477 	cbz	x23, 74c8 <f37+0x378>
    7240:	aa1703e1 	mov	x1, x23
    7244:	d2800003 	mov	x3, #0x0                   	// #0
    7248:	f9400821 	ldr	x1, [x1, #16]
    724c:	91000463 	add	x3, x3, #0x1
    7250:	b5ffffc1 	cbnz	x1, 7248 <f37+0xf8>
    7254:	eb02007f 	cmp	x3, x2
    7258:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    725c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7260:	eb00027f 	cmp	x19, x0
    7264:	540010a8 	b.hi	7478 <f37+0x328>  // b.pmore
    7268:	d37ffa74 	lsl	x20, x19, #1
    726c:	52800041 	mov	w1, #0x2                   	// #2
    7270:	91000680 	add	x0, x20, #0x1
    7274:	d37df000 	lsl	x0, x0, #3
    7278:	97fff7a6 	bl	5110 <fwp_heap_alloc>
    727c:	aa0003f8 	mov	x24, x0
    7280:	9118c2a1 	add	x1, x21, #0x630
    7284:	aa0103e0 	mov	x0, x1
    7288:	f9000314 	str	x20, [x24]
    728c:	f949d821 	ldr	x1, [x1, #5040]
    7290:	f949ec00 	ldr	x0, [x0, #5080]
    7294:	cb010301 	sub	x1, x24, x1
    7298:	eb00403f 	cmp	x1, x0, lsl #16
    729c:	54000342 	b.cs	7304 <f37+0x1b4>  // b.hs, b.nlast
    72a0:	9118c2a2 	add	x2, x21, #0x630
    72a4:	d350fc20 	lsr	x0, x1, #16
    72a8:	8b000800 	add	x0, x0, x0, lsl #2
    72ac:	f949fc43 	ldr	x3, [x2, #5112]
    72b0:	d37df002 	lsl	x2, x0, #3
    72b4:	8b020060 	add	x0, x3, x2
    72b8:	f9401014 	ldr	x20, [x0, #32]
    72bc:	b4000254 	cbz	x20, 7304 <f37+0x1b4>
    72c0:	38626862 	ldrb	w2, [x3, x2]
    72c4:	7100085f 	cmp	w2, #0x2
    72c8:	54000ee0 	b.eq	74a4 <f37+0x354>  // b.none
    72cc:	7100045f 	cmp	w2, #0x1
    72d0:	540001a1 	b.ne	7304 <f37+0x1b4>  // b.any
    72d4:	29430002 	ldp	w2, w0, [x0, #24]
    72d8:	92403c21 	and	x1, x1, #0xffff
    72dc:	9b027c21 	mul	x1, x1, x2
    72e0:	d360fc21 	lsr	x1, x1, #32
    72e4:	eb00003f 	cmp	x1, x0
    72e8:	540000e2 	b.cs	7304 <f37+0x1b4>  // b.hs, b.nlast
    72ec:	8b010294 	add	x20, x20, x1
    72f0:	39400280 	ldrb	w0, [x20]
    72f4:	7103fc1f 	cmp	w0, #0xff
    72f8:	54001180 	b.eq	7528 <f37+0x3d8>  // b.none
    72fc:	52800020 	mov	w0, #0x1                   	// #1
    7300:	39000280 	strb	w0, [x20]
    7304:	b4000253 	cbz	x19, 734c <f37+0x1fc>
    7308:	8b131313 	add	x19, x24, x19, lsl #4
    730c:	aa1803f4 	mov	x20, x24
    7310:	aa1603fa 	mov	x26, x22
    7314:	aa1703f9 	mov	x25, x23
    7318:	f9400723 	ldr	x3, [x25, #8]
    731c:	f9400742 	ldr	x2, [x26, #8]
    7320:	f9400861 	ldr	x1, [x3, #16]
    7324:	f9400840 	ldr	x0, [x2, #16]
    7328:	fd400461 	ldr	d1, [x3, #8]
    732c:	fd400440 	ldr	d0, [x2, #8]
    7330:	97fff91d 	bl	57a4 <w120>
    7334:	f9000680 	str	x0, [x20, #8]
    7338:	f8010e81 	str	x1, [x20, #16]!
    733c:	f9400b39 	ldr	x25, [x25, #16]
    7340:	f9400b5a 	ldr	x26, [x26, #16]
    7344:	eb14027f 	cmp	x19, x20
    7348:	54fffe81 	b.ne	7318 <f37+0x1c8>  // b.any
    734c:	aa1703e0 	mov	x0, x23
    7350:	97fffd1c 	bl	67c0 <fwp_drop4>
    7354:	aa1603e0 	mov	x0, x22
    7358:	97fffd1a 	bl	67c0 <fwp_drop4>
    735c:	f9400316 	ldr	x22, [x24]
    7360:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7364:	b4000236 	cbz	x22, 73a8 <f37+0x258>
    7368:	fd003be8 	str	d8, [sp, #112]
    736c:	2f00e408 	movi	d8, #0x0
    7370:	91002319 	add	x25, x24, #0x8
    7374:	91004317 	add	x23, x24, #0x10
    7378:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    737c:	d2800013 	mov	x19, #0x0                   	// #0
    7380:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7384:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7388:	91000a73 	add	x19, x19, #0x2
    738c:	1e602908 	fadd	d8, d8, d0
    7390:	97fff8b4 	bl	5660 <f141.constprop.0>
    7394:	aa0003f4 	mov	x20, x0
    7398:	eb1302df 	cmp	x22, x19
    739c:	54ffff28 	b.hi	7380 <f37+0x230>  // b.pmore
    73a0:	9e660116 	fmov	x22, d8
    73a4:	fd403be8 	ldr	d8, [sp, #112]
    73a8:	9118c2b5 	add	x21, x21, #0x630
    73ac:	aa1803e0 	mov	x0, x24
    73b0:	97fffec0 	bl	6eb0 <fwp_drop10>
    73b4:	a900d3f6 	stp	x22, x20, [sp, #8]
    73b8:	910023e1 	add	x1, sp, #0x8
    73bc:	52800000 	mov	w0, #0x0                   	// #0
    73c0:	97fff7b8 	bl	52a0 <fwp_data.part.0.constprop.0>
    73c4:	f949daa1 	ldr	x1, [x21, #5040]
    73c8:	aa0003f3 	mov	x19, x0
    73cc:	f949eea0 	ldr	x0, [x21, #5080]
    73d0:	cb010261 	sub	x1, x19, x1
    73d4:	eb00403f 	cmp	x1, x0, lsl #16
    73d8:	54000322 	b.cs	743c <f37+0x2ec>  // b.hs, b.nlast
    73dc:	d350fc22 	lsr	x2, x1, #16
    73e0:	f949fea3 	ldr	x3, [x21, #5112]
    73e4:	8b020842 	add	x2, x2, x2, lsl #2
    73e8:	d37df042 	lsl	x2, x2, #3
    73ec:	8b020060 	add	x0, x3, x2
    73f0:	f9401014 	ldr	x20, [x0, #32]
    73f4:	b4000254 	cbz	x20, 743c <f37+0x2ec>
    73f8:	38626862 	ldrb	w2, [x3, x2]
    73fc:	7100085f 	cmp	w2, #0x2
    7400:	54000580 	b.eq	74b0 <f37+0x360>  // b.none
    7404:	7100045f 	cmp	w2, #0x1
    7408:	540001a1 	b.ne	743c <f37+0x2ec>  // b.any
    740c:	29430002 	ldp	w2, w0, [x0, #24]
    7410:	92403c21 	and	x1, x1, #0xffff
    7414:	9b027c21 	mul	x1, x1, x2
    7418:	d360fc21 	lsr	x1, x1, #32
    741c:	eb00003f 	cmp	x1, x0
    7420:	540000e2 	b.cs	743c <f37+0x2ec>  // b.hs, b.nlast
    7424:	8b010294 	add	x20, x20, x1
    7428:	39400280 	ldrb	w0, [x20]
    742c:	7103fc1f 	cmp	w0, #0xff
    7430:	54000820 	b.eq	7534 <f37+0x3e4>  // b.none
    7434:	52800020 	mov	w0, #0x1                   	// #1
    7438:	39000280 	strb	w0, [x20]
    743c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7440:	f947f400 	ldr	x0, [x0, #4072]
    7444:	f9400fe2 	ldr	x2, [sp, #24]
    7448:	f9400001 	ldr	x1, [x0]
    744c:	eb010042 	subs	x2, x2, x1
    7450:	d2800001 	mov	x1, #0x0                   	// #0
    7454:	540007a1 	b.ne	7548 <f37+0x3f8>  // b.any
    7458:	a9427bfd 	ldp	x29, x30, [sp, #32]
    745c:	aa1303e0 	mov	x0, x19
    7460:	a94353f3 	ldp	x19, x20, [sp, #48]
    7464:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7468:	a94563f7 	ldp	x23, x24, [sp, #80]
    746c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7470:	910203ff 	add	sp, sp, #0x80
    7474:	d65f03c0 	ret
    7478:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    747c:	91238000 	add	x0, x0, #0x8e0
    7480:	fd003be8 	str	d8, [sp, #112]
    7484:	97fff3ac 	bl	4334 <fwp_trap>
    7488:	72003c3f 	tst	w1, #0xffff
    748c:	54ffec81 	b.ne	721c <f37+0xcc>  // b.any
    7490:	17ffff59 	b	71f4 <f37+0xa4>
    7494:	f940ac43 	ldr	x3, [x2, #344]
    7498:	91000463 	add	x3, x3, #0x1
    749c:	f900ac43 	str	x3, [x2, #344]
    74a0:	17ffff5b 	b	720c <f37+0xbc>
    74a4:	72003c3f 	tst	w1, #0xffff
    74a8:	54fff2e1 	b.ne	7304 <f37+0x1b4>  // b.any
    74ac:	17ffff91 	b	72f0 <f37+0x1a0>
    74b0:	72003c3f 	tst	w1, #0xffff
    74b4:	54fffc41 	b.ne	743c <f37+0x2ec>  // b.any
    74b8:	17ffffdc 	b	7428 <f37+0x2d8>
    74bc:	cb0103e1 	neg	x1, x1
    74c0:	eb02003f 	cmp	x1, x2
    74c4:	540001e3 	b.cc	7500 <f37+0x3b0>  // b.lo, b.ul, b.last
    74c8:	52800041 	mov	w1, #0x2                   	// #2
    74cc:	d2800100 	mov	x0, #0x8                   	// #8
    74d0:	97fff710 	bl	5110 <fwp_heap_alloc>
    74d4:	aa0003f8 	mov	x24, x0
    74d8:	9118c2a0 	add	x0, x21, #0x630
    74dc:	f900031f 	str	xzr, [x24]
    74e0:	f949d801 	ldr	x1, [x0, #5040]
    74e4:	f949ec00 	ldr	x0, [x0, #5080]
    74e8:	cb010301 	sub	x1, x24, x1
    74ec:	eb00403f 	cmp	x1, x0, lsl #16
    74f0:	54000282 	b.cs	7540 <f37+0x3f0>  // b.hs, b.nlast
    74f4:	d2800013 	mov	x19, #0x0                   	// #0
    74f8:	d2800017 	mov	x23, #0x0                   	// #0
    74fc:	17ffff69 	b	72a0 <f37+0x150>
    7500:	f949fc62 	ldr	x2, [x3, #5112]
    7504:	d350fc20 	lsr	x0, x1, #16
    7508:	8b000800 	add	x0, x0, x0, lsl #2
    750c:	8b000c42 	add	x2, x2, x0, lsl #3
    7510:	f9401040 	ldr	x0, [x2, #32]
    7514:	b4fffda0 	cbz	x0, 74c8 <f37+0x378>
    7518:	d2800017 	mov	x23, #0x0                   	// #0
    751c:	17ffff2a 	b	71c4 <f37+0x74>
    7520:	97fff4b9 	bl	4804 <fwp_rc_wide_dup>
    7524:	17ffff3e 	b	721c <f37+0xcc>
    7528:	aa1403e0 	mov	x0, x20
    752c:	97fff3a2 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7530:	17ffff73 	b	72fc <f37+0x1ac>
    7534:	aa1403e0 	mov	x0, x20
    7538:	97fff39f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    753c:	17ffffbe 	b	7434 <f37+0x2e4>
    7540:	d2800017 	mov	x23, #0x0                   	// #0
    7544:	17ffff82 	b	734c <f37+0x1fc>
    7548:	fd003be8 	str	d8, [sp, #112]
    754c:	97ffecd5 	bl	28a0 <__stack_chk_fail@plt>

0000000000007550 <fwp_owned_entry37>:
    7550:	f9400000 	ldr	x0, [x0]
    7554:	17fffeff 	b	7150 <f37>
    7558:	d503201f 	nop
    755c:	d503201f 	nop

0000000000007560 <e37>:
    7560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7564:	910003fd 	mov	x29, sp
    7568:	f9000bf3 	str	x19, [sp, #16]
    756c:	f9400013 	ldr	x19, [x0]
    7570:	aa1303e0 	mov	x0, x19
    7574:	97fff99f 	bl	5bf0 <fwp_rc_share>
    7578:	aa1303e0 	mov	x0, x19
    757c:	97fffef5 	bl	7150 <f37>
    7580:	aa0003f3 	mov	x19, x0
    7584:	97fff99b 	bl	5bf0 <fwp_rc_share>
    7588:	aa1303e0 	mov	x0, x19
    758c:	f9400bf3 	ldr	x19, [sp, #16]
    7590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7594:	d65f03c0 	ret
    7598:	d503201f 	nop
    759c:	d503201f 	nop

00000000000075a0 <fwp_args37>:
    75a0:	7100003f 	cmp	w1, #0x0
    75a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    75a8:	54000041 	b.ne	75b0 <fwp_args37+0x10>  // b.any
    75ac:	d65f03c0 	ret
    75b0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    75b4:	9118c042 	add	x2, x2, #0x630
    75b8:	f9400001 	ldr	x1, [x0]
    75bc:	f949d843 	ldr	x3, [x2, #5040]
    75c0:	f949ec40 	ldr	x0, [x2, #5080]
    75c4:	cb030021 	sub	x1, x1, x3
    75c8:	eb00403f 	cmp	x1, x0, lsl #16
    75cc:	54ffff02 	b.cs	75ac <fwp_args37+0xc>  // b.hs, b.nlast
    75d0:	d350fc20 	lsr	x0, x1, #16
    75d4:	f949fc44 	ldr	x4, [x2, #5112]
    75d8:	8b000800 	add	x0, x0, x0, lsl #2
    75dc:	d37df002 	lsl	x2, x0, #3
    75e0:	8b020083 	add	x3, x4, x2
    75e4:	f9401060 	ldr	x0, [x3, #32]
    75e8:	b4fffe20 	cbz	x0, 75ac <fwp_args37+0xc>
    75ec:	38626882 	ldrb	w2, [x4, x2]
    75f0:	7100085f 	cmp	w2, #0x2
    75f4:	54000320 	b.eq	7658 <fwp_args37+0xb8>  // b.none
    75f8:	7100045f 	cmp	w2, #0x1
    75fc:	54fffd81 	b.ne	75ac <fwp_args37+0xc>  // b.any
    7600:	29430864 	ldp	w4, w2, [x3, #24]
    7604:	92403c21 	and	x1, x1, #0xffff
    7608:	9b047c21 	mul	x1, x1, x4
    760c:	d360fc21 	lsr	x1, x1, #32
    7610:	eb02003f 	cmp	x1, x2
    7614:	54fffcc2 	b.cs	75ac <fwp_args37+0xc>  // b.hs, b.nlast
    7618:	8b010000 	add	x0, x0, x1
    761c:	39400001 	ldrb	w1, [x0]
    7620:	34fffc61 	cbz	w1, 75ac <fwp_args37+0xc>
    7624:	b00000c2 	adrp	x2, 20000 <__data_start>
    7628:	91014042 	add	x2, x2, #0x50
    762c:	b9413043 	ldr	w3, [x2, #304]
    7630:	350000c3 	cbnz	w3, 7648 <fwp_args37+0xa8>
    7634:	7103f43f 	cmp	w1, #0xfd
    7638:	54000168 	b.hi	7664 <fwp_args37+0xc4>  // b.pmore
    763c:	11000421 	add	w1, w1, #0x1
    7640:	39000001 	strb	w1, [x0]
    7644:	d65f03c0 	ret
    7648:	f940ac43 	ldr	x3, [x2, #344]
    764c:	91000463 	add	x3, x3, #0x1
    7650:	f900ac43 	str	x3, [x2, #344]
    7654:	17fffff8 	b	7634 <fwp_args37+0x94>
    7658:	72003c3f 	tst	w1, #0xffff
    765c:	54fffe00 	b.eq	761c <fwp_args37+0x7c>  // b.none
    7660:	d65f03c0 	ret
    7664:	17fff468 	b	4804 <fwp_rc_wide_dup>
    7668:	d503201f 	nop
    766c:	d503201f 	nop

0000000000007670 <fwp_caps37>:
    7670:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7674:	910003fd 	mov	x29, sp
    7678:	f9000bf3 	str	x19, [sp, #16]
    767c:	aa0003f3 	mov	x19, x0
    7680:	b9400400 	ldr	w0, [x0, #4]
    7684:	340004a0 	cbz	w0, 7718 <fwp_caps37+0xa8>
    7688:	f9400660 	ldr	x0, [x19, #8]
    768c:	350004e1 	cbnz	w1, 7728 <fwp_caps37+0xb8>
    7690:	97fffc4c 	bl	67c0 <fwp_drop4>
    7694:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    7698:	9118c042 	add	x2, x2, #0x630
    769c:	f949d840 	ldr	x0, [x2, #5040]
    76a0:	f949ec41 	ldr	x1, [x2, #5080]
    76a4:	cb000260 	sub	x0, x19, x0
    76a8:	eb01401f 	cmp	x0, x1, lsl #16
    76ac:	54000382 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    76b0:	d350fc01 	lsr	x1, x0, #16
    76b4:	f949fc44 	ldr	x4, [x2, #5112]
    76b8:	8b010821 	add	x1, x1, x1, lsl #2
    76bc:	d37df021 	lsl	x1, x1, #3
    76c0:	8b010083 	add	x3, x4, x1
    76c4:	f9401062 	ldr	x2, [x3, #32]
    76c8:	b40002a2 	cbz	x2, 771c <fwp_caps37+0xac>
    76cc:	38616881 	ldrb	w1, [x4, x1]
    76d0:	7100083f 	cmp	w1, #0x2
    76d4:	54000740 	b.eq	77bc <fwp_caps37+0x14c>  // b.none
    76d8:	7100043f 	cmp	w1, #0x1
    76dc:	54000201 	b.ne	771c <fwp_caps37+0xac>  // b.any
    76e0:	29430464 	ldp	w4, w1, [x3, #24]
    76e4:	92403c00 	and	x0, x0, #0xffff
    76e8:	9b047c00 	mul	x0, x0, x4
    76ec:	d360fc00 	lsr	x0, x0, #32
    76f0:	eb01001f 	cmp	x0, x1
    76f4:	54000142 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    76f8:	8b000042 	add	x2, x2, x0
    76fc:	39400040 	ldrb	w0, [x2]
    7700:	7100041f 	cmp	w0, #0x1
    7704:	540000c1 	b.ne	771c <fwp_caps37+0xac>  // b.any
    7708:	aa1303e0 	mov	x0, x19
    770c:	f9400bf3 	ldr	x19, [sp, #16]
    7710:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7714:	17fff3c3 	b	4620 <fwp_mem_free>
    7718:	34fffbe1 	cbz	w1, 7694 <fwp_caps37+0x24>
    771c:	f9400bf3 	ldr	x19, [sp, #16]
    7720:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7724:	d65f03c0 	ret
    7728:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    772c:	9118c042 	add	x2, x2, #0x630
    7730:	f949d843 	ldr	x3, [x2, #5040]
    7734:	f949ec41 	ldr	x1, [x2, #5080]
    7738:	cb030000 	sub	x0, x0, x3
    773c:	eb01401f 	cmp	x0, x1, lsl #16
    7740:	54fffee2 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    7744:	d350fc01 	lsr	x1, x0, #16
    7748:	f949fc44 	ldr	x4, [x2, #5112]
    774c:	8b010821 	add	x1, x1, x1, lsl #2
    7750:	d37df021 	lsl	x1, x1, #3
    7754:	8b010083 	add	x3, x4, x1
    7758:	f9401062 	ldr	x2, [x3, #32]
    775c:	b4fffe02 	cbz	x2, 771c <fwp_caps37+0xac>
    7760:	38616881 	ldrb	w1, [x4, x1]
    7764:	7100083f 	cmp	w1, #0x2
    7768:	54000300 	b.eq	77c8 <fwp_caps37+0x158>  // b.none
    776c:	7100043f 	cmp	w1, #0x1
    7770:	54fffd61 	b.ne	771c <fwp_caps37+0xac>  // b.any
    7774:	92403c01 	and	x1, x0, #0xffff
    7778:	29430064 	ldp	w4, w0, [x3, #24]
    777c:	9b047c21 	mul	x1, x1, x4
    7780:	d360fc21 	lsr	x1, x1, #32
    7784:	eb00003f 	cmp	x1, x0
    7788:	54fffca2 	b.cs	771c <fwp_caps37+0xac>  // b.hs, b.nlast
    778c:	8b010042 	add	x2, x2, x1
    7790:	39400040 	ldrb	w0, [x2]
    7794:	34fffc40 	cbz	w0, 771c <fwp_caps37+0xac>
    7798:	b00000c1 	adrp	x1, 20000 <__data_start>
    779c:	91014021 	add	x1, x1, #0x50
    77a0:	b9413023 	ldr	w3, [x1, #304]
    77a4:	35000183 	cbnz	w3, 77d4 <fwp_caps37+0x164>
    77a8:	7103f41f 	cmp	w0, #0xfd
    77ac:	540001c8 	b.hi	77e4 <fwp_caps37+0x174>  // b.pmore
    77b0:	11000400 	add	w0, w0, #0x1
    77b4:	39000040 	strb	w0, [x2]
    77b8:	17ffffd9 	b	771c <fwp_caps37+0xac>
    77bc:	72003c1f 	tst	w0, #0xffff
    77c0:	54fffae1 	b.ne	771c <fwp_caps37+0xac>  // b.any
    77c4:	17ffffce 	b	76fc <fwp_caps37+0x8c>
    77c8:	72003c1f 	tst	w0, #0xffff
    77cc:	54fffa81 	b.ne	771c <fwp_caps37+0xac>  // b.any
    77d0:	17fffff0 	b	7790 <fwp_caps37+0x120>
    77d4:	f940ac23 	ldr	x3, [x1, #344]
    77d8:	91000463 	add	x3, x3, #0x1
    77dc:	f900ac23 	str	x3, [x1, #344]
    77e0:	17fffff2 	b	77a8 <fwp_caps37+0x138>
    77e4:	f9400bf3 	ldr	x19, [sp, #16]
    77e8:	aa0203e0 	mov	x0, x2
    77ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    77f0:	17fff405 	b	4804 <fwp_rc_wide_dup>

00000000000077f4 <fwp_write>:
    77f4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    77f8:	910003fd 	mov	x29, sp
    77fc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7800:	f947f484 	ldr	x4, [x4, #4072]
    7804:	a90153f3 	stp	x19, x20, [sp, #16]
    7808:	d10943ff 	sub	sp, sp, #0x250
    780c:	b9400045 	ldr	w5, [x2]
    7810:	aa0003f4 	mov	x20, x0
    7814:	f9400080 	ldr	x0, [x4]
    7818:	f90127e0 	str	x0, [sp, #584]
    781c:	d2800000 	mov	x0, #0x0                   	// #0
    7820:	710064bf 	cmp	w5, #0x19
    7824:	54000408 	b.hi	78a4 <fwp_write+0xb0>  // b.pmore
    7828:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xd20>
    782c:	aa0103f3 	mov	x19, x1
    7830:	9108c000 	add	x0, x0, #0x230
    7834:	f9013bf5 	str	x21, [sp, #624]
    7838:	f9013ff6 	str	x22, [sp, #632]
    783c:	f90153fb 	str	x27, [sp, #672]
    7840:	f90157fc 	str	x28, [sp, #680]
    7844:	aa0203fc 	mov	x28, x2
    7848:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    784c:	10000061 	adr	x1, 7858 <fwp_write+0x64>
    7850:	8b20a820 	add	x0, x1, w0, sxth #2
    7854:	d61f0000 	br	x0
    7858:	910123e0 	add	x0, sp, #0x48
    785c:	aa1303e5 	mov	x5, x19
    7860:	90000024 	adrp	x4, b000 <__modti3+0xc0>
    7864:	aa0003f3 	mov	x19, x0
    7868:	9124a084 	add	x4, x4, #0x928
    786c:	d2804003 	mov	x3, #0x200                 	// #512
    7870:	aa0303e1 	mov	x1, x3
    7874:	52800042 	mov	w2, #0x2                   	// #2
    7878:	97ffebe6 	bl	2810 <__snprintf_chk@plt>
    787c:	aa1303e0 	mov	x0, x19
    7880:	97ffebac 	bl	2730 <strlen@plt>
    7884:	aa1303e1 	mov	x1, x19
    7888:	aa0003e2 	mov	x2, x0
    788c:	aa1403e0 	mov	x0, x20
    7890:	97ffef80 	bl	3690 <buf_put>
    7894:	f9413bf5 	ldr	x21, [sp, #624]
    7898:	f9413ff6 	ldr	x22, [sp, #632]
    789c:	f94153fb 	ldr	x27, [sp, #672]
    78a0:	f94157fc 	ldr	x28, [sp, #680]
    78a4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    78a8:	f947f400 	ldr	x0, [x0, #4072]
    78ac:	f94127e2 	ldr	x2, [sp, #584]
    78b0:	f9400001 	ldr	x1, [x0]
    78b4:	eb010042 	subs	x2, x2, x1
    78b8:	d2800001 	mov	x1, #0x0                   	// #0
    78bc:	540077a1 	b.ne	87b0 <fwp_write+0xfbc>  // b.any
    78c0:	910943ff 	add	sp, sp, #0x250
    78c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    78c8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    78cc:	d65f03c0 	ret
    78d0:	910123e0 	add	x0, sp, #0x48
    78d4:	aa1303e5 	mov	x5, x19
    78d8:	90000024 	adrp	x4, b000 <__modti3+0xc0>
    78dc:	aa0003f3 	mov	x19, x0
    78e0:	91248084 	add	x4, x4, #0x920
    78e4:	d2804003 	mov	x3, #0x200                 	// #512
    78e8:	17ffffe2 	b	7870 <fwp_write+0x7c>
    78ec:	71004cbf 	cmp	w5, #0x13
    78f0:	90000020 	adrp	x0, b000 <__modti3+0xc0>
    78f4:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    78f8:	91244000 	add	x0, x0, #0x910
    78fc:	91246021 	add	x1, x1, #0x918
    7900:	d2800082 	mov	x2, #0x4                   	// #4
    7904:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7908:	aa1403e0 	mov	x0, x20
    790c:	f90143f7 	str	x23, [sp, #640]
    7910:	d2800016 	mov	x22, #0x0                   	// #0
    7914:	f90147f8 	str	x24, [sp, #648]
    7918:	97ffef5e 	bl	3690 <buf_put>
    791c:	f9400260 	ldr	x0, [x19]
    7920:	90000037 	adrp	x23, b000 <__modti3+0xc0>
    7924:	d2800015 	mov	x21, #0x0                   	// #0
    7928:	912662f7 	add	x23, x23, #0x998
    792c:	b4004780 	cbz	x0, 821c <fwp_write+0xa28>
    7930:	b9400380 	ldr	w0, [x28]
    7934:	52800003 	mov	w3, #0x0                   	// #0
    7938:	f9401f82 	ldr	x2, [x28, #56]
    793c:	71004c1f 	cmp	w0, #0x13
    7940:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7944:	aa1403e0 	mov	x0, x20
    7948:	8b010e61 	add	x1, x19, x1, lsl #3
    794c:	f9400421 	ldr	x1, [x1, #8]
    7950:	97ffffa9 	bl	77f4 <fwp_write>
    7954:	b9400380 	ldr	w0, [x28]
    7958:	7100481f 	cmp	w0, #0x12
    795c:	54004b20 	b.eq	82c0 <fwp_write+0xacc>  // b.none
    7960:	f9400260 	ldr	x0, [x19]
    7964:	910006b5 	add	x21, x21, #0x1
    7968:	91000ad6 	add	x22, x22, #0x2
    796c:	eb15001f 	cmp	x0, x21
    7970:	54004569 	b.ls	821c <fwp_write+0xa28>  // b.plast
    7974:	aa1703e1 	mov	x1, x23
    7978:	aa1403e0 	mov	x0, x20
    797c:	d2800042 	mov	x2, #0x2                   	// #2
    7980:	97ffef44 	bl	3690 <buf_put>
    7984:	17ffffeb 	b	7930 <fwp_write+0x13c>
    7988:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    798c:	91254021 	add	x1, x1, #0x950
    7990:	d28000c2 	mov	x2, #0x6                   	// #6
    7994:	aa1403e0 	mov	x0, x20
    7998:	91004273 	add	x19, x19, #0x10
    799c:	97ffef3d 	bl	3690 <buf_put>
    79a0:	aa1303e0 	mov	x0, x19
    79a4:	97ffeb63 	bl	2730 <strlen@plt>
    79a8:	aa1303e1 	mov	x1, x19
    79ac:	aa0003e2 	mov	x2, x0
    79b0:	aa1403e0 	mov	x0, x20
    79b4:	97ffef37 	bl	3690 <buf_put>
    79b8:	528007c3 	mov	w3, #0x3e                  	// #62
    79bc:	aa1403e0 	mov	x0, x20
    79c0:	91001fe1 	add	x1, sp, #0x7
    79c4:	d2800022 	mov	x2, #0x1                   	// #1
    79c8:	39001fe3 	strb	w3, [sp, #7]
    79cc:	17ffffb1 	b	7890 <fwp_write+0x9c>
    79d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    79d4:	f947f400 	ldr	x0, [x0, #4072]
    79d8:	f94127e2 	ldr	x2, [sp, #584]
    79dc:	f9400001 	ldr	x1, [x0]
    79e0:	eb010042 	subs	x2, x2, x1
    79e4:	d2800001 	mov	x1, #0x0                   	// #0
    79e8:	540034c1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    79ec:	f9413bf5 	ldr	x21, [sp, #624]
    79f0:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    79f4:	f9413ff6 	ldr	x22, [sp, #632]
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	9124c021 	add	x1, x1, #0x930
    7a00:	d2800142 	mov	x2, #0xa                   	// #10
    7a04:	f94153fb 	ldr	x27, [sp, #672]
    7a08:	f94157fc 	ldr	x28, [sp, #680]
    7a0c:	910943ff 	add	sp, sp, #0x250
    7a10:	a94153f3 	ldp	x19, x20, [sp, #16]
    7a14:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7a18:	17ffef1e 	b	3690 <buf_put>
    7a1c:	f9400456 	ldr	x22, [x2, #8]
    7a20:	f90143f7 	str	x23, [sp, #640]
    7a24:	f90147f8 	str	x24, [sp, #648]
    7a28:	b4005af6 	cbz	x22, 8584 <fwp_write+0xd90>
    7a2c:	aa1603e0 	mov	x0, x22
    7a30:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    7a34:	9126c021 	add	x1, x1, #0x9b0
    7a38:	97ffebba 	bl	2920 <strcmp@plt>
    7a3c:	2a0003f5 	mov	w21, w0
    7a40:	34005fc0 	cbz	w0, 8638 <fwp_write+0xe44>
    7a44:	aa1603e0 	mov	x0, x22
    7a48:	97ffeb3a 	bl	2730 <strlen@plt>
    7a4c:	aa1603e1 	mov	x1, x22
    7a50:	aa0003e2 	mov	x2, x0
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	97ffef0e 	bl	3690 <buf_put>
    7a5c:	52800403 	mov	w3, #0x20                  	// #32
    7a60:	91001ff5 	add	x21, sp, #0x7
    7a64:	aa1503e1 	mov	x1, x21
    7a68:	aa1403e0 	mov	x0, x20
    7a6c:	d2800022 	mov	x2, #0x1                   	// #1
    7a70:	39001fe3 	strb	w3, [sp, #7]
    7a74:	97ffef07 	bl	3690 <buf_put>
    7a78:	52800f63 	mov	w3, #0x7b                  	// #123
    7a7c:	aa1403e0 	mov	x0, x20
    7a80:	aa1503e1 	mov	x1, x21
    7a84:	d2800022 	mov	x2, #0x1                   	// #1
    7a88:	39001fe3 	strb	w3, [sp, #7]
    7a8c:	97ffef01 	bl	3690 <buf_put>
    7a90:	b9401380 	ldr	w0, [x28, #16]
    7a94:	52800018 	mov	w24, #0x0                   	// #0
    7a98:	7100001f 	cmp	w0, #0x0
    7a9c:	54003a8d 	b.le	81ec <fwp_write+0x9f8>
    7aa0:	f9014bf9 	str	x25, [sp, #656]
    7aa4:	90000039 	adrp	x25, b000 <__modti3+0xc0>
    7aa8:	91276339 	add	x25, x25, #0x9d8
    7aac:	f9014ffa 	str	x26, [sp, #664]
    7ab0:	9000003a 	adrp	x26, b000 <__modti3+0xc0>
    7ab4:	9126635a 	add	x26, x26, #0x998
    7ab8:	91002276 	add	x22, x19, #0x8
    7abc:	d2800013 	mov	x19, #0x0                   	// #0
    7ac0:	b5003e73 	cbnz	x19, 828c <fwp_write+0xa98>
    7ac4:	d37df277 	lsl	x23, x19, #3
    7ac8:	34003c98 	cbz	w24, 8258 <fwp_write+0xa64>
    7acc:	f9401382 	ldr	x2, [x28, #32]
    7ad0:	aa1403e0 	mov	x0, x20
    7ad4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7ad8:	52800003 	mov	w3, #0x0                   	// #0
    7adc:	f8776842 	ldr	x2, [x2, x23]
    7ae0:	91000673 	add	x19, x19, #0x1
    7ae4:	97ffff44 	bl	77f4 <fwp_write>
    7ae8:	b9401380 	ldr	w0, [x28, #16]
    7aec:	6b13001f 	cmp	w0, w19
    7af0:	54fffe8c 	b.gt	7ac0 <fwp_write+0x2cc>
    7af4:	f9414bf9 	ldr	x25, [sp, #656]
    7af8:	f9414ffa 	ldr	x26, [sp, #664]
    7afc:	34003798 	cbz	w24, 81ec <fwp_write+0x9f8>
    7b00:	52800523 	mov	w3, #0x29                  	// #41
    7b04:	aa1503e1 	mov	x1, x21
    7b08:	aa1403e0 	mov	x0, x20
    7b0c:	d2800022 	mov	x2, #0x1                   	// #1
    7b10:	39001fe3 	strb	w3, [sp, #7]
    7b14:	97ffeedf 	bl	3690 <buf_put>
    7b18:	f9413bf5 	ldr	x21, [sp, #624]
    7b1c:	f9413ff6 	ldr	x22, [sp, #632]
    7b20:	f94143f7 	ldr	x23, [sp, #640]
    7b24:	f94147f8 	ldr	x24, [sp, #648]
    7b28:	f94153fb 	ldr	x27, [sp, #672]
    7b2c:	f94157fc 	ldr	x28, [sp, #680]
    7b30:	17ffff5d 	b	78a4 <fwp_write+0xb0>
    7b34:	b9404855 	ldr	w21, [x2, #72]
    7b38:	aa1403e0 	mov	x0, x20
    7b3c:	93407eb6 	sxtw	x22, w21
    7b40:	91000ac1 	add	x1, x22, #0x2
    7b44:	97ffee9f 	bl	35c0 <buf_grow>
    7b48:	a9400281 	ldp	x1, x0, [x20]
    7b4c:	528e8603 	mov	w3, #0x7430                	// #29744
    7b50:	78206823 	strh	w3, [x1, x0]
    7b54:	8b000022 	add	x2, x1, x0
    7b58:	710002bf 	cmp	w21, #0x0
    7b5c:	540036ad 	b.le	8230 <fwp_write+0xa3c>
    7b60:	110006a3 	add	w3, w21, #0x1
    7b64:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7b68:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7b6c:	91000449 	add	x9, x2, #0x1
    7b70:	8b23c043 	add	x3, x2, w3, sxtw
    7b74:	f28aaac6 	movk	x6, #0x5556
    7b78:	f2955568 	movk	x8, #0xaaab
    7b7c:	1400000d 	b	7bb0 <fwp_write+0x3bc>
    7b80:	d2800021 	mov	x1, #0x1                   	// #1
    7b84:	528005a5 	mov	w5, #0x2d                  	// #45
    7b88:	f100001f 	cmp	x0, #0x0
    7b8c:	9b467e60 	smulh	x0, x19, x6
    7b90:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7b94:	381ff465 	strb	w5, [x3], #-1
    7b98:	cb040000 	sub	x0, x0, x4
    7b9c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7ba0:	cb020000 	sub	x0, x0, x2
    7ba4:	8b010013 	add	x19, x0, x1
    7ba8:	eb03013f 	cmp	x9, x3
    7bac:	54003420 	b.eq	8230 <fwp_write+0xa3c>  // b.none
    7bb0:	9b467e60 	smulh	x0, x19, x6
    7bb4:	937ffe64 	asr	x4, x19, #63
    7bb8:	52800605 	mov	w5, #0x30                  	// #48
    7bbc:	cb040000 	sub	x0, x0, x4
    7bc0:	8b000400 	add	x0, x0, x0, lsl #1
    7bc4:	cb000260 	sub	x0, x19, x0
    7bc8:	91000c01 	add	x1, x0, #0x3
    7bcc:	9bc87c22 	umulh	x2, x1, x8
    7bd0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7bd4:	8b4204e2 	add	x2, x7, x2, lsr #1
    7bd8:	eb020021 	subs	x1, x1, x2
    7bdc:	54fffd60 	b.eq	7b88 <fwp_write+0x394>  // b.none
    7be0:	f100043f 	cmp	x1, #0x1
    7be4:	54fffce1 	b.ne	7b80 <fwp_write+0x38c>  // b.any
    7be8:	d2800001 	mov	x1, #0x0                   	// #0
    7bec:	52800565 	mov	w5, #0x2b                  	// #43
    7bf0:	17ffffe6 	b	7b88 <fwp_write+0x394>
    7bf4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7bf8:	f947f400 	ldr	x0, [x0, #4072]
    7bfc:	f94127e2 	ldr	x2, [sp, #584]
    7c00:	f9400001 	ldr	x1, [x0]
    7c04:	eb010042 	subs	x2, x2, x1
    7c08:	d2800001 	mov	x1, #0x0                   	// #0
    7c0c:	540023a1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    7c10:	f9413bf5 	ldr	x21, [sp, #624]
    7c14:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    7c18:	f9413ff6 	ldr	x22, [sp, #632]
    7c1c:	aa1403e0 	mov	x0, x20
    7c20:	91250021 	add	x1, x1, #0x940
    7c24:	d2800102 	mov	x2, #0x8                   	// #8
    7c28:	17ffff77 	b	7a04 <fwp_write+0x210>
    7c2c:	aa1403e0 	mov	x0, x20
    7c30:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    7c34:	d28000c2 	mov	x2, #0x6                   	// #6
    7c38:	91268021 	add	x1, x1, #0x9a0
    7c3c:	97ffee95 	bl	3690 <buf_put>
    7c40:	d2800015 	mov	x21, #0x0                   	// #0
    7c44:	f9400263 	ldr	x3, [x19]
    7c48:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7c4c:	54002c40 	b.eq	81d4 <fwp_write+0x9e0>  // b.none
    7c50:	f9401f82 	ldr	x2, [x28, #56]
    7c54:	f90143f7 	str	x23, [sp, #640]
    7c58:	f90147f8 	str	x24, [sp, #648]
    7c5c:	d2800857 	mov	x23, #0x42                  	// #66
    7c60:	f9014bf9 	str	x25, [sp, #656]
    7c64:	90000036 	adrp	x22, b000 <__modti3+0xc0>
    7c68:	f9014ffa 	str	x26, [sp, #664]
    7c6c:	912662d6 	add	x22, x22, #0x998
    7c70:	d2800038 	mov	x24, #0x1                   	// #1
    7c74:	f2a18017 	movk	x23, #0xc00, lsl #16
    7c78:	d2809099 	mov	x25, #0x484                 	// #1156
    7c7c:	b4000482 	cbz	x2, 7d0c <fwp_write+0x518>
    7c80:	b9400040 	ldr	w0, [x2]
    7c84:	7100701f 	cmp	w0, #0x1c
    7c88:	540042a0 	b.eq	84dc <fwp_write+0xce8>  // b.none
    7c8c:	71006c1f 	cmp	w0, #0x1b
    7c90:	540003e8 	b.hi	7d0c <fwp_write+0x518>  // b.pmore
    7c94:	9ac02301 	lsl	x1, x24, x0
    7c98:	ea17003f 	tst	x1, x23
    7c9c:	54003681 	b.ne	836c <fwp_write+0xb78>  // b.any
    7ca0:	ea19003f 	tst	x1, x25
    7ca4:	54003501 	b.ne	8344 <fwp_write+0xb50>  // b.any
    7ca8:	d2800424 	mov	x4, #0x21                  	// #33
    7cac:	ea04003f 	tst	x1, x4
    7cb0:	540002e0 	b.eq	7d0c <fwp_write+0x518>  // b.none
    7cb4:	b7f849a3 	tbnz	x3, #63, 85e8 <fwp_write+0xdf4>
    7cb8:	91002261 	add	x1, x19, #0x8
    7cbc:	8b150021 	add	x1, x1, x21
    7cc0:	39400021 	ldrb	w1, [x1]
    7cc4:	7100001f 	cmp	w0, #0x0
    7cc8:	93401c23 	sxtb	x3, w1
    7ccc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7cd0:	aa1403e0 	mov	x0, x20
    7cd4:	52800003 	mov	w3, #0x0                   	// #0
    7cd8:	97fffec7 	bl	77f4 <fwp_write>
    7cdc:	910006b5 	add	x21, x21, #0x1
    7ce0:	f9400260 	ldr	x0, [x19]
    7ce4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7ce8:	eb0002bf 	cmp	x21, x0
    7cec:	540026c2 	b.cs	81c4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7cf0:	d2800042 	mov	x2, #0x2                   	// #2
    7cf4:	aa1603e1 	mov	x1, x22
    7cf8:	aa1403e0 	mov	x0, x20
    7cfc:	97ffee65 	bl	3690 <buf_put>
    7d00:	f9401f82 	ldr	x2, [x28, #56]
    7d04:	f9400263 	ldr	x3, [x19]
    7d08:	b5fffbc2 	cbnz	x2, 7c80 <fwp_write+0x48c>
    7d0c:	d37df2a0 	lsl	x0, x21, #3
    7d10:	b7f83f03 	tbnz	x3, #63, 84f0 <fwp_write+0xcfc>
    7d14:	91002261 	add	x1, x19, #0x8
    7d18:	8b000020 	add	x0, x1, x0
    7d1c:	f9400001 	ldr	x1, [x0]
    7d20:	17ffffec 	b	7cd0 <fwp_write+0x4dc>
    7d24:	a9400e62 	ldp	x2, x3, [x19]
    7d28:	b7f83ca3 	tbnz	x3, #63, 84bc <fwp_write+0xcc8>
    7d2c:	910123f5 	add	x21, sp, #0x48
    7d30:	aa1503e0 	mov	x0, x21
    7d34:	97ffec3b 	bl	2e20 <fwp_fmt_u128>
    7d38:	aa1503e0 	mov	x0, x21
    7d3c:	97ffea7d 	bl	2730 <strlen@plt>
    7d40:	aa1503e1 	mov	x1, x21
    7d44:	aa0003e2 	mov	x2, x0
    7d48:	17fffed1 	b	788c <fwp_write+0x98>
    7d4c:	fd015be8 	str	d8, [sp, #688]
    7d50:	1e270268 	fmov	s8, w19
    7d54:	fd015fe9 	str	d9, [sp, #696]
    7d58:	1e282100 	fcmp	s8, s8
    7d5c:	54004d26 	b.vs	8700 <fwp_write+0xf0c>
    7d60:	1e20c101 	fabs	s1, s8
    7d64:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7d68:	1e270000 	fmov	s0, w0
    7d6c:	1e202020 	fcmp	s1, s0
    7d70:	54002c0d 	b.le	82f0 <fwp_write+0xafc>
    7d74:	1e202118 	fcmpe	s8, #0.0
    7d78:	90000022 	adrp	x2, b000 <__modti3+0xc0>
    7d7c:	91116042 	add	x2, x2, #0x458
    7d80:	910123f5 	add	x21, sp, #0x48
    7d84:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    7d88:	9123c021 	add	x1, x1, #0x8f0
    7d8c:	aa1503e0 	mov	x0, x21
    7d90:	9a81c041 	csel	x1, x2, x1, gt
    7d94:	97ffeb13 	bl	29e0 <strcpy@plt>
    7d98:	aa1503e0 	mov	x0, x21
    7d9c:	97ffea65 	bl	2730 <strlen@plt>
    7da0:	aa1503e1 	mov	x1, x21
    7da4:	aa0003e2 	mov	x2, x0
    7da8:	aa1403e0 	mov	x0, x20
    7dac:	97ffee39 	bl	3690 <buf_put>
    7db0:	f9413bf5 	ldr	x21, [sp, #624]
    7db4:	f9413ff6 	ldr	x22, [sp, #632]
    7db8:	f94153fb 	ldr	x27, [sp, #672]
    7dbc:	f94157fc 	ldr	x28, [sp, #680]
    7dc0:	fd415be8 	ldr	d8, [sp, #688]
    7dc4:	fd415fe9 	ldr	d9, [sp, #696]
    7dc8:	17fffeb7 	b	78a4 <fwp_write+0xb0>
    7dcc:	f9400276 	ldr	x22, [x19]
    7dd0:	34002e03 	cbz	w3, 8390 <fwp_write+0xb9c>
    7dd4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7dd8:	f947f400 	ldr	x0, [x0, #4072]
    7ddc:	f94127e2 	ldr	x2, [sp, #584]
    7de0:	f9400001 	ldr	x1, [x0]
    7de4:	eb010042 	subs	x2, x2, x1
    7de8:	d2800001 	mov	x1, #0x0                   	// #0
    7dec:	540014a1 	b.ne	8080 <fwp_write+0x88c>  // b.any
    7df0:	aa1603e2 	mov	x2, x22
    7df4:	91002261 	add	x1, x19, #0x8
    7df8:	f9413bf5 	ldr	x21, [sp, #624]
    7dfc:	aa1403e0 	mov	x0, x20
    7e00:	f9413ff6 	ldr	x22, [sp, #632]
    7e04:	17ffff00 	b	7a04 <fwp_write+0x210>
    7e08:	fd015be8 	str	d8, [sp, #688]
    7e0c:	9e670268 	fmov	d8, x19
    7e10:	fd015fe9 	str	d9, [sp, #696]
    7e14:	1e682100 	fcmp	d8, d8
    7e18:	54004746 	b.vs	8700 <fwp_write+0xf0c>
    7e1c:	1e60c101 	fabs	d1, d8
    7e20:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7e24:	9e670000 	fmov	d0, x0
    7e28:	910123f5 	add	x21, sp, #0x48
    7e2c:	52800033 	mov	w19, #0x1                   	// #1
    7e30:	1e602020 	fcmp	d1, d0
    7e34:	540001ad 	b.le	7e68 <fwp_write+0x674>
    7e38:	1e602118 	fcmpe	d8, #0.0
    7e3c:	90000022 	adrp	x2, b000 <__modti3+0xc0>
    7e40:	91116042 	add	x2, x2, #0x458
    7e44:	90000021 	adrp	x1, b000 <__modti3+0xc0>
    7e48:	9123c021 	add	x1, x1, #0x8f0
    7e4c:	aa1503e0 	mov	x0, x21
    7e50:	9a81c041 	csel	x1, x2, x1, gt
    7e54:	97ffeae3 	bl	29e0 <strcpy@plt>
    7e58:	17ffffd0 	b	7d98 <fwp_write+0x5a4>
    7e5c:	11000673 	add	w19, w19, #0x1
    7e60:	71004a7f 	cmp	w19, #0x12
    7e64:	54003860 	b.eq	8570 <fwp_write+0xd7c>  // b.none
    7e68:	1e604100 	fmov	d0, d8
    7e6c:	2a1303e1 	mov	w1, w19
    7e70:	aa1503e0 	mov	x0, x21
    7e74:	97ffee63 	bl	3800 <fwp_format_g.constprop.0>
    7e78:	aa1503e0 	mov	x0, x21
    7e7c:	d2800001 	mov	x1, #0x0                   	// #0
    7e80:	97ffea40 	bl	2780 <strtod@plt>
    7e84:	1e602100 	fcmp	d8, d0
    7e88:	54fffea1 	b.ne	7e5c <fwp_write+0x668>  // b.any
    7e8c:	aa1503e0 	mov	x0, x21
    7e90:	97ffee39 	bl	3774 <fwp_finish_float>
    7e94:	17ffffc1 	b	7d98 <fwp_write+0x5a4>
    7e98:	a9400e62 	ldp	x2, x3, [x19]
    7e9c:	910123f3 	add	x19, sp, #0x48
    7ea0:	aa1303e0 	mov	x0, x19
    7ea4:	97ffebdf 	bl	2e20 <fwp_fmt_u128>
    7ea8:	17fffe75 	b	787c <fwp_write+0x88>
    7eac:	f90143f7 	str	x23, [sp, #640]
    7eb0:	f90147f8 	str	x24, [sp, #648]
    7eb4:	2a1303f8 	mov	w24, w19
    7eb8:	f9014bf9 	str	x25, [sp, #656]
    7ebc:	f9014ffa 	str	x26, [sp, #664]
    7ec0:	f13ffe7f 	cmp	x19, #0xfff
    7ec4:	54000049 	b.ls	7ecc <fwp_write+0x6d8>  // b.plast
    7ec8:	b9400278 	ldr	w24, [x19]
    7ecc:	f9400f80 	ldr	x0, [x28, #24]
    7ed0:	2a1803f5 	mov	w21, w24
    7ed4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7ed8:	d37ef6b9 	lsl	x25, x21, #2
    7edc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ee0:	aa1603e0 	mov	x0, x22
    7ee4:	97ffea13 	bl	2730 <strlen@plt>
    7ee8:	aa1603e1 	mov	x1, x22
    7eec:	aa0003e2 	mov	x2, x0
    7ef0:	aa1403e0 	mov	x0, x20
    7ef4:	97ffede7 	bl	3690 <buf_put>
    7ef8:	f9401780 	ldr	x0, [x28, #40]
    7efc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7f00:	7100001f 	cmp	w0, #0x0
    7f04:	5400068d 	b.le	7fd4 <fwp_write+0x7e0>
    7f08:	91002276 	add	x22, x19, #0x8
    7f0c:	91001ff5 	add	x21, sp, #0x7
    7f10:	d280001b 	mov	x27, #0x0                   	// #0
    7f14:	5280041a 	mov	w26, #0x20                  	// #32
    7f18:	f9401b80 	ldr	x0, [x28, #48]
    7f1c:	aa1503e1 	mov	x1, x21
    7f20:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7f24:	d2800022 	mov	x2, #0x1                   	// #1
    7f28:	f8786803 	ldr	x3, [x0, x24]
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7f34:	39001ffa 	strb	w26, [sp, #7]
    7f38:	97ffedd6 	bl	3690 <buf_put>
    7f3c:	f13ffeff 	cmp	x23, #0xfff
    7f40:	b9400261 	ldr	w1, [x19]
    7f44:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7f48:	7100383f 	cmp	w1, #0xe
    7f4c:	54000160 	b.eq	7f78 <fwp_write+0x784>  // b.none
    7f50:	7100403f 	cmp	w1, #0x10
    7f54:	54001a60 	b.eq	82a0 <fwp_write+0xaac>  // b.none
    7f58:	7100283f 	cmp	w1, #0xa
    7f5c:	54002aa0 	b.eq	84b0 <fwp_write+0xcbc>  // b.none
    7f60:	540014ac 	b.gt	81f4 <fwp_write+0xa00>
    7f64:	71000c3f 	cmp	w1, #0x3
    7f68:	540029ac 	b.gt	849c <fwp_write+0xca8>
    7f6c:	d37ffee0 	lsr	x0, x23, #63
    7f70:	37f814a1 	tbnz	w1, #31, 8204 <fwp_write+0xa10>
    7f74:	d503201f 	nop
    7f78:	34001460 	cbz	w0, 8204 <fwp_write+0xa10>
    7f7c:	52800503 	mov	w3, #0x28                  	// #40
    7f80:	aa1503e1 	mov	x1, x21
    7f84:	aa1403e0 	mov	x0, x20
    7f88:	d2800022 	mov	x2, #0x1                   	// #1
    7f8c:	39001fe3 	strb	w3, [sp, #7]
    7f90:	97ffedc0 	bl	3690 <buf_put>
    7f94:	aa1303e2 	mov	x2, x19
    7f98:	aa1703e1 	mov	x1, x23
    7f9c:	aa1403e0 	mov	x0, x20
    7fa0:	52800003 	mov	w3, #0x0                   	// #0
    7fa4:	97fffe14 	bl	77f4 <fwp_write>
    7fa8:	52800523 	mov	w3, #0x29                  	// #41
    7fac:	aa1503e1 	mov	x1, x21
    7fb0:	aa1403e0 	mov	x0, x20
    7fb4:	d2800022 	mov	x2, #0x1                   	// #1
    7fb8:	39001fe3 	strb	w3, [sp, #7]
    7fbc:	97ffedb5 	bl	3690 <buf_put>
    7fc0:	f9401780 	ldr	x0, [x28, #40]
    7fc4:	9100077b 	add	x27, x27, #0x1
    7fc8:	b8796800 	ldr	w0, [x0, x25]
    7fcc:	6b1b001f 	cmp	w0, w27
    7fd0:	54fffa4c 	b.gt	7f18 <fwp_write+0x724>
    7fd4:	f9413bf5 	ldr	x21, [sp, #624]
    7fd8:	f9413ff6 	ldr	x22, [sp, #632]
    7fdc:	f94143f7 	ldr	x23, [sp, #640]
    7fe0:	f94147f8 	ldr	x24, [sp, #648]
    7fe4:	f9414bf9 	ldr	x25, [sp, #656]
    7fe8:	f9414ffa 	ldr	x26, [sp, #664]
    7fec:	f94153fb 	ldr	x27, [sp, #672]
    7ff0:	f94157fc 	ldr	x28, [sp, #680]
    7ff4:	17fffe2c 	b	78a4 <fwp_write+0xb0>
    7ff8:	52800783 	mov	w3, #0x3c                  	// #60
    7ffc:	91001ff3 	add	x19, sp, #0x7
    8000:	aa1303e1 	mov	x1, x19
    8004:	d2800022 	mov	x2, #0x1                   	// #1
    8008:	aa1403e0 	mov	x0, x20
    800c:	39001fe3 	strb	w3, [sp, #7]
    8010:	97ffeda0 	bl	3690 <buf_put>
    8014:	f9400795 	ldr	x21, [x28, #8]
    8018:	aa1503e0 	mov	x0, x21
    801c:	97ffe9c5 	bl	2730 <strlen@plt>
    8020:	aa1503e1 	mov	x1, x21
    8024:	aa0003e2 	mov	x2, x0
    8028:	aa1403e0 	mov	x0, x20
    802c:	97ffed99 	bl	3690 <buf_put>
    8030:	528007c3 	mov	w3, #0x3e                  	// #62
    8034:	aa1303e1 	mov	x1, x19
    8038:	aa1403e0 	mov	x0, x20
    803c:	d2800022 	mov	x2, #0x1                   	// #1
    8040:	39001fe3 	strb	w3, [sp, #7]
    8044:	17fffe13 	b	7890 <fwp_write+0x9c>
    8048:	f100067f 	cmp	x19, #0x1
    804c:	540025a0 	b.eq	8500 <fwp_write+0xd0c>  // b.none
    8050:	b100067f 	cmn	x19, #0x1
    8054:	54002bc0 	b.eq	85cc <fwp_write+0xdd8>  // b.none
    8058:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    805c:	9123e021 	add	x1, x1, #0x8f8
    8060:	d2800022 	mov	x2, #0x1                   	// #1
    8064:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8068:	f947f400 	ldr	x0, [x0, #4072]
    806c:	f94127e4 	ldr	x4, [sp, #584]
    8070:	f9400003 	ldr	x3, [x0]
    8074:	eb030084 	subs	x4, x4, x3
    8078:	d2800003 	mov	x3, #0x0                   	// #0
    807c:	54ffebe0 	b.eq	7df8 <fwp_write+0x604>  // b.none
    8080:	f90143f7 	str	x23, [sp, #640]
    8084:	f90147f8 	str	x24, [sp, #648]
    8088:	f9014bf9 	str	x25, [sp, #656]
    808c:	f9014ffa 	str	x26, [sp, #664]
    8090:	fd015be8 	str	d8, [sp, #688]
    8094:	fd015fe9 	str	d9, [sp, #696]
    8098:	97ffea02 	bl	28a0 <__stack_chk_fail@plt>
    809c:	52800b63 	mov	w3, #0x5b                  	// #91
    80a0:	91001ff5 	add	x21, sp, #0x7
    80a4:	aa1503e1 	mov	x1, x21
    80a8:	aa1403e0 	mov	x0, x20
    80ac:	d2800022 	mov	x2, #0x1                   	// #1
    80b0:	f0000016 	adrp	x22, b000 <__modti3+0xc0>
    80b4:	912662d6 	add	x22, x22, #0x998
    80b8:	39001fe3 	strb	w3, [sp, #7]
    80bc:	97ffed75 	bl	3690 <buf_put>
    80c0:	b4000273 	cbz	x19, 810c <fwp_write+0x918>
    80c4:	f9400661 	ldr	x1, [x19, #8]
    80c8:	aa1403e0 	mov	x0, x20
    80cc:	f9401f82 	ldr	x2, [x28, #56]
    80d0:	52800003 	mov	w3, #0x0                   	// #0
    80d4:	97fffdc8 	bl	77f4 <fwp_write>
    80d8:	f9400a73 	ldr	x19, [x19, #16]
    80dc:	b4000193 	cbz	x19, 810c <fwp_write+0x918>
    80e0:	aa1603e1 	mov	x1, x22
    80e4:	aa1403e0 	mov	x0, x20
    80e8:	d2800042 	mov	x2, #0x2                   	// #2
    80ec:	97ffed69 	bl	3690 <buf_put>
    80f0:	f9400661 	ldr	x1, [x19, #8]
    80f4:	aa1403e0 	mov	x0, x20
    80f8:	f9401f82 	ldr	x2, [x28, #56]
    80fc:	52800003 	mov	w3, #0x0                   	// #0
    8100:	97fffdbd 	bl	77f4 <fwp_write>
    8104:	f9400a73 	ldr	x19, [x19, #16]
    8108:	b5fffed3 	cbnz	x19, 80e0 <fwp_write+0x8ec>
    810c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8110:	aa1503e1 	mov	x1, x21
    8114:	aa1403e0 	mov	x0, x20
    8118:	d2800022 	mov	x2, #0x1                   	// #1
    811c:	39001fe3 	strb	w3, [sp, #7]
    8120:	17fffddc 	b	7890 <fwp_write+0x9c>
    8124:	aa1403e0 	mov	x0, x20
    8128:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    812c:	d28000c2 	mov	x2, #0x6                   	// #6
    8130:	91262021 	add	x1, x1, #0x988
    8134:	97ffed57 	bl	3690 <buf_put>
    8138:	f9400260 	ldr	x0, [x19]
    813c:	b40004c0 	cbz	x0, 81d4 <fwp_write+0x9e0>
    8140:	910123f5 	add	x21, sp, #0x48
    8144:	91002276 	add	x22, x19, #0x8
    8148:	f90143f7 	str	x23, [sp, #640]
    814c:	d2800017 	mov	x23, #0x0                   	// #0
    8150:	f90147f8 	str	x24, [sp, #648]
    8154:	f0000018 	adrp	x24, b000 <__modti3+0xc0>
    8158:	91264318 	add	x24, x24, #0x990
    815c:	f9014bf9 	str	x25, [sp, #656]
    8160:	f0000019 	adrp	x25, b000 <__modti3+0xc0>
    8164:	91266339 	add	x25, x25, #0x998
    8168:	f9014ffa 	str	x26, [sp, #664]
    816c:	14000005 	b	8180 <fwp_write+0x98c>
    8170:	aa1903e1 	mov	x1, x25
    8174:	aa1403e0 	mov	x0, x20
    8178:	d2800042 	mov	x2, #0x2                   	// #2
    817c:	97ffed45 	bl	3690 <buf_put>
    8180:	38776ac5 	ldrb	w5, [x22, x23]
    8184:	d2804003 	mov	x3, #0x200                 	// #512
    8188:	aa1803e4 	mov	x4, x24
    818c:	aa0303e1 	mov	x1, x3
    8190:	52800042 	mov	w2, #0x2                   	// #2
    8194:	aa1503e0 	mov	x0, x21
    8198:	910006f7 	add	x23, x23, #0x1
    819c:	97ffe99d 	bl	2810 <__snprintf_chk@plt>
    81a0:	aa1503e0 	mov	x0, x21
    81a4:	97ffe963 	bl	2730 <strlen@plt>
    81a8:	aa1503e1 	mov	x1, x21
    81ac:	aa0003e2 	mov	x2, x0
    81b0:	aa1403e0 	mov	x0, x20
    81b4:	97ffed37 	bl	3690 <buf_put>
    81b8:	f9400260 	ldr	x0, [x19]
    81bc:	eb17001f 	cmp	x0, x23
    81c0:	54fffd88 	b.hi	8170 <fwp_write+0x97c>  // b.pmore
    81c4:	f94143f7 	ldr	x23, [sp, #640]
    81c8:	f94147f8 	ldr	x24, [sp, #648]
    81cc:	f9414bf9 	ldr	x25, [sp, #656]
    81d0:	f9414ffa 	ldr	x26, [sp, #664]
    81d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    81d8:	aa1403e0 	mov	x0, x20
    81dc:	91001fe1 	add	x1, sp, #0x7
    81e0:	d2800022 	mov	x2, #0x1                   	// #1
    81e4:	39001fe3 	strb	w3, [sp, #7]
    81e8:	17fffdaa 	b	7890 <fwp_write+0x9c>
    81ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    81f0:	17fffe45 	b	7b04 <fwp_write+0x310>
    81f4:	f10002ff 	cmp	x23, #0x0
    81f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    81fc:	71002c3f 	cmp	w1, #0xb
    8200:	54ffebc0 	b.eq	7f78 <fwp_write+0x784>  // b.none
    8204:	aa1303e2 	mov	x2, x19
    8208:	aa1703e1 	mov	x1, x23
    820c:	aa1403e0 	mov	x0, x20
    8210:	52800003 	mov	w3, #0x0                   	// #0
    8214:	97fffd78 	bl	77f4 <fwp_write>
    8218:	17ffff6a 	b	7fc0 <fwp_write+0x7cc>
    821c:	aa1403e0 	mov	x0, x20
    8220:	91001fe1 	add	x1, sp, #0x7
    8224:	52800fa3 	mov	w3, #0x7d                  	// #125
    8228:	d2800022 	mov	x2, #0x1                   	// #1
    822c:	17fffe39 	b	7b10 <fwp_write+0x31c>
    8230:	a9400281 	ldp	x1, x0, [x20]
    8234:	91000800 	add	x0, x0, #0x2
    8238:	8b160000 	add	x0, x0, x22
    823c:	f9000680 	str	x0, [x20, #8]
    8240:	3820683f 	strb	wzr, [x1, x0]
    8244:	f9413bf5 	ldr	x21, [sp, #624]
    8248:	f9413ff6 	ldr	x22, [sp, #632]
    824c:	f94153fb 	ldr	x27, [sp, #672]
    8250:	f94157fc 	ldr	x28, [sp, #680]
    8254:	17fffd94 	b	78a4 <fwp_write+0xb0>
    8258:	f9400f80 	ldr	x0, [x28, #24]
    825c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8260:	aa1b03e0 	mov	x0, x27
    8264:	97ffe933 	bl	2730 <strlen@plt>
    8268:	aa1b03e1 	mov	x1, x27
    826c:	aa0003e2 	mov	x2, x0
    8270:	aa1403e0 	mov	x0, x20
    8274:	97ffed07 	bl	3690 <buf_put>
    8278:	aa1903e1 	mov	x1, x25
    827c:	aa1403e0 	mov	x0, x20
    8280:	d2800062 	mov	x2, #0x3                   	// #3
    8284:	97ffed03 	bl	3690 <buf_put>
    8288:	17fffe11 	b	7acc <fwp_write+0x2d8>
    828c:	aa1a03e1 	mov	x1, x26
    8290:	aa1403e0 	mov	x0, x20
    8294:	d2800042 	mov	x2, #0x2                   	// #2
    8298:	97ffecfe 	bl	3690 <buf_put>
    829c:	17fffe0a 	b	7ac4 <fwp_write+0x2d0>
    82a0:	f9400660 	ldr	x0, [x19, #8]
    82a4:	b4fffb00 	cbz	x0, 8204 <fwp_write+0xa10>
    82a8:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    82ac:	9126c021 	add	x1, x1, #0x9b0
    82b0:	97ffe99c 	bl	2920 <strcmp@plt>
    82b4:	7100001f 	cmp	w0, #0x0
    82b8:	1a9f07e0 	cset	w0, ne	// ne = any
    82bc:	17ffff2f 	b	7f78 <fwp_write+0x784>
    82c0:	aa1403e0 	mov	x0, x20
    82c4:	d2800042 	mov	x2, #0x2                   	// #2
    82c8:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    82cc:	9126a021 	add	x1, x1, #0x9a8
    82d0:	97ffecf0 	bl	3690 <buf_put>
    82d4:	91004261 	add	x1, x19, #0x10
    82d8:	aa1403e0 	mov	x0, x20
    82dc:	f9402382 	ldr	x2, [x28, #64]
    82e0:	52800003 	mov	w3, #0x0                   	// #0
    82e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    82e8:	97fffd43 	bl	77f4 <fwp_write>
    82ec:	17fffd9d 	b	7960 <fwp_write+0x16c>
    82f0:	1e22c109 	fcvt	d9, s8
    82f4:	910123f5 	add	x21, sp, #0x48
    82f8:	52800033 	mov	w19, #0x1                   	// #1
    82fc:	d503201f 	nop
    8300:	1e604120 	fmov	d0, d9
    8304:	2a1303e1 	mov	w1, w19
    8308:	aa1503e0 	mov	x0, x21
    830c:	97ffed3d 	bl	3800 <fwp_format_g.constprop.0>
    8310:	aa1503e0 	mov	x0, x21
    8314:	d2800001 	mov	x1, #0x0                   	// #0
    8318:	97ffe98e 	bl	2950 <strtof@plt>
    831c:	1e202100 	fcmp	s8, s0
    8320:	54ffdb60 	b.eq	7e8c <fwp_write+0x698>  // b.none
    8324:	11000673 	add	w19, w19, #0x1
    8328:	71002a7f 	cmp	w19, #0xa
    832c:	54fffea1 	b.ne	8300 <fwp_write+0xb0c>  // b.any
    8330:	1e604120 	fmov	d0, d9
    8334:	aa1503e0 	mov	x0, x21
    8338:	52800121 	mov	w1, #0x9                   	// #9
    833c:	97ffed31 	bl	3800 <fwp_format_g.constprop.0>
    8340:	17fffed3 	b	7e8c <fwp_write+0x698>
    8344:	d37ef6a1 	lsl	x1, x21, #2
    8348:	b7f81563 	tbnz	x3, #63, 85f4 <fwp_write+0xe00>
    834c:	91002263 	add	x3, x19, #0x8
    8350:	8b010061 	add	x1, x3, x1
    8354:	b9400023 	ldr	w3, [x1]
    8358:	7100081f 	cmp	w0, #0x2
    835c:	2a0303e1 	mov	w1, w3
    8360:	93407c63 	sxtw	x3, w3
    8364:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8368:	17fffe5a 	b	7cd0 <fwp_write+0x4dc>
    836c:	d37ffaa1 	lsl	x1, x21, #1
    8370:	b7f81363 	tbnz	x3, #63, 85dc <fwp_write+0xde8>
    8374:	91002263 	add	x3, x19, #0x8
    8378:	8b010061 	add	x1, x3, x1
    837c:	79400021 	ldrh	w1, [x1]
    8380:	7100041f 	cmp	w0, #0x1
    8384:	93403c23 	sxth	x3, w1
    8388:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    838c:	17fffe51 	b	7cd0 <fwp_write+0x4dc>
    8390:	52800443 	mov	w3, #0x22                  	// #34
    8394:	91001ff5 	add	x21, sp, #0x7
    8398:	91002273 	add	x19, x19, #0x8
    839c:	aa1503e1 	mov	x1, x21
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	d2800022 	mov	x2, #0x1                   	// #1
    83a8:	39001fe3 	strb	w3, [sp, #7]
    83ac:	f90143f7 	str	x23, [sp, #640]
    83b0:	8b160277 	add	x23, x19, x22
    83b4:	f90147f8 	str	x24, [sp, #648]
    83b8:	97ffecb6 	bl	3690 <buf_put>
    83bc:	b4000696 	cbz	x22, 848c <fwp_write+0xc98>
    83c0:	f0000018 	adrp	x24, b000 <__modti3+0xc0>
    83c4:	91256318 	add	x24, x24, #0x958
    83c8:	f9014bf9 	str	x25, [sp, #656]
    83cc:	f0000019 	adrp	x25, b000 <__modti3+0xc0>
    83d0:	9125e339 	add	x25, x25, #0x978
    83d4:	f9014ffa 	str	x26, [sp, #664]
    83d8:	1400000d 	b	840c <fwp_write+0xc18>
    83dc:	710024bf 	cmp	w5, #0x9
    83e0:	54000460 	b.eq	846c <fwp_write+0xc78>  // b.none
    83e4:	710028bf 	cmp	w5, #0xa
    83e8:	54000a61 	b.ne	8534 <fwp_write+0xd40>  // b.any
    83ec:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    83f0:	aa1403e0 	mov	x0, x20
    83f4:	9125a021 	add	x1, x1, #0x968
    83f8:	d2800042 	mov	x2, #0x2                   	// #2
    83fc:	97ffeca5 	bl	3690 <buf_put>
    8400:	91000673 	add	x19, x19, #0x1
    8404:	eb17027f 	cmp	x19, x23
    8408:	540003e0 	b.eq	8484 <fwp_write+0xc90>  // b.none
    840c:	39400265 	ldrb	w5, [x19]
    8410:	710034bf 	cmp	w5, #0xd
    8414:	54000180 	b.eq	8444 <fwp_write+0xc50>  // b.none
    8418:	54fffe29 	b.ls	83dc <fwp_write+0xbe8>  // b.plast
    841c:	710088bf 	cmp	w5, #0x22
    8420:	540001c0 	b.eq	8458 <fwp_write+0xc64>  // b.none
    8424:	710170bf 	cmp	w5, #0x5c
    8428:	54000741 	b.ne	8510 <fwp_write+0xd1c>  // b.any
    842c:	aa1403e0 	mov	x0, x20
    8430:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8434:	d2800042 	mov	x2, #0x2                   	// #2
    8438:	91258021 	add	x1, x1, #0x960
    843c:	97ffec95 	bl	3690 <buf_put>
    8440:	17fffff0 	b	8400 <fwp_write+0xc0c>
    8444:	aa1903e1 	mov	x1, x25
    8448:	aa1403e0 	mov	x0, x20
    844c:	d2800042 	mov	x2, #0x2                   	// #2
    8450:	97ffec90 	bl	3690 <buf_put>
    8454:	17ffffeb 	b	8400 <fwp_write+0xc0c>
    8458:	aa1803e1 	mov	x1, x24
    845c:	aa1403e0 	mov	x0, x20
    8460:	d2800042 	mov	x2, #0x2                   	// #2
    8464:	97ffec8b 	bl	3690 <buf_put>
    8468:	17ffffe6 	b	8400 <fwp_write+0xc0c>
    846c:	aa1403e0 	mov	x0, x20
    8470:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8474:	d2800042 	mov	x2, #0x2                   	// #2
    8478:	9125c021 	add	x1, x1, #0x970
    847c:	97ffec85 	bl	3690 <buf_put>
    8480:	17ffffe0 	b	8400 <fwp_write+0xc0c>
    8484:	f9414bf9 	ldr	x25, [sp, #656]
    8488:	f9414ffa 	ldr	x26, [sp, #664]
    848c:	aa1503e1 	mov	x1, x21
    8490:	aa1403e0 	mov	x0, x20
    8494:	52800443 	mov	w3, #0x22                  	// #34
    8498:	17fffd9d 	b	7b0c <fwp_write+0x318>
    849c:	7100103f 	cmp	w1, #0x4
    84a0:	54ffeb21 	b.ne	8204 <fwp_write+0xa10>  // b.any
    84a4:	f94006e0 	ldr	x0, [x23, #8]
    84a8:	d37ffc00 	lsr	x0, x0, #63
    84ac:	17fffeb3 	b	7f78 <fwp_write+0x784>
    84b0:	710002ff 	cmp	w23, #0x0
    84b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    84b8:	17fffeb0 	b	7f78 <fwp_write+0x784>
    84bc:	528005a1 	mov	w1, #0x2d                  	// #45
    84c0:	eb0203e2 	negs	x2, x2
    84c4:	da0303e3 	ngc	x3, x3
    84c8:	910127e0 	add	x0, sp, #0x49
    84cc:	910123f5 	add	x21, sp, #0x48
    84d0:	390123e1 	strb	w1, [sp, #72]
    84d4:	97ffea53 	bl	2e20 <fwp_fmt_u128>
    84d8:	17fffe18 	b	7d38 <fwp_write+0x544>
    84dc:	d37ceea1 	lsl	x1, x21, #4
    84e0:	b7f810a3 	tbnz	x3, #63, 86f4 <fwp_write+0xf00>
    84e4:	91002260 	add	x0, x19, #0x8
    84e8:	8b010001 	add	x1, x0, x1
    84ec:	17fffdf9 	b	7cd0 <fwp_write+0x4dc>
    84f0:	f9400a61 	ldr	x1, [x19, #16]
    84f4:	8b010000 	add	x0, x0, x1
    84f8:	f9400001 	ldr	x1, [x0]
    84fc:	17fffdf5 	b	7cd0 <fwp_write+0x4dc>
    8500:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    8504:	d2800042 	mov	x2, #0x2                   	// #2
    8508:	91240021 	add	x1, x1, #0x900
    850c:	17fffed6 	b	8064 <fwp_write+0x870>
    8510:	7101fcbf 	cmp	w5, #0x7f
    8514:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8518:	540000e9 	b.ls	8534 <fwp_write+0xd40>  // b.plast
    851c:	aa1503e1 	mov	x1, x21
    8520:	aa1403e0 	mov	x0, x20
    8524:	d2800022 	mov	x2, #0x1                   	// #1
    8528:	39001fe5 	strb	w5, [sp, #7]
    852c:	97ffec59 	bl	3690 <buf_put>
    8530:	17ffffb4 	b	8400 <fwp_write+0xc0c>
    8534:	d2800203 	mov	x3, #0x10                  	// #16
    8538:	f0000004 	adrp	x4, b000 <__modti3+0xc0>
    853c:	aa0303e1 	mov	x1, x3
    8540:	91260084 	add	x4, x4, #0x980
    8544:	910123f6 	add	x22, sp, #0x48
    8548:	52800042 	mov	w2, #0x2                   	// #2
    854c:	aa1603e0 	mov	x0, x22
    8550:	97ffe8b0 	bl	2810 <__snprintf_chk@plt>
    8554:	aa1603e0 	mov	x0, x22
    8558:	97ffe876 	bl	2730 <strlen@plt>
    855c:	aa1603e1 	mov	x1, x22
    8560:	aa0003e2 	mov	x2, x0
    8564:	aa1403e0 	mov	x0, x20
    8568:	97ffec4a 	bl	3690 <buf_put>
    856c:	17ffffa5 	b	8400 <fwp_write+0xc0c>
    8570:	1e604100 	fmov	d0, d8
    8574:	aa1503e0 	mov	x0, x21
    8578:	52800221 	mov	w1, #0x11                  	// #17
    857c:	97ffeca1 	bl	3800 <fwp_format_g.constprop.0>
    8580:	17fffe43 	b	7e8c <fwp_write+0x698>
    8584:	b9401040 	ldr	w0, [x2, #16]
    8588:	350003c0 	cbnz	w0, 8600 <fwp_write+0xe0c>
    858c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8590:	f947f400 	ldr	x0, [x0, #4072]
    8594:	f94127e2 	ldr	x2, [sp, #584]
    8598:	f9400001 	ldr	x1, [x0]
    859c:	eb010042 	subs	x2, x2, x1
    85a0:	d2800001 	mov	x1, #0x0                   	// #0
    85a4:	54ffd721 	b.ne	8088 <fwp_write+0x894>  // b.any
    85a8:	f9413bf5 	ldr	x21, [sp, #624]
    85ac:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    85b0:	f9413ff6 	ldr	x22, [sp, #632]
    85b4:	aa1403e0 	mov	x0, x20
    85b8:	f94143f7 	ldr	x23, [sp, #640]
    85bc:	91274021 	add	x1, x1, #0x9d0
    85c0:	f94147f8 	ldr	x24, [sp, #648]
    85c4:	d2800042 	mov	x2, #0x2                   	// #2
    85c8:	17fffd0f 	b	7a04 <fwp_write+0x210>
    85cc:	f0000001 	adrp	x1, b000 <__modti3+0xc0>
    85d0:	d2800042 	mov	x2, #0x2                   	// #2
    85d4:	91242021 	add	x1, x1, #0x908
    85d8:	17fffea3 	b	8064 <fwp_write+0x870>
    85dc:	f9400a63 	ldr	x3, [x19, #16]
    85e0:	8b030021 	add	x1, x1, x3
    85e4:	17ffff66 	b	837c <fwp_write+0xb88>
    85e8:	f9400a61 	ldr	x1, [x19, #16]
    85ec:	8b0102a1 	add	x1, x21, x1
    85f0:	17fffdb4 	b	7cc0 <fwp_write+0x4cc>
    85f4:	f9400a63 	ldr	x3, [x19, #16]
    85f8:	8b030021 	add	x1, x1, x3
    85fc:	17ffff56 	b	8354 <fwp_write+0xb60>
    8600:	b9404840 	ldr	w0, [x2, #72]
    8604:	91001ff5 	add	x21, sp, #0x7
    8608:	34ffa380 	cbz	w0, 7a78 <fwp_write+0x284>
    860c:	52800503 	mov	w3, #0x28                  	// #40
    8610:	aa1403e0 	mov	x0, x20
    8614:	aa1503e1 	mov	x1, x21
    8618:	d2800022 	mov	x2, #0x1                   	// #1
    861c:	39001fe3 	strb	w3, [sp, #7]
    8620:	97ffec1c 	bl	3690 <buf_put>
    8624:	b9401380 	ldr	w0, [x28, #16]
    8628:	52800038 	mov	w24, #0x1                   	// #1
    862c:	7100001f 	cmp	w0, #0x0
    8630:	54ffa38c 	b.gt	7aa0 <fwp_write+0x2ac>
    8634:	17fffd33 	b	7b00 <fwp_write+0x30c>
    8638:	f9014bf9 	str	x25, [sp, #656]
    863c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10a10>
    8640:	f9014ffa 	str	x26, [sp, #664]
    8644:	f9400676 	ldr	x22, [x19, #8]
    8648:	910ac333 	add	x19, x25, #0x2b0
    864c:	91002273 	add	x19, x19, #0x8
    8650:	937ffed8 	asr	x24, x22, #63
    8654:	aa1802c0 	orr	x0, x22, x24
    8658:	b5000320 	cbnz	x0, 86bc <fwp_write+0xec8>
    865c:	110006b5 	add	w21, w21, #0x1
    8660:	710016bf 	cmp	w21, #0x5
    8664:	54ffffc1 	b.ne	865c <fwp_write+0xe68>  // b.any
    8668:	b7f80578 	tbnz	x24, #63, 8714 <fwp_write+0xf20>
    866c:	910023f3 	add	x19, sp, #0x8
    8670:	aa1603e2 	mov	x2, x22
    8674:	aa1303e0 	mov	x0, x19
    8678:	d2800003 	mov	x3, #0x0                   	// #0
    867c:	97ffe9e9 	bl	2e20 <fwp_fmt_u128>
    8680:	910123f5 	add	x21, sp, #0x48
    8684:	f0000003 	adrp	x3, b000 <__modti3+0xc0>
    8688:	aa1303e4 	mov	x4, x19
    868c:	aa1503e0 	mov	x0, x21
    8690:	91272063 	add	x3, x3, #0x9c8
    8694:	d2804002 	mov	x2, #0x200                 	// #512
    8698:	52800041 	mov	w1, #0x2                   	// #2
    869c:	97ffe829 	bl	2740 <__sprintf_chk@plt>
    86a0:	aa1503e0 	mov	x0, x21
    86a4:	97ffe823 	bl	2730 <strlen@plt>
    86a8:	aa1503e1 	mov	x1, x21
    86ac:	aa0003e2 	mov	x2, x0
    86b0:	aa1403e0 	mov	x0, x20
    86b4:	97ffebf7 	bl	3690 <buf_put>
    86b8:	17fffe47 	b	7fd4 <fwp_write+0x7e0>
    86bc:	f9400277 	ldr	x23, [x19]
    86c0:	aa1603e0 	mov	x0, x22
    86c4:	aa1803e1 	mov	x1, x24
    86c8:	aa1703e2 	mov	x2, x23
    86cc:	937ffefa 	asr	x26, x23, #63
    86d0:	aa1a03e3 	mov	x3, x26
    86d4:	94000a1b 	bl	af40 <__modti3>
    86d8:	aa010000 	orr	x0, x0, x1
    86dc:	b40002c0 	cbz	x0, 8734 <fwp_write+0xf40>
    86e0:	110006b5 	add	w21, w21, #0x1
    86e4:	91004273 	add	x19, x19, #0x10
    86e8:	710016bf 	cmp	w21, #0x5
    86ec:	54fffe81 	b.ne	86bc <fwp_write+0xec8>  // b.any
    86f0:	17ffffde 	b	8668 <fwp_write+0xe74>
    86f4:	f9400a60 	ldr	x0, [x19, #16]
    86f8:	8b000021 	add	x1, x1, x0
    86fc:	17fffd75 	b	7cd0 <fwp_write+0x4dc>
    8700:	528c29c0 	mov	w0, #0x614e                	// #24910
    8704:	910123f5 	add	x21, sp, #0x48
    8708:	72a009c0 	movk	w0, #0x4e, lsl #16
    870c:	b9004be0 	str	w0, [sp, #72]
    8710:	17fffda2 	b	7d98 <fwp_write+0x5a4>
    8714:	528005a1 	mov	w1, #0x2d                  	// #45
    8718:	eb1603e2 	negs	x2, x22
    871c:	da1803e3 	ngc	x3, x24
    8720:	910027e0 	add	x0, sp, #0x9
    8724:	910023f3 	add	x19, sp, #0x8
    8728:	390023e1 	strb	w1, [sp, #8]
    872c:	97ffe9bd 	bl	2e20 <fwp_fmt_u128>
    8730:	17ffffd4 	b	8680 <fwp_write+0xe8c>
    8734:	aa1703e2 	mov	x2, x23
    8738:	aa1a03e3 	mov	x3, x26
    873c:	aa1603e0 	mov	x0, x22
    8740:	aa1803e1 	mov	x1, x24
    8744:	9400091f 	bl	abc0 <__divti3>
    8748:	aa0003e2 	mov	x2, x0
    874c:	aa0103e3 	mov	x3, x1
    8750:	b7f80201 	tbnz	x1, #63, 8790 <fwp_write+0xf9c>
    8754:	910023f3 	add	x19, sp, #0x8
    8758:	aa1303e0 	mov	x0, x19
    875c:	97ffe9b1 	bl	2e20 <fwp_fmt_u128>
    8760:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8764:	910ac339 	add	x25, x25, #0x2b0
    8768:	910123f5 	add	x21, sp, #0x48
    876c:	aa1303e4 	mov	x4, x19
    8770:	aa1503e0 	mov	x0, x21
    8774:	f0000003 	adrp	x3, b000 <__modti3+0xc0>
    8778:	f8616b25 	ldr	x5, [x25, x1]
    877c:	91270063 	add	x3, x3, #0x9c0
    8780:	d2804002 	mov	x2, #0x200                 	// #512
    8784:	52800041 	mov	w1, #0x2                   	// #2
    8788:	97ffe7ee 	bl	2740 <__sprintf_chk@plt>
    878c:	17ffffc5 	b	86a0 <fwp_write+0xeac>
    8790:	528005a4 	mov	w4, #0x2d                  	// #45
    8794:	eb0003e2 	negs	x2, x0
    8798:	da0103e3 	ngc	x3, x1
    879c:	910027e0 	add	x0, sp, #0x9
    87a0:	910023f3 	add	x19, sp, #0x8
    87a4:	390023e4 	strb	w4, [sp, #8]
    87a8:	97ffe99e 	bl	2e20 <fwp_fmt_u128>
    87ac:	17ffffed 	b	8760 <fwp_write+0xf6c>
    87b0:	f9013bf5 	str	x21, [sp, #624]
    87b4:	f9013ff6 	str	x22, [sp, #632]
    87b8:	f90143f7 	str	x23, [sp, #640]
    87bc:	f90147f8 	str	x24, [sp, #648]
    87c0:	f9014bf9 	str	x25, [sp, #656]
    87c4:	f9014ffa 	str	x26, [sp, #664]
    87c8:	f90153fb 	str	x27, [sp, #672]
    87cc:	f90157fc 	str	x28, [sp, #680]
    87d0:	fd015be8 	str	d8, [sp, #688]
    87d4:	fd015fe9 	str	d9, [sp, #696]
    87d8:	97ffe832 	bl	28a0 <__stack_chk_fail@plt>
    87dc:	d503201f 	nop

00000000000087e0 <fwp_main_thread>:
    87e0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    87e4:	910003fd 	mov	x29, sp
    87e8:	a90153f3 	stp	x19, x20, [sp, #16]
    87ec:	b0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    87f0:	9118c261 	add	x1, x19, #0x630
    87f4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    87f8:	f947f400 	ldr	x0, [x0, #4072]
    87fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    8800:	a90363f7 	stp	x23, x24, [sp, #48]
    8804:	d107c3ff 	sub	sp, sp, #0x1f0
    8808:	b953a421 	ldr	w1, [x1, #5028]
    880c:	f9400002 	ldr	x2, [x0]
    8810:	f900f7e2 	str	x2, [sp, #488]
    8814:	d2800002 	mov	x2, #0x0                   	// #0
    8818:	34000fc1 	cbz	w1, 8a10 <fwp_main_thread+0x230>
    881c:	9118c260 	add	x0, x19, #0x630
    8820:	b953a800 	ldr	w0, [x0, #5032]
    8824:	35000ee0 	cbnz	w0, 8a00 <fwp_main_thread+0x220>
    8828:	900000d4 	adrp	x20, 20000 <__data_start>
    882c:	900000c2 	adrp	x2, 20000 <__data_start>
    8830:	91014297 	add	x23, x20, #0x50
    8834:	91114042 	add	x2, x2, #0x450
    8838:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    883c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8840:	9103a3f5 	add	x21, sp, #0xe8
    8844:	910323f8 	add	x24, sp, #0xc8
    8848:	aa1503e0 	mov	x0, x21
    884c:	d2800001 	mov	x1, #0x0                   	// #0
    8850:	a90a0ef8 	stp	x24, x3, [x23, #160]
    8854:	f90077e2 	str	x2, [sp, #232]
    8858:	b900f3ff 	str	wzr, [sp, #240]
    885c:	f9007fe4 	str	x4, [sp, #248]
    8860:	97ffe7a8 	bl	2700 <sigaltstack@plt>
    8864:	35000220 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    8868:	4f000400 	movi	v0.4s, #0x0
    886c:	910563e0 	add	x0, sp, #0x158
    8870:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    8874:	9102c021 	add	x1, x1, #0xb0
    8878:	f900abe1 	str	x1, [sp, #336]
    887c:	52800082 	mov	w2, #0x4                   	// #4
    8880:	72a10002 	movk	w2, #0x800, lsl #16
    8884:	910543f6 	add	x22, sp, #0x150
    8888:	3d802000 	str	q0, [x0, #128]
    888c:	b901dbe2 	str	w2, [sp, #472]
    8890:	ad000000 	stp	q0, q0, [x0]
    8894:	ad010000 	stp	q0, q0, [x0, #32]
    8898:	ad020000 	stp	q0, q0, [x0, #64]
    889c:	ad030000 	stp	q0, q0, [x0, #96]
    88a0:	97ffe7f0 	bl	2860 <sigemptyset@plt>
    88a4:	34000100 	cbz	w0, 88c4 <fwp_main_thread+0xe4>
    88a8:	f0000000 	adrp	x0, b000 <__modti3+0xc0>
    88ac:	91278000 	add	x0, x0, #0x9e0
    88b0:	f9011bf9 	str	x25, [sp, #560]
    88b4:	f9011ffa 	str	x26, [sp, #568]
    88b8:	f90123fb 	str	x27, [sp, #576]
    88bc:	f90127fc 	str	x28, [sp, #584]
    88c0:	97ffee9d 	bl	4334 <fwp_trap>
    88c4:	aa1603e1 	mov	x1, x22
    88c8:	d2800002 	mov	x2, #0x0                   	// #0
    88cc:	52800160 	mov	w0, #0xb                   	// #11
    88d0:	97ffe7fc 	bl	28c0 <sigaction@plt>
    88d4:	35fffea0 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    88d8:	aa1603e1 	mov	x1, x22
    88dc:	d2800002 	mov	x2, #0x0                   	// #0
    88e0:	528000e0 	mov	w0, #0x7                   	// #7
    88e4:	97ffe7f7 	bl	28c0 <sigaction@plt>
    88e8:	35fffe00 	cbnz	w0, 88a8 <fwp_main_thread+0xc8>
    88ec:	f9011ffa 	str	x26, [sp, #568]
    88f0:	9118c27a 	add	x26, x19, #0x630
    88f4:	f9011bf9 	str	x25, [sp, #560]
    88f8:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    88fc:	52800039 	mov	w25, #0x1                   	// #1
    8900:	910ec000 	add	x0, x0, #0x3b0
    8904:	fd4a1340 	ldr	d0, [x26, #5152]
    8908:	b90132f9 	str	w25, [x23, #304]
    890c:	7e61d800 	ucvtf	d0, d0
    8910:	fd00a6e0 	str	d0, [x23, #328]
    8914:	94000a67 	bl	b2b0 <atexit>
    8918:	3500cac0 	cbnz	w0, a270 <fwp_main_thread+0x1a90>
    891c:	b943c6e0 	ldr	w0, [x23, #964]
    8920:	340007c0 	cbz	w0, 8a18 <fwp_main_thread+0x238>
    8924:	9101429a 	add	x26, x20, #0x50
    8928:	f9404f56 	ldr	x22, [x26, #152]
    892c:	b4001456 	cbz	x22, 8bb4 <fwp_main_thread+0x3d4>
    8930:	910102d7 	add	x23, x22, #0x40
    8934:	39414ad9 	ldrb	w25, [x22, #82]
    8938:	52800038 	mov	w24, #0x1                   	// #1
    893c:	39014ad8 	strb	w24, [x22, #82]
    8940:	f94016c0 	ldr	x0, [x22, #40]
    8944:	b4001360 	cbz	x0, 8bb0 <fwp_main_thread+0x3d0>
    8948:	f94032c1 	ldr	x1, [x22, #96]
    894c:	394146c0 	ldrb	w0, [x22, #81]
    8950:	b4000f81 	cbz	x1, 8b40 <fwp_main_thread+0x360>
    8954:	36000e40 	tbz	w0, #0, 8b1c <fwp_main_thread+0x33c>
    8958:	f9404f55 	ldr	x21, [x26, #152]
    895c:	f94022c0 	ldr	x0, [x22, #64]
    8960:	39414aa1 	ldrb	w1, [x21, #82]
    8964:	37001161 	tbnz	w1, #0, 8b90 <fwp_main_thread+0x3b0>
    8968:	f94032a1 	ldr	x1, [x21, #96]
    896c:	a911feb7 	stp	x23, xzr, [x21, #280]
    8970:	f90096a0 	str	x0, [x21, #296]
    8974:	b4000040 	cbz	x0, 897c <fwp_main_thread+0x19c>
    8978:	f9009015 	str	x21, [x0, #288]
    897c:	f90022d5 	str	x21, [x22, #64]
    8980:	b4000101 	cbz	x1, 89a0 <fwp_main_thread+0x1c0>
    8984:	f9409740 	ldr	x0, [x26, #296]
    8988:	390156b8 	strb	w24, [x21, #85]
    898c:	f90036a1 	str	x1, [x21, #104]
    8990:	a91082bf 	stp	xzr, x0, [x21, #264]
    8994:	b4000040 	cbz	x0, 899c <fwp_main_thread+0x1bc>
    8998:	f9008415 	str	x21, [x0, #264]
    899c:	f9009755 	str	x21, [x26, #296]
    89a0:	39015abf 	strb	wzr, [x21, #86]
    89a4:	97fff8eb 	bl	6d50 <fwp_block>
    89a8:	f9408ea2 	ldr	x2, [x21, #280]
    89ac:	b4000142 	cbz	x2, 89d4 <fwp_main_thread+0x1f4>
    89b0:	a95202a1 	ldp	x1, x0, [x21, #288]
    89b4:	b4000fa1 	cbz	x1, 8ba8 <fwp_main_thread+0x3c8>
    89b8:	f9009420 	str	x0, [x1, #296]
    89bc:	f94096a0 	ldr	x0, [x21, #296]
    89c0:	b4000040 	cbz	x0, 89c8 <fwp_main_thread+0x1e8>
    89c4:	f9009001 	str	x1, [x0, #288]
    89c8:	910802a0 	add	x0, x21, #0x200
    89cc:	f90096bf 	str	xzr, [x21, #296]
    89d0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    89d4:	394156a0 	ldrb	w0, [x21, #85]
    89d8:	3607fb40 	tbz	w0, #0, 8940 <fwp_main_thread+0x160>
    89dc:	a95082a1 	ldp	x1, x0, [x21, #264]
    89e0:	b40021e1 	cbz	x1, 8e1c <fwp_main_thread+0x63c>
    89e4:	f9008820 	str	x0, [x1, #272]
    89e8:	b4000040 	cbz	x0, 89f0 <fwp_main_thread+0x210>
    89ec:	f9008401 	str	x1, [x0, #264]
    89f0:	910802a0 	add	x0, x21, #0x200
    89f4:	390156bf 	strb	wzr, [x21, #85]
    89f8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    89fc:	17ffffd1 	b	8940 <fwp_main_thread+0x160>
    8a00:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8a04:	91301000 	add	x0, x0, #0xc04
    8a08:	94000a2a 	bl	b2b0 <atexit>
    8a0c:	17ffff87 	b	8828 <fwp_main_thread+0x48>
    8a10:	97ffecd8 	bl	3d70 <fwp_heap_init>
    8a14:	17ffff82 	b	881c <fwp_main_thread+0x3c>
    8a18:	f941cae4 	ldr	x4, [x23, #912]
    8a1c:	f90123fb 	str	x27, [sp, #576]
    8a20:	f90127fc 	str	x28, [sp, #584]
    8a24:	910203e1 	add	x1, sp, #0x80
    8a28:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0x50>
    8a2c:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8a30:	913fc000 	add	x0, x0, #0xff0
    8a34:	913d4042 	add	x2, x2, #0xf50
    8a38:	d280001c 	mov	x28, #0x0                   	// #0
    8a3c:	d280401b 	mov	x27, #0x200                 	// #512
    8a40:	390003f9 	strb	w25, [sp]
    8a44:	d2800019 	mov	x25, #0x0                   	// #0
    8a48:	a900d7e1 	stp	x1, x21, [sp, #8]
    8a4c:	aa1a03f5 	mov	x21, x26
    8a50:	a9080be4 	stp	x4, x2, [sp, #128]
    8a54:	f9004bf8 	str	x24, [sp, #144]
    8a58:	f90067ff 	str	xzr, [sp, #200]
    8a5c:	a90d83ff 	stp	xzr, x0, [sp, #216]
    8a60:	f901cae1 	str	x1, [x23, #912]
    8a64:	14000012 	b	8aac <fwp_main_thread+0x2cc>
    8a68:	7100045f 	cmp	w2, #0x1
    8a6c:	540001a1 	b.ne	8aa0 <fwp_main_thread+0x2c0>  // b.any
    8a70:	29430002 	ldp	w2, w0, [x0, #24]
    8a74:	92403c21 	and	x1, x1, #0xffff
    8a78:	9b027c21 	mul	x1, x1, x2
    8a7c:	d360fc21 	lsr	x1, x1, #32
    8a80:	eb00003f 	cmp	x1, x0
    8a84:	540000e2 	b.cs	8aa0 <fwp_main_thread+0x2c0>  // b.hs, b.nlast
    8a88:	8b01035a 	add	x26, x26, x1
    8a8c:	39400340 	ldrb	w0, [x26]
    8a90:	7103fc1f 	cmp	w0, #0xff
    8a94:	54003e80 	b.eq	9264 <fwp_main_thread+0xa84>  // b.none
    8a98:	394003e0 	ldrb	w0, [sp]
    8a9c:	39000340 	strb	w0, [x26]
    8aa0:	a90cfffc 	stp	x28, xzr, [sp, #200]
    8aa4:	aa170318 	orr	x24, x24, x23
    8aa8:	b4001bf8 	cbz	x24, 8e24 <fwp_main_thread+0x644>
    8aac:	f1000778 	subs	x24, x27, #0x1
    8ab0:	aa1603e1 	mov	x1, x22
    8ab4:	da1f0337 	sbc	x23, x25, xzr
    8ab8:	52800020 	mov	w0, #0x1                   	// #1
    8abc:	f9006bf8 	str	x24, [sp, #208]
    8ac0:	aa1803fb 	mov	x27, x24
    8ac4:	a91573f8 	stp	x24, x28, [sp, #336]
    8ac8:	97fff1f6 	bl	52a0 <fwp_data.part.0.constprop.0>
    8acc:	aa0003fc 	mov	x28, x0
    8ad0:	f949daa1 	ldr	x1, [x21, #5040]
    8ad4:	aa1703f9 	mov	x25, x23
    8ad8:	f949eea0 	ldr	x0, [x21, #5080]
    8adc:	cb010381 	sub	x1, x28, x1
    8ae0:	eb00403f 	cmp	x1, x0, lsl #16
    8ae4:	54fffde2 	b.cs	8aa0 <fwp_main_thread+0x2c0>  // b.hs, b.nlast
    8ae8:	d350fc22 	lsr	x2, x1, #16
    8aec:	f949fea5 	ldr	x5, [x21, #5112]
    8af0:	8b020842 	add	x2, x2, x2, lsl #2
    8af4:	d37df042 	lsl	x2, x2, #3
    8af8:	8b0200a0 	add	x0, x5, x2
    8afc:	f940101a 	ldr	x26, [x0, #32]
    8b00:	b4fffd1a 	cbz	x26, 8aa0 <fwp_main_thread+0x2c0>
    8b04:	386268a2 	ldrb	w2, [x5, x2]
    8b08:	7100085f 	cmp	w2, #0x2
    8b0c:	54fffae1 	b.ne	8a68 <fwp_main_thread+0x288>  // b.any
    8b10:	72003c3f 	tst	w1, #0xffff
    8b14:	54fffc61 	b.ne	8aa0 <fwp_main_thread+0x2c0>  // b.any
    8b18:	17ffffdd 	b	8a8c <fwp_main_thread+0x2ac>
    8b1c:	97fff025 	bl	4bb0 <fwp_now_ns>
    8b20:	f94032c1 	ldr	x1, [x22, #96]
    8b24:	eb01001f 	cmp	x0, x1
    8b28:	540000ab 	b.lt	8b3c <fwp_main_thread+0x35c>  // b.tstop
    8b2c:	394142c0 	ldrb	w0, [x22, #80]
    8b30:	37000060 	tbnz	w0, #0, 8b3c <fwp_main_thread+0x35c>
    8b34:	aa1603e0 	mov	x0, x22
    8b38:	97ffeaee 	bl	36f0 <fwp_cancel_tree.part.0>
    8b3c:	394146c0 	ldrb	w0, [x22, #81]
    8b40:	f9404f55 	ldr	x21, [x26, #152]
    8b44:	39414aa2 	ldrb	w2, [x21, #82]
    8b48:	3707f080 	tbnz	w0, #0, 8958 <fwp_main_thread+0x178>
    8b4c:	f94032c1 	ldr	x1, [x22, #96]
    8b50:	370001c2 	tbnz	w2, #0, 8b88 <fwp_main_thread+0x3a8>
    8b54:	f94032a0 	ldr	x0, [x21, #96]
    8b58:	b4000180 	cbz	x0, 8b88 <fwp_main_thread+0x3a8>
    8b5c:	b4000061 	cbz	x1, 8b68 <fwp_main_thread+0x388>
    8b60:	eb01001f 	cmp	x0, x1
    8b64:	9a81d000 	csel	x0, x0, x1, le
    8b68:	f94022c1 	ldr	x1, [x22, #64]
    8b6c:	a911feb7 	stp	x23, xzr, [x21, #280]
    8b70:	f90096a1 	str	x1, [x21, #296]
    8b74:	b40037e1 	cbz	x1, 9270 <fwp_main_thread+0xa90>
    8b78:	f9009035 	str	x21, [x1, #288]
    8b7c:	aa0003e1 	mov	x1, x0
    8b80:	f90022d5 	str	x21, [x22, #64]
    8b84:	17ffff80 	b	8984 <fwp_main_thread+0x1a4>
    8b88:	f94022c0 	ldr	x0, [x22, #64]
    8b8c:	17ffff78 	b	896c <fwp_main_thread+0x18c>
    8b90:	a911feb7 	stp	x23, xzr, [x21, #280]
    8b94:	f90096a0 	str	x0, [x21, #296]
    8b98:	b4000040 	cbz	x0, 8ba0 <fwp_main_thread+0x3c0>
    8b9c:	f9009015 	str	x21, [x0, #288]
    8ba0:	f90022d5 	str	x21, [x22, #64]
    8ba4:	17ffff7f 	b	89a0 <fwp_main_thread+0x1c0>
    8ba8:	f9000040 	str	x0, [x2]
    8bac:	17ffff85 	b	89c0 <fwp_main_thread+0x1e0>
    8bb0:	39014ad9 	strb	w25, [x22, #82]
    8bb4:	91014295 	add	x21, x20, #0x50
    8bb8:	f941d6a0 	ldr	x0, [x21, #936]
    8bbc:	b5000060 	cbnz	x0, 8bc8 <fwp_main_thread+0x3e8>
    8bc0:	f941dea0 	ldr	x0, [x21, #952]
    8bc4:	b4004c00 	cbz	x0, 9544 <fwp_main_thread+0xd64>
    8bc8:	91014280 	add	x0, x20, #0x50
    8bcc:	f9404c00 	ldr	x0, [x0, #152]
    8bd0:	91014281 	add	x1, x20, #0x50
    8bd4:	f941f026 	ldr	x6, [x1, #992]
    8bd8:	b903d83f 	str	wzr, [x1, #984]
    8bdc:	eb0000df 	cmp	x6, x0
    8be0:	5400fe81 	b.ne	abb0 <fwp_main_thread+0x23d0>  // b.any
    8be4:	b40003c0 	cbz	x0, 8c5c <fwp_main_thread+0x47c>
    8be8:	f941c025 	ldr	x5, [x1, #896]
    8bec:	52800021 	mov	w1, #0x1                   	// #1
    8bf0:	39014801 	strb	w1, [x0, #82]
    8bf4:	b4000345 	cbz	x5, 8c5c <fwp_main_thread+0x47c>
    8bf8:	394140a0 	ldrb	w0, [x5, #80]
    8bfc:	37000060 	tbnz	w0, #0, 8c08 <fwp_main_thread+0x428>
    8c00:	aa0503e0 	mov	x0, x5
    8c04:	97ffeabb 	bl	36f0 <fwp_cancel_tree.part.0>
    8c08:	f9409ca5 	ldr	x5, [x5, #312]
    8c0c:	b5ffff65 	cbnz	x5, 8bf8 <fwp_main_thread+0x418>
    8c10:	91014295 	add	x21, x20, #0x50
    8c14:	52800036 	mov	w22, #0x1                   	// #1
    8c18:	f94028c0 	ldr	x0, [x6, #80]
    8c1c:	f2001c1f 	tst	x0, #0xff000000ff
    8c20:	540000e1 	b.ne	8c3c <fwp_main_thread+0x45c>  // b.any
    8c24:	f94062a0 	ldr	x0, [x21, #192]
    8c28:	390150d6 	strb	w22, [x6, #84]
    8c2c:	f90080df 	str	xzr, [x6, #256]
    8c30:	b4000120 	cbz	x0, 8c54 <fwp_main_thread+0x474>
    8c34:	f9008006 	str	x6, [x0, #256]
    8c38:	f90062a6 	str	x6, [x21, #192]
    8c3c:	97fff845 	bl	6d50 <fwp_block>
    8c40:	97fff7cc 	bl	6b70 <fwp_free_zombie>
    8c44:	f941c2a0 	ldr	x0, [x21, #896]
    8c48:	b40000a0 	cbz	x0, 8c5c <fwp_main_thread+0x47c>
    8c4c:	f941f2a6 	ldr	x6, [x21, #992]
    8c50:	17fffff2 	b	8c18 <fwp_main_thread+0x438>
    8c54:	f90066a6 	str	x6, [x21, #200]
    8c58:	17fffff8 	b	8c38 <fwp_main_thread+0x458>
    8c5c:	91014296 	add	x22, x20, #0x50
    8c60:	97fff7c4 	bl	6b70 <fwp_free_zombie>
    8c64:	f94066c0 	ldr	x0, [x22, #200]
    8c68:	b500fa40 	cbnz	x0, abb0 <fwp_main_thread+0x23d0>
    8c6c:	f94096c0 	ldr	x0, [x22, #296]
    8c70:	b500fa00 	cbnz	x0, abb0 <fwp_main_thread+0x23d0>
    8c74:	b94172d5 	ldr	w21, [x22, #368]
    8c78:	340001f5 	cbz	w21, 8cb4 <fwp_main_thread+0x4d4>
    8c7c:	93407eb7 	sxtw	x23, w21
    8c80:	510006b5 	sub	w21, w21, #0x1
    8c84:	d1000af7 	sub	x23, x23, #0x2
    8c88:	910602d8 	add	x24, x22, #0x180
    8c8c:	cb3542f7 	sub	x23, x23, w21, uxtw
    8c90:	93407eb5 	sxtw	x21, w21
    8c94:	d503201f 	nop
    8c98:	f8757b00 	ldr	x0, [x24, x21, lsl #3]
    8c9c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8ca0:	b90172d5 	str	w21, [x22, #368]
    8ca4:	d10006b5 	sub	x21, x21, #0x1
    8ca8:	97ffe746 	bl	29c0 <munmap@plt>
    8cac:	eb1702bf 	cmp	x21, x23
    8cb0:	54ffff41 	b.ne	8c98 <fwp_main_thread+0x4b8>  // b.any
    8cb4:	900000d7 	adrp	x23, 20000 <__data_start>
    8cb8:	910042e0 	add	x0, x23, #0x10
    8cbc:	b9402800 	ldr	w0, [x0, #40]
    8cc0:	37f80040 	tbnz	w0, #31, 8cc8 <fwp_main_thread+0x4e8>
    8cc4:	97ffe6fb 	bl	28b0 <close@plt>
    8cc8:	91014296 	add	x22, x20, #0x50
    8ccc:	910042f7 	add	x23, x23, #0x10
    8cd0:	12800001 	mov	w1, #0xffffffff            	// #-1
    8cd4:	f941fac0 	ldr	x0, [x22, #1008]
    8cd8:	b9002ae1 	str	w1, [x23, #40]
    8cdc:	f941f6c1 	ldr	x1, [x22, #1000]
    8ce0:	b40001c0 	cbz	x0, 8d18 <fwp_main_thread+0x538>
    8ce4:	d2800015 	mov	x21, #0x0                   	// #0
    8ce8:	f8757820 	ldr	x0, [x1, x21, lsl #3]
    8cec:	b40000e0 	cbz	x0, 8d08 <fwp_main_thread+0x528>
    8cf0:	f9400001 	ldr	x1, [x0]
    8cf4:	b500f5e1 	cbnz	x1, abb0 <fwp_main_thread+0x23d0>
    8cf8:	f9400401 	ldr	x1, [x0, #8]
    8cfc:	b500f5a1 	cbnz	x1, abb0 <fwp_main_thread+0x23d0>
    8d00:	97ffee48 	bl	4620 <fwp_mem_free>
    8d04:	f941f6c1 	ldr	x1, [x22, #1000]
    8d08:	910006b5 	add	x21, x21, #0x1
    8d0c:	f941fac0 	ldr	x0, [x22, #1008]
    8d10:	eb0002bf 	cmp	x21, x0
    8d14:	54fffea3 	b.cc	8ce8 <fwp_main_thread+0x508>  // b.lo, b.ul, b.last
    8d18:	aa0103e0 	mov	x0, x1
    8d1c:	97ffee41 	bl	4620 <fwp_mem_free>
    8d20:	91014280 	add	x0, x20, #0x50
    8d24:	f941f015 	ldr	x21, [x0, #992]
    8d28:	f901f41f 	str	xzr, [x0, #1000]
    8d2c:	f901f81f 	str	xzr, [x0, #1008]
    8d30:	b40001f5 	cbz	x21, 8d6c <fwp_main_thread+0x58c>
    8d34:	f94016a1 	ldr	x1, [x21, #40]
    8d38:	b500f3c1 	cbnz	x1, abb0 <fwp_main_thread+0x23d0>
    8d3c:	f94056a1 	ldr	x1, [x21, #168]
    8d40:	b500f381 	cbnz	x1, abb0 <fwp_main_thread+0x23d0>
    8d44:	f941d401 	ldr	x1, [x0, #936]
    8d48:	b500f341 	cbnz	x1, abb0 <fwp_main_thread+0x23d0>
    8d4c:	f941dc00 	ldr	x0, [x0, #952]
    8d50:	b500f300 	cbnz	x0, abb0 <fwp_main_thread+0x23d0>
    8d54:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8d58:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    8d5c:	91114000 	add	x0, x0, #0x450
    8d60:	97ffe6c4 	bl	2870 <memset@plt>
    8d64:	aa1503e0 	mov	x0, x21
    8d68:	97ffee2e 	bl	4620 <fwp_mem_free>
    8d6c:	91014286 	add	x6, x20, #0x50
    8d70:	9118c273 	add	x19, x19, #0x630
    8d74:	3dc01682 	ldr	q2, [x20, #80]
    8d78:	52800041 	mov	w1, #0x2                   	// #2
    8d7c:	3dc004c1 	ldr	q1, [x6, #16]
    8d80:	f0000002 	adrp	x2, b000 <__modti3+0xc0>
    8d84:	fd4a1260 	ldr	d0, [x19, #5152]
    8d88:	912ba042 	add	x2, x2, #0xae8
    8d8c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8d90:	fd40a4c1 	ldr	d1, [x6, #328]
    8d94:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8d98:	f947e800 	ldr	x0, [x0, #4048]
    8d9c:	7e61d800 	ucvtf	d0, d0
    8da0:	a95390c3 	ldp	x3, x4, [x6, #312]
    8da4:	f9004cdf 	str	xzr, [x6, #152]
    8da8:	f9400000 	ldr	x0, [x0]
    8dac:	1e613801 	fsub	d1, d0, d1
    8db0:	f940acc5 	ldr	x5, [x6, #344]
    8db4:	b90130df 	str	wzr, [x6, #304]
    8db8:	5ef1b842 	addp	d2, v2.2d
    8dbc:	fd40a8c0 	ldr	d0, [x6, #336]
    8dc0:	f901f0df 	str	xzr, [x6, #992]
    8dc4:	fd0058c2 	str	d2, [x6, #176]
    8dc8:	97ffe6d2 	bl	2910 <__fprintf_chk@plt>
    8dcc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8dd0:	f947ec00 	ldr	x0, [x0, #4056]
    8dd4:	f9400000 	ldr	x0, [x0]
    8dd8:	97ffe6fe 	bl	29d0 <fflush@plt>
    8ddc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8de0:	f947f400 	ldr	x0, [x0, #4072]
    8de4:	f940f7e2 	ldr	x2, [sp, #488]
    8de8:	f9400001 	ldr	x1, [x0]
    8dec:	eb010042 	subs	x2, x2, x1
    8df0:	d2800001 	mov	x1, #0x0                   	// #0
    8df4:	5400a481 	b.ne	a284 <fwp_main_thread+0x1aa4>  // b.any
    8df8:	f9411bf9 	ldr	x25, [sp, #560]
    8dfc:	d2800000 	mov	x0, #0x0                   	// #0
    8e00:	f9411ffa 	ldr	x26, [sp, #568]
    8e04:	9107c3ff 	add	sp, sp, #0x1f0
    8e08:	a94153f3 	ldp	x19, x20, [sp, #16]
    8e0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8e10:	a94363f7 	ldp	x23, x24, [sp, #48]
    8e14:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8e18:	d65f03c0 	ret
    8e1c:	f9009740 	str	x0, [x26, #296]
    8e20:	17fffef2 	b	89e8 <fwp_main_thread+0x208>
    8e24:	a940d7e1 	ldp	x1, x21, [sp, #8]
    8e28:	91014282 	add	x2, x20, #0x50
    8e2c:	f90067ff 	str	xzr, [sp, #200]
    8e30:	f941c840 	ldr	x0, [x2, #912]
    8e34:	eb01001f 	cmp	x0, x1
    8e38:	5400ec01 	b.ne	abb8 <fwp_main_thread+0x23d8>  // b.any
    8e3c:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xd20>
    8e40:	910483e1 	add	x1, sp, #0x120
    8e44:	f94043e3 	ldr	x3, [sp, #128]
    8e48:	f901c843 	str	x3, [x2, #912]
    8e4c:	3dc0b000 	ldr	q0, [x0, #704]
    8e50:	52800020 	mov	w0, #0x1                   	// #1
    8e54:	3d804be0 	str	q0, [sp, #288]
    8e58:	97fff112 	bl	52a0 <fwp_data.part.0.constprop.0>
    8e5c:	9118c263 	add	x3, x19, #0x630
    8e60:	aa0003f8 	mov	x24, x0
    8e64:	f949d861 	ldr	x1, [x3, #5040]
    8e68:	f949ec62 	ldr	x2, [x3, #5080]
    8e6c:	cb010001 	sub	x1, x0, x1
    8e70:	eb02403f 	cmp	x1, x2, lsl #16
    8e74:	54000322 	b.cs	8ed8 <fwp_main_thread+0x6f8>  // b.hs, b.nlast
    8e78:	d350fc22 	lsr	x2, x1, #16
    8e7c:	f949fc64 	ldr	x4, [x3, #5112]
    8e80:	8b020842 	add	x2, x2, x2, lsl #2
    8e84:	d37df042 	lsl	x2, x2, #3
    8e88:	8b020083 	add	x3, x4, x2
    8e8c:	f9401077 	ldr	x23, [x3, #32]
    8e90:	b4000257 	cbz	x23, 8ed8 <fwp_main_thread+0x6f8>
    8e94:	38626880 	ldrb	w0, [x4, x2]
    8e98:	7100081f 	cmp	w0, #0x2
    8e9c:	54001f60 	b.eq	9288 <fwp_main_thread+0xaa8>  // b.none
    8ea0:	7100041f 	cmp	w0, #0x1
    8ea4:	540001a1 	b.ne	8ed8 <fwp_main_thread+0x6f8>  // b.any
    8ea8:	29430062 	ldp	w2, w0, [x3, #24]
    8eac:	92403c21 	and	x1, x1, #0xffff
    8eb0:	9b027c21 	mul	x1, x1, x2
    8eb4:	d360fc21 	lsr	x1, x1, #32
    8eb8:	eb00003f 	cmp	x1, x0
    8ebc:	540000e2 	b.cs	8ed8 <fwp_main_thread+0x6f8>  // b.hs, b.nlast
    8ec0:	8b0102f7 	add	x23, x23, x1
    8ec4:	394002e0 	ldrb	w0, [x23]
    8ec8:	7103fc1f 	cmp	w0, #0xff
    8ecc:	540065a0 	b.eq	9b80 <fwp_main_thread+0x13a0>  // b.none
    8ed0:	52800020 	mov	w0, #0x1                   	// #1
    8ed4:	390002e0 	strb	w0, [x23]
    8ed8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8edc:	910503e1 	add	x1, sp, #0x140
    8ee0:	52800020 	mov	w0, #0x1                   	// #1
    8ee4:	a91463e2 	stp	x2, x24, [sp, #320]
    8ee8:	97fff0ee 	bl	52a0 <fwp_data.part.0.constprop.0>
    8eec:	9118c263 	add	x3, x19, #0x630
    8ef0:	aa0003f8 	mov	x24, x0
    8ef4:	f949d861 	ldr	x1, [x3, #5040]
    8ef8:	f949ec62 	ldr	x2, [x3, #5080]
    8efc:	cb010001 	sub	x1, x0, x1
    8f00:	eb02403f 	cmp	x1, x2, lsl #16
    8f04:	54000322 	b.cs	8f68 <fwp_main_thread+0x788>  // b.hs, b.nlast
    8f08:	d350fc22 	lsr	x2, x1, #16
    8f0c:	f949fc64 	ldr	x4, [x3, #5112]
    8f10:	8b020842 	add	x2, x2, x2, lsl #2
    8f14:	d37df042 	lsl	x2, x2, #3
    8f18:	8b020083 	add	x3, x4, x2
    8f1c:	f9401077 	ldr	x23, [x3, #32]
    8f20:	b4000257 	cbz	x23, 8f68 <fwp_main_thread+0x788>
    8f24:	38626880 	ldrb	w0, [x4, x2]
    8f28:	7100081f 	cmp	w0, #0x2
    8f2c:	54001b40 	b.eq	9294 <fwp_main_thread+0xab4>  // b.none
    8f30:	7100041f 	cmp	w0, #0x1
    8f34:	540001a1 	b.ne	8f68 <fwp_main_thread+0x788>  // b.any
    8f38:	29430062 	ldp	w2, w0, [x3, #24]
    8f3c:	92403c21 	and	x1, x1, #0xffff
    8f40:	9b027c21 	mul	x1, x1, x2
    8f44:	d360fc21 	lsr	x1, x1, #32
    8f48:	eb00003f 	cmp	x1, x0
    8f4c:	540000e2 	b.cs	8f68 <fwp_main_thread+0x788>  // b.hs, b.nlast
    8f50:	8b0102f7 	add	x23, x23, x1
    8f54:	394002e0 	ldrb	w0, [x23]
    8f58:	7103fc1f 	cmp	w0, #0xff
    8f5c:	54006180 	b.eq	9b8c <fwp_main_thread+0x13ac>  // b.none
    8f60:	52800020 	mov	w0, #0x1                   	// #1
    8f64:	390002e0 	strb	w0, [x23]
    8f68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8f6c:	9104c3e1 	add	x1, sp, #0x130
    8f70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8f74:	52800020 	mov	w0, #0x1                   	// #1
    8f78:	a91363e2 	stp	x2, x24, [sp, #304]
    8f7c:	97fff0c9 	bl	52a0 <fwp_data.part.0.constprop.0>
    8f80:	9118c262 	add	x2, x19, #0x630
    8f84:	aa0003fb 	mov	x27, x0
    8f88:	f949d841 	ldr	x1, [x2, #5040]
    8f8c:	f949ec40 	ldr	x0, [x2, #5080]
    8f90:	cb010361 	sub	x1, x27, x1
    8f94:	eb00403f 	cmp	x1, x0, lsl #16
    8f98:	54000322 	b.cs	8ffc <fwp_main_thread+0x81c>  // b.hs, b.nlast
    8f9c:	d350fc20 	lsr	x0, x1, #16
    8fa0:	f949fc43 	ldr	x3, [x2, #5112]
    8fa4:	8b000800 	add	x0, x0, x0, lsl #2
    8fa8:	d37df002 	lsl	x2, x0, #3
    8fac:	8b020060 	add	x0, x3, x2
    8fb0:	f9401017 	ldr	x23, [x0, #32]
    8fb4:	b4000257 	cbz	x23, 8ffc <fwp_main_thread+0x81c>
    8fb8:	38626862 	ldrb	w2, [x3, x2]
    8fbc:	7100085f 	cmp	w2, #0x2
    8fc0:	54001700 	b.eq	92a0 <fwp_main_thread+0xac0>  // b.none
    8fc4:	7100045f 	cmp	w2, #0x1
    8fc8:	540001a1 	b.ne	8ffc <fwp_main_thread+0x81c>  // b.any
    8fcc:	29430002 	ldp	w2, w0, [x0, #24]
    8fd0:	92403c21 	and	x1, x1, #0xffff
    8fd4:	9b027c21 	mul	x1, x1, x2
    8fd8:	d360fc21 	lsr	x1, x1, #32
    8fdc:	eb00003f 	cmp	x1, x0
    8fe0:	540000e2 	b.cs	8ffc <fwp_main_thread+0x81c>  // b.hs, b.nlast
    8fe4:	8b0102f7 	add	x23, x23, x1
    8fe8:	394002e0 	ldrb	w0, [x23]
    8fec:	7103fc1f 	cmp	w0, #0xff
    8ff0:	54005c20 	b.eq	9b74 <fwp_main_thread+0x1394>  // b.none
    8ff4:	52800020 	mov	w0, #0x1                   	// #1
    8ff8:	390002e0 	strb	w0, [x23]
    8ffc:	b40043fc 	cbz	x28, 9878 <fwp_main_thread+0x1098>
    9000:	f00000b7 	adrp	x23, 20000 <__data_start>
    9004:	b0fffffa 	adrp	x26, 6000 <fwp_drop1+0x10>
    9008:	910042f7 	add	x23, x23, #0x10
    900c:	911a0340 	add	x0, x26, #0x680
    9010:	910082f7 	add	x23, x23, #0x20
    9014:	9118c278 	add	x24, x19, #0x630
    9018:	91014299 	add	x25, x20, #0x50
    901c:	a90173e0 	stp	x0, x28, [sp, #16]
    9020:	9101e3e0 	add	x0, sp, #0x78
    9024:	f90003e0 	str	x0, [sp]
    9028:	910263e0 	add	x0, sp, #0x98
    902c:	f90007e0 	str	x0, [sp, #8]
    9030:	f90013fc 	str	x28, [sp, #32]
    9034:	f949ef04 	ldr	x4, [x24, #5080]
    9038:	f949db01 	ldr	x1, [x24, #5040]
    903c:	d370bc84 	lsl	x4, x4, #16
    9040:	cb010363 	sub	x3, x27, x1
    9044:	eb04007f 	cmp	x3, x4
    9048:	540004a2 	b.cs	90dc <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    904c:	d350fc60 	lsr	x0, x3, #16
    9050:	f949ff06 	ldr	x6, [x24, #5112]
    9054:	8b000800 	add	x0, x0, x0, lsl #2
    9058:	d37df002 	lsl	x2, x0, #3
    905c:	8b0200c5 	add	x5, x6, x2
    9060:	f94010a0 	ldr	x0, [x5, #32]
    9064:	b40003c0 	cbz	x0, 90dc <fwp_main_thread+0x8fc>
    9068:	386268c2 	ldrb	w2, [x6, x2]
    906c:	7100085f 	cmp	w2, #0x2
    9070:	540011e0 	b.eq	92ac <fwp_main_thread+0xacc>  // b.none
    9074:	7100045f 	cmp	w2, #0x1
    9078:	54000321 	b.ne	90dc <fwp_main_thread+0x8fc>  // b.any
    907c:	92403c62 	and	x2, x3, #0xffff
    9080:	29430ca6 	ldp	w6, w3, [x5, #24]
    9084:	9b067c42 	mul	x2, x2, x6
    9088:	d360fc42 	lsr	x2, x2, #32
    908c:	eb03005f 	cmp	x2, x3
    9090:	54000262 	b.cs	90dc <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    9094:	8b020000 	add	x0, x0, x2
    9098:	39400002 	ldrb	w2, [x0]
    909c:	34000202 	cbz	w2, 90dc <fwp_main_thread+0x8fc>
    90a0:	91014281 	add	x1, x20, #0x50
    90a4:	b9413023 	ldr	w3, [x1, #304]
    90a8:	34000083 	cbz	w3, 90b8 <fwp_main_thread+0x8d8>
    90ac:	f940ac23 	ldr	x3, [x1, #344]
    90b0:	91000463 	add	x3, x3, #0x1
    90b4:	f900ac23 	str	x3, [x1, #344]
    90b8:	7103f45f 	cmp	w2, #0xfd
    90bc:	54005d88 	b.hi	9c6c <fwp_main_thread+0x148c>  // b.pmore
    90c0:	9118c261 	add	x1, x19, #0x630
    90c4:	11000442 	add	w2, w2, #0x1
    90c8:	39000002 	strb	w2, [x0]
    90cc:	aa0103e0 	mov	x0, x1
    90d0:	f949d821 	ldr	x1, [x1, #5040]
    90d4:	f949ec04 	ldr	x4, [x0, #5080]
    90d8:	d370bc84 	lsl	x4, x4, #16
    90dc:	f941cb20 	ldr	x0, [x25, #912]
    90e0:	f9004fe0 	str	x0, [sp, #152]
    90e4:	f9400be0 	ldr	x0, [sp, #16]
    90e8:	f90053e0 	str	x0, [sp, #160]
    90ec:	f94003e0 	ldr	x0, [sp]
    90f0:	f90057e0 	str	x0, [sp, #168]
    90f4:	f94007e0 	ldr	x0, [sp, #8]
    90f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    90fc:	cb0102e1 	sub	x1, x23, x1
    9100:	b9007be2 	str	w2, [sp, #120]
    9104:	f901cb20 	str	x0, [x25, #912]
    9108:	eb04003f 	cmp	x1, x4
    910c:	54000822 	b.cs	9210 <fwp_main_thread+0xa30>  // b.hs, b.nlast
    9110:	9118c262 	add	x2, x19, #0x630
    9114:	d350fc20 	lsr	x0, x1, #16
    9118:	8b000800 	add	x0, x0, x0, lsl #2
    911c:	f949fc44 	ldr	x4, [x2, #5112]
    9120:	d37df003 	lsl	x3, x0, #3
    9124:	8b030082 	add	x2, x4, x3
    9128:	f940105c 	ldr	x28, [x2, #32]
    912c:	b400073c 	cbz	x28, 9210 <fwp_main_thread+0xa30>
    9130:	38636880 	ldrb	w0, [x4, x3]
    9134:	7100081f 	cmp	w0, #0x2
    9138:	54000c00 	b.eq	92b8 <fwp_main_thread+0xad8>  // b.none
    913c:	7100041f 	cmp	w0, #0x1
    9140:	54000681 	b.ne	9210 <fwp_main_thread+0xa30>  // b.any
    9144:	29430c44 	ldp	w4, w3, [x2, #24]
    9148:	92403c20 	and	x0, x1, #0xffff
    914c:	9b047c00 	mul	x0, x0, x4
    9150:	d360fc00 	lsr	x0, x0, #32
    9154:	eb03001f 	cmp	x0, x3
    9158:	54000342 	b.cs	91c0 <fwp_main_thread+0x9e0>  // b.hs, b.nlast
    915c:	8b000380 	add	x0, x28, x0
    9160:	39400003 	ldrb	w3, [x0]
    9164:	340002e3 	cbz	w3, 91c0 <fwp_main_thread+0x9e0>
    9168:	91014281 	add	x1, x20, #0x50
    916c:	b9413022 	ldr	w2, [x1, #304]
    9170:	34000082 	cbz	w2, 9180 <fwp_main_thread+0x9a0>
    9174:	f940ac22 	ldr	x2, [x1, #344]
    9178:	91000442 	add	x2, x2, #0x1
    917c:	f900ac22 	str	x2, [x1, #344]
    9180:	7103f47f 	cmp	w3, #0xfd
    9184:	54005808 	b.hi	9c84 <fwp_main_thread+0x14a4>  // b.pmore
    9188:	11000463 	add	w3, w3, #0x1
    918c:	39000003 	strb	w3, [x0]
    9190:	9118c260 	add	x0, x19, #0x630
    9194:	f949d801 	ldr	x1, [x0, #5040]
    9198:	f949ec02 	ldr	x2, [x0, #5080]
    919c:	cb0102e1 	sub	x1, x23, x1
    91a0:	eb02403f 	cmp	x1, x2, lsl #16
    91a4:	54000362 	b.cs	9210 <fwp_main_thread+0xa30>  // b.hs, b.nlast
    91a8:	f949fc02 	ldr	x2, [x0, #5112]
    91ac:	d350fc20 	lsr	x0, x1, #16
    91b0:	8b000800 	add	x0, x0, x0, lsl #2
    91b4:	8b000c42 	add	x2, x2, x0, lsl #3
    91b8:	f940105c 	ldr	x28, [x2, #32]
    91bc:	b40002bc 	cbz	x28, 9210 <fwp_main_thread+0xa30>
    91c0:	39400040 	ldrb	w0, [x2]
    91c4:	7100081f 	cmp	w0, #0x2
    91c8:	54000800 	b.eq	92c8 <fwp_main_thread+0xae8>  // b.none
    91cc:	7100041f 	cmp	w0, #0x1
    91d0:	54000201 	b.ne	9210 <fwp_main_thread+0xa30>  // b.any
    91d4:	29430043 	ldp	w3, w0, [x2, #24]
    91d8:	92403c21 	and	x1, x1, #0xffff
    91dc:	9b037c21 	mul	x1, x1, x3
    91e0:	d360fc21 	lsr	x1, x1, #32
    91e4:	eb00003f 	cmp	x1, x0
    91e8:	54000142 	b.cs	9210 <fwp_main_thread+0xa30>  // b.hs, b.nlast
    91ec:	8b01039c 	add	x28, x28, x1
    91f0:	39400380 	ldrb	w0, [x28]
    91f4:	340000e0 	cbz	w0, 9210 <fwp_main_thread+0xa30>
    91f8:	7100041f 	cmp	w0, #0x1
    91fc:	54000240 	b.eq	9244 <fwp_main_thread+0xa64>  // b.none
    9200:	7103fc1f 	cmp	w0, #0xff
    9204:	54005440 	b.eq	9c8c <fwp_main_thread+0x14ac>  // b.none
    9208:	51000400 	sub	w0, w0, #0x1
    920c:	39000380 	strb	w0, [x28]
    9210:	b4004afb 	cbz	x27, 9b6c <fwp_main_thread+0x138c>
    9214:	aa1b03e0 	mov	x0, x27
    9218:	d2800001 	mov	x1, #0x0                   	// #0
    921c:	d503201f 	nop
    9220:	f9400800 	ldr	x0, [x0, #16]
    9224:	91000421 	add	x1, x1, #0x1
    9228:	b5ffffc0 	cbnz	x0, 9220 <fwp_main_thread+0xa40>
    922c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    9230:	eb00003f 	cmp	x1, x0
    9234:	54000509 	b.ls	92d4 <fwp_main_thread+0xaf4>  // b.plast
    9238:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    923c:	9128a000 	add	x0, x0, #0xa28
    9240:	97ffec3d 	bl	4334 <fwp_trap>
    9244:	d53bd040 	mrs	x0, tpidr_el0
    9248:	91400000 	add	x0, x0, #0x0, lsl #12
    924c:	91004000 	add	x0, x0, #0x10
    9250:	f9400000 	ldr	x0, [x0]
    9254:	b4000140 	cbz	x0, 927c <fwp_main_thread+0xa9c>
    9258:	aa1703e1 	mov	x1, x23
    925c:	97ffedb1 	bl	4920 <fwp_closure_drop_push>
    9260:	17ffffec 	b	9210 <fwp_main_thread+0xa30>
    9264:	aa1a03e0 	mov	x0, x26
    9268:	97ffec53 	bl	43b4 <fwp_rc_forget_slot.part.0>
    926c:	17fffe0b 	b	8a98 <fwp_main_thread+0x2b8>
    9270:	aa0003e1 	mov	x1, x0
    9274:	f90022d5 	str	x21, [x22, #64]
    9278:	17fffdc3 	b	8984 <fwp_main_thread+0x1a4>
    927c:	aa1703e0 	mov	x0, x23
    9280:	97ffeded 	bl	4a34 <fwp_closure_drop.part.0>
    9284:	17ffffe3 	b	9210 <fwp_main_thread+0xa30>
    9288:	72003c3f 	tst	w1, #0xffff
    928c:	54ffe261 	b.ne	8ed8 <fwp_main_thread+0x6f8>  // b.any
    9290:	17ffff0d 	b	8ec4 <fwp_main_thread+0x6e4>
    9294:	72003c3f 	tst	w1, #0xffff
    9298:	54ffe681 	b.ne	8f68 <fwp_main_thread+0x788>  // b.any
    929c:	17ffff2e 	b	8f54 <fwp_main_thread+0x774>
    92a0:	72003c3f 	tst	w1, #0xffff
    92a4:	54ffeac1 	b.ne	8ffc <fwp_main_thread+0x81c>  // b.any
    92a8:	17ffff50 	b	8fe8 <fwp_main_thread+0x808>
    92ac:	72003c7f 	tst	w3, #0xffff
    92b0:	54fff161 	b.ne	90dc <fwp_main_thread+0x8fc>  // b.any
    92b4:	17ffff79 	b	9098 <fwp_main_thread+0x8b8>
    92b8:	72003c3f 	tst	w1, #0xffff
    92bc:	54fff821 	b.ne	91c0 <fwp_main_thread+0x9e0>  // b.any
    92c0:	aa1c03e0 	mov	x0, x28
    92c4:	17ffffa7 	b	9160 <fwp_main_thread+0x980>
    92c8:	72003c3f 	tst	w1, #0xffff
    92cc:	54fffa21 	b.ne	9210 <fwp_main_thread+0xa30>  // b.any
    92d0:	17ffffc8 	b	91f0 <fwp_main_thread+0xa10>
    92d4:	aa0103fc 	mov	x28, x1
    92d8:	91014281 	add	x1, x20, #0x50
    92dc:	b943c820 	ldr	w0, [x1, #968]
    92e0:	34002e20 	cbz	w0, 98a4 <fwp_main_thread+0x10c4>
    92e4:	91014280 	add	x0, x20, #0x50
    92e8:	f9409003 	ldr	x3, [x0, #288]
    92ec:	f940b001 	ldr	x1, [x0, #352]
    92f0:	eb03003f 	cmp	x1, x3
    92f4:	54000faa 	b.ge	94e8 <fwp_main_thread+0xd08>  // b.tcont
    92f8:	f9404402 	ldr	x2, [x0, #136]
    92fc:	8b010420 	add	x0, x1, x1, lsl #1
    9300:	528fffc4 	mov	w4, #0x7ffe                	// #32766
    9304:	8b000820 	add	x0, x1, x0, lsl #2
    9308:	8b000c40 	add	x0, x2, x0, lsl #3
    930c:	d503201f 	nop
    9310:	b9400402 	ldr	w2, [x0, #4]
    9314:	35000082 	cbnz	w2, 9324 <fwp_main_thread+0xb44>
    9318:	b9400002 	ldr	w2, [x0]
    931c:	6b04005f 	cmp	w2, w4
    9320:	54000e49 	b.ls	94e8 <fwp_main_thread+0xd08>  // b.plast
    9324:	91000421 	add	x1, x1, #0x1
    9328:	9101a000 	add	x0, x0, #0x68
    932c:	eb03003f 	cmp	x1, x3
    9330:	54ffff01 	b.ne	9310 <fwp_main_thread+0xb30>  // b.any
    9334:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    9338:	eb00007f 	cmp	x3, x0
    933c:	5400492c 	b.gt	9c60 <fwp_main_thread+0x1480>
    9340:	91014280 	add	x0, x20, #0x50
    9344:	f9408800 	ldr	x0, [x0, #272]
    9348:	eb03001f 	cmp	x0, x3
    934c:	54000261 	b.ne	9398 <fwp_main_thread+0xbb8>  // b.any
    9350:	b40057a3 	cbz	x3, 9e44 <fwp_main_thread+0x1664>
    9354:	d37ff864 	lsl	x4, x3, #1
    9358:	d29fffe0 	mov	x0, #0xffff                	// #65535
    935c:	eb00009f 	cmp	x4, x0
    9360:	9a80d084 	csel	x4, x4, x0, le
    9364:	91014285 	add	x5, x20, #0x50
    9368:	d2800d01 	mov	x1, #0x68                  	// #104
    936c:	52800002 	mov	w2, #0x0                   	// #0
    9370:	a90293e5 	stp	x5, x4, [sp, #40]
    9374:	9b017c81 	mul	x1, x4, x1
    9378:	f94044a0 	ldr	x0, [x5, #136]
    937c:	f9001fe3 	str	x3, [sp, #56]
    9380:	97ffeb51 	bl	40c4 <ad_raw_realloc>
    9384:	a94293e5 	ldp	x5, x4, [sp, #40]
    9388:	f9401fe3 	ldr	x3, [sp, #56]
    938c:	b400b020 	cbz	x0, a990 <fwp_main_thread+0x21b0>
    9390:	f90044a0 	str	x0, [x5, #136]
    9394:	f90088a4 	str	x4, [x5, #272]
    9398:	91014282 	add	x2, x20, #0x50
    939c:	8b030460 	add	x0, x3, x3, lsl #1
    93a0:	4f000400 	movi	v0.4s, #0x0
    93a4:	aa0303e1 	mov	x1, x3
    93a8:	8b000860 	add	x0, x3, x0, lsl #2
    93ac:	91000464 	add	x4, x3, #0x1
    93b0:	f9404446 	ldr	x6, [x2, #136]
    93b4:	f9009044 	str	x4, [x2, #288]
    93b8:	8b000cc0 	add	x0, x6, x0, lsl #3
    93bc:	f900301f 	str	xzr, [x0, #96]
    93c0:	ad000000 	stp	q0, q0, [x0]
    93c4:	ad010000 	stp	q0, q0, [x0, #32]
    93c8:	ad020000 	stp	q0, q0, [x0, #64]
    93cc:	8b010422 	add	x2, x1, x1, lsl #1
    93d0:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    93d4:	91170000 	add	x0, x0, #0x5c0
    93d8:	8b020823 	add	x3, x1, x2, lsl #2
    93dc:	f9001fe1 	str	x1, [sp, #56]
    93e0:	8b030cc3 	add	x3, x6, x3, lsl #3
    93e4:	a9029be3 	stp	x3, x6, [sp, #40]
    93e8:	f900307f 	str	xzr, [x3, #96]
    93ec:	97ffe591 	bl	2a30 <getenv@plt>
    93f0:	a9429be3 	ldp	x3, x6, [sp, #40]
    93f4:	f9401fe1 	ldr	x1, [sp, #56]
    93f8:	b4000820 	cbz	x0, 94fc <fwp_main_thread+0xd1c>
    93fc:	39400002 	ldrb	w2, [x0]
    9400:	7100c05f 	cmp	w2, #0x30
    9404:	540007c1 	b.ne	94fc <fwp_main_thread+0xd1c>  // b.any
    9408:	39400400 	ldrb	w0, [x0, #1]
    940c:	35000780 	cbnz	w0, 94fc <fwp_main_thread+0xd1c>
    9410:	91014282 	add	x2, x20, #0x50
    9414:	2f000400 	mvni	v0.2s, #0x0
    9418:	b9400065 	ldr	w5, [x3]
    941c:	91000427 	add	x7, x1, #0x1
    9420:	52800024 	mov	w4, #0x1                   	// #1
    9424:	a900f07c 	stp	x28, x28, [x3, #8]
    9428:	110004a5 	add	w5, w5, #0x1
    942c:	f941c840 	ldr	x0, [x2, #912]
    9430:	29001065 	stp	w5, w4, [x3]
    9434:	f900287f 	str	xzr, [x3, #80]
    9438:	f900b047 	str	x7, [x2, #352]
    943c:	fd002c60 	str	d0, [x3, #88]
    9440:	b4003fc0 	cbz	x0, 9c38 <fwp_main_thread+0x1458>
    9444:	911a0344 	add	x4, x26, #0x680
    9448:	14000003 	b	9454 <fwp_main_thread+0xc74>
    944c:	f9400000 	ldr	x0, [x0]
    9450:	b4003f40 	cbz	x0, 9c38 <fwp_main_thread+0x1458>
    9454:	f9400402 	ldr	x2, [x0, #8]
    9458:	eb04005f 	cmp	x2, x4
    945c:	54ffff81 	b.ne	944c <fwp_main_thread+0xc6c>  // b.any
    9460:	f9400800 	ldr	x0, [x0, #16]
    9464:	2a0103e4 	mov	w4, w1
    9468:	b9400002 	ldr	w2, [x0]
    946c:	f9002860 	str	x0, [x3, #80]
    9470:	b9005c62 	str	w2, [x3, #92]
    9474:	37f80082 	tbnz	w2, #31, 9484 <fwp_main_thread+0xca4>
    9478:	52800d03 	mov	w3, #0x68                  	// #104
    947c:	9b231842 	smaddl	x2, w2, w3, x6
    9480:	b9005841 	str	w1, [x2, #88]
    9484:	b9000004 	str	w4, [x0]
    9488:	d2800002 	mov	x2, #0x0                   	// #0
    948c:	aa1b03e0 	mov	x0, x27
    9490:	b40021db 	cbz	x27, 98c8 <fwp_main_thread+0x10e8>
    9494:	d503201f 	nop
    9498:	f9400800 	ldr	x0, [x0, #16]
    949c:	91000442 	add	x2, x2, #0x1
    94a0:	b5ffffc0 	cbnz	x0, 9498 <fwp_main_thread+0xcb8>
    94a4:	aa1b03e1 	mov	x1, x27
    94a8:	f9400821 	ldr	x1, [x1, #16]
    94ac:	91000400 	add	x0, x0, #0x1
    94b0:	b5ffffc1 	cbnz	x1, 94a8 <fwp_main_thread+0xcc8>
    94b4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    94b8:	eb01001f 	cmp	x0, x1
    94bc:	54000108 	b.hi	94dc <fwp_main_thread+0xcfc>  // b.pmore
    94c0:	f100005f 	cmp	x2, #0x0
    94c4:	5400202d 	b.le	98c8 <fwp_main_thread+0x10e8>
    94c8:	eb00005f 	cmp	x2, x0
    94cc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    94d0:	9a80905c 	csel	x28, x2, x0, ls	// ls = plast
    94d4:	eb01039f 	cmp	x28, x1
    94d8:	54004129 	b.ls	9cfc <fwp_main_thread+0x151c>  // b.plast
    94dc:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    94e0:	91238000 	add	x0, x0, #0x8e0
    94e4:	97ffeb94 	bl	4334 <fwp_trap>
    94e8:	eb01007f 	cmp	x3, x1
    94ec:	54fff240 	b.eq	9334 <fwp_main_thread+0xb54>  // b.none
    94f0:	91014280 	add	x0, x20, #0x50
    94f4:	f9404406 	ldr	x6, [x0, #136]
    94f8:	17ffffb5 	b	93cc <fwp_main_thread+0xbec>
    94fc:	91014282 	add	x2, x20, #0x50
    9500:	f9408440 	ldr	x0, [x2, #264]
    9504:	b4fff860 	cbz	x0, 9410 <fwp_main_thread+0xc30>
    9508:	ad468442 	ldp	q2, q1, [x2, #208]
    950c:	91034040 	add	x0, x2, #0xd0
    9510:	4f000400 	movi	v0.4s, #0x0
    9514:	f900845f 	str	xzr, [x2, #264]
    9518:	ad010462 	stp	q2, q1, [x3, #32]
    951c:	f9408042 	ldr	x2, [x2, #256]
    9520:	f9002462 	str	x2, [x3, #72]
    9524:	f9401002 	ldr	x2, [x0, #32]
    9528:	f9002062 	str	x2, [x3, #64]
    952c:	f9401402 	ldr	x2, [x0, #40]
    9530:	f9000c62 	str	x2, [x3, #24]
    9534:	f900181f 	str	xzr, [x0, #48]
    9538:	ad000000 	stp	q0, q0, [x0]
    953c:	3d800800 	str	q0, [x0, #32]
    9540:	17ffffb4 	b	9410 <fwp_main_thread+0xc30>
    9544:	f941d2a0 	ldr	x0, [x21, #928]
    9548:	97ffec36 	bl	4620 <fwp_mem_free>
    954c:	f901d2bf 	str	xzr, [x21, #928]
    9550:	f9404ea0 	ldr	x0, [x21, #152]
    9554:	f901dabf 	str	xzr, [x21, #944]
    9558:	b4ffb3c0 	cbz	x0, 8bd0 <fwp_main_thread+0x3f0>
    955c:	f900541f 	str	xzr, [x0, #168]
    9560:	f9005c1f 	str	xzr, [x0, #184]
    9564:	17fffd9b 	b	8bd0 <fwp_main_thread+0x3f0>
    9568:	aa1503e4 	mov	x4, x21
    956c:	aa1c03f5 	mov	x21, x28
    9570:	f94017f7 	ldr	x23, [sp, #40]
    9574:	aa0203fc 	mov	x28, x2
    9578:	f94023f8 	ldr	x24, [sp, #64]
    957c:	aa0403e0 	mov	x0, x4
    9580:	97ffec28 	bl	4620 <fwp_mem_free>
    9584:	f9401be3 	ldr	x3, [sp, #48]
    9588:	9118c266 	add	x6, x19, #0x630
    958c:	a902dbf5 	stp	x21, x22, [sp, #40]
    9590:	aa0603f6 	mov	x22, x6
    9594:	aa0303f5 	mov	x21, x3
    9598:	d2800507 	mov	x7, #0x28                  	// #40
    959c:	f949dac1 	ldr	x1, [x22, #5040]
    95a0:	f949eec0 	ldr	x0, [x22, #5080]
    95a4:	cb0102a1 	sub	x1, x21, x1
    95a8:	eb00403f 	cmp	x1, x0, lsl #16
    95ac:	540092e2 	b.cs	a808 <fwp_main_thread+0x2028>  // b.hs, b.nlast
    95b0:	d350fc22 	lsr	x2, x1, #16
    95b4:	f949fec5 	ldr	x5, [x22, #5112]
    95b8:	9b077c42 	mul	x2, x2, x7
    95bc:	8b0200a4 	add	x4, x5, x2
    95c0:	f9401080 	ldr	x0, [x4, #32]
    95c4:	b4009220 	cbz	x0, a808 <fwp_main_thread+0x2028>
    95c8:	386268a5 	ldrb	w5, [x5, x2]
    95cc:	710008bf 	cmp	w5, #0x2
    95d0:	54009180 	b.eq	a800 <fwp_main_thread+0x2020>  // b.none
    95d4:	710004bf 	cmp	w5, #0x1
    95d8:	54009181 	b.ne	a808 <fwp_main_thread+0x2028>  // b.any
    95dc:	29432082 	ldp	w2, w8, [x4, #24]
    95e0:	92403c21 	and	x1, x1, #0xffff
    95e4:	9b027c22 	mul	x2, x1, x2
    95e8:	d360fc42 	lsr	x2, x2, #32
    95ec:	eb08005f 	cmp	x2, x8
    95f0:	540090c2 	b.cs	a808 <fwp_main_thread+0x2028>  // b.hs, b.nlast
    95f4:	8b020000 	add	x0, x0, x2
    95f8:	39400002 	ldrb	w2, [x0]
    95fc:	34009062 	cbz	w2, a808 <fwp_main_thread+0x2028>
    9600:	7100045f 	cmp	w2, #0x1
    9604:	54008d20 	b.eq	a7a8 <fwp_main_thread+0x1fc8>  // b.none
    9608:	a942dbf5 	ldp	x21, x22, [sp, #40]
    960c:	7103fc5f 	cmp	w2, #0xff
    9610:	54008900 	b.eq	a730 <fwp_main_thread+0x1f50>  // b.none
    9614:	51000442 	sub	w2, w2, #0x1
    9618:	39000002 	strb	w2, [x0]
    961c:	9118c264 	add	x4, x19, #0x630
    9620:	a902dbf5 	stp	x21, x22, [sp, #40]
    9624:	aa0403f6 	mov	x22, x4
    9628:	f9401ff5 	ldr	x21, [sp, #56]
    962c:	d2800506 	mov	x6, #0x28                  	// #40
    9630:	f949dac1 	ldr	x1, [x22, #5040]
    9634:	f949eec0 	ldr	x0, [x22, #5080]
    9638:	cb0102a1 	sub	x1, x21, x1
    963c:	eb00403f 	cmp	x1, x0, lsl #16
    9640:	54008702 	b.cs	a720 <fwp_main_thread+0x1f40>  // b.hs, b.nlast
    9644:	d350fc22 	lsr	x2, x1, #16
    9648:	f949fec5 	ldr	x5, [x22, #5112]
    964c:	9b067c42 	mul	x2, x2, x6
    9650:	8b0200a3 	add	x3, x5, x2
    9654:	f9401060 	ldr	x0, [x3, #32]
    9658:	b4008640 	cbz	x0, a720 <fwp_main_thread+0x1f40>
    965c:	386268a5 	ldrb	w5, [x5, x2]
    9660:	710008bf 	cmp	w5, #0x2
    9664:	540085a0 	b.eq	a718 <fwp_main_thread+0x1f38>  // b.none
    9668:	710004bf 	cmp	w5, #0x1
    966c:	540085a1 	b.ne	a720 <fwp_main_thread+0x1f40>  // b.any
    9670:	29432062 	ldp	w2, w8, [x3, #24]
    9674:	92403c21 	and	x1, x1, #0xffff
    9678:	9b027c22 	mul	x2, x1, x2
    967c:	d360fc42 	lsr	x2, x2, #32
    9680:	eb08005f 	cmp	x2, x8
    9684:	540084e2 	b.cs	a720 <fwp_main_thread+0x1f40>  // b.hs, b.nlast
    9688:	8b020000 	add	x0, x0, x2
    968c:	39400002 	ldrb	w2, [x0]
    9690:	34008482 	cbz	w2, a720 <fwp_main_thread+0x1f40>
    9694:	7100045f 	cmp	w2, #0x1
    9698:	540082a0 	b.eq	a6ec <fwp_main_thread+0x1f0c>  // b.none
    969c:	a942dbf5 	ldp	x21, x22, [sp, #40]
    96a0:	7103fc5f 	cmp	w2, #0xff
    96a4:	54008ee0 	b.eq	a880 <fwp_main_thread+0x20a0>  // b.none
    96a8:	51000442 	sub	w2, w2, #0x1
    96ac:	39000002 	strb	w2, [x0]
    96b0:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10a10>
    96b4:	910ac042 	add	x2, x2, #0x2b0
    96b8:	91014042 	add	x2, x2, #0x50
    96bc:	aa1503e0 	mov	x0, x21
    96c0:	52800023 	mov	w3, #0x1                   	// #1
    96c4:	aa1c03e1 	mov	x1, x28
    96c8:	a90effff 	stp	xzr, xzr, [sp, #232]
    96cc:	f9007fff 	str	xzr, [sp, #248]
    96d0:	97fff849 	bl	77f4 <fwp_write>
    96d4:	a94e8be3 	ldp	x3, x2, [sp, #232]
    96d8:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    96dc:	910c8000 	add	x0, x0, #0x320
    96e0:	f100007f 	cmp	x3, #0x0
    96e4:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    96e8:	b100285f 	cmn	x2, #0xa
    96ec:	54007e08 	b.hi	a6ac <fwp_main_thread+0x1ecc>  // b.pmore
    96f0:	91002440 	add	x0, x2, #0x9
    96f4:	52800021 	mov	w1, #0x1                   	// #1
    96f8:	a9028be3 	stp	x3, x2, [sp, #40]
    96fc:	97ffee85 	bl	5110 <fwp_heap_alloc>
    9700:	a9428be3 	ldp	x3, x2, [sp, #40]
    9704:	f90017e0 	str	x0, [sp, #40]
    9708:	f8008402 	str	x2, [x0], #8
    970c:	f9001fe2 	str	x2, [sp, #56]
    9710:	f9001be0 	str	x0, [sp, #48]
    9714:	aa0303e1 	mov	x1, x3
    9718:	97ffe3f6 	bl	26f0 <memcpy@plt>
    971c:	f94017e0 	ldr	x0, [sp, #40]
    9720:	f9401fe2 	ldr	x2, [sp, #56]
    9724:	8b020002 	add	x2, x0, x2
    9728:	3900205f 	strb	wzr, [x2, #8]
    972c:	f94077e0 	ldr	x0, [sp, #232]
    9730:	97ffe48c 	bl	2960 <free@plt>
    9734:	9118c260 	add	x0, x19, #0x630
    9738:	f94017e3 	ldr	x3, [sp, #40]
    973c:	f949d801 	ldr	x1, [x0, #5040]
    9740:	f949ec02 	ldr	x2, [x0, #5080]
    9744:	cb010061 	sub	x1, x3, x1
    9748:	eb02403f 	cmp	x1, x2, lsl #16
    974c:	54000322 	b.cs	97b0 <fwp_main_thread+0xfd0>  // b.hs, b.nlast
    9750:	d350fc22 	lsr	x2, x1, #16
    9754:	d2800503 	mov	x3, #0x28                  	// #40
    9758:	f949fc04 	ldr	x4, [x0, #5112]
    975c:	9b037c42 	mul	x2, x2, x3
    9760:	8b020083 	add	x3, x4, x2
    9764:	f9401060 	ldr	x0, [x3, #32]
    9768:	b4000240 	cbz	x0, 97b0 <fwp_main_thread+0xfd0>
    976c:	38626882 	ldrb	w2, [x4, x2]
    9770:	7100085f 	cmp	w2, #0x2
    9774:	54007ae0 	b.eq	a6d0 <fwp_main_thread+0x1ef0>  // b.none
    9778:	7100045f 	cmp	w2, #0x1
    977c:	540001a1 	b.ne	97b0 <fwp_main_thread+0xfd0>  // b.any
    9780:	29430864 	ldp	w4, w2, [x3, #24]
    9784:	92403c21 	and	x1, x1, #0xffff
    9788:	9b047c21 	mul	x1, x1, x4
    978c:	d360fc21 	lsr	x1, x1, #32
    9790:	eb02003f 	cmp	x1, x2
    9794:	540000e2 	b.cs	97b0 <fwp_main_thread+0xfd0>  // b.hs, b.nlast
    9798:	8b010000 	add	x0, x0, x1
    979c:	39400001 	ldrb	w1, [x0]
    97a0:	7103fc3f 	cmp	w1, #0xff
    97a4:	540079c0 	b.eq	a6dc <fwp_main_thread+0x1efc>  // b.none
    97a8:	52800021 	mov	w1, #0x1                   	// #1
    97ac:	39000001 	strb	w1, [x0]
    97b0:	aa1c03e0 	mov	x0, x28
    97b4:	97fff26b 	bl	6160 <fwp_drop0>
    97b8:	a94283e1 	ldp	x1, x0, [sp, #40]
    97bc:	9101429c 	add	x28, x20, #0x50
    97c0:	f9404b83 	ldr	x3, [x28, #144]
    97c4:	f9400022 	ldr	x2, [x1]
    97c8:	d2800021 	mov	x1, #0x1                   	// #1
    97cc:	97ffe475 	bl	29a0 <fwrite@plt>
    97d0:	f9404b81 	ldr	x1, [x28, #144]
    97d4:	52800140 	mov	w0, #0xa                   	// #10
    97d8:	97ffe3fa 	bl	27c0 <fputc@plt>
    97dc:	9118c262 	add	x2, x19, #0x630
    97e0:	f94017e3 	ldr	x3, [sp, #40]
    97e4:	f949d841 	ldr	x1, [x2, #5040]
    97e8:	f949ec40 	ldr	x0, [x2, #5080]
    97ec:	cb010061 	sub	x1, x3, x1
    97f0:	eb00403f 	cmp	x1, x0, lsl #16
    97f4:	54000382 	b.cs	9864 <fwp_main_thread+0x1084>  // b.hs, b.nlast
    97f8:	d350fc20 	lsr	x0, x1, #16
    97fc:	d2800504 	mov	x4, #0x28                  	// #40
    9800:	f949fc43 	ldr	x3, [x2, #5112]
    9804:	9b047c00 	mul	x0, x0, x4
    9808:	8b000062 	add	x2, x3, x0
    980c:	f940105c 	ldr	x28, [x2, #32]
    9810:	b40002bc 	cbz	x28, 9864 <fwp_main_thread+0x1084>
    9814:	38606860 	ldrb	w0, [x3, x0]
    9818:	7100081f 	cmp	w0, #0x2
    981c:	54007540 	b.eq	a6c4 <fwp_main_thread+0x1ee4>  // b.none
    9820:	7100041f 	cmp	w0, #0x1
    9824:	54000201 	b.ne	9864 <fwp_main_thread+0x1084>  // b.any
    9828:	29430043 	ldp	w3, w0, [x2, #24]
    982c:	92403c21 	and	x1, x1, #0xffff
    9830:	9b037c21 	mul	x1, x1, x3
    9834:	d360fc21 	lsr	x1, x1, #32
    9838:	eb00003f 	cmp	x1, x0
    983c:	54000142 	b.cs	9864 <fwp_main_thread+0x1084>  // b.hs, b.nlast
    9840:	8b01039c 	add	x28, x28, x1
    9844:	39400381 	ldrb	w1, [x28]
    9848:	340000e1 	cbz	w1, 9864 <fwp_main_thread+0x1084>
    984c:	7100043f 	cmp	w1, #0x1
    9850:	54007340 	b.eq	a6b8 <fwp_main_thread+0x1ed8>  // b.none
    9854:	7103fc3f 	cmp	w1, #0xff
    9858:	540078a0 	b.eq	a76c <fwp_main_thread+0x1f8c>  // b.none
    985c:	51000421 	sub	w1, w1, #0x1
    9860:	39000381 	strb	w1, [x28]
    9864:	f9400fe0 	ldr	x0, [sp, #24]
    9868:	f9400800 	ldr	x0, [x0, #16]
    986c:	f9000fe0 	str	x0, [sp, #24]
    9870:	b5ffbe20 	cbnz	x0, 9034 <fwp_main_thread+0x854>
    9874:	f94013fc 	ldr	x28, [sp, #32]
    9878:	aa1b03e0 	mov	x0, x27
    987c:	97fff239 	bl	6160 <fwp_drop0>
    9880:	aa1c03e0 	mov	x0, x28
    9884:	97fff237 	bl	6160 <fwp_drop0>
    9888:	91014280 	add	x0, x20, #0x50
    988c:	52800021 	mov	w1, #0x1                   	// #1
    9890:	f94123fb 	ldr	x27, [sp, #576]
    9894:	f94127fc 	ldr	x28, [sp, #584]
    9898:	b903c401 	str	w1, [x0, #964]
    989c:	f901e81f 	str	xzr, [x0, #976]
    98a0:	17fffc21 	b	8924 <fwp_main_thread+0x144>
    98a4:	b0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x10>
    98a8:	9115c000 	add	x0, x0, #0x570
    98ac:	f90017e1 	str	x1, [sp, #40]
    98b0:	94000680 	bl	b2b0 <atexit>
    98b4:	f94017e1 	ldr	x1, [sp, #40]
    98b8:	350086c0 	cbnz	w0, a990 <fwp_main_thread+0x21b0>
    98bc:	52800020 	mov	w0, #0x1                   	// #1
    98c0:	b903c820 	str	w0, [x1, #968]
    98c4:	17fffe88 	b	92e4 <fwp_main_thread+0xb04>
    98c8:	d3707ca5 	ubfiz	x5, x5, #16, #32
    98cc:	52800041 	mov	w1, #0x2                   	// #2
    98d0:	aa0700a0 	orr	x0, x5, x7
    98d4:	f90017e0 	str	x0, [sp, #40]
    98d8:	d2800100 	mov	x0, #0x8                   	// #8
    98dc:	97ffee0d 	bl	5110 <fwp_heap_alloc>
    98e0:	aa0003e5 	mov	x5, x0
    98e4:	9118c260 	add	x0, x19, #0x630
    98e8:	aa0503e7 	mov	x7, x5
    98ec:	f90000bf 	str	xzr, [x5]
    98f0:	f949d801 	ldr	x1, [x0, #5040]
    98f4:	f949ec00 	ldr	x0, [x0, #5080]
    98f8:	cb0100a1 	sub	x1, x5, x1
    98fc:	eb00403f 	cmp	x1, x0, lsl #16
    9900:	54002262 	b.cs	9d4c <fwp_main_thread+0x156c>  // b.hs, b.nlast
    9904:	d280001c 	mov	x28, #0x0                   	// #0
    9908:	9118c262 	add	x2, x19, #0x630
    990c:	d350fc20 	lsr	x0, x1, #16
    9910:	8b000800 	add	x0, x0, x0, lsl #2
    9914:	f949fc44 	ldr	x4, [x2, #5112]
    9918:	d37df002 	lsl	x2, x0, #3
    991c:	8b020083 	add	x3, x4, x2
    9920:	f9401060 	ldr	x0, [x3, #32]
    9924:	b4000240 	cbz	x0, 996c <fwp_main_thread+0x118c>
    9928:	38626882 	ldrb	w2, [x4, x2]
    992c:	7100085f 	cmp	w2, #0x2
    9930:	54002840 	b.eq	9e38 <fwp_main_thread+0x1658>  // b.none
    9934:	7100045f 	cmp	w2, #0x1
    9938:	540001a1 	b.ne	996c <fwp_main_thread+0x118c>  // b.any
    993c:	29430864 	ldp	w4, w2, [x3, #24]
    9940:	92403c21 	and	x1, x1, #0xffff
    9944:	9b047c21 	mul	x1, x1, x4
    9948:	d360fc21 	lsr	x1, x1, #32
    994c:	eb02003f 	cmp	x1, x2
    9950:	540000e2 	b.cs	996c <fwp_main_thread+0x118c>  // b.hs, b.nlast
    9954:	8b010000 	add	x0, x0, x1
    9958:	39400001 	ldrb	w1, [x0]
    995c:	7103fc3f 	cmp	w1, #0xff
    9960:	54004760 	b.eq	a24c <fwp_main_thread+0x1a6c>  // b.none
    9964:	52800021 	mov	w1, #0x1                   	// #1
    9968:	39000001 	strb	w1, [x0]
    996c:	b400025c 	cbz	x28, 99b4 <fwp_main_thread+0x11d4>
    9970:	f94017e0 	ldr	x0, [sp, #40]
    9974:	aa1b03e1 	mov	x1, x27
    9978:	f9400766 	ldr	x6, [x27, #8]
    997c:	910020a2 	add	x2, x5, #0x8
    9980:	d3607c04 	lsl	x4, x0, #32
    9984:	d2800000 	mov	x0, #0x0                   	// #0
    9988:	aa0403e3 	mov	x3, x4
    998c:	14000005 	b	99a0 <fwp_main_thread+0x11c0>
    9990:	f9400426 	ldr	x6, [x1, #8]
    9994:	ab040003 	adds	x3, x0, x4
    9998:	91004042 	add	x2, x2, #0x10
    999c:	54009086 	b.vs	abac <fwp_main_thread+0x23cc>
    99a0:	a9000c46 	stp	x6, x3, [x2]
    99a4:	91000400 	add	x0, x0, #0x1
    99a8:	f9400821 	ldr	x1, [x1, #16]
    99ac:	eb1c001f 	cmp	x0, x28
    99b0:	54ffff03 	b.cc	9990 <fwp_main_thread+0x11b0>  // b.lo, b.ul, b.last
    99b4:	f94000bc 	ldr	x28, [x5]
    99b8:	f100079f 	cmp	x28, #0x1
    99bc:	54001c89 	b.ls	9d4c <fwp_main_thread+0x156c>  // b.plast
    99c0:	d341ff82 	lsr	x2, x28, #1
    99c4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    99c8:	d1000440 	sub	x0, x2, #0x1
    99cc:	eb01001f 	cmp	x0, x1
    99d0:	54ffd868 	b.hi	94dc <fwp_main_thread+0xcfc>  // b.pmore
    99d4:	b4001bc0 	cbz	x0, 9d4c <fwp_main_thread+0x156c>
    99d8:	d10020a1 	sub	x1, x5, #0x8
    99dc:	910020bc 	add	x28, x5, #0x8
    99e0:	8b021021 	add	x1, x1, x2, lsl #4
    99e4:	a90303fb 	stp	x27, x0, [sp, #48]
    99e8:	aa1603e0 	mov	x0, x22
    99ec:	aa0103fb 	mov	x27, x1
    99f0:	aa1503f6 	mov	x22, x21
    99f4:	aa1c03f5 	mov	x21, x28
    99f8:	aa0003fc 	mov	x28, x0
    99fc:	a90417e7 	stp	x7, x5, [sp, #64]
    9a00:	fd4002a0 	ldr	d0, [x21]
    9a04:	f94006a0 	ldr	x0, [x21, #8]
    9a08:	f9400ea1 	ldr	x1, [x21, #24]
    9a0c:	fd400aa1 	ldr	d1, [x21, #16]
    9a10:	97ffef65 	bl	57a4 <w120>
    9a14:	a90006a0 	stp	x0, x1, [x21]
    9a18:	910042b5 	add	x21, x21, #0x10
    9a1c:	eb1b02bf 	cmp	x21, x27
    9a20:	54ffff01 	b.ne	9a00 <fwp_main_thread+0x1220>  // b.any
    9a24:	a9439fe0 	ldp	x0, x7, [sp, #56]
    9a28:	aa1603f5 	mov	x21, x22
    9a2c:	f94027e5 	ldr	x5, [sp, #72]
    9a30:	aa1c03f6 	mov	x22, x28
    9a34:	d280001c 	mov	x28, #0x0                   	// #0
    9a38:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9a3c:	aa0503e2 	mov	x2, x5
    9a40:	f90027f5 	str	x21, [sp, #72]
    9a44:	d37ff801 	lsl	x1, x0, #1
    9a48:	aa0403e0 	mov	x0, x4
    9a4c:	aa0103fb 	mov	x27, x1
    9a50:	a90397e7 	stp	x7, x5, [sp, #56]
    9a54:	f8010441 	str	x1, [x2], #16
    9a58:	aa1603e1 	mov	x1, x22
    9a5c:	aa1c03f6 	mov	x22, x28
    9a60:	aa0103fc 	mov	x28, x1
    9a64:	aa0203f5 	mov	x21, x2
    9a68:	f8767aa1 	ldr	x1, [x21, x22, lsl #3]
    9a6c:	91000ad6 	add	x22, x22, #0x2
    9a70:	97ffeefc 	bl	5660 <f141.constprop.0>
    9a74:	eb1b02df 	cmp	x22, x27
    9a78:	54ffff83 	b.cc	9a68 <fwp_main_thread+0x1288>  // b.lo, b.ul, b.last
    9a7c:	a9431ffb 	ldp	x27, x7, [sp, #48]
    9a80:	aa0003e4 	mov	x4, x0
    9a84:	a94457e5 	ldp	x5, x21, [sp, #64]
    9a88:	aa1c03f6 	mov	x22, x28
    9a8c:	9118c263 	add	x3, x19, #0x630
    9a90:	f949d861 	ldr	x1, [x3, #5040]
    9a94:	f949ec60 	ldr	x0, [x3, #5080]
    9a98:	cb0100a1 	sub	x1, x5, x1
    9a9c:	eb00403f 	cmp	x1, x0, lsl #16
    9aa0:	54000502 	b.cs	9b40 <fwp_main_thread+0x1360>  // b.hs, b.nlast
    9aa4:	aa1503e2 	mov	x2, x21
    9aa8:	aa1603e0 	mov	x0, x22
    9aac:	aa0303f5 	mov	x21, x3
    9ab0:	aa0403f6 	mov	x22, x4
    9ab4:	aa0703fc 	mov	x28, x7
    9ab8:	aa0003e4 	mov	x4, x0
    9abc:	aa0203e3 	mov	x3, x2
    9ac0:	d2800505 	mov	x5, #0x28                  	// #40
    9ac4:	d350fc20 	lsr	x0, x1, #16
    9ac8:	f949fea2 	ldr	x2, [x21, #5112]
    9acc:	9b057c00 	mul	x0, x0, x5
    9ad0:	8b000047 	add	x7, x2, x0
    9ad4:	f94010e6 	ldr	x6, [x7, #32]
    9ad8:	b4000ba6 	cbz	x6, 9c4c <fwp_main_thread+0x146c>
    9adc:	38606840 	ldrb	w0, [x2, x0]
    9ae0:	7100081f 	cmp	w0, #0x2
    9ae4:	54000b00 	b.eq	9c44 <fwp_main_thread+0x1464>  // b.none
    9ae8:	7100041f 	cmp	w0, #0x1
    9aec:	54000b01 	b.ne	9c4c <fwp_main_thread+0x146c>  // b.any
    9af0:	92403c20 	and	x0, x1, #0xffff
    9af4:	294304e8 	ldp	w8, w1, [x7, #24]
    9af8:	9b087c00 	mul	x0, x0, x8
    9afc:	d360fc00 	lsr	x0, x0, #32
    9b00:	eb01001f 	cmp	x0, x1
    9b04:	54000a42 	b.cs	9c4c <fwp_main_thread+0x146c>  // b.hs, b.nlast
    9b08:	8b0000c6 	add	x6, x6, x0
    9b0c:	394000c1 	ldrb	w1, [x6]
    9b10:	340009e1 	cbz	w1, 9c4c <fwp_main_thread+0x146c>
    9b14:	7100043f 	cmp	w1, #0x1
    9b18:	54000400 	b.eq	9b98 <fwp_main_thread+0x13b8>  // b.none
    9b1c:	aa0403e0 	mov	x0, x4
    9b20:	aa0603fc 	mov	x28, x6
    9b24:	aa1603e4 	mov	x4, x22
    9b28:	aa0303f5 	mov	x21, x3
    9b2c:	aa0003f6 	mov	x22, x0
    9b30:	7103fc3f 	cmp	w1, #0xff
    9b34:	54007460 	b.eq	a9c0 <fwp_main_thread+0x21e0>  // b.none
    9b38:	51000421 	sub	w1, w1, #0x1
    9b3c:	390000c1 	strb	w1, [x6]
    9b40:	b9802bfc 	ldrsw	x28, [sp, #40]
    9b44:	f9001be4 	str	x4, [sp, #48]
    9b48:	aa1c03e0 	mov	x0, x28
    9b4c:	97ffebfd 	bl	4b40 <fwp_tape_of>
    9b50:	f9403001 	ldr	x1, [x0, #96]
    9b54:	aa0003e5 	mov	x5, x0
    9b58:	f9401be4 	ldr	x4, [sp, #48]
    9b5c:	b4000fe1 	cbz	x1, 9d58 <fwp_main_thread+0x1578>
    9b60:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9b64:	91214000 	add	x0, x0, #0x850
    9b68:	97ffe9f3 	bl	4334 <fwp_trap>
    9b6c:	d280001c 	mov	x28, #0x0                   	// #0
    9b70:	17fffdda 	b	92d8 <fwp_main_thread+0xaf8>
    9b74:	aa1703e0 	mov	x0, x23
    9b78:	97ffea0f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9b7c:	17fffd1e 	b	8ff4 <fwp_main_thread+0x814>
    9b80:	aa1703e0 	mov	x0, x23
    9b84:	97ffea0c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9b88:	17fffcd2 	b	8ed0 <fwp_main_thread+0x6f0>
    9b8c:	aa1703e0 	mov	x0, x23
    9b90:	97ffea09 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9b94:	17fffcf3 	b	8f60 <fwp_main_thread+0x780>
    9b98:	f9400387 	ldr	x7, [x28]
    9b9c:	aa1c03e0 	mov	x0, x28
    9ba0:	f949eea6 	ldr	x6, [x21, #5080]
    9ba4:	f949daa1 	ldr	x1, [x21, #5040]
    9ba8:	d370bcc6 	lsl	x6, x6, #16
    9bac:	cb010381 	sub	x1, x28, x1
    9bb0:	b7f814e7 	tbnz	x7, #63, 9e4c <fwp_main_thread+0x166c>
    9bb4:	aa0403e0 	mov	x0, x4
    9bb8:	aa1c03e7 	mov	x7, x28
    9bbc:	aa1603e4 	mov	x4, x22
    9bc0:	aa0303f5 	mov	x21, x3
    9bc4:	aa0003f6 	mov	x22, x0
    9bc8:	eb06003f 	cmp	x1, x6
    9bcc:	54fffba2 	b.cs	9b40 <fwp_main_thread+0x1360>  // b.hs, b.nlast
    9bd0:	d350fc20 	lsr	x0, x1, #16
    9bd4:	d2800503 	mov	x3, #0x28                  	// #40
    9bd8:	9b037c00 	mul	x0, x0, x3
    9bdc:	8b000045 	add	x5, x2, x0
    9be0:	f94010a3 	ldr	x3, [x5, #32]
    9be4:	b4fffae3 	cbz	x3, 9b40 <fwp_main_thread+0x1360>
    9be8:	38606840 	ldrb	w0, [x2, x0]
    9bec:	7100081f 	cmp	w0, #0x2
    9bf0:	54001740 	b.eq	9ed8 <fwp_main_thread+0x16f8>  // b.none
    9bf4:	7100041f 	cmp	w0, #0x1
    9bf8:	54fffa41 	b.ne	9b40 <fwp_main_thread+0x1360>  // b.any
    9bfc:	92403c20 	and	x0, x1, #0xffff
    9c00:	294304a2 	ldp	w2, w1, [x5, #24]
    9c04:	9b027c00 	mul	x0, x0, x2
    9c08:	d360fc00 	lsr	x0, x0, #32
    9c0c:	eb01001f 	cmp	x0, x1
    9c10:	54fff982 	b.cs	9b40 <fwp_main_thread+0x1360>  // b.hs, b.nlast
    9c14:	8b000063 	add	x3, x3, x0
    9c18:	39400060 	ldrb	w0, [x3]
    9c1c:	7100041f 	cmp	w0, #0x1
    9c20:	54fff901 	b.ne	9b40 <fwp_main_thread+0x1360>  // b.any
    9c24:	aa0703e0 	mov	x0, x7
    9c28:	f9001be4 	str	x4, [sp, #48]
    9c2c:	97ffea7d 	bl	4620 <fwp_mem_free>
    9c30:	f9401be4 	ldr	x4, [sp, #48]
    9c34:	17ffffc3 	b	9b40 <fwp_main_thread+0x1360>
    9c38:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9c3c:	912d6000 	add	x0, x0, #0xb58
    9c40:	97ffe9bd 	bl	4334 <fwp_trap>
    9c44:	72003c3f 	tst	w1, #0xffff
    9c48:	54fff620 	b.eq	9b0c <fwp_main_thread+0x132c>  // b.none
    9c4c:	aa0403e0 	mov	x0, x4
    9c50:	aa0303f5 	mov	x21, x3
    9c54:	aa1603e4 	mov	x4, x22
    9c58:	aa0003f6 	mov	x22, x0
    9c5c:	17ffffb9 	b	9b40 <fwp_main_thread+0x1360>
    9c60:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9c64:	91292000 	add	x0, x0, #0xa48
    9c68:	97ffe9b3 	bl	4334 <fwp_trap>
    9c6c:	97ffeae6 	bl	4804 <fwp_rc_wide_dup>
    9c70:	9118c260 	add	x0, x19, #0x630
    9c74:	f949ec04 	ldr	x4, [x0, #5080]
    9c78:	f949d801 	ldr	x1, [x0, #5040]
    9c7c:	d370bc84 	lsl	x4, x4, #16
    9c80:	17fffd17 	b	90dc <fwp_main_thread+0x8fc>
    9c84:	97ffeae0 	bl	4804 <fwp_rc_wide_dup>
    9c88:	17fffd42 	b	9190 <fwp_main_thread+0x9b0>
    9c8c:	ca5c4780 	eor	x0, x28, x28, lsr #17
    9c90:	9118c262 	add	x2, x19, #0x630
    9c94:	ca402400 	eor	x0, x0, x0, lsr #9
    9c98:	92401c00 	and	x0, x0, #0xff
    9c9c:	910a2401 	add	x1, x0, #0x289
    9ca0:	8b000c40 	add	x0, x2, x0, lsl #3
    9ca4:	8b010c41 	add	x1, x2, x1, lsl #3
    9ca8:	f94a2400 	ldr	x0, [x0, #5192]
    9cac:	b50000a0 	cbnz	x0, 9cc0 <fwp_main_thread+0x14e0>
    9cb0:	1400015e 	b	a228 <fwp_main_thread+0x1a48>
    9cb4:	91004001 	add	x1, x0, #0x10
    9cb8:	f9400800 	ldr	x0, [x0, #16]
    9cbc:	b4002b60 	cbz	x0, a228 <fwp_main_thread+0x1a48>
    9cc0:	f9400002 	ldr	x2, [x0]
    9cc4:	eb02039f 	cmp	x28, x2
    9cc8:	54ffff61 	b.ne	9cb4 <fwp_main_thread+0x14d4>  // b.any
    9ccc:	f9400021 	ldr	x1, [x1]
    9cd0:	f9400420 	ldr	x0, [x1, #8]
    9cd4:	d1000400 	sub	x0, x0, #0x1
    9cd8:	f9000420 	str	x0, [x1, #8]
    9cdc:	f103f81f 	cmp	x0, #0xfe
    9ce0:	54ffa981 	b.ne	9210 <fwp_main_thread+0xa30>  // b.any
    9ce4:	39400380 	ldrb	w0, [x28]
    9ce8:	7103fc1f 	cmp	w0, #0xff
    9cec:	54002aa0 	b.eq	a240 <fwp_main_thread+0x1a60>  // b.none
    9cf0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9cf4:	39000380 	strb	w0, [x28]
    9cf8:	17fffd46 	b	9210 <fwp_main_thread+0xa30>
    9cfc:	d37ffb82 	lsl	x2, x28, #1
    9d00:	d3707ca5 	ubfiz	x5, x5, #16, #32
    9d04:	91000440 	add	x0, x2, #0x1
    9d08:	aa0700a1 	orr	x1, x5, x7
    9d0c:	a9028be1 	stp	x1, x2, [sp, #40]
    9d10:	52800041 	mov	w1, #0x2                   	// #2
    9d14:	d37df000 	lsl	x0, x0, #3
    9d18:	97ffecfe 	bl	5110 <fwp_heap_alloc>
    9d1c:	aa0003e5 	mov	x5, x0
    9d20:	9118c261 	add	x1, x19, #0x630
    9d24:	aa0003e7 	mov	x7, x0
    9d28:	f9401be2 	ldr	x2, [sp, #48]
    9d2c:	aa0103e0 	mov	x0, x1
    9d30:	f90000a2 	str	x2, [x5]
    9d34:	f949d821 	ldr	x1, [x1, #5040]
    9d38:	f949ec00 	ldr	x0, [x0, #5080]
    9d3c:	cb0100a1 	sub	x1, x5, x1
    9d40:	eb00403f 	cmp	x1, x0, lsl #16
    9d44:	54ffde23 	b.cc	9908 <fwp_main_thread+0x1128>  // b.lo, b.ul, b.last
    9d48:	b5ffe15c 	cbnz	x28, 9970 <fwp_main_thread+0x1190>
    9d4c:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9d50:	f90000bf 	str	xzr, [x5]
    9d54:	17ffff4e 	b	9a8c <fwp_main_thread+0x12ac>
    9d58:	f90027e4 	str	x4, [sp, #72]
    9d5c:	97ffe4ae 	bl	3014 <fwp_tape_unlink_scope>
    9d60:	a94190a3 	ldp	x3, x4, [x5, #24]
    9d64:	f90017e4 	str	x4, [sp, #40]
    9d68:	f94014a4 	ldr	x4, [x5, #40]
    9d6c:	f9001be4 	str	x4, [sp, #48]
    9d70:	f94018a4 	ldr	x4, [x5, #48]
    9d74:	f9001fe4 	str	x4, [sp, #56]
    9d78:	f9401ca4 	ldr	x4, [x5, #56]
    9d7c:	b90004bf 	str	wzr, [x5, #4]
    9d80:	b94000a1 	ldr	w1, [x5]
    9d84:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    9d88:	f90023e4 	str	x4, [sp, #64]
    9d8c:	a94088a8 	ldp	x8, x2, [x5, #8]
    9d90:	6b00003f 	cmp	w1, w0
    9d94:	a9441ca6 	ldp	x6, x7, [x5, #64]
    9d98:	f94027e4 	ldr	x4, [sp, #72]
    9d9c:	54000108 	b.hi	9dbc <fwp_main_thread+0x15dc>  // b.pmore
    9da0:	91014281 	add	x1, x20, #0x50
    9da4:	92403f80 	and	x0, x28, #0xffff
    9da8:	d1000400 	sub	x0, x0, #0x1
    9dac:	f940b029 	ldr	x9, [x1, #352]
    9db0:	eb09001f 	cmp	x0, x9
    9db4:	5400004a 	b.ge	9dbc <fwp_main_thread+0x15dc>  // b.tcont
    9db8:	f900b020 	str	x0, [x1, #352]
    9dbc:	4f000400 	movi	v0.4s, #0x0
    9dc0:	f9000cbf 	str	xzr, [x5, #24]
    9dc4:	f94017e0 	ldr	x0, [sp, #40]
    9dc8:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    9dcc:	91014281 	add	x1, x20, #0x50
    9dd0:	3c8080a0 	stur	q0, [x5, #8]
    9dd4:	ad0100a0 	stp	q0, q0, [x5, #32]
    9dd8:	9102c3e5 	add	x5, sp, #0xb0
    9ddc:	f90077e0 	str	x0, [sp, #232]
    9de0:	f9401be0 	ldr	x0, [sp, #48]
    9de4:	f9007be0 	str	x0, [sp, #240]
    9de8:	f9401fe0 	ldr	x0, [sp, #56]
    9dec:	f9007fe0 	str	x0, [sp, #248]
    9df0:	f94023e0 	ldr	x0, [sp, #64]
    9df4:	f90083e0 	str	x0, [sp, #256]
    9df8:	f941c820 	ldr	x0, [x1, #912]
    9dfc:	f9002be5 	str	x5, [sp, #80]
    9e00:	f9005be0 	str	x0, [sp, #176]
    9e04:	f0ffffc0 	adrp	x0, 4000 <ad_raw_free.part.0+0x10>
    9e08:	91065000 	add	x0, x0, #0x194
    9e0c:	f9005fe0 	str	x0, [sp, #184]
    9e10:	f90063f5 	str	x21, [sp, #192]
    9e14:	a9108fe6 	stp	x6, x3, [sp, #264]
    9e18:	f9008fe7 	str	x7, [sp, #280]
    9e1c:	f901c825 	str	x5, [x1, #912]
    9e20:	b7f810a4 	tbnz	x4, #63, a034 <fwp_main_thread+0x1854>
    9e24:	eb84839f 	cmp	x28, x4, asr #32
    9e28:	540005e0 	b.eq	9ee4 <fwp_main_thread+0x1704>  // b.none
    9e2c:	d0000000 	adrp	x0, b000 <__modti3+0xc0>
    9e30:	91202000 	add	x0, x0, #0x808
    9e34:	97ffe940 	bl	4334 <fwp_trap>
    9e38:	72003c3f 	tst	w1, #0xffff
    9e3c:	54ffd981 	b.ne	996c <fwp_main_thread+0x118c>  // b.any
    9e40:	17fffec6 	b	9958 <fwp_main_thread+0x1178>
    9e44:	d2800024 	mov	x4, #0x1                   	// #1
    9e48:	17fffd47 	b	9364 <fwp_main_thread+0xb84>
    9e4c:	f940079c 	ldr	x28, [x28, #8]
    9e50:	eb06003f 	cmp	x1, x6
    9e54:	54000342 	b.cs	9ebc <fwp_main_thread+0x16dc>  // b.hs, b.nlast
    9e58:	d350fc27 	lsr	x7, x1, #16
    9e5c:	d2800506 	mov	x6, #0x28                  	// #40
    9e60:	9b067ce7 	mul	x7, x7, x6
    9e64:	8b070048 	add	x8, x2, x7
    9e68:	f9401106 	ldr	x6, [x8, #32]
    9e6c:	b4000286 	cbz	x6, 9ebc <fwp_main_thread+0x16dc>
    9e70:	38676842 	ldrb	w2, [x2, x7]
    9e74:	7100085f 	cmp	w2, #0x2
    9e78:	54000d80 	b.eq	a028 <fwp_main_thread+0x1848>  // b.none
    9e7c:	7100045f 	cmp	w2, #0x1
    9e80:	540001e1 	b.ne	9ebc <fwp_main_thread+0x16dc>  // b.any
    9e84:	29430907 	ldp	w7, w2, [x8, #24]
    9e88:	92403c21 	and	x1, x1, #0xffff
    9e8c:	9b077c21 	mul	x1, x1, x7
    9e90:	d360fc21 	lsr	x1, x1, #32
    9e94:	eb02003f 	cmp	x1, x2
    9e98:	54000122 	b.cs	9ebc <fwp_main_thread+0x16dc>  // b.hs, b.nlast
    9e9c:	8b0100c6 	add	x6, x6, x1
    9ea0:	394000c1 	ldrb	w1, [x6]
    9ea4:	7100043f 	cmp	w1, #0x1
    9ea8:	540000a1 	b.ne	9ebc <fwp_main_thread+0x16dc>  // b.any
    9eac:	a90313e3 	stp	x3, x4, [sp, #48]
    9eb0:	97ffe9dc 	bl	4620 <fwp_mem_free>
    9eb4:	d2800505 	mov	x5, #0x28                  	// #40
    9eb8:	a94313e3 	ldp	x3, x4, [sp, #48]
    9ebc:	9118c260 	add	x0, x19, #0x630
    9ec0:	f949d801 	ldr	x1, [x0, #5040]
    9ec4:	f949ec00 	ldr	x0, [x0, #5080]
    9ec8:	cb010381 	sub	x1, x28, x1
    9ecc:	eb00403f 	cmp	x1, x0, lsl #16
    9ed0:	54ffdfa3 	b.cc	9ac4 <fwp_main_thread+0x12e4>  // b.lo, b.ul, b.last
    9ed4:	17ffff5e 	b	9c4c <fwp_main_thread+0x146c>
    9ed8:	72003c3f 	tst	w1, #0xffff
    9edc:	54ffe321 	b.ne	9b40 <fwp_main_thread+0x1360>  // b.any
    9ee0:	17ffff4e 	b	9c18 <fwp_main_thread+0x1438>
    9ee4:	92407c80 	and	x0, x4, #0xffffffff
    9ee8:	eb24405f 	cmp	x2, w4, uxtw
    9eec:	54001a4d 	b.le	a234 <fwp_main_thread+0x1a54>
    9ef0:	eb08001f 	cmp	x0, x8
    9ef4:	9a80b51c 	csinc	x28, x8, x0, lt	// lt = tstop
    9ef8:	eb1c00ff 	cmp	x7, x28
    9efc:	54000a2a 	b.ge	a040 <fwp_main_thread+0x1860>  // b.tcont
    9f00:	f10000ff 	cmp	x7, #0x0
    9f04:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    9f08:	9a9c10e7 	csel	x7, x7, x28, ne	// ne = any
    9f0c:	14000004 	b	9f1c <fwp_main_thread+0x173c>
    9f10:	eb0000ff 	cmp	x7, x0
    9f14:	d37ff8e7 	lsl	x7, x7, #1
    9f18:	9a9cd0e7 	csel	x7, x7, x28, le
    9f1c:	eb1c00ff 	cmp	x7, x28
    9f20:	54ffff8b 	b.lt	9f10 <fwp_main_thread+0x1730>  // b.tstop
    9f24:	b4005746 	cbz	x6, aa0c <fwp_main_thread+0x222c>
    9f28:	aa0603e0 	mov	x0, x6
    9f2c:	d37df0e1 	lsl	x1, x7, #3
    9f30:	52800062 	mov	w2, #0x3                   	// #3
    9f34:	f90027e7 	str	x7, [sp, #72]
    9f38:	a905a3e4 	stp	x4, x8, [sp, #88]
    9f3c:	97ffe862 	bl	40c4 <ad_raw_realloc>
    9f40:	aa0003e6 	mov	x6, x0
    9f44:	f94027e7 	ldr	x7, [sp, #72]
    9f48:	a945a3e4 	ldp	x4, x8, [sp, #88]
    9f4c:	b4000780 	cbz	x0, a03c <fwp_main_thread+0x185c>
    9f50:	f90087e6 	str	x6, [sp, #264]
    9f54:	f9008fe7 	str	x7, [sp, #280]
    9f58:	b400015c 	cbz	x28, 9f80 <fwp_main_thread+0x17a0>
    9f5c:	aa0603e0 	mov	x0, x6
    9f60:	d37df382 	lsl	x2, x28, #3
    9f64:	52800001 	mov	w1, #0x0                   	// #0
    9f68:	f90027e4 	str	x4, [sp, #72]
    9f6c:	f9002fe8 	str	x8, [sp, #88]
    9f70:	97ffe240 	bl	2870 <memset@plt>
    9f74:	f94027e4 	ldr	x4, [sp, #72]
    9f78:	aa0003e6 	mov	x6, x0
    9f7c:	f9402fe8 	ldr	x8, [sp, #88]
    9f80:	b7f800c4 	tbnz	x4, #63, 9f98 <fwp_main_thread+0x17b8>
    9f84:	d37d7c84 	ubfiz	x4, x4, #3, #32
    9f88:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9f8c:	fc6468c0 	ldr	d0, [x6, x4]
    9f90:	1e612800 	fadd	d0, d0, d1
    9f94:	fc2468c0 	str	d0, [x6, x4]
    9f98:	d1000780 	sub	x0, x28, #0x1
    9f9c:	eb00011f 	cmp	x8, x0
    9fa0:	540005ac 	b.gt	a054 <fwp_main_thread+0x1874>
    9fa4:	fc6078c0 	ldr	d0, [x6, x0, lsl #3]
    9fa8:	1e602008 	fcmp	d0, #0.0
    9fac:	540003a0 	b.eq	a020 <fwp_main_thread+0x1840>  // b.none
    9fb0:	92800061 	mov	x1, #0xfffffffffffffffc    	// #-4
    9fb4:	f94017e2 	ldr	x2, [sp, #40]
    9fb8:	9b017d01 	mul	x1, x8, x1
    9fbc:	8b010042 	add	x2, x2, x1
    9fc0:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    9fc4:	37f80142 	tbnz	w2, #31, 9fec <fwp_main_thread+0x180c>
    9fc8:	f9401fe4 	ldr	x4, [sp, #56]
    9fcc:	928000e3 	mov	x3, #0xfffffffffffffff8    	// #-8
    9fd0:	937d7c42 	sbfiz	x2, x2, #3, #32
    9fd4:	9b031103 	madd	x3, x8, x3, x4
    9fd8:	fc6268c1 	ldr	d1, [x6, x2]
    9fdc:	fc607862 	ldr	d2, [x3, x0, lsl #3]
    9fe0:	1e620802 	fmul	d2, d0, d2
    9fe4:	1e622821 	fadd	d1, d1, d2
    9fe8:	fc2268c1 	str	d1, [x6, x2]
    9fec:	f9401be2 	ldr	x2, [sp, #48]
    9ff0:	8b010041 	add	x1, x2, x1
    9ff4:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9ff8:	37f80141 	tbnz	w1, #31, a020 <fwp_main_thread+0x1840>
    9ffc:	f94023e3 	ldr	x3, [sp, #64]
    a000:	928000e2 	mov	x2, #0xfffffffffffffff8    	// #-8
    a004:	937d7c21 	sbfiz	x1, x1, #3, #32
    a008:	9b020d02 	madd	x2, x8, x2, x3
    a00c:	fc6168c1 	ldr	d1, [x6, x1]
    a010:	fc607842 	ldr	d2, [x2, x0, lsl #3]
    a014:	1e620800 	fmul	d0, d0, d2
    a018:	1e602820 	fadd	d0, d1, d0
    a01c:	fc2168c0 	str	d0, [x6, x1]
    a020:	d1000400 	sub	x0, x0, #0x1
    a024:	17ffffde 	b	9f9c <fwp_main_thread+0x17bc>
    a028:	72003c3f 	tst	w1, #0xffff
    a02c:	54fff481 	b.ne	9ebc <fwp_main_thread+0x16dc>  // b.any
    a030:	17ffff9c 	b	9ea0 <fwp_main_thread+0x16c0>
    a034:	aa0803fc 	mov	x28, x8
    a038:	17ffffb0 	b	9ef8 <fwp_main_thread+0x1718>
    a03c:	d2800006 	mov	x6, #0x0                   	// #0
    a040:	f100039f 	cmp	x28, #0x0
    a044:	fa4018c0 	ccmp	x6, #0x0, #0x0, ne	// ne = any
    a048:	540049a0 	b.eq	a97c <fwp_main_thread+0x219c>  // b.none
    a04c:	b4fff9bc 	cbz	x28, 9f80 <fwp_main_thread+0x17a0>
    a050:	17ffffc3 	b	9f5c <fwp_main_thread+0x177c>
    a054:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a058:	eb00011f 	cmp	x8, x0
    a05c:	540048a8 	b.hi	a970 <fwp_main_thread+0x2190>  // b.pmore
    a060:	91000500 	add	x0, x8, #0x1
    a064:	52800041 	mov	w1, #0x2                   	// #2
    a068:	a9029be8 	stp	x8, x6, [sp, #40]
    a06c:	d37df000 	lsl	x0, x0, #3
    a070:	97ffec28 	bl	5110 <fwp_heap_alloc>
    a074:	aa0003fc 	mov	x28, x0
    a078:	a9429be8 	ldp	x8, x6, [sp, #40]
    a07c:	d2800001 	mov	x1, #0x0                   	// #0
    a080:	f8008408 	str	x8, [x0], #8
    a084:	14000004 	b	a094 <fwp_main_thread+0x18b4>
    a088:	f86178c2 	ldr	x2, [x6, x1, lsl #3]
    a08c:	f8217802 	str	x2, [x0, x1, lsl #3]
    a090:	91000421 	add	x1, x1, #0x1
    a094:	eb01011f 	cmp	x8, x1
    a098:	54ffff81 	b.ne	a088 <fwp_main_thread+0x18a8>  // b.any
    a09c:	91014281 	add	x1, x20, #0x50
    a0a0:	f9402be2 	ldr	x2, [sp, #80]
    a0a4:	f941c820 	ldr	x0, [x1, #912]
    a0a8:	eb02001f 	cmp	x0, x2
    a0ac:	54005861 	b.ne	abb8 <fwp_main_thread+0x23d8>  // b.any
    a0b0:	f9405be2 	ldr	x2, [sp, #176]
    a0b4:	aa1503e0 	mov	x0, x21
    a0b8:	f901c822 	str	x2, [x1, #912]
    a0bc:	97ffe836 	bl	4194 <fwp_tape_buffers_release>
    a0c0:	9118c260 	add	x0, x19, #0x630
    a0c4:	f949d801 	ldr	x1, [x0, #5040]
    a0c8:	f949ec02 	ldr	x2, [x0, #5080]
    a0cc:	cb010381 	sub	x1, x28, x1
    a0d0:	eb02403f 	cmp	x1, x2, lsl #16
    a0d4:	54000322 	b.cs	a138 <fwp_main_thread+0x1958>  // b.hs, b.nlast
    a0d8:	d350fc22 	lsr	x2, x1, #16
    a0dc:	d2800503 	mov	x3, #0x28                  	// #40
    a0e0:	f949fc04 	ldr	x4, [x0, #5112]
    a0e4:	9b037c42 	mul	x2, x2, x3
    a0e8:	8b020083 	add	x3, x4, x2
    a0ec:	f9401060 	ldr	x0, [x3, #32]
    a0f0:	b4000240 	cbz	x0, a138 <fwp_main_thread+0x1958>
    a0f4:	38626882 	ldrb	w2, [x4, x2]
    a0f8:	7100085f 	cmp	w2, #0x2
    a0fc:	54004d40 	b.eq	aaa4 <fwp_main_thread+0x22c4>  // b.none
    a100:	7100045f 	cmp	w2, #0x1
    a104:	540001a1 	b.ne	a138 <fwp_main_thread+0x1958>  // b.any
    a108:	29430864 	ldp	w4, w2, [x3, #24]
    a10c:	92403c21 	and	x1, x1, #0xffff
    a110:	9b047c21 	mul	x1, x1, x4
    a114:	d360fc21 	lsr	x1, x1, #32
    a118:	eb02003f 	cmp	x1, x2
    a11c:	540000e2 	b.cs	a138 <fwp_main_thread+0x1958>  // b.hs, b.nlast
    a120:	8b010000 	add	x0, x0, x1
    a124:	39400001 	ldrb	w1, [x0]
    a128:	7103fc3f 	cmp	w1, #0xff
    a12c:	54004680 	b.eq	a9fc <fwp_main_thread+0x221c>  // b.none
    a130:	52800021 	mov	w1, #0x1                   	// #1
    a134:	39000001 	strb	w1, [x0]
    a138:	91014281 	add	x1, x20, #0x50
    a13c:	f94007e2 	ldr	x2, [sp, #8]
    a140:	f941c820 	ldr	x0, [x1, #912]
    a144:	eb02001f 	cmp	x0, x2
    a148:	54005381 	b.ne	abb8 <fwp_main_thread+0x23d8>  // b.any
    a14c:	f94003e0 	ldr	x0, [sp]
    a150:	f9404fe2 	ldr	x2, [sp, #152]
    a154:	f901c822 	str	x2, [x1, #912]
    a158:	97fff14a 	bl	6680 <fwp_tape_scope_release>
    a15c:	f9400380 	ldr	x0, [x28]
    a160:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    a164:	b7f80b00 	tbnz	x0, #63, a2c4 <fwp_main_thread+0x1ae4>
    a168:	9118c261 	add	x1, x19, #0x630
    a16c:	f949d820 	ldr	x0, [x1, #5040]
    a170:	f949ec23 	ldr	x3, [x1, #5080]
    a174:	cb000380 	sub	x0, x28, x0
    a178:	eb03401f 	cmp	x0, x3, lsl #16
    a17c:	54000a42 	b.cs	a2c4 <fwp_main_thread+0x1ae4>  // b.hs, b.nlast
    a180:	d350fc03 	lsr	x3, x0, #16
    a184:	d2800504 	mov	x4, #0x28                  	// #40
    a188:	f949fc25 	ldr	x5, [x1, #5112]
    a18c:	9b047c63 	mul	x3, x3, x4
    a190:	8b0300a4 	add	x4, x5, x3
    a194:	f9401081 	ldr	x1, [x4, #32]
    a198:	b4000961 	cbz	x1, a2c4 <fwp_main_thread+0x1ae4>
    a19c:	386368a3 	ldrb	w3, [x5, x3]
    a1a0:	7100087f 	cmp	w3, #0x2
    a1a4:	540008c0 	b.eq	a2bc <fwp_main_thread+0x1adc>  // b.none
    a1a8:	7100047f 	cmp	w3, #0x1
    a1ac:	540008c1 	b.ne	a2c4 <fwp_main_thread+0x1ae4>  // b.any
    a1b0:	29430c85 	ldp	w5, w3, [x4, #24]
    a1b4:	92403c00 	and	x0, x0, #0xffff
    a1b8:	9b057c00 	mul	x0, x0, x5
    a1bc:	d360fc00 	lsr	x0, x0, #32
    a1c0:	eb03001f 	cmp	x0, x3
    a1c4:	54000802 	b.cs	a2c4 <fwp_main_thread+0x1ae4>  // b.hs, b.nlast
    a1c8:	8b000021 	add	x1, x1, x0
    a1cc:	39400020 	ldrb	w0, [x1]
    a1d0:	7100041f 	cmp	w0, #0x1
    a1d4:	54000781 	b.ne	a2c4 <fwp_main_thread+0x1ae4>  // b.any
    a1d8:	aa1c03e3 	mov	x3, x28
    a1dc:	d2800000 	mov	x0, #0x0                   	// #0
    a1e0:	d0000004 	adrp	x4, c000 <_IO_stdin_used+0xd20>
    a1e4:	91002386 	add	x6, x28, #0x8
    a1e8:	d2800001 	mov	x1, #0x0                   	// #0
    a1ec:	fd416881 	ldr	d1, [x4, #720]
    a1f0:	eb02003f 	cmp	x1, x2
    a1f4:	54000520 	b.eq	a298 <fwp_main_thread+0x1ab8>  // b.none
    a1f8:	f9400384 	ldr	x4, [x28]
    a1fc:	b7f804a4 	tbnz	x4, #63, a290 <fwp_main_thread+0x1ab0>
    a200:	aa0603e5 	mov	x5, x6
    a204:	f9400067 	ldr	x7, [x3]
    a208:	d37df024 	lsl	x4, x1, #3
    a20c:	fc6468a0 	ldr	d0, [x5, x4]
    a210:	b7f802a7 	tbnz	x7, #63, a264 <fwp_main_thread+0x1a84>
    a214:	1e600820 	fmul	d0, d1, d0
    a218:	8b030084 	add	x4, x4, x3
    a21c:	91000421 	add	x1, x1, #0x1
    a220:	fd000480 	str	d0, [x4, #8]
    a224:	17fffff3 	b	a1f0 <fwp_main_thread+0x1a10>
    a228:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a22c:	9118e000 	add	x0, x0, #0x638
    a230:	97ffe841 	bl	4334 <fwp_trap>
    a234:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a238:	91220000 	add	x0, x0, #0x880
    a23c:	97ffe83e 	bl	4334 <fwp_trap>
    a240:	aa1c03e0 	mov	x0, x28
    a244:	97ffe85c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a248:	17fffeaa 	b	9cf0 <fwp_main_thread+0x1510>
    a24c:	a9031fe0 	stp	x0, x7, [sp, #48]
    a250:	f90023e5 	str	x5, [sp, #64]
    a254:	97ffe858 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a258:	a9431fe0 	ldp	x0, x7, [sp, #48]
    a25c:	f94023e5 	ldr	x5, [sp, #64]
    a260:	17fffdc1 	b	9964 <fwp_main_thread+0x1184>
    a264:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a268:	912aa000 	add	x0, x0, #0xaa8
    a26c:	97ffe832 	bl	4334 <fwp_trap>
    a270:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a274:	91282000 	add	x0, x0, #0xa08
    a278:	f90123fb 	str	x27, [sp, #576]
    a27c:	f90127fc 	str	x28, [sp, #584]
    a280:	97ffe440 	bl	3380 <ad_raw_fail>
    a284:	f90123fb 	str	x27, [sp, #576]
    a288:	f90127fc 	str	x28, [sp, #584]
    a28c:	97ffe185 	bl	28a0 <__stack_chk_fail@plt>
    a290:	f9400b85 	ldr	x5, [x28, #16]
    a294:	17ffffdc 	b	a204 <fwp_main_thread+0x1a24>
    a298:	f90017e3 	str	x3, [sp, #40]
    a29c:	97fff305 	bl	6eb0 <fwp_drop10>
    a2a0:	f94017e3 	ldr	x3, [sp, #40]
    a2a4:	aa1b03e0 	mov	x0, x27
    a2a8:	d2800005 	mov	x5, #0x0                   	// #0
    a2ac:	b4000620 	cbz	x0, a370 <fwp_main_thread+0x1b90>
    a2b0:	f9400800 	ldr	x0, [x0, #16]
    a2b4:	910004a5 	add	x5, x5, #0x1
    a2b8:	17fffffd 	b	a2ac <fwp_main_thread+0x1acc>
    a2bc:	72003c1f 	tst	w0, #0xffff
    a2c0:	54fff860 	b.eq	a1cc <fwp_main_thread+0x19ec>  // b.none
    a2c4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a2c8:	eb00005f 	cmp	x2, x0
    a2cc:	54003528 	b.hi	a970 <fwp_main_thread+0x2190>  // b.pmore
    a2d0:	91000440 	add	x0, x2, #0x1
    a2d4:	52800021 	mov	w1, #0x1                   	// #1
    a2d8:	f90017e2 	str	x2, [sp, #40]
    a2dc:	d37df000 	lsl	x0, x0, #3
    a2e0:	97ffeb8c 	bl	5110 <fwp_heap_alloc>
    a2e4:	f94017e2 	ldr	x2, [sp, #40]
    a2e8:	9118c265 	add	x5, x19, #0x630
    a2ec:	f9000002 	str	x2, [x0]
    a2f0:	aa0003e3 	mov	x3, x0
    a2f4:	f949d8a1 	ldr	x1, [x5, #5040]
    a2f8:	f949eca0 	ldr	x0, [x5, #5080]
    a2fc:	cb010061 	sub	x1, x3, x1
    a300:	eb00403f 	cmp	x1, x0, lsl #16
    a304:	54000322 	b.cs	a368 <fwp_main_thread+0x1b88>  // b.hs, b.nlast
    a308:	d350fc24 	lsr	x4, x1, #16
    a30c:	d2800500 	mov	x0, #0x28                  	// #40
    a310:	f949fca6 	ldr	x6, [x5, #5112]
    a314:	9b007c84 	mul	x4, x4, x0
    a318:	8b0400c5 	add	x5, x6, x4
    a31c:	f94010a0 	ldr	x0, [x5, #32]
    a320:	b4000240 	cbz	x0, a368 <fwp_main_thread+0x1b88>
    a324:	386468c4 	ldrb	w4, [x6, x4]
    a328:	7100089f 	cmp	w4, #0x2
    a32c:	54000940 	b.eq	a454 <fwp_main_thread+0x1c74>  // b.none
    a330:	7100049f 	cmp	w4, #0x1
    a334:	540001a1 	b.ne	a368 <fwp_main_thread+0x1b88>  // b.any
    a338:	294310a6 	ldp	w6, w4, [x5, #24]
    a33c:	92403c21 	and	x1, x1, #0xffff
    a340:	9b067c21 	mul	x1, x1, x6
    a344:	d360fc21 	lsr	x1, x1, #32
    a348:	eb04003f 	cmp	x1, x4
    a34c:	540000e2 	b.cs	a368 <fwp_main_thread+0x1b88>  // b.hs, b.nlast
    a350:	8b010000 	add	x0, x0, x1
    a354:	39400001 	ldrb	w1, [x0]
    a358:	7103fc3f 	cmp	w1, #0xff
    a35c:	54000700 	b.eq	a43c <fwp_main_thread+0x1c5c>  // b.none
    a360:	52800021 	mov	w1, #0x1                   	// #1
    a364:	39000001 	strb	w1, [x0]
    a368:	aa1c03e0 	mov	x0, x28
    a36c:	17ffff9d 	b	a1e0 <fwp_main_thread+0x1a00>
    a370:	f9400060 	ldr	x0, [x3]
    a374:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    a378:	b7f83ce0 	tbnz	x0, #63, ab14 <fwp_main_thread+0x2334>
    a37c:	9118c261 	add	x1, x19, #0x630
    a380:	f949d820 	ldr	x0, [x1, #5040]
    a384:	f949ec24 	ldr	x4, [x1, #5080]
    a388:	cb000060 	sub	x0, x3, x0
    a38c:	eb04401f 	cmp	x0, x4, lsl #16
    a390:	54003c22 	b.cs	ab14 <fwp_main_thread+0x2334>  // b.hs, b.nlast
    a394:	d350fc04 	lsr	x4, x0, #16
    a398:	d2800506 	mov	x6, #0x28                  	// #40
    a39c:	f949fc27 	ldr	x7, [x1, #5112]
    a3a0:	9b067c84 	mul	x4, x4, x6
    a3a4:	8b0400e6 	add	x6, x7, x4
    a3a8:	f94010c1 	ldr	x1, [x6, #32]
    a3ac:	b4003b41 	cbz	x1, ab14 <fwp_main_thread+0x2334>
    a3b0:	386468e4 	ldrb	w4, [x7, x4]
    a3b4:	7100089f 	cmp	w4, #0x2
    a3b8:	54003aa0 	b.eq	ab0c <fwp_main_thread+0x232c>  // b.none
    a3bc:	7100049f 	cmp	w4, #0x1
    a3c0:	54003aa1 	b.ne	ab14 <fwp_main_thread+0x2334>  // b.any
    a3c4:	294310c7 	ldp	w7, w4, [x6, #24]
    a3c8:	92403c00 	and	x0, x0, #0xffff
    a3cc:	9b077c00 	mul	x0, x0, x7
    a3d0:	d360fc00 	lsr	x0, x0, #32
    a3d4:	eb04001f 	cmp	x0, x4
    a3d8:	540039e2 	b.cs	ab14 <fwp_main_thread+0x2334>  // b.hs, b.nlast
    a3dc:	8b000021 	add	x1, x1, x0
    a3e0:	39400026 	ldrb	w6, [x1]
    a3e4:	710004df 	cmp	w6, #0x1
    a3e8:	54003961 	b.ne	ab14 <fwp_main_thread+0x2334>  // b.any
    a3ec:	91002064 	add	x4, x3, #0x8
    a3f0:	eb05005f 	cmp	x2, x5
    a3f4:	aa1b03e1 	mov	x1, x27
    a3f8:	9a859042 	csel	x2, x2, x5, ls	// ls = plast
    a3fc:	91002067 	add	x7, x3, #0x8
    a400:	d2800000 	mov	x0, #0x0                   	// #0
    a404:	14000008 	b	a424 <fwp_main_thread+0x1c44>
    a408:	aa0703e5 	mov	x5, x7
    a40c:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    a410:	fd400420 	ldr	d0, [x1, #8]
    a414:	1e613800 	fsub	d0, d0, d1
    a418:	fc207880 	str	d0, [x4, x0, lsl #3]
    a41c:	91000400 	add	x0, x0, #0x1
    a420:	f9400821 	ldr	x1, [x1, #16]
    a424:	eb02001f 	cmp	x0, x2
    a428:	540001e0 	b.eq	a464 <fwp_main_thread+0x1c84>  // b.none
    a42c:	f9400065 	ldr	x5, [x3]
    a430:	b6fffec5 	tbz	x5, #63, a408 <fwp_main_thread+0x1c28>
    a434:	f9400865 	ldr	x5, [x3, #16]
    a438:	17fffff5 	b	a40c <fwp_main_thread+0x1c2c>
    a43c:	a9028be0 	stp	x0, x2, [sp, #40]
    a440:	f9001fe3 	str	x3, [sp, #56]
    a444:	97ffe7dc 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a448:	a9428be0 	ldp	x0, x2, [sp, #40]
    a44c:	f9401fe3 	ldr	x3, [sp, #56]
    a450:	17ffffc4 	b	a360 <fwp_main_thread+0x1b80>
    a454:	72003c3f 	tst	w1, #0xffff
    a458:	54fff7e0 	b.eq	a354 <fwp_main_thread+0x1b74>  // b.none
    a45c:	aa1c03e0 	mov	x0, x28
    a460:	17ffff60 	b	a1e0 <fwp_main_thread+0x1a00>
    a464:	9118c260 	add	x0, x19, #0x630
    a468:	aa1b03ea 	mov	x10, x27
    a46c:	d2800005 	mov	x5, #0x0                   	// #0
    a470:	d280050b 	mov	x11, #0x28                  	// #40
    a474:	f949ec08 	ldr	x8, [x0, #5080]
    a478:	f949d80c 	ldr	x12, [x0, #5040]
    a47c:	f949fc0d 	ldr	x13, [x0, #5112]
    a480:	d370bd08 	lsl	x8, x8, #16
    a484:	14000003 	b	a490 <fwp_main_thread+0x1cb0>
    a488:	f940094a 	ldr	x10, [x10, #16]
    a48c:	910004a5 	add	x5, x5, #0x1
    a490:	f100015f 	cmp	x10, #0x0
    a494:	fa4210a2 	ccmp	x5, x2, #0x2, ne	// ne = any
    a498:	54000302 	b.cs	a4f8 <fwp_main_thread+0x1d18>  // b.hs, b.nlast
    a49c:	cb0c0140 	sub	x0, x10, x12
    a4a0:	eb08001f 	cmp	x0, x8
    a4a4:	540002a2 	b.cs	a4f8 <fwp_main_thread+0x1d18>  // b.hs, b.nlast
    a4a8:	d350fc07 	lsr	x7, x0, #16
    a4ac:	9b0b7ce7 	mul	x7, x7, x11
    a4b0:	8b0701a9 	add	x9, x13, x7
    a4b4:	f9401121 	ldr	x1, [x9, #32]
    a4b8:	b4000201 	cbz	x1, a4f8 <fwp_main_thread+0x1d18>
    a4bc:	386769a7 	ldrb	w7, [x13, x7]
    a4c0:	710008ff 	cmp	w7, #0x2
    a4c4:	54003340 	b.eq	ab2c <fwp_main_thread+0x234c>  // b.none
    a4c8:	710004ff 	cmp	w7, #0x1
    a4cc:	54000161 	b.ne	a4f8 <fwp_main_thread+0x1d18>  // b.any
    a4d0:	29431d2e 	ldp	w14, w7, [x9, #24]
    a4d4:	92403c00 	and	x0, x0, #0xffff
    a4d8:	9b0e7c00 	mul	x0, x0, x14
    a4dc:	d360fc00 	lsr	x0, x0, #32
    a4e0:	eb07001f 	cmp	x0, x7
    a4e4:	540000a2 	b.cs	a4f8 <fwp_main_thread+0x1d18>  // b.hs, b.nlast
    a4e8:	8b000021 	add	x1, x1, x0
    a4ec:	39400020 	ldrb	w0, [x1]
    a4f0:	7100041f 	cmp	w0, #0x1
    a4f4:	54fffca0 	b.eq	a488 <fwp_main_thread+0x1ca8>  // b.none
    a4f8:	d280001c 	mov	x28, #0x0                   	// #0
    a4fc:	a902dffb 	stp	x27, x23, [sp, #40]
    a500:	aa0203f7 	mov	x23, x2
    a504:	aa0403fb 	mov	x27, x4
    a508:	f90023e3 	str	x3, [sp, #64]
    a50c:	aa1c03e3 	mov	x3, x28
    a510:	aa1503fc 	mov	x28, x21
    a514:	aa0503f5 	mov	x21, x5
    a518:	b9003be6 	str	w6, [sp, #56]
    a51c:	eb1502ff 	cmp	x23, x21
    a520:	54000509 	b.ls	a5c0 <fwp_main_thread+0x1de0>  // b.plast
    a524:	d1002364 	sub	x4, x27, #0x8
    a528:	aa1603e1 	mov	x1, x22
    a52c:	52800020 	mov	w0, #0x1                   	// #1
    a530:	f8777884 	ldr	x4, [x4, x23, lsl #3]
    a534:	a9150fe4 	stp	x4, x3, [sp, #336]
    a538:	97ffeb5a 	bl	52a0 <fwp_data.part.0.constprop.0>
    a53c:	aa0003e3 	mov	x3, x0
    a540:	9118c265 	add	x5, x19, #0x630
    a544:	f949d8a1 	ldr	x1, [x5, #5040]
    a548:	f949eca0 	ldr	x0, [x5, #5080]
    a54c:	cb010061 	sub	x1, x3, x1
    a550:	eb00403f 	cmp	x1, x0, lsl #16
    a554:	54000322 	b.cs	a5b8 <fwp_main_thread+0x1dd8>  // b.hs, b.nlast
    a558:	d350fc24 	lsr	x4, x1, #16
    a55c:	d2800500 	mov	x0, #0x28                  	// #40
    a560:	f949fca6 	ldr	x6, [x5, #5112]
    a564:	9b007c84 	mul	x4, x4, x0
    a568:	8b0400c5 	add	x5, x6, x4
    a56c:	f94010a0 	ldr	x0, [x5, #32]
    a570:	b4000240 	cbz	x0, a5b8 <fwp_main_thread+0x1dd8>
    a574:	386468c4 	ldrb	w4, [x6, x4]
    a578:	7100089f 	cmp	w4, #0x2
    a57c:	54002e60 	b.eq	ab48 <fwp_main_thread+0x2368>  // b.none
    a580:	7100049f 	cmp	w4, #0x1
    a584:	540001a1 	b.ne	a5b8 <fwp_main_thread+0x1dd8>  // b.any
    a588:	294310a6 	ldp	w6, w4, [x5, #24]
    a58c:	92403c21 	and	x1, x1, #0xffff
    a590:	9b067c21 	mul	x1, x1, x6
    a594:	d360fc21 	lsr	x1, x1, #32
    a598:	eb04003f 	cmp	x1, x4
    a59c:	540000e2 	b.cs	a5b8 <fwp_main_thread+0x1dd8>  // b.hs, b.nlast
    a5a0:	8b010000 	add	x0, x0, x1
    a5a4:	39400001 	ldrb	w1, [x0]
    a5a8:	7103fc3f 	cmp	w1, #0xff
    a5ac:	54002c60 	b.eq	ab38 <fwp_main_thread+0x2358>  // b.none
    a5b0:	52800021 	mov	w1, #0x1                   	// #1
    a5b4:	39000001 	strb	w1, [x0]
    a5b8:	d10006f7 	sub	x23, x23, #0x1
    a5bc:	17ffffd8 	b	a51c <fwp_main_thread+0x1d3c>
    a5c0:	aa1b03e4 	mov	x4, x27
    a5c4:	aa1503e5 	mov	x5, x21
    a5c8:	a942dffb 	ldp	x27, x23, [sp, #40]
    a5cc:	aa1c03f5 	mov	x21, x28
    a5d0:	b9403be6 	ldr	w6, [sp, #56]
    a5d4:	aa0303fc 	mov	x28, x3
    a5d8:	f94023e3 	ldr	x3, [sp, #64]
    a5dc:	b50011a5 	cbnz	x5, a810 <fwp_main_thread+0x2030>
    a5e0:	f9001ffb 	str	x27, [sp, #56]
    a5e4:	710000df 	cmp	w6, #0x0
    a5e8:	9118c266 	add	x6, x19, #0x630
    a5ec:	9a9f0084 	csel	x4, x4, xzr, eq	// eq = none
    a5f0:	aa1c03e2 	mov	x2, x28
    a5f4:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    a5f8:	aa1503fc 	mov	x28, x21
    a5fc:	aa0403f5 	mov	x21, x4
    a600:	a9028ff7 	stp	x23, x3, [sp, #40]
    a604:	aa0503f7 	mov	x23, x5
    a608:	f90023f8 	str	x24, [sp, #64]
    a60c:	aa0603f8 	mov	x24, x6
    a610:	b10006ff 	cmn	x23, #0x1
    a614:	54ff7aa0 	b.eq	9568 <fwp_main_thread+0xd88>  // b.none
    a618:	f8777aa0 	ldr	x0, [x21, x23, lsl #3]
    a61c:	aa1603e1 	mov	x1, x22
    a620:	a9150be0 	stp	x0, x2, [sp, #336]
    a624:	52800020 	mov	w0, #0x1                   	// #1
    a628:	97ffeb1e 	bl	52a0 <fwp_data.part.0.constprop.0>
    a62c:	f949db01 	ldr	x1, [x24, #5040]
    a630:	aa0003e2 	mov	x2, x0
    a634:	f949ef00 	ldr	x0, [x24, #5080]
    a638:	cb010041 	sub	x1, x2, x1
    a63c:	eb00403f 	cmp	x1, x0, lsl #16
    a640:	54000322 	b.cs	a6a4 <fwp_main_thread+0x1ec4>  // b.hs, b.nlast
    a644:	d350fc23 	lsr	x3, x1, #16
    a648:	d2800500 	mov	x0, #0x28                  	// #40
    a64c:	f949ff08 	ldr	x8, [x24, #5112]
    a650:	9b007c63 	mul	x3, x3, x0
    a654:	8b030107 	add	x7, x8, x3
    a658:	f94010e0 	ldr	x0, [x7, #32]
    a65c:	b4000240 	cbz	x0, a6a4 <fwp_main_thread+0x1ec4>
    a660:	38636903 	ldrb	w3, [x8, x3]
    a664:	7100087f 	cmp	w3, #0x2
    a668:	54000c40 	b.eq	a7f0 <fwp_main_thread+0x2010>  // b.none
    a66c:	7100047f 	cmp	w3, #0x1
    a670:	540001a1 	b.ne	a6a4 <fwp_main_thread+0x1ec4>  // b.any
    a674:	29430ce8 	ldp	w8, w3, [x7, #24]
    a678:	92403c21 	and	x1, x1, #0xffff
    a67c:	9b087c21 	mul	x1, x1, x8
    a680:	d360fc21 	lsr	x1, x1, #32
    a684:	eb03003f 	cmp	x1, x3
    a688:	540000e2 	b.cs	a6a4 <fwp_main_thread+0x1ec4>  // b.hs, b.nlast
    a68c:	8b010000 	add	x0, x0, x1
    a690:	39400001 	ldrb	w1, [x0]
    a694:	7103fc3f 	cmp	w1, #0xff
    a698:	54000a40 	b.eq	a7e0 <fwp_main_thread+0x2000>  // b.none
    a69c:	52800021 	mov	w1, #0x1                   	// #1
    a6a0:	39000001 	strb	w1, [x0]
    a6a4:	d10006f7 	sub	x23, x23, #0x1
    a6a8:	17ffffda 	b	a610 <fwp_main_thread+0x1e30>
    a6ac:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a6b0:	912b4000 	add	x0, x0, #0xad0
    a6b4:	97ffe720 	bl	4334 <fwp_trap>
    a6b8:	f94017e0 	ldr	x0, [sp, #40]
    a6bc:	97ffed71 	bl	5c80 <fwp_rc_free_arr>
    a6c0:	17fffc69 	b	9864 <fwp_main_thread+0x1084>
    a6c4:	72003c3f 	tst	w1, #0xffff
    a6c8:	54ff8ce1 	b.ne	9864 <fwp_main_thread+0x1084>  // b.any
    a6cc:	17fffc5e 	b	9844 <fwp_main_thread+0x1064>
    a6d0:	72003c3f 	tst	w1, #0xffff
    a6d4:	54ff86e1 	b.ne	97b0 <fwp_main_thread+0xfd0>  // b.any
    a6d8:	17fffc31 	b	979c <fwp_main_thread+0xfbc>
    a6dc:	f9001fe0 	str	x0, [sp, #56]
    a6e0:	97ffe735 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a6e4:	f9401fe0 	ldr	x0, [sp, #56]
    a6e8:	17fffc30 	b	97a8 <fwp_main_thread+0xfc8>
    a6ec:	aa1503e0 	mov	x0, x21
    a6f0:	f9400ab5 	ldr	x21, [x21, #16]
    a6f4:	710008bf 	cmp	w5, #0x2
    a6f8:	54000180 	b.eq	a728 <fwp_main_thread+0x1f48>  // b.none
    a6fc:	29430865 	ldp	w5, w2, [x3, #24]
    a700:	9b057c21 	mul	x1, x1, x5
    a704:	eb41805f 	cmp	x2, x1, lsr #32
    a708:	54ff7949 	b.ls	9630 <fwp_main_thread+0xe50>  // b.plast
    a70c:	97ffe7c5 	bl	4620 <fwp_mem_free>
    a710:	d2800506 	mov	x6, #0x28                  	// #40
    a714:	17fffbc7 	b	9630 <fwp_main_thread+0xe50>
    a718:	f2403c21 	ands	x1, x1, #0xffff
    a71c:	54ff7b80 	b.eq	968c <fwp_main_thread+0xeac>  // b.none
    a720:	a942dbf5 	ldp	x21, x22, [sp, #40]
    a724:	17fffbe3 	b	96b0 <fwp_main_thread+0xed0>
    a728:	b5ff7841 	cbnz	x1, 9630 <fwp_main_thread+0xe50>
    a72c:	17fffff8 	b	a70c <fwp_main_thread+0x1f2c>
    a730:	ca404401 	eor	x1, x0, x0, lsr #17
    a734:	9118c263 	add	x3, x19, #0x630
    a738:	ca412421 	eor	x1, x1, x1, lsr #9
    a73c:	92401c21 	and	x1, x1, #0xff
    a740:	910a2422 	add	x2, x1, #0x289
    a744:	8b010c61 	add	x1, x3, x1, lsl #3
    a748:	8b020c62 	add	x2, x3, x2, lsl #3
    a74c:	f94a2421 	ldr	x1, [x1, #5192]
    a750:	b4ffd6c1 	cbz	x1, a228 <fwp_main_thread+0x1a48>
    a754:	f9400023 	ldr	x3, [x1]
    a758:	eb03001f 	cmp	x0, x3
    a75c:	54000b00 	b.eq	a8bc <fwp_main_thread+0x20dc>  // b.none
    a760:	91004022 	add	x2, x1, #0x10
    a764:	f9400821 	ldr	x1, [x1, #16]
    a768:	17fffffa 	b	a750 <fwp_main_thread+0x1f70>
    a76c:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a770:	9118c260 	add	x0, x19, #0x630
    a774:	ca412421 	eor	x1, x1, x1, lsr #9
    a778:	92401c21 	and	x1, x1, #0xff
    a77c:	910a2422 	add	x2, x1, #0x289
    a780:	8b010c01 	add	x1, x0, x1, lsl #3
    a784:	8b020c02 	add	x2, x0, x2, lsl #3
    a788:	f94a2420 	ldr	x0, [x1, #5192]
    a78c:	b4ffd4e0 	cbz	x0, a228 <fwp_main_thread+0x1a48>
    a790:	f9400001 	ldr	x1, [x0]
    a794:	eb1c003f 	cmp	x1, x28
    a798:	54000560 	b.eq	a844 <fwp_main_thread+0x2064>  // b.none
    a79c:	91004002 	add	x2, x0, #0x10
    a7a0:	f9400800 	ldr	x0, [x0, #16]
    a7a4:	17fffffa 	b	a78c <fwp_main_thread+0x1fac>
    a7a8:	f94002a2 	ldr	x2, [x21]
    a7ac:	aa1503e0 	mov	x0, x21
    a7b0:	b7f80c02 	tbnz	x2, #63, a930 <fwp_main_thread+0x2150>
    a7b4:	aa1503e3 	mov	x3, x21
    a7b8:	a942dbf5 	ldp	x21, x22, [sp, #40]
    a7bc:	710008bf 	cmp	w5, #0x2
    a7c0:	54000b40 	b.eq	a928 <fwp_main_thread+0x2148>  // b.none
    a7c4:	29430082 	ldp	w2, w0, [x4, #24]
    a7c8:	9b027c21 	mul	x1, x1, x2
    a7cc:	eb41801f 	cmp	x0, x1, lsr #32
    a7d0:	54ff7269 	b.ls	961c <fwp_main_thread+0xe3c>  // b.plast
    a7d4:	aa0303e0 	mov	x0, x3
    a7d8:	97ffe792 	bl	4620 <fwp_mem_free>
    a7dc:	17fffb90 	b	961c <fwp_main_thread+0xe3c>
    a7e0:	a9048be0 	stp	x0, x2, [sp, #72]
    a7e4:	97ffe6f4 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a7e8:	a9448be0 	ldp	x0, x2, [sp, #72]
    a7ec:	17ffffac 	b	a69c <fwp_main_thread+0x1ebc>
    a7f0:	72003c3f 	tst	w1, #0xffff
    a7f4:	54fff4e0 	b.eq	a690 <fwp_main_thread+0x1eb0>  // b.none
    a7f8:	d10006f7 	sub	x23, x23, #0x1
    a7fc:	17ffff85 	b	a610 <fwp_main_thread+0x1e30>
    a800:	f2403c21 	ands	x1, x1, #0xffff
    a804:	54ff6fa0 	b.eq	95f8 <fwp_main_thread+0xe18>  // b.none
    a808:	a942dbf5 	ldp	x21, x22, [sp, #40]
    a80c:	17fffb84 	b	961c <fwp_main_thread+0xe3c>
    a810:	aa1b03e2 	mov	x2, x27
    a814:	d2800000 	mov	x0, #0x0                   	// #0
    a818:	f8607881 	ldr	x1, [x4, x0, lsl #3]
    a81c:	91000400 	add	x0, x0, #0x1
    a820:	f9000441 	str	x1, [x2, #8]
    a824:	aa0203e1 	mov	x1, x2
    a828:	f9400842 	ldr	x2, [x2, #16]
    a82c:	eb0000bf 	cmp	x5, x0
    a830:	54ffff41 	b.ne	a818 <fwp_main_thread+0x2038>  // b.any
    a834:	f900083c 	str	x28, [x1, #16]
    a838:	aa1b03fc 	mov	x28, x27
    a83c:	f9001fe2 	str	x2, [sp, #56]
    a840:	17ffff69 	b	a5e4 <fwp_main_thread+0x1e04>
    a844:	f9400041 	ldr	x1, [x2]
    a848:	f9400420 	ldr	x0, [x1, #8]
    a84c:	d1000400 	sub	x0, x0, #0x1
    a850:	f9000420 	str	x0, [x1, #8]
    a854:	f103f81f 	cmp	x0, #0xfe
    a858:	54ff8061 	b.ne	9864 <fwp_main_thread+0x1084>  // b.any
    a85c:	39400380 	ldrb	w0, [x28]
    a860:	7103fc1f 	cmp	w0, #0xff
    a864:	54000080 	b.eq	a874 <fwp_main_thread+0x2094>  // b.none
    a868:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a86c:	39000380 	strb	w0, [x28]
    a870:	17fffbfd 	b	9864 <fwp_main_thread+0x1084>
    a874:	aa1c03e0 	mov	x0, x28
    a878:	97ffe6cf 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a87c:	17fffffb 	b	a868 <fwp_main_thread+0x2088>
    a880:	ca404401 	eor	x1, x0, x0, lsr #17
    a884:	9118c263 	add	x3, x19, #0x630
    a888:	ca412421 	eor	x1, x1, x1, lsr #9
    a88c:	92401c21 	and	x1, x1, #0xff
    a890:	910a2422 	add	x2, x1, #0x289
    a894:	8b010c61 	add	x1, x3, x1, lsl #3
    a898:	8b020c62 	add	x2, x3, x2, lsl #3
    a89c:	f94a2421 	ldr	x1, [x1, #5192]
    a8a0:	b4ffcc41 	cbz	x1, a228 <fwp_main_thread+0x1a48>
    a8a4:	f9400023 	ldr	x3, [x1]
    a8a8:	eb03001f 	cmp	x0, x3
    a8ac:	54000260 	b.eq	a8f8 <fwp_main_thread+0x2118>  // b.none
    a8b0:	91004022 	add	x2, x1, #0x10
    a8b4:	f9400821 	ldr	x1, [x1, #16]
    a8b8:	17fffffa 	b	a8a0 <fwp_main_thread+0x20c0>
    a8bc:	f9400042 	ldr	x2, [x2]
    a8c0:	f9400441 	ldr	x1, [x2, #8]
    a8c4:	d1000421 	sub	x1, x1, #0x1
    a8c8:	f9000441 	str	x1, [x2, #8]
    a8cc:	f103f83f 	cmp	x1, #0xfe
    a8d0:	54ff6a61 	b.ne	961c <fwp_main_thread+0xe3c>  // b.any
    a8d4:	39400001 	ldrb	w1, [x0]
    a8d8:	7103fc3f 	cmp	w1, #0xff
    a8dc:	54000081 	b.ne	a8ec <fwp_main_thread+0x210c>  // b.any
    a8e0:	f90017e0 	str	x0, [sp, #40]
    a8e4:	97ffe6b4 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a8e8:	f94017e0 	ldr	x0, [sp, #40]
    a8ec:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a8f0:	39000001 	strb	w1, [x0]
    a8f4:	17fffb4a 	b	961c <fwp_main_thread+0xe3c>
    a8f8:	f9400042 	ldr	x2, [x2]
    a8fc:	f9400441 	ldr	x1, [x2, #8]
    a900:	d1000421 	sub	x1, x1, #0x1
    a904:	f9000441 	str	x1, [x2, #8]
    a908:	f103f83f 	cmp	x1, #0xfe
    a90c:	54ff6d21 	b.ne	96b0 <fwp_main_thread+0xed0>  // b.any
    a910:	39400001 	ldrb	w1, [x0]
    a914:	7103fc3f 	cmp	w1, #0xff
    a918:	54000200 	b.eq	a958 <fwp_main_thread+0x2178>  // b.none
    a91c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a920:	39000001 	strb	w1, [x0]
    a924:	17fffb63 	b	96b0 <fwp_main_thread+0xed0>
    a928:	b5ff67a1 	cbnz	x1, 961c <fwp_main_thread+0xe3c>
    a92c:	17ffffaa 	b	a7d4 <fwp_main_thread+0x1ff4>
    a930:	f94006b5 	ldr	x21, [x21, #8]
    a934:	710008bf 	cmp	w5, #0x2
    a938:	54000180 	b.eq	a968 <fwp_main_thread+0x2188>  // b.none
    a93c:	29430885 	ldp	w5, w2, [x4, #24]
    a940:	9b057c21 	mul	x1, x1, x5
    a944:	eb41805f 	cmp	x2, x1, lsr #32
    a948:	54ff62a9 	b.ls	959c <fwp_main_thread+0xdbc>  // b.plast
    a94c:	97ffe735 	bl	4620 <fwp_mem_free>
    a950:	d2800507 	mov	x7, #0x28                  	// #40
    a954:	17fffb12 	b	959c <fwp_main_thread+0xdbc>
    a958:	f90017e0 	str	x0, [sp, #40]
    a95c:	97ffe696 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a960:	f94017e0 	ldr	x0, [sp, #40]
    a964:	17ffffee 	b	a91c <fwp_main_thread+0x213c>
    a968:	b5ff61a1 	cbnz	x1, 959c <fwp_main_thread+0xdbc>
    a96c:	17fffff8 	b	a94c <fwp_main_thread+0x216c>
    a970:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a974:	912a6000 	add	x0, x0, #0xa98
    a978:	97ffe66f 	bl	4334 <fwp_trap>
    a97c:	f9405be1 	ldr	x1, [sp, #176]
    a980:	91014294 	add	x20, x20, #0x50
    a984:	aa1503e0 	mov	x0, x21
    a988:	f901ca81 	str	x1, [x20, #912]
    a98c:	97ffe602 	bl	4194 <fwp_tape_buffers_release>
    a990:	b00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    a994:	f947e863 	ldr	x3, [x3, #4048]
    a998:	d2800262 	mov	x2, #0x13                  	// #19
    a99c:	d2800021 	mov	x1, #0x1                   	// #1
    a9a0:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    a9a4:	910ba000 	add	x0, x0, #0x2e8
    a9a8:	f9400063 	ldr	x3, [x3]
    a9ac:	97ffdffd 	bl	29a0 <fwrite@plt>
    a9b0:	d2800000 	mov	x0, #0x0                   	// #0
    a9b4:	97ffe007 	bl	29d0 <fflush@plt>
    a9b8:	52800cc0 	mov	w0, #0x66                  	// #102
    a9bc:	97ffe015 	bl	2a10 <_Exit@plt>
    a9c0:	ca4644c1 	eor	x1, x6, x6, lsr #17
    a9c4:	9118c260 	add	x0, x19, #0x630
    a9c8:	ca412421 	eor	x1, x1, x1, lsr #9
    a9cc:	92401c21 	and	x1, x1, #0xff
    a9d0:	910a2422 	add	x2, x1, #0x289
    a9d4:	8b010c01 	add	x1, x0, x1, lsl #3
    a9d8:	8b020c02 	add	x2, x0, x2, lsl #3
    a9dc:	f94a2420 	ldr	x0, [x1, #5192]
    a9e0:	b4ffc240 	cbz	x0, a228 <fwp_main_thread+0x1a48>
    a9e4:	f9400001 	ldr	x1, [x0]
    a9e8:	eb1c003f 	cmp	x1, x28
    a9ec:	54000620 	b.eq	aab0 <fwp_main_thread+0x22d0>  // b.none
    a9f0:	91004002 	add	x2, x0, #0x10
    a9f4:	f9400800 	ldr	x0, [x0, #16]
    a9f8:	17fffffa 	b	a9e0 <fwp_main_thread+0x2200>
    a9fc:	f90017e0 	str	x0, [sp, #40]
    aa00:	97ffe66d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    aa04:	f94017e0 	ldr	x0, [sp, #40]
    aa08:	17fffdca 	b	a130 <fwp_main_thread+0x1950>
    aa0c:	d10004e1 	sub	x1, x7, #0x1
    aa10:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    aa14:	eb00003f 	cmp	x1, x0
    aa18:	54000748 	b.hi	ab00 <fwp_main_thread+0x2320>  // b.pmore
    aa1c:	d00002a1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    aa20:	d2800000 	mov	x0, #0x0                   	// #0
    aa24:	91114021 	add	x1, x1, #0x450
    aa28:	d2800303 	mov	x3, #0x18                  	// #24
    aa2c:	14000004 	b	aa3c <fwp_main_thread+0x225c>
    aa30:	91000400 	add	x0, x0, #0x1
    aa34:	f140041f 	cmp	x0, #0x1, lsl #12
    aa38:	54000540 	b.eq	aae0 <fwp_main_thread+0x2300>  // b.none
    aa3c:	9b037c02 	mul	x2, x0, x3
    aa40:	8b010045 	add	x5, x2, x1
    aa44:	f90027e5 	str	x5, [sp, #72]
    aa48:	f8626822 	ldr	x2, [x1, x2]
    aa4c:	b5ffff22 	cbnz	x2, aa30 <fwp_main_thread+0x2250>
    aa50:	aa0703e0 	mov	x0, x7
    aa54:	d2800101 	mov	x1, #0x8                   	// #8
    aa58:	a905a3e7 	stp	x7, x8, [sp, #88]
    aa5c:	f90037e4 	str	x4, [sp, #104]
    aa60:	97ffdf88 	bl	2880 <calloc@plt>
    aa64:	a945a3e7 	ldp	x7, x8, [sp, #88]
    aa68:	aa0003e6 	mov	x6, x0
    aa6c:	f94037e4 	ldr	x4, [sp, #104]
    aa70:	b4ffae60 	cbz	x0, a03c <fwp_main_thread+0x185c>
    aa74:	aa0003e1 	mov	x1, x0
    aa78:	d37df0e2 	lsl	x2, x7, #3
    aa7c:	f94027e0 	ldr	x0, [sp, #72]
    aa80:	52800063 	mov	w3, #0x3                   	// #3
    aa84:	f90027e6 	str	x6, [sp, #72]
    aa88:	a90593e7 	stp	x7, x4, [sp, #88]
    aa8c:	f90037e8 	str	x8, [sp, #104]
    aa90:	97ffe140 	bl	2f90 <ad_raw_record>
    aa94:	f94027e6 	ldr	x6, [sp, #72]
    aa98:	a94593e7 	ldp	x7, x4, [sp, #88]
    aa9c:	f94037e8 	ldr	x8, [sp, #104]
    aaa0:	17fffd2c 	b	9f50 <fwp_main_thread+0x1770>
    aaa4:	72003c3f 	tst	w1, #0xffff
    aaa8:	54ffb481 	b.ne	a138 <fwp_main_thread+0x1958>  // b.any
    aaac:	17fffd9e 	b	a124 <fwp_main_thread+0x1944>
    aab0:	f9400041 	ldr	x1, [x2]
    aab4:	f9400420 	ldr	x0, [x1, #8]
    aab8:	d1000400 	sub	x0, x0, #0x1
    aabc:	f9000420 	str	x0, [x1, #8]
    aac0:	f103f81f 	cmp	x0, #0xfe
    aac4:	54ff83e1 	b.ne	9b40 <fwp_main_thread+0x1360>  // b.any
    aac8:	39400380 	ldrb	w0, [x28]
    aacc:	7103fc1f 	cmp	w0, #0xff
    aad0:	540000e0 	b.eq	aaec <fwp_main_thread+0x230c>  // b.none
    aad4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aad8:	39000380 	strb	w0, [x28]
    aadc:	17fffc19 	b	9b40 <fwp_main_thread+0x1360>
    aae0:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    aae4:	9115a000 	add	x0, x0, #0x568
    aae8:	97ffe226 	bl	3380 <ad_raw_fail>
    aaec:	aa1c03e0 	mov	x0, x28
    aaf0:	f9001be4 	str	x4, [sp, #48]
    aaf4:	97ffe630 	bl	43b4 <fwp_rc_forget_slot.part.0>
    aaf8:	f9401be4 	ldr	x4, [sp, #48]
    aafc:	17fffff6 	b	aad4 <fwp_main_thread+0x22f4>
    ab00:	b0000000 	adrp	x0, b000 <__modti3+0xc0>
    ab04:	9129e000 	add	x0, x0, #0xa78
    ab08:	97ffe21e 	bl	3380 <ad_raw_fail>
    ab0c:	72003c1f 	tst	w0, #0xffff
    ab10:	54ffc680 	b.eq	a3e0 <fwp_main_thread+0x1c00>  // b.none
    ab14:	aa1b03fc 	mov	x28, x27
    ab18:	d2800005 	mov	x5, #0x0                   	// #0
    ab1c:	b40001fc 	cbz	x28, ab58 <fwp_main_thread+0x2378>
    ab20:	f9400b9c 	ldr	x28, [x28, #16]
    ab24:	910004a5 	add	x5, x5, #0x1
    ab28:	17fffffd 	b	ab1c <fwp_main_thread+0x233c>
    ab2c:	72003c1f 	tst	w0, #0xffff
    ab30:	54ffce41 	b.ne	a4f8 <fwp_main_thread+0x1d18>  // b.any
    ab34:	17fffe6e 	b	a4ec <fwp_main_thread+0x1d0c>
    ab38:	a9048fe0 	stp	x0, x3, [sp, #72]
    ab3c:	97ffe61e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ab40:	a9448fe0 	ldp	x0, x3, [sp, #72]
    ab44:	17fffe9b 	b	a5b0 <fwp_main_thread+0x1dd0>
    ab48:	72003c3f 	tst	w1, #0xffff
    ab4c:	54ffd2c0 	b.eq	a5a4 <fwp_main_thread+0x1dc4>  // b.none
    ab50:	d10006f7 	sub	x23, x23, #0x1
    ab54:	17fffe72 	b	a51c <fwp_main_thread+0x1d3c>
    ab58:	a9030be3 	stp	x3, x2, [sp, #48]
    ab5c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    ab60:	eb0000bf 	cmp	x5, x0
    ab64:	54ff4bc8 	b.hi	94dc <fwp_main_thread+0xcfc>  // b.pmore
    ab68:	910004a0 	add	x0, x5, #0x1
    ab6c:	52800041 	mov	w1, #0x2                   	// #2
    ab70:	f90017e5 	str	x5, [sp, #40]
    ab74:	d37df000 	lsl	x0, x0, #3
    ab78:	97ffe966 	bl	5110 <fwp_heap_alloc>
    ab7c:	a9428fe5 	ldp	x5, x3, [sp, #40]
    ab80:	aa1b03e1 	mov	x1, x27
    ab84:	f9401fe2 	ldr	x2, [sp, #56]
    ab88:	aa0003e4 	mov	x4, x0
    ab8c:	b40000c1 	cbz	x1, aba4 <fwp_main_thread+0x23c4>
    ab90:	f9400420 	ldr	x0, [x1, #8]
    ab94:	f83c7880 	str	x0, [x4, x28, lsl #3]
    ab98:	9100079c 	add	x28, x28, #0x1
    ab9c:	f9400821 	ldr	x1, [x1, #16]
    aba0:	17fffffb 	b	ab8c <fwp_main_thread+0x23ac>
    aba4:	52800006 	mov	w6, #0x0                   	// #0
    aba8:	17fffe12 	b	a3f0 <fwp_main_thread+0x1c10>
    abac:	97ffdfb5 	bl	2a80 <fwp_trap_overflow.constprop.0>
    abb0:	f90123fb 	str	x27, [sp, #576]
    abb4:	f90127fc 	str	x28, [sp, #584]
    abb8:	97ffdf4e 	bl	28f0 <abort@plt>
    abbc:	d503201f 	nop

000000000000abc0 <__divti3>:
    abc0:	d503245f 	bti	c
    abc4:	d2800004 	mov	x4, #0x0                   	// #0
    abc8:	b7f80721 	tbnz	x1, #63, acac <__divti3+0xec>
    abcc:	b6f80083 	tbz	x3, #63, abdc <__divti3+0x1c>
    abd0:	eb0203e2 	negs	x2, x2
    abd4:	aa2403e4 	mvn	x4, x4
    abd8:	da0303e3 	ngc	x3, x3
    abdc:	aa0203e6 	mov	x6, x2
    abe0:	aa0003e7 	mov	x7, x0
    abe4:	aa0103e5 	mov	x5, x1
    abe8:	b5000583 	cbnz	x3, ac98 <__divti3+0xd8>
    abec:	eb01005f 	cmp	x2, x1
    abf0:	54000e69 	b.ls	adbc <__divti3+0x1fc>  // b.plast
    abf4:	dac01040 	clz	x0, x2
    abf8:	b40000e0 	cbz	x0, ac14 <__divti3+0x54>
    abfc:	4b0003e1 	neg	w1, w0
    ac00:	9ac020a5 	lsl	x5, x5, x0
    ac04:	9ac02046 	lsl	x6, x2, x0
    ac08:	9ac124e1 	lsr	x1, x7, x1
    ac0c:	aa050025 	orr	x5, x1, x5
    ac10:	9ac020e7 	lsl	x7, x7, x0
    ac14:	d360fcc8 	lsr	x8, x6, #32
    ac18:	92407cc2 	and	x2, x6, #0xffffffff
    ac1c:	9ac808a3 	udiv	x3, x5, x8
    ac20:	9b089465 	msub	x5, x3, x8, x5
    ac24:	aa0303e0 	mov	x0, x3
    ac28:	9b037c41 	mul	x1, x2, x3
    ac2c:	93c780a5 	extr	x5, x5, x7, #32
    ac30:	eb05003f 	cmp	x1, x5
    ac34:	540000a9 	b.ls	ac48 <__divti3+0x88>  // b.plast
    ac38:	ab0500c5 	adds	x5, x6, x5
    ac3c:	d1000460 	sub	x0, x3, #0x1
    ac40:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ac44:	540015a8 	b.hi	aef8 <__divti3+0x338>  // b.pmore
    ac48:	cb0100a5 	sub	x5, x5, x1
    ac4c:	9ac808a3 	udiv	x3, x5, x8
    ac50:	9b089465 	msub	x5, x3, x8, x5
    ac54:	aa0303e1 	mov	x1, x3
    ac58:	9b037c42 	mul	x2, x2, x3
    ac5c:	aa0703e3 	mov	x3, x7
    ac60:	b3607ca3 	bfi	x3, x5, #32, #32
    ac64:	eb03005f 	cmp	x2, x3
    ac68:	540000c9 	b.ls	ac80 <__divti3+0xc0>  // b.plast
    ac6c:	ab0300c3 	adds	x3, x6, x3
    ac70:	d1000425 	sub	x5, x1, #0x1
    ac74:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ac78:	d1000821 	sub	x1, x1, #0x2
    ac7c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ac80:	aa008020 	orr	x0, x1, x0, lsl #32
    ac84:	d2800001 	mov	x1, #0x0                   	// #0
    ac88:	b4000064 	cbz	x4, ac94 <__divti3+0xd4>
    ac8c:	eb0003e0 	negs	x0, x0
    ac90:	da0103e1 	ngc	x1, x1
    ac94:	d65f03c0 	ret
    ac98:	eb01007f 	cmp	x3, x1
    ac9c:	54000109 	b.ls	acbc <__divti3+0xfc>  // b.plast
    aca0:	d2800001 	mov	x1, #0x0                   	// #0
    aca4:	d2800000 	mov	x0, #0x0                   	// #0
    aca8:	17fffff8 	b	ac88 <__divti3+0xc8>
    acac:	eb0003e0 	negs	x0, x0
    acb0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    acb4:	da0103e1 	ngc	x1, x1
    acb8:	17ffffc5 	b	abcc <__divti3+0xc>
    acbc:	dac01067 	clz	x7, x3
    acc0:	b40010e7 	cbz	x7, aedc <__divti3+0x31c>
    acc4:	d2800805 	mov	x5, #0x40                  	// #64
    acc8:	cb0700a5 	sub	x5, x5, x7
    accc:	9ac72063 	lsl	x3, x3, x7
    acd0:	9ac52448 	lsr	x8, x2, x5
    acd4:	aa030108 	orr	x8, x8, x3
    acd8:	9ac52426 	lsr	x6, x1, x5
    acdc:	92407d0a 	and	x10, x8, #0xffffffff
    ace0:	d360fd09 	lsr	x9, x8, #32
    ace4:	9ac52403 	lsr	x3, x0, x5
    ace8:	9ac72021 	lsl	x1, x1, x7
    acec:	aa010063 	orr	x3, x3, x1
    acf0:	9ac72042 	lsl	x2, x2, x7
    acf4:	9ac908cb 	udiv	x11, x6, x9
    acf8:	9b099965 	msub	x5, x11, x9, x6
    acfc:	aa0b03e1 	mov	x1, x11
    ad00:	9b0b7d46 	mul	x6, x10, x11
    ad04:	93c380a5 	extr	x5, x5, x3, #32
    ad08:	eb0500df 	cmp	x6, x5
    ad0c:	540000a9 	b.ls	ad20 <__divti3+0x160>  // b.plast
    ad10:	ab050105 	adds	x5, x8, x5
    ad14:	d1000561 	sub	x1, x11, #0x1
    ad18:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ad1c:	54000f48 	b.hi	af04 <__divti3+0x344>  // b.pmore
    ad20:	cb0600a6 	sub	x6, x5, x6
    ad24:	9ac908cb 	udiv	x11, x6, x9
    ad28:	9b099969 	msub	x9, x11, x9, x6
    ad2c:	aa0b03e5 	mov	x5, x11
    ad30:	9b0b7d4a 	mul	x10, x10, x11
    ad34:	b3607d23 	bfi	x3, x9, #32, #32
    ad38:	eb03015f 	cmp	x10, x3
    ad3c:	540000a9 	b.ls	ad50 <__divti3+0x190>  // b.plast
    ad40:	ab030103 	adds	x3, x8, x3
    ad44:	d1000565 	sub	x5, x11, #0x1
    ad48:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ad4c:	54000e28 	b.hi	af10 <__divti3+0x350>  // b.pmore
    ad50:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ad54:	92407c48 	and	x8, x2, #0xffffffff
    ad58:	2a0503e5 	mov	w5, w5
    ad5c:	d360fc42 	lsr	x2, x2, #32
    ad60:	d360fc26 	lsr	x6, x1, #32
    ad64:	cb0a0063 	sub	x3, x3, x10
    ad68:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ad6c:	9b087caa 	mul	x10, x5, x8
    ad70:	9b087cc8 	mul	x8, x6, x8
    ad74:	9b0220a5 	madd	x5, x5, x2, x8
    ad78:	9b027cc6 	mul	x6, x6, x2
    ad7c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ad80:	8b0900c5 	add	x5, x6, x9
    ad84:	eb02011f 	cmp	x8, x2
    ad88:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ad8c:	8b4280c6 	add	x6, x6, x2, lsr #32
    ad90:	eb06007f 	cmp	x3, x6
    ad94:	540000e3 	b.cc	adb0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ad98:	92407d4a 	and	x10, x10, #0xffffffff
    ad9c:	9ac72000 	lsl	x0, x0, x7
    ada0:	8b028142 	add	x2, x10, x2, lsl #32
    ada4:	eb02001f 	cmp	x0, x2
    ada8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    adac:	54000a01 	b.ne	aeec <__divti3+0x32c>  // b.any
    adb0:	d1000420 	sub	x0, x1, #0x1
    adb4:	d2800001 	mov	x1, #0x0                   	// #0
    adb8:	17ffffb4 	b	ac88 <__divti3+0xc8>
    adbc:	b5000062 	cbnz	x2, adc8 <__divti3+0x208>
    adc0:	d2800022 	mov	x2, #0x1                   	// #1
    adc4:	9ac30846 	udiv	x6, x2, x3
    adc8:	dac010c8 	clz	x8, x6
    adcc:	b5000408 	cbnz	x8, ae4c <__divti3+0x28c>
    add0:	d360fcc9 	lsr	x9, x6, #32
    add4:	92407cc5 	and	x5, x6, #0xffffffff
    add8:	cb060023 	sub	x3, x1, x6
    addc:	d2800021 	mov	x1, #0x1                   	// #1
    ade0:	9ac90868 	udiv	x8, x3, x9
    ade4:	9b098d03 	msub	x3, x8, x9, x3
    ade8:	aa0803e0 	mov	x0, x8
    adec:	9b057d02 	mul	x2, x8, x5
    adf0:	93c78063 	extr	x3, x3, x7, #32
    adf4:	eb03005f 	cmp	x2, x3
    adf8:	540000a9 	b.ls	ae0c <__divti3+0x24c>  // b.plast
    adfc:	ab0300c3 	adds	x3, x6, x3
    ae00:	d1000500 	sub	x0, x8, #0x1
    ae04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ae08:	54000968 	b.hi	af34 <__divti3+0x374>  // b.pmore
    ae0c:	cb020063 	sub	x3, x3, x2
    ae10:	9ac90862 	udiv	x2, x3, x9
    ae14:	aa0203e8 	mov	x8, x2
    ae18:	9b098c42 	msub	x2, x2, x9, x3
    ae1c:	aa0703e3 	mov	x3, x7
    ae20:	9b057d05 	mul	x5, x8, x5
    ae24:	b3607c43 	bfi	x3, x2, #32, #32
    ae28:	eb0300bf 	cmp	x5, x3
    ae2c:	540000c9 	b.ls	ae44 <__divti3+0x284>  // b.plast
    ae30:	ab0300c2 	adds	x2, x6, x3
    ae34:	d1000503 	sub	x3, x8, #0x1
    ae38:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ae3c:	d1000908 	sub	x8, x8, #0x2
    ae40:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ae44:	aa008100 	orr	x0, x8, x0, lsl #32
    ae48:	17ffff90 	b	ac88 <__divti3+0xc8>
    ae4c:	9ac820c6 	lsl	x6, x6, x8
    ae50:	d2800803 	mov	x3, #0x40                  	// #64
    ae54:	cb080063 	sub	x3, x3, x8
    ae58:	d360fcc9 	lsr	x9, x6, #32
    ae5c:	9ac82027 	lsl	x7, x1, x8
    ae60:	92407cc5 	and	x5, x6, #0xffffffff
    ae64:	9ac32422 	lsr	x2, x1, x3
    ae68:	9ac32403 	lsr	x3, x0, x3
    ae6c:	aa070063 	orr	x3, x3, x7
    ae70:	9ac9084a 	udiv	x10, x2, x9
    ae74:	9ac82007 	lsl	x7, x0, x8
    ae78:	9b098940 	msub	x0, x10, x9, x2
    ae7c:	aa0a03e1 	mov	x1, x10
    ae80:	9b0a7ca2 	mul	x2, x5, x10
    ae84:	93c38000 	extr	x0, x0, x3, #32
    ae88:	eb00005f 	cmp	x2, x0
    ae8c:	540000a9 	b.ls	aea0 <__divti3+0x2e0>  // b.plast
    ae90:	ab0000c0 	adds	x0, x6, x0
    ae94:	d1000541 	sub	x1, x10, #0x1
    ae98:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    ae9c:	54000468 	b.hi	af28 <__divti3+0x368>  // b.pmore
    aea0:	cb020000 	sub	x0, x0, x2
    aea4:	9ac9080a 	udiv	x10, x0, x9
    aea8:	9b098140 	msub	x0, x10, x9, x0
    aeac:	aa0a03e2 	mov	x2, x10
    aeb0:	9b0a7ca8 	mul	x8, x5, x10
    aeb4:	b3607c03 	bfi	x3, x0, #32, #32
    aeb8:	eb03011f 	cmp	x8, x3
    aebc:	540000a9 	b.ls	aed0 <__divti3+0x310>  // b.plast
    aec0:	ab0300c3 	adds	x3, x6, x3
    aec4:	d1000542 	sub	x2, x10, #0x1
    aec8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    aecc:	54000288 	b.hi	af1c <__divti3+0x35c>  // b.pmore
    aed0:	cb080063 	sub	x3, x3, x8
    aed4:	aa018041 	orr	x1, x2, x1, lsl #32
    aed8:	17ffffc2 	b	ade0 <__divti3+0x220>
    aedc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    aee0:	d2800001 	mov	x1, #0x0                   	// #0
    aee4:	9a9f87e0 	cset	x0, ls	// ls = plast
    aee8:	17ffff68 	b	ac88 <__divti3+0xc8>
    aeec:	aa0103e0 	mov	x0, x1
    aef0:	d2800001 	mov	x1, #0x0                   	// #0
    aef4:	17ffff65 	b	ac88 <__divti3+0xc8>
    aef8:	d1000860 	sub	x0, x3, #0x2
    aefc:	8b0600a5 	add	x5, x5, x6
    af00:	17ffff52 	b	ac48 <__divti3+0x88>
    af04:	d1000961 	sub	x1, x11, #0x2
    af08:	8b0800a5 	add	x5, x5, x8
    af0c:	17ffff85 	b	ad20 <__divti3+0x160>
    af10:	d1000965 	sub	x5, x11, #0x2
    af14:	8b080063 	add	x3, x3, x8
    af18:	17ffff8e 	b	ad50 <__divti3+0x190>
    af1c:	d1000942 	sub	x2, x10, #0x2
    af20:	8b060063 	add	x3, x3, x6
    af24:	17ffffeb 	b	aed0 <__divti3+0x310>
    af28:	d1000941 	sub	x1, x10, #0x2
    af2c:	8b060000 	add	x0, x0, x6
    af30:	17ffffdc 	b	aea0 <__divti3+0x2e0>
    af34:	d1000900 	sub	x0, x8, #0x2
    af38:	8b060063 	add	x3, x3, x6
    af3c:	17ffffb4 	b	ae0c <__divti3+0x24c>

000000000000af40 <__modti3>:
    af40:	d503245f 	bti	c
    af44:	d2800004 	mov	x4, #0x0                   	// #0
    af48:	b6f80081 	tbz	x1, #63, af58 <__modti3+0x18>
    af4c:	eb0003e0 	negs	x0, x0
    af50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af54:	da0103e1 	ngc	x1, x1
    af58:	f100007f 	cmp	x3, #0x0
    af5c:	5400128b 	b.lt	b1ac <__modti3+0x26c>  // b.tstop
    af60:	aa0003e7 	mov	x7, x0
    af64:	aa0103e6 	mov	x6, x1
    af68:	540004e1 	b.ne	b004 <__modti3+0xc4>  // b.any
    af6c:	eb02003f 	cmp	x1, x2
    af70:	54000dc2 	b.cs	b128 <__modti3+0x1e8>  // b.hs, b.nlast
    af74:	dac01043 	clz	x3, x2
    af78:	aa0303e5 	mov	x5, x3
    af7c:	b40000e3 	cbz	x3, af98 <__modti3+0x58>
    af80:	4b0303e6 	neg	w6, w3
    af84:	9ac32021 	lsl	x1, x1, x3
    af88:	9ac32042 	lsl	x2, x2, x3
    af8c:	9ac62406 	lsr	x6, x0, x6
    af90:	aa0100c6 	orr	x6, x6, x1
    af94:	9ac32007 	lsl	x7, x0, x3
    af98:	d360fc40 	lsr	x0, x2, #32
    af9c:	92407c43 	and	x3, x2, #0xffffffff
    afa0:	9ac008c1 	udiv	x1, x6, x0
    afa4:	9b009826 	msub	x6, x1, x0, x6
    afa8:	9b017c61 	mul	x1, x3, x1
    afac:	93c780c6 	extr	x6, x6, x7, #32
    afb0:	eb06003f 	cmp	x1, x6
    afb4:	540000a9 	b.ls	afc8 <__modti3+0x88>  // b.plast
    afb8:	ab060046 	adds	x6, x2, x6
    afbc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    afc0:	8b0200c8 	add	x8, x6, x2
    afc4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    afc8:	cb0100c6 	sub	x6, x6, x1
    afcc:	9ac008c8 	udiv	x8, x6, x0
    afd0:	9b009901 	msub	x1, x8, x0, x6
    afd4:	aa0703e0 	mov	x0, x7
    afd8:	9b087c63 	mul	x3, x3, x8
    afdc:	b3607c20 	bfi	x0, x1, #32, #32
    afe0:	eb00007f 	cmp	x3, x0
    afe4:	54001088 	b.hi	b1f4 <__modti3+0x2b4>  // b.pmore
    afe8:	cb030000 	sub	x0, x0, x3
    afec:	9ac52400 	lsr	x0, x0, x5
    aff0:	d2800001 	mov	x1, #0x0                   	// #0
    aff4:	b4000064 	cbz	x4, b000 <__modti3+0xc0>
    aff8:	eb0003e0 	negs	x0, x0
    affc:	da0103e1 	ngc	x1, x1
    b000:	d65f03c0 	ret
    b004:	dac01066 	clz	x6, x3
    b008:	eb03003f 	cmp	x1, x3
    b00c:	54ffff43 	b.cc	aff4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b010:	93407cc5 	sxtw	x5, w6
    b014:	d2800808 	mov	x8, #0x40                  	// #64
    b018:	cb050108 	sub	x8, x8, x5
    b01c:	9ac62063 	lsl	x3, x3, x6
    b020:	9ac62025 	lsl	x5, x1, x6
    b024:	9ac82447 	lsr	x7, x2, x8
    b028:	aa0300e7 	orr	x7, x7, x3
    b02c:	9ac82423 	lsr	x3, x1, x8
    b030:	92407cec 	and	x12, x7, #0xffffffff
    b034:	d360fcea 	lsr	x10, x7, #32
    b038:	9ac82401 	lsr	x1, x0, x8
    b03c:	aa050021 	orr	x1, x1, x5
    b040:	9ac62042 	lsl	x2, x2, x6
    b044:	9ac62000 	lsl	x0, x0, x6
    b048:	9aca086b 	udiv	x11, x3, x10
    b04c:	9b0a8d63 	msub	x3, x11, x10, x3
    b050:	aa0b03e5 	mov	x5, x11
    b054:	9b0b7d89 	mul	x9, x12, x11
    b058:	93c18063 	extr	x3, x3, x1, #32
    b05c:	eb03013f 	cmp	x9, x3
    b060:	540000a9 	b.ls	b074 <__modti3+0x134>  // b.plast
    b064:	ab0300e3 	adds	x3, x7, x3
    b068:	d1000565 	sub	x5, x11, #0x1
    b06c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b070:	54001168 	b.hi	b29c <__modti3+0x35c>  // b.pmore
    b074:	cb090063 	sub	x3, x3, x9
    b078:	9aca086b 	udiv	x11, x3, x10
    b07c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b080:	aa0b03e9 	mov	x9, x11
    b084:	9b0b7d8c 	mul	x12, x12, x11
    b088:	b3607d41 	bfi	x1, x10, #32, #32
    b08c:	eb01019f 	cmp	x12, x1
    b090:	540000a9 	b.ls	b0a4 <__modti3+0x164>  // b.plast
    b094:	ab0100e1 	adds	x1, x7, x1
    b098:	d1000569 	sub	x9, x11, #0x1
    b09c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b0a0:	54000f88 	b.hi	b290 <__modti3+0x350>  // b.pmore
    b0a4:	aa058123 	orr	x3, x9, x5, lsl #32
    b0a8:	92407c4b 	and	x11, x2, #0xffffffff
    b0ac:	2a0903e9 	mov	w9, w9
    b0b0:	d360fc4a 	lsr	x10, x2, #32
    b0b4:	d360fc63 	lsr	x3, x3, #32
    b0b8:	cb0c0021 	sub	x1, x1, x12
    b0bc:	aa0a03ec 	mov	x12, x10
    b0c0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b0c4:	9b0b7d25 	mul	x5, x9, x11
    b0c8:	9b0b7c6b 	mul	x11, x3, x11
    b0cc:	9b0a2d29 	madd	x9, x9, x10, x11
    b0d0:	92407caa 	and	x10, x5, #0xffffffff
    b0d4:	9b0c7c63 	mul	x3, x3, x12
    b0d8:	8b458125 	add	x5, x9, x5, lsr #32
    b0dc:	8b0d0069 	add	x9, x3, x13
    b0e0:	eb05017f 	cmp	x11, x5
    b0e4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b0e8:	8b058149 	add	x9, x10, x5, lsl #32
    b0ec:	8b458063 	add	x3, x3, x5, lsr #32
    b0f0:	eb03003f 	cmp	x1, x3
    b0f4:	54000063 	b.cc	b100 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b0f8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b0fc:	54000082 	b.cs	b10c <__modti3+0x1cc>  // b.hs, b.nlast
    b100:	eb020129 	subs	x9, x9, x2
    b104:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b108:	cb070063 	sub	x3, x3, x7
    b10c:	eb090000 	subs	x0, x0, x9
    b110:	da030021 	sbc	x1, x1, x3
    b114:	9ac62400 	lsr	x0, x0, x6
    b118:	9ac82028 	lsl	x8, x1, x8
    b11c:	aa000100 	orr	x0, x8, x0
    b120:	9ac62421 	lsr	x1, x1, x6
    b124:	17ffffb4 	b	aff4 <__modti3+0xb4>
    b128:	b5000062 	cbnz	x2, b134 <__modti3+0x1f4>
    b12c:	d2800023 	mov	x3, #0x1                   	// #1
    b130:	9ac20862 	udiv	x2, x3, x2
    b134:	dac01048 	clz	x8, x2
    b138:	aa0803e5 	mov	x5, x8
    b13c:	b5000668 	cbnz	x8, b208 <__modti3+0x2c8>
    b140:	cb020020 	sub	x0, x1, x2
    b144:	d360fc49 	lsr	x9, x2, #32
    b148:	92407c4a 	and	x10, x2, #0xffffffff
    b14c:	9ac90801 	udiv	x1, x0, x9
    b150:	9b098020 	msub	x0, x1, x9, x0
    b154:	9b0a7c21 	mul	x1, x1, x10
    b158:	93c78000 	extr	x0, x0, x7, #32
    b15c:	eb00003f 	cmp	x1, x0
    b160:	540000a9 	b.ls	b174 <__modti3+0x234>  // b.plast
    b164:	ab000040 	adds	x0, x2, x0
    b168:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b16c:	8b020003 	add	x3, x0, x2
    b170:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b174:	cb010001 	sub	x1, x0, x1
    b178:	9ac90820 	udiv	x0, x1, x9
    b17c:	9b098403 	msub	x3, x0, x9, x1
    b180:	aa0703e1 	mov	x1, x7
    b184:	9b0a7c00 	mul	x0, x0, x10
    b188:	b3607c61 	bfi	x1, x3, #32, #32
    b18c:	eb01001f 	cmp	x0, x1
    b190:	540000a9 	b.ls	b1a4 <__modti3+0x264>  // b.plast
    b194:	ab010041 	adds	x1, x2, x1
    b198:	8b020022 	add	x2, x1, x2
    b19c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b1a0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b1a4:	cb000020 	sub	x0, x1, x0
    b1a8:	17ffff91 	b	afec <__modti3+0xac>
    b1ac:	eb0203e5 	negs	x5, x2
    b1b0:	aa0003e7 	mov	x7, x0
    b1b4:	da0303e8 	ngc	x8, x3
    b1b8:	aa0503e2 	mov	x2, x5
    b1bc:	aa0803e3 	mov	x3, x8
    b1c0:	aa0103e6 	mov	x6, x1
    b1c4:	b4ffed48 	cbz	x8, af6c <__modti3+0x2c>
    b1c8:	eb01011f 	cmp	x8, x1
    b1cc:	54fff148 	b.hi	aff4 <__modti3+0xb4>  // b.pmore
    b1d0:	dac01109 	clz	x9, x8
    b1d4:	2a0903e6 	mov	w6, w9
    b1d8:	b5fff1c9 	cbnz	x9, b010 <__modti3+0xd0>
    b1dc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b1e0:	54000068 	b.hi	b1ec <__modti3+0x2ac>  // b.pmore
    b1e4:	eb050007 	subs	x7, x0, x5
    b1e8:	da080021 	sbc	x1, x1, x8
    b1ec:	aa0703e0 	mov	x0, x7
    b1f0:	17ffff81 	b	aff4 <__modti3+0xb4>
    b1f4:	ab000040 	adds	x0, x2, x0
    b1f8:	8b020002 	add	x2, x0, x2
    b1fc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b200:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b204:	17ffff79 	b	afe8 <__modti3+0xa8>
    b208:	9ac82042 	lsl	x2, x2, x8
    b20c:	d2800803 	mov	x3, #0x40                  	// #64
    b210:	cb080063 	sub	x3, x3, x8
    b214:	d360fc49 	lsr	x9, x2, #32
    b218:	9ac82027 	lsl	x7, x1, x8
    b21c:	92407c4a 	and	x10, x2, #0xffffffff
    b220:	9ac32426 	lsr	x6, x1, x3
    b224:	9ac32403 	lsr	x3, x0, x3
    b228:	aa070063 	orr	x3, x3, x7
    b22c:	9ac908c1 	udiv	x1, x6, x9
    b230:	9ac82007 	lsl	x7, x0, x8
    b234:	9b099820 	msub	x0, x1, x9, x6
    b238:	9b017d41 	mul	x1, x10, x1
    b23c:	93c38000 	extr	x0, x0, x3, #32
    b240:	eb00003f 	cmp	x1, x0
    b244:	540000a9 	b.ls	b258 <__modti3+0x318>  // b.plast
    b248:	ab000040 	adds	x0, x2, x0
    b24c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b250:	8b020006 	add	x6, x0, x2
    b254:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b258:	cb010000 	sub	x0, x0, x1
    b25c:	9ac90801 	udiv	x1, x0, x9
    b260:	9b098026 	msub	x6, x1, x9, x0
    b264:	aa0303e0 	mov	x0, x3
    b268:	9b017d41 	mul	x1, x10, x1
    b26c:	b3607cc0 	bfi	x0, x6, #32, #32
    b270:	eb00003f 	cmp	x1, x0
    b274:	540000a9 	b.ls	b288 <__modti3+0x348>  // b.plast
    b278:	ab000040 	adds	x0, x2, x0
    b27c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b280:	8b020003 	add	x3, x0, x2
    b284:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b288:	cb010000 	sub	x0, x0, x1
    b28c:	17ffffb0 	b	b14c <__modti3+0x20c>
    b290:	d1000969 	sub	x9, x11, #0x2
    b294:	8b070021 	add	x1, x1, x7
    b298:	17ffff83 	b	b0a4 <__modti3+0x164>
    b29c:	d1000965 	sub	x5, x11, #0x2
    b2a0:	8b070063 	add	x3, x3, x7
    b2a4:	17ffff74 	b	b074 <__modti3+0x134>
    b2a8:	d503201f 	nop
    b2ac:	d503201f 	nop

000000000000b2b0 <atexit>:
    b2b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b2b4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b2b8:	d2800001 	mov	x1, #0x0                   	// #0
    b2bc:	910003fd 	mov	x29, sp
    b2c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b2c4:	f9400442 	ldr	x2, [x2, #8]
    b2c8:	17ffdd36 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b2cc <_fini>:
    b2cc:	d503201f 	nop
    b2d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b2d4:	910003fd 	mov	x29, sp
    b2d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b2dc:	d65f03c0 	ret
