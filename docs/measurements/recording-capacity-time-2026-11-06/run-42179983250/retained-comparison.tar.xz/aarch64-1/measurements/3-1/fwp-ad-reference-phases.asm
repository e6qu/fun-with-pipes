
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	b0000045 	adrp	x5, b000 <_IO_stdin_used+0x150>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	9108c0a5 	add	x5, x5, #0x230
    2b20:	b0000044 	adrp	x4, b000 <_IO_stdin_used+0x150>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	9108e084 	add	x4, x4, #0x238
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	94000590 	bl	4190 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b7c:	f947ee94 	ldr	x20, [x20, #4056]
    2b80:	f9400282 	ldr	x2, [x20]
    2b84:	f90043f5 	str	x21, [sp, #128]
    2b88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b8c:	9101c2a1 	add	x1, x21, #0x70
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11030>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9006420 	str	x0, [x1, #200]
    2bac:	94000799 	bl	4a10 <fwp_now_ns>
    2bb0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2bb4:	91152000 	add	x0, x0, #0x548
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f3 	mov	x19, x0
    2bc8:	350008c1 	cbnz	w1, 2ce0 <main+0x180>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	350007e0 	cbnz	w0, 2cd4 <main+0x174>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b5000620 	cbnz	x0, 2cc8 <main+0x168>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f3 	add	x19, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1303e0 	mov	x0, x19
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007a0 	cbnz	w0, 2d28 <main+0x1c8>
    2c38:	aa1303e0 	mov	x0, x19
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000660 	cbnz	w0, 2d10 <main+0x1b0>
    2c48:	aa1303e1 	mov	x1, x19
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xb1c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91134042 	add	x2, x2, #0x4d0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	2a0103f3 	mov	w19, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	35000613 	cbnz	w19, 2d34 <main+0x1d4>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c2b5 	add	x21, x21, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435aa0 	ldr	w0, [x21, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	54000481 	b.ne	2d40 <main+0x1e0>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2ccc:	9115e000 	add	x0, x0, #0x578
    2cd0:	94000530 	bl	4190 <fwp_trap>
    2cd4:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2cd8:	91156000 	add	x0, x0, #0x558
    2cdc:	9400052d 	bl	4190 <fwp_trap>
    2ce0:	910003e1 	mov	x1, sp
    2ce4:	52800142 	mov	w2, #0xa                   	// #10
    2ce8:	97ffff46 	bl	2a00 <strtoull@plt>
    2cec:	f94003e0 	ldr	x0, [sp]
    2cf0:	39400000 	ldrb	w0, [x0]
    2cf4:	35fff6c0 	cbnz	w0, 2bcc <main+0x6c>
    2cf8:	39400260 	ldrb	w0, [x19]
    2cfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2d00:	5100ac00 	sub	w0, w0, #0x2b
    2d04:	6a01001f 	tst	w0, w1
    2d08:	54fff620 	b.eq	2bcc <main+0x6c>  // b.none
    2d0c:	17ffffbf 	b	2c08 <main+0xa8>
    2d10:	aa1303e0 	mov	x0, x19
    2d14:	97fffeeb 	bl	28c0 <pthread_attr_destroy@plt>
    2d18:	35000160 	cbnz	w0, 2d44 <main+0x1e4>
    2d1c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2d20:	91174000 	add	x0, x0, #0x5d0
    2d24:	9400051b 	bl	4190 <fwp_trap>
    2d28:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2d2c:	91168000 	add	x0, x0, #0x5a0
    2d30:	94000518 	bl	4190 <fwp_trap>
    2d34:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    2d38:	9117e000 	add	x0, x0, #0x5f8
    2d3c:	94000515 	bl	4190 <fwp_trap>
    2d40:	97fffef4 	bl	2910 <__stack_chk_fail@plt>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x150>
    2f34:	91320021 	add	x1, x1, #0xc80
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    30d0:	913ae000 	add	x0, x0, #0xeb8
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x150>
    3198:	91318021 	add	x1, x1, #0xc60
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    31d0:	913b4000 	add	x0, x0, #0xed0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1b30>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x1b30>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x150>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	913c6042 	add	x2, x2, #0xf18
    3260:	913dc2d6 	add	x22, x22, #0xf70
    3264:	91280318 	add	x24, x24, #0xa00
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x1b30>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	913da323 	add	x3, x25, #0xf68
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	913e0000 	add	x0, x0, #0xf80
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    35f0:	913ae000 	add	x0, x0, #0xeb8
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1b30>
    3830:	aa1303e0 	mov	x0, x19
    3834:	913e2021 	add	x1, x1, #0xf88
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1b30>
    3844:	aa1303e0 	mov	x0, x19
    3848:	913e4021 	add	x1, x1, #0xf90
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1b30>
    3860:	913e6021 	add	x1, x1, #0xf98
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_format_g.constprop.0>:
    3880:	d10483ff 	sub	sp, sp, #0x120
    3884:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1b30>
    3888:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    388c:	f947f442 	ldr	x2, [x2, #4072]
    3890:	913e8084 	add	x4, x4, #0xfa0
    3894:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3898:	9102c3fd 	add	x29, sp, #0xb0
    389c:	d2800803 	mov	x3, #0x40                  	// #64
    38a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    38a4:	93407c38 	sxtw	x24, w1
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	fd008be8 	str	d8, [sp, #272]
    38b0:	1e604008 	fmov	d8, d0
    38b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    38b8:	910083f4 	add	x20, sp, #0x20
    38bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38c0:	aa0003f5 	mov	x21, x0
    38c4:	a91073fb 	stp	x27, x28, [sp, #256]
    38c8:	5100071c 	sub	w28, w24, #0x1
    38cc:	2a1c03e5 	mov	w5, w28
    38d0:	f9400040 	ldr	x0, [x2]
    38d4:	f90057e0 	str	x0, [sp, #168]
    38d8:	d2800000 	mov	x0, #0x0                   	// #0
    38dc:	52800042 	mov	w2, #0x2                   	// #2
    38e0:	aa1403e0 	mov	x0, x20
    38e4:	97fffbe7 	bl	2880 <__snprintf_chk@plt>
    38e8:	52800ca1 	mov	w1, #0x65                  	// #101
    38ec:	aa1403e0 	mov	x0, x20
    38f0:	97fffc40 	bl	29f0 <strchr@plt>
    38f4:	aa0003f3 	mov	x19, x0
    38f8:	52800142 	mov	w2, #0xa                   	// #10
    38fc:	91000400 	add	x0, x0, #0x1
    3900:	d2800001 	mov	x1, #0x0                   	// #0
    3904:	97fffc2b 	bl	29b0 <strtol@plt>
    3908:	aa0003f7 	mov	x23, x0
    390c:	11001400 	add	w0, w0, #0x5
    3910:	7100541f 	cmp	w0, #0x15
    3914:	54000d68 	b.hi	3ac0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3918:	4b170385 	sub	w5, w28, w23
    391c:	710000bf 	cmp	w5, #0x0
    3920:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3924:	54000b80 	b.eq	3a94 <fwp_format_g.constprop.0+0x214>  // b.none
    3928:	394083e0 	ldrb	w0, [sp, #32]
    392c:	cb180273 	sub	x19, x19, x24
    3930:	91000673 	add	x19, x19, #0x1
    3934:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3938:	7100b41f 	cmp	w0, #0x2d
    393c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3940:	1a9f17e4 	cset	w4, eq	// eq = none
    3944:	cb010266 	sub	x6, x19, x1
    3948:	d10004da 	sub	x26, x6, #0x1
    394c:	540018a0 	b.eq	3c60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3950:	910183f9 	add	x25, sp, #0x60
    3954:	d280091b 	mov	x27, #0x48                  	// #72
    3958:	aa1903e7 	mov	x7, x25
    395c:	91000423 	add	x3, x1, #0x1
    3960:	91011cc6 	add	x6, x6, #0x47
    3964:	910004f6 	add	x22, x7, #0x1
    3968:	37f80ff7 	tbnz	w23, #31, 3b64 <fwp_format_g.constprop.0+0x2e4>
    396c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3970:	93407ef7 	sxtw	x23, w23
    3974:	390000e4 	strb	w4, [x7]
    3978:	aa1303e1 	mov	x1, x19
    397c:	aa1703e2 	mov	x2, x23
    3980:	aa1603e0 	mov	x0, x22
    3984:	b9000be5 	str	w5, [sp, #8]
    3988:	cb170374 	sub	x20, x27, x23
    398c:	a9011be3 	stp	x3, x6, [sp, #16]
    3990:	97fffb74 	bl	2760 <memcpy@plt>
    3994:	d1000694 	sub	x20, x20, #0x1
    3998:	f9400be3 	ldr	x3, [sp, #16]
    399c:	8b1702d6 	add	x22, x22, x23
    39a0:	aa1603e0 	mov	x0, x22
    39a4:	aa1a03e2 	mov	x2, x26
    39a8:	aa0303e1 	mov	x1, x3
    39ac:	aa1403e3 	mov	x3, x20
    39b0:	97fffbac 	bl	2860 <__memcpy_chk@plt>
    39b4:	8b1a02d6 	add	x22, x22, x26
    39b8:	f9400fe6 	ldr	x6, [sp, #24]
    39bc:	d2800900 	mov	x0, #0x48                  	// #72
    39c0:	b9400be5 	ldr	w5, [sp, #8]
    39c4:	8b170261 	add	x1, x19, x23
    39c8:	cb1400c3 	sub	x3, x6, x20
    39cc:	cb060294 	sub	x20, x20, x6
    39d0:	f101207f 	cmp	x3, #0x48
    39d4:	93407cb8 	sxtw	x24, w5
    39d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39dc:	aa1803e2 	mov	x2, x24
    39e0:	8b1802d3 	add	x19, x22, x24
    39e4:	8b140063 	add	x3, x3, x20
    39e8:	aa1603e0 	mov	x0, x22
    39ec:	97fffb9d 	bl	2860 <__memcpy_chk@plt>
    39f0:	cb190273 	sub	x19, x19, x25
    39f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    39f8:	eb00027f 	cmp	x19, x0
    39fc:	aa1903e1 	mov	x1, x25
    3a00:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a04:	aa1503e0 	mov	x0, x21
    3a08:	aa1303e2 	mov	x2, x19
    3a0c:	97fffb55 	bl	2760 <memcpy@plt>
    3a10:	38336abf 	strb	wzr, [x21, x19]
    3a14:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	97fffb61 	bl	27a0 <strlen@plt>
    3a20:	aa0003f3 	mov	x19, x0
    3a24:	528005c1 	mov	w1, #0x2e                  	// #46
    3a28:	aa1503e0 	mov	x0, x21
    3a2c:	97fffbf1 	bl	29f0 <strchr@plt>
    3a30:	b4000140 	cbz	x0, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a34:	b4000133 	cbz	x19, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a38:	aa1303e1 	mov	x1, x19
    3a3c:	d1000673 	sub	x19, x19, #0x1
    3a40:	38736aa0 	ldrb	w0, [x21, x19]
    3a44:	7100c01f 	cmp	w0, #0x30
    3a48:	54001001 	b.ne	3c48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    3a4c:	38336abf 	strb	wzr, [x21, x19]
    3a50:	b5ffff53 	cbnz	x19, 3a38 <fwp_format_g.constprop.0+0x1b8>
    3a54:	d503201f 	nop
    3a58:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a5c:	f947f400 	ldr	x0, [x0, #4072]
    3a60:	f94057e2 	ldr	x2, [sp, #168]
    3a64:	f9400001 	ldr	x1, [x0]
    3a68:	eb010042 	subs	x2, x2, x1
    3a6c:	d2800001 	mov	x1, #0x0                   	// #0
    3a70:	54001061 	b.ne	3c7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3a74:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a78:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a7c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a80:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a84:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a88:	fd408be8 	ldr	d8, [sp, #272]
    3a8c:	910483ff 	add	sp, sp, #0x120
    3a90:	d65f03c0 	ret
    3a94:	1e604100 	fmov	d0, d8
    3a98:	710000bf 	cmp	w5, #0x0
    3a9c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3aa0:	aa1503e0 	mov	x0, x21
    3aa4:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1b30>
    3aa8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3aac:	913ee084 	add	x4, x4, #0xfb8
    3ab0:	52800042 	mov	w2, #0x2                   	// #2
    3ab4:	d2803201 	mov	x1, #0x190                 	// #400
    3ab8:	97fffb72 	bl	2880 <__snprintf_chk@plt>
    3abc:	17ffffd7 	b	3a18 <fwp_format_g.constprop.0+0x198>
    3ac0:	cb140273 	sub	x19, x19, x20
    3ac4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ac8:	910183f9 	add	x25, sp, #0x60
    3acc:	aa1303e2 	mov	x2, x19
    3ad0:	aa1403e1 	mov	x1, x20
    3ad4:	aa1903e0 	mov	x0, x25
    3ad8:	d2800803 	mov	x3, #0x40                  	// #64
    3adc:	97fffb61 	bl	2860 <__memcpy_chk@plt>
    3ae0:	38336b3f 	strb	wzr, [x25, x19]
    3ae4:	aa1903e0 	mov	x0, x25
    3ae8:	528005c1 	mov	w1, #0x2e                  	// #46
    3aec:	97fffbc1 	bl	29f0 <strchr@plt>
    3af0:	b40001c0 	cbz	x0, 3b28 <fwp_format_g.constprop.0+0x2a8>
    3af4:	b50000b3 	cbnz	x19, 3b08 <fwp_format_g.constprop.0+0x288>
    3af8:	1400000c 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3afc:	381ff01f 	sturb	wzr, [x0, #-1]
    3b00:	f1000673 	subs	x19, x19, #0x1
    3b04:	54000120 	b.eq	3b28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3b08:	8b130320 	add	x0, x25, x19
    3b0c:	385ff001 	ldurb	w1, [x0, #-1]
    3b10:	7100c03f 	cmp	w1, #0x30
    3b14:	54ffff40 	b.eq	3afc <fwp_format_g.constprop.0+0x27c>  // b.none
    3b18:	d1000673 	sub	x19, x19, #0x1
    3b1c:	38736b20 	ldrb	w0, [x25, x19]
    3b20:	7100b81f 	cmp	w0, #0x2e
    3b24:	54000a80 	b.eq	3c74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3b28:	710002ff 	cmp	w23, #0x0
    3b2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3b30:	aa1903e5 	mov	x5, x25
    3b34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	52800566 	mov	w6, #0x2b                  	// #43
    3b40:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1b30>
    3b44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b48:	913ea084 	add	x4, x4, #0xfa8
    3b4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b50:	52800042 	mov	w2, #0x2                   	// #2
    3b54:	d2803201 	mov	x1, #0x190                 	// #400
    3b58:	97fffb4a 	bl	2880 <__snprintf_chk@plt>
    3b5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b60:	17ffffbe 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3b64:	52800605 	mov	w5, #0x30                  	// #48
    3b68:	390000e5 	strb	w5, [x7]
    3b6c:	d100077b 	sub	x27, x27, #0x1
    3b70:	aa0303e1 	mov	x1, x3
    3b74:	aa1603e0 	mov	x0, x22
    3b78:	aa1b03e3 	mov	x3, x27
    3b7c:	aa1a03e2 	mov	x2, x26
    3b80:	f90007e6 	str	x6, [sp, #8]
    3b84:	b90013e4 	str	w4, [sp, #16]
    3b88:	8b1a02d6 	add	x22, x22, x26
    3b8c:	b9001be5 	str	w5, [sp, #24]
    3b90:	97fffb34 	bl	2860 <__memcpy_chk@plt>
    3b94:	f94007e6 	ldr	x6, [sp, #8]
    3b98:	2a3703e7 	mvn	w7, w23
    3b9c:	b94013e4 	ldr	w4, [sp, #16]
    3ba0:	cb1b00c1 	sub	x1, x6, x27
    3ba4:	cb06037b 	sub	x27, x27, x6
    3ba8:	f101203f 	cmp	x1, #0x48
    3bac:	d2800906 	mov	x6, #0x48                  	// #72
    3bb0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bb4:	8b1b0023 	add	x3, x1, x27
    3bb8:	310006ff 	cmn	w23, #0x1
    3bbc:	54000220 	b.eq	3c00 <fwp_format_g.constprop.0+0x380>  // b.none
    3bc0:	b9401be5 	ldr	w5, [sp, #24]
    3bc4:	d2800001 	mov	x1, #0x0                   	// #0
    3bc8:	f101207f 	cmp	x3, #0x48
    3bcc:	d1000462 	sub	x2, x3, #0x1
    3bd0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bd4:	38216ac5 	strb	w5, [x22, x1]
    3bd8:	cb030003 	sub	x3, x0, x3
    3bdc:	91000421 	add	x1, x1, #0x1
    3be0:	91000463 	add	x3, x3, #0x1
    3be4:	eb00007f 	cmp	x3, x0
    3be8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3bec:	cb000063 	sub	x3, x3, x0
    3bf0:	8b020063 	add	x3, x3, x2
    3bf4:	6b0100ff 	cmp	w7, w1
    3bf8:	54fffe8c 	b.gt	3bc8 <fwp_format_g.constprop.0+0x348>
    3bfc:	8b2742d6 	add	x22, x22, w7, uxtw
    3c00:	f101207f 	cmp	x3, #0x48
    3c04:	d2800905 	mov	x5, #0x48                  	// #72
    3c08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	cb0300a1 	sub	x1, x5, x3
    3c14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c18:	91000421 	add	x1, x1, #0x1
    3c1c:	d1000463 	sub	x3, x3, #0x1
    3c20:	eb05003f 	cmp	x1, x5
    3c24:	38001402 	strb	w2, [x0], #1
    3c28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c2c:	93407f82 	sxtw	x2, w28
    3c30:	cb050025 	sub	x5, x1, x5
    3c34:	aa1303e1 	mov	x1, x19
    3c38:	8b0300a3 	add	x3, x5, x3
    3c3c:	8b1802d3 	add	x19, x22, x24
    3c40:	97fffb08 	bl	2860 <__memcpy_chk@plt>
    3c44:	17ffff6b 	b	39f0 <fwp_format_g.constprop.0+0x170>
    3c48:	d1000421 	sub	x1, x1, #0x1
    3c4c:	38616aa0 	ldrb	w0, [x21, x1]
    3c50:	7100b81f 	cmp	w0, #0x2e
    3c54:	54fff021 	b.ne	3a58 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3c58:	38216abf 	strb	wzr, [x21, x1]
    3c5c:	17ffff7f 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3c60:	910187e7 	add	x7, sp, #0x61
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d28008fb 	mov	x27, #0x47                  	// #71
    3c6c:	390183e0 	strb	w0, [sp, #96]
    3c70:	17ffff3b 	b	395c <fwp_format_g.constprop.0+0xdc>
    3c74:	38336b3f 	strb	wzr, [x25, x19]
    3c78:	17ffffac 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3c7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c80:	97fffb24 	bl	2910 <__stack_chk_fail@plt>

0000000000003c84 <fwp_heap_report>:
    3c84:	d105c3ff 	sub	sp, sp, #0x170
    3c88:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c8c:	91174042 	add	x2, x2, #0x5d0
    3c90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3c94:	f947e821 	ldr	x1, [x1, #4048]
    3c98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c9c:	910443fd 	add	x29, sp, #0x110
    3ca0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ca4:	f947f400 	ldr	x0, [x0, #4072]
    3ca8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cac:	a91463f7 	stp	x23, x24, [sp, #320]
    3cb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3cc0:	f9400036 	ldr	x22, [x1]
    3cc4:	f9400001 	ldr	x1, [x0]
    3cc8:	f90087e1 	str	x1, [sp, #264]
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	f949e459 	ldr	x25, [x2, #5064]
    3cd4:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1b30>
    3cd8:	f94a1057 	ldr	x23, [x2, #5152]
    3cdc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    3ce0:	f94a1458 	ldr	x24, [x2, #5160]
    3ce4:	913f0021 	add	x1, x1, #0xfc0
    3ce8:	913f2000 	add	x0, x0, #0xfc8
    3cec:	97fffaed 	bl	28a0 <fopen@plt>
    3cf0:	b4000760 	cbz	x0, 3ddc <fwp_heap_report+0x158>
    3cf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3cf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3cfc:	aa0003f4 	mov	x20, x0
    3d00:	910023f3 	add	x19, sp, #0x8
    3d04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d08:	72aae915 	movk	w21, #0x5748, lsl #16
    3d0c:	d503201f 	nop
    3d10:	aa1403e2 	mov	x2, x20
    3d14:	aa1303e0 	mov	x0, x19
    3d18:	52802001 	mov	w1, #0x100                 	// #256
    3d1c:	97fffb6d 	bl	2ad0 <fgets@plt>
    3d20:	b4000280 	cbz	x0, 3d70 <fwp_heap_report+0xec>
    3d24:	b9400261 	ldr	w1, [x19]
    3d28:	6b15003f 	cmp	w1, w21
    3d2c:	54ffff21 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d30:	39401260 	ldrb	w0, [x19, #4]
    3d34:	7101341f 	cmp	w0, #0x4d
    3d38:	54fffec1 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d3c:	394037e0 	ldrb	w0, [sp, #13]
    3d40:	7100e81f 	cmp	w0, #0x3a
    3d44:	54fffe61 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d48:	52800142 	mov	w2, #0xa                   	// #10
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	91003be0 	add	x0, sp, #0xe
    3d54:	97fffb17 	bl	29b0 <strtol@plt>
    3d58:	aa1403e2 	mov	x2, x20
    3d5c:	aa0003fa 	mov	x26, x0
    3d60:	52802001 	mov	w1, #0x100                 	// #256
    3d64:	aa1303e0 	mov	x0, x19
    3d68:	97fffb5a 	bl	2ad0 <fgets@plt>
    3d6c:	b5fffdc0 	cbnz	x0, 3d24 <fwp_heap_report+0xa0>
    3d70:	aa1403e0 	mov	x0, x20
    3d74:	97fffac7 	bl	2890 <fclose@plt>
    3d78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d80:	f947f400 	ldr	x0, [x0, #4072]
    3d84:	f94087e2 	ldr	x2, [sp, #264]
    3d88:	f9400001 	ldr	x1, [x0]
    3d8c:	eb010042 	subs	x2, x2, x1
    3d90:	d2800001 	mov	x1, #0x0                   	// #0
    3d94:	54000281 	b.ne	3de4 <fwp_heap_report+0x160>  // b.any
    3d98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d9c:	aa1a03e6 	mov	x6, x26
    3da0:	aa1903e5 	mov	x5, x25
    3da4:	aa1803e4 	mov	x4, x24
    3da8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dac:	aa1703e3 	mov	x3, x23
    3db0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3db4:	aa1603e0 	mov	x0, x22
    3db8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dbc:	1e604121 	fmov	d1, d9
    3dc0:	1e604100 	fmov	d0, d8
    3dc4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1b30>
    3dc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3dcc:	913fa042 	add	x2, x2, #0xfe8
    3dd0:	9105c3ff 	add	sp, sp, #0x170
    3dd4:	52800041 	mov	w1, #0x2                   	// #2
    3dd8:	17fffaea 	b	2980 <__fprintf_chk@plt>
    3ddc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3de0:	17ffffe7 	b	3d7c <fwp_heap_report+0xf8>
    3de4:	a91253f3 	stp	x19, x20, [sp, #288]
    3de8:	97fffaca 	bl	2910 <__stack_chk_fail@plt>
    3dec:	d503201f 	nop

0000000000003df0 <fwp_heap_init>:
    3df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3df4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3df8:	91134061 	add	x1, x3, #0x4d0
    3dfc:	910003fd 	mov	x29, sp
    3e00:	a90153f3 	stp	x19, x20, [sp, #16]
    3e04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3e08:	91174262 	add	x2, x19, #0x5d0
    3e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e10:	52800024 	mov	w4, #0x1                   	// #1
    3e14:	52800200 	mov	w0, #0x10                  	// #16
    3e18:	b913a444 	str	w4, [x2, #5028]
    3e1c:	d503201f 	nop
    3e20:	b8004420 	str	w0, [x1], #4
    3e24:	11004000 	add	w0, w0, #0x10
    3e28:	7104401f 	cmp	w0, #0x110
    3e2c:	54ffffa1 	b.ne	3e20 <fwp_heap_init+0x30>  // b.any
    3e30:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x150>
    3e34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3e3c:	91144021 	add	x1, x1, #0x510
    3e40:	3dc32443 	ldr	q3, [x2, #3216]
    3e44:	d2800000 	mov	x0, #0x0                   	// #0
    3e48:	4e040401 	dup	v1.4s, v0.s[0]
    3e4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e50:	0f215400 	shl	v0.2s, v0.2s, #1
    3e54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e58:	3ca06821 	str	q1, [x1, x0]
    3e5c:	91004000 	add	x0, x0, #0x10
    3e60:	f101801f 	cmp	x0, #0x60
    3e64:	54ffff21 	b.ne	3e48 <fwp_heap_init+0x58>  // b.any
    3e68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3e6c:	91134063 	add	x3, x3, #0x4d0
    3e70:	9115c084 	add	x4, x4, #0x570
    3e74:	91174266 	add	x6, x19, #0x5d0
    3e78:	d2800002 	mov	x2, #0x0                   	// #0
    3e7c:	d2800000 	mov	x0, #0x0                   	// #0
    3e80:	d2880205 	mov	x5, #0x4010                	// #16400
    3e84:	d503201f 	nop
    3e88:	910f0001 	add	x1, x0, #0x3c0
    3e8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e90:	eb02003f 	cmp	x1, x2
    3e94:	540000a2 	b.cs	3ea8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e98:	91000400 	add	x0, x0, #0x1
    3e9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	54ffffa3 	b.cc	3e98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ea8:	91004042 	add	x2, x2, #0x10
    3eac:	38001480 	strb	w0, [x4], #1
    3eb0:	eb05005f 	cmp	x2, x5
    3eb4:	54fffea1 	b.ne	3e88 <fwp_heap_init+0x98>  // b.any
    3eb8:	528000b5 	mov	w21, #0x5                   	// #5
    3ebc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ec0:	14000004 	b	3ed0 <fwp_heap_init+0xe0>
    3ec4:	d342fe94 	lsr	x20, x20, #2
    3ec8:	710006b5 	subs	w21, w21, #0x1
    3ecc:	54000720 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3ed0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ed4:	d2800005 	mov	x5, #0x0                   	// #0
    3ed8:	aa1603e1 	mov	x1, x22
    3edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ee0:	52880443 	mov	w3, #0x4022                	// #16418
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	d2800000 	mov	x0, #0x0                   	// #0
    3eec:	97fffaad 	bl	29a0 <mmap@plt>
    3ef0:	aa0003e6 	mov	x6, x0
    3ef4:	b100041f 	cmn	x0, #0x1
    3ef8:	54fffe60 	b.eq	3ec4 <fwp_heap_init+0xd4>  // b.none
    3efc:	b40005a0 	cbz	x0, 3fb0 <fwp_heap_init+0x1c0>
    3f00:	d350fe94 	lsr	x20, x20, #16
    3f04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f08:	8b0000c7 	add	x7, x6, x0
    3f0c:	91174275 	add	x21, x19, #0x5d0
    3f10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f14:	8b140a81 	add	x1, x20, x20, lsl #2
    3f18:	d2800005 	mov	x5, #0x0                   	// #0
    3f1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f20:	d37df021 	lsl	x1, x1, #3
    3f24:	52880443 	mov	w3, #0x4022                	// #16418
    3f28:	52800002 	mov	w2, #0x0                   	// #0
    3f2c:	d2800000 	mov	x0, #0x0                   	// #0
    3f30:	f909daa7 	str	x7, [x21, #5040]
    3f34:	f909dea6 	str	x6, [x21, #5048]
    3f38:	f909e2b6 	str	x22, [x21, #5056]
    3f3c:	f909eab4 	str	x20, [x21, #5072]
    3f40:	f90a02a1 	str	x1, [x21, #5120]
    3f44:	97fffa97 	bl	29a0 <mmap@plt>
    3f48:	aa0003e1 	mov	x1, x0
    3f4c:	b100041f 	cmn	x0, #0x1
    3f50:	54000300 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3f54:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x150>
    3f58:	9101c000 	add	x0, x0, #0x70
    3f5c:	f909fea1 	str	x1, [x21, #5112]
    3f60:	97fffad0 	bl	2aa0 <getenv@plt>
    3f64:	52800002 	mov	w2, #0x0                   	// #0
    3f68:	aa0003e1 	mov	x1, x0
    3f6c:	b40000e0 	cbz	x0, 3f88 <fwp_heap_init+0x198>
    3f70:	39400000 	ldrb	w0, [x0]
    3f74:	340000a0 	cbz	w0, 3f88 <fwp_heap_init+0x198>
    3f78:	7100c000 	subs	w0, w0, #0x30
    3f7c:	54000120 	b.eq	3fa0 <fwp_heap_init+0x1b0>  // b.none
    3f80:	7100001f 	cmp	w0, #0x0
    3f84:	1a9f07e2 	cset	w2, ne	// ne = any
    3f88:	91174273 	add	x19, x19, #0x5d0
    3f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f90:	b913aa62 	str	w2, [x19, #5032]
    3f94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f9c:	d65f03c0 	ret
    3fa0:	39400420 	ldrb	w0, [x1, #1]
    3fa4:	7100001f 	cmp	w0, #0x0
    3fa8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fac:	17fffff7 	b	3f88 <fwp_heap_init+0x198>
    3fb0:	97fffc40 	bl	30b0 <fwp_heap_oom>

0000000000003fb4 <fwp_wake_io>:
    3fb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fb8:	9101c122 	add	x2, x9, #0x70
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	5280000a 	mov	w10, #0x0                   	// #0
    3fc4:	f9403c46 	ldr	x6, [x2, #120]
    3fc8:	52800008 	mov	w8, #0x0                   	// #0
    3fcc:	4f000400 	movi	v0.4s, #0x0
    3fd0:	52800027 	mov	w7, #0x1                   	// #1
    3fd4:	aa0103e2 	mov	x2, x1
    3fd8:	b4000321 	cbz	x1, 403c <fwp_wake_io+0x88>
    3fdc:	f9408c25 	ldr	x5, [x1, #280]
    3fe0:	39015c27 	strb	w7, [x1, #87]
    3fe4:	b4000165 	cbz	x5, 4010 <fwp_wake_io+0x5c>
    3fe8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3fec:	b4000364 	cbz	x4, 4058 <fwp_wake_io+0xa4>
    3ff0:	f9009483 	str	x3, [x4, #296]
    3ff4:	f9409423 	ldr	x3, [x1, #296]
    3ff8:	b4000043 	cbz	x3, 4000 <fwp_wake_io+0x4c>
    3ffc:	f9009064 	str	x4, [x3, #288]
    4000:	91080023 	add	x3, x1, #0x200
    4004:	f900943f 	str	xzr, [x1, #296]
    4008:	3c918060 	stur	q0, [x3, #-232]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	f9402843 	ldr	x3, [x2, #80]
    4014:	f2001c7f 	tst	x3, #0xff000000ff
    4018:	54fffde1 	b.ne	3fd4 <fwp_wake_io+0x20>  // b.any
    401c:	39015047 	strb	w7, [x2, #84]
    4020:	f900805f 	str	xzr, [x2, #256]
    4024:	b40001e6 	cbz	x6, 4060 <fwp_wake_io+0xac>
    4028:	f90080c2 	str	x2, [x6, #256]
    402c:	aa0203e6 	mov	x6, x2
    4030:	52800028 	mov	w8, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b5fffd21 	cbnz	x1, 3fdc <fwp_wake_io+0x28>
    403c:	3400006a 	cbz	w10, 4048 <fwp_wake_io+0x94>
    4040:	9101c120 	add	x0, x9, #0x70
    4044:	f900400b 	str	x11, [x0, #128]
    4048:	34000068 	cbz	w8, 4054 <fwp_wake_io+0xa0>
    404c:	9101c129 	add	x9, x9, #0x70
    4050:	f9003d26 	str	x6, [x9, #120]
    4054:	d65f03c0 	ret
    4058:	f90000a3 	str	x3, [x5]
    405c:	17ffffe7 	b	3ff8 <fwp_wake_io+0x44>
    4060:	aa0203eb 	mov	x11, x2
    4064:	5280002a 	mov	w10, #0x1                   	// #1
    4068:	17fffff1 	b	402c <fwp_wake_io+0x78>
    406c:	d503201f 	nop

0000000000004070 <fwp_tape_buffers_release>:
    4070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4074:	910003fd 	mov	x29, sp
    4078:	a90153f3 	stp	x19, x20, [sp, #16]
    407c:	aa0003f3 	mov	x19, x0
    4080:	f9401400 	ldr	x0, [x0, #40]
    4084:	b7f80760 	tbnz	x0, #63, 4170 <fwp_tape_buffers_release+0x100>
    4088:	f9401a61 	ldr	x1, [x19, #48]
    408c:	b7f80301 	tbnz	x1, #63, 40ec <fwp_tape_buffers_release+0x7c>
    4090:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4094:	eb02001f 	cmp	x0, x2
    4098:	540002a8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    409c:	8b000400 	add	x0, x0, x0, lsl #1
    40a0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40a4:	d37df000 	lsl	x0, x0, #3
    40a8:	cb000042 	sub	x2, x2, x0
    40ac:	eb420c3f 	cmp	x1, x2, lsr #3
    40b0:	540001e8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    40b4:	8b010c14 	add	x20, x0, x1, lsl #3
    40b8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    40bc:	91020000 	add	x0, x0, #0x80
    40c0:	97fffa78 	bl	2aa0 <getenv@plt>
    40c4:	b4000240 	cbz	x0, 410c <fwp_tape_buffers_release+0x9c>
    40c8:	39400001 	ldrb	w1, [x0]
    40cc:	7100c03f 	cmp	w1, #0x30
    40d0:	540001e1 	b.ne	410c <fwp_tape_buffers_release+0x9c>  // b.any
    40d4:	39400400 	ldrb	w0, [x0, #1]
    40d8:	350001a0 	cbnz	w0, 410c <fwp_tape_buffers_release+0x9c>
    40dc:	aa1303e0 	mov	x0, x19
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e8:	17fffd06 	b	3500 <fwp_tape_buffers_dispose>
    40ec:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    40f0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f4:	91020000 	add	x0, x0, #0x80
    40f8:	97fffa6a 	bl	2aa0 <getenv@plt>
    40fc:	b4ffff00 	cbz	x0, 40dc <fwp_tape_buffers_release+0x6c>
    4100:	39400001 	ldrb	w1, [x0]
    4104:	7100c03f 	cmp	w1, #0x30
    4108:	54fffe60 	b.eq	40d4 <fwp_tape_buffers_release+0x64>  // b.none
    410c:	d1000681 	sub	x1, x20, #0x1
    4110:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4114:	eb00003f 	cmp	x1, x0
    4118:	54fffe28 	b.hi	40dc <fwp_tape_buffers_release+0x6c>  // b.pmore
    411c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4120:	900000f6 	adrp	x22, 20000 <__data_start>
    4124:	9101c2d6 	add	x22, x22, #0x70
    4128:	910222d5 	add	x21, x22, #0x88
    412c:	aa1503e0 	mov	x0, x21
    4130:	97fffcf4 	bl	3500 <fwp_tape_buffers_dispose>
    4134:	ad400a61 	ldp	q1, q2, [x19]
    4138:	f90062d4 	str	x20, [x22, #192]
    413c:	4f000400 	movi	v0.4s, #0x0
    4140:	ad000aa1 	stp	q1, q2, [x21]
    4144:	3dc00a61 	ldr	q1, [x19, #32]
    4148:	3d800aa1 	str	q1, [x21, #32]
    414c:	f9401a60 	ldr	x0, [x19, #48]
    4150:	f9001aa0 	str	x0, [x21, #48]
    4154:	f9001a7f 	str	xzr, [x19, #48]
    4158:	ad000260 	stp	q0, q0, [x19]
    415c:	3d800a60 	str	q0, [x19, #32]
    4160:	a94153f3 	ldp	x19, x20, [sp, #16]
    4164:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    416c:	d65f03c0 	ret
    4170:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4174:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4178:	91020000 	add	x0, x0, #0x80
    417c:	97fffa49 	bl	2aa0 <getenv@plt>
    4180:	b5fffa40 	cbnz	x0, 40c8 <fwp_tape_buffers_release+0x58>
    4184:	17ffffd6 	b	40dc <fwp_tape_buffers_release+0x6c>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <fwp_trap>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	900000e2 	adrp	x2, 20000 <__data_start>
    4198:	d53bd041 	mrs	x1, tpidr_el0
    419c:	910003fd 	mov	x29, sp
    41a0:	f9403c42 	ldr	x2, [x2, #120]
    41a4:	91400021 	add	x1, x1, #0x0, lsl #12
    41a8:	91004021 	add	x1, x1, #0x10
    41ac:	a90153f3 	stp	x19, x20, [sp, #16]
    41b0:	aa0003f3 	mov	x19, x0
    41b4:	f9400034 	ldr	x20, [x1]
    41b8:	b4000062 	cbz	x2, 41c4 <fwp_trap+0x34>
    41bc:	aa0203e0 	mov	x0, x2
    41c0:	97fffa20 	bl	2a40 <fflush@plt>
    41c4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    41c8:	f947ec00 	ldr	x0, [x0, #4056]
    41cc:	f9400000 	ldr	x0, [x0]
    41d0:	97fffa1c 	bl	2a40 <fflush@plt>
    41d4:	aa1303e3 	mov	x3, x19
    41d8:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x150>
    41dc:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    41e0:	f947ea73 	ldr	x19, [x19, #4048]
    41e4:	91026042 	add	x2, x2, #0x98
    41e8:	52800041 	mov	w1, #0x2                   	// #2
    41ec:	f9400260 	ldr	x0, [x19]
    41f0:	97fff9e4 	bl	2980 <__fprintf_chk@plt>
    41f4:	b40000b4 	cbz	x20, 4208 <fwp_trap+0x78>
    41f8:	f9400260 	ldr	x0, [x19]
    41fc:	97fffa11 	bl	2a40 <fflush@plt>
    4200:	52800ca0 	mov	w0, #0x65                  	// #101
    4204:	97fffa1f 	bl	2a80 <_Exit@plt>
    4208:	52800ca0 	mov	w0, #0x65                  	// #101
    420c:	97fff96d 	bl	27c0 <exit@plt>

0000000000004210 <fwp_rc_forget_slot.part.0>:
    4210:	ca404401 	eor	x1, x0, x0, lsr #17
    4214:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4218:	ca412421 	eor	x1, x1, x1, lsr #9
    421c:	910003fd 	mov	x29, sp
    4220:	92401c21 	and	x1, x1, #0xff
    4224:	f9000bf3 	str	x19, [sp, #16]
    4228:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    422c:	91174262 	add	x2, x19, #0x5d0
    4230:	910a2423 	add	x3, x1, #0x289
    4234:	8b010c41 	add	x1, x2, x1, lsl #3
    4238:	8b030c43 	add	x3, x2, x3, lsl #3
    423c:	f94a2421 	ldr	x1, [x1, #5192]
    4240:	b50000a1 	cbnz	x1, 4254 <fwp_rc_forget_slot.part.0+0x44>
    4244:	14000012 	b	428c <fwp_rc_forget_slot.part.0+0x7c>
    4248:	91004023 	add	x3, x1, #0x10
    424c:	f9400821 	ldr	x1, [x1, #16]
    4250:	b40001e1 	cbz	x1, 428c <fwp_rc_forget_slot.part.0+0x7c>
    4254:	f9400022 	ldr	x2, [x1]
    4258:	eb02001f 	cmp	x0, x2
    425c:	54ffff61 	b.ne	4248 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4260:	f9400060 	ldr	x0, [x3]
    4264:	91174273 	add	x19, x19, #0x5d0
    4268:	f9400801 	ldr	x1, [x0, #16]
    426c:	f9000061 	str	x1, [x3]
    4270:	97fff9d8 	bl	29d0 <free@plt>
    4274:	f94e2660 	ldr	x0, [x19, #7240]
    4278:	d1000400 	sub	x0, x0, #0x1
    427c:	f90e2660 	str	x0, [x19, #7240]
    4280:	f9400bf3 	ldr	x19, [sp, #16]
    4284:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4288:	d65f03c0 	ret
    428c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4290:	9102a000 	add	x0, x0, #0xa8
    4294:	97ffffbf 	bl	4190 <fwp_trap>
    4298:	d503201f 	nop
    429c:	d503201f 	nop

00000000000042a0 <fwp_rc_prepare_chunk>:
    42a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42a4:	910003fd 	mov	x29, sp
    42a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    42ac:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    42b0:	911742c2 	add	x2, x22, #0x5d0
    42b4:	b9401c03 	ldr	w3, [x0, #28]
    42b8:	aa0103f5 	mov	x21, x1
    42bc:	a90153f3 	stp	x19, x20, [sp, #16]
    42c0:	aa0003f4 	mov	x20, x0
    42c4:	f94e2440 	ldr	x0, [x2, #7240]
    42c8:	b4000440 	cbz	x0, 4350 <fwp_rc_prepare_chunk+0xb0>
    42cc:	d2800013 	mov	x19, #0x0                   	// #0
    42d0:	35000203 	cbnz	w3, 4310 <fwp_rc_prepare_chunk+0x70>
    42d4:	b4000361 	cbz	x1, 4340 <fwp_rc_prepare_chunk+0xa0>
    42d8:	f9401280 	ldr	x0, [x20, #32]
    42dc:	97fff9bd 	bl	29d0 <free@plt>
    42e0:	aa1503e0 	mov	x0, x21
    42e4:	d2800021 	mov	x1, #0x1                   	// #1
    42e8:	97fff982 	bl	28f0 <calloc@plt>
    42ec:	f9001280 	str	x0, [x20, #32]
    42f0:	b5000460 	cbnz	x0, 437c <fwp_rc_prepare_chunk+0xdc>
    42f4:	97fffb6f 	bl	30b0 <fwp_heap_oom>
    42f8:	97ffffc6 	bl	4210 <fwp_rc_forget_slot.part.0>
    42fc:	91000673 	add	x19, x19, #0x1
    4300:	b9401e83 	ldr	w3, [x20, #28]
    4304:	eb13007f 	cmp	x3, x19
    4308:	54000169 	b.ls	4334 <fwp_rc_prepare_chunk+0x94>  // b.plast
    430c:	d503201f 	nop
    4310:	f9401283 	ldr	x3, [x20, #32]
    4314:	8b130060 	add	x0, x3, x19
    4318:	38736863 	ldrb	w3, [x3, x19]
    431c:	7103fc7f 	cmp	w3, #0xff
    4320:	54fffec0 	b.eq	42f8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4324:	b9401e83 	ldr	w3, [x20, #28]
    4328:	91000673 	add	x19, x19, #0x1
    432c:	eb13007f 	cmp	x3, x19
    4330:	54ffff08 	b.hi	4310 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4334:	eb0302bf 	cmp	x21, x3
    4338:	54000121 	b.ne	435c <fwp_rc_prepare_chunk+0xbc>  // b.any
    433c:	b5000335 	cbnz	x21, 43a0 <fwp_rc_prepare_chunk+0x100>
    4340:	a94153f3 	ldp	x19, x20, [sp, #16]
    4344:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4348:	a8c37bfd 	ldp	x29, x30, [sp], #48
    434c:	d65f03c0 	ret
    4350:	2a0303e3 	mov	w3, w3
    4354:	eb0302bf 	cmp	x21, x3
    4358:	54ffff20 	b.eq	433c <fwp_rc_prepare_chunk+0x9c>  // b.none
    435c:	911742c2 	add	x2, x22, #0x5d0
    4360:	f9401280 	ldr	x0, [x20, #32]
    4364:	f94e2841 	ldr	x1, [x2, #7248]
    4368:	cb030021 	sub	x1, x1, x3
    436c:	f90e2841 	str	x1, [x2, #7248]
    4370:	97fff998 	bl	29d0 <free@plt>
    4374:	b5fffb75 	cbnz	x21, 42e0 <fwp_rc_prepare_chunk+0x40>
    4378:	f900129f 	str	xzr, [x20, #32]
    437c:	911742d6 	add	x22, x22, #0x5d0
    4380:	f94e2ac0 	ldr	x0, [x22, #7248]
    4384:	b9001e95 	str	w21, [x20, #28]
    4388:	a94153f3 	ldp	x19, x20, [sp, #16]
    438c:	8b150000 	add	x0, x0, x21
    4390:	f90e2ac0 	str	x0, [x22, #7248]
    4394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4398:	a8c37bfd 	ldp	x29, x30, [sp], #48
    439c:	d65f03c0 	ret
    43a0:	f9401280 	ldr	x0, [x20, #32]
    43a4:	aa1503e2 	mov	x2, x21
    43a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43ac:	52800001 	mov	w1, #0x0                   	// #0
    43b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43b8:	17fff94a 	b	28e0 <memset@plt>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_heap_refill>:
    43c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    43d0:	911742b5 	add	x21, x21, #0x5d0
    43d4:	aa0003f6 	mov	x22, x0
    43d8:	d2800020 	mov	x0, #0x1                   	// #1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	a90363f7 	stp	x23, x24, [sp, #48]
    43e4:	2a0103f7 	mov	w23, w1
    43e8:	2a0203f8 	mov	w24, w2
    43ec:	97fffbd1 	bl	3330 <fwp_heap_chunks>
    43f0:	aa0003f3 	mov	x19, x0
    43f4:	f949fea2 	ldr	x2, [x21, #5112]
    43f8:	8b000800 	add	x0, x0, x0, lsl #2
    43fc:	2a1703e1 	mov	w1, w23
    4400:	52800025 	mov	w5, #0x1                   	// #1
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	910f0021 	add	x1, x1, #0x3c0
    440c:	8b000054 	add	x20, x2, x0
    4410:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4414:	52a00024 	mov	w4, #0x10000               	// #65536
    4418:	38206845 	strb	w5, [x2, x0]
    441c:	aa1403e0 	mov	x0, x20
    4420:	39000698 	strb	w24, [x20, #1]
    4424:	39000a97 	strb	w23, [x20, #2]
    4428:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    442c:	b9000681 	str	w1, [x20, #4]
    4430:	2a0103e5 	mov	w5, w1
    4434:	8b0300a2 	add	x2, x5, x3
    4438:	1ac10881 	udiv	w1, w4, w1
    443c:	9ac50842 	udiv	x2, x2, x5
    4440:	b9000a81 	str	w1, [x20, #8]
    4444:	92404021 	and	x1, x1, #0x1ffff
    4448:	b9001a82 	str	w2, [x20, #24]
    444c:	97ffff95 	bl	42a0 <fwp_rc_prepare_chunk>
    4450:	f949daa0 	ldr	x0, [x21, #5040]
    4454:	29408a81 	ldp	w1, w2, [x20, #4]
    4458:	8b134000 	add	x0, x0, x19, lsl #16
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	8b214003 	add	x3, x0, w1, uxtw
    4464:	9ba20021 	umaddl	x1, w1, w2, x0
    4468:	a94363f7 	ldp	x23, x24, [sp, #48]
    446c:	a90086c3 	stp	x3, x1, [x22, #8]
    4470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4474:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4478:	d65f03c0 	ret
    447c:	d503201f 	nop

0000000000004480 <fwp_mem_free>:
    4480:	b40003c0 	cbz	x0, 44f8 <fwp_mem_free+0x78>
    4484:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4488:	910003fd 	mov	x29, sp
    448c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4490:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4494:	911742a1 	add	x1, x21, #0x5d0
    4498:	a90153f3 	stp	x19, x20, [sp, #16]
    449c:	aa0003f3 	mov	x19, x0
    44a0:	f949d823 	ldr	x3, [x1, #5040]
    44a4:	f949ec22 	ldr	x2, [x1, #5080]
    44a8:	cb030000 	sub	x0, x0, x3
    44ac:	eb02401f 	cmp	x0, x2, lsl #16
    44b0:	540001c2 	b.cs	44e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    44b4:	d350fc16 	lsr	x22, x0, #16
    44b8:	a90363f7 	stp	x23, x24, [sp, #48]
    44bc:	f949fc22 	ldr	x2, [x1, #5112]
    44c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    44c4:	d37df294 	lsl	x20, x20, #3
    44c8:	ab140057 	adds	x23, x2, x20
    44cc:	540000c0 	b.eq	44e4 <fwp_mem_free+0x64>  // b.none
    44d0:	38746842 	ldrb	w2, [x2, x20]
    44d4:	7100045f 	cmp	w2, #0x1
    44d8:	54000120 	b.eq	44fc <fwp_mem_free+0x7c>  // b.none
    44dc:	7100085f 	cmp	w2, #0x2
    44e0:	540005e0 	b.eq	459c <fwp_mem_free+0x11c>  // b.none
    44e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44f4:	d65f03c0 	ret
    44f8:	d65f03c0 	ret
    44fc:	f94012f8 	ldr	x24, [x23, #32]
    4500:	b94006e1 	ldr	w1, [x23, #4]
    4504:	f90023f9 	str	x25, [sp, #64]
    4508:	2a0103e2 	mov	w2, w1
    450c:	394006f9 	ldrb	w25, [x23, #1]
    4510:	39400af4 	ldrb	w20, [x23, #2]
    4514:	b4000158 	cbz	x24, 453c <fwp_mem_free+0xbc>
    4518:	92403e76 	and	x22, x19, #0xffff
    451c:	9ac20ad6 	udiv	x22, x22, x2
    4520:	38766b01 	ldrb	w1, [x24, x22]
    4524:	8b160300 	add	x0, x24, x22
    4528:	7103fc3f 	cmp	w1, #0xff
    452c:	54000980 	b.eq	465c <fwp_mem_free+0x1dc>  // b.none
    4530:	38366b1f 	strb	wzr, [x24, x22]
    4534:	b94006e1 	ldr	w1, [x23, #4]
    4538:	2a0103e2 	mov	w2, w1
    453c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4540:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4544:	cb390000 	sub	x0, x0, w25, uxtb
    4548:	8b340074 	add	x20, x3, w20, uxtb
    454c:	911742b5 	add	x21, x21, #0x5d0
    4550:	1e630021 	ucvtf	d1, w1
    4554:	d37ae400 	lsl	x0, x0, #6
    4558:	8b140c14 	add	x20, x0, x20, lsl #3
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	f8746aa0 	ldr	x0, [x21, x20]
    4564:	f94023f9 	ldr	x25, [sp, #64]
    4568:	aa2003e0 	mvn	x0, x0
    456c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4570:	f9000260 	str	x0, [x19]
    4574:	f8346ab3 	str	x19, [x21, x20]
    4578:	f94a12a0 	ldr	x0, [x21, #5152]
    457c:	1e612800 	fadd	d0, d0, d1
    4580:	a94153f3 	ldp	x19, x20, [sp, #16]
    4584:	cb020000 	sub	x0, x0, x2
    4588:	f90a12a0 	str	x0, [x21, #5152]
    458c:	fd0a22a0 	str	d0, [x21, #5184]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4598:	d65f03c0 	ret
    459c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    45a0:	8b000063 	add	x3, x3, x0
    45a4:	eb03027f 	cmp	x19, x3
    45a8:	54fff9e1 	b.ne	44e4 <fwp_mem_free+0x64>  // b.any
    45ac:	fd400ae1 	ldr	d1, [x23, #16]
    45b0:	fd4a2020 	ldr	d0, [x1, #5184]
    45b4:	f9400ae0 	ldr	x0, [x23, #16]
    45b8:	7e61d821 	ucvtf	d1, d1
    45bc:	f94a1022 	ldr	x2, [x1, #5152]
    45c0:	f94012f3 	ldr	x19, [x23, #32]
    45c4:	1e612800 	fadd	d0, d0, d1
    45c8:	cb000042 	sub	x2, x2, x0
    45cc:	f90a1022 	str	x2, [x1, #5152]
    45d0:	fd0a2020 	str	d0, [x1, #5184]
    45d4:	b40000b3 	cbz	x19, 45e8 <fwp_mem_free+0x168>
    45d8:	39400260 	ldrb	w0, [x19]
    45dc:	7103fc1f 	cmp	w0, #0xff
    45e0:	54000380 	b.eq	4650 <fwp_mem_free+0x1d0>  // b.none
    45e4:	3900027f 	strb	wzr, [x19]
    45e8:	b9400ee2 	ldr	w2, [x23, #12]
    45ec:	b4000142 	cbz	x2, 4614 <fwp_mem_free+0x194>
    45f0:	911742a1 	add	x1, x21, #0x5d0
    45f4:	8b160040 	add	x0, x2, x22
    45f8:	8b000800 	add	x0, x0, x0, lsl #2
    45fc:	f949fc21 	ldr	x1, [x1, #5112]
    4600:	8b140034 	add	x20, x1, x20
    4604:	8b000c20 	add	x0, x1, x0, lsl #3
    4608:	3802869f 	strb	wzr, [x20], #40
    460c:	eb00029f 	cmp	x20, x0
    4610:	54ffffc1 	b.ne	4608 <fwp_mem_free+0x188>  // b.any
    4614:	911742a0 	add	x0, x21, #0x5d0
    4618:	f94a1801 	ldr	x1, [x0, #5168]
    461c:	f949f803 	ldr	x3, [x0, #5104]
    4620:	8b020021 	add	x1, x1, x2
    4624:	f90a1801 	str	x1, [x0, #5168]
    4628:	eb16007f 	cmp	x3, x22
    462c:	54000049 	b.ls	4634 <fwp_mem_free+0x1b4>  // b.plast
    4630:	f909f816 	str	x22, [x0, #5104]
    4634:	911742b5 	add	x21, x21, #0x5d0
    4638:	f949f6a0 	ldr	x0, [x21, #5096]
    463c:	eb16001f 	cmp	x0, x22
    4640:	54fff529 	b.ls	44e4 <fwp_mem_free+0x64>  // b.plast
    4644:	a94363f7 	ldp	x23, x24, [sp, #48]
    4648:	f909f6b6 	str	x22, [x21, #5096]
    464c:	17ffffa7 	b	44e8 <fwp_mem_free+0x68>
    4650:	aa1303e0 	mov	x0, x19
    4654:	97fffeef 	bl	4210 <fwp_rc_forget_slot.part.0>
    4658:	17ffffe3 	b	45e4 <fwp_mem_free+0x164>
    465c:	97fffeed 	bl	4210 <fwp_rc_forget_slot.part.0>
    4660:	17ffffb4 	b	4530 <fwp_mem_free+0xb0>

0000000000004664 <fwp_rc_wide_dup>:
    4664:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4668:	910003fd 	mov	x29, sp
    466c:	a90153f3 	stp	x19, x20, [sp, #16]
    4670:	aa0003f3 	mov	x19, x0
    4674:	ca404400 	eor	x0, x0, x0, lsr #17
    4678:	f90013f5 	str	x21, [sp, #32]
    467c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4680:	ca402400 	eor	x0, x0, x0, lsr #9
    4684:	911742a2 	add	x2, x21, #0x5d0
    4688:	92401c00 	and	x0, x0, #0xff
    468c:	910a2403 	add	x3, x0, #0x289
    4690:	8b000c40 	add	x0, x2, x0, lsl #3
    4694:	8b030c54 	add	x20, x2, x3, lsl #3
    4698:	f94a2401 	ldr	x1, [x0, #5192]
    469c:	b50000a1 	cbnz	x1, 46b0 <fwp_rc_wide_dup+0x4c>
    46a0:	14000033 	b	476c <fwp_rc_wide_dup+0x108>
    46a4:	91004034 	add	x20, x1, #0x10
    46a8:	f9400821 	ldr	x1, [x1, #16]
    46ac:	b4000241 	cbz	x1, 46f4 <fwp_rc_wide_dup+0x90>
    46b0:	f9400022 	ldr	x2, [x1]
    46b4:	eb02027f 	cmp	x19, x2
    46b8:	54ffff61 	b.ne	46a4 <fwp_rc_wide_dup+0x40>  // b.any
    46bc:	f9400281 	ldr	x1, [x20]
    46c0:	39400260 	ldrb	w0, [x19]
    46c4:	7103f81f 	cmp	w0, #0xfe
    46c8:	54000220 	b.eq	470c <fwp_rc_wide_dup+0xa8>  // b.none
    46cc:	b40001a1 	cbz	x1, 4700 <fwp_rc_wide_dup+0x9c>
    46d0:	f9400420 	ldr	x0, [x1, #8]
    46d4:	b100041f 	cmn	x0, #0x1
    46d8:	54000440 	b.eq	4760 <fwp_rc_wide_dup+0xfc>  // b.none
    46dc:	91000400 	add	x0, x0, #0x1
    46e0:	f9000420 	str	x0, [x1, #8]
    46e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e8:	f94013f5 	ldr	x21, [sp, #32]
    46ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f0:	d65f03c0 	ret
    46f4:	39400260 	ldrb	w0, [x19]
    46f8:	7103f81f 	cmp	w0, #0xfe
    46fc:	54000100 	b.eq	471c <fwp_rc_wide_dup+0xb8>  // b.none
    4700:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4704:	9102a000 	add	x0, x0, #0xa8
    4708:	97fffea2 	bl	4190 <fwp_trap>
    470c:	b4000081 	cbz	x1, 471c <fwp_rc_wide_dup+0xb8>
    4710:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4714:	91034000 	add	x0, x0, #0xd0
    4718:	97fffe9e 	bl	4190 <fwp_trap>
    471c:	d2800300 	mov	x0, #0x18                  	// #24
    4720:	97fff864 	bl	28b0 <malloc@plt>
    4724:	b4000280 	cbz	x0, 4774 <fwp_rc_wide_dup+0x110>
    4728:	d2801fe1 	mov	x1, #0xff                  	// #255
    472c:	a9000413 	stp	x19, x1, [x0]
    4730:	911742b5 	add	x21, x21, #0x5d0
    4734:	f900081f 	str	xzr, [x0, #16]
    4738:	12800001 	mov	w1, #0xffffffff            	// #-1
    473c:	f9000280 	str	x0, [x20]
    4740:	39000261 	strb	w1, [x19]
    4744:	f94e26a0 	ldr	x0, [x21, #7240]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f90e26a0 	str	x0, [x21, #7240]
    4754:	f94013f5 	ldr	x21, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4764:	9103e000 	add	x0, x0, #0xf8
    4768:	97fffe8a 	bl	4190 <fwp_trap>
    476c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4770:	17ffffd4 	b	46c0 <fwp_rc_wide_dup+0x5c>
    4774:	97fffa4f 	bl	30b0 <fwp_heap_oom>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_closure_drop_push>:
    4780:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	a9408014 	ldp	x20, x0, [x0, #8]
    4794:	a9025bf5 	stp	x21, x22, [sp, #32]
    4798:	aa0103f5 	mov	x21, x1
    479c:	a90363f7 	stp	x23, x24, [sp, #48]
    47a0:	eb00029f 	cmp	x20, x0
    47a4:	54000160 	b.eq	47d0 <fwp_closure_drop_push+0x50>  // b.none
    47a8:	f9400276 	ldr	x22, [x19]
    47ac:	d37df297 	lsl	x23, x20, #3
    47b0:	91000694 	add	x20, x20, #0x1
    47b4:	f9000674 	str	x20, [x19, #8]
    47b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47bc:	f8376ad5 	str	x21, [x22, x23]
    47c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47cc:	d65f03c0 	ret
    47d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    47d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    47d8:	eb00029f 	cmp	x20, x0
    47dc:	540003e8 	b.hi	4858 <fwp_closure_drop_push+0xd8>  // b.pmore
    47e0:	d37cee99 	lsl	x25, x20, #4
    47e4:	d37ffa9a 	lsl	x26, x20, #1
    47e8:	aa1903e0 	mov	x0, x25
    47ec:	97fff831 	bl	28b0 <malloc@plt>
    47f0:	aa0003f6 	mov	x22, x0
    47f4:	b4000380 	cbz	x0, 4864 <fwp_closure_drop_push+0xe4>
    47f8:	aa1303f8 	mov	x24, x19
    47fc:	aa1903e3 	mov	x3, x25
    4800:	d37df297 	lsl	x23, x20, #3
    4804:	aa1703e2 	mov	x2, x23
    4808:	f8418719 	ldr	x25, [x24], #24
    480c:	aa1903e1 	mov	x1, x25
    4810:	97fff814 	bl	2860 <__memcpy_chk@plt>
    4814:	eb18033f 	cmp	x25, x24
    4818:	540000a0 	b.eq	482c <fwp_closure_drop_push+0xac>  // b.none
    481c:	aa1903e0 	mov	x0, x25
    4820:	97fff86c 	bl	29d0 <free@plt>
    4824:	f9400674 	ldr	x20, [x19, #8]
    4828:	d37df297 	lsl	x23, x20, #3
    482c:	91000694 	add	x20, x20, #0x1
    4830:	f9000276 	str	x22, [x19]
    4834:	f9000a7a 	str	x26, [x19, #16]
    4838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    483c:	f9000674 	str	x20, [x19, #8]
    4840:	f8376ad5 	str	x21, [x22, x23]
    4844:	a94153f3 	ldp	x19, x20, [sp, #16]
    4848:	a9425bf5 	ldp	x21, x22, [sp, #32]
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4854:	d65f03c0 	ret
    4858:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    485c:	91046000 	add	x0, x0, #0x118
    4860:	97fffe4c 	bl	4190 <fwp_trap>
    4864:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4868:	f947e863 	ldr	x3, [x3, #4048]
    486c:	d2800262 	mov	x2, #0x13                  	// #19
    4870:	d2800021 	mov	x1, #0x1                   	// #1
    4874:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    4878:	913ae000 	add	x0, x0, #0xeb8
    487c:	f9400063 	ldr	x3, [x3]
    4880:	97fff864 	bl	2a10 <fwrite@plt>
    4884:	d2800000 	mov	x0, #0x0                   	// #0
    4888:	97fff86e 	bl	2a40 <fflush@plt>
    488c:	52800cc0 	mov	w0, #0x66                  	// #102
    4890:	97fff87c 	bl	2a80 <_Exit@plt>

0000000000004894 <fwp_closure_drop.part.0>:
    4894:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4898:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    489c:	910003fd 	mov	x29, sp
    48a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    48a4:	f947f463 	ldr	x3, [x3, #4072]
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	d10883ff 	sub	sp, sp, #0x220
    48b0:	910003e2 	mov	x2, sp
    48b4:	d53bd053 	mrs	x19, tpidr_el0
    48b8:	910063f4 	add	x20, sp, #0x18
    48bc:	3dc32820 	ldr	q0, [x1, #3232]
    48c0:	91400264 	add	x4, x19, #0x0, lsl #12
    48c4:	91004084 	add	x4, x4, #0x10
    48c8:	aa0003e1 	mov	x1, x0
    48cc:	aa0203e0 	mov	x0, x2
    48d0:	f9400062 	ldr	x2, [x3]
    48d4:	f9010fe2 	str	x2, [sp, #536]
    48d8:	d2800002 	mov	x2, #0x0                   	// #0
    48dc:	f90003f4 	str	x20, [sp]
    48e0:	f9000080 	str	x0, [x4]
    48e4:	3c8083e0 	stur	q0, [sp, #8]
    48e8:	97ffffa6 	bl	4780 <fwp_closure_drop_push>
    48ec:	f94007e0 	ldr	x0, [sp, #8]
    48f0:	b40002e0 	cbz	x0, 494c <fwp_closure_drop.part.0+0xb8>
    48f4:	f90123f5 	str	x21, [sp, #576]
    48f8:	900000f5 	adrp	x21, 20000 <__data_start>
    48fc:	9101c2b5 	add	x21, x21, #0x70
    4900:	14000006 	b	4918 <fwp_closure_drop.part.0+0x84>
    4904:	f9400422 	ldr	x2, [x1, #8]
    4908:	52800001 	mov	w1, #0x0                   	// #0
    490c:	d63f0040 	blr	x2
    4910:	f94007e0 	ldr	x0, [sp, #8]
    4914:	b40001a0 	cbz	x0, 4948 <fwp_closure_drop.part.0+0xb4>
    4918:	f94003e1 	ldr	x1, [sp]
    491c:	d1000400 	sub	x0, x0, #0x1
    4920:	f90007e0 	str	x0, [sp, #8]
    4924:	f94066a2 	ldr	x2, [x21, #200]
    4928:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    492c:	b9400001 	ldr	w1, [x0]
    4930:	8b011441 	add	x1, x2, x1, lsl #5
    4934:	f9400c21 	ldr	x1, [x1, #24]
    4938:	b5fffe61 	cbnz	x1, 4904 <fwp_closure_drop.part.0+0x70>
    493c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4940:	9104e000 	add	x0, x0, #0x138
    4944:	97fffe13 	bl	4190 <fwp_trap>
    4948:	f94123f5 	ldr	x21, [sp, #576]
    494c:	91400273 	add	x19, x19, #0x0, lsl #12
    4950:	91004273 	add	x19, x19, #0x10
    4954:	f94003e0 	ldr	x0, [sp]
    4958:	f900027f 	str	xzr, [x19]
    495c:	eb14001f 	cmp	x0, x20
    4960:	54000040 	b.eq	4968 <fwp_closure_drop.part.0+0xd4>  // b.none
    4964:	97fff81b 	bl	29d0 <free@plt>
    4968:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    496c:	f947f400 	ldr	x0, [x0, #4072]
    4970:	f9410fe2 	ldr	x2, [sp, #536]
    4974:	f9400001 	ldr	x1, [x0]
    4978:	eb010042 	subs	x2, x2, x1
    497c:	d2800001 	mov	x1, #0x0                   	// #0
    4980:	540000a1 	b.ne	4994 <fwp_closure_drop.part.0+0x100>  // b.any
    4984:	910883ff 	add	sp, sp, #0x220
    4988:	a94153f3 	ldp	x19, x20, [sp, #16]
    498c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4990:	d65f03c0 	ret
    4994:	f90123f5 	str	x21, [sp, #576]
    4998:	97fff7de 	bl	2910 <__stack_chk_fail@plt>
    499c:	d503201f 	nop

00000000000049a0 <fwp_tape_of>:
    49a0:	aa0003e1 	mov	x1, x0
    49a4:	92403c00 	and	x0, x0, #0xffff
    49a8:	b40000e0 	cbz	x0, 49c4 <fwp_tape_of+0x24>
    49ac:	d1000402 	sub	x2, x0, #0x1
    49b0:	900000e3 	adrp	x3, 20000 <__data_start>
    49b4:	9101c060 	add	x0, x3, #0x70
    49b8:	f9406800 	ldr	x0, [x0, #208]
    49bc:	eb02001f 	cmp	x0, x2
    49c0:	540000cc 	b.gt	49d8 <fwp_tape_of+0x38>
    49c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    49c8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    49cc:	9105a000 	add	x0, x0, #0x168
    49d0:	910003fd 	mov	x29, sp
    49d4:	97fffdef 	bl	4190 <fwp_trap>
    49d8:	8b020440 	add	x0, x2, x2, lsl #1
    49dc:	f9403863 	ldr	x3, [x3, #112]
    49e0:	8b000842 	add	x2, x2, x0, lsl #2
    49e4:	d37df042 	lsl	x2, x2, #3
    49e8:	8b020060 	add	x0, x3, x2
    49ec:	b9400404 	ldr	w4, [x0, #4]
    49f0:	34fffea4 	cbz	w4, 49c4 <fwp_tape_of+0x24>
    49f4:	b8626862 	ldr	w2, [x3, x2]
    49f8:	9350fc21 	asr	x1, x1, #16
    49fc:	6b01005f 	cmp	w2, w1
    4a00:	54fffe21 	b.ne	49c4 <fwp_tape_of+0x24>  // b.any
    4a04:	d65f03c0 	ret
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_now_ns>:
    4a10:	d100c3ff 	sub	sp, sp, #0x30
    4a14:	52800020 	mov	w0, #0x1                   	// #1
    4a18:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    4a1c:	f947f442 	ldr	x2, [x2, #4072]
    4a20:	910023e1 	add	x1, sp, #0x8
    4a24:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a28:	910083fd 	add	x29, sp, #0x20
    4a2c:	f9400043 	ldr	x3, [x2]
    4a30:	f9000fe3 	str	x3, [sp, #24]
    4a34:	d2800003 	mov	x3, #0x0                   	// #0
    4a38:	97fff782 	bl	2840 <clock_gettime@plt>
    4a3c:	350002c0 	cbnz	w0, 4a94 <fwp_now_ns+0x84>
    4a40:	a9408be1 	ldp	x1, x2, [sp, #8]
    4a44:	d2994003 	mov	x3, #0xca00                	// #51712
    4a48:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4a4c:	9b037c20 	mul	x0, x1, x3
    4a50:	9b437c21 	smulh	x1, x1, x3
    4a54:	ab020000 	adds	x0, x0, x2
    4a58:	937ffc42 	asr	x2, x2, #63
    4a5c:	9a020021 	adc	x1, x1, x2
    4a60:	f100001f 	cmp	x0, #0x0
    4a64:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4a68:	b50001c1 	cbnz	x1, 4aa0 <fwp_now_ns+0x90>
    4a6c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4a70:	f947f421 	ldr	x1, [x1, #4072]
    4a74:	f9400fe3 	ldr	x3, [sp, #24]
    4a78:	f9400022 	ldr	x2, [x1]
    4a7c:	eb020063 	subs	x3, x3, x2
    4a80:	d2800002 	mov	x2, #0x0                   	// #0
    4a84:	54000141 	b.ne	4aac <fwp_now_ns+0x9c>  // b.any
    4a88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a8c:	9100c3ff 	add	sp, sp, #0x30
    4a90:	d65f03c0 	ret
    4a94:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4a98:	9106e000 	add	x0, x0, #0x1b8
    4a9c:	97fffdbd 	bl	4190 <fwp_trap>
    4aa0:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4aa4:	91076000 	add	x0, x0, #0x1d8
    4aa8:	97fffdba 	bl	4190 <fwp_trap>
    4aac:	97fff799 	bl	2910 <__stack_chk_fail@plt>

0000000000004ab0 <fwp_poll_events>:
    4ab0:	d10103ff 	sub	sp, sp, #0x40
    4ab4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4ab8:	f947f400 	ldr	x0, [x0, #4072]
    4abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4ac0:	910083fd 	add	x29, sp, #0x20
    4ac4:	f9001bf3 	str	x19, [sp, #48]
    4ac8:	900000f3 	adrp	x19, 20000 <__data_start>
    4acc:	f9400001 	ldr	x1, [x0]
    4ad0:	f9000fe1 	str	x1, [sp, #24]
    4ad4:	d2800001 	mov	x1, #0x0                   	// #0
    4ad8:	97ffffce 	bl	4a10 <fwp_now_ns>
    4adc:	9101c261 	add	x1, x19, #0x70
    4ae0:	f9406c21 	ldr	x1, [x1, #216]
    4ae4:	b4000e01 	cbz	x1, 4ca4 <fwp_poll_events+0x1f4>
    4ae8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4aec:	14000005 	b	4b00 <fwp_poll_events+0x50>
    4af0:	f9408821 	ldr	x1, [x1, #272]
    4af4:	eb03005f 	cmp	x2, x3
    4af8:	9a83d042 	csel	x2, x2, x3, le
    4afc:	b40000c1 	cbz	x1, 4b14 <fwp_poll_events+0x64>
    4b00:	f9403423 	ldr	x3, [x1, #104]
    4b04:	b6ffff62 	tbz	x2, #63, 4af0 <fwp_poll_events+0x40>
    4b08:	f9408821 	ldr	x1, [x1, #272]
    4b0c:	aa0303e2 	mov	x2, x3
    4b10:	b5ffff81 	cbnz	x1, 4b00 <fwp_poll_events+0x50>
    4b14:	b7f80c82 	tbnz	x2, #63, 4ca4 <fwp_poll_events+0x1f4>
    4b18:	cb000042 	sub	x2, x2, x0
    4b1c:	f100005f 	cmp	x2, #0x0
    4b20:	540003ad 	b.le	4b94 <fwp_poll_events+0xe4>
    4b24:	d2869b60 	mov	x0, #0x34db                	// #13531
    4b28:	d2884804 	mov	x4, #0x4240                	// #16960
    4b2c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4b30:	f2a001e4 	movk	x4, #0xf, lsl #16
    4b34:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4b38:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4b3c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4b40:	9b407c40 	smulh	x0, x2, x0
    4b44:	9352fc00 	asr	x0, x0, #18
    4b48:	cb82fc00 	sub	x0, x0, x2, asr #63
    4b4c:	9b048802 	msub	x2, x0, x4, x2
    4b50:	f100005f 	cmp	x2, #0x0
    4b54:	9a800400 	cinc	x0, x0, ne	// ne = any
    4b58:	eb01001f 	cmp	x0, x1
    4b5c:	5400098c 	b.gt	4c8c <fwp_poll_events+0x1dc>
    4b60:	340001a0 	cbz	w0, 4b94 <fwp_poll_events+0xe4>
    4b64:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4b68:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4b6c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4b70:	9ba17c01 	umull	x1, w0, w1
    4b74:	d366fc23 	lsr	x3, x1, #38
    4b78:	aa0303e2 	mov	x2, x3
    4b7c:	1b058063 	msub	w3, w3, w5, w0
    4b80:	9b247c63 	smull	x3, w3, w4
    4b84:	910023e0 	add	x0, sp, #0x8
    4b88:	d2800001 	mov	x1, #0x0                   	// #0
    4b8c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b90:	97fff794 	bl	29e0 <nanosleep@plt>
    4b94:	97ffff9f 	bl	4a10 <fwp_now_ns>
    4b98:	9101c268 	add	x8, x19, #0x70
    4b9c:	aa0003e7 	mov	x7, x0
    4ba0:	4f000400 	movi	v0.4s, #0x0
    4ba4:	52800029 	mov	w9, #0x1                   	// #1
    4ba8:	f9406d06 	ldr	x6, [x8, #216]
    4bac:	d503201f 	nop
    4bb0:	b40003e6 	cbz	x6, 4c2c <fwp_poll_events+0x17c>
    4bb4:	f94034c1 	ldr	x1, [x6, #104]
    4bb8:	aa0603e5 	mov	x5, x6
    4bbc:	f94088c6 	ldr	x6, [x6, #272]
    4bc0:	eb07003f 	cmp	x1, x7
    4bc4:	54ffff6c 	b.gt	4bb0 <fwp_poll_events+0x100>
    4bc8:	394154a0 	ldrb	w0, [x5, #85]
    4bcc:	36000120 	tbz	w0, #0, 4bf0 <fwp_poll_events+0x140>
    4bd0:	f94084a0 	ldr	x0, [x5, #264]
    4bd4:	b4000560 	cbz	x0, 4c80 <fwp_poll_events+0x1d0>
    4bd8:	f9008806 	str	x6, [x0, #272]
    4bdc:	b4000046 	cbz	x6, 4be4 <fwp_poll_events+0x134>
    4be0:	f90084c0 	str	x0, [x6, #264]
    4be4:	910800a0 	add	x0, x5, #0x200
    4be8:	390154bf 	strb	wzr, [x5, #85]
    4bec:	3c908000 	stur	q0, [x0, #-248]
    4bf0:	f94030a0 	ldr	x0, [x5, #96]
    4bf4:	390158a9 	strb	w9, [x5, #86]
    4bf8:	f100001f 	cmp	x0, #0x0
    4bfc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4c00:	540002cd 	b.le	4c58 <fwp_poll_events+0x1a8>
    4c04:	f94028a0 	ldr	x0, [x5, #80]
    4c08:	f2001c1f 	tst	x0, #0xff000000ff
    4c0c:	54fffd21 	b.ne	4bb0 <fwp_poll_events+0x100>  // b.any
    4c10:	f9403d00 	ldr	x0, [x8, #120]
    4c14:	390150a9 	strb	w9, [x5, #84]
    4c18:	f90080bf 	str	xzr, [x5, #256]
    4c1c:	b40002c0 	cbz	x0, 4c74 <fwp_poll_events+0x1c4>
    4c20:	f9003d05 	str	x5, [x8, #120]
    4c24:	f9008005 	str	x5, [x0, #256]
    4c28:	b5fffc66 	cbnz	x6, 4bb4 <fwp_poll_events+0x104>
    4c2c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4c30:	f947f400 	ldr	x0, [x0, #4072]
    4c34:	f9400fe2 	ldr	x2, [sp, #24]
    4c38:	f9400001 	ldr	x1, [x0]
    4c3c:	eb010042 	subs	x2, x2, x1
    4c40:	d2800001 	mov	x1, #0x0                   	// #0
    4c44:	540002e1 	b.ne	4ca0 <fwp_poll_events+0x1f0>  // b.any
    4c48:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c4c:	f9401bf3 	ldr	x19, [sp, #48]
    4c50:	910103ff 	add	sp, sp, #0x40
    4c54:	d65f03c0 	ret
    4c58:	394144a0 	ldrb	w0, [x5, #81]
    4c5c:	3707fd40 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c60:	394140a0 	ldrb	w0, [x5, #80]
    4c64:	3707fd00 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c68:	aa0503e0 	mov	x0, x5
    4c6c:	97fffac1 	bl	3770 <fwp_cancel_tree.part.0>
    4c70:	17ffffe5 	b	4c04 <fwp_poll_events+0x154>
    4c74:	f9003d05 	str	x5, [x8, #120]
    4c78:	f9004105 	str	x5, [x8, #128]
    4c7c:	17ffffeb 	b	4c28 <fwp_poll_events+0x178>
    4c80:	9101c261 	add	x1, x19, #0x70
    4c84:	f9006c26 	str	x6, [x1, #216]
    4c88:	17ffffd5 	b	4bdc <fwp_poll_events+0x12c>
    4c8c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c90:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c94:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c98:	f2a00402 	movk	x2, #0x20, lsl #16
    4c9c:	17ffffba 	b	4b84 <fwp_poll_events+0xd4>
    4ca0:	97fff71c 	bl	2910 <__stack_chk_fail@plt>
    4ca4:	97fff8f3 	bl	3070 <fwp_flush>
    4ca8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4cac:	f947e863 	ldr	x3, [x3, #4048]
    4cb0:	d2800562 	mov	x2, #0x2b                  	// #43
    4cb4:	d2800021 	mov	x1, #0x1                   	// #1
    4cb8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    4cbc:	91080000 	add	x0, x0, #0x200
    4cc0:	f9400063 	ldr	x3, [x3]
    4cc4:	97fff753 	bl	2a10 <fwrite@plt>
    4cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    4ccc:	97fff6bd 	bl	27c0 <exit@plt>

0000000000004cd0 <fwp_heap_alloc_big>:
    4cd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd4:	910003fd 	mov	x29, sp
    4cd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce4:	aa0003f7 	mov	x23, x0
    4ce8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf0:	eb0002ff 	cmp	x23, x0
    4cf4:	540008a8 	b.hi	4e08 <fwp_heap_alloc_big+0x138>  // b.pmore
    4cf8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cfc:	8b0002f4 	add	x20, x23, x0
    4d00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d04:	91174359 	add	x25, x26, #0x5d0
    4d08:	d350fe94 	lsr	x20, x20, #16
    4d0c:	2a0103f5 	mov	w21, w1
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff987 	bl	3330 <fwp_heap_chunks>
    4d18:	f949ff22 	ldr	x2, [x25, #5112]
    4d1c:	8b000813 	add	x19, x0, x0, lsl #2
    4d20:	aa0003f8 	mov	x24, x0
    4d24:	52800043 	mov	w3, #0x2                   	// #2
    4d28:	d37df273 	lsl	x19, x19, #3
    4d2c:	d2800021 	mov	x1, #0x1                   	// #1
    4d30:	8b130040 	add	x0, x2, x19
    4d34:	38336843 	strb	w3, [x2, x19]
    4d38:	39000415 	strb	w21, [x0, #1]
    4d3c:	b9000c14 	str	w20, [x0, #12]
    4d40:	f9000817 	str	x23, [x0, #16]
    4d44:	97fffd57 	bl	42a0 <fwp_rc_prepare_chunk>
    4d48:	f100069f 	cmp	x20, #0x1
    4d4c:	54000289 	b.ls	4d9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4d50:	8b180294 	add	x20, x20, x24
    4d54:	9100a273 	add	x19, x19, #0x28
    4d58:	a90573fb 	stp	x27, x28, [sp, #80]
    4d5c:	5280007b 	mov	w27, #0x3                   	// #3
    4d60:	8b140a94 	add	x20, x20, x20, lsl #2
    4d64:	2a1803fc 	mov	w28, w24
    4d68:	9adb2296 	lsl	x22, x20, x27
    4d6c:	d503201f 	nop
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffd48 	bl	42a0 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0xa0>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x108>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffbbf 	bl	3df0 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff6f 	b	4cd0 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffd19 	bl	43c0 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_tape_reserve>:
    51a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51a8:	910003fd 	mov	x29, sp
    51ac:	a90153f3 	stp	x19, x20, [sp, #16]
    51b0:	aa0003f3 	mov	x19, x0
    51b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51b8:	eb00003f 	cmp	x1, x0
    51bc:	54000868 	b.hi	52c8 <fwp_tape_reserve+0x124>  // b.pmore
    51c0:	f9400e74 	ldr	x20, [x19, #24]
    51c4:	eb01029f 	cmp	x20, x1
    51c8:	5400076a 	b.ge	52b4 <fwp_tape_reserve+0x110>  // b.tcont
    51cc:	f100029f 	cmp	x20, #0x0
    51d0:	d2800802 	mov	x2, #0x40                  	// #64
    51d4:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    51d8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    51dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51e0:	a90363f7 	stp	x23, x24, [sp, #48]
    51e4:	eb01029f 	cmp	x20, x1
    51e8:	5400008a 	b.ge	51f8 <fwp_tape_reserve+0x54>  // b.tcont
    51ec:	eb00029f 	cmp	x20, x0
    51f0:	5400068d 	b.le	52c0 <fwp_tape_reserve+0x11c>
    51f4:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    51f8:	a940d662 	ldp	x2, x21, [x19, #8]
    51fc:	d37df297 	lsl	x23, x20, #3
    5200:	f9401260 	ldr	x0, [x19, #32]
    5204:	aa1703e1 	mov	x1, x23
    5208:	f9403276 	ldr	x22, [x19, #96]
    520c:	cb0202b5 	sub	x21, x21, x2
    5210:	97fff5bc 	bl	2900 <realloc@plt>
    5214:	b4000b00 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    5218:	f9400e61 	ldr	x1, [x19, #24]
    521c:	8b010801 	add	x1, x0, x1, lsl #2
    5220:	a9020660 	stp	x0, x1, [x19, #32]
    5224:	b40008b6 	cbz	x22, 5338 <fwp_tape_reserve+0x194>
    5228:	f94032d7 	ldr	x23, [x22, #96]
    522c:	eb17029f 	cmp	x20, x23
    5230:	5400034d 	b.le	5298 <fwp_tape_reserve+0xf4>
    5234:	a9046bf9 	stp	x25, x26, [sp, #64]
    5238:	d37cee9a 	lsl	x26, x20, #4
    523c:	aa1a03e0 	mov	x0, x26
    5240:	f94022d9 	ldr	x25, [x22, #64]
    5244:	52800041 	mov	w1, #0x2                   	// #2
    5248:	97ffff4a 	bl	4f70 <fwp_heap_alloc>
    524c:	aa0003f8 	mov	x24, x0
    5250:	b4000119 	cbz	x25, 5270 <fwp_tape_reserve+0xcc>
    5254:	d37ceef7 	lsl	x23, x23, #4
    5258:	aa1903e1 	mov	x1, x25
    525c:	eb1a02ff 	cmp	x23, x26
    5260:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    5264:	97fff53f 	bl	2760 <memcpy@plt>
    5268:	aa1903e0 	mov	x0, x25
    526c:	97fffc85 	bl	4480 <fwp_mem_free>
    5270:	f94032c0 	ldr	x0, [x22, #96]
    5274:	52800001 	mov	w1, #0x0                   	// #0
    5278:	cb000282 	sub	x2, x20, x0
    527c:	8b001300 	add	x0, x24, x0, lsl #4
    5280:	d37cec42 	lsl	x2, x2, #4
    5284:	97fff597 	bl	28e0 <memset@plt>
    5288:	f9401260 	ldr	x0, [x19, #32]
    528c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5290:	f90022d8 	str	x24, [x22, #64]
    5294:	f90032d4 	str	x20, [x22, #96]
    5298:	d37ef696 	lsl	x22, x20, #2
    529c:	b5000375 	cbnz	x21, 5308 <fwp_tape_reserve+0x164>
    52a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    52a4:	8b160000 	add	x0, x0, x22
    52a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52ac:	f9000e74 	str	x20, [x19, #24]
    52b0:	f9001660 	str	x0, [x19, #40]
    52b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52bc:	d65f03c0 	ret
    52c0:	d37ffa94 	lsl	x20, x20, #1
    52c4:	17ffffc8 	b	51e4 <fwp_tape_reserve+0x40>
    52c8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    52cc:	91096000 	add	x0, x0, #0x258
    52d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    52d4:	a90363f7 	stp	x23, x24, [sp, #48]
    52d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52dc:	97fffbad 	bl	4190 <fwp_trap>
    52e0:	eb1602ff 	cmp	x23, x22
    52e4:	aa0403e0 	mov	x0, x4
    52e8:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    52ec:	d37df2a2 	lsl	x2, x21, #3
    52f0:	cb170063 	sub	x3, x3, x23
    52f4:	97fff5ef 	bl	2ab0 <__memmove_chk@plt>
    52f8:	f9401a61 	ldr	x1, [x19, #48]
    52fc:	f9401260 	ldr	x0, [x19, #32]
    5300:	8b170021 	add	x1, x1, x23
    5304:	f9001e61 	str	x1, [x19, #56]
    5308:	f9401661 	ldr	x1, [x19, #40]
    530c:	d37ef696 	lsl	x22, x20, #2
    5310:	d37ef6a2 	lsl	x2, x21, #2
    5314:	8b160000 	add	x0, x0, x22
    5318:	97fff51a 	bl	2780 <memmove@plt>
    531c:	f9401260 	ldr	x0, [x19, #32]
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	8b160000 	add	x0, x0, x22
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000e74 	str	x20, [x19, #24]
    5330:	f9001660 	str	x0, [x19, #40]
    5334:	17ffffe0 	b	52b4 <fwp_tape_reserve+0x110>
    5338:	f9401a60 	ldr	x0, [x19, #48]
    533c:	d37cee96 	lsl	x22, x20, #4
    5340:	aa1603e1 	mov	x1, x22
    5344:	97fff56f 	bl	2900 <realloc@plt>
    5348:	b4000160 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    534c:	f9400e62 	ldr	x2, [x19, #24]
    5350:	f9001a60 	str	x0, [x19, #48]
    5354:	8b170004 	add	x4, x0, x23
    5358:	8b020c01 	add	x1, x0, x2, lsl #3
    535c:	f9001e61 	str	x1, [x19, #56]
    5360:	b5fffc15 	cbnz	x21, 52e0 <fwp_tape_reserve+0x13c>
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	d37ef696 	lsl	x22, x20, #2
    536c:	f9001e64 	str	x4, [x19, #56]
    5370:	17ffffcc 	b	52a0 <fwp_tape_reserve+0xfc>
    5374:	aa1303e0 	mov	x0, x19
    5378:	a9046bf9 	stp	x25, x26, [sp, #64]
    537c:	97fff725 	bl	3010 <fwp_tape_unlink_scope>
    5380:	f9401260 	ldr	x0, [x19, #32]
    5384:	97fff593 	bl	29d0 <free@plt>
    5388:	f9401a60 	ldr	x0, [x19, #48]
    538c:	97fff591 	bl	29d0 <free@plt>
    5390:	f9402260 	ldr	x0, [x19, #64]
    5394:	97fff58f 	bl	29d0 <free@plt>
    5398:	f9000e7f 	str	xzr, [x19, #24]
    539c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    53a0:	f947e821 	ldr	x1, [x1, #4048]
    53a4:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    53a8:	d2800262 	mov	x2, #0x13                  	// #19
    53ac:	4f000400 	movi	v0.4s, #0x0
    53b0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    53b4:	f9400023 	ldr	x3, [x1]
    53b8:	b900067f 	str	wzr, [x19, #4]
    53bc:	d2800021 	mov	x1, #0x1                   	// #1
    53c0:	913ae000 	add	x0, x0, #0xeb8
    53c4:	3c808260 	stur	q0, [x19, #8]
    53c8:	ad010260 	stp	q0, q0, [x19, #32]
    53cc:	97fff591 	bl	2a10 <fwrite@plt>
    53d0:	d2800000 	mov	x0, #0x0                   	// #0
    53d4:	97fff59b 	bl	2a40 <fflush@plt>
    53d8:	52800cc0 	mov	w0, #0x66                  	// #102
    53dc:	97fff5a9 	bl	2a80 <_Exit@plt>

00000000000053e0 <f141.constprop.0>:
    53e0:	f100001f 	cmp	x0, #0x0
    53e4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    53e8:	5400094b 	b.lt	5510 <f141.constprop.0+0x130>  // b.tstop
    53ec:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53f0:	aa0003e2 	mov	x2, x0
    53f4:	910003fd 	mov	x29, sp
    53f8:	a90153f3 	stp	x19, x20, [sp, #16]
    53fc:	aa0003f4 	mov	x20, x0
    5400:	aa010000 	orr	x0, x0, x1
    5404:	a9025bf5 	stp	x21, x22, [sp, #32]
    5408:	aa0103f6 	mov	x22, x1
    540c:	f9001bf7 	str	x23, [sp, #48]
    5410:	fd001fe8 	str	d8, [sp, #56]
    5414:	b7f80180 	tbnz	x0, #63, 5444 <f141.constprop.0+0x64>
    5418:	9360fc20 	asr	x0, x1, #32
    541c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5420:	eb82801f 	cmp	x0, x2, asr #32
    5424:	540007a1 	b.ne	5518 <f141.constprop.0+0x138>  // b.any
    5428:	97fffd5e 	bl	49a0 <fwp_tape_of>
    542c:	aa0003f3 	mov	x19, x0
    5430:	f9403000 	ldr	x0, [x0, #96]
    5434:	b40001e0 	cbz	x0, 5470 <f141.constprop.0+0x90>
    5438:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    543c:	910b0000 	add	x0, x0, #0x2c0
    5440:	97fffb54 	bl	4190 <fwp_trap>
    5444:	9360fc40 	asr	x0, x2, #32
    5448:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    544c:	b6fffee2 	tbz	x2, #63, 5428 <f141.constprop.0+0x48>
    5450:	2f00e408 	movi	d8, #0x0
    5454:	9360fc20 	asr	x0, x1, #32
    5458:	aa0103f4 	mov	x20, x1
    545c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5460:	97fffd50 	bl	49a0 <fwp_tape_of>
    5464:	aa0003f3 	mov	x19, x0
    5468:	f9403000 	ldr	x0, [x0, #96]
    546c:	b5fffe60 	cbnz	x0, 5438 <f141.constprop.0+0x58>
    5470:	f9400a77 	ldr	x23, [x19, #16]
    5474:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5478:	eb0002ff 	cmp	x23, x0
    547c:	5400044c 	b.gt	5504 <f141.constprop.0+0x124>
    5480:	eb3442ff 	cmp	x23, w20, uxtw
    5484:	5400008d 	b.le	5494 <f141.constprop.0+0xb4>
    5488:	b7f800d6 	tbnz	x22, #63, 54a0 <f141.constprop.0+0xc0>
    548c:	eb3642ff 	cmp	x23, w22, uxtw
    5490:	5400008c 	b.gt	54a0 <f141.constprop.0+0xc0>
    5494:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    5498:	910bc000 	add	x0, x0, #0x2f0
    549c:	97fffb3d 	bl	4190 <fwp_trap>
    54a0:	f9400675 	ldr	x21, [x19, #8]
    54a4:	aa1303e0 	mov	x0, x19
    54a8:	cb1502f5 	sub	x21, x23, x21
    54ac:	910006a1 	add	x1, x21, #0x1
    54b0:	97ffff3d 	bl	51a4 <fwp_tape_reserve>
    54b4:	a9420262 	ldp	x2, x0, [x19, #32]
    54b8:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54bc:	f9401a61 	ldr	x1, [x19, #48]
    54c0:	b8357854 	str	w20, [x2, x21, lsl #2]
    54c4:	f9401e62 	ldr	x2, [x19, #56]
    54c8:	f10002df 	cmp	x22, #0x0
    54cc:	fc357820 	str	d0, [x1, x21, lsl #3]
    54d0:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    54d4:	b8357816 	str	w22, [x0, x21, lsl #2]
    54d8:	92607e80 	and	x0, x20, #0xffffffff00000000
    54dc:	910006e1 	add	x1, x23, #0x1
    54e0:	aa170000 	orr	x0, x0, x23
    54e4:	fc357848 	str	d8, [x2, x21, lsl #3]
    54e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54ec:	f9401bf7 	ldr	x23, [sp, #48]
    54f0:	fd401fe8 	ldr	d8, [sp, #56]
    54f4:	f9000a61 	str	x1, [x19, #16]
    54f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    54fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5500:	d65f03c0 	ret
    5504:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    5508:	91096000 	add	x0, x0, #0x258
    550c:	97fffb21 	bl	4190 <fwp_trap>
    5510:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5514:	d65f03c0 	ret
    5518:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    551c:	9109e000 	add	x0, x0, #0x278
    5520:	97fffb1c 	bl	4190 <fwp_trap>

0000000000005524 <w120>:
    5524:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5528:	910003fd 	mov	x29, sp
    552c:	a90153f3 	stp	x19, x20, [sp, #16]
    5530:	a9025bf5 	stp	x21, x22, [sp, #32]
    5534:	aa0003f5 	mov	x21, x0
    5538:	a90363f7 	stp	x23, x24, [sp, #48]
    553c:	aa0103f7 	mov	x23, x1
    5540:	a9046bf9 	stp	x25, x26, [sp, #64]
    5544:	f9002bfb 	str	x27, [sp, #80]
    5548:	6d0627e8 	stp	d8, d9, [sp, #96]
    554c:	1e604028 	fmov	d8, d1
    5550:	1e600809 	fmul	d9, d0, d0
    5554:	6d072fea 	stp	d10, d11, [sp, #112]
    5558:	1e60400b 	fmov	d11, d0
    555c:	b7f81c80 	tbnz	x0, #63, 58ec <w120+0x3c8>
    5560:	9360fc19 	asr	x25, x0, #32
    5564:	aa1903e0 	mov	x0, x25
    5568:	97fffd0e 	bl	49a0 <fwp_tape_of>
    556c:	f9403001 	ldr	x1, [x0, #96]
    5570:	aa0003f3 	mov	x19, x0
    5574:	b4000081 	cbz	x1, 5584 <w120+0x60>
    5578:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    557c:	910b0000 	add	x0, x0, #0x2c0
    5580:	97fffb04 	bl	4190 <fwp_trap>
    5584:	f9400818 	ldr	x24, [x0, #16]
    5588:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    558c:	eb01031f 	cmp	x24, x1
    5590:	54001a8c 	b.gt	58e0 <w120+0x3bc>
    5594:	eb35431f 	cmp	x24, w21, uxtw
    5598:	540019ed 	b.le	58d4 <w120+0x3b0>
    559c:	f9400416 	ldr	x22, [x0, #8]
    55a0:	92607eb4 	and	x20, x21, #0xffffffff00000000
    55a4:	aa180294 	orr	x20, x20, x24
    55a8:	cb160316 	sub	x22, x24, x22
    55ac:	910006c1 	add	x1, x22, #0x1
    55b0:	97fffefd 	bl	51a4 <fwp_tape_reserve>
    55b4:	a9420a61 	ldp	x1, x2, [x19, #32]
    55b8:	91000700 	add	x0, x24, #0x1
    55bc:	f9401a63 	ldr	x3, [x19, #48]
    55c0:	b8367835 	str	w21, [x1, x22, lsl #2]
    55c4:	f9401e61 	ldr	x1, [x19, #56]
    55c8:	1e693908 	fsub	d8, d8, d9
    55cc:	fc36786b 	str	d11, [x3, x22, lsl #3]
    55d0:	9360fe9a 	asr	x26, x20, #32
    55d4:	b8367855 	str	w21, [x2, x22, lsl #2]
    55d8:	fc36782b 	str	d11, [x1, x22, lsl #3]
    55dc:	f9000a60 	str	x0, [x19, #16]
    55e0:	b7f80077 	tbnz	x23, #63, 55ec <w120+0xc8>
    55e4:	eb97835f 	cmp	x26, x23, asr #32
    55e8:	540019a1 	b.ne	591c <w120+0x3f8>  // b.any
    55ec:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    55f0:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    55f4:	eb19035f 	cmp	x26, x25
    55f8:	540000c0 	b.eq	5610 <w120+0xec>  // b.none
    55fc:	aa1a03e0 	mov	x0, x26
    5600:	97fffce8 	bl	49a0 <fwp_tape_of>
    5604:	aa0003f3 	mov	x19, x0
    5608:	f9403000 	ldr	x0, [x0, #96]
    560c:	b5fffb60 	cbnz	x0, 5578 <w120+0x54>
    5610:	f9400a79 	ldr	x25, [x19, #16]
    5614:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5618:	eb00033f 	cmp	x25, x0
    561c:	5400162c 	b.gt	58e0 <w120+0x3bc>
    5620:	eb34433f 	cmp	x25, w20, uxtw
    5624:	5400158d 	b.le	58d4 <w120+0x3b0>
    5628:	b7f80077 	tbnz	x23, #63, 5634 <w120+0x110>
    562c:	eb37433f 	cmp	x25, w23, uxtw
    5630:	5400152d 	b.le	58d4 <w120+0x3b0>
    5634:	f9400676 	ldr	x22, [x19, #8]
    5638:	aa1303e0 	mov	x0, x19
    563c:	cb160336 	sub	x22, x25, x22
    5640:	910006c1 	add	x1, x22, #0x1
    5644:	97fffed8 	bl	51a4 <fwp_tape_reserve>
    5648:	a9420e62 	ldp	x2, x3, [x19, #32]
    564c:	f10002ff 	cmp	x23, #0x0
    5650:	f9401a61 	ldr	x1, [x19, #48]
    5654:	b8367854 	str	w20, [x2, x22, lsl #2]
    5658:	f9401e62 	ldr	x2, [x19, #56]
    565c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5660:	fc367829 	str	d9, [x1, x22, lsl #3]
    5664:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5668:	b8367861 	str	w1, [x3, x22, lsl #2]
    566c:	91000737 	add	x23, x25, #0x1
    5670:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5674:	92607e94 	and	x20, x20, #0xffffffff00000000
    5678:	fc36784a 	str	d10, [x2, x22, lsl #3]
    567c:	aa190294 	orr	x20, x20, x25
    5680:	f9000a77 	str	x23, [x19, #16]
    5684:	1e6b3929 	fsub	d9, d9, d11
    5688:	b7f81675 	tbnz	x21, #63, 5954 <w120+0x430>
    568c:	9360febb 	asr	x27, x21, #32
    5690:	eb1a037f 	cmp	x27, x26
    5694:	540000e0 	b.eq	56b0 <w120+0x18c>  // b.none
    5698:	aa1b03e0 	mov	x0, x27
    569c:	97fffcc1 	bl	49a0 <fwp_tape_of>
    56a0:	aa0003f3 	mov	x19, x0
    56a4:	f9403000 	ldr	x0, [x0, #96]
    56a8:	b5fff680 	cbnz	x0, 5578 <w120+0x54>
    56ac:	f9400a77 	ldr	x23, [x19, #16]
    56b0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56b4:	eb0002ff 	cmp	x23, x0
    56b8:	5400114c 	b.gt	58e0 <w120+0x3bc>
    56bc:	eb3542ff 	cmp	x23, w21, uxtw
    56c0:	540010ad 	b.le	58d4 <w120+0x3b0>
    56c4:	f9400676 	ldr	x22, [x19, #8]
    56c8:	aa1303e0 	mov	x0, x19
    56cc:	cb1602f6 	sub	x22, x23, x22
    56d0:	910006c1 	add	x1, x22, #0x1
    56d4:	97fffeb4 	bl	51a4 <fwp_tape_reserve>
    56d8:	a9420261 	ldp	x1, x0, [x19, #32]
    56dc:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    56e0:	f9401a63 	ldr	x3, [x19, #48]
    56e4:	b8367835 	str	w21, [x1, x22, lsl #2]
    56e8:	f9401e61 	ldr	x1, [x19, #56]
    56ec:	12800002 	mov	w2, #0xffffffff            	// #-1
    56f0:	fc367860 	str	d0, [x3, x22, lsl #3]
    56f4:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56f8:	b8367802 	str	w2, [x0, x22, lsl #2]
    56fc:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5700:	910006e0 	add	x0, x23, #0x1
    5704:	aa1702b7 	orr	x23, x21, x23
    5708:	fc367820 	str	d0, [x1, x22, lsl #3]
    570c:	f9000a60 	str	x0, [x19, #16]
    5710:	9360fe99 	asr	x25, x20, #32
    5714:	1e68090a 	fmul	d10, d8, d8
    5718:	eb1b033f 	cmp	x25, x27
    571c:	540000c0 	b.eq	5734 <w120+0x210>  // b.none
    5720:	aa1903e0 	mov	x0, x25
    5724:	97fffc9f 	bl	49a0 <fwp_tape_of>
    5728:	aa0003f3 	mov	x19, x0
    572c:	f9403000 	ldr	x0, [x0, #96]
    5730:	b5fff240 	cbnz	x0, 5578 <w120+0x54>
    5734:	f9400a75 	ldr	x21, [x19, #16]
    5738:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    573c:	eb0002bf 	cmp	x21, x0
    5740:	54000d0c 	b.gt	58e0 <w120+0x3bc>
    5744:	eb3442bf 	cmp	x21, w20, uxtw
    5748:	54000c6d 	b.le	58d4 <w120+0x3b0>
    574c:	f9400678 	ldr	x24, [x19, #8]
    5750:	aa1303e0 	mov	x0, x19
    5754:	92607e96 	and	x22, x20, #0xffffffff00000000
    5758:	cb1802b8 	sub	x24, x21, x24
    575c:	aa1502d6 	orr	x22, x22, x21
    5760:	91000701 	add	x1, x24, #0x1
    5764:	97fffe90 	bl	51a4 <fwp_tape_reserve>
    5768:	a9420261 	ldp	x1, x0, [x19, #32]
    576c:	f9401a62 	ldr	x2, [x19, #48]
    5770:	b8387834 	str	w20, [x1, x24, lsl #2]
    5774:	f9401e61 	ldr	x1, [x19, #56]
    5778:	fc387848 	str	d8, [x2, x24, lsl #3]
    577c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5780:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5784:	9e670000 	fmov	d0, x0
    5788:	910006b4 	add	x20, x21, #0x1
    578c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5790:	9360fed8 	asr	x24, x22, #32
    5794:	f9000a74 	str	x20, [x19, #16]
    5798:	1e60094a 	fmul	d10, d10, d0
    579c:	eb19031f 	cmp	x24, x25
    57a0:	540000e0 	b.eq	57bc <w120+0x298>  // b.none
    57a4:	aa1803e0 	mov	x0, x24
    57a8:	97fffc7e 	bl	49a0 <fwp_tape_of>
    57ac:	aa0003f3 	mov	x19, x0
    57b0:	f9403000 	ldr	x0, [x0, #96]
    57b4:	b5ffee20 	cbnz	x0, 5578 <w120+0x54>
    57b8:	f9400a74 	ldr	x20, [x19, #16]
    57bc:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57c0:	eb00029f 	cmp	x20, x0
    57c4:	540008ec 	b.gt	58e0 <w120+0x3bc>
    57c8:	eb36429f 	cmp	x20, w22, uxtw
    57cc:	5400084d 	b.le	58d4 <w120+0x3b0>
    57d0:	f9400675 	ldr	x21, [x19, #8]
    57d4:	aa1303e0 	mov	x0, x19
    57d8:	cb150295 	sub	x21, x20, x21
    57dc:	910006a1 	add	x1, x21, #0x1
    57e0:	97fffe71 	bl	51a4 <fwp_tape_reserve>
    57e4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    57e8:	9e670000 	fmov	d0, x0
    57ec:	a9420261 	ldp	x1, x0, [x19, #32]
    57f0:	1e690928 	fmul	d8, d9, d9
    57f4:	f9401a62 	ldr	x2, [x19, #48]
    57f8:	b8357836 	str	w22, [x1, x21, lsl #2]
    57fc:	f9401e61 	ldr	x1, [x19, #56]
    5800:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5804:	fc357840 	str	d0, [x2, x21, lsl #3]
    5808:	12800002 	mov	w2, #0xffffffff            	// #-1
    580c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5810:	91000680 	add	x0, x20, #0x1
    5814:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5818:	aa1402d6 	orr	x22, x22, x20
    581c:	f9000a60 	str	x0, [x19, #16]
    5820:	b10006ff 	cmn	x23, #0x1
    5824:	540009e0 	b.eq	5960 <w120+0x43c>  // b.none
    5828:	9360fee0 	asr	x0, x23, #32
    582c:	eb18001f 	cmp	x0, x24
    5830:	540000a0 	b.eq	5844 <w120+0x320>  // b.none
    5834:	97fffc5b 	bl	49a0 <fwp_tape_of>
    5838:	aa0003f3 	mov	x19, x0
    583c:	f9403000 	ldr	x0, [x0, #96]
    5840:	b5ffe9c0 	cbnz	x0, 5578 <w120+0x54>
    5844:	f9400a74 	ldr	x20, [x19, #16]
    5848:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    584c:	eb00029f 	cmp	x20, x0
    5850:	5400048c 	b.gt	58e0 <w120+0x3bc>
    5854:	eb37429f 	cmp	x20, w23, uxtw
    5858:	540003ed 	b.le	58d4 <w120+0x3b0>
    585c:	f9400675 	ldr	x21, [x19, #8]
    5860:	aa1303e0 	mov	x0, x19
    5864:	cb150295 	sub	x21, x20, x21
    5868:	910006a1 	add	x1, x21, #0x1
    586c:	97fffe4e 	bl	51a4 <fwp_tape_reserve>
    5870:	a9420a61 	ldp	x1, x2, [x19, #32]
    5874:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5878:	f9401a63 	ldr	x3, [x19, #48]
    587c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5880:	f9401e61 	ldr	x1, [x19, #56]
    5884:	aa140000 	orr	x0, x0, x20
    5888:	fc357869 	str	d9, [x3, x21, lsl #3]
    588c:	91000694 	add	x20, x20, #0x1
    5890:	b8357857 	str	w23, [x2, x21, lsl #2]
    5894:	fc357829 	str	d9, [x1, x21, lsl #3]
    5898:	f9000a74 	str	x20, [x19, #16]
    589c:	1e6a2908 	fadd	d8, d8, d10
    58a0:	aa1603e1 	mov	x1, x22
    58a4:	97fffecf 	bl	53e0 <f141.constprop.0>
    58a8:	aa0003e1 	mov	x1, x0
    58ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    58b0:	9e660100 	fmov	x0, d8
    58b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    58bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    58c0:	f9402bfb 	ldr	x27, [sp, #80]
    58c4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    58c8:	6d472fea 	ldp	d10, d11, [sp, #112]
    58cc:	a8c87bfd 	ldp	x29, x30, [sp], #128
    58d0:	d65f03c0 	ret
    58d4:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    58d8:	910bc000 	add	x0, x0, #0x2f0
    58dc:	97fffa2d 	bl	4190 <fwp_trap>
    58e0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    58e4:	91096000 	add	x0, x0, #0x258
    58e8:	97fffa2a 	bl	4190 <fwp_trap>
    58ec:	1e693828 	fsub	d8, d1, d9
    58f0:	b6f801c1 	tbz	x1, #63, 5928 <w120+0x404>
    58f4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    58f8:	1e68090a 	fmul	d10, d8, d8
    58fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5900:	9e670000 	fmov	d0, x0
    5904:	1e6b3828 	fsub	d8, d1, d11
    5908:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    590c:	aa1603e0 	mov	x0, x22
    5910:	1e60094a 	fmul	d10, d10, d0
    5914:	1e680908 	fmul	d8, d8, d8
    5918:	17ffffe1 	b	589c <w120+0x378>
    591c:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    5920:	9109e000 	add	x0, x0, #0x278
    5924:	97fffa1b 	bl	4190 <fwp_trap>
    5928:	2f00e40a 	movi	d10, #0x0
    592c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5930:	9360fc3a 	asr	x26, x1, #32
    5934:	aa0103f4 	mov	x20, x1
    5938:	aa1a03e0 	mov	x0, x26
    593c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5940:	97fffc18 	bl	49a0 <fwp_tape_of>
    5944:	aa0003f3 	mov	x19, x0
    5948:	f9403000 	ldr	x0, [x0, #96]
    594c:	b5ffe160 	cbnz	x0, 5578 <w120+0x54>
    5950:	17ffff30 	b	5610 <w120+0xec>
    5954:	aa1a03fb 	mov	x27, x26
    5958:	aa0003f7 	mov	x23, x0
    595c:	17ffff6d 	b	5710 <w120+0x1ec>
    5960:	aa1703e0 	mov	x0, x23
    5964:	17ffffce 	b	589c <w120+0x378>
    5968:	d503201f 	nop
    596c:	d503201f 	nop

0000000000005970 <fwp_rc_share>:
    5970:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5974:	91174042 	add	x2, x2, #0x5d0
    5978:	f949d843 	ldr	x3, [x2, #5040]
    597c:	f949ec41 	ldr	x1, [x2, #5080]
    5980:	cb030000 	sub	x0, x0, x3
    5984:	eb01401f 	cmp	x0, x1, lsl #16
    5988:	540003a2 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    598c:	d350fc01 	lsr	x1, x0, #16
    5990:	f949fc44 	ldr	x4, [x2, #5112]
    5994:	8b010821 	add	x1, x1, x1, lsl #2
    5998:	d37df021 	lsl	x1, x1, #3
    599c:	8b010083 	add	x3, x4, x1
    59a0:	f9401062 	ldr	x2, [x3, #32]
    59a4:	b40002c2 	cbz	x2, 59fc <fwp_rc_share+0x8c>
    59a8:	38616881 	ldrb	w1, [x4, x1]
    59ac:	7100083f 	cmp	w1, #0x2
    59b0:	54000220 	b.eq	59f4 <fwp_rc_share+0x84>  // b.none
    59b4:	7100043f 	cmp	w1, #0x1
    59b8:	54000221 	b.ne	59fc <fwp_rc_share+0x8c>  // b.any
    59bc:	29430464 	ldp	w4, w1, [x3, #24]
    59c0:	92403c00 	and	x0, x0, #0xffff
    59c4:	9b047c00 	mul	x0, x0, x4
    59c8:	d360fc00 	lsr	x0, x0, #32
    59cc:	eb01001f 	cmp	x0, x1
    59d0:	54000162 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    59d4:	8b000042 	add	x2, x2, x0
    59d8:	39400040 	ldrb	w0, [x2]
    59dc:	34000100 	cbz	w0, 59fc <fwp_rc_share+0x8c>
    59e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    59e4:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    59e8:	910c4000 	add	x0, x0, #0x310
    59ec:	910003fd 	mov	x29, sp
    59f0:	97fff9e8 	bl	4190 <fwp_trap>
    59f4:	72003c1f 	tst	w0, #0xffff
    59f8:	54ffff00 	b.eq	59d8 <fwp_rc_share+0x68>  // b.none
    59fc:	d65f03c0 	ret

0000000000005a00 <fwp_rc_free_arr>:
    5a00:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a04:	91174063 	add	x3, x3, #0x5d0
    5a08:	f949d861 	ldr	x1, [x3, #5040]
    5a0c:	f949ec62 	ldr	x2, [x3, #5080]
    5a10:	cb010001 	sub	x1, x0, x1
    5a14:	eb02403f 	cmp	x1, x2, lsl #16
    5a18:	54000342 	b.cs	5a80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a1c:	d350fc22 	lsr	x2, x1, #16
    5a20:	f949fc65 	ldr	x5, [x3, #5112]
    5a24:	8b020842 	add	x2, x2, x2, lsl #2
    5a28:	d37df042 	lsl	x2, x2, #3
    5a2c:	8b0200a4 	add	x4, x5, x2
    5a30:	f9401083 	ldr	x3, [x4, #32]
    5a34:	b4000263 	cbz	x3, 5a80 <fwp_rc_free_arr+0x80>
    5a38:	386268a2 	ldrb	w2, [x5, x2]
    5a3c:	7100085f 	cmp	w2, #0x2
    5a40:	540001c0 	b.eq	5a78 <fwp_rc_free_arr+0x78>  // b.none
    5a44:	7100045f 	cmp	w2, #0x1
    5a48:	540001c1 	b.ne	5a80 <fwp_rc_free_arr+0x80>  // b.any
    5a4c:	29430885 	ldp	w5, w2, [x4, #24]
    5a50:	92403c21 	and	x1, x1, #0xffff
    5a54:	9b057c21 	mul	x1, x1, x5
    5a58:	d360fc21 	lsr	x1, x1, #32
    5a5c:	eb02003f 	cmp	x1, x2
    5a60:	54000102 	b.cs	5a80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a64:	8b010063 	add	x3, x3, x1
    5a68:	39400061 	ldrb	w1, [x3]
    5a6c:	7100043f 	cmp	w1, #0x1
    5a70:	54000081 	b.ne	5a80 <fwp_rc_free_arr+0x80>  // b.any
    5a74:	17fffa83 	b	4480 <fwp_mem_free>
    5a78:	72003c3f 	tst	w1, #0xffff
    5a7c:	54ffff60 	b.eq	5a68 <fwp_rc_free_arr+0x68>  // b.none
    5a80:	d65f03c0 	ret

0000000000005a84 <fwp_rc_dup>:
    5a84:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5a88:	91174042 	add	x2, x2, #0x5d0
    5a8c:	f949d841 	ldr	x1, [x2, #5040]
    5a90:	f949ec43 	ldr	x3, [x2, #5080]
    5a94:	cb010001 	sub	x1, x0, x1
    5a98:	eb03403f 	cmp	x1, x3, lsl #16
    5a9c:	54000342 	b.cs	5b04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5aa0:	d350fc20 	lsr	x0, x1, #16
    5aa4:	f949fc44 	ldr	x4, [x2, #5112]
    5aa8:	8b000800 	add	x0, x0, x0, lsl #2
    5aac:	d37df002 	lsl	x2, x0, #3
    5ab0:	8b020083 	add	x3, x4, x2
    5ab4:	f9401060 	ldr	x0, [x3, #32]
    5ab8:	b4000260 	cbz	x0, 5b04 <fwp_rc_dup+0x80>
    5abc:	38626882 	ldrb	w2, [x4, x2]
    5ac0:	7100085f 	cmp	w2, #0x2
    5ac4:	54000220 	b.eq	5b08 <fwp_rc_dup+0x84>  // b.none
    5ac8:	7100045f 	cmp	w2, #0x1
    5acc:	540001c1 	b.ne	5b04 <fwp_rc_dup+0x80>  // b.any
    5ad0:	29430864 	ldp	w4, w2, [x3, #24]
    5ad4:	92403c21 	and	x1, x1, #0xffff
    5ad8:	9b047c21 	mul	x1, x1, x4
    5adc:	d360fc21 	lsr	x1, x1, #32
    5ae0:	eb02003f 	cmp	x1, x2
    5ae4:	54000102 	b.cs	5b04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ae8:	8b010000 	add	x0, x0, x1
    5aec:	39400001 	ldrb	w1, [x0]
    5af0:	340000a1 	cbz	w1, 5b04 <fwp_rc_dup+0x80>
    5af4:	7103f43f 	cmp	w1, #0xfd
    5af8:	540000e8 	b.hi	5b14 <fwp_rc_dup+0x90>  // b.pmore
    5afc:	11000421 	add	w1, w1, #0x1
    5b00:	39000001 	strb	w1, [x0]
    5b04:	d65f03c0 	ret
    5b08:	72003c3f 	tst	w1, #0xffff
    5b0c:	54ffff00 	b.eq	5aec <fwp_rc_dup+0x68>  // b.none
    5b10:	d65f03c0 	ret
    5b14:	17fffad4 	b	4664 <fwp_rc_wide_dup>
    5b18:	d503201f 	nop
    5b1c:	d503201f 	nop

0000000000005b20 <fwp_owned_entry173>:
    5b20:	d10103ff 	sub	sp, sp, #0x40
    5b24:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5b28:	f947f442 	ldr	x2, [x2, #4072]
    5b2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b30:	910083fd 	add	x29, sp, #0x20
    5b34:	a90353f3 	stp	x19, x20, [sp, #48]
    5b38:	f9400043 	ldr	x3, [x2]
    5b3c:	f9000fe3 	str	x3, [sp, #24]
    5b40:	d2800003 	mov	x3, #0x0                   	// #0
    5b44:	a9400c01 	ldp	x1, x3, [x0]
    5b48:	f9400802 	ldr	x2, [x0, #16]
    5b4c:	ab020022 	adds	x2, x1, x2
    5b50:	540006e6 	b.vs	5c2c <fwp_owned_entry173+0x10c>
    5b54:	910023e1 	add	x1, sp, #0x8
    5b58:	52800000 	mov	w0, #0x0                   	// #0
    5b5c:	a9008be3 	stp	x3, x2, [sp, #8]
    5b60:	97fffd49 	bl	5084 <fwp_data.part.0.constprop.0>
    5b64:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5b68:	91174063 	add	x3, x3, #0x5d0
    5b6c:	aa0003f3 	mov	x19, x0
    5b70:	f949d861 	ldr	x1, [x3, #5040]
    5b74:	f949ec60 	ldr	x0, [x3, #5080]
    5b78:	cb010261 	sub	x1, x19, x1
    5b7c:	eb00403f 	cmp	x1, x0, lsl #16
    5b80:	54000322 	b.cs	5be4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b84:	d350fc22 	lsr	x2, x1, #16
    5b88:	f949fc63 	ldr	x3, [x3, #5112]
    5b8c:	8b020842 	add	x2, x2, x2, lsl #2
    5b90:	d37df042 	lsl	x2, x2, #3
    5b94:	8b020060 	add	x0, x3, x2
    5b98:	f9401014 	ldr	x20, [x0, #32]
    5b9c:	b4000254 	cbz	x20, 5be4 <fwp_owned_entry173+0xc4>
    5ba0:	38626862 	ldrb	w2, [x3, x2]
    5ba4:	7100085f 	cmp	w2, #0x2
    5ba8:	54000360 	b.eq	5c14 <fwp_owned_entry173+0xf4>  // b.none
    5bac:	7100045f 	cmp	w2, #0x1
    5bb0:	540001a1 	b.ne	5be4 <fwp_owned_entry173+0xc4>  // b.any
    5bb4:	29430002 	ldp	w2, w0, [x0, #24]
    5bb8:	92403c21 	and	x1, x1, #0xffff
    5bbc:	9b027c21 	mul	x1, x1, x2
    5bc0:	d360fc21 	lsr	x1, x1, #32
    5bc4:	eb00003f 	cmp	x1, x0
    5bc8:	540000e2 	b.cs	5be4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5bcc:	8b010294 	add	x20, x20, x1
    5bd0:	39400280 	ldrb	w0, [x20]
    5bd4:	7103fc1f 	cmp	w0, #0xff
    5bd8:	54000240 	b.eq	5c20 <fwp_owned_entry173+0x100>  // b.none
    5bdc:	52800020 	mov	w0, #0x1                   	// #1
    5be0:	39000280 	strb	w0, [x20]
    5be4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5be8:	f947f400 	ldr	x0, [x0, #4072]
    5bec:	f9400fe2 	ldr	x2, [sp, #24]
    5bf0:	f9400001 	ldr	x1, [x0]
    5bf4:	eb010042 	subs	x2, x2, x1
    5bf8:	d2800001 	mov	x1, #0x0                   	// #0
    5bfc:	540001a1 	b.ne	5c30 <fwp_owned_entry173+0x110>  // b.any
    5c00:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c04:	aa1303e0 	mov	x0, x19
    5c08:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c0c:	910103ff 	add	sp, sp, #0x40
    5c10:	d65f03c0 	ret
    5c14:	72003c3f 	tst	w1, #0xffff
    5c18:	54fffe61 	b.ne	5be4 <fwp_owned_entry173+0xc4>  // b.any
    5c1c:	17ffffed 	b	5bd0 <fwp_owned_entry173+0xb0>
    5c20:	aa1403e0 	mov	x0, x20
    5c24:	97fff97b 	bl	4210 <fwp_rc_forget_slot.part.0>
    5c28:	17ffffed 	b	5bdc <fwp_owned_entry173+0xbc>
    5c2c:	97fff3b5 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5c30:	97fff338 	bl	2910 <__stack_chk_fail@plt>

0000000000005c34 <e173>:
    5c34:	d10103ff 	sub	sp, sp, #0x40
    5c38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5c3c:	f947f442 	ldr	x2, [x2, #4072]
    5c40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c44:	910083fd 	add	x29, sp, #0x20
    5c48:	a90353f3 	stp	x19, x20, [sp, #48]
    5c4c:	f9400043 	ldr	x3, [x2]
    5c50:	f9000fe3 	str	x3, [sp, #24]
    5c54:	d2800003 	mov	x3, #0x0                   	// #0
    5c58:	a9400c01 	ldp	x1, x3, [x0]
    5c5c:	f9400802 	ldr	x2, [x0, #16]
    5c60:	ab020022 	adds	x2, x1, x2
    5c64:	54000726 	b.vs	5d48 <e173+0x114>
    5c68:	910023e1 	add	x1, sp, #0x8
    5c6c:	52800000 	mov	w0, #0x0                   	// #0
    5c70:	a9008be3 	stp	x3, x2, [sp, #8]
    5c74:	97fffd04 	bl	5084 <fwp_data.part.0.constprop.0>
    5c78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5c7c:	91174063 	add	x3, x3, #0x5d0
    5c80:	aa0003f3 	mov	x19, x0
    5c84:	f949d861 	ldr	x1, [x3, #5040]
    5c88:	f949ec60 	ldr	x0, [x3, #5080]
    5c8c:	cb010261 	sub	x1, x19, x1
    5c90:	eb00403f 	cmp	x1, x0, lsl #16
    5c94:	54000322 	b.cs	5cf8 <e173+0xc4>  // b.hs, b.nlast
    5c98:	d350fc22 	lsr	x2, x1, #16
    5c9c:	f949fc63 	ldr	x3, [x3, #5112]
    5ca0:	8b020842 	add	x2, x2, x2, lsl #2
    5ca4:	d37df042 	lsl	x2, x2, #3
    5ca8:	8b020060 	add	x0, x3, x2
    5cac:	f9401014 	ldr	x20, [x0, #32]
    5cb0:	b4000254 	cbz	x20, 5cf8 <e173+0xc4>
    5cb4:	38626862 	ldrb	w2, [x3, x2]
    5cb8:	7100085f 	cmp	w2, #0x2
    5cbc:	540003a0 	b.eq	5d30 <e173+0xfc>  // b.none
    5cc0:	7100045f 	cmp	w2, #0x1
    5cc4:	540001a1 	b.ne	5cf8 <e173+0xc4>  // b.any
    5cc8:	29430002 	ldp	w2, w0, [x0, #24]
    5ccc:	92403c21 	and	x1, x1, #0xffff
    5cd0:	9b027c21 	mul	x1, x1, x2
    5cd4:	d360fc21 	lsr	x1, x1, #32
    5cd8:	eb00003f 	cmp	x1, x0
    5cdc:	540000e2 	b.cs	5cf8 <e173+0xc4>  // b.hs, b.nlast
    5ce0:	8b010294 	add	x20, x20, x1
    5ce4:	39400280 	ldrb	w0, [x20]
    5ce8:	7103fc1f 	cmp	w0, #0xff
    5cec:	54000280 	b.eq	5d3c <e173+0x108>  // b.none
    5cf0:	52800020 	mov	w0, #0x1                   	// #1
    5cf4:	39000280 	strb	w0, [x20]
    5cf8:	aa1303e0 	mov	x0, x19
    5cfc:	97ffff1d 	bl	5970 <fwp_rc_share>
    5d00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d04:	f947f400 	ldr	x0, [x0, #4072]
    5d08:	f9400fe2 	ldr	x2, [sp, #24]
    5d0c:	f9400001 	ldr	x1, [x0]
    5d10:	eb010042 	subs	x2, x2, x1
    5d14:	d2800001 	mov	x1, #0x0                   	// #0
    5d18:	540001a1 	b.ne	5d4c <e173+0x118>  // b.any
    5d1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d20:	aa1303e0 	mov	x0, x19
    5d24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d28:	910103ff 	add	sp, sp, #0x40
    5d2c:	d65f03c0 	ret
    5d30:	72003c3f 	tst	w1, #0xffff
    5d34:	54fffe21 	b.ne	5cf8 <e173+0xc4>  // b.any
    5d38:	17ffffeb 	b	5ce4 <e173+0xb0>
    5d3c:	aa1403e0 	mov	x0, x20
    5d40:	97fff934 	bl	4210 <fwp_rc_forget_slot.part.0>
    5d44:	17ffffeb 	b	5cf0 <e173+0xbc>
    5d48:	97fff36e 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5d4c:	97fff2f1 	bl	2910 <__stack_chk_fail@plt>

0000000000005d50 <fwp_drop1>:
    5d50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d54:	910003fd 	mov	x29, sp
    5d58:	a90153f3 	stp	x19, x20, [sp, #16]
    5d5c:	f90013f5 	str	x21, [sp, #32]
    5d60:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5d64:	911742b4 	add	x20, x21, #0x5d0
    5d68:	f949da81 	ldr	x1, [x20, #5040]
    5d6c:	f949ee82 	ldr	x2, [x20, #5080]
    5d70:	cb010001 	sub	x1, x0, x1
    5d74:	eb02403f 	cmp	x1, x2, lsl #16
    5d78:	54000382 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d7c:	d350fc22 	lsr	x2, x1, #16
    5d80:	f949fe84 	ldr	x4, [x20, #5112]
    5d84:	8b020842 	add	x2, x2, x2, lsl #2
    5d88:	d37df042 	lsl	x2, x2, #3
    5d8c:	8b020083 	add	x3, x4, x2
    5d90:	f9401073 	ldr	x19, [x3, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_drop1+0x98>
    5d98:	38626882 	ldrb	w2, [x4, x2]
    5d9c:	7100085f 	cmp	w2, #0x2
    5da0:	540002c0 	b.eq	5df8 <fwp_drop1+0xa8>  // b.none
    5da4:	7100045f 	cmp	w2, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5dac:	29430864 	ldp	w4, w2, [x3, #24]
    5db0:	92403c21 	and	x1, x1, #0xffff
    5db4:	9b047c21 	mul	x1, x1, x4
    5db8:	d360fc21 	lsr	x1, x1, #32
    5dbc:	eb02003f 	cmp	x1, x2
    5dc0:	54000142 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dc4:	8b010273 	add	x19, x19, x1
    5dc8:	39400261 	ldrb	w1, [x19]
    5dcc:	340000e1 	cbz	w1, 5de8 <fwp_drop1+0x98>
    5dd0:	7100043f 	cmp	w1, #0x1
    5dd4:	540001e0 	b.eq	5e10 <fwp_drop1+0xc0>  // b.none
    5dd8:	7103fc3f 	cmp	w1, #0xff
    5ddc:	540002e0 	b.eq	5e38 <fwp_drop1+0xe8>  // b.none
    5de0:	51000421 	sub	w1, w1, #0x1
    5de4:	39000261 	strb	w1, [x19]
    5de8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dec:	f94013f5 	ldr	x21, [sp, #32]
    5df0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5df4:	d65f03c0 	ret
    5df8:	72003c3f 	tst	w1, #0xffff
    5dfc:	54fffe60 	b.eq	5dc8 <fwp_drop1+0x78>  // b.none
    5e00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e04:	f94013f5 	ldr	x21, [sp, #32]
    5e08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e0c:	d65f03c0 	ret
    5e10:	f9400813 	ldr	x19, [x0, #16]
    5e14:	97fffefb 	bl	5a00 <fwp_rc_free_arr>
    5e18:	911742a0 	add	x0, x21, #0x5d0
    5e1c:	f949d801 	ldr	x1, [x0, #5040]
    5e20:	f949ec00 	ldr	x0, [x0, #5080]
    5e24:	cb010261 	sub	x1, x19, x1
    5e28:	eb00403f 	cmp	x1, x0, lsl #16
    5e2c:	54fffde2 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e30:	aa1303e0 	mov	x0, x19
    5e34:	17ffffd2 	b	5d7c <fwp_drop1+0x2c>
    5e38:	ca534660 	eor	x0, x19, x19, lsr #17
    5e3c:	911742b5 	add	x21, x21, #0x5d0
    5e40:	ca402400 	eor	x0, x0, x0, lsr #9
    5e44:	92401c00 	and	x0, x0, #0xff
    5e48:	910a2402 	add	x2, x0, #0x289
    5e4c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e50:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e54:	f94a2400 	ldr	x0, [x0, #5192]
    5e58:	b50000a0 	cbnz	x0, 5e6c <fwp_drop1+0x11c>
    5e5c:	14000013 	b	5ea8 <fwp_drop1+0x158>
    5e60:	91004002 	add	x2, x0, #0x10
    5e64:	f9400800 	ldr	x0, [x0, #16]
    5e68:	b4000200 	cbz	x0, 5ea8 <fwp_drop1+0x158>
    5e6c:	f9400001 	ldr	x1, [x0]
    5e70:	eb13003f 	cmp	x1, x19
    5e74:	54ffff61 	b.ne	5e60 <fwp_drop1+0x110>  // b.any
    5e78:	f9400041 	ldr	x1, [x2]
    5e7c:	f9400420 	ldr	x0, [x1, #8]
    5e80:	d1000400 	sub	x0, x0, #0x1
    5e84:	f9000420 	str	x0, [x1, #8]
    5e88:	f103f81f 	cmp	x0, #0xfe
    5e8c:	54fffae1 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5e90:	39400260 	ldrb	w0, [x19]
    5e94:	7103fc1f 	cmp	w0, #0xff
    5e98:	540000e0 	b.eq	5eb4 <fwp_drop1+0x164>  // b.none
    5e9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ea0:	39000260 	strb	w0, [x19]
    5ea4:	17ffffd1 	b	5de8 <fwp_drop1+0x98>
    5ea8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    5eac:	9102a000 	add	x0, x0, #0xa8
    5eb0:	97fff8b8 	bl	4190 <fwp_trap>
    5eb4:	aa1303e0 	mov	x0, x19
    5eb8:	97fff8d6 	bl	4210 <fwp_rc_forget_slot.part.0>
    5ebc:	17fffff8 	b	5e9c <fwp_drop1+0x14c>

0000000000005ec0 <fwp_drop0>:
    5ec0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ec4:	910003fd 	mov	x29, sp
    5ec8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ecc:	f90013f5 	str	x21, [sp, #32]
    5ed0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5ed4:	911742b4 	add	x20, x21, #0x5d0
    5ed8:	f949da81 	ldr	x1, [x20, #5040]
    5edc:	f949ee82 	ldr	x2, [x20, #5080]
    5ee0:	cb010001 	sub	x1, x0, x1
    5ee4:	eb02403f 	cmp	x1, x2, lsl #16
    5ee8:	54000382 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5eec:	d350fc22 	lsr	x2, x1, #16
    5ef0:	f949fe84 	ldr	x4, [x20, #5112]
    5ef4:	8b020842 	add	x2, x2, x2, lsl #2
    5ef8:	d37df042 	lsl	x2, x2, #3
    5efc:	8b020083 	add	x3, x4, x2
    5f00:	f9401073 	ldr	x19, [x3, #32]
    5f04:	b40002b3 	cbz	x19, 5f58 <fwp_drop0+0x98>
    5f08:	38626882 	ldrb	w2, [x4, x2]
    5f0c:	7100085f 	cmp	w2, #0x2
    5f10:	540002c0 	b.eq	5f68 <fwp_drop0+0xa8>  // b.none
    5f14:	7100045f 	cmp	w2, #0x1
    5f18:	54000201 	b.ne	5f58 <fwp_drop0+0x98>  // b.any
    5f1c:	29430864 	ldp	w4, w2, [x3, #24]
    5f20:	92403c21 	and	x1, x1, #0xffff
    5f24:	9b047c21 	mul	x1, x1, x4
    5f28:	d360fc21 	lsr	x1, x1, #32
    5f2c:	eb02003f 	cmp	x1, x2
    5f30:	54000142 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f34:	8b010273 	add	x19, x19, x1
    5f38:	39400261 	ldrb	w1, [x19]
    5f3c:	340000e1 	cbz	w1, 5f58 <fwp_drop0+0x98>
    5f40:	7100043f 	cmp	w1, #0x1
    5f44:	540001e0 	b.eq	5f80 <fwp_drop0+0xc0>  // b.none
    5f48:	7103fc3f 	cmp	w1, #0xff
    5f4c:	540002e0 	b.eq	5fa8 <fwp_drop0+0xe8>  // b.none
    5f50:	51000421 	sub	w1, w1, #0x1
    5f54:	39000261 	strb	w1, [x19]
    5f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f5c:	f94013f5 	ldr	x21, [sp, #32]
    5f60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f64:	d65f03c0 	ret
    5f68:	72003c3f 	tst	w1, #0xffff
    5f6c:	54fffe60 	b.eq	5f38 <fwp_drop0+0x78>  // b.none
    5f70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f74:	f94013f5 	ldr	x21, [sp, #32]
    5f78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f7c:	d65f03c0 	ret
    5f80:	f9400813 	ldr	x19, [x0, #16]
    5f84:	97fffe9f 	bl	5a00 <fwp_rc_free_arr>
    5f88:	911742a0 	add	x0, x21, #0x5d0
    5f8c:	f949d801 	ldr	x1, [x0, #5040]
    5f90:	f949ec00 	ldr	x0, [x0, #5080]
    5f94:	cb010261 	sub	x1, x19, x1
    5f98:	eb00403f 	cmp	x1, x0, lsl #16
    5f9c:	54fffde2 	b.cs	5f58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fa0:	aa1303e0 	mov	x0, x19
    5fa4:	17ffffd2 	b	5eec <fwp_drop0+0x2c>
    5fa8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fac:	911742b5 	add	x21, x21, #0x5d0
    5fb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fb4:	92401c00 	and	x0, x0, #0xff
    5fb8:	910a2402 	add	x2, x0, #0x289
    5fbc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5fc0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5fc4:	f94a2400 	ldr	x0, [x0, #5192]
    5fc8:	b50000a0 	cbnz	x0, 5fdc <fwp_drop0+0x11c>
    5fcc:	14000013 	b	6018 <fwp_drop0+0x158>
    5fd0:	91004002 	add	x2, x0, #0x10
    5fd4:	f9400800 	ldr	x0, [x0, #16]
    5fd8:	b4000200 	cbz	x0, 6018 <fwp_drop0+0x158>
    5fdc:	f9400001 	ldr	x1, [x0]
    5fe0:	eb13003f 	cmp	x1, x19
    5fe4:	54ffff61 	b.ne	5fd0 <fwp_drop0+0x110>  // b.any
    5fe8:	f9400041 	ldr	x1, [x2]
    5fec:	f9400420 	ldr	x0, [x1, #8]
    5ff0:	d1000400 	sub	x0, x0, #0x1
    5ff4:	f9000420 	str	x0, [x1, #8]
    5ff8:	f103f81f 	cmp	x0, #0xfe
    5ffc:	54fffae1 	b.ne	5f58 <fwp_drop0+0x98>  // b.any
    6000:	39400260 	ldrb	w0, [x19]
    6004:	7103fc1f 	cmp	w0, #0xff
    6008:	540000e0 	b.eq	6024 <fwp_drop0+0x164>  // b.none
    600c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6010:	39000260 	strb	w0, [x19]
    6014:	17ffffd1 	b	5f58 <fwp_drop0+0x98>
    6018:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    601c:	9102a000 	add	x0, x0, #0xa8
    6020:	97fff85c 	bl	4190 <fwp_trap>
    6024:	aa1303e0 	mov	x0, x19
    6028:	97fff87a 	bl	4210 <fwp_rc_forget_slot.part.0>
    602c:	17fffff8 	b	600c <fwp_drop0+0x14c>

0000000000006030 <fwp_closure_drop>:
    6030:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    6034:	911740a4 	add	x4, x5, #0x5d0
    6038:	aa0003e1 	mov	x1, x0
    603c:	f949d882 	ldr	x2, [x4, #5040]
    6040:	f949ec80 	ldr	x0, [x4, #5080]
    6044:	cb020022 	sub	x2, x1, x2
    6048:	eb00405f 	cmp	x2, x0, lsl #16
    604c:	54000662 	b.cs	6118 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6050:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6054:	d350fc43 	lsr	x3, x2, #16
    6058:	910003fd 	mov	x29, sp
    605c:	8b030863 	add	x3, x3, x3, lsl #2
    6060:	f949fc84 	ldr	x4, [x4, #5112]
    6064:	d37df063 	lsl	x3, x3, #3
    6068:	f9000bf3 	str	x19, [sp, #16]
    606c:	8b030080 	add	x0, x4, x3
    6070:	f9401013 	ldr	x19, [x0, #32]
    6074:	b40002b3 	cbz	x19, 60c8 <fwp_closure_drop+0x98>
    6078:	38636883 	ldrb	w3, [x4, x3]
    607c:	7100087f 	cmp	w3, #0x2
    6080:	54000420 	b.eq	6104 <fwp_closure_drop+0xd4>  // b.none
    6084:	7100047f 	cmp	w3, #0x1
    6088:	54000201 	b.ne	60c8 <fwp_closure_drop+0x98>  // b.any
    608c:	29430003 	ldp	w3, w0, [x0, #24]
    6090:	92403c42 	and	x2, x2, #0xffff
    6094:	9b037c42 	mul	x2, x2, x3
    6098:	d360fc42 	lsr	x2, x2, #32
    609c:	eb00005f 	cmp	x2, x0
    60a0:	54000142 	b.cs	60c8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    60a4:	8b020273 	add	x19, x19, x2
    60a8:	39400260 	ldrb	w0, [x19]
    60ac:	340000e0 	cbz	w0, 60c8 <fwp_closure_drop+0x98>
    60b0:	7100041f 	cmp	w0, #0x1
    60b4:	54000100 	b.eq	60d4 <fwp_closure_drop+0xa4>  // b.none
    60b8:	7103fc1f 	cmp	w0, #0xff
    60bc:	54000300 	b.eq	611c <fwp_closure_drop+0xec>  // b.none
    60c0:	51000400 	sub	w0, w0, #0x1
    60c4:	39000260 	strb	w0, [x19]
    60c8:	f9400bf3 	ldr	x19, [sp, #16]
    60cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60d0:	d65f03c0 	ret
    60d4:	d53bd040 	mrs	x0, tpidr_el0
    60d8:	91400000 	add	x0, x0, #0x0, lsl #12
    60dc:	91004000 	add	x0, x0, #0x10
    60e0:	f9400000 	ldr	x0, [x0]
    60e4:	b4000080 	cbz	x0, 60f4 <fwp_closure_drop+0xc4>
    60e8:	f9400bf3 	ldr	x19, [sp, #16]
    60ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60f0:	17fff9a4 	b	4780 <fwp_closure_drop_push>
    60f4:	f9400bf3 	ldr	x19, [sp, #16]
    60f8:	aa0103e0 	mov	x0, x1
    60fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6100:	17fff9e5 	b	4894 <fwp_closure_drop.part.0>
    6104:	72003c5f 	tst	w2, #0xffff
    6108:	54fffd00 	b.eq	60a8 <fwp_closure_drop+0x78>  // b.none
    610c:	f9400bf3 	ldr	x19, [sp, #16]
    6110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6114:	d65f03c0 	ret
    6118:	d65f03c0 	ret
    611c:	ca534660 	eor	x0, x19, x19, lsr #17
    6120:	911740a5 	add	x5, x5, #0x5d0
    6124:	ca402400 	eor	x0, x0, x0, lsr #9
    6128:	92401c00 	and	x0, x0, #0xff
    612c:	910a2402 	add	x2, x0, #0x289
    6130:	8b000ca0 	add	x0, x5, x0, lsl #3
    6134:	8b020ca2 	add	x2, x5, x2, lsl #3
    6138:	f94a2400 	ldr	x0, [x0, #5192]
    613c:	b50000a0 	cbnz	x0, 6150 <fwp_closure_drop+0x120>
    6140:	14000013 	b	618c <fwp_closure_drop+0x15c>
    6144:	91004002 	add	x2, x0, #0x10
    6148:	f9400800 	ldr	x0, [x0, #16]
    614c:	b4000200 	cbz	x0, 618c <fwp_closure_drop+0x15c>
    6150:	f9400001 	ldr	x1, [x0]
    6154:	eb13003f 	cmp	x1, x19
    6158:	54ffff61 	b.ne	6144 <fwp_closure_drop+0x114>  // b.any
    615c:	f9400041 	ldr	x1, [x2]
    6160:	f9400420 	ldr	x0, [x1, #8]
    6164:	d1000400 	sub	x0, x0, #0x1
    6168:	f9000420 	str	x0, [x1, #8]
    616c:	f103f81f 	cmp	x0, #0xfe
    6170:	54fffac1 	b.ne	60c8 <fwp_closure_drop+0x98>  // b.any
    6174:	39400260 	ldrb	w0, [x19]
    6178:	7103fc1f 	cmp	w0, #0xff
    617c:	540000e0 	b.eq	6198 <fwp_closure_drop+0x168>  // b.none
    6180:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6184:	39000260 	strb	w0, [x19]
    6188:	17ffffd0 	b	60c8 <fwp_closure_drop+0x98>
    618c:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    6190:	9102a000 	add	x0, x0, #0xa8
    6194:	97fff7ff 	bl	4190 <fwp_trap>
    6198:	aa1303e0 	mov	x0, x19
    619c:	97fff81d 	bl	4210 <fwp_rc_forget_slot.part.0>
    61a0:	17fffff8 	b	6180 <fwp_closure_drop+0x150>

00000000000061a4 <fwp_owned_tape_release>:
    61a4:	b4000920 	cbz	x0, 62c8 <fwp_owned_tape_release+0x124>
    61a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61ac:	910003fd 	mov	x29, sp
    61b0:	a90153f3 	stp	x19, x20, [sp, #16]
    61b4:	aa0003f3 	mov	x19, x0
    61b8:	f9400000 	ldr	x0, [x0]
    61bc:	b4000060 	cbz	x0, 61c8 <fwp_owned_tape_release+0x24>
    61c0:	f9400661 	ldr	x1, [x19, #8]
    61c4:	f9000401 	str	x1, [x0, #8]
    61c8:	f9400661 	ldr	x1, [x19, #8]
    61cc:	b4000041 	cbz	x1, 61d4 <fwp_owned_tape_release+0x30>
    61d0:	f9000020 	str	x0, [x1]
    61d4:	f9400a60 	ldr	x0, [x19, #16]
    61d8:	f9403401 	ldr	x1, [x0, #104]
    61dc:	b40005a1 	cbz	x1, 6290 <fwp_owned_tape_release+0xec>
    61e0:	a9450a60 	ldp	x0, x2, [x19, #80]
    61e4:	eb00005f 	cmp	x2, x0
    61e8:	540002cd 	b.le	6240 <fwp_owned_tape_release+0x9c>
    61ec:	d2800014 	mov	x20, #0x0                   	// #0
    61f0:	f90013f5 	str	x21, [sp, #32]
    61f4:	d2800015 	mov	x21, #0x0                   	// #0
    61f8:	f9402260 	ldr	x0, [x19, #64]
    61fc:	910006b5 	add	x21, x21, #0x1
    6200:	f8746800 	ldr	x0, [x0, x20]
    6204:	d63f0020 	blr	x1
    6208:	f9402260 	ldr	x0, [x19, #64]
    620c:	f9400a61 	ldr	x1, [x19, #16]
    6210:	8b140000 	add	x0, x0, x20
    6214:	91004294 	add	x20, x20, #0x10
    6218:	f9400400 	ldr	x0, [x0, #8]
    621c:	f9403421 	ldr	x1, [x1, #104]
    6220:	d63f0020 	blr	x1
    6224:	a9450261 	ldp	x1, x0, [x19, #80]
    6228:	cb010000 	sub	x0, x0, x1
    622c:	eb15001f 	cmp	x0, x21
    6230:	f9400a60 	ldr	x0, [x19, #16]
    6234:	f9403401 	ldr	x1, [x0, #104]
    6238:	54fffe0c 	b.gt	61f8 <fwp_owned_tape_release+0x54>
    623c:	f94013f5 	ldr	x21, [sp, #32]
    6240:	f9403663 	ldr	x3, [x19, #104]
    6244:	f9401262 	ldr	x2, [x19, #32]
    6248:	f100007f 	cmp	x3, #0x0
    624c:	540001ed 	b.le	6288 <fwp_owned_tape_release+0xe4>
    6250:	d2800014 	mov	x20, #0x0                   	// #0
    6254:	d503201f 	nop
    6258:	f9402660 	ldr	x0, [x19, #72]
    625c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6260:	eb02001f 	cmp	x0, x2
    6264:	540000c0 	b.eq	627c <fwp_owned_tape_release+0xd8>  // b.none
    6268:	d63f0020 	blr	x1
    626c:	f9400a60 	ldr	x0, [x19, #16]
    6270:	f9401262 	ldr	x2, [x19, #32]
    6274:	f9403663 	ldr	x3, [x19, #104]
    6278:	f9403401 	ldr	x1, [x0, #104]
    627c:	91000694 	add	x20, x20, #0x1
    6280:	eb14007f 	cmp	x3, x20
    6284:	54fffeac 	b.gt	6258 <fwp_owned_tape_release+0xb4>
    6288:	aa0203e0 	mov	x0, x2
    628c:	d63f0020 	blr	x1
    6290:	f9401660 	ldr	x0, [x19, #40]
    6294:	97ffff67 	bl	6030 <fwp_closure_drop>
    6298:	f9401a60 	ldr	x0, [x19, #48]
    629c:	97ffff65 	bl	6030 <fwp_closure_drop>
    62a0:	f9401e60 	ldr	x0, [x19, #56]
    62a4:	97ffff63 	bl	6030 <fwp_closure_drop>
    62a8:	f9402260 	ldr	x0, [x19, #64]
    62ac:	97fff875 	bl	4480 <fwp_mem_free>
    62b0:	f9402660 	ldr	x0, [x19, #72]
    62b4:	97fff873 	bl	4480 <fwp_mem_free>
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	17fff86f 	b	4480 <fwp_mem_free>
    62c8:	d65f03c0 	ret
    62cc:	d503201f 	nop

00000000000062d0 <fwp_tape_finish>:
    62d0:	d10203ff 	sub	sp, sp, #0x80
    62d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    62d8:	f947f421 	ldr	x1, [x1, #4072]
    62dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    62e0:	910103fd 	add	x29, sp, #0x40
    62e4:	a90553f3 	stp	x19, x20, [sp, #80]
    62e8:	a9065bf5 	stp	x21, x22, [sp, #96]
    62ec:	a90763f7 	stp	x23, x24, [sp, #112]
    62f0:	d00000d8 	adrp	x24, 20000 <__data_start>
    62f4:	9101c316 	add	x22, x24, #0x70
    62f8:	f9400022 	ldr	x2, [x1]
    62fc:	f9001fe2 	str	x2, [sp, #56]
    6300:	d2800002 	mov	x2, #0x0                   	// #0
    6304:	910222c0 	add	x0, x22, #0x88
    6308:	97fff47e 	bl	3500 <fwp_tape_buffers_dispose>
    630c:	f90062df 	str	xzr, [x22, #192]
    6310:	f9406ac0 	ldr	x0, [x22, #208]
    6314:	f100001f 	cmp	x0, #0x0
    6318:	5400030d 	b.le	6378 <fwp_tape_finish+0xa8>
    631c:	910003f7 	mov	x23, sp
    6320:	d2800015 	mov	x21, #0x0                   	// #0
    6324:	d2800014 	mov	x20, #0x0                   	// #0
    6328:	f94002d3 	ldr	x19, [x22]
    632c:	91000694 	add	x20, x20, #0x1
    6330:	8b150273 	add	x19, x19, x21
    6334:	9101a2b5 	add	x21, x21, #0x68
    6338:	aa1303e0 	mov	x0, x19
    633c:	97fff335 	bl	3010 <fwp_tape_unlink_scope>
    6340:	aa1703e0 	mov	x0, x23
    6344:	f9401261 	ldr	x1, [x19, #32]
    6348:	f90003e1 	str	x1, [sp]
    634c:	f9401a62 	ldr	x2, [x19, #48]
    6350:	f9000be2 	str	x2, [sp, #16]
    6354:	f9402261 	ldr	x1, [x19, #64]
    6358:	f90013e1 	str	x1, [sp, #32]
    635c:	97fff469 	bl	3500 <fwp_tape_buffers_dispose>
    6360:	f9403260 	ldr	x0, [x19, #96]
    6364:	97ffff90 	bl	61a4 <fwp_owned_tape_release>
    6368:	f900327f 	str	xzr, [x19, #96]
    636c:	f9406ac0 	ldr	x0, [x22, #208]
    6370:	eb14001f 	cmp	x0, x20
    6374:	54fffdac 	b.gt	6328 <fwp_tape_finish+0x58>
    6378:	f9403b00 	ldr	x0, [x24, #112]
    637c:	9101c313 	add	x19, x24, #0x70
    6380:	97fff194 	bl	29d0 <free@plt>
    6384:	f9003b1f 	str	xzr, [x24, #112]
    6388:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    638c:	f947f400 	ldr	x0, [x0, #4072]
    6390:	f9006a7f 	str	xzr, [x19, #208]
    6394:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6398:	f9401fe2 	ldr	x2, [sp, #56]
    639c:	f9400001 	ldr	x1, [x0]
    63a0:	eb010042 	subs	x2, x2, x1
    63a4:	d2800001 	mov	x1, #0x0                   	// #0
    63a8:	540000e1 	b.ne	63c4 <fwp_tape_finish+0xf4>  // b.any
    63ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    63b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    63bc:	910203ff 	add	sp, sp, #0x80
    63c0:	d65f03c0 	ret
    63c4:	97fff153 	bl	2910 <__stack_chk_fail@plt>
    63c8:	d503201f 	nop
    63cc:	d503201f 	nop

00000000000063d0 <fwp_tape_scope_release>:
    63d0:	d10243ff 	sub	sp, sp, #0x90
    63d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    63d8:	910103fd 	add	x29, sp, #0x40
    63dc:	a90553f3 	stp	x19, x20, [sp, #80]
    63e0:	aa0003f4 	mov	x20, x0
    63e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    63e8:	f947f400 	ldr	x0, [x0, #4072]
    63ec:	b9400285 	ldr	w5, [x20]
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	f9001fe1 	str	x1, [sp, #56]
    63f8:	d2800001 	mov	x1, #0x0                   	// #0
    63fc:	37f806c5 	tbnz	w5, #31, 64d4 <fwp_tape_scope_release+0x104>
    6400:	a90763f7 	stp	x23, x24, [sp, #112]
    6404:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6408:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    640c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6410:	d00000d3 	adrp	x19, 20000 <__data_start>
    6414:	910003f7 	mov	x23, sp
    6418:	9101c273 	add	x19, x19, #0x70
    641c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6420:	a9065bf5 	stp	x21, x22, [sp, #96]
    6424:	52800d16 	mov	w22, #0x68                  	// #104
    6428:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    642c:	f90043f9 	str	x25, [sp, #128]
    6430:	14000006 	b	6448 <fwp_tape_scope_release+0x78>
    6434:	97fff433 	bl	3500 <fwp_tape_buffers_dispose>
    6438:	aa1903e0 	mov	x0, x25
    643c:	97ffff5a 	bl	61a4 <fwp_owned_tape_release>
    6440:	b9400285 	ldr	w5, [x20]
    6444:	37f80425 	tbnz	w5, #31, 64c8 <fwp_tape_scope_release+0xf8>
    6448:	f9400266 	ldr	x6, [x19]
    644c:	9b367ca5 	smull	x5, w5, w22
    6450:	8b0500c0 	add	x0, x6, x5
    6454:	97fff2ef 	bl	3010 <fwp_tape_unlink_scope>
    6458:	ad410001 	ldp	q1, q0, [x0, #32]
    645c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6460:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6464:	f9400c03 	ldr	x3, [x0, #24]
    6468:	ad0003e1 	stp	q1, q0, [sp]
    646c:	b86568c1 	ldr	w1, [x6, x5]
    6470:	a9440804 	ldp	x4, x2, [x0, #64]
    6474:	b900041f 	str	wzr, [x0, #4]
    6478:	f9403019 	ldr	x25, [x0, #96]
    647c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6480:	f9000c1f 	str	xzr, [x0, #24]
    6484:	a9020fe4 	stp	x4, x3, [sp, #32]
    6488:	f9001be2 	str	x2, [sp, #48]
    648c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6490:	f900301f 	str	xzr, [x0, #96]
    6494:	6b15003f 	cmp	w1, w21
    6498:	540000e8 	b.hi	64b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    649c:	9343fca5 	asr	x5, x5, #3
    64a0:	f9407660 	ldr	x0, [x19, #232]
    64a4:	9b187ca5 	mul	x5, x5, x24
    64a8:	eb0000bf 	cmp	x5, x0
    64ac:	5400004a 	b.ge	64b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    64b0:	f9007665 	str	x5, [x19, #232]
    64b4:	aa1703e0 	mov	x0, x23
    64b8:	b5fffbf9 	cbnz	x25, 6434 <fwp_tape_scope_release+0x64>
    64bc:	97fff6ed 	bl	4070 <fwp_tape_buffers_release>
    64c0:	b9400285 	ldr	w5, [x20]
    64c4:	36fffc25 	tbz	w5, #31, 6448 <fwp_tape_scope_release+0x78>
    64c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    64cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    64d0:	f94043f9 	ldr	x25, [sp, #128]
    64d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    64d8:	f947f400 	ldr	x0, [x0, #4072]
    64dc:	f9401fe2 	ldr	x2, [sp, #56]
    64e0:	f9400001 	ldr	x1, [x0]
    64e4:	eb010042 	subs	x2, x2, x1
    64e8:	d2800001 	mov	x1, #0x0                   	// #0
    64ec:	540000a1 	b.ne	6500 <fwp_tape_scope_release+0x130>  // b.any
    64f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    64f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    64f8:	910243ff 	add	sp, sp, #0x90
    64fc:	d65f03c0 	ret
    6500:	a9065bf5 	stp	x21, x22, [sp, #96]
    6504:	a90763f7 	stp	x23, x24, [sp, #112]
    6508:	f90043f9 	str	x25, [sp, #128]
    650c:	97fff101 	bl	2910 <__stack_chk_fail@plt>

0000000000006510 <fwp_drop4>:
    6510:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6514:	910003fd 	mov	x29, sp
    6518:	a9025bf5 	stp	x21, x22, [sp, #32]
    651c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6520:	911742d5 	add	x21, x22, #0x5d0
    6524:	a90153f3 	stp	x19, x20, [sp, #16]
    6528:	aa0003f3 	mov	x19, x0
    652c:	f949daa1 	ldr	x1, [x21, #5040]
    6530:	f949eea0 	ldr	x0, [x21, #5080]
    6534:	cb010261 	sub	x1, x19, x1
    6538:	eb00403f 	cmp	x1, x0, lsl #16
    653c:	54000382 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6540:	d350fc22 	lsr	x2, x1, #16
    6544:	f949fea3 	ldr	x3, [x21, #5112]
    6548:	8b020842 	add	x2, x2, x2, lsl #2
    654c:	d37df042 	lsl	x2, x2, #3
    6550:	8b020060 	add	x0, x3, x2
    6554:	f9401014 	ldr	x20, [x0, #32]
    6558:	b40002b4 	cbz	x20, 65ac <fwp_drop4+0x9c>
    655c:	38626862 	ldrb	w2, [x3, x2]
    6560:	7100085f 	cmp	w2, #0x2
    6564:	540002c0 	b.eq	65bc <fwp_drop4+0xac>  // b.none
    6568:	7100045f 	cmp	w2, #0x1
    656c:	54000201 	b.ne	65ac <fwp_drop4+0x9c>  // b.any
    6570:	29430002 	ldp	w2, w0, [x0, #24]
    6574:	92403c21 	and	x1, x1, #0xffff
    6578:	9b027c21 	mul	x1, x1, x2
    657c:	d360fc21 	lsr	x1, x1, #32
    6580:	eb00003f 	cmp	x1, x0
    6584:	54000142 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6588:	8b010294 	add	x20, x20, x1
    658c:	39400280 	ldrb	w0, [x20]
    6590:	340000e0 	cbz	w0, 65ac <fwp_drop4+0x9c>
    6594:	7100041f 	cmp	w0, #0x1
    6598:	540001e0 	b.eq	65d4 <fwp_drop4+0xc4>  // b.none
    659c:	7103fc1f 	cmp	w0, #0xff
    65a0:	540007c0 	b.eq	6698 <fwp_drop4+0x188>  // b.none
    65a4:	51000400 	sub	w0, w0, #0x1
    65a8:	39000280 	strb	w0, [x20]
    65ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    65b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65b8:	d65f03c0 	ret
    65bc:	72003c3f 	tst	w1, #0xffff
    65c0:	54fffe60 	b.eq	658c <fwp_drop4+0x7c>  // b.none
    65c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    65c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65d0:	d65f03c0 	ret
    65d4:	911742c2 	add	x2, x22, #0x5d0
    65d8:	f9400660 	ldr	x0, [x19, #8]
    65dc:	f949d841 	ldr	x1, [x2, #5040]
    65e0:	f949ec42 	ldr	x2, [x2, #5080]
    65e4:	cb010001 	sub	x1, x0, x1
    65e8:	eb02403f 	cmp	x1, x2, lsl #16
    65ec:	54000362 	b.cs	6658 <fwp_drop4+0x148>  // b.hs, b.nlast
    65f0:	d350fc22 	lsr	x2, x1, #16
    65f4:	8b020842 	add	x2, x2, x2, lsl #2
    65f8:	d37df042 	lsl	x2, x2, #3
    65fc:	8b020064 	add	x4, x3, x2
    6600:	f9401094 	ldr	x20, [x4, #32]
    6604:	b40002b4 	cbz	x20, 6658 <fwp_drop4+0x148>
    6608:	38626862 	ldrb	w2, [x3, x2]
    660c:	7100085f 	cmp	w2, #0x2
    6610:	540003e0 	b.eq	668c <fwp_drop4+0x17c>  // b.none
    6614:	7100045f 	cmp	w2, #0x1
    6618:	54000201 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    661c:	29430883 	ldp	w3, w2, [x4, #24]
    6620:	92403c21 	and	x1, x1, #0xffff
    6624:	9b037c21 	mul	x1, x1, x3
    6628:	d360fc21 	lsr	x1, x1, #32
    662c:	eb02003f 	cmp	x1, x2
    6630:	54000142 	b.cs	6658 <fwp_drop4+0x148>  // b.hs, b.nlast
    6634:	8b010294 	add	x20, x20, x1
    6638:	39400281 	ldrb	w1, [x20]
    663c:	340000e1 	cbz	w1, 6658 <fwp_drop4+0x148>
    6640:	7100043f 	cmp	w1, #0x1
    6644:	54000200 	b.eq	6684 <fwp_drop4+0x174>  // b.none
    6648:	7103fc3f 	cmp	w1, #0xff
    664c:	54000640 	b.eq	6714 <fwp_drop4+0x204>  // b.none
    6650:	51000421 	sub	w1, w1, #0x1
    6654:	39000281 	strb	w1, [x20]
    6658:	f9400a74 	ldr	x20, [x19, #16]
    665c:	aa1303e0 	mov	x0, x19
    6660:	97fffce8 	bl	5a00 <fwp_rc_free_arr>
    6664:	911742c0 	add	x0, x22, #0x5d0
    6668:	f949d801 	ldr	x1, [x0, #5040]
    666c:	f949ec00 	ldr	x0, [x0, #5080]
    6670:	cb010281 	sub	x1, x20, x1
    6674:	eb00403f 	cmp	x1, x0, lsl #16
    6678:	54fff9a2 	b.cs	65ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    667c:	aa1403f3 	mov	x19, x20
    6680:	17ffffb0 	b	6540 <fwp_drop4+0x30>
    6684:	97fffcdf 	bl	5a00 <fwp_rc_free_arr>
    6688:	17fffff4 	b	6658 <fwp_drop4+0x148>
    668c:	72003c3f 	tst	w1, #0xffff
    6690:	54fffe41 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    6694:	17ffffe9 	b	6638 <fwp_drop4+0x128>
    6698:	ca544681 	eor	x1, x20, x20, lsr #17
    669c:	911742c0 	add	x0, x22, #0x5d0
    66a0:	ca412421 	eor	x1, x1, x1, lsr #9
    66a4:	92401c21 	and	x1, x1, #0xff
    66a8:	910a2422 	add	x2, x1, #0x289
    66ac:	8b010c01 	add	x1, x0, x1, lsl #3
    66b0:	8b020c02 	add	x2, x0, x2, lsl #3
    66b4:	f94a2420 	ldr	x0, [x1, #5192]
    66b8:	b50000a0 	cbnz	x0, 66cc <fwp_drop4+0x1bc>
    66bc:	14000013 	b	6708 <fwp_drop4+0x1f8>
    66c0:	91004002 	add	x2, x0, #0x10
    66c4:	f9400800 	ldr	x0, [x0, #16]
    66c8:	b4000200 	cbz	x0, 6708 <fwp_drop4+0x1f8>
    66cc:	f9400001 	ldr	x1, [x0]
    66d0:	eb14003f 	cmp	x1, x20
    66d4:	54ffff61 	b.ne	66c0 <fwp_drop4+0x1b0>  // b.any
    66d8:	f9400041 	ldr	x1, [x2]
    66dc:	f9400420 	ldr	x0, [x1, #8]
    66e0:	d1000400 	sub	x0, x0, #0x1
    66e4:	f9000420 	str	x0, [x1, #8]
    66e8:	f103f81f 	cmp	x0, #0xfe
    66ec:	54fff601 	b.ne	65ac <fwp_drop4+0x9c>  // b.any
    66f0:	39400280 	ldrb	w0, [x20]
    66f4:	7103fc1f 	cmp	w0, #0xff
    66f8:	54000460 	b.eq	6784 <fwp_drop4+0x274>  // b.none
    66fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6700:	39000280 	strb	w0, [x20]
    6704:	17ffffaa 	b	65ac <fwp_drop4+0x9c>
    6708:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    670c:	9102a000 	add	x0, x0, #0xa8
    6710:	97fff6a0 	bl	4190 <fwp_trap>
    6714:	ca544680 	eor	x0, x20, x20, lsr #17
    6718:	911742c1 	add	x1, x22, #0x5d0
    671c:	ca402400 	eor	x0, x0, x0, lsr #9
    6720:	92401c00 	and	x0, x0, #0xff
    6724:	910a2402 	add	x2, x0, #0x289
    6728:	8b000c20 	add	x0, x1, x0, lsl #3
    672c:	8b020c22 	add	x2, x1, x2, lsl #3
    6730:	f94a2400 	ldr	x0, [x0, #5192]
    6734:	b50000a0 	cbnz	x0, 6748 <fwp_drop4+0x238>
    6738:	17fffff4 	b	6708 <fwp_drop4+0x1f8>
    673c:	91004002 	add	x2, x0, #0x10
    6740:	f9400800 	ldr	x0, [x0, #16]
    6744:	b4fffe20 	cbz	x0, 6708 <fwp_drop4+0x1f8>
    6748:	f9400001 	ldr	x1, [x0]
    674c:	eb14003f 	cmp	x1, x20
    6750:	54ffff61 	b.ne	673c <fwp_drop4+0x22c>  // b.any
    6754:	f9400041 	ldr	x1, [x2]
    6758:	f9400420 	ldr	x0, [x1, #8]
    675c:	d1000400 	sub	x0, x0, #0x1
    6760:	f9000420 	str	x0, [x1, #8]
    6764:	f103f81f 	cmp	x0, #0xfe
    6768:	54fff781 	b.ne	6658 <fwp_drop4+0x148>  // b.any
    676c:	39400280 	ldrb	w0, [x20]
    6770:	7103fc1f 	cmp	w0, #0xff
    6774:	540000e0 	b.eq	6790 <fwp_drop4+0x280>  // b.none
    6778:	12800020 	mov	w0, #0xfffffffe            	// #-2
    677c:	39000280 	strb	w0, [x20]
    6780:	17ffffb6 	b	6658 <fwp_drop4+0x148>
    6784:	aa1403e0 	mov	x0, x20
    6788:	97fff6a2 	bl	4210 <fwp_rc_forget_slot.part.0>
    678c:	17ffffdc 	b	66fc <fwp_drop4+0x1ec>
    6790:	aa1403e0 	mov	x0, x20
    6794:	97fff69f 	bl	4210 <fwp_rc_forget_slot.part.0>
    6798:	17fffff8 	b	6778 <fwp_drop4+0x268>
    679c:	d503201f 	nop

00000000000067a0 <fwp_arg_drop37>:
    67a0:	7100003f 	cmp	w1, #0x0
    67a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    67a8:	54000041 	b.ne	67b0 <fwp_arg_drop37+0x10>  // b.any
    67ac:	d65f03c0 	ret
    67b0:	f9400000 	ldr	x0, [x0]
    67b4:	17ffff57 	b	6510 <fwp_drop4>
    67b8:	d503201f 	nop
    67bc:	d503201f 	nop

00000000000067c0 <fwp_task_dispose>:
    67c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67c4:	910003fd 	mov	x29, sp
    67c8:	f9000bf3 	str	x19, [sp, #16]
    67cc:	aa0003f3 	mov	x19, x0
    67d0:	39414000 	ldrb	w0, [x0, #80]
    67d4:	36000720 	tbz	w0, #0, 68b8 <fwp_task_dispose+0xf8>
    67d8:	f9400a60 	ldr	x0, [x19, #16]
    67dc:	b50006e0 	cbnz	x0, 68b8 <fwp_task_dispose+0xf8>
    67e0:	a9478660 	ldp	x0, x1, [x19, #120]
    67e4:	39014e7f 	strb	wzr, [x19, #83]
    67e8:	f9003e7f 	str	xzr, [x19, #120]
    67ec:	f100003f 	cmp	x1, #0x0
    67f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67f4:	54000040 	b.eq	67fc <fwp_task_dispose+0x3c>  // b.none
    67f8:	d63f0020 	blr	x1
    67fc:	f9405660 	ldr	x0, [x19, #168]
    6800:	97fff720 	bl	4480 <fwp_mem_free>
    6804:	f900567f 	str	xzr, [x19, #168]
    6808:	b9405e60 	ldr	w0, [x19, #92]
    680c:	7100041f 	cmp	w0, #0x1
    6810:	54000420 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6814:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6818:	91174042 	add	x2, x2, #0x5d0
    681c:	f949d840 	ldr	x0, [x2, #5040]
    6820:	f949ec41 	ldr	x1, [x2, #5080]
    6824:	cb000260 	sub	x0, x19, x0
    6828:	eb01401f 	cmp	x0, x1, lsl #16
    682c:	540002e2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6830:	d350fc01 	lsr	x1, x0, #16
    6834:	f949fc44 	ldr	x4, [x2, #5112]
    6838:	8b010821 	add	x1, x1, x1, lsl #2
    683c:	d37df021 	lsl	x1, x1, #3
    6840:	8b010083 	add	x3, x4, x1
    6844:	f9401062 	ldr	x2, [x3, #32]
    6848:	b4000202 	cbz	x2, 6888 <fwp_task_dispose+0xc8>
    684c:	38616881 	ldrb	w1, [x4, x1]
    6850:	7100083f 	cmp	w1, #0x2
    6854:	54000280 	b.eq	68a4 <fwp_task_dispose+0xe4>  // b.none
    6858:	7100043f 	cmp	w1, #0x1
    685c:	54000161 	b.ne	6888 <fwp_task_dispose+0xc8>  // b.any
    6860:	29430464 	ldp	w4, w1, [x3, #24]
    6864:	92403c00 	and	x0, x0, #0xffff
    6868:	9b047c00 	mul	x0, x0, x4
    686c:	d360fc00 	lsr	x0, x0, #32
    6870:	eb01001f 	cmp	x0, x1
    6874:	540000a2 	b.cs	6888 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6878:	8b000042 	add	x2, x2, x0
    687c:	39400040 	ldrb	w0, [x2]
    6880:	7100041f 	cmp	w0, #0x1
    6884:	54000080 	b.eq	6894 <fwp_task_dispose+0xd4>  // b.none
    6888:	f9400bf3 	ldr	x19, [sp, #16]
    688c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6890:	d65f03c0 	ret
    6894:	aa1303e0 	mov	x0, x19
    6898:	f9400bf3 	ldr	x19, [sp, #16]
    689c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a0:	17fff6f8 	b	4480 <fwp_mem_free>
    68a4:	72003c1f 	tst	w0, #0xffff
    68a8:	54fffea0 	b.eq	687c <fwp_task_dispose+0xbc>  // b.none
    68ac:	f9400bf3 	ldr	x19, [sp, #16]
    68b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b4:	d65f03c0 	ret
    68b8:	97fff02a 	bl	2960 <abort@plt>
    68bc:	d503201f 	nop

00000000000068c0 <fwp_free_zombie>:
    68c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68c4:	910003fd 	mov	x29, sp
    68c8:	a90153f3 	stp	x19, x20, [sp, #16]
    68cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    68d0:	9101c281 	add	x1, x20, #0x70
    68d4:	f9407833 	ldr	x19, [x1, #240]
    68d8:	b4000333 	cbz	x19, 693c <fwp_free_zombie+0x7c>
    68dc:	f9400820 	ldr	x0, [x1, #16]
    68e0:	eb00027f 	cmp	x19, x0
    68e4:	540002c0 	b.eq	693c <fwp_free_zombie+0x7c>  // b.none
    68e8:	b940f822 	ldr	w2, [x1, #248]
    68ec:	f9400a60 	ldr	x0, [x19, #16]
    68f0:	7100fc5f 	cmp	w2, #0x3f
    68f4:	5400078c 	b.gt	69e4 <fwp_free_zombie+0x124>
    68f8:	91040023 	add	x3, x1, #0x100
    68fc:	11000444 	add	w4, w2, #0x1
    6900:	b900f824 	str	w4, [x1, #248]
    6904:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6908:	f822d860 	str	x0, [x3, w2, sxtw #3]
    690c:	a9530261 	ldp	x1, x0, [x19, #304]
    6910:	b4000741 	cbz	x1, 69f8 <fwp_free_zombie+0x138>
    6914:	f9009c20 	str	x0, [x1, #312]
    6918:	b4000040 	cbz	x0, 6920 <fwp_free_zombie+0x60>
    691c:	f9009801 	str	x1, [x0, #304]
    6920:	9101c294 	add	x20, x20, #0x70
    6924:	b9405e60 	ldr	w0, [x19, #92]
    6928:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    692c:	f9007a9f 	str	xzr, [x20, #240]
    6930:	34000140 	cbz	w0, 6958 <fwp_free_zombie+0x98>
    6934:	7100041f 	cmp	w0, #0x1
    6938:	54000080 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    693c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6944:	d65f03c0 	ret
    6948:	aa1303e0 	mov	x0, x19
    694c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6950:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6954:	17ffff9b 	b	67c0 <fwp_task_dispose>
    6958:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    695c:	91174082 	add	x2, x4, #0x5d0
    6960:	f949d841 	ldr	x1, [x2, #5040]
    6964:	f949ec40 	ldr	x0, [x2, #5080]
    6968:	cb010261 	sub	x1, x19, x1
    696c:	eb00403f 	cmp	x1, x0, lsl #16
    6970:	54fffe62 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6974:	d350fc20 	lsr	x0, x1, #16
    6978:	f949fc43 	ldr	x3, [x2, #5112]
    697c:	8b000800 	add	x0, x0, x0, lsl #2
    6980:	d37df000 	lsl	x0, x0, #3
    6984:	8b000062 	add	x2, x3, x0
    6988:	f9401054 	ldr	x20, [x2, #32]
    698c:	b4fffd94 	cbz	x20, 693c <fwp_free_zombie+0x7c>
    6990:	38606860 	ldrb	w0, [x3, x0]
    6994:	7100081f 	cmp	w0, #0x2
    6998:	54000360 	b.eq	6a04 <fwp_free_zombie+0x144>  // b.none
    699c:	7100041f 	cmp	w0, #0x1
    69a0:	54fffce1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    69a4:	29430043 	ldp	w3, w0, [x2, #24]
    69a8:	92403c21 	and	x1, x1, #0xffff
    69ac:	9b037c21 	mul	x1, x1, x3
    69b0:	d360fc21 	lsr	x1, x1, #32
    69b4:	eb00003f 	cmp	x1, x0
    69b8:	54fffc22 	b.cs	693c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    69bc:	8b010294 	add	x20, x20, x1
    69c0:	39400280 	ldrb	w0, [x20]
    69c4:	34fffbc0 	cbz	w0, 693c <fwp_free_zombie+0x7c>
    69c8:	7100041f 	cmp	w0, #0x1
    69cc:	54fffbe0 	b.eq	6948 <fwp_free_zombie+0x88>  // b.none
    69d0:	7103fc1f 	cmp	w0, #0xff
    69d4:	540001e0 	b.eq	6a10 <fwp_free_zombie+0x150>  // b.none
    69d8:	51000400 	sub	w0, w0, #0x1
    69dc:	39000280 	strb	w0, [x20]
    69e0:	17ffffd7 	b	693c <fwp_free_zombie+0x7c>
    69e4:	f9400e61 	ldr	x1, [x19, #24]
    69e8:	97fff012 	bl	2a30 <munmap@plt>
    69ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69f0:	a9530261 	ldp	x1, x0, [x19, #304]
    69f4:	b5fff901 	cbnz	x1, 6914 <fwp_free_zombie+0x54>
    69f8:	9101c282 	add	x2, x20, #0x70
    69fc:	f9018040 	str	x0, [x2, #768]
    6a00:	17ffffc6 	b	6918 <fwp_free_zombie+0x58>
    6a04:	72003c3f 	tst	w1, #0xffff
    6a08:	54fff9a1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a0c:	17ffffed 	b	69c0 <fwp_free_zombie+0x100>
    6a10:	ca544680 	eor	x0, x20, x20, lsr #17
    6a14:	91174084 	add	x4, x4, #0x5d0
    6a18:	ca402400 	eor	x0, x0, x0, lsr #9
    6a1c:	92401c00 	and	x0, x0, #0xff
    6a20:	910a2402 	add	x2, x0, #0x289
    6a24:	8b000c80 	add	x0, x4, x0, lsl #3
    6a28:	8b020c82 	add	x2, x4, x2, lsl #3
    6a2c:	f94a2400 	ldr	x0, [x0, #5192]
    6a30:	b50000a0 	cbnz	x0, 6a44 <fwp_free_zombie+0x184>
    6a34:	14000013 	b	6a80 <fwp_free_zombie+0x1c0>
    6a38:	91004002 	add	x2, x0, #0x10
    6a3c:	f9400800 	ldr	x0, [x0, #16]
    6a40:	b4000200 	cbz	x0, 6a80 <fwp_free_zombie+0x1c0>
    6a44:	f9400001 	ldr	x1, [x0]
    6a48:	eb14003f 	cmp	x1, x20
    6a4c:	54ffff61 	b.ne	6a38 <fwp_free_zombie+0x178>  // b.any
    6a50:	f9400041 	ldr	x1, [x2]
    6a54:	f9400420 	ldr	x0, [x1, #8]
    6a58:	d1000400 	sub	x0, x0, #0x1
    6a5c:	f9000420 	str	x0, [x1, #8]
    6a60:	f103f81f 	cmp	x0, #0xfe
    6a64:	54fff6c1 	b.ne	693c <fwp_free_zombie+0x7c>  // b.any
    6a68:	39400280 	ldrb	w0, [x20]
    6a6c:	7103fc1f 	cmp	w0, #0xff
    6a70:	540000e0 	b.eq	6a8c <fwp_free_zombie+0x1cc>  // b.none
    6a74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a78:	39000280 	strb	w0, [x20]
    6a7c:	17ffffb0 	b	693c <fwp_free_zombie+0x7c>
    6a80:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    6a84:	9102a000 	add	x0, x0, #0xa8
    6a88:	97fff5c2 	bl	4190 <fwp_trap>
    6a8c:	aa1403e0 	mov	x0, x20
    6a90:	97fff5e0 	bl	4210 <fwp_rc_forget_slot.part.0>
    6a94:	17fffff8 	b	6a74 <fwp_free_zombie+0x1b4>
    6a98:	d503201f 	nop
    6a9c:	d503201f 	nop

0000000000006aa0 <fwp_block>:
    6aa0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6aa4:	910003fd 	mov	x29, sp
    6aa8:	a90153f3 	stp	x19, x20, [sp, #16]
    6aac:	d00000d3 	adrp	x19, 20000 <__data_start>
    6ab0:	9101c274 	add	x20, x19, #0x70
    6ab4:	f9404282 	ldr	x2, [x20, #128]
    6ab8:	b4000642 	cbz	x2, 6b80 <fwp_block+0xe0>
    6abc:	9101c261 	add	x1, x19, #0x70
    6ac0:	f9408040 	ldr	x0, [x2, #256]
    6ac4:	f9004020 	str	x0, [x1, #128]
    6ac8:	b40006a0 	cbz	x0, 6b9c <fwp_block+0xfc>
    6acc:	d503201f 	nop
    6ad0:	9101c263 	add	x3, x19, #0x70
    6ad4:	3901505f 	strb	wzr, [x2, #84]
    6ad8:	f9400864 	ldr	x4, [x3, #16]
    6adc:	eb02009f 	cmp	x4, x2
    6ae0:	54000440 	b.eq	6b68 <fwp_block+0xc8>  // b.none
    6ae4:	f9418465 	ldr	x5, [x3, #776]
    6ae8:	f9000862 	str	x2, [x3, #16]
    6aec:	f9400441 	ldr	x1, [x2, #8]
    6af0:	f9004885 	str	x5, [x4, #144]
    6af4:	f9418865 	ldr	x5, [x3, #784]
    6af8:	f9004c85 	str	x5, [x4, #152]
    6afc:	f9418c65 	ldr	x5, [x3, #792]
    6b00:	f9005085 	str	x5, [x4, #160]
    6b04:	f9419065 	ldr	x5, [x3, #800]
    6b08:	f9005485 	str	x5, [x4, #168]
    6b0c:	f9419465 	ldr	x5, [x3, #808]
    6b10:	f9005885 	str	x5, [x4, #176]
    6b14:	f9419865 	ldr	x5, [x3, #816]
    6b18:	f9005c85 	str	x5, [x4, #184]
    6b1c:	f9419c65 	ldr	x5, [x3, #824]
    6b20:	f9006085 	str	x5, [x4, #192]
    6b24:	f9400480 	ldr	x0, [x4, #8]
    6b28:	f9404844 	ldr	x4, [x2, #144]
    6b2c:	f9018464 	str	x4, [x3, #776]
    6b30:	f9404c44 	ldr	x4, [x2, #152]
    6b34:	f9018864 	str	x4, [x3, #784]
    6b38:	f9405044 	ldr	x4, [x2, #160]
    6b3c:	f9018c64 	str	x4, [x3, #792]
    6b40:	f9405444 	ldr	x4, [x2, #168]
    6b44:	f9019064 	str	x4, [x3, #800]
    6b48:	f9405844 	ldr	x4, [x2, #176]
    6b4c:	f9019464 	str	x4, [x3, #808]
    6b50:	a94b8844 	ldp	x4, x2, [x2, #184]
    6b54:	f9019864 	str	x4, [x3, #816]
    6b58:	f9019c62 	str	x2, [x3, #824]
    6b5c:	97ffef85 	bl	2970 <swapcontext@plt>
    6b60:	97ffff58 	bl	68c0 <fwp_free_zombie>
    6b64:	d503201f 	nop
    6b68:	9101c260 	add	x0, x19, #0x70
    6b6c:	b9434000 	ldr	w0, [x0, #832]
    6b70:	340001a0 	cbz	w0, 6ba4 <fwp_block+0x104>
    6b74:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b7c:	d65f03c0 	ret
    6b80:	97fff7cc 	bl	4ab0 <fwp_poll_events>
    6b84:	f9404282 	ldr	x2, [x20, #128]
    6b88:	b4ffffc2 	cbz	x2, 6b80 <fwp_block+0xe0>
    6b8c:	9101c261 	add	x1, x19, #0x70
    6b90:	f9408040 	ldr	x0, [x2, #256]
    6b94:	f9004020 	str	x0, [x1, #128]
    6b98:	b5fff9c0 	cbnz	x0, 6ad0 <fwp_block+0x30>
    6b9c:	f9003c3f 	str	xzr, [x1, #120]
    6ba0:	17ffffcc 	b	6ad0 <fwp_block+0x30>
    6ba4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    6ba8:	910d0000 	add	x0, x0, #0x340
    6bac:	97ffefbd 	bl	2aa0 <getenv@plt>
    6bb0:	5284e202 	mov	w2, #0x2710                	// #10000
    6bb4:	b4000060 	cbz	x0, 6bc0 <fwp_block+0x120>
    6bb8:	39400001 	ldrb	w1, [x0]
    6bbc:	350000c1 	cbnz	w1, 6bd4 <fwp_block+0x134>
    6bc0:	9101c273 	add	x19, x19, #0x70
    6bc4:	b9034262 	str	w2, [x19, #832]
    6bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bd0:	d65f03c0 	ret
    6bd4:	52800142 	mov	w2, #0xa                   	// #10
    6bd8:	d2800001 	mov	x1, #0x0                   	// #0
    6bdc:	97ffef01 	bl	27e0 <strtoll@plt>
    6be0:	d1000403 	sub	x3, x0, #0x1
    6be4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6be8:	eb02007f 	cmp	x3, x2
    6bec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6bf0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6bf4:	17fffff3 	b	6bc0 <fwp_block+0x120>
    6bf8:	d503201f 	nop
    6bfc:	d503201f 	nop

0000000000006c00 <fwp_drop10>:
    6c00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6c04:	910003fd 	mov	x29, sp
    6c08:	a90153f3 	stp	x19, x20, [sp, #16]
    6c0c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6c10:	f90013f5 	str	x21, [sp, #32]
    6c14:	91174275 	add	x21, x19, #0x5d0
    6c18:	f949daa1 	ldr	x1, [x21, #5040]
    6c1c:	f949eea2 	ldr	x2, [x21, #5080]
    6c20:	cb010001 	sub	x1, x0, x1
    6c24:	eb02403f 	cmp	x1, x2, lsl #16
    6c28:	54000382 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c2c:	d350fc22 	lsr	x2, x1, #16
    6c30:	f949fea3 	ldr	x3, [x21, #5112]
    6c34:	8b020842 	add	x2, x2, x2, lsl #2
    6c38:	d37df042 	lsl	x2, x2, #3
    6c3c:	8b020064 	add	x4, x3, x2
    6c40:	f9401094 	ldr	x20, [x4, #32]
    6c44:	b40002b4 	cbz	x20, 6c98 <fwp_drop10+0x98>
    6c48:	38626862 	ldrb	w2, [x3, x2]
    6c4c:	7100085f 	cmp	w2, #0x2
    6c50:	540007a0 	b.eq	6d44 <fwp_drop10+0x144>  // b.none
    6c54:	7100045f 	cmp	w2, #0x1
    6c58:	54000201 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6c5c:	29430885 	ldp	w5, w2, [x4, #24]
    6c60:	92403c21 	and	x1, x1, #0xffff
    6c64:	9b057c21 	mul	x1, x1, x5
    6c68:	d360fc21 	lsr	x1, x1, #32
    6c6c:	eb02003f 	cmp	x1, x2
    6c70:	54000142 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c74:	8b010294 	add	x20, x20, x1
    6c78:	39400281 	ldrb	w1, [x20]
    6c7c:	340000e1 	cbz	w1, 6c98 <fwp_drop10+0x98>
    6c80:	7100043f 	cmp	w1, #0x1
    6c84:	54000120 	b.eq	6ca8 <fwp_drop10+0xa8>  // b.none
    6c88:	7103fc3f 	cmp	w1, #0xff
    6c8c:	540007c0 	b.eq	6d84 <fwp_drop10+0x184>  // b.none
    6c90:	51000421 	sub	w1, w1, #0x1
    6c94:	39000281 	strb	w1, [x20]
    6c98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c9c:	f94013f5 	ldr	x21, [sp, #32]
    6ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ca4:	d65f03c0 	ret
    6ca8:	f9400001 	ldr	x1, [x0]
    6cac:	b7f80581 	tbnz	x1, #63, 6d5c <fwp_drop10+0x15c>
    6cb0:	91174273 	add	x19, x19, #0x5d0
    6cb4:	f949da61 	ldr	x1, [x19, #5040]
    6cb8:	f949ee62 	ldr	x2, [x19, #5080]
    6cbc:	cb010001 	sub	x1, x0, x1
    6cc0:	eb02403f 	cmp	x1, x2, lsl #16
    6cc4:	54fffea2 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cc8:	d350fc22 	lsr	x2, x1, #16
    6ccc:	8b020842 	add	x2, x2, x2, lsl #2
    6cd0:	d37df042 	lsl	x2, x2, #3
    6cd4:	8b020065 	add	x5, x3, x2
    6cd8:	f94010a4 	ldr	x4, [x5, #32]
    6cdc:	b4fffde4 	cbz	x4, 6c98 <fwp_drop10+0x98>
    6ce0:	38626862 	ldrb	w2, [x3, x2]
    6ce4:	7100085f 	cmp	w2, #0x2
    6ce8:	54000220 	b.eq	6d2c <fwp_drop10+0x12c>  // b.none
    6cec:	7100045f 	cmp	w2, #0x1
    6cf0:	54fffd41 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6cf4:	294308a3 	ldp	w3, w2, [x5, #24]
    6cf8:	92403c21 	and	x1, x1, #0xffff
    6cfc:	9b037c21 	mul	x1, x1, x3
    6d00:	d360fc21 	lsr	x1, x1, #32
    6d04:	eb02003f 	cmp	x1, x2
    6d08:	54fffc82 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d0c:	8b010084 	add	x4, x4, x1
    6d10:	39400081 	ldrb	w1, [x4]
    6d14:	7100043f 	cmp	w1, #0x1
    6d18:	54fffc01 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6d1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d20:	f94013f5 	ldr	x21, [sp, #32]
    6d24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d28:	17fff5d6 	b	4480 <fwp_mem_free>
    6d2c:	72003c3f 	tst	w1, #0xffff
    6d30:	54ffff00 	b.eq	6d10 <fwp_drop10+0x110>  // b.none
    6d34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d38:	f94013f5 	ldr	x21, [sp, #32]
    6d3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d40:	d65f03c0 	ret
    6d44:	72003c3f 	tst	w1, #0xffff
    6d48:	54fff980 	b.eq	6c78 <fwp_drop10+0x78>  // b.none
    6d4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d50:	f94013f5 	ldr	x21, [sp, #32]
    6d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d58:	d65f03c0 	ret
    6d5c:	f9400414 	ldr	x20, [x0, #8]
    6d60:	97fffb28 	bl	5a00 <fwp_rc_free_arr>
    6d64:	91174260 	add	x0, x19, #0x5d0
    6d68:	f949d801 	ldr	x1, [x0, #5040]
    6d6c:	f949ec00 	ldr	x0, [x0, #5080]
    6d70:	cb010281 	sub	x1, x20, x1
    6d74:	eb00403f 	cmp	x1, x0, lsl #16
    6d78:	54fff902 	b.cs	6c98 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d7c:	aa1403e0 	mov	x0, x20
    6d80:	17ffffab 	b	6c2c <fwp_drop10+0x2c>
    6d84:	ca544680 	eor	x0, x20, x20, lsr #17
    6d88:	91174273 	add	x19, x19, #0x5d0
    6d8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d90:	92401c00 	and	x0, x0, #0xff
    6d94:	910a2402 	add	x2, x0, #0x289
    6d98:	8b000e60 	add	x0, x19, x0, lsl #3
    6d9c:	8b020e62 	add	x2, x19, x2, lsl #3
    6da0:	f94a2400 	ldr	x0, [x0, #5192]
    6da4:	b50000a0 	cbnz	x0, 6db8 <fwp_drop10+0x1b8>
    6da8:	14000013 	b	6df4 <fwp_drop10+0x1f4>
    6dac:	91004002 	add	x2, x0, #0x10
    6db0:	f9400800 	ldr	x0, [x0, #16]
    6db4:	b4000200 	cbz	x0, 6df4 <fwp_drop10+0x1f4>
    6db8:	f9400001 	ldr	x1, [x0]
    6dbc:	eb14003f 	cmp	x1, x20
    6dc0:	54ffff61 	b.ne	6dac <fwp_drop10+0x1ac>  // b.any
    6dc4:	f9400041 	ldr	x1, [x2]
    6dc8:	f9400420 	ldr	x0, [x1, #8]
    6dcc:	d1000400 	sub	x0, x0, #0x1
    6dd0:	f9000420 	str	x0, [x1, #8]
    6dd4:	f103f81f 	cmp	x0, #0xfe
    6dd8:	54fff601 	b.ne	6c98 <fwp_drop10+0x98>  // b.any
    6ddc:	39400280 	ldrb	w0, [x20]
    6de0:	7103fc1f 	cmp	w0, #0xff
    6de4:	540000e0 	b.eq	6e00 <fwp_drop10+0x200>  // b.none
    6de8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6dec:	39000280 	strb	w0, [x20]
    6df0:	17ffffaa 	b	6c98 <fwp_drop10+0x98>
    6df4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    6df8:	9102a000 	add	x0, x0, #0xa8
    6dfc:	97fff4e5 	bl	4190 <fwp_trap>
    6e00:	aa1403e0 	mov	x0, x20
    6e04:	97fff503 	bl	4210 <fwp_rc_forget_slot.part.0>
    6e08:	17fffff8 	b	6de8 <fwp_drop10+0x1e8>
    6e0c:	d503201f 	nop

0000000000006e10 <fwp_caps173>:
    6e10:	34000041 	cbz	w1, 6e18 <fwp_caps173+0x8>
    6e14:	d65f03c0 	ret
    6e18:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6e1c:	91174063 	add	x3, x3, #0x5d0
    6e20:	f949d861 	ldr	x1, [x3, #5040]
    6e24:	f949ec62 	ldr	x2, [x3, #5080]
    6e28:	cb010001 	sub	x1, x0, x1
    6e2c:	eb02403f 	cmp	x1, x2, lsl #16
    6e30:	54ffff22 	b.cs	6e14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e34:	d350fc22 	lsr	x2, x1, #16
    6e38:	f949fc65 	ldr	x5, [x3, #5112]
    6e3c:	8b020842 	add	x2, x2, x2, lsl #2
    6e40:	d37df042 	lsl	x2, x2, #3
    6e44:	8b0200a4 	add	x4, x5, x2
    6e48:	f9401083 	ldr	x3, [x4, #32]
    6e4c:	b4fffe43 	cbz	x3, 6e14 <fwp_caps173+0x4>
    6e50:	386268a2 	ldrb	w2, [x5, x2]
    6e54:	7100085f 	cmp	w2, #0x2
    6e58:	540001c0 	b.eq	6e90 <fwp_caps173+0x80>  // b.none
    6e5c:	7100045f 	cmp	w2, #0x1
    6e60:	54fffda1 	b.ne	6e14 <fwp_caps173+0x4>  // b.any
    6e64:	29430885 	ldp	w5, w2, [x4, #24]
    6e68:	92403c21 	and	x1, x1, #0xffff
    6e6c:	9b057c21 	mul	x1, x1, x5
    6e70:	d360fc21 	lsr	x1, x1, #32
    6e74:	eb02003f 	cmp	x1, x2
    6e78:	54fffce2 	b.cs	6e14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e7c:	8b010063 	add	x3, x3, x1
    6e80:	39400061 	ldrb	w1, [x3]
    6e84:	7100043f 	cmp	w1, #0x1
    6e88:	54fffc61 	b.ne	6e14 <fwp_caps173+0x4>  // b.any
    6e8c:	17fff57d 	b	4480 <fwp_mem_free>
    6e90:	72003c3f 	tst	w1, #0xffff
    6e94:	54ffff60 	b.eq	6e80 <fwp_caps173+0x70>  // b.none
    6e98:	d65f03c0 	ret
    6e9c:	d503201f 	nop

0000000000006ea0 <f37>:
    6ea0:	d10203ff 	sub	sp, sp, #0x80
    6ea4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6ea8:	f947f421 	ldr	x1, [x1, #4072]
    6eac:	a9027bfd 	stp	x29, x30, [sp, #32]
    6eb0:	910083fd 	add	x29, sp, #0x20
    6eb4:	a9045bf5 	stp	x21, x22, [sp, #64]
    6eb8:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    6ebc:	911742a3 	add	x3, x21, #0x5d0
    6ec0:	a90353f3 	stp	x19, x20, [sp, #48]
    6ec4:	aa0003f6 	mov	x22, x0
    6ec8:	a90563f7 	stp	x23, x24, [sp, #80]
    6ecc:	a9066bf9 	stp	x25, x26, [sp, #96]
    6ed0:	f949ec62 	ldr	x2, [x3, #5080]
    6ed4:	f9400024 	ldr	x4, [x1]
    6ed8:	f9000fe4 	str	x4, [sp, #24]
    6edc:	d2800004 	mov	x4, #0x0                   	// #0
    6ee0:	f949d861 	ldr	x1, [x3, #5040]
    6ee4:	d370bc42 	lsl	x2, x2, #16
    6ee8:	b4001820 	cbz	x0, 71ec <f37+0x34c>
    6eec:	f9400817 	ldr	x23, [x0, #16]
    6ef0:	cb0102e1 	sub	x1, x23, x1
    6ef4:	eb02003f 	cmp	x1, x2
    6ef8:	54000362 	b.cs	6f64 <f37+0xc4>  // b.hs, b.nlast
    6efc:	f949fc60 	ldr	x0, [x3, #5112]
    6f00:	d350fc22 	lsr	x2, x1, #16
    6f04:	8b020842 	add	x2, x2, x2, lsl #2
    6f08:	8b020c02 	add	x2, x0, x2, lsl #3
    6f0c:	f9401040 	ldr	x0, [x2, #32]
    6f10:	b40002a0 	cbz	x0, 6f64 <f37+0xc4>
    6f14:	39400043 	ldrb	w3, [x2]
    6f18:	7100087f 	cmp	w3, #0x2
    6f1c:	54001560 	b.eq	71c8 <f37+0x328>  // b.none
    6f20:	7100047f 	cmp	w3, #0x1
    6f24:	540001c1 	b.ne	6f5c <f37+0xbc>  // b.any
    6f28:	29430843 	ldp	w3, w2, [x2, #24]
    6f2c:	92403c21 	and	x1, x1, #0xffff
    6f30:	9b037c21 	mul	x1, x1, x3
    6f34:	d360fc21 	lsr	x1, x1, #32
    6f38:	eb02003f 	cmp	x1, x2
    6f3c:	54000102 	b.cs	6f5c <f37+0xbc>  // b.hs, b.nlast
    6f40:	8b010000 	add	x0, x0, x1
    6f44:	39400001 	ldrb	w1, [x0]
    6f48:	340000a1 	cbz	w1, 6f5c <f37+0xbc>
    6f4c:	7103f43f 	cmp	w1, #0xfd
    6f50:	54001808 	b.hi	7250 <f37+0x3b0>  // b.pmore
    6f54:	11000421 	add	w1, w1, #0x1
    6f58:	39000001 	strb	w1, [x0]
    6f5c:	d2800002 	mov	x2, #0x0                   	// #0
    6f60:	b40000f6 	cbz	x22, 6f7c <f37+0xdc>
    6f64:	aa1603e1 	mov	x1, x22
    6f68:	d2800002 	mov	x2, #0x0                   	// #0
    6f6c:	d503201f 	nop
    6f70:	f9400821 	ldr	x1, [x1, #16]
    6f74:	91000442 	add	x2, x2, #0x1
    6f78:	b5ffffc1 	cbnz	x1, 6f70 <f37+0xd0>
    6f7c:	b40013f7 	cbz	x23, 71f8 <f37+0x358>
    6f80:	aa1703e1 	mov	x1, x23
    6f84:	d2800003 	mov	x3, #0x0                   	// #0
    6f88:	f9400821 	ldr	x1, [x1, #16]
    6f8c:	91000463 	add	x3, x3, #0x1
    6f90:	b5ffffc1 	cbnz	x1, 6f88 <f37+0xe8>
    6f94:	eb02007f 	cmp	x3, x2
    6f98:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6f9c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6fa0:	eb00027f 	cmp	x19, x0
    6fa4:	540010a8 	b.hi	71b8 <f37+0x318>  // b.pmore
    6fa8:	d37ffa74 	lsl	x20, x19, #1
    6fac:	52800041 	mov	w1, #0x2                   	// #2
    6fb0:	91000680 	add	x0, x20, #0x1
    6fb4:	d37df000 	lsl	x0, x0, #3
    6fb8:	97fff7ee 	bl	4f70 <fwp_heap_alloc>
    6fbc:	aa0003f8 	mov	x24, x0
    6fc0:	911742a1 	add	x1, x21, #0x5d0
    6fc4:	aa0103e0 	mov	x0, x1
    6fc8:	f9000314 	str	x20, [x24]
    6fcc:	f949d821 	ldr	x1, [x1, #5040]
    6fd0:	f949ec00 	ldr	x0, [x0, #5080]
    6fd4:	cb010301 	sub	x1, x24, x1
    6fd8:	eb00403f 	cmp	x1, x0, lsl #16
    6fdc:	54000342 	b.cs	7044 <f37+0x1a4>  // b.hs, b.nlast
    6fe0:	911742a2 	add	x2, x21, #0x5d0
    6fe4:	d350fc20 	lsr	x0, x1, #16
    6fe8:	8b000800 	add	x0, x0, x0, lsl #2
    6fec:	f949fc43 	ldr	x3, [x2, #5112]
    6ff0:	d37df002 	lsl	x2, x0, #3
    6ff4:	8b020060 	add	x0, x3, x2
    6ff8:	f9401014 	ldr	x20, [x0, #32]
    6ffc:	b4000254 	cbz	x20, 7044 <f37+0x1a4>
    7000:	38626862 	ldrb	w2, [x3, x2]
    7004:	7100085f 	cmp	w2, #0x2
    7008:	54000ec0 	b.eq	71e0 <f37+0x340>  // b.none
    700c:	7100045f 	cmp	w2, #0x1
    7010:	540001a1 	b.ne	7044 <f37+0x1a4>  // b.any
    7014:	29430002 	ldp	w2, w0, [x0, #24]
    7018:	92403c21 	and	x1, x1, #0xffff
    701c:	9b027c21 	mul	x1, x1, x2
    7020:	d360fc21 	lsr	x1, x1, #32
    7024:	eb00003f 	cmp	x1, x0
    7028:	540000e2 	b.cs	7044 <f37+0x1a4>  // b.hs, b.nlast
    702c:	8b010294 	add	x20, x20, x1
    7030:	39400280 	ldrb	w0, [x20]
    7034:	7103fc1f 	cmp	w0, #0xff
    7038:	54001100 	b.eq	7258 <f37+0x3b8>  // b.none
    703c:	52800020 	mov	w0, #0x1                   	// #1
    7040:	39000280 	strb	w0, [x20]
    7044:	b4000253 	cbz	x19, 708c <f37+0x1ec>
    7048:	8b131313 	add	x19, x24, x19, lsl #4
    704c:	aa1803f4 	mov	x20, x24
    7050:	aa1603fa 	mov	x26, x22
    7054:	aa1703f9 	mov	x25, x23
    7058:	f9400723 	ldr	x3, [x25, #8]
    705c:	f9400742 	ldr	x2, [x26, #8]
    7060:	f9400861 	ldr	x1, [x3, #16]
    7064:	f9400840 	ldr	x0, [x2, #16]
    7068:	fd400461 	ldr	d1, [x3, #8]
    706c:	fd400440 	ldr	d0, [x2, #8]
    7070:	97fff92d 	bl	5524 <w120>
    7074:	f9000680 	str	x0, [x20, #8]
    7078:	f8010e81 	str	x1, [x20, #16]!
    707c:	f9400b39 	ldr	x25, [x25, #16]
    7080:	f9400b5a 	ldr	x26, [x26, #16]
    7084:	eb14027f 	cmp	x19, x20
    7088:	54fffe81 	b.ne	7058 <f37+0x1b8>  // b.any
    708c:	aa1703e0 	mov	x0, x23
    7090:	97fffd20 	bl	6510 <fwp_drop4>
    7094:	aa1603e0 	mov	x0, x22
    7098:	97fffd1e 	bl	6510 <fwp_drop4>
    709c:	f9400316 	ldr	x22, [x24]
    70a0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    70a4:	b4000236 	cbz	x22, 70e8 <f37+0x248>
    70a8:	fd003be8 	str	d8, [sp, #112]
    70ac:	2f00e408 	movi	d8, #0x0
    70b0:	91002319 	add	x25, x24, #0x8
    70b4:	91004317 	add	x23, x24, #0x10
    70b8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    70bc:	d2800013 	mov	x19, #0x0                   	// #0
    70c0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    70c4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    70c8:	91000a73 	add	x19, x19, #0x2
    70cc:	1e602908 	fadd	d8, d8, d0
    70d0:	97fff8c4 	bl	53e0 <f141.constprop.0>
    70d4:	aa0003f4 	mov	x20, x0
    70d8:	eb1302df 	cmp	x22, x19
    70dc:	54ffff28 	b.hi	70c0 <f37+0x220>  // b.pmore
    70e0:	9e660116 	fmov	x22, d8
    70e4:	fd403be8 	ldr	d8, [sp, #112]
    70e8:	911742b5 	add	x21, x21, #0x5d0
    70ec:	aa1803e0 	mov	x0, x24
    70f0:	97fffec4 	bl	6c00 <fwp_drop10>
    70f4:	a900d3f6 	stp	x22, x20, [sp, #8]
    70f8:	910023e1 	add	x1, sp, #0x8
    70fc:	52800000 	mov	w0, #0x0                   	// #0
    7100:	97fff7e1 	bl	5084 <fwp_data.part.0.constprop.0>
    7104:	f949daa1 	ldr	x1, [x21, #5040]
    7108:	aa0003f3 	mov	x19, x0
    710c:	f949eea0 	ldr	x0, [x21, #5080]
    7110:	cb010261 	sub	x1, x19, x1
    7114:	eb00403f 	cmp	x1, x0, lsl #16
    7118:	54000322 	b.cs	717c <f37+0x2dc>  // b.hs, b.nlast
    711c:	d350fc22 	lsr	x2, x1, #16
    7120:	f949fea3 	ldr	x3, [x21, #5112]
    7124:	8b020842 	add	x2, x2, x2, lsl #2
    7128:	d37df042 	lsl	x2, x2, #3
    712c:	8b020060 	add	x0, x3, x2
    7130:	f9401014 	ldr	x20, [x0, #32]
    7134:	b4000254 	cbz	x20, 717c <f37+0x2dc>
    7138:	38626862 	ldrb	w2, [x3, x2]
    713c:	7100085f 	cmp	w2, #0x2
    7140:	540004a0 	b.eq	71d4 <f37+0x334>  // b.none
    7144:	7100045f 	cmp	w2, #0x1
    7148:	540001a1 	b.ne	717c <f37+0x2dc>  // b.any
    714c:	29430002 	ldp	w2, w0, [x0, #24]
    7150:	92403c21 	and	x1, x1, #0xffff
    7154:	9b027c21 	mul	x1, x1, x2
    7158:	d360fc21 	lsr	x1, x1, #32
    715c:	eb00003f 	cmp	x1, x0
    7160:	540000e2 	b.cs	717c <f37+0x2dc>  // b.hs, b.nlast
    7164:	8b010294 	add	x20, x20, x1
    7168:	39400280 	ldrb	w0, [x20]
    716c:	7103fc1f 	cmp	w0, #0xff
    7170:	540007a0 	b.eq	7264 <f37+0x3c4>  // b.none
    7174:	52800020 	mov	w0, #0x1                   	// #1
    7178:	39000280 	strb	w0, [x20]
    717c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7180:	f947f400 	ldr	x0, [x0, #4072]
    7184:	f9400fe2 	ldr	x2, [sp, #24]
    7188:	f9400001 	ldr	x1, [x0]
    718c:	eb010042 	subs	x2, x2, x1
    7190:	d2800001 	mov	x1, #0x0                   	// #0
    7194:	54000721 	b.ne	7278 <f37+0x3d8>  // b.any
    7198:	a9427bfd 	ldp	x29, x30, [sp, #32]
    719c:	aa1303e0 	mov	x0, x19
    71a0:	a94353f3 	ldp	x19, x20, [sp, #48]
    71a4:	a9445bf5 	ldp	x21, x22, [sp, #64]
    71a8:	a94563f7 	ldp	x23, x24, [sp, #80]
    71ac:	a9466bf9 	ldp	x25, x26, [sp, #96]
    71b0:	910203ff 	add	sp, sp, #0x80
    71b4:	d65f03c0 	ret
    71b8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    71bc:	910d4000 	add	x0, x0, #0x350
    71c0:	fd003be8 	str	d8, [sp, #112]
    71c4:	97fff3f3 	bl	4190 <fwp_trap>
    71c8:	72003c3f 	tst	w1, #0xffff
    71cc:	54ffec81 	b.ne	6f5c <f37+0xbc>  // b.any
    71d0:	17ffff5d 	b	6f44 <f37+0xa4>
    71d4:	72003c3f 	tst	w1, #0xffff
    71d8:	54fffd21 	b.ne	717c <f37+0x2dc>  // b.any
    71dc:	17ffffe3 	b	7168 <f37+0x2c8>
    71e0:	72003c3f 	tst	w1, #0xffff
    71e4:	54fff301 	b.ne	7044 <f37+0x1a4>  // b.any
    71e8:	17ffff92 	b	7030 <f37+0x190>
    71ec:	cb0103e1 	neg	x1, x1
    71f0:	eb02003f 	cmp	x1, x2
    71f4:	540001e3 	b.cc	7230 <f37+0x390>  // b.lo, b.ul, b.last
    71f8:	52800041 	mov	w1, #0x2                   	// #2
    71fc:	d2800100 	mov	x0, #0x8                   	// #8
    7200:	97fff75c 	bl	4f70 <fwp_heap_alloc>
    7204:	aa0003f8 	mov	x24, x0
    7208:	911742a0 	add	x0, x21, #0x5d0
    720c:	f900031f 	str	xzr, [x24]
    7210:	f949d801 	ldr	x1, [x0, #5040]
    7214:	f949ec00 	ldr	x0, [x0, #5080]
    7218:	cb010301 	sub	x1, x24, x1
    721c:	eb00403f 	cmp	x1, x0, lsl #16
    7220:	54000282 	b.cs	7270 <f37+0x3d0>  // b.hs, b.nlast
    7224:	d2800013 	mov	x19, #0x0                   	// #0
    7228:	d2800017 	mov	x23, #0x0                   	// #0
    722c:	17ffff6d 	b	6fe0 <f37+0x140>
    7230:	f949fc62 	ldr	x2, [x3, #5112]
    7234:	d350fc20 	lsr	x0, x1, #16
    7238:	8b000800 	add	x0, x0, x0, lsl #2
    723c:	8b000c42 	add	x2, x2, x0, lsl #3
    7240:	f9401040 	ldr	x0, [x2, #32]
    7244:	b4fffda0 	cbz	x0, 71f8 <f37+0x358>
    7248:	d2800017 	mov	x23, #0x0                   	// #0
    724c:	17ffff32 	b	6f14 <f37+0x74>
    7250:	97fff505 	bl	4664 <fwp_rc_wide_dup>
    7254:	17ffff42 	b	6f5c <f37+0xbc>
    7258:	aa1403e0 	mov	x0, x20
    725c:	97fff3ed 	bl	4210 <fwp_rc_forget_slot.part.0>
    7260:	17ffff77 	b	703c <f37+0x19c>
    7264:	aa1403e0 	mov	x0, x20
    7268:	97fff3ea 	bl	4210 <fwp_rc_forget_slot.part.0>
    726c:	17ffffc2 	b	7174 <f37+0x2d4>
    7270:	d2800017 	mov	x23, #0x0                   	// #0
    7274:	17ffff86 	b	708c <f37+0x1ec>
    7278:	fd003be8 	str	d8, [sp, #112]
    727c:	97ffeda5 	bl	2910 <__stack_chk_fail@plt>

0000000000007280 <fwp_owned_entry37>:
    7280:	f9400000 	ldr	x0, [x0]
    7284:	17ffff07 	b	6ea0 <f37>
    7288:	d503201f 	nop
    728c:	d503201f 	nop

0000000000007290 <e37>:
    7290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7294:	910003fd 	mov	x29, sp
    7298:	f9000bf3 	str	x19, [sp, #16]
    729c:	f9400013 	ldr	x19, [x0]
    72a0:	aa1303e0 	mov	x0, x19
    72a4:	97fff9b3 	bl	5970 <fwp_rc_share>
    72a8:	aa1303e0 	mov	x0, x19
    72ac:	97fffefd 	bl	6ea0 <f37>
    72b0:	aa0003f3 	mov	x19, x0
    72b4:	97fff9af 	bl	5970 <fwp_rc_share>
    72b8:	aa1303e0 	mov	x0, x19
    72bc:	f9400bf3 	ldr	x19, [sp, #16]
    72c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72c4:	d65f03c0 	ret
    72c8:	d503201f 	nop
    72cc:	d503201f 	nop

00000000000072d0 <fwp_args37>:
    72d0:	7100003f 	cmp	w1, #0x0
    72d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    72d8:	54000041 	b.ne	72e0 <fwp_args37+0x10>  // b.any
    72dc:	d65f03c0 	ret
    72e0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    72e4:	91174042 	add	x2, x2, #0x5d0
    72e8:	f9400001 	ldr	x1, [x0]
    72ec:	f949d843 	ldr	x3, [x2, #5040]
    72f0:	f949ec40 	ldr	x0, [x2, #5080]
    72f4:	cb030021 	sub	x1, x1, x3
    72f8:	eb00403f 	cmp	x1, x0, lsl #16
    72fc:	54ffff02 	b.cs	72dc <fwp_args37+0xc>  // b.hs, b.nlast
    7300:	d350fc20 	lsr	x0, x1, #16
    7304:	f949fc44 	ldr	x4, [x2, #5112]
    7308:	8b000800 	add	x0, x0, x0, lsl #2
    730c:	d37df002 	lsl	x2, x0, #3
    7310:	8b020083 	add	x3, x4, x2
    7314:	f9401060 	ldr	x0, [x3, #32]
    7318:	b4fffe20 	cbz	x0, 72dc <fwp_args37+0xc>
    731c:	38626882 	ldrb	w2, [x4, x2]
    7320:	7100085f 	cmp	w2, #0x2
    7324:	54000220 	b.eq	7368 <fwp_args37+0x98>  // b.none
    7328:	7100045f 	cmp	w2, #0x1
    732c:	54fffd81 	b.ne	72dc <fwp_args37+0xc>  // b.any
    7330:	29430864 	ldp	w4, w2, [x3, #24]
    7334:	92403c21 	and	x1, x1, #0xffff
    7338:	9b047c21 	mul	x1, x1, x4
    733c:	d360fc21 	lsr	x1, x1, #32
    7340:	eb02003f 	cmp	x1, x2
    7344:	54fffcc2 	b.cs	72dc <fwp_args37+0xc>  // b.hs, b.nlast
    7348:	8b010000 	add	x0, x0, x1
    734c:	39400001 	ldrb	w1, [x0]
    7350:	34fffc61 	cbz	w1, 72dc <fwp_args37+0xc>
    7354:	7103f43f 	cmp	w1, #0xfd
    7358:	540000e8 	b.hi	7374 <fwp_args37+0xa4>  // b.pmore
    735c:	11000421 	add	w1, w1, #0x1
    7360:	39000001 	strb	w1, [x0]
    7364:	d65f03c0 	ret
    7368:	72003c3f 	tst	w1, #0xffff
    736c:	54ffff00 	b.eq	734c <fwp_args37+0x7c>  // b.none
    7370:	d65f03c0 	ret
    7374:	17fff4bc 	b	4664 <fwp_rc_wide_dup>
    7378:	d503201f 	nop
    737c:	d503201f 	nop

0000000000007380 <fwp_caps37>:
    7380:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7384:	910003fd 	mov	x29, sp
    7388:	f9000bf3 	str	x19, [sp, #16]
    738c:	aa0003f3 	mov	x19, x0
    7390:	b9400400 	ldr	w0, [x0, #4]
    7394:	340004a0 	cbz	w0, 7428 <fwp_caps37+0xa8>
    7398:	f9400660 	ldr	x0, [x19, #8]
    739c:	350004e1 	cbnz	w1, 7438 <fwp_caps37+0xb8>
    73a0:	97fffc5c 	bl	6510 <fwp_drop4>
    73a4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    73a8:	91174042 	add	x2, x2, #0x5d0
    73ac:	f949d840 	ldr	x0, [x2, #5040]
    73b0:	f949ec41 	ldr	x1, [x2, #5080]
    73b4:	cb000260 	sub	x0, x19, x0
    73b8:	eb01401f 	cmp	x0, x1, lsl #16
    73bc:	54000382 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    73c0:	d350fc01 	lsr	x1, x0, #16
    73c4:	f949fc44 	ldr	x4, [x2, #5112]
    73c8:	8b010821 	add	x1, x1, x1, lsl #2
    73cc:	d37df021 	lsl	x1, x1, #3
    73d0:	8b010083 	add	x3, x4, x1
    73d4:	f9401062 	ldr	x2, [x3, #32]
    73d8:	b40002a2 	cbz	x2, 742c <fwp_caps37+0xac>
    73dc:	38616881 	ldrb	w1, [x4, x1]
    73e0:	7100083f 	cmp	w1, #0x2
    73e4:	540006c0 	b.eq	74bc <fwp_caps37+0x13c>  // b.none
    73e8:	7100043f 	cmp	w1, #0x1
    73ec:	54000201 	b.ne	742c <fwp_caps37+0xac>  // b.any
    73f0:	29430464 	ldp	w4, w1, [x3, #24]
    73f4:	92403c00 	and	x0, x0, #0xffff
    73f8:	9b047c00 	mul	x0, x0, x4
    73fc:	d360fc00 	lsr	x0, x0, #32
    7400:	eb01001f 	cmp	x0, x1
    7404:	54000142 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    7408:	8b000042 	add	x2, x2, x0
    740c:	39400040 	ldrb	w0, [x2]
    7410:	7100041f 	cmp	w0, #0x1
    7414:	540000c1 	b.ne	742c <fwp_caps37+0xac>  // b.any
    7418:	aa1303e0 	mov	x0, x19
    741c:	f9400bf3 	ldr	x19, [sp, #16]
    7420:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7424:	17fff417 	b	4480 <fwp_mem_free>
    7428:	34fffbe1 	cbz	w1, 73a4 <fwp_caps37+0x24>
    742c:	f9400bf3 	ldr	x19, [sp, #16]
    7430:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7434:	d65f03c0 	ret
    7438:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    743c:	91174042 	add	x2, x2, #0x5d0
    7440:	f949d843 	ldr	x3, [x2, #5040]
    7444:	f949ec41 	ldr	x1, [x2, #5080]
    7448:	cb030000 	sub	x0, x0, x3
    744c:	eb01401f 	cmp	x0, x1, lsl #16
    7450:	54fffee2 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    7454:	d350fc01 	lsr	x1, x0, #16
    7458:	f949fc44 	ldr	x4, [x2, #5112]
    745c:	8b010821 	add	x1, x1, x1, lsl #2
    7460:	d37df021 	lsl	x1, x1, #3
    7464:	8b010083 	add	x3, x4, x1
    7468:	f9401062 	ldr	x2, [x3, #32]
    746c:	b4fffe02 	cbz	x2, 742c <fwp_caps37+0xac>
    7470:	38616881 	ldrb	w1, [x4, x1]
    7474:	7100083f 	cmp	w1, #0x2
    7478:	54000280 	b.eq	74c8 <fwp_caps37+0x148>  // b.none
    747c:	7100043f 	cmp	w1, #0x1
    7480:	54fffd61 	b.ne	742c <fwp_caps37+0xac>  // b.any
    7484:	92403c01 	and	x1, x0, #0xffff
    7488:	29430064 	ldp	w4, w0, [x3, #24]
    748c:	9b047c21 	mul	x1, x1, x4
    7490:	d360fc21 	lsr	x1, x1, #32
    7494:	eb00003f 	cmp	x1, x0
    7498:	54fffca2 	b.cs	742c <fwp_caps37+0xac>  // b.hs, b.nlast
    749c:	8b010042 	add	x2, x2, x1
    74a0:	39400040 	ldrb	w0, [x2]
    74a4:	34fffc40 	cbz	w0, 742c <fwp_caps37+0xac>
    74a8:	7103f41f 	cmp	w0, #0xfd
    74ac:	54000148 	b.hi	74d4 <fwp_caps37+0x154>  // b.pmore
    74b0:	11000400 	add	w0, w0, #0x1
    74b4:	39000040 	strb	w0, [x2]
    74b8:	17ffffdd 	b	742c <fwp_caps37+0xac>
    74bc:	72003c1f 	tst	w0, #0xffff
    74c0:	54fffb61 	b.ne	742c <fwp_caps37+0xac>  // b.any
    74c4:	17ffffd2 	b	740c <fwp_caps37+0x8c>
    74c8:	72003c1f 	tst	w0, #0xffff
    74cc:	54fffb01 	b.ne	742c <fwp_caps37+0xac>  // b.any
    74d0:	17fffff4 	b	74a0 <fwp_caps37+0x120>
    74d4:	f9400bf3 	ldr	x19, [sp, #16]
    74d8:	aa0203e0 	mov	x0, x2
    74dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74e0:	17fff461 	b	4664 <fwp_rc_wide_dup>

00000000000074e4 <fwp_write>:
    74e4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    74e8:	910003fd 	mov	x29, sp
    74ec:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    74f0:	f947f484 	ldr	x4, [x4, #4072]
    74f4:	a90153f3 	stp	x19, x20, [sp, #16]
    74f8:	d10943ff 	sub	sp, sp, #0x250
    74fc:	b9400045 	ldr	w5, [x2]
    7500:	aa0003f4 	mov	x20, x0
    7504:	f9400080 	ldr	x0, [x4]
    7508:	f90127e0 	str	x0, [sp, #584]
    750c:	d2800000 	mov	x0, #0x0                   	// #0
    7510:	710064bf 	cmp	w5, #0x19
    7514:	54000408 	b.hi	7594 <fwp_write+0xb0>  // b.pmore
    7518:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    751c:	aa0103f3 	mov	x19, x1
    7520:	91308000 	add	x0, x0, #0xc20
    7524:	f9013bf5 	str	x21, [sp, #624]
    7528:	f9013ff6 	str	x22, [sp, #632]
    752c:	f90153fb 	str	x27, [sp, #672]
    7530:	f90157fc 	str	x28, [sp, #680]
    7534:	aa0203fc 	mov	x28, x2
    7538:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    753c:	10000061 	adr	x1, 7548 <fwp_write+0x64>
    7540:	8b20a820 	add	x0, x1, w0, sxth #2
    7544:	d61f0000 	br	x0
    7548:	910123e0 	add	x0, sp, #0x48
    754c:	aa1303e5 	mov	x5, x19
    7550:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x150>
    7554:	aa0003f3 	mov	x19, x0
    7558:	910e6084 	add	x4, x4, #0x398
    755c:	d2804003 	mov	x3, #0x200                 	// #512
    7560:	aa0303e1 	mov	x1, x3
    7564:	52800042 	mov	w2, #0x2                   	// #2
    7568:	97ffecc6 	bl	2880 <__snprintf_chk@plt>
    756c:	aa1303e0 	mov	x0, x19
    7570:	97ffec8c 	bl	27a0 <strlen@plt>
    7574:	aa1303e1 	mov	x1, x19
    7578:	aa0003e2 	mov	x2, x0
    757c:	aa1403e0 	mov	x0, x20
    7580:	97fff024 	bl	3610 <buf_put>
    7584:	f9413bf5 	ldr	x21, [sp, #624]
    7588:	f9413ff6 	ldr	x22, [sp, #632]
    758c:	f94153fb 	ldr	x27, [sp, #672]
    7590:	f94157fc 	ldr	x28, [sp, #680]
    7594:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7598:	f947f400 	ldr	x0, [x0, #4072]
    759c:	f94127e2 	ldr	x2, [sp, #584]
    75a0:	f9400001 	ldr	x1, [x0]
    75a4:	eb010042 	subs	x2, x2, x1
    75a8:	d2800001 	mov	x1, #0x0                   	// #0
    75ac:	540077a1 	b.ne	84a0 <fwp_write+0xfbc>  // b.any
    75b0:	910943ff 	add	sp, sp, #0x250
    75b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    75b8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    75bc:	d65f03c0 	ret
    75c0:	910123e0 	add	x0, sp, #0x48
    75c4:	aa1303e5 	mov	x5, x19
    75c8:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x150>
    75cc:	aa0003f3 	mov	x19, x0
    75d0:	910e4084 	add	x4, x4, #0x390
    75d4:	d2804003 	mov	x3, #0x200                 	// #512
    75d8:	17ffffe2 	b	7560 <fwp_write+0x7c>
    75dc:	71004cbf 	cmp	w5, #0x13
    75e0:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x150>
    75e4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    75e8:	910e0000 	add	x0, x0, #0x380
    75ec:	910e2021 	add	x1, x1, #0x388
    75f0:	d2800082 	mov	x2, #0x4                   	// #4
    75f4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	f90143f7 	str	x23, [sp, #640]
    7600:	d2800016 	mov	x22, #0x0                   	// #0
    7604:	f90147f8 	str	x24, [sp, #648]
    7608:	97fff002 	bl	3610 <buf_put>
    760c:	f9400260 	ldr	x0, [x19]
    7610:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x150>
    7614:	d2800015 	mov	x21, #0x0                   	// #0
    7618:	911022f7 	add	x23, x23, #0x408
    761c:	b4004780 	cbz	x0, 7f0c <fwp_write+0xa28>
    7620:	b9400380 	ldr	w0, [x28]
    7624:	52800003 	mov	w3, #0x0                   	// #0
    7628:	f9401f82 	ldr	x2, [x28, #56]
    762c:	71004c1f 	cmp	w0, #0x13
    7630:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7634:	aa1403e0 	mov	x0, x20
    7638:	8b010e61 	add	x1, x19, x1, lsl #3
    763c:	f9400421 	ldr	x1, [x1, #8]
    7640:	97ffffa9 	bl	74e4 <fwp_write>
    7644:	b9400380 	ldr	w0, [x28]
    7648:	7100481f 	cmp	w0, #0x12
    764c:	54004b20 	b.eq	7fb0 <fwp_write+0xacc>  // b.none
    7650:	f9400260 	ldr	x0, [x19]
    7654:	910006b5 	add	x21, x21, #0x1
    7658:	91000ad6 	add	x22, x22, #0x2
    765c:	eb15001f 	cmp	x0, x21
    7660:	54004569 	b.ls	7f0c <fwp_write+0xa28>  // b.plast
    7664:	aa1703e1 	mov	x1, x23
    7668:	aa1403e0 	mov	x0, x20
    766c:	d2800042 	mov	x2, #0x2                   	// #2
    7670:	97ffefe8 	bl	3610 <buf_put>
    7674:	17ffffeb 	b	7620 <fwp_write+0x13c>
    7678:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    767c:	910f0021 	add	x1, x1, #0x3c0
    7680:	d28000c2 	mov	x2, #0x6                   	// #6
    7684:	aa1403e0 	mov	x0, x20
    7688:	91004273 	add	x19, x19, #0x10
    768c:	97ffefe1 	bl	3610 <buf_put>
    7690:	aa1303e0 	mov	x0, x19
    7694:	97ffec43 	bl	27a0 <strlen@plt>
    7698:	aa1303e1 	mov	x1, x19
    769c:	aa0003e2 	mov	x2, x0
    76a0:	aa1403e0 	mov	x0, x20
    76a4:	97ffefdb 	bl	3610 <buf_put>
    76a8:	528007c3 	mov	w3, #0x3e                  	// #62
    76ac:	aa1403e0 	mov	x0, x20
    76b0:	91001fe1 	add	x1, sp, #0x7
    76b4:	d2800022 	mov	x2, #0x1                   	// #1
    76b8:	39001fe3 	strb	w3, [sp, #7]
    76bc:	17ffffb1 	b	7580 <fwp_write+0x9c>
    76c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76c4:	f947f400 	ldr	x0, [x0, #4072]
    76c8:	f94127e2 	ldr	x2, [sp, #584]
    76cc:	f9400001 	ldr	x1, [x0]
    76d0:	eb010042 	subs	x2, x2, x1
    76d4:	d2800001 	mov	x1, #0x0                   	// #0
    76d8:	540034c1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    76dc:	f9413bf5 	ldr	x21, [sp, #624]
    76e0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    76e4:	f9413ff6 	ldr	x22, [sp, #632]
    76e8:	aa1403e0 	mov	x0, x20
    76ec:	910e8021 	add	x1, x1, #0x3a0
    76f0:	d2800142 	mov	x2, #0xa                   	// #10
    76f4:	f94153fb 	ldr	x27, [sp, #672]
    76f8:	f94157fc 	ldr	x28, [sp, #680]
    76fc:	910943ff 	add	sp, sp, #0x250
    7700:	a94153f3 	ldp	x19, x20, [sp, #16]
    7704:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7708:	17ffefc2 	b	3610 <buf_put>
    770c:	f9400456 	ldr	x22, [x2, #8]
    7710:	f90143f7 	str	x23, [sp, #640]
    7714:	f90147f8 	str	x24, [sp, #648]
    7718:	b4005af6 	cbz	x22, 8274 <fwp_write+0xd90>
    771c:	aa1603e0 	mov	x0, x22
    7720:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7724:	91108021 	add	x1, x1, #0x420
    7728:	97ffec9a 	bl	2990 <strcmp@plt>
    772c:	2a0003f5 	mov	w21, w0
    7730:	34005fc0 	cbz	w0, 8328 <fwp_write+0xe44>
    7734:	aa1603e0 	mov	x0, x22
    7738:	97ffec1a 	bl	27a0 <strlen@plt>
    773c:	aa1603e1 	mov	x1, x22
    7740:	aa0003e2 	mov	x2, x0
    7744:	aa1403e0 	mov	x0, x20
    7748:	97ffefb2 	bl	3610 <buf_put>
    774c:	52800403 	mov	w3, #0x20                  	// #32
    7750:	91001ff5 	add	x21, sp, #0x7
    7754:	aa1503e1 	mov	x1, x21
    7758:	aa1403e0 	mov	x0, x20
    775c:	d2800022 	mov	x2, #0x1                   	// #1
    7760:	39001fe3 	strb	w3, [sp, #7]
    7764:	97ffefab 	bl	3610 <buf_put>
    7768:	52800f63 	mov	w3, #0x7b                  	// #123
    776c:	aa1403e0 	mov	x0, x20
    7770:	aa1503e1 	mov	x1, x21
    7774:	d2800022 	mov	x2, #0x1                   	// #1
    7778:	39001fe3 	strb	w3, [sp, #7]
    777c:	97ffefa5 	bl	3610 <buf_put>
    7780:	b9401380 	ldr	w0, [x28, #16]
    7784:	52800018 	mov	w24, #0x0                   	// #0
    7788:	7100001f 	cmp	w0, #0x0
    778c:	54003a8d 	b.le	7edc <fwp_write+0x9f8>
    7790:	f9014bf9 	str	x25, [sp, #656]
    7794:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x150>
    7798:	91112339 	add	x25, x25, #0x448
    779c:	f9014ffa 	str	x26, [sp, #664]
    77a0:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x150>
    77a4:	9110235a 	add	x26, x26, #0x408
    77a8:	91002276 	add	x22, x19, #0x8
    77ac:	d2800013 	mov	x19, #0x0                   	// #0
    77b0:	b5003e73 	cbnz	x19, 7f7c <fwp_write+0xa98>
    77b4:	d37df277 	lsl	x23, x19, #3
    77b8:	34003c98 	cbz	w24, 7f48 <fwp_write+0xa64>
    77bc:	f9401382 	ldr	x2, [x28, #32]
    77c0:	aa1403e0 	mov	x0, x20
    77c4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    77c8:	52800003 	mov	w3, #0x0                   	// #0
    77cc:	f8776842 	ldr	x2, [x2, x23]
    77d0:	91000673 	add	x19, x19, #0x1
    77d4:	97ffff44 	bl	74e4 <fwp_write>
    77d8:	b9401380 	ldr	w0, [x28, #16]
    77dc:	6b13001f 	cmp	w0, w19
    77e0:	54fffe8c 	b.gt	77b0 <fwp_write+0x2cc>
    77e4:	f9414bf9 	ldr	x25, [sp, #656]
    77e8:	f9414ffa 	ldr	x26, [sp, #664]
    77ec:	34003798 	cbz	w24, 7edc <fwp_write+0x9f8>
    77f0:	52800523 	mov	w3, #0x29                  	// #41
    77f4:	aa1503e1 	mov	x1, x21
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	d2800022 	mov	x2, #0x1                   	// #1
    7800:	39001fe3 	strb	w3, [sp, #7]
    7804:	97ffef83 	bl	3610 <buf_put>
    7808:	f9413bf5 	ldr	x21, [sp, #624]
    780c:	f9413ff6 	ldr	x22, [sp, #632]
    7810:	f94143f7 	ldr	x23, [sp, #640]
    7814:	f94147f8 	ldr	x24, [sp, #648]
    7818:	f94153fb 	ldr	x27, [sp, #672]
    781c:	f94157fc 	ldr	x28, [sp, #680]
    7820:	17ffff5d 	b	7594 <fwp_write+0xb0>
    7824:	b9404855 	ldr	w21, [x2, #72]
    7828:	aa1403e0 	mov	x0, x20
    782c:	93407eb6 	sxtw	x22, w21
    7830:	91000ac1 	add	x1, x22, #0x2
    7834:	97ffef44 	bl	3544 <buf_grow>
    7838:	a9400281 	ldp	x1, x0, [x20]
    783c:	528e8603 	mov	w3, #0x7430                	// #29744
    7840:	78206823 	strh	w3, [x1, x0]
    7844:	8b000022 	add	x2, x1, x0
    7848:	710002bf 	cmp	w21, #0x0
    784c:	540036ad 	b.le	7f20 <fwp_write+0xa3c>
    7850:	110006a3 	add	w3, w21, #0x1
    7854:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7858:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    785c:	91000449 	add	x9, x2, #0x1
    7860:	8b23c043 	add	x3, x2, w3, sxtw
    7864:	f28aaac6 	movk	x6, #0x5556
    7868:	f2955568 	movk	x8, #0xaaab
    786c:	1400000d 	b	78a0 <fwp_write+0x3bc>
    7870:	d2800021 	mov	x1, #0x1                   	// #1
    7874:	528005a5 	mov	w5, #0x2d                  	// #45
    7878:	f100001f 	cmp	x0, #0x0
    787c:	9b467e60 	smulh	x0, x19, x6
    7880:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7884:	381ff465 	strb	w5, [x3], #-1
    7888:	cb040000 	sub	x0, x0, x4
    788c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7890:	cb020000 	sub	x0, x0, x2
    7894:	8b010013 	add	x19, x0, x1
    7898:	eb03013f 	cmp	x9, x3
    789c:	54003420 	b.eq	7f20 <fwp_write+0xa3c>  // b.none
    78a0:	9b467e60 	smulh	x0, x19, x6
    78a4:	937ffe64 	asr	x4, x19, #63
    78a8:	52800605 	mov	w5, #0x30                  	// #48
    78ac:	cb040000 	sub	x0, x0, x4
    78b0:	8b000400 	add	x0, x0, x0, lsl #1
    78b4:	cb000260 	sub	x0, x19, x0
    78b8:	91000c01 	add	x1, x0, #0x3
    78bc:	9bc87c22 	umulh	x2, x1, x8
    78c0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    78c4:	8b4204e2 	add	x2, x7, x2, lsr #1
    78c8:	eb020021 	subs	x1, x1, x2
    78cc:	54fffd60 	b.eq	7878 <fwp_write+0x394>  // b.none
    78d0:	f100043f 	cmp	x1, #0x1
    78d4:	54fffce1 	b.ne	7870 <fwp_write+0x38c>  // b.any
    78d8:	d2800001 	mov	x1, #0x0                   	// #0
    78dc:	52800565 	mov	w5, #0x2b                  	// #43
    78e0:	17ffffe6 	b	7878 <fwp_write+0x394>
    78e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    78e8:	f947f400 	ldr	x0, [x0, #4072]
    78ec:	f94127e2 	ldr	x2, [sp, #584]
    78f0:	f9400001 	ldr	x1, [x0]
    78f4:	eb010042 	subs	x2, x2, x1
    78f8:	d2800001 	mov	x1, #0x0                   	// #0
    78fc:	540023a1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    7900:	f9413bf5 	ldr	x21, [sp, #624]
    7904:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7908:	f9413ff6 	ldr	x22, [sp, #632]
    790c:	aa1403e0 	mov	x0, x20
    7910:	910ec021 	add	x1, x1, #0x3b0
    7914:	d2800102 	mov	x2, #0x8                   	// #8
    7918:	17ffff77 	b	76f4 <fwp_write+0x210>
    791c:	aa1403e0 	mov	x0, x20
    7920:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7924:	d28000c2 	mov	x2, #0x6                   	// #6
    7928:	91104021 	add	x1, x1, #0x410
    792c:	97ffef39 	bl	3610 <buf_put>
    7930:	d2800015 	mov	x21, #0x0                   	// #0
    7934:	f9400263 	ldr	x3, [x19]
    7938:	f240f87f 	tst	x3, #0x7fffffffffffffff
    793c:	54002c40 	b.eq	7ec4 <fwp_write+0x9e0>  // b.none
    7940:	f9401f82 	ldr	x2, [x28, #56]
    7944:	f90143f7 	str	x23, [sp, #640]
    7948:	f90147f8 	str	x24, [sp, #648]
    794c:	d2800857 	mov	x23, #0x42                  	// #66
    7950:	f9014bf9 	str	x25, [sp, #656]
    7954:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x150>
    7958:	f9014ffa 	str	x26, [sp, #664]
    795c:	911022d6 	add	x22, x22, #0x408
    7960:	d2800038 	mov	x24, #0x1                   	// #1
    7964:	f2a18017 	movk	x23, #0xc00, lsl #16
    7968:	d2809099 	mov	x25, #0x484                 	// #1156
    796c:	b4000482 	cbz	x2, 79fc <fwp_write+0x518>
    7970:	b9400040 	ldr	w0, [x2]
    7974:	7100701f 	cmp	w0, #0x1c
    7978:	540042a0 	b.eq	81cc <fwp_write+0xce8>  // b.none
    797c:	71006c1f 	cmp	w0, #0x1b
    7980:	540003e8 	b.hi	79fc <fwp_write+0x518>  // b.pmore
    7984:	9ac02301 	lsl	x1, x24, x0
    7988:	ea17003f 	tst	x1, x23
    798c:	54003681 	b.ne	805c <fwp_write+0xb78>  // b.any
    7990:	ea19003f 	tst	x1, x25
    7994:	54003501 	b.ne	8034 <fwp_write+0xb50>  // b.any
    7998:	d2800424 	mov	x4, #0x21                  	// #33
    799c:	ea04003f 	tst	x1, x4
    79a0:	540002e0 	b.eq	79fc <fwp_write+0x518>  // b.none
    79a4:	b7f849a3 	tbnz	x3, #63, 82d8 <fwp_write+0xdf4>
    79a8:	91002261 	add	x1, x19, #0x8
    79ac:	8b150021 	add	x1, x1, x21
    79b0:	39400021 	ldrb	w1, [x1]
    79b4:	7100001f 	cmp	w0, #0x0
    79b8:	93401c23 	sxtb	x3, w1
    79bc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    79c0:	aa1403e0 	mov	x0, x20
    79c4:	52800003 	mov	w3, #0x0                   	// #0
    79c8:	97fffec7 	bl	74e4 <fwp_write>
    79cc:	910006b5 	add	x21, x21, #0x1
    79d0:	f9400260 	ldr	x0, [x19]
    79d4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    79d8:	eb0002bf 	cmp	x21, x0
    79dc:	540026c2 	b.cs	7eb4 <fwp_write+0x9d0>  // b.hs, b.nlast
    79e0:	d2800042 	mov	x2, #0x2                   	// #2
    79e4:	aa1603e1 	mov	x1, x22
    79e8:	aa1403e0 	mov	x0, x20
    79ec:	97ffef09 	bl	3610 <buf_put>
    79f0:	f9401f82 	ldr	x2, [x28, #56]
    79f4:	f9400263 	ldr	x3, [x19]
    79f8:	b5fffbc2 	cbnz	x2, 7970 <fwp_write+0x48c>
    79fc:	d37df2a0 	lsl	x0, x21, #3
    7a00:	b7f83f03 	tbnz	x3, #63, 81e0 <fwp_write+0xcfc>
    7a04:	91002261 	add	x1, x19, #0x8
    7a08:	8b000020 	add	x0, x1, x0
    7a0c:	f9400001 	ldr	x1, [x0]
    7a10:	17ffffec 	b	79c0 <fwp_write+0x4dc>
    7a14:	a9400e62 	ldp	x2, x3, [x19]
    7a18:	b7f83ca3 	tbnz	x3, #63, 81ac <fwp_write+0xcc8>
    7a1c:	910123f5 	add	x21, sp, #0x48
    7a20:	aa1503e0 	mov	x0, x21
    7a24:	97ffed1f 	bl	2ea0 <fwp_fmt_u128>
    7a28:	aa1503e0 	mov	x0, x21
    7a2c:	97ffeb5d 	bl	27a0 <strlen@plt>
    7a30:	aa1503e1 	mov	x1, x21
    7a34:	aa0003e2 	mov	x2, x0
    7a38:	17fffed1 	b	757c <fwp_write+0x98>
    7a3c:	fd015be8 	str	d8, [sp, #688]
    7a40:	1e270268 	fmov	s8, w19
    7a44:	fd015fe9 	str	d9, [sp, #696]
    7a48:	1e282100 	fcmp	s8, s8
    7a4c:	54004d26 	b.vs	83f0 <fwp_write+0xf0c>
    7a50:	1e20c101 	fabs	s1, s8
    7a54:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7a58:	1e270000 	fmov	s0, w0
    7a5c:	1e202020 	fcmp	s1, s0
    7a60:	54002c0d 	b.le	7fe0 <fwp_write+0xafc>
    7a64:	1e202118 	fcmpe	s8, #0.0
    7a68:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1b30>
    7a6c:	913e2042 	add	x2, x2, #0xf88
    7a70:	910123f5 	add	x21, sp, #0x48
    7a74:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7a78:	910d8021 	add	x1, x1, #0x360
    7a7c:	aa1503e0 	mov	x0, x21
    7a80:	9a81c041 	csel	x1, x2, x1, gt
    7a84:	97ffebf3 	bl	2a50 <strcpy@plt>
    7a88:	aa1503e0 	mov	x0, x21
    7a8c:	97ffeb45 	bl	27a0 <strlen@plt>
    7a90:	aa1503e1 	mov	x1, x21
    7a94:	aa0003e2 	mov	x2, x0
    7a98:	aa1403e0 	mov	x0, x20
    7a9c:	97ffeedd 	bl	3610 <buf_put>
    7aa0:	f9413bf5 	ldr	x21, [sp, #624]
    7aa4:	f9413ff6 	ldr	x22, [sp, #632]
    7aa8:	f94153fb 	ldr	x27, [sp, #672]
    7aac:	f94157fc 	ldr	x28, [sp, #680]
    7ab0:	fd415be8 	ldr	d8, [sp, #688]
    7ab4:	fd415fe9 	ldr	d9, [sp, #696]
    7ab8:	17fffeb7 	b	7594 <fwp_write+0xb0>
    7abc:	f9400276 	ldr	x22, [x19]
    7ac0:	34002e03 	cbz	w3, 8080 <fwp_write+0xb9c>
    7ac4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ac8:	f947f400 	ldr	x0, [x0, #4072]
    7acc:	f94127e2 	ldr	x2, [sp, #584]
    7ad0:	f9400001 	ldr	x1, [x0]
    7ad4:	eb010042 	subs	x2, x2, x1
    7ad8:	d2800001 	mov	x1, #0x0                   	// #0
    7adc:	540014a1 	b.ne	7d70 <fwp_write+0x88c>  // b.any
    7ae0:	aa1603e2 	mov	x2, x22
    7ae4:	91002261 	add	x1, x19, #0x8
    7ae8:	f9413bf5 	ldr	x21, [sp, #624]
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	f9413ff6 	ldr	x22, [sp, #632]
    7af4:	17ffff00 	b	76f4 <fwp_write+0x210>
    7af8:	fd015be8 	str	d8, [sp, #688]
    7afc:	9e670268 	fmov	d8, x19
    7b00:	fd015fe9 	str	d9, [sp, #696]
    7b04:	1e682100 	fcmp	d8, d8
    7b08:	54004746 	b.vs	83f0 <fwp_write+0xf0c>
    7b0c:	1e60c101 	fabs	d1, d8
    7b10:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7b14:	9e670000 	fmov	d0, x0
    7b18:	910123f5 	add	x21, sp, #0x48
    7b1c:	52800033 	mov	w19, #0x1                   	// #1
    7b20:	1e602020 	fcmp	d1, d0
    7b24:	540001ad 	b.le	7b58 <fwp_write+0x674>
    7b28:	1e602118 	fcmpe	d8, #0.0
    7b2c:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1b30>
    7b30:	913e2042 	add	x2, x2, #0xf88
    7b34:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7b38:	910d8021 	add	x1, x1, #0x360
    7b3c:	aa1503e0 	mov	x0, x21
    7b40:	9a81c041 	csel	x1, x2, x1, gt
    7b44:	97ffebc3 	bl	2a50 <strcpy@plt>
    7b48:	17ffffd0 	b	7a88 <fwp_write+0x5a4>
    7b4c:	11000673 	add	w19, w19, #0x1
    7b50:	71004a7f 	cmp	w19, #0x12
    7b54:	54003860 	b.eq	8260 <fwp_write+0xd7c>  // b.none
    7b58:	1e604100 	fmov	d0, d8
    7b5c:	2a1303e1 	mov	w1, w19
    7b60:	aa1503e0 	mov	x0, x21
    7b64:	97ffef47 	bl	3880 <fwp_format_g.constprop.0>
    7b68:	aa1503e0 	mov	x0, x21
    7b6c:	d2800001 	mov	x1, #0x0                   	// #0
    7b70:	97ffeb20 	bl	27f0 <strtod@plt>
    7b74:	1e602100 	fcmp	d8, d0
    7b78:	54fffea1 	b.ne	7b4c <fwp_write+0x668>  // b.any
    7b7c:	aa1503e0 	mov	x0, x21
    7b80:	97ffef1d 	bl	37f4 <fwp_finish_float>
    7b84:	17ffffc1 	b	7a88 <fwp_write+0x5a4>
    7b88:	a9400e62 	ldp	x2, x3, [x19]
    7b8c:	910123f3 	add	x19, sp, #0x48
    7b90:	aa1303e0 	mov	x0, x19
    7b94:	97ffecc3 	bl	2ea0 <fwp_fmt_u128>
    7b98:	17fffe75 	b	756c <fwp_write+0x88>
    7b9c:	f90143f7 	str	x23, [sp, #640]
    7ba0:	f90147f8 	str	x24, [sp, #648]
    7ba4:	2a1303f8 	mov	w24, w19
    7ba8:	f9014bf9 	str	x25, [sp, #656]
    7bac:	f9014ffa 	str	x26, [sp, #664]
    7bb0:	f13ffe7f 	cmp	x19, #0xfff
    7bb4:	54000049 	b.ls	7bbc <fwp_write+0x6d8>  // b.plast
    7bb8:	b9400278 	ldr	w24, [x19]
    7bbc:	f9400f80 	ldr	x0, [x28, #24]
    7bc0:	2a1803f5 	mov	w21, w24
    7bc4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7bc8:	d37ef6b9 	lsl	x25, x21, #2
    7bcc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7bd0:	aa1603e0 	mov	x0, x22
    7bd4:	97ffeaf3 	bl	27a0 <strlen@plt>
    7bd8:	aa1603e1 	mov	x1, x22
    7bdc:	aa0003e2 	mov	x2, x0
    7be0:	aa1403e0 	mov	x0, x20
    7be4:	97ffee8b 	bl	3610 <buf_put>
    7be8:	f9401780 	ldr	x0, [x28, #40]
    7bec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7bf0:	7100001f 	cmp	w0, #0x0
    7bf4:	5400068d 	b.le	7cc4 <fwp_write+0x7e0>
    7bf8:	91002276 	add	x22, x19, #0x8
    7bfc:	91001ff5 	add	x21, sp, #0x7
    7c00:	d280001b 	mov	x27, #0x0                   	// #0
    7c04:	5280041a 	mov	w26, #0x20                  	// #32
    7c08:	f9401b80 	ldr	x0, [x28, #48]
    7c0c:	aa1503e1 	mov	x1, x21
    7c10:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7c14:	d2800022 	mov	x2, #0x1                   	// #1
    7c18:	f8786803 	ldr	x3, [x0, x24]
    7c1c:	aa1403e0 	mov	x0, x20
    7c20:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7c24:	39001ffa 	strb	w26, [sp, #7]
    7c28:	97ffee7a 	bl	3610 <buf_put>
    7c2c:	f13ffeff 	cmp	x23, #0xfff
    7c30:	b9400261 	ldr	w1, [x19]
    7c34:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7c38:	7100383f 	cmp	w1, #0xe
    7c3c:	54000160 	b.eq	7c68 <fwp_write+0x784>  // b.none
    7c40:	7100403f 	cmp	w1, #0x10
    7c44:	54001a60 	b.eq	7f90 <fwp_write+0xaac>  // b.none
    7c48:	7100283f 	cmp	w1, #0xa
    7c4c:	54002aa0 	b.eq	81a0 <fwp_write+0xcbc>  // b.none
    7c50:	540014ac 	b.gt	7ee4 <fwp_write+0xa00>
    7c54:	71000c3f 	cmp	w1, #0x3
    7c58:	540029ac 	b.gt	818c <fwp_write+0xca8>
    7c5c:	d37ffee0 	lsr	x0, x23, #63
    7c60:	37f814a1 	tbnz	w1, #31, 7ef4 <fwp_write+0xa10>
    7c64:	d503201f 	nop
    7c68:	34001460 	cbz	w0, 7ef4 <fwp_write+0xa10>
    7c6c:	52800503 	mov	w3, #0x28                  	// #40
    7c70:	aa1503e1 	mov	x1, x21
    7c74:	aa1403e0 	mov	x0, x20
    7c78:	d2800022 	mov	x2, #0x1                   	// #1
    7c7c:	39001fe3 	strb	w3, [sp, #7]
    7c80:	97ffee64 	bl	3610 <buf_put>
    7c84:	aa1303e2 	mov	x2, x19
    7c88:	aa1703e1 	mov	x1, x23
    7c8c:	aa1403e0 	mov	x0, x20
    7c90:	52800003 	mov	w3, #0x0                   	// #0
    7c94:	97fffe14 	bl	74e4 <fwp_write>
    7c98:	52800523 	mov	w3, #0x29                  	// #41
    7c9c:	aa1503e1 	mov	x1, x21
    7ca0:	aa1403e0 	mov	x0, x20
    7ca4:	d2800022 	mov	x2, #0x1                   	// #1
    7ca8:	39001fe3 	strb	w3, [sp, #7]
    7cac:	97ffee59 	bl	3610 <buf_put>
    7cb0:	f9401780 	ldr	x0, [x28, #40]
    7cb4:	9100077b 	add	x27, x27, #0x1
    7cb8:	b8796800 	ldr	w0, [x0, x25]
    7cbc:	6b1b001f 	cmp	w0, w27
    7cc0:	54fffa4c 	b.gt	7c08 <fwp_write+0x724>
    7cc4:	f9413bf5 	ldr	x21, [sp, #624]
    7cc8:	f9413ff6 	ldr	x22, [sp, #632]
    7ccc:	f94143f7 	ldr	x23, [sp, #640]
    7cd0:	f94147f8 	ldr	x24, [sp, #648]
    7cd4:	f9414bf9 	ldr	x25, [sp, #656]
    7cd8:	f9414ffa 	ldr	x26, [sp, #664]
    7cdc:	f94153fb 	ldr	x27, [sp, #672]
    7ce0:	f94157fc 	ldr	x28, [sp, #680]
    7ce4:	17fffe2c 	b	7594 <fwp_write+0xb0>
    7ce8:	52800783 	mov	w3, #0x3c                  	// #60
    7cec:	91001ff3 	add	x19, sp, #0x7
    7cf0:	aa1303e1 	mov	x1, x19
    7cf4:	d2800022 	mov	x2, #0x1                   	// #1
    7cf8:	aa1403e0 	mov	x0, x20
    7cfc:	39001fe3 	strb	w3, [sp, #7]
    7d00:	97ffee44 	bl	3610 <buf_put>
    7d04:	f9400795 	ldr	x21, [x28, #8]
    7d08:	aa1503e0 	mov	x0, x21
    7d0c:	97ffeaa5 	bl	27a0 <strlen@plt>
    7d10:	aa1503e1 	mov	x1, x21
    7d14:	aa0003e2 	mov	x2, x0
    7d18:	aa1403e0 	mov	x0, x20
    7d1c:	97ffee3d 	bl	3610 <buf_put>
    7d20:	528007c3 	mov	w3, #0x3e                  	// #62
    7d24:	aa1303e1 	mov	x1, x19
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	d2800022 	mov	x2, #0x1                   	// #1
    7d30:	39001fe3 	strb	w3, [sp, #7]
    7d34:	17fffe13 	b	7580 <fwp_write+0x9c>
    7d38:	f100067f 	cmp	x19, #0x1
    7d3c:	540025a0 	b.eq	81f0 <fwp_write+0xd0c>  // b.none
    7d40:	b100067f 	cmn	x19, #0x1
    7d44:	54002bc0 	b.eq	82bc <fwp_write+0xdd8>  // b.none
    7d48:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7d4c:	910da021 	add	x1, x1, #0x368
    7d50:	d2800022 	mov	x2, #0x1                   	// #1
    7d54:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7d58:	f947f400 	ldr	x0, [x0, #4072]
    7d5c:	f94127e4 	ldr	x4, [sp, #584]
    7d60:	f9400003 	ldr	x3, [x0]
    7d64:	eb030084 	subs	x4, x4, x3
    7d68:	d2800003 	mov	x3, #0x0                   	// #0
    7d6c:	54ffebe0 	b.eq	7ae8 <fwp_write+0x604>  // b.none
    7d70:	f90143f7 	str	x23, [sp, #640]
    7d74:	f90147f8 	str	x24, [sp, #648]
    7d78:	f9014bf9 	str	x25, [sp, #656]
    7d7c:	f9014ffa 	str	x26, [sp, #664]
    7d80:	fd015be8 	str	d8, [sp, #688]
    7d84:	fd015fe9 	str	d9, [sp, #696]
    7d88:	97ffeae2 	bl	2910 <__stack_chk_fail@plt>
    7d8c:	52800b63 	mov	w3, #0x5b                  	// #91
    7d90:	91001ff5 	add	x21, sp, #0x7
    7d94:	aa1503e1 	mov	x1, x21
    7d98:	aa1403e0 	mov	x0, x20
    7d9c:	d2800022 	mov	x2, #0x1                   	// #1
    7da0:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x150>
    7da4:	911022d6 	add	x22, x22, #0x408
    7da8:	39001fe3 	strb	w3, [sp, #7]
    7dac:	97ffee19 	bl	3610 <buf_put>
    7db0:	b4000273 	cbz	x19, 7dfc <fwp_write+0x918>
    7db4:	f9400661 	ldr	x1, [x19, #8]
    7db8:	aa1403e0 	mov	x0, x20
    7dbc:	f9401f82 	ldr	x2, [x28, #56]
    7dc0:	52800003 	mov	w3, #0x0                   	// #0
    7dc4:	97fffdc8 	bl	74e4 <fwp_write>
    7dc8:	f9400a73 	ldr	x19, [x19, #16]
    7dcc:	b4000193 	cbz	x19, 7dfc <fwp_write+0x918>
    7dd0:	aa1603e1 	mov	x1, x22
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	d2800042 	mov	x2, #0x2                   	// #2
    7ddc:	97ffee0d 	bl	3610 <buf_put>
    7de0:	f9400661 	ldr	x1, [x19, #8]
    7de4:	aa1403e0 	mov	x0, x20
    7de8:	f9401f82 	ldr	x2, [x28, #56]
    7dec:	52800003 	mov	w3, #0x0                   	// #0
    7df0:	97fffdbd 	bl	74e4 <fwp_write>
    7df4:	f9400a73 	ldr	x19, [x19, #16]
    7df8:	b5fffed3 	cbnz	x19, 7dd0 <fwp_write+0x8ec>
    7dfc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7e00:	aa1503e1 	mov	x1, x21
    7e04:	aa1403e0 	mov	x0, x20
    7e08:	d2800022 	mov	x2, #0x1                   	// #1
    7e0c:	39001fe3 	strb	w3, [sp, #7]
    7e10:	17fffddc 	b	7580 <fwp_write+0x9c>
    7e14:	aa1403e0 	mov	x0, x20
    7e18:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7e1c:	d28000c2 	mov	x2, #0x6                   	// #6
    7e20:	910fe021 	add	x1, x1, #0x3f8
    7e24:	97ffedfb 	bl	3610 <buf_put>
    7e28:	f9400260 	ldr	x0, [x19]
    7e2c:	b40004c0 	cbz	x0, 7ec4 <fwp_write+0x9e0>
    7e30:	910123f5 	add	x21, sp, #0x48
    7e34:	91002276 	add	x22, x19, #0x8
    7e38:	f90143f7 	str	x23, [sp, #640]
    7e3c:	d2800017 	mov	x23, #0x0                   	// #0
    7e40:	f90147f8 	str	x24, [sp, #648]
    7e44:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x150>
    7e48:	91100318 	add	x24, x24, #0x400
    7e4c:	f9014bf9 	str	x25, [sp, #656]
    7e50:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x150>
    7e54:	91102339 	add	x25, x25, #0x408
    7e58:	f9014ffa 	str	x26, [sp, #664]
    7e5c:	14000005 	b	7e70 <fwp_write+0x98c>
    7e60:	aa1903e1 	mov	x1, x25
    7e64:	aa1403e0 	mov	x0, x20
    7e68:	d2800042 	mov	x2, #0x2                   	// #2
    7e6c:	97ffede9 	bl	3610 <buf_put>
    7e70:	38776ac5 	ldrb	w5, [x22, x23]
    7e74:	d2804003 	mov	x3, #0x200                 	// #512
    7e78:	aa1803e4 	mov	x4, x24
    7e7c:	aa0303e1 	mov	x1, x3
    7e80:	52800042 	mov	w2, #0x2                   	// #2
    7e84:	aa1503e0 	mov	x0, x21
    7e88:	910006f7 	add	x23, x23, #0x1
    7e8c:	97ffea7d 	bl	2880 <__snprintf_chk@plt>
    7e90:	aa1503e0 	mov	x0, x21
    7e94:	97ffea43 	bl	27a0 <strlen@plt>
    7e98:	aa1503e1 	mov	x1, x21
    7e9c:	aa0003e2 	mov	x2, x0
    7ea0:	aa1403e0 	mov	x0, x20
    7ea4:	97ffeddb 	bl	3610 <buf_put>
    7ea8:	f9400260 	ldr	x0, [x19]
    7eac:	eb17001f 	cmp	x0, x23
    7eb0:	54fffd88 	b.hi	7e60 <fwp_write+0x97c>  // b.pmore
    7eb4:	f94143f7 	ldr	x23, [sp, #640]
    7eb8:	f94147f8 	ldr	x24, [sp, #648]
    7ebc:	f9414bf9 	ldr	x25, [sp, #656]
    7ec0:	f9414ffa 	ldr	x26, [sp, #664]
    7ec4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ec8:	aa1403e0 	mov	x0, x20
    7ecc:	91001fe1 	add	x1, sp, #0x7
    7ed0:	d2800022 	mov	x2, #0x1                   	// #1
    7ed4:	39001fe3 	strb	w3, [sp, #7]
    7ed8:	17fffdaa 	b	7580 <fwp_write+0x9c>
    7edc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ee0:	17fffe45 	b	77f4 <fwp_write+0x310>
    7ee4:	f10002ff 	cmp	x23, #0x0
    7ee8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7eec:	71002c3f 	cmp	w1, #0xb
    7ef0:	54ffebc0 	b.eq	7c68 <fwp_write+0x784>  // b.none
    7ef4:	aa1303e2 	mov	x2, x19
    7ef8:	aa1703e1 	mov	x1, x23
    7efc:	aa1403e0 	mov	x0, x20
    7f00:	52800003 	mov	w3, #0x0                   	// #0
    7f04:	97fffd78 	bl	74e4 <fwp_write>
    7f08:	17ffff6a 	b	7cb0 <fwp_write+0x7cc>
    7f0c:	aa1403e0 	mov	x0, x20
    7f10:	91001fe1 	add	x1, sp, #0x7
    7f14:	52800fa3 	mov	w3, #0x7d                  	// #125
    7f18:	d2800022 	mov	x2, #0x1                   	// #1
    7f1c:	17fffe39 	b	7800 <fwp_write+0x31c>
    7f20:	a9400281 	ldp	x1, x0, [x20]
    7f24:	91000800 	add	x0, x0, #0x2
    7f28:	8b160000 	add	x0, x0, x22
    7f2c:	f9000680 	str	x0, [x20, #8]
    7f30:	3820683f 	strb	wzr, [x1, x0]
    7f34:	f9413bf5 	ldr	x21, [sp, #624]
    7f38:	f9413ff6 	ldr	x22, [sp, #632]
    7f3c:	f94153fb 	ldr	x27, [sp, #672]
    7f40:	f94157fc 	ldr	x28, [sp, #680]
    7f44:	17fffd94 	b	7594 <fwp_write+0xb0>
    7f48:	f9400f80 	ldr	x0, [x28, #24]
    7f4c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7f50:	aa1b03e0 	mov	x0, x27
    7f54:	97ffea13 	bl	27a0 <strlen@plt>
    7f58:	aa1b03e1 	mov	x1, x27
    7f5c:	aa0003e2 	mov	x2, x0
    7f60:	aa1403e0 	mov	x0, x20
    7f64:	97ffedab 	bl	3610 <buf_put>
    7f68:	aa1903e1 	mov	x1, x25
    7f6c:	aa1403e0 	mov	x0, x20
    7f70:	d2800062 	mov	x2, #0x3                   	// #3
    7f74:	97ffeda7 	bl	3610 <buf_put>
    7f78:	17fffe11 	b	77bc <fwp_write+0x2d8>
    7f7c:	aa1a03e1 	mov	x1, x26
    7f80:	aa1403e0 	mov	x0, x20
    7f84:	d2800042 	mov	x2, #0x2                   	// #2
    7f88:	97ffeda2 	bl	3610 <buf_put>
    7f8c:	17fffe0a 	b	77b4 <fwp_write+0x2d0>
    7f90:	f9400660 	ldr	x0, [x19, #8]
    7f94:	b4fffb00 	cbz	x0, 7ef4 <fwp_write+0xa10>
    7f98:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7f9c:	91108021 	add	x1, x1, #0x420
    7fa0:	97ffea7c 	bl	2990 <strcmp@plt>
    7fa4:	7100001f 	cmp	w0, #0x0
    7fa8:	1a9f07e0 	cset	w0, ne	// ne = any
    7fac:	17ffff2f 	b	7c68 <fwp_write+0x784>
    7fb0:	aa1403e0 	mov	x0, x20
    7fb4:	d2800042 	mov	x2, #0x2                   	// #2
    7fb8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x150>
    7fbc:	91106021 	add	x1, x1, #0x418
    7fc0:	97ffed94 	bl	3610 <buf_put>
    7fc4:	91004261 	add	x1, x19, #0x10
    7fc8:	aa1403e0 	mov	x0, x20
    7fcc:	f9402382 	ldr	x2, [x28, #64]
    7fd0:	52800003 	mov	w3, #0x0                   	// #0
    7fd4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7fd8:	97fffd43 	bl	74e4 <fwp_write>
    7fdc:	17fffd9d 	b	7650 <fwp_write+0x16c>
    7fe0:	1e22c109 	fcvt	d9, s8
    7fe4:	910123f5 	add	x21, sp, #0x48
    7fe8:	52800033 	mov	w19, #0x1                   	// #1
    7fec:	d503201f 	nop
    7ff0:	1e604120 	fmov	d0, d9
    7ff4:	2a1303e1 	mov	w1, w19
    7ff8:	aa1503e0 	mov	x0, x21
    7ffc:	97ffee21 	bl	3880 <fwp_format_g.constprop.0>
    8000:	aa1503e0 	mov	x0, x21
    8004:	d2800001 	mov	x1, #0x0                   	// #0
    8008:	97ffea6e 	bl	29c0 <strtof@plt>
    800c:	1e202100 	fcmp	s8, s0
    8010:	54ffdb60 	b.eq	7b7c <fwp_write+0x698>  // b.none
    8014:	11000673 	add	w19, w19, #0x1
    8018:	71002a7f 	cmp	w19, #0xa
    801c:	54fffea1 	b.ne	7ff0 <fwp_write+0xb0c>  // b.any
    8020:	1e604120 	fmov	d0, d9
    8024:	aa1503e0 	mov	x0, x21
    8028:	52800121 	mov	w1, #0x9                   	// #9
    802c:	97ffee15 	bl	3880 <fwp_format_g.constprop.0>
    8030:	17fffed3 	b	7b7c <fwp_write+0x698>
    8034:	d37ef6a1 	lsl	x1, x21, #2
    8038:	b7f81563 	tbnz	x3, #63, 82e4 <fwp_write+0xe00>
    803c:	91002263 	add	x3, x19, #0x8
    8040:	8b010061 	add	x1, x3, x1
    8044:	b9400023 	ldr	w3, [x1]
    8048:	7100081f 	cmp	w0, #0x2
    804c:	2a0303e1 	mov	w1, w3
    8050:	93407c63 	sxtw	x3, w3
    8054:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8058:	17fffe5a 	b	79c0 <fwp_write+0x4dc>
    805c:	d37ffaa1 	lsl	x1, x21, #1
    8060:	b7f81363 	tbnz	x3, #63, 82cc <fwp_write+0xde8>
    8064:	91002263 	add	x3, x19, #0x8
    8068:	8b010061 	add	x1, x3, x1
    806c:	79400021 	ldrh	w1, [x1]
    8070:	7100041f 	cmp	w0, #0x1
    8074:	93403c23 	sxth	x3, w1
    8078:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    807c:	17fffe51 	b	79c0 <fwp_write+0x4dc>
    8080:	52800443 	mov	w3, #0x22                  	// #34
    8084:	91001ff5 	add	x21, sp, #0x7
    8088:	91002273 	add	x19, x19, #0x8
    808c:	aa1503e1 	mov	x1, x21
    8090:	aa1403e0 	mov	x0, x20
    8094:	d2800022 	mov	x2, #0x1                   	// #1
    8098:	39001fe3 	strb	w3, [sp, #7]
    809c:	f90143f7 	str	x23, [sp, #640]
    80a0:	8b160277 	add	x23, x19, x22
    80a4:	f90147f8 	str	x24, [sp, #648]
    80a8:	97ffed5a 	bl	3610 <buf_put>
    80ac:	b4000696 	cbz	x22, 817c <fwp_write+0xc98>
    80b0:	f0000018 	adrp	x24, b000 <_IO_stdin_used+0x150>
    80b4:	910f2318 	add	x24, x24, #0x3c8
    80b8:	f9014bf9 	str	x25, [sp, #656]
    80bc:	f0000019 	adrp	x25, b000 <_IO_stdin_used+0x150>
    80c0:	910fa339 	add	x25, x25, #0x3e8
    80c4:	f9014ffa 	str	x26, [sp, #664]
    80c8:	1400000d 	b	80fc <fwp_write+0xc18>
    80cc:	710024bf 	cmp	w5, #0x9
    80d0:	54000460 	b.eq	815c <fwp_write+0xc78>  // b.none
    80d4:	710028bf 	cmp	w5, #0xa
    80d8:	54000a61 	b.ne	8224 <fwp_write+0xd40>  // b.any
    80dc:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	910f6021 	add	x1, x1, #0x3d8
    80e8:	d2800042 	mov	x2, #0x2                   	// #2
    80ec:	97ffed49 	bl	3610 <buf_put>
    80f0:	91000673 	add	x19, x19, #0x1
    80f4:	eb17027f 	cmp	x19, x23
    80f8:	540003e0 	b.eq	8174 <fwp_write+0xc90>  // b.none
    80fc:	39400265 	ldrb	w5, [x19]
    8100:	710034bf 	cmp	w5, #0xd
    8104:	54000180 	b.eq	8134 <fwp_write+0xc50>  // b.none
    8108:	54fffe29 	b.ls	80cc <fwp_write+0xbe8>  // b.plast
    810c:	710088bf 	cmp	w5, #0x22
    8110:	540001c0 	b.eq	8148 <fwp_write+0xc64>  // b.none
    8114:	710170bf 	cmp	w5, #0x5c
    8118:	54000741 	b.ne	8200 <fwp_write+0xd1c>  // b.any
    811c:	aa1403e0 	mov	x0, x20
    8120:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    8124:	d2800042 	mov	x2, #0x2                   	// #2
    8128:	910f4021 	add	x1, x1, #0x3d0
    812c:	97ffed39 	bl	3610 <buf_put>
    8130:	17fffff0 	b	80f0 <fwp_write+0xc0c>
    8134:	aa1903e1 	mov	x1, x25
    8138:	aa1403e0 	mov	x0, x20
    813c:	d2800042 	mov	x2, #0x2                   	// #2
    8140:	97ffed34 	bl	3610 <buf_put>
    8144:	17ffffeb 	b	80f0 <fwp_write+0xc0c>
    8148:	aa1803e1 	mov	x1, x24
    814c:	aa1403e0 	mov	x0, x20
    8150:	d2800042 	mov	x2, #0x2                   	// #2
    8154:	97ffed2f 	bl	3610 <buf_put>
    8158:	17ffffe6 	b	80f0 <fwp_write+0xc0c>
    815c:	aa1403e0 	mov	x0, x20
    8160:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    8164:	d2800042 	mov	x2, #0x2                   	// #2
    8168:	910f8021 	add	x1, x1, #0x3e0
    816c:	97ffed29 	bl	3610 <buf_put>
    8170:	17ffffe0 	b	80f0 <fwp_write+0xc0c>
    8174:	f9414bf9 	ldr	x25, [sp, #656]
    8178:	f9414ffa 	ldr	x26, [sp, #664]
    817c:	aa1503e1 	mov	x1, x21
    8180:	aa1403e0 	mov	x0, x20
    8184:	52800443 	mov	w3, #0x22                  	// #34
    8188:	17fffd9d 	b	77fc <fwp_write+0x318>
    818c:	7100103f 	cmp	w1, #0x4
    8190:	54ffeb21 	b.ne	7ef4 <fwp_write+0xa10>  // b.any
    8194:	f94006e0 	ldr	x0, [x23, #8]
    8198:	d37ffc00 	lsr	x0, x0, #63
    819c:	17fffeb3 	b	7c68 <fwp_write+0x784>
    81a0:	710002ff 	cmp	w23, #0x0
    81a4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    81a8:	17fffeb0 	b	7c68 <fwp_write+0x784>
    81ac:	528005a1 	mov	w1, #0x2d                  	// #45
    81b0:	eb0203e2 	negs	x2, x2
    81b4:	da0303e3 	ngc	x3, x3
    81b8:	910127e0 	add	x0, sp, #0x49
    81bc:	910123f5 	add	x21, sp, #0x48
    81c0:	390123e1 	strb	w1, [sp, #72]
    81c4:	97ffeb37 	bl	2ea0 <fwp_fmt_u128>
    81c8:	17fffe18 	b	7a28 <fwp_write+0x544>
    81cc:	d37ceea1 	lsl	x1, x21, #4
    81d0:	b7f810a3 	tbnz	x3, #63, 83e4 <fwp_write+0xf00>
    81d4:	91002260 	add	x0, x19, #0x8
    81d8:	8b010001 	add	x1, x0, x1
    81dc:	17fffdf9 	b	79c0 <fwp_write+0x4dc>
    81e0:	f9400a61 	ldr	x1, [x19, #16]
    81e4:	8b010000 	add	x0, x0, x1
    81e8:	f9400001 	ldr	x1, [x0]
    81ec:	17fffdf5 	b	79c0 <fwp_write+0x4dc>
    81f0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    81f4:	d2800042 	mov	x2, #0x2                   	// #2
    81f8:	910dc021 	add	x1, x1, #0x370
    81fc:	17fffed6 	b	7d54 <fwp_write+0x870>
    8200:	7101fcbf 	cmp	w5, #0x7f
    8204:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8208:	540000e9 	b.ls	8224 <fwp_write+0xd40>  // b.plast
    820c:	aa1503e1 	mov	x1, x21
    8210:	aa1403e0 	mov	x0, x20
    8214:	d2800022 	mov	x2, #0x1                   	// #1
    8218:	39001fe5 	strb	w5, [sp, #7]
    821c:	97ffecfd 	bl	3610 <buf_put>
    8220:	17ffffb4 	b	80f0 <fwp_write+0xc0c>
    8224:	d2800203 	mov	x3, #0x10                  	// #16
    8228:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x150>
    822c:	aa0303e1 	mov	x1, x3
    8230:	910fc084 	add	x4, x4, #0x3f0
    8234:	910123f6 	add	x22, sp, #0x48
    8238:	52800042 	mov	w2, #0x2                   	// #2
    823c:	aa1603e0 	mov	x0, x22
    8240:	97ffe990 	bl	2880 <__snprintf_chk@plt>
    8244:	aa1603e0 	mov	x0, x22
    8248:	97ffe956 	bl	27a0 <strlen@plt>
    824c:	aa1603e1 	mov	x1, x22
    8250:	aa0003e2 	mov	x2, x0
    8254:	aa1403e0 	mov	x0, x20
    8258:	97ffecee 	bl	3610 <buf_put>
    825c:	17ffffa5 	b	80f0 <fwp_write+0xc0c>
    8260:	1e604100 	fmov	d0, d8
    8264:	aa1503e0 	mov	x0, x21
    8268:	52800221 	mov	w1, #0x11                  	// #17
    826c:	97ffed85 	bl	3880 <fwp_format_g.constprop.0>
    8270:	17fffe43 	b	7b7c <fwp_write+0x698>
    8274:	b9401040 	ldr	w0, [x2, #16]
    8278:	350003c0 	cbnz	w0, 82f0 <fwp_write+0xe0c>
    827c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8280:	f947f400 	ldr	x0, [x0, #4072]
    8284:	f94127e2 	ldr	x2, [sp, #584]
    8288:	f9400001 	ldr	x1, [x0]
    828c:	eb010042 	subs	x2, x2, x1
    8290:	d2800001 	mov	x1, #0x0                   	// #0
    8294:	54ffd721 	b.ne	7d78 <fwp_write+0x894>  // b.any
    8298:	f9413bf5 	ldr	x21, [sp, #624]
    829c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    82a0:	f9413ff6 	ldr	x22, [sp, #632]
    82a4:	aa1403e0 	mov	x0, x20
    82a8:	f94143f7 	ldr	x23, [sp, #640]
    82ac:	91110021 	add	x1, x1, #0x440
    82b0:	f94147f8 	ldr	x24, [sp, #648]
    82b4:	d2800042 	mov	x2, #0x2                   	// #2
    82b8:	17fffd0f 	b	76f4 <fwp_write+0x210>
    82bc:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x150>
    82c0:	d2800042 	mov	x2, #0x2                   	// #2
    82c4:	910de021 	add	x1, x1, #0x378
    82c8:	17fffea3 	b	7d54 <fwp_write+0x870>
    82cc:	f9400a63 	ldr	x3, [x19, #16]
    82d0:	8b030021 	add	x1, x1, x3
    82d4:	17ffff66 	b	806c <fwp_write+0xb88>
    82d8:	f9400a61 	ldr	x1, [x19, #16]
    82dc:	8b0102a1 	add	x1, x21, x1
    82e0:	17fffdb4 	b	79b0 <fwp_write+0x4cc>
    82e4:	f9400a63 	ldr	x3, [x19, #16]
    82e8:	8b030021 	add	x1, x1, x3
    82ec:	17ffff56 	b	8044 <fwp_write+0xb60>
    82f0:	b9404840 	ldr	w0, [x2, #72]
    82f4:	91001ff5 	add	x21, sp, #0x7
    82f8:	34ffa380 	cbz	w0, 7768 <fwp_write+0x284>
    82fc:	52800503 	mov	w3, #0x28                  	// #40
    8300:	aa1403e0 	mov	x0, x20
    8304:	aa1503e1 	mov	x1, x21
    8308:	d2800022 	mov	x2, #0x1                   	// #1
    830c:	39001fe3 	strb	w3, [sp, #7]
    8310:	97ffecc0 	bl	3610 <buf_put>
    8314:	b9401380 	ldr	w0, [x28, #16]
    8318:	52800038 	mov	w24, #0x1                   	// #1
    831c:	7100001f 	cmp	w0, #0x0
    8320:	54ffa38c 	b.gt	7790 <fwp_write+0x2ac>
    8324:	17fffd33 	b	77f0 <fwp_write+0x30c>
    8328:	f9014bf9 	str	x25, [sp, #656]
    832c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11030>
    8330:	f9014ffa 	str	x26, [sp, #664]
    8334:	f9400676 	ldr	x22, [x19, #8]
    8338:	910aa333 	add	x19, x25, #0x2a8
    833c:	91002273 	add	x19, x19, #0x8
    8340:	937ffed8 	asr	x24, x22, #63
    8344:	aa1802c0 	orr	x0, x22, x24
    8348:	b5000320 	cbnz	x0, 83ac <fwp_write+0xec8>
    834c:	110006b5 	add	w21, w21, #0x1
    8350:	710016bf 	cmp	w21, #0x5
    8354:	54ffffc1 	b.ne	834c <fwp_write+0xe68>  // b.any
    8358:	b7f80578 	tbnz	x24, #63, 8404 <fwp_write+0xf20>
    835c:	910023f3 	add	x19, sp, #0x8
    8360:	aa1603e2 	mov	x2, x22
    8364:	aa1303e0 	mov	x0, x19
    8368:	d2800003 	mov	x3, #0x0                   	// #0
    836c:	97ffeacd 	bl	2ea0 <fwp_fmt_u128>
    8370:	910123f5 	add	x21, sp, #0x48
    8374:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x150>
    8378:	aa1303e4 	mov	x4, x19
    837c:	aa1503e0 	mov	x0, x21
    8380:	9110e063 	add	x3, x3, #0x438
    8384:	d2804002 	mov	x2, #0x200                 	// #512
    8388:	52800041 	mov	w1, #0x2                   	// #2
    838c:	97ffe909 	bl	27b0 <__sprintf_chk@plt>
    8390:	aa1503e0 	mov	x0, x21
    8394:	97ffe903 	bl	27a0 <strlen@plt>
    8398:	aa1503e1 	mov	x1, x21
    839c:	aa0003e2 	mov	x2, x0
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	97ffec9b 	bl	3610 <buf_put>
    83a8:	17fffe47 	b	7cc4 <fwp_write+0x7e0>
    83ac:	f9400277 	ldr	x23, [x19]
    83b0:	aa1603e0 	mov	x0, x22
    83b4:	aa1803e1 	mov	x1, x24
    83b8:	aa1703e2 	mov	x2, x23
    83bc:	937ffefa 	asr	x26, x23, #63
    83c0:	aa1a03e3 	mov	x3, x26
    83c4:	940009d3 	bl	ab10 <__modti3>
    83c8:	aa010000 	orr	x0, x0, x1
    83cc:	b40002c0 	cbz	x0, 8424 <fwp_write+0xf40>
    83d0:	110006b5 	add	w21, w21, #0x1
    83d4:	91004273 	add	x19, x19, #0x10
    83d8:	710016bf 	cmp	w21, #0x5
    83dc:	54fffe81 	b.ne	83ac <fwp_write+0xec8>  // b.any
    83e0:	17ffffde 	b	8358 <fwp_write+0xe74>
    83e4:	f9400a60 	ldr	x0, [x19, #16]
    83e8:	8b000021 	add	x1, x1, x0
    83ec:	17fffd75 	b	79c0 <fwp_write+0x4dc>
    83f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    83f4:	910123f5 	add	x21, sp, #0x48
    83f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    83fc:	b9004be0 	str	w0, [sp, #72]
    8400:	17fffda2 	b	7a88 <fwp_write+0x5a4>
    8404:	528005a1 	mov	w1, #0x2d                  	// #45
    8408:	eb1603e2 	negs	x2, x22
    840c:	da1803e3 	ngc	x3, x24
    8410:	910027e0 	add	x0, sp, #0x9
    8414:	910023f3 	add	x19, sp, #0x8
    8418:	390023e1 	strb	w1, [sp, #8]
    841c:	97ffeaa1 	bl	2ea0 <fwp_fmt_u128>
    8420:	17ffffd4 	b	8370 <fwp_write+0xe8c>
    8424:	aa1703e2 	mov	x2, x23
    8428:	aa1a03e3 	mov	x3, x26
    842c:	aa1603e0 	mov	x0, x22
    8430:	aa1803e1 	mov	x1, x24
    8434:	940008d7 	bl	a790 <__divti3>
    8438:	aa0003e2 	mov	x2, x0
    843c:	aa0103e3 	mov	x3, x1
    8440:	b7f80201 	tbnz	x1, #63, 8480 <fwp_write+0xf9c>
    8444:	910023f3 	add	x19, sp, #0x8
    8448:	aa1303e0 	mov	x0, x19
    844c:	97ffea95 	bl	2ea0 <fwp_fmt_u128>
    8450:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8454:	910aa339 	add	x25, x25, #0x2a8
    8458:	910123f5 	add	x21, sp, #0x48
    845c:	aa1303e4 	mov	x4, x19
    8460:	aa1503e0 	mov	x0, x21
    8464:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x150>
    8468:	f8616b25 	ldr	x5, [x25, x1]
    846c:	9110c063 	add	x3, x3, #0x430
    8470:	d2804002 	mov	x2, #0x200                 	// #512
    8474:	52800041 	mov	w1, #0x2                   	// #2
    8478:	97ffe8ce 	bl	27b0 <__sprintf_chk@plt>
    847c:	17ffffc5 	b	8390 <fwp_write+0xeac>
    8480:	528005a4 	mov	w4, #0x2d                  	// #45
    8484:	eb0003e2 	negs	x2, x0
    8488:	da0103e3 	ngc	x3, x1
    848c:	910027e0 	add	x0, sp, #0x9
    8490:	910023f3 	add	x19, sp, #0x8
    8494:	390023e4 	strb	w4, [sp, #8]
    8498:	97ffea82 	bl	2ea0 <fwp_fmt_u128>
    849c:	17ffffed 	b	8450 <fwp_write+0xf6c>
    84a0:	f9013bf5 	str	x21, [sp, #624]
    84a4:	f9013ff6 	str	x22, [sp, #632]
    84a8:	f90143f7 	str	x23, [sp, #640]
    84ac:	f90147f8 	str	x24, [sp, #648]
    84b0:	f9014bf9 	str	x25, [sp, #656]
    84b4:	f9014ffa 	str	x26, [sp, #664]
    84b8:	f90153fb 	str	x27, [sp, #672]
    84bc:	f90157fc 	str	x28, [sp, #680]
    84c0:	fd015be8 	str	d8, [sp, #688]
    84c4:	fd015fe9 	str	d9, [sp, #696]
    84c8:	97ffe912 	bl	2910 <__stack_chk_fail@plt>
    84cc:	d503201f 	nop

00000000000084d0 <fwp_main_thread>:
    84d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    84d4:	910003fd 	mov	x29, sp
    84d8:	a90153f3 	stp	x19, x20, [sp, #16]
    84dc:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    84e0:	91174261 	add	x1, x19, #0x5d0
    84e4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    84e8:	f947f400 	ldr	x0, [x0, #4072]
    84ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    84f0:	a90363f7 	stp	x23, x24, [sp, #48]
    84f4:	d107c3ff 	sub	sp, sp, #0x1f0
    84f8:	b953a421 	ldr	w1, [x1, #5028]
    84fc:	f9400002 	ldr	x2, [x0]
    8500:	f900f7e2 	str	x2, [sp, #488]
    8504:	d2800002 	mov	x2, #0x0                   	// #0
    8508:	34000f01 	cbz	w1, 86e8 <fwp_main_thread+0x218>
    850c:	91174260 	add	x0, x19, #0x5d0
    8510:	b953a800 	ldr	w0, [x0, #5032]
    8514:	35000e20 	cbnz	w0, 86d8 <fwp_main_thread+0x208>
    8518:	900000d4 	adrp	x20, 20000 <__data_start>
    851c:	900000c2 	adrp	x2, 20000 <__data_start>
    8520:	9101c297 	add	x23, x20, #0x70
    8524:	910fc042 	add	x2, x2, #0x3f0
    8528:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    852c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8530:	9103a3f5 	add	x21, sp, #0xe8
    8534:	910323f8 	add	x24, sp, #0xc8
    8538:	aa1503e0 	mov	x0, x21
    853c:	d2800001 	mov	x1, #0x0                   	// #0
    8540:	a9018ef8 	stp	x24, x3, [x23, #24]
    8544:	f90077e2 	str	x2, [sp, #232]
    8548:	b900f3ff 	str	wzr, [sp, #240]
    854c:	f9007fe4 	str	x4, [sp, #248]
    8550:	97ffe888 	bl	2770 <sigaltstack@plt>
    8554:	35000220 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    8558:	4f000400 	movi	v0.4s, #0x0
    855c:	910563e0 	add	x0, sp, #0x158
    8560:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8564:	9103c021 	add	x1, x1, #0xf0
    8568:	f900abe1 	str	x1, [sp, #336]
    856c:	52800082 	mov	w2, #0x4                   	// #4
    8570:	72a10002 	movk	w2, #0x800, lsl #16
    8574:	910543f6 	add	x22, sp, #0x150
    8578:	3d802000 	str	q0, [x0, #128]
    857c:	b901dbe2 	str	w2, [sp, #472]
    8580:	ad000000 	stp	q0, q0, [x0]
    8584:	ad010000 	stp	q0, q0, [x0, #32]
    8588:	ad020000 	stp	q0, q0, [x0, #64]
    858c:	ad030000 	stp	q0, q0, [x0, #96]
    8590:	97ffe8d0 	bl	28d0 <sigemptyset@plt>
    8594:	34000100 	cbz	w0, 85b4 <fwp_main_thread+0xe4>
    8598:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    859c:	91114000 	add	x0, x0, #0x450
    85a0:	f9011bf9 	str	x25, [sp, #560]
    85a4:	f9011ffa 	str	x26, [sp, #568]
    85a8:	f90123fb 	str	x27, [sp, #576]
    85ac:	f90127fc 	str	x28, [sp, #584]
    85b0:	97ffeef8 	bl	4190 <fwp_trap>
    85b4:	aa1603e1 	mov	x1, x22
    85b8:	d2800002 	mov	x2, #0x0                   	// #0
    85bc:	52800160 	mov	w0, #0xb                   	// #11
    85c0:	97ffe8dc 	bl	2930 <sigaction@plt>
    85c4:	35fffea0 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    85c8:	aa1603e1 	mov	x1, x22
    85cc:	d2800002 	mov	x2, #0x0                   	// #0
    85d0:	528000e0 	mov	w0, #0x7                   	// #7
    85d4:	97ffe8d7 	bl	2930 <sigaction@plt>
    85d8:	35fffe00 	cbnz	w0, 8598 <fwp_main_thread+0xc8>
    85dc:	b94346e0 	ldr	w0, [x23, #836]
    85e0:	34000880 	cbz	w0, 86f0 <fwp_main_thread+0x220>
    85e4:	9101c280 	add	x0, x20, #0x70
    85e8:	b9434801 	ldr	w1, [x0, #840]
    85ec:	34000901 	cbz	w1, 870c <fwp_main_thread+0x23c>
    85f0:	9101c296 	add	x22, x20, #0x70
    85f4:	f9400ad5 	ldr	x21, [x22, #16]
    85f8:	b40015f5 	cbz	x21, 88b4 <fwp_main_thread+0x3e4>
    85fc:	910102b7 	add	x23, x21, #0x40
    8600:	f9011bf9 	str	x25, [sp, #560]
    8604:	f9011ffa 	str	x26, [sp, #568]
    8608:	52800038 	mov	w24, #0x1                   	// #1
    860c:	39414ab9 	ldrb	w25, [x21, #82]
    8610:	39014ab8 	strb	w24, [x21, #82]
    8614:	d503201f 	nop
    8618:	f94016a0 	ldr	x0, [x21, #40]
    861c:	b4001460 	cbz	x0, 88a8 <fwp_main_thread+0x3d8>
    8620:	f94032a1 	ldr	x1, [x21, #96]
    8624:	394146a0 	ldrb	w0, [x21, #81]
    8628:	b4001081 	cbz	x1, 8838 <fwp_main_thread+0x368>
    862c:	36000f40 	tbz	w0, #0, 8814 <fwp_main_thread+0x344>
    8630:	f9400ad3 	ldr	x19, [x22, #16]
    8634:	f94022a0 	ldr	x0, [x21, #64]
    8638:	39414a61 	ldrb	w1, [x19, #82]
    863c:	37001261 	tbnz	w1, #0, 8888 <fwp_main_thread+0x3b8>
    8640:	f9403261 	ldr	x1, [x19, #96]
    8644:	a911fe77 	stp	x23, xzr, [x19, #280]
    8648:	f9009660 	str	x0, [x19, #296]
    864c:	b4000040 	cbz	x0, 8654 <fwp_main_thread+0x184>
    8650:	f9009013 	str	x19, [x0, #288]
    8654:	f90022b3 	str	x19, [x21, #64]
    8658:	b4000101 	cbz	x1, 8678 <fwp_main_thread+0x1a8>
    865c:	f9406ec0 	ldr	x0, [x22, #216]
    8660:	39015678 	strb	w24, [x19, #85]
    8664:	f9003661 	str	x1, [x19, #104]
    8668:	a910827f 	stp	xzr, x0, [x19, #264]
    866c:	b4000040 	cbz	x0, 8674 <fwp_main_thread+0x1a4>
    8670:	f9008413 	str	x19, [x0, #264]
    8674:	f9006ed3 	str	x19, [x22, #216]
    8678:	39015a7f 	strb	wzr, [x19, #86]
    867c:	97fff909 	bl	6aa0 <fwp_block>
    8680:	f9408e62 	ldr	x2, [x19, #280]
    8684:	b4000142 	cbz	x2, 86ac <fwp_main_thread+0x1dc>
    8688:	a9520261 	ldp	x1, x0, [x19, #288]
    868c:	b40010a1 	cbz	x1, 88a0 <fwp_main_thread+0x3d0>
    8690:	f9009420 	str	x0, [x1, #296]
    8694:	f9409660 	ldr	x0, [x19, #296]
    8698:	b4000040 	cbz	x0, 86a0 <fwp_main_thread+0x1d0>
    869c:	f9009001 	str	x1, [x0, #288]
    86a0:	91080260 	add	x0, x19, #0x200
    86a4:	f900967f 	str	xzr, [x19, #296]
    86a8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    86ac:	39415660 	ldrb	w0, [x19, #85]
    86b0:	3607fb40 	tbz	w0, #0, 8618 <fwp_main_thread+0x148>
    86b4:	a9508261 	ldp	x1, x0, [x19, #264]
    86b8:	b4002041 	cbz	x1, 8ac0 <fwp_main_thread+0x5f0>
    86bc:	f9008820 	str	x0, [x1, #272]
    86c0:	b4000040 	cbz	x0, 86c8 <fwp_main_thread+0x1f8>
    86c4:	f9008401 	str	x1, [x0, #264]
    86c8:	91080260 	add	x0, x19, #0x200
    86cc:	3901567f 	strb	wzr, [x19, #85]
    86d0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    86d4:	17ffffd1 	b	8618 <fwp_main_thread+0x148>
    86d8:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    86dc:	91321000 	add	x0, x0, #0xc84
    86e0:	940009e8 	bl	ae80 <atexit>
    86e4:	17ffff8d 	b	8518 <fwp_main_thread+0x48>
    86e8:	97ffedc2 	bl	3df0 <fwp_heap_init>
    86ec:	17ffff88 	b	850c <fwp_main_thread+0x3c>
    86f0:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    86f4:	91078000 	add	x0, x0, #0x1e0
    86f8:	940009e2 	bl	ae80 <atexit>
    86fc:	3500fd00 	cbnz	w0, a69c <fwp_main_thread+0x21cc>
    8700:	52800020 	mov	w0, #0x1                   	// #1
    8704:	b90346e0 	str	w0, [x23, #836]
    8708:	17ffffb7 	b	85e4 <fwp_main_thread+0x114>
    870c:	f9418803 	ldr	x3, [x0, #784]
    8710:	f9011bf9 	str	x25, [sp, #560]
    8714:	f9011ffa 	str	x26, [sp, #568]
    8718:	910203e4 	add	x4, sp, #0x80
    871c:	f90123fb 	str	x27, [sp, #576]
    8720:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8724:	f90127fc 	str	x28, [sp, #584]
    8728:	91354021 	add	x1, x1, #0xd50
    872c:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8730:	91174279 	add	x25, x19, #0x5d0
    8734:	913f4042 	add	x2, x2, #0xfd0
    8738:	d280001a 	mov	x26, #0x0                   	// #0
    873c:	d280401b 	mov	x27, #0x200                 	// #512
    8740:	a90093ff 	stp	xzr, x4, [sp, #8]
    8744:	a9080be3 	stp	x3, x2, [sp, #128]
    8748:	f9004bf8 	str	x24, [sp, #144]
    874c:	f90067ff 	str	xzr, [sp, #200]
    8750:	a90d87ff 	stp	xzr, x1, [sp, #216]
    8754:	f9018804 	str	x4, [x0, #784]
    8758:	14000012 	b	87a0 <fwp_main_thread+0x2d0>
    875c:	7100045f 	cmp	w2, #0x1
    8760:	540001a1 	b.ne	8794 <fwp_main_thread+0x2c4>  // b.any
    8764:	29430002 	ldp	w2, w0, [x0, #24]
    8768:	92403c21 	and	x1, x1, #0xffff
    876c:	9b027c21 	mul	x1, x1, x2
    8770:	d360fc21 	lsr	x1, x1, #32
    8774:	eb00003f 	cmp	x1, x0
    8778:	540000e2 	b.cs	8794 <fwp_main_thread+0x2c4>  // b.hs, b.nlast
    877c:	8b01039c 	add	x28, x28, x1
    8780:	39400380 	ldrb	w0, [x28]
    8784:	7103fc1f 	cmp	w0, #0xff
    8788:	54003b20 	b.eq	8eec <fwp_main_thread+0xa1c>  // b.none
    878c:	52800020 	mov	w0, #0x1                   	// #1
    8790:	39000380 	strb	w0, [x28]
    8794:	a90cfffa 	stp	x26, xzr, [sp, #200]
    8798:	aa170318 	orr	x24, x24, x23
    879c:	b4001978 	cbz	x24, 8ac8 <fwp_main_thread+0x5f8>
    87a0:	f94007e0 	ldr	x0, [sp, #8]
    87a4:	f1000778 	subs	x24, x27, #0x1
    87a8:	aa1603e1 	mov	x1, x22
    87ac:	f9006bf8 	str	x24, [sp, #208]
    87b0:	da1f0017 	sbc	x23, x0, xzr
    87b4:	52800020 	mov	w0, #0x1                   	// #1
    87b8:	f90007f7 	str	x23, [sp, #8]
    87bc:	aa1803fb 	mov	x27, x24
    87c0:	a9156bf8 	stp	x24, x26, [sp, #336]
    87c4:	97fff230 	bl	5084 <fwp_data.part.0.constprop.0>
    87c8:	aa0003fa 	mov	x26, x0
    87cc:	f949db21 	ldr	x1, [x25, #5040]
    87d0:	f949ef20 	ldr	x0, [x25, #5080]
    87d4:	cb010341 	sub	x1, x26, x1
    87d8:	eb00403f 	cmp	x1, x0, lsl #16
    87dc:	54fffdc2 	b.cs	8794 <fwp_main_thread+0x2c4>  // b.hs, b.nlast
    87e0:	d350fc22 	lsr	x2, x1, #16
    87e4:	f949ff26 	ldr	x6, [x25, #5112]
    87e8:	8b020842 	add	x2, x2, x2, lsl #2
    87ec:	d37df042 	lsl	x2, x2, #3
    87f0:	8b0200c0 	add	x0, x6, x2
    87f4:	f940101c 	ldr	x28, [x0, #32]
    87f8:	b4fffcfc 	cbz	x28, 8794 <fwp_main_thread+0x2c4>
    87fc:	386268c2 	ldrb	w2, [x6, x2]
    8800:	7100085f 	cmp	w2, #0x2
    8804:	54fffac1 	b.ne	875c <fwp_main_thread+0x28c>  // b.any
    8808:	72003c3f 	tst	w1, #0xffff
    880c:	54fffc41 	b.ne	8794 <fwp_main_thread+0x2c4>  // b.any
    8810:	17ffffdc 	b	8780 <fwp_main_thread+0x2b0>
    8814:	97fff07f 	bl	4a10 <fwp_now_ns>
    8818:	f94032a1 	ldr	x1, [x21, #96]
    881c:	eb01001f 	cmp	x0, x1
    8820:	540000ab 	b.lt	8834 <fwp_main_thread+0x364>  // b.tstop
    8824:	394142a0 	ldrb	w0, [x21, #80]
    8828:	37000060 	tbnz	w0, #0, 8834 <fwp_main_thread+0x364>
    882c:	aa1503e0 	mov	x0, x21
    8830:	97ffebd0 	bl	3770 <fwp_cancel_tree.part.0>
    8834:	394146a0 	ldrb	w0, [x21, #81]
    8838:	f9400ad3 	ldr	x19, [x22, #16]
    883c:	39414a62 	ldrb	w2, [x19, #82]
    8840:	3707ef80 	tbnz	w0, #0, 8630 <fwp_main_thread+0x160>
    8844:	f94032a1 	ldr	x1, [x21, #96]
    8848:	370001c2 	tbnz	w2, #0, 8880 <fwp_main_thread+0x3b0>
    884c:	f9403260 	ldr	x0, [x19, #96]
    8850:	b4000180 	cbz	x0, 8880 <fwp_main_thread+0x3b0>
    8854:	b4000061 	cbz	x1, 8860 <fwp_main_thread+0x390>
    8858:	eb01001f 	cmp	x0, x1
    885c:	9a81d000 	csel	x0, x0, x1, le
    8860:	f94022a1 	ldr	x1, [x21, #64]
    8864:	a911fe77 	stp	x23, xzr, [x19, #280]
    8868:	f9009661 	str	x1, [x19, #296]
    886c:	b4003461 	cbz	x1, 8ef8 <fwp_main_thread+0xa28>
    8870:	f9009033 	str	x19, [x1, #288]
    8874:	aa0003e1 	mov	x1, x0
    8878:	f90022b3 	str	x19, [x21, #64]
    887c:	17ffff78 	b	865c <fwp_main_thread+0x18c>
    8880:	f94022a0 	ldr	x0, [x21, #64]
    8884:	17ffff70 	b	8644 <fwp_main_thread+0x174>
    8888:	a911fe77 	stp	x23, xzr, [x19, #280]
    888c:	f9009660 	str	x0, [x19, #296]
    8890:	b4000040 	cbz	x0, 8898 <fwp_main_thread+0x3c8>
    8894:	f9009013 	str	x19, [x0, #288]
    8898:	f90022b3 	str	x19, [x21, #64]
    889c:	17ffff77 	b	8678 <fwp_main_thread+0x1a8>
    88a0:	f9000040 	str	x0, [x2]
    88a4:	17ffff7d 	b	8698 <fwp_main_thread+0x1c8>
    88a8:	f9411ffa 	ldr	x26, [sp, #568]
    88ac:	39014ab9 	strb	w25, [x21, #82]
    88b0:	f9411bf9 	ldr	x25, [sp, #560]
    88b4:	9101c293 	add	x19, x20, #0x70
    88b8:	f9419660 	ldr	x0, [x19, #808]
    88bc:	b5000060 	cbnz	x0, 88c8 <fwp_main_thread+0x3f8>
    88c0:	f9419e60 	ldr	x0, [x19, #824]
    88c4:	b4004660 	cbz	x0, 9190 <fwp_main_thread+0xcc0>
    88c8:	9101c280 	add	x0, x20, #0x70
    88cc:	f9400800 	ldr	x0, [x0, #16]
    88d0:	9101c281 	add	x1, x20, #0x70
    88d4:	f941b026 	ldr	x6, [x1, #864]
    88d8:	b903583f 	str	wzr, [x1, #856]
    88dc:	eb0000df 	cmp	x6, x0
    88e0:	5400f481 	b.ne	a770 <fwp_main_thread+0x22a0>  // b.any
    88e4:	b40003c0 	cbz	x0, 895c <fwp_main_thread+0x48c>
    88e8:	f9418025 	ldr	x5, [x1, #768]
    88ec:	52800021 	mov	w1, #0x1                   	// #1
    88f0:	39014801 	strb	w1, [x0, #82]
    88f4:	b4000345 	cbz	x5, 895c <fwp_main_thread+0x48c>
    88f8:	394140a0 	ldrb	w0, [x5, #80]
    88fc:	37000060 	tbnz	w0, #0, 8908 <fwp_main_thread+0x438>
    8900:	aa0503e0 	mov	x0, x5
    8904:	97ffeb9b 	bl	3770 <fwp_cancel_tree.part.0>
    8908:	f9409ca5 	ldr	x5, [x5, #312]
    890c:	b5ffff65 	cbnz	x5, 88f8 <fwp_main_thread+0x428>
    8910:	9101c293 	add	x19, x20, #0x70
    8914:	52800035 	mov	w21, #0x1                   	// #1
    8918:	f94028c0 	ldr	x0, [x6, #80]
    891c:	f2001c1f 	tst	x0, #0xff000000ff
    8920:	540000e1 	b.ne	893c <fwp_main_thread+0x46c>  // b.any
    8924:	f9403e60 	ldr	x0, [x19, #120]
    8928:	390150d5 	strb	w21, [x6, #84]
    892c:	f90080df 	str	xzr, [x6, #256]
    8930:	b4000120 	cbz	x0, 8954 <fwp_main_thread+0x484>
    8934:	f9008006 	str	x6, [x0, #256]
    8938:	f9003e66 	str	x6, [x19, #120]
    893c:	97fff859 	bl	6aa0 <fwp_block>
    8940:	97fff7e0 	bl	68c0 <fwp_free_zombie>
    8944:	f9418260 	ldr	x0, [x19, #768]
    8948:	b40000a0 	cbz	x0, 895c <fwp_main_thread+0x48c>
    894c:	f941b266 	ldr	x6, [x19, #864]
    8950:	17fffff2 	b	8918 <fwp_main_thread+0x448>
    8954:	f9004266 	str	x6, [x19, #128]
    8958:	17fffff8 	b	8938 <fwp_main_thread+0x468>
    895c:	9101c295 	add	x21, x20, #0x70
    8960:	97fff7d8 	bl	68c0 <fwp_free_zombie>
    8964:	f94042a0 	ldr	x0, [x21, #128]
    8968:	b500f040 	cbnz	x0, a770 <fwp_main_thread+0x22a0>
    896c:	f9406ea0 	ldr	x0, [x21, #216]
    8970:	b500f000 	cbnz	x0, a770 <fwp_main_thread+0x22a0>
    8974:	b940fab3 	ldr	w19, [x21, #248]
    8978:	340001f3 	cbz	w19, 89b4 <fwp_main_thread+0x4e4>
    897c:	93407e76 	sxtw	x22, w19
    8980:	51000673 	sub	w19, w19, #0x1
    8984:	d1000ad6 	sub	x22, x22, #0x2
    8988:	910402b7 	add	x23, x21, #0x100
    898c:	cb3342d6 	sub	x22, x22, w19, uxtw
    8990:	93407e73 	sxtw	x19, w19
    8994:	d503201f 	nop
    8998:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    899c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    89a0:	b900fab3 	str	w19, [x21, #248]
    89a4:	d1000673 	sub	x19, x19, #0x1
    89a8:	97ffe822 	bl	2a30 <munmap@plt>
    89ac:	eb16027f 	cmp	x19, x22
    89b0:	54ffff41 	b.ne	8998 <fwp_main_thread+0x4c8>  // b.any
    89b4:	900000d7 	adrp	x23, 20000 <__data_start>
    89b8:	910042e0 	add	x0, x23, #0x10
    89bc:	b9404000 	ldr	w0, [x0, #64]
    89c0:	37f80040 	tbnz	w0, #31, 89c8 <fwp_main_thread+0x4f8>
    89c4:	97ffe7d7 	bl	2920 <close@plt>
    89c8:	9101c295 	add	x21, x20, #0x70
    89cc:	910042f7 	add	x23, x23, #0x10
    89d0:	12800001 	mov	w1, #0xffffffff            	// #-1
    89d4:	f941baa0 	ldr	x0, [x21, #880]
    89d8:	b90042e1 	str	w1, [x23, #64]
    89dc:	f941b6a1 	ldr	x1, [x21, #872]
    89e0:	b40001c0 	cbz	x0, 8a18 <fwp_main_thread+0x548>
    89e4:	d2800013 	mov	x19, #0x0                   	// #0
    89e8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    89ec:	b40000e0 	cbz	x0, 8a08 <fwp_main_thread+0x538>
    89f0:	f9400001 	ldr	x1, [x0]
    89f4:	b500ebe1 	cbnz	x1, a770 <fwp_main_thread+0x22a0>
    89f8:	f9400401 	ldr	x1, [x0, #8]
    89fc:	b500eba1 	cbnz	x1, a770 <fwp_main_thread+0x22a0>
    8a00:	97ffeea0 	bl	4480 <fwp_mem_free>
    8a04:	f941b6a1 	ldr	x1, [x21, #872]
    8a08:	91000673 	add	x19, x19, #0x1
    8a0c:	f941baa0 	ldr	x0, [x21, #880]
    8a10:	eb00027f 	cmp	x19, x0
    8a14:	54fffea3 	b.cc	89e8 <fwp_main_thread+0x518>  // b.lo, b.ul, b.last
    8a18:	aa0103e0 	mov	x0, x1
    8a1c:	97ffee99 	bl	4480 <fwp_mem_free>
    8a20:	9101c280 	add	x0, x20, #0x70
    8a24:	f941b013 	ldr	x19, [x0, #864]
    8a28:	f901b41f 	str	xzr, [x0, #872]
    8a2c:	f901b81f 	str	xzr, [x0, #880]
    8a30:	b40001f3 	cbz	x19, 8a6c <fwp_main_thread+0x59c>
    8a34:	f9401661 	ldr	x1, [x19, #40]
    8a38:	b500e9c1 	cbnz	x1, a770 <fwp_main_thread+0x22a0>
    8a3c:	f9405661 	ldr	x1, [x19, #168]
    8a40:	b500e981 	cbnz	x1, a770 <fwp_main_thread+0x22a0>
    8a44:	f9419401 	ldr	x1, [x0, #808]
    8a48:	b500e941 	cbnz	x1, a770 <fwp_main_thread+0x22a0>
    8a4c:	f9419c00 	ldr	x0, [x0, #824]
    8a50:	b500e900 	cbnz	x0, a770 <fwp_main_thread+0x22a0>
    8a54:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8a58:	90000140 	adrp	x0, 30000 <alt.5+0xfc10>
    8a5c:	910fc000 	add	x0, x0, #0x3f0
    8a60:	97ffe7a0 	bl	28e0 <memset@plt>
    8a64:	aa1303e0 	mov	x0, x19
    8a68:	97ffee86 	bl	4480 <fwp_mem_free>
    8a6c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8a70:	f947ec00 	ldr	x0, [x0, #4056]
    8a74:	9101c294 	add	x20, x20, #0x70
    8a78:	f9400000 	ldr	x0, [x0]
    8a7c:	f9000a9f 	str	xzr, [x20, #16]
    8a80:	f901b29f 	str	xzr, [x20, #864]
    8a84:	97ffe7ef 	bl	2a40 <fflush@plt>
    8a88:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8a8c:	f947f400 	ldr	x0, [x0, #4072]
    8a90:	f940f7e2 	ldr	x2, [sp, #488]
    8a94:	f9400001 	ldr	x1, [x0]
    8a98:	eb010042 	subs	x2, x2, x1
    8a9c:	d2800001 	mov	x1, #0x0                   	// #0
    8aa0:	5400e261 	b.ne	a6ec <fwp_main_thread+0x221c>  // b.any
    8aa4:	9107c3ff 	add	sp, sp, #0x1f0
    8aa8:	d2800000 	mov	x0, #0x0                   	// #0
    8aac:	a94153f3 	ldp	x19, x20, [sp, #16]
    8ab0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8ab4:	a94363f7 	ldp	x23, x24, [sp, #48]
    8ab8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8abc:	d65f03c0 	ret
    8ac0:	f9006ec0 	str	x0, [x22, #216]
    8ac4:	17fffeff 	b	86c0 <fwp_main_thread+0x1f0>
    8ac8:	9101c282 	add	x2, x20, #0x70
    8acc:	f90067ff 	str	xzr, [sp, #200]
    8ad0:	f9400be1 	ldr	x1, [sp, #16]
    8ad4:	f9418840 	ldr	x0, [x2, #784]
    8ad8:	eb01001f 	cmp	x0, x1
    8adc:	5400e521 	b.ne	a780 <fwp_main_thread+0x22b0>  // b.any
    8ae0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    8ae4:	910483e1 	add	x1, sp, #0x120
    8ae8:	f94043e3 	ldr	x3, [sp, #128]
    8aec:	f9018843 	str	x3, [x2, #784]
    8af0:	3dc32c00 	ldr	q0, [x0, #3248]
    8af4:	52800020 	mov	w0, #0x1                   	// #1
    8af8:	3d804be0 	str	q0, [sp, #288]
    8afc:	97fff162 	bl	5084 <fwp_data.part.0.constprop.0>
    8b00:	91174263 	add	x3, x19, #0x5d0
    8b04:	aa0003f7 	mov	x23, x0
    8b08:	f949d861 	ldr	x1, [x3, #5040]
    8b0c:	f949ec60 	ldr	x0, [x3, #5080]
    8b10:	cb0102e1 	sub	x1, x23, x1
    8b14:	eb00403f 	cmp	x1, x0, lsl #16
    8b18:	54000322 	b.cs	8b7c <fwp_main_thread+0x6ac>  // b.hs, b.nlast
    8b1c:	d350fc22 	lsr	x2, x1, #16
    8b20:	f949fc63 	ldr	x3, [x3, #5112]
    8b24:	8b020842 	add	x2, x2, x2, lsl #2
    8b28:	d37df042 	lsl	x2, x2, #3
    8b2c:	8b020060 	add	x0, x3, x2
    8b30:	f9401018 	ldr	x24, [x0, #32]
    8b34:	b4000258 	cbz	x24, 8b7c <fwp_main_thread+0x6ac>
    8b38:	38626862 	ldrb	w2, [x3, x2]
    8b3c:	7100085f 	cmp	w2, #0x2
    8b40:	54003020 	b.eq	9144 <fwp_main_thread+0xc74>  // b.none
    8b44:	7100045f 	cmp	w2, #0x1
    8b48:	540001a1 	b.ne	8b7c <fwp_main_thread+0x6ac>  // b.any
    8b4c:	29430002 	ldp	w2, w0, [x0, #24]
    8b50:	92403c21 	and	x1, x1, #0xffff
    8b54:	9b027c21 	mul	x1, x1, x2
    8b58:	d360fc21 	lsr	x1, x1, #32
    8b5c:	eb00003f 	cmp	x1, x0
    8b60:	540000e2 	b.cs	8b7c <fwp_main_thread+0x6ac>  // b.hs, b.nlast
    8b64:	8b010318 	add	x24, x24, x1
    8b68:	39400300 	ldrb	w0, [x24]
    8b6c:	7103fc1f 	cmp	w0, #0xff
    8b70:	540061c0 	b.eq	97a8 <fwp_main_thread+0x12d8>  // b.none
    8b74:	52800020 	mov	w0, #0x1                   	// #1
    8b78:	39000300 	strb	w0, [x24]
    8b7c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8b80:	910503e1 	add	x1, sp, #0x140
    8b84:	52800020 	mov	w0, #0x1                   	// #1
    8b88:	a9145fe2 	stp	x2, x23, [sp, #320]
    8b8c:	97fff13e 	bl	5084 <fwp_data.part.0.constprop.0>
    8b90:	91174263 	add	x3, x19, #0x5d0
    8b94:	aa0003f7 	mov	x23, x0
    8b98:	f949d861 	ldr	x1, [x3, #5040]
    8b9c:	f949ec60 	ldr	x0, [x3, #5080]
    8ba0:	cb0102e1 	sub	x1, x23, x1
    8ba4:	eb00403f 	cmp	x1, x0, lsl #16
    8ba8:	54000322 	b.cs	8c0c <fwp_main_thread+0x73c>  // b.hs, b.nlast
    8bac:	d350fc22 	lsr	x2, x1, #16
    8bb0:	f949fc63 	ldr	x3, [x3, #5112]
    8bb4:	8b020842 	add	x2, x2, x2, lsl #2
    8bb8:	d37df042 	lsl	x2, x2, #3
    8bbc:	8b020060 	add	x0, x3, x2
    8bc0:	f9401018 	ldr	x24, [x0, #32]
    8bc4:	b4000258 	cbz	x24, 8c0c <fwp_main_thread+0x73c>
    8bc8:	38626862 	ldrb	w2, [x3, x2]
    8bcc:	7100085f 	cmp	w2, #0x2
    8bd0:	54002c00 	b.eq	9150 <fwp_main_thread+0xc80>  // b.none
    8bd4:	7100045f 	cmp	w2, #0x1
    8bd8:	540001a1 	b.ne	8c0c <fwp_main_thread+0x73c>  // b.any
    8bdc:	29430002 	ldp	w2, w0, [x0, #24]
    8be0:	92403c21 	and	x1, x1, #0xffff
    8be4:	9b027c21 	mul	x1, x1, x2
    8be8:	d360fc21 	lsr	x1, x1, #32
    8bec:	eb00003f 	cmp	x1, x0
    8bf0:	540000e2 	b.cs	8c0c <fwp_main_thread+0x73c>  // b.hs, b.nlast
    8bf4:	8b010318 	add	x24, x24, x1
    8bf8:	39400300 	ldrb	w0, [x24]
    8bfc:	7103fc1f 	cmp	w0, #0xff
    8c00:	54005ce0 	b.eq	979c <fwp_main_thread+0x12cc>  // b.none
    8c04:	52800020 	mov	w0, #0x1                   	// #1
    8c08:	39000300 	strb	w0, [x24]
    8c0c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8c10:	9104c3e1 	add	x1, sp, #0x130
    8c14:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8c18:	52800020 	mov	w0, #0x1                   	// #1
    8c1c:	a9135fe2 	stp	x2, x23, [sp, #304]
    8c20:	97fff119 	bl	5084 <fwp_data.part.0.constprop.0>
    8c24:	91174262 	add	x2, x19, #0x5d0
    8c28:	aa0003f8 	mov	x24, x0
    8c2c:	f949d841 	ldr	x1, [x2, #5040]
    8c30:	f949ec40 	ldr	x0, [x2, #5080]
    8c34:	cb010301 	sub	x1, x24, x1
    8c38:	eb00403f 	cmp	x1, x0, lsl #16
    8c3c:	54000322 	b.cs	8ca0 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    8c40:	d350fc20 	lsr	x0, x1, #16
    8c44:	f949fc43 	ldr	x3, [x2, #5112]
    8c48:	8b000800 	add	x0, x0, x0, lsl #2
    8c4c:	d37df002 	lsl	x2, x0, #3
    8c50:	8b020060 	add	x0, x3, x2
    8c54:	f9401017 	ldr	x23, [x0, #32]
    8c58:	b4000257 	cbz	x23, 8ca0 <fwp_main_thread+0x7d0>
    8c5c:	38626862 	ldrb	w2, [x3, x2]
    8c60:	7100085f 	cmp	w2, #0x2
    8c64:	540027c0 	b.eq	915c <fwp_main_thread+0xc8c>  // b.none
    8c68:	7100045f 	cmp	w2, #0x1
    8c6c:	540001a1 	b.ne	8ca0 <fwp_main_thread+0x7d0>  // b.any
    8c70:	29430002 	ldp	w2, w0, [x0, #24]
    8c74:	92403c21 	and	x1, x1, #0xffff
    8c78:	9b027c21 	mul	x1, x1, x2
    8c7c:	d360fc21 	lsr	x1, x1, #32
    8c80:	eb00003f 	cmp	x1, x0
    8c84:	540000e2 	b.cs	8ca0 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    8c88:	8b0102f7 	add	x23, x23, x1
    8c8c:	394002e0 	ldrb	w0, [x23]
    8c90:	7103fc1f 	cmp	w0, #0xff
    8c94:	54005900 	b.eq	97b4 <fwp_main_thread+0x12e4>  // b.none
    8c98:	52800020 	mov	w0, #0x1                   	// #1
    8c9c:	390002e0 	strb	w0, [x23]
    8ca0:	b400429a 	cbz	x26, 94f0 <fwp_main_thread+0x1020>
    8ca4:	900000d7 	adrp	x23, 20000 <__data_start>
    8ca8:	910042f7 	add	x23, x23, #0x10
    8cac:	9100e2e0 	add	x0, x23, #0x38
    8cb0:	d0fffffb 	adrp	x27, 6000 <fwp_drop0+0x140>
    8cb4:	f90007e0 	str	x0, [sp, #8]
    8cb8:	910f4360 	add	x0, x27, #0x3d0
    8cbc:	91174279 	add	x25, x19, #0x5d0
    8cc0:	9101c297 	add	x23, x20, #0x70
    8cc4:	f90013e0 	str	x0, [sp, #32]
    8cc8:	9101e3e0 	add	x0, sp, #0x78
    8ccc:	f9000be0 	str	x0, [sp, #16]
    8cd0:	910263e0 	add	x0, sp, #0x98
    8cd4:	f9000fe0 	str	x0, [sp, #24]
    8cd8:	f90017fa 	str	x26, [sp, #40]
    8cdc:	f949ef25 	ldr	x5, [x25, #5080]
    8ce0:	f949db21 	ldr	x1, [x25, #5040]
    8ce4:	d370bca5 	lsl	x5, x5, #16
    8ce8:	cb010303 	sub	x3, x24, x1
    8cec:	eb05007f 	cmp	x3, x5
    8cf0:	540003e2 	b.cs	8d6c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    8cf4:	d350fc60 	lsr	x0, x3, #16
    8cf8:	f949ff27 	ldr	x7, [x25, #5112]
    8cfc:	8b000800 	add	x0, x0, x0, lsl #2
    8d00:	d37df002 	lsl	x2, x0, #3
    8d04:	8b0200e6 	add	x6, x7, x2
    8d08:	f94010c0 	ldr	x0, [x6, #32]
    8d0c:	b4000300 	cbz	x0, 8d6c <fwp_main_thread+0x89c>
    8d10:	386268e2 	ldrb	w2, [x7, x2]
    8d14:	7100085f 	cmp	w2, #0x2
    8d18:	54002280 	b.eq	9168 <fwp_main_thread+0xc98>  // b.none
    8d1c:	7100045f 	cmp	w2, #0x1
    8d20:	54000261 	b.ne	8d6c <fwp_main_thread+0x89c>  // b.any
    8d24:	92403c62 	and	x2, x3, #0xffff
    8d28:	29430cc7 	ldp	w7, w3, [x6, #24]
    8d2c:	9b077c42 	mul	x2, x2, x7
    8d30:	d360fc42 	lsr	x2, x2, #32
    8d34:	eb03005f 	cmp	x2, x3
    8d38:	540001a2 	b.cs	8d6c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    8d3c:	8b020000 	add	x0, x0, x2
    8d40:	39400002 	ldrb	w2, [x0]
    8d44:	34000142 	cbz	w2, 8d6c <fwp_main_thread+0x89c>
    8d48:	7103f45f 	cmp	w2, #0xfd
    8d4c:	540058e8 	b.hi	9868 <fwp_main_thread+0x1398>  // b.pmore
    8d50:	91174261 	add	x1, x19, #0x5d0
    8d54:	11000442 	add	w2, w2, #0x1
    8d58:	39000002 	strb	w2, [x0]
    8d5c:	aa0103e0 	mov	x0, x1
    8d60:	f949d821 	ldr	x1, [x1, #5040]
    8d64:	f949ec05 	ldr	x5, [x0, #5080]
    8d68:	d370bca5 	lsl	x5, x5, #16
    8d6c:	f9418ae0 	ldr	x0, [x23, #784]
    8d70:	f9004fe0 	str	x0, [sp, #152]
    8d74:	f94007e2 	ldr	x2, [sp, #8]
    8d78:	f94013e0 	ldr	x0, [sp, #32]
    8d7c:	f90053e0 	str	x0, [sp, #160]
    8d80:	f9400be0 	ldr	x0, [sp, #16]
    8d84:	f90057e0 	str	x0, [sp, #168]
    8d88:	f9400fe0 	ldr	x0, [sp, #24]
    8d8c:	cb010041 	sub	x1, x2, x1
    8d90:	12800002 	mov	w2, #0xffffffff            	// #-1
    8d94:	b9007be2 	str	w2, [sp, #120]
    8d98:	f9018ae0 	str	x0, [x23, #784]
    8d9c:	eb05003f 	cmp	x1, x5
    8da0:	54000782 	b.cs	8e90 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8da4:	91174262 	add	x2, x19, #0x5d0
    8da8:	d350fc20 	lsr	x0, x1, #16
    8dac:	8b000800 	add	x0, x0, x0, lsl #2
    8db0:	f949fc45 	ldr	x5, [x2, #5112]
    8db4:	d37df003 	lsl	x3, x0, #3
    8db8:	8b0300a2 	add	x2, x5, x3
    8dbc:	f940105c 	ldr	x28, [x2, #32]
    8dc0:	b400069c 	cbz	x28, 8e90 <fwp_main_thread+0x9c0>
    8dc4:	386368a0 	ldrb	w0, [x5, x3]
    8dc8:	7100081f 	cmp	w0, #0x2
    8dcc:	54001da0 	b.eq	9180 <fwp_main_thread+0xcb0>  // b.none
    8dd0:	7100041f 	cmp	w0, #0x1
    8dd4:	540005e1 	b.ne	8e90 <fwp_main_thread+0x9c0>  // b.any
    8dd8:	29430c45 	ldp	w5, w3, [x2, #24]
    8ddc:	92403c20 	and	x0, x1, #0xffff
    8de0:	9b057c00 	mul	x0, x0, x5
    8de4:	d360fc00 	lsr	x0, x0, #32
    8de8:	eb03001f 	cmp	x0, x3
    8dec:	540002a2 	b.cs	8e40 <fwp_main_thread+0x970>  // b.hs, b.nlast
    8df0:	8b000380 	add	x0, x28, x0
    8df4:	39400003 	ldrb	w3, [x0]
    8df8:	34000243 	cbz	w3, 8e40 <fwp_main_thread+0x970>
    8dfc:	7103f47f 	cmp	w3, #0xfd
    8e00:	54005408 	b.hi	9880 <fwp_main_thread+0x13b0>  // b.pmore
    8e04:	11000463 	add	w3, w3, #0x1
    8e08:	39000003 	strb	w3, [x0]
    8e0c:	91174260 	add	x0, x19, #0x5d0
    8e10:	f94007e3 	ldr	x3, [sp, #8]
    8e14:	f949d801 	ldr	x1, [x0, #5040]
    8e18:	f949ec02 	ldr	x2, [x0, #5080]
    8e1c:	cb010061 	sub	x1, x3, x1
    8e20:	eb02403f 	cmp	x1, x2, lsl #16
    8e24:	54000362 	b.cs	8e90 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8e28:	f949fc02 	ldr	x2, [x0, #5112]
    8e2c:	d350fc20 	lsr	x0, x1, #16
    8e30:	8b000800 	add	x0, x0, x0, lsl #2
    8e34:	8b000c42 	add	x2, x2, x0, lsl #3
    8e38:	f940105c 	ldr	x28, [x2, #32]
    8e3c:	b40002bc 	cbz	x28, 8e90 <fwp_main_thread+0x9c0>
    8e40:	39400040 	ldrb	w0, [x2]
    8e44:	7100081f 	cmp	w0, #0x2
    8e48:	54001960 	b.eq	9174 <fwp_main_thread+0xca4>  // b.none
    8e4c:	7100041f 	cmp	w0, #0x1
    8e50:	54000201 	b.ne	8e90 <fwp_main_thread+0x9c0>  // b.any
    8e54:	29430043 	ldp	w3, w0, [x2, #24]
    8e58:	92403c21 	and	x1, x1, #0xffff
    8e5c:	9b037c21 	mul	x1, x1, x3
    8e60:	d360fc21 	lsr	x1, x1, #32
    8e64:	eb00003f 	cmp	x1, x0
    8e68:	54000142 	b.cs	8e90 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8e6c:	8b01039c 	add	x28, x28, x1
    8e70:	39400380 	ldrb	w0, [x28]
    8e74:	340000e0 	cbz	w0, 8e90 <fwp_main_thread+0x9c0>
    8e78:	7100041f 	cmp	w0, #0x1
    8e7c:	54000280 	b.eq	8ecc <fwp_main_thread+0x9fc>  // b.none
    8e80:	7103fc1f 	cmp	w0, #0xff
    8e84:	54005020 	b.eq	9888 <fwp_main_thread+0x13b8>  // b.none
    8e88:	51000400 	sub	w0, w0, #0x1
    8e8c:	39000380 	strb	w0, [x28]
    8e90:	b40003b8 	cbz	x24, 8f04 <fwp_main_thread+0xa34>
    8e94:	aa1803e0 	mov	x0, x24
    8e98:	d280001c 	mov	x28, #0x0                   	// #0
    8e9c:	d503201f 	nop
    8ea0:	f9400800 	ldr	x0, [x0, #16]
    8ea4:	9100079c 	add	x28, x28, #0x1
    8ea8:	b5ffffc0 	cbnz	x0, 8ea0 <fwp_main_thread+0x9d0>
    8eac:	52800000 	mov	w0, #0x0                   	// #0
    8eb0:	97ffe9f0 	bl	3670 <descent_phase_step>
    8eb4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8eb8:	eb00039f 	cmp	x28, x0
    8ebc:	540002a9 	b.ls	8f10 <fwp_main_thread+0xa40>  // b.plast
    8ec0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    8ec4:	9111e000 	add	x0, x0, #0x478
    8ec8:	97ffecb2 	bl	4190 <fwp_trap>
    8ecc:	d53bd040 	mrs	x0, tpidr_el0
    8ed0:	91400000 	add	x0, x0, #0x0, lsl #12
    8ed4:	91004000 	add	x0, x0, #0x10
    8ed8:	f9400000 	ldr	x0, [x0]
    8edc:	b40012e0 	cbz	x0, 9138 <fwp_main_thread+0xc68>
    8ee0:	f94007e1 	ldr	x1, [sp, #8]
    8ee4:	97ffee27 	bl	4780 <fwp_closure_drop_push>
    8ee8:	17ffffea 	b	8e90 <fwp_main_thread+0x9c0>
    8eec:	aa1c03e0 	mov	x0, x28
    8ef0:	97ffecc8 	bl	4210 <fwp_rc_forget_slot.part.0>
    8ef4:	17fffe26 	b	878c <fwp_main_thread+0x2bc>
    8ef8:	aa0003e1 	mov	x1, x0
    8efc:	f90022b3 	str	x19, [x21, #64]
    8f00:	17fffdd7 	b	865c <fwp_main_thread+0x18c>
    8f04:	d280001c 	mov	x28, #0x0                   	// #0
    8f08:	52800000 	mov	w0, #0x0                   	// #0
    8f0c:	97ffe9d9 	bl	3670 <descent_phase_step>
    8f10:	9101c281 	add	x1, x20, #0x70
    8f14:	b9434c20 	ldr	w0, [x1, #844]
    8f18:	34003060 	cbz	w0, 9524 <fwp_main_thread+0x1054>
    8f1c:	9101c280 	add	x0, x20, #0x70
    8f20:	f9406803 	ldr	x3, [x0, #208]
    8f24:	f9407401 	ldr	x1, [x0, #232]
    8f28:	eb03003f 	cmp	x1, x3
    8f2c:	540016aa 	b.ge	9200 <fwp_main_thread+0xd30>  // b.tcont
    8f30:	f9403a82 	ldr	x2, [x20, #112]
    8f34:	8b010420 	add	x0, x1, x1, lsl #1
    8f38:	528fffc5 	mov	w5, #0x7ffe                	// #32766
    8f3c:	8b000820 	add	x0, x1, x0, lsl #2
    8f40:	8b000c40 	add	x0, x2, x0, lsl #3
    8f44:	d503201f 	nop
    8f48:	b9400402 	ldr	w2, [x0, #4]
    8f4c:	35000082 	cbnz	w2, 8f5c <fwp_main_thread+0xa8c>
    8f50:	b9400002 	ldr	w2, [x0]
    8f54:	6b05005f 	cmp	w2, w5
    8f58:	54001549 	b.ls	9200 <fwp_main_thread+0xd30>  // b.plast
    8f5c:	91000421 	add	x1, x1, #0x1
    8f60:	9101a000 	add	x0, x0, #0x68
    8f64:	eb03003f 	cmp	x1, x3
    8f68:	54ffff01 	b.ne	8f48 <fwp_main_thread+0xa78>  // b.any
    8f6c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8f70:	eb00007f 	cmp	x3, x0
    8f74:	5400426c 	b.gt	97c0 <fwp_main_thread+0x12f0>
    8f78:	9101c280 	add	x0, x20, #0x70
    8f7c:	f9403a86 	ldr	x6, [x20, #112]
    8f80:	f9407000 	ldr	x0, [x0, #224]
    8f84:	eb03001f 	cmp	x0, x3
    8f88:	54000261 	b.ne	8fd4 <fwp_main_thread+0xb04>  // b.any
    8f8c:	d2800022 	mov	x2, #0x1                   	// #1
    8f90:	b40000a3 	cbz	x3, 8fa4 <fwp_main_thread+0xad4>
    8f94:	d37ff862 	lsl	x2, x3, #1
    8f98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8f9c:	eb00005f 	cmp	x2, x0
    8fa0:	9a80d042 	csel	x2, x2, x0, le
    8fa4:	8b020441 	add	x1, x2, x2, lsl #1
    8fa8:	aa0603e0 	mov	x0, x6
    8fac:	a9030fe2 	stp	x2, x3, [sp, #48]
    8fb0:	8b010841 	add	x1, x2, x1, lsl #2
    8fb4:	d37df021 	lsl	x1, x1, #3
    8fb8:	97ffe652 	bl	2900 <realloc@plt>
    8fbc:	a9430fe2 	ldp	x2, x3, [sp, #48]
    8fc0:	aa0003e6 	mov	x6, x0
    8fc4:	b400b540 	cbz	x0, a66c <fwp_main_thread+0x219c>
    8fc8:	9101c280 	add	x0, x20, #0x70
    8fcc:	f9003a86 	str	x6, [x20, #112]
    8fd0:	f9007002 	str	x2, [x0, #224]
    8fd4:	8b030460 	add	x0, x3, x3, lsl #1
    8fd8:	9101c282 	add	x2, x20, #0x70
    8fdc:	4f000400 	movi	v0.4s, #0x0
    8fe0:	aa0303e1 	mov	x1, x3
    8fe4:	8b000860 	add	x0, x3, x0, lsl #2
    8fe8:	91000463 	add	x3, x3, #0x1
    8fec:	f9006843 	str	x3, [x2, #208]
    8ff0:	8b000cc0 	add	x0, x6, x0, lsl #3
    8ff4:	f900301f 	str	xzr, [x0, #96]
    8ff8:	ad000000 	stp	q0, q0, [x0]
    8ffc:	ad010000 	stp	q0, q0, [x0, #32]
    9000:	ad020000 	stp	q0, q0, [x0, #64]
    9004:	8b010422 	add	x2, x1, x1, lsl #1
    9008:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    900c:	91020000 	add	x0, x0, #0x80
    9010:	8b020823 	add	x3, x1, x2, lsl #2
    9014:	f90023e1 	str	x1, [sp, #64]
    9018:	8b030cc3 	add	x3, x6, x3, lsl #3
    901c:	a9031be3 	stp	x3, x6, [sp, #48]
    9020:	f900307f 	str	xzr, [x3, #96]
    9024:	97ffe69f 	bl	2aa0 <getenv@plt>
    9028:	a9431be3 	ldp	x3, x6, [sp, #48]
    902c:	f94023e1 	ldr	x1, [sp, #64]
    9030:	b4000c20 	cbz	x0, 91b4 <fwp_main_thread+0xce4>
    9034:	39400002 	ldrb	w2, [x0]
    9038:	7100c05f 	cmp	w2, #0x30
    903c:	54000bc1 	b.ne	91b4 <fwp_main_thread+0xce4>  // b.any
    9040:	39400400 	ldrb	w0, [x0, #1]
    9044:	35000b80 	cbnz	w0, 91b4 <fwp_main_thread+0xce4>
    9048:	9101c282 	add	x2, x20, #0x70
    904c:	2f000400 	mvni	v0.2s, #0x0
    9050:	b9400068 	ldr	w8, [x3]
    9054:	91000427 	add	x7, x1, #0x1
    9058:	52800025 	mov	w5, #0x1                   	// #1
    905c:	a900f07c 	stp	x28, x28, [x3, #8]
    9060:	11000508 	add	w8, w8, #0x1
    9064:	f9418840 	ldr	x0, [x2, #784]
    9068:	29001468 	stp	w8, w5, [x3]
    906c:	f900287f 	str	xzr, [x3, #80]
    9070:	f9007447 	str	x7, [x2, #232]
    9074:	fd002c60 	str	d0, [x3, #88]
    9078:	b4003f20 	cbz	x0, 985c <fwp_main_thread+0x138c>
    907c:	910f4365 	add	x5, x27, #0x3d0
    9080:	14000003 	b	908c <fwp_main_thread+0xbbc>
    9084:	f9400000 	ldr	x0, [x0]
    9088:	b4003ea0 	cbz	x0, 985c <fwp_main_thread+0x138c>
    908c:	f9400402 	ldr	x2, [x0, #8]
    9090:	eb05005f 	cmp	x2, x5
    9094:	54ffff81 	b.ne	9084 <fwp_main_thread+0xbb4>  // b.any
    9098:	f9400800 	ldr	x0, [x0, #16]
    909c:	2a0103e5 	mov	w5, w1
    90a0:	b9400002 	ldr	w2, [x0]
    90a4:	f9002860 	str	x0, [x3, #80]
    90a8:	b9005c62 	str	w2, [x3, #92]
    90ac:	37f80082 	tbnz	w2, #31, 90bc <fwp_main_thread+0xbec>
    90b0:	52800d03 	mov	w3, #0x68                  	// #104
    90b4:	9b231842 	smaddl	x2, w2, w3, x6
    90b8:	b9005841 	str	w1, [x2, #88]
    90bc:	b9000005 	str	w5, [x0]
    90c0:	52800020 	mov	w0, #0x1                   	// #1
    90c4:	b90033e8 	str	w8, [sp, #48]
    90c8:	f9001fe7 	str	x7, [sp, #56]
    90cc:	97ffe969 	bl	3670 <descent_phase_step>
    90d0:	f9401fe7 	ldr	x7, [sp, #56]
    90d4:	aa1803e0 	mov	x0, x24
    90d8:	b94033e8 	ldr	w8, [sp, #48]
    90dc:	d2800002 	mov	x2, #0x0                   	// #0
    90e0:	b4002358 	cbz	x24, 9548 <fwp_main_thread+0x1078>
    90e4:	d503201f 	nop
    90e8:	f9400800 	ldr	x0, [x0, #16]
    90ec:	91000442 	add	x2, x2, #0x1
    90f0:	b5ffffc0 	cbnz	x0, 90e8 <fwp_main_thread+0xc18>
    90f4:	aa1803e1 	mov	x1, x24
    90f8:	f9400821 	ldr	x1, [x1, #16]
    90fc:	91000400 	add	x0, x0, #0x1
    9100:	b5ffffc1 	cbnz	x1, 90f8 <fwp_main_thread+0xc28>
    9104:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9108:	eb01001f 	cmp	x0, x1
    910c:	54000108 	b.hi	912c <fwp_main_thread+0xc5c>  // b.pmore
    9110:	f100005f 	cmp	x2, #0x0
    9114:	540021ad 	b.le	9548 <fwp_main_thread+0x1078>
    9118:	eb00005f 	cmp	x2, x0
    911c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    9120:	9a80905c 	csel	x28, x2, x0, ls	// ls = plast
    9124:	eb01039f 	cmp	x28, x1
    9128:	54003e89 	b.ls	98f8 <fwp_main_thread+0x1428>  // b.plast
    912c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9130:	910d4000 	add	x0, x0, #0x350
    9134:	97ffec17 	bl	4190 <fwp_trap>
    9138:	f94007e0 	ldr	x0, [sp, #8]
    913c:	97ffedd6 	bl	4894 <fwp_closure_drop.part.0>
    9140:	17ffff54 	b	8e90 <fwp_main_thread+0x9c0>
    9144:	72003c3f 	tst	w1, #0xffff
    9148:	54ffd1a1 	b.ne	8b7c <fwp_main_thread+0x6ac>  // b.any
    914c:	17fffe87 	b	8b68 <fwp_main_thread+0x698>
    9150:	72003c3f 	tst	w1, #0xffff
    9154:	54ffd5c1 	b.ne	8c0c <fwp_main_thread+0x73c>  // b.any
    9158:	17fffea8 	b	8bf8 <fwp_main_thread+0x728>
    915c:	72003c3f 	tst	w1, #0xffff
    9160:	54ffda01 	b.ne	8ca0 <fwp_main_thread+0x7d0>  // b.any
    9164:	17fffeca 	b	8c8c <fwp_main_thread+0x7bc>
    9168:	72003c7f 	tst	w3, #0xffff
    916c:	54ffe001 	b.ne	8d6c <fwp_main_thread+0x89c>  // b.any
    9170:	17fffef4 	b	8d40 <fwp_main_thread+0x870>
    9174:	72003c3f 	tst	w1, #0xffff
    9178:	54ffe8c1 	b.ne	8e90 <fwp_main_thread+0x9c0>  // b.any
    917c:	17ffff3d 	b	8e70 <fwp_main_thread+0x9a0>
    9180:	72003c3f 	tst	w1, #0xffff
    9184:	54ffe5e1 	b.ne	8e40 <fwp_main_thread+0x970>  // b.any
    9188:	aa1c03e0 	mov	x0, x28
    918c:	17ffff1a 	b	8df4 <fwp_main_thread+0x924>
    9190:	f9419260 	ldr	x0, [x19, #800]
    9194:	97ffecbb 	bl	4480 <fwp_mem_free>
    9198:	f901927f 	str	xzr, [x19, #800]
    919c:	f9400a60 	ldr	x0, [x19, #16]
    91a0:	f9019a7f 	str	xzr, [x19, #816]
    91a4:	b4ffb960 	cbz	x0, 88d0 <fwp_main_thread+0x400>
    91a8:	f900541f 	str	xzr, [x0, #168]
    91ac:	f9005c1f 	str	xzr, [x0, #184]
    91b0:	17fffdc8 	b	88d0 <fwp_main_thread+0x400>
    91b4:	9101c282 	add	x2, x20, #0x70
    91b8:	f9406040 	ldr	x0, [x2, #192]
    91bc:	b4fff460 	cbz	x0, 9048 <fwp_main_thread+0xb78>
    91c0:	3cc88042 	ldur	q2, [x2, #136]
    91c4:	91022040 	add	x0, x2, #0x88
    91c8:	3cc98041 	ldur	q1, [x2, #152]
    91cc:	f900605f 	str	xzr, [x2, #192]
    91d0:	4f000400 	movi	v0.4s, #0x0
    91d4:	ad010462 	stp	q2, q1, [x3, #32]
    91d8:	f9405c42 	ldr	x2, [x2, #184]
    91dc:	f9002462 	str	x2, [x3, #72]
    91e0:	f9401002 	ldr	x2, [x0, #32]
    91e4:	f9002062 	str	x2, [x3, #64]
    91e8:	f9401402 	ldr	x2, [x0, #40]
    91ec:	f9000c62 	str	x2, [x3, #24]
    91f0:	f900181f 	str	xzr, [x0, #48]
    91f4:	ad000000 	stp	q0, q0, [x0]
    91f8:	3d800800 	str	q0, [x0, #32]
    91fc:	17ffff93 	b	9048 <fwp_main_thread+0xb78>
    9200:	eb01007f 	cmp	x3, x1
    9204:	54ffeb40 	b.eq	8f6c <fwp_main_thread+0xa9c>  // b.none
    9208:	f9403a86 	ldr	x6, [x20, #112]
    920c:	17ffff7e 	b	9004 <fwp_main_thread+0xb34>
    9210:	aa0303e0 	mov	x0, x3
    9214:	f9001fe2 	str	x2, [sp, #56]
    9218:	97ffec9a 	bl	4480 <fwp_mem_free>
    921c:	f9401fe2 	ldr	x2, [sp, #56]
    9220:	91174267 	add	x7, x19, #0x5d0
    9224:	d2800508 	mov	x8, #0x28                  	// #40
    9228:	f949d8e1 	ldr	x1, [x7, #5040]
    922c:	f949ece0 	ldr	x0, [x7, #5080]
    9230:	cb010041 	sub	x1, x2, x1
    9234:	eb00403f 	cmp	x1, x0, lsl #16
    9238:	54000362 	b.cs	92a4 <fwp_main_thread+0xdd4>  // b.hs, b.nlast
    923c:	d350fc25 	lsr	x5, x1, #16
    9240:	f949fce6 	ldr	x6, [x7, #5112]
    9244:	9b087ca5 	mul	x5, x5, x8
    9248:	8b0500c3 	add	x3, x6, x5
    924c:	f9401060 	ldr	x0, [x3, #32]
    9250:	b40002a0 	cbz	x0, 92a4 <fwp_main_thread+0xdd4>
    9254:	386568c6 	ldrb	w6, [x6, x5]
    9258:	710008df 	cmp	w6, #0x2
    925c:	54008b40 	b.eq	a3c4 <fwp_main_thread+0x1ef4>  // b.none
    9260:	710004df 	cmp	w6, #0x1
    9264:	54000201 	b.ne	92a4 <fwp_main_thread+0xdd4>  // b.any
    9268:	29432465 	ldp	w5, w9, [x3, #24]
    926c:	92403c21 	and	x1, x1, #0xffff
    9270:	9b057c25 	mul	x5, x1, x5
    9274:	d360fca5 	lsr	x5, x5, #32
    9278:	eb0900bf 	cmp	x5, x9
    927c:	54000142 	b.cs	92a4 <fwp_main_thread+0xdd4>  // b.hs, b.nlast
    9280:	8b050000 	add	x0, x0, x5
    9284:	39400005 	ldrb	w5, [x0]
    9288:	340000e5 	cbz	w5, 92a4 <fwp_main_thread+0xdd4>
    928c:	710004bf 	cmp	w5, #0x1
    9290:	54008820 	b.eq	a394 <fwp_main_thread+0x1ec4>  // b.none
    9294:	7103fcbf 	cmp	w5, #0xff
    9298:	54008ce0 	b.eq	a434 <fwp_main_thread+0x1f64>  // b.none
    929c:	510004a5 	sub	w5, w5, #0x1
    92a0:	39000005 	strb	w5, [x0]
    92a4:	91174266 	add	x6, x19, #0x5d0
    92a8:	d2800507 	mov	x7, #0x28                  	// #40
    92ac:	f9401be2 	ldr	x2, [sp, #48]
    92b0:	f949d8c1 	ldr	x1, [x6, #5040]
    92b4:	f949ecc0 	ldr	x0, [x6, #5080]
    92b8:	cb010041 	sub	x1, x2, x1
    92bc:	eb00403f 	cmp	x1, x0, lsl #16
    92c0:	54000362 	b.cs	932c <fwp_main_thread+0xe5c>  // b.hs, b.nlast
    92c4:	d350fc22 	lsr	x2, x1, #16
    92c8:	f949fcc5 	ldr	x5, [x6, #5112]
    92cc:	9b077c42 	mul	x2, x2, x7
    92d0:	8b0200a3 	add	x3, x5, x2
    92d4:	f9401060 	ldr	x0, [x3, #32]
    92d8:	b40002a0 	cbz	x0, 932c <fwp_main_thread+0xe5c>
    92dc:	386268a5 	ldrb	w5, [x5, x2]
    92e0:	710008bf 	cmp	w5, #0x2
    92e4:	54009380 	b.eq	a554 <fwp_main_thread+0x2084>  // b.none
    92e8:	710004bf 	cmp	w5, #0x1
    92ec:	54000201 	b.ne	932c <fwp_main_thread+0xe5c>  // b.any
    92f0:	29432062 	ldp	w2, w8, [x3, #24]
    92f4:	92403c21 	and	x1, x1, #0xffff
    92f8:	9b027c22 	mul	x2, x1, x2
    92fc:	d360fc42 	lsr	x2, x2, #32
    9300:	eb08005f 	cmp	x2, x8
    9304:	54000142 	b.cs	932c <fwp_main_thread+0xe5c>  // b.hs, b.nlast
    9308:	8b020000 	add	x0, x0, x2
    930c:	39400002 	ldrb	w2, [x0]
    9310:	340000e2 	cbz	w2, 932c <fwp_main_thread+0xe5c>
    9314:	7100045f 	cmp	w2, #0x1
    9318:	54009000 	b.eq	a518 <fwp_main_thread+0x2048>  // b.none
    931c:	7103fc5f 	cmp	w2, #0xff
    9320:	54008a80 	b.eq	a470 <fwp_main_thread+0x1fa0>  // b.none
    9324:	51000442 	sub	w2, w2, #0x1
    9328:	39000002 	strb	w2, [x0]
    932c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x11030>
    9330:	910aa042 	add	x2, x2, #0x2a8
    9334:	91014042 	add	x2, x2, #0x50
    9338:	aa1503e0 	mov	x0, x21
    933c:	52800023 	mov	w3, #0x1                   	// #1
    9340:	aa1c03e1 	mov	x1, x28
    9344:	a90effff 	stp	xzr, xzr, [sp, #232]
    9348:	f9007fff 	str	xzr, [sp, #248]
    934c:	97fff866 	bl	74e4 <fwp_write>
    9350:	a94e8be3 	ldp	x3, x2, [sp, #232]
    9354:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9358:	91280000 	add	x0, x0, #0xa00
    935c:	f100007f 	cmp	x3, #0x0
    9360:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    9364:	b100285f 	cmn	x2, #0xa
    9368:	54007c08 	b.hi	a2e8 <fwp_main_thread+0x1e18>  // b.pmore
    936c:	91002440 	add	x0, x2, #0x9
    9370:	52800021 	mov	w1, #0x1                   	// #1
    9374:	a9030be3 	stp	x3, x2, [sp, #48]
    9378:	97ffeefe 	bl	4f70 <fwp_heap_alloc>
    937c:	a9430be3 	ldp	x3, x2, [sp, #48]
    9380:	f9001be0 	str	x0, [sp, #48]
    9384:	f8008402 	str	x2, [x0], #8
    9388:	f90023e2 	str	x2, [sp, #64]
    938c:	f9001fe0 	str	x0, [sp, #56]
    9390:	aa0303e1 	mov	x1, x3
    9394:	97ffe4f3 	bl	2760 <memcpy@plt>
    9398:	f9401be0 	ldr	x0, [sp, #48]
    939c:	f94023e2 	ldr	x2, [sp, #64]
    93a0:	8b020002 	add	x2, x0, x2
    93a4:	3900205f 	strb	wzr, [x2, #8]
    93a8:	f94077e0 	ldr	x0, [sp, #232]
    93ac:	97ffe589 	bl	29d0 <free@plt>
    93b0:	91174260 	add	x0, x19, #0x5d0
    93b4:	f9401be3 	ldr	x3, [sp, #48]
    93b8:	f949d801 	ldr	x1, [x0, #5040]
    93bc:	f949ec02 	ldr	x2, [x0, #5080]
    93c0:	cb010061 	sub	x1, x3, x1
    93c4:	eb02403f 	cmp	x1, x2, lsl #16
    93c8:	54000322 	b.cs	942c <fwp_main_thread+0xf5c>  // b.hs, b.nlast
    93cc:	d350fc22 	lsr	x2, x1, #16
    93d0:	d2800503 	mov	x3, #0x28                  	// #40
    93d4:	f949fc05 	ldr	x5, [x0, #5112]
    93d8:	9b037c42 	mul	x2, x2, x3
    93dc:	8b0200a3 	add	x3, x5, x2
    93e0:	f9401060 	ldr	x0, [x3, #32]
    93e4:	b4000240 	cbz	x0, 942c <fwp_main_thread+0xf5c>
    93e8:	386268a2 	ldrb	w2, [x5, x2]
    93ec:	7100085f 	cmp	w2, #0x2
    93f0:	540078e0 	b.eq	a30c <fwp_main_thread+0x1e3c>  // b.none
    93f4:	7100045f 	cmp	w2, #0x1
    93f8:	540001a1 	b.ne	942c <fwp_main_thread+0xf5c>  // b.any
    93fc:	29430865 	ldp	w5, w2, [x3, #24]
    9400:	92403c21 	and	x1, x1, #0xffff
    9404:	9b057c21 	mul	x1, x1, x5
    9408:	d360fc21 	lsr	x1, x1, #32
    940c:	eb02003f 	cmp	x1, x2
    9410:	540000e2 	b.cs	942c <fwp_main_thread+0xf5c>  // b.hs, b.nlast
    9414:	8b010000 	add	x0, x0, x1
    9418:	39400001 	ldrb	w1, [x0]
    941c:	7103fc3f 	cmp	w1, #0xff
    9420:	540079a0 	b.eq	a354 <fwp_main_thread+0x1e84>  // b.none
    9424:	52800021 	mov	w1, #0x1                   	// #1
    9428:	39000001 	strb	w1, [x0]
    942c:	aa1c03e0 	mov	x0, x28
    9430:	97fff2a4 	bl	5ec0 <fwp_drop0>
    9434:	a94303e1 	ldp	x1, x0, [sp, #48]
    9438:	9101c29c 	add	x28, x20, #0x70
    943c:	f9400783 	ldr	x3, [x28, #8]
    9440:	f9400022 	ldr	x2, [x1]
    9444:	d2800021 	mov	x1, #0x1                   	// #1
    9448:	97ffe572 	bl	2a10 <fwrite@plt>
    944c:	f9400781 	ldr	x1, [x28, #8]
    9450:	52800140 	mov	w0, #0xa                   	// #10
    9454:	97ffe4f7 	bl	2830 <fputc@plt>
    9458:	91174262 	add	x2, x19, #0x5d0
    945c:	f9401be3 	ldr	x3, [sp, #48]
    9460:	f949d841 	ldr	x1, [x2, #5040]
    9464:	f949ec40 	ldr	x0, [x2, #5080]
    9468:	cb010061 	sub	x1, x3, x1
    946c:	eb00403f 	cmp	x1, x0, lsl #16
    9470:	54000382 	b.cs	94e0 <fwp_main_thread+0x1010>  // b.hs, b.nlast
    9474:	d350fc20 	lsr	x0, x1, #16
    9478:	d2800505 	mov	x5, #0x28                  	// #40
    947c:	f949fc43 	ldr	x3, [x2, #5112]
    9480:	9b057c00 	mul	x0, x0, x5
    9484:	8b000062 	add	x2, x3, x0
    9488:	f940105c 	ldr	x28, [x2, #32]
    948c:	b40002bc 	cbz	x28, 94e0 <fwp_main_thread+0x1010>
    9490:	38606860 	ldrb	w0, [x3, x0]
    9494:	7100081f 	cmp	w0, #0x2
    9498:	54007340 	b.eq	a300 <fwp_main_thread+0x1e30>  // b.none
    949c:	7100041f 	cmp	w0, #0x1
    94a0:	54000201 	b.ne	94e0 <fwp_main_thread+0x1010>  // b.any
    94a4:	29430043 	ldp	w3, w0, [x2, #24]
    94a8:	92403c21 	and	x1, x1, #0xffff
    94ac:	9b037c21 	mul	x1, x1, x3
    94b0:	d360fc21 	lsr	x1, x1, #32
    94b4:	eb00003f 	cmp	x1, x0
    94b8:	54000142 	b.cs	94e0 <fwp_main_thread+0x1010>  // b.hs, b.nlast
    94bc:	8b01039c 	add	x28, x28, x1
    94c0:	39400381 	ldrb	w1, [x28]
    94c4:	340000e1 	cbz	w1, 94e0 <fwp_main_thread+0x1010>
    94c8:	7100043f 	cmp	w1, #0x1
    94cc:	54007140 	b.eq	a2f4 <fwp_main_thread+0x1e24>  // b.none
    94d0:	7103fc3f 	cmp	w1, #0xff
    94d4:	54007220 	b.eq	a318 <fwp_main_thread+0x1e48>  // b.none
    94d8:	51000421 	sub	w1, w1, #0x1
    94dc:	39000381 	strb	w1, [x28]
    94e0:	f94017e0 	ldr	x0, [sp, #40]
    94e4:	f9400800 	ldr	x0, [x0, #16]
    94e8:	f90017e0 	str	x0, [sp, #40]
    94ec:	b5ffbf80 	cbnz	x0, 8cdc <fwp_main_thread+0x80c>
    94f0:	aa1803e0 	mov	x0, x24
    94f4:	97fff273 	bl	5ec0 <fwp_drop0>
    94f8:	aa1a03e0 	mov	x0, x26
    94fc:	97fff271 	bl	5ec0 <fwp_drop0>
    9500:	9101c280 	add	x0, x20, #0x70
    9504:	52800021 	mov	w1, #0x1                   	// #1
    9508:	f9411bf9 	ldr	x25, [sp, #560]
    950c:	f9411ffa 	ldr	x26, [sp, #568]
    9510:	f94123fb 	ldr	x27, [sp, #576]
    9514:	f94127fc 	ldr	x28, [sp, #584]
    9518:	b9034801 	str	w1, [x0, #840]
    951c:	f901a81f 	str	xzr, [x0, #848]
    9520:	17fffc34 	b	85f0 <fwp_main_thread+0x120>
    9524:	b0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x140>
    9528:	910b4000 	add	x0, x0, #0x2d0
    952c:	f9001be1 	str	x1, [sp, #48]
    9530:	94000654 	bl	ae80 <atexit>
    9534:	f9401be1 	ldr	x1, [sp, #48]
    9538:	350089a0 	cbnz	w0, a66c <fwp_main_thread+0x219c>
    953c:	52800020 	mov	w0, #0x1                   	// #1
    9540:	b9034c20 	str	w0, [x1, #844]
    9544:	17fffe76 	b	8f1c <fwp_main_thread+0xa4c>
    9548:	d3707d08 	ubfiz	x8, x8, #16, #32
    954c:	52800041 	mov	w1, #0x2                   	// #2
    9550:	aa070100 	orr	x0, x8, x7
    9554:	f9002be0 	str	x0, [sp, #80]
    9558:	d2800100 	mov	x0, #0x8                   	// #8
    955c:	97ffee85 	bl	4f70 <fwp_heap_alloc>
    9560:	aa0003e2 	mov	x2, x0
    9564:	91174260 	add	x0, x19, #0x5d0
    9568:	a9030be2 	stp	x2, x2, [sp, #48]
    956c:	f900005f 	str	xzr, [x2]
    9570:	f949d801 	ldr	x1, [x0, #5040]
    9574:	f949ec00 	ldr	x0, [x0, #5080]
    9578:	cb010041 	sub	x1, x2, x1
    957c:	eb00403f 	cmp	x1, x0, lsl #16
    9580:	54001e62 	b.cs	994c <fwp_main_thread+0x147c>  // b.hs, b.nlast
    9584:	d280001c 	mov	x28, #0x0                   	// #0
    9588:	91174262 	add	x2, x19, #0x5d0
    958c:	d350fc20 	lsr	x0, x1, #16
    9590:	8b000800 	add	x0, x0, x0, lsl #2
    9594:	f949fc45 	ldr	x5, [x2, #5112]
    9598:	d37df002 	lsl	x2, x0, #3
    959c:	8b0200a3 	add	x3, x5, x2
    95a0:	f9401060 	ldr	x0, [x3, #32]
    95a4:	b4000240 	cbz	x0, 95ec <fwp_main_thread+0x111c>
    95a8:	386268a2 	ldrb	w2, [x5, x2]
    95ac:	7100085f 	cmp	w2, #0x2
    95b0:	540029c0 	b.eq	9ae8 <fwp_main_thread+0x1618>  // b.none
    95b4:	7100045f 	cmp	w2, #0x1
    95b8:	540001a1 	b.ne	95ec <fwp_main_thread+0x111c>  // b.any
    95bc:	29430865 	ldp	w5, w2, [x3, #24]
    95c0:	92403c21 	and	x1, x1, #0xffff
    95c4:	9b057c21 	mul	x1, x1, x5
    95c8:	d360fc21 	lsr	x1, x1, #32
    95cc:	eb02003f 	cmp	x1, x2
    95d0:	540000e2 	b.cs	95ec <fwp_main_thread+0x111c>  // b.hs, b.nlast
    95d4:	8b010000 	add	x0, x0, x1
    95d8:	39400001 	ldrb	w1, [x0]
    95dc:	7103fc3f 	cmp	w1, #0xff
    95e0:	54003320 	b.eq	9c44 <fwp_main_thread+0x1774>  // b.none
    95e4:	52800021 	mov	w1, #0x1                   	// #1
    95e8:	39000001 	strb	w1, [x0]
    95ec:	b400027c 	cbz	x28, 9638 <fwp_main_thread+0x1168>
    95f0:	f9402be0 	ldr	x0, [sp, #80]
    95f4:	aa1803e1 	mov	x1, x24
    95f8:	f9400706 	ldr	x6, [x24, #8]
    95fc:	d3607c05 	lsl	x5, x0, #32
    9600:	f9401be0 	ldr	x0, [sp, #48]
    9604:	aa0503e3 	mov	x3, x5
    9608:	91002002 	add	x2, x0, #0x8
    960c:	d2800000 	mov	x0, #0x0                   	// #0
    9610:	14000005 	b	9624 <fwp_main_thread+0x1154>
    9614:	f9400426 	ldr	x6, [x1, #8]
    9618:	ab050003 	adds	x3, x0, x5
    961c:	91004042 	add	x2, x2, #0x10
    9620:	54008a66 	b.vs	a76c <fwp_main_thread+0x229c>
    9624:	a9000c46 	stp	x6, x3, [x2]
    9628:	91000400 	add	x0, x0, #0x1
    962c:	f9400821 	ldr	x1, [x1, #16]
    9630:	eb1c001f 	cmp	x0, x28
    9634:	54ffff03 	b.cc	9614 <fwp_main_thread+0x1144>  // b.lo, b.ul, b.last
    9638:	f9401be0 	ldr	x0, [sp, #48]
    963c:	f940001c 	ldr	x28, [x0]
    9640:	f100079f 	cmp	x28, #0x1
    9644:	54001849 	b.ls	994c <fwp_main_thread+0x147c>  // b.plast
    9648:	d341ff81 	lsr	x1, x28, #1
    964c:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    9650:	d1000422 	sub	x2, x1, #0x1
    9654:	f90027e2 	str	x2, [sp, #72]
    9658:	eb00005f 	cmp	x2, x0
    965c:	54ffd688 	b.hi	912c <fwp_main_thread+0xc5c>  // b.pmore
    9660:	b4001762 	cbz	x2, 994c <fwp_main_thread+0x147c>
    9664:	f9401be2 	ldr	x2, [sp, #48]
    9668:	d1002040 	sub	x0, x2, #0x8
    966c:	9100205c 	add	x28, x2, #0x8
    9670:	8b011000 	add	x0, x0, x1, lsl #4
    9674:	f90023e0 	str	x0, [sp, #64]
    9678:	f9400780 	ldr	x0, [x28, #8]
    967c:	f9400f81 	ldr	x1, [x28, #24]
    9680:	fd400380 	ldr	d0, [x28]
    9684:	fd400b81 	ldr	d1, [x28, #16]
    9688:	97ffefa7 	bl	5524 <w120>
    968c:	a9000780 	stp	x0, x1, [x28]
    9690:	9100439c 	add	x28, x28, #0x10
    9694:	f94023e0 	ldr	x0, [sp, #64]
    9698:	eb00039f 	cmp	x28, x0
    969c:	54fffee1 	b.ne	9678 <fwp_main_thread+0x11a8>  // b.any
    96a0:	f9401be0 	ldr	x0, [sp, #48]
    96a4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    96a8:	f94027e1 	ldr	x1, [sp, #72]
    96ac:	d280001c 	mov	x28, #0x0                   	// #0
    96b0:	d37ff821 	lsl	x1, x1, #1
    96b4:	f8010401 	str	x1, [x0], #16
    96b8:	a90403e1 	stp	x1, x0, [sp, #64]
    96bc:	f94027e0 	ldr	x0, [sp, #72]
    96c0:	f87c7801 	ldr	x1, [x0, x28, lsl #3]
    96c4:	aa0303e0 	mov	x0, x3
    96c8:	91000b9c 	add	x28, x28, #0x2
    96cc:	97ffef45 	bl	53e0 <f141.constprop.0>
    96d0:	aa0003e3 	mov	x3, x0
    96d4:	f94023e0 	ldr	x0, [sp, #64]
    96d8:	eb00039f 	cmp	x28, x0
    96dc:	54ffff03 	b.cc	96bc <fwp_main_thread+0x11ec>  // b.lo, b.ul, b.last
    96e0:	91174265 	add	x5, x19, #0x5d0
    96e4:	f9401be2 	ldr	x2, [sp, #48]
    96e8:	f949d8a1 	ldr	x1, [x5, #5040]
    96ec:	f949eca0 	ldr	x0, [x5, #5080]
    96f0:	cb010041 	sub	x1, x2, x1
    96f4:	eb00403f 	cmp	x1, x0, lsl #16
    96f8:	54000382 	b.cs	9768 <fwp_main_thread+0x1298>  // b.hs, b.nlast
    96fc:	d2800506 	mov	x6, #0x28                  	// #40
    9700:	d350fc20 	lsr	x0, x1, #16
    9704:	f949fca2 	ldr	x2, [x5, #5112]
    9708:	9b067c00 	mul	x0, x0, x6
    970c:	8b000047 	add	x7, x2, x0
    9710:	f94010fc 	ldr	x28, [x7, #32]
    9714:	b40002bc 	cbz	x28, 9768 <fwp_main_thread+0x1298>
    9718:	38606840 	ldrb	w0, [x2, x0]
    971c:	7100081f 	cmp	w0, #0x2
    9720:	54001de0 	b.eq	9adc <fwp_main_thread+0x160c>  // b.none
    9724:	7100041f 	cmp	w0, #0x1
    9728:	54000201 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    972c:	294300e8 	ldp	w8, w0, [x7, #24]
    9730:	92403c21 	and	x1, x1, #0xffff
    9734:	9b087c21 	mul	x1, x1, x8
    9738:	d360fc21 	lsr	x1, x1, #32
    973c:	eb00003f 	cmp	x1, x0
    9740:	54000142 	b.cs	9768 <fwp_main_thread+0x1298>  // b.hs, b.nlast
    9744:	8b01039c 	add	x28, x28, x1
    9748:	39400381 	ldrb	w1, [x28]
    974c:	340000e1 	cbz	w1, 9768 <fwp_main_thread+0x1298>
    9750:	7100043f 	cmp	w1, #0x1
    9754:	540003c0 	b.eq	97cc <fwp_main_thread+0x12fc>  // b.none
    9758:	7103fc3f 	cmp	w1, #0xff
    975c:	54007aa0 	b.eq	a6b0 <fwp_main_thread+0x21e0>  // b.none
    9760:	51000421 	sub	w1, w1, #0x1
    9764:	39000381 	strb	w1, [x28]
    9768:	52800040 	mov	w0, #0x2                   	// #2
    976c:	f9001be3 	str	x3, [sp, #48]
    9770:	97ffe7c0 	bl	3670 <descent_phase_step>
    9774:	b98053fc 	ldrsw	x28, [sp, #80]
    9778:	aa1c03e0 	mov	x0, x28
    977c:	97ffec89 	bl	49a0 <fwp_tape_of>
    9780:	f9403001 	ldr	x1, [x0, #96]
    9784:	aa0003e5 	mov	x5, x0
    9788:	f9401be3 	ldr	x3, [sp, #48]
    978c:	b4000e81 	cbz	x1, 995c <fwp_main_thread+0x148c>
    9790:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9794:	910b0000 	add	x0, x0, #0x2c0
    9798:	97ffea7e 	bl	4190 <fwp_trap>
    979c:	aa1803e0 	mov	x0, x24
    97a0:	97ffea9c 	bl	4210 <fwp_rc_forget_slot.part.0>
    97a4:	17fffd18 	b	8c04 <fwp_main_thread+0x734>
    97a8:	aa1803e0 	mov	x0, x24
    97ac:	97ffea99 	bl	4210 <fwp_rc_forget_slot.part.0>
    97b0:	17fffcf1 	b	8b74 <fwp_main_thread+0x6a4>
    97b4:	aa1703e0 	mov	x0, x23
    97b8:	97ffea96 	bl	4210 <fwp_rc_forget_slot.part.0>
    97bc:	17fffd37 	b	8c98 <fwp_main_thread+0x7c8>
    97c0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    97c4:	91126000 	add	x0, x0, #0x498
    97c8:	97ffea72 	bl	4190 <fwp_trap>
    97cc:	f9401fe4 	ldr	x4, [sp, #56]
    97d0:	f949eca7 	ldr	x7, [x5, #5080]
    97d4:	aa0403e0 	mov	x0, x4
    97d8:	f9400088 	ldr	x8, [x4]
    97dc:	f949d8a1 	ldr	x1, [x5, #5040]
    97e0:	d370bce7 	lsl	x7, x7, #16
    97e4:	cb010081 	sub	x1, x4, x1
    97e8:	b7f812c8 	tbnz	x8, #63, 9a40 <fwp_main_thread+0x1570>
    97ec:	eb07003f 	cmp	x1, x7
    97f0:	54fffbc2 	b.cs	9768 <fwp_main_thread+0x1298>  // b.hs, b.nlast
    97f4:	d350fc20 	lsr	x0, x1, #16
    97f8:	d2800505 	mov	x5, #0x28                  	// #40
    97fc:	9b057c00 	mul	x0, x0, x5
    9800:	8b000046 	add	x6, x2, x0
    9804:	f94010c5 	ldr	x5, [x6, #32]
    9808:	b4fffb05 	cbz	x5, 9768 <fwp_main_thread+0x1298>
    980c:	38606840 	ldrb	w0, [x2, x0]
    9810:	7100081f 	cmp	w0, #0x2
    9814:	54001700 	b.eq	9af4 <fwp_main_thread+0x1624>  // b.none
    9818:	7100041f 	cmp	w0, #0x1
    981c:	54fffa61 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    9820:	92403c20 	and	x0, x1, #0xffff
    9824:	294304c2 	ldp	w2, w1, [x6, #24]
    9828:	9b027c00 	mul	x0, x0, x2
    982c:	d360fc00 	lsr	x0, x0, #32
    9830:	eb01001f 	cmp	x0, x1
    9834:	54fff9a2 	b.cs	9768 <fwp_main_thread+0x1298>  // b.hs, b.nlast
    9838:	8b0000a5 	add	x5, x5, x0
    983c:	394000a0 	ldrb	w0, [x5]
    9840:	7100041f 	cmp	w0, #0x1
    9844:	54fff921 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    9848:	f9401fe0 	ldr	x0, [sp, #56]
    984c:	f9001be3 	str	x3, [sp, #48]
    9850:	97ffeb0c 	bl	4480 <fwp_mem_free>
    9854:	f9401be3 	ldr	x3, [sp, #48]
    9858:	17ffffc4 	b	9768 <fwp_main_thread+0x1298>
    985c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9860:	91146000 	add	x0, x0, #0x518
    9864:	97ffea4b 	bl	4190 <fwp_trap>
    9868:	97ffeb7f 	bl	4664 <fwp_rc_wide_dup>
    986c:	91174260 	add	x0, x19, #0x5d0
    9870:	f949ec05 	ldr	x5, [x0, #5080]
    9874:	f949d801 	ldr	x1, [x0, #5040]
    9878:	d370bca5 	lsl	x5, x5, #16
    987c:	17fffd3c 	b	8d6c <fwp_main_thread+0x89c>
    9880:	97ffeb79 	bl	4664 <fwp_rc_wide_dup>
    9884:	17fffd62 	b	8e0c <fwp_main_thread+0x93c>
    9888:	ca5c4780 	eor	x0, x28, x28, lsr #17
    988c:	91174262 	add	x2, x19, #0x5d0
    9890:	ca402400 	eor	x0, x0, x0, lsr #9
    9894:	92401c00 	and	x0, x0, #0xff
    9898:	910a2401 	add	x1, x0, #0x289
    989c:	8b000c40 	add	x0, x2, x0, lsl #3
    98a0:	8b010c41 	add	x1, x2, x1, lsl #3
    98a4:	f94a2400 	ldr	x0, [x0, #5192]
    98a8:	b50000a0 	cbnz	x0, 98bc <fwp_main_thread+0x13ec>
    98ac:	140000ef 	b	9c68 <fwp_main_thread+0x1798>
    98b0:	91004001 	add	x1, x0, #0x10
    98b4:	f9400800 	ldr	x0, [x0, #16]
    98b8:	b4001d80 	cbz	x0, 9c68 <fwp_main_thread+0x1798>
    98bc:	f9400002 	ldr	x2, [x0]
    98c0:	eb1c005f 	cmp	x2, x28
    98c4:	54ffff61 	b.ne	98b0 <fwp_main_thread+0x13e0>  // b.any
    98c8:	f9400021 	ldr	x1, [x1]
    98cc:	f9400420 	ldr	x0, [x1, #8]
    98d0:	d1000400 	sub	x0, x0, #0x1
    98d4:	f9000420 	str	x0, [x1, #8]
    98d8:	f103f81f 	cmp	x0, #0xfe
    98dc:	54ffada1 	b.ne	8e90 <fwp_main_thread+0x9c0>  // b.any
    98e0:	39400380 	ldrb	w0, [x28]
    98e4:	7103fc1f 	cmp	w0, #0xff
    98e8:	54001cc0 	b.eq	9c80 <fwp_main_thread+0x17b0>  // b.none
    98ec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    98f0:	39000380 	strb	w0, [x28]
    98f4:	17fffd67 	b	8e90 <fwp_main_thread+0x9c0>
    98f8:	d37ffb82 	lsl	x2, x28, #1
    98fc:	d3707d08 	ubfiz	x8, x8, #16, #32
    9900:	91000440 	add	x0, x2, #0x1
    9904:	aa070101 	orr	x1, x8, x7
    9908:	f90023e2 	str	x2, [sp, #64]
    990c:	d37df000 	lsl	x0, x0, #3
    9910:	f9002be1 	str	x1, [sp, #80]
    9914:	52800041 	mov	w1, #0x2                   	// #2
    9918:	97ffed96 	bl	4f70 <fwp_heap_alloc>
    991c:	aa0003e3 	mov	x3, x0
    9920:	91174261 	add	x1, x19, #0x5d0
    9924:	f94023e2 	ldr	x2, [sp, #64]
    9928:	aa0103e0 	mov	x0, x1
    992c:	f9000062 	str	x2, [x3]
    9930:	a9030fe3 	stp	x3, x3, [sp, #48]
    9934:	f949d821 	ldr	x1, [x1, #5040]
    9938:	f949ec00 	ldr	x0, [x0, #5080]
    993c:	cb010061 	sub	x1, x3, x1
    9940:	eb00403f 	cmp	x1, x0, lsl #16
    9944:	54ffe223 	b.cc	9588 <fwp_main_thread+0x10b8>  // b.lo, b.ul, b.last
    9948:	b5ffe55c 	cbnz	x28, 95f0 <fwp_main_thread+0x1120>
    994c:	f9401be0 	ldr	x0, [sp, #48]
    9950:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    9954:	f900001f 	str	xzr, [x0]
    9958:	17ffff62 	b	96e0 <fwp_main_thread+0x1210>
    995c:	f9002be3 	str	x3, [sp, #80]
    9960:	97ffe5ac 	bl	3010 <fwp_tape_unlink_scope>
    9964:	a94188a9 	ldp	x9, x2, [x5, #24]
    9968:	f9001be2 	str	x2, [sp, #48]
    996c:	f94014a2 	ldr	x2, [x5, #40]
    9970:	f9001fe2 	str	x2, [sp, #56]
    9974:	f94018a2 	ldr	x2, [x5, #48]
    9978:	f90023e2 	str	x2, [sp, #64]
    997c:	f9401ca2 	ldr	x2, [x5, #56]
    9980:	b90004bf 	str	wzr, [x5, #4]
    9984:	b94000a1 	ldr	w1, [x5]
    9988:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    998c:	f90027e2 	str	x2, [sp, #72]
    9990:	a940a0a7 	ldp	x7, x8, [x5, #8]
    9994:	6b00003f 	cmp	w1, w0
    9998:	f94020a6 	ldr	x6, [x5, #64]
    999c:	f94024a2 	ldr	x2, [x5, #72]
    99a0:	f9402be3 	ldr	x3, [sp, #80]
    99a4:	54000108 	b.hi	99c4 <fwp_main_thread+0x14f4>  // b.pmore
    99a8:	9101c281 	add	x1, x20, #0x70
    99ac:	92403f80 	and	x0, x28, #0xffff
    99b0:	d1000400 	sub	x0, x0, #0x1
    99b4:	f940742a 	ldr	x10, [x1, #232]
    99b8:	eb0a001f 	cmp	x0, x10
    99bc:	5400004a 	b.ge	99c4 <fwp_main_thread+0x14f4>  // b.tcont
    99c0:	f9007420 	str	x0, [x1, #232]
    99c4:	4f000400 	movi	v0.4s, #0x0
    99c8:	f9000cbf 	str	xzr, [x5, #24]
    99cc:	f9401be0 	ldr	x0, [sp, #48]
    99d0:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    99d4:	9101c281 	add	x1, x20, #0x70
    99d8:	3c8080a0 	stur	q0, [x5, #8]
    99dc:	9102c3e4 	add	x4, sp, #0xb0
    99e0:	ad0100a0 	stp	q0, q0, [x5, #32]
    99e4:	f90077e0 	str	x0, [sp, #232]
    99e8:	f9401fe0 	ldr	x0, [sp, #56]
    99ec:	f9007be0 	str	x0, [sp, #240]
    99f0:	f94023e0 	ldr	x0, [sp, #64]
    99f4:	f9007fe0 	str	x0, [sp, #248]
    99f8:	f94027e0 	ldr	x0, [sp, #72]
    99fc:	f90083e0 	str	x0, [sp, #256]
    9a00:	f9418820 	ldr	x0, [x1, #784]
    9a04:	f9002be4 	str	x4, [sp, #80]
    9a08:	f9005be0 	str	x0, [sp, #176]
    9a0c:	f0ffffc0 	adrp	x0, 4000 <fwp_wake_io+0x4c>
    9a10:	9101c000 	add	x0, x0, #0x70
    9a14:	f9005fe0 	str	x0, [sp, #184]
    9a18:	f90063f5 	str	x21, [sp, #192]
    9a1c:	a910a7e6 	stp	x6, x9, [sp, #264]
    9a20:	f9008fe2 	str	x2, [sp, #280]
    9a24:	f9018824 	str	x4, [x1, #784]
    9a28:	b7f811c3 	tbnz	x3, #63, 9c60 <fwp_main_thread+0x1790>
    9a2c:	eb83839f 	cmp	x28, x3, asr #32
    9a30:	54000680 	b.eq	9b00 <fwp_main_thread+0x1630>  // b.none
    9a34:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9a38:	9109e000 	add	x0, x0, #0x278
    9a3c:	97ffe9d5 	bl	4190 <fwp_trap>
    9a40:	f9400484 	ldr	x4, [x4, #8]
    9a44:	f9001fe4 	str	x4, [sp, #56]
    9a48:	eb07003f 	cmp	x1, x7
    9a4c:	54000382 	b.cs	9abc <fwp_main_thread+0x15ec>  // b.hs, b.nlast
    9a50:	d350fc28 	lsr	x8, x1, #16
    9a54:	d2800507 	mov	x7, #0x28                  	// #40
    9a58:	9b077d08 	mul	x8, x8, x7
    9a5c:	8b080049 	add	x9, x2, x8
    9a60:	f9401127 	ldr	x7, [x9, #32]
    9a64:	b40002c7 	cbz	x7, 9abc <fwp_main_thread+0x15ec>
    9a68:	38686842 	ldrb	w2, [x2, x8]
    9a6c:	7100085f 	cmp	w2, #0x2
    9a70:	54001020 	b.eq	9c74 <fwp_main_thread+0x17a4>  // b.none
    9a74:	7100045f 	cmp	w2, #0x1
    9a78:	54000221 	b.ne	9abc <fwp_main_thread+0x15ec>  // b.any
    9a7c:	29430928 	ldp	w8, w2, [x9, #24]
    9a80:	92403c21 	and	x1, x1, #0xffff
    9a84:	9b087c21 	mul	x1, x1, x8
    9a88:	d360fc21 	lsr	x1, x1, #32
    9a8c:	eb02003f 	cmp	x1, x2
    9a90:	54000162 	b.cs	9abc <fwp_main_thread+0x15ec>  // b.hs, b.nlast
    9a94:	8b0100e7 	add	x7, x7, x1
    9a98:	394000e1 	ldrb	w1, [x7]
    9a9c:	7100043f 	cmp	w1, #0x1
    9aa0:	540000e1 	b.ne	9abc <fwp_main_thread+0x15ec>  // b.any
    9aa4:	f9001be3 	str	x3, [sp, #48]
    9aa8:	f90023e5 	str	x5, [sp, #64]
    9aac:	97ffea75 	bl	4480 <fwp_mem_free>
    9ab0:	f9401be3 	ldr	x3, [sp, #48]
    9ab4:	d2800506 	mov	x6, #0x28                  	// #40
    9ab8:	f94023e5 	ldr	x5, [sp, #64]
    9abc:	91174260 	add	x0, x19, #0x5d0
    9ac0:	f9401fe2 	ldr	x2, [sp, #56]
    9ac4:	f949d801 	ldr	x1, [x0, #5040]
    9ac8:	f949ec00 	ldr	x0, [x0, #5080]
    9acc:	cb010041 	sub	x1, x2, x1
    9ad0:	eb00403f 	cmp	x1, x0, lsl #16
    9ad4:	54ffe163 	b.cc	9700 <fwp_main_thread+0x1230>  // b.lo, b.ul, b.last
    9ad8:	17ffff24 	b	9768 <fwp_main_thread+0x1298>
    9adc:	72003c3f 	tst	w1, #0xffff
    9ae0:	54ffe441 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    9ae4:	17ffff19 	b	9748 <fwp_main_thread+0x1278>
    9ae8:	72003c3f 	tst	w1, #0xffff
    9aec:	54ffd801 	b.ne	95ec <fwp_main_thread+0x111c>  // b.any
    9af0:	17fffeba 	b	95d8 <fwp_main_thread+0x1108>
    9af4:	72003c3f 	tst	w1, #0xffff
    9af8:	54ffe381 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    9afc:	17ffff50 	b	983c <fwp_main_thread+0x136c>
    9b00:	92407c60 	and	x0, x3, #0xffffffff
    9b04:	eb23411f 	cmp	x8, w3, uxtw
    9b08:	54000a6d 	b.le	9c54 <fwp_main_thread+0x1784>
    9b0c:	eb0000ff 	cmp	x7, x0
    9b10:	9a80c4fc 	csinc	x28, x7, x0, gt
    9b14:	eb1c005f 	cmp	x2, x28
    9b18:	54000baa 	b.ge	9c8c <fwp_main_thread+0x17bc>  // b.tcont
    9b1c:	f100005f 	cmp	x2, #0x0
    9b20:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    9b24:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    9b28:	14000004 	b	9b38 <fwp_main_thread+0x1668>
    9b2c:	eb00005f 	cmp	x2, x0
    9b30:	d37ff842 	lsl	x2, x2, #1
    9b34:	9a9cd042 	csel	x2, x2, x28, le
    9b38:	eb1c005f 	cmp	x2, x28
    9b3c:	54ffff8b 	b.lt	9b2c <fwp_main_thread+0x165c>  // b.tstop
    9b40:	a9061fe3 	stp	x3, x7, [sp, #96]
    9b44:	b4005fa6 	cbz	x6, a738 <fwp_main_thread+0x2268>
    9b48:	aa0603e0 	mov	x0, x6
    9b4c:	d37df041 	lsl	x1, x2, #3
    9b50:	f9002fe2 	str	x2, [sp, #88]
    9b54:	97ffe36b 	bl	2900 <realloc@plt>
    9b58:	a9458fe2 	ldp	x2, x3, [sp, #88]
    9b5c:	aa0003e6 	mov	x6, x0
    9b60:	f94037e7 	ldr	x7, [sp, #104]
    9b64:	b4000946 	cbz	x6, 9c8c <fwp_main_thread+0x17bc>
    9b68:	f90087e6 	str	x6, [sp, #264]
    9b6c:	f9008fe2 	str	x2, [sp, #280]
    9b70:	b500097c 	cbnz	x28, 9c9c <fwp_main_thread+0x17cc>
    9b74:	b7f800c3 	tbnz	x3, #63, 9b8c <fwp_main_thread+0x16bc>
    9b78:	d37d7c63 	ubfiz	x3, x3, #3, #32
    9b7c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9b80:	fc6368c0 	ldr	d0, [x6, x3]
    9b84:	1e612800 	fadd	d0, d0, d1
    9b88:	fc2368c0 	str	d0, [x6, x3]
    9b8c:	9101c281 	add	x1, x20, #0x70
    9b90:	cb070382 	sub	x2, x28, x7
    9b94:	52800060 	mov	w0, #0x3                   	// #3
    9b98:	a9059be7 	stp	x7, x6, [sp, #88]
    9b9c:	a9428c25 	ldp	x5, x3, [x1, #40]
    9ba0:	8b070063 	add	x3, x3, x7
    9ba4:	8b050042 	add	x2, x2, x5
    9ba8:	a9028c22 	stp	x2, x3, [x1, #40]
    9bac:	97ffe6b1 	bl	3670 <descent_phase_step>
    9bb0:	a9459be7 	ldp	x7, x6, [sp, #88]
    9bb4:	d1000780 	sub	x0, x28, #0x1
    9bb8:	eb0000ff 	cmp	x7, x0
    9bbc:	5400080c 	b.gt	9cbc <fwp_main_thread+0x17ec>
    9bc0:	fc6078c0 	ldr	d0, [x6, x0, lsl #3]
    9bc4:	1e602008 	fcmp	d0, #0.0
    9bc8:	540003a0 	b.eq	9c3c <fwp_main_thread+0x176c>  // b.none
    9bcc:	92800061 	mov	x1, #0xfffffffffffffffc    	// #-4
    9bd0:	f9401be2 	ldr	x2, [sp, #48]
    9bd4:	9b017ce1 	mul	x1, x7, x1
    9bd8:	8b010042 	add	x2, x2, x1
    9bdc:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    9be0:	37f80142 	tbnz	w2, #31, 9c08 <fwp_main_thread+0x1738>
    9be4:	f94023e4 	ldr	x4, [sp, #64]
    9be8:	928000e3 	mov	x3, #0xfffffffffffffff8    	// #-8
    9bec:	937d7c42 	sbfiz	x2, x2, #3, #32
    9bf0:	9b0310e3 	madd	x3, x7, x3, x4
    9bf4:	fc6268c1 	ldr	d1, [x6, x2]
    9bf8:	fc607862 	ldr	d2, [x3, x0, lsl #3]
    9bfc:	1e620802 	fmul	d2, d0, d2
    9c00:	1e622821 	fadd	d1, d1, d2
    9c04:	fc2268c1 	str	d1, [x6, x2]
    9c08:	f9401fe2 	ldr	x2, [sp, #56]
    9c0c:	8b010041 	add	x1, x2, x1
    9c10:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9c14:	37f80141 	tbnz	w1, #31, 9c3c <fwp_main_thread+0x176c>
    9c18:	f94027e3 	ldr	x3, [sp, #72]
    9c1c:	928000e2 	mov	x2, #0xfffffffffffffff8    	// #-8
    9c20:	937d7c21 	sbfiz	x1, x1, #3, #32
    9c24:	9b020ce2 	madd	x2, x7, x2, x3
    9c28:	fc6168c1 	ldr	d1, [x6, x1]
    9c2c:	fc607842 	ldr	d2, [x2, x0, lsl #3]
    9c30:	1e620800 	fmul	d0, d0, d2
    9c34:	1e602820 	fadd	d0, d1, d0
    9c38:	fc2168c0 	str	d0, [x6, x1]
    9c3c:	d1000400 	sub	x0, x0, #0x1
    9c40:	17ffffde 	b	9bb8 <fwp_main_thread+0x16e8>
    9c44:	f90023e0 	str	x0, [sp, #64]
    9c48:	97ffe972 	bl	4210 <fwp_rc_forget_slot.part.0>
    9c4c:	f94023e0 	ldr	x0, [sp, #64]
    9c50:	17fffe65 	b	95e4 <fwp_main_thread+0x1114>
    9c54:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9c58:	910bc000 	add	x0, x0, #0x2f0
    9c5c:	97ffe94d 	bl	4190 <fwp_trap>
    9c60:	aa0703fc 	mov	x28, x7
    9c64:	17ffffac 	b	9b14 <fwp_main_thread+0x1644>
    9c68:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9c6c:	9102a000 	add	x0, x0, #0xa8
    9c70:	97ffe948 	bl	4190 <fwp_trap>
    9c74:	72003c3f 	tst	w1, #0xffff
    9c78:	54fff221 	b.ne	9abc <fwp_main_thread+0x15ec>  // b.any
    9c7c:	17ffff87 	b	9a98 <fwp_main_thread+0x15c8>
    9c80:	aa1c03e0 	mov	x0, x28
    9c84:	97ffe963 	bl	4210 <fwp_rc_forget_slot.part.0>
    9c88:	17ffff19 	b	98ec <fwp_main_thread+0x141c>
    9c8c:	f100039f 	cmp	x28, #0x0
    9c90:	fa4018c0 	ccmp	x6, #0x0, #0x0, ne	// ne = any
    9c94:	54004e20 	b.eq	a658 <fwp_main_thread+0x2188>  // b.none
    9c98:	b4fff6fc 	cbz	x28, 9b74 <fwp_main_thread+0x16a4>
    9c9c:	aa0603e0 	mov	x0, x6
    9ca0:	d37df382 	lsl	x2, x28, #3
    9ca4:	52800001 	mov	w1, #0x0                   	// #0
    9ca8:	a9059fe3 	stp	x3, x7, [sp, #88]
    9cac:	97ffe30d 	bl	28e0 <memset@plt>
    9cb0:	a9459fe3 	ldp	x3, x7, [sp, #88]
    9cb4:	aa0003e6 	mov	x6, x0
    9cb8:	17ffffaf 	b	9b74 <fwp_main_thread+0x16a4>
    9cbc:	52800080 	mov	w0, #0x4                   	// #4
    9cc0:	a9031be7 	stp	x7, x6, [sp, #48]
    9cc4:	97ffe66b 	bl	3670 <descent_phase_step>
    9cc8:	a9431be7 	ldp	x7, x6, [sp, #48]
    9ccc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9cd0:	eb0000ff 	cmp	x7, x0
    9cd4:	54000ee8 	b.hi	9eb0 <fwp_main_thread+0x19e0>  // b.pmore
    9cd8:	910004e0 	add	x0, x7, #0x1
    9cdc:	52800041 	mov	w1, #0x2                   	// #2
    9ce0:	a9031be7 	stp	x7, x6, [sp, #48]
    9ce4:	d37df000 	lsl	x0, x0, #3
    9ce8:	97ffeca2 	bl	4f70 <fwp_heap_alloc>
    9cec:	aa0003fc 	mov	x28, x0
    9cf0:	a9431be7 	ldp	x7, x6, [sp, #48]
    9cf4:	d2800001 	mov	x1, #0x0                   	// #0
    9cf8:	f8008407 	str	x7, [x0], #8
    9cfc:	14000004 	b	9d0c <fwp_main_thread+0x183c>
    9d00:	f86178c2 	ldr	x2, [x6, x1, lsl #3]
    9d04:	f8217802 	str	x2, [x0, x1, lsl #3]
    9d08:	91000421 	add	x1, x1, #0x1
    9d0c:	eb0100ff 	cmp	x7, x1
    9d10:	54ffff81 	b.ne	9d00 <fwp_main_thread+0x1830>  // b.any
    9d14:	528000a0 	mov	w0, #0x5                   	// #5
    9d18:	97ffe656 	bl	3670 <descent_phase_step>
    9d1c:	9101c281 	add	x1, x20, #0x70
    9d20:	f9402be2 	ldr	x2, [sp, #80]
    9d24:	f9418820 	ldr	x0, [x1, #784]
    9d28:	eb02001f 	cmp	x0, x2
    9d2c:	540052a1 	b.ne	a780 <fwp_main_thread+0x22b0>  // b.any
    9d30:	f9405be2 	ldr	x2, [sp, #176]
    9d34:	aa1503e0 	mov	x0, x21
    9d38:	f9018822 	str	x2, [x1, #784]
    9d3c:	97ffe8cd 	bl	4070 <fwp_tape_buffers_release>
    9d40:	528000c0 	mov	w0, #0x6                   	// #6
    9d44:	97ffe64b 	bl	3670 <descent_phase_step>
    9d48:	91174260 	add	x0, x19, #0x5d0
    9d4c:	f949d801 	ldr	x1, [x0, #5040]
    9d50:	f949ec02 	ldr	x2, [x0, #5080]
    9d54:	cb010381 	sub	x1, x28, x1
    9d58:	eb02403f 	cmp	x1, x2, lsl #16
    9d5c:	54000322 	b.cs	9dc0 <fwp_main_thread+0x18f0>  // b.hs, b.nlast
    9d60:	d350fc22 	lsr	x2, x1, #16
    9d64:	d2800503 	mov	x3, #0x28                  	// #40
    9d68:	f949fc05 	ldr	x5, [x0, #5112]
    9d6c:	9b037c42 	mul	x2, x2, x3
    9d70:	8b0200a3 	add	x3, x5, x2
    9d74:	f9401060 	ldr	x0, [x3, #32]
    9d78:	b4000240 	cbz	x0, 9dc0 <fwp_main_thread+0x18f0>
    9d7c:	386268a2 	ldrb	w2, [x5, x2]
    9d80:	7100085f 	cmp	w2, #0x2
    9d84:	54004640 	b.eq	a64c <fwp_main_thread+0x217c>  // b.none
    9d88:	7100045f 	cmp	w2, #0x1
    9d8c:	540001a1 	b.ne	9dc0 <fwp_main_thread+0x18f0>  // b.any
    9d90:	29430865 	ldp	w5, w2, [x3, #24]
    9d94:	92403c21 	and	x1, x1, #0xffff
    9d98:	9b057c21 	mul	x1, x1, x5
    9d9c:	d360fc21 	lsr	x1, x1, #32
    9da0:	eb02003f 	cmp	x1, x2
    9da4:	540000e2 	b.cs	9dc0 <fwp_main_thread+0x18f0>  // b.hs, b.nlast
    9da8:	8b010000 	add	x0, x0, x1
    9dac:	39400001 	ldrb	w1, [x0]
    9db0:	7103fc3f 	cmp	w1, #0xff
    9db4:	54004440 	b.eq	a63c <fwp_main_thread+0x216c>  // b.none
    9db8:	52800021 	mov	w1, #0x1                   	// #1
    9dbc:	39000001 	strb	w1, [x0]
    9dc0:	9101c281 	add	x1, x20, #0x70
    9dc4:	f9400fe2 	ldr	x2, [sp, #24]
    9dc8:	f9418820 	ldr	x0, [x1, #784]
    9dcc:	eb02001f 	cmp	x0, x2
    9dd0:	54004d81 	b.ne	a780 <fwp_main_thread+0x22b0>  // b.any
    9dd4:	f9400be0 	ldr	x0, [sp, #16]
    9dd8:	f9404fe2 	ldr	x2, [sp, #152]
    9ddc:	f9018822 	str	x2, [x1, #784]
    9de0:	97fff17c 	bl	63d0 <fwp_tape_scope_release>
    9de4:	f9400380 	ldr	x0, [x28]
    9de8:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    9dec:	b7f80880 	tbnz	x0, #63, 9efc <fwp_main_thread+0x1a2c>
    9df0:	91174261 	add	x1, x19, #0x5d0
    9df4:	f949d820 	ldr	x0, [x1, #5040]
    9df8:	f949ec22 	ldr	x2, [x1, #5080]
    9dfc:	cb000380 	sub	x0, x28, x0
    9e00:	eb02401f 	cmp	x0, x2, lsl #16
    9e04:	540007c2 	b.cs	9efc <fwp_main_thread+0x1a2c>  // b.hs, b.nlast
    9e08:	d350fc02 	lsr	x2, x0, #16
    9e0c:	d2800505 	mov	x5, #0x28                  	// #40
    9e10:	f949fc26 	ldr	x6, [x1, #5112]
    9e14:	9b057c42 	mul	x2, x2, x5
    9e18:	8b0200c5 	add	x5, x6, x2
    9e1c:	f94010a1 	ldr	x1, [x5, #32]
    9e20:	b40006e1 	cbz	x1, 9efc <fwp_main_thread+0x1a2c>
    9e24:	386268c2 	ldrb	w2, [x6, x2]
    9e28:	7100085f 	cmp	w2, #0x2
    9e2c:	54000640 	b.eq	9ef4 <fwp_main_thread+0x1a24>  // b.none
    9e30:	7100045f 	cmp	w2, #0x1
    9e34:	54000641 	b.ne	9efc <fwp_main_thread+0x1a2c>  // b.any
    9e38:	294308a6 	ldp	w6, w2, [x5, #24]
    9e3c:	92403c00 	and	x0, x0, #0xffff
    9e40:	9b067c00 	mul	x0, x0, x6
    9e44:	d360fc00 	lsr	x0, x0, #32
    9e48:	eb02001f 	cmp	x0, x2
    9e4c:	54000582 	b.cs	9efc <fwp_main_thread+0x1a2c>  // b.hs, b.nlast
    9e50:	8b000021 	add	x1, x1, x0
    9e54:	39400020 	ldrb	w0, [x1]
    9e58:	7100041f 	cmp	w0, #0x1
    9e5c:	54000501 	b.ne	9efc <fwp_main_thread+0x1a2c>  // b.any
    9e60:	aa1c03e2 	mov	x2, x28
    9e64:	d2800000 	mov	x0, #0x0                   	// #0
    9e68:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x150>
    9e6c:	91002387 	add	x7, x28, #0x8
    9e70:	d2800001 	mov	x1, #0x0                   	// #0
    9e74:	fd466081 	ldr	d1, [x4, #3264]
    9e78:	eb01007f 	cmp	x3, x1
    9e7c:	540002a0 	b.eq	9ed0 <fwp_main_thread+0x1a00>  // b.none
    9e80:	f9400385 	ldr	x5, [x28]
    9e84:	b7f80225 	tbnz	x5, #63, 9ec8 <fwp_main_thread+0x19f8>
    9e88:	aa0703e6 	mov	x6, x7
    9e8c:	f9400048 	ldr	x8, [x2]
    9e90:	d37df025 	lsl	x5, x1, #3
    9e94:	fc6568c0 	ldr	d0, [x6, x5]
    9e98:	b7f80128 	tbnz	x8, #63, 9ebc <fwp_main_thread+0x19ec>
    9e9c:	1e600820 	fmul	d0, d1, d0
    9ea0:	8b0200a5 	add	x5, x5, x2
    9ea4:	91000421 	add	x1, x1, #0x1
    9ea8:	fd0004a0 	str	d0, [x5, #8]
    9eac:	17fffff3 	b	9e78 <fwp_main_thread+0x19a8>
    9eb0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9eb4:	91132000 	add	x0, x0, #0x4c8
    9eb8:	97ffe8b6 	bl	4190 <fwp_trap>
    9ebc:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    9ec0:	91136000 	add	x0, x0, #0x4d8
    9ec4:	97ffe8b3 	bl	4190 <fwp_trap>
    9ec8:	f9400b86 	ldr	x6, [x28, #16]
    9ecc:	17fffff0 	b	9e8c <fwp_main_thread+0x19bc>
    9ed0:	f9001be2 	str	x2, [sp, #48]
    9ed4:	97fff34b 	bl	6c00 <fwp_drop10>
    9ed8:	f9401be2 	ldr	x2, [sp, #48]
    9edc:	aa1803e0 	mov	x0, x24
    9ee0:	d2800006 	mov	x6, #0x0                   	// #0
    9ee4:	b4000620 	cbz	x0, 9fa8 <fwp_main_thread+0x1ad8>
    9ee8:	f9400800 	ldr	x0, [x0, #16]
    9eec:	910004c6 	add	x6, x6, #0x1
    9ef0:	17fffffd 	b	9ee4 <fwp_main_thread+0x1a14>
    9ef4:	72003c1f 	tst	w0, #0xffff
    9ef8:	54fffae0 	b.eq	9e54 <fwp_main_thread+0x1984>  // b.none
    9efc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9f00:	eb00007f 	cmp	x3, x0
    9f04:	54fffd68 	b.hi	9eb0 <fwp_main_thread+0x19e0>  // b.pmore
    9f08:	91000460 	add	x0, x3, #0x1
    9f0c:	52800021 	mov	w1, #0x1                   	// #1
    9f10:	f9001be3 	str	x3, [sp, #48]
    9f14:	d37df000 	lsl	x0, x0, #3
    9f18:	97ffec16 	bl	4f70 <fwp_heap_alloc>
    9f1c:	f9401be3 	ldr	x3, [sp, #48]
    9f20:	91174266 	add	x6, x19, #0x5d0
    9f24:	f9000003 	str	x3, [x0]
    9f28:	aa0003e2 	mov	x2, x0
    9f2c:	f949d8c1 	ldr	x1, [x6, #5040]
    9f30:	f949ecc0 	ldr	x0, [x6, #5080]
    9f34:	cb010041 	sub	x1, x2, x1
    9f38:	eb00403f 	cmp	x1, x0, lsl #16
    9f3c:	54000322 	b.cs	9fa0 <fwp_main_thread+0x1ad0>  // b.hs, b.nlast
    9f40:	d350fc25 	lsr	x5, x1, #16
    9f44:	d2800500 	mov	x0, #0x28                  	// #40
    9f48:	f949fcc7 	ldr	x7, [x6, #5112]
    9f4c:	9b007ca5 	mul	x5, x5, x0
    9f50:	8b0500e6 	add	x6, x7, x5
    9f54:	f94010c0 	ldr	x0, [x6, #32]
    9f58:	b4000240 	cbz	x0, 9fa0 <fwp_main_thread+0x1ad0>
    9f5c:	386568e5 	ldrb	w5, [x7, x5]
    9f60:	710008bf 	cmp	w5, #0x2
    9f64:	540033e0 	b.eq	a5e0 <fwp_main_thread+0x2110>  // b.none
    9f68:	710004bf 	cmp	w5, #0x1
    9f6c:	540001a1 	b.ne	9fa0 <fwp_main_thread+0x1ad0>  // b.any
    9f70:	294314c7 	ldp	w7, w5, [x6, #24]
    9f74:	92403c21 	and	x1, x1, #0xffff
    9f78:	9b077c21 	mul	x1, x1, x7
    9f7c:	d360fc21 	lsr	x1, x1, #32
    9f80:	eb05003f 	cmp	x1, x5
    9f84:	540000e2 	b.cs	9fa0 <fwp_main_thread+0x1ad0>  // b.hs, b.nlast
    9f88:	8b010000 	add	x0, x0, x1
    9f8c:	39400001 	ldrb	w1, [x0]
    9f90:	7103fc3f 	cmp	w1, #0xff
    9f94:	54000720 	b.eq	a078 <fwp_main_thread+0x1ba8>  // b.none
    9f98:	52800021 	mov	w1, #0x1                   	// #1
    9f9c:	39000001 	strb	w1, [x0]
    9fa0:	aa1c03e0 	mov	x0, x28
    9fa4:	17ffffb1 	b	9e68 <fwp_main_thread+0x1998>
    9fa8:	f9400040 	ldr	x0, [x2]
    9fac:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    9fb0:	b7f830c0 	tbnz	x0, #63, a5c8 <fwp_main_thread+0x20f8>
    9fb4:	91174261 	add	x1, x19, #0x5d0
    9fb8:	f949d820 	ldr	x0, [x1, #5040]
    9fbc:	f949ec23 	ldr	x3, [x1, #5080]
    9fc0:	cb000040 	sub	x0, x2, x0
    9fc4:	eb03401f 	cmp	x0, x3, lsl #16
    9fc8:	54003002 	b.cs	a5c8 <fwp_main_thread+0x20f8>  // b.hs, b.nlast
    9fcc:	d350fc03 	lsr	x3, x0, #16
    9fd0:	d2800507 	mov	x7, #0x28                  	// #40
    9fd4:	f949fc28 	ldr	x8, [x1, #5112]
    9fd8:	9b077c63 	mul	x3, x3, x7
    9fdc:	8b030107 	add	x7, x8, x3
    9fe0:	f94010e1 	ldr	x1, [x7, #32]
    9fe4:	b4002f21 	cbz	x1, a5c8 <fwp_main_thread+0x20f8>
    9fe8:	38636903 	ldrb	w3, [x8, x3]
    9fec:	7100087f 	cmp	w3, #0x2
    9ff0:	54002e80 	b.eq	a5c0 <fwp_main_thread+0x20f0>  // b.none
    9ff4:	7100047f 	cmp	w3, #0x1
    9ff8:	54002e81 	b.ne	a5c8 <fwp_main_thread+0x20f8>  // b.any
    9ffc:	29430ce8 	ldp	w8, w3, [x7, #24]
    a000:	92403c00 	and	x0, x0, #0xffff
    a004:	9b087c00 	mul	x0, x0, x8
    a008:	d360fc00 	lsr	x0, x0, #32
    a00c:	eb03001f 	cmp	x0, x3
    a010:	54002dc2 	b.cs	a5c8 <fwp_main_thread+0x20f8>  // b.hs, b.nlast
    a014:	8b000021 	add	x1, x1, x0
    a018:	39400020 	ldrb	w0, [x1]
    a01c:	7100041f 	cmp	w0, #0x1
    a020:	54002d41 	b.ne	a5c8 <fwp_main_thread+0x20f8>  // b.any
    a024:	91002043 	add	x3, x2, #0x8
    a028:	b9003be0 	str	w0, [sp, #56]
    a02c:	eb0600bf 	cmp	x5, x6
    a030:	aa1803e1 	mov	x1, x24
    a034:	9a8690a5 	csel	x5, x5, x6, ls	// ls = plast
    a038:	91002047 	add	x7, x2, #0x8
    a03c:	d2800000 	mov	x0, #0x0                   	// #0
    a040:	14000008 	b	a060 <fwp_main_thread+0x1b90>
    a044:	aa0703e6 	mov	x6, x7
    a048:	fc6078c1 	ldr	d1, [x6, x0, lsl #3]
    a04c:	fd400420 	ldr	d0, [x1, #8]
    a050:	1e613800 	fsub	d0, d0, d1
    a054:	fc207860 	str	d0, [x3, x0, lsl #3]
    a058:	91000400 	add	x0, x0, #0x1
    a05c:	f9400821 	ldr	x1, [x1, #16]
    a060:	eb05001f 	cmp	x0, x5
    a064:	54000160 	b.eq	a090 <fwp_main_thread+0x1bc0>  // b.none
    a068:	f9400046 	ldr	x6, [x2]
    a06c:	b6fffec6 	tbz	x6, #63, a044 <fwp_main_thread+0x1b74>
    a070:	f9400846 	ldr	x6, [x2, #16]
    a074:	17fffff5 	b	a048 <fwp_main_thread+0x1b78>
    a078:	a9030fe0 	stp	x0, x3, [sp, #48]
    a07c:	f90023e2 	str	x2, [sp, #64]
    a080:	97ffe864 	bl	4210 <fwp_rc_forget_slot.part.0>
    a084:	a9430fe0 	ldp	x0, x3, [sp, #48]
    a088:	f94023e2 	ldr	x2, [sp, #64]
    a08c:	17ffffc3 	b	9f98 <fwp_main_thread+0x1ac8>
    a090:	91174260 	add	x0, x19, #0x5d0
    a094:	aa1803ea 	mov	x10, x24
    a098:	d2800006 	mov	x6, #0x0                   	// #0
    a09c:	d280050b 	mov	x11, #0x28                  	// #40
    a0a0:	f949ec08 	ldr	x8, [x0, #5080]
    a0a4:	f949d80c 	ldr	x12, [x0, #5040]
    a0a8:	f949fc0d 	ldr	x13, [x0, #5112]
    a0ac:	d370bd08 	lsl	x8, x8, #16
    a0b0:	14000003 	b	a0bc <fwp_main_thread+0x1bec>
    a0b4:	f940094a 	ldr	x10, [x10, #16]
    a0b8:	910004c6 	add	x6, x6, #0x1
    a0bc:	f100015f 	cmp	x10, #0x0
    a0c0:	fa4510c2 	ccmp	x6, x5, #0x2, ne	// ne = any
    a0c4:	54000302 	b.cs	a124 <fwp_main_thread+0x1c54>  // b.hs, b.nlast
    a0c8:	cb0c0140 	sub	x0, x10, x12
    a0cc:	eb08001f 	cmp	x0, x8
    a0d0:	540002a2 	b.cs	a124 <fwp_main_thread+0x1c54>  // b.hs, b.nlast
    a0d4:	d350fc07 	lsr	x7, x0, #16
    a0d8:	9b0b7ce7 	mul	x7, x7, x11
    a0dc:	8b0701a9 	add	x9, x13, x7
    a0e0:	f9401121 	ldr	x1, [x9, #32]
    a0e4:	b4000201 	cbz	x1, a124 <fwp_main_thread+0x1c54>
    a0e8:	386769a7 	ldrb	w7, [x13, x7]
    a0ec:	710008ff 	cmp	w7, #0x2
    a0f0:	54000f60 	b.eq	a2dc <fwp_main_thread+0x1e0c>  // b.none
    a0f4:	710004ff 	cmp	w7, #0x1
    a0f8:	54000161 	b.ne	a124 <fwp_main_thread+0x1c54>  // b.any
    a0fc:	29431d2e 	ldp	w14, w7, [x9, #24]
    a100:	92403c00 	and	x0, x0, #0xffff
    a104:	9b0e7c00 	mul	x0, x0, x14
    a108:	d360fc00 	lsr	x0, x0, #32
    a10c:	eb07001f 	cmp	x0, x7
    a110:	540000a2 	b.cs	a124 <fwp_main_thread+0x1c54>  // b.hs, b.nlast
    a114:	8b000021 	add	x1, x1, x0
    a118:	39400020 	ldrb	w0, [x1]
    a11c:	7100041f 	cmp	w0, #0x1
    a120:	54fffca0 	b.eq	a0b4 <fwp_main_thread+0x1be4>  // b.none
    a124:	d280001c 	mov	x28, #0x0                   	// #0
    a128:	eb0500df 	cmp	x6, x5
    a12c:	540005c2 	b.cs	a1e4 <fwp_main_thread+0x1d14>  // b.hs, b.nlast
    a130:	d1002067 	sub	x7, x3, #0x8
    a134:	aa1603e1 	mov	x1, x22
    a138:	52800020 	mov	w0, #0x1                   	// #1
    a13c:	f9001be5 	str	x5, [sp, #48]
    a140:	a9040be3 	stp	x3, x2, [sp, #64]
    a144:	f86578e7 	ldr	x7, [x7, x5, lsl #3]
    a148:	f9002be6 	str	x6, [sp, #80]
    a14c:	a91573e7 	stp	x7, x28, [sp, #336]
    a150:	97ffebcd 	bl	5084 <fwp_data.part.0.constprop.0>
    a154:	aa0003fc 	mov	x28, x0
    a158:	91174268 	add	x8, x19, #0x5d0
    a15c:	f9401be5 	ldr	x5, [sp, #48]
    a160:	f949d901 	ldr	x1, [x8, #5040]
    a164:	f949ed00 	ldr	x0, [x8, #5080]
    a168:	cb010381 	sub	x1, x28, x1
    a16c:	a9440be3 	ldp	x3, x2, [sp, #64]
    a170:	f9402be6 	ldr	x6, [sp, #80]
    a174:	eb00403f 	cmp	x1, x0, lsl #16
    a178:	54000322 	b.cs	a1dc <fwp_main_thread+0x1d0c>  // b.hs, b.nlast
    a17c:	d350fc27 	lsr	x7, x1, #16
    a180:	d2800500 	mov	x0, #0x28                  	// #40
    a184:	f949fd09 	ldr	x9, [x8, #5112]
    a188:	9b007ce7 	mul	x7, x7, x0
    a18c:	8b070128 	add	x8, x9, x7
    a190:	f9401100 	ldr	x0, [x8, #32]
    a194:	b4000240 	cbz	x0, a1dc <fwp_main_thread+0x1d0c>
    a198:	38676927 	ldrb	w7, [x9, x7]
    a19c:	710008ff 	cmp	w7, #0x2
    a1a0:	54002040 	b.eq	a5a8 <fwp_main_thread+0x20d8>  // b.none
    a1a4:	710004ff 	cmp	w7, #0x1
    a1a8:	540001a1 	b.ne	a1dc <fwp_main_thread+0x1d0c>  // b.any
    a1ac:	29431d09 	ldp	w9, w7, [x8, #24]
    a1b0:	92403c21 	and	x1, x1, #0xffff
    a1b4:	9b097c21 	mul	x1, x1, x9
    a1b8:	d360fc21 	lsr	x1, x1, #32
    a1bc:	eb07003f 	cmp	x1, x7
    a1c0:	540000e2 	b.cs	a1dc <fwp_main_thread+0x1d0c>  // b.hs, b.nlast
    a1c4:	8b010000 	add	x0, x0, x1
    a1c8:	39400001 	ldrb	w1, [x0]
    a1cc:	7103fc3f 	cmp	w1, #0xff
    a1d0:	54001220 	b.eq	a414 <fwp_main_thread+0x1f44>  // b.none
    a1d4:	52800021 	mov	w1, #0x1                   	// #1
    a1d8:	39000001 	strb	w1, [x0]
    a1dc:	d10004a5 	sub	x5, x5, #0x1
    a1e0:	17ffffd2 	b	a128 <fwp_main_thread+0x1c58>
    a1e4:	f9001bf8 	str	x24, [sp, #48]
    a1e8:	b40001a6 	cbz	x6, a21c <fwp_main_thread+0x1d4c>
    a1ec:	d2800000 	mov	x0, #0x0                   	// #0
    a1f0:	f9401be4 	ldr	x4, [sp, #48]
    a1f4:	f8607861 	ldr	x1, [x3, x0, lsl #3]
    a1f8:	91000400 	add	x0, x0, #0x1
    a1fc:	f9000481 	str	x1, [x4, #8]
    a200:	aa0403e1 	mov	x1, x4
    a204:	f9400884 	ldr	x4, [x4, #16]
    a208:	f9001be4 	str	x4, [sp, #48]
    a20c:	eb0000df 	cmp	x6, x0
    a210:	54ffff01 	b.ne	a1f0 <fwp_main_thread+0x1d20>  // b.any
    a214:	f900083c 	str	x28, [x1, #16]
    a218:	aa1803fc 	mov	x28, x24
    a21c:	b9403be0 	ldr	w0, [sp, #56]
    a220:	91174268 	add	x8, x19, #0x5d0
    a224:	92800007 	mov	x7, #0xffffffffffffffff    	// #-1
    a228:	7100001f 	cmp	w0, #0x0
    a22c:	9a9f0063 	csel	x3, x3, xzr, eq	// eq = none
    a230:	b10004ff 	cmn	x7, #0x1
    a234:	54ff7ee0 	b.eq	9210 <fwp_main_thread+0xd40>  // b.none
    a238:	f8677860 	ldr	x0, [x3, x7, lsl #3]
    a23c:	aa1603e1 	mov	x1, x22
    a240:	a9038fe7 	stp	x7, x3, [sp, #56]
    a244:	a904a3e2 	stp	x2, x8, [sp, #72]
    a248:	a91573e0 	stp	x0, x28, [sp, #336]
    a24c:	52800020 	mov	w0, #0x1                   	// #1
    a250:	97ffeb8d 	bl	5084 <fwp_data.part.0.constprop.0>
    a254:	a944a3e2 	ldp	x2, x8, [sp, #72]
    a258:	aa0003fc 	mov	x28, x0
    a25c:	a9438fe7 	ldp	x7, x3, [sp, #56]
    a260:	f949d901 	ldr	x1, [x8, #5040]
    a264:	f949ed00 	ldr	x0, [x8, #5080]
    a268:	cb010381 	sub	x1, x28, x1
    a26c:	eb00403f 	cmp	x1, x0, lsl #16
    a270:	54000322 	b.cs	a2d4 <fwp_main_thread+0x1e04>  // b.hs, b.nlast
    a274:	d350fc25 	lsr	x5, x1, #16
    a278:	d2800500 	mov	x0, #0x28                  	// #40
    a27c:	f949fd09 	ldr	x9, [x8, #5112]
    a280:	9b007ca5 	mul	x5, x5, x0
    a284:	8b050126 	add	x6, x9, x5
    a288:	f94010c0 	ldr	x0, [x6, #32]
    a28c:	b4000240 	cbz	x0, a2d4 <fwp_main_thread+0x1e04>
    a290:	38656925 	ldrb	w5, [x9, x5]
    a294:	710008bf 	cmp	w5, #0x2
    a298:	54001800 	b.eq	a598 <fwp_main_thread+0x20c8>  // b.none
    a29c:	710004bf 	cmp	w5, #0x1
    a2a0:	540001a1 	b.ne	a2d4 <fwp_main_thread+0x1e04>  // b.any
    a2a4:	294314c9 	ldp	w9, w5, [x6, #24]
    a2a8:	92403c21 	and	x1, x1, #0xffff
    a2ac:	9b097c21 	mul	x1, x1, x9
    a2b0:	d360fc21 	lsr	x1, x1, #32
    a2b4:	eb05003f 	cmp	x1, x5
    a2b8:	540000e2 	b.cs	a2d4 <fwp_main_thread+0x1e04>  // b.hs, b.nlast
    a2bc:	8b010000 	add	x0, x0, x1
    a2c0:	39400001 	ldrb	w1, [x0]
    a2c4:	7103fc3f 	cmp	w1, #0xff
    a2c8:	54001580 	b.eq	a578 <fwp_main_thread+0x20a8>  // b.none
    a2cc:	52800021 	mov	w1, #0x1                   	// #1
    a2d0:	39000001 	strb	w1, [x0]
    a2d4:	d10004e7 	sub	x7, x7, #0x1
    a2d8:	17ffffd6 	b	a230 <fwp_main_thread+0x1d60>
    a2dc:	72003c1f 	tst	w0, #0xffff
    a2e0:	54fff221 	b.ne	a124 <fwp_main_thread+0x1c54>  // b.any
    a2e4:	17ffff8d 	b	a118 <fwp_main_thread+0x1c48>
    a2e8:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x150>
    a2ec:	91140000 	add	x0, x0, #0x500
    a2f0:	97ffe7a8 	bl	4190 <fwp_trap>
    a2f4:	f9401be0 	ldr	x0, [sp, #48]
    a2f8:	97ffedc2 	bl	5a00 <fwp_rc_free_arr>
    a2fc:	17fffc79 	b	94e0 <fwp_main_thread+0x1010>
    a300:	72003c3f 	tst	w1, #0xffff
    a304:	54ff8ee1 	b.ne	94e0 <fwp_main_thread+0x1010>  // b.any
    a308:	17fffc6e 	b	94c0 <fwp_main_thread+0xff0>
    a30c:	72003c3f 	tst	w1, #0xffff
    a310:	54ff88e1 	b.ne	942c <fwp_main_thread+0xf5c>  // b.any
    a314:	17fffc41 	b	9418 <fwp_main_thread+0xf48>
    a318:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a31c:	91174260 	add	x0, x19, #0x5d0
    a320:	ca412421 	eor	x1, x1, x1, lsr #9
    a324:	92401c21 	and	x1, x1, #0xff
    a328:	910a2422 	add	x2, x1, #0x289
    a32c:	8b010c01 	add	x1, x0, x1, lsl #3
    a330:	8b020c02 	add	x2, x0, x2, lsl #3
    a334:	f94a2420 	ldr	x0, [x1, #5192]
    a338:	b4ffc980 	cbz	x0, 9c68 <fwp_main_thread+0x1798>
    a33c:	f9400001 	ldr	x1, [x0]
    a340:	eb01039f 	cmp	x28, x1
    a344:	54000100 	b.eq	a364 <fwp_main_thread+0x1e94>  // b.none
    a348:	91004002 	add	x2, x0, #0x10
    a34c:	f9400800 	ldr	x0, [x0, #16]
    a350:	17fffffa 	b	a338 <fwp_main_thread+0x1e68>
    a354:	f90023e0 	str	x0, [sp, #64]
    a358:	97ffe7ae 	bl	4210 <fwp_rc_forget_slot.part.0>
    a35c:	f94023e0 	ldr	x0, [sp, #64]
    a360:	17fffc31 	b	9424 <fwp_main_thread+0xf54>
    a364:	f9400041 	ldr	x1, [x2]
    a368:	f9400420 	ldr	x0, [x1, #8]
    a36c:	d1000400 	sub	x0, x0, #0x1
    a370:	f9000420 	str	x0, [x1, #8]
    a374:	f103f81f 	cmp	x0, #0xfe
    a378:	54ff8b41 	b.ne	94e0 <fwp_main_thread+0x1010>  // b.any
    a37c:	39400380 	ldrb	w0, [x28]
    a380:	7103fc1f 	cmp	w0, #0xff
    a384:	54000260 	b.eq	a3d0 <fwp_main_thread+0x1f00>  // b.none
    a388:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a38c:	39000380 	strb	w0, [x28]
    a390:	17fffc54 	b	94e0 <fwp_main_thread+0x1010>
    a394:	f9400045 	ldr	x5, [x2]
    a398:	aa0203e0 	mov	x0, x2
    a39c:	b7f80245 	tbnz	x5, #63, a3e4 <fwp_main_thread+0x1f14>
    a3a0:	710008df 	cmp	w6, #0x2
    a3a4:	540001c0 	b.eq	a3dc <fwp_main_thread+0x1f0c>  // b.none
    a3a8:	29430065 	ldp	w5, w0, [x3, #24]
    a3ac:	9b057c21 	mul	x1, x1, x5
    a3b0:	eb41801f 	cmp	x0, x1, lsr #32
    a3b4:	54ff7789 	b.ls	92a4 <fwp_main_thread+0xdd4>  // b.plast
    a3b8:	aa0203e0 	mov	x0, x2
    a3bc:	97ffe831 	bl	4480 <fwp_mem_free>
    a3c0:	17fffbb9 	b	92a4 <fwp_main_thread+0xdd4>
    a3c4:	f2403c21 	ands	x1, x1, #0xffff
    a3c8:	54ff76e1 	b.ne	92a4 <fwp_main_thread+0xdd4>  // b.any
    a3cc:	17fffbae 	b	9284 <fwp_main_thread+0xdb4>
    a3d0:	aa1c03e0 	mov	x0, x28
    a3d4:	97ffe78f 	bl	4210 <fwp_rc_forget_slot.part.0>
    a3d8:	17ffffec 	b	a388 <fwp_main_thread+0x1eb8>
    a3dc:	b5ff7641 	cbnz	x1, 92a4 <fwp_main_thread+0xdd4>
    a3e0:	17fffff6 	b	a3b8 <fwp_main_thread+0x1ee8>
    a3e4:	f9400442 	ldr	x2, [x2, #8]
    a3e8:	710008df 	cmp	w6, #0x2
    a3ec:	54000e60 	b.eq	a5b8 <fwp_main_thread+0x20e8>  // b.none
    a3f0:	29430c65 	ldp	w5, w3, [x3, #24]
    a3f4:	9b057c21 	mul	x1, x1, x5
    a3f8:	eb41807f 	cmp	x3, x1, lsr #32
    a3fc:	54ff7169 	b.ls	9228 <fwp_main_thread+0xd58>  // b.plast
    a400:	a9039fe2 	stp	x2, x7, [sp, #56]
    a404:	97ffe81f 	bl	4480 <fwp_mem_free>
    a408:	d2800508 	mov	x8, #0x28                  	// #40
    a40c:	a9439fe2 	ldp	x2, x7, [sp, #56]
    a410:	17fffb86 	b	9228 <fwp_main_thread+0xd58>
    a414:	f9001be0 	str	x0, [sp, #48]
    a418:	a9040be3 	stp	x3, x2, [sp, #64]
    a41c:	a90517e6 	stp	x6, x5, [sp, #80]
    a420:	97ffe77c 	bl	4210 <fwp_rc_forget_slot.part.0>
    a424:	f9401be0 	ldr	x0, [sp, #48]
    a428:	a9440be3 	ldp	x3, x2, [sp, #64]
    a42c:	a94517e6 	ldp	x6, x5, [sp, #80]
    a430:	17ffff69 	b	a1d4 <fwp_main_thread+0x1d04>
    a434:	ca404401 	eor	x1, x0, x0, lsr #17
    a438:	91174263 	add	x3, x19, #0x5d0
    a43c:	ca412421 	eor	x1, x1, x1, lsr #9
    a440:	92401c21 	and	x1, x1, #0xff
    a444:	910a2422 	add	x2, x1, #0x289
    a448:	8b010c61 	add	x1, x3, x1, lsl #3
    a44c:	8b020c62 	add	x2, x3, x2, lsl #3
    a450:	f94a2421 	ldr	x1, [x1, #5192]
    a454:	b4ffc0a1 	cbz	x1, 9c68 <fwp_main_thread+0x1798>
    a458:	f9400023 	ldr	x3, [x1]
    a45c:	eb00007f 	cmp	x3, x0
    a460:	54000260 	b.eq	a4ac <fwp_main_thread+0x1fdc>  // b.none
    a464:	91004022 	add	x2, x1, #0x10
    a468:	f9400821 	ldr	x1, [x1, #16]
    a46c:	17fffffa 	b	a454 <fwp_main_thread+0x1f84>
    a470:	ca404401 	eor	x1, x0, x0, lsr #17
    a474:	91174263 	add	x3, x19, #0x5d0
    a478:	ca412421 	eor	x1, x1, x1, lsr #9
    a47c:	92401c21 	and	x1, x1, #0xff
    a480:	910a2422 	add	x2, x1, #0x289
    a484:	8b010c61 	add	x1, x3, x1, lsl #3
    a488:	8b020c62 	add	x2, x3, x2, lsl #3
    a48c:	f94a2421 	ldr	x1, [x1, #5192]
    a490:	b4ffbec1 	cbz	x1, 9c68 <fwp_main_thread+0x1798>
    a494:	f9400023 	ldr	x3, [x1]
    a498:	eb00007f 	cmp	x3, x0
    a49c:	54000260 	b.eq	a4e8 <fwp_main_thread+0x2018>  // b.none
    a4a0:	91004022 	add	x2, x1, #0x10
    a4a4:	f9400821 	ldr	x1, [x1, #16]
    a4a8:	17fffffa 	b	a490 <fwp_main_thread+0x1fc0>
    a4ac:	f9400042 	ldr	x2, [x2]
    a4b0:	f9400441 	ldr	x1, [x2, #8]
    a4b4:	d1000421 	sub	x1, x1, #0x1
    a4b8:	f9000441 	str	x1, [x2, #8]
    a4bc:	f103f83f 	cmp	x1, #0xfe
    a4c0:	54ff6f21 	b.ne	92a4 <fwp_main_thread+0xdd4>  // b.any
    a4c4:	39400001 	ldrb	w1, [x0]
    a4c8:	7103fc3f 	cmp	w1, #0xff
    a4cc:	54000081 	b.ne	a4dc <fwp_main_thread+0x200c>  // b.any
    a4d0:	f9001fe0 	str	x0, [sp, #56]
    a4d4:	97ffe74f 	bl	4210 <fwp_rc_forget_slot.part.0>
    a4d8:	f9401fe0 	ldr	x0, [sp, #56]
    a4dc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a4e0:	39000001 	strb	w1, [x0]
    a4e4:	17fffb70 	b	92a4 <fwp_main_thread+0xdd4>
    a4e8:	f9400042 	ldr	x2, [x2]
    a4ec:	f9400441 	ldr	x1, [x2, #8]
    a4f0:	d1000421 	sub	x1, x1, #0x1
    a4f4:	f9000441 	str	x1, [x2, #8]
    a4f8:	f103f83f 	cmp	x1, #0xfe
    a4fc:	54ff7181 	b.ne	932c <fwp_main_thread+0xe5c>  // b.any
    a500:	39400001 	ldrb	w1, [x0]
    a504:	7103fc3f 	cmp	w1, #0xff
    a508:	540002c0 	b.eq	a560 <fwp_main_thread+0x2090>  // b.none
    a50c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a510:	39000001 	strb	w1, [x0]
    a514:	17fffb86 	b	932c <fwp_main_thread+0xe5c>
    a518:	f9401be2 	ldr	x2, [sp, #48]
    a51c:	aa0203e0 	mov	x0, x2
    a520:	f9400842 	ldr	x2, [x2, #16]
    a524:	f9001be2 	str	x2, [sp, #48]
    a528:	710008bf 	cmp	w5, #0x2
    a52c:	54000220 	b.eq	a570 <fwp_main_thread+0x20a0>  // b.none
    a530:	29430865 	ldp	w5, w2, [x3, #24]
    a534:	9b057c21 	mul	x1, x1, x5
    a538:	eb41805f 	cmp	x2, x1, lsr #32
    a53c:	54ff6b89 	b.ls	92ac <fwp_main_thread+0xddc>  // b.plast
    a540:	f9001fe6 	str	x6, [sp, #56]
    a544:	97ffe7cf 	bl	4480 <fwp_mem_free>
    a548:	f9401fe6 	ldr	x6, [sp, #56]
    a54c:	d2800507 	mov	x7, #0x28                  	// #40
    a550:	17fffb57 	b	92ac <fwp_main_thread+0xddc>
    a554:	f2403c21 	ands	x1, x1, #0xffff
    a558:	54ff6ea1 	b.ne	932c <fwp_main_thread+0xe5c>  // b.any
    a55c:	17fffb6c 	b	930c <fwp_main_thread+0xe3c>
    a560:	f9001be0 	str	x0, [sp, #48]
    a564:	97ffe72b 	bl	4210 <fwp_rc_forget_slot.part.0>
    a568:	f9401be0 	ldr	x0, [sp, #48]
    a56c:	17ffffe8 	b	a50c <fwp_main_thread+0x203c>
    a570:	b5ff69e1 	cbnz	x1, 92ac <fwp_main_thread+0xddc>
    a574:	17fffff3 	b	a540 <fwp_main_thread+0x2070>
    a578:	a9038fe0 	stp	x0, x3, [sp, #56]
    a57c:	a9049fe2 	stp	x2, x7, [sp, #72]
    a580:	f9002fe8 	str	x8, [sp, #88]
    a584:	97ffe723 	bl	4210 <fwp_rc_forget_slot.part.0>
    a588:	a9438fe0 	ldp	x0, x3, [sp, #56]
    a58c:	a9449fe2 	ldp	x2, x7, [sp, #72]
    a590:	f9402fe8 	ldr	x8, [sp, #88]
    a594:	17ffff4e 	b	a2cc <fwp_main_thread+0x1dfc>
    a598:	72003c3f 	tst	w1, #0xffff
    a59c:	54ffe920 	b.eq	a2c0 <fwp_main_thread+0x1df0>  // b.none
    a5a0:	d10004e7 	sub	x7, x7, #0x1
    a5a4:	17ffff23 	b	a230 <fwp_main_thread+0x1d60>
    a5a8:	72003c3f 	tst	w1, #0xffff
    a5ac:	54ffe0e0 	b.eq	a1c8 <fwp_main_thread+0x1cf8>  // b.none
    a5b0:	d10004a5 	sub	x5, x5, #0x1
    a5b4:	17fffedd 	b	a128 <fwp_main_thread+0x1c58>
    a5b8:	b5ff6381 	cbnz	x1, 9228 <fwp_main_thread+0xd58>
    a5bc:	17ffff91 	b	a400 <fwp_main_thread+0x1f30>
    a5c0:	72003c1f 	tst	w0, #0xffff
    a5c4:	54ffd2a0 	b.eq	a018 <fwp_main_thread+0x1b48>  // b.none
    a5c8:	aa1803fc 	mov	x28, x24
    a5cc:	d2800006 	mov	x6, #0x0                   	// #0
    a5d0:	b400011c 	cbz	x28, a5f0 <fwp_main_thread+0x2120>
    a5d4:	f9400b9c 	ldr	x28, [x28, #16]
    a5d8:	910004c6 	add	x6, x6, #0x1
    a5dc:	17fffffd 	b	a5d0 <fwp_main_thread+0x2100>
    a5e0:	72003c3f 	tst	w1, #0xffff
    a5e4:	54ffcd40 	b.eq	9f8c <fwp_main_thread+0x1abc>  // b.none
    a5e8:	aa1c03e0 	mov	x0, x28
    a5ec:	17fffe1f 	b	9e68 <fwp_main_thread+0x1998>
    a5f0:	a9038be5 	stp	x5, x2, [sp, #56]
    a5f4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a5f8:	eb0000df 	cmp	x6, x0
    a5fc:	54ff5988 	b.hi	912c <fwp_main_thread+0xc5c>  // b.pmore
    a600:	910004c0 	add	x0, x6, #0x1
    a604:	52800041 	mov	w1, #0x2                   	// #2
    a608:	f9001be6 	str	x6, [sp, #48]
    a60c:	d37df000 	lsl	x0, x0, #3
    a610:	97ffea58 	bl	4f70 <fwp_heap_alloc>
    a614:	a94317e6 	ldp	x6, x5, [sp, #48]
    a618:	aa1803e1 	mov	x1, x24
    a61c:	f94023e2 	ldr	x2, [sp, #64]
    a620:	aa0003e3 	mov	x3, x0
    a624:	b40006e1 	cbz	x1, a700 <fwp_main_thread+0x2230>
    a628:	f9400420 	ldr	x0, [x1, #8]
    a62c:	f83c7860 	str	x0, [x3, x28, lsl #3]
    a630:	9100079c 	add	x28, x28, #0x1
    a634:	f9400821 	ldr	x1, [x1, #16]
    a638:	17fffffb 	b	a624 <fwp_main_thread+0x2154>
    a63c:	f9001be0 	str	x0, [sp, #48]
    a640:	97ffe6f4 	bl	4210 <fwp_rc_forget_slot.part.0>
    a644:	f9401be0 	ldr	x0, [sp, #48]
    a648:	17fffddc 	b	9db8 <fwp_main_thread+0x18e8>
    a64c:	72003c3f 	tst	w1, #0xffff
    a650:	54ffbb81 	b.ne	9dc0 <fwp_main_thread+0x18f0>  // b.any
    a654:	17fffdd6 	b	9dac <fwp_main_thread+0x18dc>
    a658:	f9405be1 	ldr	x1, [sp, #176]
    a65c:	9101c294 	add	x20, x20, #0x70
    a660:	aa1503e0 	mov	x0, x21
    a664:	f9018a81 	str	x1, [x20, #784]
    a668:	97ffe682 	bl	4070 <fwp_tape_buffers_release>
    a66c:	b00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    a670:	f947e863 	ldr	x3, [x3, #4048]
    a674:	d2800262 	mov	x2, #0x13                  	// #19
    a678:	d2800021 	mov	x1, #0x1                   	// #1
    a67c:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1b30>
    a680:	913ae000 	add	x0, x0, #0xeb8
    a684:	f9400063 	ldr	x3, [x3]
    a688:	97ffe0e2 	bl	2a10 <fwrite@plt>
    a68c:	d2800000 	mov	x0, #0x0                   	// #0
    a690:	97ffe0ec 	bl	2a40 <fflush@plt>
    a694:	52800cc0 	mov	w0, #0x66                  	// #102
    a698:	97ffe0fa 	bl	2a80 <_Exit@plt>
    a69c:	f9011bf9 	str	x25, [sp, #560]
    a6a0:	f9011ffa 	str	x26, [sp, #568]
    a6a4:	f90123fb 	str	x27, [sp, #576]
    a6a8:	f90127fc 	str	x28, [sp, #584]
    a6ac:	97ffe2c1 	bl	31b0 <descent_phase_fail>
    a6b0:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a6b4:	91174260 	add	x0, x19, #0x5d0
    a6b8:	ca412421 	eor	x1, x1, x1, lsr #9
    a6bc:	92401c21 	and	x1, x1, #0xff
    a6c0:	910a2422 	add	x2, x1, #0x289
    a6c4:	8b010c01 	add	x1, x0, x1, lsl #3
    a6c8:	8b020c02 	add	x2, x0, x2, lsl #3
    a6cc:	f94a2420 	ldr	x0, [x1, #5192]
    a6d0:	b4ffacc0 	cbz	x0, 9c68 <fwp_main_thread+0x1798>
    a6d4:	f9400001 	ldr	x1, [x0]
    a6d8:	eb01039f 	cmp	x28, x1
    a6dc:	54000160 	b.eq	a708 <fwp_main_thread+0x2238>  // b.none
    a6e0:	91004002 	add	x2, x0, #0x10
    a6e4:	f9400800 	ldr	x0, [x0, #16]
    a6e8:	17fffffa 	b	a6d0 <fwp_main_thread+0x2200>
    a6ec:	f9011bf9 	str	x25, [sp, #560]
    a6f0:	f9011ffa 	str	x26, [sp, #568]
    a6f4:	f90123fb 	str	x27, [sp, #576]
    a6f8:	f90127fc 	str	x28, [sp, #584]
    a6fc:	97ffe085 	bl	2910 <__stack_chk_fail@plt>
    a700:	b9003bff 	str	wzr, [sp, #56]
    a704:	17fffe4a 	b	a02c <fwp_main_thread+0x1b5c>
    a708:	f9400041 	ldr	x1, [x2]
    a70c:	f9400420 	ldr	x0, [x1, #8]
    a710:	d1000400 	sub	x0, x0, #0x1
    a714:	f9000420 	str	x0, [x1, #8]
    a718:	f103f81f 	cmp	x0, #0xfe
    a71c:	54ff8261 	b.ne	9768 <fwp_main_thread+0x1298>  // b.any
    a720:	39400380 	ldrb	w0, [x28]
    a724:	7103fc1f 	cmp	w0, #0xff
    a728:	54000180 	b.eq	a758 <fwp_main_thread+0x2288>  // b.none
    a72c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a730:	39000380 	strb	w0, [x28]
    a734:	17fffc0d 	b	9768 <fwp_main_thread+0x1298>
    a738:	aa0203e0 	mov	x0, x2
    a73c:	d2800101 	mov	x1, #0x8                   	// #8
    a740:	f9002fe2 	str	x2, [sp, #88]
    a744:	97ffe06b 	bl	28f0 <calloc@plt>
    a748:	a9458fe2 	ldp	x2, x3, [sp, #88]
    a74c:	aa0003e6 	mov	x6, x0
    a750:	f94037e7 	ldr	x7, [sp, #104]
    a754:	17fffd04 	b	9b64 <fwp_main_thread+0x1694>
    a758:	aa1c03e0 	mov	x0, x28
    a75c:	f9001be3 	str	x3, [sp, #48]
    a760:	97ffe6ac 	bl	4210 <fwp_rc_forget_slot.part.0>
    a764:	f9401be3 	ldr	x3, [sp, #48]
    a768:	17fffff1 	b	a72c <fwp_main_thread+0x225c>
    a76c:	97ffe0e5 	bl	2b00 <fwp_trap_overflow.constprop.0>
    a770:	f9011bf9 	str	x25, [sp, #560]
    a774:	f9011ffa 	str	x26, [sp, #568]
    a778:	f90123fb 	str	x27, [sp, #576]
    a77c:	f90127fc 	str	x28, [sp, #584]
    a780:	97ffe078 	bl	2960 <abort@plt>
    a784:	d503201f 	nop
    a788:	d503201f 	nop
    a78c:	d503201f 	nop

000000000000a790 <__divti3>:
    a790:	d503245f 	bti	c
    a794:	d2800004 	mov	x4, #0x0                   	// #0
    a798:	b7f80721 	tbnz	x1, #63, a87c <__divti3+0xec>
    a79c:	b6f80083 	tbz	x3, #63, a7ac <__divti3+0x1c>
    a7a0:	eb0203e2 	negs	x2, x2
    a7a4:	aa2403e4 	mvn	x4, x4
    a7a8:	da0303e3 	ngc	x3, x3
    a7ac:	aa0203e6 	mov	x6, x2
    a7b0:	aa0003e7 	mov	x7, x0
    a7b4:	aa0103e5 	mov	x5, x1
    a7b8:	b5000583 	cbnz	x3, a868 <__divti3+0xd8>
    a7bc:	eb01005f 	cmp	x2, x1
    a7c0:	54000e69 	b.ls	a98c <__divti3+0x1fc>  // b.plast
    a7c4:	dac01040 	clz	x0, x2
    a7c8:	b40000e0 	cbz	x0, a7e4 <__divti3+0x54>
    a7cc:	4b0003e1 	neg	w1, w0
    a7d0:	9ac020a5 	lsl	x5, x5, x0
    a7d4:	9ac02046 	lsl	x6, x2, x0
    a7d8:	9ac124e1 	lsr	x1, x7, x1
    a7dc:	aa050025 	orr	x5, x1, x5
    a7e0:	9ac020e7 	lsl	x7, x7, x0
    a7e4:	d360fcc8 	lsr	x8, x6, #32
    a7e8:	92407cc2 	and	x2, x6, #0xffffffff
    a7ec:	9ac808a3 	udiv	x3, x5, x8
    a7f0:	9b089465 	msub	x5, x3, x8, x5
    a7f4:	aa0303e0 	mov	x0, x3
    a7f8:	9b037c41 	mul	x1, x2, x3
    a7fc:	93c780a5 	extr	x5, x5, x7, #32
    a800:	eb05003f 	cmp	x1, x5
    a804:	540000a9 	b.ls	a818 <__divti3+0x88>  // b.plast
    a808:	ab0500c5 	adds	x5, x6, x5
    a80c:	d1000460 	sub	x0, x3, #0x1
    a810:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a814:	540015a8 	b.hi	aac8 <__divti3+0x338>  // b.pmore
    a818:	cb0100a5 	sub	x5, x5, x1
    a81c:	9ac808a3 	udiv	x3, x5, x8
    a820:	9b089465 	msub	x5, x3, x8, x5
    a824:	aa0303e1 	mov	x1, x3
    a828:	9b037c42 	mul	x2, x2, x3
    a82c:	aa0703e3 	mov	x3, x7
    a830:	b3607ca3 	bfi	x3, x5, #32, #32
    a834:	eb03005f 	cmp	x2, x3
    a838:	540000c9 	b.ls	a850 <__divti3+0xc0>  // b.plast
    a83c:	ab0300c3 	adds	x3, x6, x3
    a840:	d1000425 	sub	x5, x1, #0x1
    a844:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a848:	d1000821 	sub	x1, x1, #0x2
    a84c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a850:	aa008020 	orr	x0, x1, x0, lsl #32
    a854:	d2800001 	mov	x1, #0x0                   	// #0
    a858:	b4000064 	cbz	x4, a864 <__divti3+0xd4>
    a85c:	eb0003e0 	negs	x0, x0
    a860:	da0103e1 	ngc	x1, x1
    a864:	d65f03c0 	ret
    a868:	eb01007f 	cmp	x3, x1
    a86c:	54000109 	b.ls	a88c <__divti3+0xfc>  // b.plast
    a870:	d2800001 	mov	x1, #0x0                   	// #0
    a874:	d2800000 	mov	x0, #0x0                   	// #0
    a878:	17fffff8 	b	a858 <__divti3+0xc8>
    a87c:	eb0003e0 	negs	x0, x0
    a880:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a884:	da0103e1 	ngc	x1, x1
    a888:	17ffffc5 	b	a79c <__divti3+0xc>
    a88c:	dac01067 	clz	x7, x3
    a890:	b40010e7 	cbz	x7, aaac <__divti3+0x31c>
    a894:	d2800805 	mov	x5, #0x40                  	// #64
    a898:	cb0700a5 	sub	x5, x5, x7
    a89c:	9ac72063 	lsl	x3, x3, x7
    a8a0:	9ac52448 	lsr	x8, x2, x5
    a8a4:	aa030108 	orr	x8, x8, x3
    a8a8:	9ac52426 	lsr	x6, x1, x5
    a8ac:	92407d0a 	and	x10, x8, #0xffffffff
    a8b0:	d360fd09 	lsr	x9, x8, #32
    a8b4:	9ac52403 	lsr	x3, x0, x5
    a8b8:	9ac72021 	lsl	x1, x1, x7
    a8bc:	aa010063 	orr	x3, x3, x1
    a8c0:	9ac72042 	lsl	x2, x2, x7
    a8c4:	9ac908cb 	udiv	x11, x6, x9
    a8c8:	9b099965 	msub	x5, x11, x9, x6
    a8cc:	aa0b03e1 	mov	x1, x11
    a8d0:	9b0b7d46 	mul	x6, x10, x11
    a8d4:	93c380a5 	extr	x5, x5, x3, #32
    a8d8:	eb0500df 	cmp	x6, x5
    a8dc:	540000a9 	b.ls	a8f0 <__divti3+0x160>  // b.plast
    a8e0:	ab050105 	adds	x5, x8, x5
    a8e4:	d1000561 	sub	x1, x11, #0x1
    a8e8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a8ec:	54000f48 	b.hi	aad4 <__divti3+0x344>  // b.pmore
    a8f0:	cb0600a6 	sub	x6, x5, x6
    a8f4:	9ac908cb 	udiv	x11, x6, x9
    a8f8:	9b099969 	msub	x9, x11, x9, x6
    a8fc:	aa0b03e5 	mov	x5, x11
    a900:	9b0b7d4a 	mul	x10, x10, x11
    a904:	b3607d23 	bfi	x3, x9, #32, #32
    a908:	eb03015f 	cmp	x10, x3
    a90c:	540000a9 	b.ls	a920 <__divti3+0x190>  // b.plast
    a910:	ab030103 	adds	x3, x8, x3
    a914:	d1000565 	sub	x5, x11, #0x1
    a918:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a91c:	54000e28 	b.hi	aae0 <__divti3+0x350>  // b.pmore
    a920:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a924:	92407c48 	and	x8, x2, #0xffffffff
    a928:	2a0503e5 	mov	w5, w5
    a92c:	d360fc42 	lsr	x2, x2, #32
    a930:	d360fc26 	lsr	x6, x1, #32
    a934:	cb0a0063 	sub	x3, x3, x10
    a938:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a93c:	9b087caa 	mul	x10, x5, x8
    a940:	9b087cc8 	mul	x8, x6, x8
    a944:	9b0220a5 	madd	x5, x5, x2, x8
    a948:	9b027cc6 	mul	x6, x6, x2
    a94c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a950:	8b0900c5 	add	x5, x6, x9
    a954:	eb02011f 	cmp	x8, x2
    a958:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a95c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a960:	eb06007f 	cmp	x3, x6
    a964:	540000e3 	b.cc	a980 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a968:	92407d4a 	and	x10, x10, #0xffffffff
    a96c:	9ac72000 	lsl	x0, x0, x7
    a970:	8b028142 	add	x2, x10, x2, lsl #32
    a974:	eb02001f 	cmp	x0, x2
    a978:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a97c:	54000a01 	b.ne	aabc <__divti3+0x32c>  // b.any
    a980:	d1000420 	sub	x0, x1, #0x1
    a984:	d2800001 	mov	x1, #0x0                   	// #0
    a988:	17ffffb4 	b	a858 <__divti3+0xc8>
    a98c:	b5000062 	cbnz	x2, a998 <__divti3+0x208>
    a990:	d2800022 	mov	x2, #0x1                   	// #1
    a994:	9ac30846 	udiv	x6, x2, x3
    a998:	dac010c8 	clz	x8, x6
    a99c:	b5000408 	cbnz	x8, aa1c <__divti3+0x28c>
    a9a0:	d360fcc9 	lsr	x9, x6, #32
    a9a4:	92407cc5 	and	x5, x6, #0xffffffff
    a9a8:	cb060023 	sub	x3, x1, x6
    a9ac:	d2800021 	mov	x1, #0x1                   	// #1
    a9b0:	9ac90868 	udiv	x8, x3, x9
    a9b4:	9b098d03 	msub	x3, x8, x9, x3
    a9b8:	aa0803e0 	mov	x0, x8
    a9bc:	9b057d02 	mul	x2, x8, x5
    a9c0:	93c78063 	extr	x3, x3, x7, #32
    a9c4:	eb03005f 	cmp	x2, x3
    a9c8:	540000a9 	b.ls	a9dc <__divti3+0x24c>  // b.plast
    a9cc:	ab0300c3 	adds	x3, x6, x3
    a9d0:	d1000500 	sub	x0, x8, #0x1
    a9d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a9d8:	54000968 	b.hi	ab04 <__divti3+0x374>  // b.pmore
    a9dc:	cb020063 	sub	x3, x3, x2
    a9e0:	9ac90862 	udiv	x2, x3, x9
    a9e4:	aa0203e8 	mov	x8, x2
    a9e8:	9b098c42 	msub	x2, x2, x9, x3
    a9ec:	aa0703e3 	mov	x3, x7
    a9f0:	9b057d05 	mul	x5, x8, x5
    a9f4:	b3607c43 	bfi	x3, x2, #32, #32
    a9f8:	eb0300bf 	cmp	x5, x3
    a9fc:	540000c9 	b.ls	aa14 <__divti3+0x284>  // b.plast
    aa00:	ab0300c2 	adds	x2, x6, x3
    aa04:	d1000503 	sub	x3, x8, #0x1
    aa08:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    aa0c:	d1000908 	sub	x8, x8, #0x2
    aa10:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    aa14:	aa008100 	orr	x0, x8, x0, lsl #32
    aa18:	17ffff90 	b	a858 <__divti3+0xc8>
    aa1c:	9ac820c6 	lsl	x6, x6, x8
    aa20:	d2800803 	mov	x3, #0x40                  	// #64
    aa24:	cb080063 	sub	x3, x3, x8
    aa28:	d360fcc9 	lsr	x9, x6, #32
    aa2c:	9ac82027 	lsl	x7, x1, x8
    aa30:	92407cc5 	and	x5, x6, #0xffffffff
    aa34:	9ac32422 	lsr	x2, x1, x3
    aa38:	9ac32403 	lsr	x3, x0, x3
    aa3c:	aa070063 	orr	x3, x3, x7
    aa40:	9ac9084a 	udiv	x10, x2, x9
    aa44:	9ac82007 	lsl	x7, x0, x8
    aa48:	9b098940 	msub	x0, x10, x9, x2
    aa4c:	aa0a03e1 	mov	x1, x10
    aa50:	9b0a7ca2 	mul	x2, x5, x10
    aa54:	93c38000 	extr	x0, x0, x3, #32
    aa58:	eb00005f 	cmp	x2, x0
    aa5c:	540000a9 	b.ls	aa70 <__divti3+0x2e0>  // b.plast
    aa60:	ab0000c0 	adds	x0, x6, x0
    aa64:	d1000541 	sub	x1, x10, #0x1
    aa68:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    aa6c:	54000468 	b.hi	aaf8 <__divti3+0x368>  // b.pmore
    aa70:	cb020000 	sub	x0, x0, x2
    aa74:	9ac9080a 	udiv	x10, x0, x9
    aa78:	9b098140 	msub	x0, x10, x9, x0
    aa7c:	aa0a03e2 	mov	x2, x10
    aa80:	9b0a7ca8 	mul	x8, x5, x10
    aa84:	b3607c03 	bfi	x3, x0, #32, #32
    aa88:	eb03011f 	cmp	x8, x3
    aa8c:	540000a9 	b.ls	aaa0 <__divti3+0x310>  // b.plast
    aa90:	ab0300c3 	adds	x3, x6, x3
    aa94:	d1000542 	sub	x2, x10, #0x1
    aa98:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    aa9c:	54000288 	b.hi	aaec <__divti3+0x35c>  // b.pmore
    aaa0:	cb080063 	sub	x3, x3, x8
    aaa4:	aa018041 	orr	x1, x2, x1, lsl #32
    aaa8:	17ffffc2 	b	a9b0 <__divti3+0x220>
    aaac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    aab0:	d2800001 	mov	x1, #0x0                   	// #0
    aab4:	9a9f87e0 	cset	x0, ls	// ls = plast
    aab8:	17ffff68 	b	a858 <__divti3+0xc8>
    aabc:	aa0103e0 	mov	x0, x1
    aac0:	d2800001 	mov	x1, #0x0                   	// #0
    aac4:	17ffff65 	b	a858 <__divti3+0xc8>
    aac8:	d1000860 	sub	x0, x3, #0x2
    aacc:	8b0600a5 	add	x5, x5, x6
    aad0:	17ffff52 	b	a818 <__divti3+0x88>
    aad4:	d1000961 	sub	x1, x11, #0x2
    aad8:	8b0800a5 	add	x5, x5, x8
    aadc:	17ffff85 	b	a8f0 <__divti3+0x160>
    aae0:	d1000965 	sub	x5, x11, #0x2
    aae4:	8b080063 	add	x3, x3, x8
    aae8:	17ffff8e 	b	a920 <__divti3+0x190>
    aaec:	d1000942 	sub	x2, x10, #0x2
    aaf0:	8b060063 	add	x3, x3, x6
    aaf4:	17ffffeb 	b	aaa0 <__divti3+0x310>
    aaf8:	d1000941 	sub	x1, x10, #0x2
    aafc:	8b060000 	add	x0, x0, x6
    ab00:	17ffffdc 	b	aa70 <__divti3+0x2e0>
    ab04:	d1000900 	sub	x0, x8, #0x2
    ab08:	8b060063 	add	x3, x3, x6
    ab0c:	17ffffb4 	b	a9dc <__divti3+0x24c>

000000000000ab10 <__modti3>:
    ab10:	d503245f 	bti	c
    ab14:	d2800004 	mov	x4, #0x0                   	// #0
    ab18:	b6f80081 	tbz	x1, #63, ab28 <__modti3+0x18>
    ab1c:	eb0003e0 	negs	x0, x0
    ab20:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ab24:	da0103e1 	ngc	x1, x1
    ab28:	f100007f 	cmp	x3, #0x0
    ab2c:	5400128b 	b.lt	ad7c <__modti3+0x26c>  // b.tstop
    ab30:	aa0003e7 	mov	x7, x0
    ab34:	aa0103e6 	mov	x6, x1
    ab38:	540004e1 	b.ne	abd4 <__modti3+0xc4>  // b.any
    ab3c:	eb02003f 	cmp	x1, x2
    ab40:	54000dc2 	b.cs	acf8 <__modti3+0x1e8>  // b.hs, b.nlast
    ab44:	dac01043 	clz	x3, x2
    ab48:	aa0303e5 	mov	x5, x3
    ab4c:	b40000e3 	cbz	x3, ab68 <__modti3+0x58>
    ab50:	4b0303e6 	neg	w6, w3
    ab54:	9ac32021 	lsl	x1, x1, x3
    ab58:	9ac32042 	lsl	x2, x2, x3
    ab5c:	9ac62406 	lsr	x6, x0, x6
    ab60:	aa0100c6 	orr	x6, x6, x1
    ab64:	9ac32007 	lsl	x7, x0, x3
    ab68:	d360fc40 	lsr	x0, x2, #32
    ab6c:	92407c43 	and	x3, x2, #0xffffffff
    ab70:	9ac008c1 	udiv	x1, x6, x0
    ab74:	9b009826 	msub	x6, x1, x0, x6
    ab78:	9b017c61 	mul	x1, x3, x1
    ab7c:	93c780c6 	extr	x6, x6, x7, #32
    ab80:	eb06003f 	cmp	x1, x6
    ab84:	540000a9 	b.ls	ab98 <__modti3+0x88>  // b.plast
    ab88:	ab060046 	adds	x6, x2, x6
    ab8c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ab90:	8b0200c8 	add	x8, x6, x2
    ab94:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ab98:	cb0100c6 	sub	x6, x6, x1
    ab9c:	9ac008c8 	udiv	x8, x6, x0
    aba0:	9b009901 	msub	x1, x8, x0, x6
    aba4:	aa0703e0 	mov	x0, x7
    aba8:	9b087c63 	mul	x3, x3, x8
    abac:	b3607c20 	bfi	x0, x1, #32, #32
    abb0:	eb00007f 	cmp	x3, x0
    abb4:	54001088 	b.hi	adc4 <__modti3+0x2b4>  // b.pmore
    abb8:	cb030000 	sub	x0, x0, x3
    abbc:	9ac52400 	lsr	x0, x0, x5
    abc0:	d2800001 	mov	x1, #0x0                   	// #0
    abc4:	b4000064 	cbz	x4, abd0 <__modti3+0xc0>
    abc8:	eb0003e0 	negs	x0, x0
    abcc:	da0103e1 	ngc	x1, x1
    abd0:	d65f03c0 	ret
    abd4:	dac01066 	clz	x6, x3
    abd8:	eb03003f 	cmp	x1, x3
    abdc:	54ffff43 	b.cc	abc4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    abe0:	93407cc5 	sxtw	x5, w6
    abe4:	d2800808 	mov	x8, #0x40                  	// #64
    abe8:	cb050108 	sub	x8, x8, x5
    abec:	9ac62063 	lsl	x3, x3, x6
    abf0:	9ac62025 	lsl	x5, x1, x6
    abf4:	9ac82447 	lsr	x7, x2, x8
    abf8:	aa0300e7 	orr	x7, x7, x3
    abfc:	9ac82423 	lsr	x3, x1, x8
    ac00:	92407cec 	and	x12, x7, #0xffffffff
    ac04:	d360fcea 	lsr	x10, x7, #32
    ac08:	9ac82401 	lsr	x1, x0, x8
    ac0c:	aa050021 	orr	x1, x1, x5
    ac10:	9ac62042 	lsl	x2, x2, x6
    ac14:	9ac62000 	lsl	x0, x0, x6
    ac18:	9aca086b 	udiv	x11, x3, x10
    ac1c:	9b0a8d63 	msub	x3, x11, x10, x3
    ac20:	aa0b03e5 	mov	x5, x11
    ac24:	9b0b7d89 	mul	x9, x12, x11
    ac28:	93c18063 	extr	x3, x3, x1, #32
    ac2c:	eb03013f 	cmp	x9, x3
    ac30:	540000a9 	b.ls	ac44 <__modti3+0x134>  // b.plast
    ac34:	ab0300e3 	adds	x3, x7, x3
    ac38:	d1000565 	sub	x5, x11, #0x1
    ac3c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ac40:	54001168 	b.hi	ae6c <__modti3+0x35c>  // b.pmore
    ac44:	cb090063 	sub	x3, x3, x9
    ac48:	9aca086b 	udiv	x11, x3, x10
    ac4c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ac50:	aa0b03e9 	mov	x9, x11
    ac54:	9b0b7d8c 	mul	x12, x12, x11
    ac58:	b3607d41 	bfi	x1, x10, #32, #32
    ac5c:	eb01019f 	cmp	x12, x1
    ac60:	540000a9 	b.ls	ac74 <__modti3+0x164>  // b.plast
    ac64:	ab0100e1 	adds	x1, x7, x1
    ac68:	d1000569 	sub	x9, x11, #0x1
    ac6c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ac70:	54000f88 	b.hi	ae60 <__modti3+0x350>  // b.pmore
    ac74:	aa058123 	orr	x3, x9, x5, lsl #32
    ac78:	92407c4b 	and	x11, x2, #0xffffffff
    ac7c:	2a0903e9 	mov	w9, w9
    ac80:	d360fc4a 	lsr	x10, x2, #32
    ac84:	d360fc63 	lsr	x3, x3, #32
    ac88:	cb0c0021 	sub	x1, x1, x12
    ac8c:	aa0a03ec 	mov	x12, x10
    ac90:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ac94:	9b0b7d25 	mul	x5, x9, x11
    ac98:	9b0b7c6b 	mul	x11, x3, x11
    ac9c:	9b0a2d29 	madd	x9, x9, x10, x11
    aca0:	92407caa 	and	x10, x5, #0xffffffff
    aca4:	9b0c7c63 	mul	x3, x3, x12
    aca8:	8b458125 	add	x5, x9, x5, lsr #32
    acac:	8b0d0069 	add	x9, x3, x13
    acb0:	eb05017f 	cmp	x11, x5
    acb4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    acb8:	8b058149 	add	x9, x10, x5, lsl #32
    acbc:	8b458063 	add	x3, x3, x5, lsr #32
    acc0:	eb03003f 	cmp	x1, x3
    acc4:	54000063 	b.cc	acd0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    acc8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    accc:	54000082 	b.cs	acdc <__modti3+0x1cc>  // b.hs, b.nlast
    acd0:	eb020129 	subs	x9, x9, x2
    acd4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    acd8:	cb070063 	sub	x3, x3, x7
    acdc:	eb090000 	subs	x0, x0, x9
    ace0:	da030021 	sbc	x1, x1, x3
    ace4:	9ac62400 	lsr	x0, x0, x6
    ace8:	9ac82028 	lsl	x8, x1, x8
    acec:	aa000100 	orr	x0, x8, x0
    acf0:	9ac62421 	lsr	x1, x1, x6
    acf4:	17ffffb4 	b	abc4 <__modti3+0xb4>
    acf8:	b5000062 	cbnz	x2, ad04 <__modti3+0x1f4>
    acfc:	d2800023 	mov	x3, #0x1                   	// #1
    ad00:	9ac20862 	udiv	x2, x3, x2
    ad04:	dac01048 	clz	x8, x2
    ad08:	aa0803e5 	mov	x5, x8
    ad0c:	b5000668 	cbnz	x8, add8 <__modti3+0x2c8>
    ad10:	cb020020 	sub	x0, x1, x2
    ad14:	d360fc49 	lsr	x9, x2, #32
    ad18:	92407c4a 	and	x10, x2, #0xffffffff
    ad1c:	9ac90801 	udiv	x1, x0, x9
    ad20:	9b098020 	msub	x0, x1, x9, x0
    ad24:	9b0a7c21 	mul	x1, x1, x10
    ad28:	93c78000 	extr	x0, x0, x7, #32
    ad2c:	eb00003f 	cmp	x1, x0
    ad30:	540000a9 	b.ls	ad44 <__modti3+0x234>  // b.plast
    ad34:	ab000040 	adds	x0, x2, x0
    ad38:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ad3c:	8b020003 	add	x3, x0, x2
    ad40:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ad44:	cb010001 	sub	x1, x0, x1
    ad48:	9ac90820 	udiv	x0, x1, x9
    ad4c:	9b098403 	msub	x3, x0, x9, x1
    ad50:	aa0703e1 	mov	x1, x7
    ad54:	9b0a7c00 	mul	x0, x0, x10
    ad58:	b3607c61 	bfi	x1, x3, #32, #32
    ad5c:	eb01001f 	cmp	x0, x1
    ad60:	540000a9 	b.ls	ad74 <__modti3+0x264>  // b.plast
    ad64:	ab010041 	adds	x1, x2, x1
    ad68:	8b020022 	add	x2, x1, x2
    ad6c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ad70:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ad74:	cb000020 	sub	x0, x1, x0
    ad78:	17ffff91 	b	abbc <__modti3+0xac>
    ad7c:	eb0203e5 	negs	x5, x2
    ad80:	aa0003e7 	mov	x7, x0
    ad84:	da0303e8 	ngc	x8, x3
    ad88:	aa0503e2 	mov	x2, x5
    ad8c:	aa0803e3 	mov	x3, x8
    ad90:	aa0103e6 	mov	x6, x1
    ad94:	b4ffed48 	cbz	x8, ab3c <__modti3+0x2c>
    ad98:	eb01011f 	cmp	x8, x1
    ad9c:	54fff148 	b.hi	abc4 <__modti3+0xb4>  // b.pmore
    ada0:	dac01109 	clz	x9, x8
    ada4:	2a0903e6 	mov	w6, w9
    ada8:	b5fff1c9 	cbnz	x9, abe0 <__modti3+0xd0>
    adac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    adb0:	54000068 	b.hi	adbc <__modti3+0x2ac>  // b.pmore
    adb4:	eb050007 	subs	x7, x0, x5
    adb8:	da080021 	sbc	x1, x1, x8
    adbc:	aa0703e0 	mov	x0, x7
    adc0:	17ffff81 	b	abc4 <__modti3+0xb4>
    adc4:	ab000040 	adds	x0, x2, x0
    adc8:	8b020002 	add	x2, x0, x2
    adcc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    add0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    add4:	17ffff79 	b	abb8 <__modti3+0xa8>
    add8:	9ac82042 	lsl	x2, x2, x8
    addc:	d2800803 	mov	x3, #0x40                  	// #64
    ade0:	cb080063 	sub	x3, x3, x8
    ade4:	d360fc49 	lsr	x9, x2, #32
    ade8:	9ac82027 	lsl	x7, x1, x8
    adec:	92407c4a 	and	x10, x2, #0xffffffff
    adf0:	9ac32426 	lsr	x6, x1, x3
    adf4:	9ac32403 	lsr	x3, x0, x3
    adf8:	aa070063 	orr	x3, x3, x7
    adfc:	9ac908c1 	udiv	x1, x6, x9
    ae00:	9ac82007 	lsl	x7, x0, x8
    ae04:	9b099820 	msub	x0, x1, x9, x6
    ae08:	9b017d41 	mul	x1, x10, x1
    ae0c:	93c38000 	extr	x0, x0, x3, #32
    ae10:	eb00003f 	cmp	x1, x0
    ae14:	540000a9 	b.ls	ae28 <__modti3+0x318>  // b.plast
    ae18:	ab000040 	adds	x0, x2, x0
    ae1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ae20:	8b020006 	add	x6, x0, x2
    ae24:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ae28:	cb010000 	sub	x0, x0, x1
    ae2c:	9ac90801 	udiv	x1, x0, x9
    ae30:	9b098026 	msub	x6, x1, x9, x0
    ae34:	aa0303e0 	mov	x0, x3
    ae38:	9b017d41 	mul	x1, x10, x1
    ae3c:	b3607cc0 	bfi	x0, x6, #32, #32
    ae40:	eb00003f 	cmp	x1, x0
    ae44:	540000a9 	b.ls	ae58 <__modti3+0x348>  // b.plast
    ae48:	ab000040 	adds	x0, x2, x0
    ae4c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ae50:	8b020003 	add	x3, x0, x2
    ae54:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ae58:	cb010000 	sub	x0, x0, x1
    ae5c:	17ffffb0 	b	ad1c <__modti3+0x20c>
    ae60:	d1000969 	sub	x9, x11, #0x2
    ae64:	8b070021 	add	x1, x1, x7
    ae68:	17ffff83 	b	ac74 <__modti3+0x164>
    ae6c:	d1000965 	sub	x5, x11, #0x2
    ae70:	8b070063 	add	x3, x3, x7
    ae74:	17ffff74 	b	ac44 <__modti3+0x134>
    ae78:	d503201f 	nop
    ae7c:	d503201f 	nop

000000000000ae80 <atexit>:
    ae80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ae84:	d00000a2 	adrp	x2, 20000 <__data_start>
    ae88:	d2800001 	mov	x1, #0x0                   	// #0
    ae8c:	910003fd 	mov	x29, sp
    ae90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ae94:	f9400442 	ldr	x2, [x2, #8]
    ae98:	17ffde5e 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ae9c <_fini>:
    ae9c:	d503201f 	nop
    aea0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aea4:	910003fd 	mov	x29, sp
    aea8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aeac:	d65f03c0 	ret
