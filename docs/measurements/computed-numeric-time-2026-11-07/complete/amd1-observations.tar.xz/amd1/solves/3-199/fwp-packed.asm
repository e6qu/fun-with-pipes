
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-199/fwp-packed:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 7f 00 00 	mov    0x7fd9(%rip),%rax        # 9fe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 7e 00 00    	push   0x7e02(%rip)        # 9e28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 7e 00 00    	jmp    *0x7e04(%rip)        # 9e30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e 7c 00 00    	jmp    *0x7c7e(%rip)        # 9ff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae 7a 00 00    	jmp    *0x7aae(%rip)        # 9e38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 7a 00 00    	jmp    *0x7aa6(%rip)        # 9e40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e 7a 00 00    	jmp    *0x7a9e(%rip)        # 9e48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 7a 00 00    	jmp    *0x7a96(%rip)        # 9e50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e 7a 00 00    	jmp    *0x7a8e(%rip)        # 9e58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 7a 00 00    	jmp    *0x7a86(%rip)        # 9e60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e 7a 00 00    	jmp    *0x7a7e(%rip)        # 9e68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 7a 00 00    	jmp    *0x7a76(%rip)        # 9e70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e 7a 00 00    	jmp    *0x7a6e(%rip)        # 9e78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 7a 00 00    	jmp    *0x7a66(%rip)        # 9e80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e 7a 00 00    	jmp    *0x7a5e(%rip)        # 9e88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 7a 00 00    	jmp    *0x7a56(%rip)        # 9e90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e 7a 00 00    	jmp    *0x7a4e(%rip)        # 9e98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 7a 00 00    	jmp    *0x7a46(%rip)        # 9ea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e 7a 00 00    	jmp    *0x7a3e(%rip)        # 9ea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 7a 00 00    	jmp    *0x7a36(%rip)        # 9eb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e 7a 00 00    	jmp    *0x7a2e(%rip)        # 9eb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 7a 00 00    	jmp    *0x7a26(%rip)        # 9ec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e 7a 00 00    	jmp    *0x7a1e(%rip)        # 9ec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 7a 00 00    	jmp    *0x7a16(%rip)        # 9ed0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e 7a 00 00    	jmp    *0x7a0e(%rip)        # 9ed8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 7a 00 00    	jmp    *0x7a06(%rip)        # 9ee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe 79 00 00    	jmp    *0x79fe(%rip)        # 9ee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 79 00 00    	jmp    *0x79f6(%rip)        # 9ef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee 79 00 00    	jmp    *0x79ee(%rip)        # 9ef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 79 00 00    	jmp    *0x79e6(%rip)        # 9f00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de 79 00 00    	jmp    *0x79de(%rip)        # 9f08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 79 00 00    	jmp    *0x79d6(%rip)        # 9f10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce 79 00 00    	jmp    *0x79ce(%rip)        # 9f18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 79 00 00    	jmp    *0x79c6(%rip)        # 9f20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be 79 00 00    	jmp    *0x79be(%rip)        # 9f28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 79 00 00    	jmp    *0x79b6(%rip)        # 9f30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae 79 00 00    	jmp    *0x79ae(%rip)        # 9f38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 79 00 00    	jmp    *0x79a6(%rip)        # 9f40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e 79 00 00    	jmp    *0x799e(%rip)        # 9f48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 79 00 00    	jmp    *0x7996(%rip)        # 9f50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e 79 00 00    	jmp    *0x798e(%rip)        # 9f58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 79 00 00    	jmp    *0x7986(%rip)        # 9f60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e 79 00 00    	jmp    *0x797e(%rip)        # 9f68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 79 00 00    	jmp    *0x7976(%rip)        # 9f70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e 79 00 00    	jmp    *0x796e(%rip)        # 9f78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 79 00 00    	jmp    *0x7966(%rip)        # 9f80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e 79 00 00    	jmp    *0x795e(%rip)        # 9f88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 79 00 00    	jmp    *0x7956(%rip)        # 9f90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e 79 00 00    	jmp    *0x794e(%rip)        # 9f98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 79 00 00    	jmp    *0x7946(%rip)        # 9fa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e 79 00 00    	jmp    *0x793e(%rip)        # 9fa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 79 00 00    	jmp    *0x7936(%rip)        # 9fb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e 79 00 00    	jmp    *0x792e(%rip)        # 9fb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 79 00 00    	jmp    *0x7926(%rip)        # 9fc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e 79 00 00    	jmp    *0x791e(%rip)        # 9fc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 79 00 00    	jmp    *0x7916(%rip)        # 9fd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 59 00 00 	lea    0x59a0(%rip),%r9        # 8077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 59 00 00 	lea    0x599d(%rip),%r8        # 807b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>
    2710:	e8 ab ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 21 79 00 00 	mov    0x7921(%rip),%rax        # a060 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 32 9c 01 00 	mov    %rax,0x19c32(%rip)        # 1c378 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 5a 00 00 	lea    0x5a1c(%rip),%rdi        # 816e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d a6 78 00 00 	mov    0x78a6(%rip),%rdi        # a060 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 1d 37 00 00 	lea    0x371d(%rip),%rdx        # 5f30 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 11 78 00 00 	mov    0x7811(%rip),%rdi        # a060 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 66 78 01 00    	mov    0x17866(%rip),%eax        # 1a0c0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 58 00 00 	lea    0x58cc(%rip),%rdi        # 8177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 5a 00 00 	lea    0x5aec(%rip),%rdi        # 83a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d a6 5a 00 00 	lea    0x5aa6(%rip),%rdi        # 8380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 5a 00 00 	lea    0x5a6a(%rip),%rdi        # 8350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 5a 00 00 	lea    0x5a36(%rip),%rdi        # 8328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 76 00 00    	call   *0x76b3(%rip)        # 9fd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 21 77 00 00 	lea    0x7721(%rip),%rdi        # a058 <__TMC_END__>
    2937:	48 8d 05 1a 77 00 00 	lea    0x771a(%rip),%rax        # a058 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 76 00 00 	mov    0x7696(%rip),%rax        # 9fe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d f1 76 00 00 	lea    0x76f1(%rip),%rdi        # a058 <__TMC_END__>
    2967:	48 8d 35 ea 76 00 00 	lea    0x76ea(%rip),%rsi        # a058 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 76 00 00 	mov    0x7665(%rip),%rax        # 9ff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d dd 76 00 00 00 	cmpb   $0x0,0x76dd(%rip)        # a088 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 76 00 00 	cmpq   $0x0,0x7642(%rip)        # 9ff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 76 00 00 	mov    0x7646(%rip),%rdi        # a008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 b5 76 00 00 01 	movb   $0x1,0x76b5(%rip)        # a088 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d b1 97 01 00 	mov    0x197b1(%rip),%rdi        # 1c378 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d 84 74 00 00 	mov    0x7484(%rip),%rdi        # a060 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 71 74 00 00 	mov    0x7471(%rip),%rdi        # a060 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 53 00 00 	lea    0x53f5(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 62 74 00 00 	mov    0x7462(%rip),%rcx        # a080 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 b1 7a 01 00 	mov    0x17ab1(%rip),%rax        # 1a700 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 01 74 01 00 	mov    0x17401(%rip),%rax        # 1a0d0 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 ed 73 01 00 	sub    0x173ed(%rip),%rax        # 1a0c8 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 57 00 00 	lea    0x572d(%rip),%rsi        # 8440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 cb 8d 01 00 	mov    0x18dcb(%rip),%rax        # 1bb10 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 c4 8d 01 00 	lea    0x18dc4(%rip),%r8        # 1bb10 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d a5 8d 01 00 	mov    0x18da5(%rip),%rbx        # 1baf8 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d b5 8d 01 00 	mov    0x18db5(%rip),%rcx        # 1bb18 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 51 8d 01 00 	mov    0x18d51(%rip),%rdi        # 1bb00 <fwp_heap+0x13e0>
    2daf:	48 29 35 9a 8d 01 00 	sub    %rsi,0x18d9a(%rip)        # 1bb50 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 2a 8d 01 00 	mov    0x18d2a(%rip),%rax        # 1baf0 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d e0 8c 01 00 	add    0x18ce0(%rip),%rdi        # 1bad0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 ee 8c 01 00 	mov    0x18cee(%rip),%rsi        # 1bb00 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 fc 8c 01 00 	mov    0x18cfc(%rip),%rax        # 1bb18 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 ab 8c 01 00 	mov    %r12,0x18cab(%rip)        # 1bb00 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d 99 8c 01 00 	mov    %rbp,0x18c99(%rip)        # 1baf8 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 7e 8c 01 00 	cmp    %rdi,0x18c7e(%rip)        # 1bae8 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 75 8c 01 00 	mov    %rdi,0x18c75(%rip)        # 1bae8 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d b9 8c 01 00 	sub    %rdi,0x18cb9(%rip)        # 1bb50 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 61 8c 01 00 	mov    0x18c61(%rip),%rax        # 1bb08 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 5a 8c 01 00 	lea    0x18c5a(%rip),%r8        # 1bb08 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d 2d 71 00 00 	mov    0x712d(%rip),%rcx        # a080 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 50 00 00 	lea    0x50a4(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d 39 77 01 00 	cmp    0x17739(%rip),%rdi        # 1a700 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 ff 76 01 00 	mov    0x176ff(%rip),%rax        # 1a6e0 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d dd 76 01 00 	mov    %rdi,0x176dd(%rip)        # 1a6e0 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d b9 76 01 00 	mov    %rdi,0x176b9(%rip)        # 1a6e8 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 50 00 00 	lea    0x5051(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 4f 00 00 	lea    0x4f97(%rip),%rsi        # 801c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d b6 6f 00 00 	mov    0x6fb6(%rip),%rdi        # a080 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 4f 00 00 	lea    0x4f4f(%rip),%rdx        # 8020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 4e 00 00 	lea    0x4ed0(%rip),%rdi        # 802f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 50 00 00 	lea    0x5030(%rip),%rdi        # 81a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 4e 00 00 	lea    0x4eb8(%rip),%r8        # 804b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 4d 00 00 	lea    0x4d0d(%rip),%r8        # 805a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 4b 00 00 	lea    0x4b9a(%rip),%r8        # 8050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 49 00 00 	lea    0x4972(%rip),%rdi        # 805f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 49 00 00 	lea    0x49fc(%rip),%rsi        # 810a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 65 83 01 00 	mov    0x18365(%rip),%r9        # 1bae8 <fwp_heap+0x13c8>
    3783:	4c 8b 05 be 83 01 00 	mov    0x183be(%rip),%r8        # 1bb48 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 4a 00 00 	lea    0x4a3f(%rip),%rdx        # 81d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d a6 83 01 00 	mov    0x183a6(%rip),%rcx        # 1bb40 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d b4 83 01 	movsd  0x183b4(%rip),%xmm1        # 1bb60 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 a4 83 01 	movsd  0x183a4(%rip),%xmm0        # 1bb58 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d c5 68 00 00 	mov    0x68c5(%rip),%rdi        # a080 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 4c 00 	movdqa 0x4c68(%rip),%xmm0        # 8460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 5f 7e 01 00 	lea    0x17e5f(%rip),%rax        # 1b660 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 4c 00 	movdqa 0x4c91(%rip),%xmm2        # 84a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 05 7e 01 00 	movaps %xmm0,0x17e05(%rip)        # 1b620 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 4c 00 	movdqa 0x4c4d(%rip),%xmm0        # 8470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 93 82 01 00 01 	movl   $0x1,0x18293(%rip)        # 1bac4 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 f3 7d 01 00 	movaps %xmm0,0x17df3(%rip)        # 1b630 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 4c 00 	movdqa 0x4c3b(%rip),%xmm0        # 8480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 f4 7d 01 00 	movaps %xmm0,0x17df4(%rip)        # 1b640 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 4c 00 	movdqa 0x4c3c(%rip),%xmm0        # 8490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 f5 7d 01 00 	movaps %xmm0,0x17df5(%rip)        # 1b650 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 75 6e 01 00 	lea    0x16e75(%rip),%r8        # 1a720 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 90 81 01 00 	mov    %rax,0x18190(%rip)        # 1bad8 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 6e 81 01 00 	mov    %r12,0x1816e(%rip)        # 1bae0 <fwp_heap+0x13c0>
    3972:	48 89 05 57 81 01 00 	mov    %rax,0x18157(%rip)        # 1bad0 <fwp_heap+0x13b0>
    3979:	48 89 1d 70 81 01 00 	mov    %rbx,0x18170(%rip)        # 1baf0 <fwp_heap+0x13d0>
    3980:	48 89 35 99 81 01 00 	mov    %rsi,0x18199(%rip)        # 1bb20 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 46 00 00 	lea    0x46fc(%rip),%rdi        # 8095 <_IO_stdin_used+0x95>
    3999:	48 89 05 78 81 01 00 	mov    %rax,0x18178(%rip)        # 1bb18 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 fc 80 01 00    	mov    %eax,0x180fc(%rip)        # 1bac8 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 ec 6c 01 00 	mov    0x16cec(%rip),%r8        # 1a6e0 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d 1c 6c 01 00 	mov    %rbx,0x16c1c(%rip)        # 1a6e8 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 08 6c 01 00 	mov    %r8,0x16c08(%rip)        # 1a6e0 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d c7 6b 01 00 	mov    0x16bc7(%rip),%rbx        # 1a6d8 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 6a 64 00 00 	mov    0x646a(%rip),%rcx        # a080 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 46 00 00 	lea    0x463b(%rip),%rdi        # 8258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 8d 6a 01 00 	mov    0x16a8d(%rip),%rax        # 1a6e0 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 67 6a 01 00 	mov    %rdx,0x16a67(%rip)        # 1a6e0 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d b4 69 01 00 	mov    0x169b4(%rip),%rbx        # 1a6d8 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 71 69 01 00 	mov    %rbx,0x16971(%rip)        # 1a6d8 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 71 69 01 00 	mov    %rdx,0x16971(%rip)        # 1a6e8 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 5e 69 01 00 	lea    0x1695e(%rip),%rcx        # 1a720 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 5f 85 01 00 	subq   $0x1,0x1855f(%rip)        # 1c368 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 44 00 00 	lea    0x4473(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 40 85 01 00 	cmpq   $0x0,0x18540(%rip)        # 1c368 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 95 84 01 00 	sub    %rax,0x18495(%rip)        # 1c370 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 73 84 01 00 	add    %r12,0x18473(%rip)        # 1c370 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 cf 7b 01 00 	mov    0x17bcf(%rip),%rax        # 1bb18 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 cc 67 01 00 	lea    0x167cc(%rip),%rax        # 1a720 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 23 7b 01 00 	add    0x17b23(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 f0 7a 01 00 	mov    0x17af0(%rip),%rsi        # 1bad0 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 11 7b 01 00 	mov    0x17b11(%rip),%rax        # 1baf8 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 05 7b 01 00 	add    0x17b05(%rip),%r8        # 1bb18 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 cd 7a 01 	addsd  0x17acd(%rip),%xmm0        # 1bb60 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 82 66 01 00 	lea    0x16682(%rip),%rax        # 1a720 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d 8c 7a 01 00 	sub    %rdi,0x17a8c(%rip)        # 1bb40 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 a4 7a 01 	movsd  %xmm0,0x17aa4(%rip)        # 1bb60 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 5e 7a 01 00 	sub    %rdx,0x17a5e(%rip)        # 1bb40 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 64 7a 01 	addsd  0x17a64(%rip),%xmm0        # 1bb60 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 58 7a 01 	movsd  %xmm0,0x17a58(%rip)        # 1bb60 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 ef 79 01 00 	mov    0x179ef(%rip),%rdx        # 1bb18 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d e9 79 01 00 	add    %rcx,0x179e9(%rip)        # 1bb50 <fwp_heap+0x1430>
    4167:	4c 3b 0d a2 79 01 00 	cmp    0x179a2(%rip),%r9        # 1bb10 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d 99 79 01 00 	mov    %r9,0x17999(%rip)        # 1bb10 <fwp_heap+0x13f0>
    4177:	4c 3b 0d 8a 79 01 00 	cmp    0x1798a(%rip),%r9        # 1bb08 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 7d 79 01 00 	mov    %r9,0x1797d(%rip)        # 1bb08 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d 93 78 01 00 	add    0x17893(%rip),%rdi        # 1bb18 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 70 64 01 00 	lea    0x16470(%rip),%r15        # 1a720 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 e0 77 01 00 	add    0x177e0(%rip),%r12        # 1bad0 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 39 78 01 00 	add    0x17839(%rip),%rax        # 1bb40 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 38 78 01 00 	cmp    %rax,0x17838(%rip)        # 1bb48 <fwp_heap+0x1428>
    4310:	48 89 05 29 78 01 00 	mov    %rax,0x17829(%rip)        # 1bb40 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 28 78 01 00 	mov    %rax,0x17828(%rip)        # 1bb48 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 24 78 01 	addsd  0x17824(%rip),%xmm0        # 1bb58 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 1c 78 01 	movsd  %xmm0,0x1781c(%rip)        # 1bb58 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 63 77 01 00    	mov    0x17763(%rip),%eax        # 1bac4 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d 9f 63 01 00 	lea    0x1639f(%rip),%rdi        # 1a720 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 58 77 01 00 	add    0x17758(%rip),%rax        # 1bb40 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 53 77 01 00 	cmp    %rax,0x17753(%rip)        # 1bb48 <fwp_heap+0x1428>
    43f5:	48 89 05 44 77 01 00 	mov    %rax,0x17744(%rip)        # 1bb40 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 43 77 01 00 	mov    %rax,0x17743(%rip)        # 1bb48 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 3f 77 01 	addsd  0x1773f(%rip),%xmm0        # 1bb58 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 37 77 01 	movsd  %xmm0,0x17737(%rip)        # 1bb58 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_free_arr>:
    44d0:	48 8b 15 21 76 01 00 	mov    0x17621(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 2b 05 ef 75 01 00 	sub    0x175ef(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    44e1:	48 c1 e2 10          	shl    $0x10,%rdx
    44e5:	48 39 d0             	cmp    %rdx,%rax
    44e8:	73 5b                	jae    4545 <fwp_rc_free_arr+0x75>
    44ea:	48 89 c2             	mov    %rax,%rdx
    44ed:	48 c1 ea 10          	shr    $0x10,%rdx
    44f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f5:	48 8b 15 1c 76 01 00 	mov    0x1761c(%rip),%rdx        # 1bb18 <fwp_heap+0x13f8>
    44fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4500:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4504:	48 85 c9             	test   %rcx,%rcx
    4507:	74 3c                	je     4545 <fwp_rc_free_arr+0x75>
    4509:	0f b6 32             	movzbl (%rdx),%esi
    450c:	40 80 fe 02          	cmp    $0x2,%sil
    4510:	74 2e                	je     4540 <fwp_rc_free_arr+0x70>
    4512:	40 80 fe 01          	cmp    $0x1,%sil
    4516:	75 2d                	jne    4545 <fwp_rc_free_arr+0x75>
    4518:	8b 72 18             	mov    0x18(%rdx),%esi
    451b:	0f b7 c0             	movzwl %ax,%eax
    451e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4521:	48 0f af c6          	imul   %rsi,%rax
    4525:	48 c1 e8 20          	shr    $0x20,%rax
    4529:	48 39 d0             	cmp    %rdx,%rax
    452c:	73 17                	jae    4545 <fwp_rc_free_arr+0x75>
    452e:	48 01 c1             	add    %rax,%rcx
    4531:	80 39 01             	cmpb   $0x1,(%rcx)
    4534:	75 0f                	jne    4545 <fwp_rc_free_arr+0x75>
    4536:	e9 95 fa ff ff       	jmp    3fd0 <fwp_mem_free>
    453b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ec                	je     4531 <fwp_rc_free_arr+0x61>
    4545:	c3                   	ret
    4546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    454d:	00 00 00 

0000000000004550 <fwp_heap_alloc>:
    4550:	8b 05 6e 75 01 00    	mov    0x1756e(%rip),%eax        # 1bac4 <fwp_heap+0x13a4>
    4556:	48 89 fa             	mov    %rdi,%rdx
    4559:	89 f7                	mov    %esi,%edi
    455b:	85 c0                	test   %eax,%eax
    455d:	0f 84 f5 00 00 00    	je     4658 <fwp_heap_alloc+0x108>
    4563:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    456a:	0f 87 e8 00 00 00    	ja     4658 <fwp_heap_alloc+0x108>
    4570:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4574:	48 8d 05 a5 61 01 00 	lea    0x161a5(%rip),%rax        # 1a720 <fwp_heap>
    457b:	48 83 ec 18          	sub    $0x18,%rsp
    457f:	41 89 f0             	mov    %esi,%r8d
    4582:	48 c1 e9 04          	shr    $0x4,%rcx
    4586:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    458d:	00 
    458e:	48 63 cf             	movslq %edi,%rcx
    4591:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4598:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    459f:	00 
    45a0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    45a4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    45a8:	48 01 c8             	add    %rcx,%rax
    45ab:	48 8b 08             	mov    (%rax),%rcx
    45ae:	48 85 c9             	test   %rcx,%rcx
    45b1:	74 6d                	je     4620 <fwp_heap_alloc+0xd0>
    45b3:	48 8b 31             	mov    (%rcx),%rsi
    45b6:	48 f7 d6             	not    %rsi
    45b9:	48 89 30             	mov    %rsi,(%rax)
    45bc:	41 83 f8 01          	cmp    $0x1,%r8d
    45c0:	48 89 cf             	mov    %rcx,%rdi
    45c3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45c8:	49 0f 45 d1          	cmovne %r9,%rdx
    45cc:	31 f6                	xor    %esi,%esi
    45ce:	e8 cd de ff ff       	call   24a0 <memset@plt>
    45d3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    45d8:	48 89 c1             	mov    %rax,%rcx
    45db:	4c 89 c8             	mov    %r9,%rax
    45de:	48 03 05 5b 75 01 00 	add    0x1755b(%rip),%rax        # 1bb40 <fwp_heap+0x1420>
    45e5:	72 7b                	jb     4662 <fwp_heap_alloc+0x112>
    45e7:	48 39 05 5a 75 01 00 	cmp    %rax,0x1755a(%rip)        # 1bb48 <fwp_heap+0x1428>
    45ee:	48 89 05 4b 75 01 00 	mov    %rax,0x1754b(%rip)        # 1bb40 <fwp_heap+0x1420>
    45f5:	73 07                	jae    45fe <fwp_heap_alloc+0xae>
    45f7:	48 89 05 4a 75 01 00 	mov    %rax,0x1754a(%rip)        # 1bb48 <fwp_heap+0x1428>
    45fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4602:	48 89 c8             	mov    %rcx,%rax
    4605:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    460a:	f2 0f 58 05 46 75 01 	addsd  0x17546(%rip),%xmm0        # 1bb58 <fwp_heap+0x1438>
    4611:	00 
    4612:	f2 0f 11 05 3e 75 01 	movsd  %xmm0,0x1753e(%rip)        # 1bb58 <fwp_heap+0x1438>
    4619:	00 
    461a:	48 83 c4 18          	add    $0x18,%rsp
    461e:	c3                   	ret
    461f:	90                   	nop
    4620:	48 8b 48 08          	mov    0x8(%rax),%rcx
    4624:	48 85 c9             	test   %rcx,%rcx
    4627:	74 0c                	je     4635 <fwp_heap_alloc+0xe5>
    4629:	48 8b 70 10          	mov    0x10(%rax),%rsi
    462d:	48 29 ce             	sub    %rcx,%rsi
    4630:	4c 39 ce             	cmp    %r9,%rsi
    4633:	73 13                	jae    4648 <fwp_heap_alloc+0xf8>
    4635:	89 fe                	mov    %edi,%esi
    4637:	48 83 c4 18          	add    $0x18,%rsp
    463b:	48 89 d7             	mov    %rdx,%rdi
    463e:	e9 0d fd ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4643:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4648:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    464c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4650:	e9 67 ff ff ff       	jmp    45bc <fwp_heap_alloc+0x6c>
    4655:	0f 1f 00             	nopl   (%rax)
    4658:	89 fe                	mov    %edi,%esi
    465a:	48 89 d7             	mov    %rdx,%rdi
    465d:	e9 ee fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4662:	e8 99 e5 ff ff       	call   2c00 <fwp_heap_oom>
    4667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    466e:	00 00 

0000000000004670 <fwp_data.part.0.constprop.0>:
    4670:	8b 05 4e 74 01 00    	mov    0x1744e(%rip),%eax        # 1bac4 <fwp_heap+0x13a4>
    4676:	41 54                	push   %r12
    4678:	49 89 fc             	mov    %rdi,%r12
    467b:	55                   	push   %rbp
    467c:	53                   	push   %rbx
    467d:	85 c0                	test   %eax,%eax
    467f:	0f 84 e3 00 00 00    	je     4768 <fwp_data.part.0.constprop.0+0xf8>
    4685:	0f b6 05 36 70 01 00 	movzbl 0x17036(%rip),%eax        # 1b6c2 <fwp_heap+0xfa2>
    468c:	48 8d 15 8d 60 01 00 	lea    0x1608d(%rip),%rdx        # 1a720 <fwp_heap>
    4693:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    469a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    469e:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    46a2:	48 8b 18             	mov    (%rax),%rbx
    46a5:	48 85 db             	test   %rbx,%rbx
    46a8:	0f 84 92 00 00 00    	je     4740 <fwp_data.part.0.constprop.0+0xd0>
    46ae:	48 8b 13             	mov    (%rbx),%rdx
    46b1:	48 f7 d2             	not    %rdx
    46b4:	48 89 10             	mov    %rdx,(%rax)
    46b7:	48 83 fd 18          	cmp    $0x18,%rbp
    46bb:	76 1b                	jbe    46d8 <fwp_data.part.0.constprop.0+0x68>
    46bd:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    46c1:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    46c5:	31 f6                	xor    %esi,%esi
    46c7:	48 c1 e8 03          	shr    $0x3,%rax
    46cb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    46d2:	00 
    46d3:	e8 c8 dd ff ff       	call   24a0 <memset@plt>
    46d8:	48 89 e8             	mov    %rbp,%rax
    46db:	48 03 05 5e 74 01 00 	add    0x1745e(%rip),%rax        # 1bb40 <fwp_heap+0x1420>
    46e2:	0f 82 91 00 00 00    	jb     4779 <fwp_data.part.0.constprop.0+0x109>
    46e8:	48 39 05 59 74 01 00 	cmp    %rax,0x17459(%rip)        # 1bb48 <fwp_heap+0x1428>
    46ef:	48 89 05 4a 74 01 00 	mov    %rax,0x1744a(%rip)        # 1bb40 <fwp_heap+0x1420>
    46f6:	73 07                	jae    46ff <fwp_data.part.0.constprop.0+0x8f>
    46f8:	48 89 05 49 74 01 00 	mov    %rax,0x17449(%rip)        # 1bb48 <fwp_heap+0x1428>
    46ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4703:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    4708:	f2 0f 58 05 48 74 01 	addsd  0x17448(%rip),%xmm0        # 1bb58 <fwp_heap+0x1438>
    470f:	00 
    4710:	f2 0f 11 05 40 74 01 	movsd  %xmm0,0x17440(%rip)        # 1bb58 <fwp_heap+0x1438>
    4717:	00 
    4718:	48 8b 05 81 3d 00 00 	mov    0x3d81(%rip),%rax        # 84a0 <msg.3+0x60>
    471f:	48 89 03             	mov    %rax,(%rbx)
    4722:	49 8b 04 24          	mov    (%r12),%rax
    4726:	48 89 43 08          	mov    %rax,0x8(%rbx)
    472a:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    472f:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4733:	48 89 d8             	mov    %rbx,%rax
    4736:	5b                   	pop    %rbx
    4737:	5d                   	pop    %rbp
    4738:	41 5c                	pop    %r12
    473a:	c3                   	ret
    473b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4740:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4744:	48 85 db             	test   %rbx,%rbx
    4747:	74 1f                	je     4768 <fwp_data.part.0.constprop.0+0xf8>
    4749:	48 8b 50 10          	mov    0x10(%rax),%rdx
    474d:	48 29 da             	sub    %rbx,%rdx
    4750:	48 39 ea             	cmp    %rbp,%rdx
    4753:	72 13                	jb     4768 <fwp_data.part.0.constprop.0+0xf8>
    4755:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4759:	48 89 50 08          	mov    %rdx,0x8(%rax)
    475d:	e9 55 ff ff ff       	jmp    46b7 <fwp_data.part.0.constprop.0+0x47>
    4762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4768:	31 f6                	xor    %esi,%esi
    476a:	bf 18 00 00 00       	mov    $0x18,%edi
    476f:	e8 dc fd ff ff       	call   4550 <fwp_heap_alloc>
    4774:	48 89 c3             	mov    %rax,%rbx
    4777:	eb 9f                	jmp    4718 <fwp_data.part.0.constprop.0+0xa8>
    4779:	e8 82 e4 ff ff       	call   2c00 <fwp_heap_oom>
    477e:	66 90                	xchg   %ax,%ax

0000000000004780 <fwp_array_new_packed.constprop.0>:
    4780:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4787:	ff ff 1f 
    478a:	53                   	push   %rbx
    478b:	48 39 f8             	cmp    %rdi,%rax
    478e:	72 1a                	jb     47aa <fwp_array_new_packed.constprop.0+0x2a>
    4790:	48 89 fb             	mov    %rdi,%rbx
    4793:	be 01 00 00 00       	mov    $0x1,%esi
    4798:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    479f:	00 
    47a0:	e8 ab fd ff ff       	call   4550 <fwp_heap_alloc>
    47a5:	48 89 18             	mov    %rbx,(%rax)
    47a8:	5b                   	pop    %rbx
    47a9:	c3                   	ret
    47aa:	48 8d 3d f4 38 00 00 	lea    0x38f4(%rip),%rdi        # 80a5 <_IO_stdin_used+0xa5>
    47b1:	e8 fa e8 ff ff       	call   30b0 <fwp_trap>
    47b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    47bd:	00 00 00 

00000000000047c0 <fwp_task_dispose>:
    47c0:	53                   	push   %rbx
    47c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    47c5:	0f 84 3b df ff ff    	je     2706 <fwp_task_dispose.cold>
    47cb:	48 89 fb             	mov    %rdi,%rbx
    47ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    47d3:	0f 85 2d df ff ff    	jne    2706 <fwp_task_dispose.cold>
    47d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    47dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    47e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    47eb:	00 
    47ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    47f0:	48 85 ff             	test   %rdi,%rdi
    47f3:	74 07                	je     47fc <fwp_task_dispose+0x3c>
    47f5:	48 85 c0             	test   %rax,%rax
    47f8:	74 02                	je     47fc <fwp_task_dispose+0x3c>
    47fa:	ff d0                	call   *%rax
    47fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4803:	e8 c8 f7 ff ff       	call   3fd0 <fwp_mem_free>
    4808:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    480f:	00 00 00 00 
    4813:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4817:	74 6f                	je     4888 <fwp_task_dispose+0xc8>
    4819:	48 8b 15 d8 72 01 00 	mov    0x172d8(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    4820:	48 89 d8             	mov    %rbx,%rax
    4823:	48 2b 05 a6 72 01 00 	sub    0x172a6(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    482a:	48 c1 e2 10          	shl    $0x10,%rdx
    482e:	48 39 d0             	cmp    %rdx,%rax
    4831:	73 4c                	jae    487f <fwp_task_dispose+0xbf>
    4833:	48 89 c2             	mov    %rax,%rdx
    4836:	48 c1 ea 10          	shr    $0x10,%rdx
    483a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    483e:	48 8b 15 d3 72 01 00 	mov    0x172d3(%rip),%rdx        # 1bb18 <fwp_heap+0x13f8>
    4845:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4849:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    484d:	48 85 c9             	test   %rcx,%rcx
    4850:	74 2d                	je     487f <fwp_task_dispose+0xbf>
    4852:	0f b6 32             	movzbl (%rdx),%esi
    4855:	40 80 fe 02          	cmp    $0x2,%sil
    4859:	74 3d                	je     4898 <fwp_task_dispose+0xd8>
    485b:	40 80 fe 01          	cmp    $0x1,%sil
    485f:	75 1e                	jne    487f <fwp_task_dispose+0xbf>
    4861:	8b 72 18             	mov    0x18(%rdx),%esi
    4864:	0f b7 c0             	movzwl %ax,%eax
    4867:	8b 52 1c             	mov    0x1c(%rdx),%edx
    486a:	48 0f af c6          	imul   %rsi,%rax
    486e:	48 c1 e8 20          	shr    $0x20,%rax
    4872:	48 39 d0             	cmp    %rdx,%rax
    4875:	73 08                	jae    487f <fwp_task_dispose+0xbf>
    4877:	48 01 c1             	add    %rax,%rcx
    487a:	80 39 01             	cmpb   $0x1,(%rcx)
    487d:	74 09                	je     4888 <fwp_task_dispose+0xc8>
    487f:	5b                   	pop    %rbx
    4880:	c3                   	ret
    4881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4888:	48 89 df             	mov    %rbx,%rdi
    488b:	5b                   	pop    %rbx
    488c:	e9 3f f7 ff ff       	jmp    3fd0 <fwp_mem_free>
    4891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4898:	66 85 c0             	test   %ax,%ax
    489b:	74 dd                	je     487a <fwp_task_dispose+0xba>
    489d:	5b                   	pop    %rbx
    489e:	c3                   	ret
    489f:	90                   	nop

00000000000048a0 <fwp_free_zombie>:
    48a0:	48 8b 15 49 5e 01 00 	mov    0x15e49(%rip),%rdx        # 1a6f0 <fwp_zombie>
    48a7:	48 85 d2             	test   %rdx,%rdx
    48aa:	0f 84 98 00 00 00    	je     4948 <fwp_free_zombie+0xa8>
    48b0:	48 3b 15 49 5e 01 00 	cmp    0x15e49(%rip),%rdx        # 1a700 <fwp_cur>
    48b7:	0f 84 8b 00 00 00    	je     4948 <fwp_free_zombie+0xa8>
    48bd:	48 83 ec 18          	sub    $0x18,%rsp
    48c1:	48 63 05 14 58 01 00 	movslq 0x15814(%rip),%rax        # 1a0dc <fwp_stack_pool_n>
    48c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    48cc:	83 f8 3f             	cmp    $0x3f,%eax
    48cf:	7f 7f                	jg     4950 <fwp_free_zombie+0xb0>
    48d1:	8d 48 01             	lea    0x1(%rax),%ecx
    48d4:	89 0d 02 58 01 00    	mov    %ecx,0x15802(%rip)        # 1a0dc <fwp_stack_pool_n>
    48da:	48 8d 0d ff 57 01 00 	lea    0x157ff(%rip),%rcx        # 1a0e0 <fwp_stack_pool>
    48e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    48e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    48ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    48f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    48f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    48fb:	48 85 c9             	test   %rcx,%rcx
    48fe:	0f 84 fc 00 00 00    	je     4a00 <fwp_free_zombie+0x160>
    4904:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    490b:	48 85 c0             	test   %rax,%rax
    490e:	74 07                	je     4917 <fwp_free_zombie+0x77>
    4910:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4917:	8b 42 5c             	mov    0x5c(%rdx),%eax
    491a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    491e:	48 c7 05 c7 5d 01 00 	movq   $0x0,0x15dc7(%rip)        # 1a6f0 <fwp_zombie>
    4925:	00 00 00 00 
    4929:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4930:	85 c0                	test   %eax,%eax
    4932:	74 34                	je     4968 <fwp_free_zombie+0xc8>
    4934:	83 f8 01             	cmp    $0x1,%eax
    4937:	0f 84 b3 00 00 00    	je     49f0 <fwp_free_zombie+0x150>
    493d:	48 83 c4 18          	add    $0x18,%rsp
    4941:	c3                   	ret
    4942:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4948:	c3                   	ret
    4949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4950:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4954:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4959:	e8 52 dc ff ff       	call   25b0 <munmap@plt>
    495e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4963:	eb 80                	jmp    48e5 <fwp_free_zombie+0x45>
    4965:	0f 1f 00             	nopl   (%rax)
    4968:	48 8b 0d 89 71 01 00 	mov    0x17189(%rip),%rcx        # 1baf8 <fwp_heap+0x13d8>
    496f:	48 89 d0             	mov    %rdx,%rax
    4972:	48 2b 05 57 71 01 00 	sub    0x17157(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    4979:	48 c1 e1 10          	shl    $0x10,%rcx
    497d:	48 39 c8             	cmp    %rcx,%rax
    4980:	73 bb                	jae    493d <fwp_free_zombie+0x9d>
    4982:	48 89 c1             	mov    %rax,%rcx
    4985:	48 c1 e9 10          	shr    $0x10,%rcx
    4989:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    498d:	48 8b 0d 84 71 01 00 	mov    0x17184(%rip),%rcx        # 1bb18 <fwp_heap+0x13f8>
    4994:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4998:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    499c:	48 85 c9             	test   %rcx,%rcx
    499f:	74 9c                	je     493d <fwp_free_zombie+0x9d>
    49a1:	0f b6 3e             	movzbl (%rsi),%edi
    49a4:	40 80 ff 02          	cmp    $0x2,%dil
    49a8:	74 66                	je     4a10 <fwp_free_zombie+0x170>
    49aa:	40 80 ff 01          	cmp    $0x1,%dil
    49ae:	75 8d                	jne    493d <fwp_free_zombie+0x9d>
    49b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    49b3:	0f b7 c0             	movzwl %ax,%eax
    49b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    49b9:	48 0f af c7          	imul   %rdi,%rax
    49bd:	48 c1 e8 20          	shr    $0x20,%rax
    49c1:	48 39 f0             	cmp    %rsi,%rax
    49c4:	0f 83 73 ff ff ff    	jae    493d <fwp_free_zombie+0x9d>
    49ca:	48 01 c1             	add    %rax,%rcx
    49cd:	0f b6 01             	movzbl (%rcx),%eax
    49d0:	84 c0                	test   %al,%al
    49d2:	0f 84 65 ff ff ff    	je     493d <fwp_free_zombie+0x9d>
    49d8:	3c 01                	cmp    $0x1,%al
    49da:	74 14                	je     49f0 <fwp_free_zombie+0x150>
    49dc:	3c ff                	cmp    $0xff,%al
    49de:	74 3b                	je     4a1b <fwp_free_zombie+0x17b>
    49e0:	83 e8 01             	sub    $0x1,%eax
    49e3:	88 01                	mov    %al,(%rcx)
    49e5:	e9 53 ff ff ff       	jmp    493d <fwp_free_zombie+0x9d>
    49ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    49f0:	48 89 d7             	mov    %rdx,%rdi
    49f3:	48 83 c4 18          	add    $0x18,%rsp
    49f7:	e9 c4 fd ff ff       	jmp    47c0 <fwp_task_dispose>
    49fc:	0f 1f 40 00          	nopl   0x0(%rax)
    4a00:	48 89 05 c1 5c 01 00 	mov    %rax,0x15cc1(%rip)        # 1a6c8 <fwp_tasks_active>
    4a07:	e9 ff fe ff ff       	jmp    490b <fwp_free_zombie+0x6b>
    4a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a10:	66 85 c0             	test   %ax,%ax
    4a13:	0f 85 24 ff ff ff    	jne    493d <fwp_free_zombie+0x9d>
    4a19:	eb b2                	jmp    49cd <fwp_free_zombie+0x12d>
    4a1b:	48 89 ca             	mov    %rcx,%rdx
    4a1e:	48 8d 35 fb 5c 01 00 	lea    0x15cfb(%rip),%rsi        # 1a720 <fwp_heap>
    4a25:	48 c1 ea 11          	shr    $0x11,%rdx
    4a29:	48 31 ca             	xor    %rcx,%rdx
    4a2c:	48 89 d0             	mov    %rdx,%rax
    4a2f:	48 c1 e8 09          	shr    $0x9,%rax
    4a33:	48 31 c2             	xor    %rax,%rdx
    4a36:	0f b6 d2             	movzbl %dl,%edx
    4a39:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4a40:	00 
    4a41:	48 85 c0             	test   %rax,%rax
    4a44:	75 23                	jne    4a69 <fwp_free_zombie+0x1c9>
    4a46:	eb 5c                	jmp    4aa4 <fwp_free_zombie+0x204>
    4a48:	66 90                	xchg   %ax,%ax
    4a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a51:	00 00 00 00 
    4a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a5c:	00 00 00 00 
    4a60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4a64:	48 85 c0             	test   %rax,%rax
    4a67:	74 3b                	je     4aa4 <fwp_free_zombie+0x204>
    4a69:	48 89 c2             	mov    %rax,%rdx
    4a6c:	48 39 08             	cmp    %rcx,(%rax)
    4a6f:	75 ef                	jne    4a60 <fwp_free_zombie+0x1c0>
    4a71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4a75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4a79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4a7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4a84:	0f 85 b3 fe ff ff    	jne    493d <fwp_free_zombie+0x9d>
    4a8a:	48 89 cf             	mov    %rcx,%rdi
    4a8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4a92:	e8 f9 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4a97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4a9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4a9f:	e9 99 fe ff ff       	jmp    493d <fwp_free_zombie+0x9d>
    4aa4:	48 8d 3d dd 37 00 00 	lea    0x37dd(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4aab:	e8 00 e6 ff ff       	call   30b0 <fwp_trap>

0000000000004ab0 <fwp_block>:
    4ab0:	48 83 ec 08          	sub    $0x8,%rsp
    4ab4:	48 8b 05 2d 5c 01 00 	mov    0x15c2d(%rip),%rax        # 1a6e8 <fwp_ready_head>
    4abb:	48 85 c0             	test   %rax,%rax
    4abe:	0f 84 1c 01 00 00    	je     4be0 <fwp_block+0x130>
    4ac4:	90                   	nop
    4ac5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4acc:	00 00 00 00 
    4ad0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4ad7:	48 89 15 0a 5c 01 00 	mov    %rdx,0x15c0a(%rip)        # 1a6e8 <fwp_ready_head>
    4ade:	48 85 d2             	test   %rdx,%rdx
    4ae1:	0f 84 19 01 00 00    	je     4c00 <fwp_block+0x150>
    4ae7:	48 8b 15 12 5c 01 00 	mov    0x15c12(%rip),%rdx        # 1a700 <fwp_cur>
    4aee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4af2:	48 39 c2             	cmp    %rax,%rdx
    4af5:	0f 84 d5 00 00 00    	je     4bd0 <fwp_block+0x120>
    4afb:	48 8b 0d 7e 78 01 00 	mov    0x1787e(%rip),%rcx        # 1c380 <fwp_state_owners>
    4b02:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4b06:	48 89 05 f3 5b 01 00 	mov    %rax,0x15bf3(%rip)        # 1a700 <fwp_cur>
    4b0d:	f3 0f 7e 05 93 78 01 	movq   0x17893(%rip),%xmm0        # 1c3a8 <fwp_foreign_callbacks>
    4b14:	00 
    4b15:	0f 16 05 7c 78 01 00 	movhps 0x1787c(%rip),%xmm0        # 1c398 <fwp_state>
    4b1c:	f3 0f 7e 0d 7c 78 01 	movq   0x1787c(%rip),%xmm1        # 1c3a0 <fwp_handlers>
    4b23:	00 
    4b24:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4b2b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4b32:	0f 16 0d 77 78 01 00 	movhps 0x17877(%rip),%xmm1        # 1c3b0 <fwp_cleanups>
    4b39:	f3 0f 7e 05 4f 78 01 	movq   0x1784f(%rip),%xmm0        # 1c390 <fwp_state_len>
    4b40:	00 
    4b41:	0f 16 05 40 78 01 00 	movhps 0x17840(%rip),%xmm0        # 1c388 <fwp_state_cap>
    4b48:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4b4f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4b56:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b5a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4b61:	48 89 0d 38 78 01 00 	mov    %rcx,0x17838(%rip)        # 1c3a0 <fwp_handlers>
    4b68:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4b6f:	48 89 0d 3a 78 01 00 	mov    %rcx,0x1783a(%rip)        # 1c3b0 <fwp_cleanups>
    4b76:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4b7d:	48 89 0d 24 78 01 00 	mov    %rcx,0x17824(%rip)        # 1c3a8 <fwp_foreign_callbacks>
    4b84:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4b8b:	48 89 0d 06 78 01 00 	mov    %rcx,0x17806(%rip)        # 1c398 <fwp_state>
    4b92:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4b99:	48 89 0d f0 77 01 00 	mov    %rcx,0x177f0(%rip)        # 1c390 <fwp_state_len>
    4ba0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4ba7:	48 89 0d da 77 01 00 	mov    %rcx,0x177da(%rip)        # 1c388 <fwp_state_cap>
    4bae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4bb5:	48 89 0d c4 77 01 00 	mov    %rcx,0x177c4(%rip)        # 1c380 <fwp_state_owners>
    4bbc:	e8 af d8 ff ff       	call   2470 <swapcontext@plt>
    4bc1:	f3 0f 1e fa          	endbr64
    4bc5:	e8 d6 fc ff ff       	call   48a0 <fwp_free_zombie>
    4bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4bd0:	8b 05 02 55 01 00    	mov    0x15502(%rip),%eax        # 1a0d8 <fwp_slice>
    4bd6:	85 c0                	test   %eax,%eax
    4bd8:	74 36                	je     4c10 <fwp_block+0x160>
    4bda:	48 83 c4 08          	add    $0x8,%rsp
    4bde:	c3                   	ret
    4bdf:	90                   	nop
    4be0:	e8 0b ef ff ff       	call   3af0 <fwp_poll_events>
    4be5:	48 8b 05 fc 5a 01 00 	mov    0x15afc(%rip),%rax        # 1a6e8 <fwp_ready_head>
    4bec:	48 85 c0             	test   %rax,%rax
    4bef:	0f 85 db fe ff ff    	jne    4ad0 <fwp_block+0x20>
    4bf5:	eb e9                	jmp    4be0 <fwp_block+0x130>
    4bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4bfe:	00 00 
    4c00:	48 c7 05 d5 5a 01 00 	movq   $0x0,0x15ad5(%rip)        # 1a6e0 <fwp_ready_tail>
    4c07:	00 00 00 00 
    4c0b:	e9 d7 fe ff ff       	jmp    4ae7 <fwp_block+0x37>
    4c10:	48 8d 3d 9e 34 00 00 	lea    0x349e(%rip),%rdi        # 80b5 <_IO_stdin_used+0xb5>
    4c17:	e8 64 d7 ff ff       	call   2380 <getenv@plt>
    4c1c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4c21:	48 85 c0             	test   %rax,%rax
    4c24:	74 05                	je     4c2b <fwp_block+0x17b>
    4c26:	80 38 00             	cmpb   $0x0,(%rax)
    4c29:	75 0b                	jne    4c36 <fwp_block+0x186>
    4c2b:	89 15 a7 54 01 00    	mov    %edx,0x154a7(%rip)        # 1a0d8 <fwp_slice>
    4c31:	48 83 c4 08          	add    $0x8,%rsp
    4c35:	c3                   	ret
    4c36:	ba 0a 00 00 00       	mov    $0xa,%edx
    4c3b:	31 f6                	xor    %esi,%esi
    4c3d:	48 89 c7             	mov    %rax,%rdi
    4c40:	e8 eb d8 ff ff       	call   2530 <strtoll@plt>
    4c45:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4c49:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4c50:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4c55:	0f 46 d0             	cmovbe %eax,%edx
    4c58:	eb d1                	jmp    4c2b <fwp_block+0x17b>
    4c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004c60 <fwp_drop0>:
    4c60:	48 8b 15 91 6e 01 00 	mov    0x16e91(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    4c67:	48 89 f8             	mov    %rdi,%rax
    4c6a:	48 2b 05 5f 6e 01 00 	sub    0x16e5f(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    4c71:	48 c1 e2 10          	shl    $0x10,%rdx
    4c75:	48 39 d0             	cmp    %rdx,%rax
    4c78:	0f 83 c2 00 00 00    	jae    4d40 <fwp_drop0+0xe0>
    4c7e:	48 83 ec 18          	sub    $0x18,%rsp
    4c82:	4c 8d 05 97 5a 01 00 	lea    0x15a97(%rip),%r8        # 1a720 <fwp_heap>
    4c89:	48 89 c2             	mov    %rax,%rdx
    4c8c:	48 c1 ea 10          	shr    $0x10,%rdx
    4c90:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4c94:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4c9b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4c9f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4ca3:	48 85 d2             	test   %rdx,%rdx
    4ca6:	74 3c                	je     4ce4 <fwp_drop0+0x84>
    4ca8:	0f b6 31             	movzbl (%rcx),%esi
    4cab:	40 80 fe 02          	cmp    $0x2,%sil
    4caf:	74 3f                	je     4cf0 <fwp_drop0+0x90>
    4cb1:	40 80 fe 01          	cmp    $0x1,%sil
    4cb5:	75 2d                	jne    4ce4 <fwp_drop0+0x84>
    4cb7:	8b 71 18             	mov    0x18(%rcx),%esi
    4cba:	0f b7 c0             	movzwl %ax,%eax
    4cbd:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4cc0:	48 0f af c6          	imul   %rsi,%rax
    4cc4:	48 c1 e8 20          	shr    $0x20,%rax
    4cc8:	48 39 c8             	cmp    %rcx,%rax
    4ccb:	73 17                	jae    4ce4 <fwp_drop0+0x84>
    4ccd:	48 01 c2             	add    %rax,%rdx
    4cd0:	0f b6 02             	movzbl (%rdx),%eax
    4cd3:	84 c0                	test   %al,%al
    4cd5:	74 0d                	je     4ce4 <fwp_drop0+0x84>
    4cd7:	3c 01                	cmp    $0x1,%al
    4cd9:	74 25                	je     4d00 <fwp_drop0+0xa0>
    4cdb:	3c ff                	cmp    $0xff,%al
    4cdd:	74 69                	je     4d48 <fwp_drop0+0xe8>
    4cdf:	83 e8 01             	sub    $0x1,%eax
    4ce2:	88 02                	mov    %al,(%rdx)
    4ce4:	48 83 c4 18          	add    $0x18,%rsp
    4ce8:	c3                   	ret
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	66 85 c0             	test   %ax,%ax
    4cf3:	74 db                	je     4cd0 <fwp_drop0+0x70>
    4cf5:	48 83 c4 18          	add    $0x18,%rsp
    4cf9:	c3                   	ret
    4cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d00:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4d04:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4d09:	e8 c2 f7 ff ff       	call   44d0 <fwp_rc_free_arr>
    4d0e:	4c 8d 05 0b 5a 01 00 	lea    0x15a0b(%rip),%r8        # 1a720 <fwp_heap>
    4d15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4d1a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4d21:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4d28:	48 c1 e2 10          	shl    $0x10,%rdx
    4d2c:	48 39 d0             	cmp    %rdx,%rax
    4d2f:	73 b3                	jae    4ce4 <fwp_drop0+0x84>
    4d31:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4d36:	e9 4e ff ff ff       	jmp    4c89 <fwp_drop0+0x29>
    4d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d40:	c3                   	ret
    4d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d48:	48 89 d0             	mov    %rdx,%rax
    4d4b:	48 c1 e8 11          	shr    $0x11,%rax
    4d4f:	48 31 d0             	xor    %rdx,%rax
    4d52:	48 89 c1             	mov    %rax,%rcx
    4d55:	48 c1 e9 09          	shr    $0x9,%rcx
    4d59:	48 31 c8             	xor    %rcx,%rax
    4d5c:	0f b6 c8             	movzbl %al,%ecx
    4d5f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4d66:	00 
    4d67:	48 85 c0             	test   %rax,%rax
    4d6a:	75 1d                	jne    4d89 <fwp_drop0+0x129>
    4d6c:	eb 56                	jmp    4dc4 <fwp_drop0+0x164>
    4d6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4d7c:	00 00 00 00 
    4d80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4d84:	48 85 c0             	test   %rax,%rax
    4d87:	74 3b                	je     4dc4 <fwp_drop0+0x164>
    4d89:	48 89 c1             	mov    %rax,%rcx
    4d8c:	48 39 10             	cmp    %rdx,(%rax)
    4d8f:	75 ef                	jne    4d80 <fwp_drop0+0x120>
    4d91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4d95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4d99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4d9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4da4:	0f 85 3a ff ff ff    	jne    4ce4 <fwp_drop0+0x84>
    4daa:	48 89 d7             	mov    %rdx,%rdi
    4dad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4db2:	e8 d9 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4db7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4dbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4dbf:	e9 20 ff ff ff       	jmp    4ce4 <fwp_drop0+0x84>
    4dc4:	48 8d 3d bd 34 00 00 	lea    0x34bd(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4dcb:	e8 e0 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004dd0 <fwp_drop1>:
    4dd0:	f3 0f 1e fa          	endbr64
    4dd4:	48 8b 15 1d 6d 01 00 	mov    0x16d1d(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    4ddb:	48 89 f8             	mov    %rdi,%rax
    4dde:	48 2b 05 eb 6c 01 00 	sub    0x16ceb(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    4de5:	48 c1 e2 10          	shl    $0x10,%rdx
    4de9:	48 39 d0             	cmp    %rdx,%rax
    4dec:	0f 83 be 00 00 00    	jae    4eb0 <fwp_drop1+0xe0>
    4df2:	48 83 ec 18          	sub    $0x18,%rsp
    4df6:	4c 8d 05 23 59 01 00 	lea    0x15923(%rip),%r8        # 1a720 <fwp_heap>
    4dfd:	48 89 c2             	mov    %rax,%rdx
    4e00:	48 c1 ea 10          	shr    $0x10,%rdx
    4e04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e08:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4e0f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4e13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4e17:	48 85 d2             	test   %rdx,%rdx
    4e1a:	74 3c                	je     4e58 <fwp_drop1+0x88>
    4e1c:	0f b6 31             	movzbl (%rcx),%esi
    4e1f:	40 80 fe 02          	cmp    $0x2,%sil
    4e23:	74 3b                	je     4e60 <fwp_drop1+0x90>
    4e25:	40 80 fe 01          	cmp    $0x1,%sil
    4e29:	75 2d                	jne    4e58 <fwp_drop1+0x88>
    4e2b:	8b 71 18             	mov    0x18(%rcx),%esi
    4e2e:	0f b7 c0             	movzwl %ax,%eax
    4e31:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4e34:	48 0f af c6          	imul   %rsi,%rax
    4e38:	48 c1 e8 20          	shr    $0x20,%rax
    4e3c:	48 39 c8             	cmp    %rcx,%rax
    4e3f:	73 17                	jae    4e58 <fwp_drop1+0x88>
    4e41:	48 01 c2             	add    %rax,%rdx
    4e44:	0f b6 02             	movzbl (%rdx),%eax
    4e47:	84 c0                	test   %al,%al
    4e49:	74 0d                	je     4e58 <fwp_drop1+0x88>
    4e4b:	3c 01                	cmp    $0x1,%al
    4e4d:	74 21                	je     4e70 <fwp_drop1+0xa0>
    4e4f:	3c ff                	cmp    $0xff,%al
    4e51:	74 65                	je     4eb8 <fwp_drop1+0xe8>
    4e53:	83 e8 01             	sub    $0x1,%eax
    4e56:	88 02                	mov    %al,(%rdx)
    4e58:	48 83 c4 18          	add    $0x18,%rsp
    4e5c:	c3                   	ret
    4e5d:	0f 1f 00             	nopl   (%rax)
    4e60:	66 85 c0             	test   %ax,%ax
    4e63:	74 df                	je     4e44 <fwp_drop1+0x74>
    4e65:	48 83 c4 18          	add    $0x18,%rsp
    4e69:	c3                   	ret
    4e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e70:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4e74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e79:	e8 52 f6 ff ff       	call   44d0 <fwp_rc_free_arr>
    4e7e:	4c 8d 05 9b 58 01 00 	lea    0x1589b(%rip),%r8        # 1a720 <fwp_heap>
    4e85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4e8a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4e91:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4e98:	48 c1 e2 10          	shl    $0x10,%rdx
    4e9c:	48 39 d0             	cmp    %rdx,%rax
    4e9f:	73 b7                	jae    4e58 <fwp_drop1+0x88>
    4ea1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4ea6:	e9 52 ff ff ff       	jmp    4dfd <fwp_drop1+0x2d>
    4eab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb0:	c3                   	ret
    4eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4eb8:	48 89 d0             	mov    %rdx,%rax
    4ebb:	48 c1 e8 11          	shr    $0x11,%rax
    4ebf:	48 31 d0             	xor    %rdx,%rax
    4ec2:	48 89 c1             	mov    %rax,%rcx
    4ec5:	48 c1 e9 09          	shr    $0x9,%rcx
    4ec9:	48 31 c8             	xor    %rcx,%rax
    4ecc:	0f b6 c8             	movzbl %al,%ecx
    4ecf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4ed6:	00 
    4ed7:	48 85 c0             	test   %rax,%rax
    4eda:	75 0d                	jne    4ee9 <fwp_drop1+0x119>
    4edc:	eb 46                	jmp    4f24 <fwp_drop1+0x154>
    4ede:	66 90                	xchg   %ax,%ax
    4ee0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4ee4:	48 85 c0             	test   %rax,%rax
    4ee7:	74 3b                	je     4f24 <fwp_drop1+0x154>
    4ee9:	48 89 c1             	mov    %rax,%rcx
    4eec:	48 39 10             	cmp    %rdx,(%rax)
    4eef:	75 ef                	jne    4ee0 <fwp_drop1+0x110>
    4ef1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4ef5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4ef9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4efd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4f04:	0f 85 4e ff ff ff    	jne    4e58 <fwp_drop1+0x88>
    4f0a:	48 89 d7             	mov    %rdx,%rdi
    4f0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4f12:	e8 79 ee ff ff       	call   3d90 <fwp_rc_forget_slot>
    4f17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4f1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4f1f:	e9 34 ff ff ff       	jmp    4e58 <fwp_drop1+0x88>
    4f24:	48 8d 3d 5d 33 00 00 	lea    0x335d(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    4f2b:	e8 80 e1 ff ff       	call   30b0 <fwp_trap>

0000000000004f30 <fwp_write.constprop.0>:
    4f30:	41 57                	push   %r15
    4f32:	41 56                	push   %r14
    4f34:	41 55                	push   %r13
    4f36:	41 54                	push   %r12
    4f38:	55                   	push   %rbp
    4f39:	53                   	push   %rbx
    4f3a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    4f41:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    4f48:	00 00 
    4f4a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    4f51:	00 
    4f52:	49 89 d4             	mov    %rdx,%r12
    4f55:	8b 12                	mov    (%rdx),%edx
    4f57:	83 fa 19             	cmp    $0x19,%edx
    4f5a:	77 64                	ja     4fc0 <fwp_write.constprop.0+0x90>
    4f5c:	48 8d 0d 6d 34 00 00 	lea    0x346d(%rip),%rcx        # 83d0 <_IO_stdin_used+0x3d0>
    4f63:	89 d0                	mov    %edx,%eax
    4f65:	48 89 fb             	mov    %rdi,%rbx
    4f68:	48 89 f5             	mov    %rsi,%rbp
    4f6b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    4f6f:	48 01 c8             	add    %rcx,%rax
    4f72:	3e ff e0             	notrack jmp *%rax
    4f75:	0f 1f 00             	nopl   (%rax)
    4f78:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    4f7c:	48 8b 06             	mov    (%rsi),%rax
    4f7f:	48 89 ca             	mov    %rcx,%rdx
    4f82:	48 85 c9             	test   %rcx,%rcx
    4f85:	0f 88 b5 0c 00 00    	js     5c40 <fwp_write.constprop.0+0xd10>
    4f8b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    4f92:	00 
    4f93:	48 89 c6             	mov    %rax,%rsi
    4f96:	4c 89 e7             	mov    %r12,%rdi
    4f99:	e8 62 da ff ff       	call   2a00 <fwp_fmt_u128>
    4f9e:	66 90                	xchg   %ax,%ax
    4fa0:	4c 89 e7             	mov    %r12,%rdi
    4fa3:	e8 88 d4 ff ff       	call   2430 <strlen@plt>
    4fa8:	4c 89 e6             	mov    %r12,%rsi
    4fab:	48 89 df             	mov    %rbx,%rdi
    4fae:	48 89 c2             	mov    %rax,%rdx
    4fb1:	e8 ca df ff ff       	call   2f80 <buf_put>
    4fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fbd:	00 00 00 
    4fc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    4fc7:	00 
    4fc8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4fcf:	00 00 
    4fd1:	0f 85 9e 04 00 00    	jne    5475 <fwp_write.constprop.0+0x545>
    4fd7:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    4fde:	5b                   	pop    %rbx
    4fdf:	5d                   	pop    %rbp
    4fe0:	41 5c                	pop    %r12
    4fe2:	41 5d                	pop    %r13
    4fe4:	41 5e                	pop    %r14
    4fe6:	41 5f                	pop    %r15
    4fe8:	c3                   	ret
    4fe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ff0:	49 89 f1             	mov    %rsi,%r9
    4ff3:	4c 8d 05 e3 30 00 00 	lea    0x30e3(%rip),%r8        # 80dd <_IO_stdin_used+0xdd>
    4ffa:	b9 00 02 00 00       	mov    $0x200,%ecx
    4fff:	ba 02 00 00 00       	mov    $0x2,%edx
    5004:	be 00 02 00 00       	mov    $0x200,%esi
    5009:	31 c0                	xor    %eax,%eax
    500b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5012:	00 
    5013:	e8 78 d3 ff ff       	call   2390 <__snprintf_chk@plt>
    5018:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    501f:	00 
    5020:	e8 0b d4 ff ff       	call   2430 <strlen@plt>
    5025:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    502c:	00 
    502d:	48 89 df             	mov    %rbx,%rdi
    5030:	48 89 c2             	mov    %rax,%rdx
    5033:	e8 48 df ff ff       	call   2f80 <buf_put>
    5038:	eb 86                	jmp    4fc0 <fwp_write.constprop.0+0x90>
    503a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5040:	49 89 f1             	mov    %rsi,%r9
    5043:	4c 8d 05 8e 30 00 00 	lea    0x308e(%rip),%r8        # 80d8 <_IO_stdin_used+0xd8>
    504a:	eb ae                	jmp    4ffa <fwp_write.constprop.0+0xca>
    504c:	0f 1f 40 00          	nopl   0x0(%rax)
    5050:	83 fa 13             	cmp    $0x13,%edx
    5053:	48 8d 05 74 30 00 00 	lea    0x3074(%rip),%rax        # 80ce <_IO_stdin_used+0xce>
    505a:	48 8d 35 72 30 00 00 	lea    0x3072(%rip),%rsi        # 80d3 <_IO_stdin_used+0xd3>
    5061:	ba 04 00 00 00       	mov    $0x4,%edx
    5066:	48 0f 44 f0          	cmove  %rax,%rsi
    506a:	45 31 ed             	xor    %r13d,%r13d
    506d:	e8 0e df ff ff       	call   2f80 <buf_put>
    5072:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5077:	0f 84 b3 09 00 00    	je     5a30 <fwp_write.constprop.0+0xb00>
    507d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5082:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5087:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    508c:	48 89 df             	mov    %rbx,%rdi
    508f:	49 0f 44 c5          	cmove  %r13,%rax
    5093:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5098:	e8 93 fe ff ff       	call   4f30 <fwp_write.constprop.0>
    509d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    50a2:	0f 84 80 0a 00 00    	je     5b28 <fwp_write.constprop.0+0xbf8>
    50a8:	49 83 c5 01          	add    $0x1,%r13
    50ac:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    50b0:	0f 83 7a 09 00 00    	jae    5a30 <fwp_write.constprop.0+0xb00>
    50b6:	ba 02 00 00 00       	mov    $0x2,%edx
    50bb:	48 8d 35 5b 30 00 00 	lea    0x305b(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    50c2:	48 89 df             	mov    %rbx,%rdi
    50c5:	e8 b6 de ff ff       	call   2f80 <buf_put>
    50ca:	eb b1                	jmp    507d <fwp_write.constprop.0+0x14d>
    50cc:	0f 1f 40 00          	nopl   0x0(%rax)
    50d0:	ba 06 00 00 00       	mov    $0x6,%edx
    50d5:	48 8d 35 1a 30 00 00 	lea    0x301a(%rip),%rsi        # 80f6 <_IO_stdin_used+0xf6>
    50dc:	48 83 c5 10          	add    $0x10,%rbp
    50e0:	e8 9b de ff ff       	call   2f80 <buf_put>
    50e5:	48 89 ef             	mov    %rbp,%rdi
    50e8:	e8 43 d3 ff ff       	call   2430 <strlen@plt>
    50ed:	48 89 ee             	mov    %rbp,%rsi
    50f0:	48 89 df             	mov    %rbx,%rdi
    50f3:	48 89 c2             	mov    %rax,%rdx
    50f6:	e8 85 de ff ff       	call   2f80 <buf_put>
    50fb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5100:	ba 01 00 00 00       	mov    $0x1,%edx
    5105:	48 89 df             	mov    %rbx,%rdi
    5108:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    510d:	e8 6e de ff ff       	call   2f80 <buf_put>
    5112:	e9 a9 fe ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    511e:	00 00 
    5120:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5127:	00 
    5128:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    512f:	00 00 
    5131:	0f 85 3e 03 00 00    	jne    5475 <fwp_write.constprop.0+0x545>
    5137:	ba 0a 00 00 00       	mov    $0xa,%edx
    513c:	48 8d 35 9f 2f 00 00 	lea    0x2f9f(%rip),%rsi        # 80e2 <_IO_stdin_used+0xe2>
    5143:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    514a:	48 89 df             	mov    %rbx,%rdi
    514d:	5b                   	pop    %rbx
    514e:	5d                   	pop    %rbp
    514f:	41 5c                	pop    %r12
    5151:	41 5d                	pop    %r13
    5153:	41 5e                	pop    %r14
    5155:	41 5f                	pop    %r15
    5157:	e9 24 de ff ff       	jmp    2f80 <buf_put>
    515c:	0f 1f 40 00          	nopl   0x0(%rax)
    5160:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5165:	4d 85 ed             	test   %r13,%r13
    5168:	0f 84 c2 0b 00 00    	je     5d30 <fwp_write.constprop.0+0xe00>
    516e:	48 8d 35 b5 2f 00 00 	lea    0x2fb5(%rip),%rsi        # 812a <_IO_stdin_used+0x12a>
    5175:	4c 89 ef             	mov    %r13,%rdi
    5178:	e8 93 d3 ff ff       	call   2510 <strcmp@plt>
    517d:	41 89 c1             	mov    %eax,%r9d
    5180:	85 c0                	test   %eax,%eax
    5182:	0f 84 2c 0c 00 00    	je     5db4 <fwp_write.constprop.0+0xe84>
    5188:	4c 89 ef             	mov    %r13,%rdi
    518b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5190:	e8 9b d2 ff ff       	call   2430 <strlen@plt>
    5195:	4c 89 ee             	mov    %r13,%rsi
    5198:	48 89 df             	mov    %rbx,%rdi
    519b:	48 89 c2             	mov    %rax,%rdx
    519e:	e8 dd dd ff ff       	call   2f80 <buf_put>
    51a3:	ba 01 00 00 00       	mov    $0x1,%edx
    51a8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51ad:	48 89 df             	mov    %rbx,%rdi
    51b0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    51b5:	e8 c6 dd ff ff       	call   2f80 <buf_put>
    51ba:	ba 01 00 00 00       	mov    $0x1,%edx
    51bf:	4c 89 fe             	mov    %r15,%rsi
    51c2:	48 89 df             	mov    %rbx,%rdi
    51c5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    51ca:	e8 b1 dd ff ff       	call   2f80 <buf_put>
    51cf:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    51d4:	45 31 f6             	xor    %r14d,%r14d
    51d7:	85 c0                	test   %eax,%eax
    51d9:	0f 8e 91 0a 00 00    	jle    5c70 <fwp_write.constprop.0+0xd40>
    51df:	45 31 ed             	xor    %r13d,%r13d
    51e2:	4d 85 ed             	test   %r13,%r13
    51e5:	0f 85 d5 08 00 00    	jne    5ac0 <fwp_write.constprop.0+0xb90>
    51eb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    51f2:	00 
    51f3:	45 85 f6             	test   %r14d,%r14d
    51f6:	0f 84 74 08 00 00    	je     5a70 <fwp_write.constprop.0+0xb40>
    51fc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    5201:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    5206:	48 89 df             	mov    %rbx,%rdi
    5209:	49 83 c5 01          	add    $0x1,%r13
    520d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    5211:	e8 1a fd ff ff       	call   4f30 <fwp_write.constprop.0>
    5216:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    521b:	7f c5                	jg     51e2 <fwp_write.constprop.0+0x2b2>
    521d:	45 85 f6             	test   %r14d,%r14d
    5220:	0f 84 4a 0a 00 00    	je     5c70 <fwp_write.constprop.0+0xd40>
    5226:	b8 29 00 00 00       	mov    $0x29,%eax
    522b:	ba 01 00 00 00       	mov    $0x1,%edx
    5230:	4c 89 fe             	mov    %r15,%rsi
    5233:	48 89 df             	mov    %rbx,%rdi
    5236:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    523a:	e8 41 dd ff ff       	call   2f80 <buf_put>
    523f:	e9 7c fd ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5244:	0f 1f 40 00          	nopl   0x0(%rax)
    5248:	ba 01 00 00 00       	mov    $0x1,%edx
    524d:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5252:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    5257:	e8 24 dd ff ff       	call   2f80 <buf_put>
    525c:	48 85 ed             	test   %rbp,%rbp
    525f:	0f 84 8b 07 00 00    	je     59f0 <fwp_write.constprop.0+0xac0>
    5265:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5269:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    526e:	48 89 df             	mov    %rbx,%rdi
    5271:	e8 ba fc ff ff       	call   4f30 <fwp_write.constprop.0>
    5276:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    527a:	48 85 ed             	test   %rbp,%rbp
    527d:	0f 84 6d 07 00 00    	je     59f0 <fwp_write.constprop.0+0xac0>
    5283:	ba 02 00 00 00       	mov    $0x2,%edx
    5288:	48 8d 35 8e 2e 00 00 	lea    0x2e8e(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    528f:	48 89 df             	mov    %rbx,%rdi
    5292:	e8 e9 dc ff ff       	call   2f80 <buf_put>
    5297:	eb cc                	jmp    5265 <fwp_write.constprop.0+0x335>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	4c 8b 2e             	mov    (%rsi),%r13
    52a3:	ba 01 00 00 00       	mov    $0x1,%edx
    52a8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    52ad:	48 83 c5 08          	add    $0x8,%rbp
    52b1:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    52b6:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    52bb:	e8 c0 dc ff ff       	call   2f80 <buf_put>
    52c0:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    52c5:	4d 85 ed             	test   %r13,%r13
    52c8:	75 43                	jne    530d <fwp_write.constprop.0+0x3dd>
    52ca:	e9 81 07 00 00       	jmp    5a50 <fwp_write.constprop.0+0xb20>
    52cf:	90                   	nop
    52d0:	41 80 f9 09          	cmp    $0x9,%r9b
    52d4:	0f 84 f6 06 00 00    	je     59d0 <fwp_write.constprop.0+0xaa0>
    52da:	41 80 f9 0a          	cmp    $0xa,%r9b
    52de:	0f 85 bc 06 00 00    	jne    59a0 <fwp_write.constprop.0+0xa70>
    52e4:	ba 02 00 00 00       	mov    $0x2,%edx
    52e9:	48 8d 35 13 2e 00 00 	lea    0x2e13(%rip),%rsi        # 8103 <_IO_stdin_used+0x103>
    52f0:	48 89 df             	mov    %rbx,%rdi
    52f3:	e8 88 dc ff ff       	call   2f80 <buf_put>
    52f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    52ff:	00 
    5300:	48 83 c5 01          	add    $0x1,%rbp
    5304:	49 39 ec             	cmp    %rbp,%r12
    5307:	0f 84 43 07 00 00    	je     5a50 <fwp_write.constprop.0+0xb20>
    530d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    5312:	41 80 f9 0d          	cmp    $0xd,%r9b
    5316:	0f 84 64 06 00 00    	je     5980 <fwp_write.constprop.0+0xa50>
    531c:	7e b2                	jle    52d0 <fwp_write.constprop.0+0x3a0>
    531e:	41 80 f9 22          	cmp    $0x22,%r9b
    5322:	0f 84 38 06 00 00    	je     5960 <fwp_write.constprop.0+0xa30>
    5328:	41 80 f9 5c          	cmp    $0x5c,%r9b
    532c:	0f 85 6e 06 00 00    	jne    59a0 <fwp_write.constprop.0+0xa70>
    5332:	ba 02 00 00 00       	mov    $0x2,%edx
    5337:	48 8d 35 c2 2d 00 00 	lea    0x2dc2(%rip),%rsi        # 8100 <_IO_stdin_used+0x100>
    533e:	48 89 df             	mov    %rbx,%rdi
    5341:	e8 3a dc ff ff       	call   2f80 <buf_put>
    5346:	eb b8                	jmp    5300 <fwp_write.constprop.0+0x3d0>
    5348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    534f:	00 
    5350:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    5355:	ba 01 00 00 00       	mov    $0x1,%edx
    535a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    535f:	48 89 ee             	mov    %rbp,%rsi
    5362:	e8 19 dc ff ff       	call   2f80 <buf_put>
    5367:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    536c:	4c 89 e7             	mov    %r12,%rdi
    536f:	e8 bc d0 ff ff       	call   2430 <strlen@plt>
    5374:	4c 89 e6             	mov    %r12,%rsi
    5377:	48 89 df             	mov    %rbx,%rdi
    537a:	48 89 c2             	mov    %rax,%rdx
    537d:	e8 fe db ff ff       	call   2f80 <buf_put>
    5382:	ba 01 00 00 00       	mov    $0x1,%edx
    5387:	48 89 ee             	mov    %rbp,%rsi
    538a:	48 89 df             	mov    %rbx,%rdi
    538d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5392:	e8 e9 db ff ff       	call   2f80 <buf_put>
    5397:	e9 24 fc ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    539c:	0f 1f 40 00          	nopl   0x0(%rax)
    53a0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    53a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    53a9:	0f 8a de 0a 00 00    	jp     5e8d <fwp_write.constprop.0+0xf5d>
    53af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    53b3:	66 0f 54 05 05 31 00 	andpd  0x3105(%rip),%xmm0        # 84c0 <msg.3+0x80>
    53ba:	00 
    53bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    53c0:	66 0f 2e 05 18 31 00 	ucomisd 0x3118(%rip),%xmm0        # 84e0 <msg.3+0xa0>
    53c7:	00 
    53c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    53cf:	00 
    53d0:	0f 87 02 09 00 00    	ja     5cd8 <fwp_write.constprop.0+0xda8>
    53d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53dd:	00 00 00 
    53e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    53e4:	89 ee                	mov    %ebp,%esi
    53e6:	4c 89 e7             	mov    %r12,%rdi
    53e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    53ee:	e8 8d dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    53f3:	31 f6                	xor    %esi,%esi
    53f5:	4c 89 e7             	mov    %r12,%rdi
    53f8:	e8 f3 cf ff ff       	call   23f0 <strtod@plt>
    53fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    5402:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    5406:	7a 06                	jp     540e <fwp_write.constprop.0+0x4de>
    5408:	0f 84 09 03 00 00    	je     5717 <fwp_write.constprop.0+0x7e7>
    540e:	83 c5 01             	add    $0x1,%ebp
    5411:	83 fd 12             	cmp    $0x12,%ebp
    5414:	75 ca                	jne    53e0 <fwp_write.constprop.0+0x4b0>
    5416:	be 11 00 00 00       	mov    $0x11,%esi
    541b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    541f:	4c 89 e7             	mov    %r12,%rdi
    5422:	e8 59 dd ff ff       	call   3180 <fwp_format_g.constprop.0>
    5427:	e9 eb 02 00 00       	jmp    5717 <fwp_write.constprop.0+0x7e7>
    542c:	0f 1f 40 00          	nopl   0x0(%rax)
    5430:	48 83 fe 01          	cmp    $0x1,%rsi
    5434:	0f 84 86 08 00 00    	je     5cc0 <fwp_write.constprop.0+0xd90>
    543a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    543e:	b8 02 00 00 00       	mov    $0x2,%eax
    5443:	ba 01 00 00 00       	mov    $0x1,%edx
    5448:	48 0f 44 d0          	cmove  %rax,%rdx
    544c:	48 8d 35 79 2c 00 00 	lea    0x2c79(%rip),%rsi        # 80cc <_IO_stdin_used+0xcc>
    5453:	48 8d 05 6f 2c 00 00 	lea    0x2c6f(%rip),%rax        # 80c9 <_IO_stdin_used+0xc9>
    545a:	48 0f 44 f0          	cmove  %rax,%rsi
    545e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5465:	00 
    5466:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    546d:	00 00 
    546f:	0f 84 ce fc ff ff    	je     5143 <fwp_write.constprop.0+0x213>
    5475:	e8 c6 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    547a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5480:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5485:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    548a:	e8 31 da ff ff       	call   2ec0 <buf_grow>
    548f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5493:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5499:	4c 03 0b             	add    (%rbx),%r9
    549c:	66 45 89 11          	mov    %r10w,(%r9)
    54a0:	49 83 c1 01          	add    $0x1,%r9
    54a4:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    54ab:	55 55 55 
    54ae:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    54b5:	aa aa aa 
    54b8:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    54bc:	45 85 e4             	test   %r12d,%r12d
    54bf:	7f 4c                	jg     550d <fwp_write.constprop.0+0x5dd>
    54c1:	e9 4a 05 00 00       	jmp    5a10 <fwp_write.constprop.0+0xae0>
    54c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    54cd:	00 00 00 
    54d0:	be 01 00 00 00       	mov    $0x1,%esi
    54d5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    54da:	88 07                	mov    %al,(%rdi)
    54dc:	48 89 e8             	mov    %rbp,%rax
    54df:	49 f7 e8             	imul   %r8
    54e2:	48 89 e8             	mov    %rbp,%rax
    54e5:	48 c1 f8 3f          	sar    $0x3f,%rax
    54e9:	48 29 c2             	sub    %rax,%rdx
    54ec:	48 85 c9             	test   %rcx,%rcx
    54ef:	0f 95 c0             	setne  %al
    54f2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    54f6:	48 83 ef 01          	sub    $0x1,%rdi
    54fa:	48 21 c5             	and    %rax,%rbp
    54fd:	48 29 ea             	sub    %rbp,%rdx
    5500:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    5504:	49 39 f9             	cmp    %rdi,%r9
    5507:	0f 84 03 05 00 00    	je     5a10 <fwp_write.constprop.0+0xae0>
    550d:	48 89 e8             	mov    %rbp,%rax
    5510:	49 f7 e8             	imul   %r8
    5513:	48 89 e8             	mov    %rbp,%rax
    5516:	48 c1 f8 3f          	sar    $0x3f,%rax
    551a:	48 89 d1             	mov    %rdx,%rcx
    551d:	48 29 c1             	sub    %rax,%rcx
    5520:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    5524:	48 89 e9             	mov    %rbp,%rcx
    5527:	48 29 c1             	sub    %rax,%rcx
    552a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    552e:	49 f7 e2             	mul    %r10
    5531:	b8 30 00 00 00       	mov    $0x30,%eax
    5536:	48 89 d6             	mov    %rdx,%rsi
    5539:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    553d:	48 d1 ee             	shr    $1,%rsi
    5540:	48 01 f2             	add    %rsi,%rdx
    5543:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    5547:	48 29 d6             	sub    %rdx,%rsi
    554a:	74 8e                	je     54da <fwp_write.constprop.0+0x5aa>
    554c:	48 83 fe 01          	cmp    $0x1,%rsi
    5550:	0f 85 7a ff ff ff    	jne    54d0 <fwp_write.constprop.0+0x5a0>
    5556:	31 f6                	xor    %esi,%esi
    5558:	b8 2b 00 00 00       	mov    $0x2b,%eax
    555d:	e9 78 ff ff ff       	jmp    54da <fwp_write.constprop.0+0x5aa>
    5562:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5568:	ba 06 00 00 00       	mov    $0x6,%edx
    556d:	48 8d 35 ac 2b 00 00 	lea    0x2bac(%rip),%rsi        # 8120 <_IO_stdin_used+0x120>
    5574:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    557a:	e8 01 da ff ff       	call   2f80 <buf_put>
    557f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5586:	ff ff 7f 
    5589:	48 23 55 00          	and    0x0(%rbp),%rdx
    558d:	0f 84 4e 03 00 00    	je     58e1 <fwp_write.constprop.0+0x9b1>
    5593:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5598:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    559c:	48 85 d2             	test   %rdx,%rdx
    559f:	0f 84 a4 00 00 00    	je     5649 <fwp_write.constprop.0+0x719>
    55a5:	8b 0a                	mov    (%rdx),%ecx
    55a7:	83 f9 1c             	cmp    $0x1c,%ecx
    55aa:	0f 84 d0 06 00 00    	je     5c80 <fwp_write.constprop.0+0xd50>
    55b0:	83 f9 1b             	cmp    $0x1b,%ecx
    55b3:	0f 87 90 00 00 00    	ja     5649 <fwp_write.constprop.0+0x719>
    55b9:	be 01 00 00 00       	mov    $0x1,%esi
    55be:	48 d3 e6             	shl    %cl,%rsi
    55c1:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    55c7:	0f 85 13 06 00 00    	jne    5be0 <fwp_write.constprop.0+0xcb0>
    55cd:	f7 c6 84 04 00 00    	test   $0x484,%esi
    55d3:	0f 85 d7 05 00 00    	jne    5bb0 <fwp_write.constprop.0+0xc80>
    55d9:	83 e6 21             	and    $0x21,%esi
    55dc:	74 6b                	je     5649 <fwp_write.constprop.0+0x719>
    55de:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    55e3:	48 85 ff             	test   %rdi,%rdi
    55e6:	79 07                	jns    55ef <fwp_write.constprop.0+0x6bf>
    55e8:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    55ec:	4c 01 ee             	add    %r13,%rsi
    55ef:	48 0f be 3e          	movsbq (%rsi),%rdi
    55f3:	85 c9                	test   %ecx,%ecx
    55f5:	40 0f b6 f7          	movzbl %dil,%esi
    55f9:	48 0f 44 f7          	cmove  %rdi,%rsi
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	48 89 df             	mov    %rbx,%rdi
    5603:	49 83 c5 01          	add    $0x1,%r13
    5607:	e8 24 f9 ff ff       	call   4f30 <fwp_write.constprop.0>
    560c:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5613:	ff ff 7f 
    5616:	48 23 55 00          	and    0x0(%rbp),%rdx
    561a:	49 39 d5             	cmp    %rdx,%r13
    561d:	0f 83 be 02 00 00    	jae    58e1 <fwp_write.constprop.0+0x9b1>
    5623:	ba 02 00 00 00       	mov    $0x2,%edx
    5628:	48 89 df             	mov    %rbx,%rdi
    562b:	48 8d 35 eb 2a 00 00 	lea    0x2aeb(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    5632:	e8 49 d9 ff ff       	call   2f80 <buf_put>
    5637:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    563c:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    5640:	48 85 d2             	test   %rdx,%rdx
    5643:	0f 85 5c ff ff ff    	jne    55a5 <fwp_write.constprop.0+0x675>
    5649:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    564e:	48 85 ff             	test   %rdi,%rdi
    5651:	0f 88 51 06 00 00    	js     5ca8 <fwp_write.constprop.0+0xd78>
    5657:	48 8b 31             	mov    (%rcx),%rsi
    565a:	eb a4                	jmp    5600 <fwp_write.constprop.0+0x6d0>
    565c:	0f 1f 40 00          	nopl   0x0(%rax)
    5660:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5667:	00 
    5668:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566f:	00 00 
    5671:	0f 85 fe fd ff ff    	jne    5475 <fwp_write.constprop.0+0x545>
    5677:	ba 08 00 00 00       	mov    $0x8,%edx
    567c:	48 8d 35 6a 2a 00 00 	lea    0x2a6a(%rip),%rsi        # 80ed <_IO_stdin_used+0xed>
    5683:	e9 bb fa ff ff       	jmp    5143 <fwp_write.constprop.0+0x213>
    5688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    568f:	00 
    5690:	66 0f 6e ce          	movd   %esi,%xmm1
    5694:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5697:	0f 8a f0 07 00 00    	jp     5e8d <fwp_write.constprop.0+0xf5d>
    569d:	0f 28 c1             	movaps %xmm1,%xmm0
    56a0:	0f 54 05 09 2e 00 00 	andps  0x2e09(%rip),%xmm0        # 84b0 <msg.3+0x70>
    56a7:	0f 2e 05 56 29 00 00 	ucomiss 0x2956(%rip),%xmm0        # 8004 <_IO_stdin_used+0x4>
    56ae:	0f 87 4c 06 00 00    	ja     5d00 <fwp_write.constprop.0+0xdd0>
    56b4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    56b8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    56be:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    56c5:	00 
    56c6:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    56ca:	66 49 0f 7e d7       	movq   %xmm2,%r15
    56cf:	90                   	nop
    56d0:	44 89 ee             	mov    %r13d,%esi
    56d3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    56d8:	4c 89 e7             	mov    %r12,%rdi
    56db:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    56e0:	e8 9b da ff ff       	call   3180 <fwp_format_g.constprop.0>
    56e5:	31 f6                	xor    %esi,%esi
    56e7:	4c 89 e7             	mov    %r12,%rdi
    56ea:	e8 a1 cd ff ff       	call   2490 <strtof@plt>
    56ef:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    56f4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    56f7:	7a 02                	jp     56fb <fwp_write.constprop.0+0x7cb>
    56f9:	74 1c                	je     5717 <fwp_write.constprop.0+0x7e7>
    56fb:	41 83 c5 01          	add    $0x1,%r13d
    56ff:	41 83 fd 0a          	cmp    $0xa,%r13d
    5703:	75 cb                	jne    56d0 <fwp_write.constprop.0+0x7a0>
    5705:	be 09 00 00 00       	mov    $0x9,%esi
    570a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    570f:	4c 89 e7             	mov    %r12,%rdi
    5712:	e8 69 da ff ff       	call   3180 <fwp_format_g.constprop.0>
    5717:	4c 89 e7             	mov    %r12,%rdi
    571a:	e8 21 d9 ff ff       	call   3040 <fwp_finish_float>
    571f:	e9 7c f8 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5724:	0f 1f 40 00          	nopl   0x0(%rax)
    5728:	89 f0                	mov    %esi,%eax
    572a:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5731:	76 02                	jbe    5735 <fwp_write.constprop.0+0x805>
    5733:	8b 06                	mov    (%rsi),%eax
    5735:	41 89 c6             	mov    %eax,%r14d
    5738:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    573d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5742:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5746:	4c 89 ef             	mov    %r13,%rdi
    5749:	e8 e2 cc ff ff       	call   2430 <strlen@plt>
    574e:	4c 89 ee             	mov    %r13,%rsi
    5751:	48 89 df             	mov    %rbx,%rdi
    5754:	48 89 c2             	mov    %rax,%rdx
    5757:	e8 24 d8 ff ff       	call   2f80 <buf_put>
    575c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5761:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5765:	85 f6                	test   %esi,%esi
    5767:	0f 8e 53 f8 ff ff    	jle    4fc0 <fwp_write.constprop.0+0x90>
    576d:	45 31 ed             	xor    %r13d,%r13d
    5770:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5775:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    577a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    577f:	4c 89 fe             	mov    %r15,%rsi
    5782:	48 89 df             	mov    %rbx,%rdi
    5785:	ba 01 00 00 00       	mov    $0x1,%edx
    578a:	48 89 04 24          	mov    %rax,(%rsp)
    578e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5793:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5797:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    579b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    57a0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    57a5:	e8 d6 d7 ff ff       	call   2f80 <buf_put>
    57aa:	41 8b 06             	mov    (%r14),%eax
    57ad:	83 f8 0e             	cmp    $0xe,%eax
    57b0:	0f 84 5a 03 00 00    	je     5b10 <fwp_write.constprop.0+0xbe0>
    57b6:	83 f8 10             	cmp    $0x10,%eax
    57b9:	0f 84 21 03 00 00    	je     5ae0 <fwp_write.constprop.0+0xbb0>
    57bf:	83 f8 0a             	cmp    $0xa,%eax
    57c2:	0f 84 68 04 00 00    	je     5c30 <fwp_write.constprop.0+0xd00>
    57c8:	0f 8f 32 01 00 00    	jg     5900 <fwp_write.constprop.0+0x9d0>
    57ce:	83 f8 03             	cmp    $0x3,%eax
    57d1:	0f 8f 39 04 00 00    	jg     5c10 <fwp_write.constprop.0+0xce0>
    57d7:	85 c0                	test   %eax,%eax
    57d9:	78 10                	js     57eb <fwp_write.constprop.0+0x8bb>
    57db:	48 8b 04 24          	mov    (%rsp),%rax
    57df:	48 c1 e8 3f          	shr    $0x3f,%rax
    57e3:	85 c0                	test   %eax,%eax
    57e5:	0f 85 32 01 00 00    	jne    591d <fwp_write.constprop.0+0x9ed>
    57eb:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    57f0:	48 8b 34 24          	mov    (%rsp),%rsi
    57f4:	48 89 df             	mov    %rbx,%rdi
    57f7:	e8 34 f7 ff ff       	call   4f30 <fwp_write.constprop.0>
    57fc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5801:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5806:	49 83 c5 01          	add    $0x1,%r13
    580a:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    580e:	0f 8f 61 ff ff ff    	jg     5775 <fwp_write.constprop.0+0x845>
    5814:	e9 a7 f7 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5820:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5824:	48 8b 36             	mov    (%rsi),%rsi
    5827:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    582e:	00 
    582f:	48 89 ef             	mov    %rbp,%rdi
    5832:	e8 c9 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    5837:	48 89 ef             	mov    %rbp,%rdi
    583a:	e8 f1 cb ff ff       	call   2430 <strlen@plt>
    583f:	48 89 ee             	mov    %rbp,%rsi
    5842:	48 89 df             	mov    %rbx,%rdi
    5845:	48 89 c2             	mov    %rax,%rdx
    5848:	e8 33 d7 ff ff       	call   2f80 <buf_put>
    584d:	e9 6e f7 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5852:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5858:	ba 06 00 00 00       	mov    $0x6,%edx
    585d:	48 8d 35 af 28 00 00 	lea    0x28af(%rip),%rsi        # 8113 <_IO_stdin_used+0x113>
    5864:	45 31 ed             	xor    %r13d,%r13d
    5867:	e8 14 d7 ff ff       	call   2f80 <buf_put>
    586c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5871:	75 19                	jne    588c <fwp_write.constprop.0+0x95c>
    5873:	eb 6c                	jmp    58e1 <fwp_write.constprop.0+0x9b1>
    5875:	0f 1f 00             	nopl   (%rax)
    5878:	ba 02 00 00 00       	mov    $0x2,%edx
    587d:	48 8d 35 99 28 00 00 	lea    0x2899(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    5884:	48 89 df             	mov    %rbx,%rdi
    5887:	e8 f4 d6 ff ff       	call   2f80 <buf_put>
    588c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5892:	b9 00 02 00 00       	mov    $0x200,%ecx
    5897:	31 c0                	xor    %eax,%eax
    5899:	49 83 c5 01          	add    $0x1,%r13
    589d:	4c 8d 05 76 28 00 00 	lea    0x2876(%rip),%r8        # 811a <_IO_stdin_used+0x11a>
    58a4:	ba 02 00 00 00       	mov    $0x2,%edx
    58a9:	be 00 02 00 00       	mov    $0x200,%esi
    58ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58b5:	00 
    58b6:	e8 d5 ca ff ff       	call   2390 <__snprintf_chk@plt>
    58bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    58c2:	00 
    58c3:	e8 68 cb ff ff       	call   2430 <strlen@plt>
    58c8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    58cf:	00 
    58d0:	48 89 df             	mov    %rbx,%rdi
    58d3:	48 89 c2             	mov    %rax,%rdx
    58d6:	e8 a5 d6 ff ff       	call   2f80 <buf_put>
    58db:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    58df:	72 97                	jb     5878 <fwp_write.constprop.0+0x948>
    58e1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    58e6:	ba 01 00 00 00       	mov    $0x1,%edx
    58eb:	48 89 df             	mov    %rbx,%rdi
    58ee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    58f3:	e8 88 d6 ff ff       	call   2f80 <buf_put>
    58f8:	e9 c3 f6 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    58fd:	0f 1f 00             	nopl   (%rax)
    5900:	83 f8 0b             	cmp    $0xb,%eax
    5903:	0f 85 e2 fe ff ff    	jne    57eb <fwp_write.constprop.0+0x8bb>
    5909:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    590e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5912:	83 e0 01             	and    $0x1,%eax
    5915:	85 c0                	test   %eax,%eax
    5917:	0f 84 ce fe ff ff    	je     57eb <fwp_write.constprop.0+0x8bb>
    591d:	4c 89 fe             	mov    %r15,%rsi
    5920:	48 89 df             	mov    %rbx,%rdi
    5923:	ba 01 00 00 00       	mov    $0x1,%edx
    5928:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    592d:	e8 4e d6 ff ff       	call   2f80 <buf_put>
    5932:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5937:	48 8b 34 24          	mov    (%rsp),%rsi
    593b:	48 89 df             	mov    %rbx,%rdi
    593e:	e8 ed f5 ff ff       	call   4f30 <fwp_write.constprop.0>
    5943:	ba 01 00 00 00       	mov    $0x1,%edx
    5948:	4c 89 fe             	mov    %r15,%rsi
    594b:	48 89 df             	mov    %rbx,%rdi
    594e:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5953:	e8 28 d6 ff ff       	call   2f80 <buf_put>
    5958:	e9 9f fe ff ff       	jmp    57fc <fwp_write.constprop.0+0x8cc>
    595d:	0f 1f 00             	nopl   (%rax)
    5960:	ba 02 00 00 00       	mov    $0x2,%edx
    5965:	48 8d 35 91 27 00 00 	lea    0x2791(%rip),%rsi        # 80fd <_IO_stdin_used+0xfd>
    596c:	48 89 df             	mov    %rbx,%rdi
    596f:	e8 0c d6 ff ff       	call   2f80 <buf_put>
    5974:	e9 87 f9 ff ff       	jmp    5300 <fwp_write.constprop.0+0x3d0>
    5979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5980:	ba 02 00 00 00       	mov    $0x2,%edx
    5985:	48 8d 35 7d 27 00 00 	lea    0x277d(%rip),%rsi        # 8109 <_IO_stdin_used+0x109>
    598c:	48 89 df             	mov    %rbx,%rdi
    598f:	e8 ec d5 ff ff       	call   2f80 <buf_put>
    5994:	e9 67 f9 ff ff       	jmp    5300 <fwp_write.constprop.0+0x3d0>
    5999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    59a4:	0f 86 b6 01 00 00    	jbe    5b60 <fwp_write.constprop.0+0xc30>
    59aa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    59ae:	0f 84 ac 01 00 00    	je     5b60 <fwp_write.constprop.0+0xc30>
    59b4:	ba 01 00 00 00       	mov    $0x1,%edx
    59b9:	4c 89 fe             	mov    %r15,%rsi
    59bc:	48 89 df             	mov    %rbx,%rdi
    59bf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    59c4:	e8 b7 d5 ff ff       	call   2f80 <buf_put>
    59c9:	e9 32 f9 ff ff       	jmp    5300 <fwp_write.constprop.0+0x3d0>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	ba 02 00 00 00       	mov    $0x2,%edx
    59d5:	48 8d 35 2a 27 00 00 	lea    0x272a(%rip),%rsi        # 8106 <_IO_stdin_used+0x106>
    59dc:	48 89 df             	mov    %rbx,%rdi
    59df:	e8 9c d5 ff ff       	call   2f80 <buf_put>
    59e4:	e9 17 f9 ff ff       	jmp    5300 <fwp_write.constprop.0+0x3d0>
    59e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59f0:	ba 01 00 00 00       	mov    $0x1,%edx
    59f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    59fa:	48 89 df             	mov    %rbx,%rdi
    59fd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5a02:	e8 79 d5 ff ff       	call   2f80 <buf_put>
    5a07:	e9 b4 f5 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a10:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5a14:	48 8b 13             	mov    (%rbx),%rdx
    5a17:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5a1c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5a20:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5a24:	e9 97 f5 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a30:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a35:	ba 01 00 00 00       	mov    $0x1,%edx
    5a3a:	48 89 df             	mov    %rbx,%rdi
    5a3d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5a42:	e8 39 d5 ff ff       	call   2f80 <buf_put>
    5a47:	e9 74 f5 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    5a50:	ba 01 00 00 00       	mov    $0x1,%edx
    5a55:	4c 89 fe             	mov    %r15,%rsi
    5a58:	48 89 df             	mov    %rbx,%rdi
    5a5b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5a60:	e8 1b d5 ff ff       	call   2f80 <buf_put>
    5a65:	e9 56 f5 ff ff       	jmp    4fc0 <fwp_write.constprop.0+0x90>
    5a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5a75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5a7e:	48 89 f7             	mov    %rsi,%rdi
    5a81:	48 89 34 24          	mov    %rsi,(%rsp)
    5a85:	e8 a6 c9 ff ff       	call   2430 <strlen@plt>
    5a8a:	48 8b 34 24          	mov    (%rsp),%rsi
    5a8e:	48 89 df             	mov    %rbx,%rdi
    5a91:	48 89 c2             	mov    %rax,%rdx
    5a94:	e8 e7 d4 ff ff       	call   2f80 <buf_put>
    5a99:	ba 03 00 00 00       	mov    $0x3,%edx
    5a9e:	48 8d 35 9b 26 00 00 	lea    0x269b(%rip),%rsi        # 8140 <_IO_stdin_used+0x140>
    5aa5:	48 89 df             	mov    %rbx,%rdi
    5aa8:	e8 d3 d4 ff ff       	call   2f80 <buf_put>
    5aad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5ab2:	e9 45 f7 ff ff       	jmp    51fc <fwp_write.constprop.0+0x2cc>
    5ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5abe:	00 00 
    5ac0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ac5:	48 8d 35 51 26 00 00 	lea    0x2651(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    5acc:	48 89 df             	mov    %rbx,%rdi
    5acf:	e8 ac d4 ff ff       	call   2f80 <buf_put>
    5ad4:	e9 12 f7 ff ff       	jmp    51eb <fwp_write.constprop.0+0x2bb>
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5ae5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5ae9:	48 85 ff             	test   %rdi,%rdi
    5aec:	0f 84 f9 fc ff ff    	je     57eb <fwp_write.constprop.0+0x8bb>
    5af2:	48 8d 35 31 26 00 00 	lea    0x2631(%rip),%rsi        # 812a <_IO_stdin_used+0x12a>
    5af9:	e8 12 ca ff ff       	call   2510 <strcmp@plt>
    5afe:	85 c0                	test   %eax,%eax
    5b00:	0f 95 c0             	setne  %al
    5b03:	0f b6 c0             	movzbl %al,%eax
    5b06:	e9 d8 fc ff ff       	jmp    57e3 <fwp_write.constprop.0+0x8b3>
    5b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b10:	31 c0                	xor    %eax,%eax
    5b12:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5b19:	00 
    5b1a:	0f 97 c0             	seta   %al
    5b1d:	e9 c1 fc ff ff       	jmp    57e3 <fwp_write.constprop.0+0x8b3>
    5b22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b28:	48 89 df             	mov    %rbx,%rdi
    5b2b:	ba 02 00 00 00       	mov    $0x2,%edx
    5b30:	48 8d 35 f0 25 00 00 	lea    0x25f0(%rip),%rsi        # 8127 <_IO_stdin_used+0x127>
    5b37:	e8 44 d4 ff ff       	call   2f80 <buf_put>
    5b3c:	4c 89 e8             	mov    %r13,%rax
    5b3f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5b44:	48 89 df             	mov    %rbx,%rdi
    5b47:	48 c1 e0 04          	shl    $0x4,%rax
    5b4b:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5b50:	e8 db f3 ff ff       	call   4f30 <fwp_write.constprop.0>
    5b55:	e9 4e f5 ff ff       	jmp    50a8 <fwp_write.constprop.0+0x178>
    5b5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b60:	4c 8d 05 a5 25 00 00 	lea    0x25a5(%rip),%r8        # 810c <_IO_stdin_used+0x10c>
    5b67:	b9 10 00 00 00       	mov    $0x10,%ecx
    5b6c:	31 c0                	xor    %eax,%eax
    5b6e:	ba 02 00 00 00       	mov    $0x2,%edx
    5b73:	be 10 00 00 00       	mov    $0x10,%esi
    5b78:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5b7f:	00 
    5b80:	e8 0b c8 ff ff       	call   2390 <__snprintf_chk@plt>
    5b85:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5b8c:	00 
    5b8d:	e8 9e c8 ff ff       	call   2430 <strlen@plt>
    5b92:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5b99:	00 
    5b9a:	48 89 df             	mov    %rbx,%rdi
    5b9d:	48 89 c2             	mov    %rax,%rdx
    5ba0:	e8 db d3 ff ff       	call   2f80 <buf_put>
    5ba5:	e9 56 f7 ff ff       	jmp    5300 <fwp_write.constprop.0+0x3d0>
    5baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bb0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5bb5:	48 85 ff             	test   %rdi,%rdi
    5bb8:	79 0c                	jns    5bc6 <fwp_write.constprop.0+0xc96>
    5bba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5bc1:	00 
    5bc2:	48 03 75 10          	add    0x10(%rbp),%rsi
    5bc6:	48 63 3e             	movslq (%rsi),%rdi
    5bc9:	83 f9 02             	cmp    $0x2,%ecx
    5bcc:	89 fe                	mov    %edi,%esi
    5bce:	48 0f 44 f7          	cmove  %rdi,%rsi
    5bd2:	e9 29 fa ff ff       	jmp    5600 <fwp_write.constprop.0+0x6d0>
    5bd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bde:	00 00 
    5be0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5be5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5bea:	48 85 ff             	test   %rdi,%rdi
    5bed:	0f 88 6f 01 00 00    	js     5d62 <fwp_write.constprop.0+0xe32>
    5bf3:	49 0f bf 38          	movswq (%r8),%rdi
    5bf7:	83 f9 01             	cmp    $0x1,%ecx
    5bfa:	0f b7 f7             	movzwl %di,%esi
    5bfd:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c01:	e9 fa f9 ff ff       	jmp    5600 <fwp_write.constprop.0+0x6d0>
    5c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c0d:	00 00 00 
    5c10:	83 f8 04             	cmp    $0x4,%eax
    5c13:	0f 85 d2 fb ff ff    	jne    57eb <fwp_write.constprop.0+0x8bb>
    5c19:	48 8b 04 24          	mov    (%rsp),%rax
    5c1d:	48 8b 40 08          	mov    0x8(%rax),%rax
    5c21:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5c26:	48 c1 e8 3f          	shr    $0x3f,%rax
    5c2a:	e9 e6 fc ff ff       	jmp    5915 <fwp_write.constprop.0+0x9e5>
    5c2f:	90                   	nop
    5c30:	8b 0c 24             	mov    (%rsp),%ecx
    5c33:	31 c0                	xor    %eax,%eax
    5c35:	85 c9                	test   %ecx,%ecx
    5c37:	0f 98 c0             	sets   %al
    5c3a:	e9 d6 fc ff ff       	jmp    5915 <fwp_write.constprop.0+0x9e5>
    5c3f:	90                   	nop
    5c40:	48 f7 d8             	neg    %rax
    5c43:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5c4a:	00 
    5c4b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5c52:	2d 
    5c53:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5c5a:	00 
    5c5b:	48 83 d2 00          	adc    $0x0,%rdx
    5c5f:	48 89 c6             	mov    %rax,%rsi
    5c62:	48 f7 da             	neg    %rdx
    5c65:	e8 96 cd ff ff       	call   2a00 <fwp_fmt_u128>
    5c6a:	e9 31 f3 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5c6f:	90                   	nop
    5c70:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5c75:	e9 b1 f5 ff ff       	jmp    522b <fwp_write.constprop.0+0x2fb>
    5c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c80:	4c 89 e9             	mov    %r13,%rcx
    5c83:	48 c1 e1 04          	shl    $0x4,%rcx
    5c87:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5c8c:	48 85 ff             	test   %rdi,%rdi
    5c8f:	0f 89 6b f9 ff ff    	jns    5600 <fwp_write.constprop.0+0x6d0>
    5c95:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5c99:	48 89 ce             	mov    %rcx,%rsi
    5c9c:	e9 5f f9 ff ff       	jmp    5600 <fwp_write.constprop.0+0x6d0>
    5ca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ca8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5caf:	00 
    5cb0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5cb4:	e9 9e f9 ff ff       	jmp    5657 <fwp_write.constprop.0+0x727>
    5cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cc0:	ba 02 00 00 00       	mov    $0x2,%edx
    5cc5:	48 8d 35 fa 23 00 00 	lea    0x23fa(%rip),%rsi        # 80c6 <_IO_stdin_used+0xc6>
    5ccc:	e9 8d f7 ff ff       	jmp    545e <fwp_write.constprop.0+0x52e>
    5cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5cd8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5cdc:	48 8d 35 df 23 00 00 	lea    0x23df(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    5ce3:	48 8d 05 d7 23 00 00 	lea    0x23d7(%rip),%rax        # 80c1 <_IO_stdin_used+0xc1>
    5cea:	4c 89 e7             	mov    %r12,%rdi
    5ced:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5cf1:	48 0f 46 f0          	cmovbe %rax,%rsi
    5cf5:	e8 d6 c6 ff ff       	call   23d0 <strcpy@plt>
    5cfa:	e9 a1 f2 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5cff:	90                   	nop
    5d00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d04:	48 8d 35 b7 23 00 00 	lea    0x23b7(%rip),%rsi        # 80c2 <_IO_stdin_used+0xc2>
    5d0b:	48 8d 05 af 23 00 00 	lea    0x23af(%rip),%rax        # 80c1 <_IO_stdin_used+0xc1>
    5d12:	0f 2f c8             	comiss %xmm0,%xmm1
    5d15:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5d1c:	00 
    5d1d:	4c 89 e7             	mov    %r12,%rdi
    5d20:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d24:	e8 a7 c6 ff ff       	call   23d0 <strcpy@plt>
    5d29:	e9 72 f2 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5d2e:	66 90                	xchg   %ax,%ax
    5d30:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5d35:	45 85 c0             	test   %r8d,%r8d
    5d38:	75 34                	jne    5d6e <fwp_write.constprop.0+0xe3e>
    5d3a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5d41:	00 
    5d42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d49:	00 00 
    5d4b:	0f 85 24 f7 ff ff    	jne    5475 <fwp_write.constprop.0+0x545>
    5d51:	ba 02 00 00 00       	mov    $0x2,%edx
    5d56:	48 8d 35 e0 23 00 00 	lea    0x23e0(%rip),%rsi        # 813d <_IO_stdin_used+0x13d>
    5d5d:	e9 e1 f3 ff ff       	jmp    5143 <fwp_write.constprop.0+0x213>
    5d62:	48 03 75 10          	add    0x10(%rbp),%rsi
    5d66:	49 89 f0             	mov    %rsi,%r8
    5d69:	e9 85 fe ff ff       	jmp    5bf3 <fwp_write.constprop.0+0xcc3>
    5d6e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5d73:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5d78:	85 ff                	test   %edi,%edi
    5d7a:	0f 84 3a f4 ff ff    	je     51ba <fwp_write.constprop.0+0x28a>
    5d80:	ba 01 00 00 00       	mov    $0x1,%edx
    5d85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5d8a:	48 89 df             	mov    %rbx,%rdi
    5d8d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5d92:	e8 e9 d1 ff ff       	call   2f80 <buf_put>
    5d97:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5d9c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5da1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5da7:	85 d2                	test   %edx,%edx
    5da9:	0f 8f 30 f4 ff ff    	jg     51df <fwp_write.constprop.0+0x2af>
    5daf:	e9 72 f4 ff ff       	jmp    5226 <fwp_write.constprop.0+0x2f6>
    5db4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5db8:	49 89 c5             	mov    %rax,%r13
    5dbb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5dc0:	49 89 c4             	mov    %rax,%r12
    5dc3:	49 c1 fd 3f          	sar    $0x3f,%r13
    5dc7:	4c 09 e8             	or     %r13,%rax
    5dca:	0f 84 a7 00 00 00    	je     5e77 <fwp_write.constprop.0+0xf47>
    5dd0:	48 8d 2d 89 3d 00 00 	lea    0x3d89(%rip),%rbp        # 9b60 <units.0>
    5dd7:	4d 89 e7             	mov    %r12,%r15
    5dda:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5dde:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5de3:	4c 89 ff             	mov    %r15,%rdi
    5de6:	4c 89 ee             	mov    %r13,%rsi
    5de9:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ded:	48 99                	cqto
    5def:	48 89 d1             	mov    %rdx,%rcx
    5df2:	48 89 c2             	mov    %rax,%rdx
    5df5:	e8 16 1a 00 00       	call   7810 <__divmodti4>
    5dfa:	44 8b 0c 24          	mov    (%rsp),%r9d
    5dfe:	48 89 c1             	mov    %rax,%rcx
    5e01:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5e06:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5e0b:	0f 84 94 00 00 00    	je     5ea5 <fwp_write.constprop.0+0xf75>
    5e11:	41 83 c1 01          	add    $0x1,%r9d
    5e15:	48 83 c5 10          	add    $0x10,%rbp
    5e19:	41 83 f9 05          	cmp    $0x5,%r9d
    5e1d:	75 bb                	jne    5dda <fwp_write.constprop.0+0xeaa>
    5e1f:	4d 85 ed             	test   %r13,%r13
    5e22:	79 53                	jns    5e77 <fwp_write.constprop.0+0xf47>
    5e24:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5e29:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5e2e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5e33:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e38:	48 99                	cqto
    5e3a:	48 f7 d8             	neg    %rax
    5e3d:	48 83 d2 00          	adc    $0x0,%rdx
    5e41:	48 89 c6             	mov    %rax,%rsi
    5e44:	48 f7 da             	neg    %rdx
    5e47:	e8 b4 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5e4c:	49 89 e8             	mov    %rbp,%r8
    5e4f:	ba 00 02 00 00       	mov    $0x200,%edx
    5e54:	be 02 00 00 00       	mov    $0x2,%esi
    5e59:	31 c0                	xor    %eax,%eax
    5e5b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5e62:	00 
    5e63:	48 8d 0d ce 22 00 00 	lea    0x22ce(%rip),%rcx        # 8138 <_IO_stdin_used+0x138>
    5e6a:	4c 89 e7             	mov    %r12,%rdi
    5e6d:	e8 2e c8 ff ff       	call   26a0 <__sprintf_chk@plt>
    5e72:	e9 29 f1 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5e77:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5e7c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5e81:	31 d2                	xor    %edx,%edx
    5e83:	48 89 ef             	mov    %rbp,%rdi
    5e86:	e8 75 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5e8b:	eb bf                	jmp    5e4c <fwp_write.constprop.0+0xf1c>
    5e8d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5e94:	4e 61 4e 00 
    5e98:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5e9f:	00 
    5ea0:	e9 fb f0 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5ea5:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ea9:	48 89 c8             	mov    %rcx,%rax
    5eac:	48 85 d2             	test   %rdx,%rdx
    5eaf:	78 51                	js     5f02 <fwp_write.constprop.0+0xfd2>
    5eb1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5eb6:	48 89 c6             	mov    %rax,%rsi
    5eb9:	48 89 ef             	mov    %rbp,%rdi
    5ebc:	e8 3f cb ff ff       	call   2a00 <fwp_fmt_u128>
    5ec1:	44 8b 0c 24          	mov    (%rsp),%r9d
    5ec5:	49 63 c1             	movslq %r9d,%rax
    5ec8:	49 89 e8             	mov    %rbp,%r8
    5ecb:	ba 00 02 00 00       	mov    $0x200,%edx
    5ed0:	be 02 00 00 00       	mov    $0x2,%esi
    5ed5:	48 c1 e0 04          	shl    $0x4,%rax
    5ed9:	48 8d 0d 80 3c 00 00 	lea    0x3c80(%rip),%rcx        # 9b60 <units.0>
    5ee0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5ee7:	00 
    5ee8:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5eec:	4c 89 e7             	mov    %r12,%rdi
    5eef:	48 8d 0d 3d 22 00 00 	lea    0x223d(%rip),%rcx        # 8133 <_IO_stdin_used+0x133>
    5ef6:	31 c0                	xor    %eax,%eax
    5ef8:	e8 a3 c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5efd:	e9 9e f0 ff ff       	jmp    4fa0 <fwp_write.constprop.0+0x70>
    5f02:	48 f7 d8             	neg    %rax
    5f05:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5f0a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5f0f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f14:	48 83 d2 00          	adc    $0x0,%rdx
    5f18:	48 89 c6             	mov    %rax,%rsi
    5f1b:	48 f7 da             	neg    %rdx
    5f1e:	e8 dd ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f23:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f27:	eb 9c                	jmp    5ec5 <fwp_write.constprop.0+0xf95>
    5f29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005f30 <fwp_main_thread>:
    5f30:	f3 0f 1e fa          	endbr64
    5f34:	41 57                	push   %r15
    5f36:	41 56                	push   %r14
    5f38:	41 55                	push   %r13
    5f3a:	41 54                	push   %r12
    5f3c:	55                   	push   %rbp
    5f3d:	53                   	push   %rbx
    5f3e:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    5f45:	8b 3d 79 5b 01 00    	mov    0x15b79(%rip),%edi        # 1bac4 <fwp_heap+0x13a4>
    5f4b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5f52:	00 00 
    5f54:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    5f5b:	00 
    5f5c:	31 c0                	xor    %eax,%eax
    5f5e:	85 ff                	test   %edi,%edi
    5f60:	0f 84 a2 0c 00 00    	je     6c08 <fwp_main_thread+0xcd8>
    5f66:	8b 35 5c 5b 01 00    	mov    0x15b5c(%rip),%esi        # 1bac8 <fwp_heap+0x13a8>
    5f6c:	85 f6                	test   %esi,%esi
    5f6e:	0f 85 cc 05 00 00    	jne    6540 <fwp_main_thread+0x610>
    5f74:	4c 8d 74 24 50       	lea    0x50(%rsp),%r14
    5f79:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
    5f7e:	31 f6                	xor    %esi,%esi
    5f80:	48 c7 05 3d 41 01 00 	movq   $0x40000000,0x1413d(%rip)        # 1a0c8 <fwp_main_stack_size>
    5f87:	00 00 00 40 
    5f8b:	48 8d 05 2e 41 00 00 	lea    0x412e(%rip),%rax        # a0c0 <alt.4>
    5f92:	4c 89 f7             	mov    %r14,%rdi
    5f95:	4c 89 25 34 41 01 00 	mov    %r12,0x14134(%rip)        # 1a0d0 <fwp_main_stack_top>
    5f9c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    5fa1:	48 c7 44 24 60 00 00 	movq   $0x10000,0x60(%rsp)
    5fa8:	01 00 
    5faa:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
    5fb1:	00 
    5fb2:	e8 c9 c6 ff ff       	call   2680 <sigaltstack@plt>
    5fb7:	85 c0                	test   %eax,%eax
    5fb9:	0f 85 c8 17 00 00    	jne    7787 <fwp_main_thread+0x1857>
    5fbf:	31 db                	xor    %ebx,%ebx
    5fc1:	b9 12 00 00 00       	mov    $0x12,%ecx
    5fc6:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
    5fcd:	00 
    5fce:	48 89 d8             	mov    %rbx,%rax
    5fd1:	48 8d ac 24 90 00 00 	lea    0x90(%rsp),%rbp
    5fd8:	00 
    5fd9:	f3 48 ab             	rep stos %rax,(%rdi)
    5fdc:	48 8d 05 5d cc ff ff 	lea    -0x33a3(%rip),%rax        # 2c40 <fwp_segv>
    5fe3:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
    5fea:	00 
    5feb:	c7 84 24 18 01 00 00 	movl   $0x8000004,0x118(%rsp)
    5ff2:	04 00 00 08 
    5ff6:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    5ffd:	00 
    5ffe:	e8 4d c5 ff ff       	call   2550 <sigemptyset@plt>
    6003:	85 c0                	test   %eax,%eax
    6005:	0f 85 7c 17 00 00    	jne    7787 <fwp_main_thread+0x1857>
    600b:	31 d2                	xor    %edx,%edx
    600d:	48 89 ee             	mov    %rbp,%rsi
    6010:	bf 0b 00 00 00       	mov    $0xb,%edi
    6015:	e8 c6 c3 ff ff       	call   23e0 <sigaction@plt>
    601a:	85 c0                	test   %eax,%eax
    601c:	0f 85 65 17 00 00    	jne    7787 <fwp_main_thread+0x1857>
    6022:	31 d2                	xor    %edx,%edx
    6024:	48 89 ee             	mov    %rbp,%rsi
    6027:	bf 07 00 00 00       	mov    $0x7,%edi
    602c:	e8 af c3 ff ff       	call   23e0 <sigaction@plt>
    6031:	85 c0                	test   %eax,%eax
    6033:	0f 85 4e 17 00 00    	jne    7787 <fwp_main_thread+0x1857>
    6039:	8b 0d 69 40 00 00    	mov    0x4069(%rip),%ecx        # a0a8 <st.2>
    603f:	85 c9                	test   %ecx,%ecx
    6041:	0f 84 11 05 00 00    	je     6558 <fwp_main_thread+0x628>
    6047:	48 8b 2d b2 46 01 00 	mov    0x146b2(%rip),%rbp        # 1a700 <fwp_cur>
    604e:	48 85 ed             	test   %rbp,%rbp
    6051:	0f 84 c9 01 00 00    	je     6220 <fwp_main_thread+0x2f0>
    6057:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    605c:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    6060:	48 89 eb             	mov    %rbp,%rbx
    6063:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    6068:	0f 84 41 01 00 00    	je     61af <fwp_main_thread+0x27f>
    606e:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    6073:	0f 84 e7 03 00 00    	je     6460 <fwp_main_thread+0x530>
    6079:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    607d:	0f 84 b5 03 00 00    	je     6438 <fwp_main_thread+0x508>
    6083:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    6087:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    608b:	0f 85 4f 04 00 00    	jne    64e0 <fwp_main_thread+0x5b0>
    6091:	48 8b 43 60          	mov    0x60(%rbx),%rax
    6095:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    609c:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    60a0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    60a7:	00 00 00 00 
    60ab:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    60b2:	48 85 d2             	test   %rdx,%rdx
    60b5:	74 07                	je     60be <fwp_main_thread+0x18e>
    60b7:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    60be:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    60c2:	48 85 c0             	test   %rax,%rax
    60c5:	74 34                	je     60fb <fwp_main_thread+0x1cb>
    60c7:	48 89 43 68          	mov    %rax,0x68(%rbx)
    60cb:	48 8b 05 06 46 01 00 	mov    0x14606(%rip),%rax        # 1a6d8 <fwp_timers>
    60d2:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    60d6:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    60dd:	00 00 00 00 
    60e1:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    60e8:	48 85 c0             	test   %rax,%rax
    60eb:	74 07                	je     60f4 <fwp_main_thread+0x1c4>
    60ed:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    60f4:	48 89 1d dd 45 01 00 	mov    %rbx,0x145dd(%rip)        # 1a6d8 <fwp_timers>
    60fb:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    60ff:	e8 ac e9 ff ff       	call   4ab0 <fwp_block>
    6104:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    610b:	48 85 c9             	test   %rcx,%rcx
    610e:	74 47                	je     6157 <fwp_main_thread+0x227>
    6110:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    6117:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    611e:	48 85 d2             	test   %rdx,%rdx
    6121:	0f 84 f9 03 00 00    	je     6520 <fwp_main_thread+0x5f0>
    6127:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    612e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    6135:	48 85 c0             	test   %rax,%rax
    6138:	74 07                	je     6141 <fwp_main_thread+0x211>
    613a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    6141:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    6148:	00 00 00 00 
    614c:	66 0f ef ed          	pxor   %xmm5,%xmm5
    6150:	0f 11 ab 18 01 00 00 	movups %xmm5,0x118(%rbx)
    6157:	48 8b 0d a2 45 01 00 	mov    0x145a2(%rip),%rcx        # 1a700 <fwp_cur>
    615e:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    6162:	0f 84 68 03 00 00    	je     64d0 <fwp_main_thread+0x5a0>
    6168:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    616f:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    6176:	48 85 d2             	test   %rdx,%rdx
    6179:	0f 84 b1 03 00 00    	je     6530 <fwp_main_thread+0x600>
    617f:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    6186:	48 85 c0             	test   %rax,%rax
    6189:	74 07                	je     6192 <fwp_main_thread+0x262>
    618b:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    6192:	66 0f ef f6          	pxor   %xmm6,%xmm6
    6196:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    619a:	0f 11 b3 08 01 00 00 	movups %xmm6,0x108(%rbx)
    61a1:	48 89 cb             	mov    %rcx,%rbx
    61a4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    61a9:	0f 85 bf fe ff ff    	jne    606e <fwp_main_thread+0x13e>
    61af:	48 83 3d d9 61 01 00 	cmpq   $0x0,0x161d9(%rip)        # 1c390 <fwp_state_len>
    61b6:	00 
    61b7:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    61bb:	75 0e                	jne    61cb <fwp_main_thread+0x29b>
    61bd:	48 83 3d bb 61 01 00 	cmpq   $0x0,0x161bb(%rip)        # 1c380 <fwp_state_owners>
    61c4:	00 
    61c5:	0f 84 bd 13 00 00    	je     7588 <fwp_main_thread+0x1658>
    61cb:	48 39 1d 26 45 01 00 	cmp    %rbx,0x14526(%rip)        # 1a6f8 <fwp_root>
    61d2:	c7 05 e4 3e 01 00 00 	movl   $0x0,0x13ee4(%rip)        # 1a0c0 <fwp_exit_code>
    61d9:	00 00 00 
    61dc:	0f 85 1f 16 00 00    	jne    7801 <fwp_main_thread+0x18d1>
    61e2:	48 85 db             	test   %rbx,%rbx
    61e5:	74 5f                	je     6246 <fwp_main_thread+0x316>
    61e7:	48 8b 15 da 44 01 00 	mov    0x144da(%rip),%rdx        # 1a6c8 <fwp_tasks_active>
    61ee:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    61f2:	48 85 d2             	test   %rdx,%rdx
    61f5:	74 4f                	je     6246 <fwp_main_thread+0x316>
    61f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    61fe:	00 00 
    6200:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    6204:	75 08                	jne    620e <fwp_main_thread+0x2de>
    6206:	48 89 d7             	mov    %rdx,%rdi
    6209:	e8 b2 cd ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    620e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    6215:	48 85 d2             	test   %rdx,%rdx
    6218:	75 e6                	jne    6200 <fwp_main_thread+0x2d0>
    621a:	e9 e6 01 00 00       	jmp    6405 <fwp_main_thread+0x4d5>
    621f:	90                   	nop
    6220:	48 83 3d 68 61 01 00 	cmpq   $0x0,0x16168(%rip)        # 1c390 <fwp_state_len>
    6227:	00 
    6228:	0f 84 db 11 00 00    	je     7409 <fwp_main_thread+0x14d9>
    622e:	48 83 3d c2 44 01 00 	cmpq   $0x0,0x144c2(%rip)        # 1a6f8 <fwp_root>
    6235:	00 
    6236:	c7 05 80 3e 01 00 00 	movl   $0x0,0x13e80(%rip)        # 1a0c0 <fwp_exit_code>
    623d:	00 00 00 
    6240:	0f 85 b6 15 00 00    	jne    77fc <fwp_main_thread+0x18cc>
    6246:	e8 55 e6 ff ff       	call   48a0 <fwp_free_zombie>
    624b:	48 83 3d 95 44 01 00 	cmpq   $0x0,0x14495(%rip)        # 1a6e8 <fwp_ready_head>
    6252:	00 
    6253:	0f 85 b2 c4 ff ff    	jne    270b <fwp_main_thread.cold>
    6259:	48 83 3d 77 44 01 00 	cmpq   $0x0,0x14477(%rip)        # 1a6d8 <fwp_timers>
    6260:	00 
    6261:	0f 85 a4 c4 ff ff    	jne    270b <fwp_main_thread.cold>
    6267:	8b 05 6f 3e 01 00    	mov    0x13e6f(%rip),%eax        # 1a0dc <fwp_stack_pool_n>
    626d:	85 c0                	test   %eax,%eax
    626f:	74 3c                	je     62ad <fwp_main_thread+0x37d>
    6271:	83 e8 01             	sub    $0x1,%eax
    6274:	4c 8d 25 65 3e 01 00 	lea    0x13e65(%rip),%r12        # 1a0e0 <fwp_stack_pool>
    627b:	48 63 d8             	movslq %eax,%rbx
    627e:	89 c0                	mov    %eax,%eax
    6280:	48 89 da             	mov    %rbx,%rdx
    6283:	48 29 c2             	sub    %rax,%rdx
    6286:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    628a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6290:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    6294:	89 1d 42 3e 01 00    	mov    %ebx,0x13e42(%rip)        # 1a0dc <fwp_stack_pool_n>
    629a:	be 00 00 00 10       	mov    $0x10000000,%esi
    629f:	48 83 eb 01          	sub    $0x1,%rbx
    62a3:	e8 08 c3 ff ff       	call   25b0 <munmap@plt>
    62a8:	48 39 dd             	cmp    %rbx,%rbp
    62ab:	75 e3                	jne    6290 <fwp_main_thread+0x360>
    62ad:	8b 3d 9d 3d 00 00    	mov    0x3d9d(%rip),%edi        # a050 <fwp_epfd>
    62b3:	85 ff                	test   %edi,%edi
    62b5:	78 05                	js     62bc <fwp_main_thread+0x38c>
    62b7:	e8 f4 c1 ff ff       	call   24b0 <close@plt>
    62bc:	4c 8b 25 1d 40 01 00 	mov    0x1401d(%rip),%r12        # 1a2e0 <fwp_nfdws>
    62c3:	48 8b 2d 1e 40 01 00 	mov    0x1401e(%rip),%rbp        # 1a2e8 <fwp_fdws>
    62ca:	31 db                	xor    %ebx,%ebx
    62cc:	c7 05 7a 3d 00 00 ff 	movl   $0xffffffff,0x3d7a(%rip)        # a050 <fwp_epfd>
    62d3:	ff ff ff 
    62d6:	4d 85 e4             	test   %r12,%r12
    62d9:	74 32                	je     630d <fwp_main_thread+0x3dd>
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    62e5:	48 85 ff             	test   %rdi,%rdi
    62e8:	74 1a                	je     6304 <fwp_main_thread+0x3d4>
    62ea:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    62ee:	0f 85 17 c4 ff ff    	jne    270b <fwp_main_thread.cold>
    62f4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    62f9:	0f 85 0c c4 ff ff    	jne    270b <fwp_main_thread.cold>
    62ff:	e8 cc dc ff ff       	call   3fd0 <fwp_mem_free>
    6304:	48 83 c3 01          	add    $0x1,%rbx
    6308:	4c 39 e3             	cmp    %r12,%rbx
    630b:	75 d3                	jne    62e0 <fwp_main_thread+0x3b0>
    630d:	48 89 ef             	mov    %rbp,%rdi
    6310:	e8 bb dc ff ff       	call   3fd0 <fwp_mem_free>
    6315:	48 8b 15 dc 43 01 00 	mov    0x143dc(%rip),%rdx        # 1a6f8 <fwp_root>
    631c:	48 c7 05 c1 3f 01 00 	movq   $0x0,0x13fc1(%rip)        # 1a2e8 <fwp_fdws>
    6323:	00 00 00 00 
    6327:	48 c7 05 ae 3f 01 00 	movq   $0x0,0x13fae(%rip)        # 1a2e0 <fwp_nfdws>
    632e:	00 00 00 00 
    6332:	48 85 d2             	test   %rdx,%rdx
    6335:	74 4e                	je     6385 <fwp_main_thread+0x455>
    6337:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    633c:	0f 85 c9 c3 ff ff    	jne    270b <fwp_main_thread.cold>
    6342:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    6349:	00 
    634a:	0f 85 bb c3 ff ff    	jne    270b <fwp_main_thread.cold>
    6350:	48 83 3d 38 60 01 00 	cmpq   $0x0,0x16038(%rip)        # 1c390 <fwp_state_len>
    6357:	00 
    6358:	0f 85 ad c3 ff ff    	jne    270b <fwp_main_thread.cold>
    635e:	48 83 3d 1a 60 01 00 	cmpq   $0x0,0x1601a(%rip)        # 1c380 <fwp_state_owners>
    6365:	00 
    6366:	0f 85 9f c3 ff ff    	jne    270b <fwp_main_thread.cold>
    636c:	b9 79 00 00 00       	mov    $0x79,%ecx
    6371:	31 c0                	xor    %eax,%eax
    6373:	48 8d 3d 86 3f 01 00 	lea    0x13f86(%rip),%rdi        # 1a300 <fwp_root_context>
    637a:	f3 48 ab             	rep stos %rax,(%rdi)
    637d:	48 89 d7             	mov    %rdx,%rdi
    6380:	e8 4b dc ff ff       	call   3fd0 <fwp_mem_free>
    6385:	48 8b 3d d4 3c 00 00 	mov    0x3cd4(%rip),%rdi        # a060 <stdout@GLIBC_2.2.5>
    638c:	48 c7 05 69 43 01 00 	movq   $0x0,0x14369(%rip)        # 1a700 <fwp_cur>
    6393:	00 00 00 00 
    6397:	48 c7 05 56 43 01 00 	movq   $0x0,0x14356(%rip)        # 1a6f8 <fwp_root>
    639e:	00 00 00 00 
    63a2:	e8 e9 c1 ff ff       	call   2590 <fflush@plt>
    63a7:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    63ae:	00 
    63af:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    63b6:	00 00 
    63b8:	0f 85 28 14 00 00    	jne    77e6 <fwp_main_thread+0x18b6>
    63be:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    63c5:	31 c0                	xor    %eax,%eax
    63c7:	5b                   	pop    %rbx
    63c8:	5d                   	pop    %rbp
    63c9:	41 5c                	pop    %r12
    63cb:	41 5d                	pop    %r13
    63cd:	41 5e                	pop    %r14
    63cf:	41 5f                	pop    %r15
    63d1:	c3                   	ret
    63d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63d8:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    63df:	48 89 1d fa 42 01 00 	mov    %rbx,0x142fa(%rip)        # 1a6e0 <fwp_ready_tail>
    63e6:	e8 c5 e6 ff ff       	call   4ab0 <fwp_block>
    63eb:	e8 b0 e4 ff ff       	call   48a0 <fwp_free_zombie>
    63f0:	48 83 3d d0 42 01 00 	cmpq   $0x0,0x142d0(%rip)        # 1a6c8 <fwp_tasks_active>
    63f7:	00 
    63f8:	0f 84 48 fe ff ff    	je     6246 <fwp_main_thread+0x316>
    63fe:	48 8b 1d f3 42 01 00 	mov    0x142f3(%rip),%rbx        # 1a6f8 <fwp_root>
    6405:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    6409:	75 db                	jne    63e6 <fwp_main_thread+0x4b6>
    640b:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    640f:	75 d5                	jne    63e6 <fwp_main_thread+0x4b6>
    6411:	48 8b 05 c8 42 01 00 	mov    0x142c8(%rip),%rax        # 1a6e0 <fwp_ready_tail>
    6418:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    641c:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    6423:	00 00 00 00 
    6427:	48 85 c0             	test   %rax,%rax
    642a:	75 ac                	jne    63d8 <fwp_main_thread+0x4a8>
    642c:	48 89 1d b5 42 01 00 	mov    %rbx,0x142b5(%rip)        # 1a6e8 <fwp_ready_head>
    6433:	eb aa                	jmp    63df <fwp_main_thread+0x4af>
    6435:	0f 1f 00             	nopl   (%rax)
    6438:	e8 a3 cc ff ff       	call   30e0 <fwp_now_ns>
    643d:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    6441:	7c 1d                	jl     6460 <fwp_main_thread+0x530>
    6443:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    6447:	75 17                	jne    6460 <fwp_main_thread+0x530>
    6449:	48 89 ef             	mov    %rbp,%rdi
    644c:	e8 6f cb ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    6451:	0f 1f 40 00          	nopl   0x0(%rax)
    6455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    645c:	00 00 00 00 
    6460:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    6464:	0f 85 19 fc ff ff    	jne    6083 <fwp_main_thread+0x153>
    646a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    646e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    6472:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    6476:	0f 85 19 fc ff ff    	jne    6095 <fwp_main_thread+0x165>
    647c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    6480:	48 85 c9             	test   %rcx,%rcx
    6483:	0f 84 0c fc ff ff    	je     6095 <fwp_main_thread+0x165>
    6489:	48 39 c8             	cmp    %rcx,%rax
    648c:	48 89 ce             	mov    %rcx,%rsi
    648f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    6496:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    649a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    64a1:	00 00 00 00 
    64a5:	48 0f 4e f0          	cmovle %rax,%rsi
    64a9:	48 85 c0             	test   %rax,%rax
    64ac:	48 89 c8             	mov    %rcx,%rax
    64af:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    64b6:	48 0f 45 c6          	cmovne %rsi,%rax
    64ba:	48 85 d2             	test   %rdx,%rdx
    64bd:	74 07                	je     64c6 <fwp_main_thread+0x596>
    64bf:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    64c6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    64ca:	e9 f8 fb ff ff       	jmp    60c7 <fwp_main_thread+0x197>
    64cf:	90                   	nop
    64d0:	48 89 cb             	mov    %rcx,%rbx
    64d3:	e9 8b fb ff ff       	jmp    6063 <fwp_main_thread+0x133>
    64d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64df:	00 
    64e0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    64e4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    64eb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    64f2:	00 00 00 00 
    64f6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    64fd:	48 85 c0             	test   %rax,%rax
    6500:	0f 84 fa 0e 00 00    	je     7400 <fwp_main_thread+0x14d0>
    6506:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    650d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    6511:	e9 e5 fb ff ff       	jmp    60fb <fwp_main_thread+0x1cb>
    6516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    651d:	00 00 00 
    6520:	48 89 01             	mov    %rax,(%rcx)
    6523:	e9 0d fc ff ff       	jmp    6135 <fwp_main_thread+0x205>
    6528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    652f:	00 
    6530:	48 89 05 a1 41 01 00 	mov    %rax,0x141a1(%rip)        # 1a6d8 <fwp_timers>
    6537:	e9 4a fc ff ff       	jmp    6186 <fwp_main_thread+0x256>
    653c:	0f 1f 40 00          	nopl   0x0(%rax)
    6540:	48 8d 3d 99 d1 ff ff 	lea    -0x2e67(%rip),%rdi        # 36e0 <fwp_heap_report>
    6547:	e8 d4 14 00 00       	call   7a20 <atexit>
    654c:	e9 23 fa ff ff       	jmp    5f74 <fwp_main_thread+0x44>
    6551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6558:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    655d:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
    6562:	48 8d 05 67 e8 ff ff 	lea    -0x1799(%rip),%rax        # 4dd0 <fwp_drop1>
    6569:	41 bf 1f 00 00 00    	mov    $0x1f,%r15d
    656f:	66 48 0f 6e f8       	movq   %rax,%xmm7
    6574:	48 8b 05 35 5e 01 00 	mov    0x15e35(%rip),%rax        # 1c3b0 <fwp_cleanups>
    657b:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    6582:	00 00 
    6584:	4c 8d 2d 95 41 01 00 	lea    0x14195(%rip),%r13        # 1a720 <fwp_heap>
    658b:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    658f:	4c 89 25 1a 5e 01 00 	mov    %r12,0x15e1a(%rip)        # 1c3b0 <fwp_cleanups>
    6596:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    659b:	48 8d 05 ee c5 ff ff 	lea    -0x3a12(%rip),%rax        # 2b90 <fwp_range_release>
    65a2:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    65a7:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
    65ac:	eb 3b                	jmp    65e9 <fwp_main_thread+0x6b9>
    65ae:	66 90                	xchg   %ax,%ax
    65b0:	80 f9 01             	cmp    $0x1,%cl
    65b3:	75 29                	jne    65de <fwp_main_thread+0x6ae>
    65b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    65b8:	0f b7 c0             	movzwl %ax,%eax
    65bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65be:	48 0f af c1          	imul   %rcx,%rax
    65c2:	48 c1 e8 20          	shr    $0x20,%rax
    65c6:	48 39 d0             	cmp    %rdx,%rax
    65c9:	73 13                	jae    65de <fwp_main_thread+0x6ae>
    65cb:	49 01 c4             	add    %rax,%r12
    65ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    65d3:	0f 84 92 0e 00 00    	je     746b <fwp_main_thread+0x153b>
    65d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    65de:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
    65e3:	49 83 ef 01          	sub    $0x1,%r15
    65e7:	72 77                	jb     6660 <fwp_main_thread+0x730>
    65e9:	48 89 ef             	mov    %rbp,%rdi
    65ec:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
    65f3:	00 
    65f4:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
    65f9:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
    6600:	00 
    6601:	e8 6a e0 ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6606:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    660d:	48 89 c3             	mov    %rax,%rbx
    6610:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6617:	48 c1 e2 10          	shl    $0x10,%rdx
    661b:	48 39 d0             	cmp    %rdx,%rax
    661e:	73 be                	jae    65de <fwp_main_thread+0x6ae>
    6620:	48 89 c2             	mov    %rax,%rdx
    6623:	48 c1 ea 10          	shr    $0x10,%rdx
    6627:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    662b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6632:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6636:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    663a:	4d 85 e4             	test   %r12,%r12
    663d:	74 9f                	je     65de <fwp_main_thread+0x6ae>
    663f:	0f b6 0a             	movzbl (%rdx),%ecx
    6642:	80 f9 02             	cmp    $0x2,%cl
    6645:	0f 85 65 ff ff ff    	jne    65b0 <fwp_main_thread+0x680>
    664b:	66 85 c0             	test   %ax,%ax
    664e:	0f 84 7a ff ff ff    	je     65ce <fwp_main_thread+0x69e>
    6654:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
    6659:	49 83 ef 01          	sub    $0x1,%r15
    665d:	73 8a                	jae    65e9 <fwp_main_thread+0x6b9>
    665f:	90                   	nop
    6660:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6665:	66 0f 6f 05 63 1e 00 	movdqa 0x1e63(%rip),%xmm0        # 84d0 <msg.3+0x90>
    666c:	00 
    666d:	48 89 ef             	mov    %rbp,%rdi
    6670:	48 89 05 39 5d 01 00 	mov    %rax,0x15d39(%rip)        # 1c3b0 <fwp_cleanups>
    6677:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
    667e:	00 
    667f:	e8 ec df ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    6684:	48 8b 15 6d 54 01 00 	mov    0x1546d(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    668b:	49 89 c4             	mov    %rax,%r12
    668e:	48 2b 05 3b 54 01 00 	sub    0x1543b(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    6695:	48 c1 e2 10          	shl    $0x10,%rdx
    6699:	48 39 d0             	cmp    %rdx,%rax
    669c:	73 57                	jae    66f5 <fwp_main_thread+0x7c5>
    669e:	48 89 c2             	mov    %rax,%rdx
    66a1:	48 c1 ea 10          	shr    $0x10,%rdx
    66a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66a9:	48 8b 15 68 54 01 00 	mov    0x15468(%rip),%rdx        # 1bb18 <fwp_heap+0x13f8>
    66b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    66b4:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    66b8:	48 85 ed             	test   %rbp,%rbp
    66bb:	74 38                	je     66f5 <fwp_main_thread+0x7c5>
    66bd:	0f b6 0a             	movzbl (%rdx),%ecx
    66c0:	80 f9 02             	cmp    $0x2,%cl
    66c3:	0f 84 78 0d 00 00    	je     7441 <fwp_main_thread+0x1511>
    66c9:	80 f9 01             	cmp    $0x1,%cl
    66cc:	75 27                	jne    66f5 <fwp_main_thread+0x7c5>
    66ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    66d1:	0f b7 c0             	movzwl %ax,%eax
    66d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66d7:	48 0f af c1          	imul   %rcx,%rax
    66db:	48 c1 e8 20          	shr    $0x20,%rax
    66df:	48 39 d0             	cmp    %rdx,%rax
    66e2:	73 11                	jae    66f5 <fwp_main_thread+0x7c5>
    66e4:	48 01 c5             	add    %rax,%rbp
    66e7:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    66eb:	0f 84 57 10 00 00    	je     7748 <fwp_main_thread+0x1818>
    66f1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    66f5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    66fc:	00 
    66fd:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
    6704:	00 
    6705:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    670c:	00 f0 3f 
    670f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    6716:	00 
    6717:	e8 54 df ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    671c:	48 8b 15 d5 53 01 00 	mov    0x153d5(%rip),%rdx        # 1baf8 <fwp_heap+0x13d8>
    6723:	49 89 c4             	mov    %rax,%r12
    6726:	48 2b 05 a3 53 01 00 	sub    0x153a3(%rip),%rax        # 1bad0 <fwp_heap+0x13b0>
    672d:	48 c1 e2 10          	shl    $0x10,%rdx
    6731:	48 39 d0             	cmp    %rdx,%rax
    6734:	73 57                	jae    678d <fwp_main_thread+0x85d>
    6736:	48 89 c2             	mov    %rax,%rdx
    6739:	48 c1 ea 10          	shr    $0x10,%rdx
    673d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6741:	48 8b 15 d0 53 01 00 	mov    0x153d0(%rip),%rdx        # 1bb18 <fwp_heap+0x13f8>
    6748:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    674c:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6750:	48 85 ed             	test   %rbp,%rbp
    6753:	74 38                	je     678d <fwp_main_thread+0x85d>
    6755:	0f b6 0a             	movzbl (%rdx),%ecx
    6758:	80 f9 02             	cmp    $0x2,%cl
    675b:	0f 84 fc 0c 00 00    	je     745d <fwp_main_thread+0x152d>
    6761:	80 f9 01             	cmp    $0x1,%cl
    6764:	75 27                	jne    678d <fwp_main_thread+0x85d>
    6766:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6769:	0f b7 c0             	movzwl %ax,%eax
    676c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    676f:	48 0f af c1          	imul   %rcx,%rax
    6773:	48 c1 e8 20          	shr    $0x20,%rax
    6777:	48 39 d0             	cmp    %rdx,%rax
    677a:	73 11                	jae    678d <fwp_main_thread+0x85d>
    677c:	48 01 c5             	add    %rax,%rbp
    677f:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6783:	0f 84 cc 0f 00 00    	je     7755 <fwp_main_thread+0x1825>
    6789:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    678d:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    6794:	33 f3 bf 
    6797:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
    679c:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    67a1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    67a6:	e8 c5 de ff ff       	call   4670 <fwp_data.part.0.constprop.0>
    67ab:	48 8b 0d 46 53 01 00 	mov    0x15346(%rip),%rcx        # 1baf8 <fwp_heap+0x13d8>
    67b2:	48 8b 35 17 53 01 00 	mov    0x15317(%rip),%rsi        # 1bad0 <fwp_heap+0x13b0>
    67b9:	48 89 c2             	mov    %rax,%rdx
    67bc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    67c1:	48 89 cf             	mov    %rcx,%rdi
    67c4:	48 29 f2             	sub    %rsi,%rdx
    67c7:	48 c1 e7 10          	shl    $0x10,%rdi
    67cb:	48 39 fa             	cmp    %rdi,%rdx
    67ce:	73 69                	jae    6839 <fwp_main_thread+0x909>
    67d0:	48 89 d7             	mov    %rdx,%rdi
    67d3:	48 c1 ef 10          	shr    $0x10,%rdi
    67d7:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    67db:	48 8b 3d 36 53 01 00 	mov    0x15336(%rip),%rdi        # 1bb18 <fwp_heap+0x13f8>
    67e2:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    67e6:	48 8b 6f 20          	mov    0x20(%rdi),%rbp
    67ea:	48 85 ed             	test   %rbp,%rbp
    67ed:	74 4a                	je     6839 <fwp_main_thread+0x909>
    67ef:	44 0f b6 07          	movzbl (%rdi),%r8d
    67f3:	41 80 f8 02          	cmp    $0x2,%r8b
    67f7:	0f 84 52 0c 00 00    	je     744f <fwp_main_thread+0x151f>
    67fd:	41 80 f8 01          	cmp    $0x1,%r8b
    6801:	75 36                	jne    6839 <fwp_main_thread+0x909>
    6803:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    6807:	0f b7 d2             	movzwl %dx,%edx
    680a:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    680d:	49 0f af d0          	imul   %r8,%rdx
    6811:	48 c1 ea 20          	shr    $0x20,%rdx
    6815:	48 39 fa             	cmp    %rdi,%rdx
    6818:	73 1f                	jae    6839 <fwp_main_thread+0x909>
    681a:	48 01 d5             	add    %rdx,%rbp
    681d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6821:	0f 84 3b 0f 00 00    	je     7762 <fwp_main_thread+0x1832>
    6827:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    682b:	48 8b 35 9e 52 01 00 	mov    0x1529e(%rip),%rsi        # 1bad0 <fwp_heap+0x13b0>
    6832:	48 8b 0d bf 52 01 00 	mov    0x152bf(%rip),%rcx        # 1baf8 <fwp_heap+0x13d8>
    6839:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    683e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    6843:	66 90                	xchg   %ax,%ax
    6845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    684c:	00 00 00 00 
    6850:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6855:	48 c1 e1 10          	shl    $0x10,%rcx
    6859:	48 29 f0             	sub    %rsi,%rax
    685c:	48 39 c8             	cmp    %rcx,%rax
    685f:	73 5d                	jae    68be <fwp_main_thread+0x98e>
    6861:	48 89 c2             	mov    %rax,%rdx
    6864:	48 c1 ea 10          	shr    $0x10,%rdx
    6868:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    686c:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6873:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6877:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    687b:	48 85 db             	test   %rbx,%rbx
    687e:	74 3e                	je     68be <fwp_main_thread+0x98e>
    6880:	0f b6 0a             	movzbl (%rdx),%ecx
    6883:	80 f9 02             	cmp    $0x2,%cl
    6886:	0f 84 14 0b 00 00    	je     73a0 <fwp_main_thread+0x1470>
    688c:	80 f9 01             	cmp    $0x1,%cl
    688f:	75 2d                	jne    68be <fwp_main_thread+0x98e>
    6891:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6894:	0f b7 c0             	movzwl %ax,%eax
    6897:	8b 52 1c             	mov    0x1c(%rdx),%edx
    689a:	48 0f af c1          	imul   %rcx,%rax
    689e:	48 c1 e8 20          	shr    $0x20,%rax
    68a2:	48 39 d0             	cmp    %rdx,%rax
    68a5:	73 17                	jae    68be <fwp_main_thread+0x98e>
    68a7:	48 01 c3             	add    %rax,%rbx
    68aa:	0f b6 03             	movzbl (%rbx),%eax
    68ad:	84 c0                	test   %al,%al
    68af:	74 0d                	je     68be <fwp_main_thread+0x98e>
    68b1:	3c fd                	cmp    $0xfd,%al
    68b3:	0f 87 2f 0d 00 00    	ja     75e8 <fwp_main_thread+0x16b8>
    68b9:	83 c0 01             	add    $0x1,%eax
    68bc:	88 03                	mov    %al,(%rbx)
    68be:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    68c3:	31 ff                	xor    %edi,%edi
    68c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68cc:	00 00 00 00 
    68d0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    68d4:	48 83 c7 01          	add    $0x1,%rdi
    68d8:	48 85 db             	test   %rbx,%rbx
    68db:	75 f3                	jne    68d0 <fwp_main_thread+0x9a0>
    68dd:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    68e4:	ff ff 1f 
    68e7:	48 39 f8             	cmp    %rdi,%rax
    68ea:	0f 82 8b 0e 00 00    	jb     777b <fwp_main_thread+0x184b>
    68f0:	e8 8b de ff ff       	call   4780 <fwp_array_new_packed.constprop.0>
    68f5:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    68fc:	49 89 c4             	mov    %rax,%r12
    68ff:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6906:	48 c1 e2 10          	shl    $0x10,%rdx
    690a:	48 39 d0             	cmp    %rdx,%rax
    690d:	73 57                	jae    6966 <fwp_main_thread+0xa36>
    690f:	48 89 c2             	mov    %rax,%rdx
    6912:	48 c1 ea 10          	shr    $0x10,%rdx
    6916:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    691a:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6921:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6925:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6929:	48 85 ed             	test   %rbp,%rbp
    692c:	74 38                	je     6966 <fwp_main_thread+0xa36>
    692e:	0f b6 0a             	movzbl (%rdx),%ecx
    6931:	80 f9 02             	cmp    $0x2,%cl
    6934:	0f 84 3e 0a 00 00    	je     7378 <fwp_main_thread+0x1448>
    693a:	80 f9 01             	cmp    $0x1,%cl
    693d:	75 27                	jne    6966 <fwp_main_thread+0xa36>
    693f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6942:	0f b7 c0             	movzwl %ax,%eax
    6945:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6948:	48 0f af c1          	imul   %rcx,%rax
    694c:	48 c1 e8 20          	shr    $0x20,%rax
    6950:	48 39 d0             	cmp    %rdx,%rax
    6953:	73 11                	jae    6966 <fwp_main_thread+0xa36>
    6955:	48 01 c5             	add    %rax,%rbp
    6958:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    695c:	0f 84 29 0a 00 00    	je     738b <fwp_main_thread+0x145b>
    6962:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6966:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    696b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    6971:	49 8b 71 08          	mov    0x8(%r9),%rsi
    6975:	49 8b 69 10          	mov    0x10(%r9),%rbp
    6979:	4d 89 ca             	mov    %r9,%r10
    697c:	4c 89 c9             	mov    %r9,%rcx
    697f:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6986:	48 89 c8             	mov    %rcx,%rax
    6989:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6990:	48 c1 e2 10          	shl    $0x10,%rdx
    6994:	48 39 d0             	cmp    %rdx,%rax
    6997:	73 73                	jae    6a0c <fwp_main_thread+0xadc>
    6999:	48 89 c2             	mov    %rax,%rdx
    699c:	48 c1 ea 10          	shr    $0x10,%rdx
    69a0:	48 8d 3c 92          	lea    (%rdx,%rdx,4),%rdi
    69a4:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    69ab:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
    69af:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    69b3:	48 85 ff             	test   %rdi,%rdi
    69b6:	74 54                	je     6a0c <fwp_main_thread+0xadc>
    69b8:	44 0f b6 02          	movzbl (%rdx),%r8d
    69bc:	41 80 f8 02          	cmp    $0x2,%r8b
    69c0:	0f 84 4a 05 00 00    	je     6f10 <fwp_main_thread+0xfe0>
    69c6:	41 80 f8 01          	cmp    $0x1,%r8b
    69ca:	75 40                	jne    6a0c <fwp_main_thread+0xadc>
    69cc:	44 8b 42 18          	mov    0x18(%rdx),%r8d
    69d0:	0f b7 c0             	movzwl %ax,%eax
    69d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69d6:	49 0f af c0          	imul   %r8,%rax
    69da:	48 c1 e8 20          	shr    $0x20,%rax
    69de:	48 39 d0             	cmp    %rdx,%rax
    69e1:	73 29                	jae    6a0c <fwp_main_thread+0xadc>
    69e3:	48 01 c7             	add    %rax,%rdi
    69e6:	80 3f 01             	cmpb   $0x1,(%rdi)
    69e9:	75 21                	jne    6a0c <fwp_main_thread+0xadc>
    69eb:	e9 68 04 00 00       	jmp    6e58 <fwp_main_thread+0xf28>
    69f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    69fc:	00 00 00 00 
    6a00:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    6a04:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6a08:	49 83 c7 01          	add    $0x1,%r15
    6a0c:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    6a11:	0f 88 58 0d 00 00    	js     776f <fwp_main_thread+0x183f>
    6a17:	4b 89 34 fc          	mov    %rsi,(%r12,%r15,8)
    6a1b:	48 85 ed             	test   %rbp,%rbp
    6a1e:	75 e0                	jne    6a00 <fwp_main_thread+0xad0>
    6a20:	4c 89 cf             	mov    %r9,%rdi
    6a23:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    6a29:	e8 32 e2 ff ff       	call   4c60 <fwp_drop0>
    6a2e:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    6a33:	31 c0                	xor    %eax,%eax
    6a35:	48 85 c0             	test   %rax,%rax
    6a38:	0f 85 d2 bc ff ff    	jne    2710 <fwp_main_thread.cold+0x5>
    6a3e:	48 bb ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rbx
    6a45:	ff ff 7f 
    6a48:	49 23 1c 24          	and    (%r12),%rbx
    6a4c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    6a53:	ff ff 1f 
    6a56:	48 39 d8             	cmp    %rbx,%rax
    6a59:	0f 82 1c 0d 00 00    	jb     777b <fwp_main_thread+0x184b>
    6a5f:	48 89 df             	mov    %rbx,%rdi
    6a62:	e8 19 dd ff ff       	call   4780 <fwp_array_new_packed.constprop.0>
    6a67:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6a6e:	48 89 c5             	mov    %rax,%rbp
    6a71:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6a78:	48 c1 e2 10          	shl    $0x10,%rdx
    6a7c:	48 39 d0             	cmp    %rdx,%rax
    6a7f:	73 57                	jae    6ad8 <fwp_main_thread+0xba8>
    6a81:	48 89 c2             	mov    %rax,%rdx
    6a84:	48 c1 ea 10          	shr    $0x10,%rdx
    6a88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a8c:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6a93:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a97:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a9b:	48 85 d2             	test   %rdx,%rdx
    6a9e:	74 38                	je     6ad8 <fwp_main_thread+0xba8>
    6aa0:	0f b6 31             	movzbl (%rcx),%esi
    6aa3:	40 80 fe 02          	cmp    $0x2,%sil
    6aa7:	0f 84 13 08 00 00    	je     72c0 <fwp_main_thread+0x1390>
    6aad:	40 80 fe 01          	cmp    $0x1,%sil
    6ab1:	75 25                	jne    6ad8 <fwp_main_thread+0xba8>
    6ab3:	8b 71 18             	mov    0x18(%rcx),%esi
    6ab6:	0f b7 c0             	movzwl %ax,%eax
    6ab9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6abc:	48 0f af c6          	imul   %rsi,%rax
    6ac0:	48 c1 e8 20          	shr    $0x20,%rax
    6ac4:	48 39 c8             	cmp    %rcx,%rax
    6ac7:	73 0f                	jae    6ad8 <fwp_main_thread+0xba8>
    6ac9:	48 01 c2             	add    %rax,%rdx
    6acc:	80 3a ff             	cmpb   $0xff,(%rdx)
    6acf:	0f 84 fd 07 00 00    	je     72d2 <fwp_main_thread+0x13a2>
    6ad5:	c6 02 01             	movb   $0x1,(%rdx)
    6ad8:	48 85 db             	test   %rbx,%rbx
    6adb:	0f 84 4f 01 00 00    	je     6c30 <fwp_main_thread+0xd00>
    6ae1:	4d 8d 5c 24 08       	lea    0x8(%r12),%r11
    6ae6:	49 8b 14 24          	mov    (%r12),%rdx
    6aea:	31 c9                	xor    %ecx,%ecx
    6aec:	31 c0                	xor    %eax,%eax
    6aee:	4d 89 d9             	mov    %r11,%r9
    6af1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6af5:	be 01 00 00 00       	mov    $0x1,%esi
    6afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b00:	48 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdi
    6b07:	ff ff 7f 
    6b0a:	48 21 d7             	and    %rdx,%rdi
    6b0d:	48 39 f7             	cmp    %rsi,%rdi
    6b10:	0f 84 02 01 00 00    	je     6c18 <fwp_main_thread+0xce8>
    6b16:	48 39 f9             	cmp    %rdi,%rcx
    6b19:	0f 83 02 01 00 00    	jae    6c21 <fwp_main_thread+0xcf1>
    6b1f:	48 85 d2             	test   %rdx,%rdx
    6b22:	0f 88 18 07 00 00    	js     7240 <fwp_main_thread+0x1310>
    6b28:	48 39 fe             	cmp    %rdi,%rsi
    6b2b:	0f 83 f0 00 00 00    	jae    6c21 <fwp_main_thread+0xcf1>
    6b31:	f2 41 0f 10 11       	movsd  (%r9),%xmm2
    6b36:	f2 0f 10 1d b2 19 00 	movsd  0x19b2(%rip),%xmm3        # 84f0 <msg.3+0xb0>
    6b3d:	00 
    6b3e:	4c 89 df             	mov    %r11,%rdi
    6b41:	f2 0f 10 25 af 19 00 	movsd  0x19af(%rip),%xmm4        # 84f8 <msg.3+0xb8>
    6b48:	00 
    6b49:	f2 0f 5c da          	subsd  %xmm2,%xmm3
    6b4d:	f2 0f 59 e2          	mulsd  %xmm2,%xmm4
    6b51:	f2 0f 59 d2          	mulsd  %xmm2,%xmm2
    6b55:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    6b59:	f3 0f 7e 44 07 08    	movq   0x8(%rdi,%rax,1),%xmm0
    6b5f:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    6b63:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
    6b67:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    6b6b:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6b6f:	f2 0f 59 05 89 19 00 	mulsd  0x1989(%rip),%xmm0        # 8500 <msg.3+0xc0>
    6b76:	00 
    6b77:	4c 89 df             	mov    %r11,%rdi
    6b7a:	48 85 d2             	test   %rdx,%rdx
    6b7d:	0f 88 7d 03 00 00    	js     6f00 <fwp_main_thread+0xfd0>
    6b83:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6b88:	0f 88 e1 0b 00 00    	js     776f <fwp_main_thread+0x183f>
    6b8e:	f3 0f 7e 0c 07       	movq   (%rdi,%rax,1),%xmm1
    6b93:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    6b97:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6b9b:	f2 0f 11 4c 05 08    	movsd  %xmm1,0x8(%rbp,%rax,1)
    6ba1:	48 39 fb             	cmp    %rdi,%rbx
    6ba4:	0f 84 86 00 00 00    	je     6c30 <fwp_main_thread+0xd00>
    6baa:	49 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r10
    6bb1:	ff ff 7f 
    6bb4:	49 8b 14 24          	mov    (%r12),%rdx
    6bb8:	49 21 d2             	and    %rdx,%r10
    6bbb:	4c 39 d1             	cmp    %r10,%rcx
    6bbe:	73 61                	jae    6c21 <fwp_main_thread+0xcf1>
    6bc0:	4c 8d 40 08          	lea    0x8(%rax),%r8
    6bc4:	48 85 d2             	test   %rdx,%rdx
    6bc7:	0f 88 53 06 00 00    	js     7220 <fwp_main_thread+0x12f0>
    6bcd:	4c 39 d7             	cmp    %r10,%rdi
    6bd0:	73 4f                	jae    6c21 <fwp_main_thread+0xcf1>
    6bd2:	f2 41 0f 10 44 04 08 	movsd  0x8(%r12,%rax,1),%xmm0
    6bd9:	4c 89 d9             	mov    %r11,%rcx
    6bdc:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6be0:	f3 42 0f 7e 0c 01    	movq   (%rcx,%r8,1),%xmm1
    6be6:	48 83 c6 01          	add    $0x1,%rsi
    6bea:	49 83 c1 08          	add    $0x8,%r9
    6bee:	48 89 f9             	mov    %rdi,%rcx
    6bf1:	4c 89 c0             	mov    %r8,%rax
    6bf4:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6bf8:	f2 0f 59 0d e8 18 00 	mulsd  0x18e8(%rip),%xmm1        # 84e8 <msg.3+0xa8>
    6bff:	00 
    6c00:	e9 fb fe ff ff       	jmp    6b00 <fwp_main_thread+0xbd0>
    6c05:	0f 1f 00             	nopl   (%rax)
    6c08:	e8 e3 cb ff ff       	call   37f0 <fwp_heap_init>
    6c0d:	e9 54 f3 ff ff       	jmp    5f66 <fwp_main_thread+0x36>
    6c12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c18:	48 39 f1             	cmp    %rsi,%rcx
    6c1b:	0f 82 a4 0b 00 00    	jb     77c5 <fwp_main_thread+0x1895>
    6c21:	48 8d 3d 00 34 00 00 	lea    0x3400(%rip),%rdi        # a028 <s0+0x8>
    6c28:	e8 83 c4 ff ff       	call   30b0 <fwp_trap>
    6c2d:	0f 1f 00             	nopl   (%rax)
    6c30:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6c37:	4c 89 e0             	mov    %r12,%rax
    6c3a:	4c 89 e7             	mov    %r12,%rdi
    6c3d:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6c44:	48 c1 e2 10          	shl    $0x10,%rdx
    6c48:	48 39 d0             	cmp    %rdx,%rax
    6c4b:	73 73                	jae    6cc0 <fwp_main_thread+0xd90>
    6c4d:	48 89 c2             	mov    %rax,%rdx
    6c50:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    6c57:	48 c1 ea 10          	shr    $0x10,%rdx
    6c5b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6c5f:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6c63:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6c67:	48 85 db             	test   %rbx,%rbx
    6c6a:	74 54                	je     6cc0 <fwp_main_thread+0xd90>
    6c6c:	0f b6 32             	movzbl (%rdx),%esi
    6c6f:	40 80 fe 02          	cmp    $0x2,%sil
    6c73:	0f 84 07 06 00 00    	je     7280 <fwp_main_thread+0x1350>
    6c79:	40 80 fe 01          	cmp    $0x1,%sil
    6c7d:	75 41                	jne    6cc0 <fwp_main_thread+0xd90>
    6c7f:	8b 72 18             	mov    0x18(%rdx),%esi
    6c82:	0f b7 c0             	movzwl %ax,%eax
    6c85:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c88:	48 0f af c6          	imul   %rsi,%rax
    6c8c:	48 c1 e8 20          	shr    $0x20,%rax
    6c90:	48 39 d0             	cmp    %rdx,%rax
    6c93:	73 2b                	jae    6cc0 <fwp_main_thread+0xd90>
    6c95:	48 01 c3             	add    %rax,%rbx
    6c98:	0f b6 03             	movzbl (%rbx),%eax
    6c9b:	84 c0                	test   %al,%al
    6c9d:	74 21                	je     6cc0 <fwp_main_thread+0xd90>
    6c9f:	3c 01                	cmp    $0x1,%al
    6ca1:	0f 84 f9 00 00 00    	je     6da0 <fwp_main_thread+0xe70>
    6ca7:	3c ff                	cmp    $0xff,%al
    6ca9:	0f 84 c9 07 00 00    	je     7478 <fwp_main_thread+0x1548>
    6caf:	83 e8 01             	sub    $0x1,%eax
    6cb2:	88 03                	mov    %al,(%rbx)
    6cb4:	90                   	nop
    6cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cbc:	00 00 00 00 
    6cc0:	4d 85 ff             	test   %r15,%r15
    6cc3:	0f 85 77 01 00 00    	jne    6e40 <fwp_main_thread+0xf10>
    6cc9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ccd:	be 01 00 00 00       	mov    $0x1,%esi
    6cd2:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    6cd6:	4c 89 f7             	mov    %r14,%rdi
    6cd9:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
    6ce0:	00 00 
    6ce2:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    6ce7:	49 bc ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r12
    6cee:	ff ff 7f 
    6cf1:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    6cf6:	e8 c5 c1 ff ff       	call   2ec0 <buf_grow>
    6cfb:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6d00:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    6d05:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    6d09:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6d0e:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6d12:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    6d17:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    6d1c:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6d21:	4c 23 65 00          	and    0x0(%rbp),%r12
    6d25:	75 60                	jne    6d87 <fwp_main_thread+0xe57>
    6d27:	e9 f4 01 00 00       	jmp    6f20 <fwp_main_thread+0xff0>
    6d2c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d30:	48 8b 34 d8          	mov    (%rax,%rbx,8),%rsi
    6d34:	48 8d 15 85 2e 00 00 	lea    0x2e85(%rip),%rdx        # 9bc0 <d0>
    6d3b:	4c 89 f7             	mov    %r14,%rdi
    6d3e:	48 83 c3 01          	add    $0x1,%rbx
    6d42:	e8 e9 e1 ff ff       	call   4f30 <fwp_write.constprop.0>
    6d47:	49 39 dc             	cmp    %rbx,%r12
    6d4a:	0f 84 d0 01 00 00    	je     6f20 <fwp_main_thread+0xff0>
    6d50:	be 02 00 00 00       	mov    $0x2,%esi
    6d55:	4c 89 f7             	mov    %r14,%rdi
    6d58:	e8 63 c1 ff ff       	call   2ec0 <buf_grow>
    6d5d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6d62:	ba 2c 20 00 00       	mov    $0x202c,%edx
    6d67:	48 03 44 24 50       	add    0x50(%rsp),%rax
    6d6c:	66 89 10             	mov    %dx,(%rax)
    6d6f:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6d74:	48 8d 50 02          	lea    0x2(%rax),%rdx
    6d78:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    6d7d:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    6d82:	c6 44 02 02 00       	movb   $0x0,0x2(%rdx,%rax,1)
    6d87:	4c 89 f8             	mov    %r15,%rax
    6d8a:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6d8f:	79 9f                	jns    6d30 <fwp_main_thread+0xe00>
    6d91:	48 8b 45 10          	mov    0x10(%rbp),%rax
    6d95:	eb 99                	jmp    6d30 <fwp_main_thread+0xe00>
    6d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d9e:	00 00 
    6da0:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    6da4:	0f 88 e6 04 00 00    	js     7290 <fwp_main_thread+0x1360>
    6daa:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6db1:	48 89 f8             	mov    %rdi,%rax
    6db4:	49 89 fc             	mov    %rdi,%r12
    6db7:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6dbe:	48 c1 e2 10          	shl    $0x10,%rdx
    6dc2:	48 39 d0             	cmp    %rdx,%rax
    6dc5:	0f 83 f5 fe ff ff    	jae    6cc0 <fwp_main_thread+0xd90>
    6dcb:	48 89 c2             	mov    %rax,%rdx
    6dce:	48 c1 ea 10          	shr    $0x10,%rdx
    6dd2:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6dd6:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6dda:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6dde:	48 85 c9             	test   %rcx,%rcx
    6de1:	0f 84 d9 fe ff ff    	je     6cc0 <fwp_main_thread+0xd90>
    6de7:	0f b6 32             	movzbl (%rdx),%esi
    6dea:	40 80 fe 02          	cmp    $0x2,%sil
    6dee:	0f 84 0c 05 00 00    	je     7300 <fwp_main_thread+0x13d0>
    6df4:	40 80 fe 01          	cmp    $0x1,%sil
    6df8:	0f 85 c2 fe ff ff    	jne    6cc0 <fwp_main_thread+0xd90>
    6dfe:	8b 72 18             	mov    0x18(%rdx),%esi
    6e01:	0f b7 c0             	movzwl %ax,%eax
    6e04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e07:	48 0f af c6          	imul   %rsi,%rax
    6e0b:	48 c1 e8 20          	shr    $0x20,%rax
    6e0f:	48 39 d0             	cmp    %rdx,%rax
    6e12:	0f 83 a8 fe ff ff    	jae    6cc0 <fwp_main_thread+0xd90>
    6e18:	48 01 c1             	add    %rax,%rcx
    6e1b:	80 39 01             	cmpb   $0x1,(%rcx)
    6e1e:	0f 85 9c fe ff ff    	jne    6cc0 <fwp_main_thread+0xd90>
    6e24:	4c 89 e7             	mov    %r12,%rdi
    6e27:	e8 a4 d1 ff ff       	call   3fd0 <fwp_mem_free>
    6e2c:	4d 85 ff             	test   %r15,%r15
    6e2f:	0f 84 94 fe ff ff    	je     6cc9 <fwp_main_thread+0xd99>
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	31 c0                	xor    %eax,%eax
    6e42:	49 83 ef 01          	sub    $0x1,%r15
    6e46:	49 89 ec             	mov    %rbp,%r12
    6e49:	0f 90 c0             	seto   %al
    6e4c:	e9 e4 fb ff ff       	jmp    6a35 <fwp_main_thread+0xb05>
    6e51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e58:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    6e5d:	0f 88 0c 09 00 00    	js     776f <fwp_main_thread+0x183f>
    6e63:	4b 89 34 fc          	mov    %rsi,(%r12,%r15,8)
    6e67:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    6e6e:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    6e75:	48 c1 e0 10          	shl    $0x10,%rax
    6e79:	48 39 c1             	cmp    %rax,%rcx
    6e7c:	73 58                	jae    6ed6 <fwp_main_thread+0xfa6>
    6e7e:	48 89 c8             	mov    %rcx,%rax
    6e81:	48 c1 e8 10          	shr    $0x10,%rax
    6e85:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6e89:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    6e90:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6e94:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6e98:	48 85 d2             	test   %rdx,%rdx
    6e9b:	74 39                	je     6ed6 <fwp_main_thread+0xfa6>
    6e9d:	0f b6 30             	movzbl (%rax),%esi
    6ea0:	40 80 fe 02          	cmp    $0x2,%sil
    6ea4:	0f 84 66 04 00 00    	je     7310 <fwp_main_thread+0x13e0>
    6eaa:	40 80 fe 01          	cmp    $0x1,%sil
    6eae:	75 26                	jne    6ed6 <fwp_main_thread+0xfa6>
    6eb0:	8b 70 18             	mov    0x18(%rax),%esi
    6eb3:	0f b7 c9             	movzwl %cx,%ecx
    6eb6:	8b 40 1c             	mov    0x1c(%rax),%eax
    6eb9:	48 0f af ce          	imul   %rsi,%rcx
    6ebd:	48 c1 e9 20          	shr    $0x20,%rcx
    6ec1:	48 39 c1             	cmp    %rax,%rcx
    6ec4:	73 10                	jae    6ed6 <fwp_main_thread+0xfa6>
    6ec6:	48 01 ca             	add    %rcx,%rdx
    6ec9:	80 3a 01             	cmpb   $0x1,(%rdx)
    6ecc:	75 08                	jne    6ed6 <fwp_main_thread+0xfa6>
    6ece:	4c 89 d7             	mov    %r10,%rdi
    6ed1:	e8 fa d0 ff ff       	call   3fd0 <fwp_mem_free>
    6ed6:	48 85 ed             	test   %rbp,%rbp
    6ed9:	0f 84 43 04 00 00    	je     7322 <fwp_main_thread+0x13f2>
    6edf:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    6ee3:	49 89 ea             	mov    %rbp,%r10
    6ee6:	48 89 e9             	mov    %rbp,%rcx
    6ee9:	49 89 e9             	mov    %rbp,%r9
    6eec:	49 83 c7 01          	add    $0x1,%r15
    6ef0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6ef4:	e9 86 fa ff ff       	jmp    697f <fwp_main_thread+0xa4f>
    6ef9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f00:	49 8b 7c 24 10       	mov    0x10(%r12),%rdi
    6f05:	e9 79 fc ff ff       	jmp    6b83 <fwp_main_thread+0xc53>
    6f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f10:	66 85 c0             	test   %ax,%ax
    6f13:	0f 85 f3 fa ff ff    	jne    6a0c <fwp_main_thread+0xadc>
    6f19:	e9 c8 fa ff ff       	jmp    69e6 <fwp_main_thread+0xab6>
    6f1e:	66 90                	xchg   %ax,%ax
    6f20:	be 01 00 00 00       	mov    $0x1,%esi
    6f25:	4c 89 f7             	mov    %r14,%rdi
    6f28:	e8 93 bf ff ff       	call   2ec0 <buf_grow>
    6f2d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6f32:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    6f37:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    6f3b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    6f40:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6f44:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    6f49:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    6f4e:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6f53:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    6f58:	48 8d 05 cf 10 00 00 	lea    0x10cf(%rip),%rax        # 802e <_IO_stdin_used+0x2e>
    6f5f:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
    6f64:	48 85 c9             	test   %rcx,%rcx
    6f67:	48 0f 44 c8          	cmove  %rax,%rcx
    6f6b:	48 83 fb f6          	cmp    $0xfffffffffffffff6,%rbx
    6f6f:	0f 87 65 08 00 00    	ja     77da <fwp_main_thread+0x18aa>
    6f75:	48 8d 7b 09          	lea    0x9(%rbx),%rdi
    6f79:	be 01 00 00 00       	mov    $0x1,%esi
    6f7e:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6f83:	e8 c8 d5 ff ff       	call   4550 <fwp_heap_alloc>
    6f88:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
    6f8d:	48 89 da             	mov    %rbx,%rdx
    6f90:	48 89 18             	mov    %rbx,(%rax)
    6f93:	4c 8d 78 08          	lea    0x8(%rax),%r15
    6f97:	49 89 c4             	mov    %rax,%r12
    6f9a:	4c 89 ff             	mov    %r15,%rdi
    6f9d:	e8 ce b5 ff ff       	call   2570 <memcpy@plt>
    6fa2:	41 c6 44 1c 08 00    	movb   $0x0,0x8(%r12,%rbx,1)
    6fa8:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
    6fad:	e8 ee b3 ff ff       	call   23a0 <free@plt>
    6fb2:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    6fb9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6fc0:	4c 89 e0             	mov    %r12,%rax
    6fc3:	48 29 c8             	sub    %rcx,%rax
    6fc6:	48 c1 e2 10          	shl    $0x10,%rdx
    6fca:	48 39 d0             	cmp    %rdx,%rax
    6fcd:	73 6b                	jae    703a <fwp_main_thread+0x110a>
    6fcf:	48 89 c6             	mov    %rax,%rsi
    6fd2:	48 c1 ee 10          	shr    $0x10,%rsi
    6fd6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6fda:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    6fe1:	48 8d 3c fe          	lea    (%rsi,%rdi,8),%rdi
    6fe5:	48 8b 77 20          	mov    0x20(%rdi),%rsi
    6fe9:	48 85 f6             	test   %rsi,%rsi
    6fec:	74 4c                	je     703a <fwp_main_thread+0x110a>
    6fee:	44 0f b6 07          	movzbl (%rdi),%r8d
    6ff2:	41 80 f8 02          	cmp    $0x2,%r8b
    6ff6:	0f 84 b4 03 00 00    	je     73b0 <fwp_main_thread+0x1480>
    6ffc:	41 80 f8 01          	cmp    $0x1,%r8b
    7000:	75 38                	jne    703a <fwp_main_thread+0x110a>
    7002:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    7006:	0f b7 c0             	movzwl %ax,%eax
    7009:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    700c:	49 0f af c0          	imul   %r8,%rax
    7010:	48 c1 e8 20          	shr    $0x20,%rax
    7014:	48 39 f8             	cmp    %rdi,%rax
    7017:	73 21                	jae    703a <fwp_main_thread+0x110a>
    7019:	48 01 c6             	add    %rax,%rsi
    701c:	80 3e ff             	cmpb   $0xff,(%rsi)
    701f:	0f 84 9d 03 00 00    	je     73c2 <fwp_main_thread+0x1492>
    7025:	c6 06 01             	movb   $0x1,(%rsi)
    7028:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    702f:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    7036:	48 c1 e2 10          	shl    $0x10,%rdx
    703a:	48 89 e8             	mov    %rbp,%rax
    703d:	48 29 c8             	sub    %rcx,%rax
    7040:	48 39 d0             	cmp    %rdx,%rax
    7043:	73 6b                	jae    70b0 <fwp_main_thread+0x1180>
    7045:	48 89 c2             	mov    %rax,%rdx
    7048:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    704f:	48 c1 ea 10          	shr    $0x10,%rdx
    7053:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7057:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    705b:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    705f:	48 85 d2             	test   %rdx,%rdx
    7062:	74 4c                	je     70b0 <fwp_main_thread+0x1180>
    7064:	0f b6 3e             	movzbl (%rsi),%edi
    7067:	40 80 ff 02          	cmp    $0x2,%dil
    706b:	0f 84 bf 02 00 00    	je     7330 <fwp_main_thread+0x1400>
    7071:	40 80 ff 01          	cmp    $0x1,%dil
    7075:	75 39                	jne    70b0 <fwp_main_thread+0x1180>
    7077:	8b 7e 18             	mov    0x18(%rsi),%edi
    707a:	0f b7 c0             	movzwl %ax,%eax
    707d:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7080:	48 0f af c7          	imul   %rdi,%rax
    7084:	48 c1 e8 20          	shr    $0x20,%rax
    7088:	48 39 f0             	cmp    %rsi,%rax
    708b:	73 23                	jae    70b0 <fwp_main_thread+0x1180>
    708d:	48 01 c2             	add    %rax,%rdx
    7090:	0f b6 02             	movzbl (%rdx),%eax
    7093:	84 c0                	test   %al,%al
    7095:	74 19                	je     70b0 <fwp_main_thread+0x1180>
    7097:	3c 01                	cmp    $0x1,%al
    7099:	0f 84 f1 00 00 00    	je     7190 <fwp_main_thread+0x1260>
    709f:	3c ff                	cmp    $0xff,%al
    70a1:	0f 84 57 04 00 00    	je     74fe <fwp_main_thread+0x15ce>
    70a7:	83 e8 01             	sub    $0x1,%eax
    70aa:	88 02                	mov    %al,(%rdx)
    70ac:	0f 1f 40 00          	nopl   0x0(%rax)
    70b0:	49 8b 14 24          	mov    (%r12),%rdx
    70b4:	48 8b 0d bd 52 01 00 	mov    0x152bd(%rip),%rcx        # 1c378 <fwp_prog_out>
    70bb:	be 01 00 00 00       	mov    $0x1,%esi
    70c0:	4c 89 ff             	mov    %r15,%rdi
    70c3:	e8 78 b5 ff ff       	call   2640 <fwrite@plt>
    70c8:	48 8b 35 a9 52 01 00 	mov    0x152a9(%rip),%rsi        # 1c378 <fwp_prog_out>
    70cf:	bf 0a 00 00 00       	mov    $0xa,%edi
    70d4:	e8 e7 b3 ff ff       	call   24c0 <fputc@plt>
    70d9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    70e0:	4c 89 e0             	mov    %r12,%rax
    70e3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    70ea:	48 c1 e2 10          	shl    $0x10,%rdx
    70ee:	48 39 d0             	cmp    %rdx,%rax
    70f1:	73 6d                	jae    7160 <fwp_main_thread+0x1230>
    70f3:	48 89 c2             	mov    %rax,%rdx
    70f6:	48 c1 ea 10          	shr    $0x10,%rdx
    70fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70fe:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    7105:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7109:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    710d:	48 85 db             	test   %rbx,%rbx
    7110:	74 4e                	je     7160 <fwp_main_thread+0x1230>
    7112:	0f b6 0a             	movzbl (%rdx),%ecx
    7115:	80 f9 02             	cmp    $0x2,%cl
    7118:	0f 84 c2 02 00 00    	je     73e0 <fwp_main_thread+0x14b0>
    711e:	80 f9 01             	cmp    $0x1,%cl
    7121:	75 3d                	jne    7160 <fwp_main_thread+0x1230>
    7123:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7126:	0f b7 c0             	movzwl %ax,%eax
    7129:	8b 52 1c             	mov    0x1c(%rdx),%edx
    712c:	48 0f af c1          	imul   %rcx,%rax
    7130:	48 c1 e8 20          	shr    $0x20,%rax
    7134:	48 39 d0             	cmp    %rdx,%rax
    7137:	73 27                	jae    7160 <fwp_main_thread+0x1230>
    7139:	48 01 c3             	add    %rax,%rbx
    713c:	0f b6 03             	movzbl (%rbx),%eax
    713f:	84 c0                	test   %al,%al
    7141:	74 1d                	je     7160 <fwp_main_thread+0x1230>
    7143:	3c 01                	cmp    $0x1,%al
    7145:	0f 84 a5 01 00 00    	je     72f0 <fwp_main_thread+0x13c0>
    714b:	3c ff                	cmp    $0xff,%al
    714d:	0f 84 05 05 00 00    	je     7658 <fwp_main_thread+0x1728>
    7153:	83 e8 01             	sub    $0x1,%eax
    7156:	88 03                	mov    %al,(%rbx)
    7158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    715f:	00 
    7160:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    7165:	48 8b 40 10          	mov    0x10(%rax),%rax
    7169:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    716e:	48 85 c0             	test   %rax,%rax
    7171:	0f 84 99 02 00 00    	je     7410 <fwp_main_thread+0x14e0>
    7177:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    717e:	49 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%rcx
    7185:	e9 c6 f6 ff ff       	jmp    6850 <fwp_main_thread+0x920>
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    7195:	0f 88 a5 01 00 00    	js     7340 <fwp_main_thread+0x1410>
    719b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    71a2:	48 89 e8             	mov    %rbp,%rax
    71a5:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    71ac:	48 c1 e2 10          	shl    $0x10,%rdx
    71b0:	48 39 d0             	cmp    %rdx,%rax
    71b3:	0f 83 f7 fe ff ff    	jae    70b0 <fwp_main_thread+0x1180>
    71b9:	48 89 c2             	mov    %rax,%rdx
    71bc:	48 c1 ea 10          	shr    $0x10,%rdx
    71c0:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    71c4:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    71c8:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    71cc:	48 85 c9             	test   %rcx,%rcx
    71cf:	0f 84 db fe ff ff    	je     70b0 <fwp_main_thread+0x1180>
    71d5:	0f b6 32             	movzbl (%rdx),%esi
    71d8:	40 80 fe 02          	cmp    $0x2,%sil
    71dc:	0f 84 0e 02 00 00    	je     73f0 <fwp_main_thread+0x14c0>
    71e2:	40 80 fe 01          	cmp    $0x1,%sil
    71e6:	0f 85 c4 fe ff ff    	jne    70b0 <fwp_main_thread+0x1180>
    71ec:	8b 72 18             	mov    0x18(%rdx),%esi
    71ef:	0f b7 c0             	movzwl %ax,%eax
    71f2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71f5:	48 0f af c6          	imul   %rsi,%rax
    71f9:	48 c1 e8 20          	shr    $0x20,%rax
    71fd:	48 39 d0             	cmp    %rdx,%rax
    7200:	0f 83 aa fe ff ff    	jae    70b0 <fwp_main_thread+0x1180>
    7206:	48 01 c1             	add    %rax,%rcx
    7209:	80 39 01             	cmpb   $0x1,(%rcx)
    720c:	0f 85 9e fe ff ff    	jne    70b0 <fwp_main_thread+0x1180>
    7212:	48 89 ef             	mov    %rbp,%rdi
    7215:	e8 b6 cd ff ff       	call   3fd0 <fwp_mem_free>
    721a:	e9 91 fe ff ff       	jmp    70b0 <fwp_main_thread+0x1180>
    721f:	90                   	nop
    7220:	4c 39 d7             	cmp    %r10,%rdi
    7223:	0f 83 f8 f9 ff ff    	jae    6c21 <fwp_main_thread+0xcf1>
    7229:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    722e:	f2 0f 10 04 01       	movsd  (%rcx,%rax,1),%xmm0
    7233:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    7237:	e9 a4 f9 ff ff       	jmp    6be0 <fwp_main_thread+0xcb0>
    723c:	0f 1f 40 00          	nopl   0x0(%rax)
    7240:	48 39 fe             	cmp    %rdi,%rsi
    7243:	0f 83 d8 f9 ff ff    	jae    6c21 <fwp_main_thread+0xcf1>
    7249:	49 8b 7c 24 10       	mov    0x10(%r12),%rdi
    724e:	f2 0f 10 1d 9a 12 00 	movsd  0x129a(%rip),%xmm3        # 84f0 <msg.3+0xb0>
    7255:	00 
    7256:	f2 0f 10 25 9a 12 00 	movsd  0x129a(%rip),%xmm4        # 84f8 <msg.3+0xb8>
    725d:	00 
    725e:	f2 0f 10 14 07       	movsd  (%rdi,%rax,1),%xmm2
    7263:	f2 0f 5c da          	subsd  %xmm2,%xmm3
    7267:	f2 0f 59 e2          	mulsd  %xmm2,%xmm4
    726b:	f2 0f 59 d2          	mulsd  %xmm2,%xmm2
    726f:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    7273:	e9 e1 f8 ff ff       	jmp    6b59 <fwp_main_thread+0xc29>
    7278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    727f:	00 
    7280:	66 85 c0             	test   %ax,%ax
    7283:	0f 85 37 fa ff ff    	jne    6cc0 <fwp_main_thread+0xd90>
    7289:	e9 0a fa ff ff       	jmp    6c98 <fwp_main_thread+0xd68>
    728e:	66 90                	xchg   %ax,%ax
    7290:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    7294:	e8 37 d2 ff ff       	call   44d0 <fwp_rc_free_arr>
    7299:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    72a0:	48 89 d8             	mov    %rbx,%rax
    72a3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    72aa:	48 c1 e2 10          	shl    $0x10,%rdx
    72ae:	48 39 d0             	cmp    %rdx,%rax
    72b1:	0f 83 09 fa ff ff    	jae    6cc0 <fwp_main_thread+0xd90>
    72b7:	48 89 df             	mov    %rbx,%rdi
    72ba:	e9 8e f9 ff ff       	jmp    6c4d <fwp_main_thread+0xd1d>
    72bf:	90                   	nop
    72c0:	66 85 c0             	test   %ax,%ax
    72c3:	0f 85 0f f8 ff ff    	jne    6ad8 <fwp_main_thread+0xba8>
    72c9:	80 3a ff             	cmpb   $0xff,(%rdx)
    72cc:	0f 85 03 f8 ff ff    	jne    6ad5 <fwp_main_thread+0xba5>
    72d2:	48 89 d7             	mov    %rdx,%rdi
    72d5:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    72da:	e8 b1 ca ff ff       	call   3d90 <fwp_rc_forget_slot>
    72df:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    72e4:	e9 ec f7 ff ff       	jmp    6ad5 <fwp_main_thread+0xba5>
    72e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f0:	4c 89 e7             	mov    %r12,%rdi
    72f3:	e8 d8 d1 ff ff       	call   44d0 <fwp_rc_free_arr>
    72f8:	e9 63 fe ff ff       	jmp    7160 <fwp_main_thread+0x1230>
    72fd:	0f 1f 00             	nopl   (%rax)
    7300:	66 85 c0             	test   %ax,%ax
    7303:	0f 85 b7 f9 ff ff    	jne    6cc0 <fwp_main_thread+0xd90>
    7309:	e9 0d fb ff ff       	jmp    6e1b <fwp_main_thread+0xeeb>
    730e:	66 90                	xchg   %ax,%ax
    7310:	66 85 c9             	test   %cx,%cx
    7313:	0f 84 b0 fb ff ff    	je     6ec9 <fwp_main_thread+0xf99>
    7319:	48 85 ed             	test   %rbp,%rbp
    731c:	0f 85 bd fb ff ff    	jne    6edf <fwp_main_thread+0xfaf>
    7322:	45 31 c9             	xor    %r9d,%r9d
    7325:	e9 f6 f6 ff ff       	jmp    6a20 <fwp_main_thread+0xaf0>
    732a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7330:	66 85 c0             	test   %ax,%ax
    7333:	0f 85 77 fd ff ff    	jne    70b0 <fwp_main_thread+0x1180>
    7339:	e9 52 fd ff ff       	jmp    7090 <fwp_main_thread+0x1160>
    733e:	66 90                	xchg   %ax,%ax
    7340:	48 89 ef             	mov    %rbp,%rdi
    7343:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    7347:	e8 84 d1 ff ff       	call   44d0 <fwp_rc_free_arr>
    734c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    7353:	48 89 d8             	mov    %rbx,%rax
    7356:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    735d:	48 c1 e2 10          	shl    $0x10,%rdx
    7361:	48 39 d0             	cmp    %rdx,%rax
    7364:	0f 83 46 fd ff ff    	jae    70b0 <fwp_main_thread+0x1180>
    736a:	48 89 dd             	mov    %rbx,%rbp
    736d:	e9 d3 fc ff ff       	jmp    7045 <fwp_main_thread+0x1115>
    7372:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7378:	66 85 c0             	test   %ax,%ax
    737b:	0f 85 e5 f5 ff ff    	jne    6966 <fwp_main_thread+0xa36>
    7381:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7385:	0f 85 d7 f5 ff ff    	jne    6962 <fwp_main_thread+0xa32>
    738b:	48 89 ef             	mov    %rbp,%rdi
    738e:	e8 fd c9 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7393:	e9 ca f5 ff ff       	jmp    6962 <fwp_main_thread+0xa32>
    7398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    739f:	00 
    73a0:	66 85 c0             	test   %ax,%ax
    73a3:	0f 85 15 f5 ff ff    	jne    68be <fwp_main_thread+0x98e>
    73a9:	e9 fc f4 ff ff       	jmp    68aa <fwp_main_thread+0x97a>
    73ae:	66 90                	xchg   %ax,%ax
    73b0:	66 85 c0             	test   %ax,%ax
    73b3:	0f 85 81 fc ff ff    	jne    703a <fwp_main_thread+0x110a>
    73b9:	80 3e ff             	cmpb   $0xff,(%rsi)
    73bc:	0f 85 63 fc ff ff    	jne    7025 <fwp_main_thread+0x10f5>
    73c2:	48 89 f7             	mov    %rsi,%rdi
    73c5:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    73ca:	e8 c1 c9 ff ff       	call   3d90 <fwp_rc_forget_slot>
    73cf:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
    73d4:	e9 4c fc ff ff       	jmp    7025 <fwp_main_thread+0x10f5>
    73d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73e0:	66 85 c0             	test   %ax,%ax
    73e3:	0f 85 77 fd ff ff    	jne    7160 <fwp_main_thread+0x1230>
    73e9:	e9 4e fd ff ff       	jmp    713c <fwp_main_thread+0x120c>
    73ee:	66 90                	xchg   %ax,%ax
    73f0:	66 85 c0             	test   %ax,%ax
    73f3:	0f 85 b7 fc ff ff    	jne    70b0 <fwp_main_thread+0x1180>
    73f9:	e9 0b fe ff ff       	jmp    7209 <fwp_main_thread+0x12d9>
    73fe:	66 90                	xchg   %ax,%ax
    7400:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7404:	e9 f2 ec ff ff       	jmp    60fb <fwp_main_thread+0x1cb>
    7409:	31 db                	xor    %ebx,%ebx
    740b:	e9 ad ed ff ff       	jmp    61bd <fwp_main_thread+0x28d>
    7410:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
    7415:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    741a:	e8 41 d8 ff ff       	call   4c60 <fwp_drop0>
    741f:	48 89 df             	mov    %rbx,%rdi
    7422:	e8 39 d8 ff ff       	call   4c60 <fwp_drop0>
    7427:	48 c7 05 6e 2c 00 00 	movq   $0x0,0x2c6e(%rip)        # a0a0 <v.1>
    742e:	00 00 00 00 
    7432:	c7 05 6c 2c 00 00 01 	movl   $0x1,0x2c6c(%rip)        # a0a8 <st.2>
    7439:	00 00 00 
    743c:	e9 06 ec ff ff       	jmp    6047 <fwp_main_thread+0x117>
    7441:	66 85 c0             	test   %ax,%ax
    7444:	0f 85 ab f2 ff ff    	jne    66f5 <fwp_main_thread+0x7c5>
    744a:	e9 98 f2 ff ff       	jmp    66e7 <fwp_main_thread+0x7b7>
    744f:	66 85 d2             	test   %dx,%dx
    7452:	0f 85 e1 f3 ff ff    	jne    6839 <fwp_main_thread+0x909>
    7458:	e9 c0 f3 ff ff       	jmp    681d <fwp_main_thread+0x8ed>
    745d:	66 85 c0             	test   %ax,%ax
    7460:	0f 85 27 f3 ff ff    	jne    678d <fwp_main_thread+0x85d>
    7466:	e9 14 f3 ff ff       	jmp    677f <fwp_main_thread+0x84f>
    746b:	4c 89 e7             	mov    %r12,%rdi
    746e:	e8 1d c9 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7473:	e9 61 f1 ff ff       	jmp    65d9 <fwp_main_thread+0x6a9>
    7478:	48 89 da             	mov    %rbx,%rdx
    747b:	48 c1 ea 11          	shr    $0x11,%rdx
    747f:	48 31 da             	xor    %rbx,%rdx
    7482:	48 89 d0             	mov    %rdx,%rax
    7485:	48 c1 e8 09          	shr    $0x9,%rax
    7489:	48 31 c2             	xor    %rax,%rdx
    748c:	0f b6 d2             	movzbl %dl,%edx
    748f:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    7496:	00 
    7497:	48 85 c0             	test   %rax,%rax
    749a:	75 31                	jne    74cd <fwp_main_thread+0x159d>
    749c:	e9 18 03 00 00       	jmp    77b9 <fwp_main_thread+0x1889>
    74a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74a8:	00 00 
    74aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74b1:	00 00 00 00 
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	0f 84 ec 02 00 00    	je     77b9 <fwp_main_thread+0x1889>
    74cd:	48 89 c2             	mov    %rax,%rdx
    74d0:	48 3b 18             	cmp    (%rax),%rbx
    74d3:	75 eb                	jne    74c0 <fwp_main_thread+0x1590>
    74d5:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d9:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    74dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    74e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    74e8:	0f 85 d2 f7 ff ff    	jne    6cc0 <fwp_main_thread+0xd90>
    74ee:	48 89 df             	mov    %rbx,%rdi
    74f1:	e8 9a c8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    74f6:	c6 03 fe             	movb   $0xfe,(%rbx)
    74f9:	e9 c2 f7 ff ff       	jmp    6cc0 <fwp_main_thread+0xd90>
    74fe:	48 89 d0             	mov    %rdx,%rax
    7501:	48 c1 e8 11          	shr    $0x11,%rax
    7505:	48 31 d0             	xor    %rdx,%rax
    7508:	48 89 c1             	mov    %rax,%rcx
    750b:	48 c1 e9 09          	shr    $0x9,%rcx
    750f:	48 31 c8             	xor    %rcx,%rax
    7512:	0f b6 c8             	movzbl %al,%ecx
    7515:	49 8b 84 cd 48 14 00 	mov    0x1448(%r13,%rcx,8),%rax
    751c:	00 
    751d:	48 85 c0             	test   %rax,%rax
    7520:	75 2b                	jne    754d <fwp_main_thread+0x161d>
    7522:	e9 92 02 00 00       	jmp    77b9 <fwp_main_thread+0x1889>
    7527:	0f 1f 00             	nopl   (%rax)
    752a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7531:	00 00 00 00 
    7535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    753c:	00 00 00 00 
    7540:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7544:	48 85 c0             	test   %rax,%rax
    7547:	0f 84 6c 02 00 00    	je     77b9 <fwp_main_thread+0x1889>
    754d:	48 89 c1             	mov    %rax,%rcx
    7550:	48 3b 10             	cmp    (%rax),%rdx
    7553:	75 eb                	jne    7540 <fwp_main_thread+0x1610>
    7555:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7559:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    755d:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7561:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7568:	0f 85 42 fb ff ff    	jne    70b0 <fwp_main_thread+0x1180>
    756e:	48 89 d7             	mov    %rdx,%rdi
    7571:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    7576:	e8 15 c8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    757b:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    7580:	c6 02 fe             	movb   $0xfe,(%rdx)
    7583:	e9 28 fb ff ff       	jmp    70b0 <fwp_main_thread+0x1180>
    7588:	48 8b 3d 09 4e 01 00 	mov    0x14e09(%rip),%rdi        # 1c398 <fwp_state>
    758f:	e8 3c ca ff ff       	call   3fd0 <fwp_mem_free>
    7594:	48 c7 05 f9 4d 01 00 	movq   $0x0,0x14df9(%rip)        # 1c398 <fwp_state>
    759b:	00 00 00 00 
    759f:	48 c7 05 de 4d 01 00 	movq   $0x0,0x14dde(%rip)        # 1c388 <fwp_state_cap>
    75a6:	00 00 00 00 
    75aa:	48 85 db             	test   %rbx,%rbx
    75ad:	0f 84 71 01 00 00    	je     7724 <fwp_main_thread+0x17f4>
    75b3:	48 3b 1d 3e 31 01 00 	cmp    0x1313e(%rip),%rbx        # 1a6f8 <fwp_root>
    75ba:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    75c1:	00 00 00 00 
    75c5:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    75cc:	00 00 00 00 
    75d0:	c7 05 e6 2a 01 00 00 	movl   $0x0,0x12ae6(%rip)        # 1a0c0 <fwp_exit_code>
    75d7:	00 00 00 
    75da:	0f 84 07 ec ff ff    	je     61e7 <fwp_main_thread+0x2b7>
    75e0:	e9 26 b1 ff ff       	jmp    270b <fwp_main_thread.cold>
    75e5:	0f 1f 00             	nopl   (%rax)
    75e8:	48 89 d9             	mov    %rbx,%rcx
    75eb:	48 c1 e9 11          	shr    $0x11,%rcx
    75ef:	48 31 d9             	xor    %rbx,%rcx
    75f2:	48 89 ca             	mov    %rcx,%rdx
    75f5:	48 c1 ea 09          	shr    $0x9,%rdx
    75f9:	48 31 d1             	xor    %rdx,%rcx
    75fc:	0f b6 c9             	movzbl %cl,%ecx
    75ff:	49 8d ac cd 48 14 00 	lea    0x1448(%r13,%rcx,8),%rbp
    7606:	00 
    7607:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    760b:	49 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%r13,%rcx,8)
    7612:	00 00 
    7614:	75 1a                	jne    7630 <fwp_main_thread+0x1700>
    7616:	e9 78 01 00 00       	jmp    7793 <fwp_main_thread+0x1863>
    761b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7620:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7624:	48 85 c9             	test   %rcx,%rcx
    7627:	0f 84 b1 00 00 00    	je     76de <fwp_main_thread+0x17ae>
    762d:	48 89 ca             	mov    %rcx,%rdx
    7630:	48 39 1a             	cmp    %rbx,(%rdx)
    7633:	75 eb                	jne    7620 <fwp_main_thread+0x16f0>
    7635:	3c fe                	cmp    $0xfe,%al
    7637:	0f 84 63 01 00 00    	je     77a0 <fwp_main_thread+0x1870>
    763d:	48 8b 42 08          	mov    0x8(%rdx),%rax
    7641:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    7645:	0f 84 a0 01 00 00    	je     77eb <fwp_main_thread+0x18bb>
    764b:	48 83 c0 01          	add    $0x1,%rax
    764f:	48 89 42 08          	mov    %rax,0x8(%rdx)
    7653:	e9 66 f2 ff ff       	jmp    68be <fwp_main_thread+0x98e>
    7658:	48 89 da             	mov    %rbx,%rdx
    765b:	48 c1 ea 11          	shr    $0x11,%rdx
    765f:	48 31 da             	xor    %rbx,%rdx
    7662:	48 89 d0             	mov    %rdx,%rax
    7665:	48 c1 e8 09          	shr    $0x9,%rax
    7669:	48 31 c2             	xor    %rax,%rdx
    766c:	0f b6 d2             	movzbl %dl,%edx
    766f:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    7676:	00 
    7677:	48 85 c0             	test   %rax,%rax
    767a:	75 31                	jne    76ad <fwp_main_thread+0x177d>
    767c:	e9 38 01 00 00       	jmp    77b9 <fwp_main_thread+0x1889>
    7681:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7688:	00 00 
    768a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7691:	00 00 00 00 
    7695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    769c:	00 00 00 00 
    76a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76a4:	48 85 c0             	test   %rax,%rax
    76a7:	0f 84 0c 01 00 00    	je     77b9 <fwp_main_thread+0x1889>
    76ad:	48 89 c2             	mov    %rax,%rdx
    76b0:	48 3b 18             	cmp    (%rax),%rbx
    76b3:	75 eb                	jne    76a0 <fwp_main_thread+0x1770>
    76b5:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76b9:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76bd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76c1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76c8:	0f 85 92 fa ff ff    	jne    7160 <fwp_main_thread+0x1230>
    76ce:	48 89 df             	mov    %rbx,%rdi
    76d1:	e8 ba c6 ff ff       	call   3d90 <fwp_rc_forget_slot>
    76d6:	c6 03 fe             	movb   $0xfe,(%rbx)
    76d9:	e9 82 fa ff ff       	jmp    7160 <fwp_main_thread+0x1230>
    76de:	3c fe                	cmp    $0xfe,%al
    76e0:	0f 85 d3 00 00 00    	jne    77b9 <fwp_main_thread+0x1889>
    76e6:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    76ea:	bf 18 00 00 00       	mov    $0x18,%edi
    76ef:	e8 8c ae ff ff       	call   2580 <malloc@plt>
    76f4:	48 85 c0             	test   %rax,%rax
    76f7:	0f 84 fa 00 00 00    	je     77f7 <fwp_main_thread+0x18c7>
    76fd:	48 89 18             	mov    %rbx,(%rax)
    7700:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    7707:	00 
    7708:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    770f:	00 
    7710:	48 89 45 00          	mov    %rax,0x0(%rbp)
    7714:	c6 03 ff             	movb   $0xff,(%rbx)
    7717:	49 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%r13)
    771e:	01 
    771f:	e9 9a f1 ff ff       	jmp    68be <fwp_main_thread+0x98e>
    7724:	48 83 3d cc 2f 01 00 	cmpq   $0x0,0x12fcc(%rip)        # 1a6f8 <fwp_root>
    772b:	00 
    772c:	c7 05 8a 29 01 00 00 	movl   $0x0,0x1298a(%rip)        # 1a0c0 <fwp_exit_code>
    7733:	00 00 00 
    7736:	0f 84 0a eb ff ff    	je     6246 <fwp_main_thread+0x316>
    773c:	e9 ca af ff ff       	jmp    270b <fwp_main_thread.cold>
    7741:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7748:	48 89 ef             	mov    %rbp,%rdi
    774b:	e8 40 c6 ff ff       	call   3d90 <fwp_rc_forget_slot>
    7750:	e9 9c ef ff ff       	jmp    66f1 <fwp_main_thread+0x7c1>
    7755:	48 89 ef             	mov    %rbp,%rdi
    7758:	e8 33 c6 ff ff       	call   3d90 <fwp_rc_forget_slot>
    775d:	e9 27 f0 ff ff       	jmp    6789 <fwp_main_thread+0x859>
    7762:	48 89 ef             	mov    %rbp,%rdi
    7765:	e8 26 c6 ff ff       	call   3d90 <fwp_rc_forget_slot>
    776a:	e9 b8 f0 ff ff       	jmp    6827 <fwp_main_thread+0x8f7>
    776f:	48 8d 3d 8a 0b 00 00 	lea    0xb8a(%rip),%rdi        # 8300 <_IO_stdin_used+0x300>
    7776:	e8 35 b9 ff ff       	call   30b0 <fwp_trap>
    777b:	48 8d 3d 23 09 00 00 	lea    0x923(%rip),%rdi        # 80a5 <_IO_stdin_used+0xa5>
    7782:	e8 29 b9 ff ff       	call   30b0 <fwp_trap>
    7787:	48 8d 3d 22 0b 00 00 	lea    0xb22(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    778e:	e8 1d b9 ff ff       	call   30b0 <fwp_trap>
    7793:	3c fe                	cmp    $0xfe,%al
    7795:	75 19                	jne    77b0 <fwp_main_thread+0x1880>
    7797:	48 85 d2             	test   %rdx,%rdx
    779a:	0f 84 4a ff ff ff    	je     76ea <fwp_main_thread+0x17ba>
    77a0:	48 8d 3d 31 0b 00 00 	lea    0xb31(%rip),%rdi        # 82d8 <_IO_stdin_used+0x2d8>
    77a7:	e8 04 b9 ff ff       	call   30b0 <fwp_trap>
    77ac:	0f 1f 40 00          	nopl   0x0(%rax)
    77b0:	48 85 d2             	test   %rdx,%rdx
    77b3:	0f 85 84 fe ff ff    	jne    763d <fwp_main_thread+0x170d>
    77b9:	48 8d 3d c8 0a 00 00 	lea    0xac8(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    77c0:	e8 eb b8 ff ff       	call   30b0 <fwp_trap>
    77c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77c9:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    77cd:	f2 0f 59 05 2b 0d 00 	mulsd  0xd2b(%rip),%xmm0        # 8500 <msg.3+0xc0>
    77d4:	00 
    77d5:	e9 9d f3 ff ff       	jmp    6b77 <fwp_main_thread+0xc47>
    77da:	48 8d 3d 7c 09 00 00 	lea    0x97c(%rip),%rdi        # 815d <_IO_stdin_used+0x15d>
    77e1:	e8 ca b8 ff ff       	call   30b0 <fwp_trap>
    77e6:	e8 55 ac ff ff       	call   2440 <__stack_chk_fail@plt>
    77eb:	48 8d 3d 52 09 00 00 	lea    0x952(%rip),%rdi        # 8144 <_IO_stdin_used+0x144>
    77f2:	e8 b9 b8 ff ff       	call   30b0 <fwp_trap>
    77f7:	e8 04 b4 ff ff       	call   2c00 <fwp_heap_oom>
    77fc:	e9 0a af ff ff       	jmp    270b <fwp_main_thread.cold>
    7801:	e9 05 af ff ff       	jmp    270b <fwp_main_thread.cold>
    7806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    780d:	00 00 00 

0000000000007810 <__divmodti4>:
    7810:	f3 0f 1e fa          	endbr64
    7814:	55                   	push   %rbp
    7815:	49 89 f1             	mov    %rsi,%r9
    7818:	49 89 d2             	mov    %rdx,%r10
    781b:	48 89 fe             	mov    %rdi,%rsi
    781e:	49 89 cb             	mov    %rcx,%r11
    7821:	48 89 e5             	mov    %rsp,%rbp
    7824:	41 57                	push   %r15
    7826:	41 56                	push   %r14
    7828:	41 55                	push   %r13
    782a:	41 54                	push   %r12
    782c:	53                   	push   %rbx
    782d:	4c 89 c3             	mov    %r8,%rbx
    7830:	45 31 c0             	xor    %r8d,%r8d
    7833:	4d 85 c9             	test   %r9,%r9
    7836:	79 12                	jns    784a <__divmodti4+0x3a>
    7838:	31 ff                	xor    %edi,%edi
    783a:	48 f7 de             	neg    %rsi
    783d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    7844:	4c 19 cf             	sbb    %r9,%rdi
    7847:	49 89 f9             	mov    %rdi,%r9
    784a:	4c 89 d8             	mov    %r11,%rax
    784d:	4d 85 db             	test   %r11,%r11
    7850:	0f 88 1a 01 00 00    	js     7970 <__divmodti4+0x160>
    7856:	4c 89 d9             	mov    %r11,%rcx
    7859:	49 89 f3             	mov    %rsi,%r11
    785c:	75 62                	jne    78c0 <__divmodti4+0xb0>
    785e:	4d 89 c4             	mov    %r8,%r12
    7861:	4d 39 d1             	cmp    %r10,%r9
    7864:	0f 83 46 01 00 00    	jae    79b0 <__divmodti4+0x1a0>
    786a:	4c 89 d8             	mov    %r11,%rax
    786d:	4c 89 ca             	mov    %r9,%rdx
    7870:	49 f7 f2             	div    %r10
    7873:	49 89 c3             	mov    %rax,%r11
    7876:	31 c0                	xor    %eax,%eax
    7878:	48 89 d6             	mov    %rdx,%rsi
    787b:	31 ff                	xor    %edi,%edi
    787d:	4c 89 d9             	mov    %r11,%rcx
    7880:	48 89 c2             	mov    %rax,%rdx
    7883:	48 89 c8             	mov    %rcx,%rax
    7886:	4d 85 e4             	test   %r12,%r12
    7889:	74 0a                	je     7895 <__divmodti4+0x85>
    788b:	48 f7 d8             	neg    %rax
    788e:	48 83 d2 00          	adc    $0x0,%rdx
    7892:	48 f7 da             	neg    %rdx
    7895:	4d 85 c0             	test   %r8,%r8
    7898:	74 0a                	je     78a4 <__divmodti4+0x94>
    789a:	48 f7 de             	neg    %rsi
    789d:	48 83 d7 00          	adc    $0x0,%rdi
    78a1:	48 f7 df             	neg    %rdi
    78a4:	48 89 33             	mov    %rsi,(%rbx)
    78a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    78ab:	5b                   	pop    %rbx
    78ac:	41 5c                	pop    %r12
    78ae:	41 5d                	pop    %r13
    78b0:	41 5e                	pop    %r14
    78b2:	41 5f                	pop    %r15
    78b4:	5d                   	pop    %rbp
    78b5:	c3                   	ret
    78b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78bd:	00 00 00 
    78c0:	4d 89 c4             	mov    %r8,%r12
    78c3:	49 39 c1             	cmp    %rax,%r9
    78c6:	0f 82 ce 00 00 00    	jb     799a <__divmodti4+0x18a>
    78cc:	31 ff                	xor    %edi,%edi
    78ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    78d3:	48 63 c7             	movslq %edi,%rax
    78d6:	be 40 00 00 00       	mov    $0x40,%esi
    78db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    78e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    78e5:	48 29 c6             	sub    %rax,%rsi
    78e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    78ed:	48 09 c8             	or     %rcx,%rax
    78f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    78f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    78fa:	49 89 c6             	mov    %rax,%r14
    78fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    7901:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    7906:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    790b:	49 09 c1             	or     %rax,%r9
    790e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    7912:	4c 89 c8             	mov    %r9,%rax
    7915:	49 f7 f6             	div    %r14
    7918:	48 89 d1             	mov    %rdx,%rcx
    791b:	49 89 c3             	mov    %rax,%r11
    791e:	49 89 c1             	mov    %rax,%r9
    7921:	49 f7 e2             	mul    %r10
    7924:	49 89 c6             	mov    %rax,%r14
    7927:	49 89 d2             	mov    %rdx,%r10
    792a:	48 39 d1             	cmp    %rdx,%rcx
    792d:	72 07                	jb     7936 <__divmodti4+0x126>
    792f:	75 17                	jne    7948 <__divmodti4+0x138>
    7931:	49 39 c7             	cmp    %rax,%r15
    7934:	73 12                	jae    7948 <__divmodti4+0x138>
    7936:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    793a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    793e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    7942:	49 89 d2             	mov    %rdx,%r10
    7945:	49 89 c6             	mov    %rax,%r14
    7948:	4c 89 f8             	mov    %r15,%rax
    794b:	4c 29 f0             	sub    %r14,%rax
    794e:	4c 19 d1             	sbb    %r10,%rcx
    7951:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    7956:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    795b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    7960:	48 09 c6             	or     %rax,%rsi
    7963:	48 89 cf             	mov    %rcx,%rdi
    7966:	31 c0                	xor    %eax,%eax
    7968:	4c 89 c9             	mov    %r9,%rcx
    796b:	e9 10 ff ff ff       	jmp    7880 <__divmodti4+0x70>
    7970:	4c 89 d0             	mov    %r10,%rax
    7973:	4c 89 da             	mov    %r11,%rdx
    7976:	4d 89 c4             	mov    %r8,%r12
    7979:	49 89 f3             	mov    %rsi,%r11
    797c:	48 f7 d8             	neg    %rax
    797f:	49 f7 d4             	not    %r12
    7982:	48 83 d2 00          	adc    $0x0,%rdx
    7986:	49 89 c2             	mov    %rax,%r10
    7989:	48 f7 da             	neg    %rdx
    798c:	48 89 d1             	mov    %rdx,%rcx
    798f:	0f 84 cc fe ff ff    	je     7861 <__divmodti4+0x51>
    7995:	49 39 d1             	cmp    %rdx,%r9
    7998:	73 46                	jae    79e0 <__divmodti4+0x1d0>
    799a:	4c 89 cf             	mov    %r9,%rdi
    799d:	31 c0                	xor    %eax,%eax
    799f:	31 c9                	xor    %ecx,%ecx
    79a1:	e9 da fe ff ff       	jmp    7880 <__divmodti4+0x70>
    79a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79ad:	00 00 00 
    79b0:	4d 85 d2             	test   %r10,%r10
    79b3:	75 0d                	jne    79c2 <__divmodti4+0x1b2>
    79b5:	b8 01 00 00 00       	mov    $0x1,%eax
    79ba:	31 d2                	xor    %edx,%edx
    79bc:	49 f7 f2             	div    %r10
    79bf:	49 89 c2             	mov    %rax,%r10
    79c2:	4c 89 c8             	mov    %r9,%rax
    79c5:	31 d2                	xor    %edx,%edx
    79c7:	49 f7 f2             	div    %r10
    79ca:	49 89 c1             	mov    %rax,%r9
    79cd:	4c 89 d8             	mov    %r11,%rax
    79d0:	49 f7 f2             	div    %r10
    79d3:	49 89 c3             	mov    %rax,%r11
    79d6:	4c 89 c8             	mov    %r9,%rax
    79d9:	e9 9a fe ff ff       	jmp    7878 <__divmodti4+0x68>
    79de:	66 90                	xchg   %ax,%ax
    79e0:	45 31 f6             	xor    %r14d,%r14d
    79e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    79e8:	44 89 f7             	mov    %r14d,%edi
    79eb:	45 85 f6             	test   %r14d,%r14d
    79ee:	0f 85 df fe ff ff    	jne    78d3 <__divmodti4+0xc3>
    79f4:	4c 39 ca             	cmp    %r9,%rdx
    79f7:	72 17                	jb     7a10 <__divmodti4+0x200>
    79f9:	31 c9                	xor    %ecx,%ecx
    79fb:	48 39 c6             	cmp    %rax,%rsi
    79fe:	73 10                	jae    7a10 <__divmodti4+0x200>
    7a00:	4c 89 cf             	mov    %r9,%rdi
    7a03:	31 c0                	xor    %eax,%eax
    7a05:	e9 76 fe ff ff       	jmp    7880 <__divmodti4+0x70>
    7a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a10:	4c 89 de             	mov    %r11,%rsi
    7a13:	b9 01 00 00 00       	mov    $0x1,%ecx
    7a18:	48 29 c6             	sub    %rax,%rsi
    7a1b:	49 19 d1             	sbb    %rdx,%r9
    7a1e:	eb e0                	jmp    7a00 <__divmodti4+0x1f0>

0000000000007a20 <atexit>:
    7a20:	f3 0f 1e fa          	endbr64
    7a24:	48 8b 15 dd 25 00 00 	mov    0x25dd(%rip),%rdx        # a008 <__dso_handle>
    7a2b:	31 f6                	xor    %esi,%esi
    7a2d:	e9 ee ab ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000007a34 <_fini>:
    7a34:	f3 0f 1e fa          	endbr64
    7a38:	48 83 ec 08          	sub    $0x8,%rsp
    7a3c:	48 83 c4 08          	add    $0x8,%rsp
    7a40:	c3                   	ret
