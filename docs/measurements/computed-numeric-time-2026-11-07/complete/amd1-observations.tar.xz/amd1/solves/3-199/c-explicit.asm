
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-199/c-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 d9 2f 00 00 	mov    0x2fd9(%rip),%rax        # 3fe8 <__gmon_start__>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 72 2f 00 00    	push   0x2f72(%rip)        # 3f98 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 74 2f 00 00    	jmp    *0x2f74(%rip)        # 3fa0 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)
    1030:	f3 0f 1e fa          	endbr64
    1034:	68 00 00 00 00       	push   $0x0
    1039:	e9 e2 ff ff ff       	jmp    1020 <_init+0x20>
    103e:	66 90                	xchg   %ax,%ax
    1040:	f3 0f 1e fa          	endbr64
    1044:	68 01 00 00 00       	push   $0x1
    1049:	e9 d2 ff ff ff       	jmp    1020 <_init+0x20>
    104e:	66 90                	xchg   %ax,%ax
    1050:	f3 0f 1e fa          	endbr64
    1054:	68 02 00 00 00       	push   $0x2
    1059:	e9 c2 ff ff ff       	jmp    1020 <_init+0x20>
    105e:	66 90                	xchg   %ax,%ax
    1060:	f3 0f 1e fa          	endbr64
    1064:	68 03 00 00 00       	push   $0x3
    1069:	e9 b2 ff ff ff       	jmp    1020 <_init+0x20>
    106e:	66 90                	xchg   %ax,%ax
    1070:	f3 0f 1e fa          	endbr64
    1074:	68 04 00 00 00       	push   $0x4
    1079:	e9 a2 ff ff ff       	jmp    1020 <_init+0x20>
    107e:	66 90                	xchg   %ax,%ax
    1080:	f3 0f 1e fa          	endbr64
    1084:	68 05 00 00 00       	push   $0x5
    1089:	e9 92 ff ff ff       	jmp    1020 <_init+0x20>
    108e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000001090 <__cxa_finalize@plt>:
    1090:	f3 0f 1e fa          	endbr64
    1094:	ff 25 5e 2f 00 00    	jmp    *0x2f5e(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    109a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000010a0 <free@plt>:
    10a0:	f3 0f 1e fa          	endbr64
    10a4:	ff 25 fe 2e 00 00    	jmp    *0x2efe(%rip)        # 3fa8 <free@GLIBC_2.2.5>
    10aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010b0 <puts@plt>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	ff 25 f6 2e 00 00    	jmp    *0x2ef6(%rip)        # 3fb0 <puts@GLIBC_2.2.5>
    10ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010c0 <ferror@plt>:
    10c0:	f3 0f 1e fa          	endbr64
    10c4:	ff 25 ee 2e 00 00    	jmp    *0x2eee(%rip)        # 3fb8 <ferror@GLIBC_2.2.5>
    10ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010d0 <putc@plt>:
    10d0:	f3 0f 1e fa          	endbr64
    10d4:	ff 25 e6 2e 00 00    	jmp    *0x2ee6(%rip)        # 3fc0 <putc@GLIBC_2.2.5>
    10da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010e0 <malloc@plt>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	ff 25 de 2e 00 00    	jmp    *0x2ede(%rip)        # 3fc8 <malloc@GLIBC_2.2.5>
    10ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010f0 <__printf_chk@plt>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	ff 25 d6 2e 00 00    	jmp    *0x2ed6(%rip)        # 3fd0 <__printf_chk@GLIBC_2.3.4>
    10fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000001100 <main>:
    1100:	f3 0f 1e fa          	endbr64
    1104:	41 54                	push   %r12
    1106:	55                   	push   %rbp
    1107:	53                   	push   %rbx
    1108:	bb 20 00 00 00       	mov    $0x20,%ebx
    110d:	bf 18 00 00 00       	mov    $0x18,%edi
    1112:	e8 c9 ff ff ff       	call   10e0 <malloc@plt>
    1117:	bf 18 00 00 00       	mov    $0x18,%edi
    111c:	48 89 c5             	mov    %rax,%rbp
    111f:	e8 bc ff ff ff       	call   10e0 <malloc@plt>
    1124:	49 89 c4             	mov    %rax,%r12
    1127:	48 85 ed             	test   %rbp,%rbp
    112a:	0f 84 41 02 00 00    	je     1371 <main+0x271>
    1130:	48 85 c0             	test   %rax,%rax
    1133:	0f 84 38 02 00 00    	je     1371 <main+0x271>
    1139:	66 0f 28 3d cf 0e 00 	movapd 0xecf(%rip),%xmm7        # 2010 <_IO_stdin_used+0x10>
    1140:	00 
    1141:	48 8b 05 c8 0e 00 00 	mov    0xec8(%rip),%rax        # 2010 <_IO_stdin_used+0x10>
    1148:	66 0f ef d2          	pxor   %xmm2,%xmm2
    114c:	f2 0f 10 2d ec 0e 00 	movsd  0xeec(%rip),%xmm5        # 2040 <_IO_stdin_used+0x40>
    1153:	00 
    1154:	f2 0f 10 25 bc 0e 00 	movsd  0xebc(%rip),%xmm4        # 2018 <_IO_stdin_used+0x18>
    115b:	00 
    115c:	0f 11 7d 00          	movups %xmm7,0x0(%rbp)
    1160:	66 0f 28 cf          	movapd %xmm7,%xmm1
    1164:	f2 0f 10 1d dc 0e 00 	movsd  0xedc(%rip),%xmm3        # 2048 <_IO_stdin_used+0x48>
    116b:	00 
    116c:	f2 0f 10 3d ac 0e 00 	movsd  0xeac(%rip),%xmm7        # 2020 <_IO_stdin_used+0x20>
    1173:	00 
    1174:	66 0f 28 35 a4 0e 00 	movapd 0xea4(%rip),%xmm6        # 2020 <_IO_stdin_used+0x20>
    117b:	00 
    117c:	48 89 45 10          	mov    %rax,0x10(%rbp)
    1180:	66 4c 0f 6e e0       	movq   %rax,%xmm12
    1185:	b8 c7 00 00 00       	mov    $0xc7,%eax
    118a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1190:	f2 44 0f 10 5d 00    	movsd  0x0(%rbp),%xmm11
    1196:	f2 44 0f 10 55 08    	movsd  0x8(%rbp),%xmm10
    119c:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
    11a1:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
    11a6:	66 45 0f 28 ca       	movapd %xmm10,%xmm9
    11ab:	f2 45 0f 5c c3       	subsd  %xmm11,%xmm8
    11b0:	f2 41 0f 59 c3       	mulsd  %xmm11,%xmm0
    11b5:	f2 45 0f 58 c0       	addsd  %xmm8,%xmm8
    11ba:	f2 44 0f 5c c8       	subsd  %xmm0,%xmm9
    11bf:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
    11c4:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
    11c9:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
    11cd:	f2 41 0f 59 c1       	mulsd  %xmm9,%xmm0
    11d2:	f2 44 0f 59 cb       	mulsd  %xmm3,%xmm9
    11d7:	f2 41 0f 5c c0       	subsd  %xmm8,%xmm0
    11dc:	f2 44 0f 58 ca       	addsd  %xmm2,%xmm9
    11e1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    11e5:	f2 41 0f 11 04 24    	movsd  %xmm0,(%r12)
    11eb:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
    11f0:	f2 41 0f 59 c2       	mulsd  %xmm10,%xmm0
    11f5:	f2 44 0f 5c d8       	subsd  %xmm0,%xmm11
    11fa:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
    11ff:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
    1203:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
    1208:	f2 44 0f 59 c3       	mulsd  %xmm3,%xmm8
    120d:	f2 41 0f 59 c3       	mulsd  %xmm11,%xmm0
    1212:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
    1217:	f2 45 0f 5c da       	subsd  %xmm10,%xmm11
    121c:	f2 44 0f 58 c2       	addsd  %xmm2,%xmm8
    1221:	f2 45 0f 58 db       	addsd  %xmm11,%xmm11
    1226:	f2 41 0f 5c c3       	subsd  %xmm11,%xmm0
    122b:	f2 41 0f 58 c1       	addsd  %xmm9,%xmm0
    1230:	66 41 0f 14 c0       	unpcklpd %xmm8,%xmm0
    1235:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    123b:	66 41 0f 10 04 24    	movupd (%r12),%xmm0
    1241:	f2 44 0f 59 c7       	mulsd  %xmm7,%xmm8
    1246:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
    124a:	f2 45 0f 5c e0       	subsd  %xmm8,%xmm12
    124f:	66 0f 5c c8          	subpd  %xmm0,%xmm1
    1253:	0f 11 4d 00          	movups %xmm1,0x0(%rbp)
    1257:	48 83 e8 01          	sub    $0x1,%rax
    125b:	0f 85 2f ff ff ff    	jne    1190 <main+0x90>
    1261:	f2 0f 10 05 e7 0d 00 	movsd  0xde7(%rip),%xmm0        # 2050 <_IO_stdin_used+0x50>
    1268:	00 
    1269:	66 0f 28 d1          	movapd %xmm1,%xmm2
    126d:	f2 44 0f 11 65 10    	movsd  %xmm12,0x10(%rbp)
    1273:	66 0f 54 15 b5 0d 00 	andpd  0xdb5(%rip),%xmm2        # 2030 <_IO_stdin_used+0x30>
    127a:	00 
    127b:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    127f:	0f 82 d5 00 00 00    	jb     135a <main+0x25a>
    1285:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
    1289:	66 0f 54 0d 9f 0d 00 	andpd  0xd9f(%rip),%xmm1        # 2030 <_IO_stdin_used+0x30>
    1290:	00 
    1291:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1295:	0f 82 bf 00 00 00    	jb     135a <main+0x25a>
    129b:	66 44 0f 54 25 8c 0d 	andpd  0xd8c(%rip),%xmm12        # 2030 <_IO_stdin_used+0x30>
    12a2:	00 00 
    12a4:	66 41 0f 2e c4       	ucomisd %xmm12,%xmm0
    12a9:	0f 82 ab 00 00 00    	jb     135a <main+0x25a>
    12af:	48 8b 35 5a 2d 00 00 	mov    0x2d5a(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    12b6:	bf 5b 00 00 00       	mov    $0x5b,%edi
    12bb:	e8 10 fe ff ff       	call   10d0 <putc@plt>
    12c0:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    12c5:	bf 02 00 00 00       	mov    $0x2,%edi
    12ca:	48 8d 35 35 0d 00 00 	lea    0xd35(%rip),%rsi        # 2006 <_IO_stdin_used+0x6>
    12d1:	b8 01 00 00 00       	mov    $0x1,%eax
    12d6:	e8 15 fe ff ff       	call   10f0 <__printf_chk@plt>
    12db:	f2 0f 10 45 08       	movsd  0x8(%rbp),%xmm0
    12e0:	bf 02 00 00 00       	mov    $0x2,%edi
    12e5:	48 8d 35 18 0d 00 00 	lea    0xd18(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    12ec:	b8 01 00 00 00       	mov    $0x1,%eax
    12f1:	e8 fa fd ff ff       	call   10f0 <__printf_chk@plt>
    12f6:	f2 0f 10 45 10       	movsd  0x10(%rbp),%xmm0
    12fb:	bf 02 00 00 00       	mov    $0x2,%edi
    1300:	48 8d 35 fd 0c 00 00 	lea    0xcfd(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    1307:	b8 01 00 00 00       	mov    $0x1,%eax
    130c:	e8 df fd ff ff       	call   10f0 <__printf_chk@plt>
    1311:	48 8d 3d f4 0c 00 00 	lea    0xcf4(%rip),%rdi        # 200c <_IO_stdin_used+0xc>
    1318:	e8 93 fd ff ff       	call   10b0 <puts@plt>
    131d:	48 89 ef             	mov    %rbp,%rdi
    1320:	e8 7b fd ff ff       	call   10a0 <free@plt>
    1325:	4c 89 e7             	mov    %r12,%rdi
    1328:	e8 73 fd ff ff       	call   10a0 <free@plt>
    132d:	48 8b 3d dc 2c 00 00 	mov    0x2cdc(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1334:	e8 87 fd ff ff       	call   10c0 <ferror@plt>
    1339:	85 c0                	test   %eax,%eax
    133b:	75 13                	jne    1350 <main+0x250>
    133d:	48 83 eb 01          	sub    $0x1,%rbx
    1341:	0f 85 c6 fd ff ff    	jne    110d <main+0xd>
    1347:	5b                   	pop    %rbx
    1348:	5d                   	pop    %rbp
    1349:	41 5c                	pop    %r12
    134b:	c3                   	ret
    134c:	0f 1f 40 00          	nopl   0x0(%rax)
    1350:	5b                   	pop    %rbx
    1351:	b8 04 00 00 00       	mov    $0x4,%eax
    1356:	5d                   	pop    %rbp
    1357:	41 5c                	pop    %r12
    1359:	c3                   	ret
    135a:	48 89 ef             	mov    %rbp,%rdi
    135d:	e8 3e fd ff ff       	call   10a0 <free@plt>
    1362:	4c 89 e7             	mov    %r12,%rdi
    1365:	e8 36 fd ff ff       	call   10a0 <free@plt>
    136a:	b8 03 00 00 00       	mov    $0x3,%eax
    136f:	eb d6                	jmp    1347 <main+0x247>
    1371:	48 89 ef             	mov    %rbp,%rdi
    1374:	e8 27 fd ff ff       	call   10a0 <free@plt>
    1379:	4c 89 e7             	mov    %r12,%rdi
    137c:	e8 1f fd ff ff       	call   10a0 <free@plt>
    1381:	b8 02 00 00 00       	mov    $0x2,%eax
    1386:	eb bf                	jmp    1347 <main+0x247>
    1388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    138f:	00 

0000000000001390 <_start>:
    1390:	f3 0f 1e fa          	endbr64
    1394:	31 ed                	xor    %ebp,%ebp
    1396:	49 89 d1             	mov    %rdx,%r9
    1399:	5e                   	pop    %rsi
    139a:	48 89 e2             	mov    %rsp,%rdx
    139d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    13a1:	50                   	push   %rax
    13a2:	54                   	push   %rsp
    13a3:	45 31 c0             	xor    %r8d,%r8d
    13a6:	31 c9                	xor    %ecx,%ecx
    13a8:	48 8d 3d 51 fd ff ff 	lea    -0x2af(%rip),%rdi        # 1100 <main>
    13af:	ff 15 23 2c 00 00    	call   *0x2c23(%rip)        # 3fd8 <__libc_start_main@GLIBC_2.34>
    13b5:	f4                   	hlt
    13b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    13bd:	00 00 00 

00000000000013c0 <deregister_tm_clones>:
    13c0:	48 8d 3d 49 2c 00 00 	lea    0x2c49(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    13c7:	48 8d 05 42 2c 00 00 	lea    0x2c42(%rip),%rax        # 4010 <stdout@GLIBC_2.2.5>
    13ce:	48 39 f8             	cmp    %rdi,%rax
    13d1:	74 15                	je     13e8 <deregister_tm_clones+0x28>
    13d3:	48 8b 05 06 2c 00 00 	mov    0x2c06(%rip),%rax        # 3fe0 <_ITM_deregisterTMCloneTable>
    13da:	48 85 c0             	test   %rax,%rax
    13dd:	74 09                	je     13e8 <deregister_tm_clones+0x28>
    13df:	ff e0                	jmp    *%rax
    13e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    13e8:	c3                   	ret
    13e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000013f0 <register_tm_clones>:
    13f0:	48 8d 3d 19 2c 00 00 	lea    0x2c19(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    13f7:	48 8d 35 12 2c 00 00 	lea    0x2c12(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    13fe:	48 29 fe             	sub    %rdi,%rsi
    1401:	48 89 f0             	mov    %rsi,%rax
    1404:	48 c1 ee 3f          	shr    $0x3f,%rsi
    1408:	48 c1 f8 03          	sar    $0x3,%rax
    140c:	48 01 c6             	add    %rax,%rsi
    140f:	48 d1 fe             	sar    $1,%rsi
    1412:	74 14                	je     1428 <register_tm_clones+0x38>
    1414:	48 8b 05 d5 2b 00 00 	mov    0x2bd5(%rip),%rax        # 3ff0 <_ITM_registerTMCloneTable>
    141b:	48 85 c0             	test   %rax,%rax
    141e:	74 08                	je     1428 <register_tm_clones+0x38>
    1420:	ff e0                	jmp    *%rax
    1422:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1428:	c3                   	ret
    1429:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001430 <__do_global_dtors_aux>:
    1430:	f3 0f 1e fa          	endbr64
    1434:	80 3d dd 2b 00 00 00 	cmpb   $0x0,0x2bdd(%rip)        # 4018 <completed.0>
    143b:	75 2b                	jne    1468 <__do_global_dtors_aux+0x38>
    143d:	55                   	push   %rbp
    143e:	48 83 3d b2 2b 00 00 	cmpq   $0x0,0x2bb2(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    1445:	00 
    1446:	48 89 e5             	mov    %rsp,%rbp
    1449:	74 0c                	je     1457 <__do_global_dtors_aux+0x27>
    144b:	48 8b 3d b6 2b 00 00 	mov    0x2bb6(%rip),%rdi        # 4008 <__dso_handle>
    1452:	e8 39 fc ff ff       	call   1090 <__cxa_finalize@plt>
    1457:	e8 64 ff ff ff       	call   13c0 <deregister_tm_clones>
    145c:	c6 05 b5 2b 00 00 01 	movb   $0x1,0x2bb5(%rip)        # 4018 <completed.0>
    1463:	5d                   	pop    %rbp
    1464:	c3                   	ret
    1465:	0f 1f 00             	nopl   (%rax)
    1468:	c3                   	ret
    1469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001470 <frame_dummy>:
    1470:	f3 0f 1e fa          	endbr64
    1474:	e9 77 ff ff ff       	jmp    13f0 <register_tm_clones>

Disassembly of section .fini:

000000000000147c <_fini>:
    147c:	f3 0f 1e fa          	endbr64
    1480:	48 83 ec 08          	sub    $0x8,%rsp
    1484:	48 83 c4 08          	add    $0x8,%rsp
    1488:	c3                   	ret
