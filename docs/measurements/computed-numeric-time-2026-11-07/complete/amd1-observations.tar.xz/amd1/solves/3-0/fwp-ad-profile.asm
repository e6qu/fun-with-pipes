
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # efd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 6e bc 00 00    	jmp    *0xbc6e(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 9e ba 00 00    	jmp    *0xba9e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 96 ba 00 00    	jmp    *0xba96(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee70 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eef8 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef20 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef58 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef60 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef68 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef70 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef78 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef80 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef88 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef90 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef98 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # efa0 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # efa8 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efb0 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efb8 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d fa 79 00 00 	lea    0x79fa(%rip),%r9        # b0d1 <_IO_stdin_used+0xd1>
    36d7:	4c 8d 05 f7 79 00 00 	lea    0x79f7(%rip),%r8        # b0d5 <_IO_stdin_used+0xd5>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 0a 0d 00 00       	call   4410 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_main_thread.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>

0000000000003710 <main.cold>:
    3710:	e8 9b fc ff ff       	call   33b0 <abort@plt>
    3715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    371c:	00 00 00 
    371f:	90                   	nop

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 e1 9b 00 00 	lea    0x9be1(%rip),%rax        # d320 <fwp_fn_table>
    373f:	48 89 05 12 5d 06 00 	mov    %rax,0x65d12(%rip)        # 69458 <fwp_fns>
    3746:	48 8b 05 d3 b8 00 00 	mov    0xb8d3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 0c 5d 06 00 	mov    %rax,0x65d0c(%rip)        # 69460 <fwp_prog_out>
    3754:	e8 27 0e 00 00       	call   4580 <fwp_now_ns>
    3759:	48 8d 3d 4a 7b 00 00 	lea    0x7b4a(%rip),%rdi        # b2aa <_IO_stdin_used+0x2aa>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 b8 00 00 	mov    0xb858(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 4f 64 00 00 	lea    0x644f(%rip),%rdx        # 9c70 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 d6 fe ff ff    	jne    3710 <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 ba fe ff ff    	jne    3710 <main.cold>
    3856:	48 8b 3d c3 b7 00 00 	mov    0xb7c3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 b8 01 00    	mov    0x1b818(%rip),%eax        # 1f080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d fa 79 00 00 	lea    0x79fa(%rip),%rdi        # b2b3 <_IO_stdin_used+0x2b3>
    38b9:	e8 52 0b 00 00       	call   4410 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d c6 82 00 00 	lea    0x82c6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ca:	e8 41 0b 00 00       	call   4410 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 2f fe ff ff    	jne    3710 <main.cold>
    38e1:	48 8d 3d 80 82 00 00 	lea    0x8280(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    38e8:	e8 23 0b 00 00       	call   4410 <fwp_trap>
    38ed:	48 8d 3d 44 82 00 00 	lea    0x8244(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    38f4:	e8 17 0b 00 00       	call   4410 <fwp_trap>
    38f9:	48 8d 3d 10 82 00 00 	lea    0x8210(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3900:	e8 0b 0b 00 00       	call   4410 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 93 b6 00 00    	call   *0xb693(%rip)        # efc8 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d1 b6 00 00 	lea    0xb6d1(%rip),%rdi        # f018 <__TMC_END__>
    3947:	48 8d 05 ca b6 00 00 	lea    0xb6ca(%rip),%rax        # f018 <__TMC_END__>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 76 b6 00 00 	mov    0xb676(%rip),%rax        # efd0 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a1 b6 00 00 	lea    0xb6a1(%rip),%rdi        # f018 <__TMC_END__>
    3977:	48 8d 35 9a b6 00 00 	lea    0xb69a(%rip),%rsi        # f018 <__TMC_END__>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 45 b6 00 00 	mov    0xb645(%rip),%rax        # efe0 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d b6 00 00 00 	cmpb   $0x0,0xb68d(%rip)        # f048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 22 b6 00 00 	cmpq   $0x0,0xb622(%rip)        # efe8 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 b6 00 00 	mov    0xb636(%rip),%rdi        # f008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 b6 00 00 01 	movb   $0x1,0xb665(%rip)        # f048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <ad_raw_record>:
    3bc0:	89 c8                	mov    %ecx,%eax
    3bc2:	4c 8d 05 b7 b5 04 00 	lea    0x4b5b7(%rip),%r8        # 4f180 <ad_raw_live>
    3bc9:	49 89 f1             	mov    %rsi,%r9
    3bcc:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bd3:	00 
    3bd4:	48 89 d6             	mov    %rdx,%rsi
    3bd7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bda:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bde:	48 8d 0d 5b b5 04 00 	lea    0x4b55b(%rip),%rcx        # 4f140 <ad_raw_requests>
    3be5:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3bea:	48 8d 0d 2f b5 04 00 	lea    0x4b52f(%rip),%rcx        # 4f120 <ad_raw_bytes>
    3bf1:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3bf5:	48 01 f2             	add    %rsi,%rdx
    3bf8:	48 8d 0d 61 b5 04 00 	lea    0x4b561(%rip),%rcx        # 4f160 <ad_raw_peak>
    3bff:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c03:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c07:	4c 89 0f             	mov    %r9,(%rdi)
    3c0a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c0e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c12:	73 04                	jae    3c18 <ad_raw_record+0x58>
    3c14:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c18:	66 0f 6f 05 70 b5 04 	movdqa 0x4b570(%rip),%xmm0        # 4f190 <ad_raw_live+0x10>
    3c1f:	00 
    3c20:	66 0f d4 05 58 b5 04 	paddq  0x4b558(%rip),%xmm0        # 4f180 <ad_raw_live>
    3c27:	00 
    3c28:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c2c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c31:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c35:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c3a:	48 39 05 bf b4 04 00 	cmp    %rax,0x4b4bf(%rip)        # 4f100 <ad_raw_total_peak>
    3c41:	73 08                	jae    3c4b <ad_raw_record+0x8b>
    3c43:	66 0f d6 05 b5 b4 04 	movq   %xmm0,0x4b4b5(%rip)        # 4f100 <ad_raw_total_peak>
    3c4a:	00 
    3c4b:	c3                   	ret
    3c4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c50 <fwp_tape_unlink_scope>:
    3c50:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3c54:	48 85 d2             	test   %rdx,%rdx
    3c57:	74 3e                	je     3c97 <fwp_tape_unlink_scope+0x47>
    3c59:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3c5c:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3c60:	85 c9                	test   %ecx,%ecx
    3c62:	78 3c                	js     3ca0 <fwp_tape_unlink_scope+0x50>
    3c64:	48 63 d1             	movslq %ecx,%rdx
    3c67:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3c6b:	48 03 15 6e b4 01 00 	add    0x1b46e(%rip),%rdx        # 1f0e0 <fwp_tapes>
    3c72:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3c75:	85 c0                	test   %eax,%eax
    3c77:	78 0e                	js     3c87 <fwp_tape_unlink_scope+0x37>
    3c79:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3c7d:	48 03 05 5c b4 01 00 	add    0x1b45c(%rip),%rax        # 1f0e0 <fwp_tapes>
    3c84:	89 48 48             	mov    %ecx,0x48(%rax)
    3c87:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3c8e:	00 
    3c8f:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c96:	ff 
    3c97:	c3                   	ret
    3c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c9f:	00 
    3ca0:	89 02                	mov    %eax,(%rdx)
    3ca2:	eb d1                	jmp    3c75 <fwp_tape_unlink_scope+0x25>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_args173>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	c3                   	ret
    3cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cbc:	00 00 00 00 

0000000000003cc0 <fwp_flush>:
    3cc0:	48 8b 3d 99 57 06 00 	mov    0x65799(%rip),%rdi        # 69460 <fwp_prog_out>
    3cc7:	48 85 ff             	test   %rdi,%rdi
    3cca:	74 1c                	je     3ce8 <fwp_flush+0x28>
    3ccc:	48 83 ec 08          	sub    $0x8,%rsp
    3cd0:	e8 bb f8 ff ff       	call   3590 <fflush@plt>
    3cd5:	48 8b 3d 44 b3 00 00 	mov    0xb344(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cdc:	48 83 c4 08          	add    $0x8,%rsp
    3ce0:	e9 ab f8 ff ff       	jmp    3590 <fflush@plt>
    3ce5:	0f 1f 00             	nopl   (%rax)
    3ce8:	48 8b 3d 31 b3 00 00 	mov    0xb331(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cef:	e9 9c f8 ff ff       	jmp    3590 <fflush@plt>
    3cf4:	90                   	nop
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_segv>:
    3d00:	f3 0f 1e fa          	endbr64
    3d04:	48 83 ec 28          	sub    $0x28,%rsp
    3d08:	48 8b 05 d1 3a 06 00 	mov    0x63ad1(%rip),%rax        # 677e0 <fwp_cur>
    3d0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d13:	41 89 f8             	mov    %edi,%r8d
    3d16:	48 85 c0             	test   %rax,%rax
    3d19:	74 6d                	je     3d88 <fwp_segv+0x88>
    3d1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d1f:	48 85 d2             	test   %rdx,%rdx
    3d22:	74 64                	je     3d88 <fwp_segv+0x88>
    3d24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d37:	e8 c4 f8 ff ff       	call   3600 <sysconf@plt>
    3d3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d4b:	48 01 d0             	add    %rdx,%rax
    3d4e:	48 39 c1             	cmp    %rax,%rcx
    3d51:	b8 00 00 00 00       	mov    $0x0,%eax
    3d56:	40 0f 92 c6          	setb   %sil
    3d5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d61:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d65:	31 c0                	xor    %eax,%eax
    3d67:	48 39 d1             	cmp    %rdx,%rcx
    3d6a:	0f 93 c0             	setae  %al
    3d6d:	21 f0                	and    %esi,%eax
    3d6f:	85 c0                	test   %eax,%eax
    3d71:	75 4a                	jne    3dbd <fwp_segv+0xbd>
    3d73:	31 f6                	xor    %esi,%esi
    3d75:	44 89 c7             	mov    %r8d,%edi
    3d78:	48 83 c4 28          	add    $0x28,%rsp
    3d7c:	e9 9f f7 ff ff       	jmp    3520 <signal@plt>
    3d81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d88:	48 8b 05 19 34 06 00 	mov    0x63419(%rip),%rax        # 671a8 <fwp_main_stack_top>
    3d8f:	48 85 c0             	test   %rax,%rax
    3d92:	74 df                	je     3d73 <fwp_segv+0x73>
    3d94:	48 2b 05 05 34 06 00 	sub    0x63405(%rip),%rax        # 671a0 <fwp_main_stack_size>
    3d9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3da2:	48 39 d1             	cmp    %rdx,%rcx
    3da5:	0f 93 c2             	setae  %dl
    3da8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dae:	48 39 c1             	cmp    %rax,%rcx
    3db1:	0f 92 c0             	setb   %al
    3db4:	0f b6 c0             	movzbl %al,%eax
    3db7:	21 d0                	and    %edx,%eax
    3db9:	85 c0                	test   %eax,%eax
    3dbb:	74 b6                	je     3d73 <fwp_segv+0x73>
    3dbd:	e8 fe fe ff ff       	call   3cc0 <fwp_flush>
    3dc2:	bf 02 00 00 00       	mov    $0x2,%edi
    3dc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dcc:	48 8d 35 9d 7e 00 00 	lea    0x7e9d(%rip),%rsi        # bc70 <msg.4>
    3dd3:	e8 38 f6 ff ff       	call   3410 <write@plt>
    3dd8:	bf 65 00 00 00       	mov    $0x65,%edi
    3ddd:	e8 de f5 ff ff       	call   33c0 <_exit@plt>
    3de2:	0f 1f 00             	nopl   (%rax)
    3de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3dec:	00 00 00 00 

0000000000003df0 <fwp_heap_oom>:
    3df0:	50                   	push   %rax
    3df1:	58                   	pop    %rax
    3df2:	ba 13 00 00 00       	mov    $0x13,%edx
    3df7:	be 01 00 00 00       	mov    $0x1,%esi
    3dfc:	48 8d 3d 05 72 00 00 	lea    0x7205(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e03:	48 83 ec 08          	sub    $0x8,%rsp
    3e07:	48 8b 0d 32 b2 00 00 	mov    0xb232(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e0e:	e8 2d f8 ff ff       	call   3640 <fwrite@plt>
    3e13:	31 ff                	xor    %edi,%edi
    3e15:	e8 76 f7 ff ff       	call   3590 <fflush@plt>
    3e1a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e1f:	e8 3c f8 ff ff       	call   3660 <_Exit@plt>
    3e24:	90                   	nop
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_chunks>:
    3e30:	41 54                	push   %r12
    3e32:	55                   	push   %rbp
    3e33:	53                   	push   %rbx
    3e34:	48 83 ff 01          	cmp    $0x1,%rdi
    3e38:	0f 84 62 01 00 00    	je     3fa0 <fwp_heap_chunks+0x170>
    3e3e:	48 8b 05 ab 4d 06 00 	mov    0x64dab(%rip),%rax        # 68bf0 <fwp_heap+0x13f0>
    3e45:	4c 8d 05 a4 4d 06 00 	lea    0x64da4(%rip),%r8        # 68bf0 <fwp_heap+0x13f0>
    3e4c:	48 8b 1d 85 4d 06 00 	mov    0x64d85(%rip),%rbx        # 68bd8 <fwp_heap+0x13d8>
    3e53:	48 39 d8             	cmp    %rbx,%rax
    3e56:	0f 83 57 01 00 00    	jae    3fb3 <fwp_heap_chunks+0x183>
    3e5c:	48 8b 0d 95 4d 06 00 	mov    0x64d95(%rip),%rcx        # 68bf8 <fwp_heap+0x13f8>
    3e63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e67:	31 f6                	xor    %esi,%esi
    3e69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e6d:	eb 1e                	jmp    3e8d <fwp_heap_chunks+0x5d>
    3e6f:	90                   	nop
    3e70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e74:	48 39 cf             	cmp    %rcx,%rdi
    3e77:	0f 84 03 01 00 00    	je     3f80 <fwp_heap_chunks+0x150>
    3e7d:	48 83 c0 01          	add    $0x1,%rax
    3e81:	48 89 ce             	mov    %rcx,%rsi
    3e84:	48 83 c2 28          	add    $0x28,%rdx
    3e88:	48 39 c3             	cmp    %rax,%rbx
    3e8b:	74 14                	je     3ea1 <fwp_heap_chunks+0x71>
    3e8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e90:	74 de                	je     3e70 <fwp_heap_chunks+0x40>
    3e92:	48 83 c0 01          	add    $0x1,%rax
    3e96:	31 f6                	xor    %esi,%esi
    3e98:	48 83 c2 28          	add    $0x28,%rdx
    3e9c:	48 39 c3             	cmp    %rax,%rbx
    3e9f:	75 ec                	jne    3e8d <fwp_heap_chunks+0x5d>
    3ea1:	48 29 f3             	sub    %rsi,%rbx
    3ea4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ea8:	48 8b 3d 31 4d 06 00 	mov    0x64d31(%rip),%rdi        # 68be0 <fwp_heap+0x13e0>
    3eaf:	48 29 35 7a 4d 06 00 	sub    %rsi,0x64d7a(%rip)        # 68c30 <fwp_heap+0x1430>
    3eb6:	48 39 ef             	cmp    %rbp,%rdi
    3eb9:	0f 83 96 00 00 00    	jae    3f55 <fwp_heap_chunks+0x125>
    3ebf:	48 8b 05 0a 4d 06 00 	mov    0x64d0a(%rip),%rax        # 68bd0 <fwp_heap+0x13d0>
    3ec6:	48 39 e8             	cmp    %rbp,%rax
    3ec9:	0f 82 eb 00 00 00    	jb     3fba <fwp_heap_chunks+0x18a>
    3ecf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ed3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ed8:	49 39 c4             	cmp    %rax,%r12
    3edb:	4c 0f 47 e0          	cmova  %rax,%r12
    3edf:	4c 89 e6             	mov    %r12,%rsi
    3ee2:	48 29 fe             	sub    %rdi,%rsi
    3ee5:	48 c1 e7 10          	shl    $0x10,%rdi
    3ee9:	48 03 3d c0 4c 06 00 	add    0x64cc0(%rip),%rdi        # 68bb0 <fwp_heap+0x13b0>
    3ef0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ef4:	e8 e7 f6 ff ff       	call   35e0 <mprotect@plt>
    3ef9:	85 c0                	test   %eax,%eax
    3efb:	0f 85 b9 00 00 00    	jne    3fba <fwp_heap_chunks+0x18a>
    3f01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f06:	e8 f5 f6 ff ff       	call   3600 <sysconf@plt>
    3f0b:	48 8b 35 ce 4c 06 00 	mov    0x64cce(%rip),%rsi        # 68be0 <fwp_heap+0x13e0>
    3f12:	48 89 c1             	mov    %rax,%rcx
    3f15:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    3f1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f20:	48 89 ca             	mov    %rcx,%rdx
    3f23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f2b:	48 f7 da             	neg    %rdx
    3f2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f33:	48 21 d7             	and    %rdx,%rdi
    3f36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f3a:	48 21 d6             	and    %rdx,%rsi
    3f3d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f42:	48 29 fe             	sub    %rdi,%rsi
    3f45:	e8 96 f6 ff ff       	call   35e0 <mprotect@plt>
    3f4a:	85 c0                	test   %eax,%eax
    3f4c:	75 6c                	jne    3fba <fwp_heap_chunks+0x18a>
    3f4e:	4c 89 25 8b 4c 06 00 	mov    %r12,0x64c8b(%rip)        # 68be0 <fwp_heap+0x13e0>
    3f55:	48 89 ef             	mov    %rbp,%rdi
    3f58:	48 89 2d 79 4c 06 00 	mov    %rbp,0x64c79(%rip)        # 68bd8 <fwp_heap+0x13d8>
    3f5f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f63:	48 39 3d 5e 4c 06 00 	cmp    %rdi,0x64c5e(%rip)        # 68bc8 <fwp_heap+0x13c8>
    3f6a:	73 07                	jae    3f73 <fwp_heap_chunks+0x143>
    3f6c:	48 89 3d 55 4c 06 00 	mov    %rdi,0x64c55(%rip)        # 68bc8 <fwp_heap+0x13c8>
    3f73:	48 89 d8             	mov    %rbx,%rax
    3f76:	5b                   	pop    %rbx
    3f77:	5d                   	pop    %rbp
    3f78:	41 5c                	pop    %r12
    3f7a:	c3                   	ret
    3f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f84:	48 29 f0             	sub    %rsi,%rax
    3f87:	48 89 c3             	mov    %rax,%rbx
    3f8a:	49 89 10             	mov    %rdx,(%r8)
    3f8d:	48 89 d8             	mov    %rbx,%rax
    3f90:	48 29 3d 99 4c 06 00 	sub    %rdi,0x64c99(%rip)        # 68c30 <fwp_heap+0x1430>
    3f97:	5b                   	pop    %rbx
    3f98:	5d                   	pop    %rbp
    3f99:	41 5c                	pop    %r12
    3f9b:	c3                   	ret
    3f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    3fa0:	48 8b 05 41 4c 06 00 	mov    0x64c41(%rip),%rax        # 68be8 <fwp_heap+0x13e8>
    3fa7:	4c 8d 05 3a 4c 06 00 	lea    0x64c3a(%rip),%r8        # 68be8 <fwp_heap+0x13e8>
    3fae:	e9 99 fe ff ff       	jmp    3e4c <fwp_heap_chunks+0x1c>
    3fb3:	31 f6                	xor    %esi,%esi
    3fb5:	e9 ea fe ff ff       	jmp    3ea4 <fwp_heap_chunks+0x74>
    3fba:	e8 31 fe ff ff       	call   3df0 <fwp_heap_oom>
    3fbf:	90                   	nop

0000000000003fc0 <ad_raw_fail>:
    3fc0:	50                   	push   %rax
    3fc1:	58                   	pop    %rax
    3fc2:	48 8d 15 f7 76 00 00 	lea    0x76f7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fc9:	be 02 00 00 00       	mov    $0x2,%esi
    3fce:	31 c0                	xor    %eax,%eax
    3fd0:	48 83 ec 08          	sub    $0x8,%rsp
    3fd4:	48 89 f9             	mov    %rdi,%rcx
    3fd7:	48 8b 3d 62 b0 00 00 	mov    0xb062(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3fde:	e8 6d f6 ff ff       	call   3650 <__fprintf_chk@plt>
    3fe3:	bf e8 00 00 00       	mov    $0xe8,%edi
    3fe8:	e8 43 f6 ff ff       	call   3630 <exit@plt>
    3fed:	0f 1f 00             	nopl   (%rax)

0000000000003ff0 <buf_grow>:
    3ff0:	48 83 ec 18          	sub    $0x18,%rsp
    3ff4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3ff8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ffc:	74 7e                	je     407c <buf_grow+0x8c>
    3ffe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4005:	48 29 c2             	sub    %rax,%rdx
    4008:	48 39 f2             	cmp    %rsi,%rdx
    400b:	72 6f                	jb     407c <buf_grow+0x8c>
    400d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4012:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4016:	48 89 f9             	mov    %rdi,%rcx
    4019:	48 39 d0             	cmp    %rdx,%rax
    401c:	73 48                	jae    4066 <buf_grow+0x76>
    401e:	48 85 c0             	test   %rax,%rax
    4021:	75 15                	jne    4038 <buf_grow+0x48>
    4023:	48 83 fa 40          	cmp    $0x40,%rdx
    4027:	76 4c                	jbe    4075 <buf_grow+0x85>
    4029:	b8 40 00 00 00       	mov    $0x40,%eax
    402e:	eb 08                	jmp    4038 <buf_grow+0x48>
    4030:	48 01 c0             	add    %rax,%rax
    4033:	48 39 d0             	cmp    %rdx,%rax
    4036:	73 38                	jae    4070 <buf_grow+0x80>
    4038:	48 85 c0             	test   %rax,%rax
    403b:	79 f3                	jns    4030 <buf_grow+0x40>
    403d:	48 8b 39             	mov    (%rcx),%rdi
    4040:	48 89 d6             	mov    %rdx,%rsi
    4043:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4048:	48 89 14 24          	mov    %rdx,(%rsp)
    404c:	e8 4f f5 ff ff       	call   35a0 <realloc@plt>
    4051:	48 8b 14 24          	mov    (%rsp),%rdx
    4055:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    405a:	48 85 c0             	test   %rax,%rax
    405d:	74 1d                	je     407c <buf_grow+0x8c>
    405f:	48 89 01             	mov    %rax,(%rcx)
    4062:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4066:	48 83 c4 18          	add    $0x18,%rsp
    406a:	c3                   	ret
    406b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4070:	48 89 c2             	mov    %rax,%rdx
    4073:	eb c8                	jmp    403d <buf_grow+0x4d>
    4075:	ba 40 00 00 00       	mov    $0x40,%edx
    407a:	eb c1                	jmp    403d <buf_grow+0x4d>
    407c:	48 8b 0d bd af 00 00 	mov    0xafbd(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    4083:	ba 13 00 00 00       	mov    $0x13,%edx
    4088:	be 01 00 00 00       	mov    $0x1,%esi
    408d:	48 8d 3d 74 6f 00 00 	lea    0x6f74(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4094:	e8 a7 f5 ff ff       	call   3640 <fwrite@plt>
    4099:	31 ff                	xor    %edi,%edi
    409b:	e8 f0 f4 ff ff       	call   3590 <fflush@plt>
    40a0:	bf 66 00 00 00       	mov    $0x66,%edi
    40a5:	e8 b6 f5 ff ff       	call   3660 <_Exit@plt>
    40aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040b0 <buf_put>:
    40b0:	41 54                	push   %r12
    40b2:	49 89 f4             	mov    %rsi,%r12
    40b5:	48 89 d6             	mov    %rdx,%rsi
    40b8:	55                   	push   %rbp
    40b9:	48 89 fd             	mov    %rdi,%rbp
    40bc:	53                   	push   %rbx
    40bd:	48 89 d3             	mov    %rdx,%rbx
    40c0:	e8 2b ff ff ff       	call   3ff0 <buf_grow>
    40c5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40c9:	48 89 da             	mov    %rbx,%rdx
    40cc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40d0:	4c 89 e6             	mov    %r12,%rsi
    40d3:	e8 98 f4 ff ff       	call   3570 <memcpy@plt>
    40d8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40dc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40e0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40e4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40e8:	5b                   	pop    %rbx
    40e9:	5d                   	pop    %rbp
    40ea:	41 5c                	pop    %r12
    40ec:	c3                   	ret
    40ed:	0f 1f 00             	nopl   (%rax)

00000000000040f0 <fwp_cancel_tree.part.0>:
    40f0:	48 3b 3d e9 36 06 00 	cmp    0x636e9(%rip),%rdi        # 677e0 <fwp_cur>
    40f7:	53                   	push   %rbx
    40f8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40fc:	74 35                	je     4133 <fwp_cancel_tree.part.0+0x43>
    40fe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4102:	75 2f                	jne    4133 <fwp_cancel_tree.part.0+0x43>
    4104:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4108:	75 29                	jne    4133 <fwp_cancel_tree.part.0+0x43>
    410a:	48 8b 05 af 36 06 00 	mov    0x636af(%rip),%rax        # 677c0 <fwp_ready_tail>
    4111:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4115:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    411c:	00 00 00 00 
    4120:	48 85 c0             	test   %rax,%rax
    4123:	74 33                	je     4158 <fwp_cancel_tree.part.0+0x68>
    4125:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    412c:	48 89 3d 8d 36 06 00 	mov    %rdi,0x6368d(%rip)        # 677c0 <fwp_ready_tail>
    4133:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4137:	48 85 db             	test   %rbx,%rbx
    413a:	74 17                	je     4153 <fwp_cancel_tree.part.0+0x63>
    413c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4140:	75 08                	jne    414a <fwp_cancel_tree.part.0+0x5a>
    4142:	48 89 df             	mov    %rbx,%rdi
    4145:	e8 a6 ff ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    414a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    414e:	48 85 db             	test   %rbx,%rbx
    4151:	75 e9                	jne    413c <fwp_cancel_tree.part.0+0x4c>
    4153:	5b                   	pop    %rbx
    4154:	c3                   	ret
    4155:	0f 1f 00             	nopl   (%rax)
    4158:	48 89 3d 69 36 06 00 	mov    %rdi,0x63669(%rip)        # 677c8 <fwp_ready_head>
    415f:	eb cb                	jmp    412c <fwp_cancel_tree.part.0+0x3c>
    4161:	0f 1f 40 00          	nopl   0x0(%rax)
    4165:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    416c:	00 00 00 00 

0000000000004170 <fwp_finish_float>:
    4170:	53                   	push   %rbx
    4171:	be 2e 00 00 00       	mov    $0x2e,%esi
    4176:	48 89 fb             	mov    %rdi,%rbx
    4179:	e8 e2 f2 ff ff       	call   3460 <strchr@plt>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	74 05                	je     4188 <fwp_finish_float+0x18>
    4183:	5b                   	pop    %rbx
    4184:	c3                   	ret
    4185:	0f 1f 00             	nopl   (%rax)
    4188:	be 65 00 00 00       	mov    $0x65,%esi
    418d:	48 89 df             	mov    %rbx,%rdi
    4190:	e8 cb f2 ff ff       	call   3460 <strchr@plt>
    4195:	48 85 c0             	test   %rax,%rax
    4198:	75 e9                	jne    4183 <fwp_finish_float+0x13>
    419a:	48 8d 35 5b 70 00 00 	lea    0x705b(%rip),%rsi        # b1fc <_IO_stdin_used+0x1fc>
    41a1:	48 89 df             	mov    %rbx,%rdi
    41a4:	e8 e7 f4 ff ff       	call   3690 <strstr@plt>
    41a9:	48 85 c0             	test   %rax,%rax
    41ac:	75 d5                	jne    4183 <fwp_finish_float+0x13>
    41ae:	48 8d 35 67 6e 00 00 	lea    0x6e67(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41b5:	48 89 df             	mov    %rbx,%rdi
    41b8:	e8 d3 f4 ff ff       	call   3690 <strstr@plt>
    41bd:	48 85 c0             	test   %rax,%rax
    41c0:	75 c1                	jne    4183 <fwp_finish_float+0x13>
    41c2:	48 89 df             	mov    %rbx,%rdi
    41c5:	e8 66 f2 ff ff       	call   3430 <strlen@plt>
    41ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41d8:	5b                   	pop    %rbx
    41d9:	c3                   	ret
    41da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041e0 <ad_raw_report>:
    41e0:	f3 0f 1e fa          	endbr64
    41e4:	41 57                	push   %r15
    41e6:	41 56                	push   %r14
    41e8:	41 55                	push   %r13
    41ea:	41 54                	push   %r12
    41ec:	55                   	push   %rbp
    41ed:	53                   	push   %rbx
    41ee:	48 83 ec 38          	sub    $0x38,%rsp
    41f2:	66 0f 6f 05 96 af 04 	movdqa 0x4af96(%rip),%xmm0        # 4f190 <ad_raw_live+0x10>
    41f9:	00 
    41fa:	66 0f d4 05 7e af 04 	paddq  0x4af7e(%rip),%xmm0        # 4f180 <ad_raw_live>
    4201:	00 
    4202:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4209:	00 00 
    420b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4210:	31 c0                	xor    %eax,%eax
    4212:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4216:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    421b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    421f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4224:	48 85 ed             	test   %rbp,%rbp
    4227:	0f 85 d2 01 00 00    	jne    43ff <ad_raw_report+0x21f>
    422d:	4c 8b 05 b4 ae 01 00 	mov    0x1aeb4(%rip),%r8        # 1f0e8 <ad_raw_before_shutdown>
    4234:	45 31 c9             	xor    %r9d,%r9d
    4237:	31 c0                	xor    %eax,%eax
    4239:	31 db                	xor    %ebx,%ebx
    423b:	48 8b 0d be ae 04 00 	mov    0x4aebe(%rip),%rcx        # 4f100 <ad_raw_total_peak>
    4242:	48 8b 3d f7 ad 00 00 	mov    0xadf7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4249:	49 89 e4             	mov    %rsp,%r12
    424c:	48 8d 15 bd 74 00 00 	lea    0x74bd(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4253:	be 02 00 00 00       	mov    $0x2,%esi
    4258:	4c 8d 3d 01 af 04 00 	lea    0x4af01(%rip),%r15        # 4f160 <ad_raw_peak>
    425f:	4c 8d 35 ba ae 04 00 	lea    0x4aeba(%rip),%r14        # 4f120 <ad_raw_bytes>
    4266:	e8 e5 f3 ff ff       	call   3650 <__fprintf_chk@plt>
    426b:	48 8d 05 b9 6d 00 00 	lea    0x6db9(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4272:	f3 0f 7e 05 96 a9 00 	movq   0xa996(%rip),%xmm0        # ec10 <d0+0x70>
    4279:	00 
    427a:	4c 8d 2d bf ae 04 00 	lea    0x4aebf(%rip),%r13        # 4f140 <ad_raw_requests>
    4281:	66 48 0f 6e d0       	movq   %rax,%xmm2
    4286:	48 8d 05 b1 6d 00 00 	lea    0x6db1(%rip),%rax        # b03e <_IO_stdin_used+0x3e>
    428d:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    4291:	66 48 0f 6e d8       	movq   %rax,%xmm3
    4296:	0f 29 04 24          	movaps %xmm0,(%rsp)
    429a:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec18 <d0+0x78>
    42a1:	00 
    42a2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42a6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42ab:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42af:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42b3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42b8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42bc:	48 85 db             	test   %rbx,%rbx
    42bf:	0f 84 0b 01 00 00    	je     43d0 <ad_raw_report+0x1f0>
    42c5:	52                   	push   %rdx
    42c6:	48 8b 3d 73 ad 00 00 	mov    0xad73(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42cd:	48 8d 0d 4c 6d 00 00 	lea    0x6d4c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42d4:	48 8d 15 95 74 00 00 	lea    0x7495(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42db:	50                   	push   %rax
    42dc:	be 02 00 00 00       	mov    $0x2,%esi
    42e1:	31 c0                	xor    %eax,%eax
    42e3:	48 83 c3 01          	add    $0x1,%rbx
    42e7:	e8 64 f3 ff ff       	call   3650 <__fprintf_chk@plt>
    42ec:	5f                   	pop    %rdi
    42ed:	41 58                	pop    %r8
    42ef:	48 83 fb 04          	cmp    $0x4,%rbx
    42f3:	75 b6                	jne    42ab <ad_raw_report+0xcb>
    42f5:	48 8b 0d 44 ad 00 00 	mov    0xad44(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    42fc:	ba 13 00 00 00       	mov    $0x13,%edx
    4301:	be 01 00 00 00       	mov    $0x1,%esi
    4306:	48 8d 3d 3a 6d 00 00 	lea    0x6d3a(%rip),%rdi        # b047 <_IO_stdin_used+0x47>
    430d:	e8 2e f3 ff ff       	call   3640 <fwrite@plt>
    4312:	48 83 3d d6 ad 01 00 	cmpq   $0x0,0x1add6(%rip)        # 1f0f0 <ad_raw_checkpoint_count>
    4319:	00 
    431a:	74 75                	je     4391 <ad_raw_report+0x1b1>
    431c:	4c 8b 05 dd ad 01 00 	mov    0x1addd(%rip),%r8        # 1f100 <ad_raw_checkpoints>
    4323:	4c 8b 0d de ad 01 00 	mov    0x1adde(%rip),%r9        # 1f108 <ad_raw_checkpoints+0x8>
    432a:	48 8d 1d cf ad 01 00 	lea    0x1adcf(%rip),%rbx        # 1f100 <ad_raw_checkpoints>
    4331:	48 8d 0d 36 6d 00 00 	lea    0x6d36(%rip),%rcx        # b06e <_IO_stdin_used+0x6e>
    4338:	48 8b 05 d1 ad 01 00 	mov    0x1add1(%rip),%rax        # 1f110 <ad_raw_checkpoints+0x10>
    433f:	4c 8d 25 da 6c 00 00 	lea    0x6cda(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4346:	eb 1b                	jmp    4363 <ad_raw_report+0x183>
    4348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    434f:	00 
    4350:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4354:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4358:	48 83 c3 18          	add    $0x18,%rbx
    435c:	4c 89 e1             	mov    %r12,%rcx
    435f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4363:	48 83 ec 08          	sub    $0x8,%rsp
    4367:	be 02 00 00 00       	mov    $0x2,%esi
    436c:	48 83 c5 01          	add    $0x1,%rbp
    4370:	48 8b 3d c9 ac 00 00 	mov    0xacc9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4377:	50                   	push   %rax
    4378:	48 8d 15 31 74 00 00 	lea    0x7431(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    437f:	31 c0                	xor    %eax,%eax
    4381:	e8 ca f2 ff ff       	call   3650 <__fprintf_chk@plt>
    4386:	48 3b 2d 63 ad 01 00 	cmp    0x1ad63(%rip),%rbp        # 1f0f0 <ad_raw_checkpoint_count>
    438d:	59                   	pop    %rcx
    438e:	5e                   	pop    %rsi
    438f:	72 bf                	jb     4350 <ad_raw_report+0x170>
    4391:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    4396:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    439d:	00 00 
    439f:	75 6a                	jne    440b <ad_raw_report+0x22b>
    43a1:	48 8b 0d 98 ac 00 00 	mov    0xac98(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43a8:	48 83 c4 38          	add    $0x38,%rsp
    43ac:	ba 04 00 00 00       	mov    $0x4,%edx
    43b1:	be 01 00 00 00       	mov    $0x1,%esi
    43b6:	5b                   	pop    %rbx
    43b7:	48 8d 3d 9d 6c 00 00 	lea    0x6c9d(%rip),%rdi        # b05b <_IO_stdin_used+0x5b>
    43be:	5d                   	pop    %rbp
    43bf:	41 5c                	pop    %r12
    43c1:	41 5d                	pop    %r13
    43c3:	41 5e                	pop    %r14
    43c5:	41 5f                	pop    %r15
    43c7:	e9 74 f2 ff ff       	jmp    3640 <fwrite@plt>
    43cc:	0f 1f 40 00          	nopl   0x0(%rax)
    43d0:	52                   	push   %rdx
    43d1:	be 02 00 00 00       	mov    $0x2,%esi
    43d6:	48 8b 3d 63 ac 00 00 	mov    0xac63(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43dd:	48 8d 15 8c 73 00 00 	lea    0x738c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    43e4:	50                   	push   %rax
    43e5:	48 8d 0d 82 6c 00 00 	lea    0x6c82(%rip),%rcx        # b06e <_IO_stdin_used+0x6e>
    43ec:	31 c0                	xor    %eax,%eax
    43ee:	bb 01 00 00 00       	mov    $0x1,%ebx
    43f3:	e8 58 f2 ff ff       	call   3650 <__fprintf_chk@plt>
    43f8:	58                   	pop    %rax
    43f9:	5a                   	pop    %rdx
    43fa:	e9 ac fe ff ff       	jmp    42ab <ad_raw_report+0xcb>
    43ff:	48 8d 3d e2 72 00 00 	lea    0x72e2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4406:	e8 b5 fb ff ff       	call   3fc0 <ad_raw_fail>
    440b:	e8 30 f0 ff ff       	call   3440 <__stack_chk_fail@plt>

0000000000004410 <fwp_trap>:
    4410:	55                   	push   %rbp
    4411:	48 89 fd             	mov    %rdi,%rbp
    4414:	53                   	push   %rbx
    4415:	48 83 ec 08          	sub    $0x8,%rsp
    4419:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4420:	ff ff 
    4422:	e8 99 f8 ff ff       	call   3cc0 <fwp_flush>
    4427:	31 c0                	xor    %eax,%eax
    4429:	48 89 e9             	mov    %rbp,%rcx
    442c:	be 02 00 00 00       	mov    $0x2,%esi
    4431:	48 8b 3d 08 ac 00 00 	mov    0xac08(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4438:	48 8d 15 21 6c 00 00 	lea    0x6c21(%rip),%rdx        # b060 <_IO_stdin_used+0x60>
    443f:	e8 0c f2 ff ff       	call   3650 <__fprintf_chk@plt>
    4444:	48 85 db             	test   %rbx,%rbx
    4447:	74 16                	je     445f <fwp_trap+0x4f>
    4449:	48 8b 3d f0 ab 00 00 	mov    0xabf0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4450:	e8 3b f1 ff ff       	call   3590 <fflush@plt>
    4455:	bf 65 00 00 00       	mov    $0x65,%edi
    445a:	e8 01 f2 ff ff       	call   3660 <_Exit@plt>
    445f:	bf 65 00 00 00       	mov    $0x65,%edi
    4464:	e8 c7 f1 ff ff       	call   3630 <exit@plt>
    4469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004470 <fwp_closure_drop_push>:
    4470:	41 56                	push   %r14
    4472:	41 54                	push   %r12
    4474:	49 89 f4             	mov    %rsi,%r12
    4477:	55                   	push   %rbp
    4478:	48 89 fd             	mov    %rdi,%rbp
    447b:	53                   	push   %rbx
    447c:	48 83 ec 18          	sub    $0x18,%rsp
    4480:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4484:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4488:	74 26                	je     44b0 <fwp_closure_drop_push+0x40>
    448a:	4c 8b 07             	mov    (%rdi),%r8
    448d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4494:	00 
    4495:	48 83 c3 01          	add    $0x1,%rbx
    4499:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    449d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44a1:	48 83 c4 18          	add    $0x18,%rsp
    44a5:	5b                   	pop    %rbx
    44a6:	5d                   	pop    %rbp
    44a7:	41 5c                	pop    %r12
    44a9:	41 5e                	pop    %r14
    44ab:	c3                   	ret
    44ac:	0f 1f 40 00          	nopl   0x0(%rax)
    44b0:	48 89 d8             	mov    %rbx,%rax
    44b3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44b7:	0f 85 a9 00 00 00    	jne    4566 <fwp_closure_drop_push+0xf6>
    44bd:	48 89 d9             	mov    %rbx,%rcx
    44c0:	48 c1 e1 04          	shl    $0x4,%rcx
    44c4:	48 89 cf             	mov    %rcx,%rdi
    44c7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44cb:	e8 b0 f0 ff ff       	call   3580 <malloc@plt>
    44d0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44d4:	48 85 c0             	test   %rax,%rax
    44d7:	74 5f                	je     4538 <fwp_closure_drop_push+0xc8>
    44d9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44dd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44e4:	00 
    44e5:	48 89 c7             	mov    %rax,%rdi
    44e8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44ec:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44f1:	48 89 34 24          	mov    %rsi,(%rsp)
    44f5:	e8 46 f0 ff ff       	call   3540 <__memcpy_chk@plt>
    44fa:	48 8b 34 24          	mov    (%rsp),%rsi
    44fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4503:	49 89 c0             	mov    %rax,%r8
    4506:	48 8d 45 18          	lea    0x18(%rbp),%rax
    450a:	48 39 c6             	cmp    %rax,%rsi
    450d:	74 1c                	je     452b <fwp_closure_drop_push+0xbb>
    450f:	48 89 f7             	mov    %rsi,%rdi
    4512:	4c 89 04 24          	mov    %r8,(%rsp)
    4516:	e8 85 ee ff ff       	call   33a0 <free@plt>
    451b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    451f:	4c 8b 04 24          	mov    (%rsp),%r8
    4523:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    452a:	00 
    452b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    452f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4533:	e9 5d ff ff ff       	jmp    4495 <fwp_closure_drop_push+0x25>
    4538:	48 8b 0d 01 ab 00 00 	mov    0xab01(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    453f:	ba 13 00 00 00       	mov    $0x13,%edx
    4544:	be 01 00 00 00       	mov    $0x1,%esi
    4549:	48 8d 3d b8 6a 00 00 	lea    0x6ab8(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4550:	e8 eb f0 ff ff       	call   3640 <fwrite@plt>
    4555:	31 ff                	xor    %edi,%edi
    4557:	e8 34 f0 ff ff       	call   3590 <fflush@plt>
    455c:	bf 66 00 00 00       	mov    $0x66,%edi
    4561:	e8 fa f0 ff ff       	call   3660 <_Exit@plt>
    4566:	48 8d 3d 02 6b 00 00 	lea    0x6b02(%rip),%rdi        # b06f <_IO_stdin_used+0x6f>
    456d:	e8 9e fe ff ff       	call   4410 <fwp_trap>
    4572:	0f 1f 00             	nopl   (%rax)
    4575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    457c:	00 00 00 00 

0000000000004580 <fwp_now_ns>:
    4580:	53                   	push   %rbx
    4581:	bf 01 00 00 00       	mov    $0x1,%edi
    4586:	48 83 ec 20          	sub    $0x20,%rsp
    458a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4591:	00 00 
    4593:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4598:	31 db                	xor    %ebx,%ebx
    459a:	48 89 e6             	mov    %rsp,%rsi
    459d:	e8 5e ee ff ff       	call   3400 <clock_gettime@plt>
    45a2:	85 c0                	test   %eax,%eax
    45a4:	75 52                	jne    45f8 <fwp_now_ns+0x78>
    45a6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45ab:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45b0:	48 f7 2c 24          	imulq  (%rsp)
    45b4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45bb:	48 89 f7             	mov    %rsi,%rdi
    45be:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45c2:	48 01 f0             	add    %rsi,%rax
    45c5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45cc:	00 00 80 
    45cf:	48 11 fa             	adc    %rdi,%rdx
    45d2:	31 ff                	xor    %edi,%edi
    45d4:	48 01 c6             	add    %rax,%rsi
    45d7:	48 11 d7             	adc    %rdx,%rdi
    45da:	48 39 f1             	cmp    %rsi,%rcx
    45dd:	48 19 fb             	sbb    %rdi,%rbx
    45e0:	72 27                	jb     4609 <fwp_now_ns+0x89>
    45e2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45e7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ee:	00 00 
    45f0:	75 12                	jne    4604 <fwp_now_ns+0x84>
    45f2:	48 83 c4 20          	add    $0x20,%rsp
    45f6:	5b                   	pop    %rbx
    45f7:	c3                   	ret
    45f8:	48 8d 3d 8a 6a 00 00 	lea    0x6a8a(%rip),%rdi        # b089 <_IO_stdin_used+0x89>
    45ff:	e8 0c fe ff ff       	call   4410 <fwp_trap>
    4604:	e8 37 ee ff ff       	call   3440 <__stack_chk_fail@plt>
    4609:	48 8d 3d e0 71 00 00 	lea    0x71e0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4610:	e8 fb fd ff ff       	call   4410 <fwp_trap>
    4615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    461c:	00 00 00 00 

0000000000004620 <fwp_closure_drop.part.0>:
    4620:	53                   	push   %rbx
    4621:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4628:	66 0f 6f 05 60 76 00 	movdqa 0x7660(%rip),%xmm0        # bc90 <msg.4+0x20>
    462f:	00 
    4630:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4637:	00 00 
    4639:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4640:	00 
    4641:	48 89 fe             	mov    %rdi,%rsi
    4644:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4649:	48 89 e7             	mov    %rsp,%rdi
    464c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4650:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4655:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    465c:	ff ff 
    465e:	e8 0d fe ff ff       	call   4470 <fwp_closure_drop_push>
    4663:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4668:	48 85 c0             	test   %rax,%rax
    466b:	74 39                	je     46a6 <fwp_closure_drop.part.0+0x86>
    466d:	0f 1f 00             	nopl   (%rax)
    4670:	48 8b 14 24          	mov    (%rsp),%rdx
    4674:	48 83 e8 01          	sub    $0x1,%rax
    4678:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    467d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4681:	8b 07                	mov    (%rdi),%eax
    4683:	48 c1 e0 05          	shl    $0x5,%rax
    4687:	48 03 05 ca 4d 06 00 	add    0x64dca(%rip),%rax        # 69458 <fwp_fns>
    468e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4692:	48 85 c0             	test   %rax,%rax
    4695:	74 46                	je     46dd <fwp_closure_drop.part.0+0xbd>
    4697:	31 f6                	xor    %esi,%esi
    4699:	ff 50 08             	call   *0x8(%rax)
    469c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a1:	48 85 c0             	test   %rax,%rax
    46a4:	75 ca                	jne    4670 <fwp_closure_drop.part.0+0x50>
    46a6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ad:	ff ff 00 00 00 00 
    46b3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46b7:	48 39 df             	cmp    %rbx,%rdi
    46ba:	74 05                	je     46c1 <fwp_closure_drop.part.0+0xa1>
    46bc:	e8 df ec ff ff       	call   33a0 <free@plt>
    46c1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46c8:	00 
    46c9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46d0:	00 00 
    46d2:	75 15                	jne    46e9 <fwp_closure_drop.part.0+0xc9>
    46d4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46db:	5b                   	pop    %rbx
    46dc:	c3                   	ret
    46dd:	48 8d 3d 34 71 00 00 	lea    0x7134(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    46e4:	e8 27 fd ff ff       	call   4410 <fwp_trap>
    46e9:	e8 52 ed ff ff       	call   3440 <__stack_chk_fail@plt>
    46ee:	66 90                	xchg   %ax,%ax

00000000000046f0 <fwp_tape_of>:
    46f0:	0f b7 d7             	movzwl %di,%edx
    46f3:	48 85 d2             	test   %rdx,%rdx
    46f6:	74 28                	je     4720 <fwp_tape_of+0x30>
    46f8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46fc:	48 39 05 d5 a9 01 00 	cmp    %rax,0x1a9d5(%rip)        # 1f0d8 <fwp_ntapes>
    4703:	7e 1b                	jle    4720 <fwp_tape_of+0x30>
    4705:	48 6b c0 58          	imul   $0x58,%rax,%rax
    4709:	48 03 05 d0 a9 01 00 	add    0x1a9d0(%rip),%rax        # 1f0e0 <fwp_tapes>
    4710:	8b 50 04             	mov    0x4(%rax),%edx
    4713:	85 d2                	test   %edx,%edx
    4715:	74 09                	je     4720 <fwp_tape_of+0x30>
    4717:	48 c1 ff 10          	sar    $0x10,%rdi
    471b:	39 38                	cmp    %edi,(%rax)
    471d:	75 01                	jne    4720 <fwp_tape_of+0x30>
    471f:	c3                   	ret
    4720:	48 83 ec 08          	sub    $0x8,%rsp
    4724:	48 8d 3d 1d 71 00 00 	lea    0x711d(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    472b:	e8 e0 fc ff ff       	call   4410 <fwp_trap>

0000000000004730 <fwp_format_g.constprop.0>:
    4730:	41 57                	push   %r15
    4732:	b9 40 00 00 00       	mov    $0x40,%ecx
    4737:	ba 02 00 00 00       	mov    $0x2,%edx
    473c:	4c 8d 05 62 69 00 00 	lea    0x6962(%rip),%r8        # b0a5 <_IO_stdin_used+0xa5>
    4743:	41 56                	push   %r14
    4745:	b8 01 00 00 00       	mov    $0x1,%eax
    474a:	41 55                	push   %r13
    474c:	41 54                	push   %r12
    474e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4752:	55                   	push   %rbp
    4753:	45 89 e1             	mov    %r12d,%r9d
    4756:	53                   	push   %rbx
    4757:	48 89 fb             	mov    %rdi,%rbx
    475a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4761:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4768:	00 00 
    476a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4771:	00 
    4772:	41 89 f7             	mov    %esi,%r15d
    4775:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    477a:	be 40 00 00 00       	mov    $0x40,%esi
    477f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4784:	4c 89 f7             	mov    %r14,%rdi
    4787:	e8 04 ec ff ff       	call   3390 <__snprintf_chk@plt>
    478c:	be 65 00 00 00       	mov    $0x65,%esi
    4791:	4c 89 f7             	mov    %r14,%rdi
    4794:	e8 c7 ec ff ff       	call   3460 <strchr@plt>
    4799:	31 f6                	xor    %esi,%esi
    479b:	ba 0a 00 00 00       	mov    $0xa,%edx
    47a0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47a4:	48 89 c5             	mov    %rax,%rbp
    47a7:	e8 b4 ed ff ff       	call   3560 <strtol@plt>
    47ac:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47b1:	49 89 c0             	mov    %rax,%r8
    47b4:	83 c0 05             	add    $0x5,%eax
    47b7:	83 f8 15             	cmp    $0x15,%eax
    47ba:	0f 87 e0 01 00 00    	ja     49a0 <fwp_format_g.constprop.0+0x270>
    47c0:	45 89 e5             	mov    %r12d,%r13d
    47c3:	45 29 c5             	sub    %r8d,%r13d
    47c6:	45 85 ed             	test   %r13d,%r13d
    47c9:	0f 8e 21 01 00 00    	jle    48f0 <fwp_format_g.constprop.0+0x1c0>
    47cf:	41 83 ff 01          	cmp    $0x1,%r15d
    47d3:	0f 84 17 01 00 00    	je     48f0 <fwp_format_g.constprop.0+0x1c0>
    47d9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47de:	31 d2                	xor    %edx,%edx
    47e0:	4d 63 df             	movslq %r15d,%r11
    47e3:	3c 2d                	cmp    $0x2d,%al
    47e5:	0f 94 c2             	sete   %dl
    47e8:	4c 29 dd             	sub    %r11,%rbp
    47eb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47ef:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47f3:	4d 89 f1             	mov    %r14,%r9
    47f6:	4d 29 d1             	sub    %r10,%r9
    47f9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47fd:	3c 2d                	cmp    $0x2d,%al
    47ff:	0f 84 fb 03 00 00    	je     4c00 <fwp_format_g.constprop.0+0x4d0>
    4805:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    480a:	b9 48 00 00 00       	mov    $0x48,%ecx
    480f:	48 89 e8             	mov    %rbp,%rax
    4812:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4816:	49 8d 72 01          	lea    0x1(%r10),%rsi
    481a:	49 83 c1 47          	add    $0x47,%r9
    481e:	45 85 c0             	test   %r8d,%r8d
    4821:	0f 88 f1 02 00 00    	js     4b18 <fwp_format_g.constprop.0+0x3e8>
    4827:	45 0f b6 12          	movzbl (%r10),%r10d
    482b:	4d 63 e0             	movslq %r8d,%r12
    482e:	44 88 10             	mov    %r10b,(%rax)
    4831:	41 83 f8 07          	cmp    $0x7,%r8d
    4835:	0f 87 2d 02 00 00    	ja     4a68 <fwp_format_g.constprop.0+0x338>
    483b:	41 f6 c4 04          	test   $0x4,%r12b
    483f:	0f 85 f2 03 00 00    	jne    4c37 <fwp_format_g.constprop.0+0x507>
    4845:	45 85 e4             	test   %r12d,%r12d
    4848:	74 12                	je     485c <fwp_format_g.constprop.0+0x12c>
    484a:	45 0f b6 06          	movzbl (%r14),%r8d
    484e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4852:	41 f6 c4 02          	test   $0x2,%r12b
    4856:	0f 85 03 04 00 00    	jne    4c5f <fwp_format_g.constprop.0+0x52f>
    485c:	4c 29 e1             	sub    %r12,%rcx
    485f:	4c 01 e7             	add    %r12,%rdi
    4862:	4c 89 fa             	mov    %r15,%rdx
    4865:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    486a:	48 83 e9 01          	sub    $0x1,%rcx
    486e:	4d 63 ed             	movslq %r13d,%r13
    4871:	48 89 0c 24          	mov    %rcx,(%rsp)
    4875:	e8 c6 ec ff ff       	call   3540 <__memcpy_chk@plt>
    487a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    487f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4883:	ba 48 00 00 00       	mov    $0x48,%edx
    4888:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    488c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4890:	4c 89 c8             	mov    %r9,%rax
    4893:	48 29 c8             	sub    %rcx,%rax
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 42 c2          	cmovb  %rdx,%rax
    489d:	4c 29 c9             	sub    %r9,%rcx
    48a0:	4c 89 ea             	mov    %r13,%rdx
    48a3:	48 01 c1             	add    %rax,%rcx
    48a6:	e8 95 ec ff ff       	call   3540 <__memcpy_chk@plt>
    48ab:	4c 01 e8             	add    %r13,%rax
    48ae:	48 29 e8             	sub    %rbp,%rax
    48b1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 47 c2          	cmova  %rdx,%rax
    48bd:	89 c1                	mov    %eax,%ecx
    48bf:	83 f8 08             	cmp    $0x8,%eax
    48c2:	0f 83 18 02 00 00    	jae    4ae0 <fwp_format_g.constprop.0+0x3b0>
    48c8:	a8 04                	test   $0x4,%al
    48ca:	0f 85 54 03 00 00    	jne    4c24 <fwp_format_g.constprop.0+0x4f4>
    48d0:	85 c0                	test   %eax,%eax
    48d2:	74 0f                	je     48e3 <fwp_format_g.constprop.0+0x1b3>
    48d4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48d9:	88 13                	mov    %dl,(%rbx)
    48db:	a8 02                	test   $0x2,%al
    48dd:	0f 85 6b 03 00 00    	jne    4c4e <fwp_format_g.constprop.0+0x51e>
    48e3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48e7:	eb 36                	jmp    491f <fwp_format_g.constprop.0+0x1ef>
    48e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48f0:	45 31 c9             	xor    %r9d,%r9d
    48f3:	45 85 ed             	test   %r13d,%r13d
    48f6:	4c 8d 05 b7 67 00 00 	lea    0x67b7(%rip),%r8        # b0b4 <_IO_stdin_used+0xb4>
    48fd:	48 89 df             	mov    %rbx,%rdi
    4900:	45 0f 49 cd          	cmovns %r13d,%r9d
    4904:	ba 02 00 00 00       	mov    $0x2,%edx
    4909:	be 90 01 00 00       	mov    $0x190,%esi
    490e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4915:	b8 01 00 00 00       	mov    $0x1,%eax
    491a:	e8 71 ea ff ff       	call   3390 <__snprintf_chk@plt>
    491f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4924:	48 89 df             	mov    %rbx,%rdi
    4927:	e8 34 eb ff ff       	call   3460 <strchr@plt>
    492c:	48 85 c0             	test   %rax,%rax
    492f:	74 3f                	je     4970 <fwp_format_g.constprop.0+0x240>
    4931:	48 89 df             	mov    %rbx,%rdi
    4934:	e8 f7 ea ff ff       	call   3430 <strlen@plt>
    4939:	48 85 c0             	test   %rax,%rax
    493c:	75 0b                	jne    4949 <fwp_format_g.constprop.0+0x219>
    493e:	eb 30                	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4940:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4944:	48 85 c0             	test   %rax,%rax
    4947:	74 27                	je     4970 <fwp_format_g.constprop.0+0x240>
    4949:	48 89 c2             	mov    %rax,%rdx
    494c:	48 83 e8 01          	sub    $0x1,%rax
    4950:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4954:	74 ea                	je     4940 <fwp_format_g.constprop.0+0x210>
    4956:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    495b:	0f 84 6f 01 00 00    	je     4ad0 <fwp_format_g.constprop.0+0x3a0>
    4961:	0f 1f 40 00          	nopl   0x0(%rax)
    4965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    496c:	00 00 00 00 
    4970:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4977:	00 
    4978:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    497f:	00 00 
    4981:	0f 85 ec 02 00 00    	jne    4c73 <fwp_format_g.constprop.0+0x543>
    4987:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    498e:	5b                   	pop    %rbx
    498f:	5d                   	pop    %rbp
    4990:	41 5c                	pop    %r12
    4992:	41 5d                	pop    %r13
    4994:	41 5e                	pop    %r14
    4996:	41 5f                	pop    %r15
    4998:	c3                   	ret
    4999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49a0:	4c 29 f5             	sub    %r14,%rbp
    49a3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49a8:	4c 89 f6             	mov    %r14,%rsi
    49ab:	4c 89 04 24          	mov    %r8,(%rsp)
    49af:	49 89 ec             	mov    %rbp,%r12
    49b2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b7:	4c 89 e2             	mov    %r12,%rdx
    49ba:	48 89 ef             	mov    %rbp,%rdi
    49bd:	e8 7e eb ff ff       	call   3540 <__memcpy_chk@plt>
    49c2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49c8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49cd:	48 89 ef             	mov    %rbp,%rdi
    49d0:	e8 8b ea ff ff       	call   3460 <strchr@plt>
    49d5:	4c 8b 04 24          	mov    (%rsp),%r8
    49d9:	48 85 c0             	test   %rax,%rax
    49dc:	74 40                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    49de:	4d 85 e4             	test   %r12,%r12
    49e1:	74 3b                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    49e3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49e8:	eb 23                	jmp    4a0d <fwp_format_g.constprop.0+0x2dd>
    49ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49f1:	00 00 00 00 
    49f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49fc:	00 00 00 00 
    4a00:	c6 00 00             	movb   $0x0,(%rax)
    4a03:	48 83 e8 01          	sub    $0x1,%rax
    4a07:	49 83 ec 01          	sub    $0x1,%r12
    4a0b:	74 11                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    4a0d:	80 38 30             	cmpb   $0x30,(%rax)
    4a10:	74 ee                	je     4a00 <fwp_format_g.constprop.0+0x2d0>
    4a12:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a18:	0f 84 fb 01 00 00    	je     4c19 <fwp_format_g.constprop.0+0x4e9>
    4a1e:	44 89 c0             	mov    %r8d,%eax
    4a21:	ba 02 00 00 00       	mov    $0x2,%edx
    4a26:	49 89 e9             	mov    %rbp,%r9
    4a29:	be 90 01 00 00       	mov    $0x190,%esi
    4a2e:	f7 d8                	neg    %eax
    4a30:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a37:	48 89 df             	mov    %rbx,%rdi
    4a3a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a3e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a42:	41 83 e0 02          	and    $0x2,%r8d
    4a46:	41 83 c0 2b          	add    $0x2b,%r8d
    4a4a:	50                   	push   %rax
    4a4b:	31 c0                	xor    %eax,%eax
    4a4d:	41 50                	push   %r8
    4a4f:	4c 8d 05 54 66 00 00 	lea    0x6654(%rip),%r8        # b0aa <_IO_stdin_used+0xaa>
    4a56:	e8 35 e9 ff ff       	call   3390 <__snprintf_chk@plt>
    4a5b:	58                   	pop    %rax
    4a5c:	5a                   	pop    %rdx
    4a5d:	e9 0e ff ff ff       	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4a62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a68:	4d 8b 06             	mov    (%r14),%r8
    4a6b:	48 83 c0 09          	add    $0x9,%rax
    4a6f:	4c 89 f2             	mov    %r14,%rdx
    4a72:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a76:	4c 89 07             	mov    %r8,(%rdi)
    4a79:	45 89 e0             	mov    %r12d,%r8d
    4a7c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a81:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a86:	49 89 f8             	mov    %rdi,%r8
    4a89:	49 29 c0             	sub    %rax,%r8
    4a8c:	4c 29 c2             	sub    %r8,%rdx
    4a8f:	45 01 e0             	add    %r12d,%r8d
    4a92:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a96:	41 83 f8 08          	cmp    $0x8,%r8d
    4a9a:	0f 82 bc fd ff ff    	jb     485c <fwp_format_g.constprop.0+0x12c>
    4aa0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4aa4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4aa8:	45 31 d2             	xor    %r10d,%r10d
    4aab:	45 89 d3             	mov    %r10d,%r11d
    4aae:	41 83 c2 08          	add    $0x8,%r10d
    4ab2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ab6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4aba:	45 39 c2             	cmp    %r8d,%r10d
    4abd:	72 ec                	jb     4aab <fwp_format_g.constprop.0+0x37b>
    4abf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ac3:	e9 94 fd ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4ac8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4acf:	00 
    4ad0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ad5:	e9 96 fe ff ff       	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ae0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ae5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ae9:	48 89 ee             	mov    %rbp,%rsi
    4aec:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4af0:	48 89 13             	mov    %rdx,(%rbx)
    4af3:	89 c2                	mov    %eax,%edx
    4af5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4afa:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4aff:	48 89 d9             	mov    %rbx,%rcx
    4b02:	48 29 f9             	sub    %rdi,%rcx
    4b05:	48 29 ce             	sub    %rcx,%rsi
    4b08:	01 c1                	add    %eax,%ecx
    4b0a:	c1 e9 03             	shr    $0x3,%ecx
    4b0d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b10:	e9 ce fd ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4b15:	0f 1f 00             	nopl   (%rax)
    4b18:	c6 00 30             	movb   $0x30,(%rax)
    4b1b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b1f:	4c 89 fa             	mov    %r15,%rdx
    4b22:	4c 89 e9             	mov    %r13,%rcx
    4b25:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b2a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b2f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b33:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b38:	e8 03 ea ff ff       	call   3540 <__memcpy_chk@plt>
    4b3d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b42:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b47:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b4c:	48 89 c7             	mov    %rax,%rdi
    4b4f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b53:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b58:	4c 89 c8             	mov    %r9,%rax
    4b5b:	4c 29 e8             	sub    %r13,%rax
    4b5e:	48 39 c8             	cmp    %rcx,%rax
    4b61:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b65:	4d 29 cd             	sub    %r9,%r13
    4b68:	49 01 ff             	add    %rdi,%r15
    4b6b:	4c 01 e8             	add    %r13,%rax
    4b6e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b72:	74 3d                	je     4bb1 <fwp_format_g.constprop.0+0x481>
    4b74:	41 f7 d0             	not    %r8d
    4b77:	31 f6                	xor    %esi,%esi
    4b79:	ba 48 00 00 00       	mov    $0x48,%edx
    4b7e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b83:	48 39 d0             	cmp    %rdx,%rax
    4b86:	48 0f 43 d0          	cmovae %rax,%rdx
    4b8a:	48 89 d1             	mov    %rdx,%rcx
    4b8d:	48 29 c1             	sub    %rax,%rcx
    4b90:	48 83 c1 01          	add    $0x1,%rcx
    4b94:	48 39 d1             	cmp    %rdx,%rcx
    4b97:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b9b:	48 83 e8 01          	sub    $0x1,%rax
    4b9f:	48 83 c6 01          	add    $0x1,%rsi
    4ba3:	48 29 d0             	sub    %rdx,%rax
    4ba6:	48 01 c8             	add    %rcx,%rax
    4ba9:	41 39 f0             	cmp    %esi,%r8d
    4bac:	7f cb                	jg     4b79 <fwp_format_g.constprop.0+0x449>
    4bae:	4d 01 c7             	add    %r8,%r15
    4bb1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bb6:	41 0f b6 12          	movzbl (%r10),%edx
    4bba:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bbe:	4c 89 f6             	mov    %r14,%rsi
    4bc1:	48 39 c8             	cmp    %rcx,%rax
    4bc4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4bc8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bcc:	41 88 17             	mov    %dl,(%r15)
    4bcf:	48 89 ca             	mov    %rcx,%rdx
    4bd2:	48 29 c2             	sub    %rax,%rdx
    4bd5:	48 83 c2 01          	add    $0x1,%rdx
    4bd9:	48 39 ca             	cmp    %rcx,%rdx
    4bdc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4be0:	48 83 e8 01          	sub    $0x1,%rax
    4be4:	48 29 c8             	sub    %rcx,%rax
    4be7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4beb:	49 63 d4             	movslq %r12d,%rdx
    4bee:	e8 4d e9 ff ff       	call   3540 <__memcpy_chk@plt>
    4bf3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bf7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bfb:	e9 ae fc ff ff       	jmp    48ae <fwp_format_g.constprop.0+0x17e>
    4c00:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c05:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c0a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c0f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c14:	e9 f9 fb ff ff       	jmp    4812 <fwp_format_g.constprop.0+0xe2>
    4c19:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c1f:	e9 fa fd ff ff       	jmp    4a1e <fwp_format_g.constprop.0+0x2ee>
    4c24:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c28:	89 13                	mov    %edx,(%rbx)
    4c2a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c2e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c32:	e9 ac fc ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4c37:	41 8b 06             	mov    (%r14),%eax
    4c3a:	89 07                	mov    %eax,(%rdi)
    4c3c:	44 89 e0             	mov    %r12d,%eax
    4c3f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c44:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c49:	e9 0e fc ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4c4e:	89 c2                	mov    %eax,%edx
    4c50:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c55:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c5a:	e9 84 fc ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4c5f:	44 89 e0             	mov    %r12d,%eax
    4c62:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c68:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c6e:	e9 e9 fb ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4c73:	e8 c8 e7 ff ff       	call   3440 <__stack_chk_fail@plt>
    4c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c7f:	00 

0000000000004c80 <fwp_heap_report>:
    4c80:	f3 0f 1e fa          	endbr64
    4c84:	41 54                	push   %r12
    4c86:	48 8d 3d 2c 64 00 00 	lea    0x642c(%rip),%rdi        # b0b9 <_IO_stdin_used+0xb9>
    4c8d:	55                   	push   %rbp
    4c8e:	53                   	push   %rbx
    4c8f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c96:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c9d:	00 00 
    4c9f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ca6:	00 
    4ca7:	48 8d 35 96 65 00 00 	lea    0x6596(%rip),%rsi        # b244 <_IO_stdin_used+0x244>
    4cae:	e8 3d e9 ff ff       	call   35f0 <fopen@plt>
    4cb3:	48 85 c0             	test   %rax,%rax
    4cb6:	0f 84 c5 00 00 00    	je     4d81 <fwp_heap_report+0x101>
    4cbc:	48 89 c5             	mov    %rax,%rbp
    4cbf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4cc6:	48 89 e3             	mov    %rsp,%rbx
    4cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cd0:	48 89 ea             	mov    %rbp,%rdx
    4cd3:	be 00 01 00 00       	mov    $0x100,%esi
    4cd8:	48 89 df             	mov    %rbx,%rdi
    4cdb:	e8 00 e8 ff ff       	call   34e0 <fgets@plt>
    4ce0:	48 85 c0             	test   %rax,%rax
    4ce3:	74 2b                	je     4d10 <fwp_heap_report+0x90>
    4ce5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ceb:	75 e3                	jne    4cd0 <fwp_heap_report+0x50>
    4ced:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cf1:	75 dd                	jne    4cd0 <fwp_heap_report+0x50>
    4cf3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cf8:	75 d6                	jne    4cd0 <fwp_heap_report+0x50>
    4cfa:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cff:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d04:	31 f6                	xor    %esi,%esi
    4d06:	e8 55 e8 ff ff       	call   3560 <strtol@plt>
    4d0b:	49 89 c4             	mov    %rax,%r12
    4d0e:	eb c0                	jmp    4cd0 <fwp_heap_report+0x50>
    4d10:	48 89 ef             	mov    %rbp,%rdi
    4d13:	e8 08 e7 ff ff       	call   3420 <fclose@plt>
    4d18:	48 83 ec 08          	sub    $0x8,%rsp
    4d1c:	4c 8b 0d a5 3e 06 00 	mov    0x63ea5(%rip),%r9        # 68bc8 <fwp_heap+0x13c8>
    4d23:	4c 8b 05 fe 3e 06 00 	mov    0x63efe(%rip),%r8        # 68c28 <fwp_heap+0x1428>
    4d2a:	48 8d 15 67 6b 00 00 	lea    0x6b67(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d31:	41 54                	push   %r12
    4d33:	48 8b 0d e6 3e 06 00 	mov    0x63ee6(%rip),%rcx        # 68c20 <fwp_heap+0x1420>
    4d3a:	be 02 00 00 00       	mov    $0x2,%esi
    4d3f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d44:	f2 0f 10 0d f4 3e 06 	movsd  0x63ef4(%rip),%xmm1        # 68c40 <fwp_heap+0x1440>
    4d4b:	00 
    4d4c:	f2 0f 10 05 e4 3e 06 	movsd  0x63ee4(%rip),%xmm0        # 68c38 <fwp_heap+0x1438>
    4d53:	00 
    4d54:	48 8b 3d e5 a2 00 00 	mov    0xa2e5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d5b:	e8 f0 e8 ff ff       	call   3650 <__fprintf_chk@plt>
    4d60:	58                   	pop    %rax
    4d61:	5a                   	pop    %rdx
    4d62:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d69:	00 
    4d6a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d71:	00 00 
    4d73:	75 15                	jne    4d8a <fwp_heap_report+0x10a>
    4d75:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d7c:	5b                   	pop    %rbx
    4d7d:	5d                   	pop    %rbp
    4d7e:	41 5c                	pop    %r12
    4d80:	c3                   	ret
    4d81:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d88:	eb 8e                	jmp    4d18 <fwp_heap_report+0x98>
    4d8a:	e8 b1 e6 ff ff       	call   3440 <__stack_chk_fail@plt>
    4d8f:	90                   	nop

0000000000004d90 <fwp_heap_init>:
    4d90:	66 0f 6f 05 08 6f 00 	movdqa 0x6f08(%rip),%xmm0        # bca0 <msg.4+0x30>
    4d97:	00 
    4d98:	41 54                	push   %r12
    4d9a:	48 8d 05 9f 39 06 00 	lea    0x6399f(%rip),%rax        # 68740 <fwp_heap+0xf40>
    4da1:	ba 00 01 00 00       	mov    $0x100,%edx
    4da6:	55                   	push   %rbp
    4da7:	66 0f 6f 15 31 6f 00 	movdqa 0x6f31(%rip),%xmm2        # bce0 <msg.4+0x70>
    4dae:	00 
    4daf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4db3:	53                   	push   %rbx
    4db4:	0f 29 05 45 39 06 00 	movaps %xmm0,0x63945(%rip)        # 68700 <fwp_heap+0xf00>
    4dbb:	66 0f 6f 05 ed 6e 00 	movdqa 0x6eed(%rip),%xmm0        # bcb0 <msg.4+0x40>
    4dc2:	00 
    4dc3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4dc7:	c7 05 d3 3d 06 00 01 	movl   $0x1,0x63dd3(%rip)        # 68ba4 <fwp_heap+0x13a4>
    4dce:	00 00 00 
    4dd1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4dd6:	0f 29 05 33 39 06 00 	movaps %xmm0,0x63933(%rip)        # 68710 <fwp_heap+0xf10>
    4ddd:	66 0f 6f 05 db 6e 00 	movdqa 0x6edb(%rip),%xmm0        # bcc0 <msg.4+0x50>
    4de4:	00 
    4de5:	0f 29 05 34 39 06 00 	movaps %xmm0,0x63934(%rip)        # 68720 <fwp_heap+0xf20>
    4dec:	66 0f 6f 05 dc 6e 00 	movdqa 0x6edc(%rip),%xmm0        # bcd0 <msg.4+0x60>
    4df3:	00 
    4df4:	0f 29 05 35 39 06 00 	movaps %xmm0,0x63935(%rip)        # 68730 <fwp_heap+0xf30>
    4dfb:	89 d3                	mov    %edx,%ebx
    4dfd:	66 0f 6e e2          	movd   %edx,%xmm4
    4e01:	48 83 c0 10          	add    $0x10,%rax
    4e05:	01 d2                	add    %edx,%edx
    4e07:	c1 eb 02             	shr    $0x2,%ebx
    4e0a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e0e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e13:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e17:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e1c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e20:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e24:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e29:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e2e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e32:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e37:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e3b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e3f:	48 39 c7             	cmp    %rax,%rdi
    4e42:	75 b7                	jne    4dfb <fwp_heap_init+0x6b>
    4e44:	4c 8d 05 b5 29 06 00 	lea    0x629b5(%rip),%r8        # 67800 <fwp_heap>
    4e4b:	31 c9                	xor    %ecx,%ecx
    4e4d:	31 c0                	xor    %eax,%eax
    4e4f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e5d:	00 00 00 
    4e60:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e67:	00 
    4e68:	48 39 ca             	cmp    %rcx,%rdx
    4e6b:	73 0f                	jae    4e7c <fwp_heap_init+0xec>
    4e6d:	0f 1f 00             	nopl   (%rax)
    4e70:	48 83 c0 01          	add    $0x1,%rax
    4e74:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e77:	48 39 ca             	cmp    %rcx,%rdx
    4e7a:	72 f4                	jb     4e70 <fwp_heap_init+0xe0>
    4e7c:	48 83 c1 10          	add    $0x10,%rcx
    4e80:	88 07                	mov    %al,(%rdi)
    4e82:	48 83 c7 01          	add    $0x1,%rdi
    4e86:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e8d:	75 d1                	jne    4e60 <fwp_heap_init+0xd0>
    4e8f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e96:	00 00 00 
    4e99:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e9e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ea5:	45 31 c9             	xor    %r9d,%r9d
    4ea8:	31 d2                	xor    %edx,%edx
    4eaa:	31 ff                	xor    %edi,%edi
    4eac:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4eb2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eb7:	4c 89 e6             	mov    %r12,%rsi
    4eba:	e8 91 e5 ff ff       	call   3450 <mmap@plt>
    4ebf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ec3:	75 13                	jne    4ed8 <fwp_heap_init+0x148>
    4ec5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ec9:	83 ed 01             	sub    $0x1,%ebp
    4ecc:	75 d0                	jne    4e9e <fwp_heap_init+0x10e>
    4ece:	e8 1d ef ff ff       	call   3df0 <fwp_heap_oom>
    4ed3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed8:	48 85 c0             	test   %rax,%rax
    4edb:	74 f1                	je     4ece <fwp_heap_init+0x13e>
    4edd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ee1:	48 89 05 d0 3c 06 00 	mov    %rax,0x63cd0(%rip)        # 68bb8 <fwp_heap+0x13b8>
    4ee8:	45 31 c9             	xor    %r9d,%r9d
    4eeb:	31 d2                	xor    %edx,%edx
    4eed:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ef3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ef7:	31 ff                	xor    %edi,%edi
    4ef9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4eff:	66 31 c0             	xor    %ax,%ax
    4f02:	48 c1 e6 03          	shl    $0x3,%rsi
    4f06:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f0b:	4c 89 25 ae 3c 06 00 	mov    %r12,0x63cae(%rip)        # 68bc0 <fwp_heap+0x13c0>
    4f12:	48 89 05 97 3c 06 00 	mov    %rax,0x63c97(%rip)        # 68bb0 <fwp_heap+0x13b0>
    4f19:	48 89 1d b0 3c 06 00 	mov    %rbx,0x63cb0(%rip)        # 68bd0 <fwp_heap+0x13d0>
    4f20:	48 89 35 d9 3c 06 00 	mov    %rsi,0x63cd9(%rip)        # 68c00 <fwp_heap+0x1400>
    4f27:	e8 24 e5 ff ff       	call   3450 <mmap@plt>
    4f2c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f30:	74 9c                	je     4ece <fwp_heap_init+0x13e>
    4f32:	48 8d 3d b6 61 00 00 	lea    0x61b6(%rip),%rdi        # b0ef <_IO_stdin_used+0xef>
    4f39:	48 89 05 b8 3c 06 00 	mov    %rax,0x63cb8(%rip)        # 68bf8 <fwp_heap+0x13f8>
    4f40:	e8 3b e4 ff ff       	call   3380 <getenv@plt>
    4f45:	48 89 c2             	mov    %rax,%rdx
    4f48:	31 c0                	xor    %eax,%eax
    4f4a:	48 85 d2             	test   %rdx,%rdx
    4f4d:	74 15                	je     4f64 <fwp_heap_init+0x1d4>
    4f4f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f52:	74 10                	je     4f64 <fwp_heap_init+0x1d4>
    4f54:	0f b6 02             	movzbl (%rdx),%eax
    4f57:	83 e8 30             	sub    $0x30,%eax
    4f5a:	74 13                	je     4f6f <fwp_heap_init+0x1df>
    4f5c:	85 c0                	test   %eax,%eax
    4f5e:	0f 95 c0             	setne  %al
    4f61:	0f b6 c0             	movzbl %al,%eax
    4f64:	5b                   	pop    %rbx
    4f65:	5d                   	pop    %rbp
    4f66:	89 05 3c 3c 06 00    	mov    %eax,0x63c3c(%rip)        # 68ba8 <fwp_heap+0x13a8>
    4f6c:	41 5c                	pop    %r12
    4f6e:	c3                   	ret
    4f6f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f73:	85 c0                	test   %eax,%eax
    4f75:	0f 95 c0             	setne  %al
    4f78:	0f b6 c0             	movzbl %al,%eax
    4f7b:	eb e7                	jmp    4f64 <fwp_heap_init+0x1d4>
    4f7d:	0f 1f 00             	nopl   (%rax)

0000000000004f80 <fwp_wake_io>:
    4f80:	48 8b 07             	mov    (%rdi),%rax
    4f83:	48 85 c0             	test   %rax,%rax
    4f86:	0f 84 f4 00 00 00    	je     5080 <fwp_wake_io+0x100>
    4f8c:	53                   	push   %rbx
    4f8d:	4c 8b 05 2c 28 06 00 	mov    0x6282c(%rip),%r8        # 677c0 <fwp_ready_tail>
    4f94:	49 89 f9             	mov    %rdi,%r9
    4f97:	48 89 c2             	mov    %rax,%rdx
    4f9a:	45 31 db             	xor    %r11d,%r11d
    4f9d:	45 31 d2             	xor    %r10d,%r10d
    4fa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fa4:	eb 71                	jmp    5017 <fwp_wake_io+0x97>
    4fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fad:	00 00 00 
    4fb0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fb7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fbe:	48 85 c9             	test   %rcx,%rcx
    4fc1:	74 07                	je     4fca <fwp_wake_io+0x4a>
    4fc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fd1:	00 00 00 00 
    4fd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fdc:	49 8b 01             	mov    (%r9),%rax
    4fdf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fe3:	75 2a                	jne    500f <fwp_wake_io+0x8f>
    4fe5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fe9:	75 24                	jne    500f <fwp_wake_io+0x8f>
    4feb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fef:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4ff6:	00 00 00 00 
    4ffa:	4d 85 c0             	test   %r8,%r8
    4ffd:	74 51                	je     5050 <fwp_wake_io+0xd0>
    4fff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5006:	49 89 d0             	mov    %rdx,%r8
    5009:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    500f:	48 89 c2             	mov    %rax,%rdx
    5012:	48 85 c0             	test   %rax,%rax
    5015:	74 49                	je     5060 <fwp_wake_io+0xe0>
    5017:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    501e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5022:	48 85 ff             	test   %rdi,%rdi
    5025:	74 b8                	je     4fdf <fwp_wake_io+0x5f>
    5027:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    502e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5035:	48 85 f6             	test   %rsi,%rsi
    5038:	0f 85 72 ff ff ff    	jne    4fb0 <fwp_wake_io+0x30>
    503e:	48 89 0f             	mov    %rcx,(%rdi)
    5041:	e9 78 ff ff ff       	jmp    4fbe <fwp_wake_io+0x3e>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 d3             	mov    %rdx,%rbx
    5053:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5059:	eb ab                	jmp    5006 <fwp_wake_io+0x86>
    505b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5060:	45 84 db             	test   %r11b,%r11b
    5063:	74 07                	je     506c <fwp_wake_io+0xec>
    5065:	48 89 1d 5c 27 06 00 	mov    %rbx,0x6275c(%rip)        # 677c8 <fwp_ready_head>
    506c:	45 84 d2             	test   %r10b,%r10b
    506f:	74 07                	je     5078 <fwp_wake_io+0xf8>
    5071:	4c 89 05 48 27 06 00 	mov    %r8,0x62748(%rip)        # 677c0 <fwp_ready_tail>
    5078:	5b                   	pop    %rbx
    5079:	c3                   	ret
    507a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5080:	c3                   	ret
    5081:	0f 1f 40 00          	nopl   0x0(%rax)
    5085:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    508c:	00 00 00 00 

0000000000005090 <ad_raw_free.part.0>:
    5090:	48 8d 0d 09 a1 04 00 	lea    0x4a109(%rip),%rcx        # 4f1a0 <ad_raw_blocks>
    5097:	31 c0                	xor    %eax,%eax
    5099:	48 89 ca             	mov    %rcx,%rdx
    509c:	eb 12                	jmp    50b0 <ad_raw_free.part.0+0x20>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	48 83 c0 01          	add    $0x1,%rax
    50a4:	48 83 c2 18          	add    $0x18,%rdx
    50a8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ae:	74 40                	je     50f0 <ad_raw_free.part.0+0x60>
    50b0:	48 3b 3a             	cmp    (%rdx),%rdi
    50b3:	75 eb                	jne    50a0 <ad_raw_free.part.0+0x10>
    50b5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50b9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50bd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50c1:	48 8d 0d b8 a0 04 00 	lea    0x4a0b8(%rip),%rcx        # 4f180 <ad_raw_live>
    50c8:	8b 70 10             	mov    0x10(%rax),%esi
    50cb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50d2:	00 
    50d3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50d7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50db:	0f 11 00             	movups %xmm0,(%rax)
    50de:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    50e2:	e9 b9 e2 ff ff       	jmp    33a0 <free@plt>
    50e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    50ee:	00 00 
    50f0:	48 83 ec 08          	sub    $0x8,%rsp
    50f4:	48 8d 3d 04 60 00 00 	lea    0x6004(%rip),%rdi        # b0ff <_IO_stdin_used+0xff>
    50fb:	e8 c0 ee ff ff       	call   3fc0 <ad_raw_fail>

0000000000005100 <fwp_tape_buffers_dispose>:
    5100:	53                   	push   %rbx
    5101:	48 89 fb             	mov    %rdi,%rbx
    5104:	48 8b 3f             	mov    (%rdi),%rdi
    5107:	48 85 ff             	test   %rdi,%rdi
    510a:	74 05                	je     5111 <fwp_tape_buffers_dispose+0x11>
    510c:	e8 7f ff ff ff       	call   5090 <ad_raw_free.part.0>
    5111:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    5115:	48 85 ff             	test   %rdi,%rdi
    5118:	74 05                	je     511f <fwp_tape_buffers_dispose+0x1f>
    511a:	e8 71 ff ff ff       	call   5090 <ad_raw_free.part.0>
    511f:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5123:	48 85 ff             	test   %rdi,%rdi
    5126:	74 05                	je     512d <fwp_tape_buffers_dispose+0x2d>
    5128:	e8 63 ff ff ff       	call   5090 <ad_raw_free.part.0>
    512d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5131:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    5138:	00 
    5139:	0f 11 03             	movups %xmm0,(%rbx)
    513c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5140:	5b                   	pop    %rbx
    5141:	c3                   	ret
    5142:	0f 1f 00             	nopl   (%rax)
    5145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    514c:	00 00 00 00 

0000000000005150 <ad_raw_realloc>:
    5150:	41 55                	push   %r13
    5152:	41 54                	push   %r12
    5154:	55                   	push   %rbp
    5155:	53                   	push   %rbx
    5156:	48 83 ec 08          	sub    $0x8,%rsp
    515a:	48 85 f6             	test   %rsi,%rsi
    515d:	0f 84 a6 00 00 00    	je     5209 <ad_raw_realloc+0xb9>
    5163:	4c 8d 25 36 a0 04 00 	lea    0x4a036(%rip),%r12        # 4f1a0 <ad_raw_blocks>
    516a:	48 89 f5             	mov    %rsi,%rbp
    516d:	41 89 d5             	mov    %edx,%r13d
    5170:	31 db                	xor    %ebx,%ebx
    5172:	4c 89 e0             	mov    %r12,%rax
    5175:	eb 1a                	jmp    5191 <ad_raw_realloc+0x41>
    5177:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    517e:	00 00 
    5180:	48 83 c3 01          	add    $0x1,%rbx
    5184:	48 83 c0 18          	add    $0x18,%rax
    5188:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    518f:	74 4f                	je     51e0 <ad_raw_realloc+0x90>
    5191:	48 3b 38             	cmp    (%rax),%rdi
    5194:	75 ea                	jne    5180 <ad_raw_realloc+0x30>
    5196:	48 85 ff             	test   %rdi,%rdi
    5199:	74 0b                	je     51a6 <ad_raw_realloc+0x56>
    519b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    519f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51a4:	75 57                	jne    51fd <ad_raw_realloc+0xad>
    51a6:	48 89 ee             	mov    %rbp,%rsi
    51a9:	e8 f2 e3 ff ff       	call   35a0 <realloc@plt>
    51ae:	49 89 c2             	mov    %rax,%r10
    51b1:	48 85 c0             	test   %rax,%rax
    51b4:	74 16                	je     51cc <ad_raw_realloc+0x7c>
    51b6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51ba:	44 89 e9             	mov    %r13d,%ecx
    51bd:	48 89 ea             	mov    %rbp,%rdx
    51c0:	4c 89 d6             	mov    %r10,%rsi
    51c3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51c7:	e8 f4 e9 ff ff       	call   3bc0 <ad_raw_record>
    51cc:	48 83 c4 08          	add    $0x8,%rsp
    51d0:	4c 89 d0             	mov    %r10,%rax
    51d3:	5b                   	pop    %rbx
    51d4:	5d                   	pop    %rbp
    51d5:	41 5c                	pop    %r12
    51d7:	41 5d                	pop    %r13
    51d9:	c3                   	ret
    51da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51e0:	48 85 ff             	test   %rdi,%rdi
    51e3:	48 8d 05 2a 5f 00 00 	lea    0x5f2a(%rip),%rax        # b114 <_IO_stdin_used+0x114>
    51ea:	48 8d 15 0e 5f 00 00 	lea    0x5f0e(%rip),%rdx        # b0ff <_IO_stdin_used+0xff>
    51f1:	48 0f 45 c2          	cmovne %rdx,%rax
    51f5:	48 89 c7             	mov    %rax,%rdi
    51f8:	e8 c3 ed ff ff       	call   3fc0 <ad_raw_fail>
    51fd:	48 8d 3d 46 5f 00 00 	lea    0x5f46(%rip),%rdi        # b14a <_IO_stdin_used+0x14a>
    5204:	e8 b7 ed ff ff       	call   3fc0 <ad_raw_fail>
    5209:	48 8d 3d 1f 5f 00 00 	lea    0x5f1f(%rip),%rdi        # b12f <_IO_stdin_used+0x12f>
    5210:	e8 ab ed ff ff       	call   3fc0 <ad_raw_fail>
    5215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    521c:	00 00 00 00 

0000000000005220 <fwp_tape_buffers_release>:
    5220:	f3 0f 1e fa          	endbr64
    5224:	53                   	push   %rbx
    5225:	48 89 fb             	mov    %rdi,%rbx
    5228:	48 83 ec 10          	sub    $0x10,%rsp
    522c:	48 8b 47 18          	mov    0x18(%rdi),%rax
    5230:	48 85 c0             	test   %rax,%rax
    5233:	0f 88 c7 00 00 00    	js     5300 <fwp_tape_buffers_release+0xe0>
    5239:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    523d:	48 85 d2             	test   %rdx,%rdx
    5240:	0f 88 ba 00 00 00    	js     5300 <fwp_tape_buffers_release+0xe0>
    5246:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    524c:	0f 87 ae 00 00 00    	ja     5300 <fwp_tape_buffers_release+0xe0>
    5252:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5256:	b8 00 00 08 00       	mov    $0x80000,%eax
    525b:	48 c1 e1 03          	shl    $0x3,%rcx
    525f:	48 29 c8             	sub    %rcx,%rax
    5262:	48 c1 e8 03          	shr    $0x3,%rax
    5266:	48 39 d0             	cmp    %rdx,%rax
    5269:	0f 82 91 00 00 00    	jb     5300 <fwp_tape_buffers_release+0xe0>
    526f:	48 8d 3d ec 5e 00 00 	lea    0x5eec(%rip),%rdi        # b162 <_IO_stdin_used+0x162>
    5276:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    527b:	48 89 14 24          	mov    %rdx,(%rsp)
    527f:	e8 fc e0 ff ff       	call   3380 <getenv@plt>
    5284:	48 8b 14 24          	mov    (%rsp),%rdx
    5288:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    528d:	48 85 c0             	test   %rax,%rax
    5290:	74 09                	je     529b <fwp_tape_buffers_release+0x7b>
    5292:	80 38 30             	cmpb   $0x30,(%rax)
    5295:	0f 84 f5 00 00 00    	je     5390 <fwp_tape_buffers_release+0x170>
    529b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    529f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52a3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52a9:	77 61                	ja     530c <fwp_tape_buffers_release+0xec>
    52ab:	48 8d 3d ee 9d 01 00 	lea    0x19dee(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    52b2:	48 89 34 24          	mov    %rsi,(%rsp)
    52b6:	e8 45 fe ff ff       	call   5100 <fwp_tape_buffers_dispose>
    52bb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52bf:	48 8b 34 24          	mov    (%rsp),%rsi
    52c3:	0f 29 05 d6 9d 01 00 	movaps %xmm0,0x19dd6(%rip)        # 1f0a0 <fwp_tape_workspace>
    52ca:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52cf:	48 89 35 b2 9d 01 00 	mov    %rsi,0x19db2(%rip)        # 1f088 <fwp_tape_cached_bytes>
    52d6:	0f 29 05 d3 9d 01 00 	movaps %xmm0,0x19dd3(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    52dd:	48 8b 43 20          	mov    0x20(%rbx),%rax
    52e1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52e5:	48 89 05 d4 9d 01 00 	mov    %rax,0x19dd4(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    52ec:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    52f3:	00 
    52f4:	0f 11 03             	movups %xmm0,(%rbx)
    52f7:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    52fb:	eb 1e                	jmp    531b <fwp_tape_buffers_release+0xfb>
    52fd:	0f 1f 00             	nopl   (%rax)
    5300:	48 8d 3d 5b 5e 00 00 	lea    0x5e5b(%rip),%rdi        # b162 <_IO_stdin_used+0x162>
    5307:	e8 74 e0 ff ff       	call   3380 <getenv@plt>
    530c:	48 89 df             	mov    %rbx,%rdi
    530f:	e8 ec fd ff ff       	call   5100 <fwp_tape_buffers_dispose>
    5314:	48 8b 35 6d 9d 01 00 	mov    0x19d6d(%rip),%rsi        # 1f088 <fwp_tape_cached_bytes>
    531b:	48 6b 15 ad 9d 01 00 	imul   $0x58,0x19dad(%rip),%rdx        # 1f0d0 <fwp_tapes_cap>
    5322:	58 
    5323:	48 3b 15 56 9e 04 00 	cmp    0x49e56(%rip),%rdx        # 4f180 <ad_raw_live>
    532a:	75 73                	jne    539f <fwp_tape_buffers_release+0x17f>
    532c:	48 8b 05 55 9e 04 00 	mov    0x49e55(%rip),%rax        # 4f188 <ad_raw_live+0x8>
    5333:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5337:	48 01 d0             	add    %rdx,%rax
    533a:	48 03 05 4f 9e 04 00 	add    0x49e4f(%rip),%rax        # 4f190 <ad_raw_live+0x10>
    5341:	48 03 05 50 9e 04 00 	add    0x49e50(%rip),%rax        # 4f198 <ad_raw_live+0x18>
    5348:	48 39 c8             	cmp    %rcx,%rax
    534b:	72 52                	jb     539f <fwp_tape_buffers_release+0x17f>
    534d:	48 8b 0d 9c 9d 01 00 	mov    0x19d9c(%rip),%rcx        # 1f0f0 <ad_raw_checkpoint_count>
    5354:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    535b:	74 4e                	je     53ab <fwp_tape_buffers_release+0x18b>
    535d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5361:	48 29 d0             	sub    %rdx,%rax
    5364:	48 89 3d 85 9d 01 00 	mov    %rdi,0x19d85(%rip)        # 1f0f0 <ad_raw_checkpoint_count>
    536b:	48 29 f0             	sub    %rsi,%rax
    536e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5372:	48 8d 0d 87 9d 01 00 	lea    0x19d87(%rip),%rcx        # 1f100 <ad_raw_checkpoints>
    5379:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    537d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5382:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5387:	48 83 c4 10          	add    $0x10,%rsp
    538b:	5b                   	pop    %rbx
    538c:	c3                   	ret
    538d:	0f 1f 00             	nopl   (%rax)
    5390:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5394:	0f 84 72 ff ff ff    	je     530c <fwp_tape_buffers_release+0xec>
    539a:	e9 fc fe ff ff       	jmp    529b <fwp_tape_buffers_release+0x7b>
    539f:	48 8d 3d 7a 65 00 00 	lea    0x657a(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    53a6:	e8 15 ec ff ff       	call   3fc0 <ad_raw_fail>
    53ab:	48 8d 3d c1 5d 00 00 	lea    0x5dc1(%rip),%rdi        # b173 <_IO_stdin_used+0x173>
    53b2:	e8 09 ec ff ff       	call   3fc0 <ad_raw_fail>
    53b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53be:	00 00 

00000000000053c0 <fwp_poll_events>:
    53c0:	53                   	push   %rbx
    53c1:	48 83 ec 20          	sub    $0x20,%rsp
    53c5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53cc:	00 00 
    53ce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    53d3:	31 c0                	xor    %eax,%eax
    53d5:	e8 a6 f1 ff ff       	call   4580 <fwp_now_ns>
    53da:	48 8b 1d d7 23 06 00 	mov    0x623d7(%rip),%rbx        # 677b8 <fwp_timers>
    53e1:	48 85 db             	test   %rbx,%rbx
    53e4:	0f 84 d6 00 00 00    	je     54c0 <fwp_poll_events+0x100>
    53ea:	48 89 c6             	mov    %rax,%rsi
    53ed:	48 89 da             	mov    %rbx,%rdx
    53f0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    53f7:	eb 16                	jmp    540f <fwp_poll_events+0x4f>
    53f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5400:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5407:	48 89 c8             	mov    %rcx,%rax
    540a:	48 85 d2             	test   %rdx,%rdx
    540d:	74 31                	je     5440 <fwp_poll_events+0x80>
    540f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5413:	48 85 c0             	test   %rax,%rax
    5416:	78 e8                	js     5400 <fwp_poll_events+0x40>
    5418:	48 39 c1             	cmp    %rax,%rcx
    541b:	7c e3                	jl     5400 <fwp_poll_events+0x40>
    541d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5424:	48 85 d2             	test   %rdx,%rdx
    5427:	74 1c                	je     5445 <fwp_poll_events+0x85>
    5429:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    542d:	48 39 c1             	cmp    %rax,%rcx
    5430:	7c ce                	jl     5400 <fwp_poll_events+0x40>
    5432:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5439:	48 85 d2             	test   %rdx,%rdx
    543c:	75 d1                	jne    540f <fwp_poll_events+0x4f>
    543e:	66 90                	xchg   %ax,%ax
    5440:	48 85 c0             	test   %rax,%rax
    5443:	78 7b                	js     54c0 <fwp_poll_events+0x100>
    5445:	48 29 f0             	sub    %rsi,%rax
    5448:	48 89 c1             	mov    %rax,%rcx
    544b:	48 85 c0             	test   %rax,%rax
    544e:	0f 8e 9c 00 00 00    	jle    54f0 <fwp_poll_events+0x130>
    5454:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    545b:	de 1b 43 
    545e:	48 f7 ea             	imul   %rdx
    5461:	48 89 c8             	mov    %rcx,%rax
    5464:	48 c1 f8 3f          	sar    $0x3f,%rax
    5468:	48 c1 fa 12          	sar    $0x12,%rdx
    546c:	48 29 c2             	sub    %rax,%rdx
    546f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5476:	48 39 c1             	cmp    %rax,%rcx
    5479:	0f 95 c0             	setne  %al
    547c:	0f b6 c0             	movzbl %al,%eax
    547f:	48 01 d0             	add    %rdx,%rax
    5482:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5488:	0f 8f 32 01 00 00    	jg     55c0 <fwp_poll_events+0x200>
    548e:	48 85 c0             	test   %rax,%rax
    5491:	74 5d                	je     54f0 <fwp_poll_events+0x130>
    5493:	89 c1                	mov    %eax,%ecx
    5495:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    549c:	48 c1 e9 26          	shr    $0x26,%rcx
    54a0:	48 63 d1             	movslq %ecx,%rdx
    54a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54a9:	29 c8                	sub    %ecx,%eax
    54ab:	48 98                	cltq
    54ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54b4:	e9 11 01 00 00       	jmp    55ca <fwp_poll_events+0x20a>
    54b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54c0:	e8 fb e7 ff ff       	call   3cc0 <fwp_flush>
    54c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    54ca:	be 01 00 00 00       	mov    $0x1,%esi
    54cf:	48 8b 0d 6a 9b 00 00 	mov    0x9b6a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    54d6:	48 8d 3d 73 64 00 00 	lea    0x6473(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    54dd:	e8 5e e1 ff ff       	call   3640 <fwrite@plt>
    54e2:	bf 65 00 00 00       	mov    $0x65,%edi
    54e7:	e8 44 e1 ff ff       	call   3630 <exit@plt>
    54ec:	0f 1f 40 00          	nopl   0x0(%rax)
    54f0:	e8 8b f0 ff ff       	call   4580 <fwp_now_ns>
    54f5:	48 89 c1             	mov    %rax,%rcx
    54f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    54fc:	eb 44                	jmp    5542 <fwp_poll_events+0x182>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5504:	75 33                	jne    5539 <fwp_poll_events+0x179>
    5506:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    550a:	75 2d                	jne    5539 <fwp_poll_events+0x179>
    550c:	48 8b 05 ad 22 06 00 	mov    0x622ad(%rip),%rax        # 677c0 <fwp_ready_tail>
    5513:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5517:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    551e:	00 00 00 00 
    5522:	48 85 c0             	test   %rax,%rax
    5525:	0f 84 05 01 00 00    	je     5630 <fwp_poll_events+0x270>
    552b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5532:	48 89 15 87 22 06 00 	mov    %rdx,0x62287(%rip)        # 677c0 <fwp_ready_tail>
    5539:	48 85 db             	test   %rbx,%rbx
    553c:	0f 84 be 00 00 00    	je     5600 <fwp_poll_events+0x240>
    5542:	48 89 da             	mov    %rbx,%rdx
    5545:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    554c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5550:	7f e7                	jg     5539 <fwp_poll_events+0x179>
    5552:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5556:	74 2e                	je     5586 <fwp_poll_events+0x1c6>
    5558:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    555f:	48 85 c0             	test   %rax,%rax
    5562:	0f 84 b8 00 00 00    	je     5620 <fwp_poll_events+0x260>
    5568:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    556f:	48 85 db             	test   %rbx,%rbx
    5572:	74 07                	je     557b <fwp_poll_events+0x1bb>
    5574:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    557b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    557f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5586:	48 8b 42 60          	mov    0x60(%rdx),%rax
    558a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    558e:	48 85 c0             	test   %rax,%rax
    5591:	0f 84 69 ff ff ff    	je     5500 <fwp_poll_events+0x140>
    5597:	48 39 c8             	cmp    %rcx,%rax
    559a:	0f 8f 60 ff ff ff    	jg     5500 <fwp_poll_events+0x140>
    55a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55a4:	0f 85 56 ff ff ff    	jne    5500 <fwp_poll_events+0x140>
    55aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ae:	75 89                	jne    5539 <fwp_poll_events+0x179>
    55b0:	48 89 d7             	mov    %rdx,%rdi
    55b3:	e8 38 eb ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    55b8:	e9 43 ff ff ff       	jmp    5500 <fwp_poll_events+0x140>
    55bd:	0f 1f 00             	nopl   (%rax)
    55c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    55c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    55ca:	48 89 e7             	mov    %rsp,%rdi
    55cd:	31 f6                	xor    %esi,%esi
    55cf:	48 89 14 24          	mov    %rdx,(%rsp)
    55d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    55d8:	e8 a3 de ff ff       	call   3480 <nanosleep@plt>
    55dd:	48 8b 1d d4 21 06 00 	mov    0x621d4(%rip),%rbx        # 677b8 <fwp_timers>
    55e4:	e8 97 ef ff ff       	call   4580 <fwp_now_ns>
    55e9:	48 89 c1             	mov    %rax,%rcx
    55ec:	48 85 db             	test   %rbx,%rbx
    55ef:	0f 85 03 ff ff ff    	jne    54f8 <fwp_poll_events+0x138>
    55f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    55fc:	00 00 00 00 
    5600:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5605:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    560c:	00 00 
    560e:	75 2c                	jne    563c <fwp_poll_events+0x27c>
    5610:	48 83 c4 20          	add    $0x20,%rsp
    5614:	5b                   	pop    %rbx
    5615:	c3                   	ret
    5616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    561d:	00 00 00 
    5620:	48 89 1d 91 21 06 00 	mov    %rbx,0x62191(%rip)        # 677b8 <fwp_timers>
    5627:	e9 43 ff ff ff       	jmp    556f <fwp_poll_events+0x1af>
    562c:	0f 1f 40 00          	nopl   0x0(%rax)
    5630:	48 89 15 91 21 06 00 	mov    %rdx,0x62191(%rip)        # 677c8 <fwp_ready_head>
    5637:	e9 f6 fe ff ff       	jmp    5532 <fwp_poll_events+0x172>
    563c:	e8 ff dd ff ff       	call   3440 <__stack_chk_fail@plt>
    5641:	0f 1f 40 00          	nopl   0x0(%rax)
    5645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    564c:	00 00 00 00 

0000000000005650 <fwp_rc_wide_dup>:
    5650:	48 89 fa             	mov    %rdi,%rdx
    5653:	48 8d 35 a6 21 06 00 	lea    0x621a6(%rip),%rsi        # 67800 <fwp_heap>
    565a:	48 83 ec 18          	sub    $0x18,%rsp
    565e:	48 89 f9             	mov    %rdi,%rcx
    5661:	48 c1 ea 11          	shr    $0x11,%rdx
    5665:	48 31 fa             	xor    %rdi,%rdx
    5668:	48 89 d0             	mov    %rdx,%rax
    566b:	48 c1 e8 09          	shr    $0x9,%rax
    566f:	48 31 c2             	xor    %rax,%rdx
    5672:	0f b6 d2             	movzbl %dl,%edx
    5675:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    567c:	00 
    567d:	49 8b 00             	mov    (%r8),%rax
    5680:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5687:	00 00 
    5689:	75 21                	jne    56ac <fwp_rc_wide_dup+0x5c>
    568b:	e9 98 00 00 00       	jmp    5728 <fwp_rc_wide_dup+0xd8>
    5690:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    569c:	00 00 00 00 
    56a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56a4:	48 85 d2             	test   %rdx,%rdx
    56a7:	74 2f                	je     56d8 <fwp_rc_wide_dup+0x88>
    56a9:	48 89 d0             	mov    %rdx,%rax
    56ac:	48 3b 08             	cmp    (%rax),%rcx
    56af:	75 ef                	jne    56a0 <fwp_rc_wide_dup+0x50>
    56b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56b4:	74 7c                	je     5732 <fwp_rc_wide_dup+0xe2>
    56b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56be:	0f 84 91 00 00 00    	je     5755 <fwp_rc_wide_dup+0x105>
    56c4:	48 83 c2 01          	add    $0x1,%rdx
    56c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    56cc:	48 83 c4 18          	add    $0x18,%rsp
    56d0:	c3                   	ret
    56d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    56dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56df:	75 68                	jne    5749 <fwp_rc_wide_dup+0xf9>
    56e1:	bf 18 00 00 00       	mov    $0x18,%edi
    56e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    56eb:	4c 89 04 24          	mov    %r8,(%rsp)
    56ef:	e8 8c de ff ff       	call   3580 <malloc@plt>
    56f4:	4c 8b 04 24          	mov    (%rsp),%r8
    56f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    56fd:	48 85 c0             	test   %rax,%rax
    5700:	74 5f                	je     5761 <fwp_rc_wide_dup+0x111>
    5702:	48 89 08             	mov    %rcx,(%rax)
    5705:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    570c:	00 
    570d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5714:	00 
    5715:	49 89 00             	mov    %rax,(%r8)
    5718:	c6 01 ff             	movb   $0xff,(%rcx)
    571b:	48 83 05 25 3d 06 00 	addq   $0x1,0x63d25(%rip)        # 69448 <fwp_heap+0x1c48>
    5722:	01 
    5723:	48 83 c4 18          	add    $0x18,%rsp
    5727:	c3                   	ret
    5728:	80 3f fe             	cmpb   $0xfe,(%rdi)
    572b:	75 13                	jne    5740 <fwp_rc_wide_dup+0xf0>
    572d:	48 85 c0             	test   %rax,%rax
    5730:	74 af                	je     56e1 <fwp_rc_wide_dup+0x91>
    5732:	48 8d 3d 47 62 00 00 	lea    0x6247(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    5739:	e8 d2 ec ff ff       	call   4410 <fwp_trap>
    573e:	66 90                	xchg   %ax,%ax
    5740:	48 85 c0             	test   %rax,%rax
    5743:	0f 85 6d ff ff ff    	jne    56b6 <fwp_rc_wide_dup+0x66>
    5749:	48 8d 3d 58 62 00 00 	lea    0x6258(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5750:	e8 bb ec ff ff       	call   4410 <fwp_trap>
    5755:	48 8d 3d 34 5a 00 00 	lea    0x5a34(%rip),%rdi        # b190 <_IO_stdin_used+0x190>
    575c:	e8 af ec ff ff       	call   4410 <fwp_trap>
    5761:	e8 8a e6 ff ff       	call   3df0 <fwp_heap_oom>
    5766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    576d:	00 00 00 

0000000000005770 <fwp_rc_forget_slot>:
    5770:	80 3f ff             	cmpb   $0xff,(%rdi)
    5773:	74 0b                	je     5780 <fwp_rc_forget_slot+0x10>
    5775:	c3                   	ret
    5776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    577d:	00 00 00 
    5780:	48 89 f8             	mov    %rdi,%rax
    5783:	48 83 ec 08          	sub    $0x8,%rsp
    5787:	48 89 fa             	mov    %rdi,%rdx
    578a:	48 c1 e8 11          	shr    $0x11,%rax
    578e:	48 31 f8             	xor    %rdi,%rax
    5791:	48 89 c1             	mov    %rax,%rcx
    5794:	48 c1 e9 09          	shr    $0x9,%rcx
    5798:	48 31 c8             	xor    %rcx,%rax
    579b:	48 8d 0d 5e 20 06 00 	lea    0x6205e(%rip),%rcx        # 67800 <fwp_heap>
    57a2:	0f b6 c0             	movzbl %al,%eax
    57a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ac:	00 
    57ad:	48 85 ff             	test   %rdi,%rdi
    57b0:	74 3c                	je     57ee <fwp_rc_forget_slot+0x7e>
    57b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57b9:	00 
    57ba:	48 8b 01             	mov    (%rcx),%rax
    57bd:	eb 11                	jmp    57d0 <fwp_rc_forget_slot+0x60>
    57bf:	90                   	nop
    57c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    57c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    57c8:	48 85 ff             	test   %rdi,%rdi
    57cb:	74 21                	je     57ee <fwp_rc_forget_slot+0x7e>
    57cd:	48 89 f8             	mov    %rdi,%rax
    57d0:	48 3b 10             	cmp    (%rax),%rdx
    57d3:	75 eb                	jne    57c0 <fwp_rc_forget_slot+0x50>
    57d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    57d9:	48 89 01             	mov    %rax,(%rcx)
    57dc:	e8 bf db ff ff       	call   33a0 <free@plt>
    57e1:	48 83 2d 5f 3c 06 00 	subq   $0x1,0x63c5f(%rip)        # 69448 <fwp_heap+0x1c48>
    57e8:	01 
    57e9:	48 83 c4 08          	add    $0x8,%rsp
    57ed:	c3                   	ret
    57ee:	48 8d 3d b3 61 00 00 	lea    0x61b3(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    57f5:	e8 16 ec ff ff       	call   4410 <fwp_trap>
    57fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005800 <fwp_rc_prepare_chunk>:
    5800:	48 83 3d 40 3c 06 00 	cmpq   $0x0,0x63c40(%rip)        # 69448 <fwp_heap+0x1c48>
    5807:	00 
    5808:	41 54                	push   %r12
    580a:	49 89 f4             	mov    %rsi,%r12
    580d:	55                   	push   %rbp
    580e:	48 89 fd             	mov    %rdi,%rbp
    5811:	53                   	push   %rbx
    5812:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5815:	0f 84 7d 00 00 00    	je     5898 <fwp_rc_prepare_chunk+0x98>
    581b:	31 db                	xor    %ebx,%ebx
    581d:	85 c0                	test   %eax,%eax
    581f:	75 5f                	jne    5880 <fwp_rc_prepare_chunk+0x80>
    5821:	48 85 f6             	test   %rsi,%rsi
    5824:	74 7c                	je     58a2 <fwp_rc_prepare_chunk+0xa2>
    5826:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    582a:	e8 71 db ff ff       	call   33a0 <free@plt>
    582f:	90                   	nop
    5830:	be 01 00 00 00       	mov    $0x1,%esi
    5835:	4c 89 e7             	mov    %r12,%rdi
    5838:	e8 c3 dc ff ff       	call   3500 <calloc@plt>
    583d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5841:	48 85 c0             	test   %rax,%rax
    5844:	0f 85 87 00 00 00    	jne    58d1 <fwp_rc_prepare_chunk+0xd1>
    584a:	e8 a1 e5 ff ff       	call   3df0 <fwp_heap_oom>
    584f:	90                   	nop
    5850:	e8 1b ff ff ff       	call   5770 <fwp_rc_forget_slot>
    5855:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5858:	48 83 c3 01          	add    $0x1,%rbx
    585c:	48 39 c3             	cmp    %rax,%rbx
    585f:	73 37                	jae    5898 <fwp_rc_prepare_chunk+0x98>
    5861:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5868:	00 00 
    586a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5871:	00 00 00 00 
    5875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    587c:	00 00 00 00 
    5880:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5884:	48 01 df             	add    %rbx,%rdi
    5887:	80 3f ff             	cmpb   $0xff,(%rdi)
    588a:	74 c4                	je     5850 <fwp_rc_prepare_chunk+0x50>
    588c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    588f:	48 83 c3 01          	add    $0x1,%rbx
    5893:	48 39 c3             	cmp    %rax,%rbx
    5896:	72 e8                	jb     5880 <fwp_rc_prepare_chunk+0x80>
    5898:	49 39 c4             	cmp    %rax,%r12
    589b:	75 13                	jne    58b0 <fwp_rc_prepare_chunk+0xb0>
    589d:	4d 85 e4             	test   %r12,%r12
    58a0:	75 46                	jne    58e8 <fwp_rc_prepare_chunk+0xe8>
    58a2:	5b                   	pop    %rbx
    58a3:	5d                   	pop    %rbp
    58a4:	41 5c                	pop    %r12
    58a6:	c3                   	ret
    58a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ae:	00 00 
    58b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58b4:	48 29 05 95 3b 06 00 	sub    %rax,0x63b95(%rip)        # 69450 <fwp_heap+0x1c50>
    58bb:	e8 e0 da ff ff       	call   33a0 <free@plt>
    58c0:	4d 85 e4             	test   %r12,%r12
    58c3:	0f 85 67 ff ff ff    	jne    5830 <fwp_rc_prepare_chunk+0x30>
    58c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    58d0:	00 
    58d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    58d5:	5b                   	pop    %rbx
    58d6:	4c 01 25 73 3b 06 00 	add    %r12,0x63b73(%rip)        # 69450 <fwp_heap+0x1c50>
    58dd:	5d                   	pop    %rbp
    58de:	41 5c                	pop    %r12
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58ec:	5b                   	pop    %rbx
    58ed:	4c 89 e2             	mov    %r12,%rdx
    58f0:	31 f6                	xor    %esi,%esi
    58f2:	5d                   	pop    %rbp
    58f3:	41 5c                	pop    %r12
    58f5:	e9 a6 db ff ff       	jmp    34a0 <memset@plt>
    58fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005900 <fwp_heap_refill>:
    5900:	41 56                	push   %r14
    5902:	41 89 d6             	mov    %edx,%r14d
    5905:	41 55                	push   %r13
    5907:	41 89 f5             	mov    %esi,%r13d
    590a:	41 54                	push   %r12
    590c:	49 89 fc             	mov    %rdi,%r12
    590f:	bf 01 00 00 00       	mov    $0x1,%edi
    5914:	55                   	push   %rbp
    5915:	53                   	push   %rbx
    5916:	e8 15 e5 ff ff       	call   3e30 <fwp_heap_chunks>
    591b:	48 89 c3             	mov    %rax,%rbx
    591e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5922:	48 8b 05 cf 32 06 00 	mov    0x632cf(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    5929:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    592d:	48 8d 05 cc 1e 06 00 	lea    0x61ecc(%rip),%rax        # 67800 <fwp_heap>
    5934:	31 d2                	xor    %edx,%edx
    5936:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    593a:	48 89 ef             	mov    %rbp,%rdi
    593d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5941:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5945:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    594c:	00 
    594d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5952:	f7 f1                	div    %ecx
    5954:	31 d2                	xor    %edx,%edx
    5956:	66 0f 6e c1          	movd   %ecx,%xmm0
    595a:	66 0f 6e c8          	movd   %eax,%xmm1
    595e:	89 c6                	mov    %eax,%esi
    5960:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5965:	48 01 c8             	add    %rcx,%rax
    5968:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    596c:	48 f7 f1             	div    %rcx
    596f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5974:	89 45 18             	mov    %eax,0x18(%rbp)
    5977:	e8 84 fe ff ff       	call   5800 <fwp_rc_prepare_chunk>
    597c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    597f:	48 89 d8             	mov    %rbx,%rax
    5982:	48 c1 e0 10          	shl    $0x10,%rax
    5986:	48 03 05 23 32 06 00 	add    0x63223(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    598d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5991:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5996:	8b 55 08             	mov    0x8(%rbp),%edx
    5999:	48 0f af d1          	imul   %rcx,%rdx
    599d:	48 01 c2             	add    %rax,%rdx
    59a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59a5:	5b                   	pop    %rbx
    59a6:	5d                   	pop    %rbp
    59a7:	41 5c                	pop    %r12
    59a9:	41 5d                	pop    %r13
    59ab:	41 5e                	pop    %r14
    59ad:	c3                   	ret
    59ae:	66 90                	xchg   %ax,%ax

00000000000059b0 <fwp_mem_free>:
    59b0:	48 85 ff             	test   %rdi,%rdi
    59b3:	0f 84 17 02 00 00    	je     5bd0 <fwp_mem_free+0x220>
    59b9:	48 8b 35 f0 31 06 00 	mov    0x631f0(%rip),%rsi        # 68bb0 <fwp_heap+0x13b0>
    59c0:	48 8b 05 11 32 06 00 	mov    0x63211(%rip),%rax        # 68bd8 <fwp_heap+0x13d8>
    59c7:	48 89 fa             	mov    %rdi,%rdx
    59ca:	48 29 f2             	sub    %rsi,%rdx
    59cd:	48 c1 e0 10          	shl    $0x10,%rax
    59d1:	48 39 c2             	cmp    %rax,%rdx
    59d4:	0f 83 f6 01 00 00    	jae    5bd0 <fwp_mem_free+0x220>
    59da:	49 89 d1             	mov    %rdx,%r9
    59dd:	49 c1 e9 10          	shr    $0x10,%r9
    59e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    59e5:	48 c1 e0 03          	shl    $0x3,%rax
    59e9:	49 89 c0             	mov    %rax,%r8
    59ec:	4c 03 05 05 32 06 00 	add    0x63205(%rip),%r8        # 68bf8 <fwp_heap+0x13f8>
    59f3:	0f 84 d7 01 00 00    	je     5bd0 <fwp_mem_free+0x220>
    59f9:	48 83 ec 38          	sub    $0x38,%rsp
    59fd:	48 89 f9             	mov    %rdi,%rcx
    5a00:	41 0f b6 38          	movzbl (%r8),%edi
    5a04:	40 80 ff 01          	cmp    $0x1,%dil
    5a08:	74 16                	je     5a20 <fwp_mem_free+0x70>
    5a0a:	40 80 ff 02          	cmp    $0x2,%dil
    5a0e:	0f 84 94 00 00 00    	je     5aa8 <fwp_mem_free+0xf8>
    5a14:	48 83 c4 38          	add    $0x38,%rsp
    5a18:	c3                   	ret
    5a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a20:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a24:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a29:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a2e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a32:	4d 85 d2             	test   %r10,%r10
    5a35:	74 1d                	je     5a54 <fwp_mem_free+0xa4>
    5a37:	0f b7 c1             	movzwl %cx,%eax
    5a3a:	31 d2                	xor    %edx,%edx
    5a3c:	48 f7 f7             	div    %rdi
    5a3f:	49 01 c2             	add    %rax,%r10
    5a42:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a46:	0f 84 44 01 00 00    	je     5b90 <fwp_mem_free+0x1e0>
    5a4c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a50:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a54:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a5b:	49 63 c1             	movslq %r9d,%rax
    5a5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5a62:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5a66:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5a6b:	f2 0f 58 05 cd 31 06 	addsd  0x631cd(%rip),%xmm0        # 68c40 <fwp_heap+0x1440>
    5a72:	00 
    5a73:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5a77:	48 8d 05 82 1d 06 00 	lea    0x61d82(%rip),%rax        # 67800 <fwp_heap>
    5a7e:	48 01 d0             	add    %rdx,%rax
    5a81:	48 8b 10             	mov    (%rax),%rdx
    5a84:	48 f7 d2             	not    %rdx
    5a87:	48 89 11             	mov    %rdx,(%rcx)
    5a8a:	48 89 08             	mov    %rcx,(%rax)
    5a8d:	48 29 3d 8c 31 06 00 	sub    %rdi,0x6318c(%rip)        # 68c20 <fwp_heap+0x1420>
    5a94:	f2 0f 11 05 a4 31 06 	movsd  %xmm0,0x631a4(%rip)        # 68c40 <fwp_heap+0x1440>
    5a9b:	00 
    5a9c:	48 83 c4 38          	add    $0x38,%rsp
    5aa0:	c3                   	ret
    5aa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5aa8:	66 31 d2             	xor    %dx,%dx
    5aab:	48 01 d6             	add    %rdx,%rsi
    5aae:	48 39 f1             	cmp    %rsi,%rcx
    5ab1:	0f 85 5d ff ff ff    	jne    5a14 <fwp_mem_free+0x64>
    5ab7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5abb:	48 29 15 5e 31 06 00 	sub    %rdx,0x6315e(%rip)        # 68c20 <fwp_heap+0x1420>
    5ac2:	48 85 d2             	test   %rdx,%rdx
    5ac5:	0f 88 a5 00 00 00    	js     5b70 <fwp_mem_free+0x1c0>
    5acb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5acf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5ad4:	f2 0f 58 05 64 31 06 	addsd  0x63164(%rip),%xmm0        # 68c40 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ae0:	f2 0f 11 05 58 31 06 	movsd  %xmm0,0x63158(%rip)        # 68c40 <fwp_heap+0x1440>
    5ae7:	00 
    5ae8:	48 85 d2             	test   %rdx,%rdx
    5aeb:	74 0c                	je     5af9 <fwp_mem_free+0x149>
    5aed:	80 3a ff             	cmpb   $0xff,(%rdx)
    5af0:	0f 84 db 00 00 00    	je     5bd1 <fwp_mem_free+0x221>
    5af6:	c6 02 00             	movb   $0x0,(%rdx)
    5af9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5afd:	48 85 c9             	test   %rcx,%rcx
    5b00:	74 3e                	je     5b40 <fwp_mem_free+0x190>
    5b02:	48 8b 15 ef 30 06 00 	mov    0x630ef(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    5b09:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b0d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b11:	48 01 d0             	add    %rdx,%rax
    5b14:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b18:	48 89 d6             	mov    %rdx,%rsi
    5b1b:	48 29 c6             	sub    %rax,%rsi
    5b1e:	83 e6 08             	and    $0x8,%esi
    5b21:	74 0d                	je     5b30 <fwp_mem_free+0x180>
    5b23:	c6 00 00             	movb   $0x0,(%rax)
    5b26:	48 83 c0 28          	add    $0x28,%rax
    5b2a:	48 39 c2             	cmp    %rax,%rdx
    5b2d:	74 11                	je     5b40 <fwp_mem_free+0x190>
    5b2f:	90                   	nop
    5b30:	c6 00 00             	movb   $0x0,(%rax)
    5b33:	48 83 c0 50          	add    $0x50,%rax
    5b37:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b3b:	48 39 c2             	cmp    %rax,%rdx
    5b3e:	75 f0                	jne    5b30 <fwp_mem_free+0x180>
    5b40:	48 01 0d e9 30 06 00 	add    %rcx,0x630e9(%rip)        # 68c30 <fwp_heap+0x1430>
    5b47:	4c 3b 0d a2 30 06 00 	cmp    0x630a2(%rip),%r9        # 68bf0 <fwp_heap+0x13f0>
    5b4e:	73 07                	jae    5b57 <fwp_mem_free+0x1a7>
    5b50:	4c 89 0d 99 30 06 00 	mov    %r9,0x63099(%rip)        # 68bf0 <fwp_heap+0x13f0>
    5b57:	4c 3b 0d 8a 30 06 00 	cmp    0x6308a(%rip),%r9        # 68be8 <fwp_heap+0x13e8>
    5b5e:	0f 83 b0 fe ff ff    	jae    5a14 <fwp_mem_free+0x64>
    5b64:	4c 89 0d 7d 30 06 00 	mov    %r9,0x6307d(%rip)        # 68be8 <fwp_heap+0x13e8>
    5b6b:	e9 a4 fe ff ff       	jmp    5a14 <fwp_mem_free+0x64>
    5b70:	48 89 d1             	mov    %rdx,%rcx
    5b73:	83 e2 01             	and    $0x1,%edx
    5b76:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b7a:	48 d1 e9             	shr    $1,%rcx
    5b7d:	48 09 d1             	or     %rdx,%rcx
    5b80:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5b85:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5b89:	e9 46 ff ff ff       	jmp    5ad4 <fwp_mem_free+0x124>
    5b8e:	66 90                	xchg   %ax,%ax
    5b90:	4c 89 d7             	mov    %r10,%rdi
    5b93:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5b98:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5b9d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5ba2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5ba6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5bab:	e8 c0 fb ff ff       	call   5770 <fwp_rc_forget_slot>
    5bb0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bb5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bbf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5bc4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5bc9:	e9 7e fe ff ff       	jmp    5a4c <fwp_mem_free+0x9c>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	c3                   	ret
    5bd1:	48 89 d7             	mov    %rdx,%rdi
    5bd4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5bd9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5bde:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5be3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5be8:	e8 83 fb ff ff       	call   5770 <fwp_rc_forget_slot>
    5bed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5bf2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5bf7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5bfc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c01:	e9 f0 fe ff ff       	jmp    5af6 <fwp_mem_free+0x146>
    5c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c0d:	00 00 00 

0000000000005c10 <fwp_heap_alloc_big>:
    5c10:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c17:	00 00 40 
    5c1a:	41 57                	push   %r15
    5c1c:	41 56                	push   %r14
    5c1e:	41 55                	push   %r13
    5c20:	41 54                	push   %r12
    5c22:	55                   	push   %rbp
    5c23:	53                   	push   %rbx
    5c24:	48 83 ec 08          	sub    $0x8,%rsp
    5c28:	48 39 f8             	cmp    %rdi,%rax
    5c2b:	0f 82 fa 00 00 00    	jb     5d2b <fwp_heap_alloc_big+0x11b>
    5c31:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c38:	49 89 fd             	mov    %rdi,%r13
    5c3b:	41 89 f6             	mov    %esi,%r14d
    5c3e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c42:	48 89 ef             	mov    %rbp,%rdi
    5c45:	e8 e6 e1 ff ff       	call   3e30 <fwp_heap_chunks>
    5c4a:	be 01 00 00 00       	mov    $0x1,%esi
    5c4f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c53:	49 89 c4             	mov    %rax,%r12
    5c56:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c5d:	00 
    5c5e:	48 03 3d 93 2f 06 00 	add    0x62f93(%rip),%rdi        # 68bf8 <fwp_heap+0x13f8>
    5c65:	c6 07 02             	movb   $0x2,(%rdi)
    5c68:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5c6c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5c6f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5c73:	e8 88 fb ff ff       	call   5800 <fwp_rc_prepare_chunk>
    5c78:	48 83 fd 01          	cmp    $0x1,%rbp
    5c7c:	76 47                	jbe    5cc5 <fwp_heap_alloc_big+0xb5>
    5c7e:	4c 01 e5             	add    %r12,%rbp
    5c81:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5c88:	00 
    5c89:	4c 8d 3d 70 1b 06 00 	lea    0x61b70(%rip),%r15        # 67800 <fwp_heap>
    5c90:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5c95:	49 c1 e6 03          	shl    $0x3,%r14
    5c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ca0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ca7:	31 f6                	xor    %esi,%esi
    5ca9:	48 01 dd             	add    %rbx,%rbp
    5cac:	48 83 c3 28          	add    $0x28,%rbx
    5cb0:	48 89 ef             	mov    %rbp,%rdi
    5cb3:	e8 48 fb ff ff       	call   5800 <fwp_rc_prepare_chunk>
    5cb8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cbc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5cc0:	49 39 de             	cmp    %rbx,%r14
    5cc3:	75 db                	jne    5ca0 <fwp_heap_alloc_big+0x90>
    5cc5:	49 c1 e4 10          	shl    $0x10,%r12
    5cc9:	4c 03 25 e0 2e 06 00 	add    0x62ee0(%rip),%r12        # 68bb0 <fwp_heap+0x13b0>
    5cd0:	4c 89 ea             	mov    %r13,%rdx
    5cd3:	31 f6                	xor    %esi,%esi
    5cd5:	4c 89 e7             	mov    %r12,%rdi
    5cd8:	e8 c3 d7 ff ff       	call   34a0 <memset@plt>
    5cdd:	4c 89 e8             	mov    %r13,%rax
    5ce0:	48 03 05 39 2f 06 00 	add    0x62f39(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    5ce7:	72 42                	jb     5d2b <fwp_heap_alloc_big+0x11b>
    5ce9:	48 39 05 38 2f 06 00 	cmp    %rax,0x62f38(%rip)        # 68c28 <fwp_heap+0x1428>
    5cf0:	48 89 05 29 2f 06 00 	mov    %rax,0x62f29(%rip)        # 68c20 <fwp_heap+0x1420>
    5cf7:	73 07                	jae    5d00 <fwp_heap_alloc_big+0xf0>
    5cf9:	48 89 05 28 2f 06 00 	mov    %rax,0x62f28(%rip)        # 68c28 <fwp_heap+0x1428>
    5d00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d04:	4c 89 e0             	mov    %r12,%rax
    5d07:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d0c:	f2 0f 58 05 24 2f 06 	addsd  0x62f24(%rip),%xmm0        # 68c38 <fwp_heap+0x1438>
    5d13:	00 
    5d14:	f2 0f 11 05 1c 2f 06 	movsd  %xmm0,0x62f1c(%rip)        # 68c38 <fwp_heap+0x1438>
    5d1b:	00 
    5d1c:	48 83 c4 08          	add    $0x8,%rsp
    5d20:	5b                   	pop    %rbx
    5d21:	5d                   	pop    %rbp
    5d22:	41 5c                	pop    %r12
    5d24:	41 5d                	pop    %r13
    5d26:	41 5e                	pop    %r14
    5d28:	41 5f                	pop    %r15
    5d2a:	c3                   	ret
    5d2b:	e8 c0 e0 ff ff       	call   3df0 <fwp_heap_oom>

0000000000005d30 <fwp_heap_alloc_slow>:
    5d30:	53                   	push   %rbx
    5d31:	48 89 f9             	mov    %rdi,%rcx
    5d34:	41 89 f1             	mov    %esi,%r9d
    5d37:	48 83 ec 10          	sub    $0x10,%rsp
    5d3b:	8b 05 63 2e 06 00    	mov    0x62e63(%rip),%eax        # 68ba4 <fwp_heap+0x13a4>
    5d41:	85 c0                	test   %eax,%eax
    5d43:	0f 84 c7 00 00 00    	je     5e10 <fwp_heap_alloc_slow+0xe0>
    5d49:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d50:	0f 87 dd 00 00 00    	ja     5e33 <fwp_heap_alloc_slow+0x103>
    5d56:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d5a:	48 8d 3d 9f 1a 06 00 	lea    0x61a9f(%rip),%rdi        # 67800 <fwp_heap>
    5d61:	49 63 f1             	movslq %r9d,%rsi
    5d64:	48 c1 e8 04          	shr    $0x4,%rax
    5d68:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5d6f:	00 00 
    5d71:	41 0f b6 c2          	movzbl %r10b,%eax
    5d75:	4c 89 d2             	mov    %r10,%rdx
    5d78:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5d7c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5d83:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5d8a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5d8e:	48 01 f8             	add    %rdi,%rax
    5d91:	4c 8b 00             	mov    (%rax),%r8
    5d94:	4d 85 c0             	test   %r8,%r8
    5d97:	0f 84 ab 00 00 00    	je     5e48 <fwp_heap_alloc_slow+0x118>
    5d9d:	49 8b 10             	mov    (%r8),%rdx
    5da0:	48 f7 d2             	not    %rdx
    5da3:	48 89 10             	mov    %rdx,(%rax)
    5da6:	41 83 f9 01          	cmp    $0x1,%r9d
    5daa:	4c 89 c7             	mov    %r8,%rdi
    5dad:	48 0f 45 cb          	cmovne %rbx,%rcx
    5db1:	31 f6                	xor    %esi,%esi
    5db3:	48 89 ca             	mov    %rcx,%rdx
    5db6:	e8 e5 d6 ff ff       	call   34a0 <memset@plt>
    5dbb:	49 89 c0             	mov    %rax,%r8
    5dbe:	48 89 d8             	mov    %rbx,%rax
    5dc1:	48 03 05 58 2e 06 00 	add    0x62e58(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    5dc8:	0f 82 d9 00 00 00    	jb     5ea7 <fwp_heap_alloc_slow+0x177>
    5dce:	48 39 05 53 2e 06 00 	cmp    %rax,0x62e53(%rip)        # 68c28 <fwp_heap+0x1428>
    5dd5:	48 89 05 44 2e 06 00 	mov    %rax,0x62e44(%rip)        # 68c20 <fwp_heap+0x1420>
    5ddc:	73 07                	jae    5de5 <fwp_heap_alloc_slow+0xb5>
    5dde:	48 89 05 43 2e 06 00 	mov    %rax,0x62e43(%rip)        # 68c28 <fwp_heap+0x1428>
    5de5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5de9:	4c 89 c0             	mov    %r8,%rax
    5dec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5df1:	f2 0f 58 05 3f 2e 06 	addsd  0x62e3f(%rip),%xmm0        # 68c38 <fwp_heap+0x1438>
    5df8:	00 
    5df9:	f2 0f 11 05 37 2e 06 	movsd  %xmm0,0x62e37(%rip)        # 68c38 <fwp_heap+0x1438>
    5e00:	00 
    5e01:	48 83 c4 10          	add    $0x10,%rsp
    5e05:	5b                   	pop    %rbx
    5e06:	c3                   	ret
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 
    5e10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e18:	e8 73 ef ff ff       	call   4d90 <fwp_heap_init>
    5e1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e2d:	0f 86 23 ff ff ff    	jbe    5d56 <fwp_heap_alloc_slow+0x26>
    5e33:	48 83 c4 10          	add    $0x10,%rsp
    5e37:	44 89 ce             	mov    %r9d,%esi
    5e3a:	48 89 cf             	mov    %rcx,%rdi
    5e3d:	5b                   	pop    %rbx
    5e3e:	e9 cd fd ff ff       	jmp    5c10 <fwp_heap_alloc_big>
    5e43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e4c:	4d 85 c0             	test   %r8,%r8
    5e4f:	74 1f                	je     5e70 <fwp_heap_alloc_slow+0x140>
    5e51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e55:	4d 29 c3             	sub    %r8,%r11
    5e58:	49 39 db             	cmp    %rbx,%r11
    5e5b:	72 13                	jb     5e70 <fwp_heap_alloc_slow+0x140>
    5e5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5e61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e65:	e9 3c ff ff ff       	jmp    5da6 <fwp_heap_alloc_slow+0x76>
    5e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5e77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5e7b:	44 89 ca             	mov    %r9d,%edx
    5e7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5e8b:	44 89 d6             	mov    %r10d,%esi
    5e8e:	48 01 c7             	add    %rax,%rdi
    5e91:	e8 6a fa ff ff       	call   5900 <fwp_heap_refill>
    5e96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e9f:	49 89 c0             	mov    %rax,%r8
    5ea2:	e9 ff fe ff ff       	jmp    5da6 <fwp_heap_alloc_slow+0x76>
    5ea7:	e8 44 df ff ff       	call   3df0 <fwp_heap_oom>
    5eac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005eb0 <fwp_heap_alloc>:
    5eb0:	53                   	push   %rbx
    5eb1:	48 89 fa             	mov    %rdi,%rdx
    5eb4:	48 83 ec 10          	sub    $0x10,%rsp
    5eb8:	8b 1d 0a 36 06 00    	mov    0x6360a(%rip),%ebx        # 694c8 <iteration_active>
    5ebe:	8b 05 e0 2c 06 00    	mov    0x62ce0(%rip),%eax        # 68ba4 <fwp_heap+0x13a4>
    5ec4:	85 db                	test   %ebx,%ebx
    5ec6:	0f 85 04 01 00 00    	jne    5fd0 <fwp_heap_alloc+0x120>
    5ecc:	85 c0                	test   %eax,%eax
    5ece:	0f 84 ac 01 00 00    	je     6080 <fwp_heap_alloc+0x1d0>
    5ed4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5edb:	0f 87 9f 01 00 00    	ja     6080 <fwp_heap_alloc+0x1d0>
    5ee1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ee5:	48 8d 05 14 19 06 00 	lea    0x61914(%rip),%rax        # 67800 <fwp_heap>
    5eec:	48 c1 e9 04          	shr    $0x4,%rcx
    5ef0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5ef7:	00 
    5ef8:	48 63 ce             	movslq %esi,%rcx
    5efb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f02:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f09:	00 
    5f0a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f0e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f12:	48 01 c8             	add    %rcx,%rax
    5f15:	48 8b 08             	mov    (%rax),%rcx
    5f18:	48 85 c9             	test   %rcx,%rcx
    5f1b:	0f 84 ff 00 00 00    	je     6020 <fwp_heap_alloc+0x170>
    5f21:	48 8b 39             	mov    (%rcx),%rdi
    5f24:	48 f7 d7             	not    %rdi
    5f27:	48 89 38             	mov    %rdi,(%rax)
    5f2a:	83 fe 01             	cmp    $0x1,%esi
    5f2d:	48 89 cf             	mov    %rcx,%rdi
    5f30:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f35:	49 0f 45 d0          	cmovne %r8,%rdx
    5f39:	31 f6                	xor    %esi,%esi
    5f3b:	e8 60 d5 ff ff       	call   34a0 <memset@plt>
    5f40:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f45:	48 89 c1             	mov    %rax,%rcx
    5f48:	4c 89 c0             	mov    %r8,%rax
    5f4b:	48 03 05 ce 2c 06 00 	add    0x62cce(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    5f52:	0f 82 35 01 00 00    	jb     608d <fwp_heap_alloc+0x1dd>
    5f58:	48 39 05 c9 2c 06 00 	cmp    %rax,0x62cc9(%rip)        # 68c28 <fwp_heap+0x1428>
    5f5f:	48 89 05 ba 2c 06 00 	mov    %rax,0x62cba(%rip)        # 68c20 <fwp_heap+0x1420>
    5f66:	73 07                	jae    5f6f <fwp_heap_alloc+0xbf>
    5f68:	48 89 05 b9 2c 06 00 	mov    %rax,0x62cb9(%rip)        # 68c28 <fwp_heap+0x1428>
    5f6f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5f73:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5f78:	f2 0f 58 05 b8 2c 06 	addsd  0x62cb8(%rip),%xmm0        # 68c38 <fwp_heap+0x1438>
    5f7f:	00 
    5f80:	f2 0f 11 05 b0 2c 06 	movsd  %xmm0,0x62cb0(%rip)        # 68c38 <fwp_heap+0x1438>
    5f87:	00 
    5f88:	85 db                	test   %ebx,%ebx
    5f8a:	74 33                	je     5fbf <fwp_heap_alloc+0x10f>
    5f8c:	48 8b 05 8d 2c 06 00 	mov    0x62c8d(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    5f93:	48 85 c0             	test   %rax,%rax
    5f96:	0f 88 ac 00 00 00    	js     6048 <fwp_heap_alloc+0x198>
    5f9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fa0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fa5:	f2 0f 5c 05 fb 34 06 	subsd  0x634fb(%rip),%xmm0        # 694a8 <iteration_start_charge>
    5fac:	00 
    5fad:	66 0f 2f 05 eb 34 06 	comisd 0x634eb(%rip),%xmm0        # 694a0 <iteration_peak>
    5fb4:	00 
    5fb5:	76 08                	jbe    5fbf <fwp_heap_alloc+0x10f>
    5fb7:	f2 0f 11 05 e1 34 06 	movsd  %xmm0,0x634e1(%rip)        # 694a0 <iteration_peak>
    5fbe:	00 
    5fbf:	48 83 c4 10          	add    $0x10,%rsp
    5fc3:	48 89 c8             	mov    %rcx,%rax
    5fc6:	5b                   	pop    %rbx
    5fc7:	c3                   	ret
    5fc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5fcf:	00 
    5fd0:	85 f6                	test   %esi,%esi
    5fd2:	74 34                	je     6008 <fwp_heap_alloc+0x158>
    5fd4:	48 83 05 e4 34 06 00 	addq   $0x1,0x634e4(%rip)        # 694c0 <iteration_requests>
    5fdb:	01 
    5fdc:	48 01 3d d5 34 06 00 	add    %rdi,0x634d5(%rip)        # 694b8 <iteration_bytes>
    5fe3:	85 c0                	test   %eax,%eax
    5fe5:	74 0d                	je     5ff4 <fwp_heap_alloc+0x144>
    5fe7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5fee:	0f 86 ed fe ff ff    	jbe    5ee1 <fwp_heap_alloc+0x31>
    5ff4:	48 89 d7             	mov    %rdx,%rdi
    5ff7:	e8 34 fd ff ff       	call   5d30 <fwp_heap_alloc_slow>
    5ffc:	48 89 c1             	mov    %rax,%rcx
    5fff:	eb 8b                	jmp    5f8c <fwp_heap_alloc+0xdc>
    6001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6008:	85 c0                	test   %eax,%eax
    600a:	74 0d                	je     6019 <fwp_heap_alloc+0x169>
    600c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6013:	0f 86 c8 fe ff ff    	jbe    5ee1 <fwp_heap_alloc+0x31>
    6019:	31 f6                	xor    %esi,%esi
    601b:	eb d7                	jmp    5ff4 <fwp_heap_alloc+0x144>
    601d:	0f 1f 00             	nopl   (%rax)
    6020:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6024:	48 85 c9             	test   %rcx,%rcx
    6027:	74 0c                	je     6035 <fwp_heap_alloc+0x185>
    6029:	48 8b 78 10          	mov    0x10(%rax),%rdi
    602d:	48 29 cf             	sub    %rcx,%rdi
    6030:	4c 39 c7             	cmp    %r8,%rdi
    6033:	73 3b                	jae    6070 <fwp_heap_alloc+0x1c0>
    6035:	48 89 d7             	mov    %rdx,%rdi
    6038:	e8 f3 fc ff ff       	call   5d30 <fwp_heap_alloc_slow>
    603d:	48 89 c1             	mov    %rax,%rcx
    6040:	e9 43 ff ff ff       	jmp    5f88 <fwp_heap_alloc+0xd8>
    6045:	0f 1f 00             	nopl   (%rax)
    6048:	48 89 c2             	mov    %rax,%rdx
    604b:	83 e0 01             	and    $0x1,%eax
    604e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6052:	48 d1 ea             	shr    $1,%rdx
    6055:	48 09 c2             	or     %rax,%rdx
    6058:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    605d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6061:	e9 3f ff ff ff       	jmp    5fa5 <fwp_heap_alloc+0xf5>
    6066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    606d:	00 00 00 
    6070:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6074:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6078:	e9 ad fe ff ff       	jmp    5f2a <fwp_heap_alloc+0x7a>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 83 c4 10          	add    $0x10,%rsp
    6084:	48 89 d7             	mov    %rdx,%rdi
    6087:	5b                   	pop    %rbx
    6088:	e9 a3 fc ff ff       	jmp    5d30 <fwp_heap_alloc_slow>
    608d:	e8 5e dd ff ff       	call   3df0 <fwp_heap_oom>
    6092:	0f 1f 00             	nopl   (%rax)
    6095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    609c:	00 00 00 00 

00000000000060a0 <fwp_data.part.0.constprop.0>:
    60a0:	41 56                	push   %r14
    60a2:	8b 05 fc 2a 06 00    	mov    0x62afc(%rip),%eax        # 68ba4 <fwp_heap+0x13a4>
    60a8:	41 89 fe             	mov    %edi,%r14d
    60ab:	41 55                	push   %r13
    60ad:	44 8b 2d 14 34 06 00 	mov    0x63414(%rip),%r13d        # 694c8 <iteration_active>
    60b4:	41 54                	push   %r12
    60b6:	49 89 f4             	mov    %rsi,%r12
    60b9:	55                   	push   %rbp
    60ba:	53                   	push   %rbx
    60bb:	45 85 ed             	test   %r13d,%r13d
    60be:	0f 84 1c 01 00 00    	je     61e0 <fwp_data.part.0.constprop.0+0x140>
    60c4:	48 83 05 f4 33 06 00 	addq   $0x1,0x633f4(%rip)        # 694c0 <iteration_requests>
    60cb:	01 
    60cc:	48 83 05 e4 33 06 00 	addq   $0x18,0x633e4(%rip)        # 694b8 <iteration_bytes>
    60d3:	18 
    60d4:	85 c0                	test   %eax,%eax
    60d6:	0f 84 8c 01 00 00    	je     6268 <fwp_data.part.0.constprop.0+0x1c8>
    60dc:	0f b6 05 bf 26 06 00 	movzbl 0x626bf(%rip),%eax        # 687a2 <fwp_heap+0xfa2>
    60e3:	48 8d 15 16 17 06 00 	lea    0x61716(%rip),%rdx        # 67800 <fwp_heap>
    60ea:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    60f1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    60f5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    60f9:	48 8b 18             	mov    (%rax),%rbx
    60fc:	48 85 db             	test   %rbx,%rbx
    60ff:	0f 84 fb 00 00 00    	je     6200 <fwp_data.part.0.constprop.0+0x160>
    6105:	48 8b 13             	mov    (%rbx),%rdx
    6108:	48 f7 d2             	not    %rdx
    610b:	48 89 10             	mov    %rdx,(%rax)
    610e:	48 83 fd 18          	cmp    $0x18,%rbp
    6112:	76 1b                	jbe    612f <fwp_data.part.0.constprop.0+0x8f>
    6114:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6118:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    611c:	31 f6                	xor    %esi,%esi
    611e:	48 c1 e8 03          	shr    $0x3,%rax
    6122:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6129:	00 
    612a:	e8 71 d3 ff ff       	call   34a0 <memset@plt>
    612f:	48 89 e8             	mov    %rbp,%rax
    6132:	48 03 05 e7 2a 06 00 	add    0x62ae7(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    6139:	0f 82 3d 01 00 00    	jb     627c <fwp_data.part.0.constprop.0+0x1dc>
    613f:	48 39 05 e2 2a 06 00 	cmp    %rax,0x62ae2(%rip)        # 68c28 <fwp_heap+0x1428>
    6146:	48 89 05 d3 2a 06 00 	mov    %rax,0x62ad3(%rip)        # 68c20 <fwp_heap+0x1420>
    614d:	73 07                	jae    6156 <fwp_data.part.0.constprop.0+0xb6>
    614f:	48 89 05 d2 2a 06 00 	mov    %rax,0x62ad2(%rip)        # 68c28 <fwp_heap+0x1428>
    6156:	66 0f ef c0          	pxor   %xmm0,%xmm0
    615a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    615f:	f2 0f 58 05 d1 2a 06 	addsd  0x62ad1(%rip),%xmm0        # 68c38 <fwp_heap+0x1438>
    6166:	00 
    6167:	f2 0f 11 05 c9 2a 06 	movsd  %xmm0,0x62ac9(%rip)        # 68c38 <fwp_heap+0x1438>
    616e:	00 
    616f:	45 85 ed             	test   %r13d,%r13d
    6172:	74 33                	je     61a7 <fwp_data.part.0.constprop.0+0x107>
    6174:	48 8b 05 a5 2a 06 00 	mov    0x62aa5(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    617b:	48 85 c0             	test   %rax,%rax
    617e:	0f 88 a4 00 00 00    	js     6228 <fwp_data.part.0.constprop.0+0x188>
    6184:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6188:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    618d:	f2 0f 5c 05 13 33 06 	subsd  0x63313(%rip),%xmm0        # 694a8 <iteration_start_charge>
    6194:	00 
    6195:	66 0f 2f 05 03 33 06 	comisd 0x63303(%rip),%xmm0        # 694a0 <iteration_peak>
    619c:	00 
    619d:	76 08                	jbe    61a7 <fwp_data.part.0.constprop.0+0x107>
    619f:	f2 0f 11 05 f9 32 06 	movsd  %xmm0,0x632f9(%rip)        # 694a0 <iteration_peak>
    61a6:	00 
    61a7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ac:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61b1:	66 0f 6e c8          	movd   %eax,%xmm1
    61b5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61b9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61bd:	49 8b 04 24          	mov    (%r12),%rax
    61c1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    61c5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    61ca:	48 89 43 10          	mov    %rax,0x10(%rbx)
    61ce:	48 89 d8             	mov    %rbx,%rax
    61d1:	5b                   	pop    %rbx
    61d2:	5d                   	pop    %rbp
    61d3:	41 5c                	pop    %r12
    61d5:	41 5d                	pop    %r13
    61d7:	41 5e                	pop    %r14
    61d9:	c3                   	ret
    61da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61e0:	85 c0                	test   %eax,%eax
    61e2:	0f 85 f4 fe ff ff    	jne    60dc <fwp_data.part.0.constprop.0+0x3c>
    61e8:	31 f6                	xor    %esi,%esi
    61ea:	bf 18 00 00 00       	mov    $0x18,%edi
    61ef:	e8 bc fc ff ff       	call   5eb0 <fwp_heap_alloc>
    61f4:	48 89 c3             	mov    %rax,%rbx
    61f7:	eb ae                	jmp    61a7 <fwp_data.part.0.constprop.0+0x107>
    61f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6200:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6204:	48 85 db             	test   %rbx,%rbx
    6207:	74 47                	je     6250 <fwp_data.part.0.constprop.0+0x1b0>
    6209:	48 8b 50 10          	mov    0x10(%rax),%rdx
    620d:	48 29 da             	sub    %rbx,%rdx
    6210:	48 39 ea             	cmp    %rbp,%rdx
    6213:	72 3b                	jb     6250 <fwp_data.part.0.constprop.0+0x1b0>
    6215:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6219:	48 89 50 08          	mov    %rdx,0x8(%rax)
    621d:	e9 ec fe ff ff       	jmp    610e <fwp_data.part.0.constprop.0+0x6e>
    6222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6228:	48 89 c2             	mov    %rax,%rdx
    622b:	83 e0 01             	and    $0x1,%eax
    622e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6232:	48 d1 ea             	shr    $1,%rdx
    6235:	48 09 c2             	or     %rax,%rdx
    6238:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    623d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6241:	e9 47 ff ff ff       	jmp    618d <fwp_data.part.0.constprop.0+0xed>
    6246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    624d:	00 00 00 
    6250:	31 f6                	xor    %esi,%esi
    6252:	bf 18 00 00 00       	mov    $0x18,%edi
    6257:	e8 54 fc ff ff       	call   5eb0 <fwp_heap_alloc>
    625c:	48 89 c3             	mov    %rax,%rbx
    625f:	e9 0b ff ff ff       	jmp    616f <fwp_data.part.0.constprop.0+0xcf>
    6264:	0f 1f 40 00          	nopl   0x0(%rax)
    6268:	31 f6                	xor    %esi,%esi
    626a:	bf 18 00 00 00       	mov    $0x18,%edi
    626f:	e8 3c fc ff ff       	call   5eb0 <fwp_heap_alloc>
    6274:	48 89 c3             	mov    %rax,%rbx
    6277:	e9 f8 fe ff ff       	jmp    6174 <fwp_data.part.0.constprop.0+0xd4>
    627c:	e8 6f db ff ff       	call   3df0 <fwp_heap_oom>
    6281:	0f 1f 40 00          	nopl   0x0(%rax)
    6285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    628c:	00 00 00 00 

0000000000006290 <fwp_tape_grow.constprop.0>:
    6290:	41 56                	push   %r14
    6292:	b8 40 00 00 00       	mov    $0x40,%eax
    6297:	41 55                	push   %r13
    6299:	41 54                	push   %r12
    629b:	55                   	push   %rbp
    629c:	48 89 fd             	mov    %rdi,%rbp
    629f:	53                   	push   %rbx
    62a0:	48 83 ec 10          	sub    $0x10,%rsp
    62a4:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    62a8:	48 85 db             	test   %rbx,%rbx
    62ab:	48 0f 44 d8          	cmove  %rax,%rbx
    62af:	48 39 de             	cmp    %rbx,%rsi
    62b2:	7e 12                	jle    62c6 <fwp_tape_grow.constprop.0+0x36>
    62b4:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    62bb:	0f 8e df 00 00 00    	jle    63a0 <fwp_tape_grow.constprop.0+0x110>
    62c1:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    62c6:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    62ca:	4d 85 e4             	test   %r12,%r12
    62cd:	0f 84 dd 00 00 00    	je     63b0 <fwp_tape_grow.constprop.0+0x120>
    62d3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    62d7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    62de:	00 
    62df:	ba 01 00 00 00       	mov    $0x1,%edx
    62e4:	e8 67 ee ff ff       	call   5150 <ad_raw_realloc>
    62e9:	48 85 c0             	test   %rax,%rax
    62ec:	0f 84 eb 00 00 00    	je     63dd <fwp_tape_grow.constprop.0+0x14d>
    62f2:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    62f7:	48 89 45 28          	mov    %rax,0x28(%rbp)
    62fb:	48 39 da             	cmp    %rbx,%rdx
    62fe:	0f 8d 8b 00 00 00    	jge    638f <fwp_tape_grow.constprop.0+0xff>
    6304:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    630b:	ff ff 07 
    630e:	48 39 c3             	cmp    %rax,%rbx
    6311:	0f 8f ba 00 00 00    	jg     63d1 <fwp_tape_grow.constprop.0+0x141>
    6317:	48 89 d9             	mov    %rbx,%rcx
    631a:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    631f:	be 02 00 00 00       	mov    $0x2,%esi
    6324:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6329:	48 c1 e1 04          	shl    $0x4,%rcx
    632d:	48 89 cf             	mov    %rcx,%rdi
    6330:	48 89 0c 24          	mov    %rcx,(%rsp)
    6334:	e8 77 fb ff ff       	call   5eb0 <fwp_heap_alloc>
    6339:	49 89 c5             	mov    %rax,%r13
    633c:	4d 85 f6             	test   %r14,%r14
    633f:	74 27                	je     6368 <fwp_tape_grow.constprop.0+0xd8>
    6341:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6346:	48 8b 0c 24          	mov    (%rsp),%rcx
    634a:	48 89 c7             	mov    %rax,%rdi
    634d:	4c 89 f6             	mov    %r14,%rsi
    6350:	48 c1 e2 04          	shl    $0x4,%rdx
    6354:	48 39 ca             	cmp    %rcx,%rdx
    6357:	48 0f 47 d1          	cmova  %rcx,%rdx
    635b:	e8 10 d2 ff ff       	call   3570 <memcpy@plt>
    6360:	4c 89 f7             	mov    %r14,%rdi
    6363:	e8 48 f6 ff ff       	call   59b0 <fwp_mem_free>
    6368:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    636d:	48 89 da             	mov    %rbx,%rdx
    6370:	31 f6                	xor    %esi,%esi
    6372:	48 29 fa             	sub    %rdi,%rdx
    6375:	48 c1 e7 04          	shl    $0x4,%rdi
    6379:	48 c1 e2 04          	shl    $0x4,%rdx
    637d:	4c 01 ef             	add    %r13,%rdi
    6380:	e8 1b d1 ff ff       	call   34a0 <memset@plt>
    6385:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    638a:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    638f:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    6393:	48 83 c4 10          	add    $0x10,%rsp
    6397:	5b                   	pop    %rbx
    6398:	5d                   	pop    %rbp
    6399:	41 5c                	pop    %r12
    639b:	41 5d                	pop    %r13
    639d:	41 5e                	pop    %r14
    639f:	c3                   	ret
    63a0:	48 01 db             	add    %rbx,%rbx
    63a3:	e9 07 ff ff ff       	jmp    62af <fwp_tape_grow.constprop.0+0x1f>
    63a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63af:	00 
    63b0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    63b4:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63b8:	ba 02 00 00 00       	mov    $0x2,%edx
    63bd:	48 c1 e6 03          	shl    $0x3,%rsi
    63c1:	e8 8a ed ff ff       	call   5150 <ad_raw_realloc>
    63c6:	48 85 c0             	test   %rax,%rax
    63c9:	74 12                	je     63dd <fwp_tape_grow.constprop.0+0x14d>
    63cb:	48 89 45 20          	mov    %rax,0x20(%rbp)
    63cf:	eb be                	jmp    638f <fwp_tape_grow.constprop.0+0xff>
    63d1:	48 8d 3d d1 4d 00 00 	lea    0x4dd1(%rip),%rdi        # b1a9 <_IO_stdin_used+0x1a9>
    63d8:	e8 33 e0 ff ff       	call   4410 <fwp_trap>
    63dd:	48 89 ef             	mov    %rbp,%rdi
    63e0:	e8 6b d8 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    63e5:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63e9:	48 85 ff             	test   %rdi,%rdi
    63ec:	74 05                	je     63f3 <fwp_tape_grow.constprop.0+0x163>
    63ee:	e8 9d ec ff ff       	call   5090 <ad_raw_free.part.0>
    63f3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    63f7:	48 85 ff             	test   %rdi,%rdi
    63fa:	74 05                	je     6401 <fwp_tape_grow.constprop.0+0x171>
    63fc:	e8 8f ec ff ff       	call   5090 <ad_raw_free.part.0>
    6401:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6405:	48 85 ff             	test   %rdi,%rdi
    6408:	74 05                	je     640f <fwp_tape_grow.constprop.0+0x17f>
    640a:	e8 81 ec ff ff       	call   5090 <ad_raw_free.part.0>
    640f:	31 c9                	xor    %ecx,%ecx
    6411:	31 c0                	xor    %eax,%eax
    6413:	31 d2                	xor    %edx,%edx
    6415:	be 01 00 00 00       	mov    $0x1,%esi
    641a:	89 55 04             	mov    %edx,0x4(%rbp)
    641d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6421:	ba 13 00 00 00       	mov    $0x13,%edx
    6426:	48 8d 3d db 4b 00 00 	lea    0x4bdb(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    642d:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    6431:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6435:	48 8b 0d 04 8c 00 00 	mov    0x8c04(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    643c:	48 89 45 30          	mov    %rax,0x30(%rbp)
    6440:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6444:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6448:	e8 f3 d1 ff ff       	call   3640 <fwrite@plt>
    644d:	31 ff                	xor    %edi,%edi
    644f:	e8 3c d1 ff ff       	call   3590 <fflush@plt>
    6454:	bf 66 00 00 00       	mov    $0x66,%edi
    6459:	e8 02 d2 ff ff       	call   3660 <_Exit@plt>
    645e:	66 90                	xchg   %ax,%ax

0000000000006460 <w123>:
    6460:	41 56                	push   %r14
    6462:	55                   	push   %rbp
    6463:	53                   	push   %rbx
    6464:	48 83 ec 30          	sub    $0x30,%rsp
    6468:	48 85 f7             	test   %rsi,%rdi
    646b:	0f 88 a7 01 00 00    	js     6618 <w123+0x1b8>
    6471:	48 89 f8             	mov    %rdi,%rax
    6474:	48 89 fb             	mov    %rdi,%rbx
    6477:	48 89 f5             	mov    %rsi,%rbp
    647a:	48 09 f0             	or     %rsi,%rax
    647d:	0f 89 5d 01 00 00    	jns    65e0 <w123+0x180>
    6483:	48 85 ff             	test   %rdi,%rdi
    6486:	0f 88 a4 01 00 00    	js     6630 <w123+0x1d0>
    648c:	48 89 d9             	mov    %rbx,%rcx
    648f:	4c 8b 35 6a 58 00 00 	mov    0x586a(%rip),%r14        # bd00 <msg.4+0x90>
    6496:	48 c1 f9 20          	sar    $0x20,%rcx
    649a:	48 39 0a             	cmp    %rcx,(%rdx)
    649d:	0f 84 65 01 00 00    	je     6608 <w123+0x1a8>
    64a3:	48 89 cf             	mov    %rcx,%rdi
    64a6:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    64ab:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    64b0:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    64b6:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    64bc:	e8 2f e2 ff ff       	call   46f0 <fwp_tape_of>
    64c1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    64c6:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    64cc:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    64d1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    64d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    64dc:	0f 85 7f 01 00 00    	jne    6661 <w123+0x201>
    64e2:	48 89 0a             	mov    %rcx,(%rdx)
    64e5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    64e9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    64ed:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    64f4:	0f 8f 4f 01 00 00    	jg     6649 <w123+0x1e9>
    64fa:	89 da                	mov    %ebx,%edx
    64fc:	48 39 d1             	cmp    %rdx,%rcx
    64ff:	0f 8e 50 01 00 00    	jle    6655 <w123+0x1f5>
    6505:	48 85 ed             	test   %rbp,%rbp
    6508:	78 0b                	js     6515 <w123+0xb5>
    650a:	89 ea                	mov    %ebp,%edx
    650c:	48 39 d1             	cmp    %rdx,%rcx
    650f:	0f 8e 40 01 00 00    	jle    6655 <w123+0x1f5>
    6515:	48 89 ca             	mov    %rcx,%rdx
    6518:	48 2b 50 08          	sub    0x8(%rax),%rdx
    651c:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6520:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6527:	0f 87 1c 01 00 00    	ja     6649 <w123+0x1e9>
    652d:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6531:	7e 3e                	jle    6571 <w123+0x111>
    6533:	48 89 c7             	mov    %rax,%rdi
    6536:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    653b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6540:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6545:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    654b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6551:	e8 3a fd ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6556:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    655c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6562:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6567:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    656c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6571:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    6575:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6579:	48 85 ed             	test   %rbp,%rbp
    657c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    6581:	48 8b 3d 78 57 00 00 	mov    0x5778(%rip),%rdi        # bd00 <msg.4+0x90>
    6588:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    658c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6590:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    6597:	48 0f 48 ee          	cmovs  %rsi,%rbp
    659b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    659f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    65a3:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    65a8:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    65ac:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    65b0:	66 0f d6 12          	movq   %xmm2,(%rdx)
    65b4:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    65b8:	48 89 50 10          	mov    %rdx,0x10(%rax)
    65bc:	48 83 c4 30          	add    $0x30,%rsp
    65c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65c7:	ff ff ff 
    65ca:	48 21 c3             	and    %rax,%rbx
    65cd:	48 09 cb             	or     %rcx,%rbx
    65d0:	48 89 d8             	mov    %rbx,%rax
    65d3:	5b                   	pop    %rbx
    65d4:	5d                   	pop    %rbp
    65d5:	41 5e                	pop    %r14
    65d7:	c3                   	ret
    65d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65df:	00 
    65e0:	48 89 f9             	mov    %rdi,%rcx
    65e3:	48 89 f0             	mov    %rsi,%rax
    65e6:	48 c1 f9 20          	sar    $0x20,%rcx
    65ea:	48 c1 f8 20          	sar    $0x20,%rax
    65ee:	48 39 c1             	cmp    %rax,%rcx
    65f1:	0f 84 95 fe ff ff    	je     648c <w123+0x2c>
    65f7:	48 8d 3d d2 53 00 00 	lea    0x53d2(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    65fe:	e8 0d de ff ff       	call   4410 <fwp_trap>
    6603:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6608:	48 8b 42 08          	mov    0x8(%rdx),%rax
    660c:	e9 d8 fe ff ff       	jmp    64e9 <w123+0x89>
    6611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6618:	48 83 c4 30          	add    $0x30,%rsp
    661c:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6623:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6627:	48 89 d8             	mov    %rbx,%rax
    662a:	5b                   	pop    %rbx
    662b:	5d                   	pop    %rbp
    662c:	41 5e                	pop    %r14
    662e:	c3                   	ret
    662f:	90                   	nop
    6630:	48 89 f1             	mov    %rsi,%rcx
    6633:	48 89 f3             	mov    %rsi,%rbx
    6636:	45 31 f6             	xor    %r14d,%r14d
    6639:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6640:	48 c1 f9 20          	sar    $0x20,%rcx
    6644:	e9 51 fe ff ff       	jmp    649a <w123+0x3a>
    6649:	48 8d 3d 59 4b 00 00 	lea    0x4b59(%rip),%rdi        # b1a9 <_IO_stdin_used+0x1a9>
    6650:	e8 bb dd ff ff       	call   4410 <fwp_trap>
    6655:	48 8d 3d 68 4b 00 00 	lea    0x4b68(%rip),%rdi        # b1c4 <_IO_stdin_used+0x1c4>
    665c:	e8 af dd ff ff       	call   4410 <fwp_trap>
    6661:	48 8d 3d b0 53 00 00 	lea    0x53b0(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    6668:	e8 a3 dd ff ff       	call   4410 <fwp_trap>
    666d:	0f 1f 00             	nopl   (%rax)

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 57                	push   %r15
    6676:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667a:	41 56                	push   %r14
    667c:	41 55                	push   %r13
    667e:	49 89 fd             	mov    %rdi,%r13
    6681:	41 54                	push   %r12
    6683:	49 89 d4             	mov    %rdx,%r12
    6686:	55                   	push   %rbp
    6687:	48 89 f5             	mov    %rsi,%rbp
    668a:	53                   	push   %rbx
    668b:	48 83 ec 48          	sub    $0x48,%rsp
    668f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6695:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    669a:	48 85 ff             	test   %rdi,%rdi
    669d:	0f 88 5d 06 00 00    	js     6d00 <w120+0x690>
    66a3:	49 89 fe             	mov    %rdi,%r14
    66a6:	49 c1 fe 20          	sar    $0x20,%r14
    66aa:	4c 3b 32             	cmp    (%rdx),%r14
    66ad:	0f 84 ed 05 00 00    	je     6ca0 <w120+0x630>
    66b3:	4c 89 f7             	mov    %r14,%rdi
    66b6:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    66bc:	e8 2f e0 ff ff       	call   46f0 <fwp_tape_of>
    66c1:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    66c7:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    66cc:	48 89 c3             	mov    %rax,%rbx
    66cf:	0f 85 97 06 00 00    	jne    6d6c <w120+0x6fc>
    66d5:	4d 89 34 24          	mov    %r14,(%r12)
    66d9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    66de:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    66e2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    66e9:	0f 8f 71 06 00 00    	jg     6d60 <w120+0x6f0>
    66ef:	44 89 e8             	mov    %r13d,%eax
    66f2:	49 39 c6             	cmp    %rax,%r14
    66f5:	0f 8e 4a 06 00 00    	jle    6d45 <w120+0x6d5>
    66fb:	4c 89 f0             	mov    %r14,%rax
    66fe:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6702:	48 8d 70 01          	lea    0x1(%rax),%rsi
    6706:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    670d:	0f 87 4d 06 00 00    	ja     6d60 <w120+0x6f0>
    6713:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    6719:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    671d:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    6721:	0f 8f 61 04 00 00    	jg     6b88 <w120+0x518>
    6727:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    672b:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    6730:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6734:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    6739:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    673e:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6743:	49 8d 46 01          	lea    0x1(%r14),%rax
    6747:	48 89 43 10          	mov    %rax,0x10(%rbx)
    674b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6752:	ff ff ff 
    6755:	4c 21 eb             	and    %r13,%rbx
    6758:	4c 09 f3             	or     %r14,%rbx
    675b:	49 89 de             	mov    %rbx,%r14
    675e:	49 c1 fe 20          	sar    $0x20,%r14
    6762:	48 85 ed             	test   %rbp,%rbp
    6765:	78 10                	js     6777 <w120+0x107>
    6767:	48 89 e8             	mov    %rbp,%rax
    676a:	48 c1 f8 20          	sar    $0x20,%rax
    676e:	4c 39 f0             	cmp    %r14,%rax
    6771:	0f 85 da 05 00 00    	jne    6d51 <w120+0x6e1>
    6777:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    677c:	66 0f 28 2d 6c 55 00 	movapd 0x556c(%rip),%xmm5        # bcf0 <msg.4+0x80>
    6783:	00 
    6784:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6789:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    678e:	4d 39 34 24          	cmp    %r14,(%r12)
    6792:	0f 84 18 05 00 00    	je     6cb0 <w120+0x640>
    6798:	4c 89 f7             	mov    %r14,%rdi
    679b:	e8 50 df ff ff       	call   46f0 <fwp_tape_of>
    67a0:	48 89 c2             	mov    %rax,%rdx
    67a3:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    67a8:	0f 85 be 05 00 00    	jne    6d6c <w120+0x6fc>
    67ae:	4d 89 34 24          	mov    %r14,(%r12)
    67b2:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    67b7:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    67bb:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    67c2:	0f 8f 98 05 00 00    	jg     6d60 <w120+0x6f0>
    67c8:	89 d8                	mov    %ebx,%eax
    67ca:	49 39 c6             	cmp    %rax,%r14
    67cd:	0f 8e 72 05 00 00    	jle    6d45 <w120+0x6d5>
    67d3:	48 85 ed             	test   %rbp,%rbp
    67d6:	78 0b                	js     67e3 <w120+0x173>
    67d8:	89 e8                	mov    %ebp,%eax
    67da:	49 39 c6             	cmp    %rax,%r14
    67dd:	0f 8e 62 05 00 00    	jle    6d45 <w120+0x6d5>
    67e3:	4c 89 f0             	mov    %r14,%rax
    67e6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    67ea:	48 8d 70 01          	lea    0x1(%rax),%rsi
    67ee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    67f5:	0f 87 65 05 00 00    	ja     6d60 <w120+0x6f0>
    67fb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    67ff:	0f 8f bb 03 00 00    	jg     6bc0 <w120+0x550>
    6805:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    6809:	48 8b 42 20          	mov    0x20(%rdx),%rax
    680d:	48 85 ed             	test   %rbp,%rbp
    6810:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    6816:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    681b:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    681f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6826:	48 0f 49 c5          	cmovns %rbp,%rax
    682a:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    682e:	66 48 0f 6e d8       	movq   %rax,%xmm3
    6833:	49 8d 46 01          	lea    0x1(%r14),%rax
    6837:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    683b:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    683f:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6843:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6847:	4d 85 ed             	test   %r13,%r13
    684a:	0f 88 4b 05 00 00    	js     6d9b <w120+0x72b>
    6850:	4c 89 ea             	mov    %r13,%rdx
    6853:	48 c1 fa 20          	sar    $0x20,%rdx
    6857:	49 3b 14 24          	cmp    (%r12),%rdx
    685b:	0f 84 5f 04 00 00    	je     6cc0 <w120+0x650>
    6861:	48 89 d7             	mov    %rdx,%rdi
    6864:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6869:	e8 82 de ff ff       	call   46f0 <fwp_tape_of>
    686e:	48 89 c5             	mov    %rax,%rbp
    6871:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6876:	0f 85 f0 04 00 00    	jne    6d6c <w120+0x6fc>
    687c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6881:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6886:	49 89 14 24          	mov    %rdx,(%r12)
    688a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    688e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6894:	0f 8f c6 04 00 00    	jg     6d60 <w120+0x6f0>
    689a:	44 89 ea             	mov    %r13d,%edx
    689d:	48 39 d0             	cmp    %rdx,%rax
    68a0:	0f 8e 9f 04 00 00    	jle    6d45 <w120+0x6d5>
    68a6:	48 89 c2             	mov    %rax,%rdx
    68a9:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    68ad:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    68b1:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    68b8:	0f 87 a2 04 00 00    	ja     6d60 <w120+0x6f0>
    68be:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    68c2:	0f 8f 20 03 00 00    	jg     6be8 <w120+0x578>
    68c8:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    68cd:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    68d1:	66 0f 28 05 17 54 00 	movapd 0x5417(%rip),%xmm0        # bcf0 <msg.4+0x80>
    68d8:	00 
    68d9:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    68dd:	66 0f 28 ee          	movapd %xmm6,%xmm5
    68e1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    68e5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    68e9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    68f0:	ff 
    68f1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    68f6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    68fa:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    68fe:	4c 89 ed             	mov    %r13,%rbp
    6901:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6908:	ff ff ff 
    690b:	48 21 d5             	and    %rdx,%rbp
    690e:	48 09 c5             	or     %rax,%rbp
    6911:	66 49 0f 7e ef       	movq   %xmm5,%r15
    6916:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    691d:	ff ff ff 
    6920:	48 21 c3             	and    %rax,%rbx
    6923:	4c 09 f3             	or     %r14,%rbx
    6926:	49 89 de             	mov    %rbx,%r14
    6929:	49 c1 fe 20          	sar    $0x20,%r14
    692d:	4d 3b 34 24          	cmp    (%r12),%r14
    6931:	0f 84 99 03 00 00    	je     6cd0 <w120+0x660>
    6937:	4c 89 f7             	mov    %r14,%rdi
    693a:	e8 b1 dd ff ff       	call   46f0 <fwp_tape_of>
    693f:	49 89 c5             	mov    %rax,%r13
    6942:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6947:	0f 85 1f 04 00 00    	jne    6d6c <w120+0x6fc>
    694d:	4d 89 34 24          	mov    %r14,(%r12)
    6951:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6956:	4d 8b 75 10          	mov    0x10(%r13),%r14
    695a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6961:	0f 8f f9 03 00 00    	jg     6d60 <w120+0x6f0>
    6967:	89 d8                	mov    %ebx,%eax
    6969:	49 39 c6             	cmp    %rax,%r14
    696c:	0f 8e d3 03 00 00    	jle    6d45 <w120+0x6d5>
    6972:	4c 89 f0             	mov    %r14,%rax
    6975:	49 2b 45 08          	sub    0x8(%r13),%rax
    6979:	48 8d 70 01          	lea    0x1(%rax),%rsi
    697d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6984:	0f 87 d6 03 00 00    	ja     6d60 <w120+0x6f0>
    698a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    698f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6993:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6997:	0f 8f 73 02 00 00    	jg     6c10 <w120+0x5a0>
    699d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    69a1:	66 0f 6e eb          	movd   %ebx,%xmm5
    69a5:	49 8b 45 20          	mov    0x20(%r13),%rax
    69a9:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    69ae:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    69b3:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    69b8:	49 8d 46 01          	lea    0x1(%r14),%rax
    69bc:	49 89 45 10          	mov    %rax,0x10(%r13)
    69c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69c7:	ff ff ff 
    69ca:	48 21 c3             	and    %rax,%rbx
    69cd:	4c 09 f3             	or     %r14,%rbx
    69d0:	49 89 dd             	mov    %rbx,%r13
    69d3:	49 c1 fd 20          	sar    $0x20,%r13
    69d7:	4d 3b 2c 24          	cmp    (%r12),%r13
    69db:	0f 84 ff 02 00 00    	je     6ce0 <w120+0x670>
    69e1:	4c 89 ef             	mov    %r13,%rdi
    69e4:	e8 07 dd ff ff       	call   46f0 <fwp_tape_of>
    69e9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    69ee:	0f 85 78 03 00 00    	jne    6d6c <w120+0x6fc>
    69f4:	4d 89 2c 24          	mov    %r13,(%r12)
    69f8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    69fd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6a01:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6a08:	0f 8f 52 03 00 00    	jg     6d60 <w120+0x6f0>
    6a0e:	89 da                	mov    %ebx,%edx
    6a10:	49 39 d5             	cmp    %rdx,%r13
    6a13:	0f 8e 2c 03 00 00    	jle    6d45 <w120+0x6d5>
    6a19:	4d 89 ee             	mov    %r13,%r14
    6a1c:	4c 2b 70 08          	sub    0x8(%rax),%r14
    6a20:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6a24:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6a2b:	0f 87 2f 03 00 00    	ja     6d60 <w120+0x6f0>
    6a31:	f2 0f 10 15 c7 52 00 	movsd  0x52c7(%rip),%xmm2        # bd00 <msg.4+0x90>
    6a38:	00 
    6a39:	66 49 0f 6e cf       	movq   %r15,%xmm1
    6a3e:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6a44:	f2 0f 59 0d c4 52 00 	mulsd  0x52c4(%rip),%xmm1        # bd10 <msg.4+0xa0>
    6a4b:	00 
    6a4c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6a50:	0f 8f da 01 00 00    	jg     6c30 <w120+0x5c0>
    6a56:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a5a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    6a5e:	f3 0f 7e 05 aa 52 00 	movq   0x52aa(%rip),%xmm0        # bd10 <msg.4+0xa0>
    6a65:	00 
    6a66:	48 89 ef             	mov    %rbp,%rdi
    6a69:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    6a6c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6a71:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6a75:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    6a7c:	ff 
    6a7d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6a81:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6a85:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6a89:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a90:	ff ff ff 
    6a93:	48 21 c3             	and    %rax,%rbx
    6a96:	4c 09 eb             	or     %r13,%rbx
    6a99:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6a9d:	0f 84 c8 00 00 00    	je     6b6b <w120+0x4fb>
    6aa3:	49 89 ed             	mov    %rbp,%r13
    6aa6:	49 c1 fd 20          	sar    $0x20,%r13
    6aaa:	4d 39 2c 24          	cmp    %r13,(%r12)
    6aae:	0f 84 3c 02 00 00    	je     6cf0 <w120+0x680>
    6ab4:	4c 89 ef             	mov    %r13,%rdi
    6ab7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6abd:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6ac2:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    6ac8:	e8 23 dc ff ff       	call   46f0 <fwp_tape_of>
    6acd:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6ad2:	0f 85 94 02 00 00    	jne    6d6c <w120+0x6fc>
    6ad8:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6ade:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6ae3:	4d 89 2c 24          	mov    %r13,(%r12)
    6ae7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6aec:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    6af2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    6af6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6afd:	0f 8f 5d 02 00 00    	jg     6d60 <w120+0x6f0>
    6b03:	89 e9                	mov    %ebp,%ecx
    6b05:	4c 39 f1             	cmp    %r14,%rcx
    6b08:	0f 8d 37 02 00 00    	jge    6d45 <w120+0x6d5>
    6b0e:	4d 89 f5             	mov    %r14,%r13
    6b11:	4c 2b 68 08          	sub    0x8(%rax),%r13
    6b15:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6b19:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6b20:	0f 87 3a 02 00 00    	ja     6d60 <w120+0x6f0>
    6b26:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    6b2a:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6b2e:	0f 8f 2c 01 00 00    	jg     6c60 <w120+0x5f0>
    6b34:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6b38:	66 0f 6e dd          	movd   %ebp,%xmm3
    6b3c:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6b41:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6b48:	ff ff ff 
    6b4b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6b50:	48 21 d5             	and    %rdx,%rbp
    6b53:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6b58:	48 89 ef             	mov    %rbp,%rdi
    6b5b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6b60:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6b64:	4c 09 f7             	or     %r14,%rdi
    6b67:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6b6b:	4c 89 e2             	mov    %r12,%rdx
    6b6e:	48 89 de             	mov    %rbx,%rsi
    6b71:	e8 ea f8 ff ff       	call   6460 <w123>
    6b76:	48 83 c4 48          	add    $0x48,%rsp
    6b7a:	5b                   	pop    %rbx
    6b7b:	5d                   	pop    %rbp
    6b7c:	41 5c                	pop    %r12
    6b7e:	41 5d                	pop    %r13
    6b80:	41 5e                	pop    %r14
    6b82:	41 5f                	pop    %r15
    6b84:	c3                   	ret
    6b85:	0f 1f 00             	nopl   (%rax)
    6b88:	48 89 df             	mov    %rbx,%rdi
    6b8b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6b90:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6b96:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6b9b:	e8 f0 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6ba0:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    6ba6:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    6bac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6bb1:	e9 71 fb ff ff       	jmp    6727 <w120+0xb7>
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	48 89 d7             	mov    %rdx,%rdi
    6bc3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6bc8:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6bcd:	e8 be f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6bd2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6bd7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6bdc:	e9 24 fc ff ff       	jmp    6805 <w120+0x195>
    6be1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6be8:	48 89 ef             	mov    %rbp,%rdi
    6beb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6bf0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6bf5:	e8 96 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6bfa:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6bff:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6c04:	e9 bf fc ff ff       	jmp    68c8 <w120+0x258>
    6c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c10:	4c 89 ef             	mov    %r13,%rdi
    6c13:	48 89 04 24          	mov    %rax,(%rsp)
    6c17:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c1c:	e8 6f f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c21:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    6c27:	48 8b 04 24          	mov    (%rsp),%rax
    6c2b:	e9 6d fd ff ff       	jmp    699d <w120+0x32d>
    6c30:	48 89 c7             	mov    %rax,%rdi
    6c33:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6c38:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6c3e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6c43:	e8 48 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c48:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6c4e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6c53:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6c58:	e9 f9 fd ff ff       	jmp    6a56 <w120+0x3e6>
    6c5d:	0f 1f 00             	nopl   (%rax)
    6c60:	48 89 c7             	mov    %rax,%rdi
    6c63:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6c68:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6c6e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6c74:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6c78:	e8 13 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c7d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6c83:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6c89:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    6c8e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6c93:	e9 9c fe ff ff       	jmp    6b34 <w120+0x4c4>
    6c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c9f:	00 
    6ca0:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    6ca4:	e9 35 fa ff ff       	jmp    66de <w120+0x6e>
    6ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cb0:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    6cb5:	e9 fd fa ff ff       	jmp    67b7 <w120+0x147>
    6cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cc0:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    6cc5:	e9 c0 fb ff ff       	jmp    688a <w120+0x21a>
    6cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cd0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6cd5:	e9 7c fc ff ff       	jmp    6956 <w120+0x2e6>
    6cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6ce5:	e9 13 fd ff ff       	jmp    69fd <w120+0x38d>
    6cea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cf0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6cf5:	e9 f8 fd ff ff       	jmp    6af2 <w120+0x482>
    6cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d00:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    6d05:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6d0a:	48 85 f6             	test   %rsi,%rsi
    6d0d:	79 69                	jns    6d78 <w120+0x708>
    6d0f:	f2 0f 10 05 e9 4f 00 	movsd  0x4fe9(%rip),%xmm0        # bd00 <msg.4+0x90>
    6d16:	00 
    6d17:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6d1c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6d23:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6d2a:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    6d30:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6d34:	f2 0f 59 0d d4 4f 00 	mulsd  0x4fd4(%rip),%xmm1        # bd10 <msg.4+0xa0>
    6d3b:	00 
    6d3c:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6d40:	e9 26 fe ff ff       	jmp    6b6b <w120+0x4fb>
    6d45:	48 8d 3d 78 44 00 00 	lea    0x4478(%rip),%rdi        # b1c4 <_IO_stdin_used+0x1c4>
    6d4c:	e8 bf d6 ff ff       	call   4410 <fwp_trap>
    6d51:	48 8d 3d 78 4c 00 00 	lea    0x4c78(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    6d58:	e8 b3 d6 ff ff       	call   4410 <fwp_trap>
    6d5d:	0f 1f 00             	nopl   (%rax)
    6d60:	48 8d 3d 42 44 00 00 	lea    0x4442(%rip),%rdi        # b1a9 <_IO_stdin_used+0x1a9>
    6d67:	e8 a4 d6 ff ff       	call   4410 <fwp_trap>
    6d6c:	48 8d 3d a5 4c 00 00 	lea    0x4ca5(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    6d73:	e8 98 d6 ff ff       	call   4410 <fwp_trap>
    6d78:	49 89 f6             	mov    %rsi,%r14
    6d7b:	f3 0f 7e 3d 7d 4f 00 	movq   0x4f7d(%rip),%xmm7        # bd00 <msg.4+0x90>
    6d82:	00 
    6d83:	48 89 f3             	mov    %rsi,%rbx
    6d86:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    6d8b:	49 c1 fe 20          	sar    $0x20,%r14
    6d8f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6d96:	e9 f3 f9 ff ff       	jmp    678e <w120+0x11e>
    6d9b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    6da0:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    6da5:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6dac:	66 49 0f 7e ff       	movq   %xmm7,%r15
    6db1:	e9 60 fb ff ff       	jmp    6916 <w120+0x2a6>
    6db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dbd:	00 00 00 

0000000000006dc0 <w176.constprop.0>:
    6dc0:	41 55                	push   %r13
    6dc2:	41 54                	push   %r12
    6dc4:	55                   	push   %rbp
    6dc5:	53                   	push   %rbx
    6dc6:	48 83 ec 28          	sub    $0x28,%rsp
    6dca:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    6dd1:	00 00 
    6dd3:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    6dd8:	48 8b 2f             	mov    (%rdi),%rbp
    6ddb:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    6de2:	ff 
    6de3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6dea:	00 00 
    6dec:	48 85 ed             	test   %rbp,%rbp
    6def:	74 5f                	je     6e50 <w176.constprop.0+0x90>
    6df1:	49 89 fd             	mov    %rdi,%r13
    6df4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6df8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6dff:	31 db                	xor    %ebx,%ebx
    6e01:	0f 1f 40 00          	nopl   0x0(%rax)
    6e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e0c:	00 00 00 00 
    6e10:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    6e15:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    6e1c:	48 89 e2             	mov    %rsp,%rdx
    6e1f:	48 83 c3 02          	add    $0x2,%rbx
    6e23:	e8 38 f6 ff ff       	call   6460 <w123>
    6e28:	48 89 c7             	mov    %rax,%rdi
    6e2b:	48 39 eb             	cmp    %rbp,%rbx
    6e2e:	72 e0                	jb     6e10 <w176.constprop.0+0x50>
    6e30:	48 89 f8             	mov    %rdi,%rax
    6e33:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6e38:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6e3f:	00 00 
    6e41:	75 1a                	jne    6e5d <w176.constprop.0+0x9d>
    6e43:	48 83 c4 28          	add    $0x28,%rsp
    6e47:	5b                   	pop    %rbx
    6e48:	5d                   	pop    %rbp
    6e49:	41 5c                	pop    %r12
    6e4b:	41 5d                	pop    %r13
    6e4d:	c3                   	ret
    6e4e:	66 90                	xchg   %ax,%ax
    6e50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6e57:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e5b:	eb d3                	jmp    6e30 <w176.constprop.0+0x70>
    6e5d:	e8 de c5 ff ff       	call   3440 <__stack_chk_fail@plt>
    6e62:	0f 1f 00             	nopl   (%rax)
    6e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e6c:	00 00 00 00 

0000000000006e70 <fwp_rc_share>:
    6e70:	48 8b 05 61 1d 06 00 	mov    0x61d61(%rip),%rax        # 68bd8 <fwp_heap+0x13d8>
    6e77:	48 2b 3d 32 1d 06 00 	sub    0x61d32(%rip),%rdi        # 68bb0 <fwp_heap+0x13b0>
    6e7e:	48 c1 e0 10          	shl    $0x10,%rax
    6e82:	48 39 c7             	cmp    %rax,%rdi
    6e85:	73 4a                	jae    6ed1 <fwp_rc_share+0x61>
    6e87:	48 89 f8             	mov    %rdi,%rax
    6e8a:	48 c1 e8 10          	shr    $0x10,%rax
    6e8e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6e92:	48 8b 05 5f 1d 06 00 	mov    0x61d5f(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    6e99:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6e9d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6ea1:	48 85 d2             	test   %rdx,%rdx
    6ea4:	74 2b                	je     6ed1 <fwp_rc_share+0x61>
    6ea6:	0f b6 08             	movzbl (%rax),%ecx
    6ea9:	80 f9 02             	cmp    $0x2,%cl
    6eac:	74 2a                	je     6ed8 <fwp_rc_share+0x68>
    6eae:	80 f9 01             	cmp    $0x1,%cl
    6eb1:	75 1e                	jne    6ed1 <fwp_rc_share+0x61>
    6eb3:	8b 48 18             	mov    0x18(%rax),%ecx
    6eb6:	0f b7 ff             	movzwl %di,%edi
    6eb9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6ebc:	48 0f af f9          	imul   %rcx,%rdi
    6ec0:	48 c1 ef 20          	shr    $0x20,%rdi
    6ec4:	48 39 c7             	cmp    %rax,%rdi
    6ec7:	73 08                	jae    6ed1 <fwp_rc_share+0x61>
    6ec9:	48 01 fa             	add    %rdi,%rdx
    6ecc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6ecf:	75 0d                	jne    6ede <fwp_rc_share+0x6e>
    6ed1:	c3                   	ret
    6ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed8:	66 85 ff             	test   %di,%di
    6edb:	74 ef                	je     6ecc <fwp_rc_share+0x5c>
    6edd:	c3                   	ret
    6ede:	50                   	push   %rax
    6edf:	48 8d 3d 62 4b 00 00 	lea    0x4b62(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    6ee6:	e8 25 d5 ff ff       	call   4410 <fwp_trap>
    6eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ef0 <fwp_rc_free_obj>:
    6ef0:	48 8b 15 e1 1c 06 00 	mov    0x61ce1(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    6ef7:	48 89 f8             	mov    %rdi,%rax
    6efa:	48 2b 05 af 1c 06 00 	sub    0x61caf(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    6f01:	48 c1 e2 10          	shl    $0x10,%rdx
    6f05:	48 39 d0             	cmp    %rdx,%rax
    6f08:	73 5b                	jae    6f65 <fwp_rc_free_obj+0x75>
    6f0a:	48 89 c2             	mov    %rax,%rdx
    6f0d:	48 c1 ea 10          	shr    $0x10,%rdx
    6f11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f15:	48 8b 15 dc 1c 06 00 	mov    0x61cdc(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    6f1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f24:	48 85 c9             	test   %rcx,%rcx
    6f27:	74 3c                	je     6f65 <fwp_rc_free_obj+0x75>
    6f29:	0f b6 32             	movzbl (%rdx),%esi
    6f2c:	40 80 fe 02          	cmp    $0x2,%sil
    6f30:	74 2e                	je     6f60 <fwp_rc_free_obj+0x70>
    6f32:	40 80 fe 01          	cmp    $0x1,%sil
    6f36:	75 2d                	jne    6f65 <fwp_rc_free_obj+0x75>
    6f38:	8b 72 18             	mov    0x18(%rdx),%esi
    6f3b:	0f b7 c0             	movzwl %ax,%eax
    6f3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6f41:	48 0f af c6          	imul   %rsi,%rax
    6f45:	48 c1 e8 20          	shr    $0x20,%rax
    6f49:	48 39 d0             	cmp    %rdx,%rax
    6f4c:	73 17                	jae    6f65 <fwp_rc_free_obj+0x75>
    6f4e:	48 01 c1             	add    %rax,%rcx
    6f51:	80 39 01             	cmpb   $0x1,(%rcx)
    6f54:	75 0f                	jne    6f65 <fwp_rc_free_obj+0x75>
    6f56:	e9 55 ea ff ff       	jmp    59b0 <fwp_mem_free>
    6f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f60:	66 85 c0             	test   %ax,%ax
    6f63:	74 ec                	je     6f51 <fwp_rc_free_obj+0x61>
    6f65:	c3                   	ret
    6f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f6d:	00 00 00 

0000000000006f70 <fwp_rc_dup>:
    6f70:	f3 0f 1e fa          	endbr64
    6f74:	48 8b 05 5d 1c 06 00 	mov    0x61c5d(%rip),%rax        # 68bd8 <fwp_heap+0x13d8>
    6f7b:	48 2b 3d 2e 1c 06 00 	sub    0x61c2e(%rip),%rdi        # 68bb0 <fwp_heap+0x13b0>
    6f82:	48 c1 e0 10          	shl    $0x10,%rax
    6f86:	48 39 c7             	cmp    %rax,%rdi
    6f89:	73 60                	jae    6feb <fwp_rc_dup+0x7b>
    6f8b:	48 89 f8             	mov    %rdi,%rax
    6f8e:	48 c1 e8 10          	shr    $0x10,%rax
    6f92:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6f96:	48 8b 05 5b 1c 06 00 	mov    0x61c5b(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    6f9d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6fa1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6fa5:	48 85 c0             	test   %rax,%rax
    6fa8:	74 41                	je     6feb <fwp_rc_dup+0x7b>
    6faa:	0f b6 0a             	movzbl (%rdx),%ecx
    6fad:	80 f9 02             	cmp    $0x2,%cl
    6fb0:	74 3e                	je     6ff0 <fwp_rc_dup+0x80>
    6fb2:	80 f9 01             	cmp    $0x1,%cl
    6fb5:	75 34                	jne    6feb <fwp_rc_dup+0x7b>
    6fb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6fba:	0f b7 ff             	movzwl %di,%edi
    6fbd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fc0:	48 0f af f9          	imul   %rcx,%rdi
    6fc4:	48 c1 ef 20          	shr    $0x20,%rdi
    6fc8:	48 39 d7             	cmp    %rdx,%rdi
    6fcb:	73 1e                	jae    6feb <fwp_rc_dup+0x7b>
    6fcd:	48 01 f8             	add    %rdi,%rax
    6fd0:	0f b6 10             	movzbl (%rax),%edx
    6fd3:	84 d2                	test   %dl,%dl
    6fd5:	74 14                	je     6feb <fwp_rc_dup+0x7b>
    6fd7:	8b 0d eb 24 06 00    	mov    0x624eb(%rip),%ecx        # 694c8 <iteration_active>
    6fdd:	85 c9                	test   %ecx,%ecx
    6fdf:	75 1f                	jne    7000 <fwp_rc_dup+0x90>
    6fe1:	80 fa fd             	cmp    $0xfd,%dl
    6fe4:	77 2a                	ja     7010 <fwp_rc_dup+0xa0>
    6fe6:	83 c2 01             	add    $0x1,%edx
    6fe9:	88 10                	mov    %dl,(%rax)
    6feb:	c3                   	ret
    6fec:	0f 1f 40 00          	nopl   0x0(%rax)
    6ff0:	66 85 ff             	test   %di,%di
    6ff3:	74 db                	je     6fd0 <fwp_rc_dup+0x60>
    6ff5:	c3                   	ret
    6ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ffd:	00 00 00 
    7000:	48 83 05 a8 24 06 00 	addq   $0x1,0x624a8(%rip)        # 694b0 <iteration_retains>
    7007:	01 
    7008:	eb d7                	jmp    6fe1 <fwp_rc_dup+0x71>
    700a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7010:	48 89 c7             	mov    %rax,%rdi
    7013:	e9 38 e6 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    7018:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    701f:	00 

0000000000007020 <fwp_owned_entry173>:
    7020:	f3 0f 1e fa          	endbr64
    7024:	48 83 ec 38          	sub    $0x38,%rsp
    7028:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    702d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7034:	00 00 
    7036:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    703b:	31 c0                	xor    %eax,%eax
    703d:	48 8b 07             	mov    (%rdi),%rax
    7040:	48 03 47 10          	add    0x10(%rdi),%rax
    7044:	0f 80 c2 00 00 00    	jo     710c <fwp_owned_entry173+0xec>
    704a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    704f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7054:	31 ff                	xor    %edi,%edi
    7056:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    705a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    705f:	e8 3c f0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    7064:	48 8b 15 6d 1b 06 00 	mov    0x61b6d(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    706b:	48 89 c6             	mov    %rax,%rsi
    706e:	48 2b 05 3b 1b 06 00 	sub    0x61b3b(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7075:	48 c1 e2 10          	shl    $0x10,%rdx
    7079:	48 39 d0             	cmp    %rdx,%rax
    707c:	73 4f                	jae    70cd <fwp_owned_entry173+0xad>
    707e:	48 89 c2             	mov    %rax,%rdx
    7081:	48 c1 ea 10          	shr    $0x10,%rdx
    7085:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7089:	48 8b 15 68 1b 06 00 	mov    0x61b68(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    7090:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7094:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7098:	48 85 d2             	test   %rdx,%rdx
    709b:	74 30                	je     70cd <fwp_owned_entry173+0xad>
    709d:	0f b6 39             	movzbl (%rcx),%edi
    70a0:	40 80 ff 02          	cmp    $0x2,%dil
    70a4:	74 42                	je     70e8 <fwp_owned_entry173+0xc8>
    70a6:	40 80 ff 01          	cmp    $0x1,%dil
    70aa:	75 21                	jne    70cd <fwp_owned_entry173+0xad>
    70ac:	8b 79 18             	mov    0x18(%rcx),%edi
    70af:	0f b7 c0             	movzwl %ax,%eax
    70b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70b5:	48 0f af c7          	imul   %rdi,%rax
    70b9:	48 c1 e8 20          	shr    $0x20,%rax
    70bd:	48 39 c8             	cmp    %rcx,%rax
    70c0:	73 0b                	jae    70cd <fwp_owned_entry173+0xad>
    70c2:	48 01 c2             	add    %rax,%rdx
    70c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    70c8:	74 26                	je     70f0 <fwp_owned_entry173+0xd0>
    70ca:	c6 02 01             	movb   $0x1,(%rdx)
    70cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    70d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    70d9:	00 00 
    70db:	75 34                	jne    7111 <fwp_owned_entry173+0xf1>
    70dd:	48 89 f0             	mov    %rsi,%rax
    70e0:	48 83 c4 38          	add    $0x38,%rsp
    70e4:	c3                   	ret
    70e5:	0f 1f 00             	nopl   (%rax)
    70e8:	66 85 c0             	test   %ax,%ax
    70eb:	75 e0                	jne    70cd <fwp_owned_entry173+0xad>
    70ed:	eb d6                	jmp    70c5 <fwp_owned_entry173+0xa5>
    70ef:	90                   	nop
    70f0:	48 89 d7             	mov    %rdx,%rdi
    70f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    70f8:	48 89 14 24          	mov    %rdx,(%rsp)
    70fc:	e8 6f e6 ff ff       	call   5770 <fwp_rc_forget_slot>
    7101:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7106:	48 8b 14 24          	mov    (%rsp),%rdx
    710a:	eb be                	jmp    70ca <fwp_owned_entry173+0xaa>
    710c:	e8 af c5 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    7111:	e8 2a c3 ff ff       	call   3440 <__stack_chk_fail@plt>
    7116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    711d:	00 00 00 

0000000000007120 <e173>:
    7120:	f3 0f 1e fa          	endbr64
    7124:	53                   	push   %rbx
    7125:	48 83 ec 30          	sub    $0x30,%rsp
    7129:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    712e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7135:	00 00 
    7137:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    713c:	31 c0                	xor    %eax,%eax
    713e:	48 8b 07             	mov    (%rdi),%rax
    7141:	48 03 47 10          	add    0x10(%rdi),%rax
    7145:	0f 80 c9 00 00 00    	jo     7214 <e173+0xf4>
    714b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7150:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7155:	31 ff                	xor    %edi,%edi
    7157:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    715b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7160:	e8 3b ef ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    7165:	48 8b 15 6c 1a 06 00 	mov    0x61a6c(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    716c:	48 89 c3             	mov    %rax,%rbx
    716f:	48 2b 05 3a 1a 06 00 	sub    0x61a3a(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7176:	48 c1 e2 10          	shl    $0x10,%rdx
    717a:	48 39 d0             	cmp    %rdx,%rax
    717d:	73 4f                	jae    71ce <e173+0xae>
    717f:	48 89 c2             	mov    %rax,%rdx
    7182:	48 c1 ea 10          	shr    $0x10,%rdx
    7186:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    718a:	48 8b 15 67 1a 06 00 	mov    0x61a67(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    7191:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7195:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7199:	48 85 d2             	test   %rdx,%rdx
    719c:	74 30                	je     71ce <e173+0xae>
    719e:	0f b6 31             	movzbl (%rcx),%esi
    71a1:	40 80 fe 02          	cmp    $0x2,%sil
    71a5:	74 49                	je     71f0 <e173+0xd0>
    71a7:	40 80 fe 01          	cmp    $0x1,%sil
    71ab:	75 21                	jne    71ce <e173+0xae>
    71ad:	8b 71 18             	mov    0x18(%rcx),%esi
    71b0:	0f b7 c0             	movzwl %ax,%eax
    71b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    71b6:	48 0f af c6          	imul   %rsi,%rax
    71ba:	48 c1 e8 20          	shr    $0x20,%rax
    71be:	48 39 c8             	cmp    %rcx,%rax
    71c1:	73 0b                	jae    71ce <e173+0xae>
    71c3:	48 01 c2             	add    %rax,%rdx
    71c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    71c9:	74 35                	je     7200 <e173+0xe0>
    71cb:	c6 02 01             	movb   $0x1,(%rdx)
    71ce:	48 89 df             	mov    %rbx,%rdi
    71d1:	e8 9a fc ff ff       	call   6e70 <fwp_rc_share>
    71d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    71db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71e2:	00 00 
    71e4:	75 33                	jne    7219 <e173+0xf9>
    71e6:	48 83 c4 30          	add    $0x30,%rsp
    71ea:	48 89 d8             	mov    %rbx,%rax
    71ed:	5b                   	pop    %rbx
    71ee:	c3                   	ret
    71ef:	90                   	nop
    71f0:	66 85 c0             	test   %ax,%ax
    71f3:	75 d9                	jne    71ce <e173+0xae>
    71f5:	eb cf                	jmp    71c6 <e173+0xa6>
    71f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71fe:	00 00 
    7200:	48 89 d7             	mov    %rdx,%rdi
    7203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7208:	e8 63 e5 ff ff       	call   5770 <fwp_rc_forget_slot>
    720d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7212:	eb b7                	jmp    71cb <e173+0xab>
    7214:	e8 a7 c4 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    7219:	e8 22 c2 ff ff       	call   3440 <__stack_chk_fail@plt>
    721e:	66 90                	xchg   %ax,%ax

0000000000007220 <fwp_closure_drop>:
    7220:	48 8b 15 b1 19 06 00 	mov    0x619b1(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    7227:	48 89 f8             	mov    %rdi,%rax
    722a:	48 2b 05 7f 19 06 00 	sub    0x6197f(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7231:	48 c1 e2 10          	shl    $0x10,%rdx
    7235:	48 39 d0             	cmp    %rdx,%rax
    7238:	73 6b                	jae    72a5 <fwp_closure_drop+0x85>
    723a:	48 89 c2             	mov    %rax,%rdx
    723d:	48 c1 ea 10          	shr    $0x10,%rdx
    7241:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7245:	48 8b 15 ac 19 06 00 	mov    0x619ac(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    724c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7250:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7254:	48 85 d2             	test   %rdx,%rdx
    7257:	74 4c                	je     72a5 <fwp_closure_drop+0x85>
    7259:	0f b6 31             	movzbl (%rcx),%esi
    725c:	40 80 fe 02          	cmp    $0x2,%sil
    7260:	74 3e                	je     72a0 <fwp_closure_drop+0x80>
    7262:	40 80 fe 01          	cmp    $0x1,%sil
    7266:	75 3d                	jne    72a5 <fwp_closure_drop+0x85>
    7268:	8b 71 18             	mov    0x18(%rcx),%esi
    726b:	0f b7 c0             	movzwl %ax,%eax
    726e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7271:	48 0f af c6          	imul   %rsi,%rax
    7275:	48 c1 e8 20          	shr    $0x20,%rax
    7279:	48 39 c8             	cmp    %rcx,%rax
    727c:	73 27                	jae    72a5 <fwp_closure_drop+0x85>
    727e:	48 01 c2             	add    %rax,%rdx
    7281:	0f b6 02             	movzbl (%rdx),%eax
    7284:	84 c0                	test   %al,%al
    7286:	74 1d                	je     72a5 <fwp_closure_drop+0x85>
    7288:	3c 01                	cmp    $0x1,%al
    728a:	74 24                	je     72b0 <fwp_closure_drop+0x90>
    728c:	3c ff                	cmp    $0xff,%al
    728e:	74 48                	je     72d8 <fwp_closure_drop+0xb8>
    7290:	83 e8 01             	sub    $0x1,%eax
    7293:	88 02                	mov    %al,(%rdx)
    7295:	c3                   	ret
    7296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    729d:	00 00 00 
    72a0:	66 85 c0             	test   %ax,%ax
    72a3:	74 dc                	je     7281 <fwp_closure_drop+0x61>
    72a5:	c3                   	ret
    72a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72ad:	00 00 00 
    72b0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    72b7:	ff ff 
    72b9:	48 85 c0             	test   %rax,%rax
    72bc:	74 12                	je     72d0 <fwp_closure_drop+0xb0>
    72be:	48 89 fe             	mov    %rdi,%rsi
    72c1:	48 89 c7             	mov    %rax,%rdi
    72c4:	e9 a7 d1 ff ff       	jmp    4470 <fwp_closure_drop_push>
    72c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72d0:	e9 4b d3 ff ff       	jmp    4620 <fwp_closure_drop.part.0>
    72d5:	0f 1f 00             	nopl   (%rax)
    72d8:	48 89 d0             	mov    %rdx,%rax
    72db:	48 8d 35 1e 05 06 00 	lea    0x6051e(%rip),%rsi        # 67800 <fwp_heap>
    72e2:	48 83 ec 18          	sub    $0x18,%rsp
    72e6:	48 c1 e8 11          	shr    $0x11,%rax
    72ea:	48 31 d0             	xor    %rdx,%rax
    72ed:	48 89 c1             	mov    %rax,%rcx
    72f0:	48 c1 e9 09          	shr    $0x9,%rcx
    72f4:	48 31 c8             	xor    %rcx,%rax
    72f7:	0f b6 c8             	movzbl %al,%ecx
    72fa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7301:	00 
    7302:	48 85 c0             	test   %rax,%rax
    7305:	75 22                	jne    7329 <fwp_closure_drop+0x109>
    7307:	eb 59                	jmp    7362 <fwp_closure_drop+0x142>
    7309:	90                   	nop
    730a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7311:	00 00 00 00 
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 
    7320:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	74 39                	je     7362 <fwp_closure_drop+0x142>
    7329:	48 89 c1             	mov    %rax,%rcx
    732c:	48 39 10             	cmp    %rdx,(%rax)
    732f:	75 ef                	jne    7320 <fwp_closure_drop+0x100>
    7331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7335:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7339:	48 89 48 08          	mov    %rcx,0x8(%rax)
    733d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7344:	74 05                	je     734b <fwp_closure_drop+0x12b>
    7346:	48 83 c4 18          	add    $0x18,%rsp
    734a:	c3                   	ret
    734b:	48 89 d7             	mov    %rdx,%rdi
    734e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7353:	e8 18 e4 ff ff       	call   5770 <fwp_rc_forget_slot>
    7358:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    735d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7360:	eb e4                	jmp    7346 <fwp_closure_drop+0x126>
    7362:	48 8d 3d 3f 46 00 00 	lea    0x463f(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7369:	e8 a2 d0 ff ff       	call   4410 <fwp_trap>
    736e:	66 90                	xchg   %ax,%ax

0000000000007370 <fwp_owned_tape_release>:
    7370:	48 85 ff             	test   %rdi,%rdi
    7373:	0f 84 f7 00 00 00    	je     7470 <fwp_owned_tape_release+0x100>
    7379:	41 54                	push   %r12
    737b:	55                   	push   %rbp
    737c:	53                   	push   %rbx
    737d:	48 8b 07             	mov    (%rdi),%rax
    7380:	48 85 c0             	test   %rax,%rax
    7383:	74 08                	je     738d <fwp_owned_tape_release+0x1d>
    7385:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7389:	48 89 50 08          	mov    %rdx,0x8(%rax)
    738d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7391:	48 85 d2             	test   %rdx,%rdx
    7394:	74 03                	je     7399 <fwp_owned_tape_release+0x29>
    7396:	48 89 02             	mov    %rax,(%rdx)
    7399:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    739d:	48 89 fb             	mov    %rdi,%rbx
    73a0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    73a4:	48 85 c0             	test   %rax,%rax
    73a7:	0f 84 89 00 00 00    	je     7436 <fwp_owned_tape_release+0xc6>
    73ad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    73b1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    73b5:	7e 47                	jle    73fe <fwp_owned_tape_release+0x8e>
    73b7:	31 ed                	xor    %ebp,%ebp
    73b9:	eb 0d                	jmp    73c8 <fwp_owned_tape_release+0x58>
    73bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    73c0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    73c4:	48 8b 40 68          	mov    0x68(%rax),%rax
    73c8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    73cc:	49 89 ec             	mov    %rbp,%r12
    73cf:	48 83 c5 01          	add    $0x1,%rbp
    73d3:	49 c1 e4 04          	shl    $0x4,%r12
    73d7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    73db:	ff d0                	call   *%rax
    73dd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    73e1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    73e6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    73ea:	ff 50 68             	call   *0x68(%rax)
    73ed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    73f1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    73f5:	48 39 e8             	cmp    %rbp,%rax
    73f8:	7f c6                	jg     73c0 <fwp_owned_tape_release+0x50>
    73fa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    73fe:	31 ed                	xor    %ebp,%ebp
    7400:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7405:	7e 28                	jle    742f <fwp_owned_tape_release+0xbf>
    7407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    740e:	00 00 
    7410:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7414:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7418:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    741c:	74 07                	je     7425 <fwp_owned_tape_release+0xb5>
    741e:	ff 52 68             	call   *0x68(%rdx)
    7421:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7425:	48 83 c5 01          	add    $0x1,%rbp
    7429:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    742d:	7f e1                	jg     7410 <fwp_owned_tape_release+0xa0>
    742f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7433:	ff 52 68             	call   *0x68(%rdx)
    7436:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    743a:	e8 e1 fd ff ff       	call   7220 <fwp_closure_drop>
    743f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7443:	e8 d8 fd ff ff       	call   7220 <fwp_closure_drop>
    7448:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    744c:	e8 cf fd ff ff       	call   7220 <fwp_closure_drop>
    7451:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7455:	e8 56 e5 ff ff       	call   59b0 <fwp_mem_free>
    745a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    745e:	e8 4d e5 ff ff       	call   59b0 <fwp_mem_free>
    7463:	48 89 df             	mov    %rbx,%rdi
    7466:	5b                   	pop    %rbx
    7467:	5d                   	pop    %rbp
    7468:	41 5c                	pop    %r12
    746a:	e9 41 e5 ff ff       	jmp    59b0 <fwp_mem_free>
    746f:	90                   	nop
    7470:	c3                   	ret
    7471:	0f 1f 40 00          	nopl   0x0(%rax)
    7475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    747c:	00 00 00 00 

0000000000007480 <fwp_tape_finish>:
    7480:	f3 0f 1e fa          	endbr64
    7484:	41 55                	push   %r13
    7486:	41 54                	push   %r12
    7488:	55                   	push   %rbp
    7489:	53                   	push   %rbx
    748a:	48 83 ec 38          	sub    $0x38,%rsp
    748e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7495:	00 00 
    7497:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    749c:	48 8d 3d fd 7b 01 00 	lea    0x17bfd(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    74a3:	e8 58 dc ff ff       	call   5100 <fwp_tape_buffers_dispose>
    74a8:	48 83 3d 28 7c 01 00 	cmpq   $0x0,0x17c28(%rip)        # 1f0d8 <fwp_ntapes>
    74af:	00 
    74b0:	48 c7 05 cd 7b 01 00 	movq   $0x0,0x17bcd(%rip)        # 1f088 <fwp_tape_cached_bytes>
    74b7:	00 00 00 00 
    74bb:	7e 6f                	jle    752c <fwp_tape_finish+0xac>
    74bd:	45 31 e4             	xor    %r12d,%r12d
    74c0:	31 ed                	xor    %ebp,%ebp
    74c2:	0f 1f 00             	nopl   (%rax)
    74c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74cc:	00 00 00 00 
    74d0:	48 8b 1d 09 7c 01 00 	mov    0x17c09(%rip),%rbx        # 1f0e0 <fwp_tapes>
    74d7:	48 83 c5 01          	add    $0x1,%rbp
    74db:	4c 01 e3             	add    %r12,%rbx
    74de:	49 83 c4 58          	add    $0x58,%r12
    74e2:	48 89 df             	mov    %rbx,%rdi
    74e5:	e8 66 c7 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    74ea:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    74ef:	48 8b 43 30          	mov    0x30(%rbx),%rax
    74f3:	48 89 e7             	mov    %rsp,%rdi
    74f6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    74fb:	0f 29 04 24          	movaps %xmm0,(%rsp)
    74ff:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    7504:	0f 16 43 38          	movhps 0x38(%rbx),%xmm0
    7508:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
    750d:	e8 ee db ff ff       	call   5100 <fwp_tape_buffers_dispose>
    7512:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    7516:	e8 55 fe ff ff       	call   7370 <fwp_owned_tape_release>
    751b:	48 39 2d b6 7b 01 00 	cmp    %rbp,0x17bb6(%rip)        # 1f0d8 <fwp_ntapes>
    7522:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    7529:	00 
    752a:	7f a4                	jg     74d0 <fwp_tape_finish+0x50>
    752c:	48 8b 3d ad 7b 01 00 	mov    0x17bad(%rip),%rdi        # 1f0e0 <fwp_tapes>
    7533:	48 85 ff             	test   %rdi,%rdi
    7536:	74 05                	je     753d <fwp_tape_finish+0xbd>
    7538:	e8 53 db ff ff       	call   5090 <ad_raw_free.part.0>
    753d:	48 c7 05 98 7b 01 00 	movq   $0x0,0x17b98(%rip)        # 1f0e0 <fwp_tapes>
    7544:	00 00 00 00 
    7548:	48 c7 05 7d 7b 01 00 	movq   $0x0,0x17b7d(%rip)        # 1f0d0 <fwp_tapes_cap>
    754f:	00 00 00 00 
    7553:	48 c7 05 7a 7b 01 00 	movq   $0x0,0x17b7a(%rip)        # 1f0d8 <fwp_ntapes>
    755a:	00 00 00 00 
    755e:	48 c7 05 5f 7b 01 00 	movq   $0x0,0x17b5f(%rip)        # 1f0c8 <fwp_tape_next_slot>
    7565:	00 00 00 00 
    7569:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    756e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7575:	00 00 
    7577:	75 0b                	jne    7584 <fwp_tape_finish+0x104>
    7579:	48 83 c4 38          	add    $0x38,%rsp
    757d:	5b                   	pop    %rbx
    757e:	5d                   	pop    %rbp
    757f:	41 5c                	pop    %r12
    7581:	41 5d                	pop    %r13
    7583:	c3                   	ret
    7584:	e8 b7 be ff ff       	call   3440 <__stack_chk_fail@plt>
    7589:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007590 <fwp_tape_scope_release>:
    7590:	f3 0f 1e fa          	endbr64
    7594:	41 55                	push   %r13
    7596:	41 54                	push   %r12
    7598:	55                   	push   %rbp
    7599:	53                   	push   %rbx
    759a:	48 83 ec 38          	sub    $0x38,%rsp
    759e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    75a5:	00 00 
    75a7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    75ac:	48 63 07             	movslq (%rdi),%rax
    75af:	85 c0                	test   %eax,%eax
    75b1:	0f 88 da 00 00 00    	js     7691 <fwp_tape_scope_release+0x101>
    75b7:	49 bc a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%r12
    75be:	a2 8b 2e 
    75c1:	48 89 fb             	mov    %rdi,%rbx
    75c4:	48 89 e5             	mov    %rsp,%rbp
    75c7:	eb 1f                	jmp    75e8 <fwp_tape_scope_release+0x58>
    75c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75d0:	e8 2b db ff ff       	call   5100 <fwp_tape_buffers_dispose>
    75d5:	4c 89 ef             	mov    %r13,%rdi
    75d8:	e8 93 fd ff ff       	call   7370 <fwp_owned_tape_release>
    75dd:	48 63 03             	movslq (%rbx),%rax
    75e0:	85 c0                	test   %eax,%eax
    75e2:	0f 88 a9 00 00 00    	js     7691 <fwp_tape_scope_release+0x101>
    75e8:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    75ec:	48 8b 35 ed 7a 01 00 	mov    0x17aed(%rip),%rsi        # 1f0e0 <fwp_tapes>
    75f3:	4c 01 c6             	add    %r8,%rsi
    75f6:	48 89 f7             	mov    %rsi,%rdi
    75f9:	e8 52 c6 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    75fe:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    7603:	48 8b 46 30          	mov    0x30(%rsi),%rax
    7607:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    760e:	4c 8b 6e 50          	mov    0x50(%rsi),%r13
    7612:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    7619:	00 
    761a:	0f 29 04 24          	movaps %xmm0,(%rsp)
    761e:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7623:	0f 16 46 38          	movhps 0x38(%rsi),%xmm0
    7627:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
    762c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7630:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    7635:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    763c:	00 
    763d:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    7644:	00 
    7645:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    764c:	00 
    764d:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    7651:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7655:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    765b:	77 18                	ja     7675 <fwp_tape_scope_release+0xe5>
    765d:	49 c1 f8 03          	sar    $0x3,%r8
    7661:	4d 0f af c4          	imul   %r12,%r8
    7665:	4c 3b 05 5c 7a 01 00 	cmp    0x17a5c(%rip),%r8        # 1f0c8 <fwp_tape_next_slot>
    766c:	7d 07                	jge    7675 <fwp_tape_scope_release+0xe5>
    766e:	4c 89 05 53 7a 01 00 	mov    %r8,0x17a53(%rip)        # 1f0c8 <fwp_tape_next_slot>
    7675:	48 89 ef             	mov    %rbp,%rdi
    7678:	4d 85 ed             	test   %r13,%r13
    767b:	0f 85 4f ff ff ff    	jne    75d0 <fwp_tape_scope_release+0x40>
    7681:	e8 9a db ff ff       	call   5220 <fwp_tape_buffers_release>
    7686:	48 63 03             	movslq (%rbx),%rax
    7689:	85 c0                	test   %eax,%eax
    768b:	0f 89 57 ff ff ff    	jns    75e8 <fwp_tape_scope_release+0x58>
    7691:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7696:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    769d:	00 00 
    769f:	75 0b                	jne    76ac <fwp_tape_scope_release+0x11c>
    76a1:	48 83 c4 38          	add    $0x38,%rsp
    76a5:	5b                   	pop    %rbx
    76a6:	5d                   	pop    %rbp
    76a7:	41 5c                	pop    %r12
    76a9:	41 5d                	pop    %r13
    76ab:	c3                   	ret
    76ac:	e8 8f bd ff ff       	call   3440 <__stack_chk_fail@plt>
    76b1:	0f 1f 40 00          	nopl   0x0(%rax)
    76b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76bc:	00 00 00 00 

00000000000076c0 <fwp_drop4>:
    76c0:	48 8b 0d 11 15 06 00 	mov    0x61511(%rip),%rcx        # 68bd8 <fwp_heap+0x13d8>
    76c7:	48 89 f8             	mov    %rdi,%rax
    76ca:	48 2b 05 df 14 06 00 	sub    0x614df(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    76d1:	48 c1 e1 10          	shl    $0x10,%rcx
    76d5:	48 39 c8             	cmp    %rcx,%rax
    76d8:	0f 83 42 01 00 00    	jae    7820 <fwp_drop4+0x160>
    76de:	48 83 ec 18          	sub    $0x18,%rsp
    76e2:	48 89 fa             	mov    %rdi,%rdx
    76e5:	4c 8d 05 14 01 06 00 	lea    0x60114(%rip),%r8        # 67800 <fwp_heap>
    76ec:	48 89 c1             	mov    %rax,%rcx
    76ef:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    76f6:	48 c1 e9 10          	shr    $0x10,%rcx
    76fa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    76fe:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7702:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7706:	48 85 c9             	test   %rcx,%rcx
    7709:	74 40                	je     774b <fwp_drop4+0x8b>
    770b:	0f b6 3e             	movzbl (%rsi),%edi
    770e:	40 80 ff 02          	cmp    $0x2,%dil
    7712:	74 3c                	je     7750 <fwp_drop4+0x90>
    7714:	40 80 ff 01          	cmp    $0x1,%dil
    7718:	75 31                	jne    774b <fwp_drop4+0x8b>
    771a:	8b 7e 18             	mov    0x18(%rsi),%edi
    771d:	0f b7 c0             	movzwl %ax,%eax
    7720:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7723:	48 0f af c7          	imul   %rdi,%rax
    7727:	48 c1 e8 20          	shr    $0x20,%rax
    772b:	48 39 f0             	cmp    %rsi,%rax
    772e:	73 1b                	jae    774b <fwp_drop4+0x8b>
    7730:	48 01 c1             	add    %rax,%rcx
    7733:	0f b6 01             	movzbl (%rcx),%eax
    7736:	84 c0                	test   %al,%al
    7738:	74 11                	je     774b <fwp_drop4+0x8b>
    773a:	3c 01                	cmp    $0x1,%al
    773c:	74 22                	je     7760 <fwp_drop4+0xa0>
    773e:	3c ff                	cmp    $0xff,%al
    7740:	0f 84 0a 01 00 00    	je     7850 <fwp_drop4+0x190>
    7746:	83 e8 01             	sub    $0x1,%eax
    7749:	88 01                	mov    %al,(%rcx)
    774b:	48 83 c4 18          	add    $0x18,%rsp
    774f:	c3                   	ret
    7750:	66 85 c0             	test   %ax,%ax
    7753:	74 de                	je     7733 <fwp_drop4+0x73>
    7755:	48 83 c4 18          	add    $0x18,%rsp
    7759:	c3                   	ret
    775a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7760:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7764:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    776b:	48 89 f8             	mov    %rdi,%rax
    776e:	48 c1 e1 10          	shl    $0x10,%rcx
    7772:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7779:	48 39 c8             	cmp    %rcx,%rax
    777c:	73 62                	jae    77e0 <fwp_drop4+0x120>
    777e:	48 89 c1             	mov    %rax,%rcx
    7781:	48 c1 e9 10          	shr    $0x10,%rcx
    7785:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7789:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    778d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7791:	48 85 c9             	test   %rcx,%rcx
    7794:	74 4a                	je     77e0 <fwp_drop4+0x120>
    7796:	44 0f b6 0e          	movzbl (%rsi),%r9d
    779a:	41 80 f9 02          	cmp    $0x2,%r9b
    779e:	0f 84 9c 00 00 00    	je     7840 <fwp_drop4+0x180>
    77a4:	41 80 f9 01          	cmp    $0x1,%r9b
    77a8:	75 36                	jne    77e0 <fwp_drop4+0x120>
    77aa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    77ae:	0f b7 c0             	movzwl %ax,%eax
    77b1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    77b4:	49 0f af c1          	imul   %r9,%rax
    77b8:	48 c1 e8 20          	shr    $0x20,%rax
    77bc:	48 39 f0             	cmp    %rsi,%rax
    77bf:	73 1f                	jae    77e0 <fwp_drop4+0x120>
    77c1:	48 01 c1             	add    %rax,%rcx
    77c4:	0f b6 01             	movzbl (%rcx),%eax
    77c7:	84 c0                	test   %al,%al
    77c9:	74 15                	je     77e0 <fwp_drop4+0x120>
    77cb:	3c 01                	cmp    $0x1,%al
    77cd:	74 59                	je     7828 <fwp_drop4+0x168>
    77cf:	3c ff                	cmp    $0xff,%al
    77d1:	0f 84 ef 00 00 00    	je     78c6 <fwp_drop4+0x206>
    77d7:	83 e8 01             	sub    $0x1,%eax
    77da:	88 01                	mov    %al,(%rcx)
    77dc:	0f 1f 40 00          	nopl   0x0(%rax)
    77e0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    77e4:	48 89 d7             	mov    %rdx,%rdi
    77e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    77eb:	e8 00 f7 ff ff       	call   6ef0 <fwp_rc_free_obj>
    77f0:	4c 8d 05 09 00 06 00 	lea    0x60009(%rip),%r8        # 67800 <fwp_heap>
    77f7:	48 8b 04 24          	mov    (%rsp),%rax
    77fb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7802:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7809:	48 c1 e2 10          	shl    $0x10,%rdx
    780d:	48 39 d0             	cmp    %rdx,%rax
    7810:	0f 83 35 ff ff ff    	jae    774b <fwp_drop4+0x8b>
    7816:	48 8b 14 24          	mov    (%rsp),%rdx
    781a:	e9 cd fe ff ff       	jmp    76ec <fwp_drop4+0x2c>
    781f:	90                   	nop
    7820:	c3                   	ret
    7821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7828:	48 89 14 24          	mov    %rdx,(%rsp)
    782c:	e8 bf f6 ff ff       	call   6ef0 <fwp_rc_free_obj>
    7831:	48 8b 14 24          	mov    (%rsp),%rdx
    7835:	eb a9                	jmp    77e0 <fwp_drop4+0x120>
    7837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    783e:	00 00 
    7840:	66 85 c0             	test   %ax,%ax
    7843:	75 9b                	jne    77e0 <fwp_drop4+0x120>
    7845:	e9 7a ff ff ff       	jmp    77c4 <fwp_drop4+0x104>
    784a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7850:	48 89 c8             	mov    %rcx,%rax
    7853:	48 c1 e8 11          	shr    $0x11,%rax
    7857:	48 31 c8             	xor    %rcx,%rax
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 09          	shr    $0x9,%rdx
    7861:	48 31 d0             	xor    %rdx,%rax
    7864:	0f b6 d0             	movzbl %al,%edx
    7867:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    786e:	00 
    786f:	48 85 c0             	test   %rax,%rax
    7872:	75 19                	jne    788d <fwp_drop4+0x1cd>
    7874:	e9 d3 00 00 00       	jmp    794c <fwp_drop4+0x28c>
    7879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7880:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7884:	48 85 c0             	test   %rax,%rax
    7887:	0f 84 bf 00 00 00    	je     794c <fwp_drop4+0x28c>
    788d:	48 89 c2             	mov    %rax,%rdx
    7890:	48 39 08             	cmp    %rcx,(%rax)
    7893:	75 eb                	jne    7880 <fwp_drop4+0x1c0>
    7895:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7899:	48 83 ea 01          	sub    $0x1,%rdx
    789d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    78a1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    78a8:	0f 85 9d fe ff ff    	jne    774b <fwp_drop4+0x8b>
    78ae:	48 89 cf             	mov    %rcx,%rdi
    78b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    78b5:	e8 b6 de ff ff       	call   5770 <fwp_rc_forget_slot>
    78ba:	48 8b 0c 24          	mov    (%rsp),%rcx
    78be:	c6 01 fe             	movb   $0xfe,(%rcx)
    78c1:	e9 85 fe ff ff       	jmp    774b <fwp_drop4+0x8b>
    78c6:	48 89 ce             	mov    %rcx,%rsi
    78c9:	48 c1 ee 11          	shr    $0x11,%rsi
    78cd:	48 31 ce             	xor    %rcx,%rsi
    78d0:	48 89 f0             	mov    %rsi,%rax
    78d3:	48 c1 e8 09          	shr    $0x9,%rax
    78d7:	48 31 c6             	xor    %rax,%rsi
    78da:	40 0f b6 f6          	movzbl %sil,%esi
    78de:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    78e5:	00 
    78e6:	48 85 c0             	test   %rax,%rax
    78e9:	75 1e                	jne    7909 <fwp_drop4+0x249>
    78eb:	eb 5f                	jmp    794c <fwp_drop4+0x28c>
    78ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    78f4:	00 
    78f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78fc:	00 00 00 00 
    7900:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7904:	48 85 c0             	test   %rax,%rax
    7907:	74 43                	je     794c <fwp_drop4+0x28c>
    7909:	48 89 c6             	mov    %rax,%rsi
    790c:	48 39 08             	cmp    %rcx,(%rax)
    790f:	75 ef                	jne    7900 <fwp_drop4+0x240>
    7911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7915:	48 83 ee 01          	sub    $0x1,%rsi
    7919:	48 89 70 08          	mov    %rsi,0x8(%rax)
    791d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7924:	0f 85 b6 fe ff ff    	jne    77e0 <fwp_drop4+0x120>
    792a:	48 89 cf             	mov    %rcx,%rdi
    792d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7932:	48 89 0c 24          	mov    %rcx,(%rsp)
    7936:	e8 35 de ff ff       	call   5770 <fwp_rc_forget_slot>
    793b:	48 8b 0c 24          	mov    (%rsp),%rcx
    793f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7944:	c6 01 fe             	movb   $0xfe,(%rcx)
    7947:	e9 94 fe ff ff       	jmp    77e0 <fwp_drop4+0x120>
    794c:	48 8d 3d 55 40 00 00 	lea    0x4055(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7953:	e8 b8 ca ff ff       	call   4410 <fwp_trap>
    7958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    795f:	00 

0000000000007960 <fwp_arg_drop37>:
    7960:	f3 0f 1e fa          	endbr64
    7964:	85 f6                	test   %esi,%esi
    7966:	75 04                	jne    796c <fwp_arg_drop37+0xc>
    7968:	85 d2                	test   %edx,%edx
    796a:	75 04                	jne    7970 <fwp_arg_drop37+0x10>
    796c:	c3                   	ret
    796d:	0f 1f 00             	nopl   (%rax)
    7970:	48 8b 3f             	mov    (%rdi),%rdi
    7973:	e9 48 fd ff ff       	jmp    76c0 <fwp_drop4>
    7978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    797f:	00 

0000000000007980 <fwp_task_dispose>:
    7980:	53                   	push   %rbx
    7981:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7985:	0f 84 7b bd ff ff    	je     3706 <fwp_task_dispose.cold>
    798b:	48 89 fb             	mov    %rdi,%rbx
    798e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7993:	0f 85 6d bd ff ff    	jne    3706 <fwp_task_dispose.cold>
    7999:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    799d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    79a4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    79ab:	00 
    79ac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    79b0:	48 85 ff             	test   %rdi,%rdi
    79b3:	74 07                	je     79bc <fwp_task_dispose+0x3c>
    79b5:	48 85 c0             	test   %rax,%rax
    79b8:	74 02                	je     79bc <fwp_task_dispose+0x3c>
    79ba:	ff d0                	call   *%rax
    79bc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    79c3:	e8 e8 df ff ff       	call   59b0 <fwp_mem_free>
    79c8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    79cf:	00 00 00 00 
    79d3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    79d7:	74 6f                	je     7a48 <fwp_task_dispose+0xc8>
    79d9:	48 8b 15 f8 11 06 00 	mov    0x611f8(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    79e0:	48 89 d8             	mov    %rbx,%rax
    79e3:	48 2b 05 c6 11 06 00 	sub    0x611c6(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    79ea:	48 c1 e2 10          	shl    $0x10,%rdx
    79ee:	48 39 d0             	cmp    %rdx,%rax
    79f1:	73 4c                	jae    7a3f <fwp_task_dispose+0xbf>
    79f3:	48 89 c2             	mov    %rax,%rdx
    79f6:	48 c1 ea 10          	shr    $0x10,%rdx
    79fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79fe:	48 8b 15 f3 11 06 00 	mov    0x611f3(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    7a05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a09:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a0d:	48 85 c9             	test   %rcx,%rcx
    7a10:	74 2d                	je     7a3f <fwp_task_dispose+0xbf>
    7a12:	0f b6 32             	movzbl (%rdx),%esi
    7a15:	40 80 fe 02          	cmp    $0x2,%sil
    7a19:	74 3d                	je     7a58 <fwp_task_dispose+0xd8>
    7a1b:	40 80 fe 01          	cmp    $0x1,%sil
    7a1f:	75 1e                	jne    7a3f <fwp_task_dispose+0xbf>
    7a21:	8b 72 18             	mov    0x18(%rdx),%esi
    7a24:	0f b7 c0             	movzwl %ax,%eax
    7a27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a2a:	48 0f af c6          	imul   %rsi,%rax
    7a2e:	48 c1 e8 20          	shr    $0x20,%rax
    7a32:	48 39 d0             	cmp    %rdx,%rax
    7a35:	73 08                	jae    7a3f <fwp_task_dispose+0xbf>
    7a37:	48 01 c1             	add    %rax,%rcx
    7a3a:	80 39 01             	cmpb   $0x1,(%rcx)
    7a3d:	74 09                	je     7a48 <fwp_task_dispose+0xc8>
    7a3f:	5b                   	pop    %rbx
    7a40:	c3                   	ret
    7a41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a48:	48 89 df             	mov    %rbx,%rdi
    7a4b:	5b                   	pop    %rbx
    7a4c:	e9 5f df ff ff       	jmp    59b0 <fwp_mem_free>
    7a51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a58:	66 85 c0             	test   %ax,%ax
    7a5b:	74 dd                	je     7a3a <fwp_task_dispose+0xba>
    7a5d:	5b                   	pop    %rbx
    7a5e:	c3                   	ret
    7a5f:	90                   	nop

0000000000007a60 <fwp_free_zombie>:
    7a60:	48 8b 15 69 fd 05 00 	mov    0x5fd69(%rip),%rdx        # 677d0 <fwp_zombie>
    7a67:	48 85 d2             	test   %rdx,%rdx
    7a6a:	0f 84 98 00 00 00    	je     7b08 <fwp_free_zombie+0xa8>
    7a70:	48 3b 15 69 fd 05 00 	cmp    0x5fd69(%rip),%rdx        # 677e0 <fwp_cur>
    7a77:	0f 84 8b 00 00 00    	je     7b08 <fwp_free_zombie+0xa8>
    7a7d:	48 83 ec 18          	sub    $0x18,%rsp
    7a81:	48 63 05 2c f7 05 00 	movslq 0x5f72c(%rip),%rax        # 671b4 <fwp_stack_pool_n>
    7a88:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    7a8c:	83 f8 3f             	cmp    $0x3f,%eax
    7a8f:	7f 7f                	jg     7b10 <fwp_free_zombie+0xb0>
    7a91:	8d 48 01             	lea    0x1(%rax),%ecx
    7a94:	89 0d 1a f7 05 00    	mov    %ecx,0x5f71a(%rip)        # 671b4 <fwp_stack_pool_n>
    7a9a:	48 8d 0d 1f f7 05 00 	lea    0x5f71f(%rip),%rcx        # 671c0 <fwp_stack_pool>
    7aa1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7aa5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    7aac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7ab0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7ab7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    7abb:	48 85 c9             	test   %rcx,%rcx
    7abe:	0f 84 fc 00 00 00    	je     7bc0 <fwp_free_zombie+0x160>
    7ac4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    7acb:	48 85 c0             	test   %rax,%rax
    7ace:	74 07                	je     7ad7 <fwp_free_zombie+0x77>
    7ad0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7ad7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    7ada:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7ade:	48 c7 05 e7 fc 05 00 	movq   $0x0,0x5fce7(%rip)        # 677d0 <fwp_zombie>
    7ae5:	00 00 00 00 
    7ae9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7af0:	85 c0                	test   %eax,%eax
    7af2:	74 34                	je     7b28 <fwp_free_zombie+0xc8>
    7af4:	83 f8 01             	cmp    $0x1,%eax
    7af7:	0f 84 b3 00 00 00    	je     7bb0 <fwp_free_zombie+0x150>
    7afd:	48 83 c4 18          	add    $0x18,%rsp
    7b01:	c3                   	ret
    7b02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b08:	c3                   	ret
    7b09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b10:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7b14:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b19:	e8 92 ba ff ff       	call   35b0 <munmap@plt>
    7b1e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b23:	eb 80                	jmp    7aa5 <fwp_free_zombie+0x45>
    7b25:	0f 1f 00             	nopl   (%rax)
    7b28:	48 8b 0d a9 10 06 00 	mov    0x610a9(%rip),%rcx        # 68bd8 <fwp_heap+0x13d8>
    7b2f:	48 89 d0             	mov    %rdx,%rax
    7b32:	48 2b 05 77 10 06 00 	sub    0x61077(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7b39:	48 c1 e1 10          	shl    $0x10,%rcx
    7b3d:	48 39 c8             	cmp    %rcx,%rax
    7b40:	73 bb                	jae    7afd <fwp_free_zombie+0x9d>
    7b42:	48 89 c1             	mov    %rax,%rcx
    7b45:	48 c1 e9 10          	shr    $0x10,%rcx
    7b49:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b4d:	48 8b 0d a4 10 06 00 	mov    0x610a4(%rip),%rcx        # 68bf8 <fwp_heap+0x13f8>
    7b54:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7b58:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7b5c:	48 85 c9             	test   %rcx,%rcx
    7b5f:	74 9c                	je     7afd <fwp_free_zombie+0x9d>
    7b61:	0f b6 3e             	movzbl (%rsi),%edi
    7b64:	40 80 ff 02          	cmp    $0x2,%dil
    7b68:	74 66                	je     7bd0 <fwp_free_zombie+0x170>
    7b6a:	40 80 ff 01          	cmp    $0x1,%dil
    7b6e:	75 8d                	jne    7afd <fwp_free_zombie+0x9d>
    7b70:	8b 7e 18             	mov    0x18(%rsi),%edi
    7b73:	0f b7 c0             	movzwl %ax,%eax
    7b76:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7b79:	48 0f af c7          	imul   %rdi,%rax
    7b7d:	48 c1 e8 20          	shr    $0x20,%rax
    7b81:	48 39 f0             	cmp    %rsi,%rax
    7b84:	0f 83 73 ff ff ff    	jae    7afd <fwp_free_zombie+0x9d>
    7b8a:	48 01 c1             	add    %rax,%rcx
    7b8d:	0f b6 01             	movzbl (%rcx),%eax
    7b90:	84 c0                	test   %al,%al
    7b92:	0f 84 65 ff ff ff    	je     7afd <fwp_free_zombie+0x9d>
    7b98:	3c 01                	cmp    $0x1,%al
    7b9a:	74 14                	je     7bb0 <fwp_free_zombie+0x150>
    7b9c:	3c ff                	cmp    $0xff,%al
    7b9e:	74 3b                	je     7bdb <fwp_free_zombie+0x17b>
    7ba0:	83 e8 01             	sub    $0x1,%eax
    7ba3:	88 01                	mov    %al,(%rcx)
    7ba5:	e9 53 ff ff ff       	jmp    7afd <fwp_free_zombie+0x9d>
    7baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bb0:	48 89 d7             	mov    %rdx,%rdi
    7bb3:	48 83 c4 18          	add    $0x18,%rsp
    7bb7:	e9 c4 fd ff ff       	jmp    7980 <fwp_task_dispose>
    7bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    7bc0:	48 89 05 e1 fb 05 00 	mov    %rax,0x5fbe1(%rip)        # 677a8 <fwp_tasks_active>
    7bc7:	e9 ff fe ff ff       	jmp    7acb <fwp_free_zombie+0x6b>
    7bcc:	0f 1f 40 00          	nopl   0x0(%rax)
    7bd0:	66 85 c0             	test   %ax,%ax
    7bd3:	0f 85 24 ff ff ff    	jne    7afd <fwp_free_zombie+0x9d>
    7bd9:	eb b2                	jmp    7b8d <fwp_free_zombie+0x12d>
    7bdb:	48 89 ca             	mov    %rcx,%rdx
    7bde:	48 8d 35 1b fc 05 00 	lea    0x5fc1b(%rip),%rsi        # 67800 <fwp_heap>
    7be5:	48 c1 ea 11          	shr    $0x11,%rdx
    7be9:	48 31 ca             	xor    %rcx,%rdx
    7bec:	48 89 d0             	mov    %rdx,%rax
    7bef:	48 c1 e8 09          	shr    $0x9,%rax
    7bf3:	48 31 c2             	xor    %rax,%rdx
    7bf6:	0f b6 d2             	movzbl %dl,%edx
    7bf9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7c00:	00 
    7c01:	48 85 c0             	test   %rax,%rax
    7c04:	75 23                	jne    7c29 <fwp_free_zombie+0x1c9>
    7c06:	eb 5c                	jmp    7c64 <fwp_free_zombie+0x204>
    7c08:	66 90                	xchg   %ax,%ax
    7c0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c11:	00 00 00 00 
    7c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c1c:	00 00 00 00 
    7c20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7c24:	48 85 c0             	test   %rax,%rax
    7c27:	74 3b                	je     7c64 <fwp_free_zombie+0x204>
    7c29:	48 89 c2             	mov    %rax,%rdx
    7c2c:	48 39 08             	cmp    %rcx,(%rax)
    7c2f:	75 ef                	jne    7c20 <fwp_free_zombie+0x1c0>
    7c31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c35:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7c39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c44:	0f 85 b3 fe ff ff    	jne    7afd <fwp_free_zombie+0x9d>
    7c4a:	48 89 cf             	mov    %rcx,%rdi
    7c4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c52:	e8 19 db ff ff       	call   5770 <fwp_rc_forget_slot>
    7c57:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7c5c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c5f:	e9 99 fe ff ff       	jmp    7afd <fwp_free_zombie+0x9d>
    7c64:	48 8d 3d 3d 3d 00 00 	lea    0x3d3d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7c6b:	e8 a0 c7 ff ff       	call   4410 <fwp_trap>

0000000000007c70 <fwp_block>:
    7c70:	48 83 ec 08          	sub    $0x8,%rsp
    7c74:	48 8b 05 4d fb 05 00 	mov    0x5fb4d(%rip),%rax        # 677c8 <fwp_ready_head>
    7c7b:	48 85 c0             	test   %rax,%rax
    7c7e:	0f 84 1c 01 00 00    	je     7da0 <fwp_block+0x130>
    7c84:	90                   	nop
    7c85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c8c:	00 00 00 00 
    7c90:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7c97:	48 89 15 2a fb 05 00 	mov    %rdx,0x5fb2a(%rip)        # 677c8 <fwp_ready_head>
    7c9e:	48 85 d2             	test   %rdx,%rdx
    7ca1:	0f 84 19 01 00 00    	je     7dc0 <fwp_block+0x150>
    7ca7:	48 8b 15 32 fb 05 00 	mov    0x5fb32(%rip),%rdx        # 677e0 <fwp_cur>
    7cae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7cb2:	48 39 c2             	cmp    %rax,%rdx
    7cb5:	0f 84 d5 00 00 00    	je     7d90 <fwp_block+0x120>
    7cbb:	48 8b 0d a6 17 06 00 	mov    0x617a6(%rip),%rcx        # 69468 <fwp_state_owners>
    7cc2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7cc6:	48 89 05 13 fb 05 00 	mov    %rax,0x5fb13(%rip)        # 677e0 <fwp_cur>
    7ccd:	f3 0f 7e 05 bb 17 06 	movq   0x617bb(%rip),%xmm0        # 69490 <fwp_foreign_callbacks>
    7cd4:	00 
    7cd5:	0f 16 05 a4 17 06 00 	movhps 0x617a4(%rip),%xmm0        # 69480 <fwp_state>
    7cdc:	f3 0f 7e 0d a4 17 06 	movq   0x617a4(%rip),%xmm1        # 69488 <fwp_handlers>
    7ce3:	00 
    7ce4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7ceb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7cf2:	0f 16 0d 9f 17 06 00 	movhps 0x6179f(%rip),%xmm1        # 69498 <fwp_cleanups>
    7cf9:	f3 0f 7e 05 77 17 06 	movq   0x61777(%rip),%xmm0        # 69478 <fwp_state_len>
    7d00:	00 
    7d01:	0f 16 05 68 17 06 00 	movhps 0x61768(%rip),%xmm0        # 69470 <fwp_state_cap>
    7d08:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7d0f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7d16:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d1a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7d21:	48 89 0d 60 17 06 00 	mov    %rcx,0x61760(%rip)        # 69488 <fwp_handlers>
    7d28:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7d2f:	48 89 0d 62 17 06 00 	mov    %rcx,0x61762(%rip)        # 69498 <fwp_cleanups>
    7d36:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7d3d:	48 89 0d 4c 17 06 00 	mov    %rcx,0x6174c(%rip)        # 69490 <fwp_foreign_callbacks>
    7d44:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7d4b:	48 89 0d 2e 17 06 00 	mov    %rcx,0x6172e(%rip)        # 69480 <fwp_state>
    7d52:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7d59:	48 89 0d 18 17 06 00 	mov    %rcx,0x61718(%rip)        # 69478 <fwp_state_len>
    7d60:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7d67:	48 89 0d 02 17 06 00 	mov    %rcx,0x61702(%rip)        # 69470 <fwp_state_cap>
    7d6e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7d75:	48 89 0d ec 16 06 00 	mov    %rcx,0x616ec(%rip)        # 69468 <fwp_state_owners>
    7d7c:	e8 ef b6 ff ff       	call   3470 <swapcontext@plt>
    7d81:	f3 0f 1e fa          	endbr64
    7d85:	e8 d6 fc ff ff       	call   7a60 <fwp_free_zombie>
    7d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d90:	8b 05 1a f4 05 00    	mov    0x5f41a(%rip),%eax        # 671b0 <fwp_slice>
    7d96:	85 c0                	test   %eax,%eax
    7d98:	74 36                	je     7dd0 <fwp_block+0x160>
    7d9a:	48 83 c4 08          	add    $0x8,%rsp
    7d9e:	c3                   	ret
    7d9f:	90                   	nop
    7da0:	e8 1b d6 ff ff       	call   53c0 <fwp_poll_events>
    7da5:	48 8b 05 1c fa 05 00 	mov    0x5fa1c(%rip),%rax        # 677c8 <fwp_ready_head>
    7dac:	48 85 c0             	test   %rax,%rax
    7daf:	0f 85 db fe ff ff    	jne    7c90 <fwp_block+0x20>
    7db5:	eb e9                	jmp    7da0 <fwp_block+0x130>
    7db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dbe:	00 00 
    7dc0:	48 c7 05 f5 f9 05 00 	movq   $0x0,0x5f9f5(%rip)        # 677c0 <fwp_ready_tail>
    7dc7:	00 00 00 00 
    7dcb:	e9 d7 fe ff ff       	jmp    7ca7 <fwp_block+0x37>
    7dd0:	48 8d 3d 0a 34 00 00 	lea    0x340a(%rip),%rdi        # b1e1 <_IO_stdin_used+0x1e1>
    7dd7:	e8 a4 b5 ff ff       	call   3380 <getenv@plt>
    7ddc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7de1:	48 85 c0             	test   %rax,%rax
    7de4:	74 05                	je     7deb <fwp_block+0x17b>
    7de6:	80 38 00             	cmpb   $0x0,(%rax)
    7de9:	75 0b                	jne    7df6 <fwp_block+0x186>
    7deb:	89 15 bf f3 05 00    	mov    %edx,0x5f3bf(%rip)        # 671b0 <fwp_slice>
    7df1:	48 83 c4 08          	add    $0x8,%rsp
    7df5:	c3                   	ret
    7df6:	ba 0a 00 00 00       	mov    $0xa,%edx
    7dfb:	31 f6                	xor    %esi,%esi
    7dfd:	48 89 c7             	mov    %rax,%rdi
    7e00:	e8 2b b7 ff ff       	call   3530 <strtoll@plt>
    7e05:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7e09:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7e10:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7e15:	0f 46 d0             	cmovbe %eax,%edx
    7e18:	eb d1                	jmp    7deb <fwp_block+0x17b>
    7e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007e20 <fwp_caps173>:
    7e20:	f3 0f 1e fa          	endbr64
    7e24:	85 f6                	test   %esi,%esi
    7e26:	74 08                	je     7e30 <fwp_caps173+0x10>
    7e28:	c3                   	ret
    7e29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e30:	48 8b 15 a1 0d 06 00 	mov    0x60da1(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    7e37:	48 89 f8             	mov    %rdi,%rax
    7e3a:	48 2b 05 6f 0d 06 00 	sub    0x60d6f(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7e41:	48 c1 e2 10          	shl    $0x10,%rdx
    7e45:	48 39 d0             	cmp    %rdx,%rax
    7e48:	73 de                	jae    7e28 <fwp_caps173+0x8>
    7e4a:	48 89 c2             	mov    %rax,%rdx
    7e4d:	48 c1 ea 10          	shr    $0x10,%rdx
    7e51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e55:	48 8b 15 9c 0d 06 00 	mov    0x60d9c(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    7e5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e60:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7e64:	48 85 c9             	test   %rcx,%rcx
    7e67:	74 bf                	je     7e28 <fwp_caps173+0x8>
    7e69:	0f b6 32             	movzbl (%rdx),%esi
    7e6c:	40 80 fe 02          	cmp    $0x2,%sil
    7e70:	74 2e                	je     7ea0 <fwp_caps173+0x80>
    7e72:	40 80 fe 01          	cmp    $0x1,%sil
    7e76:	75 b0                	jne    7e28 <fwp_caps173+0x8>
    7e78:	8b 72 18             	mov    0x18(%rdx),%esi
    7e7b:	0f b7 c0             	movzwl %ax,%eax
    7e7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e81:	48 0f af c6          	imul   %rsi,%rax
    7e85:	48 c1 e8 20          	shr    $0x20,%rax
    7e89:	48 39 d0             	cmp    %rdx,%rax
    7e8c:	73 9a                	jae    7e28 <fwp_caps173+0x8>
    7e8e:	48 01 c1             	add    %rax,%rcx
    7e91:	80 39 01             	cmpb   $0x1,(%rcx)
    7e94:	75 92                	jne    7e28 <fwp_caps173+0x8>
    7e96:	e9 15 db ff ff       	jmp    59b0 <fwp_mem_free>
    7e9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ea0:	66 85 c0             	test   %ax,%ax
    7ea3:	74 ec                	je     7e91 <fwp_caps173+0x71>
    7ea5:	c3                   	ret
    7ea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ead:	00 00 00 

0000000000007eb0 <fwp_args37>:
    7eb0:	f3 0f 1e fa          	endbr64
    7eb4:	85 d2                	test   %edx,%edx
    7eb6:	74 04                	je     7ebc <fwp_args37+0xc>
    7eb8:	85 f6                	test   %esi,%esi
    7eba:	74 04                	je     7ec0 <fwp_args37+0x10>
    7ebc:	c3                   	ret
    7ebd:	0f 1f 00             	nopl   (%rax)
    7ec0:	48 8b 15 11 0d 06 00 	mov    0x60d11(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    7ec7:	48 8b 07             	mov    (%rdi),%rax
    7eca:	48 2b 05 df 0c 06 00 	sub    0x60cdf(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    7ed1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ed5:	48 39 d0             	cmp    %rdx,%rax
    7ed8:	73 e2                	jae    7ebc <fwp_args37+0xc>
    7eda:	48 89 c2             	mov    %rax,%rdx
    7edd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ee1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ee5:	48 8b 15 0c 0d 06 00 	mov    0x60d0c(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    7eec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ef0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ef4:	48 85 ff             	test   %rdi,%rdi
    7ef7:	74 c3                	je     7ebc <fwp_args37+0xc>
    7ef9:	0f b6 0a             	movzbl (%rdx),%ecx
    7efc:	80 f9 02             	cmp    $0x2,%cl
    7eff:	74 4f                	je     7f50 <fwp_args37+0xa0>
    7f01:	80 f9 01             	cmp    $0x1,%cl
    7f04:	75 b6                	jne    7ebc <fwp_args37+0xc>
    7f06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f09:	0f b7 c0             	movzwl %ax,%eax
    7f0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f0f:	48 0f af c1          	imul   %rcx,%rax
    7f13:	48 c1 e8 20          	shr    $0x20,%rax
    7f17:	48 39 d0             	cmp    %rdx,%rax
    7f1a:	73 a0                	jae    7ebc <fwp_args37+0xc>
    7f1c:	48 01 c7             	add    %rax,%rdi
    7f1f:	0f b6 07             	movzbl (%rdi),%eax
    7f22:	84 c0                	test   %al,%al
    7f24:	74 96                	je     7ebc <fwp_args37+0xc>
    7f26:	8b 15 9c 15 06 00    	mov    0x6159c(%rip),%edx        # 694c8 <iteration_active>
    7f2c:	85 d2                	test   %edx,%edx
    7f2e:	75 10                	jne    7f40 <fwp_args37+0x90>
    7f30:	3c fd                	cmp    $0xfd,%al
    7f32:	77 22                	ja     7f56 <fwp_args37+0xa6>
    7f34:	83 c0 01             	add    $0x1,%eax
    7f37:	88 07                	mov    %al,(%rdi)
    7f39:	c3                   	ret
    7f3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f40:	48 83 05 68 15 06 00 	addq   $0x1,0x61568(%rip)        # 694b0 <iteration_retains>
    7f47:	01 
    7f48:	eb e6                	jmp    7f30 <fwp_args37+0x80>
    7f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f50:	66 85 c0             	test   %ax,%ax
    7f53:	74 ca                	je     7f1f <fwp_args37+0x6f>
    7f55:	c3                   	ret
    7f56:	e9 f5 d6 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    7f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007f60 <fwp_caps37>:
    7f60:	f3 0f 1e fa          	endbr64
    7f64:	48 83 ec 18          	sub    $0x18,%rsp
    7f68:	48 89 f8             	mov    %rdi,%rax
    7f6b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7f6e:	85 ff                	test   %edi,%edi
    7f70:	0f 84 9a 00 00 00    	je     8010 <fwp_caps37+0xb0>
    7f76:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7f7a:	85 f6                	test   %esi,%esi
    7f7c:	0f 85 9e 00 00 00    	jne    8020 <fwp_caps37+0xc0>
    7f82:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7f87:	e8 34 f7 ff ff       	call   76c0 <fwp_drop4>
    7f8c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f91:	48 8b 0d 40 0c 06 00 	mov    0x60c40(%rip),%rcx        # 68bd8 <fwp_heap+0x13d8>
    7f98:	48 89 c2             	mov    %rax,%rdx
    7f9b:	48 2b 15 0e 0c 06 00 	sub    0x60c0e(%rip),%rdx        # 68bb0 <fwp_heap+0x13b0>
    7fa2:	48 c1 e1 10          	shl    $0x10,%rcx
    7fa6:	48 39 ca             	cmp    %rcx,%rdx
    7fa9:	73 6d                	jae    8018 <fwp_caps37+0xb8>
    7fab:	48 89 d1             	mov    %rdx,%rcx
    7fae:	48 c1 e9 10          	shr    $0x10,%rcx
    7fb2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7fb6:	48 8b 0d 3b 0c 06 00 	mov    0x60c3b(%rip),%rcx        # 68bf8 <fwp_heap+0x13f8>
    7fbd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7fc1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7fc5:	48 85 f6             	test   %rsi,%rsi
    7fc8:	74 4e                	je     8018 <fwp_caps37+0xb8>
    7fca:	0f b6 39             	movzbl (%rcx),%edi
    7fcd:	40 80 ff 02          	cmp    $0x2,%dil
    7fd1:	0f 84 c9 00 00 00    	je     80a0 <fwp_caps37+0x140>
    7fd7:	40 80 ff 01          	cmp    $0x1,%dil
    7fdb:	75 3b                	jne    8018 <fwp_caps37+0xb8>
    7fdd:	8b 79 18             	mov    0x18(%rcx),%edi
    7fe0:	0f b7 d2             	movzwl %dx,%edx
    7fe3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fe6:	48 0f af d7          	imul   %rdi,%rdx
    7fea:	48 c1 ea 20          	shr    $0x20,%rdx
    7fee:	48 39 ca             	cmp    %rcx,%rdx
    7ff1:	73 25                	jae    8018 <fwp_caps37+0xb8>
    7ff3:	48 01 d6             	add    %rdx,%rsi
    7ff6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7ff9:	75 1d                	jne    8018 <fwp_caps37+0xb8>
    7ffb:	48 89 c7             	mov    %rax,%rdi
    7ffe:	48 83 c4 18          	add    $0x18,%rsp
    8002:	e9 a9 d9 ff ff       	jmp    59b0 <fwp_mem_free>
    8007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    800e:	00 00 
    8010:	85 f6                	test   %esi,%esi
    8012:	0f 84 79 ff ff ff    	je     7f91 <fwp_caps37+0x31>
    8018:	48 83 c4 18          	add    $0x18,%rsp
    801c:	c3                   	ret
    801d:	0f 1f 00             	nopl   (%rax)
    8020:	48 8b 05 b1 0b 06 00 	mov    0x60bb1(%rip),%rax        # 68bd8 <fwp_heap+0x13d8>
    8027:	48 2b 3d 82 0b 06 00 	sub    0x60b82(%rip),%rdi        # 68bb0 <fwp_heap+0x13b0>
    802e:	48 c1 e0 10          	shl    $0x10,%rax
    8032:	48 39 c7             	cmp    %rax,%rdi
    8035:	73 e1                	jae    8018 <fwp_caps37+0xb8>
    8037:	48 89 f8             	mov    %rdi,%rax
    803a:	48 c1 e8 10          	shr    $0x10,%rax
    803e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8042:	48 8b 05 af 0b 06 00 	mov    0x60baf(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    8049:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    804d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8051:	48 85 c0             	test   %rax,%rax
    8054:	74 c2                	je     8018 <fwp_caps37+0xb8>
    8056:	0f b6 0a             	movzbl (%rdx),%ecx
    8059:	80 f9 02             	cmp    $0x2,%cl
    805c:	74 52                	je     80b0 <fwp_caps37+0x150>
    805e:	80 f9 01             	cmp    $0x1,%cl
    8061:	75 b5                	jne    8018 <fwp_caps37+0xb8>
    8063:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8066:	0f b7 ff             	movzwl %di,%edi
    8069:	8b 52 1c             	mov    0x1c(%rdx),%edx
    806c:	48 0f af f9          	imul   %rcx,%rdi
    8070:	48 c1 ef 20          	shr    $0x20,%rdi
    8074:	48 39 d7             	cmp    %rdx,%rdi
    8077:	73 9f                	jae    8018 <fwp_caps37+0xb8>
    8079:	48 01 f8             	add    %rdi,%rax
    807c:	0f b6 10             	movzbl (%rax),%edx
    807f:	84 d2                	test   %dl,%dl
    8081:	74 95                	je     8018 <fwp_caps37+0xb8>
    8083:	8b 0d 3f 14 06 00    	mov    0x6143f(%rip),%ecx        # 694c8 <iteration_active>
    8089:	85 c9                	test   %ecx,%ecx
    808b:	75 33                	jne    80c0 <fwp_caps37+0x160>
    808d:	80 fa fd             	cmp    $0xfd,%dl
    8090:	77 38                	ja     80ca <fwp_caps37+0x16a>
    8092:	83 c2 01             	add    $0x1,%edx
    8095:	88 10                	mov    %dl,(%rax)
    8097:	e9 7c ff ff ff       	jmp    8018 <fwp_caps37+0xb8>
    809c:	0f 1f 40 00          	nopl   0x0(%rax)
    80a0:	66 85 d2             	test   %dx,%dx
    80a3:	0f 85 6f ff ff ff    	jne    8018 <fwp_caps37+0xb8>
    80a9:	e9 48 ff ff ff       	jmp    7ff6 <fwp_caps37+0x96>
    80ae:	66 90                	xchg   %ax,%ax
    80b0:	66 85 ff             	test   %di,%di
    80b3:	0f 85 5f ff ff ff    	jne    8018 <fwp_caps37+0xb8>
    80b9:	eb c1                	jmp    807c <fwp_caps37+0x11c>
    80bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    80c0:	48 83 05 e8 13 06 00 	addq   $0x1,0x613e8(%rip)        # 694b0 <iteration_retains>
    80c7:	01 
    80c8:	eb c3                	jmp    808d <fwp_caps37+0x12d>
    80ca:	48 89 c7             	mov    %rax,%rdi
    80cd:	48 83 c4 18          	add    $0x18,%rsp
    80d1:	e9 7a d5 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    80d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80dd:	00 00 00 

00000000000080e0 <fwp_drop0>:
    80e0:	f3 0f 1e fa          	endbr64
    80e4:	48 8b 15 ed 0a 06 00 	mov    0x60aed(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    80eb:	48 89 f8             	mov    %rdi,%rax
    80ee:	48 2b 05 bb 0a 06 00 	sub    0x60abb(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    80f5:	48 c1 e2 10          	shl    $0x10,%rdx
    80f9:	48 39 d0             	cmp    %rdx,%rax
    80fc:	0f 83 36 01 00 00    	jae    8238 <fwp_drop0+0x158>
    8102:	48 83 ec 18          	sub    $0x18,%rsp
    8106:	48 8d 35 f3 f6 05 00 	lea    0x5f6f3(%rip),%rsi        # 67800 <fwp_heap>
    810d:	48 89 c2             	mov    %rax,%rdx
    8110:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    8117:	48 c1 ea 10          	shr    $0x10,%rdx
    811b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    811f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    8123:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8127:	48 85 d2             	test   %rdx,%rdx
    812a:	74 42                	je     816e <fwp_drop0+0x8e>
    812c:	44 0f b6 01          	movzbl (%rcx),%r8d
    8130:	41 80 f8 02          	cmp    $0x2,%r8b
    8134:	74 42                	je     8178 <fwp_drop0+0x98>
    8136:	41 80 f8 01          	cmp    $0x1,%r8b
    813a:	75 32                	jne    816e <fwp_drop0+0x8e>
    813c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    8140:	0f b7 c0             	movzwl %ax,%eax
    8143:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8146:	49 0f af c0          	imul   %r8,%rax
    814a:	48 c1 e8 20          	shr    $0x20,%rax
    814e:	48 39 c8             	cmp    %rcx,%rax
    8151:	73 1b                	jae    816e <fwp_drop0+0x8e>
    8153:	48 01 c2             	add    %rax,%rdx
    8156:	0f b6 02             	movzbl (%rdx),%eax
    8159:	84 c0                	test   %al,%al
    815b:	74 11                	je     816e <fwp_drop0+0x8e>
    815d:	3c 01                	cmp    $0x1,%al
    815f:	74 27                	je     8188 <fwp_drop0+0xa8>
    8161:	3c ff                	cmp    $0xff,%al
    8163:	0f 84 e7 00 00 00    	je     8250 <fwp_drop0+0x170>
    8169:	83 e8 01             	sub    $0x1,%eax
    816c:	88 02                	mov    %al,(%rdx)
    816e:	48 83 c4 18          	add    $0x18,%rsp
    8172:	c3                   	ret
    8173:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8178:	66 85 c0             	test   %ax,%ax
    817b:	74 d9                	je     8156 <fwp_drop0+0x76>
    817d:	48 83 c4 18          	add    $0x18,%rsp
    8181:	c3                   	ret
    8182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8188:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    818f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8196:	48 89 f8             	mov    %rdi,%rax
    8199:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    819d:	48 29 c8             	sub    %rcx,%rax
    81a0:	48 c1 e2 10          	shl    $0x10,%rdx
    81a4:	48 39 d0             	cmp    %rdx,%rax
    81a7:	73 71                	jae    821a <fwp_drop0+0x13a>
    81a9:	49 89 c2             	mov    %rax,%r10
    81ac:	49 c1 ea 10          	shr    $0x10,%r10
    81b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    81b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    81b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    81bc:	4d 85 d2             	test   %r10,%r10
    81bf:	74 59                	je     821a <fwp_drop0+0x13a>
    81c1:	45 0f b6 19          	movzbl (%r9),%r11d
    81c5:	41 80 fb 02          	cmp    $0x2,%r11b
    81c9:	74 75                	je     8240 <fwp_drop0+0x160>
    81cb:	41 80 fb 01          	cmp    $0x1,%r11b
    81cf:	75 49                	jne    821a <fwp_drop0+0x13a>
    81d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    81d5:	0f b7 c0             	movzwl %ax,%eax
    81d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    81dc:	49 0f af c3          	imul   %r11,%rax
    81e0:	48 c1 e8 20          	shr    $0x20,%rax
    81e4:	4c 39 c8             	cmp    %r9,%rax
    81e7:	73 31                	jae    821a <fwp_drop0+0x13a>
    81e9:	49 01 c2             	add    %rax,%r10
    81ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    81f0:	75 28                	jne    821a <fwp_drop0+0x13a>
    81f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    81f7:	e8 b4 d7 ff ff       	call   59b0 <fwp_mem_free>
    81fc:	48 8d 35 fd f5 05 00 	lea    0x5f5fd(%rip),%rsi        # 67800 <fwp_heap>
    8203:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8208:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    820f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8216:	48 c1 e2 10          	shl    $0x10,%rdx
    821a:	4c 89 c0             	mov    %r8,%rax
    821d:	48 29 c8             	sub    %rcx,%rax
    8220:	48 39 d0             	cmp    %rdx,%rax
    8223:	0f 83 45 ff ff ff    	jae    816e <fwp_drop0+0x8e>
    8229:	4c 89 c7             	mov    %r8,%rdi
    822c:	e9 dc fe ff ff       	jmp    810d <fwp_drop0+0x2d>
    8231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8238:	c3                   	ret
    8239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8240:	66 85 c0             	test   %ax,%ax
    8243:	75 d5                	jne    821a <fwp_drop0+0x13a>
    8245:	eb a5                	jmp    81ec <fwp_drop0+0x10c>
    8247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    824e:	00 00 
    8250:	48 89 d0             	mov    %rdx,%rax
    8253:	48 c1 e8 11          	shr    $0x11,%rax
    8257:	48 31 d0             	xor    %rdx,%rax
    825a:	48 89 c1             	mov    %rax,%rcx
    825d:	48 c1 e9 09          	shr    $0x9,%rcx
    8261:	48 31 c8             	xor    %rcx,%rax
    8264:	0f b6 c8             	movzbl %al,%ecx
    8267:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    826e:	00 
    826f:	48 85 c0             	test   %rax,%rax
    8272:	75 15                	jne    8289 <fwp_drop0+0x1a9>
    8274:	eb 4e                	jmp    82c4 <fwp_drop0+0x1e4>
    8276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    827d:	00 00 00 
    8280:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8284:	48 85 c0             	test   %rax,%rax
    8287:	74 3b                	je     82c4 <fwp_drop0+0x1e4>
    8289:	48 89 c1             	mov    %rax,%rcx
    828c:	48 39 10             	cmp    %rdx,(%rax)
    828f:	75 ef                	jne    8280 <fwp_drop0+0x1a0>
    8291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8295:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8299:	48 89 48 08          	mov    %rcx,0x8(%rax)
    829d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    82a4:	0f 85 c4 fe ff ff    	jne    816e <fwp_drop0+0x8e>
    82aa:	48 89 d7             	mov    %rdx,%rdi
    82ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    82b2:	e8 b9 d4 ff ff       	call   5770 <fwp_rc_forget_slot>
    82b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    82bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    82bf:	e9 aa fe ff ff       	jmp    816e <fwp_drop0+0x8e>
    82c4:	48 8d 3d dd 36 00 00 	lea    0x36dd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    82cb:	e8 40 c1 ff ff       	call   4410 <fwp_trap>

00000000000082d0 <fwp_drop1>:
    82d0:	f3 0f 1e fa          	endbr64
    82d4:	48 8b 15 fd 08 06 00 	mov    0x608fd(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    82db:	48 89 f8             	mov    %rdi,%rax
    82de:	48 2b 05 cb 08 06 00 	sub    0x608cb(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    82e5:	48 c1 e2 10          	shl    $0x10,%rdx
    82e9:	48 39 d0             	cmp    %rdx,%rax
    82ec:	0f 83 36 01 00 00    	jae    8428 <fwp_drop1+0x158>
    82f2:	48 83 ec 18          	sub    $0x18,%rsp
    82f6:	48 8d 35 03 f5 05 00 	lea    0x5f503(%rip),%rsi        # 67800 <fwp_heap>
    82fd:	48 89 c2             	mov    %rax,%rdx
    8300:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    8307:	48 c1 ea 10          	shr    $0x10,%rdx
    830b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    830f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    8313:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8317:	48 85 d2             	test   %rdx,%rdx
    831a:	74 42                	je     835e <fwp_drop1+0x8e>
    831c:	44 0f b6 01          	movzbl (%rcx),%r8d
    8320:	41 80 f8 02          	cmp    $0x2,%r8b
    8324:	74 42                	je     8368 <fwp_drop1+0x98>
    8326:	41 80 f8 01          	cmp    $0x1,%r8b
    832a:	75 32                	jne    835e <fwp_drop1+0x8e>
    832c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    8330:	0f b7 c0             	movzwl %ax,%eax
    8333:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8336:	49 0f af c0          	imul   %r8,%rax
    833a:	48 c1 e8 20          	shr    $0x20,%rax
    833e:	48 39 c8             	cmp    %rcx,%rax
    8341:	73 1b                	jae    835e <fwp_drop1+0x8e>
    8343:	48 01 c2             	add    %rax,%rdx
    8346:	0f b6 02             	movzbl (%rdx),%eax
    8349:	84 c0                	test   %al,%al
    834b:	74 11                	je     835e <fwp_drop1+0x8e>
    834d:	3c 01                	cmp    $0x1,%al
    834f:	74 27                	je     8378 <fwp_drop1+0xa8>
    8351:	3c ff                	cmp    $0xff,%al
    8353:	0f 84 e7 00 00 00    	je     8440 <fwp_drop1+0x170>
    8359:	83 e8 01             	sub    $0x1,%eax
    835c:	88 02                	mov    %al,(%rdx)
    835e:	48 83 c4 18          	add    $0x18,%rsp
    8362:	c3                   	ret
    8363:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8368:	66 85 c0             	test   %ax,%ax
    836b:	74 d9                	je     8346 <fwp_drop1+0x76>
    836d:	48 83 c4 18          	add    $0x18,%rsp
    8371:	c3                   	ret
    8372:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8378:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    837f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8386:	48 89 f8             	mov    %rdi,%rax
    8389:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    838d:	48 29 c8             	sub    %rcx,%rax
    8390:	48 c1 e2 10          	shl    $0x10,%rdx
    8394:	48 39 d0             	cmp    %rdx,%rax
    8397:	73 71                	jae    840a <fwp_drop1+0x13a>
    8399:	49 89 c2             	mov    %rax,%r10
    839c:	49 c1 ea 10          	shr    $0x10,%r10
    83a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    83a4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    83a8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    83ac:	4d 85 d2             	test   %r10,%r10
    83af:	74 59                	je     840a <fwp_drop1+0x13a>
    83b1:	45 0f b6 19          	movzbl (%r9),%r11d
    83b5:	41 80 fb 02          	cmp    $0x2,%r11b
    83b9:	74 75                	je     8430 <fwp_drop1+0x160>
    83bb:	41 80 fb 01          	cmp    $0x1,%r11b
    83bf:	75 49                	jne    840a <fwp_drop1+0x13a>
    83c1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    83c5:	0f b7 c0             	movzwl %ax,%eax
    83c8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    83cc:	49 0f af c3          	imul   %r11,%rax
    83d0:	48 c1 e8 20          	shr    $0x20,%rax
    83d4:	4c 39 c8             	cmp    %r9,%rax
    83d7:	73 31                	jae    840a <fwp_drop1+0x13a>
    83d9:	49 01 c2             	add    %rax,%r10
    83dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    83e0:	75 28                	jne    840a <fwp_drop1+0x13a>
    83e2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    83e7:	e8 c4 d5 ff ff       	call   59b0 <fwp_mem_free>
    83ec:	48 8d 35 0d f4 05 00 	lea    0x5f40d(%rip),%rsi        # 67800 <fwp_heap>
    83f3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    83f8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    83ff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8406:	48 c1 e2 10          	shl    $0x10,%rdx
    840a:	4c 89 c0             	mov    %r8,%rax
    840d:	48 29 c8             	sub    %rcx,%rax
    8410:	48 39 d0             	cmp    %rdx,%rax
    8413:	0f 83 45 ff ff ff    	jae    835e <fwp_drop1+0x8e>
    8419:	4c 89 c7             	mov    %r8,%rdi
    841c:	e9 dc fe ff ff       	jmp    82fd <fwp_drop1+0x2d>
    8421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8428:	c3                   	ret
    8429:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8430:	66 85 c0             	test   %ax,%ax
    8433:	75 d5                	jne    840a <fwp_drop1+0x13a>
    8435:	eb a5                	jmp    83dc <fwp_drop1+0x10c>
    8437:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    843e:	00 00 
    8440:	48 89 d0             	mov    %rdx,%rax
    8443:	48 c1 e8 11          	shr    $0x11,%rax
    8447:	48 31 d0             	xor    %rdx,%rax
    844a:	48 89 c1             	mov    %rax,%rcx
    844d:	48 c1 e9 09          	shr    $0x9,%rcx
    8451:	48 31 c8             	xor    %rcx,%rax
    8454:	0f b6 c8             	movzbl %al,%ecx
    8457:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    845e:	00 
    845f:	48 85 c0             	test   %rax,%rax
    8462:	75 25                	jne    8489 <fwp_drop1+0x1b9>
    8464:	eb 5e                	jmp    84c4 <fwp_drop1+0x1f4>
    8466:	0f 1f 40 00          	nopl   0x0(%rax)
    846a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8471:	00 00 00 00 
    8475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    847c:	00 00 00 00 
    8480:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8484:	48 85 c0             	test   %rax,%rax
    8487:	74 3b                	je     84c4 <fwp_drop1+0x1f4>
    8489:	48 89 c1             	mov    %rax,%rcx
    848c:	48 39 10             	cmp    %rdx,(%rax)
    848f:	75 ef                	jne    8480 <fwp_drop1+0x1b0>
    8491:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8495:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8499:	48 89 48 08          	mov    %rcx,0x8(%rax)
    849d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    84a4:	0f 85 b4 fe ff ff    	jne    835e <fwp_drop1+0x8e>
    84aa:	48 89 d7             	mov    %rdx,%rdi
    84ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    84b2:	e8 b9 d2 ff ff       	call   5770 <fwp_rc_forget_slot>
    84b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    84bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    84bf:	e9 9a fe ff ff       	jmp    835e <fwp_drop1+0x8e>
    84c4:	48 8d 3d dd 34 00 00 	lea    0x34dd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    84cb:	e8 40 bf ff ff       	call   4410 <fwp_trap>

00000000000084d0 <fwp_drop10>:
    84d0:	48 8b 0d 01 07 06 00 	mov    0x60701(%rip),%rcx        # 68bd8 <fwp_heap+0x13d8>
    84d7:	48 89 f8             	mov    %rdi,%rax
    84da:	48 2b 05 cf 06 06 00 	sub    0x606cf(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    84e1:	48 c1 e1 10          	shl    $0x10,%rcx
    84e5:	48 39 c8             	cmp    %rcx,%rax
    84e8:	0f 83 c2 01 00 00    	jae    86b0 <fwp_drop10+0x1e0>
    84ee:	48 83 ec 18          	sub    $0x18,%rsp
    84f2:	48 89 fa             	mov    %rdi,%rdx
    84f5:	48 8d 35 04 f3 05 00 	lea    0x5f304(%rip),%rsi        # 67800 <fwp_heap>
    84fc:	48 89 c1             	mov    %rax,%rcx
    84ff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8506:	48 c1 e9 10          	shr    $0x10,%rcx
    850a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    850e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8512:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8516:	48 85 c9             	test   %rcx,%rcx
    8519:	74 46                	je     8561 <fwp_drop10+0x91>
    851b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    851f:	41 80 f9 02          	cmp    $0x2,%r9b
    8523:	0f 84 d7 00 00 00    	je     8600 <fwp_drop10+0x130>
    8529:	41 80 f9 01          	cmp    $0x1,%r9b
    852d:	75 32                	jne    8561 <fwp_drop10+0x91>
    852f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    8533:	0f b7 c0             	movzwl %ax,%eax
    8536:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    8539:	49 0f af c1          	imul   %r9,%rax
    853d:	48 c1 e8 20          	shr    $0x20,%rax
    8541:	48 39 f8             	cmp    %rdi,%rax
    8544:	73 1b                	jae    8561 <fwp_drop10+0x91>
    8546:	48 01 c1             	add    %rax,%rcx
    8549:	0f b6 01             	movzbl (%rcx),%eax
    854c:	84 c0                	test   %al,%al
    854e:	74 11                	je     8561 <fwp_drop10+0x91>
    8550:	3c 01                	cmp    $0x1,%al
    8552:	74 1c                	je     8570 <fwp_drop10+0xa0>
    8554:	3c ff                	cmp    $0xff,%al
    8556:	0f 84 5c 01 00 00    	je     86b8 <fwp_drop10+0x1e8>
    855c:	83 e8 01             	sub    $0x1,%eax
    855f:	88 01                	mov    %al,(%rcx)
    8561:	48 83 c4 18          	add    $0x18,%rsp
    8565:	c3                   	ret
    8566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    856d:	00 00 00 
    8570:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8577:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    857e:	48 89 d0             	mov    %rdx,%rax
    8581:	49 89 d1             	mov    %rdx,%r9
    8584:	48 c1 e1 10          	shl    $0x10,%rcx
    8588:	48 29 f8             	sub    %rdi,%rax
    858b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    858f:	78 7f                	js     8610 <fwp_drop10+0x140>
    8591:	48 39 c8             	cmp    %rcx,%rax
    8594:	73 cb                	jae    8561 <fwp_drop10+0x91>
    8596:	48 89 c1             	mov    %rax,%rcx
    8599:	48 c1 e9 10          	shr    $0x10,%rcx
    859d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    85a1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    85a5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    85a9:	48 85 f6             	test   %rsi,%rsi
    85ac:	74 b3                	je     8561 <fwp_drop10+0x91>
    85ae:	0f b6 39             	movzbl (%rcx),%edi
    85b1:	40 80 ff 02          	cmp    $0x2,%dil
    85b5:	74 39                	je     85f0 <fwp_drop10+0x120>
    85b7:	40 80 ff 01          	cmp    $0x1,%dil
    85bb:	75 a4                	jne    8561 <fwp_drop10+0x91>
    85bd:	8b 79 18             	mov    0x18(%rcx),%edi
    85c0:	0f b7 c0             	movzwl %ax,%eax
    85c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    85c6:	48 0f af c7          	imul   %rdi,%rax
    85ca:	48 c1 e8 20          	shr    $0x20,%rax
    85ce:	48 39 c8             	cmp    %rcx,%rax
    85d1:	73 8e                	jae    8561 <fwp_drop10+0x91>
    85d3:	48 01 c6             	add    %rax,%rsi
    85d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    85d9:	75 86                	jne    8561 <fwp_drop10+0x91>
    85db:	48 89 d7             	mov    %rdx,%rdi
    85de:	48 83 c4 18          	add    $0x18,%rsp
    85e2:	e9 c9 d3 ff ff       	jmp    59b0 <fwp_mem_free>
    85e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ee:	00 00 
    85f0:	66 85 c0             	test   %ax,%ax
    85f3:	74 e1                	je     85d6 <fwp_drop10+0x106>
    85f5:	48 83 c4 18          	add    $0x18,%rsp
    85f9:	c3                   	ret
    85fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8600:	66 85 c0             	test   %ax,%ax
    8603:	0f 84 40 ff ff ff    	je     8549 <fwp_drop10+0x79>
    8609:	48 83 c4 18          	add    $0x18,%rsp
    860d:	c3                   	ret
    860e:	66 90                	xchg   %ax,%ax
    8610:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8614:	48 39 c8             	cmp    %rcx,%rax
    8617:	73 74                	jae    868d <fwp_drop10+0x1bd>
    8619:	49 89 c2             	mov    %rax,%r10
    861c:	49 c1 ea 10          	shr    $0x10,%r10
    8620:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8624:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8628:	4d 8b 50 20          	mov    0x20(%r8),%r10
    862c:	4d 85 d2             	test   %r10,%r10
    862f:	74 5c                	je     868d <fwp_drop10+0x1bd>
    8631:	45 0f b6 18          	movzbl (%r8),%r11d
    8635:	41 80 fb 02          	cmp    $0x2,%r11b
    8639:	74 6d                	je     86a8 <fwp_drop10+0x1d8>
    863b:	41 80 fb 01          	cmp    $0x1,%r11b
    863f:	75 4c                	jne    868d <fwp_drop10+0x1bd>
    8641:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8645:	0f b7 c0             	movzwl %ax,%eax
    8648:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    864c:	49 0f af c3          	imul   %r11,%rax
    8650:	48 c1 e8 20          	shr    $0x20,%rax
    8654:	4c 39 c0             	cmp    %r8,%rax
    8657:	73 34                	jae    868d <fwp_drop10+0x1bd>
    8659:	49 01 c2             	add    %rax,%r10
    865c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8660:	75 2b                	jne    868d <fwp_drop10+0x1bd>
    8662:	4c 89 cf             	mov    %r9,%rdi
    8665:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    866a:	e8 41 d3 ff ff       	call   59b0 <fwp_mem_free>
    866f:	48 8d 35 8a f1 05 00 	lea    0x5f18a(%rip),%rsi        # 67800 <fwp_heap>
    8676:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    867b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8682:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8689:	48 c1 e1 10          	shl    $0x10,%rcx
    868d:	48 89 d0             	mov    %rdx,%rax
    8690:	48 29 f8             	sub    %rdi,%rax
    8693:	48 39 c8             	cmp    %rcx,%rax
    8696:	0f 82 60 fe ff ff    	jb     84fc <fwp_drop10+0x2c>
    869c:	e9 c0 fe ff ff       	jmp    8561 <fwp_drop10+0x91>
    86a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    86a8:	66 85 c0             	test   %ax,%ax
    86ab:	75 e0                	jne    868d <fwp_drop10+0x1bd>
    86ad:	eb ad                	jmp    865c <fwp_drop10+0x18c>
    86af:	90                   	nop
    86b0:	c3                   	ret
    86b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    86b8:	48 89 c8             	mov    %rcx,%rax
    86bb:	48 c1 e8 11          	shr    $0x11,%rax
    86bf:	48 31 c8             	xor    %rcx,%rax
    86c2:	48 89 c2             	mov    %rax,%rdx
    86c5:	48 c1 ea 09          	shr    $0x9,%rdx
    86c9:	48 31 d0             	xor    %rdx,%rax
    86cc:	0f b6 d0             	movzbl %al,%edx
    86cf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    86d6:	00 
    86d7:	48 85 c0             	test   %rax,%rax
    86da:	75 0d                	jne    86e9 <fwp_drop10+0x219>
    86dc:	eb 46                	jmp    8724 <fwp_drop10+0x254>
    86de:	66 90                	xchg   %ax,%ax
    86e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    86e4:	48 85 c0             	test   %rax,%rax
    86e7:	74 3b                	je     8724 <fwp_drop10+0x254>
    86e9:	48 89 c2             	mov    %rax,%rdx
    86ec:	48 39 08             	cmp    %rcx,(%rax)
    86ef:	75 ef                	jne    86e0 <fwp_drop10+0x210>
    86f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    86f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    86f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    86fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8704:	0f 85 57 fe ff ff    	jne    8561 <fwp_drop10+0x91>
    870a:	48 89 cf             	mov    %rcx,%rdi
    870d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8712:	e8 59 d0 ff ff       	call   5770 <fwp_rc_forget_slot>
    8717:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    871c:	c6 01 fe             	movb   $0xfe,(%rcx)
    871f:	e9 3d fe ff ff       	jmp    8561 <fwp_drop10+0x91>
    8724:	48 8d 3d 7d 32 00 00 	lea    0x327d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    872b:	e8 e0 bc ff ff       	call   4410 <fwp_trap>

0000000000008730 <f37>:
    8730:	41 57                	push   %r15
    8732:	41 56                	push   %r14
    8734:	41 55                	push   %r13
    8736:	41 54                	push   %r12
    8738:	55                   	push   %rbp
    8739:	53                   	push   %rbx
    873a:	48 83 ec 48          	sub    $0x48,%rsp
    873e:	48 8b 15 93 04 06 00 	mov    0x60493(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    8745:	48 89 3c 24          	mov    %rdi,(%rsp)
    8749:	48 c1 e2 10          	shl    $0x10,%rdx
    874d:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8754:	00 00 
    8756:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    875b:	48 8b 0d 4e 04 06 00 	mov    0x6044e(%rip),%rcx        # 68bb0 <fwp_heap+0x13b0>
    8762:	48 85 ff             	test   %rdi,%rdi
    8765:	0f 84 2f 03 00 00    	je     8a9a <f37+0x36a>
    876b:	48 8b 04 24          	mov    (%rsp),%rax
    876f:	48 8b 40 10          	mov    0x10(%rax),%rax
    8773:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8778:	48 29 c8             	sub    %rcx,%rax
    877b:	48 39 d0             	cmp    %rdx,%rax
    877e:	0f 83 fc 02 00 00    	jae    8a80 <f37+0x350>
    8784:	48 89 c2             	mov    %rax,%rdx
    8787:	48 c1 ea 10          	shr    $0x10,%rdx
    878b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    878f:	48 8b 15 62 04 06 00 	mov    0x60462(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    8796:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    879a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    879e:	48 85 ff             	test   %rdi,%rdi
    87a1:	0f 84 d9 02 00 00    	je     8a80 <f37+0x350>
    87a7:	0f b6 0a             	movzbl (%rdx),%ecx
    87aa:	80 f9 02             	cmp    $0x2,%cl
    87ad:	0f 84 65 02 00 00    	je     8a18 <f37+0x2e8>
    87b3:	80 f9 01             	cmp    $0x1,%cl
    87b6:	75 24                	jne    87dc <f37+0xac>
    87b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87bb:	0f b7 c0             	movzwl %ax,%eax
    87be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87c1:	48 0f af c1          	imul   %rcx,%rax
    87c5:	48 c1 e8 20          	shr    $0x20,%rax
    87c9:	48 39 d0             	cmp    %rdx,%rax
    87cc:	73 0e                	jae    87dc <f37+0xac>
    87ce:	48 01 c7             	add    %rax,%rdi
    87d1:	0f b6 07             	movzbl (%rdi),%eax
    87d4:	84 c0                	test   %al,%al
    87d6:	0f 85 54 02 00 00    	jne    8a30 <f37+0x300>
    87dc:	48 8b 04 24          	mov    (%rsp),%rax
    87e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87e4:	ba 01 00 00 00       	mov    $0x1,%edx
    87e9:	48 85 c0             	test   %rax,%rax
    87ec:	74 0f                	je     87fd <f37+0xcd>
    87ee:	66 90                	xchg   %ax,%ax
    87f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87f4:	48 83 c2 01          	add    $0x1,%rdx
    87f8:	48 85 c0             	test   %rax,%rax
    87fb:	75 f3                	jne    87f0 <f37+0xc0>
    87fd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8802:	48 85 c0             	test   %rax,%rax
    8805:	0f 84 a5 02 00 00    	je     8ab0 <f37+0x380>
    880b:	31 db                	xor    %ebx,%ebx
    880d:	0f 1f 00             	nopl   (%rax)
    8810:	48 8b 40 10          	mov    0x10(%rax),%rax
    8814:	48 83 c3 01          	add    $0x1,%rbx
    8818:	48 85 c0             	test   %rax,%rax
    881b:	75 f3                	jne    8810 <f37+0xe0>
    881d:	48 39 d3             	cmp    %rdx,%rbx
    8820:	48 0f 47 da          	cmova  %rdx,%rbx
    8824:	48 89 d8             	mov    %rbx,%rax
    8827:	48 c1 e8 3c          	shr    $0x3c,%rax
    882b:	0f 85 a1 03 00 00    	jne    8bd2 <f37+0x4a2>
    8831:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8835:	be 02 00 00 00       	mov    $0x2,%esi
    883a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8841:	00 
    8842:	e8 69 d6 ff ff       	call   5eb0 <fwp_heap_alloc>
    8847:	48 89 28             	mov    %rbp,(%rax)
    884a:	48 8b 15 87 03 06 00 	mov    0x60387(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    8851:	49 89 c5             	mov    %rax,%r13
    8854:	48 2b 05 55 03 06 00 	sub    0x60355(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    885b:	48 c1 e2 10          	shl    $0x10,%rdx
    885f:	48 39 d0             	cmp    %rdx,%rax
    8862:	73 57                	jae    88bb <f37+0x18b>
    8864:	48 89 c2             	mov    %rax,%rdx
    8867:	48 c1 ea 10          	shr    $0x10,%rdx
    886b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    886f:	48 8b 15 82 03 06 00 	mov    0x60382(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    8876:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    887a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    887e:	48 85 ed             	test   %rbp,%rbp
    8881:	74 38                	je     88bb <f37+0x18b>
    8883:	0f b6 0a             	movzbl (%rdx),%ecx
    8886:	80 f9 02             	cmp    $0x2,%cl
    8889:	0f 84 e1 01 00 00    	je     8a70 <f37+0x340>
    888f:	80 f9 01             	cmp    $0x1,%cl
    8892:	75 27                	jne    88bb <f37+0x18b>
    8894:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8897:	0f b7 c0             	movzwl %ax,%eax
    889a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    889d:	48 0f af c1          	imul   %rcx,%rax
    88a1:	48 c1 e8 20          	shr    $0x20,%rax
    88a5:	48 39 d0             	cmp    %rdx,%rax
    88a8:	73 11                	jae    88bb <f37+0x18b>
    88aa:	48 01 c5             	add    %rax,%rbp
    88ad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    88b1:	0f 84 6d 02 00 00    	je     8b24 <f37+0x3f4>
    88b7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    88bb:	48 85 db             	test   %rbx,%rbx
    88be:	74 74                	je     8934 <f37+0x204>
    88c0:	48 c1 e3 04          	shl    $0x4,%rbx
    88c4:	4c 8b 34 24          	mov    (%rsp),%r14
    88c8:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    88cd:	4c 89 ed             	mov    %r13,%rbp
    88d0:	4c 01 eb             	add    %r13,%rbx
    88d3:	66 90                	xchg   %ax,%ax
    88d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88dc:	00 00 00 00 
    88e0:	49 8b 46 08          	mov    0x8(%r14),%rax
    88e4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    88e8:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    88ed:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    88f4:	ff ff 
    88f6:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    88fd:	00 00 
    88ff:	48 83 c5 10          	add    $0x10,%rbp
    8903:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8908:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    890c:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8910:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    8915:	e8 56 dd ff ff       	call   6670 <w120>
    891a:	66 48 0f 6e d0       	movq   %rax,%xmm2
    891f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8923:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8927:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    892b:	4d 8b 76 10          	mov    0x10(%r14),%r14
    892f:	48 39 dd             	cmp    %rbx,%rbp
    8932:	75 ac                	jne    88e0 <f37+0x1b0>
    8934:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8939:	e8 82 ed ff ff       	call   76c0 <fwp_drop4>
    893e:	48 8b 3c 24          	mov    (%rsp),%rdi
    8942:	e8 79 ed ff ff       	call   76c0 <fwp_drop4>
    8947:	4c 89 ef             	mov    %r13,%rdi
    894a:	e8 71 e4 ff ff       	call   6dc0 <w176.constprop.0>
    894f:	4c 89 ef             	mov    %r13,%rdi
    8952:	48 89 c3             	mov    %rax,%rbx
    8955:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    895a:	e8 71 fb ff ff       	call   84d0 <fwp_drop10>
    895f:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    8964:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8969:	31 ff                	xor    %edi,%edi
    896b:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    8970:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8974:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    8979:	e8 22 d7 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    897e:	48 8b 15 53 02 06 00 	mov    0x60253(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    8985:	48 89 c5             	mov    %rax,%rbp
    8988:	48 2b 05 21 02 06 00 	sub    0x60221(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    898f:	48 c1 e2 10          	shl    $0x10,%rdx
    8993:	48 39 d0             	cmp    %rdx,%rax
    8996:	73 55                	jae    89ed <f37+0x2bd>
    8998:	48 89 c2             	mov    %rax,%rdx
    899b:	48 c1 ea 10          	shr    $0x10,%rdx
    899f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89a3:	48 8b 15 4e 02 06 00 	mov    0x6024e(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    89aa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89ae:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    89b2:	48 85 db             	test   %rbx,%rbx
    89b5:	74 36                	je     89ed <f37+0x2bd>
    89b7:	0f b6 0a             	movzbl (%rdx),%ecx
    89ba:	80 f9 02             	cmp    $0x2,%cl
    89bd:	0f 84 9d 00 00 00    	je     8a60 <f37+0x330>
    89c3:	80 f9 01             	cmp    $0x1,%cl
    89c6:	75 25                	jne    89ed <f37+0x2bd>
    89c8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    89cb:	0f b7 c0             	movzwl %ax,%eax
    89ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89d1:	48 0f af c1          	imul   %rcx,%rax
    89d5:	48 c1 e8 20          	shr    $0x20,%rax
    89d9:	48 39 d0             	cmp    %rdx,%rax
    89dc:	73 0f                	jae    89ed <f37+0x2bd>
    89de:	48 01 c3             	add    %rax,%rbx
    89e1:	80 3b ff             	cmpb   $0xff,(%rbx)
    89e4:	0f 84 2d 01 00 00    	je     8b17 <f37+0x3e7>
    89ea:	c6 03 01             	movb   $0x1,(%rbx)
    89ed:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    89f2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89f9:	00 00 
    89fb:	0f 85 dd 01 00 00    	jne    8bde <f37+0x4ae>
    8a01:	48 83 c4 48          	add    $0x48,%rsp
    8a05:	48 89 e8             	mov    %rbp,%rax
    8a08:	5b                   	pop    %rbx
    8a09:	5d                   	pop    %rbp
    8a0a:	41 5c                	pop    %r12
    8a0c:	41 5d                	pop    %r13
    8a0e:	41 5e                	pop    %r14
    8a10:	41 5f                	pop    %r15
    8a12:	c3                   	ret
    8a13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a18:	66 85 c0             	test   %ax,%ax
    8a1b:	0f 85 bb fd ff ff    	jne    87dc <f37+0xac>
    8a21:	0f b6 07             	movzbl (%rdi),%eax
    8a24:	84 c0                	test   %al,%al
    8a26:	0f 84 b0 fd ff ff    	je     87dc <f37+0xac>
    8a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a30:	8b 15 92 0a 06 00    	mov    0x60a92(%rip),%edx        # 694c8 <iteration_active>
    8a36:	85 d2                	test   %edx,%edx
    8a38:	75 56                	jne    8a90 <f37+0x360>
    8a3a:	3c fd                	cmp    $0xfd,%al
    8a3c:	0f 87 57 01 00 00    	ja     8b99 <f37+0x469>
    8a42:	83 c0 01             	add    $0x1,%eax
    8a45:	88 07                	mov    %al,(%rdi)
    8a47:	31 d2                	xor    %edx,%edx
    8a49:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    8a4e:	0f 85 88 fd ff ff    	jne    87dc <f37+0xac>
    8a54:	e9 a4 fd ff ff       	jmp    87fd <f37+0xcd>
    8a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a60:	66 85 c0             	test   %ax,%ax
    8a63:	75 88                	jne    89ed <f37+0x2bd>
    8a65:	e9 77 ff ff ff       	jmp    89e1 <f37+0x2b1>
    8a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a70:	66 85 c0             	test   %ax,%ax
    8a73:	0f 85 42 fe ff ff    	jne    88bb <f37+0x18b>
    8a79:	e9 2f fe ff ff       	jmp    88ad <f37+0x17d>
    8a7e:	66 90                	xchg   %ax,%ax
    8a80:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8a85:	e9 5a fd ff ff       	jmp    87e4 <f37+0xb4>
    8a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a90:	48 83 05 18 0a 06 00 	addq   $0x1,0x60a18(%rip)        # 694b0 <iteration_retains>
    8a97:	01 
    8a98:	eb a0                	jmp    8a3a <f37+0x30a>
    8a9a:	48 f7 d9             	neg    %rcx
    8a9d:	48 39 d1             	cmp    %rdx,%rcx
    8aa0:	0f 82 8b 00 00 00    	jb     8b31 <f37+0x401>
    8aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8aad:	00 00 00 
    8ab0:	be 02 00 00 00       	mov    $0x2,%esi
    8ab5:	bf 08 00 00 00       	mov    $0x8,%edi
    8aba:	e8 f1 d3 ff ff       	call   5eb0 <fwp_heap_alloc>
    8abf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8ac6:	48 8b 15 0b 01 06 00 	mov    0x6010b(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    8acd:	49 89 c5             	mov    %rax,%r13
    8ad0:	48 2b 05 d9 00 06 00 	sub    0x600d9(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    8ad7:	48 c1 e2 10          	shl    $0x10,%rdx
    8adb:	48 39 d0             	cmp    %rdx,%rax
    8ade:	0f 83 bf 00 00 00    	jae    8ba3 <f37+0x473>
    8ae4:	48 89 c2             	mov    %rax,%rdx
    8ae7:	48 c1 ea 10          	shr    $0x10,%rdx
    8aeb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8aef:	48 8b 15 02 01 06 00 	mov    0x60102(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    8af6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8afa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8afe:	48 85 ed             	test   %rbp,%rbp
    8b01:	0f 84 9c 00 00 00    	je     8ba3 <f37+0x473>
    8b07:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8b0e:	00 00 
    8b10:	31 db                	xor    %ebx,%ebx
    8b12:	e9 6c fd ff ff       	jmp    8883 <f37+0x153>
    8b17:	48 89 df             	mov    %rbx,%rdi
    8b1a:	e8 51 cc ff ff       	call   5770 <fwp_rc_forget_slot>
    8b1f:	e9 c6 fe ff ff       	jmp    89ea <f37+0x2ba>
    8b24:	48 89 ef             	mov    %rbp,%rdi
    8b27:	e8 44 cc ff ff       	call   5770 <fwp_rc_forget_slot>
    8b2c:	e9 86 fd ff ff       	jmp    88b7 <f37+0x187>
    8b31:	48 89 c8             	mov    %rcx,%rax
    8b34:	48 c1 e8 10          	shr    $0x10,%rax
    8b38:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8b3c:	48 8b 05 b5 00 06 00 	mov    0x600b5(%rip),%rax        # 68bf8 <fwp_heap+0x13f8>
    8b43:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8b47:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8b4b:	48 85 ff             	test   %rdi,%rdi
    8b4e:	0f 84 5c ff ff ff    	je     8ab0 <f37+0x380>
    8b54:	0f b6 02             	movzbl (%rdx),%eax
    8b57:	3c 02                	cmp    $0x2,%al
    8b59:	74 56                	je     8bb1 <f37+0x481>
    8b5b:	3c 01                	cmp    $0x1,%al
    8b5d:	0f 85 4d ff ff ff    	jne    8ab0 <f37+0x380>
    8b63:	0f b7 c1             	movzwl %cx,%eax
    8b66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b6c:	48 0f af c1          	imul   %rcx,%rax
    8b70:	48 c1 e8 20          	shr    $0x20,%rax
    8b74:	48 39 d0             	cmp    %rdx,%rax
    8b77:	0f 83 33 ff ff ff    	jae    8ab0 <f37+0x380>
    8b7d:	48 01 c7             	add    %rax,%rdi
    8b80:	0f b6 07             	movzbl (%rdi),%eax
    8b83:	84 c0                	test   %al,%al
    8b85:	0f 84 25 ff ff ff    	je     8ab0 <f37+0x380>
    8b8b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8b92:	00 00 
    8b94:	e9 97 fe ff ff       	jmp    8a30 <f37+0x300>
    8b99:	e8 b2 ca ff ff       	call   5650 <fwp_rc_wide_dup>
    8b9e:	e9 a4 fe ff ff       	jmp    8a47 <f37+0x317>
    8ba3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8baa:	00 00 
    8bac:	e9 83 fd ff ff       	jmp    8934 <f37+0x204>
    8bb1:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8bb7:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8bbc:	0f 85 ee fe ff ff    	jne    8ab0 <f37+0x380>
    8bc2:	0f b6 07             	movzbl (%rdi),%eax
    8bc5:	84 c0                	test   %al,%al
    8bc7:	0f 85 63 fe ff ff    	jne    8a30 <f37+0x300>
    8bcd:	e9 de fe ff ff       	jmp    8ab0 <f37+0x380>
    8bd2:	48 8d 3d 14 26 00 00 	lea    0x2614(%rip),%rdi        # b1ed <_IO_stdin_used+0x1ed>
    8bd9:	e8 32 b8 ff ff       	call   4410 <fwp_trap>
    8bde:	e8 5d a8 ff ff       	call   3440 <__stack_chk_fail@plt>
    8be3:	66 90                	xchg   %ax,%ax
    8be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bec:	00 00 00 00 

0000000000008bf0 <fwp_owned_entry37>:
    8bf0:	f3 0f 1e fa          	endbr64
    8bf4:	48 8b 3f             	mov    (%rdi),%rdi
    8bf7:	e9 34 fb ff ff       	jmp    8730 <f37>
    8bfc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008c00 <e37>:
    8c00:	f3 0f 1e fa          	endbr64
    8c04:	53                   	push   %rbx
    8c05:	48 8b 1f             	mov    (%rdi),%rbx
    8c08:	48 89 df             	mov    %rbx,%rdi
    8c0b:	e8 60 e2 ff ff       	call   6e70 <fwp_rc_share>
    8c10:	48 89 df             	mov    %rbx,%rdi
    8c13:	e8 18 fb ff ff       	call   8730 <f37>
    8c18:	48 89 c3             	mov    %rax,%rbx
    8c1b:	48 89 c7             	mov    %rax,%rdi
    8c1e:	e8 4d e2 ff ff       	call   6e70 <fwp_rc_share>
    8c23:	48 89 d8             	mov    %rbx,%rax
    8c26:	5b                   	pop    %rbx
    8c27:	c3                   	ret
    8c28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c2f:	00 

0000000000008c30 <fwp_write>:
    8c30:	41 57                	push   %r15
    8c32:	41 56                	push   %r14
    8c34:	41 55                	push   %r13
    8c36:	41 54                	push   %r12
    8c38:	55                   	push   %rbp
    8c39:	53                   	push   %rbx
    8c3a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8c41:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8c48:	00 00 
    8c4a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8c51:	00 
    8c52:	49 89 d4             	mov    %rdx,%r12
    8c55:	8b 12                	mov    (%rdx),%edx
    8c57:	83 fa 19             	cmp    $0x19,%edx
    8c5a:	77 6a                	ja     8cc6 <fwp_write+0x96>
    8c5c:	48 89 f5             	mov    %rsi,%rbp
    8c5f:	89 d0                	mov    %edx,%eax
    8c61:	89 ce                	mov    %ecx,%esi
    8c63:	48 89 fb             	mov    %rdi,%rbx
    8c66:	48 8d 0d 93 2f 00 00 	lea    0x2f93(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    8c6d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8c71:	48 01 c8             	add    %rcx,%rax
    8c74:	3e ff e0             	notrack jmp *%rax
    8c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c7e:	00 00 
    8c80:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8c84:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8c88:	48 89 ca             	mov    %rcx,%rdx
    8c8b:	48 85 c9             	test   %rcx,%rcx
    8c8e:	0f 88 9c 0c 00 00    	js     9930 <fwp_write+0xd00>
    8c94:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c9b:	00 
    8c9c:	48 89 c6             	mov    %rax,%rsi
    8c9f:	4c 89 e7             	mov    %r12,%rdi
    8ca2:	e8 59 ad ff ff       	call   3a00 <fwp_fmt_u128>
    8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cae:	00 00 
    8cb0:	4c 89 e7             	mov    %r12,%rdi
    8cb3:	e8 78 a7 ff ff       	call   3430 <strlen@plt>
    8cb8:	4c 89 e6             	mov    %r12,%rsi
    8cbb:	48 89 df             	mov    %rbx,%rdi
    8cbe:	48 89 c2             	mov    %rax,%rdx
    8cc1:	e8 ea b3 ff ff       	call   40b0 <buf_put>
    8cc6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ccd:	00 
    8cce:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8cd5:	00 00 
    8cd7:	0f 85 28 04 00 00    	jne    9105 <fwp_write+0x4d5>
    8cdd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8ce4:	5b                   	pop    %rbx
    8ce5:	5d                   	pop    %rbp
    8ce6:	41 5c                	pop    %r12
    8ce8:	41 5d                	pop    %r13
    8cea:	41 5e                	pop    %r14
    8cec:	41 5f                	pop    %r15
    8cee:	c3                   	ret
    8cef:	90                   	nop
    8cf0:	49 89 e9             	mov    %rbp,%r9
    8cf3:	4c 8d 05 1d 25 00 00 	lea    0x251d(%rip),%r8        # b217 <_IO_stdin_used+0x217>
    8cfa:	b9 00 02 00 00       	mov    $0x200,%ecx
    8cff:	ba 02 00 00 00       	mov    $0x2,%edx
    8d04:	be 00 02 00 00       	mov    $0x200,%esi
    8d09:	31 c0                	xor    %eax,%eax
    8d0b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d12:	00 
    8d13:	e8 78 a6 ff ff       	call   3390 <__snprintf_chk@plt>
    8d18:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d1f:	00 
    8d20:	e8 0b a7 ff ff       	call   3430 <strlen@plt>
    8d25:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8d2c:	00 
    8d2d:	48 89 df             	mov    %rbx,%rdi
    8d30:	48 89 c2             	mov    %rax,%rdx
    8d33:	e8 78 b3 ff ff       	call   40b0 <buf_put>
    8d38:	eb 8c                	jmp    8cc6 <fwp_write+0x96>
    8d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d40:	49 89 e9             	mov    %rbp,%r9
    8d43:	4c 8d 05 c8 24 00 00 	lea    0x24c8(%rip),%r8        # b212 <_IO_stdin_used+0x212>
    8d4a:	eb ae                	jmp    8cfa <fwp_write+0xca>
    8d4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d50:	83 fa 13             	cmp    $0x13,%edx
    8d53:	48 8d 05 ae 24 00 00 	lea    0x24ae(%rip),%rax        # b208 <_IO_stdin_used+0x208>
    8d5a:	48 8d 35 ac 24 00 00 	lea    0x24ac(%rip),%rsi        # b20d <_IO_stdin_used+0x20d>
    8d61:	ba 04 00 00 00       	mov    $0x4,%edx
    8d66:	48 0f 44 f0          	cmove  %rax,%rsi
    8d6a:	45 31 ed             	xor    %r13d,%r13d
    8d6d:	e8 3e b3 ff ff       	call   40b0 <buf_put>
    8d72:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8d77:	0f 84 a3 08 00 00    	je     9620 <fwp_write+0x9f0>
    8d7d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8d82:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8d87:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d8c:	48 89 df             	mov    %rbx,%rdi
    8d8f:	49 0f 44 c5          	cmove  %r13,%rax
    8d93:	31 c9                	xor    %ecx,%ecx
    8d95:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    8d9a:	e8 91 fe ff ff       	call   8c30 <fwp_write>
    8d9f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8da4:	0f 84 6e 09 00 00    	je     9718 <fwp_write+0xae8>
    8daa:	49 83 c5 01          	add    $0x1,%r13
    8dae:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8db2:	0f 83 68 08 00 00    	jae    9620 <fwp_write+0x9f0>
    8db8:	ba 02 00 00 00       	mov    $0x2,%edx
    8dbd:	48 8d 35 93 24 00 00 	lea    0x2493(%rip),%rsi        # b257 <_IO_stdin_used+0x257>
    8dc4:	48 89 df             	mov    %rbx,%rdi
    8dc7:	e8 e4 b2 ff ff       	call   40b0 <buf_put>
    8dcc:	eb af                	jmp    8d7d <fwp_write+0x14d>
    8dce:	66 90                	xchg   %ax,%ax
    8dd0:	ba 06 00 00 00       	mov    $0x6,%edx
    8dd5:	48 8d 35 54 24 00 00 	lea    0x2454(%rip),%rsi        # b230 <_IO_stdin_used+0x230>
    8ddc:	48 83 c5 10          	add    $0x10,%rbp
    8de0:	e8 cb b2 ff ff       	call   40b0 <buf_put>
    8de5:	48 89 ef             	mov    %rbp,%rdi
    8de8:	e8 43 a6 ff ff       	call   3430 <strlen@plt>
    8ded:	48 89 ee             	mov    %rbp,%rsi
    8df0:	48 89 df             	mov    %rbx,%rdi
    8df3:	48 89 c2             	mov    %rax,%rdx
    8df6:	e8 b5 b2 ff ff       	call   40b0 <buf_put>
    8dfb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e00:	ba 01 00 00 00       	mov    $0x1,%edx
    8e05:	48 89 df             	mov    %rbx,%rdi
    8e08:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8e0d:	e8 9e b2 ff ff       	call   40b0 <buf_put>
    8e12:	e9 af fe ff ff       	jmp    8cc6 <fwp_write+0x96>
    8e17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e1e:	00 00 
    8e20:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e27:	00 
    8e28:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e2f:	00 00 
    8e31:	0f 85 ce 02 00 00    	jne    9105 <fwp_write+0x4d5>
    8e37:	ba 0a 00 00 00       	mov    $0xa,%edx
    8e3c:	48 8d 35 d9 23 00 00 	lea    0x23d9(%rip),%rsi        # b21c <_IO_stdin_used+0x21c>
    8e43:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8e4a:	48 89 df             	mov    %rbx,%rdi
    8e4d:	5b                   	pop    %rbx
    8e4e:	5d                   	pop    %rbp
    8e4f:	41 5c                	pop    %r12
    8e51:	41 5d                	pop    %r13
    8e53:	41 5e                	pop    %r14
    8e55:	41 5f                	pop    %r15
    8e57:	e9 54 b2 ff ff       	jmp    40b0 <buf_put>
    8e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e60:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8e65:	4d 85 ed             	test   %r13,%r13
    8e68:	0f 84 02 0c 00 00    	je     9a70 <fwp_write+0xe40>
    8e6e:	48 8d 35 ef 23 00 00 	lea    0x23ef(%rip),%rsi        # b264 <_IO_stdin_used+0x264>
    8e75:	4c 89 ef             	mov    %r13,%rdi
    8e78:	e8 93 a6 ff ff       	call   3510 <strcmp@plt>
    8e7d:	41 89 c1             	mov    %eax,%r9d
    8e80:	85 c0                	test   %eax,%eax
    8e82:	0f 84 6c 0c 00 00    	je     9af4 <fwp_write+0xec4>
    8e88:	4c 89 ef             	mov    %r13,%rdi
    8e8b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e90:	e8 9b a5 ff ff       	call   3430 <strlen@plt>
    8e95:	4c 89 ee             	mov    %r13,%rsi
    8e98:	48 89 df             	mov    %rbx,%rdi
    8e9b:	48 89 c2             	mov    %rax,%rdx
    8e9e:	e8 0d b2 ff ff       	call   40b0 <buf_put>
    8ea3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ea8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ead:	48 89 df             	mov    %rbx,%rdi
    8eb0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8eb5:	e8 f6 b1 ff ff       	call   40b0 <buf_put>
    8eba:	ba 01 00 00 00       	mov    $0x1,%edx
    8ebf:	4c 89 fe             	mov    %r15,%rsi
    8ec2:	48 89 df             	mov    %rbx,%rdi
    8ec5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8eca:	e8 e1 b1 ff ff       	call   40b0 <buf_put>
    8ecf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8ed4:	45 31 f6             	xor    %r14d,%r14d
    8ed7:	85 d2                	test   %edx,%edx
    8ed9:	0f 8e 81 0a 00 00    	jle    9960 <fwp_write+0xd30>
    8edf:	45 31 ed             	xor    %r13d,%r13d
    8ee2:	4d 85 ed             	test   %r13,%r13
    8ee5:	0f 85 75 07 00 00    	jne    9660 <fwp_write+0xa30>
    8eeb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8ef2:	00 
    8ef3:	45 85 f6             	test   %r14d,%r14d
    8ef6:	0f 84 84 07 00 00    	je     9680 <fwp_write+0xa50>
    8efc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8f01:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8f06:	48 89 df             	mov    %rbx,%rdi
    8f09:	49 83 c5 01          	add    $0x1,%r13
    8f0d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8f11:	31 c9                	xor    %ecx,%ecx
    8f13:	e8 18 fd ff ff       	call   8c30 <fwp_write>
    8f18:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8f1d:	7f c3                	jg     8ee2 <fwp_write+0x2b2>
    8f1f:	45 85 f6             	test   %r14d,%r14d
    8f22:	0f 84 38 0a 00 00    	je     9960 <fwp_write+0xd30>
    8f28:	b8 29 00 00 00       	mov    $0x29,%eax
    8f2d:	ba 01 00 00 00       	mov    $0x1,%edx
    8f32:	4c 89 fe             	mov    %r15,%rsi
    8f35:	48 89 df             	mov    %rbx,%rdi
    8f38:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8f3c:	e8 6f b1 ff ff       	call   40b0 <buf_put>
    8f41:	e9 80 fd ff ff       	jmp    8cc6 <fwp_write+0x96>
    8f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f4d:	00 00 00 
    8f50:	ba 01 00 00 00       	mov    $0x1,%edx
    8f55:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f5a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8f5f:	e8 4c b1 ff ff       	call   40b0 <buf_put>
    8f64:	48 85 ed             	test   %rbp,%rbp
    8f67:	0f 84 93 06 00 00    	je     9600 <fwp_write+0x9d0>
    8f6d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8f71:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f76:	31 c9                	xor    %ecx,%ecx
    8f78:	48 89 df             	mov    %rbx,%rdi
    8f7b:	e8 b0 fc ff ff       	call   8c30 <fwp_write>
    8f80:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8f84:	48 85 ed             	test   %rbp,%rbp
    8f87:	0f 84 73 06 00 00    	je     9600 <fwp_write+0x9d0>
    8f8d:	ba 02 00 00 00       	mov    $0x2,%edx
    8f92:	48 8d 35 be 22 00 00 	lea    0x22be(%rip),%rsi        # b257 <_IO_stdin_used+0x257>
    8f99:	48 89 df             	mov    %rbx,%rdi
    8f9c:	e8 0f b1 ff ff       	call   40b0 <buf_put>
    8fa1:	eb ca                	jmp    8f6d <fwp_write+0x33d>
    8fa3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8fa8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8fac:	85 f6                	test   %esi,%esi
    8fae:	0f 84 fc 07 00 00    	je     97b0 <fwp_write+0xb80>
    8fb4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8fbb:	00 
    8fbc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8fc3:	00 00 
    8fc5:	0f 85 3a 01 00 00    	jne    9105 <fwp_write+0x4d5>
    8fcb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8fcf:	4c 89 ea             	mov    %r13,%rdx
    8fd2:	e9 6c fe ff ff       	jmp    8e43 <fwp_write+0x213>
    8fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8fde:	00 00 
    8fe0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8fe5:	ba 01 00 00 00       	mov    $0x1,%edx
    8fea:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8fef:	48 89 ee             	mov    %rbp,%rsi
    8ff2:	e8 b9 b0 ff ff       	call   40b0 <buf_put>
    8ff7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8ffc:	4c 89 e7             	mov    %r12,%rdi
    8fff:	e8 2c a4 ff ff       	call   3430 <strlen@plt>
    9004:	4c 89 e6             	mov    %r12,%rsi
    9007:	48 89 df             	mov    %rbx,%rdi
    900a:	48 89 c2             	mov    %rax,%rdx
    900d:	e8 9e b0 ff ff       	call   40b0 <buf_put>
    9012:	ba 01 00 00 00       	mov    $0x1,%edx
    9017:	48 89 ee             	mov    %rbp,%rsi
    901a:	48 89 df             	mov    %rbx,%rdi
    901d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9022:	e8 89 b0 ff ff       	call   40b0 <buf_put>
    9027:	e9 9a fc ff ff       	jmp    8cc6 <fwp_write+0x96>
    902c:	0f 1f 40 00          	nopl   0x0(%rax)
    9030:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9035:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9039:	0f 8a 8e 0b 00 00    	jp     9bcd <fwp_write+0xf9d>
    903f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9043:	66 0f 54 05 e5 2c 00 	andpd  0x2ce5(%rip),%xmm0        # bd30 <msg.4+0xc0>
    904a:	00 
    904b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9050:	66 0f 2e 05 f8 2c 00 	ucomisd 0x2cf8(%rip),%xmm0        # bd50 <msg.4+0xe0>
    9057:	00 
    9058:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    905f:	00 
    9060:	0f 87 b2 09 00 00    	ja     9a18 <fwp_write+0xde8>
    9066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    906d:	00 00 00 
    9070:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9074:	89 ee                	mov    %ebp,%esi
    9076:	4c 89 e7             	mov    %r12,%rdi
    9079:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    907e:	e8 ad b6 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9083:	31 f6                	xor    %esi,%esi
    9085:	4c 89 e7             	mov    %r12,%rdi
    9088:	e8 63 a3 ff ff       	call   33f0 <strtod@plt>
    908d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9092:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9096:	7a 06                	jp     909e <fwp_write+0x46e>
    9098:	0f 84 e9 01 00 00    	je     9287 <fwp_write+0x657>
    909e:	83 c5 01             	add    $0x1,%ebp
    90a1:	83 fd 12             	cmp    $0x12,%ebp
    90a4:	75 ca                	jne    9070 <fwp_write+0x440>
    90a6:	be 11 00 00 00       	mov    $0x11,%esi
    90ab:	66 0f 28 c1          	movapd %xmm1,%xmm0
    90af:	4c 89 e7             	mov    %r12,%rdi
    90b2:	e8 79 b6 ff ff       	call   4730 <fwp_format_g.constprop.0>
    90b7:	e9 cb 01 00 00       	jmp    9287 <fwp_write+0x657>
    90bc:	0f 1f 40 00          	nopl   0x0(%rax)
    90c0:	48 83 fd 01          	cmp    $0x1,%rbp
    90c4:	0f 84 e6 08 00 00    	je     99b0 <fwp_write+0xd80>
    90ca:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    90ce:	b8 02 00 00 00       	mov    $0x2,%eax
    90d3:	ba 01 00 00 00       	mov    $0x1,%edx
    90d8:	48 0f 44 d0          	cmove  %rax,%rdx
    90dc:	48 8d 35 1d 21 00 00 	lea    0x211d(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    90e3:	48 8d 05 1b 21 00 00 	lea    0x211b(%rip),%rax        # b205 <_IO_stdin_used+0x205>
    90ea:	48 0f 44 f0          	cmove  %rax,%rsi
    90ee:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    90f5:	00 
    90f6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    90fd:	00 00 
    90ff:	0f 84 3e fd ff ff    	je     8e43 <fwp_write+0x213>
    9105:	e8 36 a3 ff ff       	call   3440 <__stack_chk_fail@plt>
    910a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9110:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9115:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    911a:	e8 d1 ae ff ff       	call   3ff0 <buf_grow>
    911f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9123:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9129:	4c 03 0b             	add    (%rbx),%r9
    912c:	66 45 89 11          	mov    %r10w,(%r9)
    9130:	45 85 e4             	test   %r12d,%r12d
    9133:	0f 8e 07 05 00 00    	jle    9640 <fwp_write+0xa10>
    9139:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9140:	55 55 55 
    9143:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9148:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    914f:	aa aa aa 
    9152:	49 83 c1 01          	add    $0x1,%r9
    9156:	eb 45                	jmp    919d <fwp_write+0x56d>
    9158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    915f:	00 
    9160:	be 01 00 00 00       	mov    $0x1,%esi
    9165:	b8 2d 00 00 00       	mov    $0x2d,%eax
    916a:	88 07                	mov    %al,(%rdi)
    916c:	48 89 e8             	mov    %rbp,%rax
    916f:	49 f7 e8             	imul   %r8
    9172:	48 89 e8             	mov    %rbp,%rax
    9175:	48 c1 f8 3f          	sar    $0x3f,%rax
    9179:	48 29 c2             	sub    %rax,%rdx
    917c:	48 85 c9             	test   %rcx,%rcx
    917f:	0f 95 c0             	setne  %al
    9182:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9186:	48 83 ef 01          	sub    $0x1,%rdi
    918a:	48 21 c5             	and    %rax,%rbp
    918d:	48 29 ea             	sub    %rbp,%rdx
    9190:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9194:	49 39 f9             	cmp    %rdi,%r9
    9197:	0f 84 a3 04 00 00    	je     9640 <fwp_write+0xa10>
    919d:	48 89 e8             	mov    %rbp,%rax
    91a0:	49 f7 e8             	imul   %r8
    91a3:	48 89 e8             	mov    %rbp,%rax
    91a6:	48 c1 f8 3f          	sar    $0x3f,%rax
    91aa:	48 89 d1             	mov    %rdx,%rcx
    91ad:	48 29 c1             	sub    %rax,%rcx
    91b0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    91b4:	48 89 e9             	mov    %rbp,%rcx
    91b7:	48 29 c1             	sub    %rax,%rcx
    91ba:	48 8d 41 03          	lea    0x3(%rcx),%rax
    91be:	49 f7 e2             	mul    %r10
    91c1:	b8 30 00 00 00       	mov    $0x30,%eax
    91c6:	48 89 d6             	mov    %rdx,%rsi
    91c9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    91cd:	48 d1 ee             	shr    $1,%rsi
    91d0:	48 01 f2             	add    %rsi,%rdx
    91d3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    91d7:	48 29 d6             	sub    %rdx,%rsi
    91da:	74 8e                	je     916a <fwp_write+0x53a>
    91dc:	48 83 fe 01          	cmp    $0x1,%rsi
    91e0:	0f 85 7a ff ff ff    	jne    9160 <fwp_write+0x530>
    91e6:	31 f6                	xor    %esi,%esi
    91e8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    91ed:	e9 78 ff ff ff       	jmp    916a <fwp_write+0x53a>
    91f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91f8:	66 0f 6e cd          	movd   %ebp,%xmm1
    91fc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    91ff:	0f 8a c8 09 00 00    	jp     9bcd <fwp_write+0xf9d>
    9205:	0f 28 c1             	movaps %xmm1,%xmm0
    9208:	0f 54 05 11 2b 00 00 	andps  0x2b11(%rip),%xmm0        # bd20 <msg.4+0xb0>
    920f:	0f 2e 05 ee 1d 00 00 	ucomiss 0x1dee(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    9216:	0f 87 24 08 00 00    	ja     9a40 <fwp_write+0xe10>
    921c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9220:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9226:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    922d:	00 
    922e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9232:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9237:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    923e:	00 00 
    9240:	44 89 ee             	mov    %r13d,%esi
    9243:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9248:	4c 89 e7             	mov    %r12,%rdi
    924b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9250:	e8 db b4 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9255:	31 f6                	xor    %esi,%esi
    9257:	4c 89 e7             	mov    %r12,%rdi
    925a:	e8 31 a2 ff ff       	call   3490 <strtof@plt>
    925f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9264:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9267:	7a 02                	jp     926b <fwp_write+0x63b>
    9269:	74 1c                	je     9287 <fwp_write+0x657>
    926b:	41 83 c5 01          	add    $0x1,%r13d
    926f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9273:	75 cb                	jne    9240 <fwp_write+0x610>
    9275:	be 09 00 00 00       	mov    $0x9,%esi
    927a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    927f:	4c 89 e7             	mov    %r12,%rdi
    9282:	e8 a9 b4 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9287:	4c 89 e7             	mov    %r12,%rdi
    928a:	e8 e1 ae ff ff       	call   4170 <fwp_finish_float>
    928f:	e9 1c fa ff ff       	jmp    8cb0 <fwp_write+0x80>
    9294:	0f 1f 40 00          	nopl   0x0(%rax)
    9298:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    929c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    92a0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    92a7:	00 
    92a8:	48 89 ef             	mov    %rbp,%rdi
    92ab:	e8 50 a7 ff ff       	call   3a00 <fwp_fmt_u128>
    92b0:	48 89 ef             	mov    %rbp,%rdi
    92b3:	e8 78 a1 ff ff       	call   3430 <strlen@plt>
    92b8:	48 89 ee             	mov    %rbp,%rsi
    92bb:	48 89 df             	mov    %rbx,%rdi
    92be:	48 89 c2             	mov    %rax,%rdx
    92c1:	e8 ea ad ff ff       	call   40b0 <buf_put>
    92c6:	e9 fb f9 ff ff       	jmp    8cc6 <fwp_write+0x96>
    92cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    92d0:	ba 06 00 00 00       	mov    $0x6,%edx
    92d5:	48 8d 35 7e 1f 00 00 	lea    0x1f7e(%rip),%rsi        # b25a <_IO_stdin_used+0x25a>
    92dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    92e2:	e8 c9 ad ff ff       	call   40b0 <buf_put>
    92e7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    92ee:	ff ff 7f 
    92f1:	48 23 55 00          	and    0x0(%rbp),%rdx
    92f5:	0f 84 86 02 00 00    	je     9581 <fwp_write+0x951>
    92fb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9300:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9304:	48 85 d2             	test   %rdx,%rdx
    9307:	0f 84 ae 00 00 00    	je     93bb <fwp_write+0x78b>
    930d:	8b 0a                	mov    (%rdx),%ecx
    930f:	83 f9 1c             	cmp    $0x1c,%ecx
    9312:	0f 84 58 06 00 00    	je     9970 <fwp_write+0xd40>
    9318:	83 f9 1b             	cmp    $0x1b,%ecx
    931b:	0f 87 9a 00 00 00    	ja     93bb <fwp_write+0x78b>
    9321:	be 01 00 00 00       	mov    $0x1,%esi
    9326:	48 d3 e6             	shl    %cl,%rsi
    9329:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    932f:	0f 85 4b 04 00 00    	jne    9780 <fwp_write+0xb50>
    9335:	f7 c6 84 04 00 00    	test   $0x484,%esi
    933b:	0f 85 0f 04 00 00    	jne    9750 <fwp_write+0xb20>
    9341:	83 e6 21             	and    $0x21,%esi
    9344:	74 75                	je     93bb <fwp_write+0x78b>
    9346:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    934b:	48 85 ff             	test   %rdi,%rdi
    934e:	79 07                	jns    9357 <fwp_write+0x727>
    9350:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9354:	4c 01 ee             	add    %r13,%rsi
    9357:	48 0f be 3e          	movsbq (%rsi),%rdi
    935b:	85 c9                	test   %ecx,%ecx
    935d:	40 0f b6 f7          	movzbl %dil,%esi
    9361:	48 0f 44 f7          	cmove  %rdi,%rsi
    9365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    936c:	00 00 00 00 
    9370:	31 c9                	xor    %ecx,%ecx
    9372:	48 89 df             	mov    %rbx,%rdi
    9375:	49 83 c5 01          	add    $0x1,%r13
    9379:	e8 b2 f8 ff ff       	call   8c30 <fwp_write>
    937e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9385:	ff ff 7f 
    9388:	48 23 55 00          	and    0x0(%rbp),%rdx
    938c:	49 39 d5             	cmp    %rdx,%r13
    938f:	0f 83 ec 01 00 00    	jae    9581 <fwp_write+0x951>
    9395:	ba 02 00 00 00       	mov    $0x2,%edx
    939a:	48 89 df             	mov    %rbx,%rdi
    939d:	48 8d 35 b3 1e 00 00 	lea    0x1eb3(%rip),%rsi        # b257 <_IO_stdin_used+0x257>
    93a4:	e8 07 ad ff ff       	call   40b0 <buf_put>
    93a9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    93ae:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    93b2:	48 85 d2             	test   %rdx,%rdx
    93b5:	0f 85 52 ff ff ff    	jne    930d <fwp_write+0x6dd>
    93bb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    93c0:	48 85 ff             	test   %rdi,%rdi
    93c3:	0f 88 cf 05 00 00    	js     9998 <fwp_write+0xd68>
    93c9:	48 8b 31             	mov    (%rcx),%rsi
    93cc:	eb a2                	jmp    9370 <fwp_write+0x740>
    93ce:	66 90                	xchg   %ax,%ax
    93d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    93d7:	00 
    93d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    93df:	00 00 
    93e1:	0f 85 1e fd ff ff    	jne    9105 <fwp_write+0x4d5>
    93e7:	ba 08 00 00 00       	mov    $0x8,%edx
    93ec:	48 8d 35 34 1e 00 00 	lea    0x1e34(%rip),%rsi        # b227 <_IO_stdin_used+0x227>
    93f3:	e9 4b fa ff ff       	jmp    8e43 <fwp_write+0x213>
    93f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93ff:	00 
    9400:	89 e8                	mov    %ebp,%eax
    9402:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9409:	76 03                	jbe    940e <fwp_write+0x7de>
    940b:	8b 45 00             	mov    0x0(%rbp),%eax
    940e:	41 89 c6             	mov    %eax,%r14d
    9411:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9416:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    941b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    941f:	4c 89 ef             	mov    %r13,%rdi
    9422:	e8 09 a0 ff ff       	call   3430 <strlen@plt>
    9427:	4c 89 ee             	mov    %r13,%rsi
    942a:	48 89 df             	mov    %rbx,%rdi
    942d:	48 89 c2             	mov    %rax,%rdx
    9430:	e8 7b ac ff ff       	call   40b0 <buf_put>
    9435:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    943a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    943e:	85 f6                	test   %esi,%esi
    9440:	0f 8e 80 f8 ff ff    	jle    8cc6 <fwp_write+0x96>
    9446:	45 31 ed             	xor    %r13d,%r13d
    9449:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    944e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9453:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9458:	ba 01 00 00 00       	mov    $0x1,%edx
    945d:	4c 89 fe             	mov    %r15,%rsi
    9460:	48 89 04 24          	mov    %rax,(%rsp)
    9464:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9469:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    946d:	48 89 df             	mov    %rbx,%rdi
    9470:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9474:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9479:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    947e:	e8 2d ac ff ff       	call   40b0 <buf_put>
    9483:	41 8b 06             	mov    (%r14),%eax
    9486:	83 f8 0e             	cmp    $0xe,%eax
    9489:	0f 84 71 02 00 00    	je     9700 <fwp_write+0xad0>
    948f:	83 f8 10             	cmp    $0x10,%eax
    9492:	0f 84 38 02 00 00    	je     96d0 <fwp_write+0xaa0>
    9498:	83 f8 0a             	cmp    $0xa,%eax
    949b:	0f 84 7f 04 00 00    	je     9920 <fwp_write+0xcf0>
    94a1:	0f 8f f9 00 00 00    	jg     95a0 <fwp_write+0x970>
    94a7:	83 f8 03             	cmp    $0x3,%eax
    94aa:	0f 8f 50 04 00 00    	jg     9900 <fwp_write+0xcd0>
    94b0:	85 c0                	test   %eax,%eax
    94b2:	78 10                	js     94c4 <fwp_write+0x894>
    94b4:	48 8b 04 24          	mov    (%rsp),%rax
    94b8:	48 c1 e8 3f          	shr    $0x3f,%rax
    94bc:	85 c0                	test   %eax,%eax
    94be:	0f 85 f9 00 00 00    	jne    95bd <fwp_write+0x98d>
    94c4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    94c9:	48 8b 34 24          	mov    (%rsp),%rsi
    94cd:	31 c9                	xor    %ecx,%ecx
    94cf:	48 89 df             	mov    %rbx,%rdi
    94d2:	e8 59 f7 ff ff       	call   8c30 <fwp_write>
    94d7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    94dc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    94e1:	49 83 c5 01          	add    $0x1,%r13
    94e5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    94e9:	0f 8f 5f ff ff ff    	jg     944e <fwp_write+0x81e>
    94ef:	e9 d2 f7 ff ff       	jmp    8cc6 <fwp_write+0x96>
    94f4:	0f 1f 40 00          	nopl   0x0(%rax)
    94f8:	ba 06 00 00 00       	mov    $0x6,%edx
    94fd:	48 8d 35 49 1d 00 00 	lea    0x1d49(%rip),%rsi        # b24d <_IO_stdin_used+0x24d>
    9504:	45 31 ed             	xor    %r13d,%r13d
    9507:	e8 a4 ab ff ff       	call   40b0 <buf_put>
    950c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9511:	75 19                	jne    952c <fwp_write+0x8fc>
    9513:	eb 6c                	jmp    9581 <fwp_write+0x951>
    9515:	0f 1f 00             	nopl   (%rax)
    9518:	ba 02 00 00 00       	mov    $0x2,%edx
    951d:	48 8d 35 33 1d 00 00 	lea    0x1d33(%rip),%rsi        # b257 <_IO_stdin_used+0x257>
    9524:	48 89 df             	mov    %rbx,%rdi
    9527:	e8 84 ab ff ff       	call   40b0 <buf_put>
    952c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9532:	b9 00 02 00 00       	mov    $0x200,%ecx
    9537:	31 c0                	xor    %eax,%eax
    9539:	49 83 c5 01          	add    $0x1,%r13
    953d:	4c 8d 05 10 1d 00 00 	lea    0x1d10(%rip),%r8        # b254 <_IO_stdin_used+0x254>
    9544:	ba 02 00 00 00       	mov    $0x2,%edx
    9549:	be 00 02 00 00       	mov    $0x200,%esi
    954e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9555:	00 
    9556:	e8 35 9e ff ff       	call   3390 <__snprintf_chk@plt>
    955b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9562:	00 
    9563:	e8 c8 9e ff ff       	call   3430 <strlen@plt>
    9568:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    956f:	00 
    9570:	48 89 df             	mov    %rbx,%rdi
    9573:	48 89 c2             	mov    %rax,%rdx
    9576:	e8 35 ab ff ff       	call   40b0 <buf_put>
    957b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    957f:	72 97                	jb     9518 <fwp_write+0x8e8>
    9581:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9586:	ba 01 00 00 00       	mov    $0x1,%edx
    958b:	48 89 df             	mov    %rbx,%rdi
    958e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9593:	e8 18 ab ff ff       	call   40b0 <buf_put>
    9598:	e9 29 f7 ff ff       	jmp    8cc6 <fwp_write+0x96>
    959d:	0f 1f 00             	nopl   (%rax)
    95a0:	83 f8 0b             	cmp    $0xb,%eax
    95a3:	0f 85 1b ff ff ff    	jne    94c4 <fwp_write+0x894>
    95a9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    95ae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    95b2:	83 e0 01             	and    $0x1,%eax
    95b5:	85 c0                	test   %eax,%eax
    95b7:	0f 84 07 ff ff ff    	je     94c4 <fwp_write+0x894>
    95bd:	4c 89 fe             	mov    %r15,%rsi
    95c0:	48 89 df             	mov    %rbx,%rdi
    95c3:	ba 01 00 00 00       	mov    $0x1,%edx
    95c8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    95cd:	e8 de aa ff ff       	call   40b0 <buf_put>
    95d2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    95d7:	48 8b 34 24          	mov    (%rsp),%rsi
    95db:	31 c9                	xor    %ecx,%ecx
    95dd:	48 89 df             	mov    %rbx,%rdi
    95e0:	e8 4b f6 ff ff       	call   8c30 <fwp_write>
    95e5:	ba 01 00 00 00       	mov    $0x1,%edx
    95ea:	4c 89 fe             	mov    %r15,%rsi
    95ed:	48 89 df             	mov    %rbx,%rdi
    95f0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    95f5:	e8 b6 aa ff ff       	call   40b0 <buf_put>
    95fa:	e9 d8 fe ff ff       	jmp    94d7 <fwp_write+0x8a7>
    95ff:	90                   	nop
    9600:	ba 01 00 00 00       	mov    $0x1,%edx
    9605:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    960a:	48 89 df             	mov    %rbx,%rdi
    960d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9612:	e8 99 aa ff ff       	call   40b0 <buf_put>
    9617:	e9 aa f6 ff ff       	jmp    8cc6 <fwp_write+0x96>
    961c:	0f 1f 40 00          	nopl   0x0(%rax)
    9620:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9625:	ba 01 00 00 00       	mov    $0x1,%edx
    962a:	48 89 df             	mov    %rbx,%rdi
    962d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9632:	e8 79 aa ff ff       	call   40b0 <buf_put>
    9637:	e9 8a f6 ff ff       	jmp    8cc6 <fwp_write+0x96>
    963c:	0f 1f 40 00          	nopl   0x0(%rax)
    9640:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9644:	48 8b 13             	mov    (%rbx),%rdx
    9647:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    964c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9650:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9654:	e9 6d f6 ff ff       	jmp    8cc6 <fwp_write+0x96>
    9659:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9660:	ba 02 00 00 00       	mov    $0x2,%edx
    9665:	48 8d 35 eb 1b 00 00 	lea    0x1beb(%rip),%rsi        # b257 <_IO_stdin_used+0x257>
    966c:	48 89 df             	mov    %rbx,%rdi
    966f:	e8 3c aa ff ff       	call   40b0 <buf_put>
    9674:	e9 72 f8 ff ff       	jmp    8eeb <fwp_write+0x2bb>
    9679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9680:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9685:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    968a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    968e:	48 89 f7             	mov    %rsi,%rdi
    9691:	48 89 34 24          	mov    %rsi,(%rsp)
    9695:	e8 96 9d ff ff       	call   3430 <strlen@plt>
    969a:	48 8b 34 24          	mov    (%rsp),%rsi
    969e:	48 89 df             	mov    %rbx,%rdi
    96a1:	48 89 c2             	mov    %rax,%rdx
    96a4:	e8 07 aa ff ff       	call   40b0 <buf_put>
    96a9:	ba 03 00 00 00       	mov    $0x3,%edx
    96ae:	48 8d 35 c5 1b 00 00 	lea    0x1bc5(%rip),%rsi        # b27a <_IO_stdin_used+0x27a>
    96b5:	48 89 df             	mov    %rbx,%rdi
    96b8:	e8 f3 a9 ff ff       	call   40b0 <buf_put>
    96bd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    96c2:	e9 35 f8 ff ff       	jmp    8efc <fwp_write+0x2cc>
    96c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96ce:	00 00 
    96d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    96d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    96d9:	48 85 ff             	test   %rdi,%rdi
    96dc:	0f 84 e2 fd ff ff    	je     94c4 <fwp_write+0x894>
    96e2:	48 8d 35 7b 1b 00 00 	lea    0x1b7b(%rip),%rsi        # b264 <_IO_stdin_used+0x264>
    96e9:	e8 22 9e ff ff       	call   3510 <strcmp@plt>
    96ee:	85 c0                	test   %eax,%eax
    96f0:	0f 95 c0             	setne  %al
    96f3:	0f b6 c0             	movzbl %al,%eax
    96f6:	e9 c1 fd ff ff       	jmp    94bc <fwp_write+0x88c>
    96fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9700:	31 c0                	xor    %eax,%eax
    9702:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9709:	00 
    970a:	0f 97 c0             	seta   %al
    970d:	e9 aa fd ff ff       	jmp    94bc <fwp_write+0x88c>
    9712:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9718:	48 89 df             	mov    %rbx,%rdi
    971b:	ba 02 00 00 00       	mov    $0x2,%edx
    9720:	48 8d 35 3a 1b 00 00 	lea    0x1b3a(%rip),%rsi        # b261 <_IO_stdin_used+0x261>
    9727:	e8 84 a9 ff ff       	call   40b0 <buf_put>
    972c:	4c 89 e8             	mov    %r13,%rax
    972f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9734:	31 c9                	xor    %ecx,%ecx
    9736:	48 c1 e0 04          	shl    $0x4,%rax
    973a:	48 89 df             	mov    %rbx,%rdi
    973d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9742:	e8 e9 f4 ff ff       	call   8c30 <fwp_write>
    9747:	e9 5e f6 ff ff       	jmp    8daa <fwp_write+0x17a>
    974c:	0f 1f 40 00          	nopl   0x0(%rax)
    9750:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9755:	48 85 ff             	test   %rdi,%rdi
    9758:	79 0c                	jns    9766 <fwp_write+0xb36>
    975a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9761:	00 
    9762:	48 03 75 10          	add    0x10(%rbp),%rsi
    9766:	48 63 3e             	movslq (%rsi),%rdi
    9769:	83 f9 02             	cmp    $0x2,%ecx
    976c:	89 fe                	mov    %edi,%esi
    976e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9772:	e9 f9 fb ff ff       	jmp    9370 <fwp_write+0x740>
    9777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    977e:	00 00 
    9780:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9785:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    978a:	48 85 ff             	test   %rdi,%rdi
    978d:	0f 88 0f 03 00 00    	js     9aa2 <fwp_write+0xe72>
    9793:	49 0f bf 38          	movswq (%r8),%rdi
    9797:	83 f9 01             	cmp    $0x1,%ecx
    979a:	0f b7 f7             	movzwl %di,%esi
    979d:	48 0f 44 f7          	cmove  %rdi,%rsi
    97a1:	e9 ca fb ff ff       	jmp    9370 <fwp_write+0x740>
    97a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    97ad:	00 00 00 
    97b0:	ba 01 00 00 00       	mov    $0x1,%edx
    97b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    97ba:	48 83 c5 08          	add    $0x8,%rbp
    97be:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    97c3:	e8 e8 a8 ff ff       	call   40b0 <buf_put>
    97c8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    97cd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    97d2:	4d 85 ed             	test   %r13,%r13
    97d5:	75 46                	jne    981d <fwp_write+0xbed>
    97d7:	e9 04 01 00 00       	jmp    98e0 <fwp_write+0xcb0>
    97dc:	0f 1f 40 00          	nopl   0x0(%rax)
    97e0:	41 80 f9 09          	cmp    $0x9,%r9b
    97e4:	0f 84 d6 00 00 00    	je     98c0 <fwp_write+0xc90>
    97ea:	41 80 f9 0a          	cmp    $0xa,%r9b
    97ee:	0f 85 9c 00 00 00    	jne    9890 <fwp_write+0xc60>
    97f4:	ba 02 00 00 00       	mov    $0x2,%edx
    97f9:	48 8d 35 3d 1a 00 00 	lea    0x1a3d(%rip),%rsi        # b23d <_IO_stdin_used+0x23d>
    9800:	48 89 df             	mov    %rbx,%rdi
    9803:	e8 a8 a8 ff ff       	call   40b0 <buf_put>
    9808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    980f:	00 
    9810:	48 83 c5 01          	add    $0x1,%rbp
    9814:	49 39 ec             	cmp    %rbp,%r12
    9817:	0f 84 c3 00 00 00    	je     98e0 <fwp_write+0xcb0>
    981d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9822:	41 80 f9 0d          	cmp    $0xd,%r9b
    9826:	74 28                	je     9850 <fwp_write+0xc20>
    9828:	7e b6                	jle    97e0 <fwp_write+0xbb0>
    982a:	41 80 f9 22          	cmp    $0x22,%r9b
    982e:	74 40                	je     9870 <fwp_write+0xc40>
    9830:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9834:	75 5a                	jne    9890 <fwp_write+0xc60>
    9836:	ba 02 00 00 00       	mov    $0x2,%edx
    983b:	48 8d 35 f8 19 00 00 	lea    0x19f8(%rip),%rsi        # b23a <_IO_stdin_used+0x23a>
    9842:	48 89 df             	mov    %rbx,%rdi
    9845:	e8 66 a8 ff ff       	call   40b0 <buf_put>
    984a:	eb c4                	jmp    9810 <fwp_write+0xbe0>
    984c:	0f 1f 40 00          	nopl   0x0(%rax)
    9850:	ba 02 00 00 00       	mov    $0x2,%edx
    9855:	48 8d 35 e7 19 00 00 	lea    0x19e7(%rip),%rsi        # b243 <_IO_stdin_used+0x243>
    985c:	48 89 df             	mov    %rbx,%rdi
    985f:	e8 4c a8 ff ff       	call   40b0 <buf_put>
    9864:	eb aa                	jmp    9810 <fwp_write+0xbe0>
    9866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    986d:	00 00 00 
    9870:	ba 02 00 00 00       	mov    $0x2,%edx
    9875:	48 8d 35 bb 19 00 00 	lea    0x19bb(%rip),%rsi        # b237 <_IO_stdin_used+0x237>
    987c:	48 89 df             	mov    %rbx,%rdi
    987f:	e8 2c a8 ff ff       	call   40b0 <buf_put>
    9884:	eb 8a                	jmp    9810 <fwp_write+0xbe0>
    9886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    988d:	00 00 00 
    9890:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9894:	0f 86 2e 01 00 00    	jbe    99c8 <fwp_write+0xd98>
    989a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    989e:	0f 84 24 01 00 00    	je     99c8 <fwp_write+0xd98>
    98a4:	ba 01 00 00 00       	mov    $0x1,%edx
    98a9:	4c 89 fe             	mov    %r15,%rsi
    98ac:	48 89 df             	mov    %rbx,%rdi
    98af:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    98b4:	e8 f7 a7 ff ff       	call   40b0 <buf_put>
    98b9:	e9 52 ff ff ff       	jmp    9810 <fwp_write+0xbe0>
    98be:	66 90                	xchg   %ax,%ax
    98c0:	ba 02 00 00 00       	mov    $0x2,%edx
    98c5:	48 8d 35 74 19 00 00 	lea    0x1974(%rip),%rsi        # b240 <_IO_stdin_used+0x240>
    98cc:	48 89 df             	mov    %rbx,%rdi
    98cf:	e8 dc a7 ff ff       	call   40b0 <buf_put>
    98d4:	e9 37 ff ff ff       	jmp    9810 <fwp_write+0xbe0>
    98d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    98e0:	ba 01 00 00 00       	mov    $0x1,%edx
    98e5:	4c 89 fe             	mov    %r15,%rsi
    98e8:	48 89 df             	mov    %rbx,%rdi
    98eb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    98f0:	e8 bb a7 ff ff       	call   40b0 <buf_put>
    98f5:	e9 cc f3 ff ff       	jmp    8cc6 <fwp_write+0x96>
    98fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9900:	83 f8 04             	cmp    $0x4,%eax
    9903:	0f 85 bb fb ff ff    	jne    94c4 <fwp_write+0x894>
    9909:	48 8b 04 24          	mov    (%rsp),%rax
    990d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9911:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9916:	48 c1 e8 3f          	shr    $0x3f,%rax
    991a:	e9 96 fc ff ff       	jmp    95b5 <fwp_write+0x985>
    991f:	90                   	nop
    9920:	8b 0c 24             	mov    (%rsp),%ecx
    9923:	31 c0                	xor    %eax,%eax
    9925:	85 c9                	test   %ecx,%ecx
    9927:	0f 98 c0             	sets   %al
    992a:	e9 86 fc ff ff       	jmp    95b5 <fwp_write+0x985>
    992f:	90                   	nop
    9930:	48 f7 d8             	neg    %rax
    9933:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    993a:	00 
    993b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9942:	2d 
    9943:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    994a:	00 
    994b:	48 83 d2 00          	adc    $0x0,%rdx
    994f:	48 89 c6             	mov    %rax,%rsi
    9952:	48 f7 da             	neg    %rdx
    9955:	e8 a6 a0 ff ff       	call   3a00 <fwp_fmt_u128>
    995a:	e9 51 f3 ff ff       	jmp    8cb0 <fwp_write+0x80>
    995f:	90                   	nop
    9960:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9965:	e9 c3 f5 ff ff       	jmp    8f2d <fwp_write+0x2fd>
    996a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9970:	4c 89 e9             	mov    %r13,%rcx
    9973:	48 c1 e1 04          	shl    $0x4,%rcx
    9977:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    997c:	48 85 ff             	test   %rdi,%rdi
    997f:	0f 89 eb f9 ff ff    	jns    9370 <fwp_write+0x740>
    9985:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9989:	48 89 ce             	mov    %rcx,%rsi
    998c:	e9 df f9 ff ff       	jmp    9370 <fwp_write+0x740>
    9991:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9998:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    999f:	00 
    99a0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    99a4:	e9 20 fa ff ff       	jmp    93c9 <fwp_write+0x799>
    99a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    99b0:	ba 02 00 00 00       	mov    $0x2,%edx
    99b5:	48 8d 35 46 18 00 00 	lea    0x1846(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    99bc:	e9 2d f7 ff ff       	jmp    90ee <fwp_write+0x4be>
    99c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    99c8:	4c 8d 05 77 18 00 00 	lea    0x1877(%rip),%r8        # b246 <_IO_stdin_used+0x246>
    99cf:	b9 10 00 00 00       	mov    $0x10,%ecx
    99d4:	31 c0                	xor    %eax,%eax
    99d6:	ba 02 00 00 00       	mov    $0x2,%edx
    99db:	be 10 00 00 00       	mov    $0x10,%esi
    99e0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    99e7:	00 
    99e8:	e8 a3 99 ff ff       	call   3390 <__snprintf_chk@plt>
    99ed:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    99f4:	00 
    99f5:	e8 36 9a ff ff       	call   3430 <strlen@plt>
    99fa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9a01:	00 
    9a02:	48 89 df             	mov    %rbx,%rdi
    9a05:	48 89 c2             	mov    %rax,%rdx
    9a08:	e8 a3 a6 ff ff       	call   40b0 <buf_put>
    9a0d:	e9 fe fd ff ff       	jmp    9810 <fwp_write+0xbe0>
    9a12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a18:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9a1c:	48 8d 35 d9 17 00 00 	lea    0x17d9(%rip),%rsi        # b1fc <_IO_stdin_used+0x1fc>
    9a23:	48 8d 05 d1 17 00 00 	lea    0x17d1(%rip),%rax        # b1fb <_IO_stdin_used+0x1fb>
    9a2a:	4c 89 e7             	mov    %r12,%rdi
    9a2d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9a31:	48 0f 46 f0          	cmovbe %rax,%rsi
    9a35:	e8 96 99 ff ff       	call   33d0 <strcpy@plt>
    9a3a:	e9 71 f2 ff ff       	jmp    8cb0 <fwp_write+0x80>
    9a3f:	90                   	nop
    9a40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9a44:	48 8d 35 b1 17 00 00 	lea    0x17b1(%rip),%rsi        # b1fc <_IO_stdin_used+0x1fc>
    9a4b:	48 8d 05 a9 17 00 00 	lea    0x17a9(%rip),%rax        # b1fb <_IO_stdin_used+0x1fb>
    9a52:	0f 2f c8             	comiss %xmm0,%xmm1
    9a55:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a5c:	00 
    9a5d:	4c 89 e7             	mov    %r12,%rdi
    9a60:	48 0f 46 f0          	cmovbe %rax,%rsi
    9a64:	e8 67 99 ff ff       	call   33d0 <strcpy@plt>
    9a69:	e9 42 f2 ff ff       	jmp    8cb0 <fwp_write+0x80>
    9a6e:	66 90                	xchg   %ax,%ax
    9a70:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9a75:	45 85 c0             	test   %r8d,%r8d
    9a78:	75 34                	jne    9aae <fwp_write+0xe7e>
    9a7a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a81:	00 
    9a82:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a89:	00 00 
    9a8b:	0f 85 74 f6 ff ff    	jne    9105 <fwp_write+0x4d5>
    9a91:	ba 02 00 00 00       	mov    $0x2,%edx
    9a96:	48 8d 35 da 17 00 00 	lea    0x17da(%rip),%rsi        # b277 <_IO_stdin_used+0x277>
    9a9d:	e9 a1 f3 ff ff       	jmp    8e43 <fwp_write+0x213>
    9aa2:	48 03 75 10          	add    0x10(%rbp),%rsi
    9aa6:	49 89 f0             	mov    %rsi,%r8
    9aa9:	e9 e5 fc ff ff       	jmp    9793 <fwp_write+0xb63>
    9aae:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9ab3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9ab8:	85 ff                	test   %edi,%edi
    9aba:	0f 84 fa f3 ff ff    	je     8eba <fwp_write+0x28a>
    9ac0:	ba 01 00 00 00       	mov    $0x1,%edx
    9ac5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9aca:	48 89 df             	mov    %rbx,%rdi
    9acd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9ad2:	e8 d9 a5 ff ff       	call   40b0 <buf_put>
    9ad7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    9adc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9ae1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9ae7:	85 c0                	test   %eax,%eax
    9ae9:	0f 8f f0 f3 ff ff    	jg     8edf <fwp_write+0x2af>
    9aef:	e9 34 f4 ff ff       	jmp    8f28 <fwp_write+0x2f8>
    9af4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9af8:	49 89 c5             	mov    %rax,%r13
    9afb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9b00:	49 89 c4             	mov    %rax,%r12
    9b03:	49 c1 fd 3f          	sar    $0x3f,%r13
    9b07:	4c 09 e8             	or     %r13,%rax
    9b0a:	0f 84 a7 00 00 00    	je     9bb7 <fwp_write+0xf87>
    9b10:	48 8d 2d a9 37 00 00 	lea    0x37a9(%rip),%rbp        # d2c0 <units.0>
    9b17:	4d 89 e7             	mov    %r12,%r15
    9b1a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9b1e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9b23:	4c 89 ff             	mov    %r15,%rdi
    9b26:	4c 89 ee             	mov    %r13,%rsi
    9b29:	44 89 0c 24          	mov    %r9d,(%rsp)
    9b2d:	48 99                	cqto
    9b2f:	48 89 d1             	mov    %rdx,%rcx
    9b32:	48 89 c2             	mov    %rax,%rdx
    9b35:	e8 46 10 00 00       	call   ab80 <__divmodti4>
    9b3a:	44 8b 0c 24          	mov    (%rsp),%r9d
    9b3e:	48 89 c1             	mov    %rax,%rcx
    9b41:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9b46:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    9b4b:	0f 84 94 00 00 00    	je     9be5 <fwp_write+0xfb5>
    9b51:	41 83 c1 01          	add    $0x1,%r9d
    9b55:	48 83 c5 10          	add    $0x10,%rbp
    9b59:	41 83 f9 05          	cmp    $0x5,%r9d
    9b5d:	75 bb                	jne    9b1a <fwp_write+0xeea>
    9b5f:	4d 85 ed             	test   %r13,%r13
    9b62:	79 53                	jns    9bb7 <fwp_write+0xf87>
    9b64:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b69:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9b6e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9b73:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9b78:	48 99                	cqto
    9b7a:	48 f7 d8             	neg    %rax
    9b7d:	48 83 d2 00          	adc    $0x0,%rdx
    9b81:	48 89 c6             	mov    %rax,%rsi
    9b84:	48 f7 da             	neg    %rdx
    9b87:	e8 74 9e ff ff       	call   3a00 <fwp_fmt_u128>
    9b8c:	49 89 e8             	mov    %rbp,%r8
    9b8f:	ba 00 02 00 00       	mov    $0x200,%edx
    9b94:	be 02 00 00 00       	mov    $0x2,%esi
    9b99:	31 c0                	xor    %eax,%eax
    9b9b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ba2:	00 
    9ba3:	48 8d 0d c8 16 00 00 	lea    0x16c8(%rip),%rcx        # b272 <_IO_stdin_used+0x272>
    9baa:	4c 89 e7             	mov    %r12,%rdi
    9bad:	e8 ee 9a ff ff       	call   36a0 <__sprintf_chk@plt>
    9bb2:	e9 f9 f0 ff ff       	jmp    8cb0 <fwp_write+0x80>
    9bb7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9bbc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9bc1:	31 d2                	xor    %edx,%edx
    9bc3:	48 89 ef             	mov    %rbp,%rdi
    9bc6:	e8 35 9e ff ff       	call   3a00 <fwp_fmt_u128>
    9bcb:	eb bf                	jmp    9b8c <fwp_write+0xf5c>
    9bcd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9bd4:	4e 61 4e 00 
    9bd8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9bdf:	00 
    9be0:	e9 cb f0 ff ff       	jmp    8cb0 <fwp_write+0x80>
    9be5:	44 89 0c 24          	mov    %r9d,(%rsp)
    9be9:	48 89 c8             	mov    %rcx,%rax
    9bec:	48 85 d2             	test   %rdx,%rdx
    9bef:	78 51                	js     9c42 <fwp_write+0x1012>
    9bf1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9bf6:	48 89 c6             	mov    %rax,%rsi
    9bf9:	48 89 ef             	mov    %rbp,%rdi
    9bfc:	e8 ff 9d ff ff       	call   3a00 <fwp_fmt_u128>
    9c01:	44 8b 0c 24          	mov    (%rsp),%r9d
    9c05:	49 63 c1             	movslq %r9d,%rax
    9c08:	49 89 e8             	mov    %rbp,%r8
    9c0b:	ba 00 02 00 00       	mov    $0x200,%edx
    9c10:	be 02 00 00 00       	mov    $0x2,%esi
    9c15:	48 c1 e0 04          	shl    $0x4,%rax
    9c19:	48 8d 3d a0 36 00 00 	lea    0x36a0(%rip),%rdi        # d2c0 <units.0>
    9c20:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c27:	00 
    9c28:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    9c2c:	48 8d 0d 3a 16 00 00 	lea    0x163a(%rip),%rcx        # b26d <_IO_stdin_used+0x26d>
    9c33:	4c 89 e7             	mov    %r12,%rdi
    9c36:	31 c0                	xor    %eax,%eax
    9c38:	e8 63 9a ff ff       	call   36a0 <__sprintf_chk@plt>
    9c3d:	e9 6e f0 ff ff       	jmp    8cb0 <fwp_write+0x80>
    9c42:	48 f7 d8             	neg    %rax
    9c45:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9c4a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9c4f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9c54:	48 83 d2 00          	adc    $0x0,%rdx
    9c58:	48 89 c6             	mov    %rax,%rsi
    9c5b:	48 f7 da             	neg    %rdx
    9c5e:	e8 9d 9d ff ff       	call   3a00 <fwp_fmt_u128>
    9c63:	44 8b 0c 24          	mov    (%rsp),%r9d
    9c67:	eb 9c                	jmp    9c05 <fwp_write+0xfd5>
    9c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009c70 <fwp_main_thread>:
    9c70:	f3 0f 1e fa          	endbr64
    9c74:	41 57                	push   %r15
    9c76:	41 56                	push   %r14
    9c78:	41 55                	push   %r13
    9c7a:	41 54                	push   %r12
    9c7c:	55                   	push   %rbp
    9c7d:	53                   	push   %rbx
    9c7e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9c85:	8b 3d 19 ef 05 00    	mov    0x5ef19(%rip),%edi        # 68ba4 <fwp_heap+0x13a4>
    9c8b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9c92:	00 00 
    9c94:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9c9b:	00 
    9c9c:	31 c0                	xor    %eax,%eax
    9c9e:	85 ff                	test   %edi,%edi
    9ca0:	0f 84 72 07 00 00    	je     a418 <fwp_main_thread+0x7a8>
    9ca6:	8b 35 fc ee 05 00    	mov    0x5eefc(%rip),%esi        # 68ba8 <fwp_heap+0x13a8>
    9cac:	85 f6                	test   %esi,%esi
    9cae:	0f 85 4c 07 00 00    	jne    a400 <fwp_main_thread+0x790>
    9cb4:	48 8d 05 c5 53 00 00 	lea    0x53c5(%rip),%rax        # f080 <alt.5>
    9cbb:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9cc0:	31 f6                	xor    %esi,%esi
    9cc2:	48 c7 05 d3 d4 05 00 	movq   $0x40000000,0x5d4d3(%rip)        # 671a0 <fwp_main_stack_size>
    9cc9:	00 00 00 40 
    9ccd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9cd2:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9cd7:	48 89 c7             	mov    %rax,%rdi
    9cda:	48 89 2d c7 d4 05 00 	mov    %rbp,0x5d4c7(%rip)        # 671a8 <fwp_main_stack_top>
    9ce1:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9ce8:	01 00 
    9cea:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9cf1:	00 
    9cf2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9cf7:	e8 84 99 ff ff       	call   3680 <sigaltstack@plt>
    9cfc:	85 c0                	test   %eax,%eax
    9cfe:	0f 85 33 0e 00 00    	jne    ab37 <fwp_main_thread+0xec7>
    9d04:	31 c0                	xor    %eax,%eax
    9d06:	b9 12 00 00 00       	mov    $0x12,%ecx
    9d0b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9d12:	00 
    9d13:	f3 48 ab             	rep stos %rax,(%rdi)
    9d16:	48 8d 05 e3 9f ff ff 	lea    -0x601d(%rip),%rax        # 3d00 <fwp_segv>
    9d1d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9d24:	00 
    9d25:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    9d2c:	04 00 00 08 
    9d30:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9d37:	00 
    9d38:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    9d3f:	00 
    9d40:	e8 0b 98 ff ff       	call   3550 <sigemptyset@plt>
    9d45:	85 c0                	test   %eax,%eax
    9d47:	0f 85 ea 0d 00 00    	jne    ab37 <fwp_main_thread+0xec7>
    9d4d:	31 d2                	xor    %edx,%edx
    9d4f:	48 89 de             	mov    %rbx,%rsi
    9d52:	bf 0b 00 00 00       	mov    $0xb,%edi
    9d57:	e8 84 96 ff ff       	call   33e0 <sigaction@plt>
    9d5c:	85 c0                	test   %eax,%eax
    9d5e:	0f 85 d3 0d 00 00    	jne    ab37 <fwp_main_thread+0xec7>
    9d64:	31 d2                	xor    %edx,%edx
    9d66:	48 89 de             	mov    %rbx,%rsi
    9d69:	bf 07 00 00 00       	mov    $0x7,%edi
    9d6e:	e8 6d 96 ff ff       	call   33e0 <sigaction@plt>
    9d73:	85 c0                	test   %eax,%eax
    9d75:	0f 85 bc 0d 00 00    	jne    ab37 <fwp_main_thread+0xec7>
    9d7b:	48 8b 05 9e ee 05 00 	mov    0x5ee9e(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    9d82:	48 85 c0             	test   %rax,%rax
    9d85:	0f 88 35 06 00 00    	js     a3c0 <fwp_main_thread+0x750>
    9d8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d8f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9d94:	48 8d 3d 45 a4 ff ff 	lea    -0x5bbb(%rip),%rdi        # 41e0 <ad_raw_report>
    9d9b:	f2 0f 11 05 05 f7 05 	movsd  %xmm0,0x5f705(%rip)        # 694a8 <iteration_start_charge>
    9da2:	00 
    9da3:	c7 05 1b f7 05 00 01 	movl   $0x1,0x5f71b(%rip)        # 694c8 <iteration_active>
    9daa:	00 00 00 
    9dad:	e8 de 0f 00 00       	call   ad90 <atexit>
    9db2:	85 c0                	test   %eax,%eax
    9db4:	0f 85 9a 0d 00 00    	jne    ab54 <fwp_main_thread+0xee4>
    9dba:	8b 0d a8 52 00 00    	mov    0x52a8(%rip),%ecx        # f068 <st.3>
    9dc0:	85 c9                	test   %ecx,%ecx
    9dc2:	0f 84 60 06 00 00    	je     a428 <fwp_main_thread+0x7b8>
    9dc8:	48 8b 2d 11 da 05 00 	mov    0x5da11(%rip),%rbp        # 677e0 <fwp_cur>
    9dcf:	48 85 ed             	test   %rbp,%rbp
    9dd2:	0f 84 08 03 00 00    	je     a0e0 <fwp_main_thread+0x470>
    9dd8:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9ddd:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9de1:	48 89 eb             	mov    %rbp,%rbx
    9de4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9de9:	0f 84 41 01 00 00    	je     9f30 <fwp_main_thread+0x2c0>
    9def:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9df4:	0f 84 16 02 00 00    	je     a010 <fwp_main_thread+0x3a0>
    9dfa:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9dfe:	0f 84 fc 01 00 00    	je     a000 <fwp_main_thread+0x390>
    9e04:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9e08:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9e0c:	0f 85 7e 02 00 00    	jne    a090 <fwp_main_thread+0x420>
    9e12:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9e16:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9e1d:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9e21:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9e28:	00 00 00 00 
    9e2c:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9e33:	48 85 d2             	test   %rdx,%rdx
    9e36:	74 07                	je     9e3f <fwp_main_thread+0x1cf>
    9e38:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9e3f:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e43:	48 85 c0             	test   %rax,%rax
    9e46:	74 34                	je     9e7c <fwp_main_thread+0x20c>
    9e48:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9e4c:	48 8b 05 65 d9 05 00 	mov    0x5d965(%rip),%rax        # 677b8 <fwp_timers>
    9e53:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9e57:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9e5e:	00 00 00 00 
    9e62:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9e69:	48 85 c0             	test   %rax,%rax
    9e6c:	74 07                	je     9e75 <fwp_main_thread+0x205>
    9e6e:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9e75:	48 89 1d 3c d9 05 00 	mov    %rbx,0x5d93c(%rip)        # 677b8 <fwp_timers>
    9e7c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9e80:	e8 eb dd ff ff       	call   7c70 <fwp_block>
    9e85:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9e8c:	48 85 c9             	test   %rcx,%rcx
    9e8f:	74 47                	je     9ed8 <fwp_main_thread+0x268>
    9e91:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9e98:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9e9f:	48 85 d2             	test   %rdx,%rdx
    9ea2:	0f 84 28 02 00 00    	je     a0d0 <fwp_main_thread+0x460>
    9ea8:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9eaf:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9eb6:	48 85 c0             	test   %rax,%rax
    9eb9:	74 07                	je     9ec2 <fwp_main_thread+0x252>
    9ebb:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9ec2:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9ec9:	00 00 00 00 
    9ecd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9ed1:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9ed8:	48 8b 0d 01 d9 05 00 	mov    0x5d901(%rip),%rcx        # 677e0 <fwp_cur>
    9edf:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9ee3:	0f 84 97 01 00 00    	je     a080 <fwp_main_thread+0x410>
    9ee9:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9ef0:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9ef7:	48 85 d2             	test   %rdx,%rdx
    9efa:	0f 84 20 04 00 00    	je     a320 <fwp_main_thread+0x6b0>
    9f00:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9f07:	48 85 c0             	test   %rax,%rax
    9f0a:	74 07                	je     9f13 <fwp_main_thread+0x2a3>
    9f0c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9f13:	66 0f ef db          	pxor   %xmm3,%xmm3
    9f17:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9f1b:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9f22:	48 89 cb             	mov    %rcx,%rbx
    9f25:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9f2a:	0f 85 bf fe ff ff    	jne    9def <fwp_main_thread+0x17f>
    9f30:	48 83 3d 40 f5 05 00 	cmpq   $0x0,0x5f540(%rip)        # 69478 <fwp_state_len>
    9f37:	00 
    9f38:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9f3c:	0f 84 10 04 00 00    	je     a352 <fwp_main_thread+0x6e2>
    9f42:	48 39 1d 8f d8 05 00 	cmp    %rbx,0x5d88f(%rip)        # 677d8 <fwp_root>
    9f49:	c7 05 2d 51 01 00 00 	movl   $0x0,0x1512d(%rip)        # 1f080 <fwp_exit_code>
    9f50:	00 00 00 
    9f53:	0f 85 18 0c 00 00    	jne    ab71 <fwp_main_thread+0xf01>
    9f59:	48 85 db             	test   %rbx,%rbx
    9f5c:	0f 84 a4 01 00 00    	je     a106 <fwp_main_thread+0x496>
    9f62:	48 8b 15 3f d8 05 00 	mov    0x5d83f(%rip),%rdx        # 677a8 <fwp_tasks_active>
    9f69:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9f6d:	48 85 d2             	test   %rdx,%rdx
    9f70:	0f 84 90 01 00 00    	je     a106 <fwp_main_thread+0x496>
    9f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f7d:	00 00 00 
    9f80:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9f84:	75 08                	jne    9f8e <fwp_main_thread+0x31e>
    9f86:	48 89 d7             	mov    %rdx,%rdi
    9f89:	e8 62 a1 ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    9f8e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9f95:	48 85 d2             	test   %rdx,%rdx
    9f98:	75 e6                	jne    9f80 <fwp_main_thread+0x310>
    9f9a:	eb 31                	jmp    9fcd <fwp_main_thread+0x35d>
    9f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9fa0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9fa7:	48 89 1d 12 d8 05 00 	mov    %rbx,0x5d812(%rip)        # 677c0 <fwp_ready_tail>
    9fae:	e8 bd dc ff ff       	call   7c70 <fwp_block>
    9fb3:	e8 a8 da ff ff       	call   7a60 <fwp_free_zombie>
    9fb8:	48 83 3d e8 d7 05 00 	cmpq   $0x0,0x5d7e8(%rip)        # 677a8 <fwp_tasks_active>
    9fbf:	00 
    9fc0:	0f 84 40 01 00 00    	je     a106 <fwp_main_thread+0x496>
    9fc6:	48 8b 1d 0b d8 05 00 	mov    0x5d80b(%rip),%rbx        # 677d8 <fwp_root>
    9fcd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9fd1:	75 db                	jne    9fae <fwp_main_thread+0x33e>
    9fd3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9fd7:	75 d5                	jne    9fae <fwp_main_thread+0x33e>
    9fd9:	48 8b 05 e0 d7 05 00 	mov    0x5d7e0(%rip),%rax        # 677c0 <fwp_ready_tail>
    9fe0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9fe4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9feb:	00 00 00 00 
    9fef:	48 85 c0             	test   %rax,%rax
    9ff2:	75 ac                	jne    9fa0 <fwp_main_thread+0x330>
    9ff4:	48 89 1d cd d7 05 00 	mov    %rbx,0x5d7cd(%rip)        # 677c8 <fwp_ready_head>
    9ffb:	eb aa                	jmp    9fa7 <fwp_main_thread+0x337>
    9ffd:	0f 1f 00             	nopl   (%rax)
    a000:	e8 7b a5 ff ff       	call   4580 <fwp_now_ns>
    a005:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a009:	0f 8d 21 03 00 00    	jge    a330 <fwp_main_thread+0x6c0>
    a00f:	90                   	nop
    a010:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a014:	0f 85 ea fd ff ff    	jne    9e04 <fwp_main_thread+0x194>
    a01a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a01e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a022:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a026:	0f 85 ea fd ff ff    	jne    9e16 <fwp_main_thread+0x1a6>
    a02c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a030:	48 85 c9             	test   %rcx,%rcx
    a033:	0f 84 dd fd ff ff    	je     9e16 <fwp_main_thread+0x1a6>
    a039:	48 39 c8             	cmp    %rcx,%rax
    a03c:	48 89 ce             	mov    %rcx,%rsi
    a03f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a046:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a04a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a051:	00 00 00 00 
    a055:	48 0f 4e f0          	cmovle %rax,%rsi
    a059:	48 85 c0             	test   %rax,%rax
    a05c:	48 89 c8             	mov    %rcx,%rax
    a05f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a066:	48 0f 45 c6          	cmovne %rsi,%rax
    a06a:	48 85 d2             	test   %rdx,%rdx
    a06d:	74 07                	je     a076 <fwp_main_thread+0x406>
    a06f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a076:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a07a:	e9 c9 fd ff ff       	jmp    9e48 <fwp_main_thread+0x1d8>
    a07f:	90                   	nop
    a080:	48 89 cb             	mov    %rcx,%rbx
    a083:	e9 5c fd ff ff       	jmp    9de4 <fwp_main_thread+0x174>
    a088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a08f:	00 
    a090:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a094:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a09b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a0a2:	00 00 00 00 
    a0a6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a0ad:	48 85 c0             	test   %rax,%rax
    a0b0:	0f 84 6a 09 00 00    	je     aa20 <fwp_main_thread+0xdb0>
    a0b6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a0bd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a0c1:	e9 b6 fd ff ff       	jmp    9e7c <fwp_main_thread+0x20c>
    a0c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0cd:	00 00 00 
    a0d0:	48 89 01             	mov    %rax,(%rcx)
    a0d3:	e9 de fd ff ff       	jmp    9eb6 <fwp_main_thread+0x246>
    a0d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0df:	00 
    a0e0:	48 83 3d 90 f3 05 00 	cmpq   $0x0,0x5f390(%rip)        # 69478 <fwp_state_len>
    a0e7:	00 
    a0e8:	0f 84 62 02 00 00    	je     a350 <fwp_main_thread+0x6e0>
    a0ee:	48 83 3d e2 d6 05 00 	cmpq   $0x0,0x5d6e2(%rip)        # 677d8 <fwp_root>
    a0f5:	00 
    a0f6:	c7 05 80 4f 01 00 00 	movl   $0x0,0x14f80(%rip)        # 1f080 <fwp_exit_code>
    a0fd:	00 00 00 
    a100:	0f 85 66 0a 00 00    	jne    ab6c <fwp_main_thread+0xefc>
    a106:	e8 55 d9 ff ff       	call   7a60 <fwp_free_zombie>
    a10b:	48 83 3d b5 d6 05 00 	cmpq   $0x0,0x5d6b5(%rip)        # 677c8 <fwp_ready_head>
    a112:	00 
    a113:	0f 85 f2 95 ff ff    	jne    370b <fwp_main_thread.cold>
    a119:	48 83 3d 97 d6 05 00 	cmpq   $0x0,0x5d697(%rip)        # 677b8 <fwp_timers>
    a120:	00 
    a121:	0f 85 e4 95 ff ff    	jne    370b <fwp_main_thread.cold>
    a127:	8b 05 87 d0 05 00    	mov    0x5d087(%rip),%eax        # 671b4 <fwp_stack_pool_n>
    a12d:	85 c0                	test   %eax,%eax
    a12f:	74 3c                	je     a16d <fwp_main_thread+0x4fd>
    a131:	83 e8 01             	sub    $0x1,%eax
    a134:	4c 8d 25 85 d0 05 00 	lea    0x5d085(%rip),%r12        # 671c0 <fwp_stack_pool>
    a13b:	48 63 d8             	movslq %eax,%rbx
    a13e:	89 c0                	mov    %eax,%eax
    a140:	48 89 da             	mov    %rbx,%rdx
    a143:	48 29 c2             	sub    %rax,%rdx
    a146:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    a14a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a150:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    a154:	89 1d 5a d0 05 00    	mov    %ebx,0x5d05a(%rip)        # 671b4 <fwp_stack_pool_n>
    a15a:	be 00 00 00 10       	mov    $0x10000000,%esi
    a15f:	48 83 eb 01          	sub    $0x1,%rbx
    a163:	e8 48 94 ff ff       	call   35b0 <munmap@plt>
    a168:	48 39 dd             	cmp    %rbx,%rbp
    a16b:	75 e3                	jne    a150 <fwp_main_thread+0x4e0>
    a16d:	8b 3d 9d 4e 00 00    	mov    0x4e9d(%rip),%edi        # f010 <fwp_epfd>
    a173:	85 ff                	test   %edi,%edi
    a175:	78 05                	js     a17c <fwp_main_thread+0x50c>
    a177:	e8 34 93 ff ff       	call   34b0 <close@plt>
    a17c:	4c 8b 25 3d d2 05 00 	mov    0x5d23d(%rip),%r12        # 673c0 <fwp_nfdws>
    a183:	48 8b 2d 3e d2 05 00 	mov    0x5d23e(%rip),%rbp        # 673c8 <fwp_fdws>
    a18a:	31 db                	xor    %ebx,%ebx
    a18c:	c7 05 7a 4e 00 00 ff 	movl   $0xffffffff,0x4e7a(%rip)        # f010 <fwp_epfd>
    a193:	ff ff ff 
    a196:	4d 85 e4             	test   %r12,%r12
    a199:	74 32                	je     a1cd <fwp_main_thread+0x55d>
    a19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a1a0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    a1a5:	48 85 ff             	test   %rdi,%rdi
    a1a8:	74 1a                	je     a1c4 <fwp_main_thread+0x554>
    a1aa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    a1ae:	0f 85 57 95 ff ff    	jne    370b <fwp_main_thread.cold>
    a1b4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    a1b9:	0f 85 4c 95 ff ff    	jne    370b <fwp_main_thread.cold>
    a1bf:	e8 ec b7 ff ff       	call   59b0 <fwp_mem_free>
    a1c4:	48 83 c3 01          	add    $0x1,%rbx
    a1c8:	49 39 dc             	cmp    %rbx,%r12
    a1cb:	75 d3                	jne    a1a0 <fwp_main_thread+0x530>
    a1cd:	48 89 ef             	mov    %rbp,%rdi
    a1d0:	e8 db b7 ff ff       	call   59b0 <fwp_mem_free>
    a1d5:	48 8b 15 fc d5 05 00 	mov    0x5d5fc(%rip),%rdx        # 677d8 <fwp_root>
    a1dc:	48 c7 05 e1 d1 05 00 	movq   $0x0,0x5d1e1(%rip)        # 673c8 <fwp_fdws>
    a1e3:	00 00 00 00 
    a1e7:	48 c7 05 ce d1 05 00 	movq   $0x0,0x5d1ce(%rip)        # 673c0 <fwp_nfdws>
    a1ee:	00 00 00 00 
    a1f2:	48 85 d2             	test   %rdx,%rdx
    a1f5:	74 4e                	je     a245 <fwp_main_thread+0x5d5>
    a1f7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    a1fc:	0f 85 09 95 ff ff    	jne    370b <fwp_main_thread.cold>
    a202:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    a209:	00 
    a20a:	0f 85 fb 94 ff ff    	jne    370b <fwp_main_thread.cold>
    a210:	48 83 3d 60 f2 05 00 	cmpq   $0x0,0x5f260(%rip)        # 69478 <fwp_state_len>
    a217:	00 
    a218:	0f 85 ed 94 ff ff    	jne    370b <fwp_main_thread.cold>
    a21e:	48 83 3d 42 f2 05 00 	cmpq   $0x0,0x5f242(%rip)        # 69468 <fwp_state_owners>
    a225:	00 
    a226:	0f 85 df 94 ff ff    	jne    370b <fwp_main_thread.cold>
    a22c:	b9 79 00 00 00       	mov    $0x79,%ecx
    a231:	31 c0                	xor    %eax,%eax
    a233:	48 8d 3d a6 d1 05 00 	lea    0x5d1a6(%rip),%rdi        # 673e0 <fwp_root_context>
    a23a:	f3 48 ab             	rep stos %rax,(%rdi)
    a23d:	48 89 d7             	mov    %rdx,%rdi
    a240:	e8 6b b7 ff ff       	call   59b0 <fwp_mem_free>
    a245:	66 0f 6f 05 43 4f 04 	movdqa 0x44f43(%rip),%xmm0        # 4f190 <ad_raw_live+0x10>
    a24c:	00 
    a24d:	66 0f d4 05 2b 4f 04 	paddq  0x44f2b(%rip),%xmm0        # 4f180 <ad_raw_live>
    a254:	00 
    a255:	48 c7 05 80 d5 05 00 	movq   $0x0,0x5d580(%rip)        # 677e0 <fwp_cur>
    a25c:	00 00 00 00 
    a260:	48 8b 05 b9 e9 05 00 	mov    0x5e9b9(%rip),%rax        # 68c20 <fwp_heap+0x1420>
    a267:	48 c7 05 66 d5 05 00 	movq   $0x0,0x5d566(%rip)        # 677d8 <fwp_root>
    a26e:	00 00 00 00 
    a272:	c7 05 4c f2 05 00 00 	movl   $0x0,0x5f24c(%rip)        # 694c8 <iteration_active>
    a279:	00 00 00 
    a27c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    a280:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    a285:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    a289:	66 0f d6 05 57 4e 01 	movq   %xmm0,0x14e57(%rip)        # 1f0e8 <ad_raw_before_shutdown>
    a290:	00 
    a291:	48 85 c0             	test   %rax,%rax
    a294:	0f 88 46 01 00 00    	js     a3e0 <fwp_main_thread+0x770>
    a29a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a29e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    a2a3:	f2 0f 5c 0d fd f1 05 	subsd  0x5f1fd(%rip),%xmm1        # 694a8 <iteration_start_charge>
    a2aa:	00 
    a2ab:	48 8b 3d 8e 4d 00 00 	mov    0x4d8e(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    a2b2:	48 8d 15 e7 17 00 00 	lea    0x17e7(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    a2b9:	be 02 00 00 00       	mov    $0x2,%esi
    a2be:	f2 0f 10 05 da f1 05 	movsd  0x5f1da(%rip),%xmm0        # 694a0 <iteration_peak>
    a2c5:	00 
    a2c6:	4c 8b 0d e3 f1 05 00 	mov    0x5f1e3(%rip),%r9        # 694b0 <iteration_retains>
    a2cd:	b8 02 00 00 00       	mov    $0x2,%eax
    a2d2:	4c 8b 05 df f1 05 00 	mov    0x5f1df(%rip),%r8        # 694b8 <iteration_bytes>
    a2d9:	48 8b 0d e0 f1 05 00 	mov    0x5f1e0(%rip),%rcx        # 694c0 <iteration_requests>
    a2e0:	e8 6b 93 ff ff       	call   3650 <__fprintf_chk@plt>
    a2e5:	48 8b 3d 34 4d 00 00 	mov    0x4d34(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    a2ec:	e8 9f 92 ff ff       	call   3590 <fflush@plt>
    a2f1:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a2f8:	00 
    a2f9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a300:	00 00 
    a302:	0f 85 47 08 00 00    	jne    ab4f <fwp_main_thread+0xedf>
    a308:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a30f:	31 c0                	xor    %eax,%eax
    a311:	5b                   	pop    %rbx
    a312:	5d                   	pop    %rbp
    a313:	41 5c                	pop    %r12
    a315:	41 5d                	pop    %r13
    a317:	41 5e                	pop    %r14
    a319:	41 5f                	pop    %r15
    a31b:	c3                   	ret
    a31c:	0f 1f 40 00          	nopl   0x0(%rax)
    a320:	48 89 05 91 d4 05 00 	mov    %rax,0x5d491(%rip)        # 677b8 <fwp_timers>
    a327:	e9 db fb ff ff       	jmp    9f07 <fwp_main_thread+0x297>
    a32c:	0f 1f 40 00          	nopl   0x0(%rax)
    a330:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a334:	0f 85 d6 fc ff ff    	jne    a010 <fwp_main_thread+0x3a0>
    a33a:	48 89 ef             	mov    %rbp,%rdi
    a33d:	e8 ae 9d ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    a342:	e9 c9 fc ff ff       	jmp    a010 <fwp_main_thread+0x3a0>
    a347:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a34e:	00 00 
    a350:	31 db                	xor    %ebx,%ebx
    a352:	48 83 3d 0e f1 05 00 	cmpq   $0x0,0x5f10e(%rip)        # 69468 <fwp_state_owners>
    a359:	00 
    a35a:	0f 85 e2 fb ff ff    	jne    9f42 <fwp_main_thread+0x2d2>
    a360:	48 8b 3d 19 f1 05 00 	mov    0x5f119(%rip),%rdi        # 69480 <fwp_state>
    a367:	e8 44 b6 ff ff       	call   59b0 <fwp_mem_free>
    a36c:	48 c7 05 09 f1 05 00 	movq   $0x0,0x5f109(%rip)        # 69480 <fwp_state>
    a373:	00 00 00 00 
    a377:	48 c7 05 ee f0 05 00 	movq   $0x0,0x5f0ee(%rip)        # 69470 <fwp_state_cap>
    a37e:	00 00 00 00 
    a382:	48 85 db             	test   %rbx,%rbx
    a385:	0f 84 5f 07 00 00    	je     aaea <fwp_main_thread+0xe7a>
    a38b:	48 3b 1d 46 d4 05 00 	cmp    0x5d446(%rip),%rbx        # 677d8 <fwp_root>
    a392:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    a399:	00 00 00 00 
    a39d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    a3a4:	00 00 00 00 
    a3a8:	c7 05 ce 4c 01 00 00 	movl   $0x0,0x14cce(%rip)        # 1f080 <fwp_exit_code>
    a3af:	00 00 00 
    a3b2:	0f 84 aa fb ff ff    	je     9f62 <fwp_main_thread+0x2f2>
    a3b8:	e9 4e 93 ff ff       	jmp    370b <fwp_main_thread.cold>
    a3bd:	0f 1f 00             	nopl   (%rax)
    a3c0:	48 89 c2             	mov    %rax,%rdx
    a3c3:	83 e0 01             	and    $0x1,%eax
    a3c6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a3ca:	48 d1 ea             	shr    $1,%rdx
    a3cd:	48 09 c2             	or     %rax,%rdx
    a3d0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    a3d5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    a3d9:	e9 b6 f9 ff ff       	jmp    9d94 <fwp_main_thread+0x124>
    a3de:	66 90                	xchg   %ax,%ax
    a3e0:	48 89 c2             	mov    %rax,%rdx
    a3e3:	83 e0 01             	and    $0x1,%eax
    a3e6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a3ea:	48 d1 ea             	shr    $1,%rdx
    a3ed:	48 09 c2             	or     %rax,%rdx
    a3f0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    a3f5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    a3f9:	e9 a5 fe ff ff       	jmp    a2a3 <fwp_main_thread+0x633>
    a3fe:	66 90                	xchg   %ax,%ax
    a400:	48 8d 3d 79 a8 ff ff 	lea    -0x5787(%rip),%rdi        # 4c80 <fwp_heap_report>
    a407:	e8 84 09 00 00       	call   ad90 <atexit>
    a40c:	e9 a3 f8 ff ff       	jmp    9cb4 <fwp_main_thread+0x44>
    a411:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a418:	e8 73 a9 ff ff       	call   4d90 <fwp_heap_init>
    a41d:	e9 84 f8 ff ff       	jmp    9ca6 <fwp_main_thread+0x36>
    a422:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a428:	48 8d 05 a1 de ff ff 	lea    -0x215f(%rip),%rax        # 82d0 <fwp_drop1>
    a42f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a433:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    a43a:	00 00 
    a43c:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    a442:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a447:	48 8b 05 4a f0 05 00 	mov    0x5f04a(%rip),%rax        # 69498 <fwp_cleanups>
    a44e:	4c 8d 3d ab d3 05 00 	lea    0x5d3ab(%rip),%r15        # 67800 <fwp_heap>
    a455:	48 89 2d 3c f0 05 00 	mov    %rbp,0x5f03c(%rip)        # 69498 <fwp_cleanups>
    a45c:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a460:	31 ed                	xor    %ebp,%ebp
    a462:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a467:	48 8d 05 22 97 ff ff 	lea    -0x68de(%rip),%rax        # 3b90 <fwp_range_release>
    a46e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a473:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    a478:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    a47d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a482:	eb 3d                	jmp    a4c1 <fwp_main_thread+0x851>
    a484:	0f 1f 40 00          	nopl   0x0(%rax)
    a488:	80 f9 01             	cmp    $0x1,%cl
    a48b:	75 29                	jne    a4b6 <fwp_main_thread+0x846>
    a48d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a490:	0f b7 c0             	movzwl %ax,%eax
    a493:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a496:	48 0f af c1          	imul   %rcx,%rax
    a49a:	48 c1 e8 20          	shr    $0x20,%rax
    a49e:	48 39 d0             	cmp    %rdx,%rax
    a4a1:	73 13                	jae    a4b6 <fwp_main_thread+0x846>
    a4a3:	49 01 c5             	add    %rax,%r13
    a4a6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a4ab:	0f 84 af 05 00 00    	je     aa60 <fwp_main_thread+0xdf0>
    a4b1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a4b6:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a4bb:	49 83 ec 01          	sub    $0x1,%r12
    a4bf:	72 7f                	jb     a540 <fwp_main_thread+0x8d0>
    a4c1:	48 89 de             	mov    %rbx,%rsi
    a4c4:	bf 01 00 00 00       	mov    $0x1,%edi
    a4c9:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    a4d0:	00 
    a4d1:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    a4d6:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    a4dd:	00 
    a4de:	e8 bd bb ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    a4e3:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a4ea:	48 89 c5             	mov    %rax,%rbp
    a4ed:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a4f4:	48 c1 e2 10          	shl    $0x10,%rdx
    a4f8:	48 39 d0             	cmp    %rdx,%rax
    a4fb:	73 b9                	jae    a4b6 <fwp_main_thread+0x846>
    a4fd:	48 89 c2             	mov    %rax,%rdx
    a500:	48 c1 ea 10          	shr    $0x10,%rdx
    a504:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a508:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a50f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a513:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a517:	4d 85 ed             	test   %r13,%r13
    a51a:	74 9a                	je     a4b6 <fwp_main_thread+0x846>
    a51c:	0f b6 0a             	movzbl (%rdx),%ecx
    a51f:	80 f9 02             	cmp    $0x2,%cl
    a522:	0f 85 60 ff ff ff    	jne    a488 <fwp_main_thread+0x818>
    a528:	66 85 c0             	test   %ax,%ax
    a52b:	0f 84 75 ff ff ff    	je     a4a6 <fwp_main_thread+0x836>
    a531:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a536:	49 83 ec 01          	sub    $0x1,%r12
    a53a:	73 85                	jae    a4c1 <fwp_main_thread+0x851>
    a53c:	0f 1f 40 00          	nopl   0x0(%rax)
    a540:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a545:	66 0f 6f 05 f3 17 00 	movdqa 0x17f3(%rip),%xmm0        # bd40 <msg.4+0xd0>
    a54c:	00 
    a54d:	48 89 de             	mov    %rbx,%rsi
    a550:	bf 01 00 00 00       	mov    $0x1,%edi
    a555:	48 89 05 3c ef 05 00 	mov    %rax,0x5ef3c(%rip)        # 69498 <fwp_cleanups>
    a55c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    a563:	00 
    a564:	e8 37 bb ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    a569:	48 8b 15 68 e6 05 00 	mov    0x5e668(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    a570:	49 89 c4             	mov    %rax,%r12
    a573:	48 2b 05 36 e6 05 00 	sub    0x5e636(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    a57a:	48 c1 e2 10          	shl    $0x10,%rdx
    a57e:	48 39 d0             	cmp    %rdx,%rax
    a581:	73 55                	jae    a5d8 <fwp_main_thread+0x968>
    a583:	48 89 c2             	mov    %rax,%rdx
    a586:	48 c1 ea 10          	shr    $0x10,%rdx
    a58a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a58e:	48 8b 15 63 e6 05 00 	mov    0x5e663(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    a595:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a599:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a59d:	48 85 db             	test   %rbx,%rbx
    a5a0:	74 36                	je     a5d8 <fwp_main_thread+0x968>
    a5a2:	0f b6 0a             	movzbl (%rdx),%ecx
    a5a5:	80 f9 02             	cmp    $0x2,%cl
    a5a8:	0f 84 a2 04 00 00    	je     aa50 <fwp_main_thread+0xde0>
    a5ae:	80 f9 01             	cmp    $0x1,%cl
    a5b1:	75 25                	jne    a5d8 <fwp_main_thread+0x968>
    a5b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5b6:	0f b7 c0             	movzwl %ax,%eax
    a5b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5bc:	48 0f af c1          	imul   %rcx,%rax
    a5c0:	48 c1 e8 20          	shr    $0x20,%rax
    a5c4:	48 39 d0             	cmp    %rdx,%rax
    a5c7:	73 0f                	jae    a5d8 <fwp_main_thread+0x968>
    a5c9:	48 01 c3             	add    %rax,%rbx
    a5cc:	80 3b ff             	cmpb   $0xff,(%rbx)
    a5cf:	0f 84 3b 05 00 00    	je     ab10 <fwp_main_thread+0xea0>
    a5d5:	c6 03 01             	movb   $0x1,(%rbx)
    a5d8:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    a5dd:	bf 01 00 00 00       	mov    $0x1,%edi
    a5e2:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    a5e7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a5ee:	00 f0 3f 
    a5f1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    a5f6:	e8 a5 ba ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    a5fb:	48 8b 15 d6 e5 05 00 	mov    0x5e5d6(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    a602:	49 89 c4             	mov    %rax,%r12
    a605:	48 2b 05 a4 e5 05 00 	sub    0x5e5a4(%rip),%rax        # 68bb0 <fwp_heap+0x13b0>
    a60c:	48 c1 e2 10          	shl    $0x10,%rdx
    a610:	48 39 d0             	cmp    %rdx,%rax
    a613:	73 55                	jae    a66a <fwp_main_thread+0x9fa>
    a615:	48 89 c2             	mov    %rax,%rdx
    a618:	48 c1 ea 10          	shr    $0x10,%rdx
    a61c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a620:	48 8b 15 d1 e5 05 00 	mov    0x5e5d1(%rip),%rdx        # 68bf8 <fwp_heap+0x13f8>
    a627:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a62b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a62f:	48 85 db             	test   %rbx,%rbx
    a632:	74 36                	je     a66a <fwp_main_thread+0x9fa>
    a634:	0f b6 0a             	movzbl (%rdx),%ecx
    a637:	80 f9 02             	cmp    $0x2,%cl
    a63a:	0f 84 00 04 00 00    	je     aa40 <fwp_main_thread+0xdd0>
    a640:	80 f9 01             	cmp    $0x1,%cl
    a643:	75 25                	jne    a66a <fwp_main_thread+0x9fa>
    a645:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a648:	0f b7 c0             	movzwl %ax,%eax
    a64b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a64e:	48 0f af c1          	imul   %rcx,%rax
    a652:	48 c1 e8 20          	shr    $0x20,%rax
    a656:	48 39 d0             	cmp    %rdx,%rax
    a659:	73 0f                	jae    a66a <fwp_main_thread+0x9fa>
    a65b:	48 01 c3             	add    %rax,%rbx
    a65e:	80 3b ff             	cmpb   $0xff,(%rbx)
    a661:	0f 84 b6 04 00 00    	je     ab1d <fwp_main_thread+0xead>
    a667:	c6 03 01             	movb   $0x1,(%rbx)
    a66a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    a66f:	bf 01 00 00 00       	mov    $0x1,%edi
    a674:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    a679:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a680:	33 f3 bf 
    a683:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a688:	e8 13 ba ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    a68d:	48 8b 15 44 e5 05 00 	mov    0x5e544(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    a694:	48 8b 0d 15 e5 05 00 	mov    0x5e515(%rip),%rcx        # 68bb0 <fwp_heap+0x13b0>
    a69b:	49 89 c4             	mov    %rax,%r12
    a69e:	48 89 d6             	mov    %rdx,%rsi
    a6a1:	48 29 c8             	sub    %rcx,%rax
    a6a4:	48 c1 e6 10          	shl    $0x10,%rsi
    a6a8:	48 39 f0             	cmp    %rsi,%rax
    a6ab:	73 65                	jae    a712 <fwp_main_thread+0xaa2>
    a6ad:	48 89 c6             	mov    %rax,%rsi
    a6b0:	48 c1 ee 10          	shr    $0x10,%rsi
    a6b4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a6b8:	48 8b 35 39 e5 05 00 	mov    0x5e539(%rip),%rsi        # 68bf8 <fwp_heap+0x13f8>
    a6bf:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a6c3:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a6c7:	48 85 db             	test   %rbx,%rbx
    a6ca:	74 46                	je     a712 <fwp_main_thread+0xaa2>
    a6cc:	0f b6 3e             	movzbl (%rsi),%edi
    a6cf:	40 80 ff 02          	cmp    $0x2,%dil
    a6d3:	0f 84 57 03 00 00    	je     aa30 <fwp_main_thread+0xdc0>
    a6d9:	40 80 ff 01          	cmp    $0x1,%dil
    a6dd:	75 33                	jne    a712 <fwp_main_thread+0xaa2>
    a6df:	8b 7e 18             	mov    0x18(%rsi),%edi
    a6e2:	0f b7 c0             	movzwl %ax,%eax
    a6e5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a6e8:	48 0f af c7          	imul   %rdi,%rax
    a6ec:	48 c1 e8 20          	shr    $0x20,%rax
    a6f0:	48 39 f0             	cmp    %rsi,%rax
    a6f3:	73 1d                	jae    a712 <fwp_main_thread+0xaa2>
    a6f5:	48 01 c3             	add    %rax,%rbx
    a6f8:	80 3b ff             	cmpb   $0xff,(%rbx)
    a6fb:	0f 84 29 04 00 00    	je     ab2a <fwp_main_thread+0xeba>
    a701:	c6 03 01             	movb   $0x1,(%rbx)
    a704:	48 8b 0d a5 e4 05 00 	mov    0x5e4a5(%rip),%rcx        # 68bb0 <fwp_heap+0x13b0>
    a70b:	48 8b 15 c6 e4 05 00 	mov    0x5e4c6(%rip),%rdx        # 68bd8 <fwp_heap+0x13d8>
    a712:	49 89 ed             	mov    %rbp,%r13
    a715:	e9 13 02 00 00       	jmp    a92d <fwp_main_thread+0xcbd>
    a71a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a720:	80 f9 01             	cmp    $0x1,%cl
    a723:	75 3f                	jne    a764 <fwp_main_thread+0xaf4>
    a725:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a728:	0f b7 c0             	movzwl %ax,%eax
    a72b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a72e:	48 0f af c1          	imul   %rcx,%rax
    a732:	48 c1 e8 20          	shr    $0x20,%rax
    a736:	48 39 d0             	cmp    %rdx,%rax
    a739:	73 29                	jae    a764 <fwp_main_thread+0xaf4>
    a73b:	48 01 c7             	add    %rax,%rdi
    a73e:	0f b6 07             	movzbl (%rdi),%eax
    a741:	84 c0                	test   %al,%al
    a743:	74 1f                	je     a764 <fwp_main_thread+0xaf4>
    a745:	8b 15 7d ed 05 00    	mov    0x5ed7d(%rip),%edx        # 694c8 <iteration_active>
    a74b:	85 d2                	test   %edx,%edx
    a74d:	74 08                	je     a757 <fwp_main_thread+0xae7>
    a74f:	48 83 05 59 ed 05 00 	addq   $0x1,0x5ed59(%rip)        # 694b0 <iteration_retains>
    a756:	01 
    a757:	3c fd                	cmp    $0xfd,%al
    a759:	0f 87 81 03 00 00    	ja     aae0 <fwp_main_thread+0xe70>
    a75f:	83 c0 01             	add    $0x1,%eax
    a762:	88 07                	mov    %al,(%rdi)
    a764:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a769:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a76d:	b9 01 00 00 00       	mov    $0x1,%ecx
    a772:	4c 89 e6             	mov    %r12,%rsi
    a775:	48 8d 15 24 44 00 00 	lea    0x4424(%rip),%rdx        # eba0 <d0>
    a77c:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a781:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a788:	00 00 
    a78a:	e8 a1 e4 ff ff       	call   8c30 <fwp_write>
    a78f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a794:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a799:	48 8d 05 ce 08 00 00 	lea    0x8ce(%rip),%rax        # b06e <_IO_stdin_used+0x6e>
    a7a0:	48 85 c9             	test   %rcx,%rcx
    a7a3:	48 0f 44 c8          	cmove  %rax,%rcx
    a7a7:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a7ab:	0f 87 92 03 00 00    	ja     ab43 <fwp_main_thread+0xed3>
    a7b1:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a7b5:	be 01 00 00 00       	mov    $0x1,%esi
    a7ba:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a7bf:	e8 ec b6 ff ff       	call   5eb0 <fwp_heap_alloc>
    a7c4:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a7c9:	4c 89 f2             	mov    %r14,%rdx
    a7cc:	4c 89 30             	mov    %r14,(%rax)
    a7cf:	48 89 c3             	mov    %rax,%rbx
    a7d2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a7d6:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a7db:	e8 90 8d ff ff       	call   3570 <memcpy@plt>
    a7e0:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a7e6:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a7eb:	e8 b0 8b ff ff       	call   33a0 <free@plt>
    a7f0:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a7f7:	48 89 d8             	mov    %rbx,%rax
    a7fa:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a801:	48 c1 e2 10          	shl    $0x10,%rdx
    a805:	48 39 d0             	cmp    %rdx,%rax
    a808:	73 55                	jae    a85f <fwp_main_thread+0xbef>
    a80a:	48 89 c2             	mov    %rax,%rdx
    a80d:	48 c1 ea 10          	shr    $0x10,%rdx
    a811:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a815:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a81c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a820:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a824:	48 85 f6             	test   %rsi,%rsi
    a827:	74 36                	je     a85f <fwp_main_thread+0xbef>
    a829:	0f b6 0a             	movzbl (%rdx),%ecx
    a82c:	80 f9 02             	cmp    $0x2,%cl
    a82f:	0f 84 4b 01 00 00    	je     a980 <fwp_main_thread+0xd10>
    a835:	80 f9 01             	cmp    $0x1,%cl
    a838:	75 25                	jne    a85f <fwp_main_thread+0xbef>
    a83a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a83d:	0f b7 c0             	movzwl %ax,%eax
    a840:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a843:	48 0f af c1          	imul   %rcx,%rax
    a847:	48 c1 e8 20          	shr    $0x20,%rax
    a84b:	48 39 d0             	cmp    %rdx,%rax
    a84e:	73 0f                	jae    a85f <fwp_main_thread+0xbef>
    a850:	48 01 c6             	add    %rax,%rsi
    a853:	80 3e ff             	cmpb   $0xff,(%rsi)
    a856:	0f 84 44 01 00 00    	je     a9a0 <fwp_main_thread+0xd30>
    a85c:	c6 06 01             	movb   $0x1,(%rsi)
    a85f:	4c 89 e7             	mov    %r12,%rdi
    a862:	e8 79 d8 ff ff       	call   80e0 <fwp_drop0>
    a867:	48 8b 13             	mov    (%rbx),%rdx
    a86a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a86f:	be 01 00 00 00       	mov    $0x1,%esi
    a874:	48 8b 0d e5 eb 05 00 	mov    0x5ebe5(%rip),%rcx        # 69460 <fwp_prog_out>
    a87b:	e8 c0 8d ff ff       	call   3640 <fwrite@plt>
    a880:	48 8b 35 d9 eb 05 00 	mov    0x5ebd9(%rip),%rsi        # 69460 <fwp_prog_out>
    a887:	bf 0a 00 00 00       	mov    $0xa,%edi
    a88c:	e8 2f 8c ff ff       	call   34c0 <fputc@plt>
    a891:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a898:	48 89 d8             	mov    %rbx,%rax
    a89b:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a8a2:	48 c1 e2 10          	shl    $0x10,%rdx
    a8a6:	48 39 d0             	cmp    %rdx,%rax
    a8a9:	73 67                	jae    a912 <fwp_main_thread+0xca2>
    a8ab:	48 89 c2             	mov    %rax,%rdx
    a8ae:	48 c1 ea 10          	shr    $0x10,%rdx
    a8b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8b6:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a8bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a8c1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a8c5:	4d 85 f6             	test   %r14,%r14
    a8c8:	74 48                	je     a912 <fwp_main_thread+0xca2>
    a8ca:	0f b6 0a             	movzbl (%rdx),%ecx
    a8cd:	80 f9 02             	cmp    $0x2,%cl
    a8d0:	0f 84 ea 00 00 00    	je     a9c0 <fwp_main_thread+0xd50>
    a8d6:	80 f9 01             	cmp    $0x1,%cl
    a8d9:	75 37                	jne    a912 <fwp_main_thread+0xca2>
    a8db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a8de:	0f b7 c0             	movzwl %ax,%eax
    a8e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a8e4:	48 0f af c1          	imul   %rcx,%rax
    a8e8:	48 c1 e8 20          	shr    $0x20,%rax
    a8ec:	48 39 d0             	cmp    %rdx,%rax
    a8ef:	73 21                	jae    a912 <fwp_main_thread+0xca2>
    a8f1:	49 01 c6             	add    %rax,%r14
    a8f4:	41 0f b6 06          	movzbl (%r14),%eax
    a8f8:	84 c0                	test   %al,%al
    a8fa:	74 16                	je     a912 <fwp_main_thread+0xca2>
    a8fc:	3c 01                	cmp    $0x1,%al
    a8fe:	0f 84 0c 01 00 00    	je     aa10 <fwp_main_thread+0xda0>
    a904:	3c ff                	cmp    $0xff,%al
    a906:	0f 84 64 01 00 00    	je     aa70 <fwp_main_thread+0xe00>
    a90c:	83 e8 01             	sub    $0x1,%eax
    a90f:	41 88 06             	mov    %al,(%r14)
    a912:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a916:	4d 85 ed             	test   %r13,%r13
    a919:	0f 84 c1 00 00 00    	je     a9e0 <fwp_main_thread+0xd70>
    a91f:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a926:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a92d:	4c 89 e0             	mov    %r12,%rax
    a930:	48 c1 e2 10          	shl    $0x10,%rdx
    a934:	48 29 c8             	sub    %rcx,%rax
    a937:	48 39 d0             	cmp    %rdx,%rax
    a93a:	0f 83 24 fe ff ff    	jae    a764 <fwp_main_thread+0xaf4>
    a940:	48 89 c2             	mov    %rax,%rdx
    a943:	48 c1 ea 10          	shr    $0x10,%rdx
    a947:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a94b:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a952:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a956:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a95a:	48 85 ff             	test   %rdi,%rdi
    a95d:	0f 84 01 fe ff ff    	je     a764 <fwp_main_thread+0xaf4>
    a963:	0f b6 0a             	movzbl (%rdx),%ecx
    a966:	80 f9 02             	cmp    $0x2,%cl
    a969:	0f 85 b1 fd ff ff    	jne    a720 <fwp_main_thread+0xab0>
    a96f:	66 85 c0             	test   %ax,%ax
    a972:	0f 85 ec fd ff ff    	jne    a764 <fwp_main_thread+0xaf4>
    a978:	e9 c1 fd ff ff       	jmp    a73e <fwp_main_thread+0xace>
    a97d:	0f 1f 00             	nopl   (%rax)
    a980:	66 85 c0             	test   %ax,%ax
    a983:	0f 85 d6 fe ff ff    	jne    a85f <fwp_main_thread+0xbef>
    a989:	80 3e ff             	cmpb   $0xff,(%rsi)
    a98c:	0f 85 ca fe ff ff    	jne    a85c <fwp_main_thread+0xbec>
    a992:	0f 1f 00             	nopl   (%rax)
    a995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a99c:	00 00 00 00 
    a9a0:	48 89 f7             	mov    %rsi,%rdi
    a9a3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a9a8:	e8 c3 ad ff ff       	call   5770 <fwp_rc_forget_slot>
    a9ad:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a9b2:	e9 a5 fe ff ff       	jmp    a85c <fwp_main_thread+0xbec>
    a9b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9be:	00 00 
    a9c0:	66 85 c0             	test   %ax,%ax
    a9c3:	0f 84 2b ff ff ff    	je     a8f4 <fwp_main_thread+0xc84>
    a9c9:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a9cd:	4d 85 ed             	test   %r13,%r13
    a9d0:	0f 85 49 ff ff ff    	jne    a91f <fwp_main_thread+0xcaf>
    a9d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9dd:	00 00 00 
    a9e0:	4c 89 e7             	mov    %r12,%rdi
    a9e3:	e8 f8 d6 ff ff       	call   80e0 <fwp_drop0>
    a9e8:	48 89 ef             	mov    %rbp,%rdi
    a9eb:	e8 f0 d6 ff ff       	call   80e0 <fwp_drop0>
    a9f0:	48 c7 05 65 46 00 00 	movq   $0x0,0x4665(%rip)        # f060 <v.2>
    a9f7:	00 00 00 00 
    a9fb:	c7 05 63 46 00 00 01 	movl   $0x1,0x4663(%rip)        # f068 <st.3>
    aa02:	00 00 00 
    aa05:	e9 be f3 ff ff       	jmp    9dc8 <fwp_main_thread+0x158>
    aa0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa10:	48 89 df             	mov    %rbx,%rdi
    aa13:	e8 98 af ff ff       	call   59b0 <fwp_mem_free>
    aa18:	e9 f5 fe ff ff       	jmp    a912 <fwp_main_thread+0xca2>
    aa1d:	0f 1f 00             	nopl   (%rax)
    aa20:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    aa24:	e9 53 f4 ff ff       	jmp    9e7c <fwp_main_thread+0x20c>
    aa29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa30:	66 85 c0             	test   %ax,%ax
    aa33:	0f 85 d9 fc ff ff    	jne    a712 <fwp_main_thread+0xaa2>
    aa39:	e9 ba fc ff ff       	jmp    a6f8 <fwp_main_thread+0xa88>
    aa3e:	66 90                	xchg   %ax,%ax
    aa40:	66 85 c0             	test   %ax,%ax
    aa43:	0f 85 21 fc ff ff    	jne    a66a <fwp_main_thread+0x9fa>
    aa49:	e9 10 fc ff ff       	jmp    a65e <fwp_main_thread+0x9ee>
    aa4e:	66 90                	xchg   %ax,%ax
    aa50:	66 85 c0             	test   %ax,%ax
    aa53:	0f 85 7f fb ff ff    	jne    a5d8 <fwp_main_thread+0x968>
    aa59:	e9 6e fb ff ff       	jmp    a5cc <fwp_main_thread+0x95c>
    aa5e:	66 90                	xchg   %ax,%ax
    aa60:	4c 89 ef             	mov    %r13,%rdi
    aa63:	e8 08 ad ff ff       	call   5770 <fwp_rc_forget_slot>
    aa68:	e9 44 fa ff ff       	jmp    a4b1 <fwp_main_thread+0x841>
    aa6d:	0f 1f 00             	nopl   (%rax)
    aa70:	4c 89 f0             	mov    %r14,%rax
    aa73:	48 c1 e8 11          	shr    $0x11,%rax
    aa77:	4c 31 f0             	xor    %r14,%rax
    aa7a:	48 89 c2             	mov    %rax,%rdx
    aa7d:	48 c1 ea 09          	shr    $0x9,%rdx
    aa81:	48 31 d0             	xor    %rdx,%rax
    aa84:	0f b6 d0             	movzbl %al,%edx
    aa87:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    aa8e:	00 
    aa8f:	48 85 c0             	test   %rax,%rax
    aa92:	75 19                	jne    aaad <fwp_main_thread+0xe3d>
    aa94:	e9 c7 00 00 00       	jmp    ab60 <fwp_main_thread+0xef0>
    aa99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aaa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aaa4:	48 85 c0             	test   %rax,%rax
    aaa7:	0f 84 b3 00 00 00    	je     ab60 <fwp_main_thread+0xef0>
    aaad:	48 89 c2             	mov    %rax,%rdx
    aab0:	4c 3b 30             	cmp    (%rax),%r14
    aab3:	75 eb                	jne    aaa0 <fwp_main_thread+0xe30>
    aab5:	48 8b 70 08          	mov    0x8(%rax),%rsi
    aab9:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    aabd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    aac1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aac8:	0f 85 44 fe ff ff    	jne    a912 <fwp_main_thread+0xca2>
    aace:	4c 89 f7             	mov    %r14,%rdi
    aad1:	e8 9a ac ff ff       	call   5770 <fwp_rc_forget_slot>
    aad6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    aada:	e9 33 fe ff ff       	jmp    a912 <fwp_main_thread+0xca2>
    aadf:	90                   	nop
    aae0:	e8 6b ab ff ff       	call   5650 <fwp_rc_wide_dup>
    aae5:	e9 7a fc ff ff       	jmp    a764 <fwp_main_thread+0xaf4>
    aaea:	48 83 3d e6 cc 05 00 	cmpq   $0x0,0x5cce6(%rip)        # 677d8 <fwp_root>
    aaf1:	00 
    aaf2:	c7 05 84 45 01 00 00 	movl   $0x0,0x14584(%rip)        # 1f080 <fwp_exit_code>
    aaf9:	00 00 00 
    aafc:	0f 84 04 f6 ff ff    	je     a106 <fwp_main_thread+0x496>
    ab02:	e9 04 8c ff ff       	jmp    370b <fwp_main_thread.cold>
    ab07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab0e:	00 00 
    ab10:	48 89 df             	mov    %rbx,%rdi
    ab13:	e8 58 ac ff ff       	call   5770 <fwp_rc_forget_slot>
    ab18:	e9 b8 fa ff ff       	jmp    a5d5 <fwp_main_thread+0x965>
    ab1d:	48 89 df             	mov    %rbx,%rdi
    ab20:	e8 4b ac ff ff       	call   5770 <fwp_rc_forget_slot>
    ab25:	e9 3d fb ff ff       	jmp    a667 <fwp_main_thread+0x9f7>
    ab2a:	48 89 df             	mov    %rbx,%rdi
    ab2d:	e8 3e ac ff ff       	call   5770 <fwp_rc_forget_slot>
    ab32:	e9 ca fb ff ff       	jmp    a701 <fwp_main_thread+0xa91>
    ab37:	48 8d 3d 3a 0f 00 00 	lea    0xf3a(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    ab3e:	e8 cd 98 ff ff       	call   4410 <fwp_trap>
    ab43:	48 8d 3d 4f 07 00 00 	lea    0x74f(%rip),%rdi        # b299 <_IO_stdin_used+0x299>
    ab4a:	e8 c1 98 ff ff       	call   4410 <fwp_trap>
    ab4f:	e8 ec 88 ff ff       	call   3440 <__stack_chk_fail@plt>
    ab54:	48 8d 3d 23 07 00 00 	lea    0x723(%rip),%rdi        # b27e <_IO_stdin_used+0x27e>
    ab5b:	e8 60 94 ff ff       	call   3fc0 <ad_raw_fail>
    ab60:	48 8d 3d 41 0e 00 00 	lea    0xe41(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    ab67:	e8 a4 98 ff ff       	call   4410 <fwp_trap>
    ab6c:	e9 9a 8b ff ff       	jmp    370b <fwp_main_thread.cold>
    ab71:	e9 95 8b ff ff       	jmp    370b <fwp_main_thread.cold>
    ab76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab7d:	00 00 00 

000000000000ab80 <__divmodti4>:
    ab80:	f3 0f 1e fa          	endbr64
    ab84:	55                   	push   %rbp
    ab85:	49 89 f1             	mov    %rsi,%r9
    ab88:	49 89 d2             	mov    %rdx,%r10
    ab8b:	48 89 fe             	mov    %rdi,%rsi
    ab8e:	49 89 cb             	mov    %rcx,%r11
    ab91:	48 89 e5             	mov    %rsp,%rbp
    ab94:	41 57                	push   %r15
    ab96:	41 56                	push   %r14
    ab98:	41 55                	push   %r13
    ab9a:	41 54                	push   %r12
    ab9c:	53                   	push   %rbx
    ab9d:	4c 89 c3             	mov    %r8,%rbx
    aba0:	45 31 c0             	xor    %r8d,%r8d
    aba3:	4d 85 c9             	test   %r9,%r9
    aba6:	79 12                	jns    abba <__divmodti4+0x3a>
    aba8:	31 ff                	xor    %edi,%edi
    abaa:	48 f7 de             	neg    %rsi
    abad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    abb4:	4c 19 cf             	sbb    %r9,%rdi
    abb7:	49 89 f9             	mov    %rdi,%r9
    abba:	4c 89 d8             	mov    %r11,%rax
    abbd:	4d 85 db             	test   %r11,%r11
    abc0:	0f 88 1a 01 00 00    	js     ace0 <__divmodti4+0x160>
    abc6:	4c 89 d9             	mov    %r11,%rcx
    abc9:	49 89 f3             	mov    %rsi,%r11
    abcc:	75 62                	jne    ac30 <__divmodti4+0xb0>
    abce:	4d 89 c4             	mov    %r8,%r12
    abd1:	4d 39 d1             	cmp    %r10,%r9
    abd4:	0f 83 46 01 00 00    	jae    ad20 <__divmodti4+0x1a0>
    abda:	4c 89 d8             	mov    %r11,%rax
    abdd:	4c 89 ca             	mov    %r9,%rdx
    abe0:	49 f7 f2             	div    %r10
    abe3:	49 89 c3             	mov    %rax,%r11
    abe6:	31 c0                	xor    %eax,%eax
    abe8:	48 89 d6             	mov    %rdx,%rsi
    abeb:	31 ff                	xor    %edi,%edi
    abed:	4c 89 d9             	mov    %r11,%rcx
    abf0:	48 89 c2             	mov    %rax,%rdx
    abf3:	48 89 c8             	mov    %rcx,%rax
    abf6:	4d 85 e4             	test   %r12,%r12
    abf9:	74 0a                	je     ac05 <__divmodti4+0x85>
    abfb:	48 f7 d8             	neg    %rax
    abfe:	48 83 d2 00          	adc    $0x0,%rdx
    ac02:	48 f7 da             	neg    %rdx
    ac05:	4d 85 c0             	test   %r8,%r8
    ac08:	74 0a                	je     ac14 <__divmodti4+0x94>
    ac0a:	48 f7 de             	neg    %rsi
    ac0d:	48 83 d7 00          	adc    $0x0,%rdi
    ac11:	48 f7 df             	neg    %rdi
    ac14:	48 89 33             	mov    %rsi,(%rbx)
    ac17:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ac1b:	5b                   	pop    %rbx
    ac1c:	41 5c                	pop    %r12
    ac1e:	41 5d                	pop    %r13
    ac20:	41 5e                	pop    %r14
    ac22:	41 5f                	pop    %r15
    ac24:	5d                   	pop    %rbp
    ac25:	c3                   	ret
    ac26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ac2d:	00 00 00 
    ac30:	4d 89 c4             	mov    %r8,%r12
    ac33:	49 39 c1             	cmp    %rax,%r9
    ac36:	0f 82 ce 00 00 00    	jb     ad0a <__divmodti4+0x18a>
    ac3c:	31 ff                	xor    %edi,%edi
    ac3e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ac43:	48 63 c7             	movslq %edi,%rax
    ac46:	be 40 00 00 00       	mov    $0x40,%esi
    ac4b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ac50:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ac55:	48 29 c6             	sub    %rax,%rsi
    ac58:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ac5d:	48 09 c8             	or     %rcx,%rax
    ac60:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ac65:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ac6a:	49 89 c6             	mov    %rax,%r14
    ac6d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ac71:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ac76:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ac7b:	49 09 c1             	or     %rax,%r9
    ac7e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ac82:	4c 89 c8             	mov    %r9,%rax
    ac85:	49 f7 f6             	div    %r14
    ac88:	48 89 d1             	mov    %rdx,%rcx
    ac8b:	49 89 c3             	mov    %rax,%r11
    ac8e:	49 89 c1             	mov    %rax,%r9
    ac91:	49 f7 e2             	mul    %r10
    ac94:	49 89 c6             	mov    %rax,%r14
    ac97:	49 89 d2             	mov    %rdx,%r10
    ac9a:	48 39 d1             	cmp    %rdx,%rcx
    ac9d:	72 07                	jb     aca6 <__divmodti4+0x126>
    ac9f:	75 17                	jne    acb8 <__divmodti4+0x138>
    aca1:	49 39 c7             	cmp    %rax,%r15
    aca4:	73 12                	jae    acb8 <__divmodti4+0x138>
    aca6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    acaa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    acae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    acb2:	49 89 d2             	mov    %rdx,%r10
    acb5:	49 89 c6             	mov    %rax,%r14
    acb8:	4c 89 f8             	mov    %r15,%rax
    acbb:	4c 29 f0             	sub    %r14,%rax
    acbe:	4c 19 d1             	sbb    %r10,%rcx
    acc1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    acc6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    accb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    acd0:	48 09 c6             	or     %rax,%rsi
    acd3:	48 89 cf             	mov    %rcx,%rdi
    acd6:	31 c0                	xor    %eax,%eax
    acd8:	4c 89 c9             	mov    %r9,%rcx
    acdb:	e9 10 ff ff ff       	jmp    abf0 <__divmodti4+0x70>
    ace0:	4c 89 d0             	mov    %r10,%rax
    ace3:	4c 89 da             	mov    %r11,%rdx
    ace6:	4d 89 c4             	mov    %r8,%r12
    ace9:	49 89 f3             	mov    %rsi,%r11
    acec:	48 f7 d8             	neg    %rax
    acef:	49 f7 d4             	not    %r12
    acf2:	48 83 d2 00          	adc    $0x0,%rdx
    acf6:	49 89 c2             	mov    %rax,%r10
    acf9:	48 f7 da             	neg    %rdx
    acfc:	48 89 d1             	mov    %rdx,%rcx
    acff:	0f 84 cc fe ff ff    	je     abd1 <__divmodti4+0x51>
    ad05:	49 39 d1             	cmp    %rdx,%r9
    ad08:	73 46                	jae    ad50 <__divmodti4+0x1d0>
    ad0a:	4c 89 cf             	mov    %r9,%rdi
    ad0d:	31 c0                	xor    %eax,%eax
    ad0f:	31 c9                	xor    %ecx,%ecx
    ad11:	e9 da fe ff ff       	jmp    abf0 <__divmodti4+0x70>
    ad16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad1d:	00 00 00 
    ad20:	4d 85 d2             	test   %r10,%r10
    ad23:	75 0d                	jne    ad32 <__divmodti4+0x1b2>
    ad25:	b8 01 00 00 00       	mov    $0x1,%eax
    ad2a:	31 d2                	xor    %edx,%edx
    ad2c:	49 f7 f2             	div    %r10
    ad2f:	49 89 c2             	mov    %rax,%r10
    ad32:	4c 89 c8             	mov    %r9,%rax
    ad35:	31 d2                	xor    %edx,%edx
    ad37:	49 f7 f2             	div    %r10
    ad3a:	49 89 c1             	mov    %rax,%r9
    ad3d:	4c 89 d8             	mov    %r11,%rax
    ad40:	49 f7 f2             	div    %r10
    ad43:	49 89 c3             	mov    %rax,%r11
    ad46:	4c 89 c8             	mov    %r9,%rax
    ad49:	e9 9a fe ff ff       	jmp    abe8 <__divmodti4+0x68>
    ad4e:	66 90                	xchg   %ax,%ax
    ad50:	45 31 f6             	xor    %r14d,%r14d
    ad53:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ad58:	44 89 f7             	mov    %r14d,%edi
    ad5b:	45 85 f6             	test   %r14d,%r14d
    ad5e:	0f 85 df fe ff ff    	jne    ac43 <__divmodti4+0xc3>
    ad64:	4c 39 ca             	cmp    %r9,%rdx
    ad67:	72 17                	jb     ad80 <__divmodti4+0x200>
    ad69:	31 c9                	xor    %ecx,%ecx
    ad6b:	48 39 c6             	cmp    %rax,%rsi
    ad6e:	73 10                	jae    ad80 <__divmodti4+0x200>
    ad70:	4c 89 cf             	mov    %r9,%rdi
    ad73:	31 c0                	xor    %eax,%eax
    ad75:	e9 76 fe ff ff       	jmp    abf0 <__divmodti4+0x70>
    ad7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad80:	4c 89 de             	mov    %r11,%rsi
    ad83:	b9 01 00 00 00       	mov    $0x1,%ecx
    ad88:	48 29 c6             	sub    %rax,%rsi
    ad8b:	49 19 d1             	sbb    %rdx,%r9
    ad8e:	eb e0                	jmp    ad70 <__divmodti4+0x1f0>

000000000000ad90 <atexit>:
    ad90:	f3 0f 1e fa          	endbr64
    ad94:	48 8b 15 6d 42 00 00 	mov    0x426d(%rip),%rdx        # f008 <__dso_handle>
    ad9b:	31 f6                	xor    %esi,%esi
    ad9d:	e9 7e 88 ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ada4 <_fini>:
    ada4:	f3 0f 1e fa          	endbr64
    ada8:	48 83 ec 08          	sub    $0x8,%rsp
    adac:	48 83 c4 08          	add    $0x8,%rsp
    adb0:	c3                   	ret
