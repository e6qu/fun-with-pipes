
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 8f 00 00 	mov    0x8fd9(%rip),%rax        # afe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 8e 00 00    	push   0x8e02(%rip)        # ae28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 8e 00 00    	jmp    *0x8e04(%rip)        # ae30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e 8c 00 00    	jmp    *0x8c7e(%rip)        # aff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae 8a 00 00    	jmp    *0x8aae(%rip)        # ae38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 8a 00 00    	jmp    *0x8aa6(%rip)        # ae40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e 8a 00 00    	jmp    *0x8a9e(%rip)        # ae48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 8a 00 00    	jmp    *0x8a96(%rip)        # ae50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e 8a 00 00    	jmp    *0x8a8e(%rip)        # ae58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 8a 00 00    	jmp    *0x8a86(%rip)        # ae60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e 8a 00 00    	jmp    *0x8a7e(%rip)        # ae68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 8a 00 00    	jmp    *0x8a76(%rip)        # ae70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e 8a 00 00    	jmp    *0x8a6e(%rip)        # ae78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 8a 00 00    	jmp    *0x8a66(%rip)        # ae80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e 8a 00 00    	jmp    *0x8a5e(%rip)        # ae88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 8a 00 00    	jmp    *0x8a56(%rip)        # ae90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e 8a 00 00    	jmp    *0x8a4e(%rip)        # ae98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 8a 00 00    	jmp    *0x8a46(%rip)        # aea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e 8a 00 00    	jmp    *0x8a3e(%rip)        # aea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 8a 00 00    	jmp    *0x8a36(%rip)        # aeb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e 8a 00 00    	jmp    *0x8a2e(%rip)        # aeb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 8a 00 00    	jmp    *0x8a26(%rip)        # aec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e 8a 00 00    	jmp    *0x8a1e(%rip)        # aec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 8a 00 00    	jmp    *0x8a16(%rip)        # aed0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e 8a 00 00    	jmp    *0x8a0e(%rip)        # aed8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 8a 00 00    	jmp    *0x8a06(%rip)        # aee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe 89 00 00    	jmp    *0x89fe(%rip)        # aee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 89 00 00    	jmp    *0x89f6(%rip)        # aef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee 89 00 00    	jmp    *0x89ee(%rip)        # aef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 89 00 00    	jmp    *0x89e6(%rip)        # af00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de 89 00 00    	jmp    *0x89de(%rip)        # af08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 89 00 00    	jmp    *0x89d6(%rip)        # af10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce 89 00 00    	jmp    *0x89ce(%rip)        # af18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 89 00 00    	jmp    *0x89c6(%rip)        # af20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be 89 00 00    	jmp    *0x89be(%rip)        # af28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 89 00 00    	jmp    *0x89b6(%rip)        # af30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae 89 00 00    	jmp    *0x89ae(%rip)        # af38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 89 00 00    	jmp    *0x89a6(%rip)        # af40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e 89 00 00    	jmp    *0x899e(%rip)        # af48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 89 00 00    	jmp    *0x8996(%rip)        # af50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e 89 00 00    	jmp    *0x898e(%rip)        # af58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 89 00 00    	jmp    *0x8986(%rip)        # af60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e 89 00 00    	jmp    *0x897e(%rip)        # af68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 89 00 00    	jmp    *0x8976(%rip)        # af70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e 89 00 00    	jmp    *0x896e(%rip)        # af78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 89 00 00    	jmp    *0x8966(%rip)        # af80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e 89 00 00    	jmp    *0x895e(%rip)        # af88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 89 00 00    	jmp    *0x8956(%rip)        # af90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e 89 00 00    	jmp    *0x894e(%rip)        # af98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 89 00 00    	jmp    *0x8946(%rip)        # afa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e 89 00 00    	jmp    *0x893e(%rip)        # afa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 89 00 00    	jmp    *0x8936(%rip)        # afb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e 89 00 00    	jmp    *0x892e(%rip)        # afb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 89 00 00    	jmp    *0x8926(%rip)        # afc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e 89 00 00    	jmp    *0x891e(%rip)        # afc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 89 00 00    	jmp    *0x8916(%rip)        # afd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 59 00 00 	lea    0x59a0(%rip),%r9        # 8077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 59 00 00 	lea    0x599d(%rip),%r8        # 807b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 1a 0a 00 00       	call   3120 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 88 00 00 	mov    0x88e1(%rip),%rax        # b020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 f2 ab 01 00 	mov    %rax,0x1abf2(%rip)        # 1d338 <fwp_prog_out>
    2746:	e8 05 0a 00 00       	call   3150 <fwp_now_ns>
    274b:	48 8d 3d 1a 5a 00 00 	lea    0x5a1a(%rip),%rdi        # 816c <_IO_stdin_used+0x16c>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 88 00 00 	mov    0x8866(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 dd 4d 00 00 	lea    0x4ddd(%rip),%rdx        # 75f0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d d1 87 00 00 	mov    0x87d1(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 88 01 00    	mov    0x18826(%rip),%eax        # 1b080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d ca 58 00 00 	lea    0x58ca(%rip),%rdi        # 8175 <_IO_stdin_used+0x175>
    28ab:	e8 70 08 00 00       	call   3120 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d f4 5a 00 00 	lea    0x5af4(%rip),%rdi        # 83b0 <_IO_stdin_used+0x3b0>
    28bc:	e8 5f 08 00 00       	call   3120 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d ae 5a 00 00 	lea    0x5aae(%rip),%rdi        # 8388 <_IO_stdin_used+0x388>
    28da:	e8 41 08 00 00       	call   3120 <fwp_trap>
    28df:	48 8d 3d 72 5a 00 00 	lea    0x5a72(%rip),%rdi        # 8358 <_IO_stdin_used+0x358>
    28e6:	e8 35 08 00 00       	call   3120 <fwp_trap>
    28eb:	48 8d 3d 3e 5a 00 00 	lea    0x5a3e(%rip),%rdi        # 8330 <_IO_stdin_used+0x330>
    28f2:	e8 29 08 00 00       	call   3120 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 86 00 00    	call   *0x86b3(%rip)        # afd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 86 00 00 	lea    0x86e1(%rip),%rdi        # b018 <__TMC_END__>
    2937:	48 8d 05 da 86 00 00 	lea    0x86da(%rip),%rax        # b018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 86 00 00 	mov    0x8696(%rip),%rax        # afe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 86 00 00 	lea    0x86b1(%rip),%rdi        # b018 <__TMC_END__>
    2967:	48 8d 35 aa 86 00 00 	lea    0x86aa(%rip),%rsi        # b018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 86 00 00 	mov    0x8665(%rip),%rax        # aff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d 86 00 00 00 	cmpb   $0x0,0x869d(%rip)        # b048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 86 00 00 	cmpq   $0x0,0x8642(%rip)        # aff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 86 00 00 	mov    0x8646(%rip),%rdi        # b008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 86 00 00 01 	movb   $0x1,0x8675(%rip)        # b048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_owned_entry32>:
    2bc0:	f3 0f 1e fa          	endbr64
    2bc4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bc9:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    2bcd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2bd2:	c3                   	ret
    2bd3:	66 90                	xchg   %ax,%ax
    2bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bdc:	00 00 00 00 

0000000000002be0 <fwp_args32>:
    2be0:	f3 0f 1e fa          	endbr64
    2be4:	c3                   	ret
    2be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bec:	00 00 00 00 

0000000000002bf0 <fwp_owned_entry45>:
    2bf0:	f3 0f 1e fa          	endbr64
    2bf4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bf9:	f2 0f 58 07          	addsd  (%rdi),%xmm0
    2bfd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c02:	c3                   	ret
    2c03:	66 90                	xchg   %ax,%ax
    2c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c0c:	00 00 00 00 

0000000000002c10 <fwp_owned_entry69>:
    2c10:	f3 0f 1e fa          	endbr64
    2c14:	f2 0f 10 05 54 58 00 	movsd  0x5854(%rip),%xmm0        # 8470 <msg.3+0x20>
    2c1b:	00 
    2c1c:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    2c20:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c25:	c3                   	ret
    2c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2c2d:	00 00 00 

0000000000002c30 <fwp_flush>:
    2c30:	48 8b 3d 01 a7 01 00 	mov    0x1a701(%rip),%rdi        # 1d338 <fwp_prog_out>
    2c37:	48 85 ff             	test   %rdi,%rdi
    2c3a:	74 1c                	je     2c58 <fwp_flush+0x28>
    2c3c:	48 83 ec 08          	sub    $0x8,%rsp
    2c40:	e8 4b f9 ff ff       	call   2590 <fflush@plt>
    2c45:	48 8b 3d d4 83 00 00 	mov    0x83d4(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    2c4c:	48 83 c4 08          	add    $0x8,%rsp
    2c50:	e9 3b f9 ff ff       	jmp    2590 <fflush@plt>
    2c55:	0f 1f 00             	nopl   (%rax)
    2c58:	48 8b 3d c1 83 00 00 	mov    0x83c1(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    2c5f:	e9 2c f9 ff ff       	jmp    2590 <fflush@plt>
    2c64:	90                   	nop
    2c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c6c:	00 00 00 00 

0000000000002c70 <fwp_heap_oom>:
    2c70:	50                   	push   %rax
    2c71:	58                   	pop    %rax
    2c72:	ba 13 00 00 00       	mov    $0x13,%edx
    2c77:	be 01 00 00 00       	mov    $0x1,%esi
    2c7c:	48 8d 3d 85 53 00 00 	lea    0x5385(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2c83:	48 83 ec 08          	sub    $0x8,%rsp
    2c87:	48 8b 0d b2 83 00 00 	mov    0x83b2(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    2c8e:	e8 ad f9 ff ff       	call   2640 <fwrite@plt>
    2c93:	31 ff                	xor    %edi,%edi
    2c95:	e8 f6 f8 ff ff       	call   2590 <fflush@plt>
    2c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c9f:	e8 bc f9 ff ff       	call   2660 <_Exit@plt>
    2ca4:	90                   	nop
    2ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cac:	00 00 00 00 

0000000000002cb0 <fwp_segv>:
    2cb0:	f3 0f 1e fa          	endbr64
    2cb4:	48 83 ec 28          	sub    $0x28,%rsp
    2cb8:	48 8b 05 01 8a 01 00 	mov    0x18a01(%rip),%rax        # 1b6c0 <fwp_cur>
    2cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2cc3:	41 89 f8             	mov    %edi,%r8d
    2cc6:	48 85 c0             	test   %rax,%rax
    2cc9:	74 6d                	je     2d38 <fwp_segv+0x88>
    2ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2ccf:	48 85 d2             	test   %rdx,%rdx
    2cd2:	74 64                	je     2d38 <fwp_segv+0x88>
    2cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2ce7:	e8 14 f9 ff ff       	call   2600 <sysconf@plt>
    2cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2cfb:	48 01 d0             	add    %rdx,%rax
    2cfe:	48 39 c1             	cmp    %rax,%rcx
    2d01:	b8 00 00 00 00       	mov    $0x0,%eax
    2d06:	40 0f 92 c6          	setb   %sil
    2d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    2d15:	31 c0                	xor    %eax,%eax
    2d17:	48 39 d1             	cmp    %rdx,%rcx
    2d1a:	0f 93 c0             	setae  %al
    2d1d:	21 f0                	and    %esi,%eax
    2d1f:	85 c0                	test   %eax,%eax
    2d21:	75 4a                	jne    2d6d <fwp_segv+0xbd>
    2d23:	31 f6                	xor    %esi,%esi
    2d25:	44 89 c7             	mov    %r8d,%edi
    2d28:	48 83 c4 28          	add    $0x28,%rsp
    2d2c:	e9 ef f7 ff ff       	jmp    2520 <signal@plt>
    2d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2d38:	48 8b 05 51 83 01 00 	mov    0x18351(%rip),%rax        # 1b090 <fwp_main_stack_top>
    2d3f:	48 85 c0             	test   %rax,%rax
    2d42:	74 df                	je     2d23 <fwp_segv+0x73>
    2d44:	48 2b 05 3d 83 01 00 	sub    0x1833d(%rip),%rax        # 1b088 <fwp_main_stack_size>
    2d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2d52:	48 39 d1             	cmp    %rdx,%rcx
    2d55:	0f 93 c2             	setae  %dl
    2d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    2d5e:	48 39 c1             	cmp    %rax,%rcx
    2d61:	0f 92 c0             	setb   %al
    2d64:	0f b6 c0             	movzbl %al,%eax
    2d67:	21 d0                	and    %edx,%eax
    2d69:	85 c0                	test   %eax,%eax
    2d6b:	74 b6                	je     2d23 <fwp_segv+0x73>
    2d6d:	e8 be fe ff ff       	call   2c30 <fwp_flush>
    2d72:	bf 02 00 00 00       	mov    $0x2,%edi
    2d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d7c:	48 8d 35 cd 56 00 00 	lea    0x56cd(%rip),%rsi        # 8450 <msg.3>
    2d83:	e8 88 f6 ff ff       	call   2410 <write@plt>
    2d88:	bf 65 00 00 00       	mov    $0x65,%edi
    2d8d:	e8 2e f6 ff ff       	call   23c0 <_exit@plt>
    2d92:	0f 1f 00             	nopl   (%rax)
    2d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d9c:	00 00 00 00 

0000000000002da0 <fwp_heap_chunks>:
    2da0:	41 54                	push   %r12
    2da2:	55                   	push   %rbp
    2da3:	53                   	push   %rbx
    2da4:	48 83 ff 01          	cmp    $0x1,%rdi
    2da8:	0f 84 62 01 00 00    	je     2f10 <fwp_heap_chunks+0x170>
    2dae:	48 8b 05 1b 9d 01 00 	mov    0x19d1b(%rip),%rax        # 1cad0 <fwp_heap+0x13f0>
    2db5:	4c 8d 05 14 9d 01 00 	lea    0x19d14(%rip),%r8        # 1cad0 <fwp_heap+0x13f0>
    2dbc:	48 8b 1d f5 9c 01 00 	mov    0x19cf5(%rip),%rbx        # 1cab8 <fwp_heap+0x13d8>
    2dc3:	48 39 d8             	cmp    %rbx,%rax
    2dc6:	0f 83 57 01 00 00    	jae    2f23 <fwp_heap_chunks+0x183>
    2dcc:	48 8b 0d 05 9d 01 00 	mov    0x19d05(%rip),%rcx        # 1cad8 <fwp_heap+0x13f8>
    2dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2dd7:	31 f6                	xor    %esi,%esi
    2dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2ddd:	eb 1e                	jmp    2dfd <fwp_heap_chunks+0x5d>
    2ddf:	90                   	nop
    2de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2de4:	48 39 cf             	cmp    %rcx,%rdi
    2de7:	0f 84 03 01 00 00    	je     2ef0 <fwp_heap_chunks+0x150>
    2ded:	48 83 c0 01          	add    $0x1,%rax
    2df1:	48 89 ce             	mov    %rcx,%rsi
    2df4:	48 83 c2 28          	add    $0x28,%rdx
    2df8:	48 39 c3             	cmp    %rax,%rbx
    2dfb:	74 14                	je     2e11 <fwp_heap_chunks+0x71>
    2dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    2e00:	74 de                	je     2de0 <fwp_heap_chunks+0x40>
    2e02:	48 83 c0 01          	add    $0x1,%rax
    2e06:	31 f6                	xor    %esi,%esi
    2e08:	48 83 c2 28          	add    $0x28,%rdx
    2e0c:	48 39 c3             	cmp    %rax,%rbx
    2e0f:	75 ec                	jne    2dfd <fwp_heap_chunks+0x5d>
    2e11:	48 29 f3             	sub    %rsi,%rbx
    2e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2e18:	48 8b 3d a1 9c 01 00 	mov    0x19ca1(%rip),%rdi        # 1cac0 <fwp_heap+0x13e0>
    2e1f:	48 29 35 ea 9c 01 00 	sub    %rsi,0x19cea(%rip)        # 1cb10 <fwp_heap+0x1430>
    2e26:	48 39 ef             	cmp    %rbp,%rdi
    2e29:	0f 83 96 00 00 00    	jae    2ec5 <fwp_heap_chunks+0x125>
    2e2f:	48 8b 05 7a 9c 01 00 	mov    0x19c7a(%rip),%rax        # 1cab0 <fwp_heap+0x13d0>
    2e36:	48 39 e8             	cmp    %rbp,%rax
    2e39:	0f 82 eb 00 00 00    	jb     2f2a <fwp_heap_chunks+0x18a>
    2e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2e43:	ba 03 00 00 00       	mov    $0x3,%edx
    2e48:	49 39 c4             	cmp    %rax,%r12
    2e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    2e4f:	4c 89 e6             	mov    %r12,%rsi
    2e52:	48 29 fe             	sub    %rdi,%rsi
    2e55:	48 c1 e7 10          	shl    $0x10,%rdi
    2e59:	48 03 3d 30 9c 01 00 	add    0x19c30(%rip),%rdi        # 1ca90 <fwp_heap+0x13b0>
    2e60:	48 c1 e6 10          	shl    $0x10,%rsi
    2e64:	e8 77 f7 ff ff       	call   25e0 <mprotect@plt>
    2e69:	85 c0                	test   %eax,%eax
    2e6b:	0f 85 b9 00 00 00    	jne    2f2a <fwp_heap_chunks+0x18a>
    2e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e76:	e8 85 f7 ff ff       	call   2600 <sysconf@plt>
    2e7b:	48 8b 35 3e 9c 01 00 	mov    0x19c3e(%rip),%rsi        # 1cac0 <fwp_heap+0x13e0>
    2e82:	48 89 c1             	mov    %rax,%rcx
    2e85:	48 8b 05 4c 9c 01 00 	mov    0x19c4c(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    2e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e90:	48 89 ca             	mov    %rcx,%rdx
    2e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e9b:	48 f7 da             	neg    %rdx
    2e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2ea3:	48 21 d7             	and    %rdx,%rdi
    2ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2eaa:	48 21 d6             	and    %rdx,%rsi
    2ead:	ba 03 00 00 00       	mov    $0x3,%edx
    2eb2:	48 29 fe             	sub    %rdi,%rsi
    2eb5:	e8 26 f7 ff ff       	call   25e0 <mprotect@plt>
    2eba:	85 c0                	test   %eax,%eax
    2ebc:	75 6c                	jne    2f2a <fwp_heap_chunks+0x18a>
    2ebe:	4c 89 25 fb 9b 01 00 	mov    %r12,0x19bfb(%rip)        # 1cac0 <fwp_heap+0x13e0>
    2ec5:	48 89 ef             	mov    %rbp,%rdi
    2ec8:	48 89 2d e9 9b 01 00 	mov    %rbp,0x19be9(%rip)        # 1cab8 <fwp_heap+0x13d8>
    2ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    2ed3:	48 39 3d ce 9b 01 00 	cmp    %rdi,0x19bce(%rip)        # 1caa8 <fwp_heap+0x13c8>
    2eda:	73 07                	jae    2ee3 <fwp_heap_chunks+0x143>
    2edc:	48 89 3d c5 9b 01 00 	mov    %rdi,0x19bc5(%rip)        # 1caa8 <fwp_heap+0x13c8>
    2ee3:	48 89 d8             	mov    %rbx,%rax
    2ee6:	5b                   	pop    %rbx
    2ee7:	5d                   	pop    %rbp
    2ee8:	41 5c                	pop    %r12
    2eea:	c3                   	ret
    2eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2ef4:	48 29 f0             	sub    %rsi,%rax
    2ef7:	48 89 c3             	mov    %rax,%rbx
    2efa:	49 89 10             	mov    %rdx,(%r8)
    2efd:	48 89 d8             	mov    %rbx,%rax
    2f00:	48 29 3d 09 9c 01 00 	sub    %rdi,0x19c09(%rip)        # 1cb10 <fwp_heap+0x1430>
    2f07:	5b                   	pop    %rbx
    2f08:	5d                   	pop    %rbp
    2f09:	41 5c                	pop    %r12
    2f0b:	c3                   	ret
    2f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    2f10:	48 8b 05 b1 9b 01 00 	mov    0x19bb1(%rip),%rax        # 1cac8 <fwp_heap+0x13e8>
    2f17:	4c 8d 05 aa 9b 01 00 	lea    0x19baa(%rip),%r8        # 1cac8 <fwp_heap+0x13e8>
    2f1e:	e9 99 fe ff ff       	jmp    2dbc <fwp_heap_chunks+0x1c>
    2f23:	31 f6                	xor    %esi,%esi
    2f25:	e9 ea fe ff ff       	jmp    2e14 <fwp_heap_chunks+0x74>
    2f2a:	e8 41 fd ff ff       	call   2c70 <fwp_heap_oom>
    2f2f:	90                   	nop

0000000000002f30 <buf_grow>:
    2f30:	48 83 ec 18          	sub    $0x18,%rsp
    2f34:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2f38:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2f3c:	74 7e                	je     2fbc <buf_grow+0x8c>
    2f3e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f45:	48 29 c2             	sub    %rax,%rdx
    2f48:	48 39 f2             	cmp    %rsi,%rdx
    2f4b:	72 6f                	jb     2fbc <buf_grow+0x8c>
    2f4d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f52:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f56:	48 89 f9             	mov    %rdi,%rcx
    2f59:	48 39 d0             	cmp    %rdx,%rax
    2f5c:	73 48                	jae    2fa6 <buf_grow+0x76>
    2f5e:	48 85 c0             	test   %rax,%rax
    2f61:	75 15                	jne    2f78 <buf_grow+0x48>
    2f63:	48 83 fa 40          	cmp    $0x40,%rdx
    2f67:	76 4c                	jbe    2fb5 <buf_grow+0x85>
    2f69:	b8 40 00 00 00       	mov    $0x40,%eax
    2f6e:	eb 08                	jmp    2f78 <buf_grow+0x48>
    2f70:	48 01 c0             	add    %rax,%rax
    2f73:	48 39 d0             	cmp    %rdx,%rax
    2f76:	73 38                	jae    2fb0 <buf_grow+0x80>
    2f78:	48 85 c0             	test   %rax,%rax
    2f7b:	79 f3                	jns    2f70 <buf_grow+0x40>
    2f7d:	48 8b 39             	mov    (%rcx),%rdi
    2f80:	48 89 d6             	mov    %rdx,%rsi
    2f83:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f88:	48 89 14 24          	mov    %rdx,(%rsp)
    2f8c:	e8 0f f6 ff ff       	call   25a0 <realloc@plt>
    2f91:	48 8b 14 24          	mov    (%rsp),%rdx
    2f95:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f9a:	48 85 c0             	test   %rax,%rax
    2f9d:	74 1d                	je     2fbc <buf_grow+0x8c>
    2f9f:	48 89 01             	mov    %rax,(%rcx)
    2fa2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2fa6:	48 83 c4 18          	add    $0x18,%rsp
    2faa:	c3                   	ret
    2fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fb0:	48 89 c2             	mov    %rax,%rdx
    2fb3:	eb c8                	jmp    2f7d <buf_grow+0x4d>
    2fb5:	ba 40 00 00 00       	mov    $0x40,%edx
    2fba:	eb c1                	jmp    2f7d <buf_grow+0x4d>
    2fbc:	48 8b 0d 7d 80 00 00 	mov    0x807d(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    2fc3:	ba 13 00 00 00       	mov    $0x13,%edx
    2fc8:	be 01 00 00 00       	mov    $0x1,%esi
    2fcd:	48 8d 3d 34 50 00 00 	lea    0x5034(%rip),%rdi        # 8008 <_IO_stdin_used+0x8>
    2fd4:	e8 67 f6 ff ff       	call   2640 <fwrite@plt>
    2fd9:	31 ff                	xor    %edi,%edi
    2fdb:	e8 b0 f5 ff ff       	call   2590 <fflush@plt>
    2fe0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fe5:	e8 76 f6 ff ff       	call   2660 <_Exit@plt>
    2fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002ff0 <buf_put>:
    2ff0:	41 54                	push   %r12
    2ff2:	49 89 f4             	mov    %rsi,%r12
    2ff5:	48 89 d6             	mov    %rdx,%rsi
    2ff8:	55                   	push   %rbp
    2ff9:	48 89 fd             	mov    %rdi,%rbp
    2ffc:	53                   	push   %rbx
    2ffd:	48 89 d3             	mov    %rdx,%rbx
    3000:	e8 2b ff ff ff       	call   2f30 <buf_grow>
    3005:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    3009:	48 89 da             	mov    %rbx,%rdx
    300c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    3010:	4c 89 e6             	mov    %r12,%rsi
    3013:	e8 58 f5 ff ff       	call   2570 <memcpy@plt>
    3018:	48 8b 45 00          	mov    0x0(%rbp),%rax
    301c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    3020:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    3024:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    3028:	5b                   	pop    %rbx
    3029:	5d                   	pop    %rbp
    302a:	41 5c                	pop    %r12
    302c:	c3                   	ret
    302d:	0f 1f 00             	nopl   (%rax)

0000000000003030 <fwp_cancel_tree.part.0>:
    3030:	48 3b 3d 89 86 01 00 	cmp    0x18689(%rip),%rdi        # 1b6c0 <fwp_cur>
    3037:	53                   	push   %rbx
    3038:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    303c:	74 35                	je     3073 <fwp_cancel_tree.part.0+0x43>
    303e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3042:	75 2f                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    3044:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3048:	75 29                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    304a:	48 8b 05 4f 86 01 00 	mov    0x1864f(%rip),%rax        # 1b6a0 <fwp_ready_tail>
    3051:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3055:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    305c:	00 00 00 00 
    3060:	48 85 c0             	test   %rax,%rax
    3063:	74 33                	je     3098 <fwp_cancel_tree.part.0+0x68>
    3065:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    306c:	48 89 3d 2d 86 01 00 	mov    %rdi,0x1862d(%rip)        # 1b6a0 <fwp_ready_tail>
    3073:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3077:	48 85 db             	test   %rbx,%rbx
    307a:	74 17                	je     3093 <fwp_cancel_tree.part.0+0x63>
    307c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3080:	75 08                	jne    308a <fwp_cancel_tree.part.0+0x5a>
    3082:	48 89 df             	mov    %rbx,%rdi
    3085:	e8 a6 ff ff ff       	call   3030 <fwp_cancel_tree.part.0>
    308a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    308e:	48 85 db             	test   %rbx,%rbx
    3091:	75 e9                	jne    307c <fwp_cancel_tree.part.0+0x4c>
    3093:	5b                   	pop    %rbx
    3094:	c3                   	ret
    3095:	0f 1f 00             	nopl   (%rax)
    3098:	48 89 3d 09 86 01 00 	mov    %rdi,0x18609(%rip)        # 1b6a8 <fwp_ready_head>
    309f:	eb cb                	jmp    306c <fwp_cancel_tree.part.0+0x3c>
    30a1:	0f 1f 40 00          	nopl   0x0(%rax)
    30a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    30ac:	00 00 00 00 

00000000000030b0 <fwp_finish_float>:
    30b0:	53                   	push   %rbx
    30b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    30b6:	48 89 fb             	mov    %rdi,%rbx
    30b9:	e8 a2 f3 ff ff       	call   2460 <strchr@plt>
    30be:	48 85 c0             	test   %rax,%rax
    30c1:	74 05                	je     30c8 <fwp_finish_float+0x18>
    30c3:	5b                   	pop    %rbx
    30c4:	c3                   	ret
    30c5:	0f 1f 00             	nopl   (%rax)
    30c8:	be 65 00 00 00       	mov    $0x65,%esi
    30cd:	48 89 df             	mov    %rbx,%rdi
    30d0:	e8 8b f3 ff ff       	call   2460 <strchr@plt>
    30d5:	48 85 c0             	test   %rax,%rax
    30d8:	75 e9                	jne    30c3 <fwp_finish_float+0x13>
    30da:	48 8d 35 f8 4f 00 00 	lea    0x4ff8(%rip),%rsi        # 80d9 <_IO_stdin_used+0xd9>
    30e1:	48 89 df             	mov    %rbx,%rdi
    30e4:	e8 a7 f5 ff ff       	call   2690 <strstr@plt>
    30e9:	48 85 c0             	test   %rax,%rax
    30ec:	75 d5                	jne    30c3 <fwp_finish_float+0x13>
    30ee:	48 8d 35 27 4f 00 00 	lea    0x4f27(%rip),%rsi        # 801c <_IO_stdin_used+0x1c>
    30f5:	48 89 df             	mov    %rbx,%rdi
    30f8:	e8 93 f5 ff ff       	call   2690 <strstr@plt>
    30fd:	48 85 c0             	test   %rax,%rax
    3100:	75 c1                	jne    30c3 <fwp_finish_float+0x13>
    3102:	48 89 df             	mov    %rbx,%rdi
    3105:	e8 26 f3 ff ff       	call   2430 <strlen@plt>
    310a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    310f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    3113:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    3118:	5b                   	pop    %rbx
    3119:	c3                   	ret
    311a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003120 <fwp_trap>:
    3120:	53                   	push   %rbx
    3121:	48 89 fb             	mov    %rdi,%rbx
    3124:	e8 07 fb ff ff       	call   2c30 <fwp_flush>
    3129:	48 89 d9             	mov    %rbx,%rcx
    312c:	be 02 00 00 00       	mov    $0x2,%esi
    3131:	31 c0                	xor    %eax,%eax
    3133:	48 8b 3d 06 7f 00 00 	mov    0x7f06(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    313a:	48 8d 15 df 4e 00 00 	lea    0x4edf(%rip),%rdx        # 8020 <_IO_stdin_used+0x20>
    3141:	e8 0a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3146:	bf 65 00 00 00       	mov    $0x65,%edi
    314b:	e8 e0 f4 ff ff       	call   2630 <exit@plt>

0000000000003150 <fwp_now_ns>:
    3150:	53                   	push   %rbx
    3151:	bf 01 00 00 00       	mov    $0x1,%edi
    3156:	48 83 ec 20          	sub    $0x20,%rsp
    315a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3161:	00 00 
    3163:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3168:	31 db                	xor    %ebx,%ebx
    316a:	48 89 e6             	mov    %rsp,%rsi
    316d:	e8 8e f2 ff ff       	call   2400 <clock_gettime@plt>
    3172:	85 c0                	test   %eax,%eax
    3174:	75 52                	jne    31c8 <fwp_now_ns+0x78>
    3176:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    317b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3180:	48 f7 2c 24          	imulq  (%rsp)
    3184:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    318b:	48 89 f7             	mov    %rsi,%rdi
    318e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3192:	48 01 f0             	add    %rsi,%rax
    3195:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    319c:	00 00 80 
    319f:	48 11 fa             	adc    %rdi,%rdx
    31a2:	31 ff                	xor    %edi,%edi
    31a4:	48 01 c6             	add    %rax,%rsi
    31a7:	48 11 d7             	adc    %rdx,%rdi
    31aa:	48 39 f1             	cmp    %rsi,%rcx
    31ad:	48 19 fb             	sbb    %rdi,%rbx
    31b0:	72 27                	jb     31d9 <fwp_now_ns+0x89>
    31b2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    31b7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    31be:	00 00 
    31c0:	75 12                	jne    31d4 <fwp_now_ns+0x84>
    31c2:	48 83 c4 20          	add    $0x20,%rsp
    31c6:	5b                   	pop    %rbx
    31c7:	c3                   	ret
    31c8:	48 8d 3d 60 4e 00 00 	lea    0x4e60(%rip),%rdi        # 802f <_IO_stdin_used+0x2f>
    31cf:	e8 4c ff ff ff       	call   3120 <fwp_trap>
    31d4:	e8 67 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31d9:	48 8d 3d c0 4f 00 00 	lea    0x4fc0(%rip),%rdi        # 81a0 <_IO_stdin_used+0x1a0>
    31e0:	e8 3b ff ff ff       	call   3120 <fwp_trap>
    31e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31ec:	00 00 00 00 

00000000000031f0 <fwp_args74>:
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	c3                   	ret
    31f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31fc:	00 00 00 00 

0000000000003200 <fwp_format_g.constprop.0>:
    3200:	41 57                	push   %r15
    3202:	b9 40 00 00 00       	mov    $0x40,%ecx
    3207:	ba 02 00 00 00       	mov    $0x2,%edx
    320c:	4c 8d 05 38 4e 00 00 	lea    0x4e38(%rip),%r8        # 804b <_IO_stdin_used+0x4b>
    3213:	41 56                	push   %r14
    3215:	b8 01 00 00 00       	mov    $0x1,%eax
    321a:	41 55                	push   %r13
    321c:	41 54                	push   %r12
    321e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    3222:	55                   	push   %rbp
    3223:	45 89 e1             	mov    %r12d,%r9d
    3226:	53                   	push   %rbx
    3227:	48 89 fb             	mov    %rdi,%rbx
    322a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3231:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3238:	00 00 
    323a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3241:	00 
    3242:	41 89 f7             	mov    %esi,%r15d
    3245:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    324a:	be 40 00 00 00       	mov    $0x40,%esi
    324f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3254:	4c 89 f7             	mov    %r14,%rdi
    3257:	e8 34 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    325c:	be 65 00 00 00       	mov    $0x65,%esi
    3261:	4c 89 f7             	mov    %r14,%rdi
    3264:	e8 f7 f1 ff ff       	call   2460 <strchr@plt>
    3269:	31 f6                	xor    %esi,%esi
    326b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3270:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3274:	48 89 c5             	mov    %rax,%rbp
    3277:	e8 e4 f2 ff ff       	call   2560 <strtol@plt>
    327c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3281:	49 89 c0             	mov    %rax,%r8
    3284:	83 c0 05             	add    $0x5,%eax
    3287:	83 f8 15             	cmp    $0x15,%eax
    328a:	0f 87 f0 01 00 00    	ja     3480 <fwp_format_g.constprop.0+0x280>
    3290:	45 89 e5             	mov    %r12d,%r13d
    3293:	45 29 c5             	sub    %r8d,%r13d
    3296:	45 85 ed             	test   %r13d,%r13d
    3299:	0f 8e 21 01 00 00    	jle    33c0 <fwp_format_g.constprop.0+0x1c0>
    329f:	41 83 ff 01          	cmp    $0x1,%r15d
    32a3:	0f 84 17 01 00 00    	je     33c0 <fwp_format_g.constprop.0+0x1c0>
    32a9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    32ae:	31 d2                	xor    %edx,%edx
    32b0:	4d 63 df             	movslq %r15d,%r11
    32b3:	3c 2d                	cmp    $0x2d,%al
    32b5:	0f 94 c2             	sete   %dl
    32b8:	4c 29 dd             	sub    %r11,%rbp
    32bb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    32bf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    32c3:	4d 89 f1             	mov    %r14,%r9
    32c6:	4d 29 d1             	sub    %r10,%r9
    32c9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    32cd:	3c 2d                	cmp    $0x2d,%al
    32cf:	0f 84 0b 04 00 00    	je     36e0 <fwp_format_g.constprop.0+0x4e0>
    32d5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    32da:	b9 48 00 00 00       	mov    $0x48,%ecx
    32df:	48 89 e8             	mov    %rbp,%rax
    32e2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    32e6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    32ea:	49 83 c1 47          	add    $0x47,%r9
    32ee:	45 85 c0             	test   %r8d,%r8d
    32f1:	0f 88 01 03 00 00    	js     35f8 <fwp_format_g.constprop.0+0x3f8>
    32f7:	45 0f b6 12          	movzbl (%r10),%r10d
    32fb:	4d 63 e0             	movslq %r8d,%r12
    32fe:	44 88 10             	mov    %r10b,(%rax)
    3301:	41 83 f8 07          	cmp    $0x7,%r8d
    3305:	0f 87 3d 02 00 00    	ja     3548 <fwp_format_g.constprop.0+0x348>
    330b:	41 f6 c4 04          	test   $0x4,%r12b
    330f:	0f 85 02 04 00 00    	jne    3717 <fwp_format_g.constprop.0+0x517>
    3315:	45 85 e4             	test   %r12d,%r12d
    3318:	74 12                	je     332c <fwp_format_g.constprop.0+0x12c>
    331a:	45 0f b6 06          	movzbl (%r14),%r8d
    331e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    3322:	41 f6 c4 02          	test   $0x2,%r12b
    3326:	0f 85 13 04 00 00    	jne    373f <fwp_format_g.constprop.0+0x53f>
    332c:	4c 29 e1             	sub    %r12,%rcx
    332f:	4c 01 e7             	add    %r12,%rdi
    3332:	4c 89 fa             	mov    %r15,%rdx
    3335:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    333a:	48 83 e9 01          	sub    $0x1,%rcx
    333e:	4d 63 ed             	movslq %r13d,%r13
    3341:	48 89 0c 24          	mov    %rcx,(%rsp)
    3345:	e8 f6 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    334a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    334f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3353:	ba 48 00 00 00       	mov    $0x48,%edx
    3358:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    335c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3360:	4c 89 c8             	mov    %r9,%rax
    3363:	48 29 c8             	sub    %rcx,%rax
    3366:	48 39 d0             	cmp    %rdx,%rax
    3369:	48 0f 42 c2          	cmovb  %rdx,%rax
    336d:	4c 29 c9             	sub    %r9,%rcx
    3370:	4c 89 ea             	mov    %r13,%rdx
    3373:	48 01 c1             	add    %rax,%rcx
    3376:	e8 c5 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    337b:	4c 01 e8             	add    %r13,%rax
    337e:	48 29 e8             	sub    %rbp,%rax
    3381:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3386:	48 39 d0             	cmp    %rdx,%rax
    3389:	48 0f 47 c2          	cmova  %rdx,%rax
    338d:	89 c1                	mov    %eax,%ecx
    338f:	83 f8 08             	cmp    $0x8,%eax
    3392:	0f 83 28 02 00 00    	jae    35c0 <fwp_format_g.constprop.0+0x3c0>
    3398:	a8 04                	test   $0x4,%al
    339a:	0f 85 64 03 00 00    	jne    3704 <fwp_format_g.constprop.0+0x504>
    33a0:	85 c0                	test   %eax,%eax
    33a2:	74 0f                	je     33b3 <fwp_format_g.constprop.0+0x1b3>
    33a4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    33a9:	88 13                	mov    %dl,(%rbx)
    33ab:	a8 02                	test   $0x2,%al
    33ad:	0f 85 7b 03 00 00    	jne    372e <fwp_format_g.constprop.0+0x52e>
    33b3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33b7:	eb 36                	jmp    33ef <fwp_format_g.constprop.0+0x1ef>
    33b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    33c0:	45 31 c9             	xor    %r9d,%r9d
    33c3:	45 85 ed             	test   %r13d,%r13d
    33c6:	4c 8d 05 8d 4c 00 00 	lea    0x4c8d(%rip),%r8        # 805a <_IO_stdin_used+0x5a>
    33cd:	48 89 df             	mov    %rbx,%rdi
    33d0:	45 0f 49 cd          	cmovns %r13d,%r9d
    33d4:	ba 02 00 00 00       	mov    $0x2,%edx
    33d9:	be 90 01 00 00       	mov    $0x190,%esi
    33de:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    33e5:	b8 01 00 00 00       	mov    $0x1,%eax
    33ea:	e8 a1 ef ff ff       	call   2390 <__snprintf_chk@plt>
    33ef:	be 2e 00 00 00       	mov    $0x2e,%esi
    33f4:	48 89 df             	mov    %rbx,%rdi
    33f7:	e8 64 f0 ff ff       	call   2460 <strchr@plt>
    33fc:	48 85 c0             	test   %rax,%rax
    33ff:	74 4f                	je     3450 <fwp_format_g.constprop.0+0x250>
    3401:	48 89 df             	mov    %rbx,%rdi
    3404:	e8 27 f0 ff ff       	call   2430 <strlen@plt>
    3409:	48 85 c0             	test   %rax,%rax
    340c:	75 1b                	jne    3429 <fwp_format_g.constprop.0+0x229>
    340e:	eb 40                	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3410:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    341c:	00 00 00 00 
    3420:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3424:	48 85 c0             	test   %rax,%rax
    3427:	74 27                	je     3450 <fwp_format_g.constprop.0+0x250>
    3429:	48 89 c2             	mov    %rax,%rdx
    342c:	48 83 e8 01          	sub    $0x1,%rax
    3430:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    3434:	74 ea                	je     3420 <fwp_format_g.constprop.0+0x220>
    3436:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    343b:	0f 84 6f 01 00 00    	je     35b0 <fwp_format_g.constprop.0+0x3b0>
    3441:	0f 1f 40 00          	nopl   0x0(%rax)
    3445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    344c:	00 00 00 00 
    3450:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3457:	00 
    3458:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    345f:	00 00 
    3461:	0f 85 ec 02 00 00    	jne    3753 <fwp_format_g.constprop.0+0x553>
    3467:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    346e:	5b                   	pop    %rbx
    346f:	5d                   	pop    %rbp
    3470:	41 5c                	pop    %r12
    3472:	41 5d                	pop    %r13
    3474:	41 5e                	pop    %r14
    3476:	41 5f                	pop    %r15
    3478:	c3                   	ret
    3479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3480:	4c 29 f5             	sub    %r14,%rbp
    3483:	b9 40 00 00 00       	mov    $0x40,%ecx
    3488:	4c 89 f6             	mov    %r14,%rsi
    348b:	4c 89 04 24          	mov    %r8,(%rsp)
    348f:	49 89 ec             	mov    %rbp,%r12
    3492:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3497:	4c 89 e2             	mov    %r12,%rdx
    349a:	48 89 ef             	mov    %rbp,%rdi
    349d:	e8 9e f0 ff ff       	call   2540 <__memcpy_chk@plt>
    34a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    34a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    34ad:	48 89 ef             	mov    %rbp,%rdi
    34b0:	e8 ab ef ff ff       	call   2460 <strchr@plt>
    34b5:	4c 8b 04 24          	mov    (%rsp),%r8
    34b9:	48 85 c0             	test   %rax,%rax
    34bc:	74 40                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34be:	4d 85 e4             	test   %r12,%r12
    34c1:	74 3b                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    34c8:	eb 23                	jmp    34ed <fwp_format_g.constprop.0+0x2ed>
    34ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34d1:	00 00 00 00 
    34d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34dc:	00 00 00 00 
    34e0:	c6 00 00             	movb   $0x0,(%rax)
    34e3:	48 83 e8 01          	sub    $0x1,%rax
    34e7:	49 83 ec 01          	sub    $0x1,%r12
    34eb:	74 11                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34ed:	80 38 30             	cmpb   $0x30,(%rax)
    34f0:	74 ee                	je     34e0 <fwp_format_g.constprop.0+0x2e0>
    34f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    34f8:	0f 84 fb 01 00 00    	je     36f9 <fwp_format_g.constprop.0+0x4f9>
    34fe:	44 89 c0             	mov    %r8d,%eax
    3501:	ba 02 00 00 00       	mov    $0x2,%edx
    3506:	49 89 e9             	mov    %rbp,%r9
    3509:	be 90 01 00 00       	mov    $0x190,%esi
    350e:	f7 d8                	neg    %eax
    3510:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3517:	48 89 df             	mov    %rbx,%rdi
    351a:	41 0f 48 c0          	cmovs  %r8d,%eax
    351e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    3522:	41 83 e0 02          	and    $0x2,%r8d
    3526:	41 83 c0 2b          	add    $0x2b,%r8d
    352a:	50                   	push   %rax
    352b:	31 c0                	xor    %eax,%eax
    352d:	41 50                	push   %r8
    352f:	4c 8d 05 1a 4b 00 00 	lea    0x4b1a(%rip),%r8        # 8050 <_IO_stdin_used+0x50>
    3536:	e8 55 ee ff ff       	call   2390 <__snprintf_chk@plt>
    353b:	58                   	pop    %rax
    353c:	5a                   	pop    %rdx
    353d:	e9 0e ff ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3548:	4d 8b 06             	mov    (%r14),%r8
    354b:	48 83 c0 09          	add    $0x9,%rax
    354f:	4c 89 f2             	mov    %r14,%rdx
    3552:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3556:	4c 89 07             	mov    %r8,(%rdi)
    3559:	45 89 e0             	mov    %r12d,%r8d
    355c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3561:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3566:	49 89 f8             	mov    %rdi,%r8
    3569:	49 29 c0             	sub    %rax,%r8
    356c:	4c 29 c2             	sub    %r8,%rdx
    356f:	45 01 e0             	add    %r12d,%r8d
    3572:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3576:	41 83 f8 08          	cmp    $0x8,%r8d
    357a:	0f 82 ac fd ff ff    	jb     332c <fwp_format_g.constprop.0+0x12c>
    3580:	48 89 0c 24          	mov    %rcx,(%rsp)
    3584:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3588:	45 31 d2             	xor    %r10d,%r10d
    358b:	45 89 d3             	mov    %r10d,%r11d
    358e:	41 83 c2 08          	add    $0x8,%r10d
    3592:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3596:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    359a:	45 39 c2             	cmp    %r8d,%r10d
    359d:	72 ec                	jb     358b <fwp_format_g.constprop.0+0x38b>
    359f:	48 8b 0c 24          	mov    (%rsp),%rcx
    35a3:	e9 84 fd ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    35a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    35af:	00 
    35b0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    35b5:	e9 96 fe ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    35c0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    35c5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    35c9:	48 89 ee             	mov    %rbp,%rsi
    35cc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    35d0:	48 89 13             	mov    %rdx,(%rbx)
    35d3:	89 c2                	mov    %eax,%edx
    35d5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    35da:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    35df:	48 89 d9             	mov    %rbx,%rcx
    35e2:	48 29 f9             	sub    %rdi,%rcx
    35e5:	48 29 ce             	sub    %rcx,%rsi
    35e8:	01 c1                	add    %eax,%ecx
    35ea:	c1 e9 03             	shr    $0x3,%ecx
    35ed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    35f0:	e9 be fd ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    35f5:	0f 1f 00             	nopl   (%rax)
    35f8:	c6 00 30             	movb   $0x30,(%rax)
    35fb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    35ff:	4c 89 fa             	mov    %r15,%rdx
    3602:	4c 89 e9             	mov    %r13,%rcx
    3605:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    360a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    360f:	4c 89 14 24          	mov    %r10,(%rsp)
    3613:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3618:	e8 23 ef ff ff       	call   2540 <__memcpy_chk@plt>
    361d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    3622:	b9 48 00 00 00       	mov    $0x48,%ecx
    3627:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    362c:	48 89 c7             	mov    %rax,%rdi
    362f:	4c 8b 14 24          	mov    (%rsp),%r10
    3633:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    3638:	4c 89 c8             	mov    %r9,%rax
    363b:	4c 29 e8             	sub    %r13,%rax
    363e:	48 39 c8             	cmp    %rcx,%rax
    3641:	48 0f 42 c1          	cmovb  %rcx,%rax
    3645:	4d 29 cd             	sub    %r9,%r13
    3648:	49 01 ff             	add    %rdi,%r15
    364b:	4c 01 e8             	add    %r13,%rax
    364e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3652:	74 3d                	je     3691 <fwp_format_g.constprop.0+0x491>
    3654:	41 f7 d0             	not    %r8d
    3657:	31 f6                	xor    %esi,%esi
    3659:	ba 48 00 00 00       	mov    $0x48,%edx
    365e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3663:	48 39 d0             	cmp    %rdx,%rax
    3666:	48 0f 43 d0          	cmovae %rax,%rdx
    366a:	48 89 d1             	mov    %rdx,%rcx
    366d:	48 29 c1             	sub    %rax,%rcx
    3670:	48 83 c1 01          	add    $0x1,%rcx
    3674:	48 39 d1             	cmp    %rdx,%rcx
    3677:	48 0f 42 ca          	cmovb  %rdx,%rcx
    367b:	48 83 e8 01          	sub    $0x1,%rax
    367f:	48 83 c6 01          	add    $0x1,%rsi
    3683:	48 29 d0             	sub    %rdx,%rax
    3686:	48 01 c8             	add    %rcx,%rax
    3689:	41 39 f0             	cmp    %esi,%r8d
    368c:	7f cb                	jg     3659 <fwp_format_g.constprop.0+0x459>
    368e:	4d 01 c7             	add    %r8,%r15
    3691:	b9 48 00 00 00       	mov    $0x48,%ecx
    3696:	41 0f b6 12          	movzbl (%r10),%edx
    369a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    369e:	4c 89 f6             	mov    %r14,%rsi
    36a1:	48 39 c8             	cmp    %rcx,%rax
    36a4:	4c 89 1c 24          	mov    %r11,(%rsp)
    36a8:	48 0f 43 c8          	cmovae %rax,%rcx
    36ac:	41 88 17             	mov    %dl,(%r15)
    36af:	48 89 ca             	mov    %rcx,%rdx
    36b2:	48 29 c2             	sub    %rax,%rdx
    36b5:	48 83 c2 01          	add    $0x1,%rdx
    36b9:	48 39 ca             	cmp    %rcx,%rdx
    36bc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    36c0:	48 83 e8 01          	sub    $0x1,%rax
    36c4:	48 29 c8             	sub    %rcx,%rax
    36c7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    36cb:	49 63 d4             	movslq %r12d,%rdx
    36ce:	e8 6d ee ff ff       	call   2540 <__memcpy_chk@plt>
    36d3:	4c 8b 1c 24          	mov    (%rsp),%r11
    36d7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    36db:	e9 9e fc ff ff       	jmp    337e <fwp_format_g.constprop.0+0x17e>
    36e0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    36e5:	b9 47 00 00 00       	mov    $0x47,%ecx
    36ea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    36ef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    36f4:	e9 e9 fb ff ff       	jmp    32e2 <fwp_format_g.constprop.0+0xe2>
    36f9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    36ff:	e9 fa fd ff ff       	jmp    34fe <fwp_format_g.constprop.0+0x2fe>
    3704:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3708:	89 13                	mov    %edx,(%rbx)
    370a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    370e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3712:	e9 9c fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    3717:	41 8b 06             	mov    (%r14),%eax
    371a:	89 07                	mov    %eax,(%rdi)
    371c:	44 89 e0             	mov    %r12d,%eax
    371f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    3724:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    3729:	e9 fe fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    372e:	89 c2                	mov    %eax,%edx
    3730:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    3735:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    373a:	e9 74 fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    373f:	44 89 e0             	mov    %r12d,%eax
    3742:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3748:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    374e:	e9 d9 fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    3753:	e8 e8 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    375f:	00 

0000000000003760 <fwp_heap_report>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	41 54                	push   %r12
    3766:	48 8d 3d f2 48 00 00 	lea    0x48f2(%rip),%rdi        # 805f <_IO_stdin_used+0x5f>
    376d:	55                   	push   %rbp
    376e:	53                   	push   %rbx
    376f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3776:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    377d:	00 00 
    377f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3786:	00 
    3787:	48 8d 35 93 49 00 00 	lea    0x4993(%rip),%rsi        # 8121 <_IO_stdin_used+0x121>
    378e:	e8 5d ee ff ff       	call   25f0 <fopen@plt>
    3793:	48 85 c0             	test   %rax,%rax
    3796:	0f 84 c5 00 00 00    	je     3861 <fwp_heap_report+0x101>
    379c:	48 89 c5             	mov    %rax,%rbp
    379f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37a6:	48 89 e3             	mov    %rsp,%rbx
    37a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    37b0:	48 89 ea             	mov    %rbp,%rdx
    37b3:	be 00 01 00 00       	mov    $0x100,%esi
    37b8:	48 89 df             	mov    %rbx,%rdi
    37bb:	e8 20 ed ff ff       	call   24e0 <fgets@plt>
    37c0:	48 85 c0             	test   %rax,%rax
    37c3:	74 2b                	je     37f0 <fwp_heap_report+0x90>
    37c5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    37cb:	75 e3                	jne    37b0 <fwp_heap_report+0x50>
    37cd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    37d1:	75 dd                	jne    37b0 <fwp_heap_report+0x50>
    37d3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    37d8:	75 d6                	jne    37b0 <fwp_heap_report+0x50>
    37da:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    37df:	ba 0a 00 00 00       	mov    $0xa,%edx
    37e4:	31 f6                	xor    %esi,%esi
    37e6:	e8 75 ed ff ff       	call   2560 <strtol@plt>
    37eb:	49 89 c4             	mov    %rax,%r12
    37ee:	eb c0                	jmp    37b0 <fwp_heap_report+0x50>
    37f0:	48 89 ef             	mov    %rbp,%rdi
    37f3:	e8 28 ec ff ff       	call   2420 <fclose@plt>
    37f8:	48 83 ec 08          	sub    $0x8,%rsp
    37fc:	4c 8b 0d a5 92 01 00 	mov    0x192a5(%rip),%r9        # 1caa8 <fwp_heap+0x13c8>
    3803:	4c 8b 05 fe 92 01 00 	mov    0x192fe(%rip),%r8        # 1cb08 <fwp_heap+0x1428>
    380a:	48 8d 15 bf 49 00 00 	lea    0x49bf(%rip),%rdx        # 81d0 <_IO_stdin_used+0x1d0>
    3811:	41 54                	push   %r12
    3813:	48 8b 0d e6 92 01 00 	mov    0x192e6(%rip),%rcx        # 1cb00 <fwp_heap+0x1420>
    381a:	be 02 00 00 00       	mov    $0x2,%esi
    381f:	b8 02 00 00 00       	mov    $0x2,%eax
    3824:	f2 0f 10 0d f4 92 01 	movsd  0x192f4(%rip),%xmm1        # 1cb20 <fwp_heap+0x1440>
    382b:	00 
    382c:	f2 0f 10 05 e4 92 01 	movsd  0x192e4(%rip),%xmm0        # 1cb18 <fwp_heap+0x1438>
    3833:	00 
    3834:	48 8b 3d 05 78 00 00 	mov    0x7805(%rip),%rdi        # b040 <stderr@GLIBC_2.2.5>
    383b:	e8 10 ee ff ff       	call   2650 <__fprintf_chk@plt>
    3840:	58                   	pop    %rax
    3841:	5a                   	pop    %rdx
    3842:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3849:	00 
    384a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3851:	00 00 
    3853:	75 15                	jne    386a <fwp_heap_report+0x10a>
    3855:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    385c:	5b                   	pop    %rbx
    385d:	5d                   	pop    %rbp
    385e:	41 5c                	pop    %r12
    3860:	c3                   	ret
    3861:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3868:	eb 8e                	jmp    37f8 <fwp_heap_report+0x98>
    386a:	e8 d1 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    386f:	90                   	nop

0000000000003870 <fwp_heap_init>:
    3870:	66 0f 6f 05 28 4c 00 	movdqa 0x4c28(%rip),%xmm0        # 84a0 <msg.3+0x50>
    3877:	00 
    3878:	41 54                	push   %r12
    387a:	48 8d 05 9f 8d 01 00 	lea    0x18d9f(%rip),%rax        # 1c620 <fwp_heap+0xf40>
    3881:	ba 00 01 00 00       	mov    $0x100,%edx
    3886:	55                   	push   %rbp
    3887:	66 0f 6f 15 51 4c 00 	movdqa 0x4c51(%rip),%xmm2        # 84e0 <msg.3+0x90>
    388e:	00 
    388f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3893:	53                   	push   %rbx
    3894:	0f 29 05 45 8d 01 00 	movaps %xmm0,0x18d45(%rip)        # 1c5e0 <fwp_heap+0xf00>
    389b:	66 0f 6f 05 0d 4c 00 	movdqa 0x4c0d(%rip),%xmm0        # 84b0 <msg.3+0x60>
    38a2:	00 
    38a3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    38a7:	c7 05 d3 91 01 00 01 	movl   $0x1,0x191d3(%rip)        # 1ca84 <fwp_heap+0x13a4>
    38ae:	00 00 00 
    38b1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    38b6:	0f 29 05 33 8d 01 00 	movaps %xmm0,0x18d33(%rip)        # 1c5f0 <fwp_heap+0xf10>
    38bd:	66 0f 6f 05 fb 4b 00 	movdqa 0x4bfb(%rip),%xmm0        # 84c0 <msg.3+0x70>
    38c4:	00 
    38c5:	0f 29 05 34 8d 01 00 	movaps %xmm0,0x18d34(%rip)        # 1c600 <fwp_heap+0xf20>
    38cc:	66 0f 6f 05 fc 4b 00 	movdqa 0x4bfc(%rip),%xmm0        # 84d0 <msg.3+0x80>
    38d3:	00 
    38d4:	0f 29 05 35 8d 01 00 	movaps %xmm0,0x18d35(%rip)        # 1c610 <fwp_heap+0xf30>
    38db:	89 d3                	mov    %edx,%ebx
    38dd:	66 0f 6e e2          	movd   %edx,%xmm4
    38e1:	48 83 c0 10          	add    $0x10,%rax
    38e5:	01 d2                	add    %edx,%edx
    38e7:	c1 eb 02             	shr    $0x2,%ebx
    38ea:	66 0f 6e c3          	movd   %ebx,%xmm0
    38ee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    38f3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    38f7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    38fc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3900:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3904:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3909:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    390e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3912:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3917:	66 0f fe c1          	paddd  %xmm1,%xmm0
    391b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    391f:	48 39 c7             	cmp    %rax,%rdi
    3922:	75 b7                	jne    38db <fwp_heap_init+0x6b>
    3924:	4c 8d 05 b5 7d 01 00 	lea    0x17db5(%rip),%r8        # 1b6e0 <fwp_heap>
    392b:	31 c9                	xor    %ecx,%ecx
    392d:	31 c0                	xor    %eax,%eax
    392f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 
    3940:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3947:	00 
    3948:	48 39 ca             	cmp    %rcx,%rdx
    394b:	73 0f                	jae    395c <fwp_heap_init+0xec>
    394d:	0f 1f 00             	nopl   (%rax)
    3950:	48 83 c0 01          	add    $0x1,%rax
    3954:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3957:	48 39 ca             	cmp    %rcx,%rdx
    395a:	72 f4                	jb     3950 <fwp_heap_init+0xe0>
    395c:	48 83 c1 10          	add    $0x10,%rcx
    3960:	88 07                	mov    %al,(%rdi)
    3962:	48 83 c7 01          	add    $0x1,%rdi
    3966:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    396d:	75 d1                	jne    3940 <fwp_heap_init+0xd0>
    396f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3976:	00 00 00 
    3979:	bd 05 00 00 00       	mov    $0x5,%ebp
    397e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3985:	45 31 c9             	xor    %r9d,%r9d
    3988:	31 d2                	xor    %edx,%edx
    398a:	31 ff                	xor    %edi,%edi
    398c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3992:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3997:	4c 89 e6             	mov    %r12,%rsi
    399a:	e8 b1 ea ff ff       	call   2450 <mmap@plt>
    399f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    39a3:	75 13                	jne    39b8 <fwp_heap_init+0x148>
    39a5:	48 c1 eb 02          	shr    $0x2,%rbx
    39a9:	83 ed 01             	sub    $0x1,%ebp
    39ac:	75 d0                	jne    397e <fwp_heap_init+0x10e>
    39ae:	e8 bd f2 ff ff       	call   2c70 <fwp_heap_oom>
    39b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    39b8:	48 85 c0             	test   %rax,%rax
    39bb:	74 f1                	je     39ae <fwp_heap_init+0x13e>
    39bd:	48 c1 eb 10          	shr    $0x10,%rbx
    39c1:	48 89 05 d0 90 01 00 	mov    %rax,0x190d0(%rip)        # 1ca98 <fwp_heap+0x13b8>
    39c8:	45 31 c9             	xor    %r9d,%r9d
    39cb:	31 d2                	xor    %edx,%edx
    39cd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    39d3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    39d7:	31 ff                	xor    %edi,%edi
    39d9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    39df:	66 31 c0             	xor    %ax,%ax
    39e2:	48 c1 e6 03          	shl    $0x3,%rsi
    39e6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    39eb:	4c 89 25 ae 90 01 00 	mov    %r12,0x190ae(%rip)        # 1caa0 <fwp_heap+0x13c0>
    39f2:	48 89 05 97 90 01 00 	mov    %rax,0x19097(%rip)        # 1ca90 <fwp_heap+0x13b0>
    39f9:	48 89 1d b0 90 01 00 	mov    %rbx,0x190b0(%rip)        # 1cab0 <fwp_heap+0x13d0>
    3a00:	48 89 35 d9 90 01 00 	mov    %rsi,0x190d9(%rip)        # 1cae0 <fwp_heap+0x1400>
    3a07:	e8 44 ea ff ff       	call   2450 <mmap@plt>
    3a0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a10:	74 9c                	je     39ae <fwp_heap_init+0x13e>
    3a12:	48 8d 3d 7c 46 00 00 	lea    0x467c(%rip),%rdi        # 8095 <_IO_stdin_used+0x95>
    3a19:	48 89 05 b8 90 01 00 	mov    %rax,0x190b8(%rip)        # 1cad8 <fwp_heap+0x13f8>
    3a20:	e8 5b e9 ff ff       	call   2380 <getenv@plt>
    3a25:	48 89 c2             	mov    %rax,%rdx
    3a28:	31 c0                	xor    %eax,%eax
    3a2a:	48 85 d2             	test   %rdx,%rdx
    3a2d:	74 15                	je     3a44 <fwp_heap_init+0x1d4>
    3a2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    3a32:	74 10                	je     3a44 <fwp_heap_init+0x1d4>
    3a34:	0f b6 02             	movzbl (%rdx),%eax
    3a37:	83 e8 30             	sub    $0x30,%eax
    3a3a:	74 13                	je     3a4f <fwp_heap_init+0x1df>
    3a3c:	85 c0                	test   %eax,%eax
    3a3e:	0f 95 c0             	setne  %al
    3a41:	0f b6 c0             	movzbl %al,%eax
    3a44:	5b                   	pop    %rbx
    3a45:	5d                   	pop    %rbp
    3a46:	89 05 3c 90 01 00    	mov    %eax,0x1903c(%rip)        # 1ca88 <fwp_heap+0x13a8>
    3a4c:	41 5c                	pop    %r12
    3a4e:	c3                   	ret
    3a4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3a53:	85 c0                	test   %eax,%eax
    3a55:	0f 95 c0             	setne  %al
    3a58:	0f b6 c0             	movzbl %al,%eax
    3a5b:	eb e7                	jmp    3a44 <fwp_heap_init+0x1d4>
    3a5d:	0f 1f 00             	nopl   (%rax)

0000000000003a60 <fwp_args45>:
    3a60:	f3 0f 1e fa          	endbr64
    3a64:	c3                   	ret
    3a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a6c:	00 00 00 00 

0000000000003a70 <fwp_args69>:
    3a70:	f3 0f 1e fa          	endbr64
    3a74:	c3                   	ret
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 

0000000000003a80 <fwp_wake_io>:
    3a80:	48 8b 07             	mov    (%rdi),%rax
    3a83:	48 85 c0             	test   %rax,%rax
    3a86:	0f 84 f4 00 00 00    	je     3b80 <fwp_wake_io+0x100>
    3a8c:	53                   	push   %rbx
    3a8d:	4c 8b 05 0c 7c 01 00 	mov    0x17c0c(%rip),%r8        # 1b6a0 <fwp_ready_tail>
    3a94:	49 89 f9             	mov    %rdi,%r9
    3a97:	48 89 c2             	mov    %rax,%rdx
    3a9a:	45 31 db             	xor    %r11d,%r11d
    3a9d:	45 31 d2             	xor    %r10d,%r10d
    3aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3aa4:	eb 71                	jmp    3b17 <fwp_wake_io+0x97>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3ab7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3abe:	48 85 c9             	test   %rcx,%rcx
    3ac1:	74 07                	je     3aca <fwp_wake_io+0x4a>
    3ac3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3aca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3ad1:	00 00 00 00 
    3ad5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3adc:	49 8b 01             	mov    (%r9),%rax
    3adf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ae3:	75 2a                	jne    3b0f <fwp_wake_io+0x8f>
    3ae5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3ae9:	75 24                	jne    3b0f <fwp_wake_io+0x8f>
    3aeb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3aef:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3af6:	00 00 00 00 
    3afa:	4d 85 c0             	test   %r8,%r8
    3afd:	74 51                	je     3b50 <fwp_wake_io+0xd0>
    3aff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3b06:	49 89 d0             	mov    %rdx,%r8
    3b09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3b0f:	48 89 c2             	mov    %rax,%rdx
    3b12:	48 85 c0             	test   %rax,%rax
    3b15:	74 49                	je     3b60 <fwp_wake_io+0xe0>
    3b17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3b1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3b22:	48 85 ff             	test   %rdi,%rdi
    3b25:	74 b8                	je     3adf <fwp_wake_io+0x5f>
    3b27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3b2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b35:	48 85 f6             	test   %rsi,%rsi
    3b38:	0f 85 72 ff ff ff    	jne    3ab0 <fwp_wake_io+0x30>
    3b3e:	48 89 0f             	mov    %rcx,(%rdi)
    3b41:	e9 78 ff ff ff       	jmp    3abe <fwp_wake_io+0x3e>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 d3             	mov    %rdx,%rbx
    3b53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3b59:	eb ab                	jmp    3b06 <fwp_wake_io+0x86>
    3b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3b60:	45 84 db             	test   %r11b,%r11b
    3b63:	74 07                	je     3b6c <fwp_wake_io+0xec>
    3b65:	48 89 1d 3c 7b 01 00 	mov    %rbx,0x17b3c(%rip)        # 1b6a8 <fwp_ready_head>
    3b6c:	45 84 d2             	test   %r10b,%r10b
    3b6f:	74 07                	je     3b78 <fwp_wake_io+0xf8>
    3b71:	4c 89 05 28 7b 01 00 	mov    %r8,0x17b28(%rip)        # 1b6a0 <fwp_ready_tail>
    3b78:	5b                   	pop    %rbx
    3b79:	c3                   	ret
    3b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3b80:	c3                   	ret
    3b81:	0f 1f 40 00          	nopl   0x0(%rax)
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_poll_events>:
    3b90:	53                   	push   %rbx
    3b91:	48 83 ec 20          	sub    $0x20,%rsp
    3b95:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3b9c:	00 00 
    3b9e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3ba3:	31 c0                	xor    %eax,%eax
    3ba5:	e8 a6 f5 ff ff       	call   3150 <fwp_now_ns>
    3baa:	48 8b 1d e7 7a 01 00 	mov    0x17ae7(%rip),%rbx        # 1b698 <fwp_timers>
    3bb1:	48 85 db             	test   %rbx,%rbx
    3bb4:	0f 84 e6 00 00 00    	je     3ca0 <fwp_poll_events+0x110>
    3bba:	48 89 c6             	mov    %rax,%rsi
    3bbd:	48 89 da             	mov    %rbx,%rdx
    3bc0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3bc7:	eb 26                	jmp    3bef <fwp_poll_events+0x5f>
    3bc9:	90                   	nop
    3bca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bd1:	00 00 00 00 
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 
    3be0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3be7:	48 89 c8             	mov    %rcx,%rax
    3bea:	48 85 d2             	test   %rdx,%rdx
    3bed:	74 31                	je     3c20 <fwp_poll_events+0x90>
    3bef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3bf3:	48 85 c0             	test   %rax,%rax
    3bf6:	78 e8                	js     3be0 <fwp_poll_events+0x50>
    3bf8:	48 39 c1             	cmp    %rax,%rcx
    3bfb:	7c e3                	jl     3be0 <fwp_poll_events+0x50>
    3bfd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 1c                	je     3c25 <fwp_poll_events+0x95>
    3c09:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c0d:	48 39 c1             	cmp    %rax,%rcx
    3c10:	7c ce                	jl     3be0 <fwp_poll_events+0x50>
    3c12:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c19:	48 85 d2             	test   %rdx,%rdx
    3c1c:	75 d1                	jne    3bef <fwp_poll_events+0x5f>
    3c1e:	66 90                	xchg   %ax,%ax
    3c20:	48 85 c0             	test   %rax,%rax
    3c23:	78 7b                	js     3ca0 <fwp_poll_events+0x110>
    3c25:	48 29 f0             	sub    %rsi,%rax
    3c28:	48 89 c1             	mov    %rax,%rcx
    3c2b:	48 85 c0             	test   %rax,%rax
    3c2e:	0f 8e 9c 00 00 00    	jle    3cd0 <fwp_poll_events+0x140>
    3c34:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3c3b:	de 1b 43 
    3c3e:	48 f7 ea             	imul   %rdx
    3c41:	48 89 c8             	mov    %rcx,%rax
    3c44:	48 c1 f8 3f          	sar    $0x3f,%rax
    3c48:	48 c1 fa 12          	sar    $0x12,%rdx
    3c4c:	48 29 c2             	sub    %rax,%rdx
    3c4f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3c56:	48 39 c1             	cmp    %rax,%rcx
    3c59:	0f 95 c0             	setne  %al
    3c5c:	0f b6 c0             	movzbl %al,%eax
    3c5f:	48 01 d0             	add    %rdx,%rax
    3c62:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3c68:	0f 8f 32 01 00 00    	jg     3da0 <fwp_poll_events+0x210>
    3c6e:	48 85 c0             	test   %rax,%rax
    3c71:	74 5d                	je     3cd0 <fwp_poll_events+0x140>
    3c73:	89 c1                	mov    %eax,%ecx
    3c75:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3c7c:	48 c1 e9 26          	shr    $0x26,%rcx
    3c80:	48 63 d1             	movslq %ecx,%rdx
    3c83:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3c89:	29 c8                	sub    %ecx,%eax
    3c8b:	48 98                	cltq
    3c8d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3c94:	e9 11 01 00 00       	jmp    3daa <fwp_poll_events+0x21a>
    3c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ca0:	e8 8b ef ff ff       	call   2c30 <fwp_flush>
    3ca5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3caa:	be 01 00 00 00       	mov    $0x1,%esi
    3caf:	48 8b 0d 8a 73 00 00 	mov    0x738a(%rip),%rcx        # b040 <stderr@GLIBC_2.2.5>
    3cb6:	48 8d 3d 9b 45 00 00 	lea    0x459b(%rip),%rdi        # 8258 <_IO_stdin_used+0x258>
    3cbd:	e8 7e e9 ff ff       	call   2640 <fwrite@plt>
    3cc2:	bf 65 00 00 00       	mov    $0x65,%edi
    3cc7:	e8 64 e9 ff ff       	call   2630 <exit@plt>
    3ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    3cd0:	e8 7b f4 ff ff       	call   3150 <fwp_now_ns>
    3cd5:	48 89 c1             	mov    %rax,%rcx
    3cd8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3cdc:	eb 44                	jmp    3d22 <fwp_poll_events+0x192>
    3cde:	66 90                	xchg   %ax,%ax
    3ce0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ce4:	75 33                	jne    3d19 <fwp_poll_events+0x189>
    3ce6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cea:	75 2d                	jne    3d19 <fwp_poll_events+0x189>
    3cec:	48 8b 05 ad 79 01 00 	mov    0x179ad(%rip),%rax        # 1b6a0 <fwp_ready_tail>
    3cf3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3cf7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3cfe:	00 00 00 00 
    3d02:	48 85 c0             	test   %rax,%rax
    3d05:	0f 84 05 01 00 00    	je     3e10 <fwp_poll_events+0x280>
    3d0b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3d12:	48 89 15 87 79 01 00 	mov    %rdx,0x17987(%rip)        # 1b6a0 <fwp_ready_tail>
    3d19:	48 85 db             	test   %rbx,%rbx
    3d1c:	0f 84 be 00 00 00    	je     3de0 <fwp_poll_events+0x250>
    3d22:	48 89 da             	mov    %rbx,%rdx
    3d25:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3d2c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3d30:	7f e7                	jg     3d19 <fwp_poll_events+0x189>
    3d32:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3d36:	74 2e                	je     3d66 <fwp_poll_events+0x1d6>
    3d38:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	0f 84 b8 00 00 00    	je     3e00 <fwp_poll_events+0x270>
    3d48:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3d4f:	48 85 db             	test   %rbx,%rbx
    3d52:	74 07                	je     3d5b <fwp_poll_events+0x1cb>
    3d54:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3d5b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3d5f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3d66:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3d6a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3d6e:	48 85 c0             	test   %rax,%rax
    3d71:	0f 84 69 ff ff ff    	je     3ce0 <fwp_poll_events+0x150>
    3d77:	48 39 c8             	cmp    %rcx,%rax
    3d7a:	0f 8f 60 ff ff ff    	jg     3ce0 <fwp_poll_events+0x150>
    3d80:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3d84:	0f 85 56 ff ff ff    	jne    3ce0 <fwp_poll_events+0x150>
    3d8a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8e:	75 89                	jne    3d19 <fwp_poll_events+0x189>
    3d90:	48 89 d7             	mov    %rdx,%rdi
    3d93:	e8 98 f2 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    3d98:	e9 43 ff ff ff       	jmp    3ce0 <fwp_poll_events+0x150>
    3d9d:	0f 1f 00             	nopl   (%rax)
    3da0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3da5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3daa:	48 89 e7             	mov    %rsp,%rdi
    3dad:	31 f6                	xor    %esi,%esi
    3daf:	48 89 14 24          	mov    %rdx,(%rsp)
    3db3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3db8:	e8 c3 e6 ff ff       	call   2480 <nanosleep@plt>
    3dbd:	48 8b 1d d4 78 01 00 	mov    0x178d4(%rip),%rbx        # 1b698 <fwp_timers>
    3dc4:	e8 87 f3 ff ff       	call   3150 <fwp_now_ns>
    3dc9:	48 89 c1             	mov    %rax,%rcx
    3dcc:	48 85 db             	test   %rbx,%rbx
    3dcf:	0f 85 03 ff ff ff    	jne    3cd8 <fwp_poll_events+0x148>
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 
    3de0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3de5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3dec:	00 00 
    3dee:	75 2c                	jne    3e1c <fwp_poll_events+0x28c>
    3df0:	48 83 c4 20          	add    $0x20,%rsp
    3df4:	5b                   	pop    %rbx
    3df5:	c3                   	ret
    3df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3dfd:	00 00 00 
    3e00:	48 89 1d 91 78 01 00 	mov    %rbx,0x17891(%rip)        # 1b698 <fwp_timers>
    3e07:	e9 43 ff ff ff       	jmp    3d4f <fwp_poll_events+0x1bf>
    3e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3e10:	48 89 15 91 78 01 00 	mov    %rdx,0x17891(%rip)        # 1b6a8 <fwp_ready_head>
    3e17:	e9 f6 fe ff ff       	jmp    3d12 <fwp_poll_events+0x182>
    3e1c:	e8 1f e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3e21:	0f 1f 40 00          	nopl   0x0(%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_rc_wide_dup>:
    3e30:	48 89 fa             	mov    %rdi,%rdx
    3e33:	48 8d 35 a6 78 01 00 	lea    0x178a6(%rip),%rsi        # 1b6e0 <fwp_heap>
    3e3a:	48 83 ec 18          	sub    $0x18,%rsp
    3e3e:	48 89 f9             	mov    %rdi,%rcx
    3e41:	48 c1 ea 11          	shr    $0x11,%rdx
    3e45:	48 31 fa             	xor    %rdi,%rdx
    3e48:	48 89 d0             	mov    %rdx,%rax
    3e4b:	48 c1 e8 09          	shr    $0x9,%rax
    3e4f:	48 31 c2             	xor    %rax,%rdx
    3e52:	0f b6 d2             	movzbl %dl,%edx
    3e55:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    3e5c:	00 
    3e5d:	49 8b 00             	mov    (%r8),%rax
    3e60:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    3e67:	00 00 
    3e69:	75 21                	jne    3e8c <fwp_rc_wide_dup+0x5c>
    3e6b:	e9 98 00 00 00       	jmp    3f08 <fwp_rc_wide_dup+0xd8>
    3e70:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3e84:	48 85 d2             	test   %rdx,%rdx
    3e87:	74 2f                	je     3eb8 <fwp_rc_wide_dup+0x88>
    3e89:	48 89 d0             	mov    %rdx,%rax
    3e8c:	48 3b 08             	cmp    (%rax),%rcx
    3e8f:	75 ef                	jne    3e80 <fwp_rc_wide_dup+0x50>
    3e91:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3e94:	74 7c                	je     3f12 <fwp_rc_wide_dup+0xe2>
    3e96:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3e9a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    3e9e:	0f 84 91 00 00 00    	je     3f35 <fwp_rc_wide_dup+0x105>
    3ea4:	48 83 c2 01          	add    $0x1,%rdx
    3ea8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    3eac:	48 83 c4 18          	add    $0x18,%rsp
    3eb0:	c3                   	ret
    3eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3eb8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    3ebc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3ebf:	75 68                	jne    3f29 <fwp_rc_wide_dup+0xf9>
    3ec1:	bf 18 00 00 00       	mov    $0x18,%edi
    3ec6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ecb:	4c 89 04 24          	mov    %r8,(%rsp)
    3ecf:	e8 ac e6 ff ff       	call   2580 <malloc@plt>
    3ed4:	4c 8b 04 24          	mov    (%rsp),%r8
    3ed8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3edd:	48 85 c0             	test   %rax,%rax
    3ee0:	74 5f                	je     3f41 <fwp_rc_wide_dup+0x111>
    3ee2:	48 89 08             	mov    %rcx,(%rax)
    3ee5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    3eec:	00 
    3eed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    3ef4:	00 
    3ef5:	49 89 00             	mov    %rax,(%r8)
    3ef8:	c6 01 ff             	movb   $0xff,(%rcx)
    3efb:	48 83 05 25 94 01 00 	addq   $0x1,0x19425(%rip)        # 1d328 <fwp_heap+0x1c48>
    3f02:	01 
    3f03:	48 83 c4 18          	add    $0x18,%rsp
    3f07:	c3                   	ret
    3f08:	80 3f fe             	cmpb   $0xfe,(%rdi)
    3f0b:	75 13                	jne    3f20 <fwp_rc_wide_dup+0xf0>
    3f0d:	48 85 c0             	test   %rax,%rax
    3f10:	74 af                	je     3ec1 <fwp_rc_wide_dup+0x91>
    3f12:	48 8d 3d 6f 43 00 00 	lea    0x436f(%rip),%rdi        # 8288 <_IO_stdin_used+0x288>
    3f19:	e8 02 f2 ff ff       	call   3120 <fwp_trap>
    3f1e:	66 90                	xchg   %ax,%ax
    3f20:	48 85 c0             	test   %rax,%rax
    3f23:	0f 85 6d ff ff ff    	jne    3e96 <fwp_rc_wide_dup+0x66>
    3f29:	48 8d 3d 80 43 00 00 	lea    0x4380(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    3f30:	e8 eb f1 ff ff       	call   3120 <fwp_trap>
    3f35:	48 8d 3d 69 41 00 00 	lea    0x4169(%rip),%rdi        # 80a5 <_IO_stdin_used+0xa5>
    3f3c:	e8 df f1 ff ff       	call   3120 <fwp_trap>
    3f41:	e8 2a ed ff ff       	call   2c70 <fwp_heap_oom>
    3f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f4d:	00 00 00 

0000000000003f50 <fwp_rc_forget_slot>:
    3f50:	80 3f ff             	cmpb   $0xff,(%rdi)
    3f53:	74 0b                	je     3f60 <fwp_rc_forget_slot+0x10>
    3f55:	c3                   	ret
    3f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f5d:	00 00 00 
    3f60:	48 89 f8             	mov    %rdi,%rax
    3f63:	48 83 ec 08          	sub    $0x8,%rsp
    3f67:	48 89 fa             	mov    %rdi,%rdx
    3f6a:	48 c1 e8 11          	shr    $0x11,%rax
    3f6e:	48 31 f8             	xor    %rdi,%rax
    3f71:	48 89 c1             	mov    %rax,%rcx
    3f74:	48 c1 e9 09          	shr    $0x9,%rcx
    3f78:	48 31 c8             	xor    %rcx,%rax
    3f7b:	48 8d 0d 5e 77 01 00 	lea    0x1775e(%rip),%rcx        # 1b6e0 <fwp_heap>
    3f82:	0f b6 c0             	movzbl %al,%eax
    3f85:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f8c:	00 
    3f8d:	48 85 ff             	test   %rdi,%rdi
    3f90:	74 3c                	je     3fce <fwp_rc_forget_slot+0x7e>
    3f92:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f99:	00 
    3f9a:	48 8b 01             	mov    (%rcx),%rax
    3f9d:	eb 11                	jmp    3fb0 <fwp_rc_forget_slot+0x60>
    3f9f:	90                   	nop
    3fa0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3fa4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3fa8:	48 85 ff             	test   %rdi,%rdi
    3fab:	74 21                	je     3fce <fwp_rc_forget_slot+0x7e>
    3fad:	48 89 f8             	mov    %rdi,%rax
    3fb0:	48 3b 10             	cmp    (%rax),%rdx
    3fb3:	75 eb                	jne    3fa0 <fwp_rc_forget_slot+0x50>
    3fb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fb9:	48 89 01             	mov    %rax,(%rcx)
    3fbc:	e8 df e3 ff ff       	call   23a0 <free@plt>
    3fc1:	48 83 2d 5f 93 01 00 	subq   $0x1,0x1935f(%rip)        # 1d328 <fwp_heap+0x1c48>
    3fc8:	01 
    3fc9:	48 83 c4 08          	add    $0x8,%rsp
    3fcd:	c3                   	ret
    3fce:	48 8d 3d db 42 00 00 	lea    0x42db(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    3fd5:	e8 46 f1 ff ff       	call   3120 <fwp_trap>
    3fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003fe0 <fwp_rc_prepare_chunk>:
    3fe0:	48 83 3d 40 93 01 00 	cmpq   $0x0,0x19340(%rip)        # 1d328 <fwp_heap+0x1c48>
    3fe7:	00 
    3fe8:	41 54                	push   %r12
    3fea:	49 89 f4             	mov    %rsi,%r12
    3fed:	55                   	push   %rbp
    3fee:	48 89 fd             	mov    %rdi,%rbp
    3ff1:	53                   	push   %rbx
    3ff2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3ff5:	0f 84 7d 00 00 00    	je     4078 <fwp_rc_prepare_chunk+0x98>
    3ffb:	31 db                	xor    %ebx,%ebx
    3ffd:	85 c0                	test   %eax,%eax
    3fff:	75 5f                	jne    4060 <fwp_rc_prepare_chunk+0x80>
    4001:	48 85 f6             	test   %rsi,%rsi
    4004:	74 7c                	je     4082 <fwp_rc_prepare_chunk+0xa2>
    4006:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    400a:	e8 91 e3 ff ff       	call   23a0 <free@plt>
    400f:	90                   	nop
    4010:	be 01 00 00 00       	mov    $0x1,%esi
    4015:	4c 89 e7             	mov    %r12,%rdi
    4018:	e8 e3 e4 ff ff       	call   2500 <calloc@plt>
    401d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    4021:	48 85 c0             	test   %rax,%rax
    4024:	0f 85 87 00 00 00    	jne    40b1 <fwp_rc_prepare_chunk+0xd1>
    402a:	e8 41 ec ff ff       	call   2c70 <fwp_heap_oom>
    402f:	90                   	nop
    4030:	e8 1b ff ff ff       	call   3f50 <fwp_rc_forget_slot>
    4035:	8b 45 1c             	mov    0x1c(%rbp),%eax
    4038:	48 83 c3 01          	add    $0x1,%rbx
    403c:	48 39 c3             	cmp    %rax,%rbx
    403f:	73 37                	jae    4078 <fwp_rc_prepare_chunk+0x98>
    4041:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4048:	00 00 
    404a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4051:	00 00 00 00 
    4055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    405c:	00 00 00 00 
    4060:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4064:	48 01 df             	add    %rbx,%rdi
    4067:	80 3f ff             	cmpb   $0xff,(%rdi)
    406a:	74 c4                	je     4030 <fwp_rc_prepare_chunk+0x50>
    406c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    406f:	48 83 c3 01          	add    $0x1,%rbx
    4073:	48 39 c3             	cmp    %rax,%rbx
    4076:	72 e8                	jb     4060 <fwp_rc_prepare_chunk+0x80>
    4078:	49 39 c4             	cmp    %rax,%r12
    407b:	75 13                	jne    4090 <fwp_rc_prepare_chunk+0xb0>
    407d:	4d 85 e4             	test   %r12,%r12
    4080:	75 46                	jne    40c8 <fwp_rc_prepare_chunk+0xe8>
    4082:	5b                   	pop    %rbx
    4083:	5d                   	pop    %rbp
    4084:	41 5c                	pop    %r12
    4086:	c3                   	ret
    4087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    408e:	00 00 
    4090:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4094:	48 29 05 95 92 01 00 	sub    %rax,0x19295(%rip)        # 1d330 <fwp_heap+0x1c50>
    409b:	e8 00 e3 ff ff       	call   23a0 <free@plt>
    40a0:	4d 85 e4             	test   %r12,%r12
    40a3:	0f 85 67 ff ff ff    	jne    4010 <fwp_rc_prepare_chunk+0x30>
    40a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    40b0:	00 
    40b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    40b5:	5b                   	pop    %rbx
    40b6:	4c 01 25 73 92 01 00 	add    %r12,0x19273(%rip)        # 1d330 <fwp_heap+0x1c50>
    40bd:	5d                   	pop    %rbp
    40be:	41 5c                	pop    %r12
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    40cc:	5b                   	pop    %rbx
    40cd:	4c 89 e2             	mov    %r12,%rdx
    40d0:	31 f6                	xor    %esi,%esi
    40d2:	5d                   	pop    %rbp
    40d3:	41 5c                	pop    %r12
    40d5:	e9 c6 e3 ff ff       	jmp    24a0 <memset@plt>
    40da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040e0 <fwp_heap_refill>:
    40e0:	41 56                	push   %r14
    40e2:	41 89 d6             	mov    %edx,%r14d
    40e5:	41 55                	push   %r13
    40e7:	41 89 f5             	mov    %esi,%r13d
    40ea:	41 54                	push   %r12
    40ec:	49 89 fc             	mov    %rdi,%r12
    40ef:	bf 01 00 00 00       	mov    $0x1,%edi
    40f4:	55                   	push   %rbp
    40f5:	53                   	push   %rbx
    40f6:	e8 a5 ec ff ff       	call   2da0 <fwp_heap_chunks>
    40fb:	48 89 c3             	mov    %rax,%rbx
    40fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4102:	48 8b 05 cf 89 01 00 	mov    0x189cf(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    4109:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    410d:	48 8d 05 cc 75 01 00 	lea    0x175cc(%rip),%rax        # 1b6e0 <fwp_heap>
    4114:	31 d2                	xor    %edx,%edx
    4116:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    411a:	48 89 ef             	mov    %rbp,%rdi
    411d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    4121:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    4125:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    412c:	00 
    412d:	b8 00 00 01 00       	mov    $0x10000,%eax
    4132:	f7 f1                	div    %ecx
    4134:	31 d2                	xor    %edx,%edx
    4136:	66 0f 6e c1          	movd   %ecx,%xmm0
    413a:	66 0f 6e c8          	movd   %eax,%xmm1
    413e:	89 c6                	mov    %eax,%esi
    4140:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4145:	48 01 c8             	add    %rcx,%rax
    4148:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    414c:	48 f7 f1             	div    %rcx
    414f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    4154:	89 45 18             	mov    %eax,0x18(%rbp)
    4157:	e8 84 fe ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    415c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    415f:	48 89 d8             	mov    %rbx,%rax
    4162:	48 c1 e0 10          	shl    $0x10,%rax
    4166:	48 03 05 23 89 01 00 	add    0x18923(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    416d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    4171:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    4176:	8b 55 08             	mov    0x8(%rbp),%edx
    4179:	48 0f af d1          	imul   %rcx,%rdx
    417d:	48 01 c2             	add    %rax,%rdx
    4180:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4185:	5b                   	pop    %rbx
    4186:	5d                   	pop    %rbp
    4187:	41 5c                	pop    %r12
    4189:	41 5d                	pop    %r13
    418b:	41 5e                	pop    %r14
    418d:	c3                   	ret
    418e:	66 90                	xchg   %ax,%ax

0000000000004190 <fwp_mem_free>:
    4190:	48 85 ff             	test   %rdi,%rdi
    4193:	0f 84 17 02 00 00    	je     43b0 <fwp_mem_free+0x220>
    4199:	48 8b 35 f0 88 01 00 	mov    0x188f0(%rip),%rsi        # 1ca90 <fwp_heap+0x13b0>
    41a0:	48 8b 05 11 89 01 00 	mov    0x18911(%rip),%rax        # 1cab8 <fwp_heap+0x13d8>
    41a7:	48 89 fa             	mov    %rdi,%rdx
    41aa:	48 29 f2             	sub    %rsi,%rdx
    41ad:	48 c1 e0 10          	shl    $0x10,%rax
    41b1:	48 39 c2             	cmp    %rax,%rdx
    41b4:	0f 83 f6 01 00 00    	jae    43b0 <fwp_mem_free+0x220>
    41ba:	49 89 d1             	mov    %rdx,%r9
    41bd:	49 c1 e9 10          	shr    $0x10,%r9
    41c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    41c5:	48 c1 e0 03          	shl    $0x3,%rax
    41c9:	49 89 c0             	mov    %rax,%r8
    41cc:	4c 03 05 05 89 01 00 	add    0x18905(%rip),%r8        # 1cad8 <fwp_heap+0x13f8>
    41d3:	0f 84 d7 01 00 00    	je     43b0 <fwp_mem_free+0x220>
    41d9:	48 83 ec 38          	sub    $0x38,%rsp
    41dd:	48 89 f9             	mov    %rdi,%rcx
    41e0:	41 0f b6 38          	movzbl (%r8),%edi
    41e4:	40 80 ff 01          	cmp    $0x1,%dil
    41e8:	74 16                	je     4200 <fwp_mem_free+0x70>
    41ea:	40 80 ff 02          	cmp    $0x2,%dil
    41ee:	0f 84 94 00 00 00    	je     4288 <fwp_mem_free+0xf8>
    41f4:	48 83 c4 38          	add    $0x38,%rsp
    41f8:	c3                   	ret
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4200:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4204:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4209:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    420e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4212:	4d 85 d2             	test   %r10,%r10
    4215:	74 1d                	je     4234 <fwp_mem_free+0xa4>
    4217:	0f b7 c1             	movzwl %cx,%eax
    421a:	31 d2                	xor    %edx,%edx
    421c:	48 f7 f7             	div    %rdi
    421f:	49 01 c2             	add    %rax,%r10
    4222:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4226:	0f 84 44 01 00 00    	je     4370 <fwp_mem_free+0x1e0>
    422c:	41 c6 02 00          	movb   $0x0,(%r10)
    4230:	41 8b 78 04          	mov    0x4(%r8),%edi
    4234:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    423b:	49 63 c1             	movslq %r9d,%rax
    423e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4242:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4246:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    424b:	f2 0f 58 05 cd 88 01 	addsd  0x188cd(%rip),%xmm0        # 1cb20 <fwp_heap+0x1440>
    4252:	00 
    4253:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4257:	48 8d 05 82 74 01 00 	lea    0x17482(%rip),%rax        # 1b6e0 <fwp_heap>
    425e:	48 01 d0             	add    %rdx,%rax
    4261:	48 8b 10             	mov    (%rax),%rdx
    4264:	48 f7 d2             	not    %rdx
    4267:	48 89 11             	mov    %rdx,(%rcx)
    426a:	48 89 08             	mov    %rcx,(%rax)
    426d:	48 29 3d 8c 88 01 00 	sub    %rdi,0x1888c(%rip)        # 1cb00 <fwp_heap+0x1420>
    4274:	f2 0f 11 05 a4 88 01 	movsd  %xmm0,0x188a4(%rip)        # 1cb20 <fwp_heap+0x1440>
    427b:	00 
    427c:	48 83 c4 38          	add    $0x38,%rsp
    4280:	c3                   	ret
    4281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4288:	66 31 d2             	xor    %dx,%dx
    428b:	48 01 d6             	add    %rdx,%rsi
    428e:	48 39 f1             	cmp    %rsi,%rcx
    4291:	0f 85 5d ff ff ff    	jne    41f4 <fwp_mem_free+0x64>
    4297:	49 8b 50 10          	mov    0x10(%r8),%rdx
    429b:	48 29 15 5e 88 01 00 	sub    %rdx,0x1885e(%rip)        # 1cb00 <fwp_heap+0x1420>
    42a2:	48 85 d2             	test   %rdx,%rdx
    42a5:	0f 88 a5 00 00 00    	js     4350 <fwp_mem_free+0x1c0>
    42ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    42b4:	f2 0f 58 05 64 88 01 	addsd  0x18864(%rip),%xmm0        # 1cb20 <fwp_heap+0x1440>
    42bb:	00 
    42bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    42c0:	f2 0f 11 05 58 88 01 	movsd  %xmm0,0x18858(%rip)        # 1cb20 <fwp_heap+0x1440>
    42c7:	00 
    42c8:	48 85 d2             	test   %rdx,%rdx
    42cb:	74 0c                	je     42d9 <fwp_mem_free+0x149>
    42cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    42d0:	0f 84 db 00 00 00    	je     43b1 <fwp_mem_free+0x221>
    42d6:	c6 02 00             	movb   $0x0,(%rdx)
    42d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    42dd:	48 85 c9             	test   %rcx,%rcx
    42e0:	74 3e                	je     4320 <fwp_mem_free+0x190>
    42e2:	48 8b 15 ef 87 01 00 	mov    0x187ef(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    42e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    42ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    42f1:	48 01 d0             	add    %rdx,%rax
    42f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    42f8:	48 89 d6             	mov    %rdx,%rsi
    42fb:	48 29 c6             	sub    %rax,%rsi
    42fe:	83 e6 08             	and    $0x8,%esi
    4301:	74 0d                	je     4310 <fwp_mem_free+0x180>
    4303:	c6 00 00             	movb   $0x0,(%rax)
    4306:	48 83 c0 28          	add    $0x28,%rax
    430a:	48 39 c2             	cmp    %rax,%rdx
    430d:	74 11                	je     4320 <fwp_mem_free+0x190>
    430f:	90                   	nop
    4310:	c6 00 00             	movb   $0x0,(%rax)
    4313:	48 83 c0 50          	add    $0x50,%rax
    4317:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    431b:	48 39 c2             	cmp    %rax,%rdx
    431e:	75 f0                	jne    4310 <fwp_mem_free+0x180>
    4320:	48 01 0d e9 87 01 00 	add    %rcx,0x187e9(%rip)        # 1cb10 <fwp_heap+0x1430>
    4327:	4c 3b 0d a2 87 01 00 	cmp    0x187a2(%rip),%r9        # 1cad0 <fwp_heap+0x13f0>
    432e:	73 07                	jae    4337 <fwp_mem_free+0x1a7>
    4330:	4c 89 0d 99 87 01 00 	mov    %r9,0x18799(%rip)        # 1cad0 <fwp_heap+0x13f0>
    4337:	4c 3b 0d 8a 87 01 00 	cmp    0x1878a(%rip),%r9        # 1cac8 <fwp_heap+0x13e8>
    433e:	0f 83 b0 fe ff ff    	jae    41f4 <fwp_mem_free+0x64>
    4344:	4c 89 0d 7d 87 01 00 	mov    %r9,0x1877d(%rip)        # 1cac8 <fwp_heap+0x13e8>
    434b:	e9 a4 fe ff ff       	jmp    41f4 <fwp_mem_free+0x64>
    4350:	48 89 d1             	mov    %rdx,%rcx
    4353:	83 e2 01             	and    $0x1,%edx
    4356:	66 0f ef c0          	pxor   %xmm0,%xmm0
    435a:	48 d1 e9             	shr    $1,%rcx
    435d:	48 09 d1             	or     %rdx,%rcx
    4360:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    4365:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4369:	e9 46 ff ff ff       	jmp    42b4 <fwp_mem_free+0x124>
    436e:	66 90                	xchg   %ax,%ax
    4370:	4c 89 d7             	mov    %r10,%rdi
    4373:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    4378:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    437d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4382:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4386:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    438b:	e8 c0 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    4390:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4395:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    439a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    439f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    43a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    43a9:	e9 7e fe ff ff       	jmp    422c <fwp_mem_free+0x9c>
    43ae:	66 90                	xchg   %ax,%ax
    43b0:	c3                   	ret
    43b1:	48 89 d7             	mov    %rdx,%rdi
    43b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    43b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    43be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    43c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    43c8:	e8 83 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    43cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    43d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    43d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    43dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    43e1:	e9 f0 fe ff ff       	jmp    42d6 <fwp_mem_free+0x146>
    43e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    43ed:	00 00 00 

00000000000043f0 <fwp_heap_alloc_big>:
    43f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    43f7:	00 00 40 
    43fa:	41 57                	push   %r15
    43fc:	41 56                	push   %r14
    43fe:	41 55                	push   %r13
    4400:	41 54                	push   %r12
    4402:	55                   	push   %rbp
    4403:	53                   	push   %rbx
    4404:	48 83 ec 08          	sub    $0x8,%rsp
    4408:	48 39 f8             	cmp    %rdi,%rax
    440b:	0f 82 fa 00 00 00    	jb     450b <fwp_heap_alloc_big+0x11b>
    4411:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4418:	49 89 fd             	mov    %rdi,%r13
    441b:	41 89 f6             	mov    %esi,%r14d
    441e:	48 c1 ed 10          	shr    $0x10,%rbp
    4422:	48 89 ef             	mov    %rbp,%rdi
    4425:	e8 76 e9 ff ff       	call   2da0 <fwp_heap_chunks>
    442a:	be 01 00 00 00       	mov    $0x1,%esi
    442f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4433:	49 89 c4             	mov    %rax,%r12
    4436:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    443d:	00 
    443e:	48 03 3d 93 86 01 00 	add    0x18693(%rip),%rdi        # 1cad8 <fwp_heap+0x13f8>
    4445:	c6 07 02             	movb   $0x2,(%rdi)
    4448:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    444c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    444f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4453:	e8 88 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4458:	48 83 fd 01          	cmp    $0x1,%rbp
    445c:	76 47                	jbe    44a5 <fwp_heap_alloc_big+0xb5>
    445e:	4c 01 e5             	add    %r12,%rbp
    4461:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    4468:	00 
    4469:	4c 8d 3d 70 72 01 00 	lea    0x17270(%rip),%r15        # 1b6e0 <fwp_heap>
    4470:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    4475:	49 c1 e6 03          	shl    $0x3,%r14
    4479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4480:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4487:	31 f6                	xor    %esi,%esi
    4489:	48 01 dd             	add    %rbx,%rbp
    448c:	48 83 c3 28          	add    $0x28,%rbx
    4490:	48 89 ef             	mov    %rbp,%rdi
    4493:	e8 48 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4498:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    449c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    44a0:	49 39 de             	cmp    %rbx,%r14
    44a3:	75 db                	jne    4480 <fwp_heap_alloc_big+0x90>
    44a5:	49 c1 e4 10          	shl    $0x10,%r12
    44a9:	4c 03 25 e0 85 01 00 	add    0x185e0(%rip),%r12        # 1ca90 <fwp_heap+0x13b0>
    44b0:	4c 89 ea             	mov    %r13,%rdx
    44b3:	31 f6                	xor    %esi,%esi
    44b5:	4c 89 e7             	mov    %r12,%rdi
    44b8:	e8 e3 df ff ff       	call   24a0 <memset@plt>
    44bd:	4c 89 e8             	mov    %r13,%rax
    44c0:	48 03 05 39 86 01 00 	add    0x18639(%rip),%rax        # 1cb00 <fwp_heap+0x1420>
    44c7:	72 42                	jb     450b <fwp_heap_alloc_big+0x11b>
    44c9:	48 39 05 38 86 01 00 	cmp    %rax,0x18638(%rip)        # 1cb08 <fwp_heap+0x1428>
    44d0:	48 89 05 29 86 01 00 	mov    %rax,0x18629(%rip)        # 1cb00 <fwp_heap+0x1420>
    44d7:	73 07                	jae    44e0 <fwp_heap_alloc_big+0xf0>
    44d9:	48 89 05 28 86 01 00 	mov    %rax,0x18628(%rip)        # 1cb08 <fwp_heap+0x1428>
    44e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    44e4:	4c 89 e0             	mov    %r12,%rax
    44e7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    44ec:	f2 0f 58 05 24 86 01 	addsd  0x18624(%rip),%xmm0        # 1cb18 <fwp_heap+0x1438>
    44f3:	00 
    44f4:	f2 0f 11 05 1c 86 01 	movsd  %xmm0,0x1861c(%rip)        # 1cb18 <fwp_heap+0x1438>
    44fb:	00 
    44fc:	48 83 c4 08          	add    $0x8,%rsp
    4500:	5b                   	pop    %rbx
    4501:	5d                   	pop    %rbp
    4502:	41 5c                	pop    %r12
    4504:	41 5d                	pop    %r13
    4506:	41 5e                	pop    %r14
    4508:	41 5f                	pop    %r15
    450a:	c3                   	ret
    450b:	e8 60 e7 ff ff       	call   2c70 <fwp_heap_oom>

0000000000004510 <fwp_heap_alloc_slow>:
    4510:	53                   	push   %rbx
    4511:	48 89 f9             	mov    %rdi,%rcx
    4514:	41 89 f1             	mov    %esi,%r9d
    4517:	48 83 ec 10          	sub    $0x10,%rsp
    451b:	8b 05 63 85 01 00    	mov    0x18563(%rip),%eax        # 1ca84 <fwp_heap+0x13a4>
    4521:	85 c0                	test   %eax,%eax
    4523:	0f 84 c7 00 00 00    	je     45f0 <fwp_heap_alloc_slow+0xe0>
    4529:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4530:	0f 87 dd 00 00 00    	ja     4613 <fwp_heap_alloc_slow+0x103>
    4536:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    453a:	48 8d 3d 9f 71 01 00 	lea    0x1719f(%rip),%rdi        # 1b6e0 <fwp_heap>
    4541:	49 63 f1             	movslq %r9d,%rsi
    4544:	48 c1 e8 04          	shr    $0x4,%rax
    4548:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    454f:	00 00 
    4551:	41 0f b6 c2          	movzbl %r10b,%eax
    4555:	4c 89 d2             	mov    %r10,%rdx
    4558:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    455c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    4563:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    456a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    456e:	48 01 f8             	add    %rdi,%rax
    4571:	4c 8b 00             	mov    (%rax),%r8
    4574:	4d 85 c0             	test   %r8,%r8
    4577:	0f 84 ab 00 00 00    	je     4628 <fwp_heap_alloc_slow+0x118>
    457d:	49 8b 10             	mov    (%r8),%rdx
    4580:	48 f7 d2             	not    %rdx
    4583:	48 89 10             	mov    %rdx,(%rax)
    4586:	41 83 f9 01          	cmp    $0x1,%r9d
    458a:	4c 89 c7             	mov    %r8,%rdi
    458d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4591:	31 f6                	xor    %esi,%esi
    4593:	48 89 ca             	mov    %rcx,%rdx
    4596:	e8 05 df ff ff       	call   24a0 <memset@plt>
    459b:	49 89 c0             	mov    %rax,%r8
    459e:	48 89 d8             	mov    %rbx,%rax
    45a1:	48 03 05 58 85 01 00 	add    0x18558(%rip),%rax        # 1cb00 <fwp_heap+0x1420>
    45a8:	0f 82 d9 00 00 00    	jb     4687 <fwp_heap_alloc_slow+0x177>
    45ae:	48 39 05 53 85 01 00 	cmp    %rax,0x18553(%rip)        # 1cb08 <fwp_heap+0x1428>
    45b5:	48 89 05 44 85 01 00 	mov    %rax,0x18544(%rip)        # 1cb00 <fwp_heap+0x1420>
    45bc:	73 07                	jae    45c5 <fwp_heap_alloc_slow+0xb5>
    45be:	48 89 05 43 85 01 00 	mov    %rax,0x18543(%rip)        # 1cb08 <fwp_heap+0x1428>
    45c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    45c9:	4c 89 c0             	mov    %r8,%rax
    45cc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    45d1:	f2 0f 58 05 3f 85 01 	addsd  0x1853f(%rip),%xmm0        # 1cb18 <fwp_heap+0x1438>
    45d8:	00 
    45d9:	f2 0f 11 05 37 85 01 	movsd  %xmm0,0x18537(%rip)        # 1cb18 <fwp_heap+0x1438>
    45e0:	00 
    45e1:	48 83 c4 10          	add    $0x10,%rsp
    45e5:	5b                   	pop    %rbx
    45e6:	c3                   	ret
    45e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    45ee:	00 00 
    45f0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    45f4:	48 89 3c 24          	mov    %rdi,(%rsp)
    45f8:	e8 73 f2 ff ff       	call   3870 <fwp_heap_init>
    45fd:	48 8b 0c 24          	mov    (%rsp),%rcx
    4601:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4606:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    460d:	0f 86 23 ff ff ff    	jbe    4536 <fwp_heap_alloc_slow+0x26>
    4613:	48 83 c4 10          	add    $0x10,%rsp
    4617:	44 89 ce             	mov    %r9d,%esi
    461a:	48 89 cf             	mov    %rcx,%rdi
    461d:	5b                   	pop    %rbx
    461e:	e9 cd fd ff ff       	jmp    43f0 <fwp_heap_alloc_big>
    4623:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4628:	4c 8b 40 08          	mov    0x8(%rax),%r8
    462c:	4d 85 c0             	test   %r8,%r8
    462f:	74 1f                	je     4650 <fwp_heap_alloc_slow+0x140>
    4631:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4635:	4d 29 c3             	sub    %r8,%r11
    4638:	49 39 db             	cmp    %rbx,%r11
    463b:	72 13                	jb     4650 <fwp_heap_alloc_slow+0x140>
    463d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4641:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4645:	e9 3c ff ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    464a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4650:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4657:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    465b:	44 89 ca             	mov    %r9d,%edx
    465e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4663:	44 89 0c 24          	mov    %r9d,(%rsp)
    4667:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    466b:	44 89 d6             	mov    %r10d,%esi
    466e:	48 01 c7             	add    %rax,%rdi
    4671:	e8 6a fa ff ff       	call   40e0 <fwp_heap_refill>
    4676:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    467b:	44 8b 0c 24          	mov    (%rsp),%r9d
    467f:	49 89 c0             	mov    %rax,%r8
    4682:	e9 ff fe ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    4687:	e8 e4 e5 ff ff       	call   2c70 <fwp_heap_oom>
    468c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004690 <fwp_rc_share>:
    4690:	48 8b 05 21 84 01 00 	mov    0x18421(%rip),%rax        # 1cab8 <fwp_heap+0x13d8>
    4697:	48 2b 3d f2 83 01 00 	sub    0x183f2(%rip),%rdi        # 1ca90 <fwp_heap+0x13b0>
    469e:	48 c1 e0 10          	shl    $0x10,%rax
    46a2:	48 39 c7             	cmp    %rax,%rdi
    46a5:	73 4a                	jae    46f1 <fwp_rc_share+0x61>
    46a7:	48 89 f8             	mov    %rdi,%rax
    46aa:	48 c1 e8 10          	shr    $0x10,%rax
    46ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    46b2:	48 8b 05 1f 84 01 00 	mov    0x1841f(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    46b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    46bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    46c1:	48 85 d2             	test   %rdx,%rdx
    46c4:	74 2b                	je     46f1 <fwp_rc_share+0x61>
    46c6:	0f b6 08             	movzbl (%rax),%ecx
    46c9:	80 f9 02             	cmp    $0x2,%cl
    46cc:	74 2a                	je     46f8 <fwp_rc_share+0x68>
    46ce:	80 f9 01             	cmp    $0x1,%cl
    46d1:	75 1e                	jne    46f1 <fwp_rc_share+0x61>
    46d3:	8b 48 18             	mov    0x18(%rax),%ecx
    46d6:	0f b7 ff             	movzwl %di,%edi
    46d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    46dc:	48 0f af f9          	imul   %rcx,%rdi
    46e0:	48 c1 ef 20          	shr    $0x20,%rdi
    46e4:	48 39 c7             	cmp    %rax,%rdi
    46e7:	73 08                	jae    46f1 <fwp_rc_share+0x61>
    46e9:	48 01 fa             	add    %rdi,%rdx
    46ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    46ef:	75 0d                	jne    46fe <fwp_rc_share+0x6e>
    46f1:	c3                   	ret
    46f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    46f8:	66 85 ff             	test   %di,%di
    46fb:	74 ef                	je     46ec <fwp_rc_share+0x5c>
    46fd:	c3                   	ret
    46fe:	50                   	push   %rax
    46ff:	48 8d 3d d2 3b 00 00 	lea    0x3bd2(%rip),%rdi        # 82d8 <_IO_stdin_used+0x2d8>
    4706:	e8 15 ea ff ff       	call   3120 <fwp_trap>
    470b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000004710 <e69>:
    4710:	f3 0f 1e fa          	endbr64
    4714:	53                   	push   %rbx
    4715:	f2 0f 10 05 53 3d 00 	movsd  0x3d53(%rip),%xmm0        # 8470 <msg.3+0x20>
    471c:	00 
    471d:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    4721:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4726:	48 89 df             	mov    %rbx,%rdi
    4729:	e8 62 ff ff ff       	call   4690 <fwp_rc_share>
    472e:	48 89 d8             	mov    %rbx,%rax
    4731:	5b                   	pop    %rbx
    4732:	c3                   	ret
    4733:	66 90                	xchg   %ax,%ax
    4735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    473c:	00 00 00 00 

0000000000004740 <e45>:
    4740:	f3 0f 1e fa          	endbr64
    4744:	53                   	push   %rbx
    4745:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4749:	f2 0f 58 47 08       	addsd  0x8(%rdi),%xmm0
    474e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4753:	48 89 df             	mov    %rbx,%rdi
    4756:	e8 35 ff ff ff       	call   4690 <fwp_rc_share>
    475b:	48 89 d8             	mov    %rbx,%rax
    475e:	5b                   	pop    %rbx
    475f:	c3                   	ret

0000000000004760 <e32>:
    4760:	f3 0f 1e fa          	endbr64
    4764:	53                   	push   %rbx
    4765:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    476a:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    476e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4773:	48 89 df             	mov    %rbx,%rdi
    4776:	e8 15 ff ff ff       	call   4690 <fwp_rc_share>
    477b:	48 89 d8             	mov    %rbx,%rax
    477e:	5b                   	pop    %rbx
    477f:	c3                   	ret

0000000000004780 <fwp_rc_dup>:
    4780:	f3 0f 1e fa          	endbr64
    4784:	48 8b 05 2d 83 01 00 	mov    0x1832d(%rip),%rax        # 1cab8 <fwp_heap+0x13d8>
    478b:	48 2b 3d fe 82 01 00 	sub    0x182fe(%rip),%rdi        # 1ca90 <fwp_heap+0x13b0>
    4792:	48 c1 e0 10          	shl    $0x10,%rax
    4796:	48 39 c7             	cmp    %rax,%rdi
    4799:	73 56                	jae    47f1 <fwp_rc_dup+0x71>
    479b:	48 89 f8             	mov    %rdi,%rax
    479e:	48 c1 e8 10          	shr    $0x10,%rax
    47a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    47a6:	48 8b 05 2b 83 01 00 	mov    0x1832b(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    47ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    47b1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    47b5:	48 85 c0             	test   %rax,%rax
    47b8:	74 37                	je     47f1 <fwp_rc_dup+0x71>
    47ba:	0f b6 0a             	movzbl (%rdx),%ecx
    47bd:	80 f9 02             	cmp    $0x2,%cl
    47c0:	74 36                	je     47f8 <fwp_rc_dup+0x78>
    47c2:	80 f9 01             	cmp    $0x1,%cl
    47c5:	75 2a                	jne    47f1 <fwp_rc_dup+0x71>
    47c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    47ca:	0f b7 ff             	movzwl %di,%edi
    47cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    47d0:	48 0f af f9          	imul   %rcx,%rdi
    47d4:	48 c1 ef 20          	shr    $0x20,%rdi
    47d8:	48 39 d7             	cmp    %rdx,%rdi
    47db:	73 14                	jae    47f1 <fwp_rc_dup+0x71>
    47dd:	48 01 f8             	add    %rdi,%rax
    47e0:	0f b6 10             	movzbl (%rax),%edx
    47e3:	84 d2                	test   %dl,%dl
    47e5:	74 0a                	je     47f1 <fwp_rc_dup+0x71>
    47e7:	80 fa fd             	cmp    $0xfd,%dl
    47ea:	77 14                	ja     4800 <fwp_rc_dup+0x80>
    47ec:	83 c2 01             	add    $0x1,%edx
    47ef:	88 10                	mov    %dl,(%rax)
    47f1:	c3                   	ret
    47f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    47f8:	66 85 ff             	test   %di,%di
    47fb:	74 e3                	je     47e0 <fwp_rc_dup+0x60>
    47fd:	c3                   	ret
    47fe:	66 90                	xchg   %ax,%ax
    4800:	48 89 c7             	mov    %rax,%rdi
    4803:	e9 28 f6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    4808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    480f:	00 

0000000000004810 <fwp_task_dispose>:
    4810:	53                   	push   %rbx
    4811:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4815:	0f 84 eb de ff ff    	je     2706 <fwp_task_dispose.cold>
    481b:	48 89 fb             	mov    %rdi,%rbx
    481e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4823:	0f 85 dd de ff ff    	jne    2706 <fwp_task_dispose.cold>
    4829:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    482d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4834:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    483b:	00 
    483c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4840:	48 85 ff             	test   %rdi,%rdi
    4843:	74 07                	je     484c <fwp_task_dispose+0x3c>
    4845:	48 85 c0             	test   %rax,%rax
    4848:	74 02                	je     484c <fwp_task_dispose+0x3c>
    484a:	ff d0                	call   *%rax
    484c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4853:	e8 38 f9 ff ff       	call   4190 <fwp_mem_free>
    4858:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    485f:	00 00 00 00 
    4863:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4867:	74 6f                	je     48d8 <fwp_task_dispose+0xc8>
    4869:	48 8b 15 48 82 01 00 	mov    0x18248(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    4870:	48 89 d8             	mov    %rbx,%rax
    4873:	48 2b 05 16 82 01 00 	sub    0x18216(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    487a:	48 c1 e2 10          	shl    $0x10,%rdx
    487e:	48 39 d0             	cmp    %rdx,%rax
    4881:	73 4c                	jae    48cf <fwp_task_dispose+0xbf>
    4883:	48 89 c2             	mov    %rax,%rdx
    4886:	48 c1 ea 10          	shr    $0x10,%rdx
    488a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    488e:	48 8b 15 43 82 01 00 	mov    0x18243(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    4895:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4899:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    489d:	48 85 c9             	test   %rcx,%rcx
    48a0:	74 2d                	je     48cf <fwp_task_dispose+0xbf>
    48a2:	0f b6 32             	movzbl (%rdx),%esi
    48a5:	40 80 fe 02          	cmp    $0x2,%sil
    48a9:	74 3d                	je     48e8 <fwp_task_dispose+0xd8>
    48ab:	40 80 fe 01          	cmp    $0x1,%sil
    48af:	75 1e                	jne    48cf <fwp_task_dispose+0xbf>
    48b1:	8b 72 18             	mov    0x18(%rdx),%esi
    48b4:	0f b7 c0             	movzwl %ax,%eax
    48b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    48ba:	48 0f af c6          	imul   %rsi,%rax
    48be:	48 c1 e8 20          	shr    $0x20,%rax
    48c2:	48 39 d0             	cmp    %rdx,%rax
    48c5:	73 08                	jae    48cf <fwp_task_dispose+0xbf>
    48c7:	48 01 c1             	add    %rax,%rcx
    48ca:	80 39 01             	cmpb   $0x1,(%rcx)
    48cd:	74 09                	je     48d8 <fwp_task_dispose+0xc8>
    48cf:	5b                   	pop    %rbx
    48d0:	c3                   	ret
    48d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d8:	48 89 df             	mov    %rbx,%rdi
    48db:	5b                   	pop    %rbx
    48dc:	e9 af f8 ff ff       	jmp    4190 <fwp_mem_free>
    48e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48e8:	66 85 c0             	test   %ax,%ax
    48eb:	74 dd                	je     48ca <fwp_task_dispose+0xba>
    48ed:	5b                   	pop    %rbx
    48ee:	c3                   	ret
    48ef:	90                   	nop

00000000000048f0 <fwp_free_zombie>:
    48f0:	48 8b 15 b9 6d 01 00 	mov    0x16db9(%rip),%rdx        # 1b6b0 <fwp_zombie>
    48f7:	48 85 d2             	test   %rdx,%rdx
    48fa:	0f 84 98 00 00 00    	je     4998 <fwp_free_zombie+0xa8>
    4900:	48 3b 15 b9 6d 01 00 	cmp    0x16db9(%rip),%rdx        # 1b6c0 <fwp_cur>
    4907:	0f 84 8b 00 00 00    	je     4998 <fwp_free_zombie+0xa8>
    490d:	48 83 ec 18          	sub    $0x18,%rsp
    4911:	48 63 05 84 67 01 00 	movslq 0x16784(%rip),%rax        # 1b09c <fwp_stack_pool_n>
    4918:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    491c:	83 f8 3f             	cmp    $0x3f,%eax
    491f:	7f 7f                	jg     49a0 <fwp_free_zombie+0xb0>
    4921:	8d 48 01             	lea    0x1(%rax),%ecx
    4924:	89 0d 72 67 01 00    	mov    %ecx,0x16772(%rip)        # 1b09c <fwp_stack_pool_n>
    492a:	48 8d 0d 6f 67 01 00 	lea    0x1676f(%rip),%rcx        # 1b0a0 <fwp_stack_pool>
    4931:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4935:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    493c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4940:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4947:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    494b:	48 85 c9             	test   %rcx,%rcx
    494e:	0f 84 fc 00 00 00    	je     4a50 <fwp_free_zombie+0x160>
    4954:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    495b:	48 85 c0             	test   %rax,%rax
    495e:	74 07                	je     4967 <fwp_free_zombie+0x77>
    4960:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4967:	8b 42 5c             	mov    0x5c(%rdx),%eax
    496a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    496e:	48 c7 05 37 6d 01 00 	movq   $0x0,0x16d37(%rip)        # 1b6b0 <fwp_zombie>
    4975:	00 00 00 00 
    4979:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4980:	85 c0                	test   %eax,%eax
    4982:	74 34                	je     49b8 <fwp_free_zombie+0xc8>
    4984:	83 f8 01             	cmp    $0x1,%eax
    4987:	0f 84 b3 00 00 00    	je     4a40 <fwp_free_zombie+0x150>
    498d:	48 83 c4 18          	add    $0x18,%rsp
    4991:	c3                   	ret
    4992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4998:	c3                   	ret
    4999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    49a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    49a9:	e8 02 dc ff ff       	call   25b0 <munmap@plt>
    49ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    49b3:	eb 80                	jmp    4935 <fwp_free_zombie+0x45>
    49b5:	0f 1f 00             	nopl   (%rax)
    49b8:	48 8b 0d f9 80 01 00 	mov    0x180f9(%rip),%rcx        # 1cab8 <fwp_heap+0x13d8>
    49bf:	48 89 d0             	mov    %rdx,%rax
    49c2:	48 2b 05 c7 80 01 00 	sub    0x180c7(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    49c9:	48 c1 e1 10          	shl    $0x10,%rcx
    49cd:	48 39 c8             	cmp    %rcx,%rax
    49d0:	73 bb                	jae    498d <fwp_free_zombie+0x9d>
    49d2:	48 89 c1             	mov    %rax,%rcx
    49d5:	48 c1 e9 10          	shr    $0x10,%rcx
    49d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    49dd:	48 8b 0d f4 80 01 00 	mov    0x180f4(%rip),%rcx        # 1cad8 <fwp_heap+0x13f8>
    49e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    49e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    49ec:	48 85 c9             	test   %rcx,%rcx
    49ef:	74 9c                	je     498d <fwp_free_zombie+0x9d>
    49f1:	0f b6 3e             	movzbl (%rsi),%edi
    49f4:	40 80 ff 02          	cmp    $0x2,%dil
    49f8:	74 66                	je     4a60 <fwp_free_zombie+0x170>
    49fa:	40 80 ff 01          	cmp    $0x1,%dil
    49fe:	75 8d                	jne    498d <fwp_free_zombie+0x9d>
    4a00:	8b 7e 18             	mov    0x18(%rsi),%edi
    4a03:	0f b7 c0             	movzwl %ax,%eax
    4a06:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4a09:	48 0f af c7          	imul   %rdi,%rax
    4a0d:	48 c1 e8 20          	shr    $0x20,%rax
    4a11:	48 39 f0             	cmp    %rsi,%rax
    4a14:	0f 83 73 ff ff ff    	jae    498d <fwp_free_zombie+0x9d>
    4a1a:	48 01 c1             	add    %rax,%rcx
    4a1d:	0f b6 01             	movzbl (%rcx),%eax
    4a20:	84 c0                	test   %al,%al
    4a22:	0f 84 65 ff ff ff    	je     498d <fwp_free_zombie+0x9d>
    4a28:	3c 01                	cmp    $0x1,%al
    4a2a:	74 14                	je     4a40 <fwp_free_zombie+0x150>
    4a2c:	3c ff                	cmp    $0xff,%al
    4a2e:	74 3b                	je     4a6b <fwp_free_zombie+0x17b>
    4a30:	83 e8 01             	sub    $0x1,%eax
    4a33:	88 01                	mov    %al,(%rcx)
    4a35:	e9 53 ff ff ff       	jmp    498d <fwp_free_zombie+0x9d>
    4a3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a40:	48 89 d7             	mov    %rdx,%rdi
    4a43:	48 83 c4 18          	add    $0x18,%rsp
    4a47:	e9 c4 fd ff ff       	jmp    4810 <fwp_task_dispose>
    4a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a50:	48 89 05 31 6c 01 00 	mov    %rax,0x16c31(%rip)        # 1b688 <fwp_tasks_active>
    4a57:	e9 ff fe ff ff       	jmp    495b <fwp_free_zombie+0x6b>
    4a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a60:	66 85 c0             	test   %ax,%ax
    4a63:	0f 85 24 ff ff ff    	jne    498d <fwp_free_zombie+0x9d>
    4a69:	eb b2                	jmp    4a1d <fwp_free_zombie+0x12d>
    4a6b:	48 89 ca             	mov    %rcx,%rdx
    4a6e:	48 8d 35 6b 6c 01 00 	lea    0x16c6b(%rip),%rsi        # 1b6e0 <fwp_heap>
    4a75:	48 c1 ea 11          	shr    $0x11,%rdx
    4a79:	48 31 ca             	xor    %rcx,%rdx
    4a7c:	48 89 d0             	mov    %rdx,%rax
    4a7f:	48 c1 e8 09          	shr    $0x9,%rax
    4a83:	48 31 c2             	xor    %rax,%rdx
    4a86:	0f b6 d2             	movzbl %dl,%edx
    4a89:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4a90:	00 
    4a91:	48 85 c0             	test   %rax,%rax
    4a94:	75 13                	jne    4aa9 <fwp_free_zombie+0x1b9>
    4a96:	eb 4c                	jmp    4ae4 <fwp_free_zombie+0x1f4>
    4a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a9f:	00 
    4aa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4aa4:	48 85 c0             	test   %rax,%rax
    4aa7:	74 3b                	je     4ae4 <fwp_free_zombie+0x1f4>
    4aa9:	48 89 c2             	mov    %rax,%rdx
    4aac:	48 39 08             	cmp    %rcx,(%rax)
    4aaf:	75 ef                	jne    4aa0 <fwp_free_zombie+0x1b0>
    4ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4ab5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4ab9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4abd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4ac4:	0f 85 c3 fe ff ff    	jne    498d <fwp_free_zombie+0x9d>
    4aca:	48 89 cf             	mov    %rcx,%rdi
    4acd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4ad2:	e8 79 f4 ff ff       	call   3f50 <fwp_rc_forget_slot>
    4ad7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4adc:	c6 01 fe             	movb   $0xfe,(%rcx)
    4adf:	e9 a9 fe ff ff       	jmp    498d <fwp_free_zombie+0x9d>
    4ae4:	48 8d 3d c5 37 00 00 	lea    0x37c5(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    4aeb:	e8 30 e6 ff ff       	call   3120 <fwp_trap>

0000000000004af0 <fwp_block>:
    4af0:	48 83 ec 08          	sub    $0x8,%rsp
    4af4:	48 8b 05 ad 6b 01 00 	mov    0x16bad(%rip),%rax        # 1b6a8 <fwp_ready_head>
    4afb:	48 85 c0             	test   %rax,%rax
    4afe:	0f 84 1c 01 00 00    	je     4c20 <fwp_block+0x130>
    4b04:	90                   	nop
    4b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b0c:	00 00 00 00 
    4b10:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4b17:	48 89 15 8a 6b 01 00 	mov    %rdx,0x16b8a(%rip)        # 1b6a8 <fwp_ready_head>
    4b1e:	48 85 d2             	test   %rdx,%rdx
    4b21:	0f 84 19 01 00 00    	je     4c40 <fwp_block+0x150>
    4b27:	48 8b 15 92 6b 01 00 	mov    0x16b92(%rip),%rdx        # 1b6c0 <fwp_cur>
    4b2e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b32:	48 39 c2             	cmp    %rax,%rdx
    4b35:	0f 84 d5 00 00 00    	je     4c10 <fwp_block+0x120>
    4b3b:	48 8b 0d fe 87 01 00 	mov    0x187fe(%rip),%rcx        # 1d340 <fwp_state_owners>
    4b42:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4b46:	48 89 05 73 6b 01 00 	mov    %rax,0x16b73(%rip)        # 1b6c0 <fwp_cur>
    4b4d:	f3 0f 7e 05 13 88 01 	movq   0x18813(%rip),%xmm0        # 1d368 <fwp_foreign_callbacks>
    4b54:	00 
    4b55:	0f 16 05 fc 87 01 00 	movhps 0x187fc(%rip),%xmm0        # 1d358 <fwp_state>
    4b5c:	f3 0f 7e 0d fc 87 01 	movq   0x187fc(%rip),%xmm1        # 1d360 <fwp_handlers>
    4b63:	00 
    4b64:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4b6b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4b72:	0f 16 0d f7 87 01 00 	movhps 0x187f7(%rip),%xmm1        # 1d370 <fwp_cleanups>
    4b79:	f3 0f 7e 05 cf 87 01 	movq   0x187cf(%rip),%xmm0        # 1d350 <fwp_state_len>
    4b80:	00 
    4b81:	0f 16 05 c0 87 01 00 	movhps 0x187c0(%rip),%xmm0        # 1d348 <fwp_state_cap>
    4b88:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4b8f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4b96:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b9a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4ba1:	48 89 0d b8 87 01 00 	mov    %rcx,0x187b8(%rip)        # 1d360 <fwp_handlers>
    4ba8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4baf:	48 89 0d ba 87 01 00 	mov    %rcx,0x187ba(%rip)        # 1d370 <fwp_cleanups>
    4bb6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4bbd:	48 89 0d a4 87 01 00 	mov    %rcx,0x187a4(%rip)        # 1d368 <fwp_foreign_callbacks>
    4bc4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4bcb:	48 89 0d 86 87 01 00 	mov    %rcx,0x18786(%rip)        # 1d358 <fwp_state>
    4bd2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4bd9:	48 89 0d 70 87 01 00 	mov    %rcx,0x18770(%rip)        # 1d350 <fwp_state_len>
    4be0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4be7:	48 89 0d 5a 87 01 00 	mov    %rcx,0x1875a(%rip)        # 1d348 <fwp_state_cap>
    4bee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4bf5:	48 89 0d 44 87 01 00 	mov    %rcx,0x18744(%rip)        # 1d340 <fwp_state_owners>
    4bfc:	e8 6f d8 ff ff       	call   2470 <swapcontext@plt>
    4c01:	f3 0f 1e fa          	endbr64
    4c05:	e8 e6 fc ff ff       	call   48f0 <fwp_free_zombie>
    4c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c10:	8b 05 82 64 01 00    	mov    0x16482(%rip),%eax        # 1b098 <fwp_slice>
    4c16:	85 c0                	test   %eax,%eax
    4c18:	74 36                	je     4c50 <fwp_block+0x160>
    4c1a:	48 83 c4 08          	add    $0x8,%rsp
    4c1e:	c3                   	ret
    4c1f:	90                   	nop
    4c20:	e8 6b ef ff ff       	call   3b90 <fwp_poll_events>
    4c25:	48 8b 05 7c 6a 01 00 	mov    0x16a7c(%rip),%rax        # 1b6a8 <fwp_ready_head>
    4c2c:	48 85 c0             	test   %rax,%rax
    4c2f:	0f 85 db fe ff ff    	jne    4b10 <fwp_block+0x20>
    4c35:	eb e9                	jmp    4c20 <fwp_block+0x130>
    4c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c3e:	00 00 
    4c40:	48 c7 05 55 6a 01 00 	movq   $0x0,0x16a55(%rip)        # 1b6a0 <fwp_ready_tail>
    4c47:	00 00 00 00 
    4c4b:	e9 d7 fe ff ff       	jmp    4b27 <fwp_block+0x37>
    4c50:	48 8d 3d 67 34 00 00 	lea    0x3467(%rip),%rdi        # 80be <_IO_stdin_used+0xbe>
    4c57:	e8 24 d7 ff ff       	call   2380 <getenv@plt>
    4c5c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4c61:	48 85 c0             	test   %rax,%rax
    4c64:	74 05                	je     4c6b <fwp_block+0x17b>
    4c66:	80 38 00             	cmpb   $0x0,(%rax)
    4c69:	75 0b                	jne    4c76 <fwp_block+0x186>
    4c6b:	89 15 27 64 01 00    	mov    %edx,0x16427(%rip)        # 1b098 <fwp_slice>
    4c71:	48 83 c4 08          	add    $0x8,%rsp
    4c75:	c3                   	ret
    4c76:	ba 0a 00 00 00       	mov    $0xa,%edx
    4c7b:	31 f6                	xor    %esi,%esi
    4c7d:	48 89 c7             	mov    %rax,%rdi
    4c80:	e8 ab d8 ff ff       	call   2530 <strtoll@plt>
    4c85:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4c89:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4c90:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4c95:	0f 46 d0             	cmovbe %eax,%edx
    4c98:	eb d1                	jmp    4c6b <fwp_block+0x17b>
    4c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004ca0 <fwp_map_items>:
    4ca0:	53                   	push   %rbx
    4ca1:	48 89 fb             	mov    %rdi,%rbx
    4ca4:	48 83 ec 10          	sub    $0x10,%rsp
    4ca8:	48 85 ff             	test   %rdi,%rdi
    4cab:	0f 84 6f 01 00 00    	je     4e20 <fwp_map_items+0x180>
    4cb1:	48 89 fa             	mov    %rdi,%rdx
    4cb4:	31 c0                	xor    %eax,%eax
    4cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4cbd:	00 00 00 
    4cc0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    4cc4:	48 89 c1             	mov    %rax,%rcx
    4cc7:	48 83 c0 01          	add    $0x1,%rax
    4ccb:	48 85 d2             	test   %rdx,%rdx
    4cce:	75 f0                	jne    4cc0 <fwp_map_items+0x20>
    4cd0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    4cd7:	ff ff 1f 
    4cda:	48 89 06             	mov    %rax,(%rsi)
    4cdd:	48 39 c2             	cmp    %rax,%rdx
    4ce0:	0f 82 55 01 00 00    	jb     4e3b <fwp_map_items+0x19b>
    4ce6:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    4ced:	00 
    4cee:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    4cf5:	0f 96 c2             	setbe  %dl
    4cf8:	8b 0d 86 7d 01 00    	mov    0x17d86(%rip),%ecx        # 1ca84 <fwp_heap+0x13a4>
    4cfe:	48 8d 05 db 69 01 00 	lea    0x169db(%rip),%rax        # 1b6e0 <fwp_heap>
    4d05:	85 c9                	test   %ecx,%ecx
    4d07:	0f 84 ee 00 00 00    	je     4dfb <fwp_map_items+0x15b>
    4d0d:	84 d2                	test   %dl,%dl
    4d0f:	0f 84 e6 00 00 00    	je     4dfb <fwp_map_items+0x15b>
    4d15:	48 8d 57 0f          	lea    0xf(%rdi),%rdx
    4d19:	48 c1 ea 04          	shr    $0x4,%rdx
    4d1d:	0f b6 94 10 a0 0f 00 	movzbl 0xfa0(%rax,%rdx,1),%edx
    4d24:	00 
    4d25:	44 8b 84 90 00 0f 00 	mov    0xf00(%rax,%rdx,4),%r8d
    4d2c:	00 
    4d2d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    4d31:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    4d35:	48 8b 88 80 07 00 00 	mov    0x780(%rax),%rcx
    4d3c:	48 85 c9             	test   %rcx,%rcx
    4d3f:	0f 84 9b 00 00 00    	je     4de0 <fwp_map_items+0x140>
    4d45:	48 8b 11             	mov    (%rcx),%rdx
    4d48:	48 f7 d2             	not    %rdx
    4d4b:	48 89 90 80 07 00 00 	mov    %rdx,0x780(%rax)
    4d52:	4c 89 c2             	mov    %r8,%rdx
    4d55:	48 89 cf             	mov    %rcx,%rdi
    4d58:	31 f6                	xor    %esi,%esi
    4d5a:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    4d5f:	e8 3c d7 ff ff       	call   24a0 <memset@plt>
    4d64:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4d69:	48 89 c1             	mov    %rax,%rcx
    4d6c:	4c 89 c0             	mov    %r8,%rax
    4d6f:	48 03 05 8a 7d 01 00 	add    0x17d8a(%rip),%rax        # 1cb00 <fwp_heap+0x1420>
    4d76:	0f 82 ba 00 00 00    	jb     4e36 <fwp_map_items+0x196>
    4d7c:	48 39 05 85 7d 01 00 	cmp    %rax,0x17d85(%rip)        # 1cb08 <fwp_heap+0x1428>
    4d83:	48 89 05 76 7d 01 00 	mov    %rax,0x17d76(%rip)        # 1cb00 <fwp_heap+0x1420>
    4d8a:	73 07                	jae    4d93 <fwp_map_items+0xf3>
    4d8c:	48 89 05 75 7d 01 00 	mov    %rax,0x17d75(%rip)        # 1cb08 <fwp_heap+0x1428>
    4d93:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d97:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4d9c:	f2 0f 58 05 74 7d 01 	addsd  0x17d74(%rip),%xmm0        # 1cb18 <fwp_heap+0x1438>
    4da3:	00 
    4da4:	f2 0f 11 05 6c 7d 01 	movsd  %xmm0,0x17d6c(%rip)        # 1cb18 <fwp_heap+0x1438>
    4dab:	00 
    4dac:	48 89 c8             	mov    %rcx,%rax
    4daf:	48 85 db             	test   %rbx,%rbx
    4db2:	74 21                	je     4dd5 <fwp_map_items+0x135>
    4db4:	90                   	nop
    4db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dbc:	00 00 00 00 
    4dc0:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    4dc4:	48 83 c0 08          	add    $0x8,%rax
    4dc8:	48 89 50 f8          	mov    %rdx,-0x8(%rax)
    4dcc:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    4dd0:	48 85 db             	test   %rbx,%rbx
    4dd3:	75 eb                	jne    4dc0 <fwp_map_items+0x120>
    4dd5:	48 83 c4 10          	add    $0x10,%rsp
    4dd9:	48 89 c8             	mov    %rcx,%rax
    4ddc:	5b                   	pop    %rbx
    4ddd:	c3                   	ret
    4dde:	66 90                	xchg   %ax,%ax
    4de0:	48 8b 88 88 07 00 00 	mov    0x788(%rax),%rcx
    4de7:	48 85 c9             	test   %rcx,%rcx
    4dea:	74 0f                	je     4dfb <fwp_map_items+0x15b>
    4dec:	48 8b 90 90 07 00 00 	mov    0x790(%rax),%rdx
    4df3:	48 29 ca             	sub    %rcx,%rdx
    4df6:	4c 39 c2             	cmp    %r8,%rdx
    4df9:	73 0f                	jae    4e0a <fwp_map_items+0x16a>
    4dfb:	be 02 00 00 00       	mov    $0x2,%esi
    4e00:	e8 0b f7 ff ff       	call   4510 <fwp_heap_alloc_slow>
    4e05:	48 89 c1             	mov    %rax,%rcx
    4e08:	eb a2                	jmp    4dac <fwp_map_items+0x10c>
    4e0a:	4a 8d 14 01          	lea    (%rcx,%r8,1),%rdx
    4e0e:	48 89 90 88 07 00 00 	mov    %rdx,0x788(%rax)
    4e15:	e9 38 ff ff ff       	jmp    4d52 <fwp_map_items+0xb2>
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    4e27:	ba 01 00 00 00       	mov    $0x1,%edx
    4e2c:	bf 08 00 00 00       	mov    $0x8,%edi
    4e31:	e9 c2 fe ff ff       	jmp    4cf8 <fwp_map_items+0x58>
    4e36:	e8 35 de ff ff       	call   2c70 <fwp_heap_oom>
    4e3b:	48 8d 3d 88 32 00 00 	lea    0x3288(%rip),%rdi        # 80ca <_IO_stdin_used+0xca>
    4e42:	e8 d9 e2 ff ff       	call   3120 <fwp_trap>
    4e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4e4e:	00 00 

0000000000004e50 <fwp_caps32>:
    4e50:	f3 0f 1e fa          	endbr64
    4e54:	85 f6                	test   %esi,%esi
    4e56:	74 08                	je     4e60 <fwp_caps32+0x10>
    4e58:	c3                   	ret
    4e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e60:	48 8b 15 51 7c 01 00 	mov    0x17c51(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    4e67:	48 89 f8             	mov    %rdi,%rax
    4e6a:	48 2b 05 1f 7c 01 00 	sub    0x17c1f(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    4e71:	48 c1 e2 10          	shl    $0x10,%rdx
    4e75:	48 39 d0             	cmp    %rdx,%rax
    4e78:	73 de                	jae    4e58 <fwp_caps32+0x8>
    4e7a:	48 89 c2             	mov    %rax,%rdx
    4e7d:	48 c1 ea 10          	shr    $0x10,%rdx
    4e81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e85:	48 8b 15 4c 7c 01 00 	mov    0x17c4c(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    4e8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4e90:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4e94:	48 85 c9             	test   %rcx,%rcx
    4e97:	74 bf                	je     4e58 <fwp_caps32+0x8>
    4e99:	0f b6 32             	movzbl (%rdx),%esi
    4e9c:	40 80 fe 02          	cmp    $0x2,%sil
    4ea0:	74 2e                	je     4ed0 <fwp_caps32+0x80>
    4ea2:	40 80 fe 01          	cmp    $0x1,%sil
    4ea6:	75 b0                	jne    4e58 <fwp_caps32+0x8>
    4ea8:	8b 72 18             	mov    0x18(%rdx),%esi
    4eab:	0f b7 c0             	movzwl %ax,%eax
    4eae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4eb1:	48 0f af c6          	imul   %rsi,%rax
    4eb5:	48 c1 e8 20          	shr    $0x20,%rax
    4eb9:	48 39 d0             	cmp    %rdx,%rax
    4ebc:	73 9a                	jae    4e58 <fwp_caps32+0x8>
    4ebe:	48 01 c1             	add    %rax,%rcx
    4ec1:	80 39 01             	cmpb   $0x1,(%rcx)
    4ec4:	75 92                	jne    4e58 <fwp_caps32+0x8>
    4ec6:	e9 c5 f2 ff ff       	jmp    4190 <fwp_mem_free>
    4ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed0:	66 85 c0             	test   %ax,%ax
    4ed3:	74 ec                	je     4ec1 <fwp_caps32+0x71>
    4ed5:	c3                   	ret
    4ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4edd:	00 00 00 

0000000000004ee0 <fwp_caps45>:
    4ee0:	f3 0f 1e fa          	endbr64
    4ee4:	85 f6                	test   %esi,%esi
    4ee6:	74 08                	je     4ef0 <fwp_caps45+0x10>
    4ee8:	c3                   	ret
    4ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ef0:	48 8b 15 c1 7b 01 00 	mov    0x17bc1(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    4ef7:	48 89 f8             	mov    %rdi,%rax
    4efa:	48 2b 05 8f 7b 01 00 	sub    0x17b8f(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    4f01:	48 c1 e2 10          	shl    $0x10,%rdx
    4f05:	48 39 d0             	cmp    %rdx,%rax
    4f08:	73 de                	jae    4ee8 <fwp_caps45+0x8>
    4f0a:	48 89 c2             	mov    %rax,%rdx
    4f0d:	48 c1 ea 10          	shr    $0x10,%rdx
    4f11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f15:	48 8b 15 bc 7b 01 00 	mov    0x17bbc(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    4f1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f24:	48 85 c9             	test   %rcx,%rcx
    4f27:	74 bf                	je     4ee8 <fwp_caps45+0x8>
    4f29:	0f b6 32             	movzbl (%rdx),%esi
    4f2c:	40 80 fe 02          	cmp    $0x2,%sil
    4f30:	74 2e                	je     4f60 <fwp_caps45+0x80>
    4f32:	40 80 fe 01          	cmp    $0x1,%sil
    4f36:	75 b0                	jne    4ee8 <fwp_caps45+0x8>
    4f38:	8b 72 18             	mov    0x18(%rdx),%esi
    4f3b:	0f b7 c0             	movzwl %ax,%eax
    4f3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4f41:	48 0f af c6          	imul   %rsi,%rax
    4f45:	48 c1 e8 20          	shr    $0x20,%rax
    4f49:	48 39 d0             	cmp    %rdx,%rax
    4f4c:	73 9a                	jae    4ee8 <fwp_caps45+0x8>
    4f4e:	48 01 c1             	add    %rax,%rcx
    4f51:	80 39 01             	cmpb   $0x1,(%rcx)
    4f54:	75 92                	jne    4ee8 <fwp_caps45+0x8>
    4f56:	e9 35 f2 ff ff       	jmp    4190 <fwp_mem_free>
    4f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f60:	66 85 c0             	test   %ax,%ax
    4f63:	74 ec                	je     4f51 <fwp_caps45+0x71>
    4f65:	c3                   	ret
    4f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f6d:	00 00 00 

0000000000004f70 <fwp_caps69>:
    4f70:	f3 0f 1e fa          	endbr64
    4f74:	85 f6                	test   %esi,%esi
    4f76:	74 08                	je     4f80 <fwp_caps69+0x10>
    4f78:	c3                   	ret
    4f79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f80:	48 8b 15 31 7b 01 00 	mov    0x17b31(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    4f87:	48 89 f8             	mov    %rdi,%rax
    4f8a:	48 2b 05 ff 7a 01 00 	sub    0x17aff(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    4f91:	48 c1 e2 10          	shl    $0x10,%rdx
    4f95:	48 39 d0             	cmp    %rdx,%rax
    4f98:	73 de                	jae    4f78 <fwp_caps69+0x8>
    4f9a:	48 89 c2             	mov    %rax,%rdx
    4f9d:	48 c1 ea 10          	shr    $0x10,%rdx
    4fa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4fa5:	48 8b 15 2c 7b 01 00 	mov    0x17b2c(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    4fac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4fb0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4fb4:	48 85 c9             	test   %rcx,%rcx
    4fb7:	74 bf                	je     4f78 <fwp_caps69+0x8>
    4fb9:	0f b6 32             	movzbl (%rdx),%esi
    4fbc:	40 80 fe 02          	cmp    $0x2,%sil
    4fc0:	74 2e                	je     4ff0 <fwp_caps69+0x80>
    4fc2:	40 80 fe 01          	cmp    $0x1,%sil
    4fc6:	75 b0                	jne    4f78 <fwp_caps69+0x8>
    4fc8:	8b 72 18             	mov    0x18(%rdx),%esi
    4fcb:	0f b7 c0             	movzwl %ax,%eax
    4fce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4fd1:	48 0f af c6          	imul   %rsi,%rax
    4fd5:	48 c1 e8 20          	shr    $0x20,%rax
    4fd9:	48 39 d0             	cmp    %rdx,%rax
    4fdc:	73 9a                	jae    4f78 <fwp_caps69+0x8>
    4fde:	48 01 c1             	add    %rax,%rcx
    4fe1:	80 39 01             	cmpb   $0x1,(%rcx)
    4fe4:	75 92                	jne    4f78 <fwp_caps69+0x8>
    4fe6:	e9 a5 f1 ff ff       	jmp    4190 <fwp_mem_free>
    4feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ff0:	66 85 c0             	test   %ax,%ax
    4ff3:	74 ec                	je     4fe1 <fwp_caps69+0x71>
    4ff5:	c3                   	ret
    4ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ffd:	00 00 00 

0000000000005000 <fwp_caps74>:
    5000:	f3 0f 1e fa          	endbr64
    5004:	85 f6                	test   %esi,%esi
    5006:	74 08                	je     5010 <fwp_caps74+0x10>
    5008:	c3                   	ret
    5009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5010:	48 8b 15 a1 7a 01 00 	mov    0x17aa1(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    5017:	48 89 f8             	mov    %rdi,%rax
    501a:	48 2b 05 6f 7a 01 00 	sub    0x17a6f(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    5021:	48 c1 e2 10          	shl    $0x10,%rdx
    5025:	48 39 d0             	cmp    %rdx,%rax
    5028:	73 de                	jae    5008 <fwp_caps74+0x8>
    502a:	48 89 c2             	mov    %rax,%rdx
    502d:	48 c1 ea 10          	shr    $0x10,%rdx
    5031:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5035:	48 8b 15 9c 7a 01 00 	mov    0x17a9c(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    503c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5040:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    5044:	48 85 c9             	test   %rcx,%rcx
    5047:	74 bf                	je     5008 <fwp_caps74+0x8>
    5049:	0f b6 32             	movzbl (%rdx),%esi
    504c:	40 80 fe 02          	cmp    $0x2,%sil
    5050:	74 2e                	je     5080 <fwp_caps74+0x80>
    5052:	40 80 fe 01          	cmp    $0x1,%sil
    5056:	75 b0                	jne    5008 <fwp_caps74+0x8>
    5058:	8b 72 18             	mov    0x18(%rdx),%esi
    505b:	0f b7 c0             	movzwl %ax,%eax
    505e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5061:	48 0f af c6          	imul   %rsi,%rax
    5065:	48 c1 e8 20          	shr    $0x20,%rax
    5069:	48 39 d0             	cmp    %rdx,%rax
    506c:	73 9a                	jae    5008 <fwp_caps74+0x8>
    506e:	48 01 c1             	add    %rax,%rcx
    5071:	80 39 01             	cmpb   $0x1,(%rcx)
    5074:	75 92                	jne    5008 <fwp_caps74+0x8>
    5076:	e9 15 f1 ff ff       	jmp    4190 <fwp_mem_free>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	66 85 c0             	test   %ax,%ax
    5083:	74 ec                	je     5071 <fwp_caps74+0x71>
    5085:	c3                   	ret
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 

0000000000005090 <fwp_data.part.0.constprop.0>:
    5090:	41 56                	push   %r14
    5092:	41 89 fe             	mov    %edi,%r14d
    5095:	41 54                	push   %r12
    5097:	49 89 f4             	mov    %rsi,%r12
    509a:	55                   	push   %rbp
    509b:	53                   	push   %rbx
    509c:	48 83 ec 08          	sub    $0x8,%rsp
    50a0:	8b 05 de 79 01 00    	mov    0x179de(%rip),%eax        # 1ca84 <fwp_heap+0x13a4>
    50a6:	85 c0                	test   %eax,%eax
    50a8:	0f 84 fa 00 00 00    	je     51a8 <fwp_data.part.0.constprop.0+0x118>
    50ae:	0f b6 05 cd 75 01 00 	movzbl 0x175cd(%rip),%eax        # 1c682 <fwp_heap+0xfa2>
    50b5:	48 8d 15 24 66 01 00 	lea    0x16624(%rip),%rdx        # 1b6e0 <fwp_heap>
    50bc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    50c3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50c7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    50cb:	48 8b 18             	mov    (%rax),%rbx
    50ce:	48 85 db             	test   %rbx,%rbx
    50d1:	0f 84 a9 00 00 00    	je     5180 <fwp_data.part.0.constprop.0+0xf0>
    50d7:	48 8b 13             	mov    (%rbx),%rdx
    50da:	48 f7 d2             	not    %rdx
    50dd:	48 89 10             	mov    %rdx,(%rax)
    50e0:	48 83 fd 18          	cmp    $0x18,%rbp
    50e4:	76 1b                	jbe    5101 <fwp_data.part.0.constprop.0+0x71>
    50e6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    50ea:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    50ee:	31 f6                	xor    %esi,%esi
    50f0:	48 c1 e8 03          	shr    $0x3,%rax
    50f4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    50fb:	00 
    50fc:	e8 9f d3 ff ff       	call   24a0 <memset@plt>
    5101:	48 89 e8             	mov    %rbp,%rax
    5104:	48 03 05 f5 79 01 00 	add    0x179f5(%rip),%rax        # 1cb00 <fwp_heap+0x1420>
    510b:	0f 82 a8 00 00 00    	jb     51b9 <fwp_data.part.0.constprop.0+0x129>
    5111:	48 39 05 f0 79 01 00 	cmp    %rax,0x179f0(%rip)        # 1cb08 <fwp_heap+0x1428>
    5118:	48 89 05 e1 79 01 00 	mov    %rax,0x179e1(%rip)        # 1cb00 <fwp_heap+0x1420>
    511f:	73 07                	jae    5128 <fwp_data.part.0.constprop.0+0x98>
    5121:	48 89 05 e0 79 01 00 	mov    %rax,0x179e0(%rip)        # 1cb08 <fwp_heap+0x1428>
    5128:	66 0f ef c0          	pxor   %xmm0,%xmm0
    512c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5131:	f2 0f 58 05 df 79 01 	addsd  0x179df(%rip),%xmm0        # 1cb18 <fwp_heap+0x1438>
    5138:	00 
    5139:	f2 0f 11 05 d7 79 01 	movsd  %xmm0,0x179d7(%rip)        # 1cb18 <fwp_heap+0x1438>
    5140:	00 
    5141:	b8 02 00 00 00       	mov    $0x2,%eax
    5146:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    514b:	66 0f 6e c8          	movd   %eax,%xmm1
    514f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5153:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5157:	49 8b 04 24          	mov    (%r12),%rax
    515b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    515f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5164:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5168:	48 83 c4 08          	add    $0x8,%rsp
    516c:	48 89 d8             	mov    %rbx,%rax
    516f:	5b                   	pop    %rbx
    5170:	5d                   	pop    %rbp
    5171:	41 5c                	pop    %r12
    5173:	41 5e                	pop    %r14
    5175:	c3                   	ret
    5176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    517d:	00 00 00 
    5180:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5184:	48 85 db             	test   %rbx,%rbx
    5187:	74 1f                	je     51a8 <fwp_data.part.0.constprop.0+0x118>
    5189:	48 8b 50 10          	mov    0x10(%rax),%rdx
    518d:	48 29 da             	sub    %rbx,%rdx
    5190:	48 39 ea             	cmp    %rbp,%rdx
    5193:	72 13                	jb     51a8 <fwp_data.part.0.constprop.0+0x118>
    5195:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5199:	48 89 50 08          	mov    %rdx,0x8(%rax)
    519d:	e9 3e ff ff ff       	jmp    50e0 <fwp_data.part.0.constprop.0+0x50>
    51a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51a8:	31 f6                	xor    %esi,%esi
    51aa:	bf 18 00 00 00       	mov    $0x18,%edi
    51af:	e8 5c f3 ff ff       	call   4510 <fwp_heap_alloc_slow>
    51b4:	48 89 c3             	mov    %rax,%rbx
    51b7:	eb 88                	jmp    5141 <fwp_data.part.0.constprop.0+0xb1>
    51b9:	e8 b2 da ff ff       	call   2c70 <fwp_heap_oom>
    51be:	66 90                	xchg   %ax,%ax

00000000000051c0 <f74>:
    51c0:	66 48 0f 6e df       	movq   %rdi,%xmm3
    51c5:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    51ca:	48 83 ec 38          	sub    $0x38,%rsp
    51ce:	31 ff                	xor    %edi,%edi
    51d0:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51d7:	00 00 
    51d9:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    51de:	31 c0                	xor    %eax,%eax
    51e0:	66 0f 28 c3          	movapd %xmm3,%xmm0
    51e4:	f2 0f 10 15 94 32 00 	movsd  0x3294(%rip),%xmm2        # 8480 <msg.3+0x30>
    51eb:	00 
    51ec:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    51f1:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    51f5:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    51f9:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    51fd:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    5201:	f2 0f 10 05 6f 32 00 	movsd  0x326f(%rip),%xmm0        # 8478 <msg.3+0x28>
    5208:	00 
    5209:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    520d:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    5211:	f2 0f 59 0d 6f 32 00 	mulsd  0x326f(%rip),%xmm1        # 8488 <msg.3+0x38>
    5218:	00 
    5219:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    521d:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    5221:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5226:	e8 65 fe ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    522b:	48 8b 15 86 78 01 00 	mov    0x17886(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    5232:	48 89 c6             	mov    %rax,%rsi
    5235:	48 2b 05 54 78 01 00 	sub    0x17854(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    523c:	48 c1 e2 10          	shl    $0x10,%rdx
    5240:	48 39 d0             	cmp    %rdx,%rax
    5243:	73 4f                	jae    5294 <f74+0xd4>
    5245:	48 89 c2             	mov    %rax,%rdx
    5248:	48 c1 ea 10          	shr    $0x10,%rdx
    524c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5250:	48 8b 15 81 78 01 00 	mov    0x17881(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    5257:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    525b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    525f:	48 85 d2             	test   %rdx,%rdx
    5262:	74 30                	je     5294 <f74+0xd4>
    5264:	0f b6 39             	movzbl (%rcx),%edi
    5267:	40 80 ff 02          	cmp    $0x2,%dil
    526b:	74 43                	je     52b0 <f74+0xf0>
    526d:	40 80 ff 01          	cmp    $0x1,%dil
    5271:	75 21                	jne    5294 <f74+0xd4>
    5273:	8b 79 18             	mov    0x18(%rcx),%edi
    5276:	0f b7 c0             	movzwl %ax,%eax
    5279:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    527c:	48 0f af c7          	imul   %rdi,%rax
    5280:	48 c1 e8 20          	shr    $0x20,%rax
    5284:	48 39 c8             	cmp    %rcx,%rax
    5287:	73 0b                	jae    5294 <f74+0xd4>
    5289:	48 01 c2             	add    %rax,%rdx
    528c:	80 3a ff             	cmpb   $0xff,(%rdx)
    528f:	74 2f                	je     52c0 <f74+0x100>
    5291:	c6 02 01             	movb   $0x1,(%rdx)
    5294:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    5299:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    52a0:	00 00 
    52a2:	75 38                	jne    52dc <f74+0x11c>
    52a4:	48 89 f0             	mov    %rsi,%rax
    52a7:	48 83 c4 38          	add    $0x38,%rsp
    52ab:	c3                   	ret
    52ac:	0f 1f 40 00          	nopl   0x0(%rax)
    52b0:	66 85 c0             	test   %ax,%ax
    52b3:	75 df                	jne    5294 <f74+0xd4>
    52b5:	eb d5                	jmp    528c <f74+0xcc>
    52b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    52be:	00 00 
    52c0:	48 89 d7             	mov    %rdx,%rdi
    52c3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    52c8:	48 89 14 24          	mov    %rdx,(%rsp)
    52cc:	e8 7f ec ff ff       	call   3f50 <fwp_rc_forget_slot>
    52d1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    52d6:	48 8b 14 24          	mov    (%rsp),%rdx
    52da:	eb b5                	jmp    5291 <f74+0xd1>
    52dc:	e8 5f d1 ff ff       	call   2440 <__stack_chk_fail@plt>
    52e1:	0f 1f 40 00          	nopl   0x0(%rax)
    52e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52ec:	00 00 00 00 

00000000000052f0 <fwp_owned_entry74>:
    52f0:	f3 0f 1e fa          	endbr64
    52f4:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    52f8:	48 8b 3f             	mov    (%rdi),%rdi
    52fb:	e9 c0 fe ff ff       	jmp    51c0 <f74>

0000000000005300 <e74>:
    5300:	f3 0f 1e fa          	endbr64
    5304:	48 83 ec 18          	sub    $0x18,%rsp
    5308:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    530c:	48 8b 3f             	mov    (%rdi),%rdi
    530f:	e8 ac fe ff ff       	call   51c0 <f74>
    5314:	48 89 c7             	mov    %rax,%rdi
    5317:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    531c:	e8 6f f3 ff ff       	call   4690 <fwp_rc_share>
    5321:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5326:	48 83 c4 18          	add    $0x18,%rsp
    532a:	c3                   	ret
    532b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005330 <fwp_map_finish_protected.isra.0>:
    5330:	41 55                	push   %r13
    5332:	41 54                	push   %r12
    5334:	55                   	push   %rbp
    5335:	53                   	push   %rbx
    5336:	48 83 ec 38          	sub    $0x38,%rsp
    533a:	48 8b 47 08          	mov    0x8(%rdi),%rax
    533e:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    5342:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5349:	00 00 
    534b:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    5350:	49 89 fc             	mov    %rdi,%r12
    5353:	48 85 c0             	test   %rax,%rax
    5356:	0f 84 d4 00 00 00    	je     5430 <fwp_map_finish_protected.isra.0+0x100>
    535c:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
    5361:	4c 8d 2d 78 63 01 00 	lea    0x16378(%rip),%r13        # 1b6e0 <fwp_heap>
    5368:	eb 4a                	jmp    53b4 <fwp_map_finish_protected.isra.0+0x84>
    536a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5370:	40 80 fe 01          	cmp    $0x1,%sil
    5374:	75 25                	jne    539b <fwp_map_finish_protected.isra.0+0x6b>
    5376:	8b 71 18             	mov    0x18(%rcx),%esi
    5379:	0f b7 c0             	movzwl %ax,%eax
    537c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    537f:	48 0f af c6          	imul   %rsi,%rax
    5383:	48 c1 e8 20          	shr    $0x20,%rax
    5387:	48 39 c8             	cmp    %rcx,%rax
    538a:	73 0f                	jae    539b <fwp_map_finish_protected.isra.0+0x6b>
    538c:	48 01 c2             	add    %rax,%rdx
    538f:	80 3a ff             	cmpb   $0xff,(%rdx)
    5392:	0f 84 c8 00 00 00    	je     5460 <fwp_map_finish_protected.isra.0+0x130>
    5398:	c6 02 01             	movb   $0x1,(%rdx)
    539b:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    53a0:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
    53a5:	48 83 e8 01          	sub    $0x1,%rax
    53a9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    53ae:	0f 84 7c 00 00 00    	je     5430 <fwp_map_finish_protected.isra.0+0x100>
    53b4:	49 8b 14 24          	mov    (%r12),%rdx
    53b8:	66 48 0f 6e cb       	movq   %rbx,%xmm1
    53bd:	48 89 ee             	mov    %rbp,%rsi
    53c0:	bf 01 00 00 00       	mov    $0x1,%edi
    53c5:	f3 0f 7e 44 c2 f8    	movq   -0x8(%rdx,%rax,8),%xmm0
    53cb:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    53cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    53d4:	e8 b7 fc ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    53d9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    53e0:	48 89 c3             	mov    %rax,%rbx
    53e3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    53ea:	48 c1 e2 10          	shl    $0x10,%rdx
    53ee:	48 39 d0             	cmp    %rdx,%rax
    53f1:	73 a8                	jae    539b <fwp_map_finish_protected.isra.0+0x6b>
    53f3:	48 89 c2             	mov    %rax,%rdx
    53f6:	48 c1 ea 10          	shr    $0x10,%rdx
    53fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    53fe:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    5405:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5409:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    540d:	48 85 d2             	test   %rdx,%rdx
    5410:	74 89                	je     539b <fwp_map_finish_protected.isra.0+0x6b>
    5412:	0f b6 31             	movzbl (%rcx),%esi
    5415:	40 80 fe 02          	cmp    $0x2,%sil
    5419:	0f 85 51 ff ff ff    	jne    5370 <fwp_map_finish_protected.isra.0+0x40>
    541f:	66 85 c0             	test   %ax,%ax
    5422:	0f 85 73 ff ff ff    	jne    539b <fwp_map_finish_protected.isra.0+0x6b>
    5428:	e9 62 ff ff ff       	jmp    538f <fwp_map_finish_protected.isra.0+0x5f>
    542d:	0f 1f 00             	nopl   (%rax)
    5430:	49 8b 3c 24          	mov    (%r12),%rdi
    5434:	e8 57 ed ff ff       	call   4190 <fwp_mem_free>
    5439:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    543e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5445:	00 00 
    5447:	75 2e                	jne    5477 <fwp_map_finish_protected.isra.0+0x147>
    5449:	48 83 c4 38          	add    $0x38,%rsp
    544d:	48 89 d8             	mov    %rbx,%rax
    5450:	5b                   	pop    %rbx
    5451:	5d                   	pop    %rbp
    5452:	41 5c                	pop    %r12
    5454:	41 5d                	pop    %r13
    5456:	c3                   	ret
    5457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    545e:	00 00 
    5460:	48 89 d7             	mov    %rdx,%rdi
    5463:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5468:	e8 e3 ea ff ff       	call   3f50 <fwp_rc_forget_slot>
    546d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5472:	e9 21 ff ff ff       	jmp    5398 <fwp_map_finish_protected.isra.0+0x68>
    5477:	e8 c4 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    547c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005480 <fwp_drop4>:
    5480:	f3 0f 1e fa          	endbr64
    5484:	48 8b 15 2d 76 01 00 	mov    0x1762d(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    548b:	48 89 f8             	mov    %rdi,%rax
    548e:	48 2b 05 fb 75 01 00 	sub    0x175fb(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    5495:	48 c1 e2 10          	shl    $0x10,%rdx
    5499:	48 39 d0             	cmp    %rdx,%rax
    549c:	73 67                	jae    5505 <fwp_drop4+0x85>
    549e:	48 89 c2             	mov    %rax,%rdx
    54a1:	48 c1 ea 10          	shr    $0x10,%rdx
    54a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    54a9:	48 8b 15 28 76 01 00 	mov    0x17628(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    54b0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    54b4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    54b8:	48 85 d2             	test   %rdx,%rdx
    54bb:	74 48                	je     5505 <fwp_drop4+0x85>
    54bd:	0f b6 31             	movzbl (%rcx),%esi
    54c0:	40 80 fe 02          	cmp    $0x2,%sil
    54c4:	74 3a                	je     5500 <fwp_drop4+0x80>
    54c6:	40 80 fe 01          	cmp    $0x1,%sil
    54ca:	75 39                	jne    5505 <fwp_drop4+0x85>
    54cc:	8b 71 18             	mov    0x18(%rcx),%esi
    54cf:	0f b7 c0             	movzwl %ax,%eax
    54d2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    54d5:	48 0f af c6          	imul   %rsi,%rax
    54d9:	48 c1 e8 20          	shr    $0x20,%rax
    54dd:	48 39 c8             	cmp    %rcx,%rax
    54e0:	73 23                	jae    5505 <fwp_drop4+0x85>
    54e2:	48 01 c2             	add    %rax,%rdx
    54e5:	0f b6 02             	movzbl (%rdx),%eax
    54e8:	84 c0                	test   %al,%al
    54ea:	74 19                	je     5505 <fwp_drop4+0x85>
    54ec:	3c 01                	cmp    $0x1,%al
    54ee:	74 20                	je     5510 <fwp_drop4+0x90>
    54f0:	3c ff                	cmp    $0xff,%al
    54f2:	74 24                	je     5518 <fwp_drop4+0x98>
    54f4:	83 e8 01             	sub    $0x1,%eax
    54f7:	88 02                	mov    %al,(%rdx)
    54f9:	c3                   	ret
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5500:	66 85 c0             	test   %ax,%ax
    5503:	74 e0                	je     54e5 <fwp_drop4+0x65>
    5505:	c3                   	ret
    5506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    550d:	00 00 00 
    5510:	e9 7b ec ff ff       	jmp    4190 <fwp_mem_free>
    5515:	0f 1f 00             	nopl   (%rax)
    5518:	48 89 d0             	mov    %rdx,%rax
    551b:	48 8d 35 be 61 01 00 	lea    0x161be(%rip),%rsi        # 1b6e0 <fwp_heap>
    5522:	48 83 ec 18          	sub    $0x18,%rsp
    5526:	48 c1 e8 11          	shr    $0x11,%rax
    552a:	48 31 d0             	xor    %rdx,%rax
    552d:	48 89 c1             	mov    %rax,%rcx
    5530:	48 c1 e9 09          	shr    $0x9,%rcx
    5534:	48 31 c8             	xor    %rcx,%rax
    5537:	0f b6 c8             	movzbl %al,%ecx
    553a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5541:	00 
    5542:	48 85 c0             	test   %rax,%rax
    5545:	75 22                	jne    5569 <fwp_drop4+0xe9>
    5547:	eb 59                	jmp    55a2 <fwp_drop4+0x122>
    5549:	90                   	nop
    554a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5551:	00 00 00 00 
    5555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    555c:	00 00 00 00 
    5560:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5564:	48 85 c0             	test   %rax,%rax
    5567:	74 39                	je     55a2 <fwp_drop4+0x122>
    5569:	48 89 c1             	mov    %rax,%rcx
    556c:	48 39 10             	cmp    %rdx,(%rax)
    556f:	75 ef                	jne    5560 <fwp_drop4+0xe0>
    5571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5575:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5579:	48 89 48 08          	mov    %rcx,0x8(%rax)
    557d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5584:	74 05                	je     558b <fwp_drop4+0x10b>
    5586:	48 83 c4 18          	add    $0x18,%rsp
    558a:	c3                   	ret
    558b:	48 89 d7             	mov    %rdx,%rdi
    558e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5593:	e8 b8 e9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5598:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    559d:	c6 02 fe             	movb   $0xfe,(%rdx)
    55a0:	eb e4                	jmp    5586 <fwp_drop4+0x106>
    55a2:	48 8d 3d 07 2d 00 00 	lea    0x2d07(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    55a9:	e8 72 db ff ff       	call   3120 <fwp_trap>
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_owned_entry50>:
    55b0:	f3 0f 1e fa          	endbr64
    55b4:	53                   	push   %rbx
    55b5:	48 8b 3f             	mov    (%rdi),%rdi
    55b8:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    55bc:	e8 bf fe ff ff       	call   5480 <fwp_drop4>
    55c1:	48 89 d8             	mov    %rbx,%rax
    55c4:	5b                   	pop    %rbx
    55c5:	c3                   	ret
    55c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55cd:	00 00 00 

00000000000055d0 <fwp_owned_entry47>:
    55d0:	f3 0f 1e fa          	endbr64
    55d4:	53                   	push   %rbx
    55d5:	48 8b 3f             	mov    (%rdi),%rdi
    55d8:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    55dc:	e8 9f fe ff ff       	call   5480 <fwp_drop4>
    55e1:	48 89 d8             	mov    %rbx,%rax
    55e4:	5b                   	pop    %rbx
    55e5:	c3                   	ret
    55e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ed:	00 00 00 

00000000000055f0 <fwp_arg_drop47>:
    55f0:	f3 0f 1e fa          	endbr64
    55f4:	85 f6                	test   %esi,%esi
    55f6:	75 04                	jne    55fc <fwp_arg_drop47+0xc>
    55f8:	85 d2                	test   %edx,%edx
    55fa:	75 04                	jne    5600 <fwp_arg_drop47+0x10>
    55fc:	c3                   	ret
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	48 8b 3f             	mov    (%rdi),%rdi
    5603:	e9 78 fe ff ff       	jmp    5480 <fwp_drop4>
    5608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    560f:	00 

0000000000005610 <e50>:
    5610:	f3 0f 1e fa          	endbr64
    5614:	55                   	push   %rbp
    5615:	53                   	push   %rbx
    5616:	48 83 ec 08          	sub    $0x8,%rsp
    561a:	48 8b 1f             	mov    (%rdi),%rbx
    561d:	48 89 df             	mov    %rbx,%rdi
    5620:	e8 6b f0 ff ff       	call   4690 <fwp_rc_share>
    5625:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    5629:	48 89 df             	mov    %rbx,%rdi
    562c:	e8 4f fe ff ff       	call   5480 <fwp_drop4>
    5631:	48 89 ef             	mov    %rbp,%rdi
    5634:	e8 57 f0 ff ff       	call   4690 <fwp_rc_share>
    5639:	48 83 c4 08          	add    $0x8,%rsp
    563d:	48 89 e8             	mov    %rbp,%rax
    5640:	5b                   	pop    %rbx
    5641:	5d                   	pop    %rbp
    5642:	c3                   	ret
    5643:	66 90                	xchg   %ax,%ax
    5645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    564c:	00 00 00 00 

0000000000005650 <e47>:
    5650:	f3 0f 1e fa          	endbr64
    5654:	55                   	push   %rbp
    5655:	53                   	push   %rbx
    5656:	48 83 ec 08          	sub    $0x8,%rsp
    565a:	48 8b 1f             	mov    (%rdi),%rbx
    565d:	48 89 df             	mov    %rbx,%rdi
    5660:	e8 2b f0 ff ff       	call   4690 <fwp_rc_share>
    5665:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
    5669:	48 89 df             	mov    %rbx,%rdi
    566c:	e8 0f fe ff ff       	call   5480 <fwp_drop4>
    5671:	48 89 ef             	mov    %rbp,%rdi
    5674:	e8 17 f0 ff ff       	call   4690 <fwp_rc_share>
    5679:	48 83 c4 08          	add    $0x8,%rsp
    567d:	48 89 e8             	mov    %rbp,%rax
    5680:	5b                   	pop    %rbx
    5681:	5d                   	pop    %rbp
    5682:	c3                   	ret
    5683:	66 90                	xchg   %ax,%ax
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_arg_drop50>:
    5690:	f3 0f 1e fa          	endbr64
    5694:	85 f6                	test   %esi,%esi
    5696:	75 04                	jne    569c <fwp_arg_drop50+0xc>
    5698:	85 d2                	test   %edx,%edx
    569a:	75 04                	jne    56a0 <fwp_arg_drop50+0x10>
    569c:	c3                   	ret
    569d:	0f 1f 00             	nopl   (%rax)
    56a0:	48 8b 3f             	mov    (%rdi),%rdi
    56a3:	e9 d8 fd ff ff       	jmp    5480 <fwp_drop4>
    56a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56af:	00 

00000000000056b0 <fwp_args47>:
    56b0:	f3 0f 1e fa          	endbr64
    56b4:	85 d2                	test   %edx,%edx
    56b6:	74 04                	je     56bc <fwp_args47+0xc>
    56b8:	85 f6                	test   %esi,%esi
    56ba:	74 04                	je     56c0 <fwp_args47+0x10>
    56bc:	c3                   	ret
    56bd:	0f 1f 00             	nopl   (%rax)
    56c0:	48 8b 15 f1 73 01 00 	mov    0x173f1(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    56c7:	48 8b 07             	mov    (%rdi),%rax
    56ca:	48 2b 05 bf 73 01 00 	sub    0x173bf(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    56d1:	48 c1 e2 10          	shl    $0x10,%rdx
    56d5:	48 39 d0             	cmp    %rdx,%rax
    56d8:	73 e2                	jae    56bc <fwp_args47+0xc>
    56da:	48 89 c2             	mov    %rax,%rdx
    56dd:	48 c1 ea 10          	shr    $0x10,%rdx
    56e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    56e5:	48 8b 15 ec 73 01 00 	mov    0x173ec(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    56ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    56f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    56f4:	48 85 ff             	test   %rdi,%rdi
    56f7:	74 c3                	je     56bc <fwp_args47+0xc>
    56f9:	0f b6 0a             	movzbl (%rdx),%ecx
    56fc:	80 f9 02             	cmp    $0x2,%cl
    56ff:	74 2f                	je     5730 <fwp_args47+0x80>
    5701:	80 f9 01             	cmp    $0x1,%cl
    5704:	75 b6                	jne    56bc <fwp_args47+0xc>
    5706:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5709:	0f b7 c0             	movzwl %ax,%eax
    570c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    570f:	48 0f af c1          	imul   %rcx,%rax
    5713:	48 c1 e8 20          	shr    $0x20,%rax
    5717:	48 39 d0             	cmp    %rdx,%rax
    571a:	73 a0                	jae    56bc <fwp_args47+0xc>
    571c:	48 01 c7             	add    %rax,%rdi
    571f:	0f b6 07             	movzbl (%rdi),%eax
    5722:	84 c0                	test   %al,%al
    5724:	74 96                	je     56bc <fwp_args47+0xc>
    5726:	3c fd                	cmp    $0xfd,%al
    5728:	77 0c                	ja     5736 <fwp_args47+0x86>
    572a:	83 c0 01             	add    $0x1,%eax
    572d:	88 07                	mov    %al,(%rdi)
    572f:	c3                   	ret
    5730:	66 85 c0             	test   %ax,%ax
    5733:	74 ea                	je     571f <fwp_args47+0x6f>
    5735:	c3                   	ret
    5736:	e9 f5 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    573b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005740 <fwp_args50>:
    5740:	f3 0f 1e fa          	endbr64
    5744:	85 d2                	test   %edx,%edx
    5746:	74 04                	je     574c <fwp_args50+0xc>
    5748:	85 f6                	test   %esi,%esi
    574a:	74 04                	je     5750 <fwp_args50+0x10>
    574c:	c3                   	ret
    574d:	0f 1f 00             	nopl   (%rax)
    5750:	48 8b 15 61 73 01 00 	mov    0x17361(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    5757:	48 8b 07             	mov    (%rdi),%rax
    575a:	48 2b 05 2f 73 01 00 	sub    0x1732f(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    5761:	48 c1 e2 10          	shl    $0x10,%rdx
    5765:	48 39 d0             	cmp    %rdx,%rax
    5768:	73 e2                	jae    574c <fwp_args50+0xc>
    576a:	48 89 c2             	mov    %rax,%rdx
    576d:	48 c1 ea 10          	shr    $0x10,%rdx
    5771:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5775:	48 8b 15 5c 73 01 00 	mov    0x1735c(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    577c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5780:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5784:	48 85 ff             	test   %rdi,%rdi
    5787:	74 c3                	je     574c <fwp_args50+0xc>
    5789:	0f b6 0a             	movzbl (%rdx),%ecx
    578c:	80 f9 02             	cmp    $0x2,%cl
    578f:	74 2f                	je     57c0 <fwp_args50+0x80>
    5791:	80 f9 01             	cmp    $0x1,%cl
    5794:	75 b6                	jne    574c <fwp_args50+0xc>
    5796:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5799:	0f b7 c0             	movzwl %ax,%eax
    579c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    579f:	48 0f af c1          	imul   %rcx,%rax
    57a3:	48 c1 e8 20          	shr    $0x20,%rax
    57a7:	48 39 d0             	cmp    %rdx,%rax
    57aa:	73 a0                	jae    574c <fwp_args50+0xc>
    57ac:	48 01 c7             	add    %rax,%rdi
    57af:	0f b6 07             	movzbl (%rdi),%eax
    57b2:	84 c0                	test   %al,%al
    57b4:	74 96                	je     574c <fwp_args50+0xc>
    57b6:	3c fd                	cmp    $0xfd,%al
    57b8:	77 0c                	ja     57c6 <fwp_args50+0x86>
    57ba:	83 c0 01             	add    $0x1,%eax
    57bd:	88 07                	mov    %al,(%rdi)
    57bf:	c3                   	ret
    57c0:	66 85 c0             	test   %ax,%ax
    57c3:	74 ea                	je     57af <fwp_args50+0x6f>
    57c5:	c3                   	ret
    57c6:	e9 65 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    57cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000057d0 <fwp_caps47>:
    57d0:	f3 0f 1e fa          	endbr64
    57d4:	48 83 ec 18          	sub    $0x18,%rsp
    57d8:	8b 57 04             	mov    0x4(%rdi),%edx
    57db:	48 89 f8             	mov    %rdi,%rax
    57de:	85 d2                	test   %edx,%edx
    57e0:	0f 84 9a 00 00 00    	je     5880 <fwp_caps47+0xb0>
    57e6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    57ea:	85 f6                	test   %esi,%esi
    57ec:	0f 85 9e 00 00 00    	jne    5890 <fwp_caps47+0xc0>
    57f2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    57f7:	e8 84 fc ff ff       	call   5480 <fwp_drop4>
    57fc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5801:	48 8b 0d b0 72 01 00 	mov    0x172b0(%rip),%rcx        # 1cab8 <fwp_heap+0x13d8>
    5808:	48 89 c2             	mov    %rax,%rdx
    580b:	48 2b 15 7e 72 01 00 	sub    0x1727e(%rip),%rdx        # 1ca90 <fwp_heap+0x13b0>
    5812:	48 c1 e1 10          	shl    $0x10,%rcx
    5816:	48 39 ca             	cmp    %rcx,%rdx
    5819:	73 6d                	jae    5888 <fwp_caps47+0xb8>
    581b:	48 89 d1             	mov    %rdx,%rcx
    581e:	48 c1 e9 10          	shr    $0x10,%rcx
    5822:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5826:	48 8b 0d ab 72 01 00 	mov    0x172ab(%rip),%rcx        # 1cad8 <fwp_heap+0x13f8>
    582d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5831:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5835:	48 85 f6             	test   %rsi,%rsi
    5838:	74 4e                	je     5888 <fwp_caps47+0xb8>
    583a:	0f b6 39             	movzbl (%rcx),%edi
    583d:	40 80 ff 02          	cmp    $0x2,%dil
    5841:	0f 84 b9 00 00 00    	je     5900 <fwp_caps47+0x130>
    5847:	40 80 ff 01          	cmp    $0x1,%dil
    584b:	75 3b                	jne    5888 <fwp_caps47+0xb8>
    584d:	8b 79 18             	mov    0x18(%rcx),%edi
    5850:	0f b7 d2             	movzwl %dx,%edx
    5853:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5856:	48 0f af d7          	imul   %rdi,%rdx
    585a:	48 c1 ea 20          	shr    $0x20,%rdx
    585e:	48 39 ca             	cmp    %rcx,%rdx
    5861:	73 25                	jae    5888 <fwp_caps47+0xb8>
    5863:	48 01 d6             	add    %rdx,%rsi
    5866:	80 3e 01             	cmpb   $0x1,(%rsi)
    5869:	75 1d                	jne    5888 <fwp_caps47+0xb8>
    586b:	48 89 c7             	mov    %rax,%rdi
    586e:	48 83 c4 18          	add    $0x18,%rsp
    5872:	e9 19 e9 ff ff       	jmp    4190 <fwp_mem_free>
    5877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    587e:	00 00 
    5880:	85 f6                	test   %esi,%esi
    5882:	0f 84 79 ff ff ff    	je     5801 <fwp_caps47+0x31>
    5888:	48 83 c4 18          	add    $0x18,%rsp
    588c:	c3                   	ret
    588d:	0f 1f 00             	nopl   (%rax)
    5890:	48 8b 05 21 72 01 00 	mov    0x17221(%rip),%rax        # 1cab8 <fwp_heap+0x13d8>
    5897:	48 2b 3d f2 71 01 00 	sub    0x171f2(%rip),%rdi        # 1ca90 <fwp_heap+0x13b0>
    589e:	48 c1 e0 10          	shl    $0x10,%rax
    58a2:	48 39 c7             	cmp    %rax,%rdi
    58a5:	73 e1                	jae    5888 <fwp_caps47+0xb8>
    58a7:	48 89 f8             	mov    %rdi,%rax
    58aa:	48 c1 e8 10          	shr    $0x10,%rax
    58ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    58b2:	48 8b 05 1f 72 01 00 	mov    0x1721f(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    58b9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    58bd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    58c1:	48 85 c0             	test   %rax,%rax
    58c4:	74 c2                	je     5888 <fwp_caps47+0xb8>
    58c6:	0f b6 0a             	movzbl (%rdx),%ecx
    58c9:	80 f9 02             	cmp    $0x2,%cl
    58cc:	74 42                	je     5910 <fwp_caps47+0x140>
    58ce:	80 f9 01             	cmp    $0x1,%cl
    58d1:	75 b5                	jne    5888 <fwp_caps47+0xb8>
    58d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    58d6:	0f b7 ff             	movzwl %di,%edi
    58d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    58dc:	48 0f af f9          	imul   %rcx,%rdi
    58e0:	48 c1 ef 20          	shr    $0x20,%rdi
    58e4:	48 39 d7             	cmp    %rdx,%rdi
    58e7:	73 9f                	jae    5888 <fwp_caps47+0xb8>
    58e9:	48 01 f8             	add    %rdi,%rax
    58ec:	0f b6 10             	movzbl (%rax),%edx
    58ef:	84 d2                	test   %dl,%dl
    58f1:	74 95                	je     5888 <fwp_caps47+0xb8>
    58f3:	80 fa fd             	cmp    $0xfd,%dl
    58f6:	77 23                	ja     591b <fwp_caps47+0x14b>
    58f8:	83 c2 01             	add    $0x1,%edx
    58fb:	88 10                	mov    %dl,(%rax)
    58fd:	eb 89                	jmp    5888 <fwp_caps47+0xb8>
    58ff:	90                   	nop
    5900:	66 85 d2             	test   %dx,%dx
    5903:	0f 85 7f ff ff ff    	jne    5888 <fwp_caps47+0xb8>
    5909:	e9 58 ff ff ff       	jmp    5866 <fwp_caps47+0x96>
    590e:	66 90                	xchg   %ax,%ax
    5910:	66 85 ff             	test   %di,%di
    5913:	0f 85 6f ff ff ff    	jne    5888 <fwp_caps47+0xb8>
    5919:	eb d1                	jmp    58ec <fwp_caps47+0x11c>
    591b:	48 89 c7             	mov    %rax,%rdi
    591e:	48 83 c4 18          	add    $0x18,%rsp
    5922:	e9 09 e5 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    592e:	00 00 

0000000000005930 <fwp_caps50>:
    5930:	f3 0f 1e fa          	endbr64
    5934:	48 83 ec 18          	sub    $0x18,%rsp
    5938:	8b 57 04             	mov    0x4(%rdi),%edx
    593b:	48 89 f8             	mov    %rdi,%rax
    593e:	85 d2                	test   %edx,%edx
    5940:	0f 84 9a 00 00 00    	je     59e0 <fwp_caps50+0xb0>
    5946:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    594a:	85 f6                	test   %esi,%esi
    594c:	0f 85 9e 00 00 00    	jne    59f0 <fwp_caps50+0xc0>
    5952:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5957:	e8 24 fb ff ff       	call   5480 <fwp_drop4>
    595c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5961:	48 8b 0d 50 71 01 00 	mov    0x17150(%rip),%rcx        # 1cab8 <fwp_heap+0x13d8>
    5968:	48 89 c2             	mov    %rax,%rdx
    596b:	48 2b 15 1e 71 01 00 	sub    0x1711e(%rip),%rdx        # 1ca90 <fwp_heap+0x13b0>
    5972:	48 c1 e1 10          	shl    $0x10,%rcx
    5976:	48 39 ca             	cmp    %rcx,%rdx
    5979:	73 6d                	jae    59e8 <fwp_caps50+0xb8>
    597b:	48 89 d1             	mov    %rdx,%rcx
    597e:	48 c1 e9 10          	shr    $0x10,%rcx
    5982:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5986:	48 8b 0d 4b 71 01 00 	mov    0x1714b(%rip),%rcx        # 1cad8 <fwp_heap+0x13f8>
    598d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5991:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5995:	48 85 f6             	test   %rsi,%rsi
    5998:	74 4e                	je     59e8 <fwp_caps50+0xb8>
    599a:	0f b6 39             	movzbl (%rcx),%edi
    599d:	40 80 ff 02          	cmp    $0x2,%dil
    59a1:	0f 84 b9 00 00 00    	je     5a60 <fwp_caps50+0x130>
    59a7:	40 80 ff 01          	cmp    $0x1,%dil
    59ab:	75 3b                	jne    59e8 <fwp_caps50+0xb8>
    59ad:	8b 79 18             	mov    0x18(%rcx),%edi
    59b0:	0f b7 d2             	movzwl %dx,%edx
    59b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    59b6:	48 0f af d7          	imul   %rdi,%rdx
    59ba:	48 c1 ea 20          	shr    $0x20,%rdx
    59be:	48 39 ca             	cmp    %rcx,%rdx
    59c1:	73 25                	jae    59e8 <fwp_caps50+0xb8>
    59c3:	48 01 d6             	add    %rdx,%rsi
    59c6:	80 3e 01             	cmpb   $0x1,(%rsi)
    59c9:	75 1d                	jne    59e8 <fwp_caps50+0xb8>
    59cb:	48 89 c7             	mov    %rax,%rdi
    59ce:	48 83 c4 18          	add    $0x18,%rsp
    59d2:	e9 b9 e7 ff ff       	jmp    4190 <fwp_mem_free>
    59d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59de:	00 00 
    59e0:	85 f6                	test   %esi,%esi
    59e2:	0f 84 79 ff ff ff    	je     5961 <fwp_caps50+0x31>
    59e8:	48 83 c4 18          	add    $0x18,%rsp
    59ec:	c3                   	ret
    59ed:	0f 1f 00             	nopl   (%rax)
    59f0:	48 8b 05 c1 70 01 00 	mov    0x170c1(%rip),%rax        # 1cab8 <fwp_heap+0x13d8>
    59f7:	48 2b 3d 92 70 01 00 	sub    0x17092(%rip),%rdi        # 1ca90 <fwp_heap+0x13b0>
    59fe:	48 c1 e0 10          	shl    $0x10,%rax
    5a02:	48 39 c7             	cmp    %rax,%rdi
    5a05:	73 e1                	jae    59e8 <fwp_caps50+0xb8>
    5a07:	48 89 f8             	mov    %rdi,%rax
    5a0a:	48 c1 e8 10          	shr    $0x10,%rax
    5a0e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5a12:	48 8b 05 bf 70 01 00 	mov    0x170bf(%rip),%rax        # 1cad8 <fwp_heap+0x13f8>
    5a19:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    5a1d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    5a21:	48 85 c0             	test   %rax,%rax
    5a24:	74 c2                	je     59e8 <fwp_caps50+0xb8>
    5a26:	0f b6 0a             	movzbl (%rdx),%ecx
    5a29:	80 f9 02             	cmp    $0x2,%cl
    5a2c:	74 42                	je     5a70 <fwp_caps50+0x140>
    5a2e:	80 f9 01             	cmp    $0x1,%cl
    5a31:	75 b5                	jne    59e8 <fwp_caps50+0xb8>
    5a33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5a36:	0f b7 ff             	movzwl %di,%edi
    5a39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5a3c:	48 0f af f9          	imul   %rcx,%rdi
    5a40:	48 c1 ef 20          	shr    $0x20,%rdi
    5a44:	48 39 d7             	cmp    %rdx,%rdi
    5a47:	73 9f                	jae    59e8 <fwp_caps50+0xb8>
    5a49:	48 01 f8             	add    %rdi,%rax
    5a4c:	0f b6 10             	movzbl (%rax),%edx
    5a4f:	84 d2                	test   %dl,%dl
    5a51:	74 95                	je     59e8 <fwp_caps50+0xb8>
    5a53:	80 fa fd             	cmp    $0xfd,%dl
    5a56:	77 23                	ja     5a7b <fwp_caps50+0x14b>
    5a58:	83 c2 01             	add    $0x1,%edx
    5a5b:	88 10                	mov    %dl,(%rax)
    5a5d:	eb 89                	jmp    59e8 <fwp_caps50+0xb8>
    5a5f:	90                   	nop
    5a60:	66 85 d2             	test   %dx,%dx
    5a63:	0f 85 7f ff ff ff    	jne    59e8 <fwp_caps50+0xb8>
    5a69:	e9 58 ff ff ff       	jmp    59c6 <fwp_caps50+0x96>
    5a6e:	66 90                	xchg   %ax,%ax
    5a70:	66 85 ff             	test   %di,%di
    5a73:	0f 85 6f ff ff ff    	jne    59e8 <fwp_caps50+0xb8>
    5a79:	eb d1                	jmp    5a4c <fwp_caps50+0x11c>
    5a7b:	48 89 c7             	mov    %rax,%rdi
    5a7e:	48 83 c4 18          	add    $0x18,%rsp
    5a82:	e9 a9 e3 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a8e:	00 00 

0000000000005a90 <fwp_drop0>:
    5a90:	f3 0f 1e fa          	endbr64
    5a94:	48 8b 15 1d 70 01 00 	mov    0x1701d(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    5a9b:	48 89 f8             	mov    %rdi,%rax
    5a9e:	48 2b 05 eb 6f 01 00 	sub    0x16feb(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    5aa5:	48 c1 e2 10          	shl    $0x10,%rdx
    5aa9:	48 39 d0             	cmp    %rdx,%rax
    5aac:	0f 83 36 01 00 00    	jae    5be8 <fwp_drop0+0x158>
    5ab2:	48 83 ec 18          	sub    $0x18,%rsp
    5ab6:	48 8d 35 23 5c 01 00 	lea    0x15c23(%rip),%rsi        # 1b6e0 <fwp_heap>
    5abd:	48 89 c2             	mov    %rax,%rdx
    5ac0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    5ac7:	48 c1 ea 10          	shr    $0x10,%rdx
    5acb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    5acf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    5ad3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5ad7:	48 85 d2             	test   %rdx,%rdx
    5ada:	74 42                	je     5b1e <fwp_drop0+0x8e>
    5adc:	44 0f b6 01          	movzbl (%rcx),%r8d
    5ae0:	41 80 f8 02          	cmp    $0x2,%r8b
    5ae4:	74 42                	je     5b28 <fwp_drop0+0x98>
    5ae6:	41 80 f8 01          	cmp    $0x1,%r8b
    5aea:	75 32                	jne    5b1e <fwp_drop0+0x8e>
    5aec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    5af0:	0f b7 c0             	movzwl %ax,%eax
    5af3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5af6:	49 0f af c0          	imul   %r8,%rax
    5afa:	48 c1 e8 20          	shr    $0x20,%rax
    5afe:	48 39 c8             	cmp    %rcx,%rax
    5b01:	73 1b                	jae    5b1e <fwp_drop0+0x8e>
    5b03:	48 01 c2             	add    %rax,%rdx
    5b06:	0f b6 02             	movzbl (%rdx),%eax
    5b09:	84 c0                	test   %al,%al
    5b0b:	74 11                	je     5b1e <fwp_drop0+0x8e>
    5b0d:	3c 01                	cmp    $0x1,%al
    5b0f:	74 27                	je     5b38 <fwp_drop0+0xa8>
    5b11:	3c ff                	cmp    $0xff,%al
    5b13:	0f 84 e7 00 00 00    	je     5c00 <fwp_drop0+0x170>
    5b19:	83 e8 01             	sub    $0x1,%eax
    5b1c:	88 02                	mov    %al,(%rdx)
    5b1e:	48 83 c4 18          	add    $0x18,%rsp
    5b22:	c3                   	ret
    5b23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b28:	66 85 c0             	test   %ax,%ax
    5b2b:	74 d9                	je     5b06 <fwp_drop0+0x76>
    5b2d:	48 83 c4 18          	add    $0x18,%rsp
    5b31:	c3                   	ret
    5b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5b3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5b46:	48 89 f8             	mov    %rdi,%rax
    5b49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    5b4d:	48 29 c8             	sub    %rcx,%rax
    5b50:	48 c1 e2 10          	shl    $0x10,%rdx
    5b54:	48 39 d0             	cmp    %rdx,%rax
    5b57:	73 71                	jae    5bca <fwp_drop0+0x13a>
    5b59:	49 89 c2             	mov    %rax,%r10
    5b5c:	49 c1 ea 10          	shr    $0x10,%r10
    5b60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    5b64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    5b68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    5b6c:	4d 85 d2             	test   %r10,%r10
    5b6f:	74 59                	je     5bca <fwp_drop0+0x13a>
    5b71:	45 0f b6 19          	movzbl (%r9),%r11d
    5b75:	41 80 fb 02          	cmp    $0x2,%r11b
    5b79:	74 75                	je     5bf0 <fwp_drop0+0x160>
    5b7b:	41 80 fb 01          	cmp    $0x1,%r11b
    5b7f:	75 49                	jne    5bca <fwp_drop0+0x13a>
    5b81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    5b85:	0f b7 c0             	movzwl %ax,%eax
    5b88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    5b8c:	49 0f af c3          	imul   %r11,%rax
    5b90:	48 c1 e8 20          	shr    $0x20,%rax
    5b94:	4c 39 c8             	cmp    %r9,%rax
    5b97:	73 31                	jae    5bca <fwp_drop0+0x13a>
    5b99:	49 01 c2             	add    %rax,%r10
    5b9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5ba0:	75 28                	jne    5bca <fwp_drop0+0x13a>
    5ba2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ba7:	e8 e4 e5 ff ff       	call   4190 <fwp_mem_free>
    5bac:	48 8d 35 2d 5b 01 00 	lea    0x15b2d(%rip),%rsi        # 1b6e0 <fwp_heap>
    5bb3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5bb8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5bbf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5bc6:	48 c1 e2 10          	shl    $0x10,%rdx
    5bca:	4c 89 c0             	mov    %r8,%rax
    5bcd:	48 29 c8             	sub    %rcx,%rax
    5bd0:	48 39 d0             	cmp    %rdx,%rax
    5bd3:	0f 83 45 ff ff ff    	jae    5b1e <fwp_drop0+0x8e>
    5bd9:	4c 89 c7             	mov    %r8,%rdi
    5bdc:	e9 dc fe ff ff       	jmp    5abd <fwp_drop0+0x2d>
    5be1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5be8:	c3                   	ret
    5be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5bf0:	66 85 c0             	test   %ax,%ax
    5bf3:	75 d5                	jne    5bca <fwp_drop0+0x13a>
    5bf5:	eb a5                	jmp    5b9c <fwp_drop0+0x10c>
    5bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bfe:	00 00 
    5c00:	48 89 d0             	mov    %rdx,%rax
    5c03:	48 c1 e8 11          	shr    $0x11,%rax
    5c07:	48 31 d0             	xor    %rdx,%rax
    5c0a:	48 89 c1             	mov    %rax,%rcx
    5c0d:	48 c1 e9 09          	shr    $0x9,%rcx
    5c11:	48 31 c8             	xor    %rcx,%rax
    5c14:	0f b6 c8             	movzbl %al,%ecx
    5c17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5c1e:	00 
    5c1f:	48 85 c0             	test   %rax,%rax
    5c22:	75 25                	jne    5c49 <fwp_drop0+0x1b9>
    5c24:	eb 5e                	jmp    5c84 <fwp_drop0+0x1f4>
    5c26:	0f 1f 40 00          	nopl   0x0(%rax)
    5c2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c31:	00 00 00 00 
    5c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c3c:	00 00 00 00 
    5c40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5c44:	48 85 c0             	test   %rax,%rax
    5c47:	74 3b                	je     5c84 <fwp_drop0+0x1f4>
    5c49:	48 89 c1             	mov    %rax,%rcx
    5c4c:	48 39 10             	cmp    %rdx,(%rax)
    5c4f:	75 ef                	jne    5c40 <fwp_drop0+0x1b0>
    5c51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5c55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5c59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    5c5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5c64:	0f 85 b4 fe ff ff    	jne    5b1e <fwp_drop0+0x8e>
    5c6a:	48 89 d7             	mov    %rdx,%rdi
    5c6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c72:	e8 d9 e2 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5c77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    5c7f:	e9 9a fe ff ff       	jmp    5b1e <fwp_drop0+0x8e>
    5c84:	48 8d 3d 25 26 00 00 	lea    0x2625(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    5c8b:	e8 90 d4 ff ff       	call   3120 <fwp_trap>

0000000000005c90 <fwp_drop1>:
    5c90:	f3 0f 1e fa          	endbr64
    5c94:	e9 f7 fd ff ff       	jmp    5a90 <fwp_drop0>
    5c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005ca0 <fwp_drop6>:
    5ca0:	f3 0f 1e fa          	endbr64
    5ca4:	48 8b 0d 0d 6e 01 00 	mov    0x16e0d(%rip),%rcx        # 1cab8 <fwp_heap+0x13d8>
    5cab:	48 89 f8             	mov    %rdi,%rax
    5cae:	48 2b 05 db 6d 01 00 	sub    0x16ddb(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    5cb5:	48 c1 e1 10          	shl    $0x10,%rcx
    5cb9:	48 39 c8             	cmp    %rcx,%rax
    5cbc:	0f 83 56 01 00 00    	jae    5e18 <fwp_drop6+0x178>
    5cc2:	48 83 ec 18          	sub    $0x18,%rsp
    5cc6:	48 89 fa             	mov    %rdi,%rdx
    5cc9:	4c 8d 05 10 5a 01 00 	lea    0x15a10(%rip),%r8        # 1b6e0 <fwp_heap>
    5cd0:	48 89 c1             	mov    %rax,%rcx
    5cd3:	48 c1 e9 10          	shr    $0x10,%rcx
    5cd7:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5cdb:	49 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%rcx
    5ce2:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    5ce6:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    5cea:	48 85 c9             	test   %rcx,%rcx
    5ced:	74 40                	je     5d2f <fwp_drop6+0x8f>
    5cef:	0f b6 3e             	movzbl (%rsi),%edi
    5cf2:	40 80 ff 02          	cmp    $0x2,%dil
    5cf6:	74 40                	je     5d38 <fwp_drop6+0x98>
    5cf8:	40 80 ff 01          	cmp    $0x1,%dil
    5cfc:	75 31                	jne    5d2f <fwp_drop6+0x8f>
    5cfe:	8b 7e 18             	mov    0x18(%rsi),%edi
    5d01:	0f b7 c0             	movzwl %ax,%eax
    5d04:	8b 76 1c             	mov    0x1c(%rsi),%esi
    5d07:	48 0f af c7          	imul   %rdi,%rax
    5d0b:	48 c1 e8 20          	shr    $0x20,%rax
    5d0f:	48 39 f0             	cmp    %rsi,%rax
    5d12:	73 1b                	jae    5d2f <fwp_drop6+0x8f>
    5d14:	48 01 c1             	add    %rax,%rcx
    5d17:	0f b6 01             	movzbl (%rcx),%eax
    5d1a:	84 c0                	test   %al,%al
    5d1c:	74 11                	je     5d2f <fwp_drop6+0x8f>
    5d1e:	3c 01                	cmp    $0x1,%al
    5d20:	74 26                	je     5d48 <fwp_drop6+0xa8>
    5d22:	3c ff                	cmp    $0xff,%al
    5d24:	0f 84 06 01 00 00    	je     5e30 <fwp_drop6+0x190>
    5d2a:	83 e8 01             	sub    $0x1,%eax
    5d2d:	88 01                	mov    %al,(%rcx)
    5d2f:	48 83 c4 18          	add    $0x18,%rsp
    5d33:	c3                   	ret
    5d34:	0f 1f 40 00          	nopl   0x0(%rax)
    5d38:	66 85 c0             	test   %ax,%ax
    5d3b:	74 da                	je     5d17 <fwp_drop6+0x77>
    5d3d:	48 83 c4 18          	add    $0x18,%rsp
    5d41:	c3                   	ret
    5d42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d48:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    5d4c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5d51:	e8 2a f7 ff ff       	call   5480 <fwp_drop4>
    5d56:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d5b:	4c 8d 05 7e 59 01 00 	lea    0x1597e(%rip),%r8        # 1b6e0 <fwp_heap>
    5d62:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5d69:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5d70:	48 89 d0             	mov    %rdx,%rax
    5d73:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    5d77:	48 29 f0             	sub    %rsi,%rax
    5d7a:	48 c1 e1 10          	shl    $0x10,%rcx
    5d7e:	48 39 c8             	cmp    %rcx,%rax
    5d81:	73 7a                	jae    5dfd <fwp_drop6+0x15d>
    5d83:	48 89 c7             	mov    %rax,%rdi
    5d86:	48 c1 ef 10          	shr    $0x10,%rdi
    5d8a:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
    5d8e:	49 8b b8 f8 13 00 00 	mov    0x13f8(%r8),%rdi
    5d95:	4a 8d 3c d7          	lea    (%rdi,%r10,8),%rdi
    5d99:	4c 8b 57 20          	mov    0x20(%rdi),%r10
    5d9d:	4d 85 d2             	test   %r10,%r10
    5da0:	74 5b                	je     5dfd <fwp_drop6+0x15d>
    5da2:	44 0f b6 1f          	movzbl (%rdi),%r11d
    5da6:	41 80 fb 02          	cmp    $0x2,%r11b
    5daa:	74 74                	je     5e20 <fwp_drop6+0x180>
    5dac:	41 80 fb 01          	cmp    $0x1,%r11b
    5db0:	75 4b                	jne    5dfd <fwp_drop6+0x15d>
    5db2:	44 8b 5f 18          	mov    0x18(%rdi),%r11d
    5db6:	0f b7 c0             	movzwl %ax,%eax
    5db9:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    5dbc:	49 0f af c3          	imul   %r11,%rax
    5dc0:	48 c1 e8 20          	shr    $0x20,%rax
    5dc4:	48 39 f8             	cmp    %rdi,%rax
    5dc7:	73 34                	jae    5dfd <fwp_drop6+0x15d>
    5dc9:	49 01 c2             	add    %rax,%r10
    5dcc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5dd0:	75 2b                	jne    5dfd <fwp_drop6+0x15d>
    5dd2:	48 89 d7             	mov    %rdx,%rdi
    5dd5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5dda:	e8 b1 e3 ff ff       	call   4190 <fwp_mem_free>
    5ddf:	4c 8d 05 fa 58 01 00 	lea    0x158fa(%rip),%r8        # 1b6e0 <fwp_heap>
    5de6:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5deb:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5df2:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5df9:	48 c1 e1 10          	shl    $0x10,%rcx
    5dfd:	4c 89 c8             	mov    %r9,%rax
    5e00:	48 29 f0             	sub    %rsi,%rax
    5e03:	48 39 c8             	cmp    %rcx,%rax
    5e06:	0f 83 23 ff ff ff    	jae    5d2f <fwp_drop6+0x8f>
    5e0c:	4c 89 ca             	mov    %r9,%rdx
    5e0f:	e9 bc fe ff ff       	jmp    5cd0 <fwp_drop6+0x30>
    5e14:	0f 1f 40 00          	nopl   0x0(%rax)
    5e18:	c3                   	ret
    5e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e20:	66 85 c0             	test   %ax,%ax
    5e23:	75 d8                	jne    5dfd <fwp_drop6+0x15d>
    5e25:	eb a5                	jmp    5dcc <fwp_drop6+0x12c>
    5e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e2e:	00 00 
    5e30:	48 89 c8             	mov    %rcx,%rax
    5e33:	48 c1 e8 11          	shr    $0x11,%rax
    5e37:	48 31 c8             	xor    %rcx,%rax
    5e3a:	48 89 c2             	mov    %rax,%rdx
    5e3d:	48 c1 ea 09          	shr    $0x9,%rdx
    5e41:	48 31 d0             	xor    %rdx,%rax
    5e44:	0f b6 d0             	movzbl %al,%edx
    5e47:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    5e4e:	00 
    5e4f:	48 85 c0             	test   %rax,%rax
    5e52:	75 15                	jne    5e69 <fwp_drop6+0x1c9>
    5e54:	eb 4e                	jmp    5ea4 <fwp_drop6+0x204>
    5e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e5d:	00 00 00 
    5e60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    5e64:	48 85 c0             	test   %rax,%rax
    5e67:	74 3b                	je     5ea4 <fwp_drop6+0x204>
    5e69:	48 89 c2             	mov    %rax,%rdx
    5e6c:	48 39 08             	cmp    %rcx,(%rax)
    5e6f:	75 ef                	jne    5e60 <fwp_drop6+0x1c0>
    5e71:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5e75:	48 83 ea 01          	sub    $0x1,%rdx
    5e79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    5e84:	0f 85 a5 fe ff ff    	jne    5d2f <fwp_drop6+0x8f>
    5e8a:	48 89 cf             	mov    %rcx,%rdi
    5e8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e92:	e8 b9 e0 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5e97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    5e9f:	e9 8b fe ff ff       	jmp    5d2f <fwp_drop6+0x8f>
    5ea4:	48 8d 3d 05 24 00 00 	lea    0x2405(%rip),%rdi        # 82b0 <_IO_stdin_used+0x2b0>
    5eab:	e8 70 d2 ff ff       	call   3120 <fwp_trap>

0000000000005eb0 <fwp_write>:
    5eb0:	41 57                	push   %r15
    5eb2:	41 56                	push   %r14
    5eb4:	41 55                	push   %r13
    5eb6:	41 54                	push   %r12
    5eb8:	55                   	push   %rbp
    5eb9:	53                   	push   %rbx
    5eba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    5ec1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5ec8:	00 00 
    5eca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    5ed1:	00 
    5ed2:	49 89 d4             	mov    %rdx,%r12
    5ed5:	8b 12                	mov    (%rdx),%edx
    5ed7:	83 fa 19             	cmp    $0x19,%edx
    5eda:	77 6a                	ja     5f46 <fwp_write+0x96>
    5edc:	48 89 f5             	mov    %rsi,%rbp
    5edf:	89 d0                	mov    %edx,%eax
    5ee1:	89 ce                	mov    %ecx,%esi
    5ee3:	48 89 fb             	mov    %rdi,%rbx
    5ee6:	48 8d 0d f3 24 00 00 	lea    0x24f3(%rip),%rcx        # 83e0 <_IO_stdin_used+0x3e0>
    5eed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    5ef1:	48 01 c8             	add    %rcx,%rax
    5ef4:	3e ff e0             	notrack jmp *%rax
    5ef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5efe:	00 00 
    5f00:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    5f04:	48 8b 45 00          	mov    0x0(%rbp),%rax
    5f08:	48 89 ca             	mov    %rcx,%rdx
    5f0b:	48 85 c9             	test   %rcx,%rcx
    5f0e:	0f 88 9c 0c 00 00    	js     6bb0 <fwp_write+0xd00>
    5f14:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f1b:	00 
    5f1c:	48 89 c6             	mov    %rax,%rsi
    5f1f:	4c 89 e7             	mov    %r12,%rdi
    5f22:	e8 d9 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f2e:	00 00 
    5f30:	4c 89 e7             	mov    %r12,%rdi
    5f33:	e8 f8 c4 ff ff       	call   2430 <strlen@plt>
    5f38:	4c 89 e6             	mov    %r12,%rsi
    5f3b:	48 89 df             	mov    %rbx,%rdi
    5f3e:	48 89 c2             	mov    %rax,%rdx
    5f41:	e8 aa d0 ff ff       	call   2ff0 <buf_put>
    5f46:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5f4d:	00 
    5f4e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f55:	00 00 
    5f57:	0f 85 28 04 00 00    	jne    6385 <fwp_write+0x4d5>
    5f5d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    5f64:	5b                   	pop    %rbx
    5f65:	5d                   	pop    %rbp
    5f66:	41 5c                	pop    %r12
    5f68:	41 5d                	pop    %r13
    5f6a:	41 5e                	pop    %r14
    5f6c:	41 5f                	pop    %r15
    5f6e:	c3                   	ret
    5f6f:	90                   	nop
    5f70:	49 89 e9             	mov    %rbp,%r9
    5f73:	4c 8d 05 7a 21 00 00 	lea    0x217a(%rip),%r8        # 80f4 <_IO_stdin_used+0xf4>
    5f7a:	b9 00 02 00 00       	mov    $0x200,%ecx
    5f7f:	ba 02 00 00 00       	mov    $0x2,%edx
    5f84:	be 00 02 00 00       	mov    $0x200,%esi
    5f89:	31 c0                	xor    %eax,%eax
    5f8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f92:	00 
    5f93:	e8 f8 c3 ff ff       	call   2390 <__snprintf_chk@plt>
    5f98:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f9f:	00 
    5fa0:	e8 8b c4 ff ff       	call   2430 <strlen@plt>
    5fa5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5fac:	00 
    5fad:	48 89 df             	mov    %rbx,%rdi
    5fb0:	48 89 c2             	mov    %rax,%rdx
    5fb3:	e8 38 d0 ff ff       	call   2ff0 <buf_put>
    5fb8:	eb 8c                	jmp    5f46 <fwp_write+0x96>
    5fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fc0:	49 89 e9             	mov    %rbp,%r9
    5fc3:	4c 8d 05 25 21 00 00 	lea    0x2125(%rip),%r8        # 80ef <_IO_stdin_used+0xef>
    5fca:	eb ae                	jmp    5f7a <fwp_write+0xca>
    5fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    5fd0:	83 fa 13             	cmp    $0x13,%edx
    5fd3:	48 8d 05 0b 21 00 00 	lea    0x210b(%rip),%rax        # 80e5 <_IO_stdin_used+0xe5>
    5fda:	48 8d 35 09 21 00 00 	lea    0x2109(%rip),%rsi        # 80ea <_IO_stdin_used+0xea>
    5fe1:	ba 04 00 00 00       	mov    $0x4,%edx
    5fe6:	48 0f 44 f0          	cmove  %rax,%rsi
    5fea:	45 31 ed             	xor    %r13d,%r13d
    5fed:	e8 fe cf ff ff       	call   2ff0 <buf_put>
    5ff2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5ff7:	0f 84 a3 08 00 00    	je     68a0 <fwp_write+0x9f0>
    5ffd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    6002:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    6007:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    600c:	48 89 df             	mov    %rbx,%rdi
    600f:	49 0f 44 c5          	cmove  %r13,%rax
    6013:	31 c9                	xor    %ecx,%ecx
    6015:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    601a:	e8 91 fe ff ff       	call   5eb0 <fwp_write>
    601f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    6024:	0f 84 6e 09 00 00    	je     6998 <fwp_write+0xae8>
    602a:	49 83 c5 01          	add    $0x1,%r13
    602e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    6032:	0f 83 68 08 00 00    	jae    68a0 <fwp_write+0x9f0>
    6038:	ba 02 00 00 00       	mov    $0x2,%edx
    603d:	48 8d 35 f0 20 00 00 	lea    0x20f0(%rip),%rsi        # 8134 <_IO_stdin_used+0x134>
    6044:	48 89 df             	mov    %rbx,%rdi
    6047:	e8 a4 cf ff ff       	call   2ff0 <buf_put>
    604c:	eb af                	jmp    5ffd <fwp_write+0x14d>
    604e:	66 90                	xchg   %ax,%ax
    6050:	ba 06 00 00 00       	mov    $0x6,%edx
    6055:	48 8d 35 b1 20 00 00 	lea    0x20b1(%rip),%rsi        # 810d <_IO_stdin_used+0x10d>
    605c:	48 83 c5 10          	add    $0x10,%rbp
    6060:	e8 8b cf ff ff       	call   2ff0 <buf_put>
    6065:	48 89 ef             	mov    %rbp,%rdi
    6068:	e8 c3 c3 ff ff       	call   2430 <strlen@plt>
    606d:	48 89 ee             	mov    %rbp,%rsi
    6070:	48 89 df             	mov    %rbx,%rdi
    6073:	48 89 c2             	mov    %rax,%rdx
    6076:	e8 75 cf ff ff       	call   2ff0 <buf_put>
    607b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6080:	ba 01 00 00 00       	mov    $0x1,%edx
    6085:	48 89 df             	mov    %rbx,%rdi
    6088:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    608d:	e8 5e cf ff ff       	call   2ff0 <buf_put>
    6092:	e9 af fe ff ff       	jmp    5f46 <fwp_write+0x96>
    6097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    609e:	00 00 
    60a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    60a7:	00 
    60a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60af:	00 00 
    60b1:	0f 85 ce 02 00 00    	jne    6385 <fwp_write+0x4d5>
    60b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    60bc:	48 8d 35 36 20 00 00 	lea    0x2036(%rip),%rsi        # 80f9 <_IO_stdin_used+0xf9>
    60c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    60ca:	48 89 df             	mov    %rbx,%rdi
    60cd:	5b                   	pop    %rbx
    60ce:	5d                   	pop    %rbp
    60cf:	41 5c                	pop    %r12
    60d1:	41 5d                	pop    %r13
    60d3:	41 5e                	pop    %r14
    60d5:	41 5f                	pop    %r15
    60d7:	e9 14 cf ff ff       	jmp    2ff0 <buf_put>
    60dc:	0f 1f 40 00          	nopl   0x0(%rax)
    60e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    60e5:	4d 85 ed             	test   %r13,%r13
    60e8:	0f 84 02 0c 00 00    	je     6cf0 <fwp_write+0xe40>
    60ee:	48 8d 35 4c 20 00 00 	lea    0x204c(%rip),%rsi        # 8141 <_IO_stdin_used+0x141>
    60f5:	4c 89 ef             	mov    %r13,%rdi
    60f8:	e8 13 c4 ff ff       	call   2510 <strcmp@plt>
    60fd:	41 89 c1             	mov    %eax,%r9d
    6100:	85 c0                	test   %eax,%eax
    6102:	0f 84 6c 0c 00 00    	je     6d74 <fwp_write+0xec4>
    6108:	4c 89 ef             	mov    %r13,%rdi
    610b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6110:	e8 1b c3 ff ff       	call   2430 <strlen@plt>
    6115:	4c 89 ee             	mov    %r13,%rsi
    6118:	48 89 df             	mov    %rbx,%rdi
    611b:	48 89 c2             	mov    %rax,%rdx
    611e:	e8 cd ce ff ff       	call   2ff0 <buf_put>
    6123:	ba 01 00 00 00       	mov    $0x1,%edx
    6128:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    612d:	48 89 df             	mov    %rbx,%rdi
    6130:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    6135:	e8 b6 ce ff ff       	call   2ff0 <buf_put>
    613a:	ba 01 00 00 00       	mov    $0x1,%edx
    613f:	4c 89 fe             	mov    %r15,%rsi
    6142:	48 89 df             	mov    %rbx,%rdi
    6145:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    614a:	e8 a1 ce ff ff       	call   2ff0 <buf_put>
    614f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    6154:	45 31 f6             	xor    %r14d,%r14d
    6157:	85 d2                	test   %edx,%edx
    6159:	0f 8e 81 0a 00 00    	jle    6be0 <fwp_write+0xd30>
    615f:	45 31 ed             	xor    %r13d,%r13d
    6162:	4d 85 ed             	test   %r13,%r13
    6165:	0f 85 75 07 00 00    	jne    68e0 <fwp_write+0xa30>
    616b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6172:	00 
    6173:	45 85 f6             	test   %r14d,%r14d
    6176:	0f 84 84 07 00 00    	je     6900 <fwp_write+0xa50>
    617c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    6181:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    6186:	48 89 df             	mov    %rbx,%rdi
    6189:	49 83 c5 01          	add    $0x1,%r13
    618d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    6191:	31 c9                	xor    %ecx,%ecx
    6193:	e8 18 fd ff ff       	call   5eb0 <fwp_write>
    6198:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    619d:	7f c3                	jg     6162 <fwp_write+0x2b2>
    619f:	45 85 f6             	test   %r14d,%r14d
    61a2:	0f 84 38 0a 00 00    	je     6be0 <fwp_write+0xd30>
    61a8:	b8 29 00 00 00       	mov    $0x29,%eax
    61ad:	ba 01 00 00 00       	mov    $0x1,%edx
    61b2:	4c 89 fe             	mov    %r15,%rsi
    61b5:	48 89 df             	mov    %rbx,%rdi
    61b8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    61bc:	e8 2f ce ff ff       	call   2ff0 <buf_put>
    61c1:	e9 80 fd ff ff       	jmp    5f46 <fwp_write+0x96>
    61c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61cd:	00 00 00 
    61d0:	ba 01 00 00 00       	mov    $0x1,%edx
    61d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    61da:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    61df:	e8 0c ce ff ff       	call   2ff0 <buf_put>
    61e4:	48 85 ed             	test   %rbp,%rbp
    61e7:	0f 84 93 06 00 00    	je     6880 <fwp_write+0x9d0>
    61ed:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    61f1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    61f6:	31 c9                	xor    %ecx,%ecx
    61f8:	48 89 df             	mov    %rbx,%rdi
    61fb:	e8 b0 fc ff ff       	call   5eb0 <fwp_write>
    6200:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6204:	48 85 ed             	test   %rbp,%rbp
    6207:	0f 84 73 06 00 00    	je     6880 <fwp_write+0x9d0>
    620d:	ba 02 00 00 00       	mov    $0x2,%edx
    6212:	48 8d 35 1b 1f 00 00 	lea    0x1f1b(%rip),%rsi        # 8134 <_IO_stdin_used+0x134>
    6219:	48 89 df             	mov    %rbx,%rdi
    621c:	e8 cf cd ff ff       	call   2ff0 <buf_put>
    6221:	eb ca                	jmp    61ed <fwp_write+0x33d>
    6223:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6228:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    622c:	85 f6                	test   %esi,%esi
    622e:	0f 84 fc 07 00 00    	je     6a30 <fwp_write+0xb80>
    6234:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    623b:	00 
    623c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6243:	00 00 
    6245:	0f 85 3a 01 00 00    	jne    6385 <fwp_write+0x4d5>
    624b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    624f:	4c 89 ea             	mov    %r13,%rdx
    6252:	e9 6c fe ff ff       	jmp    60c3 <fwp_write+0x213>
    6257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    625e:	00 00 
    6260:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    6265:	ba 01 00 00 00       	mov    $0x1,%edx
    626a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    626f:	48 89 ee             	mov    %rbp,%rsi
    6272:	e8 79 cd ff ff       	call   2ff0 <buf_put>
    6277:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    627c:	4c 89 e7             	mov    %r12,%rdi
    627f:	e8 ac c1 ff ff       	call   2430 <strlen@plt>
    6284:	4c 89 e6             	mov    %r12,%rsi
    6287:	48 89 df             	mov    %rbx,%rdi
    628a:	48 89 c2             	mov    %rax,%rdx
    628d:	e8 5e cd ff ff       	call   2ff0 <buf_put>
    6292:	ba 01 00 00 00       	mov    $0x1,%edx
    6297:	48 89 ee             	mov    %rbp,%rsi
    629a:	48 89 df             	mov    %rbx,%rdi
    629d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    62a2:	e8 49 cd ff ff       	call   2ff0 <buf_put>
    62a7:	e9 9a fc ff ff       	jmp    5f46 <fwp_write+0x96>
    62ac:	0f 1f 40 00          	nopl   0x0(%rax)
    62b0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    62b5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    62b9:	0f 8a 8e 0b 00 00    	jp     6e4d <fwp_write+0xf9d>
    62bf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    62c3:	66 0f 54 05 35 22 00 	andpd  0x2235(%rip),%xmm0        # 8500 <msg.3+0xb0>
    62ca:	00 
    62cb:	bd 01 00 00 00       	mov    $0x1,%ebp
    62d0:	66 0f 2e 05 b8 21 00 	ucomisd 0x21b8(%rip),%xmm0        # 8490 <msg.3+0x40>
    62d7:	00 
    62d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    62df:	00 
    62e0:	0f 87 b2 09 00 00    	ja     6c98 <fwp_write+0xde8>
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    62f4:	89 ee                	mov    %ebp,%esi
    62f6:	4c 89 e7             	mov    %r12,%rdi
    62f9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    62fe:	e8 fd ce ff ff       	call   3200 <fwp_format_g.constprop.0>
    6303:	31 f6                	xor    %esi,%esi
    6305:	4c 89 e7             	mov    %r12,%rdi
    6308:	e8 e3 c0 ff ff       	call   23f0 <strtod@plt>
    630d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6312:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    6316:	7a 06                	jp     631e <fwp_write+0x46e>
    6318:	0f 84 e9 01 00 00    	je     6507 <fwp_write+0x657>
    631e:	83 c5 01             	add    $0x1,%ebp
    6321:	83 fd 12             	cmp    $0x12,%ebp
    6324:	75 ca                	jne    62f0 <fwp_write+0x440>
    6326:	be 11 00 00 00       	mov    $0x11,%esi
    632b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    632f:	4c 89 e7             	mov    %r12,%rdi
    6332:	e8 c9 ce ff ff       	call   3200 <fwp_format_g.constprop.0>
    6337:	e9 cb 01 00 00       	jmp    6507 <fwp_write+0x657>
    633c:	0f 1f 40 00          	nopl   0x0(%rax)
    6340:	48 83 fd 01          	cmp    $0x1,%rbp
    6344:	0f 84 e6 08 00 00    	je     6c30 <fwp_write+0xd80>
    634a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    634e:	b8 02 00 00 00       	mov    $0x2,%eax
    6353:	ba 01 00 00 00       	mov    $0x1,%edx
    6358:	48 0f 44 d0          	cmove  %rax,%rdx
    635c:	48 8d 35 7a 1d 00 00 	lea    0x1d7a(%rip),%rsi        # 80dd <_IO_stdin_used+0xdd>
    6363:	48 8d 05 78 1d 00 00 	lea    0x1d78(%rip),%rax        # 80e2 <_IO_stdin_used+0xe2>
    636a:	48 0f 44 f0          	cmove  %rax,%rsi
    636e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6375:	00 
    6376:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    637d:	00 00 
    637f:	0f 84 3e fd ff ff    	je     60c3 <fwp_write+0x213>
    6385:	e8 b6 c0 ff ff       	call   2440 <__stack_chk_fail@plt>
    638a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6390:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    6395:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    639a:	e8 91 cb ff ff       	call   2f30 <buf_grow>
    639f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    63a3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    63a9:	4c 03 0b             	add    (%rbx),%r9
    63ac:	66 45 89 11          	mov    %r10w,(%r9)
    63b0:	45 85 e4             	test   %r12d,%r12d
    63b3:	0f 8e 07 05 00 00    	jle    68c0 <fwp_write+0xa10>
    63b9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    63c0:	55 55 55 
    63c3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    63c8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    63cf:	aa aa aa 
    63d2:	49 83 c1 01          	add    $0x1,%r9
    63d6:	eb 45                	jmp    641d <fwp_write+0x56d>
    63d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63df:	00 
    63e0:	be 01 00 00 00       	mov    $0x1,%esi
    63e5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    63ea:	88 07                	mov    %al,(%rdi)
    63ec:	48 89 e8             	mov    %rbp,%rax
    63ef:	49 f7 e8             	imul   %r8
    63f2:	48 89 e8             	mov    %rbp,%rax
    63f5:	48 c1 f8 3f          	sar    $0x3f,%rax
    63f9:	48 29 c2             	sub    %rax,%rdx
    63fc:	48 85 c9             	test   %rcx,%rcx
    63ff:	0f 95 c0             	setne  %al
    6402:	48 c1 ed 3f          	shr    $0x3f,%rbp
    6406:	48 83 ef 01          	sub    $0x1,%rdi
    640a:	48 21 c5             	and    %rax,%rbp
    640d:	48 29 ea             	sub    %rbp,%rdx
    6410:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    6414:	49 39 f9             	cmp    %rdi,%r9
    6417:	0f 84 a3 04 00 00    	je     68c0 <fwp_write+0xa10>
    641d:	48 89 e8             	mov    %rbp,%rax
    6420:	49 f7 e8             	imul   %r8
    6423:	48 89 e8             	mov    %rbp,%rax
    6426:	48 c1 f8 3f          	sar    $0x3f,%rax
    642a:	48 89 d1             	mov    %rdx,%rcx
    642d:	48 29 c1             	sub    %rax,%rcx
    6430:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    6434:	48 89 e9             	mov    %rbp,%rcx
    6437:	48 29 c1             	sub    %rax,%rcx
    643a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    643e:	49 f7 e2             	mul    %r10
    6441:	b8 30 00 00 00       	mov    $0x30,%eax
    6446:	48 89 d6             	mov    %rdx,%rsi
    6449:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    644d:	48 d1 ee             	shr    $1,%rsi
    6450:	48 01 f2             	add    %rsi,%rdx
    6453:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    6457:	48 29 d6             	sub    %rdx,%rsi
    645a:	74 8e                	je     63ea <fwp_write+0x53a>
    645c:	48 83 fe 01          	cmp    $0x1,%rsi
    6460:	0f 85 7a ff ff ff    	jne    63e0 <fwp_write+0x530>
    6466:	31 f6                	xor    %esi,%esi
    6468:	b8 2b 00 00 00       	mov    $0x2b,%eax
    646d:	e9 78 ff ff ff       	jmp    63ea <fwp_write+0x53a>
    6472:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6478:	66 0f 6e cd          	movd   %ebp,%xmm1
    647c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    647f:	0f 8a c8 09 00 00    	jp     6e4d <fwp_write+0xf9d>
    6485:	0f 28 c1             	movaps %xmm1,%xmm0
    6488:	0f 54 05 61 20 00 00 	andps  0x2061(%rip),%xmm0        # 84f0 <msg.3+0xa0>
    648f:	0f 2e 05 6e 1b 00 00 	ucomiss 0x1b6e(%rip),%xmm0        # 8004 <_IO_stdin_used+0x4>
    6496:	0f 87 24 08 00 00    	ja     6cc0 <fwp_write+0xe10>
    649c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    64a0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    64a6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    64ad:	00 
    64ae:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    64b2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    64b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    64be:	00 00 
    64c0:	44 89 ee             	mov    %r13d,%esi
    64c3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    64c8:	4c 89 e7             	mov    %r12,%rdi
    64cb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    64d0:	e8 2b cd ff ff       	call   3200 <fwp_format_g.constprop.0>
    64d5:	31 f6                	xor    %esi,%esi
    64d7:	4c 89 e7             	mov    %r12,%rdi
    64da:	e8 b1 bf ff ff       	call   2490 <strtof@plt>
    64df:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    64e4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    64e7:	7a 02                	jp     64eb <fwp_write+0x63b>
    64e9:	74 1c                	je     6507 <fwp_write+0x657>
    64eb:	41 83 c5 01          	add    $0x1,%r13d
    64ef:	41 83 fd 0a          	cmp    $0xa,%r13d
    64f3:	75 cb                	jne    64c0 <fwp_write+0x610>
    64f5:	be 09 00 00 00       	mov    $0x9,%esi
    64fa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    64ff:	4c 89 e7             	mov    %r12,%rdi
    6502:	e8 f9 cc ff ff       	call   3200 <fwp_format_g.constprop.0>
    6507:	4c 89 e7             	mov    %r12,%rdi
    650a:	e8 a1 cb ff ff       	call   30b0 <fwp_finish_float>
    650f:	e9 1c fa ff ff       	jmp    5f30 <fwp_write+0x80>
    6514:	0f 1f 40 00          	nopl   0x0(%rax)
    6518:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    651c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    6520:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    6527:	00 
    6528:	48 89 ef             	mov    %rbp,%rdi
    652b:	e8 d0 c4 ff ff       	call   2a00 <fwp_fmt_u128>
    6530:	48 89 ef             	mov    %rbp,%rdi
    6533:	e8 f8 be ff ff       	call   2430 <strlen@plt>
    6538:	48 89 ee             	mov    %rbp,%rsi
    653b:	48 89 df             	mov    %rbx,%rdi
    653e:	48 89 c2             	mov    %rax,%rdx
    6541:	e8 aa ca ff ff       	call   2ff0 <buf_put>
    6546:	e9 fb f9 ff ff       	jmp    5f46 <fwp_write+0x96>
    654b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6550:	ba 06 00 00 00       	mov    $0x6,%edx
    6555:	48 8d 35 db 1b 00 00 	lea    0x1bdb(%rip),%rsi        # 8137 <_IO_stdin_used+0x137>
    655c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    6562:	e8 89 ca ff ff       	call   2ff0 <buf_put>
    6567:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    656e:	ff ff 7f 
    6571:	48 23 55 00          	and    0x0(%rbp),%rdx
    6575:	0f 84 86 02 00 00    	je     6801 <fwp_write+0x951>
    657b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6580:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    6584:	48 85 d2             	test   %rdx,%rdx
    6587:	0f 84 ae 00 00 00    	je     663b <fwp_write+0x78b>
    658d:	8b 0a                	mov    (%rdx),%ecx
    658f:	83 f9 1c             	cmp    $0x1c,%ecx
    6592:	0f 84 58 06 00 00    	je     6bf0 <fwp_write+0xd40>
    6598:	83 f9 1b             	cmp    $0x1b,%ecx
    659b:	0f 87 9a 00 00 00    	ja     663b <fwp_write+0x78b>
    65a1:	be 01 00 00 00       	mov    $0x1,%esi
    65a6:	48 d3 e6             	shl    %cl,%rsi
    65a9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    65af:	0f 85 4b 04 00 00    	jne    6a00 <fwp_write+0xb50>
    65b5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    65bb:	0f 85 0f 04 00 00    	jne    69d0 <fwp_write+0xb20>
    65c1:	83 e6 21             	and    $0x21,%esi
    65c4:	74 75                	je     663b <fwp_write+0x78b>
    65c6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    65cb:	48 85 ff             	test   %rdi,%rdi
    65ce:	79 07                	jns    65d7 <fwp_write+0x727>
    65d0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    65d4:	4c 01 ee             	add    %r13,%rsi
    65d7:	48 0f be 3e          	movsbq (%rsi),%rdi
    65db:	85 c9                	test   %ecx,%ecx
    65dd:	40 0f b6 f7          	movzbl %dil,%esi
    65e1:	48 0f 44 f7          	cmove  %rdi,%rsi
    65e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    65ec:	00 00 00 00 
    65f0:	31 c9                	xor    %ecx,%ecx
    65f2:	48 89 df             	mov    %rbx,%rdi
    65f5:	49 83 c5 01          	add    $0x1,%r13
    65f9:	e8 b2 f8 ff ff       	call   5eb0 <fwp_write>
    65fe:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    6605:	ff ff 7f 
    6608:	48 23 55 00          	and    0x0(%rbp),%rdx
    660c:	49 39 d5             	cmp    %rdx,%r13
    660f:	0f 83 ec 01 00 00    	jae    6801 <fwp_write+0x951>
    6615:	ba 02 00 00 00       	mov    $0x2,%edx
    661a:	48 89 df             	mov    %rbx,%rdi
    661d:	48 8d 35 10 1b 00 00 	lea    0x1b10(%rip),%rsi        # 8134 <_IO_stdin_used+0x134>
    6624:	e8 c7 c9 ff ff       	call   2ff0 <buf_put>
    6629:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    662e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    6632:	48 85 d2             	test   %rdx,%rdx
    6635:	0f 85 52 ff ff ff    	jne    658d <fwp_write+0x6dd>
    663b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    6640:	48 85 ff             	test   %rdi,%rdi
    6643:	0f 88 cf 05 00 00    	js     6c18 <fwp_write+0xd68>
    6649:	48 8b 31             	mov    (%rcx),%rsi
    664c:	eb a2                	jmp    65f0 <fwp_write+0x740>
    664e:	66 90                	xchg   %ax,%ax
    6650:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6657:	00 
    6658:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    665f:	00 00 
    6661:	0f 85 1e fd ff ff    	jne    6385 <fwp_write+0x4d5>
    6667:	ba 08 00 00 00       	mov    $0x8,%edx
    666c:	48 8d 35 91 1a 00 00 	lea    0x1a91(%rip),%rsi        # 8104 <_IO_stdin_used+0x104>
    6673:	e9 4b fa ff ff       	jmp    60c3 <fwp_write+0x213>
    6678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    667f:	00 
    6680:	89 e8                	mov    %ebp,%eax
    6682:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    6689:	76 03                	jbe    668e <fwp_write+0x7de>
    668b:	8b 45 00             	mov    0x0(%rbp),%eax
    668e:	41 89 c6             	mov    %eax,%r14d
    6691:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6696:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    669b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    669f:	4c 89 ef             	mov    %r13,%rdi
    66a2:	e8 89 bd ff ff       	call   2430 <strlen@plt>
    66a7:	4c 89 ee             	mov    %r13,%rsi
    66aa:	48 89 df             	mov    %rbx,%rdi
    66ad:	48 89 c2             	mov    %rax,%rdx
    66b0:	e8 3b c9 ff ff       	call   2ff0 <buf_put>
    66b5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    66ba:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    66be:	85 f6                	test   %esi,%esi
    66c0:	0f 8e 80 f8 ff ff    	jle    5f46 <fwp_write+0x96>
    66c6:	45 31 ed             	xor    %r13d,%r13d
    66c9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    66ce:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    66d3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    66d8:	ba 01 00 00 00       	mov    $0x1,%edx
    66dd:	4c 89 fe             	mov    %r15,%rsi
    66e0:	48 89 04 24          	mov    %rax,(%rsp)
    66e4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    66e9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    66ed:	48 89 df             	mov    %rbx,%rdi
    66f0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    66f4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    66f9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    66fe:	e8 ed c8 ff ff       	call   2ff0 <buf_put>
    6703:	41 8b 06             	mov    (%r14),%eax
    6706:	83 f8 0e             	cmp    $0xe,%eax
    6709:	0f 84 71 02 00 00    	je     6980 <fwp_write+0xad0>
    670f:	83 f8 10             	cmp    $0x10,%eax
    6712:	0f 84 38 02 00 00    	je     6950 <fwp_write+0xaa0>
    6718:	83 f8 0a             	cmp    $0xa,%eax
    671b:	0f 84 7f 04 00 00    	je     6ba0 <fwp_write+0xcf0>
    6721:	0f 8f f9 00 00 00    	jg     6820 <fwp_write+0x970>
    6727:	83 f8 03             	cmp    $0x3,%eax
    672a:	0f 8f 50 04 00 00    	jg     6b80 <fwp_write+0xcd0>
    6730:	85 c0                	test   %eax,%eax
    6732:	78 10                	js     6744 <fwp_write+0x894>
    6734:	48 8b 04 24          	mov    (%rsp),%rax
    6738:	48 c1 e8 3f          	shr    $0x3f,%rax
    673c:	85 c0                	test   %eax,%eax
    673e:	0f 85 f9 00 00 00    	jne    683d <fwp_write+0x98d>
    6744:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6749:	48 8b 34 24          	mov    (%rsp),%rsi
    674d:	31 c9                	xor    %ecx,%ecx
    674f:	48 89 df             	mov    %rbx,%rdi
    6752:	e8 59 f7 ff ff       	call   5eb0 <fwp_write>
    6757:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    675c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6761:	49 83 c5 01          	add    $0x1,%r13
    6765:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    6769:	0f 8f 5f ff ff ff    	jg     66ce <fwp_write+0x81e>
    676f:	e9 d2 f7 ff ff       	jmp    5f46 <fwp_write+0x96>
    6774:	0f 1f 40 00          	nopl   0x0(%rax)
    6778:	ba 06 00 00 00       	mov    $0x6,%edx
    677d:	48 8d 35 a6 19 00 00 	lea    0x19a6(%rip),%rsi        # 812a <_IO_stdin_used+0x12a>
    6784:	45 31 ed             	xor    %r13d,%r13d
    6787:	e8 64 c8 ff ff       	call   2ff0 <buf_put>
    678c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6791:	75 19                	jne    67ac <fwp_write+0x8fc>
    6793:	eb 6c                	jmp    6801 <fwp_write+0x951>
    6795:	0f 1f 00             	nopl   (%rax)
    6798:	ba 02 00 00 00       	mov    $0x2,%edx
    679d:	48 8d 35 90 19 00 00 	lea    0x1990(%rip),%rsi        # 8134 <_IO_stdin_used+0x134>
    67a4:	48 89 df             	mov    %rbx,%rdi
    67a7:	e8 44 c8 ff ff       	call   2ff0 <buf_put>
    67ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    67b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    67b7:	31 c0                	xor    %eax,%eax
    67b9:	49 83 c5 01          	add    $0x1,%r13
    67bd:	4c 8d 05 6d 19 00 00 	lea    0x196d(%rip),%r8        # 8131 <_IO_stdin_used+0x131>
    67c4:	ba 02 00 00 00       	mov    $0x2,%edx
    67c9:	be 00 02 00 00       	mov    $0x200,%esi
    67ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    67d5:	00 
    67d6:	e8 b5 bb ff ff       	call   2390 <__snprintf_chk@plt>
    67db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    67e2:	00 
    67e3:	e8 48 bc ff ff       	call   2430 <strlen@plt>
    67e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    67ef:	00 
    67f0:	48 89 df             	mov    %rbx,%rdi
    67f3:	48 89 c2             	mov    %rax,%rdx
    67f6:	e8 f5 c7 ff ff       	call   2ff0 <buf_put>
    67fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    67ff:	72 97                	jb     6798 <fwp_write+0x8e8>
    6801:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6806:	ba 01 00 00 00       	mov    $0x1,%edx
    680b:	48 89 df             	mov    %rbx,%rdi
    680e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6813:	e8 d8 c7 ff ff       	call   2ff0 <buf_put>
    6818:	e9 29 f7 ff ff       	jmp    5f46 <fwp_write+0x96>
    681d:	0f 1f 00             	nopl   (%rax)
    6820:	83 f8 0b             	cmp    $0xb,%eax
    6823:	0f 85 1b ff ff ff    	jne    6744 <fwp_write+0x894>
    6829:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    682e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    6832:	83 e0 01             	and    $0x1,%eax
    6835:	85 c0                	test   %eax,%eax
    6837:	0f 84 07 ff ff ff    	je     6744 <fwp_write+0x894>
    683d:	4c 89 fe             	mov    %r15,%rsi
    6840:	48 89 df             	mov    %rbx,%rdi
    6843:	ba 01 00 00 00       	mov    $0x1,%edx
    6848:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    684d:	e8 9e c7 ff ff       	call   2ff0 <buf_put>
    6852:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6857:	48 8b 34 24          	mov    (%rsp),%rsi
    685b:	31 c9                	xor    %ecx,%ecx
    685d:	48 89 df             	mov    %rbx,%rdi
    6860:	e8 4b f6 ff ff       	call   5eb0 <fwp_write>
    6865:	ba 01 00 00 00       	mov    $0x1,%edx
    686a:	4c 89 fe             	mov    %r15,%rsi
    686d:	48 89 df             	mov    %rbx,%rdi
    6870:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    6875:	e8 76 c7 ff ff       	call   2ff0 <buf_put>
    687a:	e9 d8 fe ff ff       	jmp    6757 <fwp_write+0x8a7>
    687f:	90                   	nop
    6880:	ba 01 00 00 00       	mov    $0x1,%edx
    6885:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    688a:	48 89 df             	mov    %rbx,%rdi
    688d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6892:	e8 59 c7 ff ff       	call   2ff0 <buf_put>
    6897:	e9 aa f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    689c:	0f 1f 40 00          	nopl   0x0(%rax)
    68a0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    68a5:	ba 01 00 00 00       	mov    $0x1,%edx
    68aa:	48 89 df             	mov    %rbx,%rdi
    68ad:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    68b2:	e8 39 c7 ff ff       	call   2ff0 <buf_put>
    68b7:	e9 8a f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    68bc:	0f 1f 40 00          	nopl   0x0(%rax)
    68c0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    68c4:	48 8b 13             	mov    (%rbx),%rdx
    68c7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    68cc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    68d0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    68d4:	e9 6d f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    68d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68e0:	ba 02 00 00 00       	mov    $0x2,%edx
    68e5:	48 8d 35 48 18 00 00 	lea    0x1848(%rip),%rsi        # 8134 <_IO_stdin_used+0x134>
    68ec:	48 89 df             	mov    %rbx,%rdi
    68ef:	e8 fc c6 ff ff       	call   2ff0 <buf_put>
    68f4:	e9 72 f8 ff ff       	jmp    616b <fwp_write+0x2bb>
    68f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6900:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6905:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    690a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    690e:	48 89 f7             	mov    %rsi,%rdi
    6911:	48 89 34 24          	mov    %rsi,(%rsp)
    6915:	e8 16 bb ff ff       	call   2430 <strlen@plt>
    691a:	48 8b 34 24          	mov    (%rsp),%rsi
    691e:	48 89 df             	mov    %rbx,%rdi
    6921:	48 89 c2             	mov    %rax,%rdx
    6924:	e8 c7 c6 ff ff       	call   2ff0 <buf_put>
    6929:	ba 03 00 00 00       	mov    $0x3,%edx
    692e:	48 8d 35 22 18 00 00 	lea    0x1822(%rip),%rsi        # 8157 <_IO_stdin_used+0x157>
    6935:	48 89 df             	mov    %rbx,%rdi
    6938:	e8 b3 c6 ff ff       	call   2ff0 <buf_put>
    693d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6942:	e9 35 f8 ff ff       	jmp    617c <fwp_write+0x2cc>
    6947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    694e:	00 00 
    6950:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6955:	48 8b 78 08          	mov    0x8(%rax),%rdi
    6959:	48 85 ff             	test   %rdi,%rdi
    695c:	0f 84 e2 fd ff ff    	je     6744 <fwp_write+0x894>
    6962:	48 8d 35 d8 17 00 00 	lea    0x17d8(%rip),%rsi        # 8141 <_IO_stdin_used+0x141>
    6969:	e8 a2 bb ff ff       	call   2510 <strcmp@plt>
    696e:	85 c0                	test   %eax,%eax
    6970:	0f 95 c0             	setne  %al
    6973:	0f b6 c0             	movzbl %al,%eax
    6976:	e9 c1 fd ff ff       	jmp    673c <fwp_write+0x88c>
    697b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6980:	31 c0                	xor    %eax,%eax
    6982:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    6989:	00 
    698a:	0f 97 c0             	seta   %al
    698d:	e9 aa fd ff ff       	jmp    673c <fwp_write+0x88c>
    6992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6998:	48 89 df             	mov    %rbx,%rdi
    699b:	ba 02 00 00 00       	mov    $0x2,%edx
    69a0:	48 8d 35 97 17 00 00 	lea    0x1797(%rip),%rsi        # 813e <_IO_stdin_used+0x13e>
    69a7:	e8 44 c6 ff ff       	call   2ff0 <buf_put>
    69ac:	4c 89 e8             	mov    %r13,%rax
    69af:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    69b4:	31 c9                	xor    %ecx,%ecx
    69b6:	48 c1 e0 04          	shl    $0x4,%rax
    69ba:	48 89 df             	mov    %rbx,%rdi
    69bd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    69c2:	e8 e9 f4 ff ff       	call   5eb0 <fwp_write>
    69c7:	e9 5e f6 ff ff       	jmp    602a <fwp_write+0x17a>
    69cc:	0f 1f 40 00          	nopl   0x0(%rax)
    69d0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    69d5:	48 85 ff             	test   %rdi,%rdi
    69d8:	79 0c                	jns    69e6 <fwp_write+0xb36>
    69da:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    69e1:	00 
    69e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    69e6:	48 63 3e             	movslq (%rsi),%rdi
    69e9:	83 f9 02             	cmp    $0x2,%ecx
    69ec:	89 fe                	mov    %edi,%esi
    69ee:	48 0f 44 f7          	cmove  %rdi,%rsi
    69f2:	e9 f9 fb ff ff       	jmp    65f0 <fwp_write+0x740>
    69f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69fe:	00 00 
    6a00:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    6a05:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    6a0a:	48 85 ff             	test   %rdi,%rdi
    6a0d:	0f 88 0f 03 00 00    	js     6d22 <fwp_write+0xe72>
    6a13:	49 0f bf 38          	movswq (%r8),%rdi
    6a17:	83 f9 01             	cmp    $0x1,%ecx
    6a1a:	0f b7 f7             	movzwl %di,%esi
    6a1d:	48 0f 44 f7          	cmove  %rdi,%rsi
    6a21:	e9 ca fb ff ff       	jmp    65f0 <fwp_write+0x740>
    6a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a2d:	00 00 00 
    6a30:	ba 01 00 00 00       	mov    $0x1,%edx
    6a35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6a3a:	48 83 c5 08          	add    $0x8,%rbp
    6a3e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6a43:	e8 a8 c5 ff ff       	call   2ff0 <buf_put>
    6a48:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6a4d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    6a52:	4d 85 ed             	test   %r13,%r13
    6a55:	75 46                	jne    6a9d <fwp_write+0xbed>
    6a57:	e9 04 01 00 00       	jmp    6b60 <fwp_write+0xcb0>
    6a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a60:	41 80 f9 09          	cmp    $0x9,%r9b
    6a64:	0f 84 d6 00 00 00    	je     6b40 <fwp_write+0xc90>
    6a6a:	41 80 f9 0a          	cmp    $0xa,%r9b
    6a6e:	0f 85 9c 00 00 00    	jne    6b10 <fwp_write+0xc60>
    6a74:	ba 02 00 00 00       	mov    $0x2,%edx
    6a79:	48 8d 35 9a 16 00 00 	lea    0x169a(%rip),%rsi        # 811a <_IO_stdin_used+0x11a>
    6a80:	48 89 df             	mov    %rbx,%rdi
    6a83:	e8 68 c5 ff ff       	call   2ff0 <buf_put>
    6a88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a8f:	00 
    6a90:	48 83 c5 01          	add    $0x1,%rbp
    6a94:	49 39 ec             	cmp    %rbp,%r12
    6a97:	0f 84 c3 00 00 00    	je     6b60 <fwp_write+0xcb0>
    6a9d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    6aa2:	41 80 f9 0d          	cmp    $0xd,%r9b
    6aa6:	74 28                	je     6ad0 <fwp_write+0xc20>
    6aa8:	7e b6                	jle    6a60 <fwp_write+0xbb0>
    6aaa:	41 80 f9 22          	cmp    $0x22,%r9b
    6aae:	74 40                	je     6af0 <fwp_write+0xc40>
    6ab0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    6ab4:	75 5a                	jne    6b10 <fwp_write+0xc60>
    6ab6:	ba 02 00 00 00       	mov    $0x2,%edx
    6abb:	48 8d 35 55 16 00 00 	lea    0x1655(%rip),%rsi        # 8117 <_IO_stdin_used+0x117>
    6ac2:	48 89 df             	mov    %rbx,%rdi
    6ac5:	e8 26 c5 ff ff       	call   2ff0 <buf_put>
    6aca:	eb c4                	jmp    6a90 <fwp_write+0xbe0>
    6acc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ad0:	ba 02 00 00 00       	mov    $0x2,%edx
    6ad5:	48 8d 35 44 16 00 00 	lea    0x1644(%rip),%rsi        # 8120 <_IO_stdin_used+0x120>
    6adc:	48 89 df             	mov    %rbx,%rdi
    6adf:	e8 0c c5 ff ff       	call   2ff0 <buf_put>
    6ae4:	eb aa                	jmp    6a90 <fwp_write+0xbe0>
    6ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6aed:	00 00 00 
    6af0:	ba 02 00 00 00       	mov    $0x2,%edx
    6af5:	48 8d 35 18 16 00 00 	lea    0x1618(%rip),%rsi        # 8114 <_IO_stdin_used+0x114>
    6afc:	48 89 df             	mov    %rbx,%rdi
    6aff:	e8 ec c4 ff ff       	call   2ff0 <buf_put>
    6b04:	eb 8a                	jmp    6a90 <fwp_write+0xbe0>
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 
    6b10:	41 80 f9 1f          	cmp    $0x1f,%r9b
    6b14:	0f 86 2e 01 00 00    	jbe    6c48 <fwp_write+0xd98>
    6b1a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    6b1e:	0f 84 24 01 00 00    	je     6c48 <fwp_write+0xd98>
    6b24:	ba 01 00 00 00       	mov    $0x1,%edx
    6b29:	4c 89 fe             	mov    %r15,%rsi
    6b2c:	48 89 df             	mov    %rbx,%rdi
    6b2f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    6b34:	e8 b7 c4 ff ff       	call   2ff0 <buf_put>
    6b39:	e9 52 ff ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6b3e:	66 90                	xchg   %ax,%ax
    6b40:	ba 02 00 00 00       	mov    $0x2,%edx
    6b45:	48 8d 35 d1 15 00 00 	lea    0x15d1(%rip),%rsi        # 811d <_IO_stdin_used+0x11d>
    6b4c:	48 89 df             	mov    %rbx,%rdi
    6b4f:	e8 9c c4 ff ff       	call   2ff0 <buf_put>
    6b54:	e9 37 ff ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6b59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b60:	ba 01 00 00 00       	mov    $0x1,%edx
    6b65:	4c 89 fe             	mov    %r15,%rsi
    6b68:	48 89 df             	mov    %rbx,%rdi
    6b6b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6b70:	e8 7b c4 ff ff       	call   2ff0 <buf_put>
    6b75:	e9 cc f3 ff ff       	jmp    5f46 <fwp_write+0x96>
    6b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b80:	83 f8 04             	cmp    $0x4,%eax
    6b83:	0f 85 bb fb ff ff    	jne    6744 <fwp_write+0x894>
    6b89:	48 8b 04 24          	mov    (%rsp),%rax
    6b8d:	48 8b 40 08          	mov    0x8(%rax),%rax
    6b91:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6b96:	48 c1 e8 3f          	shr    $0x3f,%rax
    6b9a:	e9 96 fc ff ff       	jmp    6835 <fwp_write+0x985>
    6b9f:	90                   	nop
    6ba0:	8b 0c 24             	mov    (%rsp),%ecx
    6ba3:	31 c0                	xor    %eax,%eax
    6ba5:	85 c9                	test   %ecx,%ecx
    6ba7:	0f 98 c0             	sets   %al
    6baa:	e9 86 fc ff ff       	jmp    6835 <fwp_write+0x985>
    6baf:	90                   	nop
    6bb0:	48 f7 d8             	neg    %rax
    6bb3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    6bba:	00 
    6bbb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    6bc2:	2d 
    6bc3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6bca:	00 
    6bcb:	48 83 d2 00          	adc    $0x0,%rdx
    6bcf:	48 89 c6             	mov    %rax,%rsi
    6bd2:	48 f7 da             	neg    %rdx
    6bd5:	e8 26 be ff ff       	call   2a00 <fwp_fmt_u128>
    6bda:	e9 51 f3 ff ff       	jmp    5f30 <fwp_write+0x80>
    6bdf:	90                   	nop
    6be0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    6be5:	e9 c3 f5 ff ff       	jmp    61ad <fwp_write+0x2fd>
    6bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bf0:	4c 89 e9             	mov    %r13,%rcx
    6bf3:	48 c1 e1 04          	shl    $0x4,%rcx
    6bf7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    6bfc:	48 85 ff             	test   %rdi,%rdi
    6bff:	0f 89 eb f9 ff ff    	jns    65f0 <fwp_write+0x740>
    6c05:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6c09:	48 89 ce             	mov    %rcx,%rsi
    6c0c:	e9 df f9 ff ff       	jmp    65f0 <fwp_write+0x740>
    6c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c18:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6c1f:	00 
    6c20:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6c24:	e9 20 fa ff ff       	jmp    6649 <fwp_write+0x799>
    6c29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c30:	ba 02 00 00 00       	mov    $0x2,%edx
    6c35:	48 8d 35 a3 14 00 00 	lea    0x14a3(%rip),%rsi        # 80df <_IO_stdin_used+0xdf>
    6c3c:	e9 2d f7 ff ff       	jmp    636e <fwp_write+0x4be>
    6c41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c48:	4c 8d 05 d4 14 00 00 	lea    0x14d4(%rip),%r8        # 8123 <_IO_stdin_used+0x123>
    6c4f:	b9 10 00 00 00       	mov    $0x10,%ecx
    6c54:	31 c0                	xor    %eax,%eax
    6c56:	ba 02 00 00 00       	mov    $0x2,%edx
    6c5b:	be 10 00 00 00       	mov    $0x10,%esi
    6c60:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6c67:	00 
    6c68:	e8 23 b7 ff ff       	call   2390 <__snprintf_chk@plt>
    6c6d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6c74:	00 
    6c75:	e8 b6 b7 ff ff       	call   2430 <strlen@plt>
    6c7a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    6c81:	00 
    6c82:	48 89 df             	mov    %rbx,%rdi
    6c85:	48 89 c2             	mov    %rax,%rdx
    6c88:	e8 63 c3 ff ff       	call   2ff0 <buf_put>
    6c8d:	e9 fe fd ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c98:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6c9c:	48 8d 35 36 14 00 00 	lea    0x1436(%rip),%rsi        # 80d9 <_IO_stdin_used+0xd9>
    6ca3:	48 8d 05 2e 14 00 00 	lea    0x142e(%rip),%rax        # 80d8 <_IO_stdin_used+0xd8>
    6caa:	4c 89 e7             	mov    %r12,%rdi
    6cad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    6cb1:	48 0f 46 f0          	cmovbe %rax,%rsi
    6cb5:	e8 16 b7 ff ff       	call   23d0 <strcpy@plt>
    6cba:	e9 71 f2 ff ff       	jmp    5f30 <fwp_write+0x80>
    6cbf:	90                   	nop
    6cc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6cc4:	48 8d 35 0e 14 00 00 	lea    0x140e(%rip),%rsi        # 80d9 <_IO_stdin_used+0xd9>
    6ccb:	48 8d 05 06 14 00 00 	lea    0x1406(%rip),%rax        # 80d8 <_IO_stdin_used+0xd8>
    6cd2:	0f 2f c8             	comiss %xmm0,%xmm1
    6cd5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6cdc:	00 
    6cdd:	4c 89 e7             	mov    %r12,%rdi
    6ce0:	48 0f 46 f0          	cmovbe %rax,%rsi
    6ce4:	e8 e7 b6 ff ff       	call   23d0 <strcpy@plt>
    6ce9:	e9 42 f2 ff ff       	jmp    5f30 <fwp_write+0x80>
    6cee:	66 90                	xchg   %ax,%ax
    6cf0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    6cf5:	45 85 c0             	test   %r8d,%r8d
    6cf8:	75 34                	jne    6d2e <fwp_write+0xe7e>
    6cfa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6d01:	00 
    6d02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d09:	00 00 
    6d0b:	0f 85 74 f6 ff ff    	jne    6385 <fwp_write+0x4d5>
    6d11:	ba 02 00 00 00       	mov    $0x2,%edx
    6d16:	48 8d 35 37 14 00 00 	lea    0x1437(%rip),%rsi        # 8154 <_IO_stdin_used+0x154>
    6d1d:	e9 a1 f3 ff ff       	jmp    60c3 <fwp_write+0x213>
    6d22:	48 03 75 10          	add    0x10(%rbp),%rsi
    6d26:	49 89 f0             	mov    %rsi,%r8
    6d29:	e9 e5 fc ff ff       	jmp    6a13 <fwp_write+0xb63>
    6d2e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    6d33:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6d38:	85 ff                	test   %edi,%edi
    6d3a:	0f 84 fa f3 ff ff    	je     613a <fwp_write+0x28a>
    6d40:	ba 01 00 00 00       	mov    $0x1,%edx
    6d45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6d4a:	48 89 df             	mov    %rbx,%rdi
    6d4d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6d52:	e8 99 c2 ff ff       	call   2ff0 <buf_put>
    6d57:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    6d5c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6d61:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6d67:	85 c0                	test   %eax,%eax
    6d69:	0f 8f f0 f3 ff ff    	jg     615f <fwp_write+0x2af>
    6d6f:	e9 34 f4 ff ff       	jmp    61a8 <fwp_write+0x2f8>
    6d74:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6d78:	49 89 c5             	mov    %rax,%r13
    6d7b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6d80:	49 89 c4             	mov    %rax,%r12
    6d83:	49 c1 fd 3f          	sar    $0x3f,%r13
    6d87:	4c 09 e8             	or     %r13,%rax
    6d8a:	0f 84 a7 00 00 00    	je     6e37 <fwp_write+0xf87>
    6d90:	48 8d 2d 49 3d 00 00 	lea    0x3d49(%rip),%rbp        # aae0 <units.0>
    6d97:	4d 89 e7             	mov    %r12,%r15
    6d9a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6d9e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6da3:	4c 89 ff             	mov    %r15,%rdi
    6da6:	4c 89 ee             	mov    %r13,%rsi
    6da9:	44 89 0c 24          	mov    %r9d,(%rsp)
    6dad:	48 99                	cqto
    6daf:	48 89 d1             	mov    %rdx,%rcx
    6db2:	48 89 c2             	mov    %rax,%rdx
    6db5:	e8 36 0f 00 00       	call   7cf0 <__divmodti4>
    6dba:	44 8b 0c 24          	mov    (%rsp),%r9d
    6dbe:	48 89 c1             	mov    %rax,%rcx
    6dc1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6dc6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    6dcb:	0f 84 94 00 00 00    	je     6e65 <fwp_write+0xfb5>
    6dd1:	41 83 c1 01          	add    $0x1,%r9d
    6dd5:	48 83 c5 10          	add    $0x10,%rbp
    6dd9:	41 83 f9 05          	cmp    $0x5,%r9d
    6ddd:	75 bb                	jne    6d9a <fwp_write+0xeea>
    6ddf:	4d 85 ed             	test   %r13,%r13
    6de2:	79 53                	jns    6e37 <fwp_write+0xf87>
    6de4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6de9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    6dee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    6df3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6df8:	48 99                	cqto
    6dfa:	48 f7 d8             	neg    %rax
    6dfd:	48 83 d2 00          	adc    $0x0,%rdx
    6e01:	48 89 c6             	mov    %rax,%rsi
    6e04:	48 f7 da             	neg    %rdx
    6e07:	e8 f4 bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e0c:	49 89 e8             	mov    %rbp,%r8
    6e0f:	ba 00 02 00 00       	mov    $0x200,%edx
    6e14:	be 02 00 00 00       	mov    $0x2,%esi
    6e19:	31 c0                	xor    %eax,%eax
    6e1b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6e22:	00 
    6e23:	48 8d 0d 25 13 00 00 	lea    0x1325(%rip),%rcx        # 814f <_IO_stdin_used+0x14f>
    6e2a:	4c 89 e7             	mov    %r12,%rdi
    6e2d:	e8 6e b8 ff ff       	call   26a0 <__sprintf_chk@plt>
    6e32:	e9 f9 f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6e37:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6e3c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6e41:	31 d2                	xor    %edx,%edx
    6e43:	48 89 ef             	mov    %rbp,%rdi
    6e46:	e8 b5 bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e4b:	eb bf                	jmp    6e0c <fwp_write+0xf5c>
    6e4d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6e54:	4e 61 4e 00 
    6e58:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6e5f:	00 
    6e60:	e9 cb f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6e65:	44 89 0c 24          	mov    %r9d,(%rsp)
    6e69:	48 89 c8             	mov    %rcx,%rax
    6e6c:	48 85 d2             	test   %rdx,%rdx
    6e6f:	78 51                	js     6ec2 <fwp_write+0x1012>
    6e71:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6e76:	48 89 c6             	mov    %rax,%rsi
    6e79:	48 89 ef             	mov    %rbp,%rdi
    6e7c:	e8 7f bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e81:	44 8b 0c 24          	mov    (%rsp),%r9d
    6e85:	49 63 c1             	movslq %r9d,%rax
    6e88:	49 89 e8             	mov    %rbp,%r8
    6e8b:	ba 00 02 00 00       	mov    $0x200,%edx
    6e90:	be 02 00 00 00       	mov    $0x2,%esi
    6e95:	48 c1 e0 04          	shl    $0x4,%rax
    6e99:	48 8d 3d 40 3c 00 00 	lea    0x3c40(%rip),%rdi        # aae0 <units.0>
    6ea0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6ea7:	00 
    6ea8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    6eac:	48 8d 0d 97 12 00 00 	lea    0x1297(%rip),%rcx        # 814a <_IO_stdin_used+0x14a>
    6eb3:	4c 89 e7             	mov    %r12,%rdi
    6eb6:	31 c0                	xor    %eax,%eax
    6eb8:	e8 e3 b7 ff ff       	call   26a0 <__sprintf_chk@plt>
    6ebd:	e9 6e f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6ec2:	48 f7 d8             	neg    %rax
    6ec5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    6eca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    6ecf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6ed4:	48 83 d2 00          	adc    $0x0,%rdx
    6ed8:	48 89 c6             	mov    %rax,%rsi
    6edb:	48 f7 da             	neg    %rdx
    6ede:	e8 1d bb ff ff       	call   2a00 <fwp_fmt_u128>
    6ee3:	44 8b 0c 24          	mov    (%rsp),%r9d
    6ee7:	eb 9c                	jmp    6e85 <fwp_write+0xfd5>
    6ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006ef0 <f0>:
    6ef0:	41 57                	push   %r15
    6ef2:	41 56                	push   %r14
    6ef4:	4c 8d 35 e5 47 01 00 	lea    0x147e5(%rip),%r14        # 1b6e0 <fwp_heap>
    6efb:	41 55                	push   %r13
    6efd:	41 54                	push   %r12
    6eff:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    6f05:	55                   	push   %rbp
    6f06:	53                   	push   %rbx
    6f07:	31 db                	xor    %ebx,%ebx
    6f09:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
    6f10:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f17:	00 00 
    6f19:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    6f20:	00 
    6f21:	31 c0                	xor    %eax,%eax
    6f23:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    6f2a:	00 
    6f2b:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    6f32:	00 00 
    6f34:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6f39:	48 8d 05 50 ed ff ff 	lea    -0x12b0(%rip),%rax        # 5c90 <fwp_drop1>
    6f40:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6f45:	48 8b 05 24 64 01 00 	mov    0x16424(%rip),%rax        # 1d370 <fwp_cleanups>
    6f4c:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6f50:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6f55:	48 8d 05 34 bc ff ff 	lea    -0x43cc(%rip),%rax        # 2b90 <fwp_range_release>
    6f5c:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6f61:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    6f66:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6f6b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6f70:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    6f75:	48 89 05 f4 63 01 00 	mov    %rax,0x163f4(%rip)        # 1d370 <fwp_cleanups>
    6f7c:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    6f81:	eb 3e                	jmp    6fc1 <f0+0xd1>
    6f83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f88:	80 f9 01             	cmp    $0x1,%cl
    6f8b:	75 29                	jne    6fb6 <f0+0xc6>
    6f8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6f90:	0f b7 c0             	movzwl %ax,%eax
    6f93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6f96:	48 0f af c1          	imul   %rcx,%rax
    6f9a:	48 c1 e8 20          	shr    $0x20,%rax
    6f9e:	48 39 d0             	cmp    %rdx,%rax
    6fa1:	73 13                	jae    6fb6 <f0+0xc6>
    6fa3:	49 01 c5             	add    %rax,%r13
    6fa6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    6fab:	0f 84 97 05 00 00    	je     7548 <f0+0x658>
    6fb1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    6fb6:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    6fbb:	49 83 ec 01          	sub    $0x1,%r12
    6fbf:	72 7f                	jb     7040 <f0+0x150>
    6fc1:	48 89 ee             	mov    %rbp,%rsi
    6fc4:	bf 01 00 00 00       	mov    $0x1,%edi
    6fc9:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    6fd0:	00 
    6fd1:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    6fd6:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    6fdd:	00 
    6fde:	e8 ad e0 ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    6fe3:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    6fea:	48 89 c3             	mov    %rax,%rbx
    6fed:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    6ff4:	48 c1 e2 10          	shl    $0x10,%rdx
    6ff8:	48 39 d0             	cmp    %rdx,%rax
    6ffb:	73 b9                	jae    6fb6 <f0+0xc6>
    6ffd:	48 89 c2             	mov    %rax,%rdx
    7000:	48 c1 ea 10          	shr    $0x10,%rdx
    7004:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7008:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    700f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7013:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7017:	4d 85 ed             	test   %r13,%r13
    701a:	74 9a                	je     6fb6 <f0+0xc6>
    701c:	0f b6 0a             	movzbl (%rdx),%ecx
    701f:	80 f9 02             	cmp    $0x2,%cl
    7022:	0f 85 60 ff ff ff    	jne    6f88 <f0+0x98>
    7028:	66 85 c0             	test   %ax,%ax
    702b:	0f 84 75 ff ff ff    	je     6fa6 <f0+0xb6>
    7031:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    7036:	49 83 ec 01          	sub    $0x1,%r12
    703a:	73 85                	jae    6fc1 <f0+0xd1>
    703c:	0f 1f 40 00          	nopl   0x0(%rax)
    7040:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7045:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    704a:	bf 01 00 00 00       	mov    $0x1,%edi
    704f:	66 0f 6f 05 b9 14 00 	movdqa 0x14b9(%rip),%xmm0        # 8510 <msg.3+0xc0>
    7056:	00 
    7057:	48 89 05 12 63 01 00 	mov    %rax,0x16312(%rip)        # 1d370 <fwp_cleanups>
    705e:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
    7063:	e8 28 e0 ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    7068:	48 8b 15 49 5a 01 00 	mov    0x15a49(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    706f:	49 89 c5             	mov    %rax,%r13
    7072:	48 2b 05 17 5a 01 00 	sub    0x15a17(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    7079:	48 c1 e2 10          	shl    $0x10,%rdx
    707d:	48 39 d0             	cmp    %rdx,%rax
    7080:	73 59                	jae    70db <f0+0x1eb>
    7082:	48 89 c2             	mov    %rax,%rdx
    7085:	48 c1 ea 10          	shr    $0x10,%rdx
    7089:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    708d:	48 8b 15 44 5a 01 00 	mov    0x15a44(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    7094:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7098:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    709c:	4d 85 e4             	test   %r12,%r12
    709f:	74 3a                	je     70db <f0+0x1eb>
    70a1:	0f b6 0a             	movzbl (%rdx),%ecx
    70a4:	80 f9 02             	cmp    $0x2,%cl
    70a7:	0f 84 f3 04 00 00    	je     75a0 <f0+0x6b0>
    70ad:	80 f9 01             	cmp    $0x1,%cl
    70b0:	75 29                	jne    70db <f0+0x1eb>
    70b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    70b5:	0f b7 c0             	movzwl %ax,%eax
    70b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    70bb:	48 0f af c1          	imul   %rcx,%rax
    70bf:	48 c1 e8 20          	shr    $0x20,%rax
    70c3:	48 39 d0             	cmp    %rdx,%rax
    70c6:	73 13                	jae    70db <f0+0x1eb>
    70c8:	49 01 c4             	add    %rax,%r12
    70cb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    70d0:	0f 84 e5 04 00 00    	je     75bb <f0+0x6cb>
    70d6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    70db:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    70e0:	bf 01 00 00 00       	mov    $0x1,%edi
    70e5:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    70ea:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    70f1:	00 f0 3f 
    70f4:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    70f9:	e8 92 df ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    70fe:	48 8b 15 b3 59 01 00 	mov    0x159b3(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    7105:	49 89 c5             	mov    %rax,%r13
    7108:	48 2b 05 81 59 01 00 	sub    0x15981(%rip),%rax        # 1ca90 <fwp_heap+0x13b0>
    710f:	48 c1 e2 10          	shl    $0x10,%rdx
    7113:	48 39 d0             	cmp    %rdx,%rax
    7116:	73 59                	jae    7171 <f0+0x281>
    7118:	48 89 c2             	mov    %rax,%rdx
    711b:	48 c1 ea 10          	shr    $0x10,%rdx
    711f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7123:	48 8b 15 ae 59 01 00 	mov    0x159ae(%rip),%rdx        # 1cad8 <fwp_heap+0x13f8>
    712a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    712e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7132:	4d 85 e4             	test   %r12,%r12
    7135:	74 3a                	je     7171 <f0+0x281>
    7137:	0f b6 0a             	movzbl (%rdx),%ecx
    713a:	80 f9 02             	cmp    $0x2,%cl
    713d:	0f 84 4d 04 00 00    	je     7590 <f0+0x6a0>
    7143:	80 f9 01             	cmp    $0x1,%cl
    7146:	75 29                	jne    7171 <f0+0x281>
    7148:	8b 4a 18             	mov    0x18(%rdx),%ecx
    714b:	0f b7 c0             	movzwl %ax,%eax
    714e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7151:	48 0f af c1          	imul   %rcx,%rax
    7155:	48 c1 e8 20          	shr    $0x20,%rax
    7159:	48 39 d0             	cmp    %rdx,%rax
    715c:	73 13                	jae    7171 <f0+0x281>
    715e:	49 01 c4             	add    %rax,%r12
    7161:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7166:	0f 84 5c 04 00 00    	je     75c8 <f0+0x6d8>
    716c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7171:	48 89 ee             	mov    %rbp,%rsi
    7174:	bf 01 00 00 00       	mov    $0x1,%edi
    7179:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    7180:	33 f3 bf 
    7183:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    718a:	00 
    718b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    7192:	00 
    7193:	e8 f8 de ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    7198:	48 8b 15 19 59 01 00 	mov    0x15919(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    719f:	48 8b 0d ea 58 01 00 	mov    0x158ea(%rip),%rcx        # 1ca90 <fwp_heap+0x13b0>
    71a6:	48 89 c5             	mov    %rax,%rbp
    71a9:	48 89 d6             	mov    %rdx,%rsi
    71ac:	48 29 c8             	sub    %rcx,%rax
    71af:	48 c1 e6 10          	shl    $0x10,%rsi
    71b3:	48 39 f0             	cmp    %rsi,%rax
    71b6:	73 69                	jae    7221 <f0+0x331>
    71b8:	48 89 c6             	mov    %rax,%rsi
    71bb:	48 c1 ee 10          	shr    $0x10,%rsi
    71bf:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    71c3:	48 8b 35 0e 59 01 00 	mov    0x1590e(%rip),%rsi        # 1cad8 <fwp_heap+0x13f8>
    71ca:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    71ce:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    71d2:	4d 85 e4             	test   %r12,%r12
    71d5:	74 4a                	je     7221 <f0+0x331>
    71d7:	0f b6 3e             	movzbl (%rsi),%edi
    71da:	40 80 ff 02          	cmp    $0x2,%dil
    71de:	0f 84 9c 03 00 00    	je     7580 <f0+0x690>
    71e4:	40 80 ff 01          	cmp    $0x1,%dil
    71e8:	75 37                	jne    7221 <f0+0x331>
    71ea:	8b 7e 18             	mov    0x18(%rsi),%edi
    71ed:	0f b7 c0             	movzwl %ax,%eax
    71f0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71f3:	48 0f af c7          	imul   %rdi,%rax
    71f7:	48 c1 e8 20          	shr    $0x20,%rax
    71fb:	48 39 f0             	cmp    %rsi,%rax
    71fe:	73 21                	jae    7221 <f0+0x331>
    7200:	49 01 c4             	add    %rax,%r12
    7203:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    7208:	0f 84 a0 03 00 00    	je     75ae <f0+0x6be>
    720e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7213:	48 8b 0d 76 58 01 00 	mov    0x15876(%rip),%rcx        # 1ca90 <fwp_heap+0x13b0>
    721a:	48 8b 15 97 58 01 00 	mov    0x15897(%rip),%rdx        # 1cab8 <fwp_heap+0x13d8>
    7221:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7226:	e9 59 01 00 00       	jmp    7384 <f0+0x494>
    722b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7230:	49 8b 37             	mov    (%r15),%rsi
    7233:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
    7238:	48 f7 d6             	not    %rsi
    723b:	48 89 b0 c0 03 00 00 	mov    %rsi,0x3c0(%rax)
    7242:	31 f6                	xor    %esi,%esi
    7244:	4c 89 ff             	mov    %r15,%rdi
    7247:	e8 54 b2 ff ff       	call   24a0 <memset@plt>
    724c:	4c 89 e8             	mov    %r13,%rax
    724f:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    7256:	0f 82 85 03 00 00    	jb     75e1 <f0+0x6f1>
    725c:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    7263:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    726a:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
    726f:	73 07                	jae    7278 <f0+0x388>
    7271:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    7278:	66 0f ef c0          	pxor   %xmm0,%xmm0
    727c:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    7281:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    7288:	00 00 
    728a:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    7291:	00 00 
    7293:	4d 89 27             	mov    %r12,(%r15)
    7296:	4d 8d 6f 08          	lea    0x8(%r15),%r13
    729a:	4c 89 e2             	mov    %r12,%rdx
    729d:	4c 89 d6             	mov    %r10,%rsi
    72a0:	4c 89 ef             	mov    %r13,%rdi
    72a3:	e8 c8 b2 ff ff       	call   2570 <memcpy@plt>
    72a8:	43 c6 44 27 08 00    	movb   $0x0,0x8(%r15,%r12,1)
    72ae:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    72b3:	e8 e8 b0 ff ff       	call   23a0 <free@plt>
    72b8:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    72bf:	4c 89 f8             	mov    %r15,%rax
    72c2:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    72c9:	48 c1 e2 10          	shl    $0x10,%rdx
    72cd:	48 39 d0             	cmp    %rdx,%rax
    72d0:	73 55                	jae    7327 <f0+0x437>
    72d2:	48 89 c2             	mov    %rax,%rdx
    72d5:	48 c1 ea 10          	shr    $0x10,%rdx
    72d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72dd:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    72e4:	48 8d 34 ca          	lea    (%rdx,%rcx,8),%rsi
    72e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72ec:	48 85 c9             	test   %rcx,%rcx
    72ef:	74 36                	je     7327 <f0+0x437>
    72f1:	0f b6 16             	movzbl (%rsi),%edx
    72f4:	80 fa 02             	cmp    $0x2,%dl
    72f7:	0f 84 e3 01 00 00    	je     74e0 <f0+0x5f0>
    72fd:	80 fa 01             	cmp    $0x1,%dl
    7300:	75 25                	jne    7327 <f0+0x437>
    7302:	8b 56 18             	mov    0x18(%rsi),%edx
    7305:	0f b7 c0             	movzwl %ax,%eax
    7308:	48 0f af c2          	imul   %rdx,%rax
    730c:	8b 56 1c             	mov    0x1c(%rsi),%edx
    730f:	48 c1 e8 20          	shr    $0x20,%rax
    7313:	48 39 d0             	cmp    %rdx,%rax
    7316:	73 0f                	jae    7327 <f0+0x437>
    7318:	48 01 c1             	add    %rax,%rcx
    731b:	80 39 ff             	cmpb   $0xff,(%rcx)
    731e:	0f 84 34 02 00 00    	je     7558 <f0+0x668>
    7324:	c6 01 01             	movb   $0x1,(%rcx)
    7327:	48 89 ef             	mov    %rbp,%rdi
    732a:	e8 61 e7 ff ff       	call   5a90 <fwp_drop0>
    732f:	49 8b 17             	mov    (%r15),%rdx
    7332:	be 01 00 00 00       	mov    $0x1,%esi
    7337:	4c 89 ef             	mov    %r13,%rdi
    733a:	48 8b 0d f7 5f 01 00 	mov    0x15ff7(%rip),%rcx        # 1d338 <fwp_prog_out>
    7341:	e8 fa b2 ff ff       	call   2640 <fwrite@plt>
    7346:	48 8b 35 eb 5f 01 00 	mov    0x15feb(%rip),%rsi        # 1d338 <fwp_prog_out>
    734d:	bf 0a 00 00 00       	mov    $0xa,%edi
    7352:	e8 69 b1 ff ff       	call   24c0 <fputc@plt>
    7357:	4c 89 ff             	mov    %r15,%rdi
    735a:	e8 21 e1 ff ff       	call   5480 <fwp_drop4>
    735f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7364:	48 8b 40 10          	mov    0x10(%rax),%rax
    7368:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    736d:	48 85 c0             	test   %rax,%rax
    7370:	0f 84 7a 01 00 00    	je     74f0 <f0+0x600>
    7376:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    737d:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    7384:	48 89 e8             	mov    %rbp,%rax
    7387:	48 c1 e2 10          	shl    $0x10,%rdx
    738b:	48 29 c8             	sub    %rcx,%rax
    738e:	48 39 d0             	cmp    %rdx,%rax
    7391:	73 5d                	jae    73f0 <f0+0x500>
    7393:	48 89 c2             	mov    %rax,%rdx
    7396:	48 c1 ea 10          	shr    $0x10,%rdx
    739a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    739e:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    73a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73a9:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    73ad:	48 85 ff             	test   %rdi,%rdi
    73b0:	74 3e                	je     73f0 <f0+0x500>
    73b2:	0f b6 0a             	movzbl (%rdx),%ecx
    73b5:	80 f9 02             	cmp    $0x2,%cl
    73b8:	0f 84 12 01 00 00    	je     74d0 <f0+0x5e0>
    73be:	80 f9 01             	cmp    $0x1,%cl
    73c1:	75 2d                	jne    73f0 <f0+0x500>
    73c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73c6:	0f b7 c0             	movzwl %ax,%eax
    73c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73cc:	48 0f af c1          	imul   %rcx,%rax
    73d0:	48 c1 e8 20          	shr    $0x20,%rax
    73d4:	48 39 d0             	cmp    %rdx,%rax
    73d7:	73 17                	jae    73f0 <f0+0x500>
    73d9:	48 01 c7             	add    %rax,%rdi
    73dc:	0f b6 07             	movzbl (%rdi),%eax
    73df:	84 c0                	test   %al,%al
    73e1:	74 0d                	je     73f0 <f0+0x500>
    73e3:	3c fd                	cmp    $0xfd,%al
    73e5:	0f 87 85 01 00 00    	ja     7570 <f0+0x680>
    73eb:	83 c0 01             	add    $0x1,%eax
    73ee:	88 07                	mov    %al,(%rdi)
    73f0:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    73f5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    73f9:	b9 01 00 00 00       	mov    $0x1,%ecx
    73fe:	48 89 ee             	mov    %rbp,%rsi
    7401:	48 8d 15 b8 37 00 00 	lea    0x37b8(%rip),%rdx        # abc0 <d0>
    7408:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    740d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    7414:	00 00 
    7416:	e8 95 ea ff ff       	call   5eb0 <fwp_write>
    741b:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    7420:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
    7425:	48 8d 05 02 0c 00 00 	lea    0xc02(%rip),%rax        # 802e <_IO_stdin_used+0x2e>
    742c:	4d 85 d2             	test   %r10,%r10
    742f:	4c 0f 44 d0          	cmove  %rax,%r10
    7433:	49 83 fc f6          	cmp    $0xfffffffffffffff6,%r12
    7437:	0f 87 98 01 00 00    	ja     75d5 <f0+0x6e5>
    743d:	41 8b 86 a4 13 00 00 	mov    0x13a4(%r14),%eax
    7444:	49 8d 54 24 09       	lea    0x9(%r12),%rdx
    7449:	85 c0                	test   %eax,%eax
    744b:	74 5a                	je     74a7 <f0+0x5b7>
    744d:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    7454:	77 51                	ja     74a7 <f0+0x5b7>
    7456:	49 8d 44 24 18       	lea    0x18(%r12),%rax
    745b:	48 c1 e8 04          	shr    $0x4,%rax
    745f:	41 0f b6 84 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%eax
    7466:	00 00 
    7468:	45 8b ac 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r13d
    746f:	00 
    7470:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7474:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    7478:	4c 8b b8 c0 03 00 00 	mov    0x3c0(%rax),%r15
    747f:	4d 85 ff             	test   %r15,%r15
    7482:	0f 85 a8 fd ff ff    	jne    7230 <f0+0x340>
    7488:	4c 8b b8 c8 03 00 00 	mov    0x3c8(%rax),%r15
    748f:	4d 85 ff             	test   %r15,%r15
    7492:	74 13                	je     74a7 <f0+0x5b7>
    7494:	48 8b b0 d0 03 00 00 	mov    0x3d0(%rax),%rsi
    749b:	4c 29 fe             	sub    %r15,%rsi
    749e:	4c 39 ee             	cmp    %r13,%rsi
    74a1:	0f 83 89 00 00 00    	jae    7530 <f0+0x640>
    74a7:	be 01 00 00 00       	mov    $0x1,%esi
    74ac:	48 89 d7             	mov    %rdx,%rdi
    74af:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
    74b4:	e8 57 d0 ff ff       	call   4510 <fwp_heap_alloc_slow>
    74b9:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
    74be:	49 89 c7             	mov    %rax,%r15
    74c1:	e9 cd fd ff ff       	jmp    7293 <f0+0x3a3>
    74c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    74cd:	00 00 00 
    74d0:	66 85 c0             	test   %ax,%ax
    74d3:	0f 85 17 ff ff ff    	jne    73f0 <f0+0x500>
    74d9:	e9 fe fe ff ff       	jmp    73dc <f0+0x4ec>
    74de:	66 90                	xchg   %ax,%ax
    74e0:	66 85 c0             	test   %ax,%ax
    74e3:	0f 85 3e fe ff ff    	jne    7327 <f0+0x437>
    74e9:	e9 2d fe ff ff       	jmp    731b <f0+0x42b>
    74ee:	66 90                	xchg   %ax,%ax
    74f0:	48 89 ef             	mov    %rbp,%rdi
    74f3:	e8 98 e5 ff ff       	call   5a90 <fwp_drop0>
    74f8:	48 89 df             	mov    %rbx,%rdi
    74fb:	e8 90 e5 ff ff       	call   5a90 <fwp_drop0>
    7500:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
    7507:	00 
    7508:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    750f:	00 00 
    7511:	0f 85 cf 00 00 00    	jne    75e6 <f0+0x6f6>
    7517:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
    751e:	31 c0                	xor    %eax,%eax
    7520:	5b                   	pop    %rbx
    7521:	5d                   	pop    %rbp
    7522:	41 5c                	pop    %r12
    7524:	41 5d                	pop    %r13
    7526:	41 5e                	pop    %r14
    7528:	41 5f                	pop    %r15
    752a:	c3                   	ret
    752b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7530:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
    7534:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
    7539:	48 89 b0 c8 03 00 00 	mov    %rsi,0x3c8(%rax)
    7540:	e9 fd fc ff ff       	jmp    7242 <f0+0x352>
    7545:	0f 1f 00             	nopl   (%rax)
    7548:	4c 89 ef             	mov    %r13,%rdi
    754b:	e8 00 ca ff ff       	call   3f50 <fwp_rc_forget_slot>
    7550:	e9 5c fa ff ff       	jmp    6fb1 <f0+0xc1>
    7555:	0f 1f 00             	nopl   (%rax)
    7558:	48 89 cf             	mov    %rcx,%rdi
    755b:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    7560:	e8 eb c9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    7565:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    756a:	e9 b5 fd ff ff       	jmp    7324 <f0+0x434>
    756f:	90                   	nop
    7570:	e8 bb c8 ff ff       	call   3e30 <fwp_rc_wide_dup>
    7575:	e9 76 fe ff ff       	jmp    73f0 <f0+0x500>
    757a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7580:	66 85 c0             	test   %ax,%ax
    7583:	0f 85 98 fc ff ff    	jne    7221 <f0+0x331>
    7589:	e9 75 fc ff ff       	jmp    7203 <f0+0x313>
    758e:	66 90                	xchg   %ax,%ax
    7590:	66 85 c0             	test   %ax,%ax
    7593:	0f 85 d8 fb ff ff    	jne    7171 <f0+0x281>
    7599:	e9 c3 fb ff ff       	jmp    7161 <f0+0x271>
    759e:	66 90                	xchg   %ax,%ax
    75a0:	66 85 c0             	test   %ax,%ax
    75a3:	0f 85 32 fb ff ff    	jne    70db <f0+0x1eb>
    75a9:	e9 1d fb ff ff       	jmp    70cb <f0+0x1db>
    75ae:	4c 89 e7             	mov    %r12,%rdi
    75b1:	e8 9a c9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    75b6:	e9 53 fc ff ff       	jmp    720e <f0+0x31e>
    75bb:	4c 89 e7             	mov    %r12,%rdi
    75be:	e8 8d c9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    75c3:	e9 0e fb ff ff       	jmp    70d6 <f0+0x1e6>
    75c8:	4c 89 e7             	mov    %r12,%rdi
    75cb:	e8 80 c9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    75d0:	e9 97 fb ff ff       	jmp    716c <f0+0x27c>
    75d5:	48 8d 3d 7f 0b 00 00 	lea    0xb7f(%rip),%rdi        # 815b <_IO_stdin_used+0x15b>
    75dc:	e8 3f bb ff ff       	call   3120 <fwp_trap>
    75e1:	e8 8a b6 ff ff       	call   2c70 <fwp_heap_oom>
    75e6:	e8 55 ae ff ff       	call   2440 <__stack_chk_fail@plt>
    75eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000075f0 <fwp_main_thread>:
    75f0:	f3 0f 1e fa          	endbr64
    75f4:	41 54                	push   %r12
    75f6:	55                   	push   %rbp
    75f7:	53                   	push   %rbx
    75f8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    75ff:	8b 0d 7f 54 01 00    	mov    0x1547f(%rip),%ecx        # 1ca84 <fwp_heap+0x13a4>
    7605:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    760c:	00 00 
    760e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7615:	00 
    7616:	31 c0                	xor    %eax,%eax
    7618:	85 c9                	test   %ecx,%ecx
    761a:	0f 84 68 06 00 00    	je     7c88 <fwp_main_thread+0x698>
    7620:	8b 15 62 54 01 00    	mov    0x15462(%rip),%edx        # 1ca88 <fwp_heap+0x13a8>
    7626:	85 d2                	test   %edx,%edx
    7628:	0f 85 42 06 00 00    	jne    7c70 <fwp_main_thread+0x680>
    762e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    7633:	31 f6                	xor    %esi,%esi
    7635:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    763a:	48 c7 05 43 3a 01 00 	movq   $0x40000000,0x13a43(%rip)        # 1b088 <fwp_main_stack_size>
    7641:	00 00 00 40 
    7645:	48 89 05 44 3a 01 00 	mov    %rax,0x13a44(%rip)        # 1b090 <fwp_main_stack_top>
    764c:	48 8d 05 2d 3a 00 00 	lea    0x3a2d(%rip),%rax        # b080 <alt.4>
    7653:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    7658:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    765f:	01 00 
    7661:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    7668:	00 
    7669:	e8 12 b0 ff ff       	call   2680 <sigaltstack@plt>
    766e:	85 c0                	test   %eax,%eax
    7670:	0f 85 4a 06 00 00    	jne    7cc0 <fwp_main_thread+0x6d0>
    7676:	31 c0                	xor    %eax,%eax
    7678:	b9 12 00 00 00       	mov    $0x12,%ecx
    767d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    7682:	f3 48 ab             	rep stos %rax,(%rdi)
    7685:	48 8d 05 24 b6 ff ff 	lea    -0x49dc(%rip),%rax        # 2cb0 <fwp_segv>
    768c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    7691:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    7698:	04 00 00 08 
    769c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    76a1:	e8 aa ae ff ff       	call   2550 <sigemptyset@plt>
    76a6:	85 c0                	test   %eax,%eax
    76a8:	0f 85 12 06 00 00    	jne    7cc0 <fwp_main_thread+0x6d0>
    76ae:	31 d2                	xor    %edx,%edx
    76b0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    76b5:	bf 0b 00 00 00       	mov    $0xb,%edi
    76ba:	e8 21 ad ff ff       	call   23e0 <sigaction@plt>
    76bf:	85 c0                	test   %eax,%eax
    76c1:	0f 85 f9 05 00 00    	jne    7cc0 <fwp_main_thread+0x6d0>
    76c7:	31 d2                	xor    %edx,%edx
    76c9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    76ce:	bf 07 00 00 00       	mov    $0x7,%edi
    76d3:	e8 08 ad ff ff       	call   23e0 <sigaction@plt>
    76d8:	85 c0                	test   %eax,%eax
    76da:	0f 85 e0 05 00 00    	jne    7cc0 <fwp_main_thread+0x6d0>
    76e0:	8b 05 82 39 00 00    	mov    0x3982(%rip),%eax        # b068 <st.2>
    76e6:	85 c0                	test   %eax,%eax
    76e8:	0f 84 62 05 00 00    	je     7c50 <fwp_main_thread+0x660>
    76ee:	48 8b 2d cb 3f 01 00 	mov    0x13fcb(%rip),%rbp        # 1b6c0 <fwp_cur>
    76f5:	48 85 ed             	test   %rbp,%rbp
    76f8:	0f 84 72 03 00 00    	je     7a70 <fwp_main_thread+0x480>
    76fe:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    7703:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    7707:	48 89 eb             	mov    %rbp,%rbx
    770a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    770f:	0f 84 41 01 00 00    	je     7856 <fwp_main_thread+0x266>
    7715:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    771a:	0f 84 80 02 00 00    	je     79a0 <fwp_main_thread+0x3b0>
    7720:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    7724:	0f 84 66 02 00 00    	je     7990 <fwp_main_thread+0x3a0>
    772a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    772e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    7732:	0f 85 e8 02 00 00    	jne    7a20 <fwp_main_thread+0x430>
    7738:	48 8b 43 60          	mov    0x60(%rbx),%rax
    773c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    7743:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    7747:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    774e:	00 00 00 00 
    7752:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    7759:	48 85 d2             	test   %rdx,%rdx
    775c:	74 07                	je     7765 <fwp_main_thread+0x175>
    775e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    7765:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7769:	48 85 c0             	test   %rax,%rax
    776c:	74 34                	je     77a2 <fwp_main_thread+0x1b2>
    776e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    7772:	48 8b 05 1f 3f 01 00 	mov    0x13f1f(%rip),%rax        # 1b698 <fwp_timers>
    7779:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    777d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    7784:	00 00 00 00 
    7788:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    778f:	48 85 c0             	test   %rax,%rax
    7792:	74 07                	je     779b <fwp_main_thread+0x1ab>
    7794:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    779b:	48 89 1d f6 3e 01 00 	mov    %rbx,0x13ef6(%rip)        # 1b698 <fwp_timers>
    77a2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    77a6:	e8 45 d3 ff ff       	call   4af0 <fwp_block>
    77ab:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    77b2:	48 85 c9             	test   %rcx,%rcx
    77b5:	74 47                	je     77fe <fwp_main_thread+0x20e>
    77b7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    77be:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    77c5:	48 85 d2             	test   %rdx,%rdx
    77c8:	0f 84 92 02 00 00    	je     7a60 <fwp_main_thread+0x470>
    77ce:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    77d5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    77dc:	48 85 c0             	test   %rax,%rax
    77df:	74 07                	je     77e8 <fwp_main_thread+0x1f8>
    77e1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    77e8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    77ef:	00 00 00 00 
    77f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77f7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    77fe:	48 8b 0d bb 3e 01 00 	mov    0x13ebb(%rip),%rcx        # 1b6c0 <fwp_cur>
    7805:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    7809:	0f 84 01 02 00 00    	je     7a10 <fwp_main_thread+0x420>
    780f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    7816:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    781d:	48 85 d2             	test   %rdx,%rdx
    7820:	0f 84 fa 03 00 00    	je     7c20 <fwp_main_thread+0x630>
    7826:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    782d:	48 85 c0             	test   %rax,%rax
    7830:	74 07                	je     7839 <fwp_main_thread+0x249>
    7832:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    7839:	66 0f ef c9          	pxor   %xmm1,%xmm1
    783d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    7841:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    7848:	48 89 cb             	mov    %rcx,%rbx
    784b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    7850:	0f 85 bf fe ff ff    	jne    7715 <fwp_main_thread+0x125>
    7856:	48 83 3d f2 5a 01 00 	cmpq   $0x0,0x15af2(%rip)        # 1d350 <fwp_state_len>
    785d:	00 
    785e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    7862:	0f 84 ba 00 00 00    	je     7922 <fwp_main_thread+0x332>
    7868:	48 39 1d 49 3e 01 00 	cmp    %rbx,0x13e49(%rip)        # 1b6b8 <fwp_root>
    786f:	c7 05 07 38 01 00 00 	movl   $0x0,0x13807(%rip)        # 1b080 <fwp_exit_code>
    7876:	00 00 00 
    7879:	0f 85 5f 04 00 00    	jne    7cde <fwp_main_thread+0x6ee>
    787f:	48 85 db             	test   %rbx,%rbx
    7882:	0f 84 0e 02 00 00    	je     7a96 <fwp_main_thread+0x4a6>
    7888:	48 8b 15 f9 3d 01 00 	mov    0x13df9(%rip),%rdx        # 1b688 <fwp_tasks_active>
    788f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    7893:	48 85 d2             	test   %rdx,%rdx
    7896:	0f 84 fa 01 00 00    	je     7a96 <fwp_main_thread+0x4a6>
    789c:	0f 1f 40 00          	nopl   0x0(%rax)
    78a0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    78a4:	75 08                	jne    78ae <fwp_main_thread+0x2be>
    78a6:	48 89 d7             	mov    %rdx,%rdi
    78a9:	e8 82 b7 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    78ae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    78b5:	48 85 d2             	test   %rdx,%rdx
    78b8:	75 e6                	jne    78a0 <fwp_main_thread+0x2b0>
    78ba:	eb 31                	jmp    78ed <fwp_main_thread+0x2fd>
    78bc:	0f 1f 40 00          	nopl   0x0(%rax)
    78c0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    78c7:	48 89 1d d2 3d 01 00 	mov    %rbx,0x13dd2(%rip)        # 1b6a0 <fwp_ready_tail>
    78ce:	e8 1d d2 ff ff       	call   4af0 <fwp_block>
    78d3:	e8 18 d0 ff ff       	call   48f0 <fwp_free_zombie>
    78d8:	48 83 3d a8 3d 01 00 	cmpq   $0x0,0x13da8(%rip)        # 1b688 <fwp_tasks_active>
    78df:	00 
    78e0:	0f 84 b0 01 00 00    	je     7a96 <fwp_main_thread+0x4a6>
    78e6:	48 8b 1d cb 3d 01 00 	mov    0x13dcb(%rip),%rbx        # 1b6b8 <fwp_root>
    78ed:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    78f1:	75 db                	jne    78ce <fwp_main_thread+0x2de>
    78f3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    78f7:	75 d5                	jne    78ce <fwp_main_thread+0x2de>
    78f9:	48 8b 05 a0 3d 01 00 	mov    0x13da0(%rip),%rax        # 1b6a0 <fwp_ready_tail>
    7900:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    7904:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    790b:	00 00 00 00 
    790f:	48 85 c0             	test   %rax,%rax
    7912:	75 ac                	jne    78c0 <fwp_main_thread+0x2d0>
    7914:	48 89 1d 8d 3d 01 00 	mov    %rbx,0x13d8d(%rip)        # 1b6a8 <fwp_ready_head>
    791b:	eb aa                	jmp    78c7 <fwp_main_thread+0x2d7>
    791d:	0f 1f 00             	nopl   (%rax)
    7920:	31 db                	xor    %ebx,%ebx
    7922:	48 83 3d 16 5a 01 00 	cmpq   $0x0,0x15a16(%rip)        # 1d340 <fwp_state_owners>
    7929:	00 
    792a:	0f 85 38 ff ff ff    	jne    7868 <fwp_main_thread+0x278>
    7930:	48 8b 3d 21 5a 01 00 	mov    0x15a21(%rip),%rdi        # 1d358 <fwp_state>
    7937:	e8 54 c8 ff ff       	call   4190 <fwp_mem_free>
    793c:	48 c7 05 11 5a 01 00 	movq   $0x0,0x15a11(%rip)        # 1d358 <fwp_state>
    7943:	00 00 00 00 
    7947:	48 c7 05 f6 59 01 00 	movq   $0x0,0x159f6(%rip)        # 1d348 <fwp_state_cap>
    794e:	00 00 00 00 
    7952:	48 85 db             	test   %rbx,%rbx
    7955:	0f 84 46 03 00 00    	je     7ca1 <fwp_main_thread+0x6b1>
    795b:	48 39 1d 56 3d 01 00 	cmp    %rbx,0x13d56(%rip)        # 1b6b8 <fwp_root>
    7962:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    7969:	00 00 00 00 
    796d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    7974:	00 00 00 00 
    7978:	c7 05 fe 36 01 00 00 	movl   $0x0,0x136fe(%rip)        # 1b080 <fwp_exit_code>
    797f:	00 00 00 
    7982:	0f 84 00 ff ff ff    	je     7888 <fwp_main_thread+0x298>
    7988:	e9 7e ad ff ff       	jmp    270b <fwp_main_thread.cold>
    798d:	0f 1f 00             	nopl   (%rax)
    7990:	e8 bb b7 ff ff       	call   3150 <fwp_now_ns>
    7995:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    7999:	0f 8d 91 02 00 00    	jge    7c30 <fwp_main_thread+0x640>
    799f:	90                   	nop
    79a0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    79a4:	0f 85 80 fd ff ff    	jne    772a <fwp_main_thread+0x13a>
    79aa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    79ae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    79b2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    79b6:	0f 85 80 fd ff ff    	jne    773c <fwp_main_thread+0x14c>
    79bc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    79c0:	48 85 c9             	test   %rcx,%rcx
    79c3:	0f 84 73 fd ff ff    	je     773c <fwp_main_thread+0x14c>
    79c9:	48 85 c0             	test   %rax,%rax
    79cc:	0f 84 ff 02 00 00    	je     7cd1 <fwp_main_thread+0x6e1>
    79d2:	48 39 c8             	cmp    %rcx,%rax
    79d5:	48 0f 4f c1          	cmovg  %rcx,%rax
    79d9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    79e0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    79e4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    79eb:	00 00 00 00 
    79ef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    79f6:	48 85 d2             	test   %rdx,%rdx
    79f9:	74 07                	je     7a02 <fwp_main_thread+0x412>
    79fb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    7a02:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7a06:	e9 63 fd ff ff       	jmp    776e <fwp_main_thread+0x17e>
    7a0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a10:	48 89 cb             	mov    %rcx,%rbx
    7a13:	e9 f2 fc ff ff       	jmp    770a <fwp_main_thread+0x11a>
    7a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7a1f:	00 
    7a20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    7a24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    7a2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    7a32:	00 00 00 00 
    7a36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    7a3d:	48 85 c0             	test   %rax,%rax
    7a40:	0f 84 52 02 00 00    	je     7c98 <fwp_main_thread+0x6a8>
    7a46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    7a4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7a51:	e9 4c fd ff ff       	jmp    77a2 <fwp_main_thread+0x1b2>
    7a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a5d:	00 00 00 
    7a60:	48 89 01             	mov    %rax,(%rcx)
    7a63:	e9 74 fd ff ff       	jmp    77dc <fwp_main_thread+0x1ec>
    7a68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7a6f:	00 
    7a70:	48 83 3d d8 58 01 00 	cmpq   $0x0,0x158d8(%rip)        # 1d350 <fwp_state_len>
    7a77:	00 
    7a78:	0f 84 a2 fe ff ff    	je     7920 <fwp_main_thread+0x330>
    7a7e:	48 83 3d 32 3c 01 00 	cmpq   $0x0,0x13c32(%rip)        # 1b6b8 <fwp_root>
    7a85:	00 
    7a86:	c7 05 f0 35 01 00 00 	movl   $0x0,0x135f0(%rip)        # 1b080 <fwp_exit_code>
    7a8d:	00 00 00 
    7a90:	0f 85 43 02 00 00    	jne    7cd9 <fwp_main_thread+0x6e9>
    7a96:	e8 55 ce ff ff       	call   48f0 <fwp_free_zombie>
    7a9b:	48 83 3d 05 3c 01 00 	cmpq   $0x0,0x13c05(%rip)        # 1b6a8 <fwp_ready_head>
    7aa2:	00 
    7aa3:	0f 85 62 ac ff ff    	jne    270b <fwp_main_thread.cold>
    7aa9:	48 83 3d e7 3b 01 00 	cmpq   $0x0,0x13be7(%rip)        # 1b698 <fwp_timers>
    7ab0:	00 
    7ab1:	0f 85 54 ac ff ff    	jne    270b <fwp_main_thread.cold>
    7ab7:	8b 1d df 35 01 00    	mov    0x135df(%rip),%ebx        # 1b09c <fwp_stack_pool_n>
    7abd:	85 db                	test   %ebx,%ebx
    7abf:	74 36                	je     7af7 <fwp_main_thread+0x507>
    7ac1:	83 eb 01             	sub    $0x1,%ebx
    7ac4:	48 8d 05 d5 35 01 00 	lea    0x135d5(%rip),%rax        # 1b0a0 <fwp_stack_pool>
    7acb:	48 63 d3             	movslq %ebx,%rdx
    7ace:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    7ad2:	eb 07                	jmp    7adb <fwp_main_thread+0x4eb>
    7ad4:	0f 1f 40 00          	nopl   0x0(%rax)
    7ad8:	83 eb 01             	sub    $0x1,%ebx
    7adb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    7adf:	be 00 00 00 10       	mov    $0x10000000,%esi
    7ae4:	89 1d b2 35 01 00    	mov    %ebx,0x135b2(%rip)        # 1b09c <fwp_stack_pool_n>
    7aea:	48 83 ed 08          	sub    $0x8,%rbp
    7aee:	e8 bd aa ff ff       	call   25b0 <munmap@plt>
    7af3:	85 db                	test   %ebx,%ebx
    7af5:	75 e1                	jne    7ad8 <fwp_main_thread+0x4e8>
    7af7:	8b 3d 13 35 00 00    	mov    0x3513(%rip),%edi        # b010 <fwp_epfd>
    7afd:	85 ff                	test   %edi,%edi
    7aff:	78 05                	js     7b06 <fwp_main_thread+0x516>
    7b01:	e8 aa a9 ff ff       	call   24b0 <close@plt>
    7b06:	4c 8b 25 93 37 01 00 	mov    0x13793(%rip),%r12        # 1b2a0 <fwp_nfdws>
    7b0d:	48 8b 2d 94 37 01 00 	mov    0x13794(%rip),%rbp        # 1b2a8 <fwp_fdws>
    7b14:	31 db                	xor    %ebx,%ebx
    7b16:	c7 05 f0 34 00 00 ff 	movl   $0xffffffff,0x34f0(%rip)        # b010 <fwp_epfd>
    7b1d:	ff ff ff 
    7b20:	4d 85 e4             	test   %r12,%r12
    7b23:	74 38                	je     7b5d <fwp_main_thread+0x56d>
    7b25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b2c:	00 00 00 00 
    7b30:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    7b35:	48 85 ff             	test   %rdi,%rdi
    7b38:	74 1a                	je     7b54 <fwp_main_thread+0x564>
    7b3a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7b3e:	0f 85 c7 ab ff ff    	jne    270b <fwp_main_thread.cold>
    7b44:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    7b49:	0f 85 bc ab ff ff    	jne    270b <fwp_main_thread.cold>
    7b4f:	e8 3c c6 ff ff       	call   4190 <fwp_mem_free>
    7b54:	48 83 c3 01          	add    $0x1,%rbx
    7b58:	4c 39 e3             	cmp    %r12,%rbx
    7b5b:	75 d3                	jne    7b30 <fwp_main_thread+0x540>
    7b5d:	48 89 ef             	mov    %rbp,%rdi
    7b60:	e8 2b c6 ff ff       	call   4190 <fwp_mem_free>
    7b65:	48 8b 15 4c 3b 01 00 	mov    0x13b4c(%rip),%rdx        # 1b6b8 <fwp_root>
    7b6c:	48 c7 05 31 37 01 00 	movq   $0x0,0x13731(%rip)        # 1b2a8 <fwp_fdws>
    7b73:	00 00 00 00 
    7b77:	48 c7 05 1e 37 01 00 	movq   $0x0,0x1371e(%rip)        # 1b2a0 <fwp_nfdws>
    7b7e:	00 00 00 00 
    7b82:	48 85 d2             	test   %rdx,%rdx
    7b85:	74 4e                	je     7bd5 <fwp_main_thread+0x5e5>
    7b87:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    7b8c:	0f 85 79 ab ff ff    	jne    270b <fwp_main_thread.cold>
    7b92:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    7b99:	00 
    7b9a:	0f 85 6b ab ff ff    	jne    270b <fwp_main_thread.cold>
    7ba0:	48 83 3d a8 57 01 00 	cmpq   $0x0,0x157a8(%rip)        # 1d350 <fwp_state_len>
    7ba7:	00 
    7ba8:	0f 85 5d ab ff ff    	jne    270b <fwp_main_thread.cold>
    7bae:	48 83 3d 8a 57 01 00 	cmpq   $0x0,0x1578a(%rip)        # 1d340 <fwp_state_owners>
    7bb5:	00 
    7bb6:	0f 85 4f ab ff ff    	jne    270b <fwp_main_thread.cold>
    7bbc:	b9 79 00 00 00       	mov    $0x79,%ecx
    7bc1:	31 c0                	xor    %eax,%eax
    7bc3:	48 8d 3d f6 36 01 00 	lea    0x136f6(%rip),%rdi        # 1b2c0 <fwp_root_context>
    7bca:	f3 48 ab             	rep stos %rax,(%rdi)
    7bcd:	48 89 d7             	mov    %rdx,%rdi
    7bd0:	e8 bb c5 ff ff       	call   4190 <fwp_mem_free>
    7bd5:	48 8b 3d 44 34 00 00 	mov    0x3444(%rip),%rdi        # b020 <stdout@GLIBC_2.2.5>
    7bdc:	48 c7 05 d9 3a 01 00 	movq   $0x0,0x13ad9(%rip)        # 1b6c0 <fwp_cur>
    7be3:	00 00 00 00 
    7be7:	48 c7 05 c6 3a 01 00 	movq   $0x0,0x13ac6(%rip)        # 1b6b8 <fwp_root>
    7bee:	00 00 00 00 
    7bf2:	e8 99 a9 ff ff       	call   2590 <fflush@plt>
    7bf7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    7bfe:	00 
    7bff:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7c06:	00 00 
    7c08:	0f 85 be 00 00 00    	jne    7ccc <fwp_main_thread+0x6dc>
    7c0e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    7c15:	31 c0                	xor    %eax,%eax
    7c17:	5b                   	pop    %rbx
    7c18:	5d                   	pop    %rbp
    7c19:	41 5c                	pop    %r12
    7c1b:	c3                   	ret
    7c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c20:	48 89 05 71 3a 01 00 	mov    %rax,0x13a71(%rip)        # 1b698 <fwp_timers>
    7c27:	e9 01 fc ff ff       	jmp    782d <fwp_main_thread+0x23d>
    7c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c30:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    7c34:	0f 85 66 fd ff ff    	jne    79a0 <fwp_main_thread+0x3b0>
    7c3a:	48 89 ef             	mov    %rbp,%rdi
    7c3d:	e8 ee b3 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    7c42:	e9 59 fd ff ff       	jmp    79a0 <fwp_main_thread+0x3b0>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	e8 9b f2 ff ff       	call   6ef0 <f0>
    7c55:	48 c7 05 00 34 00 00 	movq   $0x0,0x3400(%rip)        # b060 <v.1>
    7c5c:	00 00 00 00 
    7c60:	c7 05 fe 33 00 00 01 	movl   $0x1,0x33fe(%rip)        # b068 <st.2>
    7c67:	00 00 00 
    7c6a:	e9 7f fa ff ff       	jmp    76ee <fwp_main_thread+0xfe>
    7c6f:	90                   	nop
    7c70:	48 8d 3d e9 ba ff ff 	lea    -0x4517(%rip),%rdi        # 3760 <fwp_heap_report>
    7c77:	e8 84 02 00 00       	call   7f00 <atexit>
    7c7c:	e9 ad f9 ff ff       	jmp    762e <fwp_main_thread+0x3e>
    7c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c88:	e8 e3 bb ff ff       	call   3870 <fwp_heap_init>
    7c8d:	e9 8e f9 ff ff       	jmp    7620 <fwp_main_thread+0x30>
    7c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c98:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    7c9c:	e9 01 fb ff ff       	jmp    77a2 <fwp_main_thread+0x1b2>
    7ca1:	48 83 3d 0f 3a 01 00 	cmpq   $0x0,0x13a0f(%rip)        # 1b6b8 <fwp_root>
    7ca8:	00 
    7ca9:	c7 05 cd 33 01 00 00 	movl   $0x0,0x133cd(%rip)        # 1b080 <fwp_exit_code>
    7cb0:	00 00 00 
    7cb3:	0f 84 dd fd ff ff    	je     7a96 <fwp_main_thread+0x4a6>
    7cb9:	e9 4d aa ff ff       	jmp    270b <fwp_main_thread.cold>
    7cbe:	66 90                	xchg   %ax,%ax
    7cc0:	48 8d 3d 41 06 00 00 	lea    0x641(%rip),%rdi        # 8308 <_IO_stdin_used+0x308>
    7cc7:	e8 54 b4 ff ff       	call   3120 <fwp_trap>
    7ccc:	e8 6f a7 ff ff       	call   2440 <__stack_chk_fail@plt>
    7cd1:	48 89 c8             	mov    %rcx,%rax
    7cd4:	e9 00 fd ff ff       	jmp    79d9 <fwp_main_thread+0x3e9>
    7cd9:	e9 2d aa ff ff       	jmp    270b <fwp_main_thread.cold>
    7cde:	e9 28 aa ff ff       	jmp    270b <fwp_main_thread.cold>
    7ce3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cea:	00 00 00 
    7ced:	0f 1f 00             	nopl   (%rax)

0000000000007cf0 <__divmodti4>:
    7cf0:	f3 0f 1e fa          	endbr64
    7cf4:	55                   	push   %rbp
    7cf5:	49 89 f1             	mov    %rsi,%r9
    7cf8:	49 89 d2             	mov    %rdx,%r10
    7cfb:	48 89 fe             	mov    %rdi,%rsi
    7cfe:	49 89 cb             	mov    %rcx,%r11
    7d01:	48 89 e5             	mov    %rsp,%rbp
    7d04:	41 57                	push   %r15
    7d06:	41 56                	push   %r14
    7d08:	41 55                	push   %r13
    7d0a:	41 54                	push   %r12
    7d0c:	53                   	push   %rbx
    7d0d:	4c 89 c3             	mov    %r8,%rbx
    7d10:	45 31 c0             	xor    %r8d,%r8d
    7d13:	4d 85 c9             	test   %r9,%r9
    7d16:	79 12                	jns    7d2a <__divmodti4+0x3a>
    7d18:	31 ff                	xor    %edi,%edi
    7d1a:	48 f7 de             	neg    %rsi
    7d1d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    7d24:	4c 19 cf             	sbb    %r9,%rdi
    7d27:	49 89 f9             	mov    %rdi,%r9
    7d2a:	4c 89 d8             	mov    %r11,%rax
    7d2d:	4d 85 db             	test   %r11,%r11
    7d30:	0f 88 1a 01 00 00    	js     7e50 <__divmodti4+0x160>
    7d36:	4c 89 d9             	mov    %r11,%rcx
    7d39:	49 89 f3             	mov    %rsi,%r11
    7d3c:	75 62                	jne    7da0 <__divmodti4+0xb0>
    7d3e:	4d 89 c4             	mov    %r8,%r12
    7d41:	4d 39 d1             	cmp    %r10,%r9
    7d44:	0f 83 46 01 00 00    	jae    7e90 <__divmodti4+0x1a0>
    7d4a:	4c 89 d8             	mov    %r11,%rax
    7d4d:	4c 89 ca             	mov    %r9,%rdx
    7d50:	49 f7 f2             	div    %r10
    7d53:	49 89 c3             	mov    %rax,%r11
    7d56:	31 c0                	xor    %eax,%eax
    7d58:	48 89 d6             	mov    %rdx,%rsi
    7d5b:	31 ff                	xor    %edi,%edi
    7d5d:	4c 89 d9             	mov    %r11,%rcx
    7d60:	48 89 c2             	mov    %rax,%rdx
    7d63:	48 89 c8             	mov    %rcx,%rax
    7d66:	4d 85 e4             	test   %r12,%r12
    7d69:	74 0a                	je     7d75 <__divmodti4+0x85>
    7d6b:	48 f7 d8             	neg    %rax
    7d6e:	48 83 d2 00          	adc    $0x0,%rdx
    7d72:	48 f7 da             	neg    %rdx
    7d75:	4d 85 c0             	test   %r8,%r8
    7d78:	74 0a                	je     7d84 <__divmodti4+0x94>
    7d7a:	48 f7 de             	neg    %rsi
    7d7d:	48 83 d7 00          	adc    $0x0,%rdi
    7d81:	48 f7 df             	neg    %rdi
    7d84:	48 89 33             	mov    %rsi,(%rbx)
    7d87:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    7d8b:	5b                   	pop    %rbx
    7d8c:	41 5c                	pop    %r12
    7d8e:	41 5d                	pop    %r13
    7d90:	41 5e                	pop    %r14
    7d92:	41 5f                	pop    %r15
    7d94:	5d                   	pop    %rbp
    7d95:	c3                   	ret
    7d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d9d:	00 00 00 
    7da0:	4d 89 c4             	mov    %r8,%r12
    7da3:	49 39 c1             	cmp    %rax,%r9
    7da6:	0f 82 ce 00 00 00    	jb     7e7a <__divmodti4+0x18a>
    7dac:	31 ff                	xor    %edi,%edi
    7dae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    7db3:	48 63 c7             	movslq %edi,%rax
    7db6:	be 40 00 00 00       	mov    $0x40,%esi
    7dbb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    7dc0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    7dc5:	48 29 c6             	sub    %rax,%rsi
    7dc8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    7dcd:	48 09 c8             	or     %rcx,%rax
    7dd0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    7dd5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    7dda:	49 89 c6             	mov    %rax,%r14
    7ddd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    7de1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    7de6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    7deb:	49 09 c1             	or     %rax,%r9
    7dee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    7df2:	4c 89 c8             	mov    %r9,%rax
    7df5:	49 f7 f6             	div    %r14
    7df8:	48 89 d1             	mov    %rdx,%rcx
    7dfb:	49 89 c3             	mov    %rax,%r11
    7dfe:	49 89 c1             	mov    %rax,%r9
    7e01:	49 f7 e2             	mul    %r10
    7e04:	49 89 c6             	mov    %rax,%r14
    7e07:	49 89 d2             	mov    %rdx,%r10
    7e0a:	48 39 d1             	cmp    %rdx,%rcx
    7e0d:	72 07                	jb     7e16 <__divmodti4+0x126>
    7e0f:	75 17                	jne    7e28 <__divmodti4+0x138>
    7e11:	49 39 c7             	cmp    %rax,%r15
    7e14:	73 12                	jae    7e28 <__divmodti4+0x138>
    7e16:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    7e1a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    7e1e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    7e22:	49 89 d2             	mov    %rdx,%r10
    7e25:	49 89 c6             	mov    %rax,%r14
    7e28:	4c 89 f8             	mov    %r15,%rax
    7e2b:	4c 29 f0             	sub    %r14,%rax
    7e2e:	4c 19 d1             	sbb    %r10,%rcx
    7e31:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    7e36:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    7e3b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    7e40:	48 09 c6             	or     %rax,%rsi
    7e43:	48 89 cf             	mov    %rcx,%rdi
    7e46:	31 c0                	xor    %eax,%eax
    7e48:	4c 89 c9             	mov    %r9,%rcx
    7e4b:	e9 10 ff ff ff       	jmp    7d60 <__divmodti4+0x70>
    7e50:	4c 89 d0             	mov    %r10,%rax
    7e53:	4c 89 da             	mov    %r11,%rdx
    7e56:	4d 89 c4             	mov    %r8,%r12
    7e59:	49 89 f3             	mov    %rsi,%r11
    7e5c:	48 f7 d8             	neg    %rax
    7e5f:	49 f7 d4             	not    %r12
    7e62:	48 83 d2 00          	adc    $0x0,%rdx
    7e66:	49 89 c2             	mov    %rax,%r10
    7e69:	48 f7 da             	neg    %rdx
    7e6c:	48 89 d1             	mov    %rdx,%rcx
    7e6f:	0f 84 cc fe ff ff    	je     7d41 <__divmodti4+0x51>
    7e75:	49 39 d1             	cmp    %rdx,%r9
    7e78:	73 46                	jae    7ec0 <__divmodti4+0x1d0>
    7e7a:	4c 89 cf             	mov    %r9,%rdi
    7e7d:	31 c0                	xor    %eax,%eax
    7e7f:	31 c9                	xor    %ecx,%ecx
    7e81:	e9 da fe ff ff       	jmp    7d60 <__divmodti4+0x70>
    7e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e8d:	00 00 00 
    7e90:	4d 85 d2             	test   %r10,%r10
    7e93:	75 0d                	jne    7ea2 <__divmodti4+0x1b2>
    7e95:	b8 01 00 00 00       	mov    $0x1,%eax
    7e9a:	31 d2                	xor    %edx,%edx
    7e9c:	49 f7 f2             	div    %r10
    7e9f:	49 89 c2             	mov    %rax,%r10
    7ea2:	4c 89 c8             	mov    %r9,%rax
    7ea5:	31 d2                	xor    %edx,%edx
    7ea7:	49 f7 f2             	div    %r10
    7eaa:	49 89 c1             	mov    %rax,%r9
    7ead:	4c 89 d8             	mov    %r11,%rax
    7eb0:	49 f7 f2             	div    %r10
    7eb3:	49 89 c3             	mov    %rax,%r11
    7eb6:	4c 89 c8             	mov    %r9,%rax
    7eb9:	e9 9a fe ff ff       	jmp    7d58 <__divmodti4+0x68>
    7ebe:	66 90                	xchg   %ax,%ax
    7ec0:	45 31 f6             	xor    %r14d,%r14d
    7ec3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    7ec8:	44 89 f7             	mov    %r14d,%edi
    7ecb:	45 85 f6             	test   %r14d,%r14d
    7ece:	0f 85 df fe ff ff    	jne    7db3 <__divmodti4+0xc3>
    7ed4:	4c 39 ca             	cmp    %r9,%rdx
    7ed7:	72 17                	jb     7ef0 <__divmodti4+0x200>
    7ed9:	31 c9                	xor    %ecx,%ecx
    7edb:	48 39 c6             	cmp    %rax,%rsi
    7ede:	73 10                	jae    7ef0 <__divmodti4+0x200>
    7ee0:	4c 89 cf             	mov    %r9,%rdi
    7ee3:	31 c0                	xor    %eax,%eax
    7ee5:	e9 76 fe ff ff       	jmp    7d60 <__divmodti4+0x70>
    7eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ef0:	4c 89 de             	mov    %r11,%rsi
    7ef3:	b9 01 00 00 00       	mov    $0x1,%ecx
    7ef8:	48 29 c6             	sub    %rax,%rsi
    7efb:	49 19 d1             	sbb    %rdx,%r9
    7efe:	eb e0                	jmp    7ee0 <__divmodti4+0x1f0>

0000000000007f00 <atexit>:
    7f00:	f3 0f 1e fa          	endbr64
    7f04:	48 8b 15 fd 30 00 00 	mov    0x30fd(%rip),%rdx        # b008 <__dso_handle>
    7f0b:	31 f6                	xor    %esi,%esi
    7f0d:	e9 0e a7 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000007f14 <_fini>:
    7f14:	f3 0f 1e fa          	endbr64
    7f18:	48 83 ec 08          	sub    $0x8,%rsp
    7f1c:	48 83 c4 08          	add    $0x8,%rsp
    7f20:	c3                   	ret
