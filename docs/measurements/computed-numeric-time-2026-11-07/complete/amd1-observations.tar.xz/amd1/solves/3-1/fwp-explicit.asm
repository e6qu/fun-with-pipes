
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c1 9f 00 00 	mov    0x9fc1(%rip),%rax        # bfd0 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 ea 9d 00 00    	push   0x9dea(%rip)        # be10 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 ec 9d 00 00    	jmp    *0x9dec(%rip)        # be18 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 66 9c 00 00    	jmp    *0x9c66(%rip)        # bfe0 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 96 9a 00 00    	jmp    *0x9a96(%rip)        # be20 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 8e 9a 00 00    	jmp    *0x9a8e(%rip)        # be28 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 86 9a 00 00    	jmp    *0x9a86(%rip)        # be30 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 7e 9a 00 00    	jmp    *0x9a7e(%rip)        # be38 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 76 9a 00 00    	jmp    *0x9a76(%rip)        # be40 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 6e 9a 00 00    	jmp    *0x9a6e(%rip)        # be48 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 66 9a 00 00    	jmp    *0x9a66(%rip)        # be50 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 5e 9a 00 00    	jmp    *0x9a5e(%rip)        # be58 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 56 9a 00 00    	jmp    *0x9a56(%rip)        # be60 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 4e 9a 00 00    	jmp    *0x9a4e(%rip)        # be68 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 46 9a 00 00    	jmp    *0x9a46(%rip)        # be70 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 3e 9a 00 00    	jmp    *0x9a3e(%rip)        # be78 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 36 9a 00 00    	jmp    *0x9a36(%rip)        # be80 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 2e 9a 00 00    	jmp    *0x9a2e(%rip)        # be88 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 26 9a 00 00    	jmp    *0x9a26(%rip)        # be90 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 1e 9a 00 00    	jmp    *0x9a1e(%rip)        # be98 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 16 9a 00 00    	jmp    *0x9a16(%rip)        # bea0 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 0e 9a 00 00    	jmp    *0x9a0e(%rip)        # bea8 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 06 9a 00 00    	jmp    *0x9a06(%rip)        # beb0 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 fe 99 00 00    	jmp    *0x99fe(%rip)        # beb8 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 f6 99 00 00    	jmp    *0x99f6(%rip)        # bec0 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 ee 99 00 00    	jmp    *0x99ee(%rip)        # bec8 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 e6 99 00 00    	jmp    *0x99e6(%rip)        # bed0 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 de 99 00 00    	jmp    *0x99de(%rip)        # bed8 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 d6 99 00 00    	jmp    *0x99d6(%rip)        # bee0 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 ce 99 00 00    	jmp    *0x99ce(%rip)        # bee8 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 c6 99 00 00    	jmp    *0x99c6(%rip)        # bef0 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 be 99 00 00    	jmp    *0x99be(%rip)        # bef8 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 b6 99 00 00    	jmp    *0x99b6(%rip)        # bf00 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 ae 99 00 00    	jmp    *0x99ae(%rip)        # bf08 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 a6 99 00 00    	jmp    *0x99a6(%rip)        # bf10 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 9e 99 00 00    	jmp    *0x999e(%rip)        # bf18 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 96 99 00 00    	jmp    *0x9996(%rip)        # bf20 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 8e 99 00 00    	jmp    *0x998e(%rip)        # bf28 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 86 99 00 00    	jmp    *0x9986(%rip)        # bf30 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 7e 99 00 00    	jmp    *0x997e(%rip)        # bf38 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 76 99 00 00    	jmp    *0x9976(%rip)        # bf40 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 6e 99 00 00    	jmp    *0x996e(%rip)        # bf48 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 66 99 00 00    	jmp    *0x9966(%rip)        # bf50 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 5e 99 00 00    	jmp    *0x995e(%rip)        # bf58 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 56 99 00 00    	jmp    *0x9956(%rip)        # bf60 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 4e 99 00 00    	jmp    *0x994e(%rip)        # bf68 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 46 99 00 00    	jmp    *0x9946(%rip)        # bf70 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 3e 99 00 00    	jmp    *0x993e(%rip)        # bf78 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 36 99 00 00    	jmp    *0x9936(%rip)        # bf80 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 2e 99 00 00    	jmp    *0x992e(%rip)        # bf88 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 26 99 00 00    	jmp    *0x9926(%rip)        # bf90 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 1e 99 00 00    	jmp    *0x991e(%rip)        # bf98 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 16 99 00 00    	jmp    *0x9916(%rip)        # bfa0 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 0e 99 00 00    	jmp    *0x990e(%rip)        # bfa8 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 06 99 00 00    	jmp    *0x9906(%rip)        # bfb0 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 fe 98 00 00    	jmp    *0x98fe(%rip)        # bfb8 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 69 00 00 	lea    0x69a0(%rip),%r9        # 9077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 69 00 00 	lea    0x699d(%rip),%r8        # 907b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 1a 0a 00 00       	call   3120 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 98 00 00 	mov    0x98e1(%rip),%rax        # c020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 f2 bb 01 00 	mov    %rax,0x1bbf2(%rip)        # 1e338 <fwp_prog_out>
    2746:	e8 05 0a 00 00       	call   3150 <fwp_now_ns>
    274b:	48 8d 3d 1a 6a 00 00 	lea    0x6a1a(%rip),%rdi        # 916c <_IO_stdin_used+0x16c>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 98 00 00 	mov    0x9866(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 fd 58 00 00 	lea    0x58fd(%rip),%rdx        # 8110 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d d1 97 00 00 	mov    0x97d1(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 98 01 00    	mov    0x19826(%rip),%eax        # 1c080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d ca 68 00 00 	lea    0x68ca(%rip),%rdi        # 9175 <_IO_stdin_used+0x175>
    28ab:	e8 70 08 00 00       	call   3120 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d f4 6a 00 00 	lea    0x6af4(%rip),%rdi        # 93b0 <_IO_stdin_used+0x3b0>
    28bc:	e8 5f 08 00 00       	call   3120 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d ae 6a 00 00 	lea    0x6aae(%rip),%rdi        # 9388 <_IO_stdin_used+0x388>
    28da:	e8 41 08 00 00       	call   3120 <fwp_trap>
    28df:	48 8d 3d 72 6a 00 00 	lea    0x6a72(%rip),%rdi        # 9358 <_IO_stdin_used+0x358>
    28e6:	e8 35 08 00 00       	call   3120 <fwp_trap>
    28eb:	48 8d 3d 3e 6a 00 00 	lea    0x6a3e(%rip),%rdi        # 9330 <_IO_stdin_used+0x330>
    28f2:	e8 29 08 00 00       	call   3120 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 9b 96 00 00    	call   *0x969b(%rip)        # bfc0 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 96 00 00 	lea    0x96e1(%rip),%rdi        # c018 <__TMC_END__>
    2937:	48 8d 05 da 96 00 00 	lea    0x96da(%rip),%rax        # c018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 7e 96 00 00 	mov    0x967e(%rip),%rax        # bfc8 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 96 00 00 	lea    0x96b1(%rip),%rdi        # c018 <__TMC_END__>
    2967:	48 8d 35 aa 96 00 00 	lea    0x96aa(%rip),%rsi        # c018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 4d 96 00 00 	mov    0x964d(%rip),%rax        # bfd8 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d 96 00 00 00 	cmpb   $0x0,0x969d(%rip)        # c048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 2a 96 00 00 	cmpq   $0x0,0x962a(%rip)        # bfe0 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 96 00 00 	mov    0x9646(%rip),%rdi        # c008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 96 00 00 01 	movb   $0x1,0x9675(%rip)        # c048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_owned_entry32>:
    2bc0:	f3 0f 1e fa          	endbr64
    2bc4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bc9:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    2bcd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2bd2:	c3                   	ret
    2bd3:	66 90                	xchg   %ax,%ax
    2bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bdc:	00 00 00 00 

0000000000002be0 <fwp_args32>:
    2be0:	f3 0f 1e fa          	endbr64
    2be4:	c3                   	ret
    2be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bec:	00 00 00 00 

0000000000002bf0 <fwp_owned_entry45>:
    2bf0:	f3 0f 1e fa          	endbr64
    2bf4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bf9:	f2 0f 58 07          	addsd  (%rdi),%xmm0
    2bfd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c02:	c3                   	ret
    2c03:	66 90                	xchg   %ax,%ax
    2c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c0c:	00 00 00 00 

0000000000002c10 <fwp_owned_entry69>:
    2c10:	f3 0f 1e fa          	endbr64
    2c14:	f2 0f 10 05 54 68 00 	movsd  0x6854(%rip),%xmm0        # 9470 <msg.3+0x20>
    2c1b:	00 
    2c1c:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    2c20:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c25:	c3                   	ret
    2c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2c2d:	00 00 00 

0000000000002c30 <fwp_flush>:
    2c30:	48 8b 3d 01 b7 01 00 	mov    0x1b701(%rip),%rdi        # 1e338 <fwp_prog_out>
    2c37:	48 85 ff             	test   %rdi,%rdi
    2c3a:	74 1c                	je     2c58 <fwp_flush+0x28>
    2c3c:	48 83 ec 08          	sub    $0x8,%rsp
    2c40:	e8 4b f9 ff ff       	call   2590 <fflush@plt>
    2c45:	48 8b 3d d4 93 00 00 	mov    0x93d4(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    2c4c:	48 83 c4 08          	add    $0x8,%rsp
    2c50:	e9 3b f9 ff ff       	jmp    2590 <fflush@plt>
    2c55:	0f 1f 00             	nopl   (%rax)
    2c58:	48 8b 3d c1 93 00 00 	mov    0x93c1(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    2c5f:	e9 2c f9 ff ff       	jmp    2590 <fflush@plt>
    2c64:	90                   	nop
    2c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c6c:	00 00 00 00 

0000000000002c70 <fwp_heap_oom>:
    2c70:	50                   	push   %rax
    2c71:	58                   	pop    %rax
    2c72:	ba 13 00 00 00       	mov    $0x13,%edx
    2c77:	be 01 00 00 00       	mov    $0x1,%esi
    2c7c:	48 8d 3d 85 63 00 00 	lea    0x6385(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    2c83:	48 83 ec 08          	sub    $0x8,%rsp
    2c87:	48 8b 0d b2 93 00 00 	mov    0x93b2(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    2c8e:	e8 ad f9 ff ff       	call   2640 <fwrite@plt>
    2c93:	31 ff                	xor    %edi,%edi
    2c95:	e8 f6 f8 ff ff       	call   2590 <fflush@plt>
    2c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c9f:	e8 bc f9 ff ff       	call   2660 <_Exit@plt>
    2ca4:	90                   	nop
    2ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cac:	00 00 00 00 

0000000000002cb0 <fwp_segv>:
    2cb0:	f3 0f 1e fa          	endbr64
    2cb4:	48 83 ec 28          	sub    $0x28,%rsp
    2cb8:	48 8b 05 01 9a 01 00 	mov    0x19a01(%rip),%rax        # 1c6c0 <fwp_cur>
    2cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2cc3:	41 89 f8             	mov    %edi,%r8d
    2cc6:	48 85 c0             	test   %rax,%rax
    2cc9:	74 6d                	je     2d38 <fwp_segv+0x88>
    2ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2ccf:	48 85 d2             	test   %rdx,%rdx
    2cd2:	74 64                	je     2d38 <fwp_segv+0x88>
    2cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2ce7:	e8 14 f9 ff ff       	call   2600 <sysconf@plt>
    2cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2cfb:	48 01 d0             	add    %rdx,%rax
    2cfe:	48 39 c1             	cmp    %rax,%rcx
    2d01:	b8 00 00 00 00       	mov    $0x0,%eax
    2d06:	40 0f 92 c6          	setb   %sil
    2d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    2d15:	31 c0                	xor    %eax,%eax
    2d17:	48 39 d1             	cmp    %rdx,%rcx
    2d1a:	0f 93 c0             	setae  %al
    2d1d:	21 f0                	and    %esi,%eax
    2d1f:	85 c0                	test   %eax,%eax
    2d21:	75 4a                	jne    2d6d <fwp_segv+0xbd>
    2d23:	31 f6                	xor    %esi,%esi
    2d25:	44 89 c7             	mov    %r8d,%edi
    2d28:	48 83 c4 28          	add    $0x28,%rsp
    2d2c:	e9 ef f7 ff ff       	jmp    2520 <signal@plt>
    2d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2d38:	48 8b 05 51 93 01 00 	mov    0x19351(%rip),%rax        # 1c090 <fwp_main_stack_top>
    2d3f:	48 85 c0             	test   %rax,%rax
    2d42:	74 df                	je     2d23 <fwp_segv+0x73>
    2d44:	48 2b 05 3d 93 01 00 	sub    0x1933d(%rip),%rax        # 1c088 <fwp_main_stack_size>
    2d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2d52:	48 39 d1             	cmp    %rdx,%rcx
    2d55:	0f 93 c2             	setae  %dl
    2d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    2d5e:	48 39 c1             	cmp    %rax,%rcx
    2d61:	0f 92 c0             	setb   %al
    2d64:	0f b6 c0             	movzbl %al,%eax
    2d67:	21 d0                	and    %edx,%eax
    2d69:	85 c0                	test   %eax,%eax
    2d6b:	74 b6                	je     2d23 <fwp_segv+0x73>
    2d6d:	e8 be fe ff ff       	call   2c30 <fwp_flush>
    2d72:	bf 02 00 00 00       	mov    $0x2,%edi
    2d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d7c:	48 8d 35 cd 66 00 00 	lea    0x66cd(%rip),%rsi        # 9450 <msg.3>
    2d83:	e8 88 f6 ff ff       	call   2410 <write@plt>
    2d88:	bf 65 00 00 00       	mov    $0x65,%edi
    2d8d:	e8 2e f6 ff ff       	call   23c0 <_exit@plt>
    2d92:	0f 1f 00             	nopl   (%rax)
    2d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d9c:	00 00 00 00 

0000000000002da0 <fwp_heap_chunks>:
    2da0:	41 54                	push   %r12
    2da2:	55                   	push   %rbp
    2da3:	53                   	push   %rbx
    2da4:	48 83 ff 01          	cmp    $0x1,%rdi
    2da8:	0f 84 62 01 00 00    	je     2f10 <fwp_heap_chunks+0x170>
    2dae:	48 8b 05 1b ad 01 00 	mov    0x1ad1b(%rip),%rax        # 1dad0 <fwp_heap+0x13f0>
    2db5:	4c 8d 05 14 ad 01 00 	lea    0x1ad14(%rip),%r8        # 1dad0 <fwp_heap+0x13f0>
    2dbc:	48 8b 1d f5 ac 01 00 	mov    0x1acf5(%rip),%rbx        # 1dab8 <fwp_heap+0x13d8>
    2dc3:	48 39 d8             	cmp    %rbx,%rax
    2dc6:	0f 83 57 01 00 00    	jae    2f23 <fwp_heap_chunks+0x183>
    2dcc:	48 8b 0d 05 ad 01 00 	mov    0x1ad05(%rip),%rcx        # 1dad8 <fwp_heap+0x13f8>
    2dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2dd7:	31 f6                	xor    %esi,%esi
    2dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2ddd:	eb 1e                	jmp    2dfd <fwp_heap_chunks+0x5d>
    2ddf:	90                   	nop
    2de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2de4:	48 39 cf             	cmp    %rcx,%rdi
    2de7:	0f 84 03 01 00 00    	je     2ef0 <fwp_heap_chunks+0x150>
    2ded:	48 83 c0 01          	add    $0x1,%rax
    2df1:	48 89 ce             	mov    %rcx,%rsi
    2df4:	48 83 c2 28          	add    $0x28,%rdx
    2df8:	48 39 c3             	cmp    %rax,%rbx
    2dfb:	74 14                	je     2e11 <fwp_heap_chunks+0x71>
    2dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    2e00:	74 de                	je     2de0 <fwp_heap_chunks+0x40>
    2e02:	48 83 c0 01          	add    $0x1,%rax
    2e06:	31 f6                	xor    %esi,%esi
    2e08:	48 83 c2 28          	add    $0x28,%rdx
    2e0c:	48 39 c3             	cmp    %rax,%rbx
    2e0f:	75 ec                	jne    2dfd <fwp_heap_chunks+0x5d>
    2e11:	48 29 f3             	sub    %rsi,%rbx
    2e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2e18:	48 8b 3d a1 ac 01 00 	mov    0x1aca1(%rip),%rdi        # 1dac0 <fwp_heap+0x13e0>
    2e1f:	48 29 35 ea ac 01 00 	sub    %rsi,0x1acea(%rip)        # 1db10 <fwp_heap+0x1430>
    2e26:	48 39 ef             	cmp    %rbp,%rdi
    2e29:	0f 83 96 00 00 00    	jae    2ec5 <fwp_heap_chunks+0x125>
    2e2f:	48 8b 05 7a ac 01 00 	mov    0x1ac7a(%rip),%rax        # 1dab0 <fwp_heap+0x13d0>
    2e36:	48 39 e8             	cmp    %rbp,%rax
    2e39:	0f 82 eb 00 00 00    	jb     2f2a <fwp_heap_chunks+0x18a>
    2e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2e43:	ba 03 00 00 00       	mov    $0x3,%edx
    2e48:	49 39 c4             	cmp    %rax,%r12
    2e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    2e4f:	4c 89 e6             	mov    %r12,%rsi
    2e52:	48 29 fe             	sub    %rdi,%rsi
    2e55:	48 c1 e7 10          	shl    $0x10,%rdi
    2e59:	48 03 3d 30 ac 01 00 	add    0x1ac30(%rip),%rdi        # 1da90 <fwp_heap+0x13b0>
    2e60:	48 c1 e6 10          	shl    $0x10,%rsi
    2e64:	e8 77 f7 ff ff       	call   25e0 <mprotect@plt>
    2e69:	85 c0                	test   %eax,%eax
    2e6b:	0f 85 b9 00 00 00    	jne    2f2a <fwp_heap_chunks+0x18a>
    2e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e76:	e8 85 f7 ff ff       	call   2600 <sysconf@plt>
    2e7b:	48 8b 35 3e ac 01 00 	mov    0x1ac3e(%rip),%rsi        # 1dac0 <fwp_heap+0x13e0>
    2e82:	48 89 c1             	mov    %rax,%rcx
    2e85:	48 8b 05 4c ac 01 00 	mov    0x1ac4c(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    2e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e90:	48 89 ca             	mov    %rcx,%rdx
    2e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e9b:	48 f7 da             	neg    %rdx
    2e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2ea3:	48 21 d7             	and    %rdx,%rdi
    2ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2eaa:	48 21 d6             	and    %rdx,%rsi
    2ead:	ba 03 00 00 00       	mov    $0x3,%edx
    2eb2:	48 29 fe             	sub    %rdi,%rsi
    2eb5:	e8 26 f7 ff ff       	call   25e0 <mprotect@plt>
    2eba:	85 c0                	test   %eax,%eax
    2ebc:	75 6c                	jne    2f2a <fwp_heap_chunks+0x18a>
    2ebe:	4c 89 25 fb ab 01 00 	mov    %r12,0x1abfb(%rip)        # 1dac0 <fwp_heap+0x13e0>
    2ec5:	48 89 ef             	mov    %rbp,%rdi
    2ec8:	48 89 2d e9 ab 01 00 	mov    %rbp,0x1abe9(%rip)        # 1dab8 <fwp_heap+0x13d8>
    2ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    2ed3:	48 39 3d ce ab 01 00 	cmp    %rdi,0x1abce(%rip)        # 1daa8 <fwp_heap+0x13c8>
    2eda:	73 07                	jae    2ee3 <fwp_heap_chunks+0x143>
    2edc:	48 89 3d c5 ab 01 00 	mov    %rdi,0x1abc5(%rip)        # 1daa8 <fwp_heap+0x13c8>
    2ee3:	48 89 d8             	mov    %rbx,%rax
    2ee6:	5b                   	pop    %rbx
    2ee7:	5d                   	pop    %rbp
    2ee8:	41 5c                	pop    %r12
    2eea:	c3                   	ret
    2eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2ef4:	48 29 f0             	sub    %rsi,%rax
    2ef7:	48 89 c3             	mov    %rax,%rbx
    2efa:	49 89 10             	mov    %rdx,(%r8)
    2efd:	48 89 d8             	mov    %rbx,%rax
    2f00:	48 29 3d 09 ac 01 00 	sub    %rdi,0x1ac09(%rip)        # 1db10 <fwp_heap+0x1430>
    2f07:	5b                   	pop    %rbx
    2f08:	5d                   	pop    %rbp
    2f09:	41 5c                	pop    %r12
    2f0b:	c3                   	ret
    2f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    2f10:	48 8b 05 b1 ab 01 00 	mov    0x1abb1(%rip),%rax        # 1dac8 <fwp_heap+0x13e8>
    2f17:	4c 8d 05 aa ab 01 00 	lea    0x1abaa(%rip),%r8        # 1dac8 <fwp_heap+0x13e8>
    2f1e:	e9 99 fe ff ff       	jmp    2dbc <fwp_heap_chunks+0x1c>
    2f23:	31 f6                	xor    %esi,%esi
    2f25:	e9 ea fe ff ff       	jmp    2e14 <fwp_heap_chunks+0x74>
    2f2a:	e8 41 fd ff ff       	call   2c70 <fwp_heap_oom>
    2f2f:	90                   	nop

0000000000002f30 <buf_grow>:
    2f30:	48 83 ec 18          	sub    $0x18,%rsp
    2f34:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2f38:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2f3c:	74 7e                	je     2fbc <buf_grow+0x8c>
    2f3e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f45:	48 29 c2             	sub    %rax,%rdx
    2f48:	48 39 f2             	cmp    %rsi,%rdx
    2f4b:	72 6f                	jb     2fbc <buf_grow+0x8c>
    2f4d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f52:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f56:	48 89 f9             	mov    %rdi,%rcx
    2f59:	48 39 d0             	cmp    %rdx,%rax
    2f5c:	73 48                	jae    2fa6 <buf_grow+0x76>
    2f5e:	48 85 c0             	test   %rax,%rax
    2f61:	75 15                	jne    2f78 <buf_grow+0x48>
    2f63:	48 83 fa 40          	cmp    $0x40,%rdx
    2f67:	76 4c                	jbe    2fb5 <buf_grow+0x85>
    2f69:	b8 40 00 00 00       	mov    $0x40,%eax
    2f6e:	eb 08                	jmp    2f78 <buf_grow+0x48>
    2f70:	48 01 c0             	add    %rax,%rax
    2f73:	48 39 d0             	cmp    %rdx,%rax
    2f76:	73 38                	jae    2fb0 <buf_grow+0x80>
    2f78:	48 85 c0             	test   %rax,%rax
    2f7b:	79 f3                	jns    2f70 <buf_grow+0x40>
    2f7d:	48 8b 39             	mov    (%rcx),%rdi
    2f80:	48 89 d6             	mov    %rdx,%rsi
    2f83:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f88:	48 89 14 24          	mov    %rdx,(%rsp)
    2f8c:	e8 0f f6 ff ff       	call   25a0 <realloc@plt>
    2f91:	48 8b 14 24          	mov    (%rsp),%rdx
    2f95:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f9a:	48 85 c0             	test   %rax,%rax
    2f9d:	74 1d                	je     2fbc <buf_grow+0x8c>
    2f9f:	48 89 01             	mov    %rax,(%rcx)
    2fa2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2fa6:	48 83 c4 18          	add    $0x18,%rsp
    2faa:	c3                   	ret
    2fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fb0:	48 89 c2             	mov    %rax,%rdx
    2fb3:	eb c8                	jmp    2f7d <buf_grow+0x4d>
    2fb5:	ba 40 00 00 00       	mov    $0x40,%edx
    2fba:	eb c1                	jmp    2f7d <buf_grow+0x4d>
    2fbc:	48 8b 0d 7d 90 00 00 	mov    0x907d(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    2fc3:	ba 13 00 00 00       	mov    $0x13,%edx
    2fc8:	be 01 00 00 00       	mov    $0x1,%esi
    2fcd:	48 8d 3d 34 60 00 00 	lea    0x6034(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    2fd4:	e8 67 f6 ff ff       	call   2640 <fwrite@plt>
    2fd9:	31 ff                	xor    %edi,%edi
    2fdb:	e8 b0 f5 ff ff       	call   2590 <fflush@plt>
    2fe0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fe5:	e8 76 f6 ff ff       	call   2660 <_Exit@plt>
    2fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002ff0 <buf_put>:
    2ff0:	41 54                	push   %r12
    2ff2:	49 89 f4             	mov    %rsi,%r12
    2ff5:	48 89 d6             	mov    %rdx,%rsi
    2ff8:	55                   	push   %rbp
    2ff9:	48 89 fd             	mov    %rdi,%rbp
    2ffc:	53                   	push   %rbx
    2ffd:	48 89 d3             	mov    %rdx,%rbx
    3000:	e8 2b ff ff ff       	call   2f30 <buf_grow>
    3005:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    3009:	48 89 da             	mov    %rbx,%rdx
    300c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    3010:	4c 89 e6             	mov    %r12,%rsi
    3013:	e8 58 f5 ff ff       	call   2570 <memcpy@plt>
    3018:	48 8b 45 00          	mov    0x0(%rbp),%rax
    301c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    3020:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    3024:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    3028:	5b                   	pop    %rbx
    3029:	5d                   	pop    %rbp
    302a:	41 5c                	pop    %r12
    302c:	c3                   	ret
    302d:	0f 1f 00             	nopl   (%rax)

0000000000003030 <fwp_cancel_tree.part.0>:
    3030:	48 3b 3d 89 96 01 00 	cmp    0x19689(%rip),%rdi        # 1c6c0 <fwp_cur>
    3037:	53                   	push   %rbx
    3038:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    303c:	74 35                	je     3073 <fwp_cancel_tree.part.0+0x43>
    303e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3042:	75 2f                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    3044:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3048:	75 29                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    304a:	48 8b 05 4f 96 01 00 	mov    0x1964f(%rip),%rax        # 1c6a0 <fwp_ready_tail>
    3051:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3055:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    305c:	00 00 00 00 
    3060:	48 85 c0             	test   %rax,%rax
    3063:	74 33                	je     3098 <fwp_cancel_tree.part.0+0x68>
    3065:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    306c:	48 89 3d 2d 96 01 00 	mov    %rdi,0x1962d(%rip)        # 1c6a0 <fwp_ready_tail>
    3073:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3077:	48 85 db             	test   %rbx,%rbx
    307a:	74 17                	je     3093 <fwp_cancel_tree.part.0+0x63>
    307c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3080:	75 08                	jne    308a <fwp_cancel_tree.part.0+0x5a>
    3082:	48 89 df             	mov    %rbx,%rdi
    3085:	e8 a6 ff ff ff       	call   3030 <fwp_cancel_tree.part.0>
    308a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    308e:	48 85 db             	test   %rbx,%rbx
    3091:	75 e9                	jne    307c <fwp_cancel_tree.part.0+0x4c>
    3093:	5b                   	pop    %rbx
    3094:	c3                   	ret
    3095:	0f 1f 00             	nopl   (%rax)
    3098:	48 89 3d 09 96 01 00 	mov    %rdi,0x19609(%rip)        # 1c6a8 <fwp_ready_head>
    309f:	eb cb                	jmp    306c <fwp_cancel_tree.part.0+0x3c>
    30a1:	0f 1f 40 00          	nopl   0x0(%rax)
    30a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    30ac:	00 00 00 00 

00000000000030b0 <fwp_finish_float>:
    30b0:	53                   	push   %rbx
    30b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    30b6:	48 89 fb             	mov    %rdi,%rbx
    30b9:	e8 a2 f3 ff ff       	call   2460 <strchr@plt>
    30be:	48 85 c0             	test   %rax,%rax
    30c1:	74 05                	je     30c8 <fwp_finish_float+0x18>
    30c3:	5b                   	pop    %rbx
    30c4:	c3                   	ret
    30c5:	0f 1f 00             	nopl   (%rax)
    30c8:	be 65 00 00 00       	mov    $0x65,%esi
    30cd:	48 89 df             	mov    %rbx,%rdi
    30d0:	e8 8b f3 ff ff       	call   2460 <strchr@plt>
    30d5:	48 85 c0             	test   %rax,%rax
    30d8:	75 e9                	jne    30c3 <fwp_finish_float+0x13>
    30da:	48 8d 35 f8 5f 00 00 	lea    0x5ff8(%rip),%rsi        # 90d9 <_IO_stdin_used+0xd9>
    30e1:	48 89 df             	mov    %rbx,%rdi
    30e4:	e8 a7 f5 ff ff       	call   2690 <strstr@plt>
    30e9:	48 85 c0             	test   %rax,%rax
    30ec:	75 d5                	jne    30c3 <fwp_finish_float+0x13>
    30ee:	48 8d 35 27 5f 00 00 	lea    0x5f27(%rip),%rsi        # 901c <_IO_stdin_used+0x1c>
    30f5:	48 89 df             	mov    %rbx,%rdi
    30f8:	e8 93 f5 ff ff       	call   2690 <strstr@plt>
    30fd:	48 85 c0             	test   %rax,%rax
    3100:	75 c1                	jne    30c3 <fwp_finish_float+0x13>
    3102:	48 89 df             	mov    %rbx,%rdi
    3105:	e8 26 f3 ff ff       	call   2430 <strlen@plt>
    310a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    310f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    3113:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    3118:	5b                   	pop    %rbx
    3119:	c3                   	ret
    311a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003120 <fwp_trap>:
    3120:	53                   	push   %rbx
    3121:	48 89 fb             	mov    %rdi,%rbx
    3124:	e8 07 fb ff ff       	call   2c30 <fwp_flush>
    3129:	48 89 d9             	mov    %rbx,%rcx
    312c:	be 02 00 00 00       	mov    $0x2,%esi
    3131:	31 c0                	xor    %eax,%eax
    3133:	48 8b 3d 06 8f 00 00 	mov    0x8f06(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    313a:	48 8d 15 df 5e 00 00 	lea    0x5edf(%rip),%rdx        # 9020 <_IO_stdin_used+0x20>
    3141:	e8 0a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3146:	bf 65 00 00 00       	mov    $0x65,%edi
    314b:	e8 e0 f4 ff ff       	call   2630 <exit@plt>

0000000000003150 <fwp_now_ns>:
    3150:	53                   	push   %rbx
    3151:	bf 01 00 00 00       	mov    $0x1,%edi
    3156:	48 83 ec 20          	sub    $0x20,%rsp
    315a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3161:	00 00 
    3163:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3168:	31 db                	xor    %ebx,%ebx
    316a:	48 89 e6             	mov    %rsp,%rsi
    316d:	e8 8e f2 ff ff       	call   2400 <clock_gettime@plt>
    3172:	85 c0                	test   %eax,%eax
    3174:	75 52                	jne    31c8 <fwp_now_ns+0x78>
    3176:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    317b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3180:	48 f7 2c 24          	imulq  (%rsp)
    3184:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    318b:	48 89 f7             	mov    %rsi,%rdi
    318e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3192:	48 01 f0             	add    %rsi,%rax
    3195:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    319c:	00 00 80 
    319f:	48 11 fa             	adc    %rdi,%rdx
    31a2:	31 ff                	xor    %edi,%edi
    31a4:	48 01 c6             	add    %rax,%rsi
    31a7:	48 11 d7             	adc    %rdx,%rdi
    31aa:	48 39 f1             	cmp    %rsi,%rcx
    31ad:	48 19 fb             	sbb    %rdi,%rbx
    31b0:	72 27                	jb     31d9 <fwp_now_ns+0x89>
    31b2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    31b7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    31be:	00 00 
    31c0:	75 12                	jne    31d4 <fwp_now_ns+0x84>
    31c2:	48 83 c4 20          	add    $0x20,%rsp
    31c6:	5b                   	pop    %rbx
    31c7:	c3                   	ret
    31c8:	48 8d 3d 60 5e 00 00 	lea    0x5e60(%rip),%rdi        # 902f <_IO_stdin_used+0x2f>
    31cf:	e8 4c ff ff ff       	call   3120 <fwp_trap>
    31d4:	e8 67 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31d9:	48 8d 3d c0 5f 00 00 	lea    0x5fc0(%rip),%rdi        # 91a0 <_IO_stdin_used+0x1a0>
    31e0:	e8 3b ff ff ff       	call   3120 <fwp_trap>
    31e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31ec:	00 00 00 00 

00000000000031f0 <fwp_args74>:
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	c3                   	ret
    31f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31fc:	00 00 00 00 

0000000000003200 <fwp_format_g.constprop.0>:
    3200:	41 57                	push   %r15
    3202:	b9 40 00 00 00       	mov    $0x40,%ecx
    3207:	ba 02 00 00 00       	mov    $0x2,%edx
    320c:	4c 8d 05 38 5e 00 00 	lea    0x5e38(%rip),%r8        # 904b <_IO_stdin_used+0x4b>
    3213:	41 56                	push   %r14
    3215:	b8 01 00 00 00       	mov    $0x1,%eax
    321a:	41 55                	push   %r13
    321c:	41 54                	push   %r12
    321e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    3222:	55                   	push   %rbp
    3223:	45 89 e1             	mov    %r12d,%r9d
    3226:	53                   	push   %rbx
    3227:	48 89 fb             	mov    %rdi,%rbx
    322a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3231:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3238:	00 00 
    323a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3241:	00 
    3242:	41 89 f7             	mov    %esi,%r15d
    3245:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    324a:	be 40 00 00 00       	mov    $0x40,%esi
    324f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3254:	4c 89 f7             	mov    %r14,%rdi
    3257:	e8 34 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    325c:	be 65 00 00 00       	mov    $0x65,%esi
    3261:	4c 89 f7             	mov    %r14,%rdi
    3264:	e8 f7 f1 ff ff       	call   2460 <strchr@plt>
    3269:	31 f6                	xor    %esi,%esi
    326b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3270:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3274:	48 89 c5             	mov    %rax,%rbp
    3277:	e8 e4 f2 ff ff       	call   2560 <strtol@plt>
    327c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3281:	49 89 c0             	mov    %rax,%r8
    3284:	83 c0 05             	add    $0x5,%eax
    3287:	83 f8 15             	cmp    $0x15,%eax
    328a:	0f 87 f0 01 00 00    	ja     3480 <fwp_format_g.constprop.0+0x280>
    3290:	45 89 e5             	mov    %r12d,%r13d
    3293:	45 29 c5             	sub    %r8d,%r13d
    3296:	45 85 ed             	test   %r13d,%r13d
    3299:	0f 8e 21 01 00 00    	jle    33c0 <fwp_format_g.constprop.0+0x1c0>
    329f:	41 83 ff 01          	cmp    $0x1,%r15d
    32a3:	0f 84 17 01 00 00    	je     33c0 <fwp_format_g.constprop.0+0x1c0>
    32a9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    32ae:	31 d2                	xor    %edx,%edx
    32b0:	4d 63 df             	movslq %r15d,%r11
    32b3:	3c 2d                	cmp    $0x2d,%al
    32b5:	0f 94 c2             	sete   %dl
    32b8:	4c 29 dd             	sub    %r11,%rbp
    32bb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    32bf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    32c3:	4d 89 f1             	mov    %r14,%r9
    32c6:	4d 29 d1             	sub    %r10,%r9
    32c9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    32cd:	3c 2d                	cmp    $0x2d,%al
    32cf:	0f 84 0b 04 00 00    	je     36e0 <fwp_format_g.constprop.0+0x4e0>
    32d5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    32da:	b9 48 00 00 00       	mov    $0x48,%ecx
    32df:	48 89 e8             	mov    %rbp,%rax
    32e2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    32e6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    32ea:	49 83 c1 47          	add    $0x47,%r9
    32ee:	45 85 c0             	test   %r8d,%r8d
    32f1:	0f 88 01 03 00 00    	js     35f8 <fwp_format_g.constprop.0+0x3f8>
    32f7:	45 0f b6 12          	movzbl (%r10),%r10d
    32fb:	4d 63 e0             	movslq %r8d,%r12
    32fe:	44 88 10             	mov    %r10b,(%rax)
    3301:	41 83 f8 07          	cmp    $0x7,%r8d
    3305:	0f 87 3d 02 00 00    	ja     3548 <fwp_format_g.constprop.0+0x348>
    330b:	41 f6 c4 04          	test   $0x4,%r12b
    330f:	0f 85 02 04 00 00    	jne    3717 <fwp_format_g.constprop.0+0x517>
    3315:	45 85 e4             	test   %r12d,%r12d
    3318:	74 12                	je     332c <fwp_format_g.constprop.0+0x12c>
    331a:	45 0f b6 06          	movzbl (%r14),%r8d
    331e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    3322:	41 f6 c4 02          	test   $0x2,%r12b
    3326:	0f 85 13 04 00 00    	jne    373f <fwp_format_g.constprop.0+0x53f>
    332c:	4c 29 e1             	sub    %r12,%rcx
    332f:	4c 01 e7             	add    %r12,%rdi
    3332:	4c 89 fa             	mov    %r15,%rdx
    3335:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    333a:	48 83 e9 01          	sub    $0x1,%rcx
    333e:	4d 63 ed             	movslq %r13d,%r13
    3341:	48 89 0c 24          	mov    %rcx,(%rsp)
    3345:	e8 f6 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    334a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    334f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3353:	ba 48 00 00 00       	mov    $0x48,%edx
    3358:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    335c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3360:	4c 89 c8             	mov    %r9,%rax
    3363:	48 29 c8             	sub    %rcx,%rax
    3366:	48 39 d0             	cmp    %rdx,%rax
    3369:	48 0f 42 c2          	cmovb  %rdx,%rax
    336d:	4c 29 c9             	sub    %r9,%rcx
    3370:	4c 89 ea             	mov    %r13,%rdx
    3373:	48 01 c1             	add    %rax,%rcx
    3376:	e8 c5 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    337b:	4c 01 e8             	add    %r13,%rax
    337e:	48 29 e8             	sub    %rbp,%rax
    3381:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3386:	48 39 d0             	cmp    %rdx,%rax
    3389:	48 0f 47 c2          	cmova  %rdx,%rax
    338d:	89 c1                	mov    %eax,%ecx
    338f:	83 f8 08             	cmp    $0x8,%eax
    3392:	0f 83 28 02 00 00    	jae    35c0 <fwp_format_g.constprop.0+0x3c0>
    3398:	a8 04                	test   $0x4,%al
    339a:	0f 85 64 03 00 00    	jne    3704 <fwp_format_g.constprop.0+0x504>
    33a0:	85 c0                	test   %eax,%eax
    33a2:	74 0f                	je     33b3 <fwp_format_g.constprop.0+0x1b3>
    33a4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    33a9:	88 13                	mov    %dl,(%rbx)
    33ab:	a8 02                	test   $0x2,%al
    33ad:	0f 85 7b 03 00 00    	jne    372e <fwp_format_g.constprop.0+0x52e>
    33b3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33b7:	eb 36                	jmp    33ef <fwp_format_g.constprop.0+0x1ef>
    33b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    33c0:	45 31 c9             	xor    %r9d,%r9d
    33c3:	45 85 ed             	test   %r13d,%r13d
    33c6:	4c 8d 05 8d 5c 00 00 	lea    0x5c8d(%rip),%r8        # 905a <_IO_stdin_used+0x5a>
    33cd:	48 89 df             	mov    %rbx,%rdi
    33d0:	45 0f 49 cd          	cmovns %r13d,%r9d
    33d4:	ba 02 00 00 00       	mov    $0x2,%edx
    33d9:	be 90 01 00 00       	mov    $0x190,%esi
    33de:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    33e5:	b8 01 00 00 00       	mov    $0x1,%eax
    33ea:	e8 a1 ef ff ff       	call   2390 <__snprintf_chk@plt>
    33ef:	be 2e 00 00 00       	mov    $0x2e,%esi
    33f4:	48 89 df             	mov    %rbx,%rdi
    33f7:	e8 64 f0 ff ff       	call   2460 <strchr@plt>
    33fc:	48 85 c0             	test   %rax,%rax
    33ff:	74 4f                	je     3450 <fwp_format_g.constprop.0+0x250>
    3401:	48 89 df             	mov    %rbx,%rdi
    3404:	e8 27 f0 ff ff       	call   2430 <strlen@plt>
    3409:	48 85 c0             	test   %rax,%rax
    340c:	75 1b                	jne    3429 <fwp_format_g.constprop.0+0x229>
    340e:	eb 40                	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3410:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    341c:	00 00 00 00 
    3420:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3424:	48 85 c0             	test   %rax,%rax
    3427:	74 27                	je     3450 <fwp_format_g.constprop.0+0x250>
    3429:	48 89 c2             	mov    %rax,%rdx
    342c:	48 83 e8 01          	sub    $0x1,%rax
    3430:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    3434:	74 ea                	je     3420 <fwp_format_g.constprop.0+0x220>
    3436:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    343b:	0f 84 6f 01 00 00    	je     35b0 <fwp_format_g.constprop.0+0x3b0>
    3441:	0f 1f 40 00          	nopl   0x0(%rax)
    3445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    344c:	00 00 00 00 
    3450:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3457:	00 
    3458:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    345f:	00 00 
    3461:	0f 85 ec 02 00 00    	jne    3753 <fwp_format_g.constprop.0+0x553>
    3467:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    346e:	5b                   	pop    %rbx
    346f:	5d                   	pop    %rbp
    3470:	41 5c                	pop    %r12
    3472:	41 5d                	pop    %r13
    3474:	41 5e                	pop    %r14
    3476:	41 5f                	pop    %r15
    3478:	c3                   	ret
    3479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3480:	4c 29 f5             	sub    %r14,%rbp
    3483:	b9 40 00 00 00       	mov    $0x40,%ecx
    3488:	4c 89 f6             	mov    %r14,%rsi
    348b:	4c 89 04 24          	mov    %r8,(%rsp)
    348f:	49 89 ec             	mov    %rbp,%r12
    3492:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3497:	4c 89 e2             	mov    %r12,%rdx
    349a:	48 89 ef             	mov    %rbp,%rdi
    349d:	e8 9e f0 ff ff       	call   2540 <__memcpy_chk@plt>
    34a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    34a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    34ad:	48 89 ef             	mov    %rbp,%rdi
    34b0:	e8 ab ef ff ff       	call   2460 <strchr@plt>
    34b5:	4c 8b 04 24          	mov    (%rsp),%r8
    34b9:	48 85 c0             	test   %rax,%rax
    34bc:	74 40                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34be:	4d 85 e4             	test   %r12,%r12
    34c1:	74 3b                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    34c8:	eb 23                	jmp    34ed <fwp_format_g.constprop.0+0x2ed>
    34ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34d1:	00 00 00 00 
    34d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34dc:	00 00 00 00 
    34e0:	c6 00 00             	movb   $0x0,(%rax)
    34e3:	48 83 e8 01          	sub    $0x1,%rax
    34e7:	49 83 ec 01          	sub    $0x1,%r12
    34eb:	74 11                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34ed:	80 38 30             	cmpb   $0x30,(%rax)
    34f0:	74 ee                	je     34e0 <fwp_format_g.constprop.0+0x2e0>
    34f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    34f8:	0f 84 fb 01 00 00    	je     36f9 <fwp_format_g.constprop.0+0x4f9>
    34fe:	44 89 c0             	mov    %r8d,%eax
    3501:	ba 02 00 00 00       	mov    $0x2,%edx
    3506:	49 89 e9             	mov    %rbp,%r9
    3509:	be 90 01 00 00       	mov    $0x190,%esi
    350e:	f7 d8                	neg    %eax
    3510:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3517:	48 89 df             	mov    %rbx,%rdi
    351a:	41 0f 48 c0          	cmovs  %r8d,%eax
    351e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    3522:	41 83 e0 02          	and    $0x2,%r8d
    3526:	41 83 c0 2b          	add    $0x2b,%r8d
    352a:	50                   	push   %rax
    352b:	31 c0                	xor    %eax,%eax
    352d:	41 50                	push   %r8
    352f:	4c 8d 05 1a 5b 00 00 	lea    0x5b1a(%rip),%r8        # 9050 <_IO_stdin_used+0x50>
    3536:	e8 55 ee ff ff       	call   2390 <__snprintf_chk@plt>
    353b:	58                   	pop    %rax
    353c:	5a                   	pop    %rdx
    353d:	e9 0e ff ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3548:	4d 8b 06             	mov    (%r14),%r8
    354b:	48 83 c0 09          	add    $0x9,%rax
    354f:	4c 89 f2             	mov    %r14,%rdx
    3552:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3556:	4c 89 07             	mov    %r8,(%rdi)
    3559:	45 89 e0             	mov    %r12d,%r8d
    355c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3561:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3566:	49 89 f8             	mov    %rdi,%r8
    3569:	49 29 c0             	sub    %rax,%r8
    356c:	4c 29 c2             	sub    %r8,%rdx
    356f:	45 01 e0             	add    %r12d,%r8d
    3572:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3576:	41 83 f8 08          	cmp    $0x8,%r8d
    357a:	0f 82 ac fd ff ff    	jb     332c <fwp_format_g.constprop.0+0x12c>
    3580:	48 89 0c 24          	mov    %rcx,(%rsp)
    3584:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3588:	45 31 d2             	xor    %r10d,%r10d
    358b:	45 89 d3             	mov    %r10d,%r11d
    358e:	41 83 c2 08          	add    $0x8,%r10d
    3592:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3596:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    359a:	45 39 c2             	cmp    %r8d,%r10d
    359d:	72 ec                	jb     358b <fwp_format_g.constprop.0+0x38b>
    359f:	48 8b 0c 24          	mov    (%rsp),%rcx
    35a3:	e9 84 fd ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    35a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    35af:	00 
    35b0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    35b5:	e9 96 fe ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    35c0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    35c5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    35c9:	48 89 ee             	mov    %rbp,%rsi
    35cc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    35d0:	48 89 13             	mov    %rdx,(%rbx)
    35d3:	89 c2                	mov    %eax,%edx
    35d5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    35da:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    35df:	48 89 d9             	mov    %rbx,%rcx
    35e2:	48 29 f9             	sub    %rdi,%rcx
    35e5:	48 29 ce             	sub    %rcx,%rsi
    35e8:	01 c1                	add    %eax,%ecx
    35ea:	c1 e9 03             	shr    $0x3,%ecx
    35ed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    35f0:	e9 be fd ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    35f5:	0f 1f 00             	nopl   (%rax)
    35f8:	c6 00 30             	movb   $0x30,(%rax)
    35fb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    35ff:	4c 89 fa             	mov    %r15,%rdx
    3602:	4c 89 e9             	mov    %r13,%rcx
    3605:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    360a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    360f:	4c 89 14 24          	mov    %r10,(%rsp)
    3613:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3618:	e8 23 ef ff ff       	call   2540 <__memcpy_chk@plt>
    361d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    3622:	b9 48 00 00 00       	mov    $0x48,%ecx
    3627:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    362c:	48 89 c7             	mov    %rax,%rdi
    362f:	4c 8b 14 24          	mov    (%rsp),%r10
    3633:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    3638:	4c 89 c8             	mov    %r9,%rax
    363b:	4c 29 e8             	sub    %r13,%rax
    363e:	48 39 c8             	cmp    %rcx,%rax
    3641:	48 0f 42 c1          	cmovb  %rcx,%rax
    3645:	4d 29 cd             	sub    %r9,%r13
    3648:	49 01 ff             	add    %rdi,%r15
    364b:	4c 01 e8             	add    %r13,%rax
    364e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3652:	74 3d                	je     3691 <fwp_format_g.constprop.0+0x491>
    3654:	41 f7 d0             	not    %r8d
    3657:	31 f6                	xor    %esi,%esi
    3659:	ba 48 00 00 00       	mov    $0x48,%edx
    365e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3663:	48 39 d0             	cmp    %rdx,%rax
    3666:	48 0f 43 d0          	cmovae %rax,%rdx
    366a:	48 89 d1             	mov    %rdx,%rcx
    366d:	48 29 c1             	sub    %rax,%rcx
    3670:	48 83 c1 01          	add    $0x1,%rcx
    3674:	48 39 d1             	cmp    %rdx,%rcx
    3677:	48 0f 42 ca          	cmovb  %rdx,%rcx
    367b:	48 83 e8 01          	sub    $0x1,%rax
    367f:	48 83 c6 01          	add    $0x1,%rsi
    3683:	48 29 d0             	sub    %rdx,%rax
    3686:	48 01 c8             	add    %rcx,%rax
    3689:	41 39 f0             	cmp    %esi,%r8d
    368c:	7f cb                	jg     3659 <fwp_format_g.constprop.0+0x459>
    368e:	4d 01 c7             	add    %r8,%r15
    3691:	b9 48 00 00 00       	mov    $0x48,%ecx
    3696:	41 0f b6 12          	movzbl (%r10),%edx
    369a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    369e:	4c 89 f6             	mov    %r14,%rsi
    36a1:	48 39 c8             	cmp    %rcx,%rax
    36a4:	4c 89 1c 24          	mov    %r11,(%rsp)
    36a8:	48 0f 43 c8          	cmovae %rax,%rcx
    36ac:	41 88 17             	mov    %dl,(%r15)
    36af:	48 89 ca             	mov    %rcx,%rdx
    36b2:	48 29 c2             	sub    %rax,%rdx
    36b5:	48 83 c2 01          	add    $0x1,%rdx
    36b9:	48 39 ca             	cmp    %rcx,%rdx
    36bc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    36c0:	48 83 e8 01          	sub    $0x1,%rax
    36c4:	48 29 c8             	sub    %rcx,%rax
    36c7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    36cb:	49 63 d4             	movslq %r12d,%rdx
    36ce:	e8 6d ee ff ff       	call   2540 <__memcpy_chk@plt>
    36d3:	4c 8b 1c 24          	mov    (%rsp),%r11
    36d7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    36db:	e9 9e fc ff ff       	jmp    337e <fwp_format_g.constprop.0+0x17e>
    36e0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    36e5:	b9 47 00 00 00       	mov    $0x47,%ecx
    36ea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    36ef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    36f4:	e9 e9 fb ff ff       	jmp    32e2 <fwp_format_g.constprop.0+0xe2>
    36f9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    36ff:	e9 fa fd ff ff       	jmp    34fe <fwp_format_g.constprop.0+0x2fe>
    3704:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3708:	89 13                	mov    %edx,(%rbx)
    370a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    370e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3712:	e9 9c fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    3717:	41 8b 06             	mov    (%r14),%eax
    371a:	89 07                	mov    %eax,(%rdi)
    371c:	44 89 e0             	mov    %r12d,%eax
    371f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    3724:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    3729:	e9 fe fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    372e:	89 c2                	mov    %eax,%edx
    3730:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    3735:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    373a:	e9 74 fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    373f:	44 89 e0             	mov    %r12d,%eax
    3742:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3748:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    374e:	e9 d9 fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    3753:	e8 e8 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    375f:	00 

0000000000003760 <fwp_heap_report>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	41 54                	push   %r12
    3766:	48 8d 3d f2 58 00 00 	lea    0x58f2(%rip),%rdi        # 905f <_IO_stdin_used+0x5f>
    376d:	55                   	push   %rbp
    376e:	53                   	push   %rbx
    376f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3776:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    377d:	00 00 
    377f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3786:	00 
    3787:	48 8d 35 93 59 00 00 	lea    0x5993(%rip),%rsi        # 9121 <_IO_stdin_used+0x121>
    378e:	e8 5d ee ff ff       	call   25f0 <fopen@plt>
    3793:	48 85 c0             	test   %rax,%rax
    3796:	0f 84 c5 00 00 00    	je     3861 <fwp_heap_report+0x101>
    379c:	48 89 c5             	mov    %rax,%rbp
    379f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37a6:	48 89 e3             	mov    %rsp,%rbx
    37a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    37b0:	48 89 ea             	mov    %rbp,%rdx
    37b3:	be 00 01 00 00       	mov    $0x100,%esi
    37b8:	48 89 df             	mov    %rbx,%rdi
    37bb:	e8 20 ed ff ff       	call   24e0 <fgets@plt>
    37c0:	48 85 c0             	test   %rax,%rax
    37c3:	74 2b                	je     37f0 <fwp_heap_report+0x90>
    37c5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    37cb:	75 e3                	jne    37b0 <fwp_heap_report+0x50>
    37cd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    37d1:	75 dd                	jne    37b0 <fwp_heap_report+0x50>
    37d3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    37d8:	75 d6                	jne    37b0 <fwp_heap_report+0x50>
    37da:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    37df:	ba 0a 00 00 00       	mov    $0xa,%edx
    37e4:	31 f6                	xor    %esi,%esi
    37e6:	e8 75 ed ff ff       	call   2560 <strtol@plt>
    37eb:	49 89 c4             	mov    %rax,%r12
    37ee:	eb c0                	jmp    37b0 <fwp_heap_report+0x50>
    37f0:	48 89 ef             	mov    %rbp,%rdi
    37f3:	e8 28 ec ff ff       	call   2420 <fclose@plt>
    37f8:	48 83 ec 08          	sub    $0x8,%rsp
    37fc:	4c 8b 0d a5 a2 01 00 	mov    0x1a2a5(%rip),%r9        # 1daa8 <fwp_heap+0x13c8>
    3803:	4c 8b 05 fe a2 01 00 	mov    0x1a2fe(%rip),%r8        # 1db08 <fwp_heap+0x1428>
    380a:	48 8d 15 bf 59 00 00 	lea    0x59bf(%rip),%rdx        # 91d0 <_IO_stdin_used+0x1d0>
    3811:	41 54                	push   %r12
    3813:	48 8b 0d e6 a2 01 00 	mov    0x1a2e6(%rip),%rcx        # 1db00 <fwp_heap+0x1420>
    381a:	be 02 00 00 00       	mov    $0x2,%esi
    381f:	b8 02 00 00 00       	mov    $0x2,%eax
    3824:	f2 0f 10 0d f4 a2 01 	movsd  0x1a2f4(%rip),%xmm1        # 1db20 <fwp_heap+0x1440>
    382b:	00 
    382c:	f2 0f 10 05 e4 a2 01 	movsd  0x1a2e4(%rip),%xmm0        # 1db18 <fwp_heap+0x1438>
    3833:	00 
    3834:	48 8b 3d 05 88 00 00 	mov    0x8805(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    383b:	e8 10 ee ff ff       	call   2650 <__fprintf_chk@plt>
    3840:	58                   	pop    %rax
    3841:	5a                   	pop    %rdx
    3842:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3849:	00 
    384a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3851:	00 00 
    3853:	75 15                	jne    386a <fwp_heap_report+0x10a>
    3855:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    385c:	5b                   	pop    %rbx
    385d:	5d                   	pop    %rbp
    385e:	41 5c                	pop    %r12
    3860:	c3                   	ret
    3861:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3868:	eb 8e                	jmp    37f8 <fwp_heap_report+0x98>
    386a:	e8 d1 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    386f:	90                   	nop

0000000000003870 <fwp_heap_init>:
    3870:	66 0f 6f 05 28 5c 00 	movdqa 0x5c28(%rip),%xmm0        # 94a0 <msg.3+0x50>
    3877:	00 
    3878:	41 54                	push   %r12
    387a:	48 8d 05 9f 9d 01 00 	lea    0x19d9f(%rip),%rax        # 1d620 <fwp_heap+0xf40>
    3881:	ba 00 01 00 00       	mov    $0x100,%edx
    3886:	55                   	push   %rbp
    3887:	66 0f 6f 15 51 5c 00 	movdqa 0x5c51(%rip),%xmm2        # 94e0 <msg.3+0x90>
    388e:	00 
    388f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3893:	53                   	push   %rbx
    3894:	0f 29 05 45 9d 01 00 	movaps %xmm0,0x19d45(%rip)        # 1d5e0 <fwp_heap+0xf00>
    389b:	66 0f 6f 05 0d 5c 00 	movdqa 0x5c0d(%rip),%xmm0        # 94b0 <msg.3+0x60>
    38a2:	00 
    38a3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    38a7:	c7 05 d3 a1 01 00 01 	movl   $0x1,0x1a1d3(%rip)        # 1da84 <fwp_heap+0x13a4>
    38ae:	00 00 00 
    38b1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    38b6:	0f 29 05 33 9d 01 00 	movaps %xmm0,0x19d33(%rip)        # 1d5f0 <fwp_heap+0xf10>
    38bd:	66 0f 6f 05 fb 5b 00 	movdqa 0x5bfb(%rip),%xmm0        # 94c0 <msg.3+0x70>
    38c4:	00 
    38c5:	0f 29 05 34 9d 01 00 	movaps %xmm0,0x19d34(%rip)        # 1d600 <fwp_heap+0xf20>
    38cc:	66 0f 6f 05 fc 5b 00 	movdqa 0x5bfc(%rip),%xmm0        # 94d0 <msg.3+0x80>
    38d3:	00 
    38d4:	0f 29 05 35 9d 01 00 	movaps %xmm0,0x19d35(%rip)        # 1d610 <fwp_heap+0xf30>
    38db:	89 d3                	mov    %edx,%ebx
    38dd:	66 0f 6e e2          	movd   %edx,%xmm4
    38e1:	48 83 c0 10          	add    $0x10,%rax
    38e5:	01 d2                	add    %edx,%edx
    38e7:	c1 eb 02             	shr    $0x2,%ebx
    38ea:	66 0f 6e c3          	movd   %ebx,%xmm0
    38ee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    38f3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    38f7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    38fc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3900:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3904:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3909:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    390e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3912:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3917:	66 0f fe c1          	paddd  %xmm1,%xmm0
    391b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    391f:	48 39 c7             	cmp    %rax,%rdi
    3922:	75 b7                	jne    38db <fwp_heap_init+0x6b>
    3924:	4c 8d 05 b5 8d 01 00 	lea    0x18db5(%rip),%r8        # 1c6e0 <fwp_heap>
    392b:	31 c9                	xor    %ecx,%ecx
    392d:	31 c0                	xor    %eax,%eax
    392f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 
    3940:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3947:	00 
    3948:	48 39 ca             	cmp    %rcx,%rdx
    394b:	73 0f                	jae    395c <fwp_heap_init+0xec>
    394d:	0f 1f 00             	nopl   (%rax)
    3950:	48 83 c0 01          	add    $0x1,%rax
    3954:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3957:	48 39 ca             	cmp    %rcx,%rdx
    395a:	72 f4                	jb     3950 <fwp_heap_init+0xe0>
    395c:	48 83 c1 10          	add    $0x10,%rcx
    3960:	88 07                	mov    %al,(%rdi)
    3962:	48 83 c7 01          	add    $0x1,%rdi
    3966:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    396d:	75 d1                	jne    3940 <fwp_heap_init+0xd0>
    396f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3976:	00 00 00 
    3979:	bd 05 00 00 00       	mov    $0x5,%ebp
    397e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3985:	45 31 c9             	xor    %r9d,%r9d
    3988:	31 d2                	xor    %edx,%edx
    398a:	31 ff                	xor    %edi,%edi
    398c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3992:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3997:	4c 89 e6             	mov    %r12,%rsi
    399a:	e8 b1 ea ff ff       	call   2450 <mmap@plt>
    399f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    39a3:	75 13                	jne    39b8 <fwp_heap_init+0x148>
    39a5:	48 c1 eb 02          	shr    $0x2,%rbx
    39a9:	83 ed 01             	sub    $0x1,%ebp
    39ac:	75 d0                	jne    397e <fwp_heap_init+0x10e>
    39ae:	e8 bd f2 ff ff       	call   2c70 <fwp_heap_oom>
    39b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    39b8:	48 85 c0             	test   %rax,%rax
    39bb:	74 f1                	je     39ae <fwp_heap_init+0x13e>
    39bd:	48 c1 eb 10          	shr    $0x10,%rbx
    39c1:	48 89 05 d0 a0 01 00 	mov    %rax,0x1a0d0(%rip)        # 1da98 <fwp_heap+0x13b8>
    39c8:	45 31 c9             	xor    %r9d,%r9d
    39cb:	31 d2                	xor    %edx,%edx
    39cd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    39d3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    39d7:	31 ff                	xor    %edi,%edi
    39d9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    39df:	66 31 c0             	xor    %ax,%ax
    39e2:	48 c1 e6 03          	shl    $0x3,%rsi
    39e6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    39eb:	4c 89 25 ae a0 01 00 	mov    %r12,0x1a0ae(%rip)        # 1daa0 <fwp_heap+0x13c0>
    39f2:	48 89 05 97 a0 01 00 	mov    %rax,0x1a097(%rip)        # 1da90 <fwp_heap+0x13b0>
    39f9:	48 89 1d b0 a0 01 00 	mov    %rbx,0x1a0b0(%rip)        # 1dab0 <fwp_heap+0x13d0>
    3a00:	48 89 35 d9 a0 01 00 	mov    %rsi,0x1a0d9(%rip)        # 1dae0 <fwp_heap+0x1400>
    3a07:	e8 44 ea ff ff       	call   2450 <mmap@plt>
    3a0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a10:	74 9c                	je     39ae <fwp_heap_init+0x13e>
    3a12:	48 8d 3d 7c 56 00 00 	lea    0x567c(%rip),%rdi        # 9095 <_IO_stdin_used+0x95>
    3a19:	48 89 05 b8 a0 01 00 	mov    %rax,0x1a0b8(%rip)        # 1dad8 <fwp_heap+0x13f8>
    3a20:	e8 5b e9 ff ff       	call   2380 <getenv@plt>
    3a25:	48 89 c2             	mov    %rax,%rdx
    3a28:	31 c0                	xor    %eax,%eax
    3a2a:	48 85 d2             	test   %rdx,%rdx
    3a2d:	74 15                	je     3a44 <fwp_heap_init+0x1d4>
    3a2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    3a32:	74 10                	je     3a44 <fwp_heap_init+0x1d4>
    3a34:	0f b6 02             	movzbl (%rdx),%eax
    3a37:	83 e8 30             	sub    $0x30,%eax
    3a3a:	74 13                	je     3a4f <fwp_heap_init+0x1df>
    3a3c:	85 c0                	test   %eax,%eax
    3a3e:	0f 95 c0             	setne  %al
    3a41:	0f b6 c0             	movzbl %al,%eax
    3a44:	5b                   	pop    %rbx
    3a45:	5d                   	pop    %rbp
    3a46:	89 05 3c a0 01 00    	mov    %eax,0x1a03c(%rip)        # 1da88 <fwp_heap+0x13a8>
    3a4c:	41 5c                	pop    %r12
    3a4e:	c3                   	ret
    3a4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3a53:	85 c0                	test   %eax,%eax
    3a55:	0f 95 c0             	setne  %al
    3a58:	0f b6 c0             	movzbl %al,%eax
    3a5b:	eb e7                	jmp    3a44 <fwp_heap_init+0x1d4>
    3a5d:	0f 1f 00             	nopl   (%rax)

0000000000003a60 <fwp_args45>:
    3a60:	f3 0f 1e fa          	endbr64
    3a64:	c3                   	ret
    3a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a6c:	00 00 00 00 

0000000000003a70 <fwp_args69>:
    3a70:	f3 0f 1e fa          	endbr64
    3a74:	c3                   	ret
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 

0000000000003a80 <fwp_wake_io>:
    3a80:	48 8b 07             	mov    (%rdi),%rax
    3a83:	48 85 c0             	test   %rax,%rax
    3a86:	0f 84 f4 00 00 00    	je     3b80 <fwp_wake_io+0x100>
    3a8c:	53                   	push   %rbx
    3a8d:	4c 8b 05 0c 8c 01 00 	mov    0x18c0c(%rip),%r8        # 1c6a0 <fwp_ready_tail>
    3a94:	49 89 f9             	mov    %rdi,%r9
    3a97:	48 89 c2             	mov    %rax,%rdx
    3a9a:	45 31 db             	xor    %r11d,%r11d
    3a9d:	45 31 d2             	xor    %r10d,%r10d
    3aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3aa4:	eb 71                	jmp    3b17 <fwp_wake_io+0x97>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3ab7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3abe:	48 85 c9             	test   %rcx,%rcx
    3ac1:	74 07                	je     3aca <fwp_wake_io+0x4a>
    3ac3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3aca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3ad1:	00 00 00 00 
    3ad5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3adc:	49 8b 01             	mov    (%r9),%rax
    3adf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ae3:	75 2a                	jne    3b0f <fwp_wake_io+0x8f>
    3ae5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3ae9:	75 24                	jne    3b0f <fwp_wake_io+0x8f>
    3aeb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3aef:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3af6:	00 00 00 00 
    3afa:	4d 85 c0             	test   %r8,%r8
    3afd:	74 51                	je     3b50 <fwp_wake_io+0xd0>
    3aff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3b06:	49 89 d0             	mov    %rdx,%r8
    3b09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3b0f:	48 89 c2             	mov    %rax,%rdx
    3b12:	48 85 c0             	test   %rax,%rax
    3b15:	74 49                	je     3b60 <fwp_wake_io+0xe0>
    3b17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3b1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3b22:	48 85 ff             	test   %rdi,%rdi
    3b25:	74 b8                	je     3adf <fwp_wake_io+0x5f>
    3b27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3b2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b35:	48 85 f6             	test   %rsi,%rsi
    3b38:	0f 85 72 ff ff ff    	jne    3ab0 <fwp_wake_io+0x30>
    3b3e:	48 89 0f             	mov    %rcx,(%rdi)
    3b41:	e9 78 ff ff ff       	jmp    3abe <fwp_wake_io+0x3e>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 d3             	mov    %rdx,%rbx
    3b53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3b59:	eb ab                	jmp    3b06 <fwp_wake_io+0x86>
    3b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3b60:	45 84 db             	test   %r11b,%r11b
    3b63:	74 07                	je     3b6c <fwp_wake_io+0xec>
    3b65:	48 89 1d 3c 8b 01 00 	mov    %rbx,0x18b3c(%rip)        # 1c6a8 <fwp_ready_head>
    3b6c:	45 84 d2             	test   %r10b,%r10b
    3b6f:	74 07                	je     3b78 <fwp_wake_io+0xf8>
    3b71:	4c 89 05 28 8b 01 00 	mov    %r8,0x18b28(%rip)        # 1c6a0 <fwp_ready_tail>
    3b78:	5b                   	pop    %rbx
    3b79:	c3                   	ret
    3b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3b80:	c3                   	ret
    3b81:	0f 1f 40 00          	nopl   0x0(%rax)
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_poll_events>:
    3b90:	53                   	push   %rbx
    3b91:	48 83 ec 20          	sub    $0x20,%rsp
    3b95:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3b9c:	00 00 
    3b9e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3ba3:	31 c0                	xor    %eax,%eax
    3ba5:	e8 a6 f5 ff ff       	call   3150 <fwp_now_ns>
    3baa:	48 8b 1d e7 8a 01 00 	mov    0x18ae7(%rip),%rbx        # 1c698 <fwp_timers>
    3bb1:	48 85 db             	test   %rbx,%rbx
    3bb4:	0f 84 e6 00 00 00    	je     3ca0 <fwp_poll_events+0x110>
    3bba:	48 89 c6             	mov    %rax,%rsi
    3bbd:	48 89 da             	mov    %rbx,%rdx
    3bc0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3bc7:	eb 26                	jmp    3bef <fwp_poll_events+0x5f>
    3bc9:	90                   	nop
    3bca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bd1:	00 00 00 00 
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 
    3be0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3be7:	48 89 c8             	mov    %rcx,%rax
    3bea:	48 85 d2             	test   %rdx,%rdx
    3bed:	74 31                	je     3c20 <fwp_poll_events+0x90>
    3bef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3bf3:	48 85 c0             	test   %rax,%rax
    3bf6:	78 e8                	js     3be0 <fwp_poll_events+0x50>
    3bf8:	48 39 c1             	cmp    %rax,%rcx
    3bfb:	7c e3                	jl     3be0 <fwp_poll_events+0x50>
    3bfd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 1c                	je     3c25 <fwp_poll_events+0x95>
    3c09:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c0d:	48 39 c1             	cmp    %rax,%rcx
    3c10:	7c ce                	jl     3be0 <fwp_poll_events+0x50>
    3c12:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c19:	48 85 d2             	test   %rdx,%rdx
    3c1c:	75 d1                	jne    3bef <fwp_poll_events+0x5f>
    3c1e:	66 90                	xchg   %ax,%ax
    3c20:	48 85 c0             	test   %rax,%rax
    3c23:	78 7b                	js     3ca0 <fwp_poll_events+0x110>
    3c25:	48 29 f0             	sub    %rsi,%rax
    3c28:	48 89 c1             	mov    %rax,%rcx
    3c2b:	48 85 c0             	test   %rax,%rax
    3c2e:	0f 8e 9c 00 00 00    	jle    3cd0 <fwp_poll_events+0x140>
    3c34:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3c3b:	de 1b 43 
    3c3e:	48 f7 ea             	imul   %rdx
    3c41:	48 89 c8             	mov    %rcx,%rax
    3c44:	48 c1 f8 3f          	sar    $0x3f,%rax
    3c48:	48 c1 fa 12          	sar    $0x12,%rdx
    3c4c:	48 29 c2             	sub    %rax,%rdx
    3c4f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3c56:	48 39 c1             	cmp    %rax,%rcx
    3c59:	0f 95 c0             	setne  %al
    3c5c:	0f b6 c0             	movzbl %al,%eax
    3c5f:	48 01 d0             	add    %rdx,%rax
    3c62:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3c68:	0f 8f 32 01 00 00    	jg     3da0 <fwp_poll_events+0x210>
    3c6e:	48 85 c0             	test   %rax,%rax
    3c71:	74 5d                	je     3cd0 <fwp_poll_events+0x140>
    3c73:	89 c1                	mov    %eax,%ecx
    3c75:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3c7c:	48 c1 e9 26          	shr    $0x26,%rcx
    3c80:	48 63 d1             	movslq %ecx,%rdx
    3c83:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3c89:	29 c8                	sub    %ecx,%eax
    3c8b:	48 98                	cltq
    3c8d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3c94:	e9 11 01 00 00       	jmp    3daa <fwp_poll_events+0x21a>
    3c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ca0:	e8 8b ef ff ff       	call   2c30 <fwp_flush>
    3ca5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3caa:	be 01 00 00 00       	mov    $0x1,%esi
    3caf:	48 8b 0d 8a 83 00 00 	mov    0x838a(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    3cb6:	48 8d 3d 9b 55 00 00 	lea    0x559b(%rip),%rdi        # 9258 <_IO_stdin_used+0x258>
    3cbd:	e8 7e e9 ff ff       	call   2640 <fwrite@plt>
    3cc2:	bf 65 00 00 00       	mov    $0x65,%edi
    3cc7:	e8 64 e9 ff ff       	call   2630 <exit@plt>
    3ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    3cd0:	e8 7b f4 ff ff       	call   3150 <fwp_now_ns>
    3cd5:	48 89 c1             	mov    %rax,%rcx
    3cd8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3cdc:	eb 44                	jmp    3d22 <fwp_poll_events+0x192>
    3cde:	66 90                	xchg   %ax,%ax
    3ce0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ce4:	75 33                	jne    3d19 <fwp_poll_events+0x189>
    3ce6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cea:	75 2d                	jne    3d19 <fwp_poll_events+0x189>
    3cec:	48 8b 05 ad 89 01 00 	mov    0x189ad(%rip),%rax        # 1c6a0 <fwp_ready_tail>
    3cf3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3cf7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3cfe:	00 00 00 00 
    3d02:	48 85 c0             	test   %rax,%rax
    3d05:	0f 84 05 01 00 00    	je     3e10 <fwp_poll_events+0x280>
    3d0b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3d12:	48 89 15 87 89 01 00 	mov    %rdx,0x18987(%rip)        # 1c6a0 <fwp_ready_tail>
    3d19:	48 85 db             	test   %rbx,%rbx
    3d1c:	0f 84 be 00 00 00    	je     3de0 <fwp_poll_events+0x250>
    3d22:	48 89 da             	mov    %rbx,%rdx
    3d25:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3d2c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3d30:	7f e7                	jg     3d19 <fwp_poll_events+0x189>
    3d32:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3d36:	74 2e                	je     3d66 <fwp_poll_events+0x1d6>
    3d38:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	0f 84 b8 00 00 00    	je     3e00 <fwp_poll_events+0x270>
    3d48:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3d4f:	48 85 db             	test   %rbx,%rbx
    3d52:	74 07                	je     3d5b <fwp_poll_events+0x1cb>
    3d54:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3d5b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3d5f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3d66:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3d6a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3d6e:	48 85 c0             	test   %rax,%rax
    3d71:	0f 84 69 ff ff ff    	je     3ce0 <fwp_poll_events+0x150>
    3d77:	48 39 c8             	cmp    %rcx,%rax
    3d7a:	0f 8f 60 ff ff ff    	jg     3ce0 <fwp_poll_events+0x150>
    3d80:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3d84:	0f 85 56 ff ff ff    	jne    3ce0 <fwp_poll_events+0x150>
    3d8a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8e:	75 89                	jne    3d19 <fwp_poll_events+0x189>
    3d90:	48 89 d7             	mov    %rdx,%rdi
    3d93:	e8 98 f2 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    3d98:	e9 43 ff ff ff       	jmp    3ce0 <fwp_poll_events+0x150>
    3d9d:	0f 1f 00             	nopl   (%rax)
    3da0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3da5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3daa:	48 89 e7             	mov    %rsp,%rdi
    3dad:	31 f6                	xor    %esi,%esi
    3daf:	48 89 14 24          	mov    %rdx,(%rsp)
    3db3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3db8:	e8 c3 e6 ff ff       	call   2480 <nanosleep@plt>
    3dbd:	48 8b 1d d4 88 01 00 	mov    0x188d4(%rip),%rbx        # 1c698 <fwp_timers>
    3dc4:	e8 87 f3 ff ff       	call   3150 <fwp_now_ns>
    3dc9:	48 89 c1             	mov    %rax,%rcx
    3dcc:	48 85 db             	test   %rbx,%rbx
    3dcf:	0f 85 03 ff ff ff    	jne    3cd8 <fwp_poll_events+0x148>
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 
    3de0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3de5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3dec:	00 00 
    3dee:	75 2c                	jne    3e1c <fwp_poll_events+0x28c>
    3df0:	48 83 c4 20          	add    $0x20,%rsp
    3df4:	5b                   	pop    %rbx
    3df5:	c3                   	ret
    3df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3dfd:	00 00 00 
    3e00:	48 89 1d 91 88 01 00 	mov    %rbx,0x18891(%rip)        # 1c698 <fwp_timers>
    3e07:	e9 43 ff ff ff       	jmp    3d4f <fwp_poll_events+0x1bf>
    3e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3e10:	48 89 15 91 88 01 00 	mov    %rdx,0x18891(%rip)        # 1c6a8 <fwp_ready_head>
    3e17:	e9 f6 fe ff ff       	jmp    3d12 <fwp_poll_events+0x182>
    3e1c:	e8 1f e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3e21:	0f 1f 40 00          	nopl   0x0(%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_rc_wide_dup>:
    3e30:	48 89 fa             	mov    %rdi,%rdx
    3e33:	48 8d 35 a6 88 01 00 	lea    0x188a6(%rip),%rsi        # 1c6e0 <fwp_heap>
    3e3a:	48 83 ec 18          	sub    $0x18,%rsp
    3e3e:	48 89 f9             	mov    %rdi,%rcx
    3e41:	48 c1 ea 11          	shr    $0x11,%rdx
    3e45:	48 31 fa             	xor    %rdi,%rdx
    3e48:	48 89 d0             	mov    %rdx,%rax
    3e4b:	48 c1 e8 09          	shr    $0x9,%rax
    3e4f:	48 31 c2             	xor    %rax,%rdx
    3e52:	0f b6 d2             	movzbl %dl,%edx
    3e55:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    3e5c:	00 
    3e5d:	49 8b 00             	mov    (%r8),%rax
    3e60:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    3e67:	00 00 
    3e69:	75 21                	jne    3e8c <fwp_rc_wide_dup+0x5c>
    3e6b:	e9 98 00 00 00       	jmp    3f08 <fwp_rc_wide_dup+0xd8>
    3e70:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3e84:	48 85 d2             	test   %rdx,%rdx
    3e87:	74 2f                	je     3eb8 <fwp_rc_wide_dup+0x88>
    3e89:	48 89 d0             	mov    %rdx,%rax
    3e8c:	48 3b 08             	cmp    (%rax),%rcx
    3e8f:	75 ef                	jne    3e80 <fwp_rc_wide_dup+0x50>
    3e91:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3e94:	74 7c                	je     3f12 <fwp_rc_wide_dup+0xe2>
    3e96:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3e9a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    3e9e:	0f 84 91 00 00 00    	je     3f35 <fwp_rc_wide_dup+0x105>
    3ea4:	48 83 c2 01          	add    $0x1,%rdx
    3ea8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    3eac:	48 83 c4 18          	add    $0x18,%rsp
    3eb0:	c3                   	ret
    3eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3eb8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    3ebc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3ebf:	75 68                	jne    3f29 <fwp_rc_wide_dup+0xf9>
    3ec1:	bf 18 00 00 00       	mov    $0x18,%edi
    3ec6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ecb:	4c 89 04 24          	mov    %r8,(%rsp)
    3ecf:	e8 ac e6 ff ff       	call   2580 <malloc@plt>
    3ed4:	4c 8b 04 24          	mov    (%rsp),%r8
    3ed8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3edd:	48 85 c0             	test   %rax,%rax
    3ee0:	74 5f                	je     3f41 <fwp_rc_wide_dup+0x111>
    3ee2:	48 89 08             	mov    %rcx,(%rax)
    3ee5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    3eec:	00 
    3eed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    3ef4:	00 
    3ef5:	49 89 00             	mov    %rax,(%r8)
    3ef8:	c6 01 ff             	movb   $0xff,(%rcx)
    3efb:	48 83 05 25 a4 01 00 	addq   $0x1,0x1a425(%rip)        # 1e328 <fwp_heap+0x1c48>
    3f02:	01 
    3f03:	48 83 c4 18          	add    $0x18,%rsp
    3f07:	c3                   	ret
    3f08:	80 3f fe             	cmpb   $0xfe,(%rdi)
    3f0b:	75 13                	jne    3f20 <fwp_rc_wide_dup+0xf0>
    3f0d:	48 85 c0             	test   %rax,%rax
    3f10:	74 af                	je     3ec1 <fwp_rc_wide_dup+0x91>
    3f12:	48 8d 3d 6f 53 00 00 	lea    0x536f(%rip),%rdi        # 9288 <_IO_stdin_used+0x288>
    3f19:	e8 02 f2 ff ff       	call   3120 <fwp_trap>
    3f1e:	66 90                	xchg   %ax,%ax
    3f20:	48 85 c0             	test   %rax,%rax
    3f23:	0f 85 6d ff ff ff    	jne    3e96 <fwp_rc_wide_dup+0x66>
    3f29:	48 8d 3d 80 53 00 00 	lea    0x5380(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    3f30:	e8 eb f1 ff ff       	call   3120 <fwp_trap>
    3f35:	48 8d 3d 69 51 00 00 	lea    0x5169(%rip),%rdi        # 90a5 <_IO_stdin_used+0xa5>
    3f3c:	e8 df f1 ff ff       	call   3120 <fwp_trap>
    3f41:	e8 2a ed ff ff       	call   2c70 <fwp_heap_oom>
    3f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f4d:	00 00 00 

0000000000003f50 <fwp_rc_forget_slot>:
    3f50:	80 3f ff             	cmpb   $0xff,(%rdi)
    3f53:	74 0b                	je     3f60 <fwp_rc_forget_slot+0x10>
    3f55:	c3                   	ret
    3f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f5d:	00 00 00 
    3f60:	48 89 f8             	mov    %rdi,%rax
    3f63:	48 83 ec 08          	sub    $0x8,%rsp
    3f67:	48 89 fa             	mov    %rdi,%rdx
    3f6a:	48 c1 e8 11          	shr    $0x11,%rax
    3f6e:	48 31 f8             	xor    %rdi,%rax
    3f71:	48 89 c1             	mov    %rax,%rcx
    3f74:	48 c1 e9 09          	shr    $0x9,%rcx
    3f78:	48 31 c8             	xor    %rcx,%rax
    3f7b:	48 8d 0d 5e 87 01 00 	lea    0x1875e(%rip),%rcx        # 1c6e0 <fwp_heap>
    3f82:	0f b6 c0             	movzbl %al,%eax
    3f85:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f8c:	00 
    3f8d:	48 85 ff             	test   %rdi,%rdi
    3f90:	74 3c                	je     3fce <fwp_rc_forget_slot+0x7e>
    3f92:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f99:	00 
    3f9a:	48 8b 01             	mov    (%rcx),%rax
    3f9d:	eb 11                	jmp    3fb0 <fwp_rc_forget_slot+0x60>
    3f9f:	90                   	nop
    3fa0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3fa4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3fa8:	48 85 ff             	test   %rdi,%rdi
    3fab:	74 21                	je     3fce <fwp_rc_forget_slot+0x7e>
    3fad:	48 89 f8             	mov    %rdi,%rax
    3fb0:	48 3b 10             	cmp    (%rax),%rdx
    3fb3:	75 eb                	jne    3fa0 <fwp_rc_forget_slot+0x50>
    3fb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fb9:	48 89 01             	mov    %rax,(%rcx)
    3fbc:	e8 df e3 ff ff       	call   23a0 <free@plt>
    3fc1:	48 83 2d 5f a3 01 00 	subq   $0x1,0x1a35f(%rip)        # 1e328 <fwp_heap+0x1c48>
    3fc8:	01 
    3fc9:	48 83 c4 08          	add    $0x8,%rsp
    3fcd:	c3                   	ret
    3fce:	48 8d 3d db 52 00 00 	lea    0x52db(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    3fd5:	e8 46 f1 ff ff       	call   3120 <fwp_trap>
    3fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003fe0 <fwp_rc_prepare_chunk>:
    3fe0:	48 83 3d 40 a3 01 00 	cmpq   $0x0,0x1a340(%rip)        # 1e328 <fwp_heap+0x1c48>
    3fe7:	00 
    3fe8:	41 54                	push   %r12
    3fea:	49 89 f4             	mov    %rsi,%r12
    3fed:	55                   	push   %rbp
    3fee:	48 89 fd             	mov    %rdi,%rbp
    3ff1:	53                   	push   %rbx
    3ff2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3ff5:	0f 84 7d 00 00 00    	je     4078 <fwp_rc_prepare_chunk+0x98>
    3ffb:	31 db                	xor    %ebx,%ebx
    3ffd:	85 c0                	test   %eax,%eax
    3fff:	75 5f                	jne    4060 <fwp_rc_prepare_chunk+0x80>
    4001:	48 85 f6             	test   %rsi,%rsi
    4004:	74 7c                	je     4082 <fwp_rc_prepare_chunk+0xa2>
    4006:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    400a:	e8 91 e3 ff ff       	call   23a0 <free@plt>
    400f:	90                   	nop
    4010:	be 01 00 00 00       	mov    $0x1,%esi
    4015:	4c 89 e7             	mov    %r12,%rdi
    4018:	e8 e3 e4 ff ff       	call   2500 <calloc@plt>
    401d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    4021:	48 85 c0             	test   %rax,%rax
    4024:	0f 85 87 00 00 00    	jne    40b1 <fwp_rc_prepare_chunk+0xd1>
    402a:	e8 41 ec ff ff       	call   2c70 <fwp_heap_oom>
    402f:	90                   	nop
    4030:	e8 1b ff ff ff       	call   3f50 <fwp_rc_forget_slot>
    4035:	8b 45 1c             	mov    0x1c(%rbp),%eax
    4038:	48 83 c3 01          	add    $0x1,%rbx
    403c:	48 39 c3             	cmp    %rax,%rbx
    403f:	73 37                	jae    4078 <fwp_rc_prepare_chunk+0x98>
    4041:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4048:	00 00 
    404a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4051:	00 00 00 00 
    4055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    405c:	00 00 00 00 
    4060:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4064:	48 01 df             	add    %rbx,%rdi
    4067:	80 3f ff             	cmpb   $0xff,(%rdi)
    406a:	74 c4                	je     4030 <fwp_rc_prepare_chunk+0x50>
    406c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    406f:	48 83 c3 01          	add    $0x1,%rbx
    4073:	48 39 c3             	cmp    %rax,%rbx
    4076:	72 e8                	jb     4060 <fwp_rc_prepare_chunk+0x80>
    4078:	49 39 c4             	cmp    %rax,%r12
    407b:	75 13                	jne    4090 <fwp_rc_prepare_chunk+0xb0>
    407d:	4d 85 e4             	test   %r12,%r12
    4080:	75 46                	jne    40c8 <fwp_rc_prepare_chunk+0xe8>
    4082:	5b                   	pop    %rbx
    4083:	5d                   	pop    %rbp
    4084:	41 5c                	pop    %r12
    4086:	c3                   	ret
    4087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    408e:	00 00 
    4090:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4094:	48 29 05 95 a2 01 00 	sub    %rax,0x1a295(%rip)        # 1e330 <fwp_heap+0x1c50>
    409b:	e8 00 e3 ff ff       	call   23a0 <free@plt>
    40a0:	4d 85 e4             	test   %r12,%r12
    40a3:	0f 85 67 ff ff ff    	jne    4010 <fwp_rc_prepare_chunk+0x30>
    40a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    40b0:	00 
    40b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    40b5:	5b                   	pop    %rbx
    40b6:	4c 01 25 73 a2 01 00 	add    %r12,0x1a273(%rip)        # 1e330 <fwp_heap+0x1c50>
    40bd:	5d                   	pop    %rbp
    40be:	41 5c                	pop    %r12
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    40cc:	5b                   	pop    %rbx
    40cd:	4c 89 e2             	mov    %r12,%rdx
    40d0:	31 f6                	xor    %esi,%esi
    40d2:	5d                   	pop    %rbp
    40d3:	41 5c                	pop    %r12
    40d5:	e9 c6 e3 ff ff       	jmp    24a0 <memset@plt>
    40da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040e0 <fwp_heap_refill>:
    40e0:	41 56                	push   %r14
    40e2:	41 89 d6             	mov    %edx,%r14d
    40e5:	41 55                	push   %r13
    40e7:	41 89 f5             	mov    %esi,%r13d
    40ea:	41 54                	push   %r12
    40ec:	49 89 fc             	mov    %rdi,%r12
    40ef:	bf 01 00 00 00       	mov    $0x1,%edi
    40f4:	55                   	push   %rbp
    40f5:	53                   	push   %rbx
    40f6:	e8 a5 ec ff ff       	call   2da0 <fwp_heap_chunks>
    40fb:	48 89 c3             	mov    %rax,%rbx
    40fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4102:	48 8b 05 cf 99 01 00 	mov    0x199cf(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    4109:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    410d:	48 8d 05 cc 85 01 00 	lea    0x185cc(%rip),%rax        # 1c6e0 <fwp_heap>
    4114:	31 d2                	xor    %edx,%edx
    4116:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    411a:	48 89 ef             	mov    %rbp,%rdi
    411d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    4121:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    4125:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    412c:	00 
    412d:	b8 00 00 01 00       	mov    $0x10000,%eax
    4132:	f7 f1                	div    %ecx
    4134:	31 d2                	xor    %edx,%edx
    4136:	66 0f 6e c1          	movd   %ecx,%xmm0
    413a:	66 0f 6e c8          	movd   %eax,%xmm1
    413e:	89 c6                	mov    %eax,%esi
    4140:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4145:	48 01 c8             	add    %rcx,%rax
    4148:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    414c:	48 f7 f1             	div    %rcx
    414f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    4154:	89 45 18             	mov    %eax,0x18(%rbp)
    4157:	e8 84 fe ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    415c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    415f:	48 89 d8             	mov    %rbx,%rax
    4162:	48 c1 e0 10          	shl    $0x10,%rax
    4166:	48 03 05 23 99 01 00 	add    0x19923(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    416d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    4171:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    4176:	8b 55 08             	mov    0x8(%rbp),%edx
    4179:	48 0f af d1          	imul   %rcx,%rdx
    417d:	48 01 c2             	add    %rax,%rdx
    4180:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4185:	5b                   	pop    %rbx
    4186:	5d                   	pop    %rbp
    4187:	41 5c                	pop    %r12
    4189:	41 5d                	pop    %r13
    418b:	41 5e                	pop    %r14
    418d:	c3                   	ret
    418e:	66 90                	xchg   %ax,%ax

0000000000004190 <fwp_mem_free>:
    4190:	48 85 ff             	test   %rdi,%rdi
    4193:	0f 84 17 02 00 00    	je     43b0 <fwp_mem_free+0x220>
    4199:	48 8b 35 f0 98 01 00 	mov    0x198f0(%rip),%rsi        # 1da90 <fwp_heap+0x13b0>
    41a0:	48 8b 05 11 99 01 00 	mov    0x19911(%rip),%rax        # 1dab8 <fwp_heap+0x13d8>
    41a7:	48 89 fa             	mov    %rdi,%rdx
    41aa:	48 29 f2             	sub    %rsi,%rdx
    41ad:	48 c1 e0 10          	shl    $0x10,%rax
    41b1:	48 39 c2             	cmp    %rax,%rdx
    41b4:	0f 83 f6 01 00 00    	jae    43b0 <fwp_mem_free+0x220>
    41ba:	49 89 d1             	mov    %rdx,%r9
    41bd:	49 c1 e9 10          	shr    $0x10,%r9
    41c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    41c5:	48 c1 e0 03          	shl    $0x3,%rax
    41c9:	49 89 c0             	mov    %rax,%r8
    41cc:	4c 03 05 05 99 01 00 	add    0x19905(%rip),%r8        # 1dad8 <fwp_heap+0x13f8>
    41d3:	0f 84 d7 01 00 00    	je     43b0 <fwp_mem_free+0x220>
    41d9:	48 83 ec 38          	sub    $0x38,%rsp
    41dd:	48 89 f9             	mov    %rdi,%rcx
    41e0:	41 0f b6 38          	movzbl (%r8),%edi
    41e4:	40 80 ff 01          	cmp    $0x1,%dil
    41e8:	74 16                	je     4200 <fwp_mem_free+0x70>
    41ea:	40 80 ff 02          	cmp    $0x2,%dil
    41ee:	0f 84 94 00 00 00    	je     4288 <fwp_mem_free+0xf8>
    41f4:	48 83 c4 38          	add    $0x38,%rsp
    41f8:	c3                   	ret
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4200:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4204:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4209:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    420e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4212:	4d 85 d2             	test   %r10,%r10
    4215:	74 1d                	je     4234 <fwp_mem_free+0xa4>
    4217:	0f b7 c1             	movzwl %cx,%eax
    421a:	31 d2                	xor    %edx,%edx
    421c:	48 f7 f7             	div    %rdi
    421f:	49 01 c2             	add    %rax,%r10
    4222:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4226:	0f 84 44 01 00 00    	je     4370 <fwp_mem_free+0x1e0>
    422c:	41 c6 02 00          	movb   $0x0,(%r10)
    4230:	41 8b 78 04          	mov    0x4(%r8),%edi
    4234:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    423b:	49 63 c1             	movslq %r9d,%rax
    423e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4242:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4246:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    424b:	f2 0f 58 05 cd 98 01 	addsd  0x198cd(%rip),%xmm0        # 1db20 <fwp_heap+0x1440>
    4252:	00 
    4253:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4257:	48 8d 05 82 84 01 00 	lea    0x18482(%rip),%rax        # 1c6e0 <fwp_heap>
    425e:	48 01 d0             	add    %rdx,%rax
    4261:	48 8b 10             	mov    (%rax),%rdx
    4264:	48 f7 d2             	not    %rdx
    4267:	48 89 11             	mov    %rdx,(%rcx)
    426a:	48 89 08             	mov    %rcx,(%rax)
    426d:	48 29 3d 8c 98 01 00 	sub    %rdi,0x1988c(%rip)        # 1db00 <fwp_heap+0x1420>
    4274:	f2 0f 11 05 a4 98 01 	movsd  %xmm0,0x198a4(%rip)        # 1db20 <fwp_heap+0x1440>
    427b:	00 
    427c:	48 83 c4 38          	add    $0x38,%rsp
    4280:	c3                   	ret
    4281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4288:	66 31 d2             	xor    %dx,%dx
    428b:	48 01 d6             	add    %rdx,%rsi
    428e:	48 39 f1             	cmp    %rsi,%rcx
    4291:	0f 85 5d ff ff ff    	jne    41f4 <fwp_mem_free+0x64>
    4297:	49 8b 50 10          	mov    0x10(%r8),%rdx
    429b:	48 29 15 5e 98 01 00 	sub    %rdx,0x1985e(%rip)        # 1db00 <fwp_heap+0x1420>
    42a2:	48 85 d2             	test   %rdx,%rdx
    42a5:	0f 88 a5 00 00 00    	js     4350 <fwp_mem_free+0x1c0>
    42ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    42b4:	f2 0f 58 05 64 98 01 	addsd  0x19864(%rip),%xmm0        # 1db20 <fwp_heap+0x1440>
    42bb:	00 
    42bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    42c0:	f2 0f 11 05 58 98 01 	movsd  %xmm0,0x19858(%rip)        # 1db20 <fwp_heap+0x1440>
    42c7:	00 
    42c8:	48 85 d2             	test   %rdx,%rdx
    42cb:	74 0c                	je     42d9 <fwp_mem_free+0x149>
    42cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    42d0:	0f 84 db 00 00 00    	je     43b1 <fwp_mem_free+0x221>
    42d6:	c6 02 00             	movb   $0x0,(%rdx)
    42d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    42dd:	48 85 c9             	test   %rcx,%rcx
    42e0:	74 3e                	je     4320 <fwp_mem_free+0x190>
    42e2:	48 8b 15 ef 97 01 00 	mov    0x197ef(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    42e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    42ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    42f1:	48 01 d0             	add    %rdx,%rax
    42f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    42f8:	48 89 d6             	mov    %rdx,%rsi
    42fb:	48 29 c6             	sub    %rax,%rsi
    42fe:	83 e6 08             	and    $0x8,%esi
    4301:	74 0d                	je     4310 <fwp_mem_free+0x180>
    4303:	c6 00 00             	movb   $0x0,(%rax)
    4306:	48 83 c0 28          	add    $0x28,%rax
    430a:	48 39 c2             	cmp    %rax,%rdx
    430d:	74 11                	je     4320 <fwp_mem_free+0x190>
    430f:	90                   	nop
    4310:	c6 00 00             	movb   $0x0,(%rax)
    4313:	48 83 c0 50          	add    $0x50,%rax
    4317:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    431b:	48 39 c2             	cmp    %rax,%rdx
    431e:	75 f0                	jne    4310 <fwp_mem_free+0x180>
    4320:	48 01 0d e9 97 01 00 	add    %rcx,0x197e9(%rip)        # 1db10 <fwp_heap+0x1430>
    4327:	4c 3b 0d a2 97 01 00 	cmp    0x197a2(%rip),%r9        # 1dad0 <fwp_heap+0x13f0>
    432e:	73 07                	jae    4337 <fwp_mem_free+0x1a7>
    4330:	4c 89 0d 99 97 01 00 	mov    %r9,0x19799(%rip)        # 1dad0 <fwp_heap+0x13f0>
    4337:	4c 3b 0d 8a 97 01 00 	cmp    0x1978a(%rip),%r9        # 1dac8 <fwp_heap+0x13e8>
    433e:	0f 83 b0 fe ff ff    	jae    41f4 <fwp_mem_free+0x64>
    4344:	4c 89 0d 7d 97 01 00 	mov    %r9,0x1977d(%rip)        # 1dac8 <fwp_heap+0x13e8>
    434b:	e9 a4 fe ff ff       	jmp    41f4 <fwp_mem_free+0x64>
    4350:	48 89 d1             	mov    %rdx,%rcx
    4353:	83 e2 01             	and    $0x1,%edx
    4356:	66 0f ef c0          	pxor   %xmm0,%xmm0
    435a:	48 d1 e9             	shr    $1,%rcx
    435d:	48 09 d1             	or     %rdx,%rcx
    4360:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    4365:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4369:	e9 46 ff ff ff       	jmp    42b4 <fwp_mem_free+0x124>
    436e:	66 90                	xchg   %ax,%ax
    4370:	4c 89 d7             	mov    %r10,%rdi
    4373:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    4378:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    437d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4382:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4386:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    438b:	e8 c0 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    4390:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4395:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    439a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    439f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    43a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    43a9:	e9 7e fe ff ff       	jmp    422c <fwp_mem_free+0x9c>
    43ae:	66 90                	xchg   %ax,%ax
    43b0:	c3                   	ret
    43b1:	48 89 d7             	mov    %rdx,%rdi
    43b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    43b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    43be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    43c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    43c8:	e8 83 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    43cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    43d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    43d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    43dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    43e1:	e9 f0 fe ff ff       	jmp    42d6 <fwp_mem_free+0x146>
    43e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    43ed:	00 00 00 

00000000000043f0 <fwp_heap_alloc_big>:
    43f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    43f7:	00 00 40 
    43fa:	41 57                	push   %r15
    43fc:	41 56                	push   %r14
    43fe:	41 55                	push   %r13
    4400:	41 54                	push   %r12
    4402:	55                   	push   %rbp
    4403:	53                   	push   %rbx
    4404:	48 83 ec 08          	sub    $0x8,%rsp
    4408:	48 39 f8             	cmp    %rdi,%rax
    440b:	0f 82 fa 00 00 00    	jb     450b <fwp_heap_alloc_big+0x11b>
    4411:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4418:	49 89 fd             	mov    %rdi,%r13
    441b:	41 89 f6             	mov    %esi,%r14d
    441e:	48 c1 ed 10          	shr    $0x10,%rbp
    4422:	48 89 ef             	mov    %rbp,%rdi
    4425:	e8 76 e9 ff ff       	call   2da0 <fwp_heap_chunks>
    442a:	be 01 00 00 00       	mov    $0x1,%esi
    442f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4433:	49 89 c4             	mov    %rax,%r12
    4436:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    443d:	00 
    443e:	48 03 3d 93 96 01 00 	add    0x19693(%rip),%rdi        # 1dad8 <fwp_heap+0x13f8>
    4445:	c6 07 02             	movb   $0x2,(%rdi)
    4448:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    444c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    444f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4453:	e8 88 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4458:	48 83 fd 01          	cmp    $0x1,%rbp
    445c:	76 47                	jbe    44a5 <fwp_heap_alloc_big+0xb5>
    445e:	4c 01 e5             	add    %r12,%rbp
    4461:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    4468:	00 
    4469:	4c 8d 3d 70 82 01 00 	lea    0x18270(%rip),%r15        # 1c6e0 <fwp_heap>
    4470:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    4475:	49 c1 e6 03          	shl    $0x3,%r14
    4479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4480:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4487:	31 f6                	xor    %esi,%esi
    4489:	48 01 dd             	add    %rbx,%rbp
    448c:	48 83 c3 28          	add    $0x28,%rbx
    4490:	48 89 ef             	mov    %rbp,%rdi
    4493:	e8 48 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4498:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    449c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    44a0:	49 39 de             	cmp    %rbx,%r14
    44a3:	75 db                	jne    4480 <fwp_heap_alloc_big+0x90>
    44a5:	49 c1 e4 10          	shl    $0x10,%r12
    44a9:	4c 03 25 e0 95 01 00 	add    0x195e0(%rip),%r12        # 1da90 <fwp_heap+0x13b0>
    44b0:	4c 89 ea             	mov    %r13,%rdx
    44b3:	31 f6                	xor    %esi,%esi
    44b5:	4c 89 e7             	mov    %r12,%rdi
    44b8:	e8 e3 df ff ff       	call   24a0 <memset@plt>
    44bd:	4c 89 e8             	mov    %r13,%rax
    44c0:	48 03 05 39 96 01 00 	add    0x19639(%rip),%rax        # 1db00 <fwp_heap+0x1420>
    44c7:	72 42                	jb     450b <fwp_heap_alloc_big+0x11b>
    44c9:	48 39 05 38 96 01 00 	cmp    %rax,0x19638(%rip)        # 1db08 <fwp_heap+0x1428>
    44d0:	48 89 05 29 96 01 00 	mov    %rax,0x19629(%rip)        # 1db00 <fwp_heap+0x1420>
    44d7:	73 07                	jae    44e0 <fwp_heap_alloc_big+0xf0>
    44d9:	48 89 05 28 96 01 00 	mov    %rax,0x19628(%rip)        # 1db08 <fwp_heap+0x1428>
    44e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    44e4:	4c 89 e0             	mov    %r12,%rax
    44e7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    44ec:	f2 0f 58 05 24 96 01 	addsd  0x19624(%rip),%xmm0        # 1db18 <fwp_heap+0x1438>
    44f3:	00 
    44f4:	f2 0f 11 05 1c 96 01 	movsd  %xmm0,0x1961c(%rip)        # 1db18 <fwp_heap+0x1438>
    44fb:	00 
    44fc:	48 83 c4 08          	add    $0x8,%rsp
    4500:	5b                   	pop    %rbx
    4501:	5d                   	pop    %rbp
    4502:	41 5c                	pop    %r12
    4504:	41 5d                	pop    %r13
    4506:	41 5e                	pop    %r14
    4508:	41 5f                	pop    %r15
    450a:	c3                   	ret
    450b:	e8 60 e7 ff ff       	call   2c70 <fwp_heap_oom>

0000000000004510 <fwp_heap_alloc_slow>:
    4510:	53                   	push   %rbx
    4511:	48 89 f9             	mov    %rdi,%rcx
    4514:	41 89 f1             	mov    %esi,%r9d
    4517:	48 83 ec 10          	sub    $0x10,%rsp
    451b:	8b 05 63 95 01 00    	mov    0x19563(%rip),%eax        # 1da84 <fwp_heap+0x13a4>
    4521:	85 c0                	test   %eax,%eax
    4523:	0f 84 c7 00 00 00    	je     45f0 <fwp_heap_alloc_slow+0xe0>
    4529:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4530:	0f 87 dd 00 00 00    	ja     4613 <fwp_heap_alloc_slow+0x103>
    4536:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    453a:	48 8d 3d 9f 81 01 00 	lea    0x1819f(%rip),%rdi        # 1c6e0 <fwp_heap>
    4541:	49 63 f1             	movslq %r9d,%rsi
    4544:	48 c1 e8 04          	shr    $0x4,%rax
    4548:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    454f:	00 00 
    4551:	41 0f b6 c2          	movzbl %r10b,%eax
    4555:	4c 89 d2             	mov    %r10,%rdx
    4558:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    455c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    4563:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    456a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    456e:	48 01 f8             	add    %rdi,%rax
    4571:	4c 8b 00             	mov    (%rax),%r8
    4574:	4d 85 c0             	test   %r8,%r8
    4577:	0f 84 ab 00 00 00    	je     4628 <fwp_heap_alloc_slow+0x118>
    457d:	49 8b 10             	mov    (%r8),%rdx
    4580:	48 f7 d2             	not    %rdx
    4583:	48 89 10             	mov    %rdx,(%rax)
    4586:	41 83 f9 01          	cmp    $0x1,%r9d
    458a:	4c 89 c7             	mov    %r8,%rdi
    458d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4591:	31 f6                	xor    %esi,%esi
    4593:	48 89 ca             	mov    %rcx,%rdx
    4596:	e8 05 df ff ff       	call   24a0 <memset@plt>
    459b:	49 89 c0             	mov    %rax,%r8
    459e:	48 89 d8             	mov    %rbx,%rax
    45a1:	48 03 05 58 95 01 00 	add    0x19558(%rip),%rax        # 1db00 <fwp_heap+0x1420>
    45a8:	0f 82 d9 00 00 00    	jb     4687 <fwp_heap_alloc_slow+0x177>
    45ae:	48 39 05 53 95 01 00 	cmp    %rax,0x19553(%rip)        # 1db08 <fwp_heap+0x1428>
    45b5:	48 89 05 44 95 01 00 	mov    %rax,0x19544(%rip)        # 1db00 <fwp_heap+0x1420>
    45bc:	73 07                	jae    45c5 <fwp_heap_alloc_slow+0xb5>
    45be:	48 89 05 43 95 01 00 	mov    %rax,0x19543(%rip)        # 1db08 <fwp_heap+0x1428>
    45c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    45c9:	4c 89 c0             	mov    %r8,%rax
    45cc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    45d1:	f2 0f 58 05 3f 95 01 	addsd  0x1953f(%rip),%xmm0        # 1db18 <fwp_heap+0x1438>
    45d8:	00 
    45d9:	f2 0f 11 05 37 95 01 	movsd  %xmm0,0x19537(%rip)        # 1db18 <fwp_heap+0x1438>
    45e0:	00 
    45e1:	48 83 c4 10          	add    $0x10,%rsp
    45e5:	5b                   	pop    %rbx
    45e6:	c3                   	ret
    45e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    45ee:	00 00 
    45f0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    45f4:	48 89 3c 24          	mov    %rdi,(%rsp)
    45f8:	e8 73 f2 ff ff       	call   3870 <fwp_heap_init>
    45fd:	48 8b 0c 24          	mov    (%rsp),%rcx
    4601:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4606:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    460d:	0f 86 23 ff ff ff    	jbe    4536 <fwp_heap_alloc_slow+0x26>
    4613:	48 83 c4 10          	add    $0x10,%rsp
    4617:	44 89 ce             	mov    %r9d,%esi
    461a:	48 89 cf             	mov    %rcx,%rdi
    461d:	5b                   	pop    %rbx
    461e:	e9 cd fd ff ff       	jmp    43f0 <fwp_heap_alloc_big>
    4623:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4628:	4c 8b 40 08          	mov    0x8(%rax),%r8
    462c:	4d 85 c0             	test   %r8,%r8
    462f:	74 1f                	je     4650 <fwp_heap_alloc_slow+0x140>
    4631:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4635:	4d 29 c3             	sub    %r8,%r11
    4638:	49 39 db             	cmp    %rbx,%r11
    463b:	72 13                	jb     4650 <fwp_heap_alloc_slow+0x140>
    463d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4641:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4645:	e9 3c ff ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    464a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4650:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4657:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    465b:	44 89 ca             	mov    %r9d,%edx
    465e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4663:	44 89 0c 24          	mov    %r9d,(%rsp)
    4667:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    466b:	44 89 d6             	mov    %r10d,%esi
    466e:	48 01 c7             	add    %rax,%rdi
    4671:	e8 6a fa ff ff       	call   40e0 <fwp_heap_refill>
    4676:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    467b:	44 8b 0c 24          	mov    (%rsp),%r9d
    467f:	49 89 c0             	mov    %rax,%r8
    4682:	e9 ff fe ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    4687:	e8 e4 e5 ff ff       	call   2c70 <fwp_heap_oom>
    468c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004690 <fwp_rc_share>:
    4690:	48 8b 05 21 94 01 00 	mov    0x19421(%rip),%rax        # 1dab8 <fwp_heap+0x13d8>
    4697:	48 2b 3d f2 93 01 00 	sub    0x193f2(%rip),%rdi        # 1da90 <fwp_heap+0x13b0>
    469e:	48 c1 e0 10          	shl    $0x10,%rax
    46a2:	48 39 c7             	cmp    %rax,%rdi
    46a5:	73 4a                	jae    46f1 <fwp_rc_share+0x61>
    46a7:	48 89 f8             	mov    %rdi,%rax
    46aa:	48 c1 e8 10          	shr    $0x10,%rax
    46ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    46b2:	48 8b 05 1f 94 01 00 	mov    0x1941f(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    46b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    46bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    46c1:	48 85 d2             	test   %rdx,%rdx
    46c4:	74 2b                	je     46f1 <fwp_rc_share+0x61>
    46c6:	0f b6 08             	movzbl (%rax),%ecx
    46c9:	80 f9 02             	cmp    $0x2,%cl
    46cc:	74 2a                	je     46f8 <fwp_rc_share+0x68>
    46ce:	80 f9 01             	cmp    $0x1,%cl
    46d1:	75 1e                	jne    46f1 <fwp_rc_share+0x61>
    46d3:	8b 48 18             	mov    0x18(%rax),%ecx
    46d6:	0f b7 ff             	movzwl %di,%edi
    46d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    46dc:	48 0f af f9          	imul   %rcx,%rdi
    46e0:	48 c1 ef 20          	shr    $0x20,%rdi
    46e4:	48 39 c7             	cmp    %rax,%rdi
    46e7:	73 08                	jae    46f1 <fwp_rc_share+0x61>
    46e9:	48 01 fa             	add    %rdi,%rdx
    46ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    46ef:	75 0d                	jne    46fe <fwp_rc_share+0x6e>
    46f1:	c3                   	ret
    46f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    46f8:	66 85 ff             	test   %di,%di
    46fb:	74 ef                	je     46ec <fwp_rc_share+0x5c>
    46fd:	c3                   	ret
    46fe:	50                   	push   %rax
    46ff:	48 8d 3d d2 4b 00 00 	lea    0x4bd2(%rip),%rdi        # 92d8 <_IO_stdin_used+0x2d8>
    4706:	e8 15 ea ff ff       	call   3120 <fwp_trap>
    470b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000004710 <e69>:
    4710:	f3 0f 1e fa          	endbr64
    4714:	53                   	push   %rbx
    4715:	f2 0f 10 05 53 4d 00 	movsd  0x4d53(%rip),%xmm0        # 9470 <msg.3+0x20>
    471c:	00 
    471d:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    4721:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4726:	48 89 df             	mov    %rbx,%rdi
    4729:	e8 62 ff ff ff       	call   4690 <fwp_rc_share>
    472e:	48 89 d8             	mov    %rbx,%rax
    4731:	5b                   	pop    %rbx
    4732:	c3                   	ret
    4733:	66 90                	xchg   %ax,%ax
    4735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    473c:	00 00 00 00 

0000000000004740 <e45>:
    4740:	f3 0f 1e fa          	endbr64
    4744:	53                   	push   %rbx
    4745:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4749:	f2 0f 58 47 08       	addsd  0x8(%rdi),%xmm0
    474e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4753:	48 89 df             	mov    %rbx,%rdi
    4756:	e8 35 ff ff ff       	call   4690 <fwp_rc_share>
    475b:	48 89 d8             	mov    %rbx,%rax
    475e:	5b                   	pop    %rbx
    475f:	c3                   	ret

0000000000004760 <e32>:
    4760:	f3 0f 1e fa          	endbr64
    4764:	53                   	push   %rbx
    4765:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    476a:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    476e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4773:	48 89 df             	mov    %rbx,%rdi
    4776:	e8 15 ff ff ff       	call   4690 <fwp_rc_share>
    477b:	48 89 d8             	mov    %rbx,%rax
    477e:	5b                   	pop    %rbx
    477f:	c3                   	ret

0000000000004780 <fwp_rc_dup>:
    4780:	f3 0f 1e fa          	endbr64
    4784:	48 8b 05 2d 93 01 00 	mov    0x1932d(%rip),%rax        # 1dab8 <fwp_heap+0x13d8>
    478b:	48 2b 3d fe 92 01 00 	sub    0x192fe(%rip),%rdi        # 1da90 <fwp_heap+0x13b0>
    4792:	48 c1 e0 10          	shl    $0x10,%rax
    4796:	48 39 c7             	cmp    %rax,%rdi
    4799:	73 56                	jae    47f1 <fwp_rc_dup+0x71>
    479b:	48 89 f8             	mov    %rdi,%rax
    479e:	48 c1 e8 10          	shr    $0x10,%rax
    47a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    47a6:	48 8b 05 2b 93 01 00 	mov    0x1932b(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    47ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    47b1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    47b5:	48 85 c0             	test   %rax,%rax
    47b8:	74 37                	je     47f1 <fwp_rc_dup+0x71>
    47ba:	0f b6 0a             	movzbl (%rdx),%ecx
    47bd:	80 f9 02             	cmp    $0x2,%cl
    47c0:	74 36                	je     47f8 <fwp_rc_dup+0x78>
    47c2:	80 f9 01             	cmp    $0x1,%cl
    47c5:	75 2a                	jne    47f1 <fwp_rc_dup+0x71>
    47c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    47ca:	0f b7 ff             	movzwl %di,%edi
    47cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    47d0:	48 0f af f9          	imul   %rcx,%rdi
    47d4:	48 c1 ef 20          	shr    $0x20,%rdi
    47d8:	48 39 d7             	cmp    %rdx,%rdi
    47db:	73 14                	jae    47f1 <fwp_rc_dup+0x71>
    47dd:	48 01 f8             	add    %rdi,%rax
    47e0:	0f b6 10             	movzbl (%rax),%edx
    47e3:	84 d2                	test   %dl,%dl
    47e5:	74 0a                	je     47f1 <fwp_rc_dup+0x71>
    47e7:	80 fa fd             	cmp    $0xfd,%dl
    47ea:	77 14                	ja     4800 <fwp_rc_dup+0x80>
    47ec:	83 c2 01             	add    $0x1,%edx
    47ef:	88 10                	mov    %dl,(%rax)
    47f1:	c3                   	ret
    47f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    47f8:	66 85 ff             	test   %di,%di
    47fb:	74 e3                	je     47e0 <fwp_rc_dup+0x60>
    47fd:	c3                   	ret
    47fe:	66 90                	xchg   %ax,%ax
    4800:	48 89 c7             	mov    %rax,%rdi
    4803:	e9 28 f6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    4808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    480f:	00 

0000000000004810 <fwp_task_dispose>:
    4810:	53                   	push   %rbx
    4811:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4815:	0f 84 eb de ff ff    	je     2706 <fwp_task_dispose.cold>
    481b:	48 89 fb             	mov    %rdi,%rbx
    481e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4823:	0f 85 dd de ff ff    	jne    2706 <fwp_task_dispose.cold>
    4829:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    482d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4834:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    483b:	00 
    483c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4840:	48 85 ff             	test   %rdi,%rdi
    4843:	74 07                	je     484c <fwp_task_dispose+0x3c>
    4845:	48 85 c0             	test   %rax,%rax
    4848:	74 02                	je     484c <fwp_task_dispose+0x3c>
    484a:	ff d0                	call   *%rax
    484c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4853:	e8 38 f9 ff ff       	call   4190 <fwp_mem_free>
    4858:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    485f:	00 00 00 00 
    4863:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4867:	74 6f                	je     48d8 <fwp_task_dispose+0xc8>
    4869:	48 8b 15 48 92 01 00 	mov    0x19248(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    4870:	48 89 d8             	mov    %rbx,%rax
    4873:	48 2b 05 16 92 01 00 	sub    0x19216(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    487a:	48 c1 e2 10          	shl    $0x10,%rdx
    487e:	48 39 d0             	cmp    %rdx,%rax
    4881:	73 4c                	jae    48cf <fwp_task_dispose+0xbf>
    4883:	48 89 c2             	mov    %rax,%rdx
    4886:	48 c1 ea 10          	shr    $0x10,%rdx
    488a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    488e:	48 8b 15 43 92 01 00 	mov    0x19243(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    4895:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4899:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    489d:	48 85 c9             	test   %rcx,%rcx
    48a0:	74 2d                	je     48cf <fwp_task_dispose+0xbf>
    48a2:	0f b6 32             	movzbl (%rdx),%esi
    48a5:	40 80 fe 02          	cmp    $0x2,%sil
    48a9:	74 3d                	je     48e8 <fwp_task_dispose+0xd8>
    48ab:	40 80 fe 01          	cmp    $0x1,%sil
    48af:	75 1e                	jne    48cf <fwp_task_dispose+0xbf>
    48b1:	8b 72 18             	mov    0x18(%rdx),%esi
    48b4:	0f b7 c0             	movzwl %ax,%eax
    48b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    48ba:	48 0f af c6          	imul   %rsi,%rax
    48be:	48 c1 e8 20          	shr    $0x20,%rax
    48c2:	48 39 d0             	cmp    %rdx,%rax
    48c5:	73 08                	jae    48cf <fwp_task_dispose+0xbf>
    48c7:	48 01 c1             	add    %rax,%rcx
    48ca:	80 39 01             	cmpb   $0x1,(%rcx)
    48cd:	74 09                	je     48d8 <fwp_task_dispose+0xc8>
    48cf:	5b                   	pop    %rbx
    48d0:	c3                   	ret
    48d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d8:	48 89 df             	mov    %rbx,%rdi
    48db:	5b                   	pop    %rbx
    48dc:	e9 af f8 ff ff       	jmp    4190 <fwp_mem_free>
    48e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48e8:	66 85 c0             	test   %ax,%ax
    48eb:	74 dd                	je     48ca <fwp_task_dispose+0xba>
    48ed:	5b                   	pop    %rbx
    48ee:	c3                   	ret
    48ef:	90                   	nop

00000000000048f0 <fwp_free_zombie>:
    48f0:	48 8b 15 b9 7d 01 00 	mov    0x17db9(%rip),%rdx        # 1c6b0 <fwp_zombie>
    48f7:	48 85 d2             	test   %rdx,%rdx
    48fa:	0f 84 98 00 00 00    	je     4998 <fwp_free_zombie+0xa8>
    4900:	48 3b 15 b9 7d 01 00 	cmp    0x17db9(%rip),%rdx        # 1c6c0 <fwp_cur>
    4907:	0f 84 8b 00 00 00    	je     4998 <fwp_free_zombie+0xa8>
    490d:	48 83 ec 18          	sub    $0x18,%rsp
    4911:	48 63 05 84 77 01 00 	movslq 0x17784(%rip),%rax        # 1c09c <fwp_stack_pool_n>
    4918:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    491c:	83 f8 3f             	cmp    $0x3f,%eax
    491f:	7f 7f                	jg     49a0 <fwp_free_zombie+0xb0>
    4921:	8d 48 01             	lea    0x1(%rax),%ecx
    4924:	89 0d 72 77 01 00    	mov    %ecx,0x17772(%rip)        # 1c09c <fwp_stack_pool_n>
    492a:	48 8d 0d 6f 77 01 00 	lea    0x1776f(%rip),%rcx        # 1c0a0 <fwp_stack_pool>
    4931:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4935:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    493c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4940:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4947:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    494b:	48 85 c9             	test   %rcx,%rcx
    494e:	0f 84 fc 00 00 00    	je     4a50 <fwp_free_zombie+0x160>
    4954:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    495b:	48 85 c0             	test   %rax,%rax
    495e:	74 07                	je     4967 <fwp_free_zombie+0x77>
    4960:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4967:	8b 42 5c             	mov    0x5c(%rdx),%eax
    496a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    496e:	48 c7 05 37 7d 01 00 	movq   $0x0,0x17d37(%rip)        # 1c6b0 <fwp_zombie>
    4975:	00 00 00 00 
    4979:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4980:	85 c0                	test   %eax,%eax
    4982:	74 34                	je     49b8 <fwp_free_zombie+0xc8>
    4984:	83 f8 01             	cmp    $0x1,%eax
    4987:	0f 84 b3 00 00 00    	je     4a40 <fwp_free_zombie+0x150>
    498d:	48 83 c4 18          	add    $0x18,%rsp
    4991:	c3                   	ret
    4992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4998:	c3                   	ret
    4999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    49a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    49a9:	e8 02 dc ff ff       	call   25b0 <munmap@plt>
    49ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    49b3:	eb 80                	jmp    4935 <fwp_free_zombie+0x45>
    49b5:	0f 1f 00             	nopl   (%rax)
    49b8:	48 8b 0d f9 90 01 00 	mov    0x190f9(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    49bf:	48 89 d0             	mov    %rdx,%rax
    49c2:	48 2b 05 c7 90 01 00 	sub    0x190c7(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    49c9:	48 c1 e1 10          	shl    $0x10,%rcx
    49cd:	48 39 c8             	cmp    %rcx,%rax
    49d0:	73 bb                	jae    498d <fwp_free_zombie+0x9d>
    49d2:	48 89 c1             	mov    %rax,%rcx
    49d5:	48 c1 e9 10          	shr    $0x10,%rcx
    49d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    49dd:	48 8b 0d f4 90 01 00 	mov    0x190f4(%rip),%rcx        # 1dad8 <fwp_heap+0x13f8>
    49e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    49e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    49ec:	48 85 c9             	test   %rcx,%rcx
    49ef:	74 9c                	je     498d <fwp_free_zombie+0x9d>
    49f1:	0f b6 3e             	movzbl (%rsi),%edi
    49f4:	40 80 ff 02          	cmp    $0x2,%dil
    49f8:	74 66                	je     4a60 <fwp_free_zombie+0x170>
    49fa:	40 80 ff 01          	cmp    $0x1,%dil
    49fe:	75 8d                	jne    498d <fwp_free_zombie+0x9d>
    4a00:	8b 7e 18             	mov    0x18(%rsi),%edi
    4a03:	0f b7 c0             	movzwl %ax,%eax
    4a06:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4a09:	48 0f af c7          	imul   %rdi,%rax
    4a0d:	48 c1 e8 20          	shr    $0x20,%rax
    4a11:	48 39 f0             	cmp    %rsi,%rax
    4a14:	0f 83 73 ff ff ff    	jae    498d <fwp_free_zombie+0x9d>
    4a1a:	48 01 c1             	add    %rax,%rcx
    4a1d:	0f b6 01             	movzbl (%rcx),%eax
    4a20:	84 c0                	test   %al,%al
    4a22:	0f 84 65 ff ff ff    	je     498d <fwp_free_zombie+0x9d>
    4a28:	3c 01                	cmp    $0x1,%al
    4a2a:	74 14                	je     4a40 <fwp_free_zombie+0x150>
    4a2c:	3c ff                	cmp    $0xff,%al
    4a2e:	74 3b                	je     4a6b <fwp_free_zombie+0x17b>
    4a30:	83 e8 01             	sub    $0x1,%eax
    4a33:	88 01                	mov    %al,(%rcx)
    4a35:	e9 53 ff ff ff       	jmp    498d <fwp_free_zombie+0x9d>
    4a3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a40:	48 89 d7             	mov    %rdx,%rdi
    4a43:	48 83 c4 18          	add    $0x18,%rsp
    4a47:	e9 c4 fd ff ff       	jmp    4810 <fwp_task_dispose>
    4a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a50:	48 89 05 31 7c 01 00 	mov    %rax,0x17c31(%rip)        # 1c688 <fwp_tasks_active>
    4a57:	e9 ff fe ff ff       	jmp    495b <fwp_free_zombie+0x6b>
    4a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    4a60:	66 85 c0             	test   %ax,%ax
    4a63:	0f 85 24 ff ff ff    	jne    498d <fwp_free_zombie+0x9d>
    4a69:	eb b2                	jmp    4a1d <fwp_free_zombie+0x12d>
    4a6b:	48 89 ca             	mov    %rcx,%rdx
    4a6e:	48 8d 35 6b 7c 01 00 	lea    0x17c6b(%rip),%rsi        # 1c6e0 <fwp_heap>
    4a75:	48 c1 ea 11          	shr    $0x11,%rdx
    4a79:	48 31 ca             	xor    %rcx,%rdx
    4a7c:	48 89 d0             	mov    %rdx,%rax
    4a7f:	48 c1 e8 09          	shr    $0x9,%rax
    4a83:	48 31 c2             	xor    %rax,%rdx
    4a86:	0f b6 d2             	movzbl %dl,%edx
    4a89:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4a90:	00 
    4a91:	48 85 c0             	test   %rax,%rax
    4a94:	75 13                	jne    4aa9 <fwp_free_zombie+0x1b9>
    4a96:	eb 4c                	jmp    4ae4 <fwp_free_zombie+0x1f4>
    4a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a9f:	00 
    4aa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4aa4:	48 85 c0             	test   %rax,%rax
    4aa7:	74 3b                	je     4ae4 <fwp_free_zombie+0x1f4>
    4aa9:	48 89 c2             	mov    %rax,%rdx
    4aac:	48 39 08             	cmp    %rcx,(%rax)
    4aaf:	75 ef                	jne    4aa0 <fwp_free_zombie+0x1b0>
    4ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4ab5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4ab9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4abd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4ac4:	0f 85 c3 fe ff ff    	jne    498d <fwp_free_zombie+0x9d>
    4aca:	48 89 cf             	mov    %rcx,%rdi
    4acd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4ad2:	e8 79 f4 ff ff       	call   3f50 <fwp_rc_forget_slot>
    4ad7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4adc:	c6 01 fe             	movb   $0xfe,(%rcx)
    4adf:	e9 a9 fe ff ff       	jmp    498d <fwp_free_zombie+0x9d>
    4ae4:	48 8d 3d c5 47 00 00 	lea    0x47c5(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    4aeb:	e8 30 e6 ff ff       	call   3120 <fwp_trap>

0000000000004af0 <fwp_block>:
    4af0:	48 83 ec 08          	sub    $0x8,%rsp
    4af4:	48 8b 05 ad 7b 01 00 	mov    0x17bad(%rip),%rax        # 1c6a8 <fwp_ready_head>
    4afb:	48 85 c0             	test   %rax,%rax
    4afe:	0f 84 1c 01 00 00    	je     4c20 <fwp_block+0x130>
    4b04:	90                   	nop
    4b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b0c:	00 00 00 00 
    4b10:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4b17:	48 89 15 8a 7b 01 00 	mov    %rdx,0x17b8a(%rip)        # 1c6a8 <fwp_ready_head>
    4b1e:	48 85 d2             	test   %rdx,%rdx
    4b21:	0f 84 19 01 00 00    	je     4c40 <fwp_block+0x150>
    4b27:	48 8b 15 92 7b 01 00 	mov    0x17b92(%rip),%rdx        # 1c6c0 <fwp_cur>
    4b2e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b32:	48 39 c2             	cmp    %rax,%rdx
    4b35:	0f 84 d5 00 00 00    	je     4c10 <fwp_block+0x120>
    4b3b:	48 8b 0d fe 97 01 00 	mov    0x197fe(%rip),%rcx        # 1e340 <fwp_state_owners>
    4b42:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4b46:	48 89 05 73 7b 01 00 	mov    %rax,0x17b73(%rip)        # 1c6c0 <fwp_cur>
    4b4d:	f3 0f 7e 05 13 98 01 	movq   0x19813(%rip),%xmm0        # 1e368 <fwp_foreign_callbacks>
    4b54:	00 
    4b55:	0f 16 05 fc 97 01 00 	movhps 0x197fc(%rip),%xmm0        # 1e358 <fwp_state>
    4b5c:	f3 0f 7e 0d fc 97 01 	movq   0x197fc(%rip),%xmm1        # 1e360 <fwp_handlers>
    4b63:	00 
    4b64:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4b6b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4b72:	0f 16 0d f7 97 01 00 	movhps 0x197f7(%rip),%xmm1        # 1e370 <fwp_cleanups>
    4b79:	f3 0f 7e 05 cf 97 01 	movq   0x197cf(%rip),%xmm0        # 1e350 <fwp_state_len>
    4b80:	00 
    4b81:	0f 16 05 c0 97 01 00 	movhps 0x197c0(%rip),%xmm0        # 1e348 <fwp_state_cap>
    4b88:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4b8f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4b96:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b9a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4ba1:	48 89 0d b8 97 01 00 	mov    %rcx,0x197b8(%rip)        # 1e360 <fwp_handlers>
    4ba8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4baf:	48 89 0d ba 97 01 00 	mov    %rcx,0x197ba(%rip)        # 1e370 <fwp_cleanups>
    4bb6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4bbd:	48 89 0d a4 97 01 00 	mov    %rcx,0x197a4(%rip)        # 1e368 <fwp_foreign_callbacks>
    4bc4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4bcb:	48 89 0d 86 97 01 00 	mov    %rcx,0x19786(%rip)        # 1e358 <fwp_state>
    4bd2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4bd9:	48 89 0d 70 97 01 00 	mov    %rcx,0x19770(%rip)        # 1e350 <fwp_state_len>
    4be0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4be7:	48 89 0d 5a 97 01 00 	mov    %rcx,0x1975a(%rip)        # 1e348 <fwp_state_cap>
    4bee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4bf5:	48 89 0d 44 97 01 00 	mov    %rcx,0x19744(%rip)        # 1e340 <fwp_state_owners>
    4bfc:	e8 6f d8 ff ff       	call   2470 <swapcontext@plt>
    4c01:	f3 0f 1e fa          	endbr64
    4c05:	e8 e6 fc ff ff       	call   48f0 <fwp_free_zombie>
    4c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c10:	8b 05 82 74 01 00    	mov    0x17482(%rip),%eax        # 1c098 <fwp_slice>
    4c16:	85 c0                	test   %eax,%eax
    4c18:	74 36                	je     4c50 <fwp_block+0x160>
    4c1a:	48 83 c4 08          	add    $0x8,%rsp
    4c1e:	c3                   	ret
    4c1f:	90                   	nop
    4c20:	e8 6b ef ff ff       	call   3b90 <fwp_poll_events>
    4c25:	48 8b 05 7c 7a 01 00 	mov    0x17a7c(%rip),%rax        # 1c6a8 <fwp_ready_head>
    4c2c:	48 85 c0             	test   %rax,%rax
    4c2f:	0f 85 db fe ff ff    	jne    4b10 <fwp_block+0x20>
    4c35:	eb e9                	jmp    4c20 <fwp_block+0x130>
    4c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c3e:	00 00 
    4c40:	48 c7 05 55 7a 01 00 	movq   $0x0,0x17a55(%rip)        # 1c6a0 <fwp_ready_tail>
    4c47:	00 00 00 00 
    4c4b:	e9 d7 fe ff ff       	jmp    4b27 <fwp_block+0x37>
    4c50:	48 8d 3d 67 44 00 00 	lea    0x4467(%rip),%rdi        # 90be <_IO_stdin_used+0xbe>
    4c57:	e8 24 d7 ff ff       	call   2380 <getenv@plt>
    4c5c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4c61:	48 85 c0             	test   %rax,%rax
    4c64:	74 05                	je     4c6b <fwp_block+0x17b>
    4c66:	80 38 00             	cmpb   $0x0,(%rax)
    4c69:	75 0b                	jne    4c76 <fwp_block+0x186>
    4c6b:	89 15 27 74 01 00    	mov    %edx,0x17427(%rip)        # 1c098 <fwp_slice>
    4c71:	48 83 c4 08          	add    $0x8,%rsp
    4c75:	c3                   	ret
    4c76:	ba 0a 00 00 00       	mov    $0xa,%edx
    4c7b:	31 f6                	xor    %esi,%esi
    4c7d:	48 89 c7             	mov    %rax,%rdi
    4c80:	e8 ab d8 ff ff       	call   2530 <strtoll@plt>
    4c85:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4c89:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4c90:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4c95:	0f 46 d0             	cmovbe %eax,%edx
    4c98:	eb d1                	jmp    4c6b <fwp_block+0x17b>
    4c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004ca0 <fwp_map_items>:
    4ca0:	53                   	push   %rbx
    4ca1:	48 89 fb             	mov    %rdi,%rbx
    4ca4:	48 83 ec 10          	sub    $0x10,%rsp
    4ca8:	48 85 ff             	test   %rdi,%rdi
    4cab:	0f 84 6f 01 00 00    	je     4e20 <fwp_map_items+0x180>
    4cb1:	48 89 fa             	mov    %rdi,%rdx
    4cb4:	31 c0                	xor    %eax,%eax
    4cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4cbd:	00 00 00 
    4cc0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    4cc4:	48 89 c1             	mov    %rax,%rcx
    4cc7:	48 83 c0 01          	add    $0x1,%rax
    4ccb:	48 85 d2             	test   %rdx,%rdx
    4cce:	75 f0                	jne    4cc0 <fwp_map_items+0x20>
    4cd0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    4cd7:	ff ff 1f 
    4cda:	48 89 06             	mov    %rax,(%rsi)
    4cdd:	48 39 c2             	cmp    %rax,%rdx
    4ce0:	0f 82 55 01 00 00    	jb     4e3b <fwp_map_items+0x19b>
    4ce6:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    4ced:	00 
    4cee:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    4cf5:	0f 96 c2             	setbe  %dl
    4cf8:	8b 0d 86 8d 01 00    	mov    0x18d86(%rip),%ecx        # 1da84 <fwp_heap+0x13a4>
    4cfe:	48 8d 05 db 79 01 00 	lea    0x179db(%rip),%rax        # 1c6e0 <fwp_heap>
    4d05:	85 c9                	test   %ecx,%ecx
    4d07:	0f 84 ee 00 00 00    	je     4dfb <fwp_map_items+0x15b>
    4d0d:	84 d2                	test   %dl,%dl
    4d0f:	0f 84 e6 00 00 00    	je     4dfb <fwp_map_items+0x15b>
    4d15:	48 8d 57 0f          	lea    0xf(%rdi),%rdx
    4d19:	48 c1 ea 04          	shr    $0x4,%rdx
    4d1d:	0f b6 94 10 a0 0f 00 	movzbl 0xfa0(%rax,%rdx,1),%edx
    4d24:	00 
    4d25:	44 8b 84 90 00 0f 00 	mov    0xf00(%rax,%rdx,4),%r8d
    4d2c:	00 
    4d2d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    4d31:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    4d35:	48 8b 88 80 07 00 00 	mov    0x780(%rax),%rcx
    4d3c:	48 85 c9             	test   %rcx,%rcx
    4d3f:	0f 84 9b 00 00 00    	je     4de0 <fwp_map_items+0x140>
    4d45:	48 8b 11             	mov    (%rcx),%rdx
    4d48:	48 f7 d2             	not    %rdx
    4d4b:	48 89 90 80 07 00 00 	mov    %rdx,0x780(%rax)
    4d52:	4c 89 c2             	mov    %r8,%rdx
    4d55:	48 89 cf             	mov    %rcx,%rdi
    4d58:	31 f6                	xor    %esi,%esi
    4d5a:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    4d5f:	e8 3c d7 ff ff       	call   24a0 <memset@plt>
    4d64:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4d69:	48 89 c1             	mov    %rax,%rcx
    4d6c:	4c 89 c0             	mov    %r8,%rax
    4d6f:	48 03 05 8a 8d 01 00 	add    0x18d8a(%rip),%rax        # 1db00 <fwp_heap+0x1420>
    4d76:	0f 82 ba 00 00 00    	jb     4e36 <fwp_map_items+0x196>
    4d7c:	48 39 05 85 8d 01 00 	cmp    %rax,0x18d85(%rip)        # 1db08 <fwp_heap+0x1428>
    4d83:	48 89 05 76 8d 01 00 	mov    %rax,0x18d76(%rip)        # 1db00 <fwp_heap+0x1420>
    4d8a:	73 07                	jae    4d93 <fwp_map_items+0xf3>
    4d8c:	48 89 05 75 8d 01 00 	mov    %rax,0x18d75(%rip)        # 1db08 <fwp_heap+0x1428>
    4d93:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d97:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4d9c:	f2 0f 58 05 74 8d 01 	addsd  0x18d74(%rip),%xmm0        # 1db18 <fwp_heap+0x1438>
    4da3:	00 
    4da4:	f2 0f 11 05 6c 8d 01 	movsd  %xmm0,0x18d6c(%rip)        # 1db18 <fwp_heap+0x1438>
    4dab:	00 
    4dac:	48 89 c8             	mov    %rcx,%rax
    4daf:	48 85 db             	test   %rbx,%rbx
    4db2:	74 21                	je     4dd5 <fwp_map_items+0x135>
    4db4:	90                   	nop
    4db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dbc:	00 00 00 00 
    4dc0:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    4dc4:	48 83 c0 08          	add    $0x8,%rax
    4dc8:	48 89 50 f8          	mov    %rdx,-0x8(%rax)
    4dcc:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    4dd0:	48 85 db             	test   %rbx,%rbx
    4dd3:	75 eb                	jne    4dc0 <fwp_map_items+0x120>
    4dd5:	48 83 c4 10          	add    $0x10,%rsp
    4dd9:	48 89 c8             	mov    %rcx,%rax
    4ddc:	5b                   	pop    %rbx
    4ddd:	c3                   	ret
    4dde:	66 90                	xchg   %ax,%ax
    4de0:	48 8b 88 88 07 00 00 	mov    0x788(%rax),%rcx
    4de7:	48 85 c9             	test   %rcx,%rcx
    4dea:	74 0f                	je     4dfb <fwp_map_items+0x15b>
    4dec:	48 8b 90 90 07 00 00 	mov    0x790(%rax),%rdx
    4df3:	48 29 ca             	sub    %rcx,%rdx
    4df6:	4c 39 c2             	cmp    %r8,%rdx
    4df9:	73 0f                	jae    4e0a <fwp_map_items+0x16a>
    4dfb:	be 02 00 00 00       	mov    $0x2,%esi
    4e00:	e8 0b f7 ff ff       	call   4510 <fwp_heap_alloc_slow>
    4e05:	48 89 c1             	mov    %rax,%rcx
    4e08:	eb a2                	jmp    4dac <fwp_map_items+0x10c>
    4e0a:	4a 8d 14 01          	lea    (%rcx,%r8,1),%rdx
    4e0e:	48 89 90 88 07 00 00 	mov    %rdx,0x788(%rax)
    4e15:	e9 38 ff ff ff       	jmp    4d52 <fwp_map_items+0xb2>
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    4e27:	ba 01 00 00 00       	mov    $0x1,%edx
    4e2c:	bf 08 00 00 00       	mov    $0x8,%edi
    4e31:	e9 c2 fe ff ff       	jmp    4cf8 <fwp_map_items+0x58>
    4e36:	e8 35 de ff ff       	call   2c70 <fwp_heap_oom>
    4e3b:	48 8d 3d 88 42 00 00 	lea    0x4288(%rip),%rdi        # 90ca <_IO_stdin_used+0xca>
    4e42:	e8 d9 e2 ff ff       	call   3120 <fwp_trap>
    4e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4e4e:	00 00 

0000000000004e50 <fwp_caps32>:
    4e50:	f3 0f 1e fa          	endbr64
    4e54:	85 f6                	test   %esi,%esi
    4e56:	74 08                	je     4e60 <fwp_caps32+0x10>
    4e58:	c3                   	ret
    4e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e60:	48 8b 15 51 8c 01 00 	mov    0x18c51(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    4e67:	48 89 f8             	mov    %rdi,%rax
    4e6a:	48 2b 05 1f 8c 01 00 	sub    0x18c1f(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    4e71:	48 c1 e2 10          	shl    $0x10,%rdx
    4e75:	48 39 d0             	cmp    %rdx,%rax
    4e78:	73 de                	jae    4e58 <fwp_caps32+0x8>
    4e7a:	48 89 c2             	mov    %rax,%rdx
    4e7d:	48 c1 ea 10          	shr    $0x10,%rdx
    4e81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e85:	48 8b 15 4c 8c 01 00 	mov    0x18c4c(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    4e8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4e90:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4e94:	48 85 c9             	test   %rcx,%rcx
    4e97:	74 bf                	je     4e58 <fwp_caps32+0x8>
    4e99:	0f b6 32             	movzbl (%rdx),%esi
    4e9c:	40 80 fe 02          	cmp    $0x2,%sil
    4ea0:	74 2e                	je     4ed0 <fwp_caps32+0x80>
    4ea2:	40 80 fe 01          	cmp    $0x1,%sil
    4ea6:	75 b0                	jne    4e58 <fwp_caps32+0x8>
    4ea8:	8b 72 18             	mov    0x18(%rdx),%esi
    4eab:	0f b7 c0             	movzwl %ax,%eax
    4eae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4eb1:	48 0f af c6          	imul   %rsi,%rax
    4eb5:	48 c1 e8 20          	shr    $0x20,%rax
    4eb9:	48 39 d0             	cmp    %rdx,%rax
    4ebc:	73 9a                	jae    4e58 <fwp_caps32+0x8>
    4ebe:	48 01 c1             	add    %rax,%rcx
    4ec1:	80 39 01             	cmpb   $0x1,(%rcx)
    4ec4:	75 92                	jne    4e58 <fwp_caps32+0x8>
    4ec6:	e9 c5 f2 ff ff       	jmp    4190 <fwp_mem_free>
    4ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed0:	66 85 c0             	test   %ax,%ax
    4ed3:	74 ec                	je     4ec1 <fwp_caps32+0x71>
    4ed5:	c3                   	ret
    4ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4edd:	00 00 00 

0000000000004ee0 <fwp_caps45>:
    4ee0:	f3 0f 1e fa          	endbr64
    4ee4:	85 f6                	test   %esi,%esi
    4ee6:	74 08                	je     4ef0 <fwp_caps45+0x10>
    4ee8:	c3                   	ret
    4ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ef0:	48 8b 15 c1 8b 01 00 	mov    0x18bc1(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    4ef7:	48 89 f8             	mov    %rdi,%rax
    4efa:	48 2b 05 8f 8b 01 00 	sub    0x18b8f(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    4f01:	48 c1 e2 10          	shl    $0x10,%rdx
    4f05:	48 39 d0             	cmp    %rdx,%rax
    4f08:	73 de                	jae    4ee8 <fwp_caps45+0x8>
    4f0a:	48 89 c2             	mov    %rax,%rdx
    4f0d:	48 c1 ea 10          	shr    $0x10,%rdx
    4f11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f15:	48 8b 15 bc 8b 01 00 	mov    0x18bbc(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    4f1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f24:	48 85 c9             	test   %rcx,%rcx
    4f27:	74 bf                	je     4ee8 <fwp_caps45+0x8>
    4f29:	0f b6 32             	movzbl (%rdx),%esi
    4f2c:	40 80 fe 02          	cmp    $0x2,%sil
    4f30:	74 2e                	je     4f60 <fwp_caps45+0x80>
    4f32:	40 80 fe 01          	cmp    $0x1,%sil
    4f36:	75 b0                	jne    4ee8 <fwp_caps45+0x8>
    4f38:	8b 72 18             	mov    0x18(%rdx),%esi
    4f3b:	0f b7 c0             	movzwl %ax,%eax
    4f3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4f41:	48 0f af c6          	imul   %rsi,%rax
    4f45:	48 c1 e8 20          	shr    $0x20,%rax
    4f49:	48 39 d0             	cmp    %rdx,%rax
    4f4c:	73 9a                	jae    4ee8 <fwp_caps45+0x8>
    4f4e:	48 01 c1             	add    %rax,%rcx
    4f51:	80 39 01             	cmpb   $0x1,(%rcx)
    4f54:	75 92                	jne    4ee8 <fwp_caps45+0x8>
    4f56:	e9 35 f2 ff ff       	jmp    4190 <fwp_mem_free>
    4f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f60:	66 85 c0             	test   %ax,%ax
    4f63:	74 ec                	je     4f51 <fwp_caps45+0x71>
    4f65:	c3                   	ret
    4f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f6d:	00 00 00 

0000000000004f70 <fwp_caps69>:
    4f70:	f3 0f 1e fa          	endbr64
    4f74:	85 f6                	test   %esi,%esi
    4f76:	74 08                	je     4f80 <fwp_caps69+0x10>
    4f78:	c3                   	ret
    4f79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f80:	48 8b 15 31 8b 01 00 	mov    0x18b31(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    4f87:	48 89 f8             	mov    %rdi,%rax
    4f8a:	48 2b 05 ff 8a 01 00 	sub    0x18aff(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    4f91:	48 c1 e2 10          	shl    $0x10,%rdx
    4f95:	48 39 d0             	cmp    %rdx,%rax
    4f98:	73 de                	jae    4f78 <fwp_caps69+0x8>
    4f9a:	48 89 c2             	mov    %rax,%rdx
    4f9d:	48 c1 ea 10          	shr    $0x10,%rdx
    4fa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4fa5:	48 8b 15 2c 8b 01 00 	mov    0x18b2c(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    4fac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4fb0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4fb4:	48 85 c9             	test   %rcx,%rcx
    4fb7:	74 bf                	je     4f78 <fwp_caps69+0x8>
    4fb9:	0f b6 32             	movzbl (%rdx),%esi
    4fbc:	40 80 fe 02          	cmp    $0x2,%sil
    4fc0:	74 2e                	je     4ff0 <fwp_caps69+0x80>
    4fc2:	40 80 fe 01          	cmp    $0x1,%sil
    4fc6:	75 b0                	jne    4f78 <fwp_caps69+0x8>
    4fc8:	8b 72 18             	mov    0x18(%rdx),%esi
    4fcb:	0f b7 c0             	movzwl %ax,%eax
    4fce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4fd1:	48 0f af c6          	imul   %rsi,%rax
    4fd5:	48 c1 e8 20          	shr    $0x20,%rax
    4fd9:	48 39 d0             	cmp    %rdx,%rax
    4fdc:	73 9a                	jae    4f78 <fwp_caps69+0x8>
    4fde:	48 01 c1             	add    %rax,%rcx
    4fe1:	80 39 01             	cmpb   $0x1,(%rcx)
    4fe4:	75 92                	jne    4f78 <fwp_caps69+0x8>
    4fe6:	e9 a5 f1 ff ff       	jmp    4190 <fwp_mem_free>
    4feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ff0:	66 85 c0             	test   %ax,%ax
    4ff3:	74 ec                	je     4fe1 <fwp_caps69+0x71>
    4ff5:	c3                   	ret
    4ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ffd:	00 00 00 

0000000000005000 <fwp_caps74>:
    5000:	f3 0f 1e fa          	endbr64
    5004:	85 f6                	test   %esi,%esi
    5006:	74 08                	je     5010 <fwp_caps74+0x10>
    5008:	c3                   	ret
    5009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5010:	48 8b 15 a1 8a 01 00 	mov    0x18aa1(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    5017:	48 89 f8             	mov    %rdi,%rax
    501a:	48 2b 05 6f 8a 01 00 	sub    0x18a6f(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    5021:	48 c1 e2 10          	shl    $0x10,%rdx
    5025:	48 39 d0             	cmp    %rdx,%rax
    5028:	73 de                	jae    5008 <fwp_caps74+0x8>
    502a:	48 89 c2             	mov    %rax,%rdx
    502d:	48 c1 ea 10          	shr    $0x10,%rdx
    5031:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5035:	48 8b 15 9c 8a 01 00 	mov    0x18a9c(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    503c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5040:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    5044:	48 85 c9             	test   %rcx,%rcx
    5047:	74 bf                	je     5008 <fwp_caps74+0x8>
    5049:	0f b6 32             	movzbl (%rdx),%esi
    504c:	40 80 fe 02          	cmp    $0x2,%sil
    5050:	74 2e                	je     5080 <fwp_caps74+0x80>
    5052:	40 80 fe 01          	cmp    $0x1,%sil
    5056:	75 b0                	jne    5008 <fwp_caps74+0x8>
    5058:	8b 72 18             	mov    0x18(%rdx),%esi
    505b:	0f b7 c0             	movzwl %ax,%eax
    505e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5061:	48 0f af c6          	imul   %rsi,%rax
    5065:	48 c1 e8 20          	shr    $0x20,%rax
    5069:	48 39 d0             	cmp    %rdx,%rax
    506c:	73 9a                	jae    5008 <fwp_caps74+0x8>
    506e:	48 01 c1             	add    %rax,%rcx
    5071:	80 39 01             	cmpb   $0x1,(%rcx)
    5074:	75 92                	jne    5008 <fwp_caps74+0x8>
    5076:	e9 15 f1 ff ff       	jmp    4190 <fwp_mem_free>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	66 85 c0             	test   %ax,%ax
    5083:	74 ec                	je     5071 <fwp_caps74+0x71>
    5085:	c3                   	ret
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 

0000000000005090 <fwp_data.part.0.constprop.0>:
    5090:	41 56                	push   %r14
    5092:	41 89 fe             	mov    %edi,%r14d
    5095:	41 54                	push   %r12
    5097:	49 89 f4             	mov    %rsi,%r12
    509a:	55                   	push   %rbp
    509b:	53                   	push   %rbx
    509c:	48 83 ec 08          	sub    $0x8,%rsp
    50a0:	8b 05 de 89 01 00    	mov    0x189de(%rip),%eax        # 1da84 <fwp_heap+0x13a4>
    50a6:	85 c0                	test   %eax,%eax
    50a8:	0f 84 fa 00 00 00    	je     51a8 <fwp_data.part.0.constprop.0+0x118>
    50ae:	0f b6 05 cd 85 01 00 	movzbl 0x185cd(%rip),%eax        # 1d682 <fwp_heap+0xfa2>
    50b5:	48 8d 15 24 76 01 00 	lea    0x17624(%rip),%rdx        # 1c6e0 <fwp_heap>
    50bc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    50c3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50c7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    50cb:	48 8b 18             	mov    (%rax),%rbx
    50ce:	48 85 db             	test   %rbx,%rbx
    50d1:	0f 84 a9 00 00 00    	je     5180 <fwp_data.part.0.constprop.0+0xf0>
    50d7:	48 8b 13             	mov    (%rbx),%rdx
    50da:	48 f7 d2             	not    %rdx
    50dd:	48 89 10             	mov    %rdx,(%rax)
    50e0:	48 83 fd 18          	cmp    $0x18,%rbp
    50e4:	76 1b                	jbe    5101 <fwp_data.part.0.constprop.0+0x71>
    50e6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    50ea:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    50ee:	31 f6                	xor    %esi,%esi
    50f0:	48 c1 e8 03          	shr    $0x3,%rax
    50f4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    50fb:	00 
    50fc:	e8 9f d3 ff ff       	call   24a0 <memset@plt>
    5101:	48 89 e8             	mov    %rbp,%rax
    5104:	48 03 05 f5 89 01 00 	add    0x189f5(%rip),%rax        # 1db00 <fwp_heap+0x1420>
    510b:	0f 82 a8 00 00 00    	jb     51b9 <fwp_data.part.0.constprop.0+0x129>
    5111:	48 39 05 f0 89 01 00 	cmp    %rax,0x189f0(%rip)        # 1db08 <fwp_heap+0x1428>
    5118:	48 89 05 e1 89 01 00 	mov    %rax,0x189e1(%rip)        # 1db00 <fwp_heap+0x1420>
    511f:	73 07                	jae    5128 <fwp_data.part.0.constprop.0+0x98>
    5121:	48 89 05 e0 89 01 00 	mov    %rax,0x189e0(%rip)        # 1db08 <fwp_heap+0x1428>
    5128:	66 0f ef c0          	pxor   %xmm0,%xmm0
    512c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5131:	f2 0f 58 05 df 89 01 	addsd  0x189df(%rip),%xmm0        # 1db18 <fwp_heap+0x1438>
    5138:	00 
    5139:	f2 0f 11 05 d7 89 01 	movsd  %xmm0,0x189d7(%rip)        # 1db18 <fwp_heap+0x1438>
    5140:	00 
    5141:	b8 02 00 00 00       	mov    $0x2,%eax
    5146:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    514b:	66 0f 6e c8          	movd   %eax,%xmm1
    514f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5153:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5157:	49 8b 04 24          	mov    (%r12),%rax
    515b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    515f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5164:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5168:	48 83 c4 08          	add    $0x8,%rsp
    516c:	48 89 d8             	mov    %rbx,%rax
    516f:	5b                   	pop    %rbx
    5170:	5d                   	pop    %rbp
    5171:	41 5c                	pop    %r12
    5173:	41 5e                	pop    %r14
    5175:	c3                   	ret
    5176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    517d:	00 00 00 
    5180:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5184:	48 85 db             	test   %rbx,%rbx
    5187:	74 1f                	je     51a8 <fwp_data.part.0.constprop.0+0x118>
    5189:	48 8b 50 10          	mov    0x10(%rax),%rdx
    518d:	48 29 da             	sub    %rbx,%rdx
    5190:	48 39 ea             	cmp    %rbp,%rdx
    5193:	72 13                	jb     51a8 <fwp_data.part.0.constprop.0+0x118>
    5195:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5199:	48 89 50 08          	mov    %rdx,0x8(%rax)
    519d:	e9 3e ff ff ff       	jmp    50e0 <fwp_data.part.0.constprop.0+0x50>
    51a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51a8:	31 f6                	xor    %esi,%esi
    51aa:	bf 18 00 00 00       	mov    $0x18,%edi
    51af:	e8 5c f3 ff ff       	call   4510 <fwp_heap_alloc_slow>
    51b4:	48 89 c3             	mov    %rax,%rbx
    51b7:	eb 88                	jmp    5141 <fwp_data.part.0.constprop.0+0xb1>
    51b9:	e8 b2 da ff ff       	call   2c70 <fwp_heap_oom>
    51be:	66 90                	xchg   %ax,%ax

00000000000051c0 <f74>:
    51c0:	66 48 0f 6e df       	movq   %rdi,%xmm3
    51c5:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    51ca:	48 83 ec 38          	sub    $0x38,%rsp
    51ce:	31 ff                	xor    %edi,%edi
    51d0:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51d7:	00 00 
    51d9:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    51de:	31 c0                	xor    %eax,%eax
    51e0:	66 0f 28 c3          	movapd %xmm3,%xmm0
    51e4:	f2 0f 10 15 94 42 00 	movsd  0x4294(%rip),%xmm2        # 9480 <msg.3+0x30>
    51eb:	00 
    51ec:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    51f1:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    51f5:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    51f9:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    51fd:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    5201:	f2 0f 10 05 6f 42 00 	movsd  0x426f(%rip),%xmm0        # 9478 <msg.3+0x28>
    5208:	00 
    5209:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    520d:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    5211:	f2 0f 59 0d 6f 42 00 	mulsd  0x426f(%rip),%xmm1        # 9488 <msg.3+0x38>
    5218:	00 
    5219:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    521d:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    5221:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5226:	e8 65 fe ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    522b:	48 8b 15 86 88 01 00 	mov    0x18886(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    5232:	48 89 c6             	mov    %rax,%rsi
    5235:	48 2b 05 54 88 01 00 	sub    0x18854(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    523c:	48 c1 e2 10          	shl    $0x10,%rdx
    5240:	48 39 d0             	cmp    %rdx,%rax
    5243:	73 4f                	jae    5294 <f74+0xd4>
    5245:	48 89 c2             	mov    %rax,%rdx
    5248:	48 c1 ea 10          	shr    $0x10,%rdx
    524c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5250:	48 8b 15 81 88 01 00 	mov    0x18881(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    5257:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    525b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    525f:	48 85 d2             	test   %rdx,%rdx
    5262:	74 30                	je     5294 <f74+0xd4>
    5264:	0f b6 39             	movzbl (%rcx),%edi
    5267:	40 80 ff 02          	cmp    $0x2,%dil
    526b:	74 43                	je     52b0 <f74+0xf0>
    526d:	40 80 ff 01          	cmp    $0x1,%dil
    5271:	75 21                	jne    5294 <f74+0xd4>
    5273:	8b 79 18             	mov    0x18(%rcx),%edi
    5276:	0f b7 c0             	movzwl %ax,%eax
    5279:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    527c:	48 0f af c7          	imul   %rdi,%rax
    5280:	48 c1 e8 20          	shr    $0x20,%rax
    5284:	48 39 c8             	cmp    %rcx,%rax
    5287:	73 0b                	jae    5294 <f74+0xd4>
    5289:	48 01 c2             	add    %rax,%rdx
    528c:	80 3a ff             	cmpb   $0xff,(%rdx)
    528f:	74 2f                	je     52c0 <f74+0x100>
    5291:	c6 02 01             	movb   $0x1,(%rdx)
    5294:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    5299:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    52a0:	00 00 
    52a2:	75 38                	jne    52dc <f74+0x11c>
    52a4:	48 89 f0             	mov    %rsi,%rax
    52a7:	48 83 c4 38          	add    $0x38,%rsp
    52ab:	c3                   	ret
    52ac:	0f 1f 40 00          	nopl   0x0(%rax)
    52b0:	66 85 c0             	test   %ax,%ax
    52b3:	75 df                	jne    5294 <f74+0xd4>
    52b5:	eb d5                	jmp    528c <f74+0xcc>
    52b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    52be:	00 00 
    52c0:	48 89 d7             	mov    %rdx,%rdi
    52c3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    52c8:	48 89 14 24          	mov    %rdx,(%rsp)
    52cc:	e8 7f ec ff ff       	call   3f50 <fwp_rc_forget_slot>
    52d1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    52d6:	48 8b 14 24          	mov    (%rsp),%rdx
    52da:	eb b5                	jmp    5291 <f74+0xd1>
    52dc:	e8 5f d1 ff ff       	call   2440 <__stack_chk_fail@plt>
    52e1:	0f 1f 40 00          	nopl   0x0(%rax)
    52e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52ec:	00 00 00 00 

00000000000052f0 <fwp_owned_entry74>:
    52f0:	f3 0f 1e fa          	endbr64
    52f4:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    52f8:	48 8b 3f             	mov    (%rdi),%rdi
    52fb:	e9 c0 fe ff ff       	jmp    51c0 <f74>

0000000000005300 <e74>:
    5300:	f3 0f 1e fa          	endbr64
    5304:	48 83 ec 18          	sub    $0x18,%rsp
    5308:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    530c:	48 8b 3f             	mov    (%rdi),%rdi
    530f:	e8 ac fe ff ff       	call   51c0 <f74>
    5314:	48 89 c7             	mov    %rax,%rdi
    5317:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    531c:	e8 6f f3 ff ff       	call   4690 <fwp_rc_share>
    5321:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5326:	48 83 c4 18          	add    $0x18,%rsp
    532a:	c3                   	ret
    532b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005330 <fwp_map_finish_protected.isra.0>:
    5330:	41 55                	push   %r13
    5332:	41 54                	push   %r12
    5334:	55                   	push   %rbp
    5335:	53                   	push   %rbx
    5336:	48 83 ec 38          	sub    $0x38,%rsp
    533a:	48 8b 47 08          	mov    0x8(%rdi),%rax
    533e:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    5342:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5349:	00 00 
    534b:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    5350:	49 89 fc             	mov    %rdi,%r12
    5353:	48 85 c0             	test   %rax,%rax
    5356:	0f 84 d4 00 00 00    	je     5430 <fwp_map_finish_protected.isra.0+0x100>
    535c:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
    5361:	4c 8d 2d 78 73 01 00 	lea    0x17378(%rip),%r13        # 1c6e0 <fwp_heap>
    5368:	eb 4a                	jmp    53b4 <fwp_map_finish_protected.isra.0+0x84>
    536a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5370:	40 80 fe 01          	cmp    $0x1,%sil
    5374:	75 25                	jne    539b <fwp_map_finish_protected.isra.0+0x6b>
    5376:	8b 71 18             	mov    0x18(%rcx),%esi
    5379:	0f b7 c0             	movzwl %ax,%eax
    537c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    537f:	48 0f af c6          	imul   %rsi,%rax
    5383:	48 c1 e8 20          	shr    $0x20,%rax
    5387:	48 39 c8             	cmp    %rcx,%rax
    538a:	73 0f                	jae    539b <fwp_map_finish_protected.isra.0+0x6b>
    538c:	48 01 c2             	add    %rax,%rdx
    538f:	80 3a ff             	cmpb   $0xff,(%rdx)
    5392:	0f 84 c8 00 00 00    	je     5460 <fwp_map_finish_protected.isra.0+0x130>
    5398:	c6 02 01             	movb   $0x1,(%rdx)
    539b:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    53a0:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
    53a5:	48 83 e8 01          	sub    $0x1,%rax
    53a9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    53ae:	0f 84 7c 00 00 00    	je     5430 <fwp_map_finish_protected.isra.0+0x100>
    53b4:	49 8b 14 24          	mov    (%r12),%rdx
    53b8:	66 48 0f 6e cb       	movq   %rbx,%xmm1
    53bd:	48 89 ee             	mov    %rbp,%rsi
    53c0:	bf 01 00 00 00       	mov    $0x1,%edi
    53c5:	f3 0f 7e 44 c2 f8    	movq   -0x8(%rdx,%rax,8),%xmm0
    53cb:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    53cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    53d4:	e8 b7 fc ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    53d9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    53e0:	48 89 c3             	mov    %rax,%rbx
    53e3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    53ea:	48 c1 e2 10          	shl    $0x10,%rdx
    53ee:	48 39 d0             	cmp    %rdx,%rax
    53f1:	73 a8                	jae    539b <fwp_map_finish_protected.isra.0+0x6b>
    53f3:	48 89 c2             	mov    %rax,%rdx
    53f6:	48 c1 ea 10          	shr    $0x10,%rdx
    53fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    53fe:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    5405:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5409:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    540d:	48 85 d2             	test   %rdx,%rdx
    5410:	74 89                	je     539b <fwp_map_finish_protected.isra.0+0x6b>
    5412:	0f b6 31             	movzbl (%rcx),%esi
    5415:	40 80 fe 02          	cmp    $0x2,%sil
    5419:	0f 85 51 ff ff ff    	jne    5370 <fwp_map_finish_protected.isra.0+0x40>
    541f:	66 85 c0             	test   %ax,%ax
    5422:	0f 85 73 ff ff ff    	jne    539b <fwp_map_finish_protected.isra.0+0x6b>
    5428:	e9 62 ff ff ff       	jmp    538f <fwp_map_finish_protected.isra.0+0x5f>
    542d:	0f 1f 00             	nopl   (%rax)
    5430:	49 8b 3c 24          	mov    (%r12),%rdi
    5434:	e8 57 ed ff ff       	call   4190 <fwp_mem_free>
    5439:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    543e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5445:	00 00 
    5447:	75 2e                	jne    5477 <fwp_map_finish_protected.isra.0+0x147>
    5449:	48 83 c4 38          	add    $0x38,%rsp
    544d:	48 89 d8             	mov    %rbx,%rax
    5450:	5b                   	pop    %rbx
    5451:	5d                   	pop    %rbp
    5452:	41 5c                	pop    %r12
    5454:	41 5d                	pop    %r13
    5456:	c3                   	ret
    5457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    545e:	00 00 
    5460:	48 89 d7             	mov    %rdx,%rdi
    5463:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5468:	e8 e3 ea ff ff       	call   3f50 <fwp_rc_forget_slot>
    546d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5472:	e9 21 ff ff ff       	jmp    5398 <fwp_map_finish_protected.isra.0+0x68>
    5477:	e8 c4 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    547c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005480 <fwp_drop4>:
    5480:	f3 0f 1e fa          	endbr64
    5484:	48 8b 15 2d 86 01 00 	mov    0x1862d(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    548b:	48 89 f8             	mov    %rdi,%rax
    548e:	48 2b 05 fb 85 01 00 	sub    0x185fb(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    5495:	48 c1 e2 10          	shl    $0x10,%rdx
    5499:	48 39 d0             	cmp    %rdx,%rax
    549c:	73 67                	jae    5505 <fwp_drop4+0x85>
    549e:	48 89 c2             	mov    %rax,%rdx
    54a1:	48 c1 ea 10          	shr    $0x10,%rdx
    54a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    54a9:	48 8b 15 28 86 01 00 	mov    0x18628(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    54b0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    54b4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    54b8:	48 85 d2             	test   %rdx,%rdx
    54bb:	74 48                	je     5505 <fwp_drop4+0x85>
    54bd:	0f b6 31             	movzbl (%rcx),%esi
    54c0:	40 80 fe 02          	cmp    $0x2,%sil
    54c4:	74 3a                	je     5500 <fwp_drop4+0x80>
    54c6:	40 80 fe 01          	cmp    $0x1,%sil
    54ca:	75 39                	jne    5505 <fwp_drop4+0x85>
    54cc:	8b 71 18             	mov    0x18(%rcx),%esi
    54cf:	0f b7 c0             	movzwl %ax,%eax
    54d2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    54d5:	48 0f af c6          	imul   %rsi,%rax
    54d9:	48 c1 e8 20          	shr    $0x20,%rax
    54dd:	48 39 c8             	cmp    %rcx,%rax
    54e0:	73 23                	jae    5505 <fwp_drop4+0x85>
    54e2:	48 01 c2             	add    %rax,%rdx
    54e5:	0f b6 02             	movzbl (%rdx),%eax
    54e8:	84 c0                	test   %al,%al
    54ea:	74 19                	je     5505 <fwp_drop4+0x85>
    54ec:	3c 01                	cmp    $0x1,%al
    54ee:	74 20                	je     5510 <fwp_drop4+0x90>
    54f0:	3c ff                	cmp    $0xff,%al
    54f2:	74 24                	je     5518 <fwp_drop4+0x98>
    54f4:	83 e8 01             	sub    $0x1,%eax
    54f7:	88 02                	mov    %al,(%rdx)
    54f9:	c3                   	ret
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5500:	66 85 c0             	test   %ax,%ax
    5503:	74 e0                	je     54e5 <fwp_drop4+0x65>
    5505:	c3                   	ret
    5506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    550d:	00 00 00 
    5510:	e9 7b ec ff ff       	jmp    4190 <fwp_mem_free>
    5515:	0f 1f 00             	nopl   (%rax)
    5518:	48 89 d0             	mov    %rdx,%rax
    551b:	48 8d 35 be 71 01 00 	lea    0x171be(%rip),%rsi        # 1c6e0 <fwp_heap>
    5522:	48 83 ec 18          	sub    $0x18,%rsp
    5526:	48 c1 e8 11          	shr    $0x11,%rax
    552a:	48 31 d0             	xor    %rdx,%rax
    552d:	48 89 c1             	mov    %rax,%rcx
    5530:	48 c1 e9 09          	shr    $0x9,%rcx
    5534:	48 31 c8             	xor    %rcx,%rax
    5537:	0f b6 c8             	movzbl %al,%ecx
    553a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5541:	00 
    5542:	48 85 c0             	test   %rax,%rax
    5545:	75 22                	jne    5569 <fwp_drop4+0xe9>
    5547:	eb 59                	jmp    55a2 <fwp_drop4+0x122>
    5549:	90                   	nop
    554a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5551:	00 00 00 00 
    5555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    555c:	00 00 00 00 
    5560:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5564:	48 85 c0             	test   %rax,%rax
    5567:	74 39                	je     55a2 <fwp_drop4+0x122>
    5569:	48 89 c1             	mov    %rax,%rcx
    556c:	48 39 10             	cmp    %rdx,(%rax)
    556f:	75 ef                	jne    5560 <fwp_drop4+0xe0>
    5571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5575:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5579:	48 89 48 08          	mov    %rcx,0x8(%rax)
    557d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5584:	74 05                	je     558b <fwp_drop4+0x10b>
    5586:	48 83 c4 18          	add    $0x18,%rsp
    558a:	c3                   	ret
    558b:	48 89 d7             	mov    %rdx,%rdi
    558e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5593:	e8 b8 e9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5598:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    559d:	c6 02 fe             	movb   $0xfe,(%rdx)
    55a0:	eb e4                	jmp    5586 <fwp_drop4+0x106>
    55a2:	48 8d 3d 07 3d 00 00 	lea    0x3d07(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    55a9:	e8 72 db ff ff       	call   3120 <fwp_trap>
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_owned_entry50>:
    55b0:	f3 0f 1e fa          	endbr64
    55b4:	53                   	push   %rbx
    55b5:	48 8b 3f             	mov    (%rdi),%rdi
    55b8:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    55bc:	e8 bf fe ff ff       	call   5480 <fwp_drop4>
    55c1:	48 89 d8             	mov    %rbx,%rax
    55c4:	5b                   	pop    %rbx
    55c5:	c3                   	ret
    55c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55cd:	00 00 00 

00000000000055d0 <fwp_owned_entry47>:
    55d0:	f3 0f 1e fa          	endbr64
    55d4:	53                   	push   %rbx
    55d5:	48 8b 3f             	mov    (%rdi),%rdi
    55d8:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    55dc:	e8 9f fe ff ff       	call   5480 <fwp_drop4>
    55e1:	48 89 d8             	mov    %rbx,%rax
    55e4:	5b                   	pop    %rbx
    55e5:	c3                   	ret
    55e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ed:	00 00 00 

00000000000055f0 <fwp_arg_drop47>:
    55f0:	f3 0f 1e fa          	endbr64
    55f4:	85 f6                	test   %esi,%esi
    55f6:	75 04                	jne    55fc <fwp_arg_drop47+0xc>
    55f8:	85 d2                	test   %edx,%edx
    55fa:	75 04                	jne    5600 <fwp_arg_drop47+0x10>
    55fc:	c3                   	ret
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	48 8b 3f             	mov    (%rdi),%rdi
    5603:	e9 78 fe ff ff       	jmp    5480 <fwp_drop4>
    5608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    560f:	00 

0000000000005610 <e50>:
    5610:	f3 0f 1e fa          	endbr64
    5614:	55                   	push   %rbp
    5615:	53                   	push   %rbx
    5616:	48 83 ec 08          	sub    $0x8,%rsp
    561a:	48 8b 1f             	mov    (%rdi),%rbx
    561d:	48 89 df             	mov    %rbx,%rdi
    5620:	e8 6b f0 ff ff       	call   4690 <fwp_rc_share>
    5625:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    5629:	48 89 df             	mov    %rbx,%rdi
    562c:	e8 4f fe ff ff       	call   5480 <fwp_drop4>
    5631:	48 89 ef             	mov    %rbp,%rdi
    5634:	e8 57 f0 ff ff       	call   4690 <fwp_rc_share>
    5639:	48 83 c4 08          	add    $0x8,%rsp
    563d:	48 89 e8             	mov    %rbp,%rax
    5640:	5b                   	pop    %rbx
    5641:	5d                   	pop    %rbp
    5642:	c3                   	ret
    5643:	66 90                	xchg   %ax,%ax
    5645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    564c:	00 00 00 00 

0000000000005650 <e47>:
    5650:	f3 0f 1e fa          	endbr64
    5654:	55                   	push   %rbp
    5655:	53                   	push   %rbx
    5656:	48 83 ec 08          	sub    $0x8,%rsp
    565a:	48 8b 1f             	mov    (%rdi),%rbx
    565d:	48 89 df             	mov    %rbx,%rdi
    5660:	e8 2b f0 ff ff       	call   4690 <fwp_rc_share>
    5665:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
    5669:	48 89 df             	mov    %rbx,%rdi
    566c:	e8 0f fe ff ff       	call   5480 <fwp_drop4>
    5671:	48 89 ef             	mov    %rbp,%rdi
    5674:	e8 17 f0 ff ff       	call   4690 <fwp_rc_share>
    5679:	48 83 c4 08          	add    $0x8,%rsp
    567d:	48 89 e8             	mov    %rbp,%rax
    5680:	5b                   	pop    %rbx
    5681:	5d                   	pop    %rbp
    5682:	c3                   	ret
    5683:	66 90                	xchg   %ax,%ax
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_arg_drop50>:
    5690:	f3 0f 1e fa          	endbr64
    5694:	85 f6                	test   %esi,%esi
    5696:	75 04                	jne    569c <fwp_arg_drop50+0xc>
    5698:	85 d2                	test   %edx,%edx
    569a:	75 04                	jne    56a0 <fwp_arg_drop50+0x10>
    569c:	c3                   	ret
    569d:	0f 1f 00             	nopl   (%rax)
    56a0:	48 8b 3f             	mov    (%rdi),%rdi
    56a3:	e9 d8 fd ff ff       	jmp    5480 <fwp_drop4>
    56a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56af:	00 

00000000000056b0 <fwp_args47>:
    56b0:	f3 0f 1e fa          	endbr64
    56b4:	85 d2                	test   %edx,%edx
    56b6:	74 04                	je     56bc <fwp_args47+0xc>
    56b8:	85 f6                	test   %esi,%esi
    56ba:	74 04                	je     56c0 <fwp_args47+0x10>
    56bc:	c3                   	ret
    56bd:	0f 1f 00             	nopl   (%rax)
    56c0:	48 8b 15 f1 83 01 00 	mov    0x183f1(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    56c7:	48 8b 07             	mov    (%rdi),%rax
    56ca:	48 2b 05 bf 83 01 00 	sub    0x183bf(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    56d1:	48 c1 e2 10          	shl    $0x10,%rdx
    56d5:	48 39 d0             	cmp    %rdx,%rax
    56d8:	73 e2                	jae    56bc <fwp_args47+0xc>
    56da:	48 89 c2             	mov    %rax,%rdx
    56dd:	48 c1 ea 10          	shr    $0x10,%rdx
    56e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    56e5:	48 8b 15 ec 83 01 00 	mov    0x183ec(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    56ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    56f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    56f4:	48 85 ff             	test   %rdi,%rdi
    56f7:	74 c3                	je     56bc <fwp_args47+0xc>
    56f9:	0f b6 0a             	movzbl (%rdx),%ecx
    56fc:	80 f9 02             	cmp    $0x2,%cl
    56ff:	74 2f                	je     5730 <fwp_args47+0x80>
    5701:	80 f9 01             	cmp    $0x1,%cl
    5704:	75 b6                	jne    56bc <fwp_args47+0xc>
    5706:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5709:	0f b7 c0             	movzwl %ax,%eax
    570c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    570f:	48 0f af c1          	imul   %rcx,%rax
    5713:	48 c1 e8 20          	shr    $0x20,%rax
    5717:	48 39 d0             	cmp    %rdx,%rax
    571a:	73 a0                	jae    56bc <fwp_args47+0xc>
    571c:	48 01 c7             	add    %rax,%rdi
    571f:	0f b6 07             	movzbl (%rdi),%eax
    5722:	84 c0                	test   %al,%al
    5724:	74 96                	je     56bc <fwp_args47+0xc>
    5726:	3c fd                	cmp    $0xfd,%al
    5728:	77 0c                	ja     5736 <fwp_args47+0x86>
    572a:	83 c0 01             	add    $0x1,%eax
    572d:	88 07                	mov    %al,(%rdi)
    572f:	c3                   	ret
    5730:	66 85 c0             	test   %ax,%ax
    5733:	74 ea                	je     571f <fwp_args47+0x6f>
    5735:	c3                   	ret
    5736:	e9 f5 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    573b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005740 <fwp_args50>:
    5740:	f3 0f 1e fa          	endbr64
    5744:	85 d2                	test   %edx,%edx
    5746:	74 04                	je     574c <fwp_args50+0xc>
    5748:	85 f6                	test   %esi,%esi
    574a:	74 04                	je     5750 <fwp_args50+0x10>
    574c:	c3                   	ret
    574d:	0f 1f 00             	nopl   (%rax)
    5750:	48 8b 15 61 83 01 00 	mov    0x18361(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    5757:	48 8b 07             	mov    (%rdi),%rax
    575a:	48 2b 05 2f 83 01 00 	sub    0x1832f(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    5761:	48 c1 e2 10          	shl    $0x10,%rdx
    5765:	48 39 d0             	cmp    %rdx,%rax
    5768:	73 e2                	jae    574c <fwp_args50+0xc>
    576a:	48 89 c2             	mov    %rax,%rdx
    576d:	48 c1 ea 10          	shr    $0x10,%rdx
    5771:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5775:	48 8b 15 5c 83 01 00 	mov    0x1835c(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    577c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5780:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5784:	48 85 ff             	test   %rdi,%rdi
    5787:	74 c3                	je     574c <fwp_args50+0xc>
    5789:	0f b6 0a             	movzbl (%rdx),%ecx
    578c:	80 f9 02             	cmp    $0x2,%cl
    578f:	74 2f                	je     57c0 <fwp_args50+0x80>
    5791:	80 f9 01             	cmp    $0x1,%cl
    5794:	75 b6                	jne    574c <fwp_args50+0xc>
    5796:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5799:	0f b7 c0             	movzwl %ax,%eax
    579c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    579f:	48 0f af c1          	imul   %rcx,%rax
    57a3:	48 c1 e8 20          	shr    $0x20,%rax
    57a7:	48 39 d0             	cmp    %rdx,%rax
    57aa:	73 a0                	jae    574c <fwp_args50+0xc>
    57ac:	48 01 c7             	add    %rax,%rdi
    57af:	0f b6 07             	movzbl (%rdi),%eax
    57b2:	84 c0                	test   %al,%al
    57b4:	74 96                	je     574c <fwp_args50+0xc>
    57b6:	3c fd                	cmp    $0xfd,%al
    57b8:	77 0c                	ja     57c6 <fwp_args50+0x86>
    57ba:	83 c0 01             	add    $0x1,%eax
    57bd:	88 07                	mov    %al,(%rdi)
    57bf:	c3                   	ret
    57c0:	66 85 c0             	test   %ax,%ax
    57c3:	74 ea                	je     57af <fwp_args50+0x6f>
    57c5:	c3                   	ret
    57c6:	e9 65 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    57cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000057d0 <fwp_caps47>:
    57d0:	f3 0f 1e fa          	endbr64
    57d4:	48 83 ec 18          	sub    $0x18,%rsp
    57d8:	8b 57 04             	mov    0x4(%rdi),%edx
    57db:	48 89 f8             	mov    %rdi,%rax
    57de:	85 d2                	test   %edx,%edx
    57e0:	0f 84 9a 00 00 00    	je     5880 <fwp_caps47+0xb0>
    57e6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    57ea:	85 f6                	test   %esi,%esi
    57ec:	0f 85 9e 00 00 00    	jne    5890 <fwp_caps47+0xc0>
    57f2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    57f7:	e8 84 fc ff ff       	call   5480 <fwp_drop4>
    57fc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5801:	48 8b 0d b0 82 01 00 	mov    0x182b0(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    5808:	48 89 c2             	mov    %rax,%rdx
    580b:	48 2b 15 7e 82 01 00 	sub    0x1827e(%rip),%rdx        # 1da90 <fwp_heap+0x13b0>
    5812:	48 c1 e1 10          	shl    $0x10,%rcx
    5816:	48 39 ca             	cmp    %rcx,%rdx
    5819:	73 6d                	jae    5888 <fwp_caps47+0xb8>
    581b:	48 89 d1             	mov    %rdx,%rcx
    581e:	48 c1 e9 10          	shr    $0x10,%rcx
    5822:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5826:	48 8b 0d ab 82 01 00 	mov    0x182ab(%rip),%rcx        # 1dad8 <fwp_heap+0x13f8>
    582d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5831:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5835:	48 85 f6             	test   %rsi,%rsi
    5838:	74 4e                	je     5888 <fwp_caps47+0xb8>
    583a:	0f b6 39             	movzbl (%rcx),%edi
    583d:	40 80 ff 02          	cmp    $0x2,%dil
    5841:	0f 84 b9 00 00 00    	je     5900 <fwp_caps47+0x130>
    5847:	40 80 ff 01          	cmp    $0x1,%dil
    584b:	75 3b                	jne    5888 <fwp_caps47+0xb8>
    584d:	8b 79 18             	mov    0x18(%rcx),%edi
    5850:	0f b7 d2             	movzwl %dx,%edx
    5853:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5856:	48 0f af d7          	imul   %rdi,%rdx
    585a:	48 c1 ea 20          	shr    $0x20,%rdx
    585e:	48 39 ca             	cmp    %rcx,%rdx
    5861:	73 25                	jae    5888 <fwp_caps47+0xb8>
    5863:	48 01 d6             	add    %rdx,%rsi
    5866:	80 3e 01             	cmpb   $0x1,(%rsi)
    5869:	75 1d                	jne    5888 <fwp_caps47+0xb8>
    586b:	48 89 c7             	mov    %rax,%rdi
    586e:	48 83 c4 18          	add    $0x18,%rsp
    5872:	e9 19 e9 ff ff       	jmp    4190 <fwp_mem_free>
    5877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    587e:	00 00 
    5880:	85 f6                	test   %esi,%esi
    5882:	0f 84 79 ff ff ff    	je     5801 <fwp_caps47+0x31>
    5888:	48 83 c4 18          	add    $0x18,%rsp
    588c:	c3                   	ret
    588d:	0f 1f 00             	nopl   (%rax)
    5890:	48 8b 05 21 82 01 00 	mov    0x18221(%rip),%rax        # 1dab8 <fwp_heap+0x13d8>
    5897:	48 2b 3d f2 81 01 00 	sub    0x181f2(%rip),%rdi        # 1da90 <fwp_heap+0x13b0>
    589e:	48 c1 e0 10          	shl    $0x10,%rax
    58a2:	48 39 c7             	cmp    %rax,%rdi
    58a5:	73 e1                	jae    5888 <fwp_caps47+0xb8>
    58a7:	48 89 f8             	mov    %rdi,%rax
    58aa:	48 c1 e8 10          	shr    $0x10,%rax
    58ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    58b2:	48 8b 05 1f 82 01 00 	mov    0x1821f(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    58b9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    58bd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    58c1:	48 85 c0             	test   %rax,%rax
    58c4:	74 c2                	je     5888 <fwp_caps47+0xb8>
    58c6:	0f b6 0a             	movzbl (%rdx),%ecx
    58c9:	80 f9 02             	cmp    $0x2,%cl
    58cc:	74 42                	je     5910 <fwp_caps47+0x140>
    58ce:	80 f9 01             	cmp    $0x1,%cl
    58d1:	75 b5                	jne    5888 <fwp_caps47+0xb8>
    58d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    58d6:	0f b7 ff             	movzwl %di,%edi
    58d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    58dc:	48 0f af f9          	imul   %rcx,%rdi
    58e0:	48 c1 ef 20          	shr    $0x20,%rdi
    58e4:	48 39 d7             	cmp    %rdx,%rdi
    58e7:	73 9f                	jae    5888 <fwp_caps47+0xb8>
    58e9:	48 01 f8             	add    %rdi,%rax
    58ec:	0f b6 10             	movzbl (%rax),%edx
    58ef:	84 d2                	test   %dl,%dl
    58f1:	74 95                	je     5888 <fwp_caps47+0xb8>
    58f3:	80 fa fd             	cmp    $0xfd,%dl
    58f6:	77 23                	ja     591b <fwp_caps47+0x14b>
    58f8:	83 c2 01             	add    $0x1,%edx
    58fb:	88 10                	mov    %dl,(%rax)
    58fd:	eb 89                	jmp    5888 <fwp_caps47+0xb8>
    58ff:	90                   	nop
    5900:	66 85 d2             	test   %dx,%dx
    5903:	0f 85 7f ff ff ff    	jne    5888 <fwp_caps47+0xb8>
    5909:	e9 58 ff ff ff       	jmp    5866 <fwp_caps47+0x96>
    590e:	66 90                	xchg   %ax,%ax
    5910:	66 85 ff             	test   %di,%di
    5913:	0f 85 6f ff ff ff    	jne    5888 <fwp_caps47+0xb8>
    5919:	eb d1                	jmp    58ec <fwp_caps47+0x11c>
    591b:	48 89 c7             	mov    %rax,%rdi
    591e:	48 83 c4 18          	add    $0x18,%rsp
    5922:	e9 09 e5 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    592e:	00 00 

0000000000005930 <fwp_caps50>:
    5930:	f3 0f 1e fa          	endbr64
    5934:	48 83 ec 18          	sub    $0x18,%rsp
    5938:	8b 57 04             	mov    0x4(%rdi),%edx
    593b:	48 89 f8             	mov    %rdi,%rax
    593e:	85 d2                	test   %edx,%edx
    5940:	0f 84 9a 00 00 00    	je     59e0 <fwp_caps50+0xb0>
    5946:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    594a:	85 f6                	test   %esi,%esi
    594c:	0f 85 9e 00 00 00    	jne    59f0 <fwp_caps50+0xc0>
    5952:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5957:	e8 24 fb ff ff       	call   5480 <fwp_drop4>
    595c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5961:	48 8b 0d 50 81 01 00 	mov    0x18150(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    5968:	48 89 c2             	mov    %rax,%rdx
    596b:	48 2b 15 1e 81 01 00 	sub    0x1811e(%rip),%rdx        # 1da90 <fwp_heap+0x13b0>
    5972:	48 c1 e1 10          	shl    $0x10,%rcx
    5976:	48 39 ca             	cmp    %rcx,%rdx
    5979:	73 6d                	jae    59e8 <fwp_caps50+0xb8>
    597b:	48 89 d1             	mov    %rdx,%rcx
    597e:	48 c1 e9 10          	shr    $0x10,%rcx
    5982:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5986:	48 8b 0d 4b 81 01 00 	mov    0x1814b(%rip),%rcx        # 1dad8 <fwp_heap+0x13f8>
    598d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5991:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5995:	48 85 f6             	test   %rsi,%rsi
    5998:	74 4e                	je     59e8 <fwp_caps50+0xb8>
    599a:	0f b6 39             	movzbl (%rcx),%edi
    599d:	40 80 ff 02          	cmp    $0x2,%dil
    59a1:	0f 84 b9 00 00 00    	je     5a60 <fwp_caps50+0x130>
    59a7:	40 80 ff 01          	cmp    $0x1,%dil
    59ab:	75 3b                	jne    59e8 <fwp_caps50+0xb8>
    59ad:	8b 79 18             	mov    0x18(%rcx),%edi
    59b0:	0f b7 d2             	movzwl %dx,%edx
    59b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    59b6:	48 0f af d7          	imul   %rdi,%rdx
    59ba:	48 c1 ea 20          	shr    $0x20,%rdx
    59be:	48 39 ca             	cmp    %rcx,%rdx
    59c1:	73 25                	jae    59e8 <fwp_caps50+0xb8>
    59c3:	48 01 d6             	add    %rdx,%rsi
    59c6:	80 3e 01             	cmpb   $0x1,(%rsi)
    59c9:	75 1d                	jne    59e8 <fwp_caps50+0xb8>
    59cb:	48 89 c7             	mov    %rax,%rdi
    59ce:	48 83 c4 18          	add    $0x18,%rsp
    59d2:	e9 b9 e7 ff ff       	jmp    4190 <fwp_mem_free>
    59d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59de:	00 00 
    59e0:	85 f6                	test   %esi,%esi
    59e2:	0f 84 79 ff ff ff    	je     5961 <fwp_caps50+0x31>
    59e8:	48 83 c4 18          	add    $0x18,%rsp
    59ec:	c3                   	ret
    59ed:	0f 1f 00             	nopl   (%rax)
    59f0:	48 8b 05 c1 80 01 00 	mov    0x180c1(%rip),%rax        # 1dab8 <fwp_heap+0x13d8>
    59f7:	48 2b 3d 92 80 01 00 	sub    0x18092(%rip),%rdi        # 1da90 <fwp_heap+0x13b0>
    59fe:	48 c1 e0 10          	shl    $0x10,%rax
    5a02:	48 39 c7             	cmp    %rax,%rdi
    5a05:	73 e1                	jae    59e8 <fwp_caps50+0xb8>
    5a07:	48 89 f8             	mov    %rdi,%rax
    5a0a:	48 c1 e8 10          	shr    $0x10,%rax
    5a0e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5a12:	48 8b 05 bf 80 01 00 	mov    0x180bf(%rip),%rax        # 1dad8 <fwp_heap+0x13f8>
    5a19:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    5a1d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    5a21:	48 85 c0             	test   %rax,%rax
    5a24:	74 c2                	je     59e8 <fwp_caps50+0xb8>
    5a26:	0f b6 0a             	movzbl (%rdx),%ecx
    5a29:	80 f9 02             	cmp    $0x2,%cl
    5a2c:	74 42                	je     5a70 <fwp_caps50+0x140>
    5a2e:	80 f9 01             	cmp    $0x1,%cl
    5a31:	75 b5                	jne    59e8 <fwp_caps50+0xb8>
    5a33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5a36:	0f b7 ff             	movzwl %di,%edi
    5a39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5a3c:	48 0f af f9          	imul   %rcx,%rdi
    5a40:	48 c1 ef 20          	shr    $0x20,%rdi
    5a44:	48 39 d7             	cmp    %rdx,%rdi
    5a47:	73 9f                	jae    59e8 <fwp_caps50+0xb8>
    5a49:	48 01 f8             	add    %rdi,%rax
    5a4c:	0f b6 10             	movzbl (%rax),%edx
    5a4f:	84 d2                	test   %dl,%dl
    5a51:	74 95                	je     59e8 <fwp_caps50+0xb8>
    5a53:	80 fa fd             	cmp    $0xfd,%dl
    5a56:	77 23                	ja     5a7b <fwp_caps50+0x14b>
    5a58:	83 c2 01             	add    $0x1,%edx
    5a5b:	88 10                	mov    %dl,(%rax)
    5a5d:	eb 89                	jmp    59e8 <fwp_caps50+0xb8>
    5a5f:	90                   	nop
    5a60:	66 85 d2             	test   %dx,%dx
    5a63:	0f 85 7f ff ff ff    	jne    59e8 <fwp_caps50+0xb8>
    5a69:	e9 58 ff ff ff       	jmp    59c6 <fwp_caps50+0x96>
    5a6e:	66 90                	xchg   %ax,%ax
    5a70:	66 85 ff             	test   %di,%di
    5a73:	0f 85 6f ff ff ff    	jne    59e8 <fwp_caps50+0xb8>
    5a79:	eb d1                	jmp    5a4c <fwp_caps50+0x11c>
    5a7b:	48 89 c7             	mov    %rax,%rdi
    5a7e:	48 83 c4 18          	add    $0x18,%rsp
    5a82:	e9 a9 e3 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a8e:	00 00 

0000000000005a90 <fwp_drop0>:
    5a90:	f3 0f 1e fa          	endbr64
    5a94:	48 8b 15 1d 80 01 00 	mov    0x1801d(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    5a9b:	48 89 f8             	mov    %rdi,%rax
    5a9e:	48 2b 05 eb 7f 01 00 	sub    0x17feb(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    5aa5:	48 c1 e2 10          	shl    $0x10,%rdx
    5aa9:	48 39 d0             	cmp    %rdx,%rax
    5aac:	0f 83 36 01 00 00    	jae    5be8 <fwp_drop0+0x158>
    5ab2:	48 83 ec 18          	sub    $0x18,%rsp
    5ab6:	48 8d 35 23 6c 01 00 	lea    0x16c23(%rip),%rsi        # 1c6e0 <fwp_heap>
    5abd:	48 89 c2             	mov    %rax,%rdx
    5ac0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    5ac7:	48 c1 ea 10          	shr    $0x10,%rdx
    5acb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    5acf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    5ad3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5ad7:	48 85 d2             	test   %rdx,%rdx
    5ada:	74 42                	je     5b1e <fwp_drop0+0x8e>
    5adc:	44 0f b6 01          	movzbl (%rcx),%r8d
    5ae0:	41 80 f8 02          	cmp    $0x2,%r8b
    5ae4:	74 42                	je     5b28 <fwp_drop0+0x98>
    5ae6:	41 80 f8 01          	cmp    $0x1,%r8b
    5aea:	75 32                	jne    5b1e <fwp_drop0+0x8e>
    5aec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    5af0:	0f b7 c0             	movzwl %ax,%eax
    5af3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5af6:	49 0f af c0          	imul   %r8,%rax
    5afa:	48 c1 e8 20          	shr    $0x20,%rax
    5afe:	48 39 c8             	cmp    %rcx,%rax
    5b01:	73 1b                	jae    5b1e <fwp_drop0+0x8e>
    5b03:	48 01 c2             	add    %rax,%rdx
    5b06:	0f b6 02             	movzbl (%rdx),%eax
    5b09:	84 c0                	test   %al,%al
    5b0b:	74 11                	je     5b1e <fwp_drop0+0x8e>
    5b0d:	3c 01                	cmp    $0x1,%al
    5b0f:	74 27                	je     5b38 <fwp_drop0+0xa8>
    5b11:	3c ff                	cmp    $0xff,%al
    5b13:	0f 84 e7 00 00 00    	je     5c00 <fwp_drop0+0x170>
    5b19:	83 e8 01             	sub    $0x1,%eax
    5b1c:	88 02                	mov    %al,(%rdx)
    5b1e:	48 83 c4 18          	add    $0x18,%rsp
    5b22:	c3                   	ret
    5b23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b28:	66 85 c0             	test   %ax,%ax
    5b2b:	74 d9                	je     5b06 <fwp_drop0+0x76>
    5b2d:	48 83 c4 18          	add    $0x18,%rsp
    5b31:	c3                   	ret
    5b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5b3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5b46:	48 89 f8             	mov    %rdi,%rax
    5b49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    5b4d:	48 29 c8             	sub    %rcx,%rax
    5b50:	48 c1 e2 10          	shl    $0x10,%rdx
    5b54:	48 39 d0             	cmp    %rdx,%rax
    5b57:	73 71                	jae    5bca <fwp_drop0+0x13a>
    5b59:	49 89 c2             	mov    %rax,%r10
    5b5c:	49 c1 ea 10          	shr    $0x10,%r10
    5b60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    5b64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    5b68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    5b6c:	4d 85 d2             	test   %r10,%r10
    5b6f:	74 59                	je     5bca <fwp_drop0+0x13a>
    5b71:	45 0f b6 19          	movzbl (%r9),%r11d
    5b75:	41 80 fb 02          	cmp    $0x2,%r11b
    5b79:	74 75                	je     5bf0 <fwp_drop0+0x160>
    5b7b:	41 80 fb 01          	cmp    $0x1,%r11b
    5b7f:	75 49                	jne    5bca <fwp_drop0+0x13a>
    5b81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    5b85:	0f b7 c0             	movzwl %ax,%eax
    5b88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    5b8c:	49 0f af c3          	imul   %r11,%rax
    5b90:	48 c1 e8 20          	shr    $0x20,%rax
    5b94:	4c 39 c8             	cmp    %r9,%rax
    5b97:	73 31                	jae    5bca <fwp_drop0+0x13a>
    5b99:	49 01 c2             	add    %rax,%r10
    5b9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5ba0:	75 28                	jne    5bca <fwp_drop0+0x13a>
    5ba2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ba7:	e8 e4 e5 ff ff       	call   4190 <fwp_mem_free>
    5bac:	48 8d 35 2d 6b 01 00 	lea    0x16b2d(%rip),%rsi        # 1c6e0 <fwp_heap>
    5bb3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5bb8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5bbf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5bc6:	48 c1 e2 10          	shl    $0x10,%rdx
    5bca:	4c 89 c0             	mov    %r8,%rax
    5bcd:	48 29 c8             	sub    %rcx,%rax
    5bd0:	48 39 d0             	cmp    %rdx,%rax
    5bd3:	0f 83 45 ff ff ff    	jae    5b1e <fwp_drop0+0x8e>
    5bd9:	4c 89 c7             	mov    %r8,%rdi
    5bdc:	e9 dc fe ff ff       	jmp    5abd <fwp_drop0+0x2d>
    5be1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5be8:	c3                   	ret
    5be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5bf0:	66 85 c0             	test   %ax,%ax
    5bf3:	75 d5                	jne    5bca <fwp_drop0+0x13a>
    5bf5:	eb a5                	jmp    5b9c <fwp_drop0+0x10c>
    5bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bfe:	00 00 
    5c00:	48 89 d0             	mov    %rdx,%rax
    5c03:	48 c1 e8 11          	shr    $0x11,%rax
    5c07:	48 31 d0             	xor    %rdx,%rax
    5c0a:	48 89 c1             	mov    %rax,%rcx
    5c0d:	48 c1 e9 09          	shr    $0x9,%rcx
    5c11:	48 31 c8             	xor    %rcx,%rax
    5c14:	0f b6 c8             	movzbl %al,%ecx
    5c17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5c1e:	00 
    5c1f:	48 85 c0             	test   %rax,%rax
    5c22:	75 25                	jne    5c49 <fwp_drop0+0x1b9>
    5c24:	eb 5e                	jmp    5c84 <fwp_drop0+0x1f4>
    5c26:	0f 1f 40 00          	nopl   0x0(%rax)
    5c2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c31:	00 00 00 00 
    5c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c3c:	00 00 00 00 
    5c40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5c44:	48 85 c0             	test   %rax,%rax
    5c47:	74 3b                	je     5c84 <fwp_drop0+0x1f4>
    5c49:	48 89 c1             	mov    %rax,%rcx
    5c4c:	48 39 10             	cmp    %rdx,(%rax)
    5c4f:	75 ef                	jne    5c40 <fwp_drop0+0x1b0>
    5c51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5c55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5c59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    5c5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5c64:	0f 85 b4 fe ff ff    	jne    5b1e <fwp_drop0+0x8e>
    5c6a:	48 89 d7             	mov    %rdx,%rdi
    5c6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c72:	e8 d9 e2 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5c77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    5c7f:	e9 9a fe ff ff       	jmp    5b1e <fwp_drop0+0x8e>
    5c84:	48 8d 3d 25 36 00 00 	lea    0x3625(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    5c8b:	e8 90 d4 ff ff       	call   3120 <fwp_trap>

0000000000005c90 <fwp_drop1>:
    5c90:	f3 0f 1e fa          	endbr64
    5c94:	e9 f7 fd ff ff       	jmp    5a90 <fwp_drop0>
    5c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005ca0 <fwp_drop6>:
    5ca0:	f3 0f 1e fa          	endbr64
    5ca4:	48 8b 0d 0d 7e 01 00 	mov    0x17e0d(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    5cab:	48 89 f8             	mov    %rdi,%rax
    5cae:	48 2b 05 db 7d 01 00 	sub    0x17ddb(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    5cb5:	48 c1 e1 10          	shl    $0x10,%rcx
    5cb9:	48 39 c8             	cmp    %rcx,%rax
    5cbc:	0f 83 56 01 00 00    	jae    5e18 <fwp_drop6+0x178>
    5cc2:	48 83 ec 18          	sub    $0x18,%rsp
    5cc6:	48 89 fa             	mov    %rdi,%rdx
    5cc9:	4c 8d 05 10 6a 01 00 	lea    0x16a10(%rip),%r8        # 1c6e0 <fwp_heap>
    5cd0:	48 89 c1             	mov    %rax,%rcx
    5cd3:	48 c1 e9 10          	shr    $0x10,%rcx
    5cd7:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5cdb:	49 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%rcx
    5ce2:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    5ce6:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    5cea:	48 85 c9             	test   %rcx,%rcx
    5ced:	74 40                	je     5d2f <fwp_drop6+0x8f>
    5cef:	0f b6 3e             	movzbl (%rsi),%edi
    5cf2:	40 80 ff 02          	cmp    $0x2,%dil
    5cf6:	74 40                	je     5d38 <fwp_drop6+0x98>
    5cf8:	40 80 ff 01          	cmp    $0x1,%dil
    5cfc:	75 31                	jne    5d2f <fwp_drop6+0x8f>
    5cfe:	8b 7e 18             	mov    0x18(%rsi),%edi
    5d01:	0f b7 c0             	movzwl %ax,%eax
    5d04:	8b 76 1c             	mov    0x1c(%rsi),%esi
    5d07:	48 0f af c7          	imul   %rdi,%rax
    5d0b:	48 c1 e8 20          	shr    $0x20,%rax
    5d0f:	48 39 f0             	cmp    %rsi,%rax
    5d12:	73 1b                	jae    5d2f <fwp_drop6+0x8f>
    5d14:	48 01 c1             	add    %rax,%rcx
    5d17:	0f b6 01             	movzbl (%rcx),%eax
    5d1a:	84 c0                	test   %al,%al
    5d1c:	74 11                	je     5d2f <fwp_drop6+0x8f>
    5d1e:	3c 01                	cmp    $0x1,%al
    5d20:	74 26                	je     5d48 <fwp_drop6+0xa8>
    5d22:	3c ff                	cmp    $0xff,%al
    5d24:	0f 84 06 01 00 00    	je     5e30 <fwp_drop6+0x190>
    5d2a:	83 e8 01             	sub    $0x1,%eax
    5d2d:	88 01                	mov    %al,(%rcx)
    5d2f:	48 83 c4 18          	add    $0x18,%rsp
    5d33:	c3                   	ret
    5d34:	0f 1f 40 00          	nopl   0x0(%rax)
    5d38:	66 85 c0             	test   %ax,%ax
    5d3b:	74 da                	je     5d17 <fwp_drop6+0x77>
    5d3d:	48 83 c4 18          	add    $0x18,%rsp
    5d41:	c3                   	ret
    5d42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d48:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    5d4c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5d51:	e8 2a f7 ff ff       	call   5480 <fwp_drop4>
    5d56:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d5b:	4c 8d 05 7e 69 01 00 	lea    0x1697e(%rip),%r8        # 1c6e0 <fwp_heap>
    5d62:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5d69:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5d70:	48 89 d0             	mov    %rdx,%rax
    5d73:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    5d77:	48 29 f0             	sub    %rsi,%rax
    5d7a:	48 c1 e1 10          	shl    $0x10,%rcx
    5d7e:	48 39 c8             	cmp    %rcx,%rax
    5d81:	73 7a                	jae    5dfd <fwp_drop6+0x15d>
    5d83:	48 89 c7             	mov    %rax,%rdi
    5d86:	48 c1 ef 10          	shr    $0x10,%rdi
    5d8a:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
    5d8e:	49 8b b8 f8 13 00 00 	mov    0x13f8(%r8),%rdi
    5d95:	4a 8d 3c d7          	lea    (%rdi,%r10,8),%rdi
    5d99:	4c 8b 57 20          	mov    0x20(%rdi),%r10
    5d9d:	4d 85 d2             	test   %r10,%r10
    5da0:	74 5b                	je     5dfd <fwp_drop6+0x15d>
    5da2:	44 0f b6 1f          	movzbl (%rdi),%r11d
    5da6:	41 80 fb 02          	cmp    $0x2,%r11b
    5daa:	74 74                	je     5e20 <fwp_drop6+0x180>
    5dac:	41 80 fb 01          	cmp    $0x1,%r11b
    5db0:	75 4b                	jne    5dfd <fwp_drop6+0x15d>
    5db2:	44 8b 5f 18          	mov    0x18(%rdi),%r11d
    5db6:	0f b7 c0             	movzwl %ax,%eax
    5db9:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    5dbc:	49 0f af c3          	imul   %r11,%rax
    5dc0:	48 c1 e8 20          	shr    $0x20,%rax
    5dc4:	48 39 f8             	cmp    %rdi,%rax
    5dc7:	73 34                	jae    5dfd <fwp_drop6+0x15d>
    5dc9:	49 01 c2             	add    %rax,%r10
    5dcc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5dd0:	75 2b                	jne    5dfd <fwp_drop6+0x15d>
    5dd2:	48 89 d7             	mov    %rdx,%rdi
    5dd5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5dda:	e8 b1 e3 ff ff       	call   4190 <fwp_mem_free>
    5ddf:	4c 8d 05 fa 68 01 00 	lea    0x168fa(%rip),%r8        # 1c6e0 <fwp_heap>
    5de6:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5deb:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5df2:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5df9:	48 c1 e1 10          	shl    $0x10,%rcx
    5dfd:	4c 89 c8             	mov    %r9,%rax
    5e00:	48 29 f0             	sub    %rsi,%rax
    5e03:	48 39 c8             	cmp    %rcx,%rax
    5e06:	0f 83 23 ff ff ff    	jae    5d2f <fwp_drop6+0x8f>
    5e0c:	4c 89 ca             	mov    %r9,%rdx
    5e0f:	e9 bc fe ff ff       	jmp    5cd0 <fwp_drop6+0x30>
    5e14:	0f 1f 40 00          	nopl   0x0(%rax)
    5e18:	c3                   	ret
    5e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e20:	66 85 c0             	test   %ax,%ax
    5e23:	75 d8                	jne    5dfd <fwp_drop6+0x15d>
    5e25:	eb a5                	jmp    5dcc <fwp_drop6+0x12c>
    5e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e2e:	00 00 
    5e30:	48 89 c8             	mov    %rcx,%rax
    5e33:	48 c1 e8 11          	shr    $0x11,%rax
    5e37:	48 31 c8             	xor    %rcx,%rax
    5e3a:	48 89 c2             	mov    %rax,%rdx
    5e3d:	48 c1 ea 09          	shr    $0x9,%rdx
    5e41:	48 31 d0             	xor    %rdx,%rax
    5e44:	0f b6 d0             	movzbl %al,%edx
    5e47:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    5e4e:	00 
    5e4f:	48 85 c0             	test   %rax,%rax
    5e52:	75 15                	jne    5e69 <fwp_drop6+0x1c9>
    5e54:	eb 4e                	jmp    5ea4 <fwp_drop6+0x204>
    5e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e5d:	00 00 00 
    5e60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    5e64:	48 85 c0             	test   %rax,%rax
    5e67:	74 3b                	je     5ea4 <fwp_drop6+0x204>
    5e69:	48 89 c2             	mov    %rax,%rdx
    5e6c:	48 39 08             	cmp    %rcx,(%rax)
    5e6f:	75 ef                	jne    5e60 <fwp_drop6+0x1c0>
    5e71:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5e75:	48 83 ea 01          	sub    $0x1,%rdx
    5e79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    5e84:	0f 85 a5 fe ff ff    	jne    5d2f <fwp_drop6+0x8f>
    5e8a:	48 89 cf             	mov    %rcx,%rdi
    5e8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e92:	e8 b9 e0 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5e97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    5e9f:	e9 8b fe ff ff       	jmp    5d2f <fwp_drop6+0x8f>
    5ea4:	48 8d 3d 05 34 00 00 	lea    0x3405(%rip),%rdi        # 92b0 <_IO_stdin_used+0x2b0>
    5eab:	e8 70 d2 ff ff       	call   3120 <fwp_trap>

0000000000005eb0 <fwp_write>:
    5eb0:	41 57                	push   %r15
    5eb2:	41 56                	push   %r14
    5eb4:	41 55                	push   %r13
    5eb6:	41 54                	push   %r12
    5eb8:	55                   	push   %rbp
    5eb9:	53                   	push   %rbx
    5eba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    5ec1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5ec8:	00 00 
    5eca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    5ed1:	00 
    5ed2:	49 89 d4             	mov    %rdx,%r12
    5ed5:	8b 12                	mov    (%rdx),%edx
    5ed7:	83 fa 19             	cmp    $0x19,%edx
    5eda:	77 6a                	ja     5f46 <fwp_write+0x96>
    5edc:	48 89 f5             	mov    %rsi,%rbp
    5edf:	89 d0                	mov    %edx,%eax
    5ee1:	89 ce                	mov    %ecx,%esi
    5ee3:	48 89 fb             	mov    %rdi,%rbx
    5ee6:	48 8d 0d f3 34 00 00 	lea    0x34f3(%rip),%rcx        # 93e0 <_IO_stdin_used+0x3e0>
    5eed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    5ef1:	48 01 c8             	add    %rcx,%rax
    5ef4:	3e ff e0             	notrack jmp *%rax
    5ef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5efe:	00 00 
    5f00:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    5f04:	48 8b 45 00          	mov    0x0(%rbp),%rax
    5f08:	48 89 ca             	mov    %rcx,%rdx
    5f0b:	48 85 c9             	test   %rcx,%rcx
    5f0e:	0f 88 9c 0c 00 00    	js     6bb0 <fwp_write+0xd00>
    5f14:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f1b:	00 
    5f1c:	48 89 c6             	mov    %rax,%rsi
    5f1f:	4c 89 e7             	mov    %r12,%rdi
    5f22:	e8 d9 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f2e:	00 00 
    5f30:	4c 89 e7             	mov    %r12,%rdi
    5f33:	e8 f8 c4 ff ff       	call   2430 <strlen@plt>
    5f38:	4c 89 e6             	mov    %r12,%rsi
    5f3b:	48 89 df             	mov    %rbx,%rdi
    5f3e:	48 89 c2             	mov    %rax,%rdx
    5f41:	e8 aa d0 ff ff       	call   2ff0 <buf_put>
    5f46:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5f4d:	00 
    5f4e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f55:	00 00 
    5f57:	0f 85 28 04 00 00    	jne    6385 <fwp_write+0x4d5>
    5f5d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    5f64:	5b                   	pop    %rbx
    5f65:	5d                   	pop    %rbp
    5f66:	41 5c                	pop    %r12
    5f68:	41 5d                	pop    %r13
    5f6a:	41 5e                	pop    %r14
    5f6c:	41 5f                	pop    %r15
    5f6e:	c3                   	ret
    5f6f:	90                   	nop
    5f70:	49 89 e9             	mov    %rbp,%r9
    5f73:	4c 8d 05 7a 31 00 00 	lea    0x317a(%rip),%r8        # 90f4 <_IO_stdin_used+0xf4>
    5f7a:	b9 00 02 00 00       	mov    $0x200,%ecx
    5f7f:	ba 02 00 00 00       	mov    $0x2,%edx
    5f84:	be 00 02 00 00       	mov    $0x200,%esi
    5f89:	31 c0                	xor    %eax,%eax
    5f8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f92:	00 
    5f93:	e8 f8 c3 ff ff       	call   2390 <__snprintf_chk@plt>
    5f98:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f9f:	00 
    5fa0:	e8 8b c4 ff ff       	call   2430 <strlen@plt>
    5fa5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5fac:	00 
    5fad:	48 89 df             	mov    %rbx,%rdi
    5fb0:	48 89 c2             	mov    %rax,%rdx
    5fb3:	e8 38 d0 ff ff       	call   2ff0 <buf_put>
    5fb8:	eb 8c                	jmp    5f46 <fwp_write+0x96>
    5fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fc0:	49 89 e9             	mov    %rbp,%r9
    5fc3:	4c 8d 05 25 31 00 00 	lea    0x3125(%rip),%r8        # 90ef <_IO_stdin_used+0xef>
    5fca:	eb ae                	jmp    5f7a <fwp_write+0xca>
    5fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    5fd0:	83 fa 13             	cmp    $0x13,%edx
    5fd3:	48 8d 05 0b 31 00 00 	lea    0x310b(%rip),%rax        # 90e5 <_IO_stdin_used+0xe5>
    5fda:	48 8d 35 09 31 00 00 	lea    0x3109(%rip),%rsi        # 90ea <_IO_stdin_used+0xea>
    5fe1:	ba 04 00 00 00       	mov    $0x4,%edx
    5fe6:	48 0f 44 f0          	cmove  %rax,%rsi
    5fea:	45 31 ed             	xor    %r13d,%r13d
    5fed:	e8 fe cf ff ff       	call   2ff0 <buf_put>
    5ff2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5ff7:	0f 84 a3 08 00 00    	je     68a0 <fwp_write+0x9f0>
    5ffd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    6002:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    6007:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    600c:	48 89 df             	mov    %rbx,%rdi
    600f:	49 0f 44 c5          	cmove  %r13,%rax
    6013:	31 c9                	xor    %ecx,%ecx
    6015:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    601a:	e8 91 fe ff ff       	call   5eb0 <fwp_write>
    601f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    6024:	0f 84 6e 09 00 00    	je     6998 <fwp_write+0xae8>
    602a:	49 83 c5 01          	add    $0x1,%r13
    602e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    6032:	0f 83 68 08 00 00    	jae    68a0 <fwp_write+0x9f0>
    6038:	ba 02 00 00 00       	mov    $0x2,%edx
    603d:	48 8d 35 f0 30 00 00 	lea    0x30f0(%rip),%rsi        # 9134 <_IO_stdin_used+0x134>
    6044:	48 89 df             	mov    %rbx,%rdi
    6047:	e8 a4 cf ff ff       	call   2ff0 <buf_put>
    604c:	eb af                	jmp    5ffd <fwp_write+0x14d>
    604e:	66 90                	xchg   %ax,%ax
    6050:	ba 06 00 00 00       	mov    $0x6,%edx
    6055:	48 8d 35 b1 30 00 00 	lea    0x30b1(%rip),%rsi        # 910d <_IO_stdin_used+0x10d>
    605c:	48 83 c5 10          	add    $0x10,%rbp
    6060:	e8 8b cf ff ff       	call   2ff0 <buf_put>
    6065:	48 89 ef             	mov    %rbp,%rdi
    6068:	e8 c3 c3 ff ff       	call   2430 <strlen@plt>
    606d:	48 89 ee             	mov    %rbp,%rsi
    6070:	48 89 df             	mov    %rbx,%rdi
    6073:	48 89 c2             	mov    %rax,%rdx
    6076:	e8 75 cf ff ff       	call   2ff0 <buf_put>
    607b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6080:	ba 01 00 00 00       	mov    $0x1,%edx
    6085:	48 89 df             	mov    %rbx,%rdi
    6088:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    608d:	e8 5e cf ff ff       	call   2ff0 <buf_put>
    6092:	e9 af fe ff ff       	jmp    5f46 <fwp_write+0x96>
    6097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    609e:	00 00 
    60a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    60a7:	00 
    60a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60af:	00 00 
    60b1:	0f 85 ce 02 00 00    	jne    6385 <fwp_write+0x4d5>
    60b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    60bc:	48 8d 35 36 30 00 00 	lea    0x3036(%rip),%rsi        # 90f9 <_IO_stdin_used+0xf9>
    60c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    60ca:	48 89 df             	mov    %rbx,%rdi
    60cd:	5b                   	pop    %rbx
    60ce:	5d                   	pop    %rbp
    60cf:	41 5c                	pop    %r12
    60d1:	41 5d                	pop    %r13
    60d3:	41 5e                	pop    %r14
    60d5:	41 5f                	pop    %r15
    60d7:	e9 14 cf ff ff       	jmp    2ff0 <buf_put>
    60dc:	0f 1f 40 00          	nopl   0x0(%rax)
    60e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    60e5:	4d 85 ed             	test   %r13,%r13
    60e8:	0f 84 02 0c 00 00    	je     6cf0 <fwp_write+0xe40>
    60ee:	48 8d 35 4c 30 00 00 	lea    0x304c(%rip),%rsi        # 9141 <_IO_stdin_used+0x141>
    60f5:	4c 89 ef             	mov    %r13,%rdi
    60f8:	e8 13 c4 ff ff       	call   2510 <strcmp@plt>
    60fd:	41 89 c1             	mov    %eax,%r9d
    6100:	85 c0                	test   %eax,%eax
    6102:	0f 84 6c 0c 00 00    	je     6d74 <fwp_write+0xec4>
    6108:	4c 89 ef             	mov    %r13,%rdi
    610b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6110:	e8 1b c3 ff ff       	call   2430 <strlen@plt>
    6115:	4c 89 ee             	mov    %r13,%rsi
    6118:	48 89 df             	mov    %rbx,%rdi
    611b:	48 89 c2             	mov    %rax,%rdx
    611e:	e8 cd ce ff ff       	call   2ff0 <buf_put>
    6123:	ba 01 00 00 00       	mov    $0x1,%edx
    6128:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    612d:	48 89 df             	mov    %rbx,%rdi
    6130:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    6135:	e8 b6 ce ff ff       	call   2ff0 <buf_put>
    613a:	ba 01 00 00 00       	mov    $0x1,%edx
    613f:	4c 89 fe             	mov    %r15,%rsi
    6142:	48 89 df             	mov    %rbx,%rdi
    6145:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    614a:	e8 a1 ce ff ff       	call   2ff0 <buf_put>
    614f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    6154:	45 31 f6             	xor    %r14d,%r14d
    6157:	85 d2                	test   %edx,%edx
    6159:	0f 8e 81 0a 00 00    	jle    6be0 <fwp_write+0xd30>
    615f:	45 31 ed             	xor    %r13d,%r13d
    6162:	4d 85 ed             	test   %r13,%r13
    6165:	0f 85 75 07 00 00    	jne    68e0 <fwp_write+0xa30>
    616b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6172:	00 
    6173:	45 85 f6             	test   %r14d,%r14d
    6176:	0f 84 84 07 00 00    	je     6900 <fwp_write+0xa50>
    617c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    6181:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    6186:	48 89 df             	mov    %rbx,%rdi
    6189:	49 83 c5 01          	add    $0x1,%r13
    618d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    6191:	31 c9                	xor    %ecx,%ecx
    6193:	e8 18 fd ff ff       	call   5eb0 <fwp_write>
    6198:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    619d:	7f c3                	jg     6162 <fwp_write+0x2b2>
    619f:	45 85 f6             	test   %r14d,%r14d
    61a2:	0f 84 38 0a 00 00    	je     6be0 <fwp_write+0xd30>
    61a8:	b8 29 00 00 00       	mov    $0x29,%eax
    61ad:	ba 01 00 00 00       	mov    $0x1,%edx
    61b2:	4c 89 fe             	mov    %r15,%rsi
    61b5:	48 89 df             	mov    %rbx,%rdi
    61b8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    61bc:	e8 2f ce ff ff       	call   2ff0 <buf_put>
    61c1:	e9 80 fd ff ff       	jmp    5f46 <fwp_write+0x96>
    61c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61cd:	00 00 00 
    61d0:	ba 01 00 00 00       	mov    $0x1,%edx
    61d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    61da:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    61df:	e8 0c ce ff ff       	call   2ff0 <buf_put>
    61e4:	48 85 ed             	test   %rbp,%rbp
    61e7:	0f 84 93 06 00 00    	je     6880 <fwp_write+0x9d0>
    61ed:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    61f1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    61f6:	31 c9                	xor    %ecx,%ecx
    61f8:	48 89 df             	mov    %rbx,%rdi
    61fb:	e8 b0 fc ff ff       	call   5eb0 <fwp_write>
    6200:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6204:	48 85 ed             	test   %rbp,%rbp
    6207:	0f 84 73 06 00 00    	je     6880 <fwp_write+0x9d0>
    620d:	ba 02 00 00 00       	mov    $0x2,%edx
    6212:	48 8d 35 1b 2f 00 00 	lea    0x2f1b(%rip),%rsi        # 9134 <_IO_stdin_used+0x134>
    6219:	48 89 df             	mov    %rbx,%rdi
    621c:	e8 cf cd ff ff       	call   2ff0 <buf_put>
    6221:	eb ca                	jmp    61ed <fwp_write+0x33d>
    6223:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6228:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    622c:	85 f6                	test   %esi,%esi
    622e:	0f 84 fc 07 00 00    	je     6a30 <fwp_write+0xb80>
    6234:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    623b:	00 
    623c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6243:	00 00 
    6245:	0f 85 3a 01 00 00    	jne    6385 <fwp_write+0x4d5>
    624b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    624f:	4c 89 ea             	mov    %r13,%rdx
    6252:	e9 6c fe ff ff       	jmp    60c3 <fwp_write+0x213>
    6257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    625e:	00 00 
    6260:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    6265:	ba 01 00 00 00       	mov    $0x1,%edx
    626a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    626f:	48 89 ee             	mov    %rbp,%rsi
    6272:	e8 79 cd ff ff       	call   2ff0 <buf_put>
    6277:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    627c:	4c 89 e7             	mov    %r12,%rdi
    627f:	e8 ac c1 ff ff       	call   2430 <strlen@plt>
    6284:	4c 89 e6             	mov    %r12,%rsi
    6287:	48 89 df             	mov    %rbx,%rdi
    628a:	48 89 c2             	mov    %rax,%rdx
    628d:	e8 5e cd ff ff       	call   2ff0 <buf_put>
    6292:	ba 01 00 00 00       	mov    $0x1,%edx
    6297:	48 89 ee             	mov    %rbp,%rsi
    629a:	48 89 df             	mov    %rbx,%rdi
    629d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    62a2:	e8 49 cd ff ff       	call   2ff0 <buf_put>
    62a7:	e9 9a fc ff ff       	jmp    5f46 <fwp_write+0x96>
    62ac:	0f 1f 40 00          	nopl   0x0(%rax)
    62b0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    62b5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    62b9:	0f 8a 8e 0b 00 00    	jp     6e4d <fwp_write+0xf9d>
    62bf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    62c3:	66 0f 54 05 35 32 00 	andpd  0x3235(%rip),%xmm0        # 9500 <msg.3+0xb0>
    62ca:	00 
    62cb:	bd 01 00 00 00       	mov    $0x1,%ebp
    62d0:	66 0f 2e 05 b8 31 00 	ucomisd 0x31b8(%rip),%xmm0        # 9490 <msg.3+0x40>
    62d7:	00 
    62d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    62df:	00 
    62e0:	0f 87 b2 09 00 00    	ja     6c98 <fwp_write+0xde8>
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    62f4:	89 ee                	mov    %ebp,%esi
    62f6:	4c 89 e7             	mov    %r12,%rdi
    62f9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    62fe:	e8 fd ce ff ff       	call   3200 <fwp_format_g.constprop.0>
    6303:	31 f6                	xor    %esi,%esi
    6305:	4c 89 e7             	mov    %r12,%rdi
    6308:	e8 e3 c0 ff ff       	call   23f0 <strtod@plt>
    630d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6312:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    6316:	7a 06                	jp     631e <fwp_write+0x46e>
    6318:	0f 84 e9 01 00 00    	je     6507 <fwp_write+0x657>
    631e:	83 c5 01             	add    $0x1,%ebp
    6321:	83 fd 12             	cmp    $0x12,%ebp
    6324:	75 ca                	jne    62f0 <fwp_write+0x440>
    6326:	be 11 00 00 00       	mov    $0x11,%esi
    632b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    632f:	4c 89 e7             	mov    %r12,%rdi
    6332:	e8 c9 ce ff ff       	call   3200 <fwp_format_g.constprop.0>
    6337:	e9 cb 01 00 00       	jmp    6507 <fwp_write+0x657>
    633c:	0f 1f 40 00          	nopl   0x0(%rax)
    6340:	48 83 fd 01          	cmp    $0x1,%rbp
    6344:	0f 84 e6 08 00 00    	je     6c30 <fwp_write+0xd80>
    634a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    634e:	b8 02 00 00 00       	mov    $0x2,%eax
    6353:	ba 01 00 00 00       	mov    $0x1,%edx
    6358:	48 0f 44 d0          	cmove  %rax,%rdx
    635c:	48 8d 35 7a 2d 00 00 	lea    0x2d7a(%rip),%rsi        # 90dd <_IO_stdin_used+0xdd>
    6363:	48 8d 05 78 2d 00 00 	lea    0x2d78(%rip),%rax        # 90e2 <_IO_stdin_used+0xe2>
    636a:	48 0f 44 f0          	cmove  %rax,%rsi
    636e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6375:	00 
    6376:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    637d:	00 00 
    637f:	0f 84 3e fd ff ff    	je     60c3 <fwp_write+0x213>
    6385:	e8 b6 c0 ff ff       	call   2440 <__stack_chk_fail@plt>
    638a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6390:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    6395:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    639a:	e8 91 cb ff ff       	call   2f30 <buf_grow>
    639f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    63a3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    63a9:	4c 03 0b             	add    (%rbx),%r9
    63ac:	66 45 89 11          	mov    %r10w,(%r9)
    63b0:	45 85 e4             	test   %r12d,%r12d
    63b3:	0f 8e 07 05 00 00    	jle    68c0 <fwp_write+0xa10>
    63b9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    63c0:	55 55 55 
    63c3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    63c8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    63cf:	aa aa aa 
    63d2:	49 83 c1 01          	add    $0x1,%r9
    63d6:	eb 45                	jmp    641d <fwp_write+0x56d>
    63d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63df:	00 
    63e0:	be 01 00 00 00       	mov    $0x1,%esi
    63e5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    63ea:	88 07                	mov    %al,(%rdi)
    63ec:	48 89 e8             	mov    %rbp,%rax
    63ef:	49 f7 e8             	imul   %r8
    63f2:	48 89 e8             	mov    %rbp,%rax
    63f5:	48 c1 f8 3f          	sar    $0x3f,%rax
    63f9:	48 29 c2             	sub    %rax,%rdx
    63fc:	48 85 c9             	test   %rcx,%rcx
    63ff:	0f 95 c0             	setne  %al
    6402:	48 c1 ed 3f          	shr    $0x3f,%rbp
    6406:	48 83 ef 01          	sub    $0x1,%rdi
    640a:	48 21 c5             	and    %rax,%rbp
    640d:	48 29 ea             	sub    %rbp,%rdx
    6410:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    6414:	49 39 f9             	cmp    %rdi,%r9
    6417:	0f 84 a3 04 00 00    	je     68c0 <fwp_write+0xa10>
    641d:	48 89 e8             	mov    %rbp,%rax
    6420:	49 f7 e8             	imul   %r8
    6423:	48 89 e8             	mov    %rbp,%rax
    6426:	48 c1 f8 3f          	sar    $0x3f,%rax
    642a:	48 89 d1             	mov    %rdx,%rcx
    642d:	48 29 c1             	sub    %rax,%rcx
    6430:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    6434:	48 89 e9             	mov    %rbp,%rcx
    6437:	48 29 c1             	sub    %rax,%rcx
    643a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    643e:	49 f7 e2             	mul    %r10
    6441:	b8 30 00 00 00       	mov    $0x30,%eax
    6446:	48 89 d6             	mov    %rdx,%rsi
    6449:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    644d:	48 d1 ee             	shr    $1,%rsi
    6450:	48 01 f2             	add    %rsi,%rdx
    6453:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    6457:	48 29 d6             	sub    %rdx,%rsi
    645a:	74 8e                	je     63ea <fwp_write+0x53a>
    645c:	48 83 fe 01          	cmp    $0x1,%rsi
    6460:	0f 85 7a ff ff ff    	jne    63e0 <fwp_write+0x530>
    6466:	31 f6                	xor    %esi,%esi
    6468:	b8 2b 00 00 00       	mov    $0x2b,%eax
    646d:	e9 78 ff ff ff       	jmp    63ea <fwp_write+0x53a>
    6472:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6478:	66 0f 6e cd          	movd   %ebp,%xmm1
    647c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    647f:	0f 8a c8 09 00 00    	jp     6e4d <fwp_write+0xf9d>
    6485:	0f 28 c1             	movaps %xmm1,%xmm0
    6488:	0f 54 05 61 30 00 00 	andps  0x3061(%rip),%xmm0        # 94f0 <msg.3+0xa0>
    648f:	0f 2e 05 6e 2b 00 00 	ucomiss 0x2b6e(%rip),%xmm0        # 9004 <_IO_stdin_used+0x4>
    6496:	0f 87 24 08 00 00    	ja     6cc0 <fwp_write+0xe10>
    649c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    64a0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    64a6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    64ad:	00 
    64ae:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    64b2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    64b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    64be:	00 00 
    64c0:	44 89 ee             	mov    %r13d,%esi
    64c3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    64c8:	4c 89 e7             	mov    %r12,%rdi
    64cb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    64d0:	e8 2b cd ff ff       	call   3200 <fwp_format_g.constprop.0>
    64d5:	31 f6                	xor    %esi,%esi
    64d7:	4c 89 e7             	mov    %r12,%rdi
    64da:	e8 b1 bf ff ff       	call   2490 <strtof@plt>
    64df:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    64e4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    64e7:	7a 02                	jp     64eb <fwp_write+0x63b>
    64e9:	74 1c                	je     6507 <fwp_write+0x657>
    64eb:	41 83 c5 01          	add    $0x1,%r13d
    64ef:	41 83 fd 0a          	cmp    $0xa,%r13d
    64f3:	75 cb                	jne    64c0 <fwp_write+0x610>
    64f5:	be 09 00 00 00       	mov    $0x9,%esi
    64fa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    64ff:	4c 89 e7             	mov    %r12,%rdi
    6502:	e8 f9 cc ff ff       	call   3200 <fwp_format_g.constprop.0>
    6507:	4c 89 e7             	mov    %r12,%rdi
    650a:	e8 a1 cb ff ff       	call   30b0 <fwp_finish_float>
    650f:	e9 1c fa ff ff       	jmp    5f30 <fwp_write+0x80>
    6514:	0f 1f 40 00          	nopl   0x0(%rax)
    6518:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    651c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    6520:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    6527:	00 
    6528:	48 89 ef             	mov    %rbp,%rdi
    652b:	e8 d0 c4 ff ff       	call   2a00 <fwp_fmt_u128>
    6530:	48 89 ef             	mov    %rbp,%rdi
    6533:	e8 f8 be ff ff       	call   2430 <strlen@plt>
    6538:	48 89 ee             	mov    %rbp,%rsi
    653b:	48 89 df             	mov    %rbx,%rdi
    653e:	48 89 c2             	mov    %rax,%rdx
    6541:	e8 aa ca ff ff       	call   2ff0 <buf_put>
    6546:	e9 fb f9 ff ff       	jmp    5f46 <fwp_write+0x96>
    654b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6550:	ba 06 00 00 00       	mov    $0x6,%edx
    6555:	48 8d 35 db 2b 00 00 	lea    0x2bdb(%rip),%rsi        # 9137 <_IO_stdin_used+0x137>
    655c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    6562:	e8 89 ca ff ff       	call   2ff0 <buf_put>
    6567:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    656e:	ff ff 7f 
    6571:	48 23 55 00          	and    0x0(%rbp),%rdx
    6575:	0f 84 86 02 00 00    	je     6801 <fwp_write+0x951>
    657b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6580:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    6584:	48 85 d2             	test   %rdx,%rdx
    6587:	0f 84 ae 00 00 00    	je     663b <fwp_write+0x78b>
    658d:	8b 0a                	mov    (%rdx),%ecx
    658f:	83 f9 1c             	cmp    $0x1c,%ecx
    6592:	0f 84 58 06 00 00    	je     6bf0 <fwp_write+0xd40>
    6598:	83 f9 1b             	cmp    $0x1b,%ecx
    659b:	0f 87 9a 00 00 00    	ja     663b <fwp_write+0x78b>
    65a1:	be 01 00 00 00       	mov    $0x1,%esi
    65a6:	48 d3 e6             	shl    %cl,%rsi
    65a9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    65af:	0f 85 4b 04 00 00    	jne    6a00 <fwp_write+0xb50>
    65b5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    65bb:	0f 85 0f 04 00 00    	jne    69d0 <fwp_write+0xb20>
    65c1:	83 e6 21             	and    $0x21,%esi
    65c4:	74 75                	je     663b <fwp_write+0x78b>
    65c6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    65cb:	48 85 ff             	test   %rdi,%rdi
    65ce:	79 07                	jns    65d7 <fwp_write+0x727>
    65d0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    65d4:	4c 01 ee             	add    %r13,%rsi
    65d7:	48 0f be 3e          	movsbq (%rsi),%rdi
    65db:	85 c9                	test   %ecx,%ecx
    65dd:	40 0f b6 f7          	movzbl %dil,%esi
    65e1:	48 0f 44 f7          	cmove  %rdi,%rsi
    65e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    65ec:	00 00 00 00 
    65f0:	31 c9                	xor    %ecx,%ecx
    65f2:	48 89 df             	mov    %rbx,%rdi
    65f5:	49 83 c5 01          	add    $0x1,%r13
    65f9:	e8 b2 f8 ff ff       	call   5eb0 <fwp_write>
    65fe:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    6605:	ff ff 7f 
    6608:	48 23 55 00          	and    0x0(%rbp),%rdx
    660c:	49 39 d5             	cmp    %rdx,%r13
    660f:	0f 83 ec 01 00 00    	jae    6801 <fwp_write+0x951>
    6615:	ba 02 00 00 00       	mov    $0x2,%edx
    661a:	48 89 df             	mov    %rbx,%rdi
    661d:	48 8d 35 10 2b 00 00 	lea    0x2b10(%rip),%rsi        # 9134 <_IO_stdin_used+0x134>
    6624:	e8 c7 c9 ff ff       	call   2ff0 <buf_put>
    6629:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    662e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    6632:	48 85 d2             	test   %rdx,%rdx
    6635:	0f 85 52 ff ff ff    	jne    658d <fwp_write+0x6dd>
    663b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    6640:	48 85 ff             	test   %rdi,%rdi
    6643:	0f 88 cf 05 00 00    	js     6c18 <fwp_write+0xd68>
    6649:	48 8b 31             	mov    (%rcx),%rsi
    664c:	eb a2                	jmp    65f0 <fwp_write+0x740>
    664e:	66 90                	xchg   %ax,%ax
    6650:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6657:	00 
    6658:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    665f:	00 00 
    6661:	0f 85 1e fd ff ff    	jne    6385 <fwp_write+0x4d5>
    6667:	ba 08 00 00 00       	mov    $0x8,%edx
    666c:	48 8d 35 91 2a 00 00 	lea    0x2a91(%rip),%rsi        # 9104 <_IO_stdin_used+0x104>
    6673:	e9 4b fa ff ff       	jmp    60c3 <fwp_write+0x213>
    6678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    667f:	00 
    6680:	89 e8                	mov    %ebp,%eax
    6682:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    6689:	76 03                	jbe    668e <fwp_write+0x7de>
    668b:	8b 45 00             	mov    0x0(%rbp),%eax
    668e:	41 89 c6             	mov    %eax,%r14d
    6691:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6696:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    669b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    669f:	4c 89 ef             	mov    %r13,%rdi
    66a2:	e8 89 bd ff ff       	call   2430 <strlen@plt>
    66a7:	4c 89 ee             	mov    %r13,%rsi
    66aa:	48 89 df             	mov    %rbx,%rdi
    66ad:	48 89 c2             	mov    %rax,%rdx
    66b0:	e8 3b c9 ff ff       	call   2ff0 <buf_put>
    66b5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    66ba:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    66be:	85 f6                	test   %esi,%esi
    66c0:	0f 8e 80 f8 ff ff    	jle    5f46 <fwp_write+0x96>
    66c6:	45 31 ed             	xor    %r13d,%r13d
    66c9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    66ce:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    66d3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    66d8:	ba 01 00 00 00       	mov    $0x1,%edx
    66dd:	4c 89 fe             	mov    %r15,%rsi
    66e0:	48 89 04 24          	mov    %rax,(%rsp)
    66e4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    66e9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    66ed:	48 89 df             	mov    %rbx,%rdi
    66f0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    66f4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    66f9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    66fe:	e8 ed c8 ff ff       	call   2ff0 <buf_put>
    6703:	41 8b 06             	mov    (%r14),%eax
    6706:	83 f8 0e             	cmp    $0xe,%eax
    6709:	0f 84 71 02 00 00    	je     6980 <fwp_write+0xad0>
    670f:	83 f8 10             	cmp    $0x10,%eax
    6712:	0f 84 38 02 00 00    	je     6950 <fwp_write+0xaa0>
    6718:	83 f8 0a             	cmp    $0xa,%eax
    671b:	0f 84 7f 04 00 00    	je     6ba0 <fwp_write+0xcf0>
    6721:	0f 8f f9 00 00 00    	jg     6820 <fwp_write+0x970>
    6727:	83 f8 03             	cmp    $0x3,%eax
    672a:	0f 8f 50 04 00 00    	jg     6b80 <fwp_write+0xcd0>
    6730:	85 c0                	test   %eax,%eax
    6732:	78 10                	js     6744 <fwp_write+0x894>
    6734:	48 8b 04 24          	mov    (%rsp),%rax
    6738:	48 c1 e8 3f          	shr    $0x3f,%rax
    673c:	85 c0                	test   %eax,%eax
    673e:	0f 85 f9 00 00 00    	jne    683d <fwp_write+0x98d>
    6744:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6749:	48 8b 34 24          	mov    (%rsp),%rsi
    674d:	31 c9                	xor    %ecx,%ecx
    674f:	48 89 df             	mov    %rbx,%rdi
    6752:	e8 59 f7 ff ff       	call   5eb0 <fwp_write>
    6757:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    675c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6761:	49 83 c5 01          	add    $0x1,%r13
    6765:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    6769:	0f 8f 5f ff ff ff    	jg     66ce <fwp_write+0x81e>
    676f:	e9 d2 f7 ff ff       	jmp    5f46 <fwp_write+0x96>
    6774:	0f 1f 40 00          	nopl   0x0(%rax)
    6778:	ba 06 00 00 00       	mov    $0x6,%edx
    677d:	48 8d 35 a6 29 00 00 	lea    0x29a6(%rip),%rsi        # 912a <_IO_stdin_used+0x12a>
    6784:	45 31 ed             	xor    %r13d,%r13d
    6787:	e8 64 c8 ff ff       	call   2ff0 <buf_put>
    678c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6791:	75 19                	jne    67ac <fwp_write+0x8fc>
    6793:	eb 6c                	jmp    6801 <fwp_write+0x951>
    6795:	0f 1f 00             	nopl   (%rax)
    6798:	ba 02 00 00 00       	mov    $0x2,%edx
    679d:	48 8d 35 90 29 00 00 	lea    0x2990(%rip),%rsi        # 9134 <_IO_stdin_used+0x134>
    67a4:	48 89 df             	mov    %rbx,%rdi
    67a7:	e8 44 c8 ff ff       	call   2ff0 <buf_put>
    67ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    67b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    67b7:	31 c0                	xor    %eax,%eax
    67b9:	49 83 c5 01          	add    $0x1,%r13
    67bd:	4c 8d 05 6d 29 00 00 	lea    0x296d(%rip),%r8        # 9131 <_IO_stdin_used+0x131>
    67c4:	ba 02 00 00 00       	mov    $0x2,%edx
    67c9:	be 00 02 00 00       	mov    $0x200,%esi
    67ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    67d5:	00 
    67d6:	e8 b5 bb ff ff       	call   2390 <__snprintf_chk@plt>
    67db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    67e2:	00 
    67e3:	e8 48 bc ff ff       	call   2430 <strlen@plt>
    67e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    67ef:	00 
    67f0:	48 89 df             	mov    %rbx,%rdi
    67f3:	48 89 c2             	mov    %rax,%rdx
    67f6:	e8 f5 c7 ff ff       	call   2ff0 <buf_put>
    67fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    67ff:	72 97                	jb     6798 <fwp_write+0x8e8>
    6801:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6806:	ba 01 00 00 00       	mov    $0x1,%edx
    680b:	48 89 df             	mov    %rbx,%rdi
    680e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6813:	e8 d8 c7 ff ff       	call   2ff0 <buf_put>
    6818:	e9 29 f7 ff ff       	jmp    5f46 <fwp_write+0x96>
    681d:	0f 1f 00             	nopl   (%rax)
    6820:	83 f8 0b             	cmp    $0xb,%eax
    6823:	0f 85 1b ff ff ff    	jne    6744 <fwp_write+0x894>
    6829:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    682e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    6832:	83 e0 01             	and    $0x1,%eax
    6835:	85 c0                	test   %eax,%eax
    6837:	0f 84 07 ff ff ff    	je     6744 <fwp_write+0x894>
    683d:	4c 89 fe             	mov    %r15,%rsi
    6840:	48 89 df             	mov    %rbx,%rdi
    6843:	ba 01 00 00 00       	mov    $0x1,%edx
    6848:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    684d:	e8 9e c7 ff ff       	call   2ff0 <buf_put>
    6852:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6857:	48 8b 34 24          	mov    (%rsp),%rsi
    685b:	31 c9                	xor    %ecx,%ecx
    685d:	48 89 df             	mov    %rbx,%rdi
    6860:	e8 4b f6 ff ff       	call   5eb0 <fwp_write>
    6865:	ba 01 00 00 00       	mov    $0x1,%edx
    686a:	4c 89 fe             	mov    %r15,%rsi
    686d:	48 89 df             	mov    %rbx,%rdi
    6870:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    6875:	e8 76 c7 ff ff       	call   2ff0 <buf_put>
    687a:	e9 d8 fe ff ff       	jmp    6757 <fwp_write+0x8a7>
    687f:	90                   	nop
    6880:	ba 01 00 00 00       	mov    $0x1,%edx
    6885:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    688a:	48 89 df             	mov    %rbx,%rdi
    688d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6892:	e8 59 c7 ff ff       	call   2ff0 <buf_put>
    6897:	e9 aa f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    689c:	0f 1f 40 00          	nopl   0x0(%rax)
    68a0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    68a5:	ba 01 00 00 00       	mov    $0x1,%edx
    68aa:	48 89 df             	mov    %rbx,%rdi
    68ad:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    68b2:	e8 39 c7 ff ff       	call   2ff0 <buf_put>
    68b7:	e9 8a f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    68bc:	0f 1f 40 00          	nopl   0x0(%rax)
    68c0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    68c4:	48 8b 13             	mov    (%rbx),%rdx
    68c7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    68cc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    68d0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    68d4:	e9 6d f6 ff ff       	jmp    5f46 <fwp_write+0x96>
    68d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68e0:	ba 02 00 00 00       	mov    $0x2,%edx
    68e5:	48 8d 35 48 28 00 00 	lea    0x2848(%rip),%rsi        # 9134 <_IO_stdin_used+0x134>
    68ec:	48 89 df             	mov    %rbx,%rdi
    68ef:	e8 fc c6 ff ff       	call   2ff0 <buf_put>
    68f4:	e9 72 f8 ff ff       	jmp    616b <fwp_write+0x2bb>
    68f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6900:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6905:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    690a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    690e:	48 89 f7             	mov    %rsi,%rdi
    6911:	48 89 34 24          	mov    %rsi,(%rsp)
    6915:	e8 16 bb ff ff       	call   2430 <strlen@plt>
    691a:	48 8b 34 24          	mov    (%rsp),%rsi
    691e:	48 89 df             	mov    %rbx,%rdi
    6921:	48 89 c2             	mov    %rax,%rdx
    6924:	e8 c7 c6 ff ff       	call   2ff0 <buf_put>
    6929:	ba 03 00 00 00       	mov    $0x3,%edx
    692e:	48 8d 35 22 28 00 00 	lea    0x2822(%rip),%rsi        # 9157 <_IO_stdin_used+0x157>
    6935:	48 89 df             	mov    %rbx,%rdi
    6938:	e8 b3 c6 ff ff       	call   2ff0 <buf_put>
    693d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6942:	e9 35 f8 ff ff       	jmp    617c <fwp_write+0x2cc>
    6947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    694e:	00 00 
    6950:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6955:	48 8b 78 08          	mov    0x8(%rax),%rdi
    6959:	48 85 ff             	test   %rdi,%rdi
    695c:	0f 84 e2 fd ff ff    	je     6744 <fwp_write+0x894>
    6962:	48 8d 35 d8 27 00 00 	lea    0x27d8(%rip),%rsi        # 9141 <_IO_stdin_used+0x141>
    6969:	e8 a2 bb ff ff       	call   2510 <strcmp@plt>
    696e:	85 c0                	test   %eax,%eax
    6970:	0f 95 c0             	setne  %al
    6973:	0f b6 c0             	movzbl %al,%eax
    6976:	e9 c1 fd ff ff       	jmp    673c <fwp_write+0x88c>
    697b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6980:	31 c0                	xor    %eax,%eax
    6982:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    6989:	00 
    698a:	0f 97 c0             	seta   %al
    698d:	e9 aa fd ff ff       	jmp    673c <fwp_write+0x88c>
    6992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6998:	48 89 df             	mov    %rbx,%rdi
    699b:	ba 02 00 00 00       	mov    $0x2,%edx
    69a0:	48 8d 35 97 27 00 00 	lea    0x2797(%rip),%rsi        # 913e <_IO_stdin_used+0x13e>
    69a7:	e8 44 c6 ff ff       	call   2ff0 <buf_put>
    69ac:	4c 89 e8             	mov    %r13,%rax
    69af:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    69b4:	31 c9                	xor    %ecx,%ecx
    69b6:	48 c1 e0 04          	shl    $0x4,%rax
    69ba:	48 89 df             	mov    %rbx,%rdi
    69bd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    69c2:	e8 e9 f4 ff ff       	call   5eb0 <fwp_write>
    69c7:	e9 5e f6 ff ff       	jmp    602a <fwp_write+0x17a>
    69cc:	0f 1f 40 00          	nopl   0x0(%rax)
    69d0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    69d5:	48 85 ff             	test   %rdi,%rdi
    69d8:	79 0c                	jns    69e6 <fwp_write+0xb36>
    69da:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    69e1:	00 
    69e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    69e6:	48 63 3e             	movslq (%rsi),%rdi
    69e9:	83 f9 02             	cmp    $0x2,%ecx
    69ec:	89 fe                	mov    %edi,%esi
    69ee:	48 0f 44 f7          	cmove  %rdi,%rsi
    69f2:	e9 f9 fb ff ff       	jmp    65f0 <fwp_write+0x740>
    69f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69fe:	00 00 
    6a00:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    6a05:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    6a0a:	48 85 ff             	test   %rdi,%rdi
    6a0d:	0f 88 0f 03 00 00    	js     6d22 <fwp_write+0xe72>
    6a13:	49 0f bf 38          	movswq (%r8),%rdi
    6a17:	83 f9 01             	cmp    $0x1,%ecx
    6a1a:	0f b7 f7             	movzwl %di,%esi
    6a1d:	48 0f 44 f7          	cmove  %rdi,%rsi
    6a21:	e9 ca fb ff ff       	jmp    65f0 <fwp_write+0x740>
    6a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a2d:	00 00 00 
    6a30:	ba 01 00 00 00       	mov    $0x1,%edx
    6a35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6a3a:	48 83 c5 08          	add    $0x8,%rbp
    6a3e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6a43:	e8 a8 c5 ff ff       	call   2ff0 <buf_put>
    6a48:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6a4d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    6a52:	4d 85 ed             	test   %r13,%r13
    6a55:	75 46                	jne    6a9d <fwp_write+0xbed>
    6a57:	e9 04 01 00 00       	jmp    6b60 <fwp_write+0xcb0>
    6a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a60:	41 80 f9 09          	cmp    $0x9,%r9b
    6a64:	0f 84 d6 00 00 00    	je     6b40 <fwp_write+0xc90>
    6a6a:	41 80 f9 0a          	cmp    $0xa,%r9b
    6a6e:	0f 85 9c 00 00 00    	jne    6b10 <fwp_write+0xc60>
    6a74:	ba 02 00 00 00       	mov    $0x2,%edx
    6a79:	48 8d 35 9a 26 00 00 	lea    0x269a(%rip),%rsi        # 911a <_IO_stdin_used+0x11a>
    6a80:	48 89 df             	mov    %rbx,%rdi
    6a83:	e8 68 c5 ff ff       	call   2ff0 <buf_put>
    6a88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a8f:	00 
    6a90:	48 83 c5 01          	add    $0x1,%rbp
    6a94:	49 39 ec             	cmp    %rbp,%r12
    6a97:	0f 84 c3 00 00 00    	je     6b60 <fwp_write+0xcb0>
    6a9d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    6aa2:	41 80 f9 0d          	cmp    $0xd,%r9b
    6aa6:	74 28                	je     6ad0 <fwp_write+0xc20>
    6aa8:	7e b6                	jle    6a60 <fwp_write+0xbb0>
    6aaa:	41 80 f9 22          	cmp    $0x22,%r9b
    6aae:	74 40                	je     6af0 <fwp_write+0xc40>
    6ab0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    6ab4:	75 5a                	jne    6b10 <fwp_write+0xc60>
    6ab6:	ba 02 00 00 00       	mov    $0x2,%edx
    6abb:	48 8d 35 55 26 00 00 	lea    0x2655(%rip),%rsi        # 9117 <_IO_stdin_used+0x117>
    6ac2:	48 89 df             	mov    %rbx,%rdi
    6ac5:	e8 26 c5 ff ff       	call   2ff0 <buf_put>
    6aca:	eb c4                	jmp    6a90 <fwp_write+0xbe0>
    6acc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ad0:	ba 02 00 00 00       	mov    $0x2,%edx
    6ad5:	48 8d 35 44 26 00 00 	lea    0x2644(%rip),%rsi        # 9120 <_IO_stdin_used+0x120>
    6adc:	48 89 df             	mov    %rbx,%rdi
    6adf:	e8 0c c5 ff ff       	call   2ff0 <buf_put>
    6ae4:	eb aa                	jmp    6a90 <fwp_write+0xbe0>
    6ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6aed:	00 00 00 
    6af0:	ba 02 00 00 00       	mov    $0x2,%edx
    6af5:	48 8d 35 18 26 00 00 	lea    0x2618(%rip),%rsi        # 9114 <_IO_stdin_used+0x114>
    6afc:	48 89 df             	mov    %rbx,%rdi
    6aff:	e8 ec c4 ff ff       	call   2ff0 <buf_put>
    6b04:	eb 8a                	jmp    6a90 <fwp_write+0xbe0>
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 
    6b10:	41 80 f9 1f          	cmp    $0x1f,%r9b
    6b14:	0f 86 2e 01 00 00    	jbe    6c48 <fwp_write+0xd98>
    6b1a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    6b1e:	0f 84 24 01 00 00    	je     6c48 <fwp_write+0xd98>
    6b24:	ba 01 00 00 00       	mov    $0x1,%edx
    6b29:	4c 89 fe             	mov    %r15,%rsi
    6b2c:	48 89 df             	mov    %rbx,%rdi
    6b2f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    6b34:	e8 b7 c4 ff ff       	call   2ff0 <buf_put>
    6b39:	e9 52 ff ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6b3e:	66 90                	xchg   %ax,%ax
    6b40:	ba 02 00 00 00       	mov    $0x2,%edx
    6b45:	48 8d 35 d1 25 00 00 	lea    0x25d1(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    6b4c:	48 89 df             	mov    %rbx,%rdi
    6b4f:	e8 9c c4 ff ff       	call   2ff0 <buf_put>
    6b54:	e9 37 ff ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6b59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b60:	ba 01 00 00 00       	mov    $0x1,%edx
    6b65:	4c 89 fe             	mov    %r15,%rsi
    6b68:	48 89 df             	mov    %rbx,%rdi
    6b6b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6b70:	e8 7b c4 ff ff       	call   2ff0 <buf_put>
    6b75:	e9 cc f3 ff ff       	jmp    5f46 <fwp_write+0x96>
    6b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b80:	83 f8 04             	cmp    $0x4,%eax
    6b83:	0f 85 bb fb ff ff    	jne    6744 <fwp_write+0x894>
    6b89:	48 8b 04 24          	mov    (%rsp),%rax
    6b8d:	48 8b 40 08          	mov    0x8(%rax),%rax
    6b91:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6b96:	48 c1 e8 3f          	shr    $0x3f,%rax
    6b9a:	e9 96 fc ff ff       	jmp    6835 <fwp_write+0x985>
    6b9f:	90                   	nop
    6ba0:	8b 0c 24             	mov    (%rsp),%ecx
    6ba3:	31 c0                	xor    %eax,%eax
    6ba5:	85 c9                	test   %ecx,%ecx
    6ba7:	0f 98 c0             	sets   %al
    6baa:	e9 86 fc ff ff       	jmp    6835 <fwp_write+0x985>
    6baf:	90                   	nop
    6bb0:	48 f7 d8             	neg    %rax
    6bb3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    6bba:	00 
    6bbb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    6bc2:	2d 
    6bc3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6bca:	00 
    6bcb:	48 83 d2 00          	adc    $0x0,%rdx
    6bcf:	48 89 c6             	mov    %rax,%rsi
    6bd2:	48 f7 da             	neg    %rdx
    6bd5:	e8 26 be ff ff       	call   2a00 <fwp_fmt_u128>
    6bda:	e9 51 f3 ff ff       	jmp    5f30 <fwp_write+0x80>
    6bdf:	90                   	nop
    6be0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    6be5:	e9 c3 f5 ff ff       	jmp    61ad <fwp_write+0x2fd>
    6bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bf0:	4c 89 e9             	mov    %r13,%rcx
    6bf3:	48 c1 e1 04          	shl    $0x4,%rcx
    6bf7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    6bfc:	48 85 ff             	test   %rdi,%rdi
    6bff:	0f 89 eb f9 ff ff    	jns    65f0 <fwp_write+0x740>
    6c05:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6c09:	48 89 ce             	mov    %rcx,%rsi
    6c0c:	e9 df f9 ff ff       	jmp    65f0 <fwp_write+0x740>
    6c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c18:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6c1f:	00 
    6c20:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6c24:	e9 20 fa ff ff       	jmp    6649 <fwp_write+0x799>
    6c29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c30:	ba 02 00 00 00       	mov    $0x2,%edx
    6c35:	48 8d 35 a3 24 00 00 	lea    0x24a3(%rip),%rsi        # 90df <_IO_stdin_used+0xdf>
    6c3c:	e9 2d f7 ff ff       	jmp    636e <fwp_write+0x4be>
    6c41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c48:	4c 8d 05 d4 24 00 00 	lea    0x24d4(%rip),%r8        # 9123 <_IO_stdin_used+0x123>
    6c4f:	b9 10 00 00 00       	mov    $0x10,%ecx
    6c54:	31 c0                	xor    %eax,%eax
    6c56:	ba 02 00 00 00       	mov    $0x2,%edx
    6c5b:	be 10 00 00 00       	mov    $0x10,%esi
    6c60:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6c67:	00 
    6c68:	e8 23 b7 ff ff       	call   2390 <__snprintf_chk@plt>
    6c6d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6c74:	00 
    6c75:	e8 b6 b7 ff ff       	call   2430 <strlen@plt>
    6c7a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    6c81:	00 
    6c82:	48 89 df             	mov    %rbx,%rdi
    6c85:	48 89 c2             	mov    %rax,%rdx
    6c88:	e8 63 c3 ff ff       	call   2ff0 <buf_put>
    6c8d:	e9 fe fd ff ff       	jmp    6a90 <fwp_write+0xbe0>
    6c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c98:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6c9c:	48 8d 35 36 24 00 00 	lea    0x2436(%rip),%rsi        # 90d9 <_IO_stdin_used+0xd9>
    6ca3:	48 8d 05 2e 24 00 00 	lea    0x242e(%rip),%rax        # 90d8 <_IO_stdin_used+0xd8>
    6caa:	4c 89 e7             	mov    %r12,%rdi
    6cad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    6cb1:	48 0f 46 f0          	cmovbe %rax,%rsi
    6cb5:	e8 16 b7 ff ff       	call   23d0 <strcpy@plt>
    6cba:	e9 71 f2 ff ff       	jmp    5f30 <fwp_write+0x80>
    6cbf:	90                   	nop
    6cc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6cc4:	48 8d 35 0e 24 00 00 	lea    0x240e(%rip),%rsi        # 90d9 <_IO_stdin_used+0xd9>
    6ccb:	48 8d 05 06 24 00 00 	lea    0x2406(%rip),%rax        # 90d8 <_IO_stdin_used+0xd8>
    6cd2:	0f 2f c8             	comiss %xmm0,%xmm1
    6cd5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6cdc:	00 
    6cdd:	4c 89 e7             	mov    %r12,%rdi
    6ce0:	48 0f 46 f0          	cmovbe %rax,%rsi
    6ce4:	e8 e7 b6 ff ff       	call   23d0 <strcpy@plt>
    6ce9:	e9 42 f2 ff ff       	jmp    5f30 <fwp_write+0x80>
    6cee:	66 90                	xchg   %ax,%ax
    6cf0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    6cf5:	45 85 c0             	test   %r8d,%r8d
    6cf8:	75 34                	jne    6d2e <fwp_write+0xe7e>
    6cfa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6d01:	00 
    6d02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d09:	00 00 
    6d0b:	0f 85 74 f6 ff ff    	jne    6385 <fwp_write+0x4d5>
    6d11:	ba 02 00 00 00       	mov    $0x2,%edx
    6d16:	48 8d 35 37 24 00 00 	lea    0x2437(%rip),%rsi        # 9154 <_IO_stdin_used+0x154>
    6d1d:	e9 a1 f3 ff ff       	jmp    60c3 <fwp_write+0x213>
    6d22:	48 03 75 10          	add    0x10(%rbp),%rsi
    6d26:	49 89 f0             	mov    %rsi,%r8
    6d29:	e9 e5 fc ff ff       	jmp    6a13 <fwp_write+0xb63>
    6d2e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    6d33:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6d38:	85 ff                	test   %edi,%edi
    6d3a:	0f 84 fa f3 ff ff    	je     613a <fwp_write+0x28a>
    6d40:	ba 01 00 00 00       	mov    $0x1,%edx
    6d45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6d4a:	48 89 df             	mov    %rbx,%rdi
    6d4d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6d52:	e8 99 c2 ff ff       	call   2ff0 <buf_put>
    6d57:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    6d5c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6d61:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6d67:	85 c0                	test   %eax,%eax
    6d69:	0f 8f f0 f3 ff ff    	jg     615f <fwp_write+0x2af>
    6d6f:	e9 34 f4 ff ff       	jmp    61a8 <fwp_write+0x2f8>
    6d74:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6d78:	49 89 c5             	mov    %rax,%r13
    6d7b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6d80:	49 89 c4             	mov    %rax,%r12
    6d83:	49 c1 fd 3f          	sar    $0x3f,%r13
    6d87:	4c 09 e8             	or     %r13,%rax
    6d8a:	0f 84 a7 00 00 00    	je     6e37 <fwp_write+0xf87>
    6d90:	48 8d 2d 29 4d 00 00 	lea    0x4d29(%rip),%rbp        # bac0 <units.0>
    6d97:	4d 89 e7             	mov    %r12,%r15
    6d9a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6d9e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6da3:	4c 89 ff             	mov    %r15,%rdi
    6da6:	4c 89 ee             	mov    %r13,%rsi
    6da9:	44 89 0c 24          	mov    %r9d,(%rsp)
    6dad:	48 99                	cqto
    6daf:	48 89 d1             	mov    %rdx,%rcx
    6db2:	48 89 c2             	mov    %rax,%rdx
    6db5:	e8 56 1a 00 00       	call   8810 <__divmodti4>
    6dba:	44 8b 0c 24          	mov    (%rsp),%r9d
    6dbe:	48 89 c1             	mov    %rax,%rcx
    6dc1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6dc6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    6dcb:	0f 84 94 00 00 00    	je     6e65 <fwp_write+0xfb5>
    6dd1:	41 83 c1 01          	add    $0x1,%r9d
    6dd5:	48 83 c5 10          	add    $0x10,%rbp
    6dd9:	41 83 f9 05          	cmp    $0x5,%r9d
    6ddd:	75 bb                	jne    6d9a <fwp_write+0xeea>
    6ddf:	4d 85 ed             	test   %r13,%r13
    6de2:	79 53                	jns    6e37 <fwp_write+0xf87>
    6de4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6de9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    6dee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    6df3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6df8:	48 99                	cqto
    6dfa:	48 f7 d8             	neg    %rax
    6dfd:	48 83 d2 00          	adc    $0x0,%rdx
    6e01:	48 89 c6             	mov    %rax,%rsi
    6e04:	48 f7 da             	neg    %rdx
    6e07:	e8 f4 bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e0c:	49 89 e8             	mov    %rbp,%r8
    6e0f:	ba 00 02 00 00       	mov    $0x200,%edx
    6e14:	be 02 00 00 00       	mov    $0x2,%esi
    6e19:	31 c0                	xor    %eax,%eax
    6e1b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6e22:	00 
    6e23:	48 8d 0d 25 23 00 00 	lea    0x2325(%rip),%rcx        # 914f <_IO_stdin_used+0x14f>
    6e2a:	4c 89 e7             	mov    %r12,%rdi
    6e2d:	e8 6e b8 ff ff       	call   26a0 <__sprintf_chk@plt>
    6e32:	e9 f9 f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6e37:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6e3c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6e41:	31 d2                	xor    %edx,%edx
    6e43:	48 89 ef             	mov    %rbp,%rdi
    6e46:	e8 b5 bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e4b:	eb bf                	jmp    6e0c <fwp_write+0xf5c>
    6e4d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6e54:	4e 61 4e 00 
    6e58:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6e5f:	00 
    6e60:	e9 cb f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6e65:	44 89 0c 24          	mov    %r9d,(%rsp)
    6e69:	48 89 c8             	mov    %rcx,%rax
    6e6c:	48 85 d2             	test   %rdx,%rdx
    6e6f:	78 51                	js     6ec2 <fwp_write+0x1012>
    6e71:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6e76:	48 89 c6             	mov    %rax,%rsi
    6e79:	48 89 ef             	mov    %rbp,%rdi
    6e7c:	e8 7f bb ff ff       	call   2a00 <fwp_fmt_u128>
    6e81:	44 8b 0c 24          	mov    (%rsp),%r9d
    6e85:	49 63 c1             	movslq %r9d,%rax
    6e88:	49 89 e8             	mov    %rbp,%r8
    6e8b:	ba 00 02 00 00       	mov    $0x200,%edx
    6e90:	be 02 00 00 00       	mov    $0x2,%esi
    6e95:	48 c1 e0 04          	shl    $0x4,%rax
    6e99:	48 8d 3d 20 4c 00 00 	lea    0x4c20(%rip),%rdi        # bac0 <units.0>
    6ea0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6ea7:	00 
    6ea8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    6eac:	48 8d 0d 97 22 00 00 	lea    0x2297(%rip),%rcx        # 914a <_IO_stdin_used+0x14a>
    6eb3:	4c 89 e7             	mov    %r12,%rdi
    6eb6:	31 c0                	xor    %eax,%eax
    6eb8:	e8 e3 b7 ff ff       	call   26a0 <__sprintf_chk@plt>
    6ebd:	e9 6e f0 ff ff       	jmp    5f30 <fwp_write+0x80>
    6ec2:	48 f7 d8             	neg    %rax
    6ec5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    6eca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    6ecf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6ed4:	48 83 d2 00          	adc    $0x0,%rdx
    6ed8:	48 89 c6             	mov    %rax,%rsi
    6edb:	48 f7 da             	neg    %rdx
    6ede:	e8 1d bb ff ff       	call   2a00 <fwp_fmt_u128>
    6ee3:	44 8b 0c 24          	mov    (%rsp),%r9d
    6ee7:	eb 9c                	jmp    6e85 <fwp_write+0xfd5>
    6ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006ef0 <f0>:
    6ef0:	41 57                	push   %r15
    6ef2:	41 56                	push   %r14
    6ef4:	41 55                	push   %r13
    6ef6:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    6efc:	41 54                	push   %r12
    6efe:	4c 8d 25 db 57 01 00 	lea    0x157db(%rip),%r12        # 1c6e0 <fwp_heap>
    6f05:	55                   	push   %rbp
    6f06:	31 ed                	xor    %ebp,%ebp
    6f08:	53                   	push   %rbx
    6f09:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    6f10:	f3 0f 7e 35 f8 4c 00 	movq   0x4cf8(%rip),%xmm6        # bc10 <d0+0x70>
    6f17:	00 
    6f18:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f1f:	00 00 
    6f21:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    6f28:	00 
    6f29:	31 c0                	xor    %eax,%eax
    6f2b:	48 8d 9c 24 10 01 00 	lea    0x110(%rsp),%rbx
    6f32:	00 
    6f33:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
    6f3a:	00 00 00 00 00 
    6f3f:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6f44:	48 8d 05 45 eb ff ff 	lea    -0x14bb(%rip),%rax        # 5a90 <fwp_drop0>
    6f4b:	66 48 0f 6e f8       	movq   %rax,%xmm7
    6f50:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    6f54:	48 8d 05 45 ed ff ff 	lea    -0x12bb(%rip),%rax        # 5ca0 <fwp_drop6>
    6f5b:	66 0f 6c ef          	punpcklqdq %xmm7,%xmm5
    6f5f:	66 48 0f 6e f8       	movq   %rax,%xmm7
    6f64:	48 8d 05 25 ed ff ff 	lea    -0x12db(%rip),%rax        # 5c90 <fwp_drop1>
    6f6b:	66 0f 6c f7          	punpcklqdq %xmm7,%xmm6
    6f6f:	66 48 0f 6e f8       	movq   %rax,%xmm7
    6f74:	48 8b 05 f5 73 01 00 	mov    0x173f5(%rip),%rax        # 1e370 <fwp_cleanups>
    6f7b:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6f80:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    6f84:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
    6f89:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    6f90:	00 
    6f91:	48 8d 05 f8 bb ff ff 	lea    -0x4408(%rip),%rax        # 2b90 <fwp_range_release>
    6f98:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    6f9f:	00 
    6fa0:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    6fa7:	00 
    6fa8:	48 89 04 24          	mov    %rax,(%rsp)
    6fac:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    6fb3:	00 
    6fb4:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    6fbb:	00 
    6fbc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6fc1:	48 89 05 a8 73 01 00 	mov    %rax,0x173a8(%rip)        # 1e370 <fwp_cleanups>
    6fc8:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    6fcf:	00 
    6fd0:	eb 44                	jmp    7016 <f0+0x126>
    6fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fd8:	80 f9 01             	cmp    $0x1,%cl
    6fdb:	75 27                	jne    7004 <f0+0x114>
    6fdd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6fe0:	0f b7 c0             	movzwl %ax,%eax
    6fe3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fe6:	48 0f af c1          	imul   %rcx,%rax
    6fea:	48 c1 e8 20          	shr    $0x20,%rax
    6fee:	48 39 d0             	cmp    %rdx,%rax
    6ff1:	73 11                	jae    7004 <f0+0x114>
    6ff3:	49 01 c6             	add    %rax,%r14
    6ff6:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6ffa:	0f 84 64 10 00 00    	je     8064 <f0+0x1174>
    7000:	41 c6 06 01          	movb   $0x1,(%r14)
    7004:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
    700b:	00 
    700c:	49 83 ed 01          	sub    $0x1,%r13
    7010:	0f 82 88 00 00 00    	jb     709e <f0+0x1ae>
    7016:	48 89 de             	mov    %rbx,%rsi
    7019:	bf 01 00 00 00       	mov    $0x1,%edi
    701e:	48 89 ac 24 18 01 00 	mov    %rbp,0x118(%rsp)
    7025:	00 
    7026:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    702d:	00 
    702e:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7035:	00 
    7036:	e8 55 e0 ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    703b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7042:	00 
    7043:	48 89 c5             	mov    %rax,%rbp
    7046:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    704d:	00 
    704e:	48 c1 e2 10          	shl    $0x10,%rdx
    7052:	48 39 d0             	cmp    %rdx,%rax
    7055:	73 ad                	jae    7004 <f0+0x114>
    7057:	48 89 c2             	mov    %rax,%rdx
    705a:	48 c1 ea 10          	shr    $0x10,%rdx
    705e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7062:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7069:	00 
    706a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    706e:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    7072:	4d 85 f6             	test   %r14,%r14
    7075:	74 8d                	je     7004 <f0+0x114>
    7077:	0f b6 0a             	movzbl (%rdx),%ecx
    707a:	80 f9 02             	cmp    $0x2,%cl
    707d:	0f 85 55 ff ff ff    	jne    6fd8 <f0+0xe8>
    7083:	66 85 c0             	test   %ax,%ax
    7086:	0f 84 6a ff ff ff    	je     6ff6 <f0+0x106>
    708c:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
    7093:	00 
    7094:	49 83 ed 01          	sub    $0x1,%r13
    7098:	0f 83 78 ff ff ff    	jae    7016 <f0+0x126>
    709e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    70a5:	00 
    70a6:	66 0f 6f 05 62 24 00 	movdqa 0x2462(%rip),%xmm0        # 9510 <msg.3+0xc0>
    70ad:	00 
    70ae:	bf 01 00 00 00       	mov    $0x1,%edi
    70b3:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    70ba:	00 
    70bb:	48 89 05 ae 72 01 00 	mov    %rax,0x172ae(%rip)        # 1e370 <fwp_cleanups>
    70c2:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    70c9:	00 
    70ca:	e8 c1 df ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    70cf:	48 8b 15 e2 69 01 00 	mov    0x169e2(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    70d6:	49 89 c7             	mov    %rax,%r15
    70d9:	48 2b 05 b0 69 01 00 	sub    0x169b0(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    70e0:	48 c1 e2 10          	shl    $0x10,%rdx
    70e4:	48 39 d0             	cmp    %rdx,%rax
    70e7:	73 59                	jae    7142 <f0+0x252>
    70e9:	48 89 c2             	mov    %rax,%rdx
    70ec:	48 c1 ea 10          	shr    $0x10,%rdx
    70f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70f4:	48 8b 15 dd 69 01 00 	mov    0x169dd(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    70fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    70ff:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7103:	4d 85 ed             	test   %r13,%r13
    7106:	74 3a                	je     7142 <f0+0x252>
    7108:	0f b6 0a             	movzbl (%rdx),%ecx
    710b:	80 f9 02             	cmp    $0x2,%cl
    710e:	0f 84 ab 0f 00 00    	je     80bf <f0+0x11cf>
    7114:	80 f9 01             	cmp    $0x1,%cl
    7117:	75 29                	jne    7142 <f0+0x252>
    7119:	8b 4a 18             	mov    0x18(%rdx),%ecx
    711c:	0f b7 c0             	movzwl %ax,%eax
    711f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7122:	48 0f af c1          	imul   %rcx,%rax
    7126:	48 c1 e8 20          	shr    $0x20,%rax
    712a:	48 39 d0             	cmp    %rdx,%rax
    712d:	73 13                	jae    7142 <f0+0x252>
    712f:	49 01 c5             	add    %rax,%r13
    7132:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7137:	0f 84 9d 0f 00 00    	je     80da <f0+0x11ea>
    713d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    7142:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    7149:	00 f0 3f 
    714c:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    7153:	00 
    7154:	bf 01 00 00 00       	mov    $0x1,%edi
    7159:	4c 89 bc 24 e8 00 00 	mov    %r15,0xe8(%rsp)
    7160:	00 
    7161:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
    7168:	00 
    7169:	e8 22 df ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    716e:	48 8b 15 43 69 01 00 	mov    0x16943(%rip),%rdx        # 1dab8 <fwp_heap+0x13d8>
    7175:	49 89 c7             	mov    %rax,%r15
    7178:	48 2b 05 11 69 01 00 	sub    0x16911(%rip),%rax        # 1da90 <fwp_heap+0x13b0>
    717f:	48 c1 e2 10          	shl    $0x10,%rdx
    7183:	48 39 d0             	cmp    %rdx,%rax
    7186:	73 59                	jae    71e1 <f0+0x2f1>
    7188:	48 89 c2             	mov    %rax,%rdx
    718b:	48 c1 ea 10          	shr    $0x10,%rdx
    718f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7193:	48 8b 15 3e 69 01 00 	mov    0x1693e(%rip),%rdx        # 1dad8 <fwp_heap+0x13f8>
    719a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    719e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    71a2:	4d 85 ed             	test   %r13,%r13
    71a5:	74 3a                	je     71e1 <f0+0x2f1>
    71a7:	0f b6 0a             	movzbl (%rdx),%ecx
    71aa:	80 f9 02             	cmp    $0x2,%cl
    71ad:	0f 84 fe 0e 00 00    	je     80b1 <f0+0x11c1>
    71b3:	80 f9 01             	cmp    $0x1,%cl
    71b6:	75 29                	jne    71e1 <f0+0x2f1>
    71b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    71bb:	0f b7 c0             	movzwl %ax,%eax
    71be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71c1:	48 0f af c1          	imul   %rcx,%rax
    71c5:	48 c1 e8 20          	shr    $0x20,%rax
    71c9:	48 39 d0             	cmp    %rdx,%rax
    71cc:	73 13                	jae    71e1 <f0+0x2f1>
    71ce:	49 01 c5             	add    %rax,%r13
    71d1:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    71d6:	0f 84 0b 0f 00 00    	je     80e7 <f0+0x11f7>
    71dc:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    71e1:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    71e8:	33 f3 bf 
    71eb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    71f2:	00 
    71f3:	bf 01 00 00 00       	mov    $0x1,%edi
    71f8:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
    71ff:	00 
    7200:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
    7207:	00 
    7208:	e8 83 de ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    720d:	48 8b 0d a4 68 01 00 	mov    0x168a4(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    7214:	48 8b 35 75 68 01 00 	mov    0x16875(%rip),%rsi        # 1da90 <fwp_heap+0x13b0>
    721b:	48 89 c2             	mov    %rax,%rdx
    721e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7223:	48 89 cf             	mov    %rcx,%rdi
    7226:	48 29 f2             	sub    %rsi,%rdx
    7229:	48 c1 e7 10          	shl    $0x10,%rdi
    722d:	48 39 fa             	cmp    %rdi,%rdx
    7230:	73 6b                	jae    729d <f0+0x3ad>
    7232:	48 89 d7             	mov    %rdx,%rdi
    7235:	48 c1 ef 10          	shr    $0x10,%rdi
    7239:	4c 8d 0c bf          	lea    (%rdi,%rdi,4),%r9
    723d:	48 8b 3d 94 68 01 00 	mov    0x16894(%rip),%rdi        # 1dad8 <fwp_heap+0x13f8>
    7244:	4a 8d 3c cf          	lea    (%rdi,%r9,8),%rdi
    7248:	4c 8b 6f 20          	mov    0x20(%rdi),%r13
    724c:	4d 85 ed             	test   %r13,%r13
    724f:	74 4c                	je     729d <f0+0x3ad>
    7251:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7255:	41 80 f9 02          	cmp    $0x2,%r9b
    7259:	0f 84 44 0e 00 00    	je     80a3 <f0+0x11b3>
    725f:	41 80 f9 01          	cmp    $0x1,%r9b
    7263:	75 38                	jne    729d <f0+0x3ad>
    7265:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7269:	0f b7 d2             	movzwl %dx,%edx
    726c:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    726f:	49 0f af d1          	imul   %r9,%rdx
    7273:	48 c1 ea 20          	shr    $0x20,%rdx
    7277:	48 39 fa             	cmp    %rdi,%rdx
    727a:	73 21                	jae    729d <f0+0x3ad>
    727c:	49 01 d5             	add    %rdx,%r13
    727f:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7284:	0f 84 43 0e 00 00    	je     80cd <f0+0x11dd>
    728a:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    728f:	48 8b 35 fa 67 01 00 	mov    0x167fa(%rip),%rsi        # 1da90 <fwp_heap+0x13b0>
    7296:	48 8b 0d 1b 68 01 00 	mov    0x1681b(%rip),%rcx        # 1dab8 <fwp_heap+0x13d8>
    729d:	48 8d 44 24 78       	lea    0x78(%rsp),%rax
    72a2:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
    72a7:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    72ac:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
    72b3:	00 
    72b4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    72b9:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
    72be:	66 90                	xchg   %ax,%ax
    72c0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    72c5:	48 c1 e1 10          	shl    $0x10,%rcx
    72c9:	48 29 f0             	sub    %rsi,%rax
    72cc:	48 39 c8             	cmp    %rcx,%rax
    72cf:	73 76                	jae    7347 <f0+0x457>
    72d1:	48 89 c2             	mov    %rax,%rdx
    72d4:	48 c1 ea 10          	shr    $0x10,%rdx
    72d8:	48 8d 3c 92          	lea    (%rdx,%rdx,4),%rdi
    72dc:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    72e3:	00 
    72e4:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
    72e8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    72ec:	48 85 ff             	test   %rdi,%rdi
    72ef:	74 56                	je     7347 <f0+0x457>
    72f1:	44 0f b6 02          	movzbl (%rdx),%r8d
    72f5:	41 80 f8 02          	cmp    $0x2,%r8b
    72f9:	0f 84 c1 0c 00 00    	je     7fc0 <f0+0x10d0>
    72ff:	41 80 f8 01          	cmp    $0x1,%r8b
    7303:	75 42                	jne    7347 <f0+0x457>
    7305:	44 8b 42 18          	mov    0x18(%rdx),%r8d
    7309:	0f b7 c0             	movzwl %ax,%eax
    730c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    730f:	49 0f af c0          	imul   %r8,%rax
    7313:	48 c1 e8 20          	shr    $0x20,%rax
    7317:	48 39 d0             	cmp    %rdx,%rax
    731a:	73 2b                	jae    7347 <f0+0x457>
    731c:	48 01 c7             	add    %rax,%rdi
    731f:	0f b6 07             	movzbl (%rdi),%eax
    7322:	84 c0                	test   %al,%al
    7324:	74 21                	je     7347 <f0+0x457>
    7326:	3c fd                	cmp    $0xfd,%al
    7328:	0f 87 57 0d 00 00    	ja     8085 <f0+0x1195>
    732e:	83 c0 01             	add    $0x1,%eax
    7331:	88 07                	mov    %al,(%rdi)
    7333:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    733a:	00 
    733b:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    7342:	00 
    7343:	48 c1 e1 10          	shl    $0x10,%rcx
    7347:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    734c:	48 8b 40 10          	mov    0x10(%rax),%rax
    7350:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7355:	48 29 f0             	sub    %rsi,%rax
    7358:	48 39 c8             	cmp    %rcx,%rax
    735b:	73 5e                	jae    73bb <f0+0x4cb>
    735d:	48 89 c2             	mov    %rax,%rdx
    7360:	48 c1 ea 10          	shr    $0x10,%rdx
    7364:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7368:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    736f:	00 
    7370:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7374:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7378:	48 85 ff             	test   %rdi,%rdi
    737b:	74 3e                	je     73bb <f0+0x4cb>
    737d:	0f b6 0a             	movzbl (%rdx),%ecx
    7380:	80 f9 02             	cmp    $0x2,%cl
    7383:	0f 84 b7 0b 00 00    	je     7f40 <f0+0x1050>
    7389:	80 f9 01             	cmp    $0x1,%cl
    738c:	75 2d                	jne    73bb <f0+0x4cb>
    738e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7391:	0f b7 c0             	movzwl %ax,%eax
    7394:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7397:	48 0f af c1          	imul   %rcx,%rax
    739b:	48 c1 e8 20          	shr    $0x20,%rax
    739f:	48 39 d0             	cmp    %rdx,%rax
    73a2:	73 17                	jae    73bb <f0+0x4cb>
    73a4:	48 01 c7             	add    %rax,%rdi
    73a7:	0f b6 07             	movzbl (%rdi),%eax
    73aa:	84 c0                	test   %al,%al
    73ac:	74 0d                	je     73bb <f0+0x4cb>
    73ae:	3c fd                	cmp    $0xfd,%al
    73b0:	0f 87 c5 0c 00 00    	ja     807b <f0+0x118b>
    73b6:	83 c0 01             	add    $0x1,%eax
    73b9:	88 07                	mov    %al,(%rdi)
    73bb:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    73c0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    73c5:	e8 d6 d8 ff ff       	call   4ca0 <fwp_map_items>
    73ca:	66 0f 6f 6c 24 50    	movdqa 0x50(%rsp),%xmm5
    73d0:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    73d5:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    73dc:	00 00 00 00 00 
    73e1:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    73e6:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    73ed:	00 
    73ee:	49 89 c6             	mov    %rax,%r14
    73f1:	0f 11 ac 24 b8 00 00 	movups %xmm5,0xb8(%rsp)
    73f8:	00 
    73f9:	e8 a2 d8 ff ff       	call   4ca0 <fwp_map_items>
    73fe:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
    7405:	00 
    7406:	49 89 c5             	mov    %rax,%r13
    7409:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    740e:	49 39 c1             	cmp    %rax,%r9
    7411:	49 0f 46 c1          	cmovbe %r9,%rax
    7415:	48 89 c5             	mov    %rax,%rbp
    7418:	48 85 c0             	test   %rax,%rax
    741b:	0f 84 bf 0a 00 00    	je     7ee0 <f0+0xff0>
    7421:	45 31 ff             	xor    %r15d,%r15d
    7424:	eb 46                	jmp    746c <f0+0x57c>
    7426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    742d:	00 00 00 
    7430:	40 80 ff 01          	cmp    $0x1,%dil
    7434:	75 25                	jne    745b <f0+0x56b>
    7436:	8b 79 18             	mov    0x18(%rcx),%edi
    7439:	0f b7 c0             	movzwl %ax,%eax
    743c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    743f:	48 0f af c7          	imul   %rdi,%rax
    7443:	48 c1 e8 20          	shr    $0x20,%rax
    7447:	48 39 c8             	cmp    %rcx,%rax
    744a:	73 0f                	jae    745b <f0+0x56b>
    744c:	48 01 c2             	add    %rax,%rdx
    744f:	80 3a ff             	cmpb   $0xff,(%rdx)
    7452:	0f 84 a8 02 00 00    	je     7700 <f0+0x810>
    7458:	c6 02 01             	movb   $0x1,(%rdx)
    745b:	4b 89 34 fe          	mov    %rsi,(%r14,%r15,8)
    745f:	49 83 c7 01          	add    $0x1,%r15
    7463:	4c 39 fd             	cmp    %r15,%rbp
    7466:	0f 84 d4 00 00 00    	je     7540 <f0+0x650>
    746c:	f2 43 0f 10 5c fd 00 	movsd  0x0(%r13,%r15,8),%xmm3
    7473:	f2 43 0f 10 0c fe    	movsd  (%r14,%r15,8),%xmm1
    7479:	48 89 de             	mov    %rbx,%rsi
    747c:	31 ff                	xor    %edi,%edi
    747e:	f2 0f 10 15 fa 1f 00 	movsd  0x1ffa(%rip),%xmm2        # 9480 <msg.3+0x30>
    7485:	00 
    7486:	66 0f 28 c3          	movapd %xmm3,%xmm0
    748a:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    748e:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    7492:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    7496:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    749a:	f2 0f 10 05 d6 1f 00 	movsd  0x1fd6(%rip),%xmm0        # 9478 <msg.3+0x28>
    74a1:	00 
    74a2:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    74a6:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    74aa:	f2 0f 59 0d d6 1f 00 	mulsd  0x1fd6(%rip),%xmm1        # 9488 <msg.3+0x38>
    74b1:	00 
    74b2:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    74b6:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    74ba:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    74c1:	00 
    74c2:	e8 c9 db ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    74c7:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    74ce:	00 
    74cf:	48 89 c6             	mov    %rax,%rsi
    74d2:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    74d9:	00 
    74da:	48 c1 e2 10          	shl    $0x10,%rdx
    74de:	48 39 d0             	cmp    %rdx,%rax
    74e1:	0f 83 74 ff ff ff    	jae    745b <f0+0x56b>
    74e7:	48 89 c2             	mov    %rax,%rdx
    74ea:	48 c1 ea 10          	shr    $0x10,%rdx
    74ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74f2:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    74f9:	00 
    74fa:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    74fe:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7502:	48 85 d2             	test   %rdx,%rdx
    7505:	0f 84 50 ff ff ff    	je     745b <f0+0x56b>
    750b:	0f b6 39             	movzbl (%rcx),%edi
    750e:	40 80 ff 02          	cmp    $0x2,%dil
    7512:	0f 85 18 ff ff ff    	jne    7430 <f0+0x540>
    7518:	66 85 c0             	test   %ax,%ax
    751b:	0f 84 2e ff ff ff    	je     744f <f0+0x55f>
    7521:	4b 89 34 fe          	mov    %rsi,(%r14,%r15,8)
    7525:	49 83 c7 01          	add    $0x1,%r15
    7529:	4c 39 fd             	cmp    %r15,%rbp
    752c:	0f 85 3a ff ff ff    	jne    746c <f0+0x57c>
    7532:	0f 1f 00             	nopl   (%rax)
    7535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    753c:	00 00 00 00 
    7540:	4c 89 ef             	mov    %r13,%rdi
    7543:	e8 48 cc ff ff       	call   4190 <fwp_mem_free>
    7548:	48 8b 3c 24          	mov    (%rsp),%rdi
    754c:	48 89 ac 24 a8 00 00 	mov    %rbp,0xa8(%rsp)
    7553:	00 
    7554:	e8 d7 dd ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    7559:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    755e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    7563:	e8 28 e5 ff ff       	call   5a90 <fwp_drop0>
    7568:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
    756d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7571:	bf 01 00 00 00       	mov    $0x1,%edi
    7576:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    757d:	00 
    757e:	e8 0d db ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    7583:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    758a:	00 
    758b:	49 89 c6             	mov    %rax,%r14
    758e:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7595:	00 
    7596:	48 c1 e2 10          	shl    $0x10,%rdx
    759a:	48 39 d0             	cmp    %rdx,%rax
    759d:	73 58                	jae    75f7 <f0+0x707>
    759f:	48 89 c2             	mov    %rax,%rdx
    75a2:	48 c1 ea 10          	shr    $0x10,%rdx
    75a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75aa:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    75b1:	00 
    75b2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75b6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    75ba:	4d 85 ff             	test   %r15,%r15
    75bd:	74 38                	je     75f7 <f0+0x707>
    75bf:	0f b6 0a             	movzbl (%rdx),%ecx
    75c2:	80 f9 02             	cmp    $0x2,%cl
    75c5:	0f 84 55 09 00 00    	je     7f20 <f0+0x1030>
    75cb:	80 f9 01             	cmp    $0x1,%cl
    75ce:	75 27                	jne    75f7 <f0+0x707>
    75d0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    75d3:	0f b7 c0             	movzwl %ax,%eax
    75d6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    75d9:	48 0f af c1          	imul   %rcx,%rax
    75dd:	48 c1 e8 20          	shr    $0x20,%rax
    75e1:	48 39 d0             	cmp    %rdx,%rax
    75e4:	73 11                	jae    75f7 <f0+0x707>
    75e6:	49 01 c7             	add    %rax,%r15
    75e9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    75ed:	0f 84 40 09 00 00    	je     7f33 <f0+0x1043>
    75f3:	41 c6 07 01          	movb   $0x1,(%r15)
    75f7:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    75fc:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    7601:	e8 9a d6 ff ff       	call   4ca0 <fwp_map_items>
    7606:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    760c:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
    7613:	00 
    7614:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    761b:	00 00 00 00 00 
    7620:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7627:	00 
    7628:	0f 11 b4 24 b8 00 00 	movups %xmm6,0xb8(%rsp)
    762f:	00 
    7630:	48 85 ed             	test   %rbp,%rbp
    7633:	0f 84 f9 00 00 00    	je     7732 <f0+0x842>
    7639:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    763e:	45 31 ff             	xor    %r15d,%r15d
    7641:	48 89 c3             	mov    %rax,%rbx
    7644:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
    7649:	eb 55                	jmp    76a0 <f0+0x7b0>
    764b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7650:	40 80 fe 01          	cmp    $0x1,%sil
    7654:	75 2d                	jne    7683 <f0+0x793>
    7656:	8b 72 18             	mov    0x18(%rdx),%esi
    7659:	0f b7 c0             	movzwl %ax,%eax
    765c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    765f:	48 0f af c6          	imul   %rsi,%rax
    7663:	48 c1 e8 20          	shr    $0x20,%rax
    7667:	48 39 d0             	cmp    %rdx,%rax
    766a:	73 17                	jae    7683 <f0+0x793>
    766c:	48 01 c7             	add    %rax,%rdi
    766f:	0f b6 07             	movzbl (%rdi),%eax
    7672:	84 c0                	test   %al,%al
    7674:	74 0d                	je     7683 <f0+0x793>
    7676:	3c fd                	cmp    $0xfd,%al
    7678:	0f 87 82 08 00 00    	ja     7f00 <f0+0x1010>
    767e:	83 c0 01             	add    $0x1,%eax
    7681:	88 07                	mov    %al,(%rdi)
    7683:	4d 8b 75 08          	mov    0x8(%r13),%r14
    7687:	4c 89 ef             	mov    %r13,%rdi
    768a:	e8 f1 dd ff ff       	call   5480 <fwp_drop4>
    768f:	4e 89 34 fb          	mov    %r14,(%rbx,%r15,8)
    7693:	49 83 c7 01          	add    $0x1,%r15
    7697:	49 39 ef             	cmp    %rbp,%r15
    769a:	0f 84 88 00 00 00    	je     7728 <f0+0x838>
    76a0:	4e 8b 2c fb          	mov    (%rbx,%r15,8),%r13
    76a4:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    76ab:	00 
    76ac:	4c 89 e8             	mov    %r13,%rax
    76af:	48 c1 e2 10          	shl    $0x10,%rdx
    76b3:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    76ba:	00 
    76bb:	48 39 d0             	cmp    %rdx,%rax
    76be:	73 c3                	jae    7683 <f0+0x793>
    76c0:	48 89 c2             	mov    %rax,%rdx
    76c3:	48 c1 ea 10          	shr    $0x10,%rdx
    76c7:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    76cb:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    76d2:	00 
    76d3:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    76d7:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    76db:	48 85 ff             	test   %rdi,%rdi
    76de:	74 a3                	je     7683 <f0+0x793>
    76e0:	0f b6 32             	movzbl (%rdx),%esi
    76e3:	40 80 fe 02          	cmp    $0x2,%sil
    76e7:	0f 85 63 ff ff ff    	jne    7650 <f0+0x760>
    76ed:	66 85 c0             	test   %ax,%ax
    76f0:	75 91                	jne    7683 <f0+0x793>
    76f2:	e9 78 ff ff ff       	jmp    766f <f0+0x77f>
    76f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76fe:	00 00 
    7700:	48 89 d7             	mov    %rdx,%rdi
    7703:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
    7708:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    770d:	e8 3e c8 ff ff       	call   3f50 <fwp_rc_forget_slot>
    7712:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    7717:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    771c:	e9 37 fd ff ff       	jmp    7458 <f0+0x568>
    7721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7728:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
    772d:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    7732:	4c 8b 3c 24          	mov    (%rsp),%r15
    7736:	48 89 ac 24 a8 00 00 	mov    %rbp,0xa8(%rsp)
    773d:	00 
    773e:	4c 89 ff             	mov    %r15,%rdi
    7741:	e8 ea db ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    7746:	4c 89 fe             	mov    %r15,%rsi
    7749:	48 89 c7             	mov    %rax,%rdi
    774c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7751:	e8 4a d5 ff ff       	call   4ca0 <fwp_map_items>
    7756:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    775d:	00 
    775e:	48 89 c5             	mov    %rax,%rbp
    7761:	4c 89 f0             	mov    %r14,%rax
    7764:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    776b:	00 
    776c:	48 c1 e2 10          	shl    $0x10,%rdx
    7770:	48 39 d0             	cmp    %rdx,%rax
    7773:	73 5e                	jae    77d3 <f0+0x8e3>
    7775:	48 89 c2             	mov    %rax,%rdx
    7778:	48 c1 ea 10          	shr    $0x10,%rdx
    777c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7780:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7787:	00 
    7788:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    778c:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7790:	48 85 ff             	test   %rdi,%rdi
    7793:	74 3e                	je     77d3 <f0+0x8e3>
    7795:	0f b6 0a             	movzbl (%rdx),%ecx
    7798:	80 f9 02             	cmp    $0x2,%cl
    779b:	0f 84 6f 07 00 00    	je     7f10 <f0+0x1020>
    77a1:	80 f9 01             	cmp    $0x1,%cl
    77a4:	75 2d                	jne    77d3 <f0+0x8e3>
    77a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77a9:	0f b7 c0             	movzwl %ax,%eax
    77ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77af:	48 0f af c1          	imul   %rcx,%rax
    77b3:	48 c1 e8 20          	shr    $0x20,%rax
    77b7:	48 39 d0             	cmp    %rdx,%rax
    77ba:	73 17                	jae    77d3 <f0+0x8e3>
    77bc:	48 01 c7             	add    %rax,%rdi
    77bf:	0f b6 07             	movzbl (%rdi),%eax
    77c2:	84 c0                	test   %al,%al
    77c4:	74 0d                	je     77d3 <f0+0x8e3>
    77c6:	3c fd                	cmp    $0xfd,%al
    77c8:	0f 87 a3 08 00 00    	ja     8071 <f0+0x1181>
    77ce:	83 c0 01             	add    $0x1,%eax
    77d1:	88 07                	mov    %al,(%rdi)
    77d3:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
    77da:	00 
    77db:	4d 89 f5             	mov    %r14,%r13
    77de:	4d 85 ff             	test   %r15,%r15
    77e1:	0f 84 e9 06 00 00    	je     7ed0 <f0+0xfe0>
    77e7:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
    77ec:	49 89 ee             	mov    %rbp,%r14
    77ef:	4c 89 fd             	mov    %r15,%rbp
    77f2:	eb 3a                	jmp    782e <f0+0x93e>
    77f4:	0f 1f 40 00          	nopl   0x0(%rax)
    77f8:	40 80 fe 01          	cmp    $0x1,%sil
    77fc:	75 27                	jne    7825 <f0+0x935>
    77fe:	8b 72 18             	mov    0x18(%rdx),%esi
    7801:	0f b7 c0             	movzwl %ax,%eax
    7804:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7807:	48 0f af c6          	imul   %rsi,%rax
    780b:	48 c1 e8 20          	shr    $0x20,%rax
    780f:	48 39 d0             	cmp    %rdx,%rax
    7812:	73 11                	jae    7825 <f0+0x935>
    7814:	49 01 c7             	add    %rax,%r15
    7817:	41 80 3f ff          	cmpb   $0xff,(%r15)
    781b:	0f 84 9f 06 00 00    	je     7ec0 <f0+0xfd0>
    7821:	41 c6 07 01          	movb   $0x1,(%r15)
    7825:	48 85 ed             	test   %rbp,%rbp
    7828:	0f 84 82 00 00 00    	je     78b0 <f0+0x9c0>
    782e:	48 83 ed 01          	sub    $0x1,%rbp
    7832:	66 49 0f 6e e5       	movq   %r13,%xmm4
    7837:	48 89 de             	mov    %rbx,%rsi
    783a:	bf 01 00 00 00       	mov    $0x1,%edi
    783f:	f3 41 0f 7e 04 ee    	movq   (%r14,%rbp,8),%xmm0
    7845:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    7849:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    7850:	00 
    7851:	e8 3a d8 ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    7856:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    785d:	00 
    785e:	49 89 c5             	mov    %rax,%r13
    7861:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7868:	00 
    7869:	48 c1 e2 10          	shl    $0x10,%rdx
    786d:	48 39 d0             	cmp    %rdx,%rax
    7870:	73 b3                	jae    7825 <f0+0x935>
    7872:	48 89 c2             	mov    %rax,%rdx
    7875:	48 c1 ea 10          	shr    $0x10,%rdx
    7879:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    787d:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7884:	00 
    7885:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    7889:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    788d:	4d 85 ff             	test   %r15,%r15
    7890:	74 93                	je     7825 <f0+0x935>
    7892:	0f b6 32             	movzbl (%rdx),%esi
    7895:	40 80 fe 02          	cmp    $0x2,%sil
    7899:	0f 85 59 ff ff ff    	jne    77f8 <f0+0x908>
    789f:	66 85 c0             	test   %ax,%ax
    78a2:	0f 84 6f ff ff ff    	je     7817 <f0+0x927>
    78a8:	48 85 ed             	test   %rbp,%rbp
    78ab:	75 81                	jne    782e <f0+0x93e>
    78ad:	0f 1f 00             	nopl   (%rax)
    78b0:	4c 89 f5             	mov    %r14,%rbp
    78b3:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    78b8:	48 89 ef             	mov    %rbp,%rdi
    78bb:	e8 d0 c8 ff ff       	call   4190 <fwp_mem_free>
    78c0:	4c 89 f7             	mov    %r14,%rdi
    78c3:	e8 c8 e1 ff ff       	call   5a90 <fwp_drop0>
    78c8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    78cd:	e8 be e1 ff ff       	call   5a90 <fwp_drop0>
    78d2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    78d7:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    78dc:	e8 bf d3 ff ff       	call   4ca0 <fwp_map_items>
    78e1:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    78e7:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
    78ee:	00 
    78ef:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    78f6:	00 00 00 00 00 
    78fb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7902:	00 
    7903:	0f 11 bc 24 b8 00 00 	movups %xmm7,0xb8(%rsp)
    790a:	00 
    790b:	48 85 d2             	test   %rdx,%rdx
    790e:	0f 84 d1 00 00 00    	je     79e5 <f0+0xaf5>
    7914:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    7919:	45 31 f6             	xor    %r14d,%r14d
    791c:	49 89 d7             	mov    %rdx,%r15
    791f:	48 89 c3             	mov    %rax,%rbx
    7922:	4c 89 6c 24 38       	mov    %r13,0x38(%rsp)
    7927:	eb 53                	jmp    797c <f0+0xa8c>
    7929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7930:	40 80 fe 01          	cmp    $0x1,%sil
    7934:	75 2d                	jne    7963 <f0+0xa73>
    7936:	8b 72 18             	mov    0x18(%rdx),%esi
    7939:	0f b7 c0             	movzwl %ax,%eax
    793c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    793f:	48 0f af c6          	imul   %rsi,%rax
    7943:	48 c1 e8 20          	shr    $0x20,%rax
    7947:	48 39 d0             	cmp    %rdx,%rax
    794a:	73 17                	jae    7963 <f0+0xa73>
    794c:	48 01 c7             	add    %rax,%rdi
    794f:	0f b6 07             	movzbl (%rdi),%eax
    7952:	84 c0                	test   %al,%al
    7954:	74 0d                	je     7963 <f0+0xa73>
    7956:	3c fd                	cmp    $0xfd,%al
    7958:	0f 87 92 05 00 00    	ja     7ef0 <f0+0x1000>
    795e:	83 c0 01             	add    $0x1,%eax
    7961:	88 07                	mov    %al,(%rdi)
    7963:	4c 8b 6d 10          	mov    0x10(%rbp),%r13
    7967:	48 89 ef             	mov    %rbp,%rdi
    796a:	e8 11 db ff ff       	call   5480 <fwp_drop4>
    796f:	4e 89 2c f3          	mov    %r13,(%rbx,%r14,8)
    7973:	49 83 c6 01          	add    $0x1,%r14
    7977:	4d 39 fe             	cmp    %r15,%r14
    797a:	74 5c                	je     79d8 <f0+0xae8>
    797c:	4a 8b 2c f3          	mov    (%rbx,%r14,8),%rbp
    7980:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7987:	00 
    7988:	48 89 e8             	mov    %rbp,%rax
    798b:	48 c1 e2 10          	shl    $0x10,%rdx
    798f:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7996:	00 
    7997:	48 39 d0             	cmp    %rdx,%rax
    799a:	73 c7                	jae    7963 <f0+0xa73>
    799c:	48 89 c2             	mov    %rax,%rdx
    799f:	48 c1 ea 10          	shr    $0x10,%rdx
    79a3:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    79a7:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    79ae:	00 
    79af:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    79b3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    79b7:	48 85 ff             	test   %rdi,%rdi
    79ba:	74 a7                	je     7963 <f0+0xa73>
    79bc:	0f b6 32             	movzbl (%rdx),%esi
    79bf:	40 80 fe 02          	cmp    $0x2,%sil
    79c3:	0f 85 67 ff ff ff    	jne    7930 <f0+0xa40>
    79c9:	66 85 c0             	test   %ax,%ax
    79cc:	75 95                	jne    7963 <f0+0xa73>
    79ce:	e9 7c ff ff ff       	jmp    794f <f0+0xa5f>
    79d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79d8:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
    79dd:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    79e2:	4c 89 fa             	mov    %r15,%rdx
    79e5:	48 8b 3c 24          	mov    (%rsp),%rdi
    79e9:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    79f0:	00 
    79f1:	e8 3a d9 ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    79f6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    79fb:	49 89 c6             	mov    %rax,%r14
    79fe:	e8 9d e2 ff ff       	call   5ca0 <fwp_drop6>
    7a03:	48 89 de             	mov    %rbx,%rsi
    7a06:	bf 01 00 00 00       	mov    $0x1,%edi
    7a0b:	4c 89 b4 24 18 01 00 	mov    %r14,0x118(%rsp)
    7a12:	00 
    7a13:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
    7a1a:	00 00 00 00 00 
    7a1f:	e8 6c d6 ff ff       	call   5090 <fwp_data.part.0.constprop.0>
    7a24:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    7a2b:	00 
    7a2c:	49 89 c6             	mov    %rax,%r14
    7a2f:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7a36:	00 
    7a37:	48 c1 e1 10          	shl    $0x10,%rcx
    7a3b:	48 39 c8             	cmp    %rcx,%rax
    7a3e:	73 5a                	jae    7a9a <f0+0xbaa>
    7a40:	48 89 c1             	mov    %rax,%rcx
    7a43:	48 c1 e9 10          	shr    $0x10,%rcx
    7a47:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a4b:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    7a52:	00 
    7a53:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a57:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    7a5b:	4d 85 ff             	test   %r15,%r15
    7a5e:	74 3a                	je     7a9a <f0+0xbaa>
    7a60:	0f b6 31             	movzbl (%rcx),%esi
    7a63:	40 80 fe 02          	cmp    $0x2,%sil
    7a67:	0f 84 e3 04 00 00    	je     7f50 <f0+0x1060>
    7a6d:	40 80 fe 01          	cmp    $0x1,%sil
    7a71:	75 27                	jne    7a9a <f0+0xbaa>
    7a73:	8b 71 18             	mov    0x18(%rcx),%esi
    7a76:	0f b7 c0             	movzwl %ax,%eax
    7a79:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a7c:	48 0f af c6          	imul   %rsi,%rax
    7a80:	48 c1 e8 20          	shr    $0x20,%rax
    7a84:	48 39 c8             	cmp    %rcx,%rax
    7a87:	73 11                	jae    7a9a <f0+0xbaa>
    7a89:	49 01 c7             	add    %rax,%r15
    7a8c:	41 80 3f ff          	cmpb   $0xff,(%r15)
    7a90:	0f 84 68 05 00 00    	je     7ffe <f0+0x110e>
    7a96:	41 c6 07 01          	movb   $0x1,(%r15)
    7a9a:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    7a9f:	4c 89 f7             	mov    %r14,%rdi
    7aa2:	e8 f9 d1 ff ff       	call   4ca0 <fwp_map_items>
    7aa7:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    7aad:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7ab2:	4c 89 ef             	mov    %r13,%rdi
    7ab5:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7abc:	00 
    7abd:	49 89 c7             	mov    %rax,%r15
    7ac0:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7ac7:	00 00 00 00 00 
    7acc:	0f 11 ac 24 b8 00 00 	movups %xmm5,0xb8(%rsp)
    7ad3:	00 
    7ad4:	e8 c7 d1 ff ff       	call   4ca0 <fwp_map_items>
    7ad9:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    7ae0:	00 
    7ae1:	48 89 c7             	mov    %rax,%rdi
    7ae4:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    7ae9:	48 39 c1             	cmp    %rax,%rcx
    7aec:	48 0f 47 c8          	cmova  %rax,%rcx
    7af0:	48 85 c9             	test   %rcx,%rcx
    7af3:	0f 84 f7 04 00 00    	je     7ff0 <f0+0x1100>
    7af9:	31 c0                	xor    %eax,%eax
    7afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b00:	f2 41 0f 10 04 c7    	movsd  (%r15,%rax,8),%xmm0
    7b06:	f2 0f 58 04 c7       	addsd  (%rdi,%rax,8),%xmm0
    7b0b:	f2 41 0f 11 04 c7    	movsd  %xmm0,(%r15,%rax,8)
    7b11:	48 83 c0 01          	add    $0x1,%rax
    7b15:	48 39 c1             	cmp    %rax,%rcx
    7b18:	75 e6                	jne    7b00 <f0+0xc10>
    7b1a:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    7b1f:	e8 6c c6 ff ff       	call   4190 <fwp_mem_free>
    7b24:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    7b29:	48 8b 3c 24          	mov    (%rsp),%rdi
    7b2d:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
    7b34:	00 
    7b35:	e8 f6 d7 ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    7b3a:	4c 89 ef             	mov    %r13,%rdi
    7b3d:	49 89 c7             	mov    %rax,%r15
    7b40:	e8 4b df ff ff       	call   5a90 <fwp_drop0>
    7b45:	4c 89 f7             	mov    %r14,%rdi
    7b48:	e8 43 df ff ff       	call   5a90 <fwp_drop0>
    7b4d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7b52:	4c 89 ff             	mov    %r15,%rdi
    7b55:	e8 46 d1 ff ff       	call   4ca0 <fwp_map_items>
    7b5a:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    7b60:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    7b67:	00 
    7b68:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7b6f:	00 00 00 00 00 
    7b74:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7b7b:	00 
    7b7c:	0f 11 b4 24 b8 00 00 	movups %xmm6,0xb8(%rsp)
    7b83:	00 
    7b84:	48 85 c9             	test   %rcx,%rcx
    7b87:	74 31                	je     7bba <f0+0xcca>
    7b89:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
    7b8d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7b94:	00 
    7b95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b9c:	00 00 00 00 
    7ba0:	f2 0f 10 05 c8 18 00 	movsd  0x18c8(%rip),%xmm0        # 9470 <msg.3+0x20>
    7ba7:	00 
    7ba8:	f2 0f 59 00          	mulsd  (%rax),%xmm0
    7bac:	48 83 c0 08          	add    $0x8,%rax
    7bb0:	f2 0f 11 40 f8       	movsd  %xmm0,-0x8(%rax)
    7bb5:	48 39 c2             	cmp    %rax,%rdx
    7bb8:	75 e6                	jne    7ba0 <f0+0xcb0>
    7bba:	48 8b 3c 24          	mov    (%rsp),%rdi
    7bbe:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
    7bc5:	00 
    7bc6:	e8 65 d7 ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    7bcb:	4c 89 ff             	mov    %r15,%rdi
    7bce:	49 89 c6             	mov    %rax,%r14
    7bd1:	e8 ba de ff ff       	call   5a90 <fwp_drop0>
    7bd6:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    7bdb:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    7be0:	e8 bb d0 ff ff       	call   4ca0 <fwp_map_items>
    7be5:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    7beb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7bf0:	4c 89 f7             	mov    %r14,%rdi
    7bf3:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7bfa:	00 
    7bfb:	49 89 c7             	mov    %rax,%r15
    7bfe:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7c05:	00 00 00 00 00 
    7c0a:	0f 11 bc 24 b8 00 00 	movups %xmm7,0xb8(%rsp)
    7c11:	00 
    7c12:	e8 89 d0 ff ff       	call   4ca0 <fwp_map_items>
    7c17:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
    7c1e:	00 
    7c1f:	48 89 c7             	mov    %rax,%rdi
    7c22:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    7c27:	48 39 c2             	cmp    %rax,%rdx
    7c2a:	48 0f 47 d0          	cmova  %rax,%rdx
    7c2e:	48 85 d2             	test   %rdx,%rdx
    7c31:	0f 84 a9 03 00 00    	je     7fe0 <f0+0x10f0>
    7c37:	31 c0                	xor    %eax,%eax
    7c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c40:	f2 41 0f 10 04 c7    	movsd  (%r15,%rax,8),%xmm0
    7c46:	f2 0f 5c 04 c7       	subsd  (%rdi,%rax,8),%xmm0
    7c4b:	f2 41 0f 11 04 c7    	movsd  %xmm0,(%r15,%rax,8)
    7c51:	48 83 c0 01          	add    $0x1,%rax
    7c55:	48 39 c2             	cmp    %rax,%rdx
    7c58:	75 e6                	jne    7c40 <f0+0xd50>
    7c5a:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    7c5f:	e8 2c c5 ff ff       	call   4190 <fwp_mem_free>
    7c64:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    7c69:	4c 8b 3c 24          	mov    (%rsp),%r15
    7c6d:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    7c74:	00 
    7c75:	4c 89 ff             	mov    %r15,%rdi
    7c78:	e8 b3 d6 ff ff       	call   5330 <fwp_map_finish_protected.isra.0>
    7c7d:	4c 89 f7             	mov    %r14,%rdi
    7c80:	48 89 c5             	mov    %rax,%rbp
    7c83:	e8 08 de ff ff       	call   5a90 <fwp_drop0>
    7c88:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    7c8d:	e8 fe dd ff ff       	call   5a90 <fwp_drop0>
    7c92:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7c96:	48 89 ee             	mov    %rbp,%rsi
    7c99:	4c 89 ff             	mov    %r15,%rdi
    7c9c:	b9 01 00 00 00       	mov    $0x1,%ecx
    7ca1:	48 8d 15 f8 3e 00 00 	lea    0x3ef8(%rip),%rdx        # bba0 <d0>
    7ca8:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7caf:	00 00 00 00 00 
    7cb4:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    7cbb:	00 
    7cbc:	e8 ef e1 ff ff       	call   5eb0 <fwp_write>
    7cc1:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    7cc8:	00 
    7cc9:	4c 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%r9
    7cd0:	00 
    7cd1:	48 8d 05 56 13 00 00 	lea    0x1356(%rip),%rax        # 902e <_IO_stdin_used+0x2e>
    7cd8:	48 85 c9             	test   %rcx,%rcx
    7cdb:	48 0f 44 c8          	cmove  %rax,%rcx
    7cdf:	49 83 f9 f6          	cmp    $0xfffffffffffffff6,%r9
    7ce3:	0f 87 10 04 00 00    	ja     80f9 <f0+0x1209>
    7ce9:	41 8b 84 24 a4 13 00 	mov    0x13a4(%r12),%eax
    7cf0:	00 
    7cf1:	49 8d 51 09          	lea    0x9(%r9),%rdx
    7cf5:	85 c0                	test   %eax,%eax
    7cf7:	0f 84 7e 02 00 00    	je     7f7b <f0+0x108b>
    7cfd:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    7d04:	0f 87 71 02 00 00    	ja     7f7b <f0+0x108b>
    7d0a:	49 8d 41 18          	lea    0x18(%r9),%rax
    7d0e:	48 c1 e8 04          	shr    $0x4,%rax
    7d12:	41 0f b6 84 04 a0 0f 	movzbl 0xfa0(%r12,%rax,1),%eax
    7d19:	00 00 
    7d1b:	45 8b b4 84 00 0f 00 	mov    0xf00(%r12,%rax,4),%r14d
    7d22:	00 
    7d23:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7d27:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
    7d2b:	4c 8b b8 c0 03 00 00 	mov    0x3c0(%rax),%r15
    7d32:	4d 85 ff             	test   %r15,%r15
    7d35:	0f 84 25 02 00 00    	je     7f60 <f0+0x1070>
    7d3b:	49 8b 37             	mov    (%r15),%rsi
    7d3e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    7d43:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    7d48:	48 f7 d6             	not    %rsi
    7d4b:	48 89 b0 c0 03 00 00 	mov    %rsi,0x3c0(%rax)
    7d52:	31 f6                	xor    %esi,%esi
    7d54:	4c 89 ff             	mov    %r15,%rdi
    7d57:	e8 44 a7 ff ff       	call   24a0 <memset@plt>
    7d5c:	4c 89 f0             	mov    %r14,%rax
    7d5f:	49 03 84 24 20 14 00 	add    0x1420(%r12),%rax
    7d66:	00 
    7d67:	0f 82 87 03 00 00    	jb     80f4 <f0+0x1204>
    7d6d:	49 39 84 24 28 14 00 	cmp    %rax,0x1428(%r12)
    7d74:	00 
    7d75:	49 89 84 24 20 14 00 	mov    %rax,0x1420(%r12)
    7d7c:	00 
    7d7d:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    7d82:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    7d87:	73 08                	jae    7d91 <f0+0xea1>
    7d89:	49 89 84 24 28 14 00 	mov    %rax,0x1428(%r12)
    7d90:	00 
    7d91:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7d95:	f2 49 0f 2a c6       	cvtsi2sd %r14,%xmm0
    7d9a:	f2 41 0f 58 84 24 38 	addsd  0x1438(%r12),%xmm0
    7da1:	14 00 00 
    7da4:	f2 41 0f 11 84 24 38 	movsd  %xmm0,0x1438(%r12)
    7dab:	14 00 00 
    7dae:	4d 89 0f             	mov    %r9,(%r15)
    7db1:	4d 8d 77 08          	lea    0x8(%r15),%r14
    7db5:	4c 89 ca             	mov    %r9,%rdx
    7db8:	48 89 ce             	mov    %rcx,%rsi
    7dbb:	4c 89 f7             	mov    %r14,%rdi
    7dbe:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    7dc3:	e8 a8 a7 ff ff       	call   2570 <memcpy@plt>
    7dc8:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    7dcd:	43 c6 44 0f 08 00    	movb   $0x0,0x8(%r15,%r9,1)
    7dd3:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    7dda:	00 
    7ddb:	e8 c0 a5 ff ff       	call   23a0 <free@plt>
    7de0:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7de7:	00 
    7de8:	4c 89 f8             	mov    %r15,%rax
    7deb:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7df2:	00 
    7df3:	48 c1 e2 10          	shl    $0x10,%rdx
    7df7:	48 39 d0             	cmp    %rdx,%rax
    7dfa:	73 58                	jae    7e54 <f0+0xf64>
    7dfc:	48 89 c2             	mov    %rax,%rdx
    7dff:	48 c1 ea 10          	shr    $0x10,%rdx
    7e03:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e07:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7e0e:	00 
    7e0f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7e13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7e17:	48 85 d2             	test   %rdx,%rdx
    7e1a:	74 38                	je     7e54 <f0+0xf64>
    7e1c:	0f b6 31             	movzbl (%rcx),%esi
    7e1f:	40 80 fe 02          	cmp    $0x2,%sil
    7e23:	0f 84 a7 01 00 00    	je     7fd0 <f0+0x10e0>
    7e29:	40 80 fe 01          	cmp    $0x1,%sil
    7e2d:	75 25                	jne    7e54 <f0+0xf64>
    7e2f:	8b 71 18             	mov    0x18(%rcx),%esi
    7e32:	0f b7 c0             	movzwl %ax,%eax
    7e35:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e38:	48 0f af c6          	imul   %rsi,%rax
    7e3c:	48 c1 e8 20          	shr    $0x20,%rax
    7e40:	48 39 c8             	cmp    %rcx,%rax
    7e43:	73 0f                	jae    7e54 <f0+0xf64>
    7e45:	48 01 c2             	add    %rax,%rdx
    7e48:	80 3a ff             	cmpb   $0xff,(%rdx)
    7e4b:	0f 84 fc 01 00 00    	je     804d <f0+0x115d>
    7e51:	c6 02 01             	movb   $0x1,(%rdx)
    7e54:	48 89 ef             	mov    %rbp,%rdi
    7e57:	e8 34 dc ff ff       	call   5a90 <fwp_drop0>
    7e5c:	49 8b 17             	mov    (%r15),%rdx
    7e5f:	be 01 00 00 00       	mov    $0x1,%esi
    7e64:	4c 89 f7             	mov    %r14,%rdi
    7e67:	48 8b 0d ca 64 01 00 	mov    0x164ca(%rip),%rcx        # 1e338 <fwp_prog_out>
    7e6e:	e8 cd a7 ff ff       	call   2640 <fwrite@plt>
    7e73:	48 8b 35 be 64 01 00 	mov    0x164be(%rip),%rsi        # 1e338 <fwp_prog_out>
    7e7a:	bf 0a 00 00 00       	mov    $0xa,%edi
    7e7f:	e8 3c a6 ff ff       	call   24c0 <fputc@plt>
    7e84:	4c 89 ff             	mov    %r15,%rdi
    7e87:	e8 f4 d5 ff ff       	call   5480 <fwp_drop4>
    7e8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7e91:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e95:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    7e9a:	48 85 c0             	test   %rax,%rax
    7e9d:	0f 84 68 01 00 00    	je     800b <f0+0x111b>
    7ea3:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    7eaa:	00 
    7eab:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    7eb2:	00 
    7eb3:	e9 08 f4 ff ff       	jmp    72c0 <f0+0x3d0>
    7eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7ebf:	00 
    7ec0:	4c 89 ff             	mov    %r15,%rdi
    7ec3:	e8 88 c0 ff ff       	call   3f50 <fwp_rc_forget_slot>
    7ec8:	e9 54 f9 ff ff       	jmp    7821 <f0+0x931>
    7ecd:	0f 1f 00             	nopl   (%rax)
    7ed0:	48 85 ed             	test   %rbp,%rbp
    7ed3:	0f 84 e7 f9 ff ff    	je     78c0 <f0+0x9d0>
    7ed9:	e9 da f9 ff ff       	jmp    78b8 <f0+0x9c8>
    7ede:	66 90                	xchg   %ax,%ax
    7ee0:	4d 85 ed             	test   %r13,%r13
    7ee3:	0f 84 5f f6 ff ff    	je     7548 <f0+0x658>
    7ee9:	e9 52 f6 ff ff       	jmp    7540 <f0+0x650>
    7eee:	66 90                	xchg   %ax,%ax
    7ef0:	e8 3b bf ff ff       	call   3e30 <fwp_rc_wide_dup>
    7ef5:	e9 69 fa ff ff       	jmp    7963 <f0+0xa73>
    7efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f00:	e8 2b bf ff ff       	call   3e30 <fwp_rc_wide_dup>
    7f05:	e9 79 f7 ff ff       	jmp    7683 <f0+0x793>
    7f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f10:	66 85 c0             	test   %ax,%ax
    7f13:	0f 85 ba f8 ff ff    	jne    77d3 <f0+0x8e3>
    7f19:	e9 a1 f8 ff ff       	jmp    77bf <f0+0x8cf>
    7f1e:	66 90                	xchg   %ax,%ax
    7f20:	66 85 c0             	test   %ax,%ax
    7f23:	0f 85 ce f6 ff ff    	jne    75f7 <f0+0x707>
    7f29:	41 80 3f ff          	cmpb   $0xff,(%r15)
    7f2d:	0f 85 c0 f6 ff ff    	jne    75f3 <f0+0x703>
    7f33:	4c 89 ff             	mov    %r15,%rdi
    7f36:	e8 15 c0 ff ff       	call   3f50 <fwp_rc_forget_slot>
    7f3b:	e9 b3 f6 ff ff       	jmp    75f3 <f0+0x703>
    7f40:	66 85 c0             	test   %ax,%ax
    7f43:	0f 85 72 f4 ff ff    	jne    73bb <f0+0x4cb>
    7f49:	e9 59 f4 ff ff       	jmp    73a7 <f0+0x4b7>
    7f4e:	66 90                	xchg   %ax,%ax
    7f50:	66 85 c0             	test   %ax,%ax
    7f53:	0f 85 41 fb ff ff    	jne    7a9a <f0+0xbaa>
    7f59:	e9 2e fb ff ff       	jmp    7a8c <f0+0xb9c>
    7f5e:	66 90                	xchg   %ax,%ax
    7f60:	4c 8b b8 c8 03 00 00 	mov    0x3c8(%rax),%r15
    7f67:	4d 85 ff             	test   %r15,%r15
    7f6a:	74 0f                	je     7f7b <f0+0x108b>
    7f6c:	48 8b b0 d0 03 00 00 	mov    0x3d0(%rax),%rsi
    7f73:	4c 29 fe             	sub    %r15,%rsi
    7f76:	4c 39 f6             	cmp    %r14,%rsi
    7f79:	73 29                	jae    7fa4 <f0+0x10b4>
    7f7b:	be 01 00 00 00       	mov    $0x1,%esi
    7f80:	48 89 d7             	mov    %rdx,%rdi
    7f83:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    7f88:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    7f8d:	e8 7e c5 ff ff       	call   4510 <fwp_heap_alloc_slow>
    7f92:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    7f97:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    7f9c:	49 89 c7             	mov    %rax,%r15
    7f9f:	e9 0a fe ff ff       	jmp    7dae <f0+0xebe>
    7fa4:	4b 8d 34 37          	lea    (%r15,%r14,1),%rsi
    7fa8:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    7fad:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
    7fb2:	48 89 b0 c8 03 00 00 	mov    %rsi,0x3c8(%rax)
    7fb9:	e9 94 fd ff ff       	jmp    7d52 <f0+0xe62>
    7fbe:	66 90                	xchg   %ax,%ax
    7fc0:	66 85 c0             	test   %ax,%ax
    7fc3:	0f 85 7e f3 ff ff    	jne    7347 <f0+0x457>
    7fc9:	e9 51 f3 ff ff       	jmp    731f <f0+0x42f>
    7fce:	66 90                	xchg   %ax,%ax
    7fd0:	66 85 c0             	test   %ax,%ax
    7fd3:	0f 85 7b fe ff ff    	jne    7e54 <f0+0xf64>
    7fd9:	e9 6a fe ff ff       	jmp    7e48 <f0+0xf58>
    7fde:	66 90                	xchg   %ax,%ax
    7fe0:	48 85 ff             	test   %rdi,%rdi
    7fe3:	0f 84 80 fc ff ff    	je     7c69 <f0+0xd79>
    7fe9:	e9 6c fc ff ff       	jmp    7c5a <f0+0xd6a>
    7fee:	66 90                	xchg   %ax,%ax
    7ff0:	48 85 ff             	test   %rdi,%rdi
    7ff3:	0f 84 30 fb ff ff    	je     7b29 <f0+0xc39>
    7ff9:	e9 1c fb ff ff       	jmp    7b1a <f0+0xc2a>
    7ffe:	4c 89 ff             	mov    %r15,%rdi
    8001:	e8 4a bf ff ff       	call   3f50 <fwp_rc_forget_slot>
    8006:	e9 8b fa ff ff       	jmp    7a96 <f0+0xba6>
    800b:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
    8010:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8015:	e8 76 da ff ff       	call   5a90 <fwp_drop0>
    801a:	48 89 ef             	mov    %rbp,%rdi
    801d:	e8 6e da ff ff       	call   5a90 <fwp_drop0>
    8022:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    8029:	00 
    802a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8031:	00 00 
    8033:	0f 85 cc 00 00 00    	jne    8105 <f0+0x1215>
    8039:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    8040:	31 c0                	xor    %eax,%eax
    8042:	5b                   	pop    %rbx
    8043:	5d                   	pop    %rbp
    8044:	41 5c                	pop    %r12
    8046:	41 5d                	pop    %r13
    8048:	41 5e                	pop    %r14
    804a:	41 5f                	pop    %r15
    804c:	c3                   	ret
    804d:	48 89 d7             	mov    %rdx,%rdi
    8050:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    8055:	e8 f6 be ff ff       	call   3f50 <fwp_rc_forget_slot>
    805a:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    805f:	e9 ed fd ff ff       	jmp    7e51 <f0+0xf61>
    8064:	4c 89 f7             	mov    %r14,%rdi
    8067:	e8 e4 be ff ff       	call   3f50 <fwp_rc_forget_slot>
    806c:	e9 8f ef ff ff       	jmp    7000 <f0+0x110>
    8071:	e8 ba bd ff ff       	call   3e30 <fwp_rc_wide_dup>
    8076:	e9 58 f7 ff ff       	jmp    77d3 <f0+0x8e3>
    807b:	e8 b0 bd ff ff       	call   3e30 <fwp_rc_wide_dup>
    8080:	e9 36 f3 ff ff       	jmp    73bb <f0+0x4cb>
    8085:	e8 a6 bd ff ff       	call   3e30 <fwp_rc_wide_dup>
    808a:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    8091:	00 
    8092:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    8099:	00 
    809a:	48 c1 e1 10          	shl    $0x10,%rcx
    809e:	e9 a4 f2 ff ff       	jmp    7347 <f0+0x457>
    80a3:	66 85 d2             	test   %dx,%dx
    80a6:	0f 85 f1 f1 ff ff    	jne    729d <f0+0x3ad>
    80ac:	e9 ce f1 ff ff       	jmp    727f <f0+0x38f>
    80b1:	66 85 c0             	test   %ax,%ax
    80b4:	0f 85 27 f1 ff ff    	jne    71e1 <f0+0x2f1>
    80ba:	e9 12 f1 ff ff       	jmp    71d1 <f0+0x2e1>
    80bf:	66 85 c0             	test   %ax,%ax
    80c2:	0f 85 7a f0 ff ff    	jne    7142 <f0+0x252>
    80c8:	e9 65 f0 ff ff       	jmp    7132 <f0+0x242>
    80cd:	4c 89 ef             	mov    %r13,%rdi
    80d0:	e8 7b be ff ff       	call   3f50 <fwp_rc_forget_slot>
    80d5:	e9 b0 f1 ff ff       	jmp    728a <f0+0x39a>
    80da:	4c 89 ef             	mov    %r13,%rdi
    80dd:	e8 6e be ff ff       	call   3f50 <fwp_rc_forget_slot>
    80e2:	e9 56 f0 ff ff       	jmp    713d <f0+0x24d>
    80e7:	4c 89 ef             	mov    %r13,%rdi
    80ea:	e8 61 be ff ff       	call   3f50 <fwp_rc_forget_slot>
    80ef:	e9 e8 f0 ff ff       	jmp    71dc <f0+0x2ec>
    80f4:	e8 77 ab ff ff       	call   2c70 <fwp_heap_oom>
    80f9:	48 8d 3d 5b 10 00 00 	lea    0x105b(%rip),%rdi        # 915b <_IO_stdin_used+0x15b>
    8100:	e8 1b b0 ff ff       	call   3120 <fwp_trap>
    8105:	e8 36 a3 ff ff       	call   2440 <__stack_chk_fail@plt>
    810a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008110 <fwp_main_thread>:
    8110:	f3 0f 1e fa          	endbr64
    8114:	41 54                	push   %r12
    8116:	55                   	push   %rbp
    8117:	53                   	push   %rbx
    8118:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    811f:	8b 0d 5f 59 01 00    	mov    0x1595f(%rip),%ecx        # 1da84 <fwp_heap+0x13a4>
    8125:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    812c:	00 00 
    812e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    8135:	00 
    8136:	31 c0                	xor    %eax,%eax
    8138:	85 c9                	test   %ecx,%ecx
    813a:	0f 84 68 06 00 00    	je     87a8 <fwp_main_thread+0x698>
    8140:	8b 15 42 59 01 00    	mov    0x15942(%rip),%edx        # 1da88 <fwp_heap+0x13a8>
    8146:	85 d2                	test   %edx,%edx
    8148:	0f 85 42 06 00 00    	jne    8790 <fwp_main_thread+0x680>
    814e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    8153:	31 f6                	xor    %esi,%esi
    8155:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    815a:	48 c7 05 23 3f 01 00 	movq   $0x40000000,0x13f23(%rip)        # 1c088 <fwp_main_stack_size>
    8161:	00 00 00 40 
    8165:	48 89 05 24 3f 01 00 	mov    %rax,0x13f24(%rip)        # 1c090 <fwp_main_stack_top>
    816c:	48 8d 05 0d 3f 00 00 	lea    0x3f0d(%rip),%rax        # c080 <alt.4>
    8173:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8178:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    817f:	01 00 
    8181:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    8188:	00 
    8189:	e8 f2 a4 ff ff       	call   2680 <sigaltstack@plt>
    818e:	85 c0                	test   %eax,%eax
    8190:	0f 85 4a 06 00 00    	jne    87e0 <fwp_main_thread+0x6d0>
    8196:	31 c0                	xor    %eax,%eax
    8198:	b9 12 00 00 00       	mov    $0x12,%ecx
    819d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    81a2:	f3 48 ab             	rep stos %rax,(%rdi)
    81a5:	48 8d 05 04 ab ff ff 	lea    -0x54fc(%rip),%rax        # 2cb0 <fwp_segv>
    81ac:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    81b1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    81b8:	04 00 00 08 
    81bc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    81c1:	e8 8a a3 ff ff       	call   2550 <sigemptyset@plt>
    81c6:	85 c0                	test   %eax,%eax
    81c8:	0f 85 12 06 00 00    	jne    87e0 <fwp_main_thread+0x6d0>
    81ce:	31 d2                	xor    %edx,%edx
    81d0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    81d5:	bf 0b 00 00 00       	mov    $0xb,%edi
    81da:	e8 01 a2 ff ff       	call   23e0 <sigaction@plt>
    81df:	85 c0                	test   %eax,%eax
    81e1:	0f 85 f9 05 00 00    	jne    87e0 <fwp_main_thread+0x6d0>
    81e7:	31 d2                	xor    %edx,%edx
    81e9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    81ee:	bf 07 00 00 00       	mov    $0x7,%edi
    81f3:	e8 e8 a1 ff ff       	call   23e0 <sigaction@plt>
    81f8:	85 c0                	test   %eax,%eax
    81fa:	0f 85 e0 05 00 00    	jne    87e0 <fwp_main_thread+0x6d0>
    8200:	8b 05 62 3e 00 00    	mov    0x3e62(%rip),%eax        # c068 <st.2>
    8206:	85 c0                	test   %eax,%eax
    8208:	0f 84 62 05 00 00    	je     8770 <fwp_main_thread+0x660>
    820e:	48 8b 2d ab 44 01 00 	mov    0x144ab(%rip),%rbp        # 1c6c0 <fwp_cur>
    8215:	48 85 ed             	test   %rbp,%rbp
    8218:	0f 84 72 03 00 00    	je     8590 <fwp_main_thread+0x480>
    821e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    8223:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    8227:	48 89 eb             	mov    %rbp,%rbx
    822a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    822f:	0f 84 41 01 00 00    	je     8376 <fwp_main_thread+0x266>
    8235:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    823a:	0f 84 80 02 00 00    	je     84c0 <fwp_main_thread+0x3b0>
    8240:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    8244:	0f 84 66 02 00 00    	je     84b0 <fwp_main_thread+0x3a0>
    824a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    824e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    8252:	0f 85 e8 02 00 00    	jne    8540 <fwp_main_thread+0x430>
    8258:	48 8b 43 60          	mov    0x60(%rbx),%rax
    825c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    8263:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    8267:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    826e:	00 00 00 00 
    8272:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    8279:	48 85 d2             	test   %rdx,%rdx
    827c:	74 07                	je     8285 <fwp_main_thread+0x175>
    827e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    8285:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    8289:	48 85 c0             	test   %rax,%rax
    828c:	74 34                	je     82c2 <fwp_main_thread+0x1b2>
    828e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    8292:	48 8b 05 ff 43 01 00 	mov    0x143ff(%rip),%rax        # 1c698 <fwp_timers>
    8299:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    829d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    82a4:	00 00 00 00 
    82a8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    82af:	48 85 c0             	test   %rax,%rax
    82b2:	74 07                	je     82bb <fwp_main_thread+0x1ab>
    82b4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    82bb:	48 89 1d d6 43 01 00 	mov    %rbx,0x143d6(%rip)        # 1c698 <fwp_timers>
    82c2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    82c6:	e8 25 c8 ff ff       	call   4af0 <fwp_block>
    82cb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    82d2:	48 85 c9             	test   %rcx,%rcx
    82d5:	74 47                	je     831e <fwp_main_thread+0x20e>
    82d7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    82de:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    82e5:	48 85 d2             	test   %rdx,%rdx
    82e8:	0f 84 92 02 00 00    	je     8580 <fwp_main_thread+0x470>
    82ee:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    82f5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    82fc:	48 85 c0             	test   %rax,%rax
    82ff:	74 07                	je     8308 <fwp_main_thread+0x1f8>
    8301:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    8308:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    830f:	00 00 00 00 
    8313:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8317:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    831e:	48 8b 0d 9b 43 01 00 	mov    0x1439b(%rip),%rcx        # 1c6c0 <fwp_cur>
    8325:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    8329:	0f 84 01 02 00 00    	je     8530 <fwp_main_thread+0x420>
    832f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    8336:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    833d:	48 85 d2             	test   %rdx,%rdx
    8340:	0f 84 fa 03 00 00    	je     8740 <fwp_main_thread+0x630>
    8346:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    834d:	48 85 c0             	test   %rax,%rax
    8350:	74 07                	je     8359 <fwp_main_thread+0x249>
    8352:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    8359:	66 0f ef c9          	pxor   %xmm1,%xmm1
    835d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    8361:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    8368:	48 89 cb             	mov    %rcx,%rbx
    836b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    8370:	0f 85 bf fe ff ff    	jne    8235 <fwp_main_thread+0x125>
    8376:	48 83 3d d2 5f 01 00 	cmpq   $0x0,0x15fd2(%rip)        # 1e350 <fwp_state_len>
    837d:	00 
    837e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    8382:	0f 84 ba 00 00 00    	je     8442 <fwp_main_thread+0x332>
    8388:	48 39 1d 29 43 01 00 	cmp    %rbx,0x14329(%rip)        # 1c6b8 <fwp_root>
    838f:	c7 05 e7 3c 01 00 00 	movl   $0x0,0x13ce7(%rip)        # 1c080 <fwp_exit_code>
    8396:	00 00 00 
    8399:	0f 85 5f 04 00 00    	jne    87fe <fwp_main_thread+0x6ee>
    839f:	48 85 db             	test   %rbx,%rbx
    83a2:	0f 84 0e 02 00 00    	je     85b6 <fwp_main_thread+0x4a6>
    83a8:	48 8b 15 d9 42 01 00 	mov    0x142d9(%rip),%rdx        # 1c688 <fwp_tasks_active>
    83af:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    83b3:	48 85 d2             	test   %rdx,%rdx
    83b6:	0f 84 fa 01 00 00    	je     85b6 <fwp_main_thread+0x4a6>
    83bc:	0f 1f 40 00          	nopl   0x0(%rax)
    83c0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    83c4:	75 08                	jne    83ce <fwp_main_thread+0x2be>
    83c6:	48 89 d7             	mov    %rdx,%rdi
    83c9:	e8 62 ac ff ff       	call   3030 <fwp_cancel_tree.part.0>
    83ce:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    83d5:	48 85 d2             	test   %rdx,%rdx
    83d8:	75 e6                	jne    83c0 <fwp_main_thread+0x2b0>
    83da:	eb 31                	jmp    840d <fwp_main_thread+0x2fd>
    83dc:	0f 1f 40 00          	nopl   0x0(%rax)
    83e0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    83e7:	48 89 1d b2 42 01 00 	mov    %rbx,0x142b2(%rip)        # 1c6a0 <fwp_ready_tail>
    83ee:	e8 fd c6 ff ff       	call   4af0 <fwp_block>
    83f3:	e8 f8 c4 ff ff       	call   48f0 <fwp_free_zombie>
    83f8:	48 83 3d 88 42 01 00 	cmpq   $0x0,0x14288(%rip)        # 1c688 <fwp_tasks_active>
    83ff:	00 
    8400:	0f 84 b0 01 00 00    	je     85b6 <fwp_main_thread+0x4a6>
    8406:	48 8b 1d ab 42 01 00 	mov    0x142ab(%rip),%rbx        # 1c6b8 <fwp_root>
    840d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    8411:	75 db                	jne    83ee <fwp_main_thread+0x2de>
    8413:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    8417:	75 d5                	jne    83ee <fwp_main_thread+0x2de>
    8419:	48 8b 05 80 42 01 00 	mov    0x14280(%rip),%rax        # 1c6a0 <fwp_ready_tail>
    8420:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    8424:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    842b:	00 00 00 00 
    842f:	48 85 c0             	test   %rax,%rax
    8432:	75 ac                	jne    83e0 <fwp_main_thread+0x2d0>
    8434:	48 89 1d 6d 42 01 00 	mov    %rbx,0x1426d(%rip)        # 1c6a8 <fwp_ready_head>
    843b:	eb aa                	jmp    83e7 <fwp_main_thread+0x2d7>
    843d:	0f 1f 00             	nopl   (%rax)
    8440:	31 db                	xor    %ebx,%ebx
    8442:	48 83 3d f6 5e 01 00 	cmpq   $0x0,0x15ef6(%rip)        # 1e340 <fwp_state_owners>
    8449:	00 
    844a:	0f 85 38 ff ff ff    	jne    8388 <fwp_main_thread+0x278>
    8450:	48 8b 3d 01 5f 01 00 	mov    0x15f01(%rip),%rdi        # 1e358 <fwp_state>
    8457:	e8 34 bd ff ff       	call   4190 <fwp_mem_free>
    845c:	48 c7 05 f1 5e 01 00 	movq   $0x0,0x15ef1(%rip)        # 1e358 <fwp_state>
    8463:	00 00 00 00 
    8467:	48 c7 05 d6 5e 01 00 	movq   $0x0,0x15ed6(%rip)        # 1e348 <fwp_state_cap>
    846e:	00 00 00 00 
    8472:	48 85 db             	test   %rbx,%rbx
    8475:	0f 84 46 03 00 00    	je     87c1 <fwp_main_thread+0x6b1>
    847b:	48 39 1d 36 42 01 00 	cmp    %rbx,0x14236(%rip)        # 1c6b8 <fwp_root>
    8482:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    8489:	00 00 00 00 
    848d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    8494:	00 00 00 00 
    8498:	c7 05 de 3b 01 00 00 	movl   $0x0,0x13bde(%rip)        # 1c080 <fwp_exit_code>
    849f:	00 00 00 
    84a2:	0f 84 00 ff ff ff    	je     83a8 <fwp_main_thread+0x298>
    84a8:	e9 5e a2 ff ff       	jmp    270b <fwp_main_thread.cold>
    84ad:	0f 1f 00             	nopl   (%rax)
    84b0:	e8 9b ac ff ff       	call   3150 <fwp_now_ns>
    84b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    84b9:	0f 8d 91 02 00 00    	jge    8750 <fwp_main_thread+0x640>
    84bf:	90                   	nop
    84c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    84c4:	0f 85 80 fd ff ff    	jne    824a <fwp_main_thread+0x13a>
    84ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    84ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    84d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    84d6:	0f 85 80 fd ff ff    	jne    825c <fwp_main_thread+0x14c>
    84dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    84e0:	48 85 c9             	test   %rcx,%rcx
    84e3:	0f 84 73 fd ff ff    	je     825c <fwp_main_thread+0x14c>
    84e9:	48 85 c0             	test   %rax,%rax
    84ec:	0f 84 ff 02 00 00    	je     87f1 <fwp_main_thread+0x6e1>
    84f2:	48 39 c8             	cmp    %rcx,%rax
    84f5:	48 0f 4f c1          	cmovg  %rcx,%rax
    84f9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    8500:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    8504:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    850b:	00 00 00 00 
    850f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    8516:	48 85 d2             	test   %rdx,%rdx
    8519:	74 07                	je     8522 <fwp_main_thread+0x412>
    851b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    8522:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    8526:	e9 63 fd ff ff       	jmp    828e <fwp_main_thread+0x17e>
    852b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8530:	48 89 cb             	mov    %rcx,%rbx
    8533:	e9 f2 fc ff ff       	jmp    822a <fwp_main_thread+0x11a>
    8538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    853f:	00 
    8540:	48 8b 45 40          	mov    0x40(%rbp),%rax
    8544:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    854b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    8552:	00 00 00 00 
    8556:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    855d:	48 85 c0             	test   %rax,%rax
    8560:	0f 84 52 02 00 00    	je     87b8 <fwp_main_thread+0x6a8>
    8566:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    856d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    8571:	e9 4c fd ff ff       	jmp    82c2 <fwp_main_thread+0x1b2>
    8576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    857d:	00 00 00 
    8580:	48 89 01             	mov    %rax,(%rcx)
    8583:	e9 74 fd ff ff       	jmp    82fc <fwp_main_thread+0x1ec>
    8588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    858f:	00 
    8590:	48 83 3d b8 5d 01 00 	cmpq   $0x0,0x15db8(%rip)        # 1e350 <fwp_state_len>
    8597:	00 
    8598:	0f 84 a2 fe ff ff    	je     8440 <fwp_main_thread+0x330>
    859e:	48 83 3d 12 41 01 00 	cmpq   $0x0,0x14112(%rip)        # 1c6b8 <fwp_root>
    85a5:	00 
    85a6:	c7 05 d0 3a 01 00 00 	movl   $0x0,0x13ad0(%rip)        # 1c080 <fwp_exit_code>
    85ad:	00 00 00 
    85b0:	0f 85 43 02 00 00    	jne    87f9 <fwp_main_thread+0x6e9>
    85b6:	e8 35 c3 ff ff       	call   48f0 <fwp_free_zombie>
    85bb:	48 83 3d e5 40 01 00 	cmpq   $0x0,0x140e5(%rip)        # 1c6a8 <fwp_ready_head>
    85c2:	00 
    85c3:	0f 85 42 a1 ff ff    	jne    270b <fwp_main_thread.cold>
    85c9:	48 83 3d c7 40 01 00 	cmpq   $0x0,0x140c7(%rip)        # 1c698 <fwp_timers>
    85d0:	00 
    85d1:	0f 85 34 a1 ff ff    	jne    270b <fwp_main_thread.cold>
    85d7:	8b 1d bf 3a 01 00    	mov    0x13abf(%rip),%ebx        # 1c09c <fwp_stack_pool_n>
    85dd:	85 db                	test   %ebx,%ebx
    85df:	74 36                	je     8617 <fwp_main_thread+0x507>
    85e1:	83 eb 01             	sub    $0x1,%ebx
    85e4:	48 8d 05 b5 3a 01 00 	lea    0x13ab5(%rip),%rax        # 1c0a0 <fwp_stack_pool>
    85eb:	48 63 d3             	movslq %ebx,%rdx
    85ee:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    85f2:	eb 07                	jmp    85fb <fwp_main_thread+0x4eb>
    85f4:	0f 1f 40 00          	nopl   0x0(%rax)
    85f8:	83 eb 01             	sub    $0x1,%ebx
    85fb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    85ff:	be 00 00 00 10       	mov    $0x10000000,%esi
    8604:	89 1d 92 3a 01 00    	mov    %ebx,0x13a92(%rip)        # 1c09c <fwp_stack_pool_n>
    860a:	48 83 ed 08          	sub    $0x8,%rbp
    860e:	e8 9d 9f ff ff       	call   25b0 <munmap@plt>
    8613:	85 db                	test   %ebx,%ebx
    8615:	75 e1                	jne    85f8 <fwp_main_thread+0x4e8>
    8617:	8b 3d f3 39 00 00    	mov    0x39f3(%rip),%edi        # c010 <fwp_epfd>
    861d:	85 ff                	test   %edi,%edi
    861f:	78 05                	js     8626 <fwp_main_thread+0x516>
    8621:	e8 8a 9e ff ff       	call   24b0 <close@plt>
    8626:	4c 8b 25 73 3c 01 00 	mov    0x13c73(%rip),%r12        # 1c2a0 <fwp_nfdws>
    862d:	48 8b 2d 74 3c 01 00 	mov    0x13c74(%rip),%rbp        # 1c2a8 <fwp_fdws>
    8634:	31 db                	xor    %ebx,%ebx
    8636:	c7 05 d0 39 00 00 ff 	movl   $0xffffffff,0x39d0(%rip)        # c010 <fwp_epfd>
    863d:	ff ff ff 
    8640:	4d 85 e4             	test   %r12,%r12
    8643:	74 38                	je     867d <fwp_main_thread+0x56d>
    8645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    864c:	00 00 00 00 
    8650:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    8655:	48 85 ff             	test   %rdi,%rdi
    8658:	74 1a                	je     8674 <fwp_main_thread+0x564>
    865a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    865e:	0f 85 a7 a0 ff ff    	jne    270b <fwp_main_thread.cold>
    8664:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    8669:	0f 85 9c a0 ff ff    	jne    270b <fwp_main_thread.cold>
    866f:	e8 1c bb ff ff       	call   4190 <fwp_mem_free>
    8674:	48 83 c3 01          	add    $0x1,%rbx
    8678:	4c 39 e3             	cmp    %r12,%rbx
    867b:	75 d3                	jne    8650 <fwp_main_thread+0x540>
    867d:	48 89 ef             	mov    %rbp,%rdi
    8680:	e8 0b bb ff ff       	call   4190 <fwp_mem_free>
    8685:	48 8b 15 2c 40 01 00 	mov    0x1402c(%rip),%rdx        # 1c6b8 <fwp_root>
    868c:	48 c7 05 11 3c 01 00 	movq   $0x0,0x13c11(%rip)        # 1c2a8 <fwp_fdws>
    8693:	00 00 00 00 
    8697:	48 c7 05 fe 3b 01 00 	movq   $0x0,0x13bfe(%rip)        # 1c2a0 <fwp_nfdws>
    869e:	00 00 00 00 
    86a2:	48 85 d2             	test   %rdx,%rdx
    86a5:	74 4e                	je     86f5 <fwp_main_thread+0x5e5>
    86a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    86ac:	0f 85 59 a0 ff ff    	jne    270b <fwp_main_thread.cold>
    86b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    86b9:	00 
    86ba:	0f 85 4b a0 ff ff    	jne    270b <fwp_main_thread.cold>
    86c0:	48 83 3d 88 5c 01 00 	cmpq   $0x0,0x15c88(%rip)        # 1e350 <fwp_state_len>
    86c7:	00 
    86c8:	0f 85 3d a0 ff ff    	jne    270b <fwp_main_thread.cold>
    86ce:	48 83 3d 6a 5c 01 00 	cmpq   $0x0,0x15c6a(%rip)        # 1e340 <fwp_state_owners>
    86d5:	00 
    86d6:	0f 85 2f a0 ff ff    	jne    270b <fwp_main_thread.cold>
    86dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    86e1:	31 c0                	xor    %eax,%eax
    86e3:	48 8d 3d d6 3b 01 00 	lea    0x13bd6(%rip),%rdi        # 1c2c0 <fwp_root_context>
    86ea:	f3 48 ab             	rep stos %rax,(%rdi)
    86ed:	48 89 d7             	mov    %rdx,%rdi
    86f0:	e8 9b ba ff ff       	call   4190 <fwp_mem_free>
    86f5:	48 8b 3d 24 39 00 00 	mov    0x3924(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    86fc:	48 c7 05 b9 3f 01 00 	movq   $0x0,0x13fb9(%rip)        # 1c6c0 <fwp_cur>
    8703:	00 00 00 00 
    8707:	48 c7 05 a6 3f 01 00 	movq   $0x0,0x13fa6(%rip)        # 1c6b8 <fwp_root>
    870e:	00 00 00 00 
    8712:	e8 79 9e ff ff       	call   2590 <fflush@plt>
    8717:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    871e:	00 
    871f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8726:	00 00 
    8728:	0f 85 be 00 00 00    	jne    87ec <fwp_main_thread+0x6dc>
    872e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    8735:	31 c0                	xor    %eax,%eax
    8737:	5b                   	pop    %rbx
    8738:	5d                   	pop    %rbp
    8739:	41 5c                	pop    %r12
    873b:	c3                   	ret
    873c:	0f 1f 40 00          	nopl   0x0(%rax)
    8740:	48 89 05 51 3f 01 00 	mov    %rax,0x13f51(%rip)        # 1c698 <fwp_timers>
    8747:	e9 01 fc ff ff       	jmp    834d <fwp_main_thread+0x23d>
    874c:	0f 1f 40 00          	nopl   0x0(%rax)
    8750:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    8754:	0f 85 66 fd ff ff    	jne    84c0 <fwp_main_thread+0x3b0>
    875a:	48 89 ef             	mov    %rbp,%rdi
    875d:	e8 ce a8 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    8762:	e9 59 fd ff ff       	jmp    84c0 <fwp_main_thread+0x3b0>
    8767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    876e:	00 00 
    8770:	e8 7b e7 ff ff       	call   6ef0 <f0>
    8775:	48 c7 05 e0 38 00 00 	movq   $0x0,0x38e0(%rip)        # c060 <v.1>
    877c:	00 00 00 00 
    8780:	c7 05 de 38 00 00 01 	movl   $0x1,0x38de(%rip)        # c068 <st.2>
    8787:	00 00 00 
    878a:	e9 7f fa ff ff       	jmp    820e <fwp_main_thread+0xfe>
    878f:	90                   	nop
    8790:	48 8d 3d c9 af ff ff 	lea    -0x5037(%rip),%rdi        # 3760 <fwp_heap_report>
    8797:	e8 84 02 00 00       	call   8a20 <atexit>
    879c:	e9 ad f9 ff ff       	jmp    814e <fwp_main_thread+0x3e>
    87a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    87a8:	e8 c3 b0 ff ff       	call   3870 <fwp_heap_init>
    87ad:	e9 8e f9 ff ff       	jmp    8140 <fwp_main_thread+0x30>
    87b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87b8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    87bc:	e9 01 fb ff ff       	jmp    82c2 <fwp_main_thread+0x1b2>
    87c1:	48 83 3d ef 3e 01 00 	cmpq   $0x0,0x13eef(%rip)        # 1c6b8 <fwp_root>
    87c8:	00 
    87c9:	c7 05 ad 38 01 00 00 	movl   $0x0,0x138ad(%rip)        # 1c080 <fwp_exit_code>
    87d0:	00 00 00 
    87d3:	0f 84 dd fd ff ff    	je     85b6 <fwp_main_thread+0x4a6>
    87d9:	e9 2d 9f ff ff       	jmp    270b <fwp_main_thread.cold>
    87de:	66 90                	xchg   %ax,%ax
    87e0:	48 8d 3d 21 0b 00 00 	lea    0xb21(%rip),%rdi        # 9308 <_IO_stdin_used+0x308>
    87e7:	e8 34 a9 ff ff       	call   3120 <fwp_trap>
    87ec:	e8 4f 9c ff ff       	call   2440 <__stack_chk_fail@plt>
    87f1:	48 89 c8             	mov    %rcx,%rax
    87f4:	e9 00 fd ff ff       	jmp    84f9 <fwp_main_thread+0x3e9>
    87f9:	e9 0d 9f ff ff       	jmp    270b <fwp_main_thread.cold>
    87fe:	e9 08 9f ff ff       	jmp    270b <fwp_main_thread.cold>
    8803:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    880a:	00 00 00 
    880d:	0f 1f 00             	nopl   (%rax)

0000000000008810 <__divmodti4>:
    8810:	f3 0f 1e fa          	endbr64
    8814:	55                   	push   %rbp
    8815:	49 89 f1             	mov    %rsi,%r9
    8818:	49 89 d2             	mov    %rdx,%r10
    881b:	48 89 fe             	mov    %rdi,%rsi
    881e:	49 89 cb             	mov    %rcx,%r11
    8821:	48 89 e5             	mov    %rsp,%rbp
    8824:	41 57                	push   %r15
    8826:	41 56                	push   %r14
    8828:	41 55                	push   %r13
    882a:	41 54                	push   %r12
    882c:	53                   	push   %rbx
    882d:	4c 89 c3             	mov    %r8,%rbx
    8830:	45 31 c0             	xor    %r8d,%r8d
    8833:	4d 85 c9             	test   %r9,%r9
    8836:	79 12                	jns    884a <__divmodti4+0x3a>
    8838:	31 ff                	xor    %edi,%edi
    883a:	48 f7 de             	neg    %rsi
    883d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    8844:	4c 19 cf             	sbb    %r9,%rdi
    8847:	49 89 f9             	mov    %rdi,%r9
    884a:	4c 89 d8             	mov    %r11,%rax
    884d:	4d 85 db             	test   %r11,%r11
    8850:	0f 88 1a 01 00 00    	js     8970 <__divmodti4+0x160>
    8856:	4c 89 d9             	mov    %r11,%rcx
    8859:	49 89 f3             	mov    %rsi,%r11
    885c:	75 62                	jne    88c0 <__divmodti4+0xb0>
    885e:	4d 89 c4             	mov    %r8,%r12
    8861:	4d 39 d1             	cmp    %r10,%r9
    8864:	0f 83 46 01 00 00    	jae    89b0 <__divmodti4+0x1a0>
    886a:	4c 89 d8             	mov    %r11,%rax
    886d:	4c 89 ca             	mov    %r9,%rdx
    8870:	49 f7 f2             	div    %r10
    8873:	49 89 c3             	mov    %rax,%r11
    8876:	31 c0                	xor    %eax,%eax
    8878:	48 89 d6             	mov    %rdx,%rsi
    887b:	31 ff                	xor    %edi,%edi
    887d:	4c 89 d9             	mov    %r11,%rcx
    8880:	48 89 c2             	mov    %rax,%rdx
    8883:	48 89 c8             	mov    %rcx,%rax
    8886:	4d 85 e4             	test   %r12,%r12
    8889:	74 0a                	je     8895 <__divmodti4+0x85>
    888b:	48 f7 d8             	neg    %rax
    888e:	48 83 d2 00          	adc    $0x0,%rdx
    8892:	48 f7 da             	neg    %rdx
    8895:	4d 85 c0             	test   %r8,%r8
    8898:	74 0a                	je     88a4 <__divmodti4+0x94>
    889a:	48 f7 de             	neg    %rsi
    889d:	48 83 d7 00          	adc    $0x0,%rdi
    88a1:	48 f7 df             	neg    %rdi
    88a4:	48 89 33             	mov    %rsi,(%rbx)
    88a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    88ab:	5b                   	pop    %rbx
    88ac:	41 5c                	pop    %r12
    88ae:	41 5d                	pop    %r13
    88b0:	41 5e                	pop    %r14
    88b2:	41 5f                	pop    %r15
    88b4:	5d                   	pop    %rbp
    88b5:	c3                   	ret
    88b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88bd:	00 00 00 
    88c0:	4d 89 c4             	mov    %r8,%r12
    88c3:	49 39 c1             	cmp    %rax,%r9
    88c6:	0f 82 ce 00 00 00    	jb     899a <__divmodti4+0x18a>
    88cc:	31 ff                	xor    %edi,%edi
    88ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    88d3:	48 63 c7             	movslq %edi,%rax
    88d6:	be 40 00 00 00       	mov    $0x40,%esi
    88db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    88e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    88e5:	48 29 c6             	sub    %rax,%rsi
    88e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    88ed:	48 09 c8             	or     %rcx,%rax
    88f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    88f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    88fa:	49 89 c6             	mov    %rax,%r14
    88fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    8901:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    8906:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    890b:	49 09 c1             	or     %rax,%r9
    890e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    8912:	4c 89 c8             	mov    %r9,%rax
    8915:	49 f7 f6             	div    %r14
    8918:	48 89 d1             	mov    %rdx,%rcx
    891b:	49 89 c3             	mov    %rax,%r11
    891e:	49 89 c1             	mov    %rax,%r9
    8921:	49 f7 e2             	mul    %r10
    8924:	49 89 c6             	mov    %rax,%r14
    8927:	49 89 d2             	mov    %rdx,%r10
    892a:	48 39 d1             	cmp    %rdx,%rcx
    892d:	72 07                	jb     8936 <__divmodti4+0x126>
    892f:	75 17                	jne    8948 <__divmodti4+0x138>
    8931:	49 39 c7             	cmp    %rax,%r15
    8934:	73 12                	jae    8948 <__divmodti4+0x138>
    8936:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    893a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    893e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    8942:	49 89 d2             	mov    %rdx,%r10
    8945:	49 89 c6             	mov    %rax,%r14
    8948:	4c 89 f8             	mov    %r15,%rax
    894b:	4c 29 f0             	sub    %r14,%rax
    894e:	4c 19 d1             	sbb    %r10,%rcx
    8951:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    8956:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    895b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    8960:	48 09 c6             	or     %rax,%rsi
    8963:	48 89 cf             	mov    %rcx,%rdi
    8966:	31 c0                	xor    %eax,%eax
    8968:	4c 89 c9             	mov    %r9,%rcx
    896b:	e9 10 ff ff ff       	jmp    8880 <__divmodti4+0x70>
    8970:	4c 89 d0             	mov    %r10,%rax
    8973:	4c 89 da             	mov    %r11,%rdx
    8976:	4d 89 c4             	mov    %r8,%r12
    8979:	49 89 f3             	mov    %rsi,%r11
    897c:	48 f7 d8             	neg    %rax
    897f:	49 f7 d4             	not    %r12
    8982:	48 83 d2 00          	adc    $0x0,%rdx
    8986:	49 89 c2             	mov    %rax,%r10
    8989:	48 f7 da             	neg    %rdx
    898c:	48 89 d1             	mov    %rdx,%rcx
    898f:	0f 84 cc fe ff ff    	je     8861 <__divmodti4+0x51>
    8995:	49 39 d1             	cmp    %rdx,%r9
    8998:	73 46                	jae    89e0 <__divmodti4+0x1d0>
    899a:	4c 89 cf             	mov    %r9,%rdi
    899d:	31 c0                	xor    %eax,%eax
    899f:	31 c9                	xor    %ecx,%ecx
    89a1:	e9 da fe ff ff       	jmp    8880 <__divmodti4+0x70>
    89a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89ad:	00 00 00 
    89b0:	4d 85 d2             	test   %r10,%r10
    89b3:	75 0d                	jne    89c2 <__divmodti4+0x1b2>
    89b5:	b8 01 00 00 00       	mov    $0x1,%eax
    89ba:	31 d2                	xor    %edx,%edx
    89bc:	49 f7 f2             	div    %r10
    89bf:	49 89 c2             	mov    %rax,%r10
    89c2:	4c 89 c8             	mov    %r9,%rax
    89c5:	31 d2                	xor    %edx,%edx
    89c7:	49 f7 f2             	div    %r10
    89ca:	49 89 c1             	mov    %rax,%r9
    89cd:	4c 89 d8             	mov    %r11,%rax
    89d0:	49 f7 f2             	div    %r10
    89d3:	49 89 c3             	mov    %rax,%r11
    89d6:	4c 89 c8             	mov    %r9,%rax
    89d9:	e9 9a fe ff ff       	jmp    8878 <__divmodti4+0x68>
    89de:	66 90                	xchg   %ax,%ax
    89e0:	45 31 f6             	xor    %r14d,%r14d
    89e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    89e8:	44 89 f7             	mov    %r14d,%edi
    89eb:	45 85 f6             	test   %r14d,%r14d
    89ee:	0f 85 df fe ff ff    	jne    88d3 <__divmodti4+0xc3>
    89f4:	4c 39 ca             	cmp    %r9,%rdx
    89f7:	72 17                	jb     8a10 <__divmodti4+0x200>
    89f9:	31 c9                	xor    %ecx,%ecx
    89fb:	48 39 c6             	cmp    %rax,%rsi
    89fe:	73 10                	jae    8a10 <__divmodti4+0x200>
    8a00:	4c 89 cf             	mov    %r9,%rdi
    8a03:	31 c0                	xor    %eax,%eax
    8a05:	e9 76 fe ff ff       	jmp    8880 <__divmodti4+0x70>
    8a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a10:	4c 89 de             	mov    %r11,%rsi
    8a13:	b9 01 00 00 00       	mov    $0x1,%ecx
    8a18:	48 29 c6             	sub    %rax,%rsi
    8a1b:	49 19 d1             	sbb    %rdx,%r9
    8a1e:	eb e0                	jmp    8a00 <__divmodti4+0x1f0>

0000000000008a20 <atexit>:
    8a20:	f3 0f 1e fa          	endbr64
    8a24:	48 8b 15 dd 35 00 00 	mov    0x35dd(%rip),%rdx        # c008 <__dso_handle>
    8a2b:	31 f6                	xor    %esi,%esi
    8a2d:	e9 ee 9b ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008a34 <_fini>:
    8a34:	f3 0f 1e fa          	endbr64
    8a38:	48 83 ec 08          	sub    $0x8,%rsp
    8a3c:	48 83 c4 08          	add    $0x8,%rsp
    8a40:	c3                   	ret
