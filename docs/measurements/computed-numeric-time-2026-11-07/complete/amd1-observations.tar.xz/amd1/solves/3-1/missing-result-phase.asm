
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/missing-result-phase:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 fa cd 00 00    	push   0xcdfa(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 fc cd 00 00    	jmp    *0xcdfc(%rip)        # fe28 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 76 cc 00 00    	jmp    *0xcc76(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 a6 ca 00 00    	jmp    *0xcaa6(%rip)        # fe30 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 9e ca 00 00    	jmp    *0xca9e(%rip)        # fe38 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 96 ca 00 00    	jmp    *0xca96(%rip)        # fe40 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe48 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe50 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe58 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe60 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe68 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe70 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe78 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe80 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe88 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe90 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe98 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fea0 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fea8 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # feb0 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # feb8 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fec0 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fec8 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fed0 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fed8 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fee0 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fee8 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fef0 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fef8 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # ff00 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # ff08 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # ff10 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # ff18 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff20 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff28 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff30 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff38 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff40 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff48 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff50 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff58 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d 1d 8a 00 00 	lea    0x8a1d(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    36d7:	4c 8d 05 1a 8a 00 00 	lea    0x8a1a(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 aa 0c 00 00       	call   43b0 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_main_thread.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>

0000000000003710 <main.cold>:
    3710:	e8 9b fc ff ff       	call   33b0 <abort@plt>
    3715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    371c:	00 00 00 
    371f:	90                   	nop

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 e1 ab 00 00 	lea    0xabe1(%rip),%rax        # e320 <fwp_fn_table>
    373f:	48 89 05 d2 ec 01 00 	mov    %rax,0x1ecd2(%rip)        # 22418 <fwp_fns>
    3746:	48 8b 05 d3 c8 00 00 	mov    0xc8d3(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 cc ec 01 00 	mov    %rax,0x1eccc(%rip)        # 22420 <fwp_prog_out>
    3754:	e8 c7 0d 00 00       	call   4520 <fwp_now_ns>
    3759:	48 8d 3d f7 8a 00 00 	lea    0x8af7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 c8 00 00 	mov    0xc858(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 df 5f 00 00 	lea    0x5fdf(%rip),%rdx        # 9800 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 d6 fe ff ff    	jne    3710 <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 ba fe ff ff    	jne    3710 <main.cold>
    3856:	48 8b 3d c3 c7 00 00 	mov    0xc7c3(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 c8 01 00    	mov    0x1c818(%rip),%eax        # 20080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d a7 89 00 00 	lea    0x89a7(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38b9:	e8 f2 0a 00 00       	call   43b0 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d c6 91 00 00 	lea    0x91c6(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    38ca:	e8 e1 0a 00 00       	call   43b0 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 2f fe ff ff    	jne    3710 <main.cold>
    38e1:	48 8d 3d 80 91 00 00 	lea    0x9180(%rip),%rdi        # ca68 <_IO_stdin_used+0xa68>
    38e8:	e8 c3 0a 00 00       	call   43b0 <fwp_trap>
    38ed:	48 8d 3d 44 91 00 00 	lea    0x9144(%rip),%rdi        # ca38 <_IO_stdin_used+0xa38>
    38f4:	e8 b7 0a 00 00       	call   43b0 <fwp_trap>
    38f9:	48 8d 3d 10 91 00 00 	lea    0x9110(%rip),%rdi        # ca10 <_IO_stdin_used+0xa10>
    3900:	e8 ab 0a 00 00       	call   43b0 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 9b c6 00 00    	call   *0xc69b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d9 c6 00 00 	lea    0xc6d9(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3947:	48 8d 05 d2 c6 00 00 	lea    0xc6d2(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 7e c6 00 00 	mov    0xc67e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a9 c6 00 00 	lea    0xc6a9(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3977:	48 8d 35 a2 c6 00 00 	lea    0xc6a2(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 4d c6 00 00 	mov    0xc64d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d c6 00 00 00 	cmpb   $0x0,0xc68d(%rip)        # 10048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 2a c6 00 00 	cmpq   $0x0,0xc62a(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 c6 00 00 	mov    0xc636(%rip),%rdi        # 10008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 c6 00 00 01 	movb   $0x1,0xc665(%rip)        # 10048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_tape_unlink_scope>:
    3bc0:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3bc4:	48 85 d2             	test   %rdx,%rdx
    3bc7:	74 3e                	je     3c07 <fwp_tape_unlink_scope+0x47>
    3bc9:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3bcc:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3bd0:	85 c9                	test   %ecx,%ecx
    3bd2:	78 3c                	js     3c10 <fwp_tape_unlink_scope+0x50>
    3bd4:	48 63 d1             	movslq %ecx,%rdx
    3bd7:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3bdb:	48 03 15 fe c4 01 00 	add    0x1c4fe(%rip),%rdx        # 200e0 <fwp_tapes>
    3be2:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3be5:	85 c0                	test   %eax,%eax
    3be7:	78 0e                	js     3bf7 <fwp_tape_unlink_scope+0x37>
    3be9:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3bed:	48 03 05 ec c4 01 00 	add    0x1c4ec(%rip),%rax        # 200e0 <fwp_tapes>
    3bf4:	89 48 48             	mov    %ecx,0x48(%rax)
    3bf7:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3bfe:	00 
    3bff:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c06:	ff 
    3c07:	c3                   	ret
    3c08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c0f:	00 
    3c10:	89 02                	mov    %eax,(%rdx)
    3c12:	eb d1                	jmp    3be5 <fwp_tape_unlink_scope+0x25>
    3c14:	90                   	nop
    3c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c1c:	00 00 00 00 

0000000000003c20 <fwp_args173>:
    3c20:	f3 0f 1e fa          	endbr64
    3c24:	c3                   	ret
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_flush>:
    3c30:	48 8b 3d e9 e7 01 00 	mov    0x1e7e9(%rip),%rdi        # 22420 <fwp_prog_out>
    3c37:	48 85 ff             	test   %rdi,%rdi
    3c3a:	74 1c                	je     3c58 <fwp_flush+0x28>
    3c3c:	48 83 ec 08          	sub    $0x8,%rsp
    3c40:	e8 4b f9 ff ff       	call   3590 <fflush@plt>
    3c45:	48 8b 3d d4 c3 00 00 	mov    0xc3d4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c4c:	48 83 c4 08          	add    $0x8,%rsp
    3c50:	e9 3b f9 ff ff       	jmp    3590 <fflush@plt>
    3c55:	0f 1f 00             	nopl   (%rax)
    3c58:	48 8b 3d c1 c3 00 00 	mov    0xc3c1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c5f:	e9 2c f9 ff ff       	jmp    3590 <fflush@plt>
    3c64:	90                   	nop
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_heap_oom>:
    3c70:	50                   	push   %rax
    3c71:	58                   	pop    %rax
    3c72:	ba 13 00 00 00       	mov    $0x13,%edx
    3c77:	be 01 00 00 00       	mov    $0x1,%esi
    3c7c:	48 8d 3d 85 83 00 00 	lea    0x8385(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3c83:	48 83 ec 08          	sub    $0x8,%rsp
    3c87:	48 8b 0d b2 c3 00 00 	mov    0xc3b2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3c8e:	e8 ad f9 ff ff       	call   3640 <fwrite@plt>
    3c93:	31 ff                	xor    %edi,%edi
    3c95:	e8 f6 f8 ff ff       	call   3590 <fflush@plt>
    3c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    3c9f:	e8 bc f9 ff ff       	call   3660 <_Exit@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_segv>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	48 83 ec 28          	sub    $0x28,%rsp
    3cb8:	48 8b 05 e1 ca 01 00 	mov    0x1cae1(%rip),%rax        # 207a0 <fwp_cur>
    3cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3cc3:	41 89 f8             	mov    %edi,%r8d
    3cc6:	48 85 c0             	test   %rax,%rax
    3cc9:	74 6d                	je     3d38 <fwp_segv+0x88>
    3ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3ccf:	48 85 d2             	test   %rdx,%rdx
    3cd2:	74 64                	je     3d38 <fwp_segv+0x88>
    3cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3ce7:	e8 14 f9 ff ff       	call   3600 <sysconf@plt>
    3cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3cfb:	48 01 d0             	add    %rdx,%rax
    3cfe:	48 39 c1             	cmp    %rax,%rcx
    3d01:	b8 00 00 00 00       	mov    $0x0,%eax
    3d06:	40 0f 92 c6          	setb   %sil
    3d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d15:	31 c0                	xor    %eax,%eax
    3d17:	48 39 d1             	cmp    %rdx,%rcx
    3d1a:	0f 93 c0             	setae  %al
    3d1d:	21 f0                	and    %esi,%eax
    3d1f:	85 c0                	test   %eax,%eax
    3d21:	75 4a                	jne    3d6d <fwp_segv+0xbd>
    3d23:	31 f6                	xor    %esi,%esi
    3d25:	44 89 c7             	mov    %r8d,%edi
    3d28:	48 83 c4 28          	add    $0x28,%rsp
    3d2c:	e9 ef f7 ff ff       	jmp    3520 <signal@plt>
    3d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d38:	48 8b 05 19 c4 01 00 	mov    0x1c419(%rip),%rax        # 20158 <fwp_main_stack_top>
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	74 df                	je     3d23 <fwp_segv+0x73>
    3d44:	48 2b 05 05 c4 01 00 	sub    0x1c405(%rip),%rax        # 20150 <fwp_main_stack_size>
    3d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d52:	48 39 d1             	cmp    %rdx,%rcx
    3d55:	0f 93 c2             	setae  %dl
    3d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d5e:	48 39 c1             	cmp    %rax,%rcx
    3d61:	0f 92 c0             	setb   %al
    3d64:	0f b6 c0             	movzbl %al,%eax
    3d67:	21 d0                	and    %edx,%eax
    3d69:	85 c0                	test   %eax,%eax
    3d6b:	74 b6                	je     3d23 <fwp_segv+0x73>
    3d6d:	e8 be fe ff ff       	call   3c30 <fwp_flush>
    3d72:	bf 02 00 00 00       	mov    $0x2,%edi
    3d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3d7c:	48 8d 35 ed 8d 00 00 	lea    0x8ded(%rip),%rsi        # cb70 <msg.4>
    3d83:	e8 88 f6 ff ff       	call   3410 <write@plt>
    3d88:	bf 65 00 00 00       	mov    $0x65,%edi
    3d8d:	e8 2e f6 ff ff       	call   33c0 <_exit@plt>
    3d92:	0f 1f 00             	nopl   (%rax)
    3d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d9c:	00 00 00 00 

0000000000003da0 <descent_phase_fail>:
    3da0:	50                   	push   %rax
    3da1:	58                   	pop    %rax
    3da2:	48 8d 3d c7 88 00 00 	lea    0x88c7(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    3da9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dae:	be 01 00 00 00       	mov    $0x1,%esi
    3db3:	48 83 ec 08          	sub    $0x8,%rsp
    3db7:	48 8b 0d 82 c2 00 00 	mov    0xc282(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dbe:	e8 7d f8 ff ff       	call   3640 <fwrite@plt>
    3dc3:	bf e9 00 00 00       	mov    $0xe9,%edi
    3dc8:	e8 93 f8 ff ff       	call   3660 <_Exit@plt>
    3dcd:	0f 1f 00             	nopl   (%rax)

0000000000003dd0 <descent_phase_report>:
    3dd0:	f3 0f 1e fa          	endbr64
    3dd4:	41 54                	push   %r12
    3dd6:	55                   	push   %rbp
    3dd7:	53                   	push   %rbx
    3dd8:	48 83 ec 40          	sub    $0x40,%rsp
    3ddc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3de3:	00 00 
    3de5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3dea:	31 c0                	xor    %eax,%eax
    3dec:	83 3d 25 c2 00 00 ff 	cmpl   $0xffffffff,0xc225(%rip)        # 10018 <descent_active_phase>
    3df3:	0f 85 32 01 00 00    	jne    3f2b <descent_phase_report+0x15b>
    3df9:	48 8d 05 22 82 00 00 	lea    0x8222(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e00:	4c 8b 0d f1 c2 01 00 	mov    0x1c2f1(%rip),%r9        # 200f8 <descent_nodes>
    3e07:	31 db                	xor    %ebx,%ebx
    3e09:	f3 0f 7e 05 ff bd 00 	movq   0xbdff(%rip),%xmm0        # fc10 <d0+0x70>
    3e10:	00 
    3e11:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e16:	48 8d 05 27 82 00 00 	lea    0x8227(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e1d:	4c 8b 05 cc c2 01 00 	mov    0x1c2cc(%rip),%r8        # 200f0 <descent_inputs>
    3e24:	48 8b 0d d5 c2 01 00 	mov    0x1c2d5(%rip),%rcx        # 20100 <descent_updates>
    3e2b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e2f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e34:	48 89 e5             	mov    %rsp,%rbp
    3e37:	48 8b 3d 02 c2 00 00 	mov    0xc202(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e3e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e42:	48 8d 05 18 82 00 00 	lea    0x8218(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e49:	f3 0f 7e 05 c7 bd 00 	movq   0xbdc7(%rip),%xmm0        # fc18 <d0+0x78>
    3e50:	00 
    3e51:	48 8d 15 60 88 00 00 	lea    0x8860(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    3e58:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e5d:	be 02 00 00 00       	mov    $0x2,%esi
    3e62:	31 c0                	xor    %eax,%eax
    3e64:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3e68:	4c 8d 25 b1 c2 01 00 	lea    0x1c2b1(%rip),%r12        # 20120 <descent_phase_ns>
    3e6f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3e74:	f3 0f 7e 05 a4 bd 00 	movq   0xbda4(%rip),%xmm0        # fc20 <d0+0x80>
    3e7b:	00 
    3e7c:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3e80:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3e85:	e8 c6 f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3e90:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3e94:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3e99:	48 85 db             	test   %rbx,%rbx
    3e9c:	74 62                	je     3f00 <descent_phase_report+0x130>
    3e9e:	48 8b 3d 9b c1 00 00 	mov    0xc19b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ea5:	be 02 00 00 00       	mov    $0x2,%esi
    3eaa:	31 c0                	xor    %eax,%eax
    3eac:	48 83 c3 01          	add    $0x1,%rbx
    3eb0:	48 8d 0d b5 81 00 00 	lea    0x81b5(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3eb7:	48 8d 15 b0 81 00 00 	lea    0x81b0(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3ebe:	e8 8d f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3ec3:	48 83 fb 06          	cmp    $0x6,%rbx
    3ec7:	75 c7                	jne    3e90 <descent_phase_report+0xc0>
    3ec9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3ece:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ed5:	00 00 
    3ed7:	75 57                	jne    3f30 <descent_phase_report+0x160>
    3ed9:	48 8b 0d 60 c1 00 00 	mov    0xc160(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3ee0:	48 83 c4 40          	add    $0x40,%rsp
    3ee4:	ba 04 00 00 00       	mov    $0x4,%edx
    3ee9:	be 01 00 00 00       	mov    $0x1,%esi
    3eee:	5b                   	pop    %rbx
    3eef:	48 8d 3d 84 81 00 00 	lea    0x8184(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3ef6:	5d                   	pop    %rbp
    3ef7:	41 5c                	pop    %r12
    3ef9:	e9 42 f7 ff ff       	jmp    3640 <fwrite@plt>
    3efe:	66 90                	xchg   %ax,%ax
    3f00:	48 8b 3d 39 c1 00 00 	mov    0xc139(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f07:	48 8d 0d 83 81 00 00 	lea    0x8183(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f0e:	48 8d 15 59 81 00 00 	lea    0x8159(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f15:	31 c0                	xor    %eax,%eax
    3f17:	be 02 00 00 00       	mov    $0x2,%esi
    3f1c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f21:	e8 2a f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3f26:	e9 65 ff ff ff       	jmp    3e90 <descent_phase_report+0xc0>
    3f2b:	e8 70 fe ff ff       	call   3da0 <descent_phase_fail>
    3f30:	e8 0b f5 ff ff       	call   3440 <__stack_chk_fail@plt>
    3f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f3c:	00 00 00 00 

0000000000003f40 <fwp_heap_chunks>:
    3f40:	41 54                	push   %r12
    3f42:	55                   	push   %rbp
    3f43:	53                   	push   %rbx
    3f44:	48 83 ff 01          	cmp    $0x1,%rdi
    3f48:	0f 84 62 01 00 00    	je     40b0 <fwp_heap_chunks+0x170>
    3f4e:	48 8b 05 5b dc 01 00 	mov    0x1dc5b(%rip),%rax        # 21bb0 <fwp_heap+0x13f0>
    3f55:	4c 8d 05 54 dc 01 00 	lea    0x1dc54(%rip),%r8        # 21bb0 <fwp_heap+0x13f0>
    3f5c:	48 8b 1d 35 dc 01 00 	mov    0x1dc35(%rip),%rbx        # 21b98 <fwp_heap+0x13d8>
    3f63:	48 39 d8             	cmp    %rbx,%rax
    3f66:	0f 83 57 01 00 00    	jae    40c3 <fwp_heap_chunks+0x183>
    3f6c:	48 8b 0d 45 dc 01 00 	mov    0x1dc45(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    3f73:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f77:	31 f6                	xor    %esi,%esi
    3f79:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3f7d:	eb 1e                	jmp    3f9d <fwp_heap_chunks+0x5d>
    3f7f:	90                   	nop
    3f80:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3f84:	48 39 cf             	cmp    %rcx,%rdi
    3f87:	0f 84 03 01 00 00    	je     4090 <fwp_heap_chunks+0x150>
    3f8d:	48 83 c0 01          	add    $0x1,%rax
    3f91:	48 89 ce             	mov    %rcx,%rsi
    3f94:	48 83 c2 28          	add    $0x28,%rdx
    3f98:	48 39 c3             	cmp    %rax,%rbx
    3f9b:	74 14                	je     3fb1 <fwp_heap_chunks+0x71>
    3f9d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fa0:	74 de                	je     3f80 <fwp_heap_chunks+0x40>
    3fa2:	48 83 c0 01          	add    $0x1,%rax
    3fa6:	31 f6                	xor    %esi,%esi
    3fa8:	48 83 c2 28          	add    $0x28,%rdx
    3fac:	48 39 c3             	cmp    %rax,%rbx
    3faf:	75 ec                	jne    3f9d <fwp_heap_chunks+0x5d>
    3fb1:	48 29 f3             	sub    %rsi,%rbx
    3fb4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3fb8:	48 8b 3d e1 db 01 00 	mov    0x1dbe1(%rip),%rdi        # 21ba0 <fwp_heap+0x13e0>
    3fbf:	48 29 35 2a dc 01 00 	sub    %rsi,0x1dc2a(%rip)        # 21bf0 <fwp_heap+0x1430>
    3fc6:	48 39 ef             	cmp    %rbp,%rdi
    3fc9:	0f 83 96 00 00 00    	jae    4065 <fwp_heap_chunks+0x125>
    3fcf:	48 8b 05 ba db 01 00 	mov    0x1dbba(%rip),%rax        # 21b90 <fwp_heap+0x13d0>
    3fd6:	48 39 e8             	cmp    %rbp,%rax
    3fd9:	0f 82 eb 00 00 00    	jb     40ca <fwp_heap_chunks+0x18a>
    3fdf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3fe3:	ba 03 00 00 00       	mov    $0x3,%edx
    3fe8:	49 39 c4             	cmp    %rax,%r12
    3feb:	4c 0f 47 e0          	cmova  %rax,%r12
    3fef:	4c 89 e6             	mov    %r12,%rsi
    3ff2:	48 29 fe             	sub    %rdi,%rsi
    3ff5:	48 c1 e7 10          	shl    $0x10,%rdi
    3ff9:	48 03 3d 70 db 01 00 	add    0x1db70(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    4000:	48 c1 e6 10          	shl    $0x10,%rsi
    4004:	e8 d7 f5 ff ff       	call   35e0 <mprotect@plt>
    4009:	85 c0                	test   %eax,%eax
    400b:	0f 85 b9 00 00 00    	jne    40ca <fwp_heap_chunks+0x18a>
    4011:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4016:	e8 e5 f5 ff ff       	call   3600 <sysconf@plt>
    401b:	48 8b 35 7e db 01 00 	mov    0x1db7e(%rip),%rsi        # 21ba0 <fwp_heap+0x13e0>
    4022:	48 89 c1             	mov    %rax,%rcx
    4025:	48 8b 05 8c db 01 00 	mov    0x1db8c(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    402c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4030:	48 89 ca             	mov    %rcx,%rdx
    4033:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4037:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    403b:	48 f7 da             	neg    %rdx
    403e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4043:	48 21 d7             	and    %rdx,%rdi
    4046:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    404a:	48 21 d6             	and    %rdx,%rsi
    404d:	ba 03 00 00 00       	mov    $0x3,%edx
    4052:	48 29 fe             	sub    %rdi,%rsi
    4055:	e8 86 f5 ff ff       	call   35e0 <mprotect@plt>
    405a:	85 c0                	test   %eax,%eax
    405c:	75 6c                	jne    40ca <fwp_heap_chunks+0x18a>
    405e:	4c 89 25 3b db 01 00 	mov    %r12,0x1db3b(%rip)        # 21ba0 <fwp_heap+0x13e0>
    4065:	48 89 ef             	mov    %rbp,%rdi
    4068:	48 89 2d 29 db 01 00 	mov    %rbp,0x1db29(%rip)        # 21b98 <fwp_heap+0x13d8>
    406f:	48 c1 e7 10          	shl    $0x10,%rdi
    4073:	48 39 3d 0e db 01 00 	cmp    %rdi,0x1db0e(%rip)        # 21b88 <fwp_heap+0x13c8>
    407a:	73 07                	jae    4083 <fwp_heap_chunks+0x143>
    407c:	48 89 3d 05 db 01 00 	mov    %rdi,0x1db05(%rip)        # 21b88 <fwp_heap+0x13c8>
    4083:	48 89 d8             	mov    %rbx,%rax
    4086:	5b                   	pop    %rbx
    4087:	5d                   	pop    %rbp
    4088:	41 5c                	pop    %r12
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 8d 50 01          	lea    0x1(%rax),%rdx
    4094:	48 29 f0             	sub    %rsi,%rax
    4097:	48 89 c3             	mov    %rax,%rbx
    409a:	49 89 10             	mov    %rdx,(%r8)
    409d:	48 89 d8             	mov    %rbx,%rax
    40a0:	48 29 3d 49 db 01 00 	sub    %rdi,0x1db49(%rip)        # 21bf0 <fwp_heap+0x1430>
    40a7:	5b                   	pop    %rbx
    40a8:	5d                   	pop    %rbp
    40a9:	41 5c                	pop    %r12
    40ab:	c3                   	ret
    40ac:	0f 1f 40 00          	nopl   0x0(%rax)
    40b0:	48 8b 05 f1 da 01 00 	mov    0x1daf1(%rip),%rax        # 21ba8 <fwp_heap+0x13e8>
    40b7:	4c 8d 05 ea da 01 00 	lea    0x1daea(%rip),%r8        # 21ba8 <fwp_heap+0x13e8>
    40be:	e9 99 fe ff ff       	jmp    3f5c <fwp_heap_chunks+0x1c>
    40c3:	31 f6                	xor    %esi,%esi
    40c5:	e9 ea fe ff ff       	jmp    3fb4 <fwp_heap_chunks+0x74>
    40ca:	e8 a1 fb ff ff       	call   3c70 <fwp_heap_oom>
    40cf:	90                   	nop

00000000000040d0 <fwp_tape_buffers_dispose>:
    40d0:	53                   	push   %rbx
    40d1:	48 89 fb             	mov    %rdi,%rbx
    40d4:	48 8b 3f             	mov    (%rdi),%rdi
    40d7:	e8 c4 f2 ff ff       	call   33a0 <free@plt>
    40dc:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    40e0:	e8 bb f2 ff ff       	call   33a0 <free@plt>
    40e5:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    40e9:	e8 b2 f2 ff ff       	call   33a0 <free@plt>
    40ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40f2:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    40f9:	00 
    40fa:	0f 11 03             	movups %xmm0,(%rbx)
    40fd:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4101:	5b                   	pop    %rbx
    4102:	c3                   	ret
    4103:	66 90                	xchg   %ax,%ax
    4105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    410c:	00 00 00 00 

0000000000004110 <buf_grow>:
    4110:	48 83 ec 18          	sub    $0x18,%rsp
    4114:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4118:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    411c:	74 7e                	je     419c <buf_grow+0x8c>
    411e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4125:	48 29 c2             	sub    %rax,%rdx
    4128:	48 39 f2             	cmp    %rsi,%rdx
    412b:	72 6f                	jb     419c <buf_grow+0x8c>
    412d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4132:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4136:	48 89 f9             	mov    %rdi,%rcx
    4139:	48 39 d0             	cmp    %rdx,%rax
    413c:	73 48                	jae    4186 <buf_grow+0x76>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	75 15                	jne    4158 <buf_grow+0x48>
    4143:	48 83 fa 40          	cmp    $0x40,%rdx
    4147:	76 4c                	jbe    4195 <buf_grow+0x85>
    4149:	b8 40 00 00 00       	mov    $0x40,%eax
    414e:	eb 08                	jmp    4158 <buf_grow+0x48>
    4150:	48 01 c0             	add    %rax,%rax
    4153:	48 39 d0             	cmp    %rdx,%rax
    4156:	73 38                	jae    4190 <buf_grow+0x80>
    4158:	48 85 c0             	test   %rax,%rax
    415b:	79 f3                	jns    4150 <buf_grow+0x40>
    415d:	48 8b 39             	mov    (%rcx),%rdi
    4160:	48 89 d6             	mov    %rdx,%rsi
    4163:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4168:	48 89 14 24          	mov    %rdx,(%rsp)
    416c:	e8 2f f4 ff ff       	call   35a0 <realloc@plt>
    4171:	48 8b 14 24          	mov    (%rsp),%rdx
    4175:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    417a:	48 85 c0             	test   %rax,%rax
    417d:	74 1d                	je     419c <buf_grow+0x8c>
    417f:	48 89 01             	mov    %rax,(%rcx)
    4182:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4186:	48 83 c4 18          	add    $0x18,%rsp
    418a:	c3                   	ret
    418b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4190:	48 89 c2             	mov    %rax,%rdx
    4193:	eb c8                	jmp    415d <buf_grow+0x4d>
    4195:	ba 40 00 00 00       	mov    $0x40,%edx
    419a:	eb c1                	jmp    415d <buf_grow+0x4d>
    419c:	48 8b 0d 9d be 00 00 	mov    0xbe9d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41a3:	ba 13 00 00 00       	mov    $0x13,%edx
    41a8:	be 01 00 00 00       	mov    $0x1,%esi
    41ad:	48 8d 3d 54 7e 00 00 	lea    0x7e54(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41b4:	e8 87 f4 ff ff       	call   3640 <fwrite@plt>
    41b9:	31 ff                	xor    %edi,%edi
    41bb:	e8 d0 f3 ff ff       	call   3590 <fflush@plt>
    41c0:	bf 66 00 00 00       	mov    $0x66,%edi
    41c5:	e8 96 f4 ff ff       	call   3660 <_Exit@plt>
    41ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041d0 <buf_put>:
    41d0:	41 54                	push   %r12
    41d2:	49 89 f4             	mov    %rsi,%r12
    41d5:	48 89 d6             	mov    %rdx,%rsi
    41d8:	55                   	push   %rbp
    41d9:	48 89 fd             	mov    %rdi,%rbp
    41dc:	53                   	push   %rbx
    41dd:	48 89 d3             	mov    %rdx,%rbx
    41e0:	e8 2b ff ff ff       	call   4110 <buf_grow>
    41e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    41e9:	48 89 da             	mov    %rbx,%rdx
    41ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    41f0:	4c 89 e6             	mov    %r12,%rsi
    41f3:	e8 78 f3 ff ff       	call   3570 <memcpy@plt>
    41f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    41fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4200:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4204:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4208:	5b                   	pop    %rbx
    4209:	5d                   	pop    %rbp
    420a:	41 5c                	pop    %r12
    420c:	c3                   	ret
    420d:	0f 1f 00             	nopl   (%rax)

0000000000004210 <descent_phase_step>:
    4210:	55                   	push   %rbp
    4211:	53                   	push   %rbx
    4212:	48 83 ec 28          	sub    $0x28,%rsp
    4216:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    421d:	00 00 
    421f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4224:	48 63 2d ed bd 00 00 	movslq 0xbded(%rip),%rbp        # 10018 <descent_active_phase>
    422b:	8d 45 01             	lea    0x1(%rbp),%eax
    422e:	39 f8                	cmp    %edi,%eax
    4230:	75 7c                	jne    42ae <descent_phase_step+0x9e>
    4232:	89 fb                	mov    %edi,%ebx
    4234:	48 89 e6             	mov    %rsp,%rsi
    4237:	bf 01 00 00 00       	mov    $0x1,%edi
    423c:	e8 bf f1 ff ff       	call   3400 <clock_gettime@plt>
    4241:	85 c0                	test   %eax,%eax
    4243:	75 69                	jne    42ae <descent_phase_step+0x9e>
    4245:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    424c:	3b 
    424d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4252:	83 fd ff             	cmp    $0xffffffff,%ebp
    4255:	74 21                	je     4278 <descent_phase_step+0x68>
    4257:	48 8b 35 aa be 01 00 	mov    0x1beaa(%rip),%rsi        # 20108 <descent_last_ns>
    425e:	48 39 f0             	cmp    %rsi,%rax
    4261:	72 4b                	jb     42ae <descent_phase_step+0x9e>
    4263:	48 8d 0d b6 be 01 00 	lea    0x1beb6(%rip),%rcx        # 20120 <descent_phase_ns>
    426a:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    426e:	48 29 f2             	sub    %rsi,%rdx
    4271:	48 01 c2             	add    %rax,%rdx
    4274:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    4278:	83 fb 06             	cmp    $0x6,%ebx
    427b:	75 0d                	jne    428a <descent_phase_step+0x7a>
    427d:	48 83 05 7b be 01 00 	addq   $0x1,0x1be7b(%rip)        # 20100 <descent_updates>
    4284:	01 
    4285:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    428a:	89 1d 88 bd 00 00    	mov    %ebx,0xbd88(%rip)        # 10018 <descent_active_phase>
    4290:	48 89 05 71 be 01 00 	mov    %rax,0x1be71(%rip)        # 20108 <descent_last_ns>
    4297:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    429c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42a3:	00 00 
    42a5:	75 0c                	jne    42b3 <descent_phase_step+0xa3>
    42a7:	48 83 c4 28          	add    $0x28,%rsp
    42ab:	5b                   	pop    %rbx
    42ac:	5d                   	pop    %rbp
    42ad:	c3                   	ret
    42ae:	e8 ed fa ff ff       	call   3da0 <descent_phase_fail>
    42b3:	e8 88 f1 ff ff       	call   3440 <__stack_chk_fail@plt>
    42b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42bf:	00 

00000000000042c0 <fwp_cancel_tree.part.0>:
    42c0:	48 3b 3d d9 c4 01 00 	cmp    0x1c4d9(%rip),%rdi        # 207a0 <fwp_cur>
    42c7:	53                   	push   %rbx
    42c8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    42cc:	74 35                	je     4303 <fwp_cancel_tree.part.0+0x43>
    42ce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    42d2:	75 2f                	jne    4303 <fwp_cancel_tree.part.0+0x43>
    42d4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    42d8:	75 29                	jne    4303 <fwp_cancel_tree.part.0+0x43>
    42da:	48 8b 05 9f c4 01 00 	mov    0x1c49f(%rip),%rax        # 20780 <fwp_ready_tail>
    42e1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    42e5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    42ec:	00 00 00 00 
    42f0:	48 85 c0             	test   %rax,%rax
    42f3:	74 33                	je     4328 <fwp_cancel_tree.part.0+0x68>
    42f5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    42fc:	48 89 3d 7d c4 01 00 	mov    %rdi,0x1c47d(%rip)        # 20780 <fwp_ready_tail>
    4303:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4307:	48 85 db             	test   %rbx,%rbx
    430a:	74 17                	je     4323 <fwp_cancel_tree.part.0+0x63>
    430c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4310:	75 08                	jne    431a <fwp_cancel_tree.part.0+0x5a>
    4312:	48 89 df             	mov    %rbx,%rdi
    4315:	e8 a6 ff ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    431a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    431e:	48 85 db             	test   %rbx,%rbx
    4321:	75 e9                	jne    430c <fwp_cancel_tree.part.0+0x4c>
    4323:	5b                   	pop    %rbx
    4324:	c3                   	ret
    4325:	0f 1f 00             	nopl   (%rax)
    4328:	48 89 3d 59 c4 01 00 	mov    %rdi,0x1c459(%rip)        # 20788 <fwp_ready_head>
    432f:	eb cb                	jmp    42fc <fwp_cancel_tree.part.0+0x3c>
    4331:	0f 1f 40 00          	nopl   0x0(%rax)
    4335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    433c:	00 00 00 00 

0000000000004340 <fwp_finish_float>:
    4340:	53                   	push   %rbx
    4341:	be 2e 00 00 00       	mov    $0x2e,%esi
    4346:	48 89 fb             	mov    %rdi,%rbx
    4349:	e8 12 f1 ff ff       	call   3460 <strchr@plt>
    434e:	48 85 c0             	test   %rax,%rax
    4351:	74 05                	je     4358 <fwp_finish_float+0x18>
    4353:	5b                   	pop    %rbx
    4354:	c3                   	ret
    4355:	0f 1f 00             	nopl   (%rax)
    4358:	be 65 00 00 00       	mov    $0x65,%esi
    435d:	48 89 df             	mov    %rbx,%rdi
    4360:	e8 fb f0 ff ff       	call   3460 <strchr@plt>
    4365:	48 85 c0             	test   %rax,%rax
    4368:	75 e9                	jne    4353 <fwp_finish_float+0x13>
    436a:	48 8d 35 2e 7e 00 00 	lea    0x7e2e(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    4371:	48 89 df             	mov    %rbx,%rdi
    4374:	e8 17 f3 ff ff       	call   3690 <strstr@plt>
    4379:	48 85 c0             	test   %rax,%rax
    437c:	75 d5                	jne    4353 <fwp_finish_float+0x13>
    437e:	48 8d 35 fa 7c 00 00 	lea    0x7cfa(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    4385:	48 89 df             	mov    %rbx,%rdi
    4388:	e8 03 f3 ff ff       	call   3690 <strstr@plt>
    438d:	48 85 c0             	test   %rax,%rax
    4390:	75 c1                	jne    4353 <fwp_finish_float+0x13>
    4392:	48 89 df             	mov    %rbx,%rdi
    4395:	e8 96 f0 ff ff       	call   3430 <strlen@plt>
    439a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    439f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43a8:	5b                   	pop    %rbx
    43a9:	c3                   	ret
    43aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043b0 <fwp_trap>:
    43b0:	55                   	push   %rbp
    43b1:	48 89 fd             	mov    %rdi,%rbp
    43b4:	53                   	push   %rbx
    43b5:	48 83 ec 08          	sub    $0x8,%rsp
    43b9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    43c0:	ff ff 
    43c2:	e8 69 f8 ff ff       	call   3c30 <fwp_flush>
    43c7:	31 c0                	xor    %eax,%eax
    43c9:	48 89 e9             	mov    %rbp,%rcx
    43cc:	be 02 00 00 00       	mov    $0x2,%esi
    43d1:	48 8b 3d 68 bc 00 00 	mov    0xbc68(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43d8:	48 8d 15 a4 7c 00 00 	lea    0x7ca4(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    43df:	e8 6c f2 ff ff       	call   3650 <__fprintf_chk@plt>
    43e4:	48 85 db             	test   %rbx,%rbx
    43e7:	74 16                	je     43ff <fwp_trap+0x4f>
    43e9:	48 8b 3d 50 bc 00 00 	mov    0xbc50(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43f0:	e8 9b f1 ff ff       	call   3590 <fflush@plt>
    43f5:	bf 65 00 00 00       	mov    $0x65,%edi
    43fa:	e8 61 f2 ff ff       	call   3660 <_Exit@plt>
    43ff:	bf 65 00 00 00       	mov    $0x65,%edi
    4404:	e8 27 f2 ff ff       	call   3630 <exit@plt>
    4409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004410 <fwp_closure_drop_push>:
    4410:	41 56                	push   %r14
    4412:	41 54                	push   %r12
    4414:	49 89 f4             	mov    %rsi,%r12
    4417:	55                   	push   %rbp
    4418:	48 89 fd             	mov    %rdi,%rbp
    441b:	53                   	push   %rbx
    441c:	48 83 ec 18          	sub    $0x18,%rsp
    4420:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4424:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4428:	74 26                	je     4450 <fwp_closure_drop_push+0x40>
    442a:	4c 8b 07             	mov    (%rdi),%r8
    442d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4434:	00 
    4435:	48 83 c3 01          	add    $0x1,%rbx
    4439:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    443d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4441:	48 83 c4 18          	add    $0x18,%rsp
    4445:	5b                   	pop    %rbx
    4446:	5d                   	pop    %rbp
    4447:	41 5c                	pop    %r12
    4449:	41 5e                	pop    %r14
    444b:	c3                   	ret
    444c:	0f 1f 40 00          	nopl   0x0(%rax)
    4450:	48 89 d8             	mov    %rbx,%rax
    4453:	48 c1 e8 3c          	shr    $0x3c,%rax
    4457:	0f 85 a9 00 00 00    	jne    4506 <fwp_closure_drop_push+0xf6>
    445d:	48 89 d9             	mov    %rbx,%rcx
    4460:	48 c1 e1 04          	shl    $0x4,%rcx
    4464:	48 89 cf             	mov    %rcx,%rdi
    4467:	48 89 0c 24          	mov    %rcx,(%rsp)
    446b:	e8 10 f1 ff ff       	call   3580 <malloc@plt>
    4470:	48 8b 0c 24          	mov    (%rsp),%rcx
    4474:	48 85 c0             	test   %rax,%rax
    4477:	74 5f                	je     44d8 <fwp_closure_drop_push+0xc8>
    4479:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    447d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4484:	00 
    4485:	48 89 c7             	mov    %rax,%rdi
    4488:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    448c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4491:	48 89 34 24          	mov    %rsi,(%rsp)
    4495:	e8 a6 f0 ff ff       	call   3540 <__memcpy_chk@plt>
    449a:	48 8b 34 24          	mov    (%rsp),%rsi
    449e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44a3:	49 89 c0             	mov    %rax,%r8
    44a6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44aa:	48 39 c6             	cmp    %rax,%rsi
    44ad:	74 1c                	je     44cb <fwp_closure_drop_push+0xbb>
    44af:	48 89 f7             	mov    %rsi,%rdi
    44b2:	4c 89 04 24          	mov    %r8,(%rsp)
    44b6:	e8 e5 ee ff ff       	call   33a0 <free@plt>
    44bb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44bf:	4c 8b 04 24          	mov    (%rsp),%r8
    44c3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44ca:	00 
    44cb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    44cf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    44d3:	e9 5d ff ff ff       	jmp    4435 <fwp_closure_drop_push+0x25>
    44d8:	48 8b 0d 61 bb 00 00 	mov    0xbb61(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    44df:	ba 13 00 00 00       	mov    $0x13,%edx
    44e4:	be 01 00 00 00       	mov    $0x1,%esi
    44e9:	48 8d 3d 18 7b 00 00 	lea    0x7b18(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    44f0:	e8 4b f1 ff ff       	call   3640 <fwrite@plt>
    44f5:	31 ff                	xor    %edi,%edi
    44f7:	e8 94 f0 ff ff       	call   3590 <fflush@plt>
    44fc:	bf 66 00 00 00       	mov    $0x66,%edi
    4501:	e8 5a f1 ff ff       	call   3660 <_Exit@plt>
    4506:	48 8d 3d 85 7b 00 00 	lea    0x7b85(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    450d:	e8 9e fe ff ff       	call   43b0 <fwp_trap>
    4512:	0f 1f 00             	nopl   (%rax)
    4515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    451c:	00 00 00 00 

0000000000004520 <fwp_now_ns>:
    4520:	53                   	push   %rbx
    4521:	bf 01 00 00 00       	mov    $0x1,%edi
    4526:	48 83 ec 20          	sub    $0x20,%rsp
    452a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4531:	00 00 
    4533:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4538:	31 db                	xor    %ebx,%ebx
    453a:	48 89 e6             	mov    %rsp,%rsi
    453d:	e8 be ee ff ff       	call   3400 <clock_gettime@plt>
    4542:	85 c0                	test   %eax,%eax
    4544:	75 52                	jne    4598 <fwp_now_ns+0x78>
    4546:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    454b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4550:	48 f7 2c 24          	imulq  (%rsp)
    4554:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    455b:	48 89 f7             	mov    %rsi,%rdi
    455e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4562:	48 01 f0             	add    %rsi,%rax
    4565:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    456c:	00 00 80 
    456f:	48 11 fa             	adc    %rdi,%rdx
    4572:	31 ff                	xor    %edi,%edi
    4574:	48 01 c6             	add    %rax,%rsi
    4577:	48 11 d7             	adc    %rdx,%rdi
    457a:	48 39 f1             	cmp    %rsi,%rcx
    457d:	48 19 fb             	sbb    %rdi,%rbx
    4580:	72 27                	jb     45a9 <fwp_now_ns+0x89>
    4582:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4587:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    458e:	00 00 
    4590:	75 12                	jne    45a4 <fwp_now_ns+0x84>
    4592:	48 83 c4 20          	add    $0x20,%rsp
    4596:	5b                   	pop    %rbx
    4597:	c3                   	ret
    4598:	48 8d 3d 0d 7b 00 00 	lea    0x7b0d(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    459f:	e8 0c fe ff ff       	call   43b0 <fwp_trap>
    45a4:	e8 97 ee ff ff       	call   3440 <__stack_chk_fail@plt>
    45a9:	48 8d 3d 58 81 00 00 	lea    0x8158(%rip),%rdi        # c708 <_IO_stdin_used+0x708>
    45b0:	e8 fb fd ff ff       	call   43b0 <fwp_trap>
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_closure_drop.part.0>:
    45c0:	53                   	push   %rbx
    45c1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    45c8:	66 0f 6f 05 e0 85 00 	movdqa 0x85e0(%rip),%xmm0        # cbb0 <msg.4+0x40>
    45cf:	00 
    45d0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    45d7:	00 00 
    45d9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    45e0:	00 
    45e1:	48 89 fe             	mov    %rdi,%rsi
    45e4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    45e9:	48 89 e7             	mov    %rsp,%rdi
    45ec:	48 89 1c 24          	mov    %rbx,(%rsp)
    45f0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    45f5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    45fc:	ff ff 
    45fe:	e8 0d fe ff ff       	call   4410 <fwp_closure_drop_push>
    4603:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4608:	48 85 c0             	test   %rax,%rax
    460b:	74 39                	je     4646 <fwp_closure_drop.part.0+0x86>
    460d:	0f 1f 00             	nopl   (%rax)
    4610:	48 8b 14 24          	mov    (%rsp),%rdx
    4614:	48 83 e8 01          	sub    $0x1,%rax
    4618:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    461d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4621:	8b 07                	mov    (%rdi),%eax
    4623:	48 c1 e0 05          	shl    $0x5,%rax
    4627:	48 03 05 ea dd 01 00 	add    0x1ddea(%rip),%rax        # 22418 <fwp_fns>
    462e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4632:	48 85 c0             	test   %rax,%rax
    4635:	74 46                	je     467d <fwp_closure_drop.part.0+0xbd>
    4637:	31 f6                	xor    %esi,%esi
    4639:	ff 50 08             	call   *0x8(%rax)
    463c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4641:	48 85 c0             	test   %rax,%rax
    4644:	75 ca                	jne    4610 <fwp_closure_drop.part.0+0x50>
    4646:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    464d:	ff ff 00 00 00 00 
    4653:	48 8b 3c 24          	mov    (%rsp),%rdi
    4657:	48 39 df             	cmp    %rbx,%rdi
    465a:	74 05                	je     4661 <fwp_closure_drop.part.0+0xa1>
    465c:	e8 3f ed ff ff       	call   33a0 <free@plt>
    4661:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4668:	00 
    4669:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4670:	00 00 
    4672:	75 15                	jne    4689 <fwp_closure_drop.part.0+0xc9>
    4674:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    467b:	5b                   	pop    %rbx
    467c:	c3                   	ret
    467d:	48 8d 3d ac 80 00 00 	lea    0x80ac(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    4684:	e8 27 fd ff ff       	call   43b0 <fwp_trap>
    4689:	e8 b2 ed ff ff       	call   3440 <__stack_chk_fail@plt>
    468e:	66 90                	xchg   %ax,%ax

0000000000004690 <fwp_tape_of>:
    4690:	0f b7 d7             	movzwl %di,%edx
    4693:	48 85 d2             	test   %rdx,%rdx
    4696:	74 28                	je     46c0 <fwp_tape_of+0x30>
    4698:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    469c:	48 39 05 35 ba 01 00 	cmp    %rax,0x1ba35(%rip)        # 200d8 <fwp_ntapes>
    46a3:	7e 1b                	jle    46c0 <fwp_tape_of+0x30>
    46a5:	48 6b c0 58          	imul   $0x58,%rax,%rax
    46a9:	48 03 05 30 ba 01 00 	add    0x1ba30(%rip),%rax        # 200e0 <fwp_tapes>
    46b0:	8b 50 04             	mov    0x4(%rax),%edx
    46b3:	85 d2                	test   %edx,%edx
    46b5:	74 09                	je     46c0 <fwp_tape_of+0x30>
    46b7:	48 c1 ff 10          	sar    $0x10,%rdi
    46bb:	39 38                	cmp    %edi,(%rax)
    46bd:	75 01                	jne    46c0 <fwp_tape_of+0x30>
    46bf:	c3                   	ret
    46c0:	48 83 ec 08          	sub    $0x8,%rsp
    46c4:	48 8d 3d 95 80 00 00 	lea    0x8095(%rip),%rdi        # c760 <_IO_stdin_used+0x760>
    46cb:	e8 e0 fc ff ff       	call   43b0 <fwp_trap>

00000000000046d0 <fwp_format_g.constprop.0>:
    46d0:	41 57                	push   %r15
    46d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    46d7:	ba 02 00 00 00       	mov    $0x2,%edx
    46dc:	4c 8d 05 e5 79 00 00 	lea    0x79e5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    46e3:	41 56                	push   %r14
    46e5:	b8 01 00 00 00       	mov    $0x1,%eax
    46ea:	41 55                	push   %r13
    46ec:	41 54                	push   %r12
    46ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    46f2:	55                   	push   %rbp
    46f3:	45 89 e1             	mov    %r12d,%r9d
    46f6:	53                   	push   %rbx
    46f7:	48 89 fb             	mov    %rdi,%rbx
    46fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4701:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4708:	00 00 
    470a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4711:	00 
    4712:	41 89 f7             	mov    %esi,%r15d
    4715:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    471a:	be 40 00 00 00       	mov    $0x40,%esi
    471f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4724:	4c 89 f7             	mov    %r14,%rdi
    4727:	e8 64 ec ff ff       	call   3390 <__snprintf_chk@plt>
    472c:	be 65 00 00 00       	mov    $0x65,%esi
    4731:	4c 89 f7             	mov    %r14,%rdi
    4734:	e8 27 ed ff ff       	call   3460 <strchr@plt>
    4739:	31 f6                	xor    %esi,%esi
    473b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4740:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4744:	48 89 c5             	mov    %rax,%rbp
    4747:	e8 14 ee ff ff       	call   3560 <strtol@plt>
    474c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4751:	49 89 c0             	mov    %rax,%r8
    4754:	83 c0 05             	add    $0x5,%eax
    4757:	83 f8 15             	cmp    $0x15,%eax
    475a:	0f 87 e0 01 00 00    	ja     4940 <fwp_format_g.constprop.0+0x270>
    4760:	45 89 e5             	mov    %r12d,%r13d
    4763:	45 29 c5             	sub    %r8d,%r13d
    4766:	45 85 ed             	test   %r13d,%r13d
    4769:	0f 8e 21 01 00 00    	jle    4890 <fwp_format_g.constprop.0+0x1c0>
    476f:	41 83 ff 01          	cmp    $0x1,%r15d
    4773:	0f 84 17 01 00 00    	je     4890 <fwp_format_g.constprop.0+0x1c0>
    4779:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    477e:	31 d2                	xor    %edx,%edx
    4780:	4d 63 df             	movslq %r15d,%r11
    4783:	3c 2d                	cmp    $0x2d,%al
    4785:	0f 94 c2             	sete   %dl
    4788:	4c 29 dd             	sub    %r11,%rbp
    478b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    478f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4793:	4d 89 f1             	mov    %r14,%r9
    4796:	4d 29 d1             	sub    %r10,%r9
    4799:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    479d:	3c 2d                	cmp    $0x2d,%al
    479f:	0f 84 fb 03 00 00    	je     4ba0 <fwp_format_g.constprop.0+0x4d0>
    47a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    47af:	48 89 e8             	mov    %rbp,%rax
    47b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47ba:	49 83 c1 47          	add    $0x47,%r9
    47be:	45 85 c0             	test   %r8d,%r8d
    47c1:	0f 88 f1 02 00 00    	js     4ab8 <fwp_format_g.constprop.0+0x3e8>
    47c7:	45 0f b6 12          	movzbl (%r10),%r10d
    47cb:	4d 63 e0             	movslq %r8d,%r12
    47ce:	44 88 10             	mov    %r10b,(%rax)
    47d1:	41 83 f8 07          	cmp    $0x7,%r8d
    47d5:	0f 87 2d 02 00 00    	ja     4a08 <fwp_format_g.constprop.0+0x338>
    47db:	41 f6 c4 04          	test   $0x4,%r12b
    47df:	0f 85 f2 03 00 00    	jne    4bd7 <fwp_format_g.constprop.0+0x507>
    47e5:	45 85 e4             	test   %r12d,%r12d
    47e8:	74 12                	je     47fc <fwp_format_g.constprop.0+0x12c>
    47ea:	45 0f b6 06          	movzbl (%r14),%r8d
    47ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    47f2:	41 f6 c4 02          	test   $0x2,%r12b
    47f6:	0f 85 03 04 00 00    	jne    4bff <fwp_format_g.constprop.0+0x52f>
    47fc:	4c 29 e1             	sub    %r12,%rcx
    47ff:	4c 01 e7             	add    %r12,%rdi
    4802:	4c 89 fa             	mov    %r15,%rdx
    4805:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    480a:	48 83 e9 01          	sub    $0x1,%rcx
    480e:	4d 63 ed             	movslq %r13d,%r13
    4811:	48 89 0c 24          	mov    %rcx,(%rsp)
    4815:	e8 26 ed ff ff       	call   3540 <__memcpy_chk@plt>
    481a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    481f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4823:	ba 48 00 00 00       	mov    $0x48,%edx
    4828:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    482c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4830:	4c 89 c8             	mov    %r9,%rax
    4833:	48 29 c8             	sub    %rcx,%rax
    4836:	48 39 d0             	cmp    %rdx,%rax
    4839:	48 0f 42 c2          	cmovb  %rdx,%rax
    483d:	4c 29 c9             	sub    %r9,%rcx
    4840:	4c 89 ea             	mov    %r13,%rdx
    4843:	48 01 c1             	add    %rax,%rcx
    4846:	e8 f5 ec ff ff       	call   3540 <__memcpy_chk@plt>
    484b:	4c 01 e8             	add    %r13,%rax
    484e:	48 29 e8             	sub    %rbp,%rax
    4851:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4856:	48 39 d0             	cmp    %rdx,%rax
    4859:	48 0f 47 c2          	cmova  %rdx,%rax
    485d:	89 c1                	mov    %eax,%ecx
    485f:	83 f8 08             	cmp    $0x8,%eax
    4862:	0f 83 18 02 00 00    	jae    4a80 <fwp_format_g.constprop.0+0x3b0>
    4868:	a8 04                	test   $0x4,%al
    486a:	0f 85 54 03 00 00    	jne    4bc4 <fwp_format_g.constprop.0+0x4f4>
    4870:	85 c0                	test   %eax,%eax
    4872:	74 0f                	je     4883 <fwp_format_g.constprop.0+0x1b3>
    4874:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4879:	88 13                	mov    %dl,(%rbx)
    487b:	a8 02                	test   $0x2,%al
    487d:	0f 85 6b 03 00 00    	jne    4bee <fwp_format_g.constprop.0+0x51e>
    4883:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4887:	eb 36                	jmp    48bf <fwp_format_g.constprop.0+0x1ef>
    4889:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4890:	45 31 c9             	xor    %r9d,%r9d
    4893:	45 85 ed             	test   %r13d,%r13d
    4896:	4c 8d 05 3a 78 00 00 	lea    0x783a(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    489d:	48 89 df             	mov    %rbx,%rdi
    48a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48a4:	ba 02 00 00 00       	mov    $0x2,%edx
    48a9:	be 90 01 00 00       	mov    $0x190,%esi
    48ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48b5:	b8 01 00 00 00       	mov    $0x1,%eax
    48ba:	e8 d1 ea ff ff       	call   3390 <__snprintf_chk@plt>
    48bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    48c4:	48 89 df             	mov    %rbx,%rdi
    48c7:	e8 94 eb ff ff       	call   3460 <strchr@plt>
    48cc:	48 85 c0             	test   %rax,%rax
    48cf:	74 3f                	je     4910 <fwp_format_g.constprop.0+0x240>
    48d1:	48 89 df             	mov    %rbx,%rdi
    48d4:	e8 57 eb ff ff       	call   3430 <strlen@plt>
    48d9:	48 85 c0             	test   %rax,%rax
    48dc:	75 0b                	jne    48e9 <fwp_format_g.constprop.0+0x219>
    48de:	eb 30                	jmp    4910 <fwp_format_g.constprop.0+0x240>
    48e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48e4:	48 85 c0             	test   %rax,%rax
    48e7:	74 27                	je     4910 <fwp_format_g.constprop.0+0x240>
    48e9:	48 89 c2             	mov    %rax,%rdx
    48ec:	48 83 e8 01          	sub    $0x1,%rax
    48f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    48f4:	74 ea                	je     48e0 <fwp_format_g.constprop.0+0x210>
    48f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    48fb:	0f 84 6f 01 00 00    	je     4a70 <fwp_format_g.constprop.0+0x3a0>
    4901:	0f 1f 40 00          	nopl   0x0(%rax)
    4905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    490c:	00 00 00 00 
    4910:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4917:	00 
    4918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    491f:	00 00 
    4921:	0f 85 ec 02 00 00    	jne    4c13 <fwp_format_g.constprop.0+0x543>
    4927:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    492e:	5b                   	pop    %rbx
    492f:	5d                   	pop    %rbp
    4930:	41 5c                	pop    %r12
    4932:	41 5d                	pop    %r13
    4934:	41 5e                	pop    %r14
    4936:	41 5f                	pop    %r15
    4938:	c3                   	ret
    4939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4940:	4c 29 f5             	sub    %r14,%rbp
    4943:	b9 40 00 00 00       	mov    $0x40,%ecx
    4948:	4c 89 f6             	mov    %r14,%rsi
    494b:	4c 89 04 24          	mov    %r8,(%rsp)
    494f:	49 89 ec             	mov    %rbp,%r12
    4952:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4957:	4c 89 e2             	mov    %r12,%rdx
    495a:	48 89 ef             	mov    %rbp,%rdi
    495d:	e8 de eb ff ff       	call   3540 <__memcpy_chk@plt>
    4962:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4968:	be 2e 00 00 00       	mov    $0x2e,%esi
    496d:	48 89 ef             	mov    %rbp,%rdi
    4970:	e8 eb ea ff ff       	call   3460 <strchr@plt>
    4975:	4c 8b 04 24          	mov    (%rsp),%r8
    4979:	48 85 c0             	test   %rax,%rax
    497c:	74 40                	je     49be <fwp_format_g.constprop.0+0x2ee>
    497e:	4d 85 e4             	test   %r12,%r12
    4981:	74 3b                	je     49be <fwp_format_g.constprop.0+0x2ee>
    4983:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4988:	eb 23                	jmp    49ad <fwp_format_g.constprop.0+0x2dd>
    498a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4991:	00 00 00 00 
    4995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    499c:	00 00 00 00 
    49a0:	c6 00 00             	movb   $0x0,(%rax)
    49a3:	48 83 e8 01          	sub    $0x1,%rax
    49a7:	49 83 ec 01          	sub    $0x1,%r12
    49ab:	74 11                	je     49be <fwp_format_g.constprop.0+0x2ee>
    49ad:	80 38 30             	cmpb   $0x30,(%rax)
    49b0:	74 ee                	je     49a0 <fwp_format_g.constprop.0+0x2d0>
    49b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49b8:	0f 84 fb 01 00 00    	je     4bb9 <fwp_format_g.constprop.0+0x4e9>
    49be:	44 89 c0             	mov    %r8d,%eax
    49c1:	ba 02 00 00 00       	mov    $0x2,%edx
    49c6:	49 89 e9             	mov    %rbp,%r9
    49c9:	be 90 01 00 00       	mov    $0x190,%esi
    49ce:	f7 d8                	neg    %eax
    49d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    49d7:	48 89 df             	mov    %rbx,%rdi
    49da:	41 0f 48 c0          	cmovs  %r8d,%eax
    49de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    49e2:	41 83 e0 02          	and    $0x2,%r8d
    49e6:	41 83 c0 2b          	add    $0x2b,%r8d
    49ea:	50                   	push   %rax
    49eb:	31 c0                	xor    %eax,%eax
    49ed:	41 50                	push   %r8
    49ef:	4c 8d 05 d7 76 00 00 	lea    0x76d7(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    49f6:	e8 95 e9 ff ff       	call   3390 <__snprintf_chk@plt>
    49fb:	58                   	pop    %rax
    49fc:	5a                   	pop    %rdx
    49fd:	e9 0e ff ff ff       	jmp    4910 <fwp_format_g.constprop.0+0x240>
    4a02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a08:	4d 8b 06             	mov    (%r14),%r8
    4a0b:	48 83 c0 09          	add    $0x9,%rax
    4a0f:	4c 89 f2             	mov    %r14,%rdx
    4a12:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a16:	4c 89 07             	mov    %r8,(%rdi)
    4a19:	45 89 e0             	mov    %r12d,%r8d
    4a1c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a21:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a26:	49 89 f8             	mov    %rdi,%r8
    4a29:	49 29 c0             	sub    %rax,%r8
    4a2c:	4c 29 c2             	sub    %r8,%rdx
    4a2f:	45 01 e0             	add    %r12d,%r8d
    4a32:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a36:	41 83 f8 08          	cmp    $0x8,%r8d
    4a3a:	0f 82 bc fd ff ff    	jb     47fc <fwp_format_g.constprop.0+0x12c>
    4a40:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a44:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a48:	45 31 d2             	xor    %r10d,%r10d
    4a4b:	45 89 d3             	mov    %r10d,%r11d
    4a4e:	41 83 c2 08          	add    $0x8,%r10d
    4a52:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a56:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a5a:	45 39 c2             	cmp    %r8d,%r10d
    4a5d:	72 ec                	jb     4a4b <fwp_format_g.constprop.0+0x37b>
    4a5f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4a63:	e9 94 fd ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4a68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a6f:	00 
    4a70:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4a75:	e9 96 fe ff ff       	jmp    4910 <fwp_format_g.constprop.0+0x240>
    4a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a80:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4a85:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4a89:	48 89 ee             	mov    %rbp,%rsi
    4a8c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4a90:	48 89 13             	mov    %rdx,(%rbx)
    4a93:	89 c2                	mov    %eax,%edx
    4a95:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4a9a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4a9f:	48 89 d9             	mov    %rbx,%rcx
    4aa2:	48 29 f9             	sub    %rdi,%rcx
    4aa5:	48 29 ce             	sub    %rcx,%rsi
    4aa8:	01 c1                	add    %eax,%ecx
    4aaa:	c1 e9 03             	shr    $0x3,%ecx
    4aad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4ab0:	e9 ce fd ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4ab5:	0f 1f 00             	nopl   (%rax)
    4ab8:	c6 00 30             	movb   $0x30,(%rax)
    4abb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4abf:	4c 89 fa             	mov    %r15,%rdx
    4ac2:	4c 89 e9             	mov    %r13,%rcx
    4ac5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4aca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4acf:	4c 89 14 24          	mov    %r10,(%rsp)
    4ad3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4ad8:	e8 63 ea ff ff       	call   3540 <__memcpy_chk@plt>
    4add:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4ae2:	b9 48 00 00 00       	mov    $0x48,%ecx
    4ae7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4aec:	48 89 c7             	mov    %rax,%rdi
    4aef:	4c 8b 14 24          	mov    (%rsp),%r10
    4af3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4af8:	4c 89 c8             	mov    %r9,%rax
    4afb:	4c 29 e8             	sub    %r13,%rax
    4afe:	48 39 c8             	cmp    %rcx,%rax
    4b01:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b05:	4d 29 cd             	sub    %r9,%r13
    4b08:	49 01 ff             	add    %rdi,%r15
    4b0b:	4c 01 e8             	add    %r13,%rax
    4b0e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b12:	74 3d                	je     4b51 <fwp_format_g.constprop.0+0x481>
    4b14:	41 f7 d0             	not    %r8d
    4b17:	31 f6                	xor    %esi,%esi
    4b19:	ba 48 00 00 00       	mov    $0x48,%edx
    4b1e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b23:	48 39 d0             	cmp    %rdx,%rax
    4b26:	48 0f 43 d0          	cmovae %rax,%rdx
    4b2a:	48 89 d1             	mov    %rdx,%rcx
    4b2d:	48 29 c1             	sub    %rax,%rcx
    4b30:	48 83 c1 01          	add    $0x1,%rcx
    4b34:	48 39 d1             	cmp    %rdx,%rcx
    4b37:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b3b:	48 83 e8 01          	sub    $0x1,%rax
    4b3f:	48 83 c6 01          	add    $0x1,%rsi
    4b43:	48 29 d0             	sub    %rdx,%rax
    4b46:	48 01 c8             	add    %rcx,%rax
    4b49:	41 39 f0             	cmp    %esi,%r8d
    4b4c:	7f cb                	jg     4b19 <fwp_format_g.constprop.0+0x449>
    4b4e:	4d 01 c7             	add    %r8,%r15
    4b51:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b56:	41 0f b6 12          	movzbl (%r10),%edx
    4b5a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b5e:	4c 89 f6             	mov    %r14,%rsi
    4b61:	48 39 c8             	cmp    %rcx,%rax
    4b64:	4c 89 1c 24          	mov    %r11,(%rsp)
    4b68:	48 0f 43 c8          	cmovae %rax,%rcx
    4b6c:	41 88 17             	mov    %dl,(%r15)
    4b6f:	48 89 ca             	mov    %rcx,%rdx
    4b72:	48 29 c2             	sub    %rax,%rdx
    4b75:	48 83 c2 01          	add    $0x1,%rdx
    4b79:	48 39 ca             	cmp    %rcx,%rdx
    4b7c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4b80:	48 83 e8 01          	sub    $0x1,%rax
    4b84:	48 29 c8             	sub    %rcx,%rax
    4b87:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4b8b:	49 63 d4             	movslq %r12d,%rdx
    4b8e:	e8 ad e9 ff ff       	call   3540 <__memcpy_chk@plt>
    4b93:	4c 8b 1c 24          	mov    (%rsp),%r11
    4b97:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4b9b:	e9 ae fc ff ff       	jmp    484e <fwp_format_g.constprop.0+0x17e>
    4ba0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4ba5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4baa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4baf:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bb4:	e9 f9 fb ff ff       	jmp    47b2 <fwp_format_g.constprop.0+0xe2>
    4bb9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bbf:	e9 fa fd ff ff       	jmp    49be <fwp_format_g.constprop.0+0x2ee>
    4bc4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4bc8:	89 13                	mov    %edx,(%rbx)
    4bca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4bce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4bd2:	e9 ac fc ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4bd7:	41 8b 06             	mov    (%r14),%eax
    4bda:	89 07                	mov    %eax,(%rdi)
    4bdc:	44 89 e0             	mov    %r12d,%eax
    4bdf:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4be4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4be9:	e9 0e fc ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4bee:	89 c2                	mov    %eax,%edx
    4bf0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4bf5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4bfa:	e9 84 fc ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4bff:	44 89 e0             	mov    %r12d,%eax
    4c02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c0e:	e9 e9 fb ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4c13:	e8 28 e8 ff ff       	call   3440 <__stack_chk_fail@plt>
    4c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c1f:	00 

0000000000004c20 <fwp_heap_report>:
    4c20:	f3 0f 1e fa          	endbr64
    4c24:	41 54                	push   %r12
    4c26:	48 8d 3d af 74 00 00 	lea    0x74af(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c2d:	55                   	push   %rbp
    4c2e:	53                   	push   %rbx
    4c2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c3d:	00 00 
    4c3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c46:	00 
    4c47:	48 8d 35 94 75 00 00 	lea    0x7594(%rip),%rsi        # c1e2 <_IO_stdin_used+0x1e2>
    4c4e:	e8 9d e9 ff ff       	call   35f0 <fopen@plt>
    4c53:	48 85 c0             	test   %rax,%rax
    4c56:	0f 84 c5 00 00 00    	je     4d21 <fwp_heap_report+0x101>
    4c5c:	48 89 c5             	mov    %rax,%rbp
    4c5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4c66:	48 89 e3             	mov    %rsp,%rbx
    4c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c70:	48 89 ea             	mov    %rbp,%rdx
    4c73:	be 00 01 00 00       	mov    $0x100,%esi
    4c78:	48 89 df             	mov    %rbx,%rdi
    4c7b:	e8 60 e8 ff ff       	call   34e0 <fgets@plt>
    4c80:	48 85 c0             	test   %rax,%rax
    4c83:	74 2b                	je     4cb0 <fwp_heap_report+0x90>
    4c85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4c8b:	75 e3                	jne    4c70 <fwp_heap_report+0x50>
    4c8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4c91:	75 dd                	jne    4c70 <fwp_heap_report+0x50>
    4c93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4c98:	75 d6                	jne    4c70 <fwp_heap_report+0x50>
    4c9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4c9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ca4:	31 f6                	xor    %esi,%esi
    4ca6:	e8 b5 e8 ff ff       	call   3560 <strtol@plt>
    4cab:	49 89 c4             	mov    %rax,%r12
    4cae:	eb c0                	jmp    4c70 <fwp_heap_report+0x50>
    4cb0:	48 89 ef             	mov    %rbp,%rdi
    4cb3:	e8 68 e7 ff ff       	call   3420 <fclose@plt>
    4cb8:	48 83 ec 08          	sub    $0x8,%rsp
    4cbc:	4c 8b 0d c5 ce 01 00 	mov    0x1cec5(%rip),%r9        # 21b88 <fwp_heap+0x13c8>
    4cc3:	4c 8b 05 1e cf 01 00 	mov    0x1cf1e(%rip),%r8        # 21be8 <fwp_heap+0x1428>
    4cca:	48 8d 15 df 7a 00 00 	lea    0x7adf(%rip),%rdx        # c7b0 <_IO_stdin_used+0x7b0>
    4cd1:	41 54                	push   %r12
    4cd3:	48 8b 0d 06 cf 01 00 	mov    0x1cf06(%rip),%rcx        # 21be0 <fwp_heap+0x1420>
    4cda:	be 02 00 00 00       	mov    $0x2,%esi
    4cdf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ce4:	f2 0f 10 0d 14 cf 01 	movsd  0x1cf14(%rip),%xmm1        # 21c00 <fwp_heap+0x1440>
    4ceb:	00 
    4cec:	f2 0f 10 05 04 cf 01 	movsd  0x1cf04(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    4cf3:	00 
    4cf4:	48 8b 3d 45 b3 00 00 	mov    0xb345(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4cfb:	e8 50 e9 ff ff       	call   3650 <__fprintf_chk@plt>
    4d00:	58                   	pop    %rax
    4d01:	5a                   	pop    %rdx
    4d02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d09:	00 
    4d0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d11:	00 00 
    4d13:	75 15                	jne    4d2a <fwp_heap_report+0x10a>
    4d15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d1c:	5b                   	pop    %rbx
    4d1d:	5d                   	pop    %rbp
    4d1e:	41 5c                	pop    %r12
    4d20:	c3                   	ret
    4d21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d28:	eb 8e                	jmp    4cb8 <fwp_heap_report+0x98>
    4d2a:	e8 11 e7 ff ff       	call   3440 <__stack_chk_fail@plt>
    4d2f:	90                   	nop

0000000000004d30 <fwp_heap_init>:
    4d30:	66 0f 6f 05 88 7e 00 	movdqa 0x7e88(%rip),%xmm0        # cbc0 <msg.4+0x50>
    4d37:	00 
    4d38:	41 54                	push   %r12
    4d3a:	48 8d 05 bf c9 01 00 	lea    0x1c9bf(%rip),%rax        # 21700 <fwp_heap+0xf40>
    4d41:	ba 00 01 00 00       	mov    $0x100,%edx
    4d46:	55                   	push   %rbp
    4d47:	66 0f 6f 15 b1 7e 00 	movdqa 0x7eb1(%rip),%xmm2        # cc00 <msg.4+0x90>
    4d4e:	00 
    4d4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d53:	53                   	push   %rbx
    4d54:	0f 29 05 65 c9 01 00 	movaps %xmm0,0x1c965(%rip)        # 216c0 <fwp_heap+0xf00>
    4d5b:	66 0f 6f 05 6d 7e 00 	movdqa 0x7e6d(%rip),%xmm0        # cbd0 <msg.4+0x60>
    4d62:	00 
    4d63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4d67:	c7 05 f3 cd 01 00 01 	movl   $0x1,0x1cdf3(%rip)        # 21b64 <fwp_heap+0x13a4>
    4d6e:	00 00 00 
    4d71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4d76:	0f 29 05 53 c9 01 00 	movaps %xmm0,0x1c953(%rip)        # 216d0 <fwp_heap+0xf10>
    4d7d:	66 0f 6f 05 5b 7e 00 	movdqa 0x7e5b(%rip),%xmm0        # cbe0 <msg.4+0x70>
    4d84:	00 
    4d85:	0f 29 05 54 c9 01 00 	movaps %xmm0,0x1c954(%rip)        # 216e0 <fwp_heap+0xf20>
    4d8c:	66 0f 6f 05 5c 7e 00 	movdqa 0x7e5c(%rip),%xmm0        # cbf0 <msg.4+0x80>
    4d93:	00 
    4d94:	0f 29 05 55 c9 01 00 	movaps %xmm0,0x1c955(%rip)        # 216f0 <fwp_heap+0xf30>
    4d9b:	89 d3                	mov    %edx,%ebx
    4d9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4da1:	48 83 c0 10          	add    $0x10,%rax
    4da5:	01 d2                	add    %edx,%edx
    4da7:	c1 eb 02             	shr    $0x2,%ebx
    4daa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4db3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4db7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4dc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4dc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4dc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4dce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4dd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4dd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4ddb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4ddf:	48 39 c7             	cmp    %rax,%rdi
    4de2:	75 b7                	jne    4d9b <fwp_heap_init+0x6b>
    4de4:	4c 8d 05 d5 b9 01 00 	lea    0x1b9d5(%rip),%r8        # 207c0 <fwp_heap>
    4deb:	31 c9                	xor    %ecx,%ecx
    4ded:	31 c0                	xor    %eax,%eax
    4def:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dfd:	00 00 00 
    4e00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e07:	00 
    4e08:	48 39 ca             	cmp    %rcx,%rdx
    4e0b:	73 0f                	jae    4e1c <fwp_heap_init+0xec>
    4e0d:	0f 1f 00             	nopl   (%rax)
    4e10:	48 83 c0 01          	add    $0x1,%rax
    4e14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e17:	48 39 ca             	cmp    %rcx,%rdx
    4e1a:	72 f4                	jb     4e10 <fwp_heap_init+0xe0>
    4e1c:	48 83 c1 10          	add    $0x10,%rcx
    4e20:	88 07                	mov    %al,(%rdi)
    4e22:	48 83 c7 01          	add    $0x1,%rdi
    4e26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e2d:	75 d1                	jne    4e00 <fwp_heap_init+0xd0>
    4e2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e36:	00 00 00 
    4e39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e45:	45 31 c9             	xor    %r9d,%r9d
    4e48:	31 d2                	xor    %edx,%edx
    4e4a:	31 ff                	xor    %edi,%edi
    4e4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e57:	4c 89 e6             	mov    %r12,%rsi
    4e5a:	e8 f1 e5 ff ff       	call   3450 <mmap@plt>
    4e5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4e63:	75 13                	jne    4e78 <fwp_heap_init+0x148>
    4e65:	48 c1 eb 02          	shr    $0x2,%rbx
    4e69:	83 ed 01             	sub    $0x1,%ebp
    4e6c:	75 d0                	jne    4e3e <fwp_heap_init+0x10e>
    4e6e:	e8 fd ed ff ff       	call   3c70 <fwp_heap_oom>
    4e73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e78:	48 85 c0             	test   %rax,%rax
    4e7b:	74 f1                	je     4e6e <fwp_heap_init+0x13e>
    4e7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4e81:	48 89 05 f0 cc 01 00 	mov    %rax,0x1ccf0(%rip)        # 21b78 <fwp_heap+0x13b8>
    4e88:	45 31 c9             	xor    %r9d,%r9d
    4e8b:	31 d2                	xor    %edx,%edx
    4e8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4e93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4e97:	31 ff                	xor    %edi,%edi
    4e99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e9f:	66 31 c0             	xor    %ax,%ax
    4ea2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ea6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eab:	4c 89 25 ce cc 01 00 	mov    %r12,0x1ccce(%rip)        # 21b80 <fwp_heap+0x13c0>
    4eb2:	48 89 05 b7 cc 01 00 	mov    %rax,0x1ccb7(%rip)        # 21b70 <fwp_heap+0x13b0>
    4eb9:	48 89 1d d0 cc 01 00 	mov    %rbx,0x1ccd0(%rip)        # 21b90 <fwp_heap+0x13d0>
    4ec0:	48 89 35 f9 cc 01 00 	mov    %rsi,0x1ccf9(%rip)        # 21bc0 <fwp_heap+0x1400>
    4ec7:	e8 84 e5 ff ff       	call   3450 <mmap@plt>
    4ecc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ed0:	74 9c                	je     4e6e <fwp_heap_init+0x13e>
    4ed2:	48 8d 3d 39 72 00 00 	lea    0x7239(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4ed9:	48 89 05 d8 cc 01 00 	mov    %rax,0x1ccd8(%rip)        # 21bb8 <fwp_heap+0x13f8>
    4ee0:	e8 9b e4 ff ff       	call   3380 <getenv@plt>
    4ee5:	48 89 c2             	mov    %rax,%rdx
    4ee8:	31 c0                	xor    %eax,%eax
    4eea:	48 85 d2             	test   %rdx,%rdx
    4eed:	74 15                	je     4f04 <fwp_heap_init+0x1d4>
    4eef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4ef2:	74 10                	je     4f04 <fwp_heap_init+0x1d4>
    4ef4:	0f b6 02             	movzbl (%rdx),%eax
    4ef7:	83 e8 30             	sub    $0x30,%eax
    4efa:	74 13                	je     4f0f <fwp_heap_init+0x1df>
    4efc:	85 c0                	test   %eax,%eax
    4efe:	0f 95 c0             	setne  %al
    4f01:	0f b6 c0             	movzbl %al,%eax
    4f04:	5b                   	pop    %rbx
    4f05:	5d                   	pop    %rbp
    4f06:	89 05 5c cc 01 00    	mov    %eax,0x1cc5c(%rip)        # 21b68 <fwp_heap+0x13a8>
    4f0c:	41 5c                	pop    %r12
    4f0e:	c3                   	ret
    4f0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f13:	85 c0                	test   %eax,%eax
    4f15:	0f 95 c0             	setne  %al
    4f18:	0f b6 c0             	movzbl %al,%eax
    4f1b:	eb e7                	jmp    4f04 <fwp_heap_init+0x1d4>
    4f1d:	0f 1f 00             	nopl   (%rax)

0000000000004f20 <fwp_wake_io>:
    4f20:	48 8b 07             	mov    (%rdi),%rax
    4f23:	48 85 c0             	test   %rax,%rax
    4f26:	0f 84 f4 00 00 00    	je     5020 <fwp_wake_io+0x100>
    4f2c:	53                   	push   %rbx
    4f2d:	4c 8b 05 4c b8 01 00 	mov    0x1b84c(%rip),%r8        # 20780 <fwp_ready_tail>
    4f34:	49 89 f9             	mov    %rdi,%r9
    4f37:	48 89 c2             	mov    %rax,%rdx
    4f3a:	45 31 db             	xor    %r11d,%r11d
    4f3d:	45 31 d2             	xor    %r10d,%r10d
    4f40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f44:	eb 71                	jmp    4fb7 <fwp_wake_io+0x97>
    4f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f4d:	00 00 00 
    4f50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f5e:	48 85 c9             	test   %rcx,%rcx
    4f61:	74 07                	je     4f6a <fwp_wake_io+0x4a>
    4f63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4f6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4f71:	00 00 00 00 
    4f75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4f7c:	49 8b 01             	mov    (%r9),%rax
    4f7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4f83:	75 2a                	jne    4faf <fwp_wake_io+0x8f>
    4f85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4f89:	75 24                	jne    4faf <fwp_wake_io+0x8f>
    4f8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4f8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4f96:	00 00 00 00 
    4f9a:	4d 85 c0             	test   %r8,%r8
    4f9d:	74 51                	je     4ff0 <fwp_wake_io+0xd0>
    4f9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fa6:	49 89 d0             	mov    %rdx,%r8
    4fa9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4faf:	48 89 c2             	mov    %rax,%rdx
    4fb2:	48 85 c0             	test   %rax,%rax
    4fb5:	74 49                	je     5000 <fwp_wake_io+0xe0>
    4fb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4fbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4fc2:	48 85 ff             	test   %rdi,%rdi
    4fc5:	74 b8                	je     4f7f <fwp_wake_io+0x5f>
    4fc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4fce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fd5:	48 85 f6             	test   %rsi,%rsi
    4fd8:	0f 85 72 ff ff ff    	jne    4f50 <fwp_wake_io+0x30>
    4fde:	48 89 0f             	mov    %rcx,(%rdi)
    4fe1:	e9 78 ff ff ff       	jmp    4f5e <fwp_wake_io+0x3e>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 d3             	mov    %rdx,%rbx
    4ff3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4ff9:	eb ab                	jmp    4fa6 <fwp_wake_io+0x86>
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	45 84 db             	test   %r11b,%r11b
    5003:	74 07                	je     500c <fwp_wake_io+0xec>
    5005:	48 89 1d 7c b7 01 00 	mov    %rbx,0x1b77c(%rip)        # 20788 <fwp_ready_head>
    500c:	45 84 d2             	test   %r10b,%r10b
    500f:	74 07                	je     5018 <fwp_wake_io+0xf8>
    5011:	4c 89 05 68 b7 01 00 	mov    %r8,0x1b768(%rip)        # 20780 <fwp_ready_tail>
    5018:	5b                   	pop    %rbx
    5019:	c3                   	ret
    501a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5020:	c3                   	ret
    5021:	0f 1f 40 00          	nopl   0x0(%rax)
    5025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    502c:	00 00 00 00 

0000000000005030 <fwp_tape_buffers_release>:
    5030:	f3 0f 1e fa          	endbr64
    5034:	53                   	push   %rbx
    5035:	48 89 fb             	mov    %rdi,%rbx
    5038:	48 83 ec 10          	sub    $0x10,%rsp
    503c:	48 8b 47 18          	mov    0x18(%rdi),%rax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	0f 88 cf 00 00 00    	js     5118 <fwp_tape_buffers_release+0xe8>
    5049:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    504d:	48 85 d2             	test   %rdx,%rdx
    5050:	0f 88 c2 00 00 00    	js     5118 <fwp_tape_buffers_release+0xe8>
    5056:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    505c:	0f 87 b6 00 00 00    	ja     5118 <fwp_tape_buffers_release+0xe8>
    5062:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5066:	b8 00 00 08 00       	mov    $0x80000,%eax
    506b:	48 c1 e1 03          	shl    $0x3,%rcx
    506f:	48 29 c8             	sub    %rcx,%rax
    5072:	48 c1 e8 03          	shr    $0x3,%rax
    5076:	48 39 d0             	cmp    %rdx,%rax
    5079:	0f 82 99 00 00 00    	jb     5118 <fwp_tape_buffers_release+0xe8>
    507f:	48 8d 3d 9c 70 00 00 	lea    0x709c(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    5086:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    508b:	48 89 14 24          	mov    %rdx,(%rsp)
    508f:	e8 ec e2 ff ff       	call   3380 <getenv@plt>
    5094:	48 8b 14 24          	mov    (%rsp),%rdx
    5098:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    509d:	48 85 c0             	test   %rax,%rax
    50a0:	74 09                	je     50ab <fwp_tape_buffers_release+0x7b>
    50a2:	80 38 30             	cmpb   $0x30,(%rax)
    50a5:	0f 84 8d 00 00 00    	je     5138 <fwp_tape_buffers_release+0x108>
    50ab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50af:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50b3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50ba:	77 68                	ja     5124 <fwp_tape_buffers_release+0xf4>
    50bc:	48 8d 3d dd af 01 00 	lea    0x1afdd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    50c3:	48 89 04 24          	mov    %rax,(%rsp)
    50c7:	e8 04 f0 ff ff       	call   40d0 <fwp_tape_buffers_dispose>
    50cc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    50d0:	48 8b 04 24          	mov    (%rsp),%rax
    50d4:	0f 29 05 c5 af 01 00 	movaps %xmm0,0x1afc5(%rip)        # 200a0 <fwp_tape_workspace>
    50db:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    50e0:	48 89 05 a1 af 01 00 	mov    %rax,0x1afa1(%rip)        # 20088 <fwp_tape_cached_bytes>
    50e7:	0f 29 05 c2 af 01 00 	movaps %xmm0,0x1afc2(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    50ee:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    50f2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50f6:	48 89 15 c3 af 01 00 	mov    %rdx,0x1afc3(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    50fd:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    5104:	00 
    5105:	0f 11 03             	movups %xmm0,(%rbx)
    5108:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    510c:	48 83 c4 10          	add    $0x10,%rsp
    5110:	5b                   	pop    %rbx
    5111:	c3                   	ret
    5112:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5118:	48 8d 3d 03 70 00 00 	lea    0x7003(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    511f:	e8 5c e2 ff ff       	call   3380 <getenv@plt>
    5124:	48 83 c4 10          	add    $0x10,%rsp
    5128:	48 89 df             	mov    %rbx,%rdi
    512b:	5b                   	pop    %rbx
    512c:	e9 9f ef ff ff       	jmp    40d0 <fwp_tape_buffers_dispose>
    5131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5138:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    513c:	0f 85 69 ff ff ff    	jne    50ab <fwp_tape_buffers_release+0x7b>
    5142:	48 83 c4 10          	add    $0x10,%rsp
    5146:	48 89 df             	mov    %rbx,%rdi
    5149:	5b                   	pop    %rbx
    514a:	e9 81 ef ff ff       	jmp    40d0 <fwp_tape_buffers_dispose>
    514f:	90                   	nop

0000000000005150 <fwp_poll_events>:
    5150:	53                   	push   %rbx
    5151:	48 83 ec 20          	sub    $0x20,%rsp
    5155:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    515c:	00 00 
    515e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5163:	31 c0                	xor    %eax,%eax
    5165:	e8 b6 f3 ff ff       	call   4520 <fwp_now_ns>
    516a:	48 8b 1d 07 b6 01 00 	mov    0x1b607(%rip),%rbx        # 20778 <fwp_timers>
    5171:	48 85 db             	test   %rbx,%rbx
    5174:	0f 84 e6 00 00 00    	je     5260 <fwp_poll_events+0x110>
    517a:	48 89 c6             	mov    %rax,%rsi
    517d:	48 89 da             	mov    %rbx,%rdx
    5180:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5187:	eb 26                	jmp    51af <fwp_poll_events+0x5f>
    5189:	90                   	nop
    518a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5191:	00 00 00 00 
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51a7:	48 89 c8             	mov    %rcx,%rax
    51aa:	48 85 d2             	test   %rdx,%rdx
    51ad:	74 31                	je     51e0 <fwp_poll_events+0x90>
    51af:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51b3:	48 85 c0             	test   %rax,%rax
    51b6:	78 e8                	js     51a0 <fwp_poll_events+0x50>
    51b8:	48 39 c1             	cmp    %rax,%rcx
    51bb:	7c e3                	jl     51a0 <fwp_poll_events+0x50>
    51bd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51c4:	48 85 d2             	test   %rdx,%rdx
    51c7:	74 1c                	je     51e5 <fwp_poll_events+0x95>
    51c9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51cd:	48 39 c1             	cmp    %rax,%rcx
    51d0:	7c ce                	jl     51a0 <fwp_poll_events+0x50>
    51d2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51d9:	48 85 d2             	test   %rdx,%rdx
    51dc:	75 d1                	jne    51af <fwp_poll_events+0x5f>
    51de:	66 90                	xchg   %ax,%ax
    51e0:	48 85 c0             	test   %rax,%rax
    51e3:	78 7b                	js     5260 <fwp_poll_events+0x110>
    51e5:	48 29 f0             	sub    %rsi,%rax
    51e8:	48 89 c1             	mov    %rax,%rcx
    51eb:	48 85 c0             	test   %rax,%rax
    51ee:	0f 8e 9c 00 00 00    	jle    5290 <fwp_poll_events+0x140>
    51f4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    51fb:	de 1b 43 
    51fe:	48 f7 ea             	imul   %rdx
    5201:	48 89 c8             	mov    %rcx,%rax
    5204:	48 c1 f8 3f          	sar    $0x3f,%rax
    5208:	48 c1 fa 12          	sar    $0x12,%rdx
    520c:	48 29 c2             	sub    %rax,%rdx
    520f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5216:	48 39 c1             	cmp    %rax,%rcx
    5219:	0f 95 c0             	setne  %al
    521c:	0f b6 c0             	movzbl %al,%eax
    521f:	48 01 d0             	add    %rdx,%rax
    5222:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5228:	0f 8f 32 01 00 00    	jg     5360 <fwp_poll_events+0x210>
    522e:	48 85 c0             	test   %rax,%rax
    5231:	74 5d                	je     5290 <fwp_poll_events+0x140>
    5233:	89 c1                	mov    %eax,%ecx
    5235:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    523c:	48 c1 e9 26          	shr    $0x26,%rcx
    5240:	48 63 d1             	movslq %ecx,%rdx
    5243:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5249:	29 c8                	sub    %ecx,%eax
    524b:	48 98                	cltq
    524d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5254:	e9 11 01 00 00       	jmp    536a <fwp_poll_events+0x21a>
    5259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5260:	e8 cb e9 ff ff       	call   3c30 <fwp_flush>
    5265:	ba 2b 00 00 00       	mov    $0x2b,%edx
    526a:	be 01 00 00 00       	mov    $0x1,%esi
    526f:	48 8b 0d ca ad 00 00 	mov    0xadca(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5276:	48 8d 3d bb 75 00 00 	lea    0x75bb(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    527d:	e8 be e3 ff ff       	call   3640 <fwrite@plt>
    5282:	bf 65 00 00 00       	mov    $0x65,%edi
    5287:	e8 a4 e3 ff ff       	call   3630 <exit@plt>
    528c:	0f 1f 40 00          	nopl   0x0(%rax)
    5290:	e8 8b f2 ff ff       	call   4520 <fwp_now_ns>
    5295:	48 89 c1             	mov    %rax,%rcx
    5298:	66 0f ef c0          	pxor   %xmm0,%xmm0
    529c:	eb 44                	jmp    52e2 <fwp_poll_events+0x192>
    529e:	66 90                	xchg   %ax,%ax
    52a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52a4:	75 33                	jne    52d9 <fwp_poll_events+0x189>
    52a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52aa:	75 2d                	jne    52d9 <fwp_poll_events+0x189>
    52ac:	48 8b 05 cd b4 01 00 	mov    0x1b4cd(%rip),%rax        # 20780 <fwp_ready_tail>
    52b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52be:	00 00 00 00 
    52c2:	48 85 c0             	test   %rax,%rax
    52c5:	0f 84 05 01 00 00    	je     53d0 <fwp_poll_events+0x280>
    52cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    52d2:	48 89 15 a7 b4 01 00 	mov    %rdx,0x1b4a7(%rip)        # 20780 <fwp_ready_tail>
    52d9:	48 85 db             	test   %rbx,%rbx
    52dc:	0f 84 be 00 00 00    	je     53a0 <fwp_poll_events+0x250>
    52e2:	48 89 da             	mov    %rbx,%rdx
    52e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    52ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    52f0:	7f e7                	jg     52d9 <fwp_poll_events+0x189>
    52f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    52f6:	74 2e                	je     5326 <fwp_poll_events+0x1d6>
    52f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    52ff:	48 85 c0             	test   %rax,%rax
    5302:	0f 84 b8 00 00 00    	je     53c0 <fwp_poll_events+0x270>
    5308:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    530f:	48 85 db             	test   %rbx,%rbx
    5312:	74 07                	je     531b <fwp_poll_events+0x1cb>
    5314:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    531b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    531f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5326:	48 8b 42 60          	mov    0x60(%rdx),%rax
    532a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    532e:	48 85 c0             	test   %rax,%rax
    5331:	0f 84 69 ff ff ff    	je     52a0 <fwp_poll_events+0x150>
    5337:	48 39 c8             	cmp    %rcx,%rax
    533a:	0f 8f 60 ff ff ff    	jg     52a0 <fwp_poll_events+0x150>
    5340:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5344:	0f 85 56 ff ff ff    	jne    52a0 <fwp_poll_events+0x150>
    534a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534e:	75 89                	jne    52d9 <fwp_poll_events+0x189>
    5350:	48 89 d7             	mov    %rdx,%rdi
    5353:	e8 68 ef ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    5358:	e9 43 ff ff ff       	jmp    52a0 <fwp_poll_events+0x150>
    535d:	0f 1f 00             	nopl   (%rax)
    5360:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5365:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    536a:	48 89 e7             	mov    %rsp,%rdi
    536d:	31 f6                	xor    %esi,%esi
    536f:	48 89 14 24          	mov    %rdx,(%rsp)
    5373:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5378:	e8 03 e1 ff ff       	call   3480 <nanosleep@plt>
    537d:	48 8b 1d f4 b3 01 00 	mov    0x1b3f4(%rip),%rbx        # 20778 <fwp_timers>
    5384:	e8 97 f1 ff ff       	call   4520 <fwp_now_ns>
    5389:	48 89 c1             	mov    %rax,%rcx
    538c:	48 85 db             	test   %rbx,%rbx
    538f:	0f 85 03 ff ff ff    	jne    5298 <fwp_poll_events+0x148>
    5395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    539c:	00 00 00 00 
    53a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ac:	00 00 
    53ae:	75 2c                	jne    53dc <fwp_poll_events+0x28c>
    53b0:	48 83 c4 20          	add    $0x20,%rsp
    53b4:	5b                   	pop    %rbx
    53b5:	c3                   	ret
    53b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53bd:	00 00 00 
    53c0:	48 89 1d b1 b3 01 00 	mov    %rbx,0x1b3b1(%rip)        # 20778 <fwp_timers>
    53c7:	e9 43 ff ff ff       	jmp    530f <fwp_poll_events+0x1bf>
    53cc:	0f 1f 40 00          	nopl   0x0(%rax)
    53d0:	48 89 15 b1 b3 01 00 	mov    %rdx,0x1b3b1(%rip)        # 20788 <fwp_ready_head>
    53d7:	e9 f6 fe ff ff       	jmp    52d2 <fwp_poll_events+0x182>
    53dc:	e8 5f e0 ff ff       	call   3440 <__stack_chk_fail@plt>
    53e1:	0f 1f 40 00          	nopl   0x0(%rax)
    53e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53ec:	00 00 00 00 

00000000000053f0 <fwp_rc_wide_dup>:
    53f0:	48 89 fa             	mov    %rdi,%rdx
    53f3:	48 8d 35 c6 b3 01 00 	lea    0x1b3c6(%rip),%rsi        # 207c0 <fwp_heap>
    53fa:	48 83 ec 18          	sub    $0x18,%rsp
    53fe:	48 89 f9             	mov    %rdi,%rcx
    5401:	48 c1 ea 11          	shr    $0x11,%rdx
    5405:	48 31 fa             	xor    %rdi,%rdx
    5408:	48 89 d0             	mov    %rdx,%rax
    540b:	48 c1 e8 09          	shr    $0x9,%rax
    540f:	48 31 c2             	xor    %rax,%rdx
    5412:	0f b6 d2             	movzbl %dl,%edx
    5415:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    541c:	00 
    541d:	49 8b 00             	mov    (%r8),%rax
    5420:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5427:	00 00 
    5429:	75 21                	jne    544c <fwp_rc_wide_dup+0x5c>
    542b:	e9 98 00 00 00       	jmp    54c8 <fwp_rc_wide_dup+0xd8>
    5430:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5444:	48 85 d2             	test   %rdx,%rdx
    5447:	74 2f                	je     5478 <fwp_rc_wide_dup+0x88>
    5449:	48 89 d0             	mov    %rdx,%rax
    544c:	48 3b 08             	cmp    (%rax),%rcx
    544f:	75 ef                	jne    5440 <fwp_rc_wide_dup+0x50>
    5451:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5454:	74 7c                	je     54d2 <fwp_rc_wide_dup+0xe2>
    5456:	48 8b 50 08          	mov    0x8(%rax),%rdx
    545a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    545e:	0f 84 91 00 00 00    	je     54f5 <fwp_rc_wide_dup+0x105>
    5464:	48 83 c2 01          	add    $0x1,%rdx
    5468:	48 89 50 08          	mov    %rdx,0x8(%rax)
    546c:	48 83 c4 18          	add    $0x18,%rsp
    5470:	c3                   	ret
    5471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5478:	4c 8d 40 10          	lea    0x10(%rax),%r8
    547c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    547f:	75 68                	jne    54e9 <fwp_rc_wide_dup+0xf9>
    5481:	bf 18 00 00 00       	mov    $0x18,%edi
    5486:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    548b:	4c 89 04 24          	mov    %r8,(%rsp)
    548f:	e8 ec e0 ff ff       	call   3580 <malloc@plt>
    5494:	4c 8b 04 24          	mov    (%rsp),%r8
    5498:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    549d:	48 85 c0             	test   %rax,%rax
    54a0:	74 5f                	je     5501 <fwp_rc_wide_dup+0x111>
    54a2:	48 89 08             	mov    %rcx,(%rax)
    54a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ac:	00 
    54ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54b4:	00 
    54b5:	49 89 00             	mov    %rax,(%r8)
    54b8:	c6 01 ff             	movb   $0xff,(%rcx)
    54bb:	48 83 05 45 cf 01 00 	addq   $0x1,0x1cf45(%rip)        # 22408 <fwp_heap+0x1c48>
    54c2:	01 
    54c3:	48 83 c4 18          	add    $0x18,%rsp
    54c7:	c3                   	ret
    54c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    54cb:	75 13                	jne    54e0 <fwp_rc_wide_dup+0xf0>
    54cd:	48 85 c0             	test   %rax,%rax
    54d0:	74 af                	je     5481 <fwp_rc_wide_dup+0x91>
    54d2:	48 8d 3d 8f 73 00 00 	lea    0x738f(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    54d9:	e8 d2 ee ff ff       	call   43b0 <fwp_trap>
    54de:	66 90                	xchg   %ax,%ax
    54e0:	48 85 c0             	test   %rax,%rax
    54e3:	0f 85 6d ff ff ff    	jne    5456 <fwp_rc_wide_dup+0x66>
    54e9:	48 8d 3d a0 73 00 00 	lea    0x73a0(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    54f0:	e8 bb ee ff ff       	call   43b0 <fwp_trap>
    54f5:	48 8d 3d 37 6c 00 00 	lea    0x6c37(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    54fc:	e8 af ee ff ff       	call   43b0 <fwp_trap>
    5501:	e8 6a e7 ff ff       	call   3c70 <fwp_heap_oom>
    5506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    550d:	00 00 00 

0000000000005510 <fwp_rc_forget_slot>:
    5510:	80 3f ff             	cmpb   $0xff,(%rdi)
    5513:	74 0b                	je     5520 <fwp_rc_forget_slot+0x10>
    5515:	c3                   	ret
    5516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    551d:	00 00 00 
    5520:	48 89 f8             	mov    %rdi,%rax
    5523:	48 83 ec 08          	sub    $0x8,%rsp
    5527:	48 89 fa             	mov    %rdi,%rdx
    552a:	48 c1 e8 11          	shr    $0x11,%rax
    552e:	48 31 f8             	xor    %rdi,%rax
    5531:	48 89 c1             	mov    %rax,%rcx
    5534:	48 c1 e9 09          	shr    $0x9,%rcx
    5538:	48 31 c8             	xor    %rcx,%rax
    553b:	48 8d 0d 7e b2 01 00 	lea    0x1b27e(%rip),%rcx        # 207c0 <fwp_heap>
    5542:	0f b6 c0             	movzbl %al,%eax
    5545:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    554c:	00 
    554d:	48 85 ff             	test   %rdi,%rdi
    5550:	74 3c                	je     558e <fwp_rc_forget_slot+0x7e>
    5552:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5559:	00 
    555a:	48 8b 01             	mov    (%rcx),%rax
    555d:	eb 11                	jmp    5570 <fwp_rc_forget_slot+0x60>
    555f:	90                   	nop
    5560:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5564:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5568:	48 85 ff             	test   %rdi,%rdi
    556b:	74 21                	je     558e <fwp_rc_forget_slot+0x7e>
    556d:	48 89 f8             	mov    %rdi,%rax
    5570:	48 3b 10             	cmp    (%rax),%rdx
    5573:	75 eb                	jne    5560 <fwp_rc_forget_slot+0x50>
    5575:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5579:	48 89 01             	mov    %rax,(%rcx)
    557c:	e8 1f de ff ff       	call   33a0 <free@plt>
    5581:	48 83 2d 7f ce 01 00 	subq   $0x1,0x1ce7f(%rip)        # 22408 <fwp_heap+0x1c48>
    5588:	01 
    5589:	48 83 c4 08          	add    $0x8,%rsp
    558d:	c3                   	ret
    558e:	48 8d 3d fb 72 00 00 	lea    0x72fb(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    5595:	e8 16 ee ff ff       	call   43b0 <fwp_trap>
    559a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055a0 <fwp_rc_prepare_chunk>:
    55a0:	48 83 3d 60 ce 01 00 	cmpq   $0x0,0x1ce60(%rip)        # 22408 <fwp_heap+0x1c48>
    55a7:	00 
    55a8:	41 54                	push   %r12
    55aa:	49 89 f4             	mov    %rsi,%r12
    55ad:	55                   	push   %rbp
    55ae:	48 89 fd             	mov    %rdi,%rbp
    55b1:	53                   	push   %rbx
    55b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55b5:	0f 84 7d 00 00 00    	je     5638 <fwp_rc_prepare_chunk+0x98>
    55bb:	31 db                	xor    %ebx,%ebx
    55bd:	85 c0                	test   %eax,%eax
    55bf:	75 5f                	jne    5620 <fwp_rc_prepare_chunk+0x80>
    55c1:	48 85 f6             	test   %rsi,%rsi
    55c4:	74 7c                	je     5642 <fwp_rc_prepare_chunk+0xa2>
    55c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    55ca:	e8 d1 dd ff ff       	call   33a0 <free@plt>
    55cf:	90                   	nop
    55d0:	be 01 00 00 00       	mov    $0x1,%esi
    55d5:	4c 89 e7             	mov    %r12,%rdi
    55d8:	e8 23 df ff ff       	call   3500 <calloc@plt>
    55dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    55e1:	48 85 c0             	test   %rax,%rax
    55e4:	0f 85 87 00 00 00    	jne    5671 <fwp_rc_prepare_chunk+0xd1>
    55ea:	e8 81 e6 ff ff       	call   3c70 <fwp_heap_oom>
    55ef:	90                   	nop
    55f0:	e8 1b ff ff ff       	call   5510 <fwp_rc_forget_slot>
    55f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    55f8:	48 83 c3 01          	add    $0x1,%rbx
    55fc:	48 39 c3             	cmp    %rax,%rbx
    55ff:	73 37                	jae    5638 <fwp_rc_prepare_chunk+0x98>
    5601:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5608:	00 00 
    560a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5611:	00 00 00 00 
    5615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    561c:	00 00 00 00 
    5620:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5624:	48 01 df             	add    %rbx,%rdi
    5627:	80 3f ff             	cmpb   $0xff,(%rdi)
    562a:	74 c4                	je     55f0 <fwp_rc_prepare_chunk+0x50>
    562c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    562f:	48 83 c3 01          	add    $0x1,%rbx
    5633:	48 39 c3             	cmp    %rax,%rbx
    5636:	72 e8                	jb     5620 <fwp_rc_prepare_chunk+0x80>
    5638:	49 39 c4             	cmp    %rax,%r12
    563b:	75 13                	jne    5650 <fwp_rc_prepare_chunk+0xb0>
    563d:	4d 85 e4             	test   %r12,%r12
    5640:	75 46                	jne    5688 <fwp_rc_prepare_chunk+0xe8>
    5642:	5b                   	pop    %rbx
    5643:	5d                   	pop    %rbp
    5644:	41 5c                	pop    %r12
    5646:	c3                   	ret
    5647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    564e:	00 00 
    5650:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5654:	48 29 05 b5 cd 01 00 	sub    %rax,0x1cdb5(%rip)        # 22410 <fwp_heap+0x1c50>
    565b:	e8 40 dd ff ff       	call   33a0 <free@plt>
    5660:	4d 85 e4             	test   %r12,%r12
    5663:	0f 85 67 ff ff ff    	jne    55d0 <fwp_rc_prepare_chunk+0x30>
    5669:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5670:	00 
    5671:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5675:	5b                   	pop    %rbx
    5676:	4c 01 25 93 cd 01 00 	add    %r12,0x1cd93(%rip)        # 22410 <fwp_heap+0x1c50>
    567d:	5d                   	pop    %rbp
    567e:	41 5c                	pop    %r12
    5680:	c3                   	ret
    5681:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5688:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    568c:	5b                   	pop    %rbx
    568d:	4c 89 e2             	mov    %r12,%rdx
    5690:	31 f6                	xor    %esi,%esi
    5692:	5d                   	pop    %rbp
    5693:	41 5c                	pop    %r12
    5695:	e9 06 de ff ff       	jmp    34a0 <memset@plt>
    569a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056a0 <fwp_heap_refill>:
    56a0:	41 56                	push   %r14
    56a2:	41 89 d6             	mov    %edx,%r14d
    56a5:	41 55                	push   %r13
    56a7:	41 89 f5             	mov    %esi,%r13d
    56aa:	41 54                	push   %r12
    56ac:	49 89 fc             	mov    %rdi,%r12
    56af:	bf 01 00 00 00       	mov    $0x1,%edi
    56b4:	55                   	push   %rbp
    56b5:	53                   	push   %rbx
    56b6:	e8 85 e8 ff ff       	call   3f40 <fwp_heap_chunks>
    56bb:	48 89 c3             	mov    %rax,%rbx
    56be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    56c2:	48 8b 05 ef c4 01 00 	mov    0x1c4ef(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    56c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    56cd:	48 8d 05 ec b0 01 00 	lea    0x1b0ec(%rip),%rax        # 207c0 <fwp_heap>
    56d4:	31 d2                	xor    %edx,%edx
    56d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    56da:	48 89 ef             	mov    %rbp,%rdi
    56dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    56e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    56e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    56ec:	00 
    56ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    56f2:	f7 f1                	div    %ecx
    56f4:	31 d2                	xor    %edx,%edx
    56f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    56fa:	66 0f 6e c8          	movd   %eax,%xmm1
    56fe:	89 c6                	mov    %eax,%esi
    5700:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5705:	48 01 c8             	add    %rcx,%rax
    5708:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    570c:	48 f7 f1             	div    %rcx
    570f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5714:	89 45 18             	mov    %eax,0x18(%rbp)
    5717:	e8 84 fe ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    571c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    571f:	48 89 d8             	mov    %rbx,%rax
    5722:	48 c1 e0 10          	shl    $0x10,%rax
    5726:	48 03 05 43 c4 01 00 	add    0x1c443(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    572d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5731:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5736:	8b 55 08             	mov    0x8(%rbp),%edx
    5739:	48 0f af d1          	imul   %rcx,%rdx
    573d:	48 01 c2             	add    %rax,%rdx
    5740:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5745:	5b                   	pop    %rbx
    5746:	5d                   	pop    %rbp
    5747:	41 5c                	pop    %r12
    5749:	41 5d                	pop    %r13
    574b:	41 5e                	pop    %r14
    574d:	c3                   	ret
    574e:	66 90                	xchg   %ax,%ax

0000000000005750 <fwp_mem_free>:
    5750:	48 85 ff             	test   %rdi,%rdi
    5753:	0f 84 17 02 00 00    	je     5970 <fwp_mem_free+0x220>
    5759:	48 8b 35 10 c4 01 00 	mov    0x1c410(%rip),%rsi        # 21b70 <fwp_heap+0x13b0>
    5760:	48 8b 05 31 c4 01 00 	mov    0x1c431(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    5767:	48 89 fa             	mov    %rdi,%rdx
    576a:	48 29 f2             	sub    %rsi,%rdx
    576d:	48 c1 e0 10          	shl    $0x10,%rax
    5771:	48 39 c2             	cmp    %rax,%rdx
    5774:	0f 83 f6 01 00 00    	jae    5970 <fwp_mem_free+0x220>
    577a:	49 89 d1             	mov    %rdx,%r9
    577d:	49 c1 e9 10          	shr    $0x10,%r9
    5781:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5785:	48 c1 e0 03          	shl    $0x3,%rax
    5789:	49 89 c0             	mov    %rax,%r8
    578c:	4c 03 05 25 c4 01 00 	add    0x1c425(%rip),%r8        # 21bb8 <fwp_heap+0x13f8>
    5793:	0f 84 d7 01 00 00    	je     5970 <fwp_mem_free+0x220>
    5799:	48 83 ec 38          	sub    $0x38,%rsp
    579d:	48 89 f9             	mov    %rdi,%rcx
    57a0:	41 0f b6 38          	movzbl (%r8),%edi
    57a4:	40 80 ff 01          	cmp    $0x1,%dil
    57a8:	74 16                	je     57c0 <fwp_mem_free+0x70>
    57aa:	40 80 ff 02          	cmp    $0x2,%dil
    57ae:	0f 84 94 00 00 00    	je     5848 <fwp_mem_free+0xf8>
    57b4:	48 83 c4 38          	add    $0x38,%rsp
    57b8:	c3                   	ret
    57b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    57c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    57c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    57c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    57ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    57d2:	4d 85 d2             	test   %r10,%r10
    57d5:	74 1d                	je     57f4 <fwp_mem_free+0xa4>
    57d7:	0f b7 c1             	movzwl %cx,%eax
    57da:	31 d2                	xor    %edx,%edx
    57dc:	48 f7 f7             	div    %rdi
    57df:	49 01 c2             	add    %rax,%r10
    57e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    57e6:	0f 84 44 01 00 00    	je     5930 <fwp_mem_free+0x1e0>
    57ec:	41 c6 02 00          	movb   $0x0,(%r10)
    57f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    57f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    57fb:	49 63 c1             	movslq %r9d,%rax
    57fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5802:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5806:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    580b:	f2 0f 58 05 ed c3 01 	addsd  0x1c3ed(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    5812:	00 
    5813:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5817:	48 8d 05 a2 af 01 00 	lea    0x1afa2(%rip),%rax        # 207c0 <fwp_heap>
    581e:	48 01 d0             	add    %rdx,%rax
    5821:	48 8b 10             	mov    (%rax),%rdx
    5824:	48 f7 d2             	not    %rdx
    5827:	48 89 11             	mov    %rdx,(%rcx)
    582a:	48 89 08             	mov    %rcx,(%rax)
    582d:	48 29 3d ac c3 01 00 	sub    %rdi,0x1c3ac(%rip)        # 21be0 <fwp_heap+0x1420>
    5834:	f2 0f 11 05 c4 c3 01 	movsd  %xmm0,0x1c3c4(%rip)        # 21c00 <fwp_heap+0x1440>
    583b:	00 
    583c:	48 83 c4 38          	add    $0x38,%rsp
    5840:	c3                   	ret
    5841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5848:	66 31 d2             	xor    %dx,%dx
    584b:	48 01 d6             	add    %rdx,%rsi
    584e:	48 39 f1             	cmp    %rsi,%rcx
    5851:	0f 85 5d ff ff ff    	jne    57b4 <fwp_mem_free+0x64>
    5857:	49 8b 50 10          	mov    0x10(%r8),%rdx
    585b:	48 29 15 7e c3 01 00 	sub    %rdx,0x1c37e(%rip)        # 21be0 <fwp_heap+0x1420>
    5862:	48 85 d2             	test   %rdx,%rdx
    5865:	0f 88 a5 00 00 00    	js     5910 <fwp_mem_free+0x1c0>
    586b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    586f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5874:	f2 0f 58 05 84 c3 01 	addsd  0x1c384(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5880:	f2 0f 11 05 78 c3 01 	movsd  %xmm0,0x1c378(%rip)        # 21c00 <fwp_heap+0x1440>
    5887:	00 
    5888:	48 85 d2             	test   %rdx,%rdx
    588b:	74 0c                	je     5899 <fwp_mem_free+0x149>
    588d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5890:	0f 84 db 00 00 00    	je     5971 <fwp_mem_free+0x221>
    5896:	c6 02 00             	movb   $0x0,(%rdx)
    5899:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    589d:	48 85 c9             	test   %rcx,%rcx
    58a0:	74 3e                	je     58e0 <fwp_mem_free+0x190>
    58a2:	48 8b 15 0f c3 01 00 	mov    0x1c30f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    58a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58b1:	48 01 d0             	add    %rdx,%rax
    58b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58b8:	48 89 d6             	mov    %rdx,%rsi
    58bb:	48 29 c6             	sub    %rax,%rsi
    58be:	83 e6 08             	and    $0x8,%esi
    58c1:	74 0d                	je     58d0 <fwp_mem_free+0x180>
    58c3:	c6 00 00             	movb   $0x0,(%rax)
    58c6:	48 83 c0 28          	add    $0x28,%rax
    58ca:	48 39 c2             	cmp    %rax,%rdx
    58cd:	74 11                	je     58e0 <fwp_mem_free+0x190>
    58cf:	90                   	nop
    58d0:	c6 00 00             	movb   $0x0,(%rax)
    58d3:	48 83 c0 50          	add    $0x50,%rax
    58d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    58db:	48 39 c2             	cmp    %rax,%rdx
    58de:	75 f0                	jne    58d0 <fwp_mem_free+0x180>
    58e0:	48 01 0d 09 c3 01 00 	add    %rcx,0x1c309(%rip)        # 21bf0 <fwp_heap+0x1430>
    58e7:	4c 3b 0d c2 c2 01 00 	cmp    0x1c2c2(%rip),%r9        # 21bb0 <fwp_heap+0x13f0>
    58ee:	73 07                	jae    58f7 <fwp_mem_free+0x1a7>
    58f0:	4c 89 0d b9 c2 01 00 	mov    %r9,0x1c2b9(%rip)        # 21bb0 <fwp_heap+0x13f0>
    58f7:	4c 3b 0d aa c2 01 00 	cmp    0x1c2aa(%rip),%r9        # 21ba8 <fwp_heap+0x13e8>
    58fe:	0f 83 b0 fe ff ff    	jae    57b4 <fwp_mem_free+0x64>
    5904:	4c 89 0d 9d c2 01 00 	mov    %r9,0x1c29d(%rip)        # 21ba8 <fwp_heap+0x13e8>
    590b:	e9 a4 fe ff ff       	jmp    57b4 <fwp_mem_free+0x64>
    5910:	48 89 d1             	mov    %rdx,%rcx
    5913:	83 e2 01             	and    $0x1,%edx
    5916:	66 0f ef c0          	pxor   %xmm0,%xmm0
    591a:	48 d1 e9             	shr    $1,%rcx
    591d:	48 09 d1             	or     %rdx,%rcx
    5920:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5925:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5929:	e9 46 ff ff ff       	jmp    5874 <fwp_mem_free+0x124>
    592e:	66 90                	xchg   %ax,%ax
    5930:	4c 89 d7             	mov    %r10,%rdi
    5933:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5938:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    593d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5942:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5946:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    594b:	e8 c0 fb ff ff       	call   5510 <fwp_rc_forget_slot>
    5950:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5955:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    595a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    595f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5964:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5969:	e9 7e fe ff ff       	jmp    57ec <fwp_mem_free+0x9c>
    596e:	66 90                	xchg   %ax,%ax
    5970:	c3                   	ret
    5971:	48 89 d7             	mov    %rdx,%rdi
    5974:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5979:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    597e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5983:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5988:	e8 83 fb ff ff       	call   5510 <fwp_rc_forget_slot>
    598d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5992:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5997:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    599c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59a1:	e9 f0 fe ff ff       	jmp    5896 <fwp_mem_free+0x146>
    59a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ad:	00 00 00 

00000000000059b0 <fwp_heap_alloc_big>:
    59b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59b7:	00 00 40 
    59ba:	41 57                	push   %r15
    59bc:	41 56                	push   %r14
    59be:	41 55                	push   %r13
    59c0:	41 54                	push   %r12
    59c2:	55                   	push   %rbp
    59c3:	53                   	push   %rbx
    59c4:	48 83 ec 08          	sub    $0x8,%rsp
    59c8:	48 39 f8             	cmp    %rdi,%rax
    59cb:	0f 82 fa 00 00 00    	jb     5acb <fwp_heap_alloc_big+0x11b>
    59d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    59d8:	49 89 fd             	mov    %rdi,%r13
    59db:	41 89 f6             	mov    %esi,%r14d
    59de:	48 c1 ed 10          	shr    $0x10,%rbp
    59e2:	48 89 ef             	mov    %rbp,%rdi
    59e5:	e8 56 e5 ff ff       	call   3f40 <fwp_heap_chunks>
    59ea:	be 01 00 00 00       	mov    $0x1,%esi
    59ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    59f3:	49 89 c4             	mov    %rax,%r12
    59f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    59fd:	00 
    59fe:	48 03 3d b3 c1 01 00 	add    0x1c1b3(%rip),%rdi        # 21bb8 <fwp_heap+0x13f8>
    5a05:	c6 07 02             	movb   $0x2,(%rdi)
    5a08:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a0c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a0f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a13:	e8 88 fb ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    5a18:	48 83 fd 01          	cmp    $0x1,%rbp
    5a1c:	76 47                	jbe    5a65 <fwp_heap_alloc_big+0xb5>
    5a1e:	4c 01 e5             	add    %r12,%rbp
    5a21:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a28:	00 
    5a29:	4c 8d 3d 90 ad 01 00 	lea    0x1ad90(%rip),%r15        # 207c0 <fwp_heap>
    5a30:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a35:	49 c1 e6 03          	shl    $0x3,%r14
    5a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a40:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a47:	31 f6                	xor    %esi,%esi
    5a49:	48 01 dd             	add    %rbx,%rbp
    5a4c:	48 83 c3 28          	add    $0x28,%rbx
    5a50:	48 89 ef             	mov    %rbp,%rdi
    5a53:	e8 48 fb ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    5a58:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a5c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5a60:	49 39 de             	cmp    %rbx,%r14
    5a63:	75 db                	jne    5a40 <fwp_heap_alloc_big+0x90>
    5a65:	49 c1 e4 10          	shl    $0x10,%r12
    5a69:	4c 03 25 00 c1 01 00 	add    0x1c100(%rip),%r12        # 21b70 <fwp_heap+0x13b0>
    5a70:	4c 89 ea             	mov    %r13,%rdx
    5a73:	31 f6                	xor    %esi,%esi
    5a75:	4c 89 e7             	mov    %r12,%rdi
    5a78:	e8 23 da ff ff       	call   34a0 <memset@plt>
    5a7d:	4c 89 e8             	mov    %r13,%rax
    5a80:	48 03 05 59 c1 01 00 	add    0x1c159(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5a87:	72 42                	jb     5acb <fwp_heap_alloc_big+0x11b>
    5a89:	48 39 05 58 c1 01 00 	cmp    %rax,0x1c158(%rip)        # 21be8 <fwp_heap+0x1428>
    5a90:	48 89 05 49 c1 01 00 	mov    %rax,0x1c149(%rip)        # 21be0 <fwp_heap+0x1420>
    5a97:	73 07                	jae    5aa0 <fwp_heap_alloc_big+0xf0>
    5a99:	48 89 05 48 c1 01 00 	mov    %rax,0x1c148(%rip)        # 21be8 <fwp_heap+0x1428>
    5aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa4:	4c 89 e0             	mov    %r12,%rax
    5aa7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aac:	f2 0f 58 05 44 c1 01 	addsd  0x1c144(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5ab3:	00 
    5ab4:	f2 0f 11 05 3c c1 01 	movsd  %xmm0,0x1c13c(%rip)        # 21bf8 <fwp_heap+0x1438>
    5abb:	00 
    5abc:	48 83 c4 08          	add    $0x8,%rsp
    5ac0:	5b                   	pop    %rbx
    5ac1:	5d                   	pop    %rbp
    5ac2:	41 5c                	pop    %r12
    5ac4:	41 5d                	pop    %r13
    5ac6:	41 5e                	pop    %r14
    5ac8:	41 5f                	pop    %r15
    5aca:	c3                   	ret
    5acb:	e8 a0 e1 ff ff       	call   3c70 <fwp_heap_oom>

0000000000005ad0 <fwp_heap_alloc_slow>:
    5ad0:	53                   	push   %rbx
    5ad1:	48 89 f9             	mov    %rdi,%rcx
    5ad4:	41 89 f1             	mov    %esi,%r9d
    5ad7:	48 83 ec 10          	sub    $0x10,%rsp
    5adb:	8b 05 83 c0 01 00    	mov    0x1c083(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5ae1:	85 c0                	test   %eax,%eax
    5ae3:	0f 84 c7 00 00 00    	je     5bb0 <fwp_heap_alloc_slow+0xe0>
    5ae9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5af0:	0f 87 dd 00 00 00    	ja     5bd3 <fwp_heap_alloc_slow+0x103>
    5af6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5afa:	48 8d 3d bf ac 01 00 	lea    0x1acbf(%rip),%rdi        # 207c0 <fwp_heap>
    5b01:	49 63 f1             	movslq %r9d,%rsi
    5b04:	48 c1 e8 04          	shr    $0x4,%rax
    5b08:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b0f:	00 00 
    5b11:	41 0f b6 c2          	movzbl %r10b,%eax
    5b15:	4c 89 d2             	mov    %r10,%rdx
    5b18:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b1c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b23:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b2a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b2e:	48 01 f8             	add    %rdi,%rax
    5b31:	4c 8b 00             	mov    (%rax),%r8
    5b34:	4d 85 c0             	test   %r8,%r8
    5b37:	0f 84 ab 00 00 00    	je     5be8 <fwp_heap_alloc_slow+0x118>
    5b3d:	49 8b 10             	mov    (%r8),%rdx
    5b40:	48 f7 d2             	not    %rdx
    5b43:	48 89 10             	mov    %rdx,(%rax)
    5b46:	41 83 f9 01          	cmp    $0x1,%r9d
    5b4a:	4c 89 c7             	mov    %r8,%rdi
    5b4d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b51:	31 f6                	xor    %esi,%esi
    5b53:	48 89 ca             	mov    %rcx,%rdx
    5b56:	e8 45 d9 ff ff       	call   34a0 <memset@plt>
    5b5b:	49 89 c0             	mov    %rax,%r8
    5b5e:	48 89 d8             	mov    %rbx,%rax
    5b61:	48 03 05 78 c0 01 00 	add    0x1c078(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5b68:	0f 82 d9 00 00 00    	jb     5c47 <fwp_heap_alloc_slow+0x177>
    5b6e:	48 39 05 73 c0 01 00 	cmp    %rax,0x1c073(%rip)        # 21be8 <fwp_heap+0x1428>
    5b75:	48 89 05 64 c0 01 00 	mov    %rax,0x1c064(%rip)        # 21be0 <fwp_heap+0x1420>
    5b7c:	73 07                	jae    5b85 <fwp_heap_alloc_slow+0xb5>
    5b7e:	48 89 05 63 c0 01 00 	mov    %rax,0x1c063(%rip)        # 21be8 <fwp_heap+0x1428>
    5b85:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b89:	4c 89 c0             	mov    %r8,%rax
    5b8c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5b91:	f2 0f 58 05 5f c0 01 	addsd  0x1c05f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5b98:	00 
    5b99:	f2 0f 11 05 57 c0 01 	movsd  %xmm0,0x1c057(%rip)        # 21bf8 <fwp_heap+0x1438>
    5ba0:	00 
    5ba1:	48 83 c4 10          	add    $0x10,%rsp
    5ba5:	5b                   	pop    %rbx
    5ba6:	c3                   	ret
    5ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bae:	00 00 
    5bb0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bb4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bb8:	e8 73 f1 ff ff       	call   4d30 <fwp_heap_init>
    5bbd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5bc1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5bc6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5bcd:	0f 86 23 ff ff ff    	jbe    5af6 <fwp_heap_alloc_slow+0x26>
    5bd3:	48 83 c4 10          	add    $0x10,%rsp
    5bd7:	44 89 ce             	mov    %r9d,%esi
    5bda:	48 89 cf             	mov    %rcx,%rdi
    5bdd:	5b                   	pop    %rbx
    5bde:	e9 cd fd ff ff       	jmp    59b0 <fwp_heap_alloc_big>
    5be3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5be8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5bec:	4d 85 c0             	test   %r8,%r8
    5bef:	74 1f                	je     5c10 <fwp_heap_alloc_slow+0x140>
    5bf1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5bf5:	4d 29 c3             	sub    %r8,%r11
    5bf8:	49 39 db             	cmp    %rbx,%r11
    5bfb:	72 13                	jb     5c10 <fwp_heap_alloc_slow+0x140>
    5bfd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c05:	e9 3c ff ff ff       	jmp    5b46 <fwp_heap_alloc_slow+0x76>
    5c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c1b:	44 89 ca             	mov    %r9d,%edx
    5c1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c2b:	44 89 d6             	mov    %r10d,%esi
    5c2e:	48 01 c7             	add    %rax,%rdi
    5c31:	e8 6a fa ff ff       	call   56a0 <fwp_heap_refill>
    5c36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c3f:	49 89 c0             	mov    %rax,%r8
    5c42:	e9 ff fe ff ff       	jmp    5b46 <fwp_heap_alloc_slow+0x76>
    5c47:	e8 24 e0 ff ff       	call   3c70 <fwp_heap_oom>
    5c4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c50 <fwp_heap_alloc>:
    5c50:	8b 05 0e bf 01 00    	mov    0x1bf0e(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5c56:	48 89 fa             	mov    %rdi,%rdx
    5c59:	89 f7                	mov    %esi,%edi
    5c5b:	85 c0                	test   %eax,%eax
    5c5d:	0f 84 f5 00 00 00    	je     5d58 <fwp_heap_alloc+0x108>
    5c63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5c6a:	0f 87 e8 00 00 00    	ja     5d58 <fwp_heap_alloc+0x108>
    5c70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5c74:	48 8d 05 45 ab 01 00 	lea    0x1ab45(%rip),%rax        # 207c0 <fwp_heap>
    5c7b:	48 83 ec 18          	sub    $0x18,%rsp
    5c7f:	41 89 f0             	mov    %esi,%r8d
    5c82:	48 c1 e9 04          	shr    $0x4,%rcx
    5c86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5c8d:	00 
    5c8e:	48 63 cf             	movslq %edi,%rcx
    5c91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5c98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5c9f:	00 
    5ca0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ca4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ca8:	48 01 c8             	add    %rcx,%rax
    5cab:	48 8b 08             	mov    (%rax),%rcx
    5cae:	48 85 c9             	test   %rcx,%rcx
    5cb1:	74 6d                	je     5d20 <fwp_heap_alloc+0xd0>
    5cb3:	48 8b 31             	mov    (%rcx),%rsi
    5cb6:	48 f7 d6             	not    %rsi
    5cb9:	48 89 30             	mov    %rsi,(%rax)
    5cbc:	41 83 f8 01          	cmp    $0x1,%r8d
    5cc0:	48 89 cf             	mov    %rcx,%rdi
    5cc3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5cc8:	49 0f 45 d1          	cmovne %r9,%rdx
    5ccc:	31 f6                	xor    %esi,%esi
    5cce:	e8 cd d7 ff ff       	call   34a0 <memset@plt>
    5cd3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5cd8:	48 89 c1             	mov    %rax,%rcx
    5cdb:	4c 89 c8             	mov    %r9,%rax
    5cde:	48 03 05 fb be 01 00 	add    0x1befb(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ce5:	72 7b                	jb     5d62 <fwp_heap_alloc+0x112>
    5ce7:	48 39 05 fa be 01 00 	cmp    %rax,0x1befa(%rip)        # 21be8 <fwp_heap+0x1428>
    5cee:	48 89 05 eb be 01 00 	mov    %rax,0x1beeb(%rip)        # 21be0 <fwp_heap+0x1420>
    5cf5:	73 07                	jae    5cfe <fwp_heap_alloc+0xae>
    5cf7:	48 89 05 ea be 01 00 	mov    %rax,0x1beea(%rip)        # 21be8 <fwp_heap+0x1428>
    5cfe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d02:	48 89 c8             	mov    %rcx,%rax
    5d05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d0a:	f2 0f 58 05 e6 be 01 	addsd  0x1bee6(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5d11:	00 
    5d12:	f2 0f 11 05 de be 01 	movsd  %xmm0,0x1bede(%rip)        # 21bf8 <fwp_heap+0x1438>
    5d19:	00 
    5d1a:	48 83 c4 18          	add    $0x18,%rsp
    5d1e:	c3                   	ret
    5d1f:	90                   	nop
    5d20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d24:	48 85 c9             	test   %rcx,%rcx
    5d27:	74 0c                	je     5d35 <fwp_heap_alloc+0xe5>
    5d29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d2d:	48 29 ce             	sub    %rcx,%rsi
    5d30:	4c 39 ce             	cmp    %r9,%rsi
    5d33:	73 13                	jae    5d48 <fwp_heap_alloc+0xf8>
    5d35:	89 fe                	mov    %edi,%esi
    5d37:	48 83 c4 18          	add    $0x18,%rsp
    5d3b:	48 89 d7             	mov    %rdx,%rdi
    5d3e:	e9 8d fd ff ff       	jmp    5ad0 <fwp_heap_alloc_slow>
    5d43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d50:	e9 67 ff ff ff       	jmp    5cbc <fwp_heap_alloc+0x6c>
    5d55:	0f 1f 00             	nopl   (%rax)
    5d58:	89 fe                	mov    %edi,%esi
    5d5a:	48 89 d7             	mov    %rdx,%rdi
    5d5d:	e9 6e fd ff ff       	jmp    5ad0 <fwp_heap_alloc_slow>
    5d62:	e8 09 df ff ff       	call   3c70 <fwp_heap_oom>
    5d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5d6e:	00 00 

0000000000005d70 <fwp_data.part.0.constprop.0>:
    5d70:	41 56                	push   %r14
    5d72:	41 89 fe             	mov    %edi,%r14d
    5d75:	41 54                	push   %r12
    5d77:	49 89 f4             	mov    %rsi,%r12
    5d7a:	55                   	push   %rbp
    5d7b:	53                   	push   %rbx
    5d7c:	48 83 ec 08          	sub    $0x8,%rsp
    5d80:	8b 05 de bd 01 00    	mov    0x1bdde(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5d86:	85 c0                	test   %eax,%eax
    5d88:	0f 84 fa 00 00 00    	je     5e88 <fwp_data.part.0.constprop.0+0x118>
    5d8e:	0f b6 05 cd b9 01 00 	movzbl 0x1b9cd(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    5d95:	48 8d 15 24 aa 01 00 	lea    0x1aa24(%rip),%rdx        # 207c0 <fwp_heap>
    5d9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5da3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5da7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5dab:	48 8b 18             	mov    (%rax),%rbx
    5dae:	48 85 db             	test   %rbx,%rbx
    5db1:	0f 84 a9 00 00 00    	je     5e60 <fwp_data.part.0.constprop.0+0xf0>
    5db7:	48 8b 13             	mov    (%rbx),%rdx
    5dba:	48 f7 d2             	not    %rdx
    5dbd:	48 89 10             	mov    %rdx,(%rax)
    5dc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5dc4:	76 1b                	jbe    5de1 <fwp_data.part.0.constprop.0+0x71>
    5dc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5dca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5dce:	31 f6                	xor    %esi,%esi
    5dd0:	48 c1 e8 03          	shr    $0x3,%rax
    5dd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5ddb:	00 
    5ddc:	e8 bf d6 ff ff       	call   34a0 <memset@plt>
    5de1:	48 89 e8             	mov    %rbp,%rax
    5de4:	48 03 05 f5 bd 01 00 	add    0x1bdf5(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5deb:	0f 82 a8 00 00 00    	jb     5e99 <fwp_data.part.0.constprop.0+0x129>
    5df1:	48 39 05 f0 bd 01 00 	cmp    %rax,0x1bdf0(%rip)        # 21be8 <fwp_heap+0x1428>
    5df8:	48 89 05 e1 bd 01 00 	mov    %rax,0x1bde1(%rip)        # 21be0 <fwp_heap+0x1420>
    5dff:	73 07                	jae    5e08 <fwp_data.part.0.constprop.0+0x98>
    5e01:	48 89 05 e0 bd 01 00 	mov    %rax,0x1bde0(%rip)        # 21be8 <fwp_heap+0x1428>
    5e08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e11:	f2 0f 58 05 df bd 01 	addsd  0x1bddf(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5e18:	00 
    5e19:	f2 0f 11 05 d7 bd 01 	movsd  %xmm0,0x1bdd7(%rip)        # 21bf8 <fwp_heap+0x1438>
    5e20:	00 
    5e21:	b8 02 00 00 00       	mov    $0x2,%eax
    5e26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e37:	49 8b 04 24          	mov    (%r12),%rax
    5e3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e48:	48 83 c4 08          	add    $0x8,%rsp
    5e4c:	48 89 d8             	mov    %rbx,%rax
    5e4f:	5b                   	pop    %rbx
    5e50:	5d                   	pop    %rbp
    5e51:	41 5c                	pop    %r12
    5e53:	41 5e                	pop    %r14
    5e55:	c3                   	ret
    5e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e5d:	00 00 00 
    5e60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5e64:	48 85 db             	test   %rbx,%rbx
    5e67:	74 1f                	je     5e88 <fwp_data.part.0.constprop.0+0x118>
    5e69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5e6d:	48 29 da             	sub    %rbx,%rdx
    5e70:	48 39 ea             	cmp    %rbp,%rdx
    5e73:	72 13                	jb     5e88 <fwp_data.part.0.constprop.0+0x118>
    5e75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5e79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e7d:	e9 3e ff ff ff       	jmp    5dc0 <fwp_data.part.0.constprop.0+0x50>
    5e82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e88:	31 f6                	xor    %esi,%esi
    5e8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5e8f:	e8 bc fd ff ff       	call   5c50 <fwp_heap_alloc>
    5e94:	48 89 c3             	mov    %rax,%rbx
    5e97:	eb 88                	jmp    5e21 <fwp_data.part.0.constprop.0+0xb1>
    5e99:	e8 d2 dd ff ff       	call   3c70 <fwp_heap_oom>
    5e9e:	66 90                	xchg   %ax,%ax

0000000000005ea0 <fwp_tape_grow.constprop.0>:
    5ea0:	41 56                	push   %r14
    5ea2:	b8 40 00 00 00       	mov    $0x40,%eax
    5ea7:	41 55                	push   %r13
    5ea9:	41 54                	push   %r12
    5eab:	55                   	push   %rbp
    5eac:	48 89 fd             	mov    %rdi,%rbp
    5eaf:	53                   	push   %rbx
    5eb0:	48 83 ec 10          	sub    $0x10,%rsp
    5eb4:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5eb8:	48 85 db             	test   %rbx,%rbx
    5ebb:	48 0f 44 d8          	cmove  %rax,%rbx
    5ebf:	48 39 de             	cmp    %rbx,%rsi
    5ec2:	7e 12                	jle    5ed6 <fwp_tape_grow.constprop.0+0x36>
    5ec4:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5ecb:	0f 8e df 00 00 00    	jle    5fb0 <fwp_tape_grow.constprop.0+0x110>
    5ed1:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5ed6:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    5eda:	4d 85 e4             	test   %r12,%r12
    5edd:	0f 84 dd 00 00 00    	je     5fc0 <fwp_tape_grow.constprop.0+0x120>
    5ee3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ee7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    5eee:	00 
    5eef:	e8 ac d6 ff ff       	call   35a0 <realloc@plt>
    5ef4:	48 85 c0             	test   %rax,%rax
    5ef7:	0f 84 eb 00 00 00    	je     5fe8 <fwp_tape_grow.constprop.0+0x148>
    5efd:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    5f02:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5f06:	48 39 da             	cmp    %rbx,%rdx
    5f09:	0f 8d 8b 00 00 00    	jge    5f9a <fwp_tape_grow.constprop.0+0xfa>
    5f0f:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    5f16:	ff ff 07 
    5f19:	48 39 c3             	cmp    %rax,%rbx
    5f1c:	0f 8f ba 00 00 00    	jg     5fdc <fwp_tape_grow.constprop.0+0x13c>
    5f22:	48 89 d9             	mov    %rbx,%rcx
    5f25:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    5f2a:	be 02 00 00 00       	mov    $0x2,%esi
    5f2f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5f34:	48 c1 e1 04          	shl    $0x4,%rcx
    5f38:	48 89 cf             	mov    %rcx,%rdi
    5f3b:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f3f:	e8 0c fd ff ff       	call   5c50 <fwp_heap_alloc>
    5f44:	49 89 c5             	mov    %rax,%r13
    5f47:	4d 85 f6             	test   %r14,%r14
    5f4a:	74 27                	je     5f73 <fwp_tape_grow.constprop.0+0xd3>
    5f4c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5f51:	48 8b 0c 24          	mov    (%rsp),%rcx
    5f55:	48 89 c7             	mov    %rax,%rdi
    5f58:	4c 89 f6             	mov    %r14,%rsi
    5f5b:	48 c1 e2 04          	shl    $0x4,%rdx
    5f5f:	48 39 ca             	cmp    %rcx,%rdx
    5f62:	48 0f 47 d1          	cmova  %rcx,%rdx
    5f66:	e8 05 d6 ff ff       	call   3570 <memcpy@plt>
    5f6b:	4c 89 f7             	mov    %r14,%rdi
    5f6e:	e8 dd f7 ff ff       	call   5750 <fwp_mem_free>
    5f73:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    5f78:	48 89 da             	mov    %rbx,%rdx
    5f7b:	31 f6                	xor    %esi,%esi
    5f7d:	48 29 fa             	sub    %rdi,%rdx
    5f80:	48 c1 e7 04          	shl    $0x4,%rdi
    5f84:	48 c1 e2 04          	shl    $0x4,%rdx
    5f88:	4c 01 ef             	add    %r13,%rdi
    5f8b:	e8 10 d5 ff ff       	call   34a0 <memset@plt>
    5f90:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    5f95:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    5f9a:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5f9e:	48 83 c4 10          	add    $0x10,%rsp
    5fa2:	5b                   	pop    %rbx
    5fa3:	5d                   	pop    %rbp
    5fa4:	41 5c                	pop    %r12
    5fa6:	41 5d                	pop    %r13
    5fa8:	41 5e                	pop    %r14
    5faa:	c3                   	ret
    5fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fb0:	48 01 db             	add    %rbx,%rbx
    5fb3:	e9 07 ff ff ff       	jmp    5ebf <fwp_tape_grow.constprop.0+0x1f>
    5fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5fbf:	00 
    5fc0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    5fc4:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5fc8:	48 c1 e6 03          	shl    $0x3,%rsi
    5fcc:	e8 cf d5 ff ff       	call   35a0 <realloc@plt>
    5fd1:	48 85 c0             	test   %rax,%rax
    5fd4:	74 12                	je     5fe8 <fwp_tape_grow.constprop.0+0x148>
    5fd6:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5fda:	eb be                	jmp    5f9a <fwp_tape_grow.constprop.0+0xfa>
    5fdc:	48 8d 3d 69 61 00 00 	lea    0x6169(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    5fe3:	e8 c8 e3 ff ff       	call   43b0 <fwp_trap>
    5fe8:	48 89 ef             	mov    %rbp,%rdi
    5feb:	e8 d0 db ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    5ff0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5ff4:	e8 a7 d3 ff ff       	call   33a0 <free@plt>
    5ff9:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ffd:	e8 9e d3 ff ff       	call   33a0 <free@plt>
    6002:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6006:	e8 95 d3 ff ff       	call   33a0 <free@plt>
    600b:	31 c9                	xor    %ecx,%ecx
    600d:	31 c0                	xor    %eax,%eax
    600f:	31 d2                	xor    %edx,%edx
    6011:	89 55 04             	mov    %edx,0x4(%rbp)
    6014:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6018:	ba 13 00 00 00       	mov    $0x13,%edx
    601d:	be 01 00 00 00       	mov    $0x1,%esi
    6022:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    6026:	48 8d 3d db 5f 00 00 	lea    0x5fdb(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    602d:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6031:	48 8b 0d 08 a0 00 00 	mov    0xa008(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6038:	48 89 45 30          	mov    %rax,0x30(%rbp)
    603c:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6040:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6044:	e8 f7 d5 ff ff       	call   3640 <fwrite@plt>
    6049:	31 ff                	xor    %edi,%edi
    604b:	e8 40 d5 ff ff       	call   3590 <fflush@plt>
    6050:	bf 66 00 00 00       	mov    $0x66,%edi
    6055:	e8 06 d6 ff ff       	call   3660 <_Exit@plt>
    605a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000006060 <w123>:
    6060:	41 56                	push   %r14
    6062:	55                   	push   %rbp
    6063:	53                   	push   %rbx
    6064:	48 83 ec 30          	sub    $0x30,%rsp
    6068:	48 85 f7             	test   %rsi,%rdi
    606b:	0f 88 a7 01 00 00    	js     6218 <w123+0x1b8>
    6071:	48 89 f8             	mov    %rdi,%rax
    6074:	48 89 fb             	mov    %rdi,%rbx
    6077:	48 89 f5             	mov    %rsi,%rbp
    607a:	48 09 f0             	or     %rsi,%rax
    607d:	0f 89 5d 01 00 00    	jns    61e0 <w123+0x180>
    6083:	48 85 ff             	test   %rdi,%rdi
    6086:	0f 88 a4 01 00 00    	js     6230 <w123+0x1d0>
    608c:	48 89 d9             	mov    %rbx,%rcx
    608f:	4c 8b 35 8a 6b 00 00 	mov    0x6b8a(%rip),%r14        # cc20 <msg.4+0xb0>
    6096:	48 c1 f9 20          	sar    $0x20,%rcx
    609a:	48 39 0a             	cmp    %rcx,(%rdx)
    609d:	0f 84 65 01 00 00    	je     6208 <w123+0x1a8>
    60a3:	48 89 cf             	mov    %rcx,%rdi
    60a6:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    60ab:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    60b0:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    60b6:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60bc:	e8 cf e5 ff ff       	call   4690 <fwp_tape_of>
    60c1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    60c6:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    60cc:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    60d1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    60d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    60dc:	0f 85 7f 01 00 00    	jne    6261 <w123+0x201>
    60e2:	48 89 0a             	mov    %rcx,(%rdx)
    60e5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    60e9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    60ed:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    60f4:	0f 8f 4f 01 00 00    	jg     6249 <w123+0x1e9>
    60fa:	89 da                	mov    %ebx,%edx
    60fc:	48 39 d1             	cmp    %rdx,%rcx
    60ff:	0f 8e 50 01 00 00    	jle    6255 <w123+0x1f5>
    6105:	48 85 ed             	test   %rbp,%rbp
    6108:	78 0b                	js     6115 <w123+0xb5>
    610a:	89 ea                	mov    %ebp,%edx
    610c:	48 39 d1             	cmp    %rdx,%rcx
    610f:	0f 8e 40 01 00 00    	jle    6255 <w123+0x1f5>
    6115:	48 89 ca             	mov    %rcx,%rdx
    6118:	48 2b 50 08          	sub    0x8(%rax),%rdx
    611c:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6120:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6127:	0f 87 1c 01 00 00    	ja     6249 <w123+0x1e9>
    612d:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6131:	7e 3e                	jle    6171 <w123+0x111>
    6133:	48 89 c7             	mov    %rax,%rdi
    6136:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    613b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6140:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6145:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    614b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6151:	e8 4a fd ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6156:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    615c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6162:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6167:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    616c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6171:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    6175:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6179:	48 85 ed             	test   %rbp,%rbp
    617c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    6181:	48 8b 3d 98 6a 00 00 	mov    0x6a98(%rip),%rdi        # cc20 <msg.4+0xb0>
    6188:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    618c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6190:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    6197:	48 0f 48 ee          	cmovs  %rsi,%rbp
    619b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    619f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    61a3:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    61a8:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    61ac:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    61b0:	66 0f d6 12          	movq   %xmm2,(%rdx)
    61b4:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    61b8:	48 89 50 10          	mov    %rdx,0x10(%rax)
    61bc:	48 83 c4 30          	add    $0x30,%rsp
    61c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    61c7:	ff ff ff 
    61ca:	48 21 c3             	and    %rax,%rbx
    61cd:	48 09 cb             	or     %rcx,%rbx
    61d0:	48 89 d8             	mov    %rbx,%rax
    61d3:	5b                   	pop    %rbx
    61d4:	5d                   	pop    %rbp
    61d5:	41 5e                	pop    %r14
    61d7:	c3                   	ret
    61d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61df:	00 
    61e0:	48 89 f9             	mov    %rdi,%rcx
    61e3:	48 89 f0             	mov    %rsi,%rax
    61e6:	48 c1 f9 20          	sar    $0x20,%rcx
    61ea:	48 c1 f8 20          	sar    $0x20,%rax
    61ee:	48 39 c1             	cmp    %rax,%rcx
    61f1:	0f 84 95 fe ff ff    	je     608c <w123+0x2c>
    61f7:	48 8d 3d ba 66 00 00 	lea    0x66ba(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    61fe:	e8 ad e1 ff ff       	call   43b0 <fwp_trap>
    6203:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6208:	48 8b 42 08          	mov    0x8(%rdx),%rax
    620c:	e9 d8 fe ff ff       	jmp    60e9 <w123+0x89>
    6211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6218:	48 83 c4 30          	add    $0x30,%rsp
    621c:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6223:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6227:	48 89 d8             	mov    %rbx,%rax
    622a:	5b                   	pop    %rbx
    622b:	5d                   	pop    %rbp
    622c:	41 5e                	pop    %r14
    622e:	c3                   	ret
    622f:	90                   	nop
    6230:	48 89 f1             	mov    %rsi,%rcx
    6233:	48 89 f3             	mov    %rsi,%rbx
    6236:	45 31 f6             	xor    %r14d,%r14d
    6239:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6240:	48 c1 f9 20          	sar    $0x20,%rcx
    6244:	e9 51 fe ff ff       	jmp    609a <w123+0x3a>
    6249:	48 8d 3d fc 5e 00 00 	lea    0x5efc(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    6250:	e8 5b e1 ff ff       	call   43b0 <fwp_trap>
    6255:	48 8d 3d 0b 5f 00 00 	lea    0x5f0b(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    625c:	e8 4f e1 ff ff       	call   43b0 <fwp_trap>
    6261:	48 8d 3d 98 66 00 00 	lea    0x6698(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    6268:	e8 43 e1 ff ff       	call   43b0 <fwp_trap>
    626d:	0f 1f 00             	nopl   (%rax)

0000000000006270 <w120>:
    6270:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6274:	41 57                	push   %r15
    6276:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    627a:	41 56                	push   %r14
    627c:	41 55                	push   %r13
    627e:	49 89 fd             	mov    %rdi,%r13
    6281:	41 54                	push   %r12
    6283:	49 89 d4             	mov    %rdx,%r12
    6286:	55                   	push   %rbp
    6287:	48 89 f5             	mov    %rsi,%rbp
    628a:	53                   	push   %rbx
    628b:	48 83 ec 48          	sub    $0x48,%rsp
    628f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6295:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    629a:	48 85 ff             	test   %rdi,%rdi
    629d:	0f 88 5d 06 00 00    	js     6900 <w120+0x690>
    62a3:	49 89 fe             	mov    %rdi,%r14
    62a6:	49 c1 fe 20          	sar    $0x20,%r14
    62aa:	4c 3b 32             	cmp    (%rdx),%r14
    62ad:	0f 84 ed 05 00 00    	je     68a0 <w120+0x630>
    62b3:	4c 89 f7             	mov    %r14,%rdi
    62b6:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    62bc:	e8 cf e3 ff ff       	call   4690 <fwp_tape_of>
    62c1:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    62c7:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    62cc:	48 89 c3             	mov    %rax,%rbx
    62cf:	0f 85 97 06 00 00    	jne    696c <w120+0x6fc>
    62d5:	4d 89 34 24          	mov    %r14,(%r12)
    62d9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    62de:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    62e2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    62e9:	0f 8f 71 06 00 00    	jg     6960 <w120+0x6f0>
    62ef:	44 89 e8             	mov    %r13d,%eax
    62f2:	49 39 c6             	cmp    %rax,%r14
    62f5:	0f 8e 4a 06 00 00    	jle    6945 <w120+0x6d5>
    62fb:	4c 89 f0             	mov    %r14,%rax
    62fe:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6302:	48 8d 70 01          	lea    0x1(%rax),%rsi
    6306:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    630d:	0f 87 4d 06 00 00    	ja     6960 <w120+0x6f0>
    6313:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    6319:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    631d:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    6321:	0f 8f 61 04 00 00    	jg     6788 <w120+0x518>
    6327:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    632b:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    6330:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6334:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    6339:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    633e:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6343:	49 8d 46 01          	lea    0x1(%r14),%rax
    6347:	48 89 43 10          	mov    %rax,0x10(%rbx)
    634b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6352:	ff ff ff 
    6355:	4c 21 eb             	and    %r13,%rbx
    6358:	4c 09 f3             	or     %r14,%rbx
    635b:	49 89 de             	mov    %rbx,%r14
    635e:	49 c1 fe 20          	sar    $0x20,%r14
    6362:	48 85 ed             	test   %rbp,%rbp
    6365:	78 10                	js     6377 <w120+0x107>
    6367:	48 89 e8             	mov    %rbp,%rax
    636a:	48 c1 f8 20          	sar    $0x20,%rax
    636e:	4c 39 f0             	cmp    %r14,%rax
    6371:	0f 85 da 05 00 00    	jne    6951 <w120+0x6e1>
    6377:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    637c:	66 0f 28 2d 8c 68 00 	movapd 0x688c(%rip),%xmm5        # cc10 <msg.4+0xa0>
    6383:	00 
    6384:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6389:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    638e:	4d 39 34 24          	cmp    %r14,(%r12)
    6392:	0f 84 18 05 00 00    	je     68b0 <w120+0x640>
    6398:	4c 89 f7             	mov    %r14,%rdi
    639b:	e8 f0 e2 ff ff       	call   4690 <fwp_tape_of>
    63a0:	48 89 c2             	mov    %rax,%rdx
    63a3:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    63a8:	0f 85 be 05 00 00    	jne    696c <w120+0x6fc>
    63ae:	4d 89 34 24          	mov    %r14,(%r12)
    63b2:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    63b7:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    63bb:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    63c2:	0f 8f 98 05 00 00    	jg     6960 <w120+0x6f0>
    63c8:	89 d8                	mov    %ebx,%eax
    63ca:	49 39 c6             	cmp    %rax,%r14
    63cd:	0f 8e 72 05 00 00    	jle    6945 <w120+0x6d5>
    63d3:	48 85 ed             	test   %rbp,%rbp
    63d6:	78 0b                	js     63e3 <w120+0x173>
    63d8:	89 e8                	mov    %ebp,%eax
    63da:	49 39 c6             	cmp    %rax,%r14
    63dd:	0f 8e 62 05 00 00    	jle    6945 <w120+0x6d5>
    63e3:	4c 89 f0             	mov    %r14,%rax
    63e6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    63ea:	48 8d 70 01          	lea    0x1(%rax),%rsi
    63ee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    63f5:	0f 87 65 05 00 00    	ja     6960 <w120+0x6f0>
    63fb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    63ff:	0f 8f bb 03 00 00    	jg     67c0 <w120+0x550>
    6405:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    6409:	48 8b 42 20          	mov    0x20(%rdx),%rax
    640d:	48 85 ed             	test   %rbp,%rbp
    6410:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    6416:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    641b:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    641f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6426:	48 0f 49 c5          	cmovns %rbp,%rax
    642a:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    642e:	66 48 0f 6e d8       	movq   %rax,%xmm3
    6433:	49 8d 46 01          	lea    0x1(%r14),%rax
    6437:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    643b:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    643f:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6443:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6447:	4d 85 ed             	test   %r13,%r13
    644a:	0f 88 4b 05 00 00    	js     699b <w120+0x72b>
    6450:	4c 89 ea             	mov    %r13,%rdx
    6453:	48 c1 fa 20          	sar    $0x20,%rdx
    6457:	49 3b 14 24          	cmp    (%r12),%rdx
    645b:	0f 84 5f 04 00 00    	je     68c0 <w120+0x650>
    6461:	48 89 d7             	mov    %rdx,%rdi
    6464:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6469:	e8 22 e2 ff ff       	call   4690 <fwp_tape_of>
    646e:	48 89 c5             	mov    %rax,%rbp
    6471:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6476:	0f 85 f0 04 00 00    	jne    696c <w120+0x6fc>
    647c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6481:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6486:	49 89 14 24          	mov    %rdx,(%r12)
    648a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    648e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6494:	0f 8f c6 04 00 00    	jg     6960 <w120+0x6f0>
    649a:	44 89 ea             	mov    %r13d,%edx
    649d:	48 39 d0             	cmp    %rdx,%rax
    64a0:	0f 8e 9f 04 00 00    	jle    6945 <w120+0x6d5>
    64a6:	48 89 c2             	mov    %rax,%rdx
    64a9:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    64ad:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    64b1:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    64b8:	0f 87 a2 04 00 00    	ja     6960 <w120+0x6f0>
    64be:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    64c2:	0f 8f 20 03 00 00    	jg     67e8 <w120+0x578>
    64c8:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    64cd:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    64d1:	66 0f 28 05 37 67 00 	movapd 0x6737(%rip),%xmm0        # cc10 <msg.4+0xa0>
    64d8:	00 
    64d9:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    64dd:	66 0f 28 ee          	movapd %xmm6,%xmm5
    64e1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    64e5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    64e9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    64f0:	ff 
    64f1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    64f6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    64fa:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    64fe:	4c 89 ed             	mov    %r13,%rbp
    6501:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6508:	ff ff ff 
    650b:	48 21 d5             	and    %rdx,%rbp
    650e:	48 09 c5             	or     %rax,%rbp
    6511:	66 49 0f 7e ef       	movq   %xmm5,%r15
    6516:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    651d:	ff ff ff 
    6520:	48 21 c3             	and    %rax,%rbx
    6523:	4c 09 f3             	or     %r14,%rbx
    6526:	49 89 de             	mov    %rbx,%r14
    6529:	49 c1 fe 20          	sar    $0x20,%r14
    652d:	4d 3b 34 24          	cmp    (%r12),%r14
    6531:	0f 84 99 03 00 00    	je     68d0 <w120+0x660>
    6537:	4c 89 f7             	mov    %r14,%rdi
    653a:	e8 51 e1 ff ff       	call   4690 <fwp_tape_of>
    653f:	49 89 c5             	mov    %rax,%r13
    6542:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6547:	0f 85 1f 04 00 00    	jne    696c <w120+0x6fc>
    654d:	4d 89 34 24          	mov    %r14,(%r12)
    6551:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6556:	4d 8b 75 10          	mov    0x10(%r13),%r14
    655a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6561:	0f 8f f9 03 00 00    	jg     6960 <w120+0x6f0>
    6567:	89 d8                	mov    %ebx,%eax
    6569:	49 39 c6             	cmp    %rax,%r14
    656c:	0f 8e d3 03 00 00    	jle    6945 <w120+0x6d5>
    6572:	4c 89 f0             	mov    %r14,%rax
    6575:	49 2b 45 08          	sub    0x8(%r13),%rax
    6579:	48 8d 70 01          	lea    0x1(%rax),%rsi
    657d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6584:	0f 87 d6 03 00 00    	ja     6960 <w120+0x6f0>
    658a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    658f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6593:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6597:	0f 8f 73 02 00 00    	jg     6810 <w120+0x5a0>
    659d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    65a1:	66 0f 6e eb          	movd   %ebx,%xmm5
    65a5:	49 8b 45 20          	mov    0x20(%r13),%rax
    65a9:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    65ae:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    65b3:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    65b8:	49 8d 46 01          	lea    0x1(%r14),%rax
    65bc:	49 89 45 10          	mov    %rax,0x10(%r13)
    65c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65c7:	ff ff ff 
    65ca:	48 21 c3             	and    %rax,%rbx
    65cd:	4c 09 f3             	or     %r14,%rbx
    65d0:	49 89 dd             	mov    %rbx,%r13
    65d3:	49 c1 fd 20          	sar    $0x20,%r13
    65d7:	4d 3b 2c 24          	cmp    (%r12),%r13
    65db:	0f 84 ff 02 00 00    	je     68e0 <w120+0x670>
    65e1:	4c 89 ef             	mov    %r13,%rdi
    65e4:	e8 a7 e0 ff ff       	call   4690 <fwp_tape_of>
    65e9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    65ee:	0f 85 78 03 00 00    	jne    696c <w120+0x6fc>
    65f4:	4d 89 2c 24          	mov    %r13,(%r12)
    65f8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    65fd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6601:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6608:	0f 8f 52 03 00 00    	jg     6960 <w120+0x6f0>
    660e:	89 da                	mov    %ebx,%edx
    6610:	49 39 d5             	cmp    %rdx,%r13
    6613:	0f 8e 2c 03 00 00    	jle    6945 <w120+0x6d5>
    6619:	4d 89 ee             	mov    %r13,%r14
    661c:	4c 2b 70 08          	sub    0x8(%rax),%r14
    6620:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6624:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    662b:	0f 87 2f 03 00 00    	ja     6960 <w120+0x6f0>
    6631:	f2 0f 10 15 e7 65 00 	movsd  0x65e7(%rip),%xmm2        # cc20 <msg.4+0xb0>
    6638:	00 
    6639:	66 49 0f 6e cf       	movq   %r15,%xmm1
    663e:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6644:	f2 0f 59 0d e4 65 00 	mulsd  0x65e4(%rip),%xmm1        # cc30 <msg.4+0xc0>
    664b:	00 
    664c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6650:	0f 8f da 01 00 00    	jg     6830 <w120+0x5c0>
    6656:	48 8b 50 20          	mov    0x20(%rax),%rdx
    665a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    665e:	f3 0f 7e 05 ca 65 00 	movq   0x65ca(%rip),%xmm0        # cc30 <msg.4+0xc0>
    6665:	00 
    6666:	48 89 ef             	mov    %rbp,%rdi
    6669:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    666c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6671:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6675:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    667c:	ff 
    667d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6681:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6685:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6689:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6690:	ff ff ff 
    6693:	48 21 c3             	and    %rax,%rbx
    6696:	4c 09 eb             	or     %r13,%rbx
    6699:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    669d:	0f 84 c8 00 00 00    	je     676b <w120+0x4fb>
    66a3:	49 89 ed             	mov    %rbp,%r13
    66a6:	49 c1 fd 20          	sar    $0x20,%r13
    66aa:	4d 39 2c 24          	cmp    %r13,(%r12)
    66ae:	0f 84 3c 02 00 00    	je     68f0 <w120+0x680>
    66b4:	4c 89 ef             	mov    %r13,%rdi
    66b7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66bd:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    66c2:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    66c8:	e8 c3 df ff ff       	call   4690 <fwp_tape_of>
    66cd:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    66d2:	0f 85 94 02 00 00    	jne    696c <w120+0x6fc>
    66d8:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    66de:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    66e3:	4d 89 2c 24          	mov    %r13,(%r12)
    66e7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    66ec:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    66f2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    66f6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    66fd:	0f 8f 5d 02 00 00    	jg     6960 <w120+0x6f0>
    6703:	89 e9                	mov    %ebp,%ecx
    6705:	4c 39 f1             	cmp    %r14,%rcx
    6708:	0f 8d 37 02 00 00    	jge    6945 <w120+0x6d5>
    670e:	4d 89 f5             	mov    %r14,%r13
    6711:	4c 2b 68 08          	sub    0x8(%rax),%r13
    6715:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6719:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6720:	0f 87 3a 02 00 00    	ja     6960 <w120+0x6f0>
    6726:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    672a:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    672e:	0f 8f 2c 01 00 00    	jg     6860 <w120+0x5f0>
    6734:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6738:	66 0f 6e dd          	movd   %ebp,%xmm3
    673c:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6741:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6748:	ff ff ff 
    674b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6750:	48 21 d5             	and    %rdx,%rbp
    6753:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6758:	48 89 ef             	mov    %rbp,%rdi
    675b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6760:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6764:	4c 09 f7             	or     %r14,%rdi
    6767:	48 89 48 10          	mov    %rcx,0x10(%rax)
    676b:	4c 89 e2             	mov    %r12,%rdx
    676e:	48 89 de             	mov    %rbx,%rsi
    6771:	e8 ea f8 ff ff       	call   6060 <w123>
    6776:	48 83 c4 48          	add    $0x48,%rsp
    677a:	5b                   	pop    %rbx
    677b:	5d                   	pop    %rbp
    677c:	41 5c                	pop    %r12
    677e:	41 5d                	pop    %r13
    6780:	41 5e                	pop    %r14
    6782:	41 5f                	pop    %r15
    6784:	c3                   	ret
    6785:	0f 1f 00             	nopl   (%rax)
    6788:	48 89 df             	mov    %rbx,%rdi
    678b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6790:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6796:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    679b:	e8 00 f7 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67a0:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    67a6:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    67ac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    67b1:	e9 71 fb ff ff       	jmp    6327 <w120+0xb7>
    67b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67bd:	00 00 00 
    67c0:	48 89 d7             	mov    %rdx,%rdi
    67c3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    67c8:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    67cd:	e8 ce f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67d2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    67d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    67dc:	e9 24 fc ff ff       	jmp    6405 <w120+0x195>
    67e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67e8:	48 89 ef             	mov    %rbp,%rdi
    67eb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    67f0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    67f5:	e8 a6 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67fa:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    67ff:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6804:	e9 bf fc ff ff       	jmp    64c8 <w120+0x258>
    6809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6810:	4c 89 ef             	mov    %r13,%rdi
    6813:	48 89 04 24          	mov    %rax,(%rsp)
    6817:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    681c:	e8 7f f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6821:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    6827:	48 8b 04 24          	mov    (%rsp),%rax
    682b:	e9 6d fd ff ff       	jmp    659d <w120+0x32d>
    6830:	48 89 c7             	mov    %rax,%rdi
    6833:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6838:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    683e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6843:	e8 58 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6848:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    684e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6853:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6858:	e9 f9 fd ff ff       	jmp    6656 <w120+0x3e6>
    685d:	0f 1f 00             	nopl   (%rax)
    6860:	48 89 c7             	mov    %rax,%rdi
    6863:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6868:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    686e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6874:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6878:	e8 23 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    687d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6883:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6889:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    688e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6893:	e9 9c fe ff ff       	jmp    6734 <w120+0x4c4>
    6898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    689f:	00 
    68a0:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    68a4:	e9 35 fa ff ff       	jmp    62de <w120+0x6e>
    68a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b0:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    68b5:	e9 fd fa ff ff       	jmp    63b7 <w120+0x147>
    68ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c0:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    68c5:	e9 c0 fb ff ff       	jmp    648a <w120+0x21a>
    68ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    68d5:	e9 7c fc ff ff       	jmp    6556 <w120+0x2e6>
    68da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68e0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    68e5:	e9 13 fd ff ff       	jmp    65fd <w120+0x38d>
    68ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68f0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    68f5:	e9 f8 fd ff ff       	jmp    66f2 <w120+0x482>
    68fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6900:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    6905:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    690a:	48 85 f6             	test   %rsi,%rsi
    690d:	79 69                	jns    6978 <w120+0x708>
    690f:	f2 0f 10 05 09 63 00 	movsd  0x6309(%rip),%xmm0        # cc20 <msg.4+0xb0>
    6916:	00 
    6917:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    691c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6923:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    692a:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    6930:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6934:	f2 0f 59 0d f4 62 00 	mulsd  0x62f4(%rip),%xmm1        # cc30 <msg.4+0xc0>
    693b:	00 
    693c:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6940:	e9 26 fe ff ff       	jmp    676b <w120+0x4fb>
    6945:	48 8d 3d 1b 58 00 00 	lea    0x581b(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    694c:	e8 5f da ff ff       	call   43b0 <fwp_trap>
    6951:	48 8d 3d 60 5f 00 00 	lea    0x5f60(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    6958:	e8 53 da ff ff       	call   43b0 <fwp_trap>
    695d:	0f 1f 00             	nopl   (%rax)
    6960:	48 8d 3d e5 57 00 00 	lea    0x57e5(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    6967:	e8 44 da ff ff       	call   43b0 <fwp_trap>
    696c:	48 8d 3d 8d 5f 00 00 	lea    0x5f8d(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    6973:	e8 38 da ff ff       	call   43b0 <fwp_trap>
    6978:	49 89 f6             	mov    %rsi,%r14
    697b:	f3 0f 7e 3d 9d 62 00 	movq   0x629d(%rip),%xmm7        # cc20 <msg.4+0xb0>
    6982:	00 
    6983:	48 89 f3             	mov    %rsi,%rbx
    6986:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    698b:	49 c1 fe 20          	sar    $0x20,%r14
    698f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6996:	e9 f3 f9 ff ff       	jmp    638e <w120+0x11e>
    699b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    69a0:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    69a5:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    69ac:	66 49 0f 7e ff       	movq   %xmm7,%r15
    69b1:	e9 60 fb ff ff       	jmp    6516 <w120+0x2a6>
    69b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69bd:	00 00 00 

00000000000069c0 <w176.constprop.0>:
    69c0:	41 55                	push   %r13
    69c2:	41 54                	push   %r12
    69c4:	55                   	push   %rbp
    69c5:	53                   	push   %rbx
    69c6:	48 83 ec 28          	sub    $0x28,%rsp
    69ca:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    69d1:	00 00 
    69d3:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    69d8:	48 8b 2f             	mov    (%rdi),%rbp
    69db:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    69e2:	ff 
    69e3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    69ea:	00 00 
    69ec:	48 85 ed             	test   %rbp,%rbp
    69ef:	74 5f                	je     6a50 <w176.constprop.0+0x90>
    69f1:	49 89 fd             	mov    %rdi,%r13
    69f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69f8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    69ff:	31 db                	xor    %ebx,%ebx
    6a01:	0f 1f 40 00          	nopl   0x0(%rax)
    6a05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a0c:	00 00 00 00 
    6a10:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    6a15:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    6a1c:	48 89 e2             	mov    %rsp,%rdx
    6a1f:	48 83 c3 02          	add    $0x2,%rbx
    6a23:	e8 38 f6 ff ff       	call   6060 <w123>
    6a28:	48 89 c7             	mov    %rax,%rdi
    6a2b:	48 39 eb             	cmp    %rbp,%rbx
    6a2e:	72 e0                	jb     6a10 <w176.constprop.0+0x50>
    6a30:	48 89 f8             	mov    %rdi,%rax
    6a33:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6a38:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6a3f:	00 00 
    6a41:	75 1a                	jne    6a5d <w176.constprop.0+0x9d>
    6a43:	48 83 c4 28          	add    $0x28,%rsp
    6a47:	5b                   	pop    %rbx
    6a48:	5d                   	pop    %rbp
    6a49:	41 5c                	pop    %r12
    6a4b:	41 5d                	pop    %r13
    6a4d:	c3                   	ret
    6a4e:	66 90                	xchg   %ax,%ax
    6a50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a57:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a5b:	eb d3                	jmp    6a30 <w176.constprop.0+0x70>
    6a5d:	e8 de c9 ff ff       	call   3440 <__stack_chk_fail@plt>
    6a62:	0f 1f 00             	nopl   (%rax)
    6a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a6c:	00 00 00 00 

0000000000006a70 <fwp_rc_share>:
    6a70:	48 8b 05 21 b1 01 00 	mov    0x1b121(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    6a77:	48 2b 3d f2 b0 01 00 	sub    0x1b0f2(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    6a7e:	48 c1 e0 10          	shl    $0x10,%rax
    6a82:	48 39 c7             	cmp    %rax,%rdi
    6a85:	73 4a                	jae    6ad1 <fwp_rc_share+0x61>
    6a87:	48 89 f8             	mov    %rdi,%rax
    6a8a:	48 c1 e8 10          	shr    $0x10,%rax
    6a8e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a92:	48 8b 05 1f b1 01 00 	mov    0x1b11f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    6a99:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a9d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6aa1:	48 85 d2             	test   %rdx,%rdx
    6aa4:	74 2b                	je     6ad1 <fwp_rc_share+0x61>
    6aa6:	0f b6 08             	movzbl (%rax),%ecx
    6aa9:	80 f9 02             	cmp    $0x2,%cl
    6aac:	74 2a                	je     6ad8 <fwp_rc_share+0x68>
    6aae:	80 f9 01             	cmp    $0x1,%cl
    6ab1:	75 1e                	jne    6ad1 <fwp_rc_share+0x61>
    6ab3:	8b 48 18             	mov    0x18(%rax),%ecx
    6ab6:	0f b7 ff             	movzwl %di,%edi
    6ab9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6abc:	48 0f af f9          	imul   %rcx,%rdi
    6ac0:	48 c1 ef 20          	shr    $0x20,%rdi
    6ac4:	48 39 c7             	cmp    %rax,%rdi
    6ac7:	73 08                	jae    6ad1 <fwp_rc_share+0x61>
    6ac9:	48 01 fa             	add    %rdi,%rdx
    6acc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6acf:	75 0d                	jne    6ade <fwp_rc_share+0x6e>
    6ad1:	c3                   	ret
    6ad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad8:	66 85 ff             	test   %di,%di
    6adb:	74 ef                	je     6acc <fwp_rc_share+0x5c>
    6add:	c3                   	ret
    6ade:	50                   	push   %rax
    6adf:	48 8d 3d 4a 5e 00 00 	lea    0x5e4a(%rip),%rdi        # c930 <_IO_stdin_used+0x930>
    6ae6:	e8 c5 d8 ff ff       	call   43b0 <fwp_trap>
    6aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006af0 <fwp_rc_free_obj>:
    6af0:	48 8b 15 a1 b0 01 00 	mov    0x1b0a1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6af7:	48 89 f8             	mov    %rdi,%rax
    6afa:	48 2b 05 6f b0 01 00 	sub    0x1b06f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6b01:	48 c1 e2 10          	shl    $0x10,%rdx
    6b05:	48 39 d0             	cmp    %rdx,%rax
    6b08:	73 5b                	jae    6b65 <fwp_rc_free_obj+0x75>
    6b0a:	48 89 c2             	mov    %rax,%rdx
    6b0d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b15:	48 8b 15 9c b0 01 00 	mov    0x1b09c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6b1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6b20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6b24:	48 85 c9             	test   %rcx,%rcx
    6b27:	74 3c                	je     6b65 <fwp_rc_free_obj+0x75>
    6b29:	0f b6 32             	movzbl (%rdx),%esi
    6b2c:	40 80 fe 02          	cmp    $0x2,%sil
    6b30:	74 2e                	je     6b60 <fwp_rc_free_obj+0x70>
    6b32:	40 80 fe 01          	cmp    $0x1,%sil
    6b36:	75 2d                	jne    6b65 <fwp_rc_free_obj+0x75>
    6b38:	8b 72 18             	mov    0x18(%rdx),%esi
    6b3b:	0f b7 c0             	movzwl %ax,%eax
    6b3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b41:	48 0f af c6          	imul   %rsi,%rax
    6b45:	48 c1 e8 20          	shr    $0x20,%rax
    6b49:	48 39 d0             	cmp    %rdx,%rax
    6b4c:	73 17                	jae    6b65 <fwp_rc_free_obj+0x75>
    6b4e:	48 01 c1             	add    %rax,%rcx
    6b51:	80 39 01             	cmpb   $0x1,(%rcx)
    6b54:	75 0f                	jne    6b65 <fwp_rc_free_obj+0x75>
    6b56:	e9 f5 eb ff ff       	jmp    5750 <fwp_mem_free>
    6b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b60:	66 85 c0             	test   %ax,%ax
    6b63:	74 ec                	je     6b51 <fwp_rc_free_obj+0x61>
    6b65:	c3                   	ret
    6b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b6d:	00 00 00 

0000000000006b70 <fwp_rc_dup>:
    6b70:	f3 0f 1e fa          	endbr64
    6b74:	48 8b 05 1d b0 01 00 	mov    0x1b01d(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    6b7b:	48 2b 3d ee af 01 00 	sub    0x1afee(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    6b82:	48 c1 e0 10          	shl    $0x10,%rax
    6b86:	48 39 c7             	cmp    %rax,%rdi
    6b89:	73 56                	jae    6be1 <fwp_rc_dup+0x71>
    6b8b:	48 89 f8             	mov    %rdi,%rax
    6b8e:	48 c1 e8 10          	shr    $0x10,%rax
    6b92:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b96:	48 8b 05 1b b0 01 00 	mov    0x1b01b(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    6b9d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6ba1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6ba5:	48 85 c0             	test   %rax,%rax
    6ba8:	74 37                	je     6be1 <fwp_rc_dup+0x71>
    6baa:	0f b6 0a             	movzbl (%rdx),%ecx
    6bad:	80 f9 02             	cmp    $0x2,%cl
    6bb0:	74 36                	je     6be8 <fwp_rc_dup+0x78>
    6bb2:	80 f9 01             	cmp    $0x1,%cl
    6bb5:	75 2a                	jne    6be1 <fwp_rc_dup+0x71>
    6bb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6bba:	0f b7 ff             	movzwl %di,%edi
    6bbd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bc0:	48 0f af f9          	imul   %rcx,%rdi
    6bc4:	48 c1 ef 20          	shr    $0x20,%rdi
    6bc8:	48 39 d7             	cmp    %rdx,%rdi
    6bcb:	73 14                	jae    6be1 <fwp_rc_dup+0x71>
    6bcd:	48 01 f8             	add    %rdi,%rax
    6bd0:	0f b6 10             	movzbl (%rax),%edx
    6bd3:	84 d2                	test   %dl,%dl
    6bd5:	74 0a                	je     6be1 <fwp_rc_dup+0x71>
    6bd7:	80 fa fd             	cmp    $0xfd,%dl
    6bda:	77 14                	ja     6bf0 <fwp_rc_dup+0x80>
    6bdc:	83 c2 01             	add    $0x1,%edx
    6bdf:	88 10                	mov    %dl,(%rax)
    6be1:	c3                   	ret
    6be2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6be8:	66 85 ff             	test   %di,%di
    6beb:	74 e3                	je     6bd0 <fwp_rc_dup+0x60>
    6bed:	c3                   	ret
    6bee:	66 90                	xchg   %ax,%ax
    6bf0:	48 89 c7             	mov    %rax,%rdi
    6bf3:	e9 f8 e7 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    6bf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bff:	00 

0000000000006c00 <fwp_owned_entry173>:
    6c00:	f3 0f 1e fa          	endbr64
    6c04:	48 83 ec 38          	sub    $0x38,%rsp
    6c08:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c0d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c14:	00 00 
    6c16:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6c1b:	31 c0                	xor    %eax,%eax
    6c1d:	48 8b 07             	mov    (%rdi),%rax
    6c20:	48 03 47 10          	add    0x10(%rdi),%rax
    6c24:	0f 80 c2 00 00 00    	jo     6cec <fwp_owned_entry173+0xec>
    6c2a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c2f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c34:	31 ff                	xor    %edi,%edi
    6c36:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c3a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c3f:	e8 2c f1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    6c44:	48 8b 15 4d af 01 00 	mov    0x1af4d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6c4b:	48 89 c6             	mov    %rax,%rsi
    6c4e:	48 2b 05 1b af 01 00 	sub    0x1af1b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6c55:	48 c1 e2 10          	shl    $0x10,%rdx
    6c59:	48 39 d0             	cmp    %rdx,%rax
    6c5c:	73 4f                	jae    6cad <fwp_owned_entry173+0xad>
    6c5e:	48 89 c2             	mov    %rax,%rdx
    6c61:	48 c1 ea 10          	shr    $0x10,%rdx
    6c65:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c69:	48 8b 15 48 af 01 00 	mov    0x1af48(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6c70:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c74:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c78:	48 85 d2             	test   %rdx,%rdx
    6c7b:	74 30                	je     6cad <fwp_owned_entry173+0xad>
    6c7d:	0f b6 39             	movzbl (%rcx),%edi
    6c80:	40 80 ff 02          	cmp    $0x2,%dil
    6c84:	74 42                	je     6cc8 <fwp_owned_entry173+0xc8>
    6c86:	40 80 ff 01          	cmp    $0x1,%dil
    6c8a:	75 21                	jne    6cad <fwp_owned_entry173+0xad>
    6c8c:	8b 79 18             	mov    0x18(%rcx),%edi
    6c8f:	0f b7 c0             	movzwl %ax,%eax
    6c92:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c95:	48 0f af c7          	imul   %rdi,%rax
    6c99:	48 c1 e8 20          	shr    $0x20,%rax
    6c9d:	48 39 c8             	cmp    %rcx,%rax
    6ca0:	73 0b                	jae    6cad <fwp_owned_entry173+0xad>
    6ca2:	48 01 c2             	add    %rax,%rdx
    6ca5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ca8:	74 26                	je     6cd0 <fwp_owned_entry173+0xd0>
    6caa:	c6 02 01             	movb   $0x1,(%rdx)
    6cad:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6cb2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cb9:	00 00 
    6cbb:	75 34                	jne    6cf1 <fwp_owned_entry173+0xf1>
    6cbd:	48 89 f0             	mov    %rsi,%rax
    6cc0:	48 83 c4 38          	add    $0x38,%rsp
    6cc4:	c3                   	ret
    6cc5:	0f 1f 00             	nopl   (%rax)
    6cc8:	66 85 c0             	test   %ax,%ax
    6ccb:	75 e0                	jne    6cad <fwp_owned_entry173+0xad>
    6ccd:	eb d6                	jmp    6ca5 <fwp_owned_entry173+0xa5>
    6ccf:	90                   	nop
    6cd0:	48 89 d7             	mov    %rdx,%rdi
    6cd3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6cd8:	48 89 14 24          	mov    %rdx,(%rsp)
    6cdc:	e8 2f e8 ff ff       	call   5510 <fwp_rc_forget_slot>
    6ce1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6ce6:	48 8b 14 24          	mov    (%rsp),%rdx
    6cea:	eb be                	jmp    6caa <fwp_owned_entry173+0xaa>
    6cec:	e8 cf c9 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6cf1:	e8 4a c7 ff ff       	call   3440 <__stack_chk_fail@plt>
    6cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cfd:	00 00 00 

0000000000006d00 <e173>:
    6d00:	f3 0f 1e fa          	endbr64
    6d04:	53                   	push   %rbx
    6d05:	48 83 ec 30          	sub    $0x30,%rsp
    6d09:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d15:	00 00 
    6d17:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6d1c:	31 c0                	xor    %eax,%eax
    6d1e:	48 8b 07             	mov    (%rdi),%rax
    6d21:	48 03 47 10          	add    0x10(%rdi),%rax
    6d25:	0f 80 c9 00 00 00    	jo     6df4 <e173+0xf4>
    6d2b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d30:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d35:	31 ff                	xor    %edi,%edi
    6d37:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d3b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d40:	e8 2b f0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    6d45:	48 8b 15 4c ae 01 00 	mov    0x1ae4c(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6d4c:	48 89 c3             	mov    %rax,%rbx
    6d4f:	48 2b 05 1a ae 01 00 	sub    0x1ae1a(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6d56:	48 c1 e2 10          	shl    $0x10,%rdx
    6d5a:	48 39 d0             	cmp    %rdx,%rax
    6d5d:	73 4f                	jae    6dae <e173+0xae>
    6d5f:	48 89 c2             	mov    %rax,%rdx
    6d62:	48 c1 ea 10          	shr    $0x10,%rdx
    6d66:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d6a:	48 8b 15 47 ae 01 00 	mov    0x1ae47(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6d71:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d75:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d79:	48 85 d2             	test   %rdx,%rdx
    6d7c:	74 30                	je     6dae <e173+0xae>
    6d7e:	0f b6 31             	movzbl (%rcx),%esi
    6d81:	40 80 fe 02          	cmp    $0x2,%sil
    6d85:	74 49                	je     6dd0 <e173+0xd0>
    6d87:	40 80 fe 01          	cmp    $0x1,%sil
    6d8b:	75 21                	jne    6dae <e173+0xae>
    6d8d:	8b 71 18             	mov    0x18(%rcx),%esi
    6d90:	0f b7 c0             	movzwl %ax,%eax
    6d93:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d96:	48 0f af c6          	imul   %rsi,%rax
    6d9a:	48 c1 e8 20          	shr    $0x20,%rax
    6d9e:	48 39 c8             	cmp    %rcx,%rax
    6da1:	73 0b                	jae    6dae <e173+0xae>
    6da3:	48 01 c2             	add    %rax,%rdx
    6da6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6da9:	74 35                	je     6de0 <e173+0xe0>
    6dab:	c6 02 01             	movb   $0x1,(%rdx)
    6dae:	48 89 df             	mov    %rbx,%rdi
    6db1:	e8 ba fc ff ff       	call   6a70 <fwp_rc_share>
    6db6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6dbb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6dc2:	00 00 
    6dc4:	75 33                	jne    6df9 <e173+0xf9>
    6dc6:	48 83 c4 30          	add    $0x30,%rsp
    6dca:	48 89 d8             	mov    %rbx,%rax
    6dcd:	5b                   	pop    %rbx
    6dce:	c3                   	ret
    6dcf:	90                   	nop
    6dd0:	66 85 c0             	test   %ax,%ax
    6dd3:	75 d9                	jne    6dae <e173+0xae>
    6dd5:	eb cf                	jmp    6da6 <e173+0xa6>
    6dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dde:	00 00 
    6de0:	48 89 d7             	mov    %rdx,%rdi
    6de3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6de8:	e8 23 e7 ff ff       	call   5510 <fwp_rc_forget_slot>
    6ded:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6df2:	eb b7                	jmp    6dab <e173+0xab>
    6df4:	e8 c7 c8 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6df9:	e8 42 c6 ff ff       	call   3440 <__stack_chk_fail@plt>
    6dfe:	66 90                	xchg   %ax,%ax

0000000000006e00 <fwp_closure_drop>:
    6e00:	48 8b 15 91 ad 01 00 	mov    0x1ad91(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6e07:	48 89 f8             	mov    %rdi,%rax
    6e0a:	48 2b 05 5f ad 01 00 	sub    0x1ad5f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6e11:	48 c1 e2 10          	shl    $0x10,%rdx
    6e15:	48 39 d0             	cmp    %rdx,%rax
    6e18:	73 6b                	jae    6e85 <fwp_closure_drop+0x85>
    6e1a:	48 89 c2             	mov    %rax,%rdx
    6e1d:	48 c1 ea 10          	shr    $0x10,%rdx
    6e21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e25:	48 8b 15 8c ad 01 00 	mov    0x1ad8c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6e2c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e30:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e34:	48 85 d2             	test   %rdx,%rdx
    6e37:	74 4c                	je     6e85 <fwp_closure_drop+0x85>
    6e39:	0f b6 31             	movzbl (%rcx),%esi
    6e3c:	40 80 fe 02          	cmp    $0x2,%sil
    6e40:	74 3e                	je     6e80 <fwp_closure_drop+0x80>
    6e42:	40 80 fe 01          	cmp    $0x1,%sil
    6e46:	75 3d                	jne    6e85 <fwp_closure_drop+0x85>
    6e48:	8b 71 18             	mov    0x18(%rcx),%esi
    6e4b:	0f b7 c0             	movzwl %ax,%eax
    6e4e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e51:	48 0f af c6          	imul   %rsi,%rax
    6e55:	48 c1 e8 20          	shr    $0x20,%rax
    6e59:	48 39 c8             	cmp    %rcx,%rax
    6e5c:	73 27                	jae    6e85 <fwp_closure_drop+0x85>
    6e5e:	48 01 c2             	add    %rax,%rdx
    6e61:	0f b6 02             	movzbl (%rdx),%eax
    6e64:	84 c0                	test   %al,%al
    6e66:	74 1d                	je     6e85 <fwp_closure_drop+0x85>
    6e68:	3c 01                	cmp    $0x1,%al
    6e6a:	74 24                	je     6e90 <fwp_closure_drop+0x90>
    6e6c:	3c ff                	cmp    $0xff,%al
    6e6e:	74 48                	je     6eb8 <fwp_closure_drop+0xb8>
    6e70:	83 e8 01             	sub    $0x1,%eax
    6e73:	88 02                	mov    %al,(%rdx)
    6e75:	c3                   	ret
    6e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e7d:	00 00 00 
    6e80:	66 85 c0             	test   %ax,%ax
    6e83:	74 dc                	je     6e61 <fwp_closure_drop+0x61>
    6e85:	c3                   	ret
    6e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e8d:	00 00 00 
    6e90:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6e97:	ff ff 
    6e99:	48 85 c0             	test   %rax,%rax
    6e9c:	74 12                	je     6eb0 <fwp_closure_drop+0xb0>
    6e9e:	48 89 fe             	mov    %rdi,%rsi
    6ea1:	48 89 c7             	mov    %rax,%rdi
    6ea4:	e9 67 d5 ff ff       	jmp    4410 <fwp_closure_drop_push>
    6ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6eb0:	e9 0b d7 ff ff       	jmp    45c0 <fwp_closure_drop.part.0>
    6eb5:	0f 1f 00             	nopl   (%rax)
    6eb8:	48 89 d0             	mov    %rdx,%rax
    6ebb:	48 8d 35 fe 98 01 00 	lea    0x198fe(%rip),%rsi        # 207c0 <fwp_heap>
    6ec2:	48 83 ec 18          	sub    $0x18,%rsp
    6ec6:	48 c1 e8 11          	shr    $0x11,%rax
    6eca:	48 31 d0             	xor    %rdx,%rax
    6ecd:	48 89 c1             	mov    %rax,%rcx
    6ed0:	48 c1 e9 09          	shr    $0x9,%rcx
    6ed4:	48 31 c8             	xor    %rcx,%rax
    6ed7:	0f b6 c8             	movzbl %al,%ecx
    6eda:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6ee1:	00 
    6ee2:	48 85 c0             	test   %rax,%rax
    6ee5:	75 22                	jne    6f09 <fwp_closure_drop+0x109>
    6ee7:	eb 59                	jmp    6f42 <fwp_closure_drop+0x142>
    6ee9:	90                   	nop
    6eea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ef1:	00 00 00 00 
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f04:	48 85 c0             	test   %rax,%rax
    6f07:	74 39                	je     6f42 <fwp_closure_drop+0x142>
    6f09:	48 89 c1             	mov    %rax,%rcx
    6f0c:	48 39 10             	cmp    %rdx,(%rax)
    6f0f:	75 ef                	jne    6f00 <fwp_closure_drop+0x100>
    6f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f24:	74 05                	je     6f2b <fwp_closure_drop+0x12b>
    6f26:	48 83 c4 18          	add    $0x18,%rsp
    6f2a:	c3                   	ret
    6f2b:	48 89 d7             	mov    %rdx,%rdi
    6f2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f33:	e8 d8 e5 ff ff       	call   5510 <fwp_rc_forget_slot>
    6f38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f3d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f40:	eb e4                	jmp    6f26 <fwp_closure_drop+0x126>
    6f42:	48 8d 3d 47 59 00 00 	lea    0x5947(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    6f49:	e8 62 d4 ff ff       	call   43b0 <fwp_trap>
    6f4e:	66 90                	xchg   %ax,%ax

0000000000006f50 <fwp_owned_tape_release>:
    6f50:	48 85 ff             	test   %rdi,%rdi
    6f53:	0f 84 f7 00 00 00    	je     7050 <fwp_owned_tape_release+0x100>
    6f59:	41 54                	push   %r12
    6f5b:	55                   	push   %rbp
    6f5c:	53                   	push   %rbx
    6f5d:	48 8b 07             	mov    (%rdi),%rax
    6f60:	48 85 c0             	test   %rax,%rax
    6f63:	74 08                	je     6f6d <fwp_owned_tape_release+0x1d>
    6f65:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f6d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f71:	48 85 d2             	test   %rdx,%rdx
    6f74:	74 03                	je     6f79 <fwp_owned_tape_release+0x29>
    6f76:	48 89 02             	mov    %rax,(%rdx)
    6f79:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6f7d:	48 89 fb             	mov    %rdi,%rbx
    6f80:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6f84:	48 85 c0             	test   %rax,%rax
    6f87:	0f 84 89 00 00 00    	je     7016 <fwp_owned_tape_release+0xc6>
    6f8d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6f91:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6f95:	7e 47                	jle    6fde <fwp_owned_tape_release+0x8e>
    6f97:	31 ed                	xor    %ebp,%ebp
    6f99:	eb 0d                	jmp    6fa8 <fwp_owned_tape_release+0x58>
    6f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6fa0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6fa4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6fa8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6fac:	49 89 ec             	mov    %rbp,%r12
    6faf:	48 83 c5 01          	add    $0x1,%rbp
    6fb3:	49 c1 e4 04          	shl    $0x4,%r12
    6fb7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6fbb:	ff d0                	call   *%rax
    6fbd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6fc1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6fc6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6fca:	ff 50 68             	call   *0x68(%rax)
    6fcd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6fd1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6fd5:	48 39 e8             	cmp    %rbp,%rax
    6fd8:	7f c6                	jg     6fa0 <fwp_owned_tape_release+0x50>
    6fda:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6fde:	31 ed                	xor    %ebp,%ebp
    6fe0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6fe5:	7e 28                	jle    700f <fwp_owned_tape_release+0xbf>
    6fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fee:	00 00 
    6ff0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6ff4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6ff8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6ffc:	74 07                	je     7005 <fwp_owned_tape_release+0xb5>
    6ffe:	ff 52 68             	call   *0x68(%rdx)
    7001:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7005:	48 83 c5 01          	add    $0x1,%rbp
    7009:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    700d:	7f e1                	jg     6ff0 <fwp_owned_tape_release+0xa0>
    700f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7013:	ff 52 68             	call   *0x68(%rdx)
    7016:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    701a:	e8 e1 fd ff ff       	call   6e00 <fwp_closure_drop>
    701f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7023:	e8 d8 fd ff ff       	call   6e00 <fwp_closure_drop>
    7028:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    702c:	e8 cf fd ff ff       	call   6e00 <fwp_closure_drop>
    7031:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7035:	e8 16 e7 ff ff       	call   5750 <fwp_mem_free>
    703a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    703e:	e8 0d e7 ff ff       	call   5750 <fwp_mem_free>
    7043:	48 89 df             	mov    %rbx,%rdi
    7046:	5b                   	pop    %rbx
    7047:	5d                   	pop    %rbp
    7048:	41 5c                	pop    %r12
    704a:	e9 01 e7 ff ff       	jmp    5750 <fwp_mem_free>
    704f:	90                   	nop
    7050:	c3                   	ret
    7051:	0f 1f 40 00          	nopl   0x0(%rax)
    7055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    705c:	00 00 00 00 

0000000000007060 <fwp_tape_finish>:
    7060:	f3 0f 1e fa          	endbr64
    7064:	41 56                	push   %r14
    7066:	48 8d 3d 33 90 01 00 	lea    0x19033(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    706d:	41 55                	push   %r13
    706f:	41 54                	push   %r12
    7071:	55                   	push   %rbp
    7072:	53                   	push   %rbx
    7073:	e8 58 d0 ff ff       	call   40d0 <fwp_tape_buffers_dispose>
    7078:	48 83 3d 58 90 01 00 	cmpq   $0x0,0x19058(%rip)        # 200d8 <fwp_ntapes>
    707f:	00 
    7080:	48 c7 05 fd 8f 01 00 	movq   $0x0,0x18ffd(%rip)        # 20088 <fwp_tape_cached_bytes>
    7087:	00 00 00 00 
    708b:	7e 68                	jle    70f5 <fwp_tape_finish+0x95>
    708d:	45 31 e4             	xor    %r12d,%r12d
    7090:	31 ed                	xor    %ebp,%ebp
    7092:	0f 1f 00             	nopl   (%rax)
    7095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    709c:	00 00 00 00 
    70a0:	48 8b 1d 39 90 01 00 	mov    0x19039(%rip),%rbx        # 200e0 <fwp_tapes>
    70a7:	48 83 c5 01          	add    $0x1,%rbp
    70ab:	4c 01 e3             	add    %r12,%rbx
    70ae:	49 83 c4 58          	add    $0x58,%r12
    70b2:	48 89 df             	mov    %rbx,%rdi
    70b5:	e8 06 cb ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    70ba:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    70be:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    70c2:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
    70c6:	e8 d5 c2 ff ff       	call   33a0 <free@plt>
    70cb:	4c 89 f7             	mov    %r14,%rdi
    70ce:	e8 cd c2 ff ff       	call   33a0 <free@plt>
    70d3:	4c 89 ef             	mov    %r13,%rdi
    70d6:	e8 c5 c2 ff ff       	call   33a0 <free@plt>
    70db:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    70df:	e8 6c fe ff ff       	call   6f50 <fwp_owned_tape_release>
    70e4:	48 39 2d ed 8f 01 00 	cmp    %rbp,0x18fed(%rip)        # 200d8 <fwp_ntapes>
    70eb:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    70f2:	00 
    70f3:	7f ab                	jg     70a0 <fwp_tape_finish+0x40>
    70f5:	48 8b 3d e4 8f 01 00 	mov    0x18fe4(%rip),%rdi        # 200e0 <fwp_tapes>
    70fc:	e8 9f c2 ff ff       	call   33a0 <free@plt>
    7101:	5b                   	pop    %rbx
    7102:	5d                   	pop    %rbp
    7103:	48 c7 05 d2 8f 01 00 	movq   $0x0,0x18fd2(%rip)        # 200e0 <fwp_tapes>
    710a:	00 00 00 00 
    710e:	48 c7 05 b7 8f 01 00 	movq   $0x0,0x18fb7(%rip)        # 200d0 <fwp_tapes_cap>
    7115:	00 00 00 00 
    7119:	41 5c                	pop    %r12
    711b:	48 c7 05 b2 8f 01 00 	movq   $0x0,0x18fb2(%rip)        # 200d8 <fwp_ntapes>
    7122:	00 00 00 00 
    7126:	41 5d                	pop    %r13
    7128:	48 c7 05 95 8f 01 00 	movq   $0x0,0x18f95(%rip)        # 200c8 <fwp_tape_next_slot>
    712f:	00 00 00 00 
    7133:	41 5e                	pop    %r14
    7135:	c3                   	ret
    7136:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    713d:	00 00 00 

0000000000007140 <fwp_tape_scope_release>:
    7140:	f3 0f 1e fa          	endbr64
    7144:	41 55                	push   %r13
    7146:	41 54                	push   %r12
    7148:	55                   	push   %rbp
    7149:	53                   	push   %rbx
    714a:	48 83 ec 48          	sub    $0x48,%rsp
    714e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7155:	00 00 
    7157:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    715c:	48 63 07             	movslq (%rdi),%rax
    715f:	85 c0                	test   %eax,%eax
    7161:	0f 88 f8 00 00 00    	js     725f <fwp_tape_scope_release+0x11f>
    7167:	48 bd a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%rbp
    716e:	a2 8b 2e 
    7171:	48 89 fb             	mov    %rdi,%rbx
    7174:	eb 3d                	jmp    71b3 <fwp_tape_scope_release+0x73>
    7176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    717d:	00 00 00 
    7180:	66 48 0f 7e c7       	movq   %xmm0,%rdi
    7185:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7189:	e8 12 c2 ff ff       	call   33a0 <free@plt>
    718e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7193:	e8 08 c2 ff ff       	call   33a0 <free@plt>
    7198:	4c 89 ef             	mov    %r13,%rdi
    719b:	e8 00 c2 ff ff       	call   33a0 <free@plt>
    71a0:	4c 89 e7             	mov    %r12,%rdi
    71a3:	e8 a8 fd ff ff       	call   6f50 <fwp_owned_tape_release>
    71a8:	48 63 03             	movslq (%rbx),%rax
    71ab:	85 c0                	test   %eax,%eax
    71ad:	0f 88 ac 00 00 00    	js     725f <fwp_tape_scope_release+0x11f>
    71b3:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    71b7:	48 8b 35 22 8f 01 00 	mov    0x18f22(%rip),%rsi        # 200e0 <fwp_tapes>
    71be:	4c 01 c6             	add    %r8,%rsi
    71c1:	48 89 f7             	mov    %rsi,%rdi
    71c4:	e8 f7 c9 ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    71c9:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    71ce:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
    71d2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    71d9:	f3 0f 7e 4e 18       	movq   0x18(%rsi),%xmm1
    71de:	0f 16 4e 38          	movhps 0x38(%rsi),%xmm1
    71e2:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
    71e7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    71eb:	4c 8b 66 50          	mov    0x50(%rsi),%r12
    71ef:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
    71f4:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    71fb:	00 
    71fc:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    7203:	00 
    7204:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    720b:	00 
    720c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7213:	00 
    7214:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7219:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    721d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    7221:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7227:	77 18                	ja     7241 <fwp_tape_scope_release+0x101>
    7229:	49 c1 f8 03          	sar    $0x3,%r8
    722d:	4c 0f af c5          	imul   %rbp,%r8
    7231:	4c 3b 05 90 8e 01 00 	cmp    0x18e90(%rip),%r8        # 200c8 <fwp_tape_next_slot>
    7238:	7d 07                	jge    7241 <fwp_tape_scope_release+0x101>
    723a:	4c 89 05 87 8e 01 00 	mov    %r8,0x18e87(%rip)        # 200c8 <fwp_tape_next_slot>
    7241:	4d 85 e4             	test   %r12,%r12
    7244:	0f 85 36 ff ff ff    	jne    7180 <fwp_tape_scope_release+0x40>
    724a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    724f:	e8 dc dd ff ff       	call   5030 <fwp_tape_buffers_release>
    7254:	48 63 03             	movslq (%rbx),%rax
    7257:	85 c0                	test   %eax,%eax
    7259:	0f 89 54 ff ff ff    	jns    71b3 <fwp_tape_scope_release+0x73>
    725f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7264:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    726b:	00 00 
    726d:	75 0b                	jne    727a <fwp_tape_scope_release+0x13a>
    726f:	48 83 c4 48          	add    $0x48,%rsp
    7273:	5b                   	pop    %rbx
    7274:	5d                   	pop    %rbp
    7275:	41 5c                	pop    %r12
    7277:	41 5d                	pop    %r13
    7279:	c3                   	ret
    727a:	e8 c1 c1 ff ff       	call   3440 <__stack_chk_fail@plt>
    727f:	90                   	nop

0000000000007280 <fwp_drop4>:
    7280:	48 8b 0d 11 a9 01 00 	mov    0x1a911(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    7287:	48 89 f8             	mov    %rdi,%rax
    728a:	48 2b 05 df a8 01 00 	sub    0x1a8df(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7291:	48 c1 e1 10          	shl    $0x10,%rcx
    7295:	48 39 c8             	cmp    %rcx,%rax
    7298:	0f 83 42 01 00 00    	jae    73e0 <fwp_drop4+0x160>
    729e:	48 83 ec 18          	sub    $0x18,%rsp
    72a2:	48 89 fa             	mov    %rdi,%rdx
    72a5:	4c 8d 05 14 95 01 00 	lea    0x19514(%rip),%r8        # 207c0 <fwp_heap>
    72ac:	48 89 c1             	mov    %rax,%rcx
    72af:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    72b6:	48 c1 e9 10          	shr    $0x10,%rcx
    72ba:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    72be:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    72c2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72c6:	48 85 c9             	test   %rcx,%rcx
    72c9:	74 40                	je     730b <fwp_drop4+0x8b>
    72cb:	0f b6 3e             	movzbl (%rsi),%edi
    72ce:	40 80 ff 02          	cmp    $0x2,%dil
    72d2:	74 3c                	je     7310 <fwp_drop4+0x90>
    72d4:	40 80 ff 01          	cmp    $0x1,%dil
    72d8:	75 31                	jne    730b <fwp_drop4+0x8b>
    72da:	8b 7e 18             	mov    0x18(%rsi),%edi
    72dd:	0f b7 c0             	movzwl %ax,%eax
    72e0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    72e3:	48 0f af c7          	imul   %rdi,%rax
    72e7:	48 c1 e8 20          	shr    $0x20,%rax
    72eb:	48 39 f0             	cmp    %rsi,%rax
    72ee:	73 1b                	jae    730b <fwp_drop4+0x8b>
    72f0:	48 01 c1             	add    %rax,%rcx
    72f3:	0f b6 01             	movzbl (%rcx),%eax
    72f6:	84 c0                	test   %al,%al
    72f8:	74 11                	je     730b <fwp_drop4+0x8b>
    72fa:	3c 01                	cmp    $0x1,%al
    72fc:	74 22                	je     7320 <fwp_drop4+0xa0>
    72fe:	3c ff                	cmp    $0xff,%al
    7300:	0f 84 0a 01 00 00    	je     7410 <fwp_drop4+0x190>
    7306:	83 e8 01             	sub    $0x1,%eax
    7309:	88 01                	mov    %al,(%rcx)
    730b:	48 83 c4 18          	add    $0x18,%rsp
    730f:	c3                   	ret
    7310:	66 85 c0             	test   %ax,%ax
    7313:	74 de                	je     72f3 <fwp_drop4+0x73>
    7315:	48 83 c4 18          	add    $0x18,%rsp
    7319:	c3                   	ret
    731a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7320:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7324:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    732b:	48 89 f8             	mov    %rdi,%rax
    732e:	48 c1 e1 10          	shl    $0x10,%rcx
    7332:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7339:	48 39 c8             	cmp    %rcx,%rax
    733c:	73 62                	jae    73a0 <fwp_drop4+0x120>
    733e:	48 89 c1             	mov    %rax,%rcx
    7341:	48 c1 e9 10          	shr    $0x10,%rcx
    7345:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7349:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    734d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7351:	48 85 c9             	test   %rcx,%rcx
    7354:	74 4a                	je     73a0 <fwp_drop4+0x120>
    7356:	44 0f b6 0e          	movzbl (%rsi),%r9d
    735a:	41 80 f9 02          	cmp    $0x2,%r9b
    735e:	0f 84 9c 00 00 00    	je     7400 <fwp_drop4+0x180>
    7364:	41 80 f9 01          	cmp    $0x1,%r9b
    7368:	75 36                	jne    73a0 <fwp_drop4+0x120>
    736a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    736e:	0f b7 c0             	movzwl %ax,%eax
    7371:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7374:	49 0f af c1          	imul   %r9,%rax
    7378:	48 c1 e8 20          	shr    $0x20,%rax
    737c:	48 39 f0             	cmp    %rsi,%rax
    737f:	73 1f                	jae    73a0 <fwp_drop4+0x120>
    7381:	48 01 c1             	add    %rax,%rcx
    7384:	0f b6 01             	movzbl (%rcx),%eax
    7387:	84 c0                	test   %al,%al
    7389:	74 15                	je     73a0 <fwp_drop4+0x120>
    738b:	3c 01                	cmp    $0x1,%al
    738d:	74 59                	je     73e8 <fwp_drop4+0x168>
    738f:	3c ff                	cmp    $0xff,%al
    7391:	0f 84 ef 00 00 00    	je     7486 <fwp_drop4+0x206>
    7397:	83 e8 01             	sub    $0x1,%eax
    739a:	88 01                	mov    %al,(%rcx)
    739c:	0f 1f 40 00          	nopl   0x0(%rax)
    73a0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    73a4:	48 89 d7             	mov    %rdx,%rdi
    73a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    73ab:	e8 40 f7 ff ff       	call   6af0 <fwp_rc_free_obj>
    73b0:	4c 8d 05 09 94 01 00 	lea    0x19409(%rip),%r8        # 207c0 <fwp_heap>
    73b7:	48 8b 04 24          	mov    (%rsp),%rax
    73bb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    73c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73c9:	48 c1 e2 10          	shl    $0x10,%rdx
    73cd:	48 39 d0             	cmp    %rdx,%rax
    73d0:	0f 83 35 ff ff ff    	jae    730b <fwp_drop4+0x8b>
    73d6:	48 8b 14 24          	mov    (%rsp),%rdx
    73da:	e9 cd fe ff ff       	jmp    72ac <fwp_drop4+0x2c>
    73df:	90                   	nop
    73e0:	c3                   	ret
    73e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73e8:	48 89 14 24          	mov    %rdx,(%rsp)
    73ec:	e8 ff f6 ff ff       	call   6af0 <fwp_rc_free_obj>
    73f1:	48 8b 14 24          	mov    (%rsp),%rdx
    73f5:	eb a9                	jmp    73a0 <fwp_drop4+0x120>
    73f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73fe:	00 00 
    7400:	66 85 c0             	test   %ax,%ax
    7403:	75 9b                	jne    73a0 <fwp_drop4+0x120>
    7405:	e9 7a ff ff ff       	jmp    7384 <fwp_drop4+0x104>
    740a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7410:	48 89 c8             	mov    %rcx,%rax
    7413:	48 c1 e8 11          	shr    $0x11,%rax
    7417:	48 31 c8             	xor    %rcx,%rax
    741a:	48 89 c2             	mov    %rax,%rdx
    741d:	48 c1 ea 09          	shr    $0x9,%rdx
    7421:	48 31 d0             	xor    %rdx,%rax
    7424:	0f b6 d0             	movzbl %al,%edx
    7427:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    742e:	00 
    742f:	48 85 c0             	test   %rax,%rax
    7432:	75 19                	jne    744d <fwp_drop4+0x1cd>
    7434:	e9 d3 00 00 00       	jmp    750c <fwp_drop4+0x28c>
    7439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7440:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7444:	48 85 c0             	test   %rax,%rax
    7447:	0f 84 bf 00 00 00    	je     750c <fwp_drop4+0x28c>
    744d:	48 89 c2             	mov    %rax,%rdx
    7450:	48 39 08             	cmp    %rcx,(%rax)
    7453:	75 eb                	jne    7440 <fwp_drop4+0x1c0>
    7455:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7459:	48 83 ea 01          	sub    $0x1,%rdx
    745d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7461:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7468:	0f 85 9d fe ff ff    	jne    730b <fwp_drop4+0x8b>
    746e:	48 89 cf             	mov    %rcx,%rdi
    7471:	48 89 0c 24          	mov    %rcx,(%rsp)
    7475:	e8 96 e0 ff ff       	call   5510 <fwp_rc_forget_slot>
    747a:	48 8b 0c 24          	mov    (%rsp),%rcx
    747e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7481:	e9 85 fe ff ff       	jmp    730b <fwp_drop4+0x8b>
    7486:	48 89 ce             	mov    %rcx,%rsi
    7489:	48 c1 ee 11          	shr    $0x11,%rsi
    748d:	48 31 ce             	xor    %rcx,%rsi
    7490:	48 89 f0             	mov    %rsi,%rax
    7493:	48 c1 e8 09          	shr    $0x9,%rax
    7497:	48 31 c6             	xor    %rax,%rsi
    749a:	40 0f b6 f6          	movzbl %sil,%esi
    749e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    74a5:	00 
    74a6:	48 85 c0             	test   %rax,%rax
    74a9:	75 1e                	jne    74c9 <fwp_drop4+0x249>
    74ab:	eb 5f                	jmp    750c <fwp_drop4+0x28c>
    74ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74b4:	00 
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 43                	je     750c <fwp_drop4+0x28c>
    74c9:	48 89 c6             	mov    %rax,%rsi
    74cc:	48 39 08             	cmp    %rcx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_drop4+0x240>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 83 ee 01          	sub    $0x1,%rsi
    74d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    74dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    74e4:	0f 85 b6 fe ff ff    	jne    73a0 <fwp_drop4+0x120>
    74ea:	48 89 cf             	mov    %rcx,%rdi
    74ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    74f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    74f6:	e8 15 e0 ff ff       	call   5510 <fwp_rc_forget_slot>
    74fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    74ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7504:	c6 01 fe             	movb   $0xfe,(%rcx)
    7507:	e9 94 fe ff ff       	jmp    73a0 <fwp_drop4+0x120>
    750c:	48 8d 3d 7d 53 00 00 	lea    0x537d(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7513:	e8 98 ce ff ff       	call   43b0 <fwp_trap>
    7518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    751f:	00 

0000000000007520 <fwp_arg_drop37>:
    7520:	f3 0f 1e fa          	endbr64
    7524:	85 f6                	test   %esi,%esi
    7526:	75 04                	jne    752c <fwp_arg_drop37+0xc>
    7528:	85 d2                	test   %edx,%edx
    752a:	75 04                	jne    7530 <fwp_arg_drop37+0x10>
    752c:	c3                   	ret
    752d:	0f 1f 00             	nopl   (%rax)
    7530:	48 8b 3f             	mov    (%rdi),%rdi
    7533:	e9 48 fd ff ff       	jmp    7280 <fwp_drop4>
    7538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    753f:	00 

0000000000007540 <fwp_task_dispose>:
    7540:	53                   	push   %rbx
    7541:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7545:	0f 84 bb c1 ff ff    	je     3706 <fwp_task_dispose.cold>
    754b:	48 89 fb             	mov    %rdi,%rbx
    754e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7553:	0f 85 ad c1 ff ff    	jne    3706 <fwp_task_dispose.cold>
    7559:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    755d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7564:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    756b:	00 
    756c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7570:	48 85 ff             	test   %rdi,%rdi
    7573:	74 07                	je     757c <fwp_task_dispose+0x3c>
    7575:	48 85 c0             	test   %rax,%rax
    7578:	74 02                	je     757c <fwp_task_dispose+0x3c>
    757a:	ff d0                	call   *%rax
    757c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7583:	e8 c8 e1 ff ff       	call   5750 <fwp_mem_free>
    7588:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    758f:	00 00 00 00 
    7593:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7597:	74 6f                	je     7608 <fwp_task_dispose+0xc8>
    7599:	48 8b 15 f8 a5 01 00 	mov    0x1a5f8(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    75a0:	48 89 d8             	mov    %rbx,%rax
    75a3:	48 2b 05 c6 a5 01 00 	sub    0x1a5c6(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    75aa:	48 c1 e2 10          	shl    $0x10,%rdx
    75ae:	48 39 d0             	cmp    %rdx,%rax
    75b1:	73 4c                	jae    75ff <fwp_task_dispose+0xbf>
    75b3:	48 89 c2             	mov    %rax,%rdx
    75b6:	48 c1 ea 10          	shr    $0x10,%rdx
    75ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75be:	48 8b 15 f3 a5 01 00 	mov    0x1a5f3(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    75c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75c9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75cd:	48 85 c9             	test   %rcx,%rcx
    75d0:	74 2d                	je     75ff <fwp_task_dispose+0xbf>
    75d2:	0f b6 32             	movzbl (%rdx),%esi
    75d5:	40 80 fe 02          	cmp    $0x2,%sil
    75d9:	74 3d                	je     7618 <fwp_task_dispose+0xd8>
    75db:	40 80 fe 01          	cmp    $0x1,%sil
    75df:	75 1e                	jne    75ff <fwp_task_dispose+0xbf>
    75e1:	8b 72 18             	mov    0x18(%rdx),%esi
    75e4:	0f b7 c0             	movzwl %ax,%eax
    75e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    75ea:	48 0f af c6          	imul   %rsi,%rax
    75ee:	48 c1 e8 20          	shr    $0x20,%rax
    75f2:	48 39 d0             	cmp    %rdx,%rax
    75f5:	73 08                	jae    75ff <fwp_task_dispose+0xbf>
    75f7:	48 01 c1             	add    %rax,%rcx
    75fa:	80 39 01             	cmpb   $0x1,(%rcx)
    75fd:	74 09                	je     7608 <fwp_task_dispose+0xc8>
    75ff:	5b                   	pop    %rbx
    7600:	c3                   	ret
    7601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7608:	48 89 df             	mov    %rbx,%rdi
    760b:	5b                   	pop    %rbx
    760c:	e9 3f e1 ff ff       	jmp    5750 <fwp_mem_free>
    7611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7618:	66 85 c0             	test   %ax,%ax
    761b:	74 dd                	je     75fa <fwp_task_dispose+0xba>
    761d:	5b                   	pop    %rbx
    761e:	c3                   	ret
    761f:	90                   	nop

0000000000007620 <fwp_free_zombie>:
    7620:	48 8b 15 69 91 01 00 	mov    0x19169(%rip),%rdx        # 20790 <fwp_zombie>
    7627:	48 85 d2             	test   %rdx,%rdx
    762a:	0f 84 98 00 00 00    	je     76c8 <fwp_free_zombie+0xa8>
    7630:	48 3b 15 69 91 01 00 	cmp    0x19169(%rip),%rdx        # 207a0 <fwp_cur>
    7637:	0f 84 8b 00 00 00    	je     76c8 <fwp_free_zombie+0xa8>
    763d:	48 83 ec 18          	sub    $0x18,%rsp
    7641:	48 63 05 1c 8b 01 00 	movslq 0x18b1c(%rip),%rax        # 20164 <fwp_stack_pool_n>
    7648:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    764c:	83 f8 3f             	cmp    $0x3f,%eax
    764f:	7f 7f                	jg     76d0 <fwp_free_zombie+0xb0>
    7651:	8d 48 01             	lea    0x1(%rax),%ecx
    7654:	89 0d 0a 8b 01 00    	mov    %ecx,0x18b0a(%rip)        # 20164 <fwp_stack_pool_n>
    765a:	48 8d 0d 1f 8b 01 00 	lea    0x18b1f(%rip),%rcx        # 20180 <fwp_stack_pool>
    7661:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7665:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    766c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7670:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7677:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    767b:	48 85 c9             	test   %rcx,%rcx
    767e:	0f 84 fc 00 00 00    	je     7780 <fwp_free_zombie+0x160>
    7684:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    768b:	48 85 c0             	test   %rax,%rax
    768e:	74 07                	je     7697 <fwp_free_zombie+0x77>
    7690:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7697:	8b 42 5c             	mov    0x5c(%rdx),%eax
    769a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    769e:	48 c7 05 e7 90 01 00 	movq   $0x0,0x190e7(%rip)        # 20790 <fwp_zombie>
    76a5:	00 00 00 00 
    76a9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    76b0:	85 c0                	test   %eax,%eax
    76b2:	74 34                	je     76e8 <fwp_free_zombie+0xc8>
    76b4:	83 f8 01             	cmp    $0x1,%eax
    76b7:	0f 84 b3 00 00 00    	je     7770 <fwp_free_zombie+0x150>
    76bd:	48 83 c4 18          	add    $0x18,%rsp
    76c1:	c3                   	ret
    76c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76c8:	c3                   	ret
    76c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    76d4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    76d9:	e8 d2 be ff ff       	call   35b0 <munmap@plt>
    76de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    76e3:	eb 80                	jmp    7665 <fwp_free_zombie+0x45>
    76e5:	0f 1f 00             	nopl   (%rax)
    76e8:	48 8b 0d a9 a4 01 00 	mov    0x1a4a9(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    76ef:	48 89 d0             	mov    %rdx,%rax
    76f2:	48 2b 05 77 a4 01 00 	sub    0x1a477(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    76f9:	48 c1 e1 10          	shl    $0x10,%rcx
    76fd:	48 39 c8             	cmp    %rcx,%rax
    7700:	73 bb                	jae    76bd <fwp_free_zombie+0x9d>
    7702:	48 89 c1             	mov    %rax,%rcx
    7705:	48 c1 e9 10          	shr    $0x10,%rcx
    7709:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    770d:	48 8b 0d a4 a4 01 00 	mov    0x1a4a4(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7714:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7718:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    771c:	48 85 c9             	test   %rcx,%rcx
    771f:	74 9c                	je     76bd <fwp_free_zombie+0x9d>
    7721:	0f b6 3e             	movzbl (%rsi),%edi
    7724:	40 80 ff 02          	cmp    $0x2,%dil
    7728:	74 66                	je     7790 <fwp_free_zombie+0x170>
    772a:	40 80 ff 01          	cmp    $0x1,%dil
    772e:	75 8d                	jne    76bd <fwp_free_zombie+0x9d>
    7730:	8b 7e 18             	mov    0x18(%rsi),%edi
    7733:	0f b7 c0             	movzwl %ax,%eax
    7736:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7739:	48 0f af c7          	imul   %rdi,%rax
    773d:	48 c1 e8 20          	shr    $0x20,%rax
    7741:	48 39 f0             	cmp    %rsi,%rax
    7744:	0f 83 73 ff ff ff    	jae    76bd <fwp_free_zombie+0x9d>
    774a:	48 01 c1             	add    %rax,%rcx
    774d:	0f b6 01             	movzbl (%rcx),%eax
    7750:	84 c0                	test   %al,%al
    7752:	0f 84 65 ff ff ff    	je     76bd <fwp_free_zombie+0x9d>
    7758:	3c 01                	cmp    $0x1,%al
    775a:	74 14                	je     7770 <fwp_free_zombie+0x150>
    775c:	3c ff                	cmp    $0xff,%al
    775e:	74 3b                	je     779b <fwp_free_zombie+0x17b>
    7760:	83 e8 01             	sub    $0x1,%eax
    7763:	88 01                	mov    %al,(%rcx)
    7765:	e9 53 ff ff ff       	jmp    76bd <fwp_free_zombie+0x9d>
    776a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7770:	48 89 d7             	mov    %rdx,%rdi
    7773:	48 83 c4 18          	add    $0x18,%rsp
    7777:	e9 c4 fd ff ff       	jmp    7540 <fwp_task_dispose>
    777c:	0f 1f 40 00          	nopl   0x0(%rax)
    7780:	48 89 05 e1 8f 01 00 	mov    %rax,0x18fe1(%rip)        # 20768 <fwp_tasks_active>
    7787:	e9 ff fe ff ff       	jmp    768b <fwp_free_zombie+0x6b>
    778c:	0f 1f 40 00          	nopl   0x0(%rax)
    7790:	66 85 c0             	test   %ax,%ax
    7793:	0f 85 24 ff ff ff    	jne    76bd <fwp_free_zombie+0x9d>
    7799:	eb b2                	jmp    774d <fwp_free_zombie+0x12d>
    779b:	48 89 ca             	mov    %rcx,%rdx
    779e:	48 8d 35 1b 90 01 00 	lea    0x1901b(%rip),%rsi        # 207c0 <fwp_heap>
    77a5:	48 c1 ea 11          	shr    $0x11,%rdx
    77a9:	48 31 ca             	xor    %rcx,%rdx
    77ac:	48 89 d0             	mov    %rdx,%rax
    77af:	48 c1 e8 09          	shr    $0x9,%rax
    77b3:	48 31 c2             	xor    %rax,%rdx
    77b6:	0f b6 d2             	movzbl %dl,%edx
    77b9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    77c0:	00 
    77c1:	48 85 c0             	test   %rax,%rax
    77c4:	75 23                	jne    77e9 <fwp_free_zombie+0x1c9>
    77c6:	eb 5c                	jmp    7824 <fwp_free_zombie+0x204>
    77c8:	66 90                	xchg   %ax,%ax
    77ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77d1:	00 00 00 00 
    77d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77dc:	00 00 00 00 
    77e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    77e4:	48 85 c0             	test   %rax,%rax
    77e7:	74 3b                	je     7824 <fwp_free_zombie+0x204>
    77e9:	48 89 c2             	mov    %rax,%rdx
    77ec:	48 39 08             	cmp    %rcx,(%rax)
    77ef:	75 ef                	jne    77e0 <fwp_free_zombie+0x1c0>
    77f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    77f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    77fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7804:	0f 85 b3 fe ff ff    	jne    76bd <fwp_free_zombie+0x9d>
    780a:	48 89 cf             	mov    %rcx,%rdi
    780d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7812:	e8 f9 dc ff ff       	call   5510 <fwp_rc_forget_slot>
    7817:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    781c:	c6 01 fe             	movb   $0xfe,(%rcx)
    781f:	e9 99 fe ff ff       	jmp    76bd <fwp_free_zombie+0x9d>
    7824:	48 8d 3d 65 50 00 00 	lea    0x5065(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    782b:	e8 80 cb ff ff       	call   43b0 <fwp_trap>

0000000000007830 <fwp_block>:
    7830:	48 83 ec 08          	sub    $0x8,%rsp
    7834:	48 8b 05 4d 8f 01 00 	mov    0x18f4d(%rip),%rax        # 20788 <fwp_ready_head>
    783b:	48 85 c0             	test   %rax,%rax
    783e:	0f 84 1c 01 00 00    	je     7960 <fwp_block+0x130>
    7844:	90                   	nop
    7845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    784c:	00 00 00 00 
    7850:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7857:	48 89 15 2a 8f 01 00 	mov    %rdx,0x18f2a(%rip)        # 20788 <fwp_ready_head>
    785e:	48 85 d2             	test   %rdx,%rdx
    7861:	0f 84 19 01 00 00    	je     7980 <fwp_block+0x150>
    7867:	48 8b 15 32 8f 01 00 	mov    0x18f32(%rip),%rdx        # 207a0 <fwp_cur>
    786e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7872:	48 39 c2             	cmp    %rax,%rdx
    7875:	0f 84 d5 00 00 00    	je     7950 <fwp_block+0x120>
    787b:	48 8b 0d a6 ab 01 00 	mov    0x1aba6(%rip),%rcx        # 22428 <fwp_state_owners>
    7882:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7886:	48 89 05 13 8f 01 00 	mov    %rax,0x18f13(%rip)        # 207a0 <fwp_cur>
    788d:	f3 0f 7e 05 bb ab 01 	movq   0x1abbb(%rip),%xmm0        # 22450 <fwp_foreign_callbacks>
    7894:	00 
    7895:	0f 16 05 a4 ab 01 00 	movhps 0x1aba4(%rip),%xmm0        # 22440 <fwp_state>
    789c:	f3 0f 7e 0d a4 ab 01 	movq   0x1aba4(%rip),%xmm1        # 22448 <fwp_handlers>
    78a3:	00 
    78a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    78ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    78b2:	0f 16 0d 9f ab 01 00 	movhps 0x1ab9f(%rip),%xmm1        # 22458 <fwp_cleanups>
    78b9:	f3 0f 7e 05 77 ab 01 	movq   0x1ab77(%rip),%xmm0        # 22438 <fwp_state_len>
    78c0:	00 
    78c1:	0f 16 05 68 ab 01 00 	movhps 0x1ab68(%rip),%xmm0        # 22430 <fwp_state_cap>
    78c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    78cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    78d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    78e1:	48 89 0d 60 ab 01 00 	mov    %rcx,0x1ab60(%rip)        # 22448 <fwp_handlers>
    78e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    78ef:	48 89 0d 62 ab 01 00 	mov    %rcx,0x1ab62(%rip)        # 22458 <fwp_cleanups>
    78f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    78fd:	48 89 0d 4c ab 01 00 	mov    %rcx,0x1ab4c(%rip)        # 22450 <fwp_foreign_callbacks>
    7904:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    790b:	48 89 0d 2e ab 01 00 	mov    %rcx,0x1ab2e(%rip)        # 22440 <fwp_state>
    7912:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7919:	48 89 0d 18 ab 01 00 	mov    %rcx,0x1ab18(%rip)        # 22438 <fwp_state_len>
    7920:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7927:	48 89 0d 02 ab 01 00 	mov    %rcx,0x1ab02(%rip)        # 22430 <fwp_state_cap>
    792e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7935:	48 89 0d ec aa 01 00 	mov    %rcx,0x1aaec(%rip)        # 22428 <fwp_state_owners>
    793c:	e8 2f bb ff ff       	call   3470 <swapcontext@plt>
    7941:	f3 0f 1e fa          	endbr64
    7945:	e8 d6 fc ff ff       	call   7620 <fwp_free_zombie>
    794a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7950:	8b 05 0a 88 01 00    	mov    0x1880a(%rip),%eax        # 20160 <fwp_slice>
    7956:	85 c0                	test   %eax,%eax
    7958:	74 36                	je     7990 <fwp_block+0x160>
    795a:	48 83 c4 08          	add    $0x8,%rsp
    795e:	c3                   	ret
    795f:	90                   	nop
    7960:	e8 eb d7 ff ff       	call   5150 <fwp_poll_events>
    7965:	48 8b 05 1c 8e 01 00 	mov    0x18e1c(%rip),%rax        # 20788 <fwp_ready_head>
    796c:	48 85 c0             	test   %rax,%rax
    796f:	0f 85 db fe ff ff    	jne    7850 <fwp_block+0x20>
    7975:	eb e9                	jmp    7960 <fwp_block+0x130>
    7977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    797e:	00 00 
    7980:	48 c7 05 f5 8d 01 00 	movq   $0x0,0x18df5(%rip)        # 20780 <fwp_ready_tail>
    7987:	00 00 00 00 
    798b:	e9 d7 fe ff ff       	jmp    7867 <fwp_block+0x37>
    7990:	48 8d 3d ed 47 00 00 	lea    0x47ed(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    7997:	e8 e4 b9 ff ff       	call   3380 <getenv@plt>
    799c:	ba 10 27 00 00       	mov    $0x2710,%edx
    79a1:	48 85 c0             	test   %rax,%rax
    79a4:	74 05                	je     79ab <fwp_block+0x17b>
    79a6:	80 38 00             	cmpb   $0x0,(%rax)
    79a9:	75 0b                	jne    79b6 <fwp_block+0x186>
    79ab:	89 15 af 87 01 00    	mov    %edx,0x187af(%rip)        # 20160 <fwp_slice>
    79b1:	48 83 c4 08          	add    $0x8,%rsp
    79b5:	c3                   	ret
    79b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    79bb:	31 f6                	xor    %esi,%esi
    79bd:	48 89 c7             	mov    %rax,%rdi
    79c0:	e8 6b bb ff ff       	call   3530 <strtoll@plt>
    79c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    79c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    79d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    79d5:	0f 46 d0             	cmovbe %eax,%edx
    79d8:	eb d1                	jmp    79ab <fwp_block+0x17b>
    79da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000079e0 <fwp_caps173>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	85 f6                	test   %esi,%esi
    79e6:	74 08                	je     79f0 <fwp_caps173+0x10>
    79e8:	c3                   	ret
    79e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f0:	48 8b 15 a1 a1 01 00 	mov    0x1a1a1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    79f7:	48 89 f8             	mov    %rdi,%rax
    79fa:	48 2b 05 6f a1 01 00 	sub    0x1a16f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7a01:	48 c1 e2 10          	shl    $0x10,%rdx
    7a05:	48 39 d0             	cmp    %rdx,%rax
    7a08:	73 de                	jae    79e8 <fwp_caps173+0x8>
    7a0a:	48 89 c2             	mov    %rax,%rdx
    7a0d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a15:	48 8b 15 9c a1 01 00 	mov    0x1a19c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7a1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a24:	48 85 c9             	test   %rcx,%rcx
    7a27:	74 bf                	je     79e8 <fwp_caps173+0x8>
    7a29:	0f b6 32             	movzbl (%rdx),%esi
    7a2c:	40 80 fe 02          	cmp    $0x2,%sil
    7a30:	74 2e                	je     7a60 <fwp_caps173+0x80>
    7a32:	40 80 fe 01          	cmp    $0x1,%sil
    7a36:	75 b0                	jne    79e8 <fwp_caps173+0x8>
    7a38:	8b 72 18             	mov    0x18(%rdx),%esi
    7a3b:	0f b7 c0             	movzwl %ax,%eax
    7a3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a41:	48 0f af c6          	imul   %rsi,%rax
    7a45:	48 c1 e8 20          	shr    $0x20,%rax
    7a49:	48 39 d0             	cmp    %rdx,%rax
    7a4c:	73 9a                	jae    79e8 <fwp_caps173+0x8>
    7a4e:	48 01 c1             	add    %rax,%rcx
    7a51:	80 39 01             	cmpb   $0x1,(%rcx)
    7a54:	75 92                	jne    79e8 <fwp_caps173+0x8>
    7a56:	e9 f5 dc ff ff       	jmp    5750 <fwp_mem_free>
    7a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a60:	66 85 c0             	test   %ax,%ax
    7a63:	74 ec                	je     7a51 <fwp_caps173+0x71>
    7a65:	c3                   	ret
    7a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a6d:	00 00 00 

0000000000007a70 <fwp_args37>:
    7a70:	f3 0f 1e fa          	endbr64
    7a74:	85 d2                	test   %edx,%edx
    7a76:	74 04                	je     7a7c <fwp_args37+0xc>
    7a78:	85 f6                	test   %esi,%esi
    7a7a:	74 04                	je     7a80 <fwp_args37+0x10>
    7a7c:	c3                   	ret
    7a7d:	0f 1f 00             	nopl   (%rax)
    7a80:	48 8b 15 11 a1 01 00 	mov    0x1a111(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7a87:	48 8b 07             	mov    (%rdi),%rax
    7a8a:	48 2b 05 df a0 01 00 	sub    0x1a0df(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7a91:	48 c1 e2 10          	shl    $0x10,%rdx
    7a95:	48 39 d0             	cmp    %rdx,%rax
    7a98:	73 e2                	jae    7a7c <fwp_args37+0xc>
    7a9a:	48 89 c2             	mov    %rax,%rdx
    7a9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7aa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7aa5:	48 8b 15 0c a1 01 00 	mov    0x1a10c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7aac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ab0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ab4:	48 85 ff             	test   %rdi,%rdi
    7ab7:	74 c3                	je     7a7c <fwp_args37+0xc>
    7ab9:	0f b6 0a             	movzbl (%rdx),%ecx
    7abc:	80 f9 02             	cmp    $0x2,%cl
    7abf:	74 2f                	je     7af0 <fwp_args37+0x80>
    7ac1:	80 f9 01             	cmp    $0x1,%cl
    7ac4:	75 b6                	jne    7a7c <fwp_args37+0xc>
    7ac6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ac9:	0f b7 c0             	movzwl %ax,%eax
    7acc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7acf:	48 0f af c1          	imul   %rcx,%rax
    7ad3:	48 c1 e8 20          	shr    $0x20,%rax
    7ad7:	48 39 d0             	cmp    %rdx,%rax
    7ada:	73 a0                	jae    7a7c <fwp_args37+0xc>
    7adc:	48 01 c7             	add    %rax,%rdi
    7adf:	0f b6 07             	movzbl (%rdi),%eax
    7ae2:	84 c0                	test   %al,%al
    7ae4:	74 96                	je     7a7c <fwp_args37+0xc>
    7ae6:	3c fd                	cmp    $0xfd,%al
    7ae8:	77 0c                	ja     7af6 <fwp_args37+0x86>
    7aea:	83 c0 01             	add    $0x1,%eax
    7aed:	88 07                	mov    %al,(%rdi)
    7aef:	c3                   	ret
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	74 ea                	je     7adf <fwp_args37+0x6f>
    7af5:	c3                   	ret
    7af6:	e9 f5 d8 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    7afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b00 <fwp_caps37>:
    7b00:	f3 0f 1e fa          	endbr64
    7b04:	48 83 ec 18          	sub    $0x18,%rsp
    7b08:	8b 57 04             	mov    0x4(%rdi),%edx
    7b0b:	48 89 f8             	mov    %rdi,%rax
    7b0e:	85 d2                	test   %edx,%edx
    7b10:	0f 84 9a 00 00 00    	je     7bb0 <fwp_caps37+0xb0>
    7b16:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7b1a:	85 f6                	test   %esi,%esi
    7b1c:	0f 85 9e 00 00 00    	jne    7bc0 <fwp_caps37+0xc0>
    7b22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b27:	e8 54 f7 ff ff       	call   7280 <fwp_drop4>
    7b2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b31:	48 8b 0d 60 a0 01 00 	mov    0x1a060(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    7b38:	48 89 c2             	mov    %rax,%rdx
    7b3b:	48 2b 15 2e a0 01 00 	sub    0x1a02e(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    7b42:	48 c1 e1 10          	shl    $0x10,%rcx
    7b46:	48 39 ca             	cmp    %rcx,%rdx
    7b49:	73 6d                	jae    7bb8 <fwp_caps37+0xb8>
    7b4b:	48 89 d1             	mov    %rdx,%rcx
    7b4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b56:	48 8b 0d 5b a0 01 00 	mov    0x1a05b(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7b5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b65:	48 85 f6             	test   %rsi,%rsi
    7b68:	74 4e                	je     7bb8 <fwp_caps37+0xb8>
    7b6a:	0f b6 39             	movzbl (%rcx),%edi
    7b6d:	40 80 ff 02          	cmp    $0x2,%dil
    7b71:	0f 84 b9 00 00 00    	je     7c30 <fwp_caps37+0x130>
    7b77:	40 80 ff 01          	cmp    $0x1,%dil
    7b7b:	75 3b                	jne    7bb8 <fwp_caps37+0xb8>
    7b7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b80:	0f b7 d2             	movzwl %dx,%edx
    7b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b86:	48 0f af d7          	imul   %rdi,%rdx
    7b8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7b8e:	48 39 ca             	cmp    %rcx,%rdx
    7b91:	73 25                	jae    7bb8 <fwp_caps37+0xb8>
    7b93:	48 01 d6             	add    %rdx,%rsi
    7b96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b99:	75 1d                	jne    7bb8 <fwp_caps37+0xb8>
    7b9b:	48 89 c7             	mov    %rax,%rdi
    7b9e:	48 83 c4 18          	add    $0x18,%rsp
    7ba2:	e9 a9 db ff ff       	jmp    5750 <fwp_mem_free>
    7ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bae:	00 00 
    7bb0:	85 f6                	test   %esi,%esi
    7bb2:	0f 84 79 ff ff ff    	je     7b31 <fwp_caps37+0x31>
    7bb8:	48 83 c4 18          	add    $0x18,%rsp
    7bbc:	c3                   	ret
    7bbd:	0f 1f 00             	nopl   (%rax)
    7bc0:	48 8b 05 d1 9f 01 00 	mov    0x19fd1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    7bc7:	48 2b 3d a2 9f 01 00 	sub    0x19fa2(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    7bce:	48 c1 e0 10          	shl    $0x10,%rax
    7bd2:	48 39 c7             	cmp    %rax,%rdi
    7bd5:	73 e1                	jae    7bb8 <fwp_caps37+0xb8>
    7bd7:	48 89 f8             	mov    %rdi,%rax
    7bda:	48 c1 e8 10          	shr    $0x10,%rax
    7bde:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7be2:	48 8b 05 cf 9f 01 00 	mov    0x19fcf(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    7be9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7bed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7bf1:	48 85 c0             	test   %rax,%rax
    7bf4:	74 c2                	je     7bb8 <fwp_caps37+0xb8>
    7bf6:	0f b6 0a             	movzbl (%rdx),%ecx
    7bf9:	80 f9 02             	cmp    $0x2,%cl
    7bfc:	74 42                	je     7c40 <fwp_caps37+0x140>
    7bfe:	80 f9 01             	cmp    $0x1,%cl
    7c01:	75 b5                	jne    7bb8 <fwp_caps37+0xb8>
    7c03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c06:	0f b7 ff             	movzwl %di,%edi
    7c09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c0c:	48 0f af f9          	imul   %rcx,%rdi
    7c10:	48 c1 ef 20          	shr    $0x20,%rdi
    7c14:	48 39 d7             	cmp    %rdx,%rdi
    7c17:	73 9f                	jae    7bb8 <fwp_caps37+0xb8>
    7c19:	48 01 f8             	add    %rdi,%rax
    7c1c:	0f b6 10             	movzbl (%rax),%edx
    7c1f:	84 d2                	test   %dl,%dl
    7c21:	74 95                	je     7bb8 <fwp_caps37+0xb8>
    7c23:	80 fa fd             	cmp    $0xfd,%dl
    7c26:	77 23                	ja     7c4b <fwp_caps37+0x14b>
    7c28:	83 c2 01             	add    $0x1,%edx
    7c2b:	88 10                	mov    %dl,(%rax)
    7c2d:	eb 89                	jmp    7bb8 <fwp_caps37+0xb8>
    7c2f:	90                   	nop
    7c30:	66 85 d2             	test   %dx,%dx
    7c33:	0f 85 7f ff ff ff    	jne    7bb8 <fwp_caps37+0xb8>
    7c39:	e9 58 ff ff ff       	jmp    7b96 <fwp_caps37+0x96>
    7c3e:	66 90                	xchg   %ax,%ax
    7c40:	66 85 ff             	test   %di,%di
    7c43:	0f 85 6f ff ff ff    	jne    7bb8 <fwp_caps37+0xb8>
    7c49:	eb d1                	jmp    7c1c <fwp_caps37+0x11c>
    7c4b:	48 89 c7             	mov    %rax,%rdi
    7c4e:	48 83 c4 18          	add    $0x18,%rsp
    7c52:	e9 99 d7 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    7c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c5e:	00 00 

0000000000007c60 <fwp_drop0>:
    7c60:	f3 0f 1e fa          	endbr64
    7c64:	48 8b 15 2d 9f 01 00 	mov    0x19f2d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7c6b:	48 89 f8             	mov    %rdi,%rax
    7c6e:	48 2b 05 fb 9e 01 00 	sub    0x19efb(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7c75:	48 c1 e2 10          	shl    $0x10,%rdx
    7c79:	48 39 d0             	cmp    %rdx,%rax
    7c7c:	0f 83 36 01 00 00    	jae    7db8 <fwp_drop0+0x158>
    7c82:	48 83 ec 18          	sub    $0x18,%rsp
    7c86:	48 8d 35 33 8b 01 00 	lea    0x18b33(%rip),%rsi        # 207c0 <fwp_heap>
    7c8d:	48 89 c2             	mov    %rax,%rdx
    7c90:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7c97:	48 c1 ea 10          	shr    $0x10,%rdx
    7c9b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c9f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ca3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ca7:	48 85 d2             	test   %rdx,%rdx
    7caa:	74 42                	je     7cee <fwp_drop0+0x8e>
    7cac:	44 0f b6 01          	movzbl (%rcx),%r8d
    7cb0:	41 80 f8 02          	cmp    $0x2,%r8b
    7cb4:	74 42                	je     7cf8 <fwp_drop0+0x98>
    7cb6:	41 80 f8 01          	cmp    $0x1,%r8b
    7cba:	75 32                	jne    7cee <fwp_drop0+0x8e>
    7cbc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7cc0:	0f b7 c0             	movzwl %ax,%eax
    7cc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7cc6:	49 0f af c0          	imul   %r8,%rax
    7cca:	48 c1 e8 20          	shr    $0x20,%rax
    7cce:	48 39 c8             	cmp    %rcx,%rax
    7cd1:	73 1b                	jae    7cee <fwp_drop0+0x8e>
    7cd3:	48 01 c2             	add    %rax,%rdx
    7cd6:	0f b6 02             	movzbl (%rdx),%eax
    7cd9:	84 c0                	test   %al,%al
    7cdb:	74 11                	je     7cee <fwp_drop0+0x8e>
    7cdd:	3c 01                	cmp    $0x1,%al
    7cdf:	74 27                	je     7d08 <fwp_drop0+0xa8>
    7ce1:	3c ff                	cmp    $0xff,%al
    7ce3:	0f 84 e7 00 00 00    	je     7dd0 <fwp_drop0+0x170>
    7ce9:	83 e8 01             	sub    $0x1,%eax
    7cec:	88 02                	mov    %al,(%rdx)
    7cee:	48 83 c4 18          	add    $0x18,%rsp
    7cf2:	c3                   	ret
    7cf3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cf8:	66 85 c0             	test   %ax,%ax
    7cfb:	74 d9                	je     7cd6 <fwp_drop0+0x76>
    7cfd:	48 83 c4 18          	add    $0x18,%rsp
    7d01:	c3                   	ret
    7d02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d08:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d0f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d16:	48 89 f8             	mov    %rdi,%rax
    7d19:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d1d:	48 29 c8             	sub    %rcx,%rax
    7d20:	48 c1 e2 10          	shl    $0x10,%rdx
    7d24:	48 39 d0             	cmp    %rdx,%rax
    7d27:	73 71                	jae    7d9a <fwp_drop0+0x13a>
    7d29:	49 89 c2             	mov    %rax,%r10
    7d2c:	49 c1 ea 10          	shr    $0x10,%r10
    7d30:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d34:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d38:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d3c:	4d 85 d2             	test   %r10,%r10
    7d3f:	74 59                	je     7d9a <fwp_drop0+0x13a>
    7d41:	45 0f b6 19          	movzbl (%r9),%r11d
    7d45:	41 80 fb 02          	cmp    $0x2,%r11b
    7d49:	74 75                	je     7dc0 <fwp_drop0+0x160>
    7d4b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d4f:	75 49                	jne    7d9a <fwp_drop0+0x13a>
    7d51:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d55:	0f b7 c0             	movzwl %ax,%eax
    7d58:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d5c:	49 0f af c3          	imul   %r11,%rax
    7d60:	48 c1 e8 20          	shr    $0x20,%rax
    7d64:	4c 39 c8             	cmp    %r9,%rax
    7d67:	73 31                	jae    7d9a <fwp_drop0+0x13a>
    7d69:	49 01 c2             	add    %rax,%r10
    7d6c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d70:	75 28                	jne    7d9a <fwp_drop0+0x13a>
    7d72:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7d77:	e8 d4 d9 ff ff       	call   5750 <fwp_mem_free>
    7d7c:	48 8d 35 3d 8a 01 00 	lea    0x18a3d(%rip),%rsi        # 207c0 <fwp_heap>
    7d83:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7d88:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d8f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d96:	48 c1 e2 10          	shl    $0x10,%rdx
    7d9a:	4c 89 c0             	mov    %r8,%rax
    7d9d:	48 29 c8             	sub    %rcx,%rax
    7da0:	48 39 d0             	cmp    %rdx,%rax
    7da3:	0f 83 45 ff ff ff    	jae    7cee <fwp_drop0+0x8e>
    7da9:	4c 89 c7             	mov    %r8,%rdi
    7dac:	e9 dc fe ff ff       	jmp    7c8d <fwp_drop0+0x2d>
    7db1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7db8:	c3                   	ret
    7db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7dc0:	66 85 c0             	test   %ax,%ax
    7dc3:	75 d5                	jne    7d9a <fwp_drop0+0x13a>
    7dc5:	eb a5                	jmp    7d6c <fwp_drop0+0x10c>
    7dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dce:	00 00 
    7dd0:	48 89 d0             	mov    %rdx,%rax
    7dd3:	48 c1 e8 11          	shr    $0x11,%rax
    7dd7:	48 31 d0             	xor    %rdx,%rax
    7dda:	48 89 c1             	mov    %rax,%rcx
    7ddd:	48 c1 e9 09          	shr    $0x9,%rcx
    7de1:	48 31 c8             	xor    %rcx,%rax
    7de4:	0f b6 c8             	movzbl %al,%ecx
    7de7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7dee:	00 
    7def:	48 85 c0             	test   %rax,%rax
    7df2:	75 15                	jne    7e09 <fwp_drop0+0x1a9>
    7df4:	eb 4e                	jmp    7e44 <fwp_drop0+0x1e4>
    7df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7dfd:	00 00 00 
    7e00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e04:	48 85 c0             	test   %rax,%rax
    7e07:	74 3b                	je     7e44 <fwp_drop0+0x1e4>
    7e09:	48 89 c1             	mov    %rax,%rcx
    7e0c:	48 39 10             	cmp    %rdx,(%rax)
    7e0f:	75 ef                	jne    7e00 <fwp_drop0+0x1a0>
    7e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e24:	0f 85 c4 fe ff ff    	jne    7cee <fwp_drop0+0x8e>
    7e2a:	48 89 d7             	mov    %rdx,%rdi
    7e2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e32:	e8 d9 d6 ff ff       	call   5510 <fwp_rc_forget_slot>
    7e37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e3f:	e9 aa fe ff ff       	jmp    7cee <fwp_drop0+0x8e>
    7e44:	48 8d 3d 45 4a 00 00 	lea    0x4a45(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7e4b:	e8 60 c5 ff ff       	call   43b0 <fwp_trap>

0000000000007e50 <fwp_drop1>:
    7e50:	f3 0f 1e fa          	endbr64
    7e54:	48 8b 15 3d 9d 01 00 	mov    0x19d3d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7e5b:	48 89 f8             	mov    %rdi,%rax
    7e5e:	48 2b 05 0b 9d 01 00 	sub    0x19d0b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7e65:	48 c1 e2 10          	shl    $0x10,%rdx
    7e69:	48 39 d0             	cmp    %rdx,%rax
    7e6c:	0f 83 36 01 00 00    	jae    7fa8 <fwp_drop1+0x158>
    7e72:	48 83 ec 18          	sub    $0x18,%rsp
    7e76:	48 8d 35 43 89 01 00 	lea    0x18943(%rip),%rsi        # 207c0 <fwp_heap>
    7e7d:	48 89 c2             	mov    %rax,%rdx
    7e80:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7e87:	48 c1 ea 10          	shr    $0x10,%rdx
    7e8b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7e8f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7e93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7e97:	48 85 d2             	test   %rdx,%rdx
    7e9a:	74 42                	je     7ede <fwp_drop1+0x8e>
    7e9c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7ea0:	41 80 f8 02          	cmp    $0x2,%r8b
    7ea4:	74 42                	je     7ee8 <fwp_drop1+0x98>
    7ea6:	41 80 f8 01          	cmp    $0x1,%r8b
    7eaa:	75 32                	jne    7ede <fwp_drop1+0x8e>
    7eac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7eb0:	0f b7 c0             	movzwl %ax,%eax
    7eb3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7eb6:	49 0f af c0          	imul   %r8,%rax
    7eba:	48 c1 e8 20          	shr    $0x20,%rax
    7ebe:	48 39 c8             	cmp    %rcx,%rax
    7ec1:	73 1b                	jae    7ede <fwp_drop1+0x8e>
    7ec3:	48 01 c2             	add    %rax,%rdx
    7ec6:	0f b6 02             	movzbl (%rdx),%eax
    7ec9:	84 c0                	test   %al,%al
    7ecb:	74 11                	je     7ede <fwp_drop1+0x8e>
    7ecd:	3c 01                	cmp    $0x1,%al
    7ecf:	74 27                	je     7ef8 <fwp_drop1+0xa8>
    7ed1:	3c ff                	cmp    $0xff,%al
    7ed3:	0f 84 e7 00 00 00    	je     7fc0 <fwp_drop1+0x170>
    7ed9:	83 e8 01             	sub    $0x1,%eax
    7edc:	88 02                	mov    %al,(%rdx)
    7ede:	48 83 c4 18          	add    $0x18,%rsp
    7ee2:	c3                   	ret
    7ee3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ee8:	66 85 c0             	test   %ax,%ax
    7eeb:	74 d9                	je     7ec6 <fwp_drop1+0x76>
    7eed:	48 83 c4 18          	add    $0x18,%rsp
    7ef1:	c3                   	ret
    7ef2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ef8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7eff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7f06:	48 89 f8             	mov    %rdi,%rax
    7f09:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7f0d:	48 29 c8             	sub    %rcx,%rax
    7f10:	48 c1 e2 10          	shl    $0x10,%rdx
    7f14:	48 39 d0             	cmp    %rdx,%rax
    7f17:	73 71                	jae    7f8a <fwp_drop1+0x13a>
    7f19:	49 89 c2             	mov    %rax,%r10
    7f1c:	49 c1 ea 10          	shr    $0x10,%r10
    7f20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7f24:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7f28:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7f2c:	4d 85 d2             	test   %r10,%r10
    7f2f:	74 59                	je     7f8a <fwp_drop1+0x13a>
    7f31:	45 0f b6 19          	movzbl (%r9),%r11d
    7f35:	41 80 fb 02          	cmp    $0x2,%r11b
    7f39:	74 75                	je     7fb0 <fwp_drop1+0x160>
    7f3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7f3f:	75 49                	jne    7f8a <fwp_drop1+0x13a>
    7f41:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7f45:	0f b7 c0             	movzwl %ax,%eax
    7f48:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7f4c:	49 0f af c3          	imul   %r11,%rax
    7f50:	48 c1 e8 20          	shr    $0x20,%rax
    7f54:	4c 39 c8             	cmp    %r9,%rax
    7f57:	73 31                	jae    7f8a <fwp_drop1+0x13a>
    7f59:	49 01 c2             	add    %rax,%r10
    7f5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7f60:	75 28                	jne    7f8a <fwp_drop1+0x13a>
    7f62:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7f67:	e8 e4 d7 ff ff       	call   5750 <fwp_mem_free>
    7f6c:	48 8d 35 4d 88 01 00 	lea    0x1884d(%rip),%rsi        # 207c0 <fwp_heap>
    7f73:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7f78:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7f7f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7f86:	48 c1 e2 10          	shl    $0x10,%rdx
    7f8a:	4c 89 c0             	mov    %r8,%rax
    7f8d:	48 29 c8             	sub    %rcx,%rax
    7f90:	48 39 d0             	cmp    %rdx,%rax
    7f93:	0f 83 45 ff ff ff    	jae    7ede <fwp_drop1+0x8e>
    7f99:	4c 89 c7             	mov    %r8,%rdi
    7f9c:	e9 dc fe ff ff       	jmp    7e7d <fwp_drop1+0x2d>
    7fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fa8:	c3                   	ret
    7fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fb0:	66 85 c0             	test   %ax,%ax
    7fb3:	75 d5                	jne    7f8a <fwp_drop1+0x13a>
    7fb5:	eb a5                	jmp    7f5c <fwp_drop1+0x10c>
    7fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fbe:	00 00 
    7fc0:	48 89 d0             	mov    %rdx,%rax
    7fc3:	48 c1 e8 11          	shr    $0x11,%rax
    7fc7:	48 31 d0             	xor    %rdx,%rax
    7fca:	48 89 c1             	mov    %rax,%rcx
    7fcd:	48 c1 e9 09          	shr    $0x9,%rcx
    7fd1:	48 31 c8             	xor    %rcx,%rax
    7fd4:	0f b6 c8             	movzbl %al,%ecx
    7fd7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7fde:	00 
    7fdf:	48 85 c0             	test   %rax,%rax
    7fe2:	75 25                	jne    8009 <fwp_drop1+0x1b9>
    7fe4:	eb 5e                	jmp    8044 <fwp_drop1+0x1f4>
    7fe6:	0f 1f 40 00          	nopl   0x0(%rax)
    7fea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ff1:	00 00 00 00 
    7ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ffc:	00 00 00 00 
    8000:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8004:	48 85 c0             	test   %rax,%rax
    8007:	74 3b                	je     8044 <fwp_drop1+0x1f4>
    8009:	48 89 c1             	mov    %rax,%rcx
    800c:	48 39 10             	cmp    %rdx,(%rax)
    800f:	75 ef                	jne    8000 <fwp_drop1+0x1b0>
    8011:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8015:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8019:	48 89 48 08          	mov    %rcx,0x8(%rax)
    801d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8024:	0f 85 b4 fe ff ff    	jne    7ede <fwp_drop1+0x8e>
    802a:	48 89 d7             	mov    %rdx,%rdi
    802d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8032:	e8 d9 d4 ff ff       	call   5510 <fwp_rc_forget_slot>
    8037:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    803c:	c6 02 fe             	movb   $0xfe,(%rdx)
    803f:	e9 9a fe ff ff       	jmp    7ede <fwp_drop1+0x8e>
    8044:	48 8d 3d 45 48 00 00 	lea    0x4845(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    804b:	e8 60 c3 ff ff       	call   43b0 <fwp_trap>

0000000000008050 <fwp_drop10>:
    8050:	48 8b 0d 41 9b 01 00 	mov    0x19b41(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    8057:	48 89 f8             	mov    %rdi,%rax
    805a:	48 2b 05 0f 9b 01 00 	sub    0x19b0f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8061:	48 c1 e1 10          	shl    $0x10,%rcx
    8065:	48 39 c8             	cmp    %rcx,%rax
    8068:	0f 83 c2 01 00 00    	jae    8230 <fwp_drop10+0x1e0>
    806e:	48 83 ec 18          	sub    $0x18,%rsp
    8072:	48 89 fa             	mov    %rdi,%rdx
    8075:	48 8d 35 44 87 01 00 	lea    0x18744(%rip),%rsi        # 207c0 <fwp_heap>
    807c:	48 89 c1             	mov    %rax,%rcx
    807f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8086:	48 c1 e9 10          	shr    $0x10,%rcx
    808a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    808e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8092:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8096:	48 85 c9             	test   %rcx,%rcx
    8099:	74 46                	je     80e1 <fwp_drop10+0x91>
    809b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    809f:	41 80 f9 02          	cmp    $0x2,%r9b
    80a3:	0f 84 d7 00 00 00    	je     8180 <fwp_drop10+0x130>
    80a9:	41 80 f9 01          	cmp    $0x1,%r9b
    80ad:	75 32                	jne    80e1 <fwp_drop10+0x91>
    80af:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    80b3:	0f b7 c0             	movzwl %ax,%eax
    80b6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    80b9:	49 0f af c1          	imul   %r9,%rax
    80bd:	48 c1 e8 20          	shr    $0x20,%rax
    80c1:	48 39 f8             	cmp    %rdi,%rax
    80c4:	73 1b                	jae    80e1 <fwp_drop10+0x91>
    80c6:	48 01 c1             	add    %rax,%rcx
    80c9:	0f b6 01             	movzbl (%rcx),%eax
    80cc:	84 c0                	test   %al,%al
    80ce:	74 11                	je     80e1 <fwp_drop10+0x91>
    80d0:	3c 01                	cmp    $0x1,%al
    80d2:	74 1c                	je     80f0 <fwp_drop10+0xa0>
    80d4:	3c ff                	cmp    $0xff,%al
    80d6:	0f 84 5c 01 00 00    	je     8238 <fwp_drop10+0x1e8>
    80dc:	83 e8 01             	sub    $0x1,%eax
    80df:	88 01                	mov    %al,(%rcx)
    80e1:	48 83 c4 18          	add    $0x18,%rsp
    80e5:	c3                   	ret
    80e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80ed:	00 00 00 
    80f0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    80f7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    80fe:	48 89 d0             	mov    %rdx,%rax
    8101:	49 89 d1             	mov    %rdx,%r9
    8104:	48 c1 e1 10          	shl    $0x10,%rcx
    8108:	48 29 f8             	sub    %rdi,%rax
    810b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    810f:	78 7f                	js     8190 <fwp_drop10+0x140>
    8111:	48 39 c8             	cmp    %rcx,%rax
    8114:	73 cb                	jae    80e1 <fwp_drop10+0x91>
    8116:	48 89 c1             	mov    %rax,%rcx
    8119:	48 c1 e9 10          	shr    $0x10,%rcx
    811d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8121:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8125:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8129:	48 85 f6             	test   %rsi,%rsi
    812c:	74 b3                	je     80e1 <fwp_drop10+0x91>
    812e:	0f b6 39             	movzbl (%rcx),%edi
    8131:	40 80 ff 02          	cmp    $0x2,%dil
    8135:	74 39                	je     8170 <fwp_drop10+0x120>
    8137:	40 80 ff 01          	cmp    $0x1,%dil
    813b:	75 a4                	jne    80e1 <fwp_drop10+0x91>
    813d:	8b 79 18             	mov    0x18(%rcx),%edi
    8140:	0f b7 c0             	movzwl %ax,%eax
    8143:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8146:	48 0f af c7          	imul   %rdi,%rax
    814a:	48 c1 e8 20          	shr    $0x20,%rax
    814e:	48 39 c8             	cmp    %rcx,%rax
    8151:	73 8e                	jae    80e1 <fwp_drop10+0x91>
    8153:	48 01 c6             	add    %rax,%rsi
    8156:	80 3e 01             	cmpb   $0x1,(%rsi)
    8159:	75 86                	jne    80e1 <fwp_drop10+0x91>
    815b:	48 89 d7             	mov    %rdx,%rdi
    815e:	48 83 c4 18          	add    $0x18,%rsp
    8162:	e9 e9 d5 ff ff       	jmp    5750 <fwp_mem_free>
    8167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    816e:	00 00 
    8170:	66 85 c0             	test   %ax,%ax
    8173:	74 e1                	je     8156 <fwp_drop10+0x106>
    8175:	48 83 c4 18          	add    $0x18,%rsp
    8179:	c3                   	ret
    817a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8180:	66 85 c0             	test   %ax,%ax
    8183:	0f 84 40 ff ff ff    	je     80c9 <fwp_drop10+0x79>
    8189:	48 83 c4 18          	add    $0x18,%rsp
    818d:	c3                   	ret
    818e:	66 90                	xchg   %ax,%ax
    8190:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8194:	48 39 c8             	cmp    %rcx,%rax
    8197:	73 74                	jae    820d <fwp_drop10+0x1bd>
    8199:	49 89 c2             	mov    %rax,%r10
    819c:	49 c1 ea 10          	shr    $0x10,%r10
    81a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    81a4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    81a8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    81ac:	4d 85 d2             	test   %r10,%r10
    81af:	74 5c                	je     820d <fwp_drop10+0x1bd>
    81b1:	45 0f b6 18          	movzbl (%r8),%r11d
    81b5:	41 80 fb 02          	cmp    $0x2,%r11b
    81b9:	74 6d                	je     8228 <fwp_drop10+0x1d8>
    81bb:	41 80 fb 01          	cmp    $0x1,%r11b
    81bf:	75 4c                	jne    820d <fwp_drop10+0x1bd>
    81c1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    81c5:	0f b7 c0             	movzwl %ax,%eax
    81c8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    81cc:	49 0f af c3          	imul   %r11,%rax
    81d0:	48 c1 e8 20          	shr    $0x20,%rax
    81d4:	4c 39 c0             	cmp    %r8,%rax
    81d7:	73 34                	jae    820d <fwp_drop10+0x1bd>
    81d9:	49 01 c2             	add    %rax,%r10
    81dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    81e0:	75 2b                	jne    820d <fwp_drop10+0x1bd>
    81e2:	4c 89 cf             	mov    %r9,%rdi
    81e5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    81ea:	e8 61 d5 ff ff       	call   5750 <fwp_mem_free>
    81ef:	48 8d 35 ca 85 01 00 	lea    0x185ca(%rip),%rsi        # 207c0 <fwp_heap>
    81f6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    81fb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8202:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8209:	48 c1 e1 10          	shl    $0x10,%rcx
    820d:	48 89 d0             	mov    %rdx,%rax
    8210:	48 29 f8             	sub    %rdi,%rax
    8213:	48 39 c8             	cmp    %rcx,%rax
    8216:	0f 82 60 fe ff ff    	jb     807c <fwp_drop10+0x2c>
    821c:	e9 c0 fe ff ff       	jmp    80e1 <fwp_drop10+0x91>
    8221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8228:	66 85 c0             	test   %ax,%ax
    822b:	75 e0                	jne    820d <fwp_drop10+0x1bd>
    822d:	eb ad                	jmp    81dc <fwp_drop10+0x18c>
    822f:	90                   	nop
    8230:	c3                   	ret
    8231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8238:	48 89 c8             	mov    %rcx,%rax
    823b:	48 c1 e8 11          	shr    $0x11,%rax
    823f:	48 31 c8             	xor    %rcx,%rax
    8242:	48 89 c2             	mov    %rax,%rdx
    8245:	48 c1 ea 09          	shr    $0x9,%rdx
    8249:	48 31 d0             	xor    %rdx,%rax
    824c:	0f b6 d0             	movzbl %al,%edx
    824f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8256:	00 
    8257:	48 85 c0             	test   %rax,%rax
    825a:	75 0d                	jne    8269 <fwp_drop10+0x219>
    825c:	eb 46                	jmp    82a4 <fwp_drop10+0x254>
    825e:	66 90                	xchg   %ax,%ax
    8260:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8264:	48 85 c0             	test   %rax,%rax
    8267:	74 3b                	je     82a4 <fwp_drop10+0x254>
    8269:	48 89 c2             	mov    %rax,%rdx
    826c:	48 39 08             	cmp    %rcx,(%rax)
    826f:	75 ef                	jne    8260 <fwp_drop10+0x210>
    8271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8275:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    827d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8284:	0f 85 57 fe ff ff    	jne    80e1 <fwp_drop10+0x91>
    828a:	48 89 cf             	mov    %rcx,%rdi
    828d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8292:	e8 79 d2 ff ff       	call   5510 <fwp_rc_forget_slot>
    8297:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    829c:	c6 01 fe             	movb   $0xfe,(%rcx)
    829f:	e9 3d fe ff ff       	jmp    80e1 <fwp_drop10+0x91>
    82a4:	48 8d 3d e5 45 00 00 	lea    0x45e5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    82ab:	e8 00 c1 ff ff       	call   43b0 <fwp_trap>

00000000000082b0 <f37>:
    82b0:	41 57                	push   %r15
    82b2:	41 56                	push   %r14
    82b4:	41 55                	push   %r13
    82b6:	41 54                	push   %r12
    82b8:	55                   	push   %rbp
    82b9:	53                   	push   %rbx
    82ba:	48 83 ec 48          	sub    $0x48,%rsp
    82be:	48 8b 15 d3 98 01 00 	mov    0x198d3(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    82c5:	48 89 3c 24          	mov    %rdi,(%rsp)
    82c9:	48 c1 e2 10          	shl    $0x10,%rdx
    82cd:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    82d4:	00 00 
    82d6:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    82db:	48 8b 0d 8e 98 01 00 	mov    0x1988e(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    82e2:	48 85 ff             	test   %rdi,%rdi
    82e5:	0f 84 e3 02 00 00    	je     85ce <f37+0x31e>
    82eb:	48 8b 04 24          	mov    (%rsp),%rax
    82ef:	48 8b 58 10          	mov    0x10(%rax),%rbx
    82f3:	48 89 d8             	mov    %rbx,%rax
    82f6:	48 29 c8             	sub    %rcx,%rax
    82f9:	48 39 d0             	cmp    %rdx,%rax
    82fc:	0f 83 8e 03 00 00    	jae    8690 <f37+0x3e0>
    8302:	48 89 c2             	mov    %rax,%rdx
    8305:	48 c1 ea 10          	shr    $0x10,%rdx
    8309:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    830d:	48 8b 15 a4 98 01 00 	mov    0x198a4(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8314:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8318:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    831c:	48 85 ff             	test   %rdi,%rdi
    831f:	0f 84 6b 03 00 00    	je     8690 <f37+0x3e0>
    8325:	0f b6 0a             	movzbl (%rdx),%ecx
    8328:	80 f9 02             	cmp    $0x2,%cl
    832b:	0f 84 77 02 00 00    	je     85a8 <f37+0x2f8>
    8331:	80 f9 01             	cmp    $0x1,%cl
    8334:	75 24                	jne    835a <f37+0xaa>
    8336:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8339:	0f b7 c0             	movzwl %ax,%eax
    833c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    833f:	48 0f af c1          	imul   %rcx,%rax
    8343:	48 c1 e8 20          	shr    $0x20,%rax
    8347:	48 39 d0             	cmp    %rdx,%rax
    834a:	73 0e                	jae    835a <f37+0xaa>
    834c:	48 01 c7             	add    %rax,%rdi
    834f:	0f b6 07             	movzbl (%rdi),%eax
    8352:	84 c0                	test   %al,%al
    8354:	0f 85 e6 02 00 00    	jne    8640 <f37+0x390>
    835a:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    835f:	48 8b 04 24          	mov    (%rsp),%rax
    8363:	48 8b 58 10          	mov    0x10(%rax),%rbx
    8367:	ba 01 00 00 00       	mov    $0x1,%edx
    836c:	48 85 db             	test   %rbx,%rbx
    836f:	74 1c                	je     838d <f37+0xdd>
    8371:	0f 1f 40 00          	nopl   0x0(%rax)
    8375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    837c:	00 00 00 00 
    8380:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8384:	48 83 c2 01          	add    $0x1,%rdx
    8388:	48 85 db             	test   %rbx,%rbx
    838b:	75 f3                	jne    8380 <f37+0xd0>
    838d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8392:	48 85 c0             	test   %rax,%rax
    8395:	0f 84 25 03 00 00    	je     86c0 <f37+0x410>
    839b:	31 db                	xor    %ebx,%ebx
    839d:	0f 1f 00             	nopl   (%rax)
    83a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    83a4:	48 83 c3 01          	add    $0x1,%rbx
    83a8:	48 85 c0             	test   %rax,%rax
    83ab:	75 f3                	jne    83a0 <f37+0xf0>
    83ad:	48 39 d3             	cmp    %rdx,%rbx
    83b0:	48 0f 47 da          	cmova  %rdx,%rbx
    83b4:	48 89 d8             	mov    %rbx,%rax
    83b7:	48 c1 e8 3c          	shr    $0x3c,%rax
    83bb:	0f 85 9f 03 00 00    	jne    8760 <f37+0x4b0>
    83c1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    83c5:	be 02 00 00 00       	mov    $0x2,%esi
    83ca:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    83d1:	00 
    83d2:	e8 79 d8 ff ff       	call   5c50 <fwp_heap_alloc>
    83d7:	48 89 28             	mov    %rbp,(%rax)
    83da:	48 8b 15 b7 97 01 00 	mov    0x197b7(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    83e1:	49 89 c5             	mov    %rax,%r13
    83e4:	48 2b 05 85 97 01 00 	sub    0x19785(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    83eb:	48 c1 e2 10          	shl    $0x10,%rdx
    83ef:	48 39 d0             	cmp    %rdx,%rax
    83f2:	73 57                	jae    844b <f37+0x19b>
    83f4:	48 89 c2             	mov    %rax,%rdx
    83f7:	48 c1 ea 10          	shr    $0x10,%rdx
    83fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ff:	48 8b 15 b2 97 01 00 	mov    0x197b2(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8406:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    840a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    840e:	48 85 ed             	test   %rbp,%rbp
    8411:	74 38                	je     844b <f37+0x19b>
    8413:	0f b6 0a             	movzbl (%rdx),%ecx
    8416:	80 f9 02             	cmp    $0x2,%cl
    8419:	0f 84 61 02 00 00    	je     8680 <f37+0x3d0>
    841f:	80 f9 01             	cmp    $0x1,%cl
    8422:	75 27                	jne    844b <f37+0x19b>
    8424:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8427:	0f b7 c0             	movzwl %ax,%eax
    842a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    842d:	48 0f af c1          	imul   %rcx,%rax
    8431:	48 c1 e8 20          	shr    $0x20,%rax
    8435:	48 39 d0             	cmp    %rdx,%rax
    8438:	73 11                	jae    844b <f37+0x19b>
    843a:	48 01 c5             	add    %rax,%rbp
    843d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8441:	0f 84 e5 02 00 00    	je     872c <f37+0x47c>
    8447:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    844b:	48 85 db             	test   %rbx,%rbx
    844e:	74 74                	je     84c4 <f37+0x214>
    8450:	48 c1 e3 04          	shl    $0x4,%rbx
    8454:	4c 8b 34 24          	mov    (%rsp),%r14
    8458:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    845d:	4c 89 ed             	mov    %r13,%rbp
    8460:	4c 01 eb             	add    %r13,%rbx
    8463:	66 90                	xchg   %ax,%ax
    8465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    846c:	00 00 00 00 
    8470:	49 8b 46 08          	mov    0x8(%r14),%rax
    8474:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8478:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    847d:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    8484:	ff ff 
    8486:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    848d:	00 00 
    848f:	48 83 c5 10          	add    $0x10,%rbp
    8493:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8498:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    849c:	48 8b 78 10          	mov    0x10(%rax),%rdi
    84a0:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    84a5:	e8 c6 dd ff ff       	call   6270 <w120>
    84aa:	66 48 0f 6e d0       	movq   %rax,%xmm2
    84af:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    84b3:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    84b7:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    84bb:	4d 8b 76 10          	mov    0x10(%r14),%r14
    84bf:	48 39 dd             	cmp    %rbx,%rbp
    84c2:	75 ac                	jne    8470 <f37+0x1c0>
    84c4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    84c9:	e8 b2 ed ff ff       	call   7280 <fwp_drop4>
    84ce:	48 8b 3c 24          	mov    (%rsp),%rdi
    84d2:	e8 a9 ed ff ff       	call   7280 <fwp_drop4>
    84d7:	4c 89 ef             	mov    %r13,%rdi
    84da:	e8 e1 e4 ff ff       	call   69c0 <w176.constprop.0>
    84df:	4c 89 ef             	mov    %r13,%rdi
    84e2:	48 89 c3             	mov    %rax,%rbx
    84e5:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    84ea:	e8 61 fb ff ff       	call   8050 <fwp_drop10>
    84ef:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    84f4:	66 48 0f 6e db       	movq   %rbx,%xmm3
    84f9:	31 ff                	xor    %edi,%edi
    84fb:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    8500:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8504:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    8509:	e8 62 d8 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    850e:	48 8b 15 83 96 01 00 	mov    0x19683(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    8515:	48 89 c5             	mov    %rax,%rbp
    8518:	48 2b 05 51 96 01 00 	sub    0x19651(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    851f:	48 c1 e2 10          	shl    $0x10,%rdx
    8523:	48 39 d0             	cmp    %rdx,%rax
    8526:	73 55                	jae    857d <f37+0x2cd>
    8528:	48 89 c2             	mov    %rax,%rdx
    852b:	48 c1 ea 10          	shr    $0x10,%rdx
    852f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8533:	48 8b 15 7e 96 01 00 	mov    0x1967e(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    853a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    853e:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8542:	48 85 db             	test   %rbx,%rbx
    8545:	74 36                	je     857d <f37+0x2cd>
    8547:	0f b6 0a             	movzbl (%rdx),%ecx
    854a:	80 f9 02             	cmp    $0x2,%cl
    854d:	0f 84 15 01 00 00    	je     8668 <f37+0x3b8>
    8553:	80 f9 01             	cmp    $0x1,%cl
    8556:	75 25                	jne    857d <f37+0x2cd>
    8558:	8b 4a 18             	mov    0x18(%rdx),%ecx
    855b:	0f b7 c0             	movzwl %ax,%eax
    855e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8561:	48 0f af c1          	imul   %rcx,%rax
    8565:	48 c1 e8 20          	shr    $0x20,%rax
    8569:	48 39 d0             	cmp    %rdx,%rax
    856c:	73 0f                	jae    857d <f37+0x2cd>
    856e:	48 01 c3             	add    %rax,%rbx
    8571:	80 3b ff             	cmpb   $0xff,(%rbx)
    8574:	0f 84 a5 01 00 00    	je     871f <f37+0x46f>
    857a:	c6 03 01             	movb   $0x1,(%rbx)
    857d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8582:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8589:	00 00 
    858b:	0f 85 ca 01 00 00    	jne    875b <f37+0x4ab>
    8591:	48 83 c4 48          	add    $0x48,%rsp
    8595:	48 89 e8             	mov    %rbp,%rax
    8598:	5b                   	pop    %rbx
    8599:	5d                   	pop    %rbp
    859a:	41 5c                	pop    %r12
    859c:	41 5d                	pop    %r13
    859e:	41 5e                	pop    %r14
    85a0:	41 5f                	pop    %r15
    85a2:	c3                   	ret
    85a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    85a8:	66 85 c0             	test   %ax,%ax
    85ab:	0f 85 a9 fd ff ff    	jne    835a <f37+0xaa>
    85b1:	0f b6 07             	movzbl (%rdi),%eax
    85b4:	84 c0                	test   %al,%al
    85b6:	0f 84 9e fd ff ff    	je     835a <f37+0xaa>
    85bc:	3c fd                	cmp    $0xfd,%al
    85be:	0f 87 8d 01 00 00    	ja     8751 <f37+0x4a1>
    85c4:	83 c0 01             	add    $0x1,%eax
    85c7:	88 07                	mov    %al,(%rdi)
    85c9:	e9 8c fd ff ff       	jmp    835a <f37+0xaa>
    85ce:	48 f7 d9             	neg    %rcx
    85d1:	48 39 d1             	cmp    %rdx,%rcx
    85d4:	0f 83 e6 00 00 00    	jae    86c0 <f37+0x410>
    85da:	48 89 c8             	mov    %rcx,%rax
    85dd:	48 c1 e8 10          	shr    $0x10,%rax
    85e1:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    85e5:	48 8b 05 cc 95 01 00 	mov    0x195cc(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    85ec:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    85f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85f4:	48 85 ff             	test   %rdi,%rdi
    85f7:	0f 84 c3 00 00 00    	je     86c0 <f37+0x410>
    85fd:	0f b6 02             	movzbl (%rdx),%eax
    8600:	3c 02                	cmp    $0x2,%al
    8602:	0f 84 92 00 00 00    	je     869a <f37+0x3ea>
    8608:	3c 01                	cmp    $0x1,%al
    860a:	0f 85 b0 00 00 00    	jne    86c0 <f37+0x410>
    8610:	0f b7 c1             	movzwl %cx,%eax
    8613:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8616:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8619:	48 0f af c1          	imul   %rcx,%rax
    861d:	48 c1 e8 20          	shr    $0x20,%rax
    8621:	48 39 d0             	cmp    %rdx,%rax
    8624:	0f 83 96 00 00 00    	jae    86c0 <f37+0x410>
    862a:	48 01 c7             	add    %rax,%rdi
    862d:	0f b6 07             	movzbl (%rdi),%eax
    8630:	84 c0                	test   %al,%al
    8632:	0f 84 88 00 00 00    	je     86c0 <f37+0x410>
    8638:	31 db                	xor    %ebx,%ebx
    863a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8640:	3c fd                	cmp    $0xfd,%al
    8642:	0f 87 f1 00 00 00    	ja     8739 <f37+0x489>
    8648:	83 c0 01             	add    $0x1,%eax
    864b:	88 07                	mov    %al,(%rdi)
    864d:	31 d2                	xor    %edx,%edx
    864f:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    8654:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8659:	0f 85 00 fd ff ff    	jne    835f <f37+0xaf>
    865f:	e9 29 fd ff ff       	jmp    838d <f37+0xdd>
    8664:	0f 1f 40 00          	nopl   0x0(%rax)
    8668:	66 85 c0             	test   %ax,%ax
    866b:	0f 85 0c ff ff ff    	jne    857d <f37+0x2cd>
    8671:	e9 fb fe ff ff       	jmp    8571 <f37+0x2c1>
    8676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    867d:	00 00 00 
    8680:	66 85 c0             	test   %ax,%ax
    8683:	0f 85 c2 fd ff ff    	jne    844b <f37+0x19b>
    8689:	e9 af fd ff ff       	jmp    843d <f37+0x18d>
    868e:	66 90                	xchg   %ax,%ax
    8690:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8695:	e9 cd fc ff ff       	jmp    8367 <f37+0xb7>
    869a:	66 85 c9             	test   %cx,%cx
    869d:	75 21                	jne    86c0 <f37+0x410>
    869f:	0f b6 07             	movzbl (%rdi),%eax
    86a2:	84 c0                	test   %al,%al
    86a4:	74 1a                	je     86c0 <f37+0x410>
    86a6:	3c fd                	cmp    $0xfd,%al
    86a8:	0f 87 be 00 00 00    	ja     876c <f37+0x4bc>
    86ae:	83 c0 01             	add    $0x1,%eax
    86b1:	88 07                	mov    %al,(%rdi)
    86b3:	66 90                	xchg   %ax,%ax
    86b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86bc:	00 00 00 00 
    86c0:	be 02 00 00 00       	mov    $0x2,%esi
    86c5:	bf 08 00 00 00       	mov    $0x8,%edi
    86ca:	e8 81 d5 ff ff       	call   5c50 <fwp_heap_alloc>
    86cf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    86d6:	48 8b 15 bb 94 01 00 	mov    0x194bb(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    86dd:	49 89 c5             	mov    %rax,%r13
    86e0:	48 2b 05 89 94 01 00 	sub    0x19489(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    86e7:	48 c1 e2 10          	shl    $0x10,%rdx
    86eb:	48 39 d0             	cmp    %rdx,%rax
    86ee:	73 53                	jae    8743 <f37+0x493>
    86f0:	48 89 c2             	mov    %rax,%rdx
    86f3:	48 c1 ea 10          	shr    $0x10,%rdx
    86f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86fb:	48 8b 15 b6 94 01 00 	mov    0x194b6(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8702:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8706:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    870a:	48 85 ed             	test   %rbp,%rbp
    870d:	74 34                	je     8743 <f37+0x493>
    870f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8716:	00 00 
    8718:	31 db                	xor    %ebx,%ebx
    871a:	e9 f4 fc ff ff       	jmp    8413 <f37+0x163>
    871f:	48 89 df             	mov    %rbx,%rdi
    8722:	e8 e9 cd ff ff       	call   5510 <fwp_rc_forget_slot>
    8727:	e9 4e fe ff ff       	jmp    857a <f37+0x2ca>
    872c:	48 89 ef             	mov    %rbp,%rdi
    872f:	e8 dc cd ff ff       	call   5510 <fwp_rc_forget_slot>
    8734:	e9 0e fd ff ff       	jmp    8447 <f37+0x197>
    8739:	e8 b2 cc ff ff       	call   53f0 <fwp_rc_wide_dup>
    873e:	e9 0a ff ff ff       	jmp    864d <f37+0x39d>
    8743:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    874a:	00 00 
    874c:	e9 73 fd ff ff       	jmp    84c4 <f37+0x214>
    8751:	e8 9a cc ff ff       	call   53f0 <fwp_rc_wide_dup>
    8756:	e9 ff fb ff ff       	jmp    835a <f37+0xaa>
    875b:	e8 e0 ac ff ff       	call   3440 <__stack_chk_fail@plt>
    8760:	48 8d 3d 29 3a 00 00 	lea    0x3a29(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    8767:	e8 44 bc ff ff       	call   43b0 <fwp_trap>
    876c:	e8 7f cc ff ff       	call   53f0 <fwp_rc_wide_dup>
    8771:	e9 4a ff ff ff       	jmp    86c0 <f37+0x410>
    8776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    877d:	00 00 00 

0000000000008780 <fwp_owned_entry37>:
    8780:	f3 0f 1e fa          	endbr64
    8784:	48 8b 3f             	mov    (%rdi),%rdi
    8787:	e9 24 fb ff ff       	jmp    82b0 <f37>
    878c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008790 <e37>:
    8790:	f3 0f 1e fa          	endbr64
    8794:	53                   	push   %rbx
    8795:	48 8b 1f             	mov    (%rdi),%rbx
    8798:	48 89 df             	mov    %rbx,%rdi
    879b:	e8 d0 e2 ff ff       	call   6a70 <fwp_rc_share>
    87a0:	48 89 df             	mov    %rbx,%rdi
    87a3:	e8 08 fb ff ff       	call   82b0 <f37>
    87a8:	48 89 c3             	mov    %rax,%rbx
    87ab:	48 89 c7             	mov    %rax,%rdi
    87ae:	e8 bd e2 ff ff       	call   6a70 <fwp_rc_share>
    87b3:	48 89 d8             	mov    %rbx,%rax
    87b6:	5b                   	pop    %rbx
    87b7:	c3                   	ret
    87b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87bf:	00 

00000000000087c0 <fwp_write>:
    87c0:	41 57                	push   %r15
    87c2:	41 56                	push   %r14
    87c4:	41 55                	push   %r13
    87c6:	41 54                	push   %r12
    87c8:	55                   	push   %rbp
    87c9:	53                   	push   %rbx
    87ca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    87d1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    87d8:	00 00 
    87da:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    87e1:	00 
    87e2:	49 89 d4             	mov    %rdx,%r12
    87e5:	8b 12                	mov    (%rdx),%edx
    87e7:	83 fa 19             	cmp    $0x19,%edx
    87ea:	77 6a                	ja     8856 <fwp_write+0x96>
    87ec:	48 89 f5             	mov    %rsi,%rbp
    87ef:	89 d0                	mov    %edx,%eax
    87f1:	89 ce                	mov    %ecx,%esi
    87f3:	48 89 fb             	mov    %rdi,%rbx
    87f6:	48 8d 0d 03 43 00 00 	lea    0x4303(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    87fd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8801:	48 01 c8             	add    %rcx,%rax
    8804:	3e ff e0             	notrack jmp *%rax
    8807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    880e:	00 00 
    8810:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8814:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8818:	48 89 ca             	mov    %rcx,%rdx
    881b:	48 85 c9             	test   %rcx,%rcx
    881e:	0f 88 9c 0c 00 00    	js     94c0 <fwp_write+0xd00>
    8824:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    882b:	00 
    882c:	48 89 c6             	mov    %rax,%rsi
    882f:	4c 89 e7             	mov    %r12,%rdi
    8832:	e8 c9 b1 ff ff       	call   3a00 <fwp_fmt_u128>
    8837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    883e:	00 00 
    8840:	4c 89 e7             	mov    %r12,%rdi
    8843:	e8 e8 ab ff ff       	call   3430 <strlen@plt>
    8848:	4c 89 e6             	mov    %r12,%rsi
    884b:	48 89 df             	mov    %rbx,%rdi
    884e:	48 89 c2             	mov    %rax,%rdx
    8851:	e8 7a b9 ff ff       	call   41d0 <buf_put>
    8856:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    885d:	00 
    885e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8865:	00 00 
    8867:	0f 85 28 04 00 00    	jne    8c95 <fwp_write+0x4d5>
    886d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8874:	5b                   	pop    %rbx
    8875:	5d                   	pop    %rbp
    8876:	41 5c                	pop    %r12
    8878:	41 5d                	pop    %r13
    887a:	41 5e                	pop    %r14
    887c:	41 5f                	pop    %r15
    887e:	c3                   	ret
    887f:	90                   	nop
    8880:	49 89 e9             	mov    %rbp,%r9
    8883:	4c 8d 05 eb 37 00 00 	lea    0x37eb(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    888a:	b9 00 02 00 00       	mov    $0x200,%ecx
    888f:	ba 02 00 00 00       	mov    $0x2,%edx
    8894:	be 00 02 00 00       	mov    $0x200,%esi
    8899:	31 c0                	xor    %eax,%eax
    889b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88a2:	00 
    88a3:	e8 e8 aa ff ff       	call   3390 <__snprintf_chk@plt>
    88a8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88af:	00 
    88b0:	e8 7b ab ff ff       	call   3430 <strlen@plt>
    88b5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    88bc:	00 
    88bd:	48 89 df             	mov    %rbx,%rdi
    88c0:	48 89 c2             	mov    %rax,%rdx
    88c3:	e8 08 b9 ff ff       	call   41d0 <buf_put>
    88c8:	eb 8c                	jmp    8856 <fwp_write+0x96>
    88ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88d0:	49 89 e9             	mov    %rbp,%r9
    88d3:	4c 8d 05 db 38 00 00 	lea    0x38db(%rip),%r8        # c1b5 <_IO_stdin_used+0x1b5>
    88da:	eb ae                	jmp    888a <fwp_write+0xca>
    88dc:	0f 1f 40 00          	nopl   0x0(%rax)
    88e0:	83 fa 13             	cmp    $0x13,%edx
    88e3:	48 8d 05 c1 38 00 00 	lea    0x38c1(%rip),%rax        # c1ab <_IO_stdin_used+0x1ab>
    88ea:	48 8d 35 bf 38 00 00 	lea    0x38bf(%rip),%rsi        # c1b0 <_IO_stdin_used+0x1b0>
    88f1:	ba 04 00 00 00       	mov    $0x4,%edx
    88f6:	48 0f 44 f0          	cmove  %rax,%rsi
    88fa:	45 31 ed             	xor    %r13d,%r13d
    88fd:	e8 ce b8 ff ff       	call   41d0 <buf_put>
    8902:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8907:	0f 84 a3 08 00 00    	je     91b0 <fwp_write+0x9f0>
    890d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8912:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8917:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    891c:	48 89 df             	mov    %rbx,%rdi
    891f:	49 0f 44 c5          	cmove  %r13,%rax
    8923:	31 c9                	xor    %ecx,%ecx
    8925:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    892a:	e8 91 fe ff ff       	call   87c0 <fwp_write>
    892f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8934:	0f 84 6e 09 00 00    	je     92a8 <fwp_write+0xae8>
    893a:	49 83 c5 01          	add    $0x1,%r13
    893e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8942:	0f 83 68 08 00 00    	jae    91b0 <fwp_write+0x9f0>
    8948:	ba 02 00 00 00       	mov    $0x2,%edx
    894d:	48 8d 35 a1 38 00 00 	lea    0x38a1(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8954:	48 89 df             	mov    %rbx,%rdi
    8957:	e8 74 b8 ff ff       	call   41d0 <buf_put>
    895c:	eb af                	jmp    890d <fwp_write+0x14d>
    895e:	66 90                	xchg   %ax,%ax
    8960:	ba 06 00 00 00       	mov    $0x6,%edx
    8965:	48 8d 35 62 38 00 00 	lea    0x3862(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    896c:	48 83 c5 10          	add    $0x10,%rbp
    8970:	e8 5b b8 ff ff       	call   41d0 <buf_put>
    8975:	48 89 ef             	mov    %rbp,%rdi
    8978:	e8 b3 aa ff ff       	call   3430 <strlen@plt>
    897d:	48 89 ee             	mov    %rbp,%rsi
    8980:	48 89 df             	mov    %rbx,%rdi
    8983:	48 89 c2             	mov    %rax,%rdx
    8986:	e8 45 b8 ff ff       	call   41d0 <buf_put>
    898b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8990:	ba 01 00 00 00       	mov    $0x1,%edx
    8995:	48 89 df             	mov    %rbx,%rdi
    8998:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    899d:	e8 2e b8 ff ff       	call   41d0 <buf_put>
    89a2:	e9 af fe ff ff       	jmp    8856 <fwp_write+0x96>
    89a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ae:	00 00 
    89b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89b7:	00 
    89b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89bf:	00 00 
    89c1:	0f 85 ce 02 00 00    	jne    8c95 <fwp_write+0x4d5>
    89c7:	ba 0a 00 00 00       	mov    $0xa,%edx
    89cc:	48 8d 35 e7 37 00 00 	lea    0x37e7(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    89d3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    89da:	48 89 df             	mov    %rbx,%rdi
    89dd:	5b                   	pop    %rbx
    89de:	5d                   	pop    %rbp
    89df:	41 5c                	pop    %r12
    89e1:	41 5d                	pop    %r13
    89e3:	41 5e                	pop    %r14
    89e5:	41 5f                	pop    %r15
    89e7:	e9 e4 b7 ff ff       	jmp    41d0 <buf_put>
    89ec:	0f 1f 40 00          	nopl   0x0(%rax)
    89f0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    89f5:	4d 85 ed             	test   %r13,%r13
    89f8:	0f 84 02 0c 00 00    	je     9600 <fwp_write+0xe40>
    89fe:	48 8d 35 fd 37 00 00 	lea    0x37fd(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    8a05:	4c 89 ef             	mov    %r13,%rdi
    8a08:	e8 03 ab ff ff       	call   3510 <strcmp@plt>
    8a0d:	41 89 c1             	mov    %eax,%r9d
    8a10:	85 c0                	test   %eax,%eax
    8a12:	0f 84 6c 0c 00 00    	je     9684 <fwp_write+0xec4>
    8a18:	4c 89 ef             	mov    %r13,%rdi
    8a1b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a20:	e8 0b aa ff ff       	call   3430 <strlen@plt>
    8a25:	4c 89 ee             	mov    %r13,%rsi
    8a28:	48 89 df             	mov    %rbx,%rdi
    8a2b:	48 89 c2             	mov    %rax,%rdx
    8a2e:	e8 9d b7 ff ff       	call   41d0 <buf_put>
    8a33:	ba 01 00 00 00       	mov    $0x1,%edx
    8a38:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a3d:	48 89 df             	mov    %rbx,%rdi
    8a40:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a45:	e8 86 b7 ff ff       	call   41d0 <buf_put>
    8a4a:	ba 01 00 00 00       	mov    $0x1,%edx
    8a4f:	4c 89 fe             	mov    %r15,%rsi
    8a52:	48 89 df             	mov    %rbx,%rdi
    8a55:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8a5a:	e8 71 b7 ff ff       	call   41d0 <buf_put>
    8a5f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8a64:	45 31 f6             	xor    %r14d,%r14d
    8a67:	85 d2                	test   %edx,%edx
    8a69:	0f 8e 81 0a 00 00    	jle    94f0 <fwp_write+0xd30>
    8a6f:	45 31 ed             	xor    %r13d,%r13d
    8a72:	4d 85 ed             	test   %r13,%r13
    8a75:	0f 85 75 07 00 00    	jne    91f0 <fwp_write+0xa30>
    8a7b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8a82:	00 
    8a83:	45 85 f6             	test   %r14d,%r14d
    8a86:	0f 84 84 07 00 00    	je     9210 <fwp_write+0xa50>
    8a8c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8a91:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8a96:	48 89 df             	mov    %rbx,%rdi
    8a99:	49 83 c5 01          	add    $0x1,%r13
    8a9d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8aa1:	31 c9                	xor    %ecx,%ecx
    8aa3:	e8 18 fd ff ff       	call   87c0 <fwp_write>
    8aa8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8aad:	7f c3                	jg     8a72 <fwp_write+0x2b2>
    8aaf:	45 85 f6             	test   %r14d,%r14d
    8ab2:	0f 84 38 0a 00 00    	je     94f0 <fwp_write+0xd30>
    8ab8:	b8 29 00 00 00       	mov    $0x29,%eax
    8abd:	ba 01 00 00 00       	mov    $0x1,%edx
    8ac2:	4c 89 fe             	mov    %r15,%rsi
    8ac5:	48 89 df             	mov    %rbx,%rdi
    8ac8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8acc:	e8 ff b6 ff ff       	call   41d0 <buf_put>
    8ad1:	e9 80 fd ff ff       	jmp    8856 <fwp_write+0x96>
    8ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8add:	00 00 00 
    8ae0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ae5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8aea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8aef:	e8 dc b6 ff ff       	call   41d0 <buf_put>
    8af4:	48 85 ed             	test   %rbp,%rbp
    8af7:	0f 84 93 06 00 00    	je     9190 <fwp_write+0x9d0>
    8afd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8b01:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b06:	31 c9                	xor    %ecx,%ecx
    8b08:	48 89 df             	mov    %rbx,%rdi
    8b0b:	e8 b0 fc ff ff       	call   87c0 <fwp_write>
    8b10:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8b14:	48 85 ed             	test   %rbp,%rbp
    8b17:	0f 84 73 06 00 00    	je     9190 <fwp_write+0x9d0>
    8b1d:	ba 02 00 00 00       	mov    $0x2,%edx
    8b22:	48 8d 35 cc 36 00 00 	lea    0x36cc(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8b29:	48 89 df             	mov    %rbx,%rdi
    8b2c:	e8 9f b6 ff ff       	call   41d0 <buf_put>
    8b31:	eb ca                	jmp    8afd <fwp_write+0x33d>
    8b33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b38:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8b3c:	85 f6                	test   %esi,%esi
    8b3e:	0f 84 fc 07 00 00    	je     9340 <fwp_write+0xb80>
    8b44:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b4b:	00 
    8b4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b53:	00 00 
    8b55:	0f 85 3a 01 00 00    	jne    8c95 <fwp_write+0x4d5>
    8b5b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8b5f:	4c 89 ea             	mov    %r13,%rdx
    8b62:	e9 6c fe ff ff       	jmp    89d3 <fwp_write+0x213>
    8b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b6e:	00 00 
    8b70:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8b75:	ba 01 00 00 00       	mov    $0x1,%edx
    8b7a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8b7f:	48 89 ee             	mov    %rbp,%rsi
    8b82:	e8 49 b6 ff ff       	call   41d0 <buf_put>
    8b87:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8b8c:	4c 89 e7             	mov    %r12,%rdi
    8b8f:	e8 9c a8 ff ff       	call   3430 <strlen@plt>
    8b94:	4c 89 e6             	mov    %r12,%rsi
    8b97:	48 89 df             	mov    %rbx,%rdi
    8b9a:	48 89 c2             	mov    %rax,%rdx
    8b9d:	e8 2e b6 ff ff       	call   41d0 <buf_put>
    8ba2:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba7:	48 89 ee             	mov    %rbp,%rsi
    8baa:	48 89 df             	mov    %rbx,%rdi
    8bad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8bb2:	e8 19 b6 ff ff       	call   41d0 <buf_put>
    8bb7:	e9 9a fc ff ff       	jmp    8856 <fwp_write+0x96>
    8bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8bc0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8bc5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8bc9:	0f 8a 8e 0b 00 00    	jp     975d <fwp_write+0xf9d>
    8bcf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8bd3:	66 0f 54 05 75 40 00 	andpd  0x4075(%rip),%xmm0        # cc50 <msg.4+0xe0>
    8bda:	00 
    8bdb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8be0:	66 0f 2e 05 b0 3f 00 	ucomisd 0x3fb0(%rip),%xmm0        # cb98 <msg.4+0x28>
    8be7:	00 
    8be8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bef:	00 
    8bf0:	0f 87 b2 09 00 00    	ja     95a8 <fwp_write+0xde8>
    8bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bfd:	00 00 00 
    8c00:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c04:	89 ee                	mov    %ebp,%esi
    8c06:	4c 89 e7             	mov    %r12,%rdi
    8c09:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8c0e:	e8 bd ba ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8c13:	31 f6                	xor    %esi,%esi
    8c15:	4c 89 e7             	mov    %r12,%rdi
    8c18:	e8 d3 a7 ff ff       	call   33f0 <strtod@plt>
    8c1d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8c22:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8c26:	7a 06                	jp     8c2e <fwp_write+0x46e>
    8c28:	0f 84 e9 01 00 00    	je     8e17 <fwp_write+0x657>
    8c2e:	83 c5 01             	add    $0x1,%ebp
    8c31:	83 fd 12             	cmp    $0x12,%ebp
    8c34:	75 ca                	jne    8c00 <fwp_write+0x440>
    8c36:	be 11 00 00 00       	mov    $0x11,%esi
    8c3b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c3f:	4c 89 e7             	mov    %r12,%rdi
    8c42:	e8 89 ba ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8c47:	e9 cb 01 00 00       	jmp    8e17 <fwp_write+0x657>
    8c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c50:	48 83 fd 01          	cmp    $0x1,%rbp
    8c54:	0f 84 e6 08 00 00    	je     9540 <fwp_write+0xd80>
    8c5a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8c5e:	b8 02 00 00 00       	mov    $0x2,%eax
    8c63:	ba 01 00 00 00       	mov    $0x1,%edx
    8c68:	48 0f 44 d0          	cmove  %rax,%rdx
    8c6c:	48 8d 35 30 35 00 00 	lea    0x3530(%rip),%rsi        # c1a3 <_IO_stdin_used+0x1a3>
    8c73:	48 8d 05 2e 35 00 00 	lea    0x352e(%rip),%rax        # c1a8 <_IO_stdin_used+0x1a8>
    8c7a:	48 0f 44 f0          	cmove  %rax,%rsi
    8c7e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c85:	00 
    8c86:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c8d:	00 00 
    8c8f:	0f 84 3e fd ff ff    	je     89d3 <fwp_write+0x213>
    8c95:	e8 a6 a7 ff ff       	call   3440 <__stack_chk_fail@plt>
    8c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ca0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ca5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8caa:	e8 61 b4 ff ff       	call   4110 <buf_grow>
    8caf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8cb3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8cb9:	4c 03 0b             	add    (%rbx),%r9
    8cbc:	66 45 89 11          	mov    %r10w,(%r9)
    8cc0:	45 85 e4             	test   %r12d,%r12d
    8cc3:	0f 8e 07 05 00 00    	jle    91d0 <fwp_write+0xa10>
    8cc9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8cd0:	55 55 55 
    8cd3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8cd8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8cdf:	aa aa aa 
    8ce2:	49 83 c1 01          	add    $0x1,%r9
    8ce6:	eb 45                	jmp    8d2d <fwp_write+0x56d>
    8ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8cef:	00 
    8cf0:	be 01 00 00 00       	mov    $0x1,%esi
    8cf5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8cfa:	88 07                	mov    %al,(%rdi)
    8cfc:	48 89 e8             	mov    %rbp,%rax
    8cff:	49 f7 e8             	imul   %r8
    8d02:	48 89 e8             	mov    %rbp,%rax
    8d05:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d09:	48 29 c2             	sub    %rax,%rdx
    8d0c:	48 85 c9             	test   %rcx,%rcx
    8d0f:	0f 95 c0             	setne  %al
    8d12:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8d16:	48 83 ef 01          	sub    $0x1,%rdi
    8d1a:	48 21 c5             	and    %rax,%rbp
    8d1d:	48 29 ea             	sub    %rbp,%rdx
    8d20:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8d24:	49 39 f9             	cmp    %rdi,%r9
    8d27:	0f 84 a3 04 00 00    	je     91d0 <fwp_write+0xa10>
    8d2d:	48 89 e8             	mov    %rbp,%rax
    8d30:	49 f7 e8             	imul   %r8
    8d33:	48 89 e8             	mov    %rbp,%rax
    8d36:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d3a:	48 89 d1             	mov    %rdx,%rcx
    8d3d:	48 29 c1             	sub    %rax,%rcx
    8d40:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8d44:	48 89 e9             	mov    %rbp,%rcx
    8d47:	48 29 c1             	sub    %rax,%rcx
    8d4a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8d4e:	49 f7 e2             	mul    %r10
    8d51:	b8 30 00 00 00       	mov    $0x30,%eax
    8d56:	48 89 d6             	mov    %rdx,%rsi
    8d59:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8d5d:	48 d1 ee             	shr    $1,%rsi
    8d60:	48 01 f2             	add    %rsi,%rdx
    8d63:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8d67:	48 29 d6             	sub    %rdx,%rsi
    8d6a:	74 8e                	je     8cfa <fwp_write+0x53a>
    8d6c:	48 83 fe 01          	cmp    $0x1,%rsi
    8d70:	0f 85 7a ff ff ff    	jne    8cf0 <fwp_write+0x530>
    8d76:	31 f6                	xor    %esi,%esi
    8d78:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8d7d:	e9 78 ff ff ff       	jmp    8cfa <fwp_write+0x53a>
    8d82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d88:	66 0f 6e cd          	movd   %ebp,%xmm1
    8d8c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8d8f:	0f 8a c8 09 00 00    	jp     975d <fwp_write+0xf9d>
    8d95:	0f 28 c1             	movaps %xmm1,%xmm0
    8d98:	0f 54 05 a1 3e 00 00 	andps  0x3ea1(%rip),%xmm0        # cc40 <msg.4+0xd0>
    8d9f:	0f 2e 05 5e 32 00 00 	ucomiss 0x325e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8da6:	0f 87 24 08 00 00    	ja     95d0 <fwp_write+0xe10>
    8dac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8db0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8db6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8dbd:	00 
    8dbe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8dc2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8dce:	00 00 
    8dd0:	44 89 ee             	mov    %r13d,%esi
    8dd3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8dd8:	4c 89 e7             	mov    %r12,%rdi
    8ddb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8de0:	e8 eb b8 ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8de5:	31 f6                	xor    %esi,%esi
    8de7:	4c 89 e7             	mov    %r12,%rdi
    8dea:	e8 a1 a6 ff ff       	call   3490 <strtof@plt>
    8def:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8df4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8df7:	7a 02                	jp     8dfb <fwp_write+0x63b>
    8df9:	74 1c                	je     8e17 <fwp_write+0x657>
    8dfb:	41 83 c5 01          	add    $0x1,%r13d
    8dff:	41 83 fd 0a          	cmp    $0xa,%r13d
    8e03:	75 cb                	jne    8dd0 <fwp_write+0x610>
    8e05:	be 09 00 00 00       	mov    $0x9,%esi
    8e0a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8e0f:	4c 89 e7             	mov    %r12,%rdi
    8e12:	e8 b9 b8 ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8e17:	4c 89 e7             	mov    %r12,%rdi
    8e1a:	e8 21 b5 ff ff       	call   4340 <fwp_finish_float>
    8e1f:	e9 1c fa ff ff       	jmp    8840 <fwp_write+0x80>
    8e24:	0f 1f 40 00          	nopl   0x0(%rax)
    8e28:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8e2c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8e30:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8e37:	00 
    8e38:	48 89 ef             	mov    %rbp,%rdi
    8e3b:	e8 c0 ab ff ff       	call   3a00 <fwp_fmt_u128>
    8e40:	48 89 ef             	mov    %rbp,%rdi
    8e43:	e8 e8 a5 ff ff       	call   3430 <strlen@plt>
    8e48:	48 89 ee             	mov    %rbp,%rsi
    8e4b:	48 89 df             	mov    %rbx,%rdi
    8e4e:	48 89 c2             	mov    %rax,%rdx
    8e51:	e8 7a b3 ff ff       	call   41d0 <buf_put>
    8e56:	e9 fb f9 ff ff       	jmp    8856 <fwp_write+0x96>
    8e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e60:	ba 06 00 00 00       	mov    $0x6,%edx
    8e65:	48 8d 35 8c 33 00 00 	lea    0x338c(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    8e6c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8e72:	e8 59 b3 ff ff       	call   41d0 <buf_put>
    8e77:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e7e:	ff ff 7f 
    8e81:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e85:	0f 84 86 02 00 00    	je     9111 <fwp_write+0x951>
    8e8b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e90:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e94:	48 85 d2             	test   %rdx,%rdx
    8e97:	0f 84 ae 00 00 00    	je     8f4b <fwp_write+0x78b>
    8e9d:	8b 0a                	mov    (%rdx),%ecx
    8e9f:	83 f9 1c             	cmp    $0x1c,%ecx
    8ea2:	0f 84 58 06 00 00    	je     9500 <fwp_write+0xd40>
    8ea8:	83 f9 1b             	cmp    $0x1b,%ecx
    8eab:	0f 87 9a 00 00 00    	ja     8f4b <fwp_write+0x78b>
    8eb1:	be 01 00 00 00       	mov    $0x1,%esi
    8eb6:	48 d3 e6             	shl    %cl,%rsi
    8eb9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8ebf:	0f 85 4b 04 00 00    	jne    9310 <fwp_write+0xb50>
    8ec5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8ecb:	0f 85 0f 04 00 00    	jne    92e0 <fwp_write+0xb20>
    8ed1:	83 e6 21             	and    $0x21,%esi
    8ed4:	74 75                	je     8f4b <fwp_write+0x78b>
    8ed6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8edb:	48 85 ff             	test   %rdi,%rdi
    8ede:	79 07                	jns    8ee7 <fwp_write+0x727>
    8ee0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8ee4:	4c 01 ee             	add    %r13,%rsi
    8ee7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8eeb:	85 c9                	test   %ecx,%ecx
    8eed:	40 0f b6 f7          	movzbl %dil,%esi
    8ef1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8efc:	00 00 00 00 
    8f00:	31 c9                	xor    %ecx,%ecx
    8f02:	48 89 df             	mov    %rbx,%rdi
    8f05:	49 83 c5 01          	add    $0x1,%r13
    8f09:	e8 b2 f8 ff ff       	call   87c0 <fwp_write>
    8f0e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8f15:	ff ff 7f 
    8f18:	48 23 55 00          	and    0x0(%rbp),%rdx
    8f1c:	49 39 d5             	cmp    %rdx,%r13
    8f1f:	0f 83 ec 01 00 00    	jae    9111 <fwp_write+0x951>
    8f25:	ba 02 00 00 00       	mov    $0x2,%edx
    8f2a:	48 89 df             	mov    %rbx,%rdi
    8f2d:	48 8d 35 c1 32 00 00 	lea    0x32c1(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8f34:	e8 97 b2 ff ff       	call   41d0 <buf_put>
    8f39:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f3e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8f42:	48 85 d2             	test   %rdx,%rdx
    8f45:	0f 85 52 ff ff ff    	jne    8e9d <fwp_write+0x6dd>
    8f4b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8f50:	48 85 ff             	test   %rdi,%rdi
    8f53:	0f 88 cf 05 00 00    	js     9528 <fwp_write+0xd68>
    8f59:	48 8b 31             	mov    (%rcx),%rsi
    8f5c:	eb a2                	jmp    8f00 <fwp_write+0x740>
    8f5e:	66 90                	xchg   %ax,%ax
    8f60:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f67:	00 
    8f68:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f6f:	00 00 
    8f71:	0f 85 1e fd ff ff    	jne    8c95 <fwp_write+0x4d5>
    8f77:	ba 08 00 00 00       	mov    $0x8,%edx
    8f7c:	48 8d 35 42 32 00 00 	lea    0x3242(%rip),%rsi        # c1c5 <_IO_stdin_used+0x1c5>
    8f83:	e9 4b fa ff ff       	jmp    89d3 <fwp_write+0x213>
    8f88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f8f:	00 
    8f90:	89 e8                	mov    %ebp,%eax
    8f92:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8f99:	76 03                	jbe    8f9e <fwp_write+0x7de>
    8f9b:	8b 45 00             	mov    0x0(%rbp),%eax
    8f9e:	41 89 c6             	mov    %eax,%r14d
    8fa1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8fa6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8fab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8faf:	4c 89 ef             	mov    %r13,%rdi
    8fb2:	e8 79 a4 ff ff       	call   3430 <strlen@plt>
    8fb7:	4c 89 ee             	mov    %r13,%rsi
    8fba:	48 89 df             	mov    %rbx,%rdi
    8fbd:	48 89 c2             	mov    %rax,%rdx
    8fc0:	e8 0b b2 ff ff       	call   41d0 <buf_put>
    8fc5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8fca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8fce:	85 f6                	test   %esi,%esi
    8fd0:	0f 8e 80 f8 ff ff    	jle    8856 <fwp_write+0x96>
    8fd6:	45 31 ed             	xor    %r13d,%r13d
    8fd9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fde:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8fe3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8fe8:	ba 01 00 00 00       	mov    $0x1,%edx
    8fed:	4c 89 fe             	mov    %r15,%rsi
    8ff0:	48 89 04 24          	mov    %rax,(%rsp)
    8ff4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8ff9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8ffd:	48 89 df             	mov    %rbx,%rdi
    9000:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9004:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9009:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    900e:	e8 bd b1 ff ff       	call   41d0 <buf_put>
    9013:	41 8b 06             	mov    (%r14),%eax
    9016:	83 f8 0e             	cmp    $0xe,%eax
    9019:	0f 84 71 02 00 00    	je     9290 <fwp_write+0xad0>
    901f:	83 f8 10             	cmp    $0x10,%eax
    9022:	0f 84 38 02 00 00    	je     9260 <fwp_write+0xaa0>
    9028:	83 f8 0a             	cmp    $0xa,%eax
    902b:	0f 84 7f 04 00 00    	je     94b0 <fwp_write+0xcf0>
    9031:	0f 8f f9 00 00 00    	jg     9130 <fwp_write+0x970>
    9037:	83 f8 03             	cmp    $0x3,%eax
    903a:	0f 8f 50 04 00 00    	jg     9490 <fwp_write+0xcd0>
    9040:	85 c0                	test   %eax,%eax
    9042:	78 10                	js     9054 <fwp_write+0x894>
    9044:	48 8b 04 24          	mov    (%rsp),%rax
    9048:	48 c1 e8 3f          	shr    $0x3f,%rax
    904c:	85 c0                	test   %eax,%eax
    904e:	0f 85 f9 00 00 00    	jne    914d <fwp_write+0x98d>
    9054:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9059:	48 8b 34 24          	mov    (%rsp),%rsi
    905d:	31 c9                	xor    %ecx,%ecx
    905f:	48 89 df             	mov    %rbx,%rdi
    9062:	e8 59 f7 ff ff       	call   87c0 <fwp_write>
    9067:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    906c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9071:	49 83 c5 01          	add    $0x1,%r13
    9075:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9079:	0f 8f 5f ff ff ff    	jg     8fde <fwp_write+0x81e>
    907f:	e9 d2 f7 ff ff       	jmp    8856 <fwp_write+0x96>
    9084:	0f 1f 40 00          	nopl   0x0(%rax)
    9088:	ba 06 00 00 00       	mov    $0x6,%edx
    908d:	48 8d 35 57 31 00 00 	lea    0x3157(%rip),%rsi        # c1eb <_IO_stdin_used+0x1eb>
    9094:	45 31 ed             	xor    %r13d,%r13d
    9097:	e8 34 b1 ff ff       	call   41d0 <buf_put>
    909c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    90a1:	75 19                	jne    90bc <fwp_write+0x8fc>
    90a3:	eb 6c                	jmp    9111 <fwp_write+0x951>
    90a5:	0f 1f 00             	nopl   (%rax)
    90a8:	ba 02 00 00 00       	mov    $0x2,%edx
    90ad:	48 8d 35 41 31 00 00 	lea    0x3141(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    90b4:	48 89 df             	mov    %rbx,%rdi
    90b7:	e8 14 b1 ff ff       	call   41d0 <buf_put>
    90bc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    90c2:	b9 00 02 00 00       	mov    $0x200,%ecx
    90c7:	31 c0                	xor    %eax,%eax
    90c9:	49 83 c5 01          	add    $0x1,%r13
    90cd:	4c 8d 05 1e 31 00 00 	lea    0x311e(%rip),%r8        # c1f2 <_IO_stdin_used+0x1f2>
    90d4:	ba 02 00 00 00       	mov    $0x2,%edx
    90d9:	be 00 02 00 00       	mov    $0x200,%esi
    90de:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    90e5:	00 
    90e6:	e8 a5 a2 ff ff       	call   3390 <__snprintf_chk@plt>
    90eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    90f2:	00 
    90f3:	e8 38 a3 ff ff       	call   3430 <strlen@plt>
    90f8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    90ff:	00 
    9100:	48 89 df             	mov    %rbx,%rdi
    9103:	48 89 c2             	mov    %rax,%rdx
    9106:	e8 c5 b0 ff ff       	call   41d0 <buf_put>
    910b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    910f:	72 97                	jb     90a8 <fwp_write+0x8e8>
    9111:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9116:	ba 01 00 00 00       	mov    $0x1,%edx
    911b:	48 89 df             	mov    %rbx,%rdi
    911e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9123:	e8 a8 b0 ff ff       	call   41d0 <buf_put>
    9128:	e9 29 f7 ff ff       	jmp    8856 <fwp_write+0x96>
    912d:	0f 1f 00             	nopl   (%rax)
    9130:	83 f8 0b             	cmp    $0xb,%eax
    9133:	0f 85 1b ff ff ff    	jne    9054 <fwp_write+0x894>
    9139:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    913e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9142:	83 e0 01             	and    $0x1,%eax
    9145:	85 c0                	test   %eax,%eax
    9147:	0f 84 07 ff ff ff    	je     9054 <fwp_write+0x894>
    914d:	4c 89 fe             	mov    %r15,%rsi
    9150:	48 89 df             	mov    %rbx,%rdi
    9153:	ba 01 00 00 00       	mov    $0x1,%edx
    9158:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    915d:	e8 6e b0 ff ff       	call   41d0 <buf_put>
    9162:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9167:	48 8b 34 24          	mov    (%rsp),%rsi
    916b:	31 c9                	xor    %ecx,%ecx
    916d:	48 89 df             	mov    %rbx,%rdi
    9170:	e8 4b f6 ff ff       	call   87c0 <fwp_write>
    9175:	ba 01 00 00 00       	mov    $0x1,%edx
    917a:	4c 89 fe             	mov    %r15,%rsi
    917d:	48 89 df             	mov    %rbx,%rdi
    9180:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9185:	e8 46 b0 ff ff       	call   41d0 <buf_put>
    918a:	e9 d8 fe ff ff       	jmp    9067 <fwp_write+0x8a7>
    918f:	90                   	nop
    9190:	ba 01 00 00 00       	mov    $0x1,%edx
    9195:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    919a:	48 89 df             	mov    %rbx,%rdi
    919d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    91a2:	e8 29 b0 ff ff       	call   41d0 <buf_put>
    91a7:	e9 aa f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91ac:	0f 1f 40 00          	nopl   0x0(%rax)
    91b0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91b5:	ba 01 00 00 00       	mov    $0x1,%edx
    91ba:	48 89 df             	mov    %rbx,%rdi
    91bd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    91c2:	e8 09 b0 ff ff       	call   41d0 <buf_put>
    91c7:	e9 8a f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91cc:	0f 1f 40 00          	nopl   0x0(%rax)
    91d0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    91d4:	48 8b 13             	mov    (%rbx),%rdx
    91d7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    91dc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    91e0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    91e4:	e9 6d f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91f0:	ba 02 00 00 00       	mov    $0x2,%edx
    91f5:	48 8d 35 f9 2f 00 00 	lea    0x2ff9(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    91fc:	48 89 df             	mov    %rbx,%rdi
    91ff:	e8 cc af ff ff       	call   41d0 <buf_put>
    9204:	e9 72 f8 ff ff       	jmp    8a7b <fwp_write+0x2bb>
    9209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9210:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9215:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    921a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    921e:	48 89 f7             	mov    %rsi,%rdi
    9221:	48 89 34 24          	mov    %rsi,(%rsp)
    9225:	e8 06 a2 ff ff       	call   3430 <strlen@plt>
    922a:	48 8b 34 24          	mov    (%rsp),%rsi
    922e:	48 89 df             	mov    %rbx,%rdi
    9231:	48 89 c2             	mov    %rax,%rdx
    9234:	e8 97 af ff ff       	call   41d0 <buf_put>
    9239:	ba 03 00 00 00       	mov    $0x3,%edx
    923e:	48 8d 35 d3 2f 00 00 	lea    0x2fd3(%rip),%rsi        # c218 <_IO_stdin_used+0x218>
    9245:	48 89 df             	mov    %rbx,%rdi
    9248:	e8 83 af ff ff       	call   41d0 <buf_put>
    924d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9252:	e9 35 f8 ff ff       	jmp    8a8c <fwp_write+0x2cc>
    9257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    925e:	00 00 
    9260:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9265:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9269:	48 85 ff             	test   %rdi,%rdi
    926c:	0f 84 e2 fd ff ff    	je     9054 <fwp_write+0x894>
    9272:	48 8d 35 89 2f 00 00 	lea    0x2f89(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    9279:	e8 92 a2 ff ff       	call   3510 <strcmp@plt>
    927e:	85 c0                	test   %eax,%eax
    9280:	0f 95 c0             	setne  %al
    9283:	0f b6 c0             	movzbl %al,%eax
    9286:	e9 c1 fd ff ff       	jmp    904c <fwp_write+0x88c>
    928b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9290:	31 c0                	xor    %eax,%eax
    9292:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9299:	00 
    929a:	0f 97 c0             	seta   %al
    929d:	e9 aa fd ff ff       	jmp    904c <fwp_write+0x88c>
    92a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92a8:	48 89 df             	mov    %rbx,%rdi
    92ab:	ba 02 00 00 00       	mov    $0x2,%edx
    92b0:	48 8d 35 48 2f 00 00 	lea    0x2f48(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    92b7:	e8 14 af ff ff       	call   41d0 <buf_put>
    92bc:	4c 89 e8             	mov    %r13,%rax
    92bf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    92c4:	31 c9                	xor    %ecx,%ecx
    92c6:	48 c1 e0 04          	shl    $0x4,%rax
    92ca:	48 89 df             	mov    %rbx,%rdi
    92cd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    92d2:	e8 e9 f4 ff ff       	call   87c0 <fwp_write>
    92d7:	e9 5e f6 ff ff       	jmp    893a <fwp_write+0x17a>
    92dc:	0f 1f 40 00          	nopl   0x0(%rax)
    92e0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    92e5:	48 85 ff             	test   %rdi,%rdi
    92e8:	79 0c                	jns    92f6 <fwp_write+0xb36>
    92ea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    92f1:	00 
    92f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    92f6:	48 63 3e             	movslq (%rsi),%rdi
    92f9:	83 f9 02             	cmp    $0x2,%ecx
    92fc:	89 fe                	mov    %edi,%esi
    92fe:	48 0f 44 f7          	cmove  %rdi,%rsi
    9302:	e9 f9 fb ff ff       	jmp    8f00 <fwp_write+0x740>
    9307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    930e:	00 00 
    9310:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9315:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    931a:	48 85 ff             	test   %rdi,%rdi
    931d:	0f 88 0f 03 00 00    	js     9632 <fwp_write+0xe72>
    9323:	49 0f bf 38          	movswq (%r8),%rdi
    9327:	83 f9 01             	cmp    $0x1,%ecx
    932a:	0f b7 f7             	movzwl %di,%esi
    932d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9331:	e9 ca fb ff ff       	jmp    8f00 <fwp_write+0x740>
    9336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    933d:	00 00 00 
    9340:	ba 01 00 00 00       	mov    $0x1,%edx
    9345:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    934a:	48 83 c5 08          	add    $0x8,%rbp
    934e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9353:	e8 78 ae ff ff       	call   41d0 <buf_put>
    9358:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    935d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9362:	4d 85 ed             	test   %r13,%r13
    9365:	75 46                	jne    93ad <fwp_write+0xbed>
    9367:	e9 04 01 00 00       	jmp    9470 <fwp_write+0xcb0>
    936c:	0f 1f 40 00          	nopl   0x0(%rax)
    9370:	41 80 f9 09          	cmp    $0x9,%r9b
    9374:	0f 84 d6 00 00 00    	je     9450 <fwp_write+0xc90>
    937a:	41 80 f9 0a          	cmp    $0xa,%r9b
    937e:	0f 85 9c 00 00 00    	jne    9420 <fwp_write+0xc60>
    9384:	ba 02 00 00 00       	mov    $0x2,%edx
    9389:	48 8d 35 4b 2e 00 00 	lea    0x2e4b(%rip),%rsi        # c1db <_IO_stdin_used+0x1db>
    9390:	48 89 df             	mov    %rbx,%rdi
    9393:	e8 38 ae ff ff       	call   41d0 <buf_put>
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 
    93a0:	48 83 c5 01          	add    $0x1,%rbp
    93a4:	49 39 ec             	cmp    %rbp,%r12
    93a7:	0f 84 c3 00 00 00    	je     9470 <fwp_write+0xcb0>
    93ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    93b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    93b6:	74 28                	je     93e0 <fwp_write+0xc20>
    93b8:	7e b6                	jle    9370 <fwp_write+0xbb0>
    93ba:	41 80 f9 22          	cmp    $0x22,%r9b
    93be:	74 40                	je     9400 <fwp_write+0xc40>
    93c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    93c4:	75 5a                	jne    9420 <fwp_write+0xc60>
    93c6:	ba 02 00 00 00       	mov    $0x2,%edx
    93cb:	48 8d 35 06 2e 00 00 	lea    0x2e06(%rip),%rsi        # c1d8 <_IO_stdin_used+0x1d8>
    93d2:	48 89 df             	mov    %rbx,%rdi
    93d5:	e8 f6 ad ff ff       	call   41d0 <buf_put>
    93da:	eb c4                	jmp    93a0 <fwp_write+0xbe0>
    93dc:	0f 1f 40 00          	nopl   0x0(%rax)
    93e0:	ba 02 00 00 00       	mov    $0x2,%edx
    93e5:	48 8d 35 f5 2d 00 00 	lea    0x2df5(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    93ec:	48 89 df             	mov    %rbx,%rdi
    93ef:	e8 dc ad ff ff       	call   41d0 <buf_put>
    93f4:	eb aa                	jmp    93a0 <fwp_write+0xbe0>
    93f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93fd:	00 00 00 
    9400:	ba 02 00 00 00       	mov    $0x2,%edx
    9405:	48 8d 35 c9 2d 00 00 	lea    0x2dc9(%rip),%rsi        # c1d5 <_IO_stdin_used+0x1d5>
    940c:	48 89 df             	mov    %rbx,%rdi
    940f:	e8 bc ad ff ff       	call   41d0 <buf_put>
    9414:	eb 8a                	jmp    93a0 <fwp_write+0xbe0>
    9416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    941d:	00 00 00 
    9420:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9424:	0f 86 2e 01 00 00    	jbe    9558 <fwp_write+0xd98>
    942a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    942e:	0f 84 24 01 00 00    	je     9558 <fwp_write+0xd98>
    9434:	ba 01 00 00 00       	mov    $0x1,%edx
    9439:	4c 89 fe             	mov    %r15,%rsi
    943c:	48 89 df             	mov    %rbx,%rdi
    943f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9444:	e8 87 ad ff ff       	call   41d0 <buf_put>
    9449:	e9 52 ff ff ff       	jmp    93a0 <fwp_write+0xbe0>
    944e:	66 90                	xchg   %ax,%ax
    9450:	ba 02 00 00 00       	mov    $0x2,%edx
    9455:	48 8d 35 82 2d 00 00 	lea    0x2d82(%rip),%rsi        # c1de <_IO_stdin_used+0x1de>
    945c:	48 89 df             	mov    %rbx,%rdi
    945f:	e8 6c ad ff ff       	call   41d0 <buf_put>
    9464:	e9 37 ff ff ff       	jmp    93a0 <fwp_write+0xbe0>
    9469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9470:	ba 01 00 00 00       	mov    $0x1,%edx
    9475:	4c 89 fe             	mov    %r15,%rsi
    9478:	48 89 df             	mov    %rbx,%rdi
    947b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9480:	e8 4b ad ff ff       	call   41d0 <buf_put>
    9485:	e9 cc f3 ff ff       	jmp    8856 <fwp_write+0x96>
    948a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9490:	83 f8 04             	cmp    $0x4,%eax
    9493:	0f 85 bb fb ff ff    	jne    9054 <fwp_write+0x894>
    9499:	48 8b 04 24          	mov    (%rsp),%rax
    949d:	48 8b 40 08          	mov    0x8(%rax),%rax
    94a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    94a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    94aa:	e9 96 fc ff ff       	jmp    9145 <fwp_write+0x985>
    94af:	90                   	nop
    94b0:	8b 0c 24             	mov    (%rsp),%ecx
    94b3:	31 c0                	xor    %eax,%eax
    94b5:	85 c9                	test   %ecx,%ecx
    94b7:	0f 98 c0             	sets   %al
    94ba:	e9 86 fc ff ff       	jmp    9145 <fwp_write+0x985>
    94bf:	90                   	nop
    94c0:	48 f7 d8             	neg    %rax
    94c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    94ca:	00 
    94cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    94d2:	2d 
    94d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94da:	00 
    94db:	48 83 d2 00          	adc    $0x0,%rdx
    94df:	48 89 c6             	mov    %rax,%rsi
    94e2:	48 f7 da             	neg    %rdx
    94e5:	e8 16 a5 ff ff       	call   3a00 <fwp_fmt_u128>
    94ea:	e9 51 f3 ff ff       	jmp    8840 <fwp_write+0x80>
    94ef:	90                   	nop
    94f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    94f5:	e9 c3 f5 ff ff       	jmp    8abd <fwp_write+0x2fd>
    94fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9500:	4c 89 e9             	mov    %r13,%rcx
    9503:	48 c1 e1 04          	shl    $0x4,%rcx
    9507:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    950c:	48 85 ff             	test   %rdi,%rdi
    950f:	0f 89 eb f9 ff ff    	jns    8f00 <fwp_write+0x740>
    9515:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9519:	48 89 ce             	mov    %rcx,%rsi
    951c:	e9 df f9 ff ff       	jmp    8f00 <fwp_write+0x740>
    9521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9528:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    952f:	00 
    9530:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9534:	e9 20 fa ff ff       	jmp    8f59 <fwp_write+0x799>
    9539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9540:	ba 02 00 00 00       	mov    $0x2,%edx
    9545:	48 8d 35 59 2c 00 00 	lea    0x2c59(%rip),%rsi        # c1a5 <_IO_stdin_used+0x1a5>
    954c:	e9 2d f7 ff ff       	jmp    8c7e <fwp_write+0x4be>
    9551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9558:	4c 8d 05 85 2c 00 00 	lea    0x2c85(%rip),%r8        # c1e4 <_IO_stdin_used+0x1e4>
    955f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9564:	31 c0                	xor    %eax,%eax
    9566:	ba 02 00 00 00       	mov    $0x2,%edx
    956b:	be 10 00 00 00       	mov    $0x10,%esi
    9570:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9577:	00 
    9578:	e8 13 9e ff ff       	call   3390 <__snprintf_chk@plt>
    957d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9584:	00 
    9585:	e8 a6 9e ff ff       	call   3430 <strlen@plt>
    958a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9591:	00 
    9592:	48 89 df             	mov    %rbx,%rdi
    9595:	48 89 c2             	mov    %rax,%rdx
    9598:	e8 33 ac ff ff       	call   41d0 <buf_put>
    959d:	e9 fe fd ff ff       	jmp    93a0 <fwp_write+0xbe0>
    95a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95ac:	48 8d 35 ec 2b 00 00 	lea    0x2bec(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    95b3:	48 8d 05 e4 2b 00 00 	lea    0x2be4(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    95ba:	4c 89 e7             	mov    %r12,%rdi
    95bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    95c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    95c5:	e8 06 9e ff ff       	call   33d0 <strcpy@plt>
    95ca:	e9 71 f2 ff ff       	jmp    8840 <fwp_write+0x80>
    95cf:	90                   	nop
    95d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95d4:	48 8d 35 c4 2b 00 00 	lea    0x2bc4(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    95db:	48 8d 05 bc 2b 00 00 	lea    0x2bbc(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    95e2:	0f 2f c8             	comiss %xmm0,%xmm1
    95e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95ec:	00 
    95ed:	4c 89 e7             	mov    %r12,%rdi
    95f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    95f4:	e8 d7 9d ff ff       	call   33d0 <strcpy@plt>
    95f9:	e9 42 f2 ff ff       	jmp    8840 <fwp_write+0x80>
    95fe:	66 90                	xchg   %ax,%ax
    9600:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9605:	45 85 c0             	test   %r8d,%r8d
    9608:	75 34                	jne    963e <fwp_write+0xe7e>
    960a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9611:	00 
    9612:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9619:	00 00 
    961b:	0f 85 74 f6 ff ff    	jne    8c95 <fwp_write+0x4d5>
    9621:	ba 02 00 00 00       	mov    $0x2,%edx
    9626:	48 8d 35 e8 2b 00 00 	lea    0x2be8(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    962d:	e9 a1 f3 ff ff       	jmp    89d3 <fwp_write+0x213>
    9632:	48 03 75 10          	add    0x10(%rbp),%rsi
    9636:	49 89 f0             	mov    %rsi,%r8
    9639:	e9 e5 fc ff ff       	jmp    9323 <fwp_write+0xb63>
    963e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9643:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9648:	85 ff                	test   %edi,%edi
    964a:	0f 84 fa f3 ff ff    	je     8a4a <fwp_write+0x28a>
    9650:	ba 01 00 00 00       	mov    $0x1,%edx
    9655:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    965a:	48 89 df             	mov    %rbx,%rdi
    965d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9662:	e8 69 ab ff ff       	call   41d0 <buf_put>
    9667:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    966c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9671:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9677:	85 c0                	test   %eax,%eax
    9679:	0f 8f f0 f3 ff ff    	jg     8a6f <fwp_write+0x2af>
    967f:	e9 34 f4 ff ff       	jmp    8ab8 <fwp_write+0x2f8>
    9684:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9688:	49 89 c5             	mov    %rax,%r13
    968b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9690:	49 89 c4             	mov    %rax,%r12
    9693:	49 c1 fd 3f          	sar    $0x3f,%r13
    9697:	4c 09 e8             	or     %r13,%rax
    969a:	0f 84 a7 00 00 00    	je     9747 <fwp_write+0xf87>
    96a0:	48 8d 2d 19 4c 00 00 	lea    0x4c19(%rip),%rbp        # e2c0 <units.0>
    96a7:	4d 89 e7             	mov    %r12,%r15
    96aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    96ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    96b3:	4c 89 ff             	mov    %r15,%rdi
    96b6:	4c 89 ee             	mov    %r13,%rsi
    96b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    96bd:	48 99                	cqto
    96bf:	48 89 d1             	mov    %rdx,%rcx
    96c2:	48 89 c2             	mov    %rax,%rdx
    96c5:	e8 66 23 00 00       	call   ba30 <__divmodti4>
    96ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    96ce:	48 89 c1             	mov    %rax,%rcx
    96d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    96d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    96db:	0f 84 94 00 00 00    	je     9775 <fwp_write+0xfb5>
    96e1:	41 83 c1 01          	add    $0x1,%r9d
    96e5:	48 83 c5 10          	add    $0x10,%rbp
    96e9:	41 83 f9 05          	cmp    $0x5,%r9d
    96ed:	75 bb                	jne    96aa <fwp_write+0xeea>
    96ef:	4d 85 ed             	test   %r13,%r13
    96f2:	79 53                	jns    9747 <fwp_write+0xf87>
    96f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    96f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    96fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9703:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9708:	48 99                	cqto
    970a:	48 f7 d8             	neg    %rax
    970d:	48 83 d2 00          	adc    $0x0,%rdx
    9711:	48 89 c6             	mov    %rax,%rsi
    9714:	48 f7 da             	neg    %rdx
    9717:	e8 e4 a2 ff ff       	call   3a00 <fwp_fmt_u128>
    971c:	49 89 e8             	mov    %rbp,%r8
    971f:	ba 00 02 00 00       	mov    $0x200,%edx
    9724:	be 02 00 00 00       	mov    $0x2,%esi
    9729:	31 c0                	xor    %eax,%eax
    972b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9732:	00 
    9733:	48 8d 0d d6 2a 00 00 	lea    0x2ad6(%rip),%rcx        # c210 <_IO_stdin_used+0x210>
    973a:	4c 89 e7             	mov    %r12,%rdi
    973d:	e8 5e 9f ff ff       	call   36a0 <__sprintf_chk@plt>
    9742:	e9 f9 f0 ff ff       	jmp    8840 <fwp_write+0x80>
    9747:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    974c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9751:	31 d2                	xor    %edx,%edx
    9753:	48 89 ef             	mov    %rbp,%rdi
    9756:	e8 a5 a2 ff ff       	call   3a00 <fwp_fmt_u128>
    975b:	eb bf                	jmp    971c <fwp_write+0xf5c>
    975d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9764:	4e 61 4e 00 
    9768:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    976f:	00 
    9770:	e9 cb f0 ff ff       	jmp    8840 <fwp_write+0x80>
    9775:	44 89 0c 24          	mov    %r9d,(%rsp)
    9779:	48 89 c8             	mov    %rcx,%rax
    977c:	48 85 d2             	test   %rdx,%rdx
    977f:	78 51                	js     97d2 <fwp_write+0x1012>
    9781:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9786:	48 89 c6             	mov    %rax,%rsi
    9789:	48 89 ef             	mov    %rbp,%rdi
    978c:	e8 6f a2 ff ff       	call   3a00 <fwp_fmt_u128>
    9791:	44 8b 0c 24          	mov    (%rsp),%r9d
    9795:	49 63 c1             	movslq %r9d,%rax
    9798:	49 89 e8             	mov    %rbp,%r8
    979b:	ba 00 02 00 00       	mov    $0x200,%edx
    97a0:	be 02 00 00 00       	mov    $0x2,%esi
    97a5:	48 c1 e0 04          	shl    $0x4,%rax
    97a9:	48 8d 3d 10 4b 00 00 	lea    0x4b10(%rip),%rdi        # e2c0 <units.0>
    97b0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97b7:	00 
    97b8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    97bc:	48 8d 0d 48 2a 00 00 	lea    0x2a48(%rip),%rcx        # c20b <_IO_stdin_used+0x20b>
    97c3:	4c 89 e7             	mov    %r12,%rdi
    97c6:	31 c0                	xor    %eax,%eax
    97c8:	e8 d3 9e ff ff       	call   36a0 <__sprintf_chk@plt>
    97cd:	e9 6e f0 ff ff       	jmp    8840 <fwp_write+0x80>
    97d2:	48 f7 d8             	neg    %rax
    97d5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    97da:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    97df:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97e4:	48 83 d2 00          	adc    $0x0,%rdx
    97e8:	48 89 c6             	mov    %rax,%rsi
    97eb:	48 f7 da             	neg    %rdx
    97ee:	e8 0d a2 ff ff       	call   3a00 <fwp_fmt_u128>
    97f3:	44 8b 0c 24          	mov    (%rsp),%r9d
    97f7:	eb 9c                	jmp    9795 <fwp_write+0xfd5>
    97f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009800 <fwp_main_thread>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	41 57                	push   %r15
    9806:	41 56                	push   %r14
    9808:	41 55                	push   %r13
    980a:	41 54                	push   %r12
    980c:	55                   	push   %rbp
    980d:	53                   	push   %rbx
    980e:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
    9815:	44 8b 15 48 83 01 00 	mov    0x18348(%rip),%r10d        # 21b64 <fwp_heap+0x13a4>
    981c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9823:	00 00 
    9825:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    982c:	00 
    982d:	31 c0                	xor    %eax,%eax
    982f:	45 85 d2             	test   %r10d,%r10d
    9832:	0f 84 1a 13 00 00    	je     ab52 <fwp_main_thread+0x1352>
    9838:	44 8b 0d 29 83 01 00 	mov    0x18329(%rip),%r9d        # 21b68 <fwp_heap+0x13a8>
    983f:	45 85 c9             	test   %r9d,%r9d
    9842:	0f 85 f9 12 00 00    	jne    ab41 <fwp_main_thread+0x1341>
    9848:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    984f:	00 
    9850:	31 f6                	xor    %esi,%esi
    9852:	48 c7 05 f3 68 01 00 	movq   $0x40000000,0x168f3(%rip)        # 20150 <fwp_main_stack_size>
    9859:	00 00 00 40 
    985d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    9862:	48 89 05 ef 68 01 00 	mov    %rax,0x168ef(%rip)        # 20158 <fwp_main_stack_top>
    9869:	48 8d 05 10 68 00 00 	lea    0x6810(%rip),%rax        # 10080 <alt.5>
    9870:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9877:	00 
    9878:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    987f:	00 
    9880:	48 89 c7             	mov    %rax,%rdi
    9883:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9888:	48 c7 84 24 d0 00 00 	movq   $0x10000,0xd0(%rsp)
    988f:	00 00 00 01 00 
    9894:	c7 84 24 c8 00 00 00 	movl   $0x0,0xc8(%rsp)
    989b:	00 00 00 00 
    989f:	e8 dc 9d ff ff       	call   3680 <sigaltstack@plt>
    98a4:	85 c0                	test   %eax,%eax
    98a6:	0f 85 2c 21 00 00    	jne    b9d8 <fwp_main_thread+0x21d8>
    98ac:	31 c0                	xor    %eax,%eax
    98ae:	b9 12 00 00 00       	mov    $0x12,%ecx
    98b3:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
    98ba:	00 
    98bb:	f3 48 ab             	rep stos %rax,(%rdi)
    98be:	48 8d 9c 24 20 01 00 	lea    0x120(%rsp),%rbx
    98c5:	00 
    98c6:	48 8d 05 e3 a3 ff ff 	lea    -0x5c1d(%rip),%rax        # 3cb0 <fwp_segv>
    98cd:	c7 84 24 a8 01 00 00 	movl   $0x8000004,0x1a8(%rsp)
    98d4:	04 00 00 08 
    98d8:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
    98df:	00 
    98e0:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    98e5:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    98ec:	00 
    98ed:	e8 5e 9c ff ff       	call   3550 <sigemptyset@plt>
    98f2:	85 c0                	test   %eax,%eax
    98f4:	0f 85 de 20 00 00    	jne    b9d8 <fwp_main_thread+0x21d8>
    98fa:	31 d2                	xor    %edx,%edx
    98fc:	48 89 de             	mov    %rbx,%rsi
    98ff:	bf 0b 00 00 00       	mov    $0xb,%edi
    9904:	e8 d7 9a ff ff       	call   33e0 <sigaction@plt>
    9909:	85 c0                	test   %eax,%eax
    990b:	0f 85 c7 20 00 00    	jne    b9d8 <fwp_main_thread+0x21d8>
    9911:	31 d2                	xor    %edx,%edx
    9913:	48 89 de             	mov    %rbx,%rsi
    9916:	bf 07 00 00 00       	mov    $0x7,%edi
    991b:	e8 c0 9a ff ff       	call   33e0 <sigaction@plt>
    9920:	85 c0                	test   %eax,%eax
    9922:	0f 85 b0 20 00 00    	jne    b9d8 <fwp_main_thread+0x21d8>
    9928:	44 8b 05 b9 67 01 00 	mov    0x167b9(%rip),%r8d        # 200e8 <descent_registered>
    992f:	45 85 c0             	test   %r8d,%r8d
    9932:	0f 84 08 05 00 00    	je     9e40 <fwp_main_thread+0x640>
    9938:	8b 3d 32 67 00 00    	mov    0x6732(%rip),%edi        # 10070 <st.3>
    993e:	85 ff                	test   %edi,%edi
    9940:	0f 84 26 05 00 00    	je     9e6c <fwp_main_thread+0x66c>
    9946:	48 8b 2d 53 6e 01 00 	mov    0x16e53(%rip),%rbp        # 207a0 <fwp_cur>
    994d:	48 85 ed             	test   %rbp,%rbp
    9950:	0f 84 c9 01 00 00    	je     9b1f <fwp_main_thread+0x31f>
    9956:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    995b:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    995f:	48 89 eb             	mov    %rbp,%rbx
    9962:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9967:	0f 84 41 01 00 00    	je     9aae <fwp_main_thread+0x2ae>
    996d:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9972:	0f 84 e8 03 00 00    	je     9d60 <fwp_main_thread+0x560>
    9978:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    997c:	0f 84 b6 03 00 00    	je     9d38 <fwp_main_thread+0x538>
    9982:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9986:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    998a:	0f 85 50 04 00 00    	jne    9de0 <fwp_main_thread+0x5e0>
    9990:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9994:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    999b:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    999f:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    99a6:	00 00 00 00 
    99aa:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    99b1:	48 85 d2             	test   %rdx,%rdx
    99b4:	74 07                	je     99bd <fwp_main_thread+0x1bd>
    99b6:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    99bd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    99c1:	48 85 c0             	test   %rax,%rax
    99c4:	74 34                	je     99fa <fwp_main_thread+0x1fa>
    99c6:	48 89 43 68          	mov    %rax,0x68(%rbx)
    99ca:	48 8b 05 a7 6d 01 00 	mov    0x16da7(%rip),%rax        # 20778 <fwp_timers>
    99d1:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    99d5:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    99dc:	00 00 00 00 
    99e0:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    99e7:	48 85 c0             	test   %rax,%rax
    99ea:	74 07                	je     99f3 <fwp_main_thread+0x1f3>
    99ec:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    99f3:	48 89 1d 7e 6d 01 00 	mov    %rbx,0x16d7e(%rip)        # 20778 <fwp_timers>
    99fa:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    99fe:	e8 2d de ff ff       	call   7830 <fwp_block>
    9a03:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9a0a:	48 85 c9             	test   %rcx,%rcx
    9a0d:	74 47                	je     9a56 <fwp_main_thread+0x256>
    9a0f:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9a16:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a1d:	48 85 d2             	test   %rdx,%rdx
    9a20:	0f 84 fa 03 00 00    	je     9e20 <fwp_main_thread+0x620>
    9a26:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9a2d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a34:	48 85 c0             	test   %rax,%rax
    9a37:	74 07                	je     9a40 <fwp_main_thread+0x240>
    9a39:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9a40:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9a47:	00 00 00 00 
    9a4b:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9a4f:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9a56:	48 8b 0d 43 6d 01 00 	mov    0x16d43(%rip),%rcx        # 207a0 <fwp_cur>
    9a5d:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9a61:	0f 84 69 03 00 00    	je     9dd0 <fwp_main_thread+0x5d0>
    9a67:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9a6e:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9a75:	48 85 d2             	test   %rdx,%rdx
    9a78:	0f 84 b2 03 00 00    	je     9e30 <fwp_main_thread+0x630>
    9a7e:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9a85:	48 85 c0             	test   %rax,%rax
    9a88:	74 07                	je     9a91 <fwp_main_thread+0x291>
    9a8a:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9a91:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9a95:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9a99:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9aa0:	48 89 cb             	mov    %rcx,%rbx
    9aa3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9aa8:	0f 85 bf fe ff ff    	jne    996d <fwp_main_thread+0x16d>
    9aae:	48 83 3d 82 89 01 00 	cmpq   $0x0,0x18982(%rip)        # 22438 <fwp_state_len>
    9ab5:	00 
    9ab6:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9aba:	75 0e                	jne    9aca <fwp_main_thread+0x2ca>
    9abc:	48 83 3d 64 89 01 00 	cmpq   $0x0,0x18964(%rip)        # 22428 <fwp_state_owners>
    9ac3:	00 
    9ac4:	0f 84 6c 1d 00 00    	je     b836 <fwp_main_thread+0x2036>
    9aca:	48 39 1d c7 6c 01 00 	cmp    %rbx,0x16cc7(%rip)        # 20798 <fwp_root>
    9ad1:	c7 05 a5 65 01 00 00 	movl   $0x0,0x165a5(%rip)        # 20080 <fwp_exit_code>
    9ad8:	00 00 00 
    9adb:	0f 85 38 1f 00 00    	jne    ba19 <fwp_main_thread+0x2219>
    9ae1:	48 85 db             	test   %rbx,%rbx
    9ae4:	74 5f                	je     9b45 <fwp_main_thread+0x345>
    9ae6:	48 8b 15 7b 6c 01 00 	mov    0x16c7b(%rip),%rdx        # 20768 <fwp_tasks_active>
    9aed:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9af1:	48 85 d2             	test   %rdx,%rdx
    9af4:	74 4f                	je     9b45 <fwp_main_thread+0x345>
    9af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9afd:	00 00 00 
    9b00:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9b04:	75 08                	jne    9b0e <fwp_main_thread+0x30e>
    9b06:	48 89 d7             	mov    %rdx,%rdi
    9b09:	e8 b2 a7 ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    9b0e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9b15:	48 85 d2             	test   %rdx,%rdx
    9b18:	75 e6                	jne    9b00 <fwp_main_thread+0x300>
    9b1a:	e9 e6 01 00 00       	jmp    9d05 <fwp_main_thread+0x505>
    9b1f:	48 83 3d 11 89 01 00 	cmpq   $0x0,0x18911(%rip)        # 22438 <fwp_state_len>
    9b26:	00 
    9b27:	0f 84 ea 1b 00 00    	je     b717 <fwp_main_thread+0x1f17>
    9b2d:	48 83 3d 63 6c 01 00 	cmpq   $0x0,0x16c63(%rip)        # 20798 <fwp_root>
    9b34:	00 
    9b35:	c7 05 41 65 01 00 00 	movl   $0x0,0x16541(%rip)        # 20080 <fwp_exit_code>
    9b3c:	00 00 00 
    9b3f:	0f 85 d9 1e 00 00    	jne    ba1e <fwp_main_thread+0x221e>
    9b45:	e8 d6 da ff ff       	call   7620 <fwp_free_zombie>
    9b4a:	48 83 3d 36 6c 01 00 	cmpq   $0x0,0x16c36(%rip)        # 20788 <fwp_ready_head>
    9b51:	00 
    9b52:	0f 85 b3 9b ff ff    	jne    370b <fwp_main_thread.cold>
    9b58:	48 83 3d 18 6c 01 00 	cmpq   $0x0,0x16c18(%rip)        # 20778 <fwp_timers>
    9b5f:	00 
    9b60:	0f 85 a5 9b ff ff    	jne    370b <fwp_main_thread.cold>
    9b66:	8b 05 f8 65 01 00    	mov    0x165f8(%rip),%eax        # 20164 <fwp_stack_pool_n>
    9b6c:	85 c0                	test   %eax,%eax
    9b6e:	74 3d                	je     9bad <fwp_main_thread+0x3ad>
    9b70:	83 e8 01             	sub    $0x1,%eax
    9b73:	4c 8d 25 06 66 01 00 	lea    0x16606(%rip),%r12        # 20180 <fwp_stack_pool>
    9b7a:	48 63 d8             	movslq %eax,%rbx
    9b7d:	89 c0                	mov    %eax,%eax
    9b7f:	48 89 da             	mov    %rbx,%rdx
    9b82:	48 29 c2             	sub    %rax,%rdx
    9b85:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9b89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9b90:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9b94:	89 1d ca 65 01 00    	mov    %ebx,0x165ca(%rip)        # 20164 <fwp_stack_pool_n>
    9b9a:	be 00 00 00 10       	mov    $0x10000000,%esi
    9b9f:	48 83 eb 01          	sub    $0x1,%rbx
    9ba3:	e8 08 9a ff ff       	call   35b0 <munmap@plt>
    9ba8:	48 39 eb             	cmp    %rbp,%rbx
    9bab:	75 e3                	jne    9b90 <fwp_main_thread+0x390>
    9bad:	8b 3d 69 64 00 00    	mov    0x6469(%rip),%edi        # 1001c <fwp_epfd>
    9bb3:	85 ff                	test   %edi,%edi
    9bb5:	78 05                	js     9bbc <fwp_main_thread+0x3bc>
    9bb7:	e8 f4 98 ff ff       	call   34b0 <close@plt>
    9bbc:	4c 8b 25 bd 67 01 00 	mov    0x167bd(%rip),%r12        # 20380 <fwp_nfdws>
    9bc3:	48 8b 2d be 67 01 00 	mov    0x167be(%rip),%rbp        # 20388 <fwp_fdws>
    9bca:	31 db                	xor    %ebx,%ebx
    9bcc:	c7 05 46 64 00 00 ff 	movl   $0xffffffff,0x6446(%rip)        # 1001c <fwp_epfd>
    9bd3:	ff ff ff 
    9bd6:	4d 85 e4             	test   %r12,%r12
    9bd9:	74 32                	je     9c0d <fwp_main_thread+0x40d>
    9bdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9be0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9be5:	48 85 ff             	test   %rdi,%rdi
    9be8:	74 1a                	je     9c04 <fwp_main_thread+0x404>
    9bea:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9bee:	0f 85 17 9b ff ff    	jne    370b <fwp_main_thread.cold>
    9bf4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9bf9:	0f 85 0c 9b ff ff    	jne    370b <fwp_main_thread.cold>
    9bff:	e8 4c bb ff ff       	call   5750 <fwp_mem_free>
    9c04:	48 83 c3 01          	add    $0x1,%rbx
    9c08:	4c 39 e3             	cmp    %r12,%rbx
    9c0b:	75 d3                	jne    9be0 <fwp_main_thread+0x3e0>
    9c0d:	48 89 ef             	mov    %rbp,%rdi
    9c10:	e8 3b bb ff ff       	call   5750 <fwp_mem_free>
    9c15:	48 8b 15 7c 6b 01 00 	mov    0x16b7c(%rip),%rdx        # 20798 <fwp_root>
    9c1c:	48 c7 05 61 67 01 00 	movq   $0x0,0x16761(%rip)        # 20388 <fwp_fdws>
    9c23:	00 00 00 00 
    9c27:	48 c7 05 4e 67 01 00 	movq   $0x0,0x1674e(%rip)        # 20380 <fwp_nfdws>
    9c2e:	00 00 00 00 
    9c32:	48 85 d2             	test   %rdx,%rdx
    9c35:	74 4e                	je     9c85 <fwp_main_thread+0x485>
    9c37:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9c3c:	0f 85 c9 9a ff ff    	jne    370b <fwp_main_thread.cold>
    9c42:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9c49:	00 
    9c4a:	0f 85 bb 9a ff ff    	jne    370b <fwp_main_thread.cold>
    9c50:	48 83 3d e0 87 01 00 	cmpq   $0x0,0x187e0(%rip)        # 22438 <fwp_state_len>
    9c57:	00 
    9c58:	0f 85 ad 9a ff ff    	jne    370b <fwp_main_thread.cold>
    9c5e:	48 83 3d c2 87 01 00 	cmpq   $0x0,0x187c2(%rip)        # 22428 <fwp_state_owners>
    9c65:	00 
    9c66:	0f 85 9f 9a ff ff    	jne    370b <fwp_main_thread.cold>
    9c6c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9c71:	31 c0                	xor    %eax,%eax
    9c73:	48 8d 3d 26 67 01 00 	lea    0x16726(%rip),%rdi        # 203a0 <fwp_root_context>
    9c7a:	f3 48 ab             	rep stos %rax,(%rdi)
    9c7d:	48 89 d7             	mov    %rdx,%rdi
    9c80:	e8 cb ba ff ff       	call   5750 <fwp_mem_free>
    9c85:	48 8b 3d 94 63 00 00 	mov    0x6394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9c8c:	48 c7 05 09 6b 01 00 	movq   $0x0,0x16b09(%rip)        # 207a0 <fwp_cur>
    9c93:	00 00 00 00 
    9c97:	48 c7 05 f6 6a 01 00 	movq   $0x0,0x16af6(%rip)        # 20798 <fwp_root>
    9c9e:	00 00 00 00 
    9ca2:	e8 e9 98 ff ff       	call   3590 <fflush@plt>
    9ca7:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
    9cae:	00 
    9caf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9cb6:	00 00 
    9cb8:	0f 85 26 1d 00 00    	jne    b9e4 <fwp_main_thread+0x21e4>
    9cbe:	48 81 c4 c8 01 00 00 	add    $0x1c8,%rsp
    9cc5:	31 c0                	xor    %eax,%eax
    9cc7:	5b                   	pop    %rbx
    9cc8:	5d                   	pop    %rbp
    9cc9:	41 5c                	pop    %r12
    9ccb:	41 5d                	pop    %r13
    9ccd:	41 5e                	pop    %r14
    9ccf:	41 5f                	pop    %r15
    9cd1:	c3                   	ret
    9cd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9cd8:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9cdf:	48 89 1d 9a 6a 01 00 	mov    %rbx,0x16a9a(%rip)        # 20780 <fwp_ready_tail>
    9ce6:	e8 45 db ff ff       	call   7830 <fwp_block>
    9ceb:	e8 30 d9 ff ff       	call   7620 <fwp_free_zombie>
    9cf0:	48 83 3d 70 6a 01 00 	cmpq   $0x0,0x16a70(%rip)        # 20768 <fwp_tasks_active>
    9cf7:	00 
    9cf8:	0f 84 47 fe ff ff    	je     9b45 <fwp_main_thread+0x345>
    9cfe:	48 8b 1d 93 6a 01 00 	mov    0x16a93(%rip),%rbx        # 20798 <fwp_root>
    9d05:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9d09:	75 db                	jne    9ce6 <fwp_main_thread+0x4e6>
    9d0b:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9d0f:	75 d5                	jne    9ce6 <fwp_main_thread+0x4e6>
    9d11:	48 8b 05 68 6a 01 00 	mov    0x16a68(%rip),%rax        # 20780 <fwp_ready_tail>
    9d18:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9d1c:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9d23:	00 00 00 00 
    9d27:	48 85 c0             	test   %rax,%rax
    9d2a:	75 ac                	jne    9cd8 <fwp_main_thread+0x4d8>
    9d2c:	48 89 1d 55 6a 01 00 	mov    %rbx,0x16a55(%rip)        # 20788 <fwp_ready_head>
    9d33:	eb aa                	jmp    9cdf <fwp_main_thread+0x4df>
    9d35:	0f 1f 00             	nopl   (%rax)
    9d38:	e8 e3 a7 ff ff       	call   4520 <fwp_now_ns>
    9d3d:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9d41:	7c 1d                	jl     9d60 <fwp_main_thread+0x560>
    9d43:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9d47:	75 17                	jne    9d60 <fwp_main_thread+0x560>
    9d49:	48 89 ef             	mov    %rbp,%rdi
    9d4c:	e8 6f a5 ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    9d51:	0f 1f 40 00          	nopl   0x0(%rax)
    9d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d5c:	00 00 00 00 
    9d60:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9d64:	0f 85 18 fc ff ff    	jne    9982 <fwp_main_thread+0x182>
    9d6a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9d6e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9d72:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9d76:	0f 85 18 fc ff ff    	jne    9994 <fwp_main_thread+0x194>
    9d7c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9d80:	48 85 c9             	test   %rcx,%rcx
    9d83:	0f 84 0b fc ff ff    	je     9994 <fwp_main_thread+0x194>
    9d89:	48 39 c8             	cmp    %rcx,%rax
    9d8c:	48 89 ce             	mov    %rcx,%rsi
    9d8f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9d96:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9d9a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9da1:	00 00 00 00 
    9da5:	48 0f 4e f0          	cmovle %rax,%rsi
    9da9:	48 85 c0             	test   %rax,%rax
    9dac:	48 89 c8             	mov    %rcx,%rax
    9daf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9db6:	48 0f 45 c6          	cmovne %rsi,%rax
    9dba:	48 85 d2             	test   %rdx,%rdx
    9dbd:	74 07                	je     9dc6 <fwp_main_thread+0x5c6>
    9dbf:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9dc6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9dca:	e9 f7 fb ff ff       	jmp    99c6 <fwp_main_thread+0x1c6>
    9dcf:	90                   	nop
    9dd0:	48 89 cb             	mov    %rcx,%rbx
    9dd3:	e9 8a fb ff ff       	jmp    9962 <fwp_main_thread+0x162>
    9dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9ddf:	00 
    9de0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9de4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9deb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9df2:	00 00 00 00 
    9df6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9dfd:	48 85 c0             	test   %rax,%rax
    9e00:	0f 84 fa 18 00 00    	je     b700 <fwp_main_thread+0x1f00>
    9e06:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9e0d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e11:	e9 e4 fb ff ff       	jmp    99fa <fwp_main_thread+0x1fa>
    9e16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e1d:	00 00 00 
    9e20:	48 89 01             	mov    %rax,(%rcx)
    9e23:	e9 0c fc ff ff       	jmp    9a34 <fwp_main_thread+0x234>
    9e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e2f:	00 
    9e30:	48 89 05 41 69 01 00 	mov    %rax,0x16941(%rip)        # 20778 <fwp_timers>
    9e37:	e9 49 fc ff ff       	jmp    9a85 <fwp_main_thread+0x285>
    9e3c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e40:	48 8d 3d 89 9f ff ff 	lea    -0x6077(%rip),%rdi        # 3dd0 <descent_phase_report>
    9e47:	e8 f4 1d 00 00       	call   bc40 <atexit>
    9e4c:	85 c0                	test   %eax,%eax
    9e4e:	0f 85 b4 1b 00 00    	jne    ba08 <fwp_main_thread+0x2208>
    9e54:	c7 05 8a 62 01 00 01 	movl   $0x1,0x1628a(%rip)        # 200e8 <descent_registered>
    9e5b:	00 00 00 
    9e5e:	8b 3d 0c 62 00 00    	mov    0x620c(%rip),%edi        # 10070 <st.3>
    9e64:	85 ff                	test   %edi,%edi
    9e66:	0f 85 da fa ff ff    	jne    9946 <fwp_main_thread+0x146>
    9e6c:	48 8d 05 dd df ff ff 	lea    -0x2023(%rip),%rax        # 7e50 <fwp_drop1>
    9e73:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e77:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
    9e7c:	45 31 f6             	xor    %r14d,%r14d
    9e7f:	66 48 0f 6e f0       	movq   %rax,%xmm6
    9e84:	48 8b 05 cd 85 01 00 	mov    0x185cd(%rip),%rax        # 22458 <fwp_cleanups>
    9e8b:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
    9e92:	00 00 00 00 00 
    9e97:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    9e9c:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9ea0:	48 8d 2d 19 69 01 00 	lea    0x16919(%rip),%rbp        # 207c0 <fwp_heap>
    9ea7:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9eae:	00 
    9eaf:	48 8d 05 da 9c ff ff 	lea    -0x6326(%rip),%rax        # 3b90 <fwp_range_release>
    9eb6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9ebd:	00 
    9ebe:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9ec3:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9eca:	00 
    9ecb:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9ed2:	00 
    9ed3:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    9ed8:	48 89 05 79 85 01 00 	mov    %rax,0x18579(%rip)        # 22458 <fwp_cleanups>
    9edf:	eb 47                	jmp    9f28 <fwp_main_thread+0x728>
    9ee1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ee8:	80 f9 01             	cmp    $0x1,%cl
    9eeb:	75 29                	jne    9f16 <fwp_main_thread+0x716>
    9eed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ef0:	0f b7 c0             	movzwl %ax,%eax
    9ef3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ef6:	48 0f af c1          	imul   %rcx,%rax
    9efa:	48 c1 e8 20          	shr    $0x20,%rax
    9efe:	48 39 d0             	cmp    %rdx,%rax
    9f01:	73 13                	jae    9f16 <fwp_main_thread+0x716>
    9f03:	49 01 c5             	add    %rax,%r13
    9f06:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9f0b:	0f 84 68 18 00 00    	je     b779 <fwp_main_thread+0x1f79>
    9f11:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9f16:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    9f1d:	00 
    9f1e:	48 83 eb 01          	sub    $0x1,%rbx
    9f22:	0f 82 85 00 00 00    	jb     9fad <fwp_main_thread+0x7ad>
    9f28:	4c 89 e6             	mov    %r12,%rsi
    9f2b:	bf 01 00 00 00       	mov    $0x1,%edi
    9f30:	4c 89 b4 24 28 01 00 	mov    %r14,0x128(%rsp)
    9f37:	00 
    9f38:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
    9f3f:	00 
    9f40:	48 89 9c 24 20 01 00 	mov    %rbx,0x120(%rsp)
    9f47:	00 
    9f48:	e8 23 be ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    9f4d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9f54:	49 89 c6             	mov    %rax,%r14
    9f57:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9f5e:	48 c1 e2 10          	shl    $0x10,%rdx
    9f62:	48 39 d0             	cmp    %rdx,%rax
    9f65:	73 af                	jae    9f16 <fwp_main_thread+0x716>
    9f67:	48 89 c2             	mov    %rax,%rdx
    9f6a:	48 c1 ea 10          	shr    $0x10,%rdx
    9f6e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f72:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9f79:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f7d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9f81:	4d 85 ed             	test   %r13,%r13
    9f84:	74 90                	je     9f16 <fwp_main_thread+0x716>
    9f86:	0f b6 0a             	movzbl (%rdx),%ecx
    9f89:	80 f9 02             	cmp    $0x2,%cl
    9f8c:	0f 85 56 ff ff ff    	jne    9ee8 <fwp_main_thread+0x6e8>
    9f92:	66 85 c0             	test   %ax,%ax
    9f95:	0f 84 6b ff ff ff    	je     9f06 <fwp_main_thread+0x706>
    9f9b:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    9fa2:	00 
    9fa3:	48 83 eb 01          	sub    $0x1,%rbx
    9fa7:	0f 83 7b ff ff ff    	jae    9f28 <fwp_main_thread+0x728>
    9fad:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
    9fb4:	00 
    9fb5:	66 0f 6f 05 a3 2c 00 	movdqa 0x2ca3(%rip),%xmm0        # cc60 <msg.4+0xf0>
    9fbc:	00 
    9fbd:	bf 01 00 00 00       	mov    $0x1,%edi
    9fc2:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9fc9:	00 
    9fca:	48 89 1d 87 84 01 00 	mov    %rbx,0x18487(%rip)        # 22458 <fwp_cleanups>
    9fd1:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    9fd8:	00 
    9fd9:	e8 92 bd ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    9fde:	48 8b 15 b3 7b 01 00 	mov    0x17bb3(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9fe5:	49 89 c5             	mov    %rax,%r13
    9fe8:	48 2b 05 81 7b 01 00 	sub    0x17b81(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9fef:	48 c1 e2 10          	shl    $0x10,%rdx
    9ff3:	48 39 d0             	cmp    %rdx,%rax
    9ff6:	73 59                	jae    a051 <fwp_main_thread+0x851>
    9ff8:	48 89 c2             	mov    %rax,%rdx
    9ffb:	48 c1 ea 10          	shr    $0x10,%rdx
    9fff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a003:	48 8b 15 ae 7b 01 00 	mov    0x17bae(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    a00a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a00e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a012:	4d 85 e4             	test   %r12,%r12
    a015:	74 3a                	je     a051 <fwp_main_thread+0x851>
    a017:	0f b6 0a             	movzbl (%rdx),%ecx
    a01a:	80 f9 02             	cmp    $0x2,%cl
    a01d:	0f 84 2c 17 00 00    	je     b74f <fwp_main_thread+0x1f4f>
    a023:	80 f9 01             	cmp    $0x1,%cl
    a026:	75 29                	jne    a051 <fwp_main_thread+0x851>
    a028:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a02b:	0f b7 c0             	movzwl %ax,%eax
    a02e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a031:	48 0f af c1          	imul   %rcx,%rax
    a035:	48 c1 e8 20          	shr    $0x20,%rax
    a039:	48 39 d0             	cmp    %rdx,%rax
    a03c:	73 13                	jae    a051 <fwp_main_thread+0x851>
    a03e:	49 01 c4             	add    %rax,%r12
    a041:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a046:	0f 84 24 19 00 00    	je     b970 <fwp_main_thread+0x2170>
    a04c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a051:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a058:	00 f0 3f 
    a05b:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a062:	00 
    a063:	bf 01 00 00 00       	mov    $0x1,%edi
    a068:	4c 89 ac 24 08 01 00 	mov    %r13,0x108(%rsp)
    a06f:	00 
    a070:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
    a077:	00 
    a078:	e8 f3 bc ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    a07d:	48 8b 15 14 7b 01 00 	mov    0x17b14(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    a084:	49 89 c5             	mov    %rax,%r13
    a087:	48 2b 05 e2 7a 01 00 	sub    0x17ae2(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    a08e:	48 c1 e2 10          	shl    $0x10,%rdx
    a092:	48 39 d0             	cmp    %rdx,%rax
    a095:	73 59                	jae    a0f0 <fwp_main_thread+0x8f0>
    a097:	48 89 c2             	mov    %rax,%rdx
    a09a:	48 c1 ea 10          	shr    $0x10,%rdx
    a09e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0a2:	48 8b 15 0f 7b 01 00 	mov    0x17b0f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    a0a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0ad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a0b1:	4d 85 e4             	test   %r12,%r12
    a0b4:	74 3a                	je     a0f0 <fwp_main_thread+0x8f0>
    a0b6:	0f b6 0a             	movzbl (%rdx),%ecx
    a0b9:	80 f9 02             	cmp    $0x2,%cl
    a0bc:	0f 84 a9 16 00 00    	je     b76b <fwp_main_thread+0x1f6b>
    a0c2:	80 f9 01             	cmp    $0x1,%cl
    a0c5:	75 29                	jne    a0f0 <fwp_main_thread+0x8f0>
    a0c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0ca:	0f b7 c0             	movzwl %ax,%eax
    a0cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0d0:	48 0f af c1          	imul   %rcx,%rax
    a0d4:	48 c1 e8 20          	shr    $0x20,%rax
    a0d8:	48 39 d0             	cmp    %rdx,%rax
    a0db:	73 13                	jae    a0f0 <fwp_main_thread+0x8f0>
    a0dd:	49 01 c4             	add    %rax,%r12
    a0e0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a0e5:	0f 84 92 18 00 00    	je     b97d <fwp_main_thread+0x217d>
    a0eb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a0f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a0f7:	33 f3 bf 
    a0fa:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    a101:	00 
    a102:	bf 01 00 00 00       	mov    $0x1,%edi
    a107:	4c 89 ac 24 f8 00 00 	mov    %r13,0xf8(%rsp)
    a10e:	00 
    a10f:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
    a116:	00 
    a117:	e8 54 bc ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    a11c:	48 8b 15 75 7a 01 00 	mov    0x17a75(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    a123:	48 8b 0d 46 7a 01 00 	mov    0x17a46(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    a12a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a12f:	48 89 d6             	mov    %rdx,%rsi
    a132:	48 29 c8             	sub    %rcx,%rax
    a135:	48 c1 e6 10          	shl    $0x10,%rsi
    a139:	48 39 f0             	cmp    %rsi,%rax
    a13c:	73 69                	jae    a1a7 <fwp_main_thread+0x9a7>
    a13e:	48 89 c6             	mov    %rax,%rsi
    a141:	48 c1 ee 10          	shr    $0x10,%rsi
    a145:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a149:	48 8b 35 68 7a 01 00 	mov    0x17a68(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    a150:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a154:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    a158:	4d 85 e4             	test   %r12,%r12
    a15b:	74 4a                	je     a1a7 <fwp_main_thread+0x9a7>
    a15d:	0f b6 3e             	movzbl (%rsi),%edi
    a160:	40 80 ff 02          	cmp    $0x2,%dil
    a164:	0f 84 f3 15 00 00    	je     b75d <fwp_main_thread+0x1f5d>
    a16a:	40 80 ff 01          	cmp    $0x1,%dil
    a16e:	75 37                	jne    a1a7 <fwp_main_thread+0x9a7>
    a170:	8b 7e 18             	mov    0x18(%rsi),%edi
    a173:	0f b7 c0             	movzwl %ax,%eax
    a176:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a179:	48 0f af c7          	imul   %rdi,%rax
    a17d:	48 c1 e8 20          	shr    $0x20,%rax
    a181:	48 39 f0             	cmp    %rsi,%rax
    a184:	73 21                	jae    a1a7 <fwp_main_thread+0x9a7>
    a186:	49 01 c4             	add    %rax,%r12
    a189:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a18e:	0f 84 f6 17 00 00    	je     b98a <fwp_main_thread+0x218a>
    a194:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a199:	48 8b 0d d0 79 01 00 	mov    0x179d0(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    a1a0:	48 8b 15 f1 79 01 00 	mov    0x179f1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    a1a7:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    a1ac:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
    a1b1:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a1b6:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    a1bd:	00 
    a1be:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    a1c3:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    a1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1cf:	00 
    a1d0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a1d5:	48 c1 e2 10          	shl    $0x10,%rdx
    a1d9:	48 29 c8             	sub    %rcx,%rax
    a1dc:	48 39 d0             	cmp    %rdx,%rax
    a1df:	73 73                	jae    a254 <fwp_main_thread+0xa54>
    a1e1:	48 89 c6             	mov    %rax,%rsi
    a1e4:	48 c1 ee 10          	shr    $0x10,%rsi
    a1e8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a1ec:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a1f3:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a1f7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a1fb:	48 85 ff             	test   %rdi,%rdi
    a1fe:	74 54                	je     a254 <fwp_main_thread+0xa54>
    a200:	44 0f b6 06          	movzbl (%rsi),%r8d
    a204:	41 80 f8 02          	cmp    $0x2,%r8b
    a208:	0f 84 6a 14 00 00    	je     b678 <fwp_main_thread+0x1e78>
    a20e:	41 80 f8 01          	cmp    $0x1,%r8b
    a212:	75 40                	jne    a254 <fwp_main_thread+0xa54>
    a214:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a218:	0f b7 c0             	movzwl %ax,%eax
    a21b:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a21e:	49 0f af c0          	imul   %r8,%rax
    a222:	48 c1 e8 20          	shr    $0x20,%rax
    a226:	48 39 f0             	cmp    %rsi,%rax
    a229:	73 29                	jae    a254 <fwp_main_thread+0xa54>
    a22b:	48 01 c7             	add    %rax,%rdi
    a22e:	0f b6 07             	movzbl (%rdi),%eax
    a231:	84 c0                	test   %al,%al
    a233:	74 1f                	je     a254 <fwp_main_thread+0xa54>
    a235:	3c fd                	cmp    $0xfd,%al
    a237:	0f 87 e1 16 00 00    	ja     b91e <fwp_main_thread+0x211e>
    a23d:	83 c0 01             	add    $0x1,%eax
    a240:	88 07                	mov    %al,(%rdi)
    a242:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a249:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    a250:	48 c1 e2 10          	shl    $0x10,%rdx
    a254:	48 8d 05 e5 ce ff ff 	lea    -0x311b(%rip),%rax        # 7140 <fwp_tape_scope_release>
    a25b:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    a262:	ff 
    a263:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    a26a:	00 
    a26b:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a270:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
    a277:	00 
    a278:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    a27f:	00 
    a280:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a285:	48 89 05 cc 81 01 00 	mov    %rax,0x181cc(%rip)        # 22458 <fwp_cleanups>
    a28c:	48 8d 05 7d 5d 00 00 	lea    0x5d7d(%rip),%rax        # 10010 <fc37>
    a293:	48 29 c8             	sub    %rcx,%rax
    a296:	48 39 d0             	cmp    %rdx,%rax
    a299:	73 5d                	jae    a2f8 <fwp_main_thread+0xaf8>
    a29b:	48 89 c2             	mov    %rax,%rdx
    a29e:	48 c1 ea 10          	shr    $0x10,%rdx
    a2a2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2a6:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a2ad:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2b1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a2b5:	48 85 ff             	test   %rdi,%rdi
    a2b8:	74 3e                	je     a2f8 <fwp_main_thread+0xaf8>
    a2ba:	0f b6 0a             	movzbl (%rdx),%ecx
    a2bd:	80 f9 02             	cmp    $0x2,%cl
    a2c0:	0f 84 2a 12 00 00    	je     b4f0 <fwp_main_thread+0x1cf0>
    a2c6:	80 f9 01             	cmp    $0x1,%cl
    a2c9:	75 2d                	jne    a2f8 <fwp_main_thread+0xaf8>
    a2cb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2ce:	0f b7 c0             	movzwl %ax,%eax
    a2d1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2d4:	48 0f af c1          	imul   %rcx,%rax
    a2d8:	48 c1 e8 20          	shr    $0x20,%rax
    a2dc:	48 39 d0             	cmp    %rdx,%rax
    a2df:	73 17                	jae    a2f8 <fwp_main_thread+0xaf8>
    a2e1:	48 01 c7             	add    %rax,%rdi
    a2e4:	0f b6 07             	movzbl (%rdi),%eax
    a2e7:	84 c0                	test   %al,%al
    a2e9:	74 0d                	je     a2f8 <fwp_main_thread+0xaf8>
    a2eb:	3c fd                	cmp    $0xfd,%al
    a2ed:	0f 87 09 15 00 00    	ja     b7fc <fwp_main_thread+0x1ffc>
    a2f3:	83 c0 01             	add    $0x1,%eax
    a2f6:	88 07                	mov    %al,(%rdi)
    a2f8:	48 8d 3d 11 5d 00 00 	lea    0x5d11(%rip),%rdi        # 10010 <fc37>
    a2ff:	45 31 ed             	xor    %r13d,%r13d
    a302:	e8 f9 ca ff ff       	call   6e00 <fwp_closure_drop>
    a307:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    a30c:	0f 1f 40 00          	nopl   0x0(%rax)
    a310:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    a315:	49 83 c5 01          	add    $0x1,%r13
    a319:	4d 85 e4             	test   %r12,%r12
    a31c:	75 f2                	jne    a310 <fwp_main_thread+0xb10>
    a31e:	31 ff                	xor    %edi,%edi
    a320:	e8 eb 9e ff ff       	call   4210 <descent_phase_step>
    a325:	49 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%r13
    a32c:	0f 87 82 16 00 00    	ja     b9b4 <fwp_main_thread+0x21b4>
    a332:	8b 35 28 5d 00 00    	mov    0x5d28(%rip),%esi        # 10060 <registered_finish.1>
    a338:	85 f6                	test   %esi,%esi
    a33a:	0f 84 80 11 00 00    	je     b4c0 <fwp_main_thread+0x1cc0>
    a340:	48 8b 15 81 5d 01 00 	mov    0x15d81(%rip),%rdx        # 200c8 <fwp_tape_next_slot>
    a347:	4c 8b 35 8a 5d 01 00 	mov    0x15d8a(%rip),%r14        # 200d8 <fwp_ntapes>
    a34e:	4c 39 f2             	cmp    %r14,%rdx
    a351:	0f 8d e9 0f 00 00    	jge    b340 <fwp_main_thread+0x1b40>
    a357:	48 6b c2 58          	imul   $0x58,%rdx,%rax
    a35b:	48 03 05 7e 5d 01 00 	add    0x15d7e(%rip),%rax        # 200e0 <fwp_tapes>
    a362:	0f 1f 00             	nopl   (%rax)
    a365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a36c:	00 00 00 00 
    a370:	8b 48 04             	mov    0x4(%rax),%ecx
    a373:	85 c9                	test   %ecx,%ecx
    a375:	75 0c                	jne    a383 <fwp_main_thread+0xb83>
    a377:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a37d:	0f 86 bd 0f 00 00    	jbe    b340 <fwp_main_thread+0x1b40>
    a383:	48 83 c2 01          	add    $0x1,%rdx
    a387:	48 83 c0 58          	add    $0x58,%rax
    a38b:	4c 39 f2             	cmp    %r14,%rdx
    a38e:	75 e0                	jne    a370 <fwp_main_thread+0xb70>
    a390:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    a397:	0f 8f 2f 16 00 00    	jg     b9cc <fwp_main_thread+0x21cc>
    a39d:	4c 39 35 2c 5d 01 00 	cmp    %r14,0x15d2c(%rip)        # 200d0 <fwp_tapes_cap>
    a3a4:	4c 8b 3d 35 5d 01 00 	mov    0x15d35(%rip),%r15        # 200e0 <fwp_tapes>
    a3ab:	75 3f                	jne    a3ec <fwp_main_thread+0xbec>
    a3ad:	4d 85 f6             	test   %r14,%r14
    a3b0:	0f 84 2a 13 00 00    	je     b6e0 <fwp_main_thread+0x1ee0>
    a3b6:	4b 8d 1c 36          	lea    (%r14,%r14,1),%rbx
    a3ba:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a3bf:	48 39 c3             	cmp    %rax,%rbx
    a3c2:	48 0f 4f d8          	cmovg  %rax,%rbx
    a3c6:	48 6b f3 58          	imul   $0x58,%rbx,%rsi
    a3ca:	4c 89 ff             	mov    %r15,%rdi
    a3cd:	e8 ce 91 ff ff       	call   35a0 <realloc@plt>
    a3d2:	49 89 c7             	mov    %rax,%r15
    a3d5:	48 85 c0             	test   %rax,%rax
    a3d8:	0f 84 55 11 00 00    	je     b533 <fwp_main_thread+0x1d33>
    a3de:	48 89 05 fb 5c 01 00 	mov    %rax,0x15cfb(%rip)        # 200e0 <fwp_tapes>
    a3e5:	48 89 1d e4 5c 01 00 	mov    %rbx,0x15ce4(%rip)        # 200d0 <fwp_tapes_cap>
    a3ec:	49 6b c6 58          	imul   $0x58,%r14,%rax
    a3f0:	49 8d 5e 01          	lea    0x1(%r14),%rbx
    a3f4:	4c 01 f8             	add    %r15,%rax
    a3f7:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a3fb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a402:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a406:	48 c7 40 50 00 00 00 	movq   $0x0,0x50(%rax)
    a40d:	00 
    a40e:	48 29 f8             	sub    %rdi,%rax
    a411:	8d 48 58             	lea    0x58(%rax),%ecx
    a414:	31 c0                	xor    %eax,%eax
    a416:	c1 e9 03             	shr    $0x3,%ecx
    a419:	f3 48 ab             	rep stos %rax,(%rdi)
    a41c:	48 89 1d b5 5c 01 00 	mov    %rbx,0x15cb5(%rip)        # 200d8 <fwp_ntapes>
    a423:	49 6b d6 58          	imul   $0x58,%r14,%rdx
    a427:	66 49 0f 6e c5       	movq   %r13,%xmm0
    a42c:	48 8d 3d ef 1c 00 00 	lea    0x1cef(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    a433:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a437:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    a43c:	4c 01 fa             	add    %r15,%rdx
    a43f:	48 c7 42 50 00 00 00 	movq   $0x0,0x50(%rdx)
    a446:	00 
    a447:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a44c:	e8 2f 8f ff ff       	call   3380 <getenv@plt>
    a451:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a456:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    a45c:	48 85 c0             	test   %rax,%rax
    a45f:	0f 84 73 0d 00 00    	je     b1d8 <fwp_main_thread+0x19d8>
    a465:	80 38 30             	cmpb   $0x30,(%rax)
    a468:	0f 85 6a 0d 00 00    	jne    b1d8 <fwp_main_thread+0x19d8>
    a46e:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a472:	0f 85 60 0d 00 00    	jne    b1d8 <fwp_main_thread+0x19d8>
    a478:	8b 02                	mov    (%rdx),%eax
    a47a:	c7 42 04 01 00 00 00 	movl   $0x1,0x4(%rdx)
    a481:	48 89 1d 40 5c 01 00 	mov    %rbx,0x15c40(%rip)        # 200c8 <fwp_tape_next_slot>
    a488:	44 8d 68 01          	lea    0x1(%rax),%r13d
    a48c:	48 8b 05 fd 26 00 00 	mov    0x26fd(%rip),%rax        # cb90 <msg.4+0x20>
    a493:	48 c7 42 40 00 00 00 	movq   $0x0,0x40(%rdx)
    a49a:	00 
    a49b:	44 89 2a             	mov    %r13d,(%rdx)
    a49e:	48 89 42 48          	mov    %rax,0x48(%rdx)
    a4a2:	48 8b 05 af 7f 01 00 	mov    0x17faf(%rip),%rax        # 22458 <fwp_cleanups>
    a4a9:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    a4ad:	48 85 c0             	test   %rax,%rax
    a4b0:	75 1a                	jne    a4cc <fwp_main_thread+0xccc>
    a4b2:	e9 39 15 00 00       	jmp    b9f0 <fwp_main_thread+0x21f0>
    a4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4be:	00 00 
    a4c0:	48 8b 00             	mov    (%rax),%rax
    a4c3:	48 85 c0             	test   %rax,%rax
    a4c6:	0f 84 24 15 00 00    	je     b9f0 <fwp_main_thread+0x21f0>
    a4cc:	48 8d 3d 6d cc ff ff 	lea    -0x3393(%rip),%rdi        # 7140 <fwp_tape_scope_release>
    a4d3:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a4d7:	75 e7                	jne    a4c0 <fwp_main_thread+0xcc0>
    a4d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a4dd:	44 89 f1             	mov    %r14d,%ecx
    a4e0:	48 63 06             	movslq (%rsi),%rax
    a4e3:	48 89 72 40          	mov    %rsi,0x40(%rdx)
    a4e7:	89 42 4c             	mov    %eax,0x4c(%rdx)
    a4ea:	85 c0                	test   %eax,%eax
    a4ec:	78 09                	js     a4f7 <fwp_main_thread+0xcf7>
    a4ee:	48 6b c0 58          	imul   $0x58,%rax,%rax
    a4f2:	45 89 74 07 48       	mov    %r14d,0x48(%r15,%rax,1)
    a4f7:	89 0e                	mov    %ecx,(%rsi)
    a4f9:	bf 01 00 00 00       	mov    $0x1,%edi
    a4fe:	e8 0d 9d ff ff       	call   4210 <descent_phase_step>
    a503:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a50f:	00 
    a510:	48 8b 40 10          	mov    0x10(%rax),%rax
    a514:	49 83 c4 01          	add    $0x1,%r12
    a518:	48 85 c0             	test   %rax,%rax
    a51b:	75 f3                	jne    a510 <fwp_main_thread+0xd10>
    a51d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    a522:	0f 1f 00             	nopl   (%rax)
    a525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a52c:	00 00 00 00 
    a530:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    a534:	48 83 c0 01          	add    $0x1,%rax
    a538:	4d 85 ff             	test   %r15,%r15
    a53b:	75 f3                	jne    a530 <fwp_main_thread+0xd30>
    a53d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    a544:	ff ff 1f 
    a547:	48 39 c2             	cmp    %rax,%rdx
    a54a:	0f 82 70 14 00 00    	jb     b9c0 <fwp_main_thread+0x21c0>
    a550:	4d 85 e4             	test   %r12,%r12
    a553:	0f 8e 07 0e 00 00    	jle    b360 <fwp_main_thread+0x1b60>
    a559:	49 39 c4             	cmp    %rax,%r12
    a55c:	4c 0f 47 e0          	cmova  %rax,%r12
    a560:	4c 89 e0             	mov    %r12,%rax
    a563:	48 c1 e8 3c          	shr    $0x3c,%rax
    a567:	0f 85 53 14 00 00    	jne    b9c0 <fwp_main_thread+0x21c0>
    a56d:	4b 8d 14 24          	lea    (%r12,%r12,1),%rdx
    a571:	be 02 00 00 00       	mov    $0x2,%esi
    a576:	49 c1 e5 10          	shl    $0x10,%r13
    a57a:	48 8d 3c d5 08 00 00 	lea    0x8(,%rdx,8),%rdi
    a581:	00 
    a582:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a587:	4c 09 eb             	or     %r13,%rbx
    a58a:	e8 c1 b6 ff ff       	call   5c50 <fwp_heap_alloc>
    a58f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a594:	49 89 c6             	mov    %rax,%r14
    a597:	48 89 10             	mov    %rdx,(%rax)
    a59a:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5a1:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a5a8:	48 c1 e2 10          	shl    $0x10,%rdx
    a5ac:	48 39 d0             	cmp    %rdx,%rax
    a5af:	0f 83 6b 0d 00 00    	jae    b320 <fwp_main_thread+0x1b20>
    a5b5:	48 89 c2             	mov    %rax,%rdx
    a5b8:	48 c1 ea 10          	shr    $0x10,%rdx
    a5bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5c0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a5c7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a5cb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a5cf:	4d 85 ed             	test   %r13,%r13
    a5d2:	74 3a                	je     a60e <fwp_main_thread+0xe0e>
    a5d4:	0f b6 0a             	movzbl (%rdx),%ecx
    a5d7:	80 f9 02             	cmp    $0x2,%cl
    a5da:	0f 84 e9 0d 00 00    	je     b3c9 <fwp_main_thread+0x1bc9>
    a5e0:	80 f9 01             	cmp    $0x1,%cl
    a5e3:	75 29                	jne    a60e <fwp_main_thread+0xe0e>
    a5e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5e8:	0f b7 c0             	movzwl %ax,%eax
    a5eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5ee:	48 0f af c1          	imul   %rcx,%rax
    a5f2:	48 c1 e8 20          	shr    $0x20,%rax
    a5f6:	48 39 d0             	cmp    %rdx,%rax
    a5f9:	73 13                	jae    a60e <fwp_main_thread+0xe0e>
    a5fb:	49 01 c5             	add    %rax,%r13
    a5fe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a603:	0f 84 d4 0d 00 00    	je     b3dd <fwp_main_thread+0x1bdd>
    a609:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a60e:	4d 85 e4             	test   %r12,%r12
    a611:	74 61                	je     a674 <fwp_main_thread+0xe74>
    a613:	48 89 d9             	mov    %rbx,%rcx
    a616:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a61b:	31 c0                	xor    %eax,%eax
    a61d:	48 c1 e1 20          	shl    $0x20,%rcx
    a621:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a628:	00 00 
    a62a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a631:	00 00 00 00 
    a635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a63c:	00 00 00 00 
    a640:	48 89 c6             	mov    %rax,%rsi
    a643:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a648:	48 01 ce             	add    %rcx,%rsi
    a64b:	0f 80 52 13 00 00    	jo     b9a3 <fwp_main_thread+0x21a3>
    a651:	66 48 0f 6e de       	movq   %rsi,%xmm3
    a656:	48 89 c6             	mov    %rax,%rsi
    a659:	48 83 c0 01          	add    $0x1,%rax
    a65d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a661:	48 c1 e6 04          	shl    $0x4,%rsi
    a665:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a66b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a66f:	4c 39 e0             	cmp    %r12,%rax
    a672:	72 cc                	jb     a640 <fwp_main_thread+0xe40>
    a674:	49 8b 06             	mov    (%r14),%rax
    a677:	48 d1 e8             	shr    $1,%rax
    a67a:	0f 84 b0 0c 00 00    	je     b330 <fwp_main_thread+0x1b30>
    a680:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a684:	48 89 cf             	mov    %rcx,%rdi
    a687:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a68b:	0f 85 2f 13 00 00    	jne    b9c0 <fwp_main_thread+0x21c0>
    a691:	48 c7 84 24 c0 00 00 	movq   $0xffffffffffffffff,0xc0(%rsp)
    a698:	00 ff ff ff ff 
    a69d:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a6a1:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
    a6a8:	00 00 00 00 00 
    a6ad:	48 85 c9             	test   %rcx,%rcx
    a6b0:	74 56                	je     a708 <fwp_main_thread+0xf08>
    a6b2:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a6b7:	48 c1 e0 04          	shl    $0x4,%rax
    a6bb:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
    a6c0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a6c5:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a6ca:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a6ce:	66 90                	xchg   %ax,%ax
    a6d0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a6d4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a6d8:	4c 89 ea             	mov    %r13,%rdx
    a6db:	48 83 c3 10          	add    $0x10,%rbx
    a6df:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a6e3:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a6e7:	e8 84 bb ff ff       	call   6270 <w120>
    a6ec:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a6f1:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a6f5:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a6f9:	49 39 dc             	cmp    %rbx,%r12
    a6fc:	75 d2                	jne    a6d0 <fwp_main_thread+0xed0>
    a6fe:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a703:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a708:	49 89 16             	mov    %rdx,(%r14)
    a70b:	4c 89 f7             	mov    %r14,%rdi
    a70e:	4c 63 eb             	movslq %ebx,%r13
    a711:	e8 aa c2 ff ff       	call   69c0 <w176.constprop.0>
    a716:	4c 89 f7             	mov    %r14,%rdi
    a719:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a71e:	e8 2d d9 ff ff       	call   8050 <fwp_drop10>
    a723:	bf 02 00 00 00       	mov    $0x2,%edi
    a728:	e8 e3 9a ff ff       	call   4210 <descent_phase_step>
    a72d:	4c 89 ef             	mov    %r13,%rdi
    a730:	e8 5b 9f ff ff       	call   4690 <fwp_tape_of>
    a735:	48 89 c6             	mov    %rax,%rsi
    a738:	48 8b 40 50          	mov    0x50(%rax),%rax
    a73c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a741:	48 85 c0             	test   %rax,%rax
    a744:	0f 85 b2 12 00 00    	jne    b9fc <fwp_main_thread+0x21fc>
    a74a:	48 89 f7             	mov    %rsi,%rdi
    a74d:	e8 6e 94 ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    a752:	4c 8b 76 38          	mov    0x38(%rsi),%r14
    a756:	4c 8b 66 08          	mov    0x8(%rsi),%r12
    a75a:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a761:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    a766:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a76b:	66 49 0f 6e fe       	movq   %r14,%xmm7
    a770:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a774:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    a778:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    a77d:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a781:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a787:	77 18                	ja     a7a1 <fwp_main_thread+0xfa1>
    a789:	0f b7 c3             	movzwl %bx,%eax
    a78c:	83 e8 01             	sub    $0x1,%eax
    a78f:	48 98                	cltq
    a791:	48 3b 05 30 59 01 00 	cmp    0x15930(%rip),%rax        # 200c8 <fwp_tape_next_slot>
    a798:	7d 07                	jge    a7a1 <fwp_main_thread+0xfa1>
    a79a:	48 89 05 27 59 01 00 	mov    %rax,0x15927(%rip)        # 200c8 <fwp_tape_next_slot>
    a7a1:	48 8b 05 b0 7c 01 00 	mov    0x17cb0(%rip),%rax        # 22458 <fwp_cleanups>
    a7a8:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a7ac:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    a7b3:	00 
    a7b4:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a7b8:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    a7be:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a7c3:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    a7ca:	00 
    a7cb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a7d2:	00 
    a7d3:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a7d7:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a7de:	00 
    a7df:	48 8d 05 4a a8 ff ff 	lea    -0x57b6(%rip),%rax        # 5030 <fwp_tape_buffers_release>
    a7e6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    a7ed:	00 
    a7ee:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    a7f3:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    a7fa:	00 
    a7fb:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a802:	00 
    a803:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    a808:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    a80f:	00 
    a810:	48 89 05 41 7c 01 00 	mov    %rax,0x17c41(%rip)        # 22458 <fwp_cleanups>
    a817:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    a81e:	00 
    a81f:	48 85 ff             	test   %rdi,%rdi
    a822:	0f 88 d8 0c 00 00    	js     b500 <fwp_main_thread+0x1d00>
    a828:	48 89 f8             	mov    %rdi,%rax
    a82b:	48 c1 f8 20          	sar    $0x20,%rax
    a82f:	49 39 c5             	cmp    %rax,%r13
    a832:	0f 85 0e 11 00 00    	jne    b946 <fwp_main_thread+0x2146>
    a838:	41 89 f9             	mov    %edi,%r9d
    a83b:	4d 89 cd             	mov    %r9,%r13
    a83e:	4c 39 ca             	cmp    %r9,%rdx
    a841:	0f 8e f3 10 00 00    	jle    b93a <fwp_main_thread+0x213a>
    a847:	4d 39 cc             	cmp    %r9,%r12
    a84a:	0f 8e a0 0b 00 00    	jle    b3f0 <fwp_main_thread+0x1bf0>
    a850:	4d 39 f4             	cmp    %r14,%r12
    a853:	0f 8f d7 0b 00 00    	jg     b430 <fwp_main_thread+0x1c30>
    a859:	48 85 c9             	test   %rcx,%rcx
    a85c:	0f 84 b8 0c 00 00    	je     b51a <fwp_main_thread+0x1d1a>
    a862:	48 89 cf             	mov    %rcx,%rdi
    a865:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a86c:	00 
    a86d:	31 f6                	xor    %esi,%esi
    a86f:	45 31 f6             	xor    %r14d,%r14d
    a872:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    a877:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    a87c:	e8 1f 8c ff ff       	call   34a0 <memset@plt>
    a881:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    a886:	48 89 c1             	mov    %rax,%rcx
    a889:	f2 0f 10 05 8f 23 00 	movsd  0x238f(%rip),%xmm0        # cc20 <msg.4+0xb0>
    a890:	00 
    a891:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    a897:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    a89d:	bf 03 00 00 00       	mov    $0x3,%edi
    a8a2:	4c 01 25 47 58 01 00 	add    %r12,0x15847(%rip)        # 200f0 <descent_inputs>
    a8a9:	4c 01 35 48 58 01 00 	add    %r14,0x15848(%rip)        # 200f8 <descent_nodes>
    a8b0:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    a8b5:	e8 56 99 ff ff       	call   4210 <descent_phase_step>
    a8ba:	4d 39 ec             	cmp    %r13,%r12
    a8bd:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a8c2:	7f 66                	jg     a92a <fwp_main_thread+0x112a>
    a8c4:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a8c9:	4a 8d 14 e9          	lea    (%rcx,%r13,8),%rdx
    a8cd:	4d 29 e5             	sub    %r12,%r13
    a8d0:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a8d4:	4b 8d 44 6d 00       	lea    0x0(%r13,%r13,2),%rax
    a8d9:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    a8dd:	eb 05                	jmp    a8e4 <fwp_main_thread+0x10e4>
    a8df:	90                   	nop
    a8e0:	48 83 e8 18          	sub    $0x18,%rax
    a8e4:	f2 0f 10 02          	movsd  (%rdx),%xmm0
    a8e8:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a8ec:	7a 02                	jp     a8f0 <fwp_main_thread+0x10f0>
    a8ee:	74 31                	je     a921 <fwp_main_thread+0x1121>
    a8f0:	48 63 38             	movslq (%rax),%rdi
    a8f3:	85 ff                	test   %edi,%edi
    a8f5:	78 13                	js     a90a <fwp_main_thread+0x110a>
    a8f7:	f2 0f 10 48 08       	movsd  0x8(%rax),%xmm1
    a8fc:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a900:	f2 0f 58 0c f9       	addsd  (%rcx,%rdi,8),%xmm1
    a905:	f2 0f 11 0c f9       	movsd  %xmm1,(%rcx,%rdi,8)
    a90a:	48 63 78 04          	movslq 0x4(%rax),%rdi
    a90e:	85 ff                	test   %edi,%edi
    a910:	78 0f                	js     a921 <fwp_main_thread+0x1121>
    a912:	f2 0f 59 40 10       	mulsd  0x10(%rax),%xmm0
    a917:	f2 0f 58 04 f9       	addsd  (%rcx,%rdi,8),%xmm0
    a91c:	f2 0f 11 04 f9       	movsd  %xmm0,(%rcx,%rdi,8)
    a921:	48 83 ea 08          	sub    $0x8,%rdx
    a925:	48 39 f0             	cmp    %rsi,%rax
    a928:	75 b6                	jne    a8e0 <fwp_main_thread+0x10e0>
    a92a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a931:	ff ff 1f 
    a934:	4c 39 e0             	cmp    %r12,%rax
    a937:	0f 82 6b 10 00 00    	jb     b9a8 <fwp_main_thread+0x21a8>
    a93d:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    a944:	00 
    a945:	be 02 00 00 00       	mov    $0x2,%esi
    a94a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a94f:	e8 fc b2 ff ff       	call   5c50 <fwp_heap_alloc>
    a954:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a959:	4c 89 20             	mov    %r12,(%rax)
    a95c:	48 89 c3             	mov    %rax,%rbx
    a95f:	31 c0                	xor    %eax,%eax
    a961:	4d 85 e4             	test   %r12,%r12
    a964:	74 2c                	je     a992 <fwp_main_thread+0x1192>
    a966:	0f 1f 40 00          	nopl   0x0(%rax)
    a96a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a971:	00 00 00 00 
    a975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a97c:	00 00 00 00 
    a980:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    a984:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a989:	48 83 c0 01          	add    $0x1,%rax
    a98d:	49 39 c4             	cmp    %rax,%r12
    a990:	75 ee                	jne    a980 <fwp_main_thread+0x1180>
    a992:	bf 05 00 00 00       	mov    $0x5,%edi
    a997:	e8 74 98 ff ff       	call   4210 <descent_phase_step>
    a99c:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    a9a3:	00 
    a9a4:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a9a9:	4c 89 25 a8 7a 01 00 	mov    %r12,0x17aa8(%rip)        # 22458 <fwp_cleanups>
    a9b0:	e8 7b a6 ff ff       	call   5030 <fwp_tape_buffers_release>
    a9b5:	bf 06 00 00 00       	mov    $0x6,%edi
    a9ba:	e8 51 98 ff ff       	call   4210 <descent_phase_step>
    a9bf:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a9c6:	48 89 d8             	mov    %rbx,%rax
    a9c9:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a9d0:	48 c1 e2 10          	shl    $0x10,%rdx
    a9d4:	48 39 d0             	cmp    %rdx,%rax
    a9d7:	73 59                	jae    aa32 <fwp_main_thread+0x1232>
    a9d9:	48 89 c2             	mov    %rax,%rdx
    a9dc:	48 c1 ea 10          	shr    $0x10,%rdx
    a9e0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a9e4:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a9eb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9ef:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a9f3:	4d 85 ed             	test   %r13,%r13
    a9f6:	74 3a                	je     aa32 <fwp_main_thread+0x1232>
    a9f8:	0f b6 0a             	movzbl (%rdx),%ecx
    a9fb:	80 f9 02             	cmp    $0x2,%cl
    a9fe:	0f 84 64 0b 00 00    	je     b568 <fwp_main_thread+0x1d68>
    aa04:	80 f9 01             	cmp    $0x1,%cl
    aa07:	75 29                	jne    aa32 <fwp_main_thread+0x1232>
    aa09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa0c:	0f b7 c0             	movzwl %ax,%eax
    aa0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa12:	48 0f af c1          	imul   %rcx,%rax
    aa16:	48 c1 e8 20          	shr    $0x20,%rax
    aa1a:	48 39 d0             	cmp    %rdx,%rax
    aa1d:	73 13                	jae    aa32 <fwp_main_thread+0x1232>
    aa1f:	49 01 c5             	add    %rax,%r13
    aa22:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aa27:	0f 84 4f 0b 00 00    	je     b57c <fwp_main_thread+0x1d7c>
    aa2d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    aa32:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
    aa37:	0f 85 ce 8c ff ff    	jne    370b <fwp_main_thread.cold>
    aa3d:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    aa44:	00 
    aa45:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    aa4a:	48 89 05 07 7a 01 00 	mov    %rax,0x17a07(%rip)        # 22458 <fwp_cleanups>
    aa51:	e8 ea c6 ff ff       	call   7140 <fwp_tape_scope_release>
    aa56:	48 8b 03             	mov    (%rbx),%rax
    aa59:	49 89 c5             	mov    %rax,%r13
    aa5c:	49 0f ba f5 3f       	btr    $0x3f,%r13
    aa61:	48 85 c0             	test   %rax,%rax
    aa64:	0f 88 e6 07 00 00    	js     b250 <fwp_main_thread+0x1a50>
    aa6a:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa71:	48 89 d8             	mov    %rbx,%rax
    aa74:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa7b:	48 c1 e2 10          	shl    $0x10,%rdx
    aa7f:	48 39 d0             	cmp    %rdx,%rax
    aa82:	0f 83 c8 07 00 00    	jae    b250 <fwp_main_thread+0x1a50>
    aa88:	48 89 c2             	mov    %rax,%rdx
    aa8b:	48 c1 ea 10          	shr    $0x10,%rdx
    aa8f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa93:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa9a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa9e:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    aaa2:	48 85 c9             	test   %rcx,%rcx
    aaa5:	0f 84 a5 07 00 00    	je     b250 <fwp_main_thread+0x1a50>
    aaab:	0f b6 32             	movzbl (%rdx),%esi
    aaae:	40 80 fe 02          	cmp    $0x2,%sil
    aab2:	0f 84 88 07 00 00    	je     b240 <fwp_main_thread+0x1a40>
    aab8:	40 80 fe 01          	cmp    $0x1,%sil
    aabc:	0f 85 8e 07 00 00    	jne    b250 <fwp_main_thread+0x1a50>
    aac2:	8b 72 18             	mov    0x18(%rdx),%esi
    aac5:	0f b7 c0             	movzwl %ax,%eax
    aac8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aacb:	48 0f af c6          	imul   %rsi,%rax
    aacf:	48 c1 e8 20          	shr    $0x20,%rax
    aad3:	48 39 d0             	cmp    %rdx,%rax
    aad6:	0f 83 74 07 00 00    	jae    b250 <fwp_main_thread+0x1a50>
    aadc:	48 01 c1             	add    %rax,%rcx
    aadf:	80 39 01             	cmpb   $0x1,(%rcx)
    aae2:	0f 85 68 07 00 00    	jne    b250 <fwp_main_thread+0x1a50>
    aae8:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    aaed:	48 89 da             	mov    %rbx,%rdx
    aaf0:	31 ff                	xor    %edi,%edi
    aaf2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aaf7:	48 8d 48 08          	lea    0x8(%rax),%rcx
    aafb:	31 c0                	xor    %eax,%eax
    aafd:	4d 85 ed             	test   %r13,%r13
    ab00:	75 2f                	jne    ab31 <fwp_main_thread+0x1331>
    ab02:	eb 5c                	jmp    ab60 <fwp_main_thread+0x1360>
    ab04:	0f 1f 40 00          	nopl   0x0(%rax)
    ab08:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ab0c:	0f 88 85 0e 00 00    	js     b997 <fwp_main_thread+0x2197>
    ab12:	f2 0f 10 05 86 20 00 	movsd  0x2086(%rip),%xmm0        # cba0 <msg.4+0x30>
    ab19:	00 
    ab1a:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    ab1f:	48 83 c0 01          	add    $0x1,%rax
    ab23:	48 83 c1 08          	add    $0x8,%rcx
    ab27:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    ab2c:	49 39 c5             	cmp    %rax,%r13
    ab2f:	74 2f                	je     ab60 <fwp_main_thread+0x1360>
    ab31:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    ab35:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    ab39:	79 cd                	jns    ab08 <fwp_main_thread+0x1308>
    ab3b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    ab3f:	eb c7                	jmp    ab08 <fwp_main_thread+0x1308>
    ab41:	48 8d 3d d8 a0 ff ff 	lea    -0x5f28(%rip),%rdi        # 4c20 <fwp_heap_report>
    ab48:	e8 f3 10 00 00       	call   bc40 <atexit>
    ab4d:	e9 f6 ec ff ff       	jmp    9848 <fwp_main_thread+0x48>
    ab52:	e8 d9 a1 ff ff       	call   4d30 <fwp_heap_init>
    ab57:	e9 dc ec ff ff       	jmp    9838 <fwp_main_thread+0x38>
    ab5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab60:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    ab65:	e8 e6 d4 ff ff       	call   8050 <fwp_drop10>
    ab6a:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    ab6f:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    ab74:	90                   	nop
    ab75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab7c:	00 00 00 00 
    ab80:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    ab84:	49 83 c7 01          	add    $0x1,%r15
    ab88:	48 85 db             	test   %rbx,%rbx
    ab8b:	75 f3                	jne    ab80 <fwp_main_thread+0x1380>
    ab8d:	4c 8b 32             	mov    (%rdx),%r14
    ab90:	4d 85 f6             	test   %r14,%r14
    ab93:	0f 88 27 01 00 00    	js     acc0 <fwp_main_thread+0x14c0>
    ab99:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    aba0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aba5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    abac:	48 c1 e1 10          	shl    $0x10,%rcx
    abb0:	48 39 c8             	cmp    %rcx,%rax
    abb3:	0f 83 07 01 00 00    	jae    acc0 <fwp_main_thread+0x14c0>
    abb9:	48 89 c1             	mov    %rax,%rcx
    abbc:	48 c1 e9 10          	shr    $0x10,%rcx
    abc0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    abc4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    abcb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    abcf:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    abd3:	48 85 f6             	test   %rsi,%rsi
    abd6:	0f 84 e4 00 00 00    	je     acc0 <fwp_main_thread+0x14c0>
    abdc:	0f b6 39             	movzbl (%rcx),%edi
    abdf:	40 80 ff 02          	cmp    $0x2,%dil
    abe3:	0f 84 c7 00 00 00    	je     acb0 <fwp_main_thread+0x14b0>
    abe9:	40 80 ff 01          	cmp    $0x1,%dil
    abed:	0f 85 cd 00 00 00    	jne    acc0 <fwp_main_thread+0x14c0>
    abf3:	8b 79 18             	mov    0x18(%rcx),%edi
    abf6:	0f b7 c0             	movzwl %ax,%eax
    abf9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abfc:	48 0f af c7          	imul   %rdi,%rax
    ac00:	48 c1 e8 20          	shr    $0x20,%rax
    ac04:	48 39 c8             	cmp    %rcx,%rax
    ac07:	0f 83 b3 00 00 00    	jae    acc0 <fwp_main_thread+0x14c0>
    ac0d:	48 01 c6             	add    %rax,%rsi
    ac10:	80 3e 01             	cmpb   $0x1,(%rsi)
    ac13:	0f 85 a7 00 00 00    	jne    acc0 <fwp_main_thread+0x14c0>
    ac19:	4d 39 f7             	cmp    %r14,%r15
    ac1c:	4d 0f 46 f7          	cmovbe %r15,%r14
    ac20:	4d 85 f6             	test   %r14,%r14
    ac23:	0f 84 cb 0a 00 00    	je     b6f4 <fwp_main_thread+0x1ef4>
    ac29:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    ac2d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    ac33:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    ac38:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac3d:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    ac44:	00 
    ac45:	31 c0                	xor    %eax,%eax
    ac47:	49 8d 79 08          	lea    0x8(%r9),%rdi
    ac4b:	eb 54                	jmp    aca1 <fwp_main_thread+0x14a1>
    ac4d:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac5b:	00 00 00 00 
    ac5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac66:	00 00 00 00 
    ac6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac71:	00 00 00 00 
    ac75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac7c:	00 00 00 00 
    ac80:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    ac85:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    ac8a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    ac90:	48 83 c0 08          	add    $0x8,%rax
    ac94:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    ac98:	49 39 c0             	cmp    %rax,%r8
    ac9b:	0f 84 b7 00 00 00    	je     ad58 <fwp_main_thread+0x1558>
    aca1:	48 89 f9             	mov    %rdi,%rcx
    aca4:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    aca8:	79 d6                	jns    ac80 <fwp_main_thread+0x1480>
    acaa:	49 8b 49 10          	mov    0x10(%r9),%rcx
    acae:	eb d0                	jmp    ac80 <fwp_main_thread+0x1480>
    acb0:	66 85 c0             	test   %ax,%ax
    acb3:	0f 84 57 ff ff ff    	je     ac10 <fwp_main_thread+0x1410>
    acb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    acc0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    acc5:	45 31 ed             	xor    %r13d,%r13d
    acc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    accf:	00 
    acd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    acd4:	4c 89 e9             	mov    %r13,%rcx
    acd7:	49 83 c5 01          	add    $0x1,%r13
    acdb:	48 85 c0             	test   %rax,%rax
    acde:	75 f0                	jne    acd0 <fwp_main_thread+0x14d0>
    ace0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ace7:	ff ff 1f 
    acea:	4c 39 e8             	cmp    %r13,%rax
    aced:	0f 82 cd 0c 00 00    	jb     b9c0 <fwp_main_thread+0x21c0>
    acf3:	be 02 00 00 00       	mov    $0x2,%esi
    acf8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    acff:	00 
    ad00:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    ad05:	e8 46 af ff ff       	call   5c50 <fwp_heap_alloc>
    ad0a:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    ad0f:	49 89 c4             	mov    %rax,%r12
    ad12:	48 89 c6             	mov    %rax,%rsi
    ad15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ad1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    ad24:	48 83 c6 08          	add    $0x8,%rsi
    ad28:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    ad2c:	48 8b 40 10          	mov    0x10(%rax),%rax
    ad30:	48 85 c0             	test   %rax,%rax
    ad33:	75 eb                	jne    ad20 <fwp_main_thread+0x1520>
    ad35:	49 0f ba f6 3f       	btr    $0x3f,%r14
    ad3a:	4d 39 ee             	cmp    %r13,%r14
    ad3d:	4d 0f 47 f5          	cmova  %r13,%r14
    ad41:	4d 85 f6             	test   %r14,%r14
    ad44:	0f 84 a5 09 00 00    	je     b6ef <fwp_main_thread+0x1eef>
    ad4a:	45 31 ed             	xor    %r13d,%r13d
    ad4d:	e9 e1 fe ff ff       	jmp    ac33 <fwp_main_thread+0x1433>
    ad52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad58:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    ad5f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    ad66:	45 31 ff             	xor    %r15d,%r15d
    ad69:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    ad70:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    ad75:	48 c1 e7 10          	shl    $0x10,%rdi
    ad79:	eb 1b                	jmp    ad96 <fwp_main_thread+0x1596>
    ad7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad80:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ad84:	49 83 c7 01          	add    $0x1,%r15
    ad88:	48 85 d2             	test   %rdx,%rdx
    ad8b:	74 5f                	je     adec <fwp_main_thread+0x15ec>
    ad8d:	4d 39 f7             	cmp    %r14,%r15
    ad90:	0f 83 fa 03 00 00    	jae    b190 <fwp_main_thread+0x1990>
    ad96:	48 89 d0             	mov    %rdx,%rax
    ad99:	4c 29 c0             	sub    %r8,%rax
    ad9c:	48 39 f8             	cmp    %rdi,%rax
    ad9f:	73 4b                	jae    adec <fwp_main_thread+0x15ec>
    ada1:	48 89 c1             	mov    %rax,%rcx
    ada4:	48 c1 e9 10          	shr    $0x10,%rcx
    ada8:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    adac:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    adb0:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    adb4:	48 85 f6             	test   %rsi,%rsi
    adb7:	74 33                	je     adec <fwp_main_thread+0x15ec>
    adb9:	44 0f b6 11          	movzbl (%rcx),%r10d
    adbd:	41 80 fa 02          	cmp    $0x2,%r10b
    adc1:	0f 84 b1 03 00 00    	je     b178 <fwp_main_thread+0x1978>
    adc7:	41 80 fa 01          	cmp    $0x1,%r10b
    adcb:	75 1f                	jne    adec <fwp_main_thread+0x15ec>
    adcd:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    add1:	0f b7 c0             	movzwl %ax,%eax
    add4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    add7:	49 0f af c2          	imul   %r10,%rax
    addb:	48 c1 e8 20          	shr    $0x20,%rax
    addf:	48 39 c8             	cmp    %rcx,%rax
    ade2:	73 08                	jae    adec <fwp_main_thread+0x15ec>
    ade4:	48 01 c6             	add    %rax,%rsi
    ade7:	80 3e 01             	cmpb   $0x1,(%rsi)
    adea:	74 94                	je     ad80 <fwp_main_thread+0x1580>
    adec:	4d 39 f7             	cmp    %r14,%r15
    adef:	72 43                	jb     ae34 <fwp_main_thread+0x1634>
    adf1:	e9 9a 03 00 00       	jmp    b190 <fwp_main_thread+0x1990>
    adf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adfd:	00 00 00 
    ae00:	40 80 fe 01          	cmp    $0x1,%sil
    ae04:	75 25                	jne    ae2b <fwp_main_thread+0x162b>
    ae06:	8b 71 18             	mov    0x18(%rcx),%esi
    ae09:	0f b7 c0             	movzwl %ax,%eax
    ae0c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ae0f:	48 0f af c6          	imul   %rsi,%rax
    ae13:	48 c1 e8 20          	shr    $0x20,%rax
    ae17:	48 39 c8             	cmp    %rcx,%rax
    ae1a:	73 0f                	jae    ae2b <fwp_main_thread+0x162b>
    ae1c:	48 01 c2             	add    %rax,%rdx
    ae1f:	80 3a ff             	cmpb   $0xff,(%rdx)
    ae22:	0f 84 d8 04 00 00    	je     b300 <fwp_main_thread+0x1b00>
    ae28:	c6 02 01             	movb   $0x1,(%rdx)
    ae2b:	4d 39 fe             	cmp    %r15,%r14
    ae2e:	0f 84 8c 00 00 00    	je     aec0 <fwp_main_thread+0x16c0>
    ae34:	49 83 ee 01          	sub    $0x1,%r14
    ae38:	66 48 0f 6e eb       	movq   %rbx,%xmm5
    ae3d:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    ae42:	bf 01 00 00 00       	mov    $0x1,%edi
    ae47:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    ae4d:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    ae51:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
    ae58:	00 
    ae59:	e8 12 af ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ae5e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ae65:	48 89 c3             	mov    %rax,%rbx
    ae68:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ae6f:	48 c1 e2 10          	shl    $0x10,%rdx
    ae73:	48 39 d0             	cmp    %rdx,%rax
    ae76:	73 b3                	jae    ae2b <fwp_main_thread+0x162b>
    ae78:	48 89 c2             	mov    %rax,%rdx
    ae7b:	48 c1 ea 10          	shr    $0x10,%rdx
    ae7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae83:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ae8a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ae8e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ae92:	48 85 d2             	test   %rdx,%rdx
    ae95:	74 94                	je     ae2b <fwp_main_thread+0x162b>
    ae97:	0f b6 31             	movzbl (%rcx),%esi
    ae9a:	40 80 fe 02          	cmp    $0x2,%sil
    ae9e:	0f 85 5c ff ff ff    	jne    ae00 <fwp_main_thread+0x1600>
    aea4:	66 85 c0             	test   %ax,%ax
    aea7:	0f 84 72 ff ff ff    	je     ae1f <fwp_main_thread+0x161f>
    aead:	4d 39 fe             	cmp    %r15,%r14
    aeb0:	75 82                	jne    ae34 <fwp_main_thread+0x1634>
    aeb2:	0f 1f 00             	nopl   (%rax)
    aeb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aebc:	00 00 00 00 
    aec0:	4d 85 f6             	test   %r14,%r14
    aec3:	0f 85 c7 02 00 00    	jne    b190 <fwp_main_thread+0x1990>
    aec9:	45 85 ed             	test   %r13d,%r13d
    aecc:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    aed2:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    aed7:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    aedc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    aee1:	e8 6a a8 ff ff       	call   5750 <fwp_mem_free>
    aee6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    aeeb:	e8 60 d1 ff ff       	call   8050 <fwp_drop10>
    aef0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aef7:	4c 89 f0             	mov    %r14,%rax
    aefa:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    af01:	48 c1 e2 10          	shl    $0x10,%rdx
    af05:	48 39 d0             	cmp    %rdx,%rax
    af08:	73 76                	jae    af80 <fwp_main_thread+0x1780>
    af0a:	48 89 c2             	mov    %rax,%rdx
    af0d:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    af14:	48 c1 ea 10          	shr    $0x10,%rdx
    af18:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    af1c:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    af20:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af24:	4d 85 e4             	test   %r12,%r12
    af27:	74 57                	je     af80 <fwp_main_thread+0x1780>
    af29:	0f b6 0a             	movzbl (%rdx),%ecx
    af2c:	80 f9 02             	cmp    $0x2,%cl
    af2f:	0f 84 ab 05 00 00    	je     b4e0 <fwp_main_thread+0x1ce0>
    af35:	80 f9 01             	cmp    $0x1,%cl
    af38:	75 46                	jne    af80 <fwp_main_thread+0x1780>
    af3a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af3d:	0f b7 c0             	movzwl %ax,%eax
    af40:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af43:	48 0f af c1          	imul   %rcx,%rax
    af47:	48 c1 e8 20          	shr    $0x20,%rax
    af4b:	48 39 d0             	cmp    %rdx,%rax
    af4e:	73 30                	jae    af80 <fwp_main_thread+0x1780>
    af50:	49 01 c4             	add    %rax,%r12
    af53:	41 0f b6 04 24       	movzbl (%r12),%eax
    af58:	84 c0                	test   %al,%al
    af5a:	74 24                	je     af80 <fwp_main_thread+0x1780>
    af5c:	3c 01                	cmp    $0x1,%al
    af5e:	0f 84 2c 06 00 00    	je     b590 <fwp_main_thread+0x1d90>
    af64:	3c ff                	cmp    $0xff,%al
    af66:	0f 84 1a 08 00 00    	je     b786 <fwp_main_thread+0x1f86>
    af6c:	83 e8 01             	sub    $0x1,%eax
    af6f:	41 88 04 24          	mov    %al,(%r12)
    af73:	66 90                	xchg   %ax,%ax
    af75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af7c:	00 00 00 00 
    af80:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    af85:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af89:	b9 01 00 00 00       	mov    $0x1,%ecx
    af8e:	48 89 de             	mov    %rbx,%rsi
    af91:	48 8d 15 08 4c 00 00 	lea    0x4c08(%rip),%rdx        # fba0 <d0>
    af98:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    af9f:	00 
    afa0:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    afa7:	00 00 00 00 00 
    afac:	e8 0f d8 ff ff       	call   87c0 <fwp_write>
    afb1:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
    afb8:	00 
    afb9:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    afc0:	00 
    afc1:	48 8d 05 c9 10 00 00 	lea    0x10c9(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    afc8:	4d 85 f6             	test   %r14,%r14
    afcb:	4c 0f 44 f0          	cmove  %rax,%r14
    afcf:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    afd3:	0f 87 34 0a 00 00    	ja     ba0d <fwp_main_thread+0x220d>
    afd9:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    afdd:	be 01 00 00 00       	mov    $0x1,%esi
    afe2:	e8 69 ac ff ff       	call   5c50 <fwp_heap_alloc>
    afe7:	4c 89 fa             	mov    %r15,%rdx
    afea:	4c 89 f6             	mov    %r14,%rsi
    afed:	4c 89 38             	mov    %r15,(%rax)
    aff0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    aff4:	49 89 c4             	mov    %rax,%r12
    aff7:	4c 89 ef             	mov    %r13,%rdi
    affa:	e8 71 85 ff ff       	call   3570 <memcpy@plt>
    afff:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    b005:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    b00c:	00 
    b00d:	e8 8e 83 ff ff       	call   33a0 <free@plt>
    b012:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b019:	4c 89 e0             	mov    %r12,%rax
    b01c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b023:	48 c1 e2 10          	shl    $0x10,%rdx
    b027:	48 39 d0             	cmp    %rdx,%rax
    b02a:	73 57                	jae    b083 <fwp_main_thread+0x1883>
    b02c:	48 89 c2             	mov    %rax,%rdx
    b02f:	48 c1 ea 10          	shr    $0x10,%rdx
    b033:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b037:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b03e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b042:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b046:	4d 85 f6             	test   %r14,%r14
    b049:	74 38                	je     b083 <fwp_main_thread+0x1883>
    b04b:	0f b6 0a             	movzbl (%rdx),%ecx
    b04e:	80 f9 02             	cmp    $0x2,%cl
    b051:	0f 84 69 06 00 00    	je     b6c0 <fwp_main_thread+0x1ec0>
    b057:	80 f9 01             	cmp    $0x1,%cl
    b05a:	75 27                	jne    b083 <fwp_main_thread+0x1883>
    b05c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b05f:	0f b7 c0             	movzwl %ax,%eax
    b062:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b065:	48 0f af c1          	imul   %rcx,%rax
    b069:	48 c1 e8 20          	shr    $0x20,%rax
    b06d:	48 39 d0             	cmp    %rdx,%rax
    b070:	73 11                	jae    b083 <fwp_main_thread+0x1883>
    b072:	49 01 c6             	add    %rax,%r14
    b075:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b079:	0f 84 54 06 00 00    	je     b6d3 <fwp_main_thread+0x1ed3>
    b07f:	41 c6 06 01          	movb   $0x1,(%r14)
    b083:	48 89 df             	mov    %rbx,%rdi
    b086:	e8 d5 cb ff ff       	call   7c60 <fwp_drop0>
    b08b:	49 8b 14 24          	mov    (%r12),%rdx
    b08f:	be 01 00 00 00       	mov    $0x1,%esi
    b094:	4c 89 ef             	mov    %r13,%rdi
    b097:	48 8b 0d 82 73 01 00 	mov    0x17382(%rip),%rcx        # 22420 <fwp_prog_out>
    b09e:	e8 9d 85 ff ff       	call   3640 <fwrite@plt>
    b0a3:	48 8b 35 76 73 01 00 	mov    0x17376(%rip),%rsi        # 22420 <fwp_prog_out>
    b0aa:	bf 0a 00 00 00       	mov    $0xa,%edi
    b0af:	e8 0c 84 ff ff       	call   34c0 <fputc@plt>
    b0b4:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b0bb:	4c 89 e0             	mov    %r12,%rax
    b0be:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b0c5:	48 c1 e2 10          	shl    $0x10,%rdx
    b0c9:	48 39 d0             	cmp    %rdx,%rax
    b0cc:	73 72                	jae    b140 <fwp_main_thread+0x1940>
    b0ce:	48 89 c2             	mov    %rax,%rdx
    b0d1:	48 c1 ea 10          	shr    $0x10,%rdx
    b0d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0d9:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b0e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0e4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b0e8:	48 85 db             	test   %rbx,%rbx
    b0eb:	74 53                	je     b140 <fwp_main_thread+0x1940>
    b0ed:	0f b6 0a             	movzbl (%rdx),%ecx
    b0f0:	80 f9 02             	cmp    $0x2,%cl
    b0f3:	0f 84 97 05 00 00    	je     b690 <fwp_main_thread+0x1e90>
    b0f9:	80 f9 01             	cmp    $0x1,%cl
    b0fc:	75 42                	jne    b140 <fwp_main_thread+0x1940>
    b0fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b101:	0f b7 c0             	movzwl %ax,%eax
    b104:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b107:	48 0f af c1          	imul   %rcx,%rax
    b10b:	48 c1 e8 20          	shr    $0x20,%rax
    b10f:	48 39 d0             	cmp    %rdx,%rax
    b112:	73 2c                	jae    b140 <fwp_main_thread+0x1940>
    b114:	48 01 c3             	add    %rax,%rbx
    b117:	0f b6 03             	movzbl (%rbx),%eax
    b11a:	84 c0                	test   %al,%al
    b11c:	74 22                	je     b140 <fwp_main_thread+0x1940>
    b11e:	3c 01                	cmp    $0x1,%al
    b120:	0f 84 86 05 00 00    	je     b6ac <fwp_main_thread+0x1eac>
    b126:	3c ff                	cmp    $0xff,%al
    b128:	0f 84 6a 07 00 00    	je     b898 <fwp_main_thread+0x2098>
    b12e:	83 e8 01             	sub    $0x1,%eax
    b131:	88 03                	mov    %al,(%rbx)
    b133:	66 90                	xchg   %ax,%ax
    b135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b13c:	00 00 00 00 
    b140:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    b145:	48 8b 40 10          	mov    0x10(%rax),%rax
    b149:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b14e:	48 85 c0             	test   %rax,%rax
    b151:	0f 84 c7 05 00 00    	je     b71e <fwp_main_thread+0x1f1e>
    b157:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b15e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b165:	48 8b 1d ec 72 01 00 	mov    0x172ec(%rip),%rbx        # 22458 <fwp_cleanups>
    b16c:	e9 5f f0 ff ff       	jmp    a1d0 <fwp_main_thread+0x9d0>
    b171:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b178:	66 85 c0             	test   %ax,%ax
    b17b:	0f 84 66 fc ff ff    	je     ade7 <fwp_main_thread+0x15e7>
    b181:	4d 39 f7             	cmp    %r14,%r15
    b184:	0f 82 aa fc ff ff    	jb     ae34 <fwp_main_thread+0x1634>
    b18a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b190:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b195:	4c 89 e0             	mov    %r12,%rax
    b198:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    b19c:	0f 1f 40 00          	nopl   0x0(%rax)
    b1a0:	48 8b 10             	mov    (%rax),%rdx
    b1a3:	48 83 c0 08          	add    $0x8,%rax
    b1a7:	4c 89 f6             	mov    %r14,%rsi
    b1aa:	49 89 56 08          	mov    %rdx,0x8(%r14)
    b1ae:	4d 8b 76 10          	mov    0x10(%r14),%r14
    b1b2:	48 39 c7             	cmp    %rax,%rdi
    b1b5:	75 e9                	jne    b1a0 <fwp_main_thread+0x19a0>
    b1b7:	45 85 ed             	test   %r13d,%r13d
    b1ba:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    b1c0:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    b1c4:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    b1c9:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b1ce:	e9 09 fd ff ff       	jmp    aedc <fwp_main_thread+0x16dc>
    b1d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b1d8:	48 83 3d a8 4e 01 00 	cmpq   $0x0,0x14ea8(%rip)        # 20088 <fwp_tape_cached_bytes>
    b1df:	00 
    b1e0:	0f 84 92 f2 ff ff    	je     a478 <fwp_main_thread+0xc78>
    b1e6:	48 8b 05 c3 4e 01 00 	mov    0x14ec3(%rip),%rax        # 200b0 <fwp_tape_workspace+0x10>
    b1ed:	66 0f 6f 0d ab 4e 01 	movdqa 0x14eab(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    b1f4:	00 
    b1f5:	48 c7 05 88 4e 01 00 	movq   $0x0,0x14e88(%rip)        # 20088 <fwp_tape_cached_bytes>
    b1fc:	00 00 00 00 
    b200:	48 89 42 30          	mov    %rax,0x30(%rdx)
    b204:	48 8b 05 ad 4e 01 00 	mov    0x14ead(%rip),%rax        # 200b8 <fwp_tape_workspace+0x18>
    b20b:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
    b20f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b213:	48 89 42 18          	mov    %rax,0x18(%rdx)
    b217:	48 8b 05 a2 4e 01 00 	mov    0x14ea2(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    b21e:	0f 29 0d 7b 4e 01 00 	movaps %xmm1,0x14e7b(%rip)        # 200a0 <fwp_tape_workspace>
    b225:	48 89 42 38          	mov    %rax,0x38(%rdx)
    b229:	0f 29 0d 80 4e 01 00 	movaps %xmm1,0x14e80(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    b230:	48 c7 05 85 4e 01 00 	movq   $0x0,0x14e85(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    b237:	00 00 00 00 
    b23b:	e9 38 f2 ff ff       	jmp    a478 <fwp_main_thread+0xc78>
    b240:	66 85 c0             	test   %ax,%ax
    b243:	0f 84 96 f8 ff ff    	je     aadf <fwp_main_thread+0x12df>
    b249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b250:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b257:	ff ff 1f 
    b25a:	4c 39 e8             	cmp    %r13,%rax
    b25d:	0f 82 45 07 00 00    	jb     b9a8 <fwp_main_thread+0x21a8>
    b263:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b26a:	00 
    b26b:	be 01 00 00 00       	mov    $0x1,%esi
    b270:	e8 db a9 ff ff       	call   5c50 <fwp_heap_alloc>
    b275:	4c 89 28             	mov    %r13,(%rax)
    b278:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    b27f:	48 89 c2             	mov    %rax,%rdx
    b282:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b287:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b28e:	48 c1 e1 10          	shl    $0x10,%rcx
    b292:	48 39 c8             	cmp    %rcx,%rax
    b295:	73 59                	jae    b2f0 <fwp_main_thread+0x1af0>
    b297:	48 89 c1             	mov    %rax,%rcx
    b29a:	48 c1 e9 10          	shr    $0x10,%rcx
    b29e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b2a2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    b2a9:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b2ad:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    b2b1:	4d 85 f6             	test   %r14,%r14
    b2b4:	74 3a                	je     b2f0 <fwp_main_thread+0x1af0>
    b2b6:	0f b6 31             	movzbl (%rcx),%esi
    b2b9:	40 80 fe 02          	cmp    $0x2,%sil
    b2bd:	0f 84 6d 03 00 00    	je     b630 <fwp_main_thread+0x1e30>
    b2c3:	40 80 fe 01          	cmp    $0x1,%sil
    b2c7:	75 27                	jne    b2f0 <fwp_main_thread+0x1af0>
    b2c9:	8b 71 18             	mov    0x18(%rcx),%esi
    b2cc:	0f b7 c0             	movzwl %ax,%eax
    b2cf:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b2d2:	48 0f af c6          	imul   %rsi,%rax
    b2d6:	48 c1 e8 20          	shr    $0x20,%rax
    b2da:	48 39 c8             	cmp    %rcx,%rax
    b2dd:	73 11                	jae    b2f0 <fwp_main_thread+0x1af0>
    b2df:	49 01 c6             	add    %rax,%r14
    b2e2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b2e6:	0f 84 57 03 00 00    	je     b643 <fwp_main_thread+0x1e43>
    b2ec:	41 c6 06 01          	movb   $0x1,(%r14)
    b2f0:	48 89 df             	mov    %rbx,%rdi
    b2f3:	e9 fa f7 ff ff       	jmp    aaf2 <fwp_main_thread+0x12f2>
    b2f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b2ff:	00 
    b300:	48 89 d7             	mov    %rdx,%rdi
    b303:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    b308:	e8 03 a2 ff ff       	call   5510 <fwp_rc_forget_slot>
    b30d:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    b312:	e9 11 fb ff ff       	jmp    ae28 <fwp_main_thread+0x1628>
    b317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b31e:	00 00 
    b320:	4d 85 e4             	test   %r12,%r12
    b323:	0f 85 ea f2 ff ff    	jne    a613 <fwp_main_thread+0xe13>
    b329:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b330:	31 d2                	xor    %edx,%edx
    b332:	e9 d1 f3 ff ff       	jmp    a708 <fwp_main_thread+0xf08>
    b337:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b33e:	00 00 
    b340:	49 39 d6             	cmp    %rdx,%r14
    b343:	0f 84 47 f0 ff ff    	je     a390 <fwp_main_thread+0xb90>
    b349:	4c 8b 3d 90 4d 01 00 	mov    0x14d90(%rip),%r15        # 200e0 <fwp_tapes>
    b350:	49 89 d6             	mov    %rdx,%r14
    b353:	48 8d 5a 01          	lea    0x1(%rdx),%rbx
    b357:	e9 c7 f0 ff ff       	jmp    a423 <fwp_main_thread+0xc23>
    b35c:	0f 1f 40 00          	nopl   0x0(%rax)
    b360:	be 02 00 00 00       	mov    $0x2,%esi
    b365:	bf 08 00 00 00       	mov    $0x8,%edi
    b36a:	49 c1 e5 10          	shl    $0x10,%r13
    b36e:	e8 dd a8 ff ff       	call   5c50 <fwp_heap_alloc>
    b373:	4c 09 eb             	or     %r13,%rbx
    b376:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b37d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b384:	49 89 c6             	mov    %rax,%r14
    b387:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b38e:	48 c1 e2 10          	shl    $0x10,%rdx
    b392:	48 39 d0             	cmp    %rdx,%rax
    b395:	73 99                	jae    b330 <fwp_main_thread+0x1b30>
    b397:	48 89 c2             	mov    %rax,%rdx
    b39a:	48 c1 ea 10          	shr    $0x10,%rdx
    b39e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3a2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b3a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3ad:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b3b1:	4d 85 ed             	test   %r13,%r13
    b3b4:	0f 84 ba f2 ff ff    	je     a674 <fwp_main_thread+0xe74>
    b3ba:	0f b6 0a             	movzbl (%rdx),%ecx
    b3bd:	45 31 e4             	xor    %r12d,%r12d
    b3c0:	80 f9 02             	cmp    $0x2,%cl
    b3c3:	0f 85 17 f2 ff ff    	jne    a5e0 <fwp_main_thread+0xde0>
    b3c9:	66 85 c0             	test   %ax,%ax
    b3cc:	0f 85 3c f2 ff ff    	jne    a60e <fwp_main_thread+0xe0e>
    b3d2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b3d7:	0f 85 2c f2 ff ff    	jne    a609 <fwp_main_thread+0xe09>
    b3dd:	4c 89 ef             	mov    %r13,%rdi
    b3e0:	e8 2b a1 ff ff       	call   5510 <fwp_rc_forget_slot>
    b3e5:	e9 1f f2 ff ff       	jmp    a609 <fwp_main_thread+0xe09>
    b3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b3f0:	49 8d 59 01          	lea    0x1(%r9),%rbx
    b3f4:	49 39 de             	cmp    %rbx,%r14
    b3f7:	7c 3a                	jl     b433 <fwp_main_thread+0x1c33>
    b3f9:	48 85 c9             	test   %rcx,%rcx
    b3fc:	0f 84 18 01 00 00    	je     b51a <fwp_main_thread+0x1d1a>
    b402:	48 89 cf             	mov    %rcx,%rdi
    b405:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b40c:	00 
    b40d:	31 f6                	xor    %esi,%esi
    b40f:	49 89 de             	mov    %rbx,%r14
    b412:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    b417:	4d 29 e6             	sub    %r12,%r14
    b41a:	e8 81 80 ff ff       	call   34a0 <memset@plt>
    b41f:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    b424:	48 89 c1             	mov    %rax,%rcx
    b427:	e9 5d f4 ff ff       	jmp    a889 <fwp_main_thread+0x1089>
    b42c:	0f 1f 40 00          	nopl   0x0(%rax)
    b430:	4c 89 e3             	mov    %r12,%rbx
    b433:	4d 85 f6             	test   %r14,%r14
    b436:	4c 0f 44 f3          	cmove  %rbx,%r14
    b43a:	eb 19                	jmp    b455 <fwp_main_thread+0x1c55>
    b43c:	0f 1f 40 00          	nopl   0x0(%rax)
    b440:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    b444:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    b44b:	48 89 d8             	mov    %rbx,%rax
    b44e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b452:	49 89 c6             	mov    %rax,%r14
    b455:	49 39 de             	cmp    %rbx,%r14
    b458:	7c e6                	jl     b440 <fwp_main_thread+0x1c40>
    b45a:	48 85 c9             	test   %rcx,%rcx
    b45d:	0f 84 fd 01 00 00    	je     b660 <fwp_main_thread+0x1e60>
    b463:	48 89 cf             	mov    %rcx,%rdi
    b466:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    b46d:	00 
    b46e:	e8 2d 81 ff ff       	call   35a0 <realloc@plt>
    b473:	48 89 c1             	mov    %rax,%rcx
    b476:	48 85 c9             	test   %rcx,%rcx
    b479:	0f 84 8d 00 00 00    	je     b50c <fwp_main_thread+0x1d0c>
    b47f:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    b486:	00 
    b487:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    b48e:	00 
    b48f:	48 85 db             	test   %rbx,%rbx
    b492:	0f 85 7a 03 00 00    	jne    b812 <fwp_main_thread+0x2012>
    b498:	4d 89 e6             	mov    %r12,%r14
    b49b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b4a2:	49 f7 de             	neg    %r14
    b4a5:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    b4aa:	48 85 c0             	test   %rax,%rax
    b4ad:	0f 88 ea f3 ff ff    	js     a89d <fwp_main_thread+0x109d>
    b4b3:	41 89 c1             	mov    %eax,%r9d
    b4b6:	e9 ce f3 ff ff       	jmp    a889 <fwp_main_thread+0x1089>
    b4bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b4c0:	48 8d 3d 99 bb ff ff 	lea    -0x4467(%rip),%rdi        # 7060 <fwp_tape_finish>
    b4c7:	e8 74 07 00 00       	call   bc40 <atexit>
    b4cc:	85 c0                	test   %eax,%eax
    b4ce:	75 63                	jne    b533 <fwp_main_thread+0x1d33>
    b4d0:	c7 05 86 4b 00 00 01 	movl   $0x1,0x4b86(%rip)        # 10060 <registered_finish.1>
    b4d7:	00 00 00 
    b4da:	e9 61 ee ff ff       	jmp    a340 <fwp_main_thread+0xb40>
    b4df:	90                   	nop
    b4e0:	66 85 c0             	test   %ax,%ax
    b4e3:	0f 85 97 fa ff ff    	jne    af80 <fwp_main_thread+0x1780>
    b4e9:	e9 65 fa ff ff       	jmp    af53 <fwp_main_thread+0x1753>
    b4ee:	66 90                	xchg   %ax,%ax
    b4f0:	66 85 c0             	test   %ax,%ax
    b4f3:	0f 85 ff ed ff ff    	jne    a2f8 <fwp_main_thread+0xaf8>
    b4f9:	e9 e6 ed ff ff       	jmp    a2e4 <fwp_main_thread+0xae4>
    b4fe:	66 90                	xchg   %ax,%ax
    b500:	4c 89 e3             	mov    %r12,%rbx
    b503:	4d 39 f4             	cmp    %r14,%r12
    b506:	0f 8f 27 ff ff ff    	jg     b433 <fwp_main_thread+0x1c33>
    b50c:	48 85 db             	test   %rbx,%rbx
    b50f:	74 87                	je     b498 <fwp_main_thread+0x1c98>
    b511:	48 85 c9             	test   %rcx,%rcx
    b514:	0f 85 75 ff ff ff    	jne    b48f <fwp_main_thread+0x1c8f>
    b51a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    b521:	00 
    b522:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    b527:	48 89 05 2a 6f 01 00 	mov    %rax,0x16f2a(%rip)        # 22458 <fwp_cleanups>
    b52e:	e8 fd 9a ff ff       	call   5030 <fwp_tape_buffers_release>
    b533:	48 8b 0d 06 4b 00 00 	mov    0x4b06(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    b53a:	ba 13 00 00 00       	mov    $0x13,%edx
    b53f:	be 01 00 00 00       	mov    $0x1,%esi
    b544:	48 8d 3d bd 0a 00 00 	lea    0xabd(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    b54b:	e8 f0 80 ff ff       	call   3640 <fwrite@plt>
    b550:	31 ff                	xor    %edi,%edi
    b552:	e8 39 80 ff ff       	call   3590 <fflush@plt>
    b557:	bf 66 00 00 00       	mov    $0x66,%edi
    b55c:	e8 ff 80 ff ff       	call   3660 <_Exit@plt>
    b561:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b568:	66 85 c0             	test   %ax,%ax
    b56b:	0f 85 c1 f4 ff ff    	jne    aa32 <fwp_main_thread+0x1232>
    b571:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b576:	0f 85 b1 f4 ff ff    	jne    aa2d <fwp_main_thread+0x122d>
    b57c:	4c 89 ef             	mov    %r13,%rdi
    b57f:	e8 8c 9f ff ff       	call   5510 <fwp_rc_forget_slot>
    b584:	e9 a4 f4 ff ff       	jmp    aa2d <fwp_main_thread+0x122d>
    b589:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b590:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b597:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b59e:	4c 89 f0             	mov    %r14,%rax
    b5a1:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b5a5:	48 29 c8             	sub    %rcx,%rax
    b5a8:	48 c1 e2 10          	shl    $0x10,%rdx
    b5ac:	48 39 d0             	cmp    %rdx,%rax
    b5af:	73 65                	jae    b616 <fwp_main_thread+0x1e16>
    b5b1:	48 89 c7             	mov    %rax,%rdi
    b5b4:	48 c1 ef 10          	shr    $0x10,%rdi
    b5b8:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b5bc:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b5c0:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b5c4:	48 85 ff             	test   %rdi,%rdi
    b5c7:	74 4d                	je     b616 <fwp_main_thread+0x1e16>
    b5c9:	44 0f b6 06          	movzbl (%rsi),%r8d
    b5cd:	41 80 f8 02          	cmp    $0x2,%r8b
    b5d1:	0f 84 32 01 00 00    	je     b709 <fwp_main_thread+0x1f09>
    b5d7:	41 80 f8 01          	cmp    $0x1,%r8b
    b5db:	75 39                	jne    b616 <fwp_main_thread+0x1e16>
    b5dd:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b5e1:	0f b7 c0             	movzwl %ax,%eax
    b5e4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b5e7:	49 0f af c0          	imul   %r8,%rax
    b5eb:	48 c1 e8 20          	shr    $0x20,%rax
    b5ef:	48 39 f0             	cmp    %rsi,%rax
    b5f2:	73 22                	jae    b616 <fwp_main_thread+0x1e16>
    b5f4:	48 01 c7             	add    %rax,%rdi
    b5f7:	80 3f 01             	cmpb   $0x1,(%rdi)
    b5fa:	75 1a                	jne    b616 <fwp_main_thread+0x1e16>
    b5fc:	4c 89 f7             	mov    %r14,%rdi
    b5ff:	e8 4c a1 ff ff       	call   5750 <fwp_mem_free>
    b604:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b60b:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b612:	48 c1 e2 10          	shl    $0x10,%rdx
    b616:	4c 89 e0             	mov    %r12,%rax
    b619:	48 29 c8             	sub    %rcx,%rax
    b61c:	48 39 d0             	cmp    %rdx,%rax
    b61f:	0f 83 5b f9 ff ff    	jae    af80 <fwp_main_thread+0x1780>
    b625:	4d 89 e6             	mov    %r12,%r14
    b628:	e9 dd f8 ff ff       	jmp    af0a <fwp_main_thread+0x170a>
    b62d:	0f 1f 00             	nopl   (%rax)
    b630:	66 85 c0             	test   %ax,%ax
    b633:	0f 85 b7 fc ff ff    	jne    b2f0 <fwp_main_thread+0x1af0>
    b639:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b63d:	0f 85 a9 fc ff ff    	jne    b2ec <fwp_main_thread+0x1aec>
    b643:	4c 89 f7             	mov    %r14,%rdi
    b646:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    b64b:	e8 c0 9e ff ff       	call   5510 <fwp_rc_forget_slot>
    b650:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    b655:	e9 92 fc ff ff       	jmp    b2ec <fwp_main_thread+0x1aec>
    b65a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b660:	be 08 00 00 00       	mov    $0x8,%esi
    b665:	4c 89 f7             	mov    %r14,%rdi
    b668:	e8 93 7e ff ff       	call   3500 <calloc@plt>
    b66d:	48 89 c1             	mov    %rax,%rcx
    b670:	e9 01 fe ff ff       	jmp    b476 <fwp_main_thread+0x1c76>
    b675:	0f 1f 00             	nopl   (%rax)
    b678:	66 85 c0             	test   %ax,%ax
    b67b:	0f 85 d3 eb ff ff    	jne    a254 <fwp_main_thread+0xa54>
    b681:	e9 a8 eb ff ff       	jmp    a22e <fwp_main_thread+0xa2e>
    b686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b68d:	00 00 00 
    b690:	66 85 c0             	test   %ax,%ax
    b693:	0f 85 a7 fa ff ff    	jne    b140 <fwp_main_thread+0x1940>
    b699:	0f b6 03             	movzbl (%rbx),%eax
    b69c:	84 c0                	test   %al,%al
    b69e:	0f 84 9c fa ff ff    	je     b140 <fwp_main_thread+0x1940>
    b6a4:	3c 01                	cmp    $0x1,%al
    b6a6:	0f 85 7a fa ff ff    	jne    b126 <fwp_main_thread+0x1926>
    b6ac:	4c 89 e7             	mov    %r12,%rdi
    b6af:	e8 9c a0 ff ff       	call   5750 <fwp_mem_free>
    b6b4:	e9 87 fa ff ff       	jmp    b140 <fwp_main_thread+0x1940>
    b6b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6c0:	66 85 c0             	test   %ax,%ax
    b6c3:	0f 85 ba f9 ff ff    	jne    b083 <fwp_main_thread+0x1883>
    b6c9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b6cd:	0f 85 ac f9 ff ff    	jne    b07f <fwp_main_thread+0x187f>
    b6d3:	4c 89 f7             	mov    %r14,%rdi
    b6d6:	e8 35 9e ff ff       	call   5510 <fwp_rc_forget_slot>
    b6db:	e9 9f f9 ff ff       	jmp    b07f <fwp_main_thread+0x187f>
    b6e0:	be 58 00 00 00       	mov    $0x58,%esi
    b6e5:	bb 01 00 00 00       	mov    $0x1,%ebx
    b6ea:	e9 db ec ff ff       	jmp    a3ca <fwp_main_thread+0xbca>
    b6ef:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b6f4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b6f9:	31 db                	xor    %ebx,%ebx
    b6fb:	e9 dc f7 ff ff       	jmp    aedc <fwp_main_thread+0x16dc>
    b700:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b704:	e9 f1 e2 ff ff       	jmp    99fa <fwp_main_thread+0x1fa>
    b709:	66 85 c0             	test   %ax,%ax
    b70c:	0f 85 04 ff ff ff    	jne    b616 <fwp_main_thread+0x1e16>
    b712:	e9 e0 fe ff ff       	jmp    b5f7 <fwp_main_thread+0x1df7>
    b717:	31 db                	xor    %ebx,%ebx
    b719:	e9 9e e3 ff ff       	jmp    9abc <fwp_main_thread+0x2bc>
    b71e:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
    b723:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b728:	e8 33 c5 ff ff       	call   7c60 <fwp_drop0>
    b72d:	4c 89 f7             	mov    %r14,%rdi
    b730:	e8 2b c5 ff ff       	call   7c60 <fwp_drop0>
    b735:	48 c7 05 28 49 00 00 	movq   $0x0,0x4928(%rip)        # 10068 <v.2>
    b73c:	00 00 00 00 
    b740:	c7 05 26 49 00 00 01 	movl   $0x1,0x4926(%rip)        # 10070 <st.3>
    b747:	00 00 00 
    b74a:	e9 f7 e1 ff ff       	jmp    9946 <fwp_main_thread+0x146>
    b74f:	66 85 c0             	test   %ax,%ax
    b752:	0f 85 f9 e8 ff ff    	jne    a051 <fwp_main_thread+0x851>
    b758:	e9 e4 e8 ff ff       	jmp    a041 <fwp_main_thread+0x841>
    b75d:	66 85 c0             	test   %ax,%ax
    b760:	0f 85 41 ea ff ff    	jne    a1a7 <fwp_main_thread+0x9a7>
    b766:	e9 1e ea ff ff       	jmp    a189 <fwp_main_thread+0x989>
    b76b:	66 85 c0             	test   %ax,%ax
    b76e:	0f 85 7c e9 ff ff    	jne    a0f0 <fwp_main_thread+0x8f0>
    b774:	e9 67 e9 ff ff       	jmp    a0e0 <fwp_main_thread+0x8e0>
    b779:	4c 89 ef             	mov    %r13,%rdi
    b77c:	e8 8f 9d ff ff       	call   5510 <fwp_rc_forget_slot>
    b781:	e9 8b e7 ff ff       	jmp    9f11 <fwp_main_thread+0x711>
    b786:	4c 89 e2             	mov    %r12,%rdx
    b789:	48 c1 ea 11          	shr    $0x11,%rdx
    b78d:	4c 31 e2             	xor    %r12,%rdx
    b790:	48 89 d0             	mov    %rdx,%rax
    b793:	48 c1 e8 09          	shr    $0x9,%rax
    b797:	48 31 c2             	xor    %rax,%rdx
    b79a:	0f b6 d2             	movzbl %dl,%edx
    b79d:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b7a4:	00 
    b7a5:	48 85 c0             	test   %rax,%rax
    b7a8:	75 1f                	jne    b7c9 <fwp_main_thread+0x1fc9>
    b7aa:	eb 5a                	jmp    b806 <fwp_main_thread+0x2006>
    b7ac:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b7b3:	00 00 
    b7b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b7bc:	00 00 00 00 
    b7c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b7c4:	48 85 c0             	test   %rax,%rax
    b7c7:	74 3d                	je     b806 <fwp_main_thread+0x2006>
    b7c9:	48 89 c2             	mov    %rax,%rdx
    b7cc:	4c 39 20             	cmp    %r12,(%rax)
    b7cf:	75 ef                	jne    b7c0 <fwp_main_thread+0x1fc0>
    b7d1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b7d5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b7d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b7dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b7e4:	0f 85 96 f7 ff ff    	jne    af80 <fwp_main_thread+0x1780>
    b7ea:	4c 89 e7             	mov    %r12,%rdi
    b7ed:	e8 1e 9d ff ff       	call   5510 <fwp_rc_forget_slot>
    b7f2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b7f7:	e9 84 f7 ff ff       	jmp    af80 <fwp_main_thread+0x1780>
    b7fc:	e8 ef 9b ff ff       	call   53f0 <fwp_rc_wide_dup>
    b801:	e9 f2 ea ff ff       	jmp    a2f8 <fwp_main_thread+0xaf8>
    b806:	48 8d 3d 83 10 00 00 	lea    0x1083(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    b80d:	e8 9e 8b ff ff       	call   43b0 <fwp_trap>
    b812:	48 89 cf             	mov    %rcx,%rdi
    b815:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b81c:	00 
    b81d:	31 f6                	xor    %esi,%esi
    b81f:	49 89 de             	mov    %rbx,%r14
    b822:	e8 79 7c ff ff       	call   34a0 <memset@plt>
    b827:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b82b:	4d 29 e6             	sub    %r12,%r14
    b82e:	48 89 c1             	mov    %rax,%rcx
    b831:	e9 6f fc ff ff       	jmp    b4a5 <fwp_main_thread+0x1ca5>
    b836:	48 8b 3d 03 6c 01 00 	mov    0x16c03(%rip),%rdi        # 22440 <fwp_state>
    b83d:	e8 0e 9f ff ff       	call   5750 <fwp_mem_free>
    b842:	48 c7 05 f3 6b 01 00 	movq   $0x0,0x16bf3(%rip)        # 22440 <fwp_state>
    b849:	00 00 00 00 
    b84d:	48 c7 05 d8 6b 01 00 	movq   $0x0,0x16bd8(%rip)        # 22430 <fwp_state_cap>
    b854:	00 00 00 00 
    b858:	48 85 db             	test   %rbx,%rbx
    b85b:	0f 84 f1 00 00 00    	je     b952 <fwp_main_thread+0x2152>
    b861:	48 3b 1d 30 4f 01 00 	cmp    0x14f30(%rip),%rbx        # 20798 <fwp_root>
    b868:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b86f:	00 00 00 00 
    b873:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b87a:	00 00 00 00 
    b87e:	c7 05 f8 47 01 00 00 	movl   $0x0,0x147f8(%rip)        # 20080 <fwp_exit_code>
    b885:	00 00 00 
    b888:	0f 84 58 e2 ff ff    	je     9ae6 <fwp_main_thread+0x2e6>
    b88e:	e9 78 7e ff ff       	jmp    370b <fwp_main_thread.cold>
    b893:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b898:	48 89 d8             	mov    %rbx,%rax
    b89b:	48 c1 e8 11          	shr    $0x11,%rax
    b89f:	48 31 d8             	xor    %rbx,%rax
    b8a2:	48 89 c2             	mov    %rax,%rdx
    b8a5:	48 c1 ea 09          	shr    $0x9,%rdx
    b8a9:	48 31 d0             	xor    %rdx,%rax
    b8ac:	0f b6 d0             	movzbl %al,%edx
    b8af:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b8b6:	00 
    b8b7:	48 85 c0             	test   %rax,%rax
    b8ba:	75 31                	jne    b8ed <fwp_main_thread+0x20ed>
    b8bc:	e9 45 ff ff ff       	jmp    b806 <fwp_main_thread+0x2006>
    b8c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b8c8:	00 00 
    b8ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b8d1:	00 00 00 00 
    b8d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b8dc:	00 00 00 00 
    b8e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b8e4:	48 85 c0             	test   %rax,%rax
    b8e7:	0f 84 19 ff ff ff    	je     b806 <fwp_main_thread+0x2006>
    b8ed:	48 89 c2             	mov    %rax,%rdx
    b8f0:	48 3b 18             	cmp    (%rax),%rbx
    b8f3:	75 eb                	jne    b8e0 <fwp_main_thread+0x20e0>
    b8f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b8f9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b8fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b901:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b908:	0f 85 32 f8 ff ff    	jne    b140 <fwp_main_thread+0x1940>
    b90e:	48 89 df             	mov    %rbx,%rdi
    b911:	e8 fa 9b ff ff       	call   5510 <fwp_rc_forget_slot>
    b916:	c6 03 fe             	movb   $0xfe,(%rbx)
    b919:	e9 22 f8 ff ff       	jmp    b140 <fwp_main_thread+0x1940>
    b91e:	e8 cd 9a ff ff       	call   53f0 <fwp_rc_wide_dup>
    b923:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b92a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b931:	48 c1 e2 10          	shl    $0x10,%rdx
    b935:	e9 1a e9 ff ff       	jmp    a254 <fwp_main_thread+0xa54>
    b93a:	48 8d 3d 26 08 00 00 	lea    0x826(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    b941:	e8 6a 8a ff ff       	call   43b0 <fwp_trap>
    b946:	48 8d 3d 6b 0f 00 00 	lea    0xf6b(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    b94d:	e8 5e 8a ff ff       	call   43b0 <fwp_trap>
    b952:	48 83 3d 3e 4e 01 00 	cmpq   $0x0,0x14e3e(%rip)        # 20798 <fwp_root>
    b959:	00 
    b95a:	c7 05 1c 47 01 00 00 	movl   $0x0,0x1471c(%rip)        # 20080 <fwp_exit_code>
    b961:	00 00 00 
    b964:	0f 84 db e1 ff ff    	je     9b45 <fwp_main_thread+0x345>
    b96a:	e9 9c 7d ff ff       	jmp    370b <fwp_main_thread.cold>
    b96f:	90                   	nop
    b970:	4c 89 e7             	mov    %r12,%rdi
    b973:	e8 98 9b ff ff       	call   5510 <fwp_rc_forget_slot>
    b978:	e9 cf e6 ff ff       	jmp    a04c <fwp_main_thread+0x84c>
    b97d:	4c 89 e7             	mov    %r12,%rdi
    b980:	e8 8b 9b ff ff       	call   5510 <fwp_rc_forget_slot>
    b985:	e9 61 e7 ff ff       	jmp    a0eb <fwp_main_thread+0x8eb>
    b98a:	4c 89 e7             	mov    %r12,%rdi
    b98d:	e8 7e 9b ff ff       	call   5510 <fwp_rc_forget_slot>
    b992:	e9 fd e7 ff ff       	jmp    a194 <fwp_main_thread+0x994>
    b997:	48 8d 3d 1a 10 00 00 	lea    0x101a(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    b99e:	e8 0d 8a ff ff       	call   43b0 <fwp_trap>
    b9a3:	e8 18 7d ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    b9a8:	48 8d 3d 87 08 00 00 	lea    0x887(%rip),%rdi        # c236 <_IO_stdin_used+0x236>
    b9af:	e8 fc 89 ff ff       	call   43b0 <fwp_trap>
    b9b4:	48 8d 3d 61 08 00 00 	lea    0x861(%rip),%rdi        # c21c <_IO_stdin_used+0x21c>
    b9bb:	e8 f0 89 ff ff       	call   43b0 <fwp_trap>
    b9c0:	48 8d 3d c9 07 00 00 	lea    0x7c9(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    b9c7:	e8 e4 89 ff ff       	call   43b0 <fwp_trap>
    b9cc:	48 8d 3d b5 0f 00 00 	lea    0xfb5(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    b9d3:	e8 d8 89 ff ff       	call   43b0 <fwp_trap>
    b9d8:	48 8d 3d 81 0f 00 00 	lea    0xf81(%rip),%rdi        # c960 <_IO_stdin_used+0x960>
    b9df:	e8 cc 89 ff ff       	call   43b0 <fwp_trap>
    b9e4:	e8 57 7a ff ff       	call   3440 <__stack_chk_fail@plt>
    b9e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b9f0:	48 8d 3d e9 0f 00 00 	lea    0xfe9(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    b9f7:	e8 b4 89 ff ff       	call   43b0 <fwp_trap>
    b9fc:	48 8d 3d fd 0e 00 00 	lea    0xefd(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    ba03:	e8 a8 89 ff ff       	call   43b0 <fwp_trap>
    ba08:	e8 93 83 ff ff       	call   3da0 <descent_phase_fail>
    ba0d:	48 8d 3d 32 08 00 00 	lea    0x832(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    ba14:	e8 97 89 ff ff       	call   43b0 <fwp_trap>
    ba19:	e9 ed 7c ff ff       	jmp    370b <fwp_main_thread.cold>
    ba1e:	e9 e8 7c ff ff       	jmp    370b <fwp_main_thread.cold>
    ba23:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba2a:	00 00 00 
    ba2d:	0f 1f 00             	nopl   (%rax)

000000000000ba30 <__divmodti4>:
    ba30:	f3 0f 1e fa          	endbr64
    ba34:	55                   	push   %rbp
    ba35:	49 89 f1             	mov    %rsi,%r9
    ba38:	49 89 d2             	mov    %rdx,%r10
    ba3b:	48 89 fe             	mov    %rdi,%rsi
    ba3e:	49 89 cb             	mov    %rcx,%r11
    ba41:	48 89 e5             	mov    %rsp,%rbp
    ba44:	41 57                	push   %r15
    ba46:	41 56                	push   %r14
    ba48:	41 55                	push   %r13
    ba4a:	41 54                	push   %r12
    ba4c:	53                   	push   %rbx
    ba4d:	4c 89 c3             	mov    %r8,%rbx
    ba50:	45 31 c0             	xor    %r8d,%r8d
    ba53:	4d 85 c9             	test   %r9,%r9
    ba56:	79 12                	jns    ba6a <__divmodti4+0x3a>
    ba58:	31 ff                	xor    %edi,%edi
    ba5a:	48 f7 de             	neg    %rsi
    ba5d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    ba64:	4c 19 cf             	sbb    %r9,%rdi
    ba67:	49 89 f9             	mov    %rdi,%r9
    ba6a:	4c 89 d8             	mov    %r11,%rax
    ba6d:	4d 85 db             	test   %r11,%r11
    ba70:	0f 88 1a 01 00 00    	js     bb90 <__divmodti4+0x160>
    ba76:	4c 89 d9             	mov    %r11,%rcx
    ba79:	49 89 f3             	mov    %rsi,%r11
    ba7c:	75 62                	jne    bae0 <__divmodti4+0xb0>
    ba7e:	4d 89 c4             	mov    %r8,%r12
    ba81:	4d 39 d1             	cmp    %r10,%r9
    ba84:	0f 83 46 01 00 00    	jae    bbd0 <__divmodti4+0x1a0>
    ba8a:	4c 89 d8             	mov    %r11,%rax
    ba8d:	4c 89 ca             	mov    %r9,%rdx
    ba90:	49 f7 f2             	div    %r10
    ba93:	49 89 c3             	mov    %rax,%r11
    ba96:	31 c0                	xor    %eax,%eax
    ba98:	48 89 d6             	mov    %rdx,%rsi
    ba9b:	31 ff                	xor    %edi,%edi
    ba9d:	4c 89 d9             	mov    %r11,%rcx
    baa0:	48 89 c2             	mov    %rax,%rdx
    baa3:	48 89 c8             	mov    %rcx,%rax
    baa6:	4d 85 e4             	test   %r12,%r12
    baa9:	74 0a                	je     bab5 <__divmodti4+0x85>
    baab:	48 f7 d8             	neg    %rax
    baae:	48 83 d2 00          	adc    $0x0,%rdx
    bab2:	48 f7 da             	neg    %rdx
    bab5:	4d 85 c0             	test   %r8,%r8
    bab8:	74 0a                	je     bac4 <__divmodti4+0x94>
    baba:	48 f7 de             	neg    %rsi
    babd:	48 83 d7 00          	adc    $0x0,%rdi
    bac1:	48 f7 df             	neg    %rdi
    bac4:	48 89 33             	mov    %rsi,(%rbx)
    bac7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bacb:	5b                   	pop    %rbx
    bacc:	41 5c                	pop    %r12
    bace:	41 5d                	pop    %r13
    bad0:	41 5e                	pop    %r14
    bad2:	41 5f                	pop    %r15
    bad4:	5d                   	pop    %rbp
    bad5:	c3                   	ret
    bad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    badd:	00 00 00 
    bae0:	4d 89 c4             	mov    %r8,%r12
    bae3:	49 39 c1             	cmp    %rax,%r9
    bae6:	0f 82 ce 00 00 00    	jb     bbba <__divmodti4+0x18a>
    baec:	31 ff                	xor    %edi,%edi
    baee:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    baf3:	48 63 c7             	movslq %edi,%rax
    baf6:	be 40 00 00 00       	mov    $0x40,%esi
    bafb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bb00:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bb05:	48 29 c6             	sub    %rax,%rsi
    bb08:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bb0d:	48 09 c8             	or     %rcx,%rax
    bb10:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bb15:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bb1a:	49 89 c6             	mov    %rax,%r14
    bb1d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bb21:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bb26:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bb2b:	49 09 c1             	or     %rax,%r9
    bb2e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bb32:	4c 89 c8             	mov    %r9,%rax
    bb35:	49 f7 f6             	div    %r14
    bb38:	48 89 d1             	mov    %rdx,%rcx
    bb3b:	49 89 c3             	mov    %rax,%r11
    bb3e:	49 89 c1             	mov    %rax,%r9
    bb41:	49 f7 e2             	mul    %r10
    bb44:	49 89 c6             	mov    %rax,%r14
    bb47:	49 89 d2             	mov    %rdx,%r10
    bb4a:	48 39 d1             	cmp    %rdx,%rcx
    bb4d:	72 07                	jb     bb56 <__divmodti4+0x126>
    bb4f:	75 17                	jne    bb68 <__divmodti4+0x138>
    bb51:	49 39 c7             	cmp    %rax,%r15
    bb54:	73 12                	jae    bb68 <__divmodti4+0x138>
    bb56:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bb5a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bb5e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bb62:	49 89 d2             	mov    %rdx,%r10
    bb65:	49 89 c6             	mov    %rax,%r14
    bb68:	4c 89 f8             	mov    %r15,%rax
    bb6b:	4c 29 f0             	sub    %r14,%rax
    bb6e:	4c 19 d1             	sbb    %r10,%rcx
    bb71:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bb76:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bb7b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bb80:	48 09 c6             	or     %rax,%rsi
    bb83:	48 89 cf             	mov    %rcx,%rdi
    bb86:	31 c0                	xor    %eax,%eax
    bb88:	4c 89 c9             	mov    %r9,%rcx
    bb8b:	e9 10 ff ff ff       	jmp    baa0 <__divmodti4+0x70>
    bb90:	4c 89 d0             	mov    %r10,%rax
    bb93:	4c 89 da             	mov    %r11,%rdx
    bb96:	4d 89 c4             	mov    %r8,%r12
    bb99:	49 89 f3             	mov    %rsi,%r11
    bb9c:	48 f7 d8             	neg    %rax
    bb9f:	49 f7 d4             	not    %r12
    bba2:	48 83 d2 00          	adc    $0x0,%rdx
    bba6:	49 89 c2             	mov    %rax,%r10
    bba9:	48 f7 da             	neg    %rdx
    bbac:	48 89 d1             	mov    %rdx,%rcx
    bbaf:	0f 84 cc fe ff ff    	je     ba81 <__divmodti4+0x51>
    bbb5:	49 39 d1             	cmp    %rdx,%r9
    bbb8:	73 46                	jae    bc00 <__divmodti4+0x1d0>
    bbba:	4c 89 cf             	mov    %r9,%rdi
    bbbd:	31 c0                	xor    %eax,%eax
    bbbf:	31 c9                	xor    %ecx,%ecx
    bbc1:	e9 da fe ff ff       	jmp    baa0 <__divmodti4+0x70>
    bbc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bbcd:	00 00 00 
    bbd0:	4d 85 d2             	test   %r10,%r10
    bbd3:	75 0d                	jne    bbe2 <__divmodti4+0x1b2>
    bbd5:	b8 01 00 00 00       	mov    $0x1,%eax
    bbda:	31 d2                	xor    %edx,%edx
    bbdc:	49 f7 f2             	div    %r10
    bbdf:	49 89 c2             	mov    %rax,%r10
    bbe2:	4c 89 c8             	mov    %r9,%rax
    bbe5:	31 d2                	xor    %edx,%edx
    bbe7:	49 f7 f2             	div    %r10
    bbea:	49 89 c1             	mov    %rax,%r9
    bbed:	4c 89 d8             	mov    %r11,%rax
    bbf0:	49 f7 f2             	div    %r10
    bbf3:	49 89 c3             	mov    %rax,%r11
    bbf6:	4c 89 c8             	mov    %r9,%rax
    bbf9:	e9 9a fe ff ff       	jmp    ba98 <__divmodti4+0x68>
    bbfe:	66 90                	xchg   %ax,%ax
    bc00:	45 31 f6             	xor    %r14d,%r14d
    bc03:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bc08:	44 89 f7             	mov    %r14d,%edi
    bc0b:	45 85 f6             	test   %r14d,%r14d
    bc0e:	0f 85 df fe ff ff    	jne    baf3 <__divmodti4+0xc3>
    bc14:	4c 39 ca             	cmp    %r9,%rdx
    bc17:	72 17                	jb     bc30 <__divmodti4+0x200>
    bc19:	31 c9                	xor    %ecx,%ecx
    bc1b:	48 39 c6             	cmp    %rax,%rsi
    bc1e:	73 10                	jae    bc30 <__divmodti4+0x200>
    bc20:	4c 89 cf             	mov    %r9,%rdi
    bc23:	31 c0                	xor    %eax,%eax
    bc25:	e9 76 fe ff ff       	jmp    baa0 <__divmodti4+0x70>
    bc2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bc30:	4c 89 de             	mov    %r11,%rsi
    bc33:	b9 01 00 00 00       	mov    $0x1,%ecx
    bc38:	48 29 c6             	sub    %rax,%rsi
    bc3b:	49 19 d1             	sbb    %rdx,%r9
    bc3e:	eb e0                	jmp    bc20 <__divmodti4+0x1f0>

000000000000bc40 <atexit>:
    bc40:	f3 0f 1e fa          	endbr64
    bc44:	48 8b 15 bd 43 00 00 	mov    0x43bd(%rip),%rdx        # 10008 <__dso_handle>
    bc4b:	31 f6                	xor    %esi,%esi
    bc4d:	e9 ce 79 ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bc54 <_fini>:
    bc54:	f3 0f 1e fa          	endbr64
    bc58:	48 83 ec 08          	sub    $0x8,%rsp
    bc5c:	48 83 c4 08          	add    $0x8,%rsp
    bc60:	c3                   	ret
