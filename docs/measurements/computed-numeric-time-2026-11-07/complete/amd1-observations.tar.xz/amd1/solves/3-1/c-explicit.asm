
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/c-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 d9 2f 00 00 	mov    0x2fd9(%rip),%rax        # 3fe8 <__gmon_start__>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 72 2f 00 00    	push   0x2f72(%rip)        # 3f98 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 74 2f 00 00    	jmp    *0x2f74(%rip)        # 3fa0 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)
    1030:	f3 0f 1e fa          	endbr64
    1034:	68 00 00 00 00       	push   $0x0
    1039:	e9 e2 ff ff ff       	jmp    1020 <_init+0x20>
    103e:	66 90                	xchg   %ax,%ax
    1040:	f3 0f 1e fa          	endbr64
    1044:	68 01 00 00 00       	push   $0x1
    1049:	e9 d2 ff ff ff       	jmp    1020 <_init+0x20>
    104e:	66 90                	xchg   %ax,%ax
    1050:	f3 0f 1e fa          	endbr64
    1054:	68 02 00 00 00       	push   $0x2
    1059:	e9 c2 ff ff ff       	jmp    1020 <_init+0x20>
    105e:	66 90                	xchg   %ax,%ax
    1060:	f3 0f 1e fa          	endbr64
    1064:	68 03 00 00 00       	push   $0x3
    1069:	e9 b2 ff ff ff       	jmp    1020 <_init+0x20>
    106e:	66 90                	xchg   %ax,%ax
    1070:	f3 0f 1e fa          	endbr64
    1074:	68 04 00 00 00       	push   $0x4
    1079:	e9 a2 ff ff ff       	jmp    1020 <_init+0x20>
    107e:	66 90                	xchg   %ax,%ax
    1080:	f3 0f 1e fa          	endbr64
    1084:	68 05 00 00 00       	push   $0x5
    1089:	e9 92 ff ff ff       	jmp    1020 <_init+0x20>
    108e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000001090 <__cxa_finalize@plt>:
    1090:	f3 0f 1e fa          	endbr64
    1094:	ff 25 5e 2f 00 00    	jmp    *0x2f5e(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    109a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000010a0 <free@plt>:
    10a0:	f3 0f 1e fa          	endbr64
    10a4:	ff 25 fe 2e 00 00    	jmp    *0x2efe(%rip)        # 3fa8 <free@GLIBC_2.2.5>
    10aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010b0 <puts@plt>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	ff 25 f6 2e 00 00    	jmp    *0x2ef6(%rip)        # 3fb0 <puts@GLIBC_2.2.5>
    10ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010c0 <ferror@plt>:
    10c0:	f3 0f 1e fa          	endbr64
    10c4:	ff 25 ee 2e 00 00    	jmp    *0x2eee(%rip)        # 3fb8 <ferror@GLIBC_2.2.5>
    10ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010d0 <putc@plt>:
    10d0:	f3 0f 1e fa          	endbr64
    10d4:	ff 25 e6 2e 00 00    	jmp    *0x2ee6(%rip)        # 3fc0 <putc@GLIBC_2.2.5>
    10da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010e0 <malloc@plt>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	ff 25 de 2e 00 00    	jmp    *0x2ede(%rip)        # 3fc8 <malloc@GLIBC_2.2.5>
    10ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010f0 <__printf_chk@plt>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	ff 25 d6 2e 00 00    	jmp    *0x2ed6(%rip)        # 3fd0 <__printf_chk@GLIBC_2.3.4>
    10fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000001100 <main>:
    1100:	f3 0f 1e fa          	endbr64
    1104:	41 55                	push   %r13
    1106:	49 bd 51 b8 1e 85 eb 	movabs $0xbfe851eb851eb851,%r13
    110d:	51 e8 bf 
    1110:	41 54                	push   %r12
    1112:	41 bc 00 02 00 00    	mov    $0x200,%r12d
    1118:	55                   	push   %rbp
    1119:	53                   	push   %rbx
    111a:	48 83 ec 08          	sub    $0x8,%rsp
    111e:	eb 0a                	jmp    112a <main+0x2a>
    1120:	49 83 ec 01          	sub    $0x1,%r12
    1124:	0f 84 dd 00 00 00    	je     1207 <main+0x107>
    112a:	bf 18 00 00 00       	mov    $0x18,%edi
    112f:	e8 ac ff ff ff       	call   10e0 <malloc@plt>
    1134:	bf 18 00 00 00       	mov    $0x18,%edi
    1139:	48 89 c3             	mov    %rax,%rbx
    113c:	e8 9f ff ff ff       	call   10e0 <malloc@plt>
    1141:	48 89 c5             	mov    %rax,%rbp
    1144:	48 85 db             	test   %rbx,%rbx
    1147:	0f 84 c5 00 00 00    	je     1212 <main+0x112>
    114d:	48 85 c0             	test   %rax,%rax
    1150:	0f 84 bc 00 00 00    	je     1212 <main+0x112>
    1156:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    115a:	66 0f 28 0d ae 0e 00 	movapd 0xeae(%rip),%xmm1        # 2010 <_IO_stdin_used+0x10>
    1161:	00 
    1162:	bf 5b 00 00 00       	mov    $0x5b,%edi
    1167:	66 0f 28 15 b1 0e 00 	movapd 0xeb1(%rip),%xmm2        # 2020 <_IO_stdin_used+0x20>
    116e:	00 
    116f:	48 8b 35 9a 2e 00 00 	mov    0x2e9a(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    1176:	0f 11 48 08          	movups %xmm1,0x8(%rax)
    117a:	0f 11 13             	movups %xmm2,(%rbx)
    117d:	e8 4e ff ff ff       	call   10d0 <putc@plt>
    1182:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    1186:	bf 02 00 00 00       	mov    $0x2,%edi
    118b:	48 8d 35 74 0e 00 00 	lea    0xe74(%rip),%rsi        # 2006 <_IO_stdin_used+0x6>
    1192:	b8 01 00 00 00       	mov    $0x1,%eax
    1197:	e8 54 ff ff ff       	call   10f0 <__printf_chk@plt>
    119c:	f2 0f 10 43 08       	movsd  0x8(%rbx),%xmm0
    11a1:	bf 02 00 00 00       	mov    $0x2,%edi
    11a6:	48 8d 35 57 0e 00 00 	lea    0xe57(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    11ad:	b8 01 00 00 00       	mov    $0x1,%eax
    11b2:	e8 39 ff ff ff       	call   10f0 <__printf_chk@plt>
    11b7:	f2 0f 10 43 10       	movsd  0x10(%rbx),%xmm0
    11bc:	bf 02 00 00 00       	mov    $0x2,%edi
    11c1:	48 8d 35 3c 0e 00 00 	lea    0xe3c(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    11c8:	b8 01 00 00 00       	mov    $0x1,%eax
    11cd:	e8 1e ff ff ff       	call   10f0 <__printf_chk@plt>
    11d2:	48 8d 3d 33 0e 00 00 	lea    0xe33(%rip),%rdi        # 200c <_IO_stdin_used+0xc>
    11d9:	e8 d2 fe ff ff       	call   10b0 <puts@plt>
    11de:	48 89 df             	mov    %rbx,%rdi
    11e1:	e8 ba fe ff ff       	call   10a0 <free@plt>
    11e6:	48 89 ef             	mov    %rbp,%rdi
    11e9:	e8 b2 fe ff ff       	call   10a0 <free@plt>
    11ee:	48 8b 3d 1b 2e 00 00 	mov    0x2e1b(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    11f5:	e8 c6 fe ff ff       	call   10c0 <ferror@plt>
    11fa:	85 c0                	test   %eax,%eax
    11fc:	0f 84 1e ff ff ff    	je     1120 <main+0x20>
    1202:	b8 04 00 00 00       	mov    $0x4,%eax
    1207:	48 83 c4 08          	add    $0x8,%rsp
    120b:	5b                   	pop    %rbx
    120c:	5d                   	pop    %rbp
    120d:	41 5c                	pop    %r12
    120f:	41 5d                	pop    %r13
    1211:	c3                   	ret
    1212:	48 89 df             	mov    %rbx,%rdi
    1215:	e8 86 fe ff ff       	call   10a0 <free@plt>
    121a:	48 89 ef             	mov    %rbp,%rdi
    121d:	e8 7e fe ff ff       	call   10a0 <free@plt>
    1222:	b8 02 00 00 00       	mov    $0x2,%eax
    1227:	eb de                	jmp    1207 <main+0x107>
    1229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001230 <_start>:
    1230:	f3 0f 1e fa          	endbr64
    1234:	31 ed                	xor    %ebp,%ebp
    1236:	49 89 d1             	mov    %rdx,%r9
    1239:	5e                   	pop    %rsi
    123a:	48 89 e2             	mov    %rsp,%rdx
    123d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1241:	50                   	push   %rax
    1242:	54                   	push   %rsp
    1243:	45 31 c0             	xor    %r8d,%r8d
    1246:	31 c9                	xor    %ecx,%ecx
    1248:	48 8d 3d b1 fe ff ff 	lea    -0x14f(%rip),%rdi        # 1100 <main>
    124f:	ff 15 83 2d 00 00    	call   *0x2d83(%rip)        # 3fd8 <__libc_start_main@GLIBC_2.34>
    1255:	f4                   	hlt
    1256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    125d:	00 00 00 

0000000000001260 <deregister_tm_clones>:
    1260:	48 8d 3d a9 2d 00 00 	lea    0x2da9(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1267:	48 8d 05 a2 2d 00 00 	lea    0x2da2(%rip),%rax        # 4010 <stdout@GLIBC_2.2.5>
    126e:	48 39 f8             	cmp    %rdi,%rax
    1271:	74 15                	je     1288 <deregister_tm_clones+0x28>
    1273:	48 8b 05 66 2d 00 00 	mov    0x2d66(%rip),%rax        # 3fe0 <_ITM_deregisterTMCloneTable>
    127a:	48 85 c0             	test   %rax,%rax
    127d:	74 09                	je     1288 <deregister_tm_clones+0x28>
    127f:	ff e0                	jmp    *%rax
    1281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1288:	c3                   	ret
    1289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001290 <register_tm_clones>:
    1290:	48 8d 3d 79 2d 00 00 	lea    0x2d79(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1297:	48 8d 35 72 2d 00 00 	lea    0x2d72(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    129e:	48 29 fe             	sub    %rdi,%rsi
    12a1:	48 89 f0             	mov    %rsi,%rax
    12a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    12a8:	48 c1 f8 03          	sar    $0x3,%rax
    12ac:	48 01 c6             	add    %rax,%rsi
    12af:	48 d1 fe             	sar    $1,%rsi
    12b2:	74 14                	je     12c8 <register_tm_clones+0x38>
    12b4:	48 8b 05 35 2d 00 00 	mov    0x2d35(%rip),%rax        # 3ff0 <_ITM_registerTMCloneTable>
    12bb:	48 85 c0             	test   %rax,%rax
    12be:	74 08                	je     12c8 <register_tm_clones+0x38>
    12c0:	ff e0                	jmp    *%rax
    12c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    12c8:	c3                   	ret
    12c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000012d0 <__do_global_dtors_aux>:
    12d0:	f3 0f 1e fa          	endbr64
    12d4:	80 3d 3d 2d 00 00 00 	cmpb   $0x0,0x2d3d(%rip)        # 4018 <completed.0>
    12db:	75 2b                	jne    1308 <__do_global_dtors_aux+0x38>
    12dd:	55                   	push   %rbp
    12de:	48 83 3d 12 2d 00 00 	cmpq   $0x0,0x2d12(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    12e5:	00 
    12e6:	48 89 e5             	mov    %rsp,%rbp
    12e9:	74 0c                	je     12f7 <__do_global_dtors_aux+0x27>
    12eb:	48 8b 3d 16 2d 00 00 	mov    0x2d16(%rip),%rdi        # 4008 <__dso_handle>
    12f2:	e8 99 fd ff ff       	call   1090 <__cxa_finalize@plt>
    12f7:	e8 64 ff ff ff       	call   1260 <deregister_tm_clones>
    12fc:	c6 05 15 2d 00 00 01 	movb   $0x1,0x2d15(%rip)        # 4018 <completed.0>
    1303:	5d                   	pop    %rbp
    1304:	c3                   	ret
    1305:	0f 1f 00             	nopl   (%rax)
    1308:	c3                   	ret
    1309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001310 <frame_dummy>:
    1310:	f3 0f 1e fa          	endbr64
    1314:	e9 77 ff ff ff       	jmp    1290 <register_tm_clones>

Disassembly of section .fini:

000000000000131c <_fini>:
    131c:	f3 0f 1e fa          	endbr64
    1320:	48 83 ec 08          	sub    $0x8,%rsp
    1324:	48 83 c4 08          	add    $0x8,%rsp
    1328:	c3                   	ret
