
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-explicit-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d1 9f 00 00 	mov    0x9fd1(%rip),%rax        # bfe0 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 fa 9d 00 00    	push   0x9dfa(%rip)        # be20 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 fc 9d 00 00    	jmp    *0x9dfc(%rip)        # be28 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 76 9c 00 00    	jmp    *0x9c76(%rip)        # bff0 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 a6 9a 00 00    	jmp    *0x9aa6(%rip)        # be30 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 9e 9a 00 00    	jmp    *0x9a9e(%rip)        # be38 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 96 9a 00 00    	jmp    *0x9a96(%rip)        # be40 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 8e 9a 00 00    	jmp    *0x9a8e(%rip)        # be48 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 86 9a 00 00    	jmp    *0x9a86(%rip)        # be50 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 7e 9a 00 00    	jmp    *0x9a7e(%rip)        # be58 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 76 9a 00 00    	jmp    *0x9a76(%rip)        # be60 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 6e 9a 00 00    	jmp    *0x9a6e(%rip)        # be68 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 66 9a 00 00    	jmp    *0x9a66(%rip)        # be70 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 5e 9a 00 00    	jmp    *0x9a5e(%rip)        # be78 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 56 9a 00 00    	jmp    *0x9a56(%rip)        # be80 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 4e 9a 00 00    	jmp    *0x9a4e(%rip)        # be88 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 46 9a 00 00    	jmp    *0x9a46(%rip)        # be90 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 3e 9a 00 00    	jmp    *0x9a3e(%rip)        # be98 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 36 9a 00 00    	jmp    *0x9a36(%rip)        # bea0 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 2e 9a 00 00    	jmp    *0x9a2e(%rip)        # bea8 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 26 9a 00 00    	jmp    *0x9a26(%rip)        # beb0 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 1e 9a 00 00    	jmp    *0x9a1e(%rip)        # beb8 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 16 9a 00 00    	jmp    *0x9a16(%rip)        # bec0 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 0e 9a 00 00    	jmp    *0x9a0e(%rip)        # bec8 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 06 9a 00 00    	jmp    *0x9a06(%rip)        # bed0 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 fe 99 00 00    	jmp    *0x99fe(%rip)        # bed8 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 f6 99 00 00    	jmp    *0x99f6(%rip)        # bee0 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 ee 99 00 00    	jmp    *0x99ee(%rip)        # bee8 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 e6 99 00 00    	jmp    *0x99e6(%rip)        # bef0 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 de 99 00 00    	jmp    *0x99de(%rip)        # bef8 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 d6 99 00 00    	jmp    *0x99d6(%rip)        # bf00 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 ce 99 00 00    	jmp    *0x99ce(%rip)        # bf08 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 c6 99 00 00    	jmp    *0x99c6(%rip)        # bf10 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 be 99 00 00    	jmp    *0x99be(%rip)        # bf18 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 b6 99 00 00    	jmp    *0x99b6(%rip)        # bf20 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 ae 99 00 00    	jmp    *0x99ae(%rip)        # bf28 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 a6 99 00 00    	jmp    *0x99a6(%rip)        # bf30 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 9e 99 00 00    	jmp    *0x999e(%rip)        # bf38 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 96 99 00 00    	jmp    *0x9996(%rip)        # bf40 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 8e 99 00 00    	jmp    *0x998e(%rip)        # bf48 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 86 99 00 00    	jmp    *0x9986(%rip)        # bf50 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 7e 99 00 00    	jmp    *0x997e(%rip)        # bf58 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 76 99 00 00    	jmp    *0x9976(%rip)        # bf60 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 6e 99 00 00    	jmp    *0x996e(%rip)        # bf68 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 66 99 00 00    	jmp    *0x9966(%rip)        # bf70 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 5e 99 00 00    	jmp    *0x995e(%rip)        # bf78 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 56 99 00 00    	jmp    *0x9956(%rip)        # bf80 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 4e 99 00 00    	jmp    *0x994e(%rip)        # bf88 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 46 99 00 00    	jmp    *0x9946(%rip)        # bf90 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 3e 99 00 00    	jmp    *0x993e(%rip)        # bf98 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 36 99 00 00    	jmp    *0x9936(%rip)        # bfa0 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 2e 99 00 00    	jmp    *0x992e(%rip)        # bfa8 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 26 99 00 00    	jmp    *0x9926(%rip)        # bfb0 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 1e 99 00 00    	jmp    *0x991e(%rip)        # bfb8 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 16 99 00 00    	jmp    *0x9916(%rip)        # bfc0 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 0e 99 00 00    	jmp    *0x990e(%rip)        # bfc8 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 69 00 00 	lea    0x69e0(%rip),%r9        # 90b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 69 00 00 	lea    0x69dd(%rip),%r8        # 90bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 6a 0b 00 00       	call   3270 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_main_thread.cold>:
    270b:	e8 a0 fc ff ff       	call   23b0 <abort@plt>

0000000000002710 <main.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>
    2715:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    271c:	00 00 00 
    271f:	90                   	nop

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 98 00 00 	mov    0x98e1(%rip),%rax        # c020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 12 bc 01 00 	mov    %rax,0x1bc12(%rip)        # 1e358 <fwp_prog_out>
    2746:	e8 55 0b 00 00       	call   32a0 <fwp_now_ns>
    274b:	48 8d 3d 75 6a 00 00 	lea    0x6a75(%rip),%rdi        # 91c7 <_IO_stdin_used+0x1c7>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 98 00 00 	mov    0x9866(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 ed 5b 00 00 	lea    0x5bed(%rip),%rdx        # 8400 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e4 fe ff ff    	jne    2710 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 c8 fe ff ff    	jne    2710 <main.cold>
    2848:	48 8b 3d d1 97 00 00 	mov    0x97d1(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 98 01 00    	mov    0x19826(%rip),%eax        # 1c080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 25 69 00 00 	lea    0x6925(%rip),%rdi        # 91d0 <_IO_stdin_used+0x1d0>
    28ab:	e8 c0 09 00 00       	call   3270 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 7c 6c 00 00 	lea    0x6c7c(%rip),%rdi        # 9538 <_IO_stdin_used+0x538>
    28bc:	e8 af 09 00 00       	call   3270 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 3d fe ff ff    	jne    2710 <main.cold>
    28d3:	48 8d 3d 36 6c 00 00 	lea    0x6c36(%rip),%rdi        # 9510 <_IO_stdin_used+0x510>
    28da:	e8 91 09 00 00       	call   3270 <fwp_trap>
    28df:	48 8d 3d fa 6b 00 00 	lea    0x6bfa(%rip),%rdi        # 94e0 <_IO_stdin_used+0x4e0>
    28e6:	e8 85 09 00 00       	call   3270 <fwp_trap>
    28eb:	48 8d 3d c6 6b 00 00 	lea    0x6bc6(%rip),%rdi        # 94b8 <_IO_stdin_used+0x4b8>
    28f2:	e8 79 09 00 00       	call   3270 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 ab 96 00 00    	call   *0x96ab(%rip)        # bfd0 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 96 00 00 	lea    0x96e1(%rip),%rdi        # c018 <__TMC_END__>
    2937:	48 8d 05 da 96 00 00 	lea    0x96da(%rip),%rax        # c018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 8e 96 00 00 	mov    0x968e(%rip),%rax        # bfd8 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 96 00 00 	lea    0x96b1(%rip),%rdi        # c018 <__TMC_END__>
    2967:	48 8d 35 aa 96 00 00 	lea    0x96aa(%rip),%rsi        # c018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 5d 96 00 00 	mov    0x965d(%rip),%rax        # bfe8 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d 96 00 00 00 	cmpb   $0x0,0x969d(%rip)        # c048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 3a 96 00 00 	cmpq   $0x0,0x963a(%rip)        # bff0 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 96 00 00 	mov    0x9646(%rip),%rdi        # c008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 96 00 00 01 	movb   $0x1,0x9675(%rip)        # c048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_owned_entry32>:
    2bc0:	f3 0f 1e fa          	endbr64
    2bc4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bc9:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    2bcd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2bd2:	c3                   	ret
    2bd3:	66 90                	xchg   %ax,%ax
    2bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bdc:	00 00 00 00 

0000000000002be0 <fwp_args32>:
    2be0:	f3 0f 1e fa          	endbr64
    2be4:	c3                   	ret
    2be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bec:	00 00 00 00 

0000000000002bf0 <fwp_owned_entry45>:
    2bf0:	f3 0f 1e fa          	endbr64
    2bf4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bf9:	f2 0f 58 07          	addsd  (%rdi),%xmm0
    2bfd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c02:	c3                   	ret
    2c03:	66 90                	xchg   %ax,%ax
    2c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c0c:	00 00 00 00 

0000000000002c10 <fwp_owned_entry69>:
    2c10:	f3 0f 1e fa          	endbr64
    2c14:	f2 0f 10 05 d4 69 00 	movsd  0x69d4(%rip),%xmm0        # 95f0 <msg.3+0x20>
    2c1b:	00 
    2c1c:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    2c20:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c25:	c3                   	ret
    2c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2c2d:	00 00 00 

0000000000002c30 <fwp_flush>:
    2c30:	48 8b 3d 21 b7 01 00 	mov    0x1b721(%rip),%rdi        # 1e358 <fwp_prog_out>
    2c37:	48 85 ff             	test   %rdi,%rdi
    2c3a:	74 1c                	je     2c58 <fwp_flush+0x28>
    2c3c:	48 83 ec 08          	sub    $0x8,%rsp
    2c40:	e8 4b f9 ff ff       	call   2590 <fflush@plt>
    2c45:	48 8b 3d d4 93 00 00 	mov    0x93d4(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    2c4c:	48 83 c4 08          	add    $0x8,%rsp
    2c50:	e9 3b f9 ff ff       	jmp    2590 <fflush@plt>
    2c55:	0f 1f 00             	nopl   (%rax)
    2c58:	48 8b 3d c1 93 00 00 	mov    0x93c1(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    2c5f:	e9 2c f9 ff ff       	jmp    2590 <fflush@plt>
    2c64:	90                   	nop
    2c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c6c:	00 00 00 00 

0000000000002c70 <fwp_segv>:
    2c70:	f3 0f 1e fa          	endbr64
    2c74:	48 83 ec 28          	sub    $0x28,%rsp
    2c78:	48 8b 05 61 9a 01 00 	mov    0x19a61(%rip),%rax        # 1c6e0 <fwp_cur>
    2c7f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c83:	41 89 f8             	mov    %edi,%r8d
    2c86:	48 85 c0             	test   %rax,%rax
    2c89:	74 6d                	je     2cf8 <fwp_segv+0x88>
    2c8b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c8f:	48 85 d2             	test   %rdx,%rdx
    2c92:	74 64                	je     2cf8 <fwp_segv+0x88>
    2c94:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c98:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c9d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2ca2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2ca7:	e8 54 f9 ff ff       	call   2600 <sysconf@plt>
    2cac:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cb1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2cb6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2cbb:	48 01 d0             	add    %rdx,%rax
    2cbe:	48 39 c1             	cmp    %rax,%rcx
    2cc1:	b8 00 00 00 00       	mov    $0x0,%eax
    2cc6:	40 0f 92 c6          	setb   %sil
    2cca:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2cd1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2cd5:	31 c0                	xor    %eax,%eax
    2cd7:	48 39 d1             	cmp    %rdx,%rcx
    2cda:	0f 93 c0             	setae  %al
    2cdd:	21 f0                	and    %esi,%eax
    2cdf:	85 c0                	test   %eax,%eax
    2ce1:	75 4a                	jne    2d2d <fwp_segv+0xbd>
    2ce3:	31 f6                	xor    %esi,%esi
    2ce5:	44 89 c7             	mov    %r8d,%edi
    2ce8:	48 83 c4 28          	add    $0x28,%rsp
    2cec:	e9 2f f8 ff ff       	jmp    2520 <signal@plt>
    2cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cf8:	48 8b 05 99 93 01 00 	mov    0x19399(%rip),%rax        # 1c098 <fwp_main_stack_top>
    2cff:	48 85 c0             	test   %rax,%rax
    2d02:	74 df                	je     2ce3 <fwp_segv+0x73>
    2d04:	48 2b 05 85 93 01 00 	sub    0x19385(%rip),%rax        # 1c090 <fwp_main_stack_size>
    2d0b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2d12:	48 39 d1             	cmp    %rdx,%rcx
    2d15:	0f 93 c2             	setae  %dl
    2d18:	48 05 00 00 10 00    	add    $0x100000,%rax
    2d1e:	48 39 c1             	cmp    %rax,%rcx
    2d21:	0f 92 c0             	setb   %al
    2d24:	0f b6 c0             	movzbl %al,%eax
    2d27:	21 d0                	and    %edx,%eax
    2d29:	85 c0                	test   %eax,%eax
    2d2b:	74 b6                	je     2ce3 <fwp_segv+0x73>
    2d2d:	e8 fe fe ff ff       	call   2c30 <fwp_flush>
    2d32:	bf 02 00 00 00       	mov    $0x2,%edi
    2d37:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d3c:	48 8d 35 8d 68 00 00 	lea    0x688d(%rip),%rsi        # 95d0 <msg.3>
    2d43:	e8 c8 f6 ff ff       	call   2410 <write@plt>
    2d48:	bf 65 00 00 00       	mov    $0x65,%edi
    2d4d:	e8 6e f6 ff ff       	call   23c0 <_exit@plt>
    2d52:	0f 1f 00             	nopl   (%rax)
    2d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d5c:	00 00 00 00 

0000000000002d60 <fwp_heap_oom>:
    2d60:	50                   	push   %rax
    2d61:	58                   	pop    %rax
    2d62:	ba 13 00 00 00       	mov    $0x13,%edx
    2d67:	be 01 00 00 00       	mov    $0x1,%esi
    2d6c:	48 8d 3d 95 62 00 00 	lea    0x6295(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    2d73:	48 83 ec 08          	sub    $0x8,%rsp
    2d77:	48 8b 0d c2 92 00 00 	mov    0x92c2(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    2d7e:	e8 bd f8 ff ff       	call   2640 <fwrite@plt>
    2d83:	31 ff                	xor    %edi,%edi
    2d85:	e8 06 f8 ff ff       	call   2590 <fflush@plt>
    2d8a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d8f:	e8 cc f8 ff ff       	call   2660 <_Exit@plt>
    2d94:	90                   	nop
    2d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d9c:	00 00 00 00 

0000000000002da0 <fwp_heap_chunks>:
    2da0:	41 54                	push   %r12
    2da2:	55                   	push   %rbp
    2da3:	53                   	push   %rbx
    2da4:	48 83 ff 01          	cmp    $0x1,%rdi
    2da8:	0f 84 62 01 00 00    	je     2f10 <fwp_heap_chunks+0x170>
    2dae:	48 8b 05 3b ad 01 00 	mov    0x1ad3b(%rip),%rax        # 1daf0 <fwp_heap+0x13f0>
    2db5:	4c 8d 05 34 ad 01 00 	lea    0x1ad34(%rip),%r8        # 1daf0 <fwp_heap+0x13f0>
    2dbc:	48 8b 1d 15 ad 01 00 	mov    0x1ad15(%rip),%rbx        # 1dad8 <fwp_heap+0x13d8>
    2dc3:	48 39 d8             	cmp    %rbx,%rax
    2dc6:	0f 83 57 01 00 00    	jae    2f23 <fwp_heap_chunks+0x183>
    2dcc:	48 8b 0d 25 ad 01 00 	mov    0x1ad25(%rip),%rcx        # 1daf8 <fwp_heap+0x13f8>
    2dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2dd7:	31 f6                	xor    %esi,%esi
    2dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2ddd:	eb 1e                	jmp    2dfd <fwp_heap_chunks+0x5d>
    2ddf:	90                   	nop
    2de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2de4:	48 39 cf             	cmp    %rcx,%rdi
    2de7:	0f 84 03 01 00 00    	je     2ef0 <fwp_heap_chunks+0x150>
    2ded:	48 83 c0 01          	add    $0x1,%rax
    2df1:	48 89 ce             	mov    %rcx,%rsi
    2df4:	48 83 c2 28          	add    $0x28,%rdx
    2df8:	48 39 c3             	cmp    %rax,%rbx
    2dfb:	74 14                	je     2e11 <fwp_heap_chunks+0x71>
    2dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    2e00:	74 de                	je     2de0 <fwp_heap_chunks+0x40>
    2e02:	48 83 c0 01          	add    $0x1,%rax
    2e06:	31 f6                	xor    %esi,%esi
    2e08:	48 83 c2 28          	add    $0x28,%rdx
    2e0c:	48 39 c3             	cmp    %rax,%rbx
    2e0f:	75 ec                	jne    2dfd <fwp_heap_chunks+0x5d>
    2e11:	48 29 f3             	sub    %rsi,%rbx
    2e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2e18:	48 8b 3d c1 ac 01 00 	mov    0x1acc1(%rip),%rdi        # 1dae0 <fwp_heap+0x13e0>
    2e1f:	48 29 35 0a ad 01 00 	sub    %rsi,0x1ad0a(%rip)        # 1db30 <fwp_heap+0x1430>
    2e26:	48 39 ef             	cmp    %rbp,%rdi
    2e29:	0f 83 96 00 00 00    	jae    2ec5 <fwp_heap_chunks+0x125>
    2e2f:	48 8b 05 9a ac 01 00 	mov    0x1ac9a(%rip),%rax        # 1dad0 <fwp_heap+0x13d0>
    2e36:	48 39 e8             	cmp    %rbp,%rax
    2e39:	0f 82 eb 00 00 00    	jb     2f2a <fwp_heap_chunks+0x18a>
    2e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2e43:	ba 03 00 00 00       	mov    $0x3,%edx
    2e48:	49 39 c4             	cmp    %rax,%r12
    2e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    2e4f:	4c 89 e6             	mov    %r12,%rsi
    2e52:	48 29 fe             	sub    %rdi,%rsi
    2e55:	48 c1 e7 10          	shl    $0x10,%rdi
    2e59:	48 03 3d 50 ac 01 00 	add    0x1ac50(%rip),%rdi        # 1dab0 <fwp_heap+0x13b0>
    2e60:	48 c1 e6 10          	shl    $0x10,%rsi
    2e64:	e8 77 f7 ff ff       	call   25e0 <mprotect@plt>
    2e69:	85 c0                	test   %eax,%eax
    2e6b:	0f 85 b9 00 00 00    	jne    2f2a <fwp_heap_chunks+0x18a>
    2e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e76:	e8 85 f7 ff ff       	call   2600 <sysconf@plt>
    2e7b:	48 8b 35 5e ac 01 00 	mov    0x1ac5e(%rip),%rsi        # 1dae0 <fwp_heap+0x13e0>
    2e82:	48 89 c1             	mov    %rax,%rcx
    2e85:	48 8b 05 6c ac 01 00 	mov    0x1ac6c(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    2e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e90:	48 89 ca             	mov    %rcx,%rdx
    2e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e9b:	48 f7 da             	neg    %rdx
    2e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2ea3:	48 21 d7             	and    %rdx,%rdi
    2ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2eaa:	48 21 d6             	and    %rdx,%rsi
    2ead:	ba 03 00 00 00       	mov    $0x3,%edx
    2eb2:	48 29 fe             	sub    %rdi,%rsi
    2eb5:	e8 26 f7 ff ff       	call   25e0 <mprotect@plt>
    2eba:	85 c0                	test   %eax,%eax
    2ebc:	75 6c                	jne    2f2a <fwp_heap_chunks+0x18a>
    2ebe:	4c 89 25 1b ac 01 00 	mov    %r12,0x1ac1b(%rip)        # 1dae0 <fwp_heap+0x13e0>
    2ec5:	48 89 ef             	mov    %rbp,%rdi
    2ec8:	48 89 2d 09 ac 01 00 	mov    %rbp,0x1ac09(%rip)        # 1dad8 <fwp_heap+0x13d8>
    2ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    2ed3:	48 39 3d ee ab 01 00 	cmp    %rdi,0x1abee(%rip)        # 1dac8 <fwp_heap+0x13c8>
    2eda:	73 07                	jae    2ee3 <fwp_heap_chunks+0x143>
    2edc:	48 89 3d e5 ab 01 00 	mov    %rdi,0x1abe5(%rip)        # 1dac8 <fwp_heap+0x13c8>
    2ee3:	48 89 d8             	mov    %rbx,%rax
    2ee6:	5b                   	pop    %rbx
    2ee7:	5d                   	pop    %rbp
    2ee8:	41 5c                	pop    %r12
    2eea:	c3                   	ret
    2eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2ef4:	48 29 f0             	sub    %rsi,%rax
    2ef7:	48 89 c3             	mov    %rax,%rbx
    2efa:	49 89 10             	mov    %rdx,(%r8)
    2efd:	48 89 d8             	mov    %rbx,%rax
    2f00:	48 29 3d 29 ac 01 00 	sub    %rdi,0x1ac29(%rip)        # 1db30 <fwp_heap+0x1430>
    2f07:	5b                   	pop    %rbx
    2f08:	5d                   	pop    %rbp
    2f09:	41 5c                	pop    %r12
    2f0b:	c3                   	ret
    2f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    2f10:	48 8b 05 d1 ab 01 00 	mov    0x1abd1(%rip),%rax        # 1dae8 <fwp_heap+0x13e8>
    2f17:	4c 8d 05 ca ab 01 00 	lea    0x1abca(%rip),%r8        # 1dae8 <fwp_heap+0x13e8>
    2f1e:	e9 99 fe ff ff       	jmp    2dbc <fwp_heap_chunks+0x1c>
    2f23:	31 f6                	xor    %esi,%esi
    2f25:	e9 ea fe ff ff       	jmp    2e14 <fwp_heap_chunks+0x74>
    2f2a:	e8 31 fe ff ff       	call   2d60 <fwp_heap_oom>
    2f2f:	90                   	nop

0000000000002f30 <ad_raw_fail>:
    2f30:	50                   	push   %rax
    2f31:	58                   	pop    %rax
    2f32:	48 8d 15 bf 62 00 00 	lea    0x62bf(%rip),%rdx        # 91f8 <_IO_stdin_used+0x1f8>
    2f39:	be 02 00 00 00       	mov    $0x2,%esi
    2f3e:	31 c0                	xor    %eax,%eax
    2f40:	48 83 ec 08          	sub    $0x8,%rsp
    2f44:	48 89 f9             	mov    %rdi,%rcx
    2f47:	48 8b 3d f2 90 00 00 	mov    0x90f2(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    2f4e:	e8 fd f6 ff ff       	call   2650 <__fprintf_chk@plt>
    2f53:	bf e8 00 00 00       	mov    $0xe8,%edi
    2f58:	e8 d3 f6 ff ff       	call   2630 <exit@plt>
    2f5d:	0f 1f 00             	nopl   (%rax)

0000000000002f60 <buf_grow>:
    2f60:	48 83 ec 18          	sub    $0x18,%rsp
    2f64:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2f68:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2f6c:	74 7e                	je     2fec <buf_grow+0x8c>
    2f6e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f75:	48 29 c2             	sub    %rax,%rdx
    2f78:	48 39 f2             	cmp    %rsi,%rdx
    2f7b:	72 6f                	jb     2fec <buf_grow+0x8c>
    2f7d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f82:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f86:	48 89 f9             	mov    %rdi,%rcx
    2f89:	48 39 d0             	cmp    %rdx,%rax
    2f8c:	73 48                	jae    2fd6 <buf_grow+0x76>
    2f8e:	48 85 c0             	test   %rax,%rax
    2f91:	75 15                	jne    2fa8 <buf_grow+0x48>
    2f93:	48 83 fa 40          	cmp    $0x40,%rdx
    2f97:	76 4c                	jbe    2fe5 <buf_grow+0x85>
    2f99:	b8 40 00 00 00       	mov    $0x40,%eax
    2f9e:	eb 08                	jmp    2fa8 <buf_grow+0x48>
    2fa0:	48 01 c0             	add    %rax,%rax
    2fa3:	48 39 d0             	cmp    %rdx,%rax
    2fa6:	73 38                	jae    2fe0 <buf_grow+0x80>
    2fa8:	48 85 c0             	test   %rax,%rax
    2fab:	79 f3                	jns    2fa0 <buf_grow+0x40>
    2fad:	48 8b 39             	mov    (%rcx),%rdi
    2fb0:	48 89 d6             	mov    %rdx,%rsi
    2fb3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2fb8:	48 89 14 24          	mov    %rdx,(%rsp)
    2fbc:	e8 df f5 ff ff       	call   25a0 <realloc@plt>
    2fc1:	48 8b 14 24          	mov    (%rsp),%rdx
    2fc5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2fca:	48 85 c0             	test   %rax,%rax
    2fcd:	74 1d                	je     2fec <buf_grow+0x8c>
    2fcf:	48 89 01             	mov    %rax,(%rcx)
    2fd2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2fd6:	48 83 c4 18          	add    $0x18,%rsp
    2fda:	c3                   	ret
    2fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fe0:	48 89 c2             	mov    %rax,%rdx
    2fe3:	eb c8                	jmp    2fad <buf_grow+0x4d>
    2fe5:	ba 40 00 00 00       	mov    $0x40,%edx
    2fea:	eb c1                	jmp    2fad <buf_grow+0x4d>
    2fec:	48 8b 0d 4d 90 00 00 	mov    0x904d(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    2ff3:	ba 13 00 00 00       	mov    $0x13,%edx
    2ff8:	be 01 00 00 00       	mov    $0x1,%esi
    2ffd:	48 8d 3d 04 60 00 00 	lea    0x6004(%rip),%rdi        # 9008 <_IO_stdin_used+0x8>
    3004:	e8 37 f6 ff ff       	call   2640 <fwrite@plt>
    3009:	31 ff                	xor    %edi,%edi
    300b:	e8 80 f5 ff ff       	call   2590 <fflush@plt>
    3010:	bf 66 00 00 00       	mov    $0x66,%edi
    3015:	e8 46 f6 ff ff       	call   2660 <_Exit@plt>
    301a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003020 <buf_put>:
    3020:	41 54                	push   %r12
    3022:	49 89 f4             	mov    %rsi,%r12
    3025:	48 89 d6             	mov    %rdx,%rsi
    3028:	55                   	push   %rbp
    3029:	48 89 fd             	mov    %rdi,%rbp
    302c:	53                   	push   %rbx
    302d:	48 89 d3             	mov    %rdx,%rbx
    3030:	e8 2b ff ff ff       	call   2f60 <buf_grow>
    3035:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    3039:	48 89 da             	mov    %rbx,%rdx
    303c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    3040:	4c 89 e6             	mov    %r12,%rsi
    3043:	e8 28 f5 ff ff       	call   2570 <memcpy@plt>
    3048:	48 8b 45 00          	mov    0x0(%rbp),%rax
    304c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    3050:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    3054:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    3058:	5b                   	pop    %rbx
    3059:	5d                   	pop    %rbp
    305a:	41 5c                	pop    %r12
    305c:	c3                   	ret
    305d:	0f 1f 00             	nopl   (%rax)

0000000000003060 <fwp_cancel_tree.part.0>:
    3060:	48 3b 3d 79 96 01 00 	cmp    0x19679(%rip),%rdi        # 1c6e0 <fwp_cur>
    3067:	53                   	push   %rbx
    3068:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    306c:	74 35                	je     30a3 <fwp_cancel_tree.part.0+0x43>
    306e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3072:	75 2f                	jne    30a3 <fwp_cancel_tree.part.0+0x43>
    3074:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3078:	75 29                	jne    30a3 <fwp_cancel_tree.part.0+0x43>
    307a:	48 8b 05 3f 96 01 00 	mov    0x1963f(%rip),%rax        # 1c6c0 <fwp_ready_tail>
    3081:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3085:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    308c:	00 00 00 00 
    3090:	48 85 c0             	test   %rax,%rax
    3093:	74 33                	je     30c8 <fwp_cancel_tree.part.0+0x68>
    3095:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    309c:	48 89 3d 1d 96 01 00 	mov    %rdi,0x1961d(%rip)        # 1c6c0 <fwp_ready_tail>
    30a3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    30a7:	48 85 db             	test   %rbx,%rbx
    30aa:	74 17                	je     30c3 <fwp_cancel_tree.part.0+0x63>
    30ac:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    30b0:	75 08                	jne    30ba <fwp_cancel_tree.part.0+0x5a>
    30b2:	48 89 df             	mov    %rbx,%rdi
    30b5:	e8 a6 ff ff ff       	call   3060 <fwp_cancel_tree.part.0>
    30ba:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    30be:	48 85 db             	test   %rbx,%rbx
    30c1:	75 e9                	jne    30ac <fwp_cancel_tree.part.0+0x4c>
    30c3:	5b                   	pop    %rbx
    30c4:	c3                   	ret
    30c5:	0f 1f 00             	nopl   (%rax)
    30c8:	48 89 3d f9 95 01 00 	mov    %rdi,0x195f9(%rip)        # 1c6c8 <fwp_ready_head>
    30cf:	eb cb                	jmp    309c <fwp_cancel_tree.part.0+0x3c>
    30d1:	0f 1f 40 00          	nopl   0x0(%rax)
    30d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    30dc:	00 00 00 00 

00000000000030e0 <fwp_finish_float>:
    30e0:	53                   	push   %rbx
    30e1:	be 2e 00 00 00       	mov    $0x2e,%esi
    30e6:	48 89 fb             	mov    %rdi,%rbx
    30e9:	e8 72 f3 ff ff       	call   2460 <strchr@plt>
    30ee:	48 85 c0             	test   %rax,%rax
    30f1:	74 05                	je     30f8 <fwp_finish_float+0x18>
    30f3:	5b                   	pop    %rbx
    30f4:	c3                   	ret
    30f5:	0f 1f 00             	nopl   (%rax)
    30f8:	be 65 00 00 00       	mov    $0x65,%esi
    30fd:	48 89 df             	mov    %rbx,%rdi
    3100:	e8 5b f3 ff ff       	call   2460 <strchr@plt>
    3105:	48 85 c0             	test   %rax,%rax
    3108:	75 e9                	jne    30f3 <fwp_finish_float+0x13>
    310a:	48 8d 35 08 60 00 00 	lea    0x6008(%rip),%rsi        # 9119 <_IO_stdin_used+0x119>
    3111:	48 89 df             	mov    %rbx,%rdi
    3114:	e8 77 f5 ff ff       	call   2690 <strstr@plt>
    3119:	48 85 c0             	test   %rax,%rax
    311c:	75 d5                	jne    30f3 <fwp_finish_float+0x13>
    311e:	48 8d 35 f7 5e 00 00 	lea    0x5ef7(%rip),%rsi        # 901c <_IO_stdin_used+0x1c>
    3125:	48 89 df             	mov    %rbx,%rdi
    3128:	e8 63 f5 ff ff       	call   2690 <strstr@plt>
    312d:	48 85 c0             	test   %rax,%rax
    3130:	75 c1                	jne    30f3 <fwp_finish_float+0x13>
    3132:	48 89 df             	mov    %rbx,%rdi
    3135:	e8 f6 f2 ff ff       	call   2430 <strlen@plt>
    313a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    313f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    3143:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    3148:	5b                   	pop    %rbx
    3149:	c3                   	ret
    314a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003150 <ad_raw_report>:
    3150:	f3 0f 1e fa          	endbr64
    3154:	55                   	push   %rbp
    3155:	31 c9                	xor    %ecx,%ecx
    3157:	45 31 c9             	xor    %r9d,%r9d
    315a:	48 8d 15 bf 60 00 00 	lea    0x60bf(%rip),%rdx        # 9220 <_IO_stdin_used+0x220>
    3161:	53                   	push   %rbx
    3162:	be 02 00 00 00       	mov    $0x2,%esi
    3167:	31 db                	xor    %ebx,%ebx
    3169:	48 83 ec 38          	sub    $0x38,%rsp
    316d:	4c 8b 05 14 8f 01 00 	mov    0x18f14(%rip),%r8        # 1c088 <ad_raw_before_shutdown>
    3174:	48 8b 3d c5 8e 00 00 	mov    0x8ec5(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    317b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3182:	00 00 
    3184:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3189:	31 c0                	xor    %eax,%eax
    318b:	48 89 e5             	mov    %rsp,%rbp
    318e:	e8 bd f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3193:	48 8d 05 91 5e 00 00 	lea    0x5e91(%rip),%rax        # 902b <_IO_stdin_used+0x2b>
    319a:	f3 0f 7e 05 6e 8a 00 	movq   0x8a6e(%rip),%xmm0        # bc10 <d0+0x70>
    31a1:	00 
    31a2:	48 8d 0d c5 5e 00 00 	lea    0x5ec5(%rip),%rcx        # 906e <_IO_stdin_used+0x6e>
    31a9:	66 48 0f 6e c8       	movq   %rax,%xmm1
    31ae:	48 8d 05 89 5e 00 00 	lea    0x5e89(%rip),%rax        # 903e <_IO_stdin_used+0x3e>
    31b5:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    31b9:	66 48 0f 6e d0       	movq   %rax,%xmm2
    31be:	66 49 0f 7e c0       	movq   %xmm0,%r8
    31c3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    31c7:	f3 0f 7e 05 49 8a 00 	movq   0x8a49(%rip),%xmm0        # bc18 <d0+0x78>
    31ce:	00 
    31cf:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    31d3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    31d8:	6a 00                	push   $0x0
    31da:	48 8b 3d 5f 8e 00 00 	mov    0x8e5f(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    31e1:	45 31 c9             	xor    %r9d,%r9d
    31e4:	31 c0                	xor    %eax,%eax
    31e6:	6a 00                	push   $0x0
    31e8:	48 8d 15 91 60 00 00 	lea    0x6091(%rip),%rdx        # 9280 <_IO_stdin_used+0x280>
    31ef:	be 02 00 00 00       	mov    $0x2,%esi
    31f4:	83 c3 01             	add    $0x1,%ebx
    31f7:	e8 54 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    31fc:	58                   	pop    %rax
    31fd:	5a                   	pop    %rdx
    31fe:	83 fb 04             	cmp    $0x4,%ebx
    3201:	74 15                	je     3218 <ad_raw_report+0xc8>
    3203:	48 83 c5 08          	add    $0x8,%rbp
    3207:	48 8d 0d 12 5e 00 00 	lea    0x5e12(%rip),%rcx        # 9020 <_IO_stdin_used+0x20>
    320e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    3212:	eb c4                	jmp    31d8 <ad_raw_report+0x88>
    3214:	0f 1f 40 00          	nopl   0x0(%rax)
    3218:	48 8b 0d 21 8e 00 00 	mov    0x8e21(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    321f:	ba 13 00 00 00       	mov    $0x13,%edx
    3224:	be 01 00 00 00       	mov    $0x1,%esi
    3229:	48 8d 3d 17 5e 00 00 	lea    0x5e17(%rip),%rdi        # 9047 <_IO_stdin_used+0x47>
    3230:	e8 0b f4 ff ff       	call   2640 <fwrite@plt>
    3235:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    323a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3241:	00 00 
    3243:	75 23                	jne    3268 <ad_raw_report+0x118>
    3245:	48 8b 0d f4 8d 00 00 	mov    0x8df4(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    324c:	48 83 c4 38          	add    $0x38,%rsp
    3250:	ba 04 00 00 00       	mov    $0x4,%edx
    3255:	be 01 00 00 00       	mov    $0x1,%esi
    325a:	5b                   	pop    %rbx
    325b:	48 8d 3d f9 5d 00 00 	lea    0x5df9(%rip),%rdi        # 905b <_IO_stdin_used+0x5b>
    3262:	5d                   	pop    %rbp
    3263:	e9 d8 f3 ff ff       	jmp    2640 <fwrite@plt>
    3268:	e8 d3 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    326d:	0f 1f 00             	nopl   (%rax)

0000000000003270 <fwp_trap>:
    3270:	53                   	push   %rbx
    3271:	48 89 fb             	mov    %rdi,%rbx
    3274:	e8 b7 f9 ff ff       	call   2c30 <fwp_flush>
    3279:	48 89 d9             	mov    %rbx,%rcx
    327c:	be 02 00 00 00       	mov    $0x2,%esi
    3281:	31 c0                	xor    %eax,%eax
    3283:	48 8b 3d b6 8d 00 00 	mov    0x8db6(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    328a:	48 8d 15 cf 5d 00 00 	lea    0x5dcf(%rip),%rdx        # 9060 <_IO_stdin_used+0x60>
    3291:	e8 ba f3 ff ff       	call   2650 <__fprintf_chk@plt>
    3296:	bf 65 00 00 00       	mov    $0x65,%edi
    329b:	e8 90 f3 ff ff       	call   2630 <exit@plt>

00000000000032a0 <fwp_now_ns>:
    32a0:	53                   	push   %rbx
    32a1:	bf 01 00 00 00       	mov    $0x1,%edi
    32a6:	48 83 ec 20          	sub    $0x20,%rsp
    32aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    32b1:	00 00 
    32b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    32b8:	31 db                	xor    %ebx,%ebx
    32ba:	48 89 e6             	mov    %rsp,%rsi
    32bd:	e8 3e f1 ff ff       	call   2400 <clock_gettime@plt>
    32c2:	85 c0                	test   %eax,%eax
    32c4:	75 52                	jne    3318 <fwp_now_ns+0x78>
    32c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    32cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    32d0:	48 f7 2c 24          	imulq  (%rsp)
    32d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    32db:	48 89 f7             	mov    %rsi,%rdi
    32de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    32e2:	48 01 f0             	add    %rsi,%rax
    32e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    32ec:	00 00 80 
    32ef:	48 11 fa             	adc    %rdi,%rdx
    32f2:	31 ff                	xor    %edi,%edi
    32f4:	48 01 c6             	add    %rax,%rsi
    32f7:	48 11 d7             	adc    %rdx,%rdi
    32fa:	48 39 f1             	cmp    %rsi,%rcx
    32fd:	48 19 fb             	sbb    %rdi,%rbx
    3300:	72 27                	jb     3329 <fwp_now_ns+0x89>
    3302:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3307:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    330e:	00 00 
    3310:	75 12                	jne    3324 <fwp_now_ns+0x84>
    3312:	48 83 c4 20          	add    $0x20,%rsp
    3316:	5b                   	pop    %rbx
    3317:	c3                   	ret
    3318:	48 8d 3d 50 5d 00 00 	lea    0x5d50(%rip),%rdi        # 906f <_IO_stdin_used+0x6f>
    331f:	e8 4c ff ff ff       	call   3270 <fwp_trap>
    3324:	e8 17 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    3329:	48 8d 3d 90 5f 00 00 	lea    0x5f90(%rip),%rdi        # 92c0 <_IO_stdin_used+0x2c0>
    3330:	e8 3b ff ff ff       	call   3270 <fwp_trap>
    3335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    333c:	00 00 00 00 

0000000000003340 <fwp_args74>:
    3340:	f3 0f 1e fa          	endbr64
    3344:	c3                   	ret
    3345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    334c:	00 00 00 00 

0000000000003350 <fwp_format_g.constprop.0>:
    3350:	41 57                	push   %r15
    3352:	b9 40 00 00 00       	mov    $0x40,%ecx
    3357:	ba 02 00 00 00       	mov    $0x2,%edx
    335c:	4c 8d 05 28 5d 00 00 	lea    0x5d28(%rip),%r8        # 908b <_IO_stdin_used+0x8b>
    3363:	41 56                	push   %r14
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	41 55                	push   %r13
    336c:	41 54                	push   %r12
    336e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    3372:	55                   	push   %rbp
    3373:	45 89 e1             	mov    %r12d,%r9d
    3376:	53                   	push   %rbx
    3377:	48 89 fb             	mov    %rdi,%rbx
    337a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3381:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3388:	00 00 
    338a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3391:	00 
    3392:	41 89 f7             	mov    %esi,%r15d
    3395:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    339a:	be 40 00 00 00       	mov    $0x40,%esi
    339f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    33a4:	4c 89 f7             	mov    %r14,%rdi
    33a7:	e8 e4 ef ff ff       	call   2390 <__snprintf_chk@plt>
    33ac:	be 65 00 00 00       	mov    $0x65,%esi
    33b1:	4c 89 f7             	mov    %r14,%rdi
    33b4:	e8 a7 f0 ff ff       	call   2460 <strchr@plt>
    33b9:	31 f6                	xor    %esi,%esi
    33bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    33c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33c4:	48 89 c5             	mov    %rax,%rbp
    33c7:	e8 94 f1 ff ff       	call   2560 <strtol@plt>
    33cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    33d1:	49 89 c0             	mov    %rax,%r8
    33d4:	83 c0 05             	add    $0x5,%eax
    33d7:	83 f8 15             	cmp    $0x15,%eax
    33da:	0f 87 e0 01 00 00    	ja     35c0 <fwp_format_g.constprop.0+0x270>
    33e0:	45 89 e5             	mov    %r12d,%r13d
    33e3:	45 29 c5             	sub    %r8d,%r13d
    33e6:	45 85 ed             	test   %r13d,%r13d
    33e9:	0f 8e 21 01 00 00    	jle    3510 <fwp_format_g.constprop.0+0x1c0>
    33ef:	41 83 ff 01          	cmp    $0x1,%r15d
    33f3:	0f 84 17 01 00 00    	je     3510 <fwp_format_g.constprop.0+0x1c0>
    33f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    33fe:	31 d2                	xor    %edx,%edx
    3400:	4d 63 df             	movslq %r15d,%r11
    3403:	3c 2d                	cmp    $0x2d,%al
    3405:	0f 94 c2             	sete   %dl
    3408:	4c 29 dd             	sub    %r11,%rbp
    340b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    340f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3413:	4d 89 f1             	mov    %r14,%r9
    3416:	4d 29 d1             	sub    %r10,%r9
    3419:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    341d:	3c 2d                	cmp    $0x2d,%al
    341f:	0f 84 fb 03 00 00    	je     3820 <fwp_format_g.constprop.0+0x4d0>
    3425:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    342a:	b9 48 00 00 00       	mov    $0x48,%ecx
    342f:	48 89 e8             	mov    %rbp,%rax
    3432:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3436:	49 8d 72 01          	lea    0x1(%r10),%rsi
    343a:	49 83 c1 47          	add    $0x47,%r9
    343e:	45 85 c0             	test   %r8d,%r8d
    3441:	0f 88 f1 02 00 00    	js     3738 <fwp_format_g.constprop.0+0x3e8>
    3447:	45 0f b6 12          	movzbl (%r10),%r10d
    344b:	4d 63 e0             	movslq %r8d,%r12
    344e:	44 88 10             	mov    %r10b,(%rax)
    3451:	41 83 f8 07          	cmp    $0x7,%r8d
    3455:	0f 87 2d 02 00 00    	ja     3688 <fwp_format_g.constprop.0+0x338>
    345b:	41 f6 c4 04          	test   $0x4,%r12b
    345f:	0f 85 f2 03 00 00    	jne    3857 <fwp_format_g.constprop.0+0x507>
    3465:	45 85 e4             	test   %r12d,%r12d
    3468:	74 12                	je     347c <fwp_format_g.constprop.0+0x12c>
    346a:	45 0f b6 06          	movzbl (%r14),%r8d
    346e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    3472:	41 f6 c4 02          	test   $0x2,%r12b
    3476:	0f 85 03 04 00 00    	jne    387f <fwp_format_g.constprop.0+0x52f>
    347c:	4c 29 e1             	sub    %r12,%rcx
    347f:	4c 01 e7             	add    %r12,%rdi
    3482:	4c 89 fa             	mov    %r15,%rdx
    3485:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    348a:	48 83 e9 01          	sub    $0x1,%rcx
    348e:	4d 63 ed             	movslq %r13d,%r13
    3491:	48 89 0c 24          	mov    %rcx,(%rsp)
    3495:	e8 a6 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    349a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    349f:	48 8b 0c 24          	mov    (%rsp),%rcx
    34a3:	ba 48 00 00 00       	mov    $0x48,%edx
    34a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    34ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    34b0:	4c 89 c8             	mov    %r9,%rax
    34b3:	48 29 c8             	sub    %rcx,%rax
    34b6:	48 39 d0             	cmp    %rdx,%rax
    34b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    34bd:	4c 29 c9             	sub    %r9,%rcx
    34c0:	4c 89 ea             	mov    %r13,%rdx
    34c3:	48 01 c1             	add    %rax,%rcx
    34c6:	e8 75 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    34cb:	4c 01 e8             	add    %r13,%rax
    34ce:	48 29 e8             	sub    %rbp,%rax
    34d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    34d6:	48 39 d0             	cmp    %rdx,%rax
    34d9:	48 0f 47 c2          	cmova  %rdx,%rax
    34dd:	89 c1                	mov    %eax,%ecx
    34df:	83 f8 08             	cmp    $0x8,%eax
    34e2:	0f 83 18 02 00 00    	jae    3700 <fwp_format_g.constprop.0+0x3b0>
    34e8:	a8 04                	test   $0x4,%al
    34ea:	0f 85 54 03 00 00    	jne    3844 <fwp_format_g.constprop.0+0x4f4>
    34f0:	85 c0                	test   %eax,%eax
    34f2:	74 0f                	je     3503 <fwp_format_g.constprop.0+0x1b3>
    34f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    34f9:	88 13                	mov    %dl,(%rbx)
    34fb:	a8 02                	test   $0x2,%al
    34fd:	0f 85 6b 03 00 00    	jne    386e <fwp_format_g.constprop.0+0x51e>
    3503:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3507:	eb 36                	jmp    353f <fwp_format_g.constprop.0+0x1ef>
    3509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3510:	45 31 c9             	xor    %r9d,%r9d
    3513:	45 85 ed             	test   %r13d,%r13d
    3516:	4c 8d 05 7d 5b 00 00 	lea    0x5b7d(%rip),%r8        # 909a <_IO_stdin_used+0x9a>
    351d:	48 89 df             	mov    %rbx,%rdi
    3520:	45 0f 49 cd          	cmovns %r13d,%r9d
    3524:	ba 02 00 00 00       	mov    $0x2,%edx
    3529:	be 90 01 00 00       	mov    $0x190,%esi
    352e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3535:	b8 01 00 00 00       	mov    $0x1,%eax
    353a:	e8 51 ee ff ff       	call   2390 <__snprintf_chk@plt>
    353f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3544:	48 89 df             	mov    %rbx,%rdi
    3547:	e8 14 ef ff ff       	call   2460 <strchr@plt>
    354c:	48 85 c0             	test   %rax,%rax
    354f:	74 3f                	je     3590 <fwp_format_g.constprop.0+0x240>
    3551:	48 89 df             	mov    %rbx,%rdi
    3554:	e8 d7 ee ff ff       	call   2430 <strlen@plt>
    3559:	48 85 c0             	test   %rax,%rax
    355c:	75 0b                	jne    3569 <fwp_format_g.constprop.0+0x219>
    355e:	eb 30                	jmp    3590 <fwp_format_g.constprop.0+0x240>
    3560:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3564:	48 85 c0             	test   %rax,%rax
    3567:	74 27                	je     3590 <fwp_format_g.constprop.0+0x240>
    3569:	48 89 c2             	mov    %rax,%rdx
    356c:	48 83 e8 01          	sub    $0x1,%rax
    3570:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    3574:	74 ea                	je     3560 <fwp_format_g.constprop.0+0x210>
    3576:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    357b:	0f 84 6f 01 00 00    	je     36f0 <fwp_format_g.constprop.0+0x3a0>
    3581:	0f 1f 40 00          	nopl   0x0(%rax)
    3585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    358c:	00 00 00 00 
    3590:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3597:	00 
    3598:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    359f:	00 00 
    35a1:	0f 85 ec 02 00 00    	jne    3893 <fwp_format_g.constprop.0+0x543>
    35a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    35ae:	5b                   	pop    %rbx
    35af:	5d                   	pop    %rbp
    35b0:	41 5c                	pop    %r12
    35b2:	41 5d                	pop    %r13
    35b4:	41 5e                	pop    %r14
    35b6:	41 5f                	pop    %r15
    35b8:	c3                   	ret
    35b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    35c0:	4c 29 f5             	sub    %r14,%rbp
    35c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    35c8:	4c 89 f6             	mov    %r14,%rsi
    35cb:	4c 89 04 24          	mov    %r8,(%rsp)
    35cf:	49 89 ec             	mov    %rbp,%r12
    35d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    35d7:	4c 89 e2             	mov    %r12,%rdx
    35da:	48 89 ef             	mov    %rbp,%rdi
    35dd:	e8 5e ef ff ff       	call   2540 <__memcpy_chk@plt>
    35e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    35e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    35ed:	48 89 ef             	mov    %rbp,%rdi
    35f0:	e8 6b ee ff ff       	call   2460 <strchr@plt>
    35f5:	4c 8b 04 24          	mov    (%rsp),%r8
    35f9:	48 85 c0             	test   %rax,%rax
    35fc:	74 40                	je     363e <fwp_format_g.constprop.0+0x2ee>
    35fe:	4d 85 e4             	test   %r12,%r12
    3601:	74 3b                	je     363e <fwp_format_g.constprop.0+0x2ee>
    3603:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3608:	eb 23                	jmp    362d <fwp_format_g.constprop.0+0x2dd>
    360a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3611:	00 00 00 00 
    3615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    361c:	00 00 00 00 
    3620:	c6 00 00             	movb   $0x0,(%rax)
    3623:	48 83 e8 01          	sub    $0x1,%rax
    3627:	49 83 ec 01          	sub    $0x1,%r12
    362b:	74 11                	je     363e <fwp_format_g.constprop.0+0x2ee>
    362d:	80 38 30             	cmpb   $0x30,(%rax)
    3630:	74 ee                	je     3620 <fwp_format_g.constprop.0+0x2d0>
    3632:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3638:	0f 84 fb 01 00 00    	je     3839 <fwp_format_g.constprop.0+0x4e9>
    363e:	44 89 c0             	mov    %r8d,%eax
    3641:	ba 02 00 00 00       	mov    $0x2,%edx
    3646:	49 89 e9             	mov    %rbp,%r9
    3649:	be 90 01 00 00       	mov    $0x190,%esi
    364e:	f7 d8                	neg    %eax
    3650:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3657:	48 89 df             	mov    %rbx,%rdi
    365a:	41 0f 48 c0          	cmovs  %r8d,%eax
    365e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    3662:	41 83 e0 02          	and    $0x2,%r8d
    3666:	41 83 c0 2b          	add    $0x2b,%r8d
    366a:	50                   	push   %rax
    366b:	31 c0                	xor    %eax,%eax
    366d:	41 50                	push   %r8
    366f:	4c 8d 05 1a 5a 00 00 	lea    0x5a1a(%rip),%r8        # 9090 <_IO_stdin_used+0x90>
    3676:	e8 15 ed ff ff       	call   2390 <__snprintf_chk@plt>
    367b:	58                   	pop    %rax
    367c:	5a                   	pop    %rdx
    367d:	e9 0e ff ff ff       	jmp    3590 <fwp_format_g.constprop.0+0x240>
    3682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3688:	4d 8b 06             	mov    (%r14),%r8
    368b:	48 83 c0 09          	add    $0x9,%rax
    368f:	4c 89 f2             	mov    %r14,%rdx
    3692:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3696:	4c 89 07             	mov    %r8,(%rdi)
    3699:	45 89 e0             	mov    %r12d,%r8d
    369c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    36a1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    36a6:	49 89 f8             	mov    %rdi,%r8
    36a9:	49 29 c0             	sub    %rax,%r8
    36ac:	4c 29 c2             	sub    %r8,%rdx
    36af:	45 01 e0             	add    %r12d,%r8d
    36b2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    36b6:	41 83 f8 08          	cmp    $0x8,%r8d
    36ba:	0f 82 bc fd ff ff    	jb     347c <fwp_format_g.constprop.0+0x12c>
    36c0:	48 89 0c 24          	mov    %rcx,(%rsp)
    36c4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    36c8:	45 31 d2             	xor    %r10d,%r10d
    36cb:	45 89 d3             	mov    %r10d,%r11d
    36ce:	41 83 c2 08          	add    $0x8,%r10d
    36d2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    36d6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    36da:	45 39 c2             	cmp    %r8d,%r10d
    36dd:	72 ec                	jb     36cb <fwp_format_g.constprop.0+0x37b>
    36df:	48 8b 0c 24          	mov    (%rsp),%rcx
    36e3:	e9 94 fd ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    36e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36ef:	00 
    36f0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    36f5:	e9 96 fe ff ff       	jmp    3590 <fwp_format_g.constprop.0+0x240>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3700:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3705:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3709:	48 89 ee             	mov    %rbp,%rsi
    370c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3710:	48 89 13             	mov    %rdx,(%rbx)
    3713:	89 c2                	mov    %eax,%edx
    3715:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    371a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    371f:	48 89 d9             	mov    %rbx,%rcx
    3722:	48 29 f9             	sub    %rdi,%rcx
    3725:	48 29 ce             	sub    %rcx,%rsi
    3728:	01 c1                	add    %eax,%ecx
    372a:	c1 e9 03             	shr    $0x3,%ecx
    372d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3730:	e9 ce fd ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    3735:	0f 1f 00             	nopl   (%rax)
    3738:	c6 00 30             	movb   $0x30,(%rax)
    373b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    373f:	4c 89 fa             	mov    %r15,%rdx
    3742:	4c 89 e9             	mov    %r13,%rcx
    3745:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    374a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    374f:	4c 89 14 24          	mov    %r10,(%rsp)
    3753:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3758:	e8 e3 ed ff ff       	call   2540 <__memcpy_chk@plt>
    375d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    3762:	b9 48 00 00 00       	mov    $0x48,%ecx
    3767:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    376c:	48 89 c7             	mov    %rax,%rdi
    376f:	4c 8b 14 24          	mov    (%rsp),%r10
    3773:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    3778:	4c 89 c8             	mov    %r9,%rax
    377b:	4c 29 e8             	sub    %r13,%rax
    377e:	48 39 c8             	cmp    %rcx,%rax
    3781:	48 0f 42 c1          	cmovb  %rcx,%rax
    3785:	4d 29 cd             	sub    %r9,%r13
    3788:	49 01 ff             	add    %rdi,%r15
    378b:	4c 01 e8             	add    %r13,%rax
    378e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3792:	74 3d                	je     37d1 <fwp_format_g.constprop.0+0x481>
    3794:	41 f7 d0             	not    %r8d
    3797:	31 f6                	xor    %esi,%esi
    3799:	ba 48 00 00 00       	mov    $0x48,%edx
    379e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    37a3:	48 39 d0             	cmp    %rdx,%rax
    37a6:	48 0f 43 d0          	cmovae %rax,%rdx
    37aa:	48 89 d1             	mov    %rdx,%rcx
    37ad:	48 29 c1             	sub    %rax,%rcx
    37b0:	48 83 c1 01          	add    $0x1,%rcx
    37b4:	48 39 d1             	cmp    %rdx,%rcx
    37b7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    37bb:	48 83 e8 01          	sub    $0x1,%rax
    37bf:	48 83 c6 01          	add    $0x1,%rsi
    37c3:	48 29 d0             	sub    %rdx,%rax
    37c6:	48 01 c8             	add    %rcx,%rax
    37c9:	41 39 f0             	cmp    %esi,%r8d
    37cc:	7f cb                	jg     3799 <fwp_format_g.constprop.0+0x449>
    37ce:	4d 01 c7             	add    %r8,%r15
    37d1:	b9 48 00 00 00       	mov    $0x48,%ecx
    37d6:	41 0f b6 12          	movzbl (%r10),%edx
    37da:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    37de:	4c 89 f6             	mov    %r14,%rsi
    37e1:	48 39 c8             	cmp    %rcx,%rax
    37e4:	4c 89 1c 24          	mov    %r11,(%rsp)
    37e8:	48 0f 43 c8          	cmovae %rax,%rcx
    37ec:	41 88 17             	mov    %dl,(%r15)
    37ef:	48 89 ca             	mov    %rcx,%rdx
    37f2:	48 29 c2             	sub    %rax,%rdx
    37f5:	48 83 c2 01          	add    $0x1,%rdx
    37f9:	48 39 ca             	cmp    %rcx,%rdx
    37fc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3800:	48 83 e8 01          	sub    $0x1,%rax
    3804:	48 29 c8             	sub    %rcx,%rax
    3807:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    380b:	49 63 d4             	movslq %r12d,%rdx
    380e:	e8 2d ed ff ff       	call   2540 <__memcpy_chk@plt>
    3813:	4c 8b 1c 24          	mov    (%rsp),%r11
    3817:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    381b:	e9 ae fc ff ff       	jmp    34ce <fwp_format_g.constprop.0+0x17e>
    3820:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3825:	b9 47 00 00 00       	mov    $0x47,%ecx
    382a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    382f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3834:	e9 f9 fb ff ff       	jmp    3432 <fwp_format_g.constprop.0+0xe2>
    3839:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    383f:	e9 fa fd ff ff       	jmp    363e <fwp_format_g.constprop.0+0x2ee>
    3844:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3848:	89 13                	mov    %edx,(%rbx)
    384a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    384e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3852:	e9 ac fc ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    3857:	41 8b 06             	mov    (%r14),%eax
    385a:	89 07                	mov    %eax,(%rdi)
    385c:	44 89 e0             	mov    %r12d,%eax
    385f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    3864:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    3869:	e9 0e fc ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    386e:	89 c2                	mov    %eax,%edx
    3870:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    3875:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    387a:	e9 84 fc ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    387f:	44 89 e0             	mov    %r12d,%eax
    3882:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3888:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    388e:	e9 e9 fb ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    3893:	e8 a8 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    3898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    389f:	00 

00000000000038a0 <fwp_heap_report>:
    38a0:	f3 0f 1e fa          	endbr64
    38a4:	41 54                	push   %r12
    38a6:	48 8d 3d f2 57 00 00 	lea    0x57f2(%rip),%rdi        # 909f <_IO_stdin_used+0x9f>
    38ad:	55                   	push   %rbp
    38ae:	53                   	push   %rbx
    38af:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    38b6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    38bd:	00 00 
    38bf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    38c6:	00 
    38c7:	48 8d 35 93 58 00 00 	lea    0x5893(%rip),%rsi        # 9161 <_IO_stdin_used+0x161>
    38ce:	e8 1d ed ff ff       	call   25f0 <fopen@plt>
    38d3:	48 85 c0             	test   %rax,%rax
    38d6:	0f 84 c5 00 00 00    	je     39a1 <fwp_heap_report+0x101>
    38dc:	48 89 c5             	mov    %rax,%rbp
    38df:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    38e6:	48 89 e3             	mov    %rsp,%rbx
    38e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    38f0:	48 89 ea             	mov    %rbp,%rdx
    38f3:	be 00 01 00 00       	mov    $0x100,%esi
    38f8:	48 89 df             	mov    %rbx,%rdi
    38fb:	e8 e0 eb ff ff       	call   24e0 <fgets@plt>
    3900:	48 85 c0             	test   %rax,%rax
    3903:	74 2b                	je     3930 <fwp_heap_report+0x90>
    3905:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    390b:	75 e3                	jne    38f0 <fwp_heap_report+0x50>
    390d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3911:	75 dd                	jne    38f0 <fwp_heap_report+0x50>
    3913:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3918:	75 d6                	jne    38f0 <fwp_heap_report+0x50>
    391a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    391f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3924:	31 f6                	xor    %esi,%esi
    3926:	e8 35 ec ff ff       	call   2560 <strtol@plt>
    392b:	49 89 c4             	mov    %rax,%r12
    392e:	eb c0                	jmp    38f0 <fwp_heap_report+0x50>
    3930:	48 89 ef             	mov    %rbp,%rdi
    3933:	e8 e8 ea ff ff       	call   2420 <fclose@plt>
    3938:	48 83 ec 08          	sub    $0x8,%rsp
    393c:	4c 8b 0d 85 a1 01 00 	mov    0x1a185(%rip),%r9        # 1dac8 <fwp_heap+0x13c8>
    3943:	4c 8b 05 de a1 01 00 	mov    0x1a1de(%rip),%r8        # 1db28 <fwp_heap+0x1428>
    394a:	48 8d 15 97 59 00 00 	lea    0x5997(%rip),%rdx        # 92e8 <_IO_stdin_used+0x2e8>
    3951:	41 54                	push   %r12
    3953:	48 8b 0d c6 a1 01 00 	mov    0x1a1c6(%rip),%rcx        # 1db20 <fwp_heap+0x1420>
    395a:	be 02 00 00 00       	mov    $0x2,%esi
    395f:	b8 02 00 00 00       	mov    $0x2,%eax
    3964:	f2 0f 10 0d d4 a1 01 	movsd  0x1a1d4(%rip),%xmm1        # 1db40 <fwp_heap+0x1440>
    396b:	00 
    396c:	f2 0f 10 05 c4 a1 01 	movsd  0x1a1c4(%rip),%xmm0        # 1db38 <fwp_heap+0x1438>
    3973:	00 
    3974:	48 8b 3d c5 86 00 00 	mov    0x86c5(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    397b:	e8 d0 ec ff ff       	call   2650 <__fprintf_chk@plt>
    3980:	58                   	pop    %rax
    3981:	5a                   	pop    %rdx
    3982:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3989:	00 
    398a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3991:	00 00 
    3993:	75 15                	jne    39aa <fwp_heap_report+0x10a>
    3995:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    399c:	5b                   	pop    %rbx
    399d:	5d                   	pop    %rbp
    399e:	41 5c                	pop    %r12
    39a0:	c3                   	ret
    39a1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    39a8:	eb 8e                	jmp    3938 <fwp_heap_report+0x98>
    39aa:	e8 91 ea ff ff       	call   2440 <__stack_chk_fail@plt>
    39af:	90                   	nop

00000000000039b0 <fwp_heap_init>:
    39b0:	66 0f 6f 05 68 5c 00 	movdqa 0x5c68(%rip),%xmm0        # 9620 <msg.3+0x50>
    39b7:	00 
    39b8:	41 54                	push   %r12
    39ba:	48 8d 05 7f 9c 01 00 	lea    0x19c7f(%rip),%rax        # 1d640 <fwp_heap+0xf40>
    39c1:	ba 00 01 00 00       	mov    $0x100,%edx
    39c6:	55                   	push   %rbp
    39c7:	66 0f 6f 15 91 5c 00 	movdqa 0x5c91(%rip),%xmm2        # 9660 <msg.3+0x90>
    39ce:	00 
    39cf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    39d3:	53                   	push   %rbx
    39d4:	0f 29 05 25 9c 01 00 	movaps %xmm0,0x19c25(%rip)        # 1d600 <fwp_heap+0xf00>
    39db:	66 0f 6f 05 4d 5c 00 	movdqa 0x5c4d(%rip),%xmm0        # 9630 <msg.3+0x60>
    39e2:	00 
    39e3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    39e7:	c7 05 b3 a0 01 00 01 	movl   $0x1,0x1a0b3(%rip)        # 1daa4 <fwp_heap+0x13a4>
    39ee:	00 00 00 
    39f1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    39f6:	0f 29 05 13 9c 01 00 	movaps %xmm0,0x19c13(%rip)        # 1d610 <fwp_heap+0xf10>
    39fd:	66 0f 6f 05 3b 5c 00 	movdqa 0x5c3b(%rip),%xmm0        # 9640 <msg.3+0x70>
    3a04:	00 
    3a05:	0f 29 05 14 9c 01 00 	movaps %xmm0,0x19c14(%rip)        # 1d620 <fwp_heap+0xf20>
    3a0c:	66 0f 6f 05 3c 5c 00 	movdqa 0x5c3c(%rip),%xmm0        # 9650 <msg.3+0x80>
    3a13:	00 
    3a14:	0f 29 05 15 9c 01 00 	movaps %xmm0,0x19c15(%rip)        # 1d630 <fwp_heap+0xf30>
    3a1b:	89 d3                	mov    %edx,%ebx
    3a1d:	66 0f 6e e2          	movd   %edx,%xmm4
    3a21:	48 83 c0 10          	add    $0x10,%rax
    3a25:	01 d2                	add    %edx,%edx
    3a27:	c1 eb 02             	shr    $0x2,%ebx
    3a2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    3a2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3a33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3a37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    3a3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3a40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3a44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3a49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    3a4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3a52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3a57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    3a5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    3a5f:	48 39 c7             	cmp    %rax,%rdi
    3a62:	75 b7                	jne    3a1b <fwp_heap_init+0x6b>
    3a64:	4c 8d 05 95 8c 01 00 	lea    0x18c95(%rip),%r8        # 1c700 <fwp_heap>
    3a6b:	31 c9                	xor    %ecx,%ecx
    3a6d:	31 c0                	xor    %eax,%eax
    3a6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    3a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a7d:	00 00 00 
    3a80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a87:	00 
    3a88:	48 39 ca             	cmp    %rcx,%rdx
    3a8b:	73 0f                	jae    3a9c <fwp_heap_init+0xec>
    3a8d:	0f 1f 00             	nopl   (%rax)
    3a90:	48 83 c0 01          	add    $0x1,%rax
    3a94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a97:	48 39 ca             	cmp    %rcx,%rdx
    3a9a:	72 f4                	jb     3a90 <fwp_heap_init+0xe0>
    3a9c:	48 83 c1 10          	add    $0x10,%rcx
    3aa0:	88 07                	mov    %al,(%rdi)
    3aa2:	48 83 c7 01          	add    $0x1,%rdi
    3aa6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3aad:	75 d1                	jne    3a80 <fwp_heap_init+0xd0>
    3aaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3ab6:	00 00 00 
    3ab9:	bd 05 00 00 00       	mov    $0x5,%ebp
    3abe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3ac5:	45 31 c9             	xor    %r9d,%r9d
    3ac8:	31 d2                	xor    %edx,%edx
    3aca:	31 ff                	xor    %edi,%edi
    3acc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3ad2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3ad7:	4c 89 e6             	mov    %r12,%rsi
    3ada:	e8 71 e9 ff ff       	call   2450 <mmap@plt>
    3adf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ae3:	75 13                	jne    3af8 <fwp_heap_init+0x148>
    3ae5:	48 c1 eb 02          	shr    $0x2,%rbx
    3ae9:	83 ed 01             	sub    $0x1,%ebp
    3aec:	75 d0                	jne    3abe <fwp_heap_init+0x10e>
    3aee:	e8 6d f2 ff ff       	call   2d60 <fwp_heap_oom>
    3af3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3af8:	48 85 c0             	test   %rax,%rax
    3afb:	74 f1                	je     3aee <fwp_heap_init+0x13e>
    3afd:	48 c1 eb 10          	shr    $0x10,%rbx
    3b01:	48 89 05 b0 9f 01 00 	mov    %rax,0x19fb0(%rip)        # 1dab8 <fwp_heap+0x13b8>
    3b08:	45 31 c9             	xor    %r9d,%r9d
    3b0b:	31 d2                	xor    %edx,%edx
    3b0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3b13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3b17:	31 ff                	xor    %edi,%edi
    3b19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3b1f:	66 31 c0             	xor    %ax,%ax
    3b22:	48 c1 e6 03          	shl    $0x3,%rsi
    3b26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3b2b:	4c 89 25 8e 9f 01 00 	mov    %r12,0x19f8e(%rip)        # 1dac0 <fwp_heap+0x13c0>
    3b32:	48 89 05 77 9f 01 00 	mov    %rax,0x19f77(%rip)        # 1dab0 <fwp_heap+0x13b0>
    3b39:	48 89 1d 90 9f 01 00 	mov    %rbx,0x19f90(%rip)        # 1dad0 <fwp_heap+0x13d0>
    3b40:	48 89 35 b9 9f 01 00 	mov    %rsi,0x19fb9(%rip)        # 1db00 <fwp_heap+0x1400>
    3b47:	e8 04 e9 ff ff       	call   2450 <mmap@plt>
    3b4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3b50:	74 9c                	je     3aee <fwp_heap_init+0x13e>
    3b52:	48 8d 3d 7c 55 00 00 	lea    0x557c(%rip),%rdi        # 90d5 <_IO_stdin_used+0xd5>
    3b59:	48 89 05 98 9f 01 00 	mov    %rax,0x19f98(%rip)        # 1daf8 <fwp_heap+0x13f8>
    3b60:	e8 1b e8 ff ff       	call   2380 <getenv@plt>
    3b65:	48 89 c2             	mov    %rax,%rdx
    3b68:	31 c0                	xor    %eax,%eax
    3b6a:	48 85 d2             	test   %rdx,%rdx
    3b6d:	74 15                	je     3b84 <fwp_heap_init+0x1d4>
    3b6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    3b72:	74 10                	je     3b84 <fwp_heap_init+0x1d4>
    3b74:	0f b6 02             	movzbl (%rdx),%eax
    3b77:	83 e8 30             	sub    $0x30,%eax
    3b7a:	74 13                	je     3b8f <fwp_heap_init+0x1df>
    3b7c:	85 c0                	test   %eax,%eax
    3b7e:	0f 95 c0             	setne  %al
    3b81:	0f b6 c0             	movzbl %al,%eax
    3b84:	5b                   	pop    %rbx
    3b85:	5d                   	pop    %rbp
    3b86:	89 05 1c 9f 01 00    	mov    %eax,0x19f1c(%rip)        # 1daa8 <fwp_heap+0x13a8>
    3b8c:	41 5c                	pop    %r12
    3b8e:	c3                   	ret
    3b8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b93:	85 c0                	test   %eax,%eax
    3b95:	0f 95 c0             	setne  %al
    3b98:	0f b6 c0             	movzbl %al,%eax
    3b9b:	eb e7                	jmp    3b84 <fwp_heap_init+0x1d4>
    3b9d:	0f 1f 00             	nopl   (%rax)

0000000000003ba0 <fwp_args45>:
    3ba0:	f3 0f 1e fa          	endbr64
    3ba4:	c3                   	ret
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_args69>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	c3                   	ret
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_wake_io>:
    3bc0:	48 8b 07             	mov    (%rdi),%rax
    3bc3:	48 85 c0             	test   %rax,%rax
    3bc6:	0f 84 f4 00 00 00    	je     3cc0 <fwp_wake_io+0x100>
    3bcc:	53                   	push   %rbx
    3bcd:	4c 8b 05 ec 8a 01 00 	mov    0x18aec(%rip),%r8        # 1c6c0 <fwp_ready_tail>
    3bd4:	49 89 f9             	mov    %rdi,%r9
    3bd7:	48 89 c2             	mov    %rax,%rdx
    3bda:	45 31 db             	xor    %r11d,%r11d
    3bdd:	45 31 d2             	xor    %r10d,%r10d
    3be0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3be4:	eb 71                	jmp    3c57 <fwp_wake_io+0x97>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3bf7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bfe:	48 85 c9             	test   %rcx,%rcx
    3c01:	74 07                	je     3c0a <fwp_wake_io+0x4a>
    3c03:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3c0a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3c11:	00 00 00 00 
    3c15:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3c1c:	49 8b 01             	mov    (%r9),%rax
    3c1f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c23:	75 2a                	jne    3c4f <fwp_wake_io+0x8f>
    3c25:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c29:	75 24                	jne    3c4f <fwp_wake_io+0x8f>
    3c2b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c2f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c36:	00 00 00 00 
    3c3a:	4d 85 c0             	test   %r8,%r8
    3c3d:	74 51                	je     3c90 <fwp_wake_io+0xd0>
    3c3f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3c46:	49 89 d0             	mov    %rdx,%r8
    3c49:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3c4f:	48 89 c2             	mov    %rax,%rdx
    3c52:	48 85 c0             	test   %rax,%rax
    3c55:	74 49                	je     3ca0 <fwp_wake_io+0xe0>
    3c57:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3c5e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3c62:	48 85 ff             	test   %rdi,%rdi
    3c65:	74 b8                	je     3c1f <fwp_wake_io+0x5f>
    3c67:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3c6e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3c75:	48 85 f6             	test   %rsi,%rsi
    3c78:	0f 85 72 ff ff ff    	jne    3bf0 <fwp_wake_io+0x30>
    3c7e:	48 89 0f             	mov    %rcx,(%rdi)
    3c81:	e9 78 ff ff ff       	jmp    3bfe <fwp_wake_io+0x3e>
    3c86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3c8d:	00 00 00 
    3c90:	48 89 d3             	mov    %rdx,%rbx
    3c93:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3c99:	eb ab                	jmp    3c46 <fwp_wake_io+0x86>
    3c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ca0:	45 84 db             	test   %r11b,%r11b
    3ca3:	74 07                	je     3cac <fwp_wake_io+0xec>
    3ca5:	48 89 1d 1c 8a 01 00 	mov    %rbx,0x18a1c(%rip)        # 1c6c8 <fwp_ready_head>
    3cac:	45 84 d2             	test   %r10b,%r10b
    3caf:	74 07                	je     3cb8 <fwp_wake_io+0xf8>
    3cb1:	4c 89 05 08 8a 01 00 	mov    %r8,0x18a08(%rip)        # 1c6c0 <fwp_ready_tail>
    3cb8:	5b                   	pop    %rbx
    3cb9:	c3                   	ret
    3cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3cc0:	c3                   	ret
    3cc1:	0f 1f 40 00          	nopl   0x0(%rax)
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_poll_events>:
    3cd0:	53                   	push   %rbx
    3cd1:	48 83 ec 20          	sub    $0x20,%rsp
    3cd5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3cdc:	00 00 
    3cde:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3ce3:	31 c0                	xor    %eax,%eax
    3ce5:	e8 b6 f5 ff ff       	call   32a0 <fwp_now_ns>
    3cea:	48 8b 1d c7 89 01 00 	mov    0x189c7(%rip),%rbx        # 1c6b8 <fwp_timers>
    3cf1:	48 85 db             	test   %rbx,%rbx
    3cf4:	0f 84 e6 00 00 00    	je     3de0 <fwp_poll_events+0x110>
    3cfa:	48 89 c6             	mov    %rax,%rsi
    3cfd:	48 89 da             	mov    %rbx,%rdx
    3d00:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3d07:	eb 26                	jmp    3d2f <fwp_poll_events+0x5f>
    3d09:	90                   	nop
    3d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d11:	00 00 00 00 
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 
    3d20:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d27:	48 89 c8             	mov    %rcx,%rax
    3d2a:	48 85 d2             	test   %rdx,%rdx
    3d2d:	74 31                	je     3d60 <fwp_poll_events+0x90>
    3d2f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3d33:	48 85 c0             	test   %rax,%rax
    3d36:	78 e8                	js     3d20 <fwp_poll_events+0x50>
    3d38:	48 39 c1             	cmp    %rax,%rcx
    3d3b:	7c e3                	jl     3d20 <fwp_poll_events+0x50>
    3d3d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d44:	48 85 d2             	test   %rdx,%rdx
    3d47:	74 1c                	je     3d65 <fwp_poll_events+0x95>
    3d49:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3d4d:	48 39 c1             	cmp    %rax,%rcx
    3d50:	7c ce                	jl     3d20 <fwp_poll_events+0x50>
    3d52:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d59:	48 85 d2             	test   %rdx,%rdx
    3d5c:	75 d1                	jne    3d2f <fwp_poll_events+0x5f>
    3d5e:	66 90                	xchg   %ax,%ax
    3d60:	48 85 c0             	test   %rax,%rax
    3d63:	78 7b                	js     3de0 <fwp_poll_events+0x110>
    3d65:	48 29 f0             	sub    %rsi,%rax
    3d68:	48 89 c1             	mov    %rax,%rcx
    3d6b:	48 85 c0             	test   %rax,%rax
    3d6e:	0f 8e 9c 00 00 00    	jle    3e10 <fwp_poll_events+0x140>
    3d74:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3d7b:	de 1b 43 
    3d7e:	48 f7 ea             	imul   %rdx
    3d81:	48 89 c8             	mov    %rcx,%rax
    3d84:	48 c1 f8 3f          	sar    $0x3f,%rax
    3d88:	48 c1 fa 12          	sar    $0x12,%rdx
    3d8c:	48 29 c2             	sub    %rax,%rdx
    3d8f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3d96:	48 39 c1             	cmp    %rax,%rcx
    3d99:	0f 95 c0             	setne  %al
    3d9c:	0f b6 c0             	movzbl %al,%eax
    3d9f:	48 01 d0             	add    %rdx,%rax
    3da2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3da8:	0f 8f 32 01 00 00    	jg     3ee0 <fwp_poll_events+0x210>
    3dae:	48 85 c0             	test   %rax,%rax
    3db1:	74 5d                	je     3e10 <fwp_poll_events+0x140>
    3db3:	89 c1                	mov    %eax,%ecx
    3db5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3dbc:	48 c1 e9 26          	shr    $0x26,%rcx
    3dc0:	48 63 d1             	movslq %ecx,%rdx
    3dc3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3dc9:	29 c8                	sub    %ecx,%eax
    3dcb:	48 98                	cltq
    3dcd:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3dd4:	e9 11 01 00 00       	jmp    3eea <fwp_poll_events+0x21a>
    3dd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3de0:	e8 4b ee ff ff       	call   2c30 <fwp_flush>
    3de5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3dea:	be 01 00 00 00       	mov    $0x1,%esi
    3def:	48 8b 0d 4a 82 00 00 	mov    0x824a(%rip),%rcx        # c040 <stderr@GLIBC_2.2.5>
    3df6:	48 8d 3d 73 55 00 00 	lea    0x5573(%rip),%rdi        # 9370 <_IO_stdin_used+0x370>
    3dfd:	e8 3e e8 ff ff       	call   2640 <fwrite@plt>
    3e02:	bf 65 00 00 00       	mov    $0x65,%edi
    3e07:	e8 24 e8 ff ff       	call   2630 <exit@plt>
    3e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3e10:	e8 8b f4 ff ff       	call   32a0 <fwp_now_ns>
    3e15:	48 89 c1             	mov    %rax,%rcx
    3e18:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3e1c:	eb 44                	jmp    3e62 <fwp_poll_events+0x192>
    3e1e:	66 90                	xchg   %ax,%ax
    3e20:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3e24:	75 33                	jne    3e59 <fwp_poll_events+0x189>
    3e26:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2a:	75 2d                	jne    3e59 <fwp_poll_events+0x189>
    3e2c:	48 8b 05 8d 88 01 00 	mov    0x1888d(%rip),%rax        # 1c6c0 <fwp_ready_tail>
    3e33:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3e37:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3e3e:	00 00 00 00 
    3e42:	48 85 c0             	test   %rax,%rax
    3e45:	0f 84 05 01 00 00    	je     3f50 <fwp_poll_events+0x280>
    3e4b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3e52:	48 89 15 67 88 01 00 	mov    %rdx,0x18867(%rip)        # 1c6c0 <fwp_ready_tail>
    3e59:	48 85 db             	test   %rbx,%rbx
    3e5c:	0f 84 be 00 00 00    	je     3f20 <fwp_poll_events+0x250>
    3e62:	48 89 da             	mov    %rbx,%rdx
    3e65:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3e6c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3e70:	7f e7                	jg     3e59 <fwp_poll_events+0x189>
    3e72:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3e76:	74 2e                	je     3ea6 <fwp_poll_events+0x1d6>
    3e78:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3e7f:	48 85 c0             	test   %rax,%rax
    3e82:	0f 84 b8 00 00 00    	je     3f40 <fwp_poll_events+0x270>
    3e88:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3e8f:	48 85 db             	test   %rbx,%rbx
    3e92:	74 07                	je     3e9b <fwp_poll_events+0x1cb>
    3e94:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3e9b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3e9f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3ea6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3eaa:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3eae:	48 85 c0             	test   %rax,%rax
    3eb1:	0f 84 69 ff ff ff    	je     3e20 <fwp_poll_events+0x150>
    3eb7:	48 39 c8             	cmp    %rcx,%rax
    3eba:	0f 8f 60 ff ff ff    	jg     3e20 <fwp_poll_events+0x150>
    3ec0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ec4:	0f 85 56 ff ff ff    	jne    3e20 <fwp_poll_events+0x150>
    3eca:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3ece:	75 89                	jne    3e59 <fwp_poll_events+0x189>
    3ed0:	48 89 d7             	mov    %rdx,%rdi
    3ed3:	e8 88 f1 ff ff       	call   3060 <fwp_cancel_tree.part.0>
    3ed8:	e9 43 ff ff ff       	jmp    3e20 <fwp_poll_events+0x150>
    3edd:	0f 1f 00             	nopl   (%rax)
    3ee0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3ee5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3eea:	48 89 e7             	mov    %rsp,%rdi
    3eed:	31 f6                	xor    %esi,%esi
    3eef:	48 89 14 24          	mov    %rdx,(%rsp)
    3ef3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3ef8:	e8 83 e5 ff ff       	call   2480 <nanosleep@plt>
    3efd:	48 8b 1d b4 87 01 00 	mov    0x187b4(%rip),%rbx        # 1c6b8 <fwp_timers>
    3f04:	e8 97 f3 ff ff       	call   32a0 <fwp_now_ns>
    3f09:	48 89 c1             	mov    %rax,%rcx
    3f0c:	48 85 db             	test   %rbx,%rbx
    3f0f:	0f 85 03 ff ff ff    	jne    3e18 <fwp_poll_events+0x148>
    3f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f1c:	00 00 00 00 
    3f20:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3f25:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f2c:	00 00 
    3f2e:	75 2c                	jne    3f5c <fwp_poll_events+0x28c>
    3f30:	48 83 c4 20          	add    $0x20,%rsp
    3f34:	5b                   	pop    %rbx
    3f35:	c3                   	ret
    3f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f3d:	00 00 00 
    3f40:	48 89 1d 71 87 01 00 	mov    %rbx,0x18771(%rip)        # 1c6b8 <fwp_timers>
    3f47:	e9 43 ff ff ff       	jmp    3e8f <fwp_poll_events+0x1bf>
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 89 15 71 87 01 00 	mov    %rdx,0x18771(%rip)        # 1c6c8 <fwp_ready_head>
    3f57:	e9 f6 fe ff ff       	jmp    3e52 <fwp_poll_events+0x182>
    3f5c:	e8 df e4 ff ff       	call   2440 <__stack_chk_fail@plt>
    3f61:	0f 1f 40 00          	nopl   0x0(%rax)
    3f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f6c:	00 00 00 00 

0000000000003f70 <fwp_rc_wide_dup>:
    3f70:	48 89 fa             	mov    %rdi,%rdx
    3f73:	48 8d 35 86 87 01 00 	lea    0x18786(%rip),%rsi        # 1c700 <fwp_heap>
    3f7a:	48 83 ec 18          	sub    $0x18,%rsp
    3f7e:	48 89 f9             	mov    %rdi,%rcx
    3f81:	48 c1 ea 11          	shr    $0x11,%rdx
    3f85:	48 31 fa             	xor    %rdi,%rdx
    3f88:	48 89 d0             	mov    %rdx,%rax
    3f8b:	48 c1 e8 09          	shr    $0x9,%rax
    3f8f:	48 31 c2             	xor    %rax,%rdx
    3f92:	0f b6 d2             	movzbl %dl,%edx
    3f95:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    3f9c:	00 
    3f9d:	49 8b 00             	mov    (%r8),%rax
    3fa0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    3fa7:	00 00 
    3fa9:	75 21                	jne    3fcc <fwp_rc_wide_dup+0x5c>
    3fab:	e9 98 00 00 00       	jmp    4048 <fwp_rc_wide_dup+0xd8>
    3fb0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fbc:	00 00 00 00 
    3fc0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3fc4:	48 85 d2             	test   %rdx,%rdx
    3fc7:	74 2f                	je     3ff8 <fwp_rc_wide_dup+0x88>
    3fc9:	48 89 d0             	mov    %rdx,%rax
    3fcc:	48 3b 08             	cmp    (%rax),%rcx
    3fcf:	75 ef                	jne    3fc0 <fwp_rc_wide_dup+0x50>
    3fd1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3fd4:	74 7c                	je     4052 <fwp_rc_wide_dup+0xe2>
    3fd6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3fda:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    3fde:	0f 84 91 00 00 00    	je     4075 <fwp_rc_wide_dup+0x105>
    3fe4:	48 83 c2 01          	add    $0x1,%rdx
    3fe8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    3fec:	48 83 c4 18          	add    $0x18,%rsp
    3ff0:	c3                   	ret
    3ff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ff8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    3ffc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3fff:	75 68                	jne    4069 <fwp_rc_wide_dup+0xf9>
    4001:	bf 18 00 00 00       	mov    $0x18,%edi
    4006:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    400b:	4c 89 04 24          	mov    %r8,(%rsp)
    400f:	e8 6c e5 ff ff       	call   2580 <malloc@plt>
    4014:	4c 8b 04 24          	mov    (%rsp),%r8
    4018:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401d:	48 85 c0             	test   %rax,%rax
    4020:	74 5f                	je     4081 <fwp_rc_wide_dup+0x111>
    4022:	48 89 08             	mov    %rcx,(%rax)
    4025:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    402c:	00 
    402d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    4034:	00 
    4035:	49 89 00             	mov    %rax,(%r8)
    4038:	c6 01 ff             	movb   $0xff,(%rcx)
    403b:	48 83 05 05 a3 01 00 	addq   $0x1,0x1a305(%rip)        # 1e348 <fwp_heap+0x1c48>
    4042:	01 
    4043:	48 83 c4 18          	add    $0x18,%rsp
    4047:	c3                   	ret
    4048:	80 3f fe             	cmpb   $0xfe,(%rdi)
    404b:	75 13                	jne    4060 <fwp_rc_wide_dup+0xf0>
    404d:	48 85 c0             	test   %rax,%rax
    4050:	74 af                	je     4001 <fwp_rc_wide_dup+0x91>
    4052:	48 8d 3d 47 53 00 00 	lea    0x5347(%rip),%rdi        # 93a0 <_IO_stdin_used+0x3a0>
    4059:	e8 12 f2 ff ff       	call   3270 <fwp_trap>
    405e:	66 90                	xchg   %ax,%ax
    4060:	48 85 c0             	test   %rax,%rax
    4063:	0f 85 6d ff ff ff    	jne    3fd6 <fwp_rc_wide_dup+0x66>
    4069:	48 8d 3d 58 53 00 00 	lea    0x5358(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    4070:	e8 fb f1 ff ff       	call   3270 <fwp_trap>
    4075:	48 8d 3d 69 50 00 00 	lea    0x5069(%rip),%rdi        # 90e5 <_IO_stdin_used+0xe5>
    407c:	e8 ef f1 ff ff       	call   3270 <fwp_trap>
    4081:	e8 da ec ff ff       	call   2d60 <fwp_heap_oom>
    4086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    408d:	00 00 00 

0000000000004090 <fwp_rc_forget_slot>:
    4090:	80 3f ff             	cmpb   $0xff,(%rdi)
    4093:	74 0b                	je     40a0 <fwp_rc_forget_slot+0x10>
    4095:	c3                   	ret
    4096:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    409d:	00 00 00 
    40a0:	48 89 f8             	mov    %rdi,%rax
    40a3:	48 83 ec 08          	sub    $0x8,%rsp
    40a7:	48 89 fa             	mov    %rdi,%rdx
    40aa:	48 c1 e8 11          	shr    $0x11,%rax
    40ae:	48 31 f8             	xor    %rdi,%rax
    40b1:	48 89 c1             	mov    %rax,%rcx
    40b4:	48 c1 e9 09          	shr    $0x9,%rcx
    40b8:	48 31 c8             	xor    %rcx,%rax
    40bb:	48 8d 0d 3e 86 01 00 	lea    0x1863e(%rip),%rcx        # 1c700 <fwp_heap>
    40c2:	0f b6 c0             	movzbl %al,%eax
    40c5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    40cc:	00 
    40cd:	48 85 ff             	test   %rdi,%rdi
    40d0:	74 3c                	je     410e <fwp_rc_forget_slot+0x7e>
    40d2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    40d9:	00 
    40da:	48 8b 01             	mov    (%rcx),%rax
    40dd:	eb 11                	jmp    40f0 <fwp_rc_forget_slot+0x60>
    40df:	90                   	nop
    40e0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    40e4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    40e8:	48 85 ff             	test   %rdi,%rdi
    40eb:	74 21                	je     410e <fwp_rc_forget_slot+0x7e>
    40ed:	48 89 f8             	mov    %rdi,%rax
    40f0:	48 3b 10             	cmp    (%rax),%rdx
    40f3:	75 eb                	jne    40e0 <fwp_rc_forget_slot+0x50>
    40f5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    40f9:	48 89 01             	mov    %rax,(%rcx)
    40fc:	e8 9f e2 ff ff       	call   23a0 <free@plt>
    4101:	48 83 2d 3f a2 01 00 	subq   $0x1,0x1a23f(%rip)        # 1e348 <fwp_heap+0x1c48>
    4108:	01 
    4109:	48 83 c4 08          	add    $0x8,%rsp
    410d:	c3                   	ret
    410e:	48 8d 3d b3 52 00 00 	lea    0x52b3(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    4115:	e8 56 f1 ff ff       	call   3270 <fwp_trap>
    411a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004120 <fwp_rc_prepare_chunk>:
    4120:	48 83 3d 20 a2 01 00 	cmpq   $0x0,0x1a220(%rip)        # 1e348 <fwp_heap+0x1c48>
    4127:	00 
    4128:	41 54                	push   %r12
    412a:	49 89 f4             	mov    %rsi,%r12
    412d:	55                   	push   %rbp
    412e:	48 89 fd             	mov    %rdi,%rbp
    4131:	53                   	push   %rbx
    4132:	8b 47 1c             	mov    0x1c(%rdi),%eax
    4135:	0f 84 7d 00 00 00    	je     41b8 <fwp_rc_prepare_chunk+0x98>
    413b:	31 db                	xor    %ebx,%ebx
    413d:	85 c0                	test   %eax,%eax
    413f:	75 5f                	jne    41a0 <fwp_rc_prepare_chunk+0x80>
    4141:	48 85 f6             	test   %rsi,%rsi
    4144:	74 7c                	je     41c2 <fwp_rc_prepare_chunk+0xa2>
    4146:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    414a:	e8 51 e2 ff ff       	call   23a0 <free@plt>
    414f:	90                   	nop
    4150:	be 01 00 00 00       	mov    $0x1,%esi
    4155:	4c 89 e7             	mov    %r12,%rdi
    4158:	e8 a3 e3 ff ff       	call   2500 <calloc@plt>
    415d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    4161:	48 85 c0             	test   %rax,%rax
    4164:	0f 85 87 00 00 00    	jne    41f1 <fwp_rc_prepare_chunk+0xd1>
    416a:	e8 f1 eb ff ff       	call   2d60 <fwp_heap_oom>
    416f:	90                   	nop
    4170:	e8 1b ff ff ff       	call   4090 <fwp_rc_forget_slot>
    4175:	8b 45 1c             	mov    0x1c(%rbp),%eax
    4178:	48 83 c3 01          	add    $0x1,%rbx
    417c:	48 39 c3             	cmp    %rax,%rbx
    417f:	73 37                	jae    41b8 <fwp_rc_prepare_chunk+0x98>
    4181:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4188:	00 00 
    418a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4191:	00 00 00 00 
    4195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    419c:	00 00 00 00 
    41a0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    41a4:	48 01 df             	add    %rbx,%rdi
    41a7:	80 3f ff             	cmpb   $0xff,(%rdi)
    41aa:	74 c4                	je     4170 <fwp_rc_prepare_chunk+0x50>
    41ac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    41af:	48 83 c3 01          	add    $0x1,%rbx
    41b3:	48 39 c3             	cmp    %rax,%rbx
    41b6:	72 e8                	jb     41a0 <fwp_rc_prepare_chunk+0x80>
    41b8:	49 39 c4             	cmp    %rax,%r12
    41bb:	75 13                	jne    41d0 <fwp_rc_prepare_chunk+0xb0>
    41bd:	4d 85 e4             	test   %r12,%r12
    41c0:	75 46                	jne    4208 <fwp_rc_prepare_chunk+0xe8>
    41c2:	5b                   	pop    %rbx
    41c3:	5d                   	pop    %rbp
    41c4:	41 5c                	pop    %r12
    41c6:	c3                   	ret
    41c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    41ce:	00 00 
    41d0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    41d4:	48 29 05 75 a1 01 00 	sub    %rax,0x1a175(%rip)        # 1e350 <fwp_heap+0x1c50>
    41db:	e8 c0 e1 ff ff       	call   23a0 <free@plt>
    41e0:	4d 85 e4             	test   %r12,%r12
    41e3:	0f 85 67 ff ff ff    	jne    4150 <fwp_rc_prepare_chunk+0x30>
    41e9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    41f0:	00 
    41f1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    41f5:	5b                   	pop    %rbx
    41f6:	4c 01 25 53 a1 01 00 	add    %r12,0x1a153(%rip)        # 1e350 <fwp_heap+0x1c50>
    41fd:	5d                   	pop    %rbp
    41fe:	41 5c                	pop    %r12
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    420c:	5b                   	pop    %rbx
    420d:	4c 89 e2             	mov    %r12,%rdx
    4210:	31 f6                	xor    %esi,%esi
    4212:	5d                   	pop    %rbp
    4213:	41 5c                	pop    %r12
    4215:	e9 86 e2 ff ff       	jmp    24a0 <memset@plt>
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <fwp_heap_refill>:
    4220:	41 56                	push   %r14
    4222:	41 89 d6             	mov    %edx,%r14d
    4225:	41 55                	push   %r13
    4227:	41 89 f5             	mov    %esi,%r13d
    422a:	41 54                	push   %r12
    422c:	49 89 fc             	mov    %rdi,%r12
    422f:	bf 01 00 00 00       	mov    $0x1,%edi
    4234:	55                   	push   %rbp
    4235:	53                   	push   %rbx
    4236:	e8 65 eb ff ff       	call   2da0 <fwp_heap_chunks>
    423b:	48 89 c3             	mov    %rax,%rbx
    423e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4242:	48 8b 05 af 98 01 00 	mov    0x198af(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    4249:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    424d:	48 8d 05 ac 84 01 00 	lea    0x184ac(%rip),%rax        # 1c700 <fwp_heap>
    4254:	31 d2                	xor    %edx,%edx
    4256:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    425a:	48 89 ef             	mov    %rbp,%rdi
    425d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    4261:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    4265:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    426c:	00 
    426d:	b8 00 00 01 00       	mov    $0x10000,%eax
    4272:	f7 f1                	div    %ecx
    4274:	31 d2                	xor    %edx,%edx
    4276:	66 0f 6e c1          	movd   %ecx,%xmm0
    427a:	66 0f 6e c8          	movd   %eax,%xmm1
    427e:	89 c6                	mov    %eax,%esi
    4280:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4285:	48 01 c8             	add    %rcx,%rax
    4288:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    428c:	48 f7 f1             	div    %rcx
    428f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    4294:	89 45 18             	mov    %eax,0x18(%rbp)
    4297:	e8 84 fe ff ff       	call   4120 <fwp_rc_prepare_chunk>
    429c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    429f:	48 89 d8             	mov    %rbx,%rax
    42a2:	48 c1 e0 10          	shl    $0x10,%rax
    42a6:	48 03 05 03 98 01 00 	add    0x19803(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    42ad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    42b1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    42b6:	8b 55 08             	mov    0x8(%rbp),%edx
    42b9:	48 0f af d1          	imul   %rcx,%rdx
    42bd:	48 01 c2             	add    %rax,%rdx
    42c0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    42c5:	5b                   	pop    %rbx
    42c6:	5d                   	pop    %rbp
    42c7:	41 5c                	pop    %r12
    42c9:	41 5d                	pop    %r13
    42cb:	41 5e                	pop    %r14
    42cd:	c3                   	ret
    42ce:	66 90                	xchg   %ax,%ax

00000000000042d0 <fwp_mem_free>:
    42d0:	48 85 ff             	test   %rdi,%rdi
    42d3:	0f 84 17 02 00 00    	je     44f0 <fwp_mem_free+0x220>
    42d9:	48 8b 35 d0 97 01 00 	mov    0x197d0(%rip),%rsi        # 1dab0 <fwp_heap+0x13b0>
    42e0:	48 8b 05 f1 97 01 00 	mov    0x197f1(%rip),%rax        # 1dad8 <fwp_heap+0x13d8>
    42e7:	48 89 fa             	mov    %rdi,%rdx
    42ea:	48 29 f2             	sub    %rsi,%rdx
    42ed:	48 c1 e0 10          	shl    $0x10,%rax
    42f1:	48 39 c2             	cmp    %rax,%rdx
    42f4:	0f 83 f6 01 00 00    	jae    44f0 <fwp_mem_free+0x220>
    42fa:	49 89 d1             	mov    %rdx,%r9
    42fd:	49 c1 e9 10          	shr    $0x10,%r9
    4301:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4305:	48 c1 e0 03          	shl    $0x3,%rax
    4309:	49 89 c0             	mov    %rax,%r8
    430c:	4c 03 05 e5 97 01 00 	add    0x197e5(%rip),%r8        # 1daf8 <fwp_heap+0x13f8>
    4313:	0f 84 d7 01 00 00    	je     44f0 <fwp_mem_free+0x220>
    4319:	48 83 ec 38          	sub    $0x38,%rsp
    431d:	48 89 f9             	mov    %rdi,%rcx
    4320:	41 0f b6 38          	movzbl (%r8),%edi
    4324:	40 80 ff 01          	cmp    $0x1,%dil
    4328:	74 16                	je     4340 <fwp_mem_free+0x70>
    432a:	40 80 ff 02          	cmp    $0x2,%dil
    432e:	0f 84 94 00 00 00    	je     43c8 <fwp_mem_free+0xf8>
    4334:	48 83 c4 38          	add    $0x38,%rsp
    4338:	c3                   	ret
    4339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4340:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4344:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4349:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    434e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4352:	4d 85 d2             	test   %r10,%r10
    4355:	74 1d                	je     4374 <fwp_mem_free+0xa4>
    4357:	0f b7 c1             	movzwl %cx,%eax
    435a:	31 d2                	xor    %edx,%edx
    435c:	48 f7 f7             	div    %rdi
    435f:	49 01 c2             	add    %rax,%r10
    4362:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4366:	0f 84 44 01 00 00    	je     44b0 <fwp_mem_free+0x1e0>
    436c:	41 c6 02 00          	movb   $0x0,(%r10)
    4370:	41 8b 78 04          	mov    0x4(%r8),%edi
    4374:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    437b:	49 63 c1             	movslq %r9d,%rax
    437e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4382:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4386:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    438b:	f2 0f 58 05 ad 97 01 	addsd  0x197ad(%rip),%xmm0        # 1db40 <fwp_heap+0x1440>
    4392:	00 
    4393:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4397:	48 8d 05 62 83 01 00 	lea    0x18362(%rip),%rax        # 1c700 <fwp_heap>
    439e:	48 01 d0             	add    %rdx,%rax
    43a1:	48 8b 10             	mov    (%rax),%rdx
    43a4:	48 f7 d2             	not    %rdx
    43a7:	48 89 11             	mov    %rdx,(%rcx)
    43aa:	48 89 08             	mov    %rcx,(%rax)
    43ad:	48 29 3d 6c 97 01 00 	sub    %rdi,0x1976c(%rip)        # 1db20 <fwp_heap+0x1420>
    43b4:	f2 0f 11 05 84 97 01 	movsd  %xmm0,0x19784(%rip)        # 1db40 <fwp_heap+0x1440>
    43bb:	00 
    43bc:	48 83 c4 38          	add    $0x38,%rsp
    43c0:	c3                   	ret
    43c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    43c8:	66 31 d2             	xor    %dx,%dx
    43cb:	48 01 d6             	add    %rdx,%rsi
    43ce:	48 39 f1             	cmp    %rsi,%rcx
    43d1:	0f 85 5d ff ff ff    	jne    4334 <fwp_mem_free+0x64>
    43d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    43db:	48 29 15 3e 97 01 00 	sub    %rdx,0x1973e(%rip)        # 1db20 <fwp_heap+0x1420>
    43e2:	48 85 d2             	test   %rdx,%rdx
    43e5:	0f 88 a5 00 00 00    	js     4490 <fwp_mem_free+0x1c0>
    43eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    43ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    43f4:	f2 0f 58 05 44 97 01 	addsd  0x19744(%rip),%xmm0        # 1db40 <fwp_heap+0x1440>
    43fb:	00 
    43fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4400:	f2 0f 11 05 38 97 01 	movsd  %xmm0,0x19738(%rip)        # 1db40 <fwp_heap+0x1440>
    4407:	00 
    4408:	48 85 d2             	test   %rdx,%rdx
    440b:	74 0c                	je     4419 <fwp_mem_free+0x149>
    440d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4410:	0f 84 db 00 00 00    	je     44f1 <fwp_mem_free+0x221>
    4416:	c6 02 00             	movb   $0x0,(%rdx)
    4419:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    441d:	48 85 c9             	test   %rcx,%rcx
    4420:	74 3e                	je     4460 <fwp_mem_free+0x190>
    4422:	48 8b 15 cf 96 01 00 	mov    0x196cf(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    4429:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    442d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4431:	48 01 d0             	add    %rdx,%rax
    4434:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4438:	48 89 d6             	mov    %rdx,%rsi
    443b:	48 29 c6             	sub    %rax,%rsi
    443e:	83 e6 08             	and    $0x8,%esi
    4441:	74 0d                	je     4450 <fwp_mem_free+0x180>
    4443:	c6 00 00             	movb   $0x0,(%rax)
    4446:	48 83 c0 28          	add    $0x28,%rax
    444a:	48 39 c2             	cmp    %rax,%rdx
    444d:	74 11                	je     4460 <fwp_mem_free+0x190>
    444f:	90                   	nop
    4450:	c6 00 00             	movb   $0x0,(%rax)
    4453:	48 83 c0 50          	add    $0x50,%rax
    4457:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    445b:	48 39 c2             	cmp    %rax,%rdx
    445e:	75 f0                	jne    4450 <fwp_mem_free+0x180>
    4460:	48 01 0d c9 96 01 00 	add    %rcx,0x196c9(%rip)        # 1db30 <fwp_heap+0x1430>
    4467:	4c 3b 0d 82 96 01 00 	cmp    0x19682(%rip),%r9        # 1daf0 <fwp_heap+0x13f0>
    446e:	73 07                	jae    4477 <fwp_mem_free+0x1a7>
    4470:	4c 89 0d 79 96 01 00 	mov    %r9,0x19679(%rip)        # 1daf0 <fwp_heap+0x13f0>
    4477:	4c 3b 0d 6a 96 01 00 	cmp    0x1966a(%rip),%r9        # 1dae8 <fwp_heap+0x13e8>
    447e:	0f 83 b0 fe ff ff    	jae    4334 <fwp_mem_free+0x64>
    4484:	4c 89 0d 5d 96 01 00 	mov    %r9,0x1965d(%rip)        # 1dae8 <fwp_heap+0x13e8>
    448b:	e9 a4 fe ff ff       	jmp    4334 <fwp_mem_free+0x64>
    4490:	48 89 d1             	mov    %rdx,%rcx
    4493:	83 e2 01             	and    $0x1,%edx
    4496:	66 0f ef c0          	pxor   %xmm0,%xmm0
    449a:	48 d1 e9             	shr    $1,%rcx
    449d:	48 09 d1             	or     %rdx,%rcx
    44a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    44a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    44a9:	e9 46 ff ff ff       	jmp    43f4 <fwp_mem_free+0x124>
    44ae:	66 90                	xchg   %ax,%ax
    44b0:	4c 89 d7             	mov    %r10,%rdi
    44b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    44b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    44bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    44c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    44c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    44cb:	e8 c0 fb ff ff       	call   4090 <fwp_rc_forget_slot>
    44d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    44d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    44da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    44df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    44e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    44e9:	e9 7e fe ff ff       	jmp    436c <fwp_mem_free+0x9c>
    44ee:	66 90                	xchg   %ax,%ax
    44f0:	c3                   	ret
    44f1:	48 89 d7             	mov    %rdx,%rdi
    44f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    44f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    44fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4503:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4508:	e8 83 fb ff ff       	call   4090 <fwp_rc_forget_slot>
    450d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4512:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4517:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    451c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4521:	e9 f0 fe ff ff       	jmp    4416 <fwp_mem_free+0x146>
    4526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    452d:	00 00 00 

0000000000004530 <fwp_heap_alloc_big>:
    4530:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4537:	00 00 40 
    453a:	41 57                	push   %r15
    453c:	41 56                	push   %r14
    453e:	41 55                	push   %r13
    4540:	41 54                	push   %r12
    4542:	55                   	push   %rbp
    4543:	53                   	push   %rbx
    4544:	48 83 ec 08          	sub    $0x8,%rsp
    4548:	48 39 f8             	cmp    %rdi,%rax
    454b:	0f 82 fa 00 00 00    	jb     464b <fwp_heap_alloc_big+0x11b>
    4551:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4558:	49 89 fd             	mov    %rdi,%r13
    455b:	41 89 f6             	mov    %esi,%r14d
    455e:	48 c1 ed 10          	shr    $0x10,%rbp
    4562:	48 89 ef             	mov    %rbp,%rdi
    4565:	e8 36 e8 ff ff       	call   2da0 <fwp_heap_chunks>
    456a:	be 01 00 00 00       	mov    $0x1,%esi
    456f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4573:	49 89 c4             	mov    %rax,%r12
    4576:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    457d:	00 
    457e:	48 03 3d 73 95 01 00 	add    0x19573(%rip),%rdi        # 1daf8 <fwp_heap+0x13f8>
    4585:	c6 07 02             	movb   $0x2,(%rdi)
    4588:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    458c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    458f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4593:	e8 88 fb ff ff       	call   4120 <fwp_rc_prepare_chunk>
    4598:	48 83 fd 01          	cmp    $0x1,%rbp
    459c:	76 47                	jbe    45e5 <fwp_heap_alloc_big+0xb5>
    459e:	4c 01 e5             	add    %r12,%rbp
    45a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    45a8:	00 
    45a9:	4c 8d 3d 50 81 01 00 	lea    0x18150(%rip),%r15        # 1c700 <fwp_heap>
    45b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    45b5:	49 c1 e6 03          	shl    $0x3,%r14
    45b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    45c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    45c7:	31 f6                	xor    %esi,%esi
    45c9:	48 01 dd             	add    %rbx,%rbp
    45cc:	48 83 c3 28          	add    $0x28,%rbx
    45d0:	48 89 ef             	mov    %rbp,%rdi
    45d3:	e8 48 fb ff ff       	call   4120 <fwp_rc_prepare_chunk>
    45d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    45dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    45e0:	49 39 de             	cmp    %rbx,%r14
    45e3:	75 db                	jne    45c0 <fwp_heap_alloc_big+0x90>
    45e5:	49 c1 e4 10          	shl    $0x10,%r12
    45e9:	4c 03 25 c0 94 01 00 	add    0x194c0(%rip),%r12        # 1dab0 <fwp_heap+0x13b0>
    45f0:	4c 89 ea             	mov    %r13,%rdx
    45f3:	31 f6                	xor    %esi,%esi
    45f5:	4c 89 e7             	mov    %r12,%rdi
    45f8:	e8 a3 de ff ff       	call   24a0 <memset@plt>
    45fd:	4c 89 e8             	mov    %r13,%rax
    4600:	48 03 05 19 95 01 00 	add    0x19519(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    4607:	72 42                	jb     464b <fwp_heap_alloc_big+0x11b>
    4609:	48 39 05 18 95 01 00 	cmp    %rax,0x19518(%rip)        # 1db28 <fwp_heap+0x1428>
    4610:	48 89 05 09 95 01 00 	mov    %rax,0x19509(%rip)        # 1db20 <fwp_heap+0x1420>
    4617:	73 07                	jae    4620 <fwp_heap_alloc_big+0xf0>
    4619:	48 89 05 08 95 01 00 	mov    %rax,0x19508(%rip)        # 1db28 <fwp_heap+0x1428>
    4620:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4624:	4c 89 e0             	mov    %r12,%rax
    4627:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    462c:	f2 0f 58 05 04 95 01 	addsd  0x19504(%rip),%xmm0        # 1db38 <fwp_heap+0x1438>
    4633:	00 
    4634:	f2 0f 11 05 fc 94 01 	movsd  %xmm0,0x194fc(%rip)        # 1db38 <fwp_heap+0x1438>
    463b:	00 
    463c:	48 83 c4 08          	add    $0x8,%rsp
    4640:	5b                   	pop    %rbx
    4641:	5d                   	pop    %rbp
    4642:	41 5c                	pop    %r12
    4644:	41 5d                	pop    %r13
    4646:	41 5e                	pop    %r14
    4648:	41 5f                	pop    %r15
    464a:	c3                   	ret
    464b:	e8 10 e7 ff ff       	call   2d60 <fwp_heap_oom>

0000000000004650 <fwp_heap_alloc_slow>:
    4650:	53                   	push   %rbx
    4651:	48 89 f9             	mov    %rdi,%rcx
    4654:	41 89 f1             	mov    %esi,%r9d
    4657:	48 83 ec 10          	sub    $0x10,%rsp
    465b:	8b 05 43 94 01 00    	mov    0x19443(%rip),%eax        # 1daa4 <fwp_heap+0x13a4>
    4661:	85 c0                	test   %eax,%eax
    4663:	0f 84 c7 00 00 00    	je     4730 <fwp_heap_alloc_slow+0xe0>
    4669:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4670:	0f 87 dd 00 00 00    	ja     4753 <fwp_heap_alloc_slow+0x103>
    4676:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    467a:	48 8d 3d 7f 80 01 00 	lea    0x1807f(%rip),%rdi        # 1c700 <fwp_heap>
    4681:	49 63 f1             	movslq %r9d,%rsi
    4684:	48 c1 e8 04          	shr    $0x4,%rax
    4688:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    468f:	00 00 
    4691:	41 0f b6 c2          	movzbl %r10b,%eax
    4695:	4c 89 d2             	mov    %r10,%rdx
    4698:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    469c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    46a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    46aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    46ae:	48 01 f8             	add    %rdi,%rax
    46b1:	4c 8b 00             	mov    (%rax),%r8
    46b4:	4d 85 c0             	test   %r8,%r8
    46b7:	0f 84 ab 00 00 00    	je     4768 <fwp_heap_alloc_slow+0x118>
    46bd:	49 8b 10             	mov    (%r8),%rdx
    46c0:	48 f7 d2             	not    %rdx
    46c3:	48 89 10             	mov    %rdx,(%rax)
    46c6:	41 83 f9 01          	cmp    $0x1,%r9d
    46ca:	4c 89 c7             	mov    %r8,%rdi
    46cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    46d1:	31 f6                	xor    %esi,%esi
    46d3:	48 89 ca             	mov    %rcx,%rdx
    46d6:	e8 c5 dd ff ff       	call   24a0 <memset@plt>
    46db:	49 89 c0             	mov    %rax,%r8
    46de:	48 89 d8             	mov    %rbx,%rax
    46e1:	48 03 05 38 94 01 00 	add    0x19438(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    46e8:	0f 82 d9 00 00 00    	jb     47c7 <fwp_heap_alloc_slow+0x177>
    46ee:	48 39 05 33 94 01 00 	cmp    %rax,0x19433(%rip)        # 1db28 <fwp_heap+0x1428>
    46f5:	48 89 05 24 94 01 00 	mov    %rax,0x19424(%rip)        # 1db20 <fwp_heap+0x1420>
    46fc:	73 07                	jae    4705 <fwp_heap_alloc_slow+0xb5>
    46fe:	48 89 05 23 94 01 00 	mov    %rax,0x19423(%rip)        # 1db28 <fwp_heap+0x1428>
    4705:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4709:	4c 89 c0             	mov    %r8,%rax
    470c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4711:	f2 0f 58 05 1f 94 01 	addsd  0x1941f(%rip),%xmm0        # 1db38 <fwp_heap+0x1438>
    4718:	00 
    4719:	f2 0f 11 05 17 94 01 	movsd  %xmm0,0x19417(%rip)        # 1db38 <fwp_heap+0x1438>
    4720:	00 
    4721:	48 83 c4 10          	add    $0x10,%rsp
    4725:	5b                   	pop    %rbx
    4726:	c3                   	ret
    4727:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    472e:	00 00 
    4730:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4734:	48 89 3c 24          	mov    %rdi,(%rsp)
    4738:	e8 73 f2 ff ff       	call   39b0 <fwp_heap_init>
    473d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4741:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4746:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    474d:	0f 86 23 ff ff ff    	jbe    4676 <fwp_heap_alloc_slow+0x26>
    4753:	48 83 c4 10          	add    $0x10,%rsp
    4757:	44 89 ce             	mov    %r9d,%esi
    475a:	48 89 cf             	mov    %rcx,%rdi
    475d:	5b                   	pop    %rbx
    475e:	e9 cd fd ff ff       	jmp    4530 <fwp_heap_alloc_big>
    4763:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4768:	4c 8b 40 08          	mov    0x8(%rax),%r8
    476c:	4d 85 c0             	test   %r8,%r8
    476f:	74 1f                	je     4790 <fwp_heap_alloc_slow+0x140>
    4771:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4775:	4d 29 c3             	sub    %r8,%r11
    4778:	49 39 db             	cmp    %rbx,%r11
    477b:	72 13                	jb     4790 <fwp_heap_alloc_slow+0x140>
    477d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4781:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4785:	e9 3c ff ff ff       	jmp    46c6 <fwp_heap_alloc_slow+0x76>
    478a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4790:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4797:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    479b:	44 89 ca             	mov    %r9d,%edx
    479e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    47a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    47a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    47ab:	44 89 d6             	mov    %r10d,%esi
    47ae:	48 01 c7             	add    %rax,%rdi
    47b1:	e8 6a fa ff ff       	call   4220 <fwp_heap_refill>
    47b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    47bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    47bf:	49 89 c0             	mov    %rax,%r8
    47c2:	e9 ff fe ff ff       	jmp    46c6 <fwp_heap_alloc_slow+0x76>
    47c7:	e8 94 e5 ff ff       	call   2d60 <fwp_heap_oom>
    47cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000047d0 <fwp_rc_share>:
    47d0:	48 8b 05 01 93 01 00 	mov    0x19301(%rip),%rax        # 1dad8 <fwp_heap+0x13d8>
    47d7:	48 2b 3d d2 92 01 00 	sub    0x192d2(%rip),%rdi        # 1dab0 <fwp_heap+0x13b0>
    47de:	48 c1 e0 10          	shl    $0x10,%rax
    47e2:	48 39 c7             	cmp    %rax,%rdi
    47e5:	73 4a                	jae    4831 <fwp_rc_share+0x61>
    47e7:	48 89 f8             	mov    %rdi,%rax
    47ea:	48 c1 e8 10          	shr    $0x10,%rax
    47ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    47f2:	48 8b 05 ff 92 01 00 	mov    0x192ff(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    47f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    47fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    4801:	48 85 d2             	test   %rdx,%rdx
    4804:	74 2b                	je     4831 <fwp_rc_share+0x61>
    4806:	0f b6 08             	movzbl (%rax),%ecx
    4809:	80 f9 02             	cmp    $0x2,%cl
    480c:	74 2a                	je     4838 <fwp_rc_share+0x68>
    480e:	80 f9 01             	cmp    $0x1,%cl
    4811:	75 1e                	jne    4831 <fwp_rc_share+0x61>
    4813:	8b 48 18             	mov    0x18(%rax),%ecx
    4816:	0f b7 ff             	movzwl %di,%edi
    4819:	8b 40 1c             	mov    0x1c(%rax),%eax
    481c:	48 0f af f9          	imul   %rcx,%rdi
    4820:	48 c1 ef 20          	shr    $0x20,%rdi
    4824:	48 39 c7             	cmp    %rax,%rdi
    4827:	73 08                	jae    4831 <fwp_rc_share+0x61>
    4829:	48 01 fa             	add    %rdi,%rdx
    482c:	80 3a 00             	cmpb   $0x0,(%rdx)
    482f:	75 0d                	jne    483e <fwp_rc_share+0x6e>
    4831:	c3                   	ret
    4832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4838:	66 85 ff             	test   %di,%di
    483b:	74 ef                	je     482c <fwp_rc_share+0x5c>
    483d:	c3                   	ret
    483e:	50                   	push   %rax
    483f:	48 8d 3d aa 4b 00 00 	lea    0x4baa(%rip),%rdi        # 93f0 <_IO_stdin_used+0x3f0>
    4846:	e8 25 ea ff ff       	call   3270 <fwp_trap>
    484b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000004850 <e69>:
    4850:	f3 0f 1e fa          	endbr64
    4854:	53                   	push   %rbx
    4855:	f2 0f 10 05 93 4d 00 	movsd  0x4d93(%rip),%xmm0        # 95f0 <msg.3+0x20>
    485c:	00 
    485d:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    4861:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4866:	48 89 df             	mov    %rbx,%rdi
    4869:	e8 62 ff ff ff       	call   47d0 <fwp_rc_share>
    486e:	48 89 d8             	mov    %rbx,%rax
    4871:	5b                   	pop    %rbx
    4872:	c3                   	ret
    4873:	66 90                	xchg   %ax,%ax
    4875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    487c:	00 00 00 00 

0000000000004880 <e45>:
    4880:	f3 0f 1e fa          	endbr64
    4884:	53                   	push   %rbx
    4885:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4889:	f2 0f 58 47 08       	addsd  0x8(%rdi),%xmm0
    488e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4893:	48 89 df             	mov    %rbx,%rdi
    4896:	e8 35 ff ff ff       	call   47d0 <fwp_rc_share>
    489b:	48 89 d8             	mov    %rbx,%rax
    489e:	5b                   	pop    %rbx
    489f:	c3                   	ret

00000000000048a0 <e32>:
    48a0:	f3 0f 1e fa          	endbr64
    48a4:	53                   	push   %rbx
    48a5:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    48aa:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    48ae:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    48b3:	48 89 df             	mov    %rbx,%rdi
    48b6:	e8 15 ff ff ff       	call   47d0 <fwp_rc_share>
    48bb:	48 89 d8             	mov    %rbx,%rax
    48be:	5b                   	pop    %rbx
    48bf:	c3                   	ret

00000000000048c0 <fwp_rc_dup>:
    48c0:	f3 0f 1e fa          	endbr64
    48c4:	48 8b 05 0d 92 01 00 	mov    0x1920d(%rip),%rax        # 1dad8 <fwp_heap+0x13d8>
    48cb:	48 2b 3d de 91 01 00 	sub    0x191de(%rip),%rdi        # 1dab0 <fwp_heap+0x13b0>
    48d2:	48 c1 e0 10          	shl    $0x10,%rax
    48d6:	48 39 c7             	cmp    %rax,%rdi
    48d9:	73 60                	jae    493b <fwp_rc_dup+0x7b>
    48db:	48 89 f8             	mov    %rdi,%rax
    48de:	48 c1 e8 10          	shr    $0x10,%rax
    48e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    48e6:	48 8b 05 0b 92 01 00 	mov    0x1920b(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    48ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    48f1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    48f5:	48 85 c0             	test   %rax,%rax
    48f8:	74 41                	je     493b <fwp_rc_dup+0x7b>
    48fa:	0f b6 0a             	movzbl (%rdx),%ecx
    48fd:	80 f9 02             	cmp    $0x2,%cl
    4900:	74 3e                	je     4940 <fwp_rc_dup+0x80>
    4902:	80 f9 01             	cmp    $0x1,%cl
    4905:	75 34                	jne    493b <fwp_rc_dup+0x7b>
    4907:	8b 4a 18             	mov    0x18(%rdx),%ecx
    490a:	0f b7 ff             	movzwl %di,%edi
    490d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4910:	48 0f af f9          	imul   %rcx,%rdi
    4914:	48 c1 ef 20          	shr    $0x20,%rdi
    4918:	48 39 d7             	cmp    %rdx,%rdi
    491b:	73 1e                	jae    493b <fwp_rc_dup+0x7b>
    491d:	48 01 f8             	add    %rdi,%rax
    4920:	0f b6 10             	movzbl (%rax),%edx
    4923:	84 d2                	test   %dl,%dl
    4925:	74 14                	je     493b <fwp_rc_dup+0x7b>
    4927:	8b 0d 93 9a 01 00    	mov    0x19a93(%rip),%ecx        # 1e3c0 <iteration_active>
    492d:	85 c9                	test   %ecx,%ecx
    492f:	75 1f                	jne    4950 <fwp_rc_dup+0x90>
    4931:	80 fa fd             	cmp    $0xfd,%dl
    4934:	77 2a                	ja     4960 <fwp_rc_dup+0xa0>
    4936:	83 c2 01             	add    $0x1,%edx
    4939:	88 10                	mov    %dl,(%rax)
    493b:	c3                   	ret
    493c:	0f 1f 40 00          	nopl   0x0(%rax)
    4940:	66 85 ff             	test   %di,%di
    4943:	74 db                	je     4920 <fwp_rc_dup+0x60>
    4945:	c3                   	ret
    4946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    494d:	00 00 00 
    4950:	48 83 05 50 9a 01 00 	addq   $0x1,0x19a50(%rip)        # 1e3a8 <iteration_retains>
    4957:	01 
    4958:	eb d7                	jmp    4931 <fwp_rc_dup+0x71>
    495a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4960:	48 89 c7             	mov    %rax,%rdi
    4963:	e9 08 f6 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    4968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    496f:	00 

0000000000004970 <fwp_task_dispose>:
    4970:	53                   	push   %rbx
    4971:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4975:	0f 84 8b dd ff ff    	je     2706 <fwp_task_dispose.cold>
    497b:	48 89 fb             	mov    %rdi,%rbx
    497e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4983:	0f 85 7d dd ff ff    	jne    2706 <fwp_task_dispose.cold>
    4989:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    498d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4994:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    499b:	00 
    499c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    49a0:	48 85 ff             	test   %rdi,%rdi
    49a3:	74 07                	je     49ac <fwp_task_dispose+0x3c>
    49a5:	48 85 c0             	test   %rax,%rax
    49a8:	74 02                	je     49ac <fwp_task_dispose+0x3c>
    49aa:	ff d0                	call   *%rax
    49ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    49b3:	e8 18 f9 ff ff       	call   42d0 <fwp_mem_free>
    49b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    49bf:	00 00 00 00 
    49c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    49c7:	74 6f                	je     4a38 <fwp_task_dispose+0xc8>
    49c9:	48 8b 15 08 91 01 00 	mov    0x19108(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    49d0:	48 89 d8             	mov    %rbx,%rax
    49d3:	48 2b 05 d6 90 01 00 	sub    0x190d6(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    49da:	48 c1 e2 10          	shl    $0x10,%rdx
    49de:	48 39 d0             	cmp    %rdx,%rax
    49e1:	73 4c                	jae    4a2f <fwp_task_dispose+0xbf>
    49e3:	48 89 c2             	mov    %rax,%rdx
    49e6:	48 c1 ea 10          	shr    $0x10,%rdx
    49ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    49ee:	48 8b 15 03 91 01 00 	mov    0x19103(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    49f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    49f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    49fd:	48 85 c9             	test   %rcx,%rcx
    4a00:	74 2d                	je     4a2f <fwp_task_dispose+0xbf>
    4a02:	0f b6 32             	movzbl (%rdx),%esi
    4a05:	40 80 fe 02          	cmp    $0x2,%sil
    4a09:	74 3d                	je     4a48 <fwp_task_dispose+0xd8>
    4a0b:	40 80 fe 01          	cmp    $0x1,%sil
    4a0f:	75 1e                	jne    4a2f <fwp_task_dispose+0xbf>
    4a11:	8b 72 18             	mov    0x18(%rdx),%esi
    4a14:	0f b7 c0             	movzwl %ax,%eax
    4a17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4a1a:	48 0f af c6          	imul   %rsi,%rax
    4a1e:	48 c1 e8 20          	shr    $0x20,%rax
    4a22:	48 39 d0             	cmp    %rdx,%rax
    4a25:	73 08                	jae    4a2f <fwp_task_dispose+0xbf>
    4a27:	48 01 c1             	add    %rax,%rcx
    4a2a:	80 39 01             	cmpb   $0x1,(%rcx)
    4a2d:	74 09                	je     4a38 <fwp_task_dispose+0xc8>
    4a2f:	5b                   	pop    %rbx
    4a30:	c3                   	ret
    4a31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a38:	48 89 df             	mov    %rbx,%rdi
    4a3b:	5b                   	pop    %rbx
    4a3c:	e9 8f f8 ff ff       	jmp    42d0 <fwp_mem_free>
    4a41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a48:	66 85 c0             	test   %ax,%ax
    4a4b:	74 dd                	je     4a2a <fwp_task_dispose+0xba>
    4a4d:	5b                   	pop    %rbx
    4a4e:	c3                   	ret
    4a4f:	90                   	nop

0000000000004a50 <fwp_free_zombie>:
    4a50:	48 8b 15 79 7c 01 00 	mov    0x17c79(%rip),%rdx        # 1c6d0 <fwp_zombie>
    4a57:	48 85 d2             	test   %rdx,%rdx
    4a5a:	0f 84 98 00 00 00    	je     4af8 <fwp_free_zombie+0xa8>
    4a60:	48 3b 15 79 7c 01 00 	cmp    0x17c79(%rip),%rdx        # 1c6e0 <fwp_cur>
    4a67:	0f 84 8b 00 00 00    	je     4af8 <fwp_free_zombie+0xa8>
    4a6d:	48 83 ec 18          	sub    $0x18,%rsp
    4a71:	48 63 05 2c 76 01 00 	movslq 0x1762c(%rip),%rax        # 1c0a4 <fwp_stack_pool_n>
    4a78:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4a7c:	83 f8 3f             	cmp    $0x3f,%eax
    4a7f:	7f 7f                	jg     4b00 <fwp_free_zombie+0xb0>
    4a81:	8d 48 01             	lea    0x1(%rax),%ecx
    4a84:	89 0d 1a 76 01 00    	mov    %ecx,0x1761a(%rip)        # 1c0a4 <fwp_stack_pool_n>
    4a8a:	48 8d 0d 2f 76 01 00 	lea    0x1762f(%rip),%rcx        # 1c0c0 <fwp_stack_pool>
    4a91:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4a95:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4a9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4aa0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4aa7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4aab:	48 85 c9             	test   %rcx,%rcx
    4aae:	0f 84 fc 00 00 00    	je     4bb0 <fwp_free_zombie+0x160>
    4ab4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4abb:	48 85 c0             	test   %rax,%rax
    4abe:	74 07                	je     4ac7 <fwp_free_zombie+0x77>
    4ac0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4ac7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4aca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4ace:	48 c7 05 f7 7b 01 00 	movq   $0x0,0x17bf7(%rip)        # 1c6d0 <fwp_zombie>
    4ad5:	00 00 00 00 
    4ad9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4ae0:	85 c0                	test   %eax,%eax
    4ae2:	74 34                	je     4b18 <fwp_free_zombie+0xc8>
    4ae4:	83 f8 01             	cmp    $0x1,%eax
    4ae7:	0f 84 b3 00 00 00    	je     4ba0 <fwp_free_zombie+0x150>
    4aed:	48 83 c4 18          	add    $0x18,%rsp
    4af1:	c3                   	ret
    4af2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4af8:	c3                   	ret
    4af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4b00:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4b04:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4b09:	e8 a2 da ff ff       	call   25b0 <munmap@plt>
    4b0e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4b13:	eb 80                	jmp    4a95 <fwp_free_zombie+0x45>
    4b15:	0f 1f 00             	nopl   (%rax)
    4b18:	48 8b 0d b9 8f 01 00 	mov    0x18fb9(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    4b1f:	48 89 d0             	mov    %rdx,%rax
    4b22:	48 2b 05 87 8f 01 00 	sub    0x18f87(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    4b29:	48 c1 e1 10          	shl    $0x10,%rcx
    4b2d:	48 39 c8             	cmp    %rcx,%rax
    4b30:	73 bb                	jae    4aed <fwp_free_zombie+0x9d>
    4b32:	48 89 c1             	mov    %rax,%rcx
    4b35:	48 c1 e9 10          	shr    $0x10,%rcx
    4b39:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4b3d:	48 8b 0d b4 8f 01 00 	mov    0x18fb4(%rip),%rcx        # 1daf8 <fwp_heap+0x13f8>
    4b44:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4b48:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4b4c:	48 85 c9             	test   %rcx,%rcx
    4b4f:	74 9c                	je     4aed <fwp_free_zombie+0x9d>
    4b51:	0f b6 3e             	movzbl (%rsi),%edi
    4b54:	40 80 ff 02          	cmp    $0x2,%dil
    4b58:	74 66                	je     4bc0 <fwp_free_zombie+0x170>
    4b5a:	40 80 ff 01          	cmp    $0x1,%dil
    4b5e:	75 8d                	jne    4aed <fwp_free_zombie+0x9d>
    4b60:	8b 7e 18             	mov    0x18(%rsi),%edi
    4b63:	0f b7 c0             	movzwl %ax,%eax
    4b66:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4b69:	48 0f af c7          	imul   %rdi,%rax
    4b6d:	48 c1 e8 20          	shr    $0x20,%rax
    4b71:	48 39 f0             	cmp    %rsi,%rax
    4b74:	0f 83 73 ff ff ff    	jae    4aed <fwp_free_zombie+0x9d>
    4b7a:	48 01 c1             	add    %rax,%rcx
    4b7d:	0f b6 01             	movzbl (%rcx),%eax
    4b80:	84 c0                	test   %al,%al
    4b82:	0f 84 65 ff ff ff    	je     4aed <fwp_free_zombie+0x9d>
    4b88:	3c 01                	cmp    $0x1,%al
    4b8a:	74 14                	je     4ba0 <fwp_free_zombie+0x150>
    4b8c:	3c ff                	cmp    $0xff,%al
    4b8e:	74 3b                	je     4bcb <fwp_free_zombie+0x17b>
    4b90:	83 e8 01             	sub    $0x1,%eax
    4b93:	88 01                	mov    %al,(%rcx)
    4b95:	e9 53 ff ff ff       	jmp    4aed <fwp_free_zombie+0x9d>
    4b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ba0:	48 89 d7             	mov    %rdx,%rdi
    4ba3:	48 83 c4 18          	add    $0x18,%rsp
    4ba7:	e9 c4 fd ff ff       	jmp    4970 <fwp_task_dispose>
    4bac:	0f 1f 40 00          	nopl   0x0(%rax)
    4bb0:	48 89 05 f1 7a 01 00 	mov    %rax,0x17af1(%rip)        # 1c6a8 <fwp_tasks_active>
    4bb7:	e9 ff fe ff ff       	jmp    4abb <fwp_free_zombie+0x6b>
    4bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    4bc0:	66 85 c0             	test   %ax,%ax
    4bc3:	0f 85 24 ff ff ff    	jne    4aed <fwp_free_zombie+0x9d>
    4bc9:	eb b2                	jmp    4b7d <fwp_free_zombie+0x12d>
    4bcb:	48 89 ca             	mov    %rcx,%rdx
    4bce:	48 8d 35 2b 7b 01 00 	lea    0x17b2b(%rip),%rsi        # 1c700 <fwp_heap>
    4bd5:	48 c1 ea 11          	shr    $0x11,%rdx
    4bd9:	48 31 ca             	xor    %rcx,%rdx
    4bdc:	48 89 d0             	mov    %rdx,%rax
    4bdf:	48 c1 e8 09          	shr    $0x9,%rax
    4be3:	48 31 c2             	xor    %rax,%rdx
    4be6:	0f b6 d2             	movzbl %dl,%edx
    4be9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4bf0:	00 
    4bf1:	48 85 c0             	test   %rax,%rax
    4bf4:	75 13                	jne    4c09 <fwp_free_zombie+0x1b9>
    4bf6:	eb 4c                	jmp    4c44 <fwp_free_zombie+0x1f4>
    4bf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4bff:	00 
    4c00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4c04:	48 85 c0             	test   %rax,%rax
    4c07:	74 3b                	je     4c44 <fwp_free_zombie+0x1f4>
    4c09:	48 89 c2             	mov    %rax,%rdx
    4c0c:	48 39 08             	cmp    %rcx,(%rax)
    4c0f:	75 ef                	jne    4c00 <fwp_free_zombie+0x1b0>
    4c11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4c15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4c19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4c1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4c24:	0f 85 c3 fe ff ff    	jne    4aed <fwp_free_zombie+0x9d>
    4c2a:	48 89 cf             	mov    %rcx,%rdi
    4c2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4c32:	e8 59 f4 ff ff       	call   4090 <fwp_rc_forget_slot>
    4c37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4c3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4c3f:	e9 a9 fe ff ff       	jmp    4aed <fwp_free_zombie+0x9d>
    4c44:	48 8d 3d 7d 47 00 00 	lea    0x477d(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    4c4b:	e8 20 e6 ff ff       	call   3270 <fwp_trap>

0000000000004c50 <fwp_block>:
    4c50:	48 83 ec 08          	sub    $0x8,%rsp
    4c54:	48 8b 05 6d 7a 01 00 	mov    0x17a6d(%rip),%rax        # 1c6c8 <fwp_ready_head>
    4c5b:	48 85 c0             	test   %rax,%rax
    4c5e:	0f 84 1c 01 00 00    	je     4d80 <fwp_block+0x130>
    4c64:	90                   	nop
    4c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4c6c:	00 00 00 00 
    4c70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4c77:	48 89 15 4a 7a 01 00 	mov    %rdx,0x17a4a(%rip)        # 1c6c8 <fwp_ready_head>
    4c7e:	48 85 d2             	test   %rdx,%rdx
    4c81:	0f 84 19 01 00 00    	je     4da0 <fwp_block+0x150>
    4c87:	48 8b 15 52 7a 01 00 	mov    0x17a52(%rip),%rdx        # 1c6e0 <fwp_cur>
    4c8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4c92:	48 39 c2             	cmp    %rax,%rdx
    4c95:	0f 84 d5 00 00 00    	je     4d70 <fwp_block+0x120>
    4c9b:	48 8b 0d be 96 01 00 	mov    0x196be(%rip),%rcx        # 1e360 <fwp_state_owners>
    4ca2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4ca6:	48 89 05 33 7a 01 00 	mov    %rax,0x17a33(%rip)        # 1c6e0 <fwp_cur>
    4cad:	f3 0f 7e 05 d3 96 01 	movq   0x196d3(%rip),%xmm0        # 1e388 <fwp_foreign_callbacks>
    4cb4:	00 
    4cb5:	0f 16 05 bc 96 01 00 	movhps 0x196bc(%rip),%xmm0        # 1e378 <fwp_state>
    4cbc:	f3 0f 7e 0d bc 96 01 	movq   0x196bc(%rip),%xmm1        # 1e380 <fwp_handlers>
    4cc3:	00 
    4cc4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4ccb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4cd2:	0f 16 0d b7 96 01 00 	movhps 0x196b7(%rip),%xmm1        # 1e390 <fwp_cleanups>
    4cd9:	f3 0f 7e 05 8f 96 01 	movq   0x1968f(%rip),%xmm0        # 1e370 <fwp_state_len>
    4ce0:	00 
    4ce1:	0f 16 05 80 96 01 00 	movhps 0x19680(%rip),%xmm0        # 1e368 <fwp_state_cap>
    4ce8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4cef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4cf6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4cfa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4d01:	48 89 0d 78 96 01 00 	mov    %rcx,0x19678(%rip)        # 1e380 <fwp_handlers>
    4d08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4d0f:	48 89 0d 7a 96 01 00 	mov    %rcx,0x1967a(%rip)        # 1e390 <fwp_cleanups>
    4d16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4d1d:	48 89 0d 64 96 01 00 	mov    %rcx,0x19664(%rip)        # 1e388 <fwp_foreign_callbacks>
    4d24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4d2b:	48 89 0d 46 96 01 00 	mov    %rcx,0x19646(%rip)        # 1e378 <fwp_state>
    4d32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4d39:	48 89 0d 30 96 01 00 	mov    %rcx,0x19630(%rip)        # 1e370 <fwp_state_len>
    4d40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4d47:	48 89 0d 1a 96 01 00 	mov    %rcx,0x1961a(%rip)        # 1e368 <fwp_state_cap>
    4d4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4d55:	48 89 0d 04 96 01 00 	mov    %rcx,0x19604(%rip)        # 1e360 <fwp_state_owners>
    4d5c:	e8 0f d7 ff ff       	call   2470 <swapcontext@plt>
    4d61:	f3 0f 1e fa          	endbr64
    4d65:	e8 e6 fc ff ff       	call   4a50 <fwp_free_zombie>
    4d6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d70:	8b 05 2a 73 01 00    	mov    0x1732a(%rip),%eax        # 1c0a0 <fwp_slice>
    4d76:	85 c0                	test   %eax,%eax
    4d78:	74 36                	je     4db0 <fwp_block+0x160>
    4d7a:	48 83 c4 08          	add    $0x8,%rsp
    4d7e:	c3                   	ret
    4d7f:	90                   	nop
    4d80:	e8 4b ef ff ff       	call   3cd0 <fwp_poll_events>
    4d85:	48 8b 05 3c 79 01 00 	mov    0x1793c(%rip),%rax        # 1c6c8 <fwp_ready_head>
    4d8c:	48 85 c0             	test   %rax,%rax
    4d8f:	0f 85 db fe ff ff    	jne    4c70 <fwp_block+0x20>
    4d95:	eb e9                	jmp    4d80 <fwp_block+0x130>
    4d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4d9e:	00 00 
    4da0:	48 c7 05 15 79 01 00 	movq   $0x0,0x17915(%rip)        # 1c6c0 <fwp_ready_tail>
    4da7:	00 00 00 00 
    4dab:	e9 d7 fe ff ff       	jmp    4c87 <fwp_block+0x37>
    4db0:	48 8d 3d 47 43 00 00 	lea    0x4347(%rip),%rdi        # 90fe <_IO_stdin_used+0xfe>
    4db7:	e8 c4 d5 ff ff       	call   2380 <getenv@plt>
    4dbc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4dc1:	48 85 c0             	test   %rax,%rax
    4dc4:	74 05                	je     4dcb <fwp_block+0x17b>
    4dc6:	80 38 00             	cmpb   $0x0,(%rax)
    4dc9:	75 0b                	jne    4dd6 <fwp_block+0x186>
    4dcb:	89 15 cf 72 01 00    	mov    %edx,0x172cf(%rip)        # 1c0a0 <fwp_slice>
    4dd1:	48 83 c4 08          	add    $0x8,%rsp
    4dd5:	c3                   	ret
    4dd6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ddb:	31 f6                	xor    %esi,%esi
    4ddd:	48 89 c7             	mov    %rax,%rdi
    4de0:	e8 4b d7 ff ff       	call   2530 <strtoll@plt>
    4de5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4de9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4df0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4df5:	0f 46 d0             	cmovbe %eax,%edx
    4df8:	eb d1                	jmp    4dcb <fwp_block+0x17b>
    4dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004e00 <fwp_caps32>:
    4e00:	f3 0f 1e fa          	endbr64
    4e04:	85 f6                	test   %esi,%esi
    4e06:	74 08                	je     4e10 <fwp_caps32+0x10>
    4e08:	c3                   	ret
    4e09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e10:	48 8b 15 c1 8c 01 00 	mov    0x18cc1(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    4e17:	48 89 f8             	mov    %rdi,%rax
    4e1a:	48 2b 05 8f 8c 01 00 	sub    0x18c8f(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    4e21:	48 c1 e2 10          	shl    $0x10,%rdx
    4e25:	48 39 d0             	cmp    %rdx,%rax
    4e28:	73 de                	jae    4e08 <fwp_caps32+0x8>
    4e2a:	48 89 c2             	mov    %rax,%rdx
    4e2d:	48 c1 ea 10          	shr    $0x10,%rdx
    4e31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4e35:	48 8b 15 bc 8c 01 00 	mov    0x18cbc(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    4e3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4e40:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4e44:	48 85 c9             	test   %rcx,%rcx
    4e47:	74 bf                	je     4e08 <fwp_caps32+0x8>
    4e49:	0f b6 32             	movzbl (%rdx),%esi
    4e4c:	40 80 fe 02          	cmp    $0x2,%sil
    4e50:	74 2e                	je     4e80 <fwp_caps32+0x80>
    4e52:	40 80 fe 01          	cmp    $0x1,%sil
    4e56:	75 b0                	jne    4e08 <fwp_caps32+0x8>
    4e58:	8b 72 18             	mov    0x18(%rdx),%esi
    4e5b:	0f b7 c0             	movzwl %ax,%eax
    4e5e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4e61:	48 0f af c6          	imul   %rsi,%rax
    4e65:	48 c1 e8 20          	shr    $0x20,%rax
    4e69:	48 39 d0             	cmp    %rdx,%rax
    4e6c:	73 9a                	jae    4e08 <fwp_caps32+0x8>
    4e6e:	48 01 c1             	add    %rax,%rcx
    4e71:	80 39 01             	cmpb   $0x1,(%rcx)
    4e74:	75 92                	jne    4e08 <fwp_caps32+0x8>
    4e76:	e9 55 f4 ff ff       	jmp    42d0 <fwp_mem_free>
    4e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e80:	66 85 c0             	test   %ax,%ax
    4e83:	74 ec                	je     4e71 <fwp_caps32+0x71>
    4e85:	c3                   	ret
    4e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e8d:	00 00 00 

0000000000004e90 <fwp_caps45>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	85 f6                	test   %esi,%esi
    4e96:	74 08                	je     4ea0 <fwp_caps45+0x10>
    4e98:	c3                   	ret
    4e99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ea0:	48 8b 15 31 8c 01 00 	mov    0x18c31(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    4ea7:	48 89 f8             	mov    %rdi,%rax
    4eaa:	48 2b 05 ff 8b 01 00 	sub    0x18bff(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    4eb1:	48 c1 e2 10          	shl    $0x10,%rdx
    4eb5:	48 39 d0             	cmp    %rdx,%rax
    4eb8:	73 de                	jae    4e98 <fwp_caps45+0x8>
    4eba:	48 89 c2             	mov    %rax,%rdx
    4ebd:	48 c1 ea 10          	shr    $0x10,%rdx
    4ec1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4ec5:	48 8b 15 2c 8c 01 00 	mov    0x18c2c(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    4ecc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4ed0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4ed4:	48 85 c9             	test   %rcx,%rcx
    4ed7:	74 bf                	je     4e98 <fwp_caps45+0x8>
    4ed9:	0f b6 32             	movzbl (%rdx),%esi
    4edc:	40 80 fe 02          	cmp    $0x2,%sil
    4ee0:	74 2e                	je     4f10 <fwp_caps45+0x80>
    4ee2:	40 80 fe 01          	cmp    $0x1,%sil
    4ee6:	75 b0                	jne    4e98 <fwp_caps45+0x8>
    4ee8:	8b 72 18             	mov    0x18(%rdx),%esi
    4eeb:	0f b7 c0             	movzwl %ax,%eax
    4eee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4ef1:	48 0f af c6          	imul   %rsi,%rax
    4ef5:	48 c1 e8 20          	shr    $0x20,%rax
    4ef9:	48 39 d0             	cmp    %rdx,%rax
    4efc:	73 9a                	jae    4e98 <fwp_caps45+0x8>
    4efe:	48 01 c1             	add    %rax,%rcx
    4f01:	80 39 01             	cmpb   $0x1,(%rcx)
    4f04:	75 92                	jne    4e98 <fwp_caps45+0x8>
    4f06:	e9 c5 f3 ff ff       	jmp    42d0 <fwp_mem_free>
    4f0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f10:	66 85 c0             	test   %ax,%ax
    4f13:	74 ec                	je     4f01 <fwp_caps45+0x71>
    4f15:	c3                   	ret
    4f16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f1d:	00 00 00 

0000000000004f20 <fwp_caps69>:
    4f20:	f3 0f 1e fa          	endbr64
    4f24:	85 f6                	test   %esi,%esi
    4f26:	74 08                	je     4f30 <fwp_caps69+0x10>
    4f28:	c3                   	ret
    4f29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f30:	48 8b 15 a1 8b 01 00 	mov    0x18ba1(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    4f37:	48 89 f8             	mov    %rdi,%rax
    4f3a:	48 2b 05 6f 8b 01 00 	sub    0x18b6f(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    4f41:	48 c1 e2 10          	shl    $0x10,%rdx
    4f45:	48 39 d0             	cmp    %rdx,%rax
    4f48:	73 de                	jae    4f28 <fwp_caps69+0x8>
    4f4a:	48 89 c2             	mov    %rax,%rdx
    4f4d:	48 c1 ea 10          	shr    $0x10,%rdx
    4f51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f55:	48 8b 15 9c 8b 01 00 	mov    0x18b9c(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    4f5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f60:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f64:	48 85 c9             	test   %rcx,%rcx
    4f67:	74 bf                	je     4f28 <fwp_caps69+0x8>
    4f69:	0f b6 32             	movzbl (%rdx),%esi
    4f6c:	40 80 fe 02          	cmp    $0x2,%sil
    4f70:	74 2e                	je     4fa0 <fwp_caps69+0x80>
    4f72:	40 80 fe 01          	cmp    $0x1,%sil
    4f76:	75 b0                	jne    4f28 <fwp_caps69+0x8>
    4f78:	8b 72 18             	mov    0x18(%rdx),%esi
    4f7b:	0f b7 c0             	movzwl %ax,%eax
    4f7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4f81:	48 0f af c6          	imul   %rsi,%rax
    4f85:	48 c1 e8 20          	shr    $0x20,%rax
    4f89:	48 39 d0             	cmp    %rdx,%rax
    4f8c:	73 9a                	jae    4f28 <fwp_caps69+0x8>
    4f8e:	48 01 c1             	add    %rax,%rcx
    4f91:	80 39 01             	cmpb   $0x1,(%rcx)
    4f94:	75 92                	jne    4f28 <fwp_caps69+0x8>
    4f96:	e9 35 f3 ff ff       	jmp    42d0 <fwp_mem_free>
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	66 85 c0             	test   %ax,%ax
    4fa3:	74 ec                	je     4f91 <fwp_caps69+0x71>
    4fa5:	c3                   	ret
    4fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fad:	00 00 00 

0000000000004fb0 <fwp_caps74>:
    4fb0:	f3 0f 1e fa          	endbr64
    4fb4:	85 f6                	test   %esi,%esi
    4fb6:	74 08                	je     4fc0 <fwp_caps74+0x10>
    4fb8:	c3                   	ret
    4fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fc0:	48 8b 15 11 8b 01 00 	mov    0x18b11(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    4fc7:	48 89 f8             	mov    %rdi,%rax
    4fca:	48 2b 05 df 8a 01 00 	sub    0x18adf(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    4fd1:	48 c1 e2 10          	shl    $0x10,%rdx
    4fd5:	48 39 d0             	cmp    %rdx,%rax
    4fd8:	73 de                	jae    4fb8 <fwp_caps74+0x8>
    4fda:	48 89 c2             	mov    %rax,%rdx
    4fdd:	48 c1 ea 10          	shr    $0x10,%rdx
    4fe1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4fe5:	48 8b 15 0c 8b 01 00 	mov    0x18b0c(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    4fec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4ff0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4ff4:	48 85 c9             	test   %rcx,%rcx
    4ff7:	74 bf                	je     4fb8 <fwp_caps74+0x8>
    4ff9:	0f b6 32             	movzbl (%rdx),%esi
    4ffc:	40 80 fe 02          	cmp    $0x2,%sil
    5000:	74 2e                	je     5030 <fwp_caps74+0x80>
    5002:	40 80 fe 01          	cmp    $0x1,%sil
    5006:	75 b0                	jne    4fb8 <fwp_caps74+0x8>
    5008:	8b 72 18             	mov    0x18(%rdx),%esi
    500b:	0f b7 c0             	movzwl %ax,%eax
    500e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5011:	48 0f af c6          	imul   %rsi,%rax
    5015:	48 c1 e8 20          	shr    $0x20,%rax
    5019:	48 39 d0             	cmp    %rdx,%rax
    501c:	73 9a                	jae    4fb8 <fwp_caps74+0x8>
    501e:	48 01 c1             	add    %rax,%rcx
    5021:	80 39 01             	cmpb   $0x1,(%rcx)
    5024:	75 92                	jne    4fb8 <fwp_caps74+0x8>
    5026:	e9 a5 f2 ff ff       	jmp    42d0 <fwp_mem_free>
    502b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5030:	66 85 c0             	test   %ax,%ax
    5033:	74 ec                	je     5021 <fwp_caps74+0x71>
    5035:	c3                   	ret
    5036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    503d:	00 00 00 

0000000000005040 <fwp_data.part.0.constprop.0>:
    5040:	41 56                	push   %r14
    5042:	8b 05 5c 8a 01 00    	mov    0x18a5c(%rip),%eax        # 1daa4 <fwp_heap+0x13a4>
    5048:	41 89 fe             	mov    %edi,%r14d
    504b:	41 55                	push   %r13
    504d:	44 8b 2d 6c 93 01 00 	mov    0x1936c(%rip),%r13d        # 1e3c0 <iteration_active>
    5054:	41 54                	push   %r12
    5056:	49 89 f4             	mov    %rsi,%r12
    5059:	55                   	push   %rbp
    505a:	53                   	push   %rbx
    505b:	45 85 ed             	test   %r13d,%r13d
    505e:	0f 85 04 01 00 00    	jne    5168 <fwp_data.part.0.constprop.0+0x128>
    5064:	85 c0                	test   %eax,%eax
    5066:	0f 84 9c 01 00 00    	je     5208 <fwp_data.part.0.constprop.0+0x1c8>
    506c:	0f b6 05 2f 86 01 00 	movzbl 0x1862f(%rip),%eax        # 1d6a2 <fwp_heap+0xfa2>
    5073:	48 8d 15 86 76 01 00 	lea    0x17686(%rip),%rdx        # 1c700 <fwp_heap>
    507a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5081:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5085:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5089:	48 8b 18             	mov    (%rax),%rbx
    508c:	48 85 db             	test   %rbx,%rbx
    508f:	0f 84 03 01 00 00    	je     5198 <fwp_data.part.0.constprop.0+0x158>
    5095:	48 8b 13             	mov    (%rbx),%rdx
    5098:	48 f7 d2             	not    %rdx
    509b:	48 89 10             	mov    %rdx,(%rax)
    509e:	48 83 fd 18          	cmp    $0x18,%rbp
    50a2:	76 1b                	jbe    50bf <fwp_data.part.0.constprop.0+0x7f>
    50a4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    50a8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    50ac:	31 f6                	xor    %esi,%esi
    50ae:	48 c1 e8 03          	shr    $0x3,%rax
    50b2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    50b9:	00 
    50ba:	e8 e1 d3 ff ff       	call   24a0 <memset@plt>
    50bf:	48 89 e8             	mov    %rbp,%rax
    50c2:	48 03 05 57 8a 01 00 	add    0x18a57(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    50c9:	0f 82 4d 01 00 00    	jb     521c <fwp_data.part.0.constprop.0+0x1dc>
    50cf:	48 39 05 52 8a 01 00 	cmp    %rax,0x18a52(%rip)        # 1db28 <fwp_heap+0x1428>
    50d6:	48 89 05 43 8a 01 00 	mov    %rax,0x18a43(%rip)        # 1db20 <fwp_heap+0x1420>
    50dd:	73 07                	jae    50e6 <fwp_data.part.0.constprop.0+0xa6>
    50df:	48 89 05 42 8a 01 00 	mov    %rax,0x18a42(%rip)        # 1db28 <fwp_heap+0x1428>
    50e6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50ea:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    50ef:	f2 0f 58 05 41 8a 01 	addsd  0x18a41(%rip),%xmm0        # 1db38 <fwp_heap+0x1438>
    50f6:	00 
    50f7:	f2 0f 11 05 39 8a 01 	movsd  %xmm0,0x18a39(%rip)        # 1db38 <fwp_heap+0x1438>
    50fe:	00 
    50ff:	45 85 ed             	test   %r13d,%r13d
    5102:	74 2c                	je     5130 <fwp_data.part.0.constprop.0+0xf0>
    5104:	48 85 c0             	test   %rax,%rax
    5107:	0f 88 c8 00 00 00    	js     51d5 <fwp_data.part.0.constprop.0+0x195>
    510d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5111:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5116:	f2 0f 5c 05 82 92 01 	subsd  0x19282(%rip),%xmm0        # 1e3a0 <iteration_start_charge>
    511d:	00 
    511e:	66 0f 2f 05 72 92 01 	comisd 0x19272(%rip),%xmm0        # 1e398 <iteration_peak>
    5125:	00 
    5126:	76 08                	jbe    5130 <fwp_data.part.0.constprop.0+0xf0>
    5128:	f2 0f 11 05 68 92 01 	movsd  %xmm0,0x19268(%rip)        # 1e398 <iteration_peak>
    512f:	00 
    5130:	b8 02 00 00 00       	mov    $0x2,%eax
    5135:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    513a:	66 0f 6e c8          	movd   %eax,%xmm1
    513e:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5142:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5146:	49 8b 04 24          	mov    (%r12),%rax
    514a:	48 89 43 08          	mov    %rax,0x8(%rbx)
    514e:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5153:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5157:	48 89 d8             	mov    %rbx,%rax
    515a:	5b                   	pop    %rbx
    515b:	5d                   	pop    %rbp
    515c:	41 5c                	pop    %r12
    515e:	41 5d                	pop    %r13
    5160:	41 5e                	pop    %r14
    5162:	c3                   	ret
    5163:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5168:	48 83 05 48 92 01 00 	addq   $0x1,0x19248(%rip)        # 1e3b8 <iteration_requests>
    516f:	01 
    5170:	48 83 05 38 92 01 00 	addq   $0x18,0x19238(%rip)        # 1e3b0 <iteration_bytes>
    5177:	18 
    5178:	85 c0                	test   %eax,%eax
    517a:	0f 85 ec fe ff ff    	jne    506c <fwp_data.part.0.constprop.0+0x2c>
    5180:	31 f6                	xor    %esi,%esi
    5182:	bf 18 00 00 00       	mov    $0x18,%edi
    5187:	e8 c4 f4 ff ff       	call   4650 <fwp_heap_alloc_slow>
    518c:	48 89 c3             	mov    %rax,%rbx
    518f:	eb 34                	jmp    51c5 <fwp_data.part.0.constprop.0+0x185>
    5191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5198:	48 8b 58 08          	mov    0x8(%rax),%rbx
    519c:	48 85 db             	test   %rbx,%rbx
    519f:	74 0c                	je     51ad <fwp_data.part.0.constprop.0+0x16d>
    51a1:	48 8b 50 10          	mov    0x10(%rax),%rdx
    51a5:	48 29 da             	sub    %rbx,%rdx
    51a8:	48 39 ea             	cmp    %rbp,%rdx
    51ab:	73 4b                	jae    51f8 <fwp_data.part.0.constprop.0+0x1b8>
    51ad:	31 f6                	xor    %esi,%esi
    51af:	bf 18 00 00 00       	mov    $0x18,%edi
    51b4:	e8 97 f4 ff ff       	call   4650 <fwp_heap_alloc_slow>
    51b9:	48 89 c3             	mov    %rax,%rbx
    51bc:	45 85 ed             	test   %r13d,%r13d
    51bf:	0f 84 6b ff ff ff    	je     5130 <fwp_data.part.0.constprop.0+0xf0>
    51c5:	48 8b 05 54 89 01 00 	mov    0x18954(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    51cc:	48 85 c0             	test   %rax,%rax
    51cf:	0f 89 38 ff ff ff    	jns    510d <fwp_data.part.0.constprop.0+0xcd>
    51d5:	48 89 c2             	mov    %rax,%rdx
    51d8:	83 e0 01             	and    $0x1,%eax
    51db:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51df:	48 d1 ea             	shr    $1,%rdx
    51e2:	48 09 c2             	or     %rax,%rdx
    51e5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    51ea:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    51ee:	e9 23 ff ff ff       	jmp    5116 <fwp_data.part.0.constprop.0+0xd6>
    51f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    51f8:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    51fc:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5200:	e9 99 fe ff ff       	jmp    509e <fwp_data.part.0.constprop.0+0x5e>
    5205:	0f 1f 00             	nopl   (%rax)
    5208:	31 f6                	xor    %esi,%esi
    520a:	bf 18 00 00 00       	mov    $0x18,%edi
    520f:	e8 3c f4 ff ff       	call   4650 <fwp_heap_alloc_slow>
    5214:	48 89 c3             	mov    %rax,%rbx
    5217:	e9 14 ff ff ff       	jmp    5130 <fwp_data.part.0.constprop.0+0xf0>
    521c:	e8 3f db ff ff       	call   2d60 <fwp_heap_oom>
    5221:	0f 1f 40 00          	nopl   0x0(%rax)
    5225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    522c:	00 00 00 00 

0000000000005230 <f74>:
    5230:	66 48 0f 6e df       	movq   %rdi,%xmm3
    5235:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    523a:	48 83 ec 38          	sub    $0x38,%rsp
    523e:	31 ff                	xor    %edi,%edi
    5240:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5247:	00 00 
    5249:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    524e:	31 c0                	xor    %eax,%eax
    5250:	66 0f 28 c3          	movapd %xmm3,%xmm0
    5254:	f2 0f 10 15 a4 43 00 	movsd  0x43a4(%rip),%xmm2        # 9600 <msg.3+0x30>
    525b:	00 
    525c:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    5261:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5265:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    5269:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    526d:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    5271:	f2 0f 10 05 7f 43 00 	movsd  0x437f(%rip),%xmm0        # 95f8 <msg.3+0x28>
    5278:	00 
    5279:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    527d:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    5281:	f2 0f 59 0d 7f 43 00 	mulsd  0x437f(%rip),%xmm1        # 9608 <msg.3+0x38>
    5288:	00 
    5289:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    528d:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    5291:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5296:	e8 a5 fd ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    529b:	48 8b 15 36 88 01 00 	mov    0x18836(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    52a2:	48 89 c6             	mov    %rax,%rsi
    52a5:	48 2b 05 04 88 01 00 	sub    0x18804(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    52ac:	48 c1 e2 10          	shl    $0x10,%rdx
    52b0:	48 39 d0             	cmp    %rdx,%rax
    52b3:	73 4f                	jae    5304 <f74+0xd4>
    52b5:	48 89 c2             	mov    %rax,%rdx
    52b8:	48 c1 ea 10          	shr    $0x10,%rdx
    52bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    52c0:	48 8b 15 31 88 01 00 	mov    0x18831(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    52c7:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    52cb:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    52cf:	48 85 d2             	test   %rdx,%rdx
    52d2:	74 30                	je     5304 <f74+0xd4>
    52d4:	0f b6 39             	movzbl (%rcx),%edi
    52d7:	40 80 ff 02          	cmp    $0x2,%dil
    52db:	74 43                	je     5320 <f74+0xf0>
    52dd:	40 80 ff 01          	cmp    $0x1,%dil
    52e1:	75 21                	jne    5304 <f74+0xd4>
    52e3:	8b 79 18             	mov    0x18(%rcx),%edi
    52e6:	0f b7 c0             	movzwl %ax,%eax
    52e9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    52ec:	48 0f af c7          	imul   %rdi,%rax
    52f0:	48 c1 e8 20          	shr    $0x20,%rax
    52f4:	48 39 c8             	cmp    %rcx,%rax
    52f7:	73 0b                	jae    5304 <f74+0xd4>
    52f9:	48 01 c2             	add    %rax,%rdx
    52fc:	80 3a ff             	cmpb   $0xff,(%rdx)
    52ff:	74 2f                	je     5330 <f74+0x100>
    5301:	c6 02 01             	movb   $0x1,(%rdx)
    5304:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    5309:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5310:	00 00 
    5312:	75 38                	jne    534c <f74+0x11c>
    5314:	48 89 f0             	mov    %rsi,%rax
    5317:	48 83 c4 38          	add    $0x38,%rsp
    531b:	c3                   	ret
    531c:	0f 1f 40 00          	nopl   0x0(%rax)
    5320:	66 85 c0             	test   %ax,%ax
    5323:	75 df                	jne    5304 <f74+0xd4>
    5325:	eb d5                	jmp    52fc <f74+0xcc>
    5327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    532e:	00 00 
    5330:	48 89 d7             	mov    %rdx,%rdi
    5333:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5338:	48 89 14 24          	mov    %rdx,(%rsp)
    533c:	e8 4f ed ff ff       	call   4090 <fwp_rc_forget_slot>
    5341:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5346:	48 8b 14 24          	mov    (%rsp),%rdx
    534a:	eb b5                	jmp    5301 <f74+0xd1>
    534c:	e8 ef d0 ff ff       	call   2440 <__stack_chk_fail@plt>
    5351:	0f 1f 40 00          	nopl   0x0(%rax)
    5355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    535c:	00 00 00 00 

0000000000005360 <fwp_owned_entry74>:
    5360:	f3 0f 1e fa          	endbr64
    5364:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    5368:	48 8b 3f             	mov    (%rdi),%rdi
    536b:	e9 c0 fe ff ff       	jmp    5230 <f74>

0000000000005370 <e74>:
    5370:	f3 0f 1e fa          	endbr64
    5374:	48 83 ec 18          	sub    $0x18,%rsp
    5378:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    537c:	48 8b 3f             	mov    (%rdi),%rdi
    537f:	e8 ac fe ff ff       	call   5230 <f74>
    5384:	48 89 c7             	mov    %rax,%rdi
    5387:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    538c:	e8 3f f4 ff ff       	call   47d0 <fwp_rc_share>
    5391:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5396:	48 83 c4 18          	add    $0x18,%rsp
    539a:	c3                   	ret
    539b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000053a0 <fwp_map_finish_protected.isra.0>:
    53a0:	41 55                	push   %r13
    53a2:	41 54                	push   %r12
    53a4:	55                   	push   %rbp
    53a5:	53                   	push   %rbx
    53a6:	48 83 ec 38          	sub    $0x38,%rsp
    53aa:	48 8b 47 08          	mov    0x8(%rdi),%rax
    53ae:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    53b2:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    53b9:	00 00 
    53bb:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    53c0:	49 89 fc             	mov    %rdi,%r12
    53c3:	48 85 c0             	test   %rax,%rax
    53c6:	0f 84 d4 00 00 00    	je     54a0 <fwp_map_finish_protected.isra.0+0x100>
    53cc:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
    53d1:	4c 8d 2d 28 73 01 00 	lea    0x17328(%rip),%r13        # 1c700 <fwp_heap>
    53d8:	eb 4a                	jmp    5424 <fwp_map_finish_protected.isra.0+0x84>
    53da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    53e0:	40 80 fe 01          	cmp    $0x1,%sil
    53e4:	75 25                	jne    540b <fwp_map_finish_protected.isra.0+0x6b>
    53e6:	8b 71 18             	mov    0x18(%rcx),%esi
    53e9:	0f b7 c0             	movzwl %ax,%eax
    53ec:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    53ef:	48 0f af c6          	imul   %rsi,%rax
    53f3:	48 c1 e8 20          	shr    $0x20,%rax
    53f7:	48 39 c8             	cmp    %rcx,%rax
    53fa:	73 0f                	jae    540b <fwp_map_finish_protected.isra.0+0x6b>
    53fc:	48 01 c2             	add    %rax,%rdx
    53ff:	80 3a ff             	cmpb   $0xff,(%rdx)
    5402:	0f 84 c8 00 00 00    	je     54d0 <fwp_map_finish_protected.isra.0+0x130>
    5408:	c6 02 01             	movb   $0x1,(%rdx)
    540b:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5410:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
    5415:	48 83 e8 01          	sub    $0x1,%rax
    5419:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    541e:	0f 84 7c 00 00 00    	je     54a0 <fwp_map_finish_protected.isra.0+0x100>
    5424:	49 8b 14 24          	mov    (%r12),%rdx
    5428:	66 48 0f 6e cb       	movq   %rbx,%xmm1
    542d:	48 89 ee             	mov    %rbp,%rsi
    5430:	bf 01 00 00 00       	mov    $0x1,%edi
    5435:	f3 0f 7e 44 c2 f8    	movq   -0x8(%rdx,%rax,8),%xmm0
    543b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    543f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5444:	e8 f7 fb ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    5449:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    5450:	48 89 c3             	mov    %rax,%rbx
    5453:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    545a:	48 c1 e2 10          	shl    $0x10,%rdx
    545e:	48 39 d0             	cmp    %rdx,%rax
    5461:	73 a8                	jae    540b <fwp_map_finish_protected.isra.0+0x6b>
    5463:	48 89 c2             	mov    %rax,%rdx
    5466:	48 c1 ea 10          	shr    $0x10,%rdx
    546a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    546e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    5475:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5479:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    547d:	48 85 d2             	test   %rdx,%rdx
    5480:	74 89                	je     540b <fwp_map_finish_protected.isra.0+0x6b>
    5482:	0f b6 31             	movzbl (%rcx),%esi
    5485:	40 80 fe 02          	cmp    $0x2,%sil
    5489:	0f 85 51 ff ff ff    	jne    53e0 <fwp_map_finish_protected.isra.0+0x40>
    548f:	66 85 c0             	test   %ax,%ax
    5492:	0f 85 73 ff ff ff    	jne    540b <fwp_map_finish_protected.isra.0+0x6b>
    5498:	e9 62 ff ff ff       	jmp    53ff <fwp_map_finish_protected.isra.0+0x5f>
    549d:	0f 1f 00             	nopl   (%rax)
    54a0:	49 8b 3c 24          	mov    (%r12),%rdi
    54a4:	e8 27 ee ff ff       	call   42d0 <fwp_mem_free>
    54a9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    54ae:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    54b5:	00 00 
    54b7:	75 2e                	jne    54e7 <fwp_map_finish_protected.isra.0+0x147>
    54b9:	48 83 c4 38          	add    $0x38,%rsp
    54bd:	48 89 d8             	mov    %rbx,%rax
    54c0:	5b                   	pop    %rbx
    54c1:	5d                   	pop    %rbp
    54c2:	41 5c                	pop    %r12
    54c4:	41 5d                	pop    %r13
    54c6:	c3                   	ret
    54c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ce:	00 00 
    54d0:	48 89 d7             	mov    %rdx,%rdi
    54d3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    54d8:	e8 b3 eb ff ff       	call   4090 <fwp_rc_forget_slot>
    54dd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    54e2:	e9 21 ff ff ff       	jmp    5408 <fwp_map_finish_protected.isra.0+0x68>
    54e7:	e8 54 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    54ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000054f0 <fwp_heap_alloc>:
    54f0:	53                   	push   %rbx
    54f1:	48 89 fa             	mov    %rdi,%rdx
    54f4:	48 83 ec 10          	sub    $0x10,%rsp
    54f8:	8b 1d c2 8e 01 00    	mov    0x18ec2(%rip),%ebx        # 1e3c0 <iteration_active>
    54fe:	8b 05 a0 85 01 00    	mov    0x185a0(%rip),%eax        # 1daa4 <fwp_heap+0x13a4>
    5504:	85 db                	test   %ebx,%ebx
    5506:	0f 85 04 01 00 00    	jne    5610 <fwp_heap_alloc+0x120>
    550c:	85 c0                	test   %eax,%eax
    550e:	0f 84 ac 01 00 00    	je     56c0 <fwp_heap_alloc+0x1d0>
    5514:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    551b:	0f 87 9f 01 00 00    	ja     56c0 <fwp_heap_alloc+0x1d0>
    5521:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5525:	48 8d 05 d4 71 01 00 	lea    0x171d4(%rip),%rax        # 1c700 <fwp_heap>
    552c:	48 c1 e9 04          	shr    $0x4,%rcx
    5530:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5537:	00 
    5538:	48 63 ce             	movslq %esi,%rcx
    553b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5542:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5549:	00 
    554a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    554e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5552:	48 01 c8             	add    %rcx,%rax
    5555:	48 8b 08             	mov    (%rax),%rcx
    5558:	48 85 c9             	test   %rcx,%rcx
    555b:	0f 84 ff 00 00 00    	je     5660 <fwp_heap_alloc+0x170>
    5561:	48 8b 39             	mov    (%rcx),%rdi
    5564:	48 f7 d7             	not    %rdi
    5567:	48 89 38             	mov    %rdi,(%rax)
    556a:	83 fe 01             	cmp    $0x1,%esi
    556d:	48 89 cf             	mov    %rcx,%rdi
    5570:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5575:	49 0f 45 d0          	cmovne %r8,%rdx
    5579:	31 f6                	xor    %esi,%esi
    557b:	e8 20 cf ff ff       	call   24a0 <memset@plt>
    5580:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5585:	48 89 c1             	mov    %rax,%rcx
    5588:	4c 89 c0             	mov    %r8,%rax
    558b:	48 03 05 8e 85 01 00 	add    0x1858e(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    5592:	0f 82 35 01 00 00    	jb     56cd <fwp_heap_alloc+0x1dd>
    5598:	48 39 05 89 85 01 00 	cmp    %rax,0x18589(%rip)        # 1db28 <fwp_heap+0x1428>
    559f:	48 89 05 7a 85 01 00 	mov    %rax,0x1857a(%rip)        # 1db20 <fwp_heap+0x1420>
    55a6:	73 07                	jae    55af <fwp_heap_alloc+0xbf>
    55a8:	48 89 05 79 85 01 00 	mov    %rax,0x18579(%rip)        # 1db28 <fwp_heap+0x1428>
    55af:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55b3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    55b8:	f2 0f 58 05 78 85 01 	addsd  0x18578(%rip),%xmm0        # 1db38 <fwp_heap+0x1438>
    55bf:	00 
    55c0:	f2 0f 11 05 70 85 01 	movsd  %xmm0,0x18570(%rip)        # 1db38 <fwp_heap+0x1438>
    55c7:	00 
    55c8:	85 db                	test   %ebx,%ebx
    55ca:	74 33                	je     55ff <fwp_heap_alloc+0x10f>
    55cc:	48 8b 05 4d 85 01 00 	mov    0x1854d(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    55d3:	48 85 c0             	test   %rax,%rax
    55d6:	0f 88 ac 00 00 00    	js     5688 <fwp_heap_alloc+0x198>
    55dc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55e0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    55e5:	f2 0f 5c 05 b3 8d 01 	subsd  0x18db3(%rip),%xmm0        # 1e3a0 <iteration_start_charge>
    55ec:	00 
    55ed:	66 0f 2f 05 a3 8d 01 	comisd 0x18da3(%rip),%xmm0        # 1e398 <iteration_peak>
    55f4:	00 
    55f5:	76 08                	jbe    55ff <fwp_heap_alloc+0x10f>
    55f7:	f2 0f 11 05 99 8d 01 	movsd  %xmm0,0x18d99(%rip)        # 1e398 <iteration_peak>
    55fe:	00 
    55ff:	48 83 c4 10          	add    $0x10,%rsp
    5603:	48 89 c8             	mov    %rcx,%rax
    5606:	5b                   	pop    %rbx
    5607:	c3                   	ret
    5608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    560f:	00 
    5610:	85 f6                	test   %esi,%esi
    5612:	74 34                	je     5648 <fwp_heap_alloc+0x158>
    5614:	48 83 05 9c 8d 01 00 	addq   $0x1,0x18d9c(%rip)        # 1e3b8 <iteration_requests>
    561b:	01 
    561c:	48 01 3d 8d 8d 01 00 	add    %rdi,0x18d8d(%rip)        # 1e3b0 <iteration_bytes>
    5623:	85 c0                	test   %eax,%eax
    5625:	74 0d                	je     5634 <fwp_heap_alloc+0x144>
    5627:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    562e:	0f 86 ed fe ff ff    	jbe    5521 <fwp_heap_alloc+0x31>
    5634:	48 89 d7             	mov    %rdx,%rdi
    5637:	e8 14 f0 ff ff       	call   4650 <fwp_heap_alloc_slow>
    563c:	48 89 c1             	mov    %rax,%rcx
    563f:	eb 8b                	jmp    55cc <fwp_heap_alloc+0xdc>
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	85 c0                	test   %eax,%eax
    564a:	74 0d                	je     5659 <fwp_heap_alloc+0x169>
    564c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5653:	0f 86 c8 fe ff ff    	jbe    5521 <fwp_heap_alloc+0x31>
    5659:	31 f6                	xor    %esi,%esi
    565b:	eb d7                	jmp    5634 <fwp_heap_alloc+0x144>
    565d:	0f 1f 00             	nopl   (%rax)
    5660:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5664:	48 85 c9             	test   %rcx,%rcx
    5667:	74 0c                	je     5675 <fwp_heap_alloc+0x185>
    5669:	48 8b 78 10          	mov    0x10(%rax),%rdi
    566d:	48 29 cf             	sub    %rcx,%rdi
    5670:	4c 39 c7             	cmp    %r8,%rdi
    5673:	73 3b                	jae    56b0 <fwp_heap_alloc+0x1c0>
    5675:	48 89 d7             	mov    %rdx,%rdi
    5678:	e8 d3 ef ff ff       	call   4650 <fwp_heap_alloc_slow>
    567d:	48 89 c1             	mov    %rax,%rcx
    5680:	e9 43 ff ff ff       	jmp    55c8 <fwp_heap_alloc+0xd8>
    5685:	0f 1f 00             	nopl   (%rax)
    5688:	48 89 c2             	mov    %rax,%rdx
    568b:	83 e0 01             	and    $0x1,%eax
    568e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5692:	48 d1 ea             	shr    $1,%rdx
    5695:	48 09 c2             	or     %rax,%rdx
    5698:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    569d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    56a1:	e9 3f ff ff ff       	jmp    55e5 <fwp_heap_alloc+0xf5>
    56a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56ad:	00 00 00 
    56b0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    56b4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    56b8:	e9 ad fe ff ff       	jmp    556a <fwp_heap_alloc+0x7a>
    56bd:	0f 1f 00             	nopl   (%rax)
    56c0:	48 83 c4 10          	add    $0x10,%rsp
    56c4:	48 89 d7             	mov    %rdx,%rdi
    56c7:	5b                   	pop    %rbx
    56c8:	e9 83 ef ff ff       	jmp    4650 <fwp_heap_alloc_slow>
    56cd:	e8 8e d6 ff ff       	call   2d60 <fwp_heap_oom>
    56d2:	0f 1f 00             	nopl   (%rax)
    56d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56dc:	00 00 00 00 

00000000000056e0 <fwp_map_items>:
    56e0:	48 85 ff             	test   %rdi,%rdi
    56e3:	74 7b                	je     5760 <fwp_map_items+0x80>
    56e5:	53                   	push   %rbx
    56e6:	48 89 fa             	mov    %rdi,%rdx
    56e9:	48 89 fb             	mov    %rdi,%rbx
    56ec:	31 c0                	xor    %eax,%eax
    56ee:	66 90                	xchg   %ax,%ax
    56f0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    56f4:	48 89 c1             	mov    %rax,%rcx
    56f7:	48 83 c0 01          	add    $0x1,%rax
    56fb:	48 85 d2             	test   %rdx,%rdx
    56fe:	75 f0                	jne    56f0 <fwp_map_items+0x10>
    5700:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    5707:	ff ff 1f 
    570a:	48 89 06             	mov    %rax,(%rsi)
    570d:	48 39 c2             	cmp    %rax,%rdx
    5710:	72 64                	jb     5776 <fwp_map_items+0x96>
    5712:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    5719:	00 
    571a:	be 02 00 00 00       	mov    $0x2,%esi
    571f:	e8 cc fd ff ff       	call   54f0 <fwp_heap_alloc>
    5724:	48 89 c1             	mov    %rax,%rcx
    5727:	0f 1f 00             	nopl   (%rax)
    572a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5731:	00 00 00 00 
    5735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    573c:	00 00 00 00 
    5740:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    5744:	48 83 c0 08          	add    $0x8,%rax
    5748:	48 89 50 f8          	mov    %rdx,-0x8(%rax)
    574c:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    5750:	48 85 db             	test   %rbx,%rbx
    5753:	75 eb                	jne    5740 <fwp_map_items+0x60>
    5755:	48 89 c8             	mov    %rcx,%rax
    5758:	5b                   	pop    %rbx
    5759:	c3                   	ret
    575a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5760:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    5767:	bf 08 00 00 00       	mov    $0x8,%edi
    576c:	be 02 00 00 00       	mov    $0x2,%esi
    5771:	e9 7a fd ff ff       	jmp    54f0 <fwp_heap_alloc>
    5776:	48 8d 3d 8d 39 00 00 	lea    0x398d(%rip),%rdi        # 910a <_IO_stdin_used+0x10a>
    577d:	e8 ee da ff ff       	call   3270 <fwp_trap>
    5782:	0f 1f 00             	nopl   (%rax)
    5785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    578c:	00 00 00 00 

0000000000005790 <fwp_drop4>:
    5790:	f3 0f 1e fa          	endbr64
    5794:	48 8b 15 3d 83 01 00 	mov    0x1833d(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    579b:	48 89 f8             	mov    %rdi,%rax
    579e:	48 2b 05 0b 83 01 00 	sub    0x1830b(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    57a5:	48 c1 e2 10          	shl    $0x10,%rdx
    57a9:	48 39 d0             	cmp    %rdx,%rax
    57ac:	73 67                	jae    5815 <fwp_drop4+0x85>
    57ae:	48 89 c2             	mov    %rax,%rdx
    57b1:	48 c1 ea 10          	shr    $0x10,%rdx
    57b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    57b9:	48 8b 15 38 83 01 00 	mov    0x18338(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    57c0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    57c4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    57c8:	48 85 d2             	test   %rdx,%rdx
    57cb:	74 48                	je     5815 <fwp_drop4+0x85>
    57cd:	0f b6 31             	movzbl (%rcx),%esi
    57d0:	40 80 fe 02          	cmp    $0x2,%sil
    57d4:	74 3a                	je     5810 <fwp_drop4+0x80>
    57d6:	40 80 fe 01          	cmp    $0x1,%sil
    57da:	75 39                	jne    5815 <fwp_drop4+0x85>
    57dc:	8b 71 18             	mov    0x18(%rcx),%esi
    57df:	0f b7 c0             	movzwl %ax,%eax
    57e2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    57e5:	48 0f af c6          	imul   %rsi,%rax
    57e9:	48 c1 e8 20          	shr    $0x20,%rax
    57ed:	48 39 c8             	cmp    %rcx,%rax
    57f0:	73 23                	jae    5815 <fwp_drop4+0x85>
    57f2:	48 01 c2             	add    %rax,%rdx
    57f5:	0f b6 02             	movzbl (%rdx),%eax
    57f8:	84 c0                	test   %al,%al
    57fa:	74 19                	je     5815 <fwp_drop4+0x85>
    57fc:	3c 01                	cmp    $0x1,%al
    57fe:	74 20                	je     5820 <fwp_drop4+0x90>
    5800:	3c ff                	cmp    $0xff,%al
    5802:	74 24                	je     5828 <fwp_drop4+0x98>
    5804:	83 e8 01             	sub    $0x1,%eax
    5807:	88 02                	mov    %al,(%rdx)
    5809:	c3                   	ret
    580a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5810:	66 85 c0             	test   %ax,%ax
    5813:	74 e0                	je     57f5 <fwp_drop4+0x65>
    5815:	c3                   	ret
    5816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    581d:	00 00 00 
    5820:	e9 ab ea ff ff       	jmp    42d0 <fwp_mem_free>
    5825:	0f 1f 00             	nopl   (%rax)
    5828:	48 89 d0             	mov    %rdx,%rax
    582b:	48 8d 35 ce 6e 01 00 	lea    0x16ece(%rip),%rsi        # 1c700 <fwp_heap>
    5832:	48 83 ec 18          	sub    $0x18,%rsp
    5836:	48 c1 e8 11          	shr    $0x11,%rax
    583a:	48 31 d0             	xor    %rdx,%rax
    583d:	48 89 c1             	mov    %rax,%rcx
    5840:	48 c1 e9 09          	shr    $0x9,%rcx
    5844:	48 31 c8             	xor    %rcx,%rax
    5847:	0f b6 c8             	movzbl %al,%ecx
    584a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5851:	00 
    5852:	48 85 c0             	test   %rax,%rax
    5855:	75 12                	jne    5869 <fwp_drop4+0xd9>
    5857:	eb 49                	jmp    58a2 <fwp_drop4+0x112>
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5864:	48 85 c0             	test   %rax,%rax
    5867:	74 39                	je     58a2 <fwp_drop4+0x112>
    5869:	48 89 c1             	mov    %rax,%rcx
    586c:	48 39 10             	cmp    %rdx,(%rax)
    586f:	75 ef                	jne    5860 <fwp_drop4+0xd0>
    5871:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5875:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5879:	48 89 48 08          	mov    %rcx,0x8(%rax)
    587d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5884:	74 05                	je     588b <fwp_drop4+0xfb>
    5886:	48 83 c4 18          	add    $0x18,%rsp
    588a:	c3                   	ret
    588b:	48 89 d7             	mov    %rdx,%rdi
    588e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5893:	e8 f8 e7 ff ff       	call   4090 <fwp_rc_forget_slot>
    5898:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    589d:	c6 02 fe             	movb   $0xfe,(%rdx)
    58a0:	eb e4                	jmp    5886 <fwp_drop4+0xf6>
    58a2:	48 8d 3d 1f 3b 00 00 	lea    0x3b1f(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    58a9:	e8 c2 d9 ff ff       	call   3270 <fwp_trap>
    58ae:	66 90                	xchg   %ax,%ax

00000000000058b0 <fwp_owned_entry50>:
    58b0:	f3 0f 1e fa          	endbr64
    58b4:	53                   	push   %rbx
    58b5:	48 8b 3f             	mov    (%rdi),%rdi
    58b8:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    58bc:	e8 cf fe ff ff       	call   5790 <fwp_drop4>
    58c1:	48 89 d8             	mov    %rbx,%rax
    58c4:	5b                   	pop    %rbx
    58c5:	c3                   	ret
    58c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    58cd:	00 00 00 

00000000000058d0 <fwp_owned_entry47>:
    58d0:	f3 0f 1e fa          	endbr64
    58d4:	53                   	push   %rbx
    58d5:	48 8b 3f             	mov    (%rdi),%rdi
    58d8:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    58dc:	e8 af fe ff ff       	call   5790 <fwp_drop4>
    58e1:	48 89 d8             	mov    %rbx,%rax
    58e4:	5b                   	pop    %rbx
    58e5:	c3                   	ret
    58e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    58ed:	00 00 00 

00000000000058f0 <fwp_arg_drop47>:
    58f0:	f3 0f 1e fa          	endbr64
    58f4:	85 f6                	test   %esi,%esi
    58f6:	75 04                	jne    58fc <fwp_arg_drop47+0xc>
    58f8:	85 d2                	test   %edx,%edx
    58fa:	75 04                	jne    5900 <fwp_arg_drop47+0x10>
    58fc:	c3                   	ret
    58fd:	0f 1f 00             	nopl   (%rax)
    5900:	48 8b 3f             	mov    (%rdi),%rdi
    5903:	e9 88 fe ff ff       	jmp    5790 <fwp_drop4>
    5908:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    590f:	00 

0000000000005910 <e50>:
    5910:	f3 0f 1e fa          	endbr64
    5914:	55                   	push   %rbp
    5915:	53                   	push   %rbx
    5916:	48 83 ec 08          	sub    $0x8,%rsp
    591a:	48 8b 1f             	mov    (%rdi),%rbx
    591d:	48 89 df             	mov    %rbx,%rdi
    5920:	e8 ab ee ff ff       	call   47d0 <fwp_rc_share>
    5925:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    5929:	48 89 df             	mov    %rbx,%rdi
    592c:	e8 5f fe ff ff       	call   5790 <fwp_drop4>
    5931:	48 89 ef             	mov    %rbp,%rdi
    5934:	e8 97 ee ff ff       	call   47d0 <fwp_rc_share>
    5939:	48 83 c4 08          	add    $0x8,%rsp
    593d:	48 89 e8             	mov    %rbp,%rax
    5940:	5b                   	pop    %rbx
    5941:	5d                   	pop    %rbp
    5942:	c3                   	ret
    5943:	66 90                	xchg   %ax,%ax
    5945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    594c:	00 00 00 00 

0000000000005950 <e47>:
    5950:	f3 0f 1e fa          	endbr64
    5954:	55                   	push   %rbp
    5955:	53                   	push   %rbx
    5956:	48 83 ec 08          	sub    $0x8,%rsp
    595a:	48 8b 1f             	mov    (%rdi),%rbx
    595d:	48 89 df             	mov    %rbx,%rdi
    5960:	e8 6b ee ff ff       	call   47d0 <fwp_rc_share>
    5965:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
    5969:	48 89 df             	mov    %rbx,%rdi
    596c:	e8 1f fe ff ff       	call   5790 <fwp_drop4>
    5971:	48 89 ef             	mov    %rbp,%rdi
    5974:	e8 57 ee ff ff       	call   47d0 <fwp_rc_share>
    5979:	48 83 c4 08          	add    $0x8,%rsp
    597d:	48 89 e8             	mov    %rbp,%rax
    5980:	5b                   	pop    %rbx
    5981:	5d                   	pop    %rbp
    5982:	c3                   	ret
    5983:	66 90                	xchg   %ax,%ax
    5985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    598c:	00 00 00 00 

0000000000005990 <fwp_arg_drop50>:
    5990:	f3 0f 1e fa          	endbr64
    5994:	85 f6                	test   %esi,%esi
    5996:	75 04                	jne    599c <fwp_arg_drop50+0xc>
    5998:	85 d2                	test   %edx,%edx
    599a:	75 04                	jne    59a0 <fwp_arg_drop50+0x10>
    599c:	c3                   	ret
    599d:	0f 1f 00             	nopl   (%rax)
    59a0:	48 8b 3f             	mov    (%rdi),%rdi
    59a3:	e9 e8 fd ff ff       	jmp    5790 <fwp_drop4>
    59a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    59af:	00 

00000000000059b0 <fwp_drop0>:
    59b0:	f3 0f 1e fa          	endbr64
    59b4:	48 8b 15 1d 81 01 00 	mov    0x1811d(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    59bb:	48 89 f8             	mov    %rdi,%rax
    59be:	48 2b 05 eb 80 01 00 	sub    0x180eb(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    59c5:	48 c1 e2 10          	shl    $0x10,%rdx
    59c9:	48 39 d0             	cmp    %rdx,%rax
    59cc:	0f 83 36 01 00 00    	jae    5b08 <fwp_drop0+0x158>
    59d2:	48 83 ec 18          	sub    $0x18,%rsp
    59d6:	48 8d 35 23 6d 01 00 	lea    0x16d23(%rip),%rsi        # 1c700 <fwp_heap>
    59dd:	48 89 c2             	mov    %rax,%rdx
    59e0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    59e7:	48 c1 ea 10          	shr    $0x10,%rdx
    59eb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    59ef:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    59f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    59f7:	48 85 d2             	test   %rdx,%rdx
    59fa:	74 42                	je     5a3e <fwp_drop0+0x8e>
    59fc:	44 0f b6 01          	movzbl (%rcx),%r8d
    5a00:	41 80 f8 02          	cmp    $0x2,%r8b
    5a04:	74 42                	je     5a48 <fwp_drop0+0x98>
    5a06:	41 80 f8 01          	cmp    $0x1,%r8b
    5a0a:	75 32                	jne    5a3e <fwp_drop0+0x8e>
    5a0c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    5a10:	0f b7 c0             	movzwl %ax,%eax
    5a13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5a16:	49 0f af c0          	imul   %r8,%rax
    5a1a:	48 c1 e8 20          	shr    $0x20,%rax
    5a1e:	48 39 c8             	cmp    %rcx,%rax
    5a21:	73 1b                	jae    5a3e <fwp_drop0+0x8e>
    5a23:	48 01 c2             	add    %rax,%rdx
    5a26:	0f b6 02             	movzbl (%rdx),%eax
    5a29:	84 c0                	test   %al,%al
    5a2b:	74 11                	je     5a3e <fwp_drop0+0x8e>
    5a2d:	3c 01                	cmp    $0x1,%al
    5a2f:	74 27                	je     5a58 <fwp_drop0+0xa8>
    5a31:	3c ff                	cmp    $0xff,%al
    5a33:	0f 84 e7 00 00 00    	je     5b20 <fwp_drop0+0x170>
    5a39:	83 e8 01             	sub    $0x1,%eax
    5a3c:	88 02                	mov    %al,(%rdx)
    5a3e:	48 83 c4 18          	add    $0x18,%rsp
    5a42:	c3                   	ret
    5a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5a48:	66 85 c0             	test   %ax,%ax
    5a4b:	74 d9                	je     5a26 <fwp_drop0+0x76>
    5a4d:	48 83 c4 18          	add    $0x18,%rsp
    5a51:	c3                   	ret
    5a52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a58:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5a5f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5a66:	48 89 f8             	mov    %rdi,%rax
    5a69:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    5a6d:	48 29 c8             	sub    %rcx,%rax
    5a70:	48 c1 e2 10          	shl    $0x10,%rdx
    5a74:	48 39 d0             	cmp    %rdx,%rax
    5a77:	73 71                	jae    5aea <fwp_drop0+0x13a>
    5a79:	49 89 c2             	mov    %rax,%r10
    5a7c:	49 c1 ea 10          	shr    $0x10,%r10
    5a80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    5a84:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    5a88:	4d 8b 51 20          	mov    0x20(%r9),%r10
    5a8c:	4d 85 d2             	test   %r10,%r10
    5a8f:	74 59                	je     5aea <fwp_drop0+0x13a>
    5a91:	45 0f b6 19          	movzbl (%r9),%r11d
    5a95:	41 80 fb 02          	cmp    $0x2,%r11b
    5a99:	74 75                	je     5b10 <fwp_drop0+0x160>
    5a9b:	41 80 fb 01          	cmp    $0x1,%r11b
    5a9f:	75 49                	jne    5aea <fwp_drop0+0x13a>
    5aa1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    5aa5:	0f b7 c0             	movzwl %ax,%eax
    5aa8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    5aac:	49 0f af c3          	imul   %r11,%rax
    5ab0:	48 c1 e8 20          	shr    $0x20,%rax
    5ab4:	4c 39 c8             	cmp    %r9,%rax
    5ab7:	73 31                	jae    5aea <fwp_drop0+0x13a>
    5ab9:	49 01 c2             	add    %rax,%r10
    5abc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5ac0:	75 28                	jne    5aea <fwp_drop0+0x13a>
    5ac2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ac7:	e8 04 e8 ff ff       	call   42d0 <fwp_mem_free>
    5acc:	48 8d 35 2d 6c 01 00 	lea    0x16c2d(%rip),%rsi        # 1c700 <fwp_heap>
    5ad3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5ad8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5adf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5ae6:	48 c1 e2 10          	shl    $0x10,%rdx
    5aea:	4c 89 c0             	mov    %r8,%rax
    5aed:	48 29 c8             	sub    %rcx,%rax
    5af0:	48 39 d0             	cmp    %rdx,%rax
    5af3:	0f 83 45 ff ff ff    	jae    5a3e <fwp_drop0+0x8e>
    5af9:	4c 89 c7             	mov    %r8,%rdi
    5afc:	e9 dc fe ff ff       	jmp    59dd <fwp_drop0+0x2d>
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	c3                   	ret
    5b09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b10:	66 85 c0             	test   %ax,%ax
    5b13:	75 d5                	jne    5aea <fwp_drop0+0x13a>
    5b15:	eb a5                	jmp    5abc <fwp_drop0+0x10c>
    5b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b1e:	00 00 
    5b20:	48 89 d0             	mov    %rdx,%rax
    5b23:	48 c1 e8 11          	shr    $0x11,%rax
    5b27:	48 31 d0             	xor    %rdx,%rax
    5b2a:	48 89 c1             	mov    %rax,%rcx
    5b2d:	48 c1 e9 09          	shr    $0x9,%rcx
    5b31:	48 31 c8             	xor    %rcx,%rax
    5b34:	0f b6 c8             	movzbl %al,%ecx
    5b37:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5b3e:	00 
    5b3f:	48 85 c0             	test   %rax,%rax
    5b42:	75 25                	jne    5b69 <fwp_drop0+0x1b9>
    5b44:	eb 5e                	jmp    5ba4 <fwp_drop0+0x1f4>
    5b46:	0f 1f 40 00          	nopl   0x0(%rax)
    5b4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5b51:	00 00 00 00 
    5b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5b5c:	00 00 00 00 
    5b60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5b64:	48 85 c0             	test   %rax,%rax
    5b67:	74 3b                	je     5ba4 <fwp_drop0+0x1f4>
    5b69:	48 89 c1             	mov    %rax,%rcx
    5b6c:	48 39 10             	cmp    %rdx,(%rax)
    5b6f:	75 ef                	jne    5b60 <fwp_drop0+0x1b0>
    5b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5b75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5b79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    5b7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5b84:	0f 85 b4 fe ff ff    	jne    5a3e <fwp_drop0+0x8e>
    5b8a:	48 89 d7             	mov    %rdx,%rdi
    5b8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5b92:	e8 f9 e4 ff ff       	call   4090 <fwp_rc_forget_slot>
    5b97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5b9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    5b9f:	e9 9a fe ff ff       	jmp    5a3e <fwp_drop0+0x8e>
    5ba4:	48 8d 3d 1d 38 00 00 	lea    0x381d(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    5bab:	e8 c0 d6 ff ff       	call   3270 <fwp_trap>

0000000000005bb0 <fwp_drop1>:
    5bb0:	f3 0f 1e fa          	endbr64
    5bb4:	e9 f7 fd ff ff       	jmp    59b0 <fwp_drop0>
    5bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005bc0 <fwp_drop6>:
    5bc0:	f3 0f 1e fa          	endbr64
    5bc4:	48 8b 0d 0d 7f 01 00 	mov    0x17f0d(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    5bcb:	48 89 f8             	mov    %rdi,%rax
    5bce:	48 2b 05 db 7e 01 00 	sub    0x17edb(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    5bd5:	48 c1 e1 10          	shl    $0x10,%rcx
    5bd9:	48 39 c8             	cmp    %rcx,%rax
    5bdc:	0f 83 56 01 00 00    	jae    5d38 <fwp_drop6+0x178>
    5be2:	48 83 ec 18          	sub    $0x18,%rsp
    5be6:	48 89 fa             	mov    %rdi,%rdx
    5be9:	4c 8d 05 10 6b 01 00 	lea    0x16b10(%rip),%r8        # 1c700 <fwp_heap>
    5bf0:	48 89 c1             	mov    %rax,%rcx
    5bf3:	48 c1 e9 10          	shr    $0x10,%rcx
    5bf7:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5bfb:	49 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%rcx
    5c02:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    5c06:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    5c0a:	48 85 c9             	test   %rcx,%rcx
    5c0d:	74 40                	je     5c4f <fwp_drop6+0x8f>
    5c0f:	0f b6 3e             	movzbl (%rsi),%edi
    5c12:	40 80 ff 02          	cmp    $0x2,%dil
    5c16:	74 40                	je     5c58 <fwp_drop6+0x98>
    5c18:	40 80 ff 01          	cmp    $0x1,%dil
    5c1c:	75 31                	jne    5c4f <fwp_drop6+0x8f>
    5c1e:	8b 7e 18             	mov    0x18(%rsi),%edi
    5c21:	0f b7 c0             	movzwl %ax,%eax
    5c24:	8b 76 1c             	mov    0x1c(%rsi),%esi
    5c27:	48 0f af c7          	imul   %rdi,%rax
    5c2b:	48 c1 e8 20          	shr    $0x20,%rax
    5c2f:	48 39 f0             	cmp    %rsi,%rax
    5c32:	73 1b                	jae    5c4f <fwp_drop6+0x8f>
    5c34:	48 01 c1             	add    %rax,%rcx
    5c37:	0f b6 01             	movzbl (%rcx),%eax
    5c3a:	84 c0                	test   %al,%al
    5c3c:	74 11                	je     5c4f <fwp_drop6+0x8f>
    5c3e:	3c 01                	cmp    $0x1,%al
    5c40:	74 26                	je     5c68 <fwp_drop6+0xa8>
    5c42:	3c ff                	cmp    $0xff,%al
    5c44:	0f 84 06 01 00 00    	je     5d50 <fwp_drop6+0x190>
    5c4a:	83 e8 01             	sub    $0x1,%eax
    5c4d:	88 01                	mov    %al,(%rcx)
    5c4f:	48 83 c4 18          	add    $0x18,%rsp
    5c53:	c3                   	ret
    5c54:	0f 1f 40 00          	nopl   0x0(%rax)
    5c58:	66 85 c0             	test   %ax,%ax
    5c5b:	74 da                	je     5c37 <fwp_drop6+0x77>
    5c5d:	48 83 c4 18          	add    $0x18,%rsp
    5c61:	c3                   	ret
    5c62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c68:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    5c6c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c71:	e8 1a fb ff ff       	call   5790 <fwp_drop4>
    5c76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c7b:	4c 8d 05 7e 6a 01 00 	lea    0x16a7e(%rip),%r8        # 1c700 <fwp_heap>
    5c82:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5c89:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5c90:	48 89 d0             	mov    %rdx,%rax
    5c93:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    5c97:	48 29 f0             	sub    %rsi,%rax
    5c9a:	48 c1 e1 10          	shl    $0x10,%rcx
    5c9e:	48 39 c8             	cmp    %rcx,%rax
    5ca1:	73 7a                	jae    5d1d <fwp_drop6+0x15d>
    5ca3:	48 89 c7             	mov    %rax,%rdi
    5ca6:	48 c1 ef 10          	shr    $0x10,%rdi
    5caa:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
    5cae:	49 8b b8 f8 13 00 00 	mov    0x13f8(%r8),%rdi
    5cb5:	4a 8d 3c d7          	lea    (%rdi,%r10,8),%rdi
    5cb9:	4c 8b 57 20          	mov    0x20(%rdi),%r10
    5cbd:	4d 85 d2             	test   %r10,%r10
    5cc0:	74 5b                	je     5d1d <fwp_drop6+0x15d>
    5cc2:	44 0f b6 1f          	movzbl (%rdi),%r11d
    5cc6:	41 80 fb 02          	cmp    $0x2,%r11b
    5cca:	74 74                	je     5d40 <fwp_drop6+0x180>
    5ccc:	41 80 fb 01          	cmp    $0x1,%r11b
    5cd0:	75 4b                	jne    5d1d <fwp_drop6+0x15d>
    5cd2:	44 8b 5f 18          	mov    0x18(%rdi),%r11d
    5cd6:	0f b7 c0             	movzwl %ax,%eax
    5cd9:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    5cdc:	49 0f af c3          	imul   %r11,%rax
    5ce0:	48 c1 e8 20          	shr    $0x20,%rax
    5ce4:	48 39 f8             	cmp    %rdi,%rax
    5ce7:	73 34                	jae    5d1d <fwp_drop6+0x15d>
    5ce9:	49 01 c2             	add    %rax,%r10
    5cec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5cf0:	75 2b                	jne    5d1d <fwp_drop6+0x15d>
    5cf2:	48 89 d7             	mov    %rdx,%rdi
    5cf5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5cfa:	e8 d1 e5 ff ff       	call   42d0 <fwp_mem_free>
    5cff:	4c 8d 05 fa 69 01 00 	lea    0x169fa(%rip),%r8        # 1c700 <fwp_heap>
    5d06:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d0b:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5d12:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5d19:	48 c1 e1 10          	shl    $0x10,%rcx
    5d1d:	4c 89 c8             	mov    %r9,%rax
    5d20:	48 29 f0             	sub    %rsi,%rax
    5d23:	48 39 c8             	cmp    %rcx,%rax
    5d26:	0f 83 23 ff ff ff    	jae    5c4f <fwp_drop6+0x8f>
    5d2c:	4c 89 ca             	mov    %r9,%rdx
    5d2f:	e9 bc fe ff ff       	jmp    5bf0 <fwp_drop6+0x30>
    5d34:	0f 1f 40 00          	nopl   0x0(%rax)
    5d38:	c3                   	ret
    5d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d40:	66 85 c0             	test   %ax,%ax
    5d43:	75 d8                	jne    5d1d <fwp_drop6+0x15d>
    5d45:	eb a5                	jmp    5cec <fwp_drop6+0x12c>
    5d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5d4e:	00 00 
    5d50:	48 89 c8             	mov    %rcx,%rax
    5d53:	48 c1 e8 11          	shr    $0x11,%rax
    5d57:	48 31 c8             	xor    %rcx,%rax
    5d5a:	48 89 c2             	mov    %rax,%rdx
    5d5d:	48 c1 ea 09          	shr    $0x9,%rdx
    5d61:	48 31 d0             	xor    %rdx,%rax
    5d64:	0f b6 d0             	movzbl %al,%edx
    5d67:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    5d6e:	00 
    5d6f:	48 85 c0             	test   %rax,%rax
    5d72:	75 15                	jne    5d89 <fwp_drop6+0x1c9>
    5d74:	eb 4e                	jmp    5dc4 <fwp_drop6+0x204>
    5d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5d7d:	00 00 00 
    5d80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    5d84:	48 85 c0             	test   %rax,%rax
    5d87:	74 3b                	je     5dc4 <fwp_drop6+0x204>
    5d89:	48 89 c2             	mov    %rax,%rdx
    5d8c:	48 39 08             	cmp    %rcx,(%rax)
    5d8f:	75 ef                	jne    5d80 <fwp_drop6+0x1c0>
    5d91:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5d95:	48 83 ea 01          	sub    $0x1,%rdx
    5d99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5d9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    5da4:	0f 85 a5 fe ff ff    	jne    5c4f <fwp_drop6+0x8f>
    5daa:	48 89 cf             	mov    %rcx,%rdi
    5dad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5db2:	e8 d9 e2 ff ff       	call   4090 <fwp_rc_forget_slot>
    5db7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5dbc:	c6 01 fe             	movb   $0xfe,(%rcx)
    5dbf:	e9 8b fe ff ff       	jmp    5c4f <fwp_drop6+0x8f>
    5dc4:	48 8d 3d fd 35 00 00 	lea    0x35fd(%rip),%rdi        # 93c8 <_IO_stdin_used+0x3c8>
    5dcb:	e8 a0 d4 ff ff       	call   3270 <fwp_trap>

0000000000005dd0 <fwp_args47>:
    5dd0:	f3 0f 1e fa          	endbr64
    5dd4:	85 d2                	test   %edx,%edx
    5dd6:	74 04                	je     5ddc <fwp_args47+0xc>
    5dd8:	85 f6                	test   %esi,%esi
    5dda:	74 04                	je     5de0 <fwp_args47+0x10>
    5ddc:	c3                   	ret
    5ddd:	0f 1f 00             	nopl   (%rax)
    5de0:	48 8b 15 f1 7c 01 00 	mov    0x17cf1(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    5de7:	48 8b 07             	mov    (%rdi),%rax
    5dea:	48 2b 05 bf 7c 01 00 	sub    0x17cbf(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    5df1:	48 c1 e2 10          	shl    $0x10,%rdx
    5df5:	48 39 d0             	cmp    %rdx,%rax
    5df8:	73 e2                	jae    5ddc <fwp_args47+0xc>
    5dfa:	48 89 c2             	mov    %rax,%rdx
    5dfd:	48 c1 ea 10          	shr    $0x10,%rdx
    5e01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5e05:	48 8b 15 ec 7c 01 00 	mov    0x17cec(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    5e0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5e10:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5e14:	48 85 ff             	test   %rdi,%rdi
    5e17:	74 c3                	je     5ddc <fwp_args47+0xc>
    5e19:	0f b6 0a             	movzbl (%rdx),%ecx
    5e1c:	80 f9 02             	cmp    $0x2,%cl
    5e1f:	74 4f                	je     5e70 <fwp_args47+0xa0>
    5e21:	80 f9 01             	cmp    $0x1,%cl
    5e24:	75 b6                	jne    5ddc <fwp_args47+0xc>
    5e26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5e29:	0f b7 c0             	movzwl %ax,%eax
    5e2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5e2f:	48 0f af c1          	imul   %rcx,%rax
    5e33:	48 c1 e8 20          	shr    $0x20,%rax
    5e37:	48 39 d0             	cmp    %rdx,%rax
    5e3a:	73 a0                	jae    5ddc <fwp_args47+0xc>
    5e3c:	48 01 c7             	add    %rax,%rdi
    5e3f:	0f b6 07             	movzbl (%rdi),%eax
    5e42:	84 c0                	test   %al,%al
    5e44:	74 96                	je     5ddc <fwp_args47+0xc>
    5e46:	8b 15 74 85 01 00    	mov    0x18574(%rip),%edx        # 1e3c0 <iteration_active>
    5e4c:	85 d2                	test   %edx,%edx
    5e4e:	75 10                	jne    5e60 <fwp_args47+0x90>
    5e50:	3c fd                	cmp    $0xfd,%al
    5e52:	77 22                	ja     5e76 <fwp_args47+0xa6>
    5e54:	83 c0 01             	add    $0x1,%eax
    5e57:	88 07                	mov    %al,(%rdi)
    5e59:	c3                   	ret
    5e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e60:	48 83 05 40 85 01 00 	addq   $0x1,0x18540(%rip)        # 1e3a8 <iteration_retains>
    5e67:	01 
    5e68:	eb e6                	jmp    5e50 <fwp_args47+0x80>
    5e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e70:	66 85 c0             	test   %ax,%ax
    5e73:	74 ca                	je     5e3f <fwp_args47+0x6f>
    5e75:	c3                   	ret
    5e76:	e9 f5 e0 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    5e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005e80 <fwp_args50>:
    5e80:	f3 0f 1e fa          	endbr64
    5e84:	85 d2                	test   %edx,%edx
    5e86:	74 04                	je     5e8c <fwp_args50+0xc>
    5e88:	85 f6                	test   %esi,%esi
    5e8a:	74 04                	je     5e90 <fwp_args50+0x10>
    5e8c:	c3                   	ret
    5e8d:	0f 1f 00             	nopl   (%rax)
    5e90:	48 8b 15 41 7c 01 00 	mov    0x17c41(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    5e97:	48 8b 07             	mov    (%rdi),%rax
    5e9a:	48 2b 05 0f 7c 01 00 	sub    0x17c0f(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    5ea1:	48 c1 e2 10          	shl    $0x10,%rdx
    5ea5:	48 39 d0             	cmp    %rdx,%rax
    5ea8:	73 e2                	jae    5e8c <fwp_args50+0xc>
    5eaa:	48 89 c2             	mov    %rax,%rdx
    5ead:	48 c1 ea 10          	shr    $0x10,%rdx
    5eb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5eb5:	48 8b 15 3c 7c 01 00 	mov    0x17c3c(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    5ebc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5ec0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5ec4:	48 85 ff             	test   %rdi,%rdi
    5ec7:	74 c3                	je     5e8c <fwp_args50+0xc>
    5ec9:	0f b6 0a             	movzbl (%rdx),%ecx
    5ecc:	80 f9 02             	cmp    $0x2,%cl
    5ecf:	74 4f                	je     5f20 <fwp_args50+0xa0>
    5ed1:	80 f9 01             	cmp    $0x1,%cl
    5ed4:	75 b6                	jne    5e8c <fwp_args50+0xc>
    5ed6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5ed9:	0f b7 c0             	movzwl %ax,%eax
    5edc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5edf:	48 0f af c1          	imul   %rcx,%rax
    5ee3:	48 c1 e8 20          	shr    $0x20,%rax
    5ee7:	48 39 d0             	cmp    %rdx,%rax
    5eea:	73 a0                	jae    5e8c <fwp_args50+0xc>
    5eec:	48 01 c7             	add    %rax,%rdi
    5eef:	0f b6 07             	movzbl (%rdi),%eax
    5ef2:	84 c0                	test   %al,%al
    5ef4:	74 96                	je     5e8c <fwp_args50+0xc>
    5ef6:	8b 15 c4 84 01 00    	mov    0x184c4(%rip),%edx        # 1e3c0 <iteration_active>
    5efc:	85 d2                	test   %edx,%edx
    5efe:	75 10                	jne    5f10 <fwp_args50+0x90>
    5f00:	3c fd                	cmp    $0xfd,%al
    5f02:	77 22                	ja     5f26 <fwp_args50+0xa6>
    5f04:	83 c0 01             	add    $0x1,%eax
    5f07:	88 07                	mov    %al,(%rdi)
    5f09:	c3                   	ret
    5f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f10:	48 83 05 90 84 01 00 	addq   $0x1,0x18490(%rip)        # 1e3a8 <iteration_retains>
    5f17:	01 
    5f18:	eb e6                	jmp    5f00 <fwp_args50+0x80>
    5f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f20:	66 85 c0             	test   %ax,%ax
    5f23:	74 ca                	je     5eef <fwp_args50+0x6f>
    5f25:	c3                   	ret
    5f26:	e9 45 e0 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    5f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005f30 <fwp_caps47>:
    5f30:	f3 0f 1e fa          	endbr64
    5f34:	48 83 ec 18          	sub    $0x18,%rsp
    5f38:	48 89 f8             	mov    %rdi,%rax
    5f3b:	8b 7f 04             	mov    0x4(%rdi),%edi
    5f3e:	85 ff                	test   %edi,%edi
    5f40:	0f 84 9a 00 00 00    	je     5fe0 <fwp_caps47+0xb0>
    5f46:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5f4a:	85 f6                	test   %esi,%esi
    5f4c:	0f 85 9e 00 00 00    	jne    5ff0 <fwp_caps47+0xc0>
    5f52:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5f57:	e8 34 f8 ff ff       	call   5790 <fwp_drop4>
    5f5c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5f61:	48 8b 0d 70 7b 01 00 	mov    0x17b70(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    5f68:	48 89 c2             	mov    %rax,%rdx
    5f6b:	48 2b 15 3e 7b 01 00 	sub    0x17b3e(%rip),%rdx        # 1dab0 <fwp_heap+0x13b0>
    5f72:	48 c1 e1 10          	shl    $0x10,%rcx
    5f76:	48 39 ca             	cmp    %rcx,%rdx
    5f79:	73 6d                	jae    5fe8 <fwp_caps47+0xb8>
    5f7b:	48 89 d1             	mov    %rdx,%rcx
    5f7e:	48 c1 e9 10          	shr    $0x10,%rcx
    5f82:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5f86:	48 8b 0d 6b 7b 01 00 	mov    0x17b6b(%rip),%rcx        # 1daf8 <fwp_heap+0x13f8>
    5f8d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5f91:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5f95:	48 85 f6             	test   %rsi,%rsi
    5f98:	74 4e                	je     5fe8 <fwp_caps47+0xb8>
    5f9a:	0f b6 39             	movzbl (%rcx),%edi
    5f9d:	40 80 ff 02          	cmp    $0x2,%dil
    5fa1:	0f 84 c9 00 00 00    	je     6070 <fwp_caps47+0x140>
    5fa7:	40 80 ff 01          	cmp    $0x1,%dil
    5fab:	75 3b                	jne    5fe8 <fwp_caps47+0xb8>
    5fad:	8b 79 18             	mov    0x18(%rcx),%edi
    5fb0:	0f b7 d2             	movzwl %dx,%edx
    5fb3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5fb6:	48 0f af d7          	imul   %rdi,%rdx
    5fba:	48 c1 ea 20          	shr    $0x20,%rdx
    5fbe:	48 39 ca             	cmp    %rcx,%rdx
    5fc1:	73 25                	jae    5fe8 <fwp_caps47+0xb8>
    5fc3:	48 01 d6             	add    %rdx,%rsi
    5fc6:	80 3e 01             	cmpb   $0x1,(%rsi)
    5fc9:	75 1d                	jne    5fe8 <fwp_caps47+0xb8>
    5fcb:	48 89 c7             	mov    %rax,%rdi
    5fce:	48 83 c4 18          	add    $0x18,%rsp
    5fd2:	e9 f9 e2 ff ff       	jmp    42d0 <fwp_mem_free>
    5fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5fde:	00 00 
    5fe0:	85 f6                	test   %esi,%esi
    5fe2:	0f 84 79 ff ff ff    	je     5f61 <fwp_caps47+0x31>
    5fe8:	48 83 c4 18          	add    $0x18,%rsp
    5fec:	c3                   	ret
    5fed:	0f 1f 00             	nopl   (%rax)
    5ff0:	48 8b 05 e1 7a 01 00 	mov    0x17ae1(%rip),%rax        # 1dad8 <fwp_heap+0x13d8>
    5ff7:	48 2b 3d b2 7a 01 00 	sub    0x17ab2(%rip),%rdi        # 1dab0 <fwp_heap+0x13b0>
    5ffe:	48 c1 e0 10          	shl    $0x10,%rax
    6002:	48 39 c7             	cmp    %rax,%rdi
    6005:	73 e1                	jae    5fe8 <fwp_caps47+0xb8>
    6007:	48 89 f8             	mov    %rdi,%rax
    600a:	48 c1 e8 10          	shr    $0x10,%rax
    600e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6012:	48 8b 05 df 7a 01 00 	mov    0x17adf(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    6019:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    601d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6021:	48 85 c0             	test   %rax,%rax
    6024:	74 c2                	je     5fe8 <fwp_caps47+0xb8>
    6026:	0f b6 0a             	movzbl (%rdx),%ecx
    6029:	80 f9 02             	cmp    $0x2,%cl
    602c:	74 52                	je     6080 <fwp_caps47+0x150>
    602e:	80 f9 01             	cmp    $0x1,%cl
    6031:	75 b5                	jne    5fe8 <fwp_caps47+0xb8>
    6033:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6036:	0f b7 ff             	movzwl %di,%edi
    6039:	8b 52 1c             	mov    0x1c(%rdx),%edx
    603c:	48 0f af f9          	imul   %rcx,%rdi
    6040:	48 c1 ef 20          	shr    $0x20,%rdi
    6044:	48 39 d7             	cmp    %rdx,%rdi
    6047:	73 9f                	jae    5fe8 <fwp_caps47+0xb8>
    6049:	48 01 f8             	add    %rdi,%rax
    604c:	0f b6 10             	movzbl (%rax),%edx
    604f:	84 d2                	test   %dl,%dl
    6051:	74 95                	je     5fe8 <fwp_caps47+0xb8>
    6053:	8b 0d 67 83 01 00    	mov    0x18367(%rip),%ecx        # 1e3c0 <iteration_active>
    6059:	85 c9                	test   %ecx,%ecx
    605b:	75 33                	jne    6090 <fwp_caps47+0x160>
    605d:	80 fa fd             	cmp    $0xfd,%dl
    6060:	77 38                	ja     609a <fwp_caps47+0x16a>
    6062:	83 c2 01             	add    $0x1,%edx
    6065:	88 10                	mov    %dl,(%rax)
    6067:	e9 7c ff ff ff       	jmp    5fe8 <fwp_caps47+0xb8>
    606c:	0f 1f 40 00          	nopl   0x0(%rax)
    6070:	66 85 d2             	test   %dx,%dx
    6073:	0f 85 6f ff ff ff    	jne    5fe8 <fwp_caps47+0xb8>
    6079:	e9 48 ff ff ff       	jmp    5fc6 <fwp_caps47+0x96>
    607e:	66 90                	xchg   %ax,%ax
    6080:	66 85 ff             	test   %di,%di
    6083:	0f 85 5f ff ff ff    	jne    5fe8 <fwp_caps47+0xb8>
    6089:	eb c1                	jmp    604c <fwp_caps47+0x11c>
    608b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6090:	48 83 05 10 83 01 00 	addq   $0x1,0x18310(%rip)        # 1e3a8 <iteration_retains>
    6097:	01 
    6098:	eb c3                	jmp    605d <fwp_caps47+0x12d>
    609a:	48 89 c7             	mov    %rax,%rdi
    609d:	48 83 c4 18          	add    $0x18,%rsp
    60a1:	e9 ca de ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 

00000000000060b0 <fwp_caps50>:
    60b0:	f3 0f 1e fa          	endbr64
    60b4:	48 83 ec 18          	sub    $0x18,%rsp
    60b8:	48 89 f8             	mov    %rdi,%rax
    60bb:	8b 7f 04             	mov    0x4(%rdi),%edi
    60be:	85 ff                	test   %edi,%edi
    60c0:	0f 84 9a 00 00 00    	je     6160 <fwp_caps50+0xb0>
    60c6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    60ca:	85 f6                	test   %esi,%esi
    60cc:	0f 85 9e 00 00 00    	jne    6170 <fwp_caps50+0xc0>
    60d2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    60d7:	e8 b4 f6 ff ff       	call   5790 <fwp_drop4>
    60dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    60e1:	48 8b 0d f0 79 01 00 	mov    0x179f0(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    60e8:	48 89 c2             	mov    %rax,%rdx
    60eb:	48 2b 15 be 79 01 00 	sub    0x179be(%rip),%rdx        # 1dab0 <fwp_heap+0x13b0>
    60f2:	48 c1 e1 10          	shl    $0x10,%rcx
    60f6:	48 39 ca             	cmp    %rcx,%rdx
    60f9:	73 6d                	jae    6168 <fwp_caps50+0xb8>
    60fb:	48 89 d1             	mov    %rdx,%rcx
    60fe:	48 c1 e9 10          	shr    $0x10,%rcx
    6102:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6106:	48 8b 0d eb 79 01 00 	mov    0x179eb(%rip),%rcx        # 1daf8 <fwp_heap+0x13f8>
    610d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    6111:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    6115:	48 85 f6             	test   %rsi,%rsi
    6118:	74 4e                	je     6168 <fwp_caps50+0xb8>
    611a:	0f b6 39             	movzbl (%rcx),%edi
    611d:	40 80 ff 02          	cmp    $0x2,%dil
    6121:	0f 84 c9 00 00 00    	je     61f0 <fwp_caps50+0x140>
    6127:	40 80 ff 01          	cmp    $0x1,%dil
    612b:	75 3b                	jne    6168 <fwp_caps50+0xb8>
    612d:	8b 79 18             	mov    0x18(%rcx),%edi
    6130:	0f b7 d2             	movzwl %dx,%edx
    6133:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6136:	48 0f af d7          	imul   %rdi,%rdx
    613a:	48 c1 ea 20          	shr    $0x20,%rdx
    613e:	48 39 ca             	cmp    %rcx,%rdx
    6141:	73 25                	jae    6168 <fwp_caps50+0xb8>
    6143:	48 01 d6             	add    %rdx,%rsi
    6146:	80 3e 01             	cmpb   $0x1,(%rsi)
    6149:	75 1d                	jne    6168 <fwp_caps50+0xb8>
    614b:	48 89 c7             	mov    %rax,%rdi
    614e:	48 83 c4 18          	add    $0x18,%rsp
    6152:	e9 79 e1 ff ff       	jmp    42d0 <fwp_mem_free>
    6157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    615e:	00 00 
    6160:	85 f6                	test   %esi,%esi
    6162:	0f 84 79 ff ff ff    	je     60e1 <fwp_caps50+0x31>
    6168:	48 83 c4 18          	add    $0x18,%rsp
    616c:	c3                   	ret
    616d:	0f 1f 00             	nopl   (%rax)
    6170:	48 8b 05 61 79 01 00 	mov    0x17961(%rip),%rax        # 1dad8 <fwp_heap+0x13d8>
    6177:	48 2b 3d 32 79 01 00 	sub    0x17932(%rip),%rdi        # 1dab0 <fwp_heap+0x13b0>
    617e:	48 c1 e0 10          	shl    $0x10,%rax
    6182:	48 39 c7             	cmp    %rax,%rdi
    6185:	73 e1                	jae    6168 <fwp_caps50+0xb8>
    6187:	48 89 f8             	mov    %rdi,%rax
    618a:	48 c1 e8 10          	shr    $0x10,%rax
    618e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6192:	48 8b 05 5f 79 01 00 	mov    0x1795f(%rip),%rax        # 1daf8 <fwp_heap+0x13f8>
    6199:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    619d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    61a1:	48 85 c0             	test   %rax,%rax
    61a4:	74 c2                	je     6168 <fwp_caps50+0xb8>
    61a6:	0f b6 0a             	movzbl (%rdx),%ecx
    61a9:	80 f9 02             	cmp    $0x2,%cl
    61ac:	74 52                	je     6200 <fwp_caps50+0x150>
    61ae:	80 f9 01             	cmp    $0x1,%cl
    61b1:	75 b5                	jne    6168 <fwp_caps50+0xb8>
    61b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    61b6:	0f b7 ff             	movzwl %di,%edi
    61b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    61bc:	48 0f af f9          	imul   %rcx,%rdi
    61c0:	48 c1 ef 20          	shr    $0x20,%rdi
    61c4:	48 39 d7             	cmp    %rdx,%rdi
    61c7:	73 9f                	jae    6168 <fwp_caps50+0xb8>
    61c9:	48 01 f8             	add    %rdi,%rax
    61cc:	0f b6 10             	movzbl (%rax),%edx
    61cf:	84 d2                	test   %dl,%dl
    61d1:	74 95                	je     6168 <fwp_caps50+0xb8>
    61d3:	8b 0d e7 81 01 00    	mov    0x181e7(%rip),%ecx        # 1e3c0 <iteration_active>
    61d9:	85 c9                	test   %ecx,%ecx
    61db:	75 33                	jne    6210 <fwp_caps50+0x160>
    61dd:	80 fa fd             	cmp    $0xfd,%dl
    61e0:	77 38                	ja     621a <fwp_caps50+0x16a>
    61e2:	83 c2 01             	add    $0x1,%edx
    61e5:	88 10                	mov    %dl,(%rax)
    61e7:	e9 7c ff ff ff       	jmp    6168 <fwp_caps50+0xb8>
    61ec:	0f 1f 40 00          	nopl   0x0(%rax)
    61f0:	66 85 d2             	test   %dx,%dx
    61f3:	0f 85 6f ff ff ff    	jne    6168 <fwp_caps50+0xb8>
    61f9:	e9 48 ff ff ff       	jmp    6146 <fwp_caps50+0x96>
    61fe:	66 90                	xchg   %ax,%ax
    6200:	66 85 ff             	test   %di,%di
    6203:	0f 85 5f ff ff ff    	jne    6168 <fwp_caps50+0xb8>
    6209:	eb c1                	jmp    61cc <fwp_caps50+0x11c>
    620b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6210:	48 83 05 90 81 01 00 	addq   $0x1,0x18190(%rip)        # 1e3a8 <iteration_retains>
    6217:	01 
    6218:	eb c3                	jmp    61dd <fwp_caps50+0x12d>
    621a:	48 89 c7             	mov    %rax,%rdi
    621d:	48 83 c4 18          	add    $0x18,%rsp
    6221:	e9 4a dd ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    6226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    622d:	00 00 00 

0000000000006230 <fwp_write>:
    6230:	41 57                	push   %r15
    6232:	41 56                	push   %r14
    6234:	41 55                	push   %r13
    6236:	41 54                	push   %r12
    6238:	55                   	push   %rbp
    6239:	53                   	push   %rbx
    623a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    6241:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    6248:	00 00 
    624a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    6251:	00 
    6252:	49 89 d4             	mov    %rdx,%r12
    6255:	8b 12                	mov    (%rdx),%edx
    6257:	83 fa 19             	cmp    $0x19,%edx
    625a:	77 6a                	ja     62c6 <fwp_write+0x96>
    625c:	48 89 f5             	mov    %rsi,%rbp
    625f:	89 d0                	mov    %edx,%eax
    6261:	89 ce                	mov    %ecx,%esi
    6263:	48 89 fb             	mov    %rdi,%rbx
    6266:	48 8d 0d f3 32 00 00 	lea    0x32f3(%rip),%rcx        # 9560 <_IO_stdin_used+0x560>
    626d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    6271:	48 01 c8             	add    %rcx,%rax
    6274:	3e ff e0             	notrack jmp *%rax
    6277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    627e:	00 00 
    6280:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    6284:	48 8b 45 00          	mov    0x0(%rbp),%rax
    6288:	48 89 ca             	mov    %rcx,%rdx
    628b:	48 85 c9             	test   %rcx,%rcx
    628e:	0f 88 9c 0c 00 00    	js     6f30 <fwp_write+0xd00>
    6294:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    629b:	00 
    629c:	48 89 c6             	mov    %rax,%rsi
    629f:	4c 89 e7             	mov    %r12,%rdi
    62a2:	e8 59 c7 ff ff       	call   2a00 <fwp_fmt_u128>
    62a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    62ae:	00 00 
    62b0:	4c 89 e7             	mov    %r12,%rdi
    62b3:	e8 78 c1 ff ff       	call   2430 <strlen@plt>
    62b8:	4c 89 e6             	mov    %r12,%rsi
    62bb:	48 89 df             	mov    %rbx,%rdi
    62be:	48 89 c2             	mov    %rax,%rdx
    62c1:	e8 5a cd ff ff       	call   3020 <buf_put>
    62c6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    62cd:	00 
    62ce:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62d5:	00 00 
    62d7:	0f 85 28 04 00 00    	jne    6705 <fwp_write+0x4d5>
    62dd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    62e4:	5b                   	pop    %rbx
    62e5:	5d                   	pop    %rbp
    62e6:	41 5c                	pop    %r12
    62e8:	41 5d                	pop    %r13
    62ea:	41 5e                	pop    %r14
    62ec:	41 5f                	pop    %r15
    62ee:	c3                   	ret
    62ef:	90                   	nop
    62f0:	49 89 e9             	mov    %rbp,%r9
    62f3:	4c 8d 05 3a 2e 00 00 	lea    0x2e3a(%rip),%r8        # 9134 <_IO_stdin_used+0x134>
    62fa:	b9 00 02 00 00       	mov    $0x200,%ecx
    62ff:	ba 02 00 00 00       	mov    $0x2,%edx
    6304:	be 00 02 00 00       	mov    $0x200,%esi
    6309:	31 c0                	xor    %eax,%eax
    630b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6312:	00 
    6313:	e8 78 c0 ff ff       	call   2390 <__snprintf_chk@plt>
    6318:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    631f:	00 
    6320:	e8 0b c1 ff ff       	call   2430 <strlen@plt>
    6325:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    632c:	00 
    632d:	48 89 df             	mov    %rbx,%rdi
    6330:	48 89 c2             	mov    %rax,%rdx
    6333:	e8 e8 cc ff ff       	call   3020 <buf_put>
    6338:	eb 8c                	jmp    62c6 <fwp_write+0x96>
    633a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6340:	49 89 e9             	mov    %rbp,%r9
    6343:	4c 8d 05 e5 2d 00 00 	lea    0x2de5(%rip),%r8        # 912f <_IO_stdin_used+0x12f>
    634a:	eb ae                	jmp    62fa <fwp_write+0xca>
    634c:	0f 1f 40 00          	nopl   0x0(%rax)
    6350:	83 fa 13             	cmp    $0x13,%edx
    6353:	48 8d 05 cb 2d 00 00 	lea    0x2dcb(%rip),%rax        # 9125 <_IO_stdin_used+0x125>
    635a:	48 8d 35 c9 2d 00 00 	lea    0x2dc9(%rip),%rsi        # 912a <_IO_stdin_used+0x12a>
    6361:	ba 04 00 00 00       	mov    $0x4,%edx
    6366:	48 0f 44 f0          	cmove  %rax,%rsi
    636a:	45 31 ed             	xor    %r13d,%r13d
    636d:	e8 ae cc ff ff       	call   3020 <buf_put>
    6372:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6377:	0f 84 a3 08 00 00    	je     6c20 <fwp_write+0x9f0>
    637d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    6382:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    6387:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    638c:	48 89 df             	mov    %rbx,%rdi
    638f:	49 0f 44 c5          	cmove  %r13,%rax
    6393:	31 c9                	xor    %ecx,%ecx
    6395:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    639a:	e8 91 fe ff ff       	call   6230 <fwp_write>
    639f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    63a4:	0f 84 6e 09 00 00    	je     6d18 <fwp_write+0xae8>
    63aa:	49 83 c5 01          	add    $0x1,%r13
    63ae:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    63b2:	0f 83 68 08 00 00    	jae    6c20 <fwp_write+0x9f0>
    63b8:	ba 02 00 00 00       	mov    $0x2,%edx
    63bd:	48 8d 35 b0 2d 00 00 	lea    0x2db0(%rip),%rsi        # 9174 <_IO_stdin_used+0x174>
    63c4:	48 89 df             	mov    %rbx,%rdi
    63c7:	e8 54 cc ff ff       	call   3020 <buf_put>
    63cc:	eb af                	jmp    637d <fwp_write+0x14d>
    63ce:	66 90                	xchg   %ax,%ax
    63d0:	ba 06 00 00 00       	mov    $0x6,%edx
    63d5:	48 8d 35 71 2d 00 00 	lea    0x2d71(%rip),%rsi        # 914d <_IO_stdin_used+0x14d>
    63dc:	48 83 c5 10          	add    $0x10,%rbp
    63e0:	e8 3b cc ff ff       	call   3020 <buf_put>
    63e5:	48 89 ef             	mov    %rbp,%rdi
    63e8:	e8 43 c0 ff ff       	call   2430 <strlen@plt>
    63ed:	48 89 ee             	mov    %rbp,%rsi
    63f0:	48 89 df             	mov    %rbx,%rdi
    63f3:	48 89 c2             	mov    %rax,%rdx
    63f6:	e8 25 cc ff ff       	call   3020 <buf_put>
    63fb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6400:	ba 01 00 00 00       	mov    $0x1,%edx
    6405:	48 89 df             	mov    %rbx,%rdi
    6408:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    640d:	e8 0e cc ff ff       	call   3020 <buf_put>
    6412:	e9 af fe ff ff       	jmp    62c6 <fwp_write+0x96>
    6417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    641e:	00 00 
    6420:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6427:	00 
    6428:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    642f:	00 00 
    6431:	0f 85 ce 02 00 00    	jne    6705 <fwp_write+0x4d5>
    6437:	ba 0a 00 00 00       	mov    $0xa,%edx
    643c:	48 8d 35 f6 2c 00 00 	lea    0x2cf6(%rip),%rsi        # 9139 <_IO_stdin_used+0x139>
    6443:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    644a:	48 89 df             	mov    %rbx,%rdi
    644d:	5b                   	pop    %rbx
    644e:	5d                   	pop    %rbp
    644f:	41 5c                	pop    %r12
    6451:	41 5d                	pop    %r13
    6453:	41 5e                	pop    %r14
    6455:	41 5f                	pop    %r15
    6457:	e9 c4 cb ff ff       	jmp    3020 <buf_put>
    645c:	0f 1f 40 00          	nopl   0x0(%rax)
    6460:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6465:	4d 85 ed             	test   %r13,%r13
    6468:	0f 84 02 0c 00 00    	je     7070 <fwp_write+0xe40>
    646e:	48 8d 35 0c 2d 00 00 	lea    0x2d0c(%rip),%rsi        # 9181 <_IO_stdin_used+0x181>
    6475:	4c 89 ef             	mov    %r13,%rdi
    6478:	e8 93 c0 ff ff       	call   2510 <strcmp@plt>
    647d:	41 89 c1             	mov    %eax,%r9d
    6480:	85 c0                	test   %eax,%eax
    6482:	0f 84 6c 0c 00 00    	je     70f4 <fwp_write+0xec4>
    6488:	4c 89 ef             	mov    %r13,%rdi
    648b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6490:	e8 9b bf ff ff       	call   2430 <strlen@plt>
    6495:	4c 89 ee             	mov    %r13,%rsi
    6498:	48 89 df             	mov    %rbx,%rdi
    649b:	48 89 c2             	mov    %rax,%rdx
    649e:	e8 7d cb ff ff       	call   3020 <buf_put>
    64a3:	ba 01 00 00 00       	mov    $0x1,%edx
    64a8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    64ad:	48 89 df             	mov    %rbx,%rdi
    64b0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    64b5:	e8 66 cb ff ff       	call   3020 <buf_put>
    64ba:	ba 01 00 00 00       	mov    $0x1,%edx
    64bf:	4c 89 fe             	mov    %r15,%rsi
    64c2:	48 89 df             	mov    %rbx,%rdi
    64c5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    64ca:	e8 51 cb ff ff       	call   3020 <buf_put>
    64cf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    64d4:	45 31 f6             	xor    %r14d,%r14d
    64d7:	85 d2                	test   %edx,%edx
    64d9:	0f 8e 81 0a 00 00    	jle    6f60 <fwp_write+0xd30>
    64df:	45 31 ed             	xor    %r13d,%r13d
    64e2:	4d 85 ed             	test   %r13,%r13
    64e5:	0f 85 75 07 00 00    	jne    6c60 <fwp_write+0xa30>
    64eb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    64f2:	00 
    64f3:	45 85 f6             	test   %r14d,%r14d
    64f6:	0f 84 84 07 00 00    	je     6c80 <fwp_write+0xa50>
    64fc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    6501:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    6506:	48 89 df             	mov    %rbx,%rdi
    6509:	49 83 c5 01          	add    $0x1,%r13
    650d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    6511:	31 c9                	xor    %ecx,%ecx
    6513:	e8 18 fd ff ff       	call   6230 <fwp_write>
    6518:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    651d:	7f c3                	jg     64e2 <fwp_write+0x2b2>
    651f:	45 85 f6             	test   %r14d,%r14d
    6522:	0f 84 38 0a 00 00    	je     6f60 <fwp_write+0xd30>
    6528:	b8 29 00 00 00       	mov    $0x29,%eax
    652d:	ba 01 00 00 00       	mov    $0x1,%edx
    6532:	4c 89 fe             	mov    %r15,%rsi
    6535:	48 89 df             	mov    %rbx,%rdi
    6538:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    653c:	e8 df ca ff ff       	call   3020 <buf_put>
    6541:	e9 80 fd ff ff       	jmp    62c6 <fwp_write+0x96>
    6546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    654d:	00 00 00 
    6550:	ba 01 00 00 00       	mov    $0x1,%edx
    6555:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    655a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    655f:	e8 bc ca ff ff       	call   3020 <buf_put>
    6564:	48 85 ed             	test   %rbp,%rbp
    6567:	0f 84 93 06 00 00    	je     6c00 <fwp_write+0x9d0>
    656d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    6571:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6576:	31 c9                	xor    %ecx,%ecx
    6578:	48 89 df             	mov    %rbx,%rdi
    657b:	e8 b0 fc ff ff       	call   6230 <fwp_write>
    6580:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6584:	48 85 ed             	test   %rbp,%rbp
    6587:	0f 84 73 06 00 00    	je     6c00 <fwp_write+0x9d0>
    658d:	ba 02 00 00 00       	mov    $0x2,%edx
    6592:	48 8d 35 db 2b 00 00 	lea    0x2bdb(%rip),%rsi        # 9174 <_IO_stdin_used+0x174>
    6599:	48 89 df             	mov    %rbx,%rdi
    659c:	e8 7f ca ff ff       	call   3020 <buf_put>
    65a1:	eb ca                	jmp    656d <fwp_write+0x33d>
    65a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65a8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    65ac:	85 f6                	test   %esi,%esi
    65ae:	0f 84 fc 07 00 00    	je     6db0 <fwp_write+0xb80>
    65b4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    65bb:	00 
    65bc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    65c3:	00 00 
    65c5:	0f 85 3a 01 00 00    	jne    6705 <fwp_write+0x4d5>
    65cb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    65cf:	4c 89 ea             	mov    %r13,%rdx
    65d2:	e9 6c fe ff ff       	jmp    6443 <fwp_write+0x213>
    65d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    65de:	00 00 
    65e0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    65e5:	ba 01 00 00 00       	mov    $0x1,%edx
    65ea:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    65ef:	48 89 ee             	mov    %rbp,%rsi
    65f2:	e8 29 ca ff ff       	call   3020 <buf_put>
    65f7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    65fc:	4c 89 e7             	mov    %r12,%rdi
    65ff:	e8 2c be ff ff       	call   2430 <strlen@plt>
    6604:	4c 89 e6             	mov    %r12,%rsi
    6607:	48 89 df             	mov    %rbx,%rdi
    660a:	48 89 c2             	mov    %rax,%rdx
    660d:	e8 0e ca ff ff       	call   3020 <buf_put>
    6612:	ba 01 00 00 00       	mov    $0x1,%edx
    6617:	48 89 ee             	mov    %rbp,%rsi
    661a:	48 89 df             	mov    %rbx,%rdi
    661d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    6622:	e8 f9 c9 ff ff       	call   3020 <buf_put>
    6627:	e9 9a fc ff ff       	jmp    62c6 <fwp_write+0x96>
    662c:	0f 1f 40 00          	nopl   0x0(%rax)
    6630:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    6635:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    6639:	0f 8a 8e 0b 00 00    	jp     71cd <fwp_write+0xf9d>
    663f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    6643:	66 0f 54 05 35 30 00 	andpd  0x3035(%rip),%xmm0        # 9680 <msg.3+0xb0>
    664a:	00 
    664b:	bd 01 00 00 00       	mov    $0x1,%ebp
    6650:	66 0f 2e 05 b8 2f 00 	ucomisd 0x2fb8(%rip),%xmm0        # 9610 <msg.3+0x40>
    6657:	00 
    6658:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    665f:	00 
    6660:	0f 87 b2 09 00 00    	ja     7018 <fwp_write+0xde8>
    6666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    666d:	00 00 00 
    6670:	66 0f 28 c1          	movapd %xmm1,%xmm0
    6674:	89 ee                	mov    %ebp,%esi
    6676:	4c 89 e7             	mov    %r12,%rdi
    6679:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    667e:	e8 cd cc ff ff       	call   3350 <fwp_format_g.constprop.0>
    6683:	31 f6                	xor    %esi,%esi
    6685:	4c 89 e7             	mov    %r12,%rdi
    6688:	e8 63 bd ff ff       	call   23f0 <strtod@plt>
    668d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6692:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    6696:	7a 06                	jp     669e <fwp_write+0x46e>
    6698:	0f 84 e9 01 00 00    	je     6887 <fwp_write+0x657>
    669e:	83 c5 01             	add    $0x1,%ebp
    66a1:	83 fd 12             	cmp    $0x12,%ebp
    66a4:	75 ca                	jne    6670 <fwp_write+0x440>
    66a6:	be 11 00 00 00       	mov    $0x11,%esi
    66ab:	66 0f 28 c1          	movapd %xmm1,%xmm0
    66af:	4c 89 e7             	mov    %r12,%rdi
    66b2:	e8 99 cc ff ff       	call   3350 <fwp_format_g.constprop.0>
    66b7:	e9 cb 01 00 00       	jmp    6887 <fwp_write+0x657>
    66bc:	0f 1f 40 00          	nopl   0x0(%rax)
    66c0:	48 83 fd 01          	cmp    $0x1,%rbp
    66c4:	0f 84 e6 08 00 00    	je     6fb0 <fwp_write+0xd80>
    66ca:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    66ce:	b8 02 00 00 00       	mov    $0x2,%eax
    66d3:	ba 01 00 00 00       	mov    $0x1,%edx
    66d8:	48 0f 44 d0          	cmove  %rax,%rdx
    66dc:	48 8d 35 3a 2a 00 00 	lea    0x2a3a(%rip),%rsi        # 911d <_IO_stdin_used+0x11d>
    66e3:	48 8d 05 38 2a 00 00 	lea    0x2a38(%rip),%rax        # 9122 <_IO_stdin_used+0x122>
    66ea:	48 0f 44 f0          	cmove  %rax,%rsi
    66ee:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    66f5:	00 
    66f6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    66fd:	00 00 
    66ff:	0f 84 3e fd ff ff    	je     6443 <fwp_write+0x213>
    6705:	e8 36 bd ff ff       	call   2440 <__stack_chk_fail@plt>
    670a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6710:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    6715:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    671a:	e8 41 c8 ff ff       	call   2f60 <buf_grow>
    671f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    6723:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    6729:	4c 03 0b             	add    (%rbx),%r9
    672c:	66 45 89 11          	mov    %r10w,(%r9)
    6730:	45 85 e4             	test   %r12d,%r12d
    6733:	0f 8e 07 05 00 00    	jle    6c40 <fwp_write+0xa10>
    6739:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    6740:	55 55 55 
    6743:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    6748:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    674f:	aa aa aa 
    6752:	49 83 c1 01          	add    $0x1,%r9
    6756:	eb 45                	jmp    679d <fwp_write+0x56d>
    6758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    675f:	00 
    6760:	be 01 00 00 00       	mov    $0x1,%esi
    6765:	b8 2d 00 00 00       	mov    $0x2d,%eax
    676a:	88 07                	mov    %al,(%rdi)
    676c:	48 89 e8             	mov    %rbp,%rax
    676f:	49 f7 e8             	imul   %r8
    6772:	48 89 e8             	mov    %rbp,%rax
    6775:	48 c1 f8 3f          	sar    $0x3f,%rax
    6779:	48 29 c2             	sub    %rax,%rdx
    677c:	48 85 c9             	test   %rcx,%rcx
    677f:	0f 95 c0             	setne  %al
    6782:	48 c1 ed 3f          	shr    $0x3f,%rbp
    6786:	48 83 ef 01          	sub    $0x1,%rdi
    678a:	48 21 c5             	and    %rax,%rbp
    678d:	48 29 ea             	sub    %rbp,%rdx
    6790:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    6794:	49 39 f9             	cmp    %rdi,%r9
    6797:	0f 84 a3 04 00 00    	je     6c40 <fwp_write+0xa10>
    679d:	48 89 e8             	mov    %rbp,%rax
    67a0:	49 f7 e8             	imul   %r8
    67a3:	48 89 e8             	mov    %rbp,%rax
    67a6:	48 c1 f8 3f          	sar    $0x3f,%rax
    67aa:	48 89 d1             	mov    %rdx,%rcx
    67ad:	48 29 c1             	sub    %rax,%rcx
    67b0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    67b4:	48 89 e9             	mov    %rbp,%rcx
    67b7:	48 29 c1             	sub    %rax,%rcx
    67ba:	48 8d 41 03          	lea    0x3(%rcx),%rax
    67be:	49 f7 e2             	mul    %r10
    67c1:	b8 30 00 00 00       	mov    $0x30,%eax
    67c6:	48 89 d6             	mov    %rdx,%rsi
    67c9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    67cd:	48 d1 ee             	shr    $1,%rsi
    67d0:	48 01 f2             	add    %rsi,%rdx
    67d3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    67d7:	48 29 d6             	sub    %rdx,%rsi
    67da:	74 8e                	je     676a <fwp_write+0x53a>
    67dc:	48 83 fe 01          	cmp    $0x1,%rsi
    67e0:	0f 85 7a ff ff ff    	jne    6760 <fwp_write+0x530>
    67e6:	31 f6                	xor    %esi,%esi
    67e8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    67ed:	e9 78 ff ff ff       	jmp    676a <fwp_write+0x53a>
    67f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    67f8:	66 0f 6e cd          	movd   %ebp,%xmm1
    67fc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    67ff:	0f 8a c8 09 00 00    	jp     71cd <fwp_write+0xf9d>
    6805:	0f 28 c1             	movaps %xmm1,%xmm0
    6808:	0f 54 05 61 2e 00 00 	andps  0x2e61(%rip),%xmm0        # 9670 <msg.3+0xa0>
    680f:	0f 2e 05 ee 27 00 00 	ucomiss 0x27ee(%rip),%xmm0        # 9004 <_IO_stdin_used+0x4>
    6816:	0f 87 24 08 00 00    	ja     7040 <fwp_write+0xe10>
    681c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6820:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6826:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    682d:	00 
    682e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    6832:	66 49 0f 7e d7       	movq   %xmm2,%r15
    6837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    683e:	00 00 
    6840:	44 89 ee             	mov    %r13d,%esi
    6843:	66 49 0f 6e c7       	movq   %r15,%xmm0
    6848:	4c 89 e7             	mov    %r12,%rdi
    684b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    6850:	e8 fb ca ff ff       	call   3350 <fwp_format_g.constprop.0>
    6855:	31 f6                	xor    %esi,%esi
    6857:	4c 89 e7             	mov    %r12,%rdi
    685a:	e8 31 bc ff ff       	call   2490 <strtof@plt>
    685f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    6864:	0f 2e c8             	ucomiss %xmm0,%xmm1
    6867:	7a 02                	jp     686b <fwp_write+0x63b>
    6869:	74 1c                	je     6887 <fwp_write+0x657>
    686b:	41 83 c5 01          	add    $0x1,%r13d
    686f:	41 83 fd 0a          	cmp    $0xa,%r13d
    6873:	75 cb                	jne    6840 <fwp_write+0x610>
    6875:	be 09 00 00 00       	mov    $0x9,%esi
    687a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    687f:	4c 89 e7             	mov    %r12,%rdi
    6882:	e8 c9 ca ff ff       	call   3350 <fwp_format_g.constprop.0>
    6887:	4c 89 e7             	mov    %r12,%rdi
    688a:	e8 51 c8 ff ff       	call   30e0 <fwp_finish_float>
    688f:	e9 1c fa ff ff       	jmp    62b0 <fwp_write+0x80>
    6894:	0f 1f 40 00          	nopl   0x0(%rax)
    6898:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    689c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    68a0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    68a7:	00 
    68a8:	48 89 ef             	mov    %rbp,%rdi
    68ab:	e8 50 c1 ff ff       	call   2a00 <fwp_fmt_u128>
    68b0:	48 89 ef             	mov    %rbp,%rdi
    68b3:	e8 78 bb ff ff       	call   2430 <strlen@plt>
    68b8:	48 89 ee             	mov    %rbp,%rsi
    68bb:	48 89 df             	mov    %rbx,%rdi
    68be:	48 89 c2             	mov    %rax,%rdx
    68c1:	e8 5a c7 ff ff       	call   3020 <buf_put>
    68c6:	e9 fb f9 ff ff       	jmp    62c6 <fwp_write+0x96>
    68cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68d0:	ba 06 00 00 00       	mov    $0x6,%edx
    68d5:	48 8d 35 9b 28 00 00 	lea    0x289b(%rip),%rsi        # 9177 <_IO_stdin_used+0x177>
    68dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    68e2:	e8 39 c7 ff ff       	call   3020 <buf_put>
    68e7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    68ee:	ff ff 7f 
    68f1:	48 23 55 00          	and    0x0(%rbp),%rdx
    68f5:	0f 84 86 02 00 00    	je     6b81 <fwp_write+0x951>
    68fb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6900:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    6904:	48 85 d2             	test   %rdx,%rdx
    6907:	0f 84 ae 00 00 00    	je     69bb <fwp_write+0x78b>
    690d:	8b 0a                	mov    (%rdx),%ecx
    690f:	83 f9 1c             	cmp    $0x1c,%ecx
    6912:	0f 84 58 06 00 00    	je     6f70 <fwp_write+0xd40>
    6918:	83 f9 1b             	cmp    $0x1b,%ecx
    691b:	0f 87 9a 00 00 00    	ja     69bb <fwp_write+0x78b>
    6921:	be 01 00 00 00       	mov    $0x1,%esi
    6926:	48 d3 e6             	shl    %cl,%rsi
    6929:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    692f:	0f 85 4b 04 00 00    	jne    6d80 <fwp_write+0xb50>
    6935:	f7 c6 84 04 00 00    	test   $0x484,%esi
    693b:	0f 85 0f 04 00 00    	jne    6d50 <fwp_write+0xb20>
    6941:	83 e6 21             	and    $0x21,%esi
    6944:	74 75                	je     69bb <fwp_write+0x78b>
    6946:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    694b:	48 85 ff             	test   %rdi,%rdi
    694e:	79 07                	jns    6957 <fwp_write+0x727>
    6950:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    6954:	4c 01 ee             	add    %r13,%rsi
    6957:	48 0f be 3e          	movsbq (%rsi),%rdi
    695b:	85 c9                	test   %ecx,%ecx
    695d:	40 0f b6 f7          	movzbl %dil,%esi
    6961:	48 0f 44 f7          	cmove  %rdi,%rsi
    6965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    696c:	00 00 00 00 
    6970:	31 c9                	xor    %ecx,%ecx
    6972:	48 89 df             	mov    %rbx,%rdi
    6975:	49 83 c5 01          	add    $0x1,%r13
    6979:	e8 b2 f8 ff ff       	call   6230 <fwp_write>
    697e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    6985:	ff ff 7f 
    6988:	48 23 55 00          	and    0x0(%rbp),%rdx
    698c:	49 39 d5             	cmp    %rdx,%r13
    698f:	0f 83 ec 01 00 00    	jae    6b81 <fwp_write+0x951>
    6995:	ba 02 00 00 00       	mov    $0x2,%edx
    699a:	48 89 df             	mov    %rbx,%rdi
    699d:	48 8d 35 d0 27 00 00 	lea    0x27d0(%rip),%rsi        # 9174 <_IO_stdin_used+0x174>
    69a4:	e8 77 c6 ff ff       	call   3020 <buf_put>
    69a9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    69ae:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    69b2:	48 85 d2             	test   %rdx,%rdx
    69b5:	0f 85 52 ff ff ff    	jne    690d <fwp_write+0x6dd>
    69bb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    69c0:	48 85 ff             	test   %rdi,%rdi
    69c3:	0f 88 cf 05 00 00    	js     6f98 <fwp_write+0xd68>
    69c9:	48 8b 31             	mov    (%rcx),%rsi
    69cc:	eb a2                	jmp    6970 <fwp_write+0x740>
    69ce:	66 90                	xchg   %ax,%ax
    69d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    69d7:	00 
    69d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    69df:	00 00 
    69e1:	0f 85 1e fd ff ff    	jne    6705 <fwp_write+0x4d5>
    69e7:	ba 08 00 00 00       	mov    $0x8,%edx
    69ec:	48 8d 35 51 27 00 00 	lea    0x2751(%rip),%rsi        # 9144 <_IO_stdin_used+0x144>
    69f3:	e9 4b fa ff ff       	jmp    6443 <fwp_write+0x213>
    69f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69ff:	00 
    6a00:	89 e8                	mov    %ebp,%eax
    6a02:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    6a09:	76 03                	jbe    6a0e <fwp_write+0x7de>
    6a0b:	8b 45 00             	mov    0x0(%rbp),%eax
    6a0e:	41 89 c6             	mov    %eax,%r14d
    6a11:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6a16:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    6a1b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    6a1f:	4c 89 ef             	mov    %r13,%rdi
    6a22:	e8 09 ba ff ff       	call   2430 <strlen@plt>
    6a27:	4c 89 ee             	mov    %r13,%rsi
    6a2a:	48 89 df             	mov    %rbx,%rdi
    6a2d:	48 89 c2             	mov    %rax,%rdx
    6a30:	e8 eb c5 ff ff       	call   3020 <buf_put>
    6a35:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    6a3a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    6a3e:	85 f6                	test   %esi,%esi
    6a40:	0f 8e 80 f8 ff ff    	jle    62c6 <fwp_write+0x96>
    6a46:	45 31 ed             	xor    %r13d,%r13d
    6a49:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6a4e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    6a53:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a58:	ba 01 00 00 00       	mov    $0x1,%edx
    6a5d:	4c 89 fe             	mov    %r15,%rsi
    6a60:	48 89 04 24          	mov    %rax,(%rsp)
    6a64:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    6a69:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    6a6d:	48 89 df             	mov    %rbx,%rdi
    6a70:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    6a74:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    6a79:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    6a7e:	e8 9d c5 ff ff       	call   3020 <buf_put>
    6a83:	41 8b 06             	mov    (%r14),%eax
    6a86:	83 f8 0e             	cmp    $0xe,%eax
    6a89:	0f 84 71 02 00 00    	je     6d00 <fwp_write+0xad0>
    6a8f:	83 f8 10             	cmp    $0x10,%eax
    6a92:	0f 84 38 02 00 00    	je     6cd0 <fwp_write+0xaa0>
    6a98:	83 f8 0a             	cmp    $0xa,%eax
    6a9b:	0f 84 7f 04 00 00    	je     6f20 <fwp_write+0xcf0>
    6aa1:	0f 8f f9 00 00 00    	jg     6ba0 <fwp_write+0x970>
    6aa7:	83 f8 03             	cmp    $0x3,%eax
    6aaa:	0f 8f 50 04 00 00    	jg     6f00 <fwp_write+0xcd0>
    6ab0:	85 c0                	test   %eax,%eax
    6ab2:	78 10                	js     6ac4 <fwp_write+0x894>
    6ab4:	48 8b 04 24          	mov    (%rsp),%rax
    6ab8:	48 c1 e8 3f          	shr    $0x3f,%rax
    6abc:	85 c0                	test   %eax,%eax
    6abe:	0f 85 f9 00 00 00    	jne    6bbd <fwp_write+0x98d>
    6ac4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6ac9:	48 8b 34 24          	mov    (%rsp),%rsi
    6acd:	31 c9                	xor    %ecx,%ecx
    6acf:	48 89 df             	mov    %rbx,%rdi
    6ad2:	e8 59 f7 ff ff       	call   6230 <fwp_write>
    6ad7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    6adc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ae1:	49 83 c5 01          	add    $0x1,%r13
    6ae5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    6ae9:	0f 8f 5f ff ff ff    	jg     6a4e <fwp_write+0x81e>
    6aef:	e9 d2 f7 ff ff       	jmp    62c6 <fwp_write+0x96>
    6af4:	0f 1f 40 00          	nopl   0x0(%rax)
    6af8:	ba 06 00 00 00       	mov    $0x6,%edx
    6afd:	48 8d 35 66 26 00 00 	lea    0x2666(%rip),%rsi        # 916a <_IO_stdin_used+0x16a>
    6b04:	45 31 ed             	xor    %r13d,%r13d
    6b07:	e8 14 c5 ff ff       	call   3020 <buf_put>
    6b0c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6b11:	75 19                	jne    6b2c <fwp_write+0x8fc>
    6b13:	eb 6c                	jmp    6b81 <fwp_write+0x951>
    6b15:	0f 1f 00             	nopl   (%rax)
    6b18:	ba 02 00 00 00       	mov    $0x2,%edx
    6b1d:	48 8d 35 50 26 00 00 	lea    0x2650(%rip),%rsi        # 9174 <_IO_stdin_used+0x174>
    6b24:	48 89 df             	mov    %rbx,%rdi
    6b27:	e8 f4 c4 ff ff       	call   3020 <buf_put>
    6b2c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    6b32:	b9 00 02 00 00       	mov    $0x200,%ecx
    6b37:	31 c0                	xor    %eax,%eax
    6b39:	49 83 c5 01          	add    $0x1,%r13
    6b3d:	4c 8d 05 2d 26 00 00 	lea    0x262d(%rip),%r8        # 9171 <_IO_stdin_used+0x171>
    6b44:	ba 02 00 00 00       	mov    $0x2,%edx
    6b49:	be 00 02 00 00       	mov    $0x200,%esi
    6b4e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6b55:	00 
    6b56:	e8 35 b8 ff ff       	call   2390 <__snprintf_chk@plt>
    6b5b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6b62:	00 
    6b63:	e8 c8 b8 ff ff       	call   2430 <strlen@plt>
    6b68:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    6b6f:	00 
    6b70:	48 89 df             	mov    %rbx,%rdi
    6b73:	48 89 c2             	mov    %rax,%rdx
    6b76:	e8 a5 c4 ff ff       	call   3020 <buf_put>
    6b7b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    6b7f:	72 97                	jb     6b18 <fwp_write+0x8e8>
    6b81:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6b86:	ba 01 00 00 00       	mov    $0x1,%edx
    6b8b:	48 89 df             	mov    %rbx,%rdi
    6b8e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6b93:	e8 88 c4 ff ff       	call   3020 <buf_put>
    6b98:	e9 29 f7 ff ff       	jmp    62c6 <fwp_write+0x96>
    6b9d:	0f 1f 00             	nopl   (%rax)
    6ba0:	83 f8 0b             	cmp    $0xb,%eax
    6ba3:	0f 85 1b ff ff ff    	jne    6ac4 <fwp_write+0x894>
    6ba9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6bae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    6bb2:	83 e0 01             	and    $0x1,%eax
    6bb5:	85 c0                	test   %eax,%eax
    6bb7:	0f 84 07 ff ff ff    	je     6ac4 <fwp_write+0x894>
    6bbd:	4c 89 fe             	mov    %r15,%rsi
    6bc0:	48 89 df             	mov    %rbx,%rdi
    6bc3:	ba 01 00 00 00       	mov    $0x1,%edx
    6bc8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6bcd:	e8 4e c4 ff ff       	call   3020 <buf_put>
    6bd2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6bd7:	48 8b 34 24          	mov    (%rsp),%rsi
    6bdb:	31 c9                	xor    %ecx,%ecx
    6bdd:	48 89 df             	mov    %rbx,%rdi
    6be0:	e8 4b f6 ff ff       	call   6230 <fwp_write>
    6be5:	ba 01 00 00 00       	mov    $0x1,%edx
    6bea:	4c 89 fe             	mov    %r15,%rsi
    6bed:	48 89 df             	mov    %rbx,%rdi
    6bf0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    6bf5:	e8 26 c4 ff ff       	call   3020 <buf_put>
    6bfa:	e9 d8 fe ff ff       	jmp    6ad7 <fwp_write+0x8a7>
    6bff:	90                   	nop
    6c00:	ba 01 00 00 00       	mov    $0x1,%edx
    6c05:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6c0a:	48 89 df             	mov    %rbx,%rdi
    6c0d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    6c12:	e8 09 c4 ff ff       	call   3020 <buf_put>
    6c17:	e9 aa f6 ff ff       	jmp    62c6 <fwp_write+0x96>
    6c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c20:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6c25:	ba 01 00 00 00       	mov    $0x1,%edx
    6c2a:	48 89 df             	mov    %rbx,%rdi
    6c2d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    6c32:	e8 e9 c3 ff ff       	call   3020 <buf_put>
    6c37:	e9 8a f6 ff ff       	jmp    62c6 <fwp_write+0x96>
    6c3c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c40:	48 8b 43 08          	mov    0x8(%rbx),%rax
    6c44:	48 8b 13             	mov    (%rbx),%rdx
    6c47:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    6c4c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6c50:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    6c54:	e9 6d f6 ff ff       	jmp    62c6 <fwp_write+0x96>
    6c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c60:	ba 02 00 00 00       	mov    $0x2,%edx
    6c65:	48 8d 35 08 25 00 00 	lea    0x2508(%rip),%rsi        # 9174 <_IO_stdin_used+0x174>
    6c6c:	48 89 df             	mov    %rbx,%rdi
    6c6f:	e8 ac c3 ff ff       	call   3020 <buf_put>
    6c74:	e9 72 f8 ff ff       	jmp    64eb <fwp_write+0x2bb>
    6c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c80:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    6c85:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c8a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    6c8e:	48 89 f7             	mov    %rsi,%rdi
    6c91:	48 89 34 24          	mov    %rsi,(%rsp)
    6c95:	e8 96 b7 ff ff       	call   2430 <strlen@plt>
    6c9a:	48 8b 34 24          	mov    (%rsp),%rsi
    6c9e:	48 89 df             	mov    %rbx,%rdi
    6ca1:	48 89 c2             	mov    %rax,%rdx
    6ca4:	e8 77 c3 ff ff       	call   3020 <buf_put>
    6ca9:	ba 03 00 00 00       	mov    $0x3,%edx
    6cae:	48 8d 35 e2 24 00 00 	lea    0x24e2(%rip),%rsi        # 9197 <_IO_stdin_used+0x197>
    6cb5:	48 89 df             	mov    %rbx,%rdi
    6cb8:	e8 63 c3 ff ff       	call   3020 <buf_put>
    6cbd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6cc2:	e9 35 f8 ff ff       	jmp    64fc <fwp_write+0x2cc>
    6cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cce:	00 00 
    6cd0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6cd5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    6cd9:	48 85 ff             	test   %rdi,%rdi
    6cdc:	0f 84 e2 fd ff ff    	je     6ac4 <fwp_write+0x894>
    6ce2:	48 8d 35 98 24 00 00 	lea    0x2498(%rip),%rsi        # 9181 <_IO_stdin_used+0x181>
    6ce9:	e8 22 b8 ff ff       	call   2510 <strcmp@plt>
    6cee:	85 c0                	test   %eax,%eax
    6cf0:	0f 95 c0             	setne  %al
    6cf3:	0f b6 c0             	movzbl %al,%eax
    6cf6:	e9 c1 fd ff ff       	jmp    6abc <fwp_write+0x88c>
    6cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d00:	31 c0                	xor    %eax,%eax
    6d02:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    6d09:	00 
    6d0a:	0f 97 c0             	seta   %al
    6d0d:	e9 aa fd ff ff       	jmp    6abc <fwp_write+0x88c>
    6d12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d18:	48 89 df             	mov    %rbx,%rdi
    6d1b:	ba 02 00 00 00       	mov    $0x2,%edx
    6d20:	48 8d 35 57 24 00 00 	lea    0x2457(%rip),%rsi        # 917e <_IO_stdin_used+0x17e>
    6d27:	e8 f4 c2 ff ff       	call   3020 <buf_put>
    6d2c:	4c 89 e8             	mov    %r13,%rax
    6d2f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    6d34:	31 c9                	xor    %ecx,%ecx
    6d36:	48 c1 e0 04          	shl    $0x4,%rax
    6d3a:	48 89 df             	mov    %rbx,%rdi
    6d3d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    6d42:	e8 e9 f4 ff ff       	call   6230 <fwp_write>
    6d47:	e9 5e f6 ff ff       	jmp    63aa <fwp_write+0x17a>
    6d4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d50:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    6d55:	48 85 ff             	test   %rdi,%rdi
    6d58:	79 0c                	jns    6d66 <fwp_write+0xb36>
    6d5a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    6d61:	00 
    6d62:	48 03 75 10          	add    0x10(%rbp),%rsi
    6d66:	48 63 3e             	movslq (%rsi),%rdi
    6d69:	83 f9 02             	cmp    $0x2,%ecx
    6d6c:	89 fe                	mov    %edi,%esi
    6d6e:	48 0f 44 f7          	cmove  %rdi,%rsi
    6d72:	e9 f9 fb ff ff       	jmp    6970 <fwp_write+0x740>
    6d77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d7e:	00 00 
    6d80:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    6d85:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    6d8a:	48 85 ff             	test   %rdi,%rdi
    6d8d:	0f 88 0f 03 00 00    	js     70a2 <fwp_write+0xe72>
    6d93:	49 0f bf 38          	movswq (%r8),%rdi
    6d97:	83 f9 01             	cmp    $0x1,%ecx
    6d9a:	0f b7 f7             	movzwl %di,%esi
    6d9d:	48 0f 44 f7          	cmove  %rdi,%rsi
    6da1:	e9 ca fb ff ff       	jmp    6970 <fwp_write+0x740>
    6da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dad:	00 00 00 
    6db0:	ba 01 00 00 00       	mov    $0x1,%edx
    6db5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6dba:	48 83 c5 08          	add    $0x8,%rbp
    6dbe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6dc3:	e8 58 c2 ff ff       	call   3020 <buf_put>
    6dc8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6dcd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    6dd2:	4d 85 ed             	test   %r13,%r13
    6dd5:	75 46                	jne    6e1d <fwp_write+0xbed>
    6dd7:	e9 04 01 00 00       	jmp    6ee0 <fwp_write+0xcb0>
    6ddc:	0f 1f 40 00          	nopl   0x0(%rax)
    6de0:	41 80 f9 09          	cmp    $0x9,%r9b
    6de4:	0f 84 d6 00 00 00    	je     6ec0 <fwp_write+0xc90>
    6dea:	41 80 f9 0a          	cmp    $0xa,%r9b
    6dee:	0f 85 9c 00 00 00    	jne    6e90 <fwp_write+0xc60>
    6df4:	ba 02 00 00 00       	mov    $0x2,%edx
    6df9:	48 8d 35 5a 23 00 00 	lea    0x235a(%rip),%rsi        # 915a <_IO_stdin_used+0x15a>
    6e00:	48 89 df             	mov    %rbx,%rdi
    6e03:	e8 18 c2 ff ff       	call   3020 <buf_put>
    6e08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e0f:	00 
    6e10:	48 83 c5 01          	add    $0x1,%rbp
    6e14:	49 39 ec             	cmp    %rbp,%r12
    6e17:	0f 84 c3 00 00 00    	je     6ee0 <fwp_write+0xcb0>
    6e1d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    6e22:	41 80 f9 0d          	cmp    $0xd,%r9b
    6e26:	74 28                	je     6e50 <fwp_write+0xc20>
    6e28:	7e b6                	jle    6de0 <fwp_write+0xbb0>
    6e2a:	41 80 f9 22          	cmp    $0x22,%r9b
    6e2e:	74 40                	je     6e70 <fwp_write+0xc40>
    6e30:	41 80 f9 5c          	cmp    $0x5c,%r9b
    6e34:	75 5a                	jne    6e90 <fwp_write+0xc60>
    6e36:	ba 02 00 00 00       	mov    $0x2,%edx
    6e3b:	48 8d 35 15 23 00 00 	lea    0x2315(%rip),%rsi        # 9157 <_IO_stdin_used+0x157>
    6e42:	48 89 df             	mov    %rbx,%rdi
    6e45:	e8 d6 c1 ff ff       	call   3020 <buf_put>
    6e4a:	eb c4                	jmp    6e10 <fwp_write+0xbe0>
    6e4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e50:	ba 02 00 00 00       	mov    $0x2,%edx
    6e55:	48 8d 35 04 23 00 00 	lea    0x2304(%rip),%rsi        # 9160 <_IO_stdin_used+0x160>
    6e5c:	48 89 df             	mov    %rbx,%rdi
    6e5f:	e8 bc c1 ff ff       	call   3020 <buf_put>
    6e64:	eb aa                	jmp    6e10 <fwp_write+0xbe0>
    6e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e6d:	00 00 00 
    6e70:	ba 02 00 00 00       	mov    $0x2,%edx
    6e75:	48 8d 35 d8 22 00 00 	lea    0x22d8(%rip),%rsi        # 9154 <_IO_stdin_used+0x154>
    6e7c:	48 89 df             	mov    %rbx,%rdi
    6e7f:	e8 9c c1 ff ff       	call   3020 <buf_put>
    6e84:	eb 8a                	jmp    6e10 <fwp_write+0xbe0>
    6e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e8d:	00 00 00 
    6e90:	41 80 f9 1f          	cmp    $0x1f,%r9b
    6e94:	0f 86 2e 01 00 00    	jbe    6fc8 <fwp_write+0xd98>
    6e9a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    6e9e:	0f 84 24 01 00 00    	je     6fc8 <fwp_write+0xd98>
    6ea4:	ba 01 00 00 00       	mov    $0x1,%edx
    6ea9:	4c 89 fe             	mov    %r15,%rsi
    6eac:	48 89 df             	mov    %rbx,%rdi
    6eaf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    6eb4:	e8 67 c1 ff ff       	call   3020 <buf_put>
    6eb9:	e9 52 ff ff ff       	jmp    6e10 <fwp_write+0xbe0>
    6ebe:	66 90                	xchg   %ax,%ax
    6ec0:	ba 02 00 00 00       	mov    $0x2,%edx
    6ec5:	48 8d 35 91 22 00 00 	lea    0x2291(%rip),%rsi        # 915d <_IO_stdin_used+0x15d>
    6ecc:	48 89 df             	mov    %rbx,%rdi
    6ecf:	e8 4c c1 ff ff       	call   3020 <buf_put>
    6ed4:	e9 37 ff ff ff       	jmp    6e10 <fwp_write+0xbe0>
    6ed9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ee0:	ba 01 00 00 00       	mov    $0x1,%edx
    6ee5:	4c 89 fe             	mov    %r15,%rsi
    6ee8:	48 89 df             	mov    %rbx,%rdi
    6eeb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    6ef0:	e8 2b c1 ff ff       	call   3020 <buf_put>
    6ef5:	e9 cc f3 ff ff       	jmp    62c6 <fwp_write+0x96>
    6efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f00:	83 f8 04             	cmp    $0x4,%eax
    6f03:	0f 85 bb fb ff ff    	jne    6ac4 <fwp_write+0x894>
    6f09:	48 8b 04 24          	mov    (%rsp),%rax
    6f0d:	48 8b 40 08          	mov    0x8(%rax),%rax
    6f11:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6f16:	48 c1 e8 3f          	shr    $0x3f,%rax
    6f1a:	e9 96 fc ff ff       	jmp    6bb5 <fwp_write+0x985>
    6f1f:	90                   	nop
    6f20:	8b 0c 24             	mov    (%rsp),%ecx
    6f23:	31 c0                	xor    %eax,%eax
    6f25:	85 c9                	test   %ecx,%ecx
    6f27:	0f 98 c0             	sets   %al
    6f2a:	e9 86 fc ff ff       	jmp    6bb5 <fwp_write+0x985>
    6f2f:	90                   	nop
    6f30:	48 f7 d8             	neg    %rax
    6f33:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    6f3a:	00 
    6f3b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    6f42:	2d 
    6f43:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6f4a:	00 
    6f4b:	48 83 d2 00          	adc    $0x0,%rdx
    6f4f:	48 89 c6             	mov    %rax,%rsi
    6f52:	48 f7 da             	neg    %rdx
    6f55:	e8 a6 ba ff ff       	call   2a00 <fwp_fmt_u128>
    6f5a:	e9 51 f3 ff ff       	jmp    62b0 <fwp_write+0x80>
    6f5f:	90                   	nop
    6f60:	b8 7d 00 00 00       	mov    $0x7d,%eax
    6f65:	e9 c3 f5 ff ff       	jmp    652d <fwp_write+0x2fd>
    6f6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f70:	4c 89 e9             	mov    %r13,%rcx
    6f73:	48 c1 e1 04          	shl    $0x4,%rcx
    6f77:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    6f7c:	48 85 ff             	test   %rdi,%rdi
    6f7f:	0f 89 eb f9 ff ff    	jns    6970 <fwp_write+0x740>
    6f85:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6f89:	48 89 ce             	mov    %rcx,%rsi
    6f8c:	e9 df f9 ff ff       	jmp    6970 <fwp_write+0x740>
    6f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f98:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6f9f:	00 
    6fa0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6fa4:	e9 20 fa ff ff       	jmp    69c9 <fwp_write+0x799>
    6fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fb0:	ba 02 00 00 00       	mov    $0x2,%edx
    6fb5:	48 8d 35 63 21 00 00 	lea    0x2163(%rip),%rsi        # 911f <_IO_stdin_used+0x11f>
    6fbc:	e9 2d f7 ff ff       	jmp    66ee <fwp_write+0x4be>
    6fc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fc8:	4c 8d 05 94 21 00 00 	lea    0x2194(%rip),%r8        # 9163 <_IO_stdin_used+0x163>
    6fcf:	b9 10 00 00 00       	mov    $0x10,%ecx
    6fd4:	31 c0                	xor    %eax,%eax
    6fd6:	ba 02 00 00 00       	mov    $0x2,%edx
    6fdb:	be 10 00 00 00       	mov    $0x10,%esi
    6fe0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6fe7:	00 
    6fe8:	e8 a3 b3 ff ff       	call   2390 <__snprintf_chk@plt>
    6fed:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6ff4:	00 
    6ff5:	e8 36 b4 ff ff       	call   2430 <strlen@plt>
    6ffa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    7001:	00 
    7002:	48 89 df             	mov    %rbx,%rdi
    7005:	48 89 c2             	mov    %rax,%rdx
    7008:	e8 13 c0 ff ff       	call   3020 <buf_put>
    700d:	e9 fe fd ff ff       	jmp    6e10 <fwp_write+0xbe0>
    7012:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7018:	66 0f ef c0          	pxor   %xmm0,%xmm0
    701c:	48 8d 35 f6 20 00 00 	lea    0x20f6(%rip),%rsi        # 9119 <_IO_stdin_used+0x119>
    7023:	48 8d 05 ee 20 00 00 	lea    0x20ee(%rip),%rax        # 9118 <_IO_stdin_used+0x118>
    702a:	4c 89 e7             	mov    %r12,%rdi
    702d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    7031:	48 0f 46 f0          	cmovbe %rax,%rsi
    7035:	e8 96 b3 ff ff       	call   23d0 <strcpy@plt>
    703a:	e9 71 f2 ff ff       	jmp    62b0 <fwp_write+0x80>
    703f:	90                   	nop
    7040:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7044:	48 8d 35 ce 20 00 00 	lea    0x20ce(%rip),%rsi        # 9119 <_IO_stdin_used+0x119>
    704b:	48 8d 05 c6 20 00 00 	lea    0x20c6(%rip),%rax        # 9118 <_IO_stdin_used+0x118>
    7052:	0f 2f c8             	comiss %xmm0,%xmm1
    7055:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    705c:	00 
    705d:	4c 89 e7             	mov    %r12,%rdi
    7060:	48 0f 46 f0          	cmovbe %rax,%rsi
    7064:	e8 67 b3 ff ff       	call   23d0 <strcpy@plt>
    7069:	e9 42 f2 ff ff       	jmp    62b0 <fwp_write+0x80>
    706e:	66 90                	xchg   %ax,%ax
    7070:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    7075:	45 85 c0             	test   %r8d,%r8d
    7078:	75 34                	jne    70ae <fwp_write+0xe7e>
    707a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7081:	00 
    7082:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7089:	00 00 
    708b:	0f 85 74 f6 ff ff    	jne    6705 <fwp_write+0x4d5>
    7091:	ba 02 00 00 00       	mov    $0x2,%edx
    7096:	48 8d 35 f7 20 00 00 	lea    0x20f7(%rip),%rsi        # 9194 <_IO_stdin_used+0x194>
    709d:	e9 a1 f3 ff ff       	jmp    6443 <fwp_write+0x213>
    70a2:	48 03 75 10          	add    0x10(%rbp),%rsi
    70a6:	49 89 f0             	mov    %rsi,%r8
    70a9:	e9 e5 fc ff ff       	jmp    6d93 <fwp_write+0xb63>
    70ae:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    70b3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    70b8:	85 ff                	test   %edi,%edi
    70ba:	0f 84 fa f3 ff ff    	je     64ba <fwp_write+0x28a>
    70c0:	ba 01 00 00 00       	mov    $0x1,%edx
    70c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    70ca:	48 89 df             	mov    %rbx,%rdi
    70cd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    70d2:	e8 49 bf ff ff       	call   3020 <buf_put>
    70d7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    70dc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    70e1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    70e7:	85 c0                	test   %eax,%eax
    70e9:	0f 8f f0 f3 ff ff    	jg     64df <fwp_write+0x2af>
    70ef:	e9 34 f4 ff ff       	jmp    6528 <fwp_write+0x2f8>
    70f4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    70f8:	49 89 c5             	mov    %rax,%r13
    70fb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7100:	49 89 c4             	mov    %rax,%r12
    7103:	49 c1 fd 3f          	sar    $0x3f,%r13
    7107:	4c 09 e8             	or     %r13,%rax
    710a:	0f 84 a7 00 00 00    	je     71b7 <fwp_write+0xf87>
    7110:	48 8d 2d a9 49 00 00 	lea    0x49a9(%rip),%rbp        # bac0 <units.0>
    7117:	4d 89 e7             	mov    %r12,%r15
    711a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    711e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    7123:	4c 89 ff             	mov    %r15,%rdi
    7126:	4c 89 ee             	mov    %r13,%rsi
    7129:	44 89 0c 24          	mov    %r9d,(%rsp)
    712d:	48 99                	cqto
    712f:	48 89 d1             	mov    %rdx,%rcx
    7132:	48 89 c2             	mov    %rax,%rdx
    7135:	e8 86 1a 00 00       	call   8bc0 <__divmodti4>
    713a:	44 8b 0c 24          	mov    (%rsp),%r9d
    713e:	48 89 c1             	mov    %rax,%rcx
    7141:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7146:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    714b:	0f 84 94 00 00 00    	je     71e5 <fwp_write+0xfb5>
    7151:	41 83 c1 01          	add    $0x1,%r9d
    7155:	48 83 c5 10          	add    $0x10,%rbp
    7159:	41 83 f9 05          	cmp    $0x5,%r9d
    715d:	75 bb                	jne    711a <fwp_write+0xeea>
    715f:	4d 85 ed             	test   %r13,%r13
    7162:	79 53                	jns    71b7 <fwp_write+0xf87>
    7164:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7169:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    716e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    7173:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7178:	48 99                	cqto
    717a:	48 f7 d8             	neg    %rax
    717d:	48 83 d2 00          	adc    $0x0,%rdx
    7181:	48 89 c6             	mov    %rax,%rsi
    7184:	48 f7 da             	neg    %rdx
    7187:	e8 74 b8 ff ff       	call   2a00 <fwp_fmt_u128>
    718c:	49 89 e8             	mov    %rbp,%r8
    718f:	ba 00 02 00 00       	mov    $0x200,%edx
    7194:	be 02 00 00 00       	mov    $0x2,%esi
    7199:	31 c0                	xor    %eax,%eax
    719b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    71a2:	00 
    71a3:	48 8d 0d e5 1f 00 00 	lea    0x1fe5(%rip),%rcx        # 918f <_IO_stdin_used+0x18f>
    71aa:	4c 89 e7             	mov    %r12,%rdi
    71ad:	e8 ee b4 ff ff       	call   26a0 <__sprintf_chk@plt>
    71b2:	e9 f9 f0 ff ff       	jmp    62b0 <fwp_write+0x80>
    71b7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    71bc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    71c1:	31 d2                	xor    %edx,%edx
    71c3:	48 89 ef             	mov    %rbp,%rdi
    71c6:	e8 35 b8 ff ff       	call   2a00 <fwp_fmt_u128>
    71cb:	eb bf                	jmp    718c <fwp_write+0xf5c>
    71cd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    71d4:	4e 61 4e 00 
    71d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    71df:	00 
    71e0:	e9 cb f0 ff ff       	jmp    62b0 <fwp_write+0x80>
    71e5:	44 89 0c 24          	mov    %r9d,(%rsp)
    71e9:	48 89 c8             	mov    %rcx,%rax
    71ec:	48 85 d2             	test   %rdx,%rdx
    71ef:	78 51                	js     7242 <fwp_write+0x1012>
    71f1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    71f6:	48 89 c6             	mov    %rax,%rsi
    71f9:	48 89 ef             	mov    %rbp,%rdi
    71fc:	e8 ff b7 ff ff       	call   2a00 <fwp_fmt_u128>
    7201:	44 8b 0c 24          	mov    (%rsp),%r9d
    7205:	49 63 c1             	movslq %r9d,%rax
    7208:	49 89 e8             	mov    %rbp,%r8
    720b:	ba 00 02 00 00       	mov    $0x200,%edx
    7210:	be 02 00 00 00       	mov    $0x2,%esi
    7215:	48 c1 e0 04          	shl    $0x4,%rax
    7219:	48 8d 3d a0 48 00 00 	lea    0x48a0(%rip),%rdi        # bac0 <units.0>
    7220:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7227:	00 
    7228:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    722c:	48 8d 0d 57 1f 00 00 	lea    0x1f57(%rip),%rcx        # 918a <_IO_stdin_used+0x18a>
    7233:	4c 89 e7             	mov    %r12,%rdi
    7236:	31 c0                	xor    %eax,%eax
    7238:	e8 63 b4 ff ff       	call   26a0 <__sprintf_chk@plt>
    723d:	e9 6e f0 ff ff       	jmp    62b0 <fwp_write+0x80>
    7242:	48 f7 d8             	neg    %rax
    7245:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    724a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    724f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7254:	48 83 d2 00          	adc    $0x0,%rdx
    7258:	48 89 c6             	mov    %rax,%rsi
    725b:	48 f7 da             	neg    %rdx
    725e:	e8 9d b7 ff ff       	call   2a00 <fwp_fmt_u128>
    7263:	44 8b 0c 24          	mov    (%rsp),%r9d
    7267:	eb 9c                	jmp    7205 <fwp_write+0xfd5>
    7269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007270 <f0>:
    7270:	41 57                	push   %r15
    7272:	41 56                	push   %r14
    7274:	41 55                	push   %r13
    7276:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    727c:	41 54                	push   %r12
    727e:	4c 8d 25 7b 54 01 00 	lea    0x1547b(%rip),%r12        # 1c700 <fwp_heap>
    7285:	55                   	push   %rbp
    7286:	31 ed                	xor    %ebp,%ebp
    7288:	53                   	push   %rbx
    7289:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    7290:	f3 0f 7e 35 88 49 00 	movq   0x4988(%rip),%xmm6        # bc20 <d0+0x80>
    7297:	00 
    7298:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    729f:	00 00 
    72a1:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    72a8:	00 
    72a9:	31 c0                	xor    %eax,%eax
    72ab:	48 8d 9c 24 10 01 00 	lea    0x110(%rsp),%rbx
    72b2:	00 
    72b3:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
    72ba:	00 00 00 00 00 
    72bf:	66 48 0f 6e c0       	movq   %rax,%xmm0
    72c4:	48 8d 05 e5 e6 ff ff 	lea    -0x191b(%rip),%rax        # 59b0 <fwp_drop0>
    72cb:	66 48 0f 6e f8       	movq   %rax,%xmm7
    72d0:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    72d4:	48 8d 05 e5 e8 ff ff 	lea    -0x171b(%rip),%rax        # 5bc0 <fwp_drop6>
    72db:	66 0f 6c ef          	punpcklqdq %xmm7,%xmm5
    72df:	66 48 0f 6e f8       	movq   %rax,%xmm7
    72e4:	48 8d 05 c5 e8 ff ff 	lea    -0x173b(%rip),%rax        # 5bb0 <fwp_drop1>
    72eb:	66 0f 6c f7          	punpcklqdq %xmm7,%xmm6
    72ef:	66 48 0f 6e f8       	movq   %rax,%xmm7
    72f4:	48 8b 05 95 70 01 00 	mov    0x17095(%rip),%rax        # 1e390 <fwp_cleanups>
    72fb:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    7300:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    7304:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
    7309:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    7310:	00 
    7311:	48 8d 05 78 b8 ff ff 	lea    -0x4788(%rip),%rax        # 2b90 <fwp_range_release>
    7318:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    731f:	00 
    7320:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    7327:	00 
    7328:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    732d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    7334:	00 
    7335:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    733c:	00 
    733d:	48 89 04 24          	mov    %rax,(%rsp)
    7341:	48 89 05 48 70 01 00 	mov    %rax,0x17048(%rip)        # 1e390 <fwp_cleanups>
    7348:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    734f:	00 
    7350:	eb 44                	jmp    7396 <f0+0x126>
    7352:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7358:	80 f9 01             	cmp    $0x1,%cl
    735b:	75 27                	jne    7384 <f0+0x114>
    735d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7360:	0f b7 c0             	movzwl %ax,%eax
    7363:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7366:	48 0f af c1          	imul   %rcx,%rax
    736a:	48 c1 e8 20          	shr    $0x20,%rax
    736e:	48 39 d0             	cmp    %rdx,%rax
    7371:	73 11                	jae    7384 <f0+0x114>
    7373:	49 01 c6             	add    %rax,%r14
    7376:	41 80 3e ff          	cmpb   $0xff,(%r14)
    737a:	0f 84 d4 0f 00 00    	je     8354 <f0+0x10e4>
    7380:	41 c6 06 01          	movb   $0x1,(%r14)
    7384:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
    738b:	00 
    738c:	49 83 ed 01          	sub    $0x1,%r13
    7390:	0f 82 88 00 00 00    	jb     741e <f0+0x1ae>
    7396:	48 89 de             	mov    %rbx,%rsi
    7399:	bf 01 00 00 00       	mov    $0x1,%edi
    739e:	48 89 ac 24 18 01 00 	mov    %rbp,0x118(%rsp)
    73a5:	00 
    73a6:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    73ad:	00 
    73ae:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    73b5:	00 
    73b6:	e8 85 dc ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    73bb:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    73c2:	00 
    73c3:	48 89 c5             	mov    %rax,%rbp
    73c6:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    73cd:	00 
    73ce:	48 c1 e2 10          	shl    $0x10,%rdx
    73d2:	48 39 d0             	cmp    %rdx,%rax
    73d5:	73 ad                	jae    7384 <f0+0x114>
    73d7:	48 89 c2             	mov    %rax,%rdx
    73da:	48 c1 ea 10          	shr    $0x10,%rdx
    73de:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73e2:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    73e9:	00 
    73ea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73ee:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    73f2:	4d 85 f6             	test   %r14,%r14
    73f5:	74 8d                	je     7384 <f0+0x114>
    73f7:	0f b6 0a             	movzbl (%rdx),%ecx
    73fa:	80 f9 02             	cmp    $0x2,%cl
    73fd:	0f 85 55 ff ff ff    	jne    7358 <f0+0xe8>
    7403:	66 85 c0             	test   %ax,%ax
    7406:	0f 84 6a ff ff ff    	je     7376 <f0+0x106>
    740c:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
    7413:	00 
    7414:	49 83 ed 01          	sub    $0x1,%r13
    7418:	0f 83 78 ff ff ff    	jae    7396 <f0+0x126>
    741e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    7425:	00 
    7426:	66 0f 6f 05 62 22 00 	movdqa 0x2262(%rip),%xmm0        # 9690 <msg.3+0xc0>
    742d:	00 
    742e:	bf 01 00 00 00       	mov    $0x1,%edi
    7433:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    743a:	00 
    743b:	48 89 05 4e 6f 01 00 	mov    %rax,0x16f4e(%rip)        # 1e390 <fwp_cleanups>
    7442:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    7449:	00 
    744a:	e8 f1 db ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    744f:	48 8b 15 82 66 01 00 	mov    0x16682(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    7456:	49 89 c7             	mov    %rax,%r15
    7459:	48 2b 05 50 66 01 00 	sub    0x16650(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    7460:	48 c1 e2 10          	shl    $0x10,%rdx
    7464:	48 39 d0             	cmp    %rdx,%rax
    7467:	73 59                	jae    74c2 <f0+0x252>
    7469:	48 89 c2             	mov    %rax,%rdx
    746c:	48 c1 ea 10          	shr    $0x10,%rdx
    7470:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7474:	48 8b 15 7d 66 01 00 	mov    0x1667d(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    747b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    747f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7483:	4d 85 ed             	test   %r13,%r13
    7486:	74 3a                	je     74c2 <f0+0x252>
    7488:	0f b6 0a             	movzbl (%rdx),%ecx
    748b:	80 f9 02             	cmp    $0x2,%cl
    748e:	0f 84 1b 0f 00 00    	je     83af <f0+0x113f>
    7494:	80 f9 01             	cmp    $0x1,%cl
    7497:	75 29                	jne    74c2 <f0+0x252>
    7499:	8b 4a 18             	mov    0x18(%rdx),%ecx
    749c:	0f b7 c0             	movzwl %ax,%eax
    749f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74a2:	48 0f af c1          	imul   %rcx,%rax
    74a6:	48 c1 e8 20          	shr    $0x20,%rax
    74aa:	48 39 d0             	cmp    %rdx,%rax
    74ad:	73 13                	jae    74c2 <f0+0x252>
    74af:	49 01 c5             	add    %rax,%r13
    74b2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    74b7:	0f 84 0d 0f 00 00    	je     83ca <f0+0x115a>
    74bd:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    74c2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    74c9:	00 f0 3f 
    74cc:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    74d3:	00 
    74d4:	bf 01 00 00 00       	mov    $0x1,%edi
    74d9:	4c 89 bc 24 e8 00 00 	mov    %r15,0xe8(%rsp)
    74e0:	00 
    74e1:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
    74e8:	00 
    74e9:	e8 52 db ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    74ee:	48 8b 15 e3 65 01 00 	mov    0x165e3(%rip),%rdx        # 1dad8 <fwp_heap+0x13d8>
    74f5:	49 89 c7             	mov    %rax,%r15
    74f8:	48 2b 05 b1 65 01 00 	sub    0x165b1(%rip),%rax        # 1dab0 <fwp_heap+0x13b0>
    74ff:	48 c1 e2 10          	shl    $0x10,%rdx
    7503:	48 39 d0             	cmp    %rdx,%rax
    7506:	73 59                	jae    7561 <f0+0x2f1>
    7508:	48 89 c2             	mov    %rax,%rdx
    750b:	48 c1 ea 10          	shr    $0x10,%rdx
    750f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7513:	48 8b 15 de 65 01 00 	mov    0x165de(%rip),%rdx        # 1daf8 <fwp_heap+0x13f8>
    751a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    751e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7522:	4d 85 ed             	test   %r13,%r13
    7525:	74 3a                	je     7561 <f0+0x2f1>
    7527:	0f b6 0a             	movzbl (%rdx),%ecx
    752a:	80 f9 02             	cmp    $0x2,%cl
    752d:	0f 84 6e 0e 00 00    	je     83a1 <f0+0x1131>
    7533:	80 f9 01             	cmp    $0x1,%cl
    7536:	75 29                	jne    7561 <f0+0x2f1>
    7538:	8b 4a 18             	mov    0x18(%rdx),%ecx
    753b:	0f b7 c0             	movzwl %ax,%eax
    753e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7541:	48 0f af c1          	imul   %rcx,%rax
    7545:	48 c1 e8 20          	shr    $0x20,%rax
    7549:	48 39 d0             	cmp    %rdx,%rax
    754c:	73 13                	jae    7561 <f0+0x2f1>
    754e:	49 01 c5             	add    %rax,%r13
    7551:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7556:	0f 84 7b 0e 00 00    	je     83d7 <f0+0x1167>
    755c:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    7561:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    7568:	33 f3 bf 
    756b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    7572:	00 
    7573:	bf 01 00 00 00       	mov    $0x1,%edi
    7578:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
    757f:	00 
    7580:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
    7587:	00 
    7588:	e8 b3 da ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    758d:	48 8b 0d 44 65 01 00 	mov    0x16544(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    7594:	48 8b 35 15 65 01 00 	mov    0x16515(%rip),%rsi        # 1dab0 <fwp_heap+0x13b0>
    759b:	48 89 c2             	mov    %rax,%rdx
    759e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    75a3:	48 89 cf             	mov    %rcx,%rdi
    75a6:	48 29 f2             	sub    %rsi,%rdx
    75a9:	48 c1 e7 10          	shl    $0x10,%rdi
    75ad:	48 39 fa             	cmp    %rdi,%rdx
    75b0:	73 6b                	jae    761d <f0+0x3ad>
    75b2:	48 89 d7             	mov    %rdx,%rdi
    75b5:	48 c1 ef 10          	shr    $0x10,%rdi
    75b9:	4c 8d 0c bf          	lea    (%rdi,%rdi,4),%r9
    75bd:	48 8b 3d 34 65 01 00 	mov    0x16534(%rip),%rdi        # 1daf8 <fwp_heap+0x13f8>
    75c4:	4a 8d 3c cf          	lea    (%rdi,%r9,8),%rdi
    75c8:	4c 8b 6f 20          	mov    0x20(%rdi),%r13
    75cc:	4d 85 ed             	test   %r13,%r13
    75cf:	74 4c                	je     761d <f0+0x3ad>
    75d1:	44 0f b6 0f          	movzbl (%rdi),%r9d
    75d5:	41 80 f9 02          	cmp    $0x2,%r9b
    75d9:	0f 84 b4 0d 00 00    	je     8393 <f0+0x1123>
    75df:	41 80 f9 01          	cmp    $0x1,%r9b
    75e3:	75 38                	jne    761d <f0+0x3ad>
    75e5:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    75e9:	0f b7 d2             	movzwl %dx,%edx
    75ec:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    75ef:	49 0f af d1          	imul   %r9,%rdx
    75f3:	48 c1 ea 20          	shr    $0x20,%rdx
    75f7:	48 39 fa             	cmp    %rdi,%rdx
    75fa:	73 21                	jae    761d <f0+0x3ad>
    75fc:	49 01 d5             	add    %rdx,%r13
    75ff:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7604:	0f 84 b3 0d 00 00    	je     83bd <f0+0x114d>
    760a:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    760f:	48 8b 35 9a 64 01 00 	mov    0x1649a(%rip),%rsi        # 1dab0 <fwp_heap+0x13b0>
    7616:	48 8b 0d bb 64 01 00 	mov    0x164bb(%rip),%rcx        # 1dad8 <fwp_heap+0x13d8>
    761d:	48 8d 44 24 78       	lea    0x78(%rsp),%rax
    7622:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
    7627:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    762c:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
    7633:	00 
    7634:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7639:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
    763e:	66 90                	xchg   %ax,%ax
    7640:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7645:	48 c1 e1 10          	shl    $0x10,%rcx
    7649:	48 29 f0             	sub    %rsi,%rax
    764c:	48 39 c8             	cmp    %rcx,%rax
    764f:	0f 83 8a 00 00 00    	jae    76df <f0+0x46f>
    7655:	48 89 c2             	mov    %rax,%rdx
    7658:	48 c1 ea 10          	shr    $0x10,%rdx
    765c:	48 8d 3c 92          	lea    (%rdx,%rdx,4),%rdi
    7660:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7667:	00 
    7668:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
    766c:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7670:	48 85 ff             	test   %rdi,%rdi
    7673:	74 6a                	je     76df <f0+0x46f>
    7675:	44 0f b6 02          	movzbl (%rdx),%r8d
    7679:	41 80 f8 02          	cmp    $0x2,%r8b
    767d:	0f 84 2d 0c 00 00    	je     82b0 <f0+0x1040>
    7683:	41 80 f8 01          	cmp    $0x1,%r8b
    7687:	75 56                	jne    76df <f0+0x46f>
    7689:	44 8b 42 18          	mov    0x18(%rdx),%r8d
    768d:	0f b7 c0             	movzwl %ax,%eax
    7690:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7693:	49 0f af c0          	imul   %r8,%rax
    7697:	48 c1 e8 20          	shr    $0x20,%rax
    769b:	48 39 d0             	cmp    %rdx,%rax
    769e:	73 3f                	jae    76df <f0+0x46f>
    76a0:	48 01 c7             	add    %rax,%rdi
    76a3:	0f b6 07             	movzbl (%rdi),%eax
    76a6:	84 c0                	test   %al,%al
    76a8:	74 35                	je     76df <f0+0x46f>
    76aa:	44 8b 0d 0f 6d 01 00 	mov    0x16d0f(%rip),%r9d        # 1e3c0 <iteration_active>
    76b1:	45 85 c9             	test   %r9d,%r9d
    76b4:	74 08                	je     76be <f0+0x44e>
    76b6:	48 83 05 ea 6c 01 00 	addq   $0x1,0x16cea(%rip)        # 1e3a8 <iteration_retains>
    76bd:	01 
    76be:	3c fd                	cmp    $0xfd,%al
    76c0:	0f 87 af 0c 00 00    	ja     8375 <f0+0x1105>
    76c6:	83 c0 01             	add    $0x1,%eax
    76c9:	88 07                	mov    %al,(%rdi)
    76cb:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    76d2:	00 
    76d3:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    76da:	00 
    76db:	48 c1 e1 10          	shl    $0x10,%rcx
    76df:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    76e4:	4c 8b 78 10          	mov    0x10(%rax),%r15
    76e8:	4c 89 f8             	mov    %r15,%rax
    76eb:	48 29 f0             	sub    %rsi,%rax
    76ee:	48 39 c8             	cmp    %rcx,%rax
    76f1:	73 72                	jae    7765 <f0+0x4f5>
    76f3:	48 89 c2             	mov    %rax,%rdx
    76f6:	48 c1 ea 10          	shr    $0x10,%rdx
    76fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76fe:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7705:	00 
    7706:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    770a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    770e:	48 85 ff             	test   %rdi,%rdi
    7711:	74 52                	je     7765 <f0+0x4f5>
    7713:	0f b6 0a             	movzbl (%rdx),%ecx
    7716:	80 f9 02             	cmp    $0x2,%cl
    7719:	0f 84 81 0b 00 00    	je     82a0 <f0+0x1030>
    771f:	80 f9 01             	cmp    $0x1,%cl
    7722:	75 41                	jne    7765 <f0+0x4f5>
    7724:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7727:	0f b7 c0             	movzwl %ax,%eax
    772a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    772d:	48 0f af c1          	imul   %rcx,%rax
    7731:	48 c1 e8 20          	shr    $0x20,%rax
    7735:	48 39 d0             	cmp    %rdx,%rax
    7738:	73 2b                	jae    7765 <f0+0x4f5>
    773a:	48 01 c7             	add    %rax,%rdi
    773d:	0f b6 07             	movzbl (%rdi),%eax
    7740:	84 c0                	test   %al,%al
    7742:	74 21                	je     7765 <f0+0x4f5>
    7744:	44 8b 05 75 6c 01 00 	mov    0x16c75(%rip),%r8d        # 1e3c0 <iteration_active>
    774b:	45 85 c0             	test   %r8d,%r8d
    774e:	74 08                	je     7758 <f0+0x4e8>
    7750:	48 83 05 50 6c 01 00 	addq   $0x1,0x16c50(%rip)        # 1e3a8 <iteration_retains>
    7757:	01 
    7758:	3c fd                	cmp    $0xfd,%al
    775a:	0f 87 0b 0c 00 00    	ja     836b <f0+0x10fb>
    7760:	83 c0 01             	add    $0x1,%eax
    7763:	88 07                	mov    %al,(%rdi)
    7765:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    776a:	4c 89 ff             	mov    %r15,%rdi
    776d:	e8 6e df ff ff       	call   56e0 <fwp_map_items>
    7772:	66 0f 6f 6c 24 50    	movdqa 0x50(%rsp),%xmm5
    7778:	48 8b 34 24          	mov    (%rsp),%rsi
    777c:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7783:	00 00 00 00 00 
    7788:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    778d:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7794:	00 
    7795:	48 89 c5             	mov    %rax,%rbp
    7798:	0f 11 ac 24 b8 00 00 	movups %xmm5,0xb8(%rsp)
    779f:	00 
    77a0:	e8 3b df ff ff       	call   56e0 <fwp_map_items>
    77a5:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
    77ac:	00 
    77ad:	49 89 c5             	mov    %rax,%r13
    77b0:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    77b5:	49 39 c0             	cmp    %rax,%r8
    77b8:	49 0f 46 c0          	cmovbe %r8,%rax
    77bc:	48 89 c2             	mov    %rax,%rdx
    77bf:	48 85 c0             	test   %rax,%rax
    77c2:	0f 84 50 0a 00 00    	je     8218 <f0+0xfa8>
    77c8:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
    77cd:	45 31 f6             	xor    %r14d,%r14d
    77d0:	4d 89 ef             	mov    %r13,%r15
    77d3:	49 89 ed             	mov    %rbp,%r13
    77d6:	48 89 c5             	mov    %rax,%rbp
    77d9:	eb 43                	jmp    781e <f0+0x5ae>
    77db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    77e0:	41 80 f8 01          	cmp    $0x1,%r8b
    77e4:	75 26                	jne    780c <f0+0x59c>
    77e6:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    77ea:	0f b7 c0             	movzwl %ax,%eax
    77ed:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    77f0:	49 0f af c0          	imul   %r8,%rax
    77f4:	48 c1 e8 20          	shr    $0x20,%rax
    77f8:	48 39 f8             	cmp    %rdi,%rax
    77fb:	73 0f                	jae    780c <f0+0x59c>
    77fd:	48 01 c1             	add    %rax,%rcx
    7800:	80 39 ff             	cmpb   $0xff,(%rcx)
    7803:	0f 84 e7 09 00 00    	je     81f0 <f0+0xf80>
    7809:	c6 01 01             	movb   $0x1,(%rcx)
    780c:	4b 89 74 f5 00       	mov    %rsi,0x0(%r13,%r14,8)
    7811:	49 83 c6 01          	add    $0x1,%r14
    7815:	4c 39 f5             	cmp    %r14,%rbp
    7818:	0f 84 d2 00 00 00    	je     78f0 <f0+0x680>
    781e:	f2 43 0f 10 1c f7    	movsd  (%r15,%r14,8),%xmm3
    7824:	f2 43 0f 10 4c f5 00 	movsd  0x0(%r13,%r14,8),%xmm1
    782b:	48 89 de             	mov    %rbx,%rsi
    782e:	31 ff                	xor    %edi,%edi
    7830:	f2 0f 10 15 c8 1d 00 	movsd  0x1dc8(%rip),%xmm2        # 9600 <msg.3+0x30>
    7837:	00 
    7838:	66 0f 28 c3          	movapd %xmm3,%xmm0
    783c:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    7840:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    7844:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    7848:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    784c:	f2 0f 10 05 a4 1d 00 	movsd  0x1da4(%rip),%xmm0        # 95f8 <msg.3+0x28>
    7853:	00 
    7854:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    7858:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    785c:	f2 0f 59 0d a4 1d 00 	mulsd  0x1da4(%rip),%xmm1        # 9608 <msg.3+0x38>
    7863:	00 
    7864:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    7868:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    786c:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    7873:	00 
    7874:	e8 c7 d7 ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    7879:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    7880:	00 
    7881:	48 89 c6             	mov    %rax,%rsi
    7884:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    788b:	00 
    788c:	48 c1 e1 10          	shl    $0x10,%rcx
    7890:	48 39 c8             	cmp    %rcx,%rax
    7893:	0f 83 73 ff ff ff    	jae    780c <f0+0x59c>
    7899:	48 89 c1             	mov    %rax,%rcx
    789c:	48 c1 e9 10          	shr    $0x10,%rcx
    78a0:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    78a4:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    78ab:	00 
    78ac:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    78b0:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    78b4:	48 85 c9             	test   %rcx,%rcx
    78b7:	0f 84 4f ff ff ff    	je     780c <f0+0x59c>
    78bd:	44 0f b6 07          	movzbl (%rdi),%r8d
    78c1:	41 80 f8 02          	cmp    $0x2,%r8b
    78c5:	0f 85 15 ff ff ff    	jne    77e0 <f0+0x570>
    78cb:	66 85 c0             	test   %ax,%ax
    78ce:	0f 84 2c ff ff ff    	je     7800 <f0+0x590>
    78d4:	4b 89 74 f5 00       	mov    %rsi,0x0(%r13,%r14,8)
    78d9:	49 83 c6 01          	add    $0x1,%r14
    78dd:	4c 39 f5             	cmp    %r14,%rbp
    78e0:	0f 85 38 ff ff ff    	jne    781e <f0+0x5ae>
    78e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ed:	00 00 00 
    78f0:	4d 89 fd             	mov    %r15,%r13
    78f3:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
    78f8:	48 89 ea             	mov    %rbp,%rdx
    78fb:	4c 89 ef             	mov    %r13,%rdi
    78fe:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    7903:	e8 c8 c9 ff ff       	call   42d0 <fwp_mem_free>
    7908:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    790d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7912:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    7919:	00 
    791a:	e8 81 da ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    791f:	4c 89 ff             	mov    %r15,%rdi
    7922:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    7927:	e8 84 e0 ff ff       	call   59b0 <fwp_drop0>
    792c:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
    7931:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7935:	bf 01 00 00 00       	mov    $0x1,%edi
    793a:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    7941:	00 
    7942:	e8 f9 d6 ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    7947:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    794e:	00 
    794f:	49 89 c5             	mov    %rax,%r13
    7952:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7959:	00 
    795a:	48 c1 e2 10          	shl    $0x10,%rdx
    795e:	48 39 d0             	cmp    %rdx,%rax
    7961:	73 58                	jae    79bb <f0+0x74b>
    7963:	48 89 c2             	mov    %rax,%rdx
    7966:	48 c1 ea 10          	shr    $0x10,%rdx
    796a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    796e:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7975:	00 
    7976:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    797a:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    797e:	4d 85 f6             	test   %r14,%r14
    7981:	74 38                	je     79bb <f0+0x74b>
    7983:	0f b6 0a             	movzbl (%rdx),%ecx
    7986:	80 f9 02             	cmp    $0x2,%cl
    7989:	0f 84 d1 08 00 00    	je     8260 <f0+0xff0>
    798f:	80 f9 01             	cmp    $0x1,%cl
    7992:	75 27                	jne    79bb <f0+0x74b>
    7994:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7997:	0f b7 c0             	movzwl %ax,%eax
    799a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    799d:	48 0f af c1          	imul   %rcx,%rax
    79a1:	48 c1 e8 20          	shr    $0x20,%rax
    79a5:	48 39 d0             	cmp    %rdx,%rax
    79a8:	73 11                	jae    79bb <f0+0x74b>
    79aa:	49 01 c6             	add    %rax,%r14
    79ad:	41 80 3e ff          	cmpb   $0xff,(%r14)
    79b1:	0f 84 bc 08 00 00    	je     8273 <f0+0x1003>
    79b7:	41 c6 06 01          	movb   $0x1,(%r14)
    79bb:	48 8b 34 24          	mov    (%rsp),%rsi
    79bf:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    79c4:	e8 17 dd ff ff       	call   56e0 <fwp_map_items>
    79c9:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    79cf:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
    79d6:	00 
    79d7:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    79de:	00 00 00 00 00 
    79e3:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    79ea:	00 
    79eb:	0f 11 b4 24 b8 00 00 	movups %xmm6,0xb8(%rsp)
    79f2:	00 
    79f3:	48 85 ed             	test   %rbp,%rbp
    79f6:	0f 84 d6 00 00 00    	je     7ad2 <f0+0x862>
    79fc:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    7a01:	45 31 f6             	xor    %r14d,%r14d
    7a04:	48 89 c3             	mov    %rax,%rbx
    7a07:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
    7a0c:	eb 60                	jmp    7a6e <f0+0x7fe>
    7a0e:	66 90                	xchg   %ax,%ax
    7a10:	40 80 fe 01          	cmp    $0x1,%sil
    7a14:	75 3f                	jne    7a55 <f0+0x7e5>
    7a16:	8b 72 18             	mov    0x18(%rdx),%esi
    7a19:	0f b7 c0             	movzwl %ax,%eax
    7a1c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a1f:	48 0f af c6          	imul   %rsi,%rax
    7a23:	48 c1 e8 20          	shr    $0x20,%rax
    7a27:	48 39 d0             	cmp    %rdx,%rax
    7a2a:	73 29                	jae    7a55 <f0+0x7e5>
    7a2c:	48 01 c7             	add    %rax,%rdi
    7a2f:	0f b6 07             	movzbl (%rdi),%eax
    7a32:	84 c0                	test   %al,%al
    7a34:	74 1f                	je     7a55 <f0+0x7e5>
    7a36:	8b 35 84 69 01 00    	mov    0x16984(%rip),%esi        # 1e3c0 <iteration_active>
    7a3c:	85 f6                	test   %esi,%esi
    7a3e:	74 08                	je     7a48 <f0+0x7d8>
    7a40:	48 83 05 60 69 01 00 	addq   $0x1,0x16960(%rip)        # 1e3a8 <iteration_retains>
    7a47:	01 
    7a48:	3c fd                	cmp    $0xfd,%al
    7a4a:	0f 87 f0 07 00 00    	ja     8240 <f0+0xfd0>
    7a50:	83 c0 01             	add    $0x1,%eax
    7a53:	88 07                	mov    %al,(%rdi)
    7a55:	4d 8b 6f 08          	mov    0x8(%r15),%r13
    7a59:	4c 89 ff             	mov    %r15,%rdi
    7a5c:	e8 2f dd ff ff       	call   5790 <fwp_drop4>
    7a61:	4e 89 2c f3          	mov    %r13,(%rbx,%r14,8)
    7a65:	49 83 c6 01          	add    $0x1,%r14
    7a69:	49 39 ee             	cmp    %rbp,%r14
    7a6c:	74 5a                	je     7ac8 <f0+0x858>
    7a6e:	4e 8b 3c f3          	mov    (%rbx,%r14,8),%r15
    7a72:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7a79:	00 
    7a7a:	4c 89 f8             	mov    %r15,%rax
    7a7d:	48 c1 e2 10          	shl    $0x10,%rdx
    7a81:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7a88:	00 
    7a89:	48 39 d0             	cmp    %rdx,%rax
    7a8c:	73 c7                	jae    7a55 <f0+0x7e5>
    7a8e:	48 89 c2             	mov    %rax,%rdx
    7a91:	48 c1 ea 10          	shr    $0x10,%rdx
    7a95:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    7a99:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7aa0:	00 
    7aa1:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    7aa5:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7aa9:	48 85 ff             	test   %rdi,%rdi
    7aac:	74 a7                	je     7a55 <f0+0x7e5>
    7aae:	0f b6 32             	movzbl (%rdx),%esi
    7ab1:	40 80 fe 02          	cmp    $0x2,%sil
    7ab5:	0f 85 55 ff ff ff    	jne    7a10 <f0+0x7a0>
    7abb:	66 85 c0             	test   %ax,%ax
    7abe:	75 95                	jne    7a55 <f0+0x7e5>
    7ac0:	e9 6a ff ff ff       	jmp    7a2f <f0+0x7bf>
    7ac5:	0f 1f 00             	nopl   (%rax)
    7ac8:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
    7acd:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
    7ad2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7ad7:	48 89 ac 24 a8 00 00 	mov    %rbp,0xa8(%rsp)
    7ade:	00 
    7adf:	4c 89 ff             	mov    %r15,%rdi
    7ae2:	e8 b9 d8 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    7ae7:	4c 89 fe             	mov    %r15,%rsi
    7aea:	48 89 c7             	mov    %rax,%rdi
    7aed:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7af2:	e8 e9 db ff ff       	call   56e0 <fwp_map_items>
    7af7:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7afe:	00 
    7aff:	49 89 c7             	mov    %rax,%r15
    7b02:	4c 89 e8             	mov    %r13,%rax
    7b05:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7b0c:	00 
    7b0d:	48 c1 e2 10          	shl    $0x10,%rdx
    7b11:	48 39 d0             	cmp    %rdx,%rax
    7b14:	73 70                	jae    7b86 <f0+0x916>
    7b16:	48 89 c2             	mov    %rax,%rdx
    7b19:	48 c1 ea 10          	shr    $0x10,%rdx
    7b1d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b21:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7b28:	00 
    7b29:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b2d:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b31:	48 85 ff             	test   %rdi,%rdi
    7b34:	74 50                	je     7b86 <f0+0x916>
    7b36:	0f b6 0a             	movzbl (%rdx),%ecx
    7b39:	80 f9 02             	cmp    $0x2,%cl
    7b3c:	0f 84 3e 07 00 00    	je     8280 <f0+0x1010>
    7b42:	80 f9 01             	cmp    $0x1,%cl
    7b45:	75 3f                	jne    7b86 <f0+0x916>
    7b47:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b4a:	0f b7 c0             	movzwl %ax,%eax
    7b4d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b50:	48 0f af c1          	imul   %rcx,%rax
    7b54:	48 c1 e8 20          	shr    $0x20,%rax
    7b58:	48 39 d0             	cmp    %rdx,%rax
    7b5b:	73 29                	jae    7b86 <f0+0x916>
    7b5d:	48 01 c7             	add    %rax,%rdi
    7b60:	0f b6 07             	movzbl (%rdi),%eax
    7b63:	84 c0                	test   %al,%al
    7b65:	74 1f                	je     7b86 <f0+0x916>
    7b67:	8b 0d 53 68 01 00    	mov    0x16853(%rip),%ecx        # 1e3c0 <iteration_active>
    7b6d:	85 c9                	test   %ecx,%ecx
    7b6f:	74 08                	je     7b79 <f0+0x909>
    7b71:	48 83 05 2f 68 01 00 	addq   $0x1,0x1682f(%rip)        # 1e3a8 <iteration_retains>
    7b78:	01 
    7b79:	3c fd                	cmp    $0xfd,%al
    7b7b:	0f 87 e0 07 00 00    	ja     8361 <f0+0x10f1>
    7b81:	83 c0 01             	add    $0x1,%eax
    7b84:	88 07                	mov    %al,(%rdi)
    7b86:	4c 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%r14
    7b8d:	00 
    7b8e:	4c 89 ed             	mov    %r13,%rbp
    7b91:	4d 85 f6             	test   %r14,%r14
    7b94:	0f 84 96 06 00 00    	je     8230 <f0+0xfc0>
    7b9a:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
    7b9f:	4d 89 fd             	mov    %r15,%r13
    7ba2:	4d 89 f7             	mov    %r14,%r15
    7ba5:	eb 3f                	jmp    7be6 <f0+0x976>
    7ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bae:	00 00 
    7bb0:	40 80 fe 01          	cmp    $0x1,%sil
    7bb4:	75 27                	jne    7bdd <f0+0x96d>
    7bb6:	8b 72 18             	mov    0x18(%rdx),%esi
    7bb9:	0f b7 c0             	movzwl %ax,%eax
    7bbc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bbf:	48 0f af c6          	imul   %rsi,%rax
    7bc3:	48 c1 e8 20          	shr    $0x20,%rax
    7bc7:	48 39 d0             	cmp    %rdx,%rax
    7bca:	73 11                	jae    7bdd <f0+0x96d>
    7bcc:	49 01 c6             	add    %rax,%r14
    7bcf:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7bd3:	0f 84 07 06 00 00    	je     81e0 <f0+0xf70>
    7bd9:	41 c6 06 01          	movb   $0x1,(%r14)
    7bdd:	4d 85 ff             	test   %r15,%r15
    7be0:	0f 84 8a 00 00 00    	je     7c70 <f0+0xa00>
    7be6:	49 83 ef 01          	sub    $0x1,%r15
    7bea:	66 48 0f 6e e5       	movq   %rbp,%xmm4
    7bef:	48 89 de             	mov    %rbx,%rsi
    7bf2:	bf 01 00 00 00       	mov    $0x1,%edi
    7bf7:	f3 43 0f 7e 44 fd 00 	movq   0x0(%r13,%r15,8),%xmm0
    7bfe:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    7c02:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    7c09:	00 
    7c0a:	e8 31 d4 ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    7c0f:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7c16:	00 
    7c17:	48 89 c5             	mov    %rax,%rbp
    7c1a:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7c21:	00 
    7c22:	48 c1 e2 10          	shl    $0x10,%rdx
    7c26:	48 39 d0             	cmp    %rdx,%rax
    7c29:	73 b2                	jae    7bdd <f0+0x96d>
    7c2b:	48 89 c2             	mov    %rax,%rdx
    7c2e:	48 c1 ea 10          	shr    $0x10,%rdx
    7c32:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    7c36:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7c3d:	00 
    7c3e:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    7c42:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    7c46:	4d 85 f6             	test   %r14,%r14
    7c49:	74 92                	je     7bdd <f0+0x96d>
    7c4b:	0f b6 32             	movzbl (%rdx),%esi
    7c4e:	40 80 fe 02          	cmp    $0x2,%sil
    7c52:	0f 85 58 ff ff ff    	jne    7bb0 <f0+0x940>
    7c58:	66 85 c0             	test   %ax,%ax
    7c5b:	0f 84 6e ff ff ff    	je     7bcf <f0+0x95f>
    7c61:	4d 85 ff             	test   %r15,%r15
    7c64:	75 80                	jne    7be6 <f0+0x976>
    7c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c6d:	00 00 00 
    7c70:	4d 89 ef             	mov    %r13,%r15
    7c73:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
    7c78:	4c 89 ff             	mov    %r15,%rdi
    7c7b:	e8 50 c6 ff ff       	call   42d0 <fwp_mem_free>
    7c80:	4c 89 ef             	mov    %r13,%rdi
    7c83:	e8 28 dd ff ff       	call   59b0 <fwp_drop0>
    7c88:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    7c8d:	e8 1e dd ff ff       	call   59b0 <fwp_drop0>
    7c92:	48 8b 34 24          	mov    (%rsp),%rsi
    7c96:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    7c9b:	e8 40 da ff ff       	call   56e0 <fwp_map_items>
    7ca0:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    7ca6:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
    7cad:	00 
    7cae:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7cb5:	00 00 00 00 00 
    7cba:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7cc1:	00 
    7cc2:	0f 11 bc 24 b8 00 00 	movups %xmm7,0xb8(%rsp)
    7cc9:	00 
    7cca:	48 85 d2             	test   %rdx,%rdx
    7ccd:	0f 84 e2 00 00 00    	je     7db5 <f0+0xb45>
    7cd3:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    7cd8:	45 31 ed             	xor    %r13d,%r13d
    7cdb:	49 89 d6             	mov    %rdx,%r14
    7cde:	48 89 c3             	mov    %rax,%rbx
    7ce1:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    7ce6:	eb 66                	jmp    7d4e <f0+0xade>
    7ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7cef:	00 
    7cf0:	40 80 fe 01          	cmp    $0x1,%sil
    7cf4:	75 3f                	jne    7d35 <f0+0xac5>
    7cf6:	8b 72 18             	mov    0x18(%rdx),%esi
    7cf9:	0f b7 c0             	movzwl %ax,%eax
    7cfc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cff:	48 0f af c6          	imul   %rsi,%rax
    7d03:	48 c1 e8 20          	shr    $0x20,%rax
    7d07:	48 39 d0             	cmp    %rdx,%rax
    7d0a:	73 29                	jae    7d35 <f0+0xac5>
    7d0c:	48 01 c7             	add    %rax,%rdi
    7d0f:	0f b6 07             	movzbl (%rdi),%eax
    7d12:	84 c0                	test   %al,%al
    7d14:	74 1f                	je     7d35 <f0+0xac5>
    7d16:	8b 15 a4 66 01 00    	mov    0x166a4(%rip),%edx        # 1e3c0 <iteration_active>
    7d1c:	85 d2                	test   %edx,%edx
    7d1e:	74 08                	je     7d28 <f0+0xab8>
    7d20:	48 83 05 80 66 01 00 	addq   $0x1,0x16680(%rip)        # 1e3a8 <iteration_retains>
    7d27:	01 
    7d28:	3c fd                	cmp    $0xfd,%al
    7d2a:	0f 87 20 05 00 00    	ja     8250 <f0+0xfe0>
    7d30:	83 c0 01             	add    $0x1,%eax
    7d33:	88 07                	mov    %al,(%rdi)
    7d35:	49 8b 6f 10          	mov    0x10(%r15),%rbp
    7d39:	4c 89 ff             	mov    %r15,%rdi
    7d3c:	e8 4f da ff ff       	call   5790 <fwp_drop4>
    7d41:	4a 89 2c eb          	mov    %rbp,(%rbx,%r13,8)
    7d45:	49 83 c5 01          	add    $0x1,%r13
    7d49:	4d 39 ee             	cmp    %r13,%r14
    7d4c:	74 5a                	je     7da8 <f0+0xb38>
    7d4e:	4e 8b 3c eb          	mov    (%rbx,%r13,8),%r15
    7d52:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    7d59:	00 
    7d5a:	4c 89 f8             	mov    %r15,%rax
    7d5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d61:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7d68:	00 
    7d69:	48 39 d0             	cmp    %rdx,%rax
    7d6c:	73 c7                	jae    7d35 <f0+0xac5>
    7d6e:	48 89 c2             	mov    %rax,%rdx
    7d71:	48 c1 ea 10          	shr    $0x10,%rdx
    7d75:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    7d79:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    7d80:	00 
    7d81:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    7d85:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d89:	48 85 ff             	test   %rdi,%rdi
    7d8c:	74 a7                	je     7d35 <f0+0xac5>
    7d8e:	0f b6 32             	movzbl (%rdx),%esi
    7d91:	40 80 fe 02          	cmp    $0x2,%sil
    7d95:	0f 85 55 ff ff ff    	jne    7cf0 <f0+0xa80>
    7d9b:	66 85 c0             	test   %ax,%ax
    7d9e:	75 95                	jne    7d35 <f0+0xac5>
    7da0:	e9 6a ff ff ff       	jmp    7d0f <f0+0xa9f>
    7da5:	0f 1f 00             	nopl   (%rax)
    7da8:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
    7dad:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    7db2:	4c 89 f2             	mov    %r14,%rdx
    7db5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7dba:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    7dc1:	00 
    7dc2:	e8 d9 d5 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    7dc7:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    7dcc:	49 89 c5             	mov    %rax,%r13
    7dcf:	e8 ec dd ff ff       	call   5bc0 <fwp_drop6>
    7dd4:	48 89 de             	mov    %rbx,%rsi
    7dd7:	bf 01 00 00 00       	mov    $0x1,%edi
    7ddc:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    7de3:	00 
    7de4:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
    7deb:	00 00 00 00 00 
    7df0:	e8 4b d2 ff ff       	call   5040 <fwp_data.part.0.constprop.0>
    7df5:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    7dfc:	00 
    7dfd:	49 89 c5             	mov    %rax,%r13
    7e00:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    7e07:	00 
    7e08:	48 c1 e1 10          	shl    $0x10,%rcx
    7e0c:	48 39 c8             	cmp    %rcx,%rax
    7e0f:	73 5a                	jae    7e6b <f0+0xbfb>
    7e11:	48 89 c1             	mov    %rax,%rcx
    7e14:	48 c1 e9 10          	shr    $0x10,%rcx
    7e18:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e1c:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    7e23:	00 
    7e24:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e28:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    7e2c:	4d 85 f6             	test   %r14,%r14
    7e2f:	74 3a                	je     7e6b <f0+0xbfb>
    7e31:	0f b6 31             	movzbl (%rcx),%esi
    7e34:	40 80 fe 02          	cmp    $0x2,%sil
    7e38:	0f 84 52 04 00 00    	je     8290 <f0+0x1020>
    7e3e:	40 80 fe 01          	cmp    $0x1,%sil
    7e42:	75 27                	jne    7e6b <f0+0xbfb>
    7e44:	8b 71 18             	mov    0x18(%rcx),%esi
    7e47:	0f b7 c0             	movzwl %ax,%eax
    7e4a:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e4d:	48 0f af c6          	imul   %rsi,%rax
    7e51:	48 c1 e8 20          	shr    $0x20,%rax
    7e55:	48 39 c8             	cmp    %rcx,%rax
    7e58:	73 11                	jae    7e6b <f0+0xbfb>
    7e5a:	49 01 c6             	add    %rax,%r14
    7e5d:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7e61:	0f 84 87 04 00 00    	je     82ee <f0+0x107e>
    7e67:	41 c6 06 01          	movb   $0x1,(%r14)
    7e6b:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    7e70:	4c 89 ef             	mov    %r13,%rdi
    7e73:	e8 68 d8 ff ff       	call   56e0 <fwp_map_items>
    7e78:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    7e7e:	48 8b 34 24          	mov    (%rsp),%rsi
    7e82:	48 89 ef             	mov    %rbp,%rdi
    7e85:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7e8c:	00 
    7e8d:	49 89 c6             	mov    %rax,%r14
    7e90:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7e97:	00 00 00 00 00 
    7e9c:	0f 11 ac 24 b8 00 00 	movups %xmm5,0xb8(%rsp)
    7ea3:	00 
    7ea4:	e8 37 d8 ff ff       	call   56e0 <fwp_map_items>
    7ea9:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
    7eb0:	00 
    7eb1:	48 89 c7             	mov    %rax,%rdi
    7eb4:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    7eb9:	49 39 c7             	cmp    %rax,%r15
    7ebc:	4c 0f 47 f8          	cmova  %rax,%r15
    7ec0:	4d 85 ff             	test   %r15,%r15
    7ec3:	0f 84 17 04 00 00    	je     82e0 <f0+0x1070>
    7ec9:	31 c0                	xor    %eax,%eax
    7ecb:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ed2:	00 00 00 
    7ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7edc:	00 00 00 00 
    7ee0:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    7ee6:	f2 0f 58 04 c7       	addsd  (%rdi,%rax,8),%xmm0
    7eeb:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    7ef1:	48 83 c0 01          	add    $0x1,%rax
    7ef5:	49 39 c7             	cmp    %rax,%r15
    7ef8:	75 e6                	jne    7ee0 <f0+0xc70>
    7efa:	e8 d1 c3 ff ff       	call   42d0 <fwp_mem_free>
    7eff:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f04:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    7f0b:	00 
    7f0c:	e8 8f d4 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    7f11:	48 89 ef             	mov    %rbp,%rdi
    7f14:	49 89 c6             	mov    %rax,%r14
    7f17:	e8 94 da ff ff       	call   59b0 <fwp_drop0>
    7f1c:	4c 89 ef             	mov    %r13,%rdi
    7f1f:	e8 8c da ff ff       	call   59b0 <fwp_drop0>
    7f24:	48 8b 34 24          	mov    (%rsp),%rsi
    7f28:	4c 89 f7             	mov    %r14,%rdi
    7f2b:	e8 b0 d7 ff ff       	call   56e0 <fwp_map_items>
    7f30:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    7f36:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    7f3d:	00 
    7f3e:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7f45:	00 00 00 00 00 
    7f4a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7f51:	00 
    7f52:	0f 11 b4 24 b8 00 00 	movups %xmm6,0xb8(%rsp)
    7f59:	00 
    7f5a:	48 85 c9             	test   %rcx,%rcx
    7f5d:	74 3b                	je     7f9a <f0+0xd2a>
    7f5f:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
    7f63:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f71:	00 00 00 00 
    7f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f7c:	00 00 00 00 
    7f80:	f2 0f 10 05 68 16 00 	movsd  0x1668(%rip),%xmm0        # 95f0 <msg.3+0x20>
    7f87:	00 
    7f88:	f2 0f 59 00          	mulsd  (%rax),%xmm0
    7f8c:	48 83 c0 08          	add    $0x8,%rax
    7f90:	f2 0f 11 40 f8       	movsd  %xmm0,-0x8(%rax)
    7f95:	48 39 c2             	cmp    %rax,%rdx
    7f98:	75 e6                	jne    7f80 <f0+0xd10>
    7f9a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f9f:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
    7fa6:	00 
    7fa7:	e8 f4 d3 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    7fac:	4c 89 f7             	mov    %r14,%rdi
    7faf:	49 89 c5             	mov    %rax,%r13
    7fb2:	e8 f9 d9 ff ff       	call   59b0 <fwp_drop0>
    7fb7:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    7fbc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    7fc1:	e8 1a d7 ff ff       	call   56e0 <fwp_map_items>
    7fc6:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    7fcc:	48 8b 34 24          	mov    (%rsp),%rsi
    7fd0:	4c 89 ef             	mov    %r13,%rdi
    7fd3:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    7fda:	00 
    7fdb:	49 89 c6             	mov    %rax,%r14
    7fde:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    7fe5:	00 00 00 00 00 
    7fea:	0f 11 bc 24 b8 00 00 	movups %xmm7,0xb8(%rsp)
    7ff1:	00 
    7ff2:	e8 e9 d6 ff ff       	call   56e0 <fwp_map_items>
    7ff7:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
    7ffe:	00 
    7fff:	48 89 c7             	mov    %rax,%rdi
    8002:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
    8007:	49 39 c7             	cmp    %rax,%r15
    800a:	4c 0f 47 f8          	cmova  %rax,%r15
    800e:	4d 85 ff             	test   %r15,%r15
    8011:	0f 84 b9 02 00 00    	je     82d0 <f0+0x1060>
    8017:	31 c0                	xor    %eax,%eax
    8019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8020:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    8026:	f2 0f 5c 04 c7       	subsd  (%rdi,%rax,8),%xmm0
    802b:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    8031:	48 83 c0 01          	add    $0x1,%rax
    8035:	49 39 c7             	cmp    %rax,%r15
    8038:	75 e6                	jne    8020 <f0+0xdb0>
    803a:	e8 91 c2 ff ff       	call   42d0 <fwp_mem_free>
    803f:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    8046:	00 
    8047:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    804c:	4c 89 ff             	mov    %r15,%rdi
    804f:	e8 4c d3 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    8054:	4c 89 ef             	mov    %r13,%rdi
    8057:	49 89 c6             	mov    %rax,%r14
    805a:	e8 51 d9 ff ff       	call   59b0 <fwp_drop0>
    805f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8064:	e8 47 d9 ff ff       	call   59b0 <fwp_drop0>
    8069:	66 0f ef c0          	pxor   %xmm0,%xmm0
    806d:	4c 89 ff             	mov    %r15,%rdi
    8070:	4c 89 f6             	mov    %r14,%rsi
    8073:	b9 01 00 00 00       	mov    $0x1,%ecx
    8078:	48 8d 15 21 3b 00 00 	lea    0x3b21(%rip),%rdx        # bba0 <d0>
    807f:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    8086:	00 00 00 00 00 
    808b:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    8092:	00 
    8093:	e8 98 e1 ff ff       	call   6230 <fwp_write>
    8098:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    809f:	00 
    80a0:	4c 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%r15
    80a7:	00 
    80a8:	48 8d 05 bf 0f 00 00 	lea    0xfbf(%rip),%rax        # 906e <_IO_stdin_used+0x6e>
    80af:	48 85 c9             	test   %rcx,%rcx
    80b2:	48 0f 44 c8          	cmove  %rax,%rcx
    80b6:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    80ba:	0f 87 29 03 00 00    	ja     83e9 <f0+0x1179>
    80c0:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    80c4:	be 01 00 00 00       	mov    $0x1,%esi
    80c9:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    80ce:	e8 1d d4 ff ff       	call   54f0 <fwp_heap_alloc>
    80d3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
    80d8:	4c 89 fa             	mov    %r15,%rdx
    80db:	4c 89 38             	mov    %r15,(%rax)
    80de:	48 8d 68 08          	lea    0x8(%rax),%rbp
    80e2:	49 89 c5             	mov    %rax,%r13
    80e5:	48 89 ef             	mov    %rbp,%rdi
    80e8:	e8 83 a4 ff ff       	call   2570 <memcpy@plt>
    80ed:	43 c6 44 3d 08 00    	movb   $0x0,0x8(%r13,%r15,1)
    80f3:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    80fa:	00 
    80fb:	e8 a0 a2 ff ff       	call   23a0 <free@plt>
    8100:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    8107:	00 
    8108:	4c 89 e8             	mov    %r13,%rax
    810b:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    8112:	00 
    8113:	48 c1 e2 10          	shl    $0x10,%rdx
    8117:	48 39 d0             	cmp    %rdx,%rax
    811a:	73 58                	jae    8174 <f0+0xf04>
    811c:	48 89 c2             	mov    %rax,%rdx
    811f:	48 c1 ea 10          	shr    $0x10,%rdx
    8123:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8127:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    812e:	00 
    812f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8133:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8137:	48 85 d2             	test   %rdx,%rdx
    813a:	74 38                	je     8174 <f0+0xf04>
    813c:	0f b6 31             	movzbl (%rcx),%esi
    813f:	40 80 fe 02          	cmp    $0x2,%sil
    8143:	0f 84 77 01 00 00    	je     82c0 <f0+0x1050>
    8149:	40 80 fe 01          	cmp    $0x1,%sil
    814d:	75 25                	jne    8174 <f0+0xf04>
    814f:	8b 71 18             	mov    0x18(%rcx),%esi
    8152:	0f b7 c0             	movzwl %ax,%eax
    8155:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8158:	48 0f af c6          	imul   %rsi,%rax
    815c:	48 c1 e8 20          	shr    $0x20,%rax
    8160:	48 39 c8             	cmp    %rcx,%rax
    8163:	73 0f                	jae    8174 <f0+0xf04>
    8165:	48 01 c2             	add    %rax,%rdx
    8168:	80 3a ff             	cmpb   $0xff,(%rdx)
    816b:	0f 84 cc 01 00 00    	je     833d <f0+0x10cd>
    8171:	c6 02 01             	movb   $0x1,(%rdx)
    8174:	4c 89 f7             	mov    %r14,%rdi
    8177:	e8 34 d8 ff ff       	call   59b0 <fwp_drop0>
    817c:	49 8b 55 00          	mov    0x0(%r13),%rdx
    8180:	be 01 00 00 00       	mov    $0x1,%esi
    8185:	48 89 ef             	mov    %rbp,%rdi
    8188:	48 8b 0d c9 61 01 00 	mov    0x161c9(%rip),%rcx        # 1e358 <fwp_prog_out>
    818f:	e8 ac a4 ff ff       	call   2640 <fwrite@plt>
    8194:	48 8b 35 bd 61 01 00 	mov    0x161bd(%rip),%rsi        # 1e358 <fwp_prog_out>
    819b:	bf 0a 00 00 00       	mov    $0xa,%edi
    81a0:	e8 1b a3 ff ff       	call   24c0 <fputc@plt>
    81a5:	4c 89 ef             	mov    %r13,%rdi
    81a8:	e8 e3 d5 ff ff       	call   5790 <fwp_drop4>
    81ad:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    81b2:	48 8b 40 10          	mov    0x10(%rax),%rax
    81b6:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    81bb:	48 85 c0             	test   %rax,%rax
    81be:	0f 84 37 01 00 00    	je     82fb <f0+0x108b>
    81c4:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    81cb:	00 
    81cc:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    81d3:	00 
    81d4:	e9 67 f4 ff ff       	jmp    7640 <f0+0x3d0>
    81d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    81e0:	4c 89 f7             	mov    %r14,%rdi
    81e3:	e8 a8 be ff ff       	call   4090 <fwp_rc_forget_slot>
    81e8:	e9 ec f9 ff ff       	jmp    7bd9 <f0+0x969>
    81ed:	0f 1f 00             	nopl   (%rax)
    81f0:	48 89 cf             	mov    %rcx,%rdi
    81f3:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
    81f8:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    81fd:	e8 8e be ff ff       	call   4090 <fwp_rc_forget_slot>
    8202:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    8207:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    820c:	e9 f8 f5 ff ff       	jmp    7809 <f0+0x599>
    8211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8218:	4d 85 ed             	test   %r13,%r13
    821b:	0f 84 ec f6 ff ff    	je     790d <f0+0x69d>
    8221:	e9 d5 f6 ff ff       	jmp    78fb <f0+0x68b>
    8226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    822d:	00 00 00 
    8230:	4d 85 ff             	test   %r15,%r15
    8233:	0f 84 47 fa ff ff    	je     7c80 <f0+0xa10>
    8239:	e9 3a fa ff ff       	jmp    7c78 <f0+0xa08>
    823e:	66 90                	xchg   %ax,%ax
    8240:	e8 2b bd ff ff       	call   3f70 <fwp_rc_wide_dup>
    8245:	e9 0b f8 ff ff       	jmp    7a55 <f0+0x7e5>
    824a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8250:	e8 1b bd ff ff       	call   3f70 <fwp_rc_wide_dup>
    8255:	e9 db fa ff ff       	jmp    7d35 <f0+0xac5>
    825a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8260:	66 85 c0             	test   %ax,%ax
    8263:	0f 85 52 f7 ff ff    	jne    79bb <f0+0x74b>
    8269:	41 80 3e ff          	cmpb   $0xff,(%r14)
    826d:	0f 85 44 f7 ff ff    	jne    79b7 <f0+0x747>
    8273:	4c 89 f7             	mov    %r14,%rdi
    8276:	e8 15 be ff ff       	call   4090 <fwp_rc_forget_slot>
    827b:	e9 37 f7 ff ff       	jmp    79b7 <f0+0x747>
    8280:	66 85 c0             	test   %ax,%ax
    8283:	0f 85 fd f8 ff ff    	jne    7b86 <f0+0x916>
    8289:	e9 d2 f8 ff ff       	jmp    7b60 <f0+0x8f0>
    828e:	66 90                	xchg   %ax,%ax
    8290:	66 85 c0             	test   %ax,%ax
    8293:	0f 85 d2 fb ff ff    	jne    7e6b <f0+0xbfb>
    8299:	e9 bf fb ff ff       	jmp    7e5d <f0+0xbed>
    829e:	66 90                	xchg   %ax,%ax
    82a0:	66 85 c0             	test   %ax,%ax
    82a3:	0f 85 bc f4 ff ff    	jne    7765 <f0+0x4f5>
    82a9:	e9 8f f4 ff ff       	jmp    773d <f0+0x4cd>
    82ae:	66 90                	xchg   %ax,%ax
    82b0:	66 85 c0             	test   %ax,%ax
    82b3:	0f 85 26 f4 ff ff    	jne    76df <f0+0x46f>
    82b9:	e9 e5 f3 ff ff       	jmp    76a3 <f0+0x433>
    82be:	66 90                	xchg   %ax,%ax
    82c0:	66 85 c0             	test   %ax,%ax
    82c3:	0f 85 ab fe ff ff    	jne    8174 <f0+0xf04>
    82c9:	e9 9a fe ff ff       	jmp    8168 <f0+0xef8>
    82ce:	66 90                	xchg   %ax,%ax
    82d0:	48 85 ff             	test   %rdi,%rdi
    82d3:	0f 84 66 fd ff ff    	je     803f <f0+0xdcf>
    82d9:	e9 5c fd ff ff       	jmp    803a <f0+0xdca>
    82de:	66 90                	xchg   %ax,%ax
    82e0:	48 85 ff             	test   %rdi,%rdi
    82e3:	0f 84 16 fc ff ff    	je     7eff <f0+0xc8f>
    82e9:	e9 0c fc ff ff       	jmp    7efa <f0+0xc8a>
    82ee:	4c 89 f7             	mov    %r14,%rdi
    82f1:	e8 9a bd ff ff       	call   4090 <fwp_rc_forget_slot>
    82f6:	e9 6c fb ff ff       	jmp    7e67 <f0+0xbf7>
    82fb:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
    8300:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8305:	e8 a6 d6 ff ff       	call   59b0 <fwp_drop0>
    830a:	48 89 ef             	mov    %rbp,%rdi
    830d:	e8 9e d6 ff ff       	call   59b0 <fwp_drop0>
    8312:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    8319:	00 
    831a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8321:	00 00 
    8323:	0f 85 bb 00 00 00    	jne    83e4 <f0+0x1174>
    8329:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    8330:	31 c0                	xor    %eax,%eax
    8332:	5b                   	pop    %rbx
    8333:	5d                   	pop    %rbp
    8334:	41 5c                	pop    %r12
    8336:	41 5d                	pop    %r13
    8338:	41 5e                	pop    %r14
    833a:	41 5f                	pop    %r15
    833c:	c3                   	ret
    833d:	48 89 d7             	mov    %rdx,%rdi
    8340:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    8345:	e8 46 bd ff ff       	call   4090 <fwp_rc_forget_slot>
    834a:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    834f:	e9 1d fe ff ff       	jmp    8171 <f0+0xf01>
    8354:	4c 89 f7             	mov    %r14,%rdi
    8357:	e8 34 bd ff ff       	call   4090 <fwp_rc_forget_slot>
    835c:	e9 1f f0 ff ff       	jmp    7380 <f0+0x110>
    8361:	e8 0a bc ff ff       	call   3f70 <fwp_rc_wide_dup>
    8366:	e9 1b f8 ff ff       	jmp    7b86 <f0+0x916>
    836b:	e8 00 bc ff ff       	call   3f70 <fwp_rc_wide_dup>
    8370:	e9 f0 f3 ff ff       	jmp    7765 <f0+0x4f5>
    8375:	e8 f6 bb ff ff       	call   3f70 <fwp_rc_wide_dup>
    837a:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    8381:	00 
    8382:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    8389:	00 
    838a:	48 c1 e1 10          	shl    $0x10,%rcx
    838e:	e9 4c f3 ff ff       	jmp    76df <f0+0x46f>
    8393:	66 85 d2             	test   %dx,%dx
    8396:	0f 85 81 f2 ff ff    	jne    761d <f0+0x3ad>
    839c:	e9 5e f2 ff ff       	jmp    75ff <f0+0x38f>
    83a1:	66 85 c0             	test   %ax,%ax
    83a4:	0f 85 b7 f1 ff ff    	jne    7561 <f0+0x2f1>
    83aa:	e9 a2 f1 ff ff       	jmp    7551 <f0+0x2e1>
    83af:	66 85 c0             	test   %ax,%ax
    83b2:	0f 85 0a f1 ff ff    	jne    74c2 <f0+0x252>
    83b8:	e9 f5 f0 ff ff       	jmp    74b2 <f0+0x242>
    83bd:	4c 89 ef             	mov    %r13,%rdi
    83c0:	e8 cb bc ff ff       	call   4090 <fwp_rc_forget_slot>
    83c5:	e9 40 f2 ff ff       	jmp    760a <f0+0x39a>
    83ca:	4c 89 ef             	mov    %r13,%rdi
    83cd:	e8 be bc ff ff       	call   4090 <fwp_rc_forget_slot>
    83d2:	e9 e6 f0 ff ff       	jmp    74bd <f0+0x24d>
    83d7:	4c 89 ef             	mov    %r13,%rdi
    83da:	e8 b1 bc ff ff       	call   4090 <fwp_rc_forget_slot>
    83df:	e9 78 f1 ff ff       	jmp    755c <f0+0x2ec>
    83e4:	e8 57 a0 ff ff       	call   2440 <__stack_chk_fail@plt>
    83e9:	48 8d 3d ab 0d 00 00 	lea    0xdab(%rip),%rdi        # 919b <_IO_stdin_used+0x19b>
    83f0:	e8 7b ae ff ff       	call   3270 <fwp_trap>
    83f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83fc:	00 00 00 00 

0000000000008400 <fwp_main_thread>:
    8400:	f3 0f 1e fa          	endbr64
    8404:	41 54                	push   %r12
    8406:	55                   	push   %rbp
    8407:	53                   	push   %rbx
    8408:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    840f:	8b 0d 8f 56 01 00    	mov    0x1568f(%rip),%ecx        # 1daa4 <fwp_heap+0x13a4>
    8415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    841c:	00 00 
    841e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    8425:	00 
    8426:	31 c0                	xor    %eax,%eax
    8428:	85 c9                	test   %ecx,%ecx
    842a:	0f 84 18 07 00 00    	je     8b48 <fwp_main_thread+0x748>
    8430:	8b 15 72 56 01 00    	mov    0x15672(%rip),%edx        # 1daa8 <fwp_heap+0x13a8>
    8436:	85 d2                	test   %edx,%edx
    8438:	0f 85 f2 06 00 00    	jne    8b30 <fwp_main_thread+0x730>
    843e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    8443:	31 f6                	xor    %esi,%esi
    8445:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    844a:	48 c7 05 3b 3c 01 00 	movq   $0x40000000,0x13c3b(%rip)        # 1c090 <fwp_main_stack_size>
    8451:	00 00 00 40 
    8455:	48 89 05 3c 3c 01 00 	mov    %rax,0x13c3c(%rip)        # 1c098 <fwp_main_stack_top>
    845c:	48 8d 05 1d 3c 00 00 	lea    0x3c1d(%rip),%rax        # c080 <alt.4>
    8463:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8468:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    846f:	01 00 
    8471:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    8478:	00 
    8479:	e8 02 a2 ff ff       	call   2680 <sigaltstack@plt>
    847e:	85 c0                	test   %eax,%eax
    8480:	0f 85 03 07 00 00    	jne    8b89 <fwp_main_thread+0x789>
    8486:	31 c0                	xor    %eax,%eax
    8488:	b9 12 00 00 00       	mov    $0x12,%ecx
    848d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    8492:	f3 48 ab             	rep stos %rax,(%rdi)
    8495:	48 8d 05 d4 a7 ff ff 	lea    -0x582c(%rip),%rax        # 2c70 <fwp_segv>
    849c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    84a1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    84a8:	04 00 00 08 
    84ac:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    84b1:	e8 9a a0 ff ff       	call   2550 <sigemptyset@plt>
    84b6:	85 c0                	test   %eax,%eax
    84b8:	0f 85 cb 06 00 00    	jne    8b89 <fwp_main_thread+0x789>
    84be:	31 d2                	xor    %edx,%edx
    84c0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    84c5:	bf 0b 00 00 00       	mov    $0xb,%edi
    84ca:	e8 11 9f ff ff       	call   23e0 <sigaction@plt>
    84cf:	85 c0                	test   %eax,%eax
    84d1:	0f 85 b2 06 00 00    	jne    8b89 <fwp_main_thread+0x789>
    84d7:	31 d2                	xor    %edx,%edx
    84d9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    84de:	bf 07 00 00 00       	mov    $0x7,%edi
    84e3:	e8 f8 9e ff ff       	call   23e0 <sigaction@plt>
    84e8:	85 c0                	test   %eax,%eax
    84ea:	0f 85 99 06 00 00    	jne    8b89 <fwp_main_thread+0x789>
    84f0:	48 8b 05 29 56 01 00 	mov    0x15629(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    84f7:	48 85 c0             	test   %rax,%rax
    84fa:	0f 88 10 06 00 00    	js     8b10 <fwp_main_thread+0x710>
    8500:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8504:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    8509:	48 8d 3d 40 ac ff ff 	lea    -0x53c0(%rip),%rdi        # 3150 <ad_raw_report>
    8510:	f2 0f 11 05 88 5e 01 	movsd  %xmm0,0x15e88(%rip)        # 1e3a0 <iteration_start_charge>
    8517:	00 
    8518:	c7 05 9e 5e 01 00 01 	movl   $0x1,0x15e9e(%rip)        # 1e3c0 <iteration_active>
    851f:	00 00 00 
    8522:	e8 a9 08 00 00       	call   8dd0 <atexit>
    8527:	85 c0                	test   %eax,%eax
    8529:	0f 85 66 06 00 00    	jne    8b95 <fwp_main_thread+0x795>
    852f:	8b 05 33 3b 00 00    	mov    0x3b33(%rip),%eax        # c068 <st.2>
    8535:	85 c0                	test   %eax,%eax
    8537:	0f 84 1b 06 00 00    	je     8b58 <fwp_main_thread+0x758>
    853d:	48 8b 2d 9c 41 01 00 	mov    0x1419c(%rip),%rbp        # 1c6e0 <fwp_cur>
    8544:	48 85 ed             	test   %rbp,%rbp
    8547:	0f 84 5f 01 00 00    	je     86ac <fwp_main_thread+0x2ac>
    854d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    8552:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    8556:	48 89 eb             	mov    %rbp,%rbx
    8559:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    855e:	0f 84 41 01 00 00    	je     86a5 <fwp_main_thread+0x2a5>
    8564:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    8569:	0f 84 21 02 00 00    	je     8790 <fwp_main_thread+0x390>
    856f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    8573:	0f 84 07 02 00 00    	je     8780 <fwp_main_thread+0x380>
    8579:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    857d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    8581:	0f 85 89 02 00 00    	jne    8810 <fwp_main_thread+0x410>
    8587:	48 8b 43 60          	mov    0x60(%rbx),%rax
    858b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    8592:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    8596:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    859d:	00 00 00 00 
    85a1:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    85a8:	48 85 d2             	test   %rdx,%rdx
    85ab:	74 07                	je     85b4 <fwp_main_thread+0x1b4>
    85ad:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    85b4:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    85b8:	48 85 c0             	test   %rax,%rax
    85bb:	74 34                	je     85f1 <fwp_main_thread+0x1f1>
    85bd:	48 89 43 68          	mov    %rax,0x68(%rbx)
    85c1:	48 8b 05 f0 40 01 00 	mov    0x140f0(%rip),%rax        # 1c6b8 <fwp_timers>
    85c8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    85cc:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    85d3:	00 00 00 00 
    85d7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    85de:	48 85 c0             	test   %rax,%rax
    85e1:	74 07                	je     85ea <fwp_main_thread+0x1ea>
    85e3:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    85ea:	48 89 1d c7 40 01 00 	mov    %rbx,0x140c7(%rip)        # 1c6b8 <fwp_timers>
    85f1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    85f5:	e8 56 c6 ff ff       	call   4c50 <fwp_block>
    85fa:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    8601:	48 85 c9             	test   %rcx,%rcx
    8604:	74 47                	je     864d <fwp_main_thread+0x24d>
    8606:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    860d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    8614:	48 85 d2             	test   %rdx,%rdx
    8617:	0f 84 33 02 00 00    	je     8850 <fwp_main_thread+0x450>
    861d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    8624:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    862b:	48 85 c0             	test   %rax,%rax
    862e:	74 07                	je     8637 <fwp_main_thread+0x237>
    8630:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    8637:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    863e:	00 00 00 00 
    8642:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8646:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    864d:	48 8b 0d 8c 40 01 00 	mov    0x1408c(%rip),%rcx        # 1c6e0 <fwp_cur>
    8654:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    8658:	0f 84 a2 01 00 00    	je     8800 <fwp_main_thread+0x400>
    865e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    8665:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    866c:	48 85 d2             	test   %rdx,%rdx
    866f:	0f 84 db 03 00 00    	je     8a50 <fwp_main_thread+0x650>
    8675:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    867c:	48 85 c0             	test   %rax,%rax
    867f:	74 07                	je     8688 <fwp_main_thread+0x288>
    8681:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    8688:	66 0f ef db          	pxor   %xmm3,%xmm3
    868c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    8690:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    8697:	48 89 cb             	mov    %rcx,%rbx
    869a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    869f:	0f 85 bf fe ff ff    	jne    8564 <fwp_main_thread+0x164>
    86a5:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    86a9:	48 89 dd             	mov    %rbx,%rbp
    86ac:	48 83 3d bc 5c 01 00 	cmpq   $0x0,0x15cbc(%rip)        # 1e370 <fwp_state_len>
    86b3:	00 
    86b4:	0f 84 a6 03 00 00    	je     8a60 <fwp_main_thread+0x660>
    86ba:	48 8b 15 17 40 01 00 	mov    0x14017(%rip),%rdx        # 1c6d8 <fwp_root>
    86c1:	c7 05 b5 39 01 00 00 	movl   $0x0,0x139b5(%rip)        # 1c080 <fwp_exit_code>
    86c8:	00 00 00 
    86cb:	48 39 d5             	cmp    %rdx,%rbp
    86ce:	0f 85 da 04 00 00    	jne    8bae <fwp_main_thread+0x7ae>
    86d4:	48 85 d2             	test   %rdx,%rdx
    86d7:	0f 84 83 01 00 00    	je     8860 <fwp_main_thread+0x460>
    86dd:	48 8b 0d c4 3f 01 00 	mov    0x13fc4(%rip),%rcx        # 1c6a8 <fwp_tasks_active>
    86e4:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    86e8:	48 85 c9             	test   %rcx,%rcx
    86eb:	0f 84 6f 01 00 00    	je     8860 <fwp_main_thread+0x460>
    86f1:	0f 1f 40 00          	nopl   0x0(%rax)
    86f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86fc:	00 00 00 00 
    8700:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    8704:	75 08                	jne    870e <fwp_main_thread+0x30e>
    8706:	48 89 cf             	mov    %rcx,%rdi
    8709:	e8 52 a9 ff ff       	call   3060 <fwp_cancel_tree.part.0>
    870e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    8715:	48 85 c9             	test   %rcx,%rcx
    8718:	75 e6                	jne    8700 <fwp_main_thread+0x300>
    871a:	eb 31                	jmp    874d <fwp_main_thread+0x34d>
    871c:	0f 1f 40 00          	nopl   0x0(%rax)
    8720:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    8727:	48 89 15 92 3f 01 00 	mov    %rdx,0x13f92(%rip)        # 1c6c0 <fwp_ready_tail>
    872e:	e8 1d c5 ff ff       	call   4c50 <fwp_block>
    8733:	e8 18 c3 ff ff       	call   4a50 <fwp_free_zombie>
    8738:	48 83 3d 68 3f 01 00 	cmpq   $0x0,0x13f68(%rip)        # 1c6a8 <fwp_tasks_active>
    873f:	00 
    8740:	0f 84 1a 01 00 00    	je     8860 <fwp_main_thread+0x460>
    8746:	48 8b 15 8b 3f 01 00 	mov    0x13f8b(%rip),%rdx        # 1c6d8 <fwp_root>
    874d:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    8751:	75 db                	jne    872e <fwp_main_thread+0x32e>
    8753:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    8757:	75 d5                	jne    872e <fwp_main_thread+0x32e>
    8759:	48 8b 05 60 3f 01 00 	mov    0x13f60(%rip),%rax        # 1c6c0 <fwp_ready_tail>
    8760:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    8764:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    876b:	00 00 00 00 
    876f:	48 85 c0             	test   %rax,%rax
    8772:	75 ac                	jne    8720 <fwp_main_thread+0x320>
    8774:	48 89 15 4d 3f 01 00 	mov    %rdx,0x13f4d(%rip)        # 1c6c8 <fwp_ready_head>
    877b:	eb aa                	jmp    8727 <fwp_main_thread+0x327>
    877d:	0f 1f 00             	nopl   (%rax)
    8780:	e8 1b ab ff ff       	call   32a0 <fwp_now_ns>
    8785:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    8789:	0f 8d 41 03 00 00    	jge    8ad0 <fwp_main_thread+0x6d0>
    878f:	90                   	nop
    8790:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    8794:	0f 85 df fd ff ff    	jne    8579 <fwp_main_thread+0x179>
    879a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    879e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    87a2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    87a6:	0f 85 df fd ff ff    	jne    858b <fwp_main_thread+0x18b>
    87ac:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    87b0:	48 85 c9             	test   %rcx,%rcx
    87b3:	0f 84 d2 fd ff ff    	je     858b <fwp_main_thread+0x18b>
    87b9:	48 85 c0             	test   %rax,%rax
    87bc:	0f 84 df 03 00 00    	je     8ba1 <fwp_main_thread+0x7a1>
    87c2:	48 39 c8             	cmp    %rcx,%rax
    87c5:	48 0f 4f c1          	cmovg  %rcx,%rax
    87c9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    87d0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    87d4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    87db:	00 00 00 00 
    87df:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    87e6:	48 85 d2             	test   %rdx,%rdx
    87e9:	74 07                	je     87f2 <fwp_main_thread+0x3f2>
    87eb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    87f2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    87f6:	e9 c2 fd ff ff       	jmp    85bd <fwp_main_thread+0x1bd>
    87fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8800:	48 89 cb             	mov    %rcx,%rbx
    8803:	e9 51 fd ff ff       	jmp    8559 <fwp_main_thread+0x159>
    8808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    880f:	00 
    8810:	48 8b 45 40          	mov    0x40(%rbp),%rax
    8814:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    881b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    8822:	00 00 00 00 
    8826:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    882d:	48 85 c0             	test   %rax,%rax
    8830:	0f 84 4a 03 00 00    	je     8b80 <fwp_main_thread+0x780>
    8836:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    883d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    8841:	e9 ab fd ff ff       	jmp    85f1 <fwp_main_thread+0x1f1>
    8846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    884d:	00 00 00 
    8850:	48 89 01             	mov    %rax,(%rcx)
    8853:	e9 d3 fd ff ff       	jmp    862b <fwp_main_thread+0x22b>
    8858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    885f:	00 
    8860:	e8 eb c1 ff ff       	call   4a50 <fwp_free_zombie>
    8865:	48 83 3d 5b 3e 01 00 	cmpq   $0x0,0x13e5b(%rip)        # 1c6c8 <fwp_ready_head>
    886c:	00 
    886d:	0f 85 98 9e ff ff    	jne    270b <fwp_main_thread.cold>
    8873:	48 83 3d 3d 3e 01 00 	cmpq   $0x0,0x13e3d(%rip)        # 1c6b8 <fwp_timers>
    887a:	00 
    887b:	0f 85 8a 9e ff ff    	jne    270b <fwp_main_thread.cold>
    8881:	8b 1d 1d 38 01 00    	mov    0x1381d(%rip),%ebx        # 1c0a4 <fwp_stack_pool_n>
    8887:	85 db                	test   %ebx,%ebx
    8889:	74 34                	je     88bf <fwp_main_thread+0x4bf>
    888b:	83 eb 01             	sub    $0x1,%ebx
    888e:	48 8d 05 2b 38 01 00 	lea    0x1382b(%rip),%rax        # 1c0c0 <fwp_stack_pool>
    8895:	48 63 d3             	movslq %ebx,%rdx
    8898:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    889c:	eb 05                	jmp    88a3 <fwp_main_thread+0x4a3>
    889e:	66 90                	xchg   %ax,%ax
    88a0:	83 eb 01             	sub    $0x1,%ebx
    88a3:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88a7:	be 00 00 00 10       	mov    $0x10000000,%esi
    88ac:	89 1d f2 37 01 00    	mov    %ebx,0x137f2(%rip)        # 1c0a4 <fwp_stack_pool_n>
    88b2:	48 83 ed 08          	sub    $0x8,%rbp
    88b6:	e8 f5 9c ff ff       	call   25b0 <munmap@plt>
    88bb:	85 db                	test   %ebx,%ebx
    88bd:	75 e1                	jne    88a0 <fwp_main_thread+0x4a0>
    88bf:	8b 3d 4b 37 00 00    	mov    0x374b(%rip),%edi        # c010 <fwp_epfd>
    88c5:	85 ff                	test   %edi,%edi
    88c7:	78 05                	js     88ce <fwp_main_thread+0x4ce>
    88c9:	e8 e2 9b ff ff       	call   24b0 <close@plt>
    88ce:	4c 8b 25 eb 39 01 00 	mov    0x139eb(%rip),%r12        # 1c2c0 <fwp_nfdws>
    88d5:	48 8b 2d ec 39 01 00 	mov    0x139ec(%rip),%rbp        # 1c2c8 <fwp_fdws>
    88dc:	31 db                	xor    %ebx,%ebx
    88de:	c7 05 28 37 00 00 ff 	movl   $0xffffffff,0x3728(%rip)        # c010 <fwp_epfd>
    88e5:	ff ff ff 
    88e8:	4d 85 e4             	test   %r12,%r12
    88eb:	74 30                	je     891d <fwp_main_thread+0x51d>
    88ed:	0f 1f 00             	nopl   (%rax)
    88f0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    88f5:	48 85 ff             	test   %rdi,%rdi
    88f8:	74 1a                	je     8914 <fwp_main_thread+0x514>
    88fa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    88fe:	0f 85 07 9e ff ff    	jne    270b <fwp_main_thread.cold>
    8904:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    8909:	0f 85 fc 9d ff ff    	jne    270b <fwp_main_thread.cold>
    890f:	e8 bc b9 ff ff       	call   42d0 <fwp_mem_free>
    8914:	48 83 c3 01          	add    $0x1,%rbx
    8918:	49 39 dc             	cmp    %rbx,%r12
    891b:	75 d3                	jne    88f0 <fwp_main_thread+0x4f0>
    891d:	48 89 ef             	mov    %rbp,%rdi
    8920:	e8 ab b9 ff ff       	call   42d0 <fwp_mem_free>
    8925:	48 8b 15 ac 3d 01 00 	mov    0x13dac(%rip),%rdx        # 1c6d8 <fwp_root>
    892c:	48 c7 05 91 39 01 00 	movq   $0x0,0x13991(%rip)        # 1c2c8 <fwp_fdws>
    8933:	00 00 00 00 
    8937:	48 c7 05 7e 39 01 00 	movq   $0x0,0x1397e(%rip)        # 1c2c0 <fwp_nfdws>
    893e:	00 00 00 00 
    8942:	48 85 d2             	test   %rdx,%rdx
    8945:	74 4e                	je     8995 <fwp_main_thread+0x595>
    8947:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    894c:	0f 85 b9 9d ff ff    	jne    270b <fwp_main_thread.cold>
    8952:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    8959:	00 
    895a:	0f 85 ab 9d ff ff    	jne    270b <fwp_main_thread.cold>
    8960:	48 83 3d 08 5a 01 00 	cmpq   $0x0,0x15a08(%rip)        # 1e370 <fwp_state_len>
    8967:	00 
    8968:	0f 85 9d 9d ff ff    	jne    270b <fwp_main_thread.cold>
    896e:	48 83 3d ea 59 01 00 	cmpq   $0x0,0x159ea(%rip)        # 1e360 <fwp_state_owners>
    8975:	00 
    8976:	0f 85 8f 9d ff ff    	jne    270b <fwp_main_thread.cold>
    897c:	b9 79 00 00 00       	mov    $0x79,%ecx
    8981:	31 c0                	xor    %eax,%eax
    8983:	48 8d 3d 56 39 01 00 	lea    0x13956(%rip),%rdi        # 1c2e0 <fwp_root_context>
    898a:	f3 48 ab             	rep stos %rax,(%rdi)
    898d:	48 89 d7             	mov    %rdx,%rdi
    8990:	e8 3b b9 ff ff       	call   42d0 <fwp_mem_free>
    8995:	48 8b 05 84 51 01 00 	mov    0x15184(%rip),%rax        # 1db20 <fwp_heap+0x1420>
    899c:	48 c7 05 39 3d 01 00 	movq   $0x0,0x13d39(%rip)        # 1c6e0 <fwp_cur>
    89a3:	00 00 00 00 
    89a7:	48 c7 05 26 3d 01 00 	movq   $0x0,0x13d26(%rip)        # 1c6d8 <fwp_root>
    89ae:	00 00 00 00 
    89b2:	48 c7 05 cb 36 01 00 	movq   $0x0,0x136cb(%rip)        # 1c088 <ad_raw_before_shutdown>
    89b9:	00 00 00 00 
    89bd:	c7 05 f9 59 01 00 00 	movl   $0x0,0x159f9(%rip)        # 1e3c0 <iteration_active>
    89c4:	00 00 00 
    89c7:	48 85 c0             	test   %rax,%rax
    89ca:	0f 88 20 01 00 00    	js     8af0 <fwp_main_thread+0x6f0>
    89d0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    89d4:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    89d9:	f2 0f 5c 0d bf 59 01 	subsd  0x159bf(%rip),%xmm1        # 1e3a0 <iteration_start_charge>
    89e0:	00 
    89e1:	48 8b 3d 58 36 00 00 	mov    0x3658(%rip),%rdi        # c040 <stderr@GLIBC_2.2.5>
    89e8:	48 8d 15 59 0a 00 00 	lea    0xa59(%rip),%rdx        # 9448 <_IO_stdin_used+0x448>
    89ef:	be 02 00 00 00       	mov    $0x2,%esi
    89f4:	f2 0f 10 05 9c 59 01 	movsd  0x1599c(%rip),%xmm0        # 1e398 <iteration_peak>
    89fb:	00 
    89fc:	4c 8b 0d a5 59 01 00 	mov    0x159a5(%rip),%r9        # 1e3a8 <iteration_retains>
    8a03:	b8 02 00 00 00       	mov    $0x2,%eax
    8a08:	4c 8b 05 a1 59 01 00 	mov    0x159a1(%rip),%r8        # 1e3b0 <iteration_bytes>
    8a0f:	48 8b 0d a2 59 01 00 	mov    0x159a2(%rip),%rcx        # 1e3b8 <iteration_requests>
    8a16:	e8 35 9c ff ff       	call   2650 <__fprintf_chk@plt>
    8a1b:	48 8b 3d fe 35 00 00 	mov    0x35fe(%rip),%rdi        # c020 <stdout@GLIBC_2.2.5>
    8a22:	e8 69 9b ff ff       	call   2590 <fflush@plt>
    8a27:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    8a2e:	00 
    8a2f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a36:	00 00 
    8a38:	0f 85 6b 01 00 00    	jne    8ba9 <fwp_main_thread+0x7a9>
    8a3e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    8a45:	31 c0                	xor    %eax,%eax
    8a47:	5b                   	pop    %rbx
    8a48:	5d                   	pop    %rbp
    8a49:	41 5c                	pop    %r12
    8a4b:	c3                   	ret
    8a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a50:	48 89 05 61 3c 01 00 	mov    %rax,0x13c61(%rip)        # 1c6b8 <fwp_timers>
    8a57:	e9 20 fc ff ff       	jmp    867c <fwp_main_thread+0x27c>
    8a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a60:	48 83 3d f8 58 01 00 	cmpq   $0x0,0x158f8(%rip)        # 1e360 <fwp_state_owners>
    8a67:	00 
    8a68:	0f 85 4c fc ff ff    	jne    86ba <fwp_main_thread+0x2ba>
    8a6e:	48 8b 3d 03 59 01 00 	mov    0x15903(%rip),%rdi        # 1e378 <fwp_state>
    8a75:	e8 56 b8 ff ff       	call   42d0 <fwp_mem_free>
    8a7a:	48 c7 05 f3 58 01 00 	movq   $0x0,0x158f3(%rip)        # 1e378 <fwp_state>
    8a81:	00 00 00 00 
    8a85:	48 c7 05 d8 58 01 00 	movq   $0x0,0x158d8(%rip)        # 1e368 <fwp_state_cap>
    8a8c:	00 00 00 00 
    8a90:	48 85 ed             	test   %rbp,%rbp
    8a93:	0f 84 21 fc ff ff    	je     86ba <fwp_main_thread+0x2ba>
    8a99:	48 8b 15 38 3c 01 00 	mov    0x13c38(%rip),%rdx        # 1c6d8 <fwp_root>
    8aa0:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    8aa7:	00 00 00 00 
    8aab:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    8ab2:	00 00 00 00 
    8ab6:	c7 05 c0 35 01 00 00 	movl   $0x0,0x135c0(%rip)        # 1c080 <fwp_exit_code>
    8abd:	00 00 00 
    8ac0:	48 39 d5             	cmp    %rdx,%rbp
    8ac3:	0f 84 14 fc ff ff    	je     86dd <fwp_main_thread+0x2dd>
    8ac9:	e9 3d 9c ff ff       	jmp    270b <fwp_main_thread.cold>
    8ace:	66 90                	xchg   %ax,%ax
    8ad0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    8ad4:	0f 85 b6 fc ff ff    	jne    8790 <fwp_main_thread+0x390>
    8ada:	48 89 ef             	mov    %rbp,%rdi
    8add:	e8 7e a5 ff ff       	call   3060 <fwp_cancel_tree.part.0>
    8ae2:	e9 a9 fc ff ff       	jmp    8790 <fwp_main_thread+0x390>
    8ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8aee:	00 00 
    8af0:	48 89 c2             	mov    %rax,%rdx
    8af3:	83 e0 01             	and    $0x1,%eax
    8af6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8afa:	48 d1 ea             	shr    $1,%rdx
    8afd:	48 09 c2             	or     %rax,%rdx
    8b00:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    8b05:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    8b09:	e9 cb fe ff ff       	jmp    89d9 <fwp_main_thread+0x5d9>
    8b0e:	66 90                	xchg   %ax,%ax
    8b10:	48 89 c2             	mov    %rax,%rdx
    8b13:	83 e0 01             	and    $0x1,%eax
    8b16:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8b1a:	48 d1 ea             	shr    $1,%rdx
    8b1d:	48 09 c2             	or     %rax,%rdx
    8b20:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    8b25:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    8b29:	e9 db f9 ff ff       	jmp    8509 <fwp_main_thread+0x109>
    8b2e:	66 90                	xchg   %ax,%ax
    8b30:	48 8d 3d 69 ad ff ff 	lea    -0x5297(%rip),%rdi        # 38a0 <fwp_heap_report>
    8b37:	e8 94 02 00 00       	call   8dd0 <atexit>
    8b3c:	e9 fd f8 ff ff       	jmp    843e <fwp_main_thread+0x3e>
    8b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b48:	e8 63 ae ff ff       	call   39b0 <fwp_heap_init>
    8b4d:	e9 de f8 ff ff       	jmp    8430 <fwp_main_thread+0x30>
    8b52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b58:	e8 13 e7 ff ff       	call   7270 <f0>
    8b5d:	48 c7 05 f8 34 00 00 	movq   $0x0,0x34f8(%rip)        # c060 <v.1>
    8b64:	00 00 00 00 
    8b68:	c7 05 f6 34 00 00 01 	movl   $0x1,0x34f6(%rip)        # c068 <st.2>
    8b6f:	00 00 00 
    8b72:	e9 c6 f9 ff ff       	jmp    853d <fwp_main_thread+0x13d>
    8b77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b7e:	00 00 
    8b80:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    8b84:	e9 68 fa ff ff       	jmp    85f1 <fwp_main_thread+0x1f1>
    8b89:	48 8d 3d 90 08 00 00 	lea    0x890(%rip),%rdi        # 9420 <_IO_stdin_used+0x420>
    8b90:	e8 db a6 ff ff       	call   3270 <fwp_trap>
    8b95:	48 8d 3d 10 06 00 00 	lea    0x610(%rip),%rdi        # 91ac <_IO_stdin_used+0x1ac>
    8b9c:	e8 8f a3 ff ff       	call   2f30 <ad_raw_fail>
    8ba1:	48 89 c8             	mov    %rcx,%rax
    8ba4:	e9 20 fc ff ff       	jmp    87c9 <fwp_main_thread+0x3c9>
    8ba9:	e8 92 98 ff ff       	call   2440 <__stack_chk_fail@plt>
    8bae:	e9 58 9b ff ff       	jmp    270b <fwp_main_thread.cold>
    8bb3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bba:	00 00 00 
    8bbd:	0f 1f 00             	nopl   (%rax)

0000000000008bc0 <__divmodti4>:
    8bc0:	f3 0f 1e fa          	endbr64
    8bc4:	55                   	push   %rbp
    8bc5:	49 89 f1             	mov    %rsi,%r9
    8bc8:	49 89 d2             	mov    %rdx,%r10
    8bcb:	48 89 fe             	mov    %rdi,%rsi
    8bce:	49 89 cb             	mov    %rcx,%r11
    8bd1:	48 89 e5             	mov    %rsp,%rbp
    8bd4:	41 57                	push   %r15
    8bd6:	41 56                	push   %r14
    8bd8:	41 55                	push   %r13
    8bda:	41 54                	push   %r12
    8bdc:	53                   	push   %rbx
    8bdd:	4c 89 c3             	mov    %r8,%rbx
    8be0:	45 31 c0             	xor    %r8d,%r8d
    8be3:	4d 85 c9             	test   %r9,%r9
    8be6:	79 12                	jns    8bfa <__divmodti4+0x3a>
    8be8:	31 ff                	xor    %edi,%edi
    8bea:	48 f7 de             	neg    %rsi
    8bed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    8bf4:	4c 19 cf             	sbb    %r9,%rdi
    8bf7:	49 89 f9             	mov    %rdi,%r9
    8bfa:	4c 89 d8             	mov    %r11,%rax
    8bfd:	4d 85 db             	test   %r11,%r11
    8c00:	0f 88 1a 01 00 00    	js     8d20 <__divmodti4+0x160>
    8c06:	4c 89 d9             	mov    %r11,%rcx
    8c09:	49 89 f3             	mov    %rsi,%r11
    8c0c:	75 62                	jne    8c70 <__divmodti4+0xb0>
    8c0e:	4d 89 c4             	mov    %r8,%r12
    8c11:	4d 39 d1             	cmp    %r10,%r9
    8c14:	0f 83 46 01 00 00    	jae    8d60 <__divmodti4+0x1a0>
    8c1a:	4c 89 d8             	mov    %r11,%rax
    8c1d:	4c 89 ca             	mov    %r9,%rdx
    8c20:	49 f7 f2             	div    %r10
    8c23:	49 89 c3             	mov    %rax,%r11
    8c26:	31 c0                	xor    %eax,%eax
    8c28:	48 89 d6             	mov    %rdx,%rsi
    8c2b:	31 ff                	xor    %edi,%edi
    8c2d:	4c 89 d9             	mov    %r11,%rcx
    8c30:	48 89 c2             	mov    %rax,%rdx
    8c33:	48 89 c8             	mov    %rcx,%rax
    8c36:	4d 85 e4             	test   %r12,%r12
    8c39:	74 0a                	je     8c45 <__divmodti4+0x85>
    8c3b:	48 f7 d8             	neg    %rax
    8c3e:	48 83 d2 00          	adc    $0x0,%rdx
    8c42:	48 f7 da             	neg    %rdx
    8c45:	4d 85 c0             	test   %r8,%r8
    8c48:	74 0a                	je     8c54 <__divmodti4+0x94>
    8c4a:	48 f7 de             	neg    %rsi
    8c4d:	48 83 d7 00          	adc    $0x0,%rdi
    8c51:	48 f7 df             	neg    %rdi
    8c54:	48 89 33             	mov    %rsi,(%rbx)
    8c57:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    8c5b:	5b                   	pop    %rbx
    8c5c:	41 5c                	pop    %r12
    8c5e:	41 5d                	pop    %r13
    8c60:	41 5e                	pop    %r14
    8c62:	41 5f                	pop    %r15
    8c64:	5d                   	pop    %rbp
    8c65:	c3                   	ret
    8c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c6d:	00 00 00 
    8c70:	4d 89 c4             	mov    %r8,%r12
    8c73:	49 39 c1             	cmp    %rax,%r9
    8c76:	0f 82 ce 00 00 00    	jb     8d4a <__divmodti4+0x18a>
    8c7c:	31 ff                	xor    %edi,%edi
    8c7e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    8c83:	48 63 c7             	movslq %edi,%rax
    8c86:	be 40 00 00 00       	mov    $0x40,%esi
    8c8b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    8c90:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    8c95:	48 29 c6             	sub    %rax,%rsi
    8c98:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    8c9d:	48 09 c8             	or     %rcx,%rax
    8ca0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    8ca5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    8caa:	49 89 c6             	mov    %rax,%r14
    8cad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    8cb1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    8cb6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    8cbb:	49 09 c1             	or     %rax,%r9
    8cbe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    8cc2:	4c 89 c8             	mov    %r9,%rax
    8cc5:	49 f7 f6             	div    %r14
    8cc8:	48 89 d1             	mov    %rdx,%rcx
    8ccb:	49 89 c3             	mov    %rax,%r11
    8cce:	49 89 c1             	mov    %rax,%r9
    8cd1:	49 f7 e2             	mul    %r10
    8cd4:	49 89 c6             	mov    %rax,%r14
    8cd7:	49 89 d2             	mov    %rdx,%r10
    8cda:	48 39 d1             	cmp    %rdx,%rcx
    8cdd:	72 07                	jb     8ce6 <__divmodti4+0x126>
    8cdf:	75 17                	jne    8cf8 <__divmodti4+0x138>
    8ce1:	49 39 c7             	cmp    %rax,%r15
    8ce4:	73 12                	jae    8cf8 <__divmodti4+0x138>
    8ce6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    8cea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    8cee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    8cf2:	49 89 d2             	mov    %rdx,%r10
    8cf5:	49 89 c6             	mov    %rax,%r14
    8cf8:	4c 89 f8             	mov    %r15,%rax
    8cfb:	4c 29 f0             	sub    %r14,%rax
    8cfe:	4c 19 d1             	sbb    %r10,%rcx
    8d01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    8d06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    8d0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    8d10:	48 09 c6             	or     %rax,%rsi
    8d13:	48 89 cf             	mov    %rcx,%rdi
    8d16:	31 c0                	xor    %eax,%eax
    8d18:	4c 89 c9             	mov    %r9,%rcx
    8d1b:	e9 10 ff ff ff       	jmp    8c30 <__divmodti4+0x70>
    8d20:	4c 89 d0             	mov    %r10,%rax
    8d23:	4c 89 da             	mov    %r11,%rdx
    8d26:	4d 89 c4             	mov    %r8,%r12
    8d29:	49 89 f3             	mov    %rsi,%r11
    8d2c:	48 f7 d8             	neg    %rax
    8d2f:	49 f7 d4             	not    %r12
    8d32:	48 83 d2 00          	adc    $0x0,%rdx
    8d36:	49 89 c2             	mov    %rax,%r10
    8d39:	48 f7 da             	neg    %rdx
    8d3c:	48 89 d1             	mov    %rdx,%rcx
    8d3f:	0f 84 cc fe ff ff    	je     8c11 <__divmodti4+0x51>
    8d45:	49 39 d1             	cmp    %rdx,%r9
    8d48:	73 46                	jae    8d90 <__divmodti4+0x1d0>
    8d4a:	4c 89 cf             	mov    %r9,%rdi
    8d4d:	31 c0                	xor    %eax,%eax
    8d4f:	31 c9                	xor    %ecx,%ecx
    8d51:	e9 da fe ff ff       	jmp    8c30 <__divmodti4+0x70>
    8d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d5d:	00 00 00 
    8d60:	4d 85 d2             	test   %r10,%r10
    8d63:	75 0d                	jne    8d72 <__divmodti4+0x1b2>
    8d65:	b8 01 00 00 00       	mov    $0x1,%eax
    8d6a:	31 d2                	xor    %edx,%edx
    8d6c:	49 f7 f2             	div    %r10
    8d6f:	49 89 c2             	mov    %rax,%r10
    8d72:	4c 89 c8             	mov    %r9,%rax
    8d75:	31 d2                	xor    %edx,%edx
    8d77:	49 f7 f2             	div    %r10
    8d7a:	49 89 c1             	mov    %rax,%r9
    8d7d:	4c 89 d8             	mov    %r11,%rax
    8d80:	49 f7 f2             	div    %r10
    8d83:	49 89 c3             	mov    %rax,%r11
    8d86:	4c 89 c8             	mov    %r9,%rax
    8d89:	e9 9a fe ff ff       	jmp    8c28 <__divmodti4+0x68>
    8d8e:	66 90                	xchg   %ax,%ax
    8d90:	45 31 f6             	xor    %r14d,%r14d
    8d93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    8d98:	44 89 f7             	mov    %r14d,%edi
    8d9b:	45 85 f6             	test   %r14d,%r14d
    8d9e:	0f 85 df fe ff ff    	jne    8c83 <__divmodti4+0xc3>
    8da4:	4c 39 ca             	cmp    %r9,%rdx
    8da7:	72 17                	jb     8dc0 <__divmodti4+0x200>
    8da9:	31 c9                	xor    %ecx,%ecx
    8dab:	48 39 c6             	cmp    %rax,%rsi
    8dae:	73 10                	jae    8dc0 <__divmodti4+0x200>
    8db0:	4c 89 cf             	mov    %r9,%rdi
    8db3:	31 c0                	xor    %eax,%eax
    8db5:	e9 76 fe ff ff       	jmp    8c30 <__divmodti4+0x70>
    8dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8dc0:	4c 89 de             	mov    %r11,%rsi
    8dc3:	b9 01 00 00 00       	mov    $0x1,%ecx
    8dc8:	48 29 c6             	sub    %rax,%rsi
    8dcb:	49 19 d1             	sbb    %rdx,%r9
    8dce:	eb e0                	jmp    8db0 <__divmodti4+0x1f0>

0000000000008dd0 <atexit>:
    8dd0:	f3 0f 1e fa          	endbr64
    8dd4:	48 8b 15 2d 32 00 00 	mov    0x322d(%rip),%rdx        # c008 <__dso_handle>
    8ddb:	31 f6                	xor    %esi,%esi
    8ddd:	e9 3e 98 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008de4 <_fini>:
    8de4:	f3 0f 1e fa          	endbr64
    8de8:	48 83 ec 08          	sub    $0x8,%rsp
    8dec:	48 83 c4 08          	add    $0x8,%rsp
    8df0:	c3                   	ret
