
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1999/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d9 cf 00 00 	mov    0xcfd9(%rip),%rax        # ffe8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 02 ce 00 00    	push   0xce02(%rip)        # fe28 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 04 ce 00 00    	jmp    *0xce04(%rip)        # fe30 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 7e cc 00 00    	jmp    *0xcc7e(%rip)        # fff8 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 ae ca 00 00    	jmp    *0xcaae(%rip)        # fe38 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 a6 ca 00 00    	jmp    *0xcaa6(%rip)        # fe40 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 9e ca 00 00    	jmp    *0xca9e(%rip)        # fe48 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 96 ca 00 00    	jmp    *0xca96(%rip)        # fe50 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe58 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe60 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe68 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe70 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe78 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe80 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe88 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe90 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe98 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fea0 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fea8 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # feb0 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # feb8 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fec0 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fec8 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fed0 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fed8 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fee0 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fee8 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fef0 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fef8 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # ff00 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # ff08 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # ff10 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # ff18 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # ff20 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # ff28 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff30 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff38 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff40 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff48 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff50 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff58 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff60 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff68 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff70 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff78 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff80 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff88 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff90 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff98 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ffa0 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ffa8 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ffb0 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ffb8 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ffc0 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ffc8 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffd0 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d ba 89 00 00 	lea    0x89ba(%rip),%r9        # c091 <_IO_stdin_used+0x91>
    36d7:	4c 8d 05 b7 89 00 00 	lea    0x89b7(%rip),%r8        # c095 <_IO_stdin_used+0x95>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 5a 0a 00 00       	call   4160 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_main_thread.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>
    3710:	e8 ab ff ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>

0000000000003715 <main.cold>:
    3715:	e8 96 fc ff ff       	call   33b0 <abort@plt>
    371a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 01 ac 00 00 	lea    0xac01(%rip),%rax        # e340 <fwp_fn_table>
    373f:	48 89 05 52 ec 01 00 	mov    %rax,0x1ec52(%rip)        # 22398 <fwp_fns>
    3746:	48 8b 05 d3 c8 00 00 	mov    0xc8d3(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 4c ec 01 00 	mov    %rax,0x1ec4c(%rip)        # 223a0 <fwp_prog_out>
    3754:	e8 77 0b 00 00       	call   42d0 <fwp_now_ns>
    3759:	48 8d 3d 99 8a 00 00 	lea    0x8a99(%rip),%rdi        # c1f9 <_IO_stdin_used+0x1f9>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 c8 00 00 	mov    0xc858(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 9f 5d 00 00 	lea    0x5d9f(%rip),%rdx        # 95c0 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 db fe ff ff    	jne    3715 <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 bf fe ff ff    	jne    3715 <main.cold>
    3856:	48 8b 3d c3 c7 00 00 	mov    0xc7c3(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 c8 01 00    	mov    0x1c818(%rip),%eax        # 20080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d 49 89 00 00 	lea    0x8949(%rip),%rdi        # c202 <_IO_stdin_used+0x202>
    38b9:	e8 a2 08 00 00       	call   4160 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d d6 90 00 00 	lea    0x90d6(%rip),%rdi        # c9a0 <_IO_stdin_used+0x9a0>
    38ca:	e8 91 08 00 00       	call   4160 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 34 fe ff ff    	jne    3715 <main.cold>
    38e1:	48 8d 3d 90 90 00 00 	lea    0x9090(%rip),%rdi        # c978 <_IO_stdin_used+0x978>
    38e8:	e8 73 08 00 00       	call   4160 <fwp_trap>
    38ed:	48 8d 3d 54 90 00 00 	lea    0x9054(%rip),%rdi        # c948 <_IO_stdin_used+0x948>
    38f4:	e8 67 08 00 00       	call   4160 <fwp_trap>
    38f9:	48 8d 3d 20 90 00 00 	lea    0x9020(%rip),%rdi        # c920 <_IO_stdin_used+0x920>
    3900:	e8 5b 08 00 00       	call   4160 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 a3 c6 00 00    	call   *0xc6a3(%rip)        # ffd8 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d9 c6 00 00 	lea    0xc6d9(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3947:	48 8d 05 d2 c6 00 00 	lea    0xc6d2(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 86 c6 00 00 	mov    0xc686(%rip),%rax        # ffe0 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a9 c6 00 00 	lea    0xc6a9(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3977:	48 8d 35 a2 c6 00 00 	lea    0xc6a2(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 55 c6 00 00 	mov    0xc655(%rip),%rax        # fff0 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d c6 00 00 00 	cmpb   $0x0,0xc68d(%rip)        # 10048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 32 c6 00 00 	cmpq   $0x0,0xc632(%rip)        # fff8 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 c6 00 00 	mov    0xc636(%rip),%rdi        # 10008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 c6 00 00 01 	movb   $0x1,0xc665(%rip)        # 10048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_tape_unlink_scope>:
    3bc0:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3bc4:	48 85 d2             	test   %rdx,%rdx
    3bc7:	74 3e                	je     3c07 <fwp_tape_unlink_scope+0x47>
    3bc9:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3bcc:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3bd0:	85 c9                	test   %ecx,%ecx
    3bd2:	78 3c                	js     3c10 <fwp_tape_unlink_scope+0x50>
    3bd4:	48 63 d1             	movslq %ecx,%rdx
    3bd7:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3bdb:	48 03 15 fe c4 01 00 	add    0x1c4fe(%rip),%rdx        # 200e0 <fwp_tapes>
    3be2:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3be5:	85 c0                	test   %eax,%eax
    3be7:	78 0e                	js     3bf7 <fwp_tape_unlink_scope+0x37>
    3be9:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3bed:	48 03 05 ec c4 01 00 	add    0x1c4ec(%rip),%rax        # 200e0 <fwp_tapes>
    3bf4:	89 48 48             	mov    %ecx,0x48(%rax)
    3bf7:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3bfe:	00 
    3bff:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c06:	ff 
    3c07:	c3                   	ret
    3c08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c0f:	00 
    3c10:	89 02                	mov    %eax,(%rdx)
    3c12:	eb d1                	jmp    3be5 <fwp_tape_unlink_scope+0x25>
    3c14:	90                   	nop
    3c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c1c:	00 00 00 00 

0000000000003c20 <fwp_args173>:
    3c20:	f3 0f 1e fa          	endbr64
    3c24:	c3                   	ret
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_flush>:
    3c30:	48 8b 3d 69 e7 01 00 	mov    0x1e769(%rip),%rdi        # 223a0 <fwp_prog_out>
    3c37:	48 85 ff             	test   %rdi,%rdi
    3c3a:	74 1c                	je     3c58 <fwp_flush+0x28>
    3c3c:	48 83 ec 08          	sub    $0x8,%rsp
    3c40:	e8 4b f9 ff ff       	call   3590 <fflush@plt>
    3c45:	48 8b 3d d4 c3 00 00 	mov    0xc3d4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c4c:	48 83 c4 08          	add    $0x8,%rsp
    3c50:	e9 3b f9 ff ff       	jmp    3590 <fflush@plt>
    3c55:	0f 1f 00             	nopl   (%rax)
    3c58:	48 8b 3d c1 c3 00 00 	mov    0xc3c1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c5f:	e9 2c f9 ff ff       	jmp    3590 <fflush@plt>
    3c64:	90                   	nop
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_heap_oom>:
    3c70:	50                   	push   %rax
    3c71:	58                   	pop    %rax
    3c72:	ba 13 00 00 00       	mov    $0x13,%edx
    3c77:	be 01 00 00 00       	mov    $0x1,%esi
    3c7c:	48 8d 3d 85 83 00 00 	lea    0x8385(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3c83:	48 83 ec 08          	sub    $0x8,%rsp
    3c87:	48 8b 0d b2 c3 00 00 	mov    0xc3b2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3c8e:	e8 ad f9 ff ff       	call   3640 <fwrite@plt>
    3c93:	31 ff                	xor    %edi,%edi
    3c95:	e8 f6 f8 ff ff       	call   3590 <fflush@plt>
    3c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    3c9f:	e8 bc f9 ff ff       	call   3660 <_Exit@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_segv>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	48 83 ec 28          	sub    $0x28,%rsp
    3cb8:	48 8b 05 61 ca 01 00 	mov    0x1ca61(%rip),%rax        # 20720 <fwp_cur>
    3cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3cc3:	41 89 f8             	mov    %edi,%r8d
    3cc6:	48 85 c0             	test   %rax,%rax
    3cc9:	74 6d                	je     3d38 <fwp_segv+0x88>
    3ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3ccf:	48 85 d2             	test   %rdx,%rdx
    3cd2:	74 64                	je     3d38 <fwp_segv+0x88>
    3cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3ce7:	e8 14 f9 ff ff       	call   3600 <sysconf@plt>
    3cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3cfb:	48 01 d0             	add    %rdx,%rax
    3cfe:	48 39 c1             	cmp    %rax,%rcx
    3d01:	b8 00 00 00 00       	mov    $0x0,%eax
    3d06:	40 0f 92 c6          	setb   %sil
    3d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d15:	31 c0                	xor    %eax,%eax
    3d17:	48 39 d1             	cmp    %rdx,%rcx
    3d1a:	0f 93 c0             	setae  %al
    3d1d:	21 f0                	and    %esi,%eax
    3d1f:	85 c0                	test   %eax,%eax
    3d21:	75 4a                	jne    3d6d <fwp_segv+0xbd>
    3d23:	31 f6                	xor    %esi,%esi
    3d25:	44 89 c7             	mov    %r8d,%edi
    3d28:	48 83 c4 28          	add    $0x28,%rsp
    3d2c:	e9 ef f7 ff ff       	jmp    3520 <signal@plt>
    3d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d38:	48 8b 05 b1 c3 01 00 	mov    0x1c3b1(%rip),%rax        # 200f0 <fwp_main_stack_top>
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	74 df                	je     3d23 <fwp_segv+0x73>
    3d44:	48 2b 05 9d c3 01 00 	sub    0x1c39d(%rip),%rax        # 200e8 <fwp_main_stack_size>
    3d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d52:	48 39 d1             	cmp    %rdx,%rcx
    3d55:	0f 93 c2             	setae  %dl
    3d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d5e:	48 39 c1             	cmp    %rax,%rcx
    3d61:	0f 92 c0             	setb   %al
    3d64:	0f b6 c0             	movzbl %al,%eax
    3d67:	21 d0                	and    %edx,%eax
    3d69:	85 c0                	test   %eax,%eax
    3d6b:	74 b6                	je     3d23 <fwp_segv+0x73>
    3d6d:	e8 be fe ff ff       	call   3c30 <fwp_flush>
    3d72:	bf 02 00 00 00       	mov    $0x2,%edi
    3d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3d7c:	48 8d 35 fd 8c 00 00 	lea    0x8cfd(%rip),%rsi        # ca80 <msg.4>
    3d83:	e8 88 f6 ff ff       	call   3410 <write@plt>
    3d88:	bf 65 00 00 00       	mov    $0x65,%edi
    3d8d:	e8 2e f6 ff ff       	call   33c0 <_exit@plt>
    3d92:	0f 1f 00             	nopl   (%rax)
    3d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d9c:	00 00 00 00 

0000000000003da0 <fwp_heap_chunks>:
    3da0:	41 54                	push   %r12
    3da2:	55                   	push   %rbp
    3da3:	53                   	push   %rbx
    3da4:	48 83 ff 01          	cmp    $0x1,%rdi
    3da8:	0f 84 62 01 00 00    	je     3f10 <fwp_heap_chunks+0x170>
    3dae:	48 8b 05 7b dd 01 00 	mov    0x1dd7b(%rip),%rax        # 21b30 <fwp_heap+0x13f0>
    3db5:	4c 8d 05 74 dd 01 00 	lea    0x1dd74(%rip),%r8        # 21b30 <fwp_heap+0x13f0>
    3dbc:	48 8b 1d 55 dd 01 00 	mov    0x1dd55(%rip),%rbx        # 21b18 <fwp_heap+0x13d8>
    3dc3:	48 39 d8             	cmp    %rbx,%rax
    3dc6:	0f 83 57 01 00 00    	jae    3f23 <fwp_heap_chunks+0x183>
    3dcc:	48 8b 0d 65 dd 01 00 	mov    0x1dd65(%rip),%rcx        # 21b38 <fwp_heap+0x13f8>
    3dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3dd7:	31 f6                	xor    %esi,%esi
    3dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ddd:	eb 1e                	jmp    3dfd <fwp_heap_chunks+0x5d>
    3ddf:	90                   	nop
    3de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3de4:	48 39 cf             	cmp    %rcx,%rdi
    3de7:	0f 84 03 01 00 00    	je     3ef0 <fwp_heap_chunks+0x150>
    3ded:	48 83 c0 01          	add    $0x1,%rax
    3df1:	48 89 ce             	mov    %rcx,%rsi
    3df4:	48 83 c2 28          	add    $0x28,%rdx
    3df8:	48 39 c3             	cmp    %rax,%rbx
    3dfb:	74 14                	je     3e11 <fwp_heap_chunks+0x71>
    3dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e00:	74 de                	je     3de0 <fwp_heap_chunks+0x40>
    3e02:	48 83 c0 01          	add    $0x1,%rax
    3e06:	31 f6                	xor    %esi,%esi
    3e08:	48 83 c2 28          	add    $0x28,%rdx
    3e0c:	48 39 c3             	cmp    %rax,%rbx
    3e0f:	75 ec                	jne    3dfd <fwp_heap_chunks+0x5d>
    3e11:	48 29 f3             	sub    %rsi,%rbx
    3e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e18:	48 8b 3d 01 dd 01 00 	mov    0x1dd01(%rip),%rdi        # 21b20 <fwp_heap+0x13e0>
    3e1f:	48 29 35 4a dd 01 00 	sub    %rsi,0x1dd4a(%rip)        # 21b70 <fwp_heap+0x1430>
    3e26:	48 39 ef             	cmp    %rbp,%rdi
    3e29:	0f 83 96 00 00 00    	jae    3ec5 <fwp_heap_chunks+0x125>
    3e2f:	48 8b 05 da dc 01 00 	mov    0x1dcda(%rip),%rax        # 21b10 <fwp_heap+0x13d0>
    3e36:	48 39 e8             	cmp    %rbp,%rax
    3e39:	0f 82 eb 00 00 00    	jb     3f2a <fwp_heap_chunks+0x18a>
    3e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e43:	ba 03 00 00 00       	mov    $0x3,%edx
    3e48:	49 39 c4             	cmp    %rax,%r12
    3e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e4f:	4c 89 e6             	mov    %r12,%rsi
    3e52:	48 29 fe             	sub    %rdi,%rsi
    3e55:	48 c1 e7 10          	shl    $0x10,%rdi
    3e59:	48 03 3d 90 dc 01 00 	add    0x1dc90(%rip),%rdi        # 21af0 <fwp_heap+0x13b0>
    3e60:	48 c1 e6 10          	shl    $0x10,%rsi
    3e64:	e8 77 f7 ff ff       	call   35e0 <mprotect@plt>
    3e69:	85 c0                	test   %eax,%eax
    3e6b:	0f 85 b9 00 00 00    	jne    3f2a <fwp_heap_chunks+0x18a>
    3e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3e76:	e8 85 f7 ff ff       	call   3600 <sysconf@plt>
    3e7b:	48 8b 35 9e dc 01 00 	mov    0x1dc9e(%rip),%rsi        # 21b20 <fwp_heap+0x13e0>
    3e82:	48 89 c1             	mov    %rax,%rcx
    3e85:	48 8b 05 ac dc 01 00 	mov    0x1dcac(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    3e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3e90:	48 89 ca             	mov    %rcx,%rdx
    3e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3e9b:	48 f7 da             	neg    %rdx
    3e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ea3:	48 21 d7             	and    %rdx,%rdi
    3ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eaa:	48 21 d6             	and    %rdx,%rsi
    3ead:	ba 03 00 00 00       	mov    $0x3,%edx
    3eb2:	48 29 fe             	sub    %rdi,%rsi
    3eb5:	e8 26 f7 ff ff       	call   35e0 <mprotect@plt>
    3eba:	85 c0                	test   %eax,%eax
    3ebc:	75 6c                	jne    3f2a <fwp_heap_chunks+0x18a>
    3ebe:	4c 89 25 5b dc 01 00 	mov    %r12,0x1dc5b(%rip)        # 21b20 <fwp_heap+0x13e0>
    3ec5:	48 89 ef             	mov    %rbp,%rdi
    3ec8:	48 89 2d 49 dc 01 00 	mov    %rbp,0x1dc49(%rip)        # 21b18 <fwp_heap+0x13d8>
    3ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    3ed3:	48 39 3d 2e dc 01 00 	cmp    %rdi,0x1dc2e(%rip)        # 21b08 <fwp_heap+0x13c8>
    3eda:	73 07                	jae    3ee3 <fwp_heap_chunks+0x143>
    3edc:	48 89 3d 25 dc 01 00 	mov    %rdi,0x1dc25(%rip)        # 21b08 <fwp_heap+0x13c8>
    3ee3:	48 89 d8             	mov    %rbx,%rax
    3ee6:	5b                   	pop    %rbx
    3ee7:	5d                   	pop    %rbp
    3ee8:	41 5c                	pop    %r12
    3eea:	c3                   	ret
    3eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3ef4:	48 29 f0             	sub    %rsi,%rax
    3ef7:	48 89 c3             	mov    %rax,%rbx
    3efa:	49 89 10             	mov    %rdx,(%r8)
    3efd:	48 89 d8             	mov    %rbx,%rax
    3f00:	48 29 3d 69 dc 01 00 	sub    %rdi,0x1dc69(%rip)        # 21b70 <fwp_heap+0x1430>
    3f07:	5b                   	pop    %rbx
    3f08:	5d                   	pop    %rbp
    3f09:	41 5c                	pop    %r12
    3f0b:	c3                   	ret
    3f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f10:	48 8b 05 11 dc 01 00 	mov    0x1dc11(%rip),%rax        # 21b28 <fwp_heap+0x13e8>
    3f17:	4c 8d 05 0a dc 01 00 	lea    0x1dc0a(%rip),%r8        # 21b28 <fwp_heap+0x13e8>
    3f1e:	e9 99 fe ff ff       	jmp    3dbc <fwp_heap_chunks+0x1c>
    3f23:	31 f6                	xor    %esi,%esi
    3f25:	e9 ea fe ff ff       	jmp    3e14 <fwp_heap_chunks+0x74>
    3f2a:	e8 41 fd ff ff       	call   3c70 <fwp_heap_oom>
    3f2f:	90                   	nop

0000000000003f30 <fwp_tape_buffers_dispose>:
    3f30:	53                   	push   %rbx
    3f31:	48 89 fb             	mov    %rdi,%rbx
    3f34:	48 8b 3f             	mov    (%rdi),%rdi
    3f37:	e8 64 f4 ff ff       	call   33a0 <free@plt>
    3f3c:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    3f40:	e8 5b f4 ff ff       	call   33a0 <free@plt>
    3f45:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f49:	e8 52 f4 ff ff       	call   33a0 <free@plt>
    3f4e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f52:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    3f59:	00 
    3f5a:	0f 11 03             	movups %xmm0,(%rbx)
    3f5d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3f61:	5b                   	pop    %rbx
    3f62:	c3                   	ret
    3f63:	66 90                	xchg   %ax,%ax
    3f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f6c:	00 00 00 00 

0000000000003f70 <buf_grow>:
    3f70:	48 83 ec 18          	sub    $0x18,%rsp
    3f74:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3f78:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3f7c:	74 7e                	je     3ffc <buf_grow+0x8c>
    3f7e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3f85:	48 29 c2             	sub    %rax,%rdx
    3f88:	48 39 f2             	cmp    %rsi,%rdx
    3f8b:	72 6f                	jb     3ffc <buf_grow+0x8c>
    3f8d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3f92:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f96:	48 89 f9             	mov    %rdi,%rcx
    3f99:	48 39 d0             	cmp    %rdx,%rax
    3f9c:	73 48                	jae    3fe6 <buf_grow+0x76>
    3f9e:	48 85 c0             	test   %rax,%rax
    3fa1:	75 15                	jne    3fb8 <buf_grow+0x48>
    3fa3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fa7:	76 4c                	jbe    3ff5 <buf_grow+0x85>
    3fa9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fae:	eb 08                	jmp    3fb8 <buf_grow+0x48>
    3fb0:	48 01 c0             	add    %rax,%rax
    3fb3:	48 39 d0             	cmp    %rdx,%rax
    3fb6:	73 38                	jae    3ff0 <buf_grow+0x80>
    3fb8:	48 85 c0             	test   %rax,%rax
    3fbb:	79 f3                	jns    3fb0 <buf_grow+0x40>
    3fbd:	48 8b 39             	mov    (%rcx),%rdi
    3fc0:	48 89 d6             	mov    %rdx,%rsi
    3fc3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3fc8:	48 89 14 24          	mov    %rdx,(%rsp)
    3fcc:	e8 cf f5 ff ff       	call   35a0 <realloc@plt>
    3fd1:	48 8b 14 24          	mov    (%rsp),%rdx
    3fd5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3fda:	48 85 c0             	test   %rax,%rax
    3fdd:	74 1d                	je     3ffc <buf_grow+0x8c>
    3fdf:	48 89 01             	mov    %rax,(%rcx)
    3fe2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    3fe6:	48 83 c4 18          	add    $0x18,%rsp
    3fea:	c3                   	ret
    3feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ff0:	48 89 c2             	mov    %rax,%rdx
    3ff3:	eb c8                	jmp    3fbd <buf_grow+0x4d>
    3ff5:	ba 40 00 00 00       	mov    $0x40,%edx
    3ffa:	eb c1                	jmp    3fbd <buf_grow+0x4d>
    3ffc:	48 8b 0d 3d c0 00 00 	mov    0xc03d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    4003:	ba 13 00 00 00       	mov    $0x13,%edx
    4008:	be 01 00 00 00       	mov    $0x1,%esi
    400d:	48 8d 3d f4 7f 00 00 	lea    0x7ff4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4014:	e8 27 f6 ff ff       	call   3640 <fwrite@plt>
    4019:	31 ff                	xor    %edi,%edi
    401b:	e8 70 f5 ff ff       	call   3590 <fflush@plt>
    4020:	bf 66 00 00 00       	mov    $0x66,%edi
    4025:	e8 36 f6 ff ff       	call   3660 <_Exit@plt>
    402a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004030 <buf_put>:
    4030:	41 54                	push   %r12
    4032:	49 89 f4             	mov    %rsi,%r12
    4035:	48 89 d6             	mov    %rdx,%rsi
    4038:	55                   	push   %rbp
    4039:	48 89 fd             	mov    %rdi,%rbp
    403c:	53                   	push   %rbx
    403d:	48 89 d3             	mov    %rdx,%rbx
    4040:	e8 2b ff ff ff       	call   3f70 <buf_grow>
    4045:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4049:	48 89 da             	mov    %rbx,%rdx
    404c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4050:	4c 89 e6             	mov    %r12,%rsi
    4053:	e8 18 f5 ff ff       	call   3570 <memcpy@plt>
    4058:	48 8b 45 00          	mov    0x0(%rbp),%rax
    405c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4060:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4064:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4068:	5b                   	pop    %rbx
    4069:	5d                   	pop    %rbp
    406a:	41 5c                	pop    %r12
    406c:	c3                   	ret
    406d:	0f 1f 00             	nopl   (%rax)

0000000000004070 <fwp_cancel_tree.part.0>:
    4070:	48 3b 3d a9 c6 01 00 	cmp    0x1c6a9(%rip),%rdi        # 20720 <fwp_cur>
    4077:	53                   	push   %rbx
    4078:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    407c:	74 35                	je     40b3 <fwp_cancel_tree.part.0+0x43>
    407e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4082:	75 2f                	jne    40b3 <fwp_cancel_tree.part.0+0x43>
    4084:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4088:	75 29                	jne    40b3 <fwp_cancel_tree.part.0+0x43>
    408a:	48 8b 05 6f c6 01 00 	mov    0x1c66f(%rip),%rax        # 20700 <fwp_ready_tail>
    4091:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4095:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    409c:	00 00 00 00 
    40a0:	48 85 c0             	test   %rax,%rax
    40a3:	74 33                	je     40d8 <fwp_cancel_tree.part.0+0x68>
    40a5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ac:	48 89 3d 4d c6 01 00 	mov    %rdi,0x1c64d(%rip)        # 20700 <fwp_ready_tail>
    40b3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40b7:	48 85 db             	test   %rbx,%rbx
    40ba:	74 17                	je     40d3 <fwp_cancel_tree.part.0+0x63>
    40bc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    40c0:	75 08                	jne    40ca <fwp_cancel_tree.part.0+0x5a>
    40c2:	48 89 df             	mov    %rbx,%rdi
    40c5:	e8 a6 ff ff ff       	call   4070 <fwp_cancel_tree.part.0>
    40ca:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    40ce:	48 85 db             	test   %rbx,%rbx
    40d1:	75 e9                	jne    40bc <fwp_cancel_tree.part.0+0x4c>
    40d3:	5b                   	pop    %rbx
    40d4:	c3                   	ret
    40d5:	0f 1f 00             	nopl   (%rax)
    40d8:	48 89 3d 29 c6 01 00 	mov    %rdi,0x1c629(%rip)        # 20708 <fwp_ready_head>
    40df:	eb cb                	jmp    40ac <fwp_cancel_tree.part.0+0x3c>
    40e1:	0f 1f 40 00          	nopl   0x0(%rax)
    40e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    40ec:	00 00 00 00 

00000000000040f0 <fwp_finish_float>:
    40f0:	53                   	push   %rbx
    40f1:	be 2e 00 00 00       	mov    $0x2e,%esi
    40f6:	48 89 fb             	mov    %rdi,%rbx
    40f9:	e8 62 f3 ff ff       	call   3460 <strchr@plt>
    40fe:	48 85 c0             	test   %rax,%rax
    4101:	74 05                	je     4108 <fwp_finish_float+0x18>
    4103:	5b                   	pop    %rbx
    4104:	c3                   	ret
    4105:	0f 1f 00             	nopl   (%rax)
    4108:	be 65 00 00 00       	mov    $0x65,%esi
    410d:	48 89 df             	mov    %rbx,%rdi
    4110:	e8 4b f3 ff ff       	call   3460 <strchr@plt>
    4115:	48 85 c0             	test   %rax,%rax
    4118:	75 e9                	jne    4103 <fwp_finish_float+0x13>
    411a:	48 8d 35 1b 80 00 00 	lea    0x801b(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    4121:	48 89 df             	mov    %rbx,%rdi
    4124:	e8 67 f5 ff ff       	call   3690 <strstr@plt>
    4129:	48 85 c0             	test   %rax,%rax
    412c:	75 d5                	jne    4103 <fwp_finish_float+0x13>
    412e:	48 8d 35 e7 7e 00 00 	lea    0x7ee7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    4135:	48 89 df             	mov    %rbx,%rdi
    4138:	e8 53 f5 ff ff       	call   3690 <strstr@plt>
    413d:	48 85 c0             	test   %rax,%rax
    4140:	75 c1                	jne    4103 <fwp_finish_float+0x13>
    4142:	48 89 df             	mov    %rbx,%rdi
    4145:	e8 e6 f2 ff ff       	call   3430 <strlen@plt>
    414a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    414f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4153:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4158:	5b                   	pop    %rbx
    4159:	c3                   	ret
    415a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004160 <fwp_trap>:
    4160:	55                   	push   %rbp
    4161:	48 89 fd             	mov    %rdi,%rbp
    4164:	53                   	push   %rbx
    4165:	48 83 ec 08          	sub    $0x8,%rsp
    4169:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4170:	ff ff 
    4172:	e8 b9 fa ff ff       	call   3c30 <fwp_flush>
    4177:	31 c0                	xor    %eax,%eax
    4179:	48 89 e9             	mov    %rbp,%rcx
    417c:	be 02 00 00 00       	mov    $0x2,%esi
    4181:	48 8b 3d b8 be 00 00 	mov    0xbeb8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4188:	48 8d 15 91 7e 00 00 	lea    0x7e91(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    418f:	e8 bc f4 ff ff       	call   3650 <__fprintf_chk@plt>
    4194:	48 85 db             	test   %rbx,%rbx
    4197:	74 16                	je     41af <fwp_trap+0x4f>
    4199:	48 8b 3d a0 be 00 00 	mov    0xbea0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41a0:	e8 eb f3 ff ff       	call   3590 <fflush@plt>
    41a5:	bf 65 00 00 00       	mov    $0x65,%edi
    41aa:	e8 b1 f4 ff ff       	call   3660 <_Exit@plt>
    41af:	bf 65 00 00 00       	mov    $0x65,%edi
    41b4:	e8 77 f4 ff ff       	call   3630 <exit@plt>
    41b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000041c0 <fwp_closure_drop_push>:
    41c0:	41 56                	push   %r14
    41c2:	41 54                	push   %r12
    41c4:	49 89 f4             	mov    %rsi,%r12
    41c7:	55                   	push   %rbp
    41c8:	48 89 fd             	mov    %rdi,%rbp
    41cb:	53                   	push   %rbx
    41cc:	48 83 ec 18          	sub    $0x18,%rsp
    41d0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    41d4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    41d8:	74 26                	je     4200 <fwp_closure_drop_push+0x40>
    41da:	4c 8b 07             	mov    (%rdi),%r8
    41dd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    41e4:	00 
    41e5:	48 83 c3 01          	add    $0x1,%rbx
    41e9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    41ed:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    41f1:	48 83 c4 18          	add    $0x18,%rsp
    41f5:	5b                   	pop    %rbx
    41f6:	5d                   	pop    %rbp
    41f7:	41 5c                	pop    %r12
    41f9:	41 5e                	pop    %r14
    41fb:	c3                   	ret
    41fc:	0f 1f 40 00          	nopl   0x0(%rax)
    4200:	48 89 d8             	mov    %rbx,%rax
    4203:	48 c1 e8 3c          	shr    $0x3c,%rax
    4207:	0f 85 a9 00 00 00    	jne    42b6 <fwp_closure_drop_push+0xf6>
    420d:	48 89 d9             	mov    %rbx,%rcx
    4210:	48 c1 e1 04          	shl    $0x4,%rcx
    4214:	48 89 cf             	mov    %rcx,%rdi
    4217:	48 89 0c 24          	mov    %rcx,(%rsp)
    421b:	e8 60 f3 ff ff       	call   3580 <malloc@plt>
    4220:	48 8b 0c 24          	mov    (%rsp),%rcx
    4224:	48 85 c0             	test   %rax,%rax
    4227:	74 5f                	je     4288 <fwp_closure_drop_push+0xc8>
    4229:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    422d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4234:	00 
    4235:	48 89 c7             	mov    %rax,%rdi
    4238:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    423c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4241:	48 89 34 24          	mov    %rsi,(%rsp)
    4245:	e8 f6 f2 ff ff       	call   3540 <__memcpy_chk@plt>
    424a:	48 8b 34 24          	mov    (%rsp),%rsi
    424e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4253:	49 89 c0             	mov    %rax,%r8
    4256:	48 8d 45 18          	lea    0x18(%rbp),%rax
    425a:	48 39 c6             	cmp    %rax,%rsi
    425d:	74 1c                	je     427b <fwp_closure_drop_push+0xbb>
    425f:	48 89 f7             	mov    %rsi,%rdi
    4262:	4c 89 04 24          	mov    %r8,(%rsp)
    4266:	e8 35 f1 ff ff       	call   33a0 <free@plt>
    426b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    426f:	4c 8b 04 24          	mov    (%rsp),%r8
    4273:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    427a:	00 
    427b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    427f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4283:	e9 5d ff ff ff       	jmp    41e5 <fwp_closure_drop_push+0x25>
    4288:	48 8b 0d b1 bd 00 00 	mov    0xbdb1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    428f:	ba 13 00 00 00       	mov    $0x13,%edx
    4294:	be 01 00 00 00       	mov    $0x1,%esi
    4299:	48 8d 3d 68 7d 00 00 	lea    0x7d68(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    42a0:	e8 9b f3 ff ff       	call   3640 <fwrite@plt>
    42a5:	31 ff                	xor    %edi,%edi
    42a7:	e8 e4 f2 ff ff       	call   3590 <fflush@plt>
    42ac:	bf 66 00 00 00       	mov    $0x66,%edi
    42b1:	e8 aa f3 ff ff       	call   3660 <_Exit@plt>
    42b6:	48 8d 3d 72 7d 00 00 	lea    0x7d72(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    42bd:	e8 9e fe ff ff       	call   4160 <fwp_trap>
    42c2:	0f 1f 00             	nopl   (%rax)
    42c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    42cc:	00 00 00 00 

00000000000042d0 <fwp_now_ns>:
    42d0:	53                   	push   %rbx
    42d1:	bf 01 00 00 00       	mov    $0x1,%edi
    42d6:	48 83 ec 20          	sub    $0x20,%rsp
    42da:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    42e1:	00 00 
    42e3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    42e8:	31 db                	xor    %ebx,%ebx
    42ea:	48 89 e6             	mov    %rsp,%rsi
    42ed:	e8 0e f1 ff ff       	call   3400 <clock_gettime@plt>
    42f2:	85 c0                	test   %eax,%eax
    42f4:	75 52                	jne    4348 <fwp_now_ns+0x78>
    42f6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    42fb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4300:	48 f7 2c 24          	imulq  (%rsp)
    4304:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    430b:	48 89 f7             	mov    %rsi,%rdi
    430e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4312:	48 01 f0             	add    %rsi,%rax
    4315:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    431c:	00 00 80 
    431f:	48 11 fa             	adc    %rdi,%rdx
    4322:	31 ff                	xor    %edi,%edi
    4324:	48 01 c6             	add    %rax,%rsi
    4327:	48 11 d7             	adc    %rdx,%rdi
    432a:	48 39 f1             	cmp    %rsi,%rcx
    432d:	48 19 fb             	sbb    %rdi,%rbx
    4330:	72 27                	jb     4359 <fwp_now_ns+0x89>
    4332:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4337:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    433e:	00 00 
    4340:	75 12                	jne    4354 <fwp_now_ns+0x84>
    4342:	48 83 c4 20          	add    $0x20,%rsp
    4346:	5b                   	pop    %rbx
    4347:	c3                   	ret
    4348:	48 8d 3d fa 7c 00 00 	lea    0x7cfa(%rip),%rdi        # c049 <_IO_stdin_used+0x49>
    434f:	e8 0c fe ff ff       	call   4160 <fwp_trap>
    4354:	e8 e7 f0 ff ff       	call   3440 <__stack_chk_fail@plt>
    4359:	48 8d 3d b0 82 00 00 	lea    0x82b0(%rip),%rdi        # c610 <_IO_stdin_used+0x610>
    4360:	e8 fb fd ff ff       	call   4160 <fwp_trap>
    4365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    436c:	00 00 00 00 

0000000000004370 <fwp_closure_drop.part.0>:
    4370:	53                   	push   %rbx
    4371:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4378:	66 0f 6f 05 40 87 00 	movdqa 0x8740(%rip),%xmm0        # cac0 <msg.4+0x40>
    437f:	00 
    4380:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4387:	00 00 
    4389:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4390:	00 
    4391:	48 89 fe             	mov    %rdi,%rsi
    4394:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4399:	48 89 e7             	mov    %rsp,%rdi
    439c:	48 89 1c 24          	mov    %rbx,(%rsp)
    43a0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43a5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ac:	ff ff 
    43ae:	e8 0d fe ff ff       	call   41c0 <fwp_closure_drop_push>
    43b3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43b8:	48 85 c0             	test   %rax,%rax
    43bb:	74 39                	je     43f6 <fwp_closure_drop.part.0+0x86>
    43bd:	0f 1f 00             	nopl   (%rax)
    43c0:	48 8b 14 24          	mov    (%rsp),%rdx
    43c4:	48 83 e8 01          	sub    $0x1,%rax
    43c8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    43cd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    43d1:	8b 07                	mov    (%rdi),%eax
    43d3:	48 c1 e0 05          	shl    $0x5,%rax
    43d7:	48 03 05 ba df 01 00 	add    0x1dfba(%rip),%rax        # 22398 <fwp_fns>
    43de:	48 8b 40 18          	mov    0x18(%rax),%rax
    43e2:	48 85 c0             	test   %rax,%rax
    43e5:	74 46                	je     442d <fwp_closure_drop.part.0+0xbd>
    43e7:	31 f6                	xor    %esi,%esi
    43e9:	ff 50 08             	call   *0x8(%rax)
    43ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f1:	48 85 c0             	test   %rax,%rax
    43f4:	75 ca                	jne    43c0 <fwp_closure_drop.part.0+0x50>
    43f6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    43fd:	ff ff 00 00 00 00 
    4403:	48 8b 3c 24          	mov    (%rsp),%rdi
    4407:	48 39 df             	cmp    %rbx,%rdi
    440a:	74 05                	je     4411 <fwp_closure_drop.part.0+0xa1>
    440c:	e8 8f ef ff ff       	call   33a0 <free@plt>
    4411:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4418:	00 
    4419:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4420:	00 00 
    4422:	75 15                	jne    4439 <fwp_closure_drop.part.0+0xc9>
    4424:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    442b:	5b                   	pop    %rbx
    442c:	c3                   	ret
    442d:	48 8d 3d 0c 82 00 00 	lea    0x820c(%rip),%rdi        # c640 <_IO_stdin_used+0x640>
    4434:	e8 27 fd ff ff       	call   4160 <fwp_trap>
    4439:	e8 02 f0 ff ff       	call   3440 <__stack_chk_fail@plt>
    443e:	66 90                	xchg   %ax,%ax

0000000000004440 <fwp_tape_of>:
    4440:	0f b7 d7             	movzwl %di,%edx
    4443:	48 85 d2             	test   %rdx,%rdx
    4446:	74 28                	je     4470 <fwp_tape_of+0x30>
    4448:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    444c:	48 39 05 85 bc 01 00 	cmp    %rax,0x1bc85(%rip)        # 200d8 <fwp_ntapes>
    4453:	7e 1b                	jle    4470 <fwp_tape_of+0x30>
    4455:	48 6b c0 58          	imul   $0x58,%rax,%rax
    4459:	48 03 05 80 bc 01 00 	add    0x1bc80(%rip),%rax        # 200e0 <fwp_tapes>
    4460:	8b 50 04             	mov    0x4(%rax),%edx
    4463:	85 d2                	test   %edx,%edx
    4465:	74 09                	je     4470 <fwp_tape_of+0x30>
    4467:	48 c1 ff 10          	sar    $0x10,%rdi
    446b:	39 38                	cmp    %edi,(%rax)
    446d:	75 01                	jne    4470 <fwp_tape_of+0x30>
    446f:	c3                   	ret
    4470:	48 83 ec 08          	sub    $0x8,%rsp
    4474:	48 8d 3d f5 81 00 00 	lea    0x81f5(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    447b:	e8 e0 fc ff ff       	call   4160 <fwp_trap>

0000000000004480 <fwp_format_g.constprop.0>:
    4480:	41 57                	push   %r15
    4482:	b9 40 00 00 00       	mov    $0x40,%ecx
    4487:	ba 02 00 00 00       	mov    $0x2,%edx
    448c:	4c 8d 05 d2 7b 00 00 	lea    0x7bd2(%rip),%r8        # c065 <_IO_stdin_used+0x65>
    4493:	41 56                	push   %r14
    4495:	b8 01 00 00 00       	mov    $0x1,%eax
    449a:	41 55                	push   %r13
    449c:	41 54                	push   %r12
    449e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44a2:	55                   	push   %rbp
    44a3:	45 89 e1             	mov    %r12d,%r9d
    44a6:	53                   	push   %rbx
    44a7:	48 89 fb             	mov    %rdi,%rbx
    44aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44b8:	00 00 
    44ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    44c1:	00 
    44c2:	41 89 f7             	mov    %esi,%r15d
    44c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    44ca:	be 40 00 00 00       	mov    $0x40,%esi
    44cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    44d4:	4c 89 f7             	mov    %r14,%rdi
    44d7:	e8 b4 ee ff ff       	call   3390 <__snprintf_chk@plt>
    44dc:	be 65 00 00 00       	mov    $0x65,%esi
    44e1:	4c 89 f7             	mov    %r14,%rdi
    44e4:	e8 77 ef ff ff       	call   3460 <strchr@plt>
    44e9:	31 f6                	xor    %esi,%esi
    44eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    44f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    44f4:	48 89 c5             	mov    %rax,%rbp
    44f7:	e8 64 f0 ff ff       	call   3560 <strtol@plt>
    44fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4501:	49 89 c0             	mov    %rax,%r8
    4504:	83 c0 05             	add    $0x5,%eax
    4507:	83 f8 15             	cmp    $0x15,%eax
    450a:	0f 87 f0 01 00 00    	ja     4700 <fwp_format_g.constprop.0+0x280>
    4510:	45 89 e5             	mov    %r12d,%r13d
    4513:	45 29 c5             	sub    %r8d,%r13d
    4516:	45 85 ed             	test   %r13d,%r13d
    4519:	0f 8e 21 01 00 00    	jle    4640 <fwp_format_g.constprop.0+0x1c0>
    451f:	41 83 ff 01          	cmp    $0x1,%r15d
    4523:	0f 84 17 01 00 00    	je     4640 <fwp_format_g.constprop.0+0x1c0>
    4529:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    452e:	31 d2                	xor    %edx,%edx
    4530:	4d 63 df             	movslq %r15d,%r11
    4533:	3c 2d                	cmp    $0x2d,%al
    4535:	0f 94 c2             	sete   %dl
    4538:	4c 29 dd             	sub    %r11,%rbp
    453b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    453f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4543:	4d 89 f1             	mov    %r14,%r9
    4546:	4d 29 d1             	sub    %r10,%r9
    4549:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    454d:	3c 2d                	cmp    $0x2d,%al
    454f:	0f 84 0b 04 00 00    	je     4960 <fwp_format_g.constprop.0+0x4e0>
    4555:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    455a:	b9 48 00 00 00       	mov    $0x48,%ecx
    455f:	48 89 e8             	mov    %rbp,%rax
    4562:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4566:	49 8d 72 01          	lea    0x1(%r10),%rsi
    456a:	49 83 c1 47          	add    $0x47,%r9
    456e:	45 85 c0             	test   %r8d,%r8d
    4571:	0f 88 01 03 00 00    	js     4878 <fwp_format_g.constprop.0+0x3f8>
    4577:	45 0f b6 12          	movzbl (%r10),%r10d
    457b:	4d 63 e0             	movslq %r8d,%r12
    457e:	44 88 10             	mov    %r10b,(%rax)
    4581:	41 83 f8 07          	cmp    $0x7,%r8d
    4585:	0f 87 3d 02 00 00    	ja     47c8 <fwp_format_g.constprop.0+0x348>
    458b:	41 f6 c4 04          	test   $0x4,%r12b
    458f:	0f 85 02 04 00 00    	jne    4997 <fwp_format_g.constprop.0+0x517>
    4595:	45 85 e4             	test   %r12d,%r12d
    4598:	74 12                	je     45ac <fwp_format_g.constprop.0+0x12c>
    459a:	45 0f b6 06          	movzbl (%r14),%r8d
    459e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45a2:	41 f6 c4 02          	test   $0x2,%r12b
    45a6:	0f 85 13 04 00 00    	jne    49bf <fwp_format_g.constprop.0+0x53f>
    45ac:	4c 29 e1             	sub    %r12,%rcx
    45af:	4c 01 e7             	add    %r12,%rdi
    45b2:	4c 89 fa             	mov    %r15,%rdx
    45b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45ba:	48 83 e9 01          	sub    $0x1,%rcx
    45be:	4d 63 ed             	movslq %r13d,%r13
    45c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    45c5:	e8 76 ef ff ff       	call   3540 <__memcpy_chk@plt>
    45ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    45cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    45d3:	ba 48 00 00 00       	mov    $0x48,%edx
    45d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    45dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    45e0:	4c 89 c8             	mov    %r9,%rax
    45e3:	48 29 c8             	sub    %rcx,%rax
    45e6:	48 39 d0             	cmp    %rdx,%rax
    45e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    45ed:	4c 29 c9             	sub    %r9,%rcx
    45f0:	4c 89 ea             	mov    %r13,%rdx
    45f3:	48 01 c1             	add    %rax,%rcx
    45f6:	e8 45 ef ff ff       	call   3540 <__memcpy_chk@plt>
    45fb:	4c 01 e8             	add    %r13,%rax
    45fe:	48 29 e8             	sub    %rbp,%rax
    4601:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4606:	48 39 d0             	cmp    %rdx,%rax
    4609:	48 0f 47 c2          	cmova  %rdx,%rax
    460d:	89 c1                	mov    %eax,%ecx
    460f:	83 f8 08             	cmp    $0x8,%eax
    4612:	0f 83 28 02 00 00    	jae    4840 <fwp_format_g.constprop.0+0x3c0>
    4618:	a8 04                	test   $0x4,%al
    461a:	0f 85 64 03 00 00    	jne    4984 <fwp_format_g.constprop.0+0x504>
    4620:	85 c0                	test   %eax,%eax
    4622:	74 0f                	je     4633 <fwp_format_g.constprop.0+0x1b3>
    4624:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4629:	88 13                	mov    %dl,(%rbx)
    462b:	a8 02                	test   $0x2,%al
    462d:	0f 85 7b 03 00 00    	jne    49ae <fwp_format_g.constprop.0+0x52e>
    4633:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4637:	eb 36                	jmp    466f <fwp_format_g.constprop.0+0x1ef>
    4639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4640:	45 31 c9             	xor    %r9d,%r9d
    4643:	45 85 ed             	test   %r13d,%r13d
    4646:	4c 8d 05 27 7a 00 00 	lea    0x7a27(%rip),%r8        # c074 <_IO_stdin_used+0x74>
    464d:	48 89 df             	mov    %rbx,%rdi
    4650:	45 0f 49 cd          	cmovns %r13d,%r9d
    4654:	ba 02 00 00 00       	mov    $0x2,%edx
    4659:	be 90 01 00 00       	mov    $0x190,%esi
    465e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4665:	b8 01 00 00 00       	mov    $0x1,%eax
    466a:	e8 21 ed ff ff       	call   3390 <__snprintf_chk@plt>
    466f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4674:	48 89 df             	mov    %rbx,%rdi
    4677:	e8 e4 ed ff ff       	call   3460 <strchr@plt>
    467c:	48 85 c0             	test   %rax,%rax
    467f:	74 4f                	je     46d0 <fwp_format_g.constprop.0+0x250>
    4681:	48 89 df             	mov    %rbx,%rdi
    4684:	e8 a7 ed ff ff       	call   3430 <strlen@plt>
    4689:	48 85 c0             	test   %rax,%rax
    468c:	75 1b                	jne    46a9 <fwp_format_g.constprop.0+0x229>
    468e:	eb 40                	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    4690:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    469c:	00 00 00 00 
    46a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46a4:	48 85 c0             	test   %rax,%rax
    46a7:	74 27                	je     46d0 <fwp_format_g.constprop.0+0x250>
    46a9:	48 89 c2             	mov    %rax,%rdx
    46ac:	48 83 e8 01          	sub    $0x1,%rax
    46b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46b4:	74 ea                	je     46a0 <fwp_format_g.constprop.0+0x220>
    46b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46bb:	0f 84 6f 01 00 00    	je     4830 <fwp_format_g.constprop.0+0x3b0>
    46c1:	0f 1f 40 00          	nopl   0x0(%rax)
    46c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46cc:	00 00 00 00 
    46d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    46d7:	00 
    46d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46df:	00 00 
    46e1:	0f 85 ec 02 00 00    	jne    49d3 <fwp_format_g.constprop.0+0x553>
    46e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    46ee:	5b                   	pop    %rbx
    46ef:	5d                   	pop    %rbp
    46f0:	41 5c                	pop    %r12
    46f2:	41 5d                	pop    %r13
    46f4:	41 5e                	pop    %r14
    46f6:	41 5f                	pop    %r15
    46f8:	c3                   	ret
    46f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4700:	4c 29 f5             	sub    %r14,%rbp
    4703:	b9 40 00 00 00       	mov    $0x40,%ecx
    4708:	4c 89 f6             	mov    %r14,%rsi
    470b:	4c 89 04 24          	mov    %r8,(%rsp)
    470f:	49 89 ec             	mov    %rbp,%r12
    4712:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4717:	4c 89 e2             	mov    %r12,%rdx
    471a:	48 89 ef             	mov    %rbp,%rdi
    471d:	e8 1e ee ff ff       	call   3540 <__memcpy_chk@plt>
    4722:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4728:	be 2e 00 00 00       	mov    $0x2e,%esi
    472d:	48 89 ef             	mov    %rbp,%rdi
    4730:	e8 2b ed ff ff       	call   3460 <strchr@plt>
    4735:	4c 8b 04 24          	mov    (%rsp),%r8
    4739:	48 85 c0             	test   %rax,%rax
    473c:	74 40                	je     477e <fwp_format_g.constprop.0+0x2fe>
    473e:	4d 85 e4             	test   %r12,%r12
    4741:	74 3b                	je     477e <fwp_format_g.constprop.0+0x2fe>
    4743:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4748:	eb 23                	jmp    476d <fwp_format_g.constprop.0+0x2ed>
    474a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4751:	00 00 00 00 
    4755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    475c:	00 00 00 00 
    4760:	c6 00 00             	movb   $0x0,(%rax)
    4763:	48 83 e8 01          	sub    $0x1,%rax
    4767:	49 83 ec 01          	sub    $0x1,%r12
    476b:	74 11                	je     477e <fwp_format_g.constprop.0+0x2fe>
    476d:	80 38 30             	cmpb   $0x30,(%rax)
    4770:	74 ee                	je     4760 <fwp_format_g.constprop.0+0x2e0>
    4772:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4778:	0f 84 fb 01 00 00    	je     4979 <fwp_format_g.constprop.0+0x4f9>
    477e:	44 89 c0             	mov    %r8d,%eax
    4781:	ba 02 00 00 00       	mov    $0x2,%edx
    4786:	49 89 e9             	mov    %rbp,%r9
    4789:	be 90 01 00 00       	mov    $0x190,%esi
    478e:	f7 d8                	neg    %eax
    4790:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4797:	48 89 df             	mov    %rbx,%rdi
    479a:	41 0f 48 c0          	cmovs  %r8d,%eax
    479e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47a2:	41 83 e0 02          	and    $0x2,%r8d
    47a6:	41 83 c0 2b          	add    $0x2b,%r8d
    47aa:	50                   	push   %rax
    47ab:	31 c0                	xor    %eax,%eax
    47ad:	41 50                	push   %r8
    47af:	4c 8d 05 b4 78 00 00 	lea    0x78b4(%rip),%r8        # c06a <_IO_stdin_used+0x6a>
    47b6:	e8 d5 eb ff ff       	call   3390 <__snprintf_chk@plt>
    47bb:	58                   	pop    %rax
    47bc:	5a                   	pop    %rdx
    47bd:	e9 0e ff ff ff       	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    47c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    47c8:	4d 8b 06             	mov    (%r14),%r8
    47cb:	48 83 c0 09          	add    $0x9,%rax
    47cf:	4c 89 f2             	mov    %r14,%rdx
    47d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    47d6:	4c 89 07             	mov    %r8,(%rdi)
    47d9:	45 89 e0             	mov    %r12d,%r8d
    47dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    47e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    47e6:	49 89 f8             	mov    %rdi,%r8
    47e9:	49 29 c0             	sub    %rax,%r8
    47ec:	4c 29 c2             	sub    %r8,%rdx
    47ef:	45 01 e0             	add    %r12d,%r8d
    47f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    47f6:	41 83 f8 08          	cmp    $0x8,%r8d
    47fa:	0f 82 ac fd ff ff    	jb     45ac <fwp_format_g.constprop.0+0x12c>
    4800:	48 89 0c 24          	mov    %rcx,(%rsp)
    4804:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4808:	45 31 d2             	xor    %r10d,%r10d
    480b:	45 89 d3             	mov    %r10d,%r11d
    480e:	41 83 c2 08          	add    $0x8,%r10d
    4812:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4816:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    481a:	45 39 c2             	cmp    %r8d,%r10d
    481d:	72 ec                	jb     480b <fwp_format_g.constprop.0+0x38b>
    481f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4823:	e9 84 fd ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    4828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    482f:	00 
    4830:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4835:	e9 96 fe ff ff       	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    483a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4840:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4845:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4849:	48 89 ee             	mov    %rbp,%rsi
    484c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4850:	48 89 13             	mov    %rdx,(%rbx)
    4853:	89 c2                	mov    %eax,%edx
    4855:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    485a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    485f:	48 89 d9             	mov    %rbx,%rcx
    4862:	48 29 f9             	sub    %rdi,%rcx
    4865:	48 29 ce             	sub    %rcx,%rsi
    4868:	01 c1                	add    %eax,%ecx
    486a:	c1 e9 03             	shr    $0x3,%ecx
    486d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4870:	e9 be fd ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    4875:	0f 1f 00             	nopl   (%rax)
    4878:	c6 00 30             	movb   $0x30,(%rax)
    487b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    487f:	4c 89 fa             	mov    %r15,%rdx
    4882:	4c 89 e9             	mov    %r13,%rcx
    4885:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    488a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488f:	4c 89 14 24          	mov    %r10,(%rsp)
    4893:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4898:	e8 a3 ec ff ff       	call   3540 <__memcpy_chk@plt>
    489d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ac:	48 89 c7             	mov    %rax,%rdi
    48af:	4c 8b 14 24          	mov    (%rsp),%r10
    48b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48b8:	4c 89 c8             	mov    %r9,%rax
    48bb:	4c 29 e8             	sub    %r13,%rax
    48be:	48 39 c8             	cmp    %rcx,%rax
    48c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    48c5:	4d 29 cd             	sub    %r9,%r13
    48c8:	49 01 ff             	add    %rdi,%r15
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    48d2:	74 3d                	je     4911 <fwp_format_g.constprop.0+0x491>
    48d4:	41 f7 d0             	not    %r8d
    48d7:	31 f6                	xor    %esi,%esi
    48d9:	ba 48 00 00 00       	mov    $0x48,%edx
    48de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    48e3:	48 39 d0             	cmp    %rdx,%rax
    48e6:	48 0f 43 d0          	cmovae %rax,%rdx
    48ea:	48 89 d1             	mov    %rdx,%rcx
    48ed:	48 29 c1             	sub    %rax,%rcx
    48f0:	48 83 c1 01          	add    $0x1,%rcx
    48f4:	48 39 d1             	cmp    %rdx,%rcx
    48f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    48fb:	48 83 e8 01          	sub    $0x1,%rax
    48ff:	48 83 c6 01          	add    $0x1,%rsi
    4903:	48 29 d0             	sub    %rdx,%rax
    4906:	48 01 c8             	add    %rcx,%rax
    4909:	41 39 f0             	cmp    %esi,%r8d
    490c:	7f cb                	jg     48d9 <fwp_format_g.constprop.0+0x459>
    490e:	4d 01 c7             	add    %r8,%r15
    4911:	b9 48 00 00 00       	mov    $0x48,%ecx
    4916:	41 0f b6 12          	movzbl (%r10),%edx
    491a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    491e:	4c 89 f6             	mov    %r14,%rsi
    4921:	48 39 c8             	cmp    %rcx,%rax
    4924:	4c 89 1c 24          	mov    %r11,(%rsp)
    4928:	48 0f 43 c8          	cmovae %rax,%rcx
    492c:	41 88 17             	mov    %dl,(%r15)
    492f:	48 89 ca             	mov    %rcx,%rdx
    4932:	48 29 c2             	sub    %rax,%rdx
    4935:	48 83 c2 01          	add    $0x1,%rdx
    4939:	48 39 ca             	cmp    %rcx,%rdx
    493c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4940:	48 83 e8 01          	sub    $0x1,%rax
    4944:	48 29 c8             	sub    %rcx,%rax
    4947:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    494b:	49 63 d4             	movslq %r12d,%rdx
    494e:	e8 ed eb ff ff       	call   3540 <__memcpy_chk@plt>
    4953:	4c 8b 1c 24          	mov    (%rsp),%r11
    4957:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    495b:	e9 9e fc ff ff       	jmp    45fe <fwp_format_g.constprop.0+0x17e>
    4960:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4965:	b9 47 00 00 00       	mov    $0x47,%ecx
    496a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    496f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4974:	e9 e9 fb ff ff       	jmp    4562 <fwp_format_g.constprop.0+0xe2>
    4979:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    497f:	e9 fa fd ff ff       	jmp    477e <fwp_format_g.constprop.0+0x2fe>
    4984:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4988:	89 13                	mov    %edx,(%rbx)
    498a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    498e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4992:	e9 9c fc ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    4997:	41 8b 06             	mov    (%r14),%eax
    499a:	89 07                	mov    %eax,(%rdi)
    499c:	44 89 e0             	mov    %r12d,%eax
    499f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49a9:	e9 fe fb ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    49ae:	89 c2                	mov    %eax,%edx
    49b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49ba:	e9 74 fc ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    49bf:	44 89 e0             	mov    %r12d,%eax
    49c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    49c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    49ce:	e9 d9 fb ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    49d3:	e8 68 ea ff ff       	call   3440 <__stack_chk_fail@plt>
    49d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    49df:	00 

00000000000049e0 <fwp_heap_report>:
    49e0:	f3 0f 1e fa          	endbr64
    49e4:	41 54                	push   %r12
    49e6:	48 8d 3d 8c 76 00 00 	lea    0x768c(%rip),%rdi        # c079 <_IO_stdin_used+0x79>
    49ed:	55                   	push   %rbp
    49ee:	53                   	push   %rbx
    49ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    49f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    49fd:	00 00 
    49ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a06:	00 
    4a07:	48 8d 35 76 77 00 00 	lea    0x7776(%rip),%rsi        # c184 <_IO_stdin_used+0x184>
    4a0e:	e8 dd eb ff ff       	call   35f0 <fopen@plt>
    4a13:	48 85 c0             	test   %rax,%rax
    4a16:	0f 84 c5 00 00 00    	je     4ae1 <fwp_heap_report+0x101>
    4a1c:	48 89 c5             	mov    %rax,%rbp
    4a1f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a26:	48 89 e3             	mov    %rsp,%rbx
    4a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a30:	48 89 ea             	mov    %rbp,%rdx
    4a33:	be 00 01 00 00       	mov    $0x100,%esi
    4a38:	48 89 df             	mov    %rbx,%rdi
    4a3b:	e8 a0 ea ff ff       	call   34e0 <fgets@plt>
    4a40:	48 85 c0             	test   %rax,%rax
    4a43:	74 2b                	je     4a70 <fwp_heap_report+0x90>
    4a45:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a4b:	75 e3                	jne    4a30 <fwp_heap_report+0x50>
    4a4d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a51:	75 dd                	jne    4a30 <fwp_heap_report+0x50>
    4a53:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a58:	75 d6                	jne    4a30 <fwp_heap_report+0x50>
    4a5a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a5f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4a64:	31 f6                	xor    %esi,%esi
    4a66:	e8 f5 ea ff ff       	call   3560 <strtol@plt>
    4a6b:	49 89 c4             	mov    %rax,%r12
    4a6e:	eb c0                	jmp    4a30 <fwp_heap_report+0x50>
    4a70:	48 89 ef             	mov    %rbp,%rdi
    4a73:	e8 a8 e9 ff ff       	call   3420 <fclose@plt>
    4a78:	48 83 ec 08          	sub    $0x8,%rsp
    4a7c:	4c 8b 0d 85 d0 01 00 	mov    0x1d085(%rip),%r9        # 21b08 <fwp_heap+0x13c8>
    4a83:	4c 8b 05 de d0 01 00 	mov    0x1d0de(%rip),%r8        # 21b68 <fwp_heap+0x1428>
    4a8a:	48 8d 15 2f 7c 00 00 	lea    0x7c2f(%rip),%rdx        # c6c0 <_IO_stdin_used+0x6c0>
    4a91:	41 54                	push   %r12
    4a93:	48 8b 0d c6 d0 01 00 	mov    0x1d0c6(%rip),%rcx        # 21b60 <fwp_heap+0x1420>
    4a9a:	be 02 00 00 00       	mov    $0x2,%esi
    4a9f:	b8 02 00 00 00       	mov    $0x2,%eax
    4aa4:	f2 0f 10 0d d4 d0 01 	movsd  0x1d0d4(%rip),%xmm1        # 21b80 <fwp_heap+0x1440>
    4aab:	00 
    4aac:	f2 0f 10 05 c4 d0 01 	movsd  0x1d0c4(%rip),%xmm0        # 21b78 <fwp_heap+0x1438>
    4ab3:	00 
    4ab4:	48 8b 3d 85 b5 00 00 	mov    0xb585(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4abb:	e8 90 eb ff ff       	call   3650 <__fprintf_chk@plt>
    4ac0:	58                   	pop    %rax
    4ac1:	5a                   	pop    %rdx
    4ac2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4ac9:	00 
    4aca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4ad1:	00 00 
    4ad3:	75 15                	jne    4aea <fwp_heap_report+0x10a>
    4ad5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4adc:	5b                   	pop    %rbx
    4add:	5d                   	pop    %rbp
    4ade:	41 5c                	pop    %r12
    4ae0:	c3                   	ret
    4ae1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ae8:	eb 8e                	jmp    4a78 <fwp_heap_report+0x98>
    4aea:	e8 51 e9 ff ff       	call   3440 <__stack_chk_fail@plt>
    4aef:	90                   	nop

0000000000004af0 <fwp_heap_init>:
    4af0:	66 0f 6f 05 d8 7f 00 	movdqa 0x7fd8(%rip),%xmm0        # cad0 <msg.4+0x50>
    4af7:	00 
    4af8:	41 54                	push   %r12
    4afa:	48 8d 05 7f cb 01 00 	lea    0x1cb7f(%rip),%rax        # 21680 <fwp_heap+0xf40>
    4b01:	ba 00 01 00 00       	mov    $0x100,%edx
    4b06:	55                   	push   %rbp
    4b07:	66 0f 6f 15 01 80 00 	movdqa 0x8001(%rip),%xmm2        # cb10 <msg.4+0x90>
    4b0e:	00 
    4b0f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b13:	53                   	push   %rbx
    4b14:	0f 29 05 25 cb 01 00 	movaps %xmm0,0x1cb25(%rip)        # 21640 <fwp_heap+0xf00>
    4b1b:	66 0f 6f 05 bd 7f 00 	movdqa 0x7fbd(%rip),%xmm0        # cae0 <msg.4+0x60>
    4b22:	00 
    4b23:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b27:	c7 05 b3 cf 01 00 01 	movl   $0x1,0x1cfb3(%rip)        # 21ae4 <fwp_heap+0x13a4>
    4b2e:	00 00 00 
    4b31:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b36:	0f 29 05 13 cb 01 00 	movaps %xmm0,0x1cb13(%rip)        # 21650 <fwp_heap+0xf10>
    4b3d:	66 0f 6f 05 ab 7f 00 	movdqa 0x7fab(%rip),%xmm0        # caf0 <msg.4+0x70>
    4b44:	00 
    4b45:	0f 29 05 14 cb 01 00 	movaps %xmm0,0x1cb14(%rip)        # 21660 <fwp_heap+0xf20>
    4b4c:	66 0f 6f 05 ac 7f 00 	movdqa 0x7fac(%rip),%xmm0        # cb00 <msg.4+0x80>
    4b53:	00 
    4b54:	0f 29 05 15 cb 01 00 	movaps %xmm0,0x1cb15(%rip)        # 21670 <fwp_heap+0xf30>
    4b5b:	89 d3                	mov    %edx,%ebx
    4b5d:	66 0f 6e e2          	movd   %edx,%xmm4
    4b61:	48 83 c0 10          	add    $0x10,%rax
    4b65:	01 d2                	add    %edx,%edx
    4b67:	c1 eb 02             	shr    $0x2,%ebx
    4b6a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4b6e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4b73:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4b77:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4b7c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4b80:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4b84:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4b89:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4b8e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4b92:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4b97:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4b9b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4b9f:	48 39 c7             	cmp    %rax,%rdi
    4ba2:	75 b7                	jne    4b5b <fwp_heap_init+0x6b>
    4ba4:	4c 8d 05 95 bb 01 00 	lea    0x1bb95(%rip),%r8        # 20740 <fwp_heap>
    4bab:	31 c9                	xor    %ecx,%ecx
    4bad:	31 c0                	xor    %eax,%eax
    4baf:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bbd:	00 00 00 
    4bc0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4bc7:	00 
    4bc8:	48 39 ca             	cmp    %rcx,%rdx
    4bcb:	73 0f                	jae    4bdc <fwp_heap_init+0xec>
    4bcd:	0f 1f 00             	nopl   (%rax)
    4bd0:	48 83 c0 01          	add    $0x1,%rax
    4bd4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4bd7:	48 39 ca             	cmp    %rcx,%rdx
    4bda:	72 f4                	jb     4bd0 <fwp_heap_init+0xe0>
    4bdc:	48 83 c1 10          	add    $0x10,%rcx
    4be0:	88 07                	mov    %al,(%rdi)
    4be2:	48 83 c7 01          	add    $0x1,%rdi
    4be6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4bed:	75 d1                	jne    4bc0 <fwp_heap_init+0xd0>
    4bef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4bf6:	00 00 00 
    4bf9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4bfe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c05:	45 31 c9             	xor    %r9d,%r9d
    4c08:	31 d2                	xor    %edx,%edx
    4c0a:	31 ff                	xor    %edi,%edi
    4c0c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c12:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c17:	4c 89 e6             	mov    %r12,%rsi
    4c1a:	e8 31 e8 ff ff       	call   3450 <mmap@plt>
    4c1f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c23:	75 13                	jne    4c38 <fwp_heap_init+0x148>
    4c25:	48 c1 eb 02          	shr    $0x2,%rbx
    4c29:	83 ed 01             	sub    $0x1,%ebp
    4c2c:	75 d0                	jne    4bfe <fwp_heap_init+0x10e>
    4c2e:	e8 3d f0 ff ff       	call   3c70 <fwp_heap_oom>
    4c33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c38:	48 85 c0             	test   %rax,%rax
    4c3b:	74 f1                	je     4c2e <fwp_heap_init+0x13e>
    4c3d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c41:	48 89 05 b0 ce 01 00 	mov    %rax,0x1ceb0(%rip)        # 21af8 <fwp_heap+0x13b8>
    4c48:	45 31 c9             	xor    %r9d,%r9d
    4c4b:	31 d2                	xor    %edx,%edx
    4c4d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c53:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c57:	31 ff                	xor    %edi,%edi
    4c59:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c5f:	66 31 c0             	xor    %ax,%ax
    4c62:	48 c1 e6 03          	shl    $0x3,%rsi
    4c66:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c6b:	4c 89 25 8e ce 01 00 	mov    %r12,0x1ce8e(%rip)        # 21b00 <fwp_heap+0x13c0>
    4c72:	48 89 05 77 ce 01 00 	mov    %rax,0x1ce77(%rip)        # 21af0 <fwp_heap+0x13b0>
    4c79:	48 89 1d 90 ce 01 00 	mov    %rbx,0x1ce90(%rip)        # 21b10 <fwp_heap+0x13d0>
    4c80:	48 89 35 b9 ce 01 00 	mov    %rsi,0x1ceb9(%rip)        # 21b40 <fwp_heap+0x1400>
    4c87:	e8 c4 e7 ff ff       	call   3450 <mmap@plt>
    4c8c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c90:	74 9c                	je     4c2e <fwp_heap_init+0x13e>
    4c92:	48 8d 3d 16 74 00 00 	lea    0x7416(%rip),%rdi        # c0af <_IO_stdin_used+0xaf>
    4c99:	48 89 05 98 ce 01 00 	mov    %rax,0x1ce98(%rip)        # 21b38 <fwp_heap+0x13f8>
    4ca0:	e8 db e6 ff ff       	call   3380 <getenv@plt>
    4ca5:	48 89 c2             	mov    %rax,%rdx
    4ca8:	31 c0                	xor    %eax,%eax
    4caa:	48 85 d2             	test   %rdx,%rdx
    4cad:	74 15                	je     4cc4 <fwp_heap_init+0x1d4>
    4caf:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cb2:	74 10                	je     4cc4 <fwp_heap_init+0x1d4>
    4cb4:	0f b6 02             	movzbl (%rdx),%eax
    4cb7:	83 e8 30             	sub    $0x30,%eax
    4cba:	74 13                	je     4ccf <fwp_heap_init+0x1df>
    4cbc:	85 c0                	test   %eax,%eax
    4cbe:	0f 95 c0             	setne  %al
    4cc1:	0f b6 c0             	movzbl %al,%eax
    4cc4:	5b                   	pop    %rbx
    4cc5:	5d                   	pop    %rbp
    4cc6:	89 05 1c ce 01 00    	mov    %eax,0x1ce1c(%rip)        # 21ae8 <fwp_heap+0x13a8>
    4ccc:	41 5c                	pop    %r12
    4cce:	c3                   	ret
    4ccf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4cd3:	85 c0                	test   %eax,%eax
    4cd5:	0f 95 c0             	setne  %al
    4cd8:	0f b6 c0             	movzbl %al,%eax
    4cdb:	eb e7                	jmp    4cc4 <fwp_heap_init+0x1d4>
    4cdd:	0f 1f 00             	nopl   (%rax)

0000000000004ce0 <fwp_wake_io>:
    4ce0:	48 8b 07             	mov    (%rdi),%rax
    4ce3:	48 85 c0             	test   %rax,%rax
    4ce6:	0f 84 f4 00 00 00    	je     4de0 <fwp_wake_io+0x100>
    4cec:	53                   	push   %rbx
    4ced:	4c 8b 05 0c ba 01 00 	mov    0x1ba0c(%rip),%r8        # 20700 <fwp_ready_tail>
    4cf4:	49 89 f9             	mov    %rdi,%r9
    4cf7:	48 89 c2             	mov    %rax,%rdx
    4cfa:	45 31 db             	xor    %r11d,%r11d
    4cfd:	45 31 d2             	xor    %r10d,%r10d
    4d00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d04:	eb 71                	jmp    4d77 <fwp_wake_io+0x97>
    4d06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d0d:	00 00 00 
    4d10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d1e:	48 85 c9             	test   %rcx,%rcx
    4d21:	74 07                	je     4d2a <fwp_wake_io+0x4a>
    4d23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d31:	00 00 00 00 
    4d35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d3c:	49 8b 01             	mov    (%r9),%rax
    4d3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d43:	75 2a                	jne    4d6f <fwp_wake_io+0x8f>
    4d45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d49:	75 24                	jne    4d6f <fwp_wake_io+0x8f>
    4d4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d56:	00 00 00 00 
    4d5a:	4d 85 c0             	test   %r8,%r8
    4d5d:	74 51                	je     4db0 <fwp_wake_io+0xd0>
    4d5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4d66:	49 89 d0             	mov    %rdx,%r8
    4d69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4d6f:	48 89 c2             	mov    %rax,%rdx
    4d72:	48 85 c0             	test   %rax,%rax
    4d75:	74 49                	je     4dc0 <fwp_wake_io+0xe0>
    4d77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4d7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4d82:	48 85 ff             	test   %rdi,%rdi
    4d85:	74 b8                	je     4d3f <fwp_wake_io+0x5f>
    4d87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4d8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d95:	48 85 f6             	test   %rsi,%rsi
    4d98:	0f 85 72 ff ff ff    	jne    4d10 <fwp_wake_io+0x30>
    4d9e:	48 89 0f             	mov    %rcx,(%rdi)
    4da1:	e9 78 ff ff ff       	jmp    4d1e <fwp_wake_io+0x3e>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 d3             	mov    %rdx,%rbx
    4db3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4db9:	eb ab                	jmp    4d66 <fwp_wake_io+0x86>
    4dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4dc0:	45 84 db             	test   %r11b,%r11b
    4dc3:	74 07                	je     4dcc <fwp_wake_io+0xec>
    4dc5:	48 89 1d 3c b9 01 00 	mov    %rbx,0x1b93c(%rip)        # 20708 <fwp_ready_head>
    4dcc:	45 84 d2             	test   %r10b,%r10b
    4dcf:	74 07                	je     4dd8 <fwp_wake_io+0xf8>
    4dd1:	4c 89 05 28 b9 01 00 	mov    %r8,0x1b928(%rip)        # 20700 <fwp_ready_tail>
    4dd8:	5b                   	pop    %rbx
    4dd9:	c3                   	ret
    4dda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4de0:	c3                   	ret
    4de1:	0f 1f 40 00          	nopl   0x0(%rax)
    4de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dec:	00 00 00 00 

0000000000004df0 <fwp_tape_buffers_release>:
    4df0:	f3 0f 1e fa          	endbr64
    4df4:	53                   	push   %rbx
    4df5:	48 89 fb             	mov    %rdi,%rbx
    4df8:	48 83 ec 10          	sub    $0x10,%rsp
    4dfc:	48 8b 47 18          	mov    0x18(%rdi),%rax
    4e00:	48 85 c0             	test   %rax,%rax
    4e03:	0f 88 cf 00 00 00    	js     4ed8 <fwp_tape_buffers_release+0xe8>
    4e09:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    4e0d:	48 85 d2             	test   %rdx,%rdx
    4e10:	0f 88 c2 00 00 00    	js     4ed8 <fwp_tape_buffers_release+0xe8>
    4e16:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e1c:	0f 87 b6 00 00 00    	ja     4ed8 <fwp_tape_buffers_release+0xe8>
    4e22:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e26:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e2b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e2f:	48 29 c8             	sub    %rcx,%rax
    4e32:	48 c1 e8 03          	shr    $0x3,%rax
    4e36:	48 39 d0             	cmp    %rdx,%rax
    4e39:	0f 82 99 00 00 00    	jb     4ed8 <fwp_tape_buffers_release+0xe8>
    4e3f:	48 8d 3d 79 72 00 00 	lea    0x7279(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4e46:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e4b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e4f:	e8 2c e5 ff ff       	call   3380 <getenv@plt>
    4e54:	48 8b 14 24          	mov    (%rsp),%rdx
    4e58:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e5d:	48 85 c0             	test   %rax,%rax
    4e60:	74 09                	je     4e6b <fwp_tape_buffers_release+0x7b>
    4e62:	80 38 30             	cmpb   $0x30,(%rax)
    4e65:	0f 84 8d 00 00 00    	je     4ef8 <fwp_tape_buffers_release+0x108>
    4e6b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4e6f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4e73:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4e7a:	77 68                	ja     4ee4 <fwp_tape_buffers_release+0xf4>
    4e7c:	48 8d 3d 1d b2 01 00 	lea    0x1b21d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    4e83:	48 89 04 24          	mov    %rax,(%rsp)
    4e87:	e8 a4 f0 ff ff       	call   3f30 <fwp_tape_buffers_dispose>
    4e8c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4e90:	48 8b 04 24          	mov    (%rsp),%rax
    4e94:	0f 29 05 05 b2 01 00 	movaps %xmm0,0x1b205(%rip)        # 200a0 <fwp_tape_workspace>
    4e9b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ea0:	48 89 05 e1 b1 01 00 	mov    %rax,0x1b1e1(%rip)        # 20088 <fwp_tape_cached_bytes>
    4ea7:	0f 29 05 02 b2 01 00 	movaps %xmm0,0x1b202(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    4eae:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    4eb2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4eb6:	48 89 15 03 b2 01 00 	mov    %rdx,0x1b203(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    4ebd:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    4ec4:	00 
    4ec5:	0f 11 03             	movups %xmm0,(%rbx)
    4ec8:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4ecc:	48 83 c4 10          	add    $0x10,%rsp
    4ed0:	5b                   	pop    %rbx
    4ed1:	c3                   	ret
    4ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ed8:	48 8d 3d e0 71 00 00 	lea    0x71e0(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4edf:	e8 9c e4 ff ff       	call   3380 <getenv@plt>
    4ee4:	48 83 c4 10          	add    $0x10,%rsp
    4ee8:	48 89 df             	mov    %rbx,%rdi
    4eeb:	5b                   	pop    %rbx
    4eec:	e9 3f f0 ff ff       	jmp    3f30 <fwp_tape_buffers_dispose>
    4ef1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ef8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4efc:	0f 85 69 ff ff ff    	jne    4e6b <fwp_tape_buffers_release+0x7b>
    4f02:	48 83 c4 10          	add    $0x10,%rsp
    4f06:	48 89 df             	mov    %rbx,%rdi
    4f09:	5b                   	pop    %rbx
    4f0a:	e9 21 f0 ff ff       	jmp    3f30 <fwp_tape_buffers_dispose>
    4f0f:	90                   	nop

0000000000004f10 <fwp_poll_events>:
    4f10:	53                   	push   %rbx
    4f11:	48 83 ec 20          	sub    $0x20,%rsp
    4f15:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f1c:	00 00 
    4f1e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f23:	31 c0                	xor    %eax,%eax
    4f25:	e8 a6 f3 ff ff       	call   42d0 <fwp_now_ns>
    4f2a:	48 8b 1d c7 b7 01 00 	mov    0x1b7c7(%rip),%rbx        # 206f8 <fwp_timers>
    4f31:	48 85 db             	test   %rbx,%rbx
    4f34:	0f 84 e6 00 00 00    	je     5020 <fwp_poll_events+0x110>
    4f3a:	48 89 c6             	mov    %rax,%rsi
    4f3d:	48 89 da             	mov    %rbx,%rdx
    4f40:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f47:	eb 26                	jmp    4f6f <fwp_poll_events+0x5f>
    4f49:	90                   	nop
    4f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4f51:	00 00 00 00 
    4f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4f5c:	00 00 00 00 
    4f60:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f67:	48 89 c8             	mov    %rcx,%rax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 31                	je     4fa0 <fwp_poll_events+0x90>
    4f6f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4f73:	48 85 c0             	test   %rax,%rax
    4f76:	78 e8                	js     4f60 <fwp_poll_events+0x50>
    4f78:	48 39 c1             	cmp    %rax,%rcx
    4f7b:	7c e3                	jl     4f60 <fwp_poll_events+0x50>
    4f7d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f84:	48 85 d2             	test   %rdx,%rdx
    4f87:	74 1c                	je     4fa5 <fwp_poll_events+0x95>
    4f89:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4f8d:	48 39 c1             	cmp    %rax,%rcx
    4f90:	7c ce                	jl     4f60 <fwp_poll_events+0x50>
    4f92:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f99:	48 85 d2             	test   %rdx,%rdx
    4f9c:	75 d1                	jne    4f6f <fwp_poll_events+0x5f>
    4f9e:	66 90                	xchg   %ax,%ax
    4fa0:	48 85 c0             	test   %rax,%rax
    4fa3:	78 7b                	js     5020 <fwp_poll_events+0x110>
    4fa5:	48 29 f0             	sub    %rsi,%rax
    4fa8:	48 89 c1             	mov    %rax,%rcx
    4fab:	48 85 c0             	test   %rax,%rax
    4fae:	0f 8e 9c 00 00 00    	jle    5050 <fwp_poll_events+0x140>
    4fb4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4fbb:	de 1b 43 
    4fbe:	48 f7 ea             	imul   %rdx
    4fc1:	48 89 c8             	mov    %rcx,%rax
    4fc4:	48 c1 f8 3f          	sar    $0x3f,%rax
    4fc8:	48 c1 fa 12          	sar    $0x12,%rdx
    4fcc:	48 29 c2             	sub    %rax,%rdx
    4fcf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    4fd6:	48 39 c1             	cmp    %rax,%rcx
    4fd9:	0f 95 c0             	setne  %al
    4fdc:	0f b6 c0             	movzbl %al,%eax
    4fdf:	48 01 d0             	add    %rdx,%rax
    4fe2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    4fe8:	0f 8f 32 01 00 00    	jg     5120 <fwp_poll_events+0x210>
    4fee:	48 85 c0             	test   %rax,%rax
    4ff1:	74 5d                	je     5050 <fwp_poll_events+0x140>
    4ff3:	89 c1                	mov    %eax,%ecx
    4ff5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    4ffc:	48 c1 e9 26          	shr    $0x26,%rcx
    5000:	48 63 d1             	movslq %ecx,%rdx
    5003:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5009:	29 c8                	sub    %ecx,%eax
    500b:	48 98                	cltq
    500d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5014:	e9 11 01 00 00       	jmp    512a <fwp_poll_events+0x21a>
    5019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5020:	e8 0b ec ff ff       	call   3c30 <fwp_flush>
    5025:	ba 2b 00 00 00       	mov    $0x2b,%edx
    502a:	be 01 00 00 00       	mov    $0x1,%esi
    502f:	48 8b 0d 0a b0 00 00 	mov    0xb00a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5036:	48 8d 3d 0b 77 00 00 	lea    0x770b(%rip),%rdi        # c748 <_IO_stdin_used+0x748>
    503d:	e8 fe e5 ff ff       	call   3640 <fwrite@plt>
    5042:	bf 65 00 00 00       	mov    $0x65,%edi
    5047:	e8 e4 e5 ff ff       	call   3630 <exit@plt>
    504c:	0f 1f 40 00          	nopl   0x0(%rax)
    5050:	e8 7b f2 ff ff       	call   42d0 <fwp_now_ns>
    5055:	48 89 c1             	mov    %rax,%rcx
    5058:	66 0f ef c0          	pxor   %xmm0,%xmm0
    505c:	eb 44                	jmp    50a2 <fwp_poll_events+0x192>
    505e:	66 90                	xchg   %ax,%ax
    5060:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5064:	75 33                	jne    5099 <fwp_poll_events+0x189>
    5066:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    506a:	75 2d                	jne    5099 <fwp_poll_events+0x189>
    506c:	48 8b 05 8d b6 01 00 	mov    0x1b68d(%rip),%rax        # 20700 <fwp_ready_tail>
    5073:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5077:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    507e:	00 00 00 00 
    5082:	48 85 c0             	test   %rax,%rax
    5085:	0f 84 05 01 00 00    	je     5190 <fwp_poll_events+0x280>
    508b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5092:	48 89 15 67 b6 01 00 	mov    %rdx,0x1b667(%rip)        # 20700 <fwp_ready_tail>
    5099:	48 85 db             	test   %rbx,%rbx
    509c:	0f 84 be 00 00 00    	je     5160 <fwp_poll_events+0x250>
    50a2:	48 89 da             	mov    %rbx,%rdx
    50a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50b0:	7f e7                	jg     5099 <fwp_poll_events+0x189>
    50b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50b6:	74 2e                	je     50e6 <fwp_poll_events+0x1d6>
    50b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50bf:	48 85 c0             	test   %rax,%rax
    50c2:	0f 84 b8 00 00 00    	je     5180 <fwp_poll_events+0x270>
    50c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    50cf:	48 85 db             	test   %rbx,%rbx
    50d2:	74 07                	je     50db <fwp_poll_events+0x1cb>
    50d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    50db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    50df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    50e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    50ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    50ee:	48 85 c0             	test   %rax,%rax
    50f1:	0f 84 69 ff ff ff    	je     5060 <fwp_poll_events+0x150>
    50f7:	48 39 c8             	cmp    %rcx,%rax
    50fa:	0f 8f 60 ff ff ff    	jg     5060 <fwp_poll_events+0x150>
    5100:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5104:	0f 85 56 ff ff ff    	jne    5060 <fwp_poll_events+0x150>
    510a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510e:	75 89                	jne    5099 <fwp_poll_events+0x189>
    5110:	48 89 d7             	mov    %rdx,%rdi
    5113:	e8 58 ef ff ff       	call   4070 <fwp_cancel_tree.part.0>
    5118:	e9 43 ff ff ff       	jmp    5060 <fwp_poll_events+0x150>
    511d:	0f 1f 00             	nopl   (%rax)
    5120:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5125:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    512a:	48 89 e7             	mov    %rsp,%rdi
    512d:	31 f6                	xor    %esi,%esi
    512f:	48 89 14 24          	mov    %rdx,(%rsp)
    5133:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5138:	e8 43 e3 ff ff       	call   3480 <nanosleep@plt>
    513d:	48 8b 1d b4 b5 01 00 	mov    0x1b5b4(%rip),%rbx        # 206f8 <fwp_timers>
    5144:	e8 87 f1 ff ff       	call   42d0 <fwp_now_ns>
    5149:	48 89 c1             	mov    %rax,%rcx
    514c:	48 85 db             	test   %rbx,%rbx
    514f:	0f 85 03 ff ff ff    	jne    5058 <fwp_poll_events+0x148>
    5155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    515c:	00 00 00 00 
    5160:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5165:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    516c:	00 00 
    516e:	75 2c                	jne    519c <fwp_poll_events+0x28c>
    5170:	48 83 c4 20          	add    $0x20,%rsp
    5174:	5b                   	pop    %rbx
    5175:	c3                   	ret
    5176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    517d:	00 00 00 
    5180:	48 89 1d 71 b5 01 00 	mov    %rbx,0x1b571(%rip)        # 206f8 <fwp_timers>
    5187:	e9 43 ff ff ff       	jmp    50cf <fwp_poll_events+0x1bf>
    518c:	0f 1f 40 00          	nopl   0x0(%rax)
    5190:	48 89 15 71 b5 01 00 	mov    %rdx,0x1b571(%rip)        # 20708 <fwp_ready_head>
    5197:	e9 f6 fe ff ff       	jmp    5092 <fwp_poll_events+0x182>
    519c:	e8 9f e2 ff ff       	call   3440 <__stack_chk_fail@plt>
    51a1:	0f 1f 40 00          	nopl   0x0(%rax)
    51a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ac:	00 00 00 00 

00000000000051b0 <fwp_rc_wide_dup>:
    51b0:	48 89 fa             	mov    %rdi,%rdx
    51b3:	48 8d 35 86 b5 01 00 	lea    0x1b586(%rip),%rsi        # 20740 <fwp_heap>
    51ba:	48 83 ec 18          	sub    $0x18,%rsp
    51be:	48 89 f9             	mov    %rdi,%rcx
    51c1:	48 c1 ea 11          	shr    $0x11,%rdx
    51c5:	48 31 fa             	xor    %rdi,%rdx
    51c8:	48 89 d0             	mov    %rdx,%rax
    51cb:	48 c1 e8 09          	shr    $0x9,%rax
    51cf:	48 31 c2             	xor    %rax,%rdx
    51d2:	0f b6 d2             	movzbl %dl,%edx
    51d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    51dc:	00 
    51dd:	49 8b 00             	mov    (%r8),%rax
    51e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    51e7:	00 00 
    51e9:	75 21                	jne    520c <fwp_rc_wide_dup+0x5c>
    51eb:	e9 98 00 00 00       	jmp    5288 <fwp_rc_wide_dup+0xd8>
    51f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 2f                	je     5238 <fwp_rc_wide_dup+0x88>
    5209:	48 89 d0             	mov    %rdx,%rax
    520c:	48 3b 08             	cmp    (%rax),%rcx
    520f:	75 ef                	jne    5200 <fwp_rc_wide_dup+0x50>
    5211:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5214:	74 7c                	je     5292 <fwp_rc_wide_dup+0xe2>
    5216:	48 8b 50 08          	mov    0x8(%rax),%rdx
    521a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    521e:	0f 84 91 00 00 00    	je     52b5 <fwp_rc_wide_dup+0x105>
    5224:	48 83 c2 01          	add    $0x1,%rdx
    5228:	48 89 50 08          	mov    %rdx,0x8(%rax)
    522c:	48 83 c4 18          	add    $0x18,%rsp
    5230:	c3                   	ret
    5231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5238:	4c 8d 40 10          	lea    0x10(%rax),%r8
    523c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    523f:	75 68                	jne    52a9 <fwp_rc_wide_dup+0xf9>
    5241:	bf 18 00 00 00       	mov    $0x18,%edi
    5246:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    524b:	4c 89 04 24          	mov    %r8,(%rsp)
    524f:	e8 2c e3 ff ff       	call   3580 <malloc@plt>
    5254:	4c 8b 04 24          	mov    (%rsp),%r8
    5258:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    525d:	48 85 c0             	test   %rax,%rax
    5260:	74 5f                	je     52c1 <fwp_rc_wide_dup+0x111>
    5262:	48 89 08             	mov    %rcx,(%rax)
    5265:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    526c:	00 
    526d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5274:	00 
    5275:	49 89 00             	mov    %rax,(%r8)
    5278:	c6 01 ff             	movb   $0xff,(%rcx)
    527b:	48 83 05 05 d1 01 00 	addq   $0x1,0x1d105(%rip)        # 22388 <fwp_heap+0x1c48>
    5282:	01 
    5283:	48 83 c4 18          	add    $0x18,%rsp
    5287:	c3                   	ret
    5288:	80 3f fe             	cmpb   $0xfe,(%rdi)
    528b:	75 13                	jne    52a0 <fwp_rc_wide_dup+0xf0>
    528d:	48 85 c0             	test   %rax,%rax
    5290:	74 af                	je     5241 <fwp_rc_wide_dup+0x91>
    5292:	48 8d 3d df 74 00 00 	lea    0x74df(%rip),%rdi        # c778 <_IO_stdin_used+0x778>
    5299:	e8 c2 ee ff ff       	call   4160 <fwp_trap>
    529e:	66 90                	xchg   %ax,%ax
    52a0:	48 85 c0             	test   %rax,%rax
    52a3:	0f 85 6d ff ff ff    	jne    5216 <fwp_rc_wide_dup+0x66>
    52a9:	48 8d 3d f0 74 00 00 	lea    0x74f0(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    52b0:	e8 ab ee ff ff       	call   4160 <fwp_trap>
    52b5:	48 8d 3d 14 6e 00 00 	lea    0x6e14(%rip),%rdi        # c0d0 <_IO_stdin_used+0xd0>
    52bc:	e8 9f ee ff ff       	call   4160 <fwp_trap>
    52c1:	e8 aa e9 ff ff       	call   3c70 <fwp_heap_oom>
    52c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    52cd:	00 00 00 

00000000000052d0 <fwp_rc_forget_slot>:
    52d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    52d3:	74 0b                	je     52e0 <fwp_rc_forget_slot+0x10>
    52d5:	c3                   	ret
    52d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    52dd:	00 00 00 
    52e0:	48 89 f8             	mov    %rdi,%rax
    52e3:	48 83 ec 08          	sub    $0x8,%rsp
    52e7:	48 89 fa             	mov    %rdi,%rdx
    52ea:	48 c1 e8 11          	shr    $0x11,%rax
    52ee:	48 31 f8             	xor    %rdi,%rax
    52f1:	48 89 c1             	mov    %rax,%rcx
    52f4:	48 c1 e9 09          	shr    $0x9,%rcx
    52f8:	48 31 c8             	xor    %rcx,%rax
    52fb:	48 8d 0d 3e b4 01 00 	lea    0x1b43e(%rip),%rcx        # 20740 <fwp_heap>
    5302:	0f b6 c0             	movzbl %al,%eax
    5305:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    530c:	00 
    530d:	48 85 ff             	test   %rdi,%rdi
    5310:	74 3c                	je     534e <fwp_rc_forget_slot+0x7e>
    5312:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5319:	00 
    531a:	48 8b 01             	mov    (%rcx),%rax
    531d:	eb 11                	jmp    5330 <fwp_rc_forget_slot+0x60>
    531f:	90                   	nop
    5320:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5324:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5328:	48 85 ff             	test   %rdi,%rdi
    532b:	74 21                	je     534e <fwp_rc_forget_slot+0x7e>
    532d:	48 89 f8             	mov    %rdi,%rax
    5330:	48 3b 10             	cmp    (%rax),%rdx
    5333:	75 eb                	jne    5320 <fwp_rc_forget_slot+0x50>
    5335:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5339:	48 89 01             	mov    %rax,(%rcx)
    533c:	e8 5f e0 ff ff       	call   33a0 <free@plt>
    5341:	48 83 2d 3f d0 01 00 	subq   $0x1,0x1d03f(%rip)        # 22388 <fwp_heap+0x1c48>
    5348:	01 
    5349:	48 83 c4 08          	add    $0x8,%rsp
    534d:	c3                   	ret
    534e:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    5355:	e8 06 ee ff ff       	call   4160 <fwp_trap>
    535a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005360 <fwp_rc_prepare_chunk>:
    5360:	48 83 3d 20 d0 01 00 	cmpq   $0x0,0x1d020(%rip)        # 22388 <fwp_heap+0x1c48>
    5367:	00 
    5368:	41 54                	push   %r12
    536a:	49 89 f4             	mov    %rsi,%r12
    536d:	55                   	push   %rbp
    536e:	48 89 fd             	mov    %rdi,%rbp
    5371:	53                   	push   %rbx
    5372:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5375:	0f 84 7d 00 00 00    	je     53f8 <fwp_rc_prepare_chunk+0x98>
    537b:	31 db                	xor    %ebx,%ebx
    537d:	85 c0                	test   %eax,%eax
    537f:	75 5f                	jne    53e0 <fwp_rc_prepare_chunk+0x80>
    5381:	48 85 f6             	test   %rsi,%rsi
    5384:	74 7c                	je     5402 <fwp_rc_prepare_chunk+0xa2>
    5386:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    538a:	e8 11 e0 ff ff       	call   33a0 <free@plt>
    538f:	90                   	nop
    5390:	be 01 00 00 00       	mov    $0x1,%esi
    5395:	4c 89 e7             	mov    %r12,%rdi
    5398:	e8 63 e1 ff ff       	call   3500 <calloc@plt>
    539d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53a1:	48 85 c0             	test   %rax,%rax
    53a4:	0f 85 87 00 00 00    	jne    5431 <fwp_rc_prepare_chunk+0xd1>
    53aa:	e8 c1 e8 ff ff       	call   3c70 <fwp_heap_oom>
    53af:	90                   	nop
    53b0:	e8 1b ff ff ff       	call   52d0 <fwp_rc_forget_slot>
    53b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53b8:	48 83 c3 01          	add    $0x1,%rbx
    53bc:	48 39 c3             	cmp    %rax,%rbx
    53bf:	73 37                	jae    53f8 <fwp_rc_prepare_chunk+0x98>
    53c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53c8:	00 00 
    53ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53d1:	00 00 00 00 
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    53e4:	48 01 df             	add    %rbx,%rdi
    53e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    53ea:	74 c4                	je     53b0 <fwp_rc_prepare_chunk+0x50>
    53ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53ef:	48 83 c3 01          	add    $0x1,%rbx
    53f3:	48 39 c3             	cmp    %rax,%rbx
    53f6:	72 e8                	jb     53e0 <fwp_rc_prepare_chunk+0x80>
    53f8:	49 39 c4             	cmp    %rax,%r12
    53fb:	75 13                	jne    5410 <fwp_rc_prepare_chunk+0xb0>
    53fd:	4d 85 e4             	test   %r12,%r12
    5400:	75 46                	jne    5448 <fwp_rc_prepare_chunk+0xe8>
    5402:	5b                   	pop    %rbx
    5403:	5d                   	pop    %rbp
    5404:	41 5c                	pop    %r12
    5406:	c3                   	ret
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 
    5410:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5414:	48 29 05 75 cf 01 00 	sub    %rax,0x1cf75(%rip)        # 22390 <fwp_heap+0x1c50>
    541b:	e8 80 df ff ff       	call   33a0 <free@plt>
    5420:	4d 85 e4             	test   %r12,%r12
    5423:	0f 85 67 ff ff ff    	jne    5390 <fwp_rc_prepare_chunk+0x30>
    5429:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5430:	00 
    5431:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5435:	5b                   	pop    %rbx
    5436:	4c 01 25 53 cf 01 00 	add    %r12,0x1cf53(%rip)        # 22390 <fwp_heap+0x1c50>
    543d:	5d                   	pop    %rbp
    543e:	41 5c                	pop    %r12
    5440:	c3                   	ret
    5441:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5448:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    544c:	5b                   	pop    %rbx
    544d:	4c 89 e2             	mov    %r12,%rdx
    5450:	31 f6                	xor    %esi,%esi
    5452:	5d                   	pop    %rbp
    5453:	41 5c                	pop    %r12
    5455:	e9 46 e0 ff ff       	jmp    34a0 <memset@plt>
    545a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005460 <fwp_heap_refill>:
    5460:	41 56                	push   %r14
    5462:	41 89 d6             	mov    %edx,%r14d
    5465:	41 55                	push   %r13
    5467:	41 89 f5             	mov    %esi,%r13d
    546a:	41 54                	push   %r12
    546c:	49 89 fc             	mov    %rdi,%r12
    546f:	bf 01 00 00 00       	mov    $0x1,%edi
    5474:	55                   	push   %rbp
    5475:	53                   	push   %rbx
    5476:	e8 25 e9 ff ff       	call   3da0 <fwp_heap_chunks>
    547b:	48 89 c3             	mov    %rax,%rbx
    547e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5482:	48 8b 05 af c6 01 00 	mov    0x1c6af(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    5489:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    548d:	48 8d 05 ac b2 01 00 	lea    0x1b2ac(%rip),%rax        # 20740 <fwp_heap>
    5494:	31 d2                	xor    %edx,%edx
    5496:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    549a:	48 89 ef             	mov    %rbp,%rdi
    549d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ac:	00 
    54ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    54b2:	f7 f1                	div    %ecx
    54b4:	31 d2                	xor    %edx,%edx
    54b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54ba:	66 0f 6e c8          	movd   %eax,%xmm1
    54be:	89 c6                	mov    %eax,%esi
    54c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    54c5:	48 01 c8             	add    %rcx,%rax
    54c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    54cc:	48 f7 f1             	div    %rcx
    54cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    54d4:	89 45 18             	mov    %eax,0x18(%rbp)
    54d7:	e8 84 fe ff ff       	call   5360 <fwp_rc_prepare_chunk>
    54dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    54df:	48 89 d8             	mov    %rbx,%rax
    54e2:	48 c1 e0 10          	shl    $0x10,%rax
    54e6:	48 03 05 03 c6 01 00 	add    0x1c603(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    54ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    54f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    54f6:	8b 55 08             	mov    0x8(%rbp),%edx
    54f9:	48 0f af d1          	imul   %rcx,%rdx
    54fd:	48 01 c2             	add    %rax,%rdx
    5500:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5505:	5b                   	pop    %rbx
    5506:	5d                   	pop    %rbp
    5507:	41 5c                	pop    %r12
    5509:	41 5d                	pop    %r13
    550b:	41 5e                	pop    %r14
    550d:	c3                   	ret
    550e:	66 90                	xchg   %ax,%ax

0000000000005510 <fwp_mem_free>:
    5510:	48 85 ff             	test   %rdi,%rdi
    5513:	0f 84 17 02 00 00    	je     5730 <fwp_mem_free+0x220>
    5519:	48 8b 35 d0 c5 01 00 	mov    0x1c5d0(%rip),%rsi        # 21af0 <fwp_heap+0x13b0>
    5520:	48 8b 05 f1 c5 01 00 	mov    0x1c5f1(%rip),%rax        # 21b18 <fwp_heap+0x13d8>
    5527:	48 89 fa             	mov    %rdi,%rdx
    552a:	48 29 f2             	sub    %rsi,%rdx
    552d:	48 c1 e0 10          	shl    $0x10,%rax
    5531:	48 39 c2             	cmp    %rax,%rdx
    5534:	0f 83 f6 01 00 00    	jae    5730 <fwp_mem_free+0x220>
    553a:	49 89 d1             	mov    %rdx,%r9
    553d:	49 c1 e9 10          	shr    $0x10,%r9
    5541:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5545:	48 c1 e0 03          	shl    $0x3,%rax
    5549:	49 89 c0             	mov    %rax,%r8
    554c:	4c 03 05 e5 c5 01 00 	add    0x1c5e5(%rip),%r8        # 21b38 <fwp_heap+0x13f8>
    5553:	0f 84 d7 01 00 00    	je     5730 <fwp_mem_free+0x220>
    5559:	48 83 ec 38          	sub    $0x38,%rsp
    555d:	48 89 f9             	mov    %rdi,%rcx
    5560:	41 0f b6 38          	movzbl (%r8),%edi
    5564:	40 80 ff 01          	cmp    $0x1,%dil
    5568:	74 16                	je     5580 <fwp_mem_free+0x70>
    556a:	40 80 ff 02          	cmp    $0x2,%dil
    556e:	0f 84 94 00 00 00    	je     5608 <fwp_mem_free+0xf8>
    5574:	48 83 c4 38          	add    $0x38,%rsp
    5578:	c3                   	ret
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5584:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5589:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    558e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5592:	4d 85 d2             	test   %r10,%r10
    5595:	74 1d                	je     55b4 <fwp_mem_free+0xa4>
    5597:	0f b7 c1             	movzwl %cx,%eax
    559a:	31 d2                	xor    %edx,%edx
    559c:	48 f7 f7             	div    %rdi
    559f:	49 01 c2             	add    %rax,%r10
    55a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55a6:	0f 84 44 01 00 00    	je     56f0 <fwp_mem_free+0x1e0>
    55ac:	41 c6 02 00          	movb   $0x0,(%r10)
    55b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55bb:	49 63 c1             	movslq %r9d,%rax
    55be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    55c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    55cb:	f2 0f 58 05 ad c5 01 	addsd  0x1c5ad(%rip),%xmm0        # 21b80 <fwp_heap+0x1440>
    55d2:	00 
    55d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    55d7:	48 8d 05 62 b1 01 00 	lea    0x1b162(%rip),%rax        # 20740 <fwp_heap>
    55de:	48 01 d0             	add    %rdx,%rax
    55e1:	48 8b 10             	mov    (%rax),%rdx
    55e4:	48 f7 d2             	not    %rdx
    55e7:	48 89 11             	mov    %rdx,(%rcx)
    55ea:	48 89 08             	mov    %rcx,(%rax)
    55ed:	48 29 3d 6c c5 01 00 	sub    %rdi,0x1c56c(%rip)        # 21b60 <fwp_heap+0x1420>
    55f4:	f2 0f 11 05 84 c5 01 	movsd  %xmm0,0x1c584(%rip)        # 21b80 <fwp_heap+0x1440>
    55fb:	00 
    55fc:	48 83 c4 38          	add    $0x38,%rsp
    5600:	c3                   	ret
    5601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5608:	66 31 d2             	xor    %dx,%dx
    560b:	48 01 d6             	add    %rdx,%rsi
    560e:	48 39 f1             	cmp    %rsi,%rcx
    5611:	0f 85 5d ff ff ff    	jne    5574 <fwp_mem_free+0x64>
    5617:	49 8b 50 10          	mov    0x10(%r8),%rdx
    561b:	48 29 15 3e c5 01 00 	sub    %rdx,0x1c53e(%rip)        # 21b60 <fwp_heap+0x1420>
    5622:	48 85 d2             	test   %rdx,%rdx
    5625:	0f 88 a5 00 00 00    	js     56d0 <fwp_mem_free+0x1c0>
    562b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    562f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5634:	f2 0f 58 05 44 c5 01 	addsd  0x1c544(%rip),%xmm0        # 21b80 <fwp_heap+0x1440>
    563b:	00 
    563c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5640:	f2 0f 11 05 38 c5 01 	movsd  %xmm0,0x1c538(%rip)        # 21b80 <fwp_heap+0x1440>
    5647:	00 
    5648:	48 85 d2             	test   %rdx,%rdx
    564b:	74 0c                	je     5659 <fwp_mem_free+0x149>
    564d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5650:	0f 84 db 00 00 00    	je     5731 <fwp_mem_free+0x221>
    5656:	c6 02 00             	movb   $0x0,(%rdx)
    5659:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    565d:	48 85 c9             	test   %rcx,%rcx
    5660:	74 3e                	je     56a0 <fwp_mem_free+0x190>
    5662:	48 8b 15 cf c4 01 00 	mov    0x1c4cf(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    5669:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    566d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5671:	48 01 d0             	add    %rdx,%rax
    5674:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5678:	48 89 d6             	mov    %rdx,%rsi
    567b:	48 29 c6             	sub    %rax,%rsi
    567e:	83 e6 08             	and    $0x8,%esi
    5681:	74 0d                	je     5690 <fwp_mem_free+0x180>
    5683:	c6 00 00             	movb   $0x0,(%rax)
    5686:	48 83 c0 28          	add    $0x28,%rax
    568a:	48 39 c2             	cmp    %rax,%rdx
    568d:	74 11                	je     56a0 <fwp_mem_free+0x190>
    568f:	90                   	nop
    5690:	c6 00 00             	movb   $0x0,(%rax)
    5693:	48 83 c0 50          	add    $0x50,%rax
    5697:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    569b:	48 39 c2             	cmp    %rax,%rdx
    569e:	75 f0                	jne    5690 <fwp_mem_free+0x180>
    56a0:	48 01 0d c9 c4 01 00 	add    %rcx,0x1c4c9(%rip)        # 21b70 <fwp_heap+0x1430>
    56a7:	4c 3b 0d 82 c4 01 00 	cmp    0x1c482(%rip),%r9        # 21b30 <fwp_heap+0x13f0>
    56ae:	73 07                	jae    56b7 <fwp_mem_free+0x1a7>
    56b0:	4c 89 0d 79 c4 01 00 	mov    %r9,0x1c479(%rip)        # 21b30 <fwp_heap+0x13f0>
    56b7:	4c 3b 0d 6a c4 01 00 	cmp    0x1c46a(%rip),%r9        # 21b28 <fwp_heap+0x13e8>
    56be:	0f 83 b0 fe ff ff    	jae    5574 <fwp_mem_free+0x64>
    56c4:	4c 89 0d 5d c4 01 00 	mov    %r9,0x1c45d(%rip)        # 21b28 <fwp_heap+0x13e8>
    56cb:	e9 a4 fe ff ff       	jmp    5574 <fwp_mem_free+0x64>
    56d0:	48 89 d1             	mov    %rdx,%rcx
    56d3:	83 e2 01             	and    $0x1,%edx
    56d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56da:	48 d1 e9             	shr    $1,%rcx
    56dd:	48 09 d1             	or     %rdx,%rcx
    56e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    56e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    56e9:	e9 46 ff ff ff       	jmp    5634 <fwp_mem_free+0x124>
    56ee:	66 90                	xchg   %ax,%ax
    56f0:	4c 89 d7             	mov    %r10,%rdi
    56f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    56f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    56fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5702:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5706:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    570b:	e8 c0 fb ff ff       	call   52d0 <fwp_rc_forget_slot>
    5710:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5715:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    571a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    571f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5724:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5729:	e9 7e fe ff ff       	jmp    55ac <fwp_mem_free+0x9c>
    572e:	66 90                	xchg   %ax,%ax
    5730:	c3                   	ret
    5731:	48 89 d7             	mov    %rdx,%rdi
    5734:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5739:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    573e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5743:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5748:	e8 83 fb ff ff       	call   52d0 <fwp_rc_forget_slot>
    574d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5752:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5757:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    575c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5761:	e9 f0 fe ff ff       	jmp    5656 <fwp_mem_free+0x146>
    5766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    576d:	00 00 00 

0000000000005770 <fwp_heap_alloc_big>:
    5770:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5777:	00 00 40 
    577a:	41 57                	push   %r15
    577c:	41 56                	push   %r14
    577e:	41 55                	push   %r13
    5780:	41 54                	push   %r12
    5782:	55                   	push   %rbp
    5783:	53                   	push   %rbx
    5784:	48 83 ec 08          	sub    $0x8,%rsp
    5788:	48 39 f8             	cmp    %rdi,%rax
    578b:	0f 82 fa 00 00 00    	jb     588b <fwp_heap_alloc_big+0x11b>
    5791:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5798:	49 89 fd             	mov    %rdi,%r13
    579b:	41 89 f6             	mov    %esi,%r14d
    579e:	48 c1 ed 10          	shr    $0x10,%rbp
    57a2:	48 89 ef             	mov    %rbp,%rdi
    57a5:	e8 f6 e5 ff ff       	call   3da0 <fwp_heap_chunks>
    57aa:	be 01 00 00 00       	mov    $0x1,%esi
    57af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57b3:	49 89 c4             	mov    %rax,%r12
    57b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57bd:	00 
    57be:	48 03 3d 73 c3 01 00 	add    0x1c373(%rip),%rdi        # 21b38 <fwp_heap+0x13f8>
    57c5:	c6 07 02             	movb   $0x2,(%rdi)
    57c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    57cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    57cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    57d3:	e8 88 fb ff ff       	call   5360 <fwp_rc_prepare_chunk>
    57d8:	48 83 fd 01          	cmp    $0x1,%rbp
    57dc:	76 47                	jbe    5825 <fwp_heap_alloc_big+0xb5>
    57de:	4c 01 e5             	add    %r12,%rbp
    57e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    57e8:	00 
    57e9:	4c 8d 3d 50 af 01 00 	lea    0x1af50(%rip),%r15        # 20740 <fwp_heap>
    57f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    57f5:	49 c1 e6 03          	shl    $0x3,%r14
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5807:	31 f6                	xor    %esi,%esi
    5809:	48 01 dd             	add    %rbx,%rbp
    580c:	48 83 c3 28          	add    $0x28,%rbx
    5810:	48 89 ef             	mov    %rbp,%rdi
    5813:	e8 48 fb ff ff       	call   5360 <fwp_rc_prepare_chunk>
    5818:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    581c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5820:	49 39 de             	cmp    %rbx,%r14
    5823:	75 db                	jne    5800 <fwp_heap_alloc_big+0x90>
    5825:	49 c1 e4 10          	shl    $0x10,%r12
    5829:	4c 03 25 c0 c2 01 00 	add    0x1c2c0(%rip),%r12        # 21af0 <fwp_heap+0x13b0>
    5830:	4c 89 ea             	mov    %r13,%rdx
    5833:	31 f6                	xor    %esi,%esi
    5835:	4c 89 e7             	mov    %r12,%rdi
    5838:	e8 63 dc ff ff       	call   34a0 <memset@plt>
    583d:	4c 89 e8             	mov    %r13,%rax
    5840:	48 03 05 19 c3 01 00 	add    0x1c319(%rip),%rax        # 21b60 <fwp_heap+0x1420>
    5847:	72 42                	jb     588b <fwp_heap_alloc_big+0x11b>
    5849:	48 39 05 18 c3 01 00 	cmp    %rax,0x1c318(%rip)        # 21b68 <fwp_heap+0x1428>
    5850:	48 89 05 09 c3 01 00 	mov    %rax,0x1c309(%rip)        # 21b60 <fwp_heap+0x1420>
    5857:	73 07                	jae    5860 <fwp_heap_alloc_big+0xf0>
    5859:	48 89 05 08 c3 01 00 	mov    %rax,0x1c308(%rip)        # 21b68 <fwp_heap+0x1428>
    5860:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5864:	4c 89 e0             	mov    %r12,%rax
    5867:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    586c:	f2 0f 58 05 04 c3 01 	addsd  0x1c304(%rip),%xmm0        # 21b78 <fwp_heap+0x1438>
    5873:	00 
    5874:	f2 0f 11 05 fc c2 01 	movsd  %xmm0,0x1c2fc(%rip)        # 21b78 <fwp_heap+0x1438>
    587b:	00 
    587c:	48 83 c4 08          	add    $0x8,%rsp
    5880:	5b                   	pop    %rbx
    5881:	5d                   	pop    %rbp
    5882:	41 5c                	pop    %r12
    5884:	41 5d                	pop    %r13
    5886:	41 5e                	pop    %r14
    5888:	41 5f                	pop    %r15
    588a:	c3                   	ret
    588b:	e8 e0 e3 ff ff       	call   3c70 <fwp_heap_oom>

0000000000005890 <fwp_heap_alloc_slow>:
    5890:	53                   	push   %rbx
    5891:	48 89 f9             	mov    %rdi,%rcx
    5894:	41 89 f1             	mov    %esi,%r9d
    5897:	48 83 ec 10          	sub    $0x10,%rsp
    589b:	8b 05 43 c2 01 00    	mov    0x1c243(%rip),%eax        # 21ae4 <fwp_heap+0x13a4>
    58a1:	85 c0                	test   %eax,%eax
    58a3:	0f 84 c7 00 00 00    	je     5970 <fwp_heap_alloc_slow+0xe0>
    58a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58b0:	0f 87 dd 00 00 00    	ja     5993 <fwp_heap_alloc_slow+0x103>
    58b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58ba:	48 8d 3d 7f ae 01 00 	lea    0x1ae7f(%rip),%rdi        # 20740 <fwp_heap>
    58c1:	49 63 f1             	movslq %r9d,%rsi
    58c4:	48 c1 e8 04          	shr    $0x4,%rax
    58c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    58cf:	00 00 
    58d1:	41 0f b6 c2          	movzbl %r10b,%eax
    58d5:	4c 89 d2             	mov    %r10,%rdx
    58d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    58dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    58e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    58ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    58ee:	48 01 f8             	add    %rdi,%rax
    58f1:	4c 8b 00             	mov    (%rax),%r8
    58f4:	4d 85 c0             	test   %r8,%r8
    58f7:	0f 84 ab 00 00 00    	je     59a8 <fwp_heap_alloc_slow+0x118>
    58fd:	49 8b 10             	mov    (%r8),%rdx
    5900:	48 f7 d2             	not    %rdx
    5903:	48 89 10             	mov    %rdx,(%rax)
    5906:	41 83 f9 01          	cmp    $0x1,%r9d
    590a:	4c 89 c7             	mov    %r8,%rdi
    590d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5911:	31 f6                	xor    %esi,%esi
    5913:	48 89 ca             	mov    %rcx,%rdx
    5916:	e8 85 db ff ff       	call   34a0 <memset@plt>
    591b:	49 89 c0             	mov    %rax,%r8
    591e:	48 89 d8             	mov    %rbx,%rax
    5921:	48 03 05 38 c2 01 00 	add    0x1c238(%rip),%rax        # 21b60 <fwp_heap+0x1420>
    5928:	0f 82 d9 00 00 00    	jb     5a07 <fwp_heap_alloc_slow+0x177>
    592e:	48 39 05 33 c2 01 00 	cmp    %rax,0x1c233(%rip)        # 21b68 <fwp_heap+0x1428>
    5935:	48 89 05 24 c2 01 00 	mov    %rax,0x1c224(%rip)        # 21b60 <fwp_heap+0x1420>
    593c:	73 07                	jae    5945 <fwp_heap_alloc_slow+0xb5>
    593e:	48 89 05 23 c2 01 00 	mov    %rax,0x1c223(%rip)        # 21b68 <fwp_heap+0x1428>
    5945:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5949:	4c 89 c0             	mov    %r8,%rax
    594c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5951:	f2 0f 58 05 1f c2 01 	addsd  0x1c21f(%rip),%xmm0        # 21b78 <fwp_heap+0x1438>
    5958:	00 
    5959:	f2 0f 11 05 17 c2 01 	movsd  %xmm0,0x1c217(%rip)        # 21b78 <fwp_heap+0x1438>
    5960:	00 
    5961:	48 83 c4 10          	add    $0x10,%rsp
    5965:	5b                   	pop    %rbx
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5974:	48 89 3c 24          	mov    %rdi,(%rsp)
    5978:	e8 73 f1 ff ff       	call   4af0 <fwp_heap_init>
    597d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5981:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5986:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    598d:	0f 86 23 ff ff ff    	jbe    58b6 <fwp_heap_alloc_slow+0x26>
    5993:	48 83 c4 10          	add    $0x10,%rsp
    5997:	44 89 ce             	mov    %r9d,%esi
    599a:	48 89 cf             	mov    %rcx,%rdi
    599d:	5b                   	pop    %rbx
    599e:	e9 cd fd ff ff       	jmp    5770 <fwp_heap_alloc_big>
    59a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ac:	4d 85 c0             	test   %r8,%r8
    59af:	74 1f                	je     59d0 <fwp_heap_alloc_slow+0x140>
    59b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59b5:	4d 29 c3             	sub    %r8,%r11
    59b8:	49 39 db             	cmp    %rbx,%r11
    59bb:	72 13                	jb     59d0 <fwp_heap_alloc_slow+0x140>
    59bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    59c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    59c5:	e9 3c ff ff ff       	jmp    5906 <fwp_heap_alloc_slow+0x76>
    59ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    59d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    59d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    59db:	44 89 ca             	mov    %r9d,%edx
    59de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    59e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    59e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    59eb:	44 89 d6             	mov    %r10d,%esi
    59ee:	48 01 c7             	add    %rax,%rdi
    59f1:	e8 6a fa ff ff       	call   5460 <fwp_heap_refill>
    59f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    59fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    59ff:	49 89 c0             	mov    %rax,%r8
    5a02:	e9 ff fe ff ff       	jmp    5906 <fwp_heap_alloc_slow+0x76>
    5a07:	e8 64 e2 ff ff       	call   3c70 <fwp_heap_oom>
    5a0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a10 <fwp_heap_alloc>:
    5a10:	8b 05 ce c0 01 00    	mov    0x1c0ce(%rip),%eax        # 21ae4 <fwp_heap+0x13a4>
    5a16:	48 89 fa             	mov    %rdi,%rdx
    5a19:	89 f7                	mov    %esi,%edi
    5a1b:	85 c0                	test   %eax,%eax
    5a1d:	0f 84 f5 00 00 00    	je     5b18 <fwp_heap_alloc+0x108>
    5a23:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a2a:	0f 87 e8 00 00 00    	ja     5b18 <fwp_heap_alloc+0x108>
    5a30:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a34:	48 8d 05 05 ad 01 00 	lea    0x1ad05(%rip),%rax        # 20740 <fwp_heap>
    5a3b:	48 83 ec 18          	sub    $0x18,%rsp
    5a3f:	41 89 f0             	mov    %esi,%r8d
    5a42:	48 c1 e9 04          	shr    $0x4,%rcx
    5a46:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a4d:	00 
    5a4e:	48 63 cf             	movslq %edi,%rcx
    5a51:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a58:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a5f:	00 
    5a60:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5a64:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5a68:	48 01 c8             	add    %rcx,%rax
    5a6b:	48 8b 08             	mov    (%rax),%rcx
    5a6e:	48 85 c9             	test   %rcx,%rcx
    5a71:	74 6d                	je     5ae0 <fwp_heap_alloc+0xd0>
    5a73:	48 8b 31             	mov    (%rcx),%rsi
    5a76:	48 f7 d6             	not    %rsi
    5a79:	48 89 30             	mov    %rsi,(%rax)
    5a7c:	41 83 f8 01          	cmp    $0x1,%r8d
    5a80:	48 89 cf             	mov    %rcx,%rdi
    5a83:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5a88:	49 0f 45 d1          	cmovne %r9,%rdx
    5a8c:	31 f6                	xor    %esi,%esi
    5a8e:	e8 0d da ff ff       	call   34a0 <memset@plt>
    5a93:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5a98:	48 89 c1             	mov    %rax,%rcx
    5a9b:	4c 89 c8             	mov    %r9,%rax
    5a9e:	48 03 05 bb c0 01 00 	add    0x1c0bb(%rip),%rax        # 21b60 <fwp_heap+0x1420>
    5aa5:	72 7b                	jb     5b22 <fwp_heap_alloc+0x112>
    5aa7:	48 39 05 ba c0 01 00 	cmp    %rax,0x1c0ba(%rip)        # 21b68 <fwp_heap+0x1428>
    5aae:	48 89 05 ab c0 01 00 	mov    %rax,0x1c0ab(%rip)        # 21b60 <fwp_heap+0x1420>
    5ab5:	73 07                	jae    5abe <fwp_heap_alloc+0xae>
    5ab7:	48 89 05 aa c0 01 00 	mov    %rax,0x1c0aa(%rip)        # 21b68 <fwp_heap+0x1428>
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 89 c8             	mov    %rcx,%rax
    5ac5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5aca:	f2 0f 58 05 a6 c0 01 	addsd  0x1c0a6(%rip),%xmm0        # 21b78 <fwp_heap+0x1438>
    5ad1:	00 
    5ad2:	f2 0f 11 05 9e c0 01 	movsd  %xmm0,0x1c09e(%rip)        # 21b78 <fwp_heap+0x1438>
    5ad9:	00 
    5ada:	48 83 c4 18          	add    $0x18,%rsp
    5ade:	c3                   	ret
    5adf:	90                   	nop
    5ae0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5ae4:	48 85 c9             	test   %rcx,%rcx
    5ae7:	74 0c                	je     5af5 <fwp_heap_alloc+0xe5>
    5ae9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5aed:	48 29 ce             	sub    %rcx,%rsi
    5af0:	4c 39 ce             	cmp    %r9,%rsi
    5af3:	73 13                	jae    5b08 <fwp_heap_alloc+0xf8>
    5af5:	89 fe                	mov    %edi,%esi
    5af7:	48 83 c4 18          	add    $0x18,%rsp
    5afb:	48 89 d7             	mov    %rdx,%rdi
    5afe:	e9 8d fd ff ff       	jmp    5890 <fwp_heap_alloc_slow>
    5b03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b08:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b0c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b10:	e9 67 ff ff ff       	jmp    5a7c <fwp_heap_alloc+0x6c>
    5b15:	0f 1f 00             	nopl   (%rax)
    5b18:	89 fe                	mov    %edi,%esi
    5b1a:	48 89 d7             	mov    %rdx,%rdi
    5b1d:	e9 6e fd ff ff       	jmp    5890 <fwp_heap_alloc_slow>
    5b22:	e8 49 e1 ff ff       	call   3c70 <fwp_heap_oom>
    5b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b2e:	00 00 

0000000000005b30 <fwp_data.part.0.constprop.0>:
    5b30:	41 56                	push   %r14
    5b32:	41 89 fe             	mov    %edi,%r14d
    5b35:	41 54                	push   %r12
    5b37:	49 89 f4             	mov    %rsi,%r12
    5b3a:	55                   	push   %rbp
    5b3b:	53                   	push   %rbx
    5b3c:	48 83 ec 08          	sub    $0x8,%rsp
    5b40:	8b 05 9e bf 01 00    	mov    0x1bf9e(%rip),%eax        # 21ae4 <fwp_heap+0x13a4>
    5b46:	85 c0                	test   %eax,%eax
    5b48:	0f 84 fa 00 00 00    	je     5c48 <fwp_data.part.0.constprop.0+0x118>
    5b4e:	0f b6 05 8d bb 01 00 	movzbl 0x1bb8d(%rip),%eax        # 216e2 <fwp_heap+0xfa2>
    5b55:	48 8d 15 e4 ab 01 00 	lea    0x1abe4(%rip),%rdx        # 20740 <fwp_heap>
    5b5c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5b63:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b67:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5b6b:	48 8b 18             	mov    (%rax),%rbx
    5b6e:	48 85 db             	test   %rbx,%rbx
    5b71:	0f 84 a9 00 00 00    	je     5c20 <fwp_data.part.0.constprop.0+0xf0>
    5b77:	48 8b 13             	mov    (%rbx),%rdx
    5b7a:	48 f7 d2             	not    %rdx
    5b7d:	48 89 10             	mov    %rdx,(%rax)
    5b80:	48 83 fd 18          	cmp    $0x18,%rbp
    5b84:	76 1b                	jbe    5ba1 <fwp_data.part.0.constprop.0+0x71>
    5b86:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5b8a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5b8e:	31 f6                	xor    %esi,%esi
    5b90:	48 c1 e8 03          	shr    $0x3,%rax
    5b94:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5b9b:	00 
    5b9c:	e8 ff d8 ff ff       	call   34a0 <memset@plt>
    5ba1:	48 89 e8             	mov    %rbp,%rax
    5ba4:	48 03 05 b5 bf 01 00 	add    0x1bfb5(%rip),%rax        # 21b60 <fwp_heap+0x1420>
    5bab:	0f 82 a8 00 00 00    	jb     5c59 <fwp_data.part.0.constprop.0+0x129>
    5bb1:	48 39 05 b0 bf 01 00 	cmp    %rax,0x1bfb0(%rip)        # 21b68 <fwp_heap+0x1428>
    5bb8:	48 89 05 a1 bf 01 00 	mov    %rax,0x1bfa1(%rip)        # 21b60 <fwp_heap+0x1420>
    5bbf:	73 07                	jae    5bc8 <fwp_data.part.0.constprop.0+0x98>
    5bc1:	48 89 05 a0 bf 01 00 	mov    %rax,0x1bfa0(%rip)        # 21b68 <fwp_heap+0x1428>
    5bc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bcc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5bd1:	f2 0f 58 05 9f bf 01 	addsd  0x1bf9f(%rip),%xmm0        # 21b78 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 97 bf 01 	movsd  %xmm0,0x1bf97(%rip)        # 21b78 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	b8 02 00 00 00       	mov    $0x2,%eax
    5be6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5beb:	66 0f 6e c8          	movd   %eax,%xmm1
    5bef:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5bf3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5bf7:	49 8b 04 24          	mov    (%r12),%rax
    5bfb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5bff:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c04:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c08:	48 83 c4 08          	add    $0x8,%rsp
    5c0c:	48 89 d8             	mov    %rbx,%rax
    5c0f:	5b                   	pop    %rbx
    5c10:	5d                   	pop    %rbp
    5c11:	41 5c                	pop    %r12
    5c13:	41 5e                	pop    %r14
    5c15:	c3                   	ret
    5c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c1d:	00 00 00 
    5c20:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c24:	48 85 db             	test   %rbx,%rbx
    5c27:	74 1f                	je     5c48 <fwp_data.part.0.constprop.0+0x118>
    5c29:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c2d:	48 29 da             	sub    %rbx,%rdx
    5c30:	48 39 ea             	cmp    %rbp,%rdx
    5c33:	72 13                	jb     5c48 <fwp_data.part.0.constprop.0+0x118>
    5c35:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c3d:	e9 3e ff ff ff       	jmp    5b80 <fwp_data.part.0.constprop.0+0x50>
    5c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c48:	31 f6                	xor    %esi,%esi
    5c4a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c4f:	e8 bc fd ff ff       	call   5a10 <fwp_heap_alloc>
    5c54:	48 89 c3             	mov    %rax,%rbx
    5c57:	eb 88                	jmp    5be1 <fwp_data.part.0.constprop.0+0xb1>
    5c59:	e8 12 e0 ff ff       	call   3c70 <fwp_heap_oom>
    5c5e:	66 90                	xchg   %ax,%ax

0000000000005c60 <fwp_tape_grow.constprop.0>:
    5c60:	41 56                	push   %r14
    5c62:	b8 40 00 00 00       	mov    $0x40,%eax
    5c67:	41 55                	push   %r13
    5c69:	41 54                	push   %r12
    5c6b:	55                   	push   %rbp
    5c6c:	48 89 fd             	mov    %rdi,%rbp
    5c6f:	53                   	push   %rbx
    5c70:	48 83 ec 10          	sub    $0x10,%rsp
    5c74:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5c78:	48 85 db             	test   %rbx,%rbx
    5c7b:	48 0f 44 d8          	cmove  %rax,%rbx
    5c7f:	48 39 de             	cmp    %rbx,%rsi
    5c82:	7e 12                	jle    5c96 <fwp_tape_grow.constprop.0+0x36>
    5c84:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5c8b:	0f 8e df 00 00 00    	jle    5d70 <fwp_tape_grow.constprop.0+0x110>
    5c91:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5c96:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    5c9a:	4d 85 e4             	test   %r12,%r12
    5c9d:	0f 84 dd 00 00 00    	je     5d80 <fwp_tape_grow.constprop.0+0x120>
    5ca3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ca7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    5cae:	00 
    5caf:	e8 ec d8 ff ff       	call   35a0 <realloc@plt>
    5cb4:	48 85 c0             	test   %rax,%rax
    5cb7:	0f 84 eb 00 00 00    	je     5da8 <fwp_tape_grow.constprop.0+0x148>
    5cbd:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    5cc2:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5cc6:	48 39 da             	cmp    %rbx,%rdx
    5cc9:	0f 8d 8b 00 00 00    	jge    5d5a <fwp_tape_grow.constprop.0+0xfa>
    5ccf:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    5cd6:	ff ff 07 
    5cd9:	48 39 c3             	cmp    %rax,%rbx
    5cdc:	0f 8f ba 00 00 00    	jg     5d9c <fwp_tape_grow.constprop.0+0x13c>
    5ce2:	48 89 d9             	mov    %rbx,%rcx
    5ce5:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    5cea:	be 02 00 00 00       	mov    $0x2,%esi
    5cef:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5cf4:	48 c1 e1 04          	shl    $0x4,%rcx
    5cf8:	48 89 cf             	mov    %rcx,%rdi
    5cfb:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cff:	e8 0c fd ff ff       	call   5a10 <fwp_heap_alloc>
    5d04:	49 89 c5             	mov    %rax,%r13
    5d07:	4d 85 f6             	test   %r14,%r14
    5d0a:	74 27                	je     5d33 <fwp_tape_grow.constprop.0+0xd3>
    5d0c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d11:	48 8b 0c 24          	mov    (%rsp),%rcx
    5d15:	48 89 c7             	mov    %rax,%rdi
    5d18:	4c 89 f6             	mov    %r14,%rsi
    5d1b:	48 c1 e2 04          	shl    $0x4,%rdx
    5d1f:	48 39 ca             	cmp    %rcx,%rdx
    5d22:	48 0f 47 d1          	cmova  %rcx,%rdx
    5d26:	e8 45 d8 ff ff       	call   3570 <memcpy@plt>
    5d2b:	4c 89 f7             	mov    %r14,%rdi
    5d2e:	e8 dd f7 ff ff       	call   5510 <fwp_mem_free>
    5d33:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    5d38:	48 89 da             	mov    %rbx,%rdx
    5d3b:	31 f6                	xor    %esi,%esi
    5d3d:	48 29 fa             	sub    %rdi,%rdx
    5d40:	48 c1 e7 04          	shl    $0x4,%rdi
    5d44:	48 c1 e2 04          	shl    $0x4,%rdx
    5d48:	4c 01 ef             	add    %r13,%rdi
    5d4b:	e8 50 d7 ff ff       	call   34a0 <memset@plt>
    5d50:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    5d55:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    5d5a:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5d5e:	48 83 c4 10          	add    $0x10,%rsp
    5d62:	5b                   	pop    %rbx
    5d63:	5d                   	pop    %rbp
    5d64:	41 5c                	pop    %r12
    5d66:	41 5d                	pop    %r13
    5d68:	41 5e                	pop    %r14
    5d6a:	c3                   	ret
    5d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d70:	48 01 db             	add    %rbx,%rbx
    5d73:	e9 07 ff ff ff       	jmp    5c7f <fwp_tape_grow.constprop.0+0x1f>
    5d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5d7f:	00 
    5d80:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    5d84:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5d88:	48 c1 e6 03          	shl    $0x3,%rsi
    5d8c:	e8 0f d8 ff ff       	call   35a0 <realloc@plt>
    5d91:	48 85 c0             	test   %rax,%rax
    5d94:	74 12                	je     5da8 <fwp_tape_grow.constprop.0+0x148>
    5d96:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5d9a:	eb be                	jmp    5d5a <fwp_tape_grow.constprop.0+0xfa>
    5d9c:	48 8d 3d 46 63 00 00 	lea    0x6346(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    5da3:	e8 b8 e3 ff ff       	call   4160 <fwp_trap>
    5da8:	48 89 ef             	mov    %rbp,%rdi
    5dab:	e8 10 de ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    5db0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5db4:	e8 e7 d5 ff ff       	call   33a0 <free@plt>
    5db9:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5dbd:	e8 de d5 ff ff       	call   33a0 <free@plt>
    5dc2:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5dc6:	e8 d5 d5 ff ff       	call   33a0 <free@plt>
    5dcb:	31 c9                	xor    %ecx,%ecx
    5dcd:	31 c0                	xor    %eax,%eax
    5dcf:	31 d2                	xor    %edx,%edx
    5dd1:	89 55 04             	mov    %edx,0x4(%rbp)
    5dd4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dd8:	ba 13 00 00 00       	mov    $0x13,%edx
    5ddd:	be 01 00 00 00       	mov    $0x1,%esi
    5de2:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    5de6:	48 8d 3d 1b 62 00 00 	lea    0x621b(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    5ded:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5df1:	48 8b 0d 48 a2 00 00 	mov    0xa248(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5df8:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5dfc:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    5e00:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    5e04:	e8 37 d8 ff ff       	call   3640 <fwrite@plt>
    5e09:	31 ff                	xor    %edi,%edi
    5e0b:	e8 80 d7 ff ff       	call   3590 <fflush@plt>
    5e10:	bf 66 00 00 00       	mov    $0x66,%edi
    5e15:	e8 46 d8 ff ff       	call   3660 <_Exit@plt>
    5e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005e20 <w123>:
    5e20:	41 56                	push   %r14
    5e22:	55                   	push   %rbp
    5e23:	53                   	push   %rbx
    5e24:	48 83 ec 30          	sub    $0x30,%rsp
    5e28:	48 85 f7             	test   %rsi,%rdi
    5e2b:	0f 88 a7 01 00 00    	js     5fd8 <w123+0x1b8>
    5e31:	48 89 f8             	mov    %rdi,%rax
    5e34:	48 89 fb             	mov    %rdi,%rbx
    5e37:	48 89 f5             	mov    %rsi,%rbp
    5e3a:	48 09 f0             	or     %rsi,%rax
    5e3d:	0f 89 5d 01 00 00    	jns    5fa0 <w123+0x180>
    5e43:	48 85 ff             	test   %rdi,%rdi
    5e46:	0f 88 a4 01 00 00    	js     5ff0 <w123+0x1d0>
    5e4c:	48 89 d9             	mov    %rbx,%rcx
    5e4f:	4c 8b 35 da 6c 00 00 	mov    0x6cda(%rip),%r14        # cb30 <msg.4+0xb0>
    5e56:	48 c1 f9 20          	sar    $0x20,%rcx
    5e5a:	48 39 0a             	cmp    %rcx,(%rdx)
    5e5d:	0f 84 65 01 00 00    	je     5fc8 <w123+0x1a8>
    5e63:	48 89 cf             	mov    %rcx,%rdi
    5e66:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    5e6b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e70:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    5e76:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    5e7c:	e8 bf e5 ff ff       	call   4440 <fwp_tape_of>
    5e81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e86:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    5e8c:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    5e91:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    5e97:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    5e9c:	0f 85 7f 01 00 00    	jne    6021 <w123+0x201>
    5ea2:	48 89 0a             	mov    %rcx,(%rdx)
    5ea5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    5ea9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5ead:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    5eb4:	0f 8f 4f 01 00 00    	jg     6009 <w123+0x1e9>
    5eba:	89 da                	mov    %ebx,%edx
    5ebc:	48 39 d1             	cmp    %rdx,%rcx
    5ebf:	0f 8e 50 01 00 00    	jle    6015 <w123+0x1f5>
    5ec5:	48 85 ed             	test   %rbp,%rbp
    5ec8:	78 0b                	js     5ed5 <w123+0xb5>
    5eca:	89 ea                	mov    %ebp,%edx
    5ecc:	48 39 d1             	cmp    %rdx,%rcx
    5ecf:	0f 8e 40 01 00 00    	jle    6015 <w123+0x1f5>
    5ed5:	48 89 ca             	mov    %rcx,%rdx
    5ed8:	48 2b 50 08          	sub    0x8(%rax),%rdx
    5edc:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    5ee0:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5ee7:	0f 87 1c 01 00 00    	ja     6009 <w123+0x1e9>
    5eed:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    5ef1:	7e 3e                	jle    5f31 <w123+0x111>
    5ef3:	48 89 c7             	mov    %rax,%rdi
    5ef6:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    5efb:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    5f00:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5f05:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    5f0b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    5f11:	e8 4a fd ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    5f16:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    5f1c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    5f22:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    5f27:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    5f2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5f31:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    5f35:	48 8b 50 20          	mov    0x20(%rax),%rdx
    5f39:	48 85 ed             	test   %rbp,%rbp
    5f3c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    5f41:	48 8b 3d e8 6b 00 00 	mov    0x6be8(%rip),%rdi        # cb30 <msg.4+0xb0>
    5f48:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    5f4c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5f50:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    5f57:	48 0f 48 ee          	cmovs  %rsi,%rbp
    5f5b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    5f5f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    5f63:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    5f68:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    5f6c:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    5f70:	66 0f d6 12          	movq   %xmm2,(%rdx)
    5f74:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    5f78:	48 89 50 10          	mov    %rdx,0x10(%rax)
    5f7c:	48 83 c4 30          	add    $0x30,%rsp
    5f80:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f87:	ff ff ff 
    5f8a:	48 21 c3             	and    %rax,%rbx
    5f8d:	48 09 cb             	or     %rcx,%rbx
    5f90:	48 89 d8             	mov    %rbx,%rax
    5f93:	5b                   	pop    %rbx
    5f94:	5d                   	pop    %rbp
    5f95:	41 5e                	pop    %r14
    5f97:	c3                   	ret
    5f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5f9f:	00 
    5fa0:	48 89 f9             	mov    %rdi,%rcx
    5fa3:	48 89 f0             	mov    %rsi,%rax
    5fa6:	48 c1 f9 20          	sar    $0x20,%rcx
    5faa:	48 c1 f8 20          	sar    $0x20,%rax
    5fae:	48 39 c1             	cmp    %rax,%rcx
    5fb1:	0f 84 95 fe ff ff    	je     5e4c <w123+0x2c>
    5fb7:	48 8d 3d 0a 68 00 00 	lea    0x680a(%rip),%rdi        # c7c8 <_IO_stdin_used+0x7c8>
    5fbe:	e8 9d e1 ff ff       	call   4160 <fwp_trap>
    5fc3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fc8:	48 8b 42 08          	mov    0x8(%rdx),%rax
    5fcc:	e9 d8 fe ff ff       	jmp    5ea9 <w123+0x89>
    5fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fd8:	48 83 c4 30          	add    $0x30,%rsp
    5fdc:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    5fe3:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    5fe7:	48 89 d8             	mov    %rbx,%rax
    5fea:	5b                   	pop    %rbx
    5feb:	5d                   	pop    %rbp
    5fec:	41 5e                	pop    %r14
    5fee:	c3                   	ret
    5fef:	90                   	nop
    5ff0:	48 89 f1             	mov    %rsi,%rcx
    5ff3:	48 89 f3             	mov    %rsi,%rbx
    5ff6:	45 31 f6             	xor    %r14d,%r14d
    5ff9:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6000:	48 c1 f9 20          	sar    $0x20,%rcx
    6004:	e9 51 fe ff ff       	jmp    5e5a <w123+0x3a>
    6009:	48 8d 3d d9 60 00 00 	lea    0x60d9(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    6010:	e8 4b e1 ff ff       	call   4160 <fwp_trap>
    6015:	48 8d 3d e8 60 00 00 	lea    0x60e8(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    601c:	e8 3f e1 ff ff       	call   4160 <fwp_trap>
    6021:	48 8d 3d e8 67 00 00 	lea    0x67e8(%rip),%rdi        # c810 <_IO_stdin_used+0x810>
    6028:	e8 33 e1 ff ff       	call   4160 <fwp_trap>
    602d:	0f 1f 00             	nopl   (%rax)

0000000000006030 <w120>:
    6030:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6034:	41 57                	push   %r15
    6036:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    603a:	41 56                	push   %r14
    603c:	41 55                	push   %r13
    603e:	49 89 fd             	mov    %rdi,%r13
    6041:	41 54                	push   %r12
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	55                   	push   %rbp
    6047:	48 89 f5             	mov    %rsi,%rbp
    604a:	53                   	push   %rbx
    604b:	48 83 ec 48          	sub    $0x48,%rsp
    604f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6055:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    605a:	48 85 ff             	test   %rdi,%rdi
    605d:	0f 88 5d 06 00 00    	js     66c0 <w120+0x690>
    6063:	49 89 fe             	mov    %rdi,%r14
    6066:	49 c1 fe 20          	sar    $0x20,%r14
    606a:	4c 3b 32             	cmp    (%rdx),%r14
    606d:	0f 84 ed 05 00 00    	je     6660 <w120+0x630>
    6073:	4c 89 f7             	mov    %r14,%rdi
    6076:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    607c:	e8 bf e3 ff ff       	call   4440 <fwp_tape_of>
    6081:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6087:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    608c:	48 89 c3             	mov    %rax,%rbx
    608f:	0f 85 97 06 00 00    	jne    672c <w120+0x6fc>
    6095:	4d 89 34 24          	mov    %r14,(%r12)
    6099:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    609e:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    60a2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    60a9:	0f 8f 71 06 00 00    	jg     6720 <w120+0x6f0>
    60af:	44 89 e8             	mov    %r13d,%eax
    60b2:	49 39 c6             	cmp    %rax,%r14
    60b5:	0f 8e 4a 06 00 00    	jle    6705 <w120+0x6d5>
    60bb:	4c 89 f0             	mov    %r14,%rax
    60be:	48 2b 43 08          	sub    0x8(%rbx),%rax
    60c2:	48 8d 70 01          	lea    0x1(%rax),%rsi
    60c6:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    60cd:	0f 87 4d 06 00 00    	ja     6720 <w120+0x6f0>
    60d3:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    60d9:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    60dd:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    60e1:	0f 8f 61 04 00 00    	jg     6548 <w120+0x518>
    60e7:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    60eb:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    60f0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60f4:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    60f9:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    60fe:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6103:	49 8d 46 01          	lea    0x1(%r14),%rax
    6107:	48 89 43 10          	mov    %rax,0x10(%rbx)
    610b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6112:	ff ff ff 
    6115:	4c 21 eb             	and    %r13,%rbx
    6118:	4c 09 f3             	or     %r14,%rbx
    611b:	49 89 de             	mov    %rbx,%r14
    611e:	49 c1 fe 20          	sar    $0x20,%r14
    6122:	48 85 ed             	test   %rbp,%rbp
    6125:	78 10                	js     6137 <w120+0x107>
    6127:	48 89 e8             	mov    %rbp,%rax
    612a:	48 c1 f8 20          	sar    $0x20,%rax
    612e:	4c 39 f0             	cmp    %r14,%rax
    6131:	0f 85 da 05 00 00    	jne    6711 <w120+0x6e1>
    6137:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    613c:	66 0f 28 2d dc 69 00 	movapd 0x69dc(%rip),%xmm5        # cb20 <msg.4+0xa0>
    6143:	00 
    6144:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6149:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    614e:	4d 39 34 24          	cmp    %r14,(%r12)
    6152:	0f 84 18 05 00 00    	je     6670 <w120+0x640>
    6158:	4c 89 f7             	mov    %r14,%rdi
    615b:	e8 e0 e2 ff ff       	call   4440 <fwp_tape_of>
    6160:	48 89 c2             	mov    %rax,%rdx
    6163:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6168:	0f 85 be 05 00 00    	jne    672c <w120+0x6fc>
    616e:	4d 89 34 24          	mov    %r14,(%r12)
    6172:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6177:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    617b:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6182:	0f 8f 98 05 00 00    	jg     6720 <w120+0x6f0>
    6188:	89 d8                	mov    %ebx,%eax
    618a:	49 39 c6             	cmp    %rax,%r14
    618d:	0f 8e 72 05 00 00    	jle    6705 <w120+0x6d5>
    6193:	48 85 ed             	test   %rbp,%rbp
    6196:	78 0b                	js     61a3 <w120+0x173>
    6198:	89 e8                	mov    %ebp,%eax
    619a:	49 39 c6             	cmp    %rax,%r14
    619d:	0f 8e 62 05 00 00    	jle    6705 <w120+0x6d5>
    61a3:	4c 89 f0             	mov    %r14,%rax
    61a6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    61aa:	48 8d 70 01          	lea    0x1(%rax),%rsi
    61ae:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    61b5:	0f 87 65 05 00 00    	ja     6720 <w120+0x6f0>
    61bb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    61bf:	0f 8f bb 03 00 00    	jg     6580 <w120+0x550>
    61c5:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    61c9:	48 8b 42 20          	mov    0x20(%rdx),%rax
    61cd:	48 85 ed             	test   %rbp,%rbp
    61d0:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    61d6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    61db:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    61df:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61e6:	48 0f 49 c5          	cmovns %rbp,%rax
    61ea:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    61ee:	66 48 0f 6e d8       	movq   %rax,%xmm3
    61f3:	49 8d 46 01          	lea    0x1(%r14),%rax
    61f7:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    61fb:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    61ff:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6203:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6207:	4d 85 ed             	test   %r13,%r13
    620a:	0f 88 4b 05 00 00    	js     675b <w120+0x72b>
    6210:	4c 89 ea             	mov    %r13,%rdx
    6213:	48 c1 fa 20          	sar    $0x20,%rdx
    6217:	49 3b 14 24          	cmp    (%r12),%rdx
    621b:	0f 84 5f 04 00 00    	je     6680 <w120+0x650>
    6221:	48 89 d7             	mov    %rdx,%rdi
    6224:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6229:	e8 12 e2 ff ff       	call   4440 <fwp_tape_of>
    622e:	48 89 c5             	mov    %rax,%rbp
    6231:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6236:	0f 85 f0 04 00 00    	jne    672c <w120+0x6fc>
    623c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6241:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6246:	49 89 14 24          	mov    %rdx,(%r12)
    624a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    624e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6254:	0f 8f c6 04 00 00    	jg     6720 <w120+0x6f0>
    625a:	44 89 ea             	mov    %r13d,%edx
    625d:	48 39 d0             	cmp    %rdx,%rax
    6260:	0f 8e 9f 04 00 00    	jle    6705 <w120+0x6d5>
    6266:	48 89 c2             	mov    %rax,%rdx
    6269:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    626d:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6271:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6278:	0f 87 a2 04 00 00    	ja     6720 <w120+0x6f0>
    627e:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    6282:	0f 8f 20 03 00 00    	jg     65a8 <w120+0x578>
    6288:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    628d:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    6291:	66 0f 28 05 87 68 00 	movapd 0x6887(%rip),%xmm0        # cb20 <msg.4+0xa0>
    6298:	00 
    6299:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    629d:	66 0f 28 ee          	movapd %xmm6,%xmm5
    62a1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    62a5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    62a9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    62b0:	ff 
    62b1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    62b6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    62ba:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    62be:	4c 89 ed             	mov    %r13,%rbp
    62c1:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    62c8:	ff ff ff 
    62cb:	48 21 d5             	and    %rdx,%rbp
    62ce:	48 09 c5             	or     %rax,%rbp
    62d1:	66 49 0f 7e ef       	movq   %xmm5,%r15
    62d6:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    62dd:	ff ff ff 
    62e0:	48 21 c3             	and    %rax,%rbx
    62e3:	4c 09 f3             	or     %r14,%rbx
    62e6:	49 89 de             	mov    %rbx,%r14
    62e9:	49 c1 fe 20          	sar    $0x20,%r14
    62ed:	4d 3b 34 24          	cmp    (%r12),%r14
    62f1:	0f 84 99 03 00 00    	je     6690 <w120+0x660>
    62f7:	4c 89 f7             	mov    %r14,%rdi
    62fa:	e8 41 e1 ff ff       	call   4440 <fwp_tape_of>
    62ff:	49 89 c5             	mov    %rax,%r13
    6302:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6307:	0f 85 1f 04 00 00    	jne    672c <w120+0x6fc>
    630d:	4d 89 34 24          	mov    %r14,(%r12)
    6311:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6316:	4d 8b 75 10          	mov    0x10(%r13),%r14
    631a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6321:	0f 8f f9 03 00 00    	jg     6720 <w120+0x6f0>
    6327:	89 d8                	mov    %ebx,%eax
    6329:	49 39 c6             	cmp    %rax,%r14
    632c:	0f 8e d3 03 00 00    	jle    6705 <w120+0x6d5>
    6332:	4c 89 f0             	mov    %r14,%rax
    6335:	49 2b 45 08          	sub    0x8(%r13),%rax
    6339:	48 8d 70 01          	lea    0x1(%rax),%rsi
    633d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6344:	0f 87 d6 03 00 00    	ja     6720 <w120+0x6f0>
    634a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    634f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6353:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6357:	0f 8f 73 02 00 00    	jg     65d0 <w120+0x5a0>
    635d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    6361:	66 0f 6e eb          	movd   %ebx,%xmm5
    6365:	49 8b 45 20          	mov    0x20(%r13),%rax
    6369:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    636e:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    6373:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6378:	49 8d 46 01          	lea    0x1(%r14),%rax
    637c:	49 89 45 10          	mov    %rax,0x10(%r13)
    6380:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6387:	ff ff ff 
    638a:	48 21 c3             	and    %rax,%rbx
    638d:	4c 09 f3             	or     %r14,%rbx
    6390:	49 89 dd             	mov    %rbx,%r13
    6393:	49 c1 fd 20          	sar    $0x20,%r13
    6397:	4d 3b 2c 24          	cmp    (%r12),%r13
    639b:	0f 84 ff 02 00 00    	je     66a0 <w120+0x670>
    63a1:	4c 89 ef             	mov    %r13,%rdi
    63a4:	e8 97 e0 ff ff       	call   4440 <fwp_tape_of>
    63a9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    63ae:	0f 85 78 03 00 00    	jne    672c <w120+0x6fc>
    63b4:	4d 89 2c 24          	mov    %r13,(%r12)
    63b8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    63bd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    63c1:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    63c8:	0f 8f 52 03 00 00    	jg     6720 <w120+0x6f0>
    63ce:	89 da                	mov    %ebx,%edx
    63d0:	49 39 d5             	cmp    %rdx,%r13
    63d3:	0f 8e 2c 03 00 00    	jle    6705 <w120+0x6d5>
    63d9:	4d 89 ee             	mov    %r13,%r14
    63dc:	4c 2b 70 08          	sub    0x8(%rax),%r14
    63e0:	49 8d 76 01          	lea    0x1(%r14),%rsi
    63e4:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    63eb:	0f 87 2f 03 00 00    	ja     6720 <w120+0x6f0>
    63f1:	f2 0f 10 15 37 67 00 	movsd  0x6737(%rip),%xmm2        # cb30 <msg.4+0xb0>
    63f8:	00 
    63f9:	66 49 0f 6e cf       	movq   %r15,%xmm1
    63fe:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6404:	f2 0f 59 0d 34 67 00 	mulsd  0x6734(%rip),%xmm1        # cb40 <msg.4+0xc0>
    640b:	00 
    640c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6410:	0f 8f da 01 00 00    	jg     65f0 <w120+0x5c0>
    6416:	48 8b 50 20          	mov    0x20(%rax),%rdx
    641a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    641e:	f3 0f 7e 05 1a 67 00 	movq   0x671a(%rip),%xmm0        # cb40 <msg.4+0xc0>
    6425:	00 
    6426:	48 89 ef             	mov    %rbp,%rdi
    6429:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    642c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6431:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6435:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    643c:	ff 
    643d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6441:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6445:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6449:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6450:	ff ff ff 
    6453:	48 21 c3             	and    %rax,%rbx
    6456:	4c 09 eb             	or     %r13,%rbx
    6459:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    645d:	0f 84 c8 00 00 00    	je     652b <w120+0x4fb>
    6463:	49 89 ed             	mov    %rbp,%r13
    6466:	49 c1 fd 20          	sar    $0x20,%r13
    646a:	4d 39 2c 24          	cmp    %r13,(%r12)
    646e:	0f 84 3c 02 00 00    	je     66b0 <w120+0x680>
    6474:	4c 89 ef             	mov    %r13,%rdi
    6477:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    647d:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6482:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    6488:	e8 b3 df ff ff       	call   4440 <fwp_tape_of>
    648d:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6492:	0f 85 94 02 00 00    	jne    672c <w120+0x6fc>
    6498:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    649e:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    64a3:	4d 89 2c 24          	mov    %r13,(%r12)
    64a7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    64ac:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    64b2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    64b6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    64bd:	0f 8f 5d 02 00 00    	jg     6720 <w120+0x6f0>
    64c3:	89 e9                	mov    %ebp,%ecx
    64c5:	4c 39 f1             	cmp    %r14,%rcx
    64c8:	0f 8d 37 02 00 00    	jge    6705 <w120+0x6d5>
    64ce:	4d 89 f5             	mov    %r14,%r13
    64d1:	4c 2b 68 08          	sub    0x8(%rax),%r13
    64d5:	49 8d 75 01          	lea    0x1(%r13),%rsi
    64d9:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    64e0:	0f 87 3a 02 00 00    	ja     6720 <w120+0x6f0>
    64e6:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    64ea:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    64ee:	0f 8f 2c 01 00 00    	jg     6620 <w120+0x5f0>
    64f4:	48 8b 48 20          	mov    0x20(%rax),%rcx
    64f8:	66 0f 6e dd          	movd   %ebp,%xmm3
    64fc:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6501:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6508:	ff ff ff 
    650b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6510:	48 21 d5             	and    %rdx,%rbp
    6513:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6518:	48 89 ef             	mov    %rbp,%rdi
    651b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6520:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6524:	4c 09 f7             	or     %r14,%rdi
    6527:	48 89 48 10          	mov    %rcx,0x10(%rax)
    652b:	4c 89 e2             	mov    %r12,%rdx
    652e:	48 89 de             	mov    %rbx,%rsi
    6531:	e8 ea f8 ff ff       	call   5e20 <w123>
    6536:	48 83 c4 48          	add    $0x48,%rsp
    653a:	5b                   	pop    %rbx
    653b:	5d                   	pop    %rbp
    653c:	41 5c                	pop    %r12
    653e:	41 5d                	pop    %r13
    6540:	41 5e                	pop    %r14
    6542:	41 5f                	pop    %r15
    6544:	c3                   	ret
    6545:	0f 1f 00             	nopl   (%rax)
    6548:	48 89 df             	mov    %rbx,%rdi
    654b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6550:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6556:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    655b:	e8 00 f7 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6560:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    6566:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    656c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6571:	e9 71 fb ff ff       	jmp    60e7 <w120+0xb7>
    6576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    657d:	00 00 00 
    6580:	48 89 d7             	mov    %rdx,%rdi
    6583:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6588:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    658d:	e8 ce f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6592:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6597:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    659c:	e9 24 fc ff ff       	jmp    61c5 <w120+0x195>
    65a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65a8:	48 89 ef             	mov    %rbp,%rdi
    65ab:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    65b0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    65b5:	e8 a6 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    65ba:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    65bf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    65c4:	e9 bf fc ff ff       	jmp    6288 <w120+0x258>
    65c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65d0:	4c 89 ef             	mov    %r13,%rdi
    65d3:	48 89 04 24          	mov    %rax,(%rsp)
    65d7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    65dc:	e8 7f f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    65e1:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    65e7:	48 8b 04 24          	mov    (%rsp),%rax
    65eb:	e9 6d fd ff ff       	jmp    635d <w120+0x32d>
    65f0:	48 89 c7             	mov    %rax,%rdi
    65f3:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    65f8:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    65fe:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6603:	e8 58 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6608:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    660e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6613:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6618:	e9 f9 fd ff ff       	jmp    6416 <w120+0x3e6>
    661d:	0f 1f 00             	nopl   (%rax)
    6620:	48 89 c7             	mov    %rax,%rdi
    6623:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6628:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    662e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6634:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6638:	e8 23 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    663d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6643:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6649:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    664e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6653:	e9 9c fe ff ff       	jmp    64f4 <w120+0x4c4>
    6658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    665f:	00 
    6660:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    6664:	e9 35 fa ff ff       	jmp    609e <w120+0x6e>
    6669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6670:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    6675:	e9 fd fa ff ff       	jmp    6177 <w120+0x147>
    667a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6680:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    6685:	e9 c0 fb ff ff       	jmp    624a <w120+0x21a>
    668a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6690:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6695:	e9 7c fc ff ff       	jmp    6316 <w120+0x2e6>
    669a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66a0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66a5:	e9 13 fd ff ff       	jmp    63bd <w120+0x38d>
    66aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66b0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66b5:	e9 f8 fd ff ff       	jmp    64b2 <w120+0x482>
    66ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66c0:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    66c5:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    66ca:	48 85 f6             	test   %rsi,%rsi
    66cd:	79 69                	jns    6738 <w120+0x708>
    66cf:	f2 0f 10 05 59 64 00 	movsd  0x6459(%rip),%xmm0        # cb30 <msg.4+0xb0>
    66d6:	00 
    66d7:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    66dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66e3:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    66ea:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    66f0:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    66f4:	f2 0f 59 0d 44 64 00 	mulsd  0x6444(%rip),%xmm1        # cb40 <msg.4+0xc0>
    66fb:	00 
    66fc:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6700:	e9 26 fe ff ff       	jmp    652b <w120+0x4fb>
    6705:	48 8d 3d f8 59 00 00 	lea    0x59f8(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    670c:	e8 4f da ff ff       	call   4160 <fwp_trap>
    6711:	48 8d 3d b0 60 00 00 	lea    0x60b0(%rip),%rdi        # c7c8 <_IO_stdin_used+0x7c8>
    6718:	e8 43 da ff ff       	call   4160 <fwp_trap>
    671d:	0f 1f 00             	nopl   (%rax)
    6720:	48 8d 3d c2 59 00 00 	lea    0x59c2(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    6727:	e8 34 da ff ff       	call   4160 <fwp_trap>
    672c:	48 8d 3d dd 60 00 00 	lea    0x60dd(%rip),%rdi        # c810 <_IO_stdin_used+0x810>
    6733:	e8 28 da ff ff       	call   4160 <fwp_trap>
    6738:	49 89 f6             	mov    %rsi,%r14
    673b:	f3 0f 7e 3d ed 63 00 	movq   0x63ed(%rip),%xmm7        # cb30 <msg.4+0xb0>
    6742:	00 
    6743:	48 89 f3             	mov    %rsi,%rbx
    6746:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    674b:	49 c1 fe 20          	sar    $0x20,%r14
    674f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6756:	e9 f3 f9 ff ff       	jmp    614e <w120+0x11e>
    675b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    6760:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    6765:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    676c:	66 49 0f 7e ff       	movq   %xmm7,%r15
    6771:	e9 60 fb ff ff       	jmp    62d6 <w120+0x2a6>
    6776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    677d:	00 00 00 

0000000000006780 <w176.constprop.0>:
    6780:	41 55                	push   %r13
    6782:	41 54                	push   %r12
    6784:	55                   	push   %rbp
    6785:	53                   	push   %rbx
    6786:	48 83 ec 28          	sub    $0x28,%rsp
    678a:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    6791:	00 00 
    6793:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    6798:	48 8b 2f             	mov    (%rdi),%rbp
    679b:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    67a2:	ff 
    67a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    67aa:	00 00 
    67ac:	48 85 ed             	test   %rbp,%rbp
    67af:	74 5f                	je     6810 <w176.constprop.0+0x90>
    67b1:	49 89 fd             	mov    %rdi,%r13
    67b4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67b8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67bf:	31 db                	xor    %ebx,%ebx
    67c1:	0f 1f 40 00          	nopl   0x0(%rax)
    67c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67cc:	00 00 00 00 
    67d0:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    67d5:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    67dc:	48 89 e2             	mov    %rsp,%rdx
    67df:	48 83 c3 02          	add    $0x2,%rbx
    67e3:	e8 38 f6 ff ff       	call   5e20 <w123>
    67e8:	48 89 c7             	mov    %rax,%rdi
    67eb:	48 39 eb             	cmp    %rbp,%rbx
    67ee:	72 e0                	jb     67d0 <w176.constprop.0+0x50>
    67f0:	48 89 f8             	mov    %rdi,%rax
    67f3:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    67f8:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    67ff:	00 00 
    6801:	75 1a                	jne    681d <w176.constprop.0+0x9d>
    6803:	48 83 c4 28          	add    $0x28,%rsp
    6807:	5b                   	pop    %rbx
    6808:	5d                   	pop    %rbp
    6809:	41 5c                	pop    %r12
    680b:	41 5d                	pop    %r13
    680d:	c3                   	ret
    680e:	66 90                	xchg   %ax,%ax
    6810:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6817:	66 0f ef c0          	pxor   %xmm0,%xmm0
    681b:	eb d3                	jmp    67f0 <w176.constprop.0+0x70>
    681d:	e8 1e cc ff ff       	call   3440 <__stack_chk_fail@plt>
    6822:	0f 1f 00             	nopl   (%rax)
    6825:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    682c:	00 00 00 00 

0000000000006830 <fwp_rc_share>:
    6830:	48 8b 05 e1 b2 01 00 	mov    0x1b2e1(%rip),%rax        # 21b18 <fwp_heap+0x13d8>
    6837:	48 2b 3d b2 b2 01 00 	sub    0x1b2b2(%rip),%rdi        # 21af0 <fwp_heap+0x13b0>
    683e:	48 c1 e0 10          	shl    $0x10,%rax
    6842:	48 39 c7             	cmp    %rax,%rdi
    6845:	73 4a                	jae    6891 <fwp_rc_share+0x61>
    6847:	48 89 f8             	mov    %rdi,%rax
    684a:	48 c1 e8 10          	shr    $0x10,%rax
    684e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6852:	48 8b 05 df b2 01 00 	mov    0x1b2df(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    6859:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    685d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6861:	48 85 d2             	test   %rdx,%rdx
    6864:	74 2b                	je     6891 <fwp_rc_share+0x61>
    6866:	0f b6 08             	movzbl (%rax),%ecx
    6869:	80 f9 02             	cmp    $0x2,%cl
    686c:	74 2a                	je     6898 <fwp_rc_share+0x68>
    686e:	80 f9 01             	cmp    $0x1,%cl
    6871:	75 1e                	jne    6891 <fwp_rc_share+0x61>
    6873:	8b 48 18             	mov    0x18(%rax),%ecx
    6876:	0f b7 ff             	movzwl %di,%edi
    6879:	8b 40 1c             	mov    0x1c(%rax),%eax
    687c:	48 0f af f9          	imul   %rcx,%rdi
    6880:	48 c1 ef 20          	shr    $0x20,%rdi
    6884:	48 39 c7             	cmp    %rax,%rdi
    6887:	73 08                	jae    6891 <fwp_rc_share+0x61>
    6889:	48 01 fa             	add    %rdi,%rdx
    688c:	80 3a 00             	cmpb   $0x0,(%rdx)
    688f:	75 0d                	jne    689e <fwp_rc_share+0x6e>
    6891:	c3                   	ret
    6892:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6898:	66 85 ff             	test   %di,%di
    689b:	74 ef                	je     688c <fwp_rc_share+0x5c>
    689d:	c3                   	ret
    689e:	50                   	push   %rax
    689f:	48 8d 3d 9a 5f 00 00 	lea    0x5f9a(%rip),%rdi        # c840 <_IO_stdin_used+0x840>
    68a6:	e8 b5 d8 ff ff       	call   4160 <fwp_trap>
    68ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068b0 <fwp_rc_free_obj>:
    68b0:	48 8b 15 61 b2 01 00 	mov    0x1b261(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    68b7:	48 89 f8             	mov    %rdi,%rax
    68ba:	48 2b 05 2f b2 01 00 	sub    0x1b22f(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    68c1:	48 c1 e2 10          	shl    $0x10,%rdx
    68c5:	48 39 d0             	cmp    %rdx,%rax
    68c8:	73 5b                	jae    6925 <fwp_rc_free_obj+0x75>
    68ca:	48 89 c2             	mov    %rax,%rdx
    68cd:	48 c1 ea 10          	shr    $0x10,%rdx
    68d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68d5:	48 8b 15 5c b2 01 00 	mov    0x1b25c(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    68dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    68e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    68e4:	48 85 c9             	test   %rcx,%rcx
    68e7:	74 3c                	je     6925 <fwp_rc_free_obj+0x75>
    68e9:	0f b6 32             	movzbl (%rdx),%esi
    68ec:	40 80 fe 02          	cmp    $0x2,%sil
    68f0:	74 2e                	je     6920 <fwp_rc_free_obj+0x70>
    68f2:	40 80 fe 01          	cmp    $0x1,%sil
    68f6:	75 2d                	jne    6925 <fwp_rc_free_obj+0x75>
    68f8:	8b 72 18             	mov    0x18(%rdx),%esi
    68fb:	0f b7 c0             	movzwl %ax,%eax
    68fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6901:	48 0f af c6          	imul   %rsi,%rax
    6905:	48 c1 e8 20          	shr    $0x20,%rax
    6909:	48 39 d0             	cmp    %rdx,%rax
    690c:	73 17                	jae    6925 <fwp_rc_free_obj+0x75>
    690e:	48 01 c1             	add    %rax,%rcx
    6911:	80 39 01             	cmpb   $0x1,(%rcx)
    6914:	75 0f                	jne    6925 <fwp_rc_free_obj+0x75>
    6916:	e9 f5 eb ff ff       	jmp    5510 <fwp_mem_free>
    691b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6920:	66 85 c0             	test   %ax,%ax
    6923:	74 ec                	je     6911 <fwp_rc_free_obj+0x61>
    6925:	c3                   	ret
    6926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    692d:	00 00 00 

0000000000006930 <fwp_rc_dup>:
    6930:	f3 0f 1e fa          	endbr64
    6934:	48 8b 05 dd b1 01 00 	mov    0x1b1dd(%rip),%rax        # 21b18 <fwp_heap+0x13d8>
    693b:	48 2b 3d ae b1 01 00 	sub    0x1b1ae(%rip),%rdi        # 21af0 <fwp_heap+0x13b0>
    6942:	48 c1 e0 10          	shl    $0x10,%rax
    6946:	48 39 c7             	cmp    %rax,%rdi
    6949:	73 56                	jae    69a1 <fwp_rc_dup+0x71>
    694b:	48 89 f8             	mov    %rdi,%rax
    694e:	48 c1 e8 10          	shr    $0x10,%rax
    6952:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6956:	48 8b 05 db b1 01 00 	mov    0x1b1db(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    695d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6961:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6965:	48 85 c0             	test   %rax,%rax
    6968:	74 37                	je     69a1 <fwp_rc_dup+0x71>
    696a:	0f b6 0a             	movzbl (%rdx),%ecx
    696d:	80 f9 02             	cmp    $0x2,%cl
    6970:	74 36                	je     69a8 <fwp_rc_dup+0x78>
    6972:	80 f9 01             	cmp    $0x1,%cl
    6975:	75 2a                	jne    69a1 <fwp_rc_dup+0x71>
    6977:	8b 4a 18             	mov    0x18(%rdx),%ecx
    697a:	0f b7 ff             	movzwl %di,%edi
    697d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6980:	48 0f af f9          	imul   %rcx,%rdi
    6984:	48 c1 ef 20          	shr    $0x20,%rdi
    6988:	48 39 d7             	cmp    %rdx,%rdi
    698b:	73 14                	jae    69a1 <fwp_rc_dup+0x71>
    698d:	48 01 f8             	add    %rdi,%rax
    6990:	0f b6 10             	movzbl (%rax),%edx
    6993:	84 d2                	test   %dl,%dl
    6995:	74 0a                	je     69a1 <fwp_rc_dup+0x71>
    6997:	80 fa fd             	cmp    $0xfd,%dl
    699a:	77 14                	ja     69b0 <fwp_rc_dup+0x80>
    699c:	83 c2 01             	add    $0x1,%edx
    699f:	88 10                	mov    %dl,(%rax)
    69a1:	c3                   	ret
    69a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69a8:	66 85 ff             	test   %di,%di
    69ab:	74 e3                	je     6990 <fwp_rc_dup+0x60>
    69ad:	c3                   	ret
    69ae:	66 90                	xchg   %ax,%ax
    69b0:	48 89 c7             	mov    %rax,%rdi
    69b3:	e9 f8 e7 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    69b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69bf:	00 

00000000000069c0 <fwp_owned_entry173>:
    69c0:	f3 0f 1e fa          	endbr64
    69c4:	48 83 ec 38          	sub    $0x38,%rsp
    69c8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    69cd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    69d4:	00 00 
    69d6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    69db:	31 c0                	xor    %eax,%eax
    69dd:	48 8b 07             	mov    (%rdi),%rax
    69e0:	48 03 47 10          	add    0x10(%rdi),%rax
    69e4:	0f 80 c2 00 00 00    	jo     6aac <fwp_owned_entry173+0xec>
    69ea:	66 48 0f 6e c8       	movq   %rax,%xmm1
    69ef:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    69f4:	31 ff                	xor    %edi,%edi
    69f6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    69fa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    69ff:	e8 2c f1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    6a04:	48 8b 15 0d b1 01 00 	mov    0x1b10d(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    6a0b:	48 89 c6             	mov    %rax,%rsi
    6a0e:	48 2b 05 db b0 01 00 	sub    0x1b0db(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    6a15:	48 c1 e2 10          	shl    $0x10,%rdx
    6a19:	48 39 d0             	cmp    %rdx,%rax
    6a1c:	73 4f                	jae    6a6d <fwp_owned_entry173+0xad>
    6a1e:	48 89 c2             	mov    %rax,%rdx
    6a21:	48 c1 ea 10          	shr    $0x10,%rdx
    6a25:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a29:	48 8b 15 08 b1 01 00 	mov    0x1b108(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    6a30:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a34:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a38:	48 85 d2             	test   %rdx,%rdx
    6a3b:	74 30                	je     6a6d <fwp_owned_entry173+0xad>
    6a3d:	0f b6 39             	movzbl (%rcx),%edi
    6a40:	40 80 ff 02          	cmp    $0x2,%dil
    6a44:	74 42                	je     6a88 <fwp_owned_entry173+0xc8>
    6a46:	40 80 ff 01          	cmp    $0x1,%dil
    6a4a:	75 21                	jne    6a6d <fwp_owned_entry173+0xad>
    6a4c:	8b 79 18             	mov    0x18(%rcx),%edi
    6a4f:	0f b7 c0             	movzwl %ax,%eax
    6a52:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a55:	48 0f af c7          	imul   %rdi,%rax
    6a59:	48 c1 e8 20          	shr    $0x20,%rax
    6a5d:	48 39 c8             	cmp    %rcx,%rax
    6a60:	73 0b                	jae    6a6d <fwp_owned_entry173+0xad>
    6a62:	48 01 c2             	add    %rax,%rdx
    6a65:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a68:	74 26                	je     6a90 <fwp_owned_entry173+0xd0>
    6a6a:	c6 02 01             	movb   $0x1,(%rdx)
    6a6d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a72:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a79:	00 00 
    6a7b:	75 34                	jne    6ab1 <fwp_owned_entry173+0xf1>
    6a7d:	48 89 f0             	mov    %rsi,%rax
    6a80:	48 83 c4 38          	add    $0x38,%rsp
    6a84:	c3                   	ret
    6a85:	0f 1f 00             	nopl   (%rax)
    6a88:	66 85 c0             	test   %ax,%ax
    6a8b:	75 e0                	jne    6a6d <fwp_owned_entry173+0xad>
    6a8d:	eb d6                	jmp    6a65 <fwp_owned_entry173+0xa5>
    6a8f:	90                   	nop
    6a90:	48 89 d7             	mov    %rdx,%rdi
    6a93:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6a98:	48 89 14 24          	mov    %rdx,(%rsp)
    6a9c:	e8 2f e8 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6aa1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6aa6:	48 8b 14 24          	mov    (%rsp),%rdx
    6aaa:	eb be                	jmp    6a6a <fwp_owned_entry173+0xaa>
    6aac:	e8 0f cc ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6ab1:	e8 8a c9 ff ff       	call   3440 <__stack_chk_fail@plt>
    6ab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6abd:	00 00 00 

0000000000006ac0 <e173>:
    6ac0:	f3 0f 1e fa          	endbr64
    6ac4:	53                   	push   %rbx
    6ac5:	48 83 ec 30          	sub    $0x30,%rsp
    6ac9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6ace:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ad5:	00 00 
    6ad7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6adc:	31 c0                	xor    %eax,%eax
    6ade:	48 8b 07             	mov    (%rdi),%rax
    6ae1:	48 03 47 10          	add    0x10(%rdi),%rax
    6ae5:	0f 80 c9 00 00 00    	jo     6bb4 <e173+0xf4>
    6aeb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6af0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6af5:	31 ff                	xor    %edi,%edi
    6af7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6afb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b00:	e8 2b f0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    6b05:	48 8b 15 0c b0 01 00 	mov    0x1b00c(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    6b0c:	48 89 c3             	mov    %rax,%rbx
    6b0f:	48 2b 05 da af 01 00 	sub    0x1afda(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    6b16:	48 c1 e2 10          	shl    $0x10,%rdx
    6b1a:	48 39 d0             	cmp    %rdx,%rax
    6b1d:	73 4f                	jae    6b6e <e173+0xae>
    6b1f:	48 89 c2             	mov    %rax,%rdx
    6b22:	48 c1 ea 10          	shr    $0x10,%rdx
    6b26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b2a:	48 8b 15 07 b0 01 00 	mov    0x1b007(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    6b31:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b35:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b39:	48 85 d2             	test   %rdx,%rdx
    6b3c:	74 30                	je     6b6e <e173+0xae>
    6b3e:	0f b6 31             	movzbl (%rcx),%esi
    6b41:	40 80 fe 02          	cmp    $0x2,%sil
    6b45:	74 49                	je     6b90 <e173+0xd0>
    6b47:	40 80 fe 01          	cmp    $0x1,%sil
    6b4b:	75 21                	jne    6b6e <e173+0xae>
    6b4d:	8b 71 18             	mov    0x18(%rcx),%esi
    6b50:	0f b7 c0             	movzwl %ax,%eax
    6b53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b56:	48 0f af c6          	imul   %rsi,%rax
    6b5a:	48 c1 e8 20          	shr    $0x20,%rax
    6b5e:	48 39 c8             	cmp    %rcx,%rax
    6b61:	73 0b                	jae    6b6e <e173+0xae>
    6b63:	48 01 c2             	add    %rax,%rdx
    6b66:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b69:	74 35                	je     6ba0 <e173+0xe0>
    6b6b:	c6 02 01             	movb   $0x1,(%rdx)
    6b6e:	48 89 df             	mov    %rbx,%rdi
    6b71:	e8 ba fc ff ff       	call   6830 <fwp_rc_share>
    6b76:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b7b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b82:	00 00 
    6b84:	75 33                	jne    6bb9 <e173+0xf9>
    6b86:	48 83 c4 30          	add    $0x30,%rsp
    6b8a:	48 89 d8             	mov    %rbx,%rax
    6b8d:	5b                   	pop    %rbx
    6b8e:	c3                   	ret
    6b8f:	90                   	nop
    6b90:	66 85 c0             	test   %ax,%ax
    6b93:	75 d9                	jne    6b6e <e173+0xae>
    6b95:	eb cf                	jmp    6b66 <e173+0xa6>
    6b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b9e:	00 00 
    6ba0:	48 89 d7             	mov    %rdx,%rdi
    6ba3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ba8:	e8 23 e7 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6bad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bb2:	eb b7                	jmp    6b6b <e173+0xab>
    6bb4:	e8 07 cb ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6bb9:	e8 82 c8 ff ff       	call   3440 <__stack_chk_fail@plt>
    6bbe:	66 90                	xchg   %ax,%ax

0000000000006bc0 <fwp_closure_drop>:
    6bc0:	48 8b 15 51 af 01 00 	mov    0x1af51(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    6bc7:	48 89 f8             	mov    %rdi,%rax
    6bca:	48 2b 05 1f af 01 00 	sub    0x1af1f(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    6bd1:	48 c1 e2 10          	shl    $0x10,%rdx
    6bd5:	48 39 d0             	cmp    %rdx,%rax
    6bd8:	73 6b                	jae    6c45 <fwp_closure_drop+0x85>
    6bda:	48 89 c2             	mov    %rax,%rdx
    6bdd:	48 c1 ea 10          	shr    $0x10,%rdx
    6be1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6be5:	48 8b 15 4c af 01 00 	mov    0x1af4c(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    6bec:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bf0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bf4:	48 85 d2             	test   %rdx,%rdx
    6bf7:	74 4c                	je     6c45 <fwp_closure_drop+0x85>
    6bf9:	0f b6 31             	movzbl (%rcx),%esi
    6bfc:	40 80 fe 02          	cmp    $0x2,%sil
    6c00:	74 3e                	je     6c40 <fwp_closure_drop+0x80>
    6c02:	40 80 fe 01          	cmp    $0x1,%sil
    6c06:	75 3d                	jne    6c45 <fwp_closure_drop+0x85>
    6c08:	8b 71 18             	mov    0x18(%rcx),%esi
    6c0b:	0f b7 c0             	movzwl %ax,%eax
    6c0e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c11:	48 0f af c6          	imul   %rsi,%rax
    6c15:	48 c1 e8 20          	shr    $0x20,%rax
    6c19:	48 39 c8             	cmp    %rcx,%rax
    6c1c:	73 27                	jae    6c45 <fwp_closure_drop+0x85>
    6c1e:	48 01 c2             	add    %rax,%rdx
    6c21:	0f b6 02             	movzbl (%rdx),%eax
    6c24:	84 c0                	test   %al,%al
    6c26:	74 1d                	je     6c45 <fwp_closure_drop+0x85>
    6c28:	3c 01                	cmp    $0x1,%al
    6c2a:	74 24                	je     6c50 <fwp_closure_drop+0x90>
    6c2c:	3c ff                	cmp    $0xff,%al
    6c2e:	74 48                	je     6c78 <fwp_closure_drop+0xb8>
    6c30:	83 e8 01             	sub    $0x1,%eax
    6c33:	88 02                	mov    %al,(%rdx)
    6c35:	c3                   	ret
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 
    6c40:	66 85 c0             	test   %ax,%ax
    6c43:	74 dc                	je     6c21 <fwp_closure_drop+0x61>
    6c45:	c3                   	ret
    6c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c4d:	00 00 00 
    6c50:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c57:	ff ff 
    6c59:	48 85 c0             	test   %rax,%rax
    6c5c:	74 12                	je     6c70 <fwp_closure_drop+0xb0>
    6c5e:	48 89 fe             	mov    %rdi,%rsi
    6c61:	48 89 c7             	mov    %rax,%rdi
    6c64:	e9 57 d5 ff ff       	jmp    41c0 <fwp_closure_drop_push>
    6c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c70:	e9 fb d6 ff ff       	jmp    4370 <fwp_closure_drop.part.0>
    6c75:	0f 1f 00             	nopl   (%rax)
    6c78:	48 89 d0             	mov    %rdx,%rax
    6c7b:	48 8d 35 be 9a 01 00 	lea    0x19abe(%rip),%rsi        # 20740 <fwp_heap>
    6c82:	48 83 ec 18          	sub    $0x18,%rsp
    6c86:	48 c1 e8 11          	shr    $0x11,%rax
    6c8a:	48 31 d0             	xor    %rdx,%rax
    6c8d:	48 89 c1             	mov    %rax,%rcx
    6c90:	48 c1 e9 09          	shr    $0x9,%rcx
    6c94:	48 31 c8             	xor    %rcx,%rax
    6c97:	0f b6 c8             	movzbl %al,%ecx
    6c9a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6ca1:	00 
    6ca2:	48 85 c0             	test   %rax,%rax
    6ca5:	75 22                	jne    6cc9 <fwp_closure_drop+0x109>
    6ca7:	eb 59                	jmp    6d02 <fwp_closure_drop+0x142>
    6ca9:	90                   	nop
    6caa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cb1:	00 00 00 00 
    6cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cbc:	00 00 00 00 
    6cc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6cc4:	48 85 c0             	test   %rax,%rax
    6cc7:	74 39                	je     6d02 <fwp_closure_drop+0x142>
    6cc9:	48 89 c1             	mov    %rax,%rcx
    6ccc:	48 39 10             	cmp    %rdx,(%rax)
    6ccf:	75 ef                	jne    6cc0 <fwp_closure_drop+0x100>
    6cd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6cd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6cd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6cdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ce4:	74 05                	je     6ceb <fwp_closure_drop+0x12b>
    6ce6:	48 83 c4 18          	add    $0x18,%rsp
    6cea:	c3                   	ret
    6ceb:	48 89 d7             	mov    %rdx,%rdi
    6cee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cf3:	e8 d8 e5 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6cf8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cfd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d00:	eb e4                	jmp    6ce6 <fwp_closure_drop+0x126>
    6d02:	48 8d 3d 97 5a 00 00 	lea    0x5a97(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    6d09:	e8 52 d4 ff ff       	call   4160 <fwp_trap>
    6d0e:	66 90                	xchg   %ax,%ax

0000000000006d10 <fwp_owned_tape_release>:
    6d10:	48 85 ff             	test   %rdi,%rdi
    6d13:	0f 84 f7 00 00 00    	je     6e10 <fwp_owned_tape_release+0x100>
    6d19:	41 54                	push   %r12
    6d1b:	55                   	push   %rbp
    6d1c:	53                   	push   %rbx
    6d1d:	48 8b 07             	mov    (%rdi),%rax
    6d20:	48 85 c0             	test   %rax,%rax
    6d23:	74 08                	je     6d2d <fwp_owned_tape_release+0x1d>
    6d25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d31:	48 85 d2             	test   %rdx,%rdx
    6d34:	74 03                	je     6d39 <fwp_owned_tape_release+0x29>
    6d36:	48 89 02             	mov    %rax,(%rdx)
    6d39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6d3d:	48 89 fb             	mov    %rdi,%rbx
    6d40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d44:	48 85 c0             	test   %rax,%rax
    6d47:	0f 84 89 00 00 00    	je     6dd6 <fwp_owned_tape_release+0xc6>
    6d4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d55:	7e 47                	jle    6d9e <fwp_owned_tape_release+0x8e>
    6d57:	31 ed                	xor    %ebp,%ebp
    6d59:	eb 0d                	jmp    6d68 <fwp_owned_tape_release+0x58>
    6d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d6c:	49 89 ec             	mov    %rbp,%r12
    6d6f:	48 83 c5 01          	add    $0x1,%rbp
    6d73:	49 c1 e4 04          	shl    $0x4,%r12
    6d77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d7b:	ff d0                	call   *%rax
    6d7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6d81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6d86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d8a:	ff 50 68             	call   *0x68(%rax)
    6d8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6d91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6d95:	48 39 e8             	cmp    %rbp,%rax
    6d98:	7f c6                	jg     6d60 <fwp_owned_tape_release+0x50>
    6d9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d9e:	31 ed                	xor    %ebp,%ebp
    6da0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6da5:	7e 28                	jle    6dcf <fwp_owned_tape_release+0xbf>
    6da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dae:	00 00 
    6db0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6db4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6db8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6dbc:	74 07                	je     6dc5 <fwp_owned_tape_release+0xb5>
    6dbe:	ff 52 68             	call   *0x68(%rdx)
    6dc1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6dc5:	48 83 c5 01          	add    $0x1,%rbp
    6dc9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6dcd:	7f e1                	jg     6db0 <fwp_owned_tape_release+0xa0>
    6dcf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6dd3:	ff 52 68             	call   *0x68(%rdx)
    6dd6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6dda:	e8 e1 fd ff ff       	call   6bc0 <fwp_closure_drop>
    6ddf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6de3:	e8 d8 fd ff ff       	call   6bc0 <fwp_closure_drop>
    6de8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6dec:	e8 cf fd ff ff       	call   6bc0 <fwp_closure_drop>
    6df1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6df5:	e8 16 e7 ff ff       	call   5510 <fwp_mem_free>
    6dfa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6dfe:	e8 0d e7 ff ff       	call   5510 <fwp_mem_free>
    6e03:	48 89 df             	mov    %rbx,%rdi
    6e06:	5b                   	pop    %rbx
    6e07:	5d                   	pop    %rbp
    6e08:	41 5c                	pop    %r12
    6e0a:	e9 01 e7 ff ff       	jmp    5510 <fwp_mem_free>
    6e0f:	90                   	nop
    6e10:	c3                   	ret
    6e11:	0f 1f 40 00          	nopl   0x0(%rax)
    6e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e1c:	00 00 00 00 

0000000000006e20 <fwp_tape_finish>:
    6e20:	f3 0f 1e fa          	endbr64
    6e24:	41 56                	push   %r14
    6e26:	48 8d 3d 73 92 01 00 	lea    0x19273(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6e2d:	41 55                	push   %r13
    6e2f:	41 54                	push   %r12
    6e31:	55                   	push   %rbp
    6e32:	53                   	push   %rbx
    6e33:	e8 f8 d0 ff ff       	call   3f30 <fwp_tape_buffers_dispose>
    6e38:	48 83 3d 98 92 01 00 	cmpq   $0x0,0x19298(%rip)        # 200d8 <fwp_ntapes>
    6e3f:	00 
    6e40:	48 c7 05 3d 92 01 00 	movq   $0x0,0x1923d(%rip)        # 20088 <fwp_tape_cached_bytes>
    6e47:	00 00 00 00 
    6e4b:	7e 68                	jle    6eb5 <fwp_tape_finish+0x95>
    6e4d:	45 31 e4             	xor    %r12d,%r12d
    6e50:	31 ed                	xor    %ebp,%ebp
    6e52:	0f 1f 00             	nopl   (%rax)
    6e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e5c:	00 00 00 00 
    6e60:	48 8b 1d 79 92 01 00 	mov    0x19279(%rip),%rbx        # 200e0 <fwp_tapes>
    6e67:	48 83 c5 01          	add    $0x1,%rbp
    6e6b:	4c 01 e3             	add    %r12,%rbx
    6e6e:	49 83 c4 58          	add    $0x58,%r12
    6e72:	48 89 df             	mov    %rbx,%rdi
    6e75:	e8 46 cd ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    6e7a:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6e7e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e82:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
    6e86:	e8 15 c5 ff ff       	call   33a0 <free@plt>
    6e8b:	4c 89 f7             	mov    %r14,%rdi
    6e8e:	e8 0d c5 ff ff       	call   33a0 <free@plt>
    6e93:	4c 89 ef             	mov    %r13,%rdi
    6e96:	e8 05 c5 ff ff       	call   33a0 <free@plt>
    6e9b:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    6e9f:	e8 6c fe ff ff       	call   6d10 <fwp_owned_tape_release>
    6ea4:	48 39 2d 2d 92 01 00 	cmp    %rbp,0x1922d(%rip)        # 200d8 <fwp_ntapes>
    6eab:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    6eb2:	00 
    6eb3:	7f ab                	jg     6e60 <fwp_tape_finish+0x40>
    6eb5:	48 8b 3d 24 92 01 00 	mov    0x19224(%rip),%rdi        # 200e0 <fwp_tapes>
    6ebc:	e8 df c4 ff ff       	call   33a0 <free@plt>
    6ec1:	5b                   	pop    %rbx
    6ec2:	5d                   	pop    %rbp
    6ec3:	48 c7 05 12 92 01 00 	movq   $0x0,0x19212(%rip)        # 200e0 <fwp_tapes>
    6eca:	00 00 00 00 
    6ece:	48 c7 05 f7 91 01 00 	movq   $0x0,0x191f7(%rip)        # 200d0 <fwp_tapes_cap>
    6ed5:	00 00 00 00 
    6ed9:	41 5c                	pop    %r12
    6edb:	48 c7 05 f2 91 01 00 	movq   $0x0,0x191f2(%rip)        # 200d8 <fwp_ntapes>
    6ee2:	00 00 00 00 
    6ee6:	41 5d                	pop    %r13
    6ee8:	48 c7 05 d5 91 01 00 	movq   $0x0,0x191d5(%rip)        # 200c8 <fwp_tape_next_slot>
    6eef:	00 00 00 00 
    6ef3:	41 5e                	pop    %r14
    6ef5:	c3                   	ret
    6ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6efd:	00 00 00 

0000000000006f00 <fwp_tape_scope_release>:
    6f00:	f3 0f 1e fa          	endbr64
    6f04:	41 55                	push   %r13
    6f06:	41 54                	push   %r12
    6f08:	55                   	push   %rbp
    6f09:	53                   	push   %rbx
    6f0a:	48 83 ec 48          	sub    $0x48,%rsp
    6f0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f15:	00 00 
    6f17:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6f1c:	48 63 07             	movslq (%rdi),%rax
    6f1f:	85 c0                	test   %eax,%eax
    6f21:	0f 88 f8 00 00 00    	js     701f <fwp_tape_scope_release+0x11f>
    6f27:	48 bd a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%rbp
    6f2e:	a2 8b 2e 
    6f31:	48 89 fb             	mov    %rdi,%rbx
    6f34:	eb 3d                	jmp    6f73 <fwp_tape_scope_release+0x73>
    6f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f3d:	00 00 00 
    6f40:	66 48 0f 7e c7       	movq   %xmm0,%rdi
    6f45:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6f49:	e8 52 c4 ff ff       	call   33a0 <free@plt>
    6f4e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f53:	e8 48 c4 ff ff       	call   33a0 <free@plt>
    6f58:	4c 89 ef             	mov    %r13,%rdi
    6f5b:	e8 40 c4 ff ff       	call   33a0 <free@plt>
    6f60:	4c 89 e7             	mov    %r12,%rdi
    6f63:	e8 a8 fd ff ff       	call   6d10 <fwp_owned_tape_release>
    6f68:	48 63 03             	movslq (%rbx),%rax
    6f6b:	85 c0                	test   %eax,%eax
    6f6d:	0f 88 ac 00 00 00    	js     701f <fwp_tape_scope_release+0x11f>
    6f73:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    6f77:	48 8b 35 62 91 01 00 	mov    0x19162(%rip),%rsi        # 200e0 <fwp_tapes>
    6f7e:	4c 01 c6             	add    %r8,%rsi
    6f81:	48 89 f7             	mov    %rsi,%rdi
    6f84:	e8 37 cc ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    6f89:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    6f8e:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
    6f92:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6f99:	f3 0f 7e 4e 18       	movq   0x18(%rsi),%xmm1
    6f9e:	0f 16 4e 38          	movhps 0x38(%rsi),%xmm1
    6fa2:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
    6fa7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6fab:	4c 8b 66 50          	mov    0x50(%rsi),%r12
    6faf:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
    6fb4:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    6fbb:	00 
    6fbc:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    6fc3:	00 
    6fc4:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    6fcb:	00 
    6fcc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6fd3:	00 
    6fd4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6fd9:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    6fdd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    6fe1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6fe7:	77 18                	ja     7001 <fwp_tape_scope_release+0x101>
    6fe9:	49 c1 f8 03          	sar    $0x3,%r8
    6fed:	4c 0f af c5          	imul   %rbp,%r8
    6ff1:	4c 3b 05 d0 90 01 00 	cmp    0x190d0(%rip),%r8        # 200c8 <fwp_tape_next_slot>
    6ff8:	7d 07                	jge    7001 <fwp_tape_scope_release+0x101>
    6ffa:	4c 89 05 c7 90 01 00 	mov    %r8,0x190c7(%rip)        # 200c8 <fwp_tape_next_slot>
    7001:	4d 85 e4             	test   %r12,%r12
    7004:	0f 85 36 ff ff ff    	jne    6f40 <fwp_tape_scope_release+0x40>
    700a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    700f:	e8 dc dd ff ff       	call   4df0 <fwp_tape_buffers_release>
    7014:	48 63 03             	movslq (%rbx),%rax
    7017:	85 c0                	test   %eax,%eax
    7019:	0f 89 54 ff ff ff    	jns    6f73 <fwp_tape_scope_release+0x73>
    701f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7024:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    702b:	00 00 
    702d:	75 0b                	jne    703a <fwp_tape_scope_release+0x13a>
    702f:	48 83 c4 48          	add    $0x48,%rsp
    7033:	5b                   	pop    %rbx
    7034:	5d                   	pop    %rbp
    7035:	41 5c                	pop    %r12
    7037:	41 5d                	pop    %r13
    7039:	c3                   	ret
    703a:	e8 01 c4 ff ff       	call   3440 <__stack_chk_fail@plt>
    703f:	90                   	nop

0000000000007040 <fwp_drop4>:
    7040:	48 8b 0d d1 aa 01 00 	mov    0x1aad1(%rip),%rcx        # 21b18 <fwp_heap+0x13d8>
    7047:	48 89 f8             	mov    %rdi,%rax
    704a:	48 2b 05 9f aa 01 00 	sub    0x1aa9f(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    7051:	48 c1 e1 10          	shl    $0x10,%rcx
    7055:	48 39 c8             	cmp    %rcx,%rax
    7058:	0f 83 42 01 00 00    	jae    71a0 <fwp_drop4+0x160>
    705e:	48 83 ec 18          	sub    $0x18,%rsp
    7062:	48 89 fa             	mov    %rdi,%rdx
    7065:	4c 8d 05 d4 96 01 00 	lea    0x196d4(%rip),%r8        # 20740 <fwp_heap>
    706c:	48 89 c1             	mov    %rax,%rcx
    706f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7076:	48 c1 e9 10          	shr    $0x10,%rcx
    707a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    707e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7082:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7086:	48 85 c9             	test   %rcx,%rcx
    7089:	74 40                	je     70cb <fwp_drop4+0x8b>
    708b:	0f b6 3e             	movzbl (%rsi),%edi
    708e:	40 80 ff 02          	cmp    $0x2,%dil
    7092:	74 3c                	je     70d0 <fwp_drop4+0x90>
    7094:	40 80 ff 01          	cmp    $0x1,%dil
    7098:	75 31                	jne    70cb <fwp_drop4+0x8b>
    709a:	8b 7e 18             	mov    0x18(%rsi),%edi
    709d:	0f b7 c0             	movzwl %ax,%eax
    70a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    70a3:	48 0f af c7          	imul   %rdi,%rax
    70a7:	48 c1 e8 20          	shr    $0x20,%rax
    70ab:	48 39 f0             	cmp    %rsi,%rax
    70ae:	73 1b                	jae    70cb <fwp_drop4+0x8b>
    70b0:	48 01 c1             	add    %rax,%rcx
    70b3:	0f b6 01             	movzbl (%rcx),%eax
    70b6:	84 c0                	test   %al,%al
    70b8:	74 11                	je     70cb <fwp_drop4+0x8b>
    70ba:	3c 01                	cmp    $0x1,%al
    70bc:	74 22                	je     70e0 <fwp_drop4+0xa0>
    70be:	3c ff                	cmp    $0xff,%al
    70c0:	0f 84 0a 01 00 00    	je     71d0 <fwp_drop4+0x190>
    70c6:	83 e8 01             	sub    $0x1,%eax
    70c9:	88 01                	mov    %al,(%rcx)
    70cb:	48 83 c4 18          	add    $0x18,%rsp
    70cf:	c3                   	ret
    70d0:	66 85 c0             	test   %ax,%ax
    70d3:	74 de                	je     70b3 <fwp_drop4+0x73>
    70d5:	48 83 c4 18          	add    $0x18,%rsp
    70d9:	c3                   	ret
    70da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    70e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    70eb:	48 89 f8             	mov    %rdi,%rax
    70ee:	48 c1 e1 10          	shl    $0x10,%rcx
    70f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70f9:	48 39 c8             	cmp    %rcx,%rax
    70fc:	73 62                	jae    7160 <fwp_drop4+0x120>
    70fe:	48 89 c1             	mov    %rax,%rcx
    7101:	48 c1 e9 10          	shr    $0x10,%rcx
    7105:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7109:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    710d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7111:	48 85 c9             	test   %rcx,%rcx
    7114:	74 4a                	je     7160 <fwp_drop4+0x120>
    7116:	44 0f b6 0e          	movzbl (%rsi),%r9d
    711a:	41 80 f9 02          	cmp    $0x2,%r9b
    711e:	0f 84 9c 00 00 00    	je     71c0 <fwp_drop4+0x180>
    7124:	41 80 f9 01          	cmp    $0x1,%r9b
    7128:	75 36                	jne    7160 <fwp_drop4+0x120>
    712a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    712e:	0f b7 c0             	movzwl %ax,%eax
    7131:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7134:	49 0f af c1          	imul   %r9,%rax
    7138:	48 c1 e8 20          	shr    $0x20,%rax
    713c:	48 39 f0             	cmp    %rsi,%rax
    713f:	73 1f                	jae    7160 <fwp_drop4+0x120>
    7141:	48 01 c1             	add    %rax,%rcx
    7144:	0f b6 01             	movzbl (%rcx),%eax
    7147:	84 c0                	test   %al,%al
    7149:	74 15                	je     7160 <fwp_drop4+0x120>
    714b:	3c 01                	cmp    $0x1,%al
    714d:	74 59                	je     71a8 <fwp_drop4+0x168>
    714f:	3c ff                	cmp    $0xff,%al
    7151:	0f 84 ef 00 00 00    	je     7246 <fwp_drop4+0x206>
    7157:	83 e8 01             	sub    $0x1,%eax
    715a:	88 01                	mov    %al,(%rcx)
    715c:	0f 1f 40 00          	nopl   0x0(%rax)
    7160:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7164:	48 89 d7             	mov    %rdx,%rdi
    7167:	48 89 0c 24          	mov    %rcx,(%rsp)
    716b:	e8 40 f7 ff ff       	call   68b0 <fwp_rc_free_obj>
    7170:	4c 8d 05 c9 95 01 00 	lea    0x195c9(%rip),%r8        # 20740 <fwp_heap>
    7177:	48 8b 04 24          	mov    (%rsp),%rax
    717b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7182:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7189:	48 c1 e2 10          	shl    $0x10,%rdx
    718d:	48 39 d0             	cmp    %rdx,%rax
    7190:	0f 83 35 ff ff ff    	jae    70cb <fwp_drop4+0x8b>
    7196:	48 8b 14 24          	mov    (%rsp),%rdx
    719a:	e9 cd fe ff ff       	jmp    706c <fwp_drop4+0x2c>
    719f:	90                   	nop
    71a0:	c3                   	ret
    71a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71a8:	48 89 14 24          	mov    %rdx,(%rsp)
    71ac:	e8 ff f6 ff ff       	call   68b0 <fwp_rc_free_obj>
    71b1:	48 8b 14 24          	mov    (%rsp),%rdx
    71b5:	eb a9                	jmp    7160 <fwp_drop4+0x120>
    71b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71be:	00 00 
    71c0:	66 85 c0             	test   %ax,%ax
    71c3:	75 9b                	jne    7160 <fwp_drop4+0x120>
    71c5:	e9 7a ff ff ff       	jmp    7144 <fwp_drop4+0x104>
    71ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71d0:	48 89 c8             	mov    %rcx,%rax
    71d3:	48 c1 e8 11          	shr    $0x11,%rax
    71d7:	48 31 c8             	xor    %rcx,%rax
    71da:	48 89 c2             	mov    %rax,%rdx
    71dd:	48 c1 ea 09          	shr    $0x9,%rdx
    71e1:	48 31 d0             	xor    %rdx,%rax
    71e4:	0f b6 d0             	movzbl %al,%edx
    71e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    71ee:	00 
    71ef:	48 85 c0             	test   %rax,%rax
    71f2:	75 19                	jne    720d <fwp_drop4+0x1cd>
    71f4:	e9 d3 00 00 00       	jmp    72cc <fwp_drop4+0x28c>
    71f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7200:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	0f 84 bf 00 00 00    	je     72cc <fwp_drop4+0x28c>
    720d:	48 89 c2             	mov    %rax,%rdx
    7210:	48 39 08             	cmp    %rcx,(%rax)
    7213:	75 eb                	jne    7200 <fwp_drop4+0x1c0>
    7215:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7219:	48 83 ea 01          	sub    $0x1,%rdx
    721d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7221:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7228:	0f 85 9d fe ff ff    	jne    70cb <fwp_drop4+0x8b>
    722e:	48 89 cf             	mov    %rcx,%rdi
    7231:	48 89 0c 24          	mov    %rcx,(%rsp)
    7235:	e8 96 e0 ff ff       	call   52d0 <fwp_rc_forget_slot>
    723a:	48 8b 0c 24          	mov    (%rsp),%rcx
    723e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7241:	e9 85 fe ff ff       	jmp    70cb <fwp_drop4+0x8b>
    7246:	48 89 ce             	mov    %rcx,%rsi
    7249:	48 c1 ee 11          	shr    $0x11,%rsi
    724d:	48 31 ce             	xor    %rcx,%rsi
    7250:	48 89 f0             	mov    %rsi,%rax
    7253:	48 c1 e8 09          	shr    $0x9,%rax
    7257:	48 31 c6             	xor    %rax,%rsi
    725a:	40 0f b6 f6          	movzbl %sil,%esi
    725e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7265:	00 
    7266:	48 85 c0             	test   %rax,%rax
    7269:	75 1e                	jne    7289 <fwp_drop4+0x249>
    726b:	eb 5f                	jmp    72cc <fwp_drop4+0x28c>
    726d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7274:	00 
    7275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    727c:	00 00 00 00 
    7280:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7284:	48 85 c0             	test   %rax,%rax
    7287:	74 43                	je     72cc <fwp_drop4+0x28c>
    7289:	48 89 c6             	mov    %rax,%rsi
    728c:	48 39 08             	cmp    %rcx,(%rax)
    728f:	75 ef                	jne    7280 <fwp_drop4+0x240>
    7291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7295:	48 83 ee 01          	sub    $0x1,%rsi
    7299:	48 89 70 08          	mov    %rsi,0x8(%rax)
    729d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    72a4:	0f 85 b6 fe ff ff    	jne    7160 <fwp_drop4+0x120>
    72aa:	48 89 cf             	mov    %rcx,%rdi
    72ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    72b6:	e8 15 e0 ff ff       	call   52d0 <fwp_rc_forget_slot>
    72bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    72bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    72c7:	e9 94 fe ff ff       	jmp    7160 <fwp_drop4+0x120>
    72cc:	48 8d 3d cd 54 00 00 	lea    0x54cd(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    72d3:	e8 88 ce ff ff       	call   4160 <fwp_trap>
    72d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72df:	00 

00000000000072e0 <fwp_arg_drop37>:
    72e0:	f3 0f 1e fa          	endbr64
    72e4:	85 f6                	test   %esi,%esi
    72e6:	75 04                	jne    72ec <fwp_arg_drop37+0xc>
    72e8:	85 d2                	test   %edx,%edx
    72ea:	75 04                	jne    72f0 <fwp_arg_drop37+0x10>
    72ec:	c3                   	ret
    72ed:	0f 1f 00             	nopl   (%rax)
    72f0:	48 8b 3f             	mov    (%rdi),%rdi
    72f3:	e9 48 fd ff ff       	jmp    7040 <fwp_drop4>
    72f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72ff:	00 

0000000000007300 <fwp_task_dispose>:
    7300:	53                   	push   %rbx
    7301:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7305:	0f 84 fb c3 ff ff    	je     3706 <fwp_task_dispose.cold>
    730b:	48 89 fb             	mov    %rdi,%rbx
    730e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7313:	0f 85 ed c3 ff ff    	jne    3706 <fwp_task_dispose.cold>
    7319:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    731d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7324:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    732b:	00 
    732c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7330:	48 85 ff             	test   %rdi,%rdi
    7333:	74 07                	je     733c <fwp_task_dispose+0x3c>
    7335:	48 85 c0             	test   %rax,%rax
    7338:	74 02                	je     733c <fwp_task_dispose+0x3c>
    733a:	ff d0                	call   *%rax
    733c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7343:	e8 c8 e1 ff ff       	call   5510 <fwp_mem_free>
    7348:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    734f:	00 00 00 00 
    7353:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7357:	74 6f                	je     73c8 <fwp_task_dispose+0xc8>
    7359:	48 8b 15 b8 a7 01 00 	mov    0x1a7b8(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    7360:	48 89 d8             	mov    %rbx,%rax
    7363:	48 2b 05 86 a7 01 00 	sub    0x1a786(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    736a:	48 c1 e2 10          	shl    $0x10,%rdx
    736e:	48 39 d0             	cmp    %rdx,%rax
    7371:	73 4c                	jae    73bf <fwp_task_dispose+0xbf>
    7373:	48 89 c2             	mov    %rax,%rdx
    7376:	48 c1 ea 10          	shr    $0x10,%rdx
    737a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    737e:	48 8b 15 b3 a7 01 00 	mov    0x1a7b3(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    7385:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7389:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    738d:	48 85 c9             	test   %rcx,%rcx
    7390:	74 2d                	je     73bf <fwp_task_dispose+0xbf>
    7392:	0f b6 32             	movzbl (%rdx),%esi
    7395:	40 80 fe 02          	cmp    $0x2,%sil
    7399:	74 3d                	je     73d8 <fwp_task_dispose+0xd8>
    739b:	40 80 fe 01          	cmp    $0x1,%sil
    739f:	75 1e                	jne    73bf <fwp_task_dispose+0xbf>
    73a1:	8b 72 18             	mov    0x18(%rdx),%esi
    73a4:	0f b7 c0             	movzwl %ax,%eax
    73a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73aa:	48 0f af c6          	imul   %rsi,%rax
    73ae:	48 c1 e8 20          	shr    $0x20,%rax
    73b2:	48 39 d0             	cmp    %rdx,%rax
    73b5:	73 08                	jae    73bf <fwp_task_dispose+0xbf>
    73b7:	48 01 c1             	add    %rax,%rcx
    73ba:	80 39 01             	cmpb   $0x1,(%rcx)
    73bd:	74 09                	je     73c8 <fwp_task_dispose+0xc8>
    73bf:	5b                   	pop    %rbx
    73c0:	c3                   	ret
    73c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73c8:	48 89 df             	mov    %rbx,%rdi
    73cb:	5b                   	pop    %rbx
    73cc:	e9 3f e1 ff ff       	jmp    5510 <fwp_mem_free>
    73d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73d8:	66 85 c0             	test   %ax,%ax
    73db:	74 dd                	je     73ba <fwp_task_dispose+0xba>
    73dd:	5b                   	pop    %rbx
    73de:	c3                   	ret
    73df:	90                   	nop

00000000000073e0 <fwp_free_zombie>:
    73e0:	48 8b 15 29 93 01 00 	mov    0x19329(%rip),%rdx        # 20710 <fwp_zombie>
    73e7:	48 85 d2             	test   %rdx,%rdx
    73ea:	0f 84 98 00 00 00    	je     7488 <fwp_free_zombie+0xa8>
    73f0:	48 3b 15 29 93 01 00 	cmp    0x19329(%rip),%rdx        # 20720 <fwp_cur>
    73f7:	0f 84 8b 00 00 00    	je     7488 <fwp_free_zombie+0xa8>
    73fd:	48 83 ec 18          	sub    $0x18,%rsp
    7401:	48 63 05 f4 8c 01 00 	movslq 0x18cf4(%rip),%rax        # 200fc <fwp_stack_pool_n>
    7408:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    740c:	83 f8 3f             	cmp    $0x3f,%eax
    740f:	7f 7f                	jg     7490 <fwp_free_zombie+0xb0>
    7411:	8d 48 01             	lea    0x1(%rax),%ecx
    7414:	89 0d e2 8c 01 00    	mov    %ecx,0x18ce2(%rip)        # 200fc <fwp_stack_pool_n>
    741a:	48 8d 0d df 8c 01 00 	lea    0x18cdf(%rip),%rcx        # 20100 <fwp_stack_pool>
    7421:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7425:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    742c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7430:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7437:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    743b:	48 85 c9             	test   %rcx,%rcx
    743e:	0f 84 fc 00 00 00    	je     7540 <fwp_free_zombie+0x160>
    7444:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    744b:	48 85 c0             	test   %rax,%rax
    744e:	74 07                	je     7457 <fwp_free_zombie+0x77>
    7450:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7457:	8b 42 5c             	mov    0x5c(%rdx),%eax
    745a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    745e:	48 c7 05 a7 92 01 00 	movq   $0x0,0x192a7(%rip)        # 20710 <fwp_zombie>
    7465:	00 00 00 00 
    7469:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7470:	85 c0                	test   %eax,%eax
    7472:	74 34                	je     74a8 <fwp_free_zombie+0xc8>
    7474:	83 f8 01             	cmp    $0x1,%eax
    7477:	0f 84 b3 00 00 00    	je     7530 <fwp_free_zombie+0x150>
    747d:	48 83 c4 18          	add    $0x18,%rsp
    7481:	c3                   	ret
    7482:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7488:	c3                   	ret
    7489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7490:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7494:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7499:	e8 12 c1 ff ff       	call   35b0 <munmap@plt>
    749e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    74a3:	eb 80                	jmp    7425 <fwp_free_zombie+0x45>
    74a5:	0f 1f 00             	nopl   (%rax)
    74a8:	48 8b 0d 69 a6 01 00 	mov    0x1a669(%rip),%rcx        # 21b18 <fwp_heap+0x13d8>
    74af:	48 89 d0             	mov    %rdx,%rax
    74b2:	48 2b 05 37 a6 01 00 	sub    0x1a637(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    74b9:	48 c1 e1 10          	shl    $0x10,%rcx
    74bd:	48 39 c8             	cmp    %rcx,%rax
    74c0:	73 bb                	jae    747d <fwp_free_zombie+0x9d>
    74c2:	48 89 c1             	mov    %rax,%rcx
    74c5:	48 c1 e9 10          	shr    $0x10,%rcx
    74c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    74cd:	48 8b 0d 64 a6 01 00 	mov    0x1a664(%rip),%rcx        # 21b38 <fwp_heap+0x13f8>
    74d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    74d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    74dc:	48 85 c9             	test   %rcx,%rcx
    74df:	74 9c                	je     747d <fwp_free_zombie+0x9d>
    74e1:	0f b6 3e             	movzbl (%rsi),%edi
    74e4:	40 80 ff 02          	cmp    $0x2,%dil
    74e8:	74 66                	je     7550 <fwp_free_zombie+0x170>
    74ea:	40 80 ff 01          	cmp    $0x1,%dil
    74ee:	75 8d                	jne    747d <fwp_free_zombie+0x9d>
    74f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    74f3:	0f b7 c0             	movzwl %ax,%eax
    74f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    74f9:	48 0f af c7          	imul   %rdi,%rax
    74fd:	48 c1 e8 20          	shr    $0x20,%rax
    7501:	48 39 f0             	cmp    %rsi,%rax
    7504:	0f 83 73 ff ff ff    	jae    747d <fwp_free_zombie+0x9d>
    750a:	48 01 c1             	add    %rax,%rcx
    750d:	0f b6 01             	movzbl (%rcx),%eax
    7510:	84 c0                	test   %al,%al
    7512:	0f 84 65 ff ff ff    	je     747d <fwp_free_zombie+0x9d>
    7518:	3c 01                	cmp    $0x1,%al
    751a:	74 14                	je     7530 <fwp_free_zombie+0x150>
    751c:	3c ff                	cmp    $0xff,%al
    751e:	74 3b                	je     755b <fwp_free_zombie+0x17b>
    7520:	83 e8 01             	sub    $0x1,%eax
    7523:	88 01                	mov    %al,(%rcx)
    7525:	e9 53 ff ff ff       	jmp    747d <fwp_free_zombie+0x9d>
    752a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7530:	48 89 d7             	mov    %rdx,%rdi
    7533:	48 83 c4 18          	add    $0x18,%rsp
    7537:	e9 c4 fd ff ff       	jmp    7300 <fwp_task_dispose>
    753c:	0f 1f 40 00          	nopl   0x0(%rax)
    7540:	48 89 05 a1 91 01 00 	mov    %rax,0x191a1(%rip)        # 206e8 <fwp_tasks_active>
    7547:	e9 ff fe ff ff       	jmp    744b <fwp_free_zombie+0x6b>
    754c:	0f 1f 40 00          	nopl   0x0(%rax)
    7550:	66 85 c0             	test   %ax,%ax
    7553:	0f 85 24 ff ff ff    	jne    747d <fwp_free_zombie+0x9d>
    7559:	eb b2                	jmp    750d <fwp_free_zombie+0x12d>
    755b:	48 89 ca             	mov    %rcx,%rdx
    755e:	48 8d 35 db 91 01 00 	lea    0x191db(%rip),%rsi        # 20740 <fwp_heap>
    7565:	48 c1 ea 11          	shr    $0x11,%rdx
    7569:	48 31 ca             	xor    %rcx,%rdx
    756c:	48 89 d0             	mov    %rdx,%rax
    756f:	48 c1 e8 09          	shr    $0x9,%rax
    7573:	48 31 c2             	xor    %rax,%rdx
    7576:	0f b6 d2             	movzbl %dl,%edx
    7579:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7580:	00 
    7581:	48 85 c0             	test   %rax,%rax
    7584:	75 23                	jne    75a9 <fwp_free_zombie+0x1c9>
    7586:	eb 5c                	jmp    75e4 <fwp_free_zombie+0x204>
    7588:	66 90                	xchg   %ax,%ax
    758a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7591:	00 00 00 00 
    7595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    759c:	00 00 00 00 
    75a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    75a4:	48 85 c0             	test   %rax,%rax
    75a7:	74 3b                	je     75e4 <fwp_free_zombie+0x204>
    75a9:	48 89 c2             	mov    %rax,%rdx
    75ac:	48 39 08             	cmp    %rcx,(%rax)
    75af:	75 ef                	jne    75a0 <fwp_free_zombie+0x1c0>
    75b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    75b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    75bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    75c4:	0f 85 b3 fe ff ff    	jne    747d <fwp_free_zombie+0x9d>
    75ca:	48 89 cf             	mov    %rcx,%rdi
    75cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    75d2:	e8 f9 dc ff ff       	call   52d0 <fwp_rc_forget_slot>
    75d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    75dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    75df:	e9 99 fe ff ff       	jmp    747d <fwp_free_zombie+0x9d>
    75e4:	48 8d 3d b5 51 00 00 	lea    0x51b5(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    75eb:	e8 70 cb ff ff       	call   4160 <fwp_trap>

00000000000075f0 <fwp_block>:
    75f0:	48 83 ec 08          	sub    $0x8,%rsp
    75f4:	48 8b 05 0d 91 01 00 	mov    0x1910d(%rip),%rax        # 20708 <fwp_ready_head>
    75fb:	48 85 c0             	test   %rax,%rax
    75fe:	0f 84 1c 01 00 00    	je     7720 <fwp_block+0x130>
    7604:	90                   	nop
    7605:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    760c:	00 00 00 00 
    7610:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7617:	48 89 15 ea 90 01 00 	mov    %rdx,0x190ea(%rip)        # 20708 <fwp_ready_head>
    761e:	48 85 d2             	test   %rdx,%rdx
    7621:	0f 84 19 01 00 00    	je     7740 <fwp_block+0x150>
    7627:	48 8b 15 f2 90 01 00 	mov    0x190f2(%rip),%rdx        # 20720 <fwp_cur>
    762e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7632:	48 39 c2             	cmp    %rax,%rdx
    7635:	0f 84 d5 00 00 00    	je     7710 <fwp_block+0x120>
    763b:	48 8b 0d 66 ad 01 00 	mov    0x1ad66(%rip),%rcx        # 223a8 <fwp_state_owners>
    7642:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7646:	48 89 05 d3 90 01 00 	mov    %rax,0x190d3(%rip)        # 20720 <fwp_cur>
    764d:	f3 0f 7e 05 7b ad 01 	movq   0x1ad7b(%rip),%xmm0        # 223d0 <fwp_foreign_callbacks>
    7654:	00 
    7655:	0f 16 05 64 ad 01 00 	movhps 0x1ad64(%rip),%xmm0        # 223c0 <fwp_state>
    765c:	f3 0f 7e 0d 64 ad 01 	movq   0x1ad64(%rip),%xmm1        # 223c8 <fwp_handlers>
    7663:	00 
    7664:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    766b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7672:	0f 16 0d 5f ad 01 00 	movhps 0x1ad5f(%rip),%xmm1        # 223d8 <fwp_cleanups>
    7679:	f3 0f 7e 05 37 ad 01 	movq   0x1ad37(%rip),%xmm0        # 223b8 <fwp_state_len>
    7680:	00 
    7681:	0f 16 05 28 ad 01 00 	movhps 0x1ad28(%rip),%xmm0        # 223b0 <fwp_state_cap>
    7688:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    768f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7696:	48 8b 70 08          	mov    0x8(%rax),%rsi
    769a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    76a1:	48 89 0d 20 ad 01 00 	mov    %rcx,0x1ad20(%rip)        # 223c8 <fwp_handlers>
    76a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    76af:	48 89 0d 22 ad 01 00 	mov    %rcx,0x1ad22(%rip)        # 223d8 <fwp_cleanups>
    76b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    76bd:	48 89 0d 0c ad 01 00 	mov    %rcx,0x1ad0c(%rip)        # 223d0 <fwp_foreign_callbacks>
    76c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    76cb:	48 89 0d ee ac 01 00 	mov    %rcx,0x1acee(%rip)        # 223c0 <fwp_state>
    76d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    76d9:	48 89 0d d8 ac 01 00 	mov    %rcx,0x1acd8(%rip)        # 223b8 <fwp_state_len>
    76e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    76e7:	48 89 0d c2 ac 01 00 	mov    %rcx,0x1acc2(%rip)        # 223b0 <fwp_state_cap>
    76ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    76f5:	48 89 0d ac ac 01 00 	mov    %rcx,0x1acac(%rip)        # 223a8 <fwp_state_owners>
    76fc:	e8 6f bd ff ff       	call   3470 <swapcontext@plt>
    7701:	f3 0f 1e fa          	endbr64
    7705:	e8 d6 fc ff ff       	call   73e0 <fwp_free_zombie>
    770a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7710:	8b 05 e2 89 01 00    	mov    0x189e2(%rip),%eax        # 200f8 <fwp_slice>
    7716:	85 c0                	test   %eax,%eax
    7718:	74 36                	je     7750 <fwp_block+0x160>
    771a:	48 83 c4 08          	add    $0x8,%rsp
    771e:	c3                   	ret
    771f:	90                   	nop
    7720:	e8 eb d7 ff ff       	call   4f10 <fwp_poll_events>
    7725:	48 8b 05 dc 8f 01 00 	mov    0x18fdc(%rip),%rax        # 20708 <fwp_ready_head>
    772c:	48 85 c0             	test   %rax,%rax
    772f:	0f 85 db fe ff ff    	jne    7610 <fwp_block+0x20>
    7735:	eb e9                	jmp    7720 <fwp_block+0x130>
    7737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    773e:	00 00 
    7740:	48 c7 05 b5 8f 01 00 	movq   $0x0,0x18fb5(%rip)        # 20700 <fwp_ready_tail>
    7747:	00 00 00 00 
    774b:	e9 d7 fe ff ff       	jmp    7627 <fwp_block+0x37>
    7750:	48 8d 3d ca 49 00 00 	lea    0x49ca(%rip),%rdi        # c121 <_IO_stdin_used+0x121>
    7757:	e8 24 bc ff ff       	call   3380 <getenv@plt>
    775c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7761:	48 85 c0             	test   %rax,%rax
    7764:	74 05                	je     776b <fwp_block+0x17b>
    7766:	80 38 00             	cmpb   $0x0,(%rax)
    7769:	75 0b                	jne    7776 <fwp_block+0x186>
    776b:	89 15 87 89 01 00    	mov    %edx,0x18987(%rip)        # 200f8 <fwp_slice>
    7771:	48 83 c4 08          	add    $0x8,%rsp
    7775:	c3                   	ret
    7776:	ba 0a 00 00 00       	mov    $0xa,%edx
    777b:	31 f6                	xor    %esi,%esi
    777d:	48 89 c7             	mov    %rax,%rdi
    7780:	e8 ab bd ff ff       	call   3530 <strtoll@plt>
    7785:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7789:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7790:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7795:	0f 46 d0             	cmovbe %eax,%edx
    7798:	eb d1                	jmp    776b <fwp_block+0x17b>
    779a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000077a0 <fwp_caps173>:
    77a0:	f3 0f 1e fa          	endbr64
    77a4:	85 f6                	test   %esi,%esi
    77a6:	74 08                	je     77b0 <fwp_caps173+0x10>
    77a8:	c3                   	ret
    77a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77b0:	48 8b 15 61 a3 01 00 	mov    0x1a361(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    77b7:	48 89 f8             	mov    %rdi,%rax
    77ba:	48 2b 05 2f a3 01 00 	sub    0x1a32f(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    77c1:	48 c1 e2 10          	shl    $0x10,%rdx
    77c5:	48 39 d0             	cmp    %rdx,%rax
    77c8:	73 de                	jae    77a8 <fwp_caps173+0x8>
    77ca:	48 89 c2             	mov    %rax,%rdx
    77cd:	48 c1 ea 10          	shr    $0x10,%rdx
    77d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77d5:	48 8b 15 5c a3 01 00 	mov    0x1a35c(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    77dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    77e4:	48 85 c9             	test   %rcx,%rcx
    77e7:	74 bf                	je     77a8 <fwp_caps173+0x8>
    77e9:	0f b6 32             	movzbl (%rdx),%esi
    77ec:	40 80 fe 02          	cmp    $0x2,%sil
    77f0:	74 2e                	je     7820 <fwp_caps173+0x80>
    77f2:	40 80 fe 01          	cmp    $0x1,%sil
    77f6:	75 b0                	jne    77a8 <fwp_caps173+0x8>
    77f8:	8b 72 18             	mov    0x18(%rdx),%esi
    77fb:	0f b7 c0             	movzwl %ax,%eax
    77fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7801:	48 0f af c6          	imul   %rsi,%rax
    7805:	48 c1 e8 20          	shr    $0x20,%rax
    7809:	48 39 d0             	cmp    %rdx,%rax
    780c:	73 9a                	jae    77a8 <fwp_caps173+0x8>
    780e:	48 01 c1             	add    %rax,%rcx
    7811:	80 39 01             	cmpb   $0x1,(%rcx)
    7814:	75 92                	jne    77a8 <fwp_caps173+0x8>
    7816:	e9 f5 dc ff ff       	jmp    5510 <fwp_mem_free>
    781b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7820:	66 85 c0             	test   %ax,%ax
    7823:	74 ec                	je     7811 <fwp_caps173+0x71>
    7825:	c3                   	ret
    7826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    782d:	00 00 00 

0000000000007830 <fwp_args37>:
    7830:	f3 0f 1e fa          	endbr64
    7834:	85 d2                	test   %edx,%edx
    7836:	74 04                	je     783c <fwp_args37+0xc>
    7838:	85 f6                	test   %esi,%esi
    783a:	74 04                	je     7840 <fwp_args37+0x10>
    783c:	c3                   	ret
    783d:	0f 1f 00             	nopl   (%rax)
    7840:	48 8b 15 d1 a2 01 00 	mov    0x1a2d1(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    7847:	48 8b 07             	mov    (%rdi),%rax
    784a:	48 2b 05 9f a2 01 00 	sub    0x1a29f(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    7851:	48 c1 e2 10          	shl    $0x10,%rdx
    7855:	48 39 d0             	cmp    %rdx,%rax
    7858:	73 e2                	jae    783c <fwp_args37+0xc>
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 10          	shr    $0x10,%rdx
    7861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7865:	48 8b 15 cc a2 01 00 	mov    0x1a2cc(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    786c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7870:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7874:	48 85 ff             	test   %rdi,%rdi
    7877:	74 c3                	je     783c <fwp_args37+0xc>
    7879:	0f b6 0a             	movzbl (%rdx),%ecx
    787c:	80 f9 02             	cmp    $0x2,%cl
    787f:	74 2f                	je     78b0 <fwp_args37+0x80>
    7881:	80 f9 01             	cmp    $0x1,%cl
    7884:	75 b6                	jne    783c <fwp_args37+0xc>
    7886:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7889:	0f b7 c0             	movzwl %ax,%eax
    788c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    788f:	48 0f af c1          	imul   %rcx,%rax
    7893:	48 c1 e8 20          	shr    $0x20,%rax
    7897:	48 39 d0             	cmp    %rdx,%rax
    789a:	73 a0                	jae    783c <fwp_args37+0xc>
    789c:	48 01 c7             	add    %rax,%rdi
    789f:	0f b6 07             	movzbl (%rdi),%eax
    78a2:	84 c0                	test   %al,%al
    78a4:	74 96                	je     783c <fwp_args37+0xc>
    78a6:	3c fd                	cmp    $0xfd,%al
    78a8:	77 0c                	ja     78b6 <fwp_args37+0x86>
    78aa:	83 c0 01             	add    $0x1,%eax
    78ad:	88 07                	mov    %al,(%rdi)
    78af:	c3                   	ret
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 ea                	je     789f <fwp_args37+0x6f>
    78b5:	c3                   	ret
    78b6:	e9 f5 d8 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    78bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078c0 <fwp_caps37>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	48 83 ec 18          	sub    $0x18,%rsp
    78c8:	8b 57 04             	mov    0x4(%rdi),%edx
    78cb:	48 89 f8             	mov    %rdi,%rax
    78ce:	85 d2                	test   %edx,%edx
    78d0:	0f 84 9a 00 00 00    	je     7970 <fwp_caps37+0xb0>
    78d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    78da:	85 f6                	test   %esi,%esi
    78dc:	0f 85 9e 00 00 00    	jne    7980 <fwp_caps37+0xc0>
    78e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    78e7:	e8 54 f7 ff ff       	call   7040 <fwp_drop4>
    78ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78f1:	48 8b 0d 20 a2 01 00 	mov    0x1a220(%rip),%rcx        # 21b18 <fwp_heap+0x13d8>
    78f8:	48 89 c2             	mov    %rax,%rdx
    78fb:	48 2b 15 ee a1 01 00 	sub    0x1a1ee(%rip),%rdx        # 21af0 <fwp_heap+0x13b0>
    7902:	48 c1 e1 10          	shl    $0x10,%rcx
    7906:	48 39 ca             	cmp    %rcx,%rdx
    7909:	73 6d                	jae    7978 <fwp_caps37+0xb8>
    790b:	48 89 d1             	mov    %rdx,%rcx
    790e:	48 c1 e9 10          	shr    $0x10,%rcx
    7912:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7916:	48 8b 0d 1b a2 01 00 	mov    0x1a21b(%rip),%rcx        # 21b38 <fwp_heap+0x13f8>
    791d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7921:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7925:	48 85 f6             	test   %rsi,%rsi
    7928:	74 4e                	je     7978 <fwp_caps37+0xb8>
    792a:	0f b6 39             	movzbl (%rcx),%edi
    792d:	40 80 ff 02          	cmp    $0x2,%dil
    7931:	0f 84 b9 00 00 00    	je     79f0 <fwp_caps37+0x130>
    7937:	40 80 ff 01          	cmp    $0x1,%dil
    793b:	75 3b                	jne    7978 <fwp_caps37+0xb8>
    793d:	8b 79 18             	mov    0x18(%rcx),%edi
    7940:	0f b7 d2             	movzwl %dx,%edx
    7943:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7946:	48 0f af d7          	imul   %rdi,%rdx
    794a:	48 c1 ea 20          	shr    $0x20,%rdx
    794e:	48 39 ca             	cmp    %rcx,%rdx
    7951:	73 25                	jae    7978 <fwp_caps37+0xb8>
    7953:	48 01 d6             	add    %rdx,%rsi
    7956:	80 3e 01             	cmpb   $0x1,(%rsi)
    7959:	75 1d                	jne    7978 <fwp_caps37+0xb8>
    795b:	48 89 c7             	mov    %rax,%rdi
    795e:	48 83 c4 18          	add    $0x18,%rsp
    7962:	e9 a9 db ff ff       	jmp    5510 <fwp_mem_free>
    7967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    796e:	00 00 
    7970:	85 f6                	test   %esi,%esi
    7972:	0f 84 79 ff ff ff    	je     78f1 <fwp_caps37+0x31>
    7978:	48 83 c4 18          	add    $0x18,%rsp
    797c:	c3                   	ret
    797d:	0f 1f 00             	nopl   (%rax)
    7980:	48 8b 05 91 a1 01 00 	mov    0x1a191(%rip),%rax        # 21b18 <fwp_heap+0x13d8>
    7987:	48 2b 3d 62 a1 01 00 	sub    0x1a162(%rip),%rdi        # 21af0 <fwp_heap+0x13b0>
    798e:	48 c1 e0 10          	shl    $0x10,%rax
    7992:	48 39 c7             	cmp    %rax,%rdi
    7995:	73 e1                	jae    7978 <fwp_caps37+0xb8>
    7997:	48 89 f8             	mov    %rdi,%rax
    799a:	48 c1 e8 10          	shr    $0x10,%rax
    799e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    79a2:	48 8b 05 8f a1 01 00 	mov    0x1a18f(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    79a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    79ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    79b1:	48 85 c0             	test   %rax,%rax
    79b4:	74 c2                	je     7978 <fwp_caps37+0xb8>
    79b6:	0f b6 0a             	movzbl (%rdx),%ecx
    79b9:	80 f9 02             	cmp    $0x2,%cl
    79bc:	74 42                	je     7a00 <fwp_caps37+0x140>
    79be:	80 f9 01             	cmp    $0x1,%cl
    79c1:	75 b5                	jne    7978 <fwp_caps37+0xb8>
    79c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79c6:	0f b7 ff             	movzwl %di,%edi
    79c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79cc:	48 0f af f9          	imul   %rcx,%rdi
    79d0:	48 c1 ef 20          	shr    $0x20,%rdi
    79d4:	48 39 d7             	cmp    %rdx,%rdi
    79d7:	73 9f                	jae    7978 <fwp_caps37+0xb8>
    79d9:	48 01 f8             	add    %rdi,%rax
    79dc:	0f b6 10             	movzbl (%rax),%edx
    79df:	84 d2                	test   %dl,%dl
    79e1:	74 95                	je     7978 <fwp_caps37+0xb8>
    79e3:	80 fa fd             	cmp    $0xfd,%dl
    79e6:	77 23                	ja     7a0b <fwp_caps37+0x14b>
    79e8:	83 c2 01             	add    $0x1,%edx
    79eb:	88 10                	mov    %dl,(%rax)
    79ed:	eb 89                	jmp    7978 <fwp_caps37+0xb8>
    79ef:	90                   	nop
    79f0:	66 85 d2             	test   %dx,%dx
    79f3:	0f 85 7f ff ff ff    	jne    7978 <fwp_caps37+0xb8>
    79f9:	e9 58 ff ff ff       	jmp    7956 <fwp_caps37+0x96>
    79fe:	66 90                	xchg   %ax,%ax
    7a00:	66 85 ff             	test   %di,%di
    7a03:	0f 85 6f ff ff ff    	jne    7978 <fwp_caps37+0xb8>
    7a09:	eb d1                	jmp    79dc <fwp_caps37+0x11c>
    7a0b:	48 89 c7             	mov    %rax,%rdi
    7a0e:	48 83 c4 18          	add    $0x18,%rsp
    7a12:	e9 99 d7 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    7a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a1e:	00 00 

0000000000007a20 <fwp_drop0>:
    7a20:	f3 0f 1e fa          	endbr64
    7a24:	48 8b 15 ed a0 01 00 	mov    0x1a0ed(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    7a2b:	48 89 f8             	mov    %rdi,%rax
    7a2e:	48 2b 05 bb a0 01 00 	sub    0x1a0bb(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    7a35:	48 c1 e2 10          	shl    $0x10,%rdx
    7a39:	48 39 d0             	cmp    %rdx,%rax
    7a3c:	0f 83 36 01 00 00    	jae    7b78 <fwp_drop0+0x158>
    7a42:	48 83 ec 18          	sub    $0x18,%rsp
    7a46:	48 8d 35 f3 8c 01 00 	lea    0x18cf3(%rip),%rsi        # 20740 <fwp_heap>
    7a4d:	48 89 c2             	mov    %rax,%rdx
    7a50:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7a57:	48 c1 ea 10          	shr    $0x10,%rdx
    7a5b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a5f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7a63:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a67:	48 85 d2             	test   %rdx,%rdx
    7a6a:	74 42                	je     7aae <fwp_drop0+0x8e>
    7a6c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7a70:	41 80 f8 02          	cmp    $0x2,%r8b
    7a74:	74 42                	je     7ab8 <fwp_drop0+0x98>
    7a76:	41 80 f8 01          	cmp    $0x1,%r8b
    7a7a:	75 32                	jne    7aae <fwp_drop0+0x8e>
    7a7c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7a80:	0f b7 c0             	movzwl %ax,%eax
    7a83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a86:	49 0f af c0          	imul   %r8,%rax
    7a8a:	48 c1 e8 20          	shr    $0x20,%rax
    7a8e:	48 39 c8             	cmp    %rcx,%rax
    7a91:	73 1b                	jae    7aae <fwp_drop0+0x8e>
    7a93:	48 01 c2             	add    %rax,%rdx
    7a96:	0f b6 02             	movzbl (%rdx),%eax
    7a99:	84 c0                	test   %al,%al
    7a9b:	74 11                	je     7aae <fwp_drop0+0x8e>
    7a9d:	3c 01                	cmp    $0x1,%al
    7a9f:	74 27                	je     7ac8 <fwp_drop0+0xa8>
    7aa1:	3c ff                	cmp    $0xff,%al
    7aa3:	0f 84 e7 00 00 00    	je     7b90 <fwp_drop0+0x170>
    7aa9:	83 e8 01             	sub    $0x1,%eax
    7aac:	88 02                	mov    %al,(%rdx)
    7aae:	48 83 c4 18          	add    $0x18,%rsp
    7ab2:	c3                   	ret
    7ab3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ab8:	66 85 c0             	test   %ax,%ax
    7abb:	74 d9                	je     7a96 <fwp_drop0+0x76>
    7abd:	48 83 c4 18          	add    $0x18,%rsp
    7ac1:	c3                   	ret
    7ac2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ac8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7acf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ad6:	48 89 f8             	mov    %rdi,%rax
    7ad9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7add:	48 29 c8             	sub    %rcx,%rax
    7ae0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ae4:	48 39 d0             	cmp    %rdx,%rax
    7ae7:	73 71                	jae    7b5a <fwp_drop0+0x13a>
    7ae9:	49 89 c2             	mov    %rax,%r10
    7aec:	49 c1 ea 10          	shr    $0x10,%r10
    7af0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7af4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7af8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7afc:	4d 85 d2             	test   %r10,%r10
    7aff:	74 59                	je     7b5a <fwp_drop0+0x13a>
    7b01:	45 0f b6 19          	movzbl (%r9),%r11d
    7b05:	41 80 fb 02          	cmp    $0x2,%r11b
    7b09:	74 75                	je     7b80 <fwp_drop0+0x160>
    7b0b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b0f:	75 49                	jne    7b5a <fwp_drop0+0x13a>
    7b11:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7b15:	0f b7 c0             	movzwl %ax,%eax
    7b18:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7b1c:	49 0f af c3          	imul   %r11,%rax
    7b20:	48 c1 e8 20          	shr    $0x20,%rax
    7b24:	4c 39 c8             	cmp    %r9,%rax
    7b27:	73 31                	jae    7b5a <fwp_drop0+0x13a>
    7b29:	49 01 c2             	add    %rax,%r10
    7b2c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b30:	75 28                	jne    7b5a <fwp_drop0+0x13a>
    7b32:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7b37:	e8 d4 d9 ff ff       	call   5510 <fwp_mem_free>
    7b3c:	48 8d 35 fd 8b 01 00 	lea    0x18bfd(%rip),%rsi        # 20740 <fwp_heap>
    7b43:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7b48:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b4f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b56:	48 c1 e2 10          	shl    $0x10,%rdx
    7b5a:	4c 89 c0             	mov    %r8,%rax
    7b5d:	48 29 c8             	sub    %rcx,%rax
    7b60:	48 39 d0             	cmp    %rdx,%rax
    7b63:	0f 83 45 ff ff ff    	jae    7aae <fwp_drop0+0x8e>
    7b69:	4c 89 c7             	mov    %r8,%rdi
    7b6c:	e9 dc fe ff ff       	jmp    7a4d <fwp_drop0+0x2d>
    7b71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b78:	c3                   	ret
    7b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b80:	66 85 c0             	test   %ax,%ax
    7b83:	75 d5                	jne    7b5a <fwp_drop0+0x13a>
    7b85:	eb a5                	jmp    7b2c <fwp_drop0+0x10c>
    7b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b8e:	00 00 
    7b90:	48 89 d0             	mov    %rdx,%rax
    7b93:	48 c1 e8 11          	shr    $0x11,%rax
    7b97:	48 31 d0             	xor    %rdx,%rax
    7b9a:	48 89 c1             	mov    %rax,%rcx
    7b9d:	48 c1 e9 09          	shr    $0x9,%rcx
    7ba1:	48 31 c8             	xor    %rcx,%rax
    7ba4:	0f b6 c8             	movzbl %al,%ecx
    7ba7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7bae:	00 
    7baf:	48 85 c0             	test   %rax,%rax
    7bb2:	75 15                	jne    7bc9 <fwp_drop0+0x1a9>
    7bb4:	eb 4e                	jmp    7c04 <fwp_drop0+0x1e4>
    7bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bbd:	00 00 00 
    7bc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7bc4:	48 85 c0             	test   %rax,%rax
    7bc7:	74 3b                	je     7c04 <fwp_drop0+0x1e4>
    7bc9:	48 89 c1             	mov    %rax,%rcx
    7bcc:	48 39 10             	cmp    %rdx,(%rax)
    7bcf:	75 ef                	jne    7bc0 <fwp_drop0+0x1a0>
    7bd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7be4:	0f 85 c4 fe ff ff    	jne    7aae <fwp_drop0+0x8e>
    7bea:	48 89 d7             	mov    %rdx,%rdi
    7bed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bf2:	e8 d9 d6 ff ff       	call   52d0 <fwp_rc_forget_slot>
    7bf7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7bff:	e9 aa fe ff ff       	jmp    7aae <fwp_drop0+0x8e>
    7c04:	48 8d 3d 95 4b 00 00 	lea    0x4b95(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    7c0b:	e8 50 c5 ff ff       	call   4160 <fwp_trap>

0000000000007c10 <fwp_drop1>:
    7c10:	f3 0f 1e fa          	endbr64
    7c14:	48 8b 15 fd 9e 01 00 	mov    0x19efd(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    7c1b:	48 89 f8             	mov    %rdi,%rax
    7c1e:	48 2b 05 cb 9e 01 00 	sub    0x19ecb(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    7c25:	48 c1 e2 10          	shl    $0x10,%rdx
    7c29:	48 39 d0             	cmp    %rdx,%rax
    7c2c:	0f 83 36 01 00 00    	jae    7d68 <fwp_drop1+0x158>
    7c32:	48 83 ec 18          	sub    $0x18,%rsp
    7c36:	48 8d 35 03 8b 01 00 	lea    0x18b03(%rip),%rsi        # 20740 <fwp_heap>
    7c3d:	48 89 c2             	mov    %rax,%rdx
    7c40:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7c47:	48 c1 ea 10          	shr    $0x10,%rdx
    7c4b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c4f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7c53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c57:	48 85 d2             	test   %rdx,%rdx
    7c5a:	74 42                	je     7c9e <fwp_drop1+0x8e>
    7c5c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7c60:	41 80 f8 02          	cmp    $0x2,%r8b
    7c64:	74 42                	je     7ca8 <fwp_drop1+0x98>
    7c66:	41 80 f8 01          	cmp    $0x1,%r8b
    7c6a:	75 32                	jne    7c9e <fwp_drop1+0x8e>
    7c6c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7c70:	0f b7 c0             	movzwl %ax,%eax
    7c73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c76:	49 0f af c0          	imul   %r8,%rax
    7c7a:	48 c1 e8 20          	shr    $0x20,%rax
    7c7e:	48 39 c8             	cmp    %rcx,%rax
    7c81:	73 1b                	jae    7c9e <fwp_drop1+0x8e>
    7c83:	48 01 c2             	add    %rax,%rdx
    7c86:	0f b6 02             	movzbl (%rdx),%eax
    7c89:	84 c0                	test   %al,%al
    7c8b:	74 11                	je     7c9e <fwp_drop1+0x8e>
    7c8d:	3c 01                	cmp    $0x1,%al
    7c8f:	74 27                	je     7cb8 <fwp_drop1+0xa8>
    7c91:	3c ff                	cmp    $0xff,%al
    7c93:	0f 84 e7 00 00 00    	je     7d80 <fwp_drop1+0x170>
    7c99:	83 e8 01             	sub    $0x1,%eax
    7c9c:	88 02                	mov    %al,(%rdx)
    7c9e:	48 83 c4 18          	add    $0x18,%rsp
    7ca2:	c3                   	ret
    7ca3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ca8:	66 85 c0             	test   %ax,%ax
    7cab:	74 d9                	je     7c86 <fwp_drop1+0x76>
    7cad:	48 83 c4 18          	add    $0x18,%rsp
    7cb1:	c3                   	ret
    7cb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cb8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cbf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7cc6:	48 89 f8             	mov    %rdi,%rax
    7cc9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7ccd:	48 29 c8             	sub    %rcx,%rax
    7cd0:	48 c1 e2 10          	shl    $0x10,%rdx
    7cd4:	48 39 d0             	cmp    %rdx,%rax
    7cd7:	73 71                	jae    7d4a <fwp_drop1+0x13a>
    7cd9:	49 89 c2             	mov    %rax,%r10
    7cdc:	49 c1 ea 10          	shr    $0x10,%r10
    7ce0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ce4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7ce8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7cec:	4d 85 d2             	test   %r10,%r10
    7cef:	74 59                	je     7d4a <fwp_drop1+0x13a>
    7cf1:	45 0f b6 19          	movzbl (%r9),%r11d
    7cf5:	41 80 fb 02          	cmp    $0x2,%r11b
    7cf9:	74 75                	je     7d70 <fwp_drop1+0x160>
    7cfb:	41 80 fb 01          	cmp    $0x1,%r11b
    7cff:	75 49                	jne    7d4a <fwp_drop1+0x13a>
    7d01:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d05:	0f b7 c0             	movzwl %ax,%eax
    7d08:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d0c:	49 0f af c3          	imul   %r11,%rax
    7d10:	48 c1 e8 20          	shr    $0x20,%rax
    7d14:	4c 39 c8             	cmp    %r9,%rax
    7d17:	73 31                	jae    7d4a <fwp_drop1+0x13a>
    7d19:	49 01 c2             	add    %rax,%r10
    7d1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d20:	75 28                	jne    7d4a <fwp_drop1+0x13a>
    7d22:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7d27:	e8 e4 d7 ff ff       	call   5510 <fwp_mem_free>
    7d2c:	48 8d 35 0d 8a 01 00 	lea    0x18a0d(%rip),%rsi        # 20740 <fwp_heap>
    7d33:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7d38:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d3f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d46:	48 c1 e2 10          	shl    $0x10,%rdx
    7d4a:	4c 89 c0             	mov    %r8,%rax
    7d4d:	48 29 c8             	sub    %rcx,%rax
    7d50:	48 39 d0             	cmp    %rdx,%rax
    7d53:	0f 83 45 ff ff ff    	jae    7c9e <fwp_drop1+0x8e>
    7d59:	4c 89 c7             	mov    %r8,%rdi
    7d5c:	e9 dc fe ff ff       	jmp    7c3d <fwp_drop1+0x2d>
    7d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d68:	c3                   	ret
    7d69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d70:	66 85 c0             	test   %ax,%ax
    7d73:	75 d5                	jne    7d4a <fwp_drop1+0x13a>
    7d75:	eb a5                	jmp    7d1c <fwp_drop1+0x10c>
    7d77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d7e:	00 00 
    7d80:	48 89 d0             	mov    %rdx,%rax
    7d83:	48 c1 e8 11          	shr    $0x11,%rax
    7d87:	48 31 d0             	xor    %rdx,%rax
    7d8a:	48 89 c1             	mov    %rax,%rcx
    7d8d:	48 c1 e9 09          	shr    $0x9,%rcx
    7d91:	48 31 c8             	xor    %rcx,%rax
    7d94:	0f b6 c8             	movzbl %al,%ecx
    7d97:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7d9e:	00 
    7d9f:	48 85 c0             	test   %rax,%rax
    7da2:	75 25                	jne    7dc9 <fwp_drop1+0x1b9>
    7da4:	eb 5e                	jmp    7e04 <fwp_drop1+0x1f4>
    7da6:	0f 1f 40 00          	nopl   0x0(%rax)
    7daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7db1:	00 00 00 00 
    7db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dbc:	00 00 00 00 
    7dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7dc4:	48 85 c0             	test   %rax,%rax
    7dc7:	74 3b                	je     7e04 <fwp_drop1+0x1f4>
    7dc9:	48 89 c1             	mov    %rax,%rcx
    7dcc:	48 39 10             	cmp    %rdx,(%rax)
    7dcf:	75 ef                	jne    7dc0 <fwp_drop1+0x1b0>
    7dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7de4:	0f 85 b4 fe ff ff    	jne    7c9e <fwp_drop1+0x8e>
    7dea:	48 89 d7             	mov    %rdx,%rdi
    7ded:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7df2:	e8 d9 d4 ff ff       	call   52d0 <fwp_rc_forget_slot>
    7df7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7dfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7dff:	e9 9a fe ff ff       	jmp    7c9e <fwp_drop1+0x8e>
    7e04:	48 8d 3d 95 49 00 00 	lea    0x4995(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    7e0b:	e8 50 c3 ff ff       	call   4160 <fwp_trap>

0000000000007e10 <fwp_drop10>:
    7e10:	48 8b 0d 01 9d 01 00 	mov    0x19d01(%rip),%rcx        # 21b18 <fwp_heap+0x13d8>
    7e17:	48 89 f8             	mov    %rdi,%rax
    7e1a:	48 2b 05 cf 9c 01 00 	sub    0x19ccf(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    7e21:	48 c1 e1 10          	shl    $0x10,%rcx
    7e25:	48 39 c8             	cmp    %rcx,%rax
    7e28:	0f 83 c2 01 00 00    	jae    7ff0 <fwp_drop10+0x1e0>
    7e2e:	48 83 ec 18          	sub    $0x18,%rsp
    7e32:	48 89 fa             	mov    %rdi,%rdx
    7e35:	48 8d 35 04 89 01 00 	lea    0x18904(%rip),%rsi        # 20740 <fwp_heap>
    7e3c:	48 89 c1             	mov    %rax,%rcx
    7e3f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7e46:	48 c1 e9 10          	shr    $0x10,%rcx
    7e4a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e4e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7e52:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7e56:	48 85 c9             	test   %rcx,%rcx
    7e59:	74 46                	je     7ea1 <fwp_drop10+0x91>
    7e5b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7e5f:	41 80 f9 02          	cmp    $0x2,%r9b
    7e63:	0f 84 d7 00 00 00    	je     7f40 <fwp_drop10+0x130>
    7e69:	41 80 f9 01          	cmp    $0x1,%r9b
    7e6d:	75 32                	jne    7ea1 <fwp_drop10+0x91>
    7e6f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7e73:	0f b7 c0             	movzwl %ax,%eax
    7e76:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7e79:	49 0f af c1          	imul   %r9,%rax
    7e7d:	48 c1 e8 20          	shr    $0x20,%rax
    7e81:	48 39 f8             	cmp    %rdi,%rax
    7e84:	73 1b                	jae    7ea1 <fwp_drop10+0x91>
    7e86:	48 01 c1             	add    %rax,%rcx
    7e89:	0f b6 01             	movzbl (%rcx),%eax
    7e8c:	84 c0                	test   %al,%al
    7e8e:	74 11                	je     7ea1 <fwp_drop10+0x91>
    7e90:	3c 01                	cmp    $0x1,%al
    7e92:	74 1c                	je     7eb0 <fwp_drop10+0xa0>
    7e94:	3c ff                	cmp    $0xff,%al
    7e96:	0f 84 5c 01 00 00    	je     7ff8 <fwp_drop10+0x1e8>
    7e9c:	83 e8 01             	sub    $0x1,%eax
    7e9f:	88 01                	mov    %al,(%rcx)
    7ea1:	48 83 c4 18          	add    $0x18,%rsp
    7ea5:	c3                   	ret
    7ea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ead:	00 00 00 
    7eb0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7eb7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7ebe:	48 89 d0             	mov    %rdx,%rax
    7ec1:	49 89 d1             	mov    %rdx,%r9
    7ec4:	48 c1 e1 10          	shl    $0x10,%rcx
    7ec8:	48 29 f8             	sub    %rdi,%rax
    7ecb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7ecf:	78 7f                	js     7f50 <fwp_drop10+0x140>
    7ed1:	48 39 c8             	cmp    %rcx,%rax
    7ed4:	73 cb                	jae    7ea1 <fwp_drop10+0x91>
    7ed6:	48 89 c1             	mov    %rax,%rcx
    7ed9:	48 c1 e9 10          	shr    $0x10,%rcx
    7edd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ee1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7ee5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ee9:	48 85 f6             	test   %rsi,%rsi
    7eec:	74 b3                	je     7ea1 <fwp_drop10+0x91>
    7eee:	0f b6 39             	movzbl (%rcx),%edi
    7ef1:	40 80 ff 02          	cmp    $0x2,%dil
    7ef5:	74 39                	je     7f30 <fwp_drop10+0x120>
    7ef7:	40 80 ff 01          	cmp    $0x1,%dil
    7efb:	75 a4                	jne    7ea1 <fwp_drop10+0x91>
    7efd:	8b 79 18             	mov    0x18(%rcx),%edi
    7f00:	0f b7 c0             	movzwl %ax,%eax
    7f03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f06:	48 0f af c7          	imul   %rdi,%rax
    7f0a:	48 c1 e8 20          	shr    $0x20,%rax
    7f0e:	48 39 c8             	cmp    %rcx,%rax
    7f11:	73 8e                	jae    7ea1 <fwp_drop10+0x91>
    7f13:	48 01 c6             	add    %rax,%rsi
    7f16:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f19:	75 86                	jne    7ea1 <fwp_drop10+0x91>
    7f1b:	48 89 d7             	mov    %rdx,%rdi
    7f1e:	48 83 c4 18          	add    $0x18,%rsp
    7f22:	e9 e9 d5 ff ff       	jmp    5510 <fwp_mem_free>
    7f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f2e:	00 00 
    7f30:	66 85 c0             	test   %ax,%ax
    7f33:	74 e1                	je     7f16 <fwp_drop10+0x106>
    7f35:	48 83 c4 18          	add    $0x18,%rsp
    7f39:	c3                   	ret
    7f3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f40:	66 85 c0             	test   %ax,%ax
    7f43:	0f 84 40 ff ff ff    	je     7e89 <fwp_drop10+0x79>
    7f49:	48 83 c4 18          	add    $0x18,%rsp
    7f4d:	c3                   	ret
    7f4e:	66 90                	xchg   %ax,%ax
    7f50:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7f54:	48 39 c8             	cmp    %rcx,%rax
    7f57:	73 74                	jae    7fcd <fwp_drop10+0x1bd>
    7f59:	49 89 c2             	mov    %rax,%r10
    7f5c:	49 c1 ea 10          	shr    $0x10,%r10
    7f60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7f64:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7f68:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7f6c:	4d 85 d2             	test   %r10,%r10
    7f6f:	74 5c                	je     7fcd <fwp_drop10+0x1bd>
    7f71:	45 0f b6 18          	movzbl (%r8),%r11d
    7f75:	41 80 fb 02          	cmp    $0x2,%r11b
    7f79:	74 6d                	je     7fe8 <fwp_drop10+0x1d8>
    7f7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7f7f:	75 4c                	jne    7fcd <fwp_drop10+0x1bd>
    7f81:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7f85:	0f b7 c0             	movzwl %ax,%eax
    7f88:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7f8c:	49 0f af c3          	imul   %r11,%rax
    7f90:	48 c1 e8 20          	shr    $0x20,%rax
    7f94:	4c 39 c0             	cmp    %r8,%rax
    7f97:	73 34                	jae    7fcd <fwp_drop10+0x1bd>
    7f99:	49 01 c2             	add    %rax,%r10
    7f9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7fa0:	75 2b                	jne    7fcd <fwp_drop10+0x1bd>
    7fa2:	4c 89 cf             	mov    %r9,%rdi
    7fa5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7faa:	e8 61 d5 ff ff       	call   5510 <fwp_mem_free>
    7faf:	48 8d 35 8a 87 01 00 	lea    0x1878a(%rip),%rsi        # 20740 <fwp_heap>
    7fb6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7fbb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7fc2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7fc9:	48 c1 e1 10          	shl    $0x10,%rcx
    7fcd:	48 89 d0             	mov    %rdx,%rax
    7fd0:	48 29 f8             	sub    %rdi,%rax
    7fd3:	48 39 c8             	cmp    %rcx,%rax
    7fd6:	0f 82 60 fe ff ff    	jb     7e3c <fwp_drop10+0x2c>
    7fdc:	e9 c0 fe ff ff       	jmp    7ea1 <fwp_drop10+0x91>
    7fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fe8:	66 85 c0             	test   %ax,%ax
    7feb:	75 e0                	jne    7fcd <fwp_drop10+0x1bd>
    7fed:	eb ad                	jmp    7f9c <fwp_drop10+0x18c>
    7fef:	90                   	nop
    7ff0:	c3                   	ret
    7ff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ff8:	48 89 c8             	mov    %rcx,%rax
    7ffb:	48 c1 e8 11          	shr    $0x11,%rax
    7fff:	48 31 c8             	xor    %rcx,%rax
    8002:	48 89 c2             	mov    %rax,%rdx
    8005:	48 c1 ea 09          	shr    $0x9,%rdx
    8009:	48 31 d0             	xor    %rdx,%rax
    800c:	0f b6 d0             	movzbl %al,%edx
    800f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8016:	00 
    8017:	48 85 c0             	test   %rax,%rax
    801a:	75 0d                	jne    8029 <fwp_drop10+0x219>
    801c:	eb 46                	jmp    8064 <fwp_drop10+0x254>
    801e:	66 90                	xchg   %ax,%ax
    8020:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8024:	48 85 c0             	test   %rax,%rax
    8027:	74 3b                	je     8064 <fwp_drop10+0x254>
    8029:	48 89 c2             	mov    %rax,%rdx
    802c:	48 39 08             	cmp    %rcx,(%rax)
    802f:	75 ef                	jne    8020 <fwp_drop10+0x210>
    8031:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8035:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8039:	48 89 50 08          	mov    %rdx,0x8(%rax)
    803d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8044:	0f 85 57 fe ff ff    	jne    7ea1 <fwp_drop10+0x91>
    804a:	48 89 cf             	mov    %rcx,%rdi
    804d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8052:	e8 79 d2 ff ff       	call   52d0 <fwp_rc_forget_slot>
    8057:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    805c:	c6 01 fe             	movb   $0xfe,(%rcx)
    805f:	e9 3d fe ff ff       	jmp    7ea1 <fwp_drop10+0x91>
    8064:	48 8d 3d 35 47 00 00 	lea    0x4735(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    806b:	e8 f0 c0 ff ff       	call   4160 <fwp_trap>

0000000000008070 <f37>:
    8070:	41 57                	push   %r15
    8072:	41 56                	push   %r14
    8074:	41 55                	push   %r13
    8076:	41 54                	push   %r12
    8078:	55                   	push   %rbp
    8079:	53                   	push   %rbx
    807a:	48 83 ec 48          	sub    $0x48,%rsp
    807e:	48 8b 15 93 9a 01 00 	mov    0x19a93(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    8085:	48 89 3c 24          	mov    %rdi,(%rsp)
    8089:	48 c1 e2 10          	shl    $0x10,%rdx
    808d:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8094:	00 00 
    8096:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    809b:	48 8b 0d 4e 9a 01 00 	mov    0x19a4e(%rip),%rcx        # 21af0 <fwp_heap+0x13b0>
    80a2:	48 85 ff             	test   %rdi,%rdi
    80a5:	0f 84 e3 02 00 00    	je     838e <f37+0x31e>
    80ab:	48 8b 04 24          	mov    (%rsp),%rax
    80af:	48 8b 58 10          	mov    0x10(%rax),%rbx
    80b3:	48 89 d8             	mov    %rbx,%rax
    80b6:	48 29 c8             	sub    %rcx,%rax
    80b9:	48 39 d0             	cmp    %rdx,%rax
    80bc:	0f 83 8e 03 00 00    	jae    8450 <f37+0x3e0>
    80c2:	48 89 c2             	mov    %rax,%rdx
    80c5:	48 c1 ea 10          	shr    $0x10,%rdx
    80c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80cd:	48 8b 15 64 9a 01 00 	mov    0x19a64(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    80d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80d8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80dc:	48 85 ff             	test   %rdi,%rdi
    80df:	0f 84 6b 03 00 00    	je     8450 <f37+0x3e0>
    80e5:	0f b6 0a             	movzbl (%rdx),%ecx
    80e8:	80 f9 02             	cmp    $0x2,%cl
    80eb:	0f 84 77 02 00 00    	je     8368 <f37+0x2f8>
    80f1:	80 f9 01             	cmp    $0x1,%cl
    80f4:	75 24                	jne    811a <f37+0xaa>
    80f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80f9:	0f b7 c0             	movzwl %ax,%eax
    80fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80ff:	48 0f af c1          	imul   %rcx,%rax
    8103:	48 c1 e8 20          	shr    $0x20,%rax
    8107:	48 39 d0             	cmp    %rdx,%rax
    810a:	73 0e                	jae    811a <f37+0xaa>
    810c:	48 01 c7             	add    %rax,%rdi
    810f:	0f b6 07             	movzbl (%rdi),%eax
    8112:	84 c0                	test   %al,%al
    8114:	0f 85 e6 02 00 00    	jne    8400 <f37+0x390>
    811a:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    811f:	48 8b 04 24          	mov    (%rsp),%rax
    8123:	48 8b 58 10          	mov    0x10(%rax),%rbx
    8127:	ba 01 00 00 00       	mov    $0x1,%edx
    812c:	48 85 db             	test   %rbx,%rbx
    812f:	74 1c                	je     814d <f37+0xdd>
    8131:	0f 1f 40 00          	nopl   0x0(%rax)
    8135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    813c:	00 00 00 00 
    8140:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8144:	48 83 c2 01          	add    $0x1,%rdx
    8148:	48 85 db             	test   %rbx,%rbx
    814b:	75 f3                	jne    8140 <f37+0xd0>
    814d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8152:	48 85 c0             	test   %rax,%rax
    8155:	0f 84 25 03 00 00    	je     8480 <f37+0x410>
    815b:	31 db                	xor    %ebx,%ebx
    815d:	0f 1f 00             	nopl   (%rax)
    8160:	48 8b 40 10          	mov    0x10(%rax),%rax
    8164:	48 83 c3 01          	add    $0x1,%rbx
    8168:	48 85 c0             	test   %rax,%rax
    816b:	75 f3                	jne    8160 <f37+0xf0>
    816d:	48 39 d3             	cmp    %rdx,%rbx
    8170:	48 0f 47 da          	cmova  %rdx,%rbx
    8174:	48 89 d8             	mov    %rbx,%rax
    8177:	48 c1 e8 3c          	shr    $0x3c,%rax
    817b:	0f 85 9f 03 00 00    	jne    8520 <f37+0x4b0>
    8181:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8185:	be 02 00 00 00       	mov    $0x2,%esi
    818a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8191:	00 
    8192:	e8 79 d8 ff ff       	call   5a10 <fwp_heap_alloc>
    8197:	48 89 28             	mov    %rbp,(%rax)
    819a:	48 8b 15 77 99 01 00 	mov    0x19977(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    81a1:	49 89 c5             	mov    %rax,%r13
    81a4:	48 2b 05 45 99 01 00 	sub    0x19945(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    81ab:	48 c1 e2 10          	shl    $0x10,%rdx
    81af:	48 39 d0             	cmp    %rdx,%rax
    81b2:	73 57                	jae    820b <f37+0x19b>
    81b4:	48 89 c2             	mov    %rax,%rdx
    81b7:	48 c1 ea 10          	shr    $0x10,%rdx
    81bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81bf:	48 8b 15 72 99 01 00 	mov    0x19972(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    81c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81ce:	48 85 ed             	test   %rbp,%rbp
    81d1:	74 38                	je     820b <f37+0x19b>
    81d3:	0f b6 0a             	movzbl (%rdx),%ecx
    81d6:	80 f9 02             	cmp    $0x2,%cl
    81d9:	0f 84 61 02 00 00    	je     8440 <f37+0x3d0>
    81df:	80 f9 01             	cmp    $0x1,%cl
    81e2:	75 27                	jne    820b <f37+0x19b>
    81e4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81e7:	0f b7 c0             	movzwl %ax,%eax
    81ea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81ed:	48 0f af c1          	imul   %rcx,%rax
    81f1:	48 c1 e8 20          	shr    $0x20,%rax
    81f5:	48 39 d0             	cmp    %rdx,%rax
    81f8:	73 11                	jae    820b <f37+0x19b>
    81fa:	48 01 c5             	add    %rax,%rbp
    81fd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8201:	0f 84 e5 02 00 00    	je     84ec <f37+0x47c>
    8207:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    820b:	48 85 db             	test   %rbx,%rbx
    820e:	74 74                	je     8284 <f37+0x214>
    8210:	48 c1 e3 04          	shl    $0x4,%rbx
    8214:	4c 8b 34 24          	mov    (%rsp),%r14
    8218:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    821d:	4c 89 ed             	mov    %r13,%rbp
    8220:	4c 01 eb             	add    %r13,%rbx
    8223:	66 90                	xchg   %ax,%ax
    8225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    822c:	00 00 00 00 
    8230:	49 8b 46 08          	mov    0x8(%r14),%rax
    8234:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8238:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    823d:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    8244:	ff ff 
    8246:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    824d:	00 00 
    824f:	48 83 c5 10          	add    $0x10,%rbp
    8253:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8258:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    825c:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8260:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    8265:	e8 c6 dd ff ff       	call   6030 <w120>
    826a:	66 48 0f 6e d0       	movq   %rax,%xmm2
    826f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8273:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8277:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    827b:	4d 8b 76 10          	mov    0x10(%r14),%r14
    827f:	48 39 dd             	cmp    %rbx,%rbp
    8282:	75 ac                	jne    8230 <f37+0x1c0>
    8284:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8289:	e8 b2 ed ff ff       	call   7040 <fwp_drop4>
    828e:	48 8b 3c 24          	mov    (%rsp),%rdi
    8292:	e8 a9 ed ff ff       	call   7040 <fwp_drop4>
    8297:	4c 89 ef             	mov    %r13,%rdi
    829a:	e8 e1 e4 ff ff       	call   6780 <w176.constprop.0>
    829f:	4c 89 ef             	mov    %r13,%rdi
    82a2:	48 89 c3             	mov    %rax,%rbx
    82a5:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    82aa:	e8 61 fb ff ff       	call   7e10 <fwp_drop10>
    82af:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    82b4:	66 48 0f 6e db       	movq   %rbx,%xmm3
    82b9:	31 ff                	xor    %edi,%edi
    82bb:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    82c0:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    82c4:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    82c9:	e8 62 d8 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    82ce:	48 8b 15 43 98 01 00 	mov    0x19843(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    82d5:	48 89 c5             	mov    %rax,%rbp
    82d8:	48 2b 05 11 98 01 00 	sub    0x19811(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    82df:	48 c1 e2 10          	shl    $0x10,%rdx
    82e3:	48 39 d0             	cmp    %rdx,%rax
    82e6:	73 55                	jae    833d <f37+0x2cd>
    82e8:	48 89 c2             	mov    %rax,%rdx
    82eb:	48 c1 ea 10          	shr    $0x10,%rdx
    82ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82f3:	48 8b 15 3e 98 01 00 	mov    0x1983e(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    82fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82fe:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8302:	48 85 db             	test   %rbx,%rbx
    8305:	74 36                	je     833d <f37+0x2cd>
    8307:	0f b6 0a             	movzbl (%rdx),%ecx
    830a:	80 f9 02             	cmp    $0x2,%cl
    830d:	0f 84 15 01 00 00    	je     8428 <f37+0x3b8>
    8313:	80 f9 01             	cmp    $0x1,%cl
    8316:	75 25                	jne    833d <f37+0x2cd>
    8318:	8b 4a 18             	mov    0x18(%rdx),%ecx
    831b:	0f b7 c0             	movzwl %ax,%eax
    831e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8321:	48 0f af c1          	imul   %rcx,%rax
    8325:	48 c1 e8 20          	shr    $0x20,%rax
    8329:	48 39 d0             	cmp    %rdx,%rax
    832c:	73 0f                	jae    833d <f37+0x2cd>
    832e:	48 01 c3             	add    %rax,%rbx
    8331:	80 3b ff             	cmpb   $0xff,(%rbx)
    8334:	0f 84 a5 01 00 00    	je     84df <f37+0x46f>
    833a:	c6 03 01             	movb   $0x1,(%rbx)
    833d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8342:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8349:	00 00 
    834b:	0f 85 ca 01 00 00    	jne    851b <f37+0x4ab>
    8351:	48 83 c4 48          	add    $0x48,%rsp
    8355:	48 89 e8             	mov    %rbp,%rax
    8358:	5b                   	pop    %rbx
    8359:	5d                   	pop    %rbp
    835a:	41 5c                	pop    %r12
    835c:	41 5d                	pop    %r13
    835e:	41 5e                	pop    %r14
    8360:	41 5f                	pop    %r15
    8362:	c3                   	ret
    8363:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8368:	66 85 c0             	test   %ax,%ax
    836b:	0f 85 a9 fd ff ff    	jne    811a <f37+0xaa>
    8371:	0f b6 07             	movzbl (%rdi),%eax
    8374:	84 c0                	test   %al,%al
    8376:	0f 84 9e fd ff ff    	je     811a <f37+0xaa>
    837c:	3c fd                	cmp    $0xfd,%al
    837e:	0f 87 8d 01 00 00    	ja     8511 <f37+0x4a1>
    8384:	83 c0 01             	add    $0x1,%eax
    8387:	88 07                	mov    %al,(%rdi)
    8389:	e9 8c fd ff ff       	jmp    811a <f37+0xaa>
    838e:	48 f7 d9             	neg    %rcx
    8391:	48 39 d1             	cmp    %rdx,%rcx
    8394:	0f 83 e6 00 00 00    	jae    8480 <f37+0x410>
    839a:	48 89 c8             	mov    %rcx,%rax
    839d:	48 c1 e8 10          	shr    $0x10,%rax
    83a1:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    83a5:	48 8b 05 8c 97 01 00 	mov    0x1978c(%rip),%rax        # 21b38 <fwp_heap+0x13f8>
    83ac:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    83b0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    83b4:	48 85 ff             	test   %rdi,%rdi
    83b7:	0f 84 c3 00 00 00    	je     8480 <f37+0x410>
    83bd:	0f b6 02             	movzbl (%rdx),%eax
    83c0:	3c 02                	cmp    $0x2,%al
    83c2:	0f 84 92 00 00 00    	je     845a <f37+0x3ea>
    83c8:	3c 01                	cmp    $0x1,%al
    83ca:	0f 85 b0 00 00 00    	jne    8480 <f37+0x410>
    83d0:	0f b7 c1             	movzwl %cx,%eax
    83d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83d6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83d9:	48 0f af c1          	imul   %rcx,%rax
    83dd:	48 c1 e8 20          	shr    $0x20,%rax
    83e1:	48 39 d0             	cmp    %rdx,%rax
    83e4:	0f 83 96 00 00 00    	jae    8480 <f37+0x410>
    83ea:	48 01 c7             	add    %rax,%rdi
    83ed:	0f b6 07             	movzbl (%rdi),%eax
    83f0:	84 c0                	test   %al,%al
    83f2:	0f 84 88 00 00 00    	je     8480 <f37+0x410>
    83f8:	31 db                	xor    %ebx,%ebx
    83fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8400:	3c fd                	cmp    $0xfd,%al
    8402:	0f 87 f1 00 00 00    	ja     84f9 <f37+0x489>
    8408:	83 c0 01             	add    $0x1,%eax
    840b:	88 07                	mov    %al,(%rdi)
    840d:	31 d2                	xor    %edx,%edx
    840f:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    8414:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8419:	0f 85 00 fd ff ff    	jne    811f <f37+0xaf>
    841f:	e9 29 fd ff ff       	jmp    814d <f37+0xdd>
    8424:	0f 1f 40 00          	nopl   0x0(%rax)
    8428:	66 85 c0             	test   %ax,%ax
    842b:	0f 85 0c ff ff ff    	jne    833d <f37+0x2cd>
    8431:	e9 fb fe ff ff       	jmp    8331 <f37+0x2c1>
    8436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    843d:	00 00 00 
    8440:	66 85 c0             	test   %ax,%ax
    8443:	0f 85 c2 fd ff ff    	jne    820b <f37+0x19b>
    8449:	e9 af fd ff ff       	jmp    81fd <f37+0x18d>
    844e:	66 90                	xchg   %ax,%ax
    8450:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8455:	e9 cd fc ff ff       	jmp    8127 <f37+0xb7>
    845a:	66 85 c9             	test   %cx,%cx
    845d:	75 21                	jne    8480 <f37+0x410>
    845f:	0f b6 07             	movzbl (%rdi),%eax
    8462:	84 c0                	test   %al,%al
    8464:	74 1a                	je     8480 <f37+0x410>
    8466:	3c fd                	cmp    $0xfd,%al
    8468:	0f 87 be 00 00 00    	ja     852c <f37+0x4bc>
    846e:	83 c0 01             	add    $0x1,%eax
    8471:	88 07                	mov    %al,(%rdi)
    8473:	66 90                	xchg   %ax,%ax
    8475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    847c:	00 00 00 00 
    8480:	be 02 00 00 00       	mov    $0x2,%esi
    8485:	bf 08 00 00 00       	mov    $0x8,%edi
    848a:	e8 81 d5 ff ff       	call   5a10 <fwp_heap_alloc>
    848f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8496:	48 8b 15 7b 96 01 00 	mov    0x1967b(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    849d:	49 89 c5             	mov    %rax,%r13
    84a0:	48 2b 05 49 96 01 00 	sub    0x19649(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    84a7:	48 c1 e2 10          	shl    $0x10,%rdx
    84ab:	48 39 d0             	cmp    %rdx,%rax
    84ae:	73 53                	jae    8503 <f37+0x493>
    84b0:	48 89 c2             	mov    %rax,%rdx
    84b3:	48 c1 ea 10          	shr    $0x10,%rdx
    84b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84bb:	48 8b 15 76 96 01 00 	mov    0x19676(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    84c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84c6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84ca:	48 85 ed             	test   %rbp,%rbp
    84cd:	74 34                	je     8503 <f37+0x493>
    84cf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    84d6:	00 00 
    84d8:	31 db                	xor    %ebx,%ebx
    84da:	e9 f4 fc ff ff       	jmp    81d3 <f37+0x163>
    84df:	48 89 df             	mov    %rbx,%rdi
    84e2:	e8 e9 cd ff ff       	call   52d0 <fwp_rc_forget_slot>
    84e7:	e9 4e fe ff ff       	jmp    833a <f37+0x2ca>
    84ec:	48 89 ef             	mov    %rbp,%rdi
    84ef:	e8 dc cd ff ff       	call   52d0 <fwp_rc_forget_slot>
    84f4:	e9 0e fd ff ff       	jmp    8207 <f37+0x197>
    84f9:	e8 b2 cc ff ff       	call   51b0 <fwp_rc_wide_dup>
    84fe:	e9 0a ff ff ff       	jmp    840d <f37+0x39d>
    8503:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    850a:	00 00 
    850c:	e9 73 fd ff ff       	jmp    8284 <f37+0x214>
    8511:	e8 9a cc ff ff       	call   51b0 <fwp_rc_wide_dup>
    8516:	e9 ff fb ff ff       	jmp    811a <f37+0xaa>
    851b:	e8 20 af ff ff       	call   3440 <__stack_chk_fail@plt>
    8520:	48 8d 3d 06 3c 00 00 	lea    0x3c06(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    8527:	e8 34 bc ff ff       	call   4160 <fwp_trap>
    852c:	e8 7f cc ff ff       	call   51b0 <fwp_rc_wide_dup>
    8531:	e9 4a ff ff ff       	jmp    8480 <f37+0x410>
    8536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    853d:	00 00 00 

0000000000008540 <fwp_owned_entry37>:
    8540:	f3 0f 1e fa          	endbr64
    8544:	48 8b 3f             	mov    (%rdi),%rdi
    8547:	e9 24 fb ff ff       	jmp    8070 <f37>
    854c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008550 <e37>:
    8550:	f3 0f 1e fa          	endbr64
    8554:	53                   	push   %rbx
    8555:	48 8b 1f             	mov    (%rdi),%rbx
    8558:	48 89 df             	mov    %rbx,%rdi
    855b:	e8 d0 e2 ff ff       	call   6830 <fwp_rc_share>
    8560:	48 89 df             	mov    %rbx,%rdi
    8563:	e8 08 fb ff ff       	call   8070 <f37>
    8568:	48 89 c3             	mov    %rax,%rbx
    856b:	48 89 c7             	mov    %rax,%rdi
    856e:	e8 bd e2 ff ff       	call   6830 <fwp_rc_share>
    8573:	48 89 d8             	mov    %rbx,%rax
    8576:	5b                   	pop    %rbx
    8577:	c3                   	ret
    8578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    857f:	00 

0000000000008580 <fwp_write>:
    8580:	41 57                	push   %r15
    8582:	41 56                	push   %r14
    8584:	41 55                	push   %r13
    8586:	41 54                	push   %r12
    8588:	55                   	push   %rbp
    8589:	53                   	push   %rbx
    858a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8591:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8598:	00 00 
    859a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    85a1:	00 
    85a2:	49 89 d4             	mov    %rdx,%r12
    85a5:	8b 12                	mov    (%rdx),%edx
    85a7:	83 fa 19             	cmp    $0x19,%edx
    85aa:	77 6a                	ja     8616 <fwp_write+0x96>
    85ac:	48 89 f5             	mov    %rsi,%rbp
    85af:	89 d0                	mov    %edx,%eax
    85b1:	89 ce                	mov    %ecx,%esi
    85b3:	48 89 fb             	mov    %rdi,%rbx
    85b6:	48 8d 0d 53 44 00 00 	lea    0x4453(%rip),%rcx        # ca10 <_IO_stdin_used+0xa10>
    85bd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    85c1:	48 01 c8             	add    %rcx,%rax
    85c4:	3e ff e0             	notrack jmp *%rax
    85c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ce:	00 00 
    85d0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    85d4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    85d8:	48 89 ca             	mov    %rcx,%rdx
    85db:	48 85 c9             	test   %rcx,%rcx
    85de:	0f 88 9c 0c 00 00    	js     9280 <fwp_write+0xd00>
    85e4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    85eb:	00 
    85ec:	48 89 c6             	mov    %rax,%rsi
    85ef:	4c 89 e7             	mov    %r12,%rdi
    85f2:	e8 09 b4 ff ff       	call   3a00 <fwp_fmt_u128>
    85f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85fe:	00 00 
    8600:	4c 89 e7             	mov    %r12,%rdi
    8603:	e8 28 ae ff ff       	call   3430 <strlen@plt>
    8608:	4c 89 e6             	mov    %r12,%rsi
    860b:	48 89 df             	mov    %rbx,%rdi
    860e:	48 89 c2             	mov    %rax,%rdx
    8611:	e8 1a ba ff ff       	call   4030 <buf_put>
    8616:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    861d:	00 
    861e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8625:	00 00 
    8627:	0f 85 28 04 00 00    	jne    8a55 <fwp_write+0x4d5>
    862d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8634:	5b                   	pop    %rbx
    8635:	5d                   	pop    %rbp
    8636:	41 5c                	pop    %r12
    8638:	41 5d                	pop    %r13
    863a:	41 5e                	pop    %r14
    863c:	41 5f                	pop    %r15
    863e:	c3                   	ret
    863f:	90                   	nop
    8640:	49 89 e9             	mov    %rbp,%r9
    8643:	4c 8d 05 0d 3b 00 00 	lea    0x3b0d(%rip),%r8        # c157 <_IO_stdin_used+0x157>
    864a:	b9 00 02 00 00       	mov    $0x200,%ecx
    864f:	ba 02 00 00 00       	mov    $0x2,%edx
    8654:	be 00 02 00 00       	mov    $0x200,%esi
    8659:	31 c0                	xor    %eax,%eax
    865b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8662:	00 
    8663:	e8 28 ad ff ff       	call   3390 <__snprintf_chk@plt>
    8668:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    866f:	00 
    8670:	e8 bb ad ff ff       	call   3430 <strlen@plt>
    8675:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    867c:	00 
    867d:	48 89 df             	mov    %rbx,%rdi
    8680:	48 89 c2             	mov    %rax,%rdx
    8683:	e8 a8 b9 ff ff       	call   4030 <buf_put>
    8688:	eb 8c                	jmp    8616 <fwp_write+0x96>
    868a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8690:	49 89 e9             	mov    %rbp,%r9
    8693:	4c 8d 05 b8 3a 00 00 	lea    0x3ab8(%rip),%r8        # c152 <_IO_stdin_used+0x152>
    869a:	eb ae                	jmp    864a <fwp_write+0xca>
    869c:	0f 1f 40 00          	nopl   0x0(%rax)
    86a0:	83 fa 13             	cmp    $0x13,%edx
    86a3:	48 8d 05 9e 3a 00 00 	lea    0x3a9e(%rip),%rax        # c148 <_IO_stdin_used+0x148>
    86aa:	48 8d 35 9c 3a 00 00 	lea    0x3a9c(%rip),%rsi        # c14d <_IO_stdin_used+0x14d>
    86b1:	ba 04 00 00 00       	mov    $0x4,%edx
    86b6:	48 0f 44 f0          	cmove  %rax,%rsi
    86ba:	45 31 ed             	xor    %r13d,%r13d
    86bd:	e8 6e b9 ff ff       	call   4030 <buf_put>
    86c2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    86c7:	0f 84 a3 08 00 00    	je     8f70 <fwp_write+0x9f0>
    86cd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    86d2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    86d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86dc:	48 89 df             	mov    %rbx,%rdi
    86df:	49 0f 44 c5          	cmove  %r13,%rax
    86e3:	31 c9                	xor    %ecx,%ecx
    86e5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    86ea:	e8 91 fe ff ff       	call   8580 <fwp_write>
    86ef:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    86f4:	0f 84 6e 09 00 00    	je     9068 <fwp_write+0xae8>
    86fa:	49 83 c5 01          	add    $0x1,%r13
    86fe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8702:	0f 83 68 08 00 00    	jae    8f70 <fwp_write+0x9f0>
    8708:	ba 02 00 00 00       	mov    $0x2,%edx
    870d:	48 8d 35 83 3a 00 00 	lea    0x3a83(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8714:	48 89 df             	mov    %rbx,%rdi
    8717:	e8 14 b9 ff ff       	call   4030 <buf_put>
    871c:	eb af                	jmp    86cd <fwp_write+0x14d>
    871e:	66 90                	xchg   %ax,%ax
    8720:	ba 06 00 00 00       	mov    $0x6,%edx
    8725:	48 8d 35 44 3a 00 00 	lea    0x3a44(%rip),%rsi        # c170 <_IO_stdin_used+0x170>
    872c:	48 83 c5 10          	add    $0x10,%rbp
    8730:	e8 fb b8 ff ff       	call   4030 <buf_put>
    8735:	48 89 ef             	mov    %rbp,%rdi
    8738:	e8 f3 ac ff ff       	call   3430 <strlen@plt>
    873d:	48 89 ee             	mov    %rbp,%rsi
    8740:	48 89 df             	mov    %rbx,%rdi
    8743:	48 89 c2             	mov    %rax,%rdx
    8746:	e8 e5 b8 ff ff       	call   4030 <buf_put>
    874b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8750:	ba 01 00 00 00       	mov    $0x1,%edx
    8755:	48 89 df             	mov    %rbx,%rdi
    8758:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    875d:	e8 ce b8 ff ff       	call   4030 <buf_put>
    8762:	e9 af fe ff ff       	jmp    8616 <fwp_write+0x96>
    8767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    876e:	00 00 
    8770:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8777:	00 
    8778:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    877f:	00 00 
    8781:	0f 85 ce 02 00 00    	jne    8a55 <fwp_write+0x4d5>
    8787:	ba 0a 00 00 00       	mov    $0xa,%edx
    878c:	48 8d 35 c9 39 00 00 	lea    0x39c9(%rip),%rsi        # c15c <_IO_stdin_used+0x15c>
    8793:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    879a:	48 89 df             	mov    %rbx,%rdi
    879d:	5b                   	pop    %rbx
    879e:	5d                   	pop    %rbp
    879f:	41 5c                	pop    %r12
    87a1:	41 5d                	pop    %r13
    87a3:	41 5e                	pop    %r14
    87a5:	41 5f                	pop    %r15
    87a7:	e9 84 b8 ff ff       	jmp    4030 <buf_put>
    87ac:	0f 1f 40 00          	nopl   0x0(%rax)
    87b0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    87b5:	4d 85 ed             	test   %r13,%r13
    87b8:	0f 84 02 0c 00 00    	je     93c0 <fwp_write+0xe40>
    87be:	48 8d 35 df 39 00 00 	lea    0x39df(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    87c5:	4c 89 ef             	mov    %r13,%rdi
    87c8:	e8 43 ad ff ff       	call   3510 <strcmp@plt>
    87cd:	41 89 c1             	mov    %eax,%r9d
    87d0:	85 c0                	test   %eax,%eax
    87d2:	0f 84 6c 0c 00 00    	je     9444 <fwp_write+0xec4>
    87d8:	4c 89 ef             	mov    %r13,%rdi
    87db:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    87e0:	e8 4b ac ff ff       	call   3430 <strlen@plt>
    87e5:	4c 89 ee             	mov    %r13,%rsi
    87e8:	48 89 df             	mov    %rbx,%rdi
    87eb:	48 89 c2             	mov    %rax,%rdx
    87ee:	e8 3d b8 ff ff       	call   4030 <buf_put>
    87f3:	ba 01 00 00 00       	mov    $0x1,%edx
    87f8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87fd:	48 89 df             	mov    %rbx,%rdi
    8800:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8805:	e8 26 b8 ff ff       	call   4030 <buf_put>
    880a:	ba 01 00 00 00       	mov    $0x1,%edx
    880f:	4c 89 fe             	mov    %r15,%rsi
    8812:	48 89 df             	mov    %rbx,%rdi
    8815:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    881a:	e8 11 b8 ff ff       	call   4030 <buf_put>
    881f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8824:	45 31 f6             	xor    %r14d,%r14d
    8827:	85 d2                	test   %edx,%edx
    8829:	0f 8e 81 0a 00 00    	jle    92b0 <fwp_write+0xd30>
    882f:	45 31 ed             	xor    %r13d,%r13d
    8832:	4d 85 ed             	test   %r13,%r13
    8835:	0f 85 75 07 00 00    	jne    8fb0 <fwp_write+0xa30>
    883b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8842:	00 
    8843:	45 85 f6             	test   %r14d,%r14d
    8846:	0f 84 84 07 00 00    	je     8fd0 <fwp_write+0xa50>
    884c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8851:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8856:	48 89 df             	mov    %rbx,%rdi
    8859:	49 83 c5 01          	add    $0x1,%r13
    885d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8861:	31 c9                	xor    %ecx,%ecx
    8863:	e8 18 fd ff ff       	call   8580 <fwp_write>
    8868:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    886d:	7f c3                	jg     8832 <fwp_write+0x2b2>
    886f:	45 85 f6             	test   %r14d,%r14d
    8872:	0f 84 38 0a 00 00    	je     92b0 <fwp_write+0xd30>
    8878:	b8 29 00 00 00       	mov    $0x29,%eax
    887d:	ba 01 00 00 00       	mov    $0x1,%edx
    8882:	4c 89 fe             	mov    %r15,%rsi
    8885:	48 89 df             	mov    %rbx,%rdi
    8888:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    888c:	e8 9f b7 ff ff       	call   4030 <buf_put>
    8891:	e9 80 fd ff ff       	jmp    8616 <fwp_write+0x96>
    8896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    889d:	00 00 00 
    88a0:	ba 01 00 00 00       	mov    $0x1,%edx
    88a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88aa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    88af:	e8 7c b7 ff ff       	call   4030 <buf_put>
    88b4:	48 85 ed             	test   %rbp,%rbp
    88b7:	0f 84 93 06 00 00    	je     8f50 <fwp_write+0x9d0>
    88bd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    88c1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88c6:	31 c9                	xor    %ecx,%ecx
    88c8:	48 89 df             	mov    %rbx,%rdi
    88cb:	e8 b0 fc ff ff       	call   8580 <fwp_write>
    88d0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    88d4:	48 85 ed             	test   %rbp,%rbp
    88d7:	0f 84 73 06 00 00    	je     8f50 <fwp_write+0x9d0>
    88dd:	ba 02 00 00 00       	mov    $0x2,%edx
    88e2:	48 8d 35 ae 38 00 00 	lea    0x38ae(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    88e9:	48 89 df             	mov    %rbx,%rdi
    88ec:	e8 3f b7 ff ff       	call   4030 <buf_put>
    88f1:	eb ca                	jmp    88bd <fwp_write+0x33d>
    88f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88f8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    88fc:	85 f6                	test   %esi,%esi
    88fe:	0f 84 fc 07 00 00    	je     9100 <fwp_write+0xb80>
    8904:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    890b:	00 
    890c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8913:	00 00 
    8915:	0f 85 3a 01 00 00    	jne    8a55 <fwp_write+0x4d5>
    891b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    891f:	4c 89 ea             	mov    %r13,%rdx
    8922:	e9 6c fe ff ff       	jmp    8793 <fwp_write+0x213>
    8927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    892e:	00 00 
    8930:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8935:	ba 01 00 00 00       	mov    $0x1,%edx
    893a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    893f:	48 89 ee             	mov    %rbp,%rsi
    8942:	e8 e9 b6 ff ff       	call   4030 <buf_put>
    8947:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    894c:	4c 89 e7             	mov    %r12,%rdi
    894f:	e8 dc aa ff ff       	call   3430 <strlen@plt>
    8954:	4c 89 e6             	mov    %r12,%rsi
    8957:	48 89 df             	mov    %rbx,%rdi
    895a:	48 89 c2             	mov    %rax,%rdx
    895d:	e8 ce b6 ff ff       	call   4030 <buf_put>
    8962:	ba 01 00 00 00       	mov    $0x1,%edx
    8967:	48 89 ee             	mov    %rbp,%rsi
    896a:	48 89 df             	mov    %rbx,%rdi
    896d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8972:	e8 b9 b6 ff ff       	call   4030 <buf_put>
    8977:	e9 9a fc ff ff       	jmp    8616 <fwp_write+0x96>
    897c:	0f 1f 40 00          	nopl   0x0(%rax)
    8980:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8985:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8989:	0f 8a 8e 0b 00 00    	jp     951d <fwp_write+0xf9d>
    898f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8993:	66 0f 54 05 c5 41 00 	andpd  0x41c5(%rip),%xmm0        # cb60 <msg.4+0xe0>
    899a:	00 
    899b:	bd 01 00 00 00       	mov    $0x1,%ebp
    89a0:	66 0f 2e 05 00 41 00 	ucomisd 0x4100(%rip),%xmm0        # caa8 <msg.4+0x28>
    89a7:	00 
    89a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    89af:	00 
    89b0:	0f 87 b2 09 00 00    	ja     9368 <fwp_write+0xde8>
    89b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89bd:	00 00 00 
    89c0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89c4:	89 ee                	mov    %ebp,%esi
    89c6:	4c 89 e7             	mov    %r12,%rdi
    89c9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    89ce:	e8 ad ba ff ff       	call   4480 <fwp_format_g.constprop.0>
    89d3:	31 f6                	xor    %esi,%esi
    89d5:	4c 89 e7             	mov    %r12,%rdi
    89d8:	e8 13 aa ff ff       	call   33f0 <strtod@plt>
    89dd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    89e2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    89e6:	7a 06                	jp     89ee <fwp_write+0x46e>
    89e8:	0f 84 e9 01 00 00    	je     8bd7 <fwp_write+0x657>
    89ee:	83 c5 01             	add    $0x1,%ebp
    89f1:	83 fd 12             	cmp    $0x12,%ebp
    89f4:	75 ca                	jne    89c0 <fwp_write+0x440>
    89f6:	be 11 00 00 00       	mov    $0x11,%esi
    89fb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89ff:	4c 89 e7             	mov    %r12,%rdi
    8a02:	e8 79 ba ff ff       	call   4480 <fwp_format_g.constprop.0>
    8a07:	e9 cb 01 00 00       	jmp    8bd7 <fwp_write+0x657>
    8a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a10:	48 83 fd 01          	cmp    $0x1,%rbp
    8a14:	0f 84 e6 08 00 00    	je     9300 <fwp_write+0xd80>
    8a1a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8a1e:	b8 02 00 00 00       	mov    $0x2,%eax
    8a23:	ba 01 00 00 00       	mov    $0x1,%edx
    8a28:	48 0f 44 d0          	cmove  %rax,%rdx
    8a2c:	48 8d 35 0d 37 00 00 	lea    0x370d(%rip),%rsi        # c140 <_IO_stdin_used+0x140>
    8a33:	48 8d 05 0b 37 00 00 	lea    0x370b(%rip),%rax        # c145 <_IO_stdin_used+0x145>
    8a3a:	48 0f 44 f0          	cmove  %rax,%rsi
    8a3e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a45:	00 
    8a46:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a4d:	00 00 
    8a4f:	0f 84 3e fd ff ff    	je     8793 <fwp_write+0x213>
    8a55:	e8 e6 a9 ff ff       	call   3440 <__stack_chk_fail@plt>
    8a5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a60:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8a65:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8a6a:	e8 01 b5 ff ff       	call   3f70 <buf_grow>
    8a6f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8a73:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8a79:	4c 03 0b             	add    (%rbx),%r9
    8a7c:	66 45 89 11          	mov    %r10w,(%r9)
    8a80:	45 85 e4             	test   %r12d,%r12d
    8a83:	0f 8e 07 05 00 00    	jle    8f90 <fwp_write+0xa10>
    8a89:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8a90:	55 55 55 
    8a93:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8a98:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8a9f:	aa aa aa 
    8aa2:	49 83 c1 01          	add    $0x1,%r9
    8aa6:	eb 45                	jmp    8aed <fwp_write+0x56d>
    8aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8aaf:	00 
    8ab0:	be 01 00 00 00       	mov    $0x1,%esi
    8ab5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8aba:	88 07                	mov    %al,(%rdi)
    8abc:	48 89 e8             	mov    %rbp,%rax
    8abf:	49 f7 e8             	imul   %r8
    8ac2:	48 89 e8             	mov    %rbp,%rax
    8ac5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8ac9:	48 29 c2             	sub    %rax,%rdx
    8acc:	48 85 c9             	test   %rcx,%rcx
    8acf:	0f 95 c0             	setne  %al
    8ad2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8ad6:	48 83 ef 01          	sub    $0x1,%rdi
    8ada:	48 21 c5             	and    %rax,%rbp
    8add:	48 29 ea             	sub    %rbp,%rdx
    8ae0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8ae4:	49 39 f9             	cmp    %rdi,%r9
    8ae7:	0f 84 a3 04 00 00    	je     8f90 <fwp_write+0xa10>
    8aed:	48 89 e8             	mov    %rbp,%rax
    8af0:	49 f7 e8             	imul   %r8
    8af3:	48 89 e8             	mov    %rbp,%rax
    8af6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8afa:	48 89 d1             	mov    %rdx,%rcx
    8afd:	48 29 c1             	sub    %rax,%rcx
    8b00:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8b04:	48 89 e9             	mov    %rbp,%rcx
    8b07:	48 29 c1             	sub    %rax,%rcx
    8b0a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8b0e:	49 f7 e2             	mul    %r10
    8b11:	b8 30 00 00 00       	mov    $0x30,%eax
    8b16:	48 89 d6             	mov    %rdx,%rsi
    8b19:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8b1d:	48 d1 ee             	shr    $1,%rsi
    8b20:	48 01 f2             	add    %rsi,%rdx
    8b23:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8b27:	48 29 d6             	sub    %rdx,%rsi
    8b2a:	74 8e                	je     8aba <fwp_write+0x53a>
    8b2c:	48 83 fe 01          	cmp    $0x1,%rsi
    8b30:	0f 85 7a ff ff ff    	jne    8ab0 <fwp_write+0x530>
    8b36:	31 f6                	xor    %esi,%esi
    8b38:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8b3d:	e9 78 ff ff ff       	jmp    8aba <fwp_write+0x53a>
    8b42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b48:	66 0f 6e cd          	movd   %ebp,%xmm1
    8b4c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8b4f:	0f 8a c8 09 00 00    	jp     951d <fwp_write+0xf9d>
    8b55:	0f 28 c1             	movaps %xmm1,%xmm0
    8b58:	0f 54 05 f1 3f 00 00 	andps  0x3ff1(%rip),%xmm0        # cb50 <msg.4+0xd0>
    8b5f:	0f 2e 05 9e 34 00 00 	ucomiss 0x349e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8b66:	0f 87 24 08 00 00    	ja     9390 <fwp_write+0xe10>
    8b6c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8b70:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8b76:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8b7d:	00 
    8b7e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8b82:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b8e:	00 00 
    8b90:	44 89 ee             	mov    %r13d,%esi
    8b93:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8b98:	4c 89 e7             	mov    %r12,%rdi
    8b9b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8ba0:	e8 db b8 ff ff       	call   4480 <fwp_format_g.constprop.0>
    8ba5:	31 f6                	xor    %esi,%esi
    8ba7:	4c 89 e7             	mov    %r12,%rdi
    8baa:	e8 e1 a8 ff ff       	call   3490 <strtof@plt>
    8baf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8bb4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8bb7:	7a 02                	jp     8bbb <fwp_write+0x63b>
    8bb9:	74 1c                	je     8bd7 <fwp_write+0x657>
    8bbb:	41 83 c5 01          	add    $0x1,%r13d
    8bbf:	41 83 fd 0a          	cmp    $0xa,%r13d
    8bc3:	75 cb                	jne    8b90 <fwp_write+0x610>
    8bc5:	be 09 00 00 00       	mov    $0x9,%esi
    8bca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8bcf:	4c 89 e7             	mov    %r12,%rdi
    8bd2:	e8 a9 b8 ff ff       	call   4480 <fwp_format_g.constprop.0>
    8bd7:	4c 89 e7             	mov    %r12,%rdi
    8bda:	e8 11 b5 ff ff       	call   40f0 <fwp_finish_float>
    8bdf:	e9 1c fa ff ff       	jmp    8600 <fwp_write+0x80>
    8be4:	0f 1f 40 00          	nopl   0x0(%rax)
    8be8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8bec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8bf0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8bf7:	00 
    8bf8:	48 89 ef             	mov    %rbp,%rdi
    8bfb:	e8 00 ae ff ff       	call   3a00 <fwp_fmt_u128>
    8c00:	48 89 ef             	mov    %rbp,%rdi
    8c03:	e8 28 a8 ff ff       	call   3430 <strlen@plt>
    8c08:	48 89 ee             	mov    %rbp,%rsi
    8c0b:	48 89 df             	mov    %rbx,%rdi
    8c0e:	48 89 c2             	mov    %rax,%rdx
    8c11:	e8 1a b4 ff ff       	call   4030 <buf_put>
    8c16:	e9 fb f9 ff ff       	jmp    8616 <fwp_write+0x96>
    8c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c20:	ba 06 00 00 00       	mov    $0x6,%edx
    8c25:	48 8d 35 6e 35 00 00 	lea    0x356e(%rip),%rsi        # c19a <_IO_stdin_used+0x19a>
    8c2c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8c32:	e8 f9 b3 ff ff       	call   4030 <buf_put>
    8c37:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8c3e:	ff ff 7f 
    8c41:	48 23 55 00          	and    0x0(%rbp),%rdx
    8c45:	0f 84 86 02 00 00    	je     8ed1 <fwp_write+0x951>
    8c4b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8c50:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8c54:	48 85 d2             	test   %rdx,%rdx
    8c57:	0f 84 ae 00 00 00    	je     8d0b <fwp_write+0x78b>
    8c5d:	8b 0a                	mov    (%rdx),%ecx
    8c5f:	83 f9 1c             	cmp    $0x1c,%ecx
    8c62:	0f 84 58 06 00 00    	je     92c0 <fwp_write+0xd40>
    8c68:	83 f9 1b             	cmp    $0x1b,%ecx
    8c6b:	0f 87 9a 00 00 00    	ja     8d0b <fwp_write+0x78b>
    8c71:	be 01 00 00 00       	mov    $0x1,%esi
    8c76:	48 d3 e6             	shl    %cl,%rsi
    8c79:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8c7f:	0f 85 4b 04 00 00    	jne    90d0 <fwp_write+0xb50>
    8c85:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8c8b:	0f 85 0f 04 00 00    	jne    90a0 <fwp_write+0xb20>
    8c91:	83 e6 21             	and    $0x21,%esi
    8c94:	74 75                	je     8d0b <fwp_write+0x78b>
    8c96:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8c9b:	48 85 ff             	test   %rdi,%rdi
    8c9e:	79 07                	jns    8ca7 <fwp_write+0x727>
    8ca0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8ca4:	4c 01 ee             	add    %r13,%rsi
    8ca7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8cab:	85 c9                	test   %ecx,%ecx
    8cad:	40 0f b6 f7          	movzbl %dil,%esi
    8cb1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cbc:	00 00 00 00 
    8cc0:	31 c9                	xor    %ecx,%ecx
    8cc2:	48 89 df             	mov    %rbx,%rdi
    8cc5:	49 83 c5 01          	add    $0x1,%r13
    8cc9:	e8 b2 f8 ff ff       	call   8580 <fwp_write>
    8cce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8cd5:	ff ff 7f 
    8cd8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8cdc:	49 39 d5             	cmp    %rdx,%r13
    8cdf:	0f 83 ec 01 00 00    	jae    8ed1 <fwp_write+0x951>
    8ce5:	ba 02 00 00 00       	mov    $0x2,%edx
    8cea:	48 89 df             	mov    %rbx,%rdi
    8ced:	48 8d 35 a3 34 00 00 	lea    0x34a3(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8cf4:	e8 37 b3 ff ff       	call   4030 <buf_put>
    8cf9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8cfe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d02:	48 85 d2             	test   %rdx,%rdx
    8d05:	0f 85 52 ff ff ff    	jne    8c5d <fwp_write+0x6dd>
    8d0b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8d10:	48 85 ff             	test   %rdi,%rdi
    8d13:	0f 88 cf 05 00 00    	js     92e8 <fwp_write+0xd68>
    8d19:	48 8b 31             	mov    (%rcx),%rsi
    8d1c:	eb a2                	jmp    8cc0 <fwp_write+0x740>
    8d1e:	66 90                	xchg   %ax,%ax
    8d20:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d27:	00 
    8d28:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d2f:	00 00 
    8d31:	0f 85 1e fd ff ff    	jne    8a55 <fwp_write+0x4d5>
    8d37:	ba 08 00 00 00       	mov    $0x8,%edx
    8d3c:	48 8d 35 24 34 00 00 	lea    0x3424(%rip),%rsi        # c167 <_IO_stdin_used+0x167>
    8d43:	e9 4b fa ff ff       	jmp    8793 <fwp_write+0x213>
    8d48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d4f:	00 
    8d50:	89 e8                	mov    %ebp,%eax
    8d52:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8d59:	76 03                	jbe    8d5e <fwp_write+0x7de>
    8d5b:	8b 45 00             	mov    0x0(%rbp),%eax
    8d5e:	41 89 c6             	mov    %eax,%r14d
    8d61:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8d66:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8d6b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8d6f:	4c 89 ef             	mov    %r13,%rdi
    8d72:	e8 b9 a6 ff ff       	call   3430 <strlen@plt>
    8d77:	4c 89 ee             	mov    %r13,%rsi
    8d7a:	48 89 df             	mov    %rbx,%rdi
    8d7d:	48 89 c2             	mov    %rax,%rdx
    8d80:	e8 ab b2 ff ff       	call   4030 <buf_put>
    8d85:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8d8a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8d8e:	85 f6                	test   %esi,%esi
    8d90:	0f 8e 80 f8 ff ff    	jle    8616 <fwp_write+0x96>
    8d96:	45 31 ed             	xor    %r13d,%r13d
    8d99:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d9e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8da3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8da8:	ba 01 00 00 00       	mov    $0x1,%edx
    8dad:	4c 89 fe             	mov    %r15,%rsi
    8db0:	48 89 04 24          	mov    %rax,(%rsp)
    8db4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8db9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8dbd:	48 89 df             	mov    %rbx,%rdi
    8dc0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8dc4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8dc9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8dce:	e8 5d b2 ff ff       	call   4030 <buf_put>
    8dd3:	41 8b 06             	mov    (%r14),%eax
    8dd6:	83 f8 0e             	cmp    $0xe,%eax
    8dd9:	0f 84 71 02 00 00    	je     9050 <fwp_write+0xad0>
    8ddf:	83 f8 10             	cmp    $0x10,%eax
    8de2:	0f 84 38 02 00 00    	je     9020 <fwp_write+0xaa0>
    8de8:	83 f8 0a             	cmp    $0xa,%eax
    8deb:	0f 84 7f 04 00 00    	je     9270 <fwp_write+0xcf0>
    8df1:	0f 8f f9 00 00 00    	jg     8ef0 <fwp_write+0x970>
    8df7:	83 f8 03             	cmp    $0x3,%eax
    8dfa:	0f 8f 50 04 00 00    	jg     9250 <fwp_write+0xcd0>
    8e00:	85 c0                	test   %eax,%eax
    8e02:	78 10                	js     8e14 <fwp_write+0x894>
    8e04:	48 8b 04 24          	mov    (%rsp),%rax
    8e08:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e0c:	85 c0                	test   %eax,%eax
    8e0e:	0f 85 f9 00 00 00    	jne    8f0d <fwp_write+0x98d>
    8e14:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e19:	48 8b 34 24          	mov    (%rsp),%rsi
    8e1d:	31 c9                	xor    %ecx,%ecx
    8e1f:	48 89 df             	mov    %rbx,%rdi
    8e22:	e8 59 f7 ff ff       	call   8580 <fwp_write>
    8e27:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e2c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e31:	49 83 c5 01          	add    $0x1,%r13
    8e35:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8e39:	0f 8f 5f ff ff ff    	jg     8d9e <fwp_write+0x81e>
    8e3f:	e9 d2 f7 ff ff       	jmp    8616 <fwp_write+0x96>
    8e44:	0f 1f 40 00          	nopl   0x0(%rax)
    8e48:	ba 06 00 00 00       	mov    $0x6,%edx
    8e4d:	48 8d 35 39 33 00 00 	lea    0x3339(%rip),%rsi        # c18d <_IO_stdin_used+0x18d>
    8e54:	45 31 ed             	xor    %r13d,%r13d
    8e57:	e8 d4 b1 ff ff       	call   4030 <buf_put>
    8e5c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8e61:	75 19                	jne    8e7c <fwp_write+0x8fc>
    8e63:	eb 6c                	jmp    8ed1 <fwp_write+0x951>
    8e65:	0f 1f 00             	nopl   (%rax)
    8e68:	ba 02 00 00 00       	mov    $0x2,%edx
    8e6d:	48 8d 35 23 33 00 00 	lea    0x3323(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8e74:	48 89 df             	mov    %rbx,%rdi
    8e77:	e8 b4 b1 ff ff       	call   4030 <buf_put>
    8e7c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8e82:	b9 00 02 00 00       	mov    $0x200,%ecx
    8e87:	31 c0                	xor    %eax,%eax
    8e89:	49 83 c5 01          	add    $0x1,%r13
    8e8d:	4c 8d 05 00 33 00 00 	lea    0x3300(%rip),%r8        # c194 <_IO_stdin_used+0x194>
    8e94:	ba 02 00 00 00       	mov    $0x2,%edx
    8e99:	be 00 02 00 00       	mov    $0x200,%esi
    8e9e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ea5:	00 
    8ea6:	e8 e5 a4 ff ff       	call   3390 <__snprintf_chk@plt>
    8eab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8eb2:	00 
    8eb3:	e8 78 a5 ff ff       	call   3430 <strlen@plt>
    8eb8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8ebf:	00 
    8ec0:	48 89 df             	mov    %rbx,%rdi
    8ec3:	48 89 c2             	mov    %rax,%rdx
    8ec6:	e8 65 b1 ff ff       	call   4030 <buf_put>
    8ecb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8ecf:	72 97                	jb     8e68 <fwp_write+0x8e8>
    8ed1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ed6:	ba 01 00 00 00       	mov    $0x1,%edx
    8edb:	48 89 df             	mov    %rbx,%rdi
    8ede:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8ee3:	e8 48 b1 ff ff       	call   4030 <buf_put>
    8ee8:	e9 29 f7 ff ff       	jmp    8616 <fwp_write+0x96>
    8eed:	0f 1f 00             	nopl   (%rax)
    8ef0:	83 f8 0b             	cmp    $0xb,%eax
    8ef3:	0f 85 1b ff ff ff    	jne    8e14 <fwp_write+0x894>
    8ef9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8efe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8f02:	83 e0 01             	and    $0x1,%eax
    8f05:	85 c0                	test   %eax,%eax
    8f07:	0f 84 07 ff ff ff    	je     8e14 <fwp_write+0x894>
    8f0d:	4c 89 fe             	mov    %r15,%rsi
    8f10:	48 89 df             	mov    %rbx,%rdi
    8f13:	ba 01 00 00 00       	mov    $0x1,%edx
    8f18:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f1d:	e8 0e b1 ff ff       	call   4030 <buf_put>
    8f22:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f27:	48 8b 34 24          	mov    (%rsp),%rsi
    8f2b:	31 c9                	xor    %ecx,%ecx
    8f2d:	48 89 df             	mov    %rbx,%rdi
    8f30:	e8 4b f6 ff ff       	call   8580 <fwp_write>
    8f35:	ba 01 00 00 00       	mov    $0x1,%edx
    8f3a:	4c 89 fe             	mov    %r15,%rsi
    8f3d:	48 89 df             	mov    %rbx,%rdi
    8f40:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8f45:	e8 e6 b0 ff ff       	call   4030 <buf_put>
    8f4a:	e9 d8 fe ff ff       	jmp    8e27 <fwp_write+0x8a7>
    8f4f:	90                   	nop
    8f50:	ba 01 00 00 00       	mov    $0x1,%edx
    8f55:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f5a:	48 89 df             	mov    %rbx,%rdi
    8f5d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f62:	e8 c9 b0 ff ff       	call   4030 <buf_put>
    8f67:	e9 aa f6 ff ff       	jmp    8616 <fwp_write+0x96>
    8f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f70:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f75:	ba 01 00 00 00       	mov    $0x1,%edx
    8f7a:	48 89 df             	mov    %rbx,%rdi
    8f7d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8f82:	e8 a9 b0 ff ff       	call   4030 <buf_put>
    8f87:	e9 8a f6 ff ff       	jmp    8616 <fwp_write+0x96>
    8f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f90:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8f94:	48 8b 13             	mov    (%rbx),%rdx
    8f97:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8f9c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8fa0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8fa4:	e9 6d f6 ff ff       	jmp    8616 <fwp_write+0x96>
    8fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fb0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fb5:	48 8d 35 db 31 00 00 	lea    0x31db(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8fbc:	48 89 df             	mov    %rbx,%rdi
    8fbf:	e8 6c b0 ff ff       	call   4030 <buf_put>
    8fc4:	e9 72 f8 ff ff       	jmp    883b <fwp_write+0x2bb>
    8fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fd0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8fd5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8fda:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8fde:	48 89 f7             	mov    %rsi,%rdi
    8fe1:	48 89 34 24          	mov    %rsi,(%rsp)
    8fe5:	e8 46 a4 ff ff       	call   3430 <strlen@plt>
    8fea:	48 8b 34 24          	mov    (%rsp),%rsi
    8fee:	48 89 df             	mov    %rbx,%rdi
    8ff1:	48 89 c2             	mov    %rax,%rdx
    8ff4:	e8 37 b0 ff ff       	call   4030 <buf_put>
    8ff9:	ba 03 00 00 00       	mov    $0x3,%edx
    8ffe:	48 8d 35 b5 31 00 00 	lea    0x31b5(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    9005:	48 89 df             	mov    %rbx,%rdi
    9008:	e8 23 b0 ff ff       	call   4030 <buf_put>
    900d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9012:	e9 35 f8 ff ff       	jmp    884c <fwp_write+0x2cc>
    9017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    901e:	00 00 
    9020:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9025:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9029:	48 85 ff             	test   %rdi,%rdi
    902c:	0f 84 e2 fd ff ff    	je     8e14 <fwp_write+0x894>
    9032:	48 8d 35 6b 31 00 00 	lea    0x316b(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    9039:	e8 d2 a4 ff ff       	call   3510 <strcmp@plt>
    903e:	85 c0                	test   %eax,%eax
    9040:	0f 95 c0             	setne  %al
    9043:	0f b6 c0             	movzbl %al,%eax
    9046:	e9 c1 fd ff ff       	jmp    8e0c <fwp_write+0x88c>
    904b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9050:	31 c0                	xor    %eax,%eax
    9052:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9059:	00 
    905a:	0f 97 c0             	seta   %al
    905d:	e9 aa fd ff ff       	jmp    8e0c <fwp_write+0x88c>
    9062:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9068:	48 89 df             	mov    %rbx,%rdi
    906b:	ba 02 00 00 00       	mov    $0x2,%edx
    9070:	48 8d 35 2a 31 00 00 	lea    0x312a(%rip),%rsi        # c1a1 <_IO_stdin_used+0x1a1>
    9077:	e8 b4 af ff ff       	call   4030 <buf_put>
    907c:	4c 89 e8             	mov    %r13,%rax
    907f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9084:	31 c9                	xor    %ecx,%ecx
    9086:	48 c1 e0 04          	shl    $0x4,%rax
    908a:	48 89 df             	mov    %rbx,%rdi
    908d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9092:	e8 e9 f4 ff ff       	call   8580 <fwp_write>
    9097:	e9 5e f6 ff ff       	jmp    86fa <fwp_write+0x17a>
    909c:	0f 1f 40 00          	nopl   0x0(%rax)
    90a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    90a5:	48 85 ff             	test   %rdi,%rdi
    90a8:	79 0c                	jns    90b6 <fwp_write+0xb36>
    90aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    90b1:	00 
    90b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    90b6:	48 63 3e             	movslq (%rsi),%rdi
    90b9:	83 f9 02             	cmp    $0x2,%ecx
    90bc:	89 fe                	mov    %edi,%esi
    90be:	48 0f 44 f7          	cmove  %rdi,%rsi
    90c2:	e9 f9 fb ff ff       	jmp    8cc0 <fwp_write+0x740>
    90c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90ce:	00 00 
    90d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    90d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    90da:	48 85 ff             	test   %rdi,%rdi
    90dd:	0f 88 0f 03 00 00    	js     93f2 <fwp_write+0xe72>
    90e3:	49 0f bf 38          	movswq (%r8),%rdi
    90e7:	83 f9 01             	cmp    $0x1,%ecx
    90ea:	0f b7 f7             	movzwl %di,%esi
    90ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    90f1:	e9 ca fb ff ff       	jmp    8cc0 <fwp_write+0x740>
    90f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90fd:	00 00 00 
    9100:	ba 01 00 00 00       	mov    $0x1,%edx
    9105:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    910a:	48 83 c5 08          	add    $0x8,%rbp
    910e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9113:	e8 18 af ff ff       	call   4030 <buf_put>
    9118:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    911d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9122:	4d 85 ed             	test   %r13,%r13
    9125:	75 46                	jne    916d <fwp_write+0xbed>
    9127:	e9 04 01 00 00       	jmp    9230 <fwp_write+0xcb0>
    912c:	0f 1f 40 00          	nopl   0x0(%rax)
    9130:	41 80 f9 09          	cmp    $0x9,%r9b
    9134:	0f 84 d6 00 00 00    	je     9210 <fwp_write+0xc90>
    913a:	41 80 f9 0a          	cmp    $0xa,%r9b
    913e:	0f 85 9c 00 00 00    	jne    91e0 <fwp_write+0xc60>
    9144:	ba 02 00 00 00       	mov    $0x2,%edx
    9149:	48 8d 35 2d 30 00 00 	lea    0x302d(%rip),%rsi        # c17d <_IO_stdin_used+0x17d>
    9150:	48 89 df             	mov    %rbx,%rdi
    9153:	e8 d8 ae ff ff       	call   4030 <buf_put>
    9158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    915f:	00 
    9160:	48 83 c5 01          	add    $0x1,%rbp
    9164:	49 39 ec             	cmp    %rbp,%r12
    9167:	0f 84 c3 00 00 00    	je     9230 <fwp_write+0xcb0>
    916d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9172:	41 80 f9 0d          	cmp    $0xd,%r9b
    9176:	74 28                	je     91a0 <fwp_write+0xc20>
    9178:	7e b6                	jle    9130 <fwp_write+0xbb0>
    917a:	41 80 f9 22          	cmp    $0x22,%r9b
    917e:	74 40                	je     91c0 <fwp_write+0xc40>
    9180:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9184:	75 5a                	jne    91e0 <fwp_write+0xc60>
    9186:	ba 02 00 00 00       	mov    $0x2,%edx
    918b:	48 8d 35 e8 2f 00 00 	lea    0x2fe8(%rip),%rsi        # c17a <_IO_stdin_used+0x17a>
    9192:	48 89 df             	mov    %rbx,%rdi
    9195:	e8 96 ae ff ff       	call   4030 <buf_put>
    919a:	eb c4                	jmp    9160 <fwp_write+0xbe0>
    919c:	0f 1f 40 00          	nopl   0x0(%rax)
    91a0:	ba 02 00 00 00       	mov    $0x2,%edx
    91a5:	48 8d 35 d7 2f 00 00 	lea    0x2fd7(%rip),%rsi        # c183 <_IO_stdin_used+0x183>
    91ac:	48 89 df             	mov    %rbx,%rdi
    91af:	e8 7c ae ff ff       	call   4030 <buf_put>
    91b4:	eb aa                	jmp    9160 <fwp_write+0xbe0>
    91b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91bd:	00 00 00 
    91c0:	ba 02 00 00 00       	mov    $0x2,%edx
    91c5:	48 8d 35 ab 2f 00 00 	lea    0x2fab(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    91cc:	48 89 df             	mov    %rbx,%rdi
    91cf:	e8 5c ae ff ff       	call   4030 <buf_put>
    91d4:	eb 8a                	jmp    9160 <fwp_write+0xbe0>
    91d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91dd:	00 00 00 
    91e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    91e4:	0f 86 2e 01 00 00    	jbe    9318 <fwp_write+0xd98>
    91ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    91ee:	0f 84 24 01 00 00    	je     9318 <fwp_write+0xd98>
    91f4:	ba 01 00 00 00       	mov    $0x1,%edx
    91f9:	4c 89 fe             	mov    %r15,%rsi
    91fc:	48 89 df             	mov    %rbx,%rdi
    91ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9204:	e8 27 ae ff ff       	call   4030 <buf_put>
    9209:	e9 52 ff ff ff       	jmp    9160 <fwp_write+0xbe0>
    920e:	66 90                	xchg   %ax,%ax
    9210:	ba 02 00 00 00       	mov    $0x2,%edx
    9215:	48 8d 35 64 2f 00 00 	lea    0x2f64(%rip),%rsi        # c180 <_IO_stdin_used+0x180>
    921c:	48 89 df             	mov    %rbx,%rdi
    921f:	e8 0c ae ff ff       	call   4030 <buf_put>
    9224:	e9 37 ff ff ff       	jmp    9160 <fwp_write+0xbe0>
    9229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9230:	ba 01 00 00 00       	mov    $0x1,%edx
    9235:	4c 89 fe             	mov    %r15,%rsi
    9238:	48 89 df             	mov    %rbx,%rdi
    923b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9240:	e8 eb ad ff ff       	call   4030 <buf_put>
    9245:	e9 cc f3 ff ff       	jmp    8616 <fwp_write+0x96>
    924a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9250:	83 f8 04             	cmp    $0x4,%eax
    9253:	0f 85 bb fb ff ff    	jne    8e14 <fwp_write+0x894>
    9259:	48 8b 04 24          	mov    (%rsp),%rax
    925d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9261:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9266:	48 c1 e8 3f          	shr    $0x3f,%rax
    926a:	e9 96 fc ff ff       	jmp    8f05 <fwp_write+0x985>
    926f:	90                   	nop
    9270:	8b 0c 24             	mov    (%rsp),%ecx
    9273:	31 c0                	xor    %eax,%eax
    9275:	85 c9                	test   %ecx,%ecx
    9277:	0f 98 c0             	sets   %al
    927a:	e9 86 fc ff ff       	jmp    8f05 <fwp_write+0x985>
    927f:	90                   	nop
    9280:	48 f7 d8             	neg    %rax
    9283:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    928a:	00 
    928b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9292:	2d 
    9293:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    929a:	00 
    929b:	48 83 d2 00          	adc    $0x0,%rdx
    929f:	48 89 c6             	mov    %rax,%rsi
    92a2:	48 f7 da             	neg    %rdx
    92a5:	e8 56 a7 ff ff       	call   3a00 <fwp_fmt_u128>
    92aa:	e9 51 f3 ff ff       	jmp    8600 <fwp_write+0x80>
    92af:	90                   	nop
    92b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    92b5:	e9 c3 f5 ff ff       	jmp    887d <fwp_write+0x2fd>
    92ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92c0:	4c 89 e9             	mov    %r13,%rcx
    92c3:	48 c1 e1 04          	shl    $0x4,%rcx
    92c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    92cc:	48 85 ff             	test   %rdi,%rdi
    92cf:	0f 89 eb f9 ff ff    	jns    8cc0 <fwp_write+0x740>
    92d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    92d9:	48 89 ce             	mov    %rcx,%rsi
    92dc:	e9 df f9 ff ff       	jmp    8cc0 <fwp_write+0x740>
    92e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    92ef:	00 
    92f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    92f4:	e9 20 fa ff ff       	jmp    8d19 <fwp_write+0x799>
    92f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9300:	ba 02 00 00 00       	mov    $0x2,%edx
    9305:	48 8d 35 36 2e 00 00 	lea    0x2e36(%rip),%rsi        # c142 <_IO_stdin_used+0x142>
    930c:	e9 2d f7 ff ff       	jmp    8a3e <fwp_write+0x4be>
    9311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9318:	4c 8d 05 67 2e 00 00 	lea    0x2e67(%rip),%r8        # c186 <_IO_stdin_used+0x186>
    931f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9324:	31 c0                	xor    %eax,%eax
    9326:	ba 02 00 00 00       	mov    $0x2,%edx
    932b:	be 10 00 00 00       	mov    $0x10,%esi
    9330:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9337:	00 
    9338:	e8 53 a0 ff ff       	call   3390 <__snprintf_chk@plt>
    933d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9344:	00 
    9345:	e8 e6 a0 ff ff       	call   3430 <strlen@plt>
    934a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9351:	00 
    9352:	48 89 df             	mov    %rbx,%rdi
    9355:	48 89 c2             	mov    %rax,%rdx
    9358:	e8 d3 ac ff ff       	call   4030 <buf_put>
    935d:	e9 fe fd ff ff       	jmp    9160 <fwp_write+0xbe0>
    9362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9368:	66 0f ef c0          	pxor   %xmm0,%xmm0
    936c:	48 8d 35 c9 2d 00 00 	lea    0x2dc9(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    9373:	48 8d 05 c1 2d 00 00 	lea    0x2dc1(%rip),%rax        # c13b <_IO_stdin_used+0x13b>
    937a:	4c 89 e7             	mov    %r12,%rdi
    937d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9381:	48 0f 46 f0          	cmovbe %rax,%rsi
    9385:	e8 46 a0 ff ff       	call   33d0 <strcpy@plt>
    938a:	e9 71 f2 ff ff       	jmp    8600 <fwp_write+0x80>
    938f:	90                   	nop
    9390:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9394:	48 8d 35 a1 2d 00 00 	lea    0x2da1(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    939b:	48 8d 05 99 2d 00 00 	lea    0x2d99(%rip),%rax        # c13b <_IO_stdin_used+0x13b>
    93a2:	0f 2f c8             	comiss %xmm0,%xmm1
    93a5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93ac:	00 
    93ad:	4c 89 e7             	mov    %r12,%rdi
    93b0:	48 0f 46 f0          	cmovbe %rax,%rsi
    93b4:	e8 17 a0 ff ff       	call   33d0 <strcpy@plt>
    93b9:	e9 42 f2 ff ff       	jmp    8600 <fwp_write+0x80>
    93be:	66 90                	xchg   %ax,%ax
    93c0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    93c5:	45 85 c0             	test   %r8d,%r8d
    93c8:	75 34                	jne    93fe <fwp_write+0xe7e>
    93ca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    93d1:	00 
    93d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    93d9:	00 00 
    93db:	0f 85 74 f6 ff ff    	jne    8a55 <fwp_write+0x4d5>
    93e1:	ba 02 00 00 00       	mov    $0x2,%edx
    93e6:	48 8d 35 ca 2d 00 00 	lea    0x2dca(%rip),%rsi        # c1b7 <_IO_stdin_used+0x1b7>
    93ed:	e9 a1 f3 ff ff       	jmp    8793 <fwp_write+0x213>
    93f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    93f6:	49 89 f0             	mov    %rsi,%r8
    93f9:	e9 e5 fc ff ff       	jmp    90e3 <fwp_write+0xb63>
    93fe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9403:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9408:	85 ff                	test   %edi,%edi
    940a:	0f 84 fa f3 ff ff    	je     880a <fwp_write+0x28a>
    9410:	ba 01 00 00 00       	mov    $0x1,%edx
    9415:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    941a:	48 89 df             	mov    %rbx,%rdi
    941d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9422:	e8 09 ac ff ff       	call   4030 <buf_put>
    9427:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    942c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9431:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9437:	85 c0                	test   %eax,%eax
    9439:	0f 8f f0 f3 ff ff    	jg     882f <fwp_write+0x2af>
    943f:	e9 34 f4 ff ff       	jmp    8878 <fwp_write+0x2f8>
    9444:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9448:	49 89 c5             	mov    %rax,%r13
    944b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9450:	49 89 c4             	mov    %rax,%r12
    9453:	49 c1 fd 3f          	sar    $0x3f,%r13
    9457:	4c 09 e8             	or     %r13,%rax
    945a:	0f 84 a7 00 00 00    	je     9507 <fwp_write+0xf87>
    9460:	48 8d 2d 79 4e 00 00 	lea    0x4e79(%rip),%rbp        # e2e0 <units.0>
    9467:	4d 89 e7             	mov    %r12,%r15
    946a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    946e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9473:	4c 89 ff             	mov    %r15,%rdi
    9476:	4c 89 ee             	mov    %r13,%rsi
    9479:	44 89 0c 24          	mov    %r9d,(%rsp)
    947d:	48 99                	cqto
    947f:	48 89 d1             	mov    %rdx,%rcx
    9482:	48 89 c2             	mov    %rax,%rdx
    9485:	e8 e6 23 00 00       	call   b870 <__divmodti4>
    948a:	44 8b 0c 24          	mov    (%rsp),%r9d
    948e:	48 89 c1             	mov    %rax,%rcx
    9491:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9496:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    949b:	0f 84 94 00 00 00    	je     9535 <fwp_write+0xfb5>
    94a1:	41 83 c1 01          	add    $0x1,%r9d
    94a5:	48 83 c5 10          	add    $0x10,%rbp
    94a9:	41 83 f9 05          	cmp    $0x5,%r9d
    94ad:	75 bb                	jne    946a <fwp_write+0xeea>
    94af:	4d 85 ed             	test   %r13,%r13
    94b2:	79 53                	jns    9507 <fwp_write+0xf87>
    94b4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    94b9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    94be:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    94c3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    94c8:	48 99                	cqto
    94ca:	48 f7 d8             	neg    %rax
    94cd:	48 83 d2 00          	adc    $0x0,%rdx
    94d1:	48 89 c6             	mov    %rax,%rsi
    94d4:	48 f7 da             	neg    %rdx
    94d7:	e8 24 a5 ff ff       	call   3a00 <fwp_fmt_u128>
    94dc:	49 89 e8             	mov    %rbp,%r8
    94df:	ba 00 02 00 00       	mov    $0x200,%edx
    94e4:	be 02 00 00 00       	mov    $0x2,%esi
    94e9:	31 c0                	xor    %eax,%eax
    94eb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94f2:	00 
    94f3:	48 8d 0d b8 2c 00 00 	lea    0x2cb8(%rip),%rcx        # c1b2 <_IO_stdin_used+0x1b2>
    94fa:	4c 89 e7             	mov    %r12,%rdi
    94fd:	e8 9e a1 ff ff       	call   36a0 <__sprintf_chk@plt>
    9502:	e9 f9 f0 ff ff       	jmp    8600 <fwp_write+0x80>
    9507:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    950c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9511:	31 d2                	xor    %edx,%edx
    9513:	48 89 ef             	mov    %rbp,%rdi
    9516:	e8 e5 a4 ff ff       	call   3a00 <fwp_fmt_u128>
    951b:	eb bf                	jmp    94dc <fwp_write+0xf5c>
    951d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9524:	4e 61 4e 00 
    9528:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    952f:	00 
    9530:	e9 cb f0 ff ff       	jmp    8600 <fwp_write+0x80>
    9535:	44 89 0c 24          	mov    %r9d,(%rsp)
    9539:	48 89 c8             	mov    %rcx,%rax
    953c:	48 85 d2             	test   %rdx,%rdx
    953f:	78 51                	js     9592 <fwp_write+0x1012>
    9541:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9546:	48 89 c6             	mov    %rax,%rsi
    9549:	48 89 ef             	mov    %rbp,%rdi
    954c:	e8 af a4 ff ff       	call   3a00 <fwp_fmt_u128>
    9551:	44 8b 0c 24          	mov    (%rsp),%r9d
    9555:	49 63 c1             	movslq %r9d,%rax
    9558:	49 89 e8             	mov    %rbp,%r8
    955b:	ba 00 02 00 00       	mov    $0x200,%edx
    9560:	be 02 00 00 00       	mov    $0x2,%esi
    9565:	48 c1 e0 04          	shl    $0x4,%rax
    9569:	48 8d 3d 70 4d 00 00 	lea    0x4d70(%rip),%rdi        # e2e0 <units.0>
    9570:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9577:	00 
    9578:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    957c:	48 8d 0d 2a 2c 00 00 	lea    0x2c2a(%rip),%rcx        # c1ad <_IO_stdin_used+0x1ad>
    9583:	4c 89 e7             	mov    %r12,%rdi
    9586:	31 c0                	xor    %eax,%eax
    9588:	e8 13 a1 ff ff       	call   36a0 <__sprintf_chk@plt>
    958d:	e9 6e f0 ff ff       	jmp    8600 <fwp_write+0x80>
    9592:	48 f7 d8             	neg    %rax
    9595:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    959a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    959f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95a4:	48 83 d2 00          	adc    $0x0,%rdx
    95a8:	48 89 c6             	mov    %rax,%rsi
    95ab:	48 f7 da             	neg    %rdx
    95ae:	e8 4d a4 ff ff       	call   3a00 <fwp_fmt_u128>
    95b3:	44 8b 0c 24          	mov    (%rsp),%r9d
    95b7:	eb 9c                	jmp    9555 <fwp_write+0xfd5>
    95b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000095c0 <fwp_main_thread>:
    95c0:	f3 0f 1e fa          	endbr64
    95c4:	41 57                	push   %r15
    95c6:	41 56                	push   %r14
    95c8:	41 55                	push   %r13
    95ca:	41 54                	push   %r12
    95cc:	55                   	push   %rbp
    95cd:	53                   	push   %rbx
    95ce:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
    95d5:	44 8b 0d 08 85 01 00 	mov    0x18508(%rip),%r9d        # 21ae4 <fwp_heap+0x13a4>
    95dc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    95e3:	00 00 
    95e5:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    95ec:	00 
    95ed:	31 c0                	xor    %eax,%eax
    95ef:	45 85 c9             	test   %r9d,%r9d
    95f2:	0f 84 92 12 00 00    	je     a88a <fwp_main_thread+0x12ca>
    95f8:	44 8b 05 e9 84 01 00 	mov    0x184e9(%rip),%r8d        # 21ae8 <fwp_heap+0x13a8>
    95ff:	45 85 c0             	test   %r8d,%r8d
    9602:	0f 85 e4 05 00 00    	jne    9bec <fwp_main_thread+0x62c>
    9608:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    960f:	00 
    9610:	31 f6                	xor    %esi,%esi
    9612:	48 c7 05 cb 6a 01 00 	movq   $0x40000000,0x16acb(%rip)        # 200e8 <fwp_main_stack_size>
    9619:	00 00 00 40 
    961d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9622:	48 89 05 c7 6a 01 00 	mov    %rax,0x16ac7(%rip)        # 200f0 <fwp_main_stack_top>
    9629:	48 8d 05 50 6a 00 00 	lea    0x6a50(%rip),%rax        # 10080 <alt.5>
    9630:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9637:	00 
    9638:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    963f:	00 
    9640:	48 89 c7             	mov    %rax,%rdi
    9643:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9648:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    964f:	00 00 00 01 00 
    9654:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    965b:	00 00 00 00 
    965f:	e8 1c a0 ff ff       	call   3680 <sigaltstack@plt>
    9664:	85 c0                	test   %eax,%eax
    9666:	0f 85 a4 21 00 00    	jne    b810 <fwp_main_thread+0x2250>
    966c:	31 db                	xor    %ebx,%ebx
    966e:	b9 12 00 00 00       	mov    $0x12,%ecx
    9673:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
    967a:	00 
    967b:	48 89 d8             	mov    %rbx,%rax
    967e:	4c 8d b4 24 30 01 00 	lea    0x130(%rsp),%r14
    9685:	00 
    9686:	f3 48 ab             	rep stos %rax,(%rdi)
    9689:	48 8d 05 20 a6 ff ff 	lea    -0x59e0(%rip),%rax        # 3cb0 <fwp_segv>
    9690:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
    9697:	00 
    9698:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    969d:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
    96a4:	00 
    96a5:	c7 84 24 b8 01 00 00 	movl   $0x8000004,0x1b8(%rsp)
    96ac:	04 00 00 08 
    96b0:	e8 9b 9e ff ff       	call   3550 <sigemptyset@plt>
    96b5:	85 c0                	test   %eax,%eax
    96b7:	0f 85 53 21 00 00    	jne    b810 <fwp_main_thread+0x2250>
    96bd:	31 d2                	xor    %edx,%edx
    96bf:	4c 89 f6             	mov    %r14,%rsi
    96c2:	bf 0b 00 00 00       	mov    $0xb,%edi
    96c7:	e8 14 9d ff ff       	call   33e0 <sigaction@plt>
    96cc:	85 c0                	test   %eax,%eax
    96ce:	0f 85 3c 21 00 00    	jne    b810 <fwp_main_thread+0x2250>
    96d4:	31 d2                	xor    %edx,%edx
    96d6:	4c 89 f6             	mov    %r14,%rsi
    96d9:	bf 07 00 00 00       	mov    $0x7,%edi
    96de:	e8 fd 9c ff ff       	call   33e0 <sigaction@plt>
    96e3:	85 c0                	test   %eax,%eax
    96e5:	0f 85 25 21 00 00    	jne    b810 <fwp_main_thread+0x2250>
    96eb:	8b 3d 7f 69 00 00    	mov    0x697f(%rip),%edi        # 10070 <st.3>
    96f1:	85 ff                	test   %edi,%edi
    96f3:	0f 84 04 05 00 00    	je     9bfd <fwp_main_thread+0x63d>
    96f9:	48 8b 2d 20 70 01 00 	mov    0x17020(%rip),%rbp        # 20720 <fwp_cur>
    9700:	48 85 ed             	test   %rbp,%rbp
    9703:	0f 84 c6 01 00 00    	je     98cf <fwp_main_thread+0x30f>
    9709:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    970e:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9712:	48 89 eb             	mov    %rbp,%rbx
    9715:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    971a:	0f 84 41 01 00 00    	je     9861 <fwp_main_thread+0x2a1>
    9720:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9725:	0f 84 e5 03 00 00    	je     9b10 <fwp_main_thread+0x550>
    972b:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    972f:	0f 84 b3 03 00 00    	je     9ae8 <fwp_main_thread+0x528>
    9735:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9739:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    973d:	0f 85 4d 04 00 00    	jne    9b90 <fwp_main_thread+0x5d0>
    9743:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9747:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    974e:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9752:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9759:	00 00 00 00 
    975d:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9764:	48 85 d2             	test   %rdx,%rdx
    9767:	74 07                	je     9770 <fwp_main_thread+0x1b0>
    9769:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9770:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9774:	48 85 c0             	test   %rax,%rax
    9777:	74 34                	je     97ad <fwp_main_thread+0x1ed>
    9779:	48 89 43 68          	mov    %rax,0x68(%rbx)
    977d:	48 8b 05 74 6f 01 00 	mov    0x16f74(%rip),%rax        # 206f8 <fwp_timers>
    9784:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9788:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    978f:	00 00 00 00 
    9793:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    979a:	48 85 c0             	test   %rax,%rax
    979d:	74 07                	je     97a6 <fwp_main_thread+0x1e6>
    979f:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    97a6:	48 89 1d 4b 6f 01 00 	mov    %rbx,0x16f4b(%rip)        # 206f8 <fwp_timers>
    97ad:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    97b1:	e8 3a de ff ff       	call   75f0 <fwp_block>
    97b6:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    97bd:	48 85 c9             	test   %rcx,%rcx
    97c0:	74 47                	je     9809 <fwp_main_thread+0x249>
    97c2:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    97c9:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    97d0:	48 85 d2             	test   %rdx,%rdx
    97d3:	0f 84 f7 03 00 00    	je     9bd0 <fwp_main_thread+0x610>
    97d9:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    97e0:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    97e7:	48 85 c0             	test   %rax,%rax
    97ea:	74 07                	je     97f3 <fwp_main_thread+0x233>
    97ec:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    97f3:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    97fa:	00 00 00 00 
    97fe:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9802:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9809:	48 8b 0d 10 6f 01 00 	mov    0x16f10(%rip),%rcx        # 20720 <fwp_cur>
    9810:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9814:	0f 84 66 03 00 00    	je     9b80 <fwp_main_thread+0x5c0>
    981a:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9821:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9828:	48 85 d2             	test   %rdx,%rdx
    982b:	0f 84 af 03 00 00    	je     9be0 <fwp_main_thread+0x620>
    9831:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9838:	48 85 c0             	test   %rax,%rax
    983b:	74 07                	je     9844 <fwp_main_thread+0x284>
    983d:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9844:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9848:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    984c:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9853:	48 89 cb             	mov    %rcx,%rbx
    9856:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    985b:	0f 85 bf fe ff ff    	jne    9720 <fwp_main_thread+0x160>
    9861:	48 83 3d 4f 8b 01 00 	cmpq   $0x0,0x18b4f(%rip)        # 223b8 <fwp_state_len>
    9868:	00 
    9869:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    986d:	75 0e                	jne    987d <fwp_main_thread+0x2bd>
    986f:	48 83 3d 31 8b 01 00 	cmpq   $0x0,0x18b31(%rip)        # 223a8 <fwp_state_owners>
    9876:	00 
    9877:	0f 84 be 1d 00 00    	je     b63b <fwp_main_thread+0x207b>
    987d:	48 39 1d 94 6e 01 00 	cmp    %rbx,0x16e94(%rip)        # 20718 <fwp_root>
    9884:	c7 05 f2 67 01 00 00 	movl   $0x0,0x167f2(%rip)        # 20080 <fwp_exit_code>
    988b:	00 00 00 
    988e:	0f 85 c9 1f 00 00    	jne    b85d <fwp_main_thread+0x229d>
    9894:	48 85 db             	test   %rbx,%rbx
    9897:	74 5c                	je     98f5 <fwp_main_thread+0x335>
    9899:	48 8b 15 48 6e 01 00 	mov    0x16e48(%rip),%rdx        # 206e8 <fwp_tasks_active>
    98a0:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    98a4:	48 85 d2             	test   %rdx,%rdx
    98a7:	74 4c                	je     98f5 <fwp_main_thread+0x335>
    98a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    98b0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    98b4:	75 08                	jne    98be <fwp_main_thread+0x2fe>
    98b6:	48 89 d7             	mov    %rdx,%rdi
    98b9:	e8 b2 a7 ff ff       	call   4070 <fwp_cancel_tree.part.0>
    98be:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    98c5:	48 85 d2             	test   %rdx,%rdx
    98c8:	75 e6                	jne    98b0 <fwp_main_thread+0x2f0>
    98ca:	e9 e6 01 00 00       	jmp    9ab5 <fwp_main_thread+0x4f5>
    98cf:	48 83 3d e1 8a 01 00 	cmpq   $0x0,0x18ae1(%rip)        # 223b8 <fwp_state_len>
    98d6:	00 
    98d7:	0f 84 84 1c 00 00    	je     b561 <fwp_main_thread+0x1fa1>
    98dd:	48 83 3d 33 6e 01 00 	cmpq   $0x0,0x16e33(%rip)        # 20718 <fwp_root>
    98e4:	00 
    98e5:	c7 05 91 67 01 00 00 	movl   $0x0,0x16791(%rip)        # 20080 <fwp_exit_code>
    98ec:	00 00 00 
    98ef:	0f 85 63 1f 00 00    	jne    b858 <fwp_main_thread+0x2298>
    98f5:	e8 e6 da ff ff       	call   73e0 <fwp_free_zombie>
    98fa:	48 83 3d 06 6e 01 00 	cmpq   $0x0,0x16e06(%rip)        # 20708 <fwp_ready_head>
    9901:	00 
    9902:	0f 85 03 9e ff ff    	jne    370b <fwp_main_thread.cold>
    9908:	48 83 3d e8 6d 01 00 	cmpq   $0x0,0x16de8(%rip)        # 206f8 <fwp_timers>
    990f:	00 
    9910:	0f 85 f5 9d ff ff    	jne    370b <fwp_main_thread.cold>
    9916:	8b 05 e0 67 01 00    	mov    0x167e0(%rip),%eax        # 200fc <fwp_stack_pool_n>
    991c:	85 c0                	test   %eax,%eax
    991e:	74 3d                	je     995d <fwp_main_thread+0x39d>
    9920:	83 e8 01             	sub    $0x1,%eax
    9923:	4c 8d 25 d6 67 01 00 	lea    0x167d6(%rip),%r12        # 20100 <fwp_stack_pool>
    992a:	48 63 d8             	movslq %eax,%rbx
    992d:	89 c0                	mov    %eax,%eax
    992f:	48 89 da             	mov    %rbx,%rdx
    9932:	48 29 c2             	sub    %rax,%rdx
    9935:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9940:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9944:	89 1d b2 67 01 00    	mov    %ebx,0x167b2(%rip)        # 200fc <fwp_stack_pool_n>
    994a:	be 00 00 00 10       	mov    $0x10000000,%esi
    994f:	48 83 eb 01          	sub    $0x1,%rbx
    9953:	e8 58 9c ff ff       	call   35b0 <munmap@plt>
    9958:	48 39 eb             	cmp    %rbp,%rbx
    995b:	75 e3                	jne    9940 <fwp_main_thread+0x380>
    995d:	8b 3d b5 66 00 00    	mov    0x66b5(%rip),%edi        # 10018 <fwp_epfd>
    9963:	85 ff                	test   %edi,%edi
    9965:	78 05                	js     996c <fwp_main_thread+0x3ac>
    9967:	e8 44 9b ff ff       	call   34b0 <close@plt>
    996c:	4c 8b 25 8d 69 01 00 	mov    0x1698d(%rip),%r12        # 20300 <fwp_nfdws>
    9973:	48 8b 2d 8e 69 01 00 	mov    0x1698e(%rip),%rbp        # 20308 <fwp_fdws>
    997a:	31 db                	xor    %ebx,%ebx
    997c:	c7 05 92 66 00 00 ff 	movl   $0xffffffff,0x6692(%rip)        # 10018 <fwp_epfd>
    9983:	ff ff ff 
    9986:	4d 85 e4             	test   %r12,%r12
    9989:	74 32                	je     99bd <fwp_main_thread+0x3fd>
    998b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9990:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9995:	48 85 ff             	test   %rdi,%rdi
    9998:	74 1a                	je     99b4 <fwp_main_thread+0x3f4>
    999a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    999e:	0f 85 67 9d ff ff    	jne    370b <fwp_main_thread.cold>
    99a4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    99a9:	0f 85 5c 9d ff ff    	jne    370b <fwp_main_thread.cold>
    99af:	e8 5c bb ff ff       	call   5510 <fwp_mem_free>
    99b4:	48 83 c3 01          	add    $0x1,%rbx
    99b8:	4c 39 e3             	cmp    %r12,%rbx
    99bb:	75 d3                	jne    9990 <fwp_main_thread+0x3d0>
    99bd:	48 89 ef             	mov    %rbp,%rdi
    99c0:	e8 4b bb ff ff       	call   5510 <fwp_mem_free>
    99c5:	48 8b 15 4c 6d 01 00 	mov    0x16d4c(%rip),%rdx        # 20718 <fwp_root>
    99cc:	48 c7 05 31 69 01 00 	movq   $0x0,0x16931(%rip)        # 20308 <fwp_fdws>
    99d3:	00 00 00 00 
    99d7:	48 c7 05 1e 69 01 00 	movq   $0x0,0x1691e(%rip)        # 20300 <fwp_nfdws>
    99de:	00 00 00 00 
    99e2:	48 85 d2             	test   %rdx,%rdx
    99e5:	74 4e                	je     9a35 <fwp_main_thread+0x475>
    99e7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    99ec:	0f 85 19 9d ff ff    	jne    370b <fwp_main_thread.cold>
    99f2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    99f9:	00 
    99fa:	0f 85 0b 9d ff ff    	jne    370b <fwp_main_thread.cold>
    9a00:	48 83 3d b0 89 01 00 	cmpq   $0x0,0x189b0(%rip)        # 223b8 <fwp_state_len>
    9a07:	00 
    9a08:	0f 85 fd 9c ff ff    	jne    370b <fwp_main_thread.cold>
    9a0e:	48 83 3d 92 89 01 00 	cmpq   $0x0,0x18992(%rip)        # 223a8 <fwp_state_owners>
    9a15:	00 
    9a16:	0f 85 ef 9c ff ff    	jne    370b <fwp_main_thread.cold>
    9a1c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9a21:	31 c0                	xor    %eax,%eax
    9a23:	48 8d 3d f6 68 01 00 	lea    0x168f6(%rip),%rdi        # 20320 <fwp_root_context>
    9a2a:	f3 48 ab             	rep stos %rax,(%rdi)
    9a2d:	48 89 d7             	mov    %rdx,%rdi
    9a30:	e8 db ba ff ff       	call   5510 <fwp_mem_free>
    9a35:	48 8b 3d e4 65 00 00 	mov    0x65e4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9a3c:	48 c7 05 d9 6c 01 00 	movq   $0x0,0x16cd9(%rip)        # 20720 <fwp_cur>
    9a43:	00 00 00 00 
    9a47:	48 c7 05 c6 6c 01 00 	movq   $0x0,0x16cc6(%rip)        # 20718 <fwp_root>
    9a4e:	00 00 00 00 
    9a52:	e8 39 9b ff ff       	call   3590 <fflush@plt>
    9a57:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
    9a5e:	00 
    9a5f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a66:	00 00 
    9a68:	0f 85 ba 1d 00 00    	jne    b828 <fwp_main_thread+0x2268>
    9a6e:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
    9a75:	31 c0                	xor    %eax,%eax
    9a77:	5b                   	pop    %rbx
    9a78:	5d                   	pop    %rbp
    9a79:	41 5c                	pop    %r12
    9a7b:	41 5d                	pop    %r13
    9a7d:	41 5e                	pop    %r14
    9a7f:	41 5f                	pop    %r15
    9a81:	c3                   	ret
    9a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a88:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9a8f:	48 89 1d 6a 6c 01 00 	mov    %rbx,0x16c6a(%rip)        # 20700 <fwp_ready_tail>
    9a96:	e8 55 db ff ff       	call   75f0 <fwp_block>
    9a9b:	e8 40 d9 ff ff       	call   73e0 <fwp_free_zombie>
    9aa0:	48 83 3d 40 6c 01 00 	cmpq   $0x0,0x16c40(%rip)        # 206e8 <fwp_tasks_active>
    9aa7:	00 
    9aa8:	0f 84 47 fe ff ff    	je     98f5 <fwp_main_thread+0x335>
    9aae:	48 8b 1d 63 6c 01 00 	mov    0x16c63(%rip),%rbx        # 20718 <fwp_root>
    9ab5:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9ab9:	75 db                	jne    9a96 <fwp_main_thread+0x4d6>
    9abb:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9abf:	75 d5                	jne    9a96 <fwp_main_thread+0x4d6>
    9ac1:	48 8b 05 38 6c 01 00 	mov    0x16c38(%rip),%rax        # 20700 <fwp_ready_tail>
    9ac8:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9acc:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9ad3:	00 00 00 00 
    9ad7:	48 85 c0             	test   %rax,%rax
    9ada:	75 ac                	jne    9a88 <fwp_main_thread+0x4c8>
    9adc:	48 89 1d 25 6c 01 00 	mov    %rbx,0x16c25(%rip)        # 20708 <fwp_ready_head>
    9ae3:	eb aa                	jmp    9a8f <fwp_main_thread+0x4cf>
    9ae5:	0f 1f 00             	nopl   (%rax)
    9ae8:	e8 e3 a7 ff ff       	call   42d0 <fwp_now_ns>
    9aed:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9af1:	7c 1d                	jl     9b10 <fwp_main_thread+0x550>
    9af3:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9af7:	75 17                	jne    9b10 <fwp_main_thread+0x550>
    9af9:	48 89 ef             	mov    %rbp,%rdi
    9afc:	e8 6f a5 ff ff       	call   4070 <fwp_cancel_tree.part.0>
    9b01:	0f 1f 40 00          	nopl   0x0(%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9b14:	0f 85 1b fc ff ff    	jne    9735 <fwp_main_thread+0x175>
    9b1a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9b1e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9b22:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9b26:	0f 85 1b fc ff ff    	jne    9747 <fwp_main_thread+0x187>
    9b2c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9b30:	48 85 c9             	test   %rcx,%rcx
    9b33:	0f 84 0e fc ff ff    	je     9747 <fwp_main_thread+0x187>
    9b39:	48 39 c8             	cmp    %rcx,%rax
    9b3c:	48 89 ce             	mov    %rcx,%rsi
    9b3f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9b46:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9b4a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9b51:	00 00 00 00 
    9b55:	48 0f 4e f0          	cmovle %rax,%rsi
    9b59:	48 85 c0             	test   %rax,%rax
    9b5c:	48 89 c8             	mov    %rcx,%rax
    9b5f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9b66:	48 0f 45 c6          	cmovne %rsi,%rax
    9b6a:	48 85 d2             	test   %rdx,%rdx
    9b6d:	74 07                	je     9b76 <fwp_main_thread+0x5b6>
    9b6f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9b76:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9b7a:	e9 fa fb ff ff       	jmp    9779 <fwp_main_thread+0x1b9>
    9b7f:	90                   	nop
    9b80:	48 89 cb             	mov    %rcx,%rbx
    9b83:	e9 8d fb ff ff       	jmp    9715 <fwp_main_thread+0x155>
    9b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b8f:	00 
    9b90:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9b94:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9b9b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9ba2:	00 00 00 00 
    9ba6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9bad:	48 85 c0             	test   %rax,%rax
    9bb0:	0f 84 55 19 00 00    	je     b50b <fwp_main_thread+0x1f4b>
    9bb6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9bbd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9bc1:	e9 e7 fb ff ff       	jmp    97ad <fwp_main_thread+0x1ed>
    9bc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9bcd:	00 00 00 
    9bd0:	48 89 01             	mov    %rax,(%rcx)
    9bd3:	e9 0f fc ff ff       	jmp    97e7 <fwp_main_thread+0x227>
    9bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9bdf:	00 
    9be0:	48 89 05 11 6b 01 00 	mov    %rax,0x16b11(%rip)        # 206f8 <fwp_timers>
    9be7:	e9 4c fc ff ff       	jmp    9838 <fwp_main_thread+0x278>
    9bec:	48 8d 3d ed ad ff ff 	lea    -0x5213(%rip),%rdi        # 49e0 <fwp_heap_report>
    9bf3:	e8 88 1e 00 00       	call   ba80 <atexit>
    9bf8:	e9 0b fa ff ff       	jmp    9608 <fwp_main_thread+0x48>
    9bfd:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    9c02:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    9c07:	48 8d 05 02 e0 ff ff 	lea    -0x1ffe(%rip),%rax        # 7c10 <fwp_drop1>
    9c0e:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9c15:	00 00 00 00 00 
    9c1a:	66 48 0f 6e f0       	movq   %rax,%xmm6
    9c1f:	48 8b 05 b2 87 01 00 	mov    0x187b2(%rip),%rax        # 223d8 <fwp_cleanups>
    9c26:	bd 03 00 00 00       	mov    $0x3,%ebp
    9c2b:	4c 8d 2d 0e 6b 01 00 	lea    0x16b0e(%rip),%r13        # 20740 <fwp_heap>
    9c32:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9c36:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9c3d:	00 
    9c3e:	48 8d 05 4b 9f ff ff 	lea    -0x60b5(%rip),%rax        # 3b90 <fwp_range_release>
    9c45:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9c4c:	00 
    9c4d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9c52:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9c59:	00 
    9c5a:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9c61:	00 
    9c62:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9c67:	48 89 05 6a 87 01 00 	mov    %rax,0x1876a(%rip)        # 223d8 <fwp_cleanups>
    9c6e:	eb 3e                	jmp    9cae <fwp_main_thread+0x6ee>
    9c70:	80 f9 01             	cmp    $0x1,%cl
    9c73:	75 27                	jne    9c9c <fwp_main_thread+0x6dc>
    9c75:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c78:	0f b7 c0             	movzwl %ax,%eax
    9c7b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c7e:	48 0f af c1          	imul   %rcx,%rax
    9c82:	48 c1 e8 20          	shr    $0x20,%rax
    9c86:	48 39 d0             	cmp    %rdx,%rax
    9c89:	73 11                	jae    9c9c <fwp_main_thread+0x6dc>
    9c8b:	49 01 c6             	add    %rax,%r14
    9c8e:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9c92:	0f 84 fa 18 00 00    	je     b592 <fwp_main_thread+0x1fd2>
    9c98:	41 c6 06 01          	movb   $0x1,(%r14)
    9c9c:	48 89 9c 24 d0 00 00 	mov    %rbx,0xd0(%rsp)
    9ca3:	00 
    9ca4:	48 83 ed 01          	sub    $0x1,%rbp
    9ca8:	0f 82 85 00 00 00    	jb     9d33 <fwp_main_thread+0x773>
    9cae:	4c 89 e6             	mov    %r12,%rsi
    9cb1:	bf 01 00 00 00       	mov    $0x1,%edi
    9cb6:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
    9cbd:	00 
    9cbe:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
    9cc5:	00 
    9cc6:	48 89 ac 24 30 01 00 	mov    %rbp,0x130(%rsp)
    9ccd:	00 
    9cce:	e8 5d be ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    9cd3:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9cda:	48 89 c3             	mov    %rax,%rbx
    9cdd:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9ce4:	48 c1 e2 10          	shl    $0x10,%rdx
    9ce8:	48 39 d0             	cmp    %rdx,%rax
    9ceb:	73 af                	jae    9c9c <fwp_main_thread+0x6dc>
    9ced:	48 89 c2             	mov    %rax,%rdx
    9cf0:	48 c1 ea 10          	shr    $0x10,%rdx
    9cf4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9cf8:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9cff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d03:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9d07:	4d 85 f6             	test   %r14,%r14
    9d0a:	74 90                	je     9c9c <fwp_main_thread+0x6dc>
    9d0c:	0f b6 0a             	movzbl (%rdx),%ecx
    9d0f:	80 f9 02             	cmp    $0x2,%cl
    9d12:	0f 85 58 ff ff ff    	jne    9c70 <fwp_main_thread+0x6b0>
    9d18:	66 85 c0             	test   %ax,%ax
    9d1b:	0f 84 6d ff ff ff    	je     9c8e <fwp_main_thread+0x6ce>
    9d21:	48 89 9c 24 d0 00 00 	mov    %rbx,0xd0(%rsp)
    9d28:	00 
    9d29:	48 83 ed 01          	sub    $0x1,%rbp
    9d2d:	0f 83 7b ff ff ff    	jae    9cae <fwp_main_thread+0x6ee>
    9d33:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    9d3a:	00 
    9d3b:	66 0f 6f 05 2d 2e 00 	movdqa 0x2e2d(%rip),%xmm0        # cb70 <msg.4+0xf0>
    9d42:	00 
    9d43:	bf 01 00 00 00       	mov    $0x1,%edi
    9d48:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9d4f:	00 
    9d50:	48 89 05 81 86 01 00 	mov    %rax,0x18681(%rip)        # 223d8 <fwp_cleanups>
    9d57:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
    9d5e:	00 
    9d5f:	e8 cc bd ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    9d64:	48 8b 15 ad 7d 01 00 	mov    0x17dad(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    9d6b:	49 89 c4             	mov    %rax,%r12
    9d6e:	48 2b 05 7b 7d 01 00 	sub    0x17d7b(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    9d75:	48 c1 e2 10          	shl    $0x10,%rdx
    9d79:	48 39 d0             	cmp    %rdx,%rax
    9d7c:	73 57                	jae    9dd5 <fwp_main_thread+0x815>
    9d7e:	48 89 c2             	mov    %rax,%rdx
    9d81:	48 c1 ea 10          	shr    $0x10,%rdx
    9d85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d89:	48 8b 15 a8 7d 01 00 	mov    0x17da8(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    9d90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d94:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9d98:	48 85 ed             	test   %rbp,%rbp
    9d9b:	74 38                	je     9dd5 <fwp_main_thread+0x815>
    9d9d:	0f b6 0a             	movzbl (%rdx),%ecx
    9da0:	80 f9 02             	cmp    $0x2,%cl
    9da3:	0f 84 cd 17 00 00    	je     b576 <fwp_main_thread+0x1fb6>
    9da9:	80 f9 01             	cmp    $0x1,%cl
    9dac:	75 27                	jne    9dd5 <fwp_main_thread+0x815>
    9dae:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9db1:	0f b7 c0             	movzwl %ax,%eax
    9db4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9db7:	48 0f af c1          	imul   %rcx,%rax
    9dbb:	48 c1 e8 20          	shr    $0x20,%rax
    9dbf:	48 39 d0             	cmp    %rdx,%rax
    9dc2:	73 11                	jae    9dd5 <fwp_main_thread+0x815>
    9dc4:	48 01 c5             	add    %rax,%rbp
    9dc7:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9dcb:	0f 84 9c 19 00 00    	je     b76d <fwp_main_thread+0x21ad>
    9dd1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9dd5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9ddc:	00 f0 3f 
    9ddf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9de6:	00 
    9de7:	bf 01 00 00 00       	mov    $0x1,%edi
    9dec:	4c 89 a4 24 18 01 00 	mov    %r12,0x118(%rsp)
    9df3:	00 
    9df4:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    9dfb:	00 
    9dfc:	e8 2f bd ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    9e01:	48 8b 15 10 7d 01 00 	mov    0x17d10(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    9e08:	49 89 c4             	mov    %rax,%r12
    9e0b:	48 2b 05 de 7c 01 00 	sub    0x17cde(%rip),%rax        # 21af0 <fwp_heap+0x13b0>
    9e12:	48 c1 e2 10          	shl    $0x10,%rdx
    9e16:	48 39 d0             	cmp    %rdx,%rax
    9e19:	73 57                	jae    9e72 <fwp_main_thread+0x8b2>
    9e1b:	48 89 c2             	mov    %rax,%rdx
    9e1e:	48 c1 ea 10          	shr    $0x10,%rdx
    9e22:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e26:	48 8b 15 0b 7d 01 00 	mov    0x17d0b(%rip),%rdx        # 21b38 <fwp_heap+0x13f8>
    9e2d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e31:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9e35:	48 85 ed             	test   %rbp,%rbp
    9e38:	74 38                	je     9e72 <fwp_main_thread+0x8b2>
    9e3a:	0f b6 0a             	movzbl (%rdx),%ecx
    9e3d:	80 f9 02             	cmp    $0x2,%cl
    9e40:	0f 84 22 17 00 00    	je     b568 <fwp_main_thread+0x1fa8>
    9e46:	80 f9 01             	cmp    $0x1,%cl
    9e49:	75 27                	jne    9e72 <fwp_main_thread+0x8b2>
    9e4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e4e:	0f b7 c0             	movzwl %ax,%eax
    9e51:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e54:	48 0f af c1          	imul   %rcx,%rax
    9e58:	48 c1 e8 20          	shr    $0x20,%rax
    9e5c:	48 39 d0             	cmp    %rdx,%rax
    9e5f:	73 11                	jae    9e72 <fwp_main_thread+0x8b2>
    9e61:	48 01 c5             	add    %rax,%rbp
    9e64:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9e68:	0f 84 0c 19 00 00    	je     b77a <fwp_main_thread+0x21ba>
    9e6e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9e72:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9e79:	33 f3 bf 
    9e7c:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    9e83:	00 
    9e84:	bf 01 00 00 00       	mov    $0x1,%edi
    9e89:	4c 89 a4 24 08 01 00 	mov    %r12,0x108(%rsp)
    9e90:	00 
    9e91:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
    9e98:	00 
    9e99:	e8 92 bc ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    9e9e:	48 8b 15 73 7c 01 00 	mov    0x17c73(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    9ea5:	48 8b 0d 44 7c 01 00 	mov    0x17c44(%rip),%rcx        # 21af0 <fwp_heap+0x13b0>
    9eac:	49 89 c6             	mov    %rax,%r14
    9eaf:	48 89 d6             	mov    %rdx,%rsi
    9eb2:	48 29 c8             	sub    %rcx,%rax
    9eb5:	48 c1 e6 10          	shl    $0x10,%rsi
    9eb9:	48 39 f0             	cmp    %rsi,%rax
    9ebc:	73 67                	jae    9f25 <fwp_main_thread+0x965>
    9ebe:	48 89 c6             	mov    %rax,%rsi
    9ec1:	48 c1 ee 10          	shr    $0x10,%rsi
    9ec5:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9ec9:	48 8b 35 68 7c 01 00 	mov    0x17c68(%rip),%rsi        # 21b38 <fwp_heap+0x13f8>
    9ed0:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9ed4:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    9ed8:	48 85 ed             	test   %rbp,%rbp
    9edb:	74 48                	je     9f25 <fwp_main_thread+0x965>
    9edd:	0f b6 3e             	movzbl (%rsi),%edi
    9ee0:	40 80 ff 02          	cmp    $0x2,%dil
    9ee4:	0f 84 9a 16 00 00    	je     b584 <fwp_main_thread+0x1fc4>
    9eea:	40 80 ff 01          	cmp    $0x1,%dil
    9eee:	75 35                	jne    9f25 <fwp_main_thread+0x965>
    9ef0:	8b 7e 18             	mov    0x18(%rsi),%edi
    9ef3:	0f b7 c0             	movzwl %ax,%eax
    9ef6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9ef9:	48 0f af c7          	imul   %rdi,%rax
    9efd:	48 c1 e8 20          	shr    $0x20,%rax
    9f01:	48 39 f0             	cmp    %rsi,%rax
    9f04:	73 1f                	jae    9f25 <fwp_main_thread+0x965>
    9f06:	48 01 c5             	add    %rax,%rbp
    9f09:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9f0d:	0f 84 4d 18 00 00    	je     b760 <fwp_main_thread+0x21a0>
    9f13:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9f17:	48 8b 0d d2 7b 01 00 	mov    0x17bd2(%rip),%rcx        # 21af0 <fwp_heap+0x13b0>
    9f1e:	48 8b 15 f3 7b 01 00 	mov    0x17bf3(%rip),%rdx        # 21b18 <fwp_heap+0x13d8>
    9f25:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
    9f2a:	49 89 dc             	mov    %rbx,%r12
    9f2d:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    9f32:	0f 1f 00             	nopl   (%rax)
    9f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f3c:	00 00 00 00 
    9f40:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    9f45:	48 c1 e2 10          	shl    $0x10,%rdx
    9f49:	48 29 c8             	sub    %rcx,%rax
    9f4c:	48 39 d0             	cmp    %rdx,%rax
    9f4f:	73 5d                	jae    9fae <fwp_main_thread+0x9ee>
    9f51:	48 89 c2             	mov    %rax,%rdx
    9f54:	48 c1 ea 10          	shr    $0x10,%rdx
    9f58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f5c:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9f63:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f67:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9f6b:	48 85 ff             	test   %rdi,%rdi
    9f6e:	74 3e                	je     9fae <fwp_main_thread+0x9ee>
    9f70:	0f b6 0a             	movzbl (%rdx),%ecx
    9f73:	80 f9 02             	cmp    $0x2,%cl
    9f76:	0f 84 84 14 00 00    	je     b400 <fwp_main_thread+0x1e40>
    9f7c:	80 f9 01             	cmp    $0x1,%cl
    9f7f:	75 2d                	jne    9fae <fwp_main_thread+0x9ee>
    9f81:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f84:	0f b7 c0             	movzwl %ax,%eax
    9f87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f8a:	48 0f af c1          	imul   %rcx,%rax
    9f8e:	48 c1 e8 20          	shr    $0x20,%rax
    9f92:	48 39 d0             	cmp    %rdx,%rax
    9f95:	73 17                	jae    9fae <fwp_main_thread+0x9ee>
    9f97:	48 01 c7             	add    %rax,%rdi
    9f9a:	0f b6 07             	movzbl (%rdi),%eax
    9f9d:	84 c0                	test   %al,%al
    9f9f:	74 0d                	je     9fae <fwp_main_thread+0x9ee>
    9fa1:	3c fd                	cmp    $0xfd,%al
    9fa3:	0f 87 f7 16 00 00    	ja     b6a0 <fwp_main_thread+0x20e0>
    9fa9:	83 c0 01             	add    $0x1,%eax
    9fac:	88 07                	mov    %al,(%rdi)
    9fae:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
    9fb3:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
    9fb8:	45 31 c0             	xor    %r8d,%r8d
    9fbb:	48 c7 44 24 30 ce 07 	movq   $0x7ce,0x30(%rsp)
    9fc2:	00 00 
    9fc4:	4d 89 c4             	mov    %r8,%r12
    9fc7:	4d 85 c0             	test   %r8,%r8
    9fca:	0f 85 40 97 ff ff    	jne    3710 <fwp_main_thread.cold+0x5>
    9fd0:	48 8b 05 01 84 01 00 	mov    0x18401(%rip),%rax        # 223d8 <fwp_cleanups>
    9fd7:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9fde:	4c 8d 35 1b cf ff ff 	lea    -0x30e5(%rip),%r14        # 6f00 <fwp_tape_scope_release>
    9fe5:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9fec:	ff ff ff ff 
    9ff0:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
    9ff7:	00 
    9ff8:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9fff:	00 
    a000:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    a007:	00 
    a008:	48 c1 e2 10          	shl    $0x10,%rdx
    a00c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    a011:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a018:	00 
    a019:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a020:	00 
    a021:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a026:	48 89 05 ab 83 01 00 	mov    %rax,0x183ab(%rip)        # 223d8 <fwp_cleanups>
    a02d:	48 8d 05 dc 5f 00 00 	lea    0x5fdc(%rip),%rax        # 10010 <fc37>
    a034:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a03b:	48 39 d0             	cmp    %rdx,%rax
    a03e:	73 5d                	jae    a09d <fwp_main_thread+0xadd>
    a040:	48 89 c2             	mov    %rax,%rdx
    a043:	48 c1 ea 10          	shr    $0x10,%rdx
    a047:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a04b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a052:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a056:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a05a:	48 85 ff             	test   %rdi,%rdi
    a05d:	74 3e                	je     a09d <fwp_main_thread+0xadd>
    a05f:	0f b6 0a             	movzbl (%rdx),%ecx
    a062:	80 f9 02             	cmp    $0x2,%cl
    a065:	0f 84 25 12 00 00    	je     b290 <fwp_main_thread+0x1cd0>
    a06b:	80 f9 01             	cmp    $0x1,%cl
    a06e:	75 2d                	jne    a09d <fwp_main_thread+0xadd>
    a070:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a073:	0f b7 c0             	movzwl %ax,%eax
    a076:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a079:	48 0f af c1          	imul   %rcx,%rax
    a07d:	48 c1 e8 20          	shr    $0x20,%rax
    a081:	48 39 d0             	cmp    %rdx,%rax
    a084:	73 17                	jae    a09d <fwp_main_thread+0xadd>
    a086:	48 01 c7             	add    %rax,%rdi
    a089:	0f b6 07             	movzbl (%rdi),%eax
    a08c:	84 c0                	test   %al,%al
    a08e:	74 0d                	je     a09d <fwp_main_thread+0xadd>
    a090:	3c fd                	cmp    $0xfd,%al
    a092:	0f 87 8d 15 00 00    	ja     b625 <fwp_main_thread+0x2065>
    a098:	83 c0 01             	add    $0x1,%eax
    a09b:	88 07                	mov    %al,(%rdi)
    a09d:	48 8d 3d 6c 5f 00 00 	lea    0x5f6c(%rip),%rdi        # 10010 <fc37>
    a0a4:	e8 17 cb ff ff       	call   6bc0 <fwp_closure_drop>
    a0a9:	48 85 db             	test   %rbx,%rbx
    a0ac:	0f 84 e6 13 00 00    	je     b498 <fwp_main_thread+0x1ed8>
    a0b2:	48 89 d8             	mov    %rbx,%rax
    a0b5:	31 d2                	xor    %edx,%edx
    a0b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0be:	00 00 
    a0c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a0c4:	48 83 c2 01          	add    $0x1,%rdx
    a0c8:	48 85 c0             	test   %rax,%rax
    a0cb:	75 f3                	jne    a0c0 <fwp_main_thread+0xb00>
    a0cd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    a0d4:	0f 87 1e 17 00 00    	ja     b7f8 <fwp_main_thread+0x2238>
    a0da:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    a0df:	8b 35 7b 5f 00 00    	mov    0x5f7b(%rip),%esi        # 10060 <registered_finish.1>
    a0e5:	85 f6                	test   %esi,%esi
    a0e7:	0f 84 73 11 00 00    	je     b260 <fwp_main_thread+0x1ca0>
    a0ed:	4c 8b 3d d4 5f 01 00 	mov    0x15fd4(%rip),%r15        # 200c8 <fwp_tape_next_slot>
    a0f4:	48 8b 2d dd 5f 01 00 	mov    0x15fdd(%rip),%rbp        # 200d8 <fwp_ntapes>
    a0fb:	49 39 ef             	cmp    %rbp,%r15
    a0fe:	0f 8d 24 0e 00 00    	jge    af28 <fwp_main_thread+0x1968>
    a104:	49 6b c7 58          	imul   $0x58,%r15,%rax
    a108:	48 03 05 d1 5f 01 00 	add    0x15fd1(%rip),%rax        # 200e0 <fwp_tapes>
    a10f:	90                   	nop
    a110:	8b 48 04             	mov    0x4(%rax),%ecx
    a113:	85 c9                	test   %ecx,%ecx
    a115:	75 0c                	jne    a123 <fwp_main_thread+0xb63>
    a117:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a11d:	0f 86 05 0e 00 00    	jbe    af28 <fwp_main_thread+0x1968>
    a123:	49 83 c7 01          	add    $0x1,%r15
    a127:	48 83 c0 58          	add    $0x58,%rax
    a12b:	49 39 ef             	cmp    %rbp,%r15
    a12e:	75 e0                	jne    a110 <fwp_main_thread+0xb50>
    a130:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    a137:	0f 8f f0 16 00 00    	jg     b82d <fwp_main_thread+0x226d>
    a13d:	48 39 2d 8c 5f 01 00 	cmp    %rbp,0x15f8c(%rip)        # 200d0 <fwp_tapes_cap>
    a144:	48 8b 15 95 5f 01 00 	mov    0x15f95(%rip),%rdx        # 200e0 <fwp_tapes>
    a14b:	75 4c                	jne    a199 <fwp_main_thread+0xbd9>
    a14d:	48 85 ed             	test   %rbp,%rbp
    a150:	0f 84 a5 13 00 00    	je     b4fb <fwp_main_thread+0x1f3b>
    a156:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    a15b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a160:	49 39 c7             	cmp    %rax,%r15
    a163:	4c 0f 4f f8          	cmovg  %rax,%r15
    a167:	49 6b f7 58          	imul   $0x58,%r15,%rsi
    a16b:	48 89 d7             	mov    %rdx,%rdi
    a16e:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    a174:	e8 27 94 ff ff       	call   35a0 <realloc@plt>
    a179:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    a17f:	48 85 c0             	test   %rax,%rax
    a182:	48 89 c2             	mov    %rax,%rdx
    a185:	0f 84 33 16 00 00    	je     b7be <fwp_main_thread+0x21fe>
    a18b:	48 89 05 4e 5f 01 00 	mov    %rax,0x15f4e(%rip)        # 200e0 <fwp_tapes>
    a192:	4c 89 3d 37 5f 01 00 	mov    %r15,0x15f37(%rip)        # 200d0 <fwp_tapes_cap>
    a199:	48 6b cd 58          	imul   $0x58,%rbp,%rcx
    a19d:	31 c0                	xor    %eax,%eax
    a19f:	49 89 ef             	mov    %rbp,%r15
    a1a2:	48 01 d1             	add    %rdx,%rcx
    a1a5:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    a1a9:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    a1b0:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a1b4:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    a1bb:	00 
    a1bc:	48 29 f9             	sub    %rdi,%rcx
    a1bf:	83 c1 58             	add    $0x58,%ecx
    a1c2:	c1 e9 03             	shr    $0x3,%ecx
    a1c5:	f3 48 ab             	rep stos %rax,(%rdi)
    a1c8:	48 8d 45 01          	lea    0x1(%rbp),%rax
    a1cc:	48 89 05 05 5f 01 00 	mov    %rax,0x15f05(%rip)        # 200d8 <fwp_ntapes>
    a1d3:	49 6b ef 58          	imul   $0x58,%r15,%rbp
    a1d7:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a1db:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a1e0:	48 8d 3d d8 1e 00 00 	lea    0x1ed8(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    a1e7:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    a1ec:	48 01 d5             	add    %rdx,%rbp
    a1ef:	48 c7 45 50 00 00 00 	movq   $0x0,0x50(%rbp)
    a1f6:	00 
    a1f7:	e8 84 91 ff ff       	call   3380 <getenv@plt>
    a1fc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a201:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    a207:	48 85 c0             	test   %rax,%rax
    a20a:	0f 84 30 0d 00 00    	je     af40 <fwp_main_thread+0x1980>
    a210:	80 38 30             	cmpb   $0x30,(%rax)
    a213:	0f 85 27 0d 00 00    	jne    af40 <fwp_main_thread+0x1980>
    a219:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a21d:	0f 85 1d 0d 00 00    	jne    af40 <fwp_main_thread+0x1980>
    a223:	8b 45 00             	mov    0x0(%rbp),%eax
    a226:	49 8d 77 01          	lea    0x1(%r15),%rsi
    a22a:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    a22e:	c7 45 04 01 00 00 00 	movl   $0x1,0x4(%rbp)
    a235:	8d 48 01             	lea    0x1(%rax),%ecx
    a238:	48 8b 05 61 28 00 00 	mov    0x2861(%rip),%rax        # caa0 <msg.4+0x20>
    a23f:	48 89 35 82 5e 01 00 	mov    %rsi,0x15e82(%rip)        # 200c8 <fwp_tape_next_slot>
    a246:	89 4d 00             	mov    %ecx,0x0(%rbp)
    a249:	48 89 45 48          	mov    %rax,0x48(%rbp)
    a24d:	48 8b 05 84 81 01 00 	mov    0x18184(%rip),%rax        # 223d8 <fwp_cleanups>
    a254:	48 c7 45 40 00 00 00 	movq   $0x0,0x40(%rbp)
    a25b:	00 
    a25c:	48 85 c0             	test   %rax,%rax
    a25f:	75 1b                	jne    a27c <fwp_main_thread+0xcbc>
    a261:	e9 da 15 00 00       	jmp    b840 <fwp_main_thread+0x2280>
    a266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a26d:	00 00 00 
    a270:	48 8b 00             	mov    (%rax),%rax
    a273:	48 85 c0             	test   %rax,%rax
    a276:	0f 84 c4 15 00 00    	je     b840 <fwp_main_thread+0x2280>
    a27c:	4c 39 70 08          	cmp    %r14,0x8(%rax)
    a280:	75 ee                	jne    a270 <fwp_main_thread+0xcb0>
    a282:	4c 8b 48 10          	mov    0x10(%rax),%r9
    a286:	44 89 ff             	mov    %r15d,%edi
    a289:	49 63 01             	movslq (%r9),%rax
    a28c:	4c 89 4d 40          	mov    %r9,0x40(%rbp)
    a290:	89 45 4c             	mov    %eax,0x4c(%rbp)
    a293:	85 c0                	test   %eax,%eax
    a295:	78 09                	js     a2a0 <fwp_main_thread+0xce0>
    a297:	48 6b c0 58          	imul   $0x58,%rax,%rax
    a29b:	44 89 7c 02 48       	mov    %r15d,0x48(%rdx,%rax,1)
    a2a0:	41 89 39             	mov    %edi,(%r9)
    a2a3:	48 89 d8             	mov    %rbx,%rax
    a2a6:	45 31 f6             	xor    %r14d,%r14d
    a2a9:	48 85 db             	test   %rbx,%rbx
    a2ac:	0f 84 de 0d 00 00    	je     b090 <fwp_main_thread+0x1ad0>
    a2b2:	0f 1f 00             	nopl   (%rax)
    a2b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a2bc:	00 00 00 00 
    a2c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a2c4:	49 83 c6 01          	add    $0x1,%r14
    a2c8:	48 85 c0             	test   %rax,%rax
    a2cb:	75 f3                	jne    a2c0 <fwp_main_thread+0xd00>
    a2cd:	48 89 da             	mov    %rbx,%rdx
    a2d0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a2d4:	48 83 c0 01          	add    $0x1,%rax
    a2d8:	48 85 d2             	test   %rdx,%rdx
    a2db:	75 f3                	jne    a2d0 <fwp_main_thread+0xd10>
    a2dd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    a2e4:	ff ff 1f 
    a2e7:	48 39 c2             	cmp    %rax,%rdx
    a2ea:	0f 82 fc 14 00 00    	jb     b7ec <fwp_main_thread+0x222c>
    a2f0:	4d 85 f6             	test   %r14,%r14
    a2f3:	0f 8e 97 0d 00 00    	jle    b090 <fwp_main_thread+0x1ad0>
    a2f9:	49 39 c6             	cmp    %rax,%r14
    a2fc:	4c 0f 47 f0          	cmova  %rax,%r14
    a300:	4c 89 f0             	mov    %r14,%rax
    a303:	48 c1 e8 3c          	shr    $0x3c,%rax
    a307:	0f 85 df 14 00 00    	jne    b7ec <fwp_main_thread+0x222c>
    a30d:	4f 8d 3c 36          	lea    (%r14,%r14,1),%r15
    a311:	48 c1 e1 10          	shl    $0x10,%rcx
    a315:	48 09 f1             	or     %rsi,%rcx
    a318:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    a31f:	00 
    a320:	be 02 00 00 00       	mov    $0x2,%esi
    a325:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a32a:	e8 e1 b6 ff ff       	call   5a10 <fwp_heap_alloc>
    a32f:	4c 89 38             	mov    %r15,(%rax)
    a332:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a339:	48 89 c5             	mov    %rax,%rbp
    a33c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a343:	48 c1 e2 10          	shl    $0x10,%rdx
    a347:	48 39 d0             	cmp    %rdx,%rax
    a34a:	0f 83 f0 0d 00 00    	jae    b140 <fwp_main_thread+0x1b80>
    a350:	48 89 c2             	mov    %rax,%rdx
    a353:	48 c1 ea 10          	shr    $0x10,%rdx
    a357:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a35b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a362:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a366:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a36a:	4d 85 ff             	test   %r15,%r15
    a36d:	74 3a                	je     a3a9 <fwp_main_thread+0xde9>
    a36f:	0f b6 32             	movzbl (%rdx),%esi
    a372:	40 80 fe 02          	cmp    $0x2,%sil
    a376:	0f 84 87 0d 00 00    	je     b103 <fwp_main_thread+0x1b43>
    a37c:	40 80 fe 01          	cmp    $0x1,%sil
    a380:	75 27                	jne    a3a9 <fwp_main_thread+0xde9>
    a382:	8b 72 18             	mov    0x18(%rdx),%esi
    a385:	0f b7 c0             	movzwl %ax,%eax
    a388:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a38b:	48 0f af c6          	imul   %rsi,%rax
    a38f:	48 c1 e8 20          	shr    $0x20,%rax
    a393:	48 39 d0             	cmp    %rdx,%rax
    a396:	73 11                	jae    a3a9 <fwp_main_thread+0xde9>
    a398:	49 01 c7             	add    %rax,%r15
    a39b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a39f:	0f 84 71 0d 00 00    	je     b116 <fwp_main_thread+0x1b56>
    a3a5:	41 c6 07 01          	movb   $0x1,(%r15)
    a3a9:	4d 85 f6             	test   %r14,%r14
    a3ac:	74 45                	je     a3f3 <fwp_main_thread+0xe33>
    a3ae:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a3b3:	48 89 da             	mov    %rbx,%rdx
    a3b6:	31 c0                	xor    %eax,%eax
    a3b8:	48 c1 e6 20          	shl    $0x20,%rsi
    a3bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a3c0:	48 89 c1             	mov    %rax,%rcx
    a3c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a3c8:	48 01 f1             	add    %rsi,%rcx
    a3cb:	0f 80 3f 93 ff ff    	jo     3710 <fwp_main_thread.cold+0x5>
    a3d1:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    a3d6:	48 89 c1             	mov    %rax,%rcx
    a3d9:	48 83 c0 01          	add    $0x1,%rax
    a3dd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a3e1:	48 c1 e1 04          	shl    $0x4,%rcx
    a3e5:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    a3ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a3ee:	4c 39 f0             	cmp    %r14,%rax
    a3f1:	72 cd                	jb     a3c0 <fwp_main_thread+0xe00>
    a3f3:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a3f7:	48 d1 e8             	shr    $1,%rax
    a3fa:	0f 84 50 0d 00 00    	je     b150 <fwp_main_thread+0x1b90>
    a400:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    a404:	48 89 f7             	mov    %rsi,%rdi
    a407:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a40b:	0f 85 db 13 00 00    	jne    b7ec <fwp_main_thread+0x222c>
    a411:	48 c7 84 24 d0 00 00 	movq   $0xffffffffffffffff,0xd0(%rsp)
    a418:	00 ff ff ff ff 
    a41d:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    a421:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
    a428:	00 00 00 00 00 
    a42d:	48 85 f6             	test   %rsi,%rsi
    a430:	74 69                	je     a49b <fwp_main_thread+0xedb>
    a432:	48 c1 e0 04          	shl    $0x4,%rax
    a436:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    a43b:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    a43f:	49 89 d7             	mov    %rdx,%r15
    a442:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
    a447:	4c 8d 74 05 f8       	lea    -0x8(%rbp,%rax,1),%r14
    a44c:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
    a451:	0f 1f 40 00          	nopl   0x0(%rax)
    a455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a45c:	00 00 00 00 
    a460:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a464:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a468:	48 89 ea             	mov    %rbp,%rdx
    a46b:	48 83 c3 10          	add    $0x10,%rbx
    a46f:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a473:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a477:	e8 b4 bb ff ff       	call   6030 <w120>
    a47c:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a481:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a485:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a489:	49 39 de             	cmp    %rbx,%r14
    a48c:	75 d2                	jne    a460 <fwp_main_thread+0xea0>
    a48e:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
    a493:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
    a498:	4c 89 fa             	mov    %r15,%rdx
    a49b:	48 89 55 00          	mov    %rdx,0x0(%rbp)
    a49f:	48 89 ef             	mov    %rbp,%rdi
    a4a2:	e8 d9 c2 ff ff       	call   6780 <w176.constprop.0>
    a4a7:	48 89 ef             	mov    %rbp,%rdi
    a4aa:	49 89 c6             	mov    %rax,%r14
    a4ad:	e8 5e d9 ff ff       	call   7e10 <fwp_drop10>
    a4b2:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    a4b7:	4c 89 ff             	mov    %r15,%rdi
    a4ba:	e8 81 9f ff ff       	call   4440 <fwp_tape_of>
    a4bf:	48 89 c6             	mov    %rax,%rsi
    a4c2:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    a4c7:	0f 85 7f 13 00 00    	jne    b84c <fwp_main_thread+0x228c>
    a4cd:	48 89 c7             	mov    %rax,%rdi
    a4d0:	e8 eb 96 ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    a4d5:	48 8b 56 38          	mov    0x38(%rsi),%rdx
    a4d9:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a4de:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a4e5:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    a4e9:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    a4ed:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    a4f2:	f3 0f 6f 56 20       	movdqu 0x20(%rsi),%xmm2
    a4f7:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    a4fb:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a4ff:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a505:	77 1a                	ja     a521 <fwp_main_thread+0xf61>
    a507:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    a50c:	83 e8 01             	sub    $0x1,%eax
    a50f:	48 98                	cltq
    a511:	48 3b 05 b0 5b 01 00 	cmp    0x15bb0(%rip),%rax        # 200c8 <fwp_tape_next_slot>
    a518:	7d 07                	jge    a521 <fwp_main_thread+0xf61>
    a51a:	48 89 05 a7 5b 01 00 	mov    %rax,0x15ba7(%rip)        # 200c8 <fwp_tape_next_slot>
    a521:	48 8b 05 b0 7e 01 00 	mov    0x17eb0(%rip),%rax        # 223d8 <fwp_cleanups>
    a528:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a52c:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    a533:	00 
    a534:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    a53b:	00 
    a53c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a543:	00 
    a544:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a548:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a54c:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a553:	00 
    a554:	48 8d 05 95 a8 ff ff 	lea    -0x576b(%rip),%rax        # 4df0 <fwp_tape_buffers_release>
    a55b:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a562:	00 
    a563:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    a568:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
    a56f:	00 
    a570:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a577:	00 
    a578:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a57d:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    a584:	00 
    a585:	48 89 05 4c 7e 01 00 	mov    %rax,0x17e4c(%rip)        # 223d8 <fwp_cleanups>
    a58c:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    a593:	00 
    a594:	4d 85 f6             	test   %r14,%r14
    a597:	0f 88 03 0d 00 00    	js     b2a0 <fwp_main_thread+0x1ce0>
    a59d:	4c 89 f0             	mov    %r14,%rax
    a5a0:	48 c1 f8 20          	sar    $0x20,%rax
    a5a4:	49 39 c7             	cmp    %rax,%r15
    a5a7:	0f 85 7a 11 00 00    	jne    b727 <fwp_main_thread+0x2167>
    a5ad:	45 89 f7             	mov    %r14d,%r15d
    a5b0:	4c 89 fd             	mov    %r15,%rbp
    a5b3:	4c 39 ff             	cmp    %r15,%rdi
    a5b6:	0f 8e 77 11 00 00    	jle    b733 <fwp_main_thread+0x2173>
    a5bc:	4d 39 f9             	cmp    %r15,%r9
    a5bf:	0f 8e 9b 0b 00 00    	jle    b160 <fwp_main_thread+0x1ba0>
    a5c5:	49 39 d1             	cmp    %rdx,%r9
    a5c8:	0f 8f da 0b 00 00    	jg     b1a8 <fwp_main_thread+0x1be8>
    a5ce:	48 85 c9             	test   %rcx,%rcx
    a5d1:	0f 84 ce 11 00 00    	je     b7a5 <fwp_main_thread+0x21e5>
    a5d7:	48 89 cf             	mov    %rcx,%rdi
    a5da:	31 f6                	xor    %esi,%esi
    a5dc:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a5e1:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    a5e5:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    a5ec:	00 
    a5ed:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    a5f2:	e8 a9 8e ff ff       	call   34a0 <memset@plt>
    a5f7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a5fc:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    a602:	48 89 c1             	mov    %rax,%rcx
    a605:	f2 0f 10 05 23 25 00 	movsd  0x2523(%rip),%xmm0        # cb30 <msg.4+0xb0>
    a60c:	00 
    a60d:	f2 42 0f 58 04 f9    	addsd  (%rcx,%r15,8),%xmm0
    a613:	f2 42 0f 11 04 f9    	movsd  %xmm0,(%rcx,%r15,8)
    a619:	4c 39 cd             	cmp    %r9,%rbp
    a61c:	7c 6c                	jl     a68a <fwp_main_thread+0x10ca>
    a61e:	48 8d 14 e9          	lea    (%rcx,%rbp,8),%rdx
    a622:	4c 29 cd             	sub    %r9,%rbp
    a625:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    a62a:	48 8d 44 6d 00       	lea    0x0(%rbp,%rbp,2),%rax
    a62f:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a633:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    a637:	eb 0b                	jmp    a644 <fwp_main_thread+0x1084>
    a639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a640:	48 83 e8 18          	sub    $0x18,%rax
    a644:	f2 0f 10 02          	movsd  (%rdx),%xmm0
    a648:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a64c:	7a 02                	jp     a650 <fwp_main_thread+0x1090>
    a64e:	74 31                	je     a681 <fwp_main_thread+0x10c1>
    a650:	48 63 38             	movslq (%rax),%rdi
    a653:	85 ff                	test   %edi,%edi
    a655:	78 13                	js     a66a <fwp_main_thread+0x10aa>
    a657:	f2 0f 10 48 08       	movsd  0x8(%rax),%xmm1
    a65c:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a660:	f2 0f 58 0c f9       	addsd  (%rcx,%rdi,8),%xmm1
    a665:	f2 0f 11 0c f9       	movsd  %xmm1,(%rcx,%rdi,8)
    a66a:	48 63 78 04          	movslq 0x4(%rax),%rdi
    a66e:	85 ff                	test   %edi,%edi
    a670:	78 0f                	js     a681 <fwp_main_thread+0x10c1>
    a672:	f2 0f 59 40 10       	mulsd  0x10(%rax),%xmm0
    a677:	f2 0f 58 04 f9       	addsd  (%rcx,%rdi,8),%xmm0
    a67c:	f2 0f 11 04 f9       	movsd  %xmm0,(%rcx,%rdi,8)
    a681:	48 83 ea 08          	sub    $0x8,%rdx
    a685:	48 39 f0             	cmp    %rsi,%rax
    a688:	75 b6                	jne    a640 <fwp_main_thread+0x1080>
    a68a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a691:	ff ff 1f 
    a694:	4c 39 c8             	cmp    %r9,%rax
    a697:	0f 82 67 11 00 00    	jb     b804 <fwp_main_thread+0x2244>
    a69d:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    a6a4:	00 
    a6a5:	be 02 00 00 00       	mov    $0x2,%esi
    a6aa:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    a6af:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a6b4:	e8 57 b3 ff ff       	call   5a10 <fwp_heap_alloc>
    a6b9:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a6be:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    a6c3:	48 89 c5             	mov    %rax,%rbp
    a6c6:	4d 85 c9             	test   %r9,%r9
    a6c9:	4c 89 08             	mov    %r9,(%rax)
    a6cc:	74 24                	je     a6f2 <fwp_main_thread+0x1132>
    a6ce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a6dc:	00 00 00 00 
    a6e0:	4a 8b 04 e1          	mov    (%rcx,%r12,8),%rax
    a6e4:	4a 89 44 e5 08       	mov    %rax,0x8(%rbp,%r12,8)
    a6e9:	49 83 c4 01          	add    $0x1,%r12
    a6ed:	4d 39 e1             	cmp    %r12,%r9
    a6f0:	75 ee                	jne    a6e0 <fwp_main_thread+0x1120>
    a6f2:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
    a6f9:	00 
    a6fa:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a6ff:	4c 89 3d d2 7c 01 00 	mov    %r15,0x17cd2(%rip)        # 223d8 <fwp_cleanups>
    a706:	e8 e5 a6 ff ff       	call   4df0 <fwp_tape_buffers_release>
    a70b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a712:	48 89 e8             	mov    %rbp,%rax
    a715:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a71c:	48 c1 e2 10          	shl    $0x10,%rdx
    a720:	48 39 d0             	cmp    %rdx,%rax
    a723:	73 57                	jae    a77c <fwp_main_thread+0x11bc>
    a725:	48 89 c2             	mov    %rax,%rdx
    a728:	48 c1 ea 10          	shr    $0x10,%rdx
    a72c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a730:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a737:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a73b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a73f:	4d 85 f6             	test   %r14,%r14
    a742:	74 38                	je     a77c <fwp_main_thread+0x11bc>
    a744:	0f b6 0a             	movzbl (%rdx),%ecx
    a747:	80 f9 02             	cmp    $0x2,%cl
    a74a:	0f 84 80 0b 00 00    	je     b2d0 <fwp_main_thread+0x1d10>
    a750:	80 f9 01             	cmp    $0x1,%cl
    a753:	75 27                	jne    a77c <fwp_main_thread+0x11bc>
    a755:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a758:	0f b7 c0             	movzwl %ax,%eax
    a75b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a75e:	48 0f af c1          	imul   %rcx,%rax
    a762:	48 c1 e8 20          	shr    $0x20,%rax
    a766:	48 39 d0             	cmp    %rdx,%rax
    a769:	73 11                	jae    a77c <fwp_main_thread+0x11bc>
    a76b:	49 01 c6             	add    %rax,%r14
    a76e:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a772:	0f 84 6b 0b 00 00    	je     b2e3 <fwp_main_thread+0x1d23>
    a778:	41 c6 06 01          	movb   $0x1,(%r14)
    a77c:	4c 3b 7c 24 40       	cmp    0x40(%rsp),%r15
    a781:	0f 85 84 8f ff ff    	jne    370b <fwp_main_thread.cold>
    a787:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a78e:	00 
    a78f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a794:	48 89 05 3d 7c 01 00 	mov    %rax,0x17c3d(%rip)        # 223d8 <fwp_cleanups>
    a79b:	e8 60 c7 ff ff       	call   6f00 <fwp_tape_scope_release>
    a7a0:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a7a4:	49 89 c4             	mov    %rax,%r12
    a7a7:	49 0f ba f4 3f       	btr    $0x3f,%r12
    a7ac:	48 85 c0             	test   %rax,%rax
    a7af:	0f 88 0b 08 00 00    	js     afc0 <fwp_main_thread+0x1a00>
    a7b5:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a7bc:	48 89 e8             	mov    %rbp,%rax
    a7bf:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a7c6:	48 c1 e2 10          	shl    $0x10,%rdx
    a7ca:	48 39 d0             	cmp    %rdx,%rax
    a7cd:	0f 83 ed 07 00 00    	jae    afc0 <fwp_main_thread+0x1a00>
    a7d3:	48 89 c2             	mov    %rax,%rdx
    a7d6:	48 c1 ea 10          	shr    $0x10,%rdx
    a7da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7de:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a7e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a7e9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a7ed:	48 85 c9             	test   %rcx,%rcx
    a7f0:	0f 84 ca 07 00 00    	je     afc0 <fwp_main_thread+0x1a00>
    a7f6:	0f b6 32             	movzbl (%rdx),%esi
    a7f9:	40 80 fe 02          	cmp    $0x2,%sil
    a7fd:	0f 84 ad 07 00 00    	je     afb0 <fwp_main_thread+0x19f0>
    a803:	40 80 fe 01          	cmp    $0x1,%sil
    a807:	0f 85 b3 07 00 00    	jne    afc0 <fwp_main_thread+0x1a00>
    a80d:	8b 72 18             	mov    0x18(%rdx),%esi
    a810:	0f b7 c0             	movzwl %ax,%eax
    a813:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a816:	48 0f af c6          	imul   %rsi,%rax
    a81a:	48 c1 e8 20          	shr    $0x20,%rax
    a81e:	48 39 d0             	cmp    %rdx,%rax
    a821:	0f 83 99 07 00 00    	jae    afc0 <fwp_main_thread+0x1a00>
    a827:	48 01 c1             	add    %rax,%rcx
    a82a:	80 39 01             	cmpb   $0x1,(%rcx)
    a82d:	0f 85 8d 07 00 00    	jne    afc0 <fwp_main_thread+0x1a00>
    a833:	49 89 ef             	mov    %rbp,%r15
    a836:	49 89 ee             	mov    %rbp,%r14
    a839:	31 ff                	xor    %edi,%edi
    a83b:	49 8d 56 08          	lea    0x8(%r14),%rdx
    a83f:	31 c0                	xor    %eax,%eax
    a841:	4d 85 e4             	test   %r12,%r12
    a844:	75 33                	jne    a879 <fwp_main_thread+0x12b9>
    a846:	eb 50                	jmp    a898 <fwp_main_thread+0x12d8>
    a848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a84f:	00 
    a850:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a854:	0f 88 2d 0f 00 00    	js     b787 <fwp_main_thread+0x21c7>
    a85a:	f2 0f 10 05 4e 22 00 	movsd  0x224e(%rip),%xmm0        # cab0 <msg.4+0x30>
    a861:	00 
    a862:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a867:	48 83 c0 01          	add    $0x1,%rax
    a86b:	48 83 c2 08          	add    $0x8,%rdx
    a86f:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a874:	49 39 c4             	cmp    %rax,%r12
    a877:	74 1f                	je     a898 <fwp_main_thread+0x12d8>
    a879:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
    a87d:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a882:	79 cc                	jns    a850 <fwp_main_thread+0x1290>
    a884:	48 8b 4d 10          	mov    0x10(%rbp),%rcx
    a888:	eb c6                	jmp    a850 <fwp_main_thread+0x1290>
    a88a:	e8 61 a2 ff ff       	call   4af0 <fwp_heap_init>
    a88f:	e9 64 ed ff ff       	jmp    95f8 <fwp_main_thread+0x38>
    a894:	0f 1f 40 00          	nopl   0x0(%rax)
    a898:	e8 73 d5 ff ff       	call   7e10 <fwp_drop10>
    a89d:	48 89 d8             	mov    %rbx,%rax
    a8a0:	31 d2                	xor    %edx,%edx
    a8a2:	48 85 db             	test   %rbx,%rbx
    a8a5:	0f 84 f6 0b 00 00    	je     b4a1 <fwp_main_thread+0x1ee1>
    a8ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a8b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a8b4:	48 83 c2 01          	add    $0x1,%rdx
    a8b8:	48 85 c0             	test   %rax,%rax
    a8bb:	75 f3                	jne    a8b0 <fwp_main_thread+0x12f0>
    a8bd:	49 8b 07             	mov    (%r15),%rax
    a8c0:	49 89 c4             	mov    %rax,%r12
    a8c3:	49 0f ba f4 3f       	btr    $0x3f,%r12
    a8c8:	48 85 c0             	test   %rax,%rax
    a8cb:	0f 88 79 05 00 00    	js     ae4a <fwp_main_thread+0x188a>
    a8d1:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    a8d8:	4c 89 f6             	mov    %r14,%rsi
    a8db:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    a8e2:	48 c1 e0 10          	shl    $0x10,%rax
    a8e6:	48 39 c6             	cmp    %rax,%rsi
    a8e9:	0f 83 5b 05 00 00    	jae    ae4a <fwp_main_thread+0x188a>
    a8ef:	48 89 f0             	mov    %rsi,%rax
    a8f2:	48 c1 e8 10          	shr    $0x10,%rax
    a8f6:	48 8d 3c 80          	lea    (%rax,%rax,4),%rdi
    a8fa:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    a901:	48 8d 3c f8          	lea    (%rax,%rdi,8),%rdi
    a905:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    a909:	4d 85 c0             	test   %r8,%r8
    a90c:	0f 84 38 05 00 00    	je     ae4a <fwp_main_thread+0x188a>
    a912:	0f b6 07             	movzbl (%rdi),%eax
    a915:	3c 02                	cmp    $0x2,%al
    a917:	0f 84 1b 05 00 00    	je     ae38 <fwp_main_thread+0x1878>
    a91d:	3c 01                	cmp    $0x1,%al
    a91f:	0f 85 1c 05 00 00    	jne    ae41 <fwp_main_thread+0x1881>
    a925:	8b 47 18             	mov    0x18(%rdi),%eax
    a928:	0f b7 f6             	movzwl %si,%esi
    a92b:	48 0f af f0          	imul   %rax,%rsi
    a92f:	8b 47 1c             	mov    0x1c(%rdi),%eax
    a932:	48 c1 ee 20          	shr    $0x20,%rsi
    a936:	48 39 c6             	cmp    %rax,%rsi
    a939:	0f 83 02 05 00 00    	jae    ae41 <fwp_main_thread+0x1881>
    a93f:	49 01 f0             	add    %rsi,%r8
    a942:	41 80 38 01          	cmpb   $0x1,(%r8)
    a946:	0f 85 f5 04 00 00    	jne    ae41 <fwp_main_thread+0x1881>
    a94c:	4c 39 e2             	cmp    %r12,%rdx
    a94f:	4c 89 e0             	mov    %r12,%rax
    a952:	48 0f 46 c2          	cmovbe %rdx,%rax
    a956:	48 85 c0             	test   %rax,%rax
    a959:	0f 84 34 0e 00 00    	je     b793 <fwp_main_thread+0x21d3>
    a95f:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    a966:	00 
    a967:	49 8d 6f 08          	lea    0x8(%r15),%rbp
    a96b:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    a972:	00 
    a973:	48 89 d9             	mov    %rbx,%rcx
    a976:	49 8d 7e 08          	lea    0x8(%r14),%rdi
    a97a:	31 d2                	xor    %edx,%edx
    a97c:	eb 1f                	jmp    a99d <fwp_main_thread+0x13dd>
    a97e:	66 90                	xchg   %ax,%ax
    a980:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a985:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a98a:	f2 0f 11 44 15 00    	movsd  %xmm0,0x0(%rbp,%rdx,1)
    a990:	48 83 c2 08          	add    $0x8,%rdx
    a994:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a998:	49 39 d0             	cmp    %rdx,%r8
    a99b:	74 13                	je     a9b0 <fwp_main_thread+0x13f0>
    a99d:	48 89 fe             	mov    %rdi,%rsi
    a9a0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a9a4:	79 da                	jns    a980 <fwp_main_thread+0x13c0>
    a9a6:	49 8b 76 10          	mov    0x10(%r14),%rsi
    a9aa:	eb d4                	jmp    a980 <fwp_main_thread+0x13c0>
    a9ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a9b0:	48 85 db             	test   %rbx,%rbx
    a9b3:	0f 84 66 0d 00 00    	je     b71f <fwp_main_thread+0x215f>
    a9b9:	4d 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%r8
    a9c0:	4d 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%r9
    a9c7:	48 89 d9             	mov    %rbx,%rcx
    a9ca:	45 31 ff             	xor    %r15d,%r15d
    a9cd:	4d 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%r10
    a9d4:	49 c1 e0 10          	shl    $0x10,%r8
    a9d8:	eb 1c                	jmp    a9f6 <fwp_main_thread+0x1436>
    a9da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9e0:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a9e4:	49 83 c7 01          	add    $0x1,%r15
    a9e8:	48 85 c9             	test   %rcx,%rcx
    a9eb:	74 5f                	je     aa4c <fwp_main_thread+0x148c>
    a9ed:	49 39 c7             	cmp    %rax,%r15
    a9f0:	0f 83 5a 01 00 00    	jae    ab50 <fwp_main_thread+0x1590>
    a9f6:	48 89 ca             	mov    %rcx,%rdx
    a9f9:	4c 29 ca             	sub    %r9,%rdx
    a9fc:	4c 39 c2             	cmp    %r8,%rdx
    a9ff:	73 4b                	jae    aa4c <fwp_main_thread+0x148c>
    aa01:	48 89 d6             	mov    %rdx,%rsi
    aa04:	48 c1 ee 10          	shr    $0x10,%rsi
    aa08:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    aa0c:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    aa10:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    aa14:	48 85 ff             	test   %rdi,%rdi
    aa17:	74 33                	je     aa4c <fwp_main_thread+0x148c>
    aa19:	44 0f b6 1e          	movzbl (%rsi),%r11d
    aa1d:	41 80 fb 02          	cmp    $0x2,%r11b
    aa21:	0f 84 11 01 00 00    	je     ab38 <fwp_main_thread+0x1578>
    aa27:	41 80 fb 01          	cmp    $0x1,%r11b
    aa2b:	75 1f                	jne    aa4c <fwp_main_thread+0x148c>
    aa2d:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    aa31:	0f b7 d2             	movzwl %dx,%edx
    aa34:	8b 76 1c             	mov    0x1c(%rsi),%esi
    aa37:	49 0f af d3          	imul   %r11,%rdx
    aa3b:	48 c1 ea 20          	shr    $0x20,%rdx
    aa3f:	48 39 f2             	cmp    %rsi,%rdx
    aa42:	73 08                	jae    aa4c <fwp_main_thread+0x148c>
    aa44:	48 01 d7             	add    %rdx,%rdi
    aa47:	80 3f 01             	cmpb   $0x1,(%rdi)
    aa4a:	74 94                	je     a9e0 <fwp_main_thread+0x1420>
    aa4c:	49 39 c7             	cmp    %rax,%r15
    aa4f:	0f 83 fb 00 00 00    	jae    ab50 <fwp_main_thread+0x1590>
    aa55:	49 89 c4             	mov    %rax,%r12
    aa58:	31 c9                	xor    %ecx,%ecx
    aa5a:	eb 38                	jmp    aa94 <fwp_main_thread+0x14d4>
    aa5c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa60:	40 80 ff 01          	cmp    $0x1,%dil
    aa64:	75 25                	jne    aa8b <fwp_main_thread+0x14cb>
    aa66:	8b 7e 18             	mov    0x18(%rsi),%edi
    aa69:	0f b7 c0             	movzwl %ax,%eax
    aa6c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    aa6f:	48 0f af c7          	imul   %rdi,%rax
    aa73:	48 c1 e8 20          	shr    $0x20,%rax
    aa77:	48 39 f0             	cmp    %rsi,%rax
    aa7a:	73 0f                	jae    aa8b <fwp_main_thread+0x14cb>
    aa7c:	48 01 c2             	add    %rax,%rdx
    aa7f:	80 3a ff             	cmpb   $0xff,(%rdx)
    aa82:	0f 84 e0 05 00 00    	je     b068 <fwp_main_thread+0x1aa8>
    aa88:	c6 02 01             	movb   $0x1,(%rdx)
    aa8b:	4d 39 e7             	cmp    %r12,%r15
    aa8e:	0f 83 8c 00 00 00    	jae    ab20 <fwp_main_thread+0x1560>
    aa94:	49 83 ec 01          	sub    $0x1,%r12
    aa98:	66 48 0f 6e e9       	movq   %rcx,%xmm5
    aa9d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    aaa2:	bf 01 00 00 00       	mov    $0x1,%edi
    aaa7:	f3 42 0f 7e 44 e5 00 	movq   0x0(%rbp,%r12,8),%xmm0
    aaae:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    aab2:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    aab9:	00 
    aaba:	e8 71 b0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    aabf:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    aac6:	48 89 c1             	mov    %rax,%rcx
    aac9:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    aad0:	48 c1 e2 10          	shl    $0x10,%rdx
    aad4:	48 39 d0             	cmp    %rdx,%rax
    aad7:	73 b2                	jae    aa8b <fwp_main_thread+0x14cb>
    aad9:	48 89 c2             	mov    %rax,%rdx
    aadc:	48 c1 ea 10          	shr    $0x10,%rdx
    aae0:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    aae4:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    aaeb:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    aaef:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    aaf3:	48 85 d2             	test   %rdx,%rdx
    aaf6:	74 93                	je     aa8b <fwp_main_thread+0x14cb>
    aaf8:	0f b6 3e             	movzbl (%rsi),%edi
    aafb:	40 80 ff 02          	cmp    $0x2,%dil
    aaff:	0f 85 5b ff ff ff    	jne    aa60 <fwp_main_thread+0x14a0>
    ab05:	66 85 c0             	test   %ax,%ax
    ab08:	0f 84 71 ff ff ff    	je     aa7f <fwp_main_thread+0x14bf>
    ab0e:	4d 39 e7             	cmp    %r12,%r15
    ab11:	72 81                	jb     aa94 <fwp_main_thread+0x14d4>
    ab13:	66 90                	xchg   %ax,%ax
    ab15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab1c:	00 00 00 00 
    ab20:	4d 85 ff             	test   %r15,%r15
    ab23:	75 2d                	jne    ab52 <fwp_main_thread+0x1592>
    ab25:	8b 44 24 10          	mov    0x10(%rsp),%eax
    ab29:	85 c0                	test   %eax,%eax
    ab2b:	49 0f 45 ef          	cmovne %r15,%rbp
    ab2f:	eb 5e                	jmp    ab8f <fwp_main_thread+0x15cf>
    ab31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab38:	66 85 d2             	test   %dx,%dx
    ab3b:	0f 84 06 ff ff ff    	je     aa47 <fwp_main_thread+0x1487>
    ab41:	49 39 c7             	cmp    %rax,%r15
    ab44:	0f 82 0b ff ff ff    	jb     aa55 <fwp_main_thread+0x1495>
    ab4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab50:	31 c9                	xor    %ecx,%ecx
    ab52:	48 89 ea             	mov    %rbp,%rdx
    ab55:	4e 8d 44 fd 00       	lea    0x0(%rbp,%r15,8),%r8
    ab5a:	48 89 d8             	mov    %rbx,%rax
    ab5d:	0f 1f 00             	nopl   (%rax)
    ab60:	48 8b 32             	mov    (%rdx),%rsi
    ab63:	48 83 c2 08          	add    $0x8,%rdx
    ab67:	48 89 c7             	mov    %rax,%rdi
    ab6a:	48 89 70 08          	mov    %rsi,0x8(%rax)
    ab6e:	48 8b 40 10          	mov    0x10(%rax),%rax
    ab72:	4c 39 c2             	cmp    %r8,%rdx
    ab75:	75 e9                	jne    ab60 <fwp_main_thread+0x15a0>
    ab77:	8b 54 24 10          	mov    0x10(%rsp),%edx
    ab7b:	48 89 4f 10          	mov    %rcx,0x10(%rdi)
    ab7f:	85 d2                	test   %edx,%edx
    ab81:	0f 84 69 07 00 00    	je     b2f0 <fwp_main_thread+0x1d30>
    ab87:	48 89 d9             	mov    %rbx,%rcx
    ab8a:	31 ed                	xor    %ebp,%ebp
    ab8c:	48 89 c3             	mov    %rax,%rbx
    ab8f:	48 89 ef             	mov    %rbp,%rdi
    ab92:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    ab97:	e8 74 a9 ff ff       	call   5510 <fwp_mem_free>
    ab9c:	4c 89 f7             	mov    %r14,%rdi
    ab9f:	e8 6c d2 ff ff       	call   7e10 <fwp_drop10>
    aba4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    abab:	48 89 d8             	mov    %rbx,%rax
    abae:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    abb5:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    abba:	48 c1 e2 10          	shl    $0x10,%rdx
    abbe:	48 39 d0             	cmp    %rdx,%rax
    abc1:	73 7f                	jae    ac42 <fwp_main_thread+0x1682>
    abc3:	49 89 cc             	mov    %rcx,%r12
    abc6:	48 89 c2             	mov    %rax,%rdx
    abc9:	49 8b bd f8 13 00 00 	mov    0x13f8(%r13),%rdi
    abd0:	48 c1 ea 10          	shr    $0x10,%rdx
    abd4:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    abd8:	48 8d 14 d7          	lea    (%rdi,%rdx,8),%rdx
    abdc:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    abe0:	48 85 ed             	test   %rbp,%rbp
    abe3:	0f 84 10 03 00 00    	je     aef9 <fwp_main_thread+0x1939>
    abe9:	0f b6 32             	movzbl (%rdx),%esi
    abec:	40 80 fe 02          	cmp    $0x2,%sil
    abf0:	0f 84 fa 02 00 00    	je     aef0 <fwp_main_thread+0x1930>
    abf6:	40 80 fe 01          	cmp    $0x1,%sil
    abfa:	0f 85 f9 02 00 00    	jne    aef9 <fwp_main_thread+0x1939>
    ac00:	8b 72 18             	mov    0x18(%rdx),%esi
    ac03:	0f b7 c0             	movzwl %ax,%eax
    ac06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac09:	48 0f af c6          	imul   %rsi,%rax
    ac0d:	48 c1 e8 20          	shr    $0x20,%rax
    ac11:	48 39 d0             	cmp    %rdx,%rax
    ac14:	0f 83 df 02 00 00    	jae    aef9 <fwp_main_thread+0x1939>
    ac1a:	48 01 c5             	add    %rax,%rbp
    ac1d:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    ac21:	84 c0                	test   %al,%al
    ac23:	0f 84 d0 02 00 00    	je     aef9 <fwp_main_thread+0x1939>
    ac29:	3c 01                	cmp    $0x1,%al
    ac2b:	0f 84 cf 06 00 00    	je     b300 <fwp_main_thread+0x1d40>
    ac31:	4c 89 e1             	mov    %r12,%rcx
    ac34:	3c ff                	cmp    $0xff,%al
    ac36:	0f 84 63 09 00 00    	je     b59f <fwp_main_thread+0x1fdf>
    ac3c:	83 e8 01             	sub    $0x1,%eax
    ac3f:	88 45 00             	mov    %al,0x0(%rbp)
    ac42:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
    ac48:	0f 85 ba 02 00 00    	jne    af08 <fwp_main_thread+0x1948>
    ac4e:	66 90                	xchg   %ax,%ax
    ac50:	48 89 cd             	mov    %rcx,%rbp
    ac53:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    ac58:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac5c:	b9 01 00 00 00       	mov    $0x1,%ecx
    ac61:	48 8d 15 58 4f 00 00 	lea    0x4f58(%rip),%rdx        # fbc0 <d0>
    ac68:	48 89 ee             	mov    %rbp,%rsi
    ac6b:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    ac72:	00 00 00 00 00 
    ac77:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
    ac7c:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    ac83:	00 
    ac84:	e8 f7 d8 ff ff       	call   8580 <fwp_write>
    ac89:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
    ac90:	00 
    ac91:	4c 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%r14
    ac98:	00 
    ac99:	48 8d 05 8e 13 00 00 	lea    0x138e(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    aca0:	48 85 c9             	test   %rcx,%rcx
    aca3:	48 0f 44 c8          	cmove  %rax,%rcx
    aca7:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    acab:	0f 87 6b 0b 00 00    	ja     b81c <fwp_main_thread+0x225c>
    acb1:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    acb5:	be 01 00 00 00       	mov    $0x1,%esi
    acba:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    acbf:	e8 4c ad ff ff       	call   5a10 <fwp_heap_alloc>
    acc4:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    acc9:	4c 89 f2             	mov    %r14,%rdx
    accc:	4c 89 30             	mov    %r14,(%rax)
    accf:	48 89 c3             	mov    %rax,%rbx
    acd2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    acd6:	49 89 ff             	mov    %rdi,%r15
    acd9:	e8 92 88 ff ff       	call   3570 <memcpy@plt>
    acde:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ace4:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    aceb:	00 
    acec:	e8 af 86 ff ff       	call   33a0 <free@plt>
    acf1:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    acf8:	48 89 d8             	mov    %rbx,%rax
    acfb:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    ad02:	48 c1 e2 10          	shl    $0x10,%rdx
    ad06:	48 39 d0             	cmp    %rdx,%rax
    ad09:	73 57                	jae    ad62 <fwp_main_thread+0x17a2>
    ad0b:	48 89 c2             	mov    %rax,%rdx
    ad0e:	48 c1 ea 10          	shr    $0x10,%rdx
    ad12:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad16:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    ad1d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad21:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ad25:	4d 85 f6             	test   %r14,%r14
    ad28:	74 38                	je     ad62 <fwp_main_thread+0x17a2>
    ad2a:	0f b6 0a             	movzbl (%rdx),%ecx
    ad2d:	80 f9 02             	cmp    $0x2,%cl
    ad30:	0f 84 42 07 00 00    	je     b478 <fwp_main_thread+0x1eb8>
    ad36:	80 f9 01             	cmp    $0x1,%cl
    ad39:	75 27                	jne    ad62 <fwp_main_thread+0x17a2>
    ad3b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad3e:	0f b7 c0             	movzwl %ax,%eax
    ad41:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad44:	48 0f af c1          	imul   %rcx,%rax
    ad48:	48 c1 e8 20          	shr    $0x20,%rax
    ad4c:	48 39 d0             	cmp    %rdx,%rax
    ad4f:	73 11                	jae    ad62 <fwp_main_thread+0x17a2>
    ad51:	49 01 c6             	add    %rax,%r14
    ad54:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ad58:	0f 84 2d 07 00 00    	je     b48b <fwp_main_thread+0x1ecb>
    ad5e:	41 c6 06 01          	movb   $0x1,(%r14)
    ad62:	48 89 ef             	mov    %rbp,%rdi
    ad65:	e8 b6 cc ff ff       	call   7a20 <fwp_drop0>
    ad6a:	48 8b 13             	mov    (%rbx),%rdx
    ad6d:	be 01 00 00 00       	mov    $0x1,%esi
    ad72:	4c 89 ff             	mov    %r15,%rdi
    ad75:	48 8b 0d 24 76 01 00 	mov    0x17624(%rip),%rcx        # 223a0 <fwp_prog_out>
    ad7c:	e8 bf 88 ff ff       	call   3640 <fwrite@plt>
    ad81:	48 8b 35 18 76 01 00 	mov    0x17618(%rip),%rsi        # 223a0 <fwp_prog_out>
    ad88:	bf 0a 00 00 00       	mov    $0xa,%edi
    ad8d:	e8 2e 87 ff ff       	call   34c0 <fputc@plt>
    ad92:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    ad99:	48 89 d8             	mov    %rbx,%rax
    ad9c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    ada3:	48 c1 e2 10          	shl    $0x10,%rdx
    ada7:	48 39 d0             	cmp    %rdx,%rax
    adaa:	73 67                	jae    ae13 <fwp_main_thread+0x1853>
    adac:	48 89 c2             	mov    %rax,%rdx
    adaf:	48 c1 ea 10          	shr    $0x10,%rdx
    adb3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adb7:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    adbe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adc2:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    adc6:	48 85 ed             	test   %rbp,%rbp
    adc9:	74 48                	je     ae13 <fwp_main_thread+0x1853>
    adcb:	0f b6 0a             	movzbl (%rdx),%ecx
    adce:	80 f9 02             	cmp    $0x2,%cl
    add1:	0f 84 39 06 00 00    	je     b410 <fwp_main_thread+0x1e50>
    add7:	80 f9 01             	cmp    $0x1,%cl
    adda:	75 37                	jne    ae13 <fwp_main_thread+0x1853>
    addc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    addf:	0f b7 c0             	movzwl %ax,%eax
    ade2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ade5:	48 0f af c1          	imul   %rcx,%rax
    ade9:	48 c1 e8 20          	shr    $0x20,%rax
    aded:	48 39 d0             	cmp    %rdx,%rax
    adf0:	73 21                	jae    ae13 <fwp_main_thread+0x1853>
    adf2:	48 01 c5             	add    %rax,%rbp
    adf5:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    adf9:	84 c0                	test   %al,%al
    adfb:	74 16                	je     ae13 <fwp_main_thread+0x1853>
    adfd:	3c 01                	cmp    $0x1,%al
    adff:	0f 84 28 06 00 00    	je     b42d <fwp_main_thread+0x1e6d>
    ae05:	3c ff                	cmp    $0xff,%al
    ae07:	0f 84 9d 08 00 00    	je     b6aa <fwp_main_thread+0x20ea>
    ae0d:	83 e8 01             	sub    $0x1,%eax
    ae10:	88 45 00             	mov    %al,0x0(%rbp)
    ae13:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    ae18:	4d 85 e4             	test   %r12,%r12
    ae1b:	0f 84 22 06 00 00    	je     b443 <fwp_main_thread+0x1e83>
    ae21:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    ae28:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    ae2f:	e9 0c f1 ff ff       	jmp    9f40 <fwp_main_thread+0x980>
    ae34:	0f 1f 40 00          	nopl   0x0(%rax)
    ae38:	66 85 f6             	test   %si,%si
    ae3b:	0f 84 01 fb ff ff    	je     a942 <fwp_main_thread+0x1382>
    ae41:	48 85 db             	test   %rbx,%rbx
    ae44:	0f 84 d9 02 00 00    	je     b123 <fwp_main_thread+0x1b63>
    ae4a:	48 89 d8             	mov    %rbx,%rax
    ae4d:	31 d2                	xor    %edx,%edx
    ae4f:	90                   	nop
    ae50:	48 8b 40 10          	mov    0x10(%rax),%rax
    ae54:	48 89 d6             	mov    %rdx,%rsi
    ae57:	48 83 c2 01          	add    $0x1,%rdx
    ae5b:	48 85 c0             	test   %rax,%rax
    ae5e:	75 f0                	jne    ae50 <fwp_main_thread+0x1890>
    ae60:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ae67:	ff ff 1f 
    ae6a:	48 39 d0             	cmp    %rdx,%rax
    ae6d:	0f 82 79 09 00 00    	jb     b7ec <fwp_main_thread+0x222c>
    ae73:	48 8d 3c f5 10 00 00 	lea    0x10(,%rsi,8),%rdi
    ae7a:	00 
    ae7b:	be 02 00 00 00       	mov    $0x2,%esi
    ae80:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    ae85:	e8 86 ab ff ff       	call   5a10 <fwp_heap_alloc>
    ae8a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    ae8f:	48 89 c5             	mov    %rax,%rbp
    ae92:	49 39 d4             	cmp    %rdx,%r12
    ae95:	48 89 d0             	mov    %rdx,%rax
    ae98:	48 89 e9             	mov    %rbp,%rcx
    ae9b:	48 89 da             	mov    %rbx,%rdx
    ae9e:	49 0f 46 c4          	cmovbe %r12,%rax
    aea2:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aea9:	00 
    aeaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aeb1:	00 00 00 00 
    aeb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aebc:	00 00 00 00 
    aec0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    aec4:	48 83 c1 08          	add    $0x8,%rcx
    aec8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    aecc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    aed0:	48 85 d2             	test   %rdx,%rdx
    aed3:	75 eb                	jne    aec0 <fwp_main_thread+0x1900>
    aed5:	48 85 c0             	test   %rax,%rax
    aed8:	0f 84 57 02 00 00    	je     b135 <fwp_main_thread+0x1b75>
    aede:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    aee5:	00 
    aee6:	e9 80 fa ff ff       	jmp    a96b <fwp_main_thread+0x13ab>
    aeeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aef0:	66 85 c0             	test   %ax,%ax
    aef3:	0f 84 24 fd ff ff    	je     ac1d <fwp_main_thread+0x165d>
    aef9:	4c 89 e1             	mov    %r12,%rcx
    aefc:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
    af02:	0f 84 48 fd ff ff    	je     ac50 <fwp_main_thread+0x1690>
    af08:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    af0d:	45 31 c0             	xor    %r8d,%r8d
    af10:	48 89 cb             	mov    %rcx,%rbx
    af13:	48 83 e8 01          	sub    $0x1,%rax
    af17:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    af1c:	41 0f 90 c0          	seto   %r8b
    af20:	e9 9f f0 ff ff       	jmp    9fc4 <fwp_main_thread+0xa04>
    af25:	0f 1f 00             	nopl   (%rax)
    af28:	4c 39 fd             	cmp    %r15,%rbp
    af2b:	0f 84 ff f1 ff ff    	je     a130 <fwp_main_thread+0xb70>
    af31:	48 8b 15 a8 51 01 00 	mov    0x151a8(%rip),%rdx        # 200e0 <fwp_tapes>
    af38:	e9 96 f2 ff ff       	jmp    a1d3 <fwp_main_thread+0xc13>
    af3d:	0f 1f 00             	nopl   (%rax)
    af40:	48 83 3d 40 51 01 00 	cmpq   $0x0,0x15140(%rip)        # 20088 <fwp_tape_cached_bytes>
    af47:	00 
    af48:	0f 84 d5 f2 ff ff    	je     a223 <fwp_main_thread+0xc63>
    af4e:	48 8b 05 5b 51 01 00 	mov    0x1515b(%rip),%rax        # 200b0 <fwp_tape_workspace+0x10>
    af55:	66 0f 6f 0d 43 51 01 	movdqa 0x15143(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    af5c:	00 
    af5d:	48 c7 05 20 51 01 00 	movq   $0x0,0x15120(%rip)        # 20088 <fwp_tape_cached_bytes>
    af64:	00 00 00 00 
    af68:	48 89 45 30          	mov    %rax,0x30(%rbp)
    af6c:	48 8b 05 45 51 01 00 	mov    0x15145(%rip),%rax        # 200b8 <fwp_tape_workspace+0x18>
    af73:	0f 11 4d 20          	movups %xmm1,0x20(%rbp)
    af77:	66 0f ef c9          	pxor   %xmm1,%xmm1
    af7b:	48 89 45 18          	mov    %rax,0x18(%rbp)
    af7f:	48 8b 05 3a 51 01 00 	mov    0x1513a(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    af86:	0f 29 0d 13 51 01 00 	movaps %xmm1,0x15113(%rip)        # 200a0 <fwp_tape_workspace>
    af8d:	48 89 45 38          	mov    %rax,0x38(%rbp)
    af91:	0f 29 0d 18 51 01 00 	movaps %xmm1,0x15118(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    af98:	48 c7 05 1d 51 01 00 	movq   $0x0,0x1511d(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    af9f:	00 00 00 00 
    afa3:	e9 7b f2 ff ff       	jmp    a223 <fwp_main_thread+0xc63>
    afa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    afaf:	00 
    afb0:	66 85 c0             	test   %ax,%ax
    afb3:	0f 84 71 f8 ff ff    	je     a82a <fwp_main_thread+0x126a>
    afb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afc0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    afc7:	ff ff 1f 
    afca:	4c 39 e0             	cmp    %r12,%rax
    afcd:	0f 82 31 08 00 00    	jb     b804 <fwp_main_thread+0x2244>
    afd3:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    afda:	00 
    afdb:	be 01 00 00 00       	mov    $0x1,%esi
    afe0:	e8 2b aa ff ff       	call   5a10 <fwp_heap_alloc>
    afe5:	4c 89 20             	mov    %r12,(%rax)
    afe8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    afef:	49 89 c7             	mov    %rax,%r15
    aff2:	49 89 c6             	mov    %rax,%r14
    aff5:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    affc:	48 c1 e2 10          	shl    $0x10,%rdx
    b000:	48 39 d0             	cmp    %rdx,%rax
    b003:	73 57                	jae    b05c <fwp_main_thread+0x1a9c>
    b005:	48 89 c2             	mov    %rax,%rdx
    b008:	48 c1 ea 10          	shr    $0x10,%rdx
    b00c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b010:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    b017:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b01b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b01f:	48 85 d2             	test   %rdx,%rdx
    b022:	74 38                	je     b05c <fwp_main_thread+0x1a9c>
    b024:	0f b6 31             	movzbl (%rcx),%esi
    b027:	40 80 fe 02          	cmp    $0x2,%sil
    b02b:	0f 84 6f 03 00 00    	je     b3a0 <fwp_main_thread+0x1de0>
    b031:	40 80 fe 01          	cmp    $0x1,%sil
    b035:	75 25                	jne    b05c <fwp_main_thread+0x1a9c>
    b037:	8b 71 18             	mov    0x18(%rcx),%esi
    b03a:	0f b7 c0             	movzwl %ax,%eax
    b03d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b040:	48 0f af c6          	imul   %rsi,%rax
    b044:	48 c1 e8 20          	shr    $0x20,%rax
    b048:	48 39 c8             	cmp    %rcx,%rax
    b04b:	73 0f                	jae    b05c <fwp_main_thread+0x1a9c>
    b04d:	48 01 c2             	add    %rax,%rdx
    b050:	80 3a ff             	cmpb   $0xff,(%rdx)
    b053:	0f 84 59 03 00 00    	je     b3b2 <fwp_main_thread+0x1df2>
    b059:	c6 02 01             	movb   $0x1,(%rdx)
    b05c:	48 89 ef             	mov    %rbp,%rdi
    b05f:	e9 d7 f7 ff ff       	jmp    a83b <fwp_main_thread+0x127b>
    b064:	0f 1f 40 00          	nopl   0x0(%rax)
    b068:	48 89 d7             	mov    %rdx,%rdi
    b06b:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    b070:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b075:	e8 56 a2 ff ff       	call   52d0 <fwp_rc_forget_slot>
    b07a:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    b07f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b084:	e9 ff f9 ff ff       	jmp    aa88 <fwp_main_thread+0x14c8>
    b089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b090:	48 c1 e1 10          	shl    $0x10,%rcx
    b094:	bf 08 00 00 00       	mov    $0x8,%edi
    b099:	48 09 f1             	or     %rsi,%rcx
    b09c:	be 02 00 00 00       	mov    $0x2,%esi
    b0a1:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    b0a6:	e8 65 a9 ff ff       	call   5a10 <fwp_heap_alloc>
    b0ab:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b0b2:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    b0b9:	48 89 c5             	mov    %rax,%rbp
    b0bc:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    b0c3:	48 c1 e2 10          	shl    $0x10,%rdx
    b0c7:	48 39 d0             	cmp    %rdx,%rax
    b0ca:	0f 83 80 00 00 00    	jae    b150 <fwp_main_thread+0x1b90>
    b0d0:	48 89 c2             	mov    %rax,%rdx
    b0d3:	48 c1 ea 10          	shr    $0x10,%rdx
    b0d7:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b0db:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    b0e2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    b0e6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    b0ea:	4d 85 ff             	test   %r15,%r15
    b0ed:	0f 84 00 f3 ff ff    	je     a3f3 <fwp_main_thread+0xe33>
    b0f3:	0f b6 32             	movzbl (%rdx),%esi
    b0f6:	45 31 f6             	xor    %r14d,%r14d
    b0f9:	40 80 fe 02          	cmp    $0x2,%sil
    b0fd:	0f 85 79 f2 ff ff    	jne    a37c <fwp_main_thread+0xdbc>
    b103:	66 85 c0             	test   %ax,%ax
    b106:	0f 85 9d f2 ff ff    	jne    a3a9 <fwp_main_thread+0xde9>
    b10c:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b110:	0f 85 8f f2 ff ff    	jne    a3a5 <fwp_main_thread+0xde5>
    b116:	4c 89 ff             	mov    %r15,%rdi
    b119:	e8 b2 a1 ff ff       	call   52d0 <fwp_rc_forget_slot>
    b11e:	e9 82 f2 ff ff       	jmp    a3a5 <fwp_main_thread+0xde5>
    b123:	be 02 00 00 00       	mov    $0x2,%esi
    b128:	bf 08 00 00 00       	mov    $0x8,%edi
    b12d:	e8 de a8 ff ff       	call   5a10 <fwp_heap_alloc>
    b132:	48 89 c5             	mov    %rax,%rbp
    b135:	31 c9                	xor    %ecx,%ecx
    b137:	e9 53 fa ff ff       	jmp    ab8f <fwp_main_thread+0x15cf>
    b13c:	0f 1f 40 00          	nopl   0x0(%rax)
    b140:	4d 85 f6             	test   %r14,%r14
    b143:	0f 85 65 f2 ff ff    	jne    a3ae <fwp_main_thread+0xdee>
    b149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b150:	31 d2                	xor    %edx,%edx
    b152:	e9 44 f3 ff ff       	jmp    a49b <fwp_main_thread+0xedb>
    b157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b15e:	00 00 
    b160:	4d 8d 57 01          	lea    0x1(%r15),%r10
    b164:	4c 39 d2             	cmp    %r10,%rdx
    b167:	7c 42                	jl     b1ab <fwp_main_thread+0x1beb>
    b169:	48 85 c9             	test   %rcx,%rcx
    b16c:	0f 84 33 06 00 00    	je     b7a5 <fwp_main_thread+0x21e5>
    b172:	48 89 cf             	mov    %rcx,%rdi
    b175:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    b17c:	00 
    b17d:	31 f6                	xor    %esi,%esi
    b17f:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b184:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    b189:	e8 12 83 ff ff       	call   34a0 <memset@plt>
    b18e:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b193:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    b199:	48 89 c1             	mov    %rax,%rcx
    b19c:	e9 64 f4 ff ff       	jmp    a605 <fwp_main_thread+0x1045>
    b1a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1a8:	4d 89 ca             	mov    %r9,%r10
    b1ab:	48 85 d2             	test   %rdx,%rdx
    b1ae:	49 0f 44 d2          	cmove  %r10,%rdx
    b1b2:	eb 21                	jmp    b1d5 <fwp_main_thread+0x1c15>
    b1b4:	90                   	nop
    b1b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b1bc:	00 00 00 00 
    b1c0:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    b1c4:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    b1cb:	4c 89 d0             	mov    %r10,%rax
    b1ce:	48 0f 4c c6          	cmovl  %rsi,%rax
    b1d2:	48 89 c2             	mov    %rax,%rdx
    b1d5:	4c 39 d2             	cmp    %r10,%rdx
    b1d8:	7c e6                	jl     b1c0 <fwp_main_thread+0x1c00>
    b1da:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    b1df:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b1e4:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    b1e9:	48 85 c9             	test   %rcx,%rcx
    b1ec:	0f 84 de 01 00 00    	je     b3d0 <fwp_main_thread+0x1e10>
    b1f2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    b1f9:	00 
    b1fa:	48 89 cf             	mov    %rcx,%rdi
    b1fd:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b202:	e8 99 83 ff ff       	call   35a0 <realloc@plt>
    b207:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b20c:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b211:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    b216:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    b21c:	48 89 c1             	mov    %rax,%rcx
    b21f:	48 85 c9             	test   %rcx,%rcx
    b222:	0f 84 74 05 00 00    	je     b79c <fwp_main_thread+0x21dc>
    b228:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
    b22f:	00 
    b230:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
    b237:	00 
    b238:	4d 85 d2             	test   %r10,%r10
    b23b:	0f 85 ed 02 00 00    	jne    b52e <fwp_main_thread+0x1f6e>
    b241:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    b248:	4d 85 f6             	test   %r14,%r14
    b24b:	0f 88 c8 f3 ff ff    	js     a619 <fwp_main_thread+0x1059>
    b251:	45 89 f7             	mov    %r14d,%r15d
    b254:	e9 ac f3 ff ff       	jmp    a605 <fwp_main_thread+0x1045>
    b259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b260:	48 8d 3d b9 bb ff ff 	lea    -0x4447(%rip),%rdi        # 6e20 <fwp_tape_finish>
    b267:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    b26d:	e8 0e 08 00 00       	call   ba80 <atexit>
    b272:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    b278:	85 c0                	test   %eax,%eax
    b27a:	0f 85 3e 05 00 00    	jne    b7be <fwp_main_thread+0x21fe>
    b280:	c7 05 d6 4d 00 00 01 	movl   $0x1,0x4dd6(%rip)        # 10060 <registered_finish.1>
    b287:	00 00 00 
    b28a:	e9 5e ee ff ff       	jmp    a0ed <fwp_main_thread+0xb2d>
    b28f:	90                   	nop
    b290:	66 85 c0             	test   %ax,%ax
    b293:	0f 85 04 ee ff ff    	jne    a09d <fwp_main_thread+0xadd>
    b299:	e9 eb ed ff ff       	jmp    a089 <fwp_main_thread+0xac9>
    b29e:	66 90                	xchg   %ax,%ax
    b2a0:	49 39 d1             	cmp    %rdx,%r9
    b2a3:	0f 8f ff fe ff ff    	jg     b1a8 <fwp_main_thread+0x1be8>
    b2a9:	48 85 c9             	test   %rcx,%rcx
    b2ac:	0f 85 70 02 00 00    	jne    b522 <fwp_main_thread+0x1f62>
    b2b2:	4d 85 c9             	test   %r9,%r9
    b2b5:	0f 85 ea 04 00 00    	jne    b7a5 <fwp_main_thread+0x21e5>
    b2bb:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    b2c2:	e9 52 f3 ff ff       	jmp    a619 <fwp_main_thread+0x1059>
    b2c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b2ce:	00 00 
    b2d0:	66 85 c0             	test   %ax,%ax
    b2d3:	0f 85 a3 f4 ff ff    	jne    a77c <fwp_main_thread+0x11bc>
    b2d9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b2dd:	0f 85 95 f4 ff ff    	jne    a778 <fwp_main_thread+0x11b8>
    b2e3:	4c 89 f7             	mov    %r14,%rdi
    b2e6:	e8 e5 9f ff ff       	call   52d0 <fwp_rc_forget_slot>
    b2eb:	e9 88 f4 ff ff       	jmp    a778 <fwp_main_thread+0x11b8>
    b2f0:	48 89 d9             	mov    %rbx,%rcx
    b2f3:	48 89 c3             	mov    %rax,%rbx
    b2f6:	e9 94 f8 ff ff       	jmp    ab8f <fwp_main_thread+0x15cf>
    b2fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b300:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    b307:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    b30e:	48 89 d8             	mov    %rbx,%rax
    b311:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    b315:	48 29 f0             	sub    %rsi,%rax
    b318:	48 c1 e2 10          	shl    $0x10,%rdx
    b31c:	48 39 d0             	cmp    %rdx,%rax
    b31f:	73 66                	jae    b387 <fwp_main_thread+0x1dc7>
    b321:	49 89 c0             	mov    %rax,%r8
    b324:	49 c1 e8 10          	shr    $0x10,%r8
    b328:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    b32c:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    b330:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    b334:	4d 85 c0             	test   %r8,%r8
    b337:	74 4e                	je     b387 <fwp_main_thread+0x1dc7>
    b339:	44 0f b6 0f          	movzbl (%rdi),%r9d
    b33d:	41 80 f9 02          	cmp    $0x2,%r9b
    b341:	0f 84 cd 01 00 00    	je     b514 <fwp_main_thread+0x1f54>
    b347:	41 80 f9 01          	cmp    $0x1,%r9b
    b34b:	75 3a                	jne    b387 <fwp_main_thread+0x1dc7>
    b34d:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    b351:	0f b7 c0             	movzwl %ax,%eax
    b354:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    b357:	49 0f af c1          	imul   %r9,%rax
    b35b:	48 c1 e8 20          	shr    $0x20,%rax
    b35f:	48 39 f8             	cmp    %rdi,%rax
    b362:	73 23                	jae    b387 <fwp_main_thread+0x1dc7>
    b364:	49 01 c0             	add    %rax,%r8
    b367:	41 80 38 01          	cmpb   $0x1,(%r8)
    b36b:	75 1a                	jne    b387 <fwp_main_thread+0x1dc7>
    b36d:	48 89 df             	mov    %rbx,%rdi
    b370:	e8 9b a1 ff ff       	call   5510 <fwp_mem_free>
    b375:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    b37c:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    b383:	48 c1 e2 10          	shl    $0x10,%rdx
    b387:	48 89 e8             	mov    %rbp,%rax
    b38a:	48 29 f0             	sub    %rsi,%rax
    b38d:	48 39 d0             	cmp    %rdx,%rax
    b390:	0f 83 63 fb ff ff    	jae    aef9 <fwp_main_thread+0x1939>
    b396:	48 89 eb             	mov    %rbp,%rbx
    b399:	e9 28 f8 ff ff       	jmp    abc6 <fwp_main_thread+0x1606>
    b39e:	66 90                	xchg   %ax,%ax
    b3a0:	66 85 c0             	test   %ax,%ax
    b3a3:	0f 85 b3 fc ff ff    	jne    b05c <fwp_main_thread+0x1a9c>
    b3a9:	80 3a ff             	cmpb   $0xff,(%rdx)
    b3ac:	0f 85 a7 fc ff ff    	jne    b059 <fwp_main_thread+0x1a99>
    b3b2:	48 89 d7             	mov    %rdx,%rdi
    b3b5:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b3ba:	e8 11 9f ff ff       	call   52d0 <fwp_rc_forget_slot>
    b3bf:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b3c4:	e9 90 fc ff ff       	jmp    b059 <fwp_main_thread+0x1a99>
    b3c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b3d0:	48 89 d7             	mov    %rdx,%rdi
    b3d3:	be 08 00 00 00       	mov    $0x8,%esi
    b3d8:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b3dd:	e8 1e 81 ff ff       	call   3500 <calloc@plt>
    b3e2:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    b3e8:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    b3ed:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b3f2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b3f7:	48 89 c1             	mov    %rax,%rcx
    b3fa:	e9 20 fe ff ff       	jmp    b21f <fwp_main_thread+0x1c5f>
    b3ff:	90                   	nop
    b400:	66 85 c0             	test   %ax,%ax
    b403:	0f 85 a5 eb ff ff    	jne    9fae <fwp_main_thread+0x9ee>
    b409:	e9 8c eb ff ff       	jmp    9f9a <fwp_main_thread+0x9da>
    b40e:	66 90                	xchg   %ax,%ax
    b410:	66 85 c0             	test   %ax,%ax
    b413:	0f 85 fa f9 ff ff    	jne    ae13 <fwp_main_thread+0x1853>
    b419:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    b41d:	84 c0                	test   %al,%al
    b41f:	0f 84 ee f9 ff ff    	je     ae13 <fwp_main_thread+0x1853>
    b425:	3c 01                	cmp    $0x1,%al
    b427:	0f 85 d8 f9 ff ff    	jne    ae05 <fwp_main_thread+0x1845>
    b42d:	48 89 df             	mov    %rbx,%rdi
    b430:	e8 db a0 ff ff       	call   5510 <fwp_mem_free>
    b435:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    b43a:	4d 85 e4             	test   %r12,%r12
    b43d:	0f 85 de f9 ff ff    	jne    ae21 <fwp_main_thread+0x1861>
    b443:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
    b448:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
    b44d:	e8 ce c5 ff ff       	call   7a20 <fwp_drop0>
    b452:	48 89 df             	mov    %rbx,%rdi
    b455:	e8 c6 c5 ff ff       	call   7a20 <fwp_drop0>
    b45a:	48 c7 05 03 4c 00 00 	movq   $0x0,0x4c03(%rip)        # 10068 <v.2>
    b461:	00 00 00 00 
    b465:	c7 05 01 4c 00 00 01 	movl   $0x1,0x4c01(%rip)        # 10070 <st.3>
    b46c:	00 00 00 
    b46f:	e9 85 e2 ff ff       	jmp    96f9 <fwp_main_thread+0x139>
    b474:	0f 1f 40 00          	nopl   0x0(%rax)
    b478:	66 85 c0             	test   %ax,%ax
    b47b:	0f 85 e1 f8 ff ff    	jne    ad62 <fwp_main_thread+0x17a2>
    b481:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b485:	0f 85 d3 f8 ff ff    	jne    ad5e <fwp_main_thread+0x179e>
    b48b:	4c 89 f7             	mov    %r14,%rdi
    b48e:	e8 3d 9e ff ff       	call   52d0 <fwp_rc_forget_slot>
    b493:	e9 c6 f8 ff ff       	jmp    ad5e <fwp_main_thread+0x179e>
    b498:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b49c:	e9 3e ec ff ff       	jmp    a0df <fwp_main_thread+0xb1f>
    b4a1:	49 8b 07             	mov    (%r15),%rax
    b4a4:	48 85 c0             	test   %rax,%rax
    b4a7:	0f 88 76 fc ff ff    	js     b123 <fwp_main_thread+0x1b63>
    b4ad:	49 8b bd d8 13 00 00 	mov    0x13d8(%r13),%rdi
    b4b4:	4c 89 f6             	mov    %r14,%rsi
    b4b7:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    b4be:	48 c1 e7 10          	shl    $0x10,%rdi
    b4c2:	48 39 fe             	cmp    %rdi,%rsi
    b4c5:	0f 83 58 fc ff ff    	jae    b123 <fwp_main_thread+0x1b63>
    b4cb:	48 89 f1             	mov    %rsi,%rcx
    b4ce:	48 c1 e9 10          	shr    $0x10,%rcx
    b4d2:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    b4d6:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    b4dd:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    b4e1:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    b4e5:	4d 85 c0             	test   %r8,%r8
    b4e8:	0f 84 35 fc ff ff    	je     b123 <fwp_main_thread+0x1b63>
    b4ee:	48 0f ba f0 3f       	btr    $0x3f,%rax
    b4f3:	49 89 c4             	mov    %rax,%r12
    b4f6:	e9 17 f4 ff ff       	jmp    a912 <fwp_main_thread+0x1352>
    b4fb:	be 58 00 00 00       	mov    $0x58,%esi
    b500:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    b506:	e9 60 ec ff ff       	jmp    a16b <fwp_main_thread+0xbab>
    b50b:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b50f:	e9 99 e2 ff ff       	jmp    97ad <fwp_main_thread+0x1ed>
    b514:	66 85 c0             	test   %ax,%ax
    b517:	0f 85 6a fe ff ff    	jne    b387 <fwp_main_thread+0x1dc7>
    b51d:	e9 45 fe ff ff       	jmp    b367 <fwp_main_thread+0x1da7>
    b522:	4d 85 c9             	test   %r9,%r9
    b525:	0f 84 90 fd ff ff    	je     b2bb <fwp_main_thread+0x1cfb>
    b52b:	4d 89 ca             	mov    %r9,%r10
    b52e:	48 89 cf             	mov    %rcx,%rdi
    b531:	31 f6                	xor    %esi,%esi
    b533:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b538:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
    b53c:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    b543:	00 
    b544:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    b549:	e8 52 7f ff ff       	call   34a0 <memset@plt>
    b54e:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b553:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    b559:	48 89 c1             	mov    %rax,%rcx
    b55c:	e9 e7 fc ff ff       	jmp    b248 <fwp_main_thread+0x1c88>
    b561:	31 db                	xor    %ebx,%ebx
    b563:	e9 07 e3 ff ff       	jmp    986f <fwp_main_thread+0x2af>
    b568:	66 85 c0             	test   %ax,%ax
    b56b:	0f 85 01 e9 ff ff    	jne    9e72 <fwp_main_thread+0x8b2>
    b571:	e9 ee e8 ff ff       	jmp    9e64 <fwp_main_thread+0x8a4>
    b576:	66 85 c0             	test   %ax,%ax
    b579:	0f 85 56 e8 ff ff    	jne    9dd5 <fwp_main_thread+0x815>
    b57f:	e9 43 e8 ff ff       	jmp    9dc7 <fwp_main_thread+0x807>
    b584:	66 85 c0             	test   %ax,%ax
    b587:	0f 85 98 e9 ff ff    	jne    9f25 <fwp_main_thread+0x965>
    b58d:	e9 77 e9 ff ff       	jmp    9f09 <fwp_main_thread+0x949>
    b592:	4c 89 f7             	mov    %r14,%rdi
    b595:	e8 36 9d ff ff       	call   52d0 <fwp_rc_forget_slot>
    b59a:	e9 f9 e6 ff ff       	jmp    9c98 <fwp_main_thread+0x6d8>
    b59f:	48 89 ea             	mov    %rbp,%rdx
    b5a2:	48 c1 ea 11          	shr    $0x11,%rdx
    b5a6:	48 31 ea             	xor    %rbp,%rdx
    b5a9:	48 89 d0             	mov    %rdx,%rax
    b5ac:	48 c1 e8 09          	shr    $0x9,%rax
    b5b0:	48 31 c2             	xor    %rax,%rdx
    b5b3:	0f b6 d2             	movzbl %dl,%edx
    b5b6:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    b5bd:	00 
    b5be:	48 85 c0             	test   %rax,%rax
    b5c1:	75 26                	jne    b5e9 <fwp_main_thread+0x2029>
    b5c3:	eb 6a                	jmp    b62f <fwp_main_thread+0x206f>
    b5c5:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b5ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5d1:	00 00 00 00 
    b5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5dc:	00 00 00 00 
    b5e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b5e4:	48 85 c0             	test   %rax,%rax
    b5e7:	74 46                	je     b62f <fwp_main_thread+0x206f>
    b5e9:	48 89 c2             	mov    %rax,%rdx
    b5ec:	48 39 28             	cmp    %rbp,(%rax)
    b5ef:	75 ef                	jne    b5e0 <fwp_main_thread+0x2020>
    b5f1:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b5f5:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    b5f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b5fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b604:	0f 85 38 f6 ff ff    	jne    ac42 <fwp_main_thread+0x1682>
    b60a:	48 89 ef             	mov    %rbp,%rdi
    b60d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    b612:	e8 b9 9c ff ff       	call   52d0 <fwp_rc_forget_slot>
    b617:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    b61b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    b620:	e9 1d f6 ff ff       	jmp    ac42 <fwp_main_thread+0x1682>
    b625:	e8 86 9b ff ff       	call   51b0 <fwp_rc_wide_dup>
    b62a:	e9 6e ea ff ff       	jmp    a09d <fwp_main_thread+0xadd>
    b62f:	48 8d 3d 6a 11 00 00 	lea    0x116a(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    b636:	e8 25 8b ff ff       	call   4160 <fwp_trap>
    b63b:	48 8b 3d 7e 6d 01 00 	mov    0x16d7e(%rip),%rdi        # 223c0 <fwp_state>
    b642:	e8 c9 9e ff ff       	call   5510 <fwp_mem_free>
    b647:	48 c7 05 6e 6d 01 00 	movq   $0x0,0x16d6e(%rip)        # 223c0 <fwp_state>
    b64e:	00 00 00 00 
    b652:	48 c7 05 53 6d 01 00 	movq   $0x0,0x16d53(%rip)        # 223b0 <fwp_state_cap>
    b659:	00 00 00 00 
    b65d:	48 85 db             	test   %rbx,%rbx
    b660:	0f 84 d9 00 00 00    	je     b73f <fwp_main_thread+0x217f>
    b666:	48 3b 1d ab 50 01 00 	cmp    0x150ab(%rip),%rbx        # 20718 <fwp_root>
    b66d:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b674:	00 00 00 00 
    b678:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b67f:	00 00 00 00 
    b683:	c7 05 f3 49 01 00 00 	movl   $0x0,0x149f3(%rip)        # 20080 <fwp_exit_code>
    b68a:	00 00 00 
    b68d:	0f 84 06 e2 ff ff    	je     9899 <fwp_main_thread+0x2d9>
    b693:	e9 73 80 ff ff       	jmp    370b <fwp_main_thread.cold>
    b698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b69f:	00 
    b6a0:	e8 0b 9b ff ff       	call   51b0 <fwp_rc_wide_dup>
    b6a5:	e9 04 e9 ff ff       	jmp    9fae <fwp_main_thread+0x9ee>
    b6aa:	48 89 e8             	mov    %rbp,%rax
    b6ad:	48 c1 e8 11          	shr    $0x11,%rax
    b6b1:	48 31 e8             	xor    %rbp,%rax
    b6b4:	48 89 c2             	mov    %rax,%rdx
    b6b7:	48 c1 ea 09          	shr    $0x9,%rdx
    b6bb:	48 31 d0             	xor    %rdx,%rax
    b6be:	0f b6 d0             	movzbl %al,%edx
    b6c1:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    b6c8:	00 
    b6c9:	48 85 c0             	test   %rax,%rax
    b6cc:	75 1f                	jne    b6ed <fwp_main_thread+0x212d>
    b6ce:	e9 5c ff ff ff       	jmp    b62f <fwp_main_thread+0x206f>
    b6d3:	66 90                	xchg   %ax,%ax
    b6d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b6dc:	00 00 00 00 
    b6e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b6e4:	48 85 c0             	test   %rax,%rax
    b6e7:	0f 84 42 ff ff ff    	je     b62f <fwp_main_thread+0x206f>
    b6ed:	48 89 c2             	mov    %rax,%rdx
    b6f0:	48 3b 28             	cmp    (%rax),%rbp
    b6f3:	75 eb                	jne    b6e0 <fwp_main_thread+0x2120>
    b6f5:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b6f9:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    b6fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b701:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b708:	0f 85 05 f7 ff ff    	jne    ae13 <fwp_main_thread+0x1853>
    b70e:	48 89 ef             	mov    %rbp,%rdi
    b711:	e8 ba 9b ff ff       	call   52d0 <fwp_rc_forget_slot>
    b716:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    b71a:	e9 f4 f6 ff ff       	jmp    ae13 <fwp_main_thread+0x1853>
    b71f:	45 31 ff             	xor    %r15d,%r15d
    b722:	e9 2e f3 ff ff       	jmp    aa55 <fwp_main_thread+0x1495>
    b727:	48 8d 3d 9a 10 00 00 	lea    0x109a(%rip),%rdi        # c7c8 <_IO_stdin_used+0x7c8>
    b72e:	e8 2d 8a ff ff       	call   4160 <fwp_trap>
    b733:	48 8d 3d ca 09 00 00 	lea    0x9ca(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    b73a:	e8 21 8a ff ff       	call   4160 <fwp_trap>
    b73f:	48 83 3d d1 4f 01 00 	cmpq   $0x0,0x14fd1(%rip)        # 20718 <fwp_root>
    b746:	00 
    b747:	c7 05 2f 49 01 00 00 	movl   $0x0,0x1492f(%rip)        # 20080 <fwp_exit_code>
    b74e:	00 00 00 
    b751:	0f 84 9e e1 ff ff    	je     98f5 <fwp_main_thread+0x335>
    b757:	e9 af 7f ff ff       	jmp    370b <fwp_main_thread.cold>
    b75c:	0f 1f 40 00          	nopl   0x0(%rax)
    b760:	48 89 ef             	mov    %rbp,%rdi
    b763:	e8 68 9b ff ff       	call   52d0 <fwp_rc_forget_slot>
    b768:	e9 a6 e7 ff ff       	jmp    9f13 <fwp_main_thread+0x953>
    b76d:	48 89 ef             	mov    %rbp,%rdi
    b770:	e8 5b 9b ff ff       	call   52d0 <fwp_rc_forget_slot>
    b775:	e9 57 e6 ff ff       	jmp    9dd1 <fwp_main_thread+0x811>
    b77a:	48 89 ef             	mov    %rbp,%rdi
    b77d:	e8 4e 9b ff ff       	call   52d0 <fwp_rc_forget_slot>
    b782:	e9 e7 e6 ff ff       	jmp    9e6e <fwp_main_thread+0x8ae>
    b787:	48 8d 3d 3a 11 00 00 	lea    0x113a(%rip),%rdi        # c8c8 <_IO_stdin_used+0x8c8>
    b78e:	e8 cd 89 ff ff       	call   4160 <fwp_trap>
    b793:	31 ed                	xor    %ebp,%ebp
    b795:	31 c9                	xor    %ecx,%ecx
    b797:	e9 f3 f3 ff ff       	jmp    ab8f <fwp_main_thread+0x15cf>
    b79c:	4d 85 d2             	test   %r10,%r10
    b79f:	0f 84 9c fa ff ff    	je     b241 <fwp_main_thread+0x1c81>
    b7a5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    b7ac:	00 
    b7ad:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b7b2:	48 89 05 1f 6c 01 00 	mov    %rax,0x16c1f(%rip)        # 223d8 <fwp_cleanups>
    b7b9:	e8 32 96 ff ff       	call   4df0 <fwp_tape_buffers_release>
    b7be:	48 8b 0d 7b 48 00 00 	mov    0x487b(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    b7c5:	ba 13 00 00 00       	mov    $0x13,%edx
    b7ca:	be 01 00 00 00       	mov    $0x1,%esi
    b7cf:	48 8d 3d 32 08 00 00 	lea    0x832(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    b7d6:	e8 65 7e ff ff       	call   3640 <fwrite@plt>
    b7db:	31 ff                	xor    %edi,%edi
    b7dd:	e8 ae 7d ff ff       	call   3590 <fflush@plt>
    b7e2:	bf 66 00 00 00       	mov    $0x66,%edi
    b7e7:	e8 74 7e ff ff       	call   3660 <_Exit@plt>
    b7ec:	48 8d 3d 3a 09 00 00 	lea    0x93a(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    b7f3:	e8 68 89 ff ff       	call   4160 <fwp_trap>
    b7f8:	48 8d 3d bf 09 00 00 	lea    0x9bf(%rip),%rdi        # c1be <_IO_stdin_used+0x1be>
    b7ff:	e8 5c 89 ff ff       	call   4160 <fwp_trap>
    b804:	48 8d 3d cd 09 00 00 	lea    0x9cd(%rip),%rdi        # c1d8 <_IO_stdin_used+0x1d8>
    b80b:	e8 50 89 ff ff       	call   4160 <fwp_trap>
    b810:	48 8d 3d 59 10 00 00 	lea    0x1059(%rip),%rdi        # c870 <_IO_stdin_used+0x870>
    b817:	e8 44 89 ff ff       	call   4160 <fwp_trap>
    b81c:	48 8d 3d c5 09 00 00 	lea    0x9c5(%rip),%rdi        # c1e8 <_IO_stdin_used+0x1e8>
    b823:	e8 38 89 ff ff       	call   4160 <fwp_trap>
    b828:	e8 13 7c ff ff       	call   3440 <__stack_chk_fail@plt>
    b82d:	48 8d 3d 64 10 00 00 	lea    0x1064(%rip),%rdi        # c898 <_IO_stdin_used+0x898>
    b834:	e8 27 89 ff ff       	call   4160 <fwp_trap>
    b839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b840:	48 8d 3d a9 10 00 00 	lea    0x10a9(%rip),%rdi        # c8f0 <_IO_stdin_used+0x8f0>
    b847:	e8 14 89 ff ff       	call   4160 <fwp_trap>
    b84c:	48 8d 3d bd 0f 00 00 	lea    0xfbd(%rip),%rdi        # c810 <_IO_stdin_used+0x810>
    b853:	e8 08 89 ff ff       	call   4160 <fwp_trap>
    b858:	e9 ae 7e ff ff       	jmp    370b <fwp_main_thread.cold>
    b85d:	e9 a9 7e ff ff       	jmp    370b <fwp_main_thread.cold>
    b862:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b869:	00 00 00 
    b86c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000000b870 <__divmodti4>:
    b870:	f3 0f 1e fa          	endbr64
    b874:	55                   	push   %rbp
    b875:	49 89 f1             	mov    %rsi,%r9
    b878:	49 89 d2             	mov    %rdx,%r10
    b87b:	48 89 fe             	mov    %rdi,%rsi
    b87e:	49 89 cb             	mov    %rcx,%r11
    b881:	48 89 e5             	mov    %rsp,%rbp
    b884:	41 57                	push   %r15
    b886:	41 56                	push   %r14
    b888:	41 55                	push   %r13
    b88a:	41 54                	push   %r12
    b88c:	53                   	push   %rbx
    b88d:	4c 89 c3             	mov    %r8,%rbx
    b890:	45 31 c0             	xor    %r8d,%r8d
    b893:	4d 85 c9             	test   %r9,%r9
    b896:	79 12                	jns    b8aa <__divmodti4+0x3a>
    b898:	31 ff                	xor    %edi,%edi
    b89a:	48 f7 de             	neg    %rsi
    b89d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b8a4:	4c 19 cf             	sbb    %r9,%rdi
    b8a7:	49 89 f9             	mov    %rdi,%r9
    b8aa:	4c 89 d8             	mov    %r11,%rax
    b8ad:	4d 85 db             	test   %r11,%r11
    b8b0:	0f 88 1a 01 00 00    	js     b9d0 <__divmodti4+0x160>
    b8b6:	4c 89 d9             	mov    %r11,%rcx
    b8b9:	49 89 f3             	mov    %rsi,%r11
    b8bc:	75 62                	jne    b920 <__divmodti4+0xb0>
    b8be:	4d 89 c4             	mov    %r8,%r12
    b8c1:	4d 39 d1             	cmp    %r10,%r9
    b8c4:	0f 83 46 01 00 00    	jae    ba10 <__divmodti4+0x1a0>
    b8ca:	4c 89 d8             	mov    %r11,%rax
    b8cd:	4c 89 ca             	mov    %r9,%rdx
    b8d0:	49 f7 f2             	div    %r10
    b8d3:	49 89 c3             	mov    %rax,%r11
    b8d6:	31 c0                	xor    %eax,%eax
    b8d8:	48 89 d6             	mov    %rdx,%rsi
    b8db:	31 ff                	xor    %edi,%edi
    b8dd:	4c 89 d9             	mov    %r11,%rcx
    b8e0:	48 89 c2             	mov    %rax,%rdx
    b8e3:	48 89 c8             	mov    %rcx,%rax
    b8e6:	4d 85 e4             	test   %r12,%r12
    b8e9:	74 0a                	je     b8f5 <__divmodti4+0x85>
    b8eb:	48 f7 d8             	neg    %rax
    b8ee:	48 83 d2 00          	adc    $0x0,%rdx
    b8f2:	48 f7 da             	neg    %rdx
    b8f5:	4d 85 c0             	test   %r8,%r8
    b8f8:	74 0a                	je     b904 <__divmodti4+0x94>
    b8fa:	48 f7 de             	neg    %rsi
    b8fd:	48 83 d7 00          	adc    $0x0,%rdi
    b901:	48 f7 df             	neg    %rdi
    b904:	48 89 33             	mov    %rsi,(%rbx)
    b907:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b90b:	5b                   	pop    %rbx
    b90c:	41 5c                	pop    %r12
    b90e:	41 5d                	pop    %r13
    b910:	41 5e                	pop    %r14
    b912:	41 5f                	pop    %r15
    b914:	5d                   	pop    %rbp
    b915:	c3                   	ret
    b916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b91d:	00 00 00 
    b920:	4d 89 c4             	mov    %r8,%r12
    b923:	49 39 c1             	cmp    %rax,%r9
    b926:	0f 82 ce 00 00 00    	jb     b9fa <__divmodti4+0x18a>
    b92c:	31 ff                	xor    %edi,%edi
    b92e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b933:	48 63 c7             	movslq %edi,%rax
    b936:	be 40 00 00 00       	mov    $0x40,%esi
    b93b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b940:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b945:	48 29 c6             	sub    %rax,%rsi
    b948:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b94d:	48 09 c8             	or     %rcx,%rax
    b950:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b955:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b95a:	49 89 c6             	mov    %rax,%r14
    b95d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b961:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b966:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b96b:	49 09 c1             	or     %rax,%r9
    b96e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b972:	4c 89 c8             	mov    %r9,%rax
    b975:	49 f7 f6             	div    %r14
    b978:	48 89 d1             	mov    %rdx,%rcx
    b97b:	49 89 c3             	mov    %rax,%r11
    b97e:	49 89 c1             	mov    %rax,%r9
    b981:	49 f7 e2             	mul    %r10
    b984:	49 89 c6             	mov    %rax,%r14
    b987:	49 89 d2             	mov    %rdx,%r10
    b98a:	48 39 d1             	cmp    %rdx,%rcx
    b98d:	72 07                	jb     b996 <__divmodti4+0x126>
    b98f:	75 17                	jne    b9a8 <__divmodti4+0x138>
    b991:	49 39 c7             	cmp    %rax,%r15
    b994:	73 12                	jae    b9a8 <__divmodti4+0x138>
    b996:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b99a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b99e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b9a2:	49 89 d2             	mov    %rdx,%r10
    b9a5:	49 89 c6             	mov    %rax,%r14
    b9a8:	4c 89 f8             	mov    %r15,%rax
    b9ab:	4c 29 f0             	sub    %r14,%rax
    b9ae:	4c 19 d1             	sbb    %r10,%rcx
    b9b1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b9b6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b9bb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b9c0:	48 09 c6             	or     %rax,%rsi
    b9c3:	48 89 cf             	mov    %rcx,%rdi
    b9c6:	31 c0                	xor    %eax,%eax
    b9c8:	4c 89 c9             	mov    %r9,%rcx
    b9cb:	e9 10 ff ff ff       	jmp    b8e0 <__divmodti4+0x70>
    b9d0:	4c 89 d0             	mov    %r10,%rax
    b9d3:	4c 89 da             	mov    %r11,%rdx
    b9d6:	4d 89 c4             	mov    %r8,%r12
    b9d9:	49 89 f3             	mov    %rsi,%r11
    b9dc:	48 f7 d8             	neg    %rax
    b9df:	49 f7 d4             	not    %r12
    b9e2:	48 83 d2 00          	adc    $0x0,%rdx
    b9e6:	49 89 c2             	mov    %rax,%r10
    b9e9:	48 f7 da             	neg    %rdx
    b9ec:	48 89 d1             	mov    %rdx,%rcx
    b9ef:	0f 84 cc fe ff ff    	je     b8c1 <__divmodti4+0x51>
    b9f5:	49 39 d1             	cmp    %rdx,%r9
    b9f8:	73 46                	jae    ba40 <__divmodti4+0x1d0>
    b9fa:	4c 89 cf             	mov    %r9,%rdi
    b9fd:	31 c0                	xor    %eax,%eax
    b9ff:	31 c9                	xor    %ecx,%ecx
    ba01:	e9 da fe ff ff       	jmp    b8e0 <__divmodti4+0x70>
    ba06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba0d:	00 00 00 
    ba10:	4d 85 d2             	test   %r10,%r10
    ba13:	75 0d                	jne    ba22 <__divmodti4+0x1b2>
    ba15:	b8 01 00 00 00       	mov    $0x1,%eax
    ba1a:	31 d2                	xor    %edx,%edx
    ba1c:	49 f7 f2             	div    %r10
    ba1f:	49 89 c2             	mov    %rax,%r10
    ba22:	4c 89 c8             	mov    %r9,%rax
    ba25:	31 d2                	xor    %edx,%edx
    ba27:	49 f7 f2             	div    %r10
    ba2a:	49 89 c1             	mov    %rax,%r9
    ba2d:	4c 89 d8             	mov    %r11,%rax
    ba30:	49 f7 f2             	div    %r10
    ba33:	49 89 c3             	mov    %rax,%r11
    ba36:	4c 89 c8             	mov    %r9,%rax
    ba39:	e9 9a fe ff ff       	jmp    b8d8 <__divmodti4+0x68>
    ba3e:	66 90                	xchg   %ax,%ax
    ba40:	45 31 f6             	xor    %r14d,%r14d
    ba43:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ba48:	44 89 f7             	mov    %r14d,%edi
    ba4b:	45 85 f6             	test   %r14d,%r14d
    ba4e:	0f 85 df fe ff ff    	jne    b933 <__divmodti4+0xc3>
    ba54:	4c 39 ca             	cmp    %r9,%rdx
    ba57:	72 17                	jb     ba70 <__divmodti4+0x200>
    ba59:	31 c9                	xor    %ecx,%ecx
    ba5b:	48 39 c6             	cmp    %rax,%rsi
    ba5e:	73 10                	jae    ba70 <__divmodti4+0x200>
    ba60:	4c 89 cf             	mov    %r9,%rdi
    ba63:	31 c0                	xor    %eax,%eax
    ba65:	e9 76 fe ff ff       	jmp    b8e0 <__divmodti4+0x70>
    ba6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba70:	4c 89 de             	mov    %r11,%rsi
    ba73:	b9 01 00 00 00       	mov    $0x1,%ecx
    ba78:	48 29 c6             	sub    %rax,%rsi
    ba7b:	49 19 d1             	sbb    %rdx,%r9
    ba7e:	eb e0                	jmp    ba60 <__divmodti4+0x1f0>

000000000000ba80 <atexit>:
    ba80:	f3 0f 1e fa          	endbr64
    ba84:	48 8b 15 7d 45 00 00 	mov    0x457d(%rip),%rdx        # 10008 <__dso_handle>
    ba8b:	31 f6                	xor    %esi,%esi
    ba8d:	e9 8e 7b ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ba94 <_fini>:
    ba94:	f3 0f 1e fa          	endbr64
    ba98:	48 83 ec 08          	sub    $0x8,%rsp
    ba9c:	48 83 c4 08          	add    $0x8,%rsp
    baa0:	c3                   	ret
