
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # efd0 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 ea cd 00 00    	push   0xcdea(%rip)        # ee10 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 ec cd 00 00    	jmp    *0xcdec(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 96 ca 00 00    	jmp    *0xca96(%rip)        # ee20 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # ee28 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # ee30 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # ee38 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # ee40 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # ee48 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # ee50 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # ee58 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # ee60 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # ee68 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # ee70 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # ee78 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # ee80 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # ee88 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # ee90 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # ee98 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # eea0 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # eea8 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # eeb0 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # eeb8 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # eec0 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # eec8 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # eed0 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # eed8 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # eee0 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # eee8 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # eef0 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # eef8 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ef00 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ef08 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ef10 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ef18 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ef20 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ef28 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ef30 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ef38 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ef40 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ef48 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ef50 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ef58 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ef60 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ef68 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ef70 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ef78 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ef80 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ef88 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ef90 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ef98 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # efa0 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # efa8 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # efb0 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # efb8 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 99 00 00 	lea    0x99a0(%rip),%r9        # c077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 99 00 00 	lea    0x999d(%rip),%r8        # c07b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 1a 0a 00 00       	call   3120 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_loop_fields68.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 c8 00 00 	mov    0xc8e1(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 f2 eb 01 00 	mov    %rax,0x1ebf2(%rip)        # 21338 <fwp_prog_out>
    2746:	e8 05 0a 00 00       	call   3150 <fwp_now_ns>
    274b:	48 8d 3d 1a 9a 00 00 	lea    0x9a1a(%rip),%rdi        # c16c <_IO_stdin_used+0x16c>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 c8 00 00 	mov    0xc866(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 cd 81 00 00 	lea    0x81cd(%rip),%rdx        # a9e0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d d1 c7 00 00 	mov    0xc7d1(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 c8 01 00    	mov    0x1c826(%rip),%eax        # 1f080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d ca 98 00 00 	lea    0x98ca(%rip),%rdi        # c175 <_IO_stdin_used+0x175>
    28ab:	e8 70 08 00 00       	call   3120 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d f4 9a 00 00 	lea    0x9af4(%rip),%rdi        # c3b0 <_IO_stdin_used+0x3b0>
    28bc:	e8 5f 08 00 00       	call   3120 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d ae 9a 00 00 	lea    0x9aae(%rip),%rdi        # c388 <_IO_stdin_used+0x388>
    28da:	e8 41 08 00 00       	call   3120 <fwp_trap>
    28df:	48 8d 3d 72 9a 00 00 	lea    0x9a72(%rip),%rdi        # c358 <_IO_stdin_used+0x358>
    28e6:	e8 35 08 00 00       	call   3120 <fwp_trap>
    28eb:	48 8d 3d 3e 9a 00 00 	lea    0x9a3e(%rip),%rdi        # c330 <_IO_stdin_used+0x330>
    28f2:	e8 29 08 00 00       	call   3120 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 9b c6 00 00    	call   *0xc69b(%rip)        # efc0 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 c6 00 00 	lea    0xc6e1(%rip),%rdi        # f018 <__TMC_END__>
    2937:	48 8d 05 da c6 00 00 	lea    0xc6da(%rip),%rax        # f018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 7e c6 00 00 	mov    0xc67e(%rip),%rax        # efc8 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 c6 00 00 	lea    0xc6b1(%rip),%rdi        # f018 <__TMC_END__>
    2967:	48 8d 35 aa c6 00 00 	lea    0xc6aa(%rip),%rsi        # f018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 4d c6 00 00 	mov    0xc64d(%rip),%rax        # efd8 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d c6 00 00 00 	cmpb   $0x0,0xc69d(%rip)        # f048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 2a c6 00 00 	cmpq   $0x0,0xc62a(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 c6 00 00 	mov    0xc646(%rip),%rdi        # f008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 c6 00 00 01 	movb   $0x1,0xc675(%rip)        # f048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_owned_entry32>:
    2bc0:	f3 0f 1e fa          	endbr64
    2bc4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bc9:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    2bcd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2bd2:	c3                   	ret
    2bd3:	66 90                	xchg   %ax,%ax
    2bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bdc:	00 00 00 00 

0000000000002be0 <fwp_args32>:
    2be0:	f3 0f 1e fa          	endbr64
    2be4:	c3                   	ret
    2be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bec:	00 00 00 00 

0000000000002bf0 <fwp_owned_entry45>:
    2bf0:	f3 0f 1e fa          	endbr64
    2bf4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bf9:	f2 0f 58 07          	addsd  (%rdi),%xmm0
    2bfd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c02:	c3                   	ret
    2c03:	66 90                	xchg   %ax,%ax
    2c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c0c:	00 00 00 00 

0000000000002c10 <fwp_owned_entry69>:
    2c10:	f3 0f 1e fa          	endbr64
    2c14:	f2 0f 10 05 54 98 00 	movsd  0x9854(%rip),%xmm0        # c470 <msg.3+0x20>
    2c1b:	00 
    2c1c:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    2c20:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c25:	c3                   	ret
    2c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2c2d:	00 00 00 

0000000000002c30 <fwp_flush>:
    2c30:	48 8b 3d 01 e7 01 00 	mov    0x1e701(%rip),%rdi        # 21338 <fwp_prog_out>
    2c37:	48 85 ff             	test   %rdi,%rdi
    2c3a:	74 1c                	je     2c58 <fwp_flush+0x28>
    2c3c:	48 83 ec 08          	sub    $0x8,%rsp
    2c40:	e8 4b f9 ff ff       	call   2590 <fflush@plt>
    2c45:	48 8b 3d d4 c3 00 00 	mov    0xc3d4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    2c4c:	48 83 c4 08          	add    $0x8,%rsp
    2c50:	e9 3b f9 ff ff       	jmp    2590 <fflush@plt>
    2c55:	0f 1f 00             	nopl   (%rax)
    2c58:	48 8b 3d c1 c3 00 00 	mov    0xc3c1(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    2c5f:	e9 2c f9 ff ff       	jmp    2590 <fflush@plt>
    2c64:	90                   	nop
    2c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c6c:	00 00 00 00 

0000000000002c70 <fwp_heap_oom>:
    2c70:	50                   	push   %rax
    2c71:	58                   	pop    %rax
    2c72:	ba 13 00 00 00       	mov    $0x13,%edx
    2c77:	be 01 00 00 00       	mov    $0x1,%esi
    2c7c:	48 8d 3d 85 93 00 00 	lea    0x9385(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    2c83:	48 83 ec 08          	sub    $0x8,%rsp
    2c87:	48 8b 0d b2 c3 00 00 	mov    0xc3b2(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    2c8e:	e8 ad f9 ff ff       	call   2640 <fwrite@plt>
    2c93:	31 ff                	xor    %edi,%edi
    2c95:	e8 f6 f8 ff ff       	call   2590 <fflush@plt>
    2c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c9f:	e8 bc f9 ff ff       	call   2660 <_Exit@plt>
    2ca4:	90                   	nop
    2ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cac:	00 00 00 00 

0000000000002cb0 <fwp_segv>:
    2cb0:	f3 0f 1e fa          	endbr64
    2cb4:	48 83 ec 28          	sub    $0x28,%rsp
    2cb8:	48 8b 05 01 ca 01 00 	mov    0x1ca01(%rip),%rax        # 1f6c0 <fwp_cur>
    2cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2cc3:	41 89 f8             	mov    %edi,%r8d
    2cc6:	48 85 c0             	test   %rax,%rax
    2cc9:	74 6d                	je     2d38 <fwp_segv+0x88>
    2ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2ccf:	48 85 d2             	test   %rdx,%rdx
    2cd2:	74 64                	je     2d38 <fwp_segv+0x88>
    2cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2ce7:	e8 14 f9 ff ff       	call   2600 <sysconf@plt>
    2cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2cfb:	48 01 d0             	add    %rdx,%rax
    2cfe:	48 39 c1             	cmp    %rax,%rcx
    2d01:	b8 00 00 00 00       	mov    $0x0,%eax
    2d06:	40 0f 92 c6          	setb   %sil
    2d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    2d15:	31 c0                	xor    %eax,%eax
    2d17:	48 39 d1             	cmp    %rdx,%rcx
    2d1a:	0f 93 c0             	setae  %al
    2d1d:	21 f0                	and    %esi,%eax
    2d1f:	85 c0                	test   %eax,%eax
    2d21:	75 4a                	jne    2d6d <fwp_segv+0xbd>
    2d23:	31 f6                	xor    %esi,%esi
    2d25:	44 89 c7             	mov    %r8d,%edi
    2d28:	48 83 c4 28          	add    $0x28,%rsp
    2d2c:	e9 ef f7 ff ff       	jmp    2520 <signal@plt>
    2d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2d38:	48 8b 05 51 c3 01 00 	mov    0x1c351(%rip),%rax        # 1f090 <fwp_main_stack_top>
    2d3f:	48 85 c0             	test   %rax,%rax
    2d42:	74 df                	je     2d23 <fwp_segv+0x73>
    2d44:	48 2b 05 3d c3 01 00 	sub    0x1c33d(%rip),%rax        # 1f088 <fwp_main_stack_size>
    2d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2d52:	48 39 d1             	cmp    %rdx,%rcx
    2d55:	0f 93 c2             	setae  %dl
    2d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    2d5e:	48 39 c1             	cmp    %rax,%rcx
    2d61:	0f 92 c0             	setb   %al
    2d64:	0f b6 c0             	movzbl %al,%eax
    2d67:	21 d0                	and    %edx,%eax
    2d69:	85 c0                	test   %eax,%eax
    2d6b:	74 b6                	je     2d23 <fwp_segv+0x73>
    2d6d:	e8 be fe ff ff       	call   2c30 <fwp_flush>
    2d72:	bf 02 00 00 00       	mov    $0x2,%edi
    2d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d7c:	48 8d 35 cd 96 00 00 	lea    0x96cd(%rip),%rsi        # c450 <msg.3>
    2d83:	e8 88 f6 ff ff       	call   2410 <write@plt>
    2d88:	bf 65 00 00 00       	mov    $0x65,%edi
    2d8d:	e8 2e f6 ff ff       	call   23c0 <_exit@plt>
    2d92:	0f 1f 00             	nopl   (%rax)
    2d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d9c:	00 00 00 00 

0000000000002da0 <fwp_heap_chunks>:
    2da0:	41 54                	push   %r12
    2da2:	55                   	push   %rbp
    2da3:	53                   	push   %rbx
    2da4:	48 83 ff 01          	cmp    $0x1,%rdi
    2da8:	0f 84 62 01 00 00    	je     2f10 <fwp_heap_chunks+0x170>
    2dae:	48 8b 05 1b dd 01 00 	mov    0x1dd1b(%rip),%rax        # 20ad0 <fwp_heap+0x13f0>
    2db5:	4c 8d 05 14 dd 01 00 	lea    0x1dd14(%rip),%r8        # 20ad0 <fwp_heap+0x13f0>
    2dbc:	48 8b 1d f5 dc 01 00 	mov    0x1dcf5(%rip),%rbx        # 20ab8 <fwp_heap+0x13d8>
    2dc3:	48 39 d8             	cmp    %rbx,%rax
    2dc6:	0f 83 57 01 00 00    	jae    2f23 <fwp_heap_chunks+0x183>
    2dcc:	48 8b 0d 05 dd 01 00 	mov    0x1dd05(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    2dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2dd7:	31 f6                	xor    %esi,%esi
    2dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2ddd:	eb 1e                	jmp    2dfd <fwp_heap_chunks+0x5d>
    2ddf:	90                   	nop
    2de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2de4:	48 39 cf             	cmp    %rcx,%rdi
    2de7:	0f 84 03 01 00 00    	je     2ef0 <fwp_heap_chunks+0x150>
    2ded:	48 83 c0 01          	add    $0x1,%rax
    2df1:	48 89 ce             	mov    %rcx,%rsi
    2df4:	48 83 c2 28          	add    $0x28,%rdx
    2df8:	48 39 c3             	cmp    %rax,%rbx
    2dfb:	74 14                	je     2e11 <fwp_heap_chunks+0x71>
    2dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    2e00:	74 de                	je     2de0 <fwp_heap_chunks+0x40>
    2e02:	48 83 c0 01          	add    $0x1,%rax
    2e06:	31 f6                	xor    %esi,%esi
    2e08:	48 83 c2 28          	add    $0x28,%rdx
    2e0c:	48 39 c3             	cmp    %rax,%rbx
    2e0f:	75 ec                	jne    2dfd <fwp_heap_chunks+0x5d>
    2e11:	48 29 f3             	sub    %rsi,%rbx
    2e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2e18:	48 8b 3d a1 dc 01 00 	mov    0x1dca1(%rip),%rdi        # 20ac0 <fwp_heap+0x13e0>
    2e1f:	48 29 35 ea dc 01 00 	sub    %rsi,0x1dcea(%rip)        # 20b10 <fwp_heap+0x1430>
    2e26:	48 39 ef             	cmp    %rbp,%rdi
    2e29:	0f 83 96 00 00 00    	jae    2ec5 <fwp_heap_chunks+0x125>
    2e2f:	48 8b 05 7a dc 01 00 	mov    0x1dc7a(%rip),%rax        # 20ab0 <fwp_heap+0x13d0>
    2e36:	48 39 e8             	cmp    %rbp,%rax
    2e39:	0f 82 eb 00 00 00    	jb     2f2a <fwp_heap_chunks+0x18a>
    2e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2e43:	ba 03 00 00 00       	mov    $0x3,%edx
    2e48:	49 39 c4             	cmp    %rax,%r12
    2e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    2e4f:	4c 89 e6             	mov    %r12,%rsi
    2e52:	48 29 fe             	sub    %rdi,%rsi
    2e55:	48 c1 e7 10          	shl    $0x10,%rdi
    2e59:	48 03 3d 30 dc 01 00 	add    0x1dc30(%rip),%rdi        # 20a90 <fwp_heap+0x13b0>
    2e60:	48 c1 e6 10          	shl    $0x10,%rsi
    2e64:	e8 77 f7 ff ff       	call   25e0 <mprotect@plt>
    2e69:	85 c0                	test   %eax,%eax
    2e6b:	0f 85 b9 00 00 00    	jne    2f2a <fwp_heap_chunks+0x18a>
    2e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e76:	e8 85 f7 ff ff       	call   2600 <sysconf@plt>
    2e7b:	48 8b 35 3e dc 01 00 	mov    0x1dc3e(%rip),%rsi        # 20ac0 <fwp_heap+0x13e0>
    2e82:	48 89 c1             	mov    %rax,%rcx
    2e85:	48 8b 05 4c dc 01 00 	mov    0x1dc4c(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    2e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e90:	48 89 ca             	mov    %rcx,%rdx
    2e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e9b:	48 f7 da             	neg    %rdx
    2e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2ea3:	48 21 d7             	and    %rdx,%rdi
    2ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2eaa:	48 21 d6             	and    %rdx,%rsi
    2ead:	ba 03 00 00 00       	mov    $0x3,%edx
    2eb2:	48 29 fe             	sub    %rdi,%rsi
    2eb5:	e8 26 f7 ff ff       	call   25e0 <mprotect@plt>
    2eba:	85 c0                	test   %eax,%eax
    2ebc:	75 6c                	jne    2f2a <fwp_heap_chunks+0x18a>
    2ebe:	4c 89 25 fb db 01 00 	mov    %r12,0x1dbfb(%rip)        # 20ac0 <fwp_heap+0x13e0>
    2ec5:	48 89 ef             	mov    %rbp,%rdi
    2ec8:	48 89 2d e9 db 01 00 	mov    %rbp,0x1dbe9(%rip)        # 20ab8 <fwp_heap+0x13d8>
    2ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    2ed3:	48 39 3d ce db 01 00 	cmp    %rdi,0x1dbce(%rip)        # 20aa8 <fwp_heap+0x13c8>
    2eda:	73 07                	jae    2ee3 <fwp_heap_chunks+0x143>
    2edc:	48 89 3d c5 db 01 00 	mov    %rdi,0x1dbc5(%rip)        # 20aa8 <fwp_heap+0x13c8>
    2ee3:	48 89 d8             	mov    %rbx,%rax
    2ee6:	5b                   	pop    %rbx
    2ee7:	5d                   	pop    %rbp
    2ee8:	41 5c                	pop    %r12
    2eea:	c3                   	ret
    2eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2ef4:	48 29 f0             	sub    %rsi,%rax
    2ef7:	48 89 c3             	mov    %rax,%rbx
    2efa:	49 89 10             	mov    %rdx,(%r8)
    2efd:	48 89 d8             	mov    %rbx,%rax
    2f00:	48 29 3d 09 dc 01 00 	sub    %rdi,0x1dc09(%rip)        # 20b10 <fwp_heap+0x1430>
    2f07:	5b                   	pop    %rbx
    2f08:	5d                   	pop    %rbp
    2f09:	41 5c                	pop    %r12
    2f0b:	c3                   	ret
    2f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    2f10:	48 8b 05 b1 db 01 00 	mov    0x1dbb1(%rip),%rax        # 20ac8 <fwp_heap+0x13e8>
    2f17:	4c 8d 05 aa db 01 00 	lea    0x1dbaa(%rip),%r8        # 20ac8 <fwp_heap+0x13e8>
    2f1e:	e9 99 fe ff ff       	jmp    2dbc <fwp_heap_chunks+0x1c>
    2f23:	31 f6                	xor    %esi,%esi
    2f25:	e9 ea fe ff ff       	jmp    2e14 <fwp_heap_chunks+0x74>
    2f2a:	e8 41 fd ff ff       	call   2c70 <fwp_heap_oom>
    2f2f:	90                   	nop

0000000000002f30 <buf_grow>:
    2f30:	48 83 ec 18          	sub    $0x18,%rsp
    2f34:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2f38:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2f3c:	74 7e                	je     2fbc <buf_grow+0x8c>
    2f3e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f45:	48 29 c2             	sub    %rax,%rdx
    2f48:	48 39 f2             	cmp    %rsi,%rdx
    2f4b:	72 6f                	jb     2fbc <buf_grow+0x8c>
    2f4d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f52:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f56:	48 89 f9             	mov    %rdi,%rcx
    2f59:	48 39 d0             	cmp    %rdx,%rax
    2f5c:	73 48                	jae    2fa6 <buf_grow+0x76>
    2f5e:	48 85 c0             	test   %rax,%rax
    2f61:	75 15                	jne    2f78 <buf_grow+0x48>
    2f63:	48 83 fa 40          	cmp    $0x40,%rdx
    2f67:	76 4c                	jbe    2fb5 <buf_grow+0x85>
    2f69:	b8 40 00 00 00       	mov    $0x40,%eax
    2f6e:	eb 08                	jmp    2f78 <buf_grow+0x48>
    2f70:	48 01 c0             	add    %rax,%rax
    2f73:	48 39 d0             	cmp    %rdx,%rax
    2f76:	73 38                	jae    2fb0 <buf_grow+0x80>
    2f78:	48 85 c0             	test   %rax,%rax
    2f7b:	79 f3                	jns    2f70 <buf_grow+0x40>
    2f7d:	48 8b 39             	mov    (%rcx),%rdi
    2f80:	48 89 d6             	mov    %rdx,%rsi
    2f83:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f88:	48 89 14 24          	mov    %rdx,(%rsp)
    2f8c:	e8 0f f6 ff ff       	call   25a0 <realloc@plt>
    2f91:	48 8b 14 24          	mov    (%rsp),%rdx
    2f95:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f9a:	48 85 c0             	test   %rax,%rax
    2f9d:	74 1d                	je     2fbc <buf_grow+0x8c>
    2f9f:	48 89 01             	mov    %rax,(%rcx)
    2fa2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2fa6:	48 83 c4 18          	add    $0x18,%rsp
    2faa:	c3                   	ret
    2fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fb0:	48 89 c2             	mov    %rax,%rdx
    2fb3:	eb c8                	jmp    2f7d <buf_grow+0x4d>
    2fb5:	ba 40 00 00 00       	mov    $0x40,%edx
    2fba:	eb c1                	jmp    2f7d <buf_grow+0x4d>
    2fbc:	48 8b 0d 7d c0 00 00 	mov    0xc07d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    2fc3:	ba 13 00 00 00       	mov    $0x13,%edx
    2fc8:	be 01 00 00 00       	mov    $0x1,%esi
    2fcd:	48 8d 3d 34 90 00 00 	lea    0x9034(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    2fd4:	e8 67 f6 ff ff       	call   2640 <fwrite@plt>
    2fd9:	31 ff                	xor    %edi,%edi
    2fdb:	e8 b0 f5 ff ff       	call   2590 <fflush@plt>
    2fe0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fe5:	e8 76 f6 ff ff       	call   2660 <_Exit@plt>
    2fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002ff0 <buf_put>:
    2ff0:	41 54                	push   %r12
    2ff2:	49 89 f4             	mov    %rsi,%r12
    2ff5:	48 89 d6             	mov    %rdx,%rsi
    2ff8:	55                   	push   %rbp
    2ff9:	48 89 fd             	mov    %rdi,%rbp
    2ffc:	53                   	push   %rbx
    2ffd:	48 89 d3             	mov    %rdx,%rbx
    3000:	e8 2b ff ff ff       	call   2f30 <buf_grow>
    3005:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    3009:	48 89 da             	mov    %rbx,%rdx
    300c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    3010:	4c 89 e6             	mov    %r12,%rsi
    3013:	e8 58 f5 ff ff       	call   2570 <memcpy@plt>
    3018:	48 8b 45 00          	mov    0x0(%rbp),%rax
    301c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    3020:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    3024:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    3028:	5b                   	pop    %rbx
    3029:	5d                   	pop    %rbp
    302a:	41 5c                	pop    %r12
    302c:	c3                   	ret
    302d:	0f 1f 00             	nopl   (%rax)

0000000000003030 <fwp_cancel_tree.part.0>:
    3030:	48 3b 3d 89 c6 01 00 	cmp    0x1c689(%rip),%rdi        # 1f6c0 <fwp_cur>
    3037:	53                   	push   %rbx
    3038:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    303c:	74 35                	je     3073 <fwp_cancel_tree.part.0+0x43>
    303e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3042:	75 2f                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    3044:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3048:	75 29                	jne    3073 <fwp_cancel_tree.part.0+0x43>
    304a:	48 8b 05 4f c6 01 00 	mov    0x1c64f(%rip),%rax        # 1f6a0 <fwp_ready_tail>
    3051:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3055:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    305c:	00 00 00 00 
    3060:	48 85 c0             	test   %rax,%rax
    3063:	74 33                	je     3098 <fwp_cancel_tree.part.0+0x68>
    3065:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    306c:	48 89 3d 2d c6 01 00 	mov    %rdi,0x1c62d(%rip)        # 1f6a0 <fwp_ready_tail>
    3073:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3077:	48 85 db             	test   %rbx,%rbx
    307a:	74 17                	je     3093 <fwp_cancel_tree.part.0+0x63>
    307c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3080:	75 08                	jne    308a <fwp_cancel_tree.part.0+0x5a>
    3082:	48 89 df             	mov    %rbx,%rdi
    3085:	e8 a6 ff ff ff       	call   3030 <fwp_cancel_tree.part.0>
    308a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    308e:	48 85 db             	test   %rbx,%rbx
    3091:	75 e9                	jne    307c <fwp_cancel_tree.part.0+0x4c>
    3093:	5b                   	pop    %rbx
    3094:	c3                   	ret
    3095:	0f 1f 00             	nopl   (%rax)
    3098:	48 89 3d 09 c6 01 00 	mov    %rdi,0x1c609(%rip)        # 1f6a8 <fwp_ready_head>
    309f:	eb cb                	jmp    306c <fwp_cancel_tree.part.0+0x3c>
    30a1:	0f 1f 40 00          	nopl   0x0(%rax)
    30a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    30ac:	00 00 00 00 

00000000000030b0 <fwp_finish_float>:
    30b0:	53                   	push   %rbx
    30b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    30b6:	48 89 fb             	mov    %rdi,%rbx
    30b9:	e8 a2 f3 ff ff       	call   2460 <strchr@plt>
    30be:	48 85 c0             	test   %rax,%rax
    30c1:	74 05                	je     30c8 <fwp_finish_float+0x18>
    30c3:	5b                   	pop    %rbx
    30c4:	c3                   	ret
    30c5:	0f 1f 00             	nopl   (%rax)
    30c8:	be 65 00 00 00       	mov    $0x65,%esi
    30cd:	48 89 df             	mov    %rbx,%rdi
    30d0:	e8 8b f3 ff ff       	call   2460 <strchr@plt>
    30d5:	48 85 c0             	test   %rax,%rax
    30d8:	75 e9                	jne    30c3 <fwp_finish_float+0x13>
    30da:	48 8d 35 f8 8f 00 00 	lea    0x8ff8(%rip),%rsi        # c0d9 <_IO_stdin_used+0xd9>
    30e1:	48 89 df             	mov    %rbx,%rdi
    30e4:	e8 a7 f5 ff ff       	call   2690 <strstr@plt>
    30e9:	48 85 c0             	test   %rax,%rax
    30ec:	75 d5                	jne    30c3 <fwp_finish_float+0x13>
    30ee:	48 8d 35 27 8f 00 00 	lea    0x8f27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    30f5:	48 89 df             	mov    %rbx,%rdi
    30f8:	e8 93 f5 ff ff       	call   2690 <strstr@plt>
    30fd:	48 85 c0             	test   %rax,%rax
    3100:	75 c1                	jne    30c3 <fwp_finish_float+0x13>
    3102:	48 89 df             	mov    %rbx,%rdi
    3105:	e8 26 f3 ff ff       	call   2430 <strlen@plt>
    310a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    310f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    3113:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    3118:	5b                   	pop    %rbx
    3119:	c3                   	ret
    311a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003120 <fwp_trap>:
    3120:	53                   	push   %rbx
    3121:	48 89 fb             	mov    %rdi,%rbx
    3124:	e8 07 fb ff ff       	call   2c30 <fwp_flush>
    3129:	48 89 d9             	mov    %rbx,%rcx
    312c:	be 02 00 00 00       	mov    $0x2,%esi
    3131:	31 c0                	xor    %eax,%eax
    3133:	48 8b 3d 06 bf 00 00 	mov    0xbf06(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    313a:	48 8d 15 df 8e 00 00 	lea    0x8edf(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    3141:	e8 0a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3146:	bf 65 00 00 00       	mov    $0x65,%edi
    314b:	e8 e0 f4 ff ff       	call   2630 <exit@plt>

0000000000003150 <fwp_now_ns>:
    3150:	53                   	push   %rbx
    3151:	bf 01 00 00 00       	mov    $0x1,%edi
    3156:	48 83 ec 20          	sub    $0x20,%rsp
    315a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3161:	00 00 
    3163:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3168:	31 db                	xor    %ebx,%ebx
    316a:	48 89 e6             	mov    %rsp,%rsi
    316d:	e8 8e f2 ff ff       	call   2400 <clock_gettime@plt>
    3172:	85 c0                	test   %eax,%eax
    3174:	75 52                	jne    31c8 <fwp_now_ns+0x78>
    3176:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    317b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3180:	48 f7 2c 24          	imulq  (%rsp)
    3184:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    318b:	48 89 f7             	mov    %rsi,%rdi
    318e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3192:	48 01 f0             	add    %rsi,%rax
    3195:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    319c:	00 00 80 
    319f:	48 11 fa             	adc    %rdi,%rdx
    31a2:	31 ff                	xor    %edi,%edi
    31a4:	48 01 c6             	add    %rax,%rsi
    31a7:	48 11 d7             	adc    %rdx,%rdi
    31aa:	48 39 f1             	cmp    %rsi,%rcx
    31ad:	48 19 fb             	sbb    %rdi,%rbx
    31b0:	72 27                	jb     31d9 <fwp_now_ns+0x89>
    31b2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    31b7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    31be:	00 00 
    31c0:	75 12                	jne    31d4 <fwp_now_ns+0x84>
    31c2:	48 83 c4 20          	add    $0x20,%rsp
    31c6:	5b                   	pop    %rbx
    31c7:	c3                   	ret
    31c8:	48 8d 3d 60 8e 00 00 	lea    0x8e60(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    31cf:	e8 4c ff ff ff       	call   3120 <fwp_trap>
    31d4:	e8 67 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31d9:	48 8d 3d c0 8f 00 00 	lea    0x8fc0(%rip),%rdi        # c1a0 <_IO_stdin_used+0x1a0>
    31e0:	e8 3b ff ff ff       	call   3120 <fwp_trap>
    31e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31ec:	00 00 00 00 

00000000000031f0 <fwp_args74>:
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	c3                   	ret
    31f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    31fc:	00 00 00 00 

0000000000003200 <fwp_format_g.constprop.0>:
    3200:	41 57                	push   %r15
    3202:	b9 40 00 00 00       	mov    $0x40,%ecx
    3207:	ba 02 00 00 00       	mov    $0x2,%edx
    320c:	4c 8d 05 38 8e 00 00 	lea    0x8e38(%rip),%r8        # c04b <_IO_stdin_used+0x4b>
    3213:	41 56                	push   %r14
    3215:	b8 01 00 00 00       	mov    $0x1,%eax
    321a:	41 55                	push   %r13
    321c:	41 54                	push   %r12
    321e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    3222:	55                   	push   %rbp
    3223:	45 89 e1             	mov    %r12d,%r9d
    3226:	53                   	push   %rbx
    3227:	48 89 fb             	mov    %rdi,%rbx
    322a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3231:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3238:	00 00 
    323a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3241:	00 
    3242:	41 89 f7             	mov    %esi,%r15d
    3245:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    324a:	be 40 00 00 00       	mov    $0x40,%esi
    324f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3254:	4c 89 f7             	mov    %r14,%rdi
    3257:	e8 34 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    325c:	be 65 00 00 00       	mov    $0x65,%esi
    3261:	4c 89 f7             	mov    %r14,%rdi
    3264:	e8 f7 f1 ff ff       	call   2460 <strchr@plt>
    3269:	31 f6                	xor    %esi,%esi
    326b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3270:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3274:	48 89 c5             	mov    %rax,%rbp
    3277:	e8 e4 f2 ff ff       	call   2560 <strtol@plt>
    327c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3281:	49 89 c0             	mov    %rax,%r8
    3284:	83 c0 05             	add    $0x5,%eax
    3287:	83 f8 15             	cmp    $0x15,%eax
    328a:	0f 87 f0 01 00 00    	ja     3480 <fwp_format_g.constprop.0+0x280>
    3290:	45 89 e5             	mov    %r12d,%r13d
    3293:	45 29 c5             	sub    %r8d,%r13d
    3296:	45 85 ed             	test   %r13d,%r13d
    3299:	0f 8e 21 01 00 00    	jle    33c0 <fwp_format_g.constprop.0+0x1c0>
    329f:	41 83 ff 01          	cmp    $0x1,%r15d
    32a3:	0f 84 17 01 00 00    	je     33c0 <fwp_format_g.constprop.0+0x1c0>
    32a9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    32ae:	31 d2                	xor    %edx,%edx
    32b0:	4d 63 df             	movslq %r15d,%r11
    32b3:	3c 2d                	cmp    $0x2d,%al
    32b5:	0f 94 c2             	sete   %dl
    32b8:	4c 29 dd             	sub    %r11,%rbp
    32bb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    32bf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    32c3:	4d 89 f1             	mov    %r14,%r9
    32c6:	4d 29 d1             	sub    %r10,%r9
    32c9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    32cd:	3c 2d                	cmp    $0x2d,%al
    32cf:	0f 84 0b 04 00 00    	je     36e0 <fwp_format_g.constprop.0+0x4e0>
    32d5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    32da:	b9 48 00 00 00       	mov    $0x48,%ecx
    32df:	48 89 e8             	mov    %rbp,%rax
    32e2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    32e6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    32ea:	49 83 c1 47          	add    $0x47,%r9
    32ee:	45 85 c0             	test   %r8d,%r8d
    32f1:	0f 88 01 03 00 00    	js     35f8 <fwp_format_g.constprop.0+0x3f8>
    32f7:	45 0f b6 12          	movzbl (%r10),%r10d
    32fb:	4d 63 e0             	movslq %r8d,%r12
    32fe:	44 88 10             	mov    %r10b,(%rax)
    3301:	41 83 f8 07          	cmp    $0x7,%r8d
    3305:	0f 87 3d 02 00 00    	ja     3548 <fwp_format_g.constprop.0+0x348>
    330b:	41 f6 c4 04          	test   $0x4,%r12b
    330f:	0f 85 02 04 00 00    	jne    3717 <fwp_format_g.constprop.0+0x517>
    3315:	45 85 e4             	test   %r12d,%r12d
    3318:	74 12                	je     332c <fwp_format_g.constprop.0+0x12c>
    331a:	45 0f b6 06          	movzbl (%r14),%r8d
    331e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    3322:	41 f6 c4 02          	test   $0x2,%r12b
    3326:	0f 85 13 04 00 00    	jne    373f <fwp_format_g.constprop.0+0x53f>
    332c:	4c 29 e1             	sub    %r12,%rcx
    332f:	4c 01 e7             	add    %r12,%rdi
    3332:	4c 89 fa             	mov    %r15,%rdx
    3335:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    333a:	48 83 e9 01          	sub    $0x1,%rcx
    333e:	4d 63 ed             	movslq %r13d,%r13
    3341:	48 89 0c 24          	mov    %rcx,(%rsp)
    3345:	e8 f6 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    334a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    334f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3353:	ba 48 00 00 00       	mov    $0x48,%edx
    3358:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    335c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3360:	4c 89 c8             	mov    %r9,%rax
    3363:	48 29 c8             	sub    %rcx,%rax
    3366:	48 39 d0             	cmp    %rdx,%rax
    3369:	48 0f 42 c2          	cmovb  %rdx,%rax
    336d:	4c 29 c9             	sub    %r9,%rcx
    3370:	4c 89 ea             	mov    %r13,%rdx
    3373:	48 01 c1             	add    %rax,%rcx
    3376:	e8 c5 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    337b:	4c 01 e8             	add    %r13,%rax
    337e:	48 29 e8             	sub    %rbp,%rax
    3381:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3386:	48 39 d0             	cmp    %rdx,%rax
    3389:	48 0f 47 c2          	cmova  %rdx,%rax
    338d:	89 c1                	mov    %eax,%ecx
    338f:	83 f8 08             	cmp    $0x8,%eax
    3392:	0f 83 28 02 00 00    	jae    35c0 <fwp_format_g.constprop.0+0x3c0>
    3398:	a8 04                	test   $0x4,%al
    339a:	0f 85 64 03 00 00    	jne    3704 <fwp_format_g.constprop.0+0x504>
    33a0:	85 c0                	test   %eax,%eax
    33a2:	74 0f                	je     33b3 <fwp_format_g.constprop.0+0x1b3>
    33a4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    33a9:	88 13                	mov    %dl,(%rbx)
    33ab:	a8 02                	test   $0x2,%al
    33ad:	0f 85 7b 03 00 00    	jne    372e <fwp_format_g.constprop.0+0x52e>
    33b3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33b7:	eb 36                	jmp    33ef <fwp_format_g.constprop.0+0x1ef>
    33b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    33c0:	45 31 c9             	xor    %r9d,%r9d
    33c3:	45 85 ed             	test   %r13d,%r13d
    33c6:	4c 8d 05 8d 8c 00 00 	lea    0x8c8d(%rip),%r8        # c05a <_IO_stdin_used+0x5a>
    33cd:	48 89 df             	mov    %rbx,%rdi
    33d0:	45 0f 49 cd          	cmovns %r13d,%r9d
    33d4:	ba 02 00 00 00       	mov    $0x2,%edx
    33d9:	be 90 01 00 00       	mov    $0x190,%esi
    33de:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    33e5:	b8 01 00 00 00       	mov    $0x1,%eax
    33ea:	e8 a1 ef ff ff       	call   2390 <__snprintf_chk@plt>
    33ef:	be 2e 00 00 00       	mov    $0x2e,%esi
    33f4:	48 89 df             	mov    %rbx,%rdi
    33f7:	e8 64 f0 ff ff       	call   2460 <strchr@plt>
    33fc:	48 85 c0             	test   %rax,%rax
    33ff:	74 4f                	je     3450 <fwp_format_g.constprop.0+0x250>
    3401:	48 89 df             	mov    %rbx,%rdi
    3404:	e8 27 f0 ff ff       	call   2430 <strlen@plt>
    3409:	48 85 c0             	test   %rax,%rax
    340c:	75 1b                	jne    3429 <fwp_format_g.constprop.0+0x229>
    340e:	eb 40                	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3410:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    341c:	00 00 00 00 
    3420:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3424:	48 85 c0             	test   %rax,%rax
    3427:	74 27                	je     3450 <fwp_format_g.constprop.0+0x250>
    3429:	48 89 c2             	mov    %rax,%rdx
    342c:	48 83 e8 01          	sub    $0x1,%rax
    3430:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    3434:	74 ea                	je     3420 <fwp_format_g.constprop.0+0x220>
    3436:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    343b:	0f 84 6f 01 00 00    	je     35b0 <fwp_format_g.constprop.0+0x3b0>
    3441:	0f 1f 40 00          	nopl   0x0(%rax)
    3445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    344c:	00 00 00 00 
    3450:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3457:	00 
    3458:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    345f:	00 00 
    3461:	0f 85 ec 02 00 00    	jne    3753 <fwp_format_g.constprop.0+0x553>
    3467:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    346e:	5b                   	pop    %rbx
    346f:	5d                   	pop    %rbp
    3470:	41 5c                	pop    %r12
    3472:	41 5d                	pop    %r13
    3474:	41 5e                	pop    %r14
    3476:	41 5f                	pop    %r15
    3478:	c3                   	ret
    3479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3480:	4c 29 f5             	sub    %r14,%rbp
    3483:	b9 40 00 00 00       	mov    $0x40,%ecx
    3488:	4c 89 f6             	mov    %r14,%rsi
    348b:	4c 89 04 24          	mov    %r8,(%rsp)
    348f:	49 89 ec             	mov    %rbp,%r12
    3492:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3497:	4c 89 e2             	mov    %r12,%rdx
    349a:	48 89 ef             	mov    %rbp,%rdi
    349d:	e8 9e f0 ff ff       	call   2540 <__memcpy_chk@plt>
    34a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    34a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    34ad:	48 89 ef             	mov    %rbp,%rdi
    34b0:	e8 ab ef ff ff       	call   2460 <strchr@plt>
    34b5:	4c 8b 04 24          	mov    (%rsp),%r8
    34b9:	48 85 c0             	test   %rax,%rax
    34bc:	74 40                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34be:	4d 85 e4             	test   %r12,%r12
    34c1:	74 3b                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    34c8:	eb 23                	jmp    34ed <fwp_format_g.constprop.0+0x2ed>
    34ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34d1:	00 00 00 00 
    34d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    34dc:	00 00 00 00 
    34e0:	c6 00 00             	movb   $0x0,(%rax)
    34e3:	48 83 e8 01          	sub    $0x1,%rax
    34e7:	49 83 ec 01          	sub    $0x1,%r12
    34eb:	74 11                	je     34fe <fwp_format_g.constprop.0+0x2fe>
    34ed:	80 38 30             	cmpb   $0x30,(%rax)
    34f0:	74 ee                	je     34e0 <fwp_format_g.constprop.0+0x2e0>
    34f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    34f8:	0f 84 fb 01 00 00    	je     36f9 <fwp_format_g.constprop.0+0x4f9>
    34fe:	44 89 c0             	mov    %r8d,%eax
    3501:	ba 02 00 00 00       	mov    $0x2,%edx
    3506:	49 89 e9             	mov    %rbp,%r9
    3509:	be 90 01 00 00       	mov    $0x190,%esi
    350e:	f7 d8                	neg    %eax
    3510:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3517:	48 89 df             	mov    %rbx,%rdi
    351a:	41 0f 48 c0          	cmovs  %r8d,%eax
    351e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    3522:	41 83 e0 02          	and    $0x2,%r8d
    3526:	41 83 c0 2b          	add    $0x2b,%r8d
    352a:	50                   	push   %rax
    352b:	31 c0                	xor    %eax,%eax
    352d:	41 50                	push   %r8
    352f:	4c 8d 05 1a 8b 00 00 	lea    0x8b1a(%rip),%r8        # c050 <_IO_stdin_used+0x50>
    3536:	e8 55 ee ff ff       	call   2390 <__snprintf_chk@plt>
    353b:	58                   	pop    %rax
    353c:	5a                   	pop    %rdx
    353d:	e9 0e ff ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    3542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3548:	4d 8b 06             	mov    (%r14),%r8
    354b:	48 83 c0 09          	add    $0x9,%rax
    354f:	4c 89 f2             	mov    %r14,%rdx
    3552:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3556:	4c 89 07             	mov    %r8,(%rdi)
    3559:	45 89 e0             	mov    %r12d,%r8d
    355c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3561:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3566:	49 89 f8             	mov    %rdi,%r8
    3569:	49 29 c0             	sub    %rax,%r8
    356c:	4c 29 c2             	sub    %r8,%rdx
    356f:	45 01 e0             	add    %r12d,%r8d
    3572:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3576:	41 83 f8 08          	cmp    $0x8,%r8d
    357a:	0f 82 ac fd ff ff    	jb     332c <fwp_format_g.constprop.0+0x12c>
    3580:	48 89 0c 24          	mov    %rcx,(%rsp)
    3584:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3588:	45 31 d2             	xor    %r10d,%r10d
    358b:	45 89 d3             	mov    %r10d,%r11d
    358e:	41 83 c2 08          	add    $0x8,%r10d
    3592:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3596:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    359a:	45 39 c2             	cmp    %r8d,%r10d
    359d:	72 ec                	jb     358b <fwp_format_g.constprop.0+0x38b>
    359f:	48 8b 0c 24          	mov    (%rsp),%rcx
    35a3:	e9 84 fd ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    35a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    35af:	00 
    35b0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    35b5:	e9 96 fe ff ff       	jmp    3450 <fwp_format_g.constprop.0+0x250>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    35c0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    35c5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    35c9:	48 89 ee             	mov    %rbp,%rsi
    35cc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    35d0:	48 89 13             	mov    %rdx,(%rbx)
    35d3:	89 c2                	mov    %eax,%edx
    35d5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    35da:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    35df:	48 89 d9             	mov    %rbx,%rcx
    35e2:	48 29 f9             	sub    %rdi,%rcx
    35e5:	48 29 ce             	sub    %rcx,%rsi
    35e8:	01 c1                	add    %eax,%ecx
    35ea:	c1 e9 03             	shr    $0x3,%ecx
    35ed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    35f0:	e9 be fd ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    35f5:	0f 1f 00             	nopl   (%rax)
    35f8:	c6 00 30             	movb   $0x30,(%rax)
    35fb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    35ff:	4c 89 fa             	mov    %r15,%rdx
    3602:	4c 89 e9             	mov    %r13,%rcx
    3605:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    360a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    360f:	4c 89 14 24          	mov    %r10,(%rsp)
    3613:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3618:	e8 23 ef ff ff       	call   2540 <__memcpy_chk@plt>
    361d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    3622:	b9 48 00 00 00       	mov    $0x48,%ecx
    3627:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    362c:	48 89 c7             	mov    %rax,%rdi
    362f:	4c 8b 14 24          	mov    (%rsp),%r10
    3633:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    3638:	4c 89 c8             	mov    %r9,%rax
    363b:	4c 29 e8             	sub    %r13,%rax
    363e:	48 39 c8             	cmp    %rcx,%rax
    3641:	48 0f 42 c1          	cmovb  %rcx,%rax
    3645:	4d 29 cd             	sub    %r9,%r13
    3648:	49 01 ff             	add    %rdi,%r15
    364b:	4c 01 e8             	add    %r13,%rax
    364e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3652:	74 3d                	je     3691 <fwp_format_g.constprop.0+0x491>
    3654:	41 f7 d0             	not    %r8d
    3657:	31 f6                	xor    %esi,%esi
    3659:	ba 48 00 00 00       	mov    $0x48,%edx
    365e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3663:	48 39 d0             	cmp    %rdx,%rax
    3666:	48 0f 43 d0          	cmovae %rax,%rdx
    366a:	48 89 d1             	mov    %rdx,%rcx
    366d:	48 29 c1             	sub    %rax,%rcx
    3670:	48 83 c1 01          	add    $0x1,%rcx
    3674:	48 39 d1             	cmp    %rdx,%rcx
    3677:	48 0f 42 ca          	cmovb  %rdx,%rcx
    367b:	48 83 e8 01          	sub    $0x1,%rax
    367f:	48 83 c6 01          	add    $0x1,%rsi
    3683:	48 29 d0             	sub    %rdx,%rax
    3686:	48 01 c8             	add    %rcx,%rax
    3689:	41 39 f0             	cmp    %esi,%r8d
    368c:	7f cb                	jg     3659 <fwp_format_g.constprop.0+0x459>
    368e:	4d 01 c7             	add    %r8,%r15
    3691:	b9 48 00 00 00       	mov    $0x48,%ecx
    3696:	41 0f b6 12          	movzbl (%r10),%edx
    369a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    369e:	4c 89 f6             	mov    %r14,%rsi
    36a1:	48 39 c8             	cmp    %rcx,%rax
    36a4:	4c 89 1c 24          	mov    %r11,(%rsp)
    36a8:	48 0f 43 c8          	cmovae %rax,%rcx
    36ac:	41 88 17             	mov    %dl,(%r15)
    36af:	48 89 ca             	mov    %rcx,%rdx
    36b2:	48 29 c2             	sub    %rax,%rdx
    36b5:	48 83 c2 01          	add    $0x1,%rdx
    36b9:	48 39 ca             	cmp    %rcx,%rdx
    36bc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    36c0:	48 83 e8 01          	sub    $0x1,%rax
    36c4:	48 29 c8             	sub    %rcx,%rax
    36c7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    36cb:	49 63 d4             	movslq %r12d,%rdx
    36ce:	e8 6d ee ff ff       	call   2540 <__memcpy_chk@plt>
    36d3:	4c 8b 1c 24          	mov    (%rsp),%r11
    36d7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    36db:	e9 9e fc ff ff       	jmp    337e <fwp_format_g.constprop.0+0x17e>
    36e0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    36e5:	b9 47 00 00 00       	mov    $0x47,%ecx
    36ea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    36ef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    36f4:	e9 e9 fb ff ff       	jmp    32e2 <fwp_format_g.constprop.0+0xe2>
    36f9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    36ff:	e9 fa fd ff ff       	jmp    34fe <fwp_format_g.constprop.0+0x2fe>
    3704:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3708:	89 13                	mov    %edx,(%rbx)
    370a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    370e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3712:	e9 9c fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    3717:	41 8b 06             	mov    (%r14),%eax
    371a:	89 07                	mov    %eax,(%rdi)
    371c:	44 89 e0             	mov    %r12d,%eax
    371f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    3724:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    3729:	e9 fe fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    372e:	89 c2                	mov    %eax,%edx
    3730:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    3735:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    373a:	e9 74 fc ff ff       	jmp    33b3 <fwp_format_g.constprop.0+0x1b3>
    373f:	44 89 e0             	mov    %r12d,%eax
    3742:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3748:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    374e:	e9 d9 fb ff ff       	jmp    332c <fwp_format_g.constprop.0+0x12c>
    3753:	e8 e8 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    375f:	00 

0000000000003760 <fwp_heap_report>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	41 54                	push   %r12
    3766:	48 8d 3d f2 88 00 00 	lea    0x88f2(%rip),%rdi        # c05f <_IO_stdin_used+0x5f>
    376d:	55                   	push   %rbp
    376e:	53                   	push   %rbx
    376f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3776:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    377d:	00 00 
    377f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3786:	00 
    3787:	48 8d 35 93 89 00 00 	lea    0x8993(%rip),%rsi        # c121 <_IO_stdin_used+0x121>
    378e:	e8 5d ee ff ff       	call   25f0 <fopen@plt>
    3793:	48 85 c0             	test   %rax,%rax
    3796:	0f 84 c5 00 00 00    	je     3861 <fwp_heap_report+0x101>
    379c:	48 89 c5             	mov    %rax,%rbp
    379f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37a6:	48 89 e3             	mov    %rsp,%rbx
    37a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    37b0:	48 89 ea             	mov    %rbp,%rdx
    37b3:	be 00 01 00 00       	mov    $0x100,%esi
    37b8:	48 89 df             	mov    %rbx,%rdi
    37bb:	e8 20 ed ff ff       	call   24e0 <fgets@plt>
    37c0:	48 85 c0             	test   %rax,%rax
    37c3:	74 2b                	je     37f0 <fwp_heap_report+0x90>
    37c5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    37cb:	75 e3                	jne    37b0 <fwp_heap_report+0x50>
    37cd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    37d1:	75 dd                	jne    37b0 <fwp_heap_report+0x50>
    37d3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    37d8:	75 d6                	jne    37b0 <fwp_heap_report+0x50>
    37da:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    37df:	ba 0a 00 00 00       	mov    $0xa,%edx
    37e4:	31 f6                	xor    %esi,%esi
    37e6:	e8 75 ed ff ff       	call   2560 <strtol@plt>
    37eb:	49 89 c4             	mov    %rax,%r12
    37ee:	eb c0                	jmp    37b0 <fwp_heap_report+0x50>
    37f0:	48 89 ef             	mov    %rbp,%rdi
    37f3:	e8 28 ec ff ff       	call   2420 <fclose@plt>
    37f8:	48 83 ec 08          	sub    $0x8,%rsp
    37fc:	4c 8b 0d a5 d2 01 00 	mov    0x1d2a5(%rip),%r9        # 20aa8 <fwp_heap+0x13c8>
    3803:	4c 8b 05 fe d2 01 00 	mov    0x1d2fe(%rip),%r8        # 20b08 <fwp_heap+0x1428>
    380a:	48 8d 15 bf 89 00 00 	lea    0x89bf(%rip),%rdx        # c1d0 <_IO_stdin_used+0x1d0>
    3811:	41 54                	push   %r12
    3813:	48 8b 0d e6 d2 01 00 	mov    0x1d2e6(%rip),%rcx        # 20b00 <fwp_heap+0x1420>
    381a:	be 02 00 00 00       	mov    $0x2,%esi
    381f:	b8 02 00 00 00       	mov    $0x2,%eax
    3824:	f2 0f 10 0d f4 d2 01 	movsd  0x1d2f4(%rip),%xmm1        # 20b20 <fwp_heap+0x1440>
    382b:	00 
    382c:	f2 0f 10 05 e4 d2 01 	movsd  0x1d2e4(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    3833:	00 
    3834:	48 8b 3d 05 b8 00 00 	mov    0xb805(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    383b:	e8 10 ee ff ff       	call   2650 <__fprintf_chk@plt>
    3840:	58                   	pop    %rax
    3841:	5a                   	pop    %rdx
    3842:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3849:	00 
    384a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3851:	00 00 
    3853:	75 15                	jne    386a <fwp_heap_report+0x10a>
    3855:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    385c:	5b                   	pop    %rbx
    385d:	5d                   	pop    %rbp
    385e:	41 5c                	pop    %r12
    3860:	c3                   	ret
    3861:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3868:	eb 8e                	jmp    37f8 <fwp_heap_report+0x98>
    386a:	e8 d1 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    386f:	90                   	nop

0000000000003870 <fwp_heap_init>:
    3870:	66 0f 6f 05 28 8c 00 	movdqa 0x8c28(%rip),%xmm0        # c4a0 <msg.3+0x50>
    3877:	00 
    3878:	41 54                	push   %r12
    387a:	48 8d 05 9f cd 01 00 	lea    0x1cd9f(%rip),%rax        # 20620 <fwp_heap+0xf40>
    3881:	ba 00 01 00 00       	mov    $0x100,%edx
    3886:	55                   	push   %rbp
    3887:	66 0f 6f 15 51 8c 00 	movdqa 0x8c51(%rip),%xmm2        # c4e0 <msg.3+0x90>
    388e:	00 
    388f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3893:	53                   	push   %rbx
    3894:	0f 29 05 45 cd 01 00 	movaps %xmm0,0x1cd45(%rip)        # 205e0 <fwp_heap+0xf00>
    389b:	66 0f 6f 05 0d 8c 00 	movdqa 0x8c0d(%rip),%xmm0        # c4b0 <msg.3+0x60>
    38a2:	00 
    38a3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    38a7:	c7 05 d3 d1 01 00 01 	movl   $0x1,0x1d1d3(%rip)        # 20a84 <fwp_heap+0x13a4>
    38ae:	00 00 00 
    38b1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    38b6:	0f 29 05 33 cd 01 00 	movaps %xmm0,0x1cd33(%rip)        # 205f0 <fwp_heap+0xf10>
    38bd:	66 0f 6f 05 fb 8b 00 	movdqa 0x8bfb(%rip),%xmm0        # c4c0 <msg.3+0x70>
    38c4:	00 
    38c5:	0f 29 05 34 cd 01 00 	movaps %xmm0,0x1cd34(%rip)        # 20600 <fwp_heap+0xf20>
    38cc:	66 0f 6f 05 fc 8b 00 	movdqa 0x8bfc(%rip),%xmm0        # c4d0 <msg.3+0x80>
    38d3:	00 
    38d4:	0f 29 05 35 cd 01 00 	movaps %xmm0,0x1cd35(%rip)        # 20610 <fwp_heap+0xf30>
    38db:	89 d3                	mov    %edx,%ebx
    38dd:	66 0f 6e e2          	movd   %edx,%xmm4
    38e1:	48 83 c0 10          	add    $0x10,%rax
    38e5:	01 d2                	add    %edx,%edx
    38e7:	c1 eb 02             	shr    $0x2,%ebx
    38ea:	66 0f 6e c3          	movd   %ebx,%xmm0
    38ee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    38f3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    38f7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    38fc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3900:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3904:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3909:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    390e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3912:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3917:	66 0f fe c1          	paddd  %xmm1,%xmm0
    391b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    391f:	48 39 c7             	cmp    %rax,%rdi
    3922:	75 b7                	jne    38db <fwp_heap_init+0x6b>
    3924:	4c 8d 05 b5 bd 01 00 	lea    0x1bdb5(%rip),%r8        # 1f6e0 <fwp_heap>
    392b:	31 c9                	xor    %ecx,%ecx
    392d:	31 c0                	xor    %eax,%eax
    392f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 
    3940:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3947:	00 
    3948:	48 39 ca             	cmp    %rcx,%rdx
    394b:	73 0f                	jae    395c <fwp_heap_init+0xec>
    394d:	0f 1f 00             	nopl   (%rax)
    3950:	48 83 c0 01          	add    $0x1,%rax
    3954:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3957:	48 39 ca             	cmp    %rcx,%rdx
    395a:	72 f4                	jb     3950 <fwp_heap_init+0xe0>
    395c:	48 83 c1 10          	add    $0x10,%rcx
    3960:	88 07                	mov    %al,(%rdi)
    3962:	48 83 c7 01          	add    $0x1,%rdi
    3966:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    396d:	75 d1                	jne    3940 <fwp_heap_init+0xd0>
    396f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3976:	00 00 00 
    3979:	bd 05 00 00 00       	mov    $0x5,%ebp
    397e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3985:	45 31 c9             	xor    %r9d,%r9d
    3988:	31 d2                	xor    %edx,%edx
    398a:	31 ff                	xor    %edi,%edi
    398c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3992:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3997:	4c 89 e6             	mov    %r12,%rsi
    399a:	e8 b1 ea ff ff       	call   2450 <mmap@plt>
    399f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    39a3:	75 13                	jne    39b8 <fwp_heap_init+0x148>
    39a5:	48 c1 eb 02          	shr    $0x2,%rbx
    39a9:	83 ed 01             	sub    $0x1,%ebp
    39ac:	75 d0                	jne    397e <fwp_heap_init+0x10e>
    39ae:	e8 bd f2 ff ff       	call   2c70 <fwp_heap_oom>
    39b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    39b8:	48 85 c0             	test   %rax,%rax
    39bb:	74 f1                	je     39ae <fwp_heap_init+0x13e>
    39bd:	48 c1 eb 10          	shr    $0x10,%rbx
    39c1:	48 89 05 d0 d0 01 00 	mov    %rax,0x1d0d0(%rip)        # 20a98 <fwp_heap+0x13b8>
    39c8:	45 31 c9             	xor    %r9d,%r9d
    39cb:	31 d2                	xor    %edx,%edx
    39cd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    39d3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    39d7:	31 ff                	xor    %edi,%edi
    39d9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    39df:	66 31 c0             	xor    %ax,%ax
    39e2:	48 c1 e6 03          	shl    $0x3,%rsi
    39e6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    39eb:	4c 89 25 ae d0 01 00 	mov    %r12,0x1d0ae(%rip)        # 20aa0 <fwp_heap+0x13c0>
    39f2:	48 89 05 97 d0 01 00 	mov    %rax,0x1d097(%rip)        # 20a90 <fwp_heap+0x13b0>
    39f9:	48 89 1d b0 d0 01 00 	mov    %rbx,0x1d0b0(%rip)        # 20ab0 <fwp_heap+0x13d0>
    3a00:	48 89 35 d9 d0 01 00 	mov    %rsi,0x1d0d9(%rip)        # 20ae0 <fwp_heap+0x1400>
    3a07:	e8 44 ea ff ff       	call   2450 <mmap@plt>
    3a0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a10:	74 9c                	je     39ae <fwp_heap_init+0x13e>
    3a12:	48 8d 3d 7c 86 00 00 	lea    0x867c(%rip),%rdi        # c095 <_IO_stdin_used+0x95>
    3a19:	48 89 05 b8 d0 01 00 	mov    %rax,0x1d0b8(%rip)        # 20ad8 <fwp_heap+0x13f8>
    3a20:	e8 5b e9 ff ff       	call   2380 <getenv@plt>
    3a25:	48 89 c2             	mov    %rax,%rdx
    3a28:	31 c0                	xor    %eax,%eax
    3a2a:	48 85 d2             	test   %rdx,%rdx
    3a2d:	74 15                	je     3a44 <fwp_heap_init+0x1d4>
    3a2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    3a32:	74 10                	je     3a44 <fwp_heap_init+0x1d4>
    3a34:	0f b6 02             	movzbl (%rdx),%eax
    3a37:	83 e8 30             	sub    $0x30,%eax
    3a3a:	74 13                	je     3a4f <fwp_heap_init+0x1df>
    3a3c:	85 c0                	test   %eax,%eax
    3a3e:	0f 95 c0             	setne  %al
    3a41:	0f b6 c0             	movzbl %al,%eax
    3a44:	5b                   	pop    %rbx
    3a45:	5d                   	pop    %rbp
    3a46:	89 05 3c d0 01 00    	mov    %eax,0x1d03c(%rip)        # 20a88 <fwp_heap+0x13a8>
    3a4c:	41 5c                	pop    %r12
    3a4e:	c3                   	ret
    3a4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3a53:	85 c0                	test   %eax,%eax
    3a55:	0f 95 c0             	setne  %al
    3a58:	0f b6 c0             	movzbl %al,%eax
    3a5b:	eb e7                	jmp    3a44 <fwp_heap_init+0x1d4>
    3a5d:	0f 1f 00             	nopl   (%rax)

0000000000003a60 <fwp_args45>:
    3a60:	f3 0f 1e fa          	endbr64
    3a64:	c3                   	ret
    3a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a6c:	00 00 00 00 

0000000000003a70 <fwp_args69>:
    3a70:	f3 0f 1e fa          	endbr64
    3a74:	c3                   	ret
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 

0000000000003a80 <fwp_wake_io>:
    3a80:	48 8b 07             	mov    (%rdi),%rax
    3a83:	48 85 c0             	test   %rax,%rax
    3a86:	0f 84 f4 00 00 00    	je     3b80 <fwp_wake_io+0x100>
    3a8c:	53                   	push   %rbx
    3a8d:	4c 8b 05 0c bc 01 00 	mov    0x1bc0c(%rip),%r8        # 1f6a0 <fwp_ready_tail>
    3a94:	49 89 f9             	mov    %rdi,%r9
    3a97:	48 89 c2             	mov    %rax,%rdx
    3a9a:	45 31 db             	xor    %r11d,%r11d
    3a9d:	45 31 d2             	xor    %r10d,%r10d
    3aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3aa4:	eb 71                	jmp    3b17 <fwp_wake_io+0x97>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3ab7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3abe:	48 85 c9             	test   %rcx,%rcx
    3ac1:	74 07                	je     3aca <fwp_wake_io+0x4a>
    3ac3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3aca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3ad1:	00 00 00 00 
    3ad5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3adc:	49 8b 01             	mov    (%r9),%rax
    3adf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ae3:	75 2a                	jne    3b0f <fwp_wake_io+0x8f>
    3ae5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3ae9:	75 24                	jne    3b0f <fwp_wake_io+0x8f>
    3aeb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3aef:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3af6:	00 00 00 00 
    3afa:	4d 85 c0             	test   %r8,%r8
    3afd:	74 51                	je     3b50 <fwp_wake_io+0xd0>
    3aff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3b06:	49 89 d0             	mov    %rdx,%r8
    3b09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3b0f:	48 89 c2             	mov    %rax,%rdx
    3b12:	48 85 c0             	test   %rax,%rax
    3b15:	74 49                	je     3b60 <fwp_wake_io+0xe0>
    3b17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3b1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3b22:	48 85 ff             	test   %rdi,%rdi
    3b25:	74 b8                	je     3adf <fwp_wake_io+0x5f>
    3b27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3b2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b35:	48 85 f6             	test   %rsi,%rsi
    3b38:	0f 85 72 ff ff ff    	jne    3ab0 <fwp_wake_io+0x30>
    3b3e:	48 89 0f             	mov    %rcx,(%rdi)
    3b41:	e9 78 ff ff ff       	jmp    3abe <fwp_wake_io+0x3e>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 d3             	mov    %rdx,%rbx
    3b53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3b59:	eb ab                	jmp    3b06 <fwp_wake_io+0x86>
    3b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3b60:	45 84 db             	test   %r11b,%r11b
    3b63:	74 07                	je     3b6c <fwp_wake_io+0xec>
    3b65:	48 89 1d 3c bb 01 00 	mov    %rbx,0x1bb3c(%rip)        # 1f6a8 <fwp_ready_head>
    3b6c:	45 84 d2             	test   %r10b,%r10b
    3b6f:	74 07                	je     3b78 <fwp_wake_io+0xf8>
    3b71:	4c 89 05 28 bb 01 00 	mov    %r8,0x1bb28(%rip)        # 1f6a0 <fwp_ready_tail>
    3b78:	5b                   	pop    %rbx
    3b79:	c3                   	ret
    3b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3b80:	c3                   	ret
    3b81:	0f 1f 40 00          	nopl   0x0(%rax)
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_poll_events>:
    3b90:	53                   	push   %rbx
    3b91:	48 83 ec 20          	sub    $0x20,%rsp
    3b95:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3b9c:	00 00 
    3b9e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3ba3:	31 c0                	xor    %eax,%eax
    3ba5:	e8 a6 f5 ff ff       	call   3150 <fwp_now_ns>
    3baa:	48 8b 1d e7 ba 01 00 	mov    0x1bae7(%rip),%rbx        # 1f698 <fwp_timers>
    3bb1:	48 85 db             	test   %rbx,%rbx
    3bb4:	0f 84 e6 00 00 00    	je     3ca0 <fwp_poll_events+0x110>
    3bba:	48 89 c6             	mov    %rax,%rsi
    3bbd:	48 89 da             	mov    %rbx,%rdx
    3bc0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3bc7:	eb 26                	jmp    3bef <fwp_poll_events+0x5f>
    3bc9:	90                   	nop
    3bca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bd1:	00 00 00 00 
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 
    3be0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3be7:	48 89 c8             	mov    %rcx,%rax
    3bea:	48 85 d2             	test   %rdx,%rdx
    3bed:	74 31                	je     3c20 <fwp_poll_events+0x90>
    3bef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3bf3:	48 85 c0             	test   %rax,%rax
    3bf6:	78 e8                	js     3be0 <fwp_poll_events+0x50>
    3bf8:	48 39 c1             	cmp    %rax,%rcx
    3bfb:	7c e3                	jl     3be0 <fwp_poll_events+0x50>
    3bfd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 1c                	je     3c25 <fwp_poll_events+0x95>
    3c09:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c0d:	48 39 c1             	cmp    %rax,%rcx
    3c10:	7c ce                	jl     3be0 <fwp_poll_events+0x50>
    3c12:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c19:	48 85 d2             	test   %rdx,%rdx
    3c1c:	75 d1                	jne    3bef <fwp_poll_events+0x5f>
    3c1e:	66 90                	xchg   %ax,%ax
    3c20:	48 85 c0             	test   %rax,%rax
    3c23:	78 7b                	js     3ca0 <fwp_poll_events+0x110>
    3c25:	48 29 f0             	sub    %rsi,%rax
    3c28:	48 89 c1             	mov    %rax,%rcx
    3c2b:	48 85 c0             	test   %rax,%rax
    3c2e:	0f 8e 9c 00 00 00    	jle    3cd0 <fwp_poll_events+0x140>
    3c34:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3c3b:	de 1b 43 
    3c3e:	48 f7 ea             	imul   %rdx
    3c41:	48 89 c8             	mov    %rcx,%rax
    3c44:	48 c1 f8 3f          	sar    $0x3f,%rax
    3c48:	48 c1 fa 12          	sar    $0x12,%rdx
    3c4c:	48 29 c2             	sub    %rax,%rdx
    3c4f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3c56:	48 39 c1             	cmp    %rax,%rcx
    3c59:	0f 95 c0             	setne  %al
    3c5c:	0f b6 c0             	movzbl %al,%eax
    3c5f:	48 01 d0             	add    %rdx,%rax
    3c62:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3c68:	0f 8f 32 01 00 00    	jg     3da0 <fwp_poll_events+0x210>
    3c6e:	48 85 c0             	test   %rax,%rax
    3c71:	74 5d                	je     3cd0 <fwp_poll_events+0x140>
    3c73:	89 c1                	mov    %eax,%ecx
    3c75:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3c7c:	48 c1 e9 26          	shr    $0x26,%rcx
    3c80:	48 63 d1             	movslq %ecx,%rdx
    3c83:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3c89:	29 c8                	sub    %ecx,%eax
    3c8b:	48 98                	cltq
    3c8d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3c94:	e9 11 01 00 00       	jmp    3daa <fwp_poll_events+0x21a>
    3c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ca0:	e8 8b ef ff ff       	call   2c30 <fwp_flush>
    3ca5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3caa:	be 01 00 00 00       	mov    $0x1,%esi
    3caf:	48 8b 0d 8a b3 00 00 	mov    0xb38a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cb6:	48 8d 3d 9b 85 00 00 	lea    0x859b(%rip),%rdi        # c258 <_IO_stdin_used+0x258>
    3cbd:	e8 7e e9 ff ff       	call   2640 <fwrite@plt>
    3cc2:	bf 65 00 00 00       	mov    $0x65,%edi
    3cc7:	e8 64 e9 ff ff       	call   2630 <exit@plt>
    3ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    3cd0:	e8 7b f4 ff ff       	call   3150 <fwp_now_ns>
    3cd5:	48 89 c1             	mov    %rax,%rcx
    3cd8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3cdc:	eb 44                	jmp    3d22 <fwp_poll_events+0x192>
    3cde:	66 90                	xchg   %ax,%ax
    3ce0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3ce4:	75 33                	jne    3d19 <fwp_poll_events+0x189>
    3ce6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cea:	75 2d                	jne    3d19 <fwp_poll_events+0x189>
    3cec:	48 8b 05 ad b9 01 00 	mov    0x1b9ad(%rip),%rax        # 1f6a0 <fwp_ready_tail>
    3cf3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3cf7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3cfe:	00 00 00 00 
    3d02:	48 85 c0             	test   %rax,%rax
    3d05:	0f 84 05 01 00 00    	je     3e10 <fwp_poll_events+0x280>
    3d0b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3d12:	48 89 15 87 b9 01 00 	mov    %rdx,0x1b987(%rip)        # 1f6a0 <fwp_ready_tail>
    3d19:	48 85 db             	test   %rbx,%rbx
    3d1c:	0f 84 be 00 00 00    	je     3de0 <fwp_poll_events+0x250>
    3d22:	48 89 da             	mov    %rbx,%rdx
    3d25:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3d2c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3d30:	7f e7                	jg     3d19 <fwp_poll_events+0x189>
    3d32:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3d36:	74 2e                	je     3d66 <fwp_poll_events+0x1d6>
    3d38:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	0f 84 b8 00 00 00    	je     3e00 <fwp_poll_events+0x270>
    3d48:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3d4f:	48 85 db             	test   %rbx,%rbx
    3d52:	74 07                	je     3d5b <fwp_poll_events+0x1cb>
    3d54:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3d5b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3d5f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3d66:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3d6a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3d6e:	48 85 c0             	test   %rax,%rax
    3d71:	0f 84 69 ff ff ff    	je     3ce0 <fwp_poll_events+0x150>
    3d77:	48 39 c8             	cmp    %rcx,%rax
    3d7a:	0f 8f 60 ff ff ff    	jg     3ce0 <fwp_poll_events+0x150>
    3d80:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3d84:	0f 85 56 ff ff ff    	jne    3ce0 <fwp_poll_events+0x150>
    3d8a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8e:	75 89                	jne    3d19 <fwp_poll_events+0x189>
    3d90:	48 89 d7             	mov    %rdx,%rdi
    3d93:	e8 98 f2 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    3d98:	e9 43 ff ff ff       	jmp    3ce0 <fwp_poll_events+0x150>
    3d9d:	0f 1f 00             	nopl   (%rax)
    3da0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3da5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3daa:	48 89 e7             	mov    %rsp,%rdi
    3dad:	31 f6                	xor    %esi,%esi
    3daf:	48 89 14 24          	mov    %rdx,(%rsp)
    3db3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3db8:	e8 c3 e6 ff ff       	call   2480 <nanosleep@plt>
    3dbd:	48 8b 1d d4 b8 01 00 	mov    0x1b8d4(%rip),%rbx        # 1f698 <fwp_timers>
    3dc4:	e8 87 f3 ff ff       	call   3150 <fwp_now_ns>
    3dc9:	48 89 c1             	mov    %rax,%rcx
    3dcc:	48 85 db             	test   %rbx,%rbx
    3dcf:	0f 85 03 ff ff ff    	jne    3cd8 <fwp_poll_events+0x148>
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 
    3de0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3de5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3dec:	00 00 
    3dee:	75 2c                	jne    3e1c <fwp_poll_events+0x28c>
    3df0:	48 83 c4 20          	add    $0x20,%rsp
    3df4:	5b                   	pop    %rbx
    3df5:	c3                   	ret
    3df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3dfd:	00 00 00 
    3e00:	48 89 1d 91 b8 01 00 	mov    %rbx,0x1b891(%rip)        # 1f698 <fwp_timers>
    3e07:	e9 43 ff ff ff       	jmp    3d4f <fwp_poll_events+0x1bf>
    3e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3e10:	48 89 15 91 b8 01 00 	mov    %rdx,0x1b891(%rip)        # 1f6a8 <fwp_ready_head>
    3e17:	e9 f6 fe ff ff       	jmp    3d12 <fwp_poll_events+0x182>
    3e1c:	e8 1f e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3e21:	0f 1f 40 00          	nopl   0x0(%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_rc_wide_dup>:
    3e30:	48 89 fa             	mov    %rdi,%rdx
    3e33:	48 8d 35 a6 b8 01 00 	lea    0x1b8a6(%rip),%rsi        # 1f6e0 <fwp_heap>
    3e3a:	48 83 ec 18          	sub    $0x18,%rsp
    3e3e:	48 89 f9             	mov    %rdi,%rcx
    3e41:	48 c1 ea 11          	shr    $0x11,%rdx
    3e45:	48 31 fa             	xor    %rdi,%rdx
    3e48:	48 89 d0             	mov    %rdx,%rax
    3e4b:	48 c1 e8 09          	shr    $0x9,%rax
    3e4f:	48 31 c2             	xor    %rax,%rdx
    3e52:	0f b6 d2             	movzbl %dl,%edx
    3e55:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    3e5c:	00 
    3e5d:	49 8b 00             	mov    (%r8),%rax
    3e60:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    3e67:	00 00 
    3e69:	75 21                	jne    3e8c <fwp_rc_wide_dup+0x5c>
    3e6b:	e9 98 00 00 00       	jmp    3f08 <fwp_rc_wide_dup+0xd8>
    3e70:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3e84:	48 85 d2             	test   %rdx,%rdx
    3e87:	74 2f                	je     3eb8 <fwp_rc_wide_dup+0x88>
    3e89:	48 89 d0             	mov    %rdx,%rax
    3e8c:	48 3b 08             	cmp    (%rax),%rcx
    3e8f:	75 ef                	jne    3e80 <fwp_rc_wide_dup+0x50>
    3e91:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3e94:	74 7c                	je     3f12 <fwp_rc_wide_dup+0xe2>
    3e96:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3e9a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    3e9e:	0f 84 91 00 00 00    	je     3f35 <fwp_rc_wide_dup+0x105>
    3ea4:	48 83 c2 01          	add    $0x1,%rdx
    3ea8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    3eac:	48 83 c4 18          	add    $0x18,%rsp
    3eb0:	c3                   	ret
    3eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3eb8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    3ebc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3ebf:	75 68                	jne    3f29 <fwp_rc_wide_dup+0xf9>
    3ec1:	bf 18 00 00 00       	mov    $0x18,%edi
    3ec6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ecb:	4c 89 04 24          	mov    %r8,(%rsp)
    3ecf:	e8 ac e6 ff ff       	call   2580 <malloc@plt>
    3ed4:	4c 8b 04 24          	mov    (%rsp),%r8
    3ed8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3edd:	48 85 c0             	test   %rax,%rax
    3ee0:	74 5f                	je     3f41 <fwp_rc_wide_dup+0x111>
    3ee2:	48 89 08             	mov    %rcx,(%rax)
    3ee5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    3eec:	00 
    3eed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    3ef4:	00 
    3ef5:	49 89 00             	mov    %rax,(%r8)
    3ef8:	c6 01 ff             	movb   $0xff,(%rcx)
    3efb:	48 83 05 25 d4 01 00 	addq   $0x1,0x1d425(%rip)        # 21328 <fwp_heap+0x1c48>
    3f02:	01 
    3f03:	48 83 c4 18          	add    $0x18,%rsp
    3f07:	c3                   	ret
    3f08:	80 3f fe             	cmpb   $0xfe,(%rdi)
    3f0b:	75 13                	jne    3f20 <fwp_rc_wide_dup+0xf0>
    3f0d:	48 85 c0             	test   %rax,%rax
    3f10:	74 af                	je     3ec1 <fwp_rc_wide_dup+0x91>
    3f12:	48 8d 3d 6f 83 00 00 	lea    0x836f(%rip),%rdi        # c288 <_IO_stdin_used+0x288>
    3f19:	e8 02 f2 ff ff       	call   3120 <fwp_trap>
    3f1e:	66 90                	xchg   %ax,%ax
    3f20:	48 85 c0             	test   %rax,%rax
    3f23:	0f 85 6d ff ff ff    	jne    3e96 <fwp_rc_wide_dup+0x66>
    3f29:	48 8d 3d 80 83 00 00 	lea    0x8380(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    3f30:	e8 eb f1 ff ff       	call   3120 <fwp_trap>
    3f35:	48 8d 3d 69 81 00 00 	lea    0x8169(%rip),%rdi        # c0a5 <_IO_stdin_used+0xa5>
    3f3c:	e8 df f1 ff ff       	call   3120 <fwp_trap>
    3f41:	e8 2a ed ff ff       	call   2c70 <fwp_heap_oom>
    3f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f4d:	00 00 00 

0000000000003f50 <fwp_rc_forget_slot>:
    3f50:	80 3f ff             	cmpb   $0xff,(%rdi)
    3f53:	74 0b                	je     3f60 <fwp_rc_forget_slot+0x10>
    3f55:	c3                   	ret
    3f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f5d:	00 00 00 
    3f60:	48 89 f8             	mov    %rdi,%rax
    3f63:	48 83 ec 08          	sub    $0x8,%rsp
    3f67:	48 89 fa             	mov    %rdi,%rdx
    3f6a:	48 c1 e8 11          	shr    $0x11,%rax
    3f6e:	48 31 f8             	xor    %rdi,%rax
    3f71:	48 89 c1             	mov    %rax,%rcx
    3f74:	48 c1 e9 09          	shr    $0x9,%rcx
    3f78:	48 31 c8             	xor    %rcx,%rax
    3f7b:	48 8d 0d 5e b7 01 00 	lea    0x1b75e(%rip),%rcx        # 1f6e0 <fwp_heap>
    3f82:	0f b6 c0             	movzbl %al,%eax
    3f85:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f8c:	00 
    3f8d:	48 85 ff             	test   %rdi,%rdi
    3f90:	74 3c                	je     3fce <fwp_rc_forget_slot+0x7e>
    3f92:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f99:	00 
    3f9a:	48 8b 01             	mov    (%rcx),%rax
    3f9d:	eb 11                	jmp    3fb0 <fwp_rc_forget_slot+0x60>
    3f9f:	90                   	nop
    3fa0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3fa4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3fa8:	48 85 ff             	test   %rdi,%rdi
    3fab:	74 21                	je     3fce <fwp_rc_forget_slot+0x7e>
    3fad:	48 89 f8             	mov    %rdi,%rax
    3fb0:	48 3b 10             	cmp    (%rax),%rdx
    3fb3:	75 eb                	jne    3fa0 <fwp_rc_forget_slot+0x50>
    3fb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fb9:	48 89 01             	mov    %rax,(%rcx)
    3fbc:	e8 df e3 ff ff       	call   23a0 <free@plt>
    3fc1:	48 83 2d 5f d3 01 00 	subq   $0x1,0x1d35f(%rip)        # 21328 <fwp_heap+0x1c48>
    3fc8:	01 
    3fc9:	48 83 c4 08          	add    $0x8,%rsp
    3fcd:	c3                   	ret
    3fce:	48 8d 3d db 82 00 00 	lea    0x82db(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    3fd5:	e8 46 f1 ff ff       	call   3120 <fwp_trap>
    3fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003fe0 <fwp_rc_prepare_chunk>:
    3fe0:	48 83 3d 40 d3 01 00 	cmpq   $0x0,0x1d340(%rip)        # 21328 <fwp_heap+0x1c48>
    3fe7:	00 
    3fe8:	41 54                	push   %r12
    3fea:	49 89 f4             	mov    %rsi,%r12
    3fed:	55                   	push   %rbp
    3fee:	48 89 fd             	mov    %rdi,%rbp
    3ff1:	53                   	push   %rbx
    3ff2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3ff5:	0f 84 7d 00 00 00    	je     4078 <fwp_rc_prepare_chunk+0x98>
    3ffb:	31 db                	xor    %ebx,%ebx
    3ffd:	85 c0                	test   %eax,%eax
    3fff:	75 5f                	jne    4060 <fwp_rc_prepare_chunk+0x80>
    4001:	48 85 f6             	test   %rsi,%rsi
    4004:	74 7c                	je     4082 <fwp_rc_prepare_chunk+0xa2>
    4006:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    400a:	e8 91 e3 ff ff       	call   23a0 <free@plt>
    400f:	90                   	nop
    4010:	be 01 00 00 00       	mov    $0x1,%esi
    4015:	4c 89 e7             	mov    %r12,%rdi
    4018:	e8 e3 e4 ff ff       	call   2500 <calloc@plt>
    401d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    4021:	48 85 c0             	test   %rax,%rax
    4024:	0f 85 87 00 00 00    	jne    40b1 <fwp_rc_prepare_chunk+0xd1>
    402a:	e8 41 ec ff ff       	call   2c70 <fwp_heap_oom>
    402f:	90                   	nop
    4030:	e8 1b ff ff ff       	call   3f50 <fwp_rc_forget_slot>
    4035:	8b 45 1c             	mov    0x1c(%rbp),%eax
    4038:	48 83 c3 01          	add    $0x1,%rbx
    403c:	48 39 c3             	cmp    %rax,%rbx
    403f:	73 37                	jae    4078 <fwp_rc_prepare_chunk+0x98>
    4041:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4048:	00 00 
    404a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4051:	00 00 00 00 
    4055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    405c:	00 00 00 00 
    4060:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4064:	48 01 df             	add    %rbx,%rdi
    4067:	80 3f ff             	cmpb   $0xff,(%rdi)
    406a:	74 c4                	je     4030 <fwp_rc_prepare_chunk+0x50>
    406c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    406f:	48 83 c3 01          	add    $0x1,%rbx
    4073:	48 39 c3             	cmp    %rax,%rbx
    4076:	72 e8                	jb     4060 <fwp_rc_prepare_chunk+0x80>
    4078:	49 39 c4             	cmp    %rax,%r12
    407b:	75 13                	jne    4090 <fwp_rc_prepare_chunk+0xb0>
    407d:	4d 85 e4             	test   %r12,%r12
    4080:	75 46                	jne    40c8 <fwp_rc_prepare_chunk+0xe8>
    4082:	5b                   	pop    %rbx
    4083:	5d                   	pop    %rbp
    4084:	41 5c                	pop    %r12
    4086:	c3                   	ret
    4087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    408e:	00 00 
    4090:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4094:	48 29 05 95 d2 01 00 	sub    %rax,0x1d295(%rip)        # 21330 <fwp_heap+0x1c50>
    409b:	e8 00 e3 ff ff       	call   23a0 <free@plt>
    40a0:	4d 85 e4             	test   %r12,%r12
    40a3:	0f 85 67 ff ff ff    	jne    4010 <fwp_rc_prepare_chunk+0x30>
    40a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    40b0:	00 
    40b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    40b5:	5b                   	pop    %rbx
    40b6:	4c 01 25 73 d2 01 00 	add    %r12,0x1d273(%rip)        # 21330 <fwp_heap+0x1c50>
    40bd:	5d                   	pop    %rbp
    40be:	41 5c                	pop    %r12
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    40cc:	5b                   	pop    %rbx
    40cd:	4c 89 e2             	mov    %r12,%rdx
    40d0:	31 f6                	xor    %esi,%esi
    40d2:	5d                   	pop    %rbp
    40d3:	41 5c                	pop    %r12
    40d5:	e9 c6 e3 ff ff       	jmp    24a0 <memset@plt>
    40da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040e0 <fwp_heap_refill>:
    40e0:	41 56                	push   %r14
    40e2:	41 89 d6             	mov    %edx,%r14d
    40e5:	41 55                	push   %r13
    40e7:	41 89 f5             	mov    %esi,%r13d
    40ea:	41 54                	push   %r12
    40ec:	49 89 fc             	mov    %rdi,%r12
    40ef:	bf 01 00 00 00       	mov    $0x1,%edi
    40f4:	55                   	push   %rbp
    40f5:	53                   	push   %rbx
    40f6:	e8 a5 ec ff ff       	call   2da0 <fwp_heap_chunks>
    40fb:	48 89 c3             	mov    %rax,%rbx
    40fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4102:	48 8b 05 cf c9 01 00 	mov    0x1c9cf(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    4109:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    410d:	48 8d 05 cc b5 01 00 	lea    0x1b5cc(%rip),%rax        # 1f6e0 <fwp_heap>
    4114:	31 d2                	xor    %edx,%edx
    4116:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    411a:	48 89 ef             	mov    %rbp,%rdi
    411d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    4121:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    4125:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    412c:	00 
    412d:	b8 00 00 01 00       	mov    $0x10000,%eax
    4132:	f7 f1                	div    %ecx
    4134:	31 d2                	xor    %edx,%edx
    4136:	66 0f 6e c1          	movd   %ecx,%xmm0
    413a:	66 0f 6e c8          	movd   %eax,%xmm1
    413e:	89 c6                	mov    %eax,%esi
    4140:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4145:	48 01 c8             	add    %rcx,%rax
    4148:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    414c:	48 f7 f1             	div    %rcx
    414f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    4154:	89 45 18             	mov    %eax,0x18(%rbp)
    4157:	e8 84 fe ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    415c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    415f:	48 89 d8             	mov    %rbx,%rax
    4162:	48 c1 e0 10          	shl    $0x10,%rax
    4166:	48 03 05 23 c9 01 00 	add    0x1c923(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    416d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    4171:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    4176:	8b 55 08             	mov    0x8(%rbp),%edx
    4179:	48 0f af d1          	imul   %rcx,%rdx
    417d:	48 01 c2             	add    %rax,%rdx
    4180:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4185:	5b                   	pop    %rbx
    4186:	5d                   	pop    %rbp
    4187:	41 5c                	pop    %r12
    4189:	41 5d                	pop    %r13
    418b:	41 5e                	pop    %r14
    418d:	c3                   	ret
    418e:	66 90                	xchg   %ax,%ax

0000000000004190 <fwp_mem_free>:
    4190:	48 85 ff             	test   %rdi,%rdi
    4193:	0f 84 17 02 00 00    	je     43b0 <fwp_mem_free+0x220>
    4199:	48 8b 35 f0 c8 01 00 	mov    0x1c8f0(%rip),%rsi        # 20a90 <fwp_heap+0x13b0>
    41a0:	48 8b 05 11 c9 01 00 	mov    0x1c911(%rip),%rax        # 20ab8 <fwp_heap+0x13d8>
    41a7:	48 89 fa             	mov    %rdi,%rdx
    41aa:	48 29 f2             	sub    %rsi,%rdx
    41ad:	48 c1 e0 10          	shl    $0x10,%rax
    41b1:	48 39 c2             	cmp    %rax,%rdx
    41b4:	0f 83 f6 01 00 00    	jae    43b0 <fwp_mem_free+0x220>
    41ba:	49 89 d1             	mov    %rdx,%r9
    41bd:	49 c1 e9 10          	shr    $0x10,%r9
    41c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    41c5:	48 c1 e0 03          	shl    $0x3,%rax
    41c9:	49 89 c0             	mov    %rax,%r8
    41cc:	4c 03 05 05 c9 01 00 	add    0x1c905(%rip),%r8        # 20ad8 <fwp_heap+0x13f8>
    41d3:	0f 84 d7 01 00 00    	je     43b0 <fwp_mem_free+0x220>
    41d9:	48 83 ec 38          	sub    $0x38,%rsp
    41dd:	48 89 f9             	mov    %rdi,%rcx
    41e0:	41 0f b6 38          	movzbl (%r8),%edi
    41e4:	40 80 ff 01          	cmp    $0x1,%dil
    41e8:	74 16                	je     4200 <fwp_mem_free+0x70>
    41ea:	40 80 ff 02          	cmp    $0x2,%dil
    41ee:	0f 84 94 00 00 00    	je     4288 <fwp_mem_free+0xf8>
    41f4:	48 83 c4 38          	add    $0x38,%rsp
    41f8:	c3                   	ret
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4200:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4204:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4209:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    420e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4212:	4d 85 d2             	test   %r10,%r10
    4215:	74 1d                	je     4234 <fwp_mem_free+0xa4>
    4217:	0f b7 c1             	movzwl %cx,%eax
    421a:	31 d2                	xor    %edx,%edx
    421c:	48 f7 f7             	div    %rdi
    421f:	49 01 c2             	add    %rax,%r10
    4222:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4226:	0f 84 44 01 00 00    	je     4370 <fwp_mem_free+0x1e0>
    422c:	41 c6 02 00          	movb   $0x0,(%r10)
    4230:	41 8b 78 04          	mov    0x4(%r8),%edi
    4234:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    423b:	49 63 c1             	movslq %r9d,%rax
    423e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4242:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4246:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    424b:	f2 0f 58 05 cd c8 01 	addsd  0x1c8cd(%rip),%xmm0        # 20b20 <fwp_heap+0x1440>
    4252:	00 
    4253:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4257:	48 8d 05 82 b4 01 00 	lea    0x1b482(%rip),%rax        # 1f6e0 <fwp_heap>
    425e:	48 01 d0             	add    %rdx,%rax
    4261:	48 8b 10             	mov    (%rax),%rdx
    4264:	48 f7 d2             	not    %rdx
    4267:	48 89 11             	mov    %rdx,(%rcx)
    426a:	48 89 08             	mov    %rcx,(%rax)
    426d:	48 29 3d 8c c8 01 00 	sub    %rdi,0x1c88c(%rip)        # 20b00 <fwp_heap+0x1420>
    4274:	f2 0f 11 05 a4 c8 01 	movsd  %xmm0,0x1c8a4(%rip)        # 20b20 <fwp_heap+0x1440>
    427b:	00 
    427c:	48 83 c4 38          	add    $0x38,%rsp
    4280:	c3                   	ret
    4281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4288:	66 31 d2             	xor    %dx,%dx
    428b:	48 01 d6             	add    %rdx,%rsi
    428e:	48 39 f1             	cmp    %rsi,%rcx
    4291:	0f 85 5d ff ff ff    	jne    41f4 <fwp_mem_free+0x64>
    4297:	49 8b 50 10          	mov    0x10(%r8),%rdx
    429b:	48 29 15 5e c8 01 00 	sub    %rdx,0x1c85e(%rip)        # 20b00 <fwp_heap+0x1420>
    42a2:	48 85 d2             	test   %rdx,%rdx
    42a5:	0f 88 a5 00 00 00    	js     4350 <fwp_mem_free+0x1c0>
    42ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    42b4:	f2 0f 58 05 64 c8 01 	addsd  0x1c864(%rip),%xmm0        # 20b20 <fwp_heap+0x1440>
    42bb:	00 
    42bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    42c0:	f2 0f 11 05 58 c8 01 	movsd  %xmm0,0x1c858(%rip)        # 20b20 <fwp_heap+0x1440>
    42c7:	00 
    42c8:	48 85 d2             	test   %rdx,%rdx
    42cb:	74 0c                	je     42d9 <fwp_mem_free+0x149>
    42cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    42d0:	0f 84 db 00 00 00    	je     43b1 <fwp_mem_free+0x221>
    42d6:	c6 02 00             	movb   $0x0,(%rdx)
    42d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    42dd:	48 85 c9             	test   %rcx,%rcx
    42e0:	74 3e                	je     4320 <fwp_mem_free+0x190>
    42e2:	48 8b 15 ef c7 01 00 	mov    0x1c7ef(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    42e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    42ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    42f1:	48 01 d0             	add    %rdx,%rax
    42f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    42f8:	48 89 d6             	mov    %rdx,%rsi
    42fb:	48 29 c6             	sub    %rax,%rsi
    42fe:	83 e6 08             	and    $0x8,%esi
    4301:	74 0d                	je     4310 <fwp_mem_free+0x180>
    4303:	c6 00 00             	movb   $0x0,(%rax)
    4306:	48 83 c0 28          	add    $0x28,%rax
    430a:	48 39 c2             	cmp    %rax,%rdx
    430d:	74 11                	je     4320 <fwp_mem_free+0x190>
    430f:	90                   	nop
    4310:	c6 00 00             	movb   $0x0,(%rax)
    4313:	48 83 c0 50          	add    $0x50,%rax
    4317:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    431b:	48 39 c2             	cmp    %rax,%rdx
    431e:	75 f0                	jne    4310 <fwp_mem_free+0x180>
    4320:	48 01 0d e9 c7 01 00 	add    %rcx,0x1c7e9(%rip)        # 20b10 <fwp_heap+0x1430>
    4327:	4c 3b 0d a2 c7 01 00 	cmp    0x1c7a2(%rip),%r9        # 20ad0 <fwp_heap+0x13f0>
    432e:	73 07                	jae    4337 <fwp_mem_free+0x1a7>
    4330:	4c 89 0d 99 c7 01 00 	mov    %r9,0x1c799(%rip)        # 20ad0 <fwp_heap+0x13f0>
    4337:	4c 3b 0d 8a c7 01 00 	cmp    0x1c78a(%rip),%r9        # 20ac8 <fwp_heap+0x13e8>
    433e:	0f 83 b0 fe ff ff    	jae    41f4 <fwp_mem_free+0x64>
    4344:	4c 89 0d 7d c7 01 00 	mov    %r9,0x1c77d(%rip)        # 20ac8 <fwp_heap+0x13e8>
    434b:	e9 a4 fe ff ff       	jmp    41f4 <fwp_mem_free+0x64>
    4350:	48 89 d1             	mov    %rdx,%rcx
    4353:	83 e2 01             	and    $0x1,%edx
    4356:	66 0f ef c0          	pxor   %xmm0,%xmm0
    435a:	48 d1 e9             	shr    $1,%rcx
    435d:	48 09 d1             	or     %rdx,%rcx
    4360:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    4365:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4369:	e9 46 ff ff ff       	jmp    42b4 <fwp_mem_free+0x124>
    436e:	66 90                	xchg   %ax,%ax
    4370:	4c 89 d7             	mov    %r10,%rdi
    4373:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    4378:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    437d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4382:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4386:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    438b:	e8 c0 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    4390:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4395:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    439a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    439f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    43a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    43a9:	e9 7e fe ff ff       	jmp    422c <fwp_mem_free+0x9c>
    43ae:	66 90                	xchg   %ax,%ax
    43b0:	c3                   	ret
    43b1:	48 89 d7             	mov    %rdx,%rdi
    43b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    43b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    43be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    43c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    43c8:	e8 83 fb ff ff       	call   3f50 <fwp_rc_forget_slot>
    43cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    43d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    43d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    43dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    43e1:	e9 f0 fe ff ff       	jmp    42d6 <fwp_mem_free+0x146>
    43e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    43ed:	00 00 00 

00000000000043f0 <fwp_heap_alloc_big>:
    43f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    43f7:	00 00 40 
    43fa:	41 57                	push   %r15
    43fc:	41 56                	push   %r14
    43fe:	41 55                	push   %r13
    4400:	41 54                	push   %r12
    4402:	55                   	push   %rbp
    4403:	53                   	push   %rbx
    4404:	48 83 ec 08          	sub    $0x8,%rsp
    4408:	48 39 f8             	cmp    %rdi,%rax
    440b:	0f 82 fa 00 00 00    	jb     450b <fwp_heap_alloc_big+0x11b>
    4411:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4418:	49 89 fd             	mov    %rdi,%r13
    441b:	41 89 f6             	mov    %esi,%r14d
    441e:	48 c1 ed 10          	shr    $0x10,%rbp
    4422:	48 89 ef             	mov    %rbp,%rdi
    4425:	e8 76 e9 ff ff       	call   2da0 <fwp_heap_chunks>
    442a:	be 01 00 00 00       	mov    $0x1,%esi
    442f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4433:	49 89 c4             	mov    %rax,%r12
    4436:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    443d:	00 
    443e:	48 03 3d 93 c6 01 00 	add    0x1c693(%rip),%rdi        # 20ad8 <fwp_heap+0x13f8>
    4445:	c6 07 02             	movb   $0x2,(%rdi)
    4448:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    444c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    444f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4453:	e8 88 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4458:	48 83 fd 01          	cmp    $0x1,%rbp
    445c:	76 47                	jbe    44a5 <fwp_heap_alloc_big+0xb5>
    445e:	4c 01 e5             	add    %r12,%rbp
    4461:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    4468:	00 
    4469:	4c 8d 3d 70 b2 01 00 	lea    0x1b270(%rip),%r15        # 1f6e0 <fwp_heap>
    4470:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    4475:	49 c1 e6 03          	shl    $0x3,%r14
    4479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4480:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4487:	31 f6                	xor    %esi,%esi
    4489:	48 01 dd             	add    %rbx,%rbp
    448c:	48 83 c3 28          	add    $0x28,%rbx
    4490:	48 89 ef             	mov    %rbp,%rdi
    4493:	e8 48 fb ff ff       	call   3fe0 <fwp_rc_prepare_chunk>
    4498:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    449c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    44a0:	49 39 de             	cmp    %rbx,%r14
    44a3:	75 db                	jne    4480 <fwp_heap_alloc_big+0x90>
    44a5:	49 c1 e4 10          	shl    $0x10,%r12
    44a9:	4c 03 25 e0 c5 01 00 	add    0x1c5e0(%rip),%r12        # 20a90 <fwp_heap+0x13b0>
    44b0:	4c 89 ea             	mov    %r13,%rdx
    44b3:	31 f6                	xor    %esi,%esi
    44b5:	4c 89 e7             	mov    %r12,%rdi
    44b8:	e8 e3 df ff ff       	call   24a0 <memset@plt>
    44bd:	4c 89 e8             	mov    %r13,%rax
    44c0:	48 03 05 39 c6 01 00 	add    0x1c639(%rip),%rax        # 20b00 <fwp_heap+0x1420>
    44c7:	72 42                	jb     450b <fwp_heap_alloc_big+0x11b>
    44c9:	48 39 05 38 c6 01 00 	cmp    %rax,0x1c638(%rip)        # 20b08 <fwp_heap+0x1428>
    44d0:	48 89 05 29 c6 01 00 	mov    %rax,0x1c629(%rip)        # 20b00 <fwp_heap+0x1420>
    44d7:	73 07                	jae    44e0 <fwp_heap_alloc_big+0xf0>
    44d9:	48 89 05 28 c6 01 00 	mov    %rax,0x1c628(%rip)        # 20b08 <fwp_heap+0x1428>
    44e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    44e4:	4c 89 e0             	mov    %r12,%rax
    44e7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    44ec:	f2 0f 58 05 24 c6 01 	addsd  0x1c624(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    44f3:	00 
    44f4:	f2 0f 11 05 1c c6 01 	movsd  %xmm0,0x1c61c(%rip)        # 20b18 <fwp_heap+0x1438>
    44fb:	00 
    44fc:	48 83 c4 08          	add    $0x8,%rsp
    4500:	5b                   	pop    %rbx
    4501:	5d                   	pop    %rbp
    4502:	41 5c                	pop    %r12
    4504:	41 5d                	pop    %r13
    4506:	41 5e                	pop    %r14
    4508:	41 5f                	pop    %r15
    450a:	c3                   	ret
    450b:	e8 60 e7 ff ff       	call   2c70 <fwp_heap_oom>

0000000000004510 <fwp_heap_alloc_slow>:
    4510:	53                   	push   %rbx
    4511:	48 89 f9             	mov    %rdi,%rcx
    4514:	41 89 f1             	mov    %esi,%r9d
    4517:	48 83 ec 10          	sub    $0x10,%rsp
    451b:	8b 05 63 c5 01 00    	mov    0x1c563(%rip),%eax        # 20a84 <fwp_heap+0x13a4>
    4521:	85 c0                	test   %eax,%eax
    4523:	0f 84 c7 00 00 00    	je     45f0 <fwp_heap_alloc_slow+0xe0>
    4529:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4530:	0f 87 dd 00 00 00    	ja     4613 <fwp_heap_alloc_slow+0x103>
    4536:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    453a:	48 8d 3d 9f b1 01 00 	lea    0x1b19f(%rip),%rdi        # 1f6e0 <fwp_heap>
    4541:	49 63 f1             	movslq %r9d,%rsi
    4544:	48 c1 e8 04          	shr    $0x4,%rax
    4548:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    454f:	00 00 
    4551:	41 0f b6 c2          	movzbl %r10b,%eax
    4555:	4c 89 d2             	mov    %r10,%rdx
    4558:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    455c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    4563:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    456a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    456e:	48 01 f8             	add    %rdi,%rax
    4571:	4c 8b 00             	mov    (%rax),%r8
    4574:	4d 85 c0             	test   %r8,%r8
    4577:	0f 84 ab 00 00 00    	je     4628 <fwp_heap_alloc_slow+0x118>
    457d:	49 8b 10             	mov    (%r8),%rdx
    4580:	48 f7 d2             	not    %rdx
    4583:	48 89 10             	mov    %rdx,(%rax)
    4586:	41 83 f9 01          	cmp    $0x1,%r9d
    458a:	4c 89 c7             	mov    %r8,%rdi
    458d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4591:	31 f6                	xor    %esi,%esi
    4593:	48 89 ca             	mov    %rcx,%rdx
    4596:	e8 05 df ff ff       	call   24a0 <memset@plt>
    459b:	49 89 c0             	mov    %rax,%r8
    459e:	48 89 d8             	mov    %rbx,%rax
    45a1:	48 03 05 58 c5 01 00 	add    0x1c558(%rip),%rax        # 20b00 <fwp_heap+0x1420>
    45a8:	0f 82 d9 00 00 00    	jb     4687 <fwp_heap_alloc_slow+0x177>
    45ae:	48 39 05 53 c5 01 00 	cmp    %rax,0x1c553(%rip)        # 20b08 <fwp_heap+0x1428>
    45b5:	48 89 05 44 c5 01 00 	mov    %rax,0x1c544(%rip)        # 20b00 <fwp_heap+0x1420>
    45bc:	73 07                	jae    45c5 <fwp_heap_alloc_slow+0xb5>
    45be:	48 89 05 43 c5 01 00 	mov    %rax,0x1c543(%rip)        # 20b08 <fwp_heap+0x1428>
    45c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    45c9:	4c 89 c0             	mov    %r8,%rax
    45cc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    45d1:	f2 0f 58 05 3f c5 01 	addsd  0x1c53f(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    45d8:	00 
    45d9:	f2 0f 11 05 37 c5 01 	movsd  %xmm0,0x1c537(%rip)        # 20b18 <fwp_heap+0x1438>
    45e0:	00 
    45e1:	48 83 c4 10          	add    $0x10,%rsp
    45e5:	5b                   	pop    %rbx
    45e6:	c3                   	ret
    45e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    45ee:	00 00 
    45f0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    45f4:	48 89 3c 24          	mov    %rdi,(%rsp)
    45f8:	e8 73 f2 ff ff       	call   3870 <fwp_heap_init>
    45fd:	48 8b 0c 24          	mov    (%rsp),%rcx
    4601:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4606:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    460d:	0f 86 23 ff ff ff    	jbe    4536 <fwp_heap_alloc_slow+0x26>
    4613:	48 83 c4 10          	add    $0x10,%rsp
    4617:	44 89 ce             	mov    %r9d,%esi
    461a:	48 89 cf             	mov    %rcx,%rdi
    461d:	5b                   	pop    %rbx
    461e:	e9 cd fd ff ff       	jmp    43f0 <fwp_heap_alloc_big>
    4623:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4628:	4c 8b 40 08          	mov    0x8(%rax),%r8
    462c:	4d 85 c0             	test   %r8,%r8
    462f:	74 1f                	je     4650 <fwp_heap_alloc_slow+0x140>
    4631:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4635:	4d 29 c3             	sub    %r8,%r11
    4638:	49 39 db             	cmp    %rbx,%r11
    463b:	72 13                	jb     4650 <fwp_heap_alloc_slow+0x140>
    463d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4641:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4645:	e9 3c ff ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    464a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4650:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4657:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    465b:	44 89 ca             	mov    %r9d,%edx
    465e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4663:	44 89 0c 24          	mov    %r9d,(%rsp)
    4667:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    466b:	44 89 d6             	mov    %r10d,%esi
    466e:	48 01 c7             	add    %rax,%rdi
    4671:	e8 6a fa ff ff       	call   40e0 <fwp_heap_refill>
    4676:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    467b:	44 8b 0c 24          	mov    (%rsp),%r9d
    467f:	49 89 c0             	mov    %rax,%r8
    4682:	e9 ff fe ff ff       	jmp    4586 <fwp_heap_alloc_slow+0x76>
    4687:	e8 e4 e5 ff ff       	call   2c70 <fwp_heap_oom>
    468c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004690 <fwp_rc_share>:
    4690:	48 8b 05 21 c4 01 00 	mov    0x1c421(%rip),%rax        # 20ab8 <fwp_heap+0x13d8>
    4697:	48 2b 3d f2 c3 01 00 	sub    0x1c3f2(%rip),%rdi        # 20a90 <fwp_heap+0x13b0>
    469e:	48 c1 e0 10          	shl    $0x10,%rax
    46a2:	48 39 c7             	cmp    %rax,%rdi
    46a5:	73 4a                	jae    46f1 <fwp_rc_share+0x61>
    46a7:	48 89 f8             	mov    %rdi,%rax
    46aa:	48 c1 e8 10          	shr    $0x10,%rax
    46ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    46b2:	48 8b 05 1f c4 01 00 	mov    0x1c41f(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    46b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    46bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    46c1:	48 85 d2             	test   %rdx,%rdx
    46c4:	74 2b                	je     46f1 <fwp_rc_share+0x61>
    46c6:	0f b6 08             	movzbl (%rax),%ecx
    46c9:	80 f9 02             	cmp    $0x2,%cl
    46cc:	74 2a                	je     46f8 <fwp_rc_share+0x68>
    46ce:	80 f9 01             	cmp    $0x1,%cl
    46d1:	75 1e                	jne    46f1 <fwp_rc_share+0x61>
    46d3:	8b 48 18             	mov    0x18(%rax),%ecx
    46d6:	0f b7 ff             	movzwl %di,%edi
    46d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    46dc:	48 0f af f9          	imul   %rcx,%rdi
    46e0:	48 c1 ef 20          	shr    $0x20,%rdi
    46e4:	48 39 c7             	cmp    %rax,%rdi
    46e7:	73 08                	jae    46f1 <fwp_rc_share+0x61>
    46e9:	48 01 fa             	add    %rdi,%rdx
    46ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    46ef:	75 0d                	jne    46fe <fwp_rc_share+0x6e>
    46f1:	c3                   	ret
    46f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    46f8:	66 85 ff             	test   %di,%di
    46fb:	74 ef                	je     46ec <fwp_rc_share+0x5c>
    46fd:	c3                   	ret
    46fe:	50                   	push   %rax
    46ff:	48 8d 3d d2 7b 00 00 	lea    0x7bd2(%rip),%rdi        # c2d8 <_IO_stdin_used+0x2d8>
    4706:	e8 15 ea ff ff       	call   3120 <fwp_trap>
    470b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000004710 <e69>:
    4710:	f3 0f 1e fa          	endbr64
    4714:	53                   	push   %rbx
    4715:	f2 0f 10 05 53 7d 00 	movsd  0x7d53(%rip),%xmm0        # c470 <msg.3+0x20>
    471c:	00 
    471d:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    4721:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4726:	48 89 df             	mov    %rbx,%rdi
    4729:	e8 62 ff ff ff       	call   4690 <fwp_rc_share>
    472e:	48 89 d8             	mov    %rbx,%rax
    4731:	5b                   	pop    %rbx
    4732:	c3                   	ret
    4733:	66 90                	xchg   %ax,%ax
    4735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    473c:	00 00 00 00 

0000000000004740 <e45>:
    4740:	f3 0f 1e fa          	endbr64
    4744:	53                   	push   %rbx
    4745:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4749:	f2 0f 58 47 08       	addsd  0x8(%rdi),%xmm0
    474e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4753:	48 89 df             	mov    %rbx,%rdi
    4756:	e8 35 ff ff ff       	call   4690 <fwp_rc_share>
    475b:	48 89 d8             	mov    %rbx,%rax
    475e:	5b                   	pop    %rbx
    475f:	c3                   	ret

0000000000004760 <e32>:
    4760:	f3 0f 1e fa          	endbr64
    4764:	53                   	push   %rbx
    4765:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    476a:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    476e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4773:	48 89 df             	mov    %rbx,%rdi
    4776:	e8 15 ff ff ff       	call   4690 <fwp_rc_share>
    477b:	48 89 d8             	mov    %rbx,%rax
    477e:	5b                   	pop    %rbx
    477f:	c3                   	ret

0000000000004780 <fwp_rc_fresh>:
    4780:	48 8b 15 31 c3 01 00 	mov    0x1c331(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    4787:	48 89 f8             	mov    %rdi,%rax
    478a:	48 89 fe             	mov    %rdi,%rsi
    478d:	48 2b 05 fc c2 01 00 	sub    0x1c2fc(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    4794:	48 c1 e2 10          	shl    $0x10,%rdx
    4798:	48 39 d0             	cmp    %rdx,%rax
    479b:	73 4f                	jae    47ec <fwp_rc_fresh+0x6c>
    479d:	48 89 c2             	mov    %rax,%rdx
    47a0:	48 c1 ea 10          	shr    $0x10,%rdx
    47a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    47a8:	48 8b 15 29 c3 01 00 	mov    0x1c329(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    47af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    47b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    47b7:	48 85 d2             	test   %rdx,%rdx
    47ba:	74 30                	je     47ec <fwp_rc_fresh+0x6c>
    47bc:	0f b6 39             	movzbl (%rcx),%edi
    47bf:	40 80 ff 02          	cmp    $0x2,%dil
    47c3:	74 2b                	je     47f0 <fwp_rc_fresh+0x70>
    47c5:	40 80 ff 01          	cmp    $0x1,%dil
    47c9:	75 21                	jne    47ec <fwp_rc_fresh+0x6c>
    47cb:	8b 79 18             	mov    0x18(%rcx),%edi
    47ce:	0f b7 c0             	movzwl %ax,%eax
    47d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    47d4:	48 0f af c7          	imul   %rdi,%rax
    47d8:	48 c1 e8 20          	shr    $0x20,%rax
    47dc:	48 39 c8             	cmp    %rcx,%rax
    47df:	73 0b                	jae    47ec <fwp_rc_fresh+0x6c>
    47e1:	48 01 c2             	add    %rax,%rdx
    47e4:	80 3a ff             	cmpb   $0xff,(%rdx)
    47e7:	74 17                	je     4800 <fwp_rc_fresh+0x80>
    47e9:	c6 02 01             	movb   $0x1,(%rdx)
    47ec:	48 89 f0             	mov    %rsi,%rax
    47ef:	c3                   	ret
    47f0:	66 85 c0             	test   %ax,%ax
    47f3:	74 ef                	je     47e4 <fwp_rc_fresh+0x64>
    47f5:	48 89 f0             	mov    %rsi,%rax
    47f8:	c3                   	ret
    47f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4800:	48 83 ec 18          	sub    $0x18,%rsp
    4804:	48 89 d7             	mov    %rdx,%rdi
    4807:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    480c:	48 89 14 24          	mov    %rdx,(%rsp)
    4810:	e8 3b f7 ff ff       	call   3f50 <fwp_rc_forget_slot>
    4815:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    481a:	48 8b 14 24          	mov    (%rsp),%rdx
    481e:	48 89 f0             	mov    %rsi,%rax
    4821:	c6 02 01             	movb   $0x1,(%rdx)
    4824:	48 83 c4 18          	add    $0x18,%rsp
    4828:	c3                   	ret
    4829:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004830 <fwp_rc_dup>:
    4830:	f3 0f 1e fa          	endbr64
    4834:	48 8b 05 7d c2 01 00 	mov    0x1c27d(%rip),%rax        # 20ab8 <fwp_heap+0x13d8>
    483b:	48 2b 3d 4e c2 01 00 	sub    0x1c24e(%rip),%rdi        # 20a90 <fwp_heap+0x13b0>
    4842:	48 c1 e0 10          	shl    $0x10,%rax
    4846:	48 39 c7             	cmp    %rax,%rdi
    4849:	73 56                	jae    48a1 <fwp_rc_dup+0x71>
    484b:	48 89 f8             	mov    %rdi,%rax
    484e:	48 c1 e8 10          	shr    $0x10,%rax
    4852:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4856:	48 8b 05 7b c2 01 00 	mov    0x1c27b(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    485d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    4861:	48 8b 42 20          	mov    0x20(%rdx),%rax
    4865:	48 85 c0             	test   %rax,%rax
    4868:	74 37                	je     48a1 <fwp_rc_dup+0x71>
    486a:	0f b6 0a             	movzbl (%rdx),%ecx
    486d:	80 f9 02             	cmp    $0x2,%cl
    4870:	74 36                	je     48a8 <fwp_rc_dup+0x78>
    4872:	80 f9 01             	cmp    $0x1,%cl
    4875:	75 2a                	jne    48a1 <fwp_rc_dup+0x71>
    4877:	8b 4a 18             	mov    0x18(%rdx),%ecx
    487a:	0f b7 ff             	movzwl %di,%edi
    487d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4880:	48 0f af f9          	imul   %rcx,%rdi
    4884:	48 c1 ef 20          	shr    $0x20,%rdi
    4888:	48 39 d7             	cmp    %rdx,%rdi
    488b:	73 14                	jae    48a1 <fwp_rc_dup+0x71>
    488d:	48 01 f8             	add    %rdi,%rax
    4890:	0f b6 10             	movzbl (%rax),%edx
    4893:	84 d2                	test   %dl,%dl
    4895:	74 0a                	je     48a1 <fwp_rc_dup+0x71>
    4897:	80 fa fd             	cmp    $0xfd,%dl
    489a:	77 14                	ja     48b0 <fwp_rc_dup+0x80>
    489c:	83 c2 01             	add    $0x1,%edx
    489f:	88 10                	mov    %dl,(%rax)
    48a1:	c3                   	ret
    48a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    48a8:	66 85 ff             	test   %di,%di
    48ab:	74 e3                	je     4890 <fwp_rc_dup+0x60>
    48ad:	c3                   	ret
    48ae:	66 90                	xchg   %ax,%ax
    48b0:	48 89 c7             	mov    %rax,%rdi
    48b3:	e9 78 f5 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    48b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    48bf:	00 

00000000000048c0 <fwp_task_dispose>:
    48c0:	53                   	push   %rbx
    48c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    48c5:	0f 84 3b de ff ff    	je     2706 <fwp_task_dispose.cold>
    48cb:	48 89 fb             	mov    %rdi,%rbx
    48ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    48d3:	0f 85 2d de ff ff    	jne    2706 <fwp_task_dispose.cold>
    48d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    48dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    48e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    48eb:	00 
    48ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    48f0:	48 85 ff             	test   %rdi,%rdi
    48f3:	74 07                	je     48fc <fwp_task_dispose+0x3c>
    48f5:	48 85 c0             	test   %rax,%rax
    48f8:	74 02                	je     48fc <fwp_task_dispose+0x3c>
    48fa:	ff d0                	call   *%rax
    48fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4903:	e8 88 f8 ff ff       	call   4190 <fwp_mem_free>
    4908:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    490f:	00 00 00 00 
    4913:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4917:	74 6f                	je     4988 <fwp_task_dispose+0xc8>
    4919:	48 8b 15 98 c1 01 00 	mov    0x1c198(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    4920:	48 89 d8             	mov    %rbx,%rax
    4923:	48 2b 05 66 c1 01 00 	sub    0x1c166(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    492a:	48 c1 e2 10          	shl    $0x10,%rdx
    492e:	48 39 d0             	cmp    %rdx,%rax
    4931:	73 4c                	jae    497f <fwp_task_dispose+0xbf>
    4933:	48 89 c2             	mov    %rax,%rdx
    4936:	48 c1 ea 10          	shr    $0x10,%rdx
    493a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    493e:	48 8b 15 93 c1 01 00 	mov    0x1c193(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    4945:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4949:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    494d:	48 85 c9             	test   %rcx,%rcx
    4950:	74 2d                	je     497f <fwp_task_dispose+0xbf>
    4952:	0f b6 32             	movzbl (%rdx),%esi
    4955:	40 80 fe 02          	cmp    $0x2,%sil
    4959:	74 3d                	je     4998 <fwp_task_dispose+0xd8>
    495b:	40 80 fe 01          	cmp    $0x1,%sil
    495f:	75 1e                	jne    497f <fwp_task_dispose+0xbf>
    4961:	8b 72 18             	mov    0x18(%rdx),%esi
    4964:	0f b7 c0             	movzwl %ax,%eax
    4967:	8b 52 1c             	mov    0x1c(%rdx),%edx
    496a:	48 0f af c6          	imul   %rsi,%rax
    496e:	48 c1 e8 20          	shr    $0x20,%rax
    4972:	48 39 d0             	cmp    %rdx,%rax
    4975:	73 08                	jae    497f <fwp_task_dispose+0xbf>
    4977:	48 01 c1             	add    %rax,%rcx
    497a:	80 39 01             	cmpb   $0x1,(%rcx)
    497d:	74 09                	je     4988 <fwp_task_dispose+0xc8>
    497f:	5b                   	pop    %rbx
    4980:	c3                   	ret
    4981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4988:	48 89 df             	mov    %rbx,%rdi
    498b:	5b                   	pop    %rbx
    498c:	e9 ff f7 ff ff       	jmp    4190 <fwp_mem_free>
    4991:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4998:	66 85 c0             	test   %ax,%ax
    499b:	74 dd                	je     497a <fwp_task_dispose+0xba>
    499d:	5b                   	pop    %rbx
    499e:	c3                   	ret
    499f:	90                   	nop

00000000000049a0 <fwp_free_zombie>:
    49a0:	48 8b 15 09 ad 01 00 	mov    0x1ad09(%rip),%rdx        # 1f6b0 <fwp_zombie>
    49a7:	48 85 d2             	test   %rdx,%rdx
    49aa:	0f 84 98 00 00 00    	je     4a48 <fwp_free_zombie+0xa8>
    49b0:	48 3b 15 09 ad 01 00 	cmp    0x1ad09(%rip),%rdx        # 1f6c0 <fwp_cur>
    49b7:	0f 84 8b 00 00 00    	je     4a48 <fwp_free_zombie+0xa8>
    49bd:	48 83 ec 18          	sub    $0x18,%rsp
    49c1:	48 63 05 d4 a6 01 00 	movslq 0x1a6d4(%rip),%rax        # 1f09c <fwp_stack_pool_n>
    49c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    49cc:	83 f8 3f             	cmp    $0x3f,%eax
    49cf:	7f 7f                	jg     4a50 <fwp_free_zombie+0xb0>
    49d1:	8d 48 01             	lea    0x1(%rax),%ecx
    49d4:	89 0d c2 a6 01 00    	mov    %ecx,0x1a6c2(%rip)        # 1f09c <fwp_stack_pool_n>
    49da:	48 8d 0d bf a6 01 00 	lea    0x1a6bf(%rip),%rcx        # 1f0a0 <fwp_stack_pool>
    49e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    49e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    49ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    49f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    49fb:	48 85 c9             	test   %rcx,%rcx
    49fe:	0f 84 fc 00 00 00    	je     4b00 <fwp_free_zombie+0x160>
    4a04:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4a0b:	48 85 c0             	test   %rax,%rax
    4a0e:	74 07                	je     4a17 <fwp_free_zombie+0x77>
    4a10:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4a17:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4a1a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4a1e:	48 c7 05 87 ac 01 00 	movq   $0x0,0x1ac87(%rip)        # 1f6b0 <fwp_zombie>
    4a25:	00 00 00 00 
    4a29:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4a30:	85 c0                	test   %eax,%eax
    4a32:	74 34                	je     4a68 <fwp_free_zombie+0xc8>
    4a34:	83 f8 01             	cmp    $0x1,%eax
    4a37:	0f 84 b3 00 00 00    	je     4af0 <fwp_free_zombie+0x150>
    4a3d:	48 83 c4 18          	add    $0x18,%rsp
    4a41:	c3                   	ret
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	c3                   	ret
    4a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a50:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4a54:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4a59:	e8 52 db ff ff       	call   25b0 <munmap@plt>
    4a5e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4a63:	eb 80                	jmp    49e5 <fwp_free_zombie+0x45>
    4a65:	0f 1f 00             	nopl   (%rax)
    4a68:	48 8b 0d 49 c0 01 00 	mov    0x1c049(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    4a6f:	48 89 d0             	mov    %rdx,%rax
    4a72:	48 2b 05 17 c0 01 00 	sub    0x1c017(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    4a79:	48 c1 e1 10          	shl    $0x10,%rcx
    4a7d:	48 39 c8             	cmp    %rcx,%rax
    4a80:	73 bb                	jae    4a3d <fwp_free_zombie+0x9d>
    4a82:	48 89 c1             	mov    %rax,%rcx
    4a85:	48 c1 e9 10          	shr    $0x10,%rcx
    4a89:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4a8d:	48 8b 0d 44 c0 01 00 	mov    0x1c044(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    4a94:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4a98:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4a9c:	48 85 c9             	test   %rcx,%rcx
    4a9f:	74 9c                	je     4a3d <fwp_free_zombie+0x9d>
    4aa1:	0f b6 3e             	movzbl (%rsi),%edi
    4aa4:	40 80 ff 02          	cmp    $0x2,%dil
    4aa8:	74 66                	je     4b10 <fwp_free_zombie+0x170>
    4aaa:	40 80 ff 01          	cmp    $0x1,%dil
    4aae:	75 8d                	jne    4a3d <fwp_free_zombie+0x9d>
    4ab0:	8b 7e 18             	mov    0x18(%rsi),%edi
    4ab3:	0f b7 c0             	movzwl %ax,%eax
    4ab6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4ab9:	48 0f af c7          	imul   %rdi,%rax
    4abd:	48 c1 e8 20          	shr    $0x20,%rax
    4ac1:	48 39 f0             	cmp    %rsi,%rax
    4ac4:	0f 83 73 ff ff ff    	jae    4a3d <fwp_free_zombie+0x9d>
    4aca:	48 01 c1             	add    %rax,%rcx
    4acd:	0f b6 01             	movzbl (%rcx),%eax
    4ad0:	84 c0                	test   %al,%al
    4ad2:	0f 84 65 ff ff ff    	je     4a3d <fwp_free_zombie+0x9d>
    4ad8:	3c 01                	cmp    $0x1,%al
    4ada:	74 14                	je     4af0 <fwp_free_zombie+0x150>
    4adc:	3c ff                	cmp    $0xff,%al
    4ade:	74 3b                	je     4b1b <fwp_free_zombie+0x17b>
    4ae0:	83 e8 01             	sub    $0x1,%eax
    4ae3:	88 01                	mov    %al,(%rcx)
    4ae5:	e9 53 ff ff ff       	jmp    4a3d <fwp_free_zombie+0x9d>
    4aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4af0:	48 89 d7             	mov    %rdx,%rdi
    4af3:	48 83 c4 18          	add    $0x18,%rsp
    4af7:	e9 c4 fd ff ff       	jmp    48c0 <fwp_task_dispose>
    4afc:	0f 1f 40 00          	nopl   0x0(%rax)
    4b00:	48 89 05 81 ab 01 00 	mov    %rax,0x1ab81(%rip)        # 1f688 <fwp_tasks_active>
    4b07:	e9 ff fe ff ff       	jmp    4a0b <fwp_free_zombie+0x6b>
    4b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    4b10:	66 85 c0             	test   %ax,%ax
    4b13:	0f 85 24 ff ff ff    	jne    4a3d <fwp_free_zombie+0x9d>
    4b19:	eb b2                	jmp    4acd <fwp_free_zombie+0x12d>
    4b1b:	48 89 ca             	mov    %rcx,%rdx
    4b1e:	48 8d 35 bb ab 01 00 	lea    0x1abbb(%rip),%rsi        # 1f6e0 <fwp_heap>
    4b25:	48 c1 ea 11          	shr    $0x11,%rdx
    4b29:	48 31 ca             	xor    %rcx,%rdx
    4b2c:	48 89 d0             	mov    %rdx,%rax
    4b2f:	48 c1 e8 09          	shr    $0x9,%rax
    4b33:	48 31 c2             	xor    %rax,%rdx
    4b36:	0f b6 d2             	movzbl %dl,%edx
    4b39:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4b40:	00 
    4b41:	48 85 c0             	test   %rax,%rax
    4b44:	75 23                	jne    4b69 <fwp_free_zombie+0x1c9>
    4b46:	eb 5c                	jmp    4ba4 <fwp_free_zombie+0x204>
    4b48:	66 90                	xchg   %ax,%ax
    4b4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b51:	00 00 00 00 
    4b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b5c:	00 00 00 00 
    4b60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4b64:	48 85 c0             	test   %rax,%rax
    4b67:	74 3b                	je     4ba4 <fwp_free_zombie+0x204>
    4b69:	48 89 c2             	mov    %rax,%rdx
    4b6c:	48 39 08             	cmp    %rcx,(%rax)
    4b6f:	75 ef                	jne    4b60 <fwp_free_zombie+0x1c0>
    4b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4b79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4b7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4b84:	0f 85 b3 fe ff ff    	jne    4a3d <fwp_free_zombie+0x9d>
    4b8a:	48 89 cf             	mov    %rcx,%rdi
    4b8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4b92:	e8 b9 f3 ff ff       	call   3f50 <fwp_rc_forget_slot>
    4b97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4b9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4b9f:	e9 99 fe ff ff       	jmp    4a3d <fwp_free_zombie+0x9d>
    4ba4:	48 8d 3d 05 77 00 00 	lea    0x7705(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    4bab:	e8 70 e5 ff ff       	call   3120 <fwp_trap>

0000000000004bb0 <fwp_block>:
    4bb0:	48 83 ec 08          	sub    $0x8,%rsp
    4bb4:	48 8b 05 ed aa 01 00 	mov    0x1aaed(%rip),%rax        # 1f6a8 <fwp_ready_head>
    4bbb:	48 85 c0             	test   %rax,%rax
    4bbe:	0f 84 1c 01 00 00    	je     4ce0 <fwp_block+0x130>
    4bc4:	90                   	nop
    4bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4bcc:	00 00 00 00 
    4bd0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4bd7:	48 89 15 ca aa 01 00 	mov    %rdx,0x1aaca(%rip)        # 1f6a8 <fwp_ready_head>
    4bde:	48 85 d2             	test   %rdx,%rdx
    4be1:	0f 84 19 01 00 00    	je     4d00 <fwp_block+0x150>
    4be7:	48 8b 15 d2 aa 01 00 	mov    0x1aad2(%rip),%rdx        # 1f6c0 <fwp_cur>
    4bee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4bf2:	48 39 c2             	cmp    %rax,%rdx
    4bf5:	0f 84 d5 00 00 00    	je     4cd0 <fwp_block+0x120>
    4bfb:	48 8b 0d 3e c7 01 00 	mov    0x1c73e(%rip),%rcx        # 21340 <fwp_state_owners>
    4c02:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4c06:	48 89 05 b3 aa 01 00 	mov    %rax,0x1aab3(%rip)        # 1f6c0 <fwp_cur>
    4c0d:	f3 0f 7e 05 53 c7 01 	movq   0x1c753(%rip),%xmm0        # 21368 <fwp_foreign_callbacks>
    4c14:	00 
    4c15:	0f 16 05 3c c7 01 00 	movhps 0x1c73c(%rip),%xmm0        # 21358 <fwp_state>
    4c1c:	f3 0f 7e 0d 3c c7 01 	movq   0x1c73c(%rip),%xmm1        # 21360 <fwp_handlers>
    4c23:	00 
    4c24:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4c2b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4c32:	0f 16 0d 37 c7 01 00 	movhps 0x1c737(%rip),%xmm1        # 21370 <fwp_cleanups>
    4c39:	f3 0f 7e 05 0f c7 01 	movq   0x1c70f(%rip),%xmm0        # 21350 <fwp_state_len>
    4c40:	00 
    4c41:	0f 16 05 00 c7 01 00 	movhps 0x1c700(%rip),%xmm0        # 21348 <fwp_state_cap>
    4c48:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4c4f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4c56:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4c5a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4c61:	48 89 0d f8 c6 01 00 	mov    %rcx,0x1c6f8(%rip)        # 21360 <fwp_handlers>
    4c68:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4c6f:	48 89 0d fa c6 01 00 	mov    %rcx,0x1c6fa(%rip)        # 21370 <fwp_cleanups>
    4c76:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4c7d:	48 89 0d e4 c6 01 00 	mov    %rcx,0x1c6e4(%rip)        # 21368 <fwp_foreign_callbacks>
    4c84:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4c8b:	48 89 0d c6 c6 01 00 	mov    %rcx,0x1c6c6(%rip)        # 21358 <fwp_state>
    4c92:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4c99:	48 89 0d b0 c6 01 00 	mov    %rcx,0x1c6b0(%rip)        # 21350 <fwp_state_len>
    4ca0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4ca7:	48 89 0d 9a c6 01 00 	mov    %rcx,0x1c69a(%rip)        # 21348 <fwp_state_cap>
    4cae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4cb5:	48 89 0d 84 c6 01 00 	mov    %rcx,0x1c684(%rip)        # 21340 <fwp_state_owners>
    4cbc:	e8 af d7 ff ff       	call   2470 <swapcontext@plt>
    4cc1:	f3 0f 1e fa          	endbr64
    4cc5:	e8 d6 fc ff ff       	call   49a0 <fwp_free_zombie>
    4cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4cd0:	8b 05 c2 a3 01 00    	mov    0x1a3c2(%rip),%eax        # 1f098 <fwp_slice>
    4cd6:	85 c0                	test   %eax,%eax
    4cd8:	74 36                	je     4d10 <fwp_block+0x160>
    4cda:	48 83 c4 08          	add    $0x8,%rsp
    4cde:	c3                   	ret
    4cdf:	90                   	nop
    4ce0:	e8 ab ee ff ff       	call   3b90 <fwp_poll_events>
    4ce5:	48 8b 05 bc a9 01 00 	mov    0x1a9bc(%rip),%rax        # 1f6a8 <fwp_ready_head>
    4cec:	48 85 c0             	test   %rax,%rax
    4cef:	0f 85 db fe ff ff    	jne    4bd0 <fwp_block+0x20>
    4cf5:	eb e9                	jmp    4ce0 <fwp_block+0x130>
    4cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4cfe:	00 00 
    4d00:	48 c7 05 95 a9 01 00 	movq   $0x0,0x1a995(%rip)        # 1f6a0 <fwp_ready_tail>
    4d07:	00 00 00 00 
    4d0b:	e9 d7 fe ff ff       	jmp    4be7 <fwp_block+0x37>
    4d10:	48 8d 3d a7 73 00 00 	lea    0x73a7(%rip),%rdi        # c0be <_IO_stdin_used+0xbe>
    4d17:	e8 64 d6 ff ff       	call   2380 <getenv@plt>
    4d1c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4d21:	48 85 c0             	test   %rax,%rax
    4d24:	74 05                	je     4d2b <fwp_block+0x17b>
    4d26:	80 38 00             	cmpb   $0x0,(%rax)
    4d29:	75 0b                	jne    4d36 <fwp_block+0x186>
    4d2b:	89 15 67 a3 01 00    	mov    %edx,0x1a367(%rip)        # 1f098 <fwp_slice>
    4d31:	48 83 c4 08          	add    $0x8,%rsp
    4d35:	c3                   	ret
    4d36:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d3b:	31 f6                	xor    %esi,%esi
    4d3d:	48 89 c7             	mov    %rax,%rdi
    4d40:	e8 eb d7 ff ff       	call   2530 <strtoll@plt>
    4d45:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4d49:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4d50:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4d55:	0f 46 d0             	cmovbe %eax,%edx
    4d58:	eb d1                	jmp    4d2b <fwp_block+0x17b>
    4d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004d60 <fwp_map_items>:
    4d60:	53                   	push   %rbx
    4d61:	48 89 fb             	mov    %rdi,%rbx
    4d64:	48 83 ec 10          	sub    $0x10,%rsp
    4d68:	48 85 ff             	test   %rdi,%rdi
    4d6b:	0f 84 6f 01 00 00    	je     4ee0 <fwp_map_items+0x180>
    4d71:	48 89 fa             	mov    %rdi,%rdx
    4d74:	31 c0                	xor    %eax,%eax
    4d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d7d:	00 00 00 
    4d80:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    4d84:	48 89 c1             	mov    %rax,%rcx
    4d87:	48 83 c0 01          	add    $0x1,%rax
    4d8b:	48 85 d2             	test   %rdx,%rdx
    4d8e:	75 f0                	jne    4d80 <fwp_map_items+0x20>
    4d90:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    4d97:	ff ff 1f 
    4d9a:	48 89 06             	mov    %rax,(%rsi)
    4d9d:	48 39 c2             	cmp    %rax,%rdx
    4da0:	0f 82 55 01 00 00    	jb     4efb <fwp_map_items+0x19b>
    4da6:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    4dad:	00 
    4dae:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    4db5:	0f 96 c2             	setbe  %dl
    4db8:	8b 0d c6 bc 01 00    	mov    0x1bcc6(%rip),%ecx        # 20a84 <fwp_heap+0x13a4>
    4dbe:	48 8d 05 1b a9 01 00 	lea    0x1a91b(%rip),%rax        # 1f6e0 <fwp_heap>
    4dc5:	85 c9                	test   %ecx,%ecx
    4dc7:	0f 84 ee 00 00 00    	je     4ebb <fwp_map_items+0x15b>
    4dcd:	84 d2                	test   %dl,%dl
    4dcf:	0f 84 e6 00 00 00    	je     4ebb <fwp_map_items+0x15b>
    4dd5:	48 8d 57 0f          	lea    0xf(%rdi),%rdx
    4dd9:	48 c1 ea 04          	shr    $0x4,%rdx
    4ddd:	0f b6 94 10 a0 0f 00 	movzbl 0xfa0(%rax,%rdx,1),%edx
    4de4:	00 
    4de5:	44 8b 84 90 00 0f 00 	mov    0xf00(%rax,%rdx,4),%r8d
    4dec:	00 
    4ded:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    4df1:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    4df5:	48 8b 88 80 07 00 00 	mov    0x780(%rax),%rcx
    4dfc:	48 85 c9             	test   %rcx,%rcx
    4dff:	0f 84 9b 00 00 00    	je     4ea0 <fwp_map_items+0x140>
    4e05:	48 8b 11             	mov    (%rcx),%rdx
    4e08:	48 f7 d2             	not    %rdx
    4e0b:	48 89 90 80 07 00 00 	mov    %rdx,0x780(%rax)
    4e12:	4c 89 c2             	mov    %r8,%rdx
    4e15:	48 89 cf             	mov    %rcx,%rdi
    4e18:	31 f6                	xor    %esi,%esi
    4e1a:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    4e1f:	e8 7c d6 ff ff       	call   24a0 <memset@plt>
    4e24:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4e29:	48 89 c1             	mov    %rax,%rcx
    4e2c:	4c 89 c0             	mov    %r8,%rax
    4e2f:	48 03 05 ca bc 01 00 	add    0x1bcca(%rip),%rax        # 20b00 <fwp_heap+0x1420>
    4e36:	0f 82 ba 00 00 00    	jb     4ef6 <fwp_map_items+0x196>
    4e3c:	48 39 05 c5 bc 01 00 	cmp    %rax,0x1bcc5(%rip)        # 20b08 <fwp_heap+0x1428>
    4e43:	48 89 05 b6 bc 01 00 	mov    %rax,0x1bcb6(%rip)        # 20b00 <fwp_heap+0x1420>
    4e4a:	73 07                	jae    4e53 <fwp_map_items+0xf3>
    4e4c:	48 89 05 b5 bc 01 00 	mov    %rax,0x1bcb5(%rip)        # 20b08 <fwp_heap+0x1428>
    4e53:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4e57:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4e5c:	f2 0f 58 05 b4 bc 01 	addsd  0x1bcb4(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    4e63:	00 
    4e64:	f2 0f 11 05 ac bc 01 	movsd  %xmm0,0x1bcac(%rip)        # 20b18 <fwp_heap+0x1438>
    4e6b:	00 
    4e6c:	48 89 c8             	mov    %rcx,%rax
    4e6f:	48 85 db             	test   %rbx,%rbx
    4e72:	74 21                	je     4e95 <fwp_map_items+0x135>
    4e74:	90                   	nop
    4e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e7c:	00 00 00 00 
    4e80:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    4e84:	48 83 c0 08          	add    $0x8,%rax
    4e88:	48 89 50 f8          	mov    %rdx,-0x8(%rax)
    4e8c:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    4e90:	48 85 db             	test   %rbx,%rbx
    4e93:	75 eb                	jne    4e80 <fwp_map_items+0x120>
    4e95:	48 83 c4 10          	add    $0x10,%rsp
    4e99:	48 89 c8             	mov    %rcx,%rax
    4e9c:	5b                   	pop    %rbx
    4e9d:	c3                   	ret
    4e9e:	66 90                	xchg   %ax,%ax
    4ea0:	48 8b 88 88 07 00 00 	mov    0x788(%rax),%rcx
    4ea7:	48 85 c9             	test   %rcx,%rcx
    4eaa:	74 0f                	je     4ebb <fwp_map_items+0x15b>
    4eac:	48 8b 90 90 07 00 00 	mov    0x790(%rax),%rdx
    4eb3:	48 29 ca             	sub    %rcx,%rdx
    4eb6:	4c 39 c2             	cmp    %r8,%rdx
    4eb9:	73 0f                	jae    4eca <fwp_map_items+0x16a>
    4ebb:	be 02 00 00 00       	mov    $0x2,%esi
    4ec0:	e8 4b f6 ff ff       	call   4510 <fwp_heap_alloc_slow>
    4ec5:	48 89 c1             	mov    %rax,%rcx
    4ec8:	eb a2                	jmp    4e6c <fwp_map_items+0x10c>
    4eca:	4a 8d 14 01          	lea    (%rcx,%r8,1),%rdx
    4ece:	48 89 90 88 07 00 00 	mov    %rdx,0x788(%rax)
    4ed5:	e9 38 ff ff ff       	jmp    4e12 <fwp_map_items+0xb2>
    4eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ee0:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    4ee7:	ba 01 00 00 00       	mov    $0x1,%edx
    4eec:	bf 08 00 00 00       	mov    $0x8,%edi
    4ef1:	e9 c2 fe ff ff       	jmp    4db8 <fwp_map_items+0x58>
    4ef6:	e8 75 dd ff ff       	call   2c70 <fwp_heap_oom>
    4efb:	48 8d 3d c8 71 00 00 	lea    0x71c8(%rip),%rdi        # c0ca <_IO_stdin_used+0xca>
    4f02:	e8 19 e2 ff ff       	call   3120 <fwp_trap>
    4f07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4f0e:	00 00 

0000000000004f10 <fwp_caps32>:
    4f10:	f3 0f 1e fa          	endbr64
    4f14:	85 f6                	test   %esi,%esi
    4f16:	74 08                	je     4f20 <fwp_caps32+0x10>
    4f18:	c3                   	ret
    4f19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f20:	48 8b 15 91 bb 01 00 	mov    0x1bb91(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    4f27:	48 89 f8             	mov    %rdi,%rax
    4f2a:	48 2b 05 5f bb 01 00 	sub    0x1bb5f(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    4f31:	48 c1 e2 10          	shl    $0x10,%rdx
    4f35:	48 39 d0             	cmp    %rdx,%rax
    4f38:	73 de                	jae    4f18 <fwp_caps32+0x8>
    4f3a:	48 89 c2             	mov    %rax,%rdx
    4f3d:	48 c1 ea 10          	shr    $0x10,%rdx
    4f41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f45:	48 8b 15 8c bb 01 00 	mov    0x1bb8c(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    4f4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f50:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f54:	48 85 c9             	test   %rcx,%rcx
    4f57:	74 bf                	je     4f18 <fwp_caps32+0x8>
    4f59:	0f b6 32             	movzbl (%rdx),%esi
    4f5c:	40 80 fe 02          	cmp    $0x2,%sil
    4f60:	74 2e                	je     4f90 <fwp_caps32+0x80>
    4f62:	40 80 fe 01          	cmp    $0x1,%sil
    4f66:	75 b0                	jne    4f18 <fwp_caps32+0x8>
    4f68:	8b 72 18             	mov    0x18(%rdx),%esi
    4f6b:	0f b7 c0             	movzwl %ax,%eax
    4f6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4f71:	48 0f af c6          	imul   %rsi,%rax
    4f75:	48 c1 e8 20          	shr    $0x20,%rax
    4f79:	48 39 d0             	cmp    %rdx,%rax
    4f7c:	73 9a                	jae    4f18 <fwp_caps32+0x8>
    4f7e:	48 01 c1             	add    %rax,%rcx
    4f81:	80 39 01             	cmpb   $0x1,(%rcx)
    4f84:	75 92                	jne    4f18 <fwp_caps32+0x8>
    4f86:	e9 05 f2 ff ff       	jmp    4190 <fwp_mem_free>
    4f8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f90:	66 85 c0             	test   %ax,%ax
    4f93:	74 ec                	je     4f81 <fwp_caps32+0x71>
    4f95:	c3                   	ret
    4f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f9d:	00 00 00 

0000000000004fa0 <fwp_caps45>:
    4fa0:	f3 0f 1e fa          	endbr64
    4fa4:	85 f6                	test   %esi,%esi
    4fa6:	74 08                	je     4fb0 <fwp_caps45+0x10>
    4fa8:	c3                   	ret
    4fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fb0:	48 8b 15 01 bb 01 00 	mov    0x1bb01(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    4fb7:	48 89 f8             	mov    %rdi,%rax
    4fba:	48 2b 05 cf ba 01 00 	sub    0x1bacf(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    4fc1:	48 c1 e2 10          	shl    $0x10,%rdx
    4fc5:	48 39 d0             	cmp    %rdx,%rax
    4fc8:	73 de                	jae    4fa8 <fwp_caps45+0x8>
    4fca:	48 89 c2             	mov    %rax,%rdx
    4fcd:	48 c1 ea 10          	shr    $0x10,%rdx
    4fd1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4fd5:	48 8b 15 fc ba 01 00 	mov    0x1bafc(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    4fdc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4fe0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4fe4:	48 85 c9             	test   %rcx,%rcx
    4fe7:	74 bf                	je     4fa8 <fwp_caps45+0x8>
    4fe9:	0f b6 32             	movzbl (%rdx),%esi
    4fec:	40 80 fe 02          	cmp    $0x2,%sil
    4ff0:	74 2e                	je     5020 <fwp_caps45+0x80>
    4ff2:	40 80 fe 01          	cmp    $0x1,%sil
    4ff6:	75 b0                	jne    4fa8 <fwp_caps45+0x8>
    4ff8:	8b 72 18             	mov    0x18(%rdx),%esi
    4ffb:	0f b7 c0             	movzwl %ax,%eax
    4ffe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5001:	48 0f af c6          	imul   %rsi,%rax
    5005:	48 c1 e8 20          	shr    $0x20,%rax
    5009:	48 39 d0             	cmp    %rdx,%rax
    500c:	73 9a                	jae    4fa8 <fwp_caps45+0x8>
    500e:	48 01 c1             	add    %rax,%rcx
    5011:	80 39 01             	cmpb   $0x1,(%rcx)
    5014:	75 92                	jne    4fa8 <fwp_caps45+0x8>
    5016:	e9 75 f1 ff ff       	jmp    4190 <fwp_mem_free>
    501b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5020:	66 85 c0             	test   %ax,%ax
    5023:	74 ec                	je     5011 <fwp_caps45+0x71>
    5025:	c3                   	ret
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 

0000000000005030 <fwp_caps69>:
    5030:	f3 0f 1e fa          	endbr64
    5034:	85 f6                	test   %esi,%esi
    5036:	74 08                	je     5040 <fwp_caps69+0x10>
    5038:	c3                   	ret
    5039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5040:	48 8b 15 71 ba 01 00 	mov    0x1ba71(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    5047:	48 89 f8             	mov    %rdi,%rax
    504a:	48 2b 05 3f ba 01 00 	sub    0x1ba3f(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5051:	48 c1 e2 10          	shl    $0x10,%rdx
    5055:	48 39 d0             	cmp    %rdx,%rax
    5058:	73 de                	jae    5038 <fwp_caps69+0x8>
    505a:	48 89 c2             	mov    %rax,%rdx
    505d:	48 c1 ea 10          	shr    $0x10,%rdx
    5061:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5065:	48 8b 15 6c ba 01 00 	mov    0x1ba6c(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    506c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5070:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    5074:	48 85 c9             	test   %rcx,%rcx
    5077:	74 bf                	je     5038 <fwp_caps69+0x8>
    5079:	0f b6 32             	movzbl (%rdx),%esi
    507c:	40 80 fe 02          	cmp    $0x2,%sil
    5080:	74 2e                	je     50b0 <fwp_caps69+0x80>
    5082:	40 80 fe 01          	cmp    $0x1,%sil
    5086:	75 b0                	jne    5038 <fwp_caps69+0x8>
    5088:	8b 72 18             	mov    0x18(%rdx),%esi
    508b:	0f b7 c0             	movzwl %ax,%eax
    508e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5091:	48 0f af c6          	imul   %rsi,%rax
    5095:	48 c1 e8 20          	shr    $0x20,%rax
    5099:	48 39 d0             	cmp    %rdx,%rax
    509c:	73 9a                	jae    5038 <fwp_caps69+0x8>
    509e:	48 01 c1             	add    %rax,%rcx
    50a1:	80 39 01             	cmpb   $0x1,(%rcx)
    50a4:	75 92                	jne    5038 <fwp_caps69+0x8>
    50a6:	e9 e5 f0 ff ff       	jmp    4190 <fwp_mem_free>
    50ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50b0:	66 85 c0             	test   %ax,%ax
    50b3:	74 ec                	je     50a1 <fwp_caps69+0x71>
    50b5:	c3                   	ret
    50b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50bd:	00 00 00 

00000000000050c0 <fwp_caps74>:
    50c0:	f3 0f 1e fa          	endbr64
    50c4:	85 f6                	test   %esi,%esi
    50c6:	74 08                	je     50d0 <fwp_caps74+0x10>
    50c8:	c3                   	ret
    50c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50d0:	48 8b 15 e1 b9 01 00 	mov    0x1b9e1(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    50d7:	48 89 f8             	mov    %rdi,%rax
    50da:	48 2b 05 af b9 01 00 	sub    0x1b9af(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    50e1:	48 c1 e2 10          	shl    $0x10,%rdx
    50e5:	48 39 d0             	cmp    %rdx,%rax
    50e8:	73 de                	jae    50c8 <fwp_caps74+0x8>
    50ea:	48 89 c2             	mov    %rax,%rdx
    50ed:	48 c1 ea 10          	shr    $0x10,%rdx
    50f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    50f5:	48 8b 15 dc b9 01 00 	mov    0x1b9dc(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    50fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5100:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    5104:	48 85 c9             	test   %rcx,%rcx
    5107:	74 bf                	je     50c8 <fwp_caps74+0x8>
    5109:	0f b6 32             	movzbl (%rdx),%esi
    510c:	40 80 fe 02          	cmp    $0x2,%sil
    5110:	74 2e                	je     5140 <fwp_caps74+0x80>
    5112:	40 80 fe 01          	cmp    $0x1,%sil
    5116:	75 b0                	jne    50c8 <fwp_caps74+0x8>
    5118:	8b 72 18             	mov    0x18(%rdx),%esi
    511b:	0f b7 c0             	movzwl %ax,%eax
    511e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5121:	48 0f af c6          	imul   %rsi,%rax
    5125:	48 c1 e8 20          	shr    $0x20,%rax
    5129:	48 39 d0             	cmp    %rdx,%rax
    512c:	73 9a                	jae    50c8 <fwp_caps74+0x8>
    512e:	48 01 c1             	add    %rax,%rcx
    5131:	80 39 01             	cmpb   $0x1,(%rcx)
    5134:	75 92                	jne    50c8 <fwp_caps74+0x8>
    5136:	e9 55 f0 ff ff       	jmp    4190 <fwp_mem_free>
    513b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5140:	66 85 c0             	test   %ax,%ax
    5143:	74 ec                	je     5131 <fwp_caps74+0x71>
    5145:	c3                   	ret
    5146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    514d:	00 00 00 

0000000000005150 <fwp_heap_alloc>:
    5150:	8b 05 2e b9 01 00    	mov    0x1b92e(%rip),%eax        # 20a84 <fwp_heap+0x13a4>
    5156:	48 89 fa             	mov    %rdi,%rdx
    5159:	89 f7                	mov    %esi,%edi
    515b:	85 c0                	test   %eax,%eax
    515d:	0f 84 f5 00 00 00    	je     5258 <fwp_heap_alloc+0x108>
    5163:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    516a:	0f 87 e8 00 00 00    	ja     5258 <fwp_heap_alloc+0x108>
    5170:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5174:	48 8d 05 65 a5 01 00 	lea    0x1a565(%rip),%rax        # 1f6e0 <fwp_heap>
    517b:	48 83 ec 18          	sub    $0x18,%rsp
    517f:	41 89 f0             	mov    %esi,%r8d
    5182:	48 c1 e9 04          	shr    $0x4,%rcx
    5186:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    518d:	00 
    518e:	48 63 cf             	movslq %edi,%rcx
    5191:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5198:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    519f:	00 
    51a0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    51a4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    51a8:	48 01 c8             	add    %rcx,%rax
    51ab:	48 8b 08             	mov    (%rax),%rcx
    51ae:	48 85 c9             	test   %rcx,%rcx
    51b1:	74 6d                	je     5220 <fwp_heap_alloc+0xd0>
    51b3:	48 8b 31             	mov    (%rcx),%rsi
    51b6:	48 f7 d6             	not    %rsi
    51b9:	48 89 30             	mov    %rsi,(%rax)
    51bc:	41 83 f8 01          	cmp    $0x1,%r8d
    51c0:	48 89 cf             	mov    %rcx,%rdi
    51c3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    51c8:	49 0f 45 d1          	cmovne %r9,%rdx
    51cc:	31 f6                	xor    %esi,%esi
    51ce:	e8 cd d2 ff ff       	call   24a0 <memset@plt>
    51d3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    51d8:	48 89 c1             	mov    %rax,%rcx
    51db:	4c 89 c8             	mov    %r9,%rax
    51de:	48 03 05 1b b9 01 00 	add    0x1b91b(%rip),%rax        # 20b00 <fwp_heap+0x1420>
    51e5:	72 7b                	jb     5262 <fwp_heap_alloc+0x112>
    51e7:	48 39 05 1a b9 01 00 	cmp    %rax,0x1b91a(%rip)        # 20b08 <fwp_heap+0x1428>
    51ee:	48 89 05 0b b9 01 00 	mov    %rax,0x1b90b(%rip)        # 20b00 <fwp_heap+0x1420>
    51f5:	73 07                	jae    51fe <fwp_heap_alloc+0xae>
    51f7:	48 89 05 0a b9 01 00 	mov    %rax,0x1b90a(%rip)        # 20b08 <fwp_heap+0x1428>
    51fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5202:	48 89 c8             	mov    %rcx,%rax
    5205:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    520a:	f2 0f 58 05 06 b9 01 	addsd  0x1b906(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    5211:	00 
    5212:	f2 0f 11 05 fe b8 01 	movsd  %xmm0,0x1b8fe(%rip)        # 20b18 <fwp_heap+0x1438>
    5219:	00 
    521a:	48 83 c4 18          	add    $0x18,%rsp
    521e:	c3                   	ret
    521f:	90                   	nop
    5220:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5224:	48 85 c9             	test   %rcx,%rcx
    5227:	74 0c                	je     5235 <fwp_heap_alloc+0xe5>
    5229:	48 8b 70 10          	mov    0x10(%rax),%rsi
    522d:	48 29 ce             	sub    %rcx,%rsi
    5230:	4c 39 ce             	cmp    %r9,%rsi
    5233:	73 13                	jae    5248 <fwp_heap_alloc+0xf8>
    5235:	89 fe                	mov    %edi,%esi
    5237:	48 83 c4 18          	add    $0x18,%rsp
    523b:	48 89 d7             	mov    %rdx,%rdi
    523e:	e9 cd f2 ff ff       	jmp    4510 <fwp_heap_alloc_slow>
    5243:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5248:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    524c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5250:	e9 67 ff ff ff       	jmp    51bc <fwp_heap_alloc+0x6c>
    5255:	0f 1f 00             	nopl   (%rax)
    5258:	89 fe                	mov    %edi,%esi
    525a:	48 89 d7             	mov    %rdx,%rdi
    525d:	e9 ae f2 ff ff       	jmp    4510 <fwp_heap_alloc_slow>
    5262:	e8 09 da ff ff       	call   2c70 <fwp_heap_oom>
    5267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    526e:	00 00 

0000000000005270 <fwp_data.part.0.constprop.0>:
    5270:	41 56                	push   %r14
    5272:	41 89 fe             	mov    %edi,%r14d
    5275:	41 54                	push   %r12
    5277:	49 89 f4             	mov    %rsi,%r12
    527a:	55                   	push   %rbp
    527b:	53                   	push   %rbx
    527c:	48 83 ec 08          	sub    $0x8,%rsp
    5280:	8b 05 fe b7 01 00    	mov    0x1b7fe(%rip),%eax        # 20a84 <fwp_heap+0x13a4>
    5286:	85 c0                	test   %eax,%eax
    5288:	0f 84 fa 00 00 00    	je     5388 <fwp_data.part.0.constprop.0+0x118>
    528e:	0f b6 05 ed b3 01 00 	movzbl 0x1b3ed(%rip),%eax        # 20682 <fwp_heap+0xfa2>
    5295:	48 8d 15 44 a4 01 00 	lea    0x1a444(%rip),%rdx        # 1f6e0 <fwp_heap>
    529c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    52a3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    52a7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    52ab:	48 8b 18             	mov    (%rax),%rbx
    52ae:	48 85 db             	test   %rbx,%rbx
    52b1:	0f 84 a9 00 00 00    	je     5360 <fwp_data.part.0.constprop.0+0xf0>
    52b7:	48 8b 13             	mov    (%rbx),%rdx
    52ba:	48 f7 d2             	not    %rdx
    52bd:	48 89 10             	mov    %rdx,(%rax)
    52c0:	48 83 fd 18          	cmp    $0x18,%rbp
    52c4:	76 1b                	jbe    52e1 <fwp_data.part.0.constprop.0+0x71>
    52c6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    52ca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    52ce:	31 f6                	xor    %esi,%esi
    52d0:	48 c1 e8 03          	shr    $0x3,%rax
    52d4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    52db:	00 
    52dc:	e8 bf d1 ff ff       	call   24a0 <memset@plt>
    52e1:	48 89 e8             	mov    %rbp,%rax
    52e4:	48 03 05 15 b8 01 00 	add    0x1b815(%rip),%rax        # 20b00 <fwp_heap+0x1420>
    52eb:	0f 82 a8 00 00 00    	jb     5399 <fwp_data.part.0.constprop.0+0x129>
    52f1:	48 39 05 10 b8 01 00 	cmp    %rax,0x1b810(%rip)        # 20b08 <fwp_heap+0x1428>
    52f8:	48 89 05 01 b8 01 00 	mov    %rax,0x1b801(%rip)        # 20b00 <fwp_heap+0x1420>
    52ff:	73 07                	jae    5308 <fwp_data.part.0.constprop.0+0x98>
    5301:	48 89 05 00 b8 01 00 	mov    %rax,0x1b800(%rip)        # 20b08 <fwp_heap+0x1428>
    5308:	66 0f ef c0          	pxor   %xmm0,%xmm0
    530c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5311:	f2 0f 58 05 ff b7 01 	addsd  0x1b7ff(%rip),%xmm0        # 20b18 <fwp_heap+0x1438>
    5318:	00 
    5319:	f2 0f 11 05 f7 b7 01 	movsd  %xmm0,0x1b7f7(%rip)        # 20b18 <fwp_heap+0x1438>
    5320:	00 
    5321:	b8 02 00 00 00       	mov    $0x2,%eax
    5326:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    532b:	66 0f 6e c8          	movd   %eax,%xmm1
    532f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5333:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5337:	49 8b 04 24          	mov    (%r12),%rax
    533b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    533f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5344:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5348:	48 83 c4 08          	add    $0x8,%rsp
    534c:	48 89 d8             	mov    %rbx,%rax
    534f:	5b                   	pop    %rbx
    5350:	5d                   	pop    %rbp
    5351:	41 5c                	pop    %r12
    5353:	41 5e                	pop    %r14
    5355:	c3                   	ret
    5356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    535d:	00 00 00 
    5360:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5364:	48 85 db             	test   %rbx,%rbx
    5367:	74 1f                	je     5388 <fwp_data.part.0.constprop.0+0x118>
    5369:	48 8b 50 10          	mov    0x10(%rax),%rdx
    536d:	48 29 da             	sub    %rbx,%rdx
    5370:	48 39 ea             	cmp    %rbp,%rdx
    5373:	72 13                	jb     5388 <fwp_data.part.0.constprop.0+0x118>
    5375:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5379:	48 89 50 08          	mov    %rdx,0x8(%rax)
    537d:	e9 3e ff ff ff       	jmp    52c0 <fwp_data.part.0.constprop.0+0x50>
    5382:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5388:	31 f6                	xor    %esi,%esi
    538a:	bf 18 00 00 00       	mov    $0x18,%edi
    538f:	e8 bc fd ff ff       	call   5150 <fwp_heap_alloc>
    5394:	48 89 c3             	mov    %rax,%rbx
    5397:	eb 88                	jmp    5321 <fwp_data.part.0.constprop.0+0xb1>
    5399:	e8 d2 d8 ff ff       	call   2c70 <fwp_heap_oom>
    539e:	66 90                	xchg   %ax,%ax

00000000000053a0 <fwp_map_finish_protected.isra.0>:
    53a0:	41 55                	push   %r13
    53a2:	41 54                	push   %r12
    53a4:	55                   	push   %rbp
    53a5:	53                   	push   %rbx
    53a6:	48 83 ec 38          	sub    $0x38,%rsp
    53aa:	48 8b 47 08          	mov    0x8(%rdi),%rax
    53ae:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    53b2:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    53b9:	00 00 
    53bb:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    53c0:	49 89 fc             	mov    %rdi,%r12
    53c3:	48 85 c0             	test   %rax,%rax
    53c6:	0f 84 d4 00 00 00    	je     54a0 <fwp_map_finish_protected.isra.0+0x100>
    53cc:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
    53d1:	4c 8d 2d 08 a3 01 00 	lea    0x1a308(%rip),%r13        # 1f6e0 <fwp_heap>
    53d8:	eb 4a                	jmp    5424 <fwp_map_finish_protected.isra.0+0x84>
    53da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    53e0:	40 80 fe 01          	cmp    $0x1,%sil
    53e4:	75 25                	jne    540b <fwp_map_finish_protected.isra.0+0x6b>
    53e6:	8b 71 18             	mov    0x18(%rcx),%esi
    53e9:	0f b7 c0             	movzwl %ax,%eax
    53ec:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    53ef:	48 0f af c6          	imul   %rsi,%rax
    53f3:	48 c1 e8 20          	shr    $0x20,%rax
    53f7:	48 39 c8             	cmp    %rcx,%rax
    53fa:	73 0f                	jae    540b <fwp_map_finish_protected.isra.0+0x6b>
    53fc:	48 01 c2             	add    %rax,%rdx
    53ff:	80 3a ff             	cmpb   $0xff,(%rdx)
    5402:	0f 84 c8 00 00 00    	je     54d0 <fwp_map_finish_protected.isra.0+0x130>
    5408:	c6 02 01             	movb   $0x1,(%rdx)
    540b:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5410:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
    5415:	48 83 e8 01          	sub    $0x1,%rax
    5419:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    541e:	0f 84 7c 00 00 00    	je     54a0 <fwp_map_finish_protected.isra.0+0x100>
    5424:	49 8b 14 24          	mov    (%r12),%rdx
    5428:	66 48 0f 6e cb       	movq   %rbx,%xmm1
    542d:	48 89 ee             	mov    %rbp,%rsi
    5430:	bf 01 00 00 00       	mov    $0x1,%edi
    5435:	f3 0f 7e 44 c2 f8    	movq   -0x8(%rdx,%rax,8),%xmm0
    543b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    543f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5444:	e8 27 fe ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    5449:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    5450:	48 89 c3             	mov    %rax,%rbx
    5453:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    545a:	48 c1 e2 10          	shl    $0x10,%rdx
    545e:	48 39 d0             	cmp    %rdx,%rax
    5461:	73 a8                	jae    540b <fwp_map_finish_protected.isra.0+0x6b>
    5463:	48 89 c2             	mov    %rax,%rdx
    5466:	48 c1 ea 10          	shr    $0x10,%rdx
    546a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    546e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    5475:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5479:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    547d:	48 85 d2             	test   %rdx,%rdx
    5480:	74 89                	je     540b <fwp_map_finish_protected.isra.0+0x6b>
    5482:	0f b6 31             	movzbl (%rcx),%esi
    5485:	40 80 fe 02          	cmp    $0x2,%sil
    5489:	0f 85 51 ff ff ff    	jne    53e0 <fwp_map_finish_protected.isra.0+0x40>
    548f:	66 85 c0             	test   %ax,%ax
    5492:	0f 85 73 ff ff ff    	jne    540b <fwp_map_finish_protected.isra.0+0x6b>
    5498:	e9 62 ff ff ff       	jmp    53ff <fwp_map_finish_protected.isra.0+0x5f>
    549d:	0f 1f 00             	nopl   (%rax)
    54a0:	49 8b 3c 24          	mov    (%r12),%rdi
    54a4:	e8 e7 ec ff ff       	call   4190 <fwp_mem_free>
    54a9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    54ae:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    54b5:	00 00 
    54b7:	75 2e                	jne    54e7 <fwp_map_finish_protected.isra.0+0x147>
    54b9:	48 83 c4 38          	add    $0x38,%rsp
    54bd:	48 89 d8             	mov    %rbx,%rax
    54c0:	5b                   	pop    %rbx
    54c1:	5d                   	pop    %rbp
    54c2:	41 5c                	pop    %r12
    54c4:	41 5d                	pop    %r13
    54c6:	c3                   	ret
    54c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ce:	00 00 
    54d0:	48 89 d7             	mov    %rdx,%rdi
    54d3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    54d8:	e8 73 ea ff ff       	call   3f50 <fwp_rc_forget_slot>
    54dd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    54e2:	e9 21 ff ff ff       	jmp    5408 <fwp_map_finish_protected.isra.0+0x68>
    54e7:	e8 54 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    54ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000054f0 <fwp_drop4>:
    54f0:	f3 0f 1e fa          	endbr64
    54f4:	48 8b 15 bd b5 01 00 	mov    0x1b5bd(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    54fb:	48 89 f8             	mov    %rdi,%rax
    54fe:	48 2b 05 8b b5 01 00 	sub    0x1b58b(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5505:	48 c1 e2 10          	shl    $0x10,%rdx
    5509:	48 39 d0             	cmp    %rdx,%rax
    550c:	73 67                	jae    5575 <fwp_drop4+0x85>
    550e:	48 89 c2             	mov    %rax,%rdx
    5511:	48 c1 ea 10          	shr    $0x10,%rdx
    5515:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5519:	48 8b 15 b8 b5 01 00 	mov    0x1b5b8(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    5520:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5524:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5528:	48 85 d2             	test   %rdx,%rdx
    552b:	74 48                	je     5575 <fwp_drop4+0x85>
    552d:	0f b6 31             	movzbl (%rcx),%esi
    5530:	40 80 fe 02          	cmp    $0x2,%sil
    5534:	74 3a                	je     5570 <fwp_drop4+0x80>
    5536:	40 80 fe 01          	cmp    $0x1,%sil
    553a:	75 39                	jne    5575 <fwp_drop4+0x85>
    553c:	8b 71 18             	mov    0x18(%rcx),%esi
    553f:	0f b7 c0             	movzwl %ax,%eax
    5542:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5545:	48 0f af c6          	imul   %rsi,%rax
    5549:	48 c1 e8 20          	shr    $0x20,%rax
    554d:	48 39 c8             	cmp    %rcx,%rax
    5550:	73 23                	jae    5575 <fwp_drop4+0x85>
    5552:	48 01 c2             	add    %rax,%rdx
    5555:	0f b6 02             	movzbl (%rdx),%eax
    5558:	84 c0                	test   %al,%al
    555a:	74 19                	je     5575 <fwp_drop4+0x85>
    555c:	3c 01                	cmp    $0x1,%al
    555e:	74 20                	je     5580 <fwp_drop4+0x90>
    5560:	3c ff                	cmp    $0xff,%al
    5562:	74 24                	je     5588 <fwp_drop4+0x98>
    5564:	83 e8 01             	sub    $0x1,%eax
    5567:	88 02                	mov    %al,(%rdx)
    5569:	c3                   	ret
    556a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5570:	66 85 c0             	test   %ax,%ax
    5573:	74 e0                	je     5555 <fwp_drop4+0x65>
    5575:	c3                   	ret
    5576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    557d:	00 00 00 
    5580:	e9 0b ec ff ff       	jmp    4190 <fwp_mem_free>
    5585:	0f 1f 00             	nopl   (%rax)
    5588:	48 89 d0             	mov    %rdx,%rax
    558b:	48 8d 35 4e a1 01 00 	lea    0x1a14e(%rip),%rsi        # 1f6e0 <fwp_heap>
    5592:	48 83 ec 18          	sub    $0x18,%rsp
    5596:	48 c1 e8 11          	shr    $0x11,%rax
    559a:	48 31 d0             	xor    %rdx,%rax
    559d:	48 89 c1             	mov    %rax,%rcx
    55a0:	48 c1 e9 09          	shr    $0x9,%rcx
    55a4:	48 31 c8             	xor    %rcx,%rax
    55a7:	0f b6 c8             	movzbl %al,%ecx
    55aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    55b1:	00 
    55b2:	48 85 c0             	test   %rax,%rax
    55b5:	75 12                	jne    55c9 <fwp_drop4+0xd9>
    55b7:	eb 49                	jmp    5602 <fwp_drop4+0x112>
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    55c4:	48 85 c0             	test   %rax,%rax
    55c7:	74 39                	je     5602 <fwp_drop4+0x112>
    55c9:	48 89 c1             	mov    %rax,%rcx
    55cc:	48 39 10             	cmp    %rdx,(%rax)
    55cf:	75 ef                	jne    55c0 <fwp_drop4+0xd0>
    55d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    55d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    55d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    55dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    55e4:	74 05                	je     55eb <fwp_drop4+0xfb>
    55e6:	48 83 c4 18          	add    $0x18,%rsp
    55ea:	c3                   	ret
    55eb:	48 89 d7             	mov    %rdx,%rdi
    55ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    55f3:	e8 58 e9 ff ff       	call   3f50 <fwp_rc_forget_slot>
    55f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    55fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    5600:	eb e4                	jmp    55e6 <fwp_drop4+0xf6>
    5602:	48 8d 3d a7 6c 00 00 	lea    0x6ca7(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    5609:	e8 12 db ff ff       	call   3120 <fwp_trap>
    560e:	66 90                	xchg   %ax,%ax

0000000000005610 <fwp_owned_entry50>:
    5610:	f3 0f 1e fa          	endbr64
    5614:	53                   	push   %rbx
    5615:	48 8b 3f             	mov    (%rdi),%rdi
    5618:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    561c:	e8 cf fe ff ff       	call   54f0 <fwp_drop4>
    5621:	48 89 d8             	mov    %rbx,%rax
    5624:	5b                   	pop    %rbx
    5625:	c3                   	ret
    5626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    562d:	00 00 00 

0000000000005630 <fwp_owned_entry47>:
    5630:	f3 0f 1e fa          	endbr64
    5634:	53                   	push   %rbx
    5635:	48 8b 3f             	mov    (%rdi),%rdi
    5638:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    563c:	e8 af fe ff ff       	call   54f0 <fwp_drop4>
    5641:	48 89 d8             	mov    %rbx,%rax
    5644:	5b                   	pop    %rbx
    5645:	c3                   	ret
    5646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    564d:	00 00 00 

0000000000005650 <fwp_arg_drop47>:
    5650:	f3 0f 1e fa          	endbr64
    5654:	85 f6                	test   %esi,%esi
    5656:	75 04                	jne    565c <fwp_arg_drop47+0xc>
    5658:	85 d2                	test   %edx,%edx
    565a:	75 04                	jne    5660 <fwp_arg_drop47+0x10>
    565c:	c3                   	ret
    565d:	0f 1f 00             	nopl   (%rax)
    5660:	48 8b 3f             	mov    (%rdi),%rdi
    5663:	e9 88 fe ff ff       	jmp    54f0 <fwp_drop4>
    5668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    566f:	00 

0000000000005670 <e50>:
    5670:	f3 0f 1e fa          	endbr64
    5674:	55                   	push   %rbp
    5675:	53                   	push   %rbx
    5676:	48 83 ec 08          	sub    $0x8,%rsp
    567a:	48 8b 1f             	mov    (%rdi),%rbx
    567d:	48 89 df             	mov    %rbx,%rdi
    5680:	e8 0b f0 ff ff       	call   4690 <fwp_rc_share>
    5685:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    5689:	48 89 df             	mov    %rbx,%rdi
    568c:	e8 5f fe ff ff       	call   54f0 <fwp_drop4>
    5691:	48 89 ef             	mov    %rbp,%rdi
    5694:	e8 f7 ef ff ff       	call   4690 <fwp_rc_share>
    5699:	48 83 c4 08          	add    $0x8,%rsp
    569d:	48 89 e8             	mov    %rbp,%rax
    56a0:	5b                   	pop    %rbx
    56a1:	5d                   	pop    %rbp
    56a2:	c3                   	ret
    56a3:	66 90                	xchg   %ax,%ax
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <e47>:
    56b0:	f3 0f 1e fa          	endbr64
    56b4:	55                   	push   %rbp
    56b5:	53                   	push   %rbx
    56b6:	48 83 ec 08          	sub    $0x8,%rsp
    56ba:	48 8b 1f             	mov    (%rdi),%rbx
    56bd:	48 89 df             	mov    %rbx,%rdi
    56c0:	e8 cb ef ff ff       	call   4690 <fwp_rc_share>
    56c5:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
    56c9:	48 89 df             	mov    %rbx,%rdi
    56cc:	e8 1f fe ff ff       	call   54f0 <fwp_drop4>
    56d1:	48 89 ef             	mov    %rbp,%rdi
    56d4:	e8 b7 ef ff ff       	call   4690 <fwp_rc_share>
    56d9:	48 83 c4 08          	add    $0x8,%rsp
    56dd:	48 89 e8             	mov    %rbp,%rax
    56e0:	5b                   	pop    %rbx
    56e1:	5d                   	pop    %rbp
    56e2:	c3                   	ret
    56e3:	66 90                	xchg   %ax,%ax
    56e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ec:	00 00 00 00 

00000000000056f0 <fwp_arg_drop50>:
    56f0:	f3 0f 1e fa          	endbr64
    56f4:	85 f6                	test   %esi,%esi
    56f6:	75 04                	jne    56fc <fwp_arg_drop50+0xc>
    56f8:	85 d2                	test   %edx,%edx
    56fa:	75 04                	jne    5700 <fwp_arg_drop50+0x10>
    56fc:	c3                   	ret
    56fd:	0f 1f 00             	nopl   (%rax)
    5700:	48 8b 3f             	mov    (%rdi),%rdi
    5703:	e9 e8 fd ff ff       	jmp    54f0 <fwp_drop4>
    5708:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    570f:	00 

0000000000005710 <fwp_args47>:
    5710:	f3 0f 1e fa          	endbr64
    5714:	85 d2                	test   %edx,%edx
    5716:	74 04                	je     571c <fwp_args47+0xc>
    5718:	85 f6                	test   %esi,%esi
    571a:	74 04                	je     5720 <fwp_args47+0x10>
    571c:	c3                   	ret
    571d:	0f 1f 00             	nopl   (%rax)
    5720:	48 8b 15 91 b3 01 00 	mov    0x1b391(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    5727:	48 8b 07             	mov    (%rdi),%rax
    572a:	48 2b 05 5f b3 01 00 	sub    0x1b35f(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5731:	48 c1 e2 10          	shl    $0x10,%rdx
    5735:	48 39 d0             	cmp    %rdx,%rax
    5738:	73 e2                	jae    571c <fwp_args47+0xc>
    573a:	48 89 c2             	mov    %rax,%rdx
    573d:	48 c1 ea 10          	shr    $0x10,%rdx
    5741:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5745:	48 8b 15 8c b3 01 00 	mov    0x1b38c(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    574c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5750:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5754:	48 85 ff             	test   %rdi,%rdi
    5757:	74 c3                	je     571c <fwp_args47+0xc>
    5759:	0f b6 0a             	movzbl (%rdx),%ecx
    575c:	80 f9 02             	cmp    $0x2,%cl
    575f:	74 2f                	je     5790 <fwp_args47+0x80>
    5761:	80 f9 01             	cmp    $0x1,%cl
    5764:	75 b6                	jne    571c <fwp_args47+0xc>
    5766:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5769:	0f b7 c0             	movzwl %ax,%eax
    576c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    576f:	48 0f af c1          	imul   %rcx,%rax
    5773:	48 c1 e8 20          	shr    $0x20,%rax
    5777:	48 39 d0             	cmp    %rdx,%rax
    577a:	73 a0                	jae    571c <fwp_args47+0xc>
    577c:	48 01 c7             	add    %rax,%rdi
    577f:	0f b6 07             	movzbl (%rdi),%eax
    5782:	84 c0                	test   %al,%al
    5784:	74 96                	je     571c <fwp_args47+0xc>
    5786:	3c fd                	cmp    $0xfd,%al
    5788:	77 0c                	ja     5796 <fwp_args47+0x86>
    578a:	83 c0 01             	add    $0x1,%eax
    578d:	88 07                	mov    %al,(%rdi)
    578f:	c3                   	ret
    5790:	66 85 c0             	test   %ax,%ax
    5793:	74 ea                	je     577f <fwp_args47+0x6f>
    5795:	c3                   	ret
    5796:	e9 95 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    579b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000057a0 <fwp_args50>:
    57a0:	f3 0f 1e fa          	endbr64
    57a4:	85 d2                	test   %edx,%edx
    57a6:	74 04                	je     57ac <fwp_args50+0xc>
    57a8:	85 f6                	test   %esi,%esi
    57aa:	74 04                	je     57b0 <fwp_args50+0x10>
    57ac:	c3                   	ret
    57ad:	0f 1f 00             	nopl   (%rax)
    57b0:	48 8b 15 01 b3 01 00 	mov    0x1b301(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    57b7:	48 8b 07             	mov    (%rdi),%rax
    57ba:	48 2b 05 cf b2 01 00 	sub    0x1b2cf(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    57c1:	48 c1 e2 10          	shl    $0x10,%rdx
    57c5:	48 39 d0             	cmp    %rdx,%rax
    57c8:	73 e2                	jae    57ac <fwp_args50+0xc>
    57ca:	48 89 c2             	mov    %rax,%rdx
    57cd:	48 c1 ea 10          	shr    $0x10,%rdx
    57d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    57d5:	48 8b 15 fc b2 01 00 	mov    0x1b2fc(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    57dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    57e0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    57e4:	48 85 ff             	test   %rdi,%rdi
    57e7:	74 c3                	je     57ac <fwp_args50+0xc>
    57e9:	0f b6 0a             	movzbl (%rdx),%ecx
    57ec:	80 f9 02             	cmp    $0x2,%cl
    57ef:	74 2f                	je     5820 <fwp_args50+0x80>
    57f1:	80 f9 01             	cmp    $0x1,%cl
    57f4:	75 b6                	jne    57ac <fwp_args50+0xc>
    57f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    57f9:	0f b7 c0             	movzwl %ax,%eax
    57fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    57ff:	48 0f af c1          	imul   %rcx,%rax
    5803:	48 c1 e8 20          	shr    $0x20,%rax
    5807:	48 39 d0             	cmp    %rdx,%rax
    580a:	73 a0                	jae    57ac <fwp_args50+0xc>
    580c:	48 01 c7             	add    %rax,%rdi
    580f:	0f b6 07             	movzbl (%rdi),%eax
    5812:	84 c0                	test   %al,%al
    5814:	74 96                	je     57ac <fwp_args50+0xc>
    5816:	3c fd                	cmp    $0xfd,%al
    5818:	77 0c                	ja     5826 <fwp_args50+0x86>
    581a:	83 c0 01             	add    $0x1,%eax
    581d:	88 07                	mov    %al,(%rdi)
    581f:	c3                   	ret
    5820:	66 85 c0             	test   %ax,%ax
    5823:	74 ea                	je     580f <fwp_args50+0x6f>
    5825:	c3                   	ret
    5826:	e9 05 e6 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    582b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005830 <fwp_caps47>:
    5830:	f3 0f 1e fa          	endbr64
    5834:	48 83 ec 18          	sub    $0x18,%rsp
    5838:	8b 57 04             	mov    0x4(%rdi),%edx
    583b:	48 89 f8             	mov    %rdi,%rax
    583e:	85 d2                	test   %edx,%edx
    5840:	0f 84 9a 00 00 00    	je     58e0 <fwp_caps47+0xb0>
    5846:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    584a:	85 f6                	test   %esi,%esi
    584c:	0f 85 9e 00 00 00    	jne    58f0 <fwp_caps47+0xc0>
    5852:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5857:	e8 94 fc ff ff       	call   54f0 <fwp_drop4>
    585c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5861:	48 8b 0d 50 b2 01 00 	mov    0x1b250(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    5868:	48 89 c2             	mov    %rax,%rdx
    586b:	48 2b 15 1e b2 01 00 	sub    0x1b21e(%rip),%rdx        # 20a90 <fwp_heap+0x13b0>
    5872:	48 c1 e1 10          	shl    $0x10,%rcx
    5876:	48 39 ca             	cmp    %rcx,%rdx
    5879:	73 6d                	jae    58e8 <fwp_caps47+0xb8>
    587b:	48 89 d1             	mov    %rdx,%rcx
    587e:	48 c1 e9 10          	shr    $0x10,%rcx
    5882:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5886:	48 8b 0d 4b b2 01 00 	mov    0x1b24b(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    588d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5891:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    5895:	48 85 f6             	test   %rsi,%rsi
    5898:	74 4e                	je     58e8 <fwp_caps47+0xb8>
    589a:	0f b6 39             	movzbl (%rcx),%edi
    589d:	40 80 ff 02          	cmp    $0x2,%dil
    58a1:	0f 84 b9 00 00 00    	je     5960 <fwp_caps47+0x130>
    58a7:	40 80 ff 01          	cmp    $0x1,%dil
    58ab:	75 3b                	jne    58e8 <fwp_caps47+0xb8>
    58ad:	8b 79 18             	mov    0x18(%rcx),%edi
    58b0:	0f b7 d2             	movzwl %dx,%edx
    58b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    58b6:	48 0f af d7          	imul   %rdi,%rdx
    58ba:	48 c1 ea 20          	shr    $0x20,%rdx
    58be:	48 39 ca             	cmp    %rcx,%rdx
    58c1:	73 25                	jae    58e8 <fwp_caps47+0xb8>
    58c3:	48 01 d6             	add    %rdx,%rsi
    58c6:	80 3e 01             	cmpb   $0x1,(%rsi)
    58c9:	75 1d                	jne    58e8 <fwp_caps47+0xb8>
    58cb:	48 89 c7             	mov    %rax,%rdi
    58ce:	48 83 c4 18          	add    $0x18,%rsp
    58d2:	e9 b9 e8 ff ff       	jmp    4190 <fwp_mem_free>
    58d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58de:	00 00 
    58e0:	85 f6                	test   %esi,%esi
    58e2:	0f 84 79 ff ff ff    	je     5861 <fwp_caps47+0x31>
    58e8:	48 83 c4 18          	add    $0x18,%rsp
    58ec:	c3                   	ret
    58ed:	0f 1f 00             	nopl   (%rax)
    58f0:	48 8b 05 c1 b1 01 00 	mov    0x1b1c1(%rip),%rax        # 20ab8 <fwp_heap+0x13d8>
    58f7:	48 2b 3d 92 b1 01 00 	sub    0x1b192(%rip),%rdi        # 20a90 <fwp_heap+0x13b0>
    58fe:	48 c1 e0 10          	shl    $0x10,%rax
    5902:	48 39 c7             	cmp    %rax,%rdi
    5905:	73 e1                	jae    58e8 <fwp_caps47+0xb8>
    5907:	48 89 f8             	mov    %rdi,%rax
    590a:	48 c1 e8 10          	shr    $0x10,%rax
    590e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5912:	48 8b 05 bf b1 01 00 	mov    0x1b1bf(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    5919:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    591d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    5921:	48 85 c0             	test   %rax,%rax
    5924:	74 c2                	je     58e8 <fwp_caps47+0xb8>
    5926:	0f b6 0a             	movzbl (%rdx),%ecx
    5929:	80 f9 02             	cmp    $0x2,%cl
    592c:	74 42                	je     5970 <fwp_caps47+0x140>
    592e:	80 f9 01             	cmp    $0x1,%cl
    5931:	75 b5                	jne    58e8 <fwp_caps47+0xb8>
    5933:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5936:	0f b7 ff             	movzwl %di,%edi
    5939:	8b 52 1c             	mov    0x1c(%rdx),%edx
    593c:	48 0f af f9          	imul   %rcx,%rdi
    5940:	48 c1 ef 20          	shr    $0x20,%rdi
    5944:	48 39 d7             	cmp    %rdx,%rdi
    5947:	73 9f                	jae    58e8 <fwp_caps47+0xb8>
    5949:	48 01 f8             	add    %rdi,%rax
    594c:	0f b6 10             	movzbl (%rax),%edx
    594f:	84 d2                	test   %dl,%dl
    5951:	74 95                	je     58e8 <fwp_caps47+0xb8>
    5953:	80 fa fd             	cmp    $0xfd,%dl
    5956:	77 23                	ja     597b <fwp_caps47+0x14b>
    5958:	83 c2 01             	add    $0x1,%edx
    595b:	88 10                	mov    %dl,(%rax)
    595d:	eb 89                	jmp    58e8 <fwp_caps47+0xb8>
    595f:	90                   	nop
    5960:	66 85 d2             	test   %dx,%dx
    5963:	0f 85 7f ff ff ff    	jne    58e8 <fwp_caps47+0xb8>
    5969:	e9 58 ff ff ff       	jmp    58c6 <fwp_caps47+0x96>
    596e:	66 90                	xchg   %ax,%ax
    5970:	66 85 ff             	test   %di,%di
    5973:	0f 85 6f ff ff ff    	jne    58e8 <fwp_caps47+0xb8>
    5979:	eb d1                	jmp    594c <fwp_caps47+0x11c>
    597b:	48 89 c7             	mov    %rax,%rdi
    597e:	48 83 c4 18          	add    $0x18,%rsp
    5982:	e9 a9 e4 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    598e:	00 00 

0000000000005990 <fwp_caps50>:
    5990:	f3 0f 1e fa          	endbr64
    5994:	48 83 ec 18          	sub    $0x18,%rsp
    5998:	8b 57 04             	mov    0x4(%rdi),%edx
    599b:	48 89 f8             	mov    %rdi,%rax
    599e:	85 d2                	test   %edx,%edx
    59a0:	0f 84 9a 00 00 00    	je     5a40 <fwp_caps50+0xb0>
    59a6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    59aa:	85 f6                	test   %esi,%esi
    59ac:	0f 85 9e 00 00 00    	jne    5a50 <fwp_caps50+0xc0>
    59b2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    59b7:	e8 34 fb ff ff       	call   54f0 <fwp_drop4>
    59bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    59c1:	48 8b 0d f0 b0 01 00 	mov    0x1b0f0(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    59c8:	48 89 c2             	mov    %rax,%rdx
    59cb:	48 2b 15 be b0 01 00 	sub    0x1b0be(%rip),%rdx        # 20a90 <fwp_heap+0x13b0>
    59d2:	48 c1 e1 10          	shl    $0x10,%rcx
    59d6:	48 39 ca             	cmp    %rcx,%rdx
    59d9:	73 6d                	jae    5a48 <fwp_caps50+0xb8>
    59db:	48 89 d1             	mov    %rdx,%rcx
    59de:	48 c1 e9 10          	shr    $0x10,%rcx
    59e2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    59e6:	48 8b 0d eb b0 01 00 	mov    0x1b0eb(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    59ed:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    59f1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    59f5:	48 85 f6             	test   %rsi,%rsi
    59f8:	74 4e                	je     5a48 <fwp_caps50+0xb8>
    59fa:	0f b6 39             	movzbl (%rcx),%edi
    59fd:	40 80 ff 02          	cmp    $0x2,%dil
    5a01:	0f 84 b9 00 00 00    	je     5ac0 <fwp_caps50+0x130>
    5a07:	40 80 ff 01          	cmp    $0x1,%dil
    5a0b:	75 3b                	jne    5a48 <fwp_caps50+0xb8>
    5a0d:	8b 79 18             	mov    0x18(%rcx),%edi
    5a10:	0f b7 d2             	movzwl %dx,%edx
    5a13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5a16:	48 0f af d7          	imul   %rdi,%rdx
    5a1a:	48 c1 ea 20          	shr    $0x20,%rdx
    5a1e:	48 39 ca             	cmp    %rcx,%rdx
    5a21:	73 25                	jae    5a48 <fwp_caps50+0xb8>
    5a23:	48 01 d6             	add    %rdx,%rsi
    5a26:	80 3e 01             	cmpb   $0x1,(%rsi)
    5a29:	75 1d                	jne    5a48 <fwp_caps50+0xb8>
    5a2b:	48 89 c7             	mov    %rax,%rdi
    5a2e:	48 83 c4 18          	add    $0x18,%rsp
    5a32:	e9 59 e7 ff ff       	jmp    4190 <fwp_mem_free>
    5a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a3e:	00 00 
    5a40:	85 f6                	test   %esi,%esi
    5a42:	0f 84 79 ff ff ff    	je     59c1 <fwp_caps50+0x31>
    5a48:	48 83 c4 18          	add    $0x18,%rsp
    5a4c:	c3                   	ret
    5a4d:	0f 1f 00             	nopl   (%rax)
    5a50:	48 8b 05 61 b0 01 00 	mov    0x1b061(%rip),%rax        # 20ab8 <fwp_heap+0x13d8>
    5a57:	48 2b 3d 32 b0 01 00 	sub    0x1b032(%rip),%rdi        # 20a90 <fwp_heap+0x13b0>
    5a5e:	48 c1 e0 10          	shl    $0x10,%rax
    5a62:	48 39 c7             	cmp    %rax,%rdi
    5a65:	73 e1                	jae    5a48 <fwp_caps50+0xb8>
    5a67:	48 89 f8             	mov    %rdi,%rax
    5a6a:	48 c1 e8 10          	shr    $0x10,%rax
    5a6e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5a72:	48 8b 05 5f b0 01 00 	mov    0x1b05f(%rip),%rax        # 20ad8 <fwp_heap+0x13f8>
    5a79:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    5a7d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    5a81:	48 85 c0             	test   %rax,%rax
    5a84:	74 c2                	je     5a48 <fwp_caps50+0xb8>
    5a86:	0f b6 0a             	movzbl (%rdx),%ecx
    5a89:	80 f9 02             	cmp    $0x2,%cl
    5a8c:	74 42                	je     5ad0 <fwp_caps50+0x140>
    5a8e:	80 f9 01             	cmp    $0x1,%cl
    5a91:	75 b5                	jne    5a48 <fwp_caps50+0xb8>
    5a93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5a96:	0f b7 ff             	movzwl %di,%edi
    5a99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5a9c:	48 0f af f9          	imul   %rcx,%rdi
    5aa0:	48 c1 ef 20          	shr    $0x20,%rdi
    5aa4:	48 39 d7             	cmp    %rdx,%rdi
    5aa7:	73 9f                	jae    5a48 <fwp_caps50+0xb8>
    5aa9:	48 01 f8             	add    %rdi,%rax
    5aac:	0f b6 10             	movzbl (%rax),%edx
    5aaf:	84 d2                	test   %dl,%dl
    5ab1:	74 95                	je     5a48 <fwp_caps50+0xb8>
    5ab3:	80 fa fd             	cmp    $0xfd,%dl
    5ab6:	77 23                	ja     5adb <fwp_caps50+0x14b>
    5ab8:	83 c2 01             	add    $0x1,%edx
    5abb:	88 10                	mov    %dl,(%rax)
    5abd:	eb 89                	jmp    5a48 <fwp_caps50+0xb8>
    5abf:	90                   	nop
    5ac0:	66 85 d2             	test   %dx,%dx
    5ac3:	0f 85 7f ff ff ff    	jne    5a48 <fwp_caps50+0xb8>
    5ac9:	e9 58 ff ff ff       	jmp    5a26 <fwp_caps50+0x96>
    5ace:	66 90                	xchg   %ax,%ax
    5ad0:	66 85 ff             	test   %di,%di
    5ad3:	0f 85 6f ff ff ff    	jne    5a48 <fwp_caps50+0xb8>
    5ad9:	eb d1                	jmp    5aac <fwp_caps50+0x11c>
    5adb:	48 89 c7             	mov    %rax,%rdi
    5ade:	48 83 c4 18          	add    $0x18,%rsp
    5ae2:	e9 49 e3 ff ff       	jmp    3e30 <fwp_rc_wide_dup>
    5ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5aee:	00 00 

0000000000005af0 <fwp_drop0>:
    5af0:	f3 0f 1e fa          	endbr64
    5af4:	48 8b 15 bd af 01 00 	mov    0x1afbd(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    5afb:	48 89 f8             	mov    %rdi,%rax
    5afe:	48 2b 05 8b af 01 00 	sub    0x1af8b(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5b05:	48 c1 e2 10          	shl    $0x10,%rdx
    5b09:	48 39 d0             	cmp    %rdx,%rax
    5b0c:	0f 83 36 01 00 00    	jae    5c48 <fwp_drop0+0x158>
    5b12:	48 83 ec 18          	sub    $0x18,%rsp
    5b16:	48 8d 35 c3 9b 01 00 	lea    0x19bc3(%rip),%rsi        # 1f6e0 <fwp_heap>
    5b1d:	48 89 c2             	mov    %rax,%rdx
    5b20:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    5b27:	48 c1 ea 10          	shr    $0x10,%rdx
    5b2b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    5b2f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    5b33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5b37:	48 85 d2             	test   %rdx,%rdx
    5b3a:	74 42                	je     5b7e <fwp_drop0+0x8e>
    5b3c:	44 0f b6 01          	movzbl (%rcx),%r8d
    5b40:	41 80 f8 02          	cmp    $0x2,%r8b
    5b44:	74 42                	je     5b88 <fwp_drop0+0x98>
    5b46:	41 80 f8 01          	cmp    $0x1,%r8b
    5b4a:	75 32                	jne    5b7e <fwp_drop0+0x8e>
    5b4c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    5b50:	0f b7 c0             	movzwl %ax,%eax
    5b53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5b56:	49 0f af c0          	imul   %r8,%rax
    5b5a:	48 c1 e8 20          	shr    $0x20,%rax
    5b5e:	48 39 c8             	cmp    %rcx,%rax
    5b61:	73 1b                	jae    5b7e <fwp_drop0+0x8e>
    5b63:	48 01 c2             	add    %rax,%rdx
    5b66:	0f b6 02             	movzbl (%rdx),%eax
    5b69:	84 c0                	test   %al,%al
    5b6b:	74 11                	je     5b7e <fwp_drop0+0x8e>
    5b6d:	3c 01                	cmp    $0x1,%al
    5b6f:	74 27                	je     5b98 <fwp_drop0+0xa8>
    5b71:	3c ff                	cmp    $0xff,%al
    5b73:	0f 84 e7 00 00 00    	je     5c60 <fwp_drop0+0x170>
    5b79:	83 e8 01             	sub    $0x1,%eax
    5b7c:	88 02                	mov    %al,(%rdx)
    5b7e:	48 83 c4 18          	add    $0x18,%rsp
    5b82:	c3                   	ret
    5b83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b88:	66 85 c0             	test   %ax,%ax
    5b8b:	74 d9                	je     5b66 <fwp_drop0+0x76>
    5b8d:	48 83 c4 18          	add    $0x18,%rsp
    5b91:	c3                   	ret
    5b92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b98:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5b9f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5ba6:	48 89 f8             	mov    %rdi,%rax
    5ba9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    5bad:	48 29 c8             	sub    %rcx,%rax
    5bb0:	48 c1 e2 10          	shl    $0x10,%rdx
    5bb4:	48 39 d0             	cmp    %rdx,%rax
    5bb7:	73 71                	jae    5c2a <fwp_drop0+0x13a>
    5bb9:	49 89 c2             	mov    %rax,%r10
    5bbc:	49 c1 ea 10          	shr    $0x10,%r10
    5bc0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    5bc4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    5bc8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    5bcc:	4d 85 d2             	test   %r10,%r10
    5bcf:	74 59                	je     5c2a <fwp_drop0+0x13a>
    5bd1:	45 0f b6 19          	movzbl (%r9),%r11d
    5bd5:	41 80 fb 02          	cmp    $0x2,%r11b
    5bd9:	74 75                	je     5c50 <fwp_drop0+0x160>
    5bdb:	41 80 fb 01          	cmp    $0x1,%r11b
    5bdf:	75 49                	jne    5c2a <fwp_drop0+0x13a>
    5be1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    5be5:	0f b7 c0             	movzwl %ax,%eax
    5be8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    5bec:	49 0f af c3          	imul   %r11,%rax
    5bf0:	48 c1 e8 20          	shr    $0x20,%rax
    5bf4:	4c 39 c8             	cmp    %r9,%rax
    5bf7:	73 31                	jae    5c2a <fwp_drop0+0x13a>
    5bf9:	49 01 c2             	add    %rax,%r10
    5bfc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5c00:	75 28                	jne    5c2a <fwp_drop0+0x13a>
    5c02:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5c07:	e8 84 e5 ff ff       	call   4190 <fwp_mem_free>
    5c0c:	48 8d 35 cd 9a 01 00 	lea    0x19acd(%rip),%rsi        # 1f6e0 <fwp_heap>
    5c13:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5c18:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5c1f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5c26:	48 c1 e2 10          	shl    $0x10,%rdx
    5c2a:	4c 89 c0             	mov    %r8,%rax
    5c2d:	48 29 c8             	sub    %rcx,%rax
    5c30:	48 39 d0             	cmp    %rdx,%rax
    5c33:	0f 83 45 ff ff ff    	jae    5b7e <fwp_drop0+0x8e>
    5c39:	4c 89 c7             	mov    %r8,%rdi
    5c3c:	e9 dc fe ff ff       	jmp    5b1d <fwp_drop0+0x2d>
    5c41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5c48:	c3                   	ret
    5c49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5c50:	66 85 c0             	test   %ax,%ax
    5c53:	75 d5                	jne    5c2a <fwp_drop0+0x13a>
    5c55:	eb a5                	jmp    5bfc <fwp_drop0+0x10c>
    5c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c5e:	00 00 
    5c60:	48 89 d0             	mov    %rdx,%rax
    5c63:	48 c1 e8 11          	shr    $0x11,%rax
    5c67:	48 31 d0             	xor    %rdx,%rax
    5c6a:	48 89 c1             	mov    %rax,%rcx
    5c6d:	48 c1 e9 09          	shr    $0x9,%rcx
    5c71:	48 31 c8             	xor    %rcx,%rax
    5c74:	0f b6 c8             	movzbl %al,%ecx
    5c77:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5c7e:	00 
    5c7f:	48 85 c0             	test   %rax,%rax
    5c82:	75 25                	jne    5ca9 <fwp_drop0+0x1b9>
    5c84:	eb 5e                	jmp    5ce4 <fwp_drop0+0x1f4>
    5c86:	0f 1f 40 00          	nopl   0x0(%rax)
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5ca4:	48 85 c0             	test   %rax,%rax
    5ca7:	74 3b                	je     5ce4 <fwp_drop0+0x1f4>
    5ca9:	48 89 c1             	mov    %rax,%rcx
    5cac:	48 39 10             	cmp    %rdx,(%rax)
    5caf:	75 ef                	jne    5ca0 <fwp_drop0+0x1b0>
    5cb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5cb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5cb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    5cbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5cc4:	0f 85 b4 fe ff ff    	jne    5b7e <fwp_drop0+0x8e>
    5cca:	48 89 d7             	mov    %rdx,%rdi
    5ccd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5cd2:	e8 79 e2 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5cd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5cdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    5cdf:	e9 9a fe ff ff       	jmp    5b7e <fwp_drop0+0x8e>
    5ce4:	48 8d 3d c5 65 00 00 	lea    0x65c5(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    5ceb:	e8 30 d4 ff ff       	call   3120 <fwp_trap>

0000000000005cf0 <fwp_drop1>:
    5cf0:	f3 0f 1e fa          	endbr64
    5cf4:	e9 f7 fd ff ff       	jmp    5af0 <fwp_drop0>
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005d00 <fwp_drop6>:
    5d00:	f3 0f 1e fa          	endbr64
    5d04:	48 8b 0d ad ad 01 00 	mov    0x1adad(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    5d0b:	48 89 f8             	mov    %rdi,%rax
    5d0e:	48 2b 05 7b ad 01 00 	sub    0x1ad7b(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5d15:	48 c1 e1 10          	shl    $0x10,%rcx
    5d19:	48 39 c8             	cmp    %rcx,%rax
    5d1c:	0f 83 56 01 00 00    	jae    5e78 <fwp_drop6+0x178>
    5d22:	48 83 ec 18          	sub    $0x18,%rsp
    5d26:	48 89 fa             	mov    %rdi,%rdx
    5d29:	4c 8d 05 b0 99 01 00 	lea    0x199b0(%rip),%r8        # 1f6e0 <fwp_heap>
    5d30:	48 89 c1             	mov    %rax,%rcx
    5d33:	48 c1 e9 10          	shr    $0x10,%rcx
    5d37:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5d3b:	49 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%rcx
    5d42:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    5d46:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    5d4a:	48 85 c9             	test   %rcx,%rcx
    5d4d:	74 40                	je     5d8f <fwp_drop6+0x8f>
    5d4f:	0f b6 3e             	movzbl (%rsi),%edi
    5d52:	40 80 ff 02          	cmp    $0x2,%dil
    5d56:	74 40                	je     5d98 <fwp_drop6+0x98>
    5d58:	40 80 ff 01          	cmp    $0x1,%dil
    5d5c:	75 31                	jne    5d8f <fwp_drop6+0x8f>
    5d5e:	8b 7e 18             	mov    0x18(%rsi),%edi
    5d61:	0f b7 c0             	movzwl %ax,%eax
    5d64:	8b 76 1c             	mov    0x1c(%rsi),%esi
    5d67:	48 0f af c7          	imul   %rdi,%rax
    5d6b:	48 c1 e8 20          	shr    $0x20,%rax
    5d6f:	48 39 f0             	cmp    %rsi,%rax
    5d72:	73 1b                	jae    5d8f <fwp_drop6+0x8f>
    5d74:	48 01 c1             	add    %rax,%rcx
    5d77:	0f b6 01             	movzbl (%rcx),%eax
    5d7a:	84 c0                	test   %al,%al
    5d7c:	74 11                	je     5d8f <fwp_drop6+0x8f>
    5d7e:	3c 01                	cmp    $0x1,%al
    5d80:	74 26                	je     5da8 <fwp_drop6+0xa8>
    5d82:	3c ff                	cmp    $0xff,%al
    5d84:	0f 84 06 01 00 00    	je     5e90 <fwp_drop6+0x190>
    5d8a:	83 e8 01             	sub    $0x1,%eax
    5d8d:	88 01                	mov    %al,(%rcx)
    5d8f:	48 83 c4 18          	add    $0x18,%rsp
    5d93:	c3                   	ret
    5d94:	0f 1f 40 00          	nopl   0x0(%rax)
    5d98:	66 85 c0             	test   %ax,%ax
    5d9b:	74 da                	je     5d77 <fwp_drop6+0x77>
    5d9d:	48 83 c4 18          	add    $0x18,%rsp
    5da1:	c3                   	ret
    5da2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5da8:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    5dac:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5db1:	e8 3a f7 ff ff       	call   54f0 <fwp_drop4>
    5db6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5dbb:	4c 8d 05 1e 99 01 00 	lea    0x1991e(%rip),%r8        # 1f6e0 <fwp_heap>
    5dc2:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5dc9:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5dd0:	48 89 d0             	mov    %rdx,%rax
    5dd3:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    5dd7:	48 29 f0             	sub    %rsi,%rax
    5dda:	48 c1 e1 10          	shl    $0x10,%rcx
    5dde:	48 39 c8             	cmp    %rcx,%rax
    5de1:	73 7a                	jae    5e5d <fwp_drop6+0x15d>
    5de3:	48 89 c7             	mov    %rax,%rdi
    5de6:	48 c1 ef 10          	shr    $0x10,%rdi
    5dea:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
    5dee:	49 8b b8 f8 13 00 00 	mov    0x13f8(%r8),%rdi
    5df5:	4a 8d 3c d7          	lea    (%rdi,%r10,8),%rdi
    5df9:	4c 8b 57 20          	mov    0x20(%rdi),%r10
    5dfd:	4d 85 d2             	test   %r10,%r10
    5e00:	74 5b                	je     5e5d <fwp_drop6+0x15d>
    5e02:	44 0f b6 1f          	movzbl (%rdi),%r11d
    5e06:	41 80 fb 02          	cmp    $0x2,%r11b
    5e0a:	74 74                	je     5e80 <fwp_drop6+0x180>
    5e0c:	41 80 fb 01          	cmp    $0x1,%r11b
    5e10:	75 4b                	jne    5e5d <fwp_drop6+0x15d>
    5e12:	44 8b 5f 18          	mov    0x18(%rdi),%r11d
    5e16:	0f b7 c0             	movzwl %ax,%eax
    5e19:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    5e1c:	49 0f af c3          	imul   %r11,%rax
    5e20:	48 c1 e8 20          	shr    $0x20,%rax
    5e24:	48 39 f8             	cmp    %rdi,%rax
    5e27:	73 34                	jae    5e5d <fwp_drop6+0x15d>
    5e29:	49 01 c2             	add    %rax,%r10
    5e2c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5e30:	75 2b                	jne    5e5d <fwp_drop6+0x15d>
    5e32:	48 89 d7             	mov    %rdx,%rdi
    5e35:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5e3a:	e8 51 e3 ff ff       	call   4190 <fwp_mem_free>
    5e3f:	4c 8d 05 9a 98 01 00 	lea    0x1989a(%rip),%r8        # 1f6e0 <fwp_heap>
    5e46:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5e4b:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5e52:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5e59:	48 c1 e1 10          	shl    $0x10,%rcx
    5e5d:	4c 89 c8             	mov    %r9,%rax
    5e60:	48 29 f0             	sub    %rsi,%rax
    5e63:	48 39 c8             	cmp    %rcx,%rax
    5e66:	0f 83 23 ff ff ff    	jae    5d8f <fwp_drop6+0x8f>
    5e6c:	4c 89 ca             	mov    %r9,%rdx
    5e6f:	e9 bc fe ff ff       	jmp    5d30 <fwp_drop6+0x30>
    5e74:	0f 1f 40 00          	nopl   0x0(%rax)
    5e78:	c3                   	ret
    5e79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e80:	66 85 c0             	test   %ax,%ax
    5e83:	75 d8                	jne    5e5d <fwp_drop6+0x15d>
    5e85:	eb a5                	jmp    5e2c <fwp_drop6+0x12c>
    5e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e8e:	00 00 
    5e90:	48 89 c8             	mov    %rcx,%rax
    5e93:	48 c1 e8 11          	shr    $0x11,%rax
    5e97:	48 31 c8             	xor    %rcx,%rax
    5e9a:	48 89 c2             	mov    %rax,%rdx
    5e9d:	48 c1 ea 09          	shr    $0x9,%rdx
    5ea1:	48 31 d0             	xor    %rdx,%rax
    5ea4:	0f b6 d0             	movzbl %al,%edx
    5ea7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    5eae:	00 
    5eaf:	48 85 c0             	test   %rax,%rax
    5eb2:	75 15                	jne    5ec9 <fwp_drop6+0x1c9>
    5eb4:	eb 4e                	jmp    5f04 <fwp_drop6+0x204>
    5eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ebd:	00 00 00 
    5ec0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    5ec4:	48 85 c0             	test   %rax,%rax
    5ec7:	74 3b                	je     5f04 <fwp_drop6+0x204>
    5ec9:	48 89 c2             	mov    %rax,%rdx
    5ecc:	48 39 08             	cmp    %rcx,(%rax)
    5ecf:	75 ef                	jne    5ec0 <fwp_drop6+0x1c0>
    5ed1:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5ed5:	48 83 ea 01          	sub    $0x1,%rdx
    5ed9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5edd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    5ee4:	0f 85 a5 fe ff ff    	jne    5d8f <fwp_drop6+0x8f>
    5eea:	48 89 cf             	mov    %rcx,%rdi
    5eed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ef2:	e8 59 e0 ff ff       	call   3f50 <fwp_rc_forget_slot>
    5ef7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efc:	c6 01 fe             	movb   $0xfe,(%rcx)
    5eff:	e9 8b fe ff ff       	jmp    5d8f <fwp_drop6+0x8f>
    5f04:	48 8d 3d a5 63 00 00 	lea    0x63a5(%rip),%rdi        # c2b0 <_IO_stdin_used+0x2b0>
    5f0b:	e8 10 d2 ff ff       	call   3120 <fwp_trap>

0000000000005f10 <fwp_owned_entry74>:
    5f10:	f3 0f 1e fa          	endbr64
    5f14:	48 83 ec 38          	sub    $0x38,%rsp
    5f18:	f2 0f 10 1f          	movsd  (%rdi),%xmm3
    5f1c:	f3 0f 7e 4f 08       	movq   0x8(%rdi),%xmm1
    5f21:	31 ff                	xor    %edi,%edi
    5f23:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5f2a:	00 00 
    5f2c:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    5f31:	31 c0                	xor    %eax,%eax
    5f33:	f2 0f 10 15 45 65 00 	movsd  0x6545(%rip),%xmm2        # c480 <msg.3+0x30>
    5f3a:	00 
    5f3b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    5f40:	66 0f 28 c3          	movapd %xmm3,%xmm0
    5f44:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5f48:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    5f4c:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    5f50:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    5f54:	f2 0f 10 05 1c 65 00 	movsd  0x651c(%rip),%xmm0        # c478 <msg.3+0x28>
    5f5b:	00 
    5f5c:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5f60:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    5f64:	f2 0f 59 0d 1c 65 00 	mulsd  0x651c(%rip),%xmm1        # c488 <msg.3+0x38>
    5f6b:	00 
    5f6c:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    5f70:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    5f74:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5f79:	e8 f2 f2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    5f7e:	48 8b 15 33 ab 01 00 	mov    0x1ab33(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    5f85:	48 89 c6             	mov    %rax,%rsi
    5f88:	48 2b 05 01 ab 01 00 	sub    0x1ab01(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    5f8f:	48 c1 e2 10          	shl    $0x10,%rdx
    5f93:	48 39 d0             	cmp    %rdx,%rax
    5f96:	73 4f                	jae    5fe7 <fwp_owned_entry74+0xd7>
    5f98:	48 89 c2             	mov    %rax,%rdx
    5f9b:	48 c1 ea 10          	shr    $0x10,%rdx
    5f9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5fa3:	48 8b 15 2e ab 01 00 	mov    0x1ab2e(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    5faa:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5fae:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5fb2:	48 85 d2             	test   %rdx,%rdx
    5fb5:	74 30                	je     5fe7 <fwp_owned_entry74+0xd7>
    5fb7:	0f b6 39             	movzbl (%rcx),%edi
    5fba:	40 80 ff 02          	cmp    $0x2,%dil
    5fbe:	74 40                	je     6000 <fwp_owned_entry74+0xf0>
    5fc0:	40 80 ff 01          	cmp    $0x1,%dil
    5fc4:	75 21                	jne    5fe7 <fwp_owned_entry74+0xd7>
    5fc6:	8b 79 18             	mov    0x18(%rcx),%edi
    5fc9:	0f b7 c0             	movzwl %ax,%eax
    5fcc:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5fcf:	48 0f af c7          	imul   %rdi,%rax
    5fd3:	48 c1 e8 20          	shr    $0x20,%rax
    5fd7:	48 39 c8             	cmp    %rcx,%rax
    5fda:	73 0b                	jae    5fe7 <fwp_owned_entry74+0xd7>
    5fdc:	48 01 c2             	add    %rax,%rdx
    5fdf:	80 3a ff             	cmpb   $0xff,(%rdx)
    5fe2:	74 2c                	je     6010 <fwp_owned_entry74+0x100>
    5fe4:	c6 02 01             	movb   $0x1,(%rdx)
    5fe7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    5fec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5ff3:	00 00 
    5ff5:	75 35                	jne    602c <fwp_owned_entry74+0x11c>
    5ff7:	48 89 f0             	mov    %rsi,%rax
    5ffa:	48 83 c4 38          	add    $0x38,%rsp
    5ffe:	c3                   	ret
    5fff:	90                   	nop
    6000:	66 85 c0             	test   %ax,%ax
    6003:	75 e2                	jne    5fe7 <fwp_owned_entry74+0xd7>
    6005:	eb d8                	jmp    5fdf <fwp_owned_entry74+0xcf>
    6007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    600e:	00 00 
    6010:	48 89 d7             	mov    %rdx,%rdi
    6013:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6018:	48 89 14 24          	mov    %rdx,(%rsp)
    601c:	e8 2f df ff ff       	call   3f50 <fwp_rc_forget_slot>
    6021:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6026:	48 8b 14 24          	mov    (%rsp),%rdx
    602a:	eb b8                	jmp    5fe4 <fwp_owned_entry74+0xd4>
    602c:	e8 0f c4 ff ff       	call   2440 <__stack_chk_fail@plt>
    6031:	0f 1f 40 00          	nopl   0x0(%rax)
    6035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    603c:	00 00 00 00 

0000000000006040 <e74>:
    6040:	f3 0f 1e fa          	endbr64
    6044:	53                   	push   %rbx
    6045:	48 83 ec 30          	sub    $0x30,%rsp
    6049:	f2 0f 10 1f          	movsd  (%rdi),%xmm3
    604d:	f3 0f 7e 4f 08       	movq   0x8(%rdi),%xmm1
    6052:	31 ff                	xor    %edi,%edi
    6054:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    605b:	00 00 
    605d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6062:	31 c0                	xor    %eax,%eax
    6064:	f2 0f 10 15 14 64 00 	movsd  0x6414(%rip),%xmm2        # c480 <msg.3+0x30>
    606b:	00 
    606c:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6071:	66 0f 28 c3          	movapd %xmm3,%xmm0
    6075:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    6079:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    607d:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6081:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6085:	f2 0f 10 05 eb 63 00 	movsd  0x63eb(%rip),%xmm0        # c478 <msg.3+0x28>
    608c:	00 
    608d:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    6091:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6095:	f2 0f 59 0d eb 63 00 	mulsd  0x63eb(%rip),%xmm1        # c488 <msg.3+0x38>
    609c:	00 
    609d:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    60a1:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    60a5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    60aa:	e8 c1 f1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    60af:	48 8b 15 02 aa 01 00 	mov    0x1aa02(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    60b6:	48 89 c3             	mov    %rax,%rbx
    60b9:	48 2b 05 d0 a9 01 00 	sub    0x1a9d0(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    60c0:	48 c1 e2 10          	shl    $0x10,%rdx
    60c4:	48 39 d0             	cmp    %rdx,%rax
    60c7:	73 4f                	jae    6118 <e74+0xd8>
    60c9:	48 89 c2             	mov    %rax,%rdx
    60cc:	48 c1 ea 10          	shr    $0x10,%rdx
    60d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    60d4:	48 8b 15 fd a9 01 00 	mov    0x1a9fd(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    60db:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    60df:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    60e3:	48 85 d2             	test   %rdx,%rdx
    60e6:	74 30                	je     6118 <e74+0xd8>
    60e8:	0f b6 31             	movzbl (%rcx),%esi
    60eb:	40 80 fe 02          	cmp    $0x2,%sil
    60ef:	74 4f                	je     6140 <e74+0x100>
    60f1:	40 80 fe 01          	cmp    $0x1,%sil
    60f5:	75 21                	jne    6118 <e74+0xd8>
    60f7:	8b 71 18             	mov    0x18(%rcx),%esi
    60fa:	0f b7 c0             	movzwl %ax,%eax
    60fd:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6100:	48 0f af c6          	imul   %rsi,%rax
    6104:	48 c1 e8 20          	shr    $0x20,%rax
    6108:	48 39 c8             	cmp    %rcx,%rax
    610b:	73 0b                	jae    6118 <e74+0xd8>
    610d:	48 01 c2             	add    %rax,%rdx
    6110:	80 3a ff             	cmpb   $0xff,(%rdx)
    6113:	74 3b                	je     6150 <e74+0x110>
    6115:	c6 02 01             	movb   $0x1,(%rdx)
    6118:	48 89 df             	mov    %rbx,%rdi
    611b:	e8 70 e5 ff ff       	call   4690 <fwp_rc_share>
    6120:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6125:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    612c:	00 00 
    612e:	75 34                	jne    6164 <e74+0x124>
    6130:	48 83 c4 30          	add    $0x30,%rsp
    6134:	48 89 d8             	mov    %rbx,%rax
    6137:	5b                   	pop    %rbx
    6138:	c3                   	ret
    6139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6140:	66 85 c0             	test   %ax,%ax
    6143:	75 d3                	jne    6118 <e74+0xd8>
    6145:	eb c9                	jmp    6110 <e74+0xd0>
    6147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    614e:	00 00 
    6150:	48 89 d7             	mov    %rdx,%rdi
    6153:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6158:	e8 f3 dd ff ff       	call   3f50 <fwp_rc_forget_slot>
    615d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6162:	eb b1                	jmp    6115 <e74+0xd5>
    6164:	e8 d7 c2 ff ff       	call   2440 <__stack_chk_fail@plt>
    6169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006170 <fwp_loop_fields68.constprop.0>:
    6170:	41 57                	push   %r15
    6172:	48 8d 05 77 f9 ff ff 	lea    -0x689(%rip),%rax        # 5af0 <fwp_drop0>
    6179:	41 56                	push   %r14
    617b:	66 48 0f 6e f0       	movq   %rax,%xmm6
    6180:	48 8d 05 79 fb ff ff 	lea    -0x487(%rip),%rax        # 5d00 <fwp_drop6>
    6187:	41 55                	push   %r13
    6189:	66 48 0f 6e f8       	movq   %rax,%xmm7
    618e:	31 c0                	xor    %eax,%eax
    6190:	41 54                	push   %r12
    6192:	55                   	push   %rbp
    6193:	53                   	push   %rbx
    6194:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    619b:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    61a0:	64 48 8b 14 25 28 00 	mov    %fs:0x28,%rdx
    61a7:	00 00 
    61a9:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
    61b0:	00 
    61b1:	31 d2                	xor    %edx,%edx
    61b3:	48 c7 44 24 38 c6 00 	movq   $0xc6,0x38(%rsp)
    61ba:	00 00 
    61bc:	66 48 0f 6e ea       	movq   %rdx,%xmm5
    61c1:	66 0f 6c ee          	punpcklqdq %xmm6,%xmm5
    61c5:	f3 0f 7e 35 43 8a 00 	movq   0x8a43(%rip),%xmm6        # ec10 <d0+0x70>
    61cc:	00 
    61cd:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    61d2:	66 0f 6c f7          	punpcklqdq %xmm7,%xmm6
    61d6:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 85 27 c5 ff ff    	jne    270b <fwp_loop_fields68.constprop.0.cold>
    61e4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    61e9:	48 85 c0             	test   %rax,%rax
    61ec:	0f 84 79 0a 00 00    	je     6c6b <fwp_loop_fields68.constprop.0+0xafb>
    61f2:	4c 8b 78 10          	mov    0x10(%rax),%r15
    61f6:	48 8b 0d bb a8 01 00 	mov    0x1a8bb(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    61fd:	4c 89 f8             	mov    %r15,%rax
    6200:	48 2b 05 89 a8 01 00 	sub    0x1a889(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    6207:	4c 8d 25 d2 94 01 00 	lea    0x194d2(%rip),%r12        # 1f6e0 <fwp_heap>
    620e:	48 c1 e1 10          	shl    $0x10,%rcx
    6212:	48 39 c8             	cmp    %rcx,%rax
    6215:	73 5f                	jae    6276 <fwp_loop_fields68.constprop.0+0x106>
    6217:	48 89 c1             	mov    %rax,%rcx
    621a:	48 c1 e9 10          	shr    $0x10,%rcx
    621e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6222:	48 8b 0d af a8 01 00 	mov    0x1a8af(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    6229:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    622d:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    6231:	48 85 ff             	test   %rdi,%rdi
    6234:	74 40                	je     6276 <fwp_loop_fields68.constprop.0+0x106>
    6236:	0f b6 31             	movzbl (%rcx),%esi
    6239:	40 80 fe 02          	cmp    $0x2,%sil
    623d:	0f 84 ed 09 00 00    	je     6c30 <fwp_loop_fields68.constprop.0+0xac0>
    6243:	40 80 fe 01          	cmp    $0x1,%sil
    6247:	75 2d                	jne    6276 <fwp_loop_fields68.constprop.0+0x106>
    6249:	8b 71 18             	mov    0x18(%rcx),%esi
    624c:	0f b7 c0             	movzwl %ax,%eax
    624f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6252:	48 0f af c6          	imul   %rsi,%rax
    6256:	48 c1 e8 20          	shr    $0x20,%rax
    625a:	48 39 c8             	cmp    %rcx,%rax
    625d:	73 17                	jae    6276 <fwp_loop_fields68.constprop.0+0x106>
    625f:	48 01 c7             	add    %rax,%rdi
    6262:	0f b6 07             	movzbl (%rdi),%eax
    6265:	84 c0                	test   %al,%al
    6267:	74 0d                	je     6276 <fwp_loop_fields68.constprop.0+0x106>
    6269:	3c fd                	cmp    $0xfd,%al
    626b:	0f 87 0c 0a 00 00    	ja     6c7d <fwp_loop_fields68.constprop.0+0xb0d>
    6271:	83 c0 01             	add    $0x1,%eax
    6274:	88 07                	mov    %al,(%rdi)
    6276:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    627b:	4c 89 ff             	mov    %r15,%rdi
    627e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
    6283:	e8 d8 ea ff ff       	call   4d60 <fwp_map_items>
    6288:	66 0f 6f 7c 24 50    	movdqa 0x50(%rsp),%xmm7
    628e:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6293:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    629a:	00 00 00 00 00 
    629f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    62a4:	49 89 c5             	mov    %rax,%r13
    62a7:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
    62ac:	48 89 c6             	mov    %rax,%rsi
    62af:	48 89 04 24          	mov    %rax,(%rsp)
    62b3:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    62ba:	00 
    62bb:	e8 a0 ea ff ff       	call   4d60 <fwp_map_items>
    62c0:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
    62c5:	49 89 c6             	mov    %rax,%r14
    62c8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    62cd:	49 39 c1             	cmp    %rax,%r9
    62d0:	49 0f 46 c1          	cmovbe %r9,%rax
    62d4:	48 89 c2             	mov    %rax,%rdx
    62d7:	48 85 c0             	test   %rax,%rax
    62da:	0f 84 d0 08 00 00    	je     6bb0 <fwp_loop_fields68.constprop.0+0xa40>
    62e0:	31 ed                	xor    %ebp,%ebp
    62e2:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    62e7:	48 8d 9c 24 b0 00 00 	lea    0xb0(%rsp),%rbx
    62ee:	00 
    62ef:	4d 89 f7             	mov    %r14,%r15
    62f2:	4d 89 ee             	mov    %r13,%r14
    62f5:	49 89 ed             	mov    %rbp,%r13
    62f8:	48 89 c5             	mov    %rax,%rbp
    62fb:	eb 40                	jmp    633d <fwp_loop_fields68.constprop.0+0x1cd>
    62fd:	0f 1f 00             	nopl   (%rax)
    6300:	41 80 f8 01          	cmp    $0x1,%r8b
    6304:	75 26                	jne    632c <fwp_loop_fields68.constprop.0+0x1bc>
    6306:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    630a:	0f b7 c0             	movzwl %ax,%eax
    630d:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    6310:	49 0f af c0          	imul   %r8,%rax
    6314:	48 c1 e8 20          	shr    $0x20,%rax
    6318:	48 39 f8             	cmp    %rdi,%rax
    631b:	73 0f                	jae    632c <fwp_loop_fields68.constprop.0+0x1bc>
    631d:	48 01 c1             	add    %rax,%rcx
    6320:	80 39 ff             	cmpb   $0xff,(%rcx)
    6323:	0f 84 27 08 00 00    	je     6b50 <fwp_loop_fields68.constprop.0+0x9e0>
    6329:	c6 01 01             	movb   $0x1,(%rcx)
    632c:	4b 89 34 ee          	mov    %rsi,(%r14,%r13,8)
    6330:	49 83 c5 01          	add    $0x1,%r13
    6334:	4c 39 ed             	cmp    %r13,%rbp
    6337:	0f 84 d3 00 00 00    	je     6410 <fwp_loop_fields68.constprop.0+0x2a0>
    633d:	f2 43 0f 10 1c ef    	movsd  (%r15,%r13,8),%xmm3
    6343:	f2 43 0f 10 0c ee    	movsd  (%r14,%r13,8),%xmm1
    6349:	48 89 de             	mov    %rbx,%rsi
    634c:	31 ff                	xor    %edi,%edi
    634e:	f2 0f 10 15 2a 61 00 	movsd  0x612a(%rip),%xmm2        # c480 <msg.3+0x30>
    6355:	00 
    6356:	66 0f 28 c3          	movapd %xmm3,%xmm0
    635a:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    635e:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    6362:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6366:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    636a:	f2 0f 10 05 06 61 00 	movsd  0x6106(%rip),%xmm0        # c478 <msg.3+0x28>
    6371:	00 
    6372:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    6376:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    637a:	f2 0f 59 0d 06 61 00 	mulsd  0x6106(%rip),%xmm1        # c488 <msg.3+0x38>
    6381:	00 
    6382:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    6386:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    638a:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    6391:	00 
    6392:	e8 d9 ee ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    6397:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    639e:	00 
    639f:	48 89 c6             	mov    %rax,%rsi
    63a2:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    63a9:	00 
    63aa:	48 c1 e1 10          	shl    $0x10,%rcx
    63ae:	48 39 c8             	cmp    %rcx,%rax
    63b1:	0f 83 75 ff ff ff    	jae    632c <fwp_loop_fields68.constprop.0+0x1bc>
    63b7:	48 89 c1             	mov    %rax,%rcx
    63ba:	48 c1 e9 10          	shr    $0x10,%rcx
    63be:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    63c2:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    63c9:	00 
    63ca:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    63ce:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    63d2:	48 85 c9             	test   %rcx,%rcx
    63d5:	0f 84 51 ff ff ff    	je     632c <fwp_loop_fields68.constprop.0+0x1bc>
    63db:	44 0f b6 07          	movzbl (%rdi),%r8d
    63df:	41 80 f8 02          	cmp    $0x2,%r8b
    63e3:	0f 85 17 ff ff ff    	jne    6300 <fwp_loop_fields68.constprop.0+0x190>
    63e9:	66 85 c0             	test   %ax,%ax
    63ec:	0f 84 2e ff ff ff    	je     6320 <fwp_loop_fields68.constprop.0+0x1b0>
    63f2:	4b 89 34 ee          	mov    %rsi,(%r14,%r13,8)
    63f6:	49 83 c5 01          	add    $0x1,%r13
    63fa:	4c 39 ed             	cmp    %r13,%rbp
    63fd:	0f 85 3a ff ff ff    	jne    633d <fwp_loop_fields68.constprop.0+0x1cd>
    6403:	66 90                	xchg   %ax,%ax
    6405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    640c:	00 00 00 00 
    6410:	4d 89 fe             	mov    %r15,%r14
    6413:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    6418:	48 89 ea             	mov    %rbp,%rdx
    641b:	4c 89 f7             	mov    %r14,%rdi
    641e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6423:	e8 68 dd ff ff       	call   4190 <fwp_mem_free>
    6428:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    642d:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    6432:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6437:	48 89 c7             	mov    %rax,%rdi
    643a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    643f:	e8 5c ef ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    6444:	4c 89 ff             	mov    %r15,%rdi
    6447:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    644c:	e8 9f f6 ff ff       	call   5af0 <fwp_drop0>
    6451:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6455:	bf 01 00 00 00       	mov    $0x1,%edi
    645a:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    6461:	00 
    6462:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    6469:	00 
    646a:	e8 01 ee ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    646f:	48 8b 0d 42 a6 01 00 	mov    0x1a642(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    6476:	49 89 c6             	mov    %rax,%r14
    6479:	48 2b 05 10 a6 01 00 	sub    0x1a610(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    6480:	48 c1 e1 10          	shl    $0x10,%rcx
    6484:	48 39 c8             	cmp    %rcx,%rax
    6487:	73 59                	jae    64e2 <fwp_loop_fields68.constprop.0+0x372>
    6489:	48 89 c1             	mov    %rax,%rcx
    648c:	48 c1 e9 10          	shr    $0x10,%rcx
    6490:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6494:	48 8b 0d 3d a6 01 00 	mov    0x1a63d(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    649b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    649f:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    64a3:	4d 85 ff             	test   %r15,%r15
    64a6:	74 3a                	je     64e2 <fwp_loop_fields68.constprop.0+0x372>
    64a8:	0f b6 31             	movzbl (%rcx),%esi
    64ab:	40 80 fe 02          	cmp    $0x2,%sil
    64af:	0f 84 3b 07 00 00    	je     6bf0 <fwp_loop_fields68.constprop.0+0xa80>
    64b5:	40 80 fe 01          	cmp    $0x1,%sil
    64b9:	75 27                	jne    64e2 <fwp_loop_fields68.constprop.0+0x372>
    64bb:	8b 71 18             	mov    0x18(%rcx),%esi
    64be:	0f b7 c0             	movzwl %ax,%eax
    64c1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64c4:	48 0f af c6          	imul   %rsi,%rax
    64c8:	48 c1 e8 20          	shr    $0x20,%rax
    64cc:	48 39 c8             	cmp    %rcx,%rax
    64cf:	73 11                	jae    64e2 <fwp_loop_fields68.constprop.0+0x372>
    64d1:	49 01 c7             	add    %rax,%r15
    64d4:	41 80 3f ff          	cmpb   $0xff,(%r15)
    64d8:	0f 84 25 07 00 00    	je     6c03 <fwp_loop_fields68.constprop.0+0xa93>
    64de:	41 c6 07 01          	movb   $0x1,(%r15)
    64e2:	48 8b 34 24          	mov    (%rsp),%rsi
    64e6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    64eb:	e8 70 e8 ff ff       	call   4d60 <fwp_map_items>
    64f0:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    64f6:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
    64fb:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6502:	00 00 00 00 00 
    6507:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    650c:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    6513:	00 
    6514:	48 85 ed             	test   %rbp,%rbp
    6517:	0f 84 c5 00 00 00    	je     65e2 <fwp_loop_fields68.constprop.0+0x472>
    651d:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    6522:	45 31 ff             	xor    %r15d,%r15d
    6525:	48 89 c3             	mov    %rax,%rbx
    6528:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    652d:	eb 4d                	jmp    657c <fwp_loop_fields68.constprop.0+0x40c>
    652f:	90                   	nop
    6530:	40 80 fe 01          	cmp    $0x1,%sil
    6534:	75 2d                	jne    6563 <fwp_loop_fields68.constprop.0+0x3f3>
    6536:	8b 72 18             	mov    0x18(%rdx),%esi
    6539:	0f b7 c0             	movzwl %ax,%eax
    653c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    653f:	48 0f af c6          	imul   %rsi,%rax
    6543:	48 c1 e8 20          	shr    $0x20,%rax
    6547:	48 39 d0             	cmp    %rdx,%rax
    654a:	73 17                	jae    6563 <fwp_loop_fields68.constprop.0+0x3f3>
    654c:	48 01 c7             	add    %rax,%rdi
    654f:	0f b6 07             	movzbl (%rdi),%eax
    6552:	84 c0                	test   %al,%al
    6554:	74 0d                	je     6563 <fwp_loop_fields68.constprop.0+0x3f3>
    6556:	3c fd                	cmp    $0xfd,%al
    6558:	0f 87 82 06 00 00    	ja     6be0 <fwp_loop_fields68.constprop.0+0xa70>
    655e:	83 c0 01             	add    $0x1,%eax
    6561:	88 07                	mov    %al,(%rdi)
    6563:	4d 8b 75 08          	mov    0x8(%r13),%r14
    6567:	4c 89 ef             	mov    %r13,%rdi
    656a:	e8 81 ef ff ff       	call   54f0 <fwp_drop4>
    656f:	4e 89 34 fb          	mov    %r14,(%rbx,%r15,8)
    6573:	49 83 c7 01          	add    $0x1,%r15
    6577:	49 39 ef             	cmp    %rbp,%r15
    657a:	74 5c                	je     65d8 <fwp_loop_fields68.constprop.0+0x468>
    657c:	4e 8b 2c fb          	mov    (%rbx,%r15,8),%r13
    6580:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6587:	00 
    6588:	4c 89 e8             	mov    %r13,%rax
    658b:	48 c1 e2 10          	shl    $0x10,%rdx
    658f:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6596:	00 
    6597:	48 39 d0             	cmp    %rdx,%rax
    659a:	73 c7                	jae    6563 <fwp_loop_fields68.constprop.0+0x3f3>
    659c:	48 89 c2             	mov    %rax,%rdx
    659f:	48 c1 ea 10          	shr    $0x10,%rdx
    65a3:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    65a7:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    65ae:	00 
    65af:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    65b3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    65b7:	48 85 ff             	test   %rdi,%rdi
    65ba:	74 a7                	je     6563 <fwp_loop_fields68.constprop.0+0x3f3>
    65bc:	0f b6 32             	movzbl (%rdx),%esi
    65bf:	40 80 fe 02          	cmp    $0x2,%sil
    65c3:	0f 85 67 ff ff ff    	jne    6530 <fwp_loop_fields68.constprop.0+0x3c0>
    65c9:	66 85 c0             	test   %ax,%ax
    65cc:	75 95                	jne    6563 <fwp_loop_fields68.constprop.0+0x3f3>
    65ce:	e9 7c ff ff ff       	jmp    654f <fwp_loop_fields68.constprop.0+0x3df>
    65d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65d8:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    65dd:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    65e2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    65e7:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
    65ec:	4c 89 ff             	mov    %r15,%rdi
    65ef:	e8 ac ed ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    65f4:	4c 89 fe             	mov    %r15,%rsi
    65f7:	48 89 c7             	mov    %rax,%rdi
    65fa:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    65ff:	e8 5c e7 ff ff       	call   4d60 <fwp_map_items>
    6604:	48 8b 0d ad a4 01 00 	mov    0x1a4ad(%rip),%rcx        # 20ab8 <fwp_heap+0x13d8>
    660b:	48 89 c5             	mov    %rax,%rbp
    660e:	4c 89 f0             	mov    %r14,%rax
    6611:	48 2b 05 78 a4 01 00 	sub    0x1a478(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    6618:	48 c1 e1 10          	shl    $0x10,%rcx
    661c:	48 39 c8             	cmp    %rcx,%rax
    661f:	73 5f                	jae    6680 <fwp_loop_fields68.constprop.0+0x510>
    6621:	48 89 c1             	mov    %rax,%rcx
    6624:	48 c1 e9 10          	shr    $0x10,%rcx
    6628:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    662c:	48 8b 0d a5 a4 01 00 	mov    0x1a4a5(%rip),%rcx        # 20ad8 <fwp_heap+0x13f8>
    6633:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    6637:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    663b:	48 85 ff             	test   %rdi,%rdi
    663e:	74 40                	je     6680 <fwp_loop_fields68.constprop.0+0x510>
    6640:	0f b6 31             	movzbl (%rcx),%esi
    6643:	40 80 fe 02          	cmp    $0x2,%sil
    6647:	0f 84 d3 05 00 00    	je     6c20 <fwp_loop_fields68.constprop.0+0xab0>
    664d:	40 80 fe 01          	cmp    $0x1,%sil
    6651:	75 2d                	jne    6680 <fwp_loop_fields68.constprop.0+0x510>
    6653:	8b 71 18             	mov    0x18(%rcx),%esi
    6656:	0f b7 c0             	movzwl %ax,%eax
    6659:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    665c:	48 0f af c6          	imul   %rsi,%rax
    6660:	48 c1 e8 20          	shr    $0x20,%rax
    6664:	48 39 c8             	cmp    %rcx,%rax
    6667:	73 17                	jae    6680 <fwp_loop_fields68.constprop.0+0x510>
    6669:	48 01 c7             	add    %rax,%rdi
    666c:	0f b6 07             	movzbl (%rdi),%eax
    666f:	84 c0                	test   %al,%al
    6671:	74 0d                	je     6680 <fwp_loop_fields68.constprop.0+0x510>
    6673:	3c fd                	cmp    $0xfd,%al
    6675:	0f 87 f8 05 00 00    	ja     6c73 <fwp_loop_fields68.constprop.0+0xb03>
    667b:	83 c0 01             	add    $0x1,%eax
    667e:	88 07                	mov    %al,(%rdi)
    6680:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
    6685:	4d 89 f5             	mov    %r14,%r13
    6688:	4d 85 ff             	test   %r15,%r15
    668b:	0f 84 07 05 00 00    	je     6b98 <fwp_loop_fields68.constprop.0+0xa28>
    6691:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    6696:	49 89 ee             	mov    %rbp,%r14
    6699:	eb 3b                	jmp    66d6 <fwp_loop_fields68.constprop.0+0x566>
    669b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    66a0:	40 80 fe 01          	cmp    $0x1,%sil
    66a4:	75 27                	jne    66cd <fwp_loop_fields68.constprop.0+0x55d>
    66a6:	8b 72 18             	mov    0x18(%rdx),%esi
    66a9:	0f b7 c0             	movzwl %ax,%eax
    66ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66af:	48 0f af c6          	imul   %rsi,%rax
    66b3:	48 c1 e8 20          	shr    $0x20,%rax
    66b7:	48 39 d0             	cmp    %rdx,%rax
    66ba:	73 11                	jae    66cd <fwp_loop_fields68.constprop.0+0x55d>
    66bc:	48 01 c5             	add    %rax,%rbp
    66bf:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    66c3:	0f 84 77 04 00 00    	je     6b40 <fwp_loop_fields68.constprop.0+0x9d0>
    66c9:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    66cd:	4d 85 ff             	test   %r15,%r15
    66d0:	0f 84 8a 00 00 00    	je     6760 <fwp_loop_fields68.constprop.0+0x5f0>
    66d6:	49 83 ef 01          	sub    $0x1,%r15
    66da:	66 49 0f 6e e5       	movq   %r13,%xmm4
    66df:	48 89 de             	mov    %rbx,%rsi
    66e2:	bf 01 00 00 00       	mov    $0x1,%edi
    66e7:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    66ed:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    66f1:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    66f8:	00 
    66f9:	e8 72 eb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    66fe:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6705:	00 
    6706:	49 89 c5             	mov    %rax,%r13
    6709:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6710:	00 
    6711:	48 c1 e2 10          	shl    $0x10,%rdx
    6715:	48 39 d0             	cmp    %rdx,%rax
    6718:	73 b3                	jae    66cd <fwp_loop_fields68.constprop.0+0x55d>
    671a:	48 89 c2             	mov    %rax,%rdx
    671d:	48 c1 ea 10          	shr    $0x10,%rdx
    6721:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6725:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    672c:	00 
    672d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6731:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6735:	48 85 ed             	test   %rbp,%rbp
    6738:	74 93                	je     66cd <fwp_loop_fields68.constprop.0+0x55d>
    673a:	0f b6 32             	movzbl (%rdx),%esi
    673d:	40 80 fe 02          	cmp    $0x2,%sil
    6741:	0f 85 59 ff ff ff    	jne    66a0 <fwp_loop_fields68.constprop.0+0x530>
    6747:	66 85 c0             	test   %ax,%ax
    674a:	0f 84 6f ff ff ff    	je     66bf <fwp_loop_fields68.constprop.0+0x54f>
    6750:	4d 85 ff             	test   %r15,%r15
    6753:	75 81                	jne    66d6 <fwp_loop_fields68.constprop.0+0x566>
    6755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    675c:	00 00 00 00 
    6760:	4c 89 f5             	mov    %r14,%rbp
    6763:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    6768:	48 89 ef             	mov    %rbp,%rdi
    676b:	e8 20 da ff ff       	call   4190 <fwp_mem_free>
    6770:	4c 89 f7             	mov    %r14,%rdi
    6773:	e8 78 f3 ff ff       	call   5af0 <fwp_drop0>
    6778:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    677d:	e8 6e f3 ff ff       	call   5af0 <fwp_drop0>
    6782:	48 8b 34 24          	mov    (%rsp),%rsi
    6786:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    678b:	e8 d0 e5 ff ff       	call   4d60 <fwp_map_items>
    6790:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    6796:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    679b:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    67a2:	00 00 00 00 00 
    67a7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    67ac:	0f 11 ac 24 88 00 00 	movups %xmm5,0x88(%rsp)
    67b3:	00 
    67b4:	48 85 d2             	test   %rdx,%rdx
    67b7:	0f 84 d0 00 00 00    	je     688d <fwp_loop_fields68.constprop.0+0x71d>
    67bd:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
    67c2:	45 31 f6             	xor    %r14d,%r14d
    67c5:	49 89 d7             	mov    %rdx,%r15
    67c8:	48 89 c3             	mov    %rax,%rbx
    67cb:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
    67d0:	eb 52                	jmp    6824 <fwp_loop_fields68.constprop.0+0x6b4>
    67d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    67d8:	40 80 fe 01          	cmp    $0x1,%sil
    67dc:	75 2d                	jne    680b <fwp_loop_fields68.constprop.0+0x69b>
    67de:	8b 72 18             	mov    0x18(%rdx),%esi
    67e1:	0f b7 c0             	movzwl %ax,%eax
    67e4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67e7:	48 0f af c6          	imul   %rsi,%rax
    67eb:	48 c1 e8 20          	shr    $0x20,%rax
    67ef:	48 39 d0             	cmp    %rdx,%rax
    67f2:	73 17                	jae    680b <fwp_loop_fields68.constprop.0+0x69b>
    67f4:	48 01 c7             	add    %rax,%rdi
    67f7:	0f b6 07             	movzbl (%rdi),%eax
    67fa:	84 c0                	test   %al,%al
    67fc:	74 0d                	je     680b <fwp_loop_fields68.constprop.0+0x69b>
    67fe:	3c fd                	cmp    $0xfd,%al
    6800:	0f 87 ca 03 00 00    	ja     6bd0 <fwp_loop_fields68.constprop.0+0xa60>
    6806:	83 c0 01             	add    $0x1,%eax
    6809:	88 07                	mov    %al,(%rdi)
    680b:	4c 8b 6d 10          	mov    0x10(%rbp),%r13
    680f:	48 89 ef             	mov    %rbp,%rdi
    6812:	e8 d9 ec ff ff       	call   54f0 <fwp_drop4>
    6817:	4e 89 2c f3          	mov    %r13,(%rbx,%r14,8)
    681b:	49 83 c6 01          	add    $0x1,%r14
    681f:	4d 39 fe             	cmp    %r15,%r14
    6822:	74 5c                	je     6880 <fwp_loop_fields68.constprop.0+0x710>
    6824:	4a 8b 2c f3          	mov    (%rbx,%r14,8),%rbp
    6828:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    682f:	00 
    6830:	48 89 e8             	mov    %rbp,%rax
    6833:	48 c1 e2 10          	shl    $0x10,%rdx
    6837:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    683e:	00 
    683f:	48 39 d0             	cmp    %rdx,%rax
    6842:	73 c7                	jae    680b <fwp_loop_fields68.constprop.0+0x69b>
    6844:	48 89 c2             	mov    %rax,%rdx
    6847:	48 c1 ea 10          	shr    $0x10,%rdx
    684b:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    684f:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6856:	00 
    6857:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    685b:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    685f:	48 85 ff             	test   %rdi,%rdi
    6862:	74 a7                	je     680b <fwp_loop_fields68.constprop.0+0x69b>
    6864:	0f b6 32             	movzbl (%rdx),%esi
    6867:	40 80 fe 02          	cmp    $0x2,%sil
    686b:	0f 85 67 ff ff ff    	jne    67d8 <fwp_loop_fields68.constprop.0+0x668>
    6871:	66 85 c0             	test   %ax,%ax
    6874:	75 95                	jne    680b <fwp_loop_fields68.constprop.0+0x69b>
    6876:	e9 7c ff ff ff       	jmp    67f7 <fwp_loop_fields68.constprop.0+0x687>
    687b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6880:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
    6885:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
    688a:	4c 89 fa             	mov    %r15,%rdx
    688d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6892:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6897:	e8 04 eb ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    689c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    68a1:	49 89 c6             	mov    %rax,%r14
    68a4:	e8 57 f4 ff ff       	call   5d00 <fwp_drop6>
    68a9:	48 89 de             	mov    %rbx,%rsi
    68ac:	bf 01 00 00 00       	mov    $0x1,%edi
    68b1:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    68b8:	00 00 00 00 00 
    68bd:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
    68c4:	00 
    68c5:	e8 a6 e9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    68ca:	48 8b 15 e7 a1 01 00 	mov    0x1a1e7(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    68d1:	48 89 c3             	mov    %rax,%rbx
    68d4:	48 2b 05 b5 a1 01 00 	sub    0x1a1b5(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    68db:	48 c1 e2 10          	shl    $0x10,%rdx
    68df:	48 39 d0             	cmp    %rdx,%rax
    68e2:	73 59                	jae    693d <fwp_loop_fields68.constprop.0+0x7cd>
    68e4:	48 89 c2             	mov    %rax,%rdx
    68e7:	48 c1 ea 10          	shr    $0x10,%rdx
    68eb:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    68ef:	48 8b 15 e2 a1 01 00 	mov    0x1a1e2(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    68f6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    68fa:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    68fe:	4d 85 f6             	test   %r14,%r14
    6901:	74 3a                	je     693d <fwp_loop_fields68.constprop.0+0x7cd>
    6903:	0f b6 32             	movzbl (%rdx),%esi
    6906:	40 80 fe 02          	cmp    $0x2,%sil
    690a:	0f 84 00 03 00 00    	je     6c10 <fwp_loop_fields68.constprop.0+0xaa0>
    6910:	40 80 fe 01          	cmp    $0x1,%sil
    6914:	75 27                	jne    693d <fwp_loop_fields68.constprop.0+0x7cd>
    6916:	8b 72 18             	mov    0x18(%rdx),%esi
    6919:	0f b7 c0             	movzwl %ax,%eax
    691c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    691f:	48 0f af c6          	imul   %rsi,%rax
    6923:	48 c1 e8 20          	shr    $0x20,%rax
    6927:	48 39 d0             	cmp    %rdx,%rax
    692a:	73 11                	jae    693d <fwp_loop_fields68.constprop.0+0x7cd>
    692c:	49 01 c6             	add    %rax,%r14
    692f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6933:	0f 84 25 03 00 00    	je     6c5e <fwp_loop_fields68.constprop.0+0xaee>
    6939:	41 c6 06 01          	movb   $0x1,(%r14)
    693d:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    6942:	48 89 df             	mov    %rbx,%rdi
    6945:	e8 16 e4 ff ff       	call   4d60 <fwp_map_items>
    694a:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    6950:	48 8b 34 24          	mov    (%rsp),%rsi
    6954:	4c 89 ef             	mov    %r13,%rdi
    6957:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    695c:	49 89 c6             	mov    %rax,%r14
    695f:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6966:	00 00 00 00 00 
    696b:	0f 11 b4 24 88 00 00 	movups %xmm6,0x88(%rsp)
    6972:	00 
    6973:	e8 e8 e3 ff ff       	call   4d60 <fwp_map_items>
    6978:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
    697d:	48 89 c7             	mov    %rax,%rdi
    6980:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    6985:	49 39 c7             	cmp    %rax,%r15
    6988:	4c 0f 47 f8          	cmova  %rax,%r15
    698c:	4d 85 ff             	test   %r15,%r15
    698f:	0f 84 ab 02 00 00    	je     6c40 <fwp_loop_fields68.constprop.0+0xad0>
    6995:	31 c0                	xor    %eax,%eax
    6997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    699e:	00 00 
    69a0:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    69a6:	f2 0f 58 04 c7       	addsd  (%rdi,%rax,8),%xmm0
    69ab:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    69b1:	48 83 c0 01          	add    $0x1,%rax
    69b5:	49 39 c7             	cmp    %rax,%r15
    69b8:	75 e6                	jne    69a0 <fwp_loop_fields68.constprop.0+0x830>
    69ba:	e8 d1 d7 ff ff       	call   4190 <fwp_mem_free>
    69bf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    69c4:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
    69c9:	e8 d2 e9 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    69ce:	4c 89 ef             	mov    %r13,%rdi
    69d1:	49 89 c6             	mov    %rax,%r14
    69d4:	e8 17 f1 ff ff       	call   5af0 <fwp_drop0>
    69d9:	48 89 df             	mov    %rbx,%rdi
    69dc:	e8 0f f1 ff ff       	call   5af0 <fwp_drop0>
    69e1:	48 8b 34 24          	mov    (%rsp),%rsi
    69e5:	4c 89 f7             	mov    %r14,%rdi
    69e8:	e8 73 e3 ff ff       	call   4d60 <fwp_map_items>
    69ed:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    69f3:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    69f8:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    69ff:	00 00 00 00 00 
    6a04:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6a09:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    6a10:	00 
    6a11:	48 85 c9             	test   %rcx,%rcx
    6a14:	74 24                	je     6a3a <fwp_loop_fields68.constprop.0+0x8ca>
    6a16:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
    6a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a20:	f2 0f 10 05 48 5a 00 	movsd  0x5a48(%rip),%xmm0        # c470 <msg.3+0x20>
    6a27:	00 
    6a28:	f2 0f 59 00          	mulsd  (%rax),%xmm0
    6a2c:	48 83 c0 08          	add    $0x8,%rax
    6a30:	f2 0f 11 40 f8       	movsd  %xmm0,-0x8(%rax)
    6a35:	48 39 c2             	cmp    %rax,%rdx
    6a38:	75 e6                	jne    6a20 <fwp_loop_fields68.constprop.0+0x8b0>
    6a3a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a3f:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
    6a44:	e8 57 e9 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    6a49:	4c 89 f7             	mov    %r14,%rdi
    6a4c:	48 89 c3             	mov    %rax,%rbx
    6a4f:	e8 9c f0 ff ff       	call   5af0 <fwp_drop0>
    6a54:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    6a59:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6a5e:	e8 fd e2 ff ff       	call   4d60 <fwp_map_items>
    6a63:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    6a69:	48 8b 34 24          	mov    (%rsp),%rsi
    6a6d:	48 89 df             	mov    %rbx,%rdi
    6a70:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6a75:	49 89 c6             	mov    %rax,%r14
    6a78:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6a7f:	00 00 00 00 00 
    6a84:	0f 11 ac 24 88 00 00 	movups %xmm5,0x88(%rsp)
    6a8b:	00 
    6a8c:	e8 cf e2 ff ff       	call   4d60 <fwp_map_items>
    6a91:	4c 8b 64 24 68       	mov    0x68(%rsp),%r12
    6a96:	48 89 c7             	mov    %rax,%rdi
    6a99:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    6a9e:	49 39 c4             	cmp    %rax,%r12
    6aa1:	4c 0f 47 e0          	cmova  %rax,%r12
    6aa5:	4d 85 e4             	test   %r12,%r12
    6aa8:	0f 84 a2 01 00 00    	je     6c50 <fwp_loop_fields68.constprop.0+0xae0>
    6aae:	31 c0                	xor    %eax,%eax
    6ab0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6abc:	00 00 00 00 
    6ac0:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    6ac6:	f2 0f 5c 04 c7       	subsd  (%rdi,%rax,8),%xmm0
    6acb:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    6ad1:	48 83 c0 01          	add    $0x1,%rax
    6ad5:	49 39 c4             	cmp    %rax,%r12
    6ad8:	75 e6                	jne    6ac0 <fwp_loop_fields68.constprop.0+0x950>
    6ada:	e8 b1 d6 ff ff       	call   4190 <fwp_mem_free>
    6adf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ae4:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    6ae9:	e8 b2 e8 ff ff       	call   53a0 <fwp_map_finish_protected.isra.0>
    6aee:	48 89 df             	mov    %rbx,%rdi
    6af1:	48 89 c5             	mov    %rax,%rbp
    6af4:	e8 f7 ef ff ff       	call   5af0 <fwp_drop0>
    6af9:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6afe:	e8 ed ef ff ff       	call   5af0 <fwp_drop0>
    6b03:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
    6b09:	75 6d                	jne    6b78 <fwp_loop_fields68.constprop.0+0xa08>
    6b0b:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    6b12:	00 
    6b13:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b1a:	00 00 
    6b1c:	0f 85 65 01 00 00    	jne    6c87 <fwp_loop_fields68.constprop.0+0xb17>
    6b22:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    6b29:	48 89 e8             	mov    %rbp,%rax
    6b2c:	5b                   	pop    %rbx
    6b2d:	5d                   	pop    %rbp
    6b2e:	41 5c                	pop    %r12
    6b30:	41 5d                	pop    %r13
    6b32:	41 5e                	pop    %r14
    6b34:	41 5f                	pop    %r15
    6b36:	c3                   	ret
    6b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b3e:	00 00 
    6b40:	48 89 ef             	mov    %rbp,%rdi
    6b43:	e8 08 d4 ff ff       	call   3f50 <fwp_rc_forget_slot>
    6b48:	e9 7c fb ff ff       	jmp    66c9 <fwp_loop_fields68.constprop.0+0x559>
    6b4d:	0f 1f 00             	nopl   (%rax)
    6b50:	48 89 cf             	mov    %rcx,%rdi
    6b53:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
    6b58:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6b5d:	e8 ee d3 ff ff       	call   3f50 <fwp_rc_forget_slot>
    6b62:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    6b67:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6b6c:	e9 b8 f7 ff ff       	jmp    6329 <fwp_loop_fields68.constprop.0+0x1b9>
    6b71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b78:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    6b7d:	31 c0                	xor    %eax,%eax
    6b7f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
    6b84:	48 83 c2 ff          	add    $0xffffffffffffffff,%rdx
    6b88:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6b8d:	0f 90 c0             	seto   %al
    6b90:	e9 46 f6 ff ff       	jmp    61db <fwp_loop_fields68.constprop.0+0x6b>
    6b95:	0f 1f 00             	nopl   (%rax)
    6b98:	48 85 ed             	test   %rbp,%rbp
    6b9b:	0f 84 cf fb ff ff    	je     6770 <fwp_loop_fields68.constprop.0+0x600>
    6ba1:	e9 c2 fb ff ff       	jmp    6768 <fwp_loop_fields68.constprop.0+0x5f8>
    6ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bad:	00 00 00 
    6bb0:	48 8d 9c 24 b0 00 00 	lea    0xb0(%rsp),%rbx
    6bb7:	00 
    6bb8:	4d 85 f6             	test   %r14,%r14
    6bbb:	0f 84 6c f8 ff ff    	je     642d <fwp_loop_fields68.constprop.0+0x2bd>
    6bc1:	e9 55 f8 ff ff       	jmp    641b <fwp_loop_fields68.constprop.0+0x2ab>
    6bc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bcd:	00 00 00 
    6bd0:	e8 5b d2 ff ff       	call   3e30 <fwp_rc_wide_dup>
    6bd5:	e9 31 fc ff ff       	jmp    680b <fwp_loop_fields68.constprop.0+0x69b>
    6bda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6be0:	e8 4b d2 ff ff       	call   3e30 <fwp_rc_wide_dup>
    6be5:	e9 79 f9 ff ff       	jmp    6563 <fwp_loop_fields68.constprop.0+0x3f3>
    6bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bf0:	66 85 c0             	test   %ax,%ax
    6bf3:	0f 85 e9 f8 ff ff    	jne    64e2 <fwp_loop_fields68.constprop.0+0x372>
    6bf9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6bfd:	0f 85 db f8 ff ff    	jne    64de <fwp_loop_fields68.constprop.0+0x36e>
    6c03:	4c 89 ff             	mov    %r15,%rdi
    6c06:	e8 45 d3 ff ff       	call   3f50 <fwp_rc_forget_slot>
    6c0b:	e9 ce f8 ff ff       	jmp    64de <fwp_loop_fields68.constprop.0+0x36e>
    6c10:	66 85 c0             	test   %ax,%ax
    6c13:	0f 85 24 fd ff ff    	jne    693d <fwp_loop_fields68.constprop.0+0x7cd>
    6c19:	e9 11 fd ff ff       	jmp    692f <fwp_loop_fields68.constprop.0+0x7bf>
    6c1e:	66 90                	xchg   %ax,%ax
    6c20:	66 85 c0             	test   %ax,%ax
    6c23:	0f 85 57 fa ff ff    	jne    6680 <fwp_loop_fields68.constprop.0+0x510>
    6c29:	e9 3e fa ff ff       	jmp    666c <fwp_loop_fields68.constprop.0+0x4fc>
    6c2e:	66 90                	xchg   %ax,%ax
    6c30:	66 85 c0             	test   %ax,%ax
    6c33:	0f 85 3d f6 ff ff    	jne    6276 <fwp_loop_fields68.constprop.0+0x106>
    6c39:	e9 24 f6 ff ff       	jmp    6262 <fwp_loop_fields68.constprop.0+0xf2>
    6c3e:	66 90                	xchg   %ax,%ax
    6c40:	48 85 ff             	test   %rdi,%rdi
    6c43:	0f 84 76 fd ff ff    	je     69bf <fwp_loop_fields68.constprop.0+0x84f>
    6c49:	e9 6c fd ff ff       	jmp    69ba <fwp_loop_fields68.constprop.0+0x84a>
    6c4e:	66 90                	xchg   %ax,%ax
    6c50:	48 85 ff             	test   %rdi,%rdi
    6c53:	0f 84 86 fe ff ff    	je     6adf <fwp_loop_fields68.constprop.0+0x96f>
    6c59:	e9 7c fe ff ff       	jmp    6ada <fwp_loop_fields68.constprop.0+0x96a>
    6c5e:	4c 89 f7             	mov    %r14,%rdi
    6c61:	e8 ea d2 ff ff       	call   3f50 <fwp_rc_forget_slot>
    6c66:	e9 ce fc ff ff       	jmp    6939 <fwp_loop_fields68.constprop.0+0x7c9>
    6c6b:	45 31 ff             	xor    %r15d,%r15d
    6c6e:	e9 83 f5 ff ff       	jmp    61f6 <fwp_loop_fields68.constprop.0+0x86>
    6c73:	e8 b8 d1 ff ff       	call   3e30 <fwp_rc_wide_dup>
    6c78:	e9 03 fa ff ff       	jmp    6680 <fwp_loop_fields68.constprop.0+0x510>
    6c7d:	e8 ae d1 ff ff       	call   3e30 <fwp_rc_wide_dup>
    6c82:	e9 ef f5 ff ff       	jmp    6276 <fwp_loop_fields68.constprop.0+0x106>
    6c87:	e8 b4 b7 ff ff       	call   2440 <__stack_chk_fail@plt>
    6c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006c90 <fwp_write>:
    6c90:	41 57                	push   %r15
    6c92:	41 56                	push   %r14
    6c94:	41 55                	push   %r13
    6c96:	41 54                	push   %r12
    6c98:	55                   	push   %rbp
    6c99:	53                   	push   %rbx
    6c9a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    6ca1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    6ca8:	00 00 
    6caa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    6cb1:	00 
    6cb2:	49 89 d4             	mov    %rdx,%r12
    6cb5:	8b 12                	mov    (%rdx),%edx
    6cb7:	83 fa 19             	cmp    $0x19,%edx
    6cba:	77 6a                	ja     6d26 <fwp_write+0x96>
    6cbc:	48 89 f5             	mov    %rsi,%rbp
    6cbf:	89 d0                	mov    %edx,%eax
    6cc1:	89 ce                	mov    %ecx,%esi
    6cc3:	48 89 fb             	mov    %rdi,%rbx
    6cc6:	48 8d 0d 13 57 00 00 	lea    0x5713(%rip),%rcx        # c3e0 <_IO_stdin_used+0x3e0>
    6ccd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    6cd1:	48 01 c8             	add    %rcx,%rax
    6cd4:	3e ff e0             	notrack jmp *%rax
    6cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cde:	00 00 
    6ce0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    6ce4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    6ce8:	48 89 ca             	mov    %rcx,%rdx
    6ceb:	48 85 c9             	test   %rcx,%rcx
    6cee:	0f 88 9c 0c 00 00    	js     7990 <fwp_write+0xd00>
    6cf4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6cfb:	00 
    6cfc:	48 89 c6             	mov    %rax,%rsi
    6cff:	4c 89 e7             	mov    %r12,%rdi
    6d02:	e8 f9 bc ff ff       	call   2a00 <fwp_fmt_u128>
    6d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d0e:	00 00 
    6d10:	4c 89 e7             	mov    %r12,%rdi
    6d13:	e8 18 b7 ff ff       	call   2430 <strlen@plt>
    6d18:	4c 89 e6             	mov    %r12,%rsi
    6d1b:	48 89 df             	mov    %rbx,%rdi
    6d1e:	48 89 c2             	mov    %rax,%rdx
    6d21:	e8 ca c2 ff ff       	call   2ff0 <buf_put>
    6d26:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6d2d:	00 
    6d2e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d35:	00 00 
    6d37:	0f 85 28 04 00 00    	jne    7165 <fwp_write+0x4d5>
    6d3d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    6d44:	5b                   	pop    %rbx
    6d45:	5d                   	pop    %rbp
    6d46:	41 5c                	pop    %r12
    6d48:	41 5d                	pop    %r13
    6d4a:	41 5e                	pop    %r14
    6d4c:	41 5f                	pop    %r15
    6d4e:	c3                   	ret
    6d4f:	90                   	nop
    6d50:	49 89 e9             	mov    %rbp,%r9
    6d53:	4c 8d 05 9a 53 00 00 	lea    0x539a(%rip),%r8        # c0f4 <_IO_stdin_used+0xf4>
    6d5a:	b9 00 02 00 00       	mov    $0x200,%ecx
    6d5f:	ba 02 00 00 00       	mov    $0x2,%edx
    6d64:	be 00 02 00 00       	mov    $0x200,%esi
    6d69:	31 c0                	xor    %eax,%eax
    6d6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6d72:	00 
    6d73:	e8 18 b6 ff ff       	call   2390 <__snprintf_chk@plt>
    6d78:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    6d7f:	00 
    6d80:	e8 ab b6 ff ff       	call   2430 <strlen@plt>
    6d85:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    6d8c:	00 
    6d8d:	48 89 df             	mov    %rbx,%rdi
    6d90:	48 89 c2             	mov    %rax,%rdx
    6d93:	e8 58 c2 ff ff       	call   2ff0 <buf_put>
    6d98:	eb 8c                	jmp    6d26 <fwp_write+0x96>
    6d9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6da0:	49 89 e9             	mov    %rbp,%r9
    6da3:	4c 8d 05 45 53 00 00 	lea    0x5345(%rip),%r8        # c0ef <_IO_stdin_used+0xef>
    6daa:	eb ae                	jmp    6d5a <fwp_write+0xca>
    6dac:	0f 1f 40 00          	nopl   0x0(%rax)
    6db0:	83 fa 13             	cmp    $0x13,%edx
    6db3:	48 8d 05 2b 53 00 00 	lea    0x532b(%rip),%rax        # c0e5 <_IO_stdin_used+0xe5>
    6dba:	48 8d 35 29 53 00 00 	lea    0x5329(%rip),%rsi        # c0ea <_IO_stdin_used+0xea>
    6dc1:	ba 04 00 00 00       	mov    $0x4,%edx
    6dc6:	48 0f 44 f0          	cmove  %rax,%rsi
    6dca:	45 31 ed             	xor    %r13d,%r13d
    6dcd:	e8 1e c2 ff ff       	call   2ff0 <buf_put>
    6dd2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6dd7:	0f 84 a3 08 00 00    	je     7680 <fwp_write+0x9f0>
    6ddd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    6de2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    6de7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6dec:	48 89 df             	mov    %rbx,%rdi
    6def:	49 0f 44 c5          	cmove  %r13,%rax
    6df3:	31 c9                	xor    %ecx,%ecx
    6df5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    6dfa:	e8 91 fe ff ff       	call   6c90 <fwp_write>
    6dff:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    6e04:	0f 84 6e 09 00 00    	je     7778 <fwp_write+0xae8>
    6e0a:	49 83 c5 01          	add    $0x1,%r13
    6e0e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    6e12:	0f 83 68 08 00 00    	jae    7680 <fwp_write+0x9f0>
    6e18:	ba 02 00 00 00       	mov    $0x2,%edx
    6e1d:	48 8d 35 10 53 00 00 	lea    0x5310(%rip),%rsi        # c134 <_IO_stdin_used+0x134>
    6e24:	48 89 df             	mov    %rbx,%rdi
    6e27:	e8 c4 c1 ff ff       	call   2ff0 <buf_put>
    6e2c:	eb af                	jmp    6ddd <fwp_write+0x14d>
    6e2e:	66 90                	xchg   %ax,%ax
    6e30:	ba 06 00 00 00       	mov    $0x6,%edx
    6e35:	48 8d 35 d1 52 00 00 	lea    0x52d1(%rip),%rsi        # c10d <_IO_stdin_used+0x10d>
    6e3c:	48 83 c5 10          	add    $0x10,%rbp
    6e40:	e8 ab c1 ff ff       	call   2ff0 <buf_put>
    6e45:	48 89 ef             	mov    %rbp,%rdi
    6e48:	e8 e3 b5 ff ff       	call   2430 <strlen@plt>
    6e4d:	48 89 ee             	mov    %rbp,%rsi
    6e50:	48 89 df             	mov    %rbx,%rdi
    6e53:	48 89 c2             	mov    %rax,%rdx
    6e56:	e8 95 c1 ff ff       	call   2ff0 <buf_put>
    6e5b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6e60:	ba 01 00 00 00       	mov    $0x1,%edx
    6e65:	48 89 df             	mov    %rbx,%rdi
    6e68:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    6e6d:	e8 7e c1 ff ff       	call   2ff0 <buf_put>
    6e72:	e9 af fe ff ff       	jmp    6d26 <fwp_write+0x96>
    6e77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e7e:	00 00 
    6e80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    6e87:	00 
    6e88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e8f:	00 00 
    6e91:	0f 85 ce 02 00 00    	jne    7165 <fwp_write+0x4d5>
    6e97:	ba 0a 00 00 00       	mov    $0xa,%edx
    6e9c:	48 8d 35 56 52 00 00 	lea    0x5256(%rip),%rsi        # c0f9 <_IO_stdin_used+0xf9>
    6ea3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    6eaa:	48 89 df             	mov    %rbx,%rdi
    6ead:	5b                   	pop    %rbx
    6eae:	5d                   	pop    %rbp
    6eaf:	41 5c                	pop    %r12
    6eb1:	41 5d                	pop    %r13
    6eb3:	41 5e                	pop    %r14
    6eb5:	41 5f                	pop    %r15
    6eb7:	e9 34 c1 ff ff       	jmp    2ff0 <buf_put>
    6ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ec0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6ec5:	4d 85 ed             	test   %r13,%r13
    6ec8:	0f 84 02 0c 00 00    	je     7ad0 <fwp_write+0xe40>
    6ece:	48 8d 35 6c 52 00 00 	lea    0x526c(%rip),%rsi        # c141 <_IO_stdin_used+0x141>
    6ed5:	4c 89 ef             	mov    %r13,%rdi
    6ed8:	e8 33 b6 ff ff       	call   2510 <strcmp@plt>
    6edd:	41 89 c1             	mov    %eax,%r9d
    6ee0:	85 c0                	test   %eax,%eax
    6ee2:	0f 84 6c 0c 00 00    	je     7b54 <fwp_write+0xec4>
    6ee8:	4c 89 ef             	mov    %r13,%rdi
    6eeb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6ef0:	e8 3b b5 ff ff       	call   2430 <strlen@plt>
    6ef5:	4c 89 ee             	mov    %r13,%rsi
    6ef8:	48 89 df             	mov    %rbx,%rdi
    6efb:	48 89 c2             	mov    %rax,%rdx
    6efe:	e8 ed c0 ff ff       	call   2ff0 <buf_put>
    6f03:	ba 01 00 00 00       	mov    $0x1,%edx
    6f08:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6f0d:	48 89 df             	mov    %rbx,%rdi
    6f10:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    6f15:	e8 d6 c0 ff ff       	call   2ff0 <buf_put>
    6f1a:	ba 01 00 00 00       	mov    $0x1,%edx
    6f1f:	4c 89 fe             	mov    %r15,%rsi
    6f22:	48 89 df             	mov    %rbx,%rdi
    6f25:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    6f2a:	e8 c1 c0 ff ff       	call   2ff0 <buf_put>
    6f2f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    6f34:	45 31 f6             	xor    %r14d,%r14d
    6f37:	85 d2                	test   %edx,%edx
    6f39:	0f 8e 81 0a 00 00    	jle    79c0 <fwp_write+0xd30>
    6f3f:	45 31 ed             	xor    %r13d,%r13d
    6f42:	4d 85 ed             	test   %r13,%r13
    6f45:	0f 85 75 07 00 00    	jne    76c0 <fwp_write+0xa30>
    6f4b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    6f52:	00 
    6f53:	45 85 f6             	test   %r14d,%r14d
    6f56:	0f 84 84 07 00 00    	je     76e0 <fwp_write+0xa50>
    6f5c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    6f61:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    6f66:	48 89 df             	mov    %rbx,%rdi
    6f69:	49 83 c5 01          	add    $0x1,%r13
    6f6d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    6f71:	31 c9                	xor    %ecx,%ecx
    6f73:	e8 18 fd ff ff       	call   6c90 <fwp_write>
    6f78:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    6f7d:	7f c3                	jg     6f42 <fwp_write+0x2b2>
    6f7f:	45 85 f6             	test   %r14d,%r14d
    6f82:	0f 84 38 0a 00 00    	je     79c0 <fwp_write+0xd30>
    6f88:	b8 29 00 00 00       	mov    $0x29,%eax
    6f8d:	ba 01 00 00 00       	mov    $0x1,%edx
    6f92:	4c 89 fe             	mov    %r15,%rsi
    6f95:	48 89 df             	mov    %rbx,%rdi
    6f98:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    6f9c:	e8 4f c0 ff ff       	call   2ff0 <buf_put>
    6fa1:	e9 80 fd ff ff       	jmp    6d26 <fwp_write+0x96>
    6fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fad:	00 00 00 
    6fb0:	ba 01 00 00 00       	mov    $0x1,%edx
    6fb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    6fba:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    6fbf:	e8 2c c0 ff ff       	call   2ff0 <buf_put>
    6fc4:	48 85 ed             	test   %rbp,%rbp
    6fc7:	0f 84 93 06 00 00    	je     7660 <fwp_write+0x9d0>
    6fcd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    6fd1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    6fd6:	31 c9                	xor    %ecx,%ecx
    6fd8:	48 89 df             	mov    %rbx,%rdi
    6fdb:	e8 b0 fc ff ff       	call   6c90 <fwp_write>
    6fe0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    6fe4:	48 85 ed             	test   %rbp,%rbp
    6fe7:	0f 84 73 06 00 00    	je     7660 <fwp_write+0x9d0>
    6fed:	ba 02 00 00 00       	mov    $0x2,%edx
    6ff2:	48 8d 35 3b 51 00 00 	lea    0x513b(%rip),%rsi        # c134 <_IO_stdin_used+0x134>
    6ff9:	48 89 df             	mov    %rbx,%rdi
    6ffc:	e8 ef bf ff ff       	call   2ff0 <buf_put>
    7001:	eb ca                	jmp    6fcd <fwp_write+0x33d>
    7003:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7008:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    700c:	85 f6                	test   %esi,%esi
    700e:	0f 84 fc 07 00 00    	je     7810 <fwp_write+0xb80>
    7014:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    701b:	00 
    701c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7023:	00 00 
    7025:	0f 85 3a 01 00 00    	jne    7165 <fwp_write+0x4d5>
    702b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    702f:	4c 89 ea             	mov    %r13,%rdx
    7032:	e9 6c fe ff ff       	jmp    6ea3 <fwp_write+0x213>
    7037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    703e:	00 00 
    7040:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    7045:	ba 01 00 00 00       	mov    $0x1,%edx
    704a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    704f:	48 89 ee             	mov    %rbp,%rsi
    7052:	e8 99 bf ff ff       	call   2ff0 <buf_put>
    7057:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    705c:	4c 89 e7             	mov    %r12,%rdi
    705f:	e8 cc b3 ff ff       	call   2430 <strlen@plt>
    7064:	4c 89 e6             	mov    %r12,%rsi
    7067:	48 89 df             	mov    %rbx,%rdi
    706a:	48 89 c2             	mov    %rax,%rdx
    706d:	e8 7e bf ff ff       	call   2ff0 <buf_put>
    7072:	ba 01 00 00 00       	mov    $0x1,%edx
    7077:	48 89 ee             	mov    %rbp,%rsi
    707a:	48 89 df             	mov    %rbx,%rdi
    707d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    7082:	e8 69 bf ff ff       	call   2ff0 <buf_put>
    7087:	e9 9a fc ff ff       	jmp    6d26 <fwp_write+0x96>
    708c:	0f 1f 40 00          	nopl   0x0(%rax)
    7090:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    7095:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    7099:	0f 8a 8e 0b 00 00    	jp     7c2d <fwp_write+0xf9d>
    709f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    70a3:	66 0f 54 05 55 54 00 	andpd  0x5455(%rip),%xmm0        # c500 <msg.3+0xb0>
    70aa:	00 
    70ab:	bd 01 00 00 00       	mov    $0x1,%ebp
    70b0:	66 0f 2e 05 d8 53 00 	ucomisd 0x53d8(%rip),%xmm0        # c490 <msg.3+0x40>
    70b7:	00 
    70b8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    70bf:	00 
    70c0:	0f 87 b2 09 00 00    	ja     7a78 <fwp_write+0xde8>
    70c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70cd:	00 00 00 
    70d0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    70d4:	89 ee                	mov    %ebp,%esi
    70d6:	4c 89 e7             	mov    %r12,%rdi
    70d9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    70de:	e8 1d c1 ff ff       	call   3200 <fwp_format_g.constprop.0>
    70e3:	31 f6                	xor    %esi,%esi
    70e5:	4c 89 e7             	mov    %r12,%rdi
    70e8:	e8 03 b3 ff ff       	call   23f0 <strtod@plt>
    70ed:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    70f2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    70f6:	7a 06                	jp     70fe <fwp_write+0x46e>
    70f8:	0f 84 e9 01 00 00    	je     72e7 <fwp_write+0x657>
    70fe:	83 c5 01             	add    $0x1,%ebp
    7101:	83 fd 12             	cmp    $0x12,%ebp
    7104:	75 ca                	jne    70d0 <fwp_write+0x440>
    7106:	be 11 00 00 00       	mov    $0x11,%esi
    710b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    710f:	4c 89 e7             	mov    %r12,%rdi
    7112:	e8 e9 c0 ff ff       	call   3200 <fwp_format_g.constprop.0>
    7117:	e9 cb 01 00 00       	jmp    72e7 <fwp_write+0x657>
    711c:	0f 1f 40 00          	nopl   0x0(%rax)
    7120:	48 83 fd 01          	cmp    $0x1,%rbp
    7124:	0f 84 e6 08 00 00    	je     7a10 <fwp_write+0xd80>
    712a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    712e:	b8 02 00 00 00       	mov    $0x2,%eax
    7133:	ba 01 00 00 00       	mov    $0x1,%edx
    7138:	48 0f 44 d0          	cmove  %rax,%rdx
    713c:	48 8d 35 9a 4f 00 00 	lea    0x4f9a(%rip),%rsi        # c0dd <_IO_stdin_used+0xdd>
    7143:	48 8d 05 98 4f 00 00 	lea    0x4f98(%rip),%rax        # c0e2 <_IO_stdin_used+0xe2>
    714a:	48 0f 44 f0          	cmove  %rax,%rsi
    714e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7155:	00 
    7156:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    715d:	00 00 
    715f:	0f 84 3e fd ff ff    	je     6ea3 <fwp_write+0x213>
    7165:	e8 d6 b2 ff ff       	call   2440 <__stack_chk_fail@plt>
    716a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7170:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    7175:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    717a:	e8 b1 bd ff ff       	call   2f30 <buf_grow>
    717f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    7183:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    7189:	4c 03 0b             	add    (%rbx),%r9
    718c:	66 45 89 11          	mov    %r10w,(%r9)
    7190:	45 85 e4             	test   %r12d,%r12d
    7193:	0f 8e 07 05 00 00    	jle    76a0 <fwp_write+0xa10>
    7199:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    71a0:	55 55 55 
    71a3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    71a8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    71af:	aa aa aa 
    71b2:	49 83 c1 01          	add    $0x1,%r9
    71b6:	eb 45                	jmp    71fd <fwp_write+0x56d>
    71b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    71bf:	00 
    71c0:	be 01 00 00 00       	mov    $0x1,%esi
    71c5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    71ca:	88 07                	mov    %al,(%rdi)
    71cc:	48 89 e8             	mov    %rbp,%rax
    71cf:	49 f7 e8             	imul   %r8
    71d2:	48 89 e8             	mov    %rbp,%rax
    71d5:	48 c1 f8 3f          	sar    $0x3f,%rax
    71d9:	48 29 c2             	sub    %rax,%rdx
    71dc:	48 85 c9             	test   %rcx,%rcx
    71df:	0f 95 c0             	setne  %al
    71e2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    71e6:	48 83 ef 01          	sub    $0x1,%rdi
    71ea:	48 21 c5             	and    %rax,%rbp
    71ed:	48 29 ea             	sub    %rbp,%rdx
    71f0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    71f4:	49 39 f9             	cmp    %rdi,%r9
    71f7:	0f 84 a3 04 00 00    	je     76a0 <fwp_write+0xa10>
    71fd:	48 89 e8             	mov    %rbp,%rax
    7200:	49 f7 e8             	imul   %r8
    7203:	48 89 e8             	mov    %rbp,%rax
    7206:	48 c1 f8 3f          	sar    $0x3f,%rax
    720a:	48 89 d1             	mov    %rdx,%rcx
    720d:	48 29 c1             	sub    %rax,%rcx
    7210:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    7214:	48 89 e9             	mov    %rbp,%rcx
    7217:	48 29 c1             	sub    %rax,%rcx
    721a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    721e:	49 f7 e2             	mul    %r10
    7221:	b8 30 00 00 00       	mov    $0x30,%eax
    7226:	48 89 d6             	mov    %rdx,%rsi
    7229:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    722d:	48 d1 ee             	shr    $1,%rsi
    7230:	48 01 f2             	add    %rsi,%rdx
    7233:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    7237:	48 29 d6             	sub    %rdx,%rsi
    723a:	74 8e                	je     71ca <fwp_write+0x53a>
    723c:	48 83 fe 01          	cmp    $0x1,%rsi
    7240:	0f 85 7a ff ff ff    	jne    71c0 <fwp_write+0x530>
    7246:	31 f6                	xor    %esi,%esi
    7248:	b8 2b 00 00 00       	mov    $0x2b,%eax
    724d:	e9 78 ff ff ff       	jmp    71ca <fwp_write+0x53a>
    7252:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7258:	66 0f 6e cd          	movd   %ebp,%xmm1
    725c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    725f:	0f 8a c8 09 00 00    	jp     7c2d <fwp_write+0xf9d>
    7265:	0f 28 c1             	movaps %xmm1,%xmm0
    7268:	0f 54 05 81 52 00 00 	andps  0x5281(%rip),%xmm0        # c4f0 <msg.3+0xa0>
    726f:	0f 2e 05 8e 4d 00 00 	ucomiss 0x4d8e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    7276:	0f 87 24 08 00 00    	ja     7aa0 <fwp_write+0xe10>
    727c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    7280:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    7286:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    728d:	00 
    728e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    7292:	66 49 0f 7e d7       	movq   %xmm2,%r15
    7297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    729e:	00 00 
    72a0:	44 89 ee             	mov    %r13d,%esi
    72a3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    72a8:	4c 89 e7             	mov    %r12,%rdi
    72ab:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    72b0:	e8 4b bf ff ff       	call   3200 <fwp_format_g.constprop.0>
    72b5:	31 f6                	xor    %esi,%esi
    72b7:	4c 89 e7             	mov    %r12,%rdi
    72ba:	e8 d1 b1 ff ff       	call   2490 <strtof@plt>
    72bf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    72c4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    72c7:	7a 02                	jp     72cb <fwp_write+0x63b>
    72c9:	74 1c                	je     72e7 <fwp_write+0x657>
    72cb:	41 83 c5 01          	add    $0x1,%r13d
    72cf:	41 83 fd 0a          	cmp    $0xa,%r13d
    72d3:	75 cb                	jne    72a0 <fwp_write+0x610>
    72d5:	be 09 00 00 00       	mov    $0x9,%esi
    72da:	66 49 0f 6e c7       	movq   %r15,%xmm0
    72df:	4c 89 e7             	mov    %r12,%rdi
    72e2:	e8 19 bf ff ff       	call   3200 <fwp_format_g.constprop.0>
    72e7:	4c 89 e7             	mov    %r12,%rdi
    72ea:	e8 c1 bd ff ff       	call   30b0 <fwp_finish_float>
    72ef:	e9 1c fa ff ff       	jmp    6d10 <fwp_write+0x80>
    72f4:	0f 1f 40 00          	nopl   0x0(%rax)
    72f8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    72fc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    7300:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    7307:	00 
    7308:	48 89 ef             	mov    %rbp,%rdi
    730b:	e8 f0 b6 ff ff       	call   2a00 <fwp_fmt_u128>
    7310:	48 89 ef             	mov    %rbp,%rdi
    7313:	e8 18 b1 ff ff       	call   2430 <strlen@plt>
    7318:	48 89 ee             	mov    %rbp,%rsi
    731b:	48 89 df             	mov    %rbx,%rdi
    731e:	48 89 c2             	mov    %rax,%rdx
    7321:	e8 ca bc ff ff       	call   2ff0 <buf_put>
    7326:	e9 fb f9 ff ff       	jmp    6d26 <fwp_write+0x96>
    732b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7330:	ba 06 00 00 00       	mov    $0x6,%edx
    7335:	48 8d 35 fb 4d 00 00 	lea    0x4dfb(%rip),%rsi        # c137 <_IO_stdin_used+0x137>
    733c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    7342:	e8 a9 bc ff ff       	call   2ff0 <buf_put>
    7347:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    734e:	ff ff 7f 
    7351:	48 23 55 00          	and    0x0(%rbp),%rdx
    7355:	0f 84 86 02 00 00    	je     75e1 <fwp_write+0x951>
    735b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    7360:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    7364:	48 85 d2             	test   %rdx,%rdx
    7367:	0f 84 ae 00 00 00    	je     741b <fwp_write+0x78b>
    736d:	8b 0a                	mov    (%rdx),%ecx
    736f:	83 f9 1c             	cmp    $0x1c,%ecx
    7372:	0f 84 58 06 00 00    	je     79d0 <fwp_write+0xd40>
    7378:	83 f9 1b             	cmp    $0x1b,%ecx
    737b:	0f 87 9a 00 00 00    	ja     741b <fwp_write+0x78b>
    7381:	be 01 00 00 00       	mov    $0x1,%esi
    7386:	48 d3 e6             	shl    %cl,%rsi
    7389:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    738f:	0f 85 4b 04 00 00    	jne    77e0 <fwp_write+0xb50>
    7395:	f7 c6 84 04 00 00    	test   $0x484,%esi
    739b:	0f 85 0f 04 00 00    	jne    77b0 <fwp_write+0xb20>
    73a1:	83 e6 21             	and    $0x21,%esi
    73a4:	74 75                	je     741b <fwp_write+0x78b>
    73a6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    73ab:	48 85 ff             	test   %rdi,%rdi
    73ae:	79 07                	jns    73b7 <fwp_write+0x727>
    73b0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    73b4:	4c 01 ee             	add    %r13,%rsi
    73b7:	48 0f be 3e          	movsbq (%rsi),%rdi
    73bb:	85 c9                	test   %ecx,%ecx
    73bd:	40 0f b6 f7          	movzbl %dil,%esi
    73c1:	48 0f 44 f7          	cmove  %rdi,%rsi
    73c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73cc:	00 00 00 00 
    73d0:	31 c9                	xor    %ecx,%ecx
    73d2:	48 89 df             	mov    %rbx,%rdi
    73d5:	49 83 c5 01          	add    $0x1,%r13
    73d9:	e8 b2 f8 ff ff       	call   6c90 <fwp_write>
    73de:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    73e5:	ff ff 7f 
    73e8:	48 23 55 00          	and    0x0(%rbp),%rdx
    73ec:	49 39 d5             	cmp    %rdx,%r13
    73ef:	0f 83 ec 01 00 00    	jae    75e1 <fwp_write+0x951>
    73f5:	ba 02 00 00 00       	mov    $0x2,%edx
    73fa:	48 89 df             	mov    %rbx,%rdi
    73fd:	48 8d 35 30 4d 00 00 	lea    0x4d30(%rip),%rsi        # c134 <_IO_stdin_used+0x134>
    7404:	e8 e7 bb ff ff       	call   2ff0 <buf_put>
    7409:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    740e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    7412:	48 85 d2             	test   %rdx,%rdx
    7415:	0f 85 52 ff ff ff    	jne    736d <fwp_write+0x6dd>
    741b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    7420:	48 85 ff             	test   %rdi,%rdi
    7423:	0f 88 cf 05 00 00    	js     79f8 <fwp_write+0xd68>
    7429:	48 8b 31             	mov    (%rcx),%rsi
    742c:	eb a2                	jmp    73d0 <fwp_write+0x740>
    742e:	66 90                	xchg   %ax,%ax
    7430:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7437:	00 
    7438:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    743f:	00 00 
    7441:	0f 85 1e fd ff ff    	jne    7165 <fwp_write+0x4d5>
    7447:	ba 08 00 00 00       	mov    $0x8,%edx
    744c:	48 8d 35 b1 4c 00 00 	lea    0x4cb1(%rip),%rsi        # c104 <_IO_stdin_used+0x104>
    7453:	e9 4b fa ff ff       	jmp    6ea3 <fwp_write+0x213>
    7458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    745f:	00 
    7460:	89 e8                	mov    %ebp,%eax
    7462:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    7469:	76 03                	jbe    746e <fwp_write+0x7de>
    746b:	8b 45 00             	mov    0x0(%rbp),%eax
    746e:	41 89 c6             	mov    %eax,%r14d
    7471:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    7476:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    747b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    747f:	4c 89 ef             	mov    %r13,%rdi
    7482:	e8 a9 af ff ff       	call   2430 <strlen@plt>
    7487:	4c 89 ee             	mov    %r13,%rsi
    748a:	48 89 df             	mov    %rbx,%rdi
    748d:	48 89 c2             	mov    %rax,%rdx
    7490:	e8 5b bb ff ff       	call   2ff0 <buf_put>
    7495:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    749a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    749e:	85 f6                	test   %esi,%esi
    74a0:	0f 8e 80 f8 ff ff    	jle    6d26 <fwp_write+0x96>
    74a6:	45 31 ed             	xor    %r13d,%r13d
    74a9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    74ae:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    74b3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    74b8:	ba 01 00 00 00       	mov    $0x1,%edx
    74bd:	4c 89 fe             	mov    %r15,%rsi
    74c0:	48 89 04 24          	mov    %rax,(%rsp)
    74c4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    74c9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    74cd:	48 89 df             	mov    %rbx,%rdi
    74d0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    74d4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    74d9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    74de:	e8 0d bb ff ff       	call   2ff0 <buf_put>
    74e3:	41 8b 06             	mov    (%r14),%eax
    74e6:	83 f8 0e             	cmp    $0xe,%eax
    74e9:	0f 84 71 02 00 00    	je     7760 <fwp_write+0xad0>
    74ef:	83 f8 10             	cmp    $0x10,%eax
    74f2:	0f 84 38 02 00 00    	je     7730 <fwp_write+0xaa0>
    74f8:	83 f8 0a             	cmp    $0xa,%eax
    74fb:	0f 84 7f 04 00 00    	je     7980 <fwp_write+0xcf0>
    7501:	0f 8f f9 00 00 00    	jg     7600 <fwp_write+0x970>
    7507:	83 f8 03             	cmp    $0x3,%eax
    750a:	0f 8f 50 04 00 00    	jg     7960 <fwp_write+0xcd0>
    7510:	85 c0                	test   %eax,%eax
    7512:	78 10                	js     7524 <fwp_write+0x894>
    7514:	48 8b 04 24          	mov    (%rsp),%rax
    7518:	48 c1 e8 3f          	shr    $0x3f,%rax
    751c:	85 c0                	test   %eax,%eax
    751e:	0f 85 f9 00 00 00    	jne    761d <fwp_write+0x98d>
    7524:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7529:	48 8b 34 24          	mov    (%rsp),%rsi
    752d:	31 c9                	xor    %ecx,%ecx
    752f:	48 89 df             	mov    %rbx,%rdi
    7532:	e8 59 f7 ff ff       	call   6c90 <fwp_write>
    7537:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    753c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7541:	49 83 c5 01          	add    $0x1,%r13
    7545:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    7549:	0f 8f 5f ff ff ff    	jg     74ae <fwp_write+0x81e>
    754f:	e9 d2 f7 ff ff       	jmp    6d26 <fwp_write+0x96>
    7554:	0f 1f 40 00          	nopl   0x0(%rax)
    7558:	ba 06 00 00 00       	mov    $0x6,%edx
    755d:	48 8d 35 c6 4b 00 00 	lea    0x4bc6(%rip),%rsi        # c12a <_IO_stdin_used+0x12a>
    7564:	45 31 ed             	xor    %r13d,%r13d
    7567:	e8 84 ba ff ff       	call   2ff0 <buf_put>
    756c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    7571:	75 19                	jne    758c <fwp_write+0x8fc>
    7573:	eb 6c                	jmp    75e1 <fwp_write+0x951>
    7575:	0f 1f 00             	nopl   (%rax)
    7578:	ba 02 00 00 00       	mov    $0x2,%edx
    757d:	48 8d 35 b0 4b 00 00 	lea    0x4bb0(%rip),%rsi        # c134 <_IO_stdin_used+0x134>
    7584:	48 89 df             	mov    %rbx,%rdi
    7587:	e8 64 ba ff ff       	call   2ff0 <buf_put>
    758c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    7592:	b9 00 02 00 00       	mov    $0x200,%ecx
    7597:	31 c0                	xor    %eax,%eax
    7599:	49 83 c5 01          	add    $0x1,%r13
    759d:	4c 8d 05 8d 4b 00 00 	lea    0x4b8d(%rip),%r8        # c131 <_IO_stdin_used+0x131>
    75a4:	ba 02 00 00 00       	mov    $0x2,%edx
    75a9:	be 00 02 00 00       	mov    $0x200,%esi
    75ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    75b5:	00 
    75b6:	e8 d5 ad ff ff       	call   2390 <__snprintf_chk@plt>
    75bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    75c2:	00 
    75c3:	e8 68 ae ff ff       	call   2430 <strlen@plt>
    75c8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    75cf:	00 
    75d0:	48 89 df             	mov    %rbx,%rdi
    75d3:	48 89 c2             	mov    %rax,%rdx
    75d6:	e8 15 ba ff ff       	call   2ff0 <buf_put>
    75db:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    75df:	72 97                	jb     7578 <fwp_write+0x8e8>
    75e1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    75e6:	ba 01 00 00 00       	mov    $0x1,%edx
    75eb:	48 89 df             	mov    %rbx,%rdi
    75ee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    75f3:	e8 f8 b9 ff ff       	call   2ff0 <buf_put>
    75f8:	e9 29 f7 ff ff       	jmp    6d26 <fwp_write+0x96>
    75fd:	0f 1f 00             	nopl   (%rax)
    7600:	83 f8 0b             	cmp    $0xb,%eax
    7603:	0f 85 1b ff ff ff    	jne    7524 <fwp_write+0x894>
    7609:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    760e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    7612:	83 e0 01             	and    $0x1,%eax
    7615:	85 c0                	test   %eax,%eax
    7617:	0f 84 07 ff ff ff    	je     7524 <fwp_write+0x894>
    761d:	4c 89 fe             	mov    %r15,%rsi
    7620:	48 89 df             	mov    %rbx,%rdi
    7623:	ba 01 00 00 00       	mov    $0x1,%edx
    7628:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    762d:	e8 be b9 ff ff       	call   2ff0 <buf_put>
    7632:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7637:	48 8b 34 24          	mov    (%rsp),%rsi
    763b:	31 c9                	xor    %ecx,%ecx
    763d:	48 89 df             	mov    %rbx,%rdi
    7640:	e8 4b f6 ff ff       	call   6c90 <fwp_write>
    7645:	ba 01 00 00 00       	mov    $0x1,%edx
    764a:	4c 89 fe             	mov    %r15,%rsi
    764d:	48 89 df             	mov    %rbx,%rdi
    7650:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    7655:	e8 96 b9 ff ff       	call   2ff0 <buf_put>
    765a:	e9 d8 fe ff ff       	jmp    7537 <fwp_write+0x8a7>
    765f:	90                   	nop
    7660:	ba 01 00 00 00       	mov    $0x1,%edx
    7665:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    766a:	48 89 df             	mov    %rbx,%rdi
    766d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    7672:	e8 79 b9 ff ff       	call   2ff0 <buf_put>
    7677:	e9 aa f6 ff ff       	jmp    6d26 <fwp_write+0x96>
    767c:	0f 1f 40 00          	nopl   0x0(%rax)
    7680:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7685:	ba 01 00 00 00       	mov    $0x1,%edx
    768a:	48 89 df             	mov    %rbx,%rdi
    768d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    7692:	e8 59 b9 ff ff       	call   2ff0 <buf_put>
    7697:	e9 8a f6 ff ff       	jmp    6d26 <fwp_write+0x96>
    769c:	0f 1f 40 00          	nopl   0x0(%rax)
    76a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    76a4:	48 8b 13             	mov    (%rbx),%rdx
    76a7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    76ac:	48 89 43 08          	mov    %rax,0x8(%rbx)
    76b0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    76b4:	e9 6d f6 ff ff       	jmp    6d26 <fwp_write+0x96>
    76b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c0:	ba 02 00 00 00       	mov    $0x2,%edx
    76c5:	48 8d 35 68 4a 00 00 	lea    0x4a68(%rip),%rsi        # c134 <_IO_stdin_used+0x134>
    76cc:	48 89 df             	mov    %rbx,%rdi
    76cf:	e8 1c b9 ff ff       	call   2ff0 <buf_put>
    76d4:	e9 72 f8 ff ff       	jmp    6f4b <fwp_write+0x2bb>
    76d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76e0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    76e5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76ea:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    76ee:	48 89 f7             	mov    %rsi,%rdi
    76f1:	48 89 34 24          	mov    %rsi,(%rsp)
    76f5:	e8 36 ad ff ff       	call   2430 <strlen@plt>
    76fa:	48 8b 34 24          	mov    (%rsp),%rsi
    76fe:	48 89 df             	mov    %rbx,%rdi
    7701:	48 89 c2             	mov    %rax,%rdx
    7704:	e8 e7 b8 ff ff       	call   2ff0 <buf_put>
    7709:	ba 03 00 00 00       	mov    $0x3,%edx
    770e:	48 8d 35 42 4a 00 00 	lea    0x4a42(%rip),%rsi        # c157 <_IO_stdin_used+0x157>
    7715:	48 89 df             	mov    %rbx,%rdi
    7718:	e8 d3 b8 ff ff       	call   2ff0 <buf_put>
    771d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7722:	e9 35 f8 ff ff       	jmp    6f5c <fwp_write+0x2cc>
    7727:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    772e:	00 00 
    7730:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    7735:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7739:	48 85 ff             	test   %rdi,%rdi
    773c:	0f 84 e2 fd ff ff    	je     7524 <fwp_write+0x894>
    7742:	48 8d 35 f8 49 00 00 	lea    0x49f8(%rip),%rsi        # c141 <_IO_stdin_used+0x141>
    7749:	e8 c2 ad ff ff       	call   2510 <strcmp@plt>
    774e:	85 c0                	test   %eax,%eax
    7750:	0f 95 c0             	setne  %al
    7753:	0f b6 c0             	movzbl %al,%eax
    7756:	e9 c1 fd ff ff       	jmp    751c <fwp_write+0x88c>
    775b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7760:	31 c0                	xor    %eax,%eax
    7762:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    7769:	00 
    776a:	0f 97 c0             	seta   %al
    776d:	e9 aa fd ff ff       	jmp    751c <fwp_write+0x88c>
    7772:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7778:	48 89 df             	mov    %rbx,%rdi
    777b:	ba 02 00 00 00       	mov    $0x2,%edx
    7780:	48 8d 35 b7 49 00 00 	lea    0x49b7(%rip),%rsi        # c13e <_IO_stdin_used+0x13e>
    7787:	e8 64 b8 ff ff       	call   2ff0 <buf_put>
    778c:	4c 89 e8             	mov    %r13,%rax
    778f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    7794:	31 c9                	xor    %ecx,%ecx
    7796:	48 c1 e0 04          	shl    $0x4,%rax
    779a:	48 89 df             	mov    %rbx,%rdi
    779d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    77a2:	e8 e9 f4 ff ff       	call   6c90 <fwp_write>
    77a7:	e9 5e f6 ff ff       	jmp    6e0a <fwp_write+0x17a>
    77ac:	0f 1f 40 00          	nopl   0x0(%rax)
    77b0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    77b5:	48 85 ff             	test   %rdi,%rdi
    77b8:	79 0c                	jns    77c6 <fwp_write+0xb36>
    77ba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    77c1:	00 
    77c2:	48 03 75 10          	add    0x10(%rbp),%rsi
    77c6:	48 63 3e             	movslq (%rsi),%rdi
    77c9:	83 f9 02             	cmp    $0x2,%ecx
    77cc:	89 fe                	mov    %edi,%esi
    77ce:	48 0f 44 f7          	cmove  %rdi,%rsi
    77d2:	e9 f9 fb ff ff       	jmp    73d0 <fwp_write+0x740>
    77d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77de:	00 00 
    77e0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    77e5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    77ea:	48 85 ff             	test   %rdi,%rdi
    77ed:	0f 88 0f 03 00 00    	js     7b02 <fwp_write+0xe72>
    77f3:	49 0f bf 38          	movswq (%r8),%rdi
    77f7:	83 f9 01             	cmp    $0x1,%ecx
    77fa:	0f b7 f7             	movzwl %di,%esi
    77fd:	48 0f 44 f7          	cmove  %rdi,%rsi
    7801:	e9 ca fb ff ff       	jmp    73d0 <fwp_write+0x740>
    7806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    780d:	00 00 00 
    7810:	ba 01 00 00 00       	mov    $0x1,%edx
    7815:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    781a:	48 83 c5 08          	add    $0x8,%rbp
    781e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    7823:	e8 c8 b7 ff ff       	call   2ff0 <buf_put>
    7828:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    782d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    7832:	4d 85 ed             	test   %r13,%r13
    7835:	75 46                	jne    787d <fwp_write+0xbed>
    7837:	e9 04 01 00 00       	jmp    7940 <fwp_write+0xcb0>
    783c:	0f 1f 40 00          	nopl   0x0(%rax)
    7840:	41 80 f9 09          	cmp    $0x9,%r9b
    7844:	0f 84 d6 00 00 00    	je     7920 <fwp_write+0xc90>
    784a:	41 80 f9 0a          	cmp    $0xa,%r9b
    784e:	0f 85 9c 00 00 00    	jne    78f0 <fwp_write+0xc60>
    7854:	ba 02 00 00 00       	mov    $0x2,%edx
    7859:	48 8d 35 ba 48 00 00 	lea    0x48ba(%rip),%rsi        # c11a <_IO_stdin_used+0x11a>
    7860:	48 89 df             	mov    %rbx,%rdi
    7863:	e8 88 b7 ff ff       	call   2ff0 <buf_put>
    7868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    786f:	00 
    7870:	48 83 c5 01          	add    $0x1,%rbp
    7874:	49 39 ec             	cmp    %rbp,%r12
    7877:	0f 84 c3 00 00 00    	je     7940 <fwp_write+0xcb0>
    787d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    7882:	41 80 f9 0d          	cmp    $0xd,%r9b
    7886:	74 28                	je     78b0 <fwp_write+0xc20>
    7888:	7e b6                	jle    7840 <fwp_write+0xbb0>
    788a:	41 80 f9 22          	cmp    $0x22,%r9b
    788e:	74 40                	je     78d0 <fwp_write+0xc40>
    7890:	41 80 f9 5c          	cmp    $0x5c,%r9b
    7894:	75 5a                	jne    78f0 <fwp_write+0xc60>
    7896:	ba 02 00 00 00       	mov    $0x2,%edx
    789b:	48 8d 35 75 48 00 00 	lea    0x4875(%rip),%rsi        # c117 <_IO_stdin_used+0x117>
    78a2:	48 89 df             	mov    %rbx,%rdi
    78a5:	e8 46 b7 ff ff       	call   2ff0 <buf_put>
    78aa:	eb c4                	jmp    7870 <fwp_write+0xbe0>
    78ac:	0f 1f 40 00          	nopl   0x0(%rax)
    78b0:	ba 02 00 00 00       	mov    $0x2,%edx
    78b5:	48 8d 35 64 48 00 00 	lea    0x4864(%rip),%rsi        # c120 <_IO_stdin_used+0x120>
    78bc:	48 89 df             	mov    %rbx,%rdi
    78bf:	e8 2c b7 ff ff       	call   2ff0 <buf_put>
    78c4:	eb aa                	jmp    7870 <fwp_write+0xbe0>
    78c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78cd:	00 00 00 
    78d0:	ba 02 00 00 00       	mov    $0x2,%edx
    78d5:	48 8d 35 38 48 00 00 	lea    0x4838(%rip),%rsi        # c114 <_IO_stdin_used+0x114>
    78dc:	48 89 df             	mov    %rbx,%rdi
    78df:	e8 0c b7 ff ff       	call   2ff0 <buf_put>
    78e4:	eb 8a                	jmp    7870 <fwp_write+0xbe0>
    78e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ed:	00 00 00 
    78f0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    78f4:	0f 86 2e 01 00 00    	jbe    7a28 <fwp_write+0xd98>
    78fa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    78fe:	0f 84 24 01 00 00    	je     7a28 <fwp_write+0xd98>
    7904:	ba 01 00 00 00       	mov    $0x1,%edx
    7909:	4c 89 fe             	mov    %r15,%rsi
    790c:	48 89 df             	mov    %rbx,%rdi
    790f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    7914:	e8 d7 b6 ff ff       	call   2ff0 <buf_put>
    7919:	e9 52 ff ff ff       	jmp    7870 <fwp_write+0xbe0>
    791e:	66 90                	xchg   %ax,%ax
    7920:	ba 02 00 00 00       	mov    $0x2,%edx
    7925:	48 8d 35 f1 47 00 00 	lea    0x47f1(%rip),%rsi        # c11d <_IO_stdin_used+0x11d>
    792c:	48 89 df             	mov    %rbx,%rdi
    792f:	e8 bc b6 ff ff       	call   2ff0 <buf_put>
    7934:	e9 37 ff ff ff       	jmp    7870 <fwp_write+0xbe0>
    7939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7940:	ba 01 00 00 00       	mov    $0x1,%edx
    7945:	4c 89 fe             	mov    %r15,%rsi
    7948:	48 89 df             	mov    %rbx,%rdi
    794b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    7950:	e8 9b b6 ff ff       	call   2ff0 <buf_put>
    7955:	e9 cc f3 ff ff       	jmp    6d26 <fwp_write+0x96>
    795a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7960:	83 f8 04             	cmp    $0x4,%eax
    7963:	0f 85 bb fb ff ff    	jne    7524 <fwp_write+0x894>
    7969:	48 8b 04 24          	mov    (%rsp),%rax
    796d:	48 8b 40 08          	mov    0x8(%rax),%rax
    7971:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7976:	48 c1 e8 3f          	shr    $0x3f,%rax
    797a:	e9 96 fc ff ff       	jmp    7615 <fwp_write+0x985>
    797f:	90                   	nop
    7980:	8b 0c 24             	mov    (%rsp),%ecx
    7983:	31 c0                	xor    %eax,%eax
    7985:	85 c9                	test   %ecx,%ecx
    7987:	0f 98 c0             	sets   %al
    798a:	e9 86 fc ff ff       	jmp    7615 <fwp_write+0x985>
    798f:	90                   	nop
    7990:	48 f7 d8             	neg    %rax
    7993:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    799a:	00 
    799b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    79a2:	2d 
    79a3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    79aa:	00 
    79ab:	48 83 d2 00          	adc    $0x0,%rdx
    79af:	48 89 c6             	mov    %rax,%rsi
    79b2:	48 f7 da             	neg    %rdx
    79b5:	e8 46 b0 ff ff       	call   2a00 <fwp_fmt_u128>
    79ba:	e9 51 f3 ff ff       	jmp    6d10 <fwp_write+0x80>
    79bf:	90                   	nop
    79c0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    79c5:	e9 c3 f5 ff ff       	jmp    6f8d <fwp_write+0x2fd>
    79ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79d0:	4c 89 e9             	mov    %r13,%rcx
    79d3:	48 c1 e1 04          	shl    $0x4,%rcx
    79d7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    79dc:	48 85 ff             	test   %rdi,%rdi
    79df:	0f 89 eb f9 ff ff    	jns    73d0 <fwp_write+0x740>
    79e5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    79e9:	48 89 ce             	mov    %rcx,%rsi
    79ec:	e9 df f9 ff ff       	jmp    73d0 <fwp_write+0x740>
    79f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    79ff:	00 
    7a00:	48 03 4d 10          	add    0x10(%rbp),%rcx
    7a04:	e9 20 fa ff ff       	jmp    7429 <fwp_write+0x799>
    7a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a10:	ba 02 00 00 00       	mov    $0x2,%edx
    7a15:	48 8d 35 c3 46 00 00 	lea    0x46c3(%rip),%rsi        # c0df <_IO_stdin_used+0xdf>
    7a1c:	e9 2d f7 ff ff       	jmp    714e <fwp_write+0x4be>
    7a21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a28:	4c 8d 05 f4 46 00 00 	lea    0x46f4(%rip),%r8        # c123 <_IO_stdin_used+0x123>
    7a2f:	b9 10 00 00 00       	mov    $0x10,%ecx
    7a34:	31 c0                	xor    %eax,%eax
    7a36:	ba 02 00 00 00       	mov    $0x2,%edx
    7a3b:	be 10 00 00 00       	mov    $0x10,%esi
    7a40:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7a47:	00 
    7a48:	e8 43 a9 ff ff       	call   2390 <__snprintf_chk@plt>
    7a4d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7a54:	00 
    7a55:	e8 d6 a9 ff ff       	call   2430 <strlen@plt>
    7a5a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    7a61:	00 
    7a62:	48 89 df             	mov    %rbx,%rdi
    7a65:	48 89 c2             	mov    %rax,%rdx
    7a68:	e8 83 b5 ff ff       	call   2ff0 <buf_put>
    7a6d:	e9 fe fd ff ff       	jmp    7870 <fwp_write+0xbe0>
    7a72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7a7c:	48 8d 35 56 46 00 00 	lea    0x4656(%rip),%rsi        # c0d9 <_IO_stdin_used+0xd9>
    7a83:	48 8d 05 4e 46 00 00 	lea    0x464e(%rip),%rax        # c0d8 <_IO_stdin_used+0xd8>
    7a8a:	4c 89 e7             	mov    %r12,%rdi
    7a8d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    7a91:	48 0f 46 f0          	cmovbe %rax,%rsi
    7a95:	e8 36 a9 ff ff       	call   23d0 <strcpy@plt>
    7a9a:	e9 71 f2 ff ff       	jmp    6d10 <fwp_write+0x80>
    7a9f:	90                   	nop
    7aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7aa4:	48 8d 35 2e 46 00 00 	lea    0x462e(%rip),%rsi        # c0d9 <_IO_stdin_used+0xd9>
    7aab:	48 8d 05 26 46 00 00 	lea    0x4626(%rip),%rax        # c0d8 <_IO_stdin_used+0xd8>
    7ab2:	0f 2f c8             	comiss %xmm0,%xmm1
    7ab5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7abc:	00 
    7abd:	4c 89 e7             	mov    %r12,%rdi
    7ac0:	48 0f 46 f0          	cmovbe %rax,%rsi
    7ac4:	e8 07 a9 ff ff       	call   23d0 <strcpy@plt>
    7ac9:	e9 42 f2 ff ff       	jmp    6d10 <fwp_write+0x80>
    7ace:	66 90                	xchg   %ax,%ax
    7ad0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    7ad5:	45 85 c0             	test   %r8d,%r8d
    7ad8:	75 34                	jne    7b0e <fwp_write+0xe7e>
    7ada:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7ae1:	00 
    7ae2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7ae9:	00 00 
    7aeb:	0f 85 74 f6 ff ff    	jne    7165 <fwp_write+0x4d5>
    7af1:	ba 02 00 00 00       	mov    $0x2,%edx
    7af6:	48 8d 35 57 46 00 00 	lea    0x4657(%rip),%rsi        # c154 <_IO_stdin_used+0x154>
    7afd:	e9 a1 f3 ff ff       	jmp    6ea3 <fwp_write+0x213>
    7b02:	48 03 75 10          	add    0x10(%rbp),%rsi
    7b06:	49 89 f0             	mov    %rsi,%r8
    7b09:	e9 e5 fc ff ff       	jmp    77f3 <fwp_write+0xb63>
    7b0e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    7b13:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    7b18:	85 ff                	test   %edi,%edi
    7b1a:	0f 84 fa f3 ff ff    	je     6f1a <fwp_write+0x28a>
    7b20:	ba 01 00 00 00       	mov    $0x1,%edx
    7b25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7b2a:	48 89 df             	mov    %rbx,%rdi
    7b2d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    7b32:	e8 b9 b4 ff ff       	call   2ff0 <buf_put>
    7b37:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    7b3c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    7b41:	41 be 01 00 00 00    	mov    $0x1,%r14d
    7b47:	85 c0                	test   %eax,%eax
    7b49:	0f 8f f0 f3 ff ff    	jg     6f3f <fwp_write+0x2af>
    7b4f:	e9 34 f4 ff ff       	jmp    6f88 <fwp_write+0x2f8>
    7b54:	48 8b 45 08          	mov    0x8(%rbp),%rax
    7b58:	49 89 c5             	mov    %rax,%r13
    7b5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b60:	49 89 c4             	mov    %rax,%r12
    7b63:	49 c1 fd 3f          	sar    $0x3f,%r13
    7b67:	4c 09 e8             	or     %r13,%rax
    7b6a:	0f 84 a7 00 00 00    	je     7c17 <fwp_write+0xf87>
    7b70:	48 8d 2d 49 6f 00 00 	lea    0x6f49(%rip),%rbp        # eac0 <units.0>
    7b77:	4d 89 e7             	mov    %r12,%r15
    7b7a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    7b7e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    7b83:	4c 89 ff             	mov    %r15,%rdi
    7b86:	4c 89 ee             	mov    %r13,%rsi
    7b89:	44 89 0c 24          	mov    %r9d,(%rsp)
    7b8d:	48 99                	cqto
    7b8f:	48 89 d1             	mov    %rdx,%rcx
    7b92:	48 89 c2             	mov    %rax,%rdx
    7b95:	e8 46 35 00 00       	call   b0e0 <__divmodti4>
    7b9a:	44 8b 0c 24          	mov    (%rsp),%r9d
    7b9e:	48 89 c1             	mov    %rax,%rcx
    7ba1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7ba6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    7bab:	0f 84 94 00 00 00    	je     7c45 <fwp_write+0xfb5>
    7bb1:	41 83 c1 01          	add    $0x1,%r9d
    7bb5:	48 83 c5 10          	add    $0x10,%rbp
    7bb9:	41 83 f9 05          	cmp    $0x5,%r9d
    7bbd:	75 bb                	jne    7b7a <fwp_write+0xeea>
    7bbf:	4d 85 ed             	test   %r13,%r13
    7bc2:	79 53                	jns    7c17 <fwp_write+0xf87>
    7bc4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bc9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    7bce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    7bd3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7bd8:	48 99                	cqto
    7bda:	48 f7 d8             	neg    %rax
    7bdd:	48 83 d2 00          	adc    $0x0,%rdx
    7be1:	48 89 c6             	mov    %rax,%rsi
    7be4:	48 f7 da             	neg    %rdx
    7be7:	e8 14 ae ff ff       	call   2a00 <fwp_fmt_u128>
    7bec:	49 89 e8             	mov    %rbp,%r8
    7bef:	ba 00 02 00 00       	mov    $0x200,%edx
    7bf4:	be 02 00 00 00       	mov    $0x2,%esi
    7bf9:	31 c0                	xor    %eax,%eax
    7bfb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7c02:	00 
    7c03:	48 8d 0d 45 45 00 00 	lea    0x4545(%rip),%rcx        # c14f <_IO_stdin_used+0x14f>
    7c0a:	4c 89 e7             	mov    %r12,%rdi
    7c0d:	e8 8e aa ff ff       	call   26a0 <__sprintf_chk@plt>
    7c12:	e9 f9 f0 ff ff       	jmp    6d10 <fwp_write+0x80>
    7c17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7c1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7c21:	31 d2                	xor    %edx,%edx
    7c23:	48 89 ef             	mov    %rbp,%rdi
    7c26:	e8 d5 ad ff ff       	call   2a00 <fwp_fmt_u128>
    7c2b:	eb bf                	jmp    7bec <fwp_write+0xf5c>
    7c2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    7c34:	4e 61 4e 00 
    7c38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7c3f:	00 
    7c40:	e9 cb f0 ff ff       	jmp    6d10 <fwp_write+0x80>
    7c45:	44 89 0c 24          	mov    %r9d,(%rsp)
    7c49:	48 89 c8             	mov    %rcx,%rax
    7c4c:	48 85 d2             	test   %rdx,%rdx
    7c4f:	78 51                	js     7ca2 <fwp_write+0x1012>
    7c51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7c56:	48 89 c6             	mov    %rax,%rsi
    7c59:	48 89 ef             	mov    %rbp,%rdi
    7c5c:	e8 9f ad ff ff       	call   2a00 <fwp_fmt_u128>
    7c61:	44 8b 0c 24          	mov    (%rsp),%r9d
    7c65:	49 63 c1             	movslq %r9d,%rax
    7c68:	49 89 e8             	mov    %rbp,%r8
    7c6b:	ba 00 02 00 00       	mov    $0x200,%edx
    7c70:	be 02 00 00 00       	mov    $0x2,%esi
    7c75:	48 c1 e0 04          	shl    $0x4,%rax
    7c79:	48 8d 3d 40 6e 00 00 	lea    0x6e40(%rip),%rdi        # eac0 <units.0>
    7c80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7c87:	00 
    7c88:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    7c8c:	48 8d 0d b7 44 00 00 	lea    0x44b7(%rip),%rcx        # c14a <_IO_stdin_used+0x14a>
    7c93:	4c 89 e7             	mov    %r12,%rdi
    7c96:	31 c0                	xor    %eax,%eax
    7c98:	e8 03 aa ff ff       	call   26a0 <__sprintf_chk@plt>
    7c9d:	e9 6e f0 ff ff       	jmp    6d10 <fwp_write+0x80>
    7ca2:	48 f7 d8             	neg    %rax
    7ca5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    7caa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    7caf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7cb4:	48 83 d2 00          	adc    $0x0,%rdx
    7cb8:	48 89 c6             	mov    %rax,%rsi
    7cbb:	48 f7 da             	neg    %rdx
    7cbe:	e8 3d ad ff ff       	call   2a00 <fwp_fmt_u128>
    7cc3:	44 8b 0c 24          	mov    (%rsp),%r9d
    7cc7:	eb 9c                	jmp    7c65 <fwp_write+0xfd5>
    7cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007cd0 <f0>:
    7cd0:	41 57                	push   %r15
    7cd2:	41 56                	push   %r14
    7cd4:	41 55                	push   %r13
    7cd6:	41 bd 07 00 00 00    	mov    $0x7,%r13d
    7cdc:	41 54                	push   %r12
    7cde:	45 31 e4             	xor    %r12d,%r12d
    7ce1:	55                   	push   %rbp
    7ce2:	53                   	push   %rbx
    7ce3:	48 8d 1d f6 79 01 00 	lea    0x179f6(%rip),%rbx        # 1f6e0 <fwp_heap>
    7cea:	48 81 ec 88 08 00 00 	sub    $0x888,%rsp
    7cf1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7cf8:	00 00 
    7cfa:	48 89 84 24 78 08 00 	mov    %rax,0x878(%rsp)
    7d01:	00 
    7d02:	31 c0                	xor    %eax,%eax
    7d04:	48 8d ac 24 60 08 00 	lea    0x860(%rsp),%rbp
    7d0b:	00 
    7d0c:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    7d13:	00 00 
    7d15:	66 48 0f 6e c0       	movq   %rax,%xmm0
    7d1a:	48 8d 05 cf df ff ff 	lea    -0x2031(%rip),%rax        # 5cf0 <fwp_drop1>
    7d21:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7d26:	48 8b 05 43 96 01 00 	mov    0x19643(%rip),%rax        # 21370 <fwp_cleanups>
    7d2d:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    7d31:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7d36:	48 8d 05 53 ae ff ff 	lea    -0x51ad(%rip),%rax        # 2b90 <fwp_range_release>
    7d3d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    7d42:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    7d47:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7d4c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7d51:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    7d56:	48 89 05 13 96 01 00 	mov    %rax,0x19613(%rip)        # 21370 <fwp_cleanups>
    7d5d:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    7d62:	eb 3f                	jmp    7da3 <f0+0xd3>
    7d64:	0f 1f 40 00          	nopl   0x0(%rax)
    7d68:	80 f9 01             	cmp    $0x1,%cl
    7d6b:	75 27                	jne    7d94 <f0+0xc4>
    7d6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d70:	0f b7 c0             	movzwl %ax,%eax
    7d73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d76:	48 0f af c1          	imul   %rcx,%rax
    7d7a:	48 c1 e8 20          	shr    $0x20,%rax
    7d7e:	48 39 d0             	cmp    %rdx,%rax
    7d81:	73 11                	jae    7d94 <f0+0xc4>
    7d83:	49 01 c6             	add    %rax,%r14
    7d86:	41 80 3e ff          	cmpb   $0xff,(%r14)
    7d8a:	0f 84 00 28 00 00    	je     a590 <f0+0x28c0>
    7d90:	41 c6 06 01          	movb   $0x1,(%r14)
    7d94:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    7d99:	49 83 ed 01          	sub    $0x1,%r13
    7d9d:	0f 82 7d 00 00 00    	jb     7e20 <f0+0x150>
    7da3:	48 89 ee             	mov    %rbp,%rsi
    7da6:	bf 01 00 00 00       	mov    $0x1,%edi
    7dab:	4c 89 a4 24 68 08 00 	mov    %r12,0x868(%rsp)
    7db2:	00 
    7db3:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
    7db8:	4c 89 ac 24 60 08 00 	mov    %r13,0x860(%rsp)
    7dbf:	00 
    7dc0:	e8 ab d4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    7dc5:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    7dcc:	49 89 c4             	mov    %rax,%r12
    7dcf:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    7dd6:	48 c1 e2 10          	shl    $0x10,%rdx
    7dda:	48 39 d0             	cmp    %rdx,%rax
    7ddd:	73 b5                	jae    7d94 <f0+0xc4>
    7ddf:	48 89 c2             	mov    %rax,%rdx
    7de2:	48 c1 ea 10          	shr    $0x10,%rdx
    7de6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7dea:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    7df1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7df5:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    7df9:	4d 85 f6             	test   %r14,%r14
    7dfc:	74 96                	je     7d94 <f0+0xc4>
    7dfe:	0f b6 0a             	movzbl (%rdx),%ecx
    7e01:	80 f9 02             	cmp    $0x2,%cl
    7e04:	0f 85 5e ff ff ff    	jne    7d68 <f0+0x98>
    7e0a:	66 85 c0             	test   %ax,%ax
    7e0d:	0f 84 73 ff ff ff    	je     7d86 <f0+0xb6>
    7e13:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    7e18:	49 83 ed 01          	sub    $0x1,%r13
    7e1c:	73 85                	jae    7da3 <f0+0xd3>
    7e1e:	66 90                	xchg   %ax,%ax
    7e20:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7e25:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    7e2a:	bf 01 00 00 00       	mov    $0x1,%edi
    7e2f:	66 0f 6f 05 d9 46 00 	movdqa 0x46d9(%rip),%xmm0        # c510 <msg.3+0xc0>
    7e36:	00 
    7e37:	48 89 05 32 95 01 00 	mov    %rax,0x19532(%rip)        # 21370 <fwp_cleanups>
    7e3e:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
    7e43:	e8 28 d4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    7e48:	48 8b 15 69 8c 01 00 	mov    0x18c69(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    7e4f:	49 89 c6             	mov    %rax,%r14
    7e52:	48 2b 05 37 8c 01 00 	sub    0x18c37(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    7e59:	48 c1 e2 10          	shl    $0x10,%rdx
    7e5d:	48 39 d0             	cmp    %rdx,%rax
    7e60:	73 59                	jae    7ebb <f0+0x1eb>
    7e62:	48 89 c2             	mov    %rax,%rdx
    7e65:	48 c1 ea 10          	shr    $0x10,%rdx
    7e69:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e6d:	48 8b 15 64 8c 01 00 	mov    0x18c64(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    7e74:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e78:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7e7c:	4d 85 ed             	test   %r13,%r13
    7e7f:	74 3a                	je     7ebb <f0+0x1eb>
    7e81:	0f b6 0a             	movzbl (%rdx),%ecx
    7e84:	80 f9 02             	cmp    $0x2,%cl
    7e87:	0f 84 63 27 00 00    	je     a5f0 <f0+0x2920>
    7e8d:	80 f9 01             	cmp    $0x1,%cl
    7e90:	75 29                	jne    7ebb <f0+0x1eb>
    7e92:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e95:	0f b7 c0             	movzwl %ax,%eax
    7e98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e9b:	48 0f af c1          	imul   %rcx,%rax
    7e9f:	48 c1 e8 20          	shr    $0x20,%rax
    7ea3:	48 39 d0             	cmp    %rdx,%rax
    7ea6:	73 13                	jae    7ebb <f0+0x1eb>
    7ea8:	49 01 c5             	add    %rax,%r13
    7eab:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7eb0:	0f 84 55 29 00 00    	je     a80b <f0+0x2b3b>
    7eb6:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    7ebb:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    7ec0:	bf 01 00 00 00       	mov    $0x1,%edi
    7ec5:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    7eca:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    7ed1:	00 f0 3f 
    7ed4:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7ed9:	e8 92 d3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    7ede:	48 8b 15 d3 8b 01 00 	mov    0x18bd3(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    7ee5:	49 89 c6             	mov    %rax,%r14
    7ee8:	48 2b 05 a1 8b 01 00 	sub    0x18ba1(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    7eef:	48 c1 e2 10          	shl    $0x10,%rdx
    7ef3:	48 39 d0             	cmp    %rdx,%rax
    7ef6:	73 59                	jae    7f51 <f0+0x281>
    7ef8:	48 89 c2             	mov    %rax,%rdx
    7efb:	48 c1 ea 10          	shr    $0x10,%rdx
    7eff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f03:	48 8b 15 ce 8b 01 00 	mov    0x18bce(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    7f0a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f0e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7f12:	4d 85 ed             	test   %r13,%r13
    7f15:	74 3a                	je     7f51 <f0+0x281>
    7f17:	0f b6 0a             	movzbl (%rdx),%ecx
    7f1a:	80 f9 02             	cmp    $0x2,%cl
    7f1d:	0f 84 bd 26 00 00    	je     a5e0 <f0+0x2910>
    7f23:	80 f9 01             	cmp    $0x1,%cl
    7f26:	75 29                	jne    7f51 <f0+0x281>
    7f28:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f2b:	0f b7 c0             	movzwl %ax,%eax
    7f2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f31:	48 0f af c1          	imul   %rcx,%rax
    7f35:	48 c1 e8 20          	shr    $0x20,%rax
    7f39:	48 39 d0             	cmp    %rdx,%rax
    7f3c:	73 13                	jae    7f51 <f0+0x281>
    7f3e:	49 01 c5             	add    %rax,%r13
    7f41:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7f46:	0f 84 cc 28 00 00    	je     a818 <f0+0x2b48>
    7f4c:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    7f51:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    7f58:	33 f3 bf 
    7f5b:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    7f62:	00 
    7f63:	bf 01 00 00 00       	mov    $0x1,%edi
    7f68:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
    7f6f:	00 
    7f70:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    7f77:	00 
    7f78:	e8 f3 d2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    7f7d:	48 8b 15 34 8b 01 00 	mov    0x18b34(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    7f84:	49 89 c6             	mov    %rax,%r14
    7f87:	48 2b 05 02 8b 01 00 	sub    0x18b02(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    7f8e:	48 c1 e2 10          	shl    $0x10,%rdx
    7f92:	48 39 d0             	cmp    %rdx,%rax
    7f95:	73 59                	jae    7ff0 <f0+0x320>
    7f97:	48 89 c2             	mov    %rax,%rdx
    7f9a:	48 c1 ea 10          	shr    $0x10,%rdx
    7f9e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fa2:	48 8b 15 2f 8b 01 00 	mov    0x18b2f(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    7fa9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fad:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    7fb1:	4d 85 ed             	test   %r13,%r13
    7fb4:	74 3a                	je     7ff0 <f0+0x320>
    7fb6:	0f b6 0a             	movzbl (%rdx),%ecx
    7fb9:	80 f9 02             	cmp    $0x2,%cl
    7fbc:	0f 84 0e 26 00 00    	je     a5d0 <f0+0x2900>
    7fc2:	80 f9 01             	cmp    $0x1,%cl
    7fc5:	75 29                	jne    7ff0 <f0+0x320>
    7fc7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fca:	0f b7 c0             	movzwl %ax,%eax
    7fcd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fd0:	48 0f af c1          	imul   %rcx,%rax
    7fd4:	48 c1 e8 20          	shr    $0x20,%rax
    7fd8:	48 39 d0             	cmp    %rdx,%rax
    7fdb:	73 13                	jae    7ff0 <f0+0x320>
    7fdd:	49 01 c5             	add    %rax,%r13
    7fe0:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7fe5:	0f 84 3a 28 00 00    	je     a825 <f0+0x2b55>
    7feb:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    7ff0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    7ff7:	00 f0 3f 
    7ffa:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    8001:	00 
    8002:	bf 01 00 00 00       	mov    $0x1,%edi
    8007:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
    800e:	00 
    800f:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8016:	00 
    8017:	e8 54 d2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    801c:	48 8b 15 95 8a 01 00 	mov    0x18a95(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    8023:	49 89 c6             	mov    %rax,%r14
    8026:	48 2b 05 63 8a 01 00 	sub    0x18a63(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    802d:	48 c1 e2 10          	shl    $0x10,%rdx
    8031:	48 39 d0             	cmp    %rdx,%rax
    8034:	73 59                	jae    808f <f0+0x3bf>
    8036:	48 89 c2             	mov    %rax,%rdx
    8039:	48 c1 ea 10          	shr    $0x10,%rdx
    803d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8041:	48 8b 15 90 8a 01 00 	mov    0x18a90(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    8048:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    804c:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    8050:	4d 85 ed             	test   %r13,%r13
    8053:	74 3a                	je     808f <f0+0x3bf>
    8055:	0f b6 0a             	movzbl (%rdx),%ecx
    8058:	80 f9 02             	cmp    $0x2,%cl
    805b:	0f 84 2f 26 00 00    	je     a690 <f0+0x29c0>
    8061:	80 f9 01             	cmp    $0x1,%cl
    8064:	75 29                	jne    808f <f0+0x3bf>
    8066:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8069:	0f b7 c0             	movzwl %ax,%eax
    806c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    806f:	48 0f af c1          	imul   %rcx,%rax
    8073:	48 c1 e8 20          	shr    $0x20,%rax
    8077:	48 39 d0             	cmp    %rdx,%rax
    807a:	73 13                	jae    808f <f0+0x3bf>
    807c:	49 01 c5             	add    %rax,%r13
    807f:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    8084:	0f 84 a8 27 00 00    	je     a832 <f0+0x2b62>
    808a:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    808f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8096:	33 f3 bf 
    8099:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    80a0:	00 
    80a1:	bf 01 00 00 00       	mov    $0x1,%edi
    80a6:	4c 89 b4 24 a8 00 00 	mov    %r14,0xa8(%rsp)
    80ad:	00 
    80ae:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    80b5:	00 
    80b6:	e8 b5 d1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    80bb:	48 8b 15 f6 89 01 00 	mov    0x189f6(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    80c2:	49 89 c6             	mov    %rax,%r14
    80c5:	48 2b 05 c4 89 01 00 	sub    0x189c4(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    80cc:	48 c1 e2 10          	shl    $0x10,%rdx
    80d0:	48 39 d0             	cmp    %rdx,%rax
    80d3:	73 59                	jae    812e <f0+0x45e>
    80d5:	48 89 c2             	mov    %rax,%rdx
    80d8:	48 c1 ea 10          	shr    $0x10,%rdx
    80dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80e0:	48 8b 15 f1 89 01 00 	mov    0x189f1(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    80e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80eb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    80ef:	4d 85 ed             	test   %r13,%r13
    80f2:	74 3a                	je     812e <f0+0x45e>
    80f4:	0f b6 0a             	movzbl (%rdx),%ecx
    80f7:	80 f9 02             	cmp    $0x2,%cl
    80fa:	0f 84 80 25 00 00    	je     a680 <f0+0x29b0>
    8100:	80 f9 01             	cmp    $0x1,%cl
    8103:	75 29                	jne    812e <f0+0x45e>
    8105:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8108:	0f b7 c0             	movzwl %ax,%eax
    810b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    810e:	48 0f af c1          	imul   %rcx,%rax
    8112:	48 c1 e8 20          	shr    $0x20,%rax
    8116:	48 39 d0             	cmp    %rdx,%rax
    8119:	73 13                	jae    812e <f0+0x45e>
    811b:	49 01 c5             	add    %rax,%r13
    811e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    8123:	0f 84 16 27 00 00    	je     a83f <f0+0x2b6f>
    8129:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    812e:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    8135:	00 f0 3f 
    8138:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    813f:	00 
    8140:	bf 01 00 00 00       	mov    $0x1,%edi
    8145:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
    814c:	00 
    814d:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    8154:	00 
    8155:	49 be 33 33 33 33 33 	movabs $0xbff3333333333333,%r14
    815c:	33 f3 bf 
    815f:	e8 0c d1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8164:	48 89 c7             	mov    %rax,%rdi
    8167:	e8 14 c6 ff ff       	call   4780 <fwp_rc_fresh>
    816c:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    8173:	00 
    8174:	bf 01 00 00 00       	mov    $0x1,%edi
    8179:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    8180:	00 
    8181:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    8188:	00 
    8189:	e8 e2 d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    818e:	48 89 c7             	mov    %rax,%rdi
    8191:	e8 ea c5 ff ff       	call   4780 <fwp_rc_fresh>
    8196:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    819d:	00 
    819e:	bf 01 00 00 00       	mov    $0x1,%edi
    81a3:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    81aa:	00 
    81ab:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    81b2:	00 
    81b3:	e8 b8 d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    81b8:	48 89 c7             	mov    %rax,%rdi
    81bb:	e8 c0 c5 ff ff       	call   4780 <fwp_rc_fresh>
    81c0:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    81c7:	00 
    81c8:	bf 01 00 00 00       	mov    $0x1,%edi
    81cd:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    81d4:	00 
    81d5:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    81dc:	00 
    81dd:	e8 8e d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    81e2:	48 89 c7             	mov    %rax,%rdi
    81e5:	e8 96 c5 ff ff       	call   4780 <fwp_rc_fresh>
    81ea:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    81f1:	00 
    81f2:	bf 01 00 00 00       	mov    $0x1,%edi
    81f7:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    81fe:	00 
    81ff:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    8206:	00 
    8207:	e8 64 d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    820c:	48 89 c7             	mov    %rax,%rdi
    820f:	e8 6c c5 ff ff       	call   4780 <fwp_rc_fresh>
    8214:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    821b:	00 
    821c:	bf 01 00 00 00       	mov    $0x1,%edi
    8221:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
    8228:	00 
    8229:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    8230:	00 
    8231:	e8 3a d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8236:	48 89 c7             	mov    %rax,%rdi
    8239:	e8 42 c5 ff ff       	call   4780 <fwp_rc_fresh>
    823e:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    8245:	00 
    8246:	bf 01 00 00 00       	mov    $0x1,%edi
    824b:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    8252:	00 
    8253:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    825a:	00 
    825b:	e8 10 d0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8260:	48 89 c7             	mov    %rax,%rdi
    8263:	e8 18 c5 ff ff       	call   4780 <fwp_rc_fresh>
    8268:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    826f:	00 
    8270:	bf 01 00 00 00       	mov    $0x1,%edi
    8275:	4c 89 b4 24 20 01 00 	mov    %r14,0x120(%rsp)
    827c:	00 
    827d:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    8284:	00 
    8285:	e8 e6 cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    828a:	48 89 c7             	mov    %rax,%rdi
    828d:	e8 ee c4 ff ff       	call   4780 <fwp_rc_fresh>
    8292:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    8299:	00 
    829a:	bf 01 00 00 00       	mov    $0x1,%edi
    829f:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    82a6:	00 
    82a7:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    82ae:	00 
    82af:	e8 bc cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    82b4:	48 89 c7             	mov    %rax,%rdi
    82b7:	e8 c4 c4 ff ff       	call   4780 <fwp_rc_fresh>
    82bc:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    82c3:	00 
    82c4:	bf 01 00 00 00       	mov    $0x1,%edi
    82c9:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
    82d0:	00 
    82d1:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    82d8:	00 
    82d9:	e8 92 cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    82de:	48 89 c7             	mov    %rax,%rdi
    82e1:	e8 9a c4 ff ff       	call   4780 <fwp_rc_fresh>
    82e6:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    82ed:	00 
    82ee:	bf 01 00 00 00       	mov    $0x1,%edi
    82f3:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    82fa:	00 
    82fb:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    8302:	00 
    8303:	e8 68 cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8308:	48 89 c7             	mov    %rax,%rdi
    830b:	e8 70 c4 ff ff       	call   4780 <fwp_rc_fresh>
    8310:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    8317:	00 
    8318:	bf 01 00 00 00       	mov    $0x1,%edi
    831d:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
    8324:	00 
    8325:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    832c:	00 
    832d:	e8 3e cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8332:	48 89 c7             	mov    %rax,%rdi
    8335:	e8 46 c4 ff ff       	call   4780 <fwp_rc_fresh>
    833a:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    8341:	00 
    8342:	bf 01 00 00 00       	mov    $0x1,%edi
    8347:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    834e:	00 
    834f:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    8356:	00 
    8357:	e8 14 cf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    835c:	48 89 c7             	mov    %rax,%rdi
    835f:	e8 1c c4 ff ff       	call   4780 <fwp_rc_fresh>
    8364:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    836b:	00 
    836c:	bf 01 00 00 00       	mov    $0x1,%edi
    8371:	4c 89 b4 24 80 01 00 	mov    %r14,0x180(%rsp)
    8378:	00 
    8379:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    8380:	00 
    8381:	e8 ea ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8386:	48 89 c7             	mov    %rax,%rdi
    8389:	e8 f2 c3 ff ff       	call   4780 <fwp_rc_fresh>
    838e:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    8395:	00 
    8396:	bf 01 00 00 00       	mov    $0x1,%edi
    839b:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    83a2:	00 
    83a3:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    83aa:	00 
    83ab:	e8 c0 ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    83b0:	48 89 c7             	mov    %rax,%rdi
    83b3:	e8 c8 c3 ff ff       	call   4780 <fwp_rc_fresh>
    83b8:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    83bf:	00 
    83c0:	bf 01 00 00 00       	mov    $0x1,%edi
    83c5:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
    83cc:	00 
    83cd:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    83d4:	00 
    83d5:	e8 96 ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    83da:	48 89 c7             	mov    %rax,%rdi
    83dd:	e8 9e c3 ff ff       	call   4780 <fwp_rc_fresh>
    83e2:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    83e9:	00 
    83ea:	bf 01 00 00 00       	mov    $0x1,%edi
    83ef:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    83f6:	00 
    83f7:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    83fe:	00 
    83ff:	e8 6c ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8404:	48 89 c7             	mov    %rax,%rdi
    8407:	e8 74 c3 ff ff       	call   4780 <fwp_rc_fresh>
    840c:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    8413:	00 
    8414:	bf 01 00 00 00       	mov    $0x1,%edi
    8419:	4c 89 b4 24 c0 01 00 	mov    %r14,0x1c0(%rsp)
    8420:	00 
    8421:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    8428:	00 
    8429:	e8 42 ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    842e:	48 89 c7             	mov    %rax,%rdi
    8431:	e8 4a c3 ff ff       	call   4780 <fwp_rc_fresh>
    8436:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    843d:	00 
    843e:	bf 01 00 00 00       	mov    $0x1,%edi
    8443:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    844a:	00 
    844b:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    8452:	00 
    8453:	e8 18 ce ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8458:	48 89 c7             	mov    %rax,%rdi
    845b:	e8 20 c3 ff ff       	call   4780 <fwp_rc_fresh>
    8460:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    8467:	00 
    8468:	bf 01 00 00 00       	mov    $0x1,%edi
    846d:	4c 89 b4 24 e0 01 00 	mov    %r14,0x1e0(%rsp)
    8474:	00 
    8475:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    847c:	00 
    847d:	e8 ee cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8482:	48 89 c7             	mov    %rax,%rdi
    8485:	e8 f6 c2 ff ff       	call   4780 <fwp_rc_fresh>
    848a:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    8491:	00 
    8492:	bf 01 00 00 00       	mov    $0x1,%edi
    8497:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    849e:	00 
    849f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    84a6:	00 
    84a7:	e8 c4 cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    84ac:	48 89 c7             	mov    %rax,%rdi
    84af:	e8 cc c2 ff ff       	call   4780 <fwp_rc_fresh>
    84b4:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    84bb:	00 
    84bc:	bf 01 00 00 00       	mov    $0x1,%edi
    84c1:	4c 89 b4 24 00 02 00 	mov    %r14,0x200(%rsp)
    84c8:	00 
    84c9:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    84d0:	00 
    84d1:	e8 9a cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    84d6:	48 89 c7             	mov    %rax,%rdi
    84d9:	e8 a2 c2 ff ff       	call   4780 <fwp_rc_fresh>
    84de:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    84e5:	00 
    84e6:	bf 01 00 00 00       	mov    $0x1,%edi
    84eb:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    84f2:	00 
    84f3:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    84fa:	00 
    84fb:	e8 70 cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8500:	48 89 c7             	mov    %rax,%rdi
    8503:	e8 78 c2 ff ff       	call   4780 <fwp_rc_fresh>
    8508:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    850f:	00 
    8510:	bf 01 00 00 00       	mov    $0x1,%edi
    8515:	4c 89 b4 24 20 02 00 	mov    %r14,0x220(%rsp)
    851c:	00 
    851d:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    8524:	00 
    8525:	e8 46 cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    852a:	48 89 c7             	mov    %rax,%rdi
    852d:	e8 4e c2 ff ff       	call   4780 <fwp_rc_fresh>
    8532:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    8539:	00 
    853a:	bf 01 00 00 00       	mov    $0x1,%edi
    853f:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    8546:	00 
    8547:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    854e:	00 
    854f:	e8 1c cd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8554:	48 89 c7             	mov    %rax,%rdi
    8557:	e8 24 c2 ff ff       	call   4780 <fwp_rc_fresh>
    855c:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    8563:	00 
    8564:	bf 01 00 00 00       	mov    $0x1,%edi
    8569:	4c 89 b4 24 40 02 00 	mov    %r14,0x240(%rsp)
    8570:	00 
    8571:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    8578:	00 
    8579:	e8 f2 cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    857e:	48 89 c7             	mov    %rax,%rdi
    8581:	e8 fa c1 ff ff       	call   4780 <fwp_rc_fresh>
    8586:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    858d:	00 
    858e:	bf 01 00 00 00       	mov    $0x1,%edi
    8593:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    859a:	00 
    859b:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    85a2:	00 
    85a3:	e8 c8 cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    85a8:	48 89 c7             	mov    %rax,%rdi
    85ab:	e8 d0 c1 ff ff       	call   4780 <fwp_rc_fresh>
    85b0:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    85b7:	00 
    85b8:	bf 01 00 00 00       	mov    $0x1,%edi
    85bd:	4c 89 b4 24 60 02 00 	mov    %r14,0x260(%rsp)
    85c4:	00 
    85c5:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    85cc:	00 
    85cd:	e8 9e cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    85d2:	48 89 c7             	mov    %rax,%rdi
    85d5:	e8 a6 c1 ff ff       	call   4780 <fwp_rc_fresh>
    85da:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    85e1:	00 
    85e2:	bf 01 00 00 00       	mov    $0x1,%edi
    85e7:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    85ee:	00 
    85ef:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    85f6:	00 
    85f7:	e8 74 cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    85fc:	48 89 c7             	mov    %rax,%rdi
    85ff:	e8 7c c1 ff ff       	call   4780 <fwp_rc_fresh>
    8604:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    860b:	00 
    860c:	bf 01 00 00 00       	mov    $0x1,%edi
    8611:	4c 89 b4 24 80 02 00 	mov    %r14,0x280(%rsp)
    8618:	00 
    8619:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    8620:	00 
    8621:	e8 4a cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8626:	48 89 c7             	mov    %rax,%rdi
    8629:	e8 52 c1 ff ff       	call   4780 <fwp_rc_fresh>
    862e:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    8635:	00 
    8636:	bf 01 00 00 00       	mov    $0x1,%edi
    863b:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    8642:	00 
    8643:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    864a:	00 
    864b:	e8 20 cc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8650:	48 89 c7             	mov    %rax,%rdi
    8653:	e8 28 c1 ff ff       	call   4780 <fwp_rc_fresh>
    8658:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    865f:	00 
    8660:	bf 01 00 00 00       	mov    $0x1,%edi
    8665:	4c 89 b4 24 a0 02 00 	mov    %r14,0x2a0(%rsp)
    866c:	00 
    866d:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    8674:	00 
    8675:	e8 f6 cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    867a:	48 89 c7             	mov    %rax,%rdi
    867d:	e8 fe c0 ff ff       	call   4780 <fwp_rc_fresh>
    8682:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    8689:	00 
    868a:	bf 01 00 00 00       	mov    $0x1,%edi
    868f:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    8696:	00 
    8697:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    869e:	00 
    869f:	e8 cc cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    86a4:	48 89 c7             	mov    %rax,%rdi
    86a7:	e8 d4 c0 ff ff       	call   4780 <fwp_rc_fresh>
    86ac:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    86b3:	00 
    86b4:	bf 01 00 00 00       	mov    $0x1,%edi
    86b9:	4c 89 b4 24 c0 02 00 	mov    %r14,0x2c0(%rsp)
    86c0:	00 
    86c1:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    86c8:	00 
    86c9:	e8 a2 cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    86ce:	48 89 c7             	mov    %rax,%rdi
    86d1:	e8 aa c0 ff ff       	call   4780 <fwp_rc_fresh>
    86d6:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    86dd:	00 
    86de:	bf 01 00 00 00       	mov    $0x1,%edi
    86e3:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    86ea:	00 
    86eb:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    86f2:	00 
    86f3:	e8 78 cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    86f8:	48 89 c7             	mov    %rax,%rdi
    86fb:	e8 80 c0 ff ff       	call   4780 <fwp_rc_fresh>
    8700:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    8707:	00 
    8708:	bf 01 00 00 00       	mov    $0x1,%edi
    870d:	4c 89 b4 24 e0 02 00 	mov    %r14,0x2e0(%rsp)
    8714:	00 
    8715:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    871c:	00 
    871d:	e8 4e cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8722:	48 89 c7             	mov    %rax,%rdi
    8725:	e8 56 c0 ff ff       	call   4780 <fwp_rc_fresh>
    872a:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    8731:	00 
    8732:	bf 01 00 00 00       	mov    $0x1,%edi
    8737:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    873e:	00 
    873f:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    8746:	00 
    8747:	e8 24 cb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    874c:	48 89 c7             	mov    %rax,%rdi
    874f:	e8 2c c0 ff ff       	call   4780 <fwp_rc_fresh>
    8754:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    875b:	00 
    875c:	bf 01 00 00 00       	mov    $0x1,%edi
    8761:	4c 89 b4 24 00 03 00 	mov    %r14,0x300(%rsp)
    8768:	00 
    8769:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    8770:	00 
    8771:	e8 fa ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8776:	48 89 c7             	mov    %rax,%rdi
    8779:	e8 02 c0 ff ff       	call   4780 <fwp_rc_fresh>
    877e:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    8785:	00 
    8786:	bf 01 00 00 00       	mov    $0x1,%edi
    878b:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    8792:	00 
    8793:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    879a:	00 
    879b:	e8 d0 ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    87a0:	48 89 c7             	mov    %rax,%rdi
    87a3:	e8 d8 bf ff ff       	call   4780 <fwp_rc_fresh>
    87a8:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    87af:	00 
    87b0:	bf 01 00 00 00       	mov    $0x1,%edi
    87b5:	4c 89 b4 24 20 03 00 	mov    %r14,0x320(%rsp)
    87bc:	00 
    87bd:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    87c4:	00 
    87c5:	e8 a6 ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    87ca:	48 89 c7             	mov    %rax,%rdi
    87cd:	e8 ae bf ff ff       	call   4780 <fwp_rc_fresh>
    87d2:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    87d9:	00 
    87da:	bf 01 00 00 00       	mov    $0x1,%edi
    87df:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    87e6:	00 
    87e7:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    87ee:	00 
    87ef:	e8 7c ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    87f4:	48 89 c7             	mov    %rax,%rdi
    87f7:	e8 84 bf ff ff       	call   4780 <fwp_rc_fresh>
    87fc:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    8803:	00 
    8804:	bf 01 00 00 00       	mov    $0x1,%edi
    8809:	4c 89 b4 24 40 03 00 	mov    %r14,0x340(%rsp)
    8810:	00 
    8811:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    8818:	00 
    8819:	e8 52 ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    881e:	48 89 c7             	mov    %rax,%rdi
    8821:	e8 5a bf ff ff       	call   4780 <fwp_rc_fresh>
    8826:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    882d:	00 
    882e:	bf 01 00 00 00       	mov    $0x1,%edi
    8833:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    883a:	00 
    883b:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    8842:	00 
    8843:	e8 28 ca ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8848:	48 89 c7             	mov    %rax,%rdi
    884b:	e8 30 bf ff ff       	call   4780 <fwp_rc_fresh>
    8850:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    8857:	00 
    8858:	bf 01 00 00 00       	mov    $0x1,%edi
    885d:	4c 89 b4 24 60 03 00 	mov    %r14,0x360(%rsp)
    8864:	00 
    8865:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    886c:	00 
    886d:	e8 fe c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8872:	48 89 c7             	mov    %rax,%rdi
    8875:	e8 06 bf ff ff       	call   4780 <fwp_rc_fresh>
    887a:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    8881:	00 
    8882:	bf 01 00 00 00       	mov    $0x1,%edi
    8887:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    888e:	00 
    888f:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    8896:	00 
    8897:	e8 d4 c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    889c:	48 89 c7             	mov    %rax,%rdi
    889f:	e8 dc be ff ff       	call   4780 <fwp_rc_fresh>
    88a4:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    88ab:	00 
    88ac:	bf 01 00 00 00       	mov    $0x1,%edi
    88b1:	4c 89 b4 24 80 03 00 	mov    %r14,0x380(%rsp)
    88b8:	00 
    88b9:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    88c0:	00 
    88c1:	e8 aa c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    88c6:	48 89 c7             	mov    %rax,%rdi
    88c9:	e8 b2 be ff ff       	call   4780 <fwp_rc_fresh>
    88ce:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    88d5:	00 
    88d6:	bf 01 00 00 00       	mov    $0x1,%edi
    88db:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    88e2:	00 
    88e3:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    88ea:	00 
    88eb:	e8 80 c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    88f0:	48 89 c7             	mov    %rax,%rdi
    88f3:	e8 88 be ff ff       	call   4780 <fwp_rc_fresh>
    88f8:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    88ff:	00 
    8900:	bf 01 00 00 00       	mov    $0x1,%edi
    8905:	4c 89 b4 24 a0 03 00 	mov    %r14,0x3a0(%rsp)
    890c:	00 
    890d:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    8914:	00 
    8915:	e8 56 c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    891a:	48 89 c7             	mov    %rax,%rdi
    891d:	e8 5e be ff ff       	call   4780 <fwp_rc_fresh>
    8922:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    8929:	00 
    892a:	bf 01 00 00 00       	mov    $0x1,%edi
    892f:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    8936:	00 
    8937:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    893e:	00 
    893f:	e8 2c c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8944:	48 89 c7             	mov    %rax,%rdi
    8947:	e8 34 be ff ff       	call   4780 <fwp_rc_fresh>
    894c:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    8953:	00 
    8954:	bf 01 00 00 00       	mov    $0x1,%edi
    8959:	4c 89 b4 24 c0 03 00 	mov    %r14,0x3c0(%rsp)
    8960:	00 
    8961:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    8968:	00 
    8969:	e8 02 c9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    896e:	48 89 c7             	mov    %rax,%rdi
    8971:	e8 0a be ff ff       	call   4780 <fwp_rc_fresh>
    8976:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    897d:	00 
    897e:	bf 01 00 00 00       	mov    $0x1,%edi
    8983:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    898a:	00 
    898b:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    8992:	00 
    8993:	e8 d8 c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8998:	48 89 c7             	mov    %rax,%rdi
    899b:	e8 e0 bd ff ff       	call   4780 <fwp_rc_fresh>
    89a0:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    89a7:	00 
    89a8:	bf 01 00 00 00       	mov    $0x1,%edi
    89ad:	4c 89 b4 24 e0 03 00 	mov    %r14,0x3e0(%rsp)
    89b4:	00 
    89b5:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    89bc:	00 
    89bd:	e8 ae c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    89c2:	48 89 c7             	mov    %rax,%rdi
    89c5:	e8 b6 bd ff ff       	call   4780 <fwp_rc_fresh>
    89ca:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    89d1:	00 
    89d2:	bf 01 00 00 00       	mov    $0x1,%edi
    89d7:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    89de:	00 
    89df:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    89e6:	00 
    89e7:	e8 84 c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    89ec:	48 89 c7             	mov    %rax,%rdi
    89ef:	e8 8c bd ff ff       	call   4780 <fwp_rc_fresh>
    89f4:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    89fb:	00 
    89fc:	bf 01 00 00 00       	mov    $0x1,%edi
    8a01:	4c 89 b4 24 00 04 00 	mov    %r14,0x400(%rsp)
    8a08:	00 
    8a09:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    8a10:	00 
    8a11:	e8 5a c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8a16:	48 89 c7             	mov    %rax,%rdi
    8a19:	e8 62 bd ff ff       	call   4780 <fwp_rc_fresh>
    8a1e:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    8a25:	00 
    8a26:	bf 01 00 00 00       	mov    $0x1,%edi
    8a2b:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    8a32:	00 
    8a33:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    8a3a:	00 
    8a3b:	e8 30 c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8a40:	48 89 c7             	mov    %rax,%rdi
    8a43:	e8 38 bd ff ff       	call   4780 <fwp_rc_fresh>
    8a48:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    8a4f:	00 
    8a50:	bf 01 00 00 00       	mov    $0x1,%edi
    8a55:	4c 89 b4 24 20 04 00 	mov    %r14,0x420(%rsp)
    8a5c:	00 
    8a5d:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    8a64:	00 
    8a65:	e8 06 c8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8a6a:	48 89 c7             	mov    %rax,%rdi
    8a6d:	e8 0e bd ff ff       	call   4780 <fwp_rc_fresh>
    8a72:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    8a79:	00 
    8a7a:	bf 01 00 00 00       	mov    $0x1,%edi
    8a7f:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    8a86:	00 
    8a87:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    8a8e:	00 
    8a8f:	e8 dc c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8a94:	48 89 c7             	mov    %rax,%rdi
    8a97:	e8 e4 bc ff ff       	call   4780 <fwp_rc_fresh>
    8a9c:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    8aa3:	00 
    8aa4:	bf 01 00 00 00       	mov    $0x1,%edi
    8aa9:	4c 89 b4 24 40 04 00 	mov    %r14,0x440(%rsp)
    8ab0:	00 
    8ab1:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    8ab8:	00 
    8ab9:	e8 b2 c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8abe:	48 89 c7             	mov    %rax,%rdi
    8ac1:	e8 ba bc ff ff       	call   4780 <fwp_rc_fresh>
    8ac6:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    8acd:	00 
    8ace:	bf 01 00 00 00       	mov    $0x1,%edi
    8ad3:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    8ada:	00 
    8adb:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    8ae2:	00 
    8ae3:	e8 88 c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8ae8:	48 89 c7             	mov    %rax,%rdi
    8aeb:	e8 90 bc ff ff       	call   4780 <fwp_rc_fresh>
    8af0:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    8af7:	00 
    8af8:	bf 01 00 00 00       	mov    $0x1,%edi
    8afd:	4c 89 b4 24 60 04 00 	mov    %r14,0x460(%rsp)
    8b04:	00 
    8b05:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    8b0c:	00 
    8b0d:	e8 5e c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8b12:	48 89 c7             	mov    %rax,%rdi
    8b15:	e8 66 bc ff ff       	call   4780 <fwp_rc_fresh>
    8b1a:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    8b21:	00 
    8b22:	bf 01 00 00 00       	mov    $0x1,%edi
    8b27:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    8b2e:	00 
    8b2f:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    8b36:	00 
    8b37:	e8 34 c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8b3c:	48 89 c7             	mov    %rax,%rdi
    8b3f:	e8 3c bc ff ff       	call   4780 <fwp_rc_fresh>
    8b44:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    8b4b:	00 
    8b4c:	bf 01 00 00 00       	mov    $0x1,%edi
    8b51:	4c 89 b4 24 80 04 00 	mov    %r14,0x480(%rsp)
    8b58:	00 
    8b59:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    8b60:	00 
    8b61:	e8 0a c7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8b66:	48 89 c7             	mov    %rax,%rdi
    8b69:	e8 12 bc ff ff       	call   4780 <fwp_rc_fresh>
    8b6e:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    8b75:	00 
    8b76:	bf 01 00 00 00       	mov    $0x1,%edi
    8b7b:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    8b82:	00 
    8b83:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    8b8a:	00 
    8b8b:	e8 e0 c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8b90:	48 89 c7             	mov    %rax,%rdi
    8b93:	e8 e8 bb ff ff       	call   4780 <fwp_rc_fresh>
    8b98:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    8b9f:	00 
    8ba0:	bf 01 00 00 00       	mov    $0x1,%edi
    8ba5:	4c 89 b4 24 a0 04 00 	mov    %r14,0x4a0(%rsp)
    8bac:	00 
    8bad:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    8bb4:	00 
    8bb5:	e8 b6 c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8bba:	48 89 c7             	mov    %rax,%rdi
    8bbd:	e8 be bb ff ff       	call   4780 <fwp_rc_fresh>
    8bc2:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    8bc9:	00 
    8bca:	bf 01 00 00 00       	mov    $0x1,%edi
    8bcf:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    8bd6:	00 
    8bd7:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    8bde:	00 
    8bdf:	e8 8c c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8be4:	48 89 c7             	mov    %rax,%rdi
    8be7:	e8 94 bb ff ff       	call   4780 <fwp_rc_fresh>
    8bec:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    8bf3:	00 
    8bf4:	bf 01 00 00 00       	mov    $0x1,%edi
    8bf9:	4c 89 b4 24 c0 04 00 	mov    %r14,0x4c0(%rsp)
    8c00:	00 
    8c01:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    8c08:	00 
    8c09:	e8 62 c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8c0e:	48 89 c7             	mov    %rax,%rdi
    8c11:	e8 6a bb ff ff       	call   4780 <fwp_rc_fresh>
    8c16:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    8c1d:	00 
    8c1e:	bf 01 00 00 00       	mov    $0x1,%edi
    8c23:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    8c2a:	00 
    8c2b:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    8c32:	00 
    8c33:	e8 38 c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8c38:	48 89 c7             	mov    %rax,%rdi
    8c3b:	e8 40 bb ff ff       	call   4780 <fwp_rc_fresh>
    8c40:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    8c47:	00 
    8c48:	bf 01 00 00 00       	mov    $0x1,%edi
    8c4d:	4c 89 b4 24 e0 04 00 	mov    %r14,0x4e0(%rsp)
    8c54:	00 
    8c55:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    8c5c:	00 
    8c5d:	e8 0e c6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8c62:	48 89 c7             	mov    %rax,%rdi
    8c65:	e8 16 bb ff ff       	call   4780 <fwp_rc_fresh>
    8c6a:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    8c71:	00 
    8c72:	bf 01 00 00 00       	mov    $0x1,%edi
    8c77:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    8c7e:	00 
    8c7f:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    8c86:	00 
    8c87:	e8 e4 c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8c8c:	48 89 c7             	mov    %rax,%rdi
    8c8f:	e8 ec ba ff ff       	call   4780 <fwp_rc_fresh>
    8c94:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    8c9b:	00 
    8c9c:	bf 01 00 00 00       	mov    $0x1,%edi
    8ca1:	4c 89 b4 24 00 05 00 	mov    %r14,0x500(%rsp)
    8ca8:	00 
    8ca9:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    8cb0:	00 
    8cb1:	e8 ba c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8cb6:	48 89 c7             	mov    %rax,%rdi
    8cb9:	e8 c2 ba ff ff       	call   4780 <fwp_rc_fresh>
    8cbe:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    8cc5:	00 
    8cc6:	bf 01 00 00 00       	mov    $0x1,%edi
    8ccb:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    8cd2:	00 
    8cd3:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    8cda:	00 
    8cdb:	e8 90 c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8ce0:	48 89 c7             	mov    %rax,%rdi
    8ce3:	e8 98 ba ff ff       	call   4780 <fwp_rc_fresh>
    8ce8:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    8cef:	00 
    8cf0:	bf 01 00 00 00       	mov    $0x1,%edi
    8cf5:	4c 89 b4 24 20 05 00 	mov    %r14,0x520(%rsp)
    8cfc:	00 
    8cfd:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    8d04:	00 
    8d05:	e8 66 c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8d0a:	48 89 c7             	mov    %rax,%rdi
    8d0d:	e8 6e ba ff ff       	call   4780 <fwp_rc_fresh>
    8d12:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    8d19:	00 
    8d1a:	bf 01 00 00 00       	mov    $0x1,%edi
    8d1f:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    8d26:	00 
    8d27:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    8d2e:	00 
    8d2f:	e8 3c c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8d34:	48 89 c7             	mov    %rax,%rdi
    8d37:	e8 44 ba ff ff       	call   4780 <fwp_rc_fresh>
    8d3c:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    8d43:	00 
    8d44:	bf 01 00 00 00       	mov    $0x1,%edi
    8d49:	4c 89 b4 24 40 05 00 	mov    %r14,0x540(%rsp)
    8d50:	00 
    8d51:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    8d58:	00 
    8d59:	e8 12 c5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8d5e:	48 89 c7             	mov    %rax,%rdi
    8d61:	e8 1a ba ff ff       	call   4780 <fwp_rc_fresh>
    8d66:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    8d6d:	00 
    8d6e:	bf 01 00 00 00       	mov    $0x1,%edi
    8d73:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    8d7a:	00 
    8d7b:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    8d82:	00 
    8d83:	e8 e8 c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8d88:	48 89 c7             	mov    %rax,%rdi
    8d8b:	e8 f0 b9 ff ff       	call   4780 <fwp_rc_fresh>
    8d90:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    8d97:	00 
    8d98:	bf 01 00 00 00       	mov    $0x1,%edi
    8d9d:	4c 89 b4 24 60 05 00 	mov    %r14,0x560(%rsp)
    8da4:	00 
    8da5:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    8dac:	00 
    8dad:	e8 be c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8db2:	48 89 c7             	mov    %rax,%rdi
    8db5:	e8 c6 b9 ff ff       	call   4780 <fwp_rc_fresh>
    8dba:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    8dc1:	00 
    8dc2:	bf 01 00 00 00       	mov    $0x1,%edi
    8dc7:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    8dce:	00 
    8dcf:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    8dd6:	00 
    8dd7:	e8 94 c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8ddc:	48 89 c7             	mov    %rax,%rdi
    8ddf:	e8 9c b9 ff ff       	call   4780 <fwp_rc_fresh>
    8de4:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    8deb:	00 
    8dec:	bf 01 00 00 00       	mov    $0x1,%edi
    8df1:	4c 89 b4 24 80 05 00 	mov    %r14,0x580(%rsp)
    8df8:	00 
    8df9:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    8e00:	00 
    8e01:	e8 6a c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8e06:	48 89 c7             	mov    %rax,%rdi
    8e09:	e8 72 b9 ff ff       	call   4780 <fwp_rc_fresh>
    8e0e:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    8e15:	00 
    8e16:	bf 01 00 00 00       	mov    $0x1,%edi
    8e1b:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    8e22:	00 
    8e23:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    8e2a:	00 
    8e2b:	e8 40 c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8e30:	48 89 c7             	mov    %rax,%rdi
    8e33:	e8 48 b9 ff ff       	call   4780 <fwp_rc_fresh>
    8e38:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    8e3f:	00 
    8e40:	bf 01 00 00 00       	mov    $0x1,%edi
    8e45:	4c 89 b4 24 a0 05 00 	mov    %r14,0x5a0(%rsp)
    8e4c:	00 
    8e4d:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    8e54:	00 
    8e55:	e8 16 c4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8e5a:	48 89 c7             	mov    %rax,%rdi
    8e5d:	e8 1e b9 ff ff       	call   4780 <fwp_rc_fresh>
    8e62:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    8e69:	00 
    8e6a:	bf 01 00 00 00       	mov    $0x1,%edi
    8e6f:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    8e76:	00 
    8e77:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    8e7e:	00 
    8e7f:	e8 ec c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8e84:	48 89 c7             	mov    %rax,%rdi
    8e87:	e8 f4 b8 ff ff       	call   4780 <fwp_rc_fresh>
    8e8c:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    8e93:	00 
    8e94:	bf 01 00 00 00       	mov    $0x1,%edi
    8e99:	4c 89 b4 24 c0 05 00 	mov    %r14,0x5c0(%rsp)
    8ea0:	00 
    8ea1:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    8ea8:	00 
    8ea9:	e8 c2 c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8eae:	48 89 c7             	mov    %rax,%rdi
    8eb1:	e8 ca b8 ff ff       	call   4780 <fwp_rc_fresh>
    8eb6:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    8ebd:	00 
    8ebe:	bf 01 00 00 00       	mov    $0x1,%edi
    8ec3:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    8eca:	00 
    8ecb:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    8ed2:	00 
    8ed3:	e8 98 c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8ed8:	48 89 c7             	mov    %rax,%rdi
    8edb:	e8 a0 b8 ff ff       	call   4780 <fwp_rc_fresh>
    8ee0:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    8ee7:	00 
    8ee8:	bf 01 00 00 00       	mov    $0x1,%edi
    8eed:	4c 89 b4 24 e0 05 00 	mov    %r14,0x5e0(%rsp)
    8ef4:	00 
    8ef5:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    8efc:	00 
    8efd:	e8 6e c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8f02:	48 89 c7             	mov    %rax,%rdi
    8f05:	e8 76 b8 ff ff       	call   4780 <fwp_rc_fresh>
    8f0a:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    8f11:	00 
    8f12:	bf 01 00 00 00       	mov    $0x1,%edi
    8f17:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    8f1e:	00 
    8f1f:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    8f26:	00 
    8f27:	e8 44 c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8f2c:	48 89 c7             	mov    %rax,%rdi
    8f2f:	e8 4c b8 ff ff       	call   4780 <fwp_rc_fresh>
    8f34:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    8f3b:	00 
    8f3c:	bf 01 00 00 00       	mov    $0x1,%edi
    8f41:	4c 89 b4 24 00 06 00 	mov    %r14,0x600(%rsp)
    8f48:	00 
    8f49:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    8f50:	00 
    8f51:	e8 1a c3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8f56:	48 89 c7             	mov    %rax,%rdi
    8f59:	e8 22 b8 ff ff       	call   4780 <fwp_rc_fresh>
    8f5e:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    8f65:	00 
    8f66:	bf 01 00 00 00       	mov    $0x1,%edi
    8f6b:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    8f72:	00 
    8f73:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    8f7a:	00 
    8f7b:	e8 f0 c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8f80:	48 89 c7             	mov    %rax,%rdi
    8f83:	e8 f8 b7 ff ff       	call   4780 <fwp_rc_fresh>
    8f88:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    8f8f:	00 
    8f90:	bf 01 00 00 00       	mov    $0x1,%edi
    8f95:	4c 89 b4 24 20 06 00 	mov    %r14,0x620(%rsp)
    8f9c:	00 
    8f9d:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    8fa4:	00 
    8fa5:	e8 c6 c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8faa:	48 89 c7             	mov    %rax,%rdi
    8fad:	e8 ce b7 ff ff       	call   4780 <fwp_rc_fresh>
    8fb2:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    8fb9:	00 
    8fba:	bf 01 00 00 00       	mov    $0x1,%edi
    8fbf:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    8fc6:	00 
    8fc7:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    8fce:	00 
    8fcf:	e8 9c c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8fd4:	48 89 c7             	mov    %rax,%rdi
    8fd7:	e8 a4 b7 ff ff       	call   4780 <fwp_rc_fresh>
    8fdc:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    8fe3:	00 
    8fe4:	bf 01 00 00 00       	mov    $0x1,%edi
    8fe9:	4c 89 b4 24 40 06 00 	mov    %r14,0x640(%rsp)
    8ff0:	00 
    8ff1:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    8ff8:	00 
    8ff9:	e8 72 c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    8ffe:	48 89 c7             	mov    %rax,%rdi
    9001:	e8 7a b7 ff ff       	call   4780 <fwp_rc_fresh>
    9006:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    900d:	00 
    900e:	bf 01 00 00 00       	mov    $0x1,%edi
    9013:	4c 89 ac 24 50 06 00 	mov    %r13,0x650(%rsp)
    901a:	00 
    901b:	48 89 84 24 58 06 00 	mov    %rax,0x658(%rsp)
    9022:	00 
    9023:	e8 48 c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9028:	48 89 c7             	mov    %rax,%rdi
    902b:	e8 50 b7 ff ff       	call   4780 <fwp_rc_fresh>
    9030:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    9037:	00 
    9038:	bf 01 00 00 00       	mov    $0x1,%edi
    903d:	4c 89 b4 24 60 06 00 	mov    %r14,0x660(%rsp)
    9044:	00 
    9045:	48 89 84 24 68 06 00 	mov    %rax,0x668(%rsp)
    904c:	00 
    904d:	e8 1e c2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9052:	48 89 c7             	mov    %rax,%rdi
    9055:	e8 26 b7 ff ff       	call   4780 <fwp_rc_fresh>
    905a:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    9061:	00 
    9062:	bf 01 00 00 00       	mov    $0x1,%edi
    9067:	4c 89 ac 24 70 06 00 	mov    %r13,0x670(%rsp)
    906e:	00 
    906f:	48 89 84 24 78 06 00 	mov    %rax,0x678(%rsp)
    9076:	00 
    9077:	e8 f4 c1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    907c:	48 89 c7             	mov    %rax,%rdi
    907f:	e8 fc b6 ff ff       	call   4780 <fwp_rc_fresh>
    9084:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    908b:	00 
    908c:	bf 01 00 00 00       	mov    $0x1,%edi
    9091:	4c 89 b4 24 80 06 00 	mov    %r14,0x680(%rsp)
    9098:	00 
    9099:	48 89 84 24 88 06 00 	mov    %rax,0x688(%rsp)
    90a0:	00 
    90a1:	e8 ca c1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    90a6:	48 89 c7             	mov    %rax,%rdi
    90a9:	e8 d2 b6 ff ff       	call   4780 <fwp_rc_fresh>
    90ae:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    90b5:	00 
    90b6:	bf 01 00 00 00       	mov    $0x1,%edi
    90bb:	4c 89 ac 24 90 06 00 	mov    %r13,0x690(%rsp)
    90c2:	00 
    90c3:	48 89 84 24 98 06 00 	mov    %rax,0x698(%rsp)
    90ca:	00 
    90cb:	e8 a0 c1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    90d0:	48 8b 15 e1 79 01 00 	mov    0x179e1(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    90d7:	49 89 c6             	mov    %rax,%r14
    90da:	48 2b 05 af 79 01 00 	sub    0x179af(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    90e1:	48 c1 e2 10          	shl    $0x10,%rdx
    90e5:	48 39 d0             	cmp    %rdx,%rax
    90e8:	73 59                	jae    9143 <f0+0x1473>
    90ea:	48 89 c2             	mov    %rax,%rdx
    90ed:	48 c1 ea 10          	shr    $0x10,%rdx
    90f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90f5:	48 8b 15 dc 79 01 00 	mov    0x179dc(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    90fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9100:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9104:	4d 85 ed             	test   %r13,%r13
    9107:	74 3a                	je     9143 <f0+0x1473>
    9109:	0f b6 0a             	movzbl (%rdx),%ecx
    910c:	80 f9 02             	cmp    $0x2,%cl
    910f:	0f 84 9b 15 00 00    	je     a6b0 <f0+0x29e0>
    9115:	80 f9 01             	cmp    $0x1,%cl
    9118:	75 29                	jne    9143 <f0+0x1473>
    911a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    911d:	0f b7 c0             	movzwl %ax,%eax
    9120:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9123:	48 0f af c1          	imul   %rcx,%rax
    9127:	48 c1 e8 20          	shr    $0x20,%rax
    912b:	48 39 d0             	cmp    %rdx,%rax
    912e:	73 13                	jae    9143 <f0+0x1473>
    9130:	49 01 c5             	add    %rax,%r13
    9133:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9138:	0f 84 0e 17 00 00    	je     a84c <f0+0x2b7c>
    913e:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9143:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    914a:	33 f3 bf 
    914d:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    9154:	00 
    9155:	bf 01 00 00 00       	mov    $0x1,%edi
    915a:	4c 89 b4 24 a8 06 00 	mov    %r14,0x6a8(%rsp)
    9161:	00 
    9162:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    9169:	00 
    916a:	e8 01 c1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    916f:	48 8b 15 42 79 01 00 	mov    0x17942(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9176:	49 89 c6             	mov    %rax,%r14
    9179:	48 2b 05 10 79 01 00 	sub    0x17910(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9180:	48 c1 e2 10          	shl    $0x10,%rdx
    9184:	48 39 d0             	cmp    %rdx,%rax
    9187:	73 59                	jae    91e2 <f0+0x1512>
    9189:	48 89 c2             	mov    %rax,%rdx
    918c:	48 c1 ea 10          	shr    $0x10,%rdx
    9190:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9194:	48 8b 15 3d 79 01 00 	mov    0x1793d(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    919b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    919f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    91a3:	4d 85 ed             	test   %r13,%r13
    91a6:	74 3a                	je     91e2 <f0+0x1512>
    91a8:	0f b6 0a             	movzbl (%rdx),%ecx
    91ab:	80 f9 02             	cmp    $0x2,%cl
    91ae:	0f 84 ec 14 00 00    	je     a6a0 <f0+0x29d0>
    91b4:	80 f9 01             	cmp    $0x1,%cl
    91b7:	75 29                	jne    91e2 <f0+0x1512>
    91b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91bc:	0f b7 c0             	movzwl %ax,%eax
    91bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91c2:	48 0f af c1          	imul   %rcx,%rax
    91c6:	48 c1 e8 20          	shr    $0x20,%rax
    91ca:	48 39 d0             	cmp    %rdx,%rax
    91cd:	73 13                	jae    91e2 <f0+0x1512>
    91cf:	49 01 c5             	add    %rax,%r13
    91d2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    91d7:	0f 84 7c 16 00 00    	je     a859 <f0+0x2b89>
    91dd:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    91e2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    91e9:	00 f0 3f 
    91ec:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    91f3:	00 
    91f4:	bf 01 00 00 00       	mov    $0x1,%edi
    91f9:	4c 89 b4 24 b8 06 00 	mov    %r14,0x6b8(%rsp)
    9200:	00 
    9201:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    9208:	00 
    9209:	e8 62 c0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    920e:	48 8b 15 a3 78 01 00 	mov    0x178a3(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9215:	49 89 c6             	mov    %rax,%r14
    9218:	48 2b 05 71 78 01 00 	sub    0x17871(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    921f:	48 c1 e2 10          	shl    $0x10,%rdx
    9223:	48 39 d0             	cmp    %rdx,%rax
    9226:	73 59                	jae    9281 <f0+0x15b1>
    9228:	48 89 c2             	mov    %rax,%rdx
    922b:	48 c1 ea 10          	shr    $0x10,%rdx
    922f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9233:	48 8b 15 9e 78 01 00 	mov    0x1789e(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    923a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    923e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9242:	4d 85 ed             	test   %r13,%r13
    9245:	74 3a                	je     9281 <f0+0x15b1>
    9247:	0f b6 0a             	movzbl (%rdx),%ecx
    924a:	80 f9 02             	cmp    $0x2,%cl
    924d:	0f 84 7d 14 00 00    	je     a6d0 <f0+0x2a00>
    9253:	80 f9 01             	cmp    $0x1,%cl
    9256:	75 29                	jne    9281 <f0+0x15b1>
    9258:	8b 4a 18             	mov    0x18(%rdx),%ecx
    925b:	0f b7 c0             	movzwl %ax,%eax
    925e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9261:	48 0f af c1          	imul   %rcx,%rax
    9265:	48 c1 e8 20          	shr    $0x20,%rax
    9269:	48 39 d0             	cmp    %rdx,%rax
    926c:	73 13                	jae    9281 <f0+0x15b1>
    926e:	49 01 c5             	add    %rax,%r13
    9271:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9276:	0f 84 ea 15 00 00    	je     a866 <f0+0x2b96>
    927c:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9281:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9288:	33 f3 bf 
    928b:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    9292:	00 
    9293:	bf 01 00 00 00       	mov    $0x1,%edi
    9298:	4c 89 b4 24 c8 06 00 	mov    %r14,0x6c8(%rsp)
    929f:	00 
    92a0:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    92a7:	00 
    92a8:	e8 c3 bf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    92ad:	48 8b 15 04 78 01 00 	mov    0x17804(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    92b4:	49 89 c6             	mov    %rax,%r14
    92b7:	48 2b 05 d2 77 01 00 	sub    0x177d2(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    92be:	48 c1 e2 10          	shl    $0x10,%rdx
    92c2:	48 39 d0             	cmp    %rdx,%rax
    92c5:	73 59                	jae    9320 <f0+0x1650>
    92c7:	48 89 c2             	mov    %rax,%rdx
    92ca:	48 c1 ea 10          	shr    $0x10,%rdx
    92ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92d2:	48 8b 15 ff 77 01 00 	mov    0x177ff(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    92d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92dd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    92e1:	4d 85 ed             	test   %r13,%r13
    92e4:	74 3a                	je     9320 <f0+0x1650>
    92e6:	0f b6 0a             	movzbl (%rdx),%ecx
    92e9:	80 f9 02             	cmp    $0x2,%cl
    92ec:	0f 84 ce 13 00 00    	je     a6c0 <f0+0x29f0>
    92f2:	80 f9 01             	cmp    $0x1,%cl
    92f5:	75 29                	jne    9320 <f0+0x1650>
    92f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92fa:	0f b7 c0             	movzwl %ax,%eax
    92fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9300:	48 0f af c1          	imul   %rcx,%rax
    9304:	48 c1 e8 20          	shr    $0x20,%rax
    9308:	48 39 d0             	cmp    %rdx,%rax
    930b:	73 13                	jae    9320 <f0+0x1650>
    930d:	49 01 c5             	add    %rax,%r13
    9310:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9315:	0f 84 58 15 00 00    	je     a873 <f0+0x2ba3>
    931b:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9320:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9327:	00 f0 3f 
    932a:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    9331:	00 
    9332:	bf 01 00 00 00       	mov    $0x1,%edi
    9337:	4c 89 b4 24 d8 06 00 	mov    %r14,0x6d8(%rsp)
    933e:	00 
    933f:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    9346:	00 
    9347:	e8 24 bf ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    934c:	48 8b 15 65 77 01 00 	mov    0x17765(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9353:	49 89 c6             	mov    %rax,%r14
    9356:	48 2b 05 33 77 01 00 	sub    0x17733(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    935d:	48 c1 e2 10          	shl    $0x10,%rdx
    9361:	48 39 d0             	cmp    %rdx,%rax
    9364:	73 59                	jae    93bf <f0+0x16ef>
    9366:	48 89 c2             	mov    %rax,%rdx
    9369:	48 c1 ea 10          	shr    $0x10,%rdx
    936d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9371:	48 8b 15 60 77 01 00 	mov    0x17760(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9378:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    937c:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9380:	4d 85 ed             	test   %r13,%r13
    9383:	74 3a                	je     93bf <f0+0x16ef>
    9385:	0f b6 0a             	movzbl (%rdx),%ecx
    9388:	80 f9 02             	cmp    $0x2,%cl
    938b:	0f 84 5f 13 00 00    	je     a6f0 <f0+0x2a20>
    9391:	80 f9 01             	cmp    $0x1,%cl
    9394:	75 29                	jne    93bf <f0+0x16ef>
    9396:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9399:	0f b7 c0             	movzwl %ax,%eax
    939c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    939f:	48 0f af c1          	imul   %rcx,%rax
    93a3:	48 c1 e8 20          	shr    $0x20,%rax
    93a7:	48 39 d0             	cmp    %rdx,%rax
    93aa:	73 13                	jae    93bf <f0+0x16ef>
    93ac:	49 01 c5             	add    %rax,%r13
    93af:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    93b4:	0f 84 c6 14 00 00    	je     a880 <f0+0x2bb0>
    93ba:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    93bf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    93c6:	33 f3 bf 
    93c9:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    93d0:	00 
    93d1:	bf 01 00 00 00       	mov    $0x1,%edi
    93d6:	4c 89 b4 24 e8 06 00 	mov    %r14,0x6e8(%rsp)
    93dd:	00 
    93de:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    93e5:	00 
    93e6:	e8 85 be ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    93eb:	48 8b 15 c6 76 01 00 	mov    0x176c6(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    93f2:	49 89 c6             	mov    %rax,%r14
    93f5:	48 2b 05 94 76 01 00 	sub    0x17694(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    93fc:	48 c1 e2 10          	shl    $0x10,%rdx
    9400:	48 39 d0             	cmp    %rdx,%rax
    9403:	73 59                	jae    945e <f0+0x178e>
    9405:	48 89 c2             	mov    %rax,%rdx
    9408:	48 c1 ea 10          	shr    $0x10,%rdx
    940c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9410:	48 8b 15 c1 76 01 00 	mov    0x176c1(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9417:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    941b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    941f:	4d 85 ed             	test   %r13,%r13
    9422:	74 3a                	je     945e <f0+0x178e>
    9424:	0f b6 0a             	movzbl (%rdx),%ecx
    9427:	80 f9 02             	cmp    $0x2,%cl
    942a:	0f 84 b0 12 00 00    	je     a6e0 <f0+0x2a10>
    9430:	80 f9 01             	cmp    $0x1,%cl
    9433:	75 29                	jne    945e <f0+0x178e>
    9435:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9438:	0f b7 c0             	movzwl %ax,%eax
    943b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    943e:	48 0f af c1          	imul   %rcx,%rax
    9442:	48 c1 e8 20          	shr    $0x20,%rax
    9446:	48 39 d0             	cmp    %rdx,%rax
    9449:	73 13                	jae    945e <f0+0x178e>
    944b:	49 01 c5             	add    %rax,%r13
    944e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9453:	0f 84 34 14 00 00    	je     a88d <f0+0x2bbd>
    9459:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    945e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9465:	00 f0 3f 
    9468:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    946f:	00 
    9470:	bf 01 00 00 00       	mov    $0x1,%edi
    9475:	4c 89 b4 24 f8 06 00 	mov    %r14,0x6f8(%rsp)
    947c:	00 
    947d:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    9484:	00 
    9485:	e8 e6 bd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    948a:	48 8b 15 27 76 01 00 	mov    0x17627(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9491:	49 89 c6             	mov    %rax,%r14
    9494:	48 2b 05 f5 75 01 00 	sub    0x175f5(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    949b:	48 c1 e2 10          	shl    $0x10,%rdx
    949f:	48 39 d0             	cmp    %rdx,%rax
    94a2:	73 59                	jae    94fd <f0+0x182d>
    94a4:	48 89 c2             	mov    %rax,%rdx
    94a7:	48 c1 ea 10          	shr    $0x10,%rdx
    94ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94af:	48 8b 15 22 76 01 00 	mov    0x17622(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    94b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94ba:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    94be:	4d 85 ed             	test   %r13,%r13
    94c1:	74 3a                	je     94fd <f0+0x182d>
    94c3:	0f b6 0a             	movzbl (%rdx),%ecx
    94c6:	80 f9 02             	cmp    $0x2,%cl
    94c9:	0f 84 41 11 00 00    	je     a610 <f0+0x2940>
    94cf:	80 f9 01             	cmp    $0x1,%cl
    94d2:	75 29                	jne    94fd <f0+0x182d>
    94d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94d7:	0f b7 c0             	movzwl %ax,%eax
    94da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94dd:	48 0f af c1          	imul   %rcx,%rax
    94e1:	48 c1 e8 20          	shr    $0x20,%rax
    94e5:	48 39 d0             	cmp    %rdx,%rax
    94e8:	73 13                	jae    94fd <f0+0x182d>
    94ea:	49 01 c5             	add    %rax,%r13
    94ed:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    94f2:	0f 84 a2 13 00 00    	je     a89a <f0+0x2bca>
    94f8:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    94fd:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9504:	33 f3 bf 
    9507:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    950e:	00 
    950f:	bf 01 00 00 00       	mov    $0x1,%edi
    9514:	4c 89 b4 24 08 07 00 	mov    %r14,0x708(%rsp)
    951b:	00 
    951c:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    9523:	00 
    9524:	e8 47 bd ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9529:	48 8b 15 88 75 01 00 	mov    0x17588(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9530:	49 89 c6             	mov    %rax,%r14
    9533:	48 2b 05 56 75 01 00 	sub    0x17556(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    953a:	48 c1 e2 10          	shl    $0x10,%rdx
    953e:	48 39 d0             	cmp    %rdx,%rax
    9541:	73 59                	jae    959c <f0+0x18cc>
    9543:	48 89 c2             	mov    %rax,%rdx
    9546:	48 c1 ea 10          	shr    $0x10,%rdx
    954a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    954e:	48 8b 15 83 75 01 00 	mov    0x17583(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9555:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9559:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    955d:	4d 85 ed             	test   %r13,%r13
    9560:	74 3a                	je     959c <f0+0x18cc>
    9562:	0f b6 0a             	movzbl (%rdx),%ecx
    9565:	80 f9 02             	cmp    $0x2,%cl
    9568:	0f 84 92 10 00 00    	je     a600 <f0+0x2930>
    956e:	80 f9 01             	cmp    $0x1,%cl
    9571:	75 29                	jne    959c <f0+0x18cc>
    9573:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9576:	0f b7 c0             	movzwl %ax,%eax
    9579:	8b 52 1c             	mov    0x1c(%rdx),%edx
    957c:	48 0f af c1          	imul   %rcx,%rax
    9580:	48 c1 e8 20          	shr    $0x20,%rax
    9584:	48 39 d0             	cmp    %rdx,%rax
    9587:	73 13                	jae    959c <f0+0x18cc>
    9589:	49 01 c5             	add    %rax,%r13
    958c:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9591:	0f 84 10 13 00 00    	je     a8a7 <f0+0x2bd7>
    9597:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    959c:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    95a3:	00 f0 3f 
    95a6:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    95ad:	00 
    95ae:	bf 01 00 00 00       	mov    $0x1,%edi
    95b3:	4c 89 b4 24 18 07 00 	mov    %r14,0x718(%rsp)
    95ba:	00 
    95bb:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    95c2:	00 
    95c3:	e8 a8 bc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    95c8:	48 8b 15 e9 74 01 00 	mov    0x174e9(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    95cf:	49 89 c6             	mov    %rax,%r14
    95d2:	48 2b 05 b7 74 01 00 	sub    0x174b7(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    95d9:	48 c1 e2 10          	shl    $0x10,%rdx
    95dd:	48 39 d0             	cmp    %rdx,%rax
    95e0:	73 59                	jae    963b <f0+0x196b>
    95e2:	48 89 c2             	mov    %rax,%rdx
    95e5:	48 c1 ea 10          	shr    $0x10,%rdx
    95e9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95ed:	48 8b 15 e4 74 01 00 	mov    0x174e4(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    95f4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95f8:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    95fc:	4d 85 ed             	test   %r13,%r13
    95ff:	74 3a                	je     963b <f0+0x196b>
    9601:	0f b6 0a             	movzbl (%rdx),%ecx
    9604:	80 f9 02             	cmp    $0x2,%cl
    9607:	0f 84 23 10 00 00    	je     a630 <f0+0x2960>
    960d:	80 f9 01             	cmp    $0x1,%cl
    9610:	75 29                	jne    963b <f0+0x196b>
    9612:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9615:	0f b7 c0             	movzwl %ax,%eax
    9618:	8b 52 1c             	mov    0x1c(%rdx),%edx
    961b:	48 0f af c1          	imul   %rcx,%rax
    961f:	48 c1 e8 20          	shr    $0x20,%rax
    9623:	48 39 d0             	cmp    %rdx,%rax
    9626:	73 13                	jae    963b <f0+0x196b>
    9628:	49 01 c5             	add    %rax,%r13
    962b:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9630:	0f 84 7e 12 00 00    	je     a8b4 <f0+0x2be4>
    9636:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    963b:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9642:	33 f3 bf 
    9645:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    964c:	00 
    964d:	bf 01 00 00 00       	mov    $0x1,%edi
    9652:	4c 89 b4 24 28 07 00 	mov    %r14,0x728(%rsp)
    9659:	00 
    965a:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    9661:	00 
    9662:	e8 09 bc ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9667:	48 8b 15 4a 74 01 00 	mov    0x1744a(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    966e:	49 89 c6             	mov    %rax,%r14
    9671:	48 2b 05 18 74 01 00 	sub    0x17418(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9678:	48 c1 e2 10          	shl    $0x10,%rdx
    967c:	48 39 d0             	cmp    %rdx,%rax
    967f:	73 59                	jae    96da <f0+0x1a0a>
    9681:	48 89 c2             	mov    %rax,%rdx
    9684:	48 c1 ea 10          	shr    $0x10,%rdx
    9688:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    968c:	48 8b 15 45 74 01 00 	mov    0x17445(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9693:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9697:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    969b:	4d 85 ed             	test   %r13,%r13
    969e:	74 3a                	je     96da <f0+0x1a0a>
    96a0:	0f b6 0a             	movzbl (%rdx),%ecx
    96a3:	80 f9 02             	cmp    $0x2,%cl
    96a6:	0f 84 74 0f 00 00    	je     a620 <f0+0x2950>
    96ac:	80 f9 01             	cmp    $0x1,%cl
    96af:	75 29                	jne    96da <f0+0x1a0a>
    96b1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96b4:	0f b7 c0             	movzwl %ax,%eax
    96b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96ba:	48 0f af c1          	imul   %rcx,%rax
    96be:	48 c1 e8 20          	shr    $0x20,%rax
    96c2:	48 39 d0             	cmp    %rdx,%rax
    96c5:	73 13                	jae    96da <f0+0x1a0a>
    96c7:	49 01 c5             	add    %rax,%r13
    96ca:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    96cf:	0f 84 ec 11 00 00    	je     a8c1 <f0+0x2bf1>
    96d5:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    96da:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    96e1:	00 f0 3f 
    96e4:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    96eb:	00 
    96ec:	bf 01 00 00 00       	mov    $0x1,%edi
    96f1:	4c 89 b4 24 38 07 00 	mov    %r14,0x738(%rsp)
    96f8:	00 
    96f9:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    9700:	00 
    9701:	e8 6a bb ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9706:	48 8b 15 ab 73 01 00 	mov    0x173ab(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    970d:	49 89 c6             	mov    %rax,%r14
    9710:	48 2b 05 79 73 01 00 	sub    0x17379(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9717:	48 c1 e2 10          	shl    $0x10,%rdx
    971b:	48 39 d0             	cmp    %rdx,%rax
    971e:	73 59                	jae    9779 <f0+0x1aa9>
    9720:	48 89 c2             	mov    %rax,%rdx
    9723:	48 c1 ea 10          	shr    $0x10,%rdx
    9727:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    972b:	48 8b 15 a6 73 01 00 	mov    0x173a6(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9732:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9736:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    973a:	4d 85 ed             	test   %r13,%r13
    973d:	74 3a                	je     9779 <f0+0x1aa9>
    973f:	0f b6 0a             	movzbl (%rdx),%ecx
    9742:	80 f9 02             	cmp    $0x2,%cl
    9745:	0f 84 05 0f 00 00    	je     a650 <f0+0x2980>
    974b:	80 f9 01             	cmp    $0x1,%cl
    974e:	75 29                	jne    9779 <f0+0x1aa9>
    9750:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9753:	0f b7 c0             	movzwl %ax,%eax
    9756:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9759:	48 0f af c1          	imul   %rcx,%rax
    975d:	48 c1 e8 20          	shr    $0x20,%rax
    9761:	48 39 d0             	cmp    %rdx,%rax
    9764:	73 13                	jae    9779 <f0+0x1aa9>
    9766:	49 01 c5             	add    %rax,%r13
    9769:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    976e:	0f 84 5a 11 00 00    	je     a8ce <f0+0x2bfe>
    9774:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9779:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9780:	33 f3 bf 
    9783:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    978a:	00 
    978b:	bf 01 00 00 00       	mov    $0x1,%edi
    9790:	4c 89 b4 24 48 07 00 	mov    %r14,0x748(%rsp)
    9797:	00 
    9798:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    979f:	00 
    97a0:	e8 cb ba ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    97a5:	48 8b 15 0c 73 01 00 	mov    0x1730c(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    97ac:	49 89 c6             	mov    %rax,%r14
    97af:	48 2b 05 da 72 01 00 	sub    0x172da(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    97b6:	48 c1 e2 10          	shl    $0x10,%rdx
    97ba:	48 39 d0             	cmp    %rdx,%rax
    97bd:	73 59                	jae    9818 <f0+0x1b48>
    97bf:	48 89 c2             	mov    %rax,%rdx
    97c2:	48 c1 ea 10          	shr    $0x10,%rdx
    97c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97ca:	48 8b 15 07 73 01 00 	mov    0x17307(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    97d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97d5:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    97d9:	4d 85 ed             	test   %r13,%r13
    97dc:	74 3a                	je     9818 <f0+0x1b48>
    97de:	0f b6 0a             	movzbl (%rdx),%ecx
    97e1:	80 f9 02             	cmp    $0x2,%cl
    97e4:	0f 84 56 0e 00 00    	je     a640 <f0+0x2970>
    97ea:	80 f9 01             	cmp    $0x1,%cl
    97ed:	75 29                	jne    9818 <f0+0x1b48>
    97ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97f2:	0f b7 c0             	movzwl %ax,%eax
    97f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97f8:	48 0f af c1          	imul   %rcx,%rax
    97fc:	48 c1 e8 20          	shr    $0x20,%rax
    9800:	48 39 d0             	cmp    %rdx,%rax
    9803:	73 13                	jae    9818 <f0+0x1b48>
    9805:	49 01 c5             	add    %rax,%r13
    9808:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    980d:	0f 84 c8 10 00 00    	je     a8db <f0+0x2c0b>
    9813:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9818:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    981f:	00 f0 3f 
    9822:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    9829:	00 
    982a:	bf 01 00 00 00       	mov    $0x1,%edi
    982f:	4c 89 b4 24 58 07 00 	mov    %r14,0x758(%rsp)
    9836:	00 
    9837:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    983e:	00 
    983f:	e8 2c ba ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9844:	48 8b 15 6d 72 01 00 	mov    0x1726d(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    984b:	49 89 c6             	mov    %rax,%r14
    984e:	48 2b 05 3b 72 01 00 	sub    0x1723b(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9855:	48 c1 e2 10          	shl    $0x10,%rdx
    9859:	48 39 d0             	cmp    %rdx,%rax
    985c:	73 59                	jae    98b7 <f0+0x1be7>
    985e:	48 89 c2             	mov    %rax,%rdx
    9861:	48 c1 ea 10          	shr    $0x10,%rdx
    9865:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9869:	48 8b 15 68 72 01 00 	mov    0x17268(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9870:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9874:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9878:	4d 85 ed             	test   %r13,%r13
    987b:	74 3a                	je     98b7 <f0+0x1be7>
    987d:	0f b6 0a             	movzbl (%rdx),%ecx
    9880:	80 f9 02             	cmp    $0x2,%cl
    9883:	0f 84 e7 0d 00 00    	je     a670 <f0+0x29a0>
    9889:	80 f9 01             	cmp    $0x1,%cl
    988c:	75 29                	jne    98b7 <f0+0x1be7>
    988e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9891:	0f b7 c0             	movzwl %ax,%eax
    9894:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9897:	48 0f af c1          	imul   %rcx,%rax
    989b:	48 c1 e8 20          	shr    $0x20,%rax
    989f:	48 39 d0             	cmp    %rdx,%rax
    98a2:	73 13                	jae    98b7 <f0+0x1be7>
    98a4:	49 01 c5             	add    %rax,%r13
    98a7:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    98ac:	0f 84 36 10 00 00    	je     a8e8 <f0+0x2c18>
    98b2:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    98b7:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    98be:	33 f3 bf 
    98c1:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    98c8:	00 
    98c9:	bf 01 00 00 00       	mov    $0x1,%edi
    98ce:	4c 89 b4 24 68 07 00 	mov    %r14,0x768(%rsp)
    98d5:	00 
    98d6:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    98dd:	00 
    98de:	e8 8d b9 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    98e3:	48 8b 15 ce 71 01 00 	mov    0x171ce(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    98ea:	49 89 c6             	mov    %rax,%r14
    98ed:	48 2b 05 9c 71 01 00 	sub    0x1719c(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    98f4:	48 c1 e2 10          	shl    $0x10,%rdx
    98f8:	48 39 d0             	cmp    %rdx,%rax
    98fb:	73 59                	jae    9956 <f0+0x1c86>
    98fd:	48 89 c2             	mov    %rax,%rdx
    9900:	48 c1 ea 10          	shr    $0x10,%rdx
    9904:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9908:	48 8b 15 c9 71 01 00 	mov    0x171c9(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    990f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9913:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9917:	4d 85 ed             	test   %r13,%r13
    991a:	74 3a                	je     9956 <f0+0x1c86>
    991c:	0f b6 0a             	movzbl (%rdx),%ecx
    991f:	80 f9 02             	cmp    $0x2,%cl
    9922:	0f 84 38 0d 00 00    	je     a660 <f0+0x2990>
    9928:	80 f9 01             	cmp    $0x1,%cl
    992b:	75 29                	jne    9956 <f0+0x1c86>
    992d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9930:	0f b7 c0             	movzwl %ax,%eax
    9933:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9936:	48 0f af c1          	imul   %rcx,%rax
    993a:	48 c1 e8 20          	shr    $0x20,%rax
    993e:	48 39 d0             	cmp    %rdx,%rax
    9941:	73 13                	jae    9956 <f0+0x1c86>
    9943:	49 01 c5             	add    %rax,%r13
    9946:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    994b:	0f 84 a4 0f 00 00    	je     a8f5 <f0+0x2c25>
    9951:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9956:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    995d:	00 f0 3f 
    9960:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    9967:	00 
    9968:	bf 01 00 00 00       	mov    $0x1,%edi
    996d:	4c 89 b4 24 78 07 00 	mov    %r14,0x778(%rsp)
    9974:	00 
    9975:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    997c:	00 
    997d:	e8 ee b8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9982:	48 8b 15 2f 71 01 00 	mov    0x1712f(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9989:	49 89 c6             	mov    %rax,%r14
    998c:	48 2b 05 fd 70 01 00 	sub    0x170fd(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9993:	48 c1 e2 10          	shl    $0x10,%rdx
    9997:	48 39 d0             	cmp    %rdx,%rax
    999a:	73 59                	jae    99f5 <f0+0x1d25>
    999c:	48 89 c2             	mov    %rax,%rdx
    999f:	48 c1 ea 10          	shr    $0x10,%rdx
    99a3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99a7:	48 8b 15 2a 71 01 00 	mov    0x1712a(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    99ae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99b2:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    99b6:	4d 85 ed             	test   %r13,%r13
    99b9:	74 3a                	je     99f5 <f0+0x1d25>
    99bb:	0f b6 0a             	movzbl (%rdx),%ecx
    99be:	80 f9 02             	cmp    $0x2,%cl
    99c1:	0f 84 c9 0d 00 00    	je     a790 <f0+0x2ac0>
    99c7:	80 f9 01             	cmp    $0x1,%cl
    99ca:	75 29                	jne    99f5 <f0+0x1d25>
    99cc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99cf:	0f b7 c0             	movzwl %ax,%eax
    99d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99d5:	48 0f af c1          	imul   %rcx,%rax
    99d9:	48 c1 e8 20          	shr    $0x20,%rax
    99dd:	48 39 d0             	cmp    %rdx,%rax
    99e0:	73 13                	jae    99f5 <f0+0x1d25>
    99e2:	49 01 c5             	add    %rax,%r13
    99e5:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    99ea:	0f 84 12 0f 00 00    	je     a902 <f0+0x2c32>
    99f0:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    99f5:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    99fc:	33 f3 bf 
    99ff:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    9a06:	00 
    9a07:	bf 01 00 00 00       	mov    $0x1,%edi
    9a0c:	4c 89 b4 24 88 07 00 	mov    %r14,0x788(%rsp)
    9a13:	00 
    9a14:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    9a1b:	00 
    9a1c:	e8 4f b8 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9a21:	48 8b 15 90 70 01 00 	mov    0x17090(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9a28:	49 89 c6             	mov    %rax,%r14
    9a2b:	48 2b 05 5e 70 01 00 	sub    0x1705e(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9a32:	48 c1 e2 10          	shl    $0x10,%rdx
    9a36:	48 39 d0             	cmp    %rdx,%rax
    9a39:	73 59                	jae    9a94 <f0+0x1dc4>
    9a3b:	48 89 c2             	mov    %rax,%rdx
    9a3e:	48 c1 ea 10          	shr    $0x10,%rdx
    9a42:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a46:	48 8b 15 8b 70 01 00 	mov    0x1708b(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9a4d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a51:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9a55:	4d 85 ed             	test   %r13,%r13
    9a58:	74 3a                	je     9a94 <f0+0x1dc4>
    9a5a:	0f b6 0a             	movzbl (%rdx),%ecx
    9a5d:	80 f9 02             	cmp    $0x2,%cl
    9a60:	0f 84 1a 0d 00 00    	je     a780 <f0+0x2ab0>
    9a66:	80 f9 01             	cmp    $0x1,%cl
    9a69:	75 29                	jne    9a94 <f0+0x1dc4>
    9a6b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a6e:	0f b7 c0             	movzwl %ax,%eax
    9a71:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a74:	48 0f af c1          	imul   %rcx,%rax
    9a78:	48 c1 e8 20          	shr    $0x20,%rax
    9a7c:	48 39 d0             	cmp    %rdx,%rax
    9a7f:	73 13                	jae    9a94 <f0+0x1dc4>
    9a81:	49 01 c5             	add    %rax,%r13
    9a84:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9a89:	0f 84 80 0e 00 00    	je     a90f <f0+0x2c3f>
    9a8f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9a94:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9a9b:	00 f0 3f 
    9a9e:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    9aa5:	00 
    9aa6:	bf 01 00 00 00       	mov    $0x1,%edi
    9aab:	4c 89 b4 24 98 07 00 	mov    %r14,0x798(%rsp)
    9ab2:	00 
    9ab3:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    9aba:	00 
    9abb:	e8 b0 b7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9ac0:	48 8b 15 f1 6f 01 00 	mov    0x16ff1(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9ac7:	49 89 c6             	mov    %rax,%r14
    9aca:	48 2b 05 bf 6f 01 00 	sub    0x16fbf(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9ad1:	48 c1 e2 10          	shl    $0x10,%rdx
    9ad5:	48 39 d0             	cmp    %rdx,%rax
    9ad8:	73 59                	jae    9b33 <f0+0x1e63>
    9ada:	48 89 c2             	mov    %rax,%rdx
    9add:	48 c1 ea 10          	shr    $0x10,%rdx
    9ae1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ae5:	48 8b 15 ec 6f 01 00 	mov    0x16fec(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9aec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9af0:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9af4:	4d 85 ed             	test   %r13,%r13
    9af7:	74 3a                	je     9b33 <f0+0x1e63>
    9af9:	0f b6 0a             	movzbl (%rdx),%ecx
    9afc:	80 f9 02             	cmp    $0x2,%cl
    9aff:	0f 84 ab 0c 00 00    	je     a7b0 <f0+0x2ae0>
    9b05:	80 f9 01             	cmp    $0x1,%cl
    9b08:	75 29                	jne    9b33 <f0+0x1e63>
    9b0a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b0d:	0f b7 c0             	movzwl %ax,%eax
    9b10:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b13:	48 0f af c1          	imul   %rcx,%rax
    9b17:	48 c1 e8 20          	shr    $0x20,%rax
    9b1b:	48 39 d0             	cmp    %rdx,%rax
    9b1e:	73 13                	jae    9b33 <f0+0x1e63>
    9b20:	49 01 c5             	add    %rax,%r13
    9b23:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9b28:	0f 84 ee 0d 00 00    	je     a91c <f0+0x2c4c>
    9b2e:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9b33:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9b3a:	33 f3 bf 
    9b3d:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    9b44:	00 
    9b45:	bf 01 00 00 00       	mov    $0x1,%edi
    9b4a:	4c 89 b4 24 a8 07 00 	mov    %r14,0x7a8(%rsp)
    9b51:	00 
    9b52:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    9b59:	00 
    9b5a:	e8 11 b7 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9b5f:	48 8b 15 52 6f 01 00 	mov    0x16f52(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9b66:	49 89 c6             	mov    %rax,%r14
    9b69:	48 2b 05 20 6f 01 00 	sub    0x16f20(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9b70:	48 c1 e2 10          	shl    $0x10,%rdx
    9b74:	48 39 d0             	cmp    %rdx,%rax
    9b77:	73 59                	jae    9bd2 <f0+0x1f02>
    9b79:	48 89 c2             	mov    %rax,%rdx
    9b7c:	48 c1 ea 10          	shr    $0x10,%rdx
    9b80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b84:	48 8b 15 4d 6f 01 00 	mov    0x16f4d(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9b8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b8f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9b93:	4d 85 ed             	test   %r13,%r13
    9b96:	74 3a                	je     9bd2 <f0+0x1f02>
    9b98:	0f b6 0a             	movzbl (%rdx),%ecx
    9b9b:	80 f9 02             	cmp    $0x2,%cl
    9b9e:	0f 84 fc 0b 00 00    	je     a7a0 <f0+0x2ad0>
    9ba4:	80 f9 01             	cmp    $0x1,%cl
    9ba7:	75 29                	jne    9bd2 <f0+0x1f02>
    9ba9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bac:	0f b7 c0             	movzwl %ax,%eax
    9baf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bb2:	48 0f af c1          	imul   %rcx,%rax
    9bb6:	48 c1 e8 20          	shr    $0x20,%rax
    9bba:	48 39 d0             	cmp    %rdx,%rax
    9bbd:	73 13                	jae    9bd2 <f0+0x1f02>
    9bbf:	49 01 c5             	add    %rax,%r13
    9bc2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9bc7:	0f 84 5c 0d 00 00    	je     a929 <f0+0x2c59>
    9bcd:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9bd2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9bd9:	00 f0 3f 
    9bdc:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    9be3:	00 
    9be4:	bf 01 00 00 00       	mov    $0x1,%edi
    9be9:	4c 89 b4 24 b8 07 00 	mov    %r14,0x7b8(%rsp)
    9bf0:	00 
    9bf1:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    9bf8:	00 
    9bf9:	e8 72 b6 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9bfe:	48 8b 15 b3 6e 01 00 	mov    0x16eb3(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9c05:	49 89 c6             	mov    %rax,%r14
    9c08:	48 2b 05 81 6e 01 00 	sub    0x16e81(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9c0f:	48 c1 e2 10          	shl    $0x10,%rdx
    9c13:	48 39 d0             	cmp    %rdx,%rax
    9c16:	73 59                	jae    9c71 <f0+0x1fa1>
    9c18:	48 89 c2             	mov    %rax,%rdx
    9c1b:	48 c1 ea 10          	shr    $0x10,%rdx
    9c1f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c23:	48 8b 15 ae 6e 01 00 	mov    0x16eae(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9c2a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c2e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9c32:	4d 85 ed             	test   %r13,%r13
    9c35:	74 3a                	je     9c71 <f0+0x1fa1>
    9c37:	0f b6 0a             	movzbl (%rdx),%ecx
    9c3a:	80 f9 02             	cmp    $0x2,%cl
    9c3d:	0f 84 8d 0b 00 00    	je     a7d0 <f0+0x2b00>
    9c43:	80 f9 01             	cmp    $0x1,%cl
    9c46:	75 29                	jne    9c71 <f0+0x1fa1>
    9c48:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c4b:	0f b7 c0             	movzwl %ax,%eax
    9c4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c51:	48 0f af c1          	imul   %rcx,%rax
    9c55:	48 c1 e8 20          	shr    $0x20,%rax
    9c59:	48 39 d0             	cmp    %rdx,%rax
    9c5c:	73 13                	jae    9c71 <f0+0x1fa1>
    9c5e:	49 01 c5             	add    %rax,%r13
    9c61:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9c66:	0f 84 ca 0c 00 00    	je     a936 <f0+0x2c66>
    9c6c:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9c71:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9c78:	33 f3 bf 
    9c7b:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    9c82:	00 
    9c83:	bf 01 00 00 00       	mov    $0x1,%edi
    9c88:	4c 89 b4 24 c8 07 00 	mov    %r14,0x7c8(%rsp)
    9c8f:	00 
    9c90:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    9c97:	00 
    9c98:	e8 d3 b5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9c9d:	48 8b 15 14 6e 01 00 	mov    0x16e14(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9ca4:	49 89 c6             	mov    %rax,%r14
    9ca7:	48 2b 05 e2 6d 01 00 	sub    0x16de2(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9cae:	48 c1 e2 10          	shl    $0x10,%rdx
    9cb2:	48 39 d0             	cmp    %rdx,%rax
    9cb5:	73 59                	jae    9d10 <f0+0x2040>
    9cb7:	48 89 c2             	mov    %rax,%rdx
    9cba:	48 c1 ea 10          	shr    $0x10,%rdx
    9cbe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9cc2:	48 8b 15 0f 6e 01 00 	mov    0x16e0f(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9cc9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ccd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9cd1:	4d 85 ed             	test   %r13,%r13
    9cd4:	74 3a                	je     9d10 <f0+0x2040>
    9cd6:	0f b6 0a             	movzbl (%rdx),%ecx
    9cd9:	80 f9 02             	cmp    $0x2,%cl
    9cdc:	0f 84 de 0a 00 00    	je     a7c0 <f0+0x2af0>
    9ce2:	80 f9 01             	cmp    $0x1,%cl
    9ce5:	75 29                	jne    9d10 <f0+0x2040>
    9ce7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cea:	0f b7 c0             	movzwl %ax,%eax
    9ced:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cf0:	48 0f af c1          	imul   %rcx,%rax
    9cf4:	48 c1 e8 20          	shr    $0x20,%rax
    9cf8:	48 39 d0             	cmp    %rdx,%rax
    9cfb:	73 13                	jae    9d10 <f0+0x2040>
    9cfd:	49 01 c5             	add    %rax,%r13
    9d00:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9d05:	0f 84 38 0c 00 00    	je     a943 <f0+0x2c73>
    9d0b:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9d10:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9d17:	00 f0 3f 
    9d1a:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    9d21:	00 
    9d22:	bf 01 00 00 00       	mov    $0x1,%edi
    9d27:	4c 89 b4 24 d8 07 00 	mov    %r14,0x7d8(%rsp)
    9d2e:	00 
    9d2f:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9d36:	00 
    9d37:	e8 34 b5 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9d3c:	48 8b 15 75 6d 01 00 	mov    0x16d75(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9d43:	49 89 c6             	mov    %rax,%r14
    9d46:	48 2b 05 43 6d 01 00 	sub    0x16d43(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9d4d:	48 c1 e2 10          	shl    $0x10,%rdx
    9d51:	48 39 d0             	cmp    %rdx,%rax
    9d54:	73 59                	jae    9daf <f0+0x20df>
    9d56:	48 89 c2             	mov    %rax,%rdx
    9d59:	48 c1 ea 10          	shr    $0x10,%rdx
    9d5d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d61:	48 8b 15 70 6d 01 00 	mov    0x16d70(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9d68:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d6c:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9d70:	4d 85 ed             	test   %r13,%r13
    9d73:	74 3a                	je     9daf <f0+0x20df>
    9d75:	0f b6 0a             	movzbl (%rdx),%ecx
    9d78:	80 f9 02             	cmp    $0x2,%cl
    9d7b:	0f 84 6f 0a 00 00    	je     a7f0 <f0+0x2b20>
    9d81:	80 f9 01             	cmp    $0x1,%cl
    9d84:	75 29                	jne    9daf <f0+0x20df>
    9d86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d89:	0f b7 c0             	movzwl %ax,%eax
    9d8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d8f:	48 0f af c1          	imul   %rcx,%rax
    9d93:	48 c1 e8 20          	shr    $0x20,%rax
    9d97:	48 39 d0             	cmp    %rdx,%rax
    9d9a:	73 13                	jae    9daf <f0+0x20df>
    9d9c:	49 01 c5             	add    %rax,%r13
    9d9f:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9da4:	0f 84 a6 0b 00 00    	je     a950 <f0+0x2c80>
    9daa:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9daf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9db6:	33 f3 bf 
    9db9:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    9dc0:	00 
    9dc1:	bf 01 00 00 00       	mov    $0x1,%edi
    9dc6:	4c 89 b4 24 e8 07 00 	mov    %r14,0x7e8(%rsp)
    9dcd:	00 
    9dce:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    9dd5:	00 
    9dd6:	e8 95 b4 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9ddb:	48 8b 15 d6 6c 01 00 	mov    0x16cd6(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9de2:	49 89 c6             	mov    %rax,%r14
    9de5:	48 2b 05 a4 6c 01 00 	sub    0x16ca4(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9dec:	48 c1 e2 10          	shl    $0x10,%rdx
    9df0:	48 39 d0             	cmp    %rdx,%rax
    9df3:	73 59                	jae    9e4e <f0+0x217e>
    9df5:	48 89 c2             	mov    %rax,%rdx
    9df8:	48 c1 ea 10          	shr    $0x10,%rdx
    9dfc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e00:	48 8b 15 d1 6c 01 00 	mov    0x16cd1(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9e07:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e0b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9e0f:	4d 85 ed             	test   %r13,%r13
    9e12:	74 3a                	je     9e4e <f0+0x217e>
    9e14:	0f b6 0a             	movzbl (%rdx),%ecx
    9e17:	80 f9 02             	cmp    $0x2,%cl
    9e1a:	0f 84 c0 09 00 00    	je     a7e0 <f0+0x2b10>
    9e20:	80 f9 01             	cmp    $0x1,%cl
    9e23:	75 29                	jne    9e4e <f0+0x217e>
    9e25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e28:	0f b7 c0             	movzwl %ax,%eax
    9e2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e2e:	48 0f af c1          	imul   %rcx,%rax
    9e32:	48 c1 e8 20          	shr    $0x20,%rax
    9e36:	48 39 d0             	cmp    %rdx,%rax
    9e39:	73 13                	jae    9e4e <f0+0x217e>
    9e3b:	49 01 c5             	add    %rax,%r13
    9e3e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9e43:	0f 84 14 0b 00 00    	je     a95d <f0+0x2c8d>
    9e49:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9e4e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9e55:	00 f0 3f 
    9e58:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    9e5f:	00 
    9e60:	bf 01 00 00 00       	mov    $0x1,%edi
    9e65:	4c 89 b4 24 f8 07 00 	mov    %r14,0x7f8(%rsp)
    9e6c:	00 
    9e6d:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9e74:	00 
    9e75:	e8 f6 b3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9e7a:	48 8b 15 37 6c 01 00 	mov    0x16c37(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9e81:	49 89 c6             	mov    %rax,%r14
    9e84:	48 2b 05 05 6c 01 00 	sub    0x16c05(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9e8b:	48 c1 e2 10          	shl    $0x10,%rdx
    9e8f:	48 39 d0             	cmp    %rdx,%rax
    9e92:	73 59                	jae    9eed <f0+0x221d>
    9e94:	48 89 c2             	mov    %rax,%rdx
    9e97:	48 c1 ea 10          	shr    $0x10,%rdx
    9e9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e9f:	48 8b 15 32 6c 01 00 	mov    0x16c32(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9ea6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9eaa:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9eae:	4d 85 ed             	test   %r13,%r13
    9eb1:	74 3a                	je     9eed <f0+0x221d>
    9eb3:	0f b6 0a             	movzbl (%rdx),%ecx
    9eb6:	80 f9 02             	cmp    $0x2,%cl
    9eb9:	0f 84 51 08 00 00    	je     a710 <f0+0x2a40>
    9ebf:	80 f9 01             	cmp    $0x1,%cl
    9ec2:	75 29                	jne    9eed <f0+0x221d>
    9ec4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ec7:	0f b7 c0             	movzwl %ax,%eax
    9eca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ecd:	48 0f af c1          	imul   %rcx,%rax
    9ed1:	48 c1 e8 20          	shr    $0x20,%rax
    9ed5:	48 39 d0             	cmp    %rdx,%rax
    9ed8:	73 13                	jae    9eed <f0+0x221d>
    9eda:	49 01 c5             	add    %rax,%r13
    9edd:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9ee2:	0f 84 82 0a 00 00    	je     a96a <f0+0x2c9a>
    9ee8:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9eed:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9ef4:	33 f3 bf 
    9ef7:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    9efe:	00 
    9eff:	bf 01 00 00 00       	mov    $0x1,%edi
    9f04:	4c 89 b4 24 08 08 00 	mov    %r14,0x808(%rsp)
    9f0b:	00 
    9f0c:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    9f13:	00 
    9f14:	e8 57 b3 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9f19:	48 8b 15 98 6b 01 00 	mov    0x16b98(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9f20:	49 89 c6             	mov    %rax,%r14
    9f23:	48 2b 05 66 6b 01 00 	sub    0x16b66(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9f2a:	48 c1 e2 10          	shl    $0x10,%rdx
    9f2e:	48 39 d0             	cmp    %rdx,%rax
    9f31:	73 59                	jae    9f8c <f0+0x22bc>
    9f33:	48 89 c2             	mov    %rax,%rdx
    9f36:	48 c1 ea 10          	shr    $0x10,%rdx
    9f3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f3e:	48 8b 15 93 6b 01 00 	mov    0x16b93(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9f45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f49:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9f4d:	4d 85 ed             	test   %r13,%r13
    9f50:	74 3a                	je     9f8c <f0+0x22bc>
    9f52:	0f b6 0a             	movzbl (%rdx),%ecx
    9f55:	80 f9 02             	cmp    $0x2,%cl
    9f58:	0f 84 a2 07 00 00    	je     a700 <f0+0x2a30>
    9f5e:	80 f9 01             	cmp    $0x1,%cl
    9f61:	75 29                	jne    9f8c <f0+0x22bc>
    9f63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f66:	0f b7 c0             	movzwl %ax,%eax
    9f69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f6c:	48 0f af c1          	imul   %rcx,%rax
    9f70:	48 c1 e8 20          	shr    $0x20,%rax
    9f74:	48 39 d0             	cmp    %rdx,%rax
    9f77:	73 13                	jae    9f8c <f0+0x22bc>
    9f79:	49 01 c5             	add    %rax,%r13
    9f7c:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9f81:	0f 84 f0 09 00 00    	je     a977 <f0+0x2ca7>
    9f87:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9f8c:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9f93:	00 f0 3f 
    9f96:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    9f9d:	00 
    9f9e:	bf 01 00 00 00       	mov    $0x1,%edi
    9fa3:	4c 89 b4 24 18 08 00 	mov    %r14,0x818(%rsp)
    9faa:	00 
    9fab:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    9fb2:	00 
    9fb3:	e8 b8 b2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    9fb8:	48 8b 15 f9 6a 01 00 	mov    0x16af9(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    9fbf:	49 89 c6             	mov    %rax,%r14
    9fc2:	48 2b 05 c7 6a 01 00 	sub    0x16ac7(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    9fc9:	48 c1 e2 10          	shl    $0x10,%rdx
    9fcd:	48 39 d0             	cmp    %rdx,%rax
    9fd0:	73 59                	jae    a02b <f0+0x235b>
    9fd2:	48 89 c2             	mov    %rax,%rdx
    9fd5:	48 c1 ea 10          	shr    $0x10,%rdx
    9fd9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fdd:	48 8b 15 f4 6a 01 00 	mov    0x16af4(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    9fe4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fe8:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9fec:	4d 85 ed             	test   %r13,%r13
    9fef:	74 3a                	je     a02b <f0+0x235b>
    9ff1:	0f b6 0a             	movzbl (%rdx),%ecx
    9ff4:	80 f9 02             	cmp    $0x2,%cl
    9ff7:	0f 84 33 07 00 00    	je     a730 <f0+0x2a60>
    9ffd:	80 f9 01             	cmp    $0x1,%cl
    a000:	75 29                	jne    a02b <f0+0x235b>
    a002:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a005:	0f b7 c0             	movzwl %ax,%eax
    a008:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a00b:	48 0f af c1          	imul   %rcx,%rax
    a00f:	48 c1 e8 20          	shr    $0x20,%rax
    a013:	48 39 d0             	cmp    %rdx,%rax
    a016:	73 13                	jae    a02b <f0+0x235b>
    a018:	49 01 c5             	add    %rax,%r13
    a01b:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a020:	0f 84 5e 09 00 00    	je     a984 <f0+0x2cb4>
    a026:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a02b:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a032:	33 f3 bf 
    a035:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    a03c:	00 
    a03d:	bf 01 00 00 00       	mov    $0x1,%edi
    a042:	4c 89 b4 24 28 08 00 	mov    %r14,0x828(%rsp)
    a049:	00 
    a04a:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    a051:	00 
    a052:	e8 19 b2 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    a057:	48 8b 15 5a 6a 01 00 	mov    0x16a5a(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a05e:	49 89 c6             	mov    %rax,%r14
    a061:	48 2b 05 28 6a 01 00 	sub    0x16a28(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    a068:	48 c1 e2 10          	shl    $0x10,%rdx
    a06c:	48 39 d0             	cmp    %rdx,%rax
    a06f:	73 59                	jae    a0ca <f0+0x23fa>
    a071:	48 89 c2             	mov    %rax,%rdx
    a074:	48 c1 ea 10          	shr    $0x10,%rdx
    a078:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a07c:	48 8b 15 55 6a 01 00 	mov    0x16a55(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    a083:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a087:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a08b:	4d 85 ed             	test   %r13,%r13
    a08e:	74 3a                	je     a0ca <f0+0x23fa>
    a090:	0f b6 0a             	movzbl (%rdx),%ecx
    a093:	80 f9 02             	cmp    $0x2,%cl
    a096:	0f 84 84 06 00 00    	je     a720 <f0+0x2a50>
    a09c:	80 f9 01             	cmp    $0x1,%cl
    a09f:	75 29                	jne    a0ca <f0+0x23fa>
    a0a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0a4:	0f b7 c0             	movzwl %ax,%eax
    a0a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0aa:	48 0f af c1          	imul   %rcx,%rax
    a0ae:	48 c1 e8 20          	shr    $0x20,%rax
    a0b2:	48 39 d0             	cmp    %rdx,%rax
    a0b5:	73 13                	jae    a0ca <f0+0x23fa>
    a0b7:	49 01 c5             	add    %rax,%r13
    a0ba:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a0bf:	0f 84 cc 08 00 00    	je     a991 <f0+0x2cc1>
    a0c5:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a0ca:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a0d1:	00 f0 3f 
    a0d4:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    a0db:	00 
    a0dc:	bf 01 00 00 00       	mov    $0x1,%edi
    a0e1:	4c 89 b4 24 38 08 00 	mov    %r14,0x838(%rsp)
    a0e8:	00 
    a0e9:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    a0f0:	00 
    a0f1:	e8 7a b1 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    a0f6:	48 8b 15 bb 69 01 00 	mov    0x169bb(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a0fd:	49 89 c6             	mov    %rax,%r14
    a100:	48 2b 05 89 69 01 00 	sub    0x16989(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    a107:	48 c1 e2 10          	shl    $0x10,%rdx
    a10b:	48 39 d0             	cmp    %rdx,%rax
    a10e:	73 59                	jae    a169 <f0+0x2499>
    a110:	48 89 c2             	mov    %rax,%rdx
    a113:	48 c1 ea 10          	shr    $0x10,%rdx
    a117:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a11b:	48 8b 15 b6 69 01 00 	mov    0x169b6(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    a122:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a126:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a12a:	4d 85 ed             	test   %r13,%r13
    a12d:	74 3a                	je     a169 <f0+0x2499>
    a12f:	0f b6 0a             	movzbl (%rdx),%ecx
    a132:	80 f9 02             	cmp    $0x2,%cl
    a135:	0f 84 15 06 00 00    	je     a750 <f0+0x2a80>
    a13b:	80 f9 01             	cmp    $0x1,%cl
    a13e:	75 29                	jne    a169 <f0+0x2499>
    a140:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a143:	0f b7 c0             	movzwl %ax,%eax
    a146:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a149:	48 0f af c1          	imul   %rcx,%rax
    a14d:	48 c1 e8 20          	shr    $0x20,%rax
    a151:	48 39 d0             	cmp    %rdx,%rax
    a154:	73 13                	jae    a169 <f0+0x2499>
    a156:	49 01 c5             	add    %rax,%r13
    a159:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a15e:	0f 84 3a 08 00 00    	je     a99e <f0+0x2cce>
    a164:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a169:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a170:	33 f3 bf 
    a173:	48 8d b4 24 40 08 00 	lea    0x840(%rsp),%rsi
    a17a:	00 
    a17b:	bf 01 00 00 00       	mov    $0x1,%edi
    a180:	4c 89 b4 24 48 08 00 	mov    %r14,0x848(%rsp)
    a187:	00 
    a188:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    a18f:	00 
    a190:	e8 db b0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    a195:	48 8b 15 1c 69 01 00 	mov    0x1691c(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a19c:	49 89 c6             	mov    %rax,%r14
    a19f:	48 2b 05 ea 68 01 00 	sub    0x168ea(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    a1a6:	48 c1 e2 10          	shl    $0x10,%rdx
    a1aa:	48 39 d0             	cmp    %rdx,%rax
    a1ad:	73 59                	jae    a208 <f0+0x2538>
    a1af:	48 89 c2             	mov    %rax,%rdx
    a1b2:	48 c1 ea 10          	shr    $0x10,%rdx
    a1b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1ba:	48 8b 15 17 69 01 00 	mov    0x16917(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    a1c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1c5:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a1c9:	4d 85 ed             	test   %r13,%r13
    a1cc:	74 3a                	je     a208 <f0+0x2538>
    a1ce:	0f b6 0a             	movzbl (%rdx),%ecx
    a1d1:	80 f9 02             	cmp    $0x2,%cl
    a1d4:	0f 84 66 05 00 00    	je     a740 <f0+0x2a70>
    a1da:	80 f9 01             	cmp    $0x1,%cl
    a1dd:	75 29                	jne    a208 <f0+0x2538>
    a1df:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1e2:	0f b7 c0             	movzwl %ax,%eax
    a1e5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1e8:	48 0f af c1          	imul   %rcx,%rax
    a1ec:	48 c1 e8 20          	shr    $0x20,%rax
    a1f0:	48 39 d0             	cmp    %rdx,%rax
    a1f3:	73 13                	jae    a208 <f0+0x2538>
    a1f5:	49 01 c5             	add    %rax,%r13
    a1f8:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a1fd:	0f 84 a8 07 00 00    	je     a9ab <f0+0x2cdb>
    a203:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a208:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a20f:	00 f0 3f 
    a212:	48 8d b4 24 50 08 00 	lea    0x850(%rsp),%rsi
    a219:	00 
    a21a:	bf 01 00 00 00       	mov    $0x1,%edi
    a21f:	4c 89 b4 24 58 08 00 	mov    %r14,0x858(%rsp)
    a226:	00 
    a227:	48 89 84 24 50 08 00 	mov    %rax,0x850(%rsp)
    a22e:	00 
    a22f:	e8 3c b0 ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    a234:	48 8b 15 7d 68 01 00 	mov    0x1687d(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a23b:	49 89 c6             	mov    %rax,%r14
    a23e:	48 2b 05 4b 68 01 00 	sub    0x1684b(%rip),%rax        # 20a90 <fwp_heap+0x13b0>
    a245:	48 c1 e2 10          	shl    $0x10,%rdx
    a249:	48 39 d0             	cmp    %rdx,%rax
    a24c:	73 59                	jae    a2a7 <f0+0x25d7>
    a24e:	48 89 c2             	mov    %rax,%rdx
    a251:	48 c1 ea 10          	shr    $0x10,%rdx
    a255:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a259:	48 8b 15 78 68 01 00 	mov    0x16878(%rip),%rdx        # 20ad8 <fwp_heap+0x13f8>
    a260:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a264:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a268:	4d 85 ed             	test   %r13,%r13
    a26b:	74 3a                	je     a2a7 <f0+0x25d7>
    a26d:	0f b6 0a             	movzbl (%rdx),%ecx
    a270:	80 f9 02             	cmp    $0x2,%cl
    a273:	0f 84 f7 04 00 00    	je     a770 <f0+0x2aa0>
    a279:	80 f9 01             	cmp    $0x1,%cl
    a27c:	75 29                	jne    a2a7 <f0+0x25d7>
    a27e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a281:	0f b7 c0             	movzwl %ax,%eax
    a284:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a287:	48 0f af c1          	imul   %rcx,%rax
    a28b:	48 c1 e8 20          	shr    $0x20,%rax
    a28f:	48 39 d0             	cmp    %rdx,%rax
    a292:	73 13                	jae    a2a7 <f0+0x25d7>
    a294:	49 01 c5             	add    %rax,%r13
    a297:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a29c:	0f 84 16 07 00 00    	je     a9b8 <f0+0x2ce8>
    a2a2:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a2a7:	48 89 ee             	mov    %rbp,%rsi
    a2aa:	bf 01 00 00 00       	mov    $0x1,%edi
    a2af:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a2b6:	33 f3 bf 
    a2b9:	4c 89 b4 24 68 08 00 	mov    %r14,0x868(%rsp)
    a2c0:	00 
    a2c1:	48 89 84 24 60 08 00 	mov    %rax,0x860(%rsp)
    a2c8:	00 
    a2c9:	e8 a2 af ff ff       	call   5270 <fwp_data.part.0.constprop.0>
    a2ce:	48 8b 15 e3 67 01 00 	mov    0x167e3(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a2d5:	48 8b 0d b4 67 01 00 	mov    0x167b4(%rip),%rcx        # 20a90 <fwp_heap+0x13b0>
    a2dc:	49 89 c7             	mov    %rax,%r15
    a2df:	48 89 d6             	mov    %rdx,%rsi
    a2e2:	48 29 c8             	sub    %rcx,%rax
    a2e5:	48 c1 e6 10          	shl    $0x10,%rsi
    a2e9:	48 39 f0             	cmp    %rsi,%rax
    a2ec:	73 67                	jae    a355 <f0+0x2685>
    a2ee:	48 89 c6             	mov    %rax,%rsi
    a2f1:	48 c1 ee 10          	shr    $0x10,%rsi
    a2f5:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a2f9:	48 8b 35 d8 67 01 00 	mov    0x167d8(%rip),%rsi        # 20ad8 <fwp_heap+0x13f8>
    a300:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a304:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    a308:	48 85 ed             	test   %rbp,%rbp
    a30b:	74 48                	je     a355 <f0+0x2685>
    a30d:	0f b6 3e             	movzbl (%rsi),%edi
    a310:	40 80 ff 02          	cmp    $0x2,%dil
    a314:	0f 84 46 04 00 00    	je     a760 <f0+0x2a90>
    a31a:	40 80 ff 01          	cmp    $0x1,%dil
    a31e:	75 35                	jne    a355 <f0+0x2685>
    a320:	8b 7e 18             	mov    0x18(%rsi),%edi
    a323:	0f b7 c0             	movzwl %ax,%eax
    a326:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a329:	48 0f af c7          	imul   %rdi,%rax
    a32d:	48 c1 e8 20          	shr    $0x20,%rax
    a331:	48 39 f0             	cmp    %rsi,%rax
    a334:	73 1f                	jae    a355 <f0+0x2685>
    a336:	48 01 c5             	add    %rax,%rbp
    a339:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a33d:	0f 84 bb 04 00 00    	je     a7fe <f0+0x2b2e>
    a343:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a347:	48 8b 0d 42 67 01 00 	mov    0x16742(%rip),%rcx        # 20a90 <fwp_heap+0x13b0>
    a34e:	48 8b 15 63 67 01 00 	mov    0x16763(%rip),%rdx        # 20ab8 <fwp_heap+0x13d8>
    a355:	4d 89 e5             	mov    %r12,%r13
    a358:	e9 91 01 00 00       	jmp    a4ee <f0+0x281e>
    a35d:	0f 1f 00             	nopl   (%rax)
    a360:	80 f9 01             	cmp    $0x1,%cl
    a363:	75 2d                	jne    a392 <f0+0x26c2>
    a365:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a368:	0f b7 c0             	movzwl %ax,%eax
    a36b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a36e:	48 0f af c1          	imul   %rcx,%rax
    a372:	48 c1 e8 20          	shr    $0x20,%rax
    a376:	48 39 d0             	cmp    %rdx,%rax
    a379:	73 17                	jae    a392 <f0+0x26c2>
    a37b:	48 01 c7             	add    %rax,%rdi
    a37e:	0f b6 07             	movzbl (%rdi),%eax
    a381:	84 c0                	test   %al,%al
    a383:	74 0d                	je     a392 <f0+0x26c2>
    a385:	3c fd                	cmp    $0xfd,%al
    a387:	0f 87 33 02 00 00    	ja     a5c0 <f0+0x28f0>
    a38d:	83 c0 01             	add    $0x1,%eax
    a390:	88 07                	mov    %al,(%rdi)
    a392:	4c 89 ff             	mov    %r15,%rdi
    a395:	e8 d6 bd ff ff       	call   6170 <fwp_loop_fields68.constprop.0>
    a39a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a39f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a3a3:	b9 01 00 00 00       	mov    $0x1,%ecx
    a3a8:	48 89 c6             	mov    %rax,%rsi
    a3ab:	48 8d 15 ee 47 00 00 	lea    0x47ee(%rip),%rdx        # eba0 <d0>
    a3b2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a3b7:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a3be:	00 00 
    a3c0:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a3c5:	e8 c6 c8 ff ff       	call   6c90 <fwp_write>
    a3ca:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a3cf:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a3d4:	48 8d 05 53 1c 00 00 	lea    0x1c53(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    a3db:	48 85 c9             	test   %rcx,%rcx
    a3de:	48 0f 44 c8          	cmove  %rax,%rcx
    a3e2:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a3e6:	0f 87 d9 05 00 00    	ja     a9c5 <f0+0x2cf5>
    a3ec:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a3f0:	be 01 00 00 00       	mov    $0x1,%esi
    a3f5:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a3fa:	e8 51 ad ff ff       	call   5150 <fwp_heap_alloc>
    a3ff:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a404:	4c 89 f2             	mov    %r14,%rdx
    a407:	4c 89 30             	mov    %r14,(%rax)
    a40a:	48 89 c5             	mov    %rax,%rbp
    a40d:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a411:	48 89 3c 24          	mov    %rdi,(%rsp)
    a415:	e8 56 81 ff ff       	call   2570 <memcpy@plt>
    a41a:	42 c6 44 35 08 00    	movb   $0x0,0x8(%rbp,%r14,1)
    a420:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a425:	e8 76 7f ff ff       	call   23a0 <free@plt>
    a42a:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a431:	48 89 e8             	mov    %rbp,%rax
    a434:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a43b:	48 c1 e2 10          	shl    $0x10,%rdx
    a43f:	48 39 d0             	cmp    %rdx,%rax
    a442:	73 57                	jae    a49b <f0+0x27cb>
    a444:	48 89 c2             	mov    %rax,%rdx
    a447:	48 c1 ea 10          	shr    $0x10,%rdx
    a44b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a44f:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a456:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a45a:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a45e:	48 85 d2             	test   %rdx,%rdx
    a461:	74 38                	je     a49b <f0+0x27cb>
    a463:	0f b6 31             	movzbl (%rcx),%esi
    a466:	40 80 fe 02          	cmp    $0x2,%sil
    a46a:	0f 84 d0 00 00 00    	je     a540 <f0+0x2870>
    a470:	40 80 fe 01          	cmp    $0x1,%sil
    a474:	75 25                	jne    a49b <f0+0x27cb>
    a476:	8b 71 18             	mov    0x18(%rcx),%esi
    a479:	0f b7 c0             	movzwl %ax,%eax
    a47c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a47f:	48 0f af c6          	imul   %rsi,%rax
    a483:	48 c1 e8 20          	shr    $0x20,%rax
    a487:	48 39 c8             	cmp    %rcx,%rax
    a48a:	73 0f                	jae    a49b <f0+0x27cb>
    a48c:	48 01 c2             	add    %rax,%rdx
    a48f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a492:	0f 84 08 01 00 00    	je     a5a0 <f0+0x28d0>
    a498:	c6 02 01             	movb   $0x1,(%rdx)
    a49b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a4a0:	e8 4b b6 ff ff       	call   5af0 <fwp_drop0>
    a4a5:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    a4a9:	48 8b 3c 24          	mov    (%rsp),%rdi
    a4ad:	be 01 00 00 00       	mov    $0x1,%esi
    a4b2:	48 8b 0d 7f 6e 01 00 	mov    0x16e7f(%rip),%rcx        # 21338 <fwp_prog_out>
    a4b9:	e8 82 81 ff ff       	call   2640 <fwrite@plt>
    a4be:	48 8b 35 73 6e 01 00 	mov    0x16e73(%rip),%rsi        # 21338 <fwp_prog_out>
    a4c5:	bf 0a 00 00 00       	mov    $0xa,%edi
    a4ca:	e8 f1 7f ff ff       	call   24c0 <fputc@plt>
    a4cf:	48 89 ef             	mov    %rbp,%rdi
    a4d2:	e8 19 b0 ff ff       	call   54f0 <fwp_drop4>
    a4d7:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a4db:	4d 85 ed             	test   %r13,%r13
    a4de:	74 70                	je     a550 <f0+0x2880>
    a4e0:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a4e7:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a4ee:	4c 89 f8             	mov    %r15,%rax
    a4f1:	48 c1 e2 10          	shl    $0x10,%rdx
    a4f5:	48 29 c8             	sub    %rcx,%rax
    a4f8:	48 39 d0             	cmp    %rdx,%rax
    a4fb:	0f 83 91 fe ff ff    	jae    a392 <f0+0x26c2>
    a501:	48 89 c2             	mov    %rax,%rdx
    a504:	48 c1 ea 10          	shr    $0x10,%rdx
    a508:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a50c:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a513:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a517:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a51b:	48 85 ff             	test   %rdi,%rdi
    a51e:	0f 84 6e fe ff ff    	je     a392 <f0+0x26c2>
    a524:	0f b6 0a             	movzbl (%rdx),%ecx
    a527:	80 f9 02             	cmp    $0x2,%cl
    a52a:	0f 85 30 fe ff ff    	jne    a360 <f0+0x2690>
    a530:	66 85 c0             	test   %ax,%ax
    a533:	0f 85 59 fe ff ff    	jne    a392 <f0+0x26c2>
    a539:	e9 40 fe ff ff       	jmp    a37e <f0+0x26ae>
    a53e:	66 90                	xchg   %ax,%ax
    a540:	66 85 c0             	test   %ax,%ax
    a543:	0f 85 52 ff ff ff    	jne    a49b <f0+0x27cb>
    a549:	e9 41 ff ff ff       	jmp    a48f <f0+0x27bf>
    a54e:	66 90                	xchg   %ax,%ax
    a550:	4c 89 ff             	mov    %r15,%rdi
    a553:	e8 98 b5 ff ff       	call   5af0 <fwp_drop0>
    a558:	4c 89 e7             	mov    %r12,%rdi
    a55b:	e8 90 b5 ff ff       	call   5af0 <fwp_drop0>
    a560:	48 8b 84 24 78 08 00 	mov    0x878(%rsp),%rax
    a567:	00 
    a568:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a56f:	00 00 
    a571:	0f 85 5a 04 00 00    	jne    a9d1 <f0+0x2d01>
    a577:	48 81 c4 88 08 00 00 	add    $0x888,%rsp
    a57e:	31 c0                	xor    %eax,%eax
    a580:	5b                   	pop    %rbx
    a581:	5d                   	pop    %rbp
    a582:	41 5c                	pop    %r12
    a584:	41 5d                	pop    %r13
    a586:	41 5e                	pop    %r14
    a588:	41 5f                	pop    %r15
    a58a:	c3                   	ret
    a58b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a590:	4c 89 f7             	mov    %r14,%rdi
    a593:	e8 b8 99 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a598:	e9 f3 d7 ff ff       	jmp    7d90 <f0+0xc0>
    a59d:	0f 1f 00             	nopl   (%rax)
    a5a0:	48 89 d7             	mov    %rdx,%rdi
    a5a3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a5a8:	e8 a3 99 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a5ad:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a5b2:	e9 e1 fe ff ff       	jmp    a498 <f0+0x27c8>
    a5b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a5be:	00 00 
    a5c0:	e8 6b 98 ff ff       	call   3e30 <fwp_rc_wide_dup>
    a5c5:	e9 c8 fd ff ff       	jmp    a392 <f0+0x26c2>
    a5ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5d0:	66 85 c0             	test   %ax,%ax
    a5d3:	0f 85 17 da ff ff    	jne    7ff0 <f0+0x320>
    a5d9:	e9 02 da ff ff       	jmp    7fe0 <f0+0x310>
    a5de:	66 90                	xchg   %ax,%ax
    a5e0:	66 85 c0             	test   %ax,%ax
    a5e3:	0f 85 68 d9 ff ff    	jne    7f51 <f0+0x281>
    a5e9:	e9 53 d9 ff ff       	jmp    7f41 <f0+0x271>
    a5ee:	66 90                	xchg   %ax,%ax
    a5f0:	66 85 c0             	test   %ax,%ax
    a5f3:	0f 85 c2 d8 ff ff    	jne    7ebb <f0+0x1eb>
    a5f9:	e9 ad d8 ff ff       	jmp    7eab <f0+0x1db>
    a5fe:	66 90                	xchg   %ax,%ax
    a600:	66 85 c0             	test   %ax,%ax
    a603:	0f 85 93 ef ff ff    	jne    959c <f0+0x18cc>
    a609:	e9 7e ef ff ff       	jmp    958c <f0+0x18bc>
    a60e:	66 90                	xchg   %ax,%ax
    a610:	66 85 c0             	test   %ax,%ax
    a613:	0f 85 e4 ee ff ff    	jne    94fd <f0+0x182d>
    a619:	e9 cf ee ff ff       	jmp    94ed <f0+0x181d>
    a61e:	66 90                	xchg   %ax,%ax
    a620:	66 85 c0             	test   %ax,%ax
    a623:	0f 85 b1 f0 ff ff    	jne    96da <f0+0x1a0a>
    a629:	e9 9c f0 ff ff       	jmp    96ca <f0+0x19fa>
    a62e:	66 90                	xchg   %ax,%ax
    a630:	66 85 c0             	test   %ax,%ax
    a633:	0f 85 02 f0 ff ff    	jne    963b <f0+0x196b>
    a639:	e9 ed ef ff ff       	jmp    962b <f0+0x195b>
    a63e:	66 90                	xchg   %ax,%ax
    a640:	66 85 c0             	test   %ax,%ax
    a643:	0f 85 cf f1 ff ff    	jne    9818 <f0+0x1b48>
    a649:	e9 ba f1 ff ff       	jmp    9808 <f0+0x1b38>
    a64e:	66 90                	xchg   %ax,%ax
    a650:	66 85 c0             	test   %ax,%ax
    a653:	0f 85 20 f1 ff ff    	jne    9779 <f0+0x1aa9>
    a659:	e9 0b f1 ff ff       	jmp    9769 <f0+0x1a99>
    a65e:	66 90                	xchg   %ax,%ax
    a660:	66 85 c0             	test   %ax,%ax
    a663:	0f 85 ed f2 ff ff    	jne    9956 <f0+0x1c86>
    a669:	e9 d8 f2 ff ff       	jmp    9946 <f0+0x1c76>
    a66e:	66 90                	xchg   %ax,%ax
    a670:	66 85 c0             	test   %ax,%ax
    a673:	0f 85 3e f2 ff ff    	jne    98b7 <f0+0x1be7>
    a679:	e9 29 f2 ff ff       	jmp    98a7 <f0+0x1bd7>
    a67e:	66 90                	xchg   %ax,%ax
    a680:	66 85 c0             	test   %ax,%ax
    a683:	0f 85 a5 da ff ff    	jne    812e <f0+0x45e>
    a689:	e9 90 da ff ff       	jmp    811e <f0+0x44e>
    a68e:	66 90                	xchg   %ax,%ax
    a690:	66 85 c0             	test   %ax,%ax
    a693:	0f 85 f6 d9 ff ff    	jne    808f <f0+0x3bf>
    a699:	e9 e1 d9 ff ff       	jmp    807f <f0+0x3af>
    a69e:	66 90                	xchg   %ax,%ax
    a6a0:	66 85 c0             	test   %ax,%ax
    a6a3:	0f 85 39 eb ff ff    	jne    91e2 <f0+0x1512>
    a6a9:	e9 24 eb ff ff       	jmp    91d2 <f0+0x1502>
    a6ae:	66 90                	xchg   %ax,%ax
    a6b0:	66 85 c0             	test   %ax,%ax
    a6b3:	0f 85 8a ea ff ff    	jne    9143 <f0+0x1473>
    a6b9:	e9 75 ea ff ff       	jmp    9133 <f0+0x1463>
    a6be:	66 90                	xchg   %ax,%ax
    a6c0:	66 85 c0             	test   %ax,%ax
    a6c3:	0f 85 57 ec ff ff    	jne    9320 <f0+0x1650>
    a6c9:	e9 42 ec ff ff       	jmp    9310 <f0+0x1640>
    a6ce:	66 90                	xchg   %ax,%ax
    a6d0:	66 85 c0             	test   %ax,%ax
    a6d3:	0f 85 a8 eb ff ff    	jne    9281 <f0+0x15b1>
    a6d9:	e9 93 eb ff ff       	jmp    9271 <f0+0x15a1>
    a6de:	66 90                	xchg   %ax,%ax
    a6e0:	66 85 c0             	test   %ax,%ax
    a6e3:	0f 85 75 ed ff ff    	jne    945e <f0+0x178e>
    a6e9:	e9 60 ed ff ff       	jmp    944e <f0+0x177e>
    a6ee:	66 90                	xchg   %ax,%ax
    a6f0:	66 85 c0             	test   %ax,%ax
    a6f3:	0f 85 c6 ec ff ff    	jne    93bf <f0+0x16ef>
    a6f9:	e9 b1 ec ff ff       	jmp    93af <f0+0x16df>
    a6fe:	66 90                	xchg   %ax,%ax
    a700:	66 85 c0             	test   %ax,%ax
    a703:	0f 85 83 f8 ff ff    	jne    9f8c <f0+0x22bc>
    a709:	e9 6e f8 ff ff       	jmp    9f7c <f0+0x22ac>
    a70e:	66 90                	xchg   %ax,%ax
    a710:	66 85 c0             	test   %ax,%ax
    a713:	0f 85 d4 f7 ff ff    	jne    9eed <f0+0x221d>
    a719:	e9 bf f7 ff ff       	jmp    9edd <f0+0x220d>
    a71e:	66 90                	xchg   %ax,%ax
    a720:	66 85 c0             	test   %ax,%ax
    a723:	0f 85 a1 f9 ff ff    	jne    a0ca <f0+0x23fa>
    a729:	e9 8c f9 ff ff       	jmp    a0ba <f0+0x23ea>
    a72e:	66 90                	xchg   %ax,%ax
    a730:	66 85 c0             	test   %ax,%ax
    a733:	0f 85 f2 f8 ff ff    	jne    a02b <f0+0x235b>
    a739:	e9 dd f8 ff ff       	jmp    a01b <f0+0x234b>
    a73e:	66 90                	xchg   %ax,%ax
    a740:	66 85 c0             	test   %ax,%ax
    a743:	0f 85 bf fa ff ff    	jne    a208 <f0+0x2538>
    a749:	e9 aa fa ff ff       	jmp    a1f8 <f0+0x2528>
    a74e:	66 90                	xchg   %ax,%ax
    a750:	66 85 c0             	test   %ax,%ax
    a753:	0f 85 10 fa ff ff    	jne    a169 <f0+0x2499>
    a759:	e9 fb f9 ff ff       	jmp    a159 <f0+0x2489>
    a75e:	66 90                	xchg   %ax,%ax
    a760:	66 85 c0             	test   %ax,%ax
    a763:	0f 85 ec fb ff ff    	jne    a355 <f0+0x2685>
    a769:	e9 cb fb ff ff       	jmp    a339 <f0+0x2669>
    a76e:	66 90                	xchg   %ax,%ax
    a770:	66 85 c0             	test   %ax,%ax
    a773:	0f 85 2e fb ff ff    	jne    a2a7 <f0+0x25d7>
    a779:	e9 19 fb ff ff       	jmp    a297 <f0+0x25c7>
    a77e:	66 90                	xchg   %ax,%ax
    a780:	66 85 c0             	test   %ax,%ax
    a783:	0f 85 0b f3 ff ff    	jne    9a94 <f0+0x1dc4>
    a789:	e9 f6 f2 ff ff       	jmp    9a84 <f0+0x1db4>
    a78e:	66 90                	xchg   %ax,%ax
    a790:	66 85 c0             	test   %ax,%ax
    a793:	0f 85 5c f2 ff ff    	jne    99f5 <f0+0x1d25>
    a799:	e9 47 f2 ff ff       	jmp    99e5 <f0+0x1d15>
    a79e:	66 90                	xchg   %ax,%ax
    a7a0:	66 85 c0             	test   %ax,%ax
    a7a3:	0f 85 29 f4 ff ff    	jne    9bd2 <f0+0x1f02>
    a7a9:	e9 14 f4 ff ff       	jmp    9bc2 <f0+0x1ef2>
    a7ae:	66 90                	xchg   %ax,%ax
    a7b0:	66 85 c0             	test   %ax,%ax
    a7b3:	0f 85 7a f3 ff ff    	jne    9b33 <f0+0x1e63>
    a7b9:	e9 65 f3 ff ff       	jmp    9b23 <f0+0x1e53>
    a7be:	66 90                	xchg   %ax,%ax
    a7c0:	66 85 c0             	test   %ax,%ax
    a7c3:	0f 85 47 f5 ff ff    	jne    9d10 <f0+0x2040>
    a7c9:	e9 32 f5 ff ff       	jmp    9d00 <f0+0x2030>
    a7ce:	66 90                	xchg   %ax,%ax
    a7d0:	66 85 c0             	test   %ax,%ax
    a7d3:	0f 85 98 f4 ff ff    	jne    9c71 <f0+0x1fa1>
    a7d9:	e9 83 f4 ff ff       	jmp    9c61 <f0+0x1f91>
    a7de:	66 90                	xchg   %ax,%ax
    a7e0:	66 85 c0             	test   %ax,%ax
    a7e3:	0f 85 65 f6 ff ff    	jne    9e4e <f0+0x217e>
    a7e9:	e9 50 f6 ff ff       	jmp    9e3e <f0+0x216e>
    a7ee:	66 90                	xchg   %ax,%ax
    a7f0:	66 85 c0             	test   %ax,%ax
    a7f3:	0f 85 b6 f5 ff ff    	jne    9daf <f0+0x20df>
    a7f9:	e9 a1 f5 ff ff       	jmp    9d9f <f0+0x20cf>
    a7fe:	48 89 ef             	mov    %rbp,%rdi
    a801:	e8 4a 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a806:	e9 38 fb ff ff       	jmp    a343 <f0+0x2673>
    a80b:	4c 89 ef             	mov    %r13,%rdi
    a80e:	e8 3d 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a813:	e9 9e d6 ff ff       	jmp    7eb6 <f0+0x1e6>
    a818:	4c 89 ef             	mov    %r13,%rdi
    a81b:	e8 30 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a820:	e9 27 d7 ff ff       	jmp    7f4c <f0+0x27c>
    a825:	4c 89 ef             	mov    %r13,%rdi
    a828:	e8 23 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a82d:	e9 b9 d7 ff ff       	jmp    7feb <f0+0x31b>
    a832:	4c 89 ef             	mov    %r13,%rdi
    a835:	e8 16 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a83a:	e9 4b d8 ff ff       	jmp    808a <f0+0x3ba>
    a83f:	4c 89 ef             	mov    %r13,%rdi
    a842:	e8 09 97 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a847:	e9 dd d8 ff ff       	jmp    8129 <f0+0x459>
    a84c:	4c 89 ef             	mov    %r13,%rdi
    a84f:	e8 fc 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a854:	e9 e5 e8 ff ff       	jmp    913e <f0+0x146e>
    a859:	4c 89 ef             	mov    %r13,%rdi
    a85c:	e8 ef 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a861:	e9 77 e9 ff ff       	jmp    91dd <f0+0x150d>
    a866:	4c 89 ef             	mov    %r13,%rdi
    a869:	e8 e2 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a86e:	e9 09 ea ff ff       	jmp    927c <f0+0x15ac>
    a873:	4c 89 ef             	mov    %r13,%rdi
    a876:	e8 d5 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a87b:	e9 9b ea ff ff       	jmp    931b <f0+0x164b>
    a880:	4c 89 ef             	mov    %r13,%rdi
    a883:	e8 c8 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a888:	e9 2d eb ff ff       	jmp    93ba <f0+0x16ea>
    a88d:	4c 89 ef             	mov    %r13,%rdi
    a890:	e8 bb 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a895:	e9 bf eb ff ff       	jmp    9459 <f0+0x1789>
    a89a:	4c 89 ef             	mov    %r13,%rdi
    a89d:	e8 ae 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8a2:	e9 51 ec ff ff       	jmp    94f8 <f0+0x1828>
    a8a7:	4c 89 ef             	mov    %r13,%rdi
    a8aa:	e8 a1 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8af:	e9 e3 ec ff ff       	jmp    9597 <f0+0x18c7>
    a8b4:	4c 89 ef             	mov    %r13,%rdi
    a8b7:	e8 94 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8bc:	e9 75 ed ff ff       	jmp    9636 <f0+0x1966>
    a8c1:	4c 89 ef             	mov    %r13,%rdi
    a8c4:	e8 87 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8c9:	e9 07 ee ff ff       	jmp    96d5 <f0+0x1a05>
    a8ce:	4c 89 ef             	mov    %r13,%rdi
    a8d1:	e8 7a 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8d6:	e9 99 ee ff ff       	jmp    9774 <f0+0x1aa4>
    a8db:	4c 89 ef             	mov    %r13,%rdi
    a8de:	e8 6d 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8e3:	e9 2b ef ff ff       	jmp    9813 <f0+0x1b43>
    a8e8:	4c 89 ef             	mov    %r13,%rdi
    a8eb:	e8 60 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8f0:	e9 bd ef ff ff       	jmp    98b2 <f0+0x1be2>
    a8f5:	4c 89 ef             	mov    %r13,%rdi
    a8f8:	e8 53 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a8fd:	e9 4f f0 ff ff       	jmp    9951 <f0+0x1c81>
    a902:	4c 89 ef             	mov    %r13,%rdi
    a905:	e8 46 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a90a:	e9 e1 f0 ff ff       	jmp    99f0 <f0+0x1d20>
    a90f:	4c 89 ef             	mov    %r13,%rdi
    a912:	e8 39 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a917:	e9 73 f1 ff ff       	jmp    9a8f <f0+0x1dbf>
    a91c:	4c 89 ef             	mov    %r13,%rdi
    a91f:	e8 2c 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a924:	e9 05 f2 ff ff       	jmp    9b2e <f0+0x1e5e>
    a929:	4c 89 ef             	mov    %r13,%rdi
    a92c:	e8 1f 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a931:	e9 97 f2 ff ff       	jmp    9bcd <f0+0x1efd>
    a936:	4c 89 ef             	mov    %r13,%rdi
    a939:	e8 12 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a93e:	e9 29 f3 ff ff       	jmp    9c6c <f0+0x1f9c>
    a943:	4c 89 ef             	mov    %r13,%rdi
    a946:	e8 05 96 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a94b:	e9 bb f3 ff ff       	jmp    9d0b <f0+0x203b>
    a950:	4c 89 ef             	mov    %r13,%rdi
    a953:	e8 f8 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a958:	e9 4d f4 ff ff       	jmp    9daa <f0+0x20da>
    a95d:	4c 89 ef             	mov    %r13,%rdi
    a960:	e8 eb 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a965:	e9 df f4 ff ff       	jmp    9e49 <f0+0x2179>
    a96a:	4c 89 ef             	mov    %r13,%rdi
    a96d:	e8 de 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a972:	e9 71 f5 ff ff       	jmp    9ee8 <f0+0x2218>
    a977:	4c 89 ef             	mov    %r13,%rdi
    a97a:	e8 d1 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a97f:	e9 03 f6 ff ff       	jmp    9f87 <f0+0x22b7>
    a984:	4c 89 ef             	mov    %r13,%rdi
    a987:	e8 c4 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a98c:	e9 95 f6 ff ff       	jmp    a026 <f0+0x2356>
    a991:	4c 89 ef             	mov    %r13,%rdi
    a994:	e8 b7 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a999:	e9 27 f7 ff ff       	jmp    a0c5 <f0+0x23f5>
    a99e:	4c 89 ef             	mov    %r13,%rdi
    a9a1:	e8 aa 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a9a6:	e9 b9 f7 ff ff       	jmp    a164 <f0+0x2494>
    a9ab:	4c 89 ef             	mov    %r13,%rdi
    a9ae:	e8 9d 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a9b3:	e9 4b f8 ff ff       	jmp    a203 <f0+0x2533>
    a9b8:	4c 89 ef             	mov    %r13,%rdi
    a9bb:	e8 90 95 ff ff       	call   3f50 <fwp_rc_forget_slot>
    a9c0:	e9 dd f8 ff ff       	jmp    a2a2 <f0+0x25d2>
    a9c5:	48 8d 3d 8f 17 00 00 	lea    0x178f(%rip),%rdi        # c15b <_IO_stdin_used+0x15b>
    a9cc:	e8 4f 87 ff ff       	call   3120 <fwp_trap>
    a9d1:	e8 6a 7a ff ff       	call   2440 <__stack_chk_fail@plt>
    a9d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9dd:	00 00 00 

000000000000a9e0 <fwp_main_thread>:
    a9e0:	f3 0f 1e fa          	endbr64
    a9e4:	41 54                	push   %r12
    a9e6:	55                   	push   %rbp
    a9e7:	53                   	push   %rbx
    a9e8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    a9ef:	8b 0d 8f 60 01 00    	mov    0x1608f(%rip),%ecx        # 20a84 <fwp_heap+0x13a4>
    a9f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a9fc:	00 00 
    a9fe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    aa05:	00 
    aa06:	31 c0                	xor    %eax,%eax
    aa08:	85 c9                	test   %ecx,%ecx
    aa0a:	0f 84 68 06 00 00    	je     b078 <fwp_main_thread+0x698>
    aa10:	8b 15 72 60 01 00    	mov    0x16072(%rip),%edx        # 20a88 <fwp_heap+0x13a8>
    aa16:	85 d2                	test   %edx,%edx
    aa18:	0f 85 42 06 00 00    	jne    b060 <fwp_main_thread+0x680>
    aa1e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    aa23:	31 f6                	xor    %esi,%esi
    aa25:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    aa2a:	48 c7 05 53 46 01 00 	movq   $0x40000000,0x14653(%rip)        # 1f088 <fwp_main_stack_size>
    aa31:	00 00 00 40 
    aa35:	48 89 05 54 46 01 00 	mov    %rax,0x14654(%rip)        # 1f090 <fwp_main_stack_top>
    aa3c:	48 8d 05 3d 46 00 00 	lea    0x463d(%rip),%rax        # f080 <alt.4>
    aa43:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    aa48:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    aa4f:	01 00 
    aa51:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    aa58:	00 
    aa59:	e8 22 7c ff ff       	call   2680 <sigaltstack@plt>
    aa5e:	85 c0                	test   %eax,%eax
    aa60:	0f 85 4a 06 00 00    	jne    b0b0 <fwp_main_thread+0x6d0>
    aa66:	31 c0                	xor    %eax,%eax
    aa68:	b9 12 00 00 00       	mov    $0x12,%ecx
    aa6d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    aa72:	f3 48 ab             	rep stos %rax,(%rdi)
    aa75:	48 8d 05 34 82 ff ff 	lea    -0x7dcc(%rip),%rax        # 2cb0 <fwp_segv>
    aa7c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    aa81:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    aa88:	04 00 00 08 
    aa8c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    aa91:	e8 ba 7a ff ff       	call   2550 <sigemptyset@plt>
    aa96:	85 c0                	test   %eax,%eax
    aa98:	0f 85 12 06 00 00    	jne    b0b0 <fwp_main_thread+0x6d0>
    aa9e:	31 d2                	xor    %edx,%edx
    aaa0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    aaa5:	bf 0b 00 00 00       	mov    $0xb,%edi
    aaaa:	e8 31 79 ff ff       	call   23e0 <sigaction@plt>
    aaaf:	85 c0                	test   %eax,%eax
    aab1:	0f 85 f9 05 00 00    	jne    b0b0 <fwp_main_thread+0x6d0>
    aab7:	31 d2                	xor    %edx,%edx
    aab9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    aabe:	bf 07 00 00 00       	mov    $0x7,%edi
    aac3:	e8 18 79 ff ff       	call   23e0 <sigaction@plt>
    aac8:	85 c0                	test   %eax,%eax
    aaca:	0f 85 e0 05 00 00    	jne    b0b0 <fwp_main_thread+0x6d0>
    aad0:	8b 05 92 45 00 00    	mov    0x4592(%rip),%eax        # f068 <st.2>
    aad6:	85 c0                	test   %eax,%eax
    aad8:	0f 84 62 05 00 00    	je     b040 <fwp_main_thread+0x660>
    aade:	48 8b 2d db 4b 01 00 	mov    0x14bdb(%rip),%rbp        # 1f6c0 <fwp_cur>
    aae5:	48 85 ed             	test   %rbp,%rbp
    aae8:	0f 84 72 03 00 00    	je     ae60 <fwp_main_thread+0x480>
    aaee:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    aaf3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    aaf7:	48 89 eb             	mov    %rbp,%rbx
    aafa:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    aaff:	0f 84 41 01 00 00    	je     ac46 <fwp_main_thread+0x266>
    ab05:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ab0a:	0f 84 80 02 00 00    	je     ad90 <fwp_main_thread+0x3b0>
    ab10:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ab14:	0f 84 66 02 00 00    	je     ad80 <fwp_main_thread+0x3a0>
    ab1a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ab1e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ab22:	0f 85 e8 02 00 00    	jne    ae10 <fwp_main_thread+0x430>
    ab28:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ab2c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ab33:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ab37:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ab3e:	00 00 00 00 
    ab42:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ab49:	48 85 d2             	test   %rdx,%rdx
    ab4c:	74 07                	je     ab55 <fwp_main_thread+0x175>
    ab4e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ab55:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ab59:	48 85 c0             	test   %rax,%rax
    ab5c:	74 34                	je     ab92 <fwp_main_thread+0x1b2>
    ab5e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ab62:	48 8b 05 2f 4b 01 00 	mov    0x14b2f(%rip),%rax        # 1f698 <fwp_timers>
    ab69:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ab6d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ab74:	00 00 00 00 
    ab78:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ab7f:	48 85 c0             	test   %rax,%rax
    ab82:	74 07                	je     ab8b <fwp_main_thread+0x1ab>
    ab84:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ab8b:	48 89 1d 06 4b 01 00 	mov    %rbx,0x14b06(%rip)        # 1f698 <fwp_timers>
    ab92:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ab96:	e8 15 a0 ff ff       	call   4bb0 <fwp_block>
    ab9b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    aba2:	48 85 c9             	test   %rcx,%rcx
    aba5:	74 47                	je     abee <fwp_main_thread+0x20e>
    aba7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    abae:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    abb5:	48 85 d2             	test   %rdx,%rdx
    abb8:	0f 84 92 02 00 00    	je     ae50 <fwp_main_thread+0x470>
    abbe:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    abc5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    abcc:	48 85 c0             	test   %rax,%rax
    abcf:	74 07                	je     abd8 <fwp_main_thread+0x1f8>
    abd1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    abd8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    abdf:	00 00 00 00 
    abe3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    abe7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    abee:	48 8b 0d cb 4a 01 00 	mov    0x14acb(%rip),%rcx        # 1f6c0 <fwp_cur>
    abf5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    abf9:	0f 84 01 02 00 00    	je     ae00 <fwp_main_thread+0x420>
    abff:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ac06:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ac0d:	48 85 d2             	test   %rdx,%rdx
    ac10:	0f 84 fa 03 00 00    	je     b010 <fwp_main_thread+0x630>
    ac16:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ac1d:	48 85 c0             	test   %rax,%rax
    ac20:	74 07                	je     ac29 <fwp_main_thread+0x249>
    ac22:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ac29:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ac2d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ac31:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    ac38:	48 89 cb             	mov    %rcx,%rbx
    ac3b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ac40:	0f 85 bf fe ff ff    	jne    ab05 <fwp_main_thread+0x125>
    ac46:	48 83 3d 02 67 01 00 	cmpq   $0x0,0x16702(%rip)        # 21350 <fwp_state_len>
    ac4d:	00 
    ac4e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    ac52:	0f 84 ba 00 00 00    	je     ad12 <fwp_main_thread+0x332>
    ac58:	48 39 1d 59 4a 01 00 	cmp    %rbx,0x14a59(%rip)        # 1f6b8 <fwp_root>
    ac5f:	c7 05 17 44 01 00 00 	movl   $0x0,0x14417(%rip)        # 1f080 <fwp_exit_code>
    ac66:	00 00 00 
    ac69:	0f 85 5f 04 00 00    	jne    b0ce <fwp_main_thread+0x6ee>
    ac6f:	48 85 db             	test   %rbx,%rbx
    ac72:	0f 84 0e 02 00 00    	je     ae86 <fwp_main_thread+0x4a6>
    ac78:	48 8b 15 09 4a 01 00 	mov    0x14a09(%rip),%rdx        # 1f688 <fwp_tasks_active>
    ac7f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    ac83:	48 85 d2             	test   %rdx,%rdx
    ac86:	0f 84 fa 01 00 00    	je     ae86 <fwp_main_thread+0x4a6>
    ac8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac90:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    ac94:	75 08                	jne    ac9e <fwp_main_thread+0x2be>
    ac96:	48 89 d7             	mov    %rdx,%rdi
    ac99:	e8 92 83 ff ff       	call   3030 <fwp_cancel_tree.part.0>
    ac9e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    aca5:	48 85 d2             	test   %rdx,%rdx
    aca8:	75 e6                	jne    ac90 <fwp_main_thread+0x2b0>
    acaa:	eb 31                	jmp    acdd <fwp_main_thread+0x2fd>
    acac:	0f 1f 40 00          	nopl   0x0(%rax)
    acb0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    acb7:	48 89 1d e2 49 01 00 	mov    %rbx,0x149e2(%rip)        # 1f6a0 <fwp_ready_tail>
    acbe:	e8 ed 9e ff ff       	call   4bb0 <fwp_block>
    acc3:	e8 d8 9c ff ff       	call   49a0 <fwp_free_zombie>
    acc8:	48 83 3d b8 49 01 00 	cmpq   $0x0,0x149b8(%rip)        # 1f688 <fwp_tasks_active>
    accf:	00 
    acd0:	0f 84 b0 01 00 00    	je     ae86 <fwp_main_thread+0x4a6>
    acd6:	48 8b 1d db 49 01 00 	mov    0x149db(%rip),%rbx        # 1f6b8 <fwp_root>
    acdd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ace1:	75 db                	jne    acbe <fwp_main_thread+0x2de>
    ace3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ace7:	75 d5                	jne    acbe <fwp_main_thread+0x2de>
    ace9:	48 8b 05 b0 49 01 00 	mov    0x149b0(%rip),%rax        # 1f6a0 <fwp_ready_tail>
    acf0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    acf4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    acfb:	00 00 00 00 
    acff:	48 85 c0             	test   %rax,%rax
    ad02:	75 ac                	jne    acb0 <fwp_main_thread+0x2d0>
    ad04:	48 89 1d 9d 49 01 00 	mov    %rbx,0x1499d(%rip)        # 1f6a8 <fwp_ready_head>
    ad0b:	eb aa                	jmp    acb7 <fwp_main_thread+0x2d7>
    ad0d:	0f 1f 00             	nopl   (%rax)
    ad10:	31 db                	xor    %ebx,%ebx
    ad12:	48 83 3d 26 66 01 00 	cmpq   $0x0,0x16626(%rip)        # 21340 <fwp_state_owners>
    ad19:	00 
    ad1a:	0f 85 38 ff ff ff    	jne    ac58 <fwp_main_thread+0x278>
    ad20:	48 8b 3d 31 66 01 00 	mov    0x16631(%rip),%rdi        # 21358 <fwp_state>
    ad27:	e8 64 94 ff ff       	call   4190 <fwp_mem_free>
    ad2c:	48 c7 05 21 66 01 00 	movq   $0x0,0x16621(%rip)        # 21358 <fwp_state>
    ad33:	00 00 00 00 
    ad37:	48 c7 05 06 66 01 00 	movq   $0x0,0x16606(%rip)        # 21348 <fwp_state_cap>
    ad3e:	00 00 00 00 
    ad42:	48 85 db             	test   %rbx,%rbx
    ad45:	0f 84 46 03 00 00    	je     b091 <fwp_main_thread+0x6b1>
    ad4b:	48 39 1d 66 49 01 00 	cmp    %rbx,0x14966(%rip)        # 1f6b8 <fwp_root>
    ad52:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ad59:	00 00 00 00 
    ad5d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ad64:	00 00 00 00 
    ad68:	c7 05 0e 43 01 00 00 	movl   $0x0,0x1430e(%rip)        # 1f080 <fwp_exit_code>
    ad6f:	00 00 00 
    ad72:	0f 84 00 ff ff ff    	je     ac78 <fwp_main_thread+0x298>
    ad78:	e9 93 79 ff ff       	jmp    2710 <fwp_main_thread.cold>
    ad7d:	0f 1f 00             	nopl   (%rax)
    ad80:	e8 cb 83 ff ff       	call   3150 <fwp_now_ns>
    ad85:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ad89:	0f 8d 91 02 00 00    	jge    b020 <fwp_main_thread+0x640>
    ad8f:	90                   	nop
    ad90:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ad94:	0f 85 80 fd ff ff    	jne    ab1a <fwp_main_thread+0x13a>
    ad9a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ad9e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ada2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ada6:	0f 85 80 fd ff ff    	jne    ab2c <fwp_main_thread+0x14c>
    adac:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    adb0:	48 85 c9             	test   %rcx,%rcx
    adb3:	0f 84 73 fd ff ff    	je     ab2c <fwp_main_thread+0x14c>
    adb9:	48 85 c0             	test   %rax,%rax
    adbc:	0f 84 ff 02 00 00    	je     b0c1 <fwp_main_thread+0x6e1>
    adc2:	48 39 c8             	cmp    %rcx,%rax
    adc5:	48 0f 4f c1          	cmovg  %rcx,%rax
    adc9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    add0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    add4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    addb:	00 00 00 00 
    addf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ade6:	48 85 d2             	test   %rdx,%rdx
    ade9:	74 07                	je     adf2 <fwp_main_thread+0x412>
    adeb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    adf2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    adf6:	e9 63 fd ff ff       	jmp    ab5e <fwp_main_thread+0x17e>
    adfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ae00:	48 89 cb             	mov    %rcx,%rbx
    ae03:	e9 f2 fc ff ff       	jmp    aafa <fwp_main_thread+0x11a>
    ae08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ae0f:	00 
    ae10:	48 8b 45 40          	mov    0x40(%rbp),%rax
    ae14:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae1b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae22:	00 00 00 00 
    ae26:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    ae2d:	48 85 c0             	test   %rax,%rax
    ae30:	0f 84 52 02 00 00    	je     b088 <fwp_main_thread+0x6a8>
    ae36:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    ae3d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ae41:	e9 4c fd ff ff       	jmp    ab92 <fwp_main_thread+0x1b2>
    ae46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae4d:	00 00 00 
    ae50:	48 89 01             	mov    %rax,(%rcx)
    ae53:	e9 74 fd ff ff       	jmp    abcc <fwp_main_thread+0x1ec>
    ae58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ae5f:	00 
    ae60:	48 83 3d e8 64 01 00 	cmpq   $0x0,0x164e8(%rip)        # 21350 <fwp_state_len>
    ae67:	00 
    ae68:	0f 84 a2 fe ff ff    	je     ad10 <fwp_main_thread+0x330>
    ae6e:	48 83 3d 42 48 01 00 	cmpq   $0x0,0x14842(%rip)        # 1f6b8 <fwp_root>
    ae75:	00 
    ae76:	c7 05 00 42 01 00 00 	movl   $0x0,0x14200(%rip)        # 1f080 <fwp_exit_code>
    ae7d:	00 00 00 
    ae80:	0f 85 43 02 00 00    	jne    b0c9 <fwp_main_thread+0x6e9>
    ae86:	e8 15 9b ff ff       	call   49a0 <fwp_free_zombie>
    ae8b:	48 83 3d 15 48 01 00 	cmpq   $0x0,0x14815(%rip)        # 1f6a8 <fwp_ready_head>
    ae92:	00 
    ae93:	0f 85 77 78 ff ff    	jne    2710 <fwp_main_thread.cold>
    ae99:	48 83 3d f7 47 01 00 	cmpq   $0x0,0x147f7(%rip)        # 1f698 <fwp_timers>
    aea0:	00 
    aea1:	0f 85 69 78 ff ff    	jne    2710 <fwp_main_thread.cold>
    aea7:	8b 1d ef 41 01 00    	mov    0x141ef(%rip),%ebx        # 1f09c <fwp_stack_pool_n>
    aead:	85 db                	test   %ebx,%ebx
    aeaf:	74 36                	je     aee7 <fwp_main_thread+0x507>
    aeb1:	83 eb 01             	sub    $0x1,%ebx
    aeb4:	48 8d 05 e5 41 01 00 	lea    0x141e5(%rip),%rax        # 1f0a0 <fwp_stack_pool>
    aebb:	48 63 d3             	movslq %ebx,%rdx
    aebe:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    aec2:	eb 07                	jmp    aecb <fwp_main_thread+0x4eb>
    aec4:	0f 1f 40 00          	nopl   0x0(%rax)
    aec8:	83 eb 01             	sub    $0x1,%ebx
    aecb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    aecf:	be 00 00 00 10       	mov    $0x10000000,%esi
    aed4:	89 1d c2 41 01 00    	mov    %ebx,0x141c2(%rip)        # 1f09c <fwp_stack_pool_n>
    aeda:	48 83 ed 08          	sub    $0x8,%rbp
    aede:	e8 cd 76 ff ff       	call   25b0 <munmap@plt>
    aee3:	85 db                	test   %ebx,%ebx
    aee5:	75 e1                	jne    aec8 <fwp_main_thread+0x4e8>
    aee7:	8b 3d 23 41 00 00    	mov    0x4123(%rip),%edi        # f010 <fwp_epfd>
    aeed:	85 ff                	test   %edi,%edi
    aeef:	78 05                	js     aef6 <fwp_main_thread+0x516>
    aef1:	e8 ba 75 ff ff       	call   24b0 <close@plt>
    aef6:	4c 8b 25 a3 43 01 00 	mov    0x143a3(%rip),%r12        # 1f2a0 <fwp_nfdws>
    aefd:	48 8b 2d a4 43 01 00 	mov    0x143a4(%rip),%rbp        # 1f2a8 <fwp_fdws>
    af04:	31 db                	xor    %ebx,%ebx
    af06:	c7 05 00 41 00 00 ff 	movl   $0xffffffff,0x4100(%rip)        # f010 <fwp_epfd>
    af0d:	ff ff ff 
    af10:	4d 85 e4             	test   %r12,%r12
    af13:	74 38                	je     af4d <fwp_main_thread+0x56d>
    af15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af1c:	00 00 00 00 
    af20:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    af25:	48 85 ff             	test   %rdi,%rdi
    af28:	74 1a                	je     af44 <fwp_main_thread+0x564>
    af2a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    af2e:	0f 85 dc 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    af34:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    af39:	0f 85 d1 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    af3f:	e8 4c 92 ff ff       	call   4190 <fwp_mem_free>
    af44:	48 83 c3 01          	add    $0x1,%rbx
    af48:	4c 39 e3             	cmp    %r12,%rbx
    af4b:	75 d3                	jne    af20 <fwp_main_thread+0x540>
    af4d:	48 89 ef             	mov    %rbp,%rdi
    af50:	e8 3b 92 ff ff       	call   4190 <fwp_mem_free>
    af55:	48 8b 15 5c 47 01 00 	mov    0x1475c(%rip),%rdx        # 1f6b8 <fwp_root>
    af5c:	48 c7 05 41 43 01 00 	movq   $0x0,0x14341(%rip)        # 1f2a8 <fwp_fdws>
    af63:	00 00 00 00 
    af67:	48 c7 05 2e 43 01 00 	movq   $0x0,0x1432e(%rip)        # 1f2a0 <fwp_nfdws>
    af6e:	00 00 00 00 
    af72:	48 85 d2             	test   %rdx,%rdx
    af75:	74 4e                	je     afc5 <fwp_main_thread+0x5e5>
    af77:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    af7c:	0f 85 8e 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    af82:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    af89:	00 
    af8a:	0f 85 80 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    af90:	48 83 3d b8 63 01 00 	cmpq   $0x0,0x163b8(%rip)        # 21350 <fwp_state_len>
    af97:	00 
    af98:	0f 85 72 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    af9e:	48 83 3d 9a 63 01 00 	cmpq   $0x0,0x1639a(%rip)        # 21340 <fwp_state_owners>
    afa5:	00 
    afa6:	0f 85 64 77 ff ff    	jne    2710 <fwp_main_thread.cold>
    afac:	b9 79 00 00 00       	mov    $0x79,%ecx
    afb1:	31 c0                	xor    %eax,%eax
    afb3:	48 8d 3d 06 43 01 00 	lea    0x14306(%rip),%rdi        # 1f2c0 <fwp_root_context>
    afba:	f3 48 ab             	rep stos %rax,(%rdi)
    afbd:	48 89 d7             	mov    %rdx,%rdi
    afc0:	e8 cb 91 ff ff       	call   4190 <fwp_mem_free>
    afc5:	48 8b 3d 54 40 00 00 	mov    0x4054(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    afcc:	48 c7 05 e9 46 01 00 	movq   $0x0,0x146e9(%rip)        # 1f6c0 <fwp_cur>
    afd3:	00 00 00 00 
    afd7:	48 c7 05 d6 46 01 00 	movq   $0x0,0x146d6(%rip)        # 1f6b8 <fwp_root>
    afde:	00 00 00 00 
    afe2:	e8 a9 75 ff ff       	call   2590 <fflush@plt>
    afe7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    afee:	00 
    afef:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aff6:	00 00 
    aff8:	0f 85 be 00 00 00    	jne    b0bc <fwp_main_thread+0x6dc>
    affe:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    b005:	31 c0                	xor    %eax,%eax
    b007:	5b                   	pop    %rbx
    b008:	5d                   	pop    %rbp
    b009:	41 5c                	pop    %r12
    b00b:	c3                   	ret
    b00c:	0f 1f 40 00          	nopl   0x0(%rax)
    b010:	48 89 05 81 46 01 00 	mov    %rax,0x14681(%rip)        # 1f698 <fwp_timers>
    b017:	e9 01 fc ff ff       	jmp    ac1d <fwp_main_thread+0x23d>
    b01c:	0f 1f 40 00          	nopl   0x0(%rax)
    b020:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b024:	0f 85 66 fd ff ff    	jne    ad90 <fwp_main_thread+0x3b0>
    b02a:	48 89 ef             	mov    %rbp,%rdi
    b02d:	e8 fe 7f ff ff       	call   3030 <fwp_cancel_tree.part.0>
    b032:	e9 59 fd ff ff       	jmp    ad90 <fwp_main_thread+0x3b0>
    b037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b03e:	00 00 
    b040:	e8 8b cc ff ff       	call   7cd0 <f0>
    b045:	48 c7 05 10 40 00 00 	movq   $0x0,0x4010(%rip)        # f060 <v.1>
    b04c:	00 00 00 00 
    b050:	c7 05 0e 40 00 00 01 	movl   $0x1,0x400e(%rip)        # f068 <st.2>
    b057:	00 00 00 
    b05a:	e9 7f fa ff ff       	jmp    aade <fwp_main_thread+0xfe>
    b05f:	90                   	nop
    b060:	48 8d 3d f9 86 ff ff 	lea    -0x7907(%rip),%rdi        # 3760 <fwp_heap_report>
    b067:	e8 84 02 00 00       	call   b2f0 <atexit>
    b06c:	e9 ad f9 ff ff       	jmp    aa1e <fwp_main_thread+0x3e>
    b071:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b078:	e8 f3 87 ff ff       	call   3870 <fwp_heap_init>
    b07d:	e9 8e f9 ff ff       	jmp    aa10 <fwp_main_thread+0x30>
    b082:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b088:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b08c:	e9 01 fb ff ff       	jmp    ab92 <fwp_main_thread+0x1b2>
    b091:	48 83 3d 1f 46 01 00 	cmpq   $0x0,0x1461f(%rip)        # 1f6b8 <fwp_root>
    b098:	00 
    b099:	c7 05 dd 3f 01 00 00 	movl   $0x0,0x13fdd(%rip)        # 1f080 <fwp_exit_code>
    b0a0:	00 00 00 
    b0a3:	0f 84 dd fd ff ff    	je     ae86 <fwp_main_thread+0x4a6>
    b0a9:	e9 62 76 ff ff       	jmp    2710 <fwp_main_thread.cold>
    b0ae:	66 90                	xchg   %ax,%ax
    b0b0:	48 8d 3d 51 12 00 00 	lea    0x1251(%rip),%rdi        # c308 <_IO_stdin_used+0x308>
    b0b7:	e8 64 80 ff ff       	call   3120 <fwp_trap>
    b0bc:	e8 7f 73 ff ff       	call   2440 <__stack_chk_fail@plt>
    b0c1:	48 89 c8             	mov    %rcx,%rax
    b0c4:	e9 00 fd ff ff       	jmp    adc9 <fwp_main_thread+0x3e9>
    b0c9:	e9 42 76 ff ff       	jmp    2710 <fwp_main_thread.cold>
    b0ce:	e9 3d 76 ff ff       	jmp    2710 <fwp_main_thread.cold>
    b0d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b0da:	00 00 00 
    b0dd:	0f 1f 00             	nopl   (%rax)

000000000000b0e0 <__divmodti4>:
    b0e0:	f3 0f 1e fa          	endbr64
    b0e4:	55                   	push   %rbp
    b0e5:	49 89 f1             	mov    %rsi,%r9
    b0e8:	49 89 d2             	mov    %rdx,%r10
    b0eb:	48 89 fe             	mov    %rdi,%rsi
    b0ee:	49 89 cb             	mov    %rcx,%r11
    b0f1:	48 89 e5             	mov    %rsp,%rbp
    b0f4:	41 57                	push   %r15
    b0f6:	41 56                	push   %r14
    b0f8:	41 55                	push   %r13
    b0fa:	41 54                	push   %r12
    b0fc:	53                   	push   %rbx
    b0fd:	4c 89 c3             	mov    %r8,%rbx
    b100:	45 31 c0             	xor    %r8d,%r8d
    b103:	4d 85 c9             	test   %r9,%r9
    b106:	79 12                	jns    b11a <__divmodti4+0x3a>
    b108:	31 ff                	xor    %edi,%edi
    b10a:	48 f7 de             	neg    %rsi
    b10d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b114:	4c 19 cf             	sbb    %r9,%rdi
    b117:	49 89 f9             	mov    %rdi,%r9
    b11a:	4c 89 d8             	mov    %r11,%rax
    b11d:	4d 85 db             	test   %r11,%r11
    b120:	0f 88 1a 01 00 00    	js     b240 <__divmodti4+0x160>
    b126:	4c 89 d9             	mov    %r11,%rcx
    b129:	49 89 f3             	mov    %rsi,%r11
    b12c:	75 62                	jne    b190 <__divmodti4+0xb0>
    b12e:	4d 89 c4             	mov    %r8,%r12
    b131:	4d 39 d1             	cmp    %r10,%r9
    b134:	0f 83 46 01 00 00    	jae    b280 <__divmodti4+0x1a0>
    b13a:	4c 89 d8             	mov    %r11,%rax
    b13d:	4c 89 ca             	mov    %r9,%rdx
    b140:	49 f7 f2             	div    %r10
    b143:	49 89 c3             	mov    %rax,%r11
    b146:	31 c0                	xor    %eax,%eax
    b148:	48 89 d6             	mov    %rdx,%rsi
    b14b:	31 ff                	xor    %edi,%edi
    b14d:	4c 89 d9             	mov    %r11,%rcx
    b150:	48 89 c2             	mov    %rax,%rdx
    b153:	48 89 c8             	mov    %rcx,%rax
    b156:	4d 85 e4             	test   %r12,%r12
    b159:	74 0a                	je     b165 <__divmodti4+0x85>
    b15b:	48 f7 d8             	neg    %rax
    b15e:	48 83 d2 00          	adc    $0x0,%rdx
    b162:	48 f7 da             	neg    %rdx
    b165:	4d 85 c0             	test   %r8,%r8
    b168:	74 0a                	je     b174 <__divmodti4+0x94>
    b16a:	48 f7 de             	neg    %rsi
    b16d:	48 83 d7 00          	adc    $0x0,%rdi
    b171:	48 f7 df             	neg    %rdi
    b174:	48 89 33             	mov    %rsi,(%rbx)
    b177:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b17b:	5b                   	pop    %rbx
    b17c:	41 5c                	pop    %r12
    b17e:	41 5d                	pop    %r13
    b180:	41 5e                	pop    %r14
    b182:	41 5f                	pop    %r15
    b184:	5d                   	pop    %rbp
    b185:	c3                   	ret
    b186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b18d:	00 00 00 
    b190:	4d 89 c4             	mov    %r8,%r12
    b193:	49 39 c1             	cmp    %rax,%r9
    b196:	0f 82 ce 00 00 00    	jb     b26a <__divmodti4+0x18a>
    b19c:	31 ff                	xor    %edi,%edi
    b19e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b1a3:	48 63 c7             	movslq %edi,%rax
    b1a6:	be 40 00 00 00       	mov    $0x40,%esi
    b1ab:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b1b0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b1b5:	48 29 c6             	sub    %rax,%rsi
    b1b8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b1bd:	48 09 c8             	or     %rcx,%rax
    b1c0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b1c5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b1ca:	49 89 c6             	mov    %rax,%r14
    b1cd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b1d1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b1d6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b1db:	49 09 c1             	or     %rax,%r9
    b1de:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b1e2:	4c 89 c8             	mov    %r9,%rax
    b1e5:	49 f7 f6             	div    %r14
    b1e8:	48 89 d1             	mov    %rdx,%rcx
    b1eb:	49 89 c3             	mov    %rax,%r11
    b1ee:	49 89 c1             	mov    %rax,%r9
    b1f1:	49 f7 e2             	mul    %r10
    b1f4:	49 89 c6             	mov    %rax,%r14
    b1f7:	49 89 d2             	mov    %rdx,%r10
    b1fa:	48 39 d1             	cmp    %rdx,%rcx
    b1fd:	72 07                	jb     b206 <__divmodti4+0x126>
    b1ff:	75 17                	jne    b218 <__divmodti4+0x138>
    b201:	49 39 c7             	cmp    %rax,%r15
    b204:	73 12                	jae    b218 <__divmodti4+0x138>
    b206:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b20a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b20e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b212:	49 89 d2             	mov    %rdx,%r10
    b215:	49 89 c6             	mov    %rax,%r14
    b218:	4c 89 f8             	mov    %r15,%rax
    b21b:	4c 29 f0             	sub    %r14,%rax
    b21e:	4c 19 d1             	sbb    %r10,%rcx
    b221:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b226:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b22b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b230:	48 09 c6             	or     %rax,%rsi
    b233:	48 89 cf             	mov    %rcx,%rdi
    b236:	31 c0                	xor    %eax,%eax
    b238:	4c 89 c9             	mov    %r9,%rcx
    b23b:	e9 10 ff ff ff       	jmp    b150 <__divmodti4+0x70>
    b240:	4c 89 d0             	mov    %r10,%rax
    b243:	4c 89 da             	mov    %r11,%rdx
    b246:	4d 89 c4             	mov    %r8,%r12
    b249:	49 89 f3             	mov    %rsi,%r11
    b24c:	48 f7 d8             	neg    %rax
    b24f:	49 f7 d4             	not    %r12
    b252:	48 83 d2 00          	adc    $0x0,%rdx
    b256:	49 89 c2             	mov    %rax,%r10
    b259:	48 f7 da             	neg    %rdx
    b25c:	48 89 d1             	mov    %rdx,%rcx
    b25f:	0f 84 cc fe ff ff    	je     b131 <__divmodti4+0x51>
    b265:	49 39 d1             	cmp    %rdx,%r9
    b268:	73 46                	jae    b2b0 <__divmodti4+0x1d0>
    b26a:	4c 89 cf             	mov    %r9,%rdi
    b26d:	31 c0                	xor    %eax,%eax
    b26f:	31 c9                	xor    %ecx,%ecx
    b271:	e9 da fe ff ff       	jmp    b150 <__divmodti4+0x70>
    b276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b27d:	00 00 00 
    b280:	4d 85 d2             	test   %r10,%r10
    b283:	75 0d                	jne    b292 <__divmodti4+0x1b2>
    b285:	b8 01 00 00 00       	mov    $0x1,%eax
    b28a:	31 d2                	xor    %edx,%edx
    b28c:	49 f7 f2             	div    %r10
    b28f:	49 89 c2             	mov    %rax,%r10
    b292:	4c 89 c8             	mov    %r9,%rax
    b295:	31 d2                	xor    %edx,%edx
    b297:	49 f7 f2             	div    %r10
    b29a:	49 89 c1             	mov    %rax,%r9
    b29d:	4c 89 d8             	mov    %r11,%rax
    b2a0:	49 f7 f2             	div    %r10
    b2a3:	49 89 c3             	mov    %rax,%r11
    b2a6:	4c 89 c8             	mov    %r9,%rax
    b2a9:	e9 9a fe ff ff       	jmp    b148 <__divmodti4+0x68>
    b2ae:	66 90                	xchg   %ax,%ax
    b2b0:	45 31 f6             	xor    %r14d,%r14d
    b2b3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    b2b8:	44 89 f7             	mov    %r14d,%edi
    b2bb:	45 85 f6             	test   %r14d,%r14d
    b2be:	0f 85 df fe ff ff    	jne    b1a3 <__divmodti4+0xc3>
    b2c4:	4c 39 ca             	cmp    %r9,%rdx
    b2c7:	72 17                	jb     b2e0 <__divmodti4+0x200>
    b2c9:	31 c9                	xor    %ecx,%ecx
    b2cb:	48 39 c6             	cmp    %rax,%rsi
    b2ce:	73 10                	jae    b2e0 <__divmodti4+0x200>
    b2d0:	4c 89 cf             	mov    %r9,%rdi
    b2d3:	31 c0                	xor    %eax,%eax
    b2d5:	e9 76 fe ff ff       	jmp    b150 <__divmodti4+0x70>
    b2da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b2e0:	4c 89 de             	mov    %r11,%rsi
    b2e3:	b9 01 00 00 00       	mov    $0x1,%ecx
    b2e8:	48 29 c6             	sub    %rax,%rsi
    b2eb:	49 19 d1             	sbb    %rdx,%r9
    b2ee:	eb e0                	jmp    b2d0 <__divmodti4+0x1f0>

000000000000b2f0 <atexit>:
    b2f0:	f3 0f 1e fa          	endbr64
    b2f4:	48 8b 15 0d 3d 00 00 	mov    0x3d0d(%rip),%rdx        # f008 <__dso_handle>
    b2fb:	31 f6                	xor    %esi,%esi
    b2fd:	e9 1e 73 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b304 <_fini>:
    b304:	f3 0f 1e fa          	endbr64
    b308:	48 83 ec 08          	sub    $0x8,%rsp
    b30c:	48 83 c4 08          	add    $0x8,%rsp
    b310:	c3                   	ret
