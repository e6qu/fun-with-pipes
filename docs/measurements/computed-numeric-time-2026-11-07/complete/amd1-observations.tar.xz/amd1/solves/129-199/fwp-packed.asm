
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-packed:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 af 00 00 	mov    0xafd9(%rip),%rax        # cfe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 ae 00 00    	push   0xae02(%rip)        # ce28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 ae 00 00    	jmp    *0xae04(%rip)        # ce30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e ac 00 00    	jmp    *0xac7e(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae aa 00 00    	jmp    *0xaaae(%rip)        # ce38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 aa 00 00    	jmp    *0xaaa6(%rip)        # ce40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e aa 00 00    	jmp    *0xaa9e(%rip)        # ce48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 aa 00 00    	jmp    *0xaa96(%rip)        # ce50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e aa 00 00    	jmp    *0xaa8e(%rip)        # ce58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 aa 00 00    	jmp    *0xaa86(%rip)        # ce60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e aa 00 00    	jmp    *0xaa7e(%rip)        # ce68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 aa 00 00    	jmp    *0xaa76(%rip)        # ce70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e aa 00 00    	jmp    *0xaa6e(%rip)        # ce78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 aa 00 00    	jmp    *0xaa66(%rip)        # ce80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e aa 00 00    	jmp    *0xaa5e(%rip)        # ce88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 aa 00 00    	jmp    *0xaa56(%rip)        # ce90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e aa 00 00    	jmp    *0xaa4e(%rip)        # ce98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 aa 00 00    	jmp    *0xaa46(%rip)        # cea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e aa 00 00    	jmp    *0xaa3e(%rip)        # cea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 aa 00 00    	jmp    *0xaa36(%rip)        # ceb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e aa 00 00    	jmp    *0xaa2e(%rip)        # ceb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 aa 00 00    	jmp    *0xaa26(%rip)        # cec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e aa 00 00    	jmp    *0xaa1e(%rip)        # cec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 aa 00 00    	jmp    *0xaa16(%rip)        # ced0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e aa 00 00    	jmp    *0xaa0e(%rip)        # ced8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 aa 00 00    	jmp    *0xaa06(%rip)        # cee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe a9 00 00    	jmp    *0xa9fe(%rip)        # cee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 a9 00 00    	jmp    *0xa9f6(%rip)        # cef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee a9 00 00    	jmp    *0xa9ee(%rip)        # cef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 a9 00 00    	jmp    *0xa9e6(%rip)        # cf00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de a9 00 00    	jmp    *0xa9de(%rip)        # cf08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 a9 00 00    	jmp    *0xa9d6(%rip)        # cf10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce a9 00 00    	jmp    *0xa9ce(%rip)        # cf18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 a9 00 00    	jmp    *0xa9c6(%rip)        # cf20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be a9 00 00    	jmp    *0xa9be(%rip)        # cf28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 a9 00 00    	jmp    *0xa9b6(%rip)        # cf30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae a9 00 00    	jmp    *0xa9ae(%rip)        # cf38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 a9 00 00    	jmp    *0xa9a6(%rip)        # cf40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e a9 00 00    	jmp    *0xa99e(%rip)        # cf48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 a9 00 00    	jmp    *0xa996(%rip)        # cf50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e a9 00 00    	jmp    *0xa98e(%rip)        # cf58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 a9 00 00    	jmp    *0xa986(%rip)        # cf60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e a9 00 00    	jmp    *0xa97e(%rip)        # cf68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 a9 00 00    	jmp    *0xa976(%rip)        # cf70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e a9 00 00    	jmp    *0xa96e(%rip)        # cf78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 a9 00 00    	jmp    *0xa966(%rip)        # cf80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e a9 00 00    	jmp    *0xa95e(%rip)        # cf88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 a9 00 00    	jmp    *0xa956(%rip)        # cf90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e a9 00 00    	jmp    *0xa94e(%rip)        # cf98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 a9 00 00    	jmp    *0xa946(%rip)        # cfa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e a9 00 00    	jmp    *0xa93e(%rip)        # cfa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 a9 00 00    	jmp    *0xa936(%rip)        # cfb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e a9 00 00    	jmp    *0xa92e(%rip)        # cfb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 a9 00 00    	jmp    *0xa926(%rip)        # cfc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e a9 00 00    	jmp    *0xa91e(%rip)        # cfc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 a9 00 00    	jmp    *0xa916(%rip)        # cfd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 89 00 00 	lea    0x89a0(%rip),%r9        # b077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 89 00 00 	lea    0x899d(%rip),%r8        # b07b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 21 a9 00 00 	mov    0xa921(%rip),%rax        # d060 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 32 cc 01 00 	mov    %rax,0x1cc32(%rip)        # 1f378 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 8a 00 00 	lea    0x8a1c(%rip),%rdi        # b16e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d a6 a8 00 00 	mov    0xa8a6(%rip),%rdi        # d060 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 8d 71 00 00 	lea    0x718d(%rip),%rdx        # 99a0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 11 a8 00 00 	mov    0xa811(%rip),%rdi        # d060 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 66 a8 01 00    	mov    0x1a866(%rip),%eax        # 1d0c0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 88 00 00 	lea    0x88cc(%rip),%rdi        # b177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 8a 00 00 	lea    0x8aec(%rip),%rdi        # b3a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d a6 8a 00 00 	lea    0x8aa6(%rip),%rdi        # b380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 8a 00 00 	lea    0x8a6a(%rip),%rdi        # b350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 8a 00 00 	lea    0x8a36(%rip),%rdi        # b328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 a6 00 00    	call   *0xa6b3(%rip)        # cfd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 21 a7 00 00 	lea    0xa721(%rip),%rdi        # d058 <__TMC_END__>
    2937:	48 8d 05 1a a7 00 00 	lea    0xa71a(%rip),%rax        # d058 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 a6 00 00 	mov    0xa696(%rip),%rax        # cfe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d f1 a6 00 00 	lea    0xa6f1(%rip),%rdi        # d058 <__TMC_END__>
    2967:	48 8d 35 ea a6 00 00 	lea    0xa6ea(%rip),%rsi        # d058 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 a6 00 00 	mov    0xa665(%rip),%rax        # cff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d dd a6 00 00 00 	cmpb   $0x0,0xa6dd(%rip)        # d088 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 a6 00 00 	cmpq   $0x0,0xa642(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 a6 00 00 	mov    0xa646(%rip),%rdi        # d008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 b5 a6 00 00 01 	movb   $0x1,0xa6b5(%rip)        # d088 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d b1 c7 01 00 	mov    0x1c7b1(%rip),%rdi        # 1f378 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d 84 a4 00 00 	mov    0xa484(%rip),%rdi        # d060 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 71 a4 00 00 	mov    0xa471(%rip),%rdi        # d060 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 83 00 00 	lea    0x83f5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 62 a4 00 00 	mov    0xa462(%rip),%rcx        # d080 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 b1 aa 01 00 	mov    0x1aab1(%rip),%rax        # 1d700 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 01 a4 01 00 	mov    0x1a401(%rip),%rax        # 1d0d0 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 ed a3 01 00 	sub    0x1a3ed(%rip),%rax        # 1d0c8 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 87 00 00 	lea    0x872d(%rip),%rsi        # b440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 cb bd 01 00 	mov    0x1bdcb(%rip),%rax        # 1eb10 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 c4 bd 01 00 	lea    0x1bdc4(%rip),%r8        # 1eb10 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d a5 bd 01 00 	mov    0x1bda5(%rip),%rbx        # 1eaf8 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d b5 bd 01 00 	mov    0x1bdb5(%rip),%rcx        # 1eb18 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 51 bd 01 00 	mov    0x1bd51(%rip),%rdi        # 1eb00 <fwp_heap+0x13e0>
    2daf:	48 29 35 9a bd 01 00 	sub    %rsi,0x1bd9a(%rip)        # 1eb50 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 2a bd 01 00 	mov    0x1bd2a(%rip),%rax        # 1eaf0 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d e0 bc 01 00 	add    0x1bce0(%rip),%rdi        # 1ead0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 ee bc 01 00 	mov    0x1bcee(%rip),%rsi        # 1eb00 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 fc bc 01 00 	mov    0x1bcfc(%rip),%rax        # 1eb18 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 ab bc 01 00 	mov    %r12,0x1bcab(%rip)        # 1eb00 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d 99 bc 01 00 	mov    %rbp,0x1bc99(%rip)        # 1eaf8 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 7e bc 01 00 	cmp    %rdi,0x1bc7e(%rip)        # 1eae8 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 75 bc 01 00 	mov    %rdi,0x1bc75(%rip)        # 1eae8 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d b9 bc 01 00 	sub    %rdi,0x1bcb9(%rip)        # 1eb50 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 61 bc 01 00 	mov    0x1bc61(%rip),%rax        # 1eb08 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 5a bc 01 00 	lea    0x1bc5a(%rip),%r8        # 1eb08 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d 2d a1 00 00 	mov    0xa12d(%rip),%rcx        # d080 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 80 00 00 	lea    0x80a4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d 39 a7 01 00 	cmp    0x1a739(%rip),%rdi        # 1d700 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 ff a6 01 00 	mov    0x1a6ff(%rip),%rax        # 1d6e0 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d dd a6 01 00 	mov    %rdi,0x1a6dd(%rip)        # 1d6e0 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d b9 a6 01 00 	mov    %rdi,0x1a6b9(%rip)        # 1d6e8 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 80 00 00 	lea    0x8051(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 7f 00 00 	lea    0x7f97(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d b6 9f 00 00 	mov    0x9fb6(%rip),%rdi        # d080 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 7f 00 00 	lea    0x7f4f(%rip),%rdx        # b020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 7e 00 00 	lea    0x7ed0(%rip),%rdi        # b02f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 80 00 00 	lea    0x8030(%rip),%rdi        # b1a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 7e 00 00 	lea    0x7eb8(%rip),%r8        # b04b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 7d 00 00 	lea    0x7d0d(%rip),%r8        # b05a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 7b 00 00 	lea    0x7b9a(%rip),%r8        # b050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 79 00 00 	lea    0x7972(%rip),%rdi        # b05f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 79 00 00 	lea    0x79fc(%rip),%rsi        # b10a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 65 b3 01 00 	mov    0x1b365(%rip),%r9        # 1eae8 <fwp_heap+0x13c8>
    3783:	4c 8b 05 be b3 01 00 	mov    0x1b3be(%rip),%r8        # 1eb48 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 7a 00 00 	lea    0x7a3f(%rip),%rdx        # b1d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d a6 b3 01 00 	mov    0x1b3a6(%rip),%rcx        # 1eb40 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d b4 b3 01 	movsd  0x1b3b4(%rip),%xmm1        # 1eb60 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 a4 b3 01 	movsd  0x1b3a4(%rip),%xmm0        # 1eb58 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d c5 98 00 00 	mov    0x98c5(%rip),%rdi        # d080 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 7c 00 	movdqa 0x7c68(%rip),%xmm0        # b460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 5f ae 01 00 	lea    0x1ae5f(%rip),%rax        # 1e660 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 7c 00 	movdqa 0x7c91(%rip),%xmm2        # b4a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 05 ae 01 00 	movaps %xmm0,0x1ae05(%rip)        # 1e620 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 7c 00 	movdqa 0x7c4d(%rip),%xmm0        # b470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 93 b2 01 00 01 	movl   $0x1,0x1b293(%rip)        # 1eac4 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 f3 ad 01 00 	movaps %xmm0,0x1adf3(%rip)        # 1e630 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 7c 00 	movdqa 0x7c3b(%rip),%xmm0        # b480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 f4 ad 01 00 	movaps %xmm0,0x1adf4(%rip)        # 1e640 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 7c 00 	movdqa 0x7c3c(%rip),%xmm0        # b490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 f5 ad 01 00 	movaps %xmm0,0x1adf5(%rip)        # 1e650 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 75 9e 01 00 	lea    0x19e75(%rip),%r8        # 1d720 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 90 b1 01 00 	mov    %rax,0x1b190(%rip)        # 1ead8 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 6e b1 01 00 	mov    %r12,0x1b16e(%rip)        # 1eae0 <fwp_heap+0x13c0>
    3972:	48 89 05 57 b1 01 00 	mov    %rax,0x1b157(%rip)        # 1ead0 <fwp_heap+0x13b0>
    3979:	48 89 1d 70 b1 01 00 	mov    %rbx,0x1b170(%rip)        # 1eaf0 <fwp_heap+0x13d0>
    3980:	48 89 35 99 b1 01 00 	mov    %rsi,0x1b199(%rip)        # 1eb20 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 76 00 00 	lea    0x76fc(%rip),%rdi        # b095 <_IO_stdin_used+0x95>
    3999:	48 89 05 78 b1 01 00 	mov    %rax,0x1b178(%rip)        # 1eb18 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 fc b0 01 00    	mov    %eax,0x1b0fc(%rip)        # 1eac8 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 ec 9c 01 00 	mov    0x19cec(%rip),%r8        # 1d6e0 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d 1c 9c 01 00 	mov    %rbx,0x19c1c(%rip)        # 1d6e8 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 08 9c 01 00 	mov    %r8,0x19c08(%rip)        # 1d6e0 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d c7 9b 01 00 	mov    0x19bc7(%rip),%rbx        # 1d6d8 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 6a 94 00 00 	mov    0x946a(%rip),%rcx        # d080 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 76 00 00 	lea    0x763b(%rip),%rdi        # b258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 8d 9a 01 00 	mov    0x19a8d(%rip),%rax        # 1d6e0 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 67 9a 01 00 	mov    %rdx,0x19a67(%rip)        # 1d6e0 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d b4 99 01 00 	mov    0x199b4(%rip),%rbx        # 1d6d8 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 71 99 01 00 	mov    %rbx,0x19971(%rip)        # 1d6d8 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 71 99 01 00 	mov    %rdx,0x19971(%rip)        # 1d6e8 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 5e 99 01 00 	lea    0x1995e(%rip),%rcx        # 1d720 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 5f b5 01 00 	subq   $0x1,0x1b55f(%rip)        # 1f368 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 74 00 00 	lea    0x7473(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 40 b5 01 00 	cmpq   $0x0,0x1b540(%rip)        # 1f368 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 95 b4 01 00 	sub    %rax,0x1b495(%rip)        # 1f370 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 73 b4 01 00 	add    %r12,0x1b473(%rip)        # 1f370 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 cf ab 01 00 	mov    0x1abcf(%rip),%rax        # 1eb18 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 cc 97 01 00 	lea    0x197cc(%rip),%rax        # 1d720 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 23 ab 01 00 	add    0x1ab23(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 f0 aa 01 00 	mov    0x1aaf0(%rip),%rsi        # 1ead0 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 11 ab 01 00 	mov    0x1ab11(%rip),%rax        # 1eaf8 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 05 ab 01 00 	add    0x1ab05(%rip),%r8        # 1eb18 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 cd aa 01 	addsd  0x1aacd(%rip),%xmm0        # 1eb60 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 82 96 01 00 	lea    0x19682(%rip),%rax        # 1d720 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d 8c aa 01 00 	sub    %rdi,0x1aa8c(%rip)        # 1eb40 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 a4 aa 01 	movsd  %xmm0,0x1aaa4(%rip)        # 1eb60 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 5e aa 01 00 	sub    %rdx,0x1aa5e(%rip)        # 1eb40 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 64 aa 01 	addsd  0x1aa64(%rip),%xmm0        # 1eb60 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 58 aa 01 	movsd  %xmm0,0x1aa58(%rip)        # 1eb60 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 ef a9 01 00 	mov    0x1a9ef(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d e9 a9 01 00 	add    %rcx,0x1a9e9(%rip)        # 1eb50 <fwp_heap+0x1430>
    4167:	4c 3b 0d a2 a9 01 00 	cmp    0x1a9a2(%rip),%r9        # 1eb10 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d 99 a9 01 00 	mov    %r9,0x1a999(%rip)        # 1eb10 <fwp_heap+0x13f0>
    4177:	4c 3b 0d 8a a9 01 00 	cmp    0x1a98a(%rip),%r9        # 1eb08 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 7d a9 01 00 	mov    %r9,0x1a97d(%rip)        # 1eb08 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d 93 a8 01 00 	add    0x1a893(%rip),%rdi        # 1eb18 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 70 94 01 00 	lea    0x19470(%rip),%r15        # 1d720 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 e0 a7 01 00 	add    0x1a7e0(%rip),%r12        # 1ead0 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 39 a8 01 00 	add    0x1a839(%rip),%rax        # 1eb40 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 38 a8 01 00 	cmp    %rax,0x1a838(%rip)        # 1eb48 <fwp_heap+0x1428>
    4310:	48 89 05 29 a8 01 00 	mov    %rax,0x1a829(%rip)        # 1eb40 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 28 a8 01 00 	mov    %rax,0x1a828(%rip)        # 1eb48 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 24 a8 01 	addsd  0x1a824(%rip),%xmm0        # 1eb58 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 1c a8 01 	movsd  %xmm0,0x1a81c(%rip)        # 1eb58 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 63 a7 01 00    	mov    0x1a763(%rip),%eax        # 1eac4 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d 9f 93 01 00 	lea    0x1939f(%rip),%rdi        # 1d720 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 58 a7 01 00 	add    0x1a758(%rip),%rax        # 1eb40 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 53 a7 01 00 	cmp    %rax,0x1a753(%rip)        # 1eb48 <fwp_heap+0x1428>
    43f5:	48 89 05 44 a7 01 00 	mov    %rax,0x1a744(%rip)        # 1eb40 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 43 a7 01 00 	mov    %rax,0x1a743(%rip)        # 1eb48 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 3f a7 01 	addsd  0x1a73f(%rip),%xmm0        # 1eb58 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 37 a7 01 	movsd  %xmm0,0x1a737(%rip)        # 1eb58 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_fresh>:
    44d0:	48 8b 15 21 a6 01 00 	mov    0x1a621(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 89 fe             	mov    %rdi,%rsi
    44dd:	48 2b 05 ec a5 01 00 	sub    0x1a5ec(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    44e4:	48 c1 e2 10          	shl    $0x10,%rdx
    44e8:	48 39 d0             	cmp    %rdx,%rax
    44eb:	73 4f                	jae    453c <fwp_rc_fresh+0x6c>
    44ed:	48 89 c2             	mov    %rax,%rdx
    44f0:	48 c1 ea 10          	shr    $0x10,%rdx
    44f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f8:	48 8b 15 19 a6 01 00 	mov    0x1a619(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    44ff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4507:	48 85 d2             	test   %rdx,%rdx
    450a:	74 30                	je     453c <fwp_rc_fresh+0x6c>
    450c:	0f b6 39             	movzbl (%rcx),%edi
    450f:	40 80 ff 02          	cmp    $0x2,%dil
    4513:	74 2b                	je     4540 <fwp_rc_fresh+0x70>
    4515:	40 80 ff 01          	cmp    $0x1,%dil
    4519:	75 21                	jne    453c <fwp_rc_fresh+0x6c>
    451b:	8b 79 18             	mov    0x18(%rcx),%edi
    451e:	0f b7 c0             	movzwl %ax,%eax
    4521:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4524:	48 0f af c7          	imul   %rdi,%rax
    4528:	48 c1 e8 20          	shr    $0x20,%rax
    452c:	48 39 c8             	cmp    %rcx,%rax
    452f:	73 0b                	jae    453c <fwp_rc_fresh+0x6c>
    4531:	48 01 c2             	add    %rax,%rdx
    4534:	80 3a ff             	cmpb   $0xff,(%rdx)
    4537:	74 17                	je     4550 <fwp_rc_fresh+0x80>
    4539:	c6 02 01             	movb   $0x1,(%rdx)
    453c:	48 89 f0             	mov    %rsi,%rax
    453f:	c3                   	ret
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ef                	je     4534 <fwp_rc_fresh+0x64>
    4545:	48 89 f0             	mov    %rsi,%rax
    4548:	c3                   	ret
    4549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4550:	48 83 ec 18          	sub    $0x18,%rsp
    4554:	48 89 d7             	mov    %rdx,%rdi
    4557:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    455c:	48 89 14 24          	mov    %rdx,(%rsp)
    4560:	e8 2b f8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4565:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    456a:	48 8b 14 24          	mov    (%rsp),%rdx
    456e:	48 89 f0             	mov    %rsi,%rax
    4571:	c6 02 01             	movb   $0x1,(%rdx)
    4574:	48 83 c4 18          	add    $0x18,%rsp
    4578:	c3                   	ret
    4579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004580 <fwp_rc_free_arr>:
    4580:	48 8b 15 71 a5 01 00 	mov    0x1a571(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    4587:	48 89 f8             	mov    %rdi,%rax
    458a:	48 2b 05 3f a5 01 00 	sub    0x1a53f(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    4591:	48 c1 e2 10          	shl    $0x10,%rdx
    4595:	48 39 d0             	cmp    %rdx,%rax
    4598:	73 5b                	jae    45f5 <fwp_rc_free_arr+0x75>
    459a:	48 89 c2             	mov    %rax,%rdx
    459d:	48 c1 ea 10          	shr    $0x10,%rdx
    45a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    45a5:	48 8b 15 6c a5 01 00 	mov    0x1a56c(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    45ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    45b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    45b4:	48 85 c9             	test   %rcx,%rcx
    45b7:	74 3c                	je     45f5 <fwp_rc_free_arr+0x75>
    45b9:	0f b6 32             	movzbl (%rdx),%esi
    45bc:	40 80 fe 02          	cmp    $0x2,%sil
    45c0:	74 2e                	je     45f0 <fwp_rc_free_arr+0x70>
    45c2:	40 80 fe 01          	cmp    $0x1,%sil
    45c6:	75 2d                	jne    45f5 <fwp_rc_free_arr+0x75>
    45c8:	8b 72 18             	mov    0x18(%rdx),%esi
    45cb:	0f b7 c0             	movzwl %ax,%eax
    45ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    45d1:	48 0f af c6          	imul   %rsi,%rax
    45d5:	48 c1 e8 20          	shr    $0x20,%rax
    45d9:	48 39 d0             	cmp    %rdx,%rax
    45dc:	73 17                	jae    45f5 <fwp_rc_free_arr+0x75>
    45de:	48 01 c1             	add    %rax,%rcx
    45e1:	80 39 01             	cmpb   $0x1,(%rcx)
    45e4:	75 0f                	jne    45f5 <fwp_rc_free_arr+0x75>
    45e6:	e9 e5 f9 ff ff       	jmp    3fd0 <fwp_mem_free>
    45eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45f0:	66 85 c0             	test   %ax,%ax
    45f3:	74 ec                	je     45e1 <fwp_rc_free_arr+0x61>
    45f5:	c3                   	ret
    45f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    45fd:	00 00 00 

0000000000004600 <fwp_heap_alloc>:
    4600:	8b 05 be a4 01 00    	mov    0x1a4be(%rip),%eax        # 1eac4 <fwp_heap+0x13a4>
    4606:	48 89 fa             	mov    %rdi,%rdx
    4609:	89 f7                	mov    %esi,%edi
    460b:	85 c0                	test   %eax,%eax
    460d:	0f 84 f5 00 00 00    	je     4708 <fwp_heap_alloc+0x108>
    4613:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    461a:	0f 87 e8 00 00 00    	ja     4708 <fwp_heap_alloc+0x108>
    4620:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4624:	48 8d 05 f5 90 01 00 	lea    0x190f5(%rip),%rax        # 1d720 <fwp_heap>
    462b:	48 83 ec 18          	sub    $0x18,%rsp
    462f:	41 89 f0             	mov    %esi,%r8d
    4632:	48 c1 e9 04          	shr    $0x4,%rcx
    4636:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    463d:	00 
    463e:	48 63 cf             	movslq %edi,%rcx
    4641:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4648:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    464f:	00 
    4650:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    4654:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    4658:	48 01 c8             	add    %rcx,%rax
    465b:	48 8b 08             	mov    (%rax),%rcx
    465e:	48 85 c9             	test   %rcx,%rcx
    4661:	74 6d                	je     46d0 <fwp_heap_alloc+0xd0>
    4663:	48 8b 31             	mov    (%rcx),%rsi
    4666:	48 f7 d6             	not    %rsi
    4669:	48 89 30             	mov    %rsi,(%rax)
    466c:	41 83 f8 01          	cmp    $0x1,%r8d
    4670:	48 89 cf             	mov    %rcx,%rdi
    4673:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4678:	49 0f 45 d1          	cmovne %r9,%rdx
    467c:	31 f6                	xor    %esi,%esi
    467e:	e8 1d de ff ff       	call   24a0 <memset@plt>
    4683:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4688:	48 89 c1             	mov    %rax,%rcx
    468b:	4c 89 c8             	mov    %r9,%rax
    468e:	48 03 05 ab a4 01 00 	add    0x1a4ab(%rip),%rax        # 1eb40 <fwp_heap+0x1420>
    4695:	72 7b                	jb     4712 <fwp_heap_alloc+0x112>
    4697:	48 39 05 aa a4 01 00 	cmp    %rax,0x1a4aa(%rip)        # 1eb48 <fwp_heap+0x1428>
    469e:	48 89 05 9b a4 01 00 	mov    %rax,0x1a49b(%rip)        # 1eb40 <fwp_heap+0x1420>
    46a5:	73 07                	jae    46ae <fwp_heap_alloc+0xae>
    46a7:	48 89 05 9a a4 01 00 	mov    %rax,0x1a49a(%rip)        # 1eb48 <fwp_heap+0x1428>
    46ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    46b2:	48 89 c8             	mov    %rcx,%rax
    46b5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    46ba:	f2 0f 58 05 96 a4 01 	addsd  0x1a496(%rip),%xmm0        # 1eb58 <fwp_heap+0x1438>
    46c1:	00 
    46c2:	f2 0f 11 05 8e a4 01 	movsd  %xmm0,0x1a48e(%rip)        # 1eb58 <fwp_heap+0x1438>
    46c9:	00 
    46ca:	48 83 c4 18          	add    $0x18,%rsp
    46ce:	c3                   	ret
    46cf:	90                   	nop
    46d0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    46d4:	48 85 c9             	test   %rcx,%rcx
    46d7:	74 0c                	je     46e5 <fwp_heap_alloc+0xe5>
    46d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    46dd:	48 29 ce             	sub    %rcx,%rsi
    46e0:	4c 39 ce             	cmp    %r9,%rsi
    46e3:	73 13                	jae    46f8 <fwp_heap_alloc+0xf8>
    46e5:	89 fe                	mov    %edi,%esi
    46e7:	48 83 c4 18          	add    $0x18,%rsp
    46eb:	48 89 d7             	mov    %rdx,%rdi
    46ee:	e9 5d fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    46f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46f8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    46fc:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4700:	e9 67 ff ff ff       	jmp    466c <fwp_heap_alloc+0x6c>
    4705:	0f 1f 00             	nopl   (%rax)
    4708:	89 fe                	mov    %edi,%esi
    470a:	48 89 d7             	mov    %rdx,%rdi
    470d:	e9 3e fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4712:	e8 e9 e4 ff ff       	call   2c00 <fwp_heap_oom>
    4717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    471e:	00 00 

0000000000004720 <fwp_data.part.0.constprop.0>:
    4720:	8b 05 9e a3 01 00    	mov    0x1a39e(%rip),%eax        # 1eac4 <fwp_heap+0x13a4>
    4726:	41 54                	push   %r12
    4728:	49 89 fc             	mov    %rdi,%r12
    472b:	55                   	push   %rbp
    472c:	53                   	push   %rbx
    472d:	85 c0                	test   %eax,%eax
    472f:	0f 84 e3 00 00 00    	je     4818 <fwp_data.part.0.constprop.0+0xf8>
    4735:	0f b6 05 86 9f 01 00 	movzbl 0x19f86(%rip),%eax        # 1e6c2 <fwp_heap+0xfa2>
    473c:	48 8d 15 dd 8f 01 00 	lea    0x18fdd(%rip),%rdx        # 1d720 <fwp_heap>
    4743:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    474a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    474e:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    4752:	48 8b 18             	mov    (%rax),%rbx
    4755:	48 85 db             	test   %rbx,%rbx
    4758:	0f 84 92 00 00 00    	je     47f0 <fwp_data.part.0.constprop.0+0xd0>
    475e:	48 8b 13             	mov    (%rbx),%rdx
    4761:	48 f7 d2             	not    %rdx
    4764:	48 89 10             	mov    %rdx,(%rax)
    4767:	48 83 fd 18          	cmp    $0x18,%rbp
    476b:	76 1b                	jbe    4788 <fwp_data.part.0.constprop.0+0x68>
    476d:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    4771:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    4775:	31 f6                	xor    %esi,%esi
    4777:	48 c1 e8 03          	shr    $0x3,%rax
    477b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    4782:	00 
    4783:	e8 18 dd ff ff       	call   24a0 <memset@plt>
    4788:	48 89 e8             	mov    %rbp,%rax
    478b:	48 03 05 ae a3 01 00 	add    0x1a3ae(%rip),%rax        # 1eb40 <fwp_heap+0x1420>
    4792:	0f 82 91 00 00 00    	jb     4829 <fwp_data.part.0.constprop.0+0x109>
    4798:	48 39 05 a9 a3 01 00 	cmp    %rax,0x1a3a9(%rip)        # 1eb48 <fwp_heap+0x1428>
    479f:	48 89 05 9a a3 01 00 	mov    %rax,0x1a39a(%rip)        # 1eb40 <fwp_heap+0x1420>
    47a6:	73 07                	jae    47af <fwp_data.part.0.constprop.0+0x8f>
    47a8:	48 89 05 99 a3 01 00 	mov    %rax,0x1a399(%rip)        # 1eb48 <fwp_heap+0x1428>
    47af:	66 0f ef c0          	pxor   %xmm0,%xmm0
    47b3:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    47b8:	f2 0f 58 05 98 a3 01 	addsd  0x1a398(%rip),%xmm0        # 1eb58 <fwp_heap+0x1438>
    47bf:	00 
    47c0:	f2 0f 11 05 90 a3 01 	movsd  %xmm0,0x1a390(%rip)        # 1eb58 <fwp_heap+0x1438>
    47c7:	00 
    47c8:	48 8b 05 d1 6c 00 00 	mov    0x6cd1(%rip),%rax        # b4a0 <msg.3+0x60>
    47cf:	48 89 03             	mov    %rax,(%rbx)
    47d2:	49 8b 04 24          	mov    (%r12),%rax
    47d6:	48 89 43 08          	mov    %rax,0x8(%rbx)
    47da:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    47df:	48 89 43 10          	mov    %rax,0x10(%rbx)
    47e3:	48 89 d8             	mov    %rbx,%rax
    47e6:	5b                   	pop    %rbx
    47e7:	5d                   	pop    %rbp
    47e8:	41 5c                	pop    %r12
    47ea:	c3                   	ret
    47eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    47f0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    47f4:	48 85 db             	test   %rbx,%rbx
    47f7:	74 1f                	je     4818 <fwp_data.part.0.constprop.0+0xf8>
    47f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    47fd:	48 29 da             	sub    %rbx,%rdx
    4800:	48 39 ea             	cmp    %rbp,%rdx
    4803:	72 13                	jb     4818 <fwp_data.part.0.constprop.0+0xf8>
    4805:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4809:	48 89 50 08          	mov    %rdx,0x8(%rax)
    480d:	e9 55 ff ff ff       	jmp    4767 <fwp_data.part.0.constprop.0+0x47>
    4812:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4818:	31 f6                	xor    %esi,%esi
    481a:	bf 18 00 00 00       	mov    $0x18,%edi
    481f:	e8 dc fd ff ff       	call   4600 <fwp_heap_alloc>
    4824:	48 89 c3             	mov    %rax,%rbx
    4827:	eb 9f                	jmp    47c8 <fwp_data.part.0.constprop.0+0xa8>
    4829:	e8 d2 e3 ff ff       	call   2c00 <fwp_heap_oom>
    482e:	66 90                	xchg   %ax,%ax

0000000000004830 <fwp_array_new_packed.constprop.0>:
    4830:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4837:	ff ff 1f 
    483a:	53                   	push   %rbx
    483b:	48 39 f8             	cmp    %rdi,%rax
    483e:	72 1a                	jb     485a <fwp_array_new_packed.constprop.0+0x2a>
    4840:	48 89 fb             	mov    %rdi,%rbx
    4843:	be 01 00 00 00       	mov    $0x1,%esi
    4848:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    484f:	00 
    4850:	e8 ab fd ff ff       	call   4600 <fwp_heap_alloc>
    4855:	48 89 18             	mov    %rbx,(%rax)
    4858:	5b                   	pop    %rbx
    4859:	c3                   	ret
    485a:	48 8d 3d 44 68 00 00 	lea    0x6844(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    4861:	e8 4a e8 ff ff       	call   30b0 <fwp_trap>
    4866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    486d:	00 00 00 

0000000000004870 <fwp_task_dispose>:
    4870:	53                   	push   %rbx
    4871:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4875:	0f 84 8b de ff ff    	je     2706 <fwp_task_dispose.cold>
    487b:	48 89 fb             	mov    %rdi,%rbx
    487e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4883:	0f 85 7d de ff ff    	jne    2706 <fwp_task_dispose.cold>
    4889:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    488d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4894:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    489b:	00 
    489c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    48a0:	48 85 ff             	test   %rdi,%rdi
    48a3:	74 07                	je     48ac <fwp_task_dispose+0x3c>
    48a5:	48 85 c0             	test   %rax,%rax
    48a8:	74 02                	je     48ac <fwp_task_dispose+0x3c>
    48aa:	ff d0                	call   *%rax
    48ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    48b3:	e8 18 f7 ff ff       	call   3fd0 <fwp_mem_free>
    48b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    48bf:	00 00 00 00 
    48c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    48c7:	74 6f                	je     4938 <fwp_task_dispose+0xc8>
    48c9:	48 8b 15 28 a2 01 00 	mov    0x1a228(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    48d0:	48 89 d8             	mov    %rbx,%rax
    48d3:	48 2b 05 f6 a1 01 00 	sub    0x1a1f6(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    48da:	48 c1 e2 10          	shl    $0x10,%rdx
    48de:	48 39 d0             	cmp    %rdx,%rax
    48e1:	73 4c                	jae    492f <fwp_task_dispose+0xbf>
    48e3:	48 89 c2             	mov    %rax,%rdx
    48e6:	48 c1 ea 10          	shr    $0x10,%rdx
    48ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    48ee:	48 8b 15 23 a2 01 00 	mov    0x1a223(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    48f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    48f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    48fd:	48 85 c9             	test   %rcx,%rcx
    4900:	74 2d                	je     492f <fwp_task_dispose+0xbf>
    4902:	0f b6 32             	movzbl (%rdx),%esi
    4905:	40 80 fe 02          	cmp    $0x2,%sil
    4909:	74 3d                	je     4948 <fwp_task_dispose+0xd8>
    490b:	40 80 fe 01          	cmp    $0x1,%sil
    490f:	75 1e                	jne    492f <fwp_task_dispose+0xbf>
    4911:	8b 72 18             	mov    0x18(%rdx),%esi
    4914:	0f b7 c0             	movzwl %ax,%eax
    4917:	8b 52 1c             	mov    0x1c(%rdx),%edx
    491a:	48 0f af c6          	imul   %rsi,%rax
    491e:	48 c1 e8 20          	shr    $0x20,%rax
    4922:	48 39 d0             	cmp    %rdx,%rax
    4925:	73 08                	jae    492f <fwp_task_dispose+0xbf>
    4927:	48 01 c1             	add    %rax,%rcx
    492a:	80 39 01             	cmpb   $0x1,(%rcx)
    492d:	74 09                	je     4938 <fwp_task_dispose+0xc8>
    492f:	5b                   	pop    %rbx
    4930:	c3                   	ret
    4931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4938:	48 89 df             	mov    %rbx,%rdi
    493b:	5b                   	pop    %rbx
    493c:	e9 8f f6 ff ff       	jmp    3fd0 <fwp_mem_free>
    4941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4948:	66 85 c0             	test   %ax,%ax
    494b:	74 dd                	je     492a <fwp_task_dispose+0xba>
    494d:	5b                   	pop    %rbx
    494e:	c3                   	ret
    494f:	90                   	nop

0000000000004950 <fwp_free_zombie>:
    4950:	48 8b 15 99 8d 01 00 	mov    0x18d99(%rip),%rdx        # 1d6f0 <fwp_zombie>
    4957:	48 85 d2             	test   %rdx,%rdx
    495a:	0f 84 98 00 00 00    	je     49f8 <fwp_free_zombie+0xa8>
    4960:	48 3b 15 99 8d 01 00 	cmp    0x18d99(%rip),%rdx        # 1d700 <fwp_cur>
    4967:	0f 84 8b 00 00 00    	je     49f8 <fwp_free_zombie+0xa8>
    496d:	48 83 ec 18          	sub    $0x18,%rsp
    4971:	48 63 05 64 87 01 00 	movslq 0x18764(%rip),%rax        # 1d0dc <fwp_stack_pool_n>
    4978:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    497c:	83 f8 3f             	cmp    $0x3f,%eax
    497f:	7f 7f                	jg     4a00 <fwp_free_zombie+0xb0>
    4981:	8d 48 01             	lea    0x1(%rax),%ecx
    4984:	89 0d 52 87 01 00    	mov    %ecx,0x18752(%rip)        # 1d0dc <fwp_stack_pool_n>
    498a:	48 8d 0d 4f 87 01 00 	lea    0x1874f(%rip),%rcx        # 1d0e0 <fwp_stack_pool>
    4991:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4995:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    499c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    49a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    49ab:	48 85 c9             	test   %rcx,%rcx
    49ae:	0f 84 fc 00 00 00    	je     4ab0 <fwp_free_zombie+0x160>
    49b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    49bb:	48 85 c0             	test   %rax,%rax
    49be:	74 07                	je     49c7 <fwp_free_zombie+0x77>
    49c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    49c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    49ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49ce:	48 c7 05 17 8d 01 00 	movq   $0x0,0x18d17(%rip)        # 1d6f0 <fwp_zombie>
    49d5:	00 00 00 00 
    49d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    49e0:	85 c0                	test   %eax,%eax
    49e2:	74 34                	je     4a18 <fwp_free_zombie+0xc8>
    49e4:	83 f8 01             	cmp    $0x1,%eax
    49e7:	0f 84 b3 00 00 00    	je     4aa0 <fwp_free_zombie+0x150>
    49ed:	48 83 c4 18          	add    $0x18,%rsp
    49f1:	c3                   	ret
    49f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    49f8:	c3                   	ret
    49f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a00:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4a04:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4a09:	e8 a2 db ff ff       	call   25b0 <munmap@plt>
    4a0e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4a13:	eb 80                	jmp    4995 <fwp_free_zombie+0x45>
    4a15:	0f 1f 00             	nopl   (%rax)
    4a18:	48 8b 0d d9 a0 01 00 	mov    0x1a0d9(%rip),%rcx        # 1eaf8 <fwp_heap+0x13d8>
    4a1f:	48 89 d0             	mov    %rdx,%rax
    4a22:	48 2b 05 a7 a0 01 00 	sub    0x1a0a7(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    4a29:	48 c1 e1 10          	shl    $0x10,%rcx
    4a2d:	48 39 c8             	cmp    %rcx,%rax
    4a30:	73 bb                	jae    49ed <fwp_free_zombie+0x9d>
    4a32:	48 89 c1             	mov    %rax,%rcx
    4a35:	48 c1 e9 10          	shr    $0x10,%rcx
    4a39:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4a3d:	48 8b 0d d4 a0 01 00 	mov    0x1a0d4(%rip),%rcx        # 1eb18 <fwp_heap+0x13f8>
    4a44:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4a48:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4a4c:	48 85 c9             	test   %rcx,%rcx
    4a4f:	74 9c                	je     49ed <fwp_free_zombie+0x9d>
    4a51:	0f b6 3e             	movzbl (%rsi),%edi
    4a54:	40 80 ff 02          	cmp    $0x2,%dil
    4a58:	74 66                	je     4ac0 <fwp_free_zombie+0x170>
    4a5a:	40 80 ff 01          	cmp    $0x1,%dil
    4a5e:	75 8d                	jne    49ed <fwp_free_zombie+0x9d>
    4a60:	8b 7e 18             	mov    0x18(%rsi),%edi
    4a63:	0f b7 c0             	movzwl %ax,%eax
    4a66:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4a69:	48 0f af c7          	imul   %rdi,%rax
    4a6d:	48 c1 e8 20          	shr    $0x20,%rax
    4a71:	48 39 f0             	cmp    %rsi,%rax
    4a74:	0f 83 73 ff ff ff    	jae    49ed <fwp_free_zombie+0x9d>
    4a7a:	48 01 c1             	add    %rax,%rcx
    4a7d:	0f b6 01             	movzbl (%rcx),%eax
    4a80:	84 c0                	test   %al,%al
    4a82:	0f 84 65 ff ff ff    	je     49ed <fwp_free_zombie+0x9d>
    4a88:	3c 01                	cmp    $0x1,%al
    4a8a:	74 14                	je     4aa0 <fwp_free_zombie+0x150>
    4a8c:	3c ff                	cmp    $0xff,%al
    4a8e:	74 3b                	je     4acb <fwp_free_zombie+0x17b>
    4a90:	83 e8 01             	sub    $0x1,%eax
    4a93:	88 01                	mov    %al,(%rcx)
    4a95:	e9 53 ff ff ff       	jmp    49ed <fwp_free_zombie+0x9d>
    4a9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa0:	48 89 d7             	mov    %rdx,%rdi
    4aa3:	48 83 c4 18          	add    $0x18,%rsp
    4aa7:	e9 c4 fd ff ff       	jmp    4870 <fwp_task_dispose>
    4aac:	0f 1f 40 00          	nopl   0x0(%rax)
    4ab0:	48 89 05 11 8c 01 00 	mov    %rax,0x18c11(%rip)        # 1d6c8 <fwp_tasks_active>
    4ab7:	e9 ff fe ff ff       	jmp    49bb <fwp_free_zombie+0x6b>
    4abc:	0f 1f 40 00          	nopl   0x0(%rax)
    4ac0:	66 85 c0             	test   %ax,%ax
    4ac3:	0f 85 24 ff ff ff    	jne    49ed <fwp_free_zombie+0x9d>
    4ac9:	eb b2                	jmp    4a7d <fwp_free_zombie+0x12d>
    4acb:	48 89 ca             	mov    %rcx,%rdx
    4ace:	48 8d 35 4b 8c 01 00 	lea    0x18c4b(%rip),%rsi        # 1d720 <fwp_heap>
    4ad5:	48 c1 ea 11          	shr    $0x11,%rdx
    4ad9:	48 31 ca             	xor    %rcx,%rdx
    4adc:	48 89 d0             	mov    %rdx,%rax
    4adf:	48 c1 e8 09          	shr    $0x9,%rax
    4ae3:	48 31 c2             	xor    %rax,%rdx
    4ae6:	0f b6 d2             	movzbl %dl,%edx
    4ae9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4af0:	00 
    4af1:	48 85 c0             	test   %rax,%rax
    4af4:	75 13                	jne    4b09 <fwp_free_zombie+0x1b9>
    4af6:	eb 4c                	jmp    4b44 <fwp_free_zombie+0x1f4>
    4af8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aff:	00 
    4b00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4b04:	48 85 c0             	test   %rax,%rax
    4b07:	74 3b                	je     4b44 <fwp_free_zombie+0x1f4>
    4b09:	48 89 c2             	mov    %rax,%rdx
    4b0c:	48 39 08             	cmp    %rcx,(%rax)
    4b0f:	75 ef                	jne    4b00 <fwp_free_zombie+0x1b0>
    4b11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4b19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4b1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4b24:	0f 85 c3 fe ff ff    	jne    49ed <fwp_free_zombie+0x9d>
    4b2a:	48 89 cf             	mov    %rcx,%rdi
    4b2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4b32:	e8 59 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4b37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4b3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4b3f:	e9 a9 fe ff ff       	jmp    49ed <fwp_free_zombie+0x9d>
    4b44:	48 8d 3d 3d 67 00 00 	lea    0x673d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4b4b:	e8 60 e5 ff ff       	call   30b0 <fwp_trap>

0000000000004b50 <fwp_block>:
    4b50:	48 83 ec 08          	sub    $0x8,%rsp
    4b54:	48 8b 05 8d 8b 01 00 	mov    0x18b8d(%rip),%rax        # 1d6e8 <fwp_ready_head>
    4b5b:	48 85 c0             	test   %rax,%rax
    4b5e:	0f 84 1c 01 00 00    	je     4c80 <fwp_block+0x130>
    4b64:	90                   	nop
    4b65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b6c:	00 00 00 00 
    4b70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4b77:	48 89 15 6a 8b 01 00 	mov    %rdx,0x18b6a(%rip)        # 1d6e8 <fwp_ready_head>
    4b7e:	48 85 d2             	test   %rdx,%rdx
    4b81:	0f 84 19 01 00 00    	je     4ca0 <fwp_block+0x150>
    4b87:	48 8b 15 72 8b 01 00 	mov    0x18b72(%rip),%rdx        # 1d700 <fwp_cur>
    4b8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b92:	48 39 c2             	cmp    %rax,%rdx
    4b95:	0f 84 d5 00 00 00    	je     4c70 <fwp_block+0x120>
    4b9b:	48 8b 0d de a7 01 00 	mov    0x1a7de(%rip),%rcx        # 1f380 <fwp_state_owners>
    4ba2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4ba6:	48 89 05 53 8b 01 00 	mov    %rax,0x18b53(%rip)        # 1d700 <fwp_cur>
    4bad:	f3 0f 7e 05 f3 a7 01 	movq   0x1a7f3(%rip),%xmm0        # 1f3a8 <fwp_foreign_callbacks>
    4bb4:	00 
    4bb5:	0f 16 05 dc a7 01 00 	movhps 0x1a7dc(%rip),%xmm0        # 1f398 <fwp_state>
    4bbc:	f3 0f 7e 0d dc a7 01 	movq   0x1a7dc(%rip),%xmm1        # 1f3a0 <fwp_handlers>
    4bc3:	00 
    4bc4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4bcb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4bd2:	0f 16 0d d7 a7 01 00 	movhps 0x1a7d7(%rip),%xmm1        # 1f3b0 <fwp_cleanups>
    4bd9:	f3 0f 7e 05 af a7 01 	movq   0x1a7af(%rip),%xmm0        # 1f390 <fwp_state_len>
    4be0:	00 
    4be1:	0f 16 05 a0 a7 01 00 	movhps 0x1a7a0(%rip),%xmm0        # 1f388 <fwp_state_cap>
    4be8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4bef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4bf6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4bfa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4c01:	48 89 0d 98 a7 01 00 	mov    %rcx,0x1a798(%rip)        # 1f3a0 <fwp_handlers>
    4c08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4c0f:	48 89 0d 9a a7 01 00 	mov    %rcx,0x1a79a(%rip)        # 1f3b0 <fwp_cleanups>
    4c16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4c1d:	48 89 0d 84 a7 01 00 	mov    %rcx,0x1a784(%rip)        # 1f3a8 <fwp_foreign_callbacks>
    4c24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4c2b:	48 89 0d 66 a7 01 00 	mov    %rcx,0x1a766(%rip)        # 1f398 <fwp_state>
    4c32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4c39:	48 89 0d 50 a7 01 00 	mov    %rcx,0x1a750(%rip)        # 1f390 <fwp_state_len>
    4c40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4c47:	48 89 0d 3a a7 01 00 	mov    %rcx,0x1a73a(%rip)        # 1f388 <fwp_state_cap>
    4c4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4c55:	48 89 0d 24 a7 01 00 	mov    %rcx,0x1a724(%rip)        # 1f380 <fwp_state_owners>
    4c5c:	e8 0f d8 ff ff       	call   2470 <swapcontext@plt>
    4c61:	f3 0f 1e fa          	endbr64
    4c65:	e8 e6 fc ff ff       	call   4950 <fwp_free_zombie>
    4c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c70:	8b 05 62 84 01 00    	mov    0x18462(%rip),%eax        # 1d0d8 <fwp_slice>
    4c76:	85 c0                	test   %eax,%eax
    4c78:	74 36                	je     4cb0 <fwp_block+0x160>
    4c7a:	48 83 c4 08          	add    $0x8,%rsp
    4c7e:	c3                   	ret
    4c7f:	90                   	nop
    4c80:	e8 6b ee ff ff       	call   3af0 <fwp_poll_events>
    4c85:	48 8b 05 5c 8a 01 00 	mov    0x18a5c(%rip),%rax        # 1d6e8 <fwp_ready_head>
    4c8c:	48 85 c0             	test   %rax,%rax
    4c8f:	0f 85 db fe ff ff    	jne    4b70 <fwp_block+0x20>
    4c95:	eb e9                	jmp    4c80 <fwp_block+0x130>
    4c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c9e:	00 00 
    4ca0:	48 c7 05 35 8a 01 00 	movq   $0x0,0x18a35(%rip)        # 1d6e0 <fwp_ready_tail>
    4ca7:	00 00 00 00 
    4cab:	e9 d7 fe ff ff       	jmp    4b87 <fwp_block+0x37>
    4cb0:	48 8d 3d fe 63 00 00 	lea    0x63fe(%rip),%rdi        # b0b5 <_IO_stdin_used+0xb5>
    4cb7:	e8 c4 d6 ff ff       	call   2380 <getenv@plt>
    4cbc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4cc1:	48 85 c0             	test   %rax,%rax
    4cc4:	74 05                	je     4ccb <fwp_block+0x17b>
    4cc6:	80 38 00             	cmpb   $0x0,(%rax)
    4cc9:	75 0b                	jne    4cd6 <fwp_block+0x186>
    4ccb:	89 15 07 84 01 00    	mov    %edx,0x18407(%rip)        # 1d0d8 <fwp_slice>
    4cd1:	48 83 c4 08          	add    $0x8,%rsp
    4cd5:	c3                   	ret
    4cd6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4cdb:	31 f6                	xor    %esi,%esi
    4cdd:	48 89 c7             	mov    %rax,%rdi
    4ce0:	e8 4b d8 ff ff       	call   2530 <strtoll@plt>
    4ce5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4ce9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4cf0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4cf5:	0f 46 d0             	cmovbe %eax,%edx
    4cf8:	eb d1                	jmp    4ccb <fwp_block+0x17b>
    4cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004d00 <fwp_drop0>:
    4d00:	48 8b 15 f1 9d 01 00 	mov    0x19df1(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    4d07:	48 89 f8             	mov    %rdi,%rax
    4d0a:	48 2b 05 bf 9d 01 00 	sub    0x19dbf(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    4d11:	48 c1 e2 10          	shl    $0x10,%rdx
    4d15:	48 39 d0             	cmp    %rdx,%rax
    4d18:	0f 83 c2 00 00 00    	jae    4de0 <fwp_drop0+0xe0>
    4d1e:	48 83 ec 18          	sub    $0x18,%rsp
    4d22:	4c 8d 05 f7 89 01 00 	lea    0x189f7(%rip),%r8        # 1d720 <fwp_heap>
    4d29:	48 89 c2             	mov    %rax,%rdx
    4d2c:	48 c1 ea 10          	shr    $0x10,%rdx
    4d30:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4d34:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4d3b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4d3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4d43:	48 85 d2             	test   %rdx,%rdx
    4d46:	74 3c                	je     4d84 <fwp_drop0+0x84>
    4d48:	0f b6 31             	movzbl (%rcx),%esi
    4d4b:	40 80 fe 02          	cmp    $0x2,%sil
    4d4f:	74 3f                	je     4d90 <fwp_drop0+0x90>
    4d51:	40 80 fe 01          	cmp    $0x1,%sil
    4d55:	75 2d                	jne    4d84 <fwp_drop0+0x84>
    4d57:	8b 71 18             	mov    0x18(%rcx),%esi
    4d5a:	0f b7 c0             	movzwl %ax,%eax
    4d5d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4d60:	48 0f af c6          	imul   %rsi,%rax
    4d64:	48 c1 e8 20          	shr    $0x20,%rax
    4d68:	48 39 c8             	cmp    %rcx,%rax
    4d6b:	73 17                	jae    4d84 <fwp_drop0+0x84>
    4d6d:	48 01 c2             	add    %rax,%rdx
    4d70:	0f b6 02             	movzbl (%rdx),%eax
    4d73:	84 c0                	test   %al,%al
    4d75:	74 0d                	je     4d84 <fwp_drop0+0x84>
    4d77:	3c 01                	cmp    $0x1,%al
    4d79:	74 25                	je     4da0 <fwp_drop0+0xa0>
    4d7b:	3c ff                	cmp    $0xff,%al
    4d7d:	74 69                	je     4de8 <fwp_drop0+0xe8>
    4d7f:	83 e8 01             	sub    $0x1,%eax
    4d82:	88 02                	mov    %al,(%rdx)
    4d84:	48 83 c4 18          	add    $0x18,%rsp
    4d88:	c3                   	ret
    4d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d90:	66 85 c0             	test   %ax,%ax
    4d93:	74 db                	je     4d70 <fwp_drop0+0x70>
    4d95:	48 83 c4 18          	add    $0x18,%rsp
    4d99:	c3                   	ret
    4d9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4da0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4da4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4da9:	e8 d2 f7 ff ff       	call   4580 <fwp_rc_free_arr>
    4dae:	4c 8d 05 6b 89 01 00 	lea    0x1896b(%rip),%r8        # 1d720 <fwp_heap>
    4db5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4dba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4dc1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4dc8:	48 c1 e2 10          	shl    $0x10,%rdx
    4dcc:	48 39 d0             	cmp    %rdx,%rax
    4dcf:	73 b3                	jae    4d84 <fwp_drop0+0x84>
    4dd1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4dd6:	e9 4e ff ff ff       	jmp    4d29 <fwp_drop0+0x29>
    4ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4de0:	c3                   	ret
    4de1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4de8:	48 89 d0             	mov    %rdx,%rax
    4deb:	48 c1 e8 11          	shr    $0x11,%rax
    4def:	48 31 d0             	xor    %rdx,%rax
    4df2:	48 89 c1             	mov    %rax,%rcx
    4df5:	48 c1 e9 09          	shr    $0x9,%rcx
    4df9:	48 31 c8             	xor    %rcx,%rax
    4dfc:	0f b6 c8             	movzbl %al,%ecx
    4dff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4e06:	00 
    4e07:	48 85 c0             	test   %rax,%rax
    4e0a:	75 1d                	jne    4e29 <fwp_drop0+0x129>
    4e0c:	eb 56                	jmp    4e64 <fwp_drop0+0x164>
    4e0e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e1c:	00 00 00 00 
    4e20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4e24:	48 85 c0             	test   %rax,%rax
    4e27:	74 3b                	je     4e64 <fwp_drop0+0x164>
    4e29:	48 89 c1             	mov    %rax,%rcx
    4e2c:	48 39 10             	cmp    %rdx,(%rax)
    4e2f:	75 ef                	jne    4e20 <fwp_drop0+0x120>
    4e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4e35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4e39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4e3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4e44:	0f 85 3a ff ff ff    	jne    4d84 <fwp_drop0+0x84>
    4e4a:	48 89 d7             	mov    %rdx,%rdi
    4e4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4e52:	e8 39 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4e57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4e5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4e5f:	e9 20 ff ff ff       	jmp    4d84 <fwp_drop0+0x84>
    4e64:	48 8d 3d 1d 64 00 00 	lea    0x641d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4e6b:	e8 40 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004e70 <fwp_drop1>:
    4e70:	f3 0f 1e fa          	endbr64
    4e74:	48 8b 15 7d 9c 01 00 	mov    0x19c7d(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    4e7b:	48 89 f8             	mov    %rdi,%rax
    4e7e:	48 2b 05 4b 9c 01 00 	sub    0x19c4b(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    4e85:	48 c1 e2 10          	shl    $0x10,%rdx
    4e89:	48 39 d0             	cmp    %rdx,%rax
    4e8c:	0f 83 be 00 00 00    	jae    4f50 <fwp_drop1+0xe0>
    4e92:	48 83 ec 18          	sub    $0x18,%rsp
    4e96:	4c 8d 05 83 88 01 00 	lea    0x18883(%rip),%r8        # 1d720 <fwp_heap>
    4e9d:	48 89 c2             	mov    %rax,%rdx
    4ea0:	48 c1 ea 10          	shr    $0x10,%rdx
    4ea4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4ea8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4eaf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4eb3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4eb7:	48 85 d2             	test   %rdx,%rdx
    4eba:	74 3c                	je     4ef8 <fwp_drop1+0x88>
    4ebc:	0f b6 31             	movzbl (%rcx),%esi
    4ebf:	40 80 fe 02          	cmp    $0x2,%sil
    4ec3:	74 3b                	je     4f00 <fwp_drop1+0x90>
    4ec5:	40 80 fe 01          	cmp    $0x1,%sil
    4ec9:	75 2d                	jne    4ef8 <fwp_drop1+0x88>
    4ecb:	8b 71 18             	mov    0x18(%rcx),%esi
    4ece:	0f b7 c0             	movzwl %ax,%eax
    4ed1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4ed4:	48 0f af c6          	imul   %rsi,%rax
    4ed8:	48 c1 e8 20          	shr    $0x20,%rax
    4edc:	48 39 c8             	cmp    %rcx,%rax
    4edf:	73 17                	jae    4ef8 <fwp_drop1+0x88>
    4ee1:	48 01 c2             	add    %rax,%rdx
    4ee4:	0f b6 02             	movzbl (%rdx),%eax
    4ee7:	84 c0                	test   %al,%al
    4ee9:	74 0d                	je     4ef8 <fwp_drop1+0x88>
    4eeb:	3c 01                	cmp    $0x1,%al
    4eed:	74 21                	je     4f10 <fwp_drop1+0xa0>
    4eef:	3c ff                	cmp    $0xff,%al
    4ef1:	74 65                	je     4f58 <fwp_drop1+0xe8>
    4ef3:	83 e8 01             	sub    $0x1,%eax
    4ef6:	88 02                	mov    %al,(%rdx)
    4ef8:	48 83 c4 18          	add    $0x18,%rsp
    4efc:	c3                   	ret
    4efd:	0f 1f 00             	nopl   (%rax)
    4f00:	66 85 c0             	test   %ax,%ax
    4f03:	74 df                	je     4ee4 <fwp_drop1+0x74>
    4f05:	48 83 c4 18          	add    $0x18,%rsp
    4f09:	c3                   	ret
    4f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f10:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4f14:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4f19:	e8 62 f6 ff ff       	call   4580 <fwp_rc_free_arr>
    4f1e:	4c 8d 05 fb 87 01 00 	lea    0x187fb(%rip),%r8        # 1d720 <fwp_heap>
    4f25:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4f2a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4f31:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4f38:	48 c1 e2 10          	shl    $0x10,%rdx
    4f3c:	48 39 d0             	cmp    %rdx,%rax
    4f3f:	73 b7                	jae    4ef8 <fwp_drop1+0x88>
    4f41:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4f46:	e9 52 ff ff ff       	jmp    4e9d <fwp_drop1+0x2d>
    4f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f50:	c3                   	ret
    4f51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f58:	48 89 d0             	mov    %rdx,%rax
    4f5b:	48 c1 e8 11          	shr    $0x11,%rax
    4f5f:	48 31 d0             	xor    %rdx,%rax
    4f62:	48 89 c1             	mov    %rax,%rcx
    4f65:	48 c1 e9 09          	shr    $0x9,%rcx
    4f69:	48 31 c8             	xor    %rcx,%rax
    4f6c:	0f b6 c8             	movzbl %al,%ecx
    4f6f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4f76:	00 
    4f77:	48 85 c0             	test   %rax,%rax
    4f7a:	75 0d                	jne    4f89 <fwp_drop1+0x119>
    4f7c:	eb 46                	jmp    4fc4 <fwp_drop1+0x154>
    4f7e:	66 90                	xchg   %ax,%ax
    4f80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4f84:	48 85 c0             	test   %rax,%rax
    4f87:	74 3b                	je     4fc4 <fwp_drop1+0x154>
    4f89:	48 89 c1             	mov    %rax,%rcx
    4f8c:	48 39 10             	cmp    %rdx,(%rax)
    4f8f:	75 ef                	jne    4f80 <fwp_drop1+0x110>
    4f91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4f95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4f99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4f9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4fa4:	0f 85 4e ff ff ff    	jne    4ef8 <fwp_drop1+0x88>
    4faa:	48 89 d7             	mov    %rdx,%rdi
    4fad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4fb2:	e8 d9 ed ff ff       	call   3d90 <fwp_rc_forget_slot>
    4fb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4fbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4fbf:	e9 34 ff ff ff       	jmp    4ef8 <fwp_drop1+0x88>
    4fc4:	48 8d 3d bd 62 00 00 	lea    0x62bd(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4fcb:	e8 e0 e0 ff ff       	call   30b0 <fwp_trap>

0000000000004fd0 <fwp_write.constprop.0>:
    4fd0:	41 57                	push   %r15
    4fd2:	41 56                	push   %r14
    4fd4:	41 55                	push   %r13
    4fd6:	41 54                	push   %r12
    4fd8:	55                   	push   %rbp
    4fd9:	53                   	push   %rbx
    4fda:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    4fe1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    4fe8:	00 00 
    4fea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    4ff1:	00 
    4ff2:	49 89 d4             	mov    %rdx,%r12
    4ff5:	8b 12                	mov    (%rdx),%edx
    4ff7:	83 fa 19             	cmp    $0x19,%edx
    4ffa:	77 64                	ja     5060 <fwp_write.constprop.0+0x90>
    4ffc:	48 8d 0d cd 63 00 00 	lea    0x63cd(%rip),%rcx        # b3d0 <_IO_stdin_used+0x3d0>
    5003:	89 d0                	mov    %edx,%eax
    5005:	48 89 fb             	mov    %rdi,%rbx
    5008:	48 89 f5             	mov    %rsi,%rbp
    500b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    500f:	48 01 c8             	add    %rcx,%rax
    5012:	3e ff e0             	notrack jmp *%rax
    5015:	0f 1f 00             	nopl   (%rax)
    5018:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    501c:	48 8b 06             	mov    (%rsi),%rax
    501f:	48 89 ca             	mov    %rcx,%rdx
    5022:	48 85 c9             	test   %rcx,%rcx
    5025:	0f 88 b5 0c 00 00    	js     5ce0 <fwp_write.constprop.0+0xd10>
    502b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5032:	00 
    5033:	48 89 c6             	mov    %rax,%rsi
    5036:	4c 89 e7             	mov    %r12,%rdi
    5039:	e8 c2 d9 ff ff       	call   2a00 <fwp_fmt_u128>
    503e:	66 90                	xchg   %ax,%ax
    5040:	4c 89 e7             	mov    %r12,%rdi
    5043:	e8 e8 d3 ff ff       	call   2430 <strlen@plt>
    5048:	4c 89 e6             	mov    %r12,%rsi
    504b:	48 89 df             	mov    %rbx,%rdi
    504e:	48 89 c2             	mov    %rax,%rdx
    5051:	e8 2a df ff ff       	call   2f80 <buf_put>
    5056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    505d:	00 00 00 
    5060:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5067:	00 
    5068:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    506f:	00 00 
    5071:	0f 85 9e 04 00 00    	jne    5515 <fwp_write.constprop.0+0x545>
    5077:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    507e:	5b                   	pop    %rbx
    507f:	5d                   	pop    %rbp
    5080:	41 5c                	pop    %r12
    5082:	41 5d                	pop    %r13
    5084:	41 5e                	pop    %r14
    5086:	41 5f                	pop    %r15
    5088:	c3                   	ret
    5089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5090:	49 89 f1             	mov    %rsi,%r9
    5093:	4c 8d 05 43 60 00 00 	lea    0x6043(%rip),%r8        # b0dd <_IO_stdin_used+0xdd>
    509a:	b9 00 02 00 00       	mov    $0x200,%ecx
    509f:	ba 02 00 00 00       	mov    $0x2,%edx
    50a4:	be 00 02 00 00       	mov    $0x200,%esi
    50a9:	31 c0                	xor    %eax,%eax
    50ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50b2:	00 
    50b3:	e8 d8 d2 ff ff       	call   2390 <__snprintf_chk@plt>
    50b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50bf:	00 
    50c0:	e8 6b d3 ff ff       	call   2430 <strlen@plt>
    50c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    50cc:	00 
    50cd:	48 89 df             	mov    %rbx,%rdi
    50d0:	48 89 c2             	mov    %rax,%rdx
    50d3:	e8 a8 de ff ff       	call   2f80 <buf_put>
    50d8:	eb 86                	jmp    5060 <fwp_write.constprop.0+0x90>
    50da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50e0:	49 89 f1             	mov    %rsi,%r9
    50e3:	4c 8d 05 ee 5f 00 00 	lea    0x5fee(%rip),%r8        # b0d8 <_IO_stdin_used+0xd8>
    50ea:	eb ae                	jmp    509a <fwp_write.constprop.0+0xca>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	83 fa 13             	cmp    $0x13,%edx
    50f3:	48 8d 05 d4 5f 00 00 	lea    0x5fd4(%rip),%rax        # b0ce <_IO_stdin_used+0xce>
    50fa:	48 8d 35 d2 5f 00 00 	lea    0x5fd2(%rip),%rsi        # b0d3 <_IO_stdin_used+0xd3>
    5101:	ba 04 00 00 00       	mov    $0x4,%edx
    5106:	48 0f 44 f0          	cmove  %rax,%rsi
    510a:	45 31 ed             	xor    %r13d,%r13d
    510d:	e8 6e de ff ff       	call   2f80 <buf_put>
    5112:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5117:	0f 84 b3 09 00 00    	je     5ad0 <fwp_write.constprop.0+0xb00>
    511d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5122:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5127:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    512c:	48 89 df             	mov    %rbx,%rdi
    512f:	49 0f 44 c5          	cmove  %r13,%rax
    5133:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5138:	e8 93 fe ff ff       	call   4fd0 <fwp_write.constprop.0>
    513d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5142:	0f 84 80 0a 00 00    	je     5bc8 <fwp_write.constprop.0+0xbf8>
    5148:	49 83 c5 01          	add    $0x1,%r13
    514c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5150:	0f 83 7a 09 00 00    	jae    5ad0 <fwp_write.constprop.0+0xb00>
    5156:	ba 02 00 00 00       	mov    $0x2,%edx
    515b:	48 8d 35 bb 5f 00 00 	lea    0x5fbb(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5162:	48 89 df             	mov    %rbx,%rdi
    5165:	e8 16 de ff ff       	call   2f80 <buf_put>
    516a:	eb b1                	jmp    511d <fwp_write.constprop.0+0x14d>
    516c:	0f 1f 40 00          	nopl   0x0(%rax)
    5170:	ba 06 00 00 00       	mov    $0x6,%edx
    5175:	48 8d 35 7a 5f 00 00 	lea    0x5f7a(%rip),%rsi        # b0f6 <_IO_stdin_used+0xf6>
    517c:	48 83 c5 10          	add    $0x10,%rbp
    5180:	e8 fb dd ff ff       	call   2f80 <buf_put>
    5185:	48 89 ef             	mov    %rbp,%rdi
    5188:	e8 a3 d2 ff ff       	call   2430 <strlen@plt>
    518d:	48 89 ee             	mov    %rbp,%rsi
    5190:	48 89 df             	mov    %rbx,%rdi
    5193:	48 89 c2             	mov    %rax,%rdx
    5196:	e8 e5 dd ff ff       	call   2f80 <buf_put>
    519b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51a0:	ba 01 00 00 00       	mov    $0x1,%edx
    51a5:	48 89 df             	mov    %rbx,%rdi
    51a8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    51ad:	e8 ce dd ff ff       	call   2f80 <buf_put>
    51b2:	e9 a9 fe ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    51c7:	00 
    51c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51cf:	00 00 
    51d1:	0f 85 3e 03 00 00    	jne    5515 <fwp_write.constprop.0+0x545>
    51d7:	ba 0a 00 00 00       	mov    $0xa,%edx
    51dc:	48 8d 35 ff 5e 00 00 	lea    0x5eff(%rip),%rsi        # b0e2 <_IO_stdin_used+0xe2>
    51e3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    51ea:	48 89 df             	mov    %rbx,%rdi
    51ed:	5b                   	pop    %rbx
    51ee:	5d                   	pop    %rbp
    51ef:	41 5c                	pop    %r12
    51f1:	41 5d                	pop    %r13
    51f3:	41 5e                	pop    %r14
    51f5:	41 5f                	pop    %r15
    51f7:	e9 84 dd ff ff       	jmp    2f80 <buf_put>
    51fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5200:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5205:	4d 85 ed             	test   %r13,%r13
    5208:	0f 84 c2 0b 00 00    	je     5dd0 <fwp_write.constprop.0+0xe00>
    520e:	48 8d 35 15 5f 00 00 	lea    0x5f15(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5215:	4c 89 ef             	mov    %r13,%rdi
    5218:	e8 f3 d2 ff ff       	call   2510 <strcmp@plt>
    521d:	41 89 c1             	mov    %eax,%r9d
    5220:	85 c0                	test   %eax,%eax
    5222:	0f 84 2c 0c 00 00    	je     5e54 <fwp_write.constprop.0+0xe84>
    5228:	4c 89 ef             	mov    %r13,%rdi
    522b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5230:	e8 fb d1 ff ff       	call   2430 <strlen@plt>
    5235:	4c 89 ee             	mov    %r13,%rsi
    5238:	48 89 df             	mov    %rbx,%rdi
    523b:	48 89 c2             	mov    %rax,%rdx
    523e:	e8 3d dd ff ff       	call   2f80 <buf_put>
    5243:	ba 01 00 00 00       	mov    $0x1,%edx
    5248:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    524d:	48 89 df             	mov    %rbx,%rdi
    5250:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5255:	e8 26 dd ff ff       	call   2f80 <buf_put>
    525a:	ba 01 00 00 00       	mov    $0x1,%edx
    525f:	4c 89 fe             	mov    %r15,%rsi
    5262:	48 89 df             	mov    %rbx,%rdi
    5265:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    526a:	e8 11 dd ff ff       	call   2f80 <buf_put>
    526f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5274:	45 31 f6             	xor    %r14d,%r14d
    5277:	85 c0                	test   %eax,%eax
    5279:	0f 8e 91 0a 00 00    	jle    5d10 <fwp_write.constprop.0+0xd40>
    527f:	45 31 ed             	xor    %r13d,%r13d
    5282:	4d 85 ed             	test   %r13,%r13
    5285:	0f 85 d5 08 00 00    	jne    5b60 <fwp_write.constprop.0+0xb90>
    528b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5292:	00 
    5293:	45 85 f6             	test   %r14d,%r14d
    5296:	0f 84 74 08 00 00    	je     5b10 <fwp_write.constprop.0+0xb40>
    529c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    52a1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    52a6:	48 89 df             	mov    %rbx,%rdi
    52a9:	49 83 c5 01          	add    $0x1,%r13
    52ad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    52b1:	e8 1a fd ff ff       	call   4fd0 <fwp_write.constprop.0>
    52b6:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    52bb:	7f c5                	jg     5282 <fwp_write.constprop.0+0x2b2>
    52bd:	45 85 f6             	test   %r14d,%r14d
    52c0:	0f 84 4a 0a 00 00    	je     5d10 <fwp_write.constprop.0+0xd40>
    52c6:	b8 29 00 00 00       	mov    $0x29,%eax
    52cb:	ba 01 00 00 00       	mov    $0x1,%edx
    52d0:	4c 89 fe             	mov    %r15,%rsi
    52d3:	48 89 df             	mov    %rbx,%rdi
    52d6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    52da:	e8 a1 dc ff ff       	call   2f80 <buf_put>
    52df:	e9 7c fd ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    52e4:	0f 1f 40 00          	nopl   0x0(%rax)
    52e8:	ba 01 00 00 00       	mov    $0x1,%edx
    52ed:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    52f2:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    52f7:	e8 84 dc ff ff       	call   2f80 <buf_put>
    52fc:	48 85 ed             	test   %rbp,%rbp
    52ff:	0f 84 8b 07 00 00    	je     5a90 <fwp_write.constprop.0+0xac0>
    5305:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5309:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    530e:	48 89 df             	mov    %rbx,%rdi
    5311:	e8 ba fc ff ff       	call   4fd0 <fwp_write.constprop.0>
    5316:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    531a:	48 85 ed             	test   %rbp,%rbp
    531d:	0f 84 6d 07 00 00    	je     5a90 <fwp_write.constprop.0+0xac0>
    5323:	ba 02 00 00 00       	mov    $0x2,%edx
    5328:	48 8d 35 ee 5d 00 00 	lea    0x5dee(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    532f:	48 89 df             	mov    %rbx,%rdi
    5332:	e8 49 dc ff ff       	call   2f80 <buf_put>
    5337:	eb cc                	jmp    5305 <fwp_write.constprop.0+0x335>
    5339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5340:	4c 8b 2e             	mov    (%rsi),%r13
    5343:	ba 01 00 00 00       	mov    $0x1,%edx
    5348:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    534d:	48 83 c5 08          	add    $0x8,%rbp
    5351:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5356:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    535b:	e8 20 dc ff ff       	call   2f80 <buf_put>
    5360:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5365:	4d 85 ed             	test   %r13,%r13
    5368:	75 43                	jne    53ad <fwp_write.constprop.0+0x3dd>
    536a:	e9 81 07 00 00       	jmp    5af0 <fwp_write.constprop.0+0xb20>
    536f:	90                   	nop
    5370:	41 80 f9 09          	cmp    $0x9,%r9b
    5374:	0f 84 f6 06 00 00    	je     5a70 <fwp_write.constprop.0+0xaa0>
    537a:	41 80 f9 0a          	cmp    $0xa,%r9b
    537e:	0f 85 bc 06 00 00    	jne    5a40 <fwp_write.constprop.0+0xa70>
    5384:	ba 02 00 00 00       	mov    $0x2,%edx
    5389:	48 8d 35 73 5d 00 00 	lea    0x5d73(%rip),%rsi        # b103 <_IO_stdin_used+0x103>
    5390:	48 89 df             	mov    %rbx,%rdi
    5393:	e8 e8 db ff ff       	call   2f80 <buf_put>
    5398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    539f:	00 
    53a0:	48 83 c5 01          	add    $0x1,%rbp
    53a4:	49 39 ec             	cmp    %rbp,%r12
    53a7:	0f 84 43 07 00 00    	je     5af0 <fwp_write.constprop.0+0xb20>
    53ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    53b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    53b6:	0f 84 64 06 00 00    	je     5a20 <fwp_write.constprop.0+0xa50>
    53bc:	7e b2                	jle    5370 <fwp_write.constprop.0+0x3a0>
    53be:	41 80 f9 22          	cmp    $0x22,%r9b
    53c2:	0f 84 38 06 00 00    	je     5a00 <fwp_write.constprop.0+0xa30>
    53c8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    53cc:	0f 85 6e 06 00 00    	jne    5a40 <fwp_write.constprop.0+0xa70>
    53d2:	ba 02 00 00 00       	mov    $0x2,%edx
    53d7:	48 8d 35 22 5d 00 00 	lea    0x5d22(%rip),%rsi        # b100 <_IO_stdin_used+0x100>
    53de:	48 89 df             	mov    %rbx,%rdi
    53e1:	e8 9a db ff ff       	call   2f80 <buf_put>
    53e6:	eb b8                	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    53e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    53ef:	00 
    53f0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    53f5:	ba 01 00 00 00       	mov    $0x1,%edx
    53fa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    53ff:	48 89 ee             	mov    %rbp,%rsi
    5402:	e8 79 db ff ff       	call   2f80 <buf_put>
    5407:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    540c:	4c 89 e7             	mov    %r12,%rdi
    540f:	e8 1c d0 ff ff       	call   2430 <strlen@plt>
    5414:	4c 89 e6             	mov    %r12,%rsi
    5417:	48 89 df             	mov    %rbx,%rdi
    541a:	48 89 c2             	mov    %rax,%rdx
    541d:	e8 5e db ff ff       	call   2f80 <buf_put>
    5422:	ba 01 00 00 00       	mov    $0x1,%edx
    5427:	48 89 ee             	mov    %rbp,%rsi
    542a:	48 89 df             	mov    %rbx,%rdi
    542d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5432:	e8 49 db ff ff       	call   2f80 <buf_put>
    5437:	e9 24 fc ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    543c:	0f 1f 40 00          	nopl   0x0(%rax)
    5440:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5445:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5449:	0f 8a de 0a 00 00    	jp     5f2d <fwp_write.constprop.0+0xf5d>
    544f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5453:	66 0f 54 05 65 60 00 	andpd  0x6065(%rip),%xmm0        # b4c0 <msg.3+0x80>
    545a:	00 
    545b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5460:	66 0f 2e 05 78 60 00 	ucomisd 0x6078(%rip),%xmm0        # b4e0 <msg.3+0xa0>
    5467:	00 
    5468:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    546f:	00 
    5470:	0f 87 02 09 00 00    	ja     5d78 <fwp_write.constprop.0+0xda8>
    5476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    547d:	00 00 00 
    5480:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5484:	89 ee                	mov    %ebp,%esi
    5486:	4c 89 e7             	mov    %r12,%rdi
    5489:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    548e:	e8 ed dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    5493:	31 f6                	xor    %esi,%esi
    5495:	4c 89 e7             	mov    %r12,%rdi
    5498:	e8 53 cf ff ff       	call   23f0 <strtod@plt>
    549d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    54a2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    54a6:	7a 06                	jp     54ae <fwp_write.constprop.0+0x4de>
    54a8:	0f 84 09 03 00 00    	je     57b7 <fwp_write.constprop.0+0x7e7>
    54ae:	83 c5 01             	add    $0x1,%ebp
    54b1:	83 fd 12             	cmp    $0x12,%ebp
    54b4:	75 ca                	jne    5480 <fwp_write.constprop.0+0x4b0>
    54b6:	be 11 00 00 00       	mov    $0x11,%esi
    54bb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    54bf:	4c 89 e7             	mov    %r12,%rdi
    54c2:	e8 b9 dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    54c7:	e9 eb 02 00 00       	jmp    57b7 <fwp_write.constprop.0+0x7e7>
    54cc:	0f 1f 40 00          	nopl   0x0(%rax)
    54d0:	48 83 fe 01          	cmp    $0x1,%rsi
    54d4:	0f 84 86 08 00 00    	je     5d60 <fwp_write.constprop.0+0xd90>
    54da:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    54de:	b8 02 00 00 00       	mov    $0x2,%eax
    54e3:	ba 01 00 00 00       	mov    $0x1,%edx
    54e8:	48 0f 44 d0          	cmove  %rax,%rdx
    54ec:	48 8d 35 d9 5b 00 00 	lea    0x5bd9(%rip),%rsi        # b0cc <_IO_stdin_used+0xcc>
    54f3:	48 8d 05 cf 5b 00 00 	lea    0x5bcf(%rip),%rax        # b0c9 <_IO_stdin_used+0xc9>
    54fa:	48 0f 44 f0          	cmove  %rax,%rsi
    54fe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5505:	00 
    5506:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    550d:	00 00 
    550f:	0f 84 ce fc ff ff    	je     51e3 <fwp_write.constprop.0+0x213>
    5515:	e8 26 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    551a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5520:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5525:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    552a:	e8 91 d9 ff ff       	call   2ec0 <buf_grow>
    552f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5533:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5539:	4c 03 0b             	add    (%rbx),%r9
    553c:	66 45 89 11          	mov    %r10w,(%r9)
    5540:	49 83 c1 01          	add    $0x1,%r9
    5544:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    554b:	55 55 55 
    554e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5555:	aa aa aa 
    5558:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    555c:	45 85 e4             	test   %r12d,%r12d
    555f:	7f 4c                	jg     55ad <fwp_write.constprop.0+0x5dd>
    5561:	e9 4a 05 00 00       	jmp    5ab0 <fwp_write.constprop.0+0xae0>
    5566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    556d:	00 00 00 
    5570:	be 01 00 00 00       	mov    $0x1,%esi
    5575:	b8 2d 00 00 00       	mov    $0x2d,%eax
    557a:	88 07                	mov    %al,(%rdi)
    557c:	48 89 e8             	mov    %rbp,%rax
    557f:	49 f7 e8             	imul   %r8
    5582:	48 89 e8             	mov    %rbp,%rax
    5585:	48 c1 f8 3f          	sar    $0x3f,%rax
    5589:	48 29 c2             	sub    %rax,%rdx
    558c:	48 85 c9             	test   %rcx,%rcx
    558f:	0f 95 c0             	setne  %al
    5592:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5596:	48 83 ef 01          	sub    $0x1,%rdi
    559a:	48 21 c5             	and    %rax,%rbp
    559d:	48 29 ea             	sub    %rbp,%rdx
    55a0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    55a4:	49 39 f9             	cmp    %rdi,%r9
    55a7:	0f 84 03 05 00 00    	je     5ab0 <fwp_write.constprop.0+0xae0>
    55ad:	48 89 e8             	mov    %rbp,%rax
    55b0:	49 f7 e8             	imul   %r8
    55b3:	48 89 e8             	mov    %rbp,%rax
    55b6:	48 c1 f8 3f          	sar    $0x3f,%rax
    55ba:	48 89 d1             	mov    %rdx,%rcx
    55bd:	48 29 c1             	sub    %rax,%rcx
    55c0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    55c4:	48 89 e9             	mov    %rbp,%rcx
    55c7:	48 29 c1             	sub    %rax,%rcx
    55ca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    55ce:	49 f7 e2             	mul    %r10
    55d1:	b8 30 00 00 00       	mov    $0x30,%eax
    55d6:	48 89 d6             	mov    %rdx,%rsi
    55d9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    55dd:	48 d1 ee             	shr    $1,%rsi
    55e0:	48 01 f2             	add    %rsi,%rdx
    55e3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    55e7:	48 29 d6             	sub    %rdx,%rsi
    55ea:	74 8e                	je     557a <fwp_write.constprop.0+0x5aa>
    55ec:	48 83 fe 01          	cmp    $0x1,%rsi
    55f0:	0f 85 7a ff ff ff    	jne    5570 <fwp_write.constprop.0+0x5a0>
    55f6:	31 f6                	xor    %esi,%esi
    55f8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    55fd:	e9 78 ff ff ff       	jmp    557a <fwp_write.constprop.0+0x5aa>
    5602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5608:	ba 06 00 00 00       	mov    $0x6,%edx
    560d:	48 8d 35 0c 5b 00 00 	lea    0x5b0c(%rip),%rsi        # b120 <_IO_stdin_used+0x120>
    5614:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    561a:	e8 61 d9 ff ff       	call   2f80 <buf_put>
    561f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5626:	ff ff 7f 
    5629:	48 23 55 00          	and    0x0(%rbp),%rdx
    562d:	0f 84 4e 03 00 00    	je     5981 <fwp_write.constprop.0+0x9b1>
    5633:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5638:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    563c:	48 85 d2             	test   %rdx,%rdx
    563f:	0f 84 a4 00 00 00    	je     56e9 <fwp_write.constprop.0+0x719>
    5645:	8b 0a                	mov    (%rdx),%ecx
    5647:	83 f9 1c             	cmp    $0x1c,%ecx
    564a:	0f 84 d0 06 00 00    	je     5d20 <fwp_write.constprop.0+0xd50>
    5650:	83 f9 1b             	cmp    $0x1b,%ecx
    5653:	0f 87 90 00 00 00    	ja     56e9 <fwp_write.constprop.0+0x719>
    5659:	be 01 00 00 00       	mov    $0x1,%esi
    565e:	48 d3 e6             	shl    %cl,%rsi
    5661:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5667:	0f 85 13 06 00 00    	jne    5c80 <fwp_write.constprop.0+0xcb0>
    566d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5673:	0f 85 d7 05 00 00    	jne    5c50 <fwp_write.constprop.0+0xc80>
    5679:	83 e6 21             	and    $0x21,%esi
    567c:	74 6b                	je     56e9 <fwp_write.constprop.0+0x719>
    567e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5683:	48 85 ff             	test   %rdi,%rdi
    5686:	79 07                	jns    568f <fwp_write.constprop.0+0x6bf>
    5688:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    568c:	4c 01 ee             	add    %r13,%rsi
    568f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5693:	85 c9                	test   %ecx,%ecx
    5695:	40 0f b6 f7          	movzbl %dil,%esi
    5699:	48 0f 44 f7          	cmove  %rdi,%rsi
    569d:	0f 1f 00             	nopl   (%rax)
    56a0:	48 89 df             	mov    %rbx,%rdi
    56a3:	49 83 c5 01          	add    $0x1,%r13
    56a7:	e8 24 f9 ff ff       	call   4fd0 <fwp_write.constprop.0>
    56ac:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    56b3:	ff ff 7f 
    56b6:	48 23 55 00          	and    0x0(%rbp),%rdx
    56ba:	49 39 d5             	cmp    %rdx,%r13
    56bd:	0f 83 be 02 00 00    	jae    5981 <fwp_write.constprop.0+0x9b1>
    56c3:	ba 02 00 00 00       	mov    $0x2,%edx
    56c8:	48 89 df             	mov    %rbx,%rdi
    56cb:	48 8d 35 4b 5a 00 00 	lea    0x5a4b(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    56d2:	e8 a9 d8 ff ff       	call   2f80 <buf_put>
    56d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    56dc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    56e0:	48 85 d2             	test   %rdx,%rdx
    56e3:	0f 85 5c ff ff ff    	jne    5645 <fwp_write.constprop.0+0x675>
    56e9:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    56ee:	48 85 ff             	test   %rdi,%rdi
    56f1:	0f 88 51 06 00 00    	js     5d48 <fwp_write.constprop.0+0xd78>
    56f7:	48 8b 31             	mov    (%rcx),%rsi
    56fa:	eb a4                	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    56fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5700:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5707:	00 
    5708:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    570f:	00 00 
    5711:	0f 85 fe fd ff ff    	jne    5515 <fwp_write.constprop.0+0x545>
    5717:	ba 08 00 00 00       	mov    $0x8,%edx
    571c:	48 8d 35 ca 59 00 00 	lea    0x59ca(%rip),%rsi        # b0ed <_IO_stdin_used+0xed>
    5723:	e9 bb fa ff ff       	jmp    51e3 <fwp_write.constprop.0+0x213>
    5728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    572f:	00 
    5730:	66 0f 6e ce          	movd   %esi,%xmm1
    5734:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5737:	0f 8a f0 07 00 00    	jp     5f2d <fwp_write.constprop.0+0xf5d>
    573d:	0f 28 c1             	movaps %xmm1,%xmm0
    5740:	0f 54 05 69 5d 00 00 	andps  0x5d69(%rip),%xmm0        # b4b0 <msg.3+0x70>
    5747:	0f 2e 05 b6 58 00 00 	ucomiss 0x58b6(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    574e:	0f 87 4c 06 00 00    	ja     5da0 <fwp_write.constprop.0+0xdd0>
    5754:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5758:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    575e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5765:	00 
    5766:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    576a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    576f:	90                   	nop
    5770:	44 89 ee             	mov    %r13d,%esi
    5773:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5778:	4c 89 e7             	mov    %r12,%rdi
    577b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5780:	e8 fb d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    5785:	31 f6                	xor    %esi,%esi
    5787:	4c 89 e7             	mov    %r12,%rdi
    578a:	e8 01 cd ff ff       	call   2490 <strtof@plt>
    578f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5794:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5797:	7a 02                	jp     579b <fwp_write.constprop.0+0x7cb>
    5799:	74 1c                	je     57b7 <fwp_write.constprop.0+0x7e7>
    579b:	41 83 c5 01          	add    $0x1,%r13d
    579f:	41 83 fd 0a          	cmp    $0xa,%r13d
    57a3:	75 cb                	jne    5770 <fwp_write.constprop.0+0x7a0>
    57a5:	be 09 00 00 00       	mov    $0x9,%esi
    57aa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    57af:	4c 89 e7             	mov    %r12,%rdi
    57b2:	e8 c9 d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    57b7:	4c 89 e7             	mov    %r12,%rdi
    57ba:	e8 81 d8 ff ff       	call   3040 <fwp_finish_float>
    57bf:	e9 7c f8 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    57c4:	0f 1f 40 00          	nopl   0x0(%rax)
    57c8:	89 f0                	mov    %esi,%eax
    57ca:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    57d1:	76 02                	jbe    57d5 <fwp_write.constprop.0+0x805>
    57d3:	8b 06                	mov    (%rsi),%eax
    57d5:	41 89 c6             	mov    %eax,%r14d
    57d8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    57dd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    57e2:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    57e6:	4c 89 ef             	mov    %r13,%rdi
    57e9:	e8 42 cc ff ff       	call   2430 <strlen@plt>
    57ee:	4c 89 ee             	mov    %r13,%rsi
    57f1:	48 89 df             	mov    %rbx,%rdi
    57f4:	48 89 c2             	mov    %rax,%rdx
    57f7:	e8 84 d7 ff ff       	call   2f80 <buf_put>
    57fc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5801:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5805:	85 f6                	test   %esi,%esi
    5807:	0f 8e 53 f8 ff ff    	jle    5060 <fwp_write.constprop.0+0x90>
    580d:	45 31 ed             	xor    %r13d,%r13d
    5810:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5815:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    581a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    581f:	4c 89 fe             	mov    %r15,%rsi
    5822:	48 89 df             	mov    %rbx,%rdi
    5825:	ba 01 00 00 00       	mov    $0x1,%edx
    582a:	48 89 04 24          	mov    %rax,(%rsp)
    582e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5833:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5837:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    583b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5840:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5845:	e8 36 d7 ff ff       	call   2f80 <buf_put>
    584a:	41 8b 06             	mov    (%r14),%eax
    584d:	83 f8 0e             	cmp    $0xe,%eax
    5850:	0f 84 5a 03 00 00    	je     5bb0 <fwp_write.constprop.0+0xbe0>
    5856:	83 f8 10             	cmp    $0x10,%eax
    5859:	0f 84 21 03 00 00    	je     5b80 <fwp_write.constprop.0+0xbb0>
    585f:	83 f8 0a             	cmp    $0xa,%eax
    5862:	0f 84 68 04 00 00    	je     5cd0 <fwp_write.constprop.0+0xd00>
    5868:	0f 8f 32 01 00 00    	jg     59a0 <fwp_write.constprop.0+0x9d0>
    586e:	83 f8 03             	cmp    $0x3,%eax
    5871:	0f 8f 39 04 00 00    	jg     5cb0 <fwp_write.constprop.0+0xce0>
    5877:	85 c0                	test   %eax,%eax
    5879:	78 10                	js     588b <fwp_write.constprop.0+0x8bb>
    587b:	48 8b 04 24          	mov    (%rsp),%rax
    587f:	48 c1 e8 3f          	shr    $0x3f,%rax
    5883:	85 c0                	test   %eax,%eax
    5885:	0f 85 32 01 00 00    	jne    59bd <fwp_write.constprop.0+0x9ed>
    588b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5890:	48 8b 34 24          	mov    (%rsp),%rsi
    5894:	48 89 df             	mov    %rbx,%rdi
    5897:	e8 34 f7 ff ff       	call   4fd0 <fwp_write.constprop.0>
    589c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    58a1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    58a6:	49 83 c5 01          	add    $0x1,%r13
    58aa:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    58ae:	0f 8f 61 ff ff ff    	jg     5815 <fwp_write.constprop.0+0x845>
    58b4:	e9 a7 f7 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    58b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58c0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    58c4:	48 8b 36             	mov    (%rsi),%rsi
    58c7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    58ce:	00 
    58cf:	48 89 ef             	mov    %rbp,%rdi
    58d2:	e8 29 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    58d7:	48 89 ef             	mov    %rbp,%rdi
    58da:	e8 51 cb ff ff       	call   2430 <strlen@plt>
    58df:	48 89 ee             	mov    %rbp,%rsi
    58e2:	48 89 df             	mov    %rbx,%rdi
    58e5:	48 89 c2             	mov    %rax,%rdx
    58e8:	e8 93 d6 ff ff       	call   2f80 <buf_put>
    58ed:	e9 6e f7 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    58f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    58f8:	ba 06 00 00 00       	mov    $0x6,%edx
    58fd:	48 8d 35 0f 58 00 00 	lea    0x580f(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    5904:	45 31 ed             	xor    %r13d,%r13d
    5907:	e8 74 d6 ff ff       	call   2f80 <buf_put>
    590c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5911:	75 19                	jne    592c <fwp_write.constprop.0+0x95c>
    5913:	eb 6c                	jmp    5981 <fwp_write.constprop.0+0x9b1>
    5915:	0f 1f 00             	nopl   (%rax)
    5918:	ba 02 00 00 00       	mov    $0x2,%edx
    591d:	48 8d 35 f9 57 00 00 	lea    0x57f9(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5924:	48 89 df             	mov    %rbx,%rdi
    5927:	e8 54 d6 ff ff       	call   2f80 <buf_put>
    592c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5932:	b9 00 02 00 00       	mov    $0x200,%ecx
    5937:	31 c0                	xor    %eax,%eax
    5939:	49 83 c5 01          	add    $0x1,%r13
    593d:	4c 8d 05 d6 57 00 00 	lea    0x57d6(%rip),%r8        # b11a <_IO_stdin_used+0x11a>
    5944:	ba 02 00 00 00       	mov    $0x2,%edx
    5949:	be 00 02 00 00       	mov    $0x200,%esi
    594e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5955:	00 
    5956:	e8 35 ca ff ff       	call   2390 <__snprintf_chk@plt>
    595b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5962:	00 
    5963:	e8 c8 ca ff ff       	call   2430 <strlen@plt>
    5968:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    596f:	00 
    5970:	48 89 df             	mov    %rbx,%rdi
    5973:	48 89 c2             	mov    %rax,%rdx
    5976:	e8 05 d6 ff ff       	call   2f80 <buf_put>
    597b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    597f:	72 97                	jb     5918 <fwp_write.constprop.0+0x948>
    5981:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5986:	ba 01 00 00 00       	mov    $0x1,%edx
    598b:	48 89 df             	mov    %rbx,%rdi
    598e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5993:	e8 e8 d5 ff ff       	call   2f80 <buf_put>
    5998:	e9 c3 f6 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    599d:	0f 1f 00             	nopl   (%rax)
    59a0:	83 f8 0b             	cmp    $0xb,%eax
    59a3:	0f 85 e2 fe ff ff    	jne    588b <fwp_write.constprop.0+0x8bb>
    59a9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    59ae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    59b2:	83 e0 01             	and    $0x1,%eax
    59b5:	85 c0                	test   %eax,%eax
    59b7:	0f 84 ce fe ff ff    	je     588b <fwp_write.constprop.0+0x8bb>
    59bd:	4c 89 fe             	mov    %r15,%rsi
    59c0:	48 89 df             	mov    %rbx,%rdi
    59c3:	ba 01 00 00 00       	mov    $0x1,%edx
    59c8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    59cd:	e8 ae d5 ff ff       	call   2f80 <buf_put>
    59d2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    59d7:	48 8b 34 24          	mov    (%rsp),%rsi
    59db:	48 89 df             	mov    %rbx,%rdi
    59de:	e8 ed f5 ff ff       	call   4fd0 <fwp_write.constprop.0>
    59e3:	ba 01 00 00 00       	mov    $0x1,%edx
    59e8:	4c 89 fe             	mov    %r15,%rsi
    59eb:	48 89 df             	mov    %rbx,%rdi
    59ee:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    59f3:	e8 88 d5 ff ff       	call   2f80 <buf_put>
    59f8:	e9 9f fe ff ff       	jmp    589c <fwp_write.constprop.0+0x8cc>
    59fd:	0f 1f 00             	nopl   (%rax)
    5a00:	ba 02 00 00 00       	mov    $0x2,%edx
    5a05:	48 8d 35 f1 56 00 00 	lea    0x56f1(%rip),%rsi        # b0fd <_IO_stdin_used+0xfd>
    5a0c:	48 89 df             	mov    %rbx,%rdi
    5a0f:	e8 6c d5 ff ff       	call   2f80 <buf_put>
    5a14:	e9 87 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a20:	ba 02 00 00 00       	mov    $0x2,%edx
    5a25:	48 8d 35 dd 56 00 00 	lea    0x56dd(%rip),%rsi        # b109 <_IO_stdin_used+0x109>
    5a2c:	48 89 df             	mov    %rbx,%rdi
    5a2f:	e8 4c d5 ff ff       	call   2f80 <buf_put>
    5a34:	e9 67 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5a44:	0f 86 b6 01 00 00    	jbe    5c00 <fwp_write.constprop.0+0xc30>
    5a4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5a4e:	0f 84 ac 01 00 00    	je     5c00 <fwp_write.constprop.0+0xc30>
    5a54:	ba 01 00 00 00       	mov    $0x1,%edx
    5a59:	4c 89 fe             	mov    %r15,%rsi
    5a5c:	48 89 df             	mov    %rbx,%rdi
    5a5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5a64:	e8 17 d5 ff ff       	call   2f80 <buf_put>
    5a69:	e9 32 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a6e:	66 90                	xchg   %ax,%ax
    5a70:	ba 02 00 00 00       	mov    $0x2,%edx
    5a75:	48 8d 35 8a 56 00 00 	lea    0x568a(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    5a7c:	48 89 df             	mov    %rbx,%rdi
    5a7f:	e8 fc d4 ff ff       	call   2f80 <buf_put>
    5a84:	e9 17 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a90:	ba 01 00 00 00       	mov    $0x1,%edx
    5a95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a9a:	48 89 df             	mov    %rbx,%rdi
    5a9d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5aa2:	e8 d9 d4 ff ff       	call   2f80 <buf_put>
    5aa7:	e9 b4 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)
    5ab0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5ab4:	48 8b 13             	mov    (%rbx),%rdx
    5ab7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5abc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5ac0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5ac4:	e9 97 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ad0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5ad5:	ba 01 00 00 00       	mov    $0x1,%edx
    5ada:	48 89 df             	mov    %rbx,%rdi
    5add:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5ae2:	e8 99 d4 ff ff       	call   2f80 <buf_put>
    5ae7:	e9 74 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5aec:	0f 1f 40 00          	nopl   0x0(%rax)
    5af0:	ba 01 00 00 00       	mov    $0x1,%edx
    5af5:	4c 89 fe             	mov    %r15,%rsi
    5af8:	48 89 df             	mov    %rbx,%rdi
    5afb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5b00:	e8 7b d4 ff ff       	call   2f80 <buf_put>
    5b05:	e9 56 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b10:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5b15:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5b1a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5b1e:	48 89 f7             	mov    %rsi,%rdi
    5b21:	48 89 34 24          	mov    %rsi,(%rsp)
    5b25:	e8 06 c9 ff ff       	call   2430 <strlen@plt>
    5b2a:	48 8b 34 24          	mov    (%rsp),%rsi
    5b2e:	48 89 df             	mov    %rbx,%rdi
    5b31:	48 89 c2             	mov    %rax,%rdx
    5b34:	e8 47 d4 ff ff       	call   2f80 <buf_put>
    5b39:	ba 03 00 00 00       	mov    $0x3,%edx
    5b3e:	48 8d 35 fb 55 00 00 	lea    0x55fb(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    5b45:	48 89 df             	mov    %rbx,%rdi
    5b48:	e8 33 d4 ff ff       	call   2f80 <buf_put>
    5b4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b52:	e9 45 f7 ff ff       	jmp    529c <fwp_write.constprop.0+0x2cc>
    5b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b5e:	00 00 
    5b60:	ba 02 00 00 00       	mov    $0x2,%edx
    5b65:	48 8d 35 b1 55 00 00 	lea    0x55b1(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5b6c:	48 89 df             	mov    %rbx,%rdi
    5b6f:	e8 0c d4 ff ff       	call   2f80 <buf_put>
    5b74:	e9 12 f7 ff ff       	jmp    528b <fwp_write.constprop.0+0x2bb>
    5b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5b85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5b89:	48 85 ff             	test   %rdi,%rdi
    5b8c:	0f 84 f9 fc ff ff    	je     588b <fwp_write.constprop.0+0x8bb>
    5b92:	48 8d 35 91 55 00 00 	lea    0x5591(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5b99:	e8 72 c9 ff ff       	call   2510 <strcmp@plt>
    5b9e:	85 c0                	test   %eax,%eax
    5ba0:	0f 95 c0             	setne  %al
    5ba3:	0f b6 c0             	movzbl %al,%eax
    5ba6:	e9 d8 fc ff ff       	jmp    5883 <fwp_write.constprop.0+0x8b3>
    5bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5bb0:	31 c0                	xor    %eax,%eax
    5bb2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5bb9:	00 
    5bba:	0f 97 c0             	seta   %al
    5bbd:	e9 c1 fc ff ff       	jmp    5883 <fwp_write.constprop.0+0x8b3>
    5bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bc8:	48 89 df             	mov    %rbx,%rdi
    5bcb:	ba 02 00 00 00       	mov    $0x2,%edx
    5bd0:	48 8d 35 50 55 00 00 	lea    0x5550(%rip),%rsi        # b127 <_IO_stdin_used+0x127>
    5bd7:	e8 a4 d3 ff ff       	call   2f80 <buf_put>
    5bdc:	4c 89 e8             	mov    %r13,%rax
    5bdf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5be4:	48 89 df             	mov    %rbx,%rdi
    5be7:	48 c1 e0 04          	shl    $0x4,%rax
    5beb:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5bf0:	e8 db f3 ff ff       	call   4fd0 <fwp_write.constprop.0>
    5bf5:	e9 4e f5 ff ff       	jmp    5148 <fwp_write.constprop.0+0x178>
    5bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c00:	4c 8d 05 05 55 00 00 	lea    0x5505(%rip),%r8        # b10c <_IO_stdin_used+0x10c>
    5c07:	b9 10 00 00 00       	mov    $0x10,%ecx
    5c0c:	31 c0                	xor    %eax,%eax
    5c0e:	ba 02 00 00 00       	mov    $0x2,%edx
    5c13:	be 10 00 00 00       	mov    $0x10,%esi
    5c18:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c1f:	00 
    5c20:	e8 6b c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c25:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c2c:	00 
    5c2d:	e8 fe c7 ff ff       	call   2430 <strlen@plt>
    5c32:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c39:	00 
    5c3a:	48 89 df             	mov    %rbx,%rdi
    5c3d:	48 89 c2             	mov    %rax,%rdx
    5c40:	e8 3b d3 ff ff       	call   2f80 <buf_put>
    5c45:	e9 56 f7 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5c55:	48 85 ff             	test   %rdi,%rdi
    5c58:	79 0c                	jns    5c66 <fwp_write.constprop.0+0xc96>
    5c5a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5c61:	00 
    5c62:	48 03 75 10          	add    0x10(%rbp),%rsi
    5c66:	48 63 3e             	movslq (%rsi),%rdi
    5c69:	83 f9 02             	cmp    $0x2,%ecx
    5c6c:	89 fe                	mov    %edi,%esi
    5c6e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c72:	e9 29 fa ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c7e:	00 00 
    5c80:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5c85:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5c8a:	48 85 ff             	test   %rdi,%rdi
    5c8d:	0f 88 6f 01 00 00    	js     5e02 <fwp_write.constprop.0+0xe32>
    5c93:	49 0f bf 38          	movswq (%r8),%rdi
    5c97:	83 f9 01             	cmp    $0x1,%ecx
    5c9a:	0f b7 f7             	movzwl %di,%esi
    5c9d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5ca1:	e9 fa f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cad:	00 00 00 
    5cb0:	83 f8 04             	cmp    $0x4,%eax
    5cb3:	0f 85 d2 fb ff ff    	jne    588b <fwp_write.constprop.0+0x8bb>
    5cb9:	48 8b 04 24          	mov    (%rsp),%rax
    5cbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    5cc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5cc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5cca:	e9 e6 fc ff ff       	jmp    59b5 <fwp_write.constprop.0+0x9e5>
    5ccf:	90                   	nop
    5cd0:	8b 0c 24             	mov    (%rsp),%ecx
    5cd3:	31 c0                	xor    %eax,%eax
    5cd5:	85 c9                	test   %ecx,%ecx
    5cd7:	0f 98 c0             	sets   %al
    5cda:	e9 d6 fc ff ff       	jmp    59b5 <fwp_write.constprop.0+0x9e5>
    5cdf:	90                   	nop
    5ce0:	48 f7 d8             	neg    %rax
    5ce3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5cea:	00 
    5ceb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5cf2:	2d 
    5cf3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5cfa:	00 
    5cfb:	48 83 d2 00          	adc    $0x0,%rdx
    5cff:	48 89 c6             	mov    %rax,%rsi
    5d02:	48 f7 da             	neg    %rdx
    5d05:	e8 f6 cc ff ff       	call   2a00 <fwp_fmt_u128>
    5d0a:	e9 31 f3 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5d0f:	90                   	nop
    5d10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5d15:	e9 b1 f5 ff ff       	jmp    52cb <fwp_write.constprop.0+0x2fb>
    5d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d20:	4c 89 e9             	mov    %r13,%rcx
    5d23:	48 c1 e1 04          	shl    $0x4,%rcx
    5d27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5d2c:	48 85 ff             	test   %rdi,%rdi
    5d2f:	0f 89 6b f9 ff ff    	jns    56a0 <fwp_write.constprop.0+0x6d0>
    5d35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d39:	48 89 ce             	mov    %rcx,%rsi
    5d3c:	e9 5f f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5d4f:	00 
    5d50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d54:	e9 9e f9 ff ff       	jmp    56f7 <fwp_write.constprop.0+0x727>
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	ba 02 00 00 00       	mov    $0x2,%edx
    5d65:	48 8d 35 5a 53 00 00 	lea    0x535a(%rip),%rsi        # b0c6 <_IO_stdin_used+0xc6>
    5d6c:	e9 8d f7 ff ff       	jmp    54fe <fwp_write.constprop.0+0x52e>
    5d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d7c:	48 8d 35 3f 53 00 00 	lea    0x533f(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5d83:	48 8d 05 37 53 00 00 	lea    0x5337(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5d8a:	4c 89 e7             	mov    %r12,%rdi
    5d8d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5d91:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d95:	e8 36 c6 ff ff       	call   23d0 <strcpy@plt>
    5d9a:	e9 a1 f2 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5d9f:	90                   	nop
    5da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da4:	48 8d 35 17 53 00 00 	lea    0x5317(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5dab:	48 8d 05 0f 53 00 00 	lea    0x530f(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5db2:	0f 2f c8             	comiss %xmm0,%xmm1
    5db5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5dbc:	00 
    5dbd:	4c 89 e7             	mov    %r12,%rdi
    5dc0:	48 0f 46 f0          	cmovbe %rax,%rsi
    5dc4:	e8 07 c6 ff ff       	call   23d0 <strcpy@plt>
    5dc9:	e9 72 f2 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5dce:	66 90                	xchg   %ax,%ax
    5dd0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5dd5:	45 85 c0             	test   %r8d,%r8d
    5dd8:	75 34                	jne    5e0e <fwp_write.constprop.0+0xe3e>
    5dda:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5de1:	00 
    5de2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5de9:	00 00 
    5deb:	0f 85 24 f7 ff ff    	jne    5515 <fwp_write.constprop.0+0x545>
    5df1:	ba 02 00 00 00       	mov    $0x2,%edx
    5df6:	48 8d 35 40 53 00 00 	lea    0x5340(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5dfd:	e9 e1 f3 ff ff       	jmp    51e3 <fwp_write.constprop.0+0x213>
    5e02:	48 03 75 10          	add    0x10(%rbp),%rsi
    5e06:	49 89 f0             	mov    %rsi,%r8
    5e09:	e9 85 fe ff ff       	jmp    5c93 <fwp_write.constprop.0+0xcc3>
    5e0e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5e13:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e18:	85 ff                	test   %edi,%edi
    5e1a:	0f 84 3a f4 ff ff    	je     525a <fwp_write.constprop.0+0x28a>
    5e20:	ba 01 00 00 00       	mov    $0x1,%edx
    5e25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5e2a:	48 89 df             	mov    %rbx,%rdi
    5e2d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5e32:	e8 49 d1 ff ff       	call   2f80 <buf_put>
    5e37:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5e3c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e41:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5e47:	85 d2                	test   %edx,%edx
    5e49:	0f 8f 30 f4 ff ff    	jg     527f <fwp_write.constprop.0+0x2af>
    5e4f:	e9 72 f4 ff ff       	jmp    52c6 <fwp_write.constprop.0+0x2f6>
    5e54:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e58:	49 89 c5             	mov    %rax,%r13
    5e5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5e60:	49 89 c4             	mov    %rax,%r12
    5e63:	49 c1 fd 3f          	sar    $0x3f,%r13
    5e67:	4c 09 e8             	or     %r13,%rax
    5e6a:	0f 84 a7 00 00 00    	je     5f17 <fwp_write.constprop.0+0xf47>
    5e70:	48 8d 2d e9 6c 00 00 	lea    0x6ce9(%rip),%rbp        # cb60 <units.0>
    5e77:	4d 89 e7             	mov    %r12,%r15
    5e7a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e7e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5e83:	4c 89 ff             	mov    %r15,%rdi
    5e86:	4c 89 ee             	mov    %r13,%rsi
    5e89:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e8d:	48 99                	cqto
    5e8f:	48 89 d1             	mov    %rdx,%rcx
    5e92:	48 89 c2             	mov    %rax,%rdx
    5e95:	e8 06 42 00 00       	call   a0a0 <__divmodti4>
    5e9a:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e9e:	48 89 c1             	mov    %rax,%rcx
    5ea1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5ea6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5eab:	0f 84 94 00 00 00    	je     5f45 <fwp_write.constprop.0+0xf75>
    5eb1:	41 83 c1 01          	add    $0x1,%r9d
    5eb5:	48 83 c5 10          	add    $0x10,%rbp
    5eb9:	41 83 f9 05          	cmp    $0x5,%r9d
    5ebd:	75 bb                	jne    5e7a <fwp_write.constprop.0+0xeaa>
    5ebf:	4d 85 ed             	test   %r13,%r13
    5ec2:	79 53                	jns    5f17 <fwp_write.constprop.0+0xf47>
    5ec4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5ec9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5ece:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5ed3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5ed8:	48 99                	cqto
    5eda:	48 f7 d8             	neg    %rax
    5edd:	48 83 d2 00          	adc    $0x0,%rdx
    5ee1:	48 89 c6             	mov    %rax,%rsi
    5ee4:	48 f7 da             	neg    %rdx
    5ee7:	e8 14 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5eec:	49 89 e8             	mov    %rbp,%r8
    5eef:	ba 00 02 00 00       	mov    $0x200,%edx
    5ef4:	be 02 00 00 00       	mov    $0x2,%esi
    5ef9:	31 c0                	xor    %eax,%eax
    5efb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f02:	00 
    5f03:	48 8d 0d 2e 52 00 00 	lea    0x522e(%rip),%rcx        # b138 <_IO_stdin_used+0x138>
    5f0a:	4c 89 e7             	mov    %r12,%rdi
    5f0d:	e8 8e c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f12:	e9 29 f1 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5f17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5f21:	31 d2                	xor    %edx,%edx
    5f23:	48 89 ef             	mov    %rbp,%rdi
    5f26:	e8 d5 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f2b:	eb bf                	jmp    5eec <fwp_write.constprop.0+0xf1c>
    5f2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5f34:	4e 61 4e 00 
    5f38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f3f:	00 
    5f40:	e9 fb f0 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5f45:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f49:	48 89 c8             	mov    %rcx,%rax
    5f4c:	48 85 d2             	test   %rdx,%rdx
    5f4f:	78 51                	js     5fa2 <fwp_write.constprop.0+0xfd2>
    5f51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f56:	48 89 c6             	mov    %rax,%rsi
    5f59:	48 89 ef             	mov    %rbp,%rdi
    5f5c:	e8 9f ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f61:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f65:	49 63 c1             	movslq %r9d,%rax
    5f68:	49 89 e8             	mov    %rbp,%r8
    5f6b:	ba 00 02 00 00       	mov    $0x200,%edx
    5f70:	be 02 00 00 00       	mov    $0x2,%esi
    5f75:	48 c1 e0 04          	shl    $0x4,%rax
    5f79:	48 8d 0d e0 6b 00 00 	lea    0x6be0(%rip),%rcx        # cb60 <units.0>
    5f80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f87:	00 
    5f88:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5f8c:	4c 89 e7             	mov    %r12,%rdi
    5f8f:	48 8d 0d 9d 51 00 00 	lea    0x519d(%rip),%rcx        # b133 <_IO_stdin_used+0x133>
    5f96:	31 c0                	xor    %eax,%eax
    5f98:	e8 03 c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f9d:	e9 9e f0 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5fa2:	48 f7 d8             	neg    %rax
    5fa5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5faa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5faf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5fb4:	48 83 d2 00          	adc    $0x0,%rdx
    5fb8:	48 89 c6             	mov    %rax,%rsi
    5fbb:	48 f7 da             	neg    %rdx
    5fbe:	e8 3d ca ff ff       	call   2a00 <fwp_fmt_u128>
    5fc3:	44 8b 0c 24          	mov    (%rsp),%r9d
    5fc7:	eb 9c                	jmp    5f65 <fwp_write.constprop.0+0xf95>
    5fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005fd0 <fwp_hof0.constprop.0>:
    5fd0:	41 57                	push   %r15
    5fd2:	41 56                	push   %r14
    5fd4:	41 55                	push   %r13
    5fd6:	4c 8d 2d 43 77 01 00 	lea    0x17743(%rip),%r13        # 1d720 <fwp_heap>
    5fdd:	41 54                	push   %r12
    5fdf:	49 89 fc             	mov    %rdi,%r12
    5fe2:	55                   	push   %rbp
    5fe3:	53                   	push   %rbx
    5fe4:	48 83 ec 38          	sub    $0x38,%rsp
    5fe8:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5fed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5ff4:	00 00 
    5ff6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    5ffb:	31 c0                	xor    %eax,%eax
    5ffd:	48 85 f6             	test   %rsi,%rsi
    6000:	0f 84 41 09 00 00    	je     6947 <fwp_hof0.constprop.0+0x977>
    6006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    600d:	00 00 00 
    6010:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6017:	4c 89 e0             	mov    %r12,%rax
    601a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6021:	48 c1 e2 10          	shl    $0x10,%rdx
    6025:	48 39 d0             	cmp    %rdx,%rax
    6028:	73 5d                	jae    6087 <fwp_hof0.constprop.0+0xb7>
    602a:	48 89 c2             	mov    %rax,%rdx
    602d:	48 c1 ea 10          	shr    $0x10,%rdx
    6031:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6035:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    603c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6040:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6044:	48 85 db             	test   %rbx,%rbx
    6047:	74 3e                	je     6087 <fwp_hof0.constprop.0+0xb7>
    6049:	0f b6 0a             	movzbl (%rdx),%ecx
    604c:	80 f9 02             	cmp    $0x2,%cl
    604f:	0f 84 8b 0b 00 00    	je     6be0 <fwp_hof0.constprop.0+0xc10>
    6055:	80 f9 01             	cmp    $0x1,%cl
    6058:	75 2d                	jne    6087 <fwp_hof0.constprop.0+0xb7>
    605a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    605d:	0f b7 c0             	movzwl %ax,%eax
    6060:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6063:	48 0f af c1          	imul   %rcx,%rax
    6067:	48 c1 e8 20          	shr    $0x20,%rax
    606b:	48 39 d0             	cmp    %rdx,%rax
    606e:	73 17                	jae    6087 <fwp_hof0.constprop.0+0xb7>
    6070:	48 01 c3             	add    %rax,%rbx
    6073:	0f b6 03             	movzbl (%rbx),%eax
    6076:	84 c0                	test   %al,%al
    6078:	74 0d                	je     6087 <fwp_hof0.constprop.0+0xb7>
    607a:	3c fd                	cmp    $0xfd,%al
    607c:	0f 87 7c 0d 00 00    	ja     6dfe <fwp_hof0.constprop.0+0xe2e>
    6082:	83 c0 01             	add    $0x1,%eax
    6085:	88 03                	mov    %al,(%rbx)
    6087:	4d 85 e4             	test   %r12,%r12
    608a:	0f 84 62 0b 00 00    	je     6bf2 <fwp_hof0.constprop.0+0xc22>
    6090:	4c 89 e0             	mov    %r12,%rax
    6093:	31 ff                	xor    %edi,%edi
    6095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    609c:	00 00 00 00 
    60a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    60a4:	48 83 c7 01          	add    $0x1,%rdi
    60a8:	48 85 c0             	test   %rax,%rax
    60ab:	75 f3                	jne    60a0 <fwp_hof0.constprop.0+0xd0>
    60ad:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    60b4:	ff ff 1f 
    60b7:	48 39 f8             	cmp    %rdi,%rax
    60ba:	0f 82 10 0e 00 00    	jb     6ed0 <fwp_hof0.constprop.0+0xf00>
    60c0:	e8 6b e7 ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    60c5:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    60cc:	48 89 c3             	mov    %rax,%rbx
    60cf:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    60d6:	48 c1 e2 10          	shl    $0x10,%rdx
    60da:	48 39 d0             	cmp    %rdx,%rax
    60dd:	73 60                	jae    613f <fwp_hof0.constprop.0+0x16f>
    60df:	48 89 c2             	mov    %rax,%rdx
    60e2:	48 c1 ea 10          	shr    $0x10,%rdx
    60e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    60ea:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    60f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    60f5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    60f9:	48 85 ed             	test   %rbp,%rbp
    60fc:	74 41                	je     613f <fwp_hof0.constprop.0+0x16f>
    60fe:	0f b6 0a             	movzbl (%rdx),%ecx
    6101:	80 f9 02             	cmp    $0x2,%cl
    6104:	0f 84 ae 0a 00 00    	je     6bb8 <fwp_hof0.constprop.0+0xbe8>
    610a:	80 f9 01             	cmp    $0x1,%cl
    610d:	75 27                	jne    6136 <fwp_hof0.constprop.0+0x166>
    610f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6112:	0f b7 c0             	movzwl %ax,%eax
    6115:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6118:	48 0f af c1          	imul   %rcx,%rax
    611c:	48 c1 e8 20          	shr    $0x20,%rax
    6120:	48 39 d0             	cmp    %rdx,%rax
    6123:	73 11                	jae    6136 <fwp_hof0.constprop.0+0x166>
    6125:	48 01 c5             	add    %rax,%rbp
    6128:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    612c:	0f 84 99 0a 00 00    	je     6bcb <fwp_hof0.constprop.0+0xbfb>
    6132:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6136:	4d 85 e4             	test   %r12,%r12
    6139:	0f 84 21 0a 00 00    	je     6b60 <fwp_hof0.constprop.0+0xb90>
    613f:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    6144:	49 8b 6c 24 10       	mov    0x10(%r12),%rbp
    6149:	4d 89 e1             	mov    %r12,%r9
    614c:	4c 89 e2             	mov    %r12,%rdx
    614f:	4d 89 e0             	mov    %r12,%r8
    6152:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6158:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    615f:	48 89 d0             	mov    %rdx,%rax
    6162:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6169:	48 c1 e6 10          	shl    $0x10,%rsi
    616d:	48 39 f0             	cmp    %rsi,%rax
    6170:	73 7a                	jae    61ec <fwp_hof0.constprop.0+0x21c>
    6172:	48 89 c6             	mov    %rax,%rsi
    6175:	48 c1 ee 10          	shr    $0x10,%rsi
    6179:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    617d:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    6184:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6188:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    618c:	48 85 ff             	test   %rdi,%rdi
    618f:	74 5b                	je     61ec <fwp_hof0.constprop.0+0x21c>
    6191:	44 0f b6 16          	movzbl (%rsi),%r10d
    6195:	41 80 fa 02          	cmp    $0x2,%r10b
    6199:	0f 84 41 05 00 00    	je     66e0 <fwp_hof0.constprop.0+0x710>
    619f:	41 80 fa 01          	cmp    $0x1,%r10b
    61a3:	75 47                	jne    61ec <fwp_hof0.constprop.0+0x21c>
    61a5:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    61a9:	0f b7 c0             	movzwl %ax,%eax
    61ac:	8b 76 1c             	mov    0x1c(%rsi),%esi
    61af:	49 0f af c2          	imul   %r10,%rax
    61b3:	48 c1 e8 20          	shr    $0x20,%rax
    61b7:	48 39 f0             	cmp    %rsi,%rax
    61ba:	73 30                	jae    61ec <fwp_hof0.constprop.0+0x21c>
    61bc:	48 01 c7             	add    %rax,%rdi
    61bf:	80 3f 01             	cmpb   $0x1,(%rdi)
    61c2:	75 28                	jne    61ec <fwp_hof0.constprop.0+0x21c>
    61c4:	e9 5f 04 00 00       	jmp    6628 <fwp_hof0.constprop.0+0x658>
    61c9:	90                   	nop
    61ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61d1:	00 00 00 00 
    61d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61dc:	00 00 00 00 
    61e0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    61e4:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    61e8:	49 83 c6 01          	add    $0x1,%r14
    61ec:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    61f0:	0f 88 b8 0c 00 00    	js     6eae <fwp_hof0.constprop.0+0xede>
    61f6:	4a 89 0c f3          	mov    %rcx,(%rbx,%r14,8)
    61fa:	48 85 ed             	test   %rbp,%rbp
    61fd:	75 e1                	jne    61e0 <fwp_hof0.constprop.0+0x210>
    61ff:	4c 89 c7             	mov    %r8,%rdi
    6202:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    6208:	e8 f3 ea ff ff       	call   4d00 <fwp_drop0>
    620d:	31 c0                	xor    %eax,%eax
    620f:	48 85 c0             	test   %rax,%rax
    6212:	0f 85 f3 c4 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    6218:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    621f:	ff ff 7f 
    6222:	4c 23 33             	and    (%rbx),%r14
    6225:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    622c:	ff ff 1f 
    622f:	4c 39 f0             	cmp    %r14,%rax
    6232:	0f 82 98 0c 00 00    	jb     6ed0 <fwp_hof0.constprop.0+0xf00>
    6238:	4c 89 f7             	mov    %r14,%rdi
    623b:	e8 f0 e5 ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    6240:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6247:	48 89 c5             	mov    %rax,%rbp
    624a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6251:	48 c1 e2 10          	shl    $0x10,%rdx
    6255:	48 39 d0             	cmp    %rdx,%rax
    6258:	73 57                	jae    62b1 <fwp_hof0.constprop.0+0x2e1>
    625a:	48 89 c2             	mov    %rax,%rdx
    625d:	48 c1 ea 10          	shr    $0x10,%rdx
    6261:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6265:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    626c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6270:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6274:	48 85 c9             	test   %rcx,%rcx
    6277:	74 38                	je     62b1 <fwp_hof0.constprop.0+0x2e1>
    6279:	0f b6 32             	movzbl (%rdx),%esi
    627c:	40 80 fe 02          	cmp    $0x2,%sil
    6280:	0f 84 6a 08 00 00    	je     6af0 <fwp_hof0.constprop.0+0xb20>
    6286:	40 80 fe 01          	cmp    $0x1,%sil
    628a:	75 25                	jne    62b1 <fwp_hof0.constprop.0+0x2e1>
    628c:	8b 72 18             	mov    0x18(%rdx),%esi
    628f:	0f b7 c0             	movzwl %ax,%eax
    6292:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6295:	48 0f af c6          	imul   %rsi,%rax
    6299:	48 c1 e8 20          	shr    $0x20,%rax
    629d:	48 39 d0             	cmp    %rdx,%rax
    62a0:	73 0f                	jae    62b1 <fwp_hof0.constprop.0+0x2e1>
    62a2:	48 01 c1             	add    %rax,%rcx
    62a5:	80 39 ff             	cmpb   $0xff,(%rcx)
    62a8:	0f 84 54 08 00 00    	je     6b02 <fwp_hof0.constprop.0+0xb32>
    62ae:	c6 01 01             	movb   $0x1,(%rcx)
    62b1:	4d 85 f6             	test   %r14,%r14
    62b4:	0f 84 46 01 00 00    	je     6400 <fwp_hof0.constprop.0+0x430>
    62ba:	4c 8d 5b 08          	lea    0x8(%rbx),%r11
    62be:	48 8b 13             	mov    (%rbx),%rdx
    62c1:	31 c9                	xor    %ecx,%ecx
    62c3:	be 01 00 00 00       	mov    $0x1,%esi
    62c8:	4d 89 d9             	mov    %r11,%r9
    62cb:	31 c0                	xor    %eax,%eax
    62cd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    62d1:	0f 1f 40 00          	nopl   0x0(%rax)
    62d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62dc:	00 00 00 00 
    62e0:	48 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdi
    62e7:	ff ff 7f 
    62ea:	48 21 d7             	and    %rdx,%rdi
    62ed:	48 39 fe             	cmp    %rdi,%rsi
    62f0:	0f 84 f2 00 00 00    	je     63e8 <fwp_hof0.constprop.0+0x418>
    62f6:	48 39 f9             	cmp    %rdi,%rcx
    62f9:	0f 83 f2 00 00 00    	jae    63f1 <fwp_hof0.constprop.0+0x421>
    62ff:	48 85 d2             	test   %rdx,%rdx
    6302:	0f 88 f8 06 00 00    	js     6a00 <fwp_hof0.constprop.0+0xa30>
    6308:	48 39 fe             	cmp    %rdi,%rsi
    630b:	0f 83 e0 00 00 00    	jae    63f1 <fwp_hof0.constprop.0+0x421>
    6311:	f2 41 0f 10 01       	movsd  (%r9),%xmm0
    6316:	f2 0f 10 1d d2 51 00 	movsd  0x51d2(%rip),%xmm3        # b4f0 <msg.3+0xb0>
    631d:	00 
    631e:	4c 89 df             	mov    %r11,%rdi
    6321:	f2 0f 10 25 cf 51 00 	movsd  0x51cf(%rip),%xmm4        # b4f8 <msg.3+0xb8>
    6328:	00 
    6329:	f2 0f 5c d8          	subsd  %xmm0,%xmm3
    632d:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    6331:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6335:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    6339:	f3 0f 7e 4c 07 08    	movq   0x8(%rdi,%rax,1),%xmm1
    633f:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6343:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6347:	66 0f 28 c1          	movapd %xmm1,%xmm0
    634b:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    634f:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    6353:	f2 0f 59 05 a5 51 00 	mulsd  0x51a5(%rip),%xmm0        # b500 <msg.3+0xc0>
    635a:	00 
    635b:	4c 89 df             	mov    %r11,%rdi
    635e:	48 85 d2             	test   %rdx,%rdx
    6361:	0f 88 69 03 00 00    	js     66d0 <fwp_hof0.constprop.0+0x700>
    6367:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    636c:	0f 88 3c 0b 00 00    	js     6eae <fwp_hof0.constprop.0+0xede>
    6372:	f3 0f 7e 0c 07       	movq   (%rdi,%rax,1),%xmm1
    6377:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    637b:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    637f:	f2 0f 11 4c 28 08    	movsd  %xmm1,0x8(%rax,%rbp,1)
    6385:	49 39 fe             	cmp    %rdi,%r14
    6388:	74 76                	je     6400 <fwp_hof0.constprop.0+0x430>
    638a:	49 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r8
    6391:	ff ff 7f 
    6394:	48 8b 13             	mov    (%rbx),%rdx
    6397:	49 21 d0             	and    %rdx,%r8
    639a:	4c 39 c1             	cmp    %r8,%rcx
    639d:	73 52                	jae    63f1 <fwp_hof0.constprop.0+0x421>
    639f:	4c 8d 50 08          	lea    0x8(%rax),%r10
    63a3:	48 85 d2             	test   %rdx,%rdx
    63a6:	0f 88 94 06 00 00    	js     6a40 <fwp_hof0.constprop.0+0xa70>
    63ac:	4c 39 c7             	cmp    %r8,%rdi
    63af:	73 40                	jae    63f1 <fwp_hof0.constprop.0+0x421>
    63b1:	f2 0f 10 44 18 08    	movsd  0x8(%rax,%rbx,1),%xmm0
    63b7:	4c 89 d9             	mov    %r11,%rcx
    63ba:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    63be:	f3 42 0f 7e 14 11    	movq   (%rcx,%r10,1),%xmm2
    63c4:	48 83 c6 01          	add    $0x1,%rsi
    63c8:	49 83 c1 08          	add    $0x8,%r9
    63cc:	48 89 f9             	mov    %rdi,%rcx
    63cf:	4c 89 d0             	mov    %r10,%rax
    63d2:	f2 0f 5c d0          	subsd  %xmm0,%xmm2
    63d6:	f2 0f 59 15 0a 51 00 	mulsd  0x510a(%rip),%xmm2        # b4e8 <msg.3+0xa8>
    63dd:	00 
    63de:	e9 fd fe ff ff       	jmp    62e0 <fwp_hof0.constprop.0+0x310>
    63e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    63e8:	48 39 f1             	cmp    %rsi,%rcx
    63eb:	0f 82 23 0b 00 00    	jb     6f14 <fwp_hof0.constprop.0+0xf44>
    63f1:	48 8d 3d 30 6c 00 00 	lea    0x6c30(%rip),%rdi        # d028 <s0+0x8>
    63f8:	e8 b3 cc ff ff       	call   30b0 <fwp_trap>
    63fd:	0f 1f 00             	nopl   (%rax)
    6400:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6407:	48 89 d8             	mov    %rbx,%rax
    640a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6411:	48 c1 e2 10          	shl    $0x10,%rdx
    6415:	48 39 d0             	cmp    %rdx,%rax
    6418:	73 76                	jae    6490 <fwp_hof0.constprop.0+0x4c0>
    641a:	48 89 c2             	mov    %rax,%rdx
    641d:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    6424:	48 c1 ea 10          	shr    $0x10,%rdx
    6428:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    642c:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6430:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6434:	4d 85 f6             	test   %r14,%r14
    6437:	74 57                	je     6490 <fwp_hof0.constprop.0+0x4c0>
    6439:	0f b6 32             	movzbl (%rdx),%esi
    643c:	40 80 fe 02          	cmp    $0x2,%sil
    6440:	0f 84 1a 06 00 00    	je     6a60 <fwp_hof0.constprop.0+0xa90>
    6446:	40 80 fe 01          	cmp    $0x1,%sil
    644a:	75 44                	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    644c:	8b 72 18             	mov    0x18(%rdx),%esi
    644f:	0f b7 c0             	movzwl %ax,%eax
    6452:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6455:	48 0f af c6          	imul   %rsi,%rax
    6459:	48 c1 e8 20          	shr    $0x20,%rax
    645d:	48 39 d0             	cmp    %rdx,%rax
    6460:	73 2e                	jae    6490 <fwp_hof0.constprop.0+0x4c0>
    6462:	49 01 c6             	add    %rax,%r14
    6465:	41 0f b6 06          	movzbl (%r14),%eax
    6469:	84 c0                	test   %al,%al
    646b:	74 23                	je     6490 <fwp_hof0.constprop.0+0x4c0>
    646d:	3c 01                	cmp    $0x1,%al
    646f:	0f 84 fb 00 00 00    	je     6570 <fwp_hof0.constprop.0+0x5a0>
    6475:	3c ff                	cmp    $0xff,%al
    6477:	0f 84 0f 08 00 00    	je     6c8c <fwp_hof0.constprop.0+0xcbc>
    647d:	83 e8 01             	sub    $0x1,%eax
    6480:	41 88 06             	mov    %al,(%r14)
    6483:	66 90                	xchg   %ax,%ax
    6485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    648c:	00 00 00 00 
    6490:	4d 85 ff             	test   %r15,%r15
    6493:	0f 85 77 01 00 00    	jne    6610 <fwp_hof0.constprop.0+0x640>
    6499:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
    649e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64a2:	be 01 00 00 00       	mov    $0x1,%esi
    64a7:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    64ae:	00 00 
    64b0:	48 89 df             	mov    %rbx,%rdi
    64b3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    64b8:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    64bf:	ff ff 7f 
    64c2:	e8 f9 c9 ff ff       	call   2ec0 <buf_grow>
    64c7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    64cc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64d1:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    64d5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    64da:	48 8d 50 01          	lea    0x1(%rax),%rdx
    64de:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    64e3:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64e8:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    64ed:	48 8d 45 08          	lea    0x8(%rbp),%rax
    64f1:	48 89 04 24          	mov    %rax,(%rsp)
    64f5:	4c 23 75 00          	and    0x0(%rbp),%r14
    64f9:	75 5c                	jne    6557 <fwp_hof0.constprop.0+0x587>
    64fb:	e9 f0 01 00 00       	jmp    66f0 <fwp_hof0.constprop.0+0x720>
    6500:	4a 8b 34 fa          	mov    (%rdx,%r15,8),%rsi
    6504:	48 89 df             	mov    %rbx,%rdi
    6507:	48 8d 15 b2 66 00 00 	lea    0x66b2(%rip),%rdx        # cbc0 <d0>
    650e:	49 83 c7 01          	add    $0x1,%r15
    6512:	e8 b9 ea ff ff       	call   4fd0 <fwp_write.constprop.0>
    6517:	4d 39 fe             	cmp    %r15,%r14
    651a:	0f 84 d0 01 00 00    	je     66f0 <fwp_hof0.constprop.0+0x720>
    6520:	be 02 00 00 00       	mov    $0x2,%esi
    6525:	48 89 df             	mov    %rbx,%rdi
    6528:	e8 93 c9 ff ff       	call   2ec0 <buf_grow>
    652d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6532:	b8 2c 20 00 00       	mov    $0x202c,%eax
    6537:	48 03 54 24 10       	add    0x10(%rsp),%rdx
    653c:	66 89 02             	mov    %ax,(%rdx)
    653f:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6544:	48 8d 4a 02          	lea    0x2(%rdx),%rcx
    6548:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    654d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    6552:	c6 44 11 02 00       	movb   $0x0,0x2(%rcx,%rdx,1)
    6557:	48 8b 14 24          	mov    (%rsp),%rdx
    655b:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6560:	79 9e                	jns    6500 <fwp_hof0.constprop.0+0x530>
    6562:	48 8b 55 10          	mov    0x10(%rbp),%rdx
    6566:	eb 98                	jmp    6500 <fwp_hof0.constprop.0+0x530>
    6568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    656f:	00 
    6570:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    6577:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    657e:	48 89 d8             	mov    %rbx,%rax
    6581:	48 89 df             	mov    %rbx,%rdi
    6584:	48 29 f0             	sub    %rsi,%rax
    6587:	48 c1 e2 10          	shl    $0x10,%rdx
    658b:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    658f:	0f 88 db 04 00 00    	js     6a70 <fwp_hof0.constprop.0+0xaa0>
    6595:	48 39 d0             	cmp    %rdx,%rax
    6598:	0f 83 f2 fe ff ff    	jae    6490 <fwp_hof0.constprop.0+0x4c0>
    659e:	48 89 c2             	mov    %rax,%rdx
    65a1:	48 c1 ea 10          	shr    $0x10,%rdx
    65a5:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    65a9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    65ad:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    65b1:	48 85 c9             	test   %rcx,%rcx
    65b4:	0f 84 d6 fe ff ff    	je     6490 <fwp_hof0.constprop.0+0x4c0>
    65ba:	0f b6 32             	movzbl (%rdx),%esi
    65bd:	40 80 fe 02          	cmp    $0x2,%sil
    65c1:	0f 84 69 05 00 00    	je     6b30 <fwp_hof0.constprop.0+0xb60>
    65c7:	40 80 fe 01          	cmp    $0x1,%sil
    65cb:	0f 85 bf fe ff ff    	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    65d1:	8b 72 18             	mov    0x18(%rdx),%esi
    65d4:	0f b7 c0             	movzwl %ax,%eax
    65d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65da:	48 0f af c6          	imul   %rsi,%rax
    65de:	48 c1 e8 20          	shr    $0x20,%rax
    65e2:	48 39 d0             	cmp    %rdx,%rax
    65e5:	0f 83 a5 fe ff ff    	jae    6490 <fwp_hof0.constprop.0+0x4c0>
    65eb:	48 01 c1             	add    %rax,%rcx
    65ee:	80 39 01             	cmpb   $0x1,(%rcx)
    65f1:	0f 85 99 fe ff ff    	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    65f7:	48 89 df             	mov    %rbx,%rdi
    65fa:	e8 d1 d9 ff ff       	call   3fd0 <fwp_mem_free>
    65ff:	4d 85 ff             	test   %r15,%r15
    6602:	0f 84 91 fe ff ff    	je     6499 <fwp_hof0.constprop.0+0x4c9>
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 
    6610:	31 c0                	xor    %eax,%eax
    6612:	49 83 ef 01          	sub    $0x1,%r15
    6616:	48 89 eb             	mov    %rbp,%rbx
    6619:	0f 90 c0             	seto   %al
    661c:	e9 ee fb ff ff       	jmp    620f <fwp_hof0.constprop.0+0x23f>
    6621:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6628:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    662c:	0f 88 7c 08 00 00    	js     6eae <fwp_hof0.constprop.0+0xede>
    6632:	4a 89 0c f3          	mov    %rcx,(%rbx,%r14,8)
    6636:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    663d:	49 2b 95 b0 13 00 00 	sub    0x13b0(%r13),%rdx
    6644:	48 c1 e0 10          	shl    $0x10,%rax
    6648:	48 39 c2             	cmp    %rax,%rdx
    664b:	73 58                	jae    66a5 <fwp_hof0.constprop.0+0x6d5>
    664d:	48 89 d0             	mov    %rdx,%rax
    6650:	48 c1 e8 10          	shr    $0x10,%rax
    6654:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    6658:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    665f:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    6663:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6667:	48 85 c9             	test   %rcx,%rcx
    666a:	74 39                	je     66a5 <fwp_hof0.constprop.0+0x6d5>
    666c:	0f b6 30             	movzbl (%rax),%esi
    666f:	40 80 fe 02          	cmp    $0x2,%sil
    6673:	0f 84 c7 04 00 00    	je     6b40 <fwp_hof0.constprop.0+0xb70>
    6679:	40 80 fe 01          	cmp    $0x1,%sil
    667d:	75 26                	jne    66a5 <fwp_hof0.constprop.0+0x6d5>
    667f:	8b 70 18             	mov    0x18(%rax),%esi
    6682:	0f b7 d2             	movzwl %dx,%edx
    6685:	8b 40 1c             	mov    0x1c(%rax),%eax
    6688:	48 0f af d6          	imul   %rsi,%rdx
    668c:	48 c1 ea 20          	shr    $0x20,%rdx
    6690:	48 39 c2             	cmp    %rax,%rdx
    6693:	73 10                	jae    66a5 <fwp_hof0.constprop.0+0x6d5>
    6695:	48 01 d1             	add    %rdx,%rcx
    6698:	80 39 01             	cmpb   $0x1,(%rcx)
    669b:	75 08                	jne    66a5 <fwp_hof0.constprop.0+0x6d5>
    669d:	4c 89 cf             	mov    %r9,%rdi
    66a0:	e8 2b d9 ff ff       	call   3fd0 <fwp_mem_free>
    66a5:	48 85 ed             	test   %rbp,%rbp
    66a8:	0f 84 b2 04 00 00    	je     6b60 <fwp_hof0.constprop.0+0xb90>
    66ae:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    66b2:	49 89 e9             	mov    %rbp,%r9
    66b5:	48 89 ea             	mov    %rbp,%rdx
    66b8:	49 89 e8             	mov    %rbp,%r8
    66bb:	49 83 c6 01          	add    $0x1,%r14
    66bf:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    66c3:	e9 90 fa ff ff       	jmp    6158 <fwp_hof0.constprop.0+0x188>
    66c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    66cf:	00 
    66d0:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    66d4:	e9 8e fc ff ff       	jmp    6367 <fwp_hof0.constprop.0+0x397>
    66d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66e0:	66 85 c0             	test   %ax,%ax
    66e3:	0f 85 03 fb ff ff    	jne    61ec <fwp_hof0.constprop.0+0x21c>
    66e9:	e9 d1 fa ff ff       	jmp    61bf <fwp_hof0.constprop.0+0x1ef>
    66ee:	66 90                	xchg   %ax,%ax
    66f0:	be 01 00 00 00       	mov    $0x1,%esi
    66f5:	48 89 df             	mov    %rbx,%rdi
    66f8:	e8 c3 c7 ff ff       	call   2ec0 <buf_grow>
    66fd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6702:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6707:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    670b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6710:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6714:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    6719:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    671e:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6723:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    6728:	48 8d 05 ff 48 00 00 	lea    0x48ff(%rip),%rax        # b02e <_IO_stdin_used+0x2e>
    672f:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    6734:	48 85 c9             	test   %rcx,%rcx
    6737:	48 0f 44 c8          	cmove  %rax,%rcx
    673b:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    673f:	0f 87 c3 07 00 00    	ja     6f08 <fwp_hof0.constprop.0+0xf38>
    6745:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    6749:	be 01 00 00 00       	mov    $0x1,%esi
    674e:	48 89 0c 24          	mov    %rcx,(%rsp)
    6752:	e8 a9 de ff ff       	call   4600 <fwp_heap_alloc>
    6757:	48 8b 34 24          	mov    (%rsp),%rsi
    675b:	4c 89 fa             	mov    %r15,%rdx
    675e:	4c 89 38             	mov    %r15,(%rax)
    6761:	48 8d 58 08          	lea    0x8(%rax),%rbx
    6765:	49 89 c6             	mov    %rax,%r14
    6768:	48 89 df             	mov    %rbx,%rdi
    676b:	e8 00 be ff ff       	call   2570 <memcpy@plt>
    6770:	43 c6 44 3e 08 00    	movb   $0x0,0x8(%r14,%r15,1)
    6776:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    677b:	e8 20 bc ff ff       	call   23a0 <free@plt>
    6780:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    6787:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    678e:	4c 89 f0             	mov    %r14,%rax
    6791:	48 29 c8             	sub    %rcx,%rax
    6794:	48 c1 e2 10          	shl    $0x10,%rdx
    6798:	48 39 d0             	cmp    %rdx,%rax
    679b:	73 6b                	jae    6808 <fwp_hof0.constprop.0+0x838>
    679d:	48 89 c6             	mov    %rax,%rsi
    67a0:	48 c1 ee 10          	shr    $0x10,%rsi
    67a4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    67a8:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    67af:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    67b3:	4c 8b 7e 20          	mov    0x20(%rsi),%r15
    67b7:	4d 85 ff             	test   %r15,%r15
    67ba:	74 4c                	je     6808 <fwp_hof0.constprop.0+0x838>
    67bc:	0f b6 3e             	movzbl (%rsi),%edi
    67bf:	40 80 ff 02          	cmp    $0x2,%dil
    67c3:	0f 84 87 04 00 00    	je     6c50 <fwp_hof0.constprop.0+0xc80>
    67c9:	40 80 ff 01          	cmp    $0x1,%dil
    67cd:	75 39                	jne    6808 <fwp_hof0.constprop.0+0x838>
    67cf:	8b 7e 18             	mov    0x18(%rsi),%edi
    67d2:	0f b7 c0             	movzwl %ax,%eax
    67d5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    67d8:	48 0f af c7          	imul   %rdi,%rax
    67dc:	48 c1 e8 20          	shr    $0x20,%rax
    67e0:	48 39 f0             	cmp    %rsi,%rax
    67e3:	73 23                	jae    6808 <fwp_hof0.constprop.0+0x838>
    67e5:	49 01 c7             	add    %rax,%r15
    67e8:	41 80 3f ff          	cmpb   $0xff,(%r15)
    67ec:	0f 84 71 04 00 00    	je     6c63 <fwp_hof0.constprop.0+0xc93>
    67f2:	41 c6 07 01          	movb   $0x1,(%r15)
    67f6:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    67fd:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    6804:	48 c1 e2 10          	shl    $0x10,%rdx
    6808:	48 89 e8             	mov    %rbp,%rax
    680b:	48 29 c8             	sub    %rcx,%rax
    680e:	48 39 d0             	cmp    %rdx,%rax
    6811:	73 6d                	jae    6880 <fwp_hof0.constprop.0+0x8b0>
    6813:	48 89 c2             	mov    %rax,%rdx
    6816:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    681d:	48 c1 ea 10          	shr    $0x10,%rdx
    6821:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6825:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6829:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    682d:	4d 85 ff             	test   %r15,%r15
    6830:	74 4e                	je     6880 <fwp_hof0.constprop.0+0x8b0>
    6832:	0f b6 32             	movzbl (%rdx),%esi
    6835:	40 80 fe 02          	cmp    $0x2,%sil
    6839:	0f 84 31 03 00 00    	je     6b70 <fwp_hof0.constprop.0+0xba0>
    683f:	40 80 fe 01          	cmp    $0x1,%sil
    6843:	75 3b                	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    6845:	8b 72 18             	mov    0x18(%rdx),%esi
    6848:	0f b7 c0             	movzwl %ax,%eax
    684b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    684e:	48 0f af c6          	imul   %rsi,%rax
    6852:	48 c1 e8 20          	shr    $0x20,%rax
    6856:	48 39 d0             	cmp    %rdx,%rax
    6859:	73 25                	jae    6880 <fwp_hof0.constprop.0+0x8b0>
    685b:	49 01 c7             	add    %rax,%r15
    685e:	41 0f b6 07          	movzbl (%r15),%eax
    6862:	84 c0                	test   %al,%al
    6864:	74 1a                	je     6880 <fwp_hof0.constprop.0+0x8b0>
    6866:	3c 01                	cmp    $0x1,%al
    6868:	0f 84 02 01 00 00    	je     6970 <fwp_hof0.constprop.0+0x9a0>
    686e:	3c ff                	cmp    $0xff,%al
    6870:	0f 84 89 04 00 00    	je     6cff <fwp_hof0.constprop.0+0xd2f>
    6876:	83 e8 01             	sub    $0x1,%eax
    6879:	41 88 07             	mov    %al,(%r15)
    687c:	0f 1f 40 00          	nopl   0x0(%rax)
    6880:	49 8b 16             	mov    (%r14),%rdx
    6883:	48 8b 0d ee 8a 01 00 	mov    0x18aee(%rip),%rcx        # 1f378 <fwp_prog_out>
    688a:	be 01 00 00 00       	mov    $0x1,%esi
    688f:	48 89 df             	mov    %rbx,%rdi
    6892:	e8 a9 bd ff ff       	call   2640 <fwrite@plt>
    6897:	48 8b 35 da 8a 01 00 	mov    0x18ada(%rip),%rsi        # 1f378 <fwp_prog_out>
    689e:	bf 0a 00 00 00       	mov    $0xa,%edi
    68a3:	e8 18 bc ff ff       	call   24c0 <fputc@plt>
    68a8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    68af:	4c 89 f0             	mov    %r14,%rax
    68b2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    68b9:	48 c1 e2 10          	shl    $0x10,%rdx
    68bd:	48 39 d0             	cmp    %rdx,%rax
    68c0:	73 6e                	jae    6930 <fwp_hof0.constprop.0+0x960>
    68c2:	48 89 c2             	mov    %rax,%rdx
    68c5:	48 c1 ea 10          	shr    $0x10,%rdx
    68c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68cd:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    68d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    68d8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    68dc:	48 85 db             	test   %rbx,%rbx
    68df:	74 4f                	je     6930 <fwp_hof0.constprop.0+0x960>
    68e1:	0f b6 0a             	movzbl (%rdx),%ecx
    68e4:	80 f9 02             	cmp    $0x2,%cl
    68e7:	0f 84 53 03 00 00    	je     6c40 <fwp_hof0.constprop.0+0xc70>
    68ed:	80 f9 01             	cmp    $0x1,%cl
    68f0:	75 3e                	jne    6930 <fwp_hof0.constprop.0+0x960>
    68f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    68f5:	0f b7 c0             	movzwl %ax,%eax
    68f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    68fb:	48 0f af c1          	imul   %rcx,%rax
    68ff:	48 c1 e8 20          	shr    $0x20,%rax
    6903:	48 39 d0             	cmp    %rdx,%rax
    6906:	73 28                	jae    6930 <fwp_hof0.constprop.0+0x960>
    6908:	48 01 c3             	add    %rax,%rbx
    690b:	0f b6 03             	movzbl (%rbx),%eax
    690e:	84 c0                	test   %al,%al
    6910:	74 1e                	je     6930 <fwp_hof0.constprop.0+0x960>
    6912:	3c 01                	cmp    $0x1,%al
    6914:	0f 84 06 02 00 00    	je     6b20 <fwp_hof0.constprop.0+0xb50>
    691a:	3c ff                	cmp    $0xff,%al
    691c:	0f 84 5d 04 00 00    	je     6d7f <fwp_hof0.constprop.0+0xdaf>
    6922:	83 e8 01             	sub    $0x1,%eax
    6925:	88 03                	mov    %al,(%rbx)
    6927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    692e:	00 00 
    6930:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6935:	48 8b 40 10          	mov    0x10(%rax),%rax
    6939:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    693e:	48 85 c0             	test   %rax,%rax
    6941:	0f 85 c9 f6 ff ff    	jne    6010 <fwp_hof0.constprop.0+0x40>
    6947:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    694c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6953:	00 00 
    6955:	0f 85 ce 05 00 00    	jne    6f29 <fwp_hof0.constprop.0+0xf59>
    695b:	48 83 c4 38          	add    $0x38,%rsp
    695f:	31 c0                	xor    %eax,%eax
    6961:	5b                   	pop    %rbx
    6962:	5d                   	pop    %rbp
    6963:	41 5c                	pop    %r12
    6965:	41 5d                	pop    %r13
    6967:	41 5e                	pop    %r14
    6969:	41 5f                	pop    %r15
    696b:	c3                   	ret
    696c:	0f 1f 40 00          	nopl   0x0(%rax)
    6970:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6975:	0f 88 05 02 00 00    	js     6b80 <fwp_hof0.constprop.0+0xbb0>
    697b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6982:	48 89 e8             	mov    %rbp,%rax
    6985:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    698c:	48 c1 e2 10          	shl    $0x10,%rdx
    6990:	48 39 d0             	cmp    %rdx,%rax
    6993:	0f 83 e7 fe ff ff    	jae    6880 <fwp_hof0.constprop.0+0x8b0>
    6999:	48 89 c2             	mov    %rax,%rdx
    699c:	48 c1 ea 10          	shr    $0x10,%rdx
    69a0:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    69a4:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    69a8:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    69ac:	48 85 c9             	test   %rcx,%rcx
    69af:	0f 84 cb fe ff ff    	je     6880 <fwp_hof0.constprop.0+0x8b0>
    69b5:	0f b6 32             	movzbl (%rdx),%esi
    69b8:	40 80 fe 02          	cmp    $0x2,%sil
    69bc:	0f 84 ae 02 00 00    	je     6c70 <fwp_hof0.constprop.0+0xca0>
    69c2:	40 80 fe 01          	cmp    $0x1,%sil
    69c6:	0f 85 b4 fe ff ff    	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    69cc:	8b 72 18             	mov    0x18(%rdx),%esi
    69cf:	0f b7 c0             	movzwl %ax,%eax
    69d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69d5:	48 0f af c6          	imul   %rsi,%rax
    69d9:	48 c1 e8 20          	shr    $0x20,%rax
    69dd:	48 39 d0             	cmp    %rdx,%rax
    69e0:	0f 83 9a fe ff ff    	jae    6880 <fwp_hof0.constprop.0+0x8b0>
    69e6:	48 01 c1             	add    %rax,%rcx
    69e9:	80 39 01             	cmpb   $0x1,(%rcx)
    69ec:	0f 85 8e fe ff ff    	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    69f2:	48 89 ef             	mov    %rbp,%rdi
    69f5:	e8 d6 d5 ff ff       	call   3fd0 <fwp_mem_free>
    69fa:	e9 81 fe ff ff       	jmp    6880 <fwp_hof0.constprop.0+0x8b0>
    69ff:	90                   	nop
    6a00:	48 39 fe             	cmp    %rdi,%rsi
    6a03:	0f 83 e8 f9 ff ff    	jae    63f1 <fwp_hof0.constprop.0+0x421>
    6a09:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    6a0d:	f2 0f 10 1d db 4a 00 	movsd  0x4adb(%rip),%xmm3        # b4f0 <msg.3+0xb0>
    6a14:	00 
    6a15:	f2 0f 10 25 db 4a 00 	movsd  0x4adb(%rip),%xmm4        # b4f8 <msg.3+0xb8>
    6a1c:	00 
    6a1d:	f2 0f 10 04 07       	movsd  (%rdi,%rax,1),%xmm0
    6a22:	f2 0f 5c d8          	subsd  %xmm0,%xmm3
    6a26:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    6a2a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6a2e:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    6a32:	e9 02 f9 ff ff       	jmp    6339 <fwp_hof0.constprop.0+0x369>
    6a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a3e:	00 00 
    6a40:	4c 39 c7             	cmp    %r8,%rdi
    6a43:	0f 83 a8 f9 ff ff    	jae    63f1 <fwp_hof0.constprop.0+0x421>
    6a49:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    6a4d:	f2 0f 10 04 01       	movsd  (%rcx,%rax,1),%xmm0
    6a52:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6a56:	e9 63 f9 ff ff       	jmp    63be <fwp_hof0.constprop.0+0x3ee>
    6a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a60:	66 85 c0             	test   %ax,%ax
    6a63:	0f 85 27 fa ff ff    	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    6a69:	e9 f7 f9 ff ff       	jmp    6465 <fwp_hof0.constprop.0+0x495>
    6a6e:	66 90                	xchg   %ax,%ax
    6a70:	48 8b 5b 08          	mov    0x8(%rbx),%rbx
    6a74:	48 39 d0             	cmp    %rdx,%rax
    6a77:	73 63                	jae    6adc <fwp_hof0.constprop.0+0xb0c>
    6a79:	49 89 c0             	mov    %rax,%r8
    6a7c:	49 c1 e8 10          	shr    $0x10,%r8
    6a80:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    6a84:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
    6a88:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    6a8c:	4d 85 c0             	test   %r8,%r8
    6a8f:	74 4b                	je     6adc <fwp_hof0.constprop.0+0xb0c>
    6a91:	44 0f b6 09          	movzbl (%rcx),%r9d
    6a95:	41 80 f9 02          	cmp    $0x2,%r9b
    6a99:	0f 84 df 01 00 00    	je     6c7e <fwp_hof0.constprop.0+0xcae>
    6a9f:	41 80 f9 01          	cmp    $0x1,%r9b
    6aa3:	75 37                	jne    6adc <fwp_hof0.constprop.0+0xb0c>
    6aa5:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    6aa9:	0f b7 c0             	movzwl %ax,%eax
    6aac:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6aaf:	49 0f af c1          	imul   %r9,%rax
    6ab3:	48 c1 e8 20          	shr    $0x20,%rax
    6ab7:	48 39 c8             	cmp    %rcx,%rax
    6aba:	73 20                	jae    6adc <fwp_hof0.constprop.0+0xb0c>
    6abc:	49 01 c0             	add    %rax,%r8
    6abf:	41 80 38 01          	cmpb   $0x1,(%r8)
    6ac3:	75 17                	jne    6adc <fwp_hof0.constprop.0+0xb0c>
    6ac5:	e8 06 d5 ff ff       	call   3fd0 <fwp_mem_free>
    6aca:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6ad1:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    6ad8:	48 c1 e2 10          	shl    $0x10,%rdx
    6adc:	48 89 d8             	mov    %rbx,%rax
    6adf:	48 29 f0             	sub    %rsi,%rax
    6ae2:	48 39 d0             	cmp    %rdx,%rax
    6ae5:	0f 82 2f f9 ff ff    	jb     641a <fwp_hof0.constprop.0+0x44a>
    6aeb:	e9 a0 f9 ff ff       	jmp    6490 <fwp_hof0.constprop.0+0x4c0>
    6af0:	66 85 c0             	test   %ax,%ax
    6af3:	0f 85 b8 f7 ff ff    	jne    62b1 <fwp_hof0.constprop.0+0x2e1>
    6af9:	80 39 ff             	cmpb   $0xff,(%rcx)
    6afc:	0f 85 ac f7 ff ff    	jne    62ae <fwp_hof0.constprop.0+0x2de>
    6b02:	48 89 cf             	mov    %rcx,%rdi
    6b05:	48 89 0c 24          	mov    %rcx,(%rsp)
    6b09:	e8 82 d2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6b0e:	48 8b 0c 24          	mov    (%rsp),%rcx
    6b12:	e9 97 f7 ff ff       	jmp    62ae <fwp_hof0.constprop.0+0x2de>
    6b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b1e:	00 00 
    6b20:	4c 89 f7             	mov    %r14,%rdi
    6b23:	e8 58 da ff ff       	call   4580 <fwp_rc_free_arr>
    6b28:	e9 03 fe ff ff       	jmp    6930 <fwp_hof0.constprop.0+0x960>
    6b2d:	0f 1f 00             	nopl   (%rax)
    6b30:	66 85 c0             	test   %ax,%ax
    6b33:	0f 85 57 f9 ff ff    	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    6b39:	e9 b0 fa ff ff       	jmp    65ee <fwp_hof0.constprop.0+0x61e>
    6b3e:	66 90                	xchg   %ax,%ax
    6b40:	66 85 d2             	test   %dx,%dx
    6b43:	0f 84 4f fb ff ff    	je     6698 <fwp_hof0.constprop.0+0x6c8>
    6b49:	48 85 ed             	test   %rbp,%rbp
    6b4c:	0f 85 5c fb ff ff    	jne    66ae <fwp_hof0.constprop.0+0x6de>
    6b52:	0f 1f 00             	nopl   (%rax)
    6b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b5c:	00 00 00 00 
    6b60:	45 31 c0             	xor    %r8d,%r8d
    6b63:	e9 97 f6 ff ff       	jmp    61ff <fwp_hof0.constprop.0+0x22f>
    6b68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b6f:	00 
    6b70:	66 85 c0             	test   %ax,%ax
    6b73:	0f 85 07 fd ff ff    	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    6b79:	e9 e0 fc ff ff       	jmp    685e <fwp_hof0.constprop.0+0x88e>
    6b7e:	66 90                	xchg   %ax,%ax
    6b80:	48 89 ef             	mov    %rbp,%rdi
    6b83:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6b87:	e8 f4 d9 ff ff       	call   4580 <fwp_rc_free_arr>
    6b8c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6b93:	4c 89 f8             	mov    %r15,%rax
    6b96:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6b9d:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba1:	48 39 d0             	cmp    %rdx,%rax
    6ba4:	0f 83 d6 fc ff ff    	jae    6880 <fwp_hof0.constprop.0+0x8b0>
    6baa:	4c 89 fd             	mov    %r15,%rbp
    6bad:	e9 61 fc ff ff       	jmp    6813 <fwp_hof0.constprop.0+0x843>
    6bb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bb8:	66 85 c0             	test   %ax,%ax
    6bbb:	0f 85 75 f5 ff ff    	jne    6136 <fwp_hof0.constprop.0+0x166>
    6bc1:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6bc5:	0f 85 67 f5 ff ff    	jne    6132 <fwp_hof0.constprop.0+0x162>
    6bcb:	48 89 ef             	mov    %rbp,%rdi
    6bce:	e8 bd d1 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6bd3:	e9 5a f5 ff ff       	jmp    6132 <fwp_hof0.constprop.0+0x162>
    6bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bdf:	00 
    6be0:	66 85 c0             	test   %ax,%ax
    6be3:	0f 84 8a f4 ff ff    	je     6073 <fwp_hof0.constprop.0+0xa3>
    6be9:	4d 85 e4             	test   %r12,%r12
    6bec:	0f 85 9e f4 ff ff    	jne    6090 <fwp_hof0.constprop.0+0xc0>
    6bf2:	31 ff                	xor    %edi,%edi
    6bf4:	e8 37 dc ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    6bf9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6c00:	48 89 c3             	mov    %rax,%rbx
    6c03:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6c0a:	48 c1 e2 10          	shl    $0x10,%rdx
    6c0e:	48 39 d0             	cmp    %rdx,%rax
    6c11:	0f 83 49 ff ff ff    	jae    6b60 <fwp_hof0.constprop.0+0xb90>
    6c17:	48 89 c2             	mov    %rax,%rdx
    6c1a:	48 c1 ea 10          	shr    $0x10,%rdx
    6c1e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c22:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6c29:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6c2d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6c31:	48 85 ed             	test   %rbp,%rbp
    6c34:	0f 85 c4 f4 ff ff    	jne    60fe <fwp_hof0.constprop.0+0x12e>
    6c3a:	e9 21 ff ff ff       	jmp    6b60 <fwp_hof0.constprop.0+0xb90>
    6c3f:	90                   	nop
    6c40:	66 85 c0             	test   %ax,%ax
    6c43:	0f 85 e7 fc ff ff    	jne    6930 <fwp_hof0.constprop.0+0x960>
    6c49:	e9 bd fc ff ff       	jmp    690b <fwp_hof0.constprop.0+0x93b>
    6c4e:	66 90                	xchg   %ax,%ax
    6c50:	66 85 c0             	test   %ax,%ax
    6c53:	0f 85 af fb ff ff    	jne    6808 <fwp_hof0.constprop.0+0x838>
    6c59:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6c5d:	0f 85 8f fb ff ff    	jne    67f2 <fwp_hof0.constprop.0+0x822>
    6c63:	4c 89 ff             	mov    %r15,%rdi
    6c66:	e8 25 d1 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6c6b:	e9 82 fb ff ff       	jmp    67f2 <fwp_hof0.constprop.0+0x822>
    6c70:	66 85 c0             	test   %ax,%ax
    6c73:	0f 85 07 fc ff ff    	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    6c79:	e9 6b fd ff ff       	jmp    69e9 <fwp_hof0.constprop.0+0xa19>
    6c7e:	66 85 c0             	test   %ax,%ax
    6c81:	0f 85 55 fe ff ff    	jne    6adc <fwp_hof0.constprop.0+0xb0c>
    6c87:	e9 33 fe ff ff       	jmp    6abf <fwp_hof0.constprop.0+0xaef>
    6c8c:	4c 89 f0             	mov    %r14,%rax
    6c8f:	48 c1 e8 11          	shr    $0x11,%rax
    6c93:	4c 31 f0             	xor    %r14,%rax
    6c96:	48 89 c2             	mov    %rax,%rdx
    6c99:	48 c1 ea 09          	shr    $0x9,%rdx
    6c9d:	48 31 d0             	xor    %rdx,%rax
    6ca0:	0f b6 d0             	movzbl %al,%edx
    6ca3:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    6caa:	00 
    6cab:	48 85 c0             	test   %rax,%rax
    6cae:	75 1d                	jne    6ccd <fwp_hof0.constprop.0+0xcfd>
    6cb0:	e9 30 02 00 00       	jmp    6ee5 <fwp_hof0.constprop.0+0xf15>
    6cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cbc:	00 00 00 00 
    6cc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6cc4:	48 85 c0             	test   %rax,%rax
    6cc7:	0f 84 18 02 00 00    	je     6ee5 <fwp_hof0.constprop.0+0xf15>
    6ccd:	48 89 c2             	mov    %rax,%rdx
    6cd0:	4c 3b 30             	cmp    (%rax),%r14
    6cd3:	75 eb                	jne    6cc0 <fwp_hof0.constprop.0+0xcf0>
    6cd5:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6cd9:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    6cdd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ce1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ce8:	0f 85 a2 f7 ff ff    	jne    6490 <fwp_hof0.constprop.0+0x4c0>
    6cee:	4c 89 f7             	mov    %r14,%rdi
    6cf1:	e8 9a d0 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6cf6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    6cfa:	e9 91 f7 ff ff       	jmp    6490 <fwp_hof0.constprop.0+0x4c0>
    6cff:	4c 89 fa             	mov    %r15,%rdx
    6d02:	48 c1 ea 11          	shr    $0x11,%rdx
    6d06:	4c 31 fa             	xor    %r15,%rdx
    6d09:	48 89 d0             	mov    %rdx,%rax
    6d0c:	48 c1 e8 09          	shr    $0x9,%rax
    6d10:	48 31 c2             	xor    %rax,%rdx
    6d13:	0f b6 d2             	movzbl %dl,%edx
    6d16:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    6d1d:	00 
    6d1e:	48 85 c0             	test   %rax,%rax
    6d21:	75 2a                	jne    6d4d <fwp_hof0.constprop.0+0xd7d>
    6d23:	e9 bd 01 00 00       	jmp    6ee5 <fwp_hof0.constprop.0+0xf15>
    6d28:	66 90                	xchg   %ax,%ax
    6d2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d31:	00 00 00 00 
    6d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d3c:	00 00 00 00 
    6d40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6d44:	48 85 c0             	test   %rax,%rax
    6d47:	0f 84 98 01 00 00    	je     6ee5 <fwp_hof0.constprop.0+0xf15>
    6d4d:	48 89 c2             	mov    %rax,%rdx
    6d50:	4c 3b 38             	cmp    (%rax),%r15
    6d53:	75 eb                	jne    6d40 <fwp_hof0.constprop.0+0xd70>
    6d55:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6d59:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6d5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6d68:	0f 85 12 fb ff ff    	jne    6880 <fwp_hof0.constprop.0+0x8b0>
    6d6e:	4c 89 ff             	mov    %r15,%rdi
    6d71:	e8 1a d0 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6d76:	41 c6 07 fe          	movb   $0xfe,(%r15)
    6d7a:	e9 01 fb ff ff       	jmp    6880 <fwp_hof0.constprop.0+0x8b0>
    6d7f:	48 89 d8             	mov    %rbx,%rax
    6d82:	48 c1 e8 11          	shr    $0x11,%rax
    6d86:	48 31 d8             	xor    %rbx,%rax
    6d89:	48 89 c2             	mov    %rax,%rdx
    6d8c:	48 c1 ea 09          	shr    $0x9,%rdx
    6d90:	48 31 d0             	xor    %rdx,%rax
    6d93:	0f b6 d0             	movzbl %al,%edx
    6d96:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    6d9d:	00 
    6d9e:	48 85 c0             	test   %rax,%rax
    6da1:	75 2a                	jne    6dcd <fwp_hof0.constprop.0+0xdfd>
    6da3:	e9 3d 01 00 00       	jmp    6ee5 <fwp_hof0.constprop.0+0xf15>
    6da8:	66 90                	xchg   %ax,%ax
    6daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6db1:	00 00 00 00 
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	0f 84 18 01 00 00    	je     6ee5 <fwp_hof0.constprop.0+0xf15>
    6dcd:	48 89 c2             	mov    %rax,%rdx
    6dd0:	48 3b 18             	cmp    (%rax),%rbx
    6dd3:	75 eb                	jne    6dc0 <fwp_hof0.constprop.0+0xdf0>
    6dd5:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6dd9:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6ddd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6de1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6de8:	0f 85 42 fb ff ff    	jne    6930 <fwp_hof0.constprop.0+0x960>
    6dee:	48 89 df             	mov    %rbx,%rdi
    6df1:	e8 9a cf ff ff       	call   3d90 <fwp_rc_forget_slot>
    6df6:	c6 03 fe             	movb   $0xfe,(%rbx)
    6df9:	e9 32 fb ff ff       	jmp    6930 <fwp_hof0.constprop.0+0x960>
    6dfe:	48 89 d9             	mov    %rbx,%rcx
    6e01:	48 c1 e9 11          	shr    $0x11,%rcx
    6e05:	48 31 d9             	xor    %rbx,%rcx
    6e08:	48 89 ca             	mov    %rcx,%rdx
    6e0b:	48 c1 ea 09          	shr    $0x9,%rdx
    6e0f:	48 31 d1             	xor    %rdx,%rcx
    6e12:	0f b6 c9             	movzbl %cl,%ecx
    6e15:	49 8d ac cd 48 14 00 	lea    0x1448(%r13,%rcx,8),%rbp
    6e1c:	00 
    6e1d:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    6e21:	49 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%r13,%rcx,8)
    6e28:	00 00 
    6e2a:	75 20                	jne    6e4c <fwp_hof0.constprop.0+0xe7c>
    6e2c:	e9 89 00 00 00       	jmp    6eba <fwp_hof0.constprop.0+0xeea>
    6e31:	0f 1f 40 00          	nopl   0x0(%rax)
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6e44:	48 85 c9             	test   %rcx,%rcx
    6e47:	74 27                	je     6e70 <fwp_hof0.constprop.0+0xea0>
    6e49:	48 89 ca             	mov    %rcx,%rdx
    6e4c:	48 39 1a             	cmp    %rbx,(%rdx)
    6e4f:	75 ef                	jne    6e40 <fwp_hof0.constprop.0+0xe70>
    6e51:	3c fe                	cmp    $0xfe,%al
    6e53:	74 6e                	je     6ec3 <fwp_hof0.constprop.0+0xef3>
    6e55:	48 8b 42 08          	mov    0x8(%rdx),%rax
    6e59:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    6e5d:	0f 84 93 00 00 00    	je     6ef6 <fwp_hof0.constprop.0+0xf26>
    6e63:	48 83 c0 01          	add    $0x1,%rax
    6e67:	48 89 42 08          	mov    %rax,0x8(%rdx)
    6e6b:	e9 17 f2 ff ff       	jmp    6087 <fwp_hof0.constprop.0+0xb7>
    6e70:	3c fe                	cmp    $0xfe,%al
    6e72:	75 71                	jne    6ee5 <fwp_hof0.constprop.0+0xf15>
    6e74:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    6e78:	bf 18 00 00 00       	mov    $0x18,%edi
    6e7d:	e8 fe b6 ff ff       	call   2580 <malloc@plt>
    6e82:	48 85 c0             	test   %rax,%rax
    6e85:	74 6a                	je     6ef1 <fwp_hof0.constprop.0+0xf21>
    6e87:	48 89 18             	mov    %rbx,(%rax)
    6e8a:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    6e91:	00 
    6e92:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    6e99:	00 
    6e9a:	48 89 45 00          	mov    %rax,0x0(%rbp)
    6e9e:	c6 03 ff             	movb   $0xff,(%rbx)
    6ea1:	49 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%r13)
    6ea8:	01 
    6ea9:	e9 d9 f1 ff ff       	jmp    6087 <fwp_hof0.constprop.0+0xb7>
    6eae:	48 8d 3d 23 44 00 00 	lea    0x4423(%rip),%rdi        # b2d8 <_IO_stdin_used+0x2d8>
    6eb5:	e8 f6 c1 ff ff       	call   30b0 <fwp_trap>
    6eba:	3c fe                	cmp    $0xfe,%al
    6ebc:	75 1e                	jne    6edc <fwp_hof0.constprop.0+0xf0c>
    6ebe:	48 85 d2             	test   %rdx,%rdx
    6ec1:	74 b5                	je     6e78 <fwp_hof0.constprop.0+0xea8>
    6ec3:	48 8d 3d e6 43 00 00 	lea    0x43e6(%rip),%rdi        # b2b0 <_IO_stdin_used+0x2b0>
    6eca:	e8 e1 c1 ff ff       	call   30b0 <fwp_trap>
    6ecf:	90                   	nop
    6ed0:	48 8d 3d ce 41 00 00 	lea    0x41ce(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    6ed7:	e8 d4 c1 ff ff       	call   30b0 <fwp_trap>
    6edc:	48 85 d2             	test   %rdx,%rdx
    6edf:	0f 85 70 ff ff ff    	jne    6e55 <fwp_hof0.constprop.0+0xe85>
    6ee5:	48 8d 3d 9c 43 00 00 	lea    0x439c(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    6eec:	e8 bf c1 ff ff       	call   30b0 <fwp_trap>
    6ef1:	e8 0a bd ff ff       	call   2c00 <fwp_heap_oom>
    6ef6:	48 8d 3d 47 42 00 00 	lea    0x4247(%rip),%rdi        # b144 <_IO_stdin_used+0x144>
    6efd:	e8 ae c1 ff ff       	call   30b0 <fwp_trap>
    6f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f08:	48 8d 3d 4e 42 00 00 	lea    0x424e(%rip),%rdi        # b15d <_IO_stdin_used+0x15d>
    6f0f:	e8 9c c1 ff ff       	call   30b0 <fwp_trap>
    6f14:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f18:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    6f1c:	f2 0f 59 05 dc 45 00 	mulsd  0x45dc(%rip),%xmm0        # b500 <msg.3+0xc0>
    6f23:	00 
    6f24:	e9 32 f4 ff ff       	jmp    635b <fwp_hof0.constprop.0+0x38b>
    6f29:	e8 12 b5 ff ff       	call   2440 <__stack_chk_fail@plt>
    6f2e:	66 90                	xchg   %ax,%ax

0000000000006f30 <f0>:
    6f30:	41 56                	push   %r14
    6f32:	4c 8d 35 e7 67 01 00 	lea    0x167e7(%rip),%r14        # 1d720 <fwp_heap>
    6f39:	41 55                	push   %r13
    6f3b:	41 54                	push   %r12
    6f3d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    6f43:	55                   	push   %rbp
    6f44:	53                   	push   %rbx
    6f45:	31 db                	xor    %ebx,%ebx
    6f47:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    6f4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f55:	00 00 
    6f57:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    6f5e:	00 
    6f5f:	31 c0                	xor    %eax,%eax
    6f61:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    6f68:	00 
    6f69:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    6f70:	00 00 
    6f72:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6f77:	48 8d 05 f2 de ff ff 	lea    -0x210e(%rip),%rax        # 4e70 <fwp_drop1>
    6f7e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6f83:	48 8b 05 26 84 01 00 	mov    0x18426(%rip),%rax        # 1f3b0 <fwp_cleanups>
    6f8a:	48 89 25 1f 84 01 00 	mov    %rsp,0x1841f(%rip)        # 1f3b0 <fwp_cleanups>
    6f91:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6f95:	48 89 04 24          	mov    %rax,(%rsp)
    6f99:	48 8d 05 f0 bb ff ff 	lea    -0x4410(%rip),%rax        # 2b90 <fwp_range_release>
    6fa0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6fa5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    6faa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6faf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    6fb4:	eb 43                	jmp    6ff9 <f0+0xc9>
    6fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fbd:	00 00 00 
    6fc0:	80 f9 01             	cmp    $0x1,%cl
    6fc3:	75 29                	jne    6fee <f0+0xbe>
    6fc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6fc8:	0f b7 c0             	movzwl %ax,%eax
    6fcb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fce:	48 0f af c1          	imul   %rcx,%rax
    6fd2:	48 c1 e8 20          	shr    $0x20,%rax
    6fd6:	48 39 d0             	cmp    %rdx,%rax
    6fd9:	73 13                	jae    6fee <f0+0xbe>
    6fdb:	49 01 c5             	add    %rax,%r13
    6fde:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    6fe3:	0f 84 2f 25 00 00    	je     9518 <f0+0x25e8>
    6fe9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    6fee:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    6ff3:	49 83 ec 01          	sub    $0x1,%r12
    6ff7:	72 77                	jb     7070 <f0+0x140>
    6ff9:	48 89 ef             	mov    %rbp,%rdi
    6ffc:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    7003:	00 
    7004:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7009:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    7010:	00 
    7011:	e8 0a d7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7016:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    701d:	48 89 c3             	mov    %rax,%rbx
    7020:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    7027:	48 c1 e2 10          	shl    $0x10,%rdx
    702b:	48 39 d0             	cmp    %rdx,%rax
    702e:	73 be                	jae    6fee <f0+0xbe>
    7030:	48 89 c2             	mov    %rax,%rdx
    7033:	48 c1 ea 10          	shr    $0x10,%rdx
    7037:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    703b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    7042:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7046:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    704a:	4d 85 ed             	test   %r13,%r13
    704d:	74 9f                	je     6fee <f0+0xbe>
    704f:	0f b6 0a             	movzbl (%rdx),%ecx
    7052:	80 f9 02             	cmp    $0x2,%cl
    7055:	0f 85 65 ff ff ff    	jne    6fc0 <f0+0x90>
    705b:	66 85 c0             	test   %ax,%ax
    705e:	0f 84 7a ff ff ff    	je     6fde <f0+0xae>
    7064:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7069:	49 83 ec 01          	sub    $0x1,%r12
    706d:	73 8a                	jae    6ff9 <f0+0xc9>
    706f:	90                   	nop
    7070:	48 8b 04 24          	mov    (%rsp),%rax
    7074:	66 0f 6f 05 54 44 00 	movdqa 0x4454(%rip),%xmm0        # b4d0 <msg.3+0x90>
    707b:	00 
    707c:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
    7081:	48 89 05 28 83 01 00 	mov    %rax,0x18328(%rip)        # 1f3b0 <fwp_cleanups>
    7088:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    708d:	e8 8e d6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7092:	48 8b 15 5f 7a 01 00 	mov    0x17a5f(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    7099:	49 89 c5             	mov    %rax,%r13
    709c:	48 2b 05 2d 7a 01 00 	sub    0x17a2d(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    70a3:	48 c1 e2 10          	shl    $0x10,%rdx
    70a7:	48 39 d0             	cmp    %rdx,%rax
    70aa:	73 59                	jae    7105 <f0+0x1d5>
    70ac:	48 89 c2             	mov    %rax,%rdx
    70af:	48 c1 ea 10          	shr    $0x10,%rdx
    70b3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70b7:	48 8b 15 5a 7a 01 00 	mov    0x17a5a(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    70be:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    70c2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    70c6:	4d 85 e4             	test   %r12,%r12
    70c9:	74 3a                	je     7105 <f0+0x1d5>
    70cb:	0f b6 0a             	movzbl (%rdx),%ecx
    70ce:	80 f9 02             	cmp    $0x2,%cl
    70d1:	0f 84 f9 24 00 00    	je     95d0 <f0+0x26a0>
    70d7:	80 f9 01             	cmp    $0x1,%cl
    70da:	75 29                	jne    7105 <f0+0x1d5>
    70dc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    70df:	0f b7 c0             	movzwl %ax,%eax
    70e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    70e5:	48 0f af c1          	imul   %rcx,%rax
    70e9:	48 c1 e8 20          	shr    $0x20,%rax
    70ed:	48 39 d0             	cmp    %rdx,%rax
    70f0:	73 13                	jae    7105 <f0+0x1d5>
    70f2:	49 01 c4             	add    %rax,%r12
    70f5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    70fa:	0f 84 ab 26 00 00    	je     97ab <f0+0x287b>
    7100:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7105:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    710c:	00 f0 3f 
    710f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
    7114:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    7119:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    711e:	e8 fd d5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7123:	48 8b 15 ce 79 01 00 	mov    0x179ce(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    712a:	49 89 c5             	mov    %rax,%r13
    712d:	48 2b 05 9c 79 01 00 	sub    0x1799c(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    7134:	48 c1 e2 10          	shl    $0x10,%rdx
    7138:	48 39 d0             	cmp    %rdx,%rax
    713b:	73 59                	jae    7196 <f0+0x266>
    713d:	48 89 c2             	mov    %rax,%rdx
    7140:	48 c1 ea 10          	shr    $0x10,%rdx
    7144:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7148:	48 8b 15 c9 79 01 00 	mov    0x179c9(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    714f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7153:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7157:	4d 85 e4             	test   %r12,%r12
    715a:	74 3a                	je     7196 <f0+0x266>
    715c:	0f b6 0a             	movzbl (%rdx),%ecx
    715f:	80 f9 02             	cmp    $0x2,%cl
    7162:	0f 84 58 24 00 00    	je     95c0 <f0+0x2690>
    7168:	80 f9 01             	cmp    $0x1,%cl
    716b:	75 29                	jne    7196 <f0+0x266>
    716d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7170:	0f b7 c0             	movzwl %ax,%eax
    7173:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7176:	48 0f af c1          	imul   %rcx,%rax
    717a:	48 c1 e8 20          	shr    $0x20,%rax
    717e:	48 39 d0             	cmp    %rdx,%rax
    7181:	73 13                	jae    7196 <f0+0x266>
    7183:	49 01 c4             	add    %rax,%r12
    7186:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    718b:	0f 84 27 26 00 00    	je     97b8 <f0+0x2888>
    7191:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7196:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    719d:	33 f3 bf 
    71a0:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
    71a5:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    71aa:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    71af:	e8 6c d5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    71b4:	48 8b 15 3d 79 01 00 	mov    0x1793d(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    71bb:	49 89 c5             	mov    %rax,%r13
    71be:	48 2b 05 0b 79 01 00 	sub    0x1790b(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    71c5:	48 c1 e2 10          	shl    $0x10,%rdx
    71c9:	48 39 d0             	cmp    %rdx,%rax
    71cc:	73 59                	jae    7227 <f0+0x2f7>
    71ce:	48 89 c2             	mov    %rax,%rdx
    71d1:	48 c1 ea 10          	shr    $0x10,%rdx
    71d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71d9:	48 8b 15 38 79 01 00 	mov    0x17938(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    71e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    71e4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    71e8:	4d 85 e4             	test   %r12,%r12
    71eb:	74 3a                	je     7227 <f0+0x2f7>
    71ed:	0f b6 0a             	movzbl (%rdx),%ecx
    71f0:	80 f9 02             	cmp    $0x2,%cl
    71f3:	0f 84 b7 23 00 00    	je     95b0 <f0+0x2680>
    71f9:	80 f9 01             	cmp    $0x1,%cl
    71fc:	75 29                	jne    7227 <f0+0x2f7>
    71fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7201:	0f b7 c0             	movzwl %ax,%eax
    7204:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7207:	48 0f af c1          	imul   %rcx,%rax
    720b:	48 c1 e8 20          	shr    $0x20,%rax
    720f:	48 39 d0             	cmp    %rdx,%rax
    7212:	73 13                	jae    7227 <f0+0x2f7>
    7214:	49 01 c4             	add    %rax,%r12
    7217:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    721c:	0f 84 a3 25 00 00    	je     97c5 <f0+0x2895>
    7222:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7227:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    722e:	00 f0 3f 
    7231:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
    7236:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    723b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7240:	e8 db d4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7245:	48 8b 15 ac 78 01 00 	mov    0x178ac(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    724c:	49 89 c5             	mov    %rax,%r13
    724f:	48 2b 05 7a 78 01 00 	sub    0x1787a(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    7256:	48 c1 e2 10          	shl    $0x10,%rdx
    725a:	48 39 d0             	cmp    %rdx,%rax
    725d:	73 59                	jae    72b8 <f0+0x388>
    725f:	48 89 c2             	mov    %rax,%rdx
    7262:	48 c1 ea 10          	shr    $0x10,%rdx
    7266:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    726a:	48 8b 15 a7 78 01 00 	mov    0x178a7(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    7271:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7275:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7279:	4d 85 e4             	test   %r12,%r12
    727c:	74 3a                	je     72b8 <f0+0x388>
    727e:	0f b6 0a             	movzbl (%rdx),%ecx
    7281:	80 f9 02             	cmp    $0x2,%cl
    7284:	0f 84 86 23 00 00    	je     9610 <f0+0x26e0>
    728a:	80 f9 01             	cmp    $0x1,%cl
    728d:	75 29                	jne    72b8 <f0+0x388>
    728f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7292:	0f b7 c0             	movzwl %ax,%eax
    7295:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7298:	48 0f af c1          	imul   %rcx,%rax
    729c:	48 c1 e8 20          	shr    $0x20,%rax
    72a0:	48 39 d0             	cmp    %rdx,%rax
    72a3:	73 13                	jae    72b8 <f0+0x388>
    72a5:	49 01 c4             	add    %rax,%r12
    72a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    72ad:	0f 84 1f 25 00 00    	je     97d2 <f0+0x28a2>
    72b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    72b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    72bf:	00 
    72c0:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    72c7:	00 
    72c8:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    72cf:	33 f3 bf 
    72d2:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    72d9:	00 f0 3f 
    72dc:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    72e3:	00 
    72e4:	e8 37 d4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    72e9:	48 89 c7             	mov    %rax,%rdi
    72ec:	e8 df d1 ff ff       	call   44d0 <fwp_rc_fresh>
    72f1:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
    72f8:	00 
    72f9:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    7300:	00 
    7301:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    7308:	00 
    7309:	e8 12 d4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    730e:	48 89 c7             	mov    %rax,%rdi
    7311:	e8 ba d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7316:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
    731d:	00 
    731e:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    7325:	00 
    7326:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    732d:	00 
    732e:	e8 ed d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7333:	48 89 c7             	mov    %rax,%rdi
    7336:	e8 95 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    733b:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
    7342:	00 
    7343:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    734a:	00 
    734b:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7352:	00 
    7353:	e8 c8 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7358:	48 89 c7             	mov    %rax,%rdi
    735b:	e8 70 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7360:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
    7367:	00 
    7368:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    736f:	00 
    7370:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7377:	00 
    7378:	e8 a3 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    737d:	48 89 c7             	mov    %rax,%rdi
    7380:	e8 4b d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7385:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
    738c:	00 
    738d:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    7394:	00 
    7395:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    739c:	00 
    739d:	e8 7e d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73a2:	48 89 c7             	mov    %rax,%rdi
    73a5:	e8 26 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    73aa:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
    73b1:	00 
    73b2:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    73b9:	00 
    73ba:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    73c1:	00 
    73c2:	e8 59 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73c7:	48 89 c7             	mov    %rax,%rdi
    73ca:	e8 01 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    73cf:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
    73d6:	00 
    73d7:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    73de:	00 
    73df:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    73e6:	00 
    73e7:	e8 34 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73ec:	48 89 c7             	mov    %rax,%rdi
    73ef:	e8 dc d0 ff ff       	call   44d0 <fwp_rc_fresh>
    73f4:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
    73fb:	00 
    73fc:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    7403:	00 
    7404:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    740b:	00 
    740c:	e8 0f d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7411:	48 89 c7             	mov    %rax,%rdi
    7414:	e8 b7 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7419:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
    7420:	00 
    7421:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7428:	00 
    7429:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7430:	00 
    7431:	e8 ea d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7436:	48 89 c7             	mov    %rax,%rdi
    7439:	e8 92 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    743e:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
    7445:	00 
    7446:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    744d:	00 
    744e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7455:	00 
    7456:	e8 c5 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    745b:	48 89 c7             	mov    %rax,%rdi
    745e:	e8 6d d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7463:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
    746a:	00 
    746b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    7472:	00 
    7473:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    747a:	00 
    747b:	e8 a0 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7480:	48 89 c7             	mov    %rax,%rdi
    7483:	e8 48 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7488:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
    748f:	00 
    7490:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    7497:	00 
    7498:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    749f:	00 
    74a0:	e8 7b d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74a5:	48 89 c7             	mov    %rax,%rdi
    74a8:	e8 23 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    74ad:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
    74b4:	00 
    74b5:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    74bc:	00 
    74bd:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    74c4:	00 
    74c5:	e8 56 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74ca:	48 89 c7             	mov    %rax,%rdi
    74cd:	e8 fe cf ff ff       	call   44d0 <fwp_rc_fresh>
    74d2:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
    74d9:	00 
    74da:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    74e1:	00 
    74e2:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    74e9:	00 
    74ea:	e8 31 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74ef:	48 89 c7             	mov    %rax,%rdi
    74f2:	e8 d9 cf ff ff       	call   44d0 <fwp_rc_fresh>
    74f7:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
    74fe:	00 
    74ff:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    7506:	00 
    7507:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    750e:	00 
    750f:	e8 0c d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7514:	48 89 c7             	mov    %rax,%rdi
    7517:	e8 b4 cf ff ff       	call   44d0 <fwp_rc_fresh>
    751c:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
    7523:	00 
    7524:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    752b:	00 
    752c:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7533:	00 
    7534:	e8 e7 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7539:	48 89 c7             	mov    %rax,%rdi
    753c:	e8 8f cf ff ff       	call   44d0 <fwp_rc_fresh>
    7541:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
    7548:	00 
    7549:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7550:	00 
    7551:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7558:	00 
    7559:	e8 c2 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    755e:	48 89 c7             	mov    %rax,%rdi
    7561:	e8 6a cf ff ff       	call   44d0 <fwp_rc_fresh>
    7566:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
    756d:	00 
    756e:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    7575:	00 
    7576:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    757d:	00 
    757e:	e8 9d d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7583:	48 89 c7             	mov    %rax,%rdi
    7586:	e8 45 cf ff ff       	call   44d0 <fwp_rc_fresh>
    758b:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
    7592:	00 
    7593:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    759a:	00 
    759b:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    75a2:	00 
    75a3:	e8 78 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75a8:	48 89 c7             	mov    %rax,%rdi
    75ab:	e8 20 cf ff ff       	call   44d0 <fwp_rc_fresh>
    75b0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
    75b7:	00 
    75b8:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    75bf:	00 
    75c0:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    75c7:	00 
    75c8:	e8 53 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75cd:	48 89 c7             	mov    %rax,%rdi
    75d0:	e8 fb ce ff ff       	call   44d0 <fwp_rc_fresh>
    75d5:	48 8d bc 24 d0 01 00 	lea    0x1d0(%rsp),%rdi
    75dc:	00 
    75dd:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    75e4:	00 
    75e5:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    75ec:	00 
    75ed:	e8 2e d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75f2:	48 89 c7             	mov    %rax,%rdi
    75f5:	e8 d6 ce ff ff       	call   44d0 <fwp_rc_fresh>
    75fa:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
    7601:	00 
    7602:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    7609:	00 
    760a:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    7611:	00 
    7612:	e8 09 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7617:	48 89 c7             	mov    %rax,%rdi
    761a:	e8 b1 ce ff ff       	call   44d0 <fwp_rc_fresh>
    761f:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
    7626:	00 
    7627:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    762e:	00 
    762f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    7636:	00 
    7637:	e8 e4 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    763c:	48 89 c7             	mov    %rax,%rdi
    763f:	e8 8c ce ff ff       	call   44d0 <fwp_rc_fresh>
    7644:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
    764b:	00 
    764c:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    7653:	00 
    7654:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    765b:	00 
    765c:	e8 bf d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7661:	48 89 c7             	mov    %rax,%rdi
    7664:	e8 67 ce ff ff       	call   44d0 <fwp_rc_fresh>
    7669:	48 8d bc 24 10 02 00 	lea    0x210(%rsp),%rdi
    7670:	00 
    7671:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    7678:	00 
    7679:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    7680:	00 
    7681:	e8 9a d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7686:	48 89 c7             	mov    %rax,%rdi
    7689:	e8 42 ce ff ff       	call   44d0 <fwp_rc_fresh>
    768e:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
    7695:	00 
    7696:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    769d:	00 
    769e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    76a5:	00 
    76a6:	e8 75 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76ab:	48 89 c7             	mov    %rax,%rdi
    76ae:	e8 1d ce ff ff       	call   44d0 <fwp_rc_fresh>
    76b3:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
    76ba:	00 
    76bb:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    76c2:	00 
    76c3:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    76ca:	00 
    76cb:	e8 50 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76d0:	48 89 c7             	mov    %rax,%rdi
    76d3:	e8 f8 cd ff ff       	call   44d0 <fwp_rc_fresh>
    76d8:	48 8d bc 24 40 02 00 	lea    0x240(%rsp),%rdi
    76df:	00 
    76e0:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    76e7:	00 
    76e8:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    76ef:	00 
    76f0:	e8 2b d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76f5:	48 89 c7             	mov    %rax,%rdi
    76f8:	e8 d3 cd ff ff       	call   44d0 <fwp_rc_fresh>
    76fd:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
    7704:	00 
    7705:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    770c:	00 
    770d:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    7714:	00 
    7715:	e8 06 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    771a:	48 89 c7             	mov    %rax,%rdi
    771d:	e8 ae cd ff ff       	call   44d0 <fwp_rc_fresh>
    7722:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
    7729:	00 
    772a:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    7731:	00 
    7732:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    7739:	00 
    773a:	e8 e1 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    773f:	48 89 c7             	mov    %rax,%rdi
    7742:	e8 89 cd ff ff       	call   44d0 <fwp_rc_fresh>
    7747:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
    774e:	00 
    774f:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    7756:	00 
    7757:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    775e:	00 
    775f:	e8 bc cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7764:	48 89 c7             	mov    %rax,%rdi
    7767:	e8 64 cd ff ff       	call   44d0 <fwp_rc_fresh>
    776c:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
    7773:	00 
    7774:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    777b:	00 
    777c:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    7783:	00 
    7784:	e8 97 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7789:	48 89 c7             	mov    %rax,%rdi
    778c:	e8 3f cd ff ff       	call   44d0 <fwp_rc_fresh>
    7791:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
    7798:	00 
    7799:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    77a0:	00 
    77a1:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    77a8:	00 
    77a9:	e8 72 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77ae:	48 89 c7             	mov    %rax,%rdi
    77b1:	e8 1a cd ff ff       	call   44d0 <fwp_rc_fresh>
    77b6:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
    77bd:	00 
    77be:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    77c5:	00 
    77c6:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    77cd:	00 
    77ce:	e8 4d cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77d3:	48 89 c7             	mov    %rax,%rdi
    77d6:	e8 f5 cc ff ff       	call   44d0 <fwp_rc_fresh>
    77db:	48 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%rdi
    77e2:	00 
    77e3:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    77ea:	00 
    77eb:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    77f2:	00 
    77f3:	e8 28 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77f8:	48 89 c7             	mov    %rax,%rdi
    77fb:	e8 d0 cc ff ff       	call   44d0 <fwp_rc_fresh>
    7800:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
    7807:	00 
    7808:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    780f:	00 
    7810:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    7817:	00 
    7818:	e8 03 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    781d:	48 89 c7             	mov    %rax,%rdi
    7820:	e8 ab cc ff ff       	call   44d0 <fwp_rc_fresh>
    7825:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
    782c:	00 
    782d:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    7834:	00 
    7835:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    783c:	00 
    783d:	e8 de ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7842:	48 89 c7             	mov    %rax,%rdi
    7845:	e8 86 cc ff ff       	call   44d0 <fwp_rc_fresh>
    784a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
    7851:	00 
    7852:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    7859:	00 
    785a:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    7861:	00 
    7862:	e8 b9 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7867:	48 89 c7             	mov    %rax,%rdi
    786a:	e8 61 cc ff ff       	call   44d0 <fwp_rc_fresh>
    786f:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
    7876:	00 
    7877:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    787e:	00 
    787f:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    7886:	00 
    7887:	e8 94 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    788c:	48 89 c7             	mov    %rax,%rdi
    788f:	e8 3c cc ff ff       	call   44d0 <fwp_rc_fresh>
    7894:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
    789b:	00 
    789c:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    78a3:	00 
    78a4:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    78ab:	00 
    78ac:	e8 6f ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    78b1:	48 89 c7             	mov    %rax,%rdi
    78b4:	e8 17 cc ff ff       	call   44d0 <fwp_rc_fresh>
    78b9:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
    78c0:	00 
    78c1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    78c8:	00 
    78c9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    78d0:	00 
    78d1:	e8 4a ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    78d6:	48 89 c7             	mov    %rax,%rdi
    78d9:	e8 f2 cb ff ff       	call   44d0 <fwp_rc_fresh>
    78de:	48 8d bc 24 20 03 00 	lea    0x320(%rsp),%rdi
    78e5:	00 
    78e6:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    78ed:	00 
    78ee:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    78f5:	00 
    78f6:	e8 25 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    78fb:	48 89 c7             	mov    %rax,%rdi
    78fe:	e8 cd cb ff ff       	call   44d0 <fwp_rc_fresh>
    7903:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
    790a:	00 
    790b:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    7912:	00 
    7913:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    791a:	00 
    791b:	e8 00 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7920:	48 89 c7             	mov    %rax,%rdi
    7923:	e8 a8 cb ff ff       	call   44d0 <fwp_rc_fresh>
    7928:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
    792f:	00 
    7930:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    7937:	00 
    7938:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    793f:	00 
    7940:	e8 db cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7945:	48 89 c7             	mov    %rax,%rdi
    7948:	e8 83 cb ff ff       	call   44d0 <fwp_rc_fresh>
    794d:	48 8d bc 24 50 03 00 	lea    0x350(%rsp),%rdi
    7954:	00 
    7955:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    795c:	00 
    795d:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    7964:	00 
    7965:	e8 b6 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    796a:	48 89 c7             	mov    %rax,%rdi
    796d:	e8 5e cb ff ff       	call   44d0 <fwp_rc_fresh>
    7972:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
    7979:	00 
    797a:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    7981:	00 
    7982:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    7989:	00 
    798a:	e8 91 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    798f:	48 89 c7             	mov    %rax,%rdi
    7992:	e8 39 cb ff ff       	call   44d0 <fwp_rc_fresh>
    7997:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
    799e:	00 
    799f:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    79a6:	00 
    79a7:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    79ae:	00 
    79af:	e8 6c cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79b4:	48 89 c7             	mov    %rax,%rdi
    79b7:	e8 14 cb ff ff       	call   44d0 <fwp_rc_fresh>
    79bc:	48 8d bc 24 80 03 00 	lea    0x380(%rsp),%rdi
    79c3:	00 
    79c4:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    79cb:	00 
    79cc:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    79d3:	00 
    79d4:	e8 47 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79d9:	48 89 c7             	mov    %rax,%rdi
    79dc:	e8 ef ca ff ff       	call   44d0 <fwp_rc_fresh>
    79e1:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
    79e8:	00 
    79e9:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    79f0:	00 
    79f1:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    79f8:	00 
    79f9:	e8 22 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79fe:	48 89 c7             	mov    %rax,%rdi
    7a01:	e8 ca ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a06:	48 8d bc 24 a0 03 00 	lea    0x3a0(%rsp),%rdi
    7a0d:	00 
    7a0e:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    7a15:	00 
    7a16:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    7a1d:	00 
    7a1e:	e8 fd cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a23:	48 89 c7             	mov    %rax,%rdi
    7a26:	e8 a5 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a2b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
    7a32:	00 
    7a33:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    7a3a:	00 
    7a3b:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    7a42:	00 
    7a43:	e8 d8 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a48:	48 89 c7             	mov    %rax,%rdi
    7a4b:	e8 80 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a50:	48 8d bc 24 c0 03 00 	lea    0x3c0(%rsp),%rdi
    7a57:	00 
    7a58:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    7a5f:	00 
    7a60:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    7a67:	00 
    7a68:	e8 b3 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a6d:	48 89 c7             	mov    %rax,%rdi
    7a70:	e8 5b ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a75:	48 8d bc 24 d0 03 00 	lea    0x3d0(%rsp),%rdi
    7a7c:	00 
    7a7d:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    7a84:	00 
    7a85:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    7a8c:	00 
    7a8d:	e8 8e cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a92:	48 89 c7             	mov    %rax,%rdi
    7a95:	e8 36 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a9a:	48 8d bc 24 e0 03 00 	lea    0x3e0(%rsp),%rdi
    7aa1:	00 
    7aa2:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    7aa9:	00 
    7aaa:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    7ab1:	00 
    7ab2:	e8 69 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ab7:	48 89 c7             	mov    %rax,%rdi
    7aba:	e8 11 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7abf:	48 8d bc 24 f0 03 00 	lea    0x3f0(%rsp),%rdi
    7ac6:	00 
    7ac7:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    7ace:	00 
    7acf:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    7ad6:	00 
    7ad7:	e8 44 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7adc:	48 89 c7             	mov    %rax,%rdi
    7adf:	e8 ec c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7ae4:	48 8d bc 24 00 04 00 	lea    0x400(%rsp),%rdi
    7aeb:	00 
    7aec:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    7af3:	00 
    7af4:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    7afb:	00 
    7afc:	e8 1f cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b01:	48 89 c7             	mov    %rax,%rdi
    7b04:	e8 c7 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b09:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
    7b10:	00 
    7b11:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    7b18:	00 
    7b19:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    7b20:	00 
    7b21:	e8 fa cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b26:	48 89 c7             	mov    %rax,%rdi
    7b29:	e8 a2 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b2e:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
    7b35:	00 
    7b36:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    7b3d:	00 
    7b3e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    7b45:	00 
    7b46:	e8 d5 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b4b:	48 89 c7             	mov    %rax,%rdi
    7b4e:	e8 7d c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b53:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
    7b5a:	00 
    7b5b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    7b62:	00 
    7b63:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    7b6a:	00 
    7b6b:	e8 b0 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b70:	48 89 c7             	mov    %rax,%rdi
    7b73:	e8 58 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b78:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
    7b7f:	00 
    7b80:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    7b87:	00 
    7b88:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    7b8f:	00 
    7b90:	e8 8b cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b95:	48 89 c7             	mov    %rax,%rdi
    7b98:	e8 33 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b9d:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
    7ba4:	00 
    7ba5:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    7bac:	00 
    7bad:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    7bb4:	00 
    7bb5:	e8 66 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bba:	48 89 c7             	mov    %rax,%rdi
    7bbd:	e8 0e c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7bc2:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
    7bc9:	00 
    7bca:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    7bd1:	00 
    7bd2:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    7bd9:	00 
    7bda:	e8 41 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bdf:	48 89 c7             	mov    %rax,%rdi
    7be2:	e8 e9 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7be7:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
    7bee:	00 
    7bef:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    7bf6:	00 
    7bf7:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    7bfe:	00 
    7bff:	e8 1c cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c04:	48 89 c7             	mov    %rax,%rdi
    7c07:	e8 c4 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c0c:	48 8d bc 24 80 04 00 	lea    0x480(%rsp),%rdi
    7c13:	00 
    7c14:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    7c1b:	00 
    7c1c:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    7c23:	00 
    7c24:	e8 f7 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c29:	48 89 c7             	mov    %rax,%rdi
    7c2c:	e8 9f c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c31:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
    7c38:	00 
    7c39:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    7c40:	00 
    7c41:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    7c48:	00 
    7c49:	e8 d2 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c4e:	48 89 c7             	mov    %rax,%rdi
    7c51:	e8 7a c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c56:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
    7c5d:	00 
    7c5e:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    7c65:	00 
    7c66:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    7c6d:	00 
    7c6e:	e8 ad ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c73:	48 89 c7             	mov    %rax,%rdi
    7c76:	e8 55 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c7b:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
    7c82:	00 
    7c83:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    7c8a:	00 
    7c8b:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    7c92:	00 
    7c93:	e8 88 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c98:	48 89 c7             	mov    %rax,%rdi
    7c9b:	e8 30 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7ca0:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
    7ca7:	00 
    7ca8:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    7caf:	00 
    7cb0:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    7cb7:	00 
    7cb8:	e8 63 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7cbd:	48 89 c7             	mov    %rax,%rdi
    7cc0:	e8 0b c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7cc5:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
    7ccc:	00 
    7ccd:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    7cd4:	00 
    7cd5:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    7cdc:	00 
    7cdd:	e8 3e ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ce2:	48 89 c7             	mov    %rax,%rdi
    7ce5:	e8 e6 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7cea:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
    7cf1:	00 
    7cf2:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    7cf9:	00 
    7cfa:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    7d01:	00 
    7d02:	e8 19 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d07:	48 89 c7             	mov    %rax,%rdi
    7d0a:	e8 c1 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d0f:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
    7d16:	00 
    7d17:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    7d1e:	00 
    7d1f:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    7d26:	00 
    7d27:	e8 f4 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d2c:	48 89 c7             	mov    %rax,%rdi
    7d2f:	e8 9c c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d34:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
    7d3b:	00 
    7d3c:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    7d43:	00 
    7d44:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    7d4b:	00 
    7d4c:	e8 cf c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d51:	48 89 c7             	mov    %rax,%rdi
    7d54:	e8 77 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d59:	48 8d bc 24 10 05 00 	lea    0x510(%rsp),%rdi
    7d60:	00 
    7d61:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    7d68:	00 
    7d69:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    7d70:	00 
    7d71:	e8 aa c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d76:	48 89 c7             	mov    %rax,%rdi
    7d79:	e8 52 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d7e:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
    7d85:	00 
    7d86:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    7d8d:	00 
    7d8e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    7d95:	00 
    7d96:	e8 85 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d9b:	48 89 c7             	mov    %rax,%rdi
    7d9e:	e8 2d c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7da3:	48 8d bc 24 30 05 00 	lea    0x530(%rsp),%rdi
    7daa:	00 
    7dab:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    7db2:	00 
    7db3:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    7dba:	00 
    7dbb:	e8 60 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7dc0:	48 89 c7             	mov    %rax,%rdi
    7dc3:	e8 08 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7dc8:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
    7dcf:	00 
    7dd0:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    7dd7:	00 
    7dd8:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    7ddf:	00 
    7de0:	e8 3b c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7de5:	48 89 c7             	mov    %rax,%rdi
    7de8:	e8 e3 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7ded:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
    7df4:	00 
    7df5:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    7dfc:	00 
    7dfd:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    7e04:	00 
    7e05:	e8 16 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e0a:	48 89 c7             	mov    %rax,%rdi
    7e0d:	e8 be c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e12:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
    7e19:	00 
    7e1a:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    7e21:	00 
    7e22:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    7e29:	00 
    7e2a:	e8 f1 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e2f:	48 89 c7             	mov    %rax,%rdi
    7e32:	e8 99 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e37:	48 8d bc 24 70 05 00 	lea    0x570(%rsp),%rdi
    7e3e:	00 
    7e3f:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    7e46:	00 
    7e47:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    7e4e:	00 
    7e4f:	e8 cc c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e54:	48 89 c7             	mov    %rax,%rdi
    7e57:	e8 74 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e5c:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
    7e63:	00 
    7e64:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    7e6b:	00 
    7e6c:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    7e73:	00 
    7e74:	e8 a7 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e79:	48 89 c7             	mov    %rax,%rdi
    7e7c:	e8 4f c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e81:	48 8d bc 24 90 05 00 	lea    0x590(%rsp),%rdi
    7e88:	00 
    7e89:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    7e90:	00 
    7e91:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    7e98:	00 
    7e99:	e8 82 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e9e:	48 89 c7             	mov    %rax,%rdi
    7ea1:	e8 2a c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7ea6:	48 8d bc 24 a0 05 00 	lea    0x5a0(%rsp),%rdi
    7ead:	00 
    7eae:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    7eb5:	00 
    7eb6:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    7ebd:	00 
    7ebe:	e8 5d c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ec3:	48 89 c7             	mov    %rax,%rdi
    7ec6:	e8 05 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7ecb:	48 8d bc 24 b0 05 00 	lea    0x5b0(%rsp),%rdi
    7ed2:	00 
    7ed3:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    7eda:	00 
    7edb:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    7ee2:	00 
    7ee3:	e8 38 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ee8:	48 89 c7             	mov    %rax,%rdi
    7eeb:	e8 e0 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7ef0:	48 8d bc 24 c0 05 00 	lea    0x5c0(%rsp),%rdi
    7ef7:	00 
    7ef8:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    7eff:	00 
    7f00:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    7f07:	00 
    7f08:	e8 13 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f0d:	48 89 c7             	mov    %rax,%rdi
    7f10:	e8 bb c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f15:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
    7f1c:	00 
    7f1d:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    7f24:	00 
    7f25:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    7f2c:	00 
    7f2d:	e8 ee c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f32:	48 89 c7             	mov    %rax,%rdi
    7f35:	e8 96 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f3a:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
    7f41:	00 
    7f42:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    7f49:	00 
    7f4a:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    7f51:	00 
    7f52:	e8 c9 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f57:	48 89 c7             	mov    %rax,%rdi
    7f5a:	e8 71 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f5f:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
    7f66:	00 
    7f67:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    7f6e:	00 
    7f6f:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    7f76:	00 
    7f77:	e8 a4 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f7c:	48 89 c7             	mov    %rax,%rdi
    7f7f:	e8 4c c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f84:	48 8d bc 24 00 06 00 	lea    0x600(%rsp),%rdi
    7f8b:	00 
    7f8c:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    7f93:	00 
    7f94:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    7f9b:	00 
    7f9c:	e8 7f c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fa1:	48 89 c7             	mov    %rax,%rdi
    7fa4:	e8 27 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7fa9:	48 8d bc 24 10 06 00 	lea    0x610(%rsp),%rdi
    7fb0:	00 
    7fb1:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    7fb8:	00 
    7fb9:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    7fc0:	00 
    7fc1:	e8 5a c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fc6:	48 89 c7             	mov    %rax,%rdi
    7fc9:	e8 02 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7fce:	48 8d bc 24 20 06 00 	lea    0x620(%rsp),%rdi
    7fd5:	00 
    7fd6:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    7fdd:	00 
    7fde:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    7fe5:	00 
    7fe6:	e8 35 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7feb:	48 8b 15 06 6b 01 00 	mov    0x16b06(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    7ff2:	49 89 c5             	mov    %rax,%r13
    7ff5:	48 2b 05 d4 6a 01 00 	sub    0x16ad4(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    7ffc:	48 c1 e2 10          	shl    $0x10,%rdx
    8000:	48 39 d0             	cmp    %rdx,%rax
    8003:	73 59                	jae    805e <f0+0x112e>
    8005:	48 89 c2             	mov    %rax,%rdx
    8008:	48 c1 ea 10          	shr    $0x10,%rdx
    800c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8010:	48 8b 15 01 6b 01 00 	mov    0x16b01(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8017:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    801b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    801f:	4d 85 e4             	test   %r12,%r12
    8022:	74 3a                	je     805e <f0+0x112e>
    8024:	0f b6 0a             	movzbl (%rdx),%ecx
    8027:	80 f9 02             	cmp    $0x2,%cl
    802a:	0f 84 d0 15 00 00    	je     9600 <f0+0x26d0>
    8030:	80 f9 01             	cmp    $0x1,%cl
    8033:	75 29                	jne    805e <f0+0x112e>
    8035:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8038:	0f b7 c0             	movzwl %ax,%eax
    803b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    803e:	48 0f af c1          	imul   %rcx,%rax
    8042:	48 c1 e8 20          	shr    $0x20,%rax
    8046:	48 39 d0             	cmp    %rdx,%rax
    8049:	73 13                	jae    805e <f0+0x112e>
    804b:	49 01 c4             	add    %rax,%r12
    804e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8053:	0f 84 86 17 00 00    	je     97df <f0+0x28af>
    8059:	41 c6 04 24 01       	movb   $0x1,(%r12)
    805e:	48 8d bc 24 30 06 00 	lea    0x630(%rsp),%rdi
    8065:	00 
    8066:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    806d:	00 
    806e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8075:	00 f0 3f 
    8078:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    807f:	00 
    8080:	e8 9b c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8085:	48 8b 15 6c 6a 01 00 	mov    0x16a6c(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    808c:	49 89 c5             	mov    %rax,%r13
    808f:	48 2b 05 3a 6a 01 00 	sub    0x16a3a(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8096:	48 c1 e2 10          	shl    $0x10,%rdx
    809a:	48 39 d0             	cmp    %rdx,%rax
    809d:	73 59                	jae    80f8 <f0+0x11c8>
    809f:	48 89 c2             	mov    %rax,%rdx
    80a2:	48 c1 ea 10          	shr    $0x10,%rdx
    80a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80aa:	48 8b 15 67 6a 01 00 	mov    0x16a67(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    80b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    80b9:	4d 85 e4             	test   %r12,%r12
    80bc:	74 3a                	je     80f8 <f0+0x11c8>
    80be:	0f b6 0a             	movzbl (%rdx),%ecx
    80c1:	80 f9 02             	cmp    $0x2,%cl
    80c4:	0f 84 26 15 00 00    	je     95f0 <f0+0x26c0>
    80ca:	80 f9 01             	cmp    $0x1,%cl
    80cd:	75 29                	jne    80f8 <f0+0x11c8>
    80cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80d2:	0f b7 c0             	movzwl %ax,%eax
    80d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80d8:	48 0f af c1          	imul   %rcx,%rax
    80dc:	48 c1 e8 20          	shr    $0x20,%rax
    80e0:	48 39 d0             	cmp    %rdx,%rax
    80e3:	73 13                	jae    80f8 <f0+0x11c8>
    80e5:	49 01 c4             	add    %rax,%r12
    80e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    80ed:	0f 84 f9 16 00 00    	je     97ec <f0+0x28bc>
    80f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    80f8:	48 8d bc 24 40 06 00 	lea    0x640(%rsp),%rdi
    80ff:	00 
    8100:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    8107:	00 
    8108:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    810f:	33 f3 bf 
    8112:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    8119:	00 
    811a:	e8 01 c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    811f:	48 8b 15 d2 69 01 00 	mov    0x169d2(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8126:	49 89 c5             	mov    %rax,%r13
    8129:	48 2b 05 a0 69 01 00 	sub    0x169a0(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8130:	48 c1 e2 10          	shl    $0x10,%rdx
    8134:	48 39 d0             	cmp    %rdx,%rax
    8137:	73 59                	jae    8192 <f0+0x1262>
    8139:	48 89 c2             	mov    %rax,%rdx
    813c:	48 c1 ea 10          	shr    $0x10,%rdx
    8140:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8144:	48 8b 15 cd 69 01 00 	mov    0x169cd(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    814b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    814f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8153:	4d 85 e4             	test   %r12,%r12
    8156:	74 3a                	je     8192 <f0+0x1262>
    8158:	0f b6 0a             	movzbl (%rdx),%ecx
    815b:	80 f9 02             	cmp    $0x2,%cl
    815e:	0f 84 7c 14 00 00    	je     95e0 <f0+0x26b0>
    8164:	80 f9 01             	cmp    $0x1,%cl
    8167:	75 29                	jne    8192 <f0+0x1262>
    8169:	8b 4a 18             	mov    0x18(%rdx),%ecx
    816c:	0f b7 c0             	movzwl %ax,%eax
    816f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8172:	48 0f af c1          	imul   %rcx,%rax
    8176:	48 c1 e8 20          	shr    $0x20,%rax
    817a:	48 39 d0             	cmp    %rdx,%rax
    817d:	73 13                	jae    8192 <f0+0x1262>
    817f:	49 01 c4             	add    %rax,%r12
    8182:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8187:	0f 84 6c 16 00 00    	je     97f9 <f0+0x28c9>
    818d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8192:	48 8d bc 24 50 06 00 	lea    0x650(%rsp),%rdi
    8199:	00 
    819a:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    81a1:	00 
    81a2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    81a9:	00 f0 3f 
    81ac:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    81b3:	00 
    81b4:	e8 67 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    81b9:	48 8b 15 38 69 01 00 	mov    0x16938(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    81c0:	49 89 c5             	mov    %rax,%r13
    81c3:	48 2b 05 06 69 01 00 	sub    0x16906(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    81ca:	48 c1 e2 10          	shl    $0x10,%rdx
    81ce:	48 39 d0             	cmp    %rdx,%rax
    81d1:	73 59                	jae    822c <f0+0x12fc>
    81d3:	48 89 c2             	mov    %rax,%rdx
    81d6:	48 c1 ea 10          	shr    $0x10,%rdx
    81da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81de:	48 8b 15 33 69 01 00 	mov    0x16933(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    81e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81e9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    81ed:	4d 85 e4             	test   %r12,%r12
    81f0:	74 3a                	je     822c <f0+0x12fc>
    81f2:	0f b6 0a             	movzbl (%rdx),%ecx
    81f5:	80 f9 02             	cmp    $0x2,%cl
    81f8:	0f 84 92 14 00 00    	je     9690 <f0+0x2760>
    81fe:	80 f9 01             	cmp    $0x1,%cl
    8201:	75 29                	jne    822c <f0+0x12fc>
    8203:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8206:	0f b7 c0             	movzwl %ax,%eax
    8209:	8b 52 1c             	mov    0x1c(%rdx),%edx
    820c:	48 0f af c1          	imul   %rcx,%rax
    8210:	48 c1 e8 20          	shr    $0x20,%rax
    8214:	48 39 d0             	cmp    %rdx,%rax
    8217:	73 13                	jae    822c <f0+0x12fc>
    8219:	49 01 c4             	add    %rax,%r12
    821c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8221:	0f 84 df 15 00 00    	je     9806 <f0+0x28d6>
    8227:	41 c6 04 24 01       	movb   $0x1,(%r12)
    822c:	48 8d bc 24 60 06 00 	lea    0x660(%rsp),%rdi
    8233:	00 
    8234:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    823b:	00 
    823c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8243:	33 f3 bf 
    8246:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    824d:	00 
    824e:	e8 cd c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8253:	48 8b 15 9e 68 01 00 	mov    0x1689e(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    825a:	49 89 c5             	mov    %rax,%r13
    825d:	48 2b 05 6c 68 01 00 	sub    0x1686c(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8264:	48 c1 e2 10          	shl    $0x10,%rdx
    8268:	48 39 d0             	cmp    %rdx,%rax
    826b:	73 59                	jae    82c6 <f0+0x1396>
    826d:	48 89 c2             	mov    %rax,%rdx
    8270:	48 c1 ea 10          	shr    $0x10,%rdx
    8274:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8278:	48 8b 15 99 68 01 00 	mov    0x16899(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    827f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8283:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8287:	4d 85 e4             	test   %r12,%r12
    828a:	74 3a                	je     82c6 <f0+0x1396>
    828c:	0f b6 0a             	movzbl (%rdx),%ecx
    828f:	80 f9 02             	cmp    $0x2,%cl
    8292:	0f 84 e8 13 00 00    	je     9680 <f0+0x2750>
    8298:	80 f9 01             	cmp    $0x1,%cl
    829b:	75 29                	jne    82c6 <f0+0x1396>
    829d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82a0:	0f b7 c0             	movzwl %ax,%eax
    82a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82a6:	48 0f af c1          	imul   %rcx,%rax
    82aa:	48 c1 e8 20          	shr    $0x20,%rax
    82ae:	48 39 d0             	cmp    %rdx,%rax
    82b1:	73 13                	jae    82c6 <f0+0x1396>
    82b3:	49 01 c4             	add    %rax,%r12
    82b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    82bb:	0f 84 52 15 00 00    	je     9813 <f0+0x28e3>
    82c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    82c6:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
    82cd:	00 
    82ce:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    82d5:	00 
    82d6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    82dd:	00 f0 3f 
    82e0:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    82e7:	00 
    82e8:	e8 33 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    82ed:	48 8b 15 04 68 01 00 	mov    0x16804(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    82f4:	49 89 c5             	mov    %rax,%r13
    82f7:	48 2b 05 d2 67 01 00 	sub    0x167d2(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    82fe:	48 c1 e2 10          	shl    $0x10,%rdx
    8302:	48 39 d0             	cmp    %rdx,%rax
    8305:	73 59                	jae    8360 <f0+0x1430>
    8307:	48 89 c2             	mov    %rax,%rdx
    830a:	48 c1 ea 10          	shr    $0x10,%rdx
    830e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8312:	48 8b 15 ff 67 01 00 	mov    0x167ff(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8319:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    831d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8321:	4d 85 e4             	test   %r12,%r12
    8324:	74 3a                	je     8360 <f0+0x1430>
    8326:	0f b6 0a             	movzbl (%rdx),%ecx
    8329:	80 f9 02             	cmp    $0x2,%cl
    832c:	0f 84 3e 13 00 00    	je     9670 <f0+0x2740>
    8332:	80 f9 01             	cmp    $0x1,%cl
    8335:	75 29                	jne    8360 <f0+0x1430>
    8337:	8b 4a 18             	mov    0x18(%rdx),%ecx
    833a:	0f b7 c0             	movzwl %ax,%eax
    833d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8340:	48 0f af c1          	imul   %rcx,%rax
    8344:	48 c1 e8 20          	shr    $0x20,%rax
    8348:	48 39 d0             	cmp    %rdx,%rax
    834b:	73 13                	jae    8360 <f0+0x1430>
    834d:	49 01 c4             	add    %rax,%r12
    8350:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8355:	0f 84 c5 14 00 00    	je     9820 <f0+0x28f0>
    835b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8360:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
    8367:	00 
    8368:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    836f:	00 
    8370:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8377:	33 f3 bf 
    837a:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    8381:	00 
    8382:	e8 99 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8387:	48 8b 15 6a 67 01 00 	mov    0x1676a(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    838e:	49 89 c5             	mov    %rax,%r13
    8391:	48 2b 05 38 67 01 00 	sub    0x16738(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8398:	48 c1 e2 10          	shl    $0x10,%rdx
    839c:	48 39 d0             	cmp    %rdx,%rax
    839f:	73 59                	jae    83fa <f0+0x14ca>
    83a1:	48 89 c2             	mov    %rax,%rdx
    83a4:	48 c1 ea 10          	shr    $0x10,%rdx
    83a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ac:	48 8b 15 65 67 01 00 	mov    0x16765(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    83b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    83bb:	4d 85 e4             	test   %r12,%r12
    83be:	74 3a                	je     83fa <f0+0x14ca>
    83c0:	0f b6 0a             	movzbl (%rdx),%ecx
    83c3:	80 f9 02             	cmp    $0x2,%cl
    83c6:	0f 84 94 12 00 00    	je     9660 <f0+0x2730>
    83cc:	80 f9 01             	cmp    $0x1,%cl
    83cf:	75 29                	jne    83fa <f0+0x14ca>
    83d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83d4:	0f b7 c0             	movzwl %ax,%eax
    83d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83da:	48 0f af c1          	imul   %rcx,%rax
    83de:	48 c1 e8 20          	shr    $0x20,%rax
    83e2:	48 39 d0             	cmp    %rdx,%rax
    83e5:	73 13                	jae    83fa <f0+0x14ca>
    83e7:	49 01 c4             	add    %rax,%r12
    83ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    83ef:	0f 84 38 14 00 00    	je     982d <f0+0x28fd>
    83f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    83fa:	48 8d bc 24 90 06 00 	lea    0x690(%rsp),%rdi
    8401:	00 
    8402:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    8409:	00 
    840a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8411:	00 f0 3f 
    8414:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    841b:	00 
    841c:	e8 ff c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8421:	48 8b 15 d0 66 01 00 	mov    0x166d0(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8428:	49 89 c5             	mov    %rax,%r13
    842b:	48 2b 05 9e 66 01 00 	sub    0x1669e(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8432:	48 c1 e2 10          	shl    $0x10,%rdx
    8436:	48 39 d0             	cmp    %rdx,%rax
    8439:	73 59                	jae    8494 <f0+0x1564>
    843b:	48 89 c2             	mov    %rax,%rdx
    843e:	48 c1 ea 10          	shr    $0x10,%rdx
    8442:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8446:	48 8b 15 cb 66 01 00 	mov    0x166cb(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    844d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8451:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8455:	4d 85 e4             	test   %r12,%r12
    8458:	74 3a                	je     8494 <f0+0x1564>
    845a:	0f b6 0a             	movzbl (%rdx),%ecx
    845d:	80 f9 02             	cmp    $0x2,%cl
    8460:	0f 84 ea 11 00 00    	je     9650 <f0+0x2720>
    8466:	80 f9 01             	cmp    $0x1,%cl
    8469:	75 29                	jne    8494 <f0+0x1564>
    846b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    846e:	0f b7 c0             	movzwl %ax,%eax
    8471:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8474:	48 0f af c1          	imul   %rcx,%rax
    8478:	48 c1 e8 20          	shr    $0x20,%rax
    847c:	48 39 d0             	cmp    %rdx,%rax
    847f:	73 13                	jae    8494 <f0+0x1564>
    8481:	49 01 c4             	add    %rax,%r12
    8484:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8489:	0f 84 ab 13 00 00    	je     983a <f0+0x290a>
    848f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8494:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
    849b:	00 
    849c:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    84a3:	00 
    84a4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    84ab:	33 f3 bf 
    84ae:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    84b5:	00 
    84b6:	e8 65 c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    84bb:	48 8b 15 36 66 01 00 	mov    0x16636(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    84c2:	49 89 c5             	mov    %rax,%r13
    84c5:	48 2b 05 04 66 01 00 	sub    0x16604(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    84cc:	48 c1 e2 10          	shl    $0x10,%rdx
    84d0:	48 39 d0             	cmp    %rdx,%rax
    84d3:	73 59                	jae    852e <f0+0x15fe>
    84d5:	48 89 c2             	mov    %rax,%rdx
    84d8:	48 c1 ea 10          	shr    $0x10,%rdx
    84dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84e0:	48 8b 15 31 66 01 00 	mov    0x16631(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    84e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84eb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    84ef:	4d 85 e4             	test   %r12,%r12
    84f2:	74 3a                	je     852e <f0+0x15fe>
    84f4:	0f b6 0a             	movzbl (%rdx),%ecx
    84f7:	80 f9 02             	cmp    $0x2,%cl
    84fa:	0f 84 40 11 00 00    	je     9640 <f0+0x2710>
    8500:	80 f9 01             	cmp    $0x1,%cl
    8503:	75 29                	jne    852e <f0+0x15fe>
    8505:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8508:	0f b7 c0             	movzwl %ax,%eax
    850b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    850e:	48 0f af c1          	imul   %rcx,%rax
    8512:	48 c1 e8 20          	shr    $0x20,%rax
    8516:	48 39 d0             	cmp    %rdx,%rax
    8519:	73 13                	jae    852e <f0+0x15fe>
    851b:	49 01 c4             	add    %rax,%r12
    851e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8523:	0f 84 1e 13 00 00    	je     9847 <f0+0x2917>
    8529:	41 c6 04 24 01       	movb   $0x1,(%r12)
    852e:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
    8535:	00 
    8536:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    853d:	00 
    853e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8545:	00 f0 3f 
    8548:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    854f:	00 
    8550:	e8 cb c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8555:	48 8b 15 9c 65 01 00 	mov    0x1659c(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    855c:	49 89 c5             	mov    %rax,%r13
    855f:	48 2b 05 6a 65 01 00 	sub    0x1656a(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8566:	48 c1 e2 10          	shl    $0x10,%rdx
    856a:	48 39 d0             	cmp    %rdx,%rax
    856d:	73 59                	jae    85c8 <f0+0x1698>
    856f:	48 89 c2             	mov    %rax,%rdx
    8572:	48 c1 ea 10          	shr    $0x10,%rdx
    8576:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    857a:	48 8b 15 97 65 01 00 	mov    0x16597(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8581:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8585:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8589:	4d 85 e4             	test   %r12,%r12
    858c:	74 3a                	je     85c8 <f0+0x1698>
    858e:	0f b6 0a             	movzbl (%rdx),%ecx
    8591:	80 f9 02             	cmp    $0x2,%cl
    8594:	0f 84 96 10 00 00    	je     9630 <f0+0x2700>
    859a:	80 f9 01             	cmp    $0x1,%cl
    859d:	75 29                	jne    85c8 <f0+0x1698>
    859f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85a2:	0f b7 c0             	movzwl %ax,%eax
    85a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85a8:	48 0f af c1          	imul   %rcx,%rax
    85ac:	48 c1 e8 20          	shr    $0x20,%rax
    85b0:	48 39 d0             	cmp    %rdx,%rax
    85b3:	73 13                	jae    85c8 <f0+0x1698>
    85b5:	49 01 c4             	add    %rax,%r12
    85b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    85bd:	0f 84 91 12 00 00    	je     9854 <f0+0x2924>
    85c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    85c8:	48 8d bc 24 c0 06 00 	lea    0x6c0(%rsp),%rdi
    85cf:	00 
    85d0:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    85d7:	00 
    85d8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    85df:	33 f3 bf 
    85e2:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    85e9:	00 
    85ea:	e8 31 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    85ef:	48 8b 15 02 65 01 00 	mov    0x16502(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    85f6:	49 89 c5             	mov    %rax,%r13
    85f9:	48 2b 05 d0 64 01 00 	sub    0x164d0(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8600:	48 c1 e2 10          	shl    $0x10,%rdx
    8604:	48 39 d0             	cmp    %rdx,%rax
    8607:	73 59                	jae    8662 <f0+0x1732>
    8609:	48 89 c2             	mov    %rax,%rdx
    860c:	48 c1 ea 10          	shr    $0x10,%rdx
    8610:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8614:	48 8b 15 fd 64 01 00 	mov    0x164fd(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    861b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    861f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8623:	4d 85 e4             	test   %r12,%r12
    8626:	74 3a                	je     8662 <f0+0x1732>
    8628:	0f b6 0a             	movzbl (%rdx),%ecx
    862b:	80 f9 02             	cmp    $0x2,%cl
    862e:	0f 84 ec 0f 00 00    	je     9620 <f0+0x26f0>
    8634:	80 f9 01             	cmp    $0x1,%cl
    8637:	75 29                	jne    8662 <f0+0x1732>
    8639:	8b 4a 18             	mov    0x18(%rdx),%ecx
    863c:	0f b7 c0             	movzwl %ax,%eax
    863f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8642:	48 0f af c1          	imul   %rcx,%rax
    8646:	48 c1 e8 20          	shr    $0x20,%rax
    864a:	48 39 d0             	cmp    %rdx,%rax
    864d:	73 13                	jae    8662 <f0+0x1732>
    864f:	49 01 c4             	add    %rax,%r12
    8652:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8657:	0f 84 04 12 00 00    	je     9861 <f0+0x2931>
    865d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8662:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
    8669:	00 
    866a:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    8671:	00 
    8672:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8679:	00 f0 3f 
    867c:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    8683:	00 
    8684:	e8 97 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8689:	48 8b 15 68 64 01 00 	mov    0x16468(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8690:	49 89 c5             	mov    %rax,%r13
    8693:	48 2b 05 36 64 01 00 	sub    0x16436(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    869a:	48 c1 e2 10          	shl    $0x10,%rdx
    869e:	48 39 d0             	cmp    %rdx,%rax
    86a1:	73 59                	jae    86fc <f0+0x17cc>
    86a3:	48 89 c2             	mov    %rax,%rdx
    86a6:	48 c1 ea 10          	shr    $0x10,%rdx
    86aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86ae:	48 8b 15 63 64 01 00 	mov    0x16463(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    86b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    86bd:	4d 85 e4             	test   %r12,%r12
    86c0:	74 3a                	je     86fc <f0+0x17cc>
    86c2:	0f b6 0a             	movzbl (%rdx),%ecx
    86c5:	80 f9 02             	cmp    $0x2,%cl
    86c8:	0f 84 d2 0e 00 00    	je     95a0 <f0+0x2670>
    86ce:	80 f9 01             	cmp    $0x1,%cl
    86d1:	75 29                	jne    86fc <f0+0x17cc>
    86d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86d6:	0f b7 c0             	movzwl %ax,%eax
    86d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86dc:	48 0f af c1          	imul   %rcx,%rax
    86e0:	48 c1 e8 20          	shr    $0x20,%rax
    86e4:	48 39 d0             	cmp    %rdx,%rax
    86e7:	73 13                	jae    86fc <f0+0x17cc>
    86e9:	49 01 c4             	add    %rax,%r12
    86ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    86f1:	0f 84 77 11 00 00    	je     986e <f0+0x293e>
    86f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    86fc:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
    8703:	00 
    8704:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    870b:	00 
    870c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8713:	33 f3 bf 
    8716:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    871d:	00 
    871e:	e8 fd bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8723:	48 8b 15 ce 63 01 00 	mov    0x163ce(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    872a:	49 89 c5             	mov    %rax,%r13
    872d:	48 2b 05 9c 63 01 00 	sub    0x1639c(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8734:	48 c1 e2 10          	shl    $0x10,%rdx
    8738:	48 39 d0             	cmp    %rdx,%rax
    873b:	73 59                	jae    8796 <f0+0x1866>
    873d:	48 89 c2             	mov    %rax,%rdx
    8740:	48 c1 ea 10          	shr    $0x10,%rdx
    8744:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8748:	48 8b 15 c9 63 01 00 	mov    0x163c9(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    874f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8753:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8757:	4d 85 e4             	test   %r12,%r12
    875a:	74 3a                	je     8796 <f0+0x1866>
    875c:	0f b6 0a             	movzbl (%rdx),%ecx
    875f:	80 f9 02             	cmp    $0x2,%cl
    8762:	0f 84 28 0e 00 00    	je     9590 <f0+0x2660>
    8768:	80 f9 01             	cmp    $0x1,%cl
    876b:	75 29                	jne    8796 <f0+0x1866>
    876d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8770:	0f b7 c0             	movzwl %ax,%eax
    8773:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8776:	48 0f af c1          	imul   %rcx,%rax
    877a:	48 c1 e8 20          	shr    $0x20,%rax
    877e:	48 39 d0             	cmp    %rdx,%rax
    8781:	73 13                	jae    8796 <f0+0x1866>
    8783:	49 01 c4             	add    %rax,%r12
    8786:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    878b:	0f 84 ea 10 00 00    	je     987b <f0+0x294b>
    8791:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8796:	48 8d bc 24 f0 06 00 	lea    0x6f0(%rsp),%rdi
    879d:	00 
    879e:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    87a5:	00 
    87a6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    87ad:	00 f0 3f 
    87b0:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    87b7:	00 
    87b8:	e8 63 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    87bd:	48 8b 15 34 63 01 00 	mov    0x16334(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    87c4:	49 89 c5             	mov    %rax,%r13
    87c7:	48 2b 05 02 63 01 00 	sub    0x16302(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    87ce:	48 c1 e2 10          	shl    $0x10,%rdx
    87d2:	48 39 d0             	cmp    %rdx,%rax
    87d5:	73 59                	jae    8830 <f0+0x1900>
    87d7:	48 89 c2             	mov    %rax,%rdx
    87da:	48 c1 ea 10          	shr    $0x10,%rdx
    87de:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87e2:	48 8b 15 2f 63 01 00 	mov    0x1632f(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    87e9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87ed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    87f1:	4d 85 e4             	test   %r12,%r12
    87f4:	74 3a                	je     8830 <f0+0x1900>
    87f6:	0f b6 0a             	movzbl (%rdx),%ecx
    87f9:	80 f9 02             	cmp    $0x2,%cl
    87fc:	0f 84 7e 0d 00 00    	je     9580 <f0+0x2650>
    8802:	80 f9 01             	cmp    $0x1,%cl
    8805:	75 29                	jne    8830 <f0+0x1900>
    8807:	8b 4a 18             	mov    0x18(%rdx),%ecx
    880a:	0f b7 c0             	movzwl %ax,%eax
    880d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8810:	48 0f af c1          	imul   %rcx,%rax
    8814:	48 c1 e8 20          	shr    $0x20,%rax
    8818:	48 39 d0             	cmp    %rdx,%rax
    881b:	73 13                	jae    8830 <f0+0x1900>
    881d:	49 01 c4             	add    %rax,%r12
    8820:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8825:	0f 84 5d 10 00 00    	je     9888 <f0+0x2958>
    882b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8830:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
    8837:	00 
    8838:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    883f:	00 
    8840:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8847:	33 f3 bf 
    884a:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    8851:	00 
    8852:	e8 c9 be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8857:	48 8b 15 9a 62 01 00 	mov    0x1629a(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    885e:	49 89 c5             	mov    %rax,%r13
    8861:	48 2b 05 68 62 01 00 	sub    0x16268(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8868:	48 c1 e2 10          	shl    $0x10,%rdx
    886c:	48 39 d0             	cmp    %rdx,%rax
    886f:	73 59                	jae    88ca <f0+0x199a>
    8871:	48 89 c2             	mov    %rax,%rdx
    8874:	48 c1 ea 10          	shr    $0x10,%rdx
    8878:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    887c:	48 8b 15 95 62 01 00 	mov    0x16295(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8883:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8887:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    888b:	4d 85 e4             	test   %r12,%r12
    888e:	74 3a                	je     88ca <f0+0x199a>
    8890:	0f b6 0a             	movzbl (%rdx),%ecx
    8893:	80 f9 02             	cmp    $0x2,%cl
    8896:	0f 84 d4 0c 00 00    	je     9570 <f0+0x2640>
    889c:	80 f9 01             	cmp    $0x1,%cl
    889f:	75 29                	jne    88ca <f0+0x199a>
    88a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88a4:	0f b7 c0             	movzwl %ax,%eax
    88a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88aa:	48 0f af c1          	imul   %rcx,%rax
    88ae:	48 c1 e8 20          	shr    $0x20,%rax
    88b2:	48 39 d0             	cmp    %rdx,%rax
    88b5:	73 13                	jae    88ca <f0+0x199a>
    88b7:	49 01 c4             	add    %rax,%r12
    88ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    88bf:	0f 84 d0 0f 00 00    	je     9895 <f0+0x2965>
    88c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    88ca:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
    88d1:	00 
    88d2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    88d9:	00 
    88da:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    88e1:	00 f0 3f 
    88e4:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    88eb:	00 
    88ec:	e8 2f be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    88f1:	48 8b 15 00 62 01 00 	mov    0x16200(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    88f8:	49 89 c5             	mov    %rax,%r13
    88fb:	48 2b 05 ce 61 01 00 	sub    0x161ce(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8902:	48 c1 e2 10          	shl    $0x10,%rdx
    8906:	48 39 d0             	cmp    %rdx,%rax
    8909:	73 59                	jae    8964 <f0+0x1a34>
    890b:	48 89 c2             	mov    %rax,%rdx
    890e:	48 c1 ea 10          	shr    $0x10,%rdx
    8912:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8916:	48 8b 15 fb 61 01 00 	mov    0x161fb(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    891d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8921:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8925:	4d 85 e4             	test   %r12,%r12
    8928:	74 3a                	je     8964 <f0+0x1a34>
    892a:	0f b6 0a             	movzbl (%rdx),%ecx
    892d:	80 f9 02             	cmp    $0x2,%cl
    8930:	0f 84 2a 0c 00 00    	je     9560 <f0+0x2630>
    8936:	80 f9 01             	cmp    $0x1,%cl
    8939:	75 29                	jne    8964 <f0+0x1a34>
    893b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    893e:	0f b7 c0             	movzwl %ax,%eax
    8941:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8944:	48 0f af c1          	imul   %rcx,%rax
    8948:	48 c1 e8 20          	shr    $0x20,%rax
    894c:	48 39 d0             	cmp    %rdx,%rax
    894f:	73 13                	jae    8964 <f0+0x1a34>
    8951:	49 01 c4             	add    %rax,%r12
    8954:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8959:	0f 84 43 0f 00 00    	je     98a2 <f0+0x2972>
    895f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8964:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
    896b:	00 
    896c:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    8973:	00 
    8974:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    897b:	33 f3 bf 
    897e:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    8985:	00 
    8986:	e8 95 bd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    898b:	48 8b 15 66 61 01 00 	mov    0x16166(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8992:	49 89 c5             	mov    %rax,%r13
    8995:	48 2b 05 34 61 01 00 	sub    0x16134(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    899c:	48 c1 e2 10          	shl    $0x10,%rdx
    89a0:	48 39 d0             	cmp    %rdx,%rax
    89a3:	73 59                	jae    89fe <f0+0x1ace>
    89a5:	48 89 c2             	mov    %rax,%rdx
    89a8:	48 c1 ea 10          	shr    $0x10,%rdx
    89ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89b0:	48 8b 15 61 61 01 00 	mov    0x16161(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    89b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    89bf:	4d 85 e4             	test   %r12,%r12
    89c2:	74 3a                	je     89fe <f0+0x1ace>
    89c4:	0f b6 0a             	movzbl (%rdx),%ecx
    89c7:	80 f9 02             	cmp    $0x2,%cl
    89ca:	0f 84 80 0b 00 00    	je     9550 <f0+0x2620>
    89d0:	80 f9 01             	cmp    $0x1,%cl
    89d3:	75 29                	jne    89fe <f0+0x1ace>
    89d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    89d8:	0f b7 c0             	movzwl %ax,%eax
    89db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89de:	48 0f af c1          	imul   %rcx,%rax
    89e2:	48 c1 e8 20          	shr    $0x20,%rax
    89e6:	48 39 d0             	cmp    %rdx,%rax
    89e9:	73 13                	jae    89fe <f0+0x1ace>
    89eb:	49 01 c4             	add    %rax,%r12
    89ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    89f3:	0f 84 b6 0e 00 00    	je     98af <f0+0x297f>
    89f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    89fe:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
    8a05:	00 
    8a06:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    8a0d:	00 
    8a0e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8a15:	00 f0 3f 
    8a18:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    8a1f:	00 
    8a20:	e8 fb bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8a25:	48 8b 15 cc 60 01 00 	mov    0x160cc(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8a2c:	49 89 c5             	mov    %rax,%r13
    8a2f:	48 2b 05 9a 60 01 00 	sub    0x1609a(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8a36:	48 c1 e2 10          	shl    $0x10,%rdx
    8a3a:	48 39 d0             	cmp    %rdx,%rax
    8a3d:	73 59                	jae    8a98 <f0+0x1b68>
    8a3f:	48 89 c2             	mov    %rax,%rdx
    8a42:	48 c1 ea 10          	shr    $0x10,%rdx
    8a46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a4a:	48 8b 15 c7 60 01 00 	mov    0x160c7(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8a51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8a59:	4d 85 e4             	test   %r12,%r12
    8a5c:	74 3a                	je     8a98 <f0+0x1b68>
    8a5e:	0f b6 0a             	movzbl (%rdx),%ecx
    8a61:	80 f9 02             	cmp    $0x2,%cl
    8a64:	0f 84 d6 0a 00 00    	je     9540 <f0+0x2610>
    8a6a:	80 f9 01             	cmp    $0x1,%cl
    8a6d:	75 29                	jne    8a98 <f0+0x1b68>
    8a6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a72:	0f b7 c0             	movzwl %ax,%eax
    8a75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a78:	48 0f af c1          	imul   %rcx,%rax
    8a7c:	48 c1 e8 20          	shr    $0x20,%rax
    8a80:	48 39 d0             	cmp    %rdx,%rax
    8a83:	73 13                	jae    8a98 <f0+0x1b68>
    8a85:	49 01 c4             	add    %rax,%r12
    8a88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a8d:	0f 84 29 0e 00 00    	je     98bc <f0+0x298c>
    8a93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8a98:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
    8a9f:	00 
    8aa0:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    8aa7:	00 
    8aa8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8aaf:	33 f3 bf 
    8ab2:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    8ab9:	00 
    8aba:	e8 61 bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8abf:	48 8b 15 32 60 01 00 	mov    0x16032(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8ac6:	49 89 c5             	mov    %rax,%r13
    8ac9:	48 2b 05 00 60 01 00 	sub    0x16000(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8ad0:	48 c1 e2 10          	shl    $0x10,%rdx
    8ad4:	48 39 d0             	cmp    %rdx,%rax
    8ad7:	73 59                	jae    8b32 <f0+0x1c02>
    8ad9:	48 89 c2             	mov    %rax,%rdx
    8adc:	48 c1 ea 10          	shr    $0x10,%rdx
    8ae0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ae4:	48 8b 15 2d 60 01 00 	mov    0x1602d(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8aeb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8aef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8af3:	4d 85 e4             	test   %r12,%r12
    8af6:	74 3a                	je     8b32 <f0+0x1c02>
    8af8:	0f b6 0a             	movzbl (%rdx),%ecx
    8afb:	80 f9 02             	cmp    $0x2,%cl
    8afe:	0f 84 24 0a 00 00    	je     9528 <f0+0x25f8>
    8b04:	80 f9 01             	cmp    $0x1,%cl
    8b07:	75 29                	jne    8b32 <f0+0x1c02>
    8b09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b0c:	0f b7 c0             	movzwl %ax,%eax
    8b0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b12:	48 0f af c1          	imul   %rcx,%rax
    8b16:	48 c1 e8 20          	shr    $0x20,%rax
    8b1a:	48 39 d0             	cmp    %rdx,%rax
    8b1d:	73 13                	jae    8b32 <f0+0x1c02>
    8b1f:	49 01 c4             	add    %rax,%r12
    8b22:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b27:	0f 84 9c 0d 00 00    	je     98c9 <f0+0x2999>
    8b2d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8b32:	48 8d bc 24 50 07 00 	lea    0x750(%rsp),%rdi
    8b39:	00 
    8b3a:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    8b41:	00 
    8b42:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8b49:	00 f0 3f 
    8b4c:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    8b53:	00 
    8b54:	e8 c7 bb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8b59:	48 8b 15 98 5f 01 00 	mov    0x15f98(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8b60:	49 89 c5             	mov    %rax,%r13
    8b63:	48 2b 05 66 5f 01 00 	sub    0x15f66(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8b6a:	48 c1 e2 10          	shl    $0x10,%rdx
    8b6e:	48 39 d0             	cmp    %rdx,%rax
    8b71:	73 59                	jae    8bcc <f0+0x1c9c>
    8b73:	48 89 c2             	mov    %rax,%rdx
    8b76:	48 c1 ea 10          	shr    $0x10,%rdx
    8b7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b7e:	48 8b 15 93 5f 01 00 	mov    0x15f93(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8b85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b89:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b8d:	4d 85 e4             	test   %r12,%r12
    8b90:	74 3a                	je     8bcc <f0+0x1c9c>
    8b92:	0f b6 0a             	movzbl (%rdx),%ecx
    8b95:	80 f9 02             	cmp    $0x2,%cl
    8b98:	0f 84 f2 0b 00 00    	je     9790 <f0+0x2860>
    8b9e:	80 f9 01             	cmp    $0x1,%cl
    8ba1:	75 29                	jne    8bcc <f0+0x1c9c>
    8ba3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ba6:	0f b7 c0             	movzwl %ax,%eax
    8ba9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bac:	48 0f af c1          	imul   %rcx,%rax
    8bb0:	48 c1 e8 20          	shr    $0x20,%rax
    8bb4:	48 39 d0             	cmp    %rdx,%rax
    8bb7:	73 13                	jae    8bcc <f0+0x1c9c>
    8bb9:	49 01 c4             	add    %rax,%r12
    8bbc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8bc1:	0f 84 0f 0d 00 00    	je     98d6 <f0+0x29a6>
    8bc7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8bcc:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
    8bd3:	00 
    8bd4:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    8bdb:	00 
    8bdc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8be3:	33 f3 bf 
    8be6:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    8bed:	00 
    8bee:	e8 2d bb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8bf3:	48 8b 15 fe 5e 01 00 	mov    0x15efe(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8bfa:	49 89 c5             	mov    %rax,%r13
    8bfd:	48 2b 05 cc 5e 01 00 	sub    0x15ecc(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8c04:	48 c1 e2 10          	shl    $0x10,%rdx
    8c08:	48 39 d0             	cmp    %rdx,%rax
    8c0b:	73 59                	jae    8c66 <f0+0x1d36>
    8c0d:	48 89 c2             	mov    %rax,%rdx
    8c10:	48 c1 ea 10          	shr    $0x10,%rdx
    8c14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c18:	48 8b 15 f9 5e 01 00 	mov    0x15ef9(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8c1f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c23:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c27:	4d 85 e4             	test   %r12,%r12
    8c2a:	74 3a                	je     8c66 <f0+0x1d36>
    8c2c:	0f b6 0a             	movzbl (%rdx),%ecx
    8c2f:	80 f9 02             	cmp    $0x2,%cl
    8c32:	0f 84 48 0b 00 00    	je     9780 <f0+0x2850>
    8c38:	80 f9 01             	cmp    $0x1,%cl
    8c3b:	75 29                	jne    8c66 <f0+0x1d36>
    8c3d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c40:	0f b7 c0             	movzwl %ax,%eax
    8c43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c46:	48 0f af c1          	imul   %rcx,%rax
    8c4a:	48 c1 e8 20          	shr    $0x20,%rax
    8c4e:	48 39 d0             	cmp    %rdx,%rax
    8c51:	73 13                	jae    8c66 <f0+0x1d36>
    8c53:	49 01 c4             	add    %rax,%r12
    8c56:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c5b:	0f 84 82 0c 00 00    	je     98e3 <f0+0x29b3>
    8c61:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c66:	48 8d bc 24 70 07 00 	lea    0x770(%rsp),%rdi
    8c6d:	00 
    8c6e:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    8c75:	00 
    8c76:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8c7d:	00 f0 3f 
    8c80:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    8c87:	00 
    8c88:	e8 93 ba ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8c8d:	48 8b 15 64 5e 01 00 	mov    0x15e64(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8c94:	49 89 c5             	mov    %rax,%r13
    8c97:	48 2b 05 32 5e 01 00 	sub    0x15e32(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8c9e:	48 c1 e2 10          	shl    $0x10,%rdx
    8ca2:	48 39 d0             	cmp    %rdx,%rax
    8ca5:	73 59                	jae    8d00 <f0+0x1dd0>
    8ca7:	48 89 c2             	mov    %rax,%rdx
    8caa:	48 c1 ea 10          	shr    $0x10,%rdx
    8cae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cb2:	48 8b 15 5f 5e 01 00 	mov    0x15e5f(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8cb9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8cbd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8cc1:	4d 85 e4             	test   %r12,%r12
    8cc4:	74 3a                	je     8d00 <f0+0x1dd0>
    8cc6:	0f b6 0a             	movzbl (%rdx),%ecx
    8cc9:	80 f9 02             	cmp    $0x2,%cl
    8ccc:	0f 84 9e 0a 00 00    	je     9770 <f0+0x2840>
    8cd2:	80 f9 01             	cmp    $0x1,%cl
    8cd5:	75 29                	jne    8d00 <f0+0x1dd0>
    8cd7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8cda:	0f b7 c0             	movzwl %ax,%eax
    8cdd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ce0:	48 0f af c1          	imul   %rcx,%rax
    8ce4:	48 c1 e8 20          	shr    $0x20,%rax
    8ce8:	48 39 d0             	cmp    %rdx,%rax
    8ceb:	73 13                	jae    8d00 <f0+0x1dd0>
    8ced:	49 01 c4             	add    %rax,%r12
    8cf0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8cf5:	0f 84 f5 0b 00 00    	je     98f0 <f0+0x29c0>
    8cfb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d00:	48 8d bc 24 80 07 00 	lea    0x780(%rsp),%rdi
    8d07:	00 
    8d08:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    8d0f:	00 
    8d10:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8d17:	33 f3 bf 
    8d1a:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    8d21:	00 
    8d22:	e8 f9 b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8d27:	48 8b 15 ca 5d 01 00 	mov    0x15dca(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8d2e:	49 89 c5             	mov    %rax,%r13
    8d31:	48 2b 05 98 5d 01 00 	sub    0x15d98(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8d38:	48 c1 e2 10          	shl    $0x10,%rdx
    8d3c:	48 39 d0             	cmp    %rdx,%rax
    8d3f:	73 59                	jae    8d9a <f0+0x1e6a>
    8d41:	48 89 c2             	mov    %rax,%rdx
    8d44:	48 c1 ea 10          	shr    $0x10,%rdx
    8d48:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d4c:	48 8b 15 c5 5d 01 00 	mov    0x15dc5(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8d53:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d57:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d5b:	4d 85 e4             	test   %r12,%r12
    8d5e:	74 3a                	je     8d9a <f0+0x1e6a>
    8d60:	0f b6 0a             	movzbl (%rdx),%ecx
    8d63:	80 f9 02             	cmp    $0x2,%cl
    8d66:	0f 84 f4 09 00 00    	je     9760 <f0+0x2830>
    8d6c:	80 f9 01             	cmp    $0x1,%cl
    8d6f:	75 29                	jne    8d9a <f0+0x1e6a>
    8d71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d74:	0f b7 c0             	movzwl %ax,%eax
    8d77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d7a:	48 0f af c1          	imul   %rcx,%rax
    8d7e:	48 c1 e8 20          	shr    $0x20,%rax
    8d82:	48 39 d0             	cmp    %rdx,%rax
    8d85:	73 13                	jae    8d9a <f0+0x1e6a>
    8d87:	49 01 c4             	add    %rax,%r12
    8d8a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d8f:	0f 84 68 0b 00 00    	je     98fd <f0+0x29cd>
    8d95:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d9a:	48 8d bc 24 90 07 00 	lea    0x790(%rsp),%rdi
    8da1:	00 
    8da2:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    8da9:	00 
    8daa:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8db1:	00 f0 3f 
    8db4:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    8dbb:	00 
    8dbc:	e8 5f b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8dc1:	48 8b 15 30 5d 01 00 	mov    0x15d30(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8dc8:	49 89 c5             	mov    %rax,%r13
    8dcb:	48 2b 05 fe 5c 01 00 	sub    0x15cfe(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8dd2:	48 c1 e2 10          	shl    $0x10,%rdx
    8dd6:	48 39 d0             	cmp    %rdx,%rax
    8dd9:	73 59                	jae    8e34 <f0+0x1f04>
    8ddb:	48 89 c2             	mov    %rax,%rdx
    8dde:	48 c1 ea 10          	shr    $0x10,%rdx
    8de2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8de6:	48 8b 15 2b 5d 01 00 	mov    0x15d2b(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8ded:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8df1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8df5:	4d 85 e4             	test   %r12,%r12
    8df8:	74 3a                	je     8e34 <f0+0x1f04>
    8dfa:	0f b6 0a             	movzbl (%rdx),%ecx
    8dfd:	80 f9 02             	cmp    $0x2,%cl
    8e00:	0f 84 4a 09 00 00    	je     9750 <f0+0x2820>
    8e06:	80 f9 01             	cmp    $0x1,%cl
    8e09:	75 29                	jne    8e34 <f0+0x1f04>
    8e0b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e0e:	0f b7 c0             	movzwl %ax,%eax
    8e11:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e14:	48 0f af c1          	imul   %rcx,%rax
    8e18:	48 c1 e8 20          	shr    $0x20,%rax
    8e1c:	48 39 d0             	cmp    %rdx,%rax
    8e1f:	73 13                	jae    8e34 <f0+0x1f04>
    8e21:	49 01 c4             	add    %rax,%r12
    8e24:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e29:	0f 84 db 0a 00 00    	je     990a <f0+0x29da>
    8e2f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e34:	48 8d bc 24 a0 07 00 	lea    0x7a0(%rsp),%rdi
    8e3b:	00 
    8e3c:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    8e43:	00 
    8e44:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8e4b:	33 f3 bf 
    8e4e:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    8e55:	00 
    8e56:	e8 c5 b8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8e5b:	48 8b 15 96 5c 01 00 	mov    0x15c96(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8e62:	49 89 c5             	mov    %rax,%r13
    8e65:	48 2b 05 64 5c 01 00 	sub    0x15c64(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8e6c:	48 c1 e2 10          	shl    $0x10,%rdx
    8e70:	48 39 d0             	cmp    %rdx,%rax
    8e73:	73 59                	jae    8ece <f0+0x1f9e>
    8e75:	48 89 c2             	mov    %rax,%rdx
    8e78:	48 c1 ea 10          	shr    $0x10,%rdx
    8e7c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e80:	48 8b 15 91 5c 01 00 	mov    0x15c91(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8e87:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e8b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e8f:	4d 85 e4             	test   %r12,%r12
    8e92:	74 3a                	je     8ece <f0+0x1f9e>
    8e94:	0f b6 0a             	movzbl (%rdx),%ecx
    8e97:	80 f9 02             	cmp    $0x2,%cl
    8e9a:	0f 84 a0 08 00 00    	je     9740 <f0+0x2810>
    8ea0:	80 f9 01             	cmp    $0x1,%cl
    8ea3:	75 29                	jne    8ece <f0+0x1f9e>
    8ea5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ea8:	0f b7 c0             	movzwl %ax,%eax
    8eab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8eae:	48 0f af c1          	imul   %rcx,%rax
    8eb2:	48 c1 e8 20          	shr    $0x20,%rax
    8eb6:	48 39 d0             	cmp    %rdx,%rax
    8eb9:	73 13                	jae    8ece <f0+0x1f9e>
    8ebb:	49 01 c4             	add    %rax,%r12
    8ebe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ec3:	0f 84 4e 0a 00 00    	je     9917 <f0+0x29e7>
    8ec9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8ece:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
    8ed5:	00 
    8ed6:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    8edd:	00 
    8ede:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8ee5:	00 f0 3f 
    8ee8:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    8eef:	00 
    8ef0:	e8 2b b8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8ef5:	48 8b 15 fc 5b 01 00 	mov    0x15bfc(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8efc:	49 89 c5             	mov    %rax,%r13
    8eff:	48 2b 05 ca 5b 01 00 	sub    0x15bca(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8f06:	48 c1 e2 10          	shl    $0x10,%rdx
    8f0a:	48 39 d0             	cmp    %rdx,%rax
    8f0d:	73 59                	jae    8f68 <f0+0x2038>
    8f0f:	48 89 c2             	mov    %rax,%rdx
    8f12:	48 c1 ea 10          	shr    $0x10,%rdx
    8f16:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f1a:	48 8b 15 f7 5b 01 00 	mov    0x15bf7(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8f21:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f25:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f29:	4d 85 e4             	test   %r12,%r12
    8f2c:	74 3a                	je     8f68 <f0+0x2038>
    8f2e:	0f b6 0a             	movzbl (%rdx),%ecx
    8f31:	80 f9 02             	cmp    $0x2,%cl
    8f34:	0f 84 f6 07 00 00    	je     9730 <f0+0x2800>
    8f3a:	80 f9 01             	cmp    $0x1,%cl
    8f3d:	75 29                	jne    8f68 <f0+0x2038>
    8f3f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f42:	0f b7 c0             	movzwl %ax,%eax
    8f45:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f48:	48 0f af c1          	imul   %rcx,%rax
    8f4c:	48 c1 e8 20          	shr    $0x20,%rax
    8f50:	48 39 d0             	cmp    %rdx,%rax
    8f53:	73 13                	jae    8f68 <f0+0x2038>
    8f55:	49 01 c4             	add    %rax,%r12
    8f58:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f5d:	0f 84 c1 09 00 00    	je     9924 <f0+0x29f4>
    8f63:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f68:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
    8f6f:	00 
    8f70:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    8f77:	00 
    8f78:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8f7f:	33 f3 bf 
    8f82:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    8f89:	00 
    8f8a:	e8 91 b7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8f8f:	48 8b 15 62 5b 01 00 	mov    0x15b62(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    8f96:	49 89 c5             	mov    %rax,%r13
    8f99:	48 2b 05 30 5b 01 00 	sub    0x15b30(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    8fa0:	48 c1 e2 10          	shl    $0x10,%rdx
    8fa4:	48 39 d0             	cmp    %rdx,%rax
    8fa7:	73 59                	jae    9002 <f0+0x20d2>
    8fa9:	48 89 c2             	mov    %rax,%rdx
    8fac:	48 c1 ea 10          	shr    $0x10,%rdx
    8fb0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8fb4:	48 8b 15 5d 5b 01 00 	mov    0x15b5d(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    8fbb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8fbf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8fc3:	4d 85 e4             	test   %r12,%r12
    8fc6:	74 3a                	je     9002 <f0+0x20d2>
    8fc8:	0f b6 0a             	movzbl (%rdx),%ecx
    8fcb:	80 f9 02             	cmp    $0x2,%cl
    8fce:	0f 84 4c 07 00 00    	je     9720 <f0+0x27f0>
    8fd4:	80 f9 01             	cmp    $0x1,%cl
    8fd7:	75 29                	jne    9002 <f0+0x20d2>
    8fd9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8fdc:	0f b7 c0             	movzwl %ax,%eax
    8fdf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8fe2:	48 0f af c1          	imul   %rcx,%rax
    8fe6:	48 c1 e8 20          	shr    $0x20,%rax
    8fea:	48 39 d0             	cmp    %rdx,%rax
    8fed:	73 13                	jae    9002 <f0+0x20d2>
    8fef:	49 01 c4             	add    %rax,%r12
    8ff2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ff7:	0f 84 34 09 00 00    	je     9931 <f0+0x2a01>
    8ffd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9002:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
    9009:	00 
    900a:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    9011:	00 
    9012:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9019:	00 f0 3f 
    901c:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9023:	00 
    9024:	e8 f7 b6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9029:	48 8b 15 c8 5a 01 00 	mov    0x15ac8(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    9030:	49 89 c5             	mov    %rax,%r13
    9033:	48 2b 05 96 5a 01 00 	sub    0x15a96(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    903a:	48 c1 e2 10          	shl    $0x10,%rdx
    903e:	48 39 d0             	cmp    %rdx,%rax
    9041:	73 59                	jae    909c <f0+0x216c>
    9043:	48 89 c2             	mov    %rax,%rdx
    9046:	48 c1 ea 10          	shr    $0x10,%rdx
    904a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    904e:	48 8b 15 c3 5a 01 00 	mov    0x15ac3(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    9055:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9059:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    905d:	4d 85 e4             	test   %r12,%r12
    9060:	74 3a                	je     909c <f0+0x216c>
    9062:	0f b6 0a             	movzbl (%rdx),%ecx
    9065:	80 f9 02             	cmp    $0x2,%cl
    9068:	0f 84 a2 06 00 00    	je     9710 <f0+0x27e0>
    906e:	80 f9 01             	cmp    $0x1,%cl
    9071:	75 29                	jne    909c <f0+0x216c>
    9073:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9076:	0f b7 c0             	movzwl %ax,%eax
    9079:	8b 52 1c             	mov    0x1c(%rdx),%edx
    907c:	48 0f af c1          	imul   %rcx,%rax
    9080:	48 c1 e8 20          	shr    $0x20,%rax
    9084:	48 39 d0             	cmp    %rdx,%rax
    9087:	73 13                	jae    909c <f0+0x216c>
    9089:	49 01 c4             	add    %rax,%r12
    908c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9091:	0f 84 a7 08 00 00    	je     993e <f0+0x2a0e>
    9097:	41 c6 04 24 01       	movb   $0x1,(%r12)
    909c:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
    90a3:	00 
    90a4:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    90ab:	00 
    90ac:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    90b3:	33 f3 bf 
    90b6:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    90bd:	00 
    90be:	e8 5d b6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    90c3:	48 8b 15 2e 5a 01 00 	mov    0x15a2e(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    90ca:	49 89 c5             	mov    %rax,%r13
    90cd:	48 2b 05 fc 59 01 00 	sub    0x159fc(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    90d4:	48 c1 e2 10          	shl    $0x10,%rdx
    90d8:	48 39 d0             	cmp    %rdx,%rax
    90db:	73 59                	jae    9136 <f0+0x2206>
    90dd:	48 89 c2             	mov    %rax,%rdx
    90e0:	48 c1 ea 10          	shr    $0x10,%rdx
    90e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90e8:	48 8b 15 29 5a 01 00 	mov    0x15a29(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    90ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    90f7:	4d 85 e4             	test   %r12,%r12
    90fa:	74 3a                	je     9136 <f0+0x2206>
    90fc:	0f b6 0a             	movzbl (%rdx),%ecx
    90ff:	80 f9 02             	cmp    $0x2,%cl
    9102:	0f 84 f8 05 00 00    	je     9700 <f0+0x27d0>
    9108:	80 f9 01             	cmp    $0x1,%cl
    910b:	75 29                	jne    9136 <f0+0x2206>
    910d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9110:	0f b7 c0             	movzwl %ax,%eax
    9113:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9116:	48 0f af c1          	imul   %rcx,%rax
    911a:	48 c1 e8 20          	shr    $0x20,%rax
    911e:	48 39 d0             	cmp    %rdx,%rax
    9121:	73 13                	jae    9136 <f0+0x2206>
    9123:	49 01 c4             	add    %rax,%r12
    9126:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    912b:	0f 84 1a 08 00 00    	je     994b <f0+0x2a1b>
    9131:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9136:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
    913d:	00 
    913e:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9145:	00 
    9146:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    914d:	00 f0 3f 
    9150:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9157:	00 
    9158:	e8 c3 b5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    915d:	48 8b 15 94 59 01 00 	mov    0x15994(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    9164:	49 89 c5             	mov    %rax,%r13
    9167:	48 2b 05 62 59 01 00 	sub    0x15962(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    916e:	48 c1 e2 10          	shl    $0x10,%rdx
    9172:	48 39 d0             	cmp    %rdx,%rax
    9175:	73 59                	jae    91d0 <f0+0x22a0>
    9177:	48 89 c2             	mov    %rax,%rdx
    917a:	48 c1 ea 10          	shr    $0x10,%rdx
    917e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9182:	48 8b 15 8f 59 01 00 	mov    0x1598f(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    9189:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    918d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9191:	4d 85 e4             	test   %r12,%r12
    9194:	74 3a                	je     91d0 <f0+0x22a0>
    9196:	0f b6 0a             	movzbl (%rdx),%ecx
    9199:	80 f9 02             	cmp    $0x2,%cl
    919c:	0f 84 4e 05 00 00    	je     96f0 <f0+0x27c0>
    91a2:	80 f9 01             	cmp    $0x1,%cl
    91a5:	75 29                	jne    91d0 <f0+0x22a0>
    91a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91aa:	0f b7 c0             	movzwl %ax,%eax
    91ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91b0:	48 0f af c1          	imul   %rcx,%rax
    91b4:	48 c1 e8 20          	shr    $0x20,%rax
    91b8:	48 39 d0             	cmp    %rdx,%rax
    91bb:	73 13                	jae    91d0 <f0+0x22a0>
    91bd:	49 01 c4             	add    %rax,%r12
    91c0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    91c5:	0f 84 8d 07 00 00    	je     9958 <f0+0x2a28>
    91cb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    91d0:	48 8d bc 24 00 08 00 	lea    0x800(%rsp),%rdi
    91d7:	00 
    91d8:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    91df:	00 
    91e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    91e7:	33 f3 bf 
    91ea:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    91f1:	00 
    91f2:	e8 29 b5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    91f7:	48 8b 15 fa 58 01 00 	mov    0x158fa(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    91fe:	49 89 c5             	mov    %rax,%r13
    9201:	48 2b 05 c8 58 01 00 	sub    0x158c8(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    9208:	48 c1 e2 10          	shl    $0x10,%rdx
    920c:	48 39 d0             	cmp    %rdx,%rax
    920f:	73 59                	jae    926a <f0+0x233a>
    9211:	48 89 c2             	mov    %rax,%rdx
    9214:	48 c1 ea 10          	shr    $0x10,%rdx
    9218:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    921c:	48 8b 15 f5 58 01 00 	mov    0x158f5(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    9223:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9227:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    922b:	4d 85 e4             	test   %r12,%r12
    922e:	74 3a                	je     926a <f0+0x233a>
    9230:	0f b6 0a             	movzbl (%rdx),%ecx
    9233:	80 f9 02             	cmp    $0x2,%cl
    9236:	0f 84 a4 04 00 00    	je     96e0 <f0+0x27b0>
    923c:	80 f9 01             	cmp    $0x1,%cl
    923f:	75 29                	jne    926a <f0+0x233a>
    9241:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9244:	0f b7 c0             	movzwl %ax,%eax
    9247:	8b 52 1c             	mov    0x1c(%rdx),%edx
    924a:	48 0f af c1          	imul   %rcx,%rax
    924e:	48 c1 e8 20          	shr    $0x20,%rax
    9252:	48 39 d0             	cmp    %rdx,%rax
    9255:	73 13                	jae    926a <f0+0x233a>
    9257:	49 01 c4             	add    %rax,%r12
    925a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    925f:	0f 84 00 07 00 00    	je     9965 <f0+0x2a35>
    9265:	41 c6 04 24 01       	movb   $0x1,(%r12)
    926a:	48 8d bc 24 10 08 00 	lea    0x810(%rsp),%rdi
    9271:	00 
    9272:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    9279:	00 
    927a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9281:	00 f0 3f 
    9284:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    928b:	00 
    928c:	e8 8f b4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9291:	48 8b 15 60 58 01 00 	mov    0x15860(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    9298:	49 89 c5             	mov    %rax,%r13
    929b:	48 2b 05 2e 58 01 00 	sub    0x1582e(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    92a2:	48 c1 e2 10          	shl    $0x10,%rdx
    92a6:	48 39 d0             	cmp    %rdx,%rax
    92a9:	73 59                	jae    9304 <f0+0x23d4>
    92ab:	48 89 c2             	mov    %rax,%rdx
    92ae:	48 c1 ea 10          	shr    $0x10,%rdx
    92b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92b6:	48 8b 15 5b 58 01 00 	mov    0x1585b(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    92bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92c1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    92c5:	4d 85 e4             	test   %r12,%r12
    92c8:	74 3a                	je     9304 <f0+0x23d4>
    92ca:	0f b6 0a             	movzbl (%rdx),%ecx
    92cd:	80 f9 02             	cmp    $0x2,%cl
    92d0:	0f 84 fa 03 00 00    	je     96d0 <f0+0x27a0>
    92d6:	80 f9 01             	cmp    $0x1,%cl
    92d9:	75 29                	jne    9304 <f0+0x23d4>
    92db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92de:	0f b7 c0             	movzwl %ax,%eax
    92e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92e4:	48 0f af c1          	imul   %rcx,%rax
    92e8:	48 c1 e8 20          	shr    $0x20,%rax
    92ec:	48 39 d0             	cmp    %rdx,%rax
    92ef:	73 13                	jae    9304 <f0+0x23d4>
    92f1:	49 01 c4             	add    %rax,%r12
    92f4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    92f9:	0f 84 73 06 00 00    	je     9972 <f0+0x2a42>
    92ff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9304:	48 8d bc 24 20 08 00 	lea    0x820(%rsp),%rdi
    930b:	00 
    930c:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    9313:	00 
    9314:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    931b:	33 f3 bf 
    931e:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9325:	00 
    9326:	e8 f5 b3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    932b:	48 8b 15 c6 57 01 00 	mov    0x157c6(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    9332:	49 89 c5             	mov    %rax,%r13
    9335:	48 2b 05 94 57 01 00 	sub    0x15794(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    933c:	48 c1 e2 10          	shl    $0x10,%rdx
    9340:	48 39 d0             	cmp    %rdx,%rax
    9343:	73 59                	jae    939e <f0+0x246e>
    9345:	48 89 c2             	mov    %rax,%rdx
    9348:	48 c1 ea 10          	shr    $0x10,%rdx
    934c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9350:	48 8b 15 c1 57 01 00 	mov    0x157c1(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    9357:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    935b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    935f:	4d 85 e4             	test   %r12,%r12
    9362:	74 3a                	je     939e <f0+0x246e>
    9364:	0f b6 0a             	movzbl (%rdx),%ecx
    9367:	80 f9 02             	cmp    $0x2,%cl
    936a:	0f 84 50 03 00 00    	je     96c0 <f0+0x2790>
    9370:	80 f9 01             	cmp    $0x1,%cl
    9373:	75 29                	jne    939e <f0+0x246e>
    9375:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9378:	0f b7 c0             	movzwl %ax,%eax
    937b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    937e:	48 0f af c1          	imul   %rcx,%rax
    9382:	48 c1 e8 20          	shr    $0x20,%rax
    9386:	48 39 d0             	cmp    %rdx,%rax
    9389:	73 13                	jae    939e <f0+0x246e>
    938b:	49 01 c4             	add    %rax,%r12
    938e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9393:	0f 84 e6 05 00 00    	je     997f <f0+0x2a4f>
    9399:	41 c6 04 24 01       	movb   $0x1,(%r12)
    939e:	48 8d bc 24 30 08 00 	lea    0x830(%rsp),%rdi
    93a5:	00 
    93a6:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    93ad:	00 
    93ae:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    93b5:	00 f0 3f 
    93b8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    93bf:	00 
    93c0:	e8 5b b3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    93c5:	48 8b 15 2c 57 01 00 	mov    0x1572c(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    93cc:	49 89 c5             	mov    %rax,%r13
    93cf:	48 2b 05 fa 56 01 00 	sub    0x156fa(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    93d6:	48 c1 e2 10          	shl    $0x10,%rdx
    93da:	48 39 d0             	cmp    %rdx,%rax
    93dd:	73 59                	jae    9438 <f0+0x2508>
    93df:	48 89 c2             	mov    %rax,%rdx
    93e2:	48 c1 ea 10          	shr    $0x10,%rdx
    93e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93ea:	48 8b 15 27 57 01 00 	mov    0x15727(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    93f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93f5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    93f9:	4d 85 e4             	test   %r12,%r12
    93fc:	74 3a                	je     9438 <f0+0x2508>
    93fe:	0f b6 0a             	movzbl (%rdx),%ecx
    9401:	80 f9 02             	cmp    $0x2,%cl
    9404:	0f 84 a6 02 00 00    	je     96b0 <f0+0x2780>
    940a:	80 f9 01             	cmp    $0x1,%cl
    940d:	75 29                	jne    9438 <f0+0x2508>
    940f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9412:	0f b7 c0             	movzwl %ax,%eax
    9415:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9418:	48 0f af c1          	imul   %rcx,%rax
    941c:	48 c1 e8 20          	shr    $0x20,%rax
    9420:	48 39 d0             	cmp    %rdx,%rax
    9423:	73 13                	jae    9438 <f0+0x2508>
    9425:	49 01 c4             	add    %rax,%r12
    9428:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    942d:	0f 84 59 05 00 00    	je     998c <f0+0x2a5c>
    9433:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9438:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    943f:	33 f3 bf 
    9442:	48 89 ef             	mov    %rbp,%rdi
    9445:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    944c:	00 
    944d:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    9454:	00 
    9455:	e8 c6 b2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    945a:	48 8b 15 97 56 01 00 	mov    0x15697(%rip),%rdx        # 1eaf8 <fwp_heap+0x13d8>
    9461:	48 89 c5             	mov    %rax,%rbp
    9464:	48 2b 05 65 56 01 00 	sub    0x15665(%rip),%rax        # 1ead0 <fwp_heap+0x13b0>
    946b:	48 c1 e2 10          	shl    $0x10,%rdx
    946f:	48 39 d0             	cmp    %rdx,%rax
    9472:	73 59                	jae    94cd <f0+0x259d>
    9474:	48 89 c2             	mov    %rax,%rdx
    9477:	48 c1 ea 10          	shr    $0x10,%rdx
    947b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    947f:	48 8b 15 92 56 01 00 	mov    0x15692(%rip),%rdx        # 1eb18 <fwp_heap+0x13f8>
    9486:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    948a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    948e:	4d 85 e4             	test   %r12,%r12
    9491:	74 3a                	je     94cd <f0+0x259d>
    9493:	0f b6 0a             	movzbl (%rdx),%ecx
    9496:	80 f9 02             	cmp    $0x2,%cl
    9499:	0f 84 01 02 00 00    	je     96a0 <f0+0x2770>
    949f:	80 f9 01             	cmp    $0x1,%cl
    94a2:	75 29                	jne    94cd <f0+0x259d>
    94a4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94a7:	0f b7 c0             	movzwl %ax,%eax
    94aa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94ad:	48 0f af c1          	imul   %rcx,%rax
    94b1:	48 c1 e8 20          	shr    $0x20,%rax
    94b5:	48 39 d0             	cmp    %rdx,%rax
    94b8:	73 13                	jae    94cd <f0+0x259d>
    94ba:	49 01 c4             	add    %rax,%r12
    94bd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    94c2:	0f 84 d6 02 00 00    	je     979e <f0+0x286e>
    94c8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    94cd:	48 89 de             	mov    %rbx,%rsi
    94d0:	48 89 ef             	mov    %rbp,%rdi
    94d3:	e8 f8 ca ff ff       	call   5fd0 <fwp_hof0.constprop.0>
    94d8:	48 89 ef             	mov    %rbp,%rdi
    94db:	e8 20 b8 ff ff       	call   4d00 <fwp_drop0>
    94e0:	48 89 df             	mov    %rbx,%rdi
    94e3:	e8 18 b8 ff ff       	call   4d00 <fwp_drop0>
    94e8:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    94ef:	00 
    94f0:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    94f7:	00 00 
    94f9:	0f 85 9a 04 00 00    	jne    9999 <f0+0x2a69>
    94ff:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    9506:	31 c0                	xor    %eax,%eax
    9508:	5b                   	pop    %rbx
    9509:	5d                   	pop    %rbp
    950a:	41 5c                	pop    %r12
    950c:	41 5d                	pop    %r13
    950e:	41 5e                	pop    %r14
    9510:	c3                   	ret
    9511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9518:	4c 89 ef             	mov    %r13,%rdi
    951b:	e8 70 a8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9520:	e9 c4 da ff ff       	jmp    6fe9 <f0+0xb9>
    9525:	0f 1f 00             	nopl   (%rax)
    9528:	66 85 c0             	test   %ax,%ax
    952b:	0f 85 01 f6 ff ff    	jne    8b32 <f0+0x1c02>
    9531:	e9 ec f5 ff ff       	jmp    8b22 <f0+0x1bf2>
    9536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    953d:	00 00 00 
    9540:	66 85 c0             	test   %ax,%ax
    9543:	0f 85 4f f5 ff ff    	jne    8a98 <f0+0x1b68>
    9549:	e9 3a f5 ff ff       	jmp    8a88 <f0+0x1b58>
    954e:	66 90                	xchg   %ax,%ax
    9550:	66 85 c0             	test   %ax,%ax
    9553:	0f 85 a5 f4 ff ff    	jne    89fe <f0+0x1ace>
    9559:	e9 90 f4 ff ff       	jmp    89ee <f0+0x1abe>
    955e:	66 90                	xchg   %ax,%ax
    9560:	66 85 c0             	test   %ax,%ax
    9563:	0f 85 fb f3 ff ff    	jne    8964 <f0+0x1a34>
    9569:	e9 e6 f3 ff ff       	jmp    8954 <f0+0x1a24>
    956e:	66 90                	xchg   %ax,%ax
    9570:	66 85 c0             	test   %ax,%ax
    9573:	0f 85 51 f3 ff ff    	jne    88ca <f0+0x199a>
    9579:	e9 3c f3 ff ff       	jmp    88ba <f0+0x198a>
    957e:	66 90                	xchg   %ax,%ax
    9580:	66 85 c0             	test   %ax,%ax
    9583:	0f 85 a7 f2 ff ff    	jne    8830 <f0+0x1900>
    9589:	e9 92 f2 ff ff       	jmp    8820 <f0+0x18f0>
    958e:	66 90                	xchg   %ax,%ax
    9590:	66 85 c0             	test   %ax,%ax
    9593:	0f 85 fd f1 ff ff    	jne    8796 <f0+0x1866>
    9599:	e9 e8 f1 ff ff       	jmp    8786 <f0+0x1856>
    959e:	66 90                	xchg   %ax,%ax
    95a0:	66 85 c0             	test   %ax,%ax
    95a3:	0f 85 53 f1 ff ff    	jne    86fc <f0+0x17cc>
    95a9:	e9 3e f1 ff ff       	jmp    86ec <f0+0x17bc>
    95ae:	66 90                	xchg   %ax,%ax
    95b0:	66 85 c0             	test   %ax,%ax
    95b3:	0f 85 6e dc ff ff    	jne    7227 <f0+0x2f7>
    95b9:	e9 59 dc ff ff       	jmp    7217 <f0+0x2e7>
    95be:	66 90                	xchg   %ax,%ax
    95c0:	66 85 c0             	test   %ax,%ax
    95c3:	0f 85 cd db ff ff    	jne    7196 <f0+0x266>
    95c9:	e9 b8 db ff ff       	jmp    7186 <f0+0x256>
    95ce:	66 90                	xchg   %ax,%ax
    95d0:	66 85 c0             	test   %ax,%ax
    95d3:	0f 85 2c db ff ff    	jne    7105 <f0+0x1d5>
    95d9:	e9 17 db ff ff       	jmp    70f5 <f0+0x1c5>
    95de:	66 90                	xchg   %ax,%ax
    95e0:	66 85 c0             	test   %ax,%ax
    95e3:	0f 85 a9 eb ff ff    	jne    8192 <f0+0x1262>
    95e9:	e9 94 eb ff ff       	jmp    8182 <f0+0x1252>
    95ee:	66 90                	xchg   %ax,%ax
    95f0:	66 85 c0             	test   %ax,%ax
    95f3:	0f 85 ff ea ff ff    	jne    80f8 <f0+0x11c8>
    95f9:	e9 ea ea ff ff       	jmp    80e8 <f0+0x11b8>
    95fe:	66 90                	xchg   %ax,%ax
    9600:	66 85 c0             	test   %ax,%ax
    9603:	0f 85 55 ea ff ff    	jne    805e <f0+0x112e>
    9609:	e9 40 ea ff ff       	jmp    804e <f0+0x111e>
    960e:	66 90                	xchg   %ax,%ax
    9610:	66 85 c0             	test   %ax,%ax
    9613:	0f 85 9f dc ff ff    	jne    72b8 <f0+0x388>
    9619:	e9 8a dc ff ff       	jmp    72a8 <f0+0x378>
    961e:	66 90                	xchg   %ax,%ax
    9620:	66 85 c0             	test   %ax,%ax
    9623:	0f 85 39 f0 ff ff    	jne    8662 <f0+0x1732>
    9629:	e9 24 f0 ff ff       	jmp    8652 <f0+0x1722>
    962e:	66 90                	xchg   %ax,%ax
    9630:	66 85 c0             	test   %ax,%ax
    9633:	0f 85 8f ef ff ff    	jne    85c8 <f0+0x1698>
    9639:	e9 7a ef ff ff       	jmp    85b8 <f0+0x1688>
    963e:	66 90                	xchg   %ax,%ax
    9640:	66 85 c0             	test   %ax,%ax
    9643:	0f 85 e5 ee ff ff    	jne    852e <f0+0x15fe>
    9649:	e9 d0 ee ff ff       	jmp    851e <f0+0x15ee>
    964e:	66 90                	xchg   %ax,%ax
    9650:	66 85 c0             	test   %ax,%ax
    9653:	0f 85 3b ee ff ff    	jne    8494 <f0+0x1564>
    9659:	e9 26 ee ff ff       	jmp    8484 <f0+0x1554>
    965e:	66 90                	xchg   %ax,%ax
    9660:	66 85 c0             	test   %ax,%ax
    9663:	0f 85 91 ed ff ff    	jne    83fa <f0+0x14ca>
    9669:	e9 7c ed ff ff       	jmp    83ea <f0+0x14ba>
    966e:	66 90                	xchg   %ax,%ax
    9670:	66 85 c0             	test   %ax,%ax
    9673:	0f 85 e7 ec ff ff    	jne    8360 <f0+0x1430>
    9679:	e9 d2 ec ff ff       	jmp    8350 <f0+0x1420>
    967e:	66 90                	xchg   %ax,%ax
    9680:	66 85 c0             	test   %ax,%ax
    9683:	0f 85 3d ec ff ff    	jne    82c6 <f0+0x1396>
    9689:	e9 28 ec ff ff       	jmp    82b6 <f0+0x1386>
    968e:	66 90                	xchg   %ax,%ax
    9690:	66 85 c0             	test   %ax,%ax
    9693:	0f 85 93 eb ff ff    	jne    822c <f0+0x12fc>
    9699:	e9 7e eb ff ff       	jmp    821c <f0+0x12ec>
    969e:	66 90                	xchg   %ax,%ax
    96a0:	66 85 c0             	test   %ax,%ax
    96a3:	0f 85 24 fe ff ff    	jne    94cd <f0+0x259d>
    96a9:	e9 0f fe ff ff       	jmp    94bd <f0+0x258d>
    96ae:	66 90                	xchg   %ax,%ax
    96b0:	66 85 c0             	test   %ax,%ax
    96b3:	0f 85 7f fd ff ff    	jne    9438 <f0+0x2508>
    96b9:	e9 6a fd ff ff       	jmp    9428 <f0+0x24f8>
    96be:	66 90                	xchg   %ax,%ax
    96c0:	66 85 c0             	test   %ax,%ax
    96c3:	0f 85 d5 fc ff ff    	jne    939e <f0+0x246e>
    96c9:	e9 c0 fc ff ff       	jmp    938e <f0+0x245e>
    96ce:	66 90                	xchg   %ax,%ax
    96d0:	66 85 c0             	test   %ax,%ax
    96d3:	0f 85 2b fc ff ff    	jne    9304 <f0+0x23d4>
    96d9:	e9 16 fc ff ff       	jmp    92f4 <f0+0x23c4>
    96de:	66 90                	xchg   %ax,%ax
    96e0:	66 85 c0             	test   %ax,%ax
    96e3:	0f 85 81 fb ff ff    	jne    926a <f0+0x233a>
    96e9:	e9 6c fb ff ff       	jmp    925a <f0+0x232a>
    96ee:	66 90                	xchg   %ax,%ax
    96f0:	66 85 c0             	test   %ax,%ax
    96f3:	0f 85 d7 fa ff ff    	jne    91d0 <f0+0x22a0>
    96f9:	e9 c2 fa ff ff       	jmp    91c0 <f0+0x2290>
    96fe:	66 90                	xchg   %ax,%ax
    9700:	66 85 c0             	test   %ax,%ax
    9703:	0f 85 2d fa ff ff    	jne    9136 <f0+0x2206>
    9709:	e9 18 fa ff ff       	jmp    9126 <f0+0x21f6>
    970e:	66 90                	xchg   %ax,%ax
    9710:	66 85 c0             	test   %ax,%ax
    9713:	0f 85 83 f9 ff ff    	jne    909c <f0+0x216c>
    9719:	e9 6e f9 ff ff       	jmp    908c <f0+0x215c>
    971e:	66 90                	xchg   %ax,%ax
    9720:	66 85 c0             	test   %ax,%ax
    9723:	0f 85 d9 f8 ff ff    	jne    9002 <f0+0x20d2>
    9729:	e9 c4 f8 ff ff       	jmp    8ff2 <f0+0x20c2>
    972e:	66 90                	xchg   %ax,%ax
    9730:	66 85 c0             	test   %ax,%ax
    9733:	0f 85 2f f8 ff ff    	jne    8f68 <f0+0x2038>
    9739:	e9 1a f8 ff ff       	jmp    8f58 <f0+0x2028>
    973e:	66 90                	xchg   %ax,%ax
    9740:	66 85 c0             	test   %ax,%ax
    9743:	0f 85 85 f7 ff ff    	jne    8ece <f0+0x1f9e>
    9749:	e9 70 f7 ff ff       	jmp    8ebe <f0+0x1f8e>
    974e:	66 90                	xchg   %ax,%ax
    9750:	66 85 c0             	test   %ax,%ax
    9753:	0f 85 db f6 ff ff    	jne    8e34 <f0+0x1f04>
    9759:	e9 c6 f6 ff ff       	jmp    8e24 <f0+0x1ef4>
    975e:	66 90                	xchg   %ax,%ax
    9760:	66 85 c0             	test   %ax,%ax
    9763:	0f 85 31 f6 ff ff    	jne    8d9a <f0+0x1e6a>
    9769:	e9 1c f6 ff ff       	jmp    8d8a <f0+0x1e5a>
    976e:	66 90                	xchg   %ax,%ax
    9770:	66 85 c0             	test   %ax,%ax
    9773:	0f 85 87 f5 ff ff    	jne    8d00 <f0+0x1dd0>
    9779:	e9 72 f5 ff ff       	jmp    8cf0 <f0+0x1dc0>
    977e:	66 90                	xchg   %ax,%ax
    9780:	66 85 c0             	test   %ax,%ax
    9783:	0f 85 dd f4 ff ff    	jne    8c66 <f0+0x1d36>
    9789:	e9 c8 f4 ff ff       	jmp    8c56 <f0+0x1d26>
    978e:	66 90                	xchg   %ax,%ax
    9790:	66 85 c0             	test   %ax,%ax
    9793:	0f 85 33 f4 ff ff    	jne    8bcc <f0+0x1c9c>
    9799:	e9 1e f4 ff ff       	jmp    8bbc <f0+0x1c8c>
    979e:	4c 89 e7             	mov    %r12,%rdi
    97a1:	e8 ea a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97a6:	e9 1d fd ff ff       	jmp    94c8 <f0+0x2598>
    97ab:	4c 89 e7             	mov    %r12,%rdi
    97ae:	e8 dd a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97b3:	e9 48 d9 ff ff       	jmp    7100 <f0+0x1d0>
    97b8:	4c 89 e7             	mov    %r12,%rdi
    97bb:	e8 d0 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97c0:	e9 cc d9 ff ff       	jmp    7191 <f0+0x261>
    97c5:	4c 89 e7             	mov    %r12,%rdi
    97c8:	e8 c3 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97cd:	e9 50 da ff ff       	jmp    7222 <f0+0x2f2>
    97d2:	4c 89 e7             	mov    %r12,%rdi
    97d5:	e8 b6 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97da:	e9 d4 da ff ff       	jmp    72b3 <f0+0x383>
    97df:	4c 89 e7             	mov    %r12,%rdi
    97e2:	e8 a9 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97e7:	e9 6d e8 ff ff       	jmp    8059 <f0+0x1129>
    97ec:	4c 89 e7             	mov    %r12,%rdi
    97ef:	e8 9c a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97f4:	e9 fa e8 ff ff       	jmp    80f3 <f0+0x11c3>
    97f9:	4c 89 e7             	mov    %r12,%rdi
    97fc:	e8 8f a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9801:	e9 87 e9 ff ff       	jmp    818d <f0+0x125d>
    9806:	4c 89 e7             	mov    %r12,%rdi
    9809:	e8 82 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    980e:	e9 14 ea ff ff       	jmp    8227 <f0+0x12f7>
    9813:	4c 89 e7             	mov    %r12,%rdi
    9816:	e8 75 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    981b:	e9 a1 ea ff ff       	jmp    82c1 <f0+0x1391>
    9820:	4c 89 e7             	mov    %r12,%rdi
    9823:	e8 68 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9828:	e9 2e eb ff ff       	jmp    835b <f0+0x142b>
    982d:	4c 89 e7             	mov    %r12,%rdi
    9830:	e8 5b a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9835:	e9 bb eb ff ff       	jmp    83f5 <f0+0x14c5>
    983a:	4c 89 e7             	mov    %r12,%rdi
    983d:	e8 4e a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9842:	e9 48 ec ff ff       	jmp    848f <f0+0x155f>
    9847:	4c 89 e7             	mov    %r12,%rdi
    984a:	e8 41 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    984f:	e9 d5 ec ff ff       	jmp    8529 <f0+0x15f9>
    9854:	4c 89 e7             	mov    %r12,%rdi
    9857:	e8 34 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    985c:	e9 62 ed ff ff       	jmp    85c3 <f0+0x1693>
    9861:	4c 89 e7             	mov    %r12,%rdi
    9864:	e8 27 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9869:	e9 ef ed ff ff       	jmp    865d <f0+0x172d>
    986e:	4c 89 e7             	mov    %r12,%rdi
    9871:	e8 1a a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9876:	e9 7c ee ff ff       	jmp    86f7 <f0+0x17c7>
    987b:	4c 89 e7             	mov    %r12,%rdi
    987e:	e8 0d a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9883:	e9 09 ef ff ff       	jmp    8791 <f0+0x1861>
    9888:	4c 89 e7             	mov    %r12,%rdi
    988b:	e8 00 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9890:	e9 96 ef ff ff       	jmp    882b <f0+0x18fb>
    9895:	4c 89 e7             	mov    %r12,%rdi
    9898:	e8 f3 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    989d:	e9 23 f0 ff ff       	jmp    88c5 <f0+0x1995>
    98a2:	4c 89 e7             	mov    %r12,%rdi
    98a5:	e8 e6 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98aa:	e9 b0 f0 ff ff       	jmp    895f <f0+0x1a2f>
    98af:	4c 89 e7             	mov    %r12,%rdi
    98b2:	e8 d9 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98b7:	e9 3d f1 ff ff       	jmp    89f9 <f0+0x1ac9>
    98bc:	4c 89 e7             	mov    %r12,%rdi
    98bf:	e8 cc a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98c4:	e9 ca f1 ff ff       	jmp    8a93 <f0+0x1b63>
    98c9:	4c 89 e7             	mov    %r12,%rdi
    98cc:	e8 bf a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98d1:	e9 57 f2 ff ff       	jmp    8b2d <f0+0x1bfd>
    98d6:	4c 89 e7             	mov    %r12,%rdi
    98d9:	e8 b2 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98de:	e9 e4 f2 ff ff       	jmp    8bc7 <f0+0x1c97>
    98e3:	4c 89 e7             	mov    %r12,%rdi
    98e6:	e8 a5 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98eb:	e9 71 f3 ff ff       	jmp    8c61 <f0+0x1d31>
    98f0:	4c 89 e7             	mov    %r12,%rdi
    98f3:	e8 98 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98f8:	e9 fe f3 ff ff       	jmp    8cfb <f0+0x1dcb>
    98fd:	4c 89 e7             	mov    %r12,%rdi
    9900:	e8 8b a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9905:	e9 8b f4 ff ff       	jmp    8d95 <f0+0x1e65>
    990a:	4c 89 e7             	mov    %r12,%rdi
    990d:	e8 7e a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9912:	e9 18 f5 ff ff       	jmp    8e2f <f0+0x1eff>
    9917:	4c 89 e7             	mov    %r12,%rdi
    991a:	e8 71 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    991f:	e9 a5 f5 ff ff       	jmp    8ec9 <f0+0x1f99>
    9924:	4c 89 e7             	mov    %r12,%rdi
    9927:	e8 64 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    992c:	e9 32 f6 ff ff       	jmp    8f63 <f0+0x2033>
    9931:	4c 89 e7             	mov    %r12,%rdi
    9934:	e8 57 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9939:	e9 bf f6 ff ff       	jmp    8ffd <f0+0x20cd>
    993e:	4c 89 e7             	mov    %r12,%rdi
    9941:	e8 4a a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9946:	e9 4c f7 ff ff       	jmp    9097 <f0+0x2167>
    994b:	4c 89 e7             	mov    %r12,%rdi
    994e:	e8 3d a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9953:	e9 d9 f7 ff ff       	jmp    9131 <f0+0x2201>
    9958:	4c 89 e7             	mov    %r12,%rdi
    995b:	e8 30 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9960:	e9 66 f8 ff ff       	jmp    91cb <f0+0x229b>
    9965:	4c 89 e7             	mov    %r12,%rdi
    9968:	e8 23 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    996d:	e9 f3 f8 ff ff       	jmp    9265 <f0+0x2335>
    9972:	4c 89 e7             	mov    %r12,%rdi
    9975:	e8 16 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    997a:	e9 80 f9 ff ff       	jmp    92ff <f0+0x23cf>
    997f:	4c 89 e7             	mov    %r12,%rdi
    9982:	e8 09 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9987:	e9 0d fa ff ff       	jmp    9399 <f0+0x2469>
    998c:	4c 89 e7             	mov    %r12,%rdi
    998f:	e8 fc a3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9994:	e9 9a fa ff ff       	jmp    9433 <f0+0x2503>
    9999:	e8 a2 8a ff ff       	call   2440 <__stack_chk_fail@plt>
    999e:	66 90                	xchg   %ax,%ax

00000000000099a0 <fwp_main_thread>:
    99a0:	f3 0f 1e fa          	endbr64
    99a4:	41 54                	push   %r12
    99a6:	55                   	push   %rbp
    99a7:	53                   	push   %rbx
    99a8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    99af:	8b 0d 0f 51 01 00    	mov    0x1510f(%rip),%ecx        # 1eac4 <fwp_heap+0x13a4>
    99b5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    99bc:	00 00 
    99be:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    99c5:	00 
    99c6:	31 c0                	xor    %eax,%eax
    99c8:	85 c9                	test   %ecx,%ecx
    99ca:	0f 84 68 06 00 00    	je     a038 <fwp_main_thread+0x698>
    99d0:	8b 15 f2 50 01 00    	mov    0x150f2(%rip),%edx        # 1eac8 <fwp_heap+0x13a8>
    99d6:	85 d2                	test   %edx,%edx
    99d8:	0f 85 42 06 00 00    	jne    a020 <fwp_main_thread+0x680>
    99de:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    99e3:	31 f6                	xor    %esi,%esi
    99e5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    99ea:	48 c7 05 d3 36 01 00 	movq   $0x40000000,0x136d3(%rip)        # 1d0c8 <fwp_main_stack_size>
    99f1:	00 00 00 40 
    99f5:	48 89 05 d4 36 01 00 	mov    %rax,0x136d4(%rip)        # 1d0d0 <fwp_main_stack_top>
    99fc:	48 8d 05 bd 36 00 00 	lea    0x36bd(%rip),%rax        # d0c0 <alt.4>
    9a03:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9a08:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    9a0f:	01 00 
    9a11:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    9a18:	00 
    9a19:	e8 62 8c ff ff       	call   2680 <sigaltstack@plt>
    9a1e:	85 c0                	test   %eax,%eax
    9a20:	0f 85 4a 06 00 00    	jne    a070 <fwp_main_thread+0x6d0>
    9a26:	31 c0                	xor    %eax,%eax
    9a28:	b9 12 00 00 00       	mov    $0x12,%ecx
    9a2d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9a32:	f3 48 ab             	rep stos %rax,(%rdi)
    9a35:	48 8d 05 04 92 ff ff 	lea    -0x6dfc(%rip),%rax        # 2c40 <fwp_segv>
    9a3c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9a41:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    9a48:	04 00 00 08 
    9a4c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9a51:	e8 fa 8a ff ff       	call   2550 <sigemptyset@plt>
    9a56:	85 c0                	test   %eax,%eax
    9a58:	0f 85 12 06 00 00    	jne    a070 <fwp_main_thread+0x6d0>
    9a5e:	31 d2                	xor    %edx,%edx
    9a60:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9a65:	bf 0b 00 00 00       	mov    $0xb,%edi
    9a6a:	e8 71 89 ff ff       	call   23e0 <sigaction@plt>
    9a6f:	85 c0                	test   %eax,%eax
    9a71:	0f 85 f9 05 00 00    	jne    a070 <fwp_main_thread+0x6d0>
    9a77:	31 d2                	xor    %edx,%edx
    9a79:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9a7e:	bf 07 00 00 00       	mov    $0x7,%edi
    9a83:	e8 58 89 ff ff       	call   23e0 <sigaction@plt>
    9a88:	85 c0                	test   %eax,%eax
    9a8a:	0f 85 e0 05 00 00    	jne    a070 <fwp_main_thread+0x6d0>
    9a90:	8b 05 12 36 00 00    	mov    0x3612(%rip),%eax        # d0a8 <st.2>
    9a96:	85 c0                	test   %eax,%eax
    9a98:	0f 84 62 05 00 00    	je     a000 <fwp_main_thread+0x660>
    9a9e:	48 8b 2d 5b 3c 01 00 	mov    0x13c5b(%rip),%rbp        # 1d700 <fwp_cur>
    9aa5:	48 85 ed             	test   %rbp,%rbp
    9aa8:	0f 84 72 03 00 00    	je     9e20 <fwp_main_thread+0x480>
    9aae:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9ab3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9ab7:	48 89 eb             	mov    %rbp,%rbx
    9aba:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9abf:	0f 84 41 01 00 00    	je     9c06 <fwp_main_thread+0x266>
    9ac5:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9aca:	0f 84 80 02 00 00    	je     9d50 <fwp_main_thread+0x3b0>
    9ad0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9ad4:	0f 84 66 02 00 00    	je     9d40 <fwp_main_thread+0x3a0>
    9ada:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9ade:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9ae2:	0f 85 e8 02 00 00    	jne    9dd0 <fwp_main_thread+0x430>
    9ae8:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9aec:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9af3:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9af7:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9afe:	00 00 00 00 
    9b02:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9b09:	48 85 d2             	test   %rdx,%rdx
    9b0c:	74 07                	je     9b15 <fwp_main_thread+0x175>
    9b0e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9b15:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9b19:	48 85 c0             	test   %rax,%rax
    9b1c:	74 34                	je     9b52 <fwp_main_thread+0x1b2>
    9b1e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9b22:	48 8b 05 af 3b 01 00 	mov    0x13baf(%rip),%rax        # 1d6d8 <fwp_timers>
    9b29:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9b2d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9b34:	00 00 00 00 
    9b38:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9b3f:	48 85 c0             	test   %rax,%rax
    9b42:	74 07                	je     9b4b <fwp_main_thread+0x1ab>
    9b44:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9b4b:	48 89 1d 86 3b 01 00 	mov    %rbx,0x13b86(%rip)        # 1d6d8 <fwp_timers>
    9b52:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9b56:	e8 f5 af ff ff       	call   4b50 <fwp_block>
    9b5b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9b62:	48 85 c9             	test   %rcx,%rcx
    9b65:	74 47                	je     9bae <fwp_main_thread+0x20e>
    9b67:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9b6e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9b75:	48 85 d2             	test   %rdx,%rdx
    9b78:	0f 84 92 02 00 00    	je     9e10 <fwp_main_thread+0x470>
    9b7e:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9b85:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9b8c:	48 85 c0             	test   %rax,%rax
    9b8f:	74 07                	je     9b98 <fwp_main_thread+0x1f8>
    9b91:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9b98:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9b9f:	00 00 00 00 
    9ba3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9ba7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    9bae:	48 8b 0d 4b 3b 01 00 	mov    0x13b4b(%rip),%rcx        # 1d700 <fwp_cur>
    9bb5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9bb9:	0f 84 01 02 00 00    	je     9dc0 <fwp_main_thread+0x420>
    9bbf:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9bc6:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9bcd:	48 85 d2             	test   %rdx,%rdx
    9bd0:	0f 84 fa 03 00 00    	je     9fd0 <fwp_main_thread+0x630>
    9bd6:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9bdd:	48 85 c0             	test   %rax,%rax
    9be0:	74 07                	je     9be9 <fwp_main_thread+0x249>
    9be2:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9be9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9bed:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9bf1:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    9bf8:	48 89 cb             	mov    %rcx,%rbx
    9bfb:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9c00:	0f 85 bf fe ff ff    	jne    9ac5 <fwp_main_thread+0x125>
    9c06:	48 83 3d 82 57 01 00 	cmpq   $0x0,0x15782(%rip)        # 1f390 <fwp_state_len>
    9c0d:	00 
    9c0e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9c12:	0f 84 ba 00 00 00    	je     9cd2 <fwp_main_thread+0x332>
    9c18:	48 39 1d d9 3a 01 00 	cmp    %rbx,0x13ad9(%rip)        # 1d6f8 <fwp_root>
    9c1f:	c7 05 97 34 01 00 00 	movl   $0x0,0x13497(%rip)        # 1d0c0 <fwp_exit_code>
    9c26:	00 00 00 
    9c29:	0f 85 5f 04 00 00    	jne    a08e <fwp_main_thread+0x6ee>
    9c2f:	48 85 db             	test   %rbx,%rbx
    9c32:	0f 84 0e 02 00 00    	je     9e46 <fwp_main_thread+0x4a6>
    9c38:	48 8b 15 89 3a 01 00 	mov    0x13a89(%rip),%rdx        # 1d6c8 <fwp_tasks_active>
    9c3f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9c43:	48 85 d2             	test   %rdx,%rdx
    9c46:	0f 84 fa 01 00 00    	je     9e46 <fwp_main_thread+0x4a6>
    9c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c50:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9c54:	75 08                	jne    9c5e <fwp_main_thread+0x2be>
    9c56:	48 89 d7             	mov    %rdx,%rdi
    9c59:	e8 62 93 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    9c5e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9c65:	48 85 d2             	test   %rdx,%rdx
    9c68:	75 e6                	jne    9c50 <fwp_main_thread+0x2b0>
    9c6a:	eb 31                	jmp    9c9d <fwp_main_thread+0x2fd>
    9c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c70:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9c77:	48 89 1d 62 3a 01 00 	mov    %rbx,0x13a62(%rip)        # 1d6e0 <fwp_ready_tail>
    9c7e:	e8 cd ae ff ff       	call   4b50 <fwp_block>
    9c83:	e8 c8 ac ff ff       	call   4950 <fwp_free_zombie>
    9c88:	48 83 3d 38 3a 01 00 	cmpq   $0x0,0x13a38(%rip)        # 1d6c8 <fwp_tasks_active>
    9c8f:	00 
    9c90:	0f 84 b0 01 00 00    	je     9e46 <fwp_main_thread+0x4a6>
    9c96:	48 8b 1d 5b 3a 01 00 	mov    0x13a5b(%rip),%rbx        # 1d6f8 <fwp_root>
    9c9d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9ca1:	75 db                	jne    9c7e <fwp_main_thread+0x2de>
    9ca3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9ca7:	75 d5                	jne    9c7e <fwp_main_thread+0x2de>
    9ca9:	48 8b 05 30 3a 01 00 	mov    0x13a30(%rip),%rax        # 1d6e0 <fwp_ready_tail>
    9cb0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9cb4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9cbb:	00 00 00 00 
    9cbf:	48 85 c0             	test   %rax,%rax
    9cc2:	75 ac                	jne    9c70 <fwp_main_thread+0x2d0>
    9cc4:	48 89 1d 1d 3a 01 00 	mov    %rbx,0x13a1d(%rip)        # 1d6e8 <fwp_ready_head>
    9ccb:	eb aa                	jmp    9c77 <fwp_main_thread+0x2d7>
    9ccd:	0f 1f 00             	nopl   (%rax)
    9cd0:	31 db                	xor    %ebx,%ebx
    9cd2:	48 83 3d a6 56 01 00 	cmpq   $0x0,0x156a6(%rip)        # 1f380 <fwp_state_owners>
    9cd9:	00 
    9cda:	0f 85 38 ff ff ff    	jne    9c18 <fwp_main_thread+0x278>
    9ce0:	48 8b 3d b1 56 01 00 	mov    0x156b1(%rip),%rdi        # 1f398 <fwp_state>
    9ce7:	e8 e4 a2 ff ff       	call   3fd0 <fwp_mem_free>
    9cec:	48 c7 05 a1 56 01 00 	movq   $0x0,0x156a1(%rip)        # 1f398 <fwp_state>
    9cf3:	00 00 00 00 
    9cf7:	48 c7 05 86 56 01 00 	movq   $0x0,0x15686(%rip)        # 1f388 <fwp_state_cap>
    9cfe:	00 00 00 00 
    9d02:	48 85 db             	test   %rbx,%rbx
    9d05:	0f 84 46 03 00 00    	je     a051 <fwp_main_thread+0x6b1>
    9d0b:	48 39 1d e6 39 01 00 	cmp    %rbx,0x139e6(%rip)        # 1d6f8 <fwp_root>
    9d12:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9d19:	00 00 00 00 
    9d1d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9d24:	00 00 00 00 
    9d28:	c7 05 8e 33 01 00 00 	movl   $0x0,0x1338e(%rip)        # 1d0c0 <fwp_exit_code>
    9d2f:	00 00 00 
    9d32:	0f 84 00 ff ff ff    	je     9c38 <fwp_main_thread+0x298>
    9d38:	e9 d3 89 ff ff       	jmp    2710 <fwp_main_thread.cold>
    9d3d:	0f 1f 00             	nopl   (%rax)
    9d40:	e8 9b 93 ff ff       	call   30e0 <fwp_now_ns>
    9d45:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9d49:	0f 8d 91 02 00 00    	jge    9fe0 <fwp_main_thread+0x640>
    9d4f:	90                   	nop
    9d50:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9d54:	0f 85 80 fd ff ff    	jne    9ada <fwp_main_thread+0x13a>
    9d5a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9d5e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9d62:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9d66:	0f 85 80 fd ff ff    	jne    9aec <fwp_main_thread+0x14c>
    9d6c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9d70:	48 85 c9             	test   %rcx,%rcx
    9d73:	0f 84 73 fd ff ff    	je     9aec <fwp_main_thread+0x14c>
    9d79:	48 85 c0             	test   %rax,%rax
    9d7c:	0f 84 ff 02 00 00    	je     a081 <fwp_main_thread+0x6e1>
    9d82:	48 39 c8             	cmp    %rcx,%rax
    9d85:	48 0f 4f c1          	cmovg  %rcx,%rax
    9d89:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9d90:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9d94:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9d9b:	00 00 00 00 
    9d9f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9da6:	48 85 d2             	test   %rdx,%rdx
    9da9:	74 07                	je     9db2 <fwp_main_thread+0x412>
    9dab:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9db2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9db6:	e9 63 fd ff ff       	jmp    9b1e <fwp_main_thread+0x17e>
    9dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9dc0:	48 89 cb             	mov    %rcx,%rbx
    9dc3:	e9 f2 fc ff ff       	jmp    9aba <fwp_main_thread+0x11a>
    9dc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9dcf:	00 
    9dd0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9dd4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9ddb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9de2:	00 00 00 00 
    9de6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9ded:	48 85 c0             	test   %rax,%rax
    9df0:	0f 84 52 02 00 00    	je     a048 <fwp_main_thread+0x6a8>
    9df6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9dfd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e01:	e9 4c fd ff ff       	jmp    9b52 <fwp_main_thread+0x1b2>
    9e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e0d:	00 00 00 
    9e10:	48 89 01             	mov    %rax,(%rcx)
    9e13:	e9 74 fd ff ff       	jmp    9b8c <fwp_main_thread+0x1ec>
    9e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e1f:	00 
    9e20:	48 83 3d 68 55 01 00 	cmpq   $0x0,0x15568(%rip)        # 1f390 <fwp_state_len>
    9e27:	00 
    9e28:	0f 84 a2 fe ff ff    	je     9cd0 <fwp_main_thread+0x330>
    9e2e:	48 83 3d c2 38 01 00 	cmpq   $0x0,0x138c2(%rip)        # 1d6f8 <fwp_root>
    9e35:	00 
    9e36:	c7 05 80 32 01 00 00 	movl   $0x0,0x13280(%rip)        # 1d0c0 <fwp_exit_code>
    9e3d:	00 00 00 
    9e40:	0f 85 43 02 00 00    	jne    a089 <fwp_main_thread+0x6e9>
    9e46:	e8 05 ab ff ff       	call   4950 <fwp_free_zombie>
    9e4b:	48 83 3d 95 38 01 00 	cmpq   $0x0,0x13895(%rip)        # 1d6e8 <fwp_ready_head>
    9e52:	00 
    9e53:	0f 85 b7 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9e59:	48 83 3d 77 38 01 00 	cmpq   $0x0,0x13877(%rip)        # 1d6d8 <fwp_timers>
    9e60:	00 
    9e61:	0f 85 a9 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9e67:	8b 1d 6f 32 01 00    	mov    0x1326f(%rip),%ebx        # 1d0dc <fwp_stack_pool_n>
    9e6d:	85 db                	test   %ebx,%ebx
    9e6f:	74 36                	je     9ea7 <fwp_main_thread+0x507>
    9e71:	83 eb 01             	sub    $0x1,%ebx
    9e74:	48 8d 05 65 32 01 00 	lea    0x13265(%rip),%rax        # 1d0e0 <fwp_stack_pool>
    9e7b:	48 63 d3             	movslq %ebx,%rdx
    9e7e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    9e82:	eb 07                	jmp    9e8b <fwp_main_thread+0x4eb>
    9e84:	0f 1f 40 00          	nopl   0x0(%rax)
    9e88:	83 eb 01             	sub    $0x1,%ebx
    9e8b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9e8f:	be 00 00 00 10       	mov    $0x10000000,%esi
    9e94:	89 1d 42 32 01 00    	mov    %ebx,0x13242(%rip)        # 1d0dc <fwp_stack_pool_n>
    9e9a:	48 83 ed 08          	sub    $0x8,%rbp
    9e9e:	e8 0d 87 ff ff       	call   25b0 <munmap@plt>
    9ea3:	85 db                	test   %ebx,%ebx
    9ea5:	75 e1                	jne    9e88 <fwp_main_thread+0x4e8>
    9ea7:	8b 3d a3 31 00 00    	mov    0x31a3(%rip),%edi        # d050 <fwp_epfd>
    9ead:	85 ff                	test   %edi,%edi
    9eaf:	78 05                	js     9eb6 <fwp_main_thread+0x516>
    9eb1:	e8 fa 85 ff ff       	call   24b0 <close@plt>
    9eb6:	4c 8b 25 23 34 01 00 	mov    0x13423(%rip),%r12        # 1d2e0 <fwp_nfdws>
    9ebd:	48 8b 2d 24 34 01 00 	mov    0x13424(%rip),%rbp        # 1d2e8 <fwp_fdws>
    9ec4:	31 db                	xor    %ebx,%ebx
    9ec6:	c7 05 80 31 00 00 ff 	movl   $0xffffffff,0x3180(%rip)        # d050 <fwp_epfd>
    9ecd:	ff ff ff 
    9ed0:	4d 85 e4             	test   %r12,%r12
    9ed3:	74 38                	je     9f0d <fwp_main_thread+0x56d>
    9ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9edc:	00 00 00 00 
    9ee0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9ee5:	48 85 ff             	test   %rdi,%rdi
    9ee8:	74 1a                	je     9f04 <fwp_main_thread+0x564>
    9eea:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9eee:	0f 85 1c 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9ef4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9ef9:	0f 85 11 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9eff:	e8 cc a0 ff ff       	call   3fd0 <fwp_mem_free>
    9f04:	48 83 c3 01          	add    $0x1,%rbx
    9f08:	4c 39 e3             	cmp    %r12,%rbx
    9f0b:	75 d3                	jne    9ee0 <fwp_main_thread+0x540>
    9f0d:	48 89 ef             	mov    %rbp,%rdi
    9f10:	e8 bb a0 ff ff       	call   3fd0 <fwp_mem_free>
    9f15:	48 8b 15 dc 37 01 00 	mov    0x137dc(%rip),%rdx        # 1d6f8 <fwp_root>
    9f1c:	48 c7 05 c1 33 01 00 	movq   $0x0,0x133c1(%rip)        # 1d2e8 <fwp_fdws>
    9f23:	00 00 00 00 
    9f27:	48 c7 05 ae 33 01 00 	movq   $0x0,0x133ae(%rip)        # 1d2e0 <fwp_nfdws>
    9f2e:	00 00 00 00 
    9f32:	48 85 d2             	test   %rdx,%rdx
    9f35:	74 4e                	je     9f85 <fwp_main_thread+0x5e5>
    9f37:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9f3c:	0f 85 ce 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f42:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9f49:	00 
    9f4a:	0f 85 c0 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f50:	48 83 3d 38 54 01 00 	cmpq   $0x0,0x15438(%rip)        # 1f390 <fwp_state_len>
    9f57:	00 
    9f58:	0f 85 b2 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f5e:	48 83 3d 1a 54 01 00 	cmpq   $0x0,0x1541a(%rip)        # 1f380 <fwp_state_owners>
    9f65:	00 
    9f66:	0f 85 a4 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f6c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9f71:	31 c0                	xor    %eax,%eax
    9f73:	48 8d 3d 86 33 01 00 	lea    0x13386(%rip),%rdi        # 1d300 <fwp_root_context>
    9f7a:	f3 48 ab             	rep stos %rax,(%rdi)
    9f7d:	48 89 d7             	mov    %rdx,%rdi
    9f80:	e8 4b a0 ff ff       	call   3fd0 <fwp_mem_free>
    9f85:	48 8b 3d d4 30 00 00 	mov    0x30d4(%rip),%rdi        # d060 <stdout@GLIBC_2.2.5>
    9f8c:	48 c7 05 69 37 01 00 	movq   $0x0,0x13769(%rip)        # 1d700 <fwp_cur>
    9f93:	00 00 00 00 
    9f97:	48 c7 05 56 37 01 00 	movq   $0x0,0x13756(%rip)        # 1d6f8 <fwp_root>
    9f9e:	00 00 00 00 
    9fa2:	e8 e9 85 ff ff       	call   2590 <fflush@plt>
    9fa7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    9fae:	00 
    9faf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fb6:	00 00 
    9fb8:	0f 85 be 00 00 00    	jne    a07c <fwp_main_thread+0x6dc>
    9fbe:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    9fc5:	31 c0                	xor    %eax,%eax
    9fc7:	5b                   	pop    %rbx
    9fc8:	5d                   	pop    %rbp
    9fc9:	41 5c                	pop    %r12
    9fcb:	c3                   	ret
    9fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fd0:	48 89 05 01 37 01 00 	mov    %rax,0x13701(%rip)        # 1d6d8 <fwp_timers>
    9fd7:	e9 01 fc ff ff       	jmp    9bdd <fwp_main_thread+0x23d>
    9fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fe0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9fe4:	0f 85 66 fd ff ff    	jne    9d50 <fwp_main_thread+0x3b0>
    9fea:	48 89 ef             	mov    %rbp,%rdi
    9fed:	e8 ce 8f ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    9ff2:	e9 59 fd ff ff       	jmp    9d50 <fwp_main_thread+0x3b0>
    9ff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ffe:	00 00 
    a000:	e8 2b cf ff ff       	call   6f30 <f0>
    a005:	48 c7 05 90 30 00 00 	movq   $0x0,0x3090(%rip)        # d0a0 <v.1>
    a00c:	00 00 00 00 
    a010:	c7 05 8e 30 00 00 01 	movl   $0x1,0x308e(%rip)        # d0a8 <st.2>
    a017:	00 00 00 
    a01a:	e9 7f fa ff ff       	jmp    9a9e <fwp_main_thread+0xfe>
    a01f:	90                   	nop
    a020:	48 8d 3d b9 96 ff ff 	lea    -0x6947(%rip),%rdi        # 36e0 <fwp_heap_report>
    a027:	e8 84 02 00 00       	call   a2b0 <atexit>
    a02c:	e9 ad f9 ff ff       	jmp    99de <fwp_main_thread+0x3e>
    a031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a038:	e8 b3 97 ff ff       	call   37f0 <fwp_heap_init>
    a03d:	e9 8e f9 ff ff       	jmp    99d0 <fwp_main_thread+0x30>
    a042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a048:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a04c:	e9 01 fb ff ff       	jmp    9b52 <fwp_main_thread+0x1b2>
    a051:	48 83 3d 9f 36 01 00 	cmpq   $0x0,0x1369f(%rip)        # 1d6f8 <fwp_root>
    a058:	00 
    a059:	c7 05 5d 30 01 00 00 	movl   $0x0,0x1305d(%rip)        # 1d0c0 <fwp_exit_code>
    a060:	00 00 00 
    a063:	0f 84 dd fd ff ff    	je     9e46 <fwp_main_thread+0x4a6>
    a069:	e9 a2 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a06e:	66 90                	xchg   %ax,%ax
    a070:	48 8d 3d 89 12 00 00 	lea    0x1289(%rip),%rdi        # b300 <_IO_stdin_used+0x300>
    a077:	e8 34 90 ff ff       	call   30b0 <fwp_trap>
    a07c:	e8 bf 83 ff ff       	call   2440 <__stack_chk_fail@plt>
    a081:	48 89 c8             	mov    %rcx,%rax
    a084:	e9 00 fd ff ff       	jmp    9d89 <fwp_main_thread+0x3e9>
    a089:	e9 82 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a08e:	e9 7d 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a093:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a09a:	00 00 00 
    a09d:	0f 1f 00             	nopl   (%rax)

000000000000a0a0 <__divmodti4>:
    a0a0:	f3 0f 1e fa          	endbr64
    a0a4:	55                   	push   %rbp
    a0a5:	49 89 f1             	mov    %rsi,%r9
    a0a8:	49 89 d2             	mov    %rdx,%r10
    a0ab:	48 89 fe             	mov    %rdi,%rsi
    a0ae:	49 89 cb             	mov    %rcx,%r11
    a0b1:	48 89 e5             	mov    %rsp,%rbp
    a0b4:	41 57                	push   %r15
    a0b6:	41 56                	push   %r14
    a0b8:	41 55                	push   %r13
    a0ba:	41 54                	push   %r12
    a0bc:	53                   	push   %rbx
    a0bd:	4c 89 c3             	mov    %r8,%rbx
    a0c0:	45 31 c0             	xor    %r8d,%r8d
    a0c3:	4d 85 c9             	test   %r9,%r9
    a0c6:	79 12                	jns    a0da <__divmodti4+0x3a>
    a0c8:	31 ff                	xor    %edi,%edi
    a0ca:	48 f7 de             	neg    %rsi
    a0cd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a0d4:	4c 19 cf             	sbb    %r9,%rdi
    a0d7:	49 89 f9             	mov    %rdi,%r9
    a0da:	4c 89 d8             	mov    %r11,%rax
    a0dd:	4d 85 db             	test   %r11,%r11
    a0e0:	0f 88 1a 01 00 00    	js     a200 <__divmodti4+0x160>
    a0e6:	4c 89 d9             	mov    %r11,%rcx
    a0e9:	49 89 f3             	mov    %rsi,%r11
    a0ec:	75 62                	jne    a150 <__divmodti4+0xb0>
    a0ee:	4d 89 c4             	mov    %r8,%r12
    a0f1:	4d 39 d1             	cmp    %r10,%r9
    a0f4:	0f 83 46 01 00 00    	jae    a240 <__divmodti4+0x1a0>
    a0fa:	4c 89 d8             	mov    %r11,%rax
    a0fd:	4c 89 ca             	mov    %r9,%rdx
    a100:	49 f7 f2             	div    %r10
    a103:	49 89 c3             	mov    %rax,%r11
    a106:	31 c0                	xor    %eax,%eax
    a108:	48 89 d6             	mov    %rdx,%rsi
    a10b:	31 ff                	xor    %edi,%edi
    a10d:	4c 89 d9             	mov    %r11,%rcx
    a110:	48 89 c2             	mov    %rax,%rdx
    a113:	48 89 c8             	mov    %rcx,%rax
    a116:	4d 85 e4             	test   %r12,%r12
    a119:	74 0a                	je     a125 <__divmodti4+0x85>
    a11b:	48 f7 d8             	neg    %rax
    a11e:	48 83 d2 00          	adc    $0x0,%rdx
    a122:	48 f7 da             	neg    %rdx
    a125:	4d 85 c0             	test   %r8,%r8
    a128:	74 0a                	je     a134 <__divmodti4+0x94>
    a12a:	48 f7 de             	neg    %rsi
    a12d:	48 83 d7 00          	adc    $0x0,%rdi
    a131:	48 f7 df             	neg    %rdi
    a134:	48 89 33             	mov    %rsi,(%rbx)
    a137:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a13b:	5b                   	pop    %rbx
    a13c:	41 5c                	pop    %r12
    a13e:	41 5d                	pop    %r13
    a140:	41 5e                	pop    %r14
    a142:	41 5f                	pop    %r15
    a144:	5d                   	pop    %rbp
    a145:	c3                   	ret
    a146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a14d:	00 00 00 
    a150:	4d 89 c4             	mov    %r8,%r12
    a153:	49 39 c1             	cmp    %rax,%r9
    a156:	0f 82 ce 00 00 00    	jb     a22a <__divmodti4+0x18a>
    a15c:	31 ff                	xor    %edi,%edi
    a15e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a163:	48 63 c7             	movslq %edi,%rax
    a166:	be 40 00 00 00       	mov    $0x40,%esi
    a16b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a170:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a175:	48 29 c6             	sub    %rax,%rsi
    a178:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a17d:	48 09 c8             	or     %rcx,%rax
    a180:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a185:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a18a:	49 89 c6             	mov    %rax,%r14
    a18d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a191:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a196:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a19b:	49 09 c1             	or     %rax,%r9
    a19e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a1a2:	4c 89 c8             	mov    %r9,%rax
    a1a5:	49 f7 f6             	div    %r14
    a1a8:	48 89 d1             	mov    %rdx,%rcx
    a1ab:	49 89 c3             	mov    %rax,%r11
    a1ae:	49 89 c1             	mov    %rax,%r9
    a1b1:	49 f7 e2             	mul    %r10
    a1b4:	49 89 c6             	mov    %rax,%r14
    a1b7:	49 89 d2             	mov    %rdx,%r10
    a1ba:	48 39 d1             	cmp    %rdx,%rcx
    a1bd:	72 07                	jb     a1c6 <__divmodti4+0x126>
    a1bf:	75 17                	jne    a1d8 <__divmodti4+0x138>
    a1c1:	49 39 c7             	cmp    %rax,%r15
    a1c4:	73 12                	jae    a1d8 <__divmodti4+0x138>
    a1c6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a1ca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a1ce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a1d2:	49 89 d2             	mov    %rdx,%r10
    a1d5:	49 89 c6             	mov    %rax,%r14
    a1d8:	4c 89 f8             	mov    %r15,%rax
    a1db:	4c 29 f0             	sub    %r14,%rax
    a1de:	4c 19 d1             	sbb    %r10,%rcx
    a1e1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a1e6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a1eb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a1f0:	48 09 c6             	or     %rax,%rsi
    a1f3:	48 89 cf             	mov    %rcx,%rdi
    a1f6:	31 c0                	xor    %eax,%eax
    a1f8:	4c 89 c9             	mov    %r9,%rcx
    a1fb:	e9 10 ff ff ff       	jmp    a110 <__divmodti4+0x70>
    a200:	4c 89 d0             	mov    %r10,%rax
    a203:	4c 89 da             	mov    %r11,%rdx
    a206:	4d 89 c4             	mov    %r8,%r12
    a209:	49 89 f3             	mov    %rsi,%r11
    a20c:	48 f7 d8             	neg    %rax
    a20f:	49 f7 d4             	not    %r12
    a212:	48 83 d2 00          	adc    $0x0,%rdx
    a216:	49 89 c2             	mov    %rax,%r10
    a219:	48 f7 da             	neg    %rdx
    a21c:	48 89 d1             	mov    %rdx,%rcx
    a21f:	0f 84 cc fe ff ff    	je     a0f1 <__divmodti4+0x51>
    a225:	49 39 d1             	cmp    %rdx,%r9
    a228:	73 46                	jae    a270 <__divmodti4+0x1d0>
    a22a:	4c 89 cf             	mov    %r9,%rdi
    a22d:	31 c0                	xor    %eax,%eax
    a22f:	31 c9                	xor    %ecx,%ecx
    a231:	e9 da fe ff ff       	jmp    a110 <__divmodti4+0x70>
    a236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a23d:	00 00 00 
    a240:	4d 85 d2             	test   %r10,%r10
    a243:	75 0d                	jne    a252 <__divmodti4+0x1b2>
    a245:	b8 01 00 00 00       	mov    $0x1,%eax
    a24a:	31 d2                	xor    %edx,%edx
    a24c:	49 f7 f2             	div    %r10
    a24f:	49 89 c2             	mov    %rax,%r10
    a252:	4c 89 c8             	mov    %r9,%rax
    a255:	31 d2                	xor    %edx,%edx
    a257:	49 f7 f2             	div    %r10
    a25a:	49 89 c1             	mov    %rax,%r9
    a25d:	4c 89 d8             	mov    %r11,%rax
    a260:	49 f7 f2             	div    %r10
    a263:	49 89 c3             	mov    %rax,%r11
    a266:	4c 89 c8             	mov    %r9,%rax
    a269:	e9 9a fe ff ff       	jmp    a108 <__divmodti4+0x68>
    a26e:	66 90                	xchg   %ax,%ax
    a270:	45 31 f6             	xor    %r14d,%r14d
    a273:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a278:	44 89 f7             	mov    %r14d,%edi
    a27b:	45 85 f6             	test   %r14d,%r14d
    a27e:	0f 85 df fe ff ff    	jne    a163 <__divmodti4+0xc3>
    a284:	4c 39 ca             	cmp    %r9,%rdx
    a287:	72 17                	jb     a2a0 <__divmodti4+0x200>
    a289:	31 c9                	xor    %ecx,%ecx
    a28b:	48 39 c6             	cmp    %rax,%rsi
    a28e:	73 10                	jae    a2a0 <__divmodti4+0x200>
    a290:	4c 89 cf             	mov    %r9,%rdi
    a293:	31 c0                	xor    %eax,%eax
    a295:	e9 76 fe ff ff       	jmp    a110 <__divmodti4+0x70>
    a29a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2a0:	4c 89 de             	mov    %r11,%rsi
    a2a3:	b9 01 00 00 00       	mov    $0x1,%ecx
    a2a8:	48 29 c6             	sub    %rax,%rsi
    a2ab:	49 19 d1             	sbb    %rdx,%r9
    a2ae:	eb e0                	jmp    a290 <__divmodti4+0x1f0>

000000000000a2b0 <atexit>:
    a2b0:	f3 0f 1e fa          	endbr64
    a2b4:	48 8b 15 4d 2d 00 00 	mov    0x2d4d(%rip),%rdx        # d008 <__dso_handle>
    a2bb:	31 f6                	xor    %esi,%esi
    a2bd:	e9 5e 83 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a2c4 <_fini>:
    a2c4:	f3 0f 1e fa          	endbr64
    a2c8:	48 83 ec 08          	sub    $0x8,%rsp
    a2cc:	48 83 c4 08          	add    $0x8,%rsp
    a2d0:	c3                   	ret
