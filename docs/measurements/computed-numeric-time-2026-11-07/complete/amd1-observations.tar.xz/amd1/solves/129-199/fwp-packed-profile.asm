
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-packed-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # dfd8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # de18 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # de20 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 6e bc 00 00    	jmp    *0xbc6e(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 9e ba 00 00    	jmp    *0xba9e(%rip)        # de28 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 96 ba 00 00    	jmp    *0xba96(%rip)        # de30 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # de38 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # de40 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # de48 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # de50 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # de58 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # de60 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # de68 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # de70 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # de78 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # de80 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # de88 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # de90 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # de98 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # dea0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # dea8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # deb0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # deb8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # dec0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # dec8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ded0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ded8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # dee0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # dee8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # def0 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # def8 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # df00 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # df08 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # df10 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # df18 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # df20 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # df28 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # df30 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # df38 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # df40 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # df48 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # df50 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # df58 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # df60 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # df68 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # df70 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # df78 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # df80 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # df88 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # df90 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # df98 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # dfa0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # dfa8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # dfb0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # dfb8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # dfc0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 89 00 00 	lea    0x89e0(%rip),%r9        # b0b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 89 00 00 	lea    0x89dd(%rip),%r8        # b0bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 fa 0a 00 00       	call   3200 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 21 b9 00 00 	mov    0xb921(%rip),%rax        # e060 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 52 dc 01 00 	mov    %rax,0x1dc52(%rip)        # 20398 <fwp_prog_out>
    2746:	e8 e5 0a 00 00       	call   3230 <fwp_now_ns>
    274b:	48 8d 3d 77 8a 00 00 	lea    0x8a77(%rip),%rdi        # b1c9 <_IO_stdin_used+0x1c9>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d a6 b8 00 00 	mov    0xb8a6(%rip),%rdi        # e060 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 6d 74 00 00 	lea    0x746d(%rip),%rdx        # 9c80 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 11 b8 00 00 	mov    0xb811(%rip),%rdi        # e060 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 66 b8 01 00    	mov    0x1b866(%rip),%eax        # 1e0c0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 27 89 00 00 	lea    0x8927(%rip),%rdi        # b1d2 <_IO_stdin_used+0x1d2>
    28ab:	e8 50 09 00 00       	call   3200 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 74 8c 00 00 	lea    0x8c74(%rip),%rdi        # b530 <_IO_stdin_used+0x530>
    28bc:	e8 3f 09 00 00       	call   3200 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d 2e 8c 00 00 	lea    0x8c2e(%rip),%rdi        # b508 <_IO_stdin_used+0x508>
    28da:	e8 21 09 00 00       	call   3200 <fwp_trap>
    28df:	48 8d 3d f2 8b 00 00 	lea    0x8bf2(%rip),%rdi        # b4d8 <_IO_stdin_used+0x4d8>
    28e6:	e8 15 09 00 00       	call   3200 <fwp_trap>
    28eb:	48 8d 3d be 8b 00 00 	lea    0x8bbe(%rip),%rdi        # b4b0 <_IO_stdin_used+0x4b0>
    28f2:	e8 09 09 00 00       	call   3200 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 a3 b6 00 00    	call   *0xb6a3(%rip)        # dfc8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 21 b7 00 00 	lea    0xb721(%rip),%rdi        # e058 <__TMC_END__>
    2937:	48 8d 05 1a b7 00 00 	lea    0xb71a(%rip),%rax        # e058 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 86 b6 00 00 	mov    0xb686(%rip),%rax        # dfd0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d f1 b6 00 00 	lea    0xb6f1(%rip),%rdi        # e058 <__TMC_END__>
    2967:	48 8d 35 ea b6 00 00 	lea    0xb6ea(%rip),%rsi        # e058 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 55 b6 00 00 	mov    0xb655(%rip),%rax        # dfe0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d dd b6 00 00 00 	cmpb   $0x0,0xb6dd(%rip)        # e088 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 32 b6 00 00 	cmpq   $0x0,0xb632(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 b6 00 00 	mov    0xb646(%rip),%rdi        # e008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 b5 b6 00 00 01 	movb   $0x1,0xb6b5(%rip)        # e088 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d d1 d7 01 00 	mov    0x1d7d1(%rip),%rdi        # 20398 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d 84 b4 00 00 	mov    0xb484(%rip),%rdi        # e060 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 71 b4 00 00 	mov    0xb471(%rip),%rdi        # e060 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_segv>:
    2c00:	f3 0f 1e fa          	endbr64
    2c04:	48 83 ec 28          	sub    $0x28,%rsp
    2c08:	48 8b 05 11 bb 01 00 	mov    0x1bb11(%rip),%rax        # 1e720 <fwp_cur>
    2c0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c13:	41 89 f8             	mov    %edi,%r8d
    2c16:	48 85 c0             	test   %rax,%rax
    2c19:	74 6d                	je     2c88 <fwp_segv+0x88>
    2c1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c1f:	48 85 d2             	test   %rdx,%rdx
    2c22:	74 64                	je     2c88 <fwp_segv+0x88>
    2c24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c37:	e8 c4 f9 ff ff       	call   2600 <sysconf@plt>
    2c3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c4b:	48 01 d0             	add    %rdx,%rax
    2c4e:	48 39 c1             	cmp    %rax,%rcx
    2c51:	b8 00 00 00 00       	mov    $0x0,%eax
    2c56:	40 0f 92 c6          	setb   %sil
    2c5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2c61:	48 0f 42 d0          	cmovb  %rax,%rdx
    2c65:	31 c0                	xor    %eax,%eax
    2c67:	48 39 d1             	cmp    %rdx,%rcx
    2c6a:	0f 93 c0             	setae  %al
    2c6d:	21 f0                	and    %esi,%eax
    2c6f:	85 c0                	test   %eax,%eax
    2c71:	75 4a                	jne    2cbd <fwp_segv+0xbd>
    2c73:	31 f6                	xor    %esi,%esi
    2c75:	44 89 c7             	mov    %r8d,%edi
    2c78:	48 83 c4 28          	add    $0x28,%rsp
    2c7c:	e9 9f f8 ff ff       	jmp    2520 <signal@plt>
    2c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2c88:	48 8b 05 49 b4 01 00 	mov    0x1b449(%rip),%rax        # 1e0d8 <fwp_main_stack_top>
    2c8f:	48 85 c0             	test   %rax,%rax
    2c92:	74 df                	je     2c73 <fwp_segv+0x73>
    2c94:	48 2b 05 35 b4 01 00 	sub    0x1b435(%rip),%rax        # 1e0d0 <fwp_main_stack_size>
    2c9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ca2:	48 39 d1             	cmp    %rdx,%rcx
    2ca5:	0f 93 c2             	setae  %dl
    2ca8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cae:	48 39 c1             	cmp    %rax,%rcx
    2cb1:	0f 92 c0             	setb   %al
    2cb4:	0f b6 c0             	movzbl %al,%eax
    2cb7:	21 d0                	and    %edx,%eax
    2cb9:	85 c0                	test   %eax,%eax
    2cbb:	74 b6                	je     2c73 <fwp_segv+0x73>
    2cbd:	e8 fe fe ff ff       	call   2bc0 <fwp_flush>
    2cc2:	bf 02 00 00 00       	mov    $0x2,%edi
    2cc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2ccc:	48 8d 35 fd 88 00 00 	lea    0x88fd(%rip),%rsi        # b5d0 <msg.3>
    2cd3:	e8 38 f7 ff ff       	call   2410 <write@plt>
    2cd8:	bf 65 00 00 00       	mov    $0x65,%edi
    2cdd:	e8 de f6 ff ff       	call   23c0 <_exit@plt>
    2ce2:	0f 1f 00             	nopl   (%rax)
    2ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cec:	00 00 00 00 

0000000000002cf0 <fwp_heap_oom>:
    2cf0:	50                   	push   %rax
    2cf1:	58                   	pop    %rax
    2cf2:	ba 13 00 00 00       	mov    $0x13,%edx
    2cf7:	be 01 00 00 00       	mov    $0x1,%esi
    2cfc:	48 8d 3d 05 83 00 00 	lea    0x8305(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2d03:	48 83 ec 08          	sub    $0x8,%rsp
    2d07:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # e080 <stderr@GLIBC_2.2.5>
    2d0e:	e8 2d f9 ff ff       	call   2640 <fwrite@plt>
    2d13:	31 ff                	xor    %edi,%edi
    2d15:	e8 76 f8 ff ff       	call   2590 <fflush@plt>
    2d1a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d1f:	e8 3c f9 ff ff       	call   2660 <_Exit@plt>
    2d24:	90                   	nop
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 eb cd 01 00 	mov    0x1cdeb(%rip),%rax        # 1fb30 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 e4 cd 01 00 	lea    0x1cde4(%rip),%r8        # 1fb30 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d c5 cd 01 00 	mov    0x1cdc5(%rip),%rbx        # 1fb18 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d d5 cd 01 00 	mov    0x1cdd5(%rip),%rcx        # 1fb38 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 71 cd 01 00 	mov    0x1cd71(%rip),%rdi        # 1fb20 <fwp_heap+0x13e0>
    2daf:	48 29 35 ba cd 01 00 	sub    %rsi,0x1cdba(%rip)        # 1fb70 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 4a cd 01 00 	mov    0x1cd4a(%rip),%rax        # 1fb10 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 00 cd 01 00 	add    0x1cd00(%rip),%rdi        # 1faf0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 0e cd 01 00 	mov    0x1cd0e(%rip),%rsi        # 1fb20 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 1c cd 01 00 	mov    0x1cd1c(%rip),%rax        # 1fb38 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 cb cc 01 00 	mov    %r12,0x1cccb(%rip)        # 1fb20 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d b9 cc 01 00 	mov    %rbp,0x1ccb9(%rip)        # 1fb18 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 9e cc 01 00 	cmp    %rdi,0x1cc9e(%rip)        # 1fb08 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 95 cc 01 00 	mov    %rdi,0x1cc95(%rip)        # 1fb08 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d d9 cc 01 00 	sub    %rdi,0x1ccd9(%rip)        # 1fb70 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 81 cc 01 00 	mov    0x1cc81(%rip),%rax        # 1fb28 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 7a cc 01 00 	lea    0x1cc7a(%rip),%r8        # 1fb28 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 31 fe ff ff       	call   2cf0 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <ad_raw_fail>:
    2ec0:	50                   	push   %rax
    2ec1:	58                   	pop    %rax
    2ec2:	48 8d 15 2f 83 00 00 	lea    0x832f(%rip),%rdx        # b1f8 <_IO_stdin_used+0x1f8>
    2ec9:	be 02 00 00 00       	mov    $0x2,%esi
    2ece:	31 c0                	xor    %eax,%eax
    2ed0:	48 83 ec 08          	sub    $0x8,%rsp
    2ed4:	48 89 f9             	mov    %rdi,%rcx
    2ed7:	48 8b 3d a2 b1 00 00 	mov    0xb1a2(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    2ede:	e8 6d f7 ff ff       	call   2650 <__fprintf_chk@plt>
    2ee3:	bf e8 00 00 00       	mov    $0xe8,%edi
    2ee8:	e8 43 f7 ff ff       	call   2630 <exit@plt>
    2eed:	0f 1f 00             	nopl   (%rax)

0000000000002ef0 <buf_grow>:
    2ef0:	48 83 ec 18          	sub    $0x18,%rsp
    2ef4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ef8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2efc:	74 7e                	je     2f7c <buf_grow+0x8c>
    2efe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f05:	48 29 c2             	sub    %rax,%rdx
    2f08:	48 39 f2             	cmp    %rsi,%rdx
    2f0b:	72 6f                	jb     2f7c <buf_grow+0x8c>
    2f0d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f12:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f16:	48 89 f9             	mov    %rdi,%rcx
    2f19:	48 39 d0             	cmp    %rdx,%rax
    2f1c:	73 48                	jae    2f66 <buf_grow+0x76>
    2f1e:	48 85 c0             	test   %rax,%rax
    2f21:	75 15                	jne    2f38 <buf_grow+0x48>
    2f23:	48 83 fa 40          	cmp    $0x40,%rdx
    2f27:	76 4c                	jbe    2f75 <buf_grow+0x85>
    2f29:	b8 40 00 00 00       	mov    $0x40,%eax
    2f2e:	eb 08                	jmp    2f38 <buf_grow+0x48>
    2f30:	48 01 c0             	add    %rax,%rax
    2f33:	48 39 d0             	cmp    %rdx,%rax
    2f36:	73 38                	jae    2f70 <buf_grow+0x80>
    2f38:	48 85 c0             	test   %rax,%rax
    2f3b:	79 f3                	jns    2f30 <buf_grow+0x40>
    2f3d:	48 8b 39             	mov    (%rcx),%rdi
    2f40:	48 89 d6             	mov    %rdx,%rsi
    2f43:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f48:	48 89 14 24          	mov    %rdx,(%rsp)
    2f4c:	e8 4f f6 ff ff       	call   25a0 <realloc@plt>
    2f51:	48 8b 14 24          	mov    (%rsp),%rdx
    2f55:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f5a:	48 85 c0             	test   %rax,%rax
    2f5d:	74 1d                	je     2f7c <buf_grow+0x8c>
    2f5f:	48 89 01             	mov    %rax,(%rcx)
    2f62:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f66:	48 83 c4 18          	add    $0x18,%rsp
    2f6a:	c3                   	ret
    2f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f70:	48 89 c2             	mov    %rax,%rdx
    2f73:	eb c8                	jmp    2f3d <buf_grow+0x4d>
    2f75:	ba 40 00 00 00       	mov    $0x40,%edx
    2f7a:	eb c1                	jmp    2f3d <buf_grow+0x4d>
    2f7c:	48 8b 0d fd b0 00 00 	mov    0xb0fd(%rip),%rcx        # e080 <stderr@GLIBC_2.2.5>
    2f83:	ba 13 00 00 00       	mov    $0x13,%edx
    2f88:	be 01 00 00 00       	mov    $0x1,%esi
    2f8d:	48 8d 3d 74 80 00 00 	lea    0x8074(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f94:	e8 a7 f6 ff ff       	call   2640 <fwrite@plt>
    2f99:	31 ff                	xor    %edi,%edi
    2f9b:	e8 f0 f5 ff ff       	call   2590 <fflush@plt>
    2fa0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fa5:	e8 b6 f6 ff ff       	call   2660 <_Exit@plt>
    2faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002fb0 <buf_put>:
    2fb0:	41 54                	push   %r12
    2fb2:	49 89 f4             	mov    %rsi,%r12
    2fb5:	48 89 d6             	mov    %rdx,%rsi
    2fb8:	55                   	push   %rbp
    2fb9:	48 89 fd             	mov    %rdi,%rbp
    2fbc:	53                   	push   %rbx
    2fbd:	48 89 d3             	mov    %rdx,%rbx
    2fc0:	e8 2b ff ff ff       	call   2ef0 <buf_grow>
    2fc5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2fc9:	48 89 da             	mov    %rbx,%rdx
    2fcc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fd0:	4c 89 e6             	mov    %r12,%rsi
    2fd3:	e8 98 f5 ff ff       	call   2570 <memcpy@plt>
    2fd8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fdc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fe0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fe4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fe8:	5b                   	pop    %rbx
    2fe9:	5d                   	pop    %rbp
    2fea:	41 5c                	pop    %r12
    2fec:	c3                   	ret
    2fed:	0f 1f 00             	nopl   (%rax)

0000000000002ff0 <fwp_cancel_tree.part.0>:
    2ff0:	48 3b 3d 29 b7 01 00 	cmp    0x1b729(%rip),%rdi        # 1e720 <fwp_cur>
    2ff7:	53                   	push   %rbx
    2ff8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2ffc:	74 35                	je     3033 <fwp_cancel_tree.part.0+0x43>
    2ffe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3002:	75 2f                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    3004:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3008:	75 29                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    300a:	48 8b 05 ef b6 01 00 	mov    0x1b6ef(%rip),%rax        # 1e700 <fwp_ready_tail>
    3011:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3015:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    301c:	00 00 00 00 
    3020:	48 85 c0             	test   %rax,%rax
    3023:	74 33                	je     3058 <fwp_cancel_tree.part.0+0x68>
    3025:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    302c:	48 89 3d cd b6 01 00 	mov    %rdi,0x1b6cd(%rip)        # 1e700 <fwp_ready_tail>
    3033:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3037:	48 85 db             	test   %rbx,%rbx
    303a:	74 17                	je     3053 <fwp_cancel_tree.part.0+0x63>
    303c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3040:	75 08                	jne    304a <fwp_cancel_tree.part.0+0x5a>
    3042:	48 89 df             	mov    %rbx,%rdi
    3045:	e8 a6 ff ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    304a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    304e:	48 85 db             	test   %rbx,%rbx
    3051:	75 e9                	jne    303c <fwp_cancel_tree.part.0+0x4c>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	48 89 3d a9 b6 01 00 	mov    %rdi,0x1b6a9(%rip)        # 1e708 <fwp_ready_head>
    305f:	eb cb                	jmp    302c <fwp_cancel_tree.part.0+0x3c>
    3061:	0f 1f 40 00          	nopl   0x0(%rax)
    3065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    306c:	00 00 00 00 

0000000000003070 <fwp_finish_float>:
    3070:	53                   	push   %rbx
    3071:	be 2e 00 00 00       	mov    $0x2e,%esi
    3076:	48 89 fb             	mov    %rdi,%rbx
    3079:	e8 e2 f3 ff ff       	call   2460 <strchr@plt>
    307e:	48 85 c0             	test   %rax,%rax
    3081:	74 05                	je     3088 <fwp_finish_float+0x18>
    3083:	5b                   	pop    %rbx
    3084:	c3                   	ret
    3085:	0f 1f 00             	nopl   (%rax)
    3088:	be 65 00 00 00       	mov    $0x65,%esi
    308d:	48 89 df             	mov    %rbx,%rdi
    3090:	e8 cb f3 ff ff       	call   2460 <strchr@plt>
    3095:	48 85 c0             	test   %rax,%rax
    3098:	75 e9                	jne    3083 <fwp_finish_float+0x13>
    309a:	48 8d 35 61 80 00 00 	lea    0x8061(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    30a1:	48 89 df             	mov    %rbx,%rdi
    30a4:	e8 e7 f5 ff ff       	call   2690 <strstr@plt>
    30a9:	48 85 c0             	test   %rax,%rax
    30ac:	75 d5                	jne    3083 <fwp_finish_float+0x13>
    30ae:	48 8d 35 67 7f 00 00 	lea    0x7f67(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    30b5:	48 89 df             	mov    %rbx,%rdi
    30b8:	e8 d3 f5 ff ff       	call   2690 <strstr@plt>
    30bd:	48 85 c0             	test   %rax,%rax
    30c0:	75 c1                	jne    3083 <fwp_finish_float+0x13>
    30c2:	48 89 df             	mov    %rbx,%rdi
    30c5:	e8 66 f3 ff ff       	call   2430 <strlen@plt>
    30ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    30cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30d8:	5b                   	pop    %rbx
    30d9:	c3                   	ret
    30da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030e0 <ad_raw_report>:
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	55                   	push   %rbp
    30e5:	31 c9                	xor    %ecx,%ecx
    30e7:	45 31 c9             	xor    %r9d,%r9d
    30ea:	48 8d 15 2f 81 00 00 	lea    0x812f(%rip),%rdx        # b220 <_IO_stdin_used+0x220>
    30f1:	53                   	push   %rbx
    30f2:	be 02 00 00 00       	mov    $0x2,%esi
    30f7:	31 db                	xor    %ebx,%ebx
    30f9:	48 83 ec 38          	sub    $0x38,%rsp
    30fd:	4c 8b 05 c4 af 01 00 	mov    0x1afc4(%rip),%r8        # 1e0c8 <ad_raw_before_shutdown>
    3104:	48 8b 3d 75 af 00 00 	mov    0xaf75(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    310b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3112:	00 00 
    3114:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3119:	31 c0                	xor    %eax,%eax
    311b:	48 89 e5             	mov    %rsp,%rbp
    311e:	e8 2d f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3123:	48 8d 05 01 7f 00 00 	lea    0x7f01(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    312a:	f3 0f 7e 05 de aa 00 	movq   0xaade(%rip),%xmm0        # dc10 <d0+0x70>
    3131:	00 
    3132:	48 8d 0d 35 7f 00 00 	lea    0x7f35(%rip),%rcx        # b06e <_IO_stdin_used+0x6e>
    3139:	66 48 0f 6e c8       	movq   %rax,%xmm1
    313e:	48 8d 05 f9 7e 00 00 	lea    0x7ef9(%rip),%rax        # b03e <_IO_stdin_used+0x3e>
    3145:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3149:	66 48 0f 6e d0       	movq   %rax,%xmm2
    314e:	66 49 0f 7e c0       	movq   %xmm0,%r8
    3153:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3157:	f3 0f 7e 05 b9 aa 00 	movq   0xaab9(%rip),%xmm0        # dc18 <d0+0x78>
    315e:	00 
    315f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3163:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3168:	6a 00                	push   $0x0
    316a:	48 8b 3d 0f af 00 00 	mov    0xaf0f(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    3171:	45 31 c9             	xor    %r9d,%r9d
    3174:	31 c0                	xor    %eax,%eax
    3176:	6a 00                	push   $0x0
    3178:	48 8d 15 01 81 00 00 	lea    0x8101(%rip),%rdx        # b280 <_IO_stdin_used+0x280>
    317f:	be 02 00 00 00       	mov    $0x2,%esi
    3184:	83 c3 01             	add    $0x1,%ebx
    3187:	e8 c4 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    318c:	58                   	pop    %rax
    318d:	5a                   	pop    %rdx
    318e:	83 fb 04             	cmp    $0x4,%ebx
    3191:	74 15                	je     31a8 <ad_raw_report+0xc8>
    3193:	48 83 c5 08          	add    $0x8,%rbp
    3197:	48 8d 0d 82 7e 00 00 	lea    0x7e82(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    319e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    31a2:	eb c4                	jmp    3168 <ad_raw_report+0x88>
    31a4:	0f 1f 40 00          	nopl   0x0(%rax)
    31a8:	48 8b 0d d1 ae 00 00 	mov    0xaed1(%rip),%rcx        # e080 <stderr@GLIBC_2.2.5>
    31af:	ba 13 00 00 00       	mov    $0x13,%edx
    31b4:	be 01 00 00 00       	mov    $0x1,%esi
    31b9:	48 8d 3d 87 7e 00 00 	lea    0x7e87(%rip),%rdi        # b047 <_IO_stdin_used+0x47>
    31c0:	e8 7b f4 ff ff       	call   2640 <fwrite@plt>
    31c5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    31ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    31d1:	00 00 
    31d3:	75 23                	jne    31f8 <ad_raw_report+0x118>
    31d5:	48 8b 0d a4 ae 00 00 	mov    0xaea4(%rip),%rcx        # e080 <stderr@GLIBC_2.2.5>
    31dc:	48 83 c4 38          	add    $0x38,%rsp
    31e0:	ba 04 00 00 00       	mov    $0x4,%edx
    31e5:	be 01 00 00 00       	mov    $0x1,%esi
    31ea:	5b                   	pop    %rbx
    31eb:	48 8d 3d 69 7e 00 00 	lea    0x7e69(%rip),%rdi        # b05b <_IO_stdin_used+0x5b>
    31f2:	5d                   	pop    %rbp
    31f3:	e9 48 f4 ff ff       	jmp    2640 <fwrite@plt>
    31f8:	e8 43 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31fd:	0f 1f 00             	nopl   (%rax)

0000000000003200 <fwp_trap>:
    3200:	53                   	push   %rbx
    3201:	48 89 fb             	mov    %rdi,%rbx
    3204:	e8 b7 f9 ff ff       	call   2bc0 <fwp_flush>
    3209:	48 89 d9             	mov    %rbx,%rcx
    320c:	be 02 00 00 00       	mov    $0x2,%esi
    3211:	31 c0                	xor    %eax,%eax
    3213:	48 8b 3d 66 ae 00 00 	mov    0xae66(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    321a:	48 8d 15 3f 7e 00 00 	lea    0x7e3f(%rip),%rdx        # b060 <_IO_stdin_used+0x60>
    3221:	e8 2a f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3226:	bf 65 00 00 00       	mov    $0x65,%edi
    322b:	e8 00 f4 ff ff       	call   2630 <exit@plt>

0000000000003230 <fwp_now_ns>:
    3230:	53                   	push   %rbx
    3231:	bf 01 00 00 00       	mov    $0x1,%edi
    3236:	48 83 ec 20          	sub    $0x20,%rsp
    323a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3241:	00 00 
    3243:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3248:	31 db                	xor    %ebx,%ebx
    324a:	48 89 e6             	mov    %rsp,%rsi
    324d:	e8 ae f1 ff ff       	call   2400 <clock_gettime@plt>
    3252:	85 c0                	test   %eax,%eax
    3254:	75 52                	jne    32a8 <fwp_now_ns+0x78>
    3256:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    325b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3260:	48 f7 2c 24          	imulq  (%rsp)
    3264:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    326b:	48 89 f7             	mov    %rsi,%rdi
    326e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3272:	48 01 f0             	add    %rsi,%rax
    3275:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    327c:	00 00 80 
    327f:	48 11 fa             	adc    %rdi,%rdx
    3282:	31 ff                	xor    %edi,%edi
    3284:	48 01 c6             	add    %rax,%rsi
    3287:	48 11 d7             	adc    %rdx,%rdi
    328a:	48 39 f1             	cmp    %rsi,%rcx
    328d:	48 19 fb             	sbb    %rdi,%rbx
    3290:	72 27                	jb     32b9 <fwp_now_ns+0x89>
    3292:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3297:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    329e:	00 00 
    32a0:	75 12                	jne    32b4 <fwp_now_ns+0x84>
    32a2:	48 83 c4 20          	add    $0x20,%rsp
    32a6:	5b                   	pop    %rbx
    32a7:	c3                   	ret
    32a8:	48 8d 3d c0 7d 00 00 	lea    0x7dc0(%rip),%rdi        # b06f <_IO_stdin_used+0x6f>
    32af:	e8 4c ff ff ff       	call   3200 <fwp_trap>
    32b4:	e8 87 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    32b9:	48 8d 3d 00 80 00 00 	lea    0x8000(%rip),%rdi        # b2c0 <_IO_stdin_used+0x2c0>
    32c0:	e8 3b ff ff ff       	call   3200 <fwp_trap>
    32c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    32cc:	00 00 00 00 

00000000000032d0 <fwp_format_g.constprop.0>:
    32d0:	41 57                	push   %r15
    32d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    32d7:	ba 02 00 00 00       	mov    $0x2,%edx
    32dc:	4c 8d 05 a8 7d 00 00 	lea    0x7da8(%rip),%r8        # b08b <_IO_stdin_used+0x8b>
    32e3:	41 56                	push   %r14
    32e5:	b8 01 00 00 00       	mov    $0x1,%eax
    32ea:	41 55                	push   %r13
    32ec:	41 54                	push   %r12
    32ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    32f2:	55                   	push   %rbp
    32f3:	45 89 e1             	mov    %r12d,%r9d
    32f6:	53                   	push   %rbx
    32f7:	48 89 fb             	mov    %rdi,%rbx
    32fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3301:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3308:	00 00 
    330a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3311:	00 
    3312:	41 89 f7             	mov    %esi,%r15d
    3315:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    331a:	be 40 00 00 00       	mov    $0x40,%esi
    331f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3324:	4c 89 f7             	mov    %r14,%rdi
    3327:	e8 64 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    332c:	be 65 00 00 00       	mov    $0x65,%esi
    3331:	4c 89 f7             	mov    %r14,%rdi
    3334:	e8 27 f1 ff ff       	call   2460 <strchr@plt>
    3339:	31 f6                	xor    %esi,%esi
    333b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3340:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3344:	48 89 c5             	mov    %rax,%rbp
    3347:	e8 14 f2 ff ff       	call   2560 <strtol@plt>
    334c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3351:	49 89 c0             	mov    %rax,%r8
    3354:	83 c0 05             	add    $0x5,%eax
    3357:	83 f8 15             	cmp    $0x15,%eax
    335a:	0f 87 e0 01 00 00    	ja     3540 <fwp_format_g.constprop.0+0x270>
    3360:	45 89 e5             	mov    %r12d,%r13d
    3363:	45 29 c5             	sub    %r8d,%r13d
    3366:	45 85 ed             	test   %r13d,%r13d
    3369:	0f 8e 21 01 00 00    	jle    3490 <fwp_format_g.constprop.0+0x1c0>
    336f:	41 83 ff 01          	cmp    $0x1,%r15d
    3373:	0f 84 17 01 00 00    	je     3490 <fwp_format_g.constprop.0+0x1c0>
    3379:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    337e:	31 d2                	xor    %edx,%edx
    3380:	4d 63 df             	movslq %r15d,%r11
    3383:	3c 2d                	cmp    $0x2d,%al
    3385:	0f 94 c2             	sete   %dl
    3388:	4c 29 dd             	sub    %r11,%rbp
    338b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    338f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3393:	4d 89 f1             	mov    %r14,%r9
    3396:	4d 29 d1             	sub    %r10,%r9
    3399:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    339d:	3c 2d                	cmp    $0x2d,%al
    339f:	0f 84 fb 03 00 00    	je     37a0 <fwp_format_g.constprop.0+0x4d0>
    33a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    33aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    33af:	48 89 e8             	mov    %rbp,%rax
    33b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    33ba:	49 83 c1 47          	add    $0x47,%r9
    33be:	45 85 c0             	test   %r8d,%r8d
    33c1:	0f 88 f1 02 00 00    	js     36b8 <fwp_format_g.constprop.0+0x3e8>
    33c7:	45 0f b6 12          	movzbl (%r10),%r10d
    33cb:	4d 63 e0             	movslq %r8d,%r12
    33ce:	44 88 10             	mov    %r10b,(%rax)
    33d1:	41 83 f8 07          	cmp    $0x7,%r8d
    33d5:	0f 87 2d 02 00 00    	ja     3608 <fwp_format_g.constprop.0+0x338>
    33db:	41 f6 c4 04          	test   $0x4,%r12b
    33df:	0f 85 f2 03 00 00    	jne    37d7 <fwp_format_g.constprop.0+0x507>
    33e5:	45 85 e4             	test   %r12d,%r12d
    33e8:	74 12                	je     33fc <fwp_format_g.constprop.0+0x12c>
    33ea:	45 0f b6 06          	movzbl (%r14),%r8d
    33ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    33f2:	41 f6 c4 02          	test   $0x2,%r12b
    33f6:	0f 85 03 04 00 00    	jne    37ff <fwp_format_g.constprop.0+0x52f>
    33fc:	4c 29 e1             	sub    %r12,%rcx
    33ff:	4c 01 e7             	add    %r12,%rdi
    3402:	4c 89 fa             	mov    %r15,%rdx
    3405:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    340a:	48 83 e9 01          	sub    $0x1,%rcx
    340e:	4d 63 ed             	movslq %r13d,%r13
    3411:	48 89 0c 24          	mov    %rcx,(%rsp)
    3415:	e8 26 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    341a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    341f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3423:	ba 48 00 00 00       	mov    $0x48,%edx
    3428:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    342c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3430:	4c 89 c8             	mov    %r9,%rax
    3433:	48 29 c8             	sub    %rcx,%rax
    3436:	48 39 d0             	cmp    %rdx,%rax
    3439:	48 0f 42 c2          	cmovb  %rdx,%rax
    343d:	4c 29 c9             	sub    %r9,%rcx
    3440:	4c 89 ea             	mov    %r13,%rdx
    3443:	48 01 c1             	add    %rax,%rcx
    3446:	e8 f5 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    344b:	4c 01 e8             	add    %r13,%rax
    344e:	48 29 e8             	sub    %rbp,%rax
    3451:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3456:	48 39 d0             	cmp    %rdx,%rax
    3459:	48 0f 47 c2          	cmova  %rdx,%rax
    345d:	89 c1                	mov    %eax,%ecx
    345f:	83 f8 08             	cmp    $0x8,%eax
    3462:	0f 83 18 02 00 00    	jae    3680 <fwp_format_g.constprop.0+0x3b0>
    3468:	a8 04                	test   $0x4,%al
    346a:	0f 85 54 03 00 00    	jne    37c4 <fwp_format_g.constprop.0+0x4f4>
    3470:	85 c0                	test   %eax,%eax
    3472:	74 0f                	je     3483 <fwp_format_g.constprop.0+0x1b3>
    3474:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3479:	88 13                	mov    %dl,(%rbx)
    347b:	a8 02                	test   $0x2,%al
    347d:	0f 85 6b 03 00 00    	jne    37ee <fwp_format_g.constprop.0+0x51e>
    3483:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3487:	eb 36                	jmp    34bf <fwp_format_g.constprop.0+0x1ef>
    3489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3490:	45 31 c9             	xor    %r9d,%r9d
    3493:	45 85 ed             	test   %r13d,%r13d
    3496:	4c 8d 05 fd 7b 00 00 	lea    0x7bfd(%rip),%r8        # b09a <_IO_stdin_used+0x9a>
    349d:	48 89 df             	mov    %rbx,%rdi
    34a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    34a4:	ba 02 00 00 00       	mov    $0x2,%edx
    34a9:	be 90 01 00 00       	mov    $0x190,%esi
    34ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    34b5:	b8 01 00 00 00       	mov    $0x1,%eax
    34ba:	e8 d1 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    34c4:	48 89 df             	mov    %rbx,%rdi
    34c7:	e8 94 ef ff ff       	call   2460 <strchr@plt>
    34cc:	48 85 c0             	test   %rax,%rax
    34cf:	74 3f                	je     3510 <fwp_format_g.constprop.0+0x240>
    34d1:	48 89 df             	mov    %rbx,%rdi
    34d4:	e8 57 ef ff ff       	call   2430 <strlen@plt>
    34d9:	48 85 c0             	test   %rax,%rax
    34dc:	75 0b                	jne    34e9 <fwp_format_g.constprop.0+0x219>
    34de:	eb 30                	jmp    3510 <fwp_format_g.constprop.0+0x240>
    34e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    34e4:	48 85 c0             	test   %rax,%rax
    34e7:	74 27                	je     3510 <fwp_format_g.constprop.0+0x240>
    34e9:	48 89 c2             	mov    %rax,%rdx
    34ec:	48 83 e8 01          	sub    $0x1,%rax
    34f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    34f4:	74 ea                	je     34e0 <fwp_format_g.constprop.0+0x210>
    34f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    34fb:	0f 84 6f 01 00 00    	je     3670 <fwp_format_g.constprop.0+0x3a0>
    3501:	0f 1f 40 00          	nopl   0x0(%rax)
    3505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    350c:	00 00 00 00 
    3510:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3517:	00 
    3518:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    351f:	00 00 
    3521:	0f 85 ec 02 00 00    	jne    3813 <fwp_format_g.constprop.0+0x543>
    3527:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    352e:	5b                   	pop    %rbx
    352f:	5d                   	pop    %rbp
    3530:	41 5c                	pop    %r12
    3532:	41 5d                	pop    %r13
    3534:	41 5e                	pop    %r14
    3536:	41 5f                	pop    %r15
    3538:	c3                   	ret
    3539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3540:	4c 29 f5             	sub    %r14,%rbp
    3543:	b9 40 00 00 00       	mov    $0x40,%ecx
    3548:	4c 89 f6             	mov    %r14,%rsi
    354b:	4c 89 04 24          	mov    %r8,(%rsp)
    354f:	49 89 ec             	mov    %rbp,%r12
    3552:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3557:	4c 89 e2             	mov    %r12,%rdx
    355a:	48 89 ef             	mov    %rbp,%rdi
    355d:	e8 de ef ff ff       	call   2540 <__memcpy_chk@plt>
    3562:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3568:	be 2e 00 00 00       	mov    $0x2e,%esi
    356d:	48 89 ef             	mov    %rbp,%rdi
    3570:	e8 eb ee ff ff       	call   2460 <strchr@plt>
    3575:	4c 8b 04 24          	mov    (%rsp),%r8
    3579:	48 85 c0             	test   %rax,%rax
    357c:	74 40                	je     35be <fwp_format_g.constprop.0+0x2ee>
    357e:	4d 85 e4             	test   %r12,%r12
    3581:	74 3b                	je     35be <fwp_format_g.constprop.0+0x2ee>
    3583:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3588:	eb 23                	jmp    35ad <fwp_format_g.constprop.0+0x2dd>
    358a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3591:	00 00 00 00 
    3595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    359c:	00 00 00 00 
    35a0:	c6 00 00             	movb   $0x0,(%rax)
    35a3:	48 83 e8 01          	sub    $0x1,%rax
    35a7:	49 83 ec 01          	sub    $0x1,%r12
    35ab:	74 11                	je     35be <fwp_format_g.constprop.0+0x2ee>
    35ad:	80 38 30             	cmpb   $0x30,(%rax)
    35b0:	74 ee                	je     35a0 <fwp_format_g.constprop.0+0x2d0>
    35b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    35b8:	0f 84 fb 01 00 00    	je     37b9 <fwp_format_g.constprop.0+0x4e9>
    35be:	44 89 c0             	mov    %r8d,%eax
    35c1:	ba 02 00 00 00       	mov    $0x2,%edx
    35c6:	49 89 e9             	mov    %rbp,%r9
    35c9:	be 90 01 00 00       	mov    $0x190,%esi
    35ce:	f7 d8                	neg    %eax
    35d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    35d7:	48 89 df             	mov    %rbx,%rdi
    35da:	41 0f 48 c0          	cmovs  %r8d,%eax
    35de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    35e2:	41 83 e0 02          	and    $0x2,%r8d
    35e6:	41 83 c0 2b          	add    $0x2b,%r8d
    35ea:	50                   	push   %rax
    35eb:	31 c0                	xor    %eax,%eax
    35ed:	41 50                	push   %r8
    35ef:	4c 8d 05 9a 7a 00 00 	lea    0x7a9a(%rip),%r8        # b090 <_IO_stdin_used+0x90>
    35f6:	e8 95 ed ff ff       	call   2390 <__snprintf_chk@plt>
    35fb:	58                   	pop    %rax
    35fc:	5a                   	pop    %rdx
    35fd:	e9 0e ff ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    3602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3608:	4d 8b 06             	mov    (%r14),%r8
    360b:	48 83 c0 09          	add    $0x9,%rax
    360f:	4c 89 f2             	mov    %r14,%rdx
    3612:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3616:	4c 89 07             	mov    %r8,(%rdi)
    3619:	45 89 e0             	mov    %r12d,%r8d
    361c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3621:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3626:	49 89 f8             	mov    %rdi,%r8
    3629:	49 29 c0             	sub    %rax,%r8
    362c:	4c 29 c2             	sub    %r8,%rdx
    362f:	45 01 e0             	add    %r12d,%r8d
    3632:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3636:	41 83 f8 08          	cmp    $0x8,%r8d
    363a:	0f 82 bc fd ff ff    	jb     33fc <fwp_format_g.constprop.0+0x12c>
    3640:	48 89 0c 24          	mov    %rcx,(%rsp)
    3644:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3648:	45 31 d2             	xor    %r10d,%r10d
    364b:	45 89 d3             	mov    %r10d,%r11d
    364e:	41 83 c2 08          	add    $0x8,%r10d
    3652:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3656:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    365a:	45 39 c2             	cmp    %r8d,%r10d
    365d:	72 ec                	jb     364b <fwp_format_g.constprop.0+0x37b>
    365f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3663:	e9 94 fd ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    366f:	00 
    3670:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3675:	e9 96 fe ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3680:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3685:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3689:	48 89 ee             	mov    %rbp,%rsi
    368c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3690:	48 89 13             	mov    %rdx,(%rbx)
    3693:	89 c2                	mov    %eax,%edx
    3695:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    369a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    369f:	48 89 d9             	mov    %rbx,%rcx
    36a2:	48 29 f9             	sub    %rdi,%rcx
    36a5:	48 29 ce             	sub    %rcx,%rsi
    36a8:	01 c1                	add    %eax,%ecx
    36aa:	c1 e9 03             	shr    $0x3,%ecx
    36ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    36b0:	e9 ce fd ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    36b5:	0f 1f 00             	nopl   (%rax)
    36b8:	c6 00 30             	movb   $0x30,(%rax)
    36bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    36bf:	4c 89 fa             	mov    %r15,%rdx
    36c2:	4c 89 e9             	mov    %r13,%rcx
    36c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    36ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    36cf:	4c 89 14 24          	mov    %r10,(%rsp)
    36d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    36d8:	e8 63 ee ff ff       	call   2540 <__memcpy_chk@plt>
    36dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    36e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    36e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    36ec:	48 89 c7             	mov    %rax,%rdi
    36ef:	4c 8b 14 24          	mov    (%rsp),%r10
    36f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    36f8:	4c 89 c8             	mov    %r9,%rax
    36fb:	4c 29 e8             	sub    %r13,%rax
    36fe:	48 39 c8             	cmp    %rcx,%rax
    3701:	48 0f 42 c1          	cmovb  %rcx,%rax
    3705:	4d 29 cd             	sub    %r9,%r13
    3708:	49 01 ff             	add    %rdi,%r15
    370b:	4c 01 e8             	add    %r13,%rax
    370e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3712:	74 3d                	je     3751 <fwp_format_g.constprop.0+0x481>
    3714:	41 f7 d0             	not    %r8d
    3717:	31 f6                	xor    %esi,%esi
    3719:	ba 48 00 00 00       	mov    $0x48,%edx
    371e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3723:	48 39 d0             	cmp    %rdx,%rax
    3726:	48 0f 43 d0          	cmovae %rax,%rdx
    372a:	48 89 d1             	mov    %rdx,%rcx
    372d:	48 29 c1             	sub    %rax,%rcx
    3730:	48 83 c1 01          	add    $0x1,%rcx
    3734:	48 39 d1             	cmp    %rdx,%rcx
    3737:	48 0f 42 ca          	cmovb  %rdx,%rcx
    373b:	48 83 e8 01          	sub    $0x1,%rax
    373f:	48 83 c6 01          	add    $0x1,%rsi
    3743:	48 29 d0             	sub    %rdx,%rax
    3746:	48 01 c8             	add    %rcx,%rax
    3749:	41 39 f0             	cmp    %esi,%r8d
    374c:	7f cb                	jg     3719 <fwp_format_g.constprop.0+0x449>
    374e:	4d 01 c7             	add    %r8,%r15
    3751:	b9 48 00 00 00       	mov    $0x48,%ecx
    3756:	41 0f b6 12          	movzbl (%r10),%edx
    375a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    375e:	4c 89 f6             	mov    %r14,%rsi
    3761:	48 39 c8             	cmp    %rcx,%rax
    3764:	4c 89 1c 24          	mov    %r11,(%rsp)
    3768:	48 0f 43 c8          	cmovae %rax,%rcx
    376c:	41 88 17             	mov    %dl,(%r15)
    376f:	48 89 ca             	mov    %rcx,%rdx
    3772:	48 29 c2             	sub    %rax,%rdx
    3775:	48 83 c2 01          	add    $0x1,%rdx
    3779:	48 39 ca             	cmp    %rcx,%rdx
    377c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3780:	48 83 e8 01          	sub    $0x1,%rax
    3784:	48 29 c8             	sub    %rcx,%rax
    3787:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    378b:	49 63 d4             	movslq %r12d,%rdx
    378e:	e8 ad ed ff ff       	call   2540 <__memcpy_chk@plt>
    3793:	4c 8b 1c 24          	mov    (%rsp),%r11
    3797:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    379b:	e9 ae fc ff ff       	jmp    344e <fwp_format_g.constprop.0+0x17e>
    37a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    37a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    37aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    37af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    37b4:	e9 f9 fb ff ff       	jmp    33b2 <fwp_format_g.constprop.0+0xe2>
    37b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    37bf:	e9 fa fd ff ff       	jmp    35be <fwp_format_g.constprop.0+0x2ee>
    37c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    37c8:	89 13                	mov    %edx,(%rbx)
    37ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    37ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    37d2:	e9 ac fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37d7:	41 8b 06             	mov    (%r14),%eax
    37da:	89 07                	mov    %eax,(%rdi)
    37dc:	44 89 e0             	mov    %r12d,%eax
    37df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    37e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    37e9:	e9 0e fc ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    37ee:	89 c2                	mov    %eax,%edx
    37f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    37f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    37fa:	e9 84 fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37ff:	44 89 e0             	mov    %r12d,%eax
    3802:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3808:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    380e:	e9 e9 fb ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3813:	e8 28 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    381f:	00 

0000000000003820 <fwp_heap_report>:
    3820:	f3 0f 1e fa          	endbr64
    3824:	41 54                	push   %r12
    3826:	48 8d 3d 72 78 00 00 	lea    0x7872(%rip),%rdi        # b09f <_IO_stdin_used+0x9f>
    382d:	55                   	push   %rbp
    382e:	53                   	push   %rbx
    382f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3836:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    383d:	00 00 
    383f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3846:	00 
    3847:	48 8d 35 fc 78 00 00 	lea    0x78fc(%rip),%rsi        # b14a <_IO_stdin_used+0x14a>
    384e:	e8 9d ed ff ff       	call   25f0 <fopen@plt>
    3853:	48 85 c0             	test   %rax,%rax
    3856:	0f 84 c5 00 00 00    	je     3921 <fwp_heap_report+0x101>
    385c:	48 89 c5             	mov    %rax,%rbp
    385f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3866:	48 89 e3             	mov    %rsp,%rbx
    3869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3870:	48 89 ea             	mov    %rbp,%rdx
    3873:	be 00 01 00 00       	mov    $0x100,%esi
    3878:	48 89 df             	mov    %rbx,%rdi
    387b:	e8 60 ec ff ff       	call   24e0 <fgets@plt>
    3880:	48 85 c0             	test   %rax,%rax
    3883:	74 2b                	je     38b0 <fwp_heap_report+0x90>
    3885:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    388b:	75 e3                	jne    3870 <fwp_heap_report+0x50>
    388d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3891:	75 dd                	jne    3870 <fwp_heap_report+0x50>
    3893:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3898:	75 d6                	jne    3870 <fwp_heap_report+0x50>
    389a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    389f:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a4:	31 f6                	xor    %esi,%esi
    38a6:	e8 b5 ec ff ff       	call   2560 <strtol@plt>
    38ab:	49 89 c4             	mov    %rax,%r12
    38ae:	eb c0                	jmp    3870 <fwp_heap_report+0x50>
    38b0:	48 89 ef             	mov    %rbp,%rdi
    38b3:	e8 68 eb ff ff       	call   2420 <fclose@plt>
    38b8:	48 83 ec 08          	sub    $0x8,%rsp
    38bc:	4c 8b 0d 45 c2 01 00 	mov    0x1c245(%rip),%r9        # 1fb08 <fwp_heap+0x13c8>
    38c3:	4c 8b 05 9e c2 01 00 	mov    0x1c29e(%rip),%r8        # 1fb68 <fwp_heap+0x1428>
    38ca:	48 8d 15 17 7a 00 00 	lea    0x7a17(%rip),%rdx        # b2e8 <_IO_stdin_used+0x2e8>
    38d1:	41 54                	push   %r12
    38d3:	48 8b 0d 86 c2 01 00 	mov    0x1c286(%rip),%rcx        # 1fb60 <fwp_heap+0x1420>
    38da:	be 02 00 00 00       	mov    $0x2,%esi
    38df:	b8 02 00 00 00       	mov    $0x2,%eax
    38e4:	f2 0f 10 0d 94 c2 01 	movsd  0x1c294(%rip),%xmm1        # 1fb80 <fwp_heap+0x1440>
    38eb:	00 
    38ec:	f2 0f 10 05 84 c2 01 	movsd  0x1c284(%rip),%xmm0        # 1fb78 <fwp_heap+0x1438>
    38f3:	00 
    38f4:	48 8b 3d 85 a7 00 00 	mov    0xa785(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    38fb:	e8 50 ed ff ff       	call   2650 <__fprintf_chk@plt>
    3900:	58                   	pop    %rax
    3901:	5a                   	pop    %rdx
    3902:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3909:	00 
    390a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3911:	00 00 
    3913:	75 15                	jne    392a <fwp_heap_report+0x10a>
    3915:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    391c:	5b                   	pop    %rbx
    391d:	5d                   	pop    %rbp
    391e:	41 5c                	pop    %r12
    3920:	c3                   	ret
    3921:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3928:	eb 8e                	jmp    38b8 <fwp_heap_report+0x98>
    392a:	e8 11 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    392f:	90                   	nop

0000000000003930 <fwp_heap_init>:
    3930:	66 0f 6f 05 b8 7c 00 	movdqa 0x7cb8(%rip),%xmm0        # b5f0 <msg.3+0x20>
    3937:	00 
    3938:	41 54                	push   %r12
    393a:	48 8d 05 3f bd 01 00 	lea    0x1bd3f(%rip),%rax        # 1f680 <fwp_heap+0xf40>
    3941:	ba 00 01 00 00       	mov    $0x100,%edx
    3946:	55                   	push   %rbp
    3947:	66 0f 6f 15 e1 7c 00 	movdqa 0x7ce1(%rip),%xmm2        # b630 <msg.3+0x60>
    394e:	00 
    394f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3953:	53                   	push   %rbx
    3954:	0f 29 05 e5 bc 01 00 	movaps %xmm0,0x1bce5(%rip)        # 1f640 <fwp_heap+0xf00>
    395b:	66 0f 6f 05 9d 7c 00 	movdqa 0x7c9d(%rip),%xmm0        # b600 <msg.3+0x30>
    3962:	00 
    3963:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3967:	c7 05 73 c1 01 00 01 	movl   $0x1,0x1c173(%rip)        # 1fae4 <fwp_heap+0x13a4>
    396e:	00 00 00 
    3971:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3976:	0f 29 05 d3 bc 01 00 	movaps %xmm0,0x1bcd3(%rip)        # 1f650 <fwp_heap+0xf10>
    397d:	66 0f 6f 05 8b 7c 00 	movdqa 0x7c8b(%rip),%xmm0        # b610 <msg.3+0x40>
    3984:	00 
    3985:	0f 29 05 d4 bc 01 00 	movaps %xmm0,0x1bcd4(%rip)        # 1f660 <fwp_heap+0xf20>
    398c:	66 0f 6f 05 8c 7c 00 	movdqa 0x7c8c(%rip),%xmm0        # b620 <msg.3+0x50>
    3993:	00 
    3994:	0f 29 05 d5 bc 01 00 	movaps %xmm0,0x1bcd5(%rip)        # 1f670 <fwp_heap+0xf30>
    399b:	89 d3                	mov    %edx,%ebx
    399d:	66 0f 6e e2          	movd   %edx,%xmm4
    39a1:	48 83 c0 10          	add    $0x10,%rax
    39a5:	01 d2                	add    %edx,%edx
    39a7:	c1 eb 02             	shr    $0x2,%ebx
    39aa:	66 0f 6e c3          	movd   %ebx,%xmm0
    39ae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    39b3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    39b7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    39bc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    39c0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    39c4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    39c9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    39ce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    39d2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    39d7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    39db:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    39df:	48 39 c7             	cmp    %rax,%rdi
    39e2:	75 b7                	jne    399b <fwp_heap_init+0x6b>
    39e4:	4c 8d 05 55 ad 01 00 	lea    0x1ad55(%rip),%r8        # 1e740 <fwp_heap>
    39eb:	31 c9                	xor    %ecx,%ecx
    39ed:	31 c0                	xor    %eax,%eax
    39ef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    39f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    39fd:	00 00 00 
    3a00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a07:	00 
    3a08:	48 39 ca             	cmp    %rcx,%rdx
    3a0b:	73 0f                	jae    3a1c <fwp_heap_init+0xec>
    3a0d:	0f 1f 00             	nopl   (%rax)
    3a10:	48 83 c0 01          	add    $0x1,%rax
    3a14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a17:	48 39 ca             	cmp    %rcx,%rdx
    3a1a:	72 f4                	jb     3a10 <fwp_heap_init+0xe0>
    3a1c:	48 83 c1 10          	add    $0x10,%rcx
    3a20:	88 07                	mov    %al,(%rdi)
    3a22:	48 83 c7 01          	add    $0x1,%rdi
    3a26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3a2d:	75 d1                	jne    3a00 <fwp_heap_init+0xd0>
    3a2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3a36:	00 00 00 
    3a39:	bd 05 00 00 00       	mov    $0x5,%ebp
    3a3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3a45:	45 31 c9             	xor    %r9d,%r9d
    3a48:	31 d2                	xor    %edx,%edx
    3a4a:	31 ff                	xor    %edi,%edi
    3a4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3a57:	4c 89 e6             	mov    %r12,%rsi
    3a5a:	e8 f1 e9 ff ff       	call   2450 <mmap@plt>
    3a5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a63:	75 13                	jne    3a78 <fwp_heap_init+0x148>
    3a65:	48 c1 eb 02          	shr    $0x2,%rbx
    3a69:	83 ed 01             	sub    $0x1,%ebp
    3a6c:	75 d0                	jne    3a3e <fwp_heap_init+0x10e>
    3a6e:	e8 7d f2 ff ff       	call   2cf0 <fwp_heap_oom>
    3a73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3a78:	48 85 c0             	test   %rax,%rax
    3a7b:	74 f1                	je     3a6e <fwp_heap_init+0x13e>
    3a7d:	48 c1 eb 10          	shr    $0x10,%rbx
    3a81:	48 89 05 70 c0 01 00 	mov    %rax,0x1c070(%rip)        # 1faf8 <fwp_heap+0x13b8>
    3a88:	45 31 c9             	xor    %r9d,%r9d
    3a8b:	31 d2                	xor    %edx,%edx
    3a8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3a93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3a97:	31 ff                	xor    %edi,%edi
    3a99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a9f:	66 31 c0             	xor    %ax,%ax
    3aa2:	48 c1 e6 03          	shl    $0x3,%rsi
    3aa6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3aab:	4c 89 25 4e c0 01 00 	mov    %r12,0x1c04e(%rip)        # 1fb00 <fwp_heap+0x13c0>
    3ab2:	48 89 05 37 c0 01 00 	mov    %rax,0x1c037(%rip)        # 1faf0 <fwp_heap+0x13b0>
    3ab9:	48 89 1d 50 c0 01 00 	mov    %rbx,0x1c050(%rip)        # 1fb10 <fwp_heap+0x13d0>
    3ac0:	48 89 35 79 c0 01 00 	mov    %rsi,0x1c079(%rip)        # 1fb40 <fwp_heap+0x1400>
    3ac7:	e8 84 e9 ff ff       	call   2450 <mmap@plt>
    3acc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ad0:	74 9c                	je     3a6e <fwp_heap_init+0x13e>
    3ad2:	48 8d 3d fc 75 00 00 	lea    0x75fc(%rip),%rdi        # b0d5 <_IO_stdin_used+0xd5>
    3ad9:	48 89 05 58 c0 01 00 	mov    %rax,0x1c058(%rip)        # 1fb38 <fwp_heap+0x13f8>
    3ae0:	e8 9b e8 ff ff       	call   2380 <getenv@plt>
    3ae5:	48 89 c2             	mov    %rax,%rdx
    3ae8:	31 c0                	xor    %eax,%eax
    3aea:	48 85 d2             	test   %rdx,%rdx
    3aed:	74 15                	je     3b04 <fwp_heap_init+0x1d4>
    3aef:	80 3a 00             	cmpb   $0x0,(%rdx)
    3af2:	74 10                	je     3b04 <fwp_heap_init+0x1d4>
    3af4:	0f b6 02             	movzbl (%rdx),%eax
    3af7:	83 e8 30             	sub    $0x30,%eax
    3afa:	74 13                	je     3b0f <fwp_heap_init+0x1df>
    3afc:	85 c0                	test   %eax,%eax
    3afe:	0f 95 c0             	setne  %al
    3b01:	0f b6 c0             	movzbl %al,%eax
    3b04:	5b                   	pop    %rbx
    3b05:	5d                   	pop    %rbp
    3b06:	89 05 dc bf 01 00    	mov    %eax,0x1bfdc(%rip)        # 1fae8 <fwp_heap+0x13a8>
    3b0c:	41 5c                	pop    %r12
    3b0e:	c3                   	ret
    3b0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b13:	85 c0                	test   %eax,%eax
    3b15:	0f 95 c0             	setne  %al
    3b18:	0f b6 c0             	movzbl %al,%eax
    3b1b:	eb e7                	jmp    3b04 <fwp_heap_init+0x1d4>
    3b1d:	0f 1f 00             	nopl   (%rax)

0000000000003b20 <fwp_wake_io>:
    3b20:	48 8b 07             	mov    (%rdi),%rax
    3b23:	48 85 c0             	test   %rax,%rax
    3b26:	0f 84 f4 00 00 00    	je     3c20 <fwp_wake_io+0x100>
    3b2c:	53                   	push   %rbx
    3b2d:	4c 8b 05 cc ab 01 00 	mov    0x1abcc(%rip),%r8        # 1e700 <fwp_ready_tail>
    3b34:	49 89 f9             	mov    %rdi,%r9
    3b37:	48 89 c2             	mov    %rax,%rdx
    3b3a:	45 31 db             	xor    %r11d,%r11d
    3b3d:	45 31 d2             	xor    %r10d,%r10d
    3b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3b44:	eb 71                	jmp    3bb7 <fwp_wake_io+0x97>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3b57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b5e:	48 85 c9             	test   %rcx,%rcx
    3b61:	74 07                	je     3b6a <fwp_wake_io+0x4a>
    3b63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3b6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3b71:	00 00 00 00 
    3b75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3b7c:	49 8b 01             	mov    (%r9),%rax
    3b7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3b83:	75 2a                	jne    3baf <fwp_wake_io+0x8f>
    3b85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3b89:	75 24                	jne    3baf <fwp_wake_io+0x8f>
    3b8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3b8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3b96:	00 00 00 00 
    3b9a:	4d 85 c0             	test   %r8,%r8
    3b9d:	74 51                	je     3bf0 <fwp_wake_io+0xd0>
    3b9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3ba6:	49 89 d0             	mov    %rdx,%r8
    3ba9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3baf:	48 89 c2             	mov    %rax,%rdx
    3bb2:	48 85 c0             	test   %rax,%rax
    3bb5:	74 49                	je     3c00 <fwp_wake_io+0xe0>
    3bb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3bbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3bc2:	48 85 ff             	test   %rdi,%rdi
    3bc5:	74 b8                	je     3b7f <fwp_wake_io+0x5f>
    3bc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3bce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bd5:	48 85 f6             	test   %rsi,%rsi
    3bd8:	0f 85 72 ff ff ff    	jne    3b50 <fwp_wake_io+0x30>
    3bde:	48 89 0f             	mov    %rcx,(%rdi)
    3be1:	e9 78 ff ff ff       	jmp    3b5e <fwp_wake_io+0x3e>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 d3             	mov    %rdx,%rbx
    3bf3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3bf9:	eb ab                	jmp    3ba6 <fwp_wake_io+0x86>
    3bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3c00:	45 84 db             	test   %r11b,%r11b
    3c03:	74 07                	je     3c0c <fwp_wake_io+0xec>
    3c05:	48 89 1d fc aa 01 00 	mov    %rbx,0x1aafc(%rip)        # 1e708 <fwp_ready_head>
    3c0c:	45 84 d2             	test   %r10b,%r10b
    3c0f:	74 07                	je     3c18 <fwp_wake_io+0xf8>
    3c11:	4c 89 05 e8 aa 01 00 	mov    %r8,0x1aae8(%rip)        # 1e700 <fwp_ready_tail>
    3c18:	5b                   	pop    %rbx
    3c19:	c3                   	ret
    3c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3c20:	c3                   	ret
    3c21:	0f 1f 40 00          	nopl   0x0(%rax)
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_poll_events>:
    3c30:	53                   	push   %rbx
    3c31:	48 83 ec 20          	sub    $0x20,%rsp
    3c35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3c3c:	00 00 
    3c3e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3c43:	31 c0                	xor    %eax,%eax
    3c45:	e8 e6 f5 ff ff       	call   3230 <fwp_now_ns>
    3c4a:	48 8b 1d a7 aa 01 00 	mov    0x1aaa7(%rip),%rbx        # 1e6f8 <fwp_timers>
    3c51:	48 85 db             	test   %rbx,%rbx
    3c54:	0f 84 e6 00 00 00    	je     3d40 <fwp_poll_events+0x110>
    3c5a:	48 89 c6             	mov    %rax,%rsi
    3c5d:	48 89 da             	mov    %rbx,%rdx
    3c60:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3c67:	eb 26                	jmp    3c8f <fwp_poll_events+0x5f>
    3c69:	90                   	nop
    3c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c71:	00 00 00 00 
    3c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c7c:	00 00 00 00 
    3c80:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c87:	48 89 c8             	mov    %rcx,%rax
    3c8a:	48 85 d2             	test   %rdx,%rdx
    3c8d:	74 31                	je     3cc0 <fwp_poll_events+0x90>
    3c8f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c93:	48 85 c0             	test   %rax,%rax
    3c96:	78 e8                	js     3c80 <fwp_poll_events+0x50>
    3c98:	48 39 c1             	cmp    %rax,%rcx
    3c9b:	7c e3                	jl     3c80 <fwp_poll_events+0x50>
    3c9d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3ca4:	48 85 d2             	test   %rdx,%rdx
    3ca7:	74 1c                	je     3cc5 <fwp_poll_events+0x95>
    3ca9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3cad:	48 39 c1             	cmp    %rax,%rcx
    3cb0:	7c ce                	jl     3c80 <fwp_poll_events+0x50>
    3cb2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3cb9:	48 85 d2             	test   %rdx,%rdx
    3cbc:	75 d1                	jne    3c8f <fwp_poll_events+0x5f>
    3cbe:	66 90                	xchg   %ax,%ax
    3cc0:	48 85 c0             	test   %rax,%rax
    3cc3:	78 7b                	js     3d40 <fwp_poll_events+0x110>
    3cc5:	48 29 f0             	sub    %rsi,%rax
    3cc8:	48 89 c1             	mov    %rax,%rcx
    3ccb:	48 85 c0             	test   %rax,%rax
    3cce:	0f 8e 9c 00 00 00    	jle    3d70 <fwp_poll_events+0x140>
    3cd4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3cdb:	de 1b 43 
    3cde:	48 f7 ea             	imul   %rdx
    3ce1:	48 89 c8             	mov    %rcx,%rax
    3ce4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ce8:	48 c1 fa 12          	sar    $0x12,%rdx
    3cec:	48 29 c2             	sub    %rax,%rdx
    3cef:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3cf6:	48 39 c1             	cmp    %rax,%rcx
    3cf9:	0f 95 c0             	setne  %al
    3cfc:	0f b6 c0             	movzbl %al,%eax
    3cff:	48 01 d0             	add    %rdx,%rax
    3d02:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3d08:	0f 8f 32 01 00 00    	jg     3e40 <fwp_poll_events+0x210>
    3d0e:	48 85 c0             	test   %rax,%rax
    3d11:	74 5d                	je     3d70 <fwp_poll_events+0x140>
    3d13:	89 c1                	mov    %eax,%ecx
    3d15:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3d1c:	48 c1 e9 26          	shr    $0x26,%rcx
    3d20:	48 63 d1             	movslq %ecx,%rdx
    3d23:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3d29:	29 c8                	sub    %ecx,%eax
    3d2b:	48 98                	cltq
    3d2d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3d34:	e9 11 01 00 00       	jmp    3e4a <fwp_poll_events+0x21a>
    3d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d40:	e8 7b ee ff ff       	call   2bc0 <fwp_flush>
    3d45:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3d4a:	be 01 00 00 00       	mov    $0x1,%esi
    3d4f:	48 8b 0d 2a a3 00 00 	mov    0xa32a(%rip),%rcx        # e080 <stderr@GLIBC_2.2.5>
    3d56:	48 8d 3d 13 76 00 00 	lea    0x7613(%rip),%rdi        # b370 <_IO_stdin_used+0x370>
    3d5d:	e8 de e8 ff ff       	call   2640 <fwrite@plt>
    3d62:	bf 65 00 00 00       	mov    $0x65,%edi
    3d67:	e8 c4 e8 ff ff       	call   2630 <exit@plt>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	e8 bb f4 ff ff       	call   3230 <fwp_now_ns>
    3d75:	48 89 c1             	mov    %rax,%rcx
    3d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3d7c:	eb 44                	jmp    3dc2 <fwp_poll_events+0x192>
    3d7e:	66 90                	xchg   %ax,%ax
    3d80:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3d84:	75 33                	jne    3db9 <fwp_poll_events+0x189>
    3d86:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8a:	75 2d                	jne    3db9 <fwp_poll_events+0x189>
    3d8c:	48 8b 05 6d a9 01 00 	mov    0x1a96d(%rip),%rax        # 1e700 <fwp_ready_tail>
    3d93:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3d97:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3d9e:	00 00 00 00 
    3da2:	48 85 c0             	test   %rax,%rax
    3da5:	0f 84 05 01 00 00    	je     3eb0 <fwp_poll_events+0x280>
    3dab:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3db2:	48 89 15 47 a9 01 00 	mov    %rdx,0x1a947(%rip)        # 1e700 <fwp_ready_tail>
    3db9:	48 85 db             	test   %rbx,%rbx
    3dbc:	0f 84 be 00 00 00    	je     3e80 <fwp_poll_events+0x250>
    3dc2:	48 89 da             	mov    %rbx,%rdx
    3dc5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3dcc:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3dd0:	7f e7                	jg     3db9 <fwp_poll_events+0x189>
    3dd2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3dd6:	74 2e                	je     3e06 <fwp_poll_events+0x1d6>
    3dd8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3ddf:	48 85 c0             	test   %rax,%rax
    3de2:	0f 84 b8 00 00 00    	je     3ea0 <fwp_poll_events+0x270>
    3de8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3def:	48 85 db             	test   %rbx,%rbx
    3df2:	74 07                	je     3dfb <fwp_poll_events+0x1cb>
    3df4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3dfb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3dff:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3e06:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3e0a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3e0e:	48 85 c0             	test   %rax,%rax
    3e11:	0f 84 69 ff ff ff    	je     3d80 <fwp_poll_events+0x150>
    3e17:	48 39 c8             	cmp    %rcx,%rax
    3e1a:	0f 8f 60 ff ff ff    	jg     3d80 <fwp_poll_events+0x150>
    3e20:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3e24:	0f 85 56 ff ff ff    	jne    3d80 <fwp_poll_events+0x150>
    3e2a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2e:	75 89                	jne    3db9 <fwp_poll_events+0x189>
    3e30:	48 89 d7             	mov    %rdx,%rdi
    3e33:	e8 b8 f1 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    3e38:	e9 43 ff ff ff       	jmp    3d80 <fwp_poll_events+0x150>
    3e3d:	0f 1f 00             	nopl   (%rax)
    3e40:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3e45:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3e4a:	48 89 e7             	mov    %rsp,%rdi
    3e4d:	31 f6                	xor    %esi,%esi
    3e4f:	48 89 14 24          	mov    %rdx,(%rsp)
    3e53:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3e58:	e8 23 e6 ff ff       	call   2480 <nanosleep@plt>
    3e5d:	48 8b 1d 94 a8 01 00 	mov    0x1a894(%rip),%rbx        # 1e6f8 <fwp_timers>
    3e64:	e8 c7 f3 ff ff       	call   3230 <fwp_now_ns>
    3e69:	48 89 c1             	mov    %rax,%rcx
    3e6c:	48 85 db             	test   %rbx,%rbx
    3e6f:	0f 85 03 ff ff ff    	jne    3d78 <fwp_poll_events+0x148>
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3e85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3e8c:	00 00 
    3e8e:	75 2c                	jne    3ebc <fwp_poll_events+0x28c>
    3e90:	48 83 c4 20          	add    $0x20,%rsp
    3e94:	5b                   	pop    %rbx
    3e95:	c3                   	ret
    3e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3e9d:	00 00 00 
    3ea0:	48 89 1d 51 a8 01 00 	mov    %rbx,0x1a851(%rip)        # 1e6f8 <fwp_timers>
    3ea7:	e9 43 ff ff ff       	jmp    3def <fwp_poll_events+0x1bf>
    3eac:	0f 1f 40 00          	nopl   0x0(%rax)
    3eb0:	48 89 15 51 a8 01 00 	mov    %rdx,0x1a851(%rip)        # 1e708 <fwp_ready_head>
    3eb7:	e9 f6 fe ff ff       	jmp    3db2 <fwp_poll_events+0x182>
    3ebc:	e8 7f e5 ff ff       	call   2440 <__stack_chk_fail@plt>
    3ec1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ecc:	00 00 00 00 

0000000000003ed0 <fwp_rc_forget_slot>:
    3ed0:	80 3f ff             	cmpb   $0xff,(%rdi)
    3ed3:	74 0b                	je     3ee0 <fwp_rc_forget_slot+0x10>
    3ed5:	c3                   	ret
    3ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3edd:	00 00 00 
    3ee0:	48 89 f8             	mov    %rdi,%rax
    3ee3:	48 83 ec 08          	sub    $0x8,%rsp
    3ee7:	48 89 fa             	mov    %rdi,%rdx
    3eea:	48 c1 e8 11          	shr    $0x11,%rax
    3eee:	48 31 f8             	xor    %rdi,%rax
    3ef1:	48 89 c1             	mov    %rax,%rcx
    3ef4:	48 c1 e9 09          	shr    $0x9,%rcx
    3ef8:	48 31 c8             	xor    %rcx,%rax
    3efb:	48 8d 0d 3e a8 01 00 	lea    0x1a83e(%rip),%rcx        # 1e740 <fwp_heap>
    3f02:	0f b6 c0             	movzbl %al,%eax
    3f05:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f0c:	00 
    3f0d:	48 85 ff             	test   %rdi,%rdi
    3f10:	74 3c                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f12:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f19:	00 
    3f1a:	48 8b 01             	mov    (%rcx),%rax
    3f1d:	eb 11                	jmp    3f30 <fwp_rc_forget_slot+0x60>
    3f1f:	90                   	nop
    3f20:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3f24:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3f28:	48 85 ff             	test   %rdi,%rdi
    3f2b:	74 21                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f2d:	48 89 f8             	mov    %rdi,%rax
    3f30:	48 3b 10             	cmp    (%rax),%rdx
    3f33:	75 eb                	jne    3f20 <fwp_rc_forget_slot+0x50>
    3f35:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f39:	48 89 01             	mov    %rax,(%rcx)
    3f3c:	e8 5f e4 ff ff       	call   23a0 <free@plt>
    3f41:	48 83 2d 3f c4 01 00 	subq   $0x1,0x1c43f(%rip)        # 20388 <fwp_heap+0x1c48>
    3f48:	01 
    3f49:	48 83 c4 08          	add    $0x8,%rsp
    3f4d:	c3                   	ret
    3f4e:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    3f55:	e8 a6 f2 ff ff       	call   3200 <fwp_trap>
    3f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f60 <fwp_rc_prepare_chunk>:
    3f60:	48 83 3d 20 c4 01 00 	cmpq   $0x0,0x1c420(%rip)        # 20388 <fwp_heap+0x1c48>
    3f67:	00 
    3f68:	41 54                	push   %r12
    3f6a:	49 89 f4             	mov    %rsi,%r12
    3f6d:	55                   	push   %rbp
    3f6e:	48 89 fd             	mov    %rdi,%rbp
    3f71:	53                   	push   %rbx
    3f72:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3f75:	0f 84 7d 00 00 00    	je     3ff8 <fwp_rc_prepare_chunk+0x98>
    3f7b:	31 db                	xor    %ebx,%ebx
    3f7d:	85 c0                	test   %eax,%eax
    3f7f:	75 5f                	jne    3fe0 <fwp_rc_prepare_chunk+0x80>
    3f81:	48 85 f6             	test   %rsi,%rsi
    3f84:	74 7c                	je     4002 <fwp_rc_prepare_chunk+0xa2>
    3f86:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3f8a:	e8 11 e4 ff ff       	call   23a0 <free@plt>
    3f8f:	90                   	nop
    3f90:	be 01 00 00 00       	mov    $0x1,%esi
    3f95:	4c 89 e7             	mov    %r12,%rdi
    3f98:	e8 63 e5 ff ff       	call   2500 <calloc@plt>
    3f9d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3fa1:	48 85 c0             	test   %rax,%rax
    3fa4:	0f 85 87 00 00 00    	jne    4031 <fwp_rc_prepare_chunk+0xd1>
    3faa:	e8 41 ed ff ff       	call   2cf0 <fwp_heap_oom>
    3faf:	90                   	nop
    3fb0:	e8 1b ff ff ff       	call   3ed0 <fwp_rc_forget_slot>
    3fb5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fb8:	48 83 c3 01          	add    $0x1,%rbx
    3fbc:	48 39 c3             	cmp    %rax,%rbx
    3fbf:	73 37                	jae    3ff8 <fwp_rc_prepare_chunk+0x98>
    3fc1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fc8:	00 00 
    3fca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fd1:	00 00 00 00 
    3fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fdc:	00 00 00 00 
    3fe0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3fe4:	48 01 df             	add    %rbx,%rdi
    3fe7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3fea:	74 c4                	je     3fb0 <fwp_rc_prepare_chunk+0x50>
    3fec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fef:	48 83 c3 01          	add    $0x1,%rbx
    3ff3:	48 39 c3             	cmp    %rax,%rbx
    3ff6:	72 e8                	jb     3fe0 <fwp_rc_prepare_chunk+0x80>
    3ff8:	49 39 c4             	cmp    %rax,%r12
    3ffb:	75 13                	jne    4010 <fwp_rc_prepare_chunk+0xb0>
    3ffd:	4d 85 e4             	test   %r12,%r12
    4000:	75 46                	jne    4048 <fwp_rc_prepare_chunk+0xe8>
    4002:	5b                   	pop    %rbx
    4003:	5d                   	pop    %rbp
    4004:	41 5c                	pop    %r12
    4006:	c3                   	ret
    4007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    400e:	00 00 
    4010:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4014:	48 29 05 75 c3 01 00 	sub    %rax,0x1c375(%rip)        # 20390 <fwp_heap+0x1c50>
    401b:	e8 80 e3 ff ff       	call   23a0 <free@plt>
    4020:	4d 85 e4             	test   %r12,%r12
    4023:	0f 85 67 ff ff ff    	jne    3f90 <fwp_rc_prepare_chunk+0x30>
    4029:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    4030:	00 
    4031:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    4035:	5b                   	pop    %rbx
    4036:	4c 01 25 53 c3 01 00 	add    %r12,0x1c353(%rip)        # 20390 <fwp_heap+0x1c50>
    403d:	5d                   	pop    %rbp
    403e:	41 5c                	pop    %r12
    4040:	c3                   	ret
    4041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4048:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    404c:	5b                   	pop    %rbx
    404d:	4c 89 e2             	mov    %r12,%rdx
    4050:	31 f6                	xor    %esi,%esi
    4052:	5d                   	pop    %rbp
    4053:	41 5c                	pop    %r12
    4055:	e9 46 e4 ff ff       	jmp    24a0 <memset@plt>
    405a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004060 <fwp_heap_refill>:
    4060:	41 56                	push   %r14
    4062:	41 89 d6             	mov    %edx,%r14d
    4065:	41 55                	push   %r13
    4067:	41 89 f5             	mov    %esi,%r13d
    406a:	41 54                	push   %r12
    406c:	49 89 fc             	mov    %rdi,%r12
    406f:	bf 01 00 00 00       	mov    $0x1,%edi
    4074:	55                   	push   %rbp
    4075:	53                   	push   %rbx
    4076:	e8 b5 ec ff ff       	call   2d30 <fwp_heap_chunks>
    407b:	48 89 c3             	mov    %rax,%rbx
    407e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4082:	48 8b 05 af ba 01 00 	mov    0x1baaf(%rip),%rax        # 1fb38 <fwp_heap+0x13f8>
    4089:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    408d:	48 8d 05 ac a6 01 00 	lea    0x1a6ac(%rip),%rax        # 1e740 <fwp_heap>
    4094:	31 d2                	xor    %edx,%edx
    4096:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    409a:	48 89 ef             	mov    %rbp,%rdi
    409d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    40a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    40a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    40ac:	00 
    40ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    40b2:	f7 f1                	div    %ecx
    40b4:	31 d2                	xor    %edx,%edx
    40b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    40ba:	66 0f 6e c8          	movd   %eax,%xmm1
    40be:	89 c6                	mov    %eax,%esi
    40c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    40c5:	48 01 c8             	add    %rcx,%rax
    40c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    40cc:	48 f7 f1             	div    %rcx
    40cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    40d4:	89 45 18             	mov    %eax,0x18(%rbp)
    40d7:	e8 84 fe ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    40dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    40df:	48 89 d8             	mov    %rbx,%rax
    40e2:	48 c1 e0 10          	shl    $0x10,%rax
    40e6:	48 03 05 03 ba 01 00 	add    0x1ba03(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    40ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    40f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    40f6:	8b 55 08             	mov    0x8(%rbp),%edx
    40f9:	48 0f af d1          	imul   %rcx,%rdx
    40fd:	48 01 c2             	add    %rax,%rdx
    4100:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4105:	5b                   	pop    %rbx
    4106:	5d                   	pop    %rbp
    4107:	41 5c                	pop    %r12
    4109:	41 5d                	pop    %r13
    410b:	41 5e                	pop    %r14
    410d:	c3                   	ret
    410e:	66 90                	xchg   %ax,%ax

0000000000004110 <fwp_mem_free>:
    4110:	48 85 ff             	test   %rdi,%rdi
    4113:	0f 84 17 02 00 00    	je     4330 <fwp_mem_free+0x220>
    4119:	48 8b 35 d0 b9 01 00 	mov    0x1b9d0(%rip),%rsi        # 1faf0 <fwp_heap+0x13b0>
    4120:	48 8b 05 f1 b9 01 00 	mov    0x1b9f1(%rip),%rax        # 1fb18 <fwp_heap+0x13d8>
    4127:	48 89 fa             	mov    %rdi,%rdx
    412a:	48 29 f2             	sub    %rsi,%rdx
    412d:	48 c1 e0 10          	shl    $0x10,%rax
    4131:	48 39 c2             	cmp    %rax,%rdx
    4134:	0f 83 f6 01 00 00    	jae    4330 <fwp_mem_free+0x220>
    413a:	49 89 d1             	mov    %rdx,%r9
    413d:	49 c1 e9 10          	shr    $0x10,%r9
    4141:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4145:	48 c1 e0 03          	shl    $0x3,%rax
    4149:	49 89 c0             	mov    %rax,%r8
    414c:	4c 03 05 e5 b9 01 00 	add    0x1b9e5(%rip),%r8        # 1fb38 <fwp_heap+0x13f8>
    4153:	0f 84 d7 01 00 00    	je     4330 <fwp_mem_free+0x220>
    4159:	48 83 ec 38          	sub    $0x38,%rsp
    415d:	48 89 f9             	mov    %rdi,%rcx
    4160:	41 0f b6 38          	movzbl (%r8),%edi
    4164:	40 80 ff 01          	cmp    $0x1,%dil
    4168:	74 16                	je     4180 <fwp_mem_free+0x70>
    416a:	40 80 ff 02          	cmp    $0x2,%dil
    416e:	0f 84 94 00 00 00    	je     4208 <fwp_mem_free+0xf8>
    4174:	48 83 c4 38          	add    $0x38,%rsp
    4178:	c3                   	ret
    4179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4180:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4184:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4189:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    418e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4192:	4d 85 d2             	test   %r10,%r10
    4195:	74 1d                	je     41b4 <fwp_mem_free+0xa4>
    4197:	0f b7 c1             	movzwl %cx,%eax
    419a:	31 d2                	xor    %edx,%edx
    419c:	48 f7 f7             	div    %rdi
    419f:	49 01 c2             	add    %rax,%r10
    41a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    41a6:	0f 84 44 01 00 00    	je     42f0 <fwp_mem_free+0x1e0>
    41ac:	41 c6 02 00          	movb   $0x0,(%r10)
    41b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    41b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    41bb:	49 63 c1             	movslq %r9d,%rax
    41be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    41c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    41c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    41cb:	f2 0f 58 05 ad b9 01 	addsd  0x1b9ad(%rip),%xmm0        # 1fb80 <fwp_heap+0x1440>
    41d2:	00 
    41d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    41d7:	48 8d 05 62 a5 01 00 	lea    0x1a562(%rip),%rax        # 1e740 <fwp_heap>
    41de:	48 01 d0             	add    %rdx,%rax
    41e1:	48 8b 10             	mov    (%rax),%rdx
    41e4:	48 f7 d2             	not    %rdx
    41e7:	48 89 11             	mov    %rdx,(%rcx)
    41ea:	48 89 08             	mov    %rcx,(%rax)
    41ed:	48 29 3d 6c b9 01 00 	sub    %rdi,0x1b96c(%rip)        # 1fb60 <fwp_heap+0x1420>
    41f4:	f2 0f 11 05 84 b9 01 	movsd  %xmm0,0x1b984(%rip)        # 1fb80 <fwp_heap+0x1440>
    41fb:	00 
    41fc:	48 83 c4 38          	add    $0x38,%rsp
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	66 31 d2             	xor    %dx,%dx
    420b:	48 01 d6             	add    %rdx,%rsi
    420e:	48 39 f1             	cmp    %rsi,%rcx
    4211:	0f 85 5d ff ff ff    	jne    4174 <fwp_mem_free+0x64>
    4217:	49 8b 50 10          	mov    0x10(%r8),%rdx
    421b:	48 29 15 3e b9 01 00 	sub    %rdx,0x1b93e(%rip)        # 1fb60 <fwp_heap+0x1420>
    4222:	48 85 d2             	test   %rdx,%rdx
    4225:	0f 88 a5 00 00 00    	js     42d0 <fwp_mem_free+0x1c0>
    422b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    422f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4234:	f2 0f 58 05 44 b9 01 	addsd  0x1b944(%rip),%xmm0        # 1fb80 <fwp_heap+0x1440>
    423b:	00 
    423c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4240:	f2 0f 11 05 38 b9 01 	movsd  %xmm0,0x1b938(%rip)        # 1fb80 <fwp_heap+0x1440>
    4247:	00 
    4248:	48 85 d2             	test   %rdx,%rdx
    424b:	74 0c                	je     4259 <fwp_mem_free+0x149>
    424d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4250:	0f 84 db 00 00 00    	je     4331 <fwp_mem_free+0x221>
    4256:	c6 02 00             	movb   $0x0,(%rdx)
    4259:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    425d:	48 85 c9             	test   %rcx,%rcx
    4260:	74 3e                	je     42a0 <fwp_mem_free+0x190>
    4262:	48 8b 15 cf b8 01 00 	mov    0x1b8cf(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    4269:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    426d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4271:	48 01 d0             	add    %rdx,%rax
    4274:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4278:	48 89 d6             	mov    %rdx,%rsi
    427b:	48 29 c6             	sub    %rax,%rsi
    427e:	83 e6 08             	and    $0x8,%esi
    4281:	74 0d                	je     4290 <fwp_mem_free+0x180>
    4283:	c6 00 00             	movb   $0x0,(%rax)
    4286:	48 83 c0 28          	add    $0x28,%rax
    428a:	48 39 c2             	cmp    %rax,%rdx
    428d:	74 11                	je     42a0 <fwp_mem_free+0x190>
    428f:	90                   	nop
    4290:	c6 00 00             	movb   $0x0,(%rax)
    4293:	48 83 c0 50          	add    $0x50,%rax
    4297:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    429b:	48 39 c2             	cmp    %rax,%rdx
    429e:	75 f0                	jne    4290 <fwp_mem_free+0x180>
    42a0:	48 01 0d c9 b8 01 00 	add    %rcx,0x1b8c9(%rip)        # 1fb70 <fwp_heap+0x1430>
    42a7:	4c 3b 0d 82 b8 01 00 	cmp    0x1b882(%rip),%r9        # 1fb30 <fwp_heap+0x13f0>
    42ae:	73 07                	jae    42b7 <fwp_mem_free+0x1a7>
    42b0:	4c 89 0d 79 b8 01 00 	mov    %r9,0x1b879(%rip)        # 1fb30 <fwp_heap+0x13f0>
    42b7:	4c 3b 0d 6a b8 01 00 	cmp    0x1b86a(%rip),%r9        # 1fb28 <fwp_heap+0x13e8>
    42be:	0f 83 b0 fe ff ff    	jae    4174 <fwp_mem_free+0x64>
    42c4:	4c 89 0d 5d b8 01 00 	mov    %r9,0x1b85d(%rip)        # 1fb28 <fwp_heap+0x13e8>
    42cb:	e9 a4 fe ff ff       	jmp    4174 <fwp_mem_free+0x64>
    42d0:	48 89 d1             	mov    %rdx,%rcx
    42d3:	83 e2 01             	and    $0x1,%edx
    42d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42da:	48 d1 e9             	shr    $1,%rcx
    42dd:	48 09 d1             	or     %rdx,%rcx
    42e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    42e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    42e9:	e9 46 ff ff ff       	jmp    4234 <fwp_mem_free+0x124>
    42ee:	66 90                	xchg   %ax,%ax
    42f0:	4c 89 d7             	mov    %r10,%rdi
    42f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    42f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    42fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4302:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4306:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    430b:	e8 c0 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4310:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4315:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    431a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    431f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    4324:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    4329:	e9 7e fe ff ff       	jmp    41ac <fwp_mem_free+0x9c>
    432e:	66 90                	xchg   %ax,%ax
    4330:	c3                   	ret
    4331:	48 89 d7             	mov    %rdx,%rdi
    4334:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    4339:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    433e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4343:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4348:	e8 83 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    434d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4352:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4357:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    435c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4361:	e9 f0 fe ff ff       	jmp    4256 <fwp_mem_free+0x146>
    4366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    436d:	00 00 00 

0000000000004370 <fwp_heap_alloc_big>:
    4370:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4377:	00 00 40 
    437a:	41 57                	push   %r15
    437c:	41 56                	push   %r14
    437e:	41 55                	push   %r13
    4380:	41 54                	push   %r12
    4382:	55                   	push   %rbp
    4383:	53                   	push   %rbx
    4384:	48 83 ec 08          	sub    $0x8,%rsp
    4388:	48 39 f8             	cmp    %rdi,%rax
    438b:	0f 82 fa 00 00 00    	jb     448b <fwp_heap_alloc_big+0x11b>
    4391:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4398:	49 89 fd             	mov    %rdi,%r13
    439b:	41 89 f6             	mov    %esi,%r14d
    439e:	48 c1 ed 10          	shr    $0x10,%rbp
    43a2:	48 89 ef             	mov    %rbp,%rdi
    43a5:	e8 86 e9 ff ff       	call   2d30 <fwp_heap_chunks>
    43aa:	be 01 00 00 00       	mov    $0x1,%esi
    43af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    43b3:	49 89 c4             	mov    %rax,%r12
    43b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    43bd:	00 
    43be:	48 03 3d 73 b7 01 00 	add    0x1b773(%rip),%rdi        # 1fb38 <fwp_heap+0x13f8>
    43c5:	c6 07 02             	movb   $0x2,(%rdi)
    43c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    43cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    43cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    43d3:	e8 88 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    43d8:	48 83 fd 01          	cmp    $0x1,%rbp
    43dc:	76 47                	jbe    4425 <fwp_heap_alloc_big+0xb5>
    43de:	4c 01 e5             	add    %r12,%rbp
    43e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    43e8:	00 
    43e9:	4c 8d 3d 50 a3 01 00 	lea    0x1a350(%rip),%r15        # 1e740 <fwp_heap>
    43f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    43f5:	49 c1 e6 03          	shl    $0x3,%r14
    43f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4400:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4407:	31 f6                	xor    %esi,%esi
    4409:	48 01 dd             	add    %rbx,%rbp
    440c:	48 83 c3 28          	add    $0x28,%rbx
    4410:	48 89 ef             	mov    %rbp,%rdi
    4413:	e8 48 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    4418:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    441c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    4420:	49 39 de             	cmp    %rbx,%r14
    4423:	75 db                	jne    4400 <fwp_heap_alloc_big+0x90>
    4425:	49 c1 e4 10          	shl    $0x10,%r12
    4429:	4c 03 25 c0 b6 01 00 	add    0x1b6c0(%rip),%r12        # 1faf0 <fwp_heap+0x13b0>
    4430:	4c 89 ea             	mov    %r13,%rdx
    4433:	31 f6                	xor    %esi,%esi
    4435:	4c 89 e7             	mov    %r12,%rdi
    4438:	e8 63 e0 ff ff       	call   24a0 <memset@plt>
    443d:	4c 89 e8             	mov    %r13,%rax
    4440:	48 03 05 19 b7 01 00 	add    0x1b719(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    4447:	72 42                	jb     448b <fwp_heap_alloc_big+0x11b>
    4449:	48 39 05 18 b7 01 00 	cmp    %rax,0x1b718(%rip)        # 1fb68 <fwp_heap+0x1428>
    4450:	48 89 05 09 b7 01 00 	mov    %rax,0x1b709(%rip)        # 1fb60 <fwp_heap+0x1420>
    4457:	73 07                	jae    4460 <fwp_heap_alloc_big+0xf0>
    4459:	48 89 05 08 b7 01 00 	mov    %rax,0x1b708(%rip)        # 1fb68 <fwp_heap+0x1428>
    4460:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4464:	4c 89 e0             	mov    %r12,%rax
    4467:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    446c:	f2 0f 58 05 04 b7 01 	addsd  0x1b704(%rip),%xmm0        # 1fb78 <fwp_heap+0x1438>
    4473:	00 
    4474:	f2 0f 11 05 fc b6 01 	movsd  %xmm0,0x1b6fc(%rip)        # 1fb78 <fwp_heap+0x1438>
    447b:	00 
    447c:	48 83 c4 08          	add    $0x8,%rsp
    4480:	5b                   	pop    %rbx
    4481:	5d                   	pop    %rbp
    4482:	41 5c                	pop    %r12
    4484:	41 5d                	pop    %r13
    4486:	41 5e                	pop    %r14
    4488:	41 5f                	pop    %r15
    448a:	c3                   	ret
    448b:	e8 60 e8 ff ff       	call   2cf0 <fwp_heap_oom>

0000000000004490 <fwp_heap_alloc_slow>:
    4490:	53                   	push   %rbx
    4491:	48 89 f9             	mov    %rdi,%rcx
    4494:	41 89 f1             	mov    %esi,%r9d
    4497:	48 83 ec 10          	sub    $0x10,%rsp
    449b:	8b 05 43 b6 01 00    	mov    0x1b643(%rip),%eax        # 1fae4 <fwp_heap+0x13a4>
    44a1:	85 c0                	test   %eax,%eax
    44a3:	0f 84 c7 00 00 00    	je     4570 <fwp_heap_alloc_slow+0xe0>
    44a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    44b0:	0f 87 dd 00 00 00    	ja     4593 <fwp_heap_alloc_slow+0x103>
    44b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    44ba:	48 8d 3d 7f a2 01 00 	lea    0x1a27f(%rip),%rdi        # 1e740 <fwp_heap>
    44c1:	49 63 f1             	movslq %r9d,%rsi
    44c4:	48 c1 e8 04          	shr    $0x4,%rax
    44c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    44cf:	00 00 
    44d1:	41 0f b6 c2          	movzbl %r10b,%eax
    44d5:	4c 89 d2             	mov    %r10,%rdx
    44d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    44dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    44e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    44ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    44ee:	48 01 f8             	add    %rdi,%rax
    44f1:	4c 8b 00             	mov    (%rax),%r8
    44f4:	4d 85 c0             	test   %r8,%r8
    44f7:	0f 84 ab 00 00 00    	je     45a8 <fwp_heap_alloc_slow+0x118>
    44fd:	49 8b 10             	mov    (%r8),%rdx
    4500:	48 f7 d2             	not    %rdx
    4503:	48 89 10             	mov    %rdx,(%rax)
    4506:	41 83 f9 01          	cmp    $0x1,%r9d
    450a:	4c 89 c7             	mov    %r8,%rdi
    450d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4511:	31 f6                	xor    %esi,%esi
    4513:	48 89 ca             	mov    %rcx,%rdx
    4516:	e8 85 df ff ff       	call   24a0 <memset@plt>
    451b:	49 89 c0             	mov    %rax,%r8
    451e:	48 89 d8             	mov    %rbx,%rax
    4521:	48 03 05 38 b6 01 00 	add    0x1b638(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    4528:	0f 82 d9 00 00 00    	jb     4607 <fwp_heap_alloc_slow+0x177>
    452e:	48 39 05 33 b6 01 00 	cmp    %rax,0x1b633(%rip)        # 1fb68 <fwp_heap+0x1428>
    4535:	48 89 05 24 b6 01 00 	mov    %rax,0x1b624(%rip)        # 1fb60 <fwp_heap+0x1420>
    453c:	73 07                	jae    4545 <fwp_heap_alloc_slow+0xb5>
    453e:	48 89 05 23 b6 01 00 	mov    %rax,0x1b623(%rip)        # 1fb68 <fwp_heap+0x1428>
    4545:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4549:	4c 89 c0             	mov    %r8,%rax
    454c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4551:	f2 0f 58 05 1f b6 01 	addsd  0x1b61f(%rip),%xmm0        # 1fb78 <fwp_heap+0x1438>
    4558:	00 
    4559:	f2 0f 11 05 17 b6 01 	movsd  %xmm0,0x1b617(%rip)        # 1fb78 <fwp_heap+0x1438>
    4560:	00 
    4561:	48 83 c4 10          	add    $0x10,%rsp
    4565:	5b                   	pop    %rbx
    4566:	c3                   	ret
    4567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    456e:	00 00 
    4570:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4574:	48 89 3c 24          	mov    %rdi,(%rsp)
    4578:	e8 b3 f3 ff ff       	call   3930 <fwp_heap_init>
    457d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4581:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4586:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    458d:	0f 86 23 ff ff ff    	jbe    44b6 <fwp_heap_alloc_slow+0x26>
    4593:	48 83 c4 10          	add    $0x10,%rsp
    4597:	44 89 ce             	mov    %r9d,%esi
    459a:	48 89 cf             	mov    %rcx,%rdi
    459d:	5b                   	pop    %rbx
    459e:	e9 cd fd ff ff       	jmp    4370 <fwp_heap_alloc_big>
    45a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    45ac:	4d 85 c0             	test   %r8,%r8
    45af:	74 1f                	je     45d0 <fwp_heap_alloc_slow+0x140>
    45b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    45b5:	4d 29 c3             	sub    %r8,%r11
    45b8:	49 39 db             	cmp    %rbx,%r11
    45bb:	72 13                	jb     45d0 <fwp_heap_alloc_slow+0x140>
    45bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    45c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    45c5:	e9 3c ff ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    45ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    45d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    45d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    45db:	44 89 ca             	mov    %r9d,%edx
    45de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    45e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    45e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    45eb:	44 89 d6             	mov    %r10d,%esi
    45ee:	48 01 c7             	add    %rax,%rdi
    45f1:	e8 6a fa ff ff       	call   4060 <fwp_heap_refill>
    45f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    45fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    45ff:	49 89 c0             	mov    %rax,%r8
    4602:	e9 ff fe ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    4607:	e8 e4 e6 ff ff       	call   2cf0 <fwp_heap_oom>
    460c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004610 <fwp_rc_fresh>:
    4610:	48 8b 15 01 b5 01 00 	mov    0x1b501(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    4617:	48 89 f8             	mov    %rdi,%rax
    461a:	48 89 fe             	mov    %rdi,%rsi
    461d:	48 2b 05 cc b4 01 00 	sub    0x1b4cc(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    4624:	48 c1 e2 10          	shl    $0x10,%rdx
    4628:	48 39 d0             	cmp    %rdx,%rax
    462b:	73 4f                	jae    467c <fwp_rc_fresh+0x6c>
    462d:	48 89 c2             	mov    %rax,%rdx
    4630:	48 c1 ea 10          	shr    $0x10,%rdx
    4634:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4638:	48 8b 15 f9 b4 01 00 	mov    0x1b4f9(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    463f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4643:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4647:	48 85 d2             	test   %rdx,%rdx
    464a:	74 30                	je     467c <fwp_rc_fresh+0x6c>
    464c:	0f b6 39             	movzbl (%rcx),%edi
    464f:	40 80 ff 02          	cmp    $0x2,%dil
    4653:	74 2b                	je     4680 <fwp_rc_fresh+0x70>
    4655:	40 80 ff 01          	cmp    $0x1,%dil
    4659:	75 21                	jne    467c <fwp_rc_fresh+0x6c>
    465b:	8b 79 18             	mov    0x18(%rcx),%edi
    465e:	0f b7 c0             	movzwl %ax,%eax
    4661:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4664:	48 0f af c7          	imul   %rdi,%rax
    4668:	48 c1 e8 20          	shr    $0x20,%rax
    466c:	48 39 c8             	cmp    %rcx,%rax
    466f:	73 0b                	jae    467c <fwp_rc_fresh+0x6c>
    4671:	48 01 c2             	add    %rax,%rdx
    4674:	80 3a ff             	cmpb   $0xff,(%rdx)
    4677:	74 17                	je     4690 <fwp_rc_fresh+0x80>
    4679:	c6 02 01             	movb   $0x1,(%rdx)
    467c:	48 89 f0             	mov    %rsi,%rax
    467f:	c3                   	ret
    4680:	66 85 c0             	test   %ax,%ax
    4683:	74 ef                	je     4674 <fwp_rc_fresh+0x64>
    4685:	48 89 f0             	mov    %rsi,%rax
    4688:	c3                   	ret
    4689:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4690:	48 83 ec 18          	sub    $0x18,%rsp
    4694:	48 89 d7             	mov    %rdx,%rdi
    4697:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    469c:	48 89 14 24          	mov    %rdx,(%rsp)
    46a0:	e8 2b f8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    46a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    46aa:	48 8b 14 24          	mov    (%rsp),%rdx
    46ae:	48 89 f0             	mov    %rsi,%rax
    46b1:	c6 02 01             	movb   $0x1,(%rdx)
    46b4:	48 83 c4 18          	add    $0x18,%rsp
    46b8:	c3                   	ret
    46b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000046c0 <fwp_rc_free_arr>:
    46c0:	48 8b 15 51 b4 01 00 	mov    0x1b451(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    46c7:	48 89 f8             	mov    %rdi,%rax
    46ca:	48 2b 05 1f b4 01 00 	sub    0x1b41f(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    46d1:	48 c1 e2 10          	shl    $0x10,%rdx
    46d5:	48 39 d0             	cmp    %rdx,%rax
    46d8:	73 5b                	jae    4735 <fwp_rc_free_arr+0x75>
    46da:	48 89 c2             	mov    %rax,%rdx
    46dd:	48 c1 ea 10          	shr    $0x10,%rdx
    46e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    46e5:	48 8b 15 4c b4 01 00 	mov    0x1b44c(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    46ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    46f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    46f4:	48 85 c9             	test   %rcx,%rcx
    46f7:	74 3c                	je     4735 <fwp_rc_free_arr+0x75>
    46f9:	0f b6 32             	movzbl (%rdx),%esi
    46fc:	40 80 fe 02          	cmp    $0x2,%sil
    4700:	74 2e                	je     4730 <fwp_rc_free_arr+0x70>
    4702:	40 80 fe 01          	cmp    $0x1,%sil
    4706:	75 2d                	jne    4735 <fwp_rc_free_arr+0x75>
    4708:	8b 72 18             	mov    0x18(%rdx),%esi
    470b:	0f b7 c0             	movzwl %ax,%eax
    470e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4711:	48 0f af c6          	imul   %rsi,%rax
    4715:	48 c1 e8 20          	shr    $0x20,%rax
    4719:	48 39 d0             	cmp    %rdx,%rax
    471c:	73 17                	jae    4735 <fwp_rc_free_arr+0x75>
    471e:	48 01 c1             	add    %rax,%rcx
    4721:	80 39 01             	cmpb   $0x1,(%rcx)
    4724:	75 0f                	jne    4735 <fwp_rc_free_arr+0x75>
    4726:	e9 e5 f9 ff ff       	jmp    4110 <fwp_mem_free>
    472b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4730:	66 85 c0             	test   %ax,%ax
    4733:	74 ec                	je     4721 <fwp_rc_free_arr+0x61>
    4735:	c3                   	ret
    4736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    473d:	00 00 00 

0000000000004740 <fwp_heap_alloc>:
    4740:	53                   	push   %rbx
    4741:	48 89 fa             	mov    %rdi,%rdx
    4744:	48 83 ec 10          	sub    $0x10,%rsp
    4748:	8b 1d b2 bc 01 00    	mov    0x1bcb2(%rip),%ebx        # 20400 <iteration_active>
    474e:	8b 05 90 b3 01 00    	mov    0x1b390(%rip),%eax        # 1fae4 <fwp_heap+0x13a4>
    4754:	85 db                	test   %ebx,%ebx
    4756:	0f 85 04 01 00 00    	jne    4860 <fwp_heap_alloc+0x120>
    475c:	85 c0                	test   %eax,%eax
    475e:	0f 84 ac 01 00 00    	je     4910 <fwp_heap_alloc+0x1d0>
    4764:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    476b:	0f 87 9f 01 00 00    	ja     4910 <fwp_heap_alloc+0x1d0>
    4771:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4775:	48 8d 05 c4 9f 01 00 	lea    0x19fc4(%rip),%rax        # 1e740 <fwp_heap>
    477c:	48 c1 e9 04          	shr    $0x4,%rcx
    4780:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    4787:	00 
    4788:	48 63 ce             	movslq %esi,%rcx
    478b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4792:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    4799:	00 
    479a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    479e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    47a2:	48 01 c8             	add    %rcx,%rax
    47a5:	48 8b 08             	mov    (%rax),%rcx
    47a8:	48 85 c9             	test   %rcx,%rcx
    47ab:	0f 84 ff 00 00 00    	je     48b0 <fwp_heap_alloc+0x170>
    47b1:	48 8b 39             	mov    (%rcx),%rdi
    47b4:	48 f7 d7             	not    %rdi
    47b7:	48 89 38             	mov    %rdi,(%rax)
    47ba:	83 fe 01             	cmp    $0x1,%esi
    47bd:	48 89 cf             	mov    %rcx,%rdi
    47c0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    47c5:	49 0f 45 d0          	cmovne %r8,%rdx
    47c9:	31 f6                	xor    %esi,%esi
    47cb:	e8 d0 dc ff ff       	call   24a0 <memset@plt>
    47d0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    47d5:	48 89 c1             	mov    %rax,%rcx
    47d8:	4c 89 c0             	mov    %r8,%rax
    47db:	48 03 05 7e b3 01 00 	add    0x1b37e(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    47e2:	0f 82 35 01 00 00    	jb     491d <fwp_heap_alloc+0x1dd>
    47e8:	48 39 05 79 b3 01 00 	cmp    %rax,0x1b379(%rip)        # 1fb68 <fwp_heap+0x1428>
    47ef:	48 89 05 6a b3 01 00 	mov    %rax,0x1b36a(%rip)        # 1fb60 <fwp_heap+0x1420>
    47f6:	73 07                	jae    47ff <fwp_heap_alloc+0xbf>
    47f8:	48 89 05 69 b3 01 00 	mov    %rax,0x1b369(%rip)        # 1fb68 <fwp_heap+0x1428>
    47ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4803:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4808:	f2 0f 58 05 68 b3 01 	addsd  0x1b368(%rip),%xmm0        # 1fb78 <fwp_heap+0x1438>
    480f:	00 
    4810:	f2 0f 11 05 60 b3 01 	movsd  %xmm0,0x1b360(%rip)        # 1fb78 <fwp_heap+0x1438>
    4817:	00 
    4818:	85 db                	test   %ebx,%ebx
    481a:	74 33                	je     484f <fwp_heap_alloc+0x10f>
    481c:	48 8b 05 3d b3 01 00 	mov    0x1b33d(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    4823:	48 85 c0             	test   %rax,%rax
    4826:	0f 88 ac 00 00 00    	js     48d8 <fwp_heap_alloc+0x198>
    482c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4830:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4835:	f2 0f 5c 05 a3 bb 01 	subsd  0x1bba3(%rip),%xmm0        # 203e0 <iteration_start_charge>
    483c:	00 
    483d:	66 0f 2f 05 93 bb 01 	comisd 0x1bb93(%rip),%xmm0        # 203d8 <iteration_peak>
    4844:	00 
    4845:	76 08                	jbe    484f <fwp_heap_alloc+0x10f>
    4847:	f2 0f 11 05 89 bb 01 	movsd  %xmm0,0x1bb89(%rip)        # 203d8 <iteration_peak>
    484e:	00 
    484f:	48 83 c4 10          	add    $0x10,%rsp
    4853:	48 89 c8             	mov    %rcx,%rax
    4856:	5b                   	pop    %rbx
    4857:	c3                   	ret
    4858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    485f:	00 
    4860:	85 f6                	test   %esi,%esi
    4862:	74 34                	je     4898 <fwp_heap_alloc+0x158>
    4864:	48 83 05 8c bb 01 00 	addq   $0x1,0x1bb8c(%rip)        # 203f8 <iteration_requests>
    486b:	01 
    486c:	48 01 3d 7d bb 01 00 	add    %rdi,0x1bb7d(%rip)        # 203f0 <iteration_bytes>
    4873:	85 c0                	test   %eax,%eax
    4875:	74 0d                	je     4884 <fwp_heap_alloc+0x144>
    4877:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    487e:	0f 86 ed fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    4884:	48 89 d7             	mov    %rdx,%rdi
    4887:	e8 04 fc ff ff       	call   4490 <fwp_heap_alloc_slow>
    488c:	48 89 c1             	mov    %rax,%rcx
    488f:	eb 8b                	jmp    481c <fwp_heap_alloc+0xdc>
    4891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4898:	85 c0                	test   %eax,%eax
    489a:	74 0d                	je     48a9 <fwp_heap_alloc+0x169>
    489c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    48a3:	0f 86 c8 fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    48a9:	31 f6                	xor    %esi,%esi
    48ab:	eb d7                	jmp    4884 <fwp_heap_alloc+0x144>
    48ad:	0f 1f 00             	nopl   (%rax)
    48b0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    48b4:	48 85 c9             	test   %rcx,%rcx
    48b7:	74 0c                	je     48c5 <fwp_heap_alloc+0x185>
    48b9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    48bd:	48 29 cf             	sub    %rcx,%rdi
    48c0:	4c 39 c7             	cmp    %r8,%rdi
    48c3:	73 3b                	jae    4900 <fwp_heap_alloc+0x1c0>
    48c5:	48 89 d7             	mov    %rdx,%rdi
    48c8:	e8 c3 fb ff ff       	call   4490 <fwp_heap_alloc_slow>
    48cd:	48 89 c1             	mov    %rax,%rcx
    48d0:	e9 43 ff ff ff       	jmp    4818 <fwp_heap_alloc+0xd8>
    48d5:	0f 1f 00             	nopl   (%rax)
    48d8:	48 89 c2             	mov    %rax,%rdx
    48db:	83 e0 01             	and    $0x1,%eax
    48de:	66 0f ef c0          	pxor   %xmm0,%xmm0
    48e2:	48 d1 ea             	shr    $1,%rdx
    48e5:	48 09 c2             	or     %rax,%rdx
    48e8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    48ed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    48f1:	e9 3f ff ff ff       	jmp    4835 <fwp_heap_alloc+0xf5>
    48f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    48fd:	00 00 00 
    4900:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    4904:	48 89 78 08          	mov    %rdi,0x8(%rax)
    4908:	e9 ad fe ff ff       	jmp    47ba <fwp_heap_alloc+0x7a>
    490d:	0f 1f 00             	nopl   (%rax)
    4910:	48 83 c4 10          	add    $0x10,%rsp
    4914:	48 89 d7             	mov    %rdx,%rdi
    4917:	5b                   	pop    %rbx
    4918:	e9 73 fb ff ff       	jmp    4490 <fwp_heap_alloc_slow>
    491d:	e8 ce e3 ff ff       	call   2cf0 <fwp_heap_oom>
    4922:	0f 1f 00             	nopl   (%rax)
    4925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    492c:	00 00 00 00 

0000000000004930 <fwp_data.part.0.constprop.0>:
    4930:	41 55                	push   %r13
    4932:	41 54                	push   %r12
    4934:	49 89 fc             	mov    %rdi,%r12
    4937:	55                   	push   %rbp
    4938:	53                   	push   %rbx
    4939:	48 83 ec 08          	sub    $0x8,%rsp
    493d:	44 8b 2d bc ba 01 00 	mov    0x1babc(%rip),%r13d        # 20400 <iteration_active>
    4944:	8b 05 9a b1 01 00    	mov    0x1b19a(%rip),%eax        # 1fae4 <fwp_heap+0x13a4>
    494a:	45 85 ed             	test   %r13d,%r13d
    494d:	0f 84 0d 01 00 00    	je     4a60 <fwp_data.part.0.constprop.0+0x130>
    4953:	48 83 05 9d ba 01 00 	addq   $0x1,0x1ba9d(%rip)        # 203f8 <iteration_requests>
    495a:	01 
    495b:	48 83 05 8d ba 01 00 	addq   $0x18,0x1ba8d(%rip)        # 203f0 <iteration_bytes>
    4962:	18 
    4963:	85 c0                	test   %eax,%eax
    4965:	0f 84 7d 01 00 00    	je     4ae8 <fwp_data.part.0.constprop.0+0x1b8>
    496b:	0f b6 05 70 ad 01 00 	movzbl 0x1ad70(%rip),%eax        # 1f6e2 <fwp_heap+0xfa2>
    4972:	48 8d 15 c7 9d 01 00 	lea    0x19dc7(%rip),%rdx        # 1e740 <fwp_heap>
    4979:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    4980:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4984:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    4988:	48 8b 18             	mov    (%rax),%rbx
    498b:	48 85 db             	test   %rbx,%rbx
    498e:	0f 84 ec 00 00 00    	je     4a80 <fwp_data.part.0.constprop.0+0x150>
    4994:	48 8b 13             	mov    (%rbx),%rdx
    4997:	48 f7 d2             	not    %rdx
    499a:	48 89 10             	mov    %rdx,(%rax)
    499d:	48 83 fd 18          	cmp    $0x18,%rbp
    49a1:	76 1b                	jbe    49be <fwp_data.part.0.constprop.0+0x8e>
    49a3:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    49a7:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    49ab:	31 f6                	xor    %esi,%esi
    49ad:	48 c1 e8 03          	shr    $0x3,%rax
    49b1:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    49b8:	00 
    49b9:	e8 e2 da ff ff       	call   24a0 <memset@plt>
    49be:	48 89 e8             	mov    %rbp,%rax
    49c1:	48 03 05 98 b1 01 00 	add    0x1b198(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    49c8:	0f 82 2e 01 00 00    	jb     4afc <fwp_data.part.0.constprop.0+0x1cc>
    49ce:	48 39 05 93 b1 01 00 	cmp    %rax,0x1b193(%rip)        # 1fb68 <fwp_heap+0x1428>
    49d5:	48 89 05 84 b1 01 00 	mov    %rax,0x1b184(%rip)        # 1fb60 <fwp_heap+0x1420>
    49dc:	73 07                	jae    49e5 <fwp_data.part.0.constprop.0+0xb5>
    49de:	48 89 05 83 b1 01 00 	mov    %rax,0x1b183(%rip)        # 1fb68 <fwp_heap+0x1428>
    49e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49e9:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    49ee:	f2 0f 58 05 82 b1 01 	addsd  0x1b182(%rip),%xmm0        # 1fb78 <fwp_heap+0x1438>
    49f5:	00 
    49f6:	f2 0f 11 05 7a b1 01 	movsd  %xmm0,0x1b17a(%rip)        # 1fb78 <fwp_heap+0x1438>
    49fd:	00 
    49fe:	45 85 ed             	test   %r13d,%r13d
    4a01:	74 33                	je     4a36 <fwp_data.part.0.constprop.0+0x106>
    4a03:	48 8b 05 56 b1 01 00 	mov    0x1b156(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    4a0a:	48 85 c0             	test   %rax,%rax
    4a0d:	0f 88 95 00 00 00    	js     4aa8 <fwp_data.part.0.constprop.0+0x178>
    4a13:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4a17:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4a1c:	f2 0f 5c 05 bc b9 01 	subsd  0x1b9bc(%rip),%xmm0        # 203e0 <iteration_start_charge>
    4a23:	00 
    4a24:	66 0f 2f 05 ac b9 01 	comisd 0x1b9ac(%rip),%xmm0        # 203d8 <iteration_peak>
    4a2b:	00 
    4a2c:	76 08                	jbe    4a36 <fwp_data.part.0.constprop.0+0x106>
    4a2e:	f2 0f 11 05 a2 b9 01 	movsd  %xmm0,0x1b9a2(%rip)        # 203d8 <iteration_peak>
    4a35:	00 
    4a36:	48 8b 05 f3 6b 00 00 	mov    0x6bf3(%rip),%rax        # b630 <msg.3+0x60>
    4a3d:	48 89 03             	mov    %rax,(%rbx)
    4a40:	49 8b 04 24          	mov    (%r12),%rax
    4a44:	48 89 43 08          	mov    %rax,0x8(%rbx)
    4a48:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    4a4d:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4a51:	48 83 c4 08          	add    $0x8,%rsp
    4a55:	48 89 d8             	mov    %rbx,%rax
    4a58:	5b                   	pop    %rbx
    4a59:	5d                   	pop    %rbp
    4a5a:	41 5c                	pop    %r12
    4a5c:	41 5d                	pop    %r13
    4a5e:	c3                   	ret
    4a5f:	90                   	nop
    4a60:	85 c0                	test   %eax,%eax
    4a62:	0f 85 03 ff ff ff    	jne    496b <fwp_data.part.0.constprop.0+0x3b>
    4a68:	31 f6                	xor    %esi,%esi
    4a6a:	bf 18 00 00 00       	mov    $0x18,%edi
    4a6f:	e8 cc fc ff ff       	call   4740 <fwp_heap_alloc>
    4a74:	48 89 c3             	mov    %rax,%rbx
    4a77:	eb bd                	jmp    4a36 <fwp_data.part.0.constprop.0+0x106>
    4a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a80:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4a84:	48 85 db             	test   %rbx,%rbx
    4a87:	74 47                	je     4ad0 <fwp_data.part.0.constprop.0+0x1a0>
    4a89:	48 8b 50 10          	mov    0x10(%rax),%rdx
    4a8d:	48 29 da             	sub    %rbx,%rdx
    4a90:	48 39 ea             	cmp    %rbp,%rdx
    4a93:	72 3b                	jb     4ad0 <fwp_data.part.0.constprop.0+0x1a0>
    4a95:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4a99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4a9d:	e9 fb fe ff ff       	jmp    499d <fwp_data.part.0.constprop.0+0x6d>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	48 89 c2             	mov    %rax,%rdx
    4aab:	83 e0 01             	and    $0x1,%eax
    4aae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4ab2:	48 d1 ea             	shr    $1,%rdx
    4ab5:	48 09 c2             	or     %rax,%rdx
    4ab8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4abd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4ac1:	e9 56 ff ff ff       	jmp    4a1c <fwp_data.part.0.constprop.0+0xec>
    4ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4acd:	00 00 00 
    4ad0:	31 f6                	xor    %esi,%esi
    4ad2:	bf 18 00 00 00       	mov    $0x18,%edi
    4ad7:	e8 64 fc ff ff       	call   4740 <fwp_heap_alloc>
    4adc:	48 89 c3             	mov    %rax,%rbx
    4adf:	e9 1a ff ff ff       	jmp    49fe <fwp_data.part.0.constprop.0+0xce>
    4ae4:	0f 1f 40 00          	nopl   0x0(%rax)
    4ae8:	31 f6                	xor    %esi,%esi
    4aea:	bf 18 00 00 00       	mov    $0x18,%edi
    4aef:	e8 4c fc ff ff       	call   4740 <fwp_heap_alloc>
    4af4:	48 89 c3             	mov    %rax,%rbx
    4af7:	e9 07 ff ff ff       	jmp    4a03 <fwp_data.part.0.constprop.0+0xd3>
    4afc:	e8 ef e1 ff ff       	call   2cf0 <fwp_heap_oom>
    4b01:	0f 1f 40 00          	nopl   0x0(%rax)
    4b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b0c:	00 00 00 00 

0000000000004b10 <fwp_array_new_packed.constprop.0>:
    4b10:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4b17:	ff ff 1f 
    4b1a:	53                   	push   %rbx
    4b1b:	48 39 f8             	cmp    %rdi,%rax
    4b1e:	72 1a                	jb     4b3a <fwp_array_new_packed.constprop.0+0x2a>
    4b20:	48 89 fb             	mov    %rdi,%rbx
    4b23:	be 01 00 00 00       	mov    $0x1,%esi
    4b28:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    4b2f:	00 
    4b30:	e8 0b fc ff ff       	call   4740 <fwp_heap_alloc>
    4b35:	48 89 18             	mov    %rbx,(%rax)
    4b38:	5b                   	pop    %rbx
    4b39:	c3                   	ret
    4b3a:	48 8d 3d a4 65 00 00 	lea    0x65a4(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    4b41:	e8 ba e6 ff ff       	call   3200 <fwp_trap>
    4b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4b4d:	00 00 00 

0000000000004b50 <fwp_task_dispose>:
    4b50:	53                   	push   %rbx
    4b51:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4b55:	0f 84 ab db ff ff    	je     2706 <fwp_task_dispose.cold>
    4b5b:	48 89 fb             	mov    %rdi,%rbx
    4b5e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4b63:	0f 85 9d db ff ff    	jne    2706 <fwp_task_dispose.cold>
    4b69:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    4b6d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4b74:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    4b7b:	00 
    4b7c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4b80:	48 85 ff             	test   %rdi,%rdi
    4b83:	74 07                	je     4b8c <fwp_task_dispose+0x3c>
    4b85:	48 85 c0             	test   %rax,%rax
    4b88:	74 02                	je     4b8c <fwp_task_dispose+0x3c>
    4b8a:	ff d0                	call   *%rax
    4b8c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4b93:	e8 78 f5 ff ff       	call   4110 <fwp_mem_free>
    4b98:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    4b9f:	00 00 00 00 
    4ba3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4ba7:	74 6f                	je     4c18 <fwp_task_dispose+0xc8>
    4ba9:	48 8b 15 68 af 01 00 	mov    0x1af68(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    4bb0:	48 89 d8             	mov    %rbx,%rax
    4bb3:	48 2b 05 36 af 01 00 	sub    0x1af36(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    4bba:	48 c1 e2 10          	shl    $0x10,%rdx
    4bbe:	48 39 d0             	cmp    %rdx,%rax
    4bc1:	73 4c                	jae    4c0f <fwp_task_dispose+0xbf>
    4bc3:	48 89 c2             	mov    %rax,%rdx
    4bc6:	48 c1 ea 10          	shr    $0x10,%rdx
    4bca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4bce:	48 8b 15 63 af 01 00 	mov    0x1af63(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    4bd5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4bd9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4bdd:	48 85 c9             	test   %rcx,%rcx
    4be0:	74 2d                	je     4c0f <fwp_task_dispose+0xbf>
    4be2:	0f b6 32             	movzbl (%rdx),%esi
    4be5:	40 80 fe 02          	cmp    $0x2,%sil
    4be9:	74 3d                	je     4c28 <fwp_task_dispose+0xd8>
    4beb:	40 80 fe 01          	cmp    $0x1,%sil
    4bef:	75 1e                	jne    4c0f <fwp_task_dispose+0xbf>
    4bf1:	8b 72 18             	mov    0x18(%rdx),%esi
    4bf4:	0f b7 c0             	movzwl %ax,%eax
    4bf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4bfa:	48 0f af c6          	imul   %rsi,%rax
    4bfe:	48 c1 e8 20          	shr    $0x20,%rax
    4c02:	48 39 d0             	cmp    %rdx,%rax
    4c05:	73 08                	jae    4c0f <fwp_task_dispose+0xbf>
    4c07:	48 01 c1             	add    %rax,%rcx
    4c0a:	80 39 01             	cmpb   $0x1,(%rcx)
    4c0d:	74 09                	je     4c18 <fwp_task_dispose+0xc8>
    4c0f:	5b                   	pop    %rbx
    4c10:	c3                   	ret
    4c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c18:	48 89 df             	mov    %rbx,%rdi
    4c1b:	5b                   	pop    %rbx
    4c1c:	e9 ef f4 ff ff       	jmp    4110 <fwp_mem_free>
    4c21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c28:	66 85 c0             	test   %ax,%ax
    4c2b:	74 dd                	je     4c0a <fwp_task_dispose+0xba>
    4c2d:	5b                   	pop    %rbx
    4c2e:	c3                   	ret
    4c2f:	90                   	nop

0000000000004c30 <fwp_free_zombie>:
    4c30:	48 8b 15 d9 9a 01 00 	mov    0x19ad9(%rip),%rdx        # 1e710 <fwp_zombie>
    4c37:	48 85 d2             	test   %rdx,%rdx
    4c3a:	0f 84 98 00 00 00    	je     4cd8 <fwp_free_zombie+0xa8>
    4c40:	48 3b 15 d9 9a 01 00 	cmp    0x19ad9(%rip),%rdx        # 1e720 <fwp_cur>
    4c47:	0f 84 8b 00 00 00    	je     4cd8 <fwp_free_zombie+0xa8>
    4c4d:	48 83 ec 18          	sub    $0x18,%rsp
    4c51:	48 63 05 8c 94 01 00 	movslq 0x1948c(%rip),%rax        # 1e0e4 <fwp_stack_pool_n>
    4c58:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4c5c:	83 f8 3f             	cmp    $0x3f,%eax
    4c5f:	7f 7f                	jg     4ce0 <fwp_free_zombie+0xb0>
    4c61:	8d 48 01             	lea    0x1(%rax),%ecx
    4c64:	89 0d 7a 94 01 00    	mov    %ecx,0x1947a(%rip)        # 1e0e4 <fwp_stack_pool_n>
    4c6a:	48 8d 0d 8f 94 01 00 	lea    0x1948f(%rip),%rcx        # 1e100 <fwp_stack_pool>
    4c71:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4c75:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4c7c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4c80:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4c87:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4c8b:	48 85 c9             	test   %rcx,%rcx
    4c8e:	0f 84 fc 00 00 00    	je     4d90 <fwp_free_zombie+0x160>
    4c94:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4c9b:	48 85 c0             	test   %rax,%rax
    4c9e:	74 07                	je     4ca7 <fwp_free_zombie+0x77>
    4ca0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4ca7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4caa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4cae:	48 c7 05 57 9a 01 00 	movq   $0x0,0x19a57(%rip)        # 1e710 <fwp_zombie>
    4cb5:	00 00 00 00 
    4cb9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4cc0:	85 c0                	test   %eax,%eax
    4cc2:	74 34                	je     4cf8 <fwp_free_zombie+0xc8>
    4cc4:	83 f8 01             	cmp    $0x1,%eax
    4cc7:	0f 84 b3 00 00 00    	je     4d80 <fwp_free_zombie+0x150>
    4ccd:	48 83 c4 18          	add    $0x18,%rsp
    4cd1:	c3                   	ret
    4cd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4cd8:	c3                   	ret
    4cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ce0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4ce4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4ce9:	e8 c2 d8 ff ff       	call   25b0 <munmap@plt>
    4cee:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4cf3:	eb 80                	jmp    4c75 <fwp_free_zombie+0x45>
    4cf5:	0f 1f 00             	nopl   (%rax)
    4cf8:	48 8b 0d 19 ae 01 00 	mov    0x1ae19(%rip),%rcx        # 1fb18 <fwp_heap+0x13d8>
    4cff:	48 89 d0             	mov    %rdx,%rax
    4d02:	48 2b 05 e7 ad 01 00 	sub    0x1ade7(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    4d09:	48 c1 e1 10          	shl    $0x10,%rcx
    4d0d:	48 39 c8             	cmp    %rcx,%rax
    4d10:	73 bb                	jae    4ccd <fwp_free_zombie+0x9d>
    4d12:	48 89 c1             	mov    %rax,%rcx
    4d15:	48 c1 e9 10          	shr    $0x10,%rcx
    4d19:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4d1d:	48 8b 0d 14 ae 01 00 	mov    0x1ae14(%rip),%rcx        # 1fb38 <fwp_heap+0x13f8>
    4d24:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4d28:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4d2c:	48 85 c9             	test   %rcx,%rcx
    4d2f:	74 9c                	je     4ccd <fwp_free_zombie+0x9d>
    4d31:	0f b6 3e             	movzbl (%rsi),%edi
    4d34:	40 80 ff 02          	cmp    $0x2,%dil
    4d38:	74 66                	je     4da0 <fwp_free_zombie+0x170>
    4d3a:	40 80 ff 01          	cmp    $0x1,%dil
    4d3e:	75 8d                	jne    4ccd <fwp_free_zombie+0x9d>
    4d40:	8b 7e 18             	mov    0x18(%rsi),%edi
    4d43:	0f b7 c0             	movzwl %ax,%eax
    4d46:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4d49:	48 0f af c7          	imul   %rdi,%rax
    4d4d:	48 c1 e8 20          	shr    $0x20,%rax
    4d51:	48 39 f0             	cmp    %rsi,%rax
    4d54:	0f 83 73 ff ff ff    	jae    4ccd <fwp_free_zombie+0x9d>
    4d5a:	48 01 c1             	add    %rax,%rcx
    4d5d:	0f b6 01             	movzbl (%rcx),%eax
    4d60:	84 c0                	test   %al,%al
    4d62:	0f 84 65 ff ff ff    	je     4ccd <fwp_free_zombie+0x9d>
    4d68:	3c 01                	cmp    $0x1,%al
    4d6a:	74 14                	je     4d80 <fwp_free_zombie+0x150>
    4d6c:	3c ff                	cmp    $0xff,%al
    4d6e:	74 3b                	je     4dab <fwp_free_zombie+0x17b>
    4d70:	83 e8 01             	sub    $0x1,%eax
    4d73:	88 01                	mov    %al,(%rcx)
    4d75:	e9 53 ff ff ff       	jmp    4ccd <fwp_free_zombie+0x9d>
    4d7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d80:	48 89 d7             	mov    %rdx,%rdi
    4d83:	48 83 c4 18          	add    $0x18,%rsp
    4d87:	e9 c4 fd ff ff       	jmp    4b50 <fwp_task_dispose>
    4d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    4d90:	48 89 05 51 99 01 00 	mov    %rax,0x19951(%rip)        # 1e6e8 <fwp_tasks_active>
    4d97:	e9 ff fe ff ff       	jmp    4c9b <fwp_free_zombie+0x6b>
    4d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    4da0:	66 85 c0             	test   %ax,%ax
    4da3:	0f 85 24 ff ff ff    	jne    4ccd <fwp_free_zombie+0x9d>
    4da9:	eb b2                	jmp    4d5d <fwp_free_zombie+0x12d>
    4dab:	48 89 ca             	mov    %rcx,%rdx
    4dae:	48 8d 35 8b 99 01 00 	lea    0x1998b(%rip),%rsi        # 1e740 <fwp_heap>
    4db5:	48 c1 ea 11          	shr    $0x11,%rdx
    4db9:	48 31 ca             	xor    %rcx,%rdx
    4dbc:	48 89 d0             	mov    %rdx,%rax
    4dbf:	48 c1 e8 09          	shr    $0x9,%rax
    4dc3:	48 31 c2             	xor    %rax,%rdx
    4dc6:	0f b6 d2             	movzbl %dl,%edx
    4dc9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4dd0:	00 
    4dd1:	48 85 c0             	test   %rax,%rax
    4dd4:	75 13                	jne    4de9 <fwp_free_zombie+0x1b9>
    4dd6:	eb 4c                	jmp    4e24 <fwp_free_zombie+0x1f4>
    4dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4ddf:	00 
    4de0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4de4:	48 85 c0             	test   %rax,%rax
    4de7:	74 3b                	je     4e24 <fwp_free_zombie+0x1f4>
    4de9:	48 89 c2             	mov    %rax,%rdx
    4dec:	48 39 08             	cmp    %rcx,(%rax)
    4def:	75 ef                	jne    4de0 <fwp_free_zombie+0x1b0>
    4df1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4df5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4df9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4dfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4e04:	0f 85 c3 fe ff ff    	jne    4ccd <fwp_free_zombie+0x9d>
    4e0a:	48 89 cf             	mov    %rcx,%rdi
    4e0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e12:	e8 b9 f0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4e17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4e1f:	e9 a9 fe ff ff       	jmp    4ccd <fwp_free_zombie+0x9d>
    4e24:	48 8d 3d 75 65 00 00 	lea    0x6575(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    4e2b:	e8 d0 e3 ff ff       	call   3200 <fwp_trap>

0000000000004e30 <fwp_block>:
    4e30:	48 83 ec 08          	sub    $0x8,%rsp
    4e34:	48 8b 05 cd 98 01 00 	mov    0x198cd(%rip),%rax        # 1e708 <fwp_ready_head>
    4e3b:	48 85 c0             	test   %rax,%rax
    4e3e:	0f 84 1c 01 00 00    	je     4f60 <fwp_block+0x130>
    4e44:	90                   	nop
    4e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e4c:	00 00 00 00 
    4e50:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4e57:	48 89 15 aa 98 01 00 	mov    %rdx,0x198aa(%rip)        # 1e708 <fwp_ready_head>
    4e5e:	48 85 d2             	test   %rdx,%rdx
    4e61:	0f 84 19 01 00 00    	je     4f80 <fwp_block+0x150>
    4e67:	48 8b 15 b2 98 01 00 	mov    0x198b2(%rip),%rdx        # 1e720 <fwp_cur>
    4e6e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4e72:	48 39 c2             	cmp    %rax,%rdx
    4e75:	0f 84 d5 00 00 00    	je     4f50 <fwp_block+0x120>
    4e7b:	48 8b 0d 1e b5 01 00 	mov    0x1b51e(%rip),%rcx        # 203a0 <fwp_state_owners>
    4e82:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4e86:	48 89 05 93 98 01 00 	mov    %rax,0x19893(%rip)        # 1e720 <fwp_cur>
    4e8d:	f3 0f 7e 05 33 b5 01 	movq   0x1b533(%rip),%xmm0        # 203c8 <fwp_foreign_callbacks>
    4e94:	00 
    4e95:	0f 16 05 1c b5 01 00 	movhps 0x1b51c(%rip),%xmm0        # 203b8 <fwp_state>
    4e9c:	f3 0f 7e 0d 1c b5 01 	movq   0x1b51c(%rip),%xmm1        # 203c0 <fwp_handlers>
    4ea3:	00 
    4ea4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4eab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4eb2:	0f 16 0d 17 b5 01 00 	movhps 0x1b517(%rip),%xmm1        # 203d0 <fwp_cleanups>
    4eb9:	f3 0f 7e 05 ef b4 01 	movq   0x1b4ef(%rip),%xmm0        # 203b0 <fwp_state_len>
    4ec0:	00 
    4ec1:	0f 16 05 e0 b4 01 00 	movhps 0x1b4e0(%rip),%xmm0        # 203a8 <fwp_state_cap>
    4ec8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4ecf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4ed6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4eda:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4ee1:	48 89 0d d8 b4 01 00 	mov    %rcx,0x1b4d8(%rip)        # 203c0 <fwp_handlers>
    4ee8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4eef:	48 89 0d da b4 01 00 	mov    %rcx,0x1b4da(%rip)        # 203d0 <fwp_cleanups>
    4ef6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4efd:	48 89 0d c4 b4 01 00 	mov    %rcx,0x1b4c4(%rip)        # 203c8 <fwp_foreign_callbacks>
    4f04:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4f0b:	48 89 0d a6 b4 01 00 	mov    %rcx,0x1b4a6(%rip)        # 203b8 <fwp_state>
    4f12:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4f19:	48 89 0d 90 b4 01 00 	mov    %rcx,0x1b490(%rip)        # 203b0 <fwp_state_len>
    4f20:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4f27:	48 89 0d 7a b4 01 00 	mov    %rcx,0x1b47a(%rip)        # 203a8 <fwp_state_cap>
    4f2e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4f35:	48 89 0d 64 b4 01 00 	mov    %rcx,0x1b464(%rip)        # 203a0 <fwp_state_owners>
    4f3c:	e8 2f d5 ff ff       	call   2470 <swapcontext@plt>
    4f41:	f3 0f 1e fa          	endbr64
    4f45:	e8 e6 fc ff ff       	call   4c30 <fwp_free_zombie>
    4f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f50:	8b 05 8a 91 01 00    	mov    0x1918a(%rip),%eax        # 1e0e0 <fwp_slice>
    4f56:	85 c0                	test   %eax,%eax
    4f58:	74 36                	je     4f90 <fwp_block+0x160>
    4f5a:	48 83 c4 08          	add    $0x8,%rsp
    4f5e:	c3                   	ret
    4f5f:	90                   	nop
    4f60:	e8 cb ec ff ff       	call   3c30 <fwp_poll_events>
    4f65:	48 8b 05 9c 97 01 00 	mov    0x1979c(%rip),%rax        # 1e708 <fwp_ready_head>
    4f6c:	48 85 c0             	test   %rax,%rax
    4f6f:	0f 85 db fe ff ff    	jne    4e50 <fwp_block+0x20>
    4f75:	eb e9                	jmp    4f60 <fwp_block+0x130>
    4f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4f7e:	00 00 
    4f80:	48 c7 05 75 97 01 00 	movq   $0x0,0x19775(%rip)        # 1e700 <fwp_ready_tail>
    4f87:	00 00 00 00 
    4f8b:	e9 d7 fe ff ff       	jmp    4e67 <fwp_block+0x37>
    4f90:	48 8d 3d 5e 61 00 00 	lea    0x615e(%rip),%rdi        # b0f5 <_IO_stdin_used+0xf5>
    4f97:	e8 e4 d3 ff ff       	call   2380 <getenv@plt>
    4f9c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4fa1:	48 85 c0             	test   %rax,%rax
    4fa4:	74 05                	je     4fab <fwp_block+0x17b>
    4fa6:	80 38 00             	cmpb   $0x0,(%rax)
    4fa9:	75 0b                	jne    4fb6 <fwp_block+0x186>
    4fab:	89 15 2f 91 01 00    	mov    %edx,0x1912f(%rip)        # 1e0e0 <fwp_slice>
    4fb1:	48 83 c4 08          	add    $0x8,%rsp
    4fb5:	c3                   	ret
    4fb6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4fbb:	31 f6                	xor    %esi,%esi
    4fbd:	48 89 c7             	mov    %rax,%rdi
    4fc0:	e8 6b d5 ff ff       	call   2530 <strtoll@plt>
    4fc5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4fc9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4fd0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4fd5:	0f 46 d0             	cmovbe %eax,%edx
    4fd8:	eb d1                	jmp    4fab <fwp_block+0x17b>
    4fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004fe0 <fwp_drop0>:
    4fe0:	48 8b 15 31 ab 01 00 	mov    0x1ab31(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    4fe7:	48 89 f8             	mov    %rdi,%rax
    4fea:	48 2b 05 ff aa 01 00 	sub    0x1aaff(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    4ff1:	48 c1 e2 10          	shl    $0x10,%rdx
    4ff5:	48 39 d0             	cmp    %rdx,%rax
    4ff8:	0f 83 c2 00 00 00    	jae    50c0 <fwp_drop0+0xe0>
    4ffe:	48 83 ec 18          	sub    $0x18,%rsp
    5002:	4c 8d 05 37 97 01 00 	lea    0x19737(%rip),%r8        # 1e740 <fwp_heap>
    5009:	48 89 c2             	mov    %rax,%rdx
    500c:	48 c1 ea 10          	shr    $0x10,%rdx
    5010:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5014:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    501b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    501f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5023:	48 85 d2             	test   %rdx,%rdx
    5026:	74 3c                	je     5064 <fwp_drop0+0x84>
    5028:	0f b6 31             	movzbl (%rcx),%esi
    502b:	40 80 fe 02          	cmp    $0x2,%sil
    502f:	74 3f                	je     5070 <fwp_drop0+0x90>
    5031:	40 80 fe 01          	cmp    $0x1,%sil
    5035:	75 2d                	jne    5064 <fwp_drop0+0x84>
    5037:	8b 71 18             	mov    0x18(%rcx),%esi
    503a:	0f b7 c0             	movzwl %ax,%eax
    503d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5040:	48 0f af c6          	imul   %rsi,%rax
    5044:	48 c1 e8 20          	shr    $0x20,%rax
    5048:	48 39 c8             	cmp    %rcx,%rax
    504b:	73 17                	jae    5064 <fwp_drop0+0x84>
    504d:	48 01 c2             	add    %rax,%rdx
    5050:	0f b6 02             	movzbl (%rdx),%eax
    5053:	84 c0                	test   %al,%al
    5055:	74 0d                	je     5064 <fwp_drop0+0x84>
    5057:	3c 01                	cmp    $0x1,%al
    5059:	74 25                	je     5080 <fwp_drop0+0xa0>
    505b:	3c ff                	cmp    $0xff,%al
    505d:	74 69                	je     50c8 <fwp_drop0+0xe8>
    505f:	83 e8 01             	sub    $0x1,%eax
    5062:	88 02                	mov    %al,(%rdx)
    5064:	48 83 c4 18          	add    $0x18,%rsp
    5068:	c3                   	ret
    5069:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5070:	66 85 c0             	test   %ax,%ax
    5073:	74 db                	je     5050 <fwp_drop0+0x70>
    5075:	48 83 c4 18          	add    $0x18,%rsp
    5079:	c3                   	ret
    507a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5080:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    5084:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5089:	e8 32 f6 ff ff       	call   46c0 <fwp_rc_free_arr>
    508e:	4c 8d 05 ab 96 01 00 	lea    0x196ab(%rip),%r8        # 1e740 <fwp_heap>
    5095:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    509a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    50a1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    50a8:	48 c1 e2 10          	shl    $0x10,%rdx
    50ac:	48 39 d0             	cmp    %rdx,%rax
    50af:	73 b3                	jae    5064 <fwp_drop0+0x84>
    50b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    50b6:	e9 4e ff ff ff       	jmp    5009 <fwp_drop0+0x29>
    50bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c8:	48 89 d0             	mov    %rdx,%rax
    50cb:	48 c1 e8 11          	shr    $0x11,%rax
    50cf:	48 31 d0             	xor    %rdx,%rax
    50d2:	48 89 c1             	mov    %rax,%rcx
    50d5:	48 c1 e9 09          	shr    $0x9,%rcx
    50d9:	48 31 c8             	xor    %rcx,%rax
    50dc:	0f b6 c8             	movzbl %al,%ecx
    50df:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    50e6:	00 
    50e7:	48 85 c0             	test   %rax,%rax
    50ea:	75 1d                	jne    5109 <fwp_drop0+0x129>
    50ec:	eb 56                	jmp    5144 <fwp_drop0+0x164>
    50ee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50fc:	00 00 00 00 
    5100:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5104:	48 85 c0             	test   %rax,%rax
    5107:	74 3b                	je     5144 <fwp_drop0+0x164>
    5109:	48 89 c1             	mov    %rax,%rcx
    510c:	48 39 10             	cmp    %rdx,(%rax)
    510f:	75 ef                	jne    5100 <fwp_drop0+0x120>
    5111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5115:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5119:	48 89 48 08          	mov    %rcx,0x8(%rax)
    511d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5124:	0f 85 3a ff ff ff    	jne    5064 <fwp_drop0+0x84>
    512a:	48 89 d7             	mov    %rdx,%rdi
    512d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5132:	e8 99 ed ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5137:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    513c:	c6 02 fe             	movb   $0xfe,(%rdx)
    513f:	e9 20 ff ff ff       	jmp    5064 <fwp_drop0+0x84>
    5144:	48 8d 3d 55 62 00 00 	lea    0x6255(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    514b:	e8 b0 e0 ff ff       	call   3200 <fwp_trap>

0000000000005150 <fwp_drop1>:
    5150:	f3 0f 1e fa          	endbr64
    5154:	48 8b 15 bd a9 01 00 	mov    0x1a9bd(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    515b:	48 89 f8             	mov    %rdi,%rax
    515e:	48 2b 05 8b a9 01 00 	sub    0x1a98b(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    5165:	48 c1 e2 10          	shl    $0x10,%rdx
    5169:	48 39 d0             	cmp    %rdx,%rax
    516c:	0f 83 be 00 00 00    	jae    5230 <fwp_drop1+0xe0>
    5172:	48 83 ec 18          	sub    $0x18,%rsp
    5176:	4c 8d 05 c3 95 01 00 	lea    0x195c3(%rip),%r8        # 1e740 <fwp_heap>
    517d:	48 89 c2             	mov    %rax,%rdx
    5180:	48 c1 ea 10          	shr    $0x10,%rdx
    5184:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5188:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    518f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5193:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5197:	48 85 d2             	test   %rdx,%rdx
    519a:	74 3c                	je     51d8 <fwp_drop1+0x88>
    519c:	0f b6 31             	movzbl (%rcx),%esi
    519f:	40 80 fe 02          	cmp    $0x2,%sil
    51a3:	74 3b                	je     51e0 <fwp_drop1+0x90>
    51a5:	40 80 fe 01          	cmp    $0x1,%sil
    51a9:	75 2d                	jne    51d8 <fwp_drop1+0x88>
    51ab:	8b 71 18             	mov    0x18(%rcx),%esi
    51ae:	0f b7 c0             	movzwl %ax,%eax
    51b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    51b4:	48 0f af c6          	imul   %rsi,%rax
    51b8:	48 c1 e8 20          	shr    $0x20,%rax
    51bc:	48 39 c8             	cmp    %rcx,%rax
    51bf:	73 17                	jae    51d8 <fwp_drop1+0x88>
    51c1:	48 01 c2             	add    %rax,%rdx
    51c4:	0f b6 02             	movzbl (%rdx),%eax
    51c7:	84 c0                	test   %al,%al
    51c9:	74 0d                	je     51d8 <fwp_drop1+0x88>
    51cb:	3c 01                	cmp    $0x1,%al
    51cd:	74 21                	je     51f0 <fwp_drop1+0xa0>
    51cf:	3c ff                	cmp    $0xff,%al
    51d1:	74 65                	je     5238 <fwp_drop1+0xe8>
    51d3:	83 e8 01             	sub    $0x1,%eax
    51d6:	88 02                	mov    %al,(%rdx)
    51d8:	48 83 c4 18          	add    $0x18,%rsp
    51dc:	c3                   	ret
    51dd:	0f 1f 00             	nopl   (%rax)
    51e0:	66 85 c0             	test   %ax,%ax
    51e3:	74 df                	je     51c4 <fwp_drop1+0x74>
    51e5:	48 83 c4 18          	add    $0x18,%rsp
    51e9:	c3                   	ret
    51ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51f0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    51f4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    51f9:	e8 c2 f4 ff ff       	call   46c0 <fwp_rc_free_arr>
    51fe:	4c 8d 05 3b 95 01 00 	lea    0x1953b(%rip),%r8        # 1e740 <fwp_heap>
    5205:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    520a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    5211:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    5218:	48 c1 e2 10          	shl    $0x10,%rdx
    521c:	48 39 d0             	cmp    %rdx,%rax
    521f:	73 b7                	jae    51d8 <fwp_drop1+0x88>
    5221:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    5226:	e9 52 ff ff ff       	jmp    517d <fwp_drop1+0x2d>
    522b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5230:	c3                   	ret
    5231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5238:	48 89 d0             	mov    %rdx,%rax
    523b:	48 c1 e8 11          	shr    $0x11,%rax
    523f:	48 31 d0             	xor    %rdx,%rax
    5242:	48 89 c1             	mov    %rax,%rcx
    5245:	48 c1 e9 09          	shr    $0x9,%rcx
    5249:	48 31 c8             	xor    %rcx,%rax
    524c:	0f b6 c8             	movzbl %al,%ecx
    524f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    5256:	00 
    5257:	48 85 c0             	test   %rax,%rax
    525a:	75 0d                	jne    5269 <fwp_drop1+0x119>
    525c:	eb 46                	jmp    52a4 <fwp_drop1+0x154>
    525e:	66 90                	xchg   %ax,%ax
    5260:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5264:	48 85 c0             	test   %rax,%rax
    5267:	74 3b                	je     52a4 <fwp_drop1+0x154>
    5269:	48 89 c1             	mov    %rax,%rcx
    526c:	48 39 10             	cmp    %rdx,(%rax)
    526f:	75 ef                	jne    5260 <fwp_drop1+0x110>
    5271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5275:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5279:	48 89 48 08          	mov    %rcx,0x8(%rax)
    527d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5284:	0f 85 4e ff ff ff    	jne    51d8 <fwp_drop1+0x88>
    528a:	48 89 d7             	mov    %rdx,%rdi
    528d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5292:	e8 39 ec ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5297:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    529c:	c6 02 fe             	movb   $0xfe,(%rdx)
    529f:	e9 34 ff ff ff       	jmp    51d8 <fwp_drop1+0x88>
    52a4:	48 8d 3d f5 60 00 00 	lea    0x60f5(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    52ab:	e8 50 df ff ff       	call   3200 <fwp_trap>

00000000000052b0 <fwp_write.constprop.0>:
    52b0:	41 57                	push   %r15
    52b2:	41 56                	push   %r14
    52b4:	41 55                	push   %r13
    52b6:	41 54                	push   %r12
    52b8:	55                   	push   %rbp
    52b9:	53                   	push   %rbx
    52ba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    52c1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    52c8:	00 00 
    52ca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    52d1:	00 
    52d2:	49 89 d4             	mov    %rdx,%r12
    52d5:	8b 12                	mov    (%rdx),%edx
    52d7:	83 fa 19             	cmp    $0x19,%edx
    52da:	77 64                	ja     5340 <fwp_write.constprop.0+0x90>
    52dc:	48 8d 0d 7d 62 00 00 	lea    0x627d(%rip),%rcx        # b560 <_IO_stdin_used+0x560>
    52e3:	89 d0                	mov    %edx,%eax
    52e5:	48 89 fb             	mov    %rdi,%rbx
    52e8:	48 89 f5             	mov    %rsi,%rbp
    52eb:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    52ef:	48 01 c8             	add    %rcx,%rax
    52f2:	3e ff e0             	notrack jmp *%rax
    52f5:	0f 1f 00             	nopl   (%rax)
    52f8:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    52fc:	48 8b 06             	mov    (%rsi),%rax
    52ff:	48 89 ca             	mov    %rcx,%rdx
    5302:	48 85 c9             	test   %rcx,%rcx
    5305:	0f 88 b5 0c 00 00    	js     5fc0 <fwp_write.constprop.0+0xd10>
    530b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5312:	00 
    5313:	48 89 c6             	mov    %rax,%rsi
    5316:	4c 89 e7             	mov    %r12,%rdi
    5319:	e8 e2 d6 ff ff       	call   2a00 <fwp_fmt_u128>
    531e:	66 90                	xchg   %ax,%ax
    5320:	4c 89 e7             	mov    %r12,%rdi
    5323:	e8 08 d1 ff ff       	call   2430 <strlen@plt>
    5328:	4c 89 e6             	mov    %r12,%rsi
    532b:	48 89 df             	mov    %rbx,%rdi
    532e:	48 89 c2             	mov    %rax,%rdx
    5331:	e8 7a dc ff ff       	call   2fb0 <buf_put>
    5336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    533d:	00 00 00 
    5340:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5347:	00 
    5348:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    534f:	00 00 
    5351:	0f 85 9e 04 00 00    	jne    57f5 <fwp_write.constprop.0+0x545>
    5357:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    535e:	5b                   	pop    %rbx
    535f:	5d                   	pop    %rbp
    5360:	41 5c                	pop    %r12
    5362:	41 5d                	pop    %r13
    5364:	41 5e                	pop    %r14
    5366:	41 5f                	pop    %r15
    5368:	c3                   	ret
    5369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5370:	49 89 f1             	mov    %rsi,%r9
    5373:	4c 8d 05 a3 5d 00 00 	lea    0x5da3(%rip),%r8        # b11d <_IO_stdin_used+0x11d>
    537a:	b9 00 02 00 00       	mov    $0x200,%ecx
    537f:	ba 02 00 00 00       	mov    $0x2,%edx
    5384:	be 00 02 00 00       	mov    $0x200,%esi
    5389:	31 c0                	xor    %eax,%eax
    538b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5392:	00 
    5393:	e8 f8 cf ff ff       	call   2390 <__snprintf_chk@plt>
    5398:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    539f:	00 
    53a0:	e8 8b d0 ff ff       	call   2430 <strlen@plt>
    53a5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    53ac:	00 
    53ad:	48 89 df             	mov    %rbx,%rdi
    53b0:	48 89 c2             	mov    %rax,%rdx
    53b3:	e8 f8 db ff ff       	call   2fb0 <buf_put>
    53b8:	eb 86                	jmp    5340 <fwp_write.constprop.0+0x90>
    53ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    53c0:	49 89 f1             	mov    %rsi,%r9
    53c3:	4c 8d 05 4e 5d 00 00 	lea    0x5d4e(%rip),%r8        # b118 <_IO_stdin_used+0x118>
    53ca:	eb ae                	jmp    537a <fwp_write.constprop.0+0xca>
    53cc:	0f 1f 40 00          	nopl   0x0(%rax)
    53d0:	83 fa 13             	cmp    $0x13,%edx
    53d3:	48 8d 05 34 5d 00 00 	lea    0x5d34(%rip),%rax        # b10e <_IO_stdin_used+0x10e>
    53da:	48 8d 35 32 5d 00 00 	lea    0x5d32(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    53e1:	ba 04 00 00 00       	mov    $0x4,%edx
    53e6:	48 0f 44 f0          	cmove  %rax,%rsi
    53ea:	45 31 ed             	xor    %r13d,%r13d
    53ed:	e8 be db ff ff       	call   2fb0 <buf_put>
    53f2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    53f7:	0f 84 b3 09 00 00    	je     5db0 <fwp_write.constprop.0+0xb00>
    53fd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5402:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5407:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    540c:	48 89 df             	mov    %rbx,%rdi
    540f:	49 0f 44 c5          	cmove  %r13,%rax
    5413:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5418:	e8 93 fe ff ff       	call   52b0 <fwp_write.constprop.0>
    541d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5422:	0f 84 80 0a 00 00    	je     5ea8 <fwp_write.constprop.0+0xbf8>
    5428:	49 83 c5 01          	add    $0x1,%r13
    542c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5430:	0f 83 7a 09 00 00    	jae    5db0 <fwp_write.constprop.0+0xb00>
    5436:	ba 02 00 00 00       	mov    $0x2,%edx
    543b:	48 8d 35 1b 5d 00 00 	lea    0x5d1b(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5442:	48 89 df             	mov    %rbx,%rdi
    5445:	e8 66 db ff ff       	call   2fb0 <buf_put>
    544a:	eb b1                	jmp    53fd <fwp_write.constprop.0+0x14d>
    544c:	0f 1f 40 00          	nopl   0x0(%rax)
    5450:	ba 06 00 00 00       	mov    $0x6,%edx
    5455:	48 8d 35 da 5c 00 00 	lea    0x5cda(%rip),%rsi        # b136 <_IO_stdin_used+0x136>
    545c:	48 83 c5 10          	add    $0x10,%rbp
    5460:	e8 4b db ff ff       	call   2fb0 <buf_put>
    5465:	48 89 ef             	mov    %rbp,%rdi
    5468:	e8 c3 cf ff ff       	call   2430 <strlen@plt>
    546d:	48 89 ee             	mov    %rbp,%rsi
    5470:	48 89 df             	mov    %rbx,%rdi
    5473:	48 89 c2             	mov    %rax,%rdx
    5476:	e8 35 db ff ff       	call   2fb0 <buf_put>
    547b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5480:	ba 01 00 00 00       	mov    $0x1,%edx
    5485:	48 89 df             	mov    %rbx,%rdi
    5488:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    548d:	e8 1e db ff ff       	call   2fb0 <buf_put>
    5492:	e9 a9 fe ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    549e:	00 00 
    54a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    54a7:	00 
    54a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    54af:	00 00 
    54b1:	0f 85 3e 03 00 00    	jne    57f5 <fwp_write.constprop.0+0x545>
    54b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    54bc:	48 8d 35 5f 5c 00 00 	lea    0x5c5f(%rip),%rsi        # b122 <_IO_stdin_used+0x122>
    54c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    54ca:	48 89 df             	mov    %rbx,%rdi
    54cd:	5b                   	pop    %rbx
    54ce:	5d                   	pop    %rbp
    54cf:	41 5c                	pop    %r12
    54d1:	41 5d                	pop    %r13
    54d3:	41 5e                	pop    %r14
    54d5:	41 5f                	pop    %r15
    54d7:	e9 d4 da ff ff       	jmp    2fb0 <buf_put>
    54dc:	0f 1f 40 00          	nopl   0x0(%rax)
    54e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    54e5:	4d 85 ed             	test   %r13,%r13
    54e8:	0f 84 c2 0b 00 00    	je     60b0 <fwp_write.constprop.0+0xe00>
    54ee:	48 8d 35 75 5c 00 00 	lea    0x5c75(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    54f5:	4c 89 ef             	mov    %r13,%rdi
    54f8:	e8 13 d0 ff ff       	call   2510 <strcmp@plt>
    54fd:	41 89 c1             	mov    %eax,%r9d
    5500:	85 c0                	test   %eax,%eax
    5502:	0f 84 2c 0c 00 00    	je     6134 <fwp_write.constprop.0+0xe84>
    5508:	4c 89 ef             	mov    %r13,%rdi
    550b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5510:	e8 1b cf ff ff       	call   2430 <strlen@plt>
    5515:	4c 89 ee             	mov    %r13,%rsi
    5518:	48 89 df             	mov    %rbx,%rdi
    551b:	48 89 c2             	mov    %rax,%rdx
    551e:	e8 8d da ff ff       	call   2fb0 <buf_put>
    5523:	ba 01 00 00 00       	mov    $0x1,%edx
    5528:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    552d:	48 89 df             	mov    %rbx,%rdi
    5530:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5535:	e8 76 da ff ff       	call   2fb0 <buf_put>
    553a:	ba 01 00 00 00       	mov    $0x1,%edx
    553f:	4c 89 fe             	mov    %r15,%rsi
    5542:	48 89 df             	mov    %rbx,%rdi
    5545:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    554a:	e8 61 da ff ff       	call   2fb0 <buf_put>
    554f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5554:	45 31 f6             	xor    %r14d,%r14d
    5557:	85 c0                	test   %eax,%eax
    5559:	0f 8e 91 0a 00 00    	jle    5ff0 <fwp_write.constprop.0+0xd40>
    555f:	45 31 ed             	xor    %r13d,%r13d
    5562:	4d 85 ed             	test   %r13,%r13
    5565:	0f 85 d5 08 00 00    	jne    5e40 <fwp_write.constprop.0+0xb90>
    556b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5572:	00 
    5573:	45 85 f6             	test   %r14d,%r14d
    5576:	0f 84 74 08 00 00    	je     5df0 <fwp_write.constprop.0+0xb40>
    557c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    5581:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    5586:	48 89 df             	mov    %rbx,%rdi
    5589:	49 83 c5 01          	add    $0x1,%r13
    558d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    5591:	e8 1a fd ff ff       	call   52b0 <fwp_write.constprop.0>
    5596:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    559b:	7f c5                	jg     5562 <fwp_write.constprop.0+0x2b2>
    559d:	45 85 f6             	test   %r14d,%r14d
    55a0:	0f 84 4a 0a 00 00    	je     5ff0 <fwp_write.constprop.0+0xd40>
    55a6:	b8 29 00 00 00       	mov    $0x29,%eax
    55ab:	ba 01 00 00 00       	mov    $0x1,%edx
    55b0:	4c 89 fe             	mov    %r15,%rsi
    55b3:	48 89 df             	mov    %rbx,%rdi
    55b6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    55ba:	e8 f1 d9 ff ff       	call   2fb0 <buf_put>
    55bf:	e9 7c fd ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    55c4:	0f 1f 40 00          	nopl   0x0(%rax)
    55c8:	ba 01 00 00 00       	mov    $0x1,%edx
    55cd:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    55d2:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    55d7:	e8 d4 d9 ff ff       	call   2fb0 <buf_put>
    55dc:	48 85 ed             	test   %rbp,%rbp
    55df:	0f 84 8b 07 00 00    	je     5d70 <fwp_write.constprop.0+0xac0>
    55e5:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    55e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    55ee:	48 89 df             	mov    %rbx,%rdi
    55f1:	e8 ba fc ff ff       	call   52b0 <fwp_write.constprop.0>
    55f6:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    55fa:	48 85 ed             	test   %rbp,%rbp
    55fd:	0f 84 6d 07 00 00    	je     5d70 <fwp_write.constprop.0+0xac0>
    5603:	ba 02 00 00 00       	mov    $0x2,%edx
    5608:	48 8d 35 4e 5b 00 00 	lea    0x5b4e(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    560f:	48 89 df             	mov    %rbx,%rdi
    5612:	e8 99 d9 ff ff       	call   2fb0 <buf_put>
    5617:	eb cc                	jmp    55e5 <fwp_write.constprop.0+0x335>
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4c 8b 2e             	mov    (%rsi),%r13
    5623:	ba 01 00 00 00       	mov    $0x1,%edx
    5628:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    562d:	48 83 c5 08          	add    $0x8,%rbp
    5631:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5636:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    563b:	e8 70 d9 ff ff       	call   2fb0 <buf_put>
    5640:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5645:	4d 85 ed             	test   %r13,%r13
    5648:	75 43                	jne    568d <fwp_write.constprop.0+0x3dd>
    564a:	e9 81 07 00 00       	jmp    5dd0 <fwp_write.constprop.0+0xb20>
    564f:	90                   	nop
    5650:	41 80 f9 09          	cmp    $0x9,%r9b
    5654:	0f 84 f6 06 00 00    	je     5d50 <fwp_write.constprop.0+0xaa0>
    565a:	41 80 f9 0a          	cmp    $0xa,%r9b
    565e:	0f 85 bc 06 00 00    	jne    5d20 <fwp_write.constprop.0+0xa70>
    5664:	ba 02 00 00 00       	mov    $0x2,%edx
    5669:	48 8d 35 d3 5a 00 00 	lea    0x5ad3(%rip),%rsi        # b143 <_IO_stdin_used+0x143>
    5670:	48 89 df             	mov    %rbx,%rdi
    5673:	e8 38 d9 ff ff       	call   2fb0 <buf_put>
    5678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    567f:	00 
    5680:	48 83 c5 01          	add    $0x1,%rbp
    5684:	49 39 ec             	cmp    %rbp,%r12
    5687:	0f 84 43 07 00 00    	je     5dd0 <fwp_write.constprop.0+0xb20>
    568d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    5692:	41 80 f9 0d          	cmp    $0xd,%r9b
    5696:	0f 84 64 06 00 00    	je     5d00 <fwp_write.constprop.0+0xa50>
    569c:	7e b2                	jle    5650 <fwp_write.constprop.0+0x3a0>
    569e:	41 80 f9 22          	cmp    $0x22,%r9b
    56a2:	0f 84 38 06 00 00    	je     5ce0 <fwp_write.constprop.0+0xa30>
    56a8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    56ac:	0f 85 6e 06 00 00    	jne    5d20 <fwp_write.constprop.0+0xa70>
    56b2:	ba 02 00 00 00       	mov    $0x2,%edx
    56b7:	48 8d 35 82 5a 00 00 	lea    0x5a82(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    56be:	48 89 df             	mov    %rbx,%rdi
    56c1:	e8 ea d8 ff ff       	call   2fb0 <buf_put>
    56c6:	eb b8                	jmp    5680 <fwp_write.constprop.0+0x3d0>
    56c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56cf:	00 
    56d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    56d5:	ba 01 00 00 00       	mov    $0x1,%edx
    56da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    56df:	48 89 ee             	mov    %rbp,%rsi
    56e2:	e8 c9 d8 ff ff       	call   2fb0 <buf_put>
    56e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    56ec:	4c 89 e7             	mov    %r12,%rdi
    56ef:	e8 3c cd ff ff       	call   2430 <strlen@plt>
    56f4:	4c 89 e6             	mov    %r12,%rsi
    56f7:	48 89 df             	mov    %rbx,%rdi
    56fa:	48 89 c2             	mov    %rax,%rdx
    56fd:	e8 ae d8 ff ff       	call   2fb0 <buf_put>
    5702:	ba 01 00 00 00       	mov    $0x1,%edx
    5707:	48 89 ee             	mov    %rbp,%rsi
    570a:	48 89 df             	mov    %rbx,%rdi
    570d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5712:	e8 99 d8 ff ff       	call   2fb0 <buf_put>
    5717:	e9 24 fc ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    571c:	0f 1f 40 00          	nopl   0x0(%rax)
    5720:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5725:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5729:	0f 8a de 0a 00 00    	jp     620d <fwp_write.constprop.0+0xf5d>
    572f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5733:	66 0f 54 05 15 5f 00 	andpd  0x5f15(%rip),%xmm0        # b650 <msg.3+0x80>
    573a:	00 
    573b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5740:	66 0f 2e 05 28 5f 00 	ucomisd 0x5f28(%rip),%xmm0        # b670 <msg.3+0xa0>
    5747:	00 
    5748:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    574f:	00 
    5750:	0f 87 02 09 00 00    	ja     6058 <fwp_write.constprop.0+0xda8>
    5756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    575d:	00 00 00 
    5760:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5764:	89 ee                	mov    %ebp,%esi
    5766:	4c 89 e7             	mov    %r12,%rdi
    5769:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    576e:	e8 5d db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5773:	31 f6                	xor    %esi,%esi
    5775:	4c 89 e7             	mov    %r12,%rdi
    5778:	e8 73 cc ff ff       	call   23f0 <strtod@plt>
    577d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    5782:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    5786:	7a 06                	jp     578e <fwp_write.constprop.0+0x4de>
    5788:	0f 84 09 03 00 00    	je     5a97 <fwp_write.constprop.0+0x7e7>
    578e:	83 c5 01             	add    $0x1,%ebp
    5791:	83 fd 12             	cmp    $0x12,%ebp
    5794:	75 ca                	jne    5760 <fwp_write.constprop.0+0x4b0>
    5796:	be 11 00 00 00       	mov    $0x11,%esi
    579b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    579f:	4c 89 e7             	mov    %r12,%rdi
    57a2:	e8 29 db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    57a7:	e9 eb 02 00 00       	jmp    5a97 <fwp_write.constprop.0+0x7e7>
    57ac:	0f 1f 40 00          	nopl   0x0(%rax)
    57b0:	48 83 fe 01          	cmp    $0x1,%rsi
    57b4:	0f 84 86 08 00 00    	je     6040 <fwp_write.constprop.0+0xd90>
    57ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    57be:	b8 02 00 00 00       	mov    $0x2,%eax
    57c3:	ba 01 00 00 00       	mov    $0x1,%edx
    57c8:	48 0f 44 d0          	cmove  %rax,%rdx
    57cc:	48 8d 35 39 59 00 00 	lea    0x5939(%rip),%rsi        # b10c <_IO_stdin_used+0x10c>
    57d3:	48 8d 05 2f 59 00 00 	lea    0x592f(%rip),%rax        # b109 <_IO_stdin_used+0x109>
    57da:	48 0f 44 f0          	cmove  %rax,%rsi
    57de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    57e5:	00 
    57e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    57ed:	00 00 
    57ef:	0f 84 ce fc ff ff    	je     54c3 <fwp_write.constprop.0+0x213>
    57f5:	e8 46 cc ff ff       	call   2440 <__stack_chk_fail@plt>
    57fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5800:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5805:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    580a:	e8 e1 d6 ff ff       	call   2ef0 <buf_grow>
    580f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5813:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5819:	4c 03 0b             	add    (%rbx),%r9
    581c:	66 45 89 11          	mov    %r10w,(%r9)
    5820:	49 83 c1 01          	add    $0x1,%r9
    5824:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    582b:	55 55 55 
    582e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5835:	aa aa aa 
    5838:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    583c:	45 85 e4             	test   %r12d,%r12d
    583f:	7f 4c                	jg     588d <fwp_write.constprop.0+0x5dd>
    5841:	e9 4a 05 00 00       	jmp    5d90 <fwp_write.constprop.0+0xae0>
    5846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    584d:	00 00 00 
    5850:	be 01 00 00 00       	mov    $0x1,%esi
    5855:	b8 2d 00 00 00       	mov    $0x2d,%eax
    585a:	88 07                	mov    %al,(%rdi)
    585c:	48 89 e8             	mov    %rbp,%rax
    585f:	49 f7 e8             	imul   %r8
    5862:	48 89 e8             	mov    %rbp,%rax
    5865:	48 c1 f8 3f          	sar    $0x3f,%rax
    5869:	48 29 c2             	sub    %rax,%rdx
    586c:	48 85 c9             	test   %rcx,%rcx
    586f:	0f 95 c0             	setne  %al
    5872:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5876:	48 83 ef 01          	sub    $0x1,%rdi
    587a:	48 21 c5             	and    %rax,%rbp
    587d:	48 29 ea             	sub    %rbp,%rdx
    5880:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    5884:	49 39 f9             	cmp    %rdi,%r9
    5887:	0f 84 03 05 00 00    	je     5d90 <fwp_write.constprop.0+0xae0>
    588d:	48 89 e8             	mov    %rbp,%rax
    5890:	49 f7 e8             	imul   %r8
    5893:	48 89 e8             	mov    %rbp,%rax
    5896:	48 c1 f8 3f          	sar    $0x3f,%rax
    589a:	48 89 d1             	mov    %rdx,%rcx
    589d:	48 29 c1             	sub    %rax,%rcx
    58a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    58a4:	48 89 e9             	mov    %rbp,%rcx
    58a7:	48 29 c1             	sub    %rax,%rcx
    58aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    58ae:	49 f7 e2             	mul    %r10
    58b1:	b8 30 00 00 00       	mov    $0x30,%eax
    58b6:	48 89 d6             	mov    %rdx,%rsi
    58b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    58bd:	48 d1 ee             	shr    $1,%rsi
    58c0:	48 01 f2             	add    %rsi,%rdx
    58c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    58c7:	48 29 d6             	sub    %rdx,%rsi
    58ca:	74 8e                	je     585a <fwp_write.constprop.0+0x5aa>
    58cc:	48 83 fe 01          	cmp    $0x1,%rsi
    58d0:	0f 85 7a ff ff ff    	jne    5850 <fwp_write.constprop.0+0x5a0>
    58d6:	31 f6                	xor    %esi,%esi
    58d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    58dd:	e9 78 ff ff ff       	jmp    585a <fwp_write.constprop.0+0x5aa>
    58e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    58e8:	ba 06 00 00 00       	mov    $0x6,%edx
    58ed:	48 8d 35 6c 58 00 00 	lea    0x586c(%rip),%rsi        # b160 <_IO_stdin_used+0x160>
    58f4:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    58fa:	e8 b1 d6 ff ff       	call   2fb0 <buf_put>
    58ff:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5906:	ff ff 7f 
    5909:	48 23 55 00          	and    0x0(%rbp),%rdx
    590d:	0f 84 4e 03 00 00    	je     5c61 <fwp_write.constprop.0+0x9b1>
    5913:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5918:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    591c:	48 85 d2             	test   %rdx,%rdx
    591f:	0f 84 a4 00 00 00    	je     59c9 <fwp_write.constprop.0+0x719>
    5925:	8b 0a                	mov    (%rdx),%ecx
    5927:	83 f9 1c             	cmp    $0x1c,%ecx
    592a:	0f 84 d0 06 00 00    	je     6000 <fwp_write.constprop.0+0xd50>
    5930:	83 f9 1b             	cmp    $0x1b,%ecx
    5933:	0f 87 90 00 00 00    	ja     59c9 <fwp_write.constprop.0+0x719>
    5939:	be 01 00 00 00       	mov    $0x1,%esi
    593e:	48 d3 e6             	shl    %cl,%rsi
    5941:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5947:	0f 85 13 06 00 00    	jne    5f60 <fwp_write.constprop.0+0xcb0>
    594d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5953:	0f 85 d7 05 00 00    	jne    5f30 <fwp_write.constprop.0+0xc80>
    5959:	83 e6 21             	and    $0x21,%esi
    595c:	74 6b                	je     59c9 <fwp_write.constprop.0+0x719>
    595e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5963:	48 85 ff             	test   %rdi,%rdi
    5966:	79 07                	jns    596f <fwp_write.constprop.0+0x6bf>
    5968:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    596c:	4c 01 ee             	add    %r13,%rsi
    596f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5973:	85 c9                	test   %ecx,%ecx
    5975:	40 0f b6 f7          	movzbl %dil,%esi
    5979:	48 0f 44 f7          	cmove  %rdi,%rsi
    597d:	0f 1f 00             	nopl   (%rax)
    5980:	48 89 df             	mov    %rbx,%rdi
    5983:	49 83 c5 01          	add    $0x1,%r13
    5987:	e8 24 f9 ff ff       	call   52b0 <fwp_write.constprop.0>
    598c:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5993:	ff ff 7f 
    5996:	48 23 55 00          	and    0x0(%rbp),%rdx
    599a:	49 39 d5             	cmp    %rdx,%r13
    599d:	0f 83 be 02 00 00    	jae    5c61 <fwp_write.constprop.0+0x9b1>
    59a3:	ba 02 00 00 00       	mov    $0x2,%edx
    59a8:	48 89 df             	mov    %rbx,%rdi
    59ab:	48 8d 35 ab 57 00 00 	lea    0x57ab(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    59b2:	e8 f9 d5 ff ff       	call   2fb0 <buf_put>
    59b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    59bc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    59c0:	48 85 d2             	test   %rdx,%rdx
    59c3:	0f 85 5c ff ff ff    	jne    5925 <fwp_write.constprop.0+0x675>
    59c9:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    59ce:	48 85 ff             	test   %rdi,%rdi
    59d1:	0f 88 51 06 00 00    	js     6028 <fwp_write.constprop.0+0xd78>
    59d7:	48 8b 31             	mov    (%rcx),%rsi
    59da:	eb a4                	jmp    5980 <fwp_write.constprop.0+0x6d0>
    59dc:	0f 1f 40 00          	nopl   0x0(%rax)
    59e0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    59e7:	00 
    59e8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    59ef:	00 00 
    59f1:	0f 85 fe fd ff ff    	jne    57f5 <fwp_write.constprop.0+0x545>
    59f7:	ba 08 00 00 00       	mov    $0x8,%edx
    59fc:	48 8d 35 2a 57 00 00 	lea    0x572a(%rip),%rsi        # b12d <_IO_stdin_used+0x12d>
    5a03:	e9 bb fa ff ff       	jmp    54c3 <fwp_write.constprop.0+0x213>
    5a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5a0f:	00 
    5a10:	66 0f 6e ce          	movd   %esi,%xmm1
    5a14:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5a17:	0f 8a f0 07 00 00    	jp     620d <fwp_write.constprop.0+0xf5d>
    5a1d:	0f 28 c1             	movaps %xmm1,%xmm0
    5a20:	0f 54 05 19 5c 00 00 	andps  0x5c19(%rip),%xmm0        # b640 <msg.3+0x70>
    5a27:	0f 2e 05 d6 55 00 00 	ucomiss 0x55d6(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    5a2e:	0f 87 4c 06 00 00    	ja     6080 <fwp_write.constprop.0+0xdd0>
    5a34:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5a38:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    5a3e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5a45:	00 
    5a46:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    5a4a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    5a4f:	90                   	nop
    5a50:	44 89 ee             	mov    %r13d,%esi
    5a53:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5a58:	4c 89 e7             	mov    %r12,%rdi
    5a5b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5a60:	e8 6b d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5a65:	31 f6                	xor    %esi,%esi
    5a67:	4c 89 e7             	mov    %r12,%rdi
    5a6a:	e8 21 ca ff ff       	call   2490 <strtof@plt>
    5a6f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5a74:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5a77:	7a 02                	jp     5a7b <fwp_write.constprop.0+0x7cb>
    5a79:	74 1c                	je     5a97 <fwp_write.constprop.0+0x7e7>
    5a7b:	41 83 c5 01          	add    $0x1,%r13d
    5a7f:	41 83 fd 0a          	cmp    $0xa,%r13d
    5a83:	75 cb                	jne    5a50 <fwp_write.constprop.0+0x7a0>
    5a85:	be 09 00 00 00       	mov    $0x9,%esi
    5a8a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5a8f:	4c 89 e7             	mov    %r12,%rdi
    5a92:	e8 39 d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5a97:	4c 89 e7             	mov    %r12,%rdi
    5a9a:	e8 d1 d5 ff ff       	call   3070 <fwp_finish_float>
    5a9f:	e9 7c f8 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    5aa4:	0f 1f 40 00          	nopl   0x0(%rax)
    5aa8:	89 f0                	mov    %esi,%eax
    5aaa:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5ab1:	76 02                	jbe    5ab5 <fwp_write.constprop.0+0x805>
    5ab3:	8b 06                	mov    (%rsi),%eax
    5ab5:	41 89 c6             	mov    %eax,%r14d
    5ab8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5abd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5ac2:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5ac6:	4c 89 ef             	mov    %r13,%rdi
    5ac9:	e8 62 c9 ff ff       	call   2430 <strlen@plt>
    5ace:	4c 89 ee             	mov    %r13,%rsi
    5ad1:	48 89 df             	mov    %rbx,%rdi
    5ad4:	48 89 c2             	mov    %rax,%rdx
    5ad7:	e8 d4 d4 ff ff       	call   2fb0 <buf_put>
    5adc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5ae1:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5ae5:	85 f6                	test   %esi,%esi
    5ae7:	0f 8e 53 f8 ff ff    	jle    5340 <fwp_write.constprop.0+0x90>
    5aed:	45 31 ed             	xor    %r13d,%r13d
    5af0:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5af5:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    5afa:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5aff:	4c 89 fe             	mov    %r15,%rsi
    5b02:	48 89 df             	mov    %rbx,%rdi
    5b05:	ba 01 00 00 00       	mov    $0x1,%edx
    5b0a:	48 89 04 24          	mov    %rax,(%rsp)
    5b0e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5b13:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5b17:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    5b1b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5b20:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5b25:	e8 86 d4 ff ff       	call   2fb0 <buf_put>
    5b2a:	41 8b 06             	mov    (%r14),%eax
    5b2d:	83 f8 0e             	cmp    $0xe,%eax
    5b30:	0f 84 5a 03 00 00    	je     5e90 <fwp_write.constprop.0+0xbe0>
    5b36:	83 f8 10             	cmp    $0x10,%eax
    5b39:	0f 84 21 03 00 00    	je     5e60 <fwp_write.constprop.0+0xbb0>
    5b3f:	83 f8 0a             	cmp    $0xa,%eax
    5b42:	0f 84 68 04 00 00    	je     5fb0 <fwp_write.constprop.0+0xd00>
    5b48:	0f 8f 32 01 00 00    	jg     5c80 <fwp_write.constprop.0+0x9d0>
    5b4e:	83 f8 03             	cmp    $0x3,%eax
    5b51:	0f 8f 39 04 00 00    	jg     5f90 <fwp_write.constprop.0+0xce0>
    5b57:	85 c0                	test   %eax,%eax
    5b59:	78 10                	js     5b6b <fwp_write.constprop.0+0x8bb>
    5b5b:	48 8b 04 24          	mov    (%rsp),%rax
    5b5f:	48 c1 e8 3f          	shr    $0x3f,%rax
    5b63:	85 c0                	test   %eax,%eax
    5b65:	0f 85 32 01 00 00    	jne    5c9d <fwp_write.constprop.0+0x9ed>
    5b6b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5b70:	48 8b 34 24          	mov    (%rsp),%rsi
    5b74:	48 89 df             	mov    %rbx,%rdi
    5b77:	e8 34 f7 ff ff       	call   52b0 <fwp_write.constprop.0>
    5b7c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5b81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b86:	49 83 c5 01          	add    $0x1,%r13
    5b8a:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    5b8e:	0f 8f 61 ff ff ff    	jg     5af5 <fwp_write.constprop.0+0x845>
    5b94:	e9 a7 f7 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ba0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5ba4:	48 8b 36             	mov    (%rsi),%rsi
    5ba7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    5bae:	00 
    5baf:	48 89 ef             	mov    %rbp,%rdi
    5bb2:	e8 49 ce ff ff       	call   2a00 <fwp_fmt_u128>
    5bb7:	48 89 ef             	mov    %rbp,%rdi
    5bba:	e8 71 c8 ff ff       	call   2430 <strlen@plt>
    5bbf:	48 89 ee             	mov    %rbp,%rsi
    5bc2:	48 89 df             	mov    %rbx,%rdi
    5bc5:	48 89 c2             	mov    %rax,%rdx
    5bc8:	e8 e3 d3 ff ff       	call   2fb0 <buf_put>
    5bcd:	e9 6e f7 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5bd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bd8:	ba 06 00 00 00       	mov    $0x6,%edx
    5bdd:	48 8d 35 6f 55 00 00 	lea    0x556f(%rip),%rsi        # b153 <_IO_stdin_used+0x153>
    5be4:	45 31 ed             	xor    %r13d,%r13d
    5be7:	e8 c4 d3 ff ff       	call   2fb0 <buf_put>
    5bec:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5bf1:	75 19                	jne    5c0c <fwp_write.constprop.0+0x95c>
    5bf3:	eb 6c                	jmp    5c61 <fwp_write.constprop.0+0x9b1>
    5bf5:	0f 1f 00             	nopl   (%rax)
    5bf8:	ba 02 00 00 00       	mov    $0x2,%edx
    5bfd:	48 8d 35 59 55 00 00 	lea    0x5559(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5c04:	48 89 df             	mov    %rbx,%rdi
    5c07:	e8 a4 d3 ff ff       	call   2fb0 <buf_put>
    5c0c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5c12:	b9 00 02 00 00       	mov    $0x200,%ecx
    5c17:	31 c0                	xor    %eax,%eax
    5c19:	49 83 c5 01          	add    $0x1,%r13
    5c1d:	4c 8d 05 36 55 00 00 	lea    0x5536(%rip),%r8        # b15a <_IO_stdin_used+0x15a>
    5c24:	ba 02 00 00 00       	mov    $0x2,%edx
    5c29:	be 00 02 00 00       	mov    $0x200,%esi
    5c2e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c35:	00 
    5c36:	e8 55 c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c3b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c42:	00 
    5c43:	e8 e8 c7 ff ff       	call   2430 <strlen@plt>
    5c48:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c4f:	00 
    5c50:	48 89 df             	mov    %rbx,%rdi
    5c53:	48 89 c2             	mov    %rax,%rdx
    5c56:	e8 55 d3 ff ff       	call   2fb0 <buf_put>
    5c5b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5c5f:	72 97                	jb     5bf8 <fwp_write.constprop.0+0x948>
    5c61:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5c66:	ba 01 00 00 00       	mov    $0x1,%edx
    5c6b:	48 89 df             	mov    %rbx,%rdi
    5c6e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5c73:	e8 38 d3 ff ff       	call   2fb0 <buf_put>
    5c78:	e9 c3 f6 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5c7d:	0f 1f 00             	nopl   (%rax)
    5c80:	83 f8 0b             	cmp    $0xb,%eax
    5c83:	0f 85 e2 fe ff ff    	jne    5b6b <fwp_write.constprop.0+0x8bb>
    5c89:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5c8e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5c92:	83 e0 01             	and    $0x1,%eax
    5c95:	85 c0                	test   %eax,%eax
    5c97:	0f 84 ce fe ff ff    	je     5b6b <fwp_write.constprop.0+0x8bb>
    5c9d:	4c 89 fe             	mov    %r15,%rsi
    5ca0:	48 89 df             	mov    %rbx,%rdi
    5ca3:	ba 01 00 00 00       	mov    $0x1,%edx
    5ca8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5cad:	e8 fe d2 ff ff       	call   2fb0 <buf_put>
    5cb2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5cb7:	48 8b 34 24          	mov    (%rsp),%rsi
    5cbb:	48 89 df             	mov    %rbx,%rdi
    5cbe:	e8 ed f5 ff ff       	call   52b0 <fwp_write.constprop.0>
    5cc3:	ba 01 00 00 00       	mov    $0x1,%edx
    5cc8:	4c 89 fe             	mov    %r15,%rsi
    5ccb:	48 89 df             	mov    %rbx,%rdi
    5cce:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5cd3:	e8 d8 d2 ff ff       	call   2fb0 <buf_put>
    5cd8:	e9 9f fe ff ff       	jmp    5b7c <fwp_write.constprop.0+0x8cc>
    5cdd:	0f 1f 00             	nopl   (%rax)
    5ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ce5:	48 8d 35 51 54 00 00 	lea    0x5451(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5cec:	48 89 df             	mov    %rbx,%rdi
    5cef:	e8 bc d2 ff ff       	call   2fb0 <buf_put>
    5cf4:	e9 87 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	ba 02 00 00 00       	mov    $0x2,%edx
    5d05:	48 8d 35 3d 54 00 00 	lea    0x543d(%rip),%rsi        # b149 <_IO_stdin_used+0x149>
    5d0c:	48 89 df             	mov    %rbx,%rdi
    5d0f:	e8 9c d2 ff ff       	call   2fb0 <buf_put>
    5d14:	e9 67 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d20:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5d24:	0f 86 b6 01 00 00    	jbe    5ee0 <fwp_write.constprop.0+0xc30>
    5d2a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5d2e:	0f 84 ac 01 00 00    	je     5ee0 <fwp_write.constprop.0+0xc30>
    5d34:	ba 01 00 00 00       	mov    $0x1,%edx
    5d39:	4c 89 fe             	mov    %r15,%rsi
    5d3c:	48 89 df             	mov    %rbx,%rdi
    5d3f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5d44:	e8 67 d2 ff ff       	call   2fb0 <buf_put>
    5d49:	e9 32 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d4e:	66 90                	xchg   %ax,%ax
    5d50:	ba 02 00 00 00       	mov    $0x2,%edx
    5d55:	48 8d 35 ea 53 00 00 	lea    0x53ea(%rip),%rsi        # b146 <_IO_stdin_used+0x146>
    5d5c:	48 89 df             	mov    %rbx,%rdi
    5d5f:	e8 4c d2 ff ff       	call   2fb0 <buf_put>
    5d64:	e9 17 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d70:	ba 01 00 00 00       	mov    $0x1,%edx
    5d75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5d7a:	48 89 df             	mov    %rbx,%rdi
    5d7d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5d82:	e8 29 d2 ff ff       	call   2fb0 <buf_put>
    5d87:	e9 b4 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    5d90:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5d94:	48 8b 13             	mov    (%rbx),%rdx
    5d97:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5d9c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5da0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5da4:	e9 97 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5db0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5db5:	ba 01 00 00 00       	mov    $0x1,%edx
    5dba:	48 89 df             	mov    %rbx,%rdi
    5dbd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5dc2:	e8 e9 d1 ff ff       	call   2fb0 <buf_put>
    5dc7:	e9 74 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5dcc:	0f 1f 40 00          	nopl   0x0(%rax)
    5dd0:	ba 01 00 00 00       	mov    $0x1,%edx
    5dd5:	4c 89 fe             	mov    %r15,%rsi
    5dd8:	48 89 df             	mov    %rbx,%rdi
    5ddb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5de0:	e8 cb d1 ff ff       	call   2fb0 <buf_put>
    5de5:	e9 56 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5df0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5df5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5dfa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5dfe:	48 89 f7             	mov    %rsi,%rdi
    5e01:	48 89 34 24          	mov    %rsi,(%rsp)
    5e05:	e8 26 c6 ff ff       	call   2430 <strlen@plt>
    5e0a:	48 8b 34 24          	mov    (%rsp),%rsi
    5e0e:	48 89 df             	mov    %rbx,%rdi
    5e11:	48 89 c2             	mov    %rax,%rdx
    5e14:	e8 97 d1 ff ff       	call   2fb0 <buf_put>
    5e19:	ba 03 00 00 00       	mov    $0x3,%edx
    5e1e:	48 8d 35 5b 53 00 00 	lea    0x535b(%rip),%rsi        # b180 <_IO_stdin_used+0x180>
    5e25:	48 89 df             	mov    %rbx,%rdi
    5e28:	e8 83 d1 ff ff       	call   2fb0 <buf_put>
    5e2d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e32:	e9 45 f7 ff ff       	jmp    557c <fwp_write.constprop.0+0x2cc>
    5e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e3e:	00 00 
    5e40:	ba 02 00 00 00       	mov    $0x2,%edx
    5e45:	48 8d 35 11 53 00 00 	lea    0x5311(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5e4c:	48 89 df             	mov    %rbx,%rdi
    5e4f:	e8 5c d1 ff ff       	call   2fb0 <buf_put>
    5e54:	e9 12 f7 ff ff       	jmp    556b <fwp_write.constprop.0+0x2bb>
    5e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e60:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5e65:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5e69:	48 85 ff             	test   %rdi,%rdi
    5e6c:	0f 84 f9 fc ff ff    	je     5b6b <fwp_write.constprop.0+0x8bb>
    5e72:	48 8d 35 f1 52 00 00 	lea    0x52f1(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    5e79:	e8 92 c6 ff ff       	call   2510 <strcmp@plt>
    5e7e:	85 c0                	test   %eax,%eax
    5e80:	0f 95 c0             	setne  %al
    5e83:	0f b6 c0             	movzbl %al,%eax
    5e86:	e9 d8 fc ff ff       	jmp    5b63 <fwp_write.constprop.0+0x8b3>
    5e8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e90:	31 c0                	xor    %eax,%eax
    5e92:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5e99:	00 
    5e9a:	0f 97 c0             	seta   %al
    5e9d:	e9 c1 fc ff ff       	jmp    5b63 <fwp_write.constprop.0+0x8b3>
    5ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea8:	48 89 df             	mov    %rbx,%rdi
    5eab:	ba 02 00 00 00       	mov    $0x2,%edx
    5eb0:	48 8d 35 b0 52 00 00 	lea    0x52b0(%rip),%rsi        # b167 <_IO_stdin_used+0x167>
    5eb7:	e8 f4 d0 ff ff       	call   2fb0 <buf_put>
    5ebc:	4c 89 e8             	mov    %r13,%rax
    5ebf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5ec4:	48 89 df             	mov    %rbx,%rdi
    5ec7:	48 c1 e0 04          	shl    $0x4,%rax
    5ecb:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5ed0:	e8 db f3 ff ff       	call   52b0 <fwp_write.constprop.0>
    5ed5:	e9 4e f5 ff ff       	jmp    5428 <fwp_write.constprop.0+0x178>
    5eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ee0:	4c 8d 05 65 52 00 00 	lea    0x5265(%rip),%r8        # b14c <_IO_stdin_used+0x14c>
    5ee7:	b9 10 00 00 00       	mov    $0x10,%ecx
    5eec:	31 c0                	xor    %eax,%eax
    5eee:	ba 02 00 00 00       	mov    $0x2,%edx
    5ef3:	be 10 00 00 00       	mov    $0x10,%esi
    5ef8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5eff:	00 
    5f00:	e8 8b c4 ff ff       	call   2390 <__snprintf_chk@plt>
    5f05:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f0c:	00 
    5f0d:	e8 1e c5 ff ff       	call   2430 <strlen@plt>
    5f12:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5f19:	00 
    5f1a:	48 89 df             	mov    %rbx,%rdi
    5f1d:	48 89 c2             	mov    %rax,%rdx
    5f20:	e8 8b d0 ff ff       	call   2fb0 <buf_put>
    5f25:	e9 56 f7 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5f35:	48 85 ff             	test   %rdi,%rdi
    5f38:	79 0c                	jns    5f46 <fwp_write.constprop.0+0xc96>
    5f3a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5f41:	00 
    5f42:	48 03 75 10          	add    0x10(%rbp),%rsi
    5f46:	48 63 3e             	movslq (%rsi),%rdi
    5f49:	83 f9 02             	cmp    $0x2,%ecx
    5f4c:	89 fe                	mov    %edi,%esi
    5f4e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5f52:	e9 29 fa ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5f65:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5f6a:	48 85 ff             	test   %rdi,%rdi
    5f6d:	0f 88 6f 01 00 00    	js     60e2 <fwp_write.constprop.0+0xe32>
    5f73:	49 0f bf 38          	movswq (%r8),%rdi
    5f77:	83 f9 01             	cmp    $0x1,%ecx
    5f7a:	0f b7 f7             	movzwl %di,%esi
    5f7d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5f81:	e9 fa f9 ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    5f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f8d:	00 00 00 
    5f90:	83 f8 04             	cmp    $0x4,%eax
    5f93:	0f 85 d2 fb ff ff    	jne    5b6b <fwp_write.constprop.0+0x8bb>
    5f99:	48 8b 04 24          	mov    (%rsp),%rax
    5f9d:	48 8b 40 08          	mov    0x8(%rax),%rax
    5fa1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5fa6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5faa:	e9 e6 fc ff ff       	jmp    5c95 <fwp_write.constprop.0+0x9e5>
    5faf:	90                   	nop
    5fb0:	8b 0c 24             	mov    (%rsp),%ecx
    5fb3:	31 c0                	xor    %eax,%eax
    5fb5:	85 c9                	test   %ecx,%ecx
    5fb7:	0f 98 c0             	sets   %al
    5fba:	e9 d6 fc ff ff       	jmp    5c95 <fwp_write.constprop.0+0x9e5>
    5fbf:	90                   	nop
    5fc0:	48 f7 d8             	neg    %rax
    5fc3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5fca:	00 
    5fcb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5fd2:	2d 
    5fd3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5fda:	00 
    5fdb:	48 83 d2 00          	adc    $0x0,%rdx
    5fdf:	48 89 c6             	mov    %rax,%rsi
    5fe2:	48 f7 da             	neg    %rdx
    5fe5:	e8 16 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5fea:	e9 31 f3 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    5fef:	90                   	nop
    5ff0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5ff5:	e9 b1 f5 ff ff       	jmp    55ab <fwp_write.constprop.0+0x2fb>
    5ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6000:	4c 89 e9             	mov    %r13,%rcx
    6003:	48 c1 e1 04          	shl    $0x4,%rcx
    6007:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    600c:	48 85 ff             	test   %rdi,%rdi
    600f:	0f 89 6b f9 ff ff    	jns    5980 <fwp_write.constprop.0+0x6d0>
    6015:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6019:	48 89 ce             	mov    %rcx,%rsi
    601c:	e9 5f f9 ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    6021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6028:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    602f:	00 
    6030:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6034:	e9 9e f9 ff ff       	jmp    59d7 <fwp_write.constprop.0+0x727>
    6039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6040:	ba 02 00 00 00       	mov    $0x2,%edx
    6045:	48 8d 35 ba 50 00 00 	lea    0x50ba(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    604c:	e9 8d f7 ff ff       	jmp    57de <fwp_write.constprop.0+0x52e>
    6051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6058:	66 0f ef c0          	pxor   %xmm0,%xmm0
    605c:	48 8d 35 9f 50 00 00 	lea    0x509f(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    6063:	48 8d 05 97 50 00 00 	lea    0x5097(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    606a:	4c 89 e7             	mov    %r12,%rdi
    606d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    6071:	48 0f 46 f0          	cmovbe %rax,%rsi
    6075:	e8 56 c3 ff ff       	call   23d0 <strcpy@plt>
    607a:	e9 a1 f2 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    607f:	90                   	nop
    6080:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6084:	48 8d 35 77 50 00 00 	lea    0x5077(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    608b:	48 8d 05 6f 50 00 00 	lea    0x506f(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    6092:	0f 2f c8             	comiss %xmm0,%xmm1
    6095:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    609c:	00 
    609d:	4c 89 e7             	mov    %r12,%rdi
    60a0:	48 0f 46 f0          	cmovbe %rax,%rsi
    60a4:	e8 27 c3 ff ff       	call   23d0 <strcpy@plt>
    60a9:	e9 72 f2 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    60ae:	66 90                	xchg   %ax,%ax
    60b0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    60b5:	45 85 c0             	test   %r8d,%r8d
    60b8:	75 34                	jne    60ee <fwp_write.constprop.0+0xe3e>
    60ba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    60c1:	00 
    60c2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60c9:	00 00 
    60cb:	0f 85 24 f7 ff ff    	jne    57f5 <fwp_write.constprop.0+0x545>
    60d1:	ba 02 00 00 00       	mov    $0x2,%edx
    60d6:	48 8d 35 a0 50 00 00 	lea    0x50a0(%rip),%rsi        # b17d <_IO_stdin_used+0x17d>
    60dd:	e9 e1 f3 ff ff       	jmp    54c3 <fwp_write.constprop.0+0x213>
    60e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    60e6:	49 89 f0             	mov    %rsi,%r8
    60e9:	e9 85 fe ff ff       	jmp    5f73 <fwp_write.constprop.0+0xcc3>
    60ee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    60f3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    60f8:	85 ff                	test   %edi,%edi
    60fa:	0f 84 3a f4 ff ff    	je     553a <fwp_write.constprop.0+0x28a>
    6100:	ba 01 00 00 00       	mov    $0x1,%edx
    6105:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    610a:	48 89 df             	mov    %rbx,%rdi
    610d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6112:	e8 99 ce ff ff       	call   2fb0 <buf_put>
    6117:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    611c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6121:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6127:	85 d2                	test   %edx,%edx
    6129:	0f 8f 30 f4 ff ff    	jg     555f <fwp_write.constprop.0+0x2af>
    612f:	e9 72 f4 ff ff       	jmp    55a6 <fwp_write.constprop.0+0x2f6>
    6134:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6138:	49 89 c5             	mov    %rax,%r13
    613b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6140:	49 89 c4             	mov    %rax,%r12
    6143:	49 c1 fd 3f          	sar    $0x3f,%r13
    6147:	4c 09 e8             	or     %r13,%rax
    614a:	0f 84 a7 00 00 00    	je     61f7 <fwp_write.constprop.0+0xf47>
    6150:	48 8d 2d e9 79 00 00 	lea    0x79e9(%rip),%rbp        # db40 <units.0>
    6157:	4d 89 e7             	mov    %r12,%r15
    615a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    615e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6163:	4c 89 ff             	mov    %r15,%rdi
    6166:	4c 89 ee             	mov    %r13,%rsi
    6169:	44 89 0c 24          	mov    %r9d,(%rsp)
    616d:	48 99                	cqto
    616f:	48 89 d1             	mov    %rdx,%rcx
    6172:	48 89 c2             	mov    %rax,%rdx
    6175:	e8 c6 42 00 00       	call   a440 <__divmodti4>
    617a:	44 8b 0c 24          	mov    (%rsp),%r9d
    617e:	48 89 c1             	mov    %rax,%rcx
    6181:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6186:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    618b:	0f 84 94 00 00 00    	je     6225 <fwp_write.constprop.0+0xf75>
    6191:	41 83 c1 01          	add    $0x1,%r9d
    6195:	48 83 c5 10          	add    $0x10,%rbp
    6199:	41 83 f9 05          	cmp    $0x5,%r9d
    619d:	75 bb                	jne    615a <fwp_write.constprop.0+0xeaa>
    619f:	4d 85 ed             	test   %r13,%r13
    61a2:	79 53                	jns    61f7 <fwp_write.constprop.0+0xf47>
    61a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    61a9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    61ae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    61b3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61b8:	48 99                	cqto
    61ba:	48 f7 d8             	neg    %rax
    61bd:	48 83 d2 00          	adc    $0x0,%rdx
    61c1:	48 89 c6             	mov    %rax,%rsi
    61c4:	48 f7 da             	neg    %rdx
    61c7:	e8 34 c8 ff ff       	call   2a00 <fwp_fmt_u128>
    61cc:	49 89 e8             	mov    %rbp,%r8
    61cf:	ba 00 02 00 00       	mov    $0x200,%edx
    61d4:	be 02 00 00 00       	mov    $0x2,%esi
    61d9:	31 c0                	xor    %eax,%eax
    61db:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    61e2:	00 
    61e3:	48 8d 0d 8e 4f 00 00 	lea    0x4f8e(%rip),%rcx        # b178 <_IO_stdin_used+0x178>
    61ea:	4c 89 e7             	mov    %r12,%rdi
    61ed:	e8 ae c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    61f2:	e9 29 f1 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    61f7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6201:	31 d2                	xor    %edx,%edx
    6203:	48 89 ef             	mov    %rbp,%rdi
    6206:	e8 f5 c7 ff ff       	call   2a00 <fwp_fmt_u128>
    620b:	eb bf                	jmp    61cc <fwp_write.constprop.0+0xf1c>
    620d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6214:	4e 61 4e 00 
    6218:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    621f:	00 
    6220:	e9 fb f0 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    6225:	44 89 0c 24          	mov    %r9d,(%rsp)
    6229:	48 89 c8             	mov    %rcx,%rax
    622c:	48 85 d2             	test   %rdx,%rdx
    622f:	78 51                	js     6282 <fwp_write.constprop.0+0xfd2>
    6231:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6236:	48 89 c6             	mov    %rax,%rsi
    6239:	48 89 ef             	mov    %rbp,%rdi
    623c:	e8 bf c7 ff ff       	call   2a00 <fwp_fmt_u128>
    6241:	44 8b 0c 24          	mov    (%rsp),%r9d
    6245:	49 63 c1             	movslq %r9d,%rax
    6248:	49 89 e8             	mov    %rbp,%r8
    624b:	ba 00 02 00 00       	mov    $0x200,%edx
    6250:	be 02 00 00 00       	mov    $0x2,%esi
    6255:	48 c1 e0 04          	shl    $0x4,%rax
    6259:	48 8d 0d e0 78 00 00 	lea    0x78e0(%rip),%rcx        # db40 <units.0>
    6260:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6267:	00 
    6268:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    626c:	4c 89 e7             	mov    %r12,%rdi
    626f:	48 8d 0d fd 4e 00 00 	lea    0x4efd(%rip),%rcx        # b173 <_IO_stdin_used+0x173>
    6276:	31 c0                	xor    %eax,%eax
    6278:	e8 23 c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    627d:	e9 9e f0 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    6282:	48 f7 d8             	neg    %rax
    6285:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    628a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    628f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6294:	48 83 d2 00          	adc    $0x0,%rdx
    6298:	48 89 c6             	mov    %rax,%rsi
    629b:	48 f7 da             	neg    %rdx
    629e:	e8 5d c7 ff ff       	call   2a00 <fwp_fmt_u128>
    62a3:	44 8b 0c 24          	mov    (%rsp),%r9d
    62a7:	eb 9c                	jmp    6245 <fwp_write.constprop.0+0xf95>
    62a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000062b0 <fwp_hof0.constprop.0>:
    62b0:	41 57                	push   %r15
    62b2:	41 56                	push   %r14
    62b4:	41 55                	push   %r13
    62b6:	4c 8d 2d 83 84 01 00 	lea    0x18483(%rip),%r13        # 1e740 <fwp_heap>
    62bd:	41 54                	push   %r12
    62bf:	49 89 fc             	mov    %rdi,%r12
    62c2:	55                   	push   %rbp
    62c3:	53                   	push   %rbx
    62c4:	48 83 ec 38          	sub    $0x38,%rsp
    62c8:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    62cd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    62d4:	00 00 
    62d6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    62db:	31 c0                	xor    %eax,%eax
    62dd:	48 85 f6             	test   %rsi,%rsi
    62e0:	0f 84 41 09 00 00    	je     6c27 <fwp_hof0.constprop.0+0x977>
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    62f7:	4c 89 e0             	mov    %r12,%rax
    62fa:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6301:	48 c1 e2 10          	shl    $0x10,%rdx
    6305:	48 39 d0             	cmp    %rdx,%rax
    6308:	73 6f                	jae    6379 <fwp_hof0.constprop.0+0xc9>
    630a:	48 89 c2             	mov    %rax,%rdx
    630d:	48 c1 ea 10          	shr    $0x10,%rdx
    6311:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6315:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    631c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6320:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6324:	48 85 db             	test   %rbx,%rbx
    6327:	74 50                	je     6379 <fwp_hof0.constprop.0+0xc9>
    6329:	0f b6 0a             	movzbl (%rdx),%ecx
    632c:	80 f9 02             	cmp    $0x2,%cl
    632f:	0f 84 8b 0b 00 00    	je     6ec0 <fwp_hof0.constprop.0+0xc10>
    6335:	80 f9 01             	cmp    $0x1,%cl
    6338:	75 3f                	jne    6379 <fwp_hof0.constprop.0+0xc9>
    633a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    633d:	0f b7 c0             	movzwl %ax,%eax
    6340:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6343:	48 0f af c1          	imul   %rcx,%rax
    6347:	48 c1 e8 20          	shr    $0x20,%rax
    634b:	48 39 d0             	cmp    %rdx,%rax
    634e:	73 29                	jae    6379 <fwp_hof0.constprop.0+0xc9>
    6350:	48 01 c3             	add    %rax,%rbx
    6353:	0f b6 03             	movzbl (%rbx),%eax
    6356:	84 c0                	test   %al,%al
    6358:	74 1f                	je     6379 <fwp_hof0.constprop.0+0xc9>
    635a:	8b 15 a0 a0 01 00    	mov    0x1a0a0(%rip),%edx        # 20400 <iteration_active>
    6360:	85 d2                	test   %edx,%edx
    6362:	74 08                	je     636c <fwp_hof0.constprop.0+0xbc>
    6364:	48 83 05 7c a0 01 00 	addq   $0x1,0x1a07c(%rip)        # 203e8 <iteration_retains>
    636b:	01 
    636c:	3c fd                	cmp    $0xfd,%al
    636e:	0f 87 6a 0d 00 00    	ja     70de <fwp_hof0.constprop.0+0xe2e>
    6374:	83 c0 01             	add    $0x1,%eax
    6377:	88 03                	mov    %al,(%rbx)
    6379:	4d 85 e4             	test   %r12,%r12
    637c:	0f 84 50 0b 00 00    	je     6ed2 <fwp_hof0.constprop.0+0xc22>
    6382:	4c 89 e0             	mov    %r12,%rax
    6385:	31 ff                	xor    %edi,%edi
    6387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    638e:	00 00 
    6390:	48 8b 40 10          	mov    0x10(%rax),%rax
    6394:	48 83 c7 01          	add    $0x1,%rdi
    6398:	48 85 c0             	test   %rax,%rax
    639b:	75 f3                	jne    6390 <fwp_hof0.constprop.0+0xe0>
    639d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    63a4:	ff ff 1f 
    63a7:	48 39 f8             	cmp    %rdi,%rax
    63aa:	0f 82 00 0e 00 00    	jb     71b0 <fwp_hof0.constprop.0+0xf00>
    63b0:	e8 5b e7 ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    63b5:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    63bc:	48 89 c3             	mov    %rax,%rbx
    63bf:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    63c6:	48 c1 e2 10          	shl    $0x10,%rdx
    63ca:	48 39 d0             	cmp    %rdx,%rax
    63cd:	73 60                	jae    642f <fwp_hof0.constprop.0+0x17f>
    63cf:	48 89 c2             	mov    %rax,%rdx
    63d2:	48 c1 ea 10          	shr    $0x10,%rdx
    63d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    63da:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    63e1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    63e5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    63e9:	48 85 ed             	test   %rbp,%rbp
    63ec:	74 41                	je     642f <fwp_hof0.constprop.0+0x17f>
    63ee:	0f b6 0a             	movzbl (%rdx),%ecx
    63f1:	80 f9 02             	cmp    $0x2,%cl
    63f4:	0f 84 9e 0a 00 00    	je     6e98 <fwp_hof0.constprop.0+0xbe8>
    63fa:	80 f9 01             	cmp    $0x1,%cl
    63fd:	75 27                	jne    6426 <fwp_hof0.constprop.0+0x176>
    63ff:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6402:	0f b7 c0             	movzwl %ax,%eax
    6405:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6408:	48 0f af c1          	imul   %rcx,%rax
    640c:	48 c1 e8 20          	shr    $0x20,%rax
    6410:	48 39 d0             	cmp    %rdx,%rax
    6413:	73 11                	jae    6426 <fwp_hof0.constprop.0+0x176>
    6415:	48 01 c5             	add    %rax,%rbp
    6418:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    641c:	0f 84 89 0a 00 00    	je     6eab <fwp_hof0.constprop.0+0xbfb>
    6422:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    6426:	4d 85 e4             	test   %r12,%r12
    6429:	0f 84 11 0a 00 00    	je     6e40 <fwp_hof0.constprop.0+0xb90>
    642f:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    6434:	49 8b 6c 24 10       	mov    0x10(%r12),%rbp
    6439:	4d 89 e1             	mov    %r12,%r9
    643c:	4d 89 e0             	mov    %r12,%r8
    643f:	4c 89 e2             	mov    %r12,%rdx
    6442:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6448:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    644f:	48 89 d0             	mov    %rdx,%rax
    6452:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6459:	48 c1 e6 10          	shl    $0x10,%rsi
    645d:	48 39 f0             	cmp    %rsi,%rax
    6460:	73 6a                	jae    64cc <fwp_hof0.constprop.0+0x21c>
    6462:	48 89 c6             	mov    %rax,%rsi
    6465:	48 c1 ee 10          	shr    $0x10,%rsi
    6469:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    646d:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    6474:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6478:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    647c:	48 85 ff             	test   %rdi,%rdi
    647f:	74 4b                	je     64cc <fwp_hof0.constprop.0+0x21c>
    6481:	44 0f b6 16          	movzbl (%rsi),%r10d
    6485:	41 80 fa 02          	cmp    $0x2,%r10b
    6489:	0f 84 31 05 00 00    	je     69c0 <fwp_hof0.constprop.0+0x710>
    648f:	41 80 fa 01          	cmp    $0x1,%r10b
    6493:	75 37                	jne    64cc <fwp_hof0.constprop.0+0x21c>
    6495:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    6499:	0f b7 c0             	movzwl %ax,%eax
    649c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    649f:	49 0f af c2          	imul   %r10,%rax
    64a3:	48 c1 e8 20          	shr    $0x20,%rax
    64a7:	48 39 f0             	cmp    %rsi,%rax
    64aa:	73 20                	jae    64cc <fwp_hof0.constprop.0+0x21c>
    64ac:	48 01 c7             	add    %rax,%rdi
    64af:	80 3f 01             	cmpb   $0x1,(%rdi)
    64b2:	75 18                	jne    64cc <fwp_hof0.constprop.0+0x21c>
    64b4:	e9 4f 04 00 00       	jmp    6908 <fwp_hof0.constprop.0+0x658>
    64b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64c0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    64c4:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    64c8:	49 83 c6 01          	add    $0x1,%r14
    64cc:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    64d0:	0f 88 b8 0c 00 00    	js     718e <fwp_hof0.constprop.0+0xede>
    64d6:	4a 89 0c f3          	mov    %rcx,(%rbx,%r14,8)
    64da:	48 85 ed             	test   %rbp,%rbp
    64dd:	75 e1                	jne    64c0 <fwp_hof0.constprop.0+0x210>
    64df:	4c 89 c7             	mov    %r8,%rdi
    64e2:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    64e8:	e8 f3 ea ff ff       	call   4fe0 <fwp_drop0>
    64ed:	31 c0                	xor    %eax,%eax
    64ef:	48 85 c0             	test   %rax,%rax
    64f2:	0f 85 13 c2 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    64f8:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    64ff:	ff ff 7f 
    6502:	4c 23 33             	and    (%rbx),%r14
    6505:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    650c:	ff ff 1f 
    650f:	4c 39 f0             	cmp    %r14,%rax
    6512:	0f 82 98 0c 00 00    	jb     71b0 <fwp_hof0.constprop.0+0xf00>
    6518:	4c 89 f7             	mov    %r14,%rdi
    651b:	e8 f0 e5 ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    6520:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6527:	48 89 c5             	mov    %rax,%rbp
    652a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6531:	48 c1 e2 10          	shl    $0x10,%rdx
    6535:	48 39 d0             	cmp    %rdx,%rax
    6538:	73 57                	jae    6591 <fwp_hof0.constprop.0+0x2e1>
    653a:	48 89 c2             	mov    %rax,%rdx
    653d:	48 c1 ea 10          	shr    $0x10,%rdx
    6541:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6545:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    654c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6550:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6554:	48 85 c9             	test   %rcx,%rcx
    6557:	74 38                	je     6591 <fwp_hof0.constprop.0+0x2e1>
    6559:	0f b6 32             	movzbl (%rdx),%esi
    655c:	40 80 fe 02          	cmp    $0x2,%sil
    6560:	0f 84 6a 08 00 00    	je     6dd0 <fwp_hof0.constprop.0+0xb20>
    6566:	40 80 fe 01          	cmp    $0x1,%sil
    656a:	75 25                	jne    6591 <fwp_hof0.constprop.0+0x2e1>
    656c:	8b 72 18             	mov    0x18(%rdx),%esi
    656f:	0f b7 c0             	movzwl %ax,%eax
    6572:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6575:	48 0f af c6          	imul   %rsi,%rax
    6579:	48 c1 e8 20          	shr    $0x20,%rax
    657d:	48 39 d0             	cmp    %rdx,%rax
    6580:	73 0f                	jae    6591 <fwp_hof0.constprop.0+0x2e1>
    6582:	48 01 c1             	add    %rax,%rcx
    6585:	80 39 ff             	cmpb   $0xff,(%rcx)
    6588:	0f 84 54 08 00 00    	je     6de2 <fwp_hof0.constprop.0+0xb32>
    658e:	c6 01 01             	movb   $0x1,(%rcx)
    6591:	4d 85 f6             	test   %r14,%r14
    6594:	0f 84 46 01 00 00    	je     66e0 <fwp_hof0.constprop.0+0x430>
    659a:	4c 8d 5b 08          	lea    0x8(%rbx),%r11
    659e:	48 8b 13             	mov    (%rbx),%rdx
    65a1:	31 c9                	xor    %ecx,%ecx
    65a3:	be 01 00 00 00       	mov    $0x1,%esi
    65a8:	4d 89 d9             	mov    %r11,%r9
    65ab:	31 c0                	xor    %eax,%eax
    65ad:	66 0f ef d2          	pxor   %xmm2,%xmm2
    65b1:	0f 1f 40 00          	nopl   0x0(%rax)
    65b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    65bc:	00 00 00 00 
    65c0:	48 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdi
    65c7:	ff ff 7f 
    65ca:	48 21 d7             	and    %rdx,%rdi
    65cd:	48 39 fe             	cmp    %rdi,%rsi
    65d0:	0f 84 f2 00 00 00    	je     66c8 <fwp_hof0.constprop.0+0x418>
    65d6:	48 39 f9             	cmp    %rdi,%rcx
    65d9:	0f 83 f2 00 00 00    	jae    66d1 <fwp_hof0.constprop.0+0x421>
    65df:	48 85 d2             	test   %rdx,%rdx
    65e2:	0f 88 f8 06 00 00    	js     6ce0 <fwp_hof0.constprop.0+0xa30>
    65e8:	48 39 fe             	cmp    %rdi,%rsi
    65eb:	0f 83 e0 00 00 00    	jae    66d1 <fwp_hof0.constprop.0+0x421>
    65f1:	f2 41 0f 10 01       	movsd  (%r9),%xmm0
    65f6:	f2 0f 10 1d 82 50 00 	movsd  0x5082(%rip),%xmm3        # b680 <msg.3+0xb0>
    65fd:	00 
    65fe:	4c 89 df             	mov    %r11,%rdi
    6601:	f2 0f 10 25 7f 50 00 	movsd  0x507f(%rip),%xmm4        # b688 <msg.3+0xb8>
    6608:	00 
    6609:	f2 0f 5c d8          	subsd  %xmm0,%xmm3
    660d:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    6611:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6615:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    6619:	f3 0f 7e 4c 07 08    	movq   0x8(%rdi,%rax,1),%xmm1
    661f:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6623:	f2 0f 59 cc          	mulsd  %xmm4,%xmm1
    6627:	66 0f 28 c1          	movapd %xmm1,%xmm0
    662b:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
    662f:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    6633:	f2 0f 59 05 55 50 00 	mulsd  0x5055(%rip),%xmm0        # b690 <msg.3+0xc0>
    663a:	00 
    663b:	4c 89 df             	mov    %r11,%rdi
    663e:	48 85 d2             	test   %rdx,%rdx
    6641:	0f 88 69 03 00 00    	js     69b0 <fwp_hof0.constprop.0+0x700>
    6647:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    664c:	0f 88 3c 0b 00 00    	js     718e <fwp_hof0.constprop.0+0xede>
    6652:	f3 0f 7e 0c 07       	movq   (%rdi,%rax,1),%xmm1
    6657:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    665b:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    665f:	f2 0f 11 4c 28 08    	movsd  %xmm1,0x8(%rax,%rbp,1)
    6665:	49 39 fe             	cmp    %rdi,%r14
    6668:	74 76                	je     66e0 <fwp_hof0.constprop.0+0x430>
    666a:	49 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r8
    6671:	ff ff 7f 
    6674:	48 8b 13             	mov    (%rbx),%rdx
    6677:	49 21 d0             	and    %rdx,%r8
    667a:	4c 39 c1             	cmp    %r8,%rcx
    667d:	73 52                	jae    66d1 <fwp_hof0.constprop.0+0x421>
    667f:	4c 8d 50 08          	lea    0x8(%rax),%r10
    6683:	48 85 d2             	test   %rdx,%rdx
    6686:	0f 88 94 06 00 00    	js     6d20 <fwp_hof0.constprop.0+0xa70>
    668c:	4c 39 c7             	cmp    %r8,%rdi
    668f:	73 40                	jae    66d1 <fwp_hof0.constprop.0+0x421>
    6691:	f2 0f 10 44 18 08    	movsd  0x8(%rax,%rbx,1),%xmm0
    6697:	4c 89 d9             	mov    %r11,%rcx
    669a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    669e:	f3 42 0f 7e 14 11    	movq   (%rcx,%r10,1),%xmm2
    66a4:	48 83 c6 01          	add    $0x1,%rsi
    66a8:	49 83 c1 08          	add    $0x8,%r9
    66ac:	48 89 f9             	mov    %rdi,%rcx
    66af:	4c 89 d0             	mov    %r10,%rax
    66b2:	f2 0f 5c d0          	subsd  %xmm0,%xmm2
    66b6:	f2 0f 59 15 ba 4f 00 	mulsd  0x4fba(%rip),%xmm2        # b678 <msg.3+0xa8>
    66bd:	00 
    66be:	e9 fd fe ff ff       	jmp    65c0 <fwp_hof0.constprop.0+0x310>
    66c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    66c8:	48 39 f1             	cmp    %rsi,%rcx
    66cb:	0f 82 23 0b 00 00    	jb     71f4 <fwp_hof0.constprop.0+0xf44>
    66d1:	48 8d 3d 50 79 00 00 	lea    0x7950(%rip),%rdi        # e028 <s0+0x8>
    66d8:	e8 23 cb ff ff       	call   3200 <fwp_trap>
    66dd:	0f 1f 00             	nopl   (%rax)
    66e0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    66e7:	48 89 d8             	mov    %rbx,%rax
    66ea:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    66f1:	48 c1 e2 10          	shl    $0x10,%rdx
    66f5:	48 39 d0             	cmp    %rdx,%rax
    66f8:	73 76                	jae    6770 <fwp_hof0.constprop.0+0x4c0>
    66fa:	48 89 c2             	mov    %rax,%rdx
    66fd:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    6704:	48 c1 ea 10          	shr    $0x10,%rdx
    6708:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    670c:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6710:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6714:	4d 85 f6             	test   %r14,%r14
    6717:	74 57                	je     6770 <fwp_hof0.constprop.0+0x4c0>
    6719:	0f b6 32             	movzbl (%rdx),%esi
    671c:	40 80 fe 02          	cmp    $0x2,%sil
    6720:	0f 84 1a 06 00 00    	je     6d40 <fwp_hof0.constprop.0+0xa90>
    6726:	40 80 fe 01          	cmp    $0x1,%sil
    672a:	75 44                	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    672c:	8b 72 18             	mov    0x18(%rdx),%esi
    672f:	0f b7 c0             	movzwl %ax,%eax
    6732:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6735:	48 0f af c6          	imul   %rsi,%rax
    6739:	48 c1 e8 20          	shr    $0x20,%rax
    673d:	48 39 d0             	cmp    %rdx,%rax
    6740:	73 2e                	jae    6770 <fwp_hof0.constprop.0+0x4c0>
    6742:	49 01 c6             	add    %rax,%r14
    6745:	41 0f b6 06          	movzbl (%r14),%eax
    6749:	84 c0                	test   %al,%al
    674b:	74 23                	je     6770 <fwp_hof0.constprop.0+0x4c0>
    674d:	3c 01                	cmp    $0x1,%al
    674f:	0f 84 fb 00 00 00    	je     6850 <fwp_hof0.constprop.0+0x5a0>
    6755:	3c ff                	cmp    $0xff,%al
    6757:	0f 84 0f 08 00 00    	je     6f6c <fwp_hof0.constprop.0+0xcbc>
    675d:	83 e8 01             	sub    $0x1,%eax
    6760:	41 88 06             	mov    %al,(%r14)
    6763:	66 90                	xchg   %ax,%ax
    6765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    676c:	00 00 00 00 
    6770:	4d 85 ff             	test   %r15,%r15
    6773:	0f 85 77 01 00 00    	jne    68f0 <fwp_hof0.constprop.0+0x640>
    6779:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
    677e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6782:	be 01 00 00 00       	mov    $0x1,%esi
    6787:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    678e:	00 00 
    6790:	48 89 df             	mov    %rbx,%rdi
    6793:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6798:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    679f:	ff ff 7f 
    67a2:	e8 49 c7 ff ff       	call   2ef0 <buf_grow>
    67a7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    67ac:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    67b1:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    67b5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    67ba:	48 8d 50 01          	lea    0x1(%rax),%rdx
    67be:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    67c3:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    67c8:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    67cd:	48 8d 45 08          	lea    0x8(%rbp),%rax
    67d1:	48 89 04 24          	mov    %rax,(%rsp)
    67d5:	4c 23 75 00          	and    0x0(%rbp),%r14
    67d9:	75 5c                	jne    6837 <fwp_hof0.constprop.0+0x587>
    67db:	e9 f0 01 00 00       	jmp    69d0 <fwp_hof0.constprop.0+0x720>
    67e0:	4a 8b 34 fa          	mov    (%rdx,%r15,8),%rsi
    67e4:	48 89 df             	mov    %rbx,%rdi
    67e7:	48 8d 15 b2 73 00 00 	lea    0x73b2(%rip),%rdx        # dba0 <d0>
    67ee:	49 83 c7 01          	add    $0x1,%r15
    67f2:	e8 b9 ea ff ff       	call   52b0 <fwp_write.constprop.0>
    67f7:	4d 39 fe             	cmp    %r15,%r14
    67fa:	0f 84 d0 01 00 00    	je     69d0 <fwp_hof0.constprop.0+0x720>
    6800:	be 02 00 00 00       	mov    $0x2,%esi
    6805:	48 89 df             	mov    %rbx,%rdi
    6808:	e8 e3 c6 ff ff       	call   2ef0 <buf_grow>
    680d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6812:	b8 2c 20 00 00       	mov    $0x202c,%eax
    6817:	48 03 54 24 10       	add    0x10(%rsp),%rdx
    681c:	66 89 02             	mov    %ax,(%rdx)
    681f:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6824:	48 8d 4a 02          	lea    0x2(%rdx),%rcx
    6828:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    682d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    6832:	c6 44 11 02 00       	movb   $0x0,0x2(%rcx,%rdx,1)
    6837:	48 8b 14 24          	mov    (%rsp),%rdx
    683b:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6840:	79 9e                	jns    67e0 <fwp_hof0.constprop.0+0x530>
    6842:	48 8b 55 10          	mov    0x10(%rbp),%rdx
    6846:	eb 98                	jmp    67e0 <fwp_hof0.constprop.0+0x530>
    6848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    684f:	00 
    6850:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    6857:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    685e:	48 89 d8             	mov    %rbx,%rax
    6861:	48 89 df             	mov    %rbx,%rdi
    6864:	48 29 f0             	sub    %rsi,%rax
    6867:	48 c1 e2 10          	shl    $0x10,%rdx
    686b:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    686f:	0f 88 db 04 00 00    	js     6d50 <fwp_hof0.constprop.0+0xaa0>
    6875:	48 39 d0             	cmp    %rdx,%rax
    6878:	0f 83 f2 fe ff ff    	jae    6770 <fwp_hof0.constprop.0+0x4c0>
    687e:	48 89 c2             	mov    %rax,%rdx
    6881:	48 c1 ea 10          	shr    $0x10,%rdx
    6885:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6889:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    688d:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6891:	48 85 c9             	test   %rcx,%rcx
    6894:	0f 84 d6 fe ff ff    	je     6770 <fwp_hof0.constprop.0+0x4c0>
    689a:	0f b6 32             	movzbl (%rdx),%esi
    689d:	40 80 fe 02          	cmp    $0x2,%sil
    68a1:	0f 84 69 05 00 00    	je     6e10 <fwp_hof0.constprop.0+0xb60>
    68a7:	40 80 fe 01          	cmp    $0x1,%sil
    68ab:	0f 85 bf fe ff ff    	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    68b1:	8b 72 18             	mov    0x18(%rdx),%esi
    68b4:	0f b7 c0             	movzwl %ax,%eax
    68b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    68ba:	48 0f af c6          	imul   %rsi,%rax
    68be:	48 c1 e8 20          	shr    $0x20,%rax
    68c2:	48 39 d0             	cmp    %rdx,%rax
    68c5:	0f 83 a5 fe ff ff    	jae    6770 <fwp_hof0.constprop.0+0x4c0>
    68cb:	48 01 c1             	add    %rax,%rcx
    68ce:	80 39 01             	cmpb   $0x1,(%rcx)
    68d1:	0f 85 99 fe ff ff    	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    68d7:	48 89 df             	mov    %rbx,%rdi
    68da:	e8 31 d8 ff ff       	call   4110 <fwp_mem_free>
    68df:	4d 85 ff             	test   %r15,%r15
    68e2:	0f 84 91 fe ff ff    	je     6779 <fwp_hof0.constprop.0+0x4c9>
    68e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    68ef:	00 
    68f0:	31 c0                	xor    %eax,%eax
    68f2:	49 83 ef 01          	sub    $0x1,%r15
    68f6:	48 89 eb             	mov    %rbp,%rbx
    68f9:	0f 90 c0             	seto   %al
    68fc:	e9 ee fb ff ff       	jmp    64ef <fwp_hof0.constprop.0+0x23f>
    6901:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6908:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    690c:	0f 88 7c 08 00 00    	js     718e <fwp_hof0.constprop.0+0xede>
    6912:	4a 89 0c f3          	mov    %rcx,(%rbx,%r14,8)
    6916:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    691d:	49 2b 95 b0 13 00 00 	sub    0x13b0(%r13),%rdx
    6924:	48 c1 e0 10          	shl    $0x10,%rax
    6928:	48 39 c2             	cmp    %rax,%rdx
    692b:	73 58                	jae    6985 <fwp_hof0.constprop.0+0x6d5>
    692d:	48 89 d0             	mov    %rdx,%rax
    6930:	48 c1 e8 10          	shr    $0x10,%rax
    6934:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    6938:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    693f:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    6943:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6947:	48 85 c9             	test   %rcx,%rcx
    694a:	74 39                	je     6985 <fwp_hof0.constprop.0+0x6d5>
    694c:	0f b6 30             	movzbl (%rax),%esi
    694f:	40 80 fe 02          	cmp    $0x2,%sil
    6953:	0f 84 c7 04 00 00    	je     6e20 <fwp_hof0.constprop.0+0xb70>
    6959:	40 80 fe 01          	cmp    $0x1,%sil
    695d:	75 26                	jne    6985 <fwp_hof0.constprop.0+0x6d5>
    695f:	8b 70 18             	mov    0x18(%rax),%esi
    6962:	0f b7 d2             	movzwl %dx,%edx
    6965:	8b 40 1c             	mov    0x1c(%rax),%eax
    6968:	48 0f af d6          	imul   %rsi,%rdx
    696c:	48 c1 ea 20          	shr    $0x20,%rdx
    6970:	48 39 c2             	cmp    %rax,%rdx
    6973:	73 10                	jae    6985 <fwp_hof0.constprop.0+0x6d5>
    6975:	48 01 d1             	add    %rdx,%rcx
    6978:	80 39 01             	cmpb   $0x1,(%rcx)
    697b:	75 08                	jne    6985 <fwp_hof0.constprop.0+0x6d5>
    697d:	4c 89 cf             	mov    %r9,%rdi
    6980:	e8 8b d7 ff ff       	call   4110 <fwp_mem_free>
    6985:	48 85 ed             	test   %rbp,%rbp
    6988:	0f 84 b2 04 00 00    	je     6e40 <fwp_hof0.constprop.0+0xb90>
    698e:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    6992:	49 89 e9             	mov    %rbp,%r9
    6995:	49 89 e8             	mov    %rbp,%r8
    6998:	48 89 ea             	mov    %rbp,%rdx
    699b:	49 83 c6 01          	add    $0x1,%r14
    699f:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    69a3:	e9 a0 fa ff ff       	jmp    6448 <fwp_hof0.constprop.0+0x198>
    69a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69af:	00 
    69b0:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    69b4:	e9 8e fc ff ff       	jmp    6647 <fwp_hof0.constprop.0+0x397>
    69b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	0f 85 03 fb ff ff    	jne    64cc <fwp_hof0.constprop.0+0x21c>
    69c9:	e9 e1 fa ff ff       	jmp    64af <fwp_hof0.constprop.0+0x1ff>
    69ce:	66 90                	xchg   %ax,%ax
    69d0:	be 01 00 00 00       	mov    $0x1,%esi
    69d5:	48 89 df             	mov    %rbx,%rdi
    69d8:	e8 13 c5 ff ff       	call   2ef0 <buf_grow>
    69dd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    69e2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    69e7:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    69eb:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    69f0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    69f4:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    69f9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    69fe:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6a03:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    6a08:	48 8d 05 5f 46 00 00 	lea    0x465f(%rip),%rax        # b06e <_IO_stdin_used+0x6e>
    6a0f:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    6a14:	48 85 c9             	test   %rcx,%rcx
    6a17:	48 0f 44 c8          	cmove  %rax,%rcx
    6a1b:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    6a1f:	0f 87 c3 07 00 00    	ja     71e8 <fwp_hof0.constprop.0+0xf38>
    6a25:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    6a29:	be 01 00 00 00       	mov    $0x1,%esi
    6a2e:	48 89 0c 24          	mov    %rcx,(%rsp)
    6a32:	e8 09 dd ff ff       	call   4740 <fwp_heap_alloc>
    6a37:	48 8b 34 24          	mov    (%rsp),%rsi
    6a3b:	4c 89 fa             	mov    %r15,%rdx
    6a3e:	4c 89 38             	mov    %r15,(%rax)
    6a41:	48 8d 58 08          	lea    0x8(%rax),%rbx
    6a45:	49 89 c6             	mov    %rax,%r14
    6a48:	48 89 df             	mov    %rbx,%rdi
    6a4b:	e8 20 bb ff ff       	call   2570 <memcpy@plt>
    6a50:	43 c6 44 3e 08 00    	movb   $0x0,0x8(%r14,%r15,1)
    6a56:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    6a5b:	e8 40 b9 ff ff       	call   23a0 <free@plt>
    6a60:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    6a67:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6a6e:	4c 89 f0             	mov    %r14,%rax
    6a71:	48 29 c8             	sub    %rcx,%rax
    6a74:	48 c1 e2 10          	shl    $0x10,%rdx
    6a78:	48 39 d0             	cmp    %rdx,%rax
    6a7b:	73 6b                	jae    6ae8 <fwp_hof0.constprop.0+0x838>
    6a7d:	48 89 c6             	mov    %rax,%rsi
    6a80:	48 c1 ee 10          	shr    $0x10,%rsi
    6a84:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6a88:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    6a8f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    6a93:	4c 8b 7e 20          	mov    0x20(%rsi),%r15
    6a97:	4d 85 ff             	test   %r15,%r15
    6a9a:	74 4c                	je     6ae8 <fwp_hof0.constprop.0+0x838>
    6a9c:	0f b6 3e             	movzbl (%rsi),%edi
    6a9f:	40 80 ff 02          	cmp    $0x2,%dil
    6aa3:	0f 84 87 04 00 00    	je     6f30 <fwp_hof0.constprop.0+0xc80>
    6aa9:	40 80 ff 01          	cmp    $0x1,%dil
    6aad:	75 39                	jne    6ae8 <fwp_hof0.constprop.0+0x838>
    6aaf:	8b 7e 18             	mov    0x18(%rsi),%edi
    6ab2:	0f b7 c0             	movzwl %ax,%eax
    6ab5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ab8:	48 0f af c7          	imul   %rdi,%rax
    6abc:	48 c1 e8 20          	shr    $0x20,%rax
    6ac0:	48 39 f0             	cmp    %rsi,%rax
    6ac3:	73 23                	jae    6ae8 <fwp_hof0.constprop.0+0x838>
    6ac5:	49 01 c7             	add    %rax,%r15
    6ac8:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6acc:	0f 84 71 04 00 00    	je     6f43 <fwp_hof0.constprop.0+0xc93>
    6ad2:	41 c6 07 01          	movb   $0x1,(%r15)
    6ad6:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6add:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    6ae4:	48 c1 e2 10          	shl    $0x10,%rdx
    6ae8:	48 89 e8             	mov    %rbp,%rax
    6aeb:	48 29 c8             	sub    %rcx,%rax
    6aee:	48 39 d0             	cmp    %rdx,%rax
    6af1:	73 6d                	jae    6b60 <fwp_hof0.constprop.0+0x8b0>
    6af3:	48 89 c2             	mov    %rax,%rdx
    6af6:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    6afd:	48 c1 ea 10          	shr    $0x10,%rdx
    6b01:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6b05:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6b09:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    6b0d:	4d 85 ff             	test   %r15,%r15
    6b10:	74 4e                	je     6b60 <fwp_hof0.constprop.0+0x8b0>
    6b12:	0f b6 32             	movzbl (%rdx),%esi
    6b15:	40 80 fe 02          	cmp    $0x2,%sil
    6b19:	0f 84 31 03 00 00    	je     6e50 <fwp_hof0.constprop.0+0xba0>
    6b1f:	40 80 fe 01          	cmp    $0x1,%sil
    6b23:	75 3b                	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    6b25:	8b 72 18             	mov    0x18(%rdx),%esi
    6b28:	0f b7 c0             	movzwl %ax,%eax
    6b2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b2e:	48 0f af c6          	imul   %rsi,%rax
    6b32:	48 c1 e8 20          	shr    $0x20,%rax
    6b36:	48 39 d0             	cmp    %rdx,%rax
    6b39:	73 25                	jae    6b60 <fwp_hof0.constprop.0+0x8b0>
    6b3b:	49 01 c7             	add    %rax,%r15
    6b3e:	41 0f b6 07          	movzbl (%r15),%eax
    6b42:	84 c0                	test   %al,%al
    6b44:	74 1a                	je     6b60 <fwp_hof0.constprop.0+0x8b0>
    6b46:	3c 01                	cmp    $0x1,%al
    6b48:	0f 84 02 01 00 00    	je     6c50 <fwp_hof0.constprop.0+0x9a0>
    6b4e:	3c ff                	cmp    $0xff,%al
    6b50:	0f 84 89 04 00 00    	je     6fdf <fwp_hof0.constprop.0+0xd2f>
    6b56:	83 e8 01             	sub    $0x1,%eax
    6b59:	41 88 07             	mov    %al,(%r15)
    6b5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6b60:	49 8b 16             	mov    (%r14),%rdx
    6b63:	48 8b 0d 2e 98 01 00 	mov    0x1982e(%rip),%rcx        # 20398 <fwp_prog_out>
    6b6a:	be 01 00 00 00       	mov    $0x1,%esi
    6b6f:	48 89 df             	mov    %rbx,%rdi
    6b72:	e8 c9 ba ff ff       	call   2640 <fwrite@plt>
    6b77:	48 8b 35 1a 98 01 00 	mov    0x1981a(%rip),%rsi        # 20398 <fwp_prog_out>
    6b7e:	bf 0a 00 00 00       	mov    $0xa,%edi
    6b83:	e8 38 b9 ff ff       	call   24c0 <fputc@plt>
    6b88:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6b8f:	4c 89 f0             	mov    %r14,%rax
    6b92:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6b99:	48 c1 e2 10          	shl    $0x10,%rdx
    6b9d:	48 39 d0             	cmp    %rdx,%rax
    6ba0:	73 6e                	jae    6c10 <fwp_hof0.constprop.0+0x960>
    6ba2:	48 89 c2             	mov    %rax,%rdx
    6ba5:	48 c1 ea 10          	shr    $0x10,%rdx
    6ba9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bad:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6bb4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6bb8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    6bbc:	48 85 db             	test   %rbx,%rbx
    6bbf:	74 4f                	je     6c10 <fwp_hof0.constprop.0+0x960>
    6bc1:	0f b6 0a             	movzbl (%rdx),%ecx
    6bc4:	80 f9 02             	cmp    $0x2,%cl
    6bc7:	0f 84 53 03 00 00    	je     6f20 <fwp_hof0.constprop.0+0xc70>
    6bcd:	80 f9 01             	cmp    $0x1,%cl
    6bd0:	75 3e                	jne    6c10 <fwp_hof0.constprop.0+0x960>
    6bd2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6bd5:	0f b7 c0             	movzwl %ax,%eax
    6bd8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bdb:	48 0f af c1          	imul   %rcx,%rax
    6bdf:	48 c1 e8 20          	shr    $0x20,%rax
    6be3:	48 39 d0             	cmp    %rdx,%rax
    6be6:	73 28                	jae    6c10 <fwp_hof0.constprop.0+0x960>
    6be8:	48 01 c3             	add    %rax,%rbx
    6beb:	0f b6 03             	movzbl (%rbx),%eax
    6bee:	84 c0                	test   %al,%al
    6bf0:	74 1e                	je     6c10 <fwp_hof0.constprop.0+0x960>
    6bf2:	3c 01                	cmp    $0x1,%al
    6bf4:	0f 84 06 02 00 00    	je     6e00 <fwp_hof0.constprop.0+0xb50>
    6bfa:	3c ff                	cmp    $0xff,%al
    6bfc:	0f 84 5d 04 00 00    	je     705f <fwp_hof0.constprop.0+0xdaf>
    6c02:	83 e8 01             	sub    $0x1,%eax
    6c05:	88 03                	mov    %al,(%rbx)
    6c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c0e:	00 00 
    6c10:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6c15:	48 8b 40 10          	mov    0x10(%rax),%rax
    6c19:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6c1e:	48 85 c0             	test   %rax,%rax
    6c21:	0f 85 c9 f6 ff ff    	jne    62f0 <fwp_hof0.constprop.0+0x40>
    6c27:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c2c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c33:	00 00 
    6c35:	0f 85 ce 05 00 00    	jne    7209 <fwp_hof0.constprop.0+0xf59>
    6c3b:	48 83 c4 38          	add    $0x38,%rsp
    6c3f:	31 c0                	xor    %eax,%eax
    6c41:	5b                   	pop    %rbx
    6c42:	5d                   	pop    %rbp
    6c43:	41 5c                	pop    %r12
    6c45:	41 5d                	pop    %r13
    6c47:	41 5e                	pop    %r14
    6c49:	41 5f                	pop    %r15
    6c4b:	c3                   	ret
    6c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c50:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6c55:	0f 88 05 02 00 00    	js     6e60 <fwp_hof0.constprop.0+0xbb0>
    6c5b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6c62:	48 89 e8             	mov    %rbp,%rax
    6c65:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6c6c:	48 c1 e2 10          	shl    $0x10,%rdx
    6c70:	48 39 d0             	cmp    %rdx,%rax
    6c73:	0f 83 e7 fe ff ff    	jae    6b60 <fwp_hof0.constprop.0+0x8b0>
    6c79:	48 89 c2             	mov    %rax,%rdx
    6c7c:	48 c1 ea 10          	shr    $0x10,%rdx
    6c80:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6c84:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    6c88:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6c8c:	48 85 c9             	test   %rcx,%rcx
    6c8f:	0f 84 cb fe ff ff    	je     6b60 <fwp_hof0.constprop.0+0x8b0>
    6c95:	0f b6 32             	movzbl (%rdx),%esi
    6c98:	40 80 fe 02          	cmp    $0x2,%sil
    6c9c:	0f 84 ae 02 00 00    	je     6f50 <fwp_hof0.constprop.0+0xca0>
    6ca2:	40 80 fe 01          	cmp    $0x1,%sil
    6ca6:	0f 85 b4 fe ff ff    	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    6cac:	8b 72 18             	mov    0x18(%rdx),%esi
    6caf:	0f b7 c0             	movzwl %ax,%eax
    6cb2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6cb5:	48 0f af c6          	imul   %rsi,%rax
    6cb9:	48 c1 e8 20          	shr    $0x20,%rax
    6cbd:	48 39 d0             	cmp    %rdx,%rax
    6cc0:	0f 83 9a fe ff ff    	jae    6b60 <fwp_hof0.constprop.0+0x8b0>
    6cc6:	48 01 c1             	add    %rax,%rcx
    6cc9:	80 39 01             	cmpb   $0x1,(%rcx)
    6ccc:	0f 85 8e fe ff ff    	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    6cd2:	48 89 ef             	mov    %rbp,%rdi
    6cd5:	e8 36 d4 ff ff       	call   4110 <fwp_mem_free>
    6cda:	e9 81 fe ff ff       	jmp    6b60 <fwp_hof0.constprop.0+0x8b0>
    6cdf:	90                   	nop
    6ce0:	48 39 fe             	cmp    %rdi,%rsi
    6ce3:	0f 83 e8 f9 ff ff    	jae    66d1 <fwp_hof0.constprop.0+0x421>
    6ce9:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    6ced:	f2 0f 10 1d 8b 49 00 	movsd  0x498b(%rip),%xmm3        # b680 <msg.3+0xb0>
    6cf4:	00 
    6cf5:	f2 0f 10 25 8b 49 00 	movsd  0x498b(%rip),%xmm4        # b688 <msg.3+0xb8>
    6cfc:	00 
    6cfd:	f2 0f 10 04 07       	movsd  (%rdi,%rax,1),%xmm0
    6d02:	f2 0f 5c d8          	subsd  %xmm0,%xmm3
    6d06:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    6d0a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6d0e:	f2 0f 58 db          	addsd  %xmm3,%xmm3
    6d12:	e9 02 f9 ff ff       	jmp    6619 <fwp_hof0.constprop.0+0x369>
    6d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d1e:	00 00 
    6d20:	4c 39 c7             	cmp    %r8,%rdi
    6d23:	0f 83 a8 f9 ff ff    	jae    66d1 <fwp_hof0.constprop.0+0x421>
    6d29:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    6d2d:	f2 0f 10 04 01       	movsd  (%rcx,%rax,1),%xmm0
    6d32:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6d36:	e9 63 f9 ff ff       	jmp    669e <fwp_hof0.constprop.0+0x3ee>
    6d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d40:	66 85 c0             	test   %ax,%ax
    6d43:	0f 85 27 fa ff ff    	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    6d49:	e9 f7 f9 ff ff       	jmp    6745 <fwp_hof0.constprop.0+0x495>
    6d4e:	66 90                	xchg   %ax,%ax
    6d50:	48 8b 5b 08          	mov    0x8(%rbx),%rbx
    6d54:	48 39 d0             	cmp    %rdx,%rax
    6d57:	73 63                	jae    6dbc <fwp_hof0.constprop.0+0xb0c>
    6d59:	49 89 c0             	mov    %rax,%r8
    6d5c:	49 c1 e8 10          	shr    $0x10,%r8
    6d60:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    6d64:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
    6d68:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    6d6c:	4d 85 c0             	test   %r8,%r8
    6d6f:	74 4b                	je     6dbc <fwp_hof0.constprop.0+0xb0c>
    6d71:	44 0f b6 09          	movzbl (%rcx),%r9d
    6d75:	41 80 f9 02          	cmp    $0x2,%r9b
    6d79:	0f 84 df 01 00 00    	je     6f5e <fwp_hof0.constprop.0+0xcae>
    6d7f:	41 80 f9 01          	cmp    $0x1,%r9b
    6d83:	75 37                	jne    6dbc <fwp_hof0.constprop.0+0xb0c>
    6d85:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    6d89:	0f b7 c0             	movzwl %ax,%eax
    6d8c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d8f:	49 0f af c1          	imul   %r9,%rax
    6d93:	48 c1 e8 20          	shr    $0x20,%rax
    6d97:	48 39 c8             	cmp    %rcx,%rax
    6d9a:	73 20                	jae    6dbc <fwp_hof0.constprop.0+0xb0c>
    6d9c:	49 01 c0             	add    %rax,%r8
    6d9f:	41 80 38 01          	cmpb   $0x1,(%r8)
    6da3:	75 17                	jne    6dbc <fwp_hof0.constprop.0+0xb0c>
    6da5:	e8 66 d3 ff ff       	call   4110 <fwp_mem_free>
    6daa:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6db1:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    6db8:	48 c1 e2 10          	shl    $0x10,%rdx
    6dbc:	48 89 d8             	mov    %rbx,%rax
    6dbf:	48 29 f0             	sub    %rsi,%rax
    6dc2:	48 39 d0             	cmp    %rdx,%rax
    6dc5:	0f 82 2f f9 ff ff    	jb     66fa <fwp_hof0.constprop.0+0x44a>
    6dcb:	e9 a0 f9 ff ff       	jmp    6770 <fwp_hof0.constprop.0+0x4c0>
    6dd0:	66 85 c0             	test   %ax,%ax
    6dd3:	0f 85 b8 f7 ff ff    	jne    6591 <fwp_hof0.constprop.0+0x2e1>
    6dd9:	80 39 ff             	cmpb   $0xff,(%rcx)
    6ddc:	0f 85 ac f7 ff ff    	jne    658e <fwp_hof0.constprop.0+0x2de>
    6de2:	48 89 cf             	mov    %rcx,%rdi
    6de5:	48 89 0c 24          	mov    %rcx,(%rsp)
    6de9:	e8 e2 d0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6dee:	48 8b 0c 24          	mov    (%rsp),%rcx
    6df2:	e9 97 f7 ff ff       	jmp    658e <fwp_hof0.constprop.0+0x2de>
    6df7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dfe:	00 00 
    6e00:	4c 89 f7             	mov    %r14,%rdi
    6e03:	e8 b8 d8 ff ff       	call   46c0 <fwp_rc_free_arr>
    6e08:	e9 03 fe ff ff       	jmp    6c10 <fwp_hof0.constprop.0+0x960>
    6e0d:	0f 1f 00             	nopl   (%rax)
    6e10:	66 85 c0             	test   %ax,%ax
    6e13:	0f 85 57 f9 ff ff    	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    6e19:	e9 b0 fa ff ff       	jmp    68ce <fwp_hof0.constprop.0+0x61e>
    6e1e:	66 90                	xchg   %ax,%ax
    6e20:	66 85 d2             	test   %dx,%dx
    6e23:	0f 84 4f fb ff ff    	je     6978 <fwp_hof0.constprop.0+0x6c8>
    6e29:	48 85 ed             	test   %rbp,%rbp
    6e2c:	0f 85 5c fb ff ff    	jne    698e <fwp_hof0.constprop.0+0x6de>
    6e32:	0f 1f 00             	nopl   (%rax)
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	45 31 c0             	xor    %r8d,%r8d
    6e43:	e9 97 f6 ff ff       	jmp    64df <fwp_hof0.constprop.0+0x22f>
    6e48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e4f:	00 
    6e50:	66 85 c0             	test   %ax,%ax
    6e53:	0f 85 07 fd ff ff    	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    6e59:	e9 e0 fc ff ff       	jmp    6b3e <fwp_hof0.constprop.0+0x88e>
    6e5e:	66 90                	xchg   %ax,%ax
    6e60:	48 89 ef             	mov    %rbp,%rdi
    6e63:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6e67:	e8 54 d8 ff ff       	call   46c0 <fwp_rc_free_arr>
    6e6c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6e73:	4c 89 f8             	mov    %r15,%rax
    6e76:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6e7d:	48 c1 e2 10          	shl    $0x10,%rdx
    6e81:	48 39 d0             	cmp    %rdx,%rax
    6e84:	0f 83 d6 fc ff ff    	jae    6b60 <fwp_hof0.constprop.0+0x8b0>
    6e8a:	4c 89 fd             	mov    %r15,%rbp
    6e8d:	e9 61 fc ff ff       	jmp    6af3 <fwp_hof0.constprop.0+0x843>
    6e92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e98:	66 85 c0             	test   %ax,%ax
    6e9b:	0f 85 85 f5 ff ff    	jne    6426 <fwp_hof0.constprop.0+0x176>
    6ea1:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6ea5:	0f 85 77 f5 ff ff    	jne    6422 <fwp_hof0.constprop.0+0x172>
    6eab:	48 89 ef             	mov    %rbp,%rdi
    6eae:	e8 1d d0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6eb3:	e9 6a f5 ff ff       	jmp    6422 <fwp_hof0.constprop.0+0x172>
    6eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ebf:	00 
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	0f 84 8a f4 ff ff    	je     6353 <fwp_hof0.constprop.0+0xa3>
    6ec9:	4d 85 e4             	test   %r12,%r12
    6ecc:	0f 85 b0 f4 ff ff    	jne    6382 <fwp_hof0.constprop.0+0xd2>
    6ed2:	31 ff                	xor    %edi,%edi
    6ed4:	e8 37 dc ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    6ed9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    6ee0:	48 89 c3             	mov    %rax,%rbx
    6ee3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    6eea:	48 c1 e2 10          	shl    $0x10,%rdx
    6eee:	48 39 d0             	cmp    %rdx,%rax
    6ef1:	0f 83 49 ff ff ff    	jae    6e40 <fwp_hof0.constprop.0+0xb90>
    6ef7:	48 89 c2             	mov    %rax,%rdx
    6efa:	48 c1 ea 10          	shr    $0x10,%rdx
    6efe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f02:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    6f09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f0d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    6f11:	48 85 ed             	test   %rbp,%rbp
    6f14:	0f 85 d4 f4 ff ff    	jne    63ee <fwp_hof0.constprop.0+0x13e>
    6f1a:	e9 21 ff ff ff       	jmp    6e40 <fwp_hof0.constprop.0+0xb90>
    6f1f:	90                   	nop
    6f20:	66 85 c0             	test   %ax,%ax
    6f23:	0f 85 e7 fc ff ff    	jne    6c10 <fwp_hof0.constprop.0+0x960>
    6f29:	e9 bd fc ff ff       	jmp    6beb <fwp_hof0.constprop.0+0x93b>
    6f2e:	66 90                	xchg   %ax,%ax
    6f30:	66 85 c0             	test   %ax,%ax
    6f33:	0f 85 af fb ff ff    	jne    6ae8 <fwp_hof0.constprop.0+0x838>
    6f39:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6f3d:	0f 85 8f fb ff ff    	jne    6ad2 <fwp_hof0.constprop.0+0x822>
    6f43:	4c 89 ff             	mov    %r15,%rdi
    6f46:	e8 85 cf ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6f4b:	e9 82 fb ff ff       	jmp    6ad2 <fwp_hof0.constprop.0+0x822>
    6f50:	66 85 c0             	test   %ax,%ax
    6f53:	0f 85 07 fc ff ff    	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    6f59:	e9 6b fd ff ff       	jmp    6cc9 <fwp_hof0.constprop.0+0xa19>
    6f5e:	66 85 c0             	test   %ax,%ax
    6f61:	0f 85 55 fe ff ff    	jne    6dbc <fwp_hof0.constprop.0+0xb0c>
    6f67:	e9 33 fe ff ff       	jmp    6d9f <fwp_hof0.constprop.0+0xaef>
    6f6c:	4c 89 f0             	mov    %r14,%rax
    6f6f:	48 c1 e8 11          	shr    $0x11,%rax
    6f73:	4c 31 f0             	xor    %r14,%rax
    6f76:	48 89 c2             	mov    %rax,%rdx
    6f79:	48 c1 ea 09          	shr    $0x9,%rdx
    6f7d:	48 31 d0             	xor    %rdx,%rax
    6f80:	0f b6 d0             	movzbl %al,%edx
    6f83:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    6f8a:	00 
    6f8b:	48 85 c0             	test   %rax,%rax
    6f8e:	75 1d                	jne    6fad <fwp_hof0.constprop.0+0xcfd>
    6f90:	e9 30 02 00 00       	jmp    71c5 <fwp_hof0.constprop.0+0xf15>
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 
    6fa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6fa4:	48 85 c0             	test   %rax,%rax
    6fa7:	0f 84 18 02 00 00    	je     71c5 <fwp_hof0.constprop.0+0xf15>
    6fad:	48 89 c2             	mov    %rax,%rdx
    6fb0:	4c 3b 30             	cmp    (%rax),%r14
    6fb3:	75 eb                	jne    6fa0 <fwp_hof0.constprop.0+0xcf0>
    6fb5:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6fb9:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    6fbd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fc1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6fc8:	0f 85 a2 f7 ff ff    	jne    6770 <fwp_hof0.constprop.0+0x4c0>
    6fce:	4c 89 f7             	mov    %r14,%rdi
    6fd1:	e8 fa ce ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6fd6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    6fda:	e9 91 f7 ff ff       	jmp    6770 <fwp_hof0.constprop.0+0x4c0>
    6fdf:	4c 89 fa             	mov    %r15,%rdx
    6fe2:	48 c1 ea 11          	shr    $0x11,%rdx
    6fe6:	4c 31 fa             	xor    %r15,%rdx
    6fe9:	48 89 d0             	mov    %rdx,%rax
    6fec:	48 c1 e8 09          	shr    $0x9,%rax
    6ff0:	48 31 c2             	xor    %rax,%rdx
    6ff3:	0f b6 d2             	movzbl %dl,%edx
    6ff6:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    6ffd:	00 
    6ffe:	48 85 c0             	test   %rax,%rax
    7001:	75 2a                	jne    702d <fwp_hof0.constprop.0+0xd7d>
    7003:	e9 bd 01 00 00       	jmp    71c5 <fwp_hof0.constprop.0+0xf15>
    7008:	66 90                	xchg   %ax,%ax
    700a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7011:	00 00 00 00 
    7015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    701c:	00 00 00 00 
    7020:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7024:	48 85 c0             	test   %rax,%rax
    7027:	0f 84 98 01 00 00    	je     71c5 <fwp_hof0.constprop.0+0xf15>
    702d:	48 89 c2             	mov    %rax,%rdx
    7030:	4c 3b 38             	cmp    (%rax),%r15
    7033:	75 eb                	jne    7020 <fwp_hof0.constprop.0+0xd70>
    7035:	48 8b 48 08          	mov    0x8(%rax),%rcx
    7039:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    703d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7041:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7048:	0f 85 12 fb ff ff    	jne    6b60 <fwp_hof0.constprop.0+0x8b0>
    704e:	4c 89 ff             	mov    %r15,%rdi
    7051:	e8 7a ce ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7056:	41 c6 07 fe          	movb   $0xfe,(%r15)
    705a:	e9 01 fb ff ff       	jmp    6b60 <fwp_hof0.constprop.0+0x8b0>
    705f:	48 89 d8             	mov    %rbx,%rax
    7062:	48 c1 e8 11          	shr    $0x11,%rax
    7066:	48 31 d8             	xor    %rbx,%rax
    7069:	48 89 c2             	mov    %rax,%rdx
    706c:	48 c1 ea 09          	shr    $0x9,%rdx
    7070:	48 31 d0             	xor    %rdx,%rax
    7073:	0f b6 d0             	movzbl %al,%edx
    7076:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    707d:	00 
    707e:	48 85 c0             	test   %rax,%rax
    7081:	75 2a                	jne    70ad <fwp_hof0.constprop.0+0xdfd>
    7083:	e9 3d 01 00 00       	jmp    71c5 <fwp_hof0.constprop.0+0xf15>
    7088:	66 90                	xchg   %ax,%ax
    708a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7091:	00 00 00 00 
    7095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    709c:	00 00 00 00 
    70a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    70a4:	48 85 c0             	test   %rax,%rax
    70a7:	0f 84 18 01 00 00    	je     71c5 <fwp_hof0.constprop.0+0xf15>
    70ad:	48 89 c2             	mov    %rax,%rdx
    70b0:	48 3b 18             	cmp    (%rax),%rbx
    70b3:	75 eb                	jne    70a0 <fwp_hof0.constprop.0+0xdf0>
    70b5:	48 8b 48 08          	mov    0x8(%rax),%rcx
    70b9:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    70bd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70c1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    70c8:	0f 85 42 fb ff ff    	jne    6c10 <fwp_hof0.constprop.0+0x960>
    70ce:	48 89 df             	mov    %rbx,%rdi
    70d1:	e8 fa cd ff ff       	call   3ed0 <fwp_rc_forget_slot>
    70d6:	c6 03 fe             	movb   $0xfe,(%rbx)
    70d9:	e9 32 fb ff ff       	jmp    6c10 <fwp_hof0.constprop.0+0x960>
    70de:	48 89 d9             	mov    %rbx,%rcx
    70e1:	48 c1 e9 11          	shr    $0x11,%rcx
    70e5:	48 31 d9             	xor    %rbx,%rcx
    70e8:	48 89 ca             	mov    %rcx,%rdx
    70eb:	48 c1 ea 09          	shr    $0x9,%rdx
    70ef:	48 31 d1             	xor    %rdx,%rcx
    70f2:	0f b6 c9             	movzbl %cl,%ecx
    70f5:	49 8d ac cd 48 14 00 	lea    0x1448(%r13,%rcx,8),%rbp
    70fc:	00 
    70fd:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    7101:	49 83 bc cd 48 14 00 	cmpq   $0x0,0x1448(%r13,%rcx,8)
    7108:	00 00 
    710a:	75 20                	jne    712c <fwp_hof0.constprop.0+0xe7c>
    710c:	e9 89 00 00 00       	jmp    719a <fwp_hof0.constprop.0+0xeea>
    7111:	0f 1f 40 00          	nopl   0x0(%rax)
    7115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    711c:	00 00 00 00 
    7120:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7124:	48 85 c9             	test   %rcx,%rcx
    7127:	74 27                	je     7150 <fwp_hof0.constprop.0+0xea0>
    7129:	48 89 ca             	mov    %rcx,%rdx
    712c:	48 39 1a             	cmp    %rbx,(%rdx)
    712f:	75 ef                	jne    7120 <fwp_hof0.constprop.0+0xe70>
    7131:	3c fe                	cmp    $0xfe,%al
    7133:	74 6e                	je     71a3 <fwp_hof0.constprop.0+0xef3>
    7135:	48 8b 42 08          	mov    0x8(%rdx),%rax
    7139:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    713d:	0f 84 93 00 00 00    	je     71d6 <fwp_hof0.constprop.0+0xf26>
    7143:	48 83 c0 01          	add    $0x1,%rax
    7147:	48 89 42 08          	mov    %rax,0x8(%rdx)
    714b:	e9 29 f2 ff ff       	jmp    6379 <fwp_hof0.constprop.0+0xc9>
    7150:	3c fe                	cmp    $0xfe,%al
    7152:	75 71                	jne    71c5 <fwp_hof0.constprop.0+0xf15>
    7154:	48 8d 6a 10          	lea    0x10(%rdx),%rbp
    7158:	bf 18 00 00 00       	mov    $0x18,%edi
    715d:	e8 1e b4 ff ff       	call   2580 <malloc@plt>
    7162:	48 85 c0             	test   %rax,%rax
    7165:	74 6a                	je     71d1 <fwp_hof0.constprop.0+0xf21>
    7167:	48 89 18             	mov    %rbx,(%rax)
    716a:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    7171:	00 
    7172:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    7179:	00 
    717a:	48 89 45 00          	mov    %rax,0x0(%rbp)
    717e:	c6 03 ff             	movb   $0xff,(%rbx)
    7181:	49 83 85 48 1c 00 00 	addq   $0x1,0x1c48(%r13)
    7188:	01 
    7189:	e9 eb f1 ff ff       	jmp    6379 <fwp_hof0.constprop.0+0xc9>
    718e:	48 8d 3d 5b 42 00 00 	lea    0x425b(%rip),%rdi        # b3f0 <_IO_stdin_used+0x3f0>
    7195:	e8 66 c0 ff ff       	call   3200 <fwp_trap>
    719a:	3c fe                	cmp    $0xfe,%al
    719c:	75 1e                	jne    71bc <fwp_hof0.constprop.0+0xf0c>
    719e:	48 85 d2             	test   %rdx,%rdx
    71a1:	74 b5                	je     7158 <fwp_hof0.constprop.0+0xea8>
    71a3:	48 8d 3d 1e 42 00 00 	lea    0x421e(%rip),%rdi        # b3c8 <_IO_stdin_used+0x3c8>
    71aa:	e8 51 c0 ff ff       	call   3200 <fwp_trap>
    71af:	90                   	nop
    71b0:	48 8d 3d 2e 3f 00 00 	lea    0x3f2e(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    71b7:	e8 44 c0 ff ff       	call   3200 <fwp_trap>
    71bc:	48 85 d2             	test   %rdx,%rdx
    71bf:	0f 85 70 ff ff ff    	jne    7135 <fwp_hof0.constprop.0+0xe85>
    71c5:	48 8d 3d d4 41 00 00 	lea    0x41d4(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    71cc:	e8 2f c0 ff ff       	call   3200 <fwp_trap>
    71d1:	e8 1a bb ff ff       	call   2cf0 <fwp_heap_oom>
    71d6:	48 8d 3d a7 3f 00 00 	lea    0x3fa7(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    71dd:	e8 1e c0 ff ff       	call   3200 <fwp_trap>
    71e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71e8:	48 8d 3d ae 3f 00 00 	lea    0x3fae(%rip),%rdi        # b19d <_IO_stdin_used+0x19d>
    71ef:	e8 0c c0 ff ff       	call   3200 <fwp_trap>
    71f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71f8:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    71fc:	f2 0f 59 05 8c 44 00 	mulsd  0x448c(%rip),%xmm0        # b690 <msg.3+0xc0>
    7203:	00 
    7204:	e9 32 f4 ff ff       	jmp    663b <fwp_hof0.constprop.0+0x38b>
    7209:	e8 32 b2 ff ff       	call   2440 <__stack_chk_fail@plt>
    720e:	66 90                	xchg   %ax,%ax

0000000000007210 <f0>:
    7210:	41 56                	push   %r14
    7212:	4c 8d 35 27 75 01 00 	lea    0x17527(%rip),%r14        # 1e740 <fwp_heap>
    7219:	41 55                	push   %r13
    721b:	41 54                	push   %r12
    721d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    7223:	55                   	push   %rbp
    7224:	53                   	push   %rbx
    7225:	31 db                	xor    %ebx,%ebx
    7227:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    722e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7235:	00 00 
    7237:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    723e:	00 
    723f:	31 c0                	xor    %eax,%eax
    7241:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    7248:	00 
    7249:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    7250:	00 00 
    7252:	66 48 0f 6e c0       	movq   %rax,%xmm0
    7257:	48 8d 05 f2 de ff ff 	lea    -0x210e(%rip),%rax        # 5150 <fwp_drop1>
    725e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7263:	48 8b 05 66 91 01 00 	mov    0x19166(%rip),%rax        # 203d0 <fwp_cleanups>
    726a:	48 89 25 5f 91 01 00 	mov    %rsp,0x1915f(%rip)        # 203d0 <fwp_cleanups>
    7271:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    7275:	48 89 04 24          	mov    %rax,(%rsp)
    7279:	48 8d 05 10 b9 ff ff 	lea    -0x46f0(%rip),%rax        # 2b90 <fwp_range_release>
    7280:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7285:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    728a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    728f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    7294:	eb 43                	jmp    72d9 <f0+0xc9>
    7296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    729d:	00 00 00 
    72a0:	80 f9 01             	cmp    $0x1,%cl
    72a3:	75 29                	jne    72ce <f0+0xbe>
    72a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    72a8:	0f b7 c0             	movzwl %ax,%eax
    72ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72ae:	48 0f af c1          	imul   %rcx,%rax
    72b2:	48 c1 e8 20          	shr    $0x20,%rax
    72b6:	48 39 d0             	cmp    %rdx,%rax
    72b9:	73 13                	jae    72ce <f0+0xbe>
    72bb:	49 01 c5             	add    %rax,%r13
    72be:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    72c3:	0f 84 2f 25 00 00    	je     97f8 <f0+0x25e8>
    72c9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    72ce:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    72d3:	49 83 ec 01          	sub    $0x1,%r12
    72d7:	72 77                	jb     7350 <f0+0x140>
    72d9:	48 89 ef             	mov    %rbp,%rdi
    72dc:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    72e3:	00 
    72e4:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    72e9:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    72f0:	00 
    72f1:	e8 3a d6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    72f6:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    72fd:	48 89 c3             	mov    %rax,%rbx
    7300:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    7307:	48 c1 e2 10          	shl    $0x10,%rdx
    730b:	48 39 d0             	cmp    %rdx,%rax
    730e:	73 be                	jae    72ce <f0+0xbe>
    7310:	48 89 c2             	mov    %rax,%rdx
    7313:	48 c1 ea 10          	shr    $0x10,%rdx
    7317:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    731b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    7322:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7326:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    732a:	4d 85 ed             	test   %r13,%r13
    732d:	74 9f                	je     72ce <f0+0xbe>
    732f:	0f b6 0a             	movzbl (%rdx),%ecx
    7332:	80 f9 02             	cmp    $0x2,%cl
    7335:	0f 85 65 ff ff ff    	jne    72a0 <f0+0x90>
    733b:	66 85 c0             	test   %ax,%ax
    733e:	0f 84 7a ff ff ff    	je     72be <f0+0xae>
    7344:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7349:	49 83 ec 01          	sub    $0x1,%r12
    734d:	73 8a                	jae    72d9 <f0+0xc9>
    734f:	90                   	nop
    7350:	48 8b 04 24          	mov    (%rsp),%rax
    7354:	66 0f 6f 05 04 43 00 	movdqa 0x4304(%rip),%xmm0        # b660 <msg.3+0x90>
    735b:	00 
    735c:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
    7361:	48 89 05 68 90 01 00 	mov    %rax,0x19068(%rip)        # 203d0 <fwp_cleanups>
    7368:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    736d:	e8 be d5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7372:	48 8b 15 9f 87 01 00 	mov    0x1879f(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    7379:	49 89 c5             	mov    %rax,%r13
    737c:	48 2b 05 6d 87 01 00 	sub    0x1876d(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    7383:	48 c1 e2 10          	shl    $0x10,%rdx
    7387:	48 39 d0             	cmp    %rdx,%rax
    738a:	73 59                	jae    73e5 <f0+0x1d5>
    738c:	48 89 c2             	mov    %rax,%rdx
    738f:	48 c1 ea 10          	shr    $0x10,%rdx
    7393:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7397:	48 8b 15 9a 87 01 00 	mov    0x1879a(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    739e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73a2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    73a6:	4d 85 e4             	test   %r12,%r12
    73a9:	74 3a                	je     73e5 <f0+0x1d5>
    73ab:	0f b6 0a             	movzbl (%rdx),%ecx
    73ae:	80 f9 02             	cmp    $0x2,%cl
    73b1:	0f 84 f9 24 00 00    	je     98b0 <f0+0x26a0>
    73b7:	80 f9 01             	cmp    $0x1,%cl
    73ba:	75 29                	jne    73e5 <f0+0x1d5>
    73bc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73bf:	0f b7 c0             	movzwl %ax,%eax
    73c2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73c5:	48 0f af c1          	imul   %rcx,%rax
    73c9:	48 c1 e8 20          	shr    $0x20,%rax
    73cd:	48 39 d0             	cmp    %rdx,%rax
    73d0:	73 13                	jae    73e5 <f0+0x1d5>
    73d2:	49 01 c4             	add    %rax,%r12
    73d5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    73da:	0f 84 ab 26 00 00    	je     9a8b <f0+0x287b>
    73e0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    73e5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    73ec:	00 f0 3f 
    73ef:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
    73f4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    73f9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    73fe:	e8 2d d5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7403:	48 8b 15 0e 87 01 00 	mov    0x1870e(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    740a:	49 89 c5             	mov    %rax,%r13
    740d:	48 2b 05 dc 86 01 00 	sub    0x186dc(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    7414:	48 c1 e2 10          	shl    $0x10,%rdx
    7418:	48 39 d0             	cmp    %rdx,%rax
    741b:	73 59                	jae    7476 <f0+0x266>
    741d:	48 89 c2             	mov    %rax,%rdx
    7420:	48 c1 ea 10          	shr    $0x10,%rdx
    7424:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7428:	48 8b 15 09 87 01 00 	mov    0x18709(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    742f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7433:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7437:	4d 85 e4             	test   %r12,%r12
    743a:	74 3a                	je     7476 <f0+0x266>
    743c:	0f b6 0a             	movzbl (%rdx),%ecx
    743f:	80 f9 02             	cmp    $0x2,%cl
    7442:	0f 84 58 24 00 00    	je     98a0 <f0+0x2690>
    7448:	80 f9 01             	cmp    $0x1,%cl
    744b:	75 29                	jne    7476 <f0+0x266>
    744d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7450:	0f b7 c0             	movzwl %ax,%eax
    7453:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7456:	48 0f af c1          	imul   %rcx,%rax
    745a:	48 c1 e8 20          	shr    $0x20,%rax
    745e:	48 39 d0             	cmp    %rdx,%rax
    7461:	73 13                	jae    7476 <f0+0x266>
    7463:	49 01 c4             	add    %rax,%r12
    7466:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    746b:	0f 84 27 26 00 00    	je     9a98 <f0+0x2888>
    7471:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7476:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    747d:	33 f3 bf 
    7480:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
    7485:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    748a:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    748f:	e8 9c d4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7494:	48 8b 15 7d 86 01 00 	mov    0x1867d(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    749b:	49 89 c5             	mov    %rax,%r13
    749e:	48 2b 05 4b 86 01 00 	sub    0x1864b(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    74a5:	48 c1 e2 10          	shl    $0x10,%rdx
    74a9:	48 39 d0             	cmp    %rdx,%rax
    74ac:	73 59                	jae    7507 <f0+0x2f7>
    74ae:	48 89 c2             	mov    %rax,%rdx
    74b1:	48 c1 ea 10          	shr    $0x10,%rdx
    74b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74b9:	48 8b 15 78 86 01 00 	mov    0x18678(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    74c0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74c4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    74c8:	4d 85 e4             	test   %r12,%r12
    74cb:	74 3a                	je     7507 <f0+0x2f7>
    74cd:	0f b6 0a             	movzbl (%rdx),%ecx
    74d0:	80 f9 02             	cmp    $0x2,%cl
    74d3:	0f 84 b7 23 00 00    	je     9890 <f0+0x2680>
    74d9:	80 f9 01             	cmp    $0x1,%cl
    74dc:	75 29                	jne    7507 <f0+0x2f7>
    74de:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74e1:	0f b7 c0             	movzwl %ax,%eax
    74e4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74e7:	48 0f af c1          	imul   %rcx,%rax
    74eb:	48 c1 e8 20          	shr    $0x20,%rax
    74ef:	48 39 d0             	cmp    %rdx,%rax
    74f2:	73 13                	jae    7507 <f0+0x2f7>
    74f4:	49 01 c4             	add    %rax,%r12
    74f7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    74fc:	0f 84 a3 25 00 00    	je     9aa5 <f0+0x2895>
    7502:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7507:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    750e:	00 f0 3f 
    7511:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
    7516:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    751b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7520:	e8 0b d4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7525:	48 8b 15 ec 85 01 00 	mov    0x185ec(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    752c:	49 89 c5             	mov    %rax,%r13
    752f:	48 2b 05 ba 85 01 00 	sub    0x185ba(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    7536:	48 c1 e2 10          	shl    $0x10,%rdx
    753a:	48 39 d0             	cmp    %rdx,%rax
    753d:	73 59                	jae    7598 <f0+0x388>
    753f:	48 89 c2             	mov    %rax,%rdx
    7542:	48 c1 ea 10          	shr    $0x10,%rdx
    7546:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    754a:	48 8b 15 e7 85 01 00 	mov    0x185e7(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    7551:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7555:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7559:	4d 85 e4             	test   %r12,%r12
    755c:	74 3a                	je     7598 <f0+0x388>
    755e:	0f b6 0a             	movzbl (%rdx),%ecx
    7561:	80 f9 02             	cmp    $0x2,%cl
    7564:	0f 84 86 23 00 00    	je     98f0 <f0+0x26e0>
    756a:	80 f9 01             	cmp    $0x1,%cl
    756d:	75 29                	jne    7598 <f0+0x388>
    756f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7572:	0f b7 c0             	movzwl %ax,%eax
    7575:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7578:	48 0f af c1          	imul   %rcx,%rax
    757c:	48 c1 e8 20          	shr    $0x20,%rax
    7580:	48 39 d0             	cmp    %rdx,%rax
    7583:	73 13                	jae    7598 <f0+0x388>
    7585:	49 01 c4             	add    %rax,%r12
    7588:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    758d:	0f 84 1f 25 00 00    	je     9ab2 <f0+0x28a2>
    7593:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7598:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    759f:	00 
    75a0:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    75a7:	00 
    75a8:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    75af:	33 f3 bf 
    75b2:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    75b9:	00 f0 3f 
    75bc:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    75c3:	00 
    75c4:	e8 67 d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    75c9:	48 89 c7             	mov    %rax,%rdi
    75cc:	e8 3f d0 ff ff       	call   4610 <fwp_rc_fresh>
    75d1:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
    75d8:	00 
    75d9:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    75e0:	00 
    75e1:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    75e8:	00 
    75e9:	e8 42 d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    75ee:	48 89 c7             	mov    %rax,%rdi
    75f1:	e8 1a d0 ff ff       	call   4610 <fwp_rc_fresh>
    75f6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
    75fd:	00 
    75fe:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    7605:	00 
    7606:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    760d:	00 
    760e:	e8 1d d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7613:	48 89 c7             	mov    %rax,%rdi
    7616:	e8 f5 cf ff ff       	call   4610 <fwp_rc_fresh>
    761b:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
    7622:	00 
    7623:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    762a:	00 
    762b:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7632:	00 
    7633:	e8 f8 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7638:	48 89 c7             	mov    %rax,%rdi
    763b:	e8 d0 cf ff ff       	call   4610 <fwp_rc_fresh>
    7640:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
    7647:	00 
    7648:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    764f:	00 
    7650:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7657:	00 
    7658:	e8 d3 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    765d:	48 89 c7             	mov    %rax,%rdi
    7660:	e8 ab cf ff ff       	call   4610 <fwp_rc_fresh>
    7665:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
    766c:	00 
    766d:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    7674:	00 
    7675:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    767c:	00 
    767d:	e8 ae d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7682:	48 89 c7             	mov    %rax,%rdi
    7685:	e8 86 cf ff ff       	call   4610 <fwp_rc_fresh>
    768a:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
    7691:	00 
    7692:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    7699:	00 
    769a:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    76a1:	00 
    76a2:	e8 89 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76a7:	48 89 c7             	mov    %rax,%rdi
    76aa:	e8 61 cf ff ff       	call   4610 <fwp_rc_fresh>
    76af:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
    76b6:	00 
    76b7:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    76be:	00 
    76bf:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    76c6:	00 
    76c7:	e8 64 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76cc:	48 89 c7             	mov    %rax,%rdi
    76cf:	e8 3c cf ff ff       	call   4610 <fwp_rc_fresh>
    76d4:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
    76db:	00 
    76dc:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    76e3:	00 
    76e4:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    76eb:	00 
    76ec:	e8 3f d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76f1:	48 89 c7             	mov    %rax,%rdi
    76f4:	e8 17 cf ff ff       	call   4610 <fwp_rc_fresh>
    76f9:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
    7700:	00 
    7701:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7708:	00 
    7709:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7710:	00 
    7711:	e8 1a d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7716:	48 89 c7             	mov    %rax,%rdi
    7719:	e8 f2 ce ff ff       	call   4610 <fwp_rc_fresh>
    771e:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
    7725:	00 
    7726:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    772d:	00 
    772e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7735:	00 
    7736:	e8 f5 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    773b:	48 89 c7             	mov    %rax,%rdi
    773e:	e8 cd ce ff ff       	call   4610 <fwp_rc_fresh>
    7743:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
    774a:	00 
    774b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    7752:	00 
    7753:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    775a:	00 
    775b:	e8 d0 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7760:	48 89 c7             	mov    %rax,%rdi
    7763:	e8 a8 ce ff ff       	call   4610 <fwp_rc_fresh>
    7768:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
    776f:	00 
    7770:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    7777:	00 
    7778:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    777f:	00 
    7780:	e8 ab d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7785:	48 89 c7             	mov    %rax,%rdi
    7788:	e8 83 ce ff ff       	call   4610 <fwp_rc_fresh>
    778d:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
    7794:	00 
    7795:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    779c:	00 
    779d:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    77a4:	00 
    77a5:	e8 86 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77aa:	48 89 c7             	mov    %rax,%rdi
    77ad:	e8 5e ce ff ff       	call   4610 <fwp_rc_fresh>
    77b2:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
    77b9:	00 
    77ba:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    77c1:	00 
    77c2:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    77c9:	00 
    77ca:	e8 61 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77cf:	48 89 c7             	mov    %rax,%rdi
    77d2:	e8 39 ce ff ff       	call   4610 <fwp_rc_fresh>
    77d7:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
    77de:	00 
    77df:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    77e6:	00 
    77e7:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    77ee:	00 
    77ef:	e8 3c d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77f4:	48 89 c7             	mov    %rax,%rdi
    77f7:	e8 14 ce ff ff       	call   4610 <fwp_rc_fresh>
    77fc:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
    7803:	00 
    7804:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    780b:	00 
    780c:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7813:	00 
    7814:	e8 17 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7819:	48 89 c7             	mov    %rax,%rdi
    781c:	e8 ef cd ff ff       	call   4610 <fwp_rc_fresh>
    7821:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
    7828:	00 
    7829:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7830:	00 
    7831:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7838:	00 
    7839:	e8 f2 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    783e:	48 89 c7             	mov    %rax,%rdi
    7841:	e8 ca cd ff ff       	call   4610 <fwp_rc_fresh>
    7846:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
    784d:	00 
    784e:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    7855:	00 
    7856:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    785d:	00 
    785e:	e8 cd d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7863:	48 89 c7             	mov    %rax,%rdi
    7866:	e8 a5 cd ff ff       	call   4610 <fwp_rc_fresh>
    786b:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
    7872:	00 
    7873:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    787a:	00 
    787b:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    7882:	00 
    7883:	e8 a8 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7888:	48 89 c7             	mov    %rax,%rdi
    788b:	e8 80 cd ff ff       	call   4610 <fwp_rc_fresh>
    7890:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
    7897:	00 
    7898:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    789f:	00 
    78a0:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    78a7:	00 
    78a8:	e8 83 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    78ad:	48 89 c7             	mov    %rax,%rdi
    78b0:	e8 5b cd ff ff       	call   4610 <fwp_rc_fresh>
    78b5:	48 8d bc 24 d0 01 00 	lea    0x1d0(%rsp),%rdi
    78bc:	00 
    78bd:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    78c4:	00 
    78c5:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    78cc:	00 
    78cd:	e8 5e d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    78d2:	48 89 c7             	mov    %rax,%rdi
    78d5:	e8 36 cd ff ff       	call   4610 <fwp_rc_fresh>
    78da:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
    78e1:	00 
    78e2:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    78e9:	00 
    78ea:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    78f1:	00 
    78f2:	e8 39 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    78f7:	48 89 c7             	mov    %rax,%rdi
    78fa:	e8 11 cd ff ff       	call   4610 <fwp_rc_fresh>
    78ff:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
    7906:	00 
    7907:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    790e:	00 
    790f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    7916:	00 
    7917:	e8 14 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    791c:	48 89 c7             	mov    %rax,%rdi
    791f:	e8 ec cc ff ff       	call   4610 <fwp_rc_fresh>
    7924:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
    792b:	00 
    792c:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    7933:	00 
    7934:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    793b:	00 
    793c:	e8 ef cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7941:	48 89 c7             	mov    %rax,%rdi
    7944:	e8 c7 cc ff ff       	call   4610 <fwp_rc_fresh>
    7949:	48 8d bc 24 10 02 00 	lea    0x210(%rsp),%rdi
    7950:	00 
    7951:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    7958:	00 
    7959:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    7960:	00 
    7961:	e8 ca cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7966:	48 89 c7             	mov    %rax,%rdi
    7969:	e8 a2 cc ff ff       	call   4610 <fwp_rc_fresh>
    796e:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
    7975:	00 
    7976:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    797d:	00 
    797e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    7985:	00 
    7986:	e8 a5 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    798b:	48 89 c7             	mov    %rax,%rdi
    798e:	e8 7d cc ff ff       	call   4610 <fwp_rc_fresh>
    7993:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
    799a:	00 
    799b:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    79a2:	00 
    79a3:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    79aa:	00 
    79ab:	e8 80 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    79b0:	48 89 c7             	mov    %rax,%rdi
    79b3:	e8 58 cc ff ff       	call   4610 <fwp_rc_fresh>
    79b8:	48 8d bc 24 40 02 00 	lea    0x240(%rsp),%rdi
    79bf:	00 
    79c0:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    79c7:	00 
    79c8:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    79cf:	00 
    79d0:	e8 5b cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    79d5:	48 89 c7             	mov    %rax,%rdi
    79d8:	e8 33 cc ff ff       	call   4610 <fwp_rc_fresh>
    79dd:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
    79e4:	00 
    79e5:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    79ec:	00 
    79ed:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    79f4:	00 
    79f5:	e8 36 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    79fa:	48 89 c7             	mov    %rax,%rdi
    79fd:	e8 0e cc ff ff       	call   4610 <fwp_rc_fresh>
    7a02:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
    7a09:	00 
    7a0a:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    7a11:	00 
    7a12:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    7a19:	00 
    7a1a:	e8 11 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a1f:	48 89 c7             	mov    %rax,%rdi
    7a22:	e8 e9 cb ff ff       	call   4610 <fwp_rc_fresh>
    7a27:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
    7a2e:	00 
    7a2f:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    7a36:	00 
    7a37:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    7a3e:	00 
    7a3f:	e8 ec ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a44:	48 89 c7             	mov    %rax,%rdi
    7a47:	e8 c4 cb ff ff       	call   4610 <fwp_rc_fresh>
    7a4c:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
    7a53:	00 
    7a54:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    7a5b:	00 
    7a5c:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    7a63:	00 
    7a64:	e8 c7 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a69:	48 89 c7             	mov    %rax,%rdi
    7a6c:	e8 9f cb ff ff       	call   4610 <fwp_rc_fresh>
    7a71:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
    7a78:	00 
    7a79:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    7a80:	00 
    7a81:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    7a88:	00 
    7a89:	e8 a2 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a8e:	48 89 c7             	mov    %rax,%rdi
    7a91:	e8 7a cb ff ff       	call   4610 <fwp_rc_fresh>
    7a96:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
    7a9d:	00 
    7a9e:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    7aa5:	00 
    7aa6:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    7aad:	00 
    7aae:	e8 7d ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ab3:	48 89 c7             	mov    %rax,%rdi
    7ab6:	e8 55 cb ff ff       	call   4610 <fwp_rc_fresh>
    7abb:	48 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%rdi
    7ac2:	00 
    7ac3:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    7aca:	00 
    7acb:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    7ad2:	00 
    7ad3:	e8 58 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ad8:	48 89 c7             	mov    %rax,%rdi
    7adb:	e8 30 cb ff ff       	call   4610 <fwp_rc_fresh>
    7ae0:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
    7ae7:	00 
    7ae8:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    7aef:	00 
    7af0:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    7af7:	00 
    7af8:	e8 33 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7afd:	48 89 c7             	mov    %rax,%rdi
    7b00:	e8 0b cb ff ff       	call   4610 <fwp_rc_fresh>
    7b05:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
    7b0c:	00 
    7b0d:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    7b14:	00 
    7b15:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    7b1c:	00 
    7b1d:	e8 0e ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b22:	48 89 c7             	mov    %rax,%rdi
    7b25:	e8 e6 ca ff ff       	call   4610 <fwp_rc_fresh>
    7b2a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
    7b31:	00 
    7b32:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    7b39:	00 
    7b3a:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    7b41:	00 
    7b42:	e8 e9 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b47:	48 89 c7             	mov    %rax,%rdi
    7b4a:	e8 c1 ca ff ff       	call   4610 <fwp_rc_fresh>
    7b4f:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
    7b56:	00 
    7b57:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    7b5e:	00 
    7b5f:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    7b66:	00 
    7b67:	e8 c4 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b6c:	48 89 c7             	mov    %rax,%rdi
    7b6f:	e8 9c ca ff ff       	call   4610 <fwp_rc_fresh>
    7b74:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
    7b7b:	00 
    7b7c:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    7b83:	00 
    7b84:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    7b8b:	00 
    7b8c:	e8 9f cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b91:	48 89 c7             	mov    %rax,%rdi
    7b94:	e8 77 ca ff ff       	call   4610 <fwp_rc_fresh>
    7b99:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
    7ba0:	00 
    7ba1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    7ba8:	00 
    7ba9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    7bb0:	00 
    7bb1:	e8 7a cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7bb6:	48 89 c7             	mov    %rax,%rdi
    7bb9:	e8 52 ca ff ff       	call   4610 <fwp_rc_fresh>
    7bbe:	48 8d bc 24 20 03 00 	lea    0x320(%rsp),%rdi
    7bc5:	00 
    7bc6:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    7bcd:	00 
    7bce:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    7bd5:	00 
    7bd6:	e8 55 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7bdb:	48 89 c7             	mov    %rax,%rdi
    7bde:	e8 2d ca ff ff       	call   4610 <fwp_rc_fresh>
    7be3:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
    7bea:	00 
    7beb:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    7bf2:	00 
    7bf3:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    7bfa:	00 
    7bfb:	e8 30 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c00:	48 89 c7             	mov    %rax,%rdi
    7c03:	e8 08 ca ff ff       	call   4610 <fwp_rc_fresh>
    7c08:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
    7c0f:	00 
    7c10:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    7c17:	00 
    7c18:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    7c1f:	00 
    7c20:	e8 0b cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c25:	48 89 c7             	mov    %rax,%rdi
    7c28:	e8 e3 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c2d:	48 8d bc 24 50 03 00 	lea    0x350(%rsp),%rdi
    7c34:	00 
    7c35:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    7c3c:	00 
    7c3d:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    7c44:	00 
    7c45:	e8 e6 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c4a:	48 89 c7             	mov    %rax,%rdi
    7c4d:	e8 be c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c52:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
    7c59:	00 
    7c5a:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    7c61:	00 
    7c62:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    7c69:	00 
    7c6a:	e8 c1 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c6f:	48 89 c7             	mov    %rax,%rdi
    7c72:	e8 99 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c77:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
    7c7e:	00 
    7c7f:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    7c86:	00 
    7c87:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    7c8e:	00 
    7c8f:	e8 9c cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c94:	48 89 c7             	mov    %rax,%rdi
    7c97:	e8 74 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c9c:	48 8d bc 24 80 03 00 	lea    0x380(%rsp),%rdi
    7ca3:	00 
    7ca4:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    7cab:	00 
    7cac:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    7cb3:	00 
    7cb4:	e8 77 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7cb9:	48 89 c7             	mov    %rax,%rdi
    7cbc:	e8 4f c9 ff ff       	call   4610 <fwp_rc_fresh>
    7cc1:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
    7cc8:	00 
    7cc9:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    7cd0:	00 
    7cd1:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    7cd8:	00 
    7cd9:	e8 52 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7cde:	48 89 c7             	mov    %rax,%rdi
    7ce1:	e8 2a c9 ff ff       	call   4610 <fwp_rc_fresh>
    7ce6:	48 8d bc 24 a0 03 00 	lea    0x3a0(%rsp),%rdi
    7ced:	00 
    7cee:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    7cf5:	00 
    7cf6:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    7cfd:	00 
    7cfe:	e8 2d cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d03:	48 89 c7             	mov    %rax,%rdi
    7d06:	e8 05 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7d0b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
    7d12:	00 
    7d13:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    7d1a:	00 
    7d1b:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    7d22:	00 
    7d23:	e8 08 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d28:	48 89 c7             	mov    %rax,%rdi
    7d2b:	e8 e0 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d30:	48 8d bc 24 c0 03 00 	lea    0x3c0(%rsp),%rdi
    7d37:	00 
    7d38:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    7d3f:	00 
    7d40:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    7d47:	00 
    7d48:	e8 e3 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d4d:	48 89 c7             	mov    %rax,%rdi
    7d50:	e8 bb c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d55:	48 8d bc 24 d0 03 00 	lea    0x3d0(%rsp),%rdi
    7d5c:	00 
    7d5d:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    7d64:	00 
    7d65:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    7d6c:	00 
    7d6d:	e8 be cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d72:	48 89 c7             	mov    %rax,%rdi
    7d75:	e8 96 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d7a:	48 8d bc 24 e0 03 00 	lea    0x3e0(%rsp),%rdi
    7d81:	00 
    7d82:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    7d89:	00 
    7d8a:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    7d91:	00 
    7d92:	e8 99 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d97:	48 89 c7             	mov    %rax,%rdi
    7d9a:	e8 71 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d9f:	48 8d bc 24 f0 03 00 	lea    0x3f0(%rsp),%rdi
    7da6:	00 
    7da7:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    7dae:	00 
    7daf:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    7db6:	00 
    7db7:	e8 74 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7dbc:	48 89 c7             	mov    %rax,%rdi
    7dbf:	e8 4c c8 ff ff       	call   4610 <fwp_rc_fresh>
    7dc4:	48 8d bc 24 00 04 00 	lea    0x400(%rsp),%rdi
    7dcb:	00 
    7dcc:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    7dd3:	00 
    7dd4:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    7ddb:	00 
    7ddc:	e8 4f cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7de1:	48 89 c7             	mov    %rax,%rdi
    7de4:	e8 27 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7de9:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
    7df0:	00 
    7df1:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    7df8:	00 
    7df9:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    7e00:	00 
    7e01:	e8 2a cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e06:	48 89 c7             	mov    %rax,%rdi
    7e09:	e8 02 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7e0e:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
    7e15:	00 
    7e16:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    7e1d:	00 
    7e1e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    7e25:	00 
    7e26:	e8 05 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e2b:	48 89 c7             	mov    %rax,%rdi
    7e2e:	e8 dd c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e33:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
    7e3a:	00 
    7e3b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    7e42:	00 
    7e43:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    7e4a:	00 
    7e4b:	e8 e0 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e50:	48 89 c7             	mov    %rax,%rdi
    7e53:	e8 b8 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e58:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
    7e5f:	00 
    7e60:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    7e67:	00 
    7e68:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    7e6f:	00 
    7e70:	e8 bb ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e75:	48 89 c7             	mov    %rax,%rdi
    7e78:	e8 93 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e7d:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
    7e84:	00 
    7e85:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    7e8c:	00 
    7e8d:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    7e94:	00 
    7e95:	e8 96 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e9a:	48 89 c7             	mov    %rax,%rdi
    7e9d:	e8 6e c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ea2:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
    7ea9:	00 
    7eaa:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    7eb1:	00 
    7eb2:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    7eb9:	00 
    7eba:	e8 71 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ebf:	48 89 c7             	mov    %rax,%rdi
    7ec2:	e8 49 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ec7:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
    7ece:	00 
    7ecf:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    7ed6:	00 
    7ed7:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    7ede:	00 
    7edf:	e8 4c ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ee4:	48 89 c7             	mov    %rax,%rdi
    7ee7:	e8 24 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7eec:	48 8d bc 24 80 04 00 	lea    0x480(%rsp),%rdi
    7ef3:	00 
    7ef4:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    7efb:	00 
    7efc:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    7f03:	00 
    7f04:	e8 27 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f09:	48 89 c7             	mov    %rax,%rdi
    7f0c:	e8 ff c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f11:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
    7f18:	00 
    7f19:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    7f20:	00 
    7f21:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    7f28:	00 
    7f29:	e8 02 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f2e:	48 89 c7             	mov    %rax,%rdi
    7f31:	e8 da c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f36:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
    7f3d:	00 
    7f3e:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    7f45:	00 
    7f46:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    7f4d:	00 
    7f4e:	e8 dd c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f53:	48 89 c7             	mov    %rax,%rdi
    7f56:	e8 b5 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f5b:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
    7f62:	00 
    7f63:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    7f6a:	00 
    7f6b:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    7f72:	00 
    7f73:	e8 b8 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f78:	48 89 c7             	mov    %rax,%rdi
    7f7b:	e8 90 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f80:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
    7f87:	00 
    7f88:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    7f8f:	00 
    7f90:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    7f97:	00 
    7f98:	e8 93 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f9d:	48 89 c7             	mov    %rax,%rdi
    7fa0:	e8 6b c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fa5:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
    7fac:	00 
    7fad:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    7fb4:	00 
    7fb5:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    7fbc:	00 
    7fbd:	e8 6e c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fc2:	48 89 c7             	mov    %rax,%rdi
    7fc5:	e8 46 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fca:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
    7fd1:	00 
    7fd2:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    7fd9:	00 
    7fda:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    7fe1:	00 
    7fe2:	e8 49 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fe7:	48 89 c7             	mov    %rax,%rdi
    7fea:	e8 21 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fef:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
    7ff6:	00 
    7ff7:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    7ffe:	00 
    7fff:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    8006:	00 
    8007:	e8 24 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    800c:	48 89 c7             	mov    %rax,%rdi
    800f:	e8 fc c5 ff ff       	call   4610 <fwp_rc_fresh>
    8014:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
    801b:	00 
    801c:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    8023:	00 
    8024:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    802b:	00 
    802c:	e8 ff c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8031:	48 89 c7             	mov    %rax,%rdi
    8034:	e8 d7 c5 ff ff       	call   4610 <fwp_rc_fresh>
    8039:	48 8d bc 24 10 05 00 	lea    0x510(%rsp),%rdi
    8040:	00 
    8041:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    8048:	00 
    8049:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    8050:	00 
    8051:	e8 da c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8056:	48 89 c7             	mov    %rax,%rdi
    8059:	e8 b2 c5 ff ff       	call   4610 <fwp_rc_fresh>
    805e:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
    8065:	00 
    8066:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    806d:	00 
    806e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    8075:	00 
    8076:	e8 b5 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    807b:	48 89 c7             	mov    %rax,%rdi
    807e:	e8 8d c5 ff ff       	call   4610 <fwp_rc_fresh>
    8083:	48 8d bc 24 30 05 00 	lea    0x530(%rsp),%rdi
    808a:	00 
    808b:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    8092:	00 
    8093:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    809a:	00 
    809b:	e8 90 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80a0:	48 89 c7             	mov    %rax,%rdi
    80a3:	e8 68 c5 ff ff       	call   4610 <fwp_rc_fresh>
    80a8:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
    80af:	00 
    80b0:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    80b7:	00 
    80b8:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    80bf:	00 
    80c0:	e8 6b c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80c5:	48 89 c7             	mov    %rax,%rdi
    80c8:	e8 43 c5 ff ff       	call   4610 <fwp_rc_fresh>
    80cd:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
    80d4:	00 
    80d5:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    80dc:	00 
    80dd:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    80e4:	00 
    80e5:	e8 46 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80ea:	48 89 c7             	mov    %rax,%rdi
    80ed:	e8 1e c5 ff ff       	call   4610 <fwp_rc_fresh>
    80f2:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
    80f9:	00 
    80fa:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    8101:	00 
    8102:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    8109:	00 
    810a:	e8 21 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    810f:	48 89 c7             	mov    %rax,%rdi
    8112:	e8 f9 c4 ff ff       	call   4610 <fwp_rc_fresh>
    8117:	48 8d bc 24 70 05 00 	lea    0x570(%rsp),%rdi
    811e:	00 
    811f:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    8126:	00 
    8127:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    812e:	00 
    812f:	e8 fc c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8134:	48 89 c7             	mov    %rax,%rdi
    8137:	e8 d4 c4 ff ff       	call   4610 <fwp_rc_fresh>
    813c:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
    8143:	00 
    8144:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    814b:	00 
    814c:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    8153:	00 
    8154:	e8 d7 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8159:	48 89 c7             	mov    %rax,%rdi
    815c:	e8 af c4 ff ff       	call   4610 <fwp_rc_fresh>
    8161:	48 8d bc 24 90 05 00 	lea    0x590(%rsp),%rdi
    8168:	00 
    8169:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    8170:	00 
    8171:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    8178:	00 
    8179:	e8 b2 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    817e:	48 89 c7             	mov    %rax,%rdi
    8181:	e8 8a c4 ff ff       	call   4610 <fwp_rc_fresh>
    8186:	48 8d bc 24 a0 05 00 	lea    0x5a0(%rsp),%rdi
    818d:	00 
    818e:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    8195:	00 
    8196:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    819d:	00 
    819e:	e8 8d c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81a3:	48 89 c7             	mov    %rax,%rdi
    81a6:	e8 65 c4 ff ff       	call   4610 <fwp_rc_fresh>
    81ab:	48 8d bc 24 b0 05 00 	lea    0x5b0(%rsp),%rdi
    81b2:	00 
    81b3:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    81ba:	00 
    81bb:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    81c2:	00 
    81c3:	e8 68 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81c8:	48 89 c7             	mov    %rax,%rdi
    81cb:	e8 40 c4 ff ff       	call   4610 <fwp_rc_fresh>
    81d0:	48 8d bc 24 c0 05 00 	lea    0x5c0(%rsp),%rdi
    81d7:	00 
    81d8:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    81df:	00 
    81e0:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    81e7:	00 
    81e8:	e8 43 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81ed:	48 89 c7             	mov    %rax,%rdi
    81f0:	e8 1b c4 ff ff       	call   4610 <fwp_rc_fresh>
    81f5:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
    81fc:	00 
    81fd:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    8204:	00 
    8205:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    820c:	00 
    820d:	e8 1e c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8212:	48 89 c7             	mov    %rax,%rdi
    8215:	e8 f6 c3 ff ff       	call   4610 <fwp_rc_fresh>
    821a:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
    8221:	00 
    8222:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    8229:	00 
    822a:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    8231:	00 
    8232:	e8 f9 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8237:	48 89 c7             	mov    %rax,%rdi
    823a:	e8 d1 c3 ff ff       	call   4610 <fwp_rc_fresh>
    823f:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
    8246:	00 
    8247:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    824e:	00 
    824f:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    8256:	00 
    8257:	e8 d4 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    825c:	48 89 c7             	mov    %rax,%rdi
    825f:	e8 ac c3 ff ff       	call   4610 <fwp_rc_fresh>
    8264:	48 8d bc 24 00 06 00 	lea    0x600(%rsp),%rdi
    826b:	00 
    826c:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    8273:	00 
    8274:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    827b:	00 
    827c:	e8 af c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8281:	48 89 c7             	mov    %rax,%rdi
    8284:	e8 87 c3 ff ff       	call   4610 <fwp_rc_fresh>
    8289:	48 8d bc 24 10 06 00 	lea    0x610(%rsp),%rdi
    8290:	00 
    8291:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    8298:	00 
    8299:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    82a0:	00 
    82a1:	e8 8a c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82a6:	48 89 c7             	mov    %rax,%rdi
    82a9:	e8 62 c3 ff ff       	call   4610 <fwp_rc_fresh>
    82ae:	48 8d bc 24 20 06 00 	lea    0x620(%rsp),%rdi
    82b5:	00 
    82b6:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    82bd:	00 
    82be:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    82c5:	00 
    82c6:	e8 65 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82cb:	48 8b 15 46 78 01 00 	mov    0x17846(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    82d2:	49 89 c5             	mov    %rax,%r13
    82d5:	48 2b 05 14 78 01 00 	sub    0x17814(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    82dc:	48 c1 e2 10          	shl    $0x10,%rdx
    82e0:	48 39 d0             	cmp    %rdx,%rax
    82e3:	73 59                	jae    833e <f0+0x112e>
    82e5:	48 89 c2             	mov    %rax,%rdx
    82e8:	48 c1 ea 10          	shr    $0x10,%rdx
    82ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82f0:	48 8b 15 41 78 01 00 	mov    0x17841(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    82f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82fb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    82ff:	4d 85 e4             	test   %r12,%r12
    8302:	74 3a                	je     833e <f0+0x112e>
    8304:	0f b6 0a             	movzbl (%rdx),%ecx
    8307:	80 f9 02             	cmp    $0x2,%cl
    830a:	0f 84 d0 15 00 00    	je     98e0 <f0+0x26d0>
    8310:	80 f9 01             	cmp    $0x1,%cl
    8313:	75 29                	jne    833e <f0+0x112e>
    8315:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8318:	0f b7 c0             	movzwl %ax,%eax
    831b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    831e:	48 0f af c1          	imul   %rcx,%rax
    8322:	48 c1 e8 20          	shr    $0x20,%rax
    8326:	48 39 d0             	cmp    %rdx,%rax
    8329:	73 13                	jae    833e <f0+0x112e>
    832b:	49 01 c4             	add    %rax,%r12
    832e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8333:	0f 84 86 17 00 00    	je     9abf <f0+0x28af>
    8339:	41 c6 04 24 01       	movb   $0x1,(%r12)
    833e:	48 8d bc 24 30 06 00 	lea    0x630(%rsp),%rdi
    8345:	00 
    8346:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    834d:	00 
    834e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8355:	00 f0 3f 
    8358:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    835f:	00 
    8360:	e8 cb c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8365:	48 8b 15 ac 77 01 00 	mov    0x177ac(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    836c:	49 89 c5             	mov    %rax,%r13
    836f:	48 2b 05 7a 77 01 00 	sub    0x1777a(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8376:	48 c1 e2 10          	shl    $0x10,%rdx
    837a:	48 39 d0             	cmp    %rdx,%rax
    837d:	73 59                	jae    83d8 <f0+0x11c8>
    837f:	48 89 c2             	mov    %rax,%rdx
    8382:	48 c1 ea 10          	shr    $0x10,%rdx
    8386:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    838a:	48 8b 15 a7 77 01 00 	mov    0x177a7(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8391:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8395:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8399:	4d 85 e4             	test   %r12,%r12
    839c:	74 3a                	je     83d8 <f0+0x11c8>
    839e:	0f b6 0a             	movzbl (%rdx),%ecx
    83a1:	80 f9 02             	cmp    $0x2,%cl
    83a4:	0f 84 26 15 00 00    	je     98d0 <f0+0x26c0>
    83aa:	80 f9 01             	cmp    $0x1,%cl
    83ad:	75 29                	jne    83d8 <f0+0x11c8>
    83af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83b2:	0f b7 c0             	movzwl %ax,%eax
    83b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83b8:	48 0f af c1          	imul   %rcx,%rax
    83bc:	48 c1 e8 20          	shr    $0x20,%rax
    83c0:	48 39 d0             	cmp    %rdx,%rax
    83c3:	73 13                	jae    83d8 <f0+0x11c8>
    83c5:	49 01 c4             	add    %rax,%r12
    83c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    83cd:	0f 84 f9 16 00 00    	je     9acc <f0+0x28bc>
    83d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    83d8:	48 8d bc 24 40 06 00 	lea    0x640(%rsp),%rdi
    83df:	00 
    83e0:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    83e7:	00 
    83e8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    83ef:	33 f3 bf 
    83f2:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    83f9:	00 
    83fa:	e8 31 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    83ff:	48 8b 15 12 77 01 00 	mov    0x17712(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8406:	49 89 c5             	mov    %rax,%r13
    8409:	48 2b 05 e0 76 01 00 	sub    0x176e0(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8410:	48 c1 e2 10          	shl    $0x10,%rdx
    8414:	48 39 d0             	cmp    %rdx,%rax
    8417:	73 59                	jae    8472 <f0+0x1262>
    8419:	48 89 c2             	mov    %rax,%rdx
    841c:	48 c1 ea 10          	shr    $0x10,%rdx
    8420:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8424:	48 8b 15 0d 77 01 00 	mov    0x1770d(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    842b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    842f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8433:	4d 85 e4             	test   %r12,%r12
    8436:	74 3a                	je     8472 <f0+0x1262>
    8438:	0f b6 0a             	movzbl (%rdx),%ecx
    843b:	80 f9 02             	cmp    $0x2,%cl
    843e:	0f 84 7c 14 00 00    	je     98c0 <f0+0x26b0>
    8444:	80 f9 01             	cmp    $0x1,%cl
    8447:	75 29                	jne    8472 <f0+0x1262>
    8449:	8b 4a 18             	mov    0x18(%rdx),%ecx
    844c:	0f b7 c0             	movzwl %ax,%eax
    844f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8452:	48 0f af c1          	imul   %rcx,%rax
    8456:	48 c1 e8 20          	shr    $0x20,%rax
    845a:	48 39 d0             	cmp    %rdx,%rax
    845d:	73 13                	jae    8472 <f0+0x1262>
    845f:	49 01 c4             	add    %rax,%r12
    8462:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8467:	0f 84 6c 16 00 00    	je     9ad9 <f0+0x28c9>
    846d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8472:	48 8d bc 24 50 06 00 	lea    0x650(%rsp),%rdi
    8479:	00 
    847a:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    8481:	00 
    8482:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8489:	00 f0 3f 
    848c:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    8493:	00 
    8494:	e8 97 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8499:	48 8b 15 78 76 01 00 	mov    0x17678(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    84a0:	49 89 c5             	mov    %rax,%r13
    84a3:	48 2b 05 46 76 01 00 	sub    0x17646(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    84aa:	48 c1 e2 10          	shl    $0x10,%rdx
    84ae:	48 39 d0             	cmp    %rdx,%rax
    84b1:	73 59                	jae    850c <f0+0x12fc>
    84b3:	48 89 c2             	mov    %rax,%rdx
    84b6:	48 c1 ea 10          	shr    $0x10,%rdx
    84ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84be:	48 8b 15 73 76 01 00 	mov    0x17673(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    84c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    84cd:	4d 85 e4             	test   %r12,%r12
    84d0:	74 3a                	je     850c <f0+0x12fc>
    84d2:	0f b6 0a             	movzbl (%rdx),%ecx
    84d5:	80 f9 02             	cmp    $0x2,%cl
    84d8:	0f 84 92 14 00 00    	je     9970 <f0+0x2760>
    84de:	80 f9 01             	cmp    $0x1,%cl
    84e1:	75 29                	jne    850c <f0+0x12fc>
    84e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84e6:	0f b7 c0             	movzwl %ax,%eax
    84e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84ec:	48 0f af c1          	imul   %rcx,%rax
    84f0:	48 c1 e8 20          	shr    $0x20,%rax
    84f4:	48 39 d0             	cmp    %rdx,%rax
    84f7:	73 13                	jae    850c <f0+0x12fc>
    84f9:	49 01 c4             	add    %rax,%r12
    84fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8501:	0f 84 df 15 00 00    	je     9ae6 <f0+0x28d6>
    8507:	41 c6 04 24 01       	movb   $0x1,(%r12)
    850c:	48 8d bc 24 60 06 00 	lea    0x660(%rsp),%rdi
    8513:	00 
    8514:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    851b:	00 
    851c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8523:	33 f3 bf 
    8526:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    852d:	00 
    852e:	e8 fd c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8533:	48 8b 15 de 75 01 00 	mov    0x175de(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    853a:	49 89 c5             	mov    %rax,%r13
    853d:	48 2b 05 ac 75 01 00 	sub    0x175ac(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8544:	48 c1 e2 10          	shl    $0x10,%rdx
    8548:	48 39 d0             	cmp    %rdx,%rax
    854b:	73 59                	jae    85a6 <f0+0x1396>
    854d:	48 89 c2             	mov    %rax,%rdx
    8550:	48 c1 ea 10          	shr    $0x10,%rdx
    8554:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8558:	48 8b 15 d9 75 01 00 	mov    0x175d9(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    855f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8563:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8567:	4d 85 e4             	test   %r12,%r12
    856a:	74 3a                	je     85a6 <f0+0x1396>
    856c:	0f b6 0a             	movzbl (%rdx),%ecx
    856f:	80 f9 02             	cmp    $0x2,%cl
    8572:	0f 84 e8 13 00 00    	je     9960 <f0+0x2750>
    8578:	80 f9 01             	cmp    $0x1,%cl
    857b:	75 29                	jne    85a6 <f0+0x1396>
    857d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8580:	0f b7 c0             	movzwl %ax,%eax
    8583:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8586:	48 0f af c1          	imul   %rcx,%rax
    858a:	48 c1 e8 20          	shr    $0x20,%rax
    858e:	48 39 d0             	cmp    %rdx,%rax
    8591:	73 13                	jae    85a6 <f0+0x1396>
    8593:	49 01 c4             	add    %rax,%r12
    8596:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    859b:	0f 84 52 15 00 00    	je     9af3 <f0+0x28e3>
    85a1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    85a6:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
    85ad:	00 
    85ae:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    85b5:	00 
    85b6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    85bd:	00 f0 3f 
    85c0:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    85c7:	00 
    85c8:	e8 63 c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    85cd:	48 8b 15 44 75 01 00 	mov    0x17544(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    85d4:	49 89 c5             	mov    %rax,%r13
    85d7:	48 2b 05 12 75 01 00 	sub    0x17512(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    85de:	48 c1 e2 10          	shl    $0x10,%rdx
    85e2:	48 39 d0             	cmp    %rdx,%rax
    85e5:	73 59                	jae    8640 <f0+0x1430>
    85e7:	48 89 c2             	mov    %rax,%rdx
    85ea:	48 c1 ea 10          	shr    $0x10,%rdx
    85ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85f2:	48 8b 15 3f 75 01 00 	mov    0x1753f(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    85f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8601:	4d 85 e4             	test   %r12,%r12
    8604:	74 3a                	je     8640 <f0+0x1430>
    8606:	0f b6 0a             	movzbl (%rdx),%ecx
    8609:	80 f9 02             	cmp    $0x2,%cl
    860c:	0f 84 3e 13 00 00    	je     9950 <f0+0x2740>
    8612:	80 f9 01             	cmp    $0x1,%cl
    8615:	75 29                	jne    8640 <f0+0x1430>
    8617:	8b 4a 18             	mov    0x18(%rdx),%ecx
    861a:	0f b7 c0             	movzwl %ax,%eax
    861d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8620:	48 0f af c1          	imul   %rcx,%rax
    8624:	48 c1 e8 20          	shr    $0x20,%rax
    8628:	48 39 d0             	cmp    %rdx,%rax
    862b:	73 13                	jae    8640 <f0+0x1430>
    862d:	49 01 c4             	add    %rax,%r12
    8630:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8635:	0f 84 c5 14 00 00    	je     9b00 <f0+0x28f0>
    863b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8640:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
    8647:	00 
    8648:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    864f:	00 
    8650:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8657:	33 f3 bf 
    865a:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    8661:	00 
    8662:	e8 c9 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8667:	48 8b 15 aa 74 01 00 	mov    0x174aa(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    866e:	49 89 c5             	mov    %rax,%r13
    8671:	48 2b 05 78 74 01 00 	sub    0x17478(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8678:	48 c1 e2 10          	shl    $0x10,%rdx
    867c:	48 39 d0             	cmp    %rdx,%rax
    867f:	73 59                	jae    86da <f0+0x14ca>
    8681:	48 89 c2             	mov    %rax,%rdx
    8684:	48 c1 ea 10          	shr    $0x10,%rdx
    8688:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    868c:	48 8b 15 a5 74 01 00 	mov    0x174a5(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8693:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8697:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    869b:	4d 85 e4             	test   %r12,%r12
    869e:	74 3a                	je     86da <f0+0x14ca>
    86a0:	0f b6 0a             	movzbl (%rdx),%ecx
    86a3:	80 f9 02             	cmp    $0x2,%cl
    86a6:	0f 84 94 12 00 00    	je     9940 <f0+0x2730>
    86ac:	80 f9 01             	cmp    $0x1,%cl
    86af:	75 29                	jne    86da <f0+0x14ca>
    86b1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86b4:	0f b7 c0             	movzwl %ax,%eax
    86b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86ba:	48 0f af c1          	imul   %rcx,%rax
    86be:	48 c1 e8 20          	shr    $0x20,%rax
    86c2:	48 39 d0             	cmp    %rdx,%rax
    86c5:	73 13                	jae    86da <f0+0x14ca>
    86c7:	49 01 c4             	add    %rax,%r12
    86ca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    86cf:	0f 84 38 14 00 00    	je     9b0d <f0+0x28fd>
    86d5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    86da:	48 8d bc 24 90 06 00 	lea    0x690(%rsp),%rdi
    86e1:	00 
    86e2:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    86e9:	00 
    86ea:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    86f1:	00 f0 3f 
    86f4:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    86fb:	00 
    86fc:	e8 2f c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8701:	48 8b 15 10 74 01 00 	mov    0x17410(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8708:	49 89 c5             	mov    %rax,%r13
    870b:	48 2b 05 de 73 01 00 	sub    0x173de(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8712:	48 c1 e2 10          	shl    $0x10,%rdx
    8716:	48 39 d0             	cmp    %rdx,%rax
    8719:	73 59                	jae    8774 <f0+0x1564>
    871b:	48 89 c2             	mov    %rax,%rdx
    871e:	48 c1 ea 10          	shr    $0x10,%rdx
    8722:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8726:	48 8b 15 0b 74 01 00 	mov    0x1740b(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    872d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8731:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8735:	4d 85 e4             	test   %r12,%r12
    8738:	74 3a                	je     8774 <f0+0x1564>
    873a:	0f b6 0a             	movzbl (%rdx),%ecx
    873d:	80 f9 02             	cmp    $0x2,%cl
    8740:	0f 84 ea 11 00 00    	je     9930 <f0+0x2720>
    8746:	80 f9 01             	cmp    $0x1,%cl
    8749:	75 29                	jne    8774 <f0+0x1564>
    874b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    874e:	0f b7 c0             	movzwl %ax,%eax
    8751:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8754:	48 0f af c1          	imul   %rcx,%rax
    8758:	48 c1 e8 20          	shr    $0x20,%rax
    875c:	48 39 d0             	cmp    %rdx,%rax
    875f:	73 13                	jae    8774 <f0+0x1564>
    8761:	49 01 c4             	add    %rax,%r12
    8764:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8769:	0f 84 ab 13 00 00    	je     9b1a <f0+0x290a>
    876f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8774:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
    877b:	00 
    877c:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    8783:	00 
    8784:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    878b:	33 f3 bf 
    878e:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    8795:	00 
    8796:	e8 95 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    879b:	48 8b 15 76 73 01 00 	mov    0x17376(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    87a2:	49 89 c5             	mov    %rax,%r13
    87a5:	48 2b 05 44 73 01 00 	sub    0x17344(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    87ac:	48 c1 e2 10          	shl    $0x10,%rdx
    87b0:	48 39 d0             	cmp    %rdx,%rax
    87b3:	73 59                	jae    880e <f0+0x15fe>
    87b5:	48 89 c2             	mov    %rax,%rdx
    87b8:	48 c1 ea 10          	shr    $0x10,%rdx
    87bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87c0:	48 8b 15 71 73 01 00 	mov    0x17371(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    87c7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87cb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    87cf:	4d 85 e4             	test   %r12,%r12
    87d2:	74 3a                	je     880e <f0+0x15fe>
    87d4:	0f b6 0a             	movzbl (%rdx),%ecx
    87d7:	80 f9 02             	cmp    $0x2,%cl
    87da:	0f 84 40 11 00 00    	je     9920 <f0+0x2710>
    87e0:	80 f9 01             	cmp    $0x1,%cl
    87e3:	75 29                	jne    880e <f0+0x15fe>
    87e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87e8:	0f b7 c0             	movzwl %ax,%eax
    87eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87ee:	48 0f af c1          	imul   %rcx,%rax
    87f2:	48 c1 e8 20          	shr    $0x20,%rax
    87f6:	48 39 d0             	cmp    %rdx,%rax
    87f9:	73 13                	jae    880e <f0+0x15fe>
    87fb:	49 01 c4             	add    %rax,%r12
    87fe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8803:	0f 84 1e 13 00 00    	je     9b27 <f0+0x2917>
    8809:	41 c6 04 24 01       	movb   $0x1,(%r12)
    880e:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
    8815:	00 
    8816:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    881d:	00 
    881e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8825:	00 f0 3f 
    8828:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    882f:	00 
    8830:	e8 fb c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8835:	48 8b 15 dc 72 01 00 	mov    0x172dc(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    883c:	49 89 c5             	mov    %rax,%r13
    883f:	48 2b 05 aa 72 01 00 	sub    0x172aa(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8846:	48 c1 e2 10          	shl    $0x10,%rdx
    884a:	48 39 d0             	cmp    %rdx,%rax
    884d:	73 59                	jae    88a8 <f0+0x1698>
    884f:	48 89 c2             	mov    %rax,%rdx
    8852:	48 c1 ea 10          	shr    $0x10,%rdx
    8856:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    885a:	48 8b 15 d7 72 01 00 	mov    0x172d7(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8861:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8865:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8869:	4d 85 e4             	test   %r12,%r12
    886c:	74 3a                	je     88a8 <f0+0x1698>
    886e:	0f b6 0a             	movzbl (%rdx),%ecx
    8871:	80 f9 02             	cmp    $0x2,%cl
    8874:	0f 84 96 10 00 00    	je     9910 <f0+0x2700>
    887a:	80 f9 01             	cmp    $0x1,%cl
    887d:	75 29                	jne    88a8 <f0+0x1698>
    887f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8882:	0f b7 c0             	movzwl %ax,%eax
    8885:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8888:	48 0f af c1          	imul   %rcx,%rax
    888c:	48 c1 e8 20          	shr    $0x20,%rax
    8890:	48 39 d0             	cmp    %rdx,%rax
    8893:	73 13                	jae    88a8 <f0+0x1698>
    8895:	49 01 c4             	add    %rax,%r12
    8898:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    889d:	0f 84 91 12 00 00    	je     9b34 <f0+0x2924>
    88a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    88a8:	48 8d bc 24 c0 06 00 	lea    0x6c0(%rsp),%rdi
    88af:	00 
    88b0:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    88b7:	00 
    88b8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    88bf:	33 f3 bf 
    88c2:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    88c9:	00 
    88ca:	e8 61 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    88cf:	48 8b 15 42 72 01 00 	mov    0x17242(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    88d6:	49 89 c5             	mov    %rax,%r13
    88d9:	48 2b 05 10 72 01 00 	sub    0x17210(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    88e0:	48 c1 e2 10          	shl    $0x10,%rdx
    88e4:	48 39 d0             	cmp    %rdx,%rax
    88e7:	73 59                	jae    8942 <f0+0x1732>
    88e9:	48 89 c2             	mov    %rax,%rdx
    88ec:	48 c1 ea 10          	shr    $0x10,%rdx
    88f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88f4:	48 8b 15 3d 72 01 00 	mov    0x1723d(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    88fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8903:	4d 85 e4             	test   %r12,%r12
    8906:	74 3a                	je     8942 <f0+0x1732>
    8908:	0f b6 0a             	movzbl (%rdx),%ecx
    890b:	80 f9 02             	cmp    $0x2,%cl
    890e:	0f 84 ec 0f 00 00    	je     9900 <f0+0x26f0>
    8914:	80 f9 01             	cmp    $0x1,%cl
    8917:	75 29                	jne    8942 <f0+0x1732>
    8919:	8b 4a 18             	mov    0x18(%rdx),%ecx
    891c:	0f b7 c0             	movzwl %ax,%eax
    891f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8922:	48 0f af c1          	imul   %rcx,%rax
    8926:	48 c1 e8 20          	shr    $0x20,%rax
    892a:	48 39 d0             	cmp    %rdx,%rax
    892d:	73 13                	jae    8942 <f0+0x1732>
    892f:	49 01 c4             	add    %rax,%r12
    8932:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8937:	0f 84 04 12 00 00    	je     9b41 <f0+0x2931>
    893d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8942:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
    8949:	00 
    894a:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    8951:	00 
    8952:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8959:	00 f0 3f 
    895c:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    8963:	00 
    8964:	e8 c7 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8969:	48 8b 15 a8 71 01 00 	mov    0x171a8(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8970:	49 89 c5             	mov    %rax,%r13
    8973:	48 2b 05 76 71 01 00 	sub    0x17176(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    897a:	48 c1 e2 10          	shl    $0x10,%rdx
    897e:	48 39 d0             	cmp    %rdx,%rax
    8981:	73 59                	jae    89dc <f0+0x17cc>
    8983:	48 89 c2             	mov    %rax,%rdx
    8986:	48 c1 ea 10          	shr    $0x10,%rdx
    898a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    898e:	48 8b 15 a3 71 01 00 	mov    0x171a3(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8995:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8999:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    899d:	4d 85 e4             	test   %r12,%r12
    89a0:	74 3a                	je     89dc <f0+0x17cc>
    89a2:	0f b6 0a             	movzbl (%rdx),%ecx
    89a5:	80 f9 02             	cmp    $0x2,%cl
    89a8:	0f 84 d2 0e 00 00    	je     9880 <f0+0x2670>
    89ae:	80 f9 01             	cmp    $0x1,%cl
    89b1:	75 29                	jne    89dc <f0+0x17cc>
    89b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    89b6:	0f b7 c0             	movzwl %ax,%eax
    89b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89bc:	48 0f af c1          	imul   %rcx,%rax
    89c0:	48 c1 e8 20          	shr    $0x20,%rax
    89c4:	48 39 d0             	cmp    %rdx,%rax
    89c7:	73 13                	jae    89dc <f0+0x17cc>
    89c9:	49 01 c4             	add    %rax,%r12
    89cc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    89d1:	0f 84 77 11 00 00    	je     9b4e <f0+0x293e>
    89d7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    89dc:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
    89e3:	00 
    89e4:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    89eb:	00 
    89ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    89f3:	33 f3 bf 
    89f6:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    89fd:	00 
    89fe:	e8 2d bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a03:	48 8b 15 0e 71 01 00 	mov    0x1710e(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8a0a:	49 89 c5             	mov    %rax,%r13
    8a0d:	48 2b 05 dc 70 01 00 	sub    0x170dc(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8a14:	48 c1 e2 10          	shl    $0x10,%rdx
    8a18:	48 39 d0             	cmp    %rdx,%rax
    8a1b:	73 59                	jae    8a76 <f0+0x1866>
    8a1d:	48 89 c2             	mov    %rax,%rdx
    8a20:	48 c1 ea 10          	shr    $0x10,%rdx
    8a24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a28:	48 8b 15 09 71 01 00 	mov    0x17109(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8a2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a33:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8a37:	4d 85 e4             	test   %r12,%r12
    8a3a:	74 3a                	je     8a76 <f0+0x1866>
    8a3c:	0f b6 0a             	movzbl (%rdx),%ecx
    8a3f:	80 f9 02             	cmp    $0x2,%cl
    8a42:	0f 84 28 0e 00 00    	je     9870 <f0+0x2660>
    8a48:	80 f9 01             	cmp    $0x1,%cl
    8a4b:	75 29                	jne    8a76 <f0+0x1866>
    8a4d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a50:	0f b7 c0             	movzwl %ax,%eax
    8a53:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a56:	48 0f af c1          	imul   %rcx,%rax
    8a5a:	48 c1 e8 20          	shr    $0x20,%rax
    8a5e:	48 39 d0             	cmp    %rdx,%rax
    8a61:	73 13                	jae    8a76 <f0+0x1866>
    8a63:	49 01 c4             	add    %rax,%r12
    8a66:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a6b:	0f 84 ea 10 00 00    	je     9b5b <f0+0x294b>
    8a71:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8a76:	48 8d bc 24 f0 06 00 	lea    0x6f0(%rsp),%rdi
    8a7d:	00 
    8a7e:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    8a85:	00 
    8a86:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8a8d:	00 f0 3f 
    8a90:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    8a97:	00 
    8a98:	e8 93 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a9d:	48 8b 15 74 70 01 00 	mov    0x17074(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8aa4:	49 89 c5             	mov    %rax,%r13
    8aa7:	48 2b 05 42 70 01 00 	sub    0x17042(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8aae:	48 c1 e2 10          	shl    $0x10,%rdx
    8ab2:	48 39 d0             	cmp    %rdx,%rax
    8ab5:	73 59                	jae    8b10 <f0+0x1900>
    8ab7:	48 89 c2             	mov    %rax,%rdx
    8aba:	48 c1 ea 10          	shr    $0x10,%rdx
    8abe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ac2:	48 8b 15 6f 70 01 00 	mov    0x1706f(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8ac9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8acd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ad1:	4d 85 e4             	test   %r12,%r12
    8ad4:	74 3a                	je     8b10 <f0+0x1900>
    8ad6:	0f b6 0a             	movzbl (%rdx),%ecx
    8ad9:	80 f9 02             	cmp    $0x2,%cl
    8adc:	0f 84 7e 0d 00 00    	je     9860 <f0+0x2650>
    8ae2:	80 f9 01             	cmp    $0x1,%cl
    8ae5:	75 29                	jne    8b10 <f0+0x1900>
    8ae7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8aea:	0f b7 c0             	movzwl %ax,%eax
    8aed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8af0:	48 0f af c1          	imul   %rcx,%rax
    8af4:	48 c1 e8 20          	shr    $0x20,%rax
    8af8:	48 39 d0             	cmp    %rdx,%rax
    8afb:	73 13                	jae    8b10 <f0+0x1900>
    8afd:	49 01 c4             	add    %rax,%r12
    8b00:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b05:	0f 84 5d 10 00 00    	je     9b68 <f0+0x2958>
    8b0b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8b10:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
    8b17:	00 
    8b18:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    8b1f:	00 
    8b20:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8b27:	33 f3 bf 
    8b2a:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    8b31:	00 
    8b32:	e8 f9 bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8b37:	48 8b 15 da 6f 01 00 	mov    0x16fda(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8b3e:	49 89 c5             	mov    %rax,%r13
    8b41:	48 2b 05 a8 6f 01 00 	sub    0x16fa8(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8b48:	48 c1 e2 10          	shl    $0x10,%rdx
    8b4c:	48 39 d0             	cmp    %rdx,%rax
    8b4f:	73 59                	jae    8baa <f0+0x199a>
    8b51:	48 89 c2             	mov    %rax,%rdx
    8b54:	48 c1 ea 10          	shr    $0x10,%rdx
    8b58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b5c:	48 8b 15 d5 6f 01 00 	mov    0x16fd5(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8b63:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b67:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b6b:	4d 85 e4             	test   %r12,%r12
    8b6e:	74 3a                	je     8baa <f0+0x199a>
    8b70:	0f b6 0a             	movzbl (%rdx),%ecx
    8b73:	80 f9 02             	cmp    $0x2,%cl
    8b76:	0f 84 d4 0c 00 00    	je     9850 <f0+0x2640>
    8b7c:	80 f9 01             	cmp    $0x1,%cl
    8b7f:	75 29                	jne    8baa <f0+0x199a>
    8b81:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b84:	0f b7 c0             	movzwl %ax,%eax
    8b87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b8a:	48 0f af c1          	imul   %rcx,%rax
    8b8e:	48 c1 e8 20          	shr    $0x20,%rax
    8b92:	48 39 d0             	cmp    %rdx,%rax
    8b95:	73 13                	jae    8baa <f0+0x199a>
    8b97:	49 01 c4             	add    %rax,%r12
    8b9a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b9f:	0f 84 d0 0f 00 00    	je     9b75 <f0+0x2965>
    8ba5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8baa:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
    8bb1:	00 
    8bb2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    8bb9:	00 
    8bba:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8bc1:	00 f0 3f 
    8bc4:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    8bcb:	00 
    8bcc:	e8 5f bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8bd1:	48 8b 15 40 6f 01 00 	mov    0x16f40(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8bd8:	49 89 c5             	mov    %rax,%r13
    8bdb:	48 2b 05 0e 6f 01 00 	sub    0x16f0e(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8be2:	48 c1 e2 10          	shl    $0x10,%rdx
    8be6:	48 39 d0             	cmp    %rdx,%rax
    8be9:	73 59                	jae    8c44 <f0+0x1a34>
    8beb:	48 89 c2             	mov    %rax,%rdx
    8bee:	48 c1 ea 10          	shr    $0x10,%rdx
    8bf2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bf6:	48 8b 15 3b 6f 01 00 	mov    0x16f3b(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8bfd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c01:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c05:	4d 85 e4             	test   %r12,%r12
    8c08:	74 3a                	je     8c44 <f0+0x1a34>
    8c0a:	0f b6 0a             	movzbl (%rdx),%ecx
    8c0d:	80 f9 02             	cmp    $0x2,%cl
    8c10:	0f 84 2a 0c 00 00    	je     9840 <f0+0x2630>
    8c16:	80 f9 01             	cmp    $0x1,%cl
    8c19:	75 29                	jne    8c44 <f0+0x1a34>
    8c1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c1e:	0f b7 c0             	movzwl %ax,%eax
    8c21:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c24:	48 0f af c1          	imul   %rcx,%rax
    8c28:	48 c1 e8 20          	shr    $0x20,%rax
    8c2c:	48 39 d0             	cmp    %rdx,%rax
    8c2f:	73 13                	jae    8c44 <f0+0x1a34>
    8c31:	49 01 c4             	add    %rax,%r12
    8c34:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c39:	0f 84 43 0f 00 00    	je     9b82 <f0+0x2972>
    8c3f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c44:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
    8c4b:	00 
    8c4c:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    8c53:	00 
    8c54:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8c5b:	33 f3 bf 
    8c5e:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    8c65:	00 
    8c66:	e8 c5 bc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8c6b:	48 8b 15 a6 6e 01 00 	mov    0x16ea6(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8c72:	49 89 c5             	mov    %rax,%r13
    8c75:	48 2b 05 74 6e 01 00 	sub    0x16e74(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8c7c:	48 c1 e2 10          	shl    $0x10,%rdx
    8c80:	48 39 d0             	cmp    %rdx,%rax
    8c83:	73 59                	jae    8cde <f0+0x1ace>
    8c85:	48 89 c2             	mov    %rax,%rdx
    8c88:	48 c1 ea 10          	shr    $0x10,%rdx
    8c8c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c90:	48 8b 15 a1 6e 01 00 	mov    0x16ea1(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8c97:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c9b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c9f:	4d 85 e4             	test   %r12,%r12
    8ca2:	74 3a                	je     8cde <f0+0x1ace>
    8ca4:	0f b6 0a             	movzbl (%rdx),%ecx
    8ca7:	80 f9 02             	cmp    $0x2,%cl
    8caa:	0f 84 80 0b 00 00    	je     9830 <f0+0x2620>
    8cb0:	80 f9 01             	cmp    $0x1,%cl
    8cb3:	75 29                	jne    8cde <f0+0x1ace>
    8cb5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8cb8:	0f b7 c0             	movzwl %ax,%eax
    8cbb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8cbe:	48 0f af c1          	imul   %rcx,%rax
    8cc2:	48 c1 e8 20          	shr    $0x20,%rax
    8cc6:	48 39 d0             	cmp    %rdx,%rax
    8cc9:	73 13                	jae    8cde <f0+0x1ace>
    8ccb:	49 01 c4             	add    %rax,%r12
    8cce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8cd3:	0f 84 b6 0e 00 00    	je     9b8f <f0+0x297f>
    8cd9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8cde:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
    8ce5:	00 
    8ce6:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    8ced:	00 
    8cee:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8cf5:	00 f0 3f 
    8cf8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    8cff:	00 
    8d00:	e8 2b bc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8d05:	48 8b 15 0c 6e 01 00 	mov    0x16e0c(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8d0c:	49 89 c5             	mov    %rax,%r13
    8d0f:	48 2b 05 da 6d 01 00 	sub    0x16dda(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8d16:	48 c1 e2 10          	shl    $0x10,%rdx
    8d1a:	48 39 d0             	cmp    %rdx,%rax
    8d1d:	73 59                	jae    8d78 <f0+0x1b68>
    8d1f:	48 89 c2             	mov    %rax,%rdx
    8d22:	48 c1 ea 10          	shr    $0x10,%rdx
    8d26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d2a:	48 8b 15 07 6e 01 00 	mov    0x16e07(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8d31:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d35:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d39:	4d 85 e4             	test   %r12,%r12
    8d3c:	74 3a                	je     8d78 <f0+0x1b68>
    8d3e:	0f b6 0a             	movzbl (%rdx),%ecx
    8d41:	80 f9 02             	cmp    $0x2,%cl
    8d44:	0f 84 d6 0a 00 00    	je     9820 <f0+0x2610>
    8d4a:	80 f9 01             	cmp    $0x1,%cl
    8d4d:	75 29                	jne    8d78 <f0+0x1b68>
    8d4f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d52:	0f b7 c0             	movzwl %ax,%eax
    8d55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d58:	48 0f af c1          	imul   %rcx,%rax
    8d5c:	48 c1 e8 20          	shr    $0x20,%rax
    8d60:	48 39 d0             	cmp    %rdx,%rax
    8d63:	73 13                	jae    8d78 <f0+0x1b68>
    8d65:	49 01 c4             	add    %rax,%r12
    8d68:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d6d:	0f 84 29 0e 00 00    	je     9b9c <f0+0x298c>
    8d73:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d78:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
    8d7f:	00 
    8d80:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    8d87:	00 
    8d88:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8d8f:	33 f3 bf 
    8d92:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    8d99:	00 
    8d9a:	e8 91 bb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8d9f:	48 8b 15 72 6d 01 00 	mov    0x16d72(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8da6:	49 89 c5             	mov    %rax,%r13
    8da9:	48 2b 05 40 6d 01 00 	sub    0x16d40(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8db0:	48 c1 e2 10          	shl    $0x10,%rdx
    8db4:	48 39 d0             	cmp    %rdx,%rax
    8db7:	73 59                	jae    8e12 <f0+0x1c02>
    8db9:	48 89 c2             	mov    %rax,%rdx
    8dbc:	48 c1 ea 10          	shr    $0x10,%rdx
    8dc0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8dc4:	48 8b 15 6d 6d 01 00 	mov    0x16d6d(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8dcb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8dcf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8dd3:	4d 85 e4             	test   %r12,%r12
    8dd6:	74 3a                	je     8e12 <f0+0x1c02>
    8dd8:	0f b6 0a             	movzbl (%rdx),%ecx
    8ddb:	80 f9 02             	cmp    $0x2,%cl
    8dde:	0f 84 24 0a 00 00    	je     9808 <f0+0x25f8>
    8de4:	80 f9 01             	cmp    $0x1,%cl
    8de7:	75 29                	jne    8e12 <f0+0x1c02>
    8de9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8dec:	0f b7 c0             	movzwl %ax,%eax
    8def:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8df2:	48 0f af c1          	imul   %rcx,%rax
    8df6:	48 c1 e8 20          	shr    $0x20,%rax
    8dfa:	48 39 d0             	cmp    %rdx,%rax
    8dfd:	73 13                	jae    8e12 <f0+0x1c02>
    8dff:	49 01 c4             	add    %rax,%r12
    8e02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e07:	0f 84 9c 0d 00 00    	je     9ba9 <f0+0x2999>
    8e0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e12:	48 8d bc 24 50 07 00 	lea    0x750(%rsp),%rdi
    8e19:	00 
    8e1a:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    8e21:	00 
    8e22:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8e29:	00 f0 3f 
    8e2c:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    8e33:	00 
    8e34:	e8 f7 ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8e39:	48 8b 15 d8 6c 01 00 	mov    0x16cd8(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8e40:	49 89 c5             	mov    %rax,%r13
    8e43:	48 2b 05 a6 6c 01 00 	sub    0x16ca6(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8e4a:	48 c1 e2 10          	shl    $0x10,%rdx
    8e4e:	48 39 d0             	cmp    %rdx,%rax
    8e51:	73 59                	jae    8eac <f0+0x1c9c>
    8e53:	48 89 c2             	mov    %rax,%rdx
    8e56:	48 c1 ea 10          	shr    $0x10,%rdx
    8e5a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e5e:	48 8b 15 d3 6c 01 00 	mov    0x16cd3(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8e65:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e69:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e6d:	4d 85 e4             	test   %r12,%r12
    8e70:	74 3a                	je     8eac <f0+0x1c9c>
    8e72:	0f b6 0a             	movzbl (%rdx),%ecx
    8e75:	80 f9 02             	cmp    $0x2,%cl
    8e78:	0f 84 f2 0b 00 00    	je     9a70 <f0+0x2860>
    8e7e:	80 f9 01             	cmp    $0x1,%cl
    8e81:	75 29                	jne    8eac <f0+0x1c9c>
    8e83:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e86:	0f b7 c0             	movzwl %ax,%eax
    8e89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e8c:	48 0f af c1          	imul   %rcx,%rax
    8e90:	48 c1 e8 20          	shr    $0x20,%rax
    8e94:	48 39 d0             	cmp    %rdx,%rax
    8e97:	73 13                	jae    8eac <f0+0x1c9c>
    8e99:	49 01 c4             	add    %rax,%r12
    8e9c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ea1:	0f 84 0f 0d 00 00    	je     9bb6 <f0+0x29a6>
    8ea7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8eac:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
    8eb3:	00 
    8eb4:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    8ebb:	00 
    8ebc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8ec3:	33 f3 bf 
    8ec6:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    8ecd:	00 
    8ece:	e8 5d ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8ed3:	48 8b 15 3e 6c 01 00 	mov    0x16c3e(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8eda:	49 89 c5             	mov    %rax,%r13
    8edd:	48 2b 05 0c 6c 01 00 	sub    0x16c0c(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8ee4:	48 c1 e2 10          	shl    $0x10,%rdx
    8ee8:	48 39 d0             	cmp    %rdx,%rax
    8eeb:	73 59                	jae    8f46 <f0+0x1d36>
    8eed:	48 89 c2             	mov    %rax,%rdx
    8ef0:	48 c1 ea 10          	shr    $0x10,%rdx
    8ef4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ef8:	48 8b 15 39 6c 01 00 	mov    0x16c39(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8eff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f03:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f07:	4d 85 e4             	test   %r12,%r12
    8f0a:	74 3a                	je     8f46 <f0+0x1d36>
    8f0c:	0f b6 0a             	movzbl (%rdx),%ecx
    8f0f:	80 f9 02             	cmp    $0x2,%cl
    8f12:	0f 84 48 0b 00 00    	je     9a60 <f0+0x2850>
    8f18:	80 f9 01             	cmp    $0x1,%cl
    8f1b:	75 29                	jne    8f46 <f0+0x1d36>
    8f1d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f20:	0f b7 c0             	movzwl %ax,%eax
    8f23:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f26:	48 0f af c1          	imul   %rcx,%rax
    8f2a:	48 c1 e8 20          	shr    $0x20,%rax
    8f2e:	48 39 d0             	cmp    %rdx,%rax
    8f31:	73 13                	jae    8f46 <f0+0x1d36>
    8f33:	49 01 c4             	add    %rax,%r12
    8f36:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f3b:	0f 84 82 0c 00 00    	je     9bc3 <f0+0x29b3>
    8f41:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f46:	48 8d bc 24 70 07 00 	lea    0x770(%rsp),%rdi
    8f4d:	00 
    8f4e:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    8f55:	00 
    8f56:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8f5d:	00 f0 3f 
    8f60:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    8f67:	00 
    8f68:	e8 c3 b9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8f6d:	48 8b 15 a4 6b 01 00 	mov    0x16ba4(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    8f74:	49 89 c5             	mov    %rax,%r13
    8f77:	48 2b 05 72 6b 01 00 	sub    0x16b72(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    8f7e:	48 c1 e2 10          	shl    $0x10,%rdx
    8f82:	48 39 d0             	cmp    %rdx,%rax
    8f85:	73 59                	jae    8fe0 <f0+0x1dd0>
    8f87:	48 89 c2             	mov    %rax,%rdx
    8f8a:	48 c1 ea 10          	shr    $0x10,%rdx
    8f8e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f92:	48 8b 15 9f 6b 01 00 	mov    0x16b9f(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    8f99:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f9d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8fa1:	4d 85 e4             	test   %r12,%r12
    8fa4:	74 3a                	je     8fe0 <f0+0x1dd0>
    8fa6:	0f b6 0a             	movzbl (%rdx),%ecx
    8fa9:	80 f9 02             	cmp    $0x2,%cl
    8fac:	0f 84 9e 0a 00 00    	je     9a50 <f0+0x2840>
    8fb2:	80 f9 01             	cmp    $0x1,%cl
    8fb5:	75 29                	jne    8fe0 <f0+0x1dd0>
    8fb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8fba:	0f b7 c0             	movzwl %ax,%eax
    8fbd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8fc0:	48 0f af c1          	imul   %rcx,%rax
    8fc4:	48 c1 e8 20          	shr    $0x20,%rax
    8fc8:	48 39 d0             	cmp    %rdx,%rax
    8fcb:	73 13                	jae    8fe0 <f0+0x1dd0>
    8fcd:	49 01 c4             	add    %rax,%r12
    8fd0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8fd5:	0f 84 f5 0b 00 00    	je     9bd0 <f0+0x29c0>
    8fdb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8fe0:	48 8d bc 24 80 07 00 	lea    0x780(%rsp),%rdi
    8fe7:	00 
    8fe8:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    8fef:	00 
    8ff0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8ff7:	33 f3 bf 
    8ffa:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    9001:	00 
    9002:	e8 29 b9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9007:	48 8b 15 0a 6b 01 00 	mov    0x16b0a(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    900e:	49 89 c5             	mov    %rax,%r13
    9011:	48 2b 05 d8 6a 01 00 	sub    0x16ad8(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    9018:	48 c1 e2 10          	shl    $0x10,%rdx
    901c:	48 39 d0             	cmp    %rdx,%rax
    901f:	73 59                	jae    907a <f0+0x1e6a>
    9021:	48 89 c2             	mov    %rax,%rdx
    9024:	48 c1 ea 10          	shr    $0x10,%rdx
    9028:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    902c:	48 8b 15 05 6b 01 00 	mov    0x16b05(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9033:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9037:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    903b:	4d 85 e4             	test   %r12,%r12
    903e:	74 3a                	je     907a <f0+0x1e6a>
    9040:	0f b6 0a             	movzbl (%rdx),%ecx
    9043:	80 f9 02             	cmp    $0x2,%cl
    9046:	0f 84 f4 09 00 00    	je     9a40 <f0+0x2830>
    904c:	80 f9 01             	cmp    $0x1,%cl
    904f:	75 29                	jne    907a <f0+0x1e6a>
    9051:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9054:	0f b7 c0             	movzwl %ax,%eax
    9057:	8b 52 1c             	mov    0x1c(%rdx),%edx
    905a:	48 0f af c1          	imul   %rcx,%rax
    905e:	48 c1 e8 20          	shr    $0x20,%rax
    9062:	48 39 d0             	cmp    %rdx,%rax
    9065:	73 13                	jae    907a <f0+0x1e6a>
    9067:	49 01 c4             	add    %rax,%r12
    906a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    906f:	0f 84 68 0b 00 00    	je     9bdd <f0+0x29cd>
    9075:	41 c6 04 24 01       	movb   $0x1,(%r12)
    907a:	48 8d bc 24 90 07 00 	lea    0x790(%rsp),%rdi
    9081:	00 
    9082:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    9089:	00 
    908a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9091:	00 f0 3f 
    9094:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    909b:	00 
    909c:	e8 8f b8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    90a1:	48 8b 15 70 6a 01 00 	mov    0x16a70(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    90a8:	49 89 c5             	mov    %rax,%r13
    90ab:	48 2b 05 3e 6a 01 00 	sub    0x16a3e(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    90b2:	48 c1 e2 10          	shl    $0x10,%rdx
    90b6:	48 39 d0             	cmp    %rdx,%rax
    90b9:	73 59                	jae    9114 <f0+0x1f04>
    90bb:	48 89 c2             	mov    %rax,%rdx
    90be:	48 c1 ea 10          	shr    $0x10,%rdx
    90c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90c6:	48 8b 15 6b 6a 01 00 	mov    0x16a6b(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    90cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90d1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    90d5:	4d 85 e4             	test   %r12,%r12
    90d8:	74 3a                	je     9114 <f0+0x1f04>
    90da:	0f b6 0a             	movzbl (%rdx),%ecx
    90dd:	80 f9 02             	cmp    $0x2,%cl
    90e0:	0f 84 4a 09 00 00    	je     9a30 <f0+0x2820>
    90e6:	80 f9 01             	cmp    $0x1,%cl
    90e9:	75 29                	jne    9114 <f0+0x1f04>
    90eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90ee:	0f b7 c0             	movzwl %ax,%eax
    90f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90f4:	48 0f af c1          	imul   %rcx,%rax
    90f8:	48 c1 e8 20          	shr    $0x20,%rax
    90fc:	48 39 d0             	cmp    %rdx,%rax
    90ff:	73 13                	jae    9114 <f0+0x1f04>
    9101:	49 01 c4             	add    %rax,%r12
    9104:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9109:	0f 84 db 0a 00 00    	je     9bea <f0+0x29da>
    910f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9114:	48 8d bc 24 a0 07 00 	lea    0x7a0(%rsp),%rdi
    911b:	00 
    911c:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    9123:	00 
    9124:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    912b:	33 f3 bf 
    912e:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    9135:	00 
    9136:	e8 f5 b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    913b:	48 8b 15 d6 69 01 00 	mov    0x169d6(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9142:	49 89 c5             	mov    %rax,%r13
    9145:	48 2b 05 a4 69 01 00 	sub    0x169a4(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    914c:	48 c1 e2 10          	shl    $0x10,%rdx
    9150:	48 39 d0             	cmp    %rdx,%rax
    9153:	73 59                	jae    91ae <f0+0x1f9e>
    9155:	48 89 c2             	mov    %rax,%rdx
    9158:	48 c1 ea 10          	shr    $0x10,%rdx
    915c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9160:	48 8b 15 d1 69 01 00 	mov    0x169d1(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9167:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    916b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    916f:	4d 85 e4             	test   %r12,%r12
    9172:	74 3a                	je     91ae <f0+0x1f9e>
    9174:	0f b6 0a             	movzbl (%rdx),%ecx
    9177:	80 f9 02             	cmp    $0x2,%cl
    917a:	0f 84 a0 08 00 00    	je     9a20 <f0+0x2810>
    9180:	80 f9 01             	cmp    $0x1,%cl
    9183:	75 29                	jne    91ae <f0+0x1f9e>
    9185:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9188:	0f b7 c0             	movzwl %ax,%eax
    918b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    918e:	48 0f af c1          	imul   %rcx,%rax
    9192:	48 c1 e8 20          	shr    $0x20,%rax
    9196:	48 39 d0             	cmp    %rdx,%rax
    9199:	73 13                	jae    91ae <f0+0x1f9e>
    919b:	49 01 c4             	add    %rax,%r12
    919e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    91a3:	0f 84 4e 0a 00 00    	je     9bf7 <f0+0x29e7>
    91a9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    91ae:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
    91b5:	00 
    91b6:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    91bd:	00 
    91be:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    91c5:	00 f0 3f 
    91c8:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    91cf:	00 
    91d0:	e8 5b b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    91d5:	48 8b 15 3c 69 01 00 	mov    0x1693c(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    91dc:	49 89 c5             	mov    %rax,%r13
    91df:	48 2b 05 0a 69 01 00 	sub    0x1690a(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    91e6:	48 c1 e2 10          	shl    $0x10,%rdx
    91ea:	48 39 d0             	cmp    %rdx,%rax
    91ed:	73 59                	jae    9248 <f0+0x2038>
    91ef:	48 89 c2             	mov    %rax,%rdx
    91f2:	48 c1 ea 10          	shr    $0x10,%rdx
    91f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    91fa:	48 8b 15 37 69 01 00 	mov    0x16937(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9201:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9205:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9209:	4d 85 e4             	test   %r12,%r12
    920c:	74 3a                	je     9248 <f0+0x2038>
    920e:	0f b6 0a             	movzbl (%rdx),%ecx
    9211:	80 f9 02             	cmp    $0x2,%cl
    9214:	0f 84 f6 07 00 00    	je     9a10 <f0+0x2800>
    921a:	80 f9 01             	cmp    $0x1,%cl
    921d:	75 29                	jne    9248 <f0+0x2038>
    921f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9222:	0f b7 c0             	movzwl %ax,%eax
    9225:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9228:	48 0f af c1          	imul   %rcx,%rax
    922c:	48 c1 e8 20          	shr    $0x20,%rax
    9230:	48 39 d0             	cmp    %rdx,%rax
    9233:	73 13                	jae    9248 <f0+0x2038>
    9235:	49 01 c4             	add    %rax,%r12
    9238:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    923d:	0f 84 c1 09 00 00    	je     9c04 <f0+0x29f4>
    9243:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9248:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
    924f:	00 
    9250:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    9257:	00 
    9258:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    925f:	33 f3 bf 
    9262:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    9269:	00 
    926a:	e8 c1 b6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    926f:	48 8b 15 a2 68 01 00 	mov    0x168a2(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9276:	49 89 c5             	mov    %rax,%r13
    9279:	48 2b 05 70 68 01 00 	sub    0x16870(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    9280:	48 c1 e2 10          	shl    $0x10,%rdx
    9284:	48 39 d0             	cmp    %rdx,%rax
    9287:	73 59                	jae    92e2 <f0+0x20d2>
    9289:	48 89 c2             	mov    %rax,%rdx
    928c:	48 c1 ea 10          	shr    $0x10,%rdx
    9290:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9294:	48 8b 15 9d 68 01 00 	mov    0x1689d(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    929b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    929f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    92a3:	4d 85 e4             	test   %r12,%r12
    92a6:	74 3a                	je     92e2 <f0+0x20d2>
    92a8:	0f b6 0a             	movzbl (%rdx),%ecx
    92ab:	80 f9 02             	cmp    $0x2,%cl
    92ae:	0f 84 4c 07 00 00    	je     9a00 <f0+0x27f0>
    92b4:	80 f9 01             	cmp    $0x1,%cl
    92b7:	75 29                	jne    92e2 <f0+0x20d2>
    92b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92bc:	0f b7 c0             	movzwl %ax,%eax
    92bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92c2:	48 0f af c1          	imul   %rcx,%rax
    92c6:	48 c1 e8 20          	shr    $0x20,%rax
    92ca:	48 39 d0             	cmp    %rdx,%rax
    92cd:	73 13                	jae    92e2 <f0+0x20d2>
    92cf:	49 01 c4             	add    %rax,%r12
    92d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    92d7:	0f 84 34 09 00 00    	je     9c11 <f0+0x2a01>
    92dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    92e2:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
    92e9:	00 
    92ea:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    92f1:	00 
    92f2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    92f9:	00 f0 3f 
    92fc:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9303:	00 
    9304:	e8 27 b6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9309:	48 8b 15 08 68 01 00 	mov    0x16808(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9310:	49 89 c5             	mov    %rax,%r13
    9313:	48 2b 05 d6 67 01 00 	sub    0x167d6(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    931a:	48 c1 e2 10          	shl    $0x10,%rdx
    931e:	48 39 d0             	cmp    %rdx,%rax
    9321:	73 59                	jae    937c <f0+0x216c>
    9323:	48 89 c2             	mov    %rax,%rdx
    9326:	48 c1 ea 10          	shr    $0x10,%rdx
    932a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    932e:	48 8b 15 03 68 01 00 	mov    0x16803(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9335:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9339:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    933d:	4d 85 e4             	test   %r12,%r12
    9340:	74 3a                	je     937c <f0+0x216c>
    9342:	0f b6 0a             	movzbl (%rdx),%ecx
    9345:	80 f9 02             	cmp    $0x2,%cl
    9348:	0f 84 a2 06 00 00    	je     99f0 <f0+0x27e0>
    934e:	80 f9 01             	cmp    $0x1,%cl
    9351:	75 29                	jne    937c <f0+0x216c>
    9353:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9356:	0f b7 c0             	movzwl %ax,%eax
    9359:	8b 52 1c             	mov    0x1c(%rdx),%edx
    935c:	48 0f af c1          	imul   %rcx,%rax
    9360:	48 c1 e8 20          	shr    $0x20,%rax
    9364:	48 39 d0             	cmp    %rdx,%rax
    9367:	73 13                	jae    937c <f0+0x216c>
    9369:	49 01 c4             	add    %rax,%r12
    936c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9371:	0f 84 a7 08 00 00    	je     9c1e <f0+0x2a0e>
    9377:	41 c6 04 24 01       	movb   $0x1,(%r12)
    937c:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
    9383:	00 
    9384:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    938b:	00 
    938c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9393:	33 f3 bf 
    9396:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    939d:	00 
    939e:	e8 8d b5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    93a3:	48 8b 15 6e 67 01 00 	mov    0x1676e(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    93aa:	49 89 c5             	mov    %rax,%r13
    93ad:	48 2b 05 3c 67 01 00 	sub    0x1673c(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    93b4:	48 c1 e2 10          	shl    $0x10,%rdx
    93b8:	48 39 d0             	cmp    %rdx,%rax
    93bb:	73 59                	jae    9416 <f0+0x2206>
    93bd:	48 89 c2             	mov    %rax,%rdx
    93c0:	48 c1 ea 10          	shr    $0x10,%rdx
    93c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93c8:	48 8b 15 69 67 01 00 	mov    0x16769(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    93cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    93d7:	4d 85 e4             	test   %r12,%r12
    93da:	74 3a                	je     9416 <f0+0x2206>
    93dc:	0f b6 0a             	movzbl (%rdx),%ecx
    93df:	80 f9 02             	cmp    $0x2,%cl
    93e2:	0f 84 f8 05 00 00    	je     99e0 <f0+0x27d0>
    93e8:	80 f9 01             	cmp    $0x1,%cl
    93eb:	75 29                	jne    9416 <f0+0x2206>
    93ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93f0:	0f b7 c0             	movzwl %ax,%eax
    93f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93f6:	48 0f af c1          	imul   %rcx,%rax
    93fa:	48 c1 e8 20          	shr    $0x20,%rax
    93fe:	48 39 d0             	cmp    %rdx,%rax
    9401:	73 13                	jae    9416 <f0+0x2206>
    9403:	49 01 c4             	add    %rax,%r12
    9406:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    940b:	0f 84 1a 08 00 00    	je     9c2b <f0+0x2a1b>
    9411:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9416:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
    941d:	00 
    941e:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9425:	00 
    9426:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    942d:	00 f0 3f 
    9430:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9437:	00 
    9438:	e8 f3 b4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    943d:	48 8b 15 d4 66 01 00 	mov    0x166d4(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9444:	49 89 c5             	mov    %rax,%r13
    9447:	48 2b 05 a2 66 01 00 	sub    0x166a2(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    944e:	48 c1 e2 10          	shl    $0x10,%rdx
    9452:	48 39 d0             	cmp    %rdx,%rax
    9455:	73 59                	jae    94b0 <f0+0x22a0>
    9457:	48 89 c2             	mov    %rax,%rdx
    945a:	48 c1 ea 10          	shr    $0x10,%rdx
    945e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9462:	48 8b 15 cf 66 01 00 	mov    0x166cf(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9469:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    946d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9471:	4d 85 e4             	test   %r12,%r12
    9474:	74 3a                	je     94b0 <f0+0x22a0>
    9476:	0f b6 0a             	movzbl (%rdx),%ecx
    9479:	80 f9 02             	cmp    $0x2,%cl
    947c:	0f 84 4e 05 00 00    	je     99d0 <f0+0x27c0>
    9482:	80 f9 01             	cmp    $0x1,%cl
    9485:	75 29                	jne    94b0 <f0+0x22a0>
    9487:	8b 4a 18             	mov    0x18(%rdx),%ecx
    948a:	0f b7 c0             	movzwl %ax,%eax
    948d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9490:	48 0f af c1          	imul   %rcx,%rax
    9494:	48 c1 e8 20          	shr    $0x20,%rax
    9498:	48 39 d0             	cmp    %rdx,%rax
    949b:	73 13                	jae    94b0 <f0+0x22a0>
    949d:	49 01 c4             	add    %rax,%r12
    94a0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    94a5:	0f 84 8d 07 00 00    	je     9c38 <f0+0x2a28>
    94ab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    94b0:	48 8d bc 24 00 08 00 	lea    0x800(%rsp),%rdi
    94b7:	00 
    94b8:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    94bf:	00 
    94c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    94c7:	33 f3 bf 
    94ca:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    94d1:	00 
    94d2:	e8 59 b4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    94d7:	48 8b 15 3a 66 01 00 	mov    0x1663a(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    94de:	49 89 c5             	mov    %rax,%r13
    94e1:	48 2b 05 08 66 01 00 	sub    0x16608(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    94e8:	48 c1 e2 10          	shl    $0x10,%rdx
    94ec:	48 39 d0             	cmp    %rdx,%rax
    94ef:	73 59                	jae    954a <f0+0x233a>
    94f1:	48 89 c2             	mov    %rax,%rdx
    94f4:	48 c1 ea 10          	shr    $0x10,%rdx
    94f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94fc:	48 8b 15 35 66 01 00 	mov    0x16635(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9503:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9507:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    950b:	4d 85 e4             	test   %r12,%r12
    950e:	74 3a                	je     954a <f0+0x233a>
    9510:	0f b6 0a             	movzbl (%rdx),%ecx
    9513:	80 f9 02             	cmp    $0x2,%cl
    9516:	0f 84 a4 04 00 00    	je     99c0 <f0+0x27b0>
    951c:	80 f9 01             	cmp    $0x1,%cl
    951f:	75 29                	jne    954a <f0+0x233a>
    9521:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9524:	0f b7 c0             	movzwl %ax,%eax
    9527:	8b 52 1c             	mov    0x1c(%rdx),%edx
    952a:	48 0f af c1          	imul   %rcx,%rax
    952e:	48 c1 e8 20          	shr    $0x20,%rax
    9532:	48 39 d0             	cmp    %rdx,%rax
    9535:	73 13                	jae    954a <f0+0x233a>
    9537:	49 01 c4             	add    %rax,%r12
    953a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    953f:	0f 84 00 07 00 00    	je     9c45 <f0+0x2a35>
    9545:	41 c6 04 24 01       	movb   $0x1,(%r12)
    954a:	48 8d bc 24 10 08 00 	lea    0x810(%rsp),%rdi
    9551:	00 
    9552:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    9559:	00 
    955a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9561:	00 f0 3f 
    9564:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    956b:	00 
    956c:	e8 bf b3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9571:	48 8b 15 a0 65 01 00 	mov    0x165a0(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9578:	49 89 c5             	mov    %rax,%r13
    957b:	48 2b 05 6e 65 01 00 	sub    0x1656e(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    9582:	48 c1 e2 10          	shl    $0x10,%rdx
    9586:	48 39 d0             	cmp    %rdx,%rax
    9589:	73 59                	jae    95e4 <f0+0x23d4>
    958b:	48 89 c2             	mov    %rax,%rdx
    958e:	48 c1 ea 10          	shr    $0x10,%rdx
    9592:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9596:	48 8b 15 9b 65 01 00 	mov    0x1659b(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    959d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95a1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    95a5:	4d 85 e4             	test   %r12,%r12
    95a8:	74 3a                	je     95e4 <f0+0x23d4>
    95aa:	0f b6 0a             	movzbl (%rdx),%ecx
    95ad:	80 f9 02             	cmp    $0x2,%cl
    95b0:	0f 84 fa 03 00 00    	je     99b0 <f0+0x27a0>
    95b6:	80 f9 01             	cmp    $0x1,%cl
    95b9:	75 29                	jne    95e4 <f0+0x23d4>
    95bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95be:	0f b7 c0             	movzwl %ax,%eax
    95c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95c4:	48 0f af c1          	imul   %rcx,%rax
    95c8:	48 c1 e8 20          	shr    $0x20,%rax
    95cc:	48 39 d0             	cmp    %rdx,%rax
    95cf:	73 13                	jae    95e4 <f0+0x23d4>
    95d1:	49 01 c4             	add    %rax,%r12
    95d4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    95d9:	0f 84 73 06 00 00    	je     9c52 <f0+0x2a42>
    95df:	41 c6 04 24 01       	movb   $0x1,(%r12)
    95e4:	48 8d bc 24 20 08 00 	lea    0x820(%rsp),%rdi
    95eb:	00 
    95ec:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    95f3:	00 
    95f4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    95fb:	33 f3 bf 
    95fe:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9605:	00 
    9606:	e8 25 b3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    960b:	48 8b 15 06 65 01 00 	mov    0x16506(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9612:	49 89 c5             	mov    %rax,%r13
    9615:	48 2b 05 d4 64 01 00 	sub    0x164d4(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    961c:	48 c1 e2 10          	shl    $0x10,%rdx
    9620:	48 39 d0             	cmp    %rdx,%rax
    9623:	73 59                	jae    967e <f0+0x246e>
    9625:	48 89 c2             	mov    %rax,%rdx
    9628:	48 c1 ea 10          	shr    $0x10,%rdx
    962c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9630:	48 8b 15 01 65 01 00 	mov    0x16501(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9637:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    963b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    963f:	4d 85 e4             	test   %r12,%r12
    9642:	74 3a                	je     967e <f0+0x246e>
    9644:	0f b6 0a             	movzbl (%rdx),%ecx
    9647:	80 f9 02             	cmp    $0x2,%cl
    964a:	0f 84 50 03 00 00    	je     99a0 <f0+0x2790>
    9650:	80 f9 01             	cmp    $0x1,%cl
    9653:	75 29                	jne    967e <f0+0x246e>
    9655:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9658:	0f b7 c0             	movzwl %ax,%eax
    965b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    965e:	48 0f af c1          	imul   %rcx,%rax
    9662:	48 c1 e8 20          	shr    $0x20,%rax
    9666:	48 39 d0             	cmp    %rdx,%rax
    9669:	73 13                	jae    967e <f0+0x246e>
    966b:	49 01 c4             	add    %rax,%r12
    966e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9673:	0f 84 e6 05 00 00    	je     9c5f <f0+0x2a4f>
    9679:	41 c6 04 24 01       	movb   $0x1,(%r12)
    967e:	48 8d bc 24 30 08 00 	lea    0x830(%rsp),%rdi
    9685:	00 
    9686:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    968d:	00 
    968e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9695:	00 f0 3f 
    9698:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    969f:	00 
    96a0:	e8 8b b2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    96a5:	48 8b 15 6c 64 01 00 	mov    0x1646c(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    96ac:	49 89 c5             	mov    %rax,%r13
    96af:	48 2b 05 3a 64 01 00 	sub    0x1643a(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    96b6:	48 c1 e2 10          	shl    $0x10,%rdx
    96ba:	48 39 d0             	cmp    %rdx,%rax
    96bd:	73 59                	jae    9718 <f0+0x2508>
    96bf:	48 89 c2             	mov    %rax,%rdx
    96c2:	48 c1 ea 10          	shr    $0x10,%rdx
    96c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96ca:	48 8b 15 67 64 01 00 	mov    0x16467(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    96d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96d5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    96d9:	4d 85 e4             	test   %r12,%r12
    96dc:	74 3a                	je     9718 <f0+0x2508>
    96de:	0f b6 0a             	movzbl (%rdx),%ecx
    96e1:	80 f9 02             	cmp    $0x2,%cl
    96e4:	0f 84 a6 02 00 00    	je     9990 <f0+0x2780>
    96ea:	80 f9 01             	cmp    $0x1,%cl
    96ed:	75 29                	jne    9718 <f0+0x2508>
    96ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96f2:	0f b7 c0             	movzwl %ax,%eax
    96f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96f8:	48 0f af c1          	imul   %rcx,%rax
    96fc:	48 c1 e8 20          	shr    $0x20,%rax
    9700:	48 39 d0             	cmp    %rdx,%rax
    9703:	73 13                	jae    9718 <f0+0x2508>
    9705:	49 01 c4             	add    %rax,%r12
    9708:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    970d:	0f 84 59 05 00 00    	je     9c6c <f0+0x2a5c>
    9713:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9718:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    971f:	33 f3 bf 
    9722:	48 89 ef             	mov    %rbp,%rdi
    9725:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    972c:	00 
    972d:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    9734:	00 
    9735:	e8 f6 b1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    973a:	48 8b 15 d7 63 01 00 	mov    0x163d7(%rip),%rdx        # 1fb18 <fwp_heap+0x13d8>
    9741:	48 89 c5             	mov    %rax,%rbp
    9744:	48 2b 05 a5 63 01 00 	sub    0x163a5(%rip),%rax        # 1faf0 <fwp_heap+0x13b0>
    974b:	48 c1 e2 10          	shl    $0x10,%rdx
    974f:	48 39 d0             	cmp    %rdx,%rax
    9752:	73 59                	jae    97ad <f0+0x259d>
    9754:	48 89 c2             	mov    %rax,%rdx
    9757:	48 c1 ea 10          	shr    $0x10,%rdx
    975b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    975f:	48 8b 15 d2 63 01 00 	mov    0x163d2(%rip),%rdx        # 1fb38 <fwp_heap+0x13f8>
    9766:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    976a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    976e:	4d 85 e4             	test   %r12,%r12
    9771:	74 3a                	je     97ad <f0+0x259d>
    9773:	0f b6 0a             	movzbl (%rdx),%ecx
    9776:	80 f9 02             	cmp    $0x2,%cl
    9779:	0f 84 01 02 00 00    	je     9980 <f0+0x2770>
    977f:	80 f9 01             	cmp    $0x1,%cl
    9782:	75 29                	jne    97ad <f0+0x259d>
    9784:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9787:	0f b7 c0             	movzwl %ax,%eax
    978a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    978d:	48 0f af c1          	imul   %rcx,%rax
    9791:	48 c1 e8 20          	shr    $0x20,%rax
    9795:	48 39 d0             	cmp    %rdx,%rax
    9798:	73 13                	jae    97ad <f0+0x259d>
    979a:	49 01 c4             	add    %rax,%r12
    979d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    97a2:	0f 84 d6 02 00 00    	je     9a7e <f0+0x286e>
    97a8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    97ad:	48 89 de             	mov    %rbx,%rsi
    97b0:	48 89 ef             	mov    %rbp,%rdi
    97b3:	e8 f8 ca ff ff       	call   62b0 <fwp_hof0.constprop.0>
    97b8:	48 89 ef             	mov    %rbp,%rdi
    97bb:	e8 20 b8 ff ff       	call   4fe0 <fwp_drop0>
    97c0:	48 89 df             	mov    %rbx,%rdi
    97c3:	e8 18 b8 ff ff       	call   4fe0 <fwp_drop0>
    97c8:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    97cf:	00 
    97d0:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    97d7:	00 00 
    97d9:	0f 85 9a 04 00 00    	jne    9c79 <f0+0x2a69>
    97df:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    97e6:	31 c0                	xor    %eax,%eax
    97e8:	5b                   	pop    %rbx
    97e9:	5d                   	pop    %rbp
    97ea:	41 5c                	pop    %r12
    97ec:	41 5d                	pop    %r13
    97ee:	41 5e                	pop    %r14
    97f0:	c3                   	ret
    97f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    97f8:	4c 89 ef             	mov    %r13,%rdi
    97fb:	e8 d0 a6 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9800:	e9 c4 da ff ff       	jmp    72c9 <f0+0xb9>
    9805:	0f 1f 00             	nopl   (%rax)
    9808:	66 85 c0             	test   %ax,%ax
    980b:	0f 85 01 f6 ff ff    	jne    8e12 <f0+0x1c02>
    9811:	e9 ec f5 ff ff       	jmp    8e02 <f0+0x1bf2>
    9816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    981d:	00 00 00 
    9820:	66 85 c0             	test   %ax,%ax
    9823:	0f 85 4f f5 ff ff    	jne    8d78 <f0+0x1b68>
    9829:	e9 3a f5 ff ff       	jmp    8d68 <f0+0x1b58>
    982e:	66 90                	xchg   %ax,%ax
    9830:	66 85 c0             	test   %ax,%ax
    9833:	0f 85 a5 f4 ff ff    	jne    8cde <f0+0x1ace>
    9839:	e9 90 f4 ff ff       	jmp    8cce <f0+0x1abe>
    983e:	66 90                	xchg   %ax,%ax
    9840:	66 85 c0             	test   %ax,%ax
    9843:	0f 85 fb f3 ff ff    	jne    8c44 <f0+0x1a34>
    9849:	e9 e6 f3 ff ff       	jmp    8c34 <f0+0x1a24>
    984e:	66 90                	xchg   %ax,%ax
    9850:	66 85 c0             	test   %ax,%ax
    9853:	0f 85 51 f3 ff ff    	jne    8baa <f0+0x199a>
    9859:	e9 3c f3 ff ff       	jmp    8b9a <f0+0x198a>
    985e:	66 90                	xchg   %ax,%ax
    9860:	66 85 c0             	test   %ax,%ax
    9863:	0f 85 a7 f2 ff ff    	jne    8b10 <f0+0x1900>
    9869:	e9 92 f2 ff ff       	jmp    8b00 <f0+0x18f0>
    986e:	66 90                	xchg   %ax,%ax
    9870:	66 85 c0             	test   %ax,%ax
    9873:	0f 85 fd f1 ff ff    	jne    8a76 <f0+0x1866>
    9879:	e9 e8 f1 ff ff       	jmp    8a66 <f0+0x1856>
    987e:	66 90                	xchg   %ax,%ax
    9880:	66 85 c0             	test   %ax,%ax
    9883:	0f 85 53 f1 ff ff    	jne    89dc <f0+0x17cc>
    9889:	e9 3e f1 ff ff       	jmp    89cc <f0+0x17bc>
    988e:	66 90                	xchg   %ax,%ax
    9890:	66 85 c0             	test   %ax,%ax
    9893:	0f 85 6e dc ff ff    	jne    7507 <f0+0x2f7>
    9899:	e9 59 dc ff ff       	jmp    74f7 <f0+0x2e7>
    989e:	66 90                	xchg   %ax,%ax
    98a0:	66 85 c0             	test   %ax,%ax
    98a3:	0f 85 cd db ff ff    	jne    7476 <f0+0x266>
    98a9:	e9 b8 db ff ff       	jmp    7466 <f0+0x256>
    98ae:	66 90                	xchg   %ax,%ax
    98b0:	66 85 c0             	test   %ax,%ax
    98b3:	0f 85 2c db ff ff    	jne    73e5 <f0+0x1d5>
    98b9:	e9 17 db ff ff       	jmp    73d5 <f0+0x1c5>
    98be:	66 90                	xchg   %ax,%ax
    98c0:	66 85 c0             	test   %ax,%ax
    98c3:	0f 85 a9 eb ff ff    	jne    8472 <f0+0x1262>
    98c9:	e9 94 eb ff ff       	jmp    8462 <f0+0x1252>
    98ce:	66 90                	xchg   %ax,%ax
    98d0:	66 85 c0             	test   %ax,%ax
    98d3:	0f 85 ff ea ff ff    	jne    83d8 <f0+0x11c8>
    98d9:	e9 ea ea ff ff       	jmp    83c8 <f0+0x11b8>
    98de:	66 90                	xchg   %ax,%ax
    98e0:	66 85 c0             	test   %ax,%ax
    98e3:	0f 85 55 ea ff ff    	jne    833e <f0+0x112e>
    98e9:	e9 40 ea ff ff       	jmp    832e <f0+0x111e>
    98ee:	66 90                	xchg   %ax,%ax
    98f0:	66 85 c0             	test   %ax,%ax
    98f3:	0f 85 9f dc ff ff    	jne    7598 <f0+0x388>
    98f9:	e9 8a dc ff ff       	jmp    7588 <f0+0x378>
    98fe:	66 90                	xchg   %ax,%ax
    9900:	66 85 c0             	test   %ax,%ax
    9903:	0f 85 39 f0 ff ff    	jne    8942 <f0+0x1732>
    9909:	e9 24 f0 ff ff       	jmp    8932 <f0+0x1722>
    990e:	66 90                	xchg   %ax,%ax
    9910:	66 85 c0             	test   %ax,%ax
    9913:	0f 85 8f ef ff ff    	jne    88a8 <f0+0x1698>
    9919:	e9 7a ef ff ff       	jmp    8898 <f0+0x1688>
    991e:	66 90                	xchg   %ax,%ax
    9920:	66 85 c0             	test   %ax,%ax
    9923:	0f 85 e5 ee ff ff    	jne    880e <f0+0x15fe>
    9929:	e9 d0 ee ff ff       	jmp    87fe <f0+0x15ee>
    992e:	66 90                	xchg   %ax,%ax
    9930:	66 85 c0             	test   %ax,%ax
    9933:	0f 85 3b ee ff ff    	jne    8774 <f0+0x1564>
    9939:	e9 26 ee ff ff       	jmp    8764 <f0+0x1554>
    993e:	66 90                	xchg   %ax,%ax
    9940:	66 85 c0             	test   %ax,%ax
    9943:	0f 85 91 ed ff ff    	jne    86da <f0+0x14ca>
    9949:	e9 7c ed ff ff       	jmp    86ca <f0+0x14ba>
    994e:	66 90                	xchg   %ax,%ax
    9950:	66 85 c0             	test   %ax,%ax
    9953:	0f 85 e7 ec ff ff    	jne    8640 <f0+0x1430>
    9959:	e9 d2 ec ff ff       	jmp    8630 <f0+0x1420>
    995e:	66 90                	xchg   %ax,%ax
    9960:	66 85 c0             	test   %ax,%ax
    9963:	0f 85 3d ec ff ff    	jne    85a6 <f0+0x1396>
    9969:	e9 28 ec ff ff       	jmp    8596 <f0+0x1386>
    996e:	66 90                	xchg   %ax,%ax
    9970:	66 85 c0             	test   %ax,%ax
    9973:	0f 85 93 eb ff ff    	jne    850c <f0+0x12fc>
    9979:	e9 7e eb ff ff       	jmp    84fc <f0+0x12ec>
    997e:	66 90                	xchg   %ax,%ax
    9980:	66 85 c0             	test   %ax,%ax
    9983:	0f 85 24 fe ff ff    	jne    97ad <f0+0x259d>
    9989:	e9 0f fe ff ff       	jmp    979d <f0+0x258d>
    998e:	66 90                	xchg   %ax,%ax
    9990:	66 85 c0             	test   %ax,%ax
    9993:	0f 85 7f fd ff ff    	jne    9718 <f0+0x2508>
    9999:	e9 6a fd ff ff       	jmp    9708 <f0+0x24f8>
    999e:	66 90                	xchg   %ax,%ax
    99a0:	66 85 c0             	test   %ax,%ax
    99a3:	0f 85 d5 fc ff ff    	jne    967e <f0+0x246e>
    99a9:	e9 c0 fc ff ff       	jmp    966e <f0+0x245e>
    99ae:	66 90                	xchg   %ax,%ax
    99b0:	66 85 c0             	test   %ax,%ax
    99b3:	0f 85 2b fc ff ff    	jne    95e4 <f0+0x23d4>
    99b9:	e9 16 fc ff ff       	jmp    95d4 <f0+0x23c4>
    99be:	66 90                	xchg   %ax,%ax
    99c0:	66 85 c0             	test   %ax,%ax
    99c3:	0f 85 81 fb ff ff    	jne    954a <f0+0x233a>
    99c9:	e9 6c fb ff ff       	jmp    953a <f0+0x232a>
    99ce:	66 90                	xchg   %ax,%ax
    99d0:	66 85 c0             	test   %ax,%ax
    99d3:	0f 85 d7 fa ff ff    	jne    94b0 <f0+0x22a0>
    99d9:	e9 c2 fa ff ff       	jmp    94a0 <f0+0x2290>
    99de:	66 90                	xchg   %ax,%ax
    99e0:	66 85 c0             	test   %ax,%ax
    99e3:	0f 85 2d fa ff ff    	jne    9416 <f0+0x2206>
    99e9:	e9 18 fa ff ff       	jmp    9406 <f0+0x21f6>
    99ee:	66 90                	xchg   %ax,%ax
    99f0:	66 85 c0             	test   %ax,%ax
    99f3:	0f 85 83 f9 ff ff    	jne    937c <f0+0x216c>
    99f9:	e9 6e f9 ff ff       	jmp    936c <f0+0x215c>
    99fe:	66 90                	xchg   %ax,%ax
    9a00:	66 85 c0             	test   %ax,%ax
    9a03:	0f 85 d9 f8 ff ff    	jne    92e2 <f0+0x20d2>
    9a09:	e9 c4 f8 ff ff       	jmp    92d2 <f0+0x20c2>
    9a0e:	66 90                	xchg   %ax,%ax
    9a10:	66 85 c0             	test   %ax,%ax
    9a13:	0f 85 2f f8 ff ff    	jne    9248 <f0+0x2038>
    9a19:	e9 1a f8 ff ff       	jmp    9238 <f0+0x2028>
    9a1e:	66 90                	xchg   %ax,%ax
    9a20:	66 85 c0             	test   %ax,%ax
    9a23:	0f 85 85 f7 ff ff    	jne    91ae <f0+0x1f9e>
    9a29:	e9 70 f7 ff ff       	jmp    919e <f0+0x1f8e>
    9a2e:	66 90                	xchg   %ax,%ax
    9a30:	66 85 c0             	test   %ax,%ax
    9a33:	0f 85 db f6 ff ff    	jne    9114 <f0+0x1f04>
    9a39:	e9 c6 f6 ff ff       	jmp    9104 <f0+0x1ef4>
    9a3e:	66 90                	xchg   %ax,%ax
    9a40:	66 85 c0             	test   %ax,%ax
    9a43:	0f 85 31 f6 ff ff    	jne    907a <f0+0x1e6a>
    9a49:	e9 1c f6 ff ff       	jmp    906a <f0+0x1e5a>
    9a4e:	66 90                	xchg   %ax,%ax
    9a50:	66 85 c0             	test   %ax,%ax
    9a53:	0f 85 87 f5 ff ff    	jne    8fe0 <f0+0x1dd0>
    9a59:	e9 72 f5 ff ff       	jmp    8fd0 <f0+0x1dc0>
    9a5e:	66 90                	xchg   %ax,%ax
    9a60:	66 85 c0             	test   %ax,%ax
    9a63:	0f 85 dd f4 ff ff    	jne    8f46 <f0+0x1d36>
    9a69:	e9 c8 f4 ff ff       	jmp    8f36 <f0+0x1d26>
    9a6e:	66 90                	xchg   %ax,%ax
    9a70:	66 85 c0             	test   %ax,%ax
    9a73:	0f 85 33 f4 ff ff    	jne    8eac <f0+0x1c9c>
    9a79:	e9 1e f4 ff ff       	jmp    8e9c <f0+0x1c8c>
    9a7e:	4c 89 e7             	mov    %r12,%rdi
    9a81:	e8 4a a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9a86:	e9 1d fd ff ff       	jmp    97a8 <f0+0x2598>
    9a8b:	4c 89 e7             	mov    %r12,%rdi
    9a8e:	e8 3d a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9a93:	e9 48 d9 ff ff       	jmp    73e0 <f0+0x1d0>
    9a98:	4c 89 e7             	mov    %r12,%rdi
    9a9b:	e8 30 a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9aa0:	e9 cc d9 ff ff       	jmp    7471 <f0+0x261>
    9aa5:	4c 89 e7             	mov    %r12,%rdi
    9aa8:	e8 23 a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9aad:	e9 50 da ff ff       	jmp    7502 <f0+0x2f2>
    9ab2:	4c 89 e7             	mov    %r12,%rdi
    9ab5:	e8 16 a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9aba:	e9 d4 da ff ff       	jmp    7593 <f0+0x383>
    9abf:	4c 89 e7             	mov    %r12,%rdi
    9ac2:	e8 09 a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ac7:	e9 6d e8 ff ff       	jmp    8339 <f0+0x1129>
    9acc:	4c 89 e7             	mov    %r12,%rdi
    9acf:	e8 fc a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ad4:	e9 fa e8 ff ff       	jmp    83d3 <f0+0x11c3>
    9ad9:	4c 89 e7             	mov    %r12,%rdi
    9adc:	e8 ef a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ae1:	e9 87 e9 ff ff       	jmp    846d <f0+0x125d>
    9ae6:	4c 89 e7             	mov    %r12,%rdi
    9ae9:	e8 e2 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9aee:	e9 14 ea ff ff       	jmp    8507 <f0+0x12f7>
    9af3:	4c 89 e7             	mov    %r12,%rdi
    9af6:	e8 d5 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9afb:	e9 a1 ea ff ff       	jmp    85a1 <f0+0x1391>
    9b00:	4c 89 e7             	mov    %r12,%rdi
    9b03:	e8 c8 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b08:	e9 2e eb ff ff       	jmp    863b <f0+0x142b>
    9b0d:	4c 89 e7             	mov    %r12,%rdi
    9b10:	e8 bb a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b15:	e9 bb eb ff ff       	jmp    86d5 <f0+0x14c5>
    9b1a:	4c 89 e7             	mov    %r12,%rdi
    9b1d:	e8 ae a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b22:	e9 48 ec ff ff       	jmp    876f <f0+0x155f>
    9b27:	4c 89 e7             	mov    %r12,%rdi
    9b2a:	e8 a1 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b2f:	e9 d5 ec ff ff       	jmp    8809 <f0+0x15f9>
    9b34:	4c 89 e7             	mov    %r12,%rdi
    9b37:	e8 94 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b3c:	e9 62 ed ff ff       	jmp    88a3 <f0+0x1693>
    9b41:	4c 89 e7             	mov    %r12,%rdi
    9b44:	e8 87 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b49:	e9 ef ed ff ff       	jmp    893d <f0+0x172d>
    9b4e:	4c 89 e7             	mov    %r12,%rdi
    9b51:	e8 7a a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b56:	e9 7c ee ff ff       	jmp    89d7 <f0+0x17c7>
    9b5b:	4c 89 e7             	mov    %r12,%rdi
    9b5e:	e8 6d a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b63:	e9 09 ef ff ff       	jmp    8a71 <f0+0x1861>
    9b68:	4c 89 e7             	mov    %r12,%rdi
    9b6b:	e8 60 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b70:	e9 96 ef ff ff       	jmp    8b0b <f0+0x18fb>
    9b75:	4c 89 e7             	mov    %r12,%rdi
    9b78:	e8 53 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b7d:	e9 23 f0 ff ff       	jmp    8ba5 <f0+0x1995>
    9b82:	4c 89 e7             	mov    %r12,%rdi
    9b85:	e8 46 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b8a:	e9 b0 f0 ff ff       	jmp    8c3f <f0+0x1a2f>
    9b8f:	4c 89 e7             	mov    %r12,%rdi
    9b92:	e8 39 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b97:	e9 3d f1 ff ff       	jmp    8cd9 <f0+0x1ac9>
    9b9c:	4c 89 e7             	mov    %r12,%rdi
    9b9f:	e8 2c a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ba4:	e9 ca f1 ff ff       	jmp    8d73 <f0+0x1b63>
    9ba9:	4c 89 e7             	mov    %r12,%rdi
    9bac:	e8 1f a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bb1:	e9 57 f2 ff ff       	jmp    8e0d <f0+0x1bfd>
    9bb6:	4c 89 e7             	mov    %r12,%rdi
    9bb9:	e8 12 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bbe:	e9 e4 f2 ff ff       	jmp    8ea7 <f0+0x1c97>
    9bc3:	4c 89 e7             	mov    %r12,%rdi
    9bc6:	e8 05 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bcb:	e9 71 f3 ff ff       	jmp    8f41 <f0+0x1d31>
    9bd0:	4c 89 e7             	mov    %r12,%rdi
    9bd3:	e8 f8 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bd8:	e9 fe f3 ff ff       	jmp    8fdb <f0+0x1dcb>
    9bdd:	4c 89 e7             	mov    %r12,%rdi
    9be0:	e8 eb a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9be5:	e9 8b f4 ff ff       	jmp    9075 <f0+0x1e65>
    9bea:	4c 89 e7             	mov    %r12,%rdi
    9bed:	e8 de a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bf2:	e9 18 f5 ff ff       	jmp    910f <f0+0x1eff>
    9bf7:	4c 89 e7             	mov    %r12,%rdi
    9bfa:	e8 d1 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bff:	e9 a5 f5 ff ff       	jmp    91a9 <f0+0x1f99>
    9c04:	4c 89 e7             	mov    %r12,%rdi
    9c07:	e8 c4 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c0c:	e9 32 f6 ff ff       	jmp    9243 <f0+0x2033>
    9c11:	4c 89 e7             	mov    %r12,%rdi
    9c14:	e8 b7 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c19:	e9 bf f6 ff ff       	jmp    92dd <f0+0x20cd>
    9c1e:	4c 89 e7             	mov    %r12,%rdi
    9c21:	e8 aa a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c26:	e9 4c f7 ff ff       	jmp    9377 <f0+0x2167>
    9c2b:	4c 89 e7             	mov    %r12,%rdi
    9c2e:	e8 9d a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c33:	e9 d9 f7 ff ff       	jmp    9411 <f0+0x2201>
    9c38:	4c 89 e7             	mov    %r12,%rdi
    9c3b:	e8 90 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c40:	e9 66 f8 ff ff       	jmp    94ab <f0+0x229b>
    9c45:	4c 89 e7             	mov    %r12,%rdi
    9c48:	e8 83 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c4d:	e9 f3 f8 ff ff       	jmp    9545 <f0+0x2335>
    9c52:	4c 89 e7             	mov    %r12,%rdi
    9c55:	e8 76 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c5a:	e9 80 f9 ff ff       	jmp    95df <f0+0x23cf>
    9c5f:	4c 89 e7             	mov    %r12,%rdi
    9c62:	e8 69 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c67:	e9 0d fa ff ff       	jmp    9679 <f0+0x2469>
    9c6c:	4c 89 e7             	mov    %r12,%rdi
    9c6f:	e8 5c a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c74:	e9 9a fa ff ff       	jmp    9713 <f0+0x2503>
    9c79:	e8 c2 87 ff ff       	call   2440 <__stack_chk_fail@plt>
    9c7e:	66 90                	xchg   %ax,%ax

0000000000009c80 <fwp_main_thread>:
    9c80:	f3 0f 1e fa          	endbr64
    9c84:	41 54                	push   %r12
    9c86:	55                   	push   %rbp
    9c87:	53                   	push   %rbx
    9c88:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    9c8f:	8b 0d 4f 5e 01 00    	mov    0x15e4f(%rip),%ecx        # 1fae4 <fwp_heap+0x13a4>
    9c95:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9c9c:	00 00 
    9c9e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    9ca5:	00 
    9ca6:	31 c0                	xor    %eax,%eax
    9ca8:	85 c9                	test   %ecx,%ecx
    9caa:	0f 84 18 07 00 00    	je     a3c8 <fwp_main_thread+0x748>
    9cb0:	8b 15 32 5e 01 00    	mov    0x15e32(%rip),%edx        # 1fae8 <fwp_heap+0x13a8>
    9cb6:	85 d2                	test   %edx,%edx
    9cb8:	0f 85 f2 06 00 00    	jne    a3b0 <fwp_main_thread+0x730>
    9cbe:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    9cc3:	31 f6                	xor    %esi,%esi
    9cc5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    9cca:	48 c7 05 fb 43 01 00 	movq   $0x40000000,0x143fb(%rip)        # 1e0d0 <fwp_main_stack_size>
    9cd1:	00 00 00 40 
    9cd5:	48 89 05 fc 43 01 00 	mov    %rax,0x143fc(%rip)        # 1e0d8 <fwp_main_stack_top>
    9cdc:	48 8d 05 dd 43 00 00 	lea    0x43dd(%rip),%rax        # e0c0 <alt.4>
    9ce3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9ce8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    9cef:	01 00 
    9cf1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    9cf8:	00 
    9cf9:	e8 82 89 ff ff       	call   2680 <sigaltstack@plt>
    9cfe:	85 c0                	test   %eax,%eax
    9d00:	0f 85 03 07 00 00    	jne    a409 <fwp_main_thread+0x789>
    9d06:	31 c0                	xor    %eax,%eax
    9d08:	b9 12 00 00 00       	mov    $0x12,%ecx
    9d0d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9d12:	f3 48 ab             	rep stos %rax,(%rdi)
    9d15:	48 8d 05 e4 8e ff ff 	lea    -0x711c(%rip),%rax        # 2c00 <fwp_segv>
    9d1c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9d21:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    9d28:	04 00 00 08 
    9d2c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9d31:	e8 1a 88 ff ff       	call   2550 <sigemptyset@plt>
    9d36:	85 c0                	test   %eax,%eax
    9d38:	0f 85 cb 06 00 00    	jne    a409 <fwp_main_thread+0x789>
    9d3e:	31 d2                	xor    %edx,%edx
    9d40:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9d45:	bf 0b 00 00 00       	mov    $0xb,%edi
    9d4a:	e8 91 86 ff ff       	call   23e0 <sigaction@plt>
    9d4f:	85 c0                	test   %eax,%eax
    9d51:	0f 85 b2 06 00 00    	jne    a409 <fwp_main_thread+0x789>
    9d57:	31 d2                	xor    %edx,%edx
    9d59:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9d5e:	bf 07 00 00 00       	mov    $0x7,%edi
    9d63:	e8 78 86 ff ff       	call   23e0 <sigaction@plt>
    9d68:	85 c0                	test   %eax,%eax
    9d6a:	0f 85 99 06 00 00    	jne    a409 <fwp_main_thread+0x789>
    9d70:	48 8b 05 e9 5d 01 00 	mov    0x15de9(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    9d77:	48 85 c0             	test   %rax,%rax
    9d7a:	0f 88 10 06 00 00    	js     a390 <fwp_main_thread+0x710>
    9d80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d84:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9d89:	48 8d 3d 50 93 ff ff 	lea    -0x6cb0(%rip),%rdi        # 30e0 <ad_raw_report>
    9d90:	f2 0f 11 05 48 66 01 	movsd  %xmm0,0x16648(%rip)        # 203e0 <iteration_start_charge>
    9d97:	00 
    9d98:	c7 05 5e 66 01 00 01 	movl   $0x1,0x1665e(%rip)        # 20400 <iteration_active>
    9d9f:	00 00 00 
    9da2:	e8 a9 08 00 00       	call   a650 <atexit>
    9da7:	85 c0                	test   %eax,%eax
    9da9:	0f 85 66 06 00 00    	jne    a415 <fwp_main_thread+0x795>
    9daf:	8b 05 f3 42 00 00    	mov    0x42f3(%rip),%eax        # e0a8 <st.2>
    9db5:	85 c0                	test   %eax,%eax
    9db7:	0f 84 1b 06 00 00    	je     a3d8 <fwp_main_thread+0x758>
    9dbd:	48 8b 2d 5c 49 01 00 	mov    0x1495c(%rip),%rbp        # 1e720 <fwp_cur>
    9dc4:	48 85 ed             	test   %rbp,%rbp
    9dc7:	0f 84 5f 01 00 00    	je     9f2c <fwp_main_thread+0x2ac>
    9dcd:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9dd2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9dd6:	48 89 eb             	mov    %rbp,%rbx
    9dd9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9dde:	0f 84 41 01 00 00    	je     9f25 <fwp_main_thread+0x2a5>
    9de4:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9de9:	0f 84 21 02 00 00    	je     a010 <fwp_main_thread+0x390>
    9def:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9df3:	0f 84 07 02 00 00    	je     a000 <fwp_main_thread+0x380>
    9df9:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9dfd:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9e01:	0f 85 89 02 00 00    	jne    a090 <fwp_main_thread+0x410>
    9e07:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9e0b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9e12:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9e16:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9e1d:	00 00 00 00 
    9e21:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9e28:	48 85 d2             	test   %rdx,%rdx
    9e2b:	74 07                	je     9e34 <fwp_main_thread+0x1b4>
    9e2d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9e34:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e38:	48 85 c0             	test   %rax,%rax
    9e3b:	74 34                	je     9e71 <fwp_main_thread+0x1f1>
    9e3d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9e41:	48 8b 05 b0 48 01 00 	mov    0x148b0(%rip),%rax        # 1e6f8 <fwp_timers>
    9e48:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9e4c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9e53:	00 00 00 00 
    9e57:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9e5e:	48 85 c0             	test   %rax,%rax
    9e61:	74 07                	je     9e6a <fwp_main_thread+0x1ea>
    9e63:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9e6a:	48 89 1d 87 48 01 00 	mov    %rbx,0x14887(%rip)        # 1e6f8 <fwp_timers>
    9e71:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9e75:	e8 b6 af ff ff       	call   4e30 <fwp_block>
    9e7a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9e81:	48 85 c9             	test   %rcx,%rcx
    9e84:	74 47                	je     9ecd <fwp_main_thread+0x24d>
    9e86:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9e8d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9e94:	48 85 d2             	test   %rdx,%rdx
    9e97:	0f 84 33 02 00 00    	je     a0d0 <fwp_main_thread+0x450>
    9e9d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9ea4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9eab:	48 85 c0             	test   %rax,%rax
    9eae:	74 07                	je     9eb7 <fwp_main_thread+0x237>
    9eb0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9eb7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9ebe:	00 00 00 00 
    9ec2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9ec6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9ecd:	48 8b 0d 4c 48 01 00 	mov    0x1484c(%rip),%rcx        # 1e720 <fwp_cur>
    9ed4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9ed8:	0f 84 a2 01 00 00    	je     a080 <fwp_main_thread+0x400>
    9ede:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9ee5:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9eec:	48 85 d2             	test   %rdx,%rdx
    9eef:	0f 84 db 03 00 00    	je     a2d0 <fwp_main_thread+0x650>
    9ef5:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9efc:	48 85 c0             	test   %rax,%rax
    9eff:	74 07                	je     9f08 <fwp_main_thread+0x288>
    9f01:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9f08:	66 0f ef db          	pxor   %xmm3,%xmm3
    9f0c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9f10:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9f17:	48 89 cb             	mov    %rcx,%rbx
    9f1a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9f1f:	0f 85 bf fe ff ff    	jne    9de4 <fwp_main_thread+0x164>
    9f25:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9f29:	48 89 dd             	mov    %rbx,%rbp
    9f2c:	48 83 3d 7c 64 01 00 	cmpq   $0x0,0x1647c(%rip)        # 203b0 <fwp_state_len>
    9f33:	00 
    9f34:	0f 84 a6 03 00 00    	je     a2e0 <fwp_main_thread+0x660>
    9f3a:	48 8b 15 d7 47 01 00 	mov    0x147d7(%rip),%rdx        # 1e718 <fwp_root>
    9f41:	c7 05 75 41 01 00 00 	movl   $0x0,0x14175(%rip)        # 1e0c0 <fwp_exit_code>
    9f48:	00 00 00 
    9f4b:	48 39 d5             	cmp    %rdx,%rbp
    9f4e:	0f 85 da 04 00 00    	jne    a42e <fwp_main_thread+0x7ae>
    9f54:	48 85 d2             	test   %rdx,%rdx
    9f57:	0f 84 83 01 00 00    	je     a0e0 <fwp_main_thread+0x460>
    9f5d:	48 8b 0d 84 47 01 00 	mov    0x14784(%rip),%rcx        # 1e6e8 <fwp_tasks_active>
    9f64:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    9f68:	48 85 c9             	test   %rcx,%rcx
    9f6b:	0f 84 6f 01 00 00    	je     a0e0 <fwp_main_thread+0x460>
    9f71:	0f 1f 40 00          	nopl   0x0(%rax)
    9f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f7c:	00 00 00 00 
    9f80:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    9f84:	75 08                	jne    9f8e <fwp_main_thread+0x30e>
    9f86:	48 89 cf             	mov    %rcx,%rdi
    9f89:	e8 62 90 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    9f8e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    9f95:	48 85 c9             	test   %rcx,%rcx
    9f98:	75 e6                	jne    9f80 <fwp_main_thread+0x300>
    9f9a:	eb 31                	jmp    9fcd <fwp_main_thread+0x34d>
    9f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9fa0:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    9fa7:	48 89 15 52 47 01 00 	mov    %rdx,0x14752(%rip)        # 1e700 <fwp_ready_tail>
    9fae:	e8 7d ae ff ff       	call   4e30 <fwp_block>
    9fb3:	e8 78 ac ff ff       	call   4c30 <fwp_free_zombie>
    9fb8:	48 83 3d 28 47 01 00 	cmpq   $0x0,0x14728(%rip)        # 1e6e8 <fwp_tasks_active>
    9fbf:	00 
    9fc0:	0f 84 1a 01 00 00    	je     a0e0 <fwp_main_thread+0x460>
    9fc6:	48 8b 15 4b 47 01 00 	mov    0x1474b(%rip),%rdx        # 1e718 <fwp_root>
    9fcd:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    9fd1:	75 db                	jne    9fae <fwp_main_thread+0x32e>
    9fd3:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9fd7:	75 d5                	jne    9fae <fwp_main_thread+0x32e>
    9fd9:	48 8b 05 20 47 01 00 	mov    0x14720(%rip),%rax        # 1e700 <fwp_ready_tail>
    9fe0:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    9fe4:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    9feb:	00 00 00 00 
    9fef:	48 85 c0             	test   %rax,%rax
    9ff2:	75 ac                	jne    9fa0 <fwp_main_thread+0x320>
    9ff4:	48 89 15 0d 47 01 00 	mov    %rdx,0x1470d(%rip)        # 1e708 <fwp_ready_head>
    9ffb:	eb aa                	jmp    9fa7 <fwp_main_thread+0x327>
    9ffd:	0f 1f 00             	nopl   (%rax)
    a000:	e8 2b 92 ff ff       	call   3230 <fwp_now_ns>
    a005:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a009:	0f 8d 41 03 00 00    	jge    a350 <fwp_main_thread+0x6d0>
    a00f:	90                   	nop
    a010:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a014:	0f 85 df fd ff ff    	jne    9df9 <fwp_main_thread+0x179>
    a01a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a01e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a022:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a026:	0f 85 df fd ff ff    	jne    9e0b <fwp_main_thread+0x18b>
    a02c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a030:	48 85 c9             	test   %rcx,%rcx
    a033:	0f 84 d2 fd ff ff    	je     9e0b <fwp_main_thread+0x18b>
    a039:	48 85 c0             	test   %rax,%rax
    a03c:	0f 84 df 03 00 00    	je     a421 <fwp_main_thread+0x7a1>
    a042:	48 39 c8             	cmp    %rcx,%rax
    a045:	48 0f 4f c1          	cmovg  %rcx,%rax
    a049:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a050:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a054:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a05b:	00 00 00 00 
    a05f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a066:	48 85 d2             	test   %rdx,%rdx
    a069:	74 07                	je     a072 <fwp_main_thread+0x3f2>
    a06b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a072:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a076:	e9 c2 fd ff ff       	jmp    9e3d <fwp_main_thread+0x1bd>
    a07b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a080:	48 89 cb             	mov    %rcx,%rbx
    a083:	e9 51 fd ff ff       	jmp    9dd9 <fwp_main_thread+0x159>
    a088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a08f:	00 
    a090:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a094:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a09b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a0a2:	00 00 00 00 
    a0a6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a0ad:	48 85 c0             	test   %rax,%rax
    a0b0:	0f 84 4a 03 00 00    	je     a400 <fwp_main_thread+0x780>
    a0b6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a0bd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a0c1:	e9 ab fd ff ff       	jmp    9e71 <fwp_main_thread+0x1f1>
    a0c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0cd:	00 00 00 
    a0d0:	48 89 01             	mov    %rax,(%rcx)
    a0d3:	e9 d3 fd ff ff       	jmp    9eab <fwp_main_thread+0x22b>
    a0d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0df:	00 
    a0e0:	e8 4b ab ff ff       	call   4c30 <fwp_free_zombie>
    a0e5:	48 83 3d 1b 46 01 00 	cmpq   $0x0,0x1461b(%rip)        # 1e708 <fwp_ready_head>
    a0ec:	00 
    a0ed:	0f 85 1d 86 ff ff    	jne    2710 <fwp_main_thread.cold>
    a0f3:	48 83 3d fd 45 01 00 	cmpq   $0x0,0x145fd(%rip)        # 1e6f8 <fwp_timers>
    a0fa:	00 
    a0fb:	0f 85 0f 86 ff ff    	jne    2710 <fwp_main_thread.cold>
    a101:	8b 1d dd 3f 01 00    	mov    0x13fdd(%rip),%ebx        # 1e0e4 <fwp_stack_pool_n>
    a107:	85 db                	test   %ebx,%ebx
    a109:	74 34                	je     a13f <fwp_main_thread+0x4bf>
    a10b:	83 eb 01             	sub    $0x1,%ebx
    a10e:	48 8d 05 eb 3f 01 00 	lea    0x13feb(%rip),%rax        # 1e100 <fwp_stack_pool>
    a115:	48 63 d3             	movslq %ebx,%rdx
    a118:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    a11c:	eb 05                	jmp    a123 <fwp_main_thread+0x4a3>
    a11e:	66 90                	xchg   %ax,%ax
    a120:	83 eb 01             	sub    $0x1,%ebx
    a123:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a127:	be 00 00 00 10       	mov    $0x10000000,%esi
    a12c:	89 1d b2 3f 01 00    	mov    %ebx,0x13fb2(%rip)        # 1e0e4 <fwp_stack_pool_n>
    a132:	48 83 ed 08          	sub    $0x8,%rbp
    a136:	e8 75 84 ff ff       	call   25b0 <munmap@plt>
    a13b:	85 db                	test   %ebx,%ebx
    a13d:	75 e1                	jne    a120 <fwp_main_thread+0x4a0>
    a13f:	8b 3d 0b 3f 00 00    	mov    0x3f0b(%rip),%edi        # e050 <fwp_epfd>
    a145:	85 ff                	test   %edi,%edi
    a147:	78 05                	js     a14e <fwp_main_thread+0x4ce>
    a149:	e8 62 83 ff ff       	call   24b0 <close@plt>
    a14e:	4c 8b 25 ab 41 01 00 	mov    0x141ab(%rip),%r12        # 1e300 <fwp_nfdws>
    a155:	48 8b 2d ac 41 01 00 	mov    0x141ac(%rip),%rbp        # 1e308 <fwp_fdws>
    a15c:	31 db                	xor    %ebx,%ebx
    a15e:	c7 05 e8 3e 00 00 ff 	movl   $0xffffffff,0x3ee8(%rip)        # e050 <fwp_epfd>
    a165:	ff ff ff 
    a168:	4d 85 e4             	test   %r12,%r12
    a16b:	74 30                	je     a19d <fwp_main_thread+0x51d>
    a16d:	0f 1f 00             	nopl   (%rax)
    a170:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    a175:	48 85 ff             	test   %rdi,%rdi
    a178:	74 1a                	je     a194 <fwp_main_thread+0x514>
    a17a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    a17e:	0f 85 8c 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a184:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    a189:	0f 85 81 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a18f:	e8 7c 9f ff ff       	call   4110 <fwp_mem_free>
    a194:	48 83 c3 01          	add    $0x1,%rbx
    a198:	49 39 dc             	cmp    %rbx,%r12
    a19b:	75 d3                	jne    a170 <fwp_main_thread+0x4f0>
    a19d:	48 89 ef             	mov    %rbp,%rdi
    a1a0:	e8 6b 9f ff ff       	call   4110 <fwp_mem_free>
    a1a5:	48 8b 15 6c 45 01 00 	mov    0x1456c(%rip),%rdx        # 1e718 <fwp_root>
    a1ac:	48 c7 05 51 41 01 00 	movq   $0x0,0x14151(%rip)        # 1e308 <fwp_fdws>
    a1b3:	00 00 00 00 
    a1b7:	48 c7 05 3e 41 01 00 	movq   $0x0,0x1413e(%rip)        # 1e300 <fwp_nfdws>
    a1be:	00 00 00 00 
    a1c2:	48 85 d2             	test   %rdx,%rdx
    a1c5:	74 4e                	je     a215 <fwp_main_thread+0x595>
    a1c7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    a1cc:	0f 85 3e 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1d2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    a1d9:	00 
    a1da:	0f 85 30 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1e0:	48 83 3d c8 61 01 00 	cmpq   $0x0,0x161c8(%rip)        # 203b0 <fwp_state_len>
    a1e7:	00 
    a1e8:	0f 85 22 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1ee:	48 83 3d aa 61 01 00 	cmpq   $0x0,0x161aa(%rip)        # 203a0 <fwp_state_owners>
    a1f5:	00 
    a1f6:	0f 85 14 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1fc:	b9 79 00 00 00       	mov    $0x79,%ecx
    a201:	31 c0                	xor    %eax,%eax
    a203:	48 8d 3d 16 41 01 00 	lea    0x14116(%rip),%rdi        # 1e320 <fwp_root_context>
    a20a:	f3 48 ab             	rep stos %rax,(%rdi)
    a20d:	48 89 d7             	mov    %rdx,%rdi
    a210:	e8 fb 9e ff ff       	call   4110 <fwp_mem_free>
    a215:	48 8b 05 44 59 01 00 	mov    0x15944(%rip),%rax        # 1fb60 <fwp_heap+0x1420>
    a21c:	48 c7 05 f9 44 01 00 	movq   $0x0,0x144f9(%rip)        # 1e720 <fwp_cur>
    a223:	00 00 00 00 
    a227:	48 c7 05 e6 44 01 00 	movq   $0x0,0x144e6(%rip)        # 1e718 <fwp_root>
    a22e:	00 00 00 00 
    a232:	48 c7 05 8b 3e 01 00 	movq   $0x0,0x13e8b(%rip)        # 1e0c8 <ad_raw_before_shutdown>
    a239:	00 00 00 00 
    a23d:	c7 05 b9 61 01 00 00 	movl   $0x0,0x161b9(%rip)        # 20400 <iteration_active>
    a244:	00 00 00 
    a247:	48 85 c0             	test   %rax,%rax
    a24a:	0f 88 20 01 00 00    	js     a370 <fwp_main_thread+0x6f0>
    a250:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a254:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    a259:	f2 0f 5c 0d 7f 61 01 	subsd  0x1617f(%rip),%xmm1        # 203e0 <iteration_start_charge>
    a260:	00 
    a261:	48 8b 3d 18 3e 00 00 	mov    0x3e18(%rip),%rdi        # e080 <stderr@GLIBC_2.2.5>
    a268:	48 8d 15 d1 11 00 00 	lea    0x11d1(%rip),%rdx        # b440 <_IO_stdin_used+0x440>
    a26f:	be 02 00 00 00       	mov    $0x2,%esi
    a274:	f2 0f 10 05 5c 61 01 	movsd  0x1615c(%rip),%xmm0        # 203d8 <iteration_peak>
    a27b:	00 
    a27c:	4c 8b 0d 65 61 01 00 	mov    0x16165(%rip),%r9        # 203e8 <iteration_retains>
    a283:	b8 02 00 00 00       	mov    $0x2,%eax
    a288:	4c 8b 05 61 61 01 00 	mov    0x16161(%rip),%r8        # 203f0 <iteration_bytes>
    a28f:	48 8b 0d 62 61 01 00 	mov    0x16162(%rip),%rcx        # 203f8 <iteration_requests>
    a296:	e8 b5 83 ff ff       	call   2650 <__fprintf_chk@plt>
    a29b:	48 8b 3d be 3d 00 00 	mov    0x3dbe(%rip),%rdi        # e060 <stdout@GLIBC_2.2.5>
    a2a2:	e8 e9 82 ff ff       	call   2590 <fflush@plt>
    a2a7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    a2ae:	00 
    a2af:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2b6:	00 00 
    a2b8:	0f 85 6b 01 00 00    	jne    a429 <fwp_main_thread+0x7a9>
    a2be:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    a2c5:	31 c0                	xor    %eax,%eax
    a2c7:	5b                   	pop    %rbx
    a2c8:	5d                   	pop    %rbp
    a2c9:	41 5c                	pop    %r12
    a2cb:	c3                   	ret
    a2cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a2d0:	48 89 05 21 44 01 00 	mov    %rax,0x14421(%rip)        # 1e6f8 <fwp_timers>
    a2d7:	e9 20 fc ff ff       	jmp    9efc <fwp_main_thread+0x27c>
    a2dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a2e0:	48 83 3d b8 60 01 00 	cmpq   $0x0,0x160b8(%rip)        # 203a0 <fwp_state_owners>
    a2e7:	00 
    a2e8:	0f 85 4c fc ff ff    	jne    9f3a <fwp_main_thread+0x2ba>
    a2ee:	48 8b 3d c3 60 01 00 	mov    0x160c3(%rip),%rdi        # 203b8 <fwp_state>
    a2f5:	e8 16 9e ff ff       	call   4110 <fwp_mem_free>
    a2fa:	48 c7 05 b3 60 01 00 	movq   $0x0,0x160b3(%rip)        # 203b8 <fwp_state>
    a301:	00 00 00 00 
    a305:	48 c7 05 98 60 01 00 	movq   $0x0,0x16098(%rip)        # 203a8 <fwp_state_cap>
    a30c:	00 00 00 00 
    a310:	48 85 ed             	test   %rbp,%rbp
    a313:	0f 84 21 fc ff ff    	je     9f3a <fwp_main_thread+0x2ba>
    a319:	48 8b 15 f8 43 01 00 	mov    0x143f8(%rip),%rdx        # 1e718 <fwp_root>
    a320:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    a327:	00 00 00 00 
    a32b:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    a332:	00 00 00 00 
    a336:	c7 05 80 3d 01 00 00 	movl   $0x0,0x13d80(%rip)        # 1e0c0 <fwp_exit_code>
    a33d:	00 00 00 
    a340:	48 39 d5             	cmp    %rdx,%rbp
    a343:	0f 84 14 fc ff ff    	je     9f5d <fwp_main_thread+0x2dd>
    a349:	e9 c2 83 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a34e:	66 90                	xchg   %ax,%ax
    a350:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a354:	0f 85 b6 fc ff ff    	jne    a010 <fwp_main_thread+0x390>
    a35a:	48 89 ef             	mov    %rbp,%rdi
    a35d:	e8 8e 8c ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    a362:	e9 a9 fc ff ff       	jmp    a010 <fwp_main_thread+0x390>
    a367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a36e:	00 00 
    a370:	48 89 c2             	mov    %rax,%rdx
    a373:	83 e0 01             	and    $0x1,%eax
    a376:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a37a:	48 d1 ea             	shr    $1,%rdx
    a37d:	48 09 c2             	or     %rax,%rdx
    a380:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    a385:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    a389:	e9 cb fe ff ff       	jmp    a259 <fwp_main_thread+0x5d9>
    a38e:	66 90                	xchg   %ax,%ax
    a390:	48 89 c2             	mov    %rax,%rdx
    a393:	83 e0 01             	and    $0x1,%eax
    a396:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a39a:	48 d1 ea             	shr    $1,%rdx
    a39d:	48 09 c2             	or     %rax,%rdx
    a3a0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    a3a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    a3a9:	e9 db f9 ff ff       	jmp    9d89 <fwp_main_thread+0x109>
    a3ae:	66 90                	xchg   %ax,%ax
    a3b0:	48 8d 3d 69 94 ff ff 	lea    -0x6b97(%rip),%rdi        # 3820 <fwp_heap_report>
    a3b7:	e8 94 02 00 00       	call   a650 <atexit>
    a3bc:	e9 fd f8 ff ff       	jmp    9cbe <fwp_main_thread+0x3e>
    a3c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3c8:	e8 63 95 ff ff       	call   3930 <fwp_heap_init>
    a3cd:	e9 de f8 ff ff       	jmp    9cb0 <fwp_main_thread+0x30>
    a3d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3d8:	e8 33 ce ff ff       	call   7210 <f0>
    a3dd:	48 c7 05 b8 3c 00 00 	movq   $0x0,0x3cb8(%rip)        # e0a0 <v.1>
    a3e4:	00 00 00 00 
    a3e8:	c7 05 b6 3c 00 00 01 	movl   $0x1,0x3cb6(%rip)        # e0a8 <st.2>
    a3ef:	00 00 00 
    a3f2:	e9 c6 f9 ff ff       	jmp    9dbd <fwp_main_thread+0x13d>
    a3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3fe:	00 00 
    a400:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a404:	e9 68 fa ff ff       	jmp    9e71 <fwp_main_thread+0x1f1>
    a409:	48 8d 3d 08 10 00 00 	lea    0x1008(%rip),%rdi        # b418 <_IO_stdin_used+0x418>
    a410:	e8 eb 8d ff ff       	call   3200 <fwp_trap>
    a415:	48 8d 3d 92 0d 00 00 	lea    0xd92(%rip),%rdi        # b1ae <_IO_stdin_used+0x1ae>
    a41c:	e8 9f 8a ff ff       	call   2ec0 <ad_raw_fail>
    a421:	48 89 c8             	mov    %rcx,%rax
    a424:	e9 20 fc ff ff       	jmp    a049 <fwp_main_thread+0x3c9>
    a429:	e8 12 80 ff ff       	call   2440 <__stack_chk_fail@plt>
    a42e:	e9 dd 82 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a433:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a43a:	00 00 00 
    a43d:	0f 1f 00             	nopl   (%rax)

000000000000a440 <__divmodti4>:
    a440:	f3 0f 1e fa          	endbr64
    a444:	55                   	push   %rbp
    a445:	49 89 f1             	mov    %rsi,%r9
    a448:	49 89 d2             	mov    %rdx,%r10
    a44b:	48 89 fe             	mov    %rdi,%rsi
    a44e:	49 89 cb             	mov    %rcx,%r11
    a451:	48 89 e5             	mov    %rsp,%rbp
    a454:	41 57                	push   %r15
    a456:	41 56                	push   %r14
    a458:	41 55                	push   %r13
    a45a:	41 54                	push   %r12
    a45c:	53                   	push   %rbx
    a45d:	4c 89 c3             	mov    %r8,%rbx
    a460:	45 31 c0             	xor    %r8d,%r8d
    a463:	4d 85 c9             	test   %r9,%r9
    a466:	79 12                	jns    a47a <__divmodti4+0x3a>
    a468:	31 ff                	xor    %edi,%edi
    a46a:	48 f7 de             	neg    %rsi
    a46d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a474:	4c 19 cf             	sbb    %r9,%rdi
    a477:	49 89 f9             	mov    %rdi,%r9
    a47a:	4c 89 d8             	mov    %r11,%rax
    a47d:	4d 85 db             	test   %r11,%r11
    a480:	0f 88 1a 01 00 00    	js     a5a0 <__divmodti4+0x160>
    a486:	4c 89 d9             	mov    %r11,%rcx
    a489:	49 89 f3             	mov    %rsi,%r11
    a48c:	75 62                	jne    a4f0 <__divmodti4+0xb0>
    a48e:	4d 89 c4             	mov    %r8,%r12
    a491:	4d 39 d1             	cmp    %r10,%r9
    a494:	0f 83 46 01 00 00    	jae    a5e0 <__divmodti4+0x1a0>
    a49a:	4c 89 d8             	mov    %r11,%rax
    a49d:	4c 89 ca             	mov    %r9,%rdx
    a4a0:	49 f7 f2             	div    %r10
    a4a3:	49 89 c3             	mov    %rax,%r11
    a4a6:	31 c0                	xor    %eax,%eax
    a4a8:	48 89 d6             	mov    %rdx,%rsi
    a4ab:	31 ff                	xor    %edi,%edi
    a4ad:	4c 89 d9             	mov    %r11,%rcx
    a4b0:	48 89 c2             	mov    %rax,%rdx
    a4b3:	48 89 c8             	mov    %rcx,%rax
    a4b6:	4d 85 e4             	test   %r12,%r12
    a4b9:	74 0a                	je     a4c5 <__divmodti4+0x85>
    a4bb:	48 f7 d8             	neg    %rax
    a4be:	48 83 d2 00          	adc    $0x0,%rdx
    a4c2:	48 f7 da             	neg    %rdx
    a4c5:	4d 85 c0             	test   %r8,%r8
    a4c8:	74 0a                	je     a4d4 <__divmodti4+0x94>
    a4ca:	48 f7 de             	neg    %rsi
    a4cd:	48 83 d7 00          	adc    $0x0,%rdi
    a4d1:	48 f7 df             	neg    %rdi
    a4d4:	48 89 33             	mov    %rsi,(%rbx)
    a4d7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a4db:	5b                   	pop    %rbx
    a4dc:	41 5c                	pop    %r12
    a4de:	41 5d                	pop    %r13
    a4e0:	41 5e                	pop    %r14
    a4e2:	41 5f                	pop    %r15
    a4e4:	5d                   	pop    %rbp
    a4e5:	c3                   	ret
    a4e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a4ed:	00 00 00 
    a4f0:	4d 89 c4             	mov    %r8,%r12
    a4f3:	49 39 c1             	cmp    %rax,%r9
    a4f6:	0f 82 ce 00 00 00    	jb     a5ca <__divmodti4+0x18a>
    a4fc:	31 ff                	xor    %edi,%edi
    a4fe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a503:	48 63 c7             	movslq %edi,%rax
    a506:	be 40 00 00 00       	mov    $0x40,%esi
    a50b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a510:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a515:	48 29 c6             	sub    %rax,%rsi
    a518:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a51d:	48 09 c8             	or     %rcx,%rax
    a520:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a525:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a52a:	49 89 c6             	mov    %rax,%r14
    a52d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a531:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a536:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a53b:	49 09 c1             	or     %rax,%r9
    a53e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a542:	4c 89 c8             	mov    %r9,%rax
    a545:	49 f7 f6             	div    %r14
    a548:	48 89 d1             	mov    %rdx,%rcx
    a54b:	49 89 c3             	mov    %rax,%r11
    a54e:	49 89 c1             	mov    %rax,%r9
    a551:	49 f7 e2             	mul    %r10
    a554:	49 89 c6             	mov    %rax,%r14
    a557:	49 89 d2             	mov    %rdx,%r10
    a55a:	48 39 d1             	cmp    %rdx,%rcx
    a55d:	72 07                	jb     a566 <__divmodti4+0x126>
    a55f:	75 17                	jne    a578 <__divmodti4+0x138>
    a561:	49 39 c7             	cmp    %rax,%r15
    a564:	73 12                	jae    a578 <__divmodti4+0x138>
    a566:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a56a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a56e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a572:	49 89 d2             	mov    %rdx,%r10
    a575:	49 89 c6             	mov    %rax,%r14
    a578:	4c 89 f8             	mov    %r15,%rax
    a57b:	4c 29 f0             	sub    %r14,%rax
    a57e:	4c 19 d1             	sbb    %r10,%rcx
    a581:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a586:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a58b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a590:	48 09 c6             	or     %rax,%rsi
    a593:	48 89 cf             	mov    %rcx,%rdi
    a596:	31 c0                	xor    %eax,%eax
    a598:	4c 89 c9             	mov    %r9,%rcx
    a59b:	e9 10 ff ff ff       	jmp    a4b0 <__divmodti4+0x70>
    a5a0:	4c 89 d0             	mov    %r10,%rax
    a5a3:	4c 89 da             	mov    %r11,%rdx
    a5a6:	4d 89 c4             	mov    %r8,%r12
    a5a9:	49 89 f3             	mov    %rsi,%r11
    a5ac:	48 f7 d8             	neg    %rax
    a5af:	49 f7 d4             	not    %r12
    a5b2:	48 83 d2 00          	adc    $0x0,%rdx
    a5b6:	49 89 c2             	mov    %rax,%r10
    a5b9:	48 f7 da             	neg    %rdx
    a5bc:	48 89 d1             	mov    %rdx,%rcx
    a5bf:	0f 84 cc fe ff ff    	je     a491 <__divmodti4+0x51>
    a5c5:	49 39 d1             	cmp    %rdx,%r9
    a5c8:	73 46                	jae    a610 <__divmodti4+0x1d0>
    a5ca:	4c 89 cf             	mov    %r9,%rdi
    a5cd:	31 c0                	xor    %eax,%eax
    a5cf:	31 c9                	xor    %ecx,%ecx
    a5d1:	e9 da fe ff ff       	jmp    a4b0 <__divmodti4+0x70>
    a5d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5dd:	00 00 00 
    a5e0:	4d 85 d2             	test   %r10,%r10
    a5e3:	75 0d                	jne    a5f2 <__divmodti4+0x1b2>
    a5e5:	b8 01 00 00 00       	mov    $0x1,%eax
    a5ea:	31 d2                	xor    %edx,%edx
    a5ec:	49 f7 f2             	div    %r10
    a5ef:	49 89 c2             	mov    %rax,%r10
    a5f2:	4c 89 c8             	mov    %r9,%rax
    a5f5:	31 d2                	xor    %edx,%edx
    a5f7:	49 f7 f2             	div    %r10
    a5fa:	49 89 c1             	mov    %rax,%r9
    a5fd:	4c 89 d8             	mov    %r11,%rax
    a600:	49 f7 f2             	div    %r10
    a603:	49 89 c3             	mov    %rax,%r11
    a606:	4c 89 c8             	mov    %r9,%rax
    a609:	e9 9a fe ff ff       	jmp    a4a8 <__divmodti4+0x68>
    a60e:	66 90                	xchg   %ax,%ax
    a610:	45 31 f6             	xor    %r14d,%r14d
    a613:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a618:	44 89 f7             	mov    %r14d,%edi
    a61b:	45 85 f6             	test   %r14d,%r14d
    a61e:	0f 85 df fe ff ff    	jne    a503 <__divmodti4+0xc3>
    a624:	4c 39 ca             	cmp    %r9,%rdx
    a627:	72 17                	jb     a640 <__divmodti4+0x200>
    a629:	31 c9                	xor    %ecx,%ecx
    a62b:	48 39 c6             	cmp    %rax,%rsi
    a62e:	73 10                	jae    a640 <__divmodti4+0x200>
    a630:	4c 89 cf             	mov    %r9,%rdi
    a633:	31 c0                	xor    %eax,%eax
    a635:	e9 76 fe ff ff       	jmp    a4b0 <__divmodti4+0x70>
    a63a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a640:	4c 89 de             	mov    %r11,%rsi
    a643:	b9 01 00 00 00       	mov    $0x1,%ecx
    a648:	48 29 c6             	sub    %rax,%rsi
    a64b:	49 19 d1             	sbb    %rdx,%r9
    a64e:	eb e0                	jmp    a630 <__divmodti4+0x1f0>

000000000000a650 <atexit>:
    a650:	f3 0f 1e fa          	endbr64
    a654:	48 8b 15 ad 39 00 00 	mov    0x39ad(%rip),%rdx        # e008 <__dso_handle>
    a65b:	31 f6                	xor    %esi,%esi
    a65d:	e9 be 7f ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a664 <_fini>:
    a664:	f3 0f 1e fa          	endbr64
    a668:	48 83 ec 08          	sub    $0x8,%rsp
    a66c:	48 83 c4 08          	add    $0x8,%rsp
    a670:	c3                   	ret
