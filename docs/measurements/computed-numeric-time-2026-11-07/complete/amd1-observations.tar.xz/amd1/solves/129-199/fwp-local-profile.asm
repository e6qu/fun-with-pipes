
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 c9 bf 00 00 	mov    0xbfc9(%rip),%rax        # dfd8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # de18 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # de20 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 6e bc 00 00    	jmp    *0xbc6e(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 9e ba 00 00    	jmp    *0xba9e(%rip)        # de28 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 96 ba 00 00    	jmp    *0xba96(%rip)        # de30 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # de38 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # de40 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # de48 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # de50 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # de58 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # de60 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # de68 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # de70 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # de78 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # de80 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # de88 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # de90 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # de98 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # dea0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # dea8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # deb0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # deb8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # dec0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # dec8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ded0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ded8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # dee0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # dee8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # def0 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # def8 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # df00 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # df08 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # df10 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # df18 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # df20 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # df28 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # df30 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # df38 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # df40 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # df48 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # df50 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # df58 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # df60 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # df68 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # df70 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # df78 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # df80 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # df88 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # df90 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # df98 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # dfa0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # dfa8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # dfb0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # dfb8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # dfc0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 89 00 00 	lea    0x89e0(%rip),%r9        # b0b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 89 00 00 	lea    0x89dd(%rip),%r8        # b0bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 fa 0a 00 00       	call   3200 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 41 b9 00 00 	mov    0xb941(%rip),%rax        # e080 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 72 dc 01 00 	mov    %rax,0x1dc72(%rip)        # 203b8 <fwp_prog_out>
    2746:	e8 e5 0a 00 00       	call   3230 <fwp_now_ns>
    274b:	48 8d 3d 77 8a 00 00 	lea    0x8a77(%rip),%rdi        # b1c9 <_IO_stdin_used+0x1c9>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d c6 b8 00 00 	mov    0xb8c6(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # 9cb0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 31 b8 00 00 	mov    0xb831(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 86 b8 01 00    	mov    0x1b886(%rip),%eax        # 1e0e0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 27 89 00 00 	lea    0x8927(%rip),%rdi        # b1d2 <_IO_stdin_used+0x1d2>
    28ab:	e8 50 09 00 00       	call   3200 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 74 8c 00 00 	lea    0x8c74(%rip),%rdi        # b530 <_IO_stdin_used+0x530>
    28bc:	e8 3f 09 00 00       	call   3200 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d 2e 8c 00 00 	lea    0x8c2e(%rip),%rdi        # b508 <_IO_stdin_used+0x508>
    28da:	e8 21 09 00 00       	call   3200 <fwp_trap>
    28df:	48 8d 3d f2 8b 00 00 	lea    0x8bf2(%rip),%rdi        # b4d8 <_IO_stdin_used+0x4d8>
    28e6:	e8 15 09 00 00       	call   3200 <fwp_trap>
    28eb:	48 8d 3d be 8b 00 00 	lea    0x8bbe(%rip),%rdi        # b4b0 <_IO_stdin_used+0x4b0>
    28f2:	e8 09 09 00 00       	call   3200 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 a3 b6 00 00    	call   *0xb6a3(%rip)        # dfc8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 31 b7 00 00 	lea    0xb731(%rip),%rdi        # e068 <__TMC_END__>
    2937:	48 8d 05 2a b7 00 00 	lea    0xb72a(%rip),%rax        # e068 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 86 b6 00 00 	mov    0xb686(%rip),%rax        # dfd0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d 01 b7 00 00 	lea    0xb701(%rip),%rdi        # e068 <__TMC_END__>
    2967:	48 8d 35 fa b6 00 00 	lea    0xb6fa(%rip),%rsi        # e068 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 55 b6 00 00 	mov    0xb655(%rip),%rax        # dfe0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d fd b6 00 00 00 	cmpb   $0x0,0xb6fd(%rip)        # e0a8 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 32 b6 00 00 	cmpq   $0x0,0xb632(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 b6 00 00 	mov    0xb646(%rip),%rdi        # e008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 d5 b6 00 00 01 	movb   $0x1,0xb6d5(%rip)        # e0a8 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d f1 d7 01 00 	mov    0x1d7f1(%rip),%rdi        # 203b8 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d a4 b4 00 00 	mov    0xb4a4(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 91 b4 00 00 	mov    0xb491(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_segv>:
    2c00:	f3 0f 1e fa          	endbr64
    2c04:	48 83 ec 28          	sub    $0x28,%rsp
    2c08:	48 8b 05 31 bb 01 00 	mov    0x1bb31(%rip),%rax        # 1e740 <fwp_cur>
    2c0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c13:	41 89 f8             	mov    %edi,%r8d
    2c16:	48 85 c0             	test   %rax,%rax
    2c19:	74 6d                	je     2c88 <fwp_segv+0x88>
    2c1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c1f:	48 85 d2             	test   %rdx,%rdx
    2c22:	74 64                	je     2c88 <fwp_segv+0x88>
    2c24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c37:	e8 c4 f9 ff ff       	call   2600 <sysconf@plt>
    2c3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c4b:	48 01 d0             	add    %rdx,%rax
    2c4e:	48 39 c1             	cmp    %rax,%rcx
    2c51:	b8 00 00 00 00       	mov    $0x0,%eax
    2c56:	40 0f 92 c6          	setb   %sil
    2c5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2c61:	48 0f 42 d0          	cmovb  %rax,%rdx
    2c65:	31 c0                	xor    %eax,%eax
    2c67:	48 39 d1             	cmp    %rdx,%rcx
    2c6a:	0f 93 c0             	setae  %al
    2c6d:	21 f0                	and    %esi,%eax
    2c6f:	85 c0                	test   %eax,%eax
    2c71:	75 4a                	jne    2cbd <fwp_segv+0xbd>
    2c73:	31 f6                	xor    %esi,%esi
    2c75:	44 89 c7             	mov    %r8d,%edi
    2c78:	48 83 c4 28          	add    $0x28,%rsp
    2c7c:	e9 9f f8 ff ff       	jmp    2520 <signal@plt>
    2c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2c88:	48 8b 05 69 b4 01 00 	mov    0x1b469(%rip),%rax        # 1e0f8 <fwp_main_stack_top>
    2c8f:	48 85 c0             	test   %rax,%rax
    2c92:	74 df                	je     2c73 <fwp_segv+0x73>
    2c94:	48 2b 05 55 b4 01 00 	sub    0x1b455(%rip),%rax        # 1e0f0 <fwp_main_stack_size>
    2c9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ca2:	48 39 d1             	cmp    %rdx,%rcx
    2ca5:	0f 93 c2             	setae  %dl
    2ca8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cae:	48 39 c1             	cmp    %rax,%rcx
    2cb1:	0f 92 c0             	setb   %al
    2cb4:	0f b6 c0             	movzbl %al,%eax
    2cb7:	21 d0                	and    %edx,%eax
    2cb9:	85 c0                	test   %eax,%eax
    2cbb:	74 b6                	je     2c73 <fwp_segv+0x73>
    2cbd:	e8 fe fe ff ff       	call   2bc0 <fwp_flush>
    2cc2:	bf 02 00 00 00       	mov    $0x2,%edi
    2cc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2ccc:	48 8d 35 fd 88 00 00 	lea    0x88fd(%rip),%rsi        # b5d0 <msg.3>
    2cd3:	e8 38 f7 ff ff       	call   2410 <write@plt>
    2cd8:	bf 65 00 00 00       	mov    $0x65,%edi
    2cdd:	e8 de f6 ff ff       	call   23c0 <_exit@plt>
    2ce2:	0f 1f 00             	nopl   (%rax)
    2ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2cec:	00 00 00 00 

0000000000002cf0 <fwp_heap_oom>:
    2cf0:	50                   	push   %rax
    2cf1:	58                   	pop    %rax
    2cf2:	ba 13 00 00 00       	mov    $0x13,%edx
    2cf7:	be 01 00 00 00       	mov    $0x1,%esi
    2cfc:	48 8d 3d 05 83 00 00 	lea    0x8305(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2d03:	48 83 ec 08          	sub    $0x8,%rsp
    2d07:	48 8b 0d 92 b3 00 00 	mov    0xb392(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    2d0e:	e8 2d f9 ff ff       	call   2640 <fwrite@plt>
    2d13:	31 ff                	xor    %edi,%edi
    2d15:	e8 76 f8 ff ff       	call   2590 <fflush@plt>
    2d1a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d1f:	e8 3c f9 ff ff       	call   2660 <_Exit@plt>
    2d24:	90                   	nop
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 0b ce 01 00 	mov    0x1ce0b(%rip),%rax        # 1fb50 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 04 ce 01 00 	lea    0x1ce04(%rip),%r8        # 1fb50 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d e5 cd 01 00 	mov    0x1cde5(%rip),%rbx        # 1fb38 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d f5 cd 01 00 	mov    0x1cdf5(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 91 cd 01 00 	mov    0x1cd91(%rip),%rdi        # 1fb40 <fwp_heap+0x13e0>
    2daf:	48 29 35 da cd 01 00 	sub    %rsi,0x1cdda(%rip)        # 1fb90 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 6a cd 01 00 	mov    0x1cd6a(%rip),%rax        # 1fb30 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 20 cd 01 00 	add    0x1cd20(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 2e cd 01 00 	mov    0x1cd2e(%rip),%rsi        # 1fb40 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 3c cd 01 00 	mov    0x1cd3c(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 eb cc 01 00 	mov    %r12,0x1cceb(%rip)        # 1fb40 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d d9 cc 01 00 	mov    %rbp,0x1ccd9(%rip)        # 1fb38 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d be cc 01 00 	cmp    %rdi,0x1ccbe(%rip)        # 1fb28 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d b5 cc 01 00 	mov    %rdi,0x1ccb5(%rip)        # 1fb28 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d f9 cc 01 00 	sub    %rdi,0x1ccf9(%rip)        # 1fb90 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 a1 cc 01 00 	mov    0x1cca1(%rip),%rax        # 1fb48 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 9a cc 01 00 	lea    0x1cc9a(%rip),%r8        # 1fb48 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 31 fe ff ff       	call   2cf0 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <ad_raw_fail>:
    2ec0:	50                   	push   %rax
    2ec1:	58                   	pop    %rax
    2ec2:	48 8d 15 2f 83 00 00 	lea    0x832f(%rip),%rdx        # b1f8 <_IO_stdin_used+0x1f8>
    2ec9:	be 02 00 00 00       	mov    $0x2,%esi
    2ece:	31 c0                	xor    %eax,%eax
    2ed0:	48 83 ec 08          	sub    $0x8,%rsp
    2ed4:	48 89 f9             	mov    %rdi,%rcx
    2ed7:	48 8b 3d c2 b1 00 00 	mov    0xb1c2(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    2ede:	e8 6d f7 ff ff       	call   2650 <__fprintf_chk@plt>
    2ee3:	bf e8 00 00 00       	mov    $0xe8,%edi
    2ee8:	e8 43 f7 ff ff       	call   2630 <exit@plt>
    2eed:	0f 1f 00             	nopl   (%rax)

0000000000002ef0 <buf_grow>:
    2ef0:	48 83 ec 18          	sub    $0x18,%rsp
    2ef4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ef8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2efc:	74 7e                	je     2f7c <buf_grow+0x8c>
    2efe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f05:	48 29 c2             	sub    %rax,%rdx
    2f08:	48 39 f2             	cmp    %rsi,%rdx
    2f0b:	72 6f                	jb     2f7c <buf_grow+0x8c>
    2f0d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f12:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f16:	48 89 f9             	mov    %rdi,%rcx
    2f19:	48 39 d0             	cmp    %rdx,%rax
    2f1c:	73 48                	jae    2f66 <buf_grow+0x76>
    2f1e:	48 85 c0             	test   %rax,%rax
    2f21:	75 15                	jne    2f38 <buf_grow+0x48>
    2f23:	48 83 fa 40          	cmp    $0x40,%rdx
    2f27:	76 4c                	jbe    2f75 <buf_grow+0x85>
    2f29:	b8 40 00 00 00       	mov    $0x40,%eax
    2f2e:	eb 08                	jmp    2f38 <buf_grow+0x48>
    2f30:	48 01 c0             	add    %rax,%rax
    2f33:	48 39 d0             	cmp    %rdx,%rax
    2f36:	73 38                	jae    2f70 <buf_grow+0x80>
    2f38:	48 85 c0             	test   %rax,%rax
    2f3b:	79 f3                	jns    2f30 <buf_grow+0x40>
    2f3d:	48 8b 39             	mov    (%rcx),%rdi
    2f40:	48 89 d6             	mov    %rdx,%rsi
    2f43:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f48:	48 89 14 24          	mov    %rdx,(%rsp)
    2f4c:	e8 4f f6 ff ff       	call   25a0 <realloc@plt>
    2f51:	48 8b 14 24          	mov    (%rsp),%rdx
    2f55:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f5a:	48 85 c0             	test   %rax,%rax
    2f5d:	74 1d                	je     2f7c <buf_grow+0x8c>
    2f5f:	48 89 01             	mov    %rax,(%rcx)
    2f62:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f66:	48 83 c4 18          	add    $0x18,%rsp
    2f6a:	c3                   	ret
    2f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f70:	48 89 c2             	mov    %rax,%rdx
    2f73:	eb c8                	jmp    2f3d <buf_grow+0x4d>
    2f75:	ba 40 00 00 00       	mov    $0x40,%edx
    2f7a:	eb c1                	jmp    2f3d <buf_grow+0x4d>
    2f7c:	48 8b 0d 1d b1 00 00 	mov    0xb11d(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    2f83:	ba 13 00 00 00       	mov    $0x13,%edx
    2f88:	be 01 00 00 00       	mov    $0x1,%esi
    2f8d:	48 8d 3d 74 80 00 00 	lea    0x8074(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f94:	e8 a7 f6 ff ff       	call   2640 <fwrite@plt>
    2f99:	31 ff                	xor    %edi,%edi
    2f9b:	e8 f0 f5 ff ff       	call   2590 <fflush@plt>
    2fa0:	bf 66 00 00 00       	mov    $0x66,%edi
    2fa5:	e8 b6 f6 ff ff       	call   2660 <_Exit@plt>
    2faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002fb0 <buf_put>:
    2fb0:	41 54                	push   %r12
    2fb2:	49 89 f4             	mov    %rsi,%r12
    2fb5:	48 89 d6             	mov    %rdx,%rsi
    2fb8:	55                   	push   %rbp
    2fb9:	48 89 fd             	mov    %rdi,%rbp
    2fbc:	53                   	push   %rbx
    2fbd:	48 89 d3             	mov    %rdx,%rbx
    2fc0:	e8 2b ff ff ff       	call   2ef0 <buf_grow>
    2fc5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2fc9:	48 89 da             	mov    %rbx,%rdx
    2fcc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fd0:	4c 89 e6             	mov    %r12,%rsi
    2fd3:	e8 98 f5 ff ff       	call   2570 <memcpy@plt>
    2fd8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fdc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fe0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fe4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fe8:	5b                   	pop    %rbx
    2fe9:	5d                   	pop    %rbp
    2fea:	41 5c                	pop    %r12
    2fec:	c3                   	ret
    2fed:	0f 1f 00             	nopl   (%rax)

0000000000002ff0 <fwp_cancel_tree.part.0>:
    2ff0:	48 3b 3d 49 b7 01 00 	cmp    0x1b749(%rip),%rdi        # 1e740 <fwp_cur>
    2ff7:	53                   	push   %rbx
    2ff8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2ffc:	74 35                	je     3033 <fwp_cancel_tree.part.0+0x43>
    2ffe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3002:	75 2f                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    3004:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3008:	75 29                	jne    3033 <fwp_cancel_tree.part.0+0x43>
    300a:	48 8b 05 0f b7 01 00 	mov    0x1b70f(%rip),%rax        # 1e720 <fwp_ready_tail>
    3011:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3015:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    301c:	00 00 00 00 
    3020:	48 85 c0             	test   %rax,%rax
    3023:	74 33                	je     3058 <fwp_cancel_tree.part.0+0x68>
    3025:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    302c:	48 89 3d ed b6 01 00 	mov    %rdi,0x1b6ed(%rip)        # 1e720 <fwp_ready_tail>
    3033:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3037:	48 85 db             	test   %rbx,%rbx
    303a:	74 17                	je     3053 <fwp_cancel_tree.part.0+0x63>
    303c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3040:	75 08                	jne    304a <fwp_cancel_tree.part.0+0x5a>
    3042:	48 89 df             	mov    %rbx,%rdi
    3045:	e8 a6 ff ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    304a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    304e:	48 85 db             	test   %rbx,%rbx
    3051:	75 e9                	jne    303c <fwp_cancel_tree.part.0+0x4c>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	48 89 3d c9 b6 01 00 	mov    %rdi,0x1b6c9(%rip)        # 1e728 <fwp_ready_head>
    305f:	eb cb                	jmp    302c <fwp_cancel_tree.part.0+0x3c>
    3061:	0f 1f 40 00          	nopl   0x0(%rax)
    3065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    306c:	00 00 00 00 

0000000000003070 <fwp_finish_float>:
    3070:	53                   	push   %rbx
    3071:	be 2e 00 00 00       	mov    $0x2e,%esi
    3076:	48 89 fb             	mov    %rdi,%rbx
    3079:	e8 e2 f3 ff ff       	call   2460 <strchr@plt>
    307e:	48 85 c0             	test   %rax,%rax
    3081:	74 05                	je     3088 <fwp_finish_float+0x18>
    3083:	5b                   	pop    %rbx
    3084:	c3                   	ret
    3085:	0f 1f 00             	nopl   (%rax)
    3088:	be 65 00 00 00       	mov    $0x65,%esi
    308d:	48 89 df             	mov    %rbx,%rdi
    3090:	e8 cb f3 ff ff       	call   2460 <strchr@plt>
    3095:	48 85 c0             	test   %rax,%rax
    3098:	75 e9                	jne    3083 <fwp_finish_float+0x13>
    309a:	48 8d 35 61 80 00 00 	lea    0x8061(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    30a1:	48 89 df             	mov    %rbx,%rdi
    30a4:	e8 e7 f5 ff ff       	call   2690 <strstr@plt>
    30a9:	48 85 c0             	test   %rax,%rax
    30ac:	75 d5                	jne    3083 <fwp_finish_float+0x13>
    30ae:	48 8d 35 67 7f 00 00 	lea    0x7f67(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    30b5:	48 89 df             	mov    %rbx,%rdi
    30b8:	e8 d3 f5 ff ff       	call   2690 <strstr@plt>
    30bd:	48 85 c0             	test   %rax,%rax
    30c0:	75 c1                	jne    3083 <fwp_finish_float+0x13>
    30c2:	48 89 df             	mov    %rbx,%rdi
    30c5:	e8 66 f3 ff ff       	call   2430 <strlen@plt>
    30ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    30cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30d8:	5b                   	pop    %rbx
    30d9:	c3                   	ret
    30da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030e0 <ad_raw_report>:
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	55                   	push   %rbp
    30e5:	31 c9                	xor    %ecx,%ecx
    30e7:	45 31 c9             	xor    %r9d,%r9d
    30ea:	48 8d 15 2f 81 00 00 	lea    0x812f(%rip),%rdx        # b220 <_IO_stdin_used+0x220>
    30f1:	53                   	push   %rbx
    30f2:	be 02 00 00 00       	mov    $0x2,%esi
    30f7:	31 db                	xor    %ebx,%ebx
    30f9:	48 83 ec 38          	sub    $0x38,%rsp
    30fd:	4c 8b 05 e4 af 01 00 	mov    0x1afe4(%rip),%r8        # 1e0e8 <ad_raw_before_shutdown>
    3104:	48 8b 3d 95 af 00 00 	mov    0xaf95(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    310b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3112:	00 00 
    3114:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3119:	31 c0                	xor    %eax,%eax
    311b:	48 89 e5             	mov    %rsp,%rbp
    311e:	e8 2d f5 ff ff       	call   2650 <__fprintf_chk@plt>
    3123:	48 8d 05 01 7f 00 00 	lea    0x7f01(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    312a:	f3 0f 7e 05 de aa 00 	movq   0xaade(%rip),%xmm0        # dc10 <d0+0x70>
    3131:	00 
    3132:	48 8d 0d 35 7f 00 00 	lea    0x7f35(%rip),%rcx        # b06e <_IO_stdin_used+0x6e>
    3139:	66 48 0f 6e c8       	movq   %rax,%xmm1
    313e:	48 8d 05 f9 7e 00 00 	lea    0x7ef9(%rip),%rax        # b03e <_IO_stdin_used+0x3e>
    3145:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3149:	66 48 0f 6e d0       	movq   %rax,%xmm2
    314e:	66 49 0f 7e c0       	movq   %xmm0,%r8
    3153:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3157:	f3 0f 7e 05 b9 aa 00 	movq   0xaab9(%rip),%xmm0        # dc18 <d0+0x78>
    315e:	00 
    315f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3163:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3168:	6a 00                	push   $0x0
    316a:	48 8b 3d 2f af 00 00 	mov    0xaf2f(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    3171:	45 31 c9             	xor    %r9d,%r9d
    3174:	31 c0                	xor    %eax,%eax
    3176:	6a 00                	push   $0x0
    3178:	48 8d 15 01 81 00 00 	lea    0x8101(%rip),%rdx        # b280 <_IO_stdin_used+0x280>
    317f:	be 02 00 00 00       	mov    $0x2,%esi
    3184:	83 c3 01             	add    $0x1,%ebx
    3187:	e8 c4 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    318c:	58                   	pop    %rax
    318d:	5a                   	pop    %rdx
    318e:	83 fb 04             	cmp    $0x4,%ebx
    3191:	74 15                	je     31a8 <ad_raw_report+0xc8>
    3193:	48 83 c5 08          	add    $0x8,%rbp
    3197:	48 8d 0d 82 7e 00 00 	lea    0x7e82(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    319e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    31a2:	eb c4                	jmp    3168 <ad_raw_report+0x88>
    31a4:	0f 1f 40 00          	nopl   0x0(%rax)
    31a8:	48 8b 0d f1 ae 00 00 	mov    0xaef1(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    31af:	ba 13 00 00 00       	mov    $0x13,%edx
    31b4:	be 01 00 00 00       	mov    $0x1,%esi
    31b9:	48 8d 3d 87 7e 00 00 	lea    0x7e87(%rip),%rdi        # b047 <_IO_stdin_used+0x47>
    31c0:	e8 7b f4 ff ff       	call   2640 <fwrite@plt>
    31c5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    31ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    31d1:	00 00 
    31d3:	75 23                	jne    31f8 <ad_raw_report+0x118>
    31d5:	48 8b 0d c4 ae 00 00 	mov    0xaec4(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    31dc:	48 83 c4 38          	add    $0x38,%rsp
    31e0:	ba 04 00 00 00       	mov    $0x4,%edx
    31e5:	be 01 00 00 00       	mov    $0x1,%esi
    31ea:	5b                   	pop    %rbx
    31eb:	48 8d 3d 69 7e 00 00 	lea    0x7e69(%rip),%rdi        # b05b <_IO_stdin_used+0x5b>
    31f2:	5d                   	pop    %rbp
    31f3:	e9 48 f4 ff ff       	jmp    2640 <fwrite@plt>
    31f8:	e8 43 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    31fd:	0f 1f 00             	nopl   (%rax)

0000000000003200 <fwp_trap>:
    3200:	53                   	push   %rbx
    3201:	48 89 fb             	mov    %rdi,%rbx
    3204:	e8 b7 f9 ff ff       	call   2bc0 <fwp_flush>
    3209:	48 89 d9             	mov    %rbx,%rcx
    320c:	be 02 00 00 00       	mov    $0x2,%esi
    3211:	31 c0                	xor    %eax,%eax
    3213:	48 8b 3d 86 ae 00 00 	mov    0xae86(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    321a:	48 8d 15 3f 7e 00 00 	lea    0x7e3f(%rip),%rdx        # b060 <_IO_stdin_used+0x60>
    3221:	e8 2a f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3226:	bf 65 00 00 00       	mov    $0x65,%edi
    322b:	e8 00 f4 ff ff       	call   2630 <exit@plt>

0000000000003230 <fwp_now_ns>:
    3230:	53                   	push   %rbx
    3231:	bf 01 00 00 00       	mov    $0x1,%edi
    3236:	48 83 ec 20          	sub    $0x20,%rsp
    323a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    3241:	00 00 
    3243:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    3248:	31 db                	xor    %ebx,%ebx
    324a:	48 89 e6             	mov    %rsp,%rsi
    324d:	e8 ae f1 ff ff       	call   2400 <clock_gettime@plt>
    3252:	85 c0                	test   %eax,%eax
    3254:	75 52                	jne    32a8 <fwp_now_ns+0x78>
    3256:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    325b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3260:	48 f7 2c 24          	imulq  (%rsp)
    3264:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    326b:	48 89 f7             	mov    %rsi,%rdi
    326e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3272:	48 01 f0             	add    %rsi,%rax
    3275:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    327c:	00 00 80 
    327f:	48 11 fa             	adc    %rdi,%rdx
    3282:	31 ff                	xor    %edi,%edi
    3284:	48 01 c6             	add    %rax,%rsi
    3287:	48 11 d7             	adc    %rdx,%rdi
    328a:	48 39 f1             	cmp    %rsi,%rcx
    328d:	48 19 fb             	sbb    %rdi,%rbx
    3290:	72 27                	jb     32b9 <fwp_now_ns+0x89>
    3292:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3297:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    329e:	00 00 
    32a0:	75 12                	jne    32b4 <fwp_now_ns+0x84>
    32a2:	48 83 c4 20          	add    $0x20,%rsp
    32a6:	5b                   	pop    %rbx
    32a7:	c3                   	ret
    32a8:	48 8d 3d c0 7d 00 00 	lea    0x7dc0(%rip),%rdi        # b06f <_IO_stdin_used+0x6f>
    32af:	e8 4c ff ff ff       	call   3200 <fwp_trap>
    32b4:	e8 87 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    32b9:	48 8d 3d 00 80 00 00 	lea    0x8000(%rip),%rdi        # b2c0 <_IO_stdin_used+0x2c0>
    32c0:	e8 3b ff ff ff       	call   3200 <fwp_trap>
    32c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    32cc:	00 00 00 00 

00000000000032d0 <fwp_format_g.constprop.0>:
    32d0:	41 57                	push   %r15
    32d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    32d7:	ba 02 00 00 00       	mov    $0x2,%edx
    32dc:	4c 8d 05 a8 7d 00 00 	lea    0x7da8(%rip),%r8        # b08b <_IO_stdin_used+0x8b>
    32e3:	41 56                	push   %r14
    32e5:	b8 01 00 00 00       	mov    $0x1,%eax
    32ea:	41 55                	push   %r13
    32ec:	41 54                	push   %r12
    32ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    32f2:	55                   	push   %rbp
    32f3:	45 89 e1             	mov    %r12d,%r9d
    32f6:	53                   	push   %rbx
    32f7:	48 89 fb             	mov    %rdi,%rbx
    32fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3301:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3308:	00 00 
    330a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3311:	00 
    3312:	41 89 f7             	mov    %esi,%r15d
    3315:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    331a:	be 40 00 00 00       	mov    $0x40,%esi
    331f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    3324:	4c 89 f7             	mov    %r14,%rdi
    3327:	e8 64 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    332c:	be 65 00 00 00       	mov    $0x65,%esi
    3331:	4c 89 f7             	mov    %r14,%rdi
    3334:	e8 27 f1 ff ff       	call   2460 <strchr@plt>
    3339:	31 f6                	xor    %esi,%esi
    333b:	ba 0a 00 00 00       	mov    $0xa,%edx
    3340:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3344:	48 89 c5             	mov    %rax,%rbp
    3347:	e8 14 f2 ff ff       	call   2560 <strtol@plt>
    334c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3351:	49 89 c0             	mov    %rax,%r8
    3354:	83 c0 05             	add    $0x5,%eax
    3357:	83 f8 15             	cmp    $0x15,%eax
    335a:	0f 87 e0 01 00 00    	ja     3540 <fwp_format_g.constprop.0+0x270>
    3360:	45 89 e5             	mov    %r12d,%r13d
    3363:	45 29 c5             	sub    %r8d,%r13d
    3366:	45 85 ed             	test   %r13d,%r13d
    3369:	0f 8e 21 01 00 00    	jle    3490 <fwp_format_g.constprop.0+0x1c0>
    336f:	41 83 ff 01          	cmp    $0x1,%r15d
    3373:	0f 84 17 01 00 00    	je     3490 <fwp_format_g.constprop.0+0x1c0>
    3379:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    337e:	31 d2                	xor    %edx,%edx
    3380:	4d 63 df             	movslq %r15d,%r11
    3383:	3c 2d                	cmp    $0x2d,%al
    3385:	0f 94 c2             	sete   %dl
    3388:	4c 29 dd             	sub    %r11,%rbp
    338b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    338f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3393:	4d 89 f1             	mov    %r14,%r9
    3396:	4d 29 d1             	sub    %r10,%r9
    3399:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    339d:	3c 2d                	cmp    $0x2d,%al
    339f:	0f 84 fb 03 00 00    	je     37a0 <fwp_format_g.constprop.0+0x4d0>
    33a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    33aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    33af:	48 89 e8             	mov    %rbp,%rax
    33b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    33ba:	49 83 c1 47          	add    $0x47,%r9
    33be:	45 85 c0             	test   %r8d,%r8d
    33c1:	0f 88 f1 02 00 00    	js     36b8 <fwp_format_g.constprop.0+0x3e8>
    33c7:	45 0f b6 12          	movzbl (%r10),%r10d
    33cb:	4d 63 e0             	movslq %r8d,%r12
    33ce:	44 88 10             	mov    %r10b,(%rax)
    33d1:	41 83 f8 07          	cmp    $0x7,%r8d
    33d5:	0f 87 2d 02 00 00    	ja     3608 <fwp_format_g.constprop.0+0x338>
    33db:	41 f6 c4 04          	test   $0x4,%r12b
    33df:	0f 85 f2 03 00 00    	jne    37d7 <fwp_format_g.constprop.0+0x507>
    33e5:	45 85 e4             	test   %r12d,%r12d
    33e8:	74 12                	je     33fc <fwp_format_g.constprop.0+0x12c>
    33ea:	45 0f b6 06          	movzbl (%r14),%r8d
    33ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    33f2:	41 f6 c4 02          	test   $0x2,%r12b
    33f6:	0f 85 03 04 00 00    	jne    37ff <fwp_format_g.constprop.0+0x52f>
    33fc:	4c 29 e1             	sub    %r12,%rcx
    33ff:	4c 01 e7             	add    %r12,%rdi
    3402:	4c 89 fa             	mov    %r15,%rdx
    3405:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    340a:	48 83 e9 01          	sub    $0x1,%rcx
    340e:	4d 63 ed             	movslq %r13d,%r13
    3411:	48 89 0c 24          	mov    %rcx,(%rsp)
    3415:	e8 26 f1 ff ff       	call   2540 <__memcpy_chk@plt>
    341a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    341f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3423:	ba 48 00 00 00       	mov    $0x48,%edx
    3428:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    342c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    3430:	4c 89 c8             	mov    %r9,%rax
    3433:	48 29 c8             	sub    %rcx,%rax
    3436:	48 39 d0             	cmp    %rdx,%rax
    3439:	48 0f 42 c2          	cmovb  %rdx,%rax
    343d:	4c 29 c9             	sub    %r9,%rcx
    3440:	4c 89 ea             	mov    %r13,%rdx
    3443:	48 01 c1             	add    %rax,%rcx
    3446:	e8 f5 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    344b:	4c 01 e8             	add    %r13,%rax
    344e:	48 29 e8             	sub    %rbp,%rax
    3451:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3456:	48 39 d0             	cmp    %rdx,%rax
    3459:	48 0f 47 c2          	cmova  %rdx,%rax
    345d:	89 c1                	mov    %eax,%ecx
    345f:	83 f8 08             	cmp    $0x8,%eax
    3462:	0f 83 18 02 00 00    	jae    3680 <fwp_format_g.constprop.0+0x3b0>
    3468:	a8 04                	test   $0x4,%al
    346a:	0f 85 54 03 00 00    	jne    37c4 <fwp_format_g.constprop.0+0x4f4>
    3470:	85 c0                	test   %eax,%eax
    3472:	74 0f                	je     3483 <fwp_format_g.constprop.0+0x1b3>
    3474:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3479:	88 13                	mov    %dl,(%rbx)
    347b:	a8 02                	test   $0x2,%al
    347d:	0f 85 6b 03 00 00    	jne    37ee <fwp_format_g.constprop.0+0x51e>
    3483:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3487:	eb 36                	jmp    34bf <fwp_format_g.constprop.0+0x1ef>
    3489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3490:	45 31 c9             	xor    %r9d,%r9d
    3493:	45 85 ed             	test   %r13d,%r13d
    3496:	4c 8d 05 fd 7b 00 00 	lea    0x7bfd(%rip),%r8        # b09a <_IO_stdin_used+0x9a>
    349d:	48 89 df             	mov    %rbx,%rdi
    34a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    34a4:	ba 02 00 00 00       	mov    $0x2,%edx
    34a9:	be 90 01 00 00       	mov    $0x190,%esi
    34ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    34b5:	b8 01 00 00 00       	mov    $0x1,%eax
    34ba:	e8 d1 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    34c4:	48 89 df             	mov    %rbx,%rdi
    34c7:	e8 94 ef ff ff       	call   2460 <strchr@plt>
    34cc:	48 85 c0             	test   %rax,%rax
    34cf:	74 3f                	je     3510 <fwp_format_g.constprop.0+0x240>
    34d1:	48 89 df             	mov    %rbx,%rdi
    34d4:	e8 57 ef ff ff       	call   2430 <strlen@plt>
    34d9:	48 85 c0             	test   %rax,%rax
    34dc:	75 0b                	jne    34e9 <fwp_format_g.constprop.0+0x219>
    34de:	eb 30                	jmp    3510 <fwp_format_g.constprop.0+0x240>
    34e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    34e4:	48 85 c0             	test   %rax,%rax
    34e7:	74 27                	je     3510 <fwp_format_g.constprop.0+0x240>
    34e9:	48 89 c2             	mov    %rax,%rdx
    34ec:	48 83 e8 01          	sub    $0x1,%rax
    34f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    34f4:	74 ea                	je     34e0 <fwp_format_g.constprop.0+0x210>
    34f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    34fb:	0f 84 6f 01 00 00    	je     3670 <fwp_format_g.constprop.0+0x3a0>
    3501:	0f 1f 40 00          	nopl   0x0(%rax)
    3505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    350c:	00 00 00 00 
    3510:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3517:	00 
    3518:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    351f:	00 00 
    3521:	0f 85 ec 02 00 00    	jne    3813 <fwp_format_g.constprop.0+0x543>
    3527:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    352e:	5b                   	pop    %rbx
    352f:	5d                   	pop    %rbp
    3530:	41 5c                	pop    %r12
    3532:	41 5d                	pop    %r13
    3534:	41 5e                	pop    %r14
    3536:	41 5f                	pop    %r15
    3538:	c3                   	ret
    3539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3540:	4c 29 f5             	sub    %r14,%rbp
    3543:	b9 40 00 00 00       	mov    $0x40,%ecx
    3548:	4c 89 f6             	mov    %r14,%rsi
    354b:	4c 89 04 24          	mov    %r8,(%rsp)
    354f:	49 89 ec             	mov    %rbp,%r12
    3552:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3557:	4c 89 e2             	mov    %r12,%rdx
    355a:	48 89 ef             	mov    %rbp,%rdi
    355d:	e8 de ef ff ff       	call   2540 <__memcpy_chk@plt>
    3562:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3568:	be 2e 00 00 00       	mov    $0x2e,%esi
    356d:	48 89 ef             	mov    %rbp,%rdi
    3570:	e8 eb ee ff ff       	call   2460 <strchr@plt>
    3575:	4c 8b 04 24          	mov    (%rsp),%r8
    3579:	48 85 c0             	test   %rax,%rax
    357c:	74 40                	je     35be <fwp_format_g.constprop.0+0x2ee>
    357e:	4d 85 e4             	test   %r12,%r12
    3581:	74 3b                	je     35be <fwp_format_g.constprop.0+0x2ee>
    3583:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3588:	eb 23                	jmp    35ad <fwp_format_g.constprop.0+0x2dd>
    358a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3591:	00 00 00 00 
    3595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    359c:	00 00 00 00 
    35a0:	c6 00 00             	movb   $0x0,(%rax)
    35a3:	48 83 e8 01          	sub    $0x1,%rax
    35a7:	49 83 ec 01          	sub    $0x1,%r12
    35ab:	74 11                	je     35be <fwp_format_g.constprop.0+0x2ee>
    35ad:	80 38 30             	cmpb   $0x30,(%rax)
    35b0:	74 ee                	je     35a0 <fwp_format_g.constprop.0+0x2d0>
    35b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    35b8:	0f 84 fb 01 00 00    	je     37b9 <fwp_format_g.constprop.0+0x4e9>
    35be:	44 89 c0             	mov    %r8d,%eax
    35c1:	ba 02 00 00 00       	mov    $0x2,%edx
    35c6:	49 89 e9             	mov    %rbp,%r9
    35c9:	be 90 01 00 00       	mov    $0x190,%esi
    35ce:	f7 d8                	neg    %eax
    35d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    35d7:	48 89 df             	mov    %rbx,%rdi
    35da:	41 0f 48 c0          	cmovs  %r8d,%eax
    35de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    35e2:	41 83 e0 02          	and    $0x2,%r8d
    35e6:	41 83 c0 2b          	add    $0x2b,%r8d
    35ea:	50                   	push   %rax
    35eb:	31 c0                	xor    %eax,%eax
    35ed:	41 50                	push   %r8
    35ef:	4c 8d 05 9a 7a 00 00 	lea    0x7a9a(%rip),%r8        # b090 <_IO_stdin_used+0x90>
    35f6:	e8 95 ed ff ff       	call   2390 <__snprintf_chk@plt>
    35fb:	58                   	pop    %rax
    35fc:	5a                   	pop    %rdx
    35fd:	e9 0e ff ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    3602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3608:	4d 8b 06             	mov    (%r14),%r8
    360b:	48 83 c0 09          	add    $0x9,%rax
    360f:	4c 89 f2             	mov    %r14,%rdx
    3612:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3616:	4c 89 07             	mov    %r8,(%rdi)
    3619:	45 89 e0             	mov    %r12d,%r8d
    361c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    3621:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    3626:	49 89 f8             	mov    %rdi,%r8
    3629:	49 29 c0             	sub    %rax,%r8
    362c:	4c 29 c2             	sub    %r8,%rdx
    362f:	45 01 e0             	add    %r12d,%r8d
    3632:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3636:	41 83 f8 08          	cmp    $0x8,%r8d
    363a:	0f 82 bc fd ff ff    	jb     33fc <fwp_format_g.constprop.0+0x12c>
    3640:	48 89 0c 24          	mov    %rcx,(%rsp)
    3644:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3648:	45 31 d2             	xor    %r10d,%r10d
    364b:	45 89 d3             	mov    %r10d,%r11d
    364e:	41 83 c2 08          	add    $0x8,%r10d
    3652:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3656:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    365a:	45 39 c2             	cmp    %r8d,%r10d
    365d:	72 ec                	jb     364b <fwp_format_g.constprop.0+0x37b>
    365f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3663:	e9 94 fd ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    366f:	00 
    3670:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3675:	e9 96 fe ff ff       	jmp    3510 <fwp_format_g.constprop.0+0x240>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3680:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3685:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3689:	48 89 ee             	mov    %rbp,%rsi
    368c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3690:	48 89 13             	mov    %rdx,(%rbx)
    3693:	89 c2                	mov    %eax,%edx
    3695:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    369a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    369f:	48 89 d9             	mov    %rbx,%rcx
    36a2:	48 29 f9             	sub    %rdi,%rcx
    36a5:	48 29 ce             	sub    %rcx,%rsi
    36a8:	01 c1                	add    %eax,%ecx
    36aa:	c1 e9 03             	shr    $0x3,%ecx
    36ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    36b0:	e9 ce fd ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    36b5:	0f 1f 00             	nopl   (%rax)
    36b8:	c6 00 30             	movb   $0x30,(%rax)
    36bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    36bf:	4c 89 fa             	mov    %r15,%rdx
    36c2:	4c 89 e9             	mov    %r13,%rcx
    36c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    36ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    36cf:	4c 89 14 24          	mov    %r10,(%rsp)
    36d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    36d8:	e8 63 ee ff ff       	call   2540 <__memcpy_chk@plt>
    36dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    36e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    36e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    36ec:	48 89 c7             	mov    %rax,%rdi
    36ef:	4c 8b 14 24          	mov    (%rsp),%r10
    36f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    36f8:	4c 89 c8             	mov    %r9,%rax
    36fb:	4c 29 e8             	sub    %r13,%rax
    36fe:	48 39 c8             	cmp    %rcx,%rax
    3701:	48 0f 42 c1          	cmovb  %rcx,%rax
    3705:	4d 29 cd             	sub    %r9,%r13
    3708:	49 01 ff             	add    %rdi,%r15
    370b:	4c 01 e8             	add    %r13,%rax
    370e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3712:	74 3d                	je     3751 <fwp_format_g.constprop.0+0x481>
    3714:	41 f7 d0             	not    %r8d
    3717:	31 f6                	xor    %esi,%esi
    3719:	ba 48 00 00 00       	mov    $0x48,%edx
    371e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    3723:	48 39 d0             	cmp    %rdx,%rax
    3726:	48 0f 43 d0          	cmovae %rax,%rdx
    372a:	48 89 d1             	mov    %rdx,%rcx
    372d:	48 29 c1             	sub    %rax,%rcx
    3730:	48 83 c1 01          	add    $0x1,%rcx
    3734:	48 39 d1             	cmp    %rdx,%rcx
    3737:	48 0f 42 ca          	cmovb  %rdx,%rcx
    373b:	48 83 e8 01          	sub    $0x1,%rax
    373f:	48 83 c6 01          	add    $0x1,%rsi
    3743:	48 29 d0             	sub    %rdx,%rax
    3746:	48 01 c8             	add    %rcx,%rax
    3749:	41 39 f0             	cmp    %esi,%r8d
    374c:	7f cb                	jg     3719 <fwp_format_g.constprop.0+0x449>
    374e:	4d 01 c7             	add    %r8,%r15
    3751:	b9 48 00 00 00       	mov    $0x48,%ecx
    3756:	41 0f b6 12          	movzbl (%r10),%edx
    375a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    375e:	4c 89 f6             	mov    %r14,%rsi
    3761:	48 39 c8             	cmp    %rcx,%rax
    3764:	4c 89 1c 24          	mov    %r11,(%rsp)
    3768:	48 0f 43 c8          	cmovae %rax,%rcx
    376c:	41 88 17             	mov    %dl,(%r15)
    376f:	48 89 ca             	mov    %rcx,%rdx
    3772:	48 29 c2             	sub    %rax,%rdx
    3775:	48 83 c2 01          	add    $0x1,%rdx
    3779:	48 39 ca             	cmp    %rcx,%rdx
    377c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3780:	48 83 e8 01          	sub    $0x1,%rax
    3784:	48 29 c8             	sub    %rcx,%rax
    3787:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    378b:	49 63 d4             	movslq %r12d,%rdx
    378e:	e8 ad ed ff ff       	call   2540 <__memcpy_chk@plt>
    3793:	4c 8b 1c 24          	mov    (%rsp),%r11
    3797:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    379b:	e9 ae fc ff ff       	jmp    344e <fwp_format_g.constprop.0+0x17e>
    37a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    37a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    37aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    37af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    37b4:	e9 f9 fb ff ff       	jmp    33b2 <fwp_format_g.constprop.0+0xe2>
    37b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    37bf:	e9 fa fd ff ff       	jmp    35be <fwp_format_g.constprop.0+0x2ee>
    37c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    37c8:	89 13                	mov    %edx,(%rbx)
    37ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    37ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    37d2:	e9 ac fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37d7:	41 8b 06             	mov    (%r14),%eax
    37da:	89 07                	mov    %eax,(%rdi)
    37dc:	44 89 e0             	mov    %r12d,%eax
    37df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    37e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    37e9:	e9 0e fc ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    37ee:	89 c2                	mov    %eax,%edx
    37f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    37f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    37fa:	e9 84 fc ff ff       	jmp    3483 <fwp_format_g.constprop.0+0x1b3>
    37ff:	44 89 e0             	mov    %r12d,%eax
    3802:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3808:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    380e:	e9 e9 fb ff ff       	jmp    33fc <fwp_format_g.constprop.0+0x12c>
    3813:	e8 28 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    3818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    381f:	00 

0000000000003820 <fwp_heap_report>:
    3820:	f3 0f 1e fa          	endbr64
    3824:	41 54                	push   %r12
    3826:	48 8d 3d 72 78 00 00 	lea    0x7872(%rip),%rdi        # b09f <_IO_stdin_used+0x9f>
    382d:	55                   	push   %rbp
    382e:	53                   	push   %rbx
    382f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    3836:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    383d:	00 00 
    383f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3846:	00 
    3847:	48 8d 35 fc 78 00 00 	lea    0x78fc(%rip),%rsi        # b14a <_IO_stdin_used+0x14a>
    384e:	e8 9d ed ff ff       	call   25f0 <fopen@plt>
    3853:	48 85 c0             	test   %rax,%rax
    3856:	0f 84 c5 00 00 00    	je     3921 <fwp_heap_report+0x101>
    385c:	48 89 c5             	mov    %rax,%rbp
    385f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3866:	48 89 e3             	mov    %rsp,%rbx
    3869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3870:	48 89 ea             	mov    %rbp,%rdx
    3873:	be 00 01 00 00       	mov    $0x100,%esi
    3878:	48 89 df             	mov    %rbx,%rdi
    387b:	e8 60 ec ff ff       	call   24e0 <fgets@plt>
    3880:	48 85 c0             	test   %rax,%rax
    3883:	74 2b                	je     38b0 <fwp_heap_report+0x90>
    3885:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    388b:	75 e3                	jne    3870 <fwp_heap_report+0x50>
    388d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3891:	75 dd                	jne    3870 <fwp_heap_report+0x50>
    3893:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3898:	75 d6                	jne    3870 <fwp_heap_report+0x50>
    389a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    389f:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a4:	31 f6                	xor    %esi,%esi
    38a6:	e8 b5 ec ff ff       	call   2560 <strtol@plt>
    38ab:	49 89 c4             	mov    %rax,%r12
    38ae:	eb c0                	jmp    3870 <fwp_heap_report+0x50>
    38b0:	48 89 ef             	mov    %rbp,%rdi
    38b3:	e8 68 eb ff ff       	call   2420 <fclose@plt>
    38b8:	48 83 ec 08          	sub    $0x8,%rsp
    38bc:	4c 8b 0d 65 c2 01 00 	mov    0x1c265(%rip),%r9        # 1fb28 <fwp_heap+0x13c8>
    38c3:	4c 8b 05 be c2 01 00 	mov    0x1c2be(%rip),%r8        # 1fb88 <fwp_heap+0x1428>
    38ca:	48 8d 15 17 7a 00 00 	lea    0x7a17(%rip),%rdx        # b2e8 <_IO_stdin_used+0x2e8>
    38d1:	41 54                	push   %r12
    38d3:	48 8b 0d a6 c2 01 00 	mov    0x1c2a6(%rip),%rcx        # 1fb80 <fwp_heap+0x1420>
    38da:	be 02 00 00 00       	mov    $0x2,%esi
    38df:	b8 02 00 00 00       	mov    $0x2,%eax
    38e4:	f2 0f 10 0d b4 c2 01 	movsd  0x1c2b4(%rip),%xmm1        # 1fba0 <fwp_heap+0x1440>
    38eb:	00 
    38ec:	f2 0f 10 05 a4 c2 01 	movsd  0x1c2a4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    38f3:	00 
    38f4:	48 8b 3d a5 a7 00 00 	mov    0xa7a5(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    38fb:	e8 50 ed ff ff       	call   2650 <__fprintf_chk@plt>
    3900:	58                   	pop    %rax
    3901:	5a                   	pop    %rdx
    3902:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3909:	00 
    390a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3911:	00 00 
    3913:	75 15                	jne    392a <fwp_heap_report+0x10a>
    3915:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    391c:	5b                   	pop    %rbx
    391d:	5d                   	pop    %rbp
    391e:	41 5c                	pop    %r12
    3920:	c3                   	ret
    3921:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3928:	eb 8e                	jmp    38b8 <fwp_heap_report+0x98>
    392a:	e8 11 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    392f:	90                   	nop

0000000000003930 <fwp_heap_init>:
    3930:	66 0f 6f 05 b8 7c 00 	movdqa 0x7cb8(%rip),%xmm0        # b5f0 <msg.3+0x20>
    3937:	00 
    3938:	41 54                	push   %r12
    393a:	48 8d 05 5f bd 01 00 	lea    0x1bd5f(%rip),%rax        # 1f6a0 <fwp_heap+0xf40>
    3941:	ba 00 01 00 00       	mov    $0x100,%edx
    3946:	55                   	push   %rbp
    3947:	66 0f 6f 15 e1 7c 00 	movdqa 0x7ce1(%rip),%xmm2        # b630 <msg.3+0x60>
    394e:	00 
    394f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3953:	53                   	push   %rbx
    3954:	0f 29 05 05 bd 01 00 	movaps %xmm0,0x1bd05(%rip)        # 1f660 <fwp_heap+0xf00>
    395b:	66 0f 6f 05 9d 7c 00 	movdqa 0x7c9d(%rip),%xmm0        # b600 <msg.3+0x30>
    3962:	00 
    3963:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3967:	c7 05 93 c1 01 00 01 	movl   $0x1,0x1c193(%rip)        # 1fb04 <fwp_heap+0x13a4>
    396e:	00 00 00 
    3971:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3976:	0f 29 05 f3 bc 01 00 	movaps %xmm0,0x1bcf3(%rip)        # 1f670 <fwp_heap+0xf10>
    397d:	66 0f 6f 05 8b 7c 00 	movdqa 0x7c8b(%rip),%xmm0        # b610 <msg.3+0x40>
    3984:	00 
    3985:	0f 29 05 f4 bc 01 00 	movaps %xmm0,0x1bcf4(%rip)        # 1f680 <fwp_heap+0xf20>
    398c:	66 0f 6f 05 8c 7c 00 	movdqa 0x7c8c(%rip),%xmm0        # b620 <msg.3+0x50>
    3993:	00 
    3994:	0f 29 05 f5 bc 01 00 	movaps %xmm0,0x1bcf5(%rip)        # 1f690 <fwp_heap+0xf30>
    399b:	89 d3                	mov    %edx,%ebx
    399d:	66 0f 6e e2          	movd   %edx,%xmm4
    39a1:	48 83 c0 10          	add    $0x10,%rax
    39a5:	01 d2                	add    %edx,%edx
    39a7:	c1 eb 02             	shr    $0x2,%ebx
    39aa:	66 0f 6e c3          	movd   %ebx,%xmm0
    39ae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    39b3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    39b7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    39bc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    39c0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    39c4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    39c9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    39ce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    39d2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    39d7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    39db:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    39df:	48 39 c7             	cmp    %rax,%rdi
    39e2:	75 b7                	jne    399b <fwp_heap_init+0x6b>
    39e4:	4c 8d 05 75 ad 01 00 	lea    0x1ad75(%rip),%r8        # 1e760 <fwp_heap>
    39eb:	31 c9                	xor    %ecx,%ecx
    39ed:	31 c0                	xor    %eax,%eax
    39ef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    39f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    39fd:	00 00 00 
    3a00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a07:	00 
    3a08:	48 39 ca             	cmp    %rcx,%rdx
    3a0b:	73 0f                	jae    3a1c <fwp_heap_init+0xec>
    3a0d:	0f 1f 00             	nopl   (%rax)
    3a10:	48 83 c0 01          	add    $0x1,%rax
    3a14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a17:	48 39 ca             	cmp    %rcx,%rdx
    3a1a:	72 f4                	jb     3a10 <fwp_heap_init+0xe0>
    3a1c:	48 83 c1 10          	add    $0x10,%rcx
    3a20:	88 07                	mov    %al,(%rdi)
    3a22:	48 83 c7 01          	add    $0x1,%rdi
    3a26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3a2d:	75 d1                	jne    3a00 <fwp_heap_init+0xd0>
    3a2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3a36:	00 00 00 
    3a39:	bd 05 00 00 00       	mov    $0x5,%ebp
    3a3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3a45:	45 31 c9             	xor    %r9d,%r9d
    3a48:	31 d2                	xor    %edx,%edx
    3a4a:	31 ff                	xor    %edi,%edi
    3a4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3a57:	4c 89 e6             	mov    %r12,%rsi
    3a5a:	e8 f1 e9 ff ff       	call   2450 <mmap@plt>
    3a5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3a63:	75 13                	jne    3a78 <fwp_heap_init+0x148>
    3a65:	48 c1 eb 02          	shr    $0x2,%rbx
    3a69:	83 ed 01             	sub    $0x1,%ebp
    3a6c:	75 d0                	jne    3a3e <fwp_heap_init+0x10e>
    3a6e:	e8 7d f2 ff ff       	call   2cf0 <fwp_heap_oom>
    3a73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3a78:	48 85 c0             	test   %rax,%rax
    3a7b:	74 f1                	je     3a6e <fwp_heap_init+0x13e>
    3a7d:	48 c1 eb 10          	shr    $0x10,%rbx
    3a81:	48 89 05 90 c0 01 00 	mov    %rax,0x1c090(%rip)        # 1fb18 <fwp_heap+0x13b8>
    3a88:	45 31 c9             	xor    %r9d,%r9d
    3a8b:	31 d2                	xor    %edx,%edx
    3a8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3a93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3a97:	31 ff                	xor    %edi,%edi
    3a99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3a9f:	66 31 c0             	xor    %ax,%ax
    3aa2:	48 c1 e6 03          	shl    $0x3,%rsi
    3aa6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3aab:	4c 89 25 6e c0 01 00 	mov    %r12,0x1c06e(%rip)        # 1fb20 <fwp_heap+0x13c0>
    3ab2:	48 89 05 57 c0 01 00 	mov    %rax,0x1c057(%rip)        # 1fb10 <fwp_heap+0x13b0>
    3ab9:	48 89 1d 70 c0 01 00 	mov    %rbx,0x1c070(%rip)        # 1fb30 <fwp_heap+0x13d0>
    3ac0:	48 89 35 99 c0 01 00 	mov    %rsi,0x1c099(%rip)        # 1fb60 <fwp_heap+0x1400>
    3ac7:	e8 84 e9 ff ff       	call   2450 <mmap@plt>
    3acc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ad0:	74 9c                	je     3a6e <fwp_heap_init+0x13e>
    3ad2:	48 8d 3d fc 75 00 00 	lea    0x75fc(%rip),%rdi        # b0d5 <_IO_stdin_used+0xd5>
    3ad9:	48 89 05 78 c0 01 00 	mov    %rax,0x1c078(%rip)        # 1fb58 <fwp_heap+0x13f8>
    3ae0:	e8 9b e8 ff ff       	call   2380 <getenv@plt>
    3ae5:	48 89 c2             	mov    %rax,%rdx
    3ae8:	31 c0                	xor    %eax,%eax
    3aea:	48 85 d2             	test   %rdx,%rdx
    3aed:	74 15                	je     3b04 <fwp_heap_init+0x1d4>
    3aef:	80 3a 00             	cmpb   $0x0,(%rdx)
    3af2:	74 10                	je     3b04 <fwp_heap_init+0x1d4>
    3af4:	0f b6 02             	movzbl (%rdx),%eax
    3af7:	83 e8 30             	sub    $0x30,%eax
    3afa:	74 13                	je     3b0f <fwp_heap_init+0x1df>
    3afc:	85 c0                	test   %eax,%eax
    3afe:	0f 95 c0             	setne  %al
    3b01:	0f b6 c0             	movzbl %al,%eax
    3b04:	5b                   	pop    %rbx
    3b05:	5d                   	pop    %rbp
    3b06:	89 05 fc bf 01 00    	mov    %eax,0x1bffc(%rip)        # 1fb08 <fwp_heap+0x13a8>
    3b0c:	41 5c                	pop    %r12
    3b0e:	c3                   	ret
    3b0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b13:	85 c0                	test   %eax,%eax
    3b15:	0f 95 c0             	setne  %al
    3b18:	0f b6 c0             	movzbl %al,%eax
    3b1b:	eb e7                	jmp    3b04 <fwp_heap_init+0x1d4>
    3b1d:	0f 1f 00             	nopl   (%rax)

0000000000003b20 <fwp_wake_io>:
    3b20:	48 8b 07             	mov    (%rdi),%rax
    3b23:	48 85 c0             	test   %rax,%rax
    3b26:	0f 84 f4 00 00 00    	je     3c20 <fwp_wake_io+0x100>
    3b2c:	53                   	push   %rbx
    3b2d:	4c 8b 05 ec ab 01 00 	mov    0x1abec(%rip),%r8        # 1e720 <fwp_ready_tail>
    3b34:	49 89 f9             	mov    %rdi,%r9
    3b37:	48 89 c2             	mov    %rax,%rdx
    3b3a:	45 31 db             	xor    %r11d,%r11d
    3b3d:	45 31 d2             	xor    %r10d,%r10d
    3b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3b44:	eb 71                	jmp    3bb7 <fwp_wake_io+0x97>
    3b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3b4d:	00 00 00 
    3b50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3b57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3b5e:	48 85 c9             	test   %rcx,%rcx
    3b61:	74 07                	je     3b6a <fwp_wake_io+0x4a>
    3b63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3b6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3b71:	00 00 00 00 
    3b75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3b7c:	49 8b 01             	mov    (%r9),%rax
    3b7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3b83:	75 2a                	jne    3baf <fwp_wake_io+0x8f>
    3b85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3b89:	75 24                	jne    3baf <fwp_wake_io+0x8f>
    3b8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3b8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3b96:	00 00 00 00 
    3b9a:	4d 85 c0             	test   %r8,%r8
    3b9d:	74 51                	je     3bf0 <fwp_wake_io+0xd0>
    3b9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3ba6:	49 89 d0             	mov    %rdx,%r8
    3ba9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3baf:	48 89 c2             	mov    %rax,%rdx
    3bb2:	48 85 c0             	test   %rax,%rax
    3bb5:	74 49                	je     3c00 <fwp_wake_io+0xe0>
    3bb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3bbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3bc2:	48 85 ff             	test   %rdi,%rdi
    3bc5:	74 b8                	je     3b7f <fwp_wake_io+0x5f>
    3bc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3bce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bd5:	48 85 f6             	test   %rsi,%rsi
    3bd8:	0f 85 72 ff ff ff    	jne    3b50 <fwp_wake_io+0x30>
    3bde:	48 89 0f             	mov    %rcx,(%rdi)
    3be1:	e9 78 ff ff ff       	jmp    3b5e <fwp_wake_io+0x3e>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 d3             	mov    %rdx,%rbx
    3bf3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3bf9:	eb ab                	jmp    3ba6 <fwp_wake_io+0x86>
    3bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3c00:	45 84 db             	test   %r11b,%r11b
    3c03:	74 07                	je     3c0c <fwp_wake_io+0xec>
    3c05:	48 89 1d 1c ab 01 00 	mov    %rbx,0x1ab1c(%rip)        # 1e728 <fwp_ready_head>
    3c0c:	45 84 d2             	test   %r10b,%r10b
    3c0f:	74 07                	je     3c18 <fwp_wake_io+0xf8>
    3c11:	4c 89 05 08 ab 01 00 	mov    %r8,0x1ab08(%rip)        # 1e720 <fwp_ready_tail>
    3c18:	5b                   	pop    %rbx
    3c19:	c3                   	ret
    3c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3c20:	c3                   	ret
    3c21:	0f 1f 40 00          	nopl   0x0(%rax)
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_poll_events>:
    3c30:	53                   	push   %rbx
    3c31:	48 83 ec 20          	sub    $0x20,%rsp
    3c35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3c3c:	00 00 
    3c3e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3c43:	31 c0                	xor    %eax,%eax
    3c45:	e8 e6 f5 ff ff       	call   3230 <fwp_now_ns>
    3c4a:	48 8b 1d c7 aa 01 00 	mov    0x1aac7(%rip),%rbx        # 1e718 <fwp_timers>
    3c51:	48 85 db             	test   %rbx,%rbx
    3c54:	0f 84 e6 00 00 00    	je     3d40 <fwp_poll_events+0x110>
    3c5a:	48 89 c6             	mov    %rax,%rsi
    3c5d:	48 89 da             	mov    %rbx,%rdx
    3c60:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3c67:	eb 26                	jmp    3c8f <fwp_poll_events+0x5f>
    3c69:	90                   	nop
    3c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c71:	00 00 00 00 
    3c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c7c:	00 00 00 00 
    3c80:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3c87:	48 89 c8             	mov    %rcx,%rax
    3c8a:	48 85 d2             	test   %rdx,%rdx
    3c8d:	74 31                	je     3cc0 <fwp_poll_events+0x90>
    3c8f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3c93:	48 85 c0             	test   %rax,%rax
    3c96:	78 e8                	js     3c80 <fwp_poll_events+0x50>
    3c98:	48 39 c1             	cmp    %rax,%rcx
    3c9b:	7c e3                	jl     3c80 <fwp_poll_events+0x50>
    3c9d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3ca4:	48 85 d2             	test   %rdx,%rdx
    3ca7:	74 1c                	je     3cc5 <fwp_poll_events+0x95>
    3ca9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3cad:	48 39 c1             	cmp    %rax,%rcx
    3cb0:	7c ce                	jl     3c80 <fwp_poll_events+0x50>
    3cb2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3cb9:	48 85 d2             	test   %rdx,%rdx
    3cbc:	75 d1                	jne    3c8f <fwp_poll_events+0x5f>
    3cbe:	66 90                	xchg   %ax,%ax
    3cc0:	48 85 c0             	test   %rax,%rax
    3cc3:	78 7b                	js     3d40 <fwp_poll_events+0x110>
    3cc5:	48 29 f0             	sub    %rsi,%rax
    3cc8:	48 89 c1             	mov    %rax,%rcx
    3ccb:	48 85 c0             	test   %rax,%rax
    3cce:	0f 8e 9c 00 00 00    	jle    3d70 <fwp_poll_events+0x140>
    3cd4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3cdb:	de 1b 43 
    3cde:	48 f7 ea             	imul   %rdx
    3ce1:	48 89 c8             	mov    %rcx,%rax
    3ce4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ce8:	48 c1 fa 12          	sar    $0x12,%rdx
    3cec:	48 29 c2             	sub    %rax,%rdx
    3cef:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3cf6:	48 39 c1             	cmp    %rax,%rcx
    3cf9:	0f 95 c0             	setne  %al
    3cfc:	0f b6 c0             	movzbl %al,%eax
    3cff:	48 01 d0             	add    %rdx,%rax
    3d02:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3d08:	0f 8f 32 01 00 00    	jg     3e40 <fwp_poll_events+0x210>
    3d0e:	48 85 c0             	test   %rax,%rax
    3d11:	74 5d                	je     3d70 <fwp_poll_events+0x140>
    3d13:	89 c1                	mov    %eax,%ecx
    3d15:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3d1c:	48 c1 e9 26          	shr    $0x26,%rcx
    3d20:	48 63 d1             	movslq %ecx,%rdx
    3d23:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3d29:	29 c8                	sub    %ecx,%eax
    3d2b:	48 98                	cltq
    3d2d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3d34:	e9 11 01 00 00       	jmp    3e4a <fwp_poll_events+0x21a>
    3d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d40:	e8 7b ee ff ff       	call   2bc0 <fwp_flush>
    3d45:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3d4a:	be 01 00 00 00       	mov    $0x1,%esi
    3d4f:	48 8b 0d 4a a3 00 00 	mov    0xa34a(%rip),%rcx        # e0a0 <stderr@GLIBC_2.2.5>
    3d56:	48 8d 3d 13 76 00 00 	lea    0x7613(%rip),%rdi        # b370 <_IO_stdin_used+0x370>
    3d5d:	e8 de e8 ff ff       	call   2640 <fwrite@plt>
    3d62:	bf 65 00 00 00       	mov    $0x65,%edi
    3d67:	e8 c4 e8 ff ff       	call   2630 <exit@plt>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	e8 bb f4 ff ff       	call   3230 <fwp_now_ns>
    3d75:	48 89 c1             	mov    %rax,%rcx
    3d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3d7c:	eb 44                	jmp    3dc2 <fwp_poll_events+0x192>
    3d7e:	66 90                	xchg   %ax,%ax
    3d80:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3d84:	75 33                	jne    3db9 <fwp_poll_events+0x189>
    3d86:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3d8a:	75 2d                	jne    3db9 <fwp_poll_events+0x189>
    3d8c:	48 8b 05 8d a9 01 00 	mov    0x1a98d(%rip),%rax        # 1e720 <fwp_ready_tail>
    3d93:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3d97:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3d9e:	00 00 00 00 
    3da2:	48 85 c0             	test   %rax,%rax
    3da5:	0f 84 05 01 00 00    	je     3eb0 <fwp_poll_events+0x280>
    3dab:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3db2:	48 89 15 67 a9 01 00 	mov    %rdx,0x1a967(%rip)        # 1e720 <fwp_ready_tail>
    3db9:	48 85 db             	test   %rbx,%rbx
    3dbc:	0f 84 be 00 00 00    	je     3e80 <fwp_poll_events+0x250>
    3dc2:	48 89 da             	mov    %rbx,%rdx
    3dc5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3dcc:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3dd0:	7f e7                	jg     3db9 <fwp_poll_events+0x189>
    3dd2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3dd6:	74 2e                	je     3e06 <fwp_poll_events+0x1d6>
    3dd8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3ddf:	48 85 c0             	test   %rax,%rax
    3de2:	0f 84 b8 00 00 00    	je     3ea0 <fwp_poll_events+0x270>
    3de8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3def:	48 85 db             	test   %rbx,%rbx
    3df2:	74 07                	je     3dfb <fwp_poll_events+0x1cb>
    3df4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3dfb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3dff:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3e06:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3e0a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3e0e:	48 85 c0             	test   %rax,%rax
    3e11:	0f 84 69 ff ff ff    	je     3d80 <fwp_poll_events+0x150>
    3e17:	48 39 c8             	cmp    %rcx,%rax
    3e1a:	0f 8f 60 ff ff ff    	jg     3d80 <fwp_poll_events+0x150>
    3e20:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3e24:	0f 85 56 ff ff ff    	jne    3d80 <fwp_poll_events+0x150>
    3e2a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2e:	75 89                	jne    3db9 <fwp_poll_events+0x189>
    3e30:	48 89 d7             	mov    %rdx,%rdi
    3e33:	e8 b8 f1 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    3e38:	e9 43 ff ff ff       	jmp    3d80 <fwp_poll_events+0x150>
    3e3d:	0f 1f 00             	nopl   (%rax)
    3e40:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3e45:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3e4a:	48 89 e7             	mov    %rsp,%rdi
    3e4d:	31 f6                	xor    %esi,%esi
    3e4f:	48 89 14 24          	mov    %rdx,(%rsp)
    3e53:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3e58:	e8 23 e6 ff ff       	call   2480 <nanosleep@plt>
    3e5d:	48 8b 1d b4 a8 01 00 	mov    0x1a8b4(%rip),%rbx        # 1e718 <fwp_timers>
    3e64:	e8 c7 f3 ff ff       	call   3230 <fwp_now_ns>
    3e69:	48 89 c1             	mov    %rax,%rcx
    3e6c:	48 85 db             	test   %rbx,%rbx
    3e6f:	0f 85 03 ff ff ff    	jne    3d78 <fwp_poll_events+0x148>
    3e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e7c:	00 00 00 00 
    3e80:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3e85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3e8c:	00 00 
    3e8e:	75 2c                	jne    3ebc <fwp_poll_events+0x28c>
    3e90:	48 83 c4 20          	add    $0x20,%rsp
    3e94:	5b                   	pop    %rbx
    3e95:	c3                   	ret
    3e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3e9d:	00 00 00 
    3ea0:	48 89 1d 71 a8 01 00 	mov    %rbx,0x1a871(%rip)        # 1e718 <fwp_timers>
    3ea7:	e9 43 ff ff ff       	jmp    3def <fwp_poll_events+0x1bf>
    3eac:	0f 1f 40 00          	nopl   0x0(%rax)
    3eb0:	48 89 15 71 a8 01 00 	mov    %rdx,0x1a871(%rip)        # 1e728 <fwp_ready_head>
    3eb7:	e9 f6 fe ff ff       	jmp    3db2 <fwp_poll_events+0x182>
    3ebc:	e8 7f e5 ff ff       	call   2440 <__stack_chk_fail@plt>
    3ec1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ecc:	00 00 00 00 

0000000000003ed0 <fwp_rc_forget_slot>:
    3ed0:	80 3f ff             	cmpb   $0xff,(%rdi)
    3ed3:	74 0b                	je     3ee0 <fwp_rc_forget_slot+0x10>
    3ed5:	c3                   	ret
    3ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3edd:	00 00 00 
    3ee0:	48 89 f8             	mov    %rdi,%rax
    3ee3:	48 83 ec 08          	sub    $0x8,%rsp
    3ee7:	48 89 fa             	mov    %rdi,%rdx
    3eea:	48 c1 e8 11          	shr    $0x11,%rax
    3eee:	48 31 f8             	xor    %rdi,%rax
    3ef1:	48 89 c1             	mov    %rax,%rcx
    3ef4:	48 c1 e9 09          	shr    $0x9,%rcx
    3ef8:	48 31 c8             	xor    %rcx,%rax
    3efb:	48 8d 0d 5e a8 01 00 	lea    0x1a85e(%rip),%rcx        # 1e760 <fwp_heap>
    3f02:	0f b6 c0             	movzbl %al,%eax
    3f05:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3f0c:	00 
    3f0d:	48 85 ff             	test   %rdi,%rdi
    3f10:	74 3c                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f12:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3f19:	00 
    3f1a:	48 8b 01             	mov    (%rcx),%rax
    3f1d:	eb 11                	jmp    3f30 <fwp_rc_forget_slot+0x60>
    3f1f:	90                   	nop
    3f20:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3f24:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3f28:	48 85 ff             	test   %rdi,%rdi
    3f2b:	74 21                	je     3f4e <fwp_rc_forget_slot+0x7e>
    3f2d:	48 89 f8             	mov    %rdi,%rax
    3f30:	48 3b 10             	cmp    (%rax),%rdx
    3f33:	75 eb                	jne    3f20 <fwp_rc_forget_slot+0x50>
    3f35:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f39:	48 89 01             	mov    %rax,(%rcx)
    3f3c:	e8 5f e4 ff ff       	call   23a0 <free@plt>
    3f41:	48 83 2d 5f c4 01 00 	subq   $0x1,0x1c45f(%rip)        # 203a8 <fwp_heap+0x1c48>
    3f48:	01 
    3f49:	48 83 c4 08          	add    $0x8,%rsp
    3f4d:	c3                   	ret
    3f4e:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    3f55:	e8 a6 f2 ff ff       	call   3200 <fwp_trap>
    3f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f60 <fwp_rc_prepare_chunk>:
    3f60:	48 83 3d 40 c4 01 00 	cmpq   $0x0,0x1c440(%rip)        # 203a8 <fwp_heap+0x1c48>
    3f67:	00 
    3f68:	41 54                	push   %r12
    3f6a:	49 89 f4             	mov    %rsi,%r12
    3f6d:	55                   	push   %rbp
    3f6e:	48 89 fd             	mov    %rdi,%rbp
    3f71:	53                   	push   %rbx
    3f72:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3f75:	0f 84 7d 00 00 00    	je     3ff8 <fwp_rc_prepare_chunk+0x98>
    3f7b:	31 db                	xor    %ebx,%ebx
    3f7d:	85 c0                	test   %eax,%eax
    3f7f:	75 5f                	jne    3fe0 <fwp_rc_prepare_chunk+0x80>
    3f81:	48 85 f6             	test   %rsi,%rsi
    3f84:	74 7c                	je     4002 <fwp_rc_prepare_chunk+0xa2>
    3f86:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3f8a:	e8 11 e4 ff ff       	call   23a0 <free@plt>
    3f8f:	90                   	nop
    3f90:	be 01 00 00 00       	mov    $0x1,%esi
    3f95:	4c 89 e7             	mov    %r12,%rdi
    3f98:	e8 63 e5 ff ff       	call   2500 <calloc@plt>
    3f9d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3fa1:	48 85 c0             	test   %rax,%rax
    3fa4:	0f 85 87 00 00 00    	jne    4031 <fwp_rc_prepare_chunk+0xd1>
    3faa:	e8 41 ed ff ff       	call   2cf0 <fwp_heap_oom>
    3faf:	90                   	nop
    3fb0:	e8 1b ff ff ff       	call   3ed0 <fwp_rc_forget_slot>
    3fb5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fb8:	48 83 c3 01          	add    $0x1,%rbx
    3fbc:	48 39 c3             	cmp    %rax,%rbx
    3fbf:	73 37                	jae    3ff8 <fwp_rc_prepare_chunk+0x98>
    3fc1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fc8:	00 00 
    3fca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fd1:	00 00 00 00 
    3fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fdc:	00 00 00 00 
    3fe0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3fe4:	48 01 df             	add    %rbx,%rdi
    3fe7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3fea:	74 c4                	je     3fb0 <fwp_rc_prepare_chunk+0x50>
    3fec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3fef:	48 83 c3 01          	add    $0x1,%rbx
    3ff3:	48 39 c3             	cmp    %rax,%rbx
    3ff6:	72 e8                	jb     3fe0 <fwp_rc_prepare_chunk+0x80>
    3ff8:	49 39 c4             	cmp    %rax,%r12
    3ffb:	75 13                	jne    4010 <fwp_rc_prepare_chunk+0xb0>
    3ffd:	4d 85 e4             	test   %r12,%r12
    4000:	75 46                	jne    4048 <fwp_rc_prepare_chunk+0xe8>
    4002:	5b                   	pop    %rbx
    4003:	5d                   	pop    %rbp
    4004:	41 5c                	pop    %r12
    4006:	c3                   	ret
    4007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    400e:	00 00 
    4010:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    4014:	48 29 05 95 c3 01 00 	sub    %rax,0x1c395(%rip)        # 203b0 <fwp_heap+0x1c50>
    401b:	e8 80 e3 ff ff       	call   23a0 <free@plt>
    4020:	4d 85 e4             	test   %r12,%r12
    4023:	0f 85 67 ff ff ff    	jne    3f90 <fwp_rc_prepare_chunk+0x30>
    4029:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    4030:	00 
    4031:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    4035:	5b                   	pop    %rbx
    4036:	4c 01 25 73 c3 01 00 	add    %r12,0x1c373(%rip)        # 203b0 <fwp_heap+0x1c50>
    403d:	5d                   	pop    %rbp
    403e:	41 5c                	pop    %r12
    4040:	c3                   	ret
    4041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4048:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    404c:	5b                   	pop    %rbx
    404d:	4c 89 e2             	mov    %r12,%rdx
    4050:	31 f6                	xor    %esi,%esi
    4052:	5d                   	pop    %rbp
    4053:	41 5c                	pop    %r12
    4055:	e9 46 e4 ff ff       	jmp    24a0 <memset@plt>
    405a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004060 <fwp_heap_refill>:
    4060:	41 56                	push   %r14
    4062:	41 89 d6             	mov    %edx,%r14d
    4065:	41 55                	push   %r13
    4067:	41 89 f5             	mov    %esi,%r13d
    406a:	41 54                	push   %r12
    406c:	49 89 fc             	mov    %rdi,%r12
    406f:	bf 01 00 00 00       	mov    $0x1,%edi
    4074:	55                   	push   %rbp
    4075:	53                   	push   %rbx
    4076:	e8 b5 ec ff ff       	call   2d30 <fwp_heap_chunks>
    407b:	48 89 c3             	mov    %rax,%rbx
    407e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4082:	48 8b 05 cf ba 01 00 	mov    0x1bacf(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    4089:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    408d:	48 8d 05 cc a6 01 00 	lea    0x1a6cc(%rip),%rax        # 1e760 <fwp_heap>
    4094:	31 d2                	xor    %edx,%edx
    4096:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    409a:	48 89 ef             	mov    %rbp,%rdi
    409d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    40a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    40a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    40ac:	00 
    40ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    40b2:	f7 f1                	div    %ecx
    40b4:	31 d2                	xor    %edx,%edx
    40b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    40ba:	66 0f 6e c8          	movd   %eax,%xmm1
    40be:	89 c6                	mov    %eax,%esi
    40c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    40c5:	48 01 c8             	add    %rcx,%rax
    40c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    40cc:	48 f7 f1             	div    %rcx
    40cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    40d4:	89 45 18             	mov    %eax,0x18(%rbp)
    40d7:	e8 84 fe ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    40dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    40df:	48 89 d8             	mov    %rbx,%rax
    40e2:	48 c1 e0 10          	shl    $0x10,%rax
    40e6:	48 03 05 23 ba 01 00 	add    0x1ba23(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    40ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    40f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    40f6:	8b 55 08             	mov    0x8(%rbp),%edx
    40f9:	48 0f af d1          	imul   %rcx,%rdx
    40fd:	48 01 c2             	add    %rax,%rdx
    4100:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    4105:	5b                   	pop    %rbx
    4106:	5d                   	pop    %rbp
    4107:	41 5c                	pop    %r12
    4109:	41 5d                	pop    %r13
    410b:	41 5e                	pop    %r14
    410d:	c3                   	ret
    410e:	66 90                	xchg   %ax,%ax

0000000000004110 <fwp_mem_free>:
    4110:	48 85 ff             	test   %rdi,%rdi
    4113:	0f 84 17 02 00 00    	je     4330 <fwp_mem_free+0x220>
    4119:	48 8b 35 f0 b9 01 00 	mov    0x1b9f0(%rip),%rsi        # 1fb10 <fwp_heap+0x13b0>
    4120:	48 8b 05 11 ba 01 00 	mov    0x1ba11(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    4127:	48 89 fa             	mov    %rdi,%rdx
    412a:	48 29 f2             	sub    %rsi,%rdx
    412d:	48 c1 e0 10          	shl    $0x10,%rax
    4131:	48 39 c2             	cmp    %rax,%rdx
    4134:	0f 83 f6 01 00 00    	jae    4330 <fwp_mem_free+0x220>
    413a:	49 89 d1             	mov    %rdx,%r9
    413d:	49 c1 e9 10          	shr    $0x10,%r9
    4141:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4145:	48 c1 e0 03          	shl    $0x3,%rax
    4149:	49 89 c0             	mov    %rax,%r8
    414c:	4c 03 05 05 ba 01 00 	add    0x1ba05(%rip),%r8        # 1fb58 <fwp_heap+0x13f8>
    4153:	0f 84 d7 01 00 00    	je     4330 <fwp_mem_free+0x220>
    4159:	48 83 ec 38          	sub    $0x38,%rsp
    415d:	48 89 f9             	mov    %rdi,%rcx
    4160:	41 0f b6 38          	movzbl (%r8),%edi
    4164:	40 80 ff 01          	cmp    $0x1,%dil
    4168:	74 16                	je     4180 <fwp_mem_free+0x70>
    416a:	40 80 ff 02          	cmp    $0x2,%dil
    416e:	0f 84 94 00 00 00    	je     4208 <fwp_mem_free+0xf8>
    4174:	48 83 c4 38          	add    $0x38,%rsp
    4178:	c3                   	ret
    4179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4180:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4184:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4189:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    418e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4192:	4d 85 d2             	test   %r10,%r10
    4195:	74 1d                	je     41b4 <fwp_mem_free+0xa4>
    4197:	0f b7 c1             	movzwl %cx,%eax
    419a:	31 d2                	xor    %edx,%edx
    419c:	48 f7 f7             	div    %rdi
    419f:	49 01 c2             	add    %rax,%r10
    41a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    41a6:	0f 84 44 01 00 00    	je     42f0 <fwp_mem_free+0x1e0>
    41ac:	41 c6 02 00          	movb   $0x0,(%r10)
    41b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    41b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    41bb:	49 63 c1             	movslq %r9d,%rax
    41be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    41c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    41c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    41cb:	f2 0f 58 05 cd b9 01 	addsd  0x1b9cd(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    41d2:	00 
    41d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    41d7:	48 8d 05 82 a5 01 00 	lea    0x1a582(%rip),%rax        # 1e760 <fwp_heap>
    41de:	48 01 d0             	add    %rdx,%rax
    41e1:	48 8b 10             	mov    (%rax),%rdx
    41e4:	48 f7 d2             	not    %rdx
    41e7:	48 89 11             	mov    %rdx,(%rcx)
    41ea:	48 89 08             	mov    %rcx,(%rax)
    41ed:	48 29 3d 8c b9 01 00 	sub    %rdi,0x1b98c(%rip)        # 1fb80 <fwp_heap+0x1420>
    41f4:	f2 0f 11 05 a4 b9 01 	movsd  %xmm0,0x1b9a4(%rip)        # 1fba0 <fwp_heap+0x1440>
    41fb:	00 
    41fc:	48 83 c4 38          	add    $0x38,%rsp
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	66 31 d2             	xor    %dx,%dx
    420b:	48 01 d6             	add    %rdx,%rsi
    420e:	48 39 f1             	cmp    %rsi,%rcx
    4211:	0f 85 5d ff ff ff    	jne    4174 <fwp_mem_free+0x64>
    4217:	49 8b 50 10          	mov    0x10(%r8),%rdx
    421b:	48 29 15 5e b9 01 00 	sub    %rdx,0x1b95e(%rip)        # 1fb80 <fwp_heap+0x1420>
    4222:	48 85 d2             	test   %rdx,%rdx
    4225:	0f 88 a5 00 00 00    	js     42d0 <fwp_mem_free+0x1c0>
    422b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    422f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4234:	f2 0f 58 05 64 b9 01 	addsd  0x1b964(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    423b:	00 
    423c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4240:	f2 0f 11 05 58 b9 01 	movsd  %xmm0,0x1b958(%rip)        # 1fba0 <fwp_heap+0x1440>
    4247:	00 
    4248:	48 85 d2             	test   %rdx,%rdx
    424b:	74 0c                	je     4259 <fwp_mem_free+0x149>
    424d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4250:	0f 84 db 00 00 00    	je     4331 <fwp_mem_free+0x221>
    4256:	c6 02 00             	movb   $0x0,(%rdx)
    4259:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    425d:	48 85 c9             	test   %rcx,%rcx
    4260:	74 3e                	je     42a0 <fwp_mem_free+0x190>
    4262:	48 8b 15 ef b8 01 00 	mov    0x1b8ef(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    4269:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    426d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4271:	48 01 d0             	add    %rdx,%rax
    4274:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4278:	48 89 d6             	mov    %rdx,%rsi
    427b:	48 29 c6             	sub    %rax,%rsi
    427e:	83 e6 08             	and    $0x8,%esi
    4281:	74 0d                	je     4290 <fwp_mem_free+0x180>
    4283:	c6 00 00             	movb   $0x0,(%rax)
    4286:	48 83 c0 28          	add    $0x28,%rax
    428a:	48 39 c2             	cmp    %rax,%rdx
    428d:	74 11                	je     42a0 <fwp_mem_free+0x190>
    428f:	90                   	nop
    4290:	c6 00 00             	movb   $0x0,(%rax)
    4293:	48 83 c0 50          	add    $0x50,%rax
    4297:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    429b:	48 39 c2             	cmp    %rax,%rdx
    429e:	75 f0                	jne    4290 <fwp_mem_free+0x180>
    42a0:	48 01 0d e9 b8 01 00 	add    %rcx,0x1b8e9(%rip)        # 1fb90 <fwp_heap+0x1430>
    42a7:	4c 3b 0d a2 b8 01 00 	cmp    0x1b8a2(%rip),%r9        # 1fb50 <fwp_heap+0x13f0>
    42ae:	73 07                	jae    42b7 <fwp_mem_free+0x1a7>
    42b0:	4c 89 0d 99 b8 01 00 	mov    %r9,0x1b899(%rip)        # 1fb50 <fwp_heap+0x13f0>
    42b7:	4c 3b 0d 8a b8 01 00 	cmp    0x1b88a(%rip),%r9        # 1fb48 <fwp_heap+0x13e8>
    42be:	0f 83 b0 fe ff ff    	jae    4174 <fwp_mem_free+0x64>
    42c4:	4c 89 0d 7d b8 01 00 	mov    %r9,0x1b87d(%rip)        # 1fb48 <fwp_heap+0x13e8>
    42cb:	e9 a4 fe ff ff       	jmp    4174 <fwp_mem_free+0x64>
    42d0:	48 89 d1             	mov    %rdx,%rcx
    42d3:	83 e2 01             	and    $0x1,%edx
    42d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    42da:	48 d1 e9             	shr    $1,%rcx
    42dd:	48 09 d1             	or     %rdx,%rcx
    42e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    42e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    42e9:	e9 46 ff ff ff       	jmp    4234 <fwp_mem_free+0x124>
    42ee:	66 90                	xchg   %ax,%ax
    42f0:	4c 89 d7             	mov    %r10,%rdi
    42f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    42f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    42fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    4302:	89 74 24 10          	mov    %esi,0x10(%rsp)
    4306:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    430b:	e8 c0 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4310:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4315:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    431a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    431f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    4324:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    4329:	e9 7e fe ff ff       	jmp    41ac <fwp_mem_free+0x9c>
    432e:	66 90                	xchg   %ax,%ax
    4330:	c3                   	ret
    4331:	48 89 d7             	mov    %rdx,%rdi
    4334:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    4339:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    433e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4343:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4348:	e8 83 fb ff ff       	call   3ed0 <fwp_rc_forget_slot>
    434d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4352:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4357:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    435c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4361:	e9 f0 fe ff ff       	jmp    4256 <fwp_mem_free+0x146>
    4366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    436d:	00 00 00 

0000000000004370 <fwp_heap_alloc_big>:
    4370:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4377:	00 00 40 
    437a:	41 57                	push   %r15
    437c:	41 56                	push   %r14
    437e:	41 55                	push   %r13
    4380:	41 54                	push   %r12
    4382:	55                   	push   %rbp
    4383:	53                   	push   %rbx
    4384:	48 83 ec 08          	sub    $0x8,%rsp
    4388:	48 39 f8             	cmp    %rdi,%rax
    438b:	0f 82 fa 00 00 00    	jb     448b <fwp_heap_alloc_big+0x11b>
    4391:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4398:	49 89 fd             	mov    %rdi,%r13
    439b:	41 89 f6             	mov    %esi,%r14d
    439e:	48 c1 ed 10          	shr    $0x10,%rbp
    43a2:	48 89 ef             	mov    %rbp,%rdi
    43a5:	e8 86 e9 ff ff       	call   2d30 <fwp_heap_chunks>
    43aa:	be 01 00 00 00       	mov    $0x1,%esi
    43af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    43b3:	49 89 c4             	mov    %rax,%r12
    43b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    43bd:	00 
    43be:	48 03 3d 93 b7 01 00 	add    0x1b793(%rip),%rdi        # 1fb58 <fwp_heap+0x13f8>
    43c5:	c6 07 02             	movb   $0x2,(%rdi)
    43c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    43cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    43cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    43d3:	e8 88 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    43d8:	48 83 fd 01          	cmp    $0x1,%rbp
    43dc:	76 47                	jbe    4425 <fwp_heap_alloc_big+0xb5>
    43de:	4c 01 e5             	add    %r12,%rbp
    43e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    43e8:	00 
    43e9:	4c 8d 3d 70 a3 01 00 	lea    0x1a370(%rip),%r15        # 1e760 <fwp_heap>
    43f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    43f5:	49 c1 e6 03          	shl    $0x3,%r14
    43f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4400:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    4407:	31 f6                	xor    %esi,%esi
    4409:	48 01 dd             	add    %rbx,%rbp
    440c:	48 83 c3 28          	add    $0x28,%rbx
    4410:	48 89 ef             	mov    %rbp,%rdi
    4413:	e8 48 fb ff ff       	call   3f60 <fwp_rc_prepare_chunk>
    4418:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    441c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    4420:	49 39 de             	cmp    %rbx,%r14
    4423:	75 db                	jne    4400 <fwp_heap_alloc_big+0x90>
    4425:	49 c1 e4 10          	shl    $0x10,%r12
    4429:	4c 03 25 e0 b6 01 00 	add    0x1b6e0(%rip),%r12        # 1fb10 <fwp_heap+0x13b0>
    4430:	4c 89 ea             	mov    %r13,%rdx
    4433:	31 f6                	xor    %esi,%esi
    4435:	4c 89 e7             	mov    %r12,%rdi
    4438:	e8 63 e0 ff ff       	call   24a0 <memset@plt>
    443d:	4c 89 e8             	mov    %r13,%rax
    4440:	48 03 05 39 b7 01 00 	add    0x1b739(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4447:	72 42                	jb     448b <fwp_heap_alloc_big+0x11b>
    4449:	48 39 05 38 b7 01 00 	cmp    %rax,0x1b738(%rip)        # 1fb88 <fwp_heap+0x1428>
    4450:	48 89 05 29 b7 01 00 	mov    %rax,0x1b729(%rip)        # 1fb80 <fwp_heap+0x1420>
    4457:	73 07                	jae    4460 <fwp_heap_alloc_big+0xf0>
    4459:	48 89 05 28 b7 01 00 	mov    %rax,0x1b728(%rip)        # 1fb88 <fwp_heap+0x1428>
    4460:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4464:	4c 89 e0             	mov    %r12,%rax
    4467:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    446c:	f2 0f 58 05 24 b7 01 	addsd  0x1b724(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4473:	00 
    4474:	f2 0f 11 05 1c b7 01 	movsd  %xmm0,0x1b71c(%rip)        # 1fb98 <fwp_heap+0x1438>
    447b:	00 
    447c:	48 83 c4 08          	add    $0x8,%rsp
    4480:	5b                   	pop    %rbx
    4481:	5d                   	pop    %rbp
    4482:	41 5c                	pop    %r12
    4484:	41 5d                	pop    %r13
    4486:	41 5e                	pop    %r14
    4488:	41 5f                	pop    %r15
    448a:	c3                   	ret
    448b:	e8 60 e8 ff ff       	call   2cf0 <fwp_heap_oom>

0000000000004490 <fwp_heap_alloc_slow>:
    4490:	53                   	push   %rbx
    4491:	48 89 f9             	mov    %rdi,%rcx
    4494:	41 89 f1             	mov    %esi,%r9d
    4497:	48 83 ec 10          	sub    $0x10,%rsp
    449b:	8b 05 63 b6 01 00    	mov    0x1b663(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    44a1:	85 c0                	test   %eax,%eax
    44a3:	0f 84 c7 00 00 00    	je     4570 <fwp_heap_alloc_slow+0xe0>
    44a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    44b0:	0f 87 dd 00 00 00    	ja     4593 <fwp_heap_alloc_slow+0x103>
    44b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    44ba:	48 8d 3d 9f a2 01 00 	lea    0x1a29f(%rip),%rdi        # 1e760 <fwp_heap>
    44c1:	49 63 f1             	movslq %r9d,%rsi
    44c4:	48 c1 e8 04          	shr    $0x4,%rax
    44c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    44cf:	00 00 
    44d1:	41 0f b6 c2          	movzbl %r10b,%eax
    44d5:	4c 89 d2             	mov    %r10,%rdx
    44d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    44dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    44e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    44ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    44ee:	48 01 f8             	add    %rdi,%rax
    44f1:	4c 8b 00             	mov    (%rax),%r8
    44f4:	4d 85 c0             	test   %r8,%r8
    44f7:	0f 84 ab 00 00 00    	je     45a8 <fwp_heap_alloc_slow+0x118>
    44fd:	49 8b 10             	mov    (%r8),%rdx
    4500:	48 f7 d2             	not    %rdx
    4503:	48 89 10             	mov    %rdx,(%rax)
    4506:	41 83 f9 01          	cmp    $0x1,%r9d
    450a:	4c 89 c7             	mov    %r8,%rdi
    450d:	48 0f 45 cb          	cmovne %rbx,%rcx
    4511:	31 f6                	xor    %esi,%esi
    4513:	48 89 ca             	mov    %rcx,%rdx
    4516:	e8 85 df ff ff       	call   24a0 <memset@plt>
    451b:	49 89 c0             	mov    %rax,%r8
    451e:	48 89 d8             	mov    %rbx,%rax
    4521:	48 03 05 58 b6 01 00 	add    0x1b658(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4528:	0f 82 d9 00 00 00    	jb     4607 <fwp_heap_alloc_slow+0x177>
    452e:	48 39 05 53 b6 01 00 	cmp    %rax,0x1b653(%rip)        # 1fb88 <fwp_heap+0x1428>
    4535:	48 89 05 44 b6 01 00 	mov    %rax,0x1b644(%rip)        # 1fb80 <fwp_heap+0x1420>
    453c:	73 07                	jae    4545 <fwp_heap_alloc_slow+0xb5>
    453e:	48 89 05 43 b6 01 00 	mov    %rax,0x1b643(%rip)        # 1fb88 <fwp_heap+0x1428>
    4545:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4549:	4c 89 c0             	mov    %r8,%rax
    454c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4551:	f2 0f 58 05 3f b6 01 	addsd  0x1b63f(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4558:	00 
    4559:	f2 0f 11 05 37 b6 01 	movsd  %xmm0,0x1b637(%rip)        # 1fb98 <fwp_heap+0x1438>
    4560:	00 
    4561:	48 83 c4 10          	add    $0x10,%rsp
    4565:	5b                   	pop    %rbx
    4566:	c3                   	ret
    4567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    456e:	00 00 
    4570:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4574:	48 89 3c 24          	mov    %rdi,(%rsp)
    4578:	e8 b3 f3 ff ff       	call   3930 <fwp_heap_init>
    457d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4581:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4586:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    458d:	0f 86 23 ff ff ff    	jbe    44b6 <fwp_heap_alloc_slow+0x26>
    4593:	48 83 c4 10          	add    $0x10,%rsp
    4597:	44 89 ce             	mov    %r9d,%esi
    459a:	48 89 cf             	mov    %rcx,%rdi
    459d:	5b                   	pop    %rbx
    459e:	e9 cd fd ff ff       	jmp    4370 <fwp_heap_alloc_big>
    45a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    45ac:	4d 85 c0             	test   %r8,%r8
    45af:	74 1f                	je     45d0 <fwp_heap_alloc_slow+0x140>
    45b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    45b5:	4d 29 c3             	sub    %r8,%r11
    45b8:	49 39 db             	cmp    %rbx,%r11
    45bb:	72 13                	jb     45d0 <fwp_heap_alloc_slow+0x140>
    45bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    45c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    45c5:	e9 3c ff ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    45ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    45d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    45d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    45db:	44 89 ca             	mov    %r9d,%edx
    45de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    45e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    45e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    45eb:	44 89 d6             	mov    %r10d,%esi
    45ee:	48 01 c7             	add    %rax,%rdi
    45f1:	e8 6a fa ff ff       	call   4060 <fwp_heap_refill>
    45f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    45fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    45ff:	49 89 c0             	mov    %rax,%r8
    4602:	e9 ff fe ff ff       	jmp    4506 <fwp_heap_alloc_slow+0x76>
    4607:	e8 e4 e6 ff ff       	call   2cf0 <fwp_heap_oom>
    460c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000004610 <fwp_rc_fresh>:
    4610:	48 8b 15 21 b5 01 00 	mov    0x1b521(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    4617:	48 89 f8             	mov    %rdi,%rax
    461a:	48 89 fe             	mov    %rdi,%rsi
    461d:	48 2b 05 ec b4 01 00 	sub    0x1b4ec(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4624:	48 c1 e2 10          	shl    $0x10,%rdx
    4628:	48 39 d0             	cmp    %rdx,%rax
    462b:	73 4f                	jae    467c <fwp_rc_fresh+0x6c>
    462d:	48 89 c2             	mov    %rax,%rdx
    4630:	48 c1 ea 10          	shr    $0x10,%rdx
    4634:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4638:	48 8b 15 19 b5 01 00 	mov    0x1b519(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    463f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4643:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4647:	48 85 d2             	test   %rdx,%rdx
    464a:	74 30                	je     467c <fwp_rc_fresh+0x6c>
    464c:	0f b6 39             	movzbl (%rcx),%edi
    464f:	40 80 ff 02          	cmp    $0x2,%dil
    4653:	74 2b                	je     4680 <fwp_rc_fresh+0x70>
    4655:	40 80 ff 01          	cmp    $0x1,%dil
    4659:	75 21                	jne    467c <fwp_rc_fresh+0x6c>
    465b:	8b 79 18             	mov    0x18(%rcx),%edi
    465e:	0f b7 c0             	movzwl %ax,%eax
    4661:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4664:	48 0f af c7          	imul   %rdi,%rax
    4668:	48 c1 e8 20          	shr    $0x20,%rax
    466c:	48 39 c8             	cmp    %rcx,%rax
    466f:	73 0b                	jae    467c <fwp_rc_fresh+0x6c>
    4671:	48 01 c2             	add    %rax,%rdx
    4674:	80 3a ff             	cmpb   $0xff,(%rdx)
    4677:	74 17                	je     4690 <fwp_rc_fresh+0x80>
    4679:	c6 02 01             	movb   $0x1,(%rdx)
    467c:	48 89 f0             	mov    %rsi,%rax
    467f:	c3                   	ret
    4680:	66 85 c0             	test   %ax,%ax
    4683:	74 ef                	je     4674 <fwp_rc_fresh+0x64>
    4685:	48 89 f0             	mov    %rsi,%rax
    4688:	c3                   	ret
    4689:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4690:	48 83 ec 18          	sub    $0x18,%rsp
    4694:	48 89 d7             	mov    %rdx,%rdi
    4697:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    469c:	48 89 14 24          	mov    %rdx,(%rsp)
    46a0:	e8 2b f8 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    46a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    46aa:	48 8b 14 24          	mov    (%rsp),%rdx
    46ae:	48 89 f0             	mov    %rsi,%rax
    46b1:	c6 02 01             	movb   $0x1,(%rdx)
    46b4:	48 83 c4 18          	add    $0x18,%rsp
    46b8:	c3                   	ret
    46b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000046c0 <fwp_rc_free_arr>:
    46c0:	48 8b 15 71 b4 01 00 	mov    0x1b471(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    46c7:	48 89 f8             	mov    %rdi,%rax
    46ca:	48 2b 05 3f b4 01 00 	sub    0x1b43f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    46d1:	48 c1 e2 10          	shl    $0x10,%rdx
    46d5:	48 39 d0             	cmp    %rdx,%rax
    46d8:	73 5b                	jae    4735 <fwp_rc_free_arr+0x75>
    46da:	48 89 c2             	mov    %rax,%rdx
    46dd:	48 c1 ea 10          	shr    $0x10,%rdx
    46e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    46e5:	48 8b 15 6c b4 01 00 	mov    0x1b46c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    46ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    46f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    46f4:	48 85 c9             	test   %rcx,%rcx
    46f7:	74 3c                	je     4735 <fwp_rc_free_arr+0x75>
    46f9:	0f b6 32             	movzbl (%rdx),%esi
    46fc:	40 80 fe 02          	cmp    $0x2,%sil
    4700:	74 2e                	je     4730 <fwp_rc_free_arr+0x70>
    4702:	40 80 fe 01          	cmp    $0x1,%sil
    4706:	75 2d                	jne    4735 <fwp_rc_free_arr+0x75>
    4708:	8b 72 18             	mov    0x18(%rdx),%esi
    470b:	0f b7 c0             	movzwl %ax,%eax
    470e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4711:	48 0f af c6          	imul   %rsi,%rax
    4715:	48 c1 e8 20          	shr    $0x20,%rax
    4719:	48 39 d0             	cmp    %rdx,%rax
    471c:	73 17                	jae    4735 <fwp_rc_free_arr+0x75>
    471e:	48 01 c1             	add    %rax,%rcx
    4721:	80 39 01             	cmpb   $0x1,(%rcx)
    4724:	75 0f                	jne    4735 <fwp_rc_free_arr+0x75>
    4726:	e9 e5 f9 ff ff       	jmp    4110 <fwp_mem_free>
    472b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4730:	66 85 c0             	test   %ax,%ax
    4733:	74 ec                	je     4721 <fwp_rc_free_arr+0x61>
    4735:	c3                   	ret
    4736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    473d:	00 00 00 

0000000000004740 <fwp_heap_alloc>:
    4740:	53                   	push   %rbx
    4741:	48 89 fa             	mov    %rdi,%rdx
    4744:	48 83 ec 10          	sub    $0x10,%rsp
    4748:	8b 1d d2 bc 01 00    	mov    0x1bcd2(%rip),%ebx        # 20420 <iteration_active>
    474e:	8b 05 b0 b3 01 00    	mov    0x1b3b0(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    4754:	85 db                	test   %ebx,%ebx
    4756:	0f 85 04 01 00 00    	jne    4860 <fwp_heap_alloc+0x120>
    475c:	85 c0                	test   %eax,%eax
    475e:	0f 84 ac 01 00 00    	je     4910 <fwp_heap_alloc+0x1d0>
    4764:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    476b:	0f 87 9f 01 00 00    	ja     4910 <fwp_heap_alloc+0x1d0>
    4771:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4775:	48 8d 05 e4 9f 01 00 	lea    0x19fe4(%rip),%rax        # 1e760 <fwp_heap>
    477c:	48 c1 e9 04          	shr    $0x4,%rcx
    4780:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    4787:	00 
    4788:	48 63 ce             	movslq %esi,%rcx
    478b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4792:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    4799:	00 
    479a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    479e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    47a2:	48 01 c8             	add    %rcx,%rax
    47a5:	48 8b 08             	mov    (%rax),%rcx
    47a8:	48 85 c9             	test   %rcx,%rcx
    47ab:	0f 84 ff 00 00 00    	je     48b0 <fwp_heap_alloc+0x170>
    47b1:	48 8b 39             	mov    (%rcx),%rdi
    47b4:	48 f7 d7             	not    %rdi
    47b7:	48 89 38             	mov    %rdi,(%rax)
    47ba:	83 fe 01             	cmp    $0x1,%esi
    47bd:	48 89 cf             	mov    %rcx,%rdi
    47c0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    47c5:	49 0f 45 d0          	cmovne %r8,%rdx
    47c9:	31 f6                	xor    %esi,%esi
    47cb:	e8 d0 dc ff ff       	call   24a0 <memset@plt>
    47d0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    47d5:	48 89 c1             	mov    %rax,%rcx
    47d8:	4c 89 c0             	mov    %r8,%rax
    47db:	48 03 05 9e b3 01 00 	add    0x1b39e(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    47e2:	0f 82 35 01 00 00    	jb     491d <fwp_heap_alloc+0x1dd>
    47e8:	48 39 05 99 b3 01 00 	cmp    %rax,0x1b399(%rip)        # 1fb88 <fwp_heap+0x1428>
    47ef:	48 89 05 8a b3 01 00 	mov    %rax,0x1b38a(%rip)        # 1fb80 <fwp_heap+0x1420>
    47f6:	73 07                	jae    47ff <fwp_heap_alloc+0xbf>
    47f8:	48 89 05 89 b3 01 00 	mov    %rax,0x1b389(%rip)        # 1fb88 <fwp_heap+0x1428>
    47ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4803:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    4808:	f2 0f 58 05 88 b3 01 	addsd  0x1b388(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    480f:	00 
    4810:	f2 0f 11 05 80 b3 01 	movsd  %xmm0,0x1b380(%rip)        # 1fb98 <fwp_heap+0x1438>
    4817:	00 
    4818:	85 db                	test   %ebx,%ebx
    481a:	74 33                	je     484f <fwp_heap_alloc+0x10f>
    481c:	48 8b 05 5d b3 01 00 	mov    0x1b35d(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4823:	48 85 c0             	test   %rax,%rax
    4826:	0f 88 ac 00 00 00    	js     48d8 <fwp_heap_alloc+0x198>
    482c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4830:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4835:	f2 0f 5c 05 c3 bb 01 	subsd  0x1bbc3(%rip),%xmm0        # 20400 <iteration_start_charge>
    483c:	00 
    483d:	66 0f 2f 05 b3 bb 01 	comisd 0x1bbb3(%rip),%xmm0        # 203f8 <iteration_peak>
    4844:	00 
    4845:	76 08                	jbe    484f <fwp_heap_alloc+0x10f>
    4847:	f2 0f 11 05 a9 bb 01 	movsd  %xmm0,0x1bba9(%rip)        # 203f8 <iteration_peak>
    484e:	00 
    484f:	48 83 c4 10          	add    $0x10,%rsp
    4853:	48 89 c8             	mov    %rcx,%rax
    4856:	5b                   	pop    %rbx
    4857:	c3                   	ret
    4858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    485f:	00 
    4860:	85 f6                	test   %esi,%esi
    4862:	74 34                	je     4898 <fwp_heap_alloc+0x158>
    4864:	48 83 05 ac bb 01 00 	addq   $0x1,0x1bbac(%rip)        # 20418 <iteration_requests>
    486b:	01 
    486c:	48 01 3d 9d bb 01 00 	add    %rdi,0x1bb9d(%rip)        # 20410 <iteration_bytes>
    4873:	85 c0                	test   %eax,%eax
    4875:	74 0d                	je     4884 <fwp_heap_alloc+0x144>
    4877:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    487e:	0f 86 ed fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    4884:	48 89 d7             	mov    %rdx,%rdi
    4887:	e8 04 fc ff ff       	call   4490 <fwp_heap_alloc_slow>
    488c:	48 89 c1             	mov    %rax,%rcx
    488f:	eb 8b                	jmp    481c <fwp_heap_alloc+0xdc>
    4891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4898:	85 c0                	test   %eax,%eax
    489a:	74 0d                	je     48a9 <fwp_heap_alloc+0x169>
    489c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    48a3:	0f 86 c8 fe ff ff    	jbe    4771 <fwp_heap_alloc+0x31>
    48a9:	31 f6                	xor    %esi,%esi
    48ab:	eb d7                	jmp    4884 <fwp_heap_alloc+0x144>
    48ad:	0f 1f 00             	nopl   (%rax)
    48b0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    48b4:	48 85 c9             	test   %rcx,%rcx
    48b7:	74 0c                	je     48c5 <fwp_heap_alloc+0x185>
    48b9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    48bd:	48 29 cf             	sub    %rcx,%rdi
    48c0:	4c 39 c7             	cmp    %r8,%rdi
    48c3:	73 3b                	jae    4900 <fwp_heap_alloc+0x1c0>
    48c5:	48 89 d7             	mov    %rdx,%rdi
    48c8:	e8 c3 fb ff ff       	call   4490 <fwp_heap_alloc_slow>
    48cd:	48 89 c1             	mov    %rax,%rcx
    48d0:	e9 43 ff ff ff       	jmp    4818 <fwp_heap_alloc+0xd8>
    48d5:	0f 1f 00             	nopl   (%rax)
    48d8:	48 89 c2             	mov    %rax,%rdx
    48db:	83 e0 01             	and    $0x1,%eax
    48de:	66 0f ef c0          	pxor   %xmm0,%xmm0
    48e2:	48 d1 ea             	shr    $1,%rdx
    48e5:	48 09 c2             	or     %rax,%rdx
    48e8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    48ed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    48f1:	e9 3f ff ff ff       	jmp    4835 <fwp_heap_alloc+0xf5>
    48f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    48fd:	00 00 00 
    4900:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    4904:	48 89 78 08          	mov    %rdi,0x8(%rax)
    4908:	e9 ad fe ff ff       	jmp    47ba <fwp_heap_alloc+0x7a>
    490d:	0f 1f 00             	nopl   (%rax)
    4910:	48 83 c4 10          	add    $0x10,%rsp
    4914:	48 89 d7             	mov    %rdx,%rdi
    4917:	5b                   	pop    %rbx
    4918:	e9 73 fb ff ff       	jmp    4490 <fwp_heap_alloc_slow>
    491d:	e8 ce e3 ff ff       	call   2cf0 <fwp_heap_oom>
    4922:	0f 1f 00             	nopl   (%rax)
    4925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    492c:	00 00 00 00 

0000000000004930 <fwp_data.part.0.constprop.0>:
    4930:	41 55                	push   %r13
    4932:	41 54                	push   %r12
    4934:	49 89 fc             	mov    %rdi,%r12
    4937:	55                   	push   %rbp
    4938:	53                   	push   %rbx
    4939:	48 83 ec 08          	sub    $0x8,%rsp
    493d:	44 8b 2d dc ba 01 00 	mov    0x1badc(%rip),%r13d        # 20420 <iteration_active>
    4944:	8b 05 ba b1 01 00    	mov    0x1b1ba(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    494a:	45 85 ed             	test   %r13d,%r13d
    494d:	0f 84 0d 01 00 00    	je     4a60 <fwp_data.part.0.constprop.0+0x130>
    4953:	48 83 05 bd ba 01 00 	addq   $0x1,0x1babd(%rip)        # 20418 <iteration_requests>
    495a:	01 
    495b:	48 83 05 ad ba 01 00 	addq   $0x18,0x1baad(%rip)        # 20410 <iteration_bytes>
    4962:	18 
    4963:	85 c0                	test   %eax,%eax
    4965:	0f 84 7d 01 00 00    	je     4ae8 <fwp_data.part.0.constprop.0+0x1b8>
    496b:	0f b6 05 90 ad 01 00 	movzbl 0x1ad90(%rip),%eax        # 1f702 <fwp_heap+0xfa2>
    4972:	48 8d 15 e7 9d 01 00 	lea    0x19de7(%rip),%rdx        # 1e760 <fwp_heap>
    4979:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    4980:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4984:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    4988:	48 8b 18             	mov    (%rax),%rbx
    498b:	48 85 db             	test   %rbx,%rbx
    498e:	0f 84 ec 00 00 00    	je     4a80 <fwp_data.part.0.constprop.0+0x150>
    4994:	48 8b 13             	mov    (%rbx),%rdx
    4997:	48 f7 d2             	not    %rdx
    499a:	48 89 10             	mov    %rdx,(%rax)
    499d:	48 83 fd 18          	cmp    $0x18,%rbp
    49a1:	76 1b                	jbe    49be <fwp_data.part.0.constprop.0+0x8e>
    49a3:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    49a7:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    49ab:	31 f6                	xor    %esi,%esi
    49ad:	48 c1 e8 03          	shr    $0x3,%rax
    49b1:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    49b8:	00 
    49b9:	e8 e2 da ff ff       	call   24a0 <memset@plt>
    49be:	48 89 e8             	mov    %rbp,%rax
    49c1:	48 03 05 b8 b1 01 00 	add    0x1b1b8(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    49c8:	0f 82 2e 01 00 00    	jb     4afc <fwp_data.part.0.constprop.0+0x1cc>
    49ce:	48 39 05 b3 b1 01 00 	cmp    %rax,0x1b1b3(%rip)        # 1fb88 <fwp_heap+0x1428>
    49d5:	48 89 05 a4 b1 01 00 	mov    %rax,0x1b1a4(%rip)        # 1fb80 <fwp_heap+0x1420>
    49dc:	73 07                	jae    49e5 <fwp_data.part.0.constprop.0+0xb5>
    49de:	48 89 05 a3 b1 01 00 	mov    %rax,0x1b1a3(%rip)        # 1fb88 <fwp_heap+0x1428>
    49e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49e9:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    49ee:	f2 0f 58 05 a2 b1 01 	addsd  0x1b1a2(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    49f5:	00 
    49f6:	f2 0f 11 05 9a b1 01 	movsd  %xmm0,0x1b19a(%rip)        # 1fb98 <fwp_heap+0x1438>
    49fd:	00 
    49fe:	45 85 ed             	test   %r13d,%r13d
    4a01:	74 33                	je     4a36 <fwp_data.part.0.constprop.0+0x106>
    4a03:	48 8b 05 76 b1 01 00 	mov    0x1b176(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    4a0a:	48 85 c0             	test   %rax,%rax
    4a0d:	0f 88 95 00 00 00    	js     4aa8 <fwp_data.part.0.constprop.0+0x178>
    4a13:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4a17:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    4a1c:	f2 0f 5c 05 dc b9 01 	subsd  0x1b9dc(%rip),%xmm0        # 20400 <iteration_start_charge>
    4a23:	00 
    4a24:	66 0f 2f 05 cc b9 01 	comisd 0x1b9cc(%rip),%xmm0        # 203f8 <iteration_peak>
    4a2b:	00 
    4a2c:	76 08                	jbe    4a36 <fwp_data.part.0.constprop.0+0x106>
    4a2e:	f2 0f 11 05 c2 b9 01 	movsd  %xmm0,0x1b9c2(%rip)        # 203f8 <iteration_peak>
    4a35:	00 
    4a36:	48 8b 05 f3 6b 00 00 	mov    0x6bf3(%rip),%rax        # b630 <msg.3+0x60>
    4a3d:	48 89 03             	mov    %rax,(%rbx)
    4a40:	49 8b 04 24          	mov    (%r12),%rax
    4a44:	48 89 43 08          	mov    %rax,0x8(%rbx)
    4a48:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    4a4d:	48 89 43 10          	mov    %rax,0x10(%rbx)
    4a51:	48 83 c4 08          	add    $0x8,%rsp
    4a55:	48 89 d8             	mov    %rbx,%rax
    4a58:	5b                   	pop    %rbx
    4a59:	5d                   	pop    %rbp
    4a5a:	41 5c                	pop    %r12
    4a5c:	41 5d                	pop    %r13
    4a5e:	c3                   	ret
    4a5f:	90                   	nop
    4a60:	85 c0                	test   %eax,%eax
    4a62:	0f 85 03 ff ff ff    	jne    496b <fwp_data.part.0.constprop.0+0x3b>
    4a68:	31 f6                	xor    %esi,%esi
    4a6a:	bf 18 00 00 00       	mov    $0x18,%edi
    4a6f:	e8 cc fc ff ff       	call   4740 <fwp_heap_alloc>
    4a74:	48 89 c3             	mov    %rax,%rbx
    4a77:	eb bd                	jmp    4a36 <fwp_data.part.0.constprop.0+0x106>
    4a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a80:	48 8b 58 08          	mov    0x8(%rax),%rbx
    4a84:	48 85 db             	test   %rbx,%rbx
    4a87:	74 47                	je     4ad0 <fwp_data.part.0.constprop.0+0x1a0>
    4a89:	48 8b 50 10          	mov    0x10(%rax),%rdx
    4a8d:	48 29 da             	sub    %rbx,%rdx
    4a90:	48 39 ea             	cmp    %rbp,%rdx
    4a93:	72 3b                	jb     4ad0 <fwp_data.part.0.constprop.0+0x1a0>
    4a95:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4a99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4a9d:	e9 fb fe ff ff       	jmp    499d <fwp_data.part.0.constprop.0+0x6d>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	48 89 c2             	mov    %rax,%rdx
    4aab:	83 e0 01             	and    $0x1,%eax
    4aae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4ab2:	48 d1 ea             	shr    $1,%rdx
    4ab5:	48 09 c2             	or     %rax,%rdx
    4ab8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    4abd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    4ac1:	e9 56 ff ff ff       	jmp    4a1c <fwp_data.part.0.constprop.0+0xec>
    4ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4acd:	00 00 00 
    4ad0:	31 f6                	xor    %esi,%esi
    4ad2:	bf 18 00 00 00       	mov    $0x18,%edi
    4ad7:	e8 64 fc ff ff       	call   4740 <fwp_heap_alloc>
    4adc:	48 89 c3             	mov    %rax,%rbx
    4adf:	e9 1a ff ff ff       	jmp    49fe <fwp_data.part.0.constprop.0+0xce>
    4ae4:	0f 1f 40 00          	nopl   0x0(%rax)
    4ae8:	31 f6                	xor    %esi,%esi
    4aea:	bf 18 00 00 00       	mov    $0x18,%edi
    4aef:	e8 4c fc ff ff       	call   4740 <fwp_heap_alloc>
    4af4:	48 89 c3             	mov    %rax,%rbx
    4af7:	e9 07 ff ff ff       	jmp    4a03 <fwp_data.part.0.constprop.0+0xd3>
    4afc:	e8 ef e1 ff ff       	call   2cf0 <fwp_heap_oom>
    4b01:	0f 1f 40 00          	nopl   0x0(%rax)
    4b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b0c:	00 00 00 00 

0000000000004b10 <fwp_array_new_packed.constprop.0>:
    4b10:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4b17:	ff ff 1f 
    4b1a:	53                   	push   %rbx
    4b1b:	48 39 f8             	cmp    %rdi,%rax
    4b1e:	72 1a                	jb     4b3a <fwp_array_new_packed.constprop.0+0x2a>
    4b20:	48 89 fb             	mov    %rdi,%rbx
    4b23:	be 01 00 00 00       	mov    $0x1,%esi
    4b28:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    4b2f:	00 
    4b30:	e8 0b fc ff ff       	call   4740 <fwp_heap_alloc>
    4b35:	48 89 18             	mov    %rbx,(%rax)
    4b38:	5b                   	pop    %rbx
    4b39:	c3                   	ret
    4b3a:	48 8d 3d a4 65 00 00 	lea    0x65a4(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    4b41:	e8 ba e6 ff ff       	call   3200 <fwp_trap>
    4b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4b4d:	00 00 00 

0000000000004b50 <fwp_task_dispose>:
    4b50:	53                   	push   %rbx
    4b51:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4b55:	0f 84 ab db ff ff    	je     2706 <fwp_task_dispose.cold>
    4b5b:	48 89 fb             	mov    %rdi,%rbx
    4b5e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4b63:	0f 85 9d db ff ff    	jne    2706 <fwp_task_dispose.cold>
    4b69:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    4b6d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4b74:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    4b7b:	00 
    4b7c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4b80:	48 85 ff             	test   %rdi,%rdi
    4b83:	74 07                	je     4b8c <fwp_task_dispose+0x3c>
    4b85:	48 85 c0             	test   %rax,%rax
    4b88:	74 02                	je     4b8c <fwp_task_dispose+0x3c>
    4b8a:	ff d0                	call   *%rax
    4b8c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4b93:	e8 78 f5 ff ff       	call   4110 <fwp_mem_free>
    4b98:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    4b9f:	00 00 00 00 
    4ba3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4ba7:	74 6f                	je     4c18 <fwp_task_dispose+0xc8>
    4ba9:	48 8b 15 88 af 01 00 	mov    0x1af88(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    4bb0:	48 89 d8             	mov    %rbx,%rax
    4bb3:	48 2b 05 56 af 01 00 	sub    0x1af56(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4bba:	48 c1 e2 10          	shl    $0x10,%rdx
    4bbe:	48 39 d0             	cmp    %rdx,%rax
    4bc1:	73 4c                	jae    4c0f <fwp_task_dispose+0xbf>
    4bc3:	48 89 c2             	mov    %rax,%rdx
    4bc6:	48 c1 ea 10          	shr    $0x10,%rdx
    4bca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4bce:	48 8b 15 83 af 01 00 	mov    0x1af83(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    4bd5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4bd9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4bdd:	48 85 c9             	test   %rcx,%rcx
    4be0:	74 2d                	je     4c0f <fwp_task_dispose+0xbf>
    4be2:	0f b6 32             	movzbl (%rdx),%esi
    4be5:	40 80 fe 02          	cmp    $0x2,%sil
    4be9:	74 3d                	je     4c28 <fwp_task_dispose+0xd8>
    4beb:	40 80 fe 01          	cmp    $0x1,%sil
    4bef:	75 1e                	jne    4c0f <fwp_task_dispose+0xbf>
    4bf1:	8b 72 18             	mov    0x18(%rdx),%esi
    4bf4:	0f b7 c0             	movzwl %ax,%eax
    4bf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4bfa:	48 0f af c6          	imul   %rsi,%rax
    4bfe:	48 c1 e8 20          	shr    $0x20,%rax
    4c02:	48 39 d0             	cmp    %rdx,%rax
    4c05:	73 08                	jae    4c0f <fwp_task_dispose+0xbf>
    4c07:	48 01 c1             	add    %rax,%rcx
    4c0a:	80 39 01             	cmpb   $0x1,(%rcx)
    4c0d:	74 09                	je     4c18 <fwp_task_dispose+0xc8>
    4c0f:	5b                   	pop    %rbx
    4c10:	c3                   	ret
    4c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c18:	48 89 df             	mov    %rbx,%rdi
    4c1b:	5b                   	pop    %rbx
    4c1c:	e9 ef f4 ff ff       	jmp    4110 <fwp_mem_free>
    4c21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c28:	66 85 c0             	test   %ax,%ax
    4c2b:	74 dd                	je     4c0a <fwp_task_dispose+0xba>
    4c2d:	5b                   	pop    %rbx
    4c2e:	c3                   	ret
    4c2f:	90                   	nop

0000000000004c30 <fwp_free_zombie>:
    4c30:	48 8b 15 f9 9a 01 00 	mov    0x19af9(%rip),%rdx        # 1e730 <fwp_zombie>
    4c37:	48 85 d2             	test   %rdx,%rdx
    4c3a:	0f 84 98 00 00 00    	je     4cd8 <fwp_free_zombie+0xa8>
    4c40:	48 3b 15 f9 9a 01 00 	cmp    0x19af9(%rip),%rdx        # 1e740 <fwp_cur>
    4c47:	0f 84 8b 00 00 00    	je     4cd8 <fwp_free_zombie+0xa8>
    4c4d:	48 83 ec 18          	sub    $0x18,%rsp
    4c51:	48 63 05 ac 94 01 00 	movslq 0x194ac(%rip),%rax        # 1e104 <fwp_stack_pool_n>
    4c58:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4c5c:	83 f8 3f             	cmp    $0x3f,%eax
    4c5f:	7f 7f                	jg     4ce0 <fwp_free_zombie+0xb0>
    4c61:	8d 48 01             	lea    0x1(%rax),%ecx
    4c64:	89 0d 9a 94 01 00    	mov    %ecx,0x1949a(%rip)        # 1e104 <fwp_stack_pool_n>
    4c6a:	48 8d 0d af 94 01 00 	lea    0x194af(%rip),%rcx        # 1e120 <fwp_stack_pool>
    4c71:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4c75:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4c7c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4c80:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4c87:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4c8b:	48 85 c9             	test   %rcx,%rcx
    4c8e:	0f 84 fc 00 00 00    	je     4d90 <fwp_free_zombie+0x160>
    4c94:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4c9b:	48 85 c0             	test   %rax,%rax
    4c9e:	74 07                	je     4ca7 <fwp_free_zombie+0x77>
    4ca0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4ca7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4caa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4cae:	48 c7 05 77 9a 01 00 	movq   $0x0,0x19a77(%rip)        # 1e730 <fwp_zombie>
    4cb5:	00 00 00 00 
    4cb9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4cc0:	85 c0                	test   %eax,%eax
    4cc2:	74 34                	je     4cf8 <fwp_free_zombie+0xc8>
    4cc4:	83 f8 01             	cmp    $0x1,%eax
    4cc7:	0f 84 b3 00 00 00    	je     4d80 <fwp_free_zombie+0x150>
    4ccd:	48 83 c4 18          	add    $0x18,%rsp
    4cd1:	c3                   	ret
    4cd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4cd8:	c3                   	ret
    4cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ce0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4ce4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4ce9:	e8 c2 d8 ff ff       	call   25b0 <munmap@plt>
    4cee:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4cf3:	eb 80                	jmp    4c75 <fwp_free_zombie+0x45>
    4cf5:	0f 1f 00             	nopl   (%rax)
    4cf8:	48 8b 0d 39 ae 01 00 	mov    0x1ae39(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    4cff:	48 89 d0             	mov    %rdx,%rax
    4d02:	48 2b 05 07 ae 01 00 	sub    0x1ae07(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4d09:	48 c1 e1 10          	shl    $0x10,%rcx
    4d0d:	48 39 c8             	cmp    %rcx,%rax
    4d10:	73 bb                	jae    4ccd <fwp_free_zombie+0x9d>
    4d12:	48 89 c1             	mov    %rax,%rcx
    4d15:	48 c1 e9 10          	shr    $0x10,%rcx
    4d19:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4d1d:	48 8b 0d 34 ae 01 00 	mov    0x1ae34(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    4d24:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4d28:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4d2c:	48 85 c9             	test   %rcx,%rcx
    4d2f:	74 9c                	je     4ccd <fwp_free_zombie+0x9d>
    4d31:	0f b6 3e             	movzbl (%rsi),%edi
    4d34:	40 80 ff 02          	cmp    $0x2,%dil
    4d38:	74 66                	je     4da0 <fwp_free_zombie+0x170>
    4d3a:	40 80 ff 01          	cmp    $0x1,%dil
    4d3e:	75 8d                	jne    4ccd <fwp_free_zombie+0x9d>
    4d40:	8b 7e 18             	mov    0x18(%rsi),%edi
    4d43:	0f b7 c0             	movzwl %ax,%eax
    4d46:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4d49:	48 0f af c7          	imul   %rdi,%rax
    4d4d:	48 c1 e8 20          	shr    $0x20,%rax
    4d51:	48 39 f0             	cmp    %rsi,%rax
    4d54:	0f 83 73 ff ff ff    	jae    4ccd <fwp_free_zombie+0x9d>
    4d5a:	48 01 c1             	add    %rax,%rcx
    4d5d:	0f b6 01             	movzbl (%rcx),%eax
    4d60:	84 c0                	test   %al,%al
    4d62:	0f 84 65 ff ff ff    	je     4ccd <fwp_free_zombie+0x9d>
    4d68:	3c 01                	cmp    $0x1,%al
    4d6a:	74 14                	je     4d80 <fwp_free_zombie+0x150>
    4d6c:	3c ff                	cmp    $0xff,%al
    4d6e:	74 3b                	je     4dab <fwp_free_zombie+0x17b>
    4d70:	83 e8 01             	sub    $0x1,%eax
    4d73:	88 01                	mov    %al,(%rcx)
    4d75:	e9 53 ff ff ff       	jmp    4ccd <fwp_free_zombie+0x9d>
    4d7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d80:	48 89 d7             	mov    %rdx,%rdi
    4d83:	48 83 c4 18          	add    $0x18,%rsp
    4d87:	e9 c4 fd ff ff       	jmp    4b50 <fwp_task_dispose>
    4d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    4d90:	48 89 05 71 99 01 00 	mov    %rax,0x19971(%rip)        # 1e708 <fwp_tasks_active>
    4d97:	e9 ff fe ff ff       	jmp    4c9b <fwp_free_zombie+0x6b>
    4d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    4da0:	66 85 c0             	test   %ax,%ax
    4da3:	0f 85 24 ff ff ff    	jne    4ccd <fwp_free_zombie+0x9d>
    4da9:	eb b2                	jmp    4d5d <fwp_free_zombie+0x12d>
    4dab:	48 89 ca             	mov    %rcx,%rdx
    4dae:	48 8d 35 ab 99 01 00 	lea    0x199ab(%rip),%rsi        # 1e760 <fwp_heap>
    4db5:	48 c1 ea 11          	shr    $0x11,%rdx
    4db9:	48 31 ca             	xor    %rcx,%rdx
    4dbc:	48 89 d0             	mov    %rdx,%rax
    4dbf:	48 c1 e8 09          	shr    $0x9,%rax
    4dc3:	48 31 c2             	xor    %rax,%rdx
    4dc6:	0f b6 d2             	movzbl %dl,%edx
    4dc9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4dd0:	00 
    4dd1:	48 85 c0             	test   %rax,%rax
    4dd4:	75 13                	jne    4de9 <fwp_free_zombie+0x1b9>
    4dd6:	eb 4c                	jmp    4e24 <fwp_free_zombie+0x1f4>
    4dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4ddf:	00 
    4de0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4de4:	48 85 c0             	test   %rax,%rax
    4de7:	74 3b                	je     4e24 <fwp_free_zombie+0x1f4>
    4de9:	48 89 c2             	mov    %rax,%rdx
    4dec:	48 39 08             	cmp    %rcx,(%rax)
    4def:	75 ef                	jne    4de0 <fwp_free_zombie+0x1b0>
    4df1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4df5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4df9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4dfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4e04:	0f 85 c3 fe ff ff    	jne    4ccd <fwp_free_zombie+0x9d>
    4e0a:	48 89 cf             	mov    %rcx,%rdi
    4e0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e12:	e8 b9 f0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    4e17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4e1f:	e9 a9 fe ff ff       	jmp    4ccd <fwp_free_zombie+0x9d>
    4e24:	48 8d 3d 75 65 00 00 	lea    0x6575(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    4e2b:	e8 d0 e3 ff ff       	call   3200 <fwp_trap>

0000000000004e30 <fwp_block>:
    4e30:	48 83 ec 08          	sub    $0x8,%rsp
    4e34:	48 8b 05 ed 98 01 00 	mov    0x198ed(%rip),%rax        # 1e728 <fwp_ready_head>
    4e3b:	48 85 c0             	test   %rax,%rax
    4e3e:	0f 84 1c 01 00 00    	je     4f60 <fwp_block+0x130>
    4e44:	90                   	nop
    4e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e4c:	00 00 00 00 
    4e50:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4e57:	48 89 15 ca 98 01 00 	mov    %rdx,0x198ca(%rip)        # 1e728 <fwp_ready_head>
    4e5e:	48 85 d2             	test   %rdx,%rdx
    4e61:	0f 84 19 01 00 00    	je     4f80 <fwp_block+0x150>
    4e67:	48 8b 15 d2 98 01 00 	mov    0x198d2(%rip),%rdx        # 1e740 <fwp_cur>
    4e6e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4e72:	48 39 c2             	cmp    %rax,%rdx
    4e75:	0f 84 d5 00 00 00    	je     4f50 <fwp_block+0x120>
    4e7b:	48 8b 0d 3e b5 01 00 	mov    0x1b53e(%rip),%rcx        # 203c0 <fwp_state_owners>
    4e82:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4e86:	48 89 05 b3 98 01 00 	mov    %rax,0x198b3(%rip)        # 1e740 <fwp_cur>
    4e8d:	f3 0f 7e 05 53 b5 01 	movq   0x1b553(%rip),%xmm0        # 203e8 <fwp_foreign_callbacks>
    4e94:	00 
    4e95:	0f 16 05 3c b5 01 00 	movhps 0x1b53c(%rip),%xmm0        # 203d8 <fwp_state>
    4e9c:	f3 0f 7e 0d 3c b5 01 	movq   0x1b53c(%rip),%xmm1        # 203e0 <fwp_handlers>
    4ea3:	00 
    4ea4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4eab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4eb2:	0f 16 0d 37 b5 01 00 	movhps 0x1b537(%rip),%xmm1        # 203f0 <fwp_cleanups>
    4eb9:	f3 0f 7e 05 0f b5 01 	movq   0x1b50f(%rip),%xmm0        # 203d0 <fwp_state_len>
    4ec0:	00 
    4ec1:	0f 16 05 00 b5 01 00 	movhps 0x1b500(%rip),%xmm0        # 203c8 <fwp_state_cap>
    4ec8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4ecf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4ed6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4eda:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4ee1:	48 89 0d f8 b4 01 00 	mov    %rcx,0x1b4f8(%rip)        # 203e0 <fwp_handlers>
    4ee8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4eef:	48 89 0d fa b4 01 00 	mov    %rcx,0x1b4fa(%rip)        # 203f0 <fwp_cleanups>
    4ef6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4efd:	48 89 0d e4 b4 01 00 	mov    %rcx,0x1b4e4(%rip)        # 203e8 <fwp_foreign_callbacks>
    4f04:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4f0b:	48 89 0d c6 b4 01 00 	mov    %rcx,0x1b4c6(%rip)        # 203d8 <fwp_state>
    4f12:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4f19:	48 89 0d b0 b4 01 00 	mov    %rcx,0x1b4b0(%rip)        # 203d0 <fwp_state_len>
    4f20:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4f27:	48 89 0d 9a b4 01 00 	mov    %rcx,0x1b49a(%rip)        # 203c8 <fwp_state_cap>
    4f2e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4f35:	48 89 0d 84 b4 01 00 	mov    %rcx,0x1b484(%rip)        # 203c0 <fwp_state_owners>
    4f3c:	e8 2f d5 ff ff       	call   2470 <swapcontext@plt>
    4f41:	f3 0f 1e fa          	endbr64
    4f45:	e8 e6 fc ff ff       	call   4c30 <fwp_free_zombie>
    4f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f50:	8b 05 aa 91 01 00    	mov    0x191aa(%rip),%eax        # 1e100 <fwp_slice>
    4f56:	85 c0                	test   %eax,%eax
    4f58:	74 36                	je     4f90 <fwp_block+0x160>
    4f5a:	48 83 c4 08          	add    $0x8,%rsp
    4f5e:	c3                   	ret
    4f5f:	90                   	nop
    4f60:	e8 cb ec ff ff       	call   3c30 <fwp_poll_events>
    4f65:	48 8b 05 bc 97 01 00 	mov    0x197bc(%rip),%rax        # 1e728 <fwp_ready_head>
    4f6c:	48 85 c0             	test   %rax,%rax
    4f6f:	0f 85 db fe ff ff    	jne    4e50 <fwp_block+0x20>
    4f75:	eb e9                	jmp    4f60 <fwp_block+0x130>
    4f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4f7e:	00 00 
    4f80:	48 c7 05 95 97 01 00 	movq   $0x0,0x19795(%rip)        # 1e720 <fwp_ready_tail>
    4f87:	00 00 00 00 
    4f8b:	e9 d7 fe ff ff       	jmp    4e67 <fwp_block+0x37>
    4f90:	48 8d 3d 5e 61 00 00 	lea    0x615e(%rip),%rdi        # b0f5 <_IO_stdin_used+0xf5>
    4f97:	e8 e4 d3 ff ff       	call   2380 <getenv@plt>
    4f9c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4fa1:	48 85 c0             	test   %rax,%rax
    4fa4:	74 05                	je     4fab <fwp_block+0x17b>
    4fa6:	80 38 00             	cmpb   $0x0,(%rax)
    4fa9:	75 0b                	jne    4fb6 <fwp_block+0x186>
    4fab:	89 15 4f 91 01 00    	mov    %edx,0x1914f(%rip)        # 1e100 <fwp_slice>
    4fb1:	48 83 c4 08          	add    $0x8,%rsp
    4fb5:	c3                   	ret
    4fb6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4fbb:	31 f6                	xor    %esi,%esi
    4fbd:	48 89 c7             	mov    %rax,%rdi
    4fc0:	e8 6b d5 ff ff       	call   2530 <strtoll@plt>
    4fc5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4fc9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4fd0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4fd5:	0f 46 d0             	cmovbe %eax,%edx
    4fd8:	eb d1                	jmp    4fab <fwp_block+0x17b>
    4fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004fe0 <fwp_drop0>:
    4fe0:	48 8b 15 51 ab 01 00 	mov    0x1ab51(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    4fe7:	48 89 f8             	mov    %rdi,%rax
    4fea:	48 2b 05 1f ab 01 00 	sub    0x1ab1f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    4ff1:	48 c1 e2 10          	shl    $0x10,%rdx
    4ff5:	48 39 d0             	cmp    %rdx,%rax
    4ff8:	0f 83 c2 00 00 00    	jae    50c0 <fwp_drop0+0xe0>
    4ffe:	48 83 ec 18          	sub    $0x18,%rsp
    5002:	4c 8d 05 57 97 01 00 	lea    0x19757(%rip),%r8        # 1e760 <fwp_heap>
    5009:	48 89 c2             	mov    %rax,%rdx
    500c:	48 c1 ea 10          	shr    $0x10,%rdx
    5010:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5014:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    501b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    501f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5023:	48 85 d2             	test   %rdx,%rdx
    5026:	74 3c                	je     5064 <fwp_drop0+0x84>
    5028:	0f b6 31             	movzbl (%rcx),%esi
    502b:	40 80 fe 02          	cmp    $0x2,%sil
    502f:	74 3f                	je     5070 <fwp_drop0+0x90>
    5031:	40 80 fe 01          	cmp    $0x1,%sil
    5035:	75 2d                	jne    5064 <fwp_drop0+0x84>
    5037:	8b 71 18             	mov    0x18(%rcx),%esi
    503a:	0f b7 c0             	movzwl %ax,%eax
    503d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5040:	48 0f af c6          	imul   %rsi,%rax
    5044:	48 c1 e8 20          	shr    $0x20,%rax
    5048:	48 39 c8             	cmp    %rcx,%rax
    504b:	73 17                	jae    5064 <fwp_drop0+0x84>
    504d:	48 01 c2             	add    %rax,%rdx
    5050:	0f b6 02             	movzbl (%rdx),%eax
    5053:	84 c0                	test   %al,%al
    5055:	74 0d                	je     5064 <fwp_drop0+0x84>
    5057:	3c 01                	cmp    $0x1,%al
    5059:	74 25                	je     5080 <fwp_drop0+0xa0>
    505b:	3c ff                	cmp    $0xff,%al
    505d:	74 69                	je     50c8 <fwp_drop0+0xe8>
    505f:	83 e8 01             	sub    $0x1,%eax
    5062:	88 02                	mov    %al,(%rdx)
    5064:	48 83 c4 18          	add    $0x18,%rsp
    5068:	c3                   	ret
    5069:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5070:	66 85 c0             	test   %ax,%ax
    5073:	74 db                	je     5050 <fwp_drop0+0x70>
    5075:	48 83 c4 18          	add    $0x18,%rsp
    5079:	c3                   	ret
    507a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5080:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    5084:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5089:	e8 32 f6 ff ff       	call   46c0 <fwp_rc_free_arr>
    508e:	4c 8d 05 cb 96 01 00 	lea    0x196cb(%rip),%r8        # 1e760 <fwp_heap>
    5095:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    509a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    50a1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    50a8:	48 c1 e2 10          	shl    $0x10,%rdx
    50ac:	48 39 d0             	cmp    %rdx,%rax
    50af:	73 b3                	jae    5064 <fwp_drop0+0x84>
    50b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    50b6:	e9 4e ff ff ff       	jmp    5009 <fwp_drop0+0x29>
    50bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c8:	48 89 d0             	mov    %rdx,%rax
    50cb:	48 c1 e8 11          	shr    $0x11,%rax
    50cf:	48 31 d0             	xor    %rdx,%rax
    50d2:	48 89 c1             	mov    %rax,%rcx
    50d5:	48 c1 e9 09          	shr    $0x9,%rcx
    50d9:	48 31 c8             	xor    %rcx,%rax
    50dc:	0f b6 c8             	movzbl %al,%ecx
    50df:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    50e6:	00 
    50e7:	48 85 c0             	test   %rax,%rax
    50ea:	75 1d                	jne    5109 <fwp_drop0+0x129>
    50ec:	eb 56                	jmp    5144 <fwp_drop0+0x164>
    50ee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50fc:	00 00 00 00 
    5100:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5104:	48 85 c0             	test   %rax,%rax
    5107:	74 3b                	je     5144 <fwp_drop0+0x164>
    5109:	48 89 c1             	mov    %rax,%rcx
    510c:	48 39 10             	cmp    %rdx,(%rax)
    510f:	75 ef                	jne    5100 <fwp_drop0+0x120>
    5111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5115:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5119:	48 89 48 08          	mov    %rcx,0x8(%rax)
    511d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5124:	0f 85 3a ff ff ff    	jne    5064 <fwp_drop0+0x84>
    512a:	48 89 d7             	mov    %rdx,%rdi
    512d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5132:	e8 99 ed ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5137:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    513c:	c6 02 fe             	movb   $0xfe,(%rdx)
    513f:	e9 20 ff ff ff       	jmp    5064 <fwp_drop0+0x84>
    5144:	48 8d 3d 55 62 00 00 	lea    0x6255(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    514b:	e8 b0 e0 ff ff       	call   3200 <fwp_trap>

0000000000005150 <fwp_drop1>:
    5150:	f3 0f 1e fa          	endbr64
    5154:	48 8b 15 dd a9 01 00 	mov    0x1a9dd(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    515b:	48 89 f8             	mov    %rdi,%rax
    515e:	48 2b 05 ab a9 01 00 	sub    0x1a9ab(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    5165:	48 c1 e2 10          	shl    $0x10,%rdx
    5169:	48 39 d0             	cmp    %rdx,%rax
    516c:	0f 83 be 00 00 00    	jae    5230 <fwp_drop1+0xe0>
    5172:	48 83 ec 18          	sub    $0x18,%rsp
    5176:	4c 8d 05 e3 95 01 00 	lea    0x195e3(%rip),%r8        # 1e760 <fwp_heap>
    517d:	48 89 c2             	mov    %rax,%rdx
    5180:	48 c1 ea 10          	shr    $0x10,%rdx
    5184:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5188:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    518f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5193:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5197:	48 85 d2             	test   %rdx,%rdx
    519a:	74 3c                	je     51d8 <fwp_drop1+0x88>
    519c:	0f b6 31             	movzbl (%rcx),%esi
    519f:	40 80 fe 02          	cmp    $0x2,%sil
    51a3:	74 3b                	je     51e0 <fwp_drop1+0x90>
    51a5:	40 80 fe 01          	cmp    $0x1,%sil
    51a9:	75 2d                	jne    51d8 <fwp_drop1+0x88>
    51ab:	8b 71 18             	mov    0x18(%rcx),%esi
    51ae:	0f b7 c0             	movzwl %ax,%eax
    51b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    51b4:	48 0f af c6          	imul   %rsi,%rax
    51b8:	48 c1 e8 20          	shr    $0x20,%rax
    51bc:	48 39 c8             	cmp    %rcx,%rax
    51bf:	73 17                	jae    51d8 <fwp_drop1+0x88>
    51c1:	48 01 c2             	add    %rax,%rdx
    51c4:	0f b6 02             	movzbl (%rdx),%eax
    51c7:	84 c0                	test   %al,%al
    51c9:	74 0d                	je     51d8 <fwp_drop1+0x88>
    51cb:	3c 01                	cmp    $0x1,%al
    51cd:	74 21                	je     51f0 <fwp_drop1+0xa0>
    51cf:	3c ff                	cmp    $0xff,%al
    51d1:	74 65                	je     5238 <fwp_drop1+0xe8>
    51d3:	83 e8 01             	sub    $0x1,%eax
    51d6:	88 02                	mov    %al,(%rdx)
    51d8:	48 83 c4 18          	add    $0x18,%rsp
    51dc:	c3                   	ret
    51dd:	0f 1f 00             	nopl   (%rax)
    51e0:	66 85 c0             	test   %ax,%ax
    51e3:	74 df                	je     51c4 <fwp_drop1+0x74>
    51e5:	48 83 c4 18          	add    $0x18,%rsp
    51e9:	c3                   	ret
    51ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51f0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    51f4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    51f9:	e8 c2 f4 ff ff       	call   46c0 <fwp_rc_free_arr>
    51fe:	4c 8d 05 5b 95 01 00 	lea    0x1955b(%rip),%r8        # 1e760 <fwp_heap>
    5205:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    520a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    5211:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    5218:	48 c1 e2 10          	shl    $0x10,%rdx
    521c:	48 39 d0             	cmp    %rdx,%rax
    521f:	73 b7                	jae    51d8 <fwp_drop1+0x88>
    5221:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    5226:	e9 52 ff ff ff       	jmp    517d <fwp_drop1+0x2d>
    522b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5230:	c3                   	ret
    5231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5238:	48 89 d0             	mov    %rdx,%rax
    523b:	48 c1 e8 11          	shr    $0x11,%rax
    523f:	48 31 d0             	xor    %rdx,%rax
    5242:	48 89 c1             	mov    %rax,%rcx
    5245:	48 c1 e9 09          	shr    $0x9,%rcx
    5249:	48 31 c8             	xor    %rcx,%rax
    524c:	0f b6 c8             	movzbl %al,%ecx
    524f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    5256:	00 
    5257:	48 85 c0             	test   %rax,%rax
    525a:	75 0d                	jne    5269 <fwp_drop1+0x119>
    525c:	eb 46                	jmp    52a4 <fwp_drop1+0x154>
    525e:	66 90                	xchg   %ax,%ax
    5260:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5264:	48 85 c0             	test   %rax,%rax
    5267:	74 3b                	je     52a4 <fwp_drop1+0x154>
    5269:	48 89 c1             	mov    %rax,%rcx
    526c:	48 39 10             	cmp    %rdx,(%rax)
    526f:	75 ef                	jne    5260 <fwp_drop1+0x110>
    5271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5275:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5279:	48 89 48 08          	mov    %rcx,0x8(%rax)
    527d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5284:	0f 85 4e ff ff ff    	jne    51d8 <fwp_drop1+0x88>
    528a:	48 89 d7             	mov    %rdx,%rdi
    528d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5292:	e8 39 ec ff ff       	call   3ed0 <fwp_rc_forget_slot>
    5297:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    529c:	c6 02 fe             	movb   $0xfe,(%rdx)
    529f:	e9 34 ff ff ff       	jmp    51d8 <fwp_drop1+0x88>
    52a4:	48 8d 3d f5 60 00 00 	lea    0x60f5(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    52ab:	e8 50 df ff ff       	call   3200 <fwp_trap>

00000000000052b0 <fwp_write.constprop.0>:
    52b0:	41 57                	push   %r15
    52b2:	41 56                	push   %r14
    52b4:	41 55                	push   %r13
    52b6:	41 54                	push   %r12
    52b8:	55                   	push   %rbp
    52b9:	53                   	push   %rbx
    52ba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    52c1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    52c8:	00 00 
    52ca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    52d1:	00 
    52d2:	49 89 d4             	mov    %rdx,%r12
    52d5:	8b 12                	mov    (%rdx),%edx
    52d7:	83 fa 19             	cmp    $0x19,%edx
    52da:	77 64                	ja     5340 <fwp_write.constprop.0+0x90>
    52dc:	48 8d 0d 7d 62 00 00 	lea    0x627d(%rip),%rcx        # b560 <_IO_stdin_used+0x560>
    52e3:	89 d0                	mov    %edx,%eax
    52e5:	48 89 fb             	mov    %rdi,%rbx
    52e8:	48 89 f5             	mov    %rsi,%rbp
    52eb:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    52ef:	48 01 c8             	add    %rcx,%rax
    52f2:	3e ff e0             	notrack jmp *%rax
    52f5:	0f 1f 00             	nopl   (%rax)
    52f8:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    52fc:	48 8b 06             	mov    (%rsi),%rax
    52ff:	48 89 ca             	mov    %rcx,%rdx
    5302:	48 85 c9             	test   %rcx,%rcx
    5305:	0f 88 b5 0c 00 00    	js     5fc0 <fwp_write.constprop.0+0xd10>
    530b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5312:	00 
    5313:	48 89 c6             	mov    %rax,%rsi
    5316:	4c 89 e7             	mov    %r12,%rdi
    5319:	e8 e2 d6 ff ff       	call   2a00 <fwp_fmt_u128>
    531e:	66 90                	xchg   %ax,%ax
    5320:	4c 89 e7             	mov    %r12,%rdi
    5323:	e8 08 d1 ff ff       	call   2430 <strlen@plt>
    5328:	4c 89 e6             	mov    %r12,%rsi
    532b:	48 89 df             	mov    %rbx,%rdi
    532e:	48 89 c2             	mov    %rax,%rdx
    5331:	e8 7a dc ff ff       	call   2fb0 <buf_put>
    5336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    533d:	00 00 00 
    5340:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5347:	00 
    5348:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    534f:	00 00 
    5351:	0f 85 9e 04 00 00    	jne    57f5 <fwp_write.constprop.0+0x545>
    5357:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    535e:	5b                   	pop    %rbx
    535f:	5d                   	pop    %rbp
    5360:	41 5c                	pop    %r12
    5362:	41 5d                	pop    %r13
    5364:	41 5e                	pop    %r14
    5366:	41 5f                	pop    %r15
    5368:	c3                   	ret
    5369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5370:	49 89 f1             	mov    %rsi,%r9
    5373:	4c 8d 05 a3 5d 00 00 	lea    0x5da3(%rip),%r8        # b11d <_IO_stdin_used+0x11d>
    537a:	b9 00 02 00 00       	mov    $0x200,%ecx
    537f:	ba 02 00 00 00       	mov    $0x2,%edx
    5384:	be 00 02 00 00       	mov    $0x200,%esi
    5389:	31 c0                	xor    %eax,%eax
    538b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5392:	00 
    5393:	e8 f8 cf ff ff       	call   2390 <__snprintf_chk@plt>
    5398:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    539f:	00 
    53a0:	e8 8b d0 ff ff       	call   2430 <strlen@plt>
    53a5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    53ac:	00 
    53ad:	48 89 df             	mov    %rbx,%rdi
    53b0:	48 89 c2             	mov    %rax,%rdx
    53b3:	e8 f8 db ff ff       	call   2fb0 <buf_put>
    53b8:	eb 86                	jmp    5340 <fwp_write.constprop.0+0x90>
    53ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    53c0:	49 89 f1             	mov    %rsi,%r9
    53c3:	4c 8d 05 4e 5d 00 00 	lea    0x5d4e(%rip),%r8        # b118 <_IO_stdin_used+0x118>
    53ca:	eb ae                	jmp    537a <fwp_write.constprop.0+0xca>
    53cc:	0f 1f 40 00          	nopl   0x0(%rax)
    53d0:	83 fa 13             	cmp    $0x13,%edx
    53d3:	48 8d 05 34 5d 00 00 	lea    0x5d34(%rip),%rax        # b10e <_IO_stdin_used+0x10e>
    53da:	48 8d 35 32 5d 00 00 	lea    0x5d32(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    53e1:	ba 04 00 00 00       	mov    $0x4,%edx
    53e6:	48 0f 44 f0          	cmove  %rax,%rsi
    53ea:	45 31 ed             	xor    %r13d,%r13d
    53ed:	e8 be db ff ff       	call   2fb0 <buf_put>
    53f2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    53f7:	0f 84 b3 09 00 00    	je     5db0 <fwp_write.constprop.0+0xb00>
    53fd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5402:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5407:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    540c:	48 89 df             	mov    %rbx,%rdi
    540f:	49 0f 44 c5          	cmove  %r13,%rax
    5413:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5418:	e8 93 fe ff ff       	call   52b0 <fwp_write.constprop.0>
    541d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5422:	0f 84 80 0a 00 00    	je     5ea8 <fwp_write.constprop.0+0xbf8>
    5428:	49 83 c5 01          	add    $0x1,%r13
    542c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5430:	0f 83 7a 09 00 00    	jae    5db0 <fwp_write.constprop.0+0xb00>
    5436:	ba 02 00 00 00       	mov    $0x2,%edx
    543b:	48 8d 35 1b 5d 00 00 	lea    0x5d1b(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5442:	48 89 df             	mov    %rbx,%rdi
    5445:	e8 66 db ff ff       	call   2fb0 <buf_put>
    544a:	eb b1                	jmp    53fd <fwp_write.constprop.0+0x14d>
    544c:	0f 1f 40 00          	nopl   0x0(%rax)
    5450:	ba 06 00 00 00       	mov    $0x6,%edx
    5455:	48 8d 35 da 5c 00 00 	lea    0x5cda(%rip),%rsi        # b136 <_IO_stdin_used+0x136>
    545c:	48 83 c5 10          	add    $0x10,%rbp
    5460:	e8 4b db ff ff       	call   2fb0 <buf_put>
    5465:	48 89 ef             	mov    %rbp,%rdi
    5468:	e8 c3 cf ff ff       	call   2430 <strlen@plt>
    546d:	48 89 ee             	mov    %rbp,%rsi
    5470:	48 89 df             	mov    %rbx,%rdi
    5473:	48 89 c2             	mov    %rax,%rdx
    5476:	e8 35 db ff ff       	call   2fb0 <buf_put>
    547b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5480:	ba 01 00 00 00       	mov    $0x1,%edx
    5485:	48 89 df             	mov    %rbx,%rdi
    5488:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    548d:	e8 1e db ff ff       	call   2fb0 <buf_put>
    5492:	e9 a9 fe ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    549e:	00 00 
    54a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    54a7:	00 
    54a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    54af:	00 00 
    54b1:	0f 85 3e 03 00 00    	jne    57f5 <fwp_write.constprop.0+0x545>
    54b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    54bc:	48 8d 35 5f 5c 00 00 	lea    0x5c5f(%rip),%rsi        # b122 <_IO_stdin_used+0x122>
    54c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    54ca:	48 89 df             	mov    %rbx,%rdi
    54cd:	5b                   	pop    %rbx
    54ce:	5d                   	pop    %rbp
    54cf:	41 5c                	pop    %r12
    54d1:	41 5d                	pop    %r13
    54d3:	41 5e                	pop    %r14
    54d5:	41 5f                	pop    %r15
    54d7:	e9 d4 da ff ff       	jmp    2fb0 <buf_put>
    54dc:	0f 1f 40 00          	nopl   0x0(%rax)
    54e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    54e5:	4d 85 ed             	test   %r13,%r13
    54e8:	0f 84 c2 0b 00 00    	je     60b0 <fwp_write.constprop.0+0xe00>
    54ee:	48 8d 35 75 5c 00 00 	lea    0x5c75(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    54f5:	4c 89 ef             	mov    %r13,%rdi
    54f8:	e8 13 d0 ff ff       	call   2510 <strcmp@plt>
    54fd:	41 89 c1             	mov    %eax,%r9d
    5500:	85 c0                	test   %eax,%eax
    5502:	0f 84 2c 0c 00 00    	je     6134 <fwp_write.constprop.0+0xe84>
    5508:	4c 89 ef             	mov    %r13,%rdi
    550b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5510:	e8 1b cf ff ff       	call   2430 <strlen@plt>
    5515:	4c 89 ee             	mov    %r13,%rsi
    5518:	48 89 df             	mov    %rbx,%rdi
    551b:	48 89 c2             	mov    %rax,%rdx
    551e:	e8 8d da ff ff       	call   2fb0 <buf_put>
    5523:	ba 01 00 00 00       	mov    $0x1,%edx
    5528:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    552d:	48 89 df             	mov    %rbx,%rdi
    5530:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5535:	e8 76 da ff ff       	call   2fb0 <buf_put>
    553a:	ba 01 00 00 00       	mov    $0x1,%edx
    553f:	4c 89 fe             	mov    %r15,%rsi
    5542:	48 89 df             	mov    %rbx,%rdi
    5545:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    554a:	e8 61 da ff ff       	call   2fb0 <buf_put>
    554f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5554:	45 31 f6             	xor    %r14d,%r14d
    5557:	85 c0                	test   %eax,%eax
    5559:	0f 8e 91 0a 00 00    	jle    5ff0 <fwp_write.constprop.0+0xd40>
    555f:	45 31 ed             	xor    %r13d,%r13d
    5562:	4d 85 ed             	test   %r13,%r13
    5565:	0f 85 d5 08 00 00    	jne    5e40 <fwp_write.constprop.0+0xb90>
    556b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5572:	00 
    5573:	45 85 f6             	test   %r14d,%r14d
    5576:	0f 84 74 08 00 00    	je     5df0 <fwp_write.constprop.0+0xb40>
    557c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    5581:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    5586:	48 89 df             	mov    %rbx,%rdi
    5589:	49 83 c5 01          	add    $0x1,%r13
    558d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    5591:	e8 1a fd ff ff       	call   52b0 <fwp_write.constprop.0>
    5596:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    559b:	7f c5                	jg     5562 <fwp_write.constprop.0+0x2b2>
    559d:	45 85 f6             	test   %r14d,%r14d
    55a0:	0f 84 4a 0a 00 00    	je     5ff0 <fwp_write.constprop.0+0xd40>
    55a6:	b8 29 00 00 00       	mov    $0x29,%eax
    55ab:	ba 01 00 00 00       	mov    $0x1,%edx
    55b0:	4c 89 fe             	mov    %r15,%rsi
    55b3:	48 89 df             	mov    %rbx,%rdi
    55b6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    55ba:	e8 f1 d9 ff ff       	call   2fb0 <buf_put>
    55bf:	e9 7c fd ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    55c4:	0f 1f 40 00          	nopl   0x0(%rax)
    55c8:	ba 01 00 00 00       	mov    $0x1,%edx
    55cd:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    55d2:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    55d7:	e8 d4 d9 ff ff       	call   2fb0 <buf_put>
    55dc:	48 85 ed             	test   %rbp,%rbp
    55df:	0f 84 8b 07 00 00    	je     5d70 <fwp_write.constprop.0+0xac0>
    55e5:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    55e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    55ee:	48 89 df             	mov    %rbx,%rdi
    55f1:	e8 ba fc ff ff       	call   52b0 <fwp_write.constprop.0>
    55f6:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    55fa:	48 85 ed             	test   %rbp,%rbp
    55fd:	0f 84 6d 07 00 00    	je     5d70 <fwp_write.constprop.0+0xac0>
    5603:	ba 02 00 00 00       	mov    $0x2,%edx
    5608:	48 8d 35 4e 5b 00 00 	lea    0x5b4e(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    560f:	48 89 df             	mov    %rbx,%rdi
    5612:	e8 99 d9 ff ff       	call   2fb0 <buf_put>
    5617:	eb cc                	jmp    55e5 <fwp_write.constprop.0+0x335>
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4c 8b 2e             	mov    (%rsi),%r13
    5623:	ba 01 00 00 00       	mov    $0x1,%edx
    5628:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    562d:	48 83 c5 08          	add    $0x8,%rbp
    5631:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5636:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    563b:	e8 70 d9 ff ff       	call   2fb0 <buf_put>
    5640:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5645:	4d 85 ed             	test   %r13,%r13
    5648:	75 43                	jne    568d <fwp_write.constprop.0+0x3dd>
    564a:	e9 81 07 00 00       	jmp    5dd0 <fwp_write.constprop.0+0xb20>
    564f:	90                   	nop
    5650:	41 80 f9 09          	cmp    $0x9,%r9b
    5654:	0f 84 f6 06 00 00    	je     5d50 <fwp_write.constprop.0+0xaa0>
    565a:	41 80 f9 0a          	cmp    $0xa,%r9b
    565e:	0f 85 bc 06 00 00    	jne    5d20 <fwp_write.constprop.0+0xa70>
    5664:	ba 02 00 00 00       	mov    $0x2,%edx
    5669:	48 8d 35 d3 5a 00 00 	lea    0x5ad3(%rip),%rsi        # b143 <_IO_stdin_used+0x143>
    5670:	48 89 df             	mov    %rbx,%rdi
    5673:	e8 38 d9 ff ff       	call   2fb0 <buf_put>
    5678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    567f:	00 
    5680:	48 83 c5 01          	add    $0x1,%rbp
    5684:	49 39 ec             	cmp    %rbp,%r12
    5687:	0f 84 43 07 00 00    	je     5dd0 <fwp_write.constprop.0+0xb20>
    568d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    5692:	41 80 f9 0d          	cmp    $0xd,%r9b
    5696:	0f 84 64 06 00 00    	je     5d00 <fwp_write.constprop.0+0xa50>
    569c:	7e b2                	jle    5650 <fwp_write.constprop.0+0x3a0>
    569e:	41 80 f9 22          	cmp    $0x22,%r9b
    56a2:	0f 84 38 06 00 00    	je     5ce0 <fwp_write.constprop.0+0xa30>
    56a8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    56ac:	0f 85 6e 06 00 00    	jne    5d20 <fwp_write.constprop.0+0xa70>
    56b2:	ba 02 00 00 00       	mov    $0x2,%edx
    56b7:	48 8d 35 82 5a 00 00 	lea    0x5a82(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    56be:	48 89 df             	mov    %rbx,%rdi
    56c1:	e8 ea d8 ff ff       	call   2fb0 <buf_put>
    56c6:	eb b8                	jmp    5680 <fwp_write.constprop.0+0x3d0>
    56c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    56cf:	00 
    56d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    56d5:	ba 01 00 00 00       	mov    $0x1,%edx
    56da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    56df:	48 89 ee             	mov    %rbp,%rsi
    56e2:	e8 c9 d8 ff ff       	call   2fb0 <buf_put>
    56e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    56ec:	4c 89 e7             	mov    %r12,%rdi
    56ef:	e8 3c cd ff ff       	call   2430 <strlen@plt>
    56f4:	4c 89 e6             	mov    %r12,%rsi
    56f7:	48 89 df             	mov    %rbx,%rdi
    56fa:	48 89 c2             	mov    %rax,%rdx
    56fd:	e8 ae d8 ff ff       	call   2fb0 <buf_put>
    5702:	ba 01 00 00 00       	mov    $0x1,%edx
    5707:	48 89 ee             	mov    %rbp,%rsi
    570a:	48 89 df             	mov    %rbx,%rdi
    570d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5712:	e8 99 d8 ff ff       	call   2fb0 <buf_put>
    5717:	e9 24 fc ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    571c:	0f 1f 40 00          	nopl   0x0(%rax)
    5720:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5725:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5729:	0f 8a de 0a 00 00    	jp     620d <fwp_write.constprop.0+0xf5d>
    572f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5733:	66 0f 54 05 15 5f 00 	andpd  0x5f15(%rip),%xmm0        # b650 <msg.3+0x80>
    573a:	00 
    573b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5740:	66 0f 2e 05 38 5f 00 	ucomisd 0x5f38(%rip),%xmm0        # b680 <msg.3+0xb0>
    5747:	00 
    5748:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    574f:	00 
    5750:	0f 87 02 09 00 00    	ja     6058 <fwp_write.constprop.0+0xda8>
    5756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    575d:	00 00 00 
    5760:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5764:	89 ee                	mov    %ebp,%esi
    5766:	4c 89 e7             	mov    %r12,%rdi
    5769:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    576e:	e8 5d db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5773:	31 f6                	xor    %esi,%esi
    5775:	4c 89 e7             	mov    %r12,%rdi
    5778:	e8 73 cc ff ff       	call   23f0 <strtod@plt>
    577d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    5782:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    5786:	7a 06                	jp     578e <fwp_write.constprop.0+0x4de>
    5788:	0f 84 09 03 00 00    	je     5a97 <fwp_write.constprop.0+0x7e7>
    578e:	83 c5 01             	add    $0x1,%ebp
    5791:	83 fd 12             	cmp    $0x12,%ebp
    5794:	75 ca                	jne    5760 <fwp_write.constprop.0+0x4b0>
    5796:	be 11 00 00 00       	mov    $0x11,%esi
    579b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    579f:	4c 89 e7             	mov    %r12,%rdi
    57a2:	e8 29 db ff ff       	call   32d0 <fwp_format_g.constprop.0>
    57a7:	e9 eb 02 00 00       	jmp    5a97 <fwp_write.constprop.0+0x7e7>
    57ac:	0f 1f 40 00          	nopl   0x0(%rax)
    57b0:	48 83 fe 01          	cmp    $0x1,%rsi
    57b4:	0f 84 86 08 00 00    	je     6040 <fwp_write.constprop.0+0xd90>
    57ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    57be:	b8 02 00 00 00       	mov    $0x2,%eax
    57c3:	ba 01 00 00 00       	mov    $0x1,%edx
    57c8:	48 0f 44 d0          	cmove  %rax,%rdx
    57cc:	48 8d 35 39 59 00 00 	lea    0x5939(%rip),%rsi        # b10c <_IO_stdin_used+0x10c>
    57d3:	48 8d 05 2f 59 00 00 	lea    0x592f(%rip),%rax        # b109 <_IO_stdin_used+0x109>
    57da:	48 0f 44 f0          	cmove  %rax,%rsi
    57de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    57e5:	00 
    57e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    57ed:	00 00 
    57ef:	0f 84 ce fc ff ff    	je     54c3 <fwp_write.constprop.0+0x213>
    57f5:	e8 46 cc ff ff       	call   2440 <__stack_chk_fail@plt>
    57fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5800:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5805:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    580a:	e8 e1 d6 ff ff       	call   2ef0 <buf_grow>
    580f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5813:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5819:	4c 03 0b             	add    (%rbx),%r9
    581c:	66 45 89 11          	mov    %r10w,(%r9)
    5820:	49 83 c1 01          	add    $0x1,%r9
    5824:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    582b:	55 55 55 
    582e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5835:	aa aa aa 
    5838:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    583c:	45 85 e4             	test   %r12d,%r12d
    583f:	7f 4c                	jg     588d <fwp_write.constprop.0+0x5dd>
    5841:	e9 4a 05 00 00       	jmp    5d90 <fwp_write.constprop.0+0xae0>
    5846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    584d:	00 00 00 
    5850:	be 01 00 00 00       	mov    $0x1,%esi
    5855:	b8 2d 00 00 00       	mov    $0x2d,%eax
    585a:	88 07                	mov    %al,(%rdi)
    585c:	48 89 e8             	mov    %rbp,%rax
    585f:	49 f7 e8             	imul   %r8
    5862:	48 89 e8             	mov    %rbp,%rax
    5865:	48 c1 f8 3f          	sar    $0x3f,%rax
    5869:	48 29 c2             	sub    %rax,%rdx
    586c:	48 85 c9             	test   %rcx,%rcx
    586f:	0f 95 c0             	setne  %al
    5872:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5876:	48 83 ef 01          	sub    $0x1,%rdi
    587a:	48 21 c5             	and    %rax,%rbp
    587d:	48 29 ea             	sub    %rbp,%rdx
    5880:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    5884:	49 39 f9             	cmp    %rdi,%r9
    5887:	0f 84 03 05 00 00    	je     5d90 <fwp_write.constprop.0+0xae0>
    588d:	48 89 e8             	mov    %rbp,%rax
    5890:	49 f7 e8             	imul   %r8
    5893:	48 89 e8             	mov    %rbp,%rax
    5896:	48 c1 f8 3f          	sar    $0x3f,%rax
    589a:	48 89 d1             	mov    %rdx,%rcx
    589d:	48 29 c1             	sub    %rax,%rcx
    58a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    58a4:	48 89 e9             	mov    %rbp,%rcx
    58a7:	48 29 c1             	sub    %rax,%rcx
    58aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    58ae:	49 f7 e2             	mul    %r10
    58b1:	b8 30 00 00 00       	mov    $0x30,%eax
    58b6:	48 89 d6             	mov    %rdx,%rsi
    58b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    58bd:	48 d1 ee             	shr    $1,%rsi
    58c0:	48 01 f2             	add    %rsi,%rdx
    58c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    58c7:	48 29 d6             	sub    %rdx,%rsi
    58ca:	74 8e                	je     585a <fwp_write.constprop.0+0x5aa>
    58cc:	48 83 fe 01          	cmp    $0x1,%rsi
    58d0:	0f 85 7a ff ff ff    	jne    5850 <fwp_write.constprop.0+0x5a0>
    58d6:	31 f6                	xor    %esi,%esi
    58d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    58dd:	e9 78 ff ff ff       	jmp    585a <fwp_write.constprop.0+0x5aa>
    58e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    58e8:	ba 06 00 00 00       	mov    $0x6,%edx
    58ed:	48 8d 35 6c 58 00 00 	lea    0x586c(%rip),%rsi        # b160 <_IO_stdin_used+0x160>
    58f4:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    58fa:	e8 b1 d6 ff ff       	call   2fb0 <buf_put>
    58ff:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5906:	ff ff 7f 
    5909:	48 23 55 00          	and    0x0(%rbp),%rdx
    590d:	0f 84 4e 03 00 00    	je     5c61 <fwp_write.constprop.0+0x9b1>
    5913:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5918:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    591c:	48 85 d2             	test   %rdx,%rdx
    591f:	0f 84 a4 00 00 00    	je     59c9 <fwp_write.constprop.0+0x719>
    5925:	8b 0a                	mov    (%rdx),%ecx
    5927:	83 f9 1c             	cmp    $0x1c,%ecx
    592a:	0f 84 d0 06 00 00    	je     6000 <fwp_write.constprop.0+0xd50>
    5930:	83 f9 1b             	cmp    $0x1b,%ecx
    5933:	0f 87 90 00 00 00    	ja     59c9 <fwp_write.constprop.0+0x719>
    5939:	be 01 00 00 00       	mov    $0x1,%esi
    593e:	48 d3 e6             	shl    %cl,%rsi
    5941:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5947:	0f 85 13 06 00 00    	jne    5f60 <fwp_write.constprop.0+0xcb0>
    594d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5953:	0f 85 d7 05 00 00    	jne    5f30 <fwp_write.constprop.0+0xc80>
    5959:	83 e6 21             	and    $0x21,%esi
    595c:	74 6b                	je     59c9 <fwp_write.constprop.0+0x719>
    595e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5963:	48 85 ff             	test   %rdi,%rdi
    5966:	79 07                	jns    596f <fwp_write.constprop.0+0x6bf>
    5968:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    596c:	4c 01 ee             	add    %r13,%rsi
    596f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5973:	85 c9                	test   %ecx,%ecx
    5975:	40 0f b6 f7          	movzbl %dil,%esi
    5979:	48 0f 44 f7          	cmove  %rdi,%rsi
    597d:	0f 1f 00             	nopl   (%rax)
    5980:	48 89 df             	mov    %rbx,%rdi
    5983:	49 83 c5 01          	add    $0x1,%r13
    5987:	e8 24 f9 ff ff       	call   52b0 <fwp_write.constprop.0>
    598c:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5993:	ff ff 7f 
    5996:	48 23 55 00          	and    0x0(%rbp),%rdx
    599a:	49 39 d5             	cmp    %rdx,%r13
    599d:	0f 83 be 02 00 00    	jae    5c61 <fwp_write.constprop.0+0x9b1>
    59a3:	ba 02 00 00 00       	mov    $0x2,%edx
    59a8:	48 89 df             	mov    %rbx,%rdi
    59ab:	48 8d 35 ab 57 00 00 	lea    0x57ab(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    59b2:	e8 f9 d5 ff ff       	call   2fb0 <buf_put>
    59b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    59bc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    59c0:	48 85 d2             	test   %rdx,%rdx
    59c3:	0f 85 5c ff ff ff    	jne    5925 <fwp_write.constprop.0+0x675>
    59c9:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    59ce:	48 85 ff             	test   %rdi,%rdi
    59d1:	0f 88 51 06 00 00    	js     6028 <fwp_write.constprop.0+0xd78>
    59d7:	48 8b 31             	mov    (%rcx),%rsi
    59da:	eb a4                	jmp    5980 <fwp_write.constprop.0+0x6d0>
    59dc:	0f 1f 40 00          	nopl   0x0(%rax)
    59e0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    59e7:	00 
    59e8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    59ef:	00 00 
    59f1:	0f 85 fe fd ff ff    	jne    57f5 <fwp_write.constprop.0+0x545>
    59f7:	ba 08 00 00 00       	mov    $0x8,%edx
    59fc:	48 8d 35 2a 57 00 00 	lea    0x572a(%rip),%rsi        # b12d <_IO_stdin_used+0x12d>
    5a03:	e9 bb fa ff ff       	jmp    54c3 <fwp_write.constprop.0+0x213>
    5a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5a0f:	00 
    5a10:	66 0f 6e ce          	movd   %esi,%xmm1
    5a14:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5a17:	0f 8a f0 07 00 00    	jp     620d <fwp_write.constprop.0+0xf5d>
    5a1d:	0f 28 c1             	movaps %xmm1,%xmm0
    5a20:	0f 54 05 19 5c 00 00 	andps  0x5c19(%rip),%xmm0        # b640 <msg.3+0x70>
    5a27:	0f 2e 05 d6 55 00 00 	ucomiss 0x55d6(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    5a2e:	0f 87 4c 06 00 00    	ja     6080 <fwp_write.constprop.0+0xdd0>
    5a34:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5a38:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    5a3e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5a45:	00 
    5a46:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    5a4a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    5a4f:	90                   	nop
    5a50:	44 89 ee             	mov    %r13d,%esi
    5a53:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5a58:	4c 89 e7             	mov    %r12,%rdi
    5a5b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5a60:	e8 6b d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5a65:	31 f6                	xor    %esi,%esi
    5a67:	4c 89 e7             	mov    %r12,%rdi
    5a6a:	e8 21 ca ff ff       	call   2490 <strtof@plt>
    5a6f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5a74:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5a77:	7a 02                	jp     5a7b <fwp_write.constprop.0+0x7cb>
    5a79:	74 1c                	je     5a97 <fwp_write.constprop.0+0x7e7>
    5a7b:	41 83 c5 01          	add    $0x1,%r13d
    5a7f:	41 83 fd 0a          	cmp    $0xa,%r13d
    5a83:	75 cb                	jne    5a50 <fwp_write.constprop.0+0x7a0>
    5a85:	be 09 00 00 00       	mov    $0x9,%esi
    5a8a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5a8f:	4c 89 e7             	mov    %r12,%rdi
    5a92:	e8 39 d8 ff ff       	call   32d0 <fwp_format_g.constprop.0>
    5a97:	4c 89 e7             	mov    %r12,%rdi
    5a9a:	e8 d1 d5 ff ff       	call   3070 <fwp_finish_float>
    5a9f:	e9 7c f8 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    5aa4:	0f 1f 40 00          	nopl   0x0(%rax)
    5aa8:	89 f0                	mov    %esi,%eax
    5aaa:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    5ab1:	76 02                	jbe    5ab5 <fwp_write.constprop.0+0x805>
    5ab3:	8b 06                	mov    (%rsi),%eax
    5ab5:	41 89 c6             	mov    %eax,%r14d
    5ab8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5abd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    5ac2:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    5ac6:	4c 89 ef             	mov    %r13,%rdi
    5ac9:	e8 62 c9 ff ff       	call   2430 <strlen@plt>
    5ace:	4c 89 ee             	mov    %r13,%rsi
    5ad1:	48 89 df             	mov    %rbx,%rdi
    5ad4:	48 89 c2             	mov    %rax,%rdx
    5ad7:	e8 d4 d4 ff ff       	call   2fb0 <buf_put>
    5adc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5ae1:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5ae5:	85 f6                	test   %esi,%esi
    5ae7:	0f 8e 53 f8 ff ff    	jle    5340 <fwp_write.constprop.0+0x90>
    5aed:	45 31 ed             	xor    %r13d,%r13d
    5af0:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5af5:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    5afa:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5aff:	4c 89 fe             	mov    %r15,%rsi
    5b02:	48 89 df             	mov    %rbx,%rdi
    5b05:	ba 01 00 00 00       	mov    $0x1,%edx
    5b0a:	48 89 04 24          	mov    %rax,(%rsp)
    5b0e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5b13:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5b17:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    5b1b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5b20:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5b25:	e8 86 d4 ff ff       	call   2fb0 <buf_put>
    5b2a:	41 8b 06             	mov    (%r14),%eax
    5b2d:	83 f8 0e             	cmp    $0xe,%eax
    5b30:	0f 84 5a 03 00 00    	je     5e90 <fwp_write.constprop.0+0xbe0>
    5b36:	83 f8 10             	cmp    $0x10,%eax
    5b39:	0f 84 21 03 00 00    	je     5e60 <fwp_write.constprop.0+0xbb0>
    5b3f:	83 f8 0a             	cmp    $0xa,%eax
    5b42:	0f 84 68 04 00 00    	je     5fb0 <fwp_write.constprop.0+0xd00>
    5b48:	0f 8f 32 01 00 00    	jg     5c80 <fwp_write.constprop.0+0x9d0>
    5b4e:	83 f8 03             	cmp    $0x3,%eax
    5b51:	0f 8f 39 04 00 00    	jg     5f90 <fwp_write.constprop.0+0xce0>
    5b57:	85 c0                	test   %eax,%eax
    5b59:	78 10                	js     5b6b <fwp_write.constprop.0+0x8bb>
    5b5b:	48 8b 04 24          	mov    (%rsp),%rax
    5b5f:	48 c1 e8 3f          	shr    $0x3f,%rax
    5b63:	85 c0                	test   %eax,%eax
    5b65:	0f 85 32 01 00 00    	jne    5c9d <fwp_write.constprop.0+0x9ed>
    5b6b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5b70:	48 8b 34 24          	mov    (%rsp),%rsi
    5b74:	48 89 df             	mov    %rbx,%rdi
    5b77:	e8 34 f7 ff ff       	call   52b0 <fwp_write.constprop.0>
    5b7c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5b81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b86:	49 83 c5 01          	add    $0x1,%r13
    5b8a:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    5b8e:	0f 8f 61 ff ff ff    	jg     5af5 <fwp_write.constprop.0+0x845>
    5b94:	e9 a7 f7 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ba0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    5ba4:	48 8b 36             	mov    (%rsi),%rsi
    5ba7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    5bae:	00 
    5baf:	48 89 ef             	mov    %rbp,%rdi
    5bb2:	e8 49 ce ff ff       	call   2a00 <fwp_fmt_u128>
    5bb7:	48 89 ef             	mov    %rbp,%rdi
    5bba:	e8 71 c8 ff ff       	call   2430 <strlen@plt>
    5bbf:	48 89 ee             	mov    %rbp,%rsi
    5bc2:	48 89 df             	mov    %rbx,%rdi
    5bc5:	48 89 c2             	mov    %rax,%rdx
    5bc8:	e8 e3 d3 ff ff       	call   2fb0 <buf_put>
    5bcd:	e9 6e f7 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5bd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bd8:	ba 06 00 00 00       	mov    $0x6,%edx
    5bdd:	48 8d 35 6f 55 00 00 	lea    0x556f(%rip),%rsi        # b153 <_IO_stdin_used+0x153>
    5be4:	45 31 ed             	xor    %r13d,%r13d
    5be7:	e8 c4 d3 ff ff       	call   2fb0 <buf_put>
    5bec:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5bf1:	75 19                	jne    5c0c <fwp_write.constprop.0+0x95c>
    5bf3:	eb 6c                	jmp    5c61 <fwp_write.constprop.0+0x9b1>
    5bf5:	0f 1f 00             	nopl   (%rax)
    5bf8:	ba 02 00 00 00       	mov    $0x2,%edx
    5bfd:	48 8d 35 59 55 00 00 	lea    0x5559(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5c04:	48 89 df             	mov    %rbx,%rdi
    5c07:	e8 a4 d3 ff ff       	call   2fb0 <buf_put>
    5c0c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5c12:	b9 00 02 00 00       	mov    $0x200,%ecx
    5c17:	31 c0                	xor    %eax,%eax
    5c19:	49 83 c5 01          	add    $0x1,%r13
    5c1d:	4c 8d 05 36 55 00 00 	lea    0x5536(%rip),%r8        # b15a <_IO_stdin_used+0x15a>
    5c24:	ba 02 00 00 00       	mov    $0x2,%edx
    5c29:	be 00 02 00 00       	mov    $0x200,%esi
    5c2e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c35:	00 
    5c36:	e8 55 c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c3b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c42:	00 
    5c43:	e8 e8 c7 ff ff       	call   2430 <strlen@plt>
    5c48:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c4f:	00 
    5c50:	48 89 df             	mov    %rbx,%rdi
    5c53:	48 89 c2             	mov    %rax,%rdx
    5c56:	e8 55 d3 ff ff       	call   2fb0 <buf_put>
    5c5b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5c5f:	72 97                	jb     5bf8 <fwp_write.constprop.0+0x948>
    5c61:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5c66:	ba 01 00 00 00       	mov    $0x1,%edx
    5c6b:	48 89 df             	mov    %rbx,%rdi
    5c6e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5c73:	e8 38 d3 ff ff       	call   2fb0 <buf_put>
    5c78:	e9 c3 f6 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5c7d:	0f 1f 00             	nopl   (%rax)
    5c80:	83 f8 0b             	cmp    $0xb,%eax
    5c83:	0f 85 e2 fe ff ff    	jne    5b6b <fwp_write.constprop.0+0x8bb>
    5c89:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5c8e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    5c92:	83 e0 01             	and    $0x1,%eax
    5c95:	85 c0                	test   %eax,%eax
    5c97:	0f 84 ce fe ff ff    	je     5b6b <fwp_write.constprop.0+0x8bb>
    5c9d:	4c 89 fe             	mov    %r15,%rsi
    5ca0:	48 89 df             	mov    %rbx,%rdi
    5ca3:	ba 01 00 00 00       	mov    $0x1,%edx
    5ca8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5cad:	e8 fe d2 ff ff       	call   2fb0 <buf_put>
    5cb2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5cb7:	48 8b 34 24          	mov    (%rsp),%rsi
    5cbb:	48 89 df             	mov    %rbx,%rdi
    5cbe:	e8 ed f5 ff ff       	call   52b0 <fwp_write.constprop.0>
    5cc3:	ba 01 00 00 00       	mov    $0x1,%edx
    5cc8:	4c 89 fe             	mov    %r15,%rsi
    5ccb:	48 89 df             	mov    %rbx,%rdi
    5cce:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    5cd3:	e8 d8 d2 ff ff       	call   2fb0 <buf_put>
    5cd8:	e9 9f fe ff ff       	jmp    5b7c <fwp_write.constprop.0+0x8cc>
    5cdd:	0f 1f 00             	nopl   (%rax)
    5ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    5ce5:	48 8d 35 51 54 00 00 	lea    0x5451(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5cec:	48 89 df             	mov    %rbx,%rdi
    5cef:	e8 bc d2 ff ff       	call   2fb0 <buf_put>
    5cf4:	e9 87 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	ba 02 00 00 00       	mov    $0x2,%edx
    5d05:	48 8d 35 3d 54 00 00 	lea    0x543d(%rip),%rsi        # b149 <_IO_stdin_used+0x149>
    5d0c:	48 89 df             	mov    %rbx,%rdi
    5d0f:	e8 9c d2 ff ff       	call   2fb0 <buf_put>
    5d14:	e9 67 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d20:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5d24:	0f 86 b6 01 00 00    	jbe    5ee0 <fwp_write.constprop.0+0xc30>
    5d2a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5d2e:	0f 84 ac 01 00 00    	je     5ee0 <fwp_write.constprop.0+0xc30>
    5d34:	ba 01 00 00 00       	mov    $0x1,%edx
    5d39:	4c 89 fe             	mov    %r15,%rsi
    5d3c:	48 89 df             	mov    %rbx,%rdi
    5d3f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5d44:	e8 67 d2 ff ff       	call   2fb0 <buf_put>
    5d49:	e9 32 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d4e:	66 90                	xchg   %ax,%ax
    5d50:	ba 02 00 00 00       	mov    $0x2,%edx
    5d55:	48 8d 35 ea 53 00 00 	lea    0x53ea(%rip),%rsi        # b146 <_IO_stdin_used+0x146>
    5d5c:	48 89 df             	mov    %rbx,%rdi
    5d5f:	e8 4c d2 ff ff       	call   2fb0 <buf_put>
    5d64:	e9 17 f9 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5d69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d70:	ba 01 00 00 00       	mov    $0x1,%edx
    5d75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5d7a:	48 89 df             	mov    %rbx,%rdi
    5d7d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5d82:	e8 29 d2 ff ff       	call   2fb0 <buf_put>
    5d87:	e9 b4 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    5d90:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5d94:	48 8b 13             	mov    (%rbx),%rdx
    5d97:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5d9c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5da0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5da4:	e9 97 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5db0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5db5:	ba 01 00 00 00       	mov    $0x1,%edx
    5dba:	48 89 df             	mov    %rbx,%rdi
    5dbd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5dc2:	e8 e9 d1 ff ff       	call   2fb0 <buf_put>
    5dc7:	e9 74 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5dcc:	0f 1f 40 00          	nopl   0x0(%rax)
    5dd0:	ba 01 00 00 00       	mov    $0x1,%edx
    5dd5:	4c 89 fe             	mov    %r15,%rsi
    5dd8:	48 89 df             	mov    %rbx,%rdi
    5ddb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5de0:	e8 cb d1 ff ff       	call   2fb0 <buf_put>
    5de5:	e9 56 f5 ff ff       	jmp    5340 <fwp_write.constprop.0+0x90>
    5dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5df0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5df5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5dfa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5dfe:	48 89 f7             	mov    %rsi,%rdi
    5e01:	48 89 34 24          	mov    %rsi,(%rsp)
    5e05:	e8 26 c6 ff ff       	call   2430 <strlen@plt>
    5e0a:	48 8b 34 24          	mov    (%rsp),%rsi
    5e0e:	48 89 df             	mov    %rbx,%rdi
    5e11:	48 89 c2             	mov    %rax,%rdx
    5e14:	e8 97 d1 ff ff       	call   2fb0 <buf_put>
    5e19:	ba 03 00 00 00       	mov    $0x3,%edx
    5e1e:	48 8d 35 5b 53 00 00 	lea    0x535b(%rip),%rsi        # b180 <_IO_stdin_used+0x180>
    5e25:	48 89 df             	mov    %rbx,%rdi
    5e28:	e8 83 d1 ff ff       	call   2fb0 <buf_put>
    5e2d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e32:	e9 45 f7 ff ff       	jmp    557c <fwp_write.constprop.0+0x2cc>
    5e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e3e:	00 00 
    5e40:	ba 02 00 00 00       	mov    $0x2,%edx
    5e45:	48 8d 35 11 53 00 00 	lea    0x5311(%rip),%rsi        # b15d <_IO_stdin_used+0x15d>
    5e4c:	48 89 df             	mov    %rbx,%rdi
    5e4f:	e8 5c d1 ff ff       	call   2fb0 <buf_put>
    5e54:	e9 12 f7 ff ff       	jmp    556b <fwp_write.constprop.0+0x2bb>
    5e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5e60:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5e65:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5e69:	48 85 ff             	test   %rdi,%rdi
    5e6c:	0f 84 f9 fc ff ff    	je     5b6b <fwp_write.constprop.0+0x8bb>
    5e72:	48 8d 35 f1 52 00 00 	lea    0x52f1(%rip),%rsi        # b16a <_IO_stdin_used+0x16a>
    5e79:	e8 92 c6 ff ff       	call   2510 <strcmp@plt>
    5e7e:	85 c0                	test   %eax,%eax
    5e80:	0f 95 c0             	setne  %al
    5e83:	0f b6 c0             	movzbl %al,%eax
    5e86:	e9 d8 fc ff ff       	jmp    5b63 <fwp_write.constprop.0+0x8b3>
    5e8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e90:	31 c0                	xor    %eax,%eax
    5e92:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5e99:	00 
    5e9a:	0f 97 c0             	seta   %al
    5e9d:	e9 c1 fc ff ff       	jmp    5b63 <fwp_write.constprop.0+0x8b3>
    5ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea8:	48 89 df             	mov    %rbx,%rdi
    5eab:	ba 02 00 00 00       	mov    $0x2,%edx
    5eb0:	48 8d 35 b0 52 00 00 	lea    0x52b0(%rip),%rsi        # b167 <_IO_stdin_used+0x167>
    5eb7:	e8 f4 d0 ff ff       	call   2fb0 <buf_put>
    5ebc:	4c 89 e8             	mov    %r13,%rax
    5ebf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5ec4:	48 89 df             	mov    %rbx,%rdi
    5ec7:	48 c1 e0 04          	shl    $0x4,%rax
    5ecb:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5ed0:	e8 db f3 ff ff       	call   52b0 <fwp_write.constprop.0>
    5ed5:	e9 4e f5 ff ff       	jmp    5428 <fwp_write.constprop.0+0x178>
    5eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ee0:	4c 8d 05 65 52 00 00 	lea    0x5265(%rip),%r8        # b14c <_IO_stdin_used+0x14c>
    5ee7:	b9 10 00 00 00       	mov    $0x10,%ecx
    5eec:	31 c0                	xor    %eax,%eax
    5eee:	ba 02 00 00 00       	mov    $0x2,%edx
    5ef3:	be 10 00 00 00       	mov    $0x10,%esi
    5ef8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5eff:	00 
    5f00:	e8 8b c4 ff ff       	call   2390 <__snprintf_chk@plt>
    5f05:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5f0c:	00 
    5f0d:	e8 1e c5 ff ff       	call   2430 <strlen@plt>
    5f12:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5f19:	00 
    5f1a:	48 89 df             	mov    %rbx,%rdi
    5f1d:	48 89 c2             	mov    %rax,%rdx
    5f20:	e8 8b d0 ff ff       	call   2fb0 <buf_put>
    5f25:	e9 56 f7 ff ff       	jmp    5680 <fwp_write.constprop.0+0x3d0>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5f35:	48 85 ff             	test   %rdi,%rdi
    5f38:	79 0c                	jns    5f46 <fwp_write.constprop.0+0xc96>
    5f3a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5f41:	00 
    5f42:	48 03 75 10          	add    0x10(%rbp),%rsi
    5f46:	48 63 3e             	movslq (%rsi),%rdi
    5f49:	83 f9 02             	cmp    $0x2,%ecx
    5f4c:	89 fe                	mov    %edi,%esi
    5f4e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5f52:	e9 29 fa ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5f65:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5f6a:	48 85 ff             	test   %rdi,%rdi
    5f6d:	0f 88 6f 01 00 00    	js     60e2 <fwp_write.constprop.0+0xe32>
    5f73:	49 0f bf 38          	movswq (%r8),%rdi
    5f77:	83 f9 01             	cmp    $0x1,%ecx
    5f7a:	0f b7 f7             	movzwl %di,%esi
    5f7d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5f81:	e9 fa f9 ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    5f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f8d:	00 00 00 
    5f90:	83 f8 04             	cmp    $0x4,%eax
    5f93:	0f 85 d2 fb ff ff    	jne    5b6b <fwp_write.constprop.0+0x8bb>
    5f99:	48 8b 04 24          	mov    (%rsp),%rax
    5f9d:	48 8b 40 08          	mov    0x8(%rax),%rax
    5fa1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5fa6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5faa:	e9 e6 fc ff ff       	jmp    5c95 <fwp_write.constprop.0+0x9e5>
    5faf:	90                   	nop
    5fb0:	8b 0c 24             	mov    (%rsp),%ecx
    5fb3:	31 c0                	xor    %eax,%eax
    5fb5:	85 c9                	test   %ecx,%ecx
    5fb7:	0f 98 c0             	sets   %al
    5fba:	e9 d6 fc ff ff       	jmp    5c95 <fwp_write.constprop.0+0x9e5>
    5fbf:	90                   	nop
    5fc0:	48 f7 d8             	neg    %rax
    5fc3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5fca:	00 
    5fcb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5fd2:	2d 
    5fd3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5fda:	00 
    5fdb:	48 83 d2 00          	adc    $0x0,%rdx
    5fdf:	48 89 c6             	mov    %rax,%rsi
    5fe2:	48 f7 da             	neg    %rdx
    5fe5:	e8 16 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5fea:	e9 31 f3 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    5fef:	90                   	nop
    5ff0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5ff5:	e9 b1 f5 ff ff       	jmp    55ab <fwp_write.constprop.0+0x2fb>
    5ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6000:	4c 89 e9             	mov    %r13,%rcx
    6003:	48 c1 e1 04          	shl    $0x4,%rcx
    6007:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    600c:	48 85 ff             	test   %rdi,%rdi
    600f:	0f 89 6b f9 ff ff    	jns    5980 <fwp_write.constprop.0+0x6d0>
    6015:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6019:	48 89 ce             	mov    %rcx,%rsi
    601c:	e9 5f f9 ff ff       	jmp    5980 <fwp_write.constprop.0+0x6d0>
    6021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6028:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    602f:	00 
    6030:	48 03 4d 10          	add    0x10(%rbp),%rcx
    6034:	e9 9e f9 ff ff       	jmp    59d7 <fwp_write.constprop.0+0x727>
    6039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6040:	ba 02 00 00 00       	mov    $0x2,%edx
    6045:	48 8d 35 ba 50 00 00 	lea    0x50ba(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    604c:	e9 8d f7 ff ff       	jmp    57de <fwp_write.constprop.0+0x52e>
    6051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6058:	66 0f ef c0          	pxor   %xmm0,%xmm0
    605c:	48 8d 35 9f 50 00 00 	lea    0x509f(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    6063:	48 8d 05 97 50 00 00 	lea    0x5097(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    606a:	4c 89 e7             	mov    %r12,%rdi
    606d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    6071:	48 0f 46 f0          	cmovbe %rax,%rsi
    6075:	e8 56 c3 ff ff       	call   23d0 <strcpy@plt>
    607a:	e9 a1 f2 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    607f:	90                   	nop
    6080:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6084:	48 8d 35 77 50 00 00 	lea    0x5077(%rip),%rsi        # b102 <_IO_stdin_used+0x102>
    608b:	48 8d 05 6f 50 00 00 	lea    0x506f(%rip),%rax        # b101 <_IO_stdin_used+0x101>
    6092:	0f 2f c8             	comiss %xmm0,%xmm1
    6095:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    609c:	00 
    609d:	4c 89 e7             	mov    %r12,%rdi
    60a0:	48 0f 46 f0          	cmovbe %rax,%rsi
    60a4:	e8 27 c3 ff ff       	call   23d0 <strcpy@plt>
    60a9:	e9 72 f2 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    60ae:	66 90                	xchg   %ax,%ax
    60b0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    60b5:	45 85 c0             	test   %r8d,%r8d
    60b8:	75 34                	jne    60ee <fwp_write.constprop.0+0xe3e>
    60ba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    60c1:	00 
    60c2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60c9:	00 00 
    60cb:	0f 85 24 f7 ff ff    	jne    57f5 <fwp_write.constprop.0+0x545>
    60d1:	ba 02 00 00 00       	mov    $0x2,%edx
    60d6:	48 8d 35 a0 50 00 00 	lea    0x50a0(%rip),%rsi        # b17d <_IO_stdin_used+0x17d>
    60dd:	e9 e1 f3 ff ff       	jmp    54c3 <fwp_write.constprop.0+0x213>
    60e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    60e6:	49 89 f0             	mov    %rsi,%r8
    60e9:	e9 85 fe ff ff       	jmp    5f73 <fwp_write.constprop.0+0xcc3>
    60ee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    60f3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    60f8:	85 ff                	test   %edi,%edi
    60fa:	0f 84 3a f4 ff ff    	je     553a <fwp_write.constprop.0+0x28a>
    6100:	ba 01 00 00 00       	mov    $0x1,%edx
    6105:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    610a:	48 89 df             	mov    %rbx,%rdi
    610d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    6112:	e8 99 ce ff ff       	call   2fb0 <buf_put>
    6117:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    611c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    6121:	41 be 01 00 00 00    	mov    $0x1,%r14d
    6127:	85 d2                	test   %edx,%edx
    6129:	0f 8f 30 f4 ff ff    	jg     555f <fwp_write.constprop.0+0x2af>
    612f:	e9 72 f4 ff ff       	jmp    55a6 <fwp_write.constprop.0+0x2f6>
    6134:	48 8b 45 08          	mov    0x8(%rbp),%rax
    6138:	49 89 c5             	mov    %rax,%r13
    613b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6140:	49 89 c4             	mov    %rax,%r12
    6143:	49 c1 fd 3f          	sar    $0x3f,%r13
    6147:	4c 09 e8             	or     %r13,%rax
    614a:	0f 84 a7 00 00 00    	je     61f7 <fwp_write.constprop.0+0xf47>
    6150:	48 8d 2d e9 79 00 00 	lea    0x79e9(%rip),%rbp        # db40 <units.0>
    6157:	4d 89 e7             	mov    %r12,%r15
    615a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    615e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6163:	4c 89 ff             	mov    %r15,%rdi
    6166:	4c 89 ee             	mov    %r13,%rsi
    6169:	44 89 0c 24          	mov    %r9d,(%rsp)
    616d:	48 99                	cqto
    616f:	48 89 d1             	mov    %rdx,%rcx
    6172:	48 89 c2             	mov    %rax,%rdx
    6175:	e8 f6 42 00 00       	call   a470 <__divmodti4>
    617a:	44 8b 0c 24          	mov    (%rsp),%r9d
    617e:	48 89 c1             	mov    %rax,%rcx
    6181:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6186:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    618b:	0f 84 94 00 00 00    	je     6225 <fwp_write.constprop.0+0xf75>
    6191:	41 83 c1 01          	add    $0x1,%r9d
    6195:	48 83 c5 10          	add    $0x10,%rbp
    6199:	41 83 f9 05          	cmp    $0x5,%r9d
    619d:	75 bb                	jne    615a <fwp_write.constprop.0+0xeaa>
    619f:	4d 85 ed             	test   %r13,%r13
    61a2:	79 53                	jns    61f7 <fwp_write.constprop.0+0xf47>
    61a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    61a9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    61ae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    61b3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61b8:	48 99                	cqto
    61ba:	48 f7 d8             	neg    %rax
    61bd:	48 83 d2 00          	adc    $0x0,%rdx
    61c1:	48 89 c6             	mov    %rax,%rsi
    61c4:	48 f7 da             	neg    %rdx
    61c7:	e8 34 c8 ff ff       	call   2a00 <fwp_fmt_u128>
    61cc:	49 89 e8             	mov    %rbp,%r8
    61cf:	ba 00 02 00 00       	mov    $0x200,%edx
    61d4:	be 02 00 00 00       	mov    $0x2,%esi
    61d9:	31 c0                	xor    %eax,%eax
    61db:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    61e2:	00 
    61e3:	48 8d 0d 8e 4f 00 00 	lea    0x4f8e(%rip),%rcx        # b178 <_IO_stdin_used+0x178>
    61ea:	4c 89 e7             	mov    %r12,%rdi
    61ed:	e8 ae c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    61f2:	e9 29 f1 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    61f7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    61fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6201:	31 d2                	xor    %edx,%edx
    6203:	48 89 ef             	mov    %rbp,%rdi
    6206:	e8 f5 c7 ff ff       	call   2a00 <fwp_fmt_u128>
    620b:	eb bf                	jmp    61cc <fwp_write.constprop.0+0xf1c>
    620d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    6214:	4e 61 4e 00 
    6218:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    621f:	00 
    6220:	e9 fb f0 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    6225:	44 89 0c 24          	mov    %r9d,(%rsp)
    6229:	48 89 c8             	mov    %rcx,%rax
    622c:	48 85 d2             	test   %rdx,%rdx
    622f:	78 51                	js     6282 <fwp_write.constprop.0+0xfd2>
    6231:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6236:	48 89 c6             	mov    %rax,%rsi
    6239:	48 89 ef             	mov    %rbp,%rdi
    623c:	e8 bf c7 ff ff       	call   2a00 <fwp_fmt_u128>
    6241:	44 8b 0c 24          	mov    (%rsp),%r9d
    6245:	49 63 c1             	movslq %r9d,%rax
    6248:	49 89 e8             	mov    %rbp,%r8
    624b:	ba 00 02 00 00       	mov    $0x200,%edx
    6250:	be 02 00 00 00       	mov    $0x2,%esi
    6255:	48 c1 e0 04          	shl    $0x4,%rax
    6259:	48 8d 0d e0 78 00 00 	lea    0x78e0(%rip),%rcx        # db40 <units.0>
    6260:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6267:	00 
    6268:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    626c:	4c 89 e7             	mov    %r12,%rdi
    626f:	48 8d 0d fd 4e 00 00 	lea    0x4efd(%rip),%rcx        # b173 <_IO_stdin_used+0x173>
    6276:	31 c0                	xor    %eax,%eax
    6278:	e8 23 c4 ff ff       	call   26a0 <__sprintf_chk@plt>
    627d:	e9 9e f0 ff ff       	jmp    5320 <fwp_write.constprop.0+0x70>
    6282:	48 f7 d8             	neg    %rax
    6285:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    628a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    628f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    6294:	48 83 d2 00          	adc    $0x0,%rdx
    6298:	48 89 c6             	mov    %rax,%rsi
    629b:	48 f7 da             	neg    %rdx
    629e:	e8 5d c7 ff ff       	call   2a00 <fwp_fmt_u128>
    62a3:	44 8b 0c 24          	mov    (%rsp),%r9d
    62a7:	eb 9c                	jmp    6245 <fwp_write.constprop.0+0xf95>
    62a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000062b0 <fwp_hof0.constprop.0>:
    62b0:	41 57                	push   %r15
    62b2:	41 56                	push   %r14
    62b4:	41 55                	push   %r13
    62b6:	41 54                	push   %r12
    62b8:	4c 8d 25 a1 84 01 00 	lea    0x184a1(%rip),%r12        # 1e760 <fwp_heap>
    62bf:	55                   	push   %rbp
    62c0:	53                   	push   %rbx
    62c1:	48 89 fb             	mov    %rdi,%rbx
    62c4:	48 83 ec 38          	sub    $0x38,%rsp
    62c8:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    62cd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    62d4:	00 00 
    62d6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    62db:	31 c0                	xor    %eax,%eax
    62dd:	48 85 f6             	test   %rsi,%rsi
    62e0:	0f 84 91 09 00 00    	je     6c77 <fwp_hof0.constprop.0+0x9c7>
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    62f7:	00 
    62f8:	48 89 d8             	mov    %rbx,%rax
    62fb:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6302:	00 
    6303:	48 c1 e2 10          	shl    $0x10,%rdx
    6307:	48 39 d0             	cmp    %rdx,%rax
    630a:	73 74                	jae    6380 <fwp_hof0.constprop.0+0xd0>
    630c:	48 89 c2             	mov    %rax,%rdx
    630f:	48 c1 ea 10          	shr    $0x10,%rdx
    6313:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6317:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    631e:	00 
    631f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6323:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    6327:	4d 85 ed             	test   %r13,%r13
    632a:	74 54                	je     6380 <fwp_hof0.constprop.0+0xd0>
    632c:	0f b6 0a             	movzbl (%rdx),%ecx
    632f:	80 f9 02             	cmp    $0x2,%cl
    6332:	0f 84 88 0b 00 00    	je     6ec0 <fwp_hof0.constprop.0+0xc10>
    6338:	80 f9 01             	cmp    $0x1,%cl
    633b:	75 43                	jne    6380 <fwp_hof0.constprop.0+0xd0>
    633d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6340:	0f b7 c0             	movzwl %ax,%eax
    6343:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6346:	48 0f af c1          	imul   %rcx,%rax
    634a:	48 c1 e8 20          	shr    $0x20,%rax
    634e:	48 39 d0             	cmp    %rdx,%rax
    6351:	73 2d                	jae    6380 <fwp_hof0.constprop.0+0xd0>
    6353:	49 01 c5             	add    %rax,%r13
    6356:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    635b:	84 c0                	test   %al,%al
    635d:	74 21                	je     6380 <fwp_hof0.constprop.0+0xd0>
    635f:	8b 15 bb a0 01 00    	mov    0x1a0bb(%rip),%edx        # 20420 <iteration_active>
    6365:	85 d2                	test   %edx,%edx
    6367:	74 08                	je     6371 <fwp_hof0.constprop.0+0xc1>
    6369:	48 83 05 97 a0 01 00 	addq   $0x1,0x1a097(%rip)        # 20408 <iteration_retains>
    6370:	01 
    6371:	3c fd                	cmp    $0xfd,%al
    6373:	0f 87 a7 0d 00 00    	ja     7120 <fwp_hof0.constprop.0+0xe70>
    6379:	83 c0 01             	add    $0x1,%eax
    637c:	41 88 45 00          	mov    %al,0x0(%r13)
    6380:	48 85 db             	test   %rbx,%rbx
    6383:	0f 84 49 0b 00 00    	je     6ed2 <fwp_hof0.constprop.0+0xc22>
    6389:	48 89 d8             	mov    %rbx,%rax
    638c:	31 ff                	xor    %edi,%edi
    638e:	66 90                	xchg   %ax,%ax
    6390:	48 8b 40 10          	mov    0x10(%rax),%rax
    6394:	48 83 c7 01          	add    $0x1,%rdi
    6398:	48 85 c0             	test   %rax,%rax
    639b:	75 f3                	jne    6390 <fwp_hof0.constprop.0+0xe0>
    639d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    63a4:	ff ff 1f 
    63a7:	48 39 f8             	cmp    %rdi,%rax
    63aa:	0f 82 2c 0e 00 00    	jb     71dc <fwp_hof0.constprop.0+0xf2c>
    63b0:	e8 5b e7 ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    63b5:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    63bc:	00 
    63bd:	49 89 c5             	mov    %rax,%r13
    63c0:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    63c7:	00 
    63c8:	48 c1 e2 10          	shl    $0x10,%rdx
    63cc:	48 39 d0             	cmp    %rdx,%rax
    63cf:	73 61                	jae    6432 <fwp_hof0.constprop.0+0x182>
    63d1:	48 89 c2             	mov    %rax,%rdx
    63d4:	48 c1 ea 10          	shr    $0x10,%rdx
    63d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    63dc:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    63e3:	00 
    63e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    63e8:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    63ec:	4d 85 f6             	test   %r14,%r14
    63ef:	74 41                	je     6432 <fwp_hof0.constprop.0+0x182>
    63f1:	0f b6 0a             	movzbl (%rdx),%ecx
    63f4:	80 f9 02             	cmp    $0x2,%cl
    63f7:	0f 84 9b 0a 00 00    	je     6e98 <fwp_hof0.constprop.0+0xbe8>
    63fd:	80 f9 01             	cmp    $0x1,%cl
    6400:	75 27                	jne    6429 <fwp_hof0.constprop.0+0x179>
    6402:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6405:	0f b7 c0             	movzwl %ax,%eax
    6408:	8b 52 1c             	mov    0x1c(%rdx),%edx
    640b:	48 0f af c1          	imul   %rcx,%rax
    640f:	48 c1 e8 20          	shr    $0x20,%rax
    6413:	48 39 d0             	cmp    %rdx,%rax
    6416:	73 11                	jae    6429 <fwp_hof0.constprop.0+0x179>
    6418:	49 01 c6             	add    %rax,%r14
    641b:	41 80 3e ff          	cmpb   $0xff,(%r14)
    641f:	0f 84 86 0a 00 00    	je     6eab <fwp_hof0.constprop.0+0xbfb>
    6425:	41 c6 06 01          	movb   $0x1,(%r14)
    6429:	48 85 db             	test   %rbx,%rbx
    642c:	0f 84 0e 0a 00 00    	je     6e40 <fwp_hof0.constprop.0+0xb90>
    6432:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    6436:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    643a:	49 89 d9             	mov    %rbx,%r9
    643d:	48 89 da             	mov    %rbx,%rdx
    6440:	49 89 d8             	mov    %rbx,%r8
    6443:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    6449:	49 8b b4 24 d8 13 00 	mov    0x13d8(%r12),%rsi
    6450:	00 
    6451:	48 89 d0             	mov    %rdx,%rax
    6454:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    645b:	00 
    645c:	48 c1 e6 10          	shl    $0x10,%rsi
    6460:	48 39 f0             	cmp    %rsi,%rax
    6463:	73 67                	jae    64cc <fwp_hof0.constprop.0+0x21c>
    6465:	48 89 c6             	mov    %rax,%rsi
    6468:	48 c1 ee 10          	shr    $0x10,%rsi
    646c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6470:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6477:	00 
    6478:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    647c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    6480:	48 85 ff             	test   %rdi,%rdi
    6483:	74 47                	je     64cc <fwp_hof0.constprop.0+0x21c>
    6485:	44 0f b6 16          	movzbl (%rsi),%r10d
    6489:	41 80 fa 02          	cmp    $0x2,%r10b
    648d:	0f 84 6d 05 00 00    	je     6a00 <fwp_hof0.constprop.0+0x750>
    6493:	41 80 fa 01          	cmp    $0x1,%r10b
    6497:	75 33                	jne    64cc <fwp_hof0.constprop.0+0x21c>
    6499:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    649d:	0f b7 c0             	movzwl %ax,%eax
    64a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    64a3:	49 0f af c2          	imul   %r10,%rax
    64a7:	48 c1 e8 20          	shr    $0x20,%rax
    64ab:	48 39 f0             	cmp    %rsi,%rax
    64ae:	73 1c                	jae    64cc <fwp_hof0.constprop.0+0x21c>
    64b0:	48 01 c7             	add    %rax,%rdi
    64b3:	80 3f 01             	cmpb   $0x1,(%rdi)
    64b6:	75 14                	jne    64cc <fwp_hof0.constprop.0+0x21c>
    64b8:	e9 8b 04 00 00       	jmp    6948 <fwp_hof0.constprop.0+0x698>
    64bd:	0f 1f 00             	nopl   (%rax)
    64c0:	49 8b 4e 08          	mov    0x8(%r14),%rcx
    64c4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    64c8:	49 83 c7 01          	add    $0x1,%r15
    64cc:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    64d1:	0f 88 f9 0c 00 00    	js     71d0 <fwp_hof0.constprop.0+0xf20>
    64d7:	4b 89 4c fd 00       	mov    %rcx,0x0(%r13,%r15,8)
    64dc:	4d 85 f6             	test   %r14,%r14
    64df:	75 df                	jne    64c0 <fwp_hof0.constprop.0+0x210>
    64e1:	4c 89 c7             	mov    %r8,%rdi
    64e4:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    64ea:	e8 f1 ea ff ff       	call   4fe0 <fwp_drop0>
    64ef:	31 c0                	xor    %eax,%eax
    64f1:	48 85 c0             	test   %rax,%rax
    64f4:	0f 85 11 c2 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    64fa:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    6501:	ff ff 7f 
    6504:	4d 23 75 00          	and    0x0(%r13),%r14
    6508:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    650f:	ff ff 1f 
    6512:	4c 39 f0             	cmp    %r14,%rax
    6515:	0f 82 c1 0c 00 00    	jb     71dc <fwp_hof0.constprop.0+0xf2c>
    651b:	4c 89 f7             	mov    %r14,%rdi
    651e:	e8 ed e5 ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    6523:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    652a:	00 
    652b:	f2 0f 10 25 55 51 00 	movsd  0x5155(%rip),%xmm4        # b688 <msg.3+0xb8>
    6532:	00 
    6533:	48 89 c5             	mov    %rax,%rbp
    6536:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    653d:	00 
    653e:	48 c1 e2 10          	shl    $0x10,%rdx
    6542:	48 39 d0             	cmp    %rdx,%rax
    6545:	73 58                	jae    659f <fwp_hof0.constprop.0+0x2ef>
    6547:	48 89 c2             	mov    %rax,%rdx
    654a:	48 c1 ea 10          	shr    $0x10,%rdx
    654e:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6552:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6559:	00 
    655a:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    655e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    6562:	48 85 f6             	test   %rsi,%rsi
    6565:	74 38                	je     659f <fwp_hof0.constprop.0+0x2ef>
    6567:	0f b6 3a             	movzbl (%rdx),%edi
    656a:	40 80 ff 02          	cmp    $0x2,%dil
    656e:	0f 84 64 08 00 00    	je     6dd8 <fwp_hof0.constprop.0+0xb28>
    6574:	40 80 ff 01          	cmp    $0x1,%dil
    6578:	75 25                	jne    659f <fwp_hof0.constprop.0+0x2ef>
    657a:	8b 7a 18             	mov    0x18(%rdx),%edi
    657d:	0f b7 c0             	movzwl %ax,%eax
    6580:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6583:	48 0f af c7          	imul   %rdi,%rax
    6587:	48 c1 e8 20          	shr    $0x20,%rax
    658b:	48 39 d0             	cmp    %rdx,%rax
    658e:	73 0f                	jae    659f <fwp_hof0.constprop.0+0x2ef>
    6590:	48 01 c6             	add    %rax,%rsi
    6593:	80 3e ff             	cmpb   $0xff,(%rsi)
    6596:	0f 84 4e 08 00 00    	je     6dea <fwp_hof0.constprop.0+0xb3a>
    659c:	c6 06 01             	movb   $0x1,(%rsi)
    659f:	ba 08 00 00 00       	mov    $0x8,%edx
    65a4:	be 01 00 00 00       	mov    $0x1,%esi
    65a9:	31 c0                	xor    %eax,%eax
    65ab:	4d 85 f6             	test   %r14,%r14
    65ae:	0f 84 57 01 00 00    	je     670b <fwp_hof0.constprop.0+0x45b>
    65b4:	f2 0f 10 1d d4 50 00 	movsd  0x50d4(%rip),%xmm3        # b690 <msg.3+0xc0>
    65bb:	00 
    65bc:	f2 0f 10 2d c4 50 00 	movsd  0x50c4(%rip),%xmm5        # b688 <msg.3+0xb8>
    65c3:	00 
    65c4:	49 8d 7d 08          	lea    0x8(%r13),%rdi
    65c8:	66 0f ef d2          	pxor   %xmm2,%xmm2
    65cc:	0f 1f 40 00          	nopl   0x0(%rax)
    65d0:	49 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r8
    65d7:	ff ff 7f 
    65da:	4d 8b 55 00          	mov    0x0(%r13),%r10
    65de:	4d 21 d0             	and    %r10,%r8
    65e1:	4c 39 c0             	cmp    %r8,%rax
    65e4:	0f 83 86 00 00 00    	jae    6670 <fwp_hof0.constprop.0+0x3c0>
    65ea:	49 89 f9             	mov    %rdi,%r9
    65ed:	4d 85 d2             	test   %r10,%r10
    65f0:	0f 88 fa 03 00 00    	js     69f0 <fwp_hof0.constprop.0+0x740>
    65f6:	f3 41 0f 7e 34 c1    	movq   (%r9,%rax,8),%xmm6
    65fc:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6600:	48 85 c0             	test   %rax,%rax
    6603:	74 5d                	je     6662 <fwp_hof0.constprop.0+0x3b2>
    6605:	f2 41 0f 10 7c 11 f0 	movsd  -0x10(%r9,%rdx,1),%xmm7
    660c:	66 0f 28 c6          	movapd %xmm6,%xmm0
    6610:	66 0f 28 cf          	movapd %xmm7,%xmm1
    6614:	f2 0f 59 cf          	mulsd  %xmm7,%xmm1
    6618:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
    661c:	66 0f 28 cf          	movapd %xmm7,%xmm1
    6620:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    6624:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6628:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
    662d:	66 0f 28 cc          	movapd %xmm4,%xmm1
    6631:	f2 41 0f 5c c8       	subsd  %xmm8,%xmm1
    6636:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    663a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    663e:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6642:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6646:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
    664a:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
    664e:	66 0f 28 c4          	movapd %xmm4,%xmm0
    6652:	f2 0f 5c c7          	subsd  %xmm7,%xmm0
    6656:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    665a:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    665e:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
    6662:	49 39 f0             	cmp    %rsi,%r8
    6665:	0f 84 15 02 00 00    	je     6880 <fwp_hof0.constprop.0+0x5d0>
    666b:	4c 39 c6             	cmp    %r8,%rsi
    666e:	72 10                	jb     6680 <fwp_hof0.constprop.0+0x3d0>
    6670:	48 8d 3d b1 79 00 00 	lea    0x79b1(%rip),%rdi        # e028 <s0+0x8>
    6677:	e8 84 cb ff ff       	call   3200 <fwp_trap>
    667c:	0f 1f 40 00          	nopl   0x0(%rax)
    6680:	66 0f 28 c6          	movapd %xmm6,%xmm0
    6684:	66 44 0f 28 ce       	movapd %xmm6,%xmm9
    6689:	f3 41 0f 7e 3c 11    	movq   (%r9,%rdx,1),%xmm7
    668f:	f2 0f 59 c6          	mulsd  %xmm6,%xmm0
    6693:	f2 44 0f 58 ce       	addsd  %xmm6,%xmm9
    6698:	f2 0f 5c f8          	subsd  %xmm0,%xmm7
    669c:	66 0f 28 c2          	movapd %xmm2,%xmm0
    66a0:	f2 41 0f 5c c1       	subsd  %xmm9,%xmm0
    66a5:	f2 0f 59 c7          	mulsd  %xmm7,%xmm0
    66a9:	f2 0f 59 ff          	mulsd  %xmm7,%xmm7
    66ad:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    66b1:	f2 0f 59 fa          	mulsd  %xmm2,%xmm7
    66b5:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    66b9:	f2 0f 58 c7          	addsd  %xmm7,%xmm0
    66bd:	66 0f 28 fd          	movapd %xmm5,%xmm7
    66c1:	f2 0f 5c fe          	subsd  %xmm6,%xmm7
    66c5:	66 0f 57 3d 93 4f 00 	xorpd  0x4f93(%rip),%xmm7        # b660 <msg.3+0x90>
    66cc:	00 
    66cd:	f2 0f 58 ff          	addsd  %xmm7,%xmm7
    66d1:	f2 0f 58 c7          	addsd  %xmm7,%xmm0
    66d5:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    66da:	0f 88 f0 0a 00 00    	js     71d0 <fwp_hof0.constprop.0+0xf20>
    66e0:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    66e4:	f2 0f 59 05 ac 4f 00 	mulsd  0x4fac(%rip),%xmm0        # b698 <msg.3+0xc8>
    66eb:	00 
    66ec:	48 83 c0 01          	add    $0x1,%rax
    66f0:	48 83 c6 01          	add    $0x1,%rsi
    66f4:	f2 0f 5c f0          	subsd  %xmm0,%xmm6
    66f8:	f2 0f 11 74 15 00    	movsd  %xmm6,0x0(%rbp,%rdx,1)
    66fe:	48 83 c2 08          	add    $0x8,%rdx
    6702:	49 39 c6             	cmp    %rax,%r14
    6705:	0f 85 c5 fe ff ff    	jne    65d0 <fwp_hof0.constprop.0+0x320>
    670b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6712:	00 
    6713:	4c 89 e8             	mov    %r13,%rax
    6716:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    671d:	00 
    671e:	48 c1 e2 10          	shl    $0x10,%rdx
    6722:	48 39 d0             	cmp    %rdx,%rax
    6725:	73 79                	jae    67a0 <fwp_hof0.constprop.0+0x4f0>
    6727:	48 89 c2             	mov    %rax,%rdx
    672a:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6731:	00 
    6732:	48 c1 ea 10          	shr    $0x10,%rdx
    6736:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    673a:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    673e:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6742:	4d 85 f6             	test   %r14,%r14
    6745:	74 59                	je     67a0 <fwp_hof0.constprop.0+0x4f0>
    6747:	0f b6 3a             	movzbl (%rdx),%edi
    674a:	40 80 ff 02          	cmp    $0x2,%dil
    674e:	0f 84 e4 05 00 00    	je     6d38 <fwp_hof0.constprop.0+0xa88>
    6754:	40 80 ff 01          	cmp    $0x1,%dil
    6758:	75 46                	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    675a:	8b 7a 18             	mov    0x18(%rdx),%edi
    675d:	0f b7 c0             	movzwl %ax,%eax
    6760:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6763:	48 0f af c7          	imul   %rdi,%rax
    6767:	48 c1 e8 20          	shr    $0x20,%rax
    676b:	48 39 d0             	cmp    %rdx,%rax
    676e:	73 30                	jae    67a0 <fwp_hof0.constprop.0+0x4f0>
    6770:	49 01 c6             	add    %rax,%r14
    6773:	41 0f b6 06          	movzbl (%r14),%eax
    6777:	84 c0                	test   %al,%al
    6779:	74 25                	je     67a0 <fwp_hof0.constprop.0+0x4f0>
    677b:	3c 01                	cmp    $0x1,%al
    677d:	0f 84 0d 01 00 00    	je     6890 <fwp_hof0.constprop.0+0x5e0>
    6783:	3c ff                	cmp    $0xff,%al
    6785:	0f 84 11 08 00 00    	je     6f9c <fwp_hof0.constprop.0+0xcec>
    678b:	83 e8 01             	sub    $0x1,%eax
    678e:	41 88 06             	mov    %al,(%r14)
    6791:	0f 1f 40 00          	nopl   0x0(%rax)
    6795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    679c:	00 00 00 00 
    67a0:	4d 85 ff             	test   %r15,%r15
    67a3:	0f 85 87 01 00 00    	jne    6930 <fwp_hof0.constprop.0+0x680>
    67a9:	4c 8d 6c 24 10       	lea    0x10(%rsp),%r13
    67ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67b2:	be 01 00 00 00       	mov    $0x1,%esi
    67b7:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    67be:	00 00 
    67c0:	4c 89 ef             	mov    %r13,%rdi
    67c3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67c8:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    67cf:	ff ff 7f 
    67d2:	e8 19 c7 ff ff       	call   2ef0 <buf_grow>
    67d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    67dc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    67e1:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    67e5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    67ea:	48 8d 50 01          	lea    0x1(%rax),%rdx
    67ee:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    67f3:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    67f8:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    67fd:	48 8d 45 08          	lea    0x8(%rbp),%rax
    6801:	48 89 04 24          	mov    %rax,(%rsp)
    6805:	4c 23 75 00          	and    0x0(%rbp),%r14
    6809:	75 5c                	jne    6867 <fwp_hof0.constprop.0+0x5b7>
    680b:	e9 00 02 00 00       	jmp    6a10 <fwp_hof0.constprop.0+0x760>
    6810:	4a 8b 34 fa          	mov    (%rdx,%r15,8),%rsi
    6814:	4c 89 ef             	mov    %r13,%rdi
    6817:	48 8d 15 82 73 00 00 	lea    0x7382(%rip),%rdx        # dba0 <d0>
    681e:	49 83 c7 01          	add    $0x1,%r15
    6822:	e8 89 ea ff ff       	call   52b0 <fwp_write.constprop.0>
    6827:	4d 39 fe             	cmp    %r15,%r14
    682a:	0f 84 e0 01 00 00    	je     6a10 <fwp_hof0.constprop.0+0x760>
    6830:	be 02 00 00 00       	mov    $0x2,%esi
    6835:	4c 89 ef             	mov    %r13,%rdi
    6838:	e8 b3 c6 ff ff       	call   2ef0 <buf_grow>
    683d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6842:	b8 2c 20 00 00       	mov    $0x202c,%eax
    6847:	48 03 54 24 10       	add    0x10(%rsp),%rdx
    684c:	66 89 02             	mov    %ax,(%rdx)
    684f:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6854:	48 8d 72 02          	lea    0x2(%rdx),%rsi
    6858:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    685d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6862:	c6 44 16 02 00       	movb   $0x0,0x2(%rsi,%rdx,1)
    6867:	48 8b 14 24          	mov    (%rsp),%rdx
    686b:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6870:	79 9e                	jns    6810 <fwp_hof0.constprop.0+0x560>
    6872:	48 8b 55 10          	mov    0x10(%rbp),%rdx
    6876:	eb 98                	jmp    6810 <fwp_hof0.constprop.0+0x560>
    6878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    687f:	00 
    6880:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6884:	e9 4c fe ff ff       	jmp    66d5 <fwp_hof0.constprop.0+0x425>
    6889:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6890:	49 8b bc 24 b0 13 00 	mov    0x13b0(%r12),%rdi
    6897:	00 
    6898:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    689f:	00 
    68a0:	4c 89 e8             	mov    %r13,%rax
    68a3:	4d 89 e8             	mov    %r13,%r8
    68a6:	48 29 f8             	sub    %rdi,%rax
    68a9:	48 c1 e2 10          	shl    $0x10,%rdx
    68ad:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    68b2:	0f 88 98 04 00 00    	js     6d50 <fwp_hof0.constprop.0+0xaa0>
    68b8:	48 39 d0             	cmp    %rdx,%rax
    68bb:	0f 83 df fe ff ff    	jae    67a0 <fwp_hof0.constprop.0+0x4f0>
    68c1:	48 89 c2             	mov    %rax,%rdx
    68c4:	48 c1 ea 10          	shr    $0x10,%rdx
    68c8:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    68cc:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    68d0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    68d4:	48 85 f6             	test   %rsi,%rsi
    68d7:	0f 84 c3 fe ff ff    	je     67a0 <fwp_hof0.constprop.0+0x4f0>
    68dd:	0f b6 3a             	movzbl (%rdx),%edi
    68e0:	40 80 ff 02          	cmp    $0x2,%dil
    68e4:	0f 84 26 05 00 00    	je     6e10 <fwp_hof0.constprop.0+0xb60>
    68ea:	40 80 ff 01          	cmp    $0x1,%dil
    68ee:	0f 85 ac fe ff ff    	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    68f4:	8b 7a 18             	mov    0x18(%rdx),%edi
    68f7:	0f b7 c0             	movzwl %ax,%eax
    68fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    68fd:	48 0f af c7          	imul   %rdi,%rax
    6901:	48 c1 e8 20          	shr    $0x20,%rax
    6905:	48 39 d0             	cmp    %rdx,%rax
    6908:	0f 83 92 fe ff ff    	jae    67a0 <fwp_hof0.constprop.0+0x4f0>
    690e:	48 01 c6             	add    %rax,%rsi
    6911:	80 3e 01             	cmpb   $0x1,(%rsi)
    6914:	0f 85 86 fe ff ff    	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    691a:	4c 89 ef             	mov    %r13,%rdi
    691d:	e8 ee d7 ff ff       	call   4110 <fwp_mem_free>
    6922:	4d 85 ff             	test   %r15,%r15
    6925:	0f 84 7e fe ff ff    	je     67a9 <fwp_hof0.constprop.0+0x4f9>
    692b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6930:	31 c0                	xor    %eax,%eax
    6932:	49 83 ef 01          	sub    $0x1,%r15
    6936:	49 89 ed             	mov    %rbp,%r13
    6939:	0f 90 c0             	seto   %al
    693c:	e9 b0 fb ff ff       	jmp    64f1 <fwp_hof0.constprop.0+0x241>
    6941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6948:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    694d:	0f 88 7d 08 00 00    	js     71d0 <fwp_hof0.constprop.0+0xf20>
    6953:	4b 89 4c fd 00       	mov    %rcx,0x0(%r13,%r15,8)
    6958:	49 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%rax
    695f:	00 
    6960:	49 2b 94 24 b0 13 00 	sub    0x13b0(%r12),%rdx
    6967:	00 
    6968:	48 c1 e0 10          	shl    $0x10,%rax
    696c:	48 39 c2             	cmp    %rax,%rdx
    696f:	73 59                	jae    69ca <fwp_hof0.constprop.0+0x71a>
    6971:	48 89 d0             	mov    %rdx,%rax
    6974:	48 c1 e8 10          	shr    $0x10,%rax
    6978:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    697c:	49 8b 84 24 f8 13 00 	mov    0x13f8(%r12),%rax
    6983:	00 
    6984:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    6988:	48 8b 48 20          	mov    0x20(%rax),%rcx
    698c:	48 85 c9             	test   %rcx,%rcx
    698f:	74 39                	je     69ca <fwp_hof0.constprop.0+0x71a>
    6991:	0f b6 30             	movzbl (%rax),%esi
    6994:	40 80 fe 02          	cmp    $0x2,%sil
    6998:	0f 84 82 04 00 00    	je     6e20 <fwp_hof0.constprop.0+0xb70>
    699e:	40 80 fe 01          	cmp    $0x1,%sil
    69a2:	75 26                	jne    69ca <fwp_hof0.constprop.0+0x71a>
    69a4:	8b 70 18             	mov    0x18(%rax),%esi
    69a7:	0f b7 d2             	movzwl %dx,%edx
    69aa:	8b 40 1c             	mov    0x1c(%rax),%eax
    69ad:	48 0f af d6          	imul   %rsi,%rdx
    69b1:	48 c1 ea 20          	shr    $0x20,%rdx
    69b5:	48 39 c2             	cmp    %rax,%rdx
    69b8:	73 10                	jae    69ca <fwp_hof0.constprop.0+0x71a>
    69ba:	48 01 d1             	add    %rdx,%rcx
    69bd:	80 39 01             	cmpb   $0x1,(%rcx)
    69c0:	75 08                	jne    69ca <fwp_hof0.constprop.0+0x71a>
    69c2:	4c 89 cf             	mov    %r9,%rdi
    69c5:	e8 46 d7 ff ff       	call   4110 <fwp_mem_free>
    69ca:	4d 85 f6             	test   %r14,%r14
    69cd:	0f 84 6d 04 00 00    	je     6e40 <fwp_hof0.constprop.0+0xb90>
    69d3:	49 8b 4e 08          	mov    0x8(%r14),%rcx
    69d7:	4d 89 f1             	mov    %r14,%r9
    69da:	4c 89 f2             	mov    %r14,%rdx
    69dd:	4d 89 f0             	mov    %r14,%r8
    69e0:	49 83 c7 01          	add    $0x1,%r15
    69e4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    69e8:	e9 5c fa ff ff       	jmp    6449 <fwp_hof0.constprop.0+0x199>
    69ed:	0f 1f 00             	nopl   (%rax)
    69f0:	4d 8b 4d 10          	mov    0x10(%r13),%r9
    69f4:	e9 fd fb ff ff       	jmp    65f6 <fwp_hof0.constprop.0+0x346>
    69f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a00:	66 85 c0             	test   %ax,%ax
    6a03:	0f 85 c3 fa ff ff    	jne    64cc <fwp_hof0.constprop.0+0x21c>
    6a09:	e9 a5 fa ff ff       	jmp    64b3 <fwp_hof0.constprop.0+0x203>
    6a0e:	66 90                	xchg   %ax,%ax
    6a10:	be 01 00 00 00       	mov    $0x1,%esi
    6a15:	4c 89 ef             	mov    %r13,%rdi
    6a18:	e8 d3 c4 ff ff       	call   2ef0 <buf_grow>
    6a1d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6a22:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6a27:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    6a2b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6a30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6a34:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    6a39:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6a3e:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6a43:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6a48:	48 8d 05 1f 46 00 00 	lea    0x461f(%rip),%rax        # b06e <_IO_stdin_used+0x6e>
    6a4f:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    6a54:	4d 85 c0             	test   %r8,%r8
    6a57:	4c 0f 44 c0          	cmove  %rax,%r8
    6a5b:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    6a5f:	0f 87 b0 07 00 00    	ja     7215 <fwp_hof0.constprop.0+0xf65>
    6a65:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    6a69:	be 01 00 00 00       	mov    $0x1,%esi
    6a6e:	4c 89 04 24          	mov    %r8,(%rsp)
    6a72:	e8 c9 dc ff ff       	call   4740 <fwp_heap_alloc>
    6a77:	48 8b 34 24          	mov    (%rsp),%rsi
    6a7b:	4c 89 fa             	mov    %r15,%rdx
    6a7e:	4c 89 38             	mov    %r15,(%rax)
    6a81:	4c 8d 68 08          	lea    0x8(%rax),%r13
    6a85:	49 89 c6             	mov    %rax,%r14
    6a88:	4c 89 ef             	mov    %r13,%rdi
    6a8b:	e8 e0 ba ff ff       	call   2570 <memcpy@plt>
    6a90:	43 c6 44 3e 08 00    	movb   $0x0,0x8(%r14,%r15,1)
    6a96:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    6a9b:	e8 00 b9 ff ff       	call   23a0 <free@plt>
    6aa0:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    6aa7:	00 
    6aa8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6aaf:	00 
    6ab0:	4c 89 f0             	mov    %r14,%rax
    6ab3:	48 29 f0             	sub    %rsi,%rax
    6ab6:	48 c1 e2 10          	shl    $0x10,%rdx
    6aba:	48 39 d0             	cmp    %rdx,%rax
    6abd:	73 70                	jae    6b2f <fwp_hof0.constprop.0+0x87f>
    6abf:	48 89 c7             	mov    %rax,%rdi
    6ac2:	48 c1 ef 10          	shr    $0x10,%rdi
    6ac6:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    6aca:	49 8b bc 24 f8 13 00 	mov    0x13f8(%r12),%rdi
    6ad1:	00 
    6ad2:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    6ad6:	4c 8b 7f 20          	mov    0x20(%rdi),%r15
    6ada:	4d 85 ff             	test   %r15,%r15
    6add:	74 50                	je     6b2f <fwp_hof0.constprop.0+0x87f>
    6adf:	44 0f b6 07          	movzbl (%rdi),%r8d
    6ae3:	41 80 f8 02          	cmp    $0x2,%r8b
    6ae7:	0f 84 6b 04 00 00    	je     6f58 <fwp_hof0.constprop.0+0xca8>
    6aed:	41 80 f8 01          	cmp    $0x1,%r8b
    6af1:	75 3c                	jne    6b2f <fwp_hof0.constprop.0+0x87f>
    6af3:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    6af7:	0f b7 c0             	movzwl %ax,%eax
    6afa:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    6afd:	49 0f af c0          	imul   %r8,%rax
    6b01:	48 c1 e8 20          	shr    $0x20,%rax
    6b05:	48 39 f8             	cmp    %rdi,%rax
    6b08:	73 25                	jae    6b2f <fwp_hof0.constprop.0+0x87f>
    6b0a:	49 01 c7             	add    %rax,%r15
    6b0d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6b11:	0f 84 54 04 00 00    	je     6f6b <fwp_hof0.constprop.0+0xcbb>
    6b17:	41 c6 07 01          	movb   $0x1,(%r15)
    6b1b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6b22:	00 
    6b23:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    6b2a:	00 
    6b2b:	48 c1 e2 10          	shl    $0x10,%rdx
    6b2f:	48 89 e8             	mov    %rbp,%rax
    6b32:	48 29 f0             	sub    %rsi,%rax
    6b35:	48 39 d0             	cmp    %rdx,%rax
    6b38:	73 76                	jae    6bb0 <fwp_hof0.constprop.0+0x900>
    6b3a:	48 89 c2             	mov    %rax,%rdx
    6b3d:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6b44:	00 
    6b45:	48 c1 ea 10          	shr    $0x10,%rdx
    6b49:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6b4d:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    6b51:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    6b55:	4d 85 ff             	test   %r15,%r15
    6b58:	74 56                	je     6bb0 <fwp_hof0.constprop.0+0x900>
    6b5a:	0f b6 3a             	movzbl (%rdx),%edi
    6b5d:	40 80 ff 02          	cmp    $0x2,%dil
    6b61:	0f 84 e9 02 00 00    	je     6e50 <fwp_hof0.constprop.0+0xba0>
    6b67:	40 80 ff 01          	cmp    $0x1,%dil
    6b6b:	75 43                	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    6b6d:	8b 7a 18             	mov    0x18(%rdx),%edi
    6b70:	0f b7 c0             	movzwl %ax,%eax
    6b73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b76:	48 0f af c7          	imul   %rdi,%rax
    6b7a:	48 c1 e8 20          	shr    $0x20,%rax
    6b7e:	48 39 d0             	cmp    %rdx,%rax
    6b81:	73 2d                	jae    6bb0 <fwp_hof0.constprop.0+0x900>
    6b83:	49 01 c7             	add    %rax,%r15
    6b86:	41 0f b6 07          	movzbl (%r15),%eax
    6b8a:	84 c0                	test   %al,%al
    6b8c:	74 22                	je     6bb0 <fwp_hof0.constprop.0+0x900>
    6b8e:	3c 01                	cmp    $0x1,%al
    6b90:	0f 84 0a 01 00 00    	je     6ca0 <fwp_hof0.constprop.0+0x9f0>
    6b96:	3c ff                	cmp    $0xff,%al
    6b98:	0f 84 81 04 00 00    	je     701f <fwp_hof0.constprop.0+0xd6f>
    6b9e:	83 e8 01             	sub    $0x1,%eax
    6ba1:	41 88 07             	mov    %al,(%r15)
    6ba4:	90                   	nop
    6ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bac:	00 00 00 00 
    6bb0:	49 8b 16             	mov    (%r14),%rdx
    6bb3:	48 8b 0d fe 97 01 00 	mov    0x197fe(%rip),%rcx        # 203b8 <fwp_prog_out>
    6bba:	be 01 00 00 00       	mov    $0x1,%esi
    6bbf:	4c 89 ef             	mov    %r13,%rdi
    6bc2:	e8 79 ba ff ff       	call   2640 <fwrite@plt>
    6bc7:	48 8b 35 ea 97 01 00 	mov    0x197ea(%rip),%rsi        # 203b8 <fwp_prog_out>
    6bce:	bf 0a 00 00 00       	mov    $0xa,%edi
    6bd3:	e8 e8 b8 ff ff       	call   24c0 <fputc@plt>
    6bd8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6bdf:	00 
    6be0:	4c 89 f0             	mov    %r14,%rax
    6be3:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6bea:	00 
    6beb:	48 c1 e2 10          	shl    $0x10,%rdx
    6bef:	48 39 d0             	cmp    %rdx,%rax
    6bf2:	73 6c                	jae    6c60 <fwp_hof0.constprop.0+0x9b0>
    6bf4:	48 89 c2             	mov    %rax,%rdx
    6bf7:	48 c1 ea 10          	shr    $0x10,%rdx
    6bfb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bff:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6c06:	00 
    6c07:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6c0b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    6c0f:	4d 85 ed             	test   %r13,%r13
    6c12:	74 4c                	je     6c60 <fwp_hof0.constprop.0+0x9b0>
    6c14:	0f b6 0a             	movzbl (%rdx),%ecx
    6c17:	80 f9 02             	cmp    $0x2,%cl
    6c1a:	0f 84 08 03 00 00    	je     6f28 <fwp_hof0.constprop.0+0xc78>
    6c20:	80 f9 01             	cmp    $0x1,%cl
    6c23:	75 3b                	jne    6c60 <fwp_hof0.constprop.0+0x9b0>
    6c25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c28:	0f b7 c0             	movzwl %ax,%eax
    6c2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c2e:	48 0f af c1          	imul   %rcx,%rax
    6c32:	48 c1 e8 20          	shr    $0x20,%rax
    6c36:	48 39 d0             	cmp    %rdx,%rax
    6c39:	73 25                	jae    6c60 <fwp_hof0.constprop.0+0x9b0>
    6c3b:	49 01 c5             	add    %rax,%r13
    6c3e:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    6c43:	84 c0                	test   %al,%al
    6c45:	74 19                	je     6c60 <fwp_hof0.constprop.0+0x9b0>
    6c47:	3c 01                	cmp    $0x1,%al
    6c49:	0f 84 f7 02 00 00    	je     6f46 <fwp_hof0.constprop.0+0xc96>
    6c4f:	3c ff                	cmp    $0xff,%al
    6c51:	0f 84 48 04 00 00    	je     709f <fwp_hof0.constprop.0+0xdef>
    6c57:	83 e8 01             	sub    $0x1,%eax
    6c5a:	41 88 45 00          	mov    %al,0x0(%r13)
    6c5e:	66 90                	xchg   %ax,%ax
    6c60:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6c65:	48 8b 40 10          	mov    0x10(%rax),%rax
    6c69:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6c6e:	48 85 c0             	test   %rax,%rax
    6c71:	0f 85 79 f6 ff ff    	jne    62f0 <fwp_hof0.constprop.0+0x40>
    6c77:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c7c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c83:	00 00 
    6c85:	0f 85 a7 05 00 00    	jne    7232 <fwp_hof0.constprop.0+0xf82>
    6c8b:	48 83 c4 38          	add    $0x38,%rsp
    6c8f:	31 c0                	xor    %eax,%eax
    6c91:	5b                   	pop    %rbx
    6c92:	5d                   	pop    %rbp
    6c93:	41 5c                	pop    %r12
    6c95:	41 5d                	pop    %r13
    6c97:	41 5e                	pop    %r14
    6c99:	41 5f                	pop    %r15
    6c9b:	c3                   	ret
    6c9c:	0f 1f 40 00          	nopl   0x0(%rax)
    6ca0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6ca5:	0f 88 b5 01 00 00    	js     6e60 <fwp_hof0.constprop.0+0xbb0>
    6cab:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6cb2:	00 
    6cb3:	48 89 e8             	mov    %rbp,%rax
    6cb6:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6cbd:	00 
    6cbe:	48 c1 e2 10          	shl    $0x10,%rdx
    6cc2:	48 39 d0             	cmp    %rdx,%rax
    6cc5:	0f 83 e5 fe ff ff    	jae    6bb0 <fwp_hof0.constprop.0+0x900>
    6ccb:	48 89 c2             	mov    %rax,%rdx
    6cce:	48 c1 ea 10          	shr    $0x10,%rdx
    6cd2:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    6cd6:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    6cda:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    6cde:	48 85 f6             	test   %rsi,%rsi
    6ce1:	0f 84 c9 fe ff ff    	je     6bb0 <fwp_hof0.constprop.0+0x900>
    6ce7:	0f b6 3a             	movzbl (%rdx),%edi
    6cea:	40 80 ff 02          	cmp    $0x2,%dil
    6cee:	0f 84 8c 02 00 00    	je     6f80 <fwp_hof0.constprop.0+0xcd0>
    6cf4:	40 80 ff 01          	cmp    $0x1,%dil
    6cf8:	0f 85 b2 fe ff ff    	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    6cfe:	8b 7a 18             	mov    0x18(%rdx),%edi
    6d01:	0f b7 c0             	movzwl %ax,%eax
    6d04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d07:	48 0f af c7          	imul   %rdi,%rax
    6d0b:	48 c1 e8 20          	shr    $0x20,%rax
    6d0f:	48 39 d0             	cmp    %rdx,%rax
    6d12:	0f 83 98 fe ff ff    	jae    6bb0 <fwp_hof0.constprop.0+0x900>
    6d18:	48 01 c6             	add    %rax,%rsi
    6d1b:	80 3e 01             	cmpb   $0x1,(%rsi)
    6d1e:	0f 85 8c fe ff ff    	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    6d24:	48 89 ef             	mov    %rbp,%rdi
    6d27:	e8 e4 d3 ff ff       	call   4110 <fwp_mem_free>
    6d2c:	e9 7f fe ff ff       	jmp    6bb0 <fwp_hof0.constprop.0+0x900>
    6d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d38:	66 85 c0             	test   %ax,%ax
    6d3b:	0f 85 5f fa ff ff    	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    6d41:	e9 2d fa ff ff       	jmp    6773 <fwp_hof0.constprop.0+0x4c3>
    6d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d4d:	00 00 00 
    6d50:	4d 8b 6d 08          	mov    0x8(%r13),%r13
    6d54:	48 39 d0             	cmp    %rdx,%rax
    6d57:	73 68                	jae    6dc1 <fwp_hof0.constprop.0+0xb11>
    6d59:	49 89 c1             	mov    %rax,%r9
    6d5c:	49 c1 e9 10          	shr    $0x10,%r9
    6d60:	4f 8d 0c 89          	lea    (%r9,%r9,4),%r9
    6d64:	4a 8d 34 ce          	lea    (%rsi,%r9,8),%rsi
    6d68:	4c 8b 4e 20          	mov    0x20(%rsi),%r9
    6d6c:	4d 85 c9             	test   %r9,%r9
    6d6f:	74 50                	je     6dc1 <fwp_hof0.constprop.0+0xb11>
    6d71:	44 0f b6 16          	movzbl (%rsi),%r10d
    6d75:	41 80 fa 02          	cmp    $0x2,%r10b
    6d79:	0f 84 0f 02 00 00    	je     6f8e <fwp_hof0.constprop.0+0xcde>
    6d7f:	41 80 fa 01          	cmp    $0x1,%r10b
    6d83:	75 3c                	jne    6dc1 <fwp_hof0.constprop.0+0xb11>
    6d85:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    6d89:	0f b7 c0             	movzwl %ax,%eax
    6d8c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d8f:	49 0f af c2          	imul   %r10,%rax
    6d93:	48 c1 e8 20          	shr    $0x20,%rax
    6d97:	48 39 f0             	cmp    %rsi,%rax
    6d9a:	73 25                	jae    6dc1 <fwp_hof0.constprop.0+0xb11>
    6d9c:	49 01 c1             	add    %rax,%r9
    6d9f:	41 80 39 01          	cmpb   $0x1,(%r9)
    6da3:	75 1c                	jne    6dc1 <fwp_hof0.constprop.0+0xb11>
    6da5:	4c 89 c7             	mov    %r8,%rdi
    6da8:	e8 63 d3 ff ff       	call   4110 <fwp_mem_free>
    6dad:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6db4:	00 
    6db5:	49 8b bc 24 b0 13 00 	mov    0x13b0(%r12),%rdi
    6dbc:	00 
    6dbd:	48 c1 e2 10          	shl    $0x10,%rdx
    6dc1:	4c 89 e8             	mov    %r13,%rax
    6dc4:	48 29 f8             	sub    %rdi,%rax
    6dc7:	48 39 d0             	cmp    %rdx,%rax
    6dca:	0f 82 57 f9 ff ff    	jb     6727 <fwp_hof0.constprop.0+0x477>
    6dd0:	e9 cb f9 ff ff       	jmp    67a0 <fwp_hof0.constprop.0+0x4f0>
    6dd5:	0f 1f 00             	nopl   (%rax)
    6dd8:	66 85 c0             	test   %ax,%ax
    6ddb:	0f 85 be f7 ff ff    	jne    659f <fwp_hof0.constprop.0+0x2ef>
    6de1:	80 3e ff             	cmpb   $0xff,(%rsi)
    6de4:	0f 85 b2 f7 ff ff    	jne    659c <fwp_hof0.constprop.0+0x2ec>
    6dea:	48 89 f7             	mov    %rsi,%rdi
    6ded:	48 89 34 24          	mov    %rsi,(%rsp)
    6df1:	e8 da d0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6df6:	f2 0f 10 25 8a 48 00 	movsd  0x488a(%rip),%xmm4        # b688 <msg.3+0xb8>
    6dfd:	00 
    6dfe:	48 8b 34 24          	mov    (%rsp),%rsi
    6e02:	e9 95 f7 ff ff       	jmp    659c <fwp_hof0.constprop.0+0x2ec>
    6e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e0e:	00 00 
    6e10:	66 85 c0             	test   %ax,%ax
    6e13:	0f 85 87 f9 ff ff    	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    6e19:	e9 f3 fa ff ff       	jmp    6911 <fwp_hof0.constprop.0+0x661>
    6e1e:	66 90                	xchg   %ax,%ax
    6e20:	66 85 d2             	test   %dx,%dx
    6e23:	0f 84 94 fb ff ff    	je     69bd <fwp_hof0.constprop.0+0x70d>
    6e29:	4d 85 f6             	test   %r14,%r14
    6e2c:	0f 85 a1 fb ff ff    	jne    69d3 <fwp_hof0.constprop.0+0x723>
    6e32:	0f 1f 00             	nopl   (%rax)
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	45 31 c0             	xor    %r8d,%r8d
    6e43:	e9 99 f6 ff ff       	jmp    64e1 <fwp_hof0.constprop.0+0x231>
    6e48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e4f:	00 
    6e50:	66 85 c0             	test   %ax,%ax
    6e53:	0f 85 57 fd ff ff    	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    6e59:	e9 28 fd ff ff       	jmp    6b86 <fwp_hof0.constprop.0+0x8d6>
    6e5e:	66 90                	xchg   %ax,%ax
    6e60:	48 89 ef             	mov    %rbp,%rdi
    6e63:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6e67:	e8 54 d8 ff ff       	call   46c0 <fwp_rc_free_arr>
    6e6c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6e73:	00 
    6e74:	4c 89 f8             	mov    %r15,%rax
    6e77:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6e7e:	00 
    6e7f:	48 c1 e2 10          	shl    $0x10,%rdx
    6e83:	48 39 d0             	cmp    %rdx,%rax
    6e86:	0f 83 24 fd ff ff    	jae    6bb0 <fwp_hof0.constprop.0+0x900>
    6e8c:	4c 89 fd             	mov    %r15,%rbp
    6e8f:	e9 a6 fc ff ff       	jmp    6b3a <fwp_hof0.constprop.0+0x88a>
    6e94:	0f 1f 40 00          	nopl   0x0(%rax)
    6e98:	66 85 c0             	test   %ax,%ax
    6e9b:	0f 85 88 f5 ff ff    	jne    6429 <fwp_hof0.constprop.0+0x179>
    6ea1:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6ea5:	0f 85 7a f5 ff ff    	jne    6425 <fwp_hof0.constprop.0+0x175>
    6eab:	4c 89 f7             	mov    %r14,%rdi
    6eae:	e8 1d d0 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6eb3:	e9 6d f5 ff ff       	jmp    6425 <fwp_hof0.constprop.0+0x175>
    6eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ebf:	00 
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	0f 84 8d f4 ff ff    	je     6356 <fwp_hof0.constprop.0+0xa6>
    6ec9:	48 85 db             	test   %rbx,%rbx
    6ecc:	0f 85 b7 f4 ff ff    	jne    6389 <fwp_hof0.constprop.0+0xd9>
    6ed2:	31 ff                	xor    %edi,%edi
    6ed4:	e8 37 dc ff ff       	call   4b10 <fwp_array_new_packed.constprop.0>
    6ed9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6ee0:	00 
    6ee1:	49 89 c5             	mov    %rax,%r13
    6ee4:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6eeb:	00 
    6eec:	48 c1 e2 10          	shl    $0x10,%rdx
    6ef0:	48 39 d0             	cmp    %rdx,%rax
    6ef3:	0f 83 47 ff ff ff    	jae    6e40 <fwp_hof0.constprop.0+0xb90>
    6ef9:	48 89 c2             	mov    %rax,%rdx
    6efc:	48 c1 ea 10          	shr    $0x10,%rdx
    6f00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f04:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6f0b:	00 
    6f0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f10:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6f14:	4d 85 f6             	test   %r14,%r14
    6f17:	0f 85 d4 f4 ff ff    	jne    63f1 <fwp_hof0.constprop.0+0x141>
    6f1d:	e9 1e ff ff ff       	jmp    6e40 <fwp_hof0.constprop.0+0xb90>
    6f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f28:	66 85 c0             	test   %ax,%ax
    6f2b:	0f 85 2f fd ff ff    	jne    6c60 <fwp_hof0.constprop.0+0x9b0>
    6f31:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    6f36:	84 c0                	test   %al,%al
    6f38:	0f 84 22 fd ff ff    	je     6c60 <fwp_hof0.constprop.0+0x9b0>
    6f3e:	3c 01                	cmp    $0x1,%al
    6f40:	0f 85 09 fd ff ff    	jne    6c4f <fwp_hof0.constprop.0+0x99f>
    6f46:	4c 89 f7             	mov    %r14,%rdi
    6f49:	e8 c2 d1 ff ff       	call   4110 <fwp_mem_free>
    6f4e:	e9 0d fd ff ff       	jmp    6c60 <fwp_hof0.constprop.0+0x9b0>
    6f53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f58:	66 85 c0             	test   %ax,%ax
    6f5b:	0f 85 ce fb ff ff    	jne    6b2f <fwp_hof0.constprop.0+0x87f>
    6f61:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6f65:	0f 85 ac fb ff ff    	jne    6b17 <fwp_hof0.constprop.0+0x867>
    6f6b:	4c 89 ff             	mov    %r15,%rdi
    6f6e:	e8 5d cf ff ff       	call   3ed0 <fwp_rc_forget_slot>
    6f73:	e9 9f fb ff ff       	jmp    6b17 <fwp_hof0.constprop.0+0x867>
    6f78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f7f:	00 
    6f80:	66 85 c0             	test   %ax,%ax
    6f83:	0f 85 27 fc ff ff    	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    6f89:	e9 8d fd ff ff       	jmp    6d1b <fwp_hof0.constprop.0+0xa6b>
    6f8e:	66 85 c0             	test   %ax,%ax
    6f91:	0f 85 2a fe ff ff    	jne    6dc1 <fwp_hof0.constprop.0+0xb11>
    6f97:	e9 03 fe ff ff       	jmp    6d9f <fwp_hof0.constprop.0+0xaef>
    6f9c:	4c 89 f0             	mov    %r14,%rax
    6f9f:	48 c1 e8 11          	shr    $0x11,%rax
    6fa3:	4c 31 f0             	xor    %r14,%rax
    6fa6:	48 89 c2             	mov    %rax,%rdx
    6fa9:	48 c1 ea 09          	shr    $0x9,%rdx
    6fad:	48 31 d0             	xor    %rdx,%rax
    6fb0:	0f b6 d0             	movzbl %al,%edx
    6fb3:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    6fba:	00 
    6fbb:	48 85 c0             	test   %rax,%rax
    6fbe:	75 2d                	jne    6fed <fwp_hof0.constprop.0+0xd3d>
    6fc0:	e9 44 02 00 00       	jmp    7209 <fwp_hof0.constprop.0+0xf59>
    6fc5:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6fca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fd1:	00 00 00 00 
    6fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fdc:	00 00 00 00 
    6fe0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6fe4:	48 85 c0             	test   %rax,%rax
    6fe7:	0f 84 1c 02 00 00    	je     7209 <fwp_hof0.constprop.0+0xf59>
    6fed:	48 89 c2             	mov    %rax,%rdx
    6ff0:	4c 3b 30             	cmp    (%rax),%r14
    6ff3:	75 eb                	jne    6fe0 <fwp_hof0.constprop.0+0xd30>
    6ff5:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6ff9:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6ffd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7001:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7008:	0f 85 92 f7 ff ff    	jne    67a0 <fwp_hof0.constprop.0+0x4f0>
    700e:	4c 89 f7             	mov    %r14,%rdi
    7011:	e8 ba ce ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7016:	41 c6 06 fe          	movb   $0xfe,(%r14)
    701a:	e9 81 f7 ff ff       	jmp    67a0 <fwp_hof0.constprop.0+0x4f0>
    701f:	4c 89 fa             	mov    %r15,%rdx
    7022:	48 c1 ea 11          	shr    $0x11,%rdx
    7026:	4c 31 fa             	xor    %r15,%rdx
    7029:	48 89 d0             	mov    %rdx,%rax
    702c:	48 c1 e8 09          	shr    $0x9,%rax
    7030:	48 31 c2             	xor    %rax,%rdx
    7033:	0f b6 d2             	movzbl %dl,%edx
    7036:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    703d:	00 
    703e:	48 85 c0             	test   %rax,%rax
    7041:	75 2a                	jne    706d <fwp_hof0.constprop.0+0xdbd>
    7043:	e9 c1 01 00 00       	jmp    7209 <fwp_hof0.constprop.0+0xf59>
    7048:	66 90                	xchg   %ax,%ax
    704a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7051:	00 00 00 00 
    7055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    705c:	00 00 00 00 
    7060:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7064:	48 85 c0             	test   %rax,%rax
    7067:	0f 84 9c 01 00 00    	je     7209 <fwp_hof0.constprop.0+0xf59>
    706d:	48 89 c2             	mov    %rax,%rdx
    7070:	4c 3b 38             	cmp    (%rax),%r15
    7073:	75 eb                	jne    7060 <fwp_hof0.constprop.0+0xdb0>
    7075:	48 8b 48 08          	mov    0x8(%rax),%rcx
    7079:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    707d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7081:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7088:	0f 85 22 fb ff ff    	jne    6bb0 <fwp_hof0.constprop.0+0x900>
    708e:	4c 89 ff             	mov    %r15,%rdi
    7091:	e8 3a ce ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7096:	41 c6 07 fe          	movb   $0xfe,(%r15)
    709a:	e9 11 fb ff ff       	jmp    6bb0 <fwp_hof0.constprop.0+0x900>
    709f:	4c 89 e8             	mov    %r13,%rax
    70a2:	48 c1 e8 11          	shr    $0x11,%rax
    70a6:	4c 31 e8             	xor    %r13,%rax
    70a9:	48 89 c2             	mov    %rax,%rdx
    70ac:	48 c1 ea 09          	shr    $0x9,%rdx
    70b0:	48 31 d0             	xor    %rdx,%rax
    70b3:	0f b6 d0             	movzbl %al,%edx
    70b6:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    70bd:	00 
    70be:	48 85 c0             	test   %rax,%rax
    70c1:	75 2a                	jne    70ed <fwp_hof0.constprop.0+0xe3d>
    70c3:	e9 41 01 00 00       	jmp    7209 <fwp_hof0.constprop.0+0xf59>
    70c8:	66 90                	xchg   %ax,%ax
    70ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70d1:	00 00 00 00 
    70d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70dc:	00 00 00 00 
    70e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    70e4:	48 85 c0             	test   %rax,%rax
    70e7:	0f 84 1c 01 00 00    	je     7209 <fwp_hof0.constprop.0+0xf59>
    70ed:	48 89 c2             	mov    %rax,%rdx
    70f0:	4c 39 28             	cmp    %r13,(%rax)
    70f3:	75 eb                	jne    70e0 <fwp_hof0.constprop.0+0xe30>
    70f5:	48 8b 48 08          	mov    0x8(%rax),%rcx
    70f9:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    70fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7101:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7108:	0f 85 52 fb ff ff    	jne    6c60 <fwp_hof0.constprop.0+0x9b0>
    710e:	4c 89 ef             	mov    %r13,%rdi
    7111:	e8 ba cd ff ff       	call   3ed0 <fwp_rc_forget_slot>
    7116:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    711b:	e9 40 fb ff ff       	jmp    6c60 <fwp_hof0.constprop.0+0x9b0>
    7120:	4c 89 e9             	mov    %r13,%rcx
    7123:	48 c1 e9 11          	shr    $0x11,%rcx
    7127:	4c 31 e9             	xor    %r13,%rcx
    712a:	48 89 ca             	mov    %rcx,%rdx
    712d:	48 c1 ea 09          	shr    $0x9,%rdx
    7131:	48 31 d1             	xor    %rdx,%rcx
    7134:	0f b6 c9             	movzbl %cl,%ecx
    7137:	4d 8d b4 cc 48 14 00 	lea    0x1448(%r12,%rcx,8),%r14
    713e:	00 
    713f:	49 8b 16             	mov    (%r14),%rdx
    7142:	49 83 bc cc 48 14 00 	cmpq   $0x0,0x1448(%r12,%rcx,8)
    7149:	00 00 
    714b:	75 1f                	jne    716c <fwp_hof0.constprop.0+0xebc>
    714d:	e9 96 00 00 00       	jmp    71e8 <fwp_hof0.constprop.0+0xf38>
    7152:	0f 1f 00             	nopl   (%rax)
    7155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    715c:	00 00 00 00 
    7160:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7164:	48 85 c9             	test   %rcx,%rcx
    7167:	74 27                	je     7190 <fwp_hof0.constprop.0+0xee0>
    7169:	48 89 ca             	mov    %rcx,%rdx
    716c:	4c 39 2a             	cmp    %r13,(%rdx)
    716f:	75 ef                	jne    7160 <fwp_hof0.constprop.0+0xeb0>
    7171:	3c fe                	cmp    $0xfe,%al
    7173:	74 7c                	je     71f1 <fwp_hof0.constprop.0+0xf41>
    7175:	48 8b 42 08          	mov    0x8(%rdx),%rax
    7179:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    717d:	0f 84 a3 00 00 00    	je     7226 <fwp_hof0.constprop.0+0xf76>
    7183:	48 83 c0 01          	add    $0x1,%rax
    7187:	48 89 42 08          	mov    %rax,0x8(%rdx)
    718b:	e9 f0 f1 ff ff       	jmp    6380 <fwp_hof0.constprop.0+0xd0>
    7190:	3c fe                	cmp    $0xfe,%al
    7192:	75 75                	jne    7209 <fwp_hof0.constprop.0+0xf59>
    7194:	4c 8d 72 10          	lea    0x10(%rdx),%r14
    7198:	bf 18 00 00 00       	mov    $0x18,%edi
    719d:	e8 de b3 ff ff       	call   2580 <malloc@plt>
    71a2:	48 85 c0             	test   %rax,%rax
    71a5:	74 7a                	je     7221 <fwp_hof0.constprop.0+0xf71>
    71a7:	4c 89 28             	mov    %r13,(%rax)
    71aa:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    71b1:	00 
    71b2:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    71b9:	00 
    71ba:	49 89 06             	mov    %rax,(%r14)
    71bd:	41 c6 45 00 ff       	movb   $0xff,0x0(%r13)
    71c2:	49 83 84 24 48 1c 00 	addq   $0x1,0x1c48(%r12)
    71c9:	00 01 
    71cb:	e9 b0 f1 ff ff       	jmp    6380 <fwp_hof0.constprop.0+0xd0>
    71d0:	48 8d 3d 19 42 00 00 	lea    0x4219(%rip),%rdi        # b3f0 <_IO_stdin_used+0x3f0>
    71d7:	e8 24 c0 ff ff       	call   3200 <fwp_trap>
    71dc:	48 8d 3d 02 3f 00 00 	lea    0x3f02(%rip),%rdi        # b0e5 <_IO_stdin_used+0xe5>
    71e3:	e8 18 c0 ff ff       	call   3200 <fwp_trap>
    71e8:	3c fe                	cmp    $0xfe,%al
    71ea:	75 14                	jne    7200 <fwp_hof0.constprop.0+0xf50>
    71ec:	48 85 d2             	test   %rdx,%rdx
    71ef:	74 a7                	je     7198 <fwp_hof0.constprop.0+0xee8>
    71f1:	48 8d 3d d0 41 00 00 	lea    0x41d0(%rip),%rdi        # b3c8 <_IO_stdin_used+0x3c8>
    71f8:	e8 03 c0 ff ff       	call   3200 <fwp_trap>
    71fd:	0f 1f 00             	nopl   (%rax)
    7200:	48 85 d2             	test   %rdx,%rdx
    7203:	0f 85 6c ff ff ff    	jne    7175 <fwp_hof0.constprop.0+0xec5>
    7209:	48 8d 3d 90 41 00 00 	lea    0x4190(%rip),%rdi        # b3a0 <_IO_stdin_used+0x3a0>
    7210:	e8 eb bf ff ff       	call   3200 <fwp_trap>
    7215:	48 8d 3d 81 3f 00 00 	lea    0x3f81(%rip),%rdi        # b19d <_IO_stdin_used+0x19d>
    721c:	e8 df bf ff ff       	call   3200 <fwp_trap>
    7221:	e8 ca ba ff ff       	call   2cf0 <fwp_heap_oom>
    7226:	48 8d 3d 57 3f 00 00 	lea    0x3f57(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    722d:	e8 ce bf ff ff       	call   3200 <fwp_trap>
    7232:	e8 09 b2 ff ff       	call   2440 <__stack_chk_fail@plt>
    7237:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    723e:	00 00 

0000000000007240 <f0>:
    7240:	41 56                	push   %r14
    7242:	4c 8d 35 17 75 01 00 	lea    0x17517(%rip),%r14        # 1e760 <fwp_heap>
    7249:	41 55                	push   %r13
    724b:	41 54                	push   %r12
    724d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    7253:	55                   	push   %rbp
    7254:	53                   	push   %rbx
    7255:	31 db                	xor    %ebx,%ebx
    7257:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    725e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7265:	00 00 
    7267:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    726e:	00 
    726f:	31 c0                	xor    %eax,%eax
    7271:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    7278:	00 
    7279:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    7280:	00 00 
    7282:	66 48 0f 6e c0       	movq   %rax,%xmm0
    7287:	48 8d 05 c2 de ff ff 	lea    -0x213e(%rip),%rax        # 5150 <fwp_drop1>
    728e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7293:	48 8b 05 56 91 01 00 	mov    0x19156(%rip),%rax        # 203f0 <fwp_cleanups>
    729a:	48 89 25 4f 91 01 00 	mov    %rsp,0x1914f(%rip)        # 203f0 <fwp_cleanups>
    72a1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    72a5:	48 89 04 24          	mov    %rax,(%rsp)
    72a9:	48 8d 05 e0 b8 ff ff 	lea    -0x4720(%rip),%rax        # 2b90 <fwp_range_release>
    72b0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    72b5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    72ba:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    72bf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    72c4:	eb 43                	jmp    7309 <f0+0xc9>
    72c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72cd:	00 00 00 
    72d0:	80 f9 01             	cmp    $0x1,%cl
    72d3:	75 29                	jne    72fe <f0+0xbe>
    72d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    72d8:	0f b7 c0             	movzwl %ax,%eax
    72db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72de:	48 0f af c1          	imul   %rcx,%rax
    72e2:	48 c1 e8 20          	shr    $0x20,%rax
    72e6:	48 39 d0             	cmp    %rdx,%rax
    72e9:	73 13                	jae    72fe <f0+0xbe>
    72eb:	49 01 c5             	add    %rax,%r13
    72ee:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    72f3:	0f 84 2f 25 00 00    	je     9828 <f0+0x25e8>
    72f9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    72fe:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7303:	49 83 ec 01          	sub    $0x1,%r12
    7307:	72 77                	jb     7380 <f0+0x140>
    7309:	48 89 ef             	mov    %rbp,%rdi
    730c:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    7313:	00 
    7314:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7319:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    7320:	00 
    7321:	e8 0a d6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7326:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    732d:	48 89 c3             	mov    %rax,%rbx
    7330:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    7337:	48 c1 e2 10          	shl    $0x10,%rdx
    733b:	48 39 d0             	cmp    %rdx,%rax
    733e:	73 be                	jae    72fe <f0+0xbe>
    7340:	48 89 c2             	mov    %rax,%rdx
    7343:	48 c1 ea 10          	shr    $0x10,%rdx
    7347:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    734b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    7352:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7356:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    735a:	4d 85 ed             	test   %r13,%r13
    735d:	74 9f                	je     72fe <f0+0xbe>
    735f:	0f b6 0a             	movzbl (%rdx),%ecx
    7362:	80 f9 02             	cmp    $0x2,%cl
    7365:	0f 85 65 ff ff ff    	jne    72d0 <f0+0x90>
    736b:	66 85 c0             	test   %ax,%ax
    736e:	0f 84 7a ff ff ff    	je     72ee <f0+0xae>
    7374:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7379:	49 83 ec 01          	sub    $0x1,%r12
    737d:	73 8a                	jae    7309 <f0+0xc9>
    737f:	90                   	nop
    7380:	48 8b 04 24          	mov    (%rsp),%rax
    7384:	66 0f 6f 05 e4 42 00 	movdqa 0x42e4(%rip),%xmm0        # b670 <msg.3+0xa0>
    738b:	00 
    738c:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
    7391:	48 89 05 58 90 01 00 	mov    %rax,0x19058(%rip)        # 203f0 <fwp_cleanups>
    7398:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    739d:	e8 8e d5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    73a2:	48 8b 15 8f 87 01 00 	mov    0x1878f(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    73a9:	49 89 c5             	mov    %rax,%r13
    73ac:	48 2b 05 5d 87 01 00 	sub    0x1875d(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    73b3:	48 c1 e2 10          	shl    $0x10,%rdx
    73b7:	48 39 d0             	cmp    %rdx,%rax
    73ba:	73 59                	jae    7415 <f0+0x1d5>
    73bc:	48 89 c2             	mov    %rax,%rdx
    73bf:	48 c1 ea 10          	shr    $0x10,%rdx
    73c3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73c7:	48 8b 15 8a 87 01 00 	mov    0x1878a(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    73ce:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73d2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    73d6:	4d 85 e4             	test   %r12,%r12
    73d9:	74 3a                	je     7415 <f0+0x1d5>
    73db:	0f b6 0a             	movzbl (%rdx),%ecx
    73de:	80 f9 02             	cmp    $0x2,%cl
    73e1:	0f 84 f9 24 00 00    	je     98e0 <f0+0x26a0>
    73e7:	80 f9 01             	cmp    $0x1,%cl
    73ea:	75 29                	jne    7415 <f0+0x1d5>
    73ec:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73ef:	0f b7 c0             	movzwl %ax,%eax
    73f2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73f5:	48 0f af c1          	imul   %rcx,%rax
    73f9:	48 c1 e8 20          	shr    $0x20,%rax
    73fd:	48 39 d0             	cmp    %rdx,%rax
    7400:	73 13                	jae    7415 <f0+0x1d5>
    7402:	49 01 c4             	add    %rax,%r12
    7405:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    740a:	0f 84 ab 26 00 00    	je     9abb <f0+0x287b>
    7410:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7415:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    741c:	00 f0 3f 
    741f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
    7424:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    7429:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    742e:	e8 fd d4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7433:	48 8b 15 fe 86 01 00 	mov    0x186fe(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    743a:	49 89 c5             	mov    %rax,%r13
    743d:	48 2b 05 cc 86 01 00 	sub    0x186cc(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7444:	48 c1 e2 10          	shl    $0x10,%rdx
    7448:	48 39 d0             	cmp    %rdx,%rax
    744b:	73 59                	jae    74a6 <f0+0x266>
    744d:	48 89 c2             	mov    %rax,%rdx
    7450:	48 c1 ea 10          	shr    $0x10,%rdx
    7454:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7458:	48 8b 15 f9 86 01 00 	mov    0x186f9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    745f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7463:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7467:	4d 85 e4             	test   %r12,%r12
    746a:	74 3a                	je     74a6 <f0+0x266>
    746c:	0f b6 0a             	movzbl (%rdx),%ecx
    746f:	80 f9 02             	cmp    $0x2,%cl
    7472:	0f 84 58 24 00 00    	je     98d0 <f0+0x2690>
    7478:	80 f9 01             	cmp    $0x1,%cl
    747b:	75 29                	jne    74a6 <f0+0x266>
    747d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7480:	0f b7 c0             	movzwl %ax,%eax
    7483:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7486:	48 0f af c1          	imul   %rcx,%rax
    748a:	48 c1 e8 20          	shr    $0x20,%rax
    748e:	48 39 d0             	cmp    %rdx,%rax
    7491:	73 13                	jae    74a6 <f0+0x266>
    7493:	49 01 c4             	add    %rax,%r12
    7496:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    749b:	0f 84 27 26 00 00    	je     9ac8 <f0+0x2888>
    74a1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    74a6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    74ad:	33 f3 bf 
    74b0:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
    74b5:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    74ba:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    74bf:	e8 6c d4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    74c4:	48 8b 15 6d 86 01 00 	mov    0x1866d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    74cb:	49 89 c5             	mov    %rax,%r13
    74ce:	48 2b 05 3b 86 01 00 	sub    0x1863b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    74d5:	48 c1 e2 10          	shl    $0x10,%rdx
    74d9:	48 39 d0             	cmp    %rdx,%rax
    74dc:	73 59                	jae    7537 <f0+0x2f7>
    74de:	48 89 c2             	mov    %rax,%rdx
    74e1:	48 c1 ea 10          	shr    $0x10,%rdx
    74e5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74e9:	48 8b 15 68 86 01 00 	mov    0x18668(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    74f0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74f4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    74f8:	4d 85 e4             	test   %r12,%r12
    74fb:	74 3a                	je     7537 <f0+0x2f7>
    74fd:	0f b6 0a             	movzbl (%rdx),%ecx
    7500:	80 f9 02             	cmp    $0x2,%cl
    7503:	0f 84 b7 23 00 00    	je     98c0 <f0+0x2680>
    7509:	80 f9 01             	cmp    $0x1,%cl
    750c:	75 29                	jne    7537 <f0+0x2f7>
    750e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7511:	0f b7 c0             	movzwl %ax,%eax
    7514:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7517:	48 0f af c1          	imul   %rcx,%rax
    751b:	48 c1 e8 20          	shr    $0x20,%rax
    751f:	48 39 d0             	cmp    %rdx,%rax
    7522:	73 13                	jae    7537 <f0+0x2f7>
    7524:	49 01 c4             	add    %rax,%r12
    7527:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    752c:	0f 84 a3 25 00 00    	je     9ad5 <f0+0x2895>
    7532:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7537:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    753e:	00 f0 3f 
    7541:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
    7546:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    754b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7550:	e8 db d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7555:	48 8b 15 dc 85 01 00 	mov    0x185dc(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    755c:	49 89 c5             	mov    %rax,%r13
    755f:	48 2b 05 aa 85 01 00 	sub    0x185aa(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7566:	48 c1 e2 10          	shl    $0x10,%rdx
    756a:	48 39 d0             	cmp    %rdx,%rax
    756d:	73 59                	jae    75c8 <f0+0x388>
    756f:	48 89 c2             	mov    %rax,%rdx
    7572:	48 c1 ea 10          	shr    $0x10,%rdx
    7576:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    757a:	48 8b 15 d7 85 01 00 	mov    0x185d7(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7581:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7585:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7589:	4d 85 e4             	test   %r12,%r12
    758c:	74 3a                	je     75c8 <f0+0x388>
    758e:	0f b6 0a             	movzbl (%rdx),%ecx
    7591:	80 f9 02             	cmp    $0x2,%cl
    7594:	0f 84 86 23 00 00    	je     9920 <f0+0x26e0>
    759a:	80 f9 01             	cmp    $0x1,%cl
    759d:	75 29                	jne    75c8 <f0+0x388>
    759f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    75a2:	0f b7 c0             	movzwl %ax,%eax
    75a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    75a8:	48 0f af c1          	imul   %rcx,%rax
    75ac:	48 c1 e8 20          	shr    $0x20,%rax
    75b0:	48 39 d0             	cmp    %rdx,%rax
    75b3:	73 13                	jae    75c8 <f0+0x388>
    75b5:	49 01 c4             	add    %rax,%r12
    75b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    75bd:	0f 84 1f 25 00 00    	je     9ae2 <f0+0x28a2>
    75c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    75c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    75cf:	00 
    75d0:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    75d7:	00 
    75d8:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    75df:	33 f3 bf 
    75e2:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    75e9:	00 f0 3f 
    75ec:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    75f3:	00 
    75f4:	e8 37 d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    75f9:	48 89 c7             	mov    %rax,%rdi
    75fc:	e8 0f d0 ff ff       	call   4610 <fwp_rc_fresh>
    7601:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
    7608:	00 
    7609:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    7610:	00 
    7611:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    7618:	00 
    7619:	e8 12 d3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    761e:	48 89 c7             	mov    %rax,%rdi
    7621:	e8 ea cf ff ff       	call   4610 <fwp_rc_fresh>
    7626:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
    762d:	00 
    762e:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    7635:	00 
    7636:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    763d:	00 
    763e:	e8 ed d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7643:	48 89 c7             	mov    %rax,%rdi
    7646:	e8 c5 cf ff ff       	call   4610 <fwp_rc_fresh>
    764b:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
    7652:	00 
    7653:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    765a:	00 
    765b:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7662:	00 
    7663:	e8 c8 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7668:	48 89 c7             	mov    %rax,%rdi
    766b:	e8 a0 cf ff ff       	call   4610 <fwp_rc_fresh>
    7670:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
    7677:	00 
    7678:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    767f:	00 
    7680:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7687:	00 
    7688:	e8 a3 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    768d:	48 89 c7             	mov    %rax,%rdi
    7690:	e8 7b cf ff ff       	call   4610 <fwp_rc_fresh>
    7695:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
    769c:	00 
    769d:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    76a4:	00 
    76a5:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    76ac:	00 
    76ad:	e8 7e d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76b2:	48 89 c7             	mov    %rax,%rdi
    76b5:	e8 56 cf ff ff       	call   4610 <fwp_rc_fresh>
    76ba:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
    76c1:	00 
    76c2:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    76c9:	00 
    76ca:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    76d1:	00 
    76d2:	e8 59 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76d7:	48 89 c7             	mov    %rax,%rdi
    76da:	e8 31 cf ff ff       	call   4610 <fwp_rc_fresh>
    76df:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
    76e6:	00 
    76e7:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    76ee:	00 
    76ef:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    76f6:	00 
    76f7:	e8 34 d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    76fc:	48 89 c7             	mov    %rax,%rdi
    76ff:	e8 0c cf ff ff       	call   4610 <fwp_rc_fresh>
    7704:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
    770b:	00 
    770c:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    7713:	00 
    7714:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    771b:	00 
    771c:	e8 0f d2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7721:	48 89 c7             	mov    %rax,%rdi
    7724:	e8 e7 ce ff ff       	call   4610 <fwp_rc_fresh>
    7729:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
    7730:	00 
    7731:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7738:	00 
    7739:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7740:	00 
    7741:	e8 ea d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7746:	48 89 c7             	mov    %rax,%rdi
    7749:	e8 c2 ce ff ff       	call   4610 <fwp_rc_fresh>
    774e:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
    7755:	00 
    7756:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    775d:	00 
    775e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7765:	00 
    7766:	e8 c5 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    776b:	48 89 c7             	mov    %rax,%rdi
    776e:	e8 9d ce ff ff       	call   4610 <fwp_rc_fresh>
    7773:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
    777a:	00 
    777b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    7782:	00 
    7783:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    778a:	00 
    778b:	e8 a0 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7790:	48 89 c7             	mov    %rax,%rdi
    7793:	e8 78 ce ff ff       	call   4610 <fwp_rc_fresh>
    7798:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
    779f:	00 
    77a0:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    77a7:	00 
    77a8:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    77af:	00 
    77b0:	e8 7b d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77b5:	48 89 c7             	mov    %rax,%rdi
    77b8:	e8 53 ce ff ff       	call   4610 <fwp_rc_fresh>
    77bd:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
    77c4:	00 
    77c5:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    77cc:	00 
    77cd:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    77d4:	00 
    77d5:	e8 56 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77da:	48 89 c7             	mov    %rax,%rdi
    77dd:	e8 2e ce ff ff       	call   4610 <fwp_rc_fresh>
    77e2:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
    77e9:	00 
    77ea:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    77f1:	00 
    77f2:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    77f9:	00 
    77fa:	e8 31 d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    77ff:	48 89 c7             	mov    %rax,%rdi
    7802:	e8 09 ce ff ff       	call   4610 <fwp_rc_fresh>
    7807:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
    780e:	00 
    780f:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    7816:	00 
    7817:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    781e:	00 
    781f:	e8 0c d1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7824:	48 89 c7             	mov    %rax,%rdi
    7827:	e8 e4 cd ff ff       	call   4610 <fwp_rc_fresh>
    782c:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
    7833:	00 
    7834:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    783b:	00 
    783c:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7843:	00 
    7844:	e8 e7 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7849:	48 89 c7             	mov    %rax,%rdi
    784c:	e8 bf cd ff ff       	call   4610 <fwp_rc_fresh>
    7851:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
    7858:	00 
    7859:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7860:	00 
    7861:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7868:	00 
    7869:	e8 c2 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    786e:	48 89 c7             	mov    %rax,%rdi
    7871:	e8 9a cd ff ff       	call   4610 <fwp_rc_fresh>
    7876:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
    787d:	00 
    787e:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    7885:	00 
    7886:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    788d:	00 
    788e:	e8 9d d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7893:	48 89 c7             	mov    %rax,%rdi
    7896:	e8 75 cd ff ff       	call   4610 <fwp_rc_fresh>
    789b:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
    78a2:	00 
    78a3:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    78aa:	00 
    78ab:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    78b2:	00 
    78b3:	e8 78 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    78b8:	48 89 c7             	mov    %rax,%rdi
    78bb:	e8 50 cd ff ff       	call   4610 <fwp_rc_fresh>
    78c0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
    78c7:	00 
    78c8:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    78cf:	00 
    78d0:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    78d7:	00 
    78d8:	e8 53 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    78dd:	48 89 c7             	mov    %rax,%rdi
    78e0:	e8 2b cd ff ff       	call   4610 <fwp_rc_fresh>
    78e5:	48 8d bc 24 d0 01 00 	lea    0x1d0(%rsp),%rdi
    78ec:	00 
    78ed:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    78f4:	00 
    78f5:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    78fc:	00 
    78fd:	e8 2e d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7902:	48 89 c7             	mov    %rax,%rdi
    7905:	e8 06 cd ff ff       	call   4610 <fwp_rc_fresh>
    790a:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
    7911:	00 
    7912:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    7919:	00 
    791a:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    7921:	00 
    7922:	e8 09 d0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7927:	48 89 c7             	mov    %rax,%rdi
    792a:	e8 e1 cc ff ff       	call   4610 <fwp_rc_fresh>
    792f:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
    7936:	00 
    7937:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    793e:	00 
    793f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    7946:	00 
    7947:	e8 e4 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    794c:	48 89 c7             	mov    %rax,%rdi
    794f:	e8 bc cc ff ff       	call   4610 <fwp_rc_fresh>
    7954:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
    795b:	00 
    795c:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    7963:	00 
    7964:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    796b:	00 
    796c:	e8 bf cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7971:	48 89 c7             	mov    %rax,%rdi
    7974:	e8 97 cc ff ff       	call   4610 <fwp_rc_fresh>
    7979:	48 8d bc 24 10 02 00 	lea    0x210(%rsp),%rdi
    7980:	00 
    7981:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    7988:	00 
    7989:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    7990:	00 
    7991:	e8 9a cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7996:	48 89 c7             	mov    %rax,%rdi
    7999:	e8 72 cc ff ff       	call   4610 <fwp_rc_fresh>
    799e:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
    79a5:	00 
    79a6:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    79ad:	00 
    79ae:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    79b5:	00 
    79b6:	e8 75 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    79bb:	48 89 c7             	mov    %rax,%rdi
    79be:	e8 4d cc ff ff       	call   4610 <fwp_rc_fresh>
    79c3:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
    79ca:	00 
    79cb:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    79d2:	00 
    79d3:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    79da:	00 
    79db:	e8 50 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    79e0:	48 89 c7             	mov    %rax,%rdi
    79e3:	e8 28 cc ff ff       	call   4610 <fwp_rc_fresh>
    79e8:	48 8d bc 24 40 02 00 	lea    0x240(%rsp),%rdi
    79ef:	00 
    79f0:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    79f7:	00 
    79f8:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    79ff:	00 
    7a00:	e8 2b cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a05:	48 89 c7             	mov    %rax,%rdi
    7a08:	e8 03 cc ff ff       	call   4610 <fwp_rc_fresh>
    7a0d:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
    7a14:	00 
    7a15:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    7a1c:	00 
    7a1d:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    7a24:	00 
    7a25:	e8 06 cf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a2a:	48 89 c7             	mov    %rax,%rdi
    7a2d:	e8 de cb ff ff       	call   4610 <fwp_rc_fresh>
    7a32:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
    7a39:	00 
    7a3a:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    7a41:	00 
    7a42:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    7a49:	00 
    7a4a:	e8 e1 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a4f:	48 89 c7             	mov    %rax,%rdi
    7a52:	e8 b9 cb ff ff       	call   4610 <fwp_rc_fresh>
    7a57:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
    7a5e:	00 
    7a5f:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    7a66:	00 
    7a67:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    7a6e:	00 
    7a6f:	e8 bc ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a74:	48 89 c7             	mov    %rax,%rdi
    7a77:	e8 94 cb ff ff       	call   4610 <fwp_rc_fresh>
    7a7c:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
    7a83:	00 
    7a84:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    7a8b:	00 
    7a8c:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    7a93:	00 
    7a94:	e8 97 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7a99:	48 89 c7             	mov    %rax,%rdi
    7a9c:	e8 6f cb ff ff       	call   4610 <fwp_rc_fresh>
    7aa1:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
    7aa8:	00 
    7aa9:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    7ab0:	00 
    7ab1:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    7ab8:	00 
    7ab9:	e8 72 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7abe:	48 89 c7             	mov    %rax,%rdi
    7ac1:	e8 4a cb ff ff       	call   4610 <fwp_rc_fresh>
    7ac6:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
    7acd:	00 
    7ace:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    7ad5:	00 
    7ad6:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    7add:	00 
    7ade:	e8 4d ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ae3:	48 89 c7             	mov    %rax,%rdi
    7ae6:	e8 25 cb ff ff       	call   4610 <fwp_rc_fresh>
    7aeb:	48 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%rdi
    7af2:	00 
    7af3:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    7afa:	00 
    7afb:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    7b02:	00 
    7b03:	e8 28 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b08:	48 89 c7             	mov    %rax,%rdi
    7b0b:	e8 00 cb ff ff       	call   4610 <fwp_rc_fresh>
    7b10:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
    7b17:	00 
    7b18:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    7b1f:	00 
    7b20:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    7b27:	00 
    7b28:	e8 03 ce ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b2d:	48 89 c7             	mov    %rax,%rdi
    7b30:	e8 db ca ff ff       	call   4610 <fwp_rc_fresh>
    7b35:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
    7b3c:	00 
    7b3d:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    7b44:	00 
    7b45:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    7b4c:	00 
    7b4d:	e8 de cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b52:	48 89 c7             	mov    %rax,%rdi
    7b55:	e8 b6 ca ff ff       	call   4610 <fwp_rc_fresh>
    7b5a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
    7b61:	00 
    7b62:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    7b69:	00 
    7b6a:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    7b71:	00 
    7b72:	e8 b9 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b77:	48 89 c7             	mov    %rax,%rdi
    7b7a:	e8 91 ca ff ff       	call   4610 <fwp_rc_fresh>
    7b7f:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
    7b86:	00 
    7b87:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    7b8e:	00 
    7b8f:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    7b96:	00 
    7b97:	e8 94 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7b9c:	48 89 c7             	mov    %rax,%rdi
    7b9f:	e8 6c ca ff ff       	call   4610 <fwp_rc_fresh>
    7ba4:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
    7bab:	00 
    7bac:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    7bb3:	00 
    7bb4:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    7bbb:	00 
    7bbc:	e8 6f cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7bc1:	48 89 c7             	mov    %rax,%rdi
    7bc4:	e8 47 ca ff ff       	call   4610 <fwp_rc_fresh>
    7bc9:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
    7bd0:	00 
    7bd1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    7bd8:	00 
    7bd9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    7be0:	00 
    7be1:	e8 4a cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7be6:	48 89 c7             	mov    %rax,%rdi
    7be9:	e8 22 ca ff ff       	call   4610 <fwp_rc_fresh>
    7bee:	48 8d bc 24 20 03 00 	lea    0x320(%rsp),%rdi
    7bf5:	00 
    7bf6:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    7bfd:	00 
    7bfe:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    7c05:	00 
    7c06:	e8 25 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c0b:	48 89 c7             	mov    %rax,%rdi
    7c0e:	e8 fd c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c13:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
    7c1a:	00 
    7c1b:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    7c22:	00 
    7c23:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    7c2a:	00 
    7c2b:	e8 00 cd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c30:	48 89 c7             	mov    %rax,%rdi
    7c33:	e8 d8 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c38:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
    7c3f:	00 
    7c40:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    7c47:	00 
    7c48:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    7c4f:	00 
    7c50:	e8 db cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c55:	48 89 c7             	mov    %rax,%rdi
    7c58:	e8 b3 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c5d:	48 8d bc 24 50 03 00 	lea    0x350(%rsp),%rdi
    7c64:	00 
    7c65:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    7c6c:	00 
    7c6d:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    7c74:	00 
    7c75:	e8 b6 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c7a:	48 89 c7             	mov    %rax,%rdi
    7c7d:	e8 8e c9 ff ff       	call   4610 <fwp_rc_fresh>
    7c82:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
    7c89:	00 
    7c8a:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    7c91:	00 
    7c92:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    7c99:	00 
    7c9a:	e8 91 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7c9f:	48 89 c7             	mov    %rax,%rdi
    7ca2:	e8 69 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7ca7:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
    7cae:	00 
    7caf:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    7cb6:	00 
    7cb7:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    7cbe:	00 
    7cbf:	e8 6c cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7cc4:	48 89 c7             	mov    %rax,%rdi
    7cc7:	e8 44 c9 ff ff       	call   4610 <fwp_rc_fresh>
    7ccc:	48 8d bc 24 80 03 00 	lea    0x380(%rsp),%rdi
    7cd3:	00 
    7cd4:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    7cdb:	00 
    7cdc:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    7ce3:	00 
    7ce4:	e8 47 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ce9:	48 89 c7             	mov    %rax,%rdi
    7cec:	e8 1f c9 ff ff       	call   4610 <fwp_rc_fresh>
    7cf1:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
    7cf8:	00 
    7cf9:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    7d00:	00 
    7d01:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    7d08:	00 
    7d09:	e8 22 cc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d0e:	48 89 c7             	mov    %rax,%rdi
    7d11:	e8 fa c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d16:	48 8d bc 24 a0 03 00 	lea    0x3a0(%rsp),%rdi
    7d1d:	00 
    7d1e:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    7d25:	00 
    7d26:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    7d2d:	00 
    7d2e:	e8 fd cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d33:	48 89 c7             	mov    %rax,%rdi
    7d36:	e8 d5 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d3b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
    7d42:	00 
    7d43:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    7d4a:	00 
    7d4b:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    7d52:	00 
    7d53:	e8 d8 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d58:	48 89 c7             	mov    %rax,%rdi
    7d5b:	e8 b0 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d60:	48 8d bc 24 c0 03 00 	lea    0x3c0(%rsp),%rdi
    7d67:	00 
    7d68:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    7d6f:	00 
    7d70:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    7d77:	00 
    7d78:	e8 b3 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7d7d:	48 89 c7             	mov    %rax,%rdi
    7d80:	e8 8b c8 ff ff       	call   4610 <fwp_rc_fresh>
    7d85:	48 8d bc 24 d0 03 00 	lea    0x3d0(%rsp),%rdi
    7d8c:	00 
    7d8d:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    7d94:	00 
    7d95:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    7d9c:	00 
    7d9d:	e8 8e cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7da2:	48 89 c7             	mov    %rax,%rdi
    7da5:	e8 66 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7daa:	48 8d bc 24 e0 03 00 	lea    0x3e0(%rsp),%rdi
    7db1:	00 
    7db2:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    7db9:	00 
    7dba:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    7dc1:	00 
    7dc2:	e8 69 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7dc7:	48 89 c7             	mov    %rax,%rdi
    7dca:	e8 41 c8 ff ff       	call   4610 <fwp_rc_fresh>
    7dcf:	48 8d bc 24 f0 03 00 	lea    0x3f0(%rsp),%rdi
    7dd6:	00 
    7dd7:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    7dde:	00 
    7ddf:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    7de6:	00 
    7de7:	e8 44 cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7dec:	48 89 c7             	mov    %rax,%rdi
    7def:	e8 1c c8 ff ff       	call   4610 <fwp_rc_fresh>
    7df4:	48 8d bc 24 00 04 00 	lea    0x400(%rsp),%rdi
    7dfb:	00 
    7dfc:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    7e03:	00 
    7e04:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    7e0b:	00 
    7e0c:	e8 1f cb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e11:	48 89 c7             	mov    %rax,%rdi
    7e14:	e8 f7 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e19:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
    7e20:	00 
    7e21:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    7e28:	00 
    7e29:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    7e30:	00 
    7e31:	e8 fa ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e36:	48 89 c7             	mov    %rax,%rdi
    7e39:	e8 d2 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e3e:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
    7e45:	00 
    7e46:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    7e4d:	00 
    7e4e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    7e55:	00 
    7e56:	e8 d5 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e5b:	48 89 c7             	mov    %rax,%rdi
    7e5e:	e8 ad c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e63:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
    7e6a:	00 
    7e6b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    7e72:	00 
    7e73:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    7e7a:	00 
    7e7b:	e8 b0 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7e80:	48 89 c7             	mov    %rax,%rdi
    7e83:	e8 88 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7e88:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
    7e8f:	00 
    7e90:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    7e97:	00 
    7e98:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    7e9f:	00 
    7ea0:	e8 8b ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ea5:	48 89 c7             	mov    %rax,%rdi
    7ea8:	e8 63 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ead:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
    7eb4:	00 
    7eb5:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    7ebc:	00 
    7ebd:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    7ec4:	00 
    7ec5:	e8 66 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7eca:	48 89 c7             	mov    %rax,%rdi
    7ecd:	e8 3e c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ed2:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
    7ed9:	00 
    7eda:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    7ee1:	00 
    7ee2:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    7ee9:	00 
    7eea:	e8 41 ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7eef:	48 89 c7             	mov    %rax,%rdi
    7ef2:	e8 19 c7 ff ff       	call   4610 <fwp_rc_fresh>
    7ef7:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
    7efe:	00 
    7eff:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    7f06:	00 
    7f07:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    7f0e:	00 
    7f0f:	e8 1c ca ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f14:	48 89 c7             	mov    %rax,%rdi
    7f17:	e8 f4 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f1c:	48 8d bc 24 80 04 00 	lea    0x480(%rsp),%rdi
    7f23:	00 
    7f24:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    7f2b:	00 
    7f2c:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    7f33:	00 
    7f34:	e8 f7 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f39:	48 89 c7             	mov    %rax,%rdi
    7f3c:	e8 cf c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f41:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
    7f48:	00 
    7f49:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    7f50:	00 
    7f51:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    7f58:	00 
    7f59:	e8 d2 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f5e:	48 89 c7             	mov    %rax,%rdi
    7f61:	e8 aa c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f66:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
    7f6d:	00 
    7f6e:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    7f75:	00 
    7f76:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    7f7d:	00 
    7f7e:	e8 ad c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7f83:	48 89 c7             	mov    %rax,%rdi
    7f86:	e8 85 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7f8b:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
    7f92:	00 
    7f93:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    7f9a:	00 
    7f9b:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    7fa2:	00 
    7fa3:	e8 88 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fa8:	48 89 c7             	mov    %rax,%rdi
    7fab:	e8 60 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fb0:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
    7fb7:	00 
    7fb8:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    7fbf:	00 
    7fc0:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    7fc7:	00 
    7fc8:	e8 63 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7fcd:	48 89 c7             	mov    %rax,%rdi
    7fd0:	e8 3b c6 ff ff       	call   4610 <fwp_rc_fresh>
    7fd5:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
    7fdc:	00 
    7fdd:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    7fe4:	00 
    7fe5:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    7fec:	00 
    7fed:	e8 3e c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    7ff2:	48 89 c7             	mov    %rax,%rdi
    7ff5:	e8 16 c6 ff ff       	call   4610 <fwp_rc_fresh>
    7ffa:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
    8001:	00 
    8002:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    8009:	00 
    800a:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    8011:	00 
    8012:	e8 19 c9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8017:	48 89 c7             	mov    %rax,%rdi
    801a:	e8 f1 c5 ff ff       	call   4610 <fwp_rc_fresh>
    801f:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
    8026:	00 
    8027:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    802e:	00 
    802f:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    8036:	00 
    8037:	e8 f4 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    803c:	48 89 c7             	mov    %rax,%rdi
    803f:	e8 cc c5 ff ff       	call   4610 <fwp_rc_fresh>
    8044:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
    804b:	00 
    804c:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    8053:	00 
    8054:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    805b:	00 
    805c:	e8 cf c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8061:	48 89 c7             	mov    %rax,%rdi
    8064:	e8 a7 c5 ff ff       	call   4610 <fwp_rc_fresh>
    8069:	48 8d bc 24 10 05 00 	lea    0x510(%rsp),%rdi
    8070:	00 
    8071:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    8078:	00 
    8079:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    8080:	00 
    8081:	e8 aa c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8086:	48 89 c7             	mov    %rax,%rdi
    8089:	e8 82 c5 ff ff       	call   4610 <fwp_rc_fresh>
    808e:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
    8095:	00 
    8096:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    809d:	00 
    809e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    80a5:	00 
    80a6:	e8 85 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80ab:	48 89 c7             	mov    %rax,%rdi
    80ae:	e8 5d c5 ff ff       	call   4610 <fwp_rc_fresh>
    80b3:	48 8d bc 24 30 05 00 	lea    0x530(%rsp),%rdi
    80ba:	00 
    80bb:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    80c2:	00 
    80c3:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    80ca:	00 
    80cb:	e8 60 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80d0:	48 89 c7             	mov    %rax,%rdi
    80d3:	e8 38 c5 ff ff       	call   4610 <fwp_rc_fresh>
    80d8:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
    80df:	00 
    80e0:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    80e7:	00 
    80e8:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    80ef:	00 
    80f0:	e8 3b c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    80f5:	48 89 c7             	mov    %rax,%rdi
    80f8:	e8 13 c5 ff ff       	call   4610 <fwp_rc_fresh>
    80fd:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
    8104:	00 
    8105:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    810c:	00 
    810d:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    8114:	00 
    8115:	e8 16 c8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    811a:	48 89 c7             	mov    %rax,%rdi
    811d:	e8 ee c4 ff ff       	call   4610 <fwp_rc_fresh>
    8122:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
    8129:	00 
    812a:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    8131:	00 
    8132:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    8139:	00 
    813a:	e8 f1 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    813f:	48 89 c7             	mov    %rax,%rdi
    8142:	e8 c9 c4 ff ff       	call   4610 <fwp_rc_fresh>
    8147:	48 8d bc 24 70 05 00 	lea    0x570(%rsp),%rdi
    814e:	00 
    814f:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    8156:	00 
    8157:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    815e:	00 
    815f:	e8 cc c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8164:	48 89 c7             	mov    %rax,%rdi
    8167:	e8 a4 c4 ff ff       	call   4610 <fwp_rc_fresh>
    816c:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
    8173:	00 
    8174:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    817b:	00 
    817c:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    8183:	00 
    8184:	e8 a7 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8189:	48 89 c7             	mov    %rax,%rdi
    818c:	e8 7f c4 ff ff       	call   4610 <fwp_rc_fresh>
    8191:	48 8d bc 24 90 05 00 	lea    0x590(%rsp),%rdi
    8198:	00 
    8199:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    81a0:	00 
    81a1:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    81a8:	00 
    81a9:	e8 82 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81ae:	48 89 c7             	mov    %rax,%rdi
    81b1:	e8 5a c4 ff ff       	call   4610 <fwp_rc_fresh>
    81b6:	48 8d bc 24 a0 05 00 	lea    0x5a0(%rsp),%rdi
    81bd:	00 
    81be:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    81c5:	00 
    81c6:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    81cd:	00 
    81ce:	e8 5d c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81d3:	48 89 c7             	mov    %rax,%rdi
    81d6:	e8 35 c4 ff ff       	call   4610 <fwp_rc_fresh>
    81db:	48 8d bc 24 b0 05 00 	lea    0x5b0(%rsp),%rdi
    81e2:	00 
    81e3:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    81ea:	00 
    81eb:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    81f2:	00 
    81f3:	e8 38 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    81f8:	48 89 c7             	mov    %rax,%rdi
    81fb:	e8 10 c4 ff ff       	call   4610 <fwp_rc_fresh>
    8200:	48 8d bc 24 c0 05 00 	lea    0x5c0(%rsp),%rdi
    8207:	00 
    8208:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    820f:	00 
    8210:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    8217:	00 
    8218:	e8 13 c7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    821d:	48 89 c7             	mov    %rax,%rdi
    8220:	e8 eb c3 ff ff       	call   4610 <fwp_rc_fresh>
    8225:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
    822c:	00 
    822d:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    8234:	00 
    8235:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    823c:	00 
    823d:	e8 ee c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8242:	48 89 c7             	mov    %rax,%rdi
    8245:	e8 c6 c3 ff ff       	call   4610 <fwp_rc_fresh>
    824a:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
    8251:	00 
    8252:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    8259:	00 
    825a:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    8261:	00 
    8262:	e8 c9 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8267:	48 89 c7             	mov    %rax,%rdi
    826a:	e8 a1 c3 ff ff       	call   4610 <fwp_rc_fresh>
    826f:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
    8276:	00 
    8277:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    827e:	00 
    827f:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    8286:	00 
    8287:	e8 a4 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    828c:	48 89 c7             	mov    %rax,%rdi
    828f:	e8 7c c3 ff ff       	call   4610 <fwp_rc_fresh>
    8294:	48 8d bc 24 00 06 00 	lea    0x600(%rsp),%rdi
    829b:	00 
    829c:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    82a3:	00 
    82a4:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    82ab:	00 
    82ac:	e8 7f c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82b1:	48 89 c7             	mov    %rax,%rdi
    82b4:	e8 57 c3 ff ff       	call   4610 <fwp_rc_fresh>
    82b9:	48 8d bc 24 10 06 00 	lea    0x610(%rsp),%rdi
    82c0:	00 
    82c1:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    82c8:	00 
    82c9:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    82d0:	00 
    82d1:	e8 5a c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82d6:	48 89 c7             	mov    %rax,%rdi
    82d9:	e8 32 c3 ff ff       	call   4610 <fwp_rc_fresh>
    82de:	48 8d bc 24 20 06 00 	lea    0x620(%rsp),%rdi
    82e5:	00 
    82e6:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    82ed:	00 
    82ee:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    82f5:	00 
    82f6:	e8 35 c6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    82fb:	48 8b 15 36 78 01 00 	mov    0x17836(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8302:	49 89 c5             	mov    %rax,%r13
    8305:	48 2b 05 04 78 01 00 	sub    0x17804(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    830c:	48 c1 e2 10          	shl    $0x10,%rdx
    8310:	48 39 d0             	cmp    %rdx,%rax
    8313:	73 59                	jae    836e <f0+0x112e>
    8315:	48 89 c2             	mov    %rax,%rdx
    8318:	48 c1 ea 10          	shr    $0x10,%rdx
    831c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8320:	48 8b 15 31 78 01 00 	mov    0x17831(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8327:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    832b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    832f:	4d 85 e4             	test   %r12,%r12
    8332:	74 3a                	je     836e <f0+0x112e>
    8334:	0f b6 0a             	movzbl (%rdx),%ecx
    8337:	80 f9 02             	cmp    $0x2,%cl
    833a:	0f 84 d0 15 00 00    	je     9910 <f0+0x26d0>
    8340:	80 f9 01             	cmp    $0x1,%cl
    8343:	75 29                	jne    836e <f0+0x112e>
    8345:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8348:	0f b7 c0             	movzwl %ax,%eax
    834b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    834e:	48 0f af c1          	imul   %rcx,%rax
    8352:	48 c1 e8 20          	shr    $0x20,%rax
    8356:	48 39 d0             	cmp    %rdx,%rax
    8359:	73 13                	jae    836e <f0+0x112e>
    835b:	49 01 c4             	add    %rax,%r12
    835e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8363:	0f 84 86 17 00 00    	je     9aef <f0+0x28af>
    8369:	41 c6 04 24 01       	movb   $0x1,(%r12)
    836e:	48 8d bc 24 30 06 00 	lea    0x630(%rsp),%rdi
    8375:	00 
    8376:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    837d:	00 
    837e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8385:	00 f0 3f 
    8388:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    838f:	00 
    8390:	e8 9b c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8395:	48 8b 15 9c 77 01 00 	mov    0x1779c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    839c:	49 89 c5             	mov    %rax,%r13
    839f:	48 2b 05 6a 77 01 00 	sub    0x1776a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    83a6:	48 c1 e2 10          	shl    $0x10,%rdx
    83aa:	48 39 d0             	cmp    %rdx,%rax
    83ad:	73 59                	jae    8408 <f0+0x11c8>
    83af:	48 89 c2             	mov    %rax,%rdx
    83b2:	48 c1 ea 10          	shr    $0x10,%rdx
    83b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ba:	48 8b 15 97 77 01 00 	mov    0x17797(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    83c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83c5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    83c9:	4d 85 e4             	test   %r12,%r12
    83cc:	74 3a                	je     8408 <f0+0x11c8>
    83ce:	0f b6 0a             	movzbl (%rdx),%ecx
    83d1:	80 f9 02             	cmp    $0x2,%cl
    83d4:	0f 84 26 15 00 00    	je     9900 <f0+0x26c0>
    83da:	80 f9 01             	cmp    $0x1,%cl
    83dd:	75 29                	jne    8408 <f0+0x11c8>
    83df:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83e2:	0f b7 c0             	movzwl %ax,%eax
    83e5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83e8:	48 0f af c1          	imul   %rcx,%rax
    83ec:	48 c1 e8 20          	shr    $0x20,%rax
    83f0:	48 39 d0             	cmp    %rdx,%rax
    83f3:	73 13                	jae    8408 <f0+0x11c8>
    83f5:	49 01 c4             	add    %rax,%r12
    83f8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    83fd:	0f 84 f9 16 00 00    	je     9afc <f0+0x28bc>
    8403:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8408:	48 8d bc 24 40 06 00 	lea    0x640(%rsp),%rdi
    840f:	00 
    8410:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    8417:	00 
    8418:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    841f:	33 f3 bf 
    8422:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    8429:	00 
    842a:	e8 01 c5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    842f:	48 8b 15 02 77 01 00 	mov    0x17702(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8436:	49 89 c5             	mov    %rax,%r13
    8439:	48 2b 05 d0 76 01 00 	sub    0x176d0(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8440:	48 c1 e2 10          	shl    $0x10,%rdx
    8444:	48 39 d0             	cmp    %rdx,%rax
    8447:	73 59                	jae    84a2 <f0+0x1262>
    8449:	48 89 c2             	mov    %rax,%rdx
    844c:	48 c1 ea 10          	shr    $0x10,%rdx
    8450:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8454:	48 8b 15 fd 76 01 00 	mov    0x176fd(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    845b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    845f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8463:	4d 85 e4             	test   %r12,%r12
    8466:	74 3a                	je     84a2 <f0+0x1262>
    8468:	0f b6 0a             	movzbl (%rdx),%ecx
    846b:	80 f9 02             	cmp    $0x2,%cl
    846e:	0f 84 7c 14 00 00    	je     98f0 <f0+0x26b0>
    8474:	80 f9 01             	cmp    $0x1,%cl
    8477:	75 29                	jne    84a2 <f0+0x1262>
    8479:	8b 4a 18             	mov    0x18(%rdx),%ecx
    847c:	0f b7 c0             	movzwl %ax,%eax
    847f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8482:	48 0f af c1          	imul   %rcx,%rax
    8486:	48 c1 e8 20          	shr    $0x20,%rax
    848a:	48 39 d0             	cmp    %rdx,%rax
    848d:	73 13                	jae    84a2 <f0+0x1262>
    848f:	49 01 c4             	add    %rax,%r12
    8492:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8497:	0f 84 6c 16 00 00    	je     9b09 <f0+0x28c9>
    849d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    84a2:	48 8d bc 24 50 06 00 	lea    0x650(%rsp),%rdi
    84a9:	00 
    84aa:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    84b1:	00 
    84b2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    84b9:	00 f0 3f 
    84bc:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    84c3:	00 
    84c4:	e8 67 c4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    84c9:	48 8b 15 68 76 01 00 	mov    0x17668(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    84d0:	49 89 c5             	mov    %rax,%r13
    84d3:	48 2b 05 36 76 01 00 	sub    0x17636(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    84da:	48 c1 e2 10          	shl    $0x10,%rdx
    84de:	48 39 d0             	cmp    %rdx,%rax
    84e1:	73 59                	jae    853c <f0+0x12fc>
    84e3:	48 89 c2             	mov    %rax,%rdx
    84e6:	48 c1 ea 10          	shr    $0x10,%rdx
    84ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84ee:	48 8b 15 63 76 01 00 	mov    0x17663(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    84f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    84fd:	4d 85 e4             	test   %r12,%r12
    8500:	74 3a                	je     853c <f0+0x12fc>
    8502:	0f b6 0a             	movzbl (%rdx),%ecx
    8505:	80 f9 02             	cmp    $0x2,%cl
    8508:	0f 84 92 14 00 00    	je     99a0 <f0+0x2760>
    850e:	80 f9 01             	cmp    $0x1,%cl
    8511:	75 29                	jne    853c <f0+0x12fc>
    8513:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8516:	0f b7 c0             	movzwl %ax,%eax
    8519:	8b 52 1c             	mov    0x1c(%rdx),%edx
    851c:	48 0f af c1          	imul   %rcx,%rax
    8520:	48 c1 e8 20          	shr    $0x20,%rax
    8524:	48 39 d0             	cmp    %rdx,%rax
    8527:	73 13                	jae    853c <f0+0x12fc>
    8529:	49 01 c4             	add    %rax,%r12
    852c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8531:	0f 84 df 15 00 00    	je     9b16 <f0+0x28d6>
    8537:	41 c6 04 24 01       	movb   $0x1,(%r12)
    853c:	48 8d bc 24 60 06 00 	lea    0x660(%rsp),%rdi
    8543:	00 
    8544:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    854b:	00 
    854c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8553:	33 f3 bf 
    8556:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    855d:	00 
    855e:	e8 cd c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8563:	48 8b 15 ce 75 01 00 	mov    0x175ce(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    856a:	49 89 c5             	mov    %rax,%r13
    856d:	48 2b 05 9c 75 01 00 	sub    0x1759c(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8574:	48 c1 e2 10          	shl    $0x10,%rdx
    8578:	48 39 d0             	cmp    %rdx,%rax
    857b:	73 59                	jae    85d6 <f0+0x1396>
    857d:	48 89 c2             	mov    %rax,%rdx
    8580:	48 c1 ea 10          	shr    $0x10,%rdx
    8584:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8588:	48 8b 15 c9 75 01 00 	mov    0x175c9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    858f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8593:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8597:	4d 85 e4             	test   %r12,%r12
    859a:	74 3a                	je     85d6 <f0+0x1396>
    859c:	0f b6 0a             	movzbl (%rdx),%ecx
    859f:	80 f9 02             	cmp    $0x2,%cl
    85a2:	0f 84 e8 13 00 00    	je     9990 <f0+0x2750>
    85a8:	80 f9 01             	cmp    $0x1,%cl
    85ab:	75 29                	jne    85d6 <f0+0x1396>
    85ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85b0:	0f b7 c0             	movzwl %ax,%eax
    85b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85b6:	48 0f af c1          	imul   %rcx,%rax
    85ba:	48 c1 e8 20          	shr    $0x20,%rax
    85be:	48 39 d0             	cmp    %rdx,%rax
    85c1:	73 13                	jae    85d6 <f0+0x1396>
    85c3:	49 01 c4             	add    %rax,%r12
    85c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    85cb:	0f 84 52 15 00 00    	je     9b23 <f0+0x28e3>
    85d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    85d6:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
    85dd:	00 
    85de:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    85e5:	00 
    85e6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    85ed:	00 f0 3f 
    85f0:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    85f7:	00 
    85f8:	e8 33 c3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    85fd:	48 8b 15 34 75 01 00 	mov    0x17534(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8604:	49 89 c5             	mov    %rax,%r13
    8607:	48 2b 05 02 75 01 00 	sub    0x17502(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    860e:	48 c1 e2 10          	shl    $0x10,%rdx
    8612:	48 39 d0             	cmp    %rdx,%rax
    8615:	73 59                	jae    8670 <f0+0x1430>
    8617:	48 89 c2             	mov    %rax,%rdx
    861a:	48 c1 ea 10          	shr    $0x10,%rdx
    861e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8622:	48 8b 15 2f 75 01 00 	mov    0x1752f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8629:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    862d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8631:	4d 85 e4             	test   %r12,%r12
    8634:	74 3a                	je     8670 <f0+0x1430>
    8636:	0f b6 0a             	movzbl (%rdx),%ecx
    8639:	80 f9 02             	cmp    $0x2,%cl
    863c:	0f 84 3e 13 00 00    	je     9980 <f0+0x2740>
    8642:	80 f9 01             	cmp    $0x1,%cl
    8645:	75 29                	jne    8670 <f0+0x1430>
    8647:	8b 4a 18             	mov    0x18(%rdx),%ecx
    864a:	0f b7 c0             	movzwl %ax,%eax
    864d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8650:	48 0f af c1          	imul   %rcx,%rax
    8654:	48 c1 e8 20          	shr    $0x20,%rax
    8658:	48 39 d0             	cmp    %rdx,%rax
    865b:	73 13                	jae    8670 <f0+0x1430>
    865d:	49 01 c4             	add    %rax,%r12
    8660:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8665:	0f 84 c5 14 00 00    	je     9b30 <f0+0x28f0>
    866b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8670:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
    8677:	00 
    8678:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    867f:	00 
    8680:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8687:	33 f3 bf 
    868a:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    8691:	00 
    8692:	e8 99 c2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8697:	48 8b 15 9a 74 01 00 	mov    0x1749a(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    869e:	49 89 c5             	mov    %rax,%r13
    86a1:	48 2b 05 68 74 01 00 	sub    0x17468(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    86a8:	48 c1 e2 10          	shl    $0x10,%rdx
    86ac:	48 39 d0             	cmp    %rdx,%rax
    86af:	73 59                	jae    870a <f0+0x14ca>
    86b1:	48 89 c2             	mov    %rax,%rdx
    86b4:	48 c1 ea 10          	shr    $0x10,%rdx
    86b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86bc:	48 8b 15 95 74 01 00 	mov    0x17495(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    86c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    86cb:	4d 85 e4             	test   %r12,%r12
    86ce:	74 3a                	je     870a <f0+0x14ca>
    86d0:	0f b6 0a             	movzbl (%rdx),%ecx
    86d3:	80 f9 02             	cmp    $0x2,%cl
    86d6:	0f 84 94 12 00 00    	je     9970 <f0+0x2730>
    86dc:	80 f9 01             	cmp    $0x1,%cl
    86df:	75 29                	jne    870a <f0+0x14ca>
    86e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86e4:	0f b7 c0             	movzwl %ax,%eax
    86e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86ea:	48 0f af c1          	imul   %rcx,%rax
    86ee:	48 c1 e8 20          	shr    $0x20,%rax
    86f2:	48 39 d0             	cmp    %rdx,%rax
    86f5:	73 13                	jae    870a <f0+0x14ca>
    86f7:	49 01 c4             	add    %rax,%r12
    86fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    86ff:	0f 84 38 14 00 00    	je     9b3d <f0+0x28fd>
    8705:	41 c6 04 24 01       	movb   $0x1,(%r12)
    870a:	48 8d bc 24 90 06 00 	lea    0x690(%rsp),%rdi
    8711:	00 
    8712:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    8719:	00 
    871a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8721:	00 f0 3f 
    8724:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    872b:	00 
    872c:	e8 ff c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8731:	48 8b 15 00 74 01 00 	mov    0x17400(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8738:	49 89 c5             	mov    %rax,%r13
    873b:	48 2b 05 ce 73 01 00 	sub    0x173ce(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8742:	48 c1 e2 10          	shl    $0x10,%rdx
    8746:	48 39 d0             	cmp    %rdx,%rax
    8749:	73 59                	jae    87a4 <f0+0x1564>
    874b:	48 89 c2             	mov    %rax,%rdx
    874e:	48 c1 ea 10          	shr    $0x10,%rdx
    8752:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8756:	48 8b 15 fb 73 01 00 	mov    0x173fb(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    875d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8761:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8765:	4d 85 e4             	test   %r12,%r12
    8768:	74 3a                	je     87a4 <f0+0x1564>
    876a:	0f b6 0a             	movzbl (%rdx),%ecx
    876d:	80 f9 02             	cmp    $0x2,%cl
    8770:	0f 84 ea 11 00 00    	je     9960 <f0+0x2720>
    8776:	80 f9 01             	cmp    $0x1,%cl
    8779:	75 29                	jne    87a4 <f0+0x1564>
    877b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    877e:	0f b7 c0             	movzwl %ax,%eax
    8781:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8784:	48 0f af c1          	imul   %rcx,%rax
    8788:	48 c1 e8 20          	shr    $0x20,%rax
    878c:	48 39 d0             	cmp    %rdx,%rax
    878f:	73 13                	jae    87a4 <f0+0x1564>
    8791:	49 01 c4             	add    %rax,%r12
    8794:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8799:	0f 84 ab 13 00 00    	je     9b4a <f0+0x290a>
    879f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    87a4:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
    87ab:	00 
    87ac:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    87b3:	00 
    87b4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    87bb:	33 f3 bf 
    87be:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    87c5:	00 
    87c6:	e8 65 c1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    87cb:	48 8b 15 66 73 01 00 	mov    0x17366(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    87d2:	49 89 c5             	mov    %rax,%r13
    87d5:	48 2b 05 34 73 01 00 	sub    0x17334(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    87dc:	48 c1 e2 10          	shl    $0x10,%rdx
    87e0:	48 39 d0             	cmp    %rdx,%rax
    87e3:	73 59                	jae    883e <f0+0x15fe>
    87e5:	48 89 c2             	mov    %rax,%rdx
    87e8:	48 c1 ea 10          	shr    $0x10,%rdx
    87ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87f0:	48 8b 15 61 73 01 00 	mov    0x17361(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    87f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87fb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    87ff:	4d 85 e4             	test   %r12,%r12
    8802:	74 3a                	je     883e <f0+0x15fe>
    8804:	0f b6 0a             	movzbl (%rdx),%ecx
    8807:	80 f9 02             	cmp    $0x2,%cl
    880a:	0f 84 40 11 00 00    	je     9950 <f0+0x2710>
    8810:	80 f9 01             	cmp    $0x1,%cl
    8813:	75 29                	jne    883e <f0+0x15fe>
    8815:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8818:	0f b7 c0             	movzwl %ax,%eax
    881b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    881e:	48 0f af c1          	imul   %rcx,%rax
    8822:	48 c1 e8 20          	shr    $0x20,%rax
    8826:	48 39 d0             	cmp    %rdx,%rax
    8829:	73 13                	jae    883e <f0+0x15fe>
    882b:	49 01 c4             	add    %rax,%r12
    882e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8833:	0f 84 1e 13 00 00    	je     9b57 <f0+0x2917>
    8839:	41 c6 04 24 01       	movb   $0x1,(%r12)
    883e:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
    8845:	00 
    8846:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    884d:	00 
    884e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8855:	00 f0 3f 
    8858:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    885f:	00 
    8860:	e8 cb c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8865:	48 8b 15 cc 72 01 00 	mov    0x172cc(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    886c:	49 89 c5             	mov    %rax,%r13
    886f:	48 2b 05 9a 72 01 00 	sub    0x1729a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8876:	48 c1 e2 10          	shl    $0x10,%rdx
    887a:	48 39 d0             	cmp    %rdx,%rax
    887d:	73 59                	jae    88d8 <f0+0x1698>
    887f:	48 89 c2             	mov    %rax,%rdx
    8882:	48 c1 ea 10          	shr    $0x10,%rdx
    8886:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    888a:	48 8b 15 c7 72 01 00 	mov    0x172c7(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8891:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8895:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8899:	4d 85 e4             	test   %r12,%r12
    889c:	74 3a                	je     88d8 <f0+0x1698>
    889e:	0f b6 0a             	movzbl (%rdx),%ecx
    88a1:	80 f9 02             	cmp    $0x2,%cl
    88a4:	0f 84 96 10 00 00    	je     9940 <f0+0x2700>
    88aa:	80 f9 01             	cmp    $0x1,%cl
    88ad:	75 29                	jne    88d8 <f0+0x1698>
    88af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88b2:	0f b7 c0             	movzwl %ax,%eax
    88b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88b8:	48 0f af c1          	imul   %rcx,%rax
    88bc:	48 c1 e8 20          	shr    $0x20,%rax
    88c0:	48 39 d0             	cmp    %rdx,%rax
    88c3:	73 13                	jae    88d8 <f0+0x1698>
    88c5:	49 01 c4             	add    %rax,%r12
    88c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    88cd:	0f 84 91 12 00 00    	je     9b64 <f0+0x2924>
    88d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    88d8:	48 8d bc 24 c0 06 00 	lea    0x6c0(%rsp),%rdi
    88df:	00 
    88e0:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    88e7:	00 
    88e8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    88ef:	33 f3 bf 
    88f2:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    88f9:	00 
    88fa:	e8 31 c0 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    88ff:	48 8b 15 32 72 01 00 	mov    0x17232(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8906:	49 89 c5             	mov    %rax,%r13
    8909:	48 2b 05 00 72 01 00 	sub    0x17200(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8910:	48 c1 e2 10          	shl    $0x10,%rdx
    8914:	48 39 d0             	cmp    %rdx,%rax
    8917:	73 59                	jae    8972 <f0+0x1732>
    8919:	48 89 c2             	mov    %rax,%rdx
    891c:	48 c1 ea 10          	shr    $0x10,%rdx
    8920:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8924:	48 8b 15 2d 72 01 00 	mov    0x1722d(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    892b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    892f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8933:	4d 85 e4             	test   %r12,%r12
    8936:	74 3a                	je     8972 <f0+0x1732>
    8938:	0f b6 0a             	movzbl (%rdx),%ecx
    893b:	80 f9 02             	cmp    $0x2,%cl
    893e:	0f 84 ec 0f 00 00    	je     9930 <f0+0x26f0>
    8944:	80 f9 01             	cmp    $0x1,%cl
    8947:	75 29                	jne    8972 <f0+0x1732>
    8949:	8b 4a 18             	mov    0x18(%rdx),%ecx
    894c:	0f b7 c0             	movzwl %ax,%eax
    894f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8952:	48 0f af c1          	imul   %rcx,%rax
    8956:	48 c1 e8 20          	shr    $0x20,%rax
    895a:	48 39 d0             	cmp    %rdx,%rax
    895d:	73 13                	jae    8972 <f0+0x1732>
    895f:	49 01 c4             	add    %rax,%r12
    8962:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8967:	0f 84 04 12 00 00    	je     9b71 <f0+0x2931>
    896d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8972:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
    8979:	00 
    897a:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    8981:	00 
    8982:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8989:	00 f0 3f 
    898c:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    8993:	00 
    8994:	e8 97 bf ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8999:	48 8b 15 98 71 01 00 	mov    0x17198(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    89a0:	49 89 c5             	mov    %rax,%r13
    89a3:	48 2b 05 66 71 01 00 	sub    0x17166(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    89aa:	48 c1 e2 10          	shl    $0x10,%rdx
    89ae:	48 39 d0             	cmp    %rdx,%rax
    89b1:	73 59                	jae    8a0c <f0+0x17cc>
    89b3:	48 89 c2             	mov    %rax,%rdx
    89b6:	48 c1 ea 10          	shr    $0x10,%rdx
    89ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89be:	48 8b 15 93 71 01 00 	mov    0x17193(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    89c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    89cd:	4d 85 e4             	test   %r12,%r12
    89d0:	74 3a                	je     8a0c <f0+0x17cc>
    89d2:	0f b6 0a             	movzbl (%rdx),%ecx
    89d5:	80 f9 02             	cmp    $0x2,%cl
    89d8:	0f 84 d2 0e 00 00    	je     98b0 <f0+0x2670>
    89de:	80 f9 01             	cmp    $0x1,%cl
    89e1:	75 29                	jne    8a0c <f0+0x17cc>
    89e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    89e6:	0f b7 c0             	movzwl %ax,%eax
    89e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89ec:	48 0f af c1          	imul   %rcx,%rax
    89f0:	48 c1 e8 20          	shr    $0x20,%rax
    89f4:	48 39 d0             	cmp    %rdx,%rax
    89f7:	73 13                	jae    8a0c <f0+0x17cc>
    89f9:	49 01 c4             	add    %rax,%r12
    89fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a01:	0f 84 77 11 00 00    	je     9b7e <f0+0x293e>
    8a07:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8a0c:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
    8a13:	00 
    8a14:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    8a1b:	00 
    8a1c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8a23:	33 f3 bf 
    8a26:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    8a2d:	00 
    8a2e:	e8 fd be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8a33:	48 8b 15 fe 70 01 00 	mov    0x170fe(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8a3a:	49 89 c5             	mov    %rax,%r13
    8a3d:	48 2b 05 cc 70 01 00 	sub    0x170cc(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8a44:	48 c1 e2 10          	shl    $0x10,%rdx
    8a48:	48 39 d0             	cmp    %rdx,%rax
    8a4b:	73 59                	jae    8aa6 <f0+0x1866>
    8a4d:	48 89 c2             	mov    %rax,%rdx
    8a50:	48 c1 ea 10          	shr    $0x10,%rdx
    8a54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a58:	48 8b 15 f9 70 01 00 	mov    0x170f9(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8a5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a63:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8a67:	4d 85 e4             	test   %r12,%r12
    8a6a:	74 3a                	je     8aa6 <f0+0x1866>
    8a6c:	0f b6 0a             	movzbl (%rdx),%ecx
    8a6f:	80 f9 02             	cmp    $0x2,%cl
    8a72:	0f 84 28 0e 00 00    	je     98a0 <f0+0x2660>
    8a78:	80 f9 01             	cmp    $0x1,%cl
    8a7b:	75 29                	jne    8aa6 <f0+0x1866>
    8a7d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a80:	0f b7 c0             	movzwl %ax,%eax
    8a83:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a86:	48 0f af c1          	imul   %rcx,%rax
    8a8a:	48 c1 e8 20          	shr    $0x20,%rax
    8a8e:	48 39 d0             	cmp    %rdx,%rax
    8a91:	73 13                	jae    8aa6 <f0+0x1866>
    8a93:	49 01 c4             	add    %rax,%r12
    8a96:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a9b:	0f 84 ea 10 00 00    	je     9b8b <f0+0x294b>
    8aa1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8aa6:	48 8d bc 24 f0 06 00 	lea    0x6f0(%rsp),%rdi
    8aad:	00 
    8aae:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    8ab5:	00 
    8ab6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8abd:	00 f0 3f 
    8ac0:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    8ac7:	00 
    8ac8:	e8 63 be ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8acd:	48 8b 15 64 70 01 00 	mov    0x17064(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8ad4:	49 89 c5             	mov    %rax,%r13
    8ad7:	48 2b 05 32 70 01 00 	sub    0x17032(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8ade:	48 c1 e2 10          	shl    $0x10,%rdx
    8ae2:	48 39 d0             	cmp    %rdx,%rax
    8ae5:	73 59                	jae    8b40 <f0+0x1900>
    8ae7:	48 89 c2             	mov    %rax,%rdx
    8aea:	48 c1 ea 10          	shr    $0x10,%rdx
    8aee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8af2:	48 8b 15 5f 70 01 00 	mov    0x1705f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8af9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8afd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b01:	4d 85 e4             	test   %r12,%r12
    8b04:	74 3a                	je     8b40 <f0+0x1900>
    8b06:	0f b6 0a             	movzbl (%rdx),%ecx
    8b09:	80 f9 02             	cmp    $0x2,%cl
    8b0c:	0f 84 7e 0d 00 00    	je     9890 <f0+0x2650>
    8b12:	80 f9 01             	cmp    $0x1,%cl
    8b15:	75 29                	jne    8b40 <f0+0x1900>
    8b17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b1a:	0f b7 c0             	movzwl %ax,%eax
    8b1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b20:	48 0f af c1          	imul   %rcx,%rax
    8b24:	48 c1 e8 20          	shr    $0x20,%rax
    8b28:	48 39 d0             	cmp    %rdx,%rax
    8b2b:	73 13                	jae    8b40 <f0+0x1900>
    8b2d:	49 01 c4             	add    %rax,%r12
    8b30:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b35:	0f 84 5d 10 00 00    	je     9b98 <f0+0x2958>
    8b3b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8b40:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
    8b47:	00 
    8b48:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    8b4f:	00 
    8b50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8b57:	33 f3 bf 
    8b5a:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    8b61:	00 
    8b62:	e8 c9 bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8b67:	48 8b 15 ca 6f 01 00 	mov    0x16fca(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8b6e:	49 89 c5             	mov    %rax,%r13
    8b71:	48 2b 05 98 6f 01 00 	sub    0x16f98(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8b78:	48 c1 e2 10          	shl    $0x10,%rdx
    8b7c:	48 39 d0             	cmp    %rdx,%rax
    8b7f:	73 59                	jae    8bda <f0+0x199a>
    8b81:	48 89 c2             	mov    %rax,%rdx
    8b84:	48 c1 ea 10          	shr    $0x10,%rdx
    8b88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b8c:	48 8b 15 c5 6f 01 00 	mov    0x16fc5(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8b93:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b97:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b9b:	4d 85 e4             	test   %r12,%r12
    8b9e:	74 3a                	je     8bda <f0+0x199a>
    8ba0:	0f b6 0a             	movzbl (%rdx),%ecx
    8ba3:	80 f9 02             	cmp    $0x2,%cl
    8ba6:	0f 84 d4 0c 00 00    	je     9880 <f0+0x2640>
    8bac:	80 f9 01             	cmp    $0x1,%cl
    8baf:	75 29                	jne    8bda <f0+0x199a>
    8bb1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8bb4:	0f b7 c0             	movzwl %ax,%eax
    8bb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bba:	48 0f af c1          	imul   %rcx,%rax
    8bbe:	48 c1 e8 20          	shr    $0x20,%rax
    8bc2:	48 39 d0             	cmp    %rdx,%rax
    8bc5:	73 13                	jae    8bda <f0+0x199a>
    8bc7:	49 01 c4             	add    %rax,%r12
    8bca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8bcf:	0f 84 d0 0f 00 00    	je     9ba5 <f0+0x2965>
    8bd5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8bda:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
    8be1:	00 
    8be2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    8be9:	00 
    8bea:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8bf1:	00 f0 3f 
    8bf4:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    8bfb:	00 
    8bfc:	e8 2f bd ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8c01:	48 8b 15 30 6f 01 00 	mov    0x16f30(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8c08:	49 89 c5             	mov    %rax,%r13
    8c0b:	48 2b 05 fe 6e 01 00 	sub    0x16efe(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8c12:	48 c1 e2 10          	shl    $0x10,%rdx
    8c16:	48 39 d0             	cmp    %rdx,%rax
    8c19:	73 59                	jae    8c74 <f0+0x1a34>
    8c1b:	48 89 c2             	mov    %rax,%rdx
    8c1e:	48 c1 ea 10          	shr    $0x10,%rdx
    8c22:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c26:	48 8b 15 2b 6f 01 00 	mov    0x16f2b(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8c2d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c31:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c35:	4d 85 e4             	test   %r12,%r12
    8c38:	74 3a                	je     8c74 <f0+0x1a34>
    8c3a:	0f b6 0a             	movzbl (%rdx),%ecx
    8c3d:	80 f9 02             	cmp    $0x2,%cl
    8c40:	0f 84 2a 0c 00 00    	je     9870 <f0+0x2630>
    8c46:	80 f9 01             	cmp    $0x1,%cl
    8c49:	75 29                	jne    8c74 <f0+0x1a34>
    8c4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c4e:	0f b7 c0             	movzwl %ax,%eax
    8c51:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c54:	48 0f af c1          	imul   %rcx,%rax
    8c58:	48 c1 e8 20          	shr    $0x20,%rax
    8c5c:	48 39 d0             	cmp    %rdx,%rax
    8c5f:	73 13                	jae    8c74 <f0+0x1a34>
    8c61:	49 01 c4             	add    %rax,%r12
    8c64:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c69:	0f 84 43 0f 00 00    	je     9bb2 <f0+0x2972>
    8c6f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c74:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
    8c7b:	00 
    8c7c:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    8c83:	00 
    8c84:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8c8b:	33 f3 bf 
    8c8e:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    8c95:	00 
    8c96:	e8 95 bc ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8c9b:	48 8b 15 96 6e 01 00 	mov    0x16e96(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8ca2:	49 89 c5             	mov    %rax,%r13
    8ca5:	48 2b 05 64 6e 01 00 	sub    0x16e64(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8cac:	48 c1 e2 10          	shl    $0x10,%rdx
    8cb0:	48 39 d0             	cmp    %rdx,%rax
    8cb3:	73 59                	jae    8d0e <f0+0x1ace>
    8cb5:	48 89 c2             	mov    %rax,%rdx
    8cb8:	48 c1 ea 10          	shr    $0x10,%rdx
    8cbc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cc0:	48 8b 15 91 6e 01 00 	mov    0x16e91(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8cc7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ccb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ccf:	4d 85 e4             	test   %r12,%r12
    8cd2:	74 3a                	je     8d0e <f0+0x1ace>
    8cd4:	0f b6 0a             	movzbl (%rdx),%ecx
    8cd7:	80 f9 02             	cmp    $0x2,%cl
    8cda:	0f 84 80 0b 00 00    	je     9860 <f0+0x2620>
    8ce0:	80 f9 01             	cmp    $0x1,%cl
    8ce3:	75 29                	jne    8d0e <f0+0x1ace>
    8ce5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ce8:	0f b7 c0             	movzwl %ax,%eax
    8ceb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8cee:	48 0f af c1          	imul   %rcx,%rax
    8cf2:	48 c1 e8 20          	shr    $0x20,%rax
    8cf6:	48 39 d0             	cmp    %rdx,%rax
    8cf9:	73 13                	jae    8d0e <f0+0x1ace>
    8cfb:	49 01 c4             	add    %rax,%r12
    8cfe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d03:	0f 84 b6 0e 00 00    	je     9bbf <f0+0x297f>
    8d09:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d0e:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
    8d15:	00 
    8d16:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    8d1d:	00 
    8d1e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8d25:	00 f0 3f 
    8d28:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    8d2f:	00 
    8d30:	e8 fb bb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8d35:	48 8b 15 fc 6d 01 00 	mov    0x16dfc(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8d3c:	49 89 c5             	mov    %rax,%r13
    8d3f:	48 2b 05 ca 6d 01 00 	sub    0x16dca(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8d46:	48 c1 e2 10          	shl    $0x10,%rdx
    8d4a:	48 39 d0             	cmp    %rdx,%rax
    8d4d:	73 59                	jae    8da8 <f0+0x1b68>
    8d4f:	48 89 c2             	mov    %rax,%rdx
    8d52:	48 c1 ea 10          	shr    $0x10,%rdx
    8d56:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d5a:	48 8b 15 f7 6d 01 00 	mov    0x16df7(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8d61:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d65:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d69:	4d 85 e4             	test   %r12,%r12
    8d6c:	74 3a                	je     8da8 <f0+0x1b68>
    8d6e:	0f b6 0a             	movzbl (%rdx),%ecx
    8d71:	80 f9 02             	cmp    $0x2,%cl
    8d74:	0f 84 d6 0a 00 00    	je     9850 <f0+0x2610>
    8d7a:	80 f9 01             	cmp    $0x1,%cl
    8d7d:	75 29                	jne    8da8 <f0+0x1b68>
    8d7f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d82:	0f b7 c0             	movzwl %ax,%eax
    8d85:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d88:	48 0f af c1          	imul   %rcx,%rax
    8d8c:	48 c1 e8 20          	shr    $0x20,%rax
    8d90:	48 39 d0             	cmp    %rdx,%rax
    8d93:	73 13                	jae    8da8 <f0+0x1b68>
    8d95:	49 01 c4             	add    %rax,%r12
    8d98:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d9d:	0f 84 29 0e 00 00    	je     9bcc <f0+0x298c>
    8da3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8da8:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
    8daf:	00 
    8db0:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    8db7:	00 
    8db8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8dbf:	33 f3 bf 
    8dc2:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    8dc9:	00 
    8dca:	e8 61 bb ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8dcf:	48 8b 15 62 6d 01 00 	mov    0x16d62(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8dd6:	49 89 c5             	mov    %rax,%r13
    8dd9:	48 2b 05 30 6d 01 00 	sub    0x16d30(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8de0:	48 c1 e2 10          	shl    $0x10,%rdx
    8de4:	48 39 d0             	cmp    %rdx,%rax
    8de7:	73 59                	jae    8e42 <f0+0x1c02>
    8de9:	48 89 c2             	mov    %rax,%rdx
    8dec:	48 c1 ea 10          	shr    $0x10,%rdx
    8df0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8df4:	48 8b 15 5d 6d 01 00 	mov    0x16d5d(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8dfb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8dff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e03:	4d 85 e4             	test   %r12,%r12
    8e06:	74 3a                	je     8e42 <f0+0x1c02>
    8e08:	0f b6 0a             	movzbl (%rdx),%ecx
    8e0b:	80 f9 02             	cmp    $0x2,%cl
    8e0e:	0f 84 24 0a 00 00    	je     9838 <f0+0x25f8>
    8e14:	80 f9 01             	cmp    $0x1,%cl
    8e17:	75 29                	jne    8e42 <f0+0x1c02>
    8e19:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e1c:	0f b7 c0             	movzwl %ax,%eax
    8e1f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e22:	48 0f af c1          	imul   %rcx,%rax
    8e26:	48 c1 e8 20          	shr    $0x20,%rax
    8e2a:	48 39 d0             	cmp    %rdx,%rax
    8e2d:	73 13                	jae    8e42 <f0+0x1c02>
    8e2f:	49 01 c4             	add    %rax,%r12
    8e32:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e37:	0f 84 9c 0d 00 00    	je     9bd9 <f0+0x2999>
    8e3d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e42:	48 8d bc 24 50 07 00 	lea    0x750(%rsp),%rdi
    8e49:	00 
    8e4a:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    8e51:	00 
    8e52:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8e59:	00 f0 3f 
    8e5c:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    8e63:	00 
    8e64:	e8 c7 ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8e69:	48 8b 15 c8 6c 01 00 	mov    0x16cc8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8e70:	49 89 c5             	mov    %rax,%r13
    8e73:	48 2b 05 96 6c 01 00 	sub    0x16c96(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8e7a:	48 c1 e2 10          	shl    $0x10,%rdx
    8e7e:	48 39 d0             	cmp    %rdx,%rax
    8e81:	73 59                	jae    8edc <f0+0x1c9c>
    8e83:	48 89 c2             	mov    %rax,%rdx
    8e86:	48 c1 ea 10          	shr    $0x10,%rdx
    8e8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e8e:	48 8b 15 c3 6c 01 00 	mov    0x16cc3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8e95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e99:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e9d:	4d 85 e4             	test   %r12,%r12
    8ea0:	74 3a                	je     8edc <f0+0x1c9c>
    8ea2:	0f b6 0a             	movzbl (%rdx),%ecx
    8ea5:	80 f9 02             	cmp    $0x2,%cl
    8ea8:	0f 84 f2 0b 00 00    	je     9aa0 <f0+0x2860>
    8eae:	80 f9 01             	cmp    $0x1,%cl
    8eb1:	75 29                	jne    8edc <f0+0x1c9c>
    8eb3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8eb6:	0f b7 c0             	movzwl %ax,%eax
    8eb9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ebc:	48 0f af c1          	imul   %rcx,%rax
    8ec0:	48 c1 e8 20          	shr    $0x20,%rax
    8ec4:	48 39 d0             	cmp    %rdx,%rax
    8ec7:	73 13                	jae    8edc <f0+0x1c9c>
    8ec9:	49 01 c4             	add    %rax,%r12
    8ecc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ed1:	0f 84 0f 0d 00 00    	je     9be6 <f0+0x29a6>
    8ed7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8edc:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
    8ee3:	00 
    8ee4:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    8eeb:	00 
    8eec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8ef3:	33 f3 bf 
    8ef6:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    8efd:	00 
    8efe:	e8 2d ba ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8f03:	48 8b 15 2e 6c 01 00 	mov    0x16c2e(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8f0a:	49 89 c5             	mov    %rax,%r13
    8f0d:	48 2b 05 fc 6b 01 00 	sub    0x16bfc(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8f14:	48 c1 e2 10          	shl    $0x10,%rdx
    8f18:	48 39 d0             	cmp    %rdx,%rax
    8f1b:	73 59                	jae    8f76 <f0+0x1d36>
    8f1d:	48 89 c2             	mov    %rax,%rdx
    8f20:	48 c1 ea 10          	shr    $0x10,%rdx
    8f24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f28:	48 8b 15 29 6c 01 00 	mov    0x16c29(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8f2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f33:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f37:	4d 85 e4             	test   %r12,%r12
    8f3a:	74 3a                	je     8f76 <f0+0x1d36>
    8f3c:	0f b6 0a             	movzbl (%rdx),%ecx
    8f3f:	80 f9 02             	cmp    $0x2,%cl
    8f42:	0f 84 48 0b 00 00    	je     9a90 <f0+0x2850>
    8f48:	80 f9 01             	cmp    $0x1,%cl
    8f4b:	75 29                	jne    8f76 <f0+0x1d36>
    8f4d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f50:	0f b7 c0             	movzwl %ax,%eax
    8f53:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f56:	48 0f af c1          	imul   %rcx,%rax
    8f5a:	48 c1 e8 20          	shr    $0x20,%rax
    8f5e:	48 39 d0             	cmp    %rdx,%rax
    8f61:	73 13                	jae    8f76 <f0+0x1d36>
    8f63:	49 01 c4             	add    %rax,%r12
    8f66:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f6b:	0f 84 82 0c 00 00    	je     9bf3 <f0+0x29b3>
    8f71:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f76:	48 8d bc 24 70 07 00 	lea    0x770(%rsp),%rdi
    8f7d:	00 
    8f7e:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    8f85:	00 
    8f86:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8f8d:	00 f0 3f 
    8f90:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    8f97:	00 
    8f98:	e8 93 b9 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    8f9d:	48 8b 15 94 6b 01 00 	mov    0x16b94(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    8fa4:	49 89 c5             	mov    %rax,%r13
    8fa7:	48 2b 05 62 6b 01 00 	sub    0x16b62(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    8fae:	48 c1 e2 10          	shl    $0x10,%rdx
    8fb2:	48 39 d0             	cmp    %rdx,%rax
    8fb5:	73 59                	jae    9010 <f0+0x1dd0>
    8fb7:	48 89 c2             	mov    %rax,%rdx
    8fba:	48 c1 ea 10          	shr    $0x10,%rdx
    8fbe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8fc2:	48 8b 15 8f 6b 01 00 	mov    0x16b8f(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    8fc9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8fcd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8fd1:	4d 85 e4             	test   %r12,%r12
    8fd4:	74 3a                	je     9010 <f0+0x1dd0>
    8fd6:	0f b6 0a             	movzbl (%rdx),%ecx
    8fd9:	80 f9 02             	cmp    $0x2,%cl
    8fdc:	0f 84 9e 0a 00 00    	je     9a80 <f0+0x2840>
    8fe2:	80 f9 01             	cmp    $0x1,%cl
    8fe5:	75 29                	jne    9010 <f0+0x1dd0>
    8fe7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8fea:	0f b7 c0             	movzwl %ax,%eax
    8fed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ff0:	48 0f af c1          	imul   %rcx,%rax
    8ff4:	48 c1 e8 20          	shr    $0x20,%rax
    8ff8:	48 39 d0             	cmp    %rdx,%rax
    8ffb:	73 13                	jae    9010 <f0+0x1dd0>
    8ffd:	49 01 c4             	add    %rax,%r12
    9000:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9005:	0f 84 f5 0b 00 00    	je     9c00 <f0+0x29c0>
    900b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9010:	48 8d bc 24 80 07 00 	lea    0x780(%rsp),%rdi
    9017:	00 
    9018:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    901f:	00 
    9020:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9027:	33 f3 bf 
    902a:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    9031:	00 
    9032:	e8 f9 b8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9037:	48 8b 15 fa 6a 01 00 	mov    0x16afa(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    903e:	49 89 c5             	mov    %rax,%r13
    9041:	48 2b 05 c8 6a 01 00 	sub    0x16ac8(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9048:	48 c1 e2 10          	shl    $0x10,%rdx
    904c:	48 39 d0             	cmp    %rdx,%rax
    904f:	73 59                	jae    90aa <f0+0x1e6a>
    9051:	48 89 c2             	mov    %rax,%rdx
    9054:	48 c1 ea 10          	shr    $0x10,%rdx
    9058:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    905c:	48 8b 15 f5 6a 01 00 	mov    0x16af5(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9063:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9067:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    906b:	4d 85 e4             	test   %r12,%r12
    906e:	74 3a                	je     90aa <f0+0x1e6a>
    9070:	0f b6 0a             	movzbl (%rdx),%ecx
    9073:	80 f9 02             	cmp    $0x2,%cl
    9076:	0f 84 f4 09 00 00    	je     9a70 <f0+0x2830>
    907c:	80 f9 01             	cmp    $0x1,%cl
    907f:	75 29                	jne    90aa <f0+0x1e6a>
    9081:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9084:	0f b7 c0             	movzwl %ax,%eax
    9087:	8b 52 1c             	mov    0x1c(%rdx),%edx
    908a:	48 0f af c1          	imul   %rcx,%rax
    908e:	48 c1 e8 20          	shr    $0x20,%rax
    9092:	48 39 d0             	cmp    %rdx,%rax
    9095:	73 13                	jae    90aa <f0+0x1e6a>
    9097:	49 01 c4             	add    %rax,%r12
    909a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    909f:	0f 84 68 0b 00 00    	je     9c0d <f0+0x29cd>
    90a5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    90aa:	48 8d bc 24 90 07 00 	lea    0x790(%rsp),%rdi
    90b1:	00 
    90b2:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    90b9:	00 
    90ba:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    90c1:	00 f0 3f 
    90c4:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    90cb:	00 
    90cc:	e8 5f b8 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    90d1:	48 8b 15 60 6a 01 00 	mov    0x16a60(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    90d8:	49 89 c5             	mov    %rax,%r13
    90db:	48 2b 05 2e 6a 01 00 	sub    0x16a2e(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    90e2:	48 c1 e2 10          	shl    $0x10,%rdx
    90e6:	48 39 d0             	cmp    %rdx,%rax
    90e9:	73 59                	jae    9144 <f0+0x1f04>
    90eb:	48 89 c2             	mov    %rax,%rdx
    90ee:	48 c1 ea 10          	shr    $0x10,%rdx
    90f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90f6:	48 8b 15 5b 6a 01 00 	mov    0x16a5b(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    90fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9101:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9105:	4d 85 e4             	test   %r12,%r12
    9108:	74 3a                	je     9144 <f0+0x1f04>
    910a:	0f b6 0a             	movzbl (%rdx),%ecx
    910d:	80 f9 02             	cmp    $0x2,%cl
    9110:	0f 84 4a 09 00 00    	je     9a60 <f0+0x2820>
    9116:	80 f9 01             	cmp    $0x1,%cl
    9119:	75 29                	jne    9144 <f0+0x1f04>
    911b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    911e:	0f b7 c0             	movzwl %ax,%eax
    9121:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9124:	48 0f af c1          	imul   %rcx,%rax
    9128:	48 c1 e8 20          	shr    $0x20,%rax
    912c:	48 39 d0             	cmp    %rdx,%rax
    912f:	73 13                	jae    9144 <f0+0x1f04>
    9131:	49 01 c4             	add    %rax,%r12
    9134:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9139:	0f 84 db 0a 00 00    	je     9c1a <f0+0x29da>
    913f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9144:	48 8d bc 24 a0 07 00 	lea    0x7a0(%rsp),%rdi
    914b:	00 
    914c:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    9153:	00 
    9154:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    915b:	33 f3 bf 
    915e:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    9165:	00 
    9166:	e8 c5 b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    916b:	48 8b 15 c6 69 01 00 	mov    0x169c6(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9172:	49 89 c5             	mov    %rax,%r13
    9175:	48 2b 05 94 69 01 00 	sub    0x16994(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    917c:	48 c1 e2 10          	shl    $0x10,%rdx
    9180:	48 39 d0             	cmp    %rdx,%rax
    9183:	73 59                	jae    91de <f0+0x1f9e>
    9185:	48 89 c2             	mov    %rax,%rdx
    9188:	48 c1 ea 10          	shr    $0x10,%rdx
    918c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9190:	48 8b 15 c1 69 01 00 	mov    0x169c1(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9197:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    919b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    919f:	4d 85 e4             	test   %r12,%r12
    91a2:	74 3a                	je     91de <f0+0x1f9e>
    91a4:	0f b6 0a             	movzbl (%rdx),%ecx
    91a7:	80 f9 02             	cmp    $0x2,%cl
    91aa:	0f 84 a0 08 00 00    	je     9a50 <f0+0x2810>
    91b0:	80 f9 01             	cmp    $0x1,%cl
    91b3:	75 29                	jne    91de <f0+0x1f9e>
    91b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91b8:	0f b7 c0             	movzwl %ax,%eax
    91bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91be:	48 0f af c1          	imul   %rcx,%rax
    91c2:	48 c1 e8 20          	shr    $0x20,%rax
    91c6:	48 39 d0             	cmp    %rdx,%rax
    91c9:	73 13                	jae    91de <f0+0x1f9e>
    91cb:	49 01 c4             	add    %rax,%r12
    91ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    91d3:	0f 84 4e 0a 00 00    	je     9c27 <f0+0x29e7>
    91d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    91de:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
    91e5:	00 
    91e6:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    91ed:	00 
    91ee:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    91f5:	00 f0 3f 
    91f8:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    91ff:	00 
    9200:	e8 2b b7 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9205:	48 8b 15 2c 69 01 00 	mov    0x1692c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    920c:	49 89 c5             	mov    %rax,%r13
    920f:	48 2b 05 fa 68 01 00 	sub    0x168fa(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9216:	48 c1 e2 10          	shl    $0x10,%rdx
    921a:	48 39 d0             	cmp    %rdx,%rax
    921d:	73 59                	jae    9278 <f0+0x2038>
    921f:	48 89 c2             	mov    %rax,%rdx
    9222:	48 c1 ea 10          	shr    $0x10,%rdx
    9226:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    922a:	48 8b 15 27 69 01 00 	mov    0x16927(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9231:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9235:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9239:	4d 85 e4             	test   %r12,%r12
    923c:	74 3a                	je     9278 <f0+0x2038>
    923e:	0f b6 0a             	movzbl (%rdx),%ecx
    9241:	80 f9 02             	cmp    $0x2,%cl
    9244:	0f 84 f6 07 00 00    	je     9a40 <f0+0x2800>
    924a:	80 f9 01             	cmp    $0x1,%cl
    924d:	75 29                	jne    9278 <f0+0x2038>
    924f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9252:	0f b7 c0             	movzwl %ax,%eax
    9255:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9258:	48 0f af c1          	imul   %rcx,%rax
    925c:	48 c1 e8 20          	shr    $0x20,%rax
    9260:	48 39 d0             	cmp    %rdx,%rax
    9263:	73 13                	jae    9278 <f0+0x2038>
    9265:	49 01 c4             	add    %rax,%r12
    9268:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    926d:	0f 84 c1 09 00 00    	je     9c34 <f0+0x29f4>
    9273:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9278:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
    927f:	00 
    9280:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    9287:	00 
    9288:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    928f:	33 f3 bf 
    9292:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    9299:	00 
    929a:	e8 91 b6 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    929f:	48 8b 15 92 68 01 00 	mov    0x16892(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    92a6:	49 89 c5             	mov    %rax,%r13
    92a9:	48 2b 05 60 68 01 00 	sub    0x16860(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    92b0:	48 c1 e2 10          	shl    $0x10,%rdx
    92b4:	48 39 d0             	cmp    %rdx,%rax
    92b7:	73 59                	jae    9312 <f0+0x20d2>
    92b9:	48 89 c2             	mov    %rax,%rdx
    92bc:	48 c1 ea 10          	shr    $0x10,%rdx
    92c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92c4:	48 8b 15 8d 68 01 00 	mov    0x1688d(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    92cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    92d3:	4d 85 e4             	test   %r12,%r12
    92d6:	74 3a                	je     9312 <f0+0x20d2>
    92d8:	0f b6 0a             	movzbl (%rdx),%ecx
    92db:	80 f9 02             	cmp    $0x2,%cl
    92de:	0f 84 4c 07 00 00    	je     9a30 <f0+0x27f0>
    92e4:	80 f9 01             	cmp    $0x1,%cl
    92e7:	75 29                	jne    9312 <f0+0x20d2>
    92e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92ec:	0f b7 c0             	movzwl %ax,%eax
    92ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92f2:	48 0f af c1          	imul   %rcx,%rax
    92f6:	48 c1 e8 20          	shr    $0x20,%rax
    92fa:	48 39 d0             	cmp    %rdx,%rax
    92fd:	73 13                	jae    9312 <f0+0x20d2>
    92ff:	49 01 c4             	add    %rax,%r12
    9302:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9307:	0f 84 34 09 00 00    	je     9c41 <f0+0x2a01>
    930d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9312:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
    9319:	00 
    931a:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    9321:	00 
    9322:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9329:	00 f0 3f 
    932c:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9333:	00 
    9334:	e8 f7 b5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9339:	48 8b 15 f8 67 01 00 	mov    0x167f8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9340:	49 89 c5             	mov    %rax,%r13
    9343:	48 2b 05 c6 67 01 00 	sub    0x167c6(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    934a:	48 c1 e2 10          	shl    $0x10,%rdx
    934e:	48 39 d0             	cmp    %rdx,%rax
    9351:	73 59                	jae    93ac <f0+0x216c>
    9353:	48 89 c2             	mov    %rax,%rdx
    9356:	48 c1 ea 10          	shr    $0x10,%rdx
    935a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    935e:	48 8b 15 f3 67 01 00 	mov    0x167f3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9365:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9369:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    936d:	4d 85 e4             	test   %r12,%r12
    9370:	74 3a                	je     93ac <f0+0x216c>
    9372:	0f b6 0a             	movzbl (%rdx),%ecx
    9375:	80 f9 02             	cmp    $0x2,%cl
    9378:	0f 84 a2 06 00 00    	je     9a20 <f0+0x27e0>
    937e:	80 f9 01             	cmp    $0x1,%cl
    9381:	75 29                	jne    93ac <f0+0x216c>
    9383:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9386:	0f b7 c0             	movzwl %ax,%eax
    9389:	8b 52 1c             	mov    0x1c(%rdx),%edx
    938c:	48 0f af c1          	imul   %rcx,%rax
    9390:	48 c1 e8 20          	shr    $0x20,%rax
    9394:	48 39 d0             	cmp    %rdx,%rax
    9397:	73 13                	jae    93ac <f0+0x216c>
    9399:	49 01 c4             	add    %rax,%r12
    939c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    93a1:	0f 84 a7 08 00 00    	je     9c4e <f0+0x2a0e>
    93a7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    93ac:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
    93b3:	00 
    93b4:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    93bb:	00 
    93bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    93c3:	33 f3 bf 
    93c6:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    93cd:	00 
    93ce:	e8 5d b5 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    93d3:	48 8b 15 5e 67 01 00 	mov    0x1675e(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    93da:	49 89 c5             	mov    %rax,%r13
    93dd:	48 2b 05 2c 67 01 00 	sub    0x1672c(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    93e4:	48 c1 e2 10          	shl    $0x10,%rdx
    93e8:	48 39 d0             	cmp    %rdx,%rax
    93eb:	73 59                	jae    9446 <f0+0x2206>
    93ed:	48 89 c2             	mov    %rax,%rdx
    93f0:	48 c1 ea 10          	shr    $0x10,%rdx
    93f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93f8:	48 8b 15 59 67 01 00 	mov    0x16759(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    93ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9403:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9407:	4d 85 e4             	test   %r12,%r12
    940a:	74 3a                	je     9446 <f0+0x2206>
    940c:	0f b6 0a             	movzbl (%rdx),%ecx
    940f:	80 f9 02             	cmp    $0x2,%cl
    9412:	0f 84 f8 05 00 00    	je     9a10 <f0+0x27d0>
    9418:	80 f9 01             	cmp    $0x1,%cl
    941b:	75 29                	jne    9446 <f0+0x2206>
    941d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9420:	0f b7 c0             	movzwl %ax,%eax
    9423:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9426:	48 0f af c1          	imul   %rcx,%rax
    942a:	48 c1 e8 20          	shr    $0x20,%rax
    942e:	48 39 d0             	cmp    %rdx,%rax
    9431:	73 13                	jae    9446 <f0+0x2206>
    9433:	49 01 c4             	add    %rax,%r12
    9436:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    943b:	0f 84 1a 08 00 00    	je     9c5b <f0+0x2a1b>
    9441:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9446:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
    944d:	00 
    944e:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9455:	00 
    9456:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    945d:	00 f0 3f 
    9460:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9467:	00 
    9468:	e8 c3 b4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    946d:	48 8b 15 c4 66 01 00 	mov    0x166c4(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9474:	49 89 c5             	mov    %rax,%r13
    9477:	48 2b 05 92 66 01 00 	sub    0x16692(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    947e:	48 c1 e2 10          	shl    $0x10,%rdx
    9482:	48 39 d0             	cmp    %rdx,%rax
    9485:	73 59                	jae    94e0 <f0+0x22a0>
    9487:	48 89 c2             	mov    %rax,%rdx
    948a:	48 c1 ea 10          	shr    $0x10,%rdx
    948e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9492:	48 8b 15 bf 66 01 00 	mov    0x166bf(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9499:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    949d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    94a1:	4d 85 e4             	test   %r12,%r12
    94a4:	74 3a                	je     94e0 <f0+0x22a0>
    94a6:	0f b6 0a             	movzbl (%rdx),%ecx
    94a9:	80 f9 02             	cmp    $0x2,%cl
    94ac:	0f 84 4e 05 00 00    	je     9a00 <f0+0x27c0>
    94b2:	80 f9 01             	cmp    $0x1,%cl
    94b5:	75 29                	jne    94e0 <f0+0x22a0>
    94b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94ba:	0f b7 c0             	movzwl %ax,%eax
    94bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94c0:	48 0f af c1          	imul   %rcx,%rax
    94c4:	48 c1 e8 20          	shr    $0x20,%rax
    94c8:	48 39 d0             	cmp    %rdx,%rax
    94cb:	73 13                	jae    94e0 <f0+0x22a0>
    94cd:	49 01 c4             	add    %rax,%r12
    94d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    94d5:	0f 84 8d 07 00 00    	je     9c68 <f0+0x2a28>
    94db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    94e0:	48 8d bc 24 00 08 00 	lea    0x800(%rsp),%rdi
    94e7:	00 
    94e8:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    94ef:	00 
    94f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    94f7:	33 f3 bf 
    94fa:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    9501:	00 
    9502:	e8 29 b4 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    9507:	48 8b 15 2a 66 01 00 	mov    0x1662a(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    950e:	49 89 c5             	mov    %rax,%r13
    9511:	48 2b 05 f8 65 01 00 	sub    0x165f8(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    9518:	48 c1 e2 10          	shl    $0x10,%rdx
    951c:	48 39 d0             	cmp    %rdx,%rax
    951f:	73 59                	jae    957a <f0+0x233a>
    9521:	48 89 c2             	mov    %rax,%rdx
    9524:	48 c1 ea 10          	shr    $0x10,%rdx
    9528:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    952c:	48 8b 15 25 66 01 00 	mov    0x16625(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9533:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9537:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    953b:	4d 85 e4             	test   %r12,%r12
    953e:	74 3a                	je     957a <f0+0x233a>
    9540:	0f b6 0a             	movzbl (%rdx),%ecx
    9543:	80 f9 02             	cmp    $0x2,%cl
    9546:	0f 84 a4 04 00 00    	je     99f0 <f0+0x27b0>
    954c:	80 f9 01             	cmp    $0x1,%cl
    954f:	75 29                	jne    957a <f0+0x233a>
    9551:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9554:	0f b7 c0             	movzwl %ax,%eax
    9557:	8b 52 1c             	mov    0x1c(%rdx),%edx
    955a:	48 0f af c1          	imul   %rcx,%rax
    955e:	48 c1 e8 20          	shr    $0x20,%rax
    9562:	48 39 d0             	cmp    %rdx,%rax
    9565:	73 13                	jae    957a <f0+0x233a>
    9567:	49 01 c4             	add    %rax,%r12
    956a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    956f:	0f 84 00 07 00 00    	je     9c75 <f0+0x2a35>
    9575:	41 c6 04 24 01       	movb   $0x1,(%r12)
    957a:	48 8d bc 24 10 08 00 	lea    0x810(%rsp),%rdi
    9581:	00 
    9582:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    9589:	00 
    958a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9591:	00 f0 3f 
    9594:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    959b:	00 
    959c:	e8 8f b3 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    95a1:	48 8b 15 90 65 01 00 	mov    0x16590(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    95a8:	49 89 c5             	mov    %rax,%r13
    95ab:	48 2b 05 5e 65 01 00 	sub    0x1655e(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    95b2:	48 c1 e2 10          	shl    $0x10,%rdx
    95b6:	48 39 d0             	cmp    %rdx,%rax
    95b9:	73 59                	jae    9614 <f0+0x23d4>
    95bb:	48 89 c2             	mov    %rax,%rdx
    95be:	48 c1 ea 10          	shr    $0x10,%rdx
    95c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95c6:	48 8b 15 8b 65 01 00 	mov    0x1658b(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    95cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95d1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    95d5:	4d 85 e4             	test   %r12,%r12
    95d8:	74 3a                	je     9614 <f0+0x23d4>
    95da:	0f b6 0a             	movzbl (%rdx),%ecx
    95dd:	80 f9 02             	cmp    $0x2,%cl
    95e0:	0f 84 fa 03 00 00    	je     99e0 <f0+0x27a0>
    95e6:	80 f9 01             	cmp    $0x1,%cl
    95e9:	75 29                	jne    9614 <f0+0x23d4>
    95eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95ee:	0f b7 c0             	movzwl %ax,%eax
    95f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95f4:	48 0f af c1          	imul   %rcx,%rax
    95f8:	48 c1 e8 20          	shr    $0x20,%rax
    95fc:	48 39 d0             	cmp    %rdx,%rax
    95ff:	73 13                	jae    9614 <f0+0x23d4>
    9601:	49 01 c4             	add    %rax,%r12
    9604:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9609:	0f 84 73 06 00 00    	je     9c82 <f0+0x2a42>
    960f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9614:	48 8d bc 24 20 08 00 	lea    0x820(%rsp),%rdi
    961b:	00 
    961c:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    9623:	00 
    9624:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    962b:	33 f3 bf 
    962e:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9635:	00 
    9636:	e8 f5 b2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    963b:	48 8b 15 f6 64 01 00 	mov    0x164f6(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9642:	49 89 c5             	mov    %rax,%r13
    9645:	48 2b 05 c4 64 01 00 	sub    0x164c4(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    964c:	48 c1 e2 10          	shl    $0x10,%rdx
    9650:	48 39 d0             	cmp    %rdx,%rax
    9653:	73 59                	jae    96ae <f0+0x246e>
    9655:	48 89 c2             	mov    %rax,%rdx
    9658:	48 c1 ea 10          	shr    $0x10,%rdx
    965c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9660:	48 8b 15 f1 64 01 00 	mov    0x164f1(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9667:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    966b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    966f:	4d 85 e4             	test   %r12,%r12
    9672:	74 3a                	je     96ae <f0+0x246e>
    9674:	0f b6 0a             	movzbl (%rdx),%ecx
    9677:	80 f9 02             	cmp    $0x2,%cl
    967a:	0f 84 50 03 00 00    	je     99d0 <f0+0x2790>
    9680:	80 f9 01             	cmp    $0x1,%cl
    9683:	75 29                	jne    96ae <f0+0x246e>
    9685:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9688:	0f b7 c0             	movzwl %ax,%eax
    968b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    968e:	48 0f af c1          	imul   %rcx,%rax
    9692:	48 c1 e8 20          	shr    $0x20,%rax
    9696:	48 39 d0             	cmp    %rdx,%rax
    9699:	73 13                	jae    96ae <f0+0x246e>
    969b:	49 01 c4             	add    %rax,%r12
    969e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    96a3:	0f 84 e6 05 00 00    	je     9c8f <f0+0x2a4f>
    96a9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    96ae:	48 8d bc 24 30 08 00 	lea    0x830(%rsp),%rdi
    96b5:	00 
    96b6:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    96bd:	00 
    96be:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    96c5:	00 f0 3f 
    96c8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    96cf:	00 
    96d0:	e8 5b b2 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    96d5:	48 8b 15 5c 64 01 00 	mov    0x1645c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    96dc:	49 89 c5             	mov    %rax,%r13
    96df:	48 2b 05 2a 64 01 00 	sub    0x1642a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    96e6:	48 c1 e2 10          	shl    $0x10,%rdx
    96ea:	48 39 d0             	cmp    %rdx,%rax
    96ed:	73 59                	jae    9748 <f0+0x2508>
    96ef:	48 89 c2             	mov    %rax,%rdx
    96f2:	48 c1 ea 10          	shr    $0x10,%rdx
    96f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96fa:	48 8b 15 57 64 01 00 	mov    0x16457(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9701:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9705:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9709:	4d 85 e4             	test   %r12,%r12
    970c:	74 3a                	je     9748 <f0+0x2508>
    970e:	0f b6 0a             	movzbl (%rdx),%ecx
    9711:	80 f9 02             	cmp    $0x2,%cl
    9714:	0f 84 a6 02 00 00    	je     99c0 <f0+0x2780>
    971a:	80 f9 01             	cmp    $0x1,%cl
    971d:	75 29                	jne    9748 <f0+0x2508>
    971f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9722:	0f b7 c0             	movzwl %ax,%eax
    9725:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9728:	48 0f af c1          	imul   %rcx,%rax
    972c:	48 c1 e8 20          	shr    $0x20,%rax
    9730:	48 39 d0             	cmp    %rdx,%rax
    9733:	73 13                	jae    9748 <f0+0x2508>
    9735:	49 01 c4             	add    %rax,%r12
    9738:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    973d:	0f 84 59 05 00 00    	je     9c9c <f0+0x2a5c>
    9743:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9748:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    974f:	33 f3 bf 
    9752:	48 89 ef             	mov    %rbp,%rdi
    9755:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    975c:	00 
    975d:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    9764:	00 
    9765:	e8 c6 b1 ff ff       	call   4930 <fwp_data.part.0.constprop.0>
    976a:	48 8b 15 c7 63 01 00 	mov    0x163c7(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9771:	48 89 c5             	mov    %rax,%rbp
    9774:	48 2b 05 95 63 01 00 	sub    0x16395(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    977b:	48 c1 e2 10          	shl    $0x10,%rdx
    977f:	48 39 d0             	cmp    %rdx,%rax
    9782:	73 59                	jae    97dd <f0+0x259d>
    9784:	48 89 c2             	mov    %rax,%rdx
    9787:	48 c1 ea 10          	shr    $0x10,%rdx
    978b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    978f:	48 8b 15 c2 63 01 00 	mov    0x163c2(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9796:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    979a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    979e:	4d 85 e4             	test   %r12,%r12
    97a1:	74 3a                	je     97dd <f0+0x259d>
    97a3:	0f b6 0a             	movzbl (%rdx),%ecx
    97a6:	80 f9 02             	cmp    $0x2,%cl
    97a9:	0f 84 01 02 00 00    	je     99b0 <f0+0x2770>
    97af:	80 f9 01             	cmp    $0x1,%cl
    97b2:	75 29                	jne    97dd <f0+0x259d>
    97b4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97b7:	0f b7 c0             	movzwl %ax,%eax
    97ba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97bd:	48 0f af c1          	imul   %rcx,%rax
    97c1:	48 c1 e8 20          	shr    $0x20,%rax
    97c5:	48 39 d0             	cmp    %rdx,%rax
    97c8:	73 13                	jae    97dd <f0+0x259d>
    97ca:	49 01 c4             	add    %rax,%r12
    97cd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    97d2:	0f 84 d6 02 00 00    	je     9aae <f0+0x286e>
    97d8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    97dd:	48 89 de             	mov    %rbx,%rsi
    97e0:	48 89 ef             	mov    %rbp,%rdi
    97e3:	e8 c8 ca ff ff       	call   62b0 <fwp_hof0.constprop.0>
    97e8:	48 89 ef             	mov    %rbp,%rdi
    97eb:	e8 f0 b7 ff ff       	call   4fe0 <fwp_drop0>
    97f0:	48 89 df             	mov    %rbx,%rdi
    97f3:	e8 e8 b7 ff ff       	call   4fe0 <fwp_drop0>
    97f8:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    97ff:	00 
    9800:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9807:	00 00 
    9809:	0f 85 9a 04 00 00    	jne    9ca9 <f0+0x2a69>
    980f:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    9816:	31 c0                	xor    %eax,%eax
    9818:	5b                   	pop    %rbx
    9819:	5d                   	pop    %rbp
    981a:	41 5c                	pop    %r12
    981c:	41 5d                	pop    %r13
    981e:	41 5e                	pop    %r14
    9820:	c3                   	ret
    9821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9828:	4c 89 ef             	mov    %r13,%rdi
    982b:	e8 a0 a6 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9830:	e9 c4 da ff ff       	jmp    72f9 <f0+0xb9>
    9835:	0f 1f 00             	nopl   (%rax)
    9838:	66 85 c0             	test   %ax,%ax
    983b:	0f 85 01 f6 ff ff    	jne    8e42 <f0+0x1c02>
    9841:	e9 ec f5 ff ff       	jmp    8e32 <f0+0x1bf2>
    9846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    984d:	00 00 00 
    9850:	66 85 c0             	test   %ax,%ax
    9853:	0f 85 4f f5 ff ff    	jne    8da8 <f0+0x1b68>
    9859:	e9 3a f5 ff ff       	jmp    8d98 <f0+0x1b58>
    985e:	66 90                	xchg   %ax,%ax
    9860:	66 85 c0             	test   %ax,%ax
    9863:	0f 85 a5 f4 ff ff    	jne    8d0e <f0+0x1ace>
    9869:	e9 90 f4 ff ff       	jmp    8cfe <f0+0x1abe>
    986e:	66 90                	xchg   %ax,%ax
    9870:	66 85 c0             	test   %ax,%ax
    9873:	0f 85 fb f3 ff ff    	jne    8c74 <f0+0x1a34>
    9879:	e9 e6 f3 ff ff       	jmp    8c64 <f0+0x1a24>
    987e:	66 90                	xchg   %ax,%ax
    9880:	66 85 c0             	test   %ax,%ax
    9883:	0f 85 51 f3 ff ff    	jne    8bda <f0+0x199a>
    9889:	e9 3c f3 ff ff       	jmp    8bca <f0+0x198a>
    988e:	66 90                	xchg   %ax,%ax
    9890:	66 85 c0             	test   %ax,%ax
    9893:	0f 85 a7 f2 ff ff    	jne    8b40 <f0+0x1900>
    9899:	e9 92 f2 ff ff       	jmp    8b30 <f0+0x18f0>
    989e:	66 90                	xchg   %ax,%ax
    98a0:	66 85 c0             	test   %ax,%ax
    98a3:	0f 85 fd f1 ff ff    	jne    8aa6 <f0+0x1866>
    98a9:	e9 e8 f1 ff ff       	jmp    8a96 <f0+0x1856>
    98ae:	66 90                	xchg   %ax,%ax
    98b0:	66 85 c0             	test   %ax,%ax
    98b3:	0f 85 53 f1 ff ff    	jne    8a0c <f0+0x17cc>
    98b9:	e9 3e f1 ff ff       	jmp    89fc <f0+0x17bc>
    98be:	66 90                	xchg   %ax,%ax
    98c0:	66 85 c0             	test   %ax,%ax
    98c3:	0f 85 6e dc ff ff    	jne    7537 <f0+0x2f7>
    98c9:	e9 59 dc ff ff       	jmp    7527 <f0+0x2e7>
    98ce:	66 90                	xchg   %ax,%ax
    98d0:	66 85 c0             	test   %ax,%ax
    98d3:	0f 85 cd db ff ff    	jne    74a6 <f0+0x266>
    98d9:	e9 b8 db ff ff       	jmp    7496 <f0+0x256>
    98de:	66 90                	xchg   %ax,%ax
    98e0:	66 85 c0             	test   %ax,%ax
    98e3:	0f 85 2c db ff ff    	jne    7415 <f0+0x1d5>
    98e9:	e9 17 db ff ff       	jmp    7405 <f0+0x1c5>
    98ee:	66 90                	xchg   %ax,%ax
    98f0:	66 85 c0             	test   %ax,%ax
    98f3:	0f 85 a9 eb ff ff    	jne    84a2 <f0+0x1262>
    98f9:	e9 94 eb ff ff       	jmp    8492 <f0+0x1252>
    98fe:	66 90                	xchg   %ax,%ax
    9900:	66 85 c0             	test   %ax,%ax
    9903:	0f 85 ff ea ff ff    	jne    8408 <f0+0x11c8>
    9909:	e9 ea ea ff ff       	jmp    83f8 <f0+0x11b8>
    990e:	66 90                	xchg   %ax,%ax
    9910:	66 85 c0             	test   %ax,%ax
    9913:	0f 85 55 ea ff ff    	jne    836e <f0+0x112e>
    9919:	e9 40 ea ff ff       	jmp    835e <f0+0x111e>
    991e:	66 90                	xchg   %ax,%ax
    9920:	66 85 c0             	test   %ax,%ax
    9923:	0f 85 9f dc ff ff    	jne    75c8 <f0+0x388>
    9929:	e9 8a dc ff ff       	jmp    75b8 <f0+0x378>
    992e:	66 90                	xchg   %ax,%ax
    9930:	66 85 c0             	test   %ax,%ax
    9933:	0f 85 39 f0 ff ff    	jne    8972 <f0+0x1732>
    9939:	e9 24 f0 ff ff       	jmp    8962 <f0+0x1722>
    993e:	66 90                	xchg   %ax,%ax
    9940:	66 85 c0             	test   %ax,%ax
    9943:	0f 85 8f ef ff ff    	jne    88d8 <f0+0x1698>
    9949:	e9 7a ef ff ff       	jmp    88c8 <f0+0x1688>
    994e:	66 90                	xchg   %ax,%ax
    9950:	66 85 c0             	test   %ax,%ax
    9953:	0f 85 e5 ee ff ff    	jne    883e <f0+0x15fe>
    9959:	e9 d0 ee ff ff       	jmp    882e <f0+0x15ee>
    995e:	66 90                	xchg   %ax,%ax
    9960:	66 85 c0             	test   %ax,%ax
    9963:	0f 85 3b ee ff ff    	jne    87a4 <f0+0x1564>
    9969:	e9 26 ee ff ff       	jmp    8794 <f0+0x1554>
    996e:	66 90                	xchg   %ax,%ax
    9970:	66 85 c0             	test   %ax,%ax
    9973:	0f 85 91 ed ff ff    	jne    870a <f0+0x14ca>
    9979:	e9 7c ed ff ff       	jmp    86fa <f0+0x14ba>
    997e:	66 90                	xchg   %ax,%ax
    9980:	66 85 c0             	test   %ax,%ax
    9983:	0f 85 e7 ec ff ff    	jne    8670 <f0+0x1430>
    9989:	e9 d2 ec ff ff       	jmp    8660 <f0+0x1420>
    998e:	66 90                	xchg   %ax,%ax
    9990:	66 85 c0             	test   %ax,%ax
    9993:	0f 85 3d ec ff ff    	jne    85d6 <f0+0x1396>
    9999:	e9 28 ec ff ff       	jmp    85c6 <f0+0x1386>
    999e:	66 90                	xchg   %ax,%ax
    99a0:	66 85 c0             	test   %ax,%ax
    99a3:	0f 85 93 eb ff ff    	jne    853c <f0+0x12fc>
    99a9:	e9 7e eb ff ff       	jmp    852c <f0+0x12ec>
    99ae:	66 90                	xchg   %ax,%ax
    99b0:	66 85 c0             	test   %ax,%ax
    99b3:	0f 85 24 fe ff ff    	jne    97dd <f0+0x259d>
    99b9:	e9 0f fe ff ff       	jmp    97cd <f0+0x258d>
    99be:	66 90                	xchg   %ax,%ax
    99c0:	66 85 c0             	test   %ax,%ax
    99c3:	0f 85 7f fd ff ff    	jne    9748 <f0+0x2508>
    99c9:	e9 6a fd ff ff       	jmp    9738 <f0+0x24f8>
    99ce:	66 90                	xchg   %ax,%ax
    99d0:	66 85 c0             	test   %ax,%ax
    99d3:	0f 85 d5 fc ff ff    	jne    96ae <f0+0x246e>
    99d9:	e9 c0 fc ff ff       	jmp    969e <f0+0x245e>
    99de:	66 90                	xchg   %ax,%ax
    99e0:	66 85 c0             	test   %ax,%ax
    99e3:	0f 85 2b fc ff ff    	jne    9614 <f0+0x23d4>
    99e9:	e9 16 fc ff ff       	jmp    9604 <f0+0x23c4>
    99ee:	66 90                	xchg   %ax,%ax
    99f0:	66 85 c0             	test   %ax,%ax
    99f3:	0f 85 81 fb ff ff    	jne    957a <f0+0x233a>
    99f9:	e9 6c fb ff ff       	jmp    956a <f0+0x232a>
    99fe:	66 90                	xchg   %ax,%ax
    9a00:	66 85 c0             	test   %ax,%ax
    9a03:	0f 85 d7 fa ff ff    	jne    94e0 <f0+0x22a0>
    9a09:	e9 c2 fa ff ff       	jmp    94d0 <f0+0x2290>
    9a0e:	66 90                	xchg   %ax,%ax
    9a10:	66 85 c0             	test   %ax,%ax
    9a13:	0f 85 2d fa ff ff    	jne    9446 <f0+0x2206>
    9a19:	e9 18 fa ff ff       	jmp    9436 <f0+0x21f6>
    9a1e:	66 90                	xchg   %ax,%ax
    9a20:	66 85 c0             	test   %ax,%ax
    9a23:	0f 85 83 f9 ff ff    	jne    93ac <f0+0x216c>
    9a29:	e9 6e f9 ff ff       	jmp    939c <f0+0x215c>
    9a2e:	66 90                	xchg   %ax,%ax
    9a30:	66 85 c0             	test   %ax,%ax
    9a33:	0f 85 d9 f8 ff ff    	jne    9312 <f0+0x20d2>
    9a39:	e9 c4 f8 ff ff       	jmp    9302 <f0+0x20c2>
    9a3e:	66 90                	xchg   %ax,%ax
    9a40:	66 85 c0             	test   %ax,%ax
    9a43:	0f 85 2f f8 ff ff    	jne    9278 <f0+0x2038>
    9a49:	e9 1a f8 ff ff       	jmp    9268 <f0+0x2028>
    9a4e:	66 90                	xchg   %ax,%ax
    9a50:	66 85 c0             	test   %ax,%ax
    9a53:	0f 85 85 f7 ff ff    	jne    91de <f0+0x1f9e>
    9a59:	e9 70 f7 ff ff       	jmp    91ce <f0+0x1f8e>
    9a5e:	66 90                	xchg   %ax,%ax
    9a60:	66 85 c0             	test   %ax,%ax
    9a63:	0f 85 db f6 ff ff    	jne    9144 <f0+0x1f04>
    9a69:	e9 c6 f6 ff ff       	jmp    9134 <f0+0x1ef4>
    9a6e:	66 90                	xchg   %ax,%ax
    9a70:	66 85 c0             	test   %ax,%ax
    9a73:	0f 85 31 f6 ff ff    	jne    90aa <f0+0x1e6a>
    9a79:	e9 1c f6 ff ff       	jmp    909a <f0+0x1e5a>
    9a7e:	66 90                	xchg   %ax,%ax
    9a80:	66 85 c0             	test   %ax,%ax
    9a83:	0f 85 87 f5 ff ff    	jne    9010 <f0+0x1dd0>
    9a89:	e9 72 f5 ff ff       	jmp    9000 <f0+0x1dc0>
    9a8e:	66 90                	xchg   %ax,%ax
    9a90:	66 85 c0             	test   %ax,%ax
    9a93:	0f 85 dd f4 ff ff    	jne    8f76 <f0+0x1d36>
    9a99:	e9 c8 f4 ff ff       	jmp    8f66 <f0+0x1d26>
    9a9e:	66 90                	xchg   %ax,%ax
    9aa0:	66 85 c0             	test   %ax,%ax
    9aa3:	0f 85 33 f4 ff ff    	jne    8edc <f0+0x1c9c>
    9aa9:	e9 1e f4 ff ff       	jmp    8ecc <f0+0x1c8c>
    9aae:	4c 89 e7             	mov    %r12,%rdi
    9ab1:	e8 1a a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ab6:	e9 1d fd ff ff       	jmp    97d8 <f0+0x2598>
    9abb:	4c 89 e7             	mov    %r12,%rdi
    9abe:	e8 0d a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ac3:	e9 48 d9 ff ff       	jmp    7410 <f0+0x1d0>
    9ac8:	4c 89 e7             	mov    %r12,%rdi
    9acb:	e8 00 a4 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ad0:	e9 cc d9 ff ff       	jmp    74a1 <f0+0x261>
    9ad5:	4c 89 e7             	mov    %r12,%rdi
    9ad8:	e8 f3 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9add:	e9 50 da ff ff       	jmp    7532 <f0+0x2f2>
    9ae2:	4c 89 e7             	mov    %r12,%rdi
    9ae5:	e8 e6 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9aea:	e9 d4 da ff ff       	jmp    75c3 <f0+0x383>
    9aef:	4c 89 e7             	mov    %r12,%rdi
    9af2:	e8 d9 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9af7:	e9 6d e8 ff ff       	jmp    8369 <f0+0x1129>
    9afc:	4c 89 e7             	mov    %r12,%rdi
    9aff:	e8 cc a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b04:	e9 fa e8 ff ff       	jmp    8403 <f0+0x11c3>
    9b09:	4c 89 e7             	mov    %r12,%rdi
    9b0c:	e8 bf a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b11:	e9 87 e9 ff ff       	jmp    849d <f0+0x125d>
    9b16:	4c 89 e7             	mov    %r12,%rdi
    9b19:	e8 b2 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b1e:	e9 14 ea ff ff       	jmp    8537 <f0+0x12f7>
    9b23:	4c 89 e7             	mov    %r12,%rdi
    9b26:	e8 a5 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b2b:	e9 a1 ea ff ff       	jmp    85d1 <f0+0x1391>
    9b30:	4c 89 e7             	mov    %r12,%rdi
    9b33:	e8 98 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b38:	e9 2e eb ff ff       	jmp    866b <f0+0x142b>
    9b3d:	4c 89 e7             	mov    %r12,%rdi
    9b40:	e8 8b a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b45:	e9 bb eb ff ff       	jmp    8705 <f0+0x14c5>
    9b4a:	4c 89 e7             	mov    %r12,%rdi
    9b4d:	e8 7e a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b52:	e9 48 ec ff ff       	jmp    879f <f0+0x155f>
    9b57:	4c 89 e7             	mov    %r12,%rdi
    9b5a:	e8 71 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b5f:	e9 d5 ec ff ff       	jmp    8839 <f0+0x15f9>
    9b64:	4c 89 e7             	mov    %r12,%rdi
    9b67:	e8 64 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b6c:	e9 62 ed ff ff       	jmp    88d3 <f0+0x1693>
    9b71:	4c 89 e7             	mov    %r12,%rdi
    9b74:	e8 57 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b79:	e9 ef ed ff ff       	jmp    896d <f0+0x172d>
    9b7e:	4c 89 e7             	mov    %r12,%rdi
    9b81:	e8 4a a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b86:	e9 7c ee ff ff       	jmp    8a07 <f0+0x17c7>
    9b8b:	4c 89 e7             	mov    %r12,%rdi
    9b8e:	e8 3d a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9b93:	e9 09 ef ff ff       	jmp    8aa1 <f0+0x1861>
    9b98:	4c 89 e7             	mov    %r12,%rdi
    9b9b:	e8 30 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ba0:	e9 96 ef ff ff       	jmp    8b3b <f0+0x18fb>
    9ba5:	4c 89 e7             	mov    %r12,%rdi
    9ba8:	e8 23 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bad:	e9 23 f0 ff ff       	jmp    8bd5 <f0+0x1995>
    9bb2:	4c 89 e7             	mov    %r12,%rdi
    9bb5:	e8 16 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bba:	e9 b0 f0 ff ff       	jmp    8c6f <f0+0x1a2f>
    9bbf:	4c 89 e7             	mov    %r12,%rdi
    9bc2:	e8 09 a3 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bc7:	e9 3d f1 ff ff       	jmp    8d09 <f0+0x1ac9>
    9bcc:	4c 89 e7             	mov    %r12,%rdi
    9bcf:	e8 fc a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bd4:	e9 ca f1 ff ff       	jmp    8da3 <f0+0x1b63>
    9bd9:	4c 89 e7             	mov    %r12,%rdi
    9bdc:	e8 ef a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9be1:	e9 57 f2 ff ff       	jmp    8e3d <f0+0x1bfd>
    9be6:	4c 89 e7             	mov    %r12,%rdi
    9be9:	e8 e2 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bee:	e9 e4 f2 ff ff       	jmp    8ed7 <f0+0x1c97>
    9bf3:	4c 89 e7             	mov    %r12,%rdi
    9bf6:	e8 d5 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9bfb:	e9 71 f3 ff ff       	jmp    8f71 <f0+0x1d31>
    9c00:	4c 89 e7             	mov    %r12,%rdi
    9c03:	e8 c8 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c08:	e9 fe f3 ff ff       	jmp    900b <f0+0x1dcb>
    9c0d:	4c 89 e7             	mov    %r12,%rdi
    9c10:	e8 bb a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c15:	e9 8b f4 ff ff       	jmp    90a5 <f0+0x1e65>
    9c1a:	4c 89 e7             	mov    %r12,%rdi
    9c1d:	e8 ae a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c22:	e9 18 f5 ff ff       	jmp    913f <f0+0x1eff>
    9c27:	4c 89 e7             	mov    %r12,%rdi
    9c2a:	e8 a1 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c2f:	e9 a5 f5 ff ff       	jmp    91d9 <f0+0x1f99>
    9c34:	4c 89 e7             	mov    %r12,%rdi
    9c37:	e8 94 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c3c:	e9 32 f6 ff ff       	jmp    9273 <f0+0x2033>
    9c41:	4c 89 e7             	mov    %r12,%rdi
    9c44:	e8 87 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c49:	e9 bf f6 ff ff       	jmp    930d <f0+0x20cd>
    9c4e:	4c 89 e7             	mov    %r12,%rdi
    9c51:	e8 7a a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c56:	e9 4c f7 ff ff       	jmp    93a7 <f0+0x2167>
    9c5b:	4c 89 e7             	mov    %r12,%rdi
    9c5e:	e8 6d a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c63:	e9 d9 f7 ff ff       	jmp    9441 <f0+0x2201>
    9c68:	4c 89 e7             	mov    %r12,%rdi
    9c6b:	e8 60 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c70:	e9 66 f8 ff ff       	jmp    94db <f0+0x229b>
    9c75:	4c 89 e7             	mov    %r12,%rdi
    9c78:	e8 53 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c7d:	e9 f3 f8 ff ff       	jmp    9575 <f0+0x2335>
    9c82:	4c 89 e7             	mov    %r12,%rdi
    9c85:	e8 46 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c8a:	e9 80 f9 ff ff       	jmp    960f <f0+0x23cf>
    9c8f:	4c 89 e7             	mov    %r12,%rdi
    9c92:	e8 39 a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9c97:	e9 0d fa ff ff       	jmp    96a9 <f0+0x2469>
    9c9c:	4c 89 e7             	mov    %r12,%rdi
    9c9f:	e8 2c a2 ff ff       	call   3ed0 <fwp_rc_forget_slot>
    9ca4:	e9 9a fa ff ff       	jmp    9743 <f0+0x2503>
    9ca9:	e8 92 87 ff ff       	call   2440 <__stack_chk_fail@plt>
    9cae:	66 90                	xchg   %ax,%ax

0000000000009cb0 <fwp_main_thread>:
    9cb0:	f3 0f 1e fa          	endbr64
    9cb4:	41 54                	push   %r12
    9cb6:	55                   	push   %rbp
    9cb7:	53                   	push   %rbx
    9cb8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    9cbf:	8b 0d 3f 5e 01 00    	mov    0x15e3f(%rip),%ecx        # 1fb04 <fwp_heap+0x13a4>
    9cc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9ccc:	00 00 
    9cce:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    9cd5:	00 
    9cd6:	31 c0                	xor    %eax,%eax
    9cd8:	85 c9                	test   %ecx,%ecx
    9cda:	0f 84 18 07 00 00    	je     a3f8 <fwp_main_thread+0x748>
    9ce0:	8b 15 22 5e 01 00    	mov    0x15e22(%rip),%edx        # 1fb08 <fwp_heap+0x13a8>
    9ce6:	85 d2                	test   %edx,%edx
    9ce8:	0f 85 f2 06 00 00    	jne    a3e0 <fwp_main_thread+0x730>
    9cee:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    9cf3:	31 f6                	xor    %esi,%esi
    9cf5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    9cfa:	48 c7 05 eb 43 01 00 	movq   $0x40000000,0x143eb(%rip)        # 1e0f0 <fwp_main_stack_size>
    9d01:	00 00 00 40 
    9d05:	48 89 05 ec 43 01 00 	mov    %rax,0x143ec(%rip)        # 1e0f8 <fwp_main_stack_top>
    9d0c:	48 8d 05 cd 43 00 00 	lea    0x43cd(%rip),%rax        # e0e0 <alt.4>
    9d13:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9d18:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    9d1f:	01 00 
    9d21:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    9d28:	00 
    9d29:	e8 52 89 ff ff       	call   2680 <sigaltstack@plt>
    9d2e:	85 c0                	test   %eax,%eax
    9d30:	0f 85 03 07 00 00    	jne    a439 <fwp_main_thread+0x789>
    9d36:	31 c0                	xor    %eax,%eax
    9d38:	b9 12 00 00 00       	mov    $0x12,%ecx
    9d3d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9d42:	f3 48 ab             	rep stos %rax,(%rdi)
    9d45:	48 8d 05 b4 8e ff ff 	lea    -0x714c(%rip),%rax        # 2c00 <fwp_segv>
    9d4c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9d51:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    9d58:	04 00 00 08 
    9d5c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9d61:	e8 ea 87 ff ff       	call   2550 <sigemptyset@plt>
    9d66:	85 c0                	test   %eax,%eax
    9d68:	0f 85 cb 06 00 00    	jne    a439 <fwp_main_thread+0x789>
    9d6e:	31 d2                	xor    %edx,%edx
    9d70:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9d75:	bf 0b 00 00 00       	mov    $0xb,%edi
    9d7a:	e8 61 86 ff ff       	call   23e0 <sigaction@plt>
    9d7f:	85 c0                	test   %eax,%eax
    9d81:	0f 85 b2 06 00 00    	jne    a439 <fwp_main_thread+0x789>
    9d87:	31 d2                	xor    %edx,%edx
    9d89:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9d8e:	bf 07 00 00 00       	mov    $0x7,%edi
    9d93:	e8 48 86 ff ff       	call   23e0 <sigaction@plt>
    9d98:	85 c0                	test   %eax,%eax
    9d9a:	0f 85 99 06 00 00    	jne    a439 <fwp_main_thread+0x789>
    9da0:	48 8b 05 d9 5d 01 00 	mov    0x15dd9(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    9da7:	48 85 c0             	test   %rax,%rax
    9daa:	0f 88 10 06 00 00    	js     a3c0 <fwp_main_thread+0x710>
    9db0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9db4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9db9:	48 8d 3d 20 93 ff ff 	lea    -0x6ce0(%rip),%rdi        # 30e0 <ad_raw_report>
    9dc0:	f2 0f 11 05 38 66 01 	movsd  %xmm0,0x16638(%rip)        # 20400 <iteration_start_charge>
    9dc7:	00 
    9dc8:	c7 05 4e 66 01 00 01 	movl   $0x1,0x1664e(%rip)        # 20420 <iteration_active>
    9dcf:	00 00 00 
    9dd2:	e8 a9 08 00 00       	call   a680 <atexit>
    9dd7:	85 c0                	test   %eax,%eax
    9dd9:	0f 85 66 06 00 00    	jne    a445 <fwp_main_thread+0x795>
    9ddf:	8b 05 e3 42 00 00    	mov    0x42e3(%rip),%eax        # e0c8 <st.2>
    9de5:	85 c0                	test   %eax,%eax
    9de7:	0f 84 1b 06 00 00    	je     a408 <fwp_main_thread+0x758>
    9ded:	48 8b 2d 4c 49 01 00 	mov    0x1494c(%rip),%rbp        # 1e740 <fwp_cur>
    9df4:	48 85 ed             	test   %rbp,%rbp
    9df7:	0f 84 5f 01 00 00    	je     9f5c <fwp_main_thread+0x2ac>
    9dfd:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9e02:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9e06:	48 89 eb             	mov    %rbp,%rbx
    9e09:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9e0e:	0f 84 41 01 00 00    	je     9f55 <fwp_main_thread+0x2a5>
    9e14:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9e19:	0f 84 21 02 00 00    	je     a040 <fwp_main_thread+0x390>
    9e1f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9e23:	0f 84 07 02 00 00    	je     a030 <fwp_main_thread+0x380>
    9e29:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9e2d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9e31:	0f 85 89 02 00 00    	jne    a0c0 <fwp_main_thread+0x410>
    9e37:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9e3b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9e42:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9e46:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9e4d:	00 00 00 00 
    9e51:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9e58:	48 85 d2             	test   %rdx,%rdx
    9e5b:	74 07                	je     9e64 <fwp_main_thread+0x1b4>
    9e5d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9e64:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e68:	48 85 c0             	test   %rax,%rax
    9e6b:	74 34                	je     9ea1 <fwp_main_thread+0x1f1>
    9e6d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9e71:	48 8b 05 a0 48 01 00 	mov    0x148a0(%rip),%rax        # 1e718 <fwp_timers>
    9e78:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9e7c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9e83:	00 00 00 00 
    9e87:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9e8e:	48 85 c0             	test   %rax,%rax
    9e91:	74 07                	je     9e9a <fwp_main_thread+0x1ea>
    9e93:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9e9a:	48 89 1d 77 48 01 00 	mov    %rbx,0x14877(%rip)        # 1e718 <fwp_timers>
    9ea1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9ea5:	e8 86 af ff ff       	call   4e30 <fwp_block>
    9eaa:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9eb1:	48 85 c9             	test   %rcx,%rcx
    9eb4:	74 47                	je     9efd <fwp_main_thread+0x24d>
    9eb6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9ebd:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9ec4:	48 85 d2             	test   %rdx,%rdx
    9ec7:	0f 84 33 02 00 00    	je     a100 <fwp_main_thread+0x450>
    9ecd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9ed4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9edb:	48 85 c0             	test   %rax,%rax
    9ede:	74 07                	je     9ee7 <fwp_main_thread+0x237>
    9ee0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9ee7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9eee:	00 00 00 00 
    9ef2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9ef6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9efd:	48 8b 0d 3c 48 01 00 	mov    0x1483c(%rip),%rcx        # 1e740 <fwp_cur>
    9f04:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9f08:	0f 84 a2 01 00 00    	je     a0b0 <fwp_main_thread+0x400>
    9f0e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9f15:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9f1c:	48 85 d2             	test   %rdx,%rdx
    9f1f:	0f 84 db 03 00 00    	je     a300 <fwp_main_thread+0x650>
    9f25:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9f2c:	48 85 c0             	test   %rax,%rax
    9f2f:	74 07                	je     9f38 <fwp_main_thread+0x288>
    9f31:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9f38:	66 0f ef db          	pxor   %xmm3,%xmm3
    9f3c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9f40:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9f47:	48 89 cb             	mov    %rcx,%rbx
    9f4a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9f4f:	0f 85 bf fe ff ff    	jne    9e14 <fwp_main_thread+0x164>
    9f55:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9f59:	48 89 dd             	mov    %rbx,%rbp
    9f5c:	48 83 3d 6c 64 01 00 	cmpq   $0x0,0x1646c(%rip)        # 203d0 <fwp_state_len>
    9f63:	00 
    9f64:	0f 84 a6 03 00 00    	je     a310 <fwp_main_thread+0x660>
    9f6a:	48 8b 15 c7 47 01 00 	mov    0x147c7(%rip),%rdx        # 1e738 <fwp_root>
    9f71:	c7 05 65 41 01 00 00 	movl   $0x0,0x14165(%rip)        # 1e0e0 <fwp_exit_code>
    9f78:	00 00 00 
    9f7b:	48 39 d5             	cmp    %rdx,%rbp
    9f7e:	0f 85 da 04 00 00    	jne    a45e <fwp_main_thread+0x7ae>
    9f84:	48 85 d2             	test   %rdx,%rdx
    9f87:	0f 84 83 01 00 00    	je     a110 <fwp_main_thread+0x460>
    9f8d:	48 8b 0d 74 47 01 00 	mov    0x14774(%rip),%rcx        # 1e708 <fwp_tasks_active>
    9f94:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    9f98:	48 85 c9             	test   %rcx,%rcx
    9f9b:	0f 84 6f 01 00 00    	je     a110 <fwp_main_thread+0x460>
    9fa1:	0f 1f 40 00          	nopl   0x0(%rax)
    9fa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fac:	00 00 00 00 
    9fb0:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    9fb4:	75 08                	jne    9fbe <fwp_main_thread+0x30e>
    9fb6:	48 89 cf             	mov    %rcx,%rdi
    9fb9:	e8 32 90 ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    9fbe:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    9fc5:	48 85 c9             	test   %rcx,%rcx
    9fc8:	75 e6                	jne    9fb0 <fwp_main_thread+0x300>
    9fca:	eb 31                	jmp    9ffd <fwp_main_thread+0x34d>
    9fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fd0:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    9fd7:	48 89 15 42 47 01 00 	mov    %rdx,0x14742(%rip)        # 1e720 <fwp_ready_tail>
    9fde:	e8 4d ae ff ff       	call   4e30 <fwp_block>
    9fe3:	e8 48 ac ff ff       	call   4c30 <fwp_free_zombie>
    9fe8:	48 83 3d 18 47 01 00 	cmpq   $0x0,0x14718(%rip)        # 1e708 <fwp_tasks_active>
    9fef:	00 
    9ff0:	0f 84 1a 01 00 00    	je     a110 <fwp_main_thread+0x460>
    9ff6:	48 8b 15 3b 47 01 00 	mov    0x1473b(%rip),%rdx        # 1e738 <fwp_root>
    9ffd:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    a001:	75 db                	jne    9fde <fwp_main_thread+0x32e>
    a003:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    a007:	75 d5                	jne    9fde <fwp_main_thread+0x32e>
    a009:	48 8b 05 10 47 01 00 	mov    0x14710(%rip),%rax        # 1e720 <fwp_ready_tail>
    a010:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    a014:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    a01b:	00 00 00 00 
    a01f:	48 85 c0             	test   %rax,%rax
    a022:	75 ac                	jne    9fd0 <fwp_main_thread+0x320>
    a024:	48 89 15 fd 46 01 00 	mov    %rdx,0x146fd(%rip)        # 1e728 <fwp_ready_head>
    a02b:	eb aa                	jmp    9fd7 <fwp_main_thread+0x327>
    a02d:	0f 1f 00             	nopl   (%rax)
    a030:	e8 fb 91 ff ff       	call   3230 <fwp_now_ns>
    a035:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a039:	0f 8d 41 03 00 00    	jge    a380 <fwp_main_thread+0x6d0>
    a03f:	90                   	nop
    a040:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a044:	0f 85 df fd ff ff    	jne    9e29 <fwp_main_thread+0x179>
    a04a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a04e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a052:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a056:	0f 85 df fd ff ff    	jne    9e3b <fwp_main_thread+0x18b>
    a05c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a060:	48 85 c9             	test   %rcx,%rcx
    a063:	0f 84 d2 fd ff ff    	je     9e3b <fwp_main_thread+0x18b>
    a069:	48 85 c0             	test   %rax,%rax
    a06c:	0f 84 df 03 00 00    	je     a451 <fwp_main_thread+0x7a1>
    a072:	48 39 c8             	cmp    %rcx,%rax
    a075:	48 0f 4f c1          	cmovg  %rcx,%rax
    a079:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a080:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a084:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a08b:	00 00 00 00 
    a08f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a096:	48 85 d2             	test   %rdx,%rdx
    a099:	74 07                	je     a0a2 <fwp_main_thread+0x3f2>
    a09b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a0a2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a0a6:	e9 c2 fd ff ff       	jmp    9e6d <fwp_main_thread+0x1bd>
    a0ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0b0:	48 89 cb             	mov    %rcx,%rbx
    a0b3:	e9 51 fd ff ff       	jmp    9e09 <fwp_main_thread+0x159>
    a0b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0bf:	00 
    a0c0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a0c4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a0cb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a0d2:	00 00 00 00 
    a0d6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a0dd:	48 85 c0             	test   %rax,%rax
    a0e0:	0f 84 4a 03 00 00    	je     a430 <fwp_main_thread+0x780>
    a0e6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a0ed:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a0f1:	e9 ab fd ff ff       	jmp    9ea1 <fwp_main_thread+0x1f1>
    a0f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0fd:	00 00 00 
    a100:	48 89 01             	mov    %rax,(%rcx)
    a103:	e9 d3 fd ff ff       	jmp    9edb <fwp_main_thread+0x22b>
    a108:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a10f:	00 
    a110:	e8 1b ab ff ff       	call   4c30 <fwp_free_zombie>
    a115:	48 83 3d 0b 46 01 00 	cmpq   $0x0,0x1460b(%rip)        # 1e728 <fwp_ready_head>
    a11c:	00 
    a11d:	0f 85 ed 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a123:	48 83 3d ed 45 01 00 	cmpq   $0x0,0x145ed(%rip)        # 1e718 <fwp_timers>
    a12a:	00 
    a12b:	0f 85 df 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a131:	8b 1d cd 3f 01 00    	mov    0x13fcd(%rip),%ebx        # 1e104 <fwp_stack_pool_n>
    a137:	85 db                	test   %ebx,%ebx
    a139:	74 34                	je     a16f <fwp_main_thread+0x4bf>
    a13b:	83 eb 01             	sub    $0x1,%ebx
    a13e:	48 8d 05 db 3f 01 00 	lea    0x13fdb(%rip),%rax        # 1e120 <fwp_stack_pool>
    a145:	48 63 d3             	movslq %ebx,%rdx
    a148:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    a14c:	eb 05                	jmp    a153 <fwp_main_thread+0x4a3>
    a14e:	66 90                	xchg   %ax,%ax
    a150:	83 eb 01             	sub    $0x1,%ebx
    a153:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a157:	be 00 00 00 10       	mov    $0x10000000,%esi
    a15c:	89 1d a2 3f 01 00    	mov    %ebx,0x13fa2(%rip)        # 1e104 <fwp_stack_pool_n>
    a162:	48 83 ed 08          	sub    $0x8,%rbp
    a166:	e8 45 84 ff ff       	call   25b0 <munmap@plt>
    a16b:	85 db                	test   %ebx,%ebx
    a16d:	75 e1                	jne    a150 <fwp_main_thread+0x4a0>
    a16f:	8b 3d eb 3e 00 00    	mov    0x3eeb(%rip),%edi        # e060 <fwp_epfd>
    a175:	85 ff                	test   %edi,%edi
    a177:	78 05                	js     a17e <fwp_main_thread+0x4ce>
    a179:	e8 32 83 ff ff       	call   24b0 <close@plt>
    a17e:	4c 8b 25 9b 41 01 00 	mov    0x1419b(%rip),%r12        # 1e320 <fwp_nfdws>
    a185:	48 8b 2d 9c 41 01 00 	mov    0x1419c(%rip),%rbp        # 1e328 <fwp_fdws>
    a18c:	31 db                	xor    %ebx,%ebx
    a18e:	c7 05 c8 3e 00 00 ff 	movl   $0xffffffff,0x3ec8(%rip)        # e060 <fwp_epfd>
    a195:	ff ff ff 
    a198:	4d 85 e4             	test   %r12,%r12
    a19b:	74 30                	je     a1cd <fwp_main_thread+0x51d>
    a19d:	0f 1f 00             	nopl   (%rax)
    a1a0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    a1a5:	48 85 ff             	test   %rdi,%rdi
    a1a8:	74 1a                	je     a1c4 <fwp_main_thread+0x514>
    a1aa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    a1ae:	0f 85 5c 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1b4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    a1b9:	0f 85 51 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a1bf:	e8 4c 9f ff ff       	call   4110 <fwp_mem_free>
    a1c4:	48 83 c3 01          	add    $0x1,%rbx
    a1c8:	49 39 dc             	cmp    %rbx,%r12
    a1cb:	75 d3                	jne    a1a0 <fwp_main_thread+0x4f0>
    a1cd:	48 89 ef             	mov    %rbp,%rdi
    a1d0:	e8 3b 9f ff ff       	call   4110 <fwp_mem_free>
    a1d5:	48 8b 15 5c 45 01 00 	mov    0x1455c(%rip),%rdx        # 1e738 <fwp_root>
    a1dc:	48 c7 05 41 41 01 00 	movq   $0x0,0x14141(%rip)        # 1e328 <fwp_fdws>
    a1e3:	00 00 00 00 
    a1e7:	48 c7 05 2e 41 01 00 	movq   $0x0,0x1412e(%rip)        # 1e320 <fwp_nfdws>
    a1ee:	00 00 00 00 
    a1f2:	48 85 d2             	test   %rdx,%rdx
    a1f5:	74 4e                	je     a245 <fwp_main_thread+0x595>
    a1f7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    a1fc:	0f 85 0e 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a202:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    a209:	00 
    a20a:	0f 85 00 85 ff ff    	jne    2710 <fwp_main_thread.cold>
    a210:	48 83 3d b8 61 01 00 	cmpq   $0x0,0x161b8(%rip)        # 203d0 <fwp_state_len>
    a217:	00 
    a218:	0f 85 f2 84 ff ff    	jne    2710 <fwp_main_thread.cold>
    a21e:	48 83 3d 9a 61 01 00 	cmpq   $0x0,0x1619a(%rip)        # 203c0 <fwp_state_owners>
    a225:	00 
    a226:	0f 85 e4 84 ff ff    	jne    2710 <fwp_main_thread.cold>
    a22c:	b9 79 00 00 00       	mov    $0x79,%ecx
    a231:	31 c0                	xor    %eax,%eax
    a233:	48 8d 3d 06 41 01 00 	lea    0x14106(%rip),%rdi        # 1e340 <fwp_root_context>
    a23a:	f3 48 ab             	rep stos %rax,(%rdi)
    a23d:	48 89 d7             	mov    %rdx,%rdi
    a240:	e8 cb 9e ff ff       	call   4110 <fwp_mem_free>
    a245:	48 8b 05 34 59 01 00 	mov    0x15934(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    a24c:	48 c7 05 e9 44 01 00 	movq   $0x0,0x144e9(%rip)        # 1e740 <fwp_cur>
    a253:	00 00 00 00 
    a257:	48 c7 05 d6 44 01 00 	movq   $0x0,0x144d6(%rip)        # 1e738 <fwp_root>
    a25e:	00 00 00 00 
    a262:	48 c7 05 7b 3e 01 00 	movq   $0x0,0x13e7b(%rip)        # 1e0e8 <ad_raw_before_shutdown>
    a269:	00 00 00 00 
    a26d:	c7 05 a9 61 01 00 00 	movl   $0x0,0x161a9(%rip)        # 20420 <iteration_active>
    a274:	00 00 00 
    a277:	48 85 c0             	test   %rax,%rax
    a27a:	0f 88 20 01 00 00    	js     a3a0 <fwp_main_thread+0x6f0>
    a280:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a284:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    a289:	f2 0f 5c 0d 6f 61 01 	subsd  0x1616f(%rip),%xmm1        # 20400 <iteration_start_charge>
    a290:	00 
    a291:	48 8b 3d 08 3e 00 00 	mov    0x3e08(%rip),%rdi        # e0a0 <stderr@GLIBC_2.2.5>
    a298:	48 8d 15 a1 11 00 00 	lea    0x11a1(%rip),%rdx        # b440 <_IO_stdin_used+0x440>
    a29f:	be 02 00 00 00       	mov    $0x2,%esi
    a2a4:	f2 0f 10 05 4c 61 01 	movsd  0x1614c(%rip),%xmm0        # 203f8 <iteration_peak>
    a2ab:	00 
    a2ac:	4c 8b 0d 55 61 01 00 	mov    0x16155(%rip),%r9        # 20408 <iteration_retains>
    a2b3:	b8 02 00 00 00       	mov    $0x2,%eax
    a2b8:	4c 8b 05 51 61 01 00 	mov    0x16151(%rip),%r8        # 20410 <iteration_bytes>
    a2bf:	48 8b 0d 52 61 01 00 	mov    0x16152(%rip),%rcx        # 20418 <iteration_requests>
    a2c6:	e8 85 83 ff ff       	call   2650 <__fprintf_chk@plt>
    a2cb:	48 8b 3d ae 3d 00 00 	mov    0x3dae(%rip),%rdi        # e080 <stdout@GLIBC_2.2.5>
    a2d2:	e8 b9 82 ff ff       	call   2590 <fflush@plt>
    a2d7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    a2de:	00 
    a2df:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2e6:	00 00 
    a2e8:	0f 85 6b 01 00 00    	jne    a459 <fwp_main_thread+0x7a9>
    a2ee:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    a2f5:	31 c0                	xor    %eax,%eax
    a2f7:	5b                   	pop    %rbx
    a2f8:	5d                   	pop    %rbp
    a2f9:	41 5c                	pop    %r12
    a2fb:	c3                   	ret
    a2fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a300:	48 89 05 11 44 01 00 	mov    %rax,0x14411(%rip)        # 1e718 <fwp_timers>
    a307:	e9 20 fc ff ff       	jmp    9f2c <fwp_main_thread+0x27c>
    a30c:	0f 1f 40 00          	nopl   0x0(%rax)
    a310:	48 83 3d a8 60 01 00 	cmpq   $0x0,0x160a8(%rip)        # 203c0 <fwp_state_owners>
    a317:	00 
    a318:	0f 85 4c fc ff ff    	jne    9f6a <fwp_main_thread+0x2ba>
    a31e:	48 8b 3d b3 60 01 00 	mov    0x160b3(%rip),%rdi        # 203d8 <fwp_state>
    a325:	e8 e6 9d ff ff       	call   4110 <fwp_mem_free>
    a32a:	48 c7 05 a3 60 01 00 	movq   $0x0,0x160a3(%rip)        # 203d8 <fwp_state>
    a331:	00 00 00 00 
    a335:	48 c7 05 88 60 01 00 	movq   $0x0,0x16088(%rip)        # 203c8 <fwp_state_cap>
    a33c:	00 00 00 00 
    a340:	48 85 ed             	test   %rbp,%rbp
    a343:	0f 84 21 fc ff ff    	je     9f6a <fwp_main_thread+0x2ba>
    a349:	48 8b 15 e8 43 01 00 	mov    0x143e8(%rip),%rdx        # 1e738 <fwp_root>
    a350:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    a357:	00 00 00 00 
    a35b:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    a362:	00 00 00 00 
    a366:	c7 05 70 3d 01 00 00 	movl   $0x0,0x13d70(%rip)        # 1e0e0 <fwp_exit_code>
    a36d:	00 00 00 
    a370:	48 39 d5             	cmp    %rdx,%rbp
    a373:	0f 84 14 fc ff ff    	je     9f8d <fwp_main_thread+0x2dd>
    a379:	e9 92 83 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a37e:	66 90                	xchg   %ax,%ax
    a380:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a384:	0f 85 b6 fc ff ff    	jne    a040 <fwp_main_thread+0x390>
    a38a:	48 89 ef             	mov    %rbp,%rdi
    a38d:	e8 5e 8c ff ff       	call   2ff0 <fwp_cancel_tree.part.0>
    a392:	e9 a9 fc ff ff       	jmp    a040 <fwp_main_thread+0x390>
    a397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a39e:	00 00 
    a3a0:	48 89 c2             	mov    %rax,%rdx
    a3a3:	83 e0 01             	and    $0x1,%eax
    a3a6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a3aa:	48 d1 ea             	shr    $1,%rdx
    a3ad:	48 09 c2             	or     %rax,%rdx
    a3b0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    a3b5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    a3b9:	e9 cb fe ff ff       	jmp    a289 <fwp_main_thread+0x5d9>
    a3be:	66 90                	xchg   %ax,%ax
    a3c0:	48 89 c2             	mov    %rax,%rdx
    a3c3:	83 e0 01             	and    $0x1,%eax
    a3c6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a3ca:	48 d1 ea             	shr    $1,%rdx
    a3cd:	48 09 c2             	or     %rax,%rdx
    a3d0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    a3d5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    a3d9:	e9 db f9 ff ff       	jmp    9db9 <fwp_main_thread+0x109>
    a3de:	66 90                	xchg   %ax,%ax
    a3e0:	48 8d 3d 39 94 ff ff 	lea    -0x6bc7(%rip),%rdi        # 3820 <fwp_heap_report>
    a3e7:	e8 94 02 00 00       	call   a680 <atexit>
    a3ec:	e9 fd f8 ff ff       	jmp    9cee <fwp_main_thread+0x3e>
    a3f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3f8:	e8 33 95 ff ff       	call   3930 <fwp_heap_init>
    a3fd:	e9 de f8 ff ff       	jmp    9ce0 <fwp_main_thread+0x30>
    a402:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a408:	e8 33 ce ff ff       	call   7240 <f0>
    a40d:	48 c7 05 a8 3c 00 00 	movq   $0x0,0x3ca8(%rip)        # e0c0 <v.1>
    a414:	00 00 00 00 
    a418:	c7 05 a6 3c 00 00 01 	movl   $0x1,0x3ca6(%rip)        # e0c8 <st.2>
    a41f:	00 00 00 
    a422:	e9 c6 f9 ff ff       	jmp    9ded <fwp_main_thread+0x13d>
    a427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a42e:	00 00 
    a430:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a434:	e9 68 fa ff ff       	jmp    9ea1 <fwp_main_thread+0x1f1>
    a439:	48 8d 3d d8 0f 00 00 	lea    0xfd8(%rip),%rdi        # b418 <_IO_stdin_used+0x418>
    a440:	e8 bb 8d ff ff       	call   3200 <fwp_trap>
    a445:	48 8d 3d 62 0d 00 00 	lea    0xd62(%rip),%rdi        # b1ae <_IO_stdin_used+0x1ae>
    a44c:	e8 6f 8a ff ff       	call   2ec0 <ad_raw_fail>
    a451:	48 89 c8             	mov    %rcx,%rax
    a454:	e9 20 fc ff ff       	jmp    a079 <fwp_main_thread+0x3c9>
    a459:	e8 e2 7f ff ff       	call   2440 <__stack_chk_fail@plt>
    a45e:	e9 ad 82 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a463:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a46a:	00 00 00 
    a46d:	0f 1f 00             	nopl   (%rax)

000000000000a470 <__divmodti4>:
    a470:	f3 0f 1e fa          	endbr64
    a474:	55                   	push   %rbp
    a475:	49 89 f1             	mov    %rsi,%r9
    a478:	49 89 d2             	mov    %rdx,%r10
    a47b:	48 89 fe             	mov    %rdi,%rsi
    a47e:	49 89 cb             	mov    %rcx,%r11
    a481:	48 89 e5             	mov    %rsp,%rbp
    a484:	41 57                	push   %r15
    a486:	41 56                	push   %r14
    a488:	41 55                	push   %r13
    a48a:	41 54                	push   %r12
    a48c:	53                   	push   %rbx
    a48d:	4c 89 c3             	mov    %r8,%rbx
    a490:	45 31 c0             	xor    %r8d,%r8d
    a493:	4d 85 c9             	test   %r9,%r9
    a496:	79 12                	jns    a4aa <__divmodti4+0x3a>
    a498:	31 ff                	xor    %edi,%edi
    a49a:	48 f7 de             	neg    %rsi
    a49d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a4a4:	4c 19 cf             	sbb    %r9,%rdi
    a4a7:	49 89 f9             	mov    %rdi,%r9
    a4aa:	4c 89 d8             	mov    %r11,%rax
    a4ad:	4d 85 db             	test   %r11,%r11
    a4b0:	0f 88 1a 01 00 00    	js     a5d0 <__divmodti4+0x160>
    a4b6:	4c 89 d9             	mov    %r11,%rcx
    a4b9:	49 89 f3             	mov    %rsi,%r11
    a4bc:	75 62                	jne    a520 <__divmodti4+0xb0>
    a4be:	4d 89 c4             	mov    %r8,%r12
    a4c1:	4d 39 d1             	cmp    %r10,%r9
    a4c4:	0f 83 46 01 00 00    	jae    a610 <__divmodti4+0x1a0>
    a4ca:	4c 89 d8             	mov    %r11,%rax
    a4cd:	4c 89 ca             	mov    %r9,%rdx
    a4d0:	49 f7 f2             	div    %r10
    a4d3:	49 89 c3             	mov    %rax,%r11
    a4d6:	31 c0                	xor    %eax,%eax
    a4d8:	48 89 d6             	mov    %rdx,%rsi
    a4db:	31 ff                	xor    %edi,%edi
    a4dd:	4c 89 d9             	mov    %r11,%rcx
    a4e0:	48 89 c2             	mov    %rax,%rdx
    a4e3:	48 89 c8             	mov    %rcx,%rax
    a4e6:	4d 85 e4             	test   %r12,%r12
    a4e9:	74 0a                	je     a4f5 <__divmodti4+0x85>
    a4eb:	48 f7 d8             	neg    %rax
    a4ee:	48 83 d2 00          	adc    $0x0,%rdx
    a4f2:	48 f7 da             	neg    %rdx
    a4f5:	4d 85 c0             	test   %r8,%r8
    a4f8:	74 0a                	je     a504 <__divmodti4+0x94>
    a4fa:	48 f7 de             	neg    %rsi
    a4fd:	48 83 d7 00          	adc    $0x0,%rdi
    a501:	48 f7 df             	neg    %rdi
    a504:	48 89 33             	mov    %rsi,(%rbx)
    a507:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a50b:	5b                   	pop    %rbx
    a50c:	41 5c                	pop    %r12
    a50e:	41 5d                	pop    %r13
    a510:	41 5e                	pop    %r14
    a512:	41 5f                	pop    %r15
    a514:	5d                   	pop    %rbp
    a515:	c3                   	ret
    a516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a51d:	00 00 00 
    a520:	4d 89 c4             	mov    %r8,%r12
    a523:	49 39 c1             	cmp    %rax,%r9
    a526:	0f 82 ce 00 00 00    	jb     a5fa <__divmodti4+0x18a>
    a52c:	31 ff                	xor    %edi,%edi
    a52e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a533:	48 63 c7             	movslq %edi,%rax
    a536:	be 40 00 00 00       	mov    $0x40,%esi
    a53b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a540:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a545:	48 29 c6             	sub    %rax,%rsi
    a548:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a54d:	48 09 c8             	or     %rcx,%rax
    a550:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a555:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a55a:	49 89 c6             	mov    %rax,%r14
    a55d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a561:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a566:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a56b:	49 09 c1             	or     %rax,%r9
    a56e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a572:	4c 89 c8             	mov    %r9,%rax
    a575:	49 f7 f6             	div    %r14
    a578:	48 89 d1             	mov    %rdx,%rcx
    a57b:	49 89 c3             	mov    %rax,%r11
    a57e:	49 89 c1             	mov    %rax,%r9
    a581:	49 f7 e2             	mul    %r10
    a584:	49 89 c6             	mov    %rax,%r14
    a587:	49 89 d2             	mov    %rdx,%r10
    a58a:	48 39 d1             	cmp    %rdx,%rcx
    a58d:	72 07                	jb     a596 <__divmodti4+0x126>
    a58f:	75 17                	jne    a5a8 <__divmodti4+0x138>
    a591:	49 39 c7             	cmp    %rax,%r15
    a594:	73 12                	jae    a5a8 <__divmodti4+0x138>
    a596:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a59a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a59e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a5a2:	49 89 d2             	mov    %rdx,%r10
    a5a5:	49 89 c6             	mov    %rax,%r14
    a5a8:	4c 89 f8             	mov    %r15,%rax
    a5ab:	4c 29 f0             	sub    %r14,%rax
    a5ae:	4c 19 d1             	sbb    %r10,%rcx
    a5b1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a5b6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a5bb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a5c0:	48 09 c6             	or     %rax,%rsi
    a5c3:	48 89 cf             	mov    %rcx,%rdi
    a5c6:	31 c0                	xor    %eax,%eax
    a5c8:	4c 89 c9             	mov    %r9,%rcx
    a5cb:	e9 10 ff ff ff       	jmp    a4e0 <__divmodti4+0x70>
    a5d0:	4c 89 d0             	mov    %r10,%rax
    a5d3:	4c 89 da             	mov    %r11,%rdx
    a5d6:	4d 89 c4             	mov    %r8,%r12
    a5d9:	49 89 f3             	mov    %rsi,%r11
    a5dc:	48 f7 d8             	neg    %rax
    a5df:	49 f7 d4             	not    %r12
    a5e2:	48 83 d2 00          	adc    $0x0,%rdx
    a5e6:	49 89 c2             	mov    %rax,%r10
    a5e9:	48 f7 da             	neg    %rdx
    a5ec:	48 89 d1             	mov    %rdx,%rcx
    a5ef:	0f 84 cc fe ff ff    	je     a4c1 <__divmodti4+0x51>
    a5f5:	49 39 d1             	cmp    %rdx,%r9
    a5f8:	73 46                	jae    a640 <__divmodti4+0x1d0>
    a5fa:	4c 89 cf             	mov    %r9,%rdi
    a5fd:	31 c0                	xor    %eax,%eax
    a5ff:	31 c9                	xor    %ecx,%ecx
    a601:	e9 da fe ff ff       	jmp    a4e0 <__divmodti4+0x70>
    a606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a60d:	00 00 00 
    a610:	4d 85 d2             	test   %r10,%r10
    a613:	75 0d                	jne    a622 <__divmodti4+0x1b2>
    a615:	b8 01 00 00 00       	mov    $0x1,%eax
    a61a:	31 d2                	xor    %edx,%edx
    a61c:	49 f7 f2             	div    %r10
    a61f:	49 89 c2             	mov    %rax,%r10
    a622:	4c 89 c8             	mov    %r9,%rax
    a625:	31 d2                	xor    %edx,%edx
    a627:	49 f7 f2             	div    %r10
    a62a:	49 89 c1             	mov    %rax,%r9
    a62d:	4c 89 d8             	mov    %r11,%rax
    a630:	49 f7 f2             	div    %r10
    a633:	49 89 c3             	mov    %rax,%r11
    a636:	4c 89 c8             	mov    %r9,%rax
    a639:	e9 9a fe ff ff       	jmp    a4d8 <__divmodti4+0x68>
    a63e:	66 90                	xchg   %ax,%ax
    a640:	45 31 f6             	xor    %r14d,%r14d
    a643:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a648:	44 89 f7             	mov    %r14d,%edi
    a64b:	45 85 f6             	test   %r14d,%r14d
    a64e:	0f 85 df fe ff ff    	jne    a533 <__divmodti4+0xc3>
    a654:	4c 39 ca             	cmp    %r9,%rdx
    a657:	72 17                	jb     a670 <__divmodti4+0x200>
    a659:	31 c9                	xor    %ecx,%ecx
    a65b:	48 39 c6             	cmp    %rax,%rsi
    a65e:	73 10                	jae    a670 <__divmodti4+0x200>
    a660:	4c 89 cf             	mov    %r9,%rdi
    a663:	31 c0                	xor    %eax,%eax
    a665:	e9 76 fe ff ff       	jmp    a4e0 <__divmodti4+0x70>
    a66a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a670:	4c 89 de             	mov    %r11,%rsi
    a673:	b9 01 00 00 00       	mov    $0x1,%ecx
    a678:	48 29 c6             	sub    %rax,%rsi
    a67b:	49 19 d1             	sbb    %rdx,%r9
    a67e:	eb e0                	jmp    a660 <__divmodti4+0x1f0>

000000000000a680 <atexit>:
    a680:	f3 0f 1e fa          	endbr64
    a684:	48 8b 15 7d 39 00 00 	mov    0x397d(%rip),%rdx        # e008 <__dso_handle>
    a68b:	31 f6                	xor    %esi,%esi
    a68d:	e9 8e 7f ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a694 <_fini>:
    a694:	f3 0f 1e fa          	endbr64
    a698:	48 83 ec 08          	sub    $0x8,%rsp
    a69c:	48 83 c4 08          	add    $0x8,%rsp
    a6a0:	c3                   	ret
