
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d9 af 00 00 	mov    0xafd9(%rip),%rax        # cfe8 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 02 ae 00 00    	push   0xae02(%rip)        # ce28 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 04 ae 00 00    	jmp    *0xae04(%rip)        # ce30 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 7e ac 00 00    	jmp    *0xac7e(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 ae aa 00 00    	jmp    *0xaaae(%rip)        # ce38 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 a6 aa 00 00    	jmp    *0xaaa6(%rip)        # ce40 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 9e aa 00 00    	jmp    *0xaa9e(%rip)        # ce48 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 96 aa 00 00    	jmp    *0xaa96(%rip)        # ce50 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 8e aa 00 00    	jmp    *0xaa8e(%rip)        # ce58 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 86 aa 00 00    	jmp    *0xaa86(%rip)        # ce60 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 7e aa 00 00    	jmp    *0xaa7e(%rip)        # ce68 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 76 aa 00 00    	jmp    *0xaa76(%rip)        # ce70 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 6e aa 00 00    	jmp    *0xaa6e(%rip)        # ce78 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 66 aa 00 00    	jmp    *0xaa66(%rip)        # ce80 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 5e aa 00 00    	jmp    *0xaa5e(%rip)        # ce88 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 56 aa 00 00    	jmp    *0xaa56(%rip)        # ce90 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 4e aa 00 00    	jmp    *0xaa4e(%rip)        # ce98 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 46 aa 00 00    	jmp    *0xaa46(%rip)        # cea0 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 3e aa 00 00    	jmp    *0xaa3e(%rip)        # cea8 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 36 aa 00 00    	jmp    *0xaa36(%rip)        # ceb0 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 2e aa 00 00    	jmp    *0xaa2e(%rip)        # ceb8 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 26 aa 00 00    	jmp    *0xaa26(%rip)        # cec0 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 1e aa 00 00    	jmp    *0xaa1e(%rip)        # cec8 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 16 aa 00 00    	jmp    *0xaa16(%rip)        # ced0 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 0e aa 00 00    	jmp    *0xaa0e(%rip)        # ced8 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 06 aa 00 00    	jmp    *0xaa06(%rip)        # cee0 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 fe a9 00 00    	jmp    *0xa9fe(%rip)        # cee8 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 f6 a9 00 00    	jmp    *0xa9f6(%rip)        # cef0 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 ee a9 00 00    	jmp    *0xa9ee(%rip)        # cef8 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 e6 a9 00 00    	jmp    *0xa9e6(%rip)        # cf00 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 de a9 00 00    	jmp    *0xa9de(%rip)        # cf08 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 d6 a9 00 00    	jmp    *0xa9d6(%rip)        # cf10 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 ce a9 00 00    	jmp    *0xa9ce(%rip)        # cf18 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 c6 a9 00 00    	jmp    *0xa9c6(%rip)        # cf20 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 be a9 00 00    	jmp    *0xa9be(%rip)        # cf28 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 b6 a9 00 00    	jmp    *0xa9b6(%rip)        # cf30 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 ae a9 00 00    	jmp    *0xa9ae(%rip)        # cf38 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 a6 a9 00 00    	jmp    *0xa9a6(%rip)        # cf40 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 9e a9 00 00    	jmp    *0xa99e(%rip)        # cf48 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 96 a9 00 00    	jmp    *0xa996(%rip)        # cf50 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 8e a9 00 00    	jmp    *0xa98e(%rip)        # cf58 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 86 a9 00 00    	jmp    *0xa986(%rip)        # cf60 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 7e a9 00 00    	jmp    *0xa97e(%rip)        # cf68 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 76 a9 00 00    	jmp    *0xa976(%rip)        # cf70 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 6e a9 00 00    	jmp    *0xa96e(%rip)        # cf78 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 66 a9 00 00    	jmp    *0xa966(%rip)        # cf80 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 5e a9 00 00    	jmp    *0xa95e(%rip)        # cf88 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 56 a9 00 00    	jmp    *0xa956(%rip)        # cf90 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 4e a9 00 00    	jmp    *0xa94e(%rip)        # cf98 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 46 a9 00 00    	jmp    *0xa946(%rip)        # cfa0 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 3e a9 00 00    	jmp    *0xa93e(%rip)        # cfa8 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 36 a9 00 00    	jmp    *0xa936(%rip)        # cfb0 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 2e a9 00 00    	jmp    *0xa92e(%rip)        # cfb8 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 26 a9 00 00    	jmp    *0xa926(%rip)        # cfc0 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 1e a9 00 00    	jmp    *0xa91e(%rip)        # cfc8 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 16 a9 00 00    	jmp    *0xa916(%rip)        # cfd0 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d a0 89 00 00 	lea    0x89a0(%rip),%r9        # b077 <_IO_stdin_used+0x77>
    26d7:	4c 8d 05 9d 89 00 00 	lea    0x899d(%rip),%r8        # b07b <_IO_stdin_used+0x7b>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 aa 09 00 00       	call   30b0 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_hof0.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 41 a9 00 00 	mov    0xa941(%rip),%rax        # d080 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 52 cc 01 00 	mov    %rax,0x1cc52(%rip)        # 1f398 <fwp_prog_out>
    2746:	e8 95 09 00 00       	call   30e0 <fwp_now_ns>
    274b:	48 8d 3d 1c 8a 00 00 	lea    0x8a1c(%rip),%rdi        # b16e <_IO_stdin_used+0x16e>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d c6 a8 00 00 	mov    0xa8c6(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 bd 71 00 00 	lea    0x71bd(%rip),%rdx        # 99d0 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d 31 a8 00 00 	mov    0xa831(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 86 a8 01 00    	mov    0x1a886(%rip),%eax        # 1d0e0 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d cc 88 00 00 	lea    0x88cc(%rip),%rdi        # b177 <_IO_stdin_used+0x177>
    28ab:	e8 00 08 00 00       	call   30b0 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d ec 8a 00 00 	lea    0x8aec(%rip),%rdi        # b3a8 <_IO_stdin_used+0x3a8>
    28bc:	e8 ef 07 00 00       	call   30b0 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d a6 8a 00 00 	lea    0x8aa6(%rip),%rdi        # b380 <_IO_stdin_used+0x380>
    28da:	e8 d1 07 00 00       	call   30b0 <fwp_trap>
    28df:	48 8d 3d 6a 8a 00 00 	lea    0x8a6a(%rip),%rdi        # b350 <_IO_stdin_used+0x350>
    28e6:	e8 c5 07 00 00       	call   30b0 <fwp_trap>
    28eb:	48 8d 3d 36 8a 00 00 	lea    0x8a36(%rip),%rdi        # b328 <_IO_stdin_used+0x328>
    28f2:	e8 b9 07 00 00       	call   30b0 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 b3 a6 00 00    	call   *0xa6b3(%rip)        # cfd8 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d 31 a7 00 00 	lea    0xa731(%rip),%rdi        # d068 <__TMC_END__>
    2937:	48 8d 05 2a a7 00 00 	lea    0xa72a(%rip),%rax        # d068 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 96 a6 00 00 	mov    0xa696(%rip),%rax        # cfe0 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d 01 a7 00 00 	lea    0xa701(%rip),%rdi        # d068 <__TMC_END__>
    2967:	48 8d 35 fa a6 00 00 	lea    0xa6fa(%rip),%rsi        # d068 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 65 a6 00 00 	mov    0xa665(%rip),%rax        # cff0 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d fd a6 00 00 00 	cmpb   $0x0,0xa6fd(%rip)        # d0a8 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 42 a6 00 00 	cmpq   $0x0,0xa642(%rip)        # cff8 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 a6 00 00 	mov    0xa646(%rip),%rdi        # d008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 d5 a6 00 00 01 	movb   $0x1,0xa6d5(%rip)        # d0a8 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_flush>:
    2bc0:	48 8b 3d d1 c7 01 00 	mov    0x1c7d1(%rip),%rdi        # 1f398 <fwp_prog_out>
    2bc7:	48 85 ff             	test   %rdi,%rdi
    2bca:	74 1c                	je     2be8 <fwp_flush+0x28>
    2bcc:	48 83 ec 08          	sub    $0x8,%rsp
    2bd0:	e8 bb f9 ff ff       	call   2590 <fflush@plt>
    2bd5:	48 8b 3d a4 a4 00 00 	mov    0xa4a4(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    2bdc:	48 83 c4 08          	add    $0x8,%rsp
    2be0:	e9 ab f9 ff ff       	jmp    2590 <fflush@plt>
    2be5:	0f 1f 00             	nopl   (%rax)
    2be8:	48 8b 3d 91 a4 00 00 	mov    0xa491(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    2bef:	e9 9c f9 ff ff       	jmp    2590 <fflush@plt>
    2bf4:	90                   	nop
    2bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bfc:	00 00 00 00 

0000000000002c00 <fwp_heap_oom>:
    2c00:	50                   	push   %rax
    2c01:	58                   	pop    %rax
    2c02:	ba 13 00 00 00       	mov    $0x13,%edx
    2c07:	be 01 00 00 00       	mov    $0x1,%esi
    2c0c:	48 8d 3d f5 83 00 00 	lea    0x83f5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2c13:	48 83 ec 08          	sub    $0x8,%rsp
    2c17:	48 8b 0d 82 a4 00 00 	mov    0xa482(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    2c1e:	e8 1d fa ff ff       	call   2640 <fwrite@plt>
    2c23:	31 ff                	xor    %edi,%edi
    2c25:	e8 66 f9 ff ff       	call   2590 <fflush@plt>
    2c2a:	bf 66 00 00 00       	mov    $0x66,%edi
    2c2f:	e8 2c fa ff ff       	call   2660 <_Exit@plt>
    2c34:	90                   	nop
    2c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c3c:	00 00 00 00 

0000000000002c40 <fwp_segv>:
    2c40:	f3 0f 1e fa          	endbr64
    2c44:	48 83 ec 28          	sub    $0x28,%rsp
    2c48:	48 8b 05 d1 aa 01 00 	mov    0x1aad1(%rip),%rax        # 1d720 <fwp_cur>
    2c4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c53:	41 89 f8             	mov    %edi,%r8d
    2c56:	48 85 c0             	test   %rax,%rax
    2c59:	74 6d                	je     2cc8 <fwp_segv+0x88>
    2c5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c5f:	48 85 d2             	test   %rdx,%rdx
    2c62:	74 64                	je     2cc8 <fwp_segv+0x88>
    2c64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2c72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2c77:	e8 84 f9 ff ff       	call   2600 <sysconf@plt>
    2c7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2c81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2c86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2c8b:	48 01 d0             	add    %rdx,%rax
    2c8e:	48 39 c1             	cmp    %rax,%rcx
    2c91:	b8 00 00 00 00       	mov    $0x0,%eax
    2c96:	40 0f 92 c6          	setb   %sil
    2c9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2ca1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2ca5:	31 c0                	xor    %eax,%eax
    2ca7:	48 39 d1             	cmp    %rdx,%rcx
    2caa:	0f 93 c0             	setae  %al
    2cad:	21 f0                	and    %esi,%eax
    2caf:	85 c0                	test   %eax,%eax
    2cb1:	75 4a                	jne    2cfd <fwp_segv+0xbd>
    2cb3:	31 f6                	xor    %esi,%esi
    2cb5:	44 89 c7             	mov    %r8d,%edi
    2cb8:	48 83 c4 28          	add    $0x28,%rsp
    2cbc:	e9 5f f8 ff ff       	jmp    2520 <signal@plt>
    2cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cc8:	48 8b 05 21 a4 01 00 	mov    0x1a421(%rip),%rax        # 1d0f0 <fwp_main_stack_top>
    2ccf:	48 85 c0             	test   %rax,%rax
    2cd2:	74 df                	je     2cb3 <fwp_segv+0x73>
    2cd4:	48 2b 05 0d a4 01 00 	sub    0x1a40d(%rip),%rax        # 1d0e8 <fwp_main_stack_size>
    2cdb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2ce2:	48 39 d1             	cmp    %rdx,%rcx
    2ce5:	0f 93 c2             	setae  %dl
    2ce8:	48 05 00 00 10 00    	add    $0x100000,%rax
    2cee:	48 39 c1             	cmp    %rax,%rcx
    2cf1:	0f 92 c0             	setb   %al
    2cf4:	0f b6 c0             	movzbl %al,%eax
    2cf7:	21 d0                	and    %edx,%eax
    2cf9:	85 c0                	test   %eax,%eax
    2cfb:	74 b6                	je     2cb3 <fwp_segv+0x73>
    2cfd:	e8 be fe ff ff       	call   2bc0 <fwp_flush>
    2d02:	bf 02 00 00 00       	mov    $0x2,%edi
    2d07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d0c:	48 8d 35 2d 87 00 00 	lea    0x872d(%rip),%rsi        # b440 <msg.3>
    2d13:	e8 f8 f6 ff ff       	call   2410 <write@plt>
    2d18:	bf 65 00 00 00       	mov    $0x65,%edi
    2d1d:	e8 9e f6 ff ff       	call   23c0 <_exit@plt>
    2d22:	0f 1f 00             	nopl   (%rax)
    2d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d2c:	00 00 00 00 

0000000000002d30 <fwp_heap_chunks>:
    2d30:	41 54                	push   %r12
    2d32:	55                   	push   %rbp
    2d33:	53                   	push   %rbx
    2d34:	48 83 ff 01          	cmp    $0x1,%rdi
    2d38:	0f 84 62 01 00 00    	je     2ea0 <fwp_heap_chunks+0x170>
    2d3e:	48 8b 05 eb bd 01 00 	mov    0x1bdeb(%rip),%rax        # 1eb30 <fwp_heap+0x13f0>
    2d45:	4c 8d 05 e4 bd 01 00 	lea    0x1bde4(%rip),%r8        # 1eb30 <fwp_heap+0x13f0>
    2d4c:	48 8b 1d c5 bd 01 00 	mov    0x1bdc5(%rip),%rbx        # 1eb18 <fwp_heap+0x13d8>
    2d53:	48 39 d8             	cmp    %rbx,%rax
    2d56:	0f 83 57 01 00 00    	jae    2eb3 <fwp_heap_chunks+0x183>
    2d5c:	48 8b 0d d5 bd 01 00 	mov    0x1bdd5(%rip),%rcx        # 1eb38 <fwp_heap+0x13f8>
    2d63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2d67:	31 f6                	xor    %esi,%esi
    2d69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2d6d:	eb 1e                	jmp    2d8d <fwp_heap_chunks+0x5d>
    2d6f:	90                   	nop
    2d70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2d74:	48 39 cf             	cmp    %rcx,%rdi
    2d77:	0f 84 03 01 00 00    	je     2e80 <fwp_heap_chunks+0x150>
    2d7d:	48 83 c0 01          	add    $0x1,%rax
    2d81:	48 89 ce             	mov    %rcx,%rsi
    2d84:	48 83 c2 28          	add    $0x28,%rdx
    2d88:	48 39 c3             	cmp    %rax,%rbx
    2d8b:	74 14                	je     2da1 <fwp_heap_chunks+0x71>
    2d8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    2d90:	74 de                	je     2d70 <fwp_heap_chunks+0x40>
    2d92:	48 83 c0 01          	add    $0x1,%rax
    2d96:	31 f6                	xor    %esi,%esi
    2d98:	48 83 c2 28          	add    $0x28,%rdx
    2d9c:	48 39 c3             	cmp    %rax,%rbx
    2d9f:	75 ec                	jne    2d8d <fwp_heap_chunks+0x5d>
    2da1:	48 29 f3             	sub    %rsi,%rbx
    2da4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2da8:	48 8b 3d 71 bd 01 00 	mov    0x1bd71(%rip),%rdi        # 1eb20 <fwp_heap+0x13e0>
    2daf:	48 29 35 ba bd 01 00 	sub    %rsi,0x1bdba(%rip)        # 1eb70 <fwp_heap+0x1430>
    2db6:	48 39 ef             	cmp    %rbp,%rdi
    2db9:	0f 83 96 00 00 00    	jae    2e55 <fwp_heap_chunks+0x125>
    2dbf:	48 8b 05 4a bd 01 00 	mov    0x1bd4a(%rip),%rax        # 1eb10 <fwp_heap+0x13d0>
    2dc6:	48 39 e8             	cmp    %rbp,%rax
    2dc9:	0f 82 eb 00 00 00    	jb     2eba <fwp_heap_chunks+0x18a>
    2dcf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2dd3:	ba 03 00 00 00       	mov    $0x3,%edx
    2dd8:	49 39 c4             	cmp    %rax,%r12
    2ddb:	4c 0f 47 e0          	cmova  %rax,%r12
    2ddf:	4c 89 e6             	mov    %r12,%rsi
    2de2:	48 29 fe             	sub    %rdi,%rsi
    2de5:	48 c1 e7 10          	shl    $0x10,%rdi
    2de9:	48 03 3d 00 bd 01 00 	add    0x1bd00(%rip),%rdi        # 1eaf0 <fwp_heap+0x13b0>
    2df0:	48 c1 e6 10          	shl    $0x10,%rsi
    2df4:	e8 e7 f7 ff ff       	call   25e0 <mprotect@plt>
    2df9:	85 c0                	test   %eax,%eax
    2dfb:	0f 85 b9 00 00 00    	jne    2eba <fwp_heap_chunks+0x18a>
    2e01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e06:	e8 f5 f7 ff ff       	call   2600 <sysconf@plt>
    2e0b:	48 8b 35 0e bd 01 00 	mov    0x1bd0e(%rip),%rsi        # 1eb20 <fwp_heap+0x13e0>
    2e12:	48 89 c1             	mov    %rax,%rcx
    2e15:	48 8b 05 1c bd 01 00 	mov    0x1bd1c(%rip),%rax        # 1eb38 <fwp_heap+0x13f8>
    2e1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e20:	48 89 ca             	mov    %rcx,%rdx
    2e23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e2b:	48 f7 da             	neg    %rdx
    2e2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2e33:	48 21 d7             	and    %rdx,%rdi
    2e36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2e3a:	48 21 d6             	and    %rdx,%rsi
    2e3d:	ba 03 00 00 00       	mov    $0x3,%edx
    2e42:	48 29 fe             	sub    %rdi,%rsi
    2e45:	e8 96 f7 ff ff       	call   25e0 <mprotect@plt>
    2e4a:	85 c0                	test   %eax,%eax
    2e4c:	75 6c                	jne    2eba <fwp_heap_chunks+0x18a>
    2e4e:	4c 89 25 cb bc 01 00 	mov    %r12,0x1bccb(%rip)        # 1eb20 <fwp_heap+0x13e0>
    2e55:	48 89 ef             	mov    %rbp,%rdi
    2e58:	48 89 2d b9 bc 01 00 	mov    %rbp,0x1bcb9(%rip)        # 1eb18 <fwp_heap+0x13d8>
    2e5f:	48 c1 e7 10          	shl    $0x10,%rdi
    2e63:	48 39 3d 9e bc 01 00 	cmp    %rdi,0x1bc9e(%rip)        # 1eb08 <fwp_heap+0x13c8>
    2e6a:	73 07                	jae    2e73 <fwp_heap_chunks+0x143>
    2e6c:	48 89 3d 95 bc 01 00 	mov    %rdi,0x1bc95(%rip)        # 1eb08 <fwp_heap+0x13c8>
    2e73:	48 89 d8             	mov    %rbx,%rax
    2e76:	5b                   	pop    %rbx
    2e77:	5d                   	pop    %rbp
    2e78:	41 5c                	pop    %r12
    2e7a:	c3                   	ret
    2e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2e84:	48 29 f0             	sub    %rsi,%rax
    2e87:	48 89 c3             	mov    %rax,%rbx
    2e8a:	49 89 10             	mov    %rdx,(%r8)
    2e8d:	48 89 d8             	mov    %rbx,%rax
    2e90:	48 29 3d d9 bc 01 00 	sub    %rdi,0x1bcd9(%rip)        # 1eb70 <fwp_heap+0x1430>
    2e97:	5b                   	pop    %rbx
    2e98:	5d                   	pop    %rbp
    2e99:	41 5c                	pop    %r12
    2e9b:	c3                   	ret
    2e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    2ea0:	48 8b 05 81 bc 01 00 	mov    0x1bc81(%rip),%rax        # 1eb28 <fwp_heap+0x13e8>
    2ea7:	4c 8d 05 7a bc 01 00 	lea    0x1bc7a(%rip),%r8        # 1eb28 <fwp_heap+0x13e8>
    2eae:	e9 99 fe ff ff       	jmp    2d4c <fwp_heap_chunks+0x1c>
    2eb3:	31 f6                	xor    %esi,%esi
    2eb5:	e9 ea fe ff ff       	jmp    2da4 <fwp_heap_chunks+0x74>
    2eba:	e8 41 fd ff ff       	call   2c00 <fwp_heap_oom>
    2ebf:	90                   	nop

0000000000002ec0 <buf_grow>:
    2ec0:	48 83 ec 18          	sub    $0x18,%rsp
    2ec4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ec8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2ecc:	74 7e                	je     2f4c <buf_grow+0x8c>
    2ece:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2ed5:	48 29 c2             	sub    %rax,%rdx
    2ed8:	48 39 f2             	cmp    %rsi,%rdx
    2edb:	72 6f                	jb     2f4c <buf_grow+0x8c>
    2edd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2ee2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2ee6:	48 89 f9             	mov    %rdi,%rcx
    2ee9:	48 39 d0             	cmp    %rdx,%rax
    2eec:	73 48                	jae    2f36 <buf_grow+0x76>
    2eee:	48 85 c0             	test   %rax,%rax
    2ef1:	75 15                	jne    2f08 <buf_grow+0x48>
    2ef3:	48 83 fa 40          	cmp    $0x40,%rdx
    2ef7:	76 4c                	jbe    2f45 <buf_grow+0x85>
    2ef9:	b8 40 00 00 00       	mov    $0x40,%eax
    2efe:	eb 08                	jmp    2f08 <buf_grow+0x48>
    2f00:	48 01 c0             	add    %rax,%rax
    2f03:	48 39 d0             	cmp    %rdx,%rax
    2f06:	73 38                	jae    2f40 <buf_grow+0x80>
    2f08:	48 85 c0             	test   %rax,%rax
    2f0b:	79 f3                	jns    2f00 <buf_grow+0x40>
    2f0d:	48 8b 39             	mov    (%rcx),%rdi
    2f10:	48 89 d6             	mov    %rdx,%rsi
    2f13:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2f18:	48 89 14 24          	mov    %rdx,(%rsp)
    2f1c:	e8 7f f6 ff ff       	call   25a0 <realloc@plt>
    2f21:	48 8b 14 24          	mov    (%rsp),%rdx
    2f25:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2f2a:	48 85 c0             	test   %rax,%rax
    2f2d:	74 1d                	je     2f4c <buf_grow+0x8c>
    2f2f:	48 89 01             	mov    %rax,(%rcx)
    2f32:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2f36:	48 83 c4 18          	add    $0x18,%rsp
    2f3a:	c3                   	ret
    2f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2f40:	48 89 c2             	mov    %rax,%rdx
    2f43:	eb c8                	jmp    2f0d <buf_grow+0x4d>
    2f45:	ba 40 00 00 00       	mov    $0x40,%edx
    2f4a:	eb c1                	jmp    2f0d <buf_grow+0x4d>
    2f4c:	48 8b 0d 4d a1 00 00 	mov    0xa14d(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    2f53:	ba 13 00 00 00       	mov    $0x13,%edx
    2f58:	be 01 00 00 00       	mov    $0x1,%esi
    2f5d:	48 8d 3d a4 80 00 00 	lea    0x80a4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    2f64:	e8 d7 f6 ff ff       	call   2640 <fwrite@plt>
    2f69:	31 ff                	xor    %edi,%edi
    2f6b:	e8 20 f6 ff ff       	call   2590 <fflush@plt>
    2f70:	bf 66 00 00 00       	mov    $0x66,%edi
    2f75:	e8 e6 f6 ff ff       	call   2660 <_Exit@plt>
    2f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002f80 <buf_put>:
    2f80:	41 54                	push   %r12
    2f82:	49 89 f4             	mov    %rsi,%r12
    2f85:	48 89 d6             	mov    %rdx,%rsi
    2f88:	55                   	push   %rbp
    2f89:	48 89 fd             	mov    %rdi,%rbp
    2f8c:	53                   	push   %rbx
    2f8d:	48 89 d3             	mov    %rdx,%rbx
    2f90:	e8 2b ff ff ff       	call   2ec0 <buf_grow>
    2f95:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    2f99:	48 89 da             	mov    %rbx,%rdx
    2f9c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    2fa0:	4c 89 e6             	mov    %r12,%rsi
    2fa3:	e8 c8 f5 ff ff       	call   2570 <memcpy@plt>
    2fa8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2fac:	48 03 5d 08          	add    0x8(%rbp),%rbx
    2fb0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    2fb4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    2fb8:	5b                   	pop    %rbx
    2fb9:	5d                   	pop    %rbp
    2fba:	41 5c                	pop    %r12
    2fbc:	c3                   	ret
    2fbd:	0f 1f 00             	nopl   (%rax)

0000000000002fc0 <fwp_cancel_tree.part.0>:
    2fc0:	48 3b 3d 59 a7 01 00 	cmp    0x1a759(%rip),%rdi        # 1d720 <fwp_cur>
    2fc7:	53                   	push   %rbx
    2fc8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    2fcc:	74 35                	je     3003 <fwp_cancel_tree.part.0+0x43>
    2fce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    2fd2:	75 2f                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fd4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    2fd8:	75 29                	jne    3003 <fwp_cancel_tree.part.0+0x43>
    2fda:	48 8b 05 1f a7 01 00 	mov    0x1a71f(%rip),%rax        # 1d700 <fwp_ready_tail>
    2fe1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    2fe5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    2fec:	00 00 00 00 
    2ff0:	48 85 c0             	test   %rax,%rax
    2ff3:	74 33                	je     3028 <fwp_cancel_tree.part.0+0x68>
    2ff5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    2ffc:	48 89 3d fd a6 01 00 	mov    %rdi,0x1a6fd(%rip)        # 1d700 <fwp_ready_tail>
    3003:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    3007:	48 85 db             	test   %rbx,%rbx
    300a:	74 17                	je     3023 <fwp_cancel_tree.part.0+0x63>
    300c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    3010:	75 08                	jne    301a <fwp_cancel_tree.part.0+0x5a>
    3012:	48 89 df             	mov    %rbx,%rdi
    3015:	e8 a6 ff ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    301a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    301e:	48 85 db             	test   %rbx,%rbx
    3021:	75 e9                	jne    300c <fwp_cancel_tree.part.0+0x4c>
    3023:	5b                   	pop    %rbx
    3024:	c3                   	ret
    3025:	0f 1f 00             	nopl   (%rax)
    3028:	48 89 3d d9 a6 01 00 	mov    %rdi,0x1a6d9(%rip)        # 1d708 <fwp_ready_head>
    302f:	eb cb                	jmp    2ffc <fwp_cancel_tree.part.0+0x3c>
    3031:	0f 1f 40 00          	nopl   0x0(%rax)
    3035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    303c:	00 00 00 00 

0000000000003040 <fwp_finish_float>:
    3040:	53                   	push   %rbx
    3041:	be 2e 00 00 00       	mov    $0x2e,%esi
    3046:	48 89 fb             	mov    %rdi,%rbx
    3049:	e8 12 f4 ff ff       	call   2460 <strchr@plt>
    304e:	48 85 c0             	test   %rax,%rax
    3051:	74 05                	je     3058 <fwp_finish_float+0x18>
    3053:	5b                   	pop    %rbx
    3054:	c3                   	ret
    3055:	0f 1f 00             	nopl   (%rax)
    3058:	be 65 00 00 00       	mov    $0x65,%esi
    305d:	48 89 df             	mov    %rbx,%rdi
    3060:	e8 fb f3 ff ff       	call   2460 <strchr@plt>
    3065:	48 85 c0             	test   %rax,%rax
    3068:	75 e9                	jne    3053 <fwp_finish_float+0x13>
    306a:	48 8d 35 51 80 00 00 	lea    0x8051(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    3071:	48 89 df             	mov    %rbx,%rdi
    3074:	e8 17 f6 ff ff       	call   2690 <strstr@plt>
    3079:	48 85 c0             	test   %rax,%rax
    307c:	75 d5                	jne    3053 <fwp_finish_float+0x13>
    307e:	48 8d 35 97 7f 00 00 	lea    0x7f97(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    3085:	48 89 df             	mov    %rbx,%rdi
    3088:	e8 03 f6 ff ff       	call   2690 <strstr@plt>
    308d:	48 85 c0             	test   %rax,%rax
    3090:	75 c1                	jne    3053 <fwp_finish_float+0x13>
    3092:	48 89 df             	mov    %rbx,%rdi
    3095:	e8 96 f3 ff ff       	call   2430 <strlen@plt>
    309a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    309f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    30a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    30a8:	5b                   	pop    %rbx
    30a9:	c3                   	ret
    30aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000030b0 <fwp_trap>:
    30b0:	53                   	push   %rbx
    30b1:	48 89 fb             	mov    %rdi,%rbx
    30b4:	e8 07 fb ff ff       	call   2bc0 <fwp_flush>
    30b9:	48 89 d9             	mov    %rbx,%rcx
    30bc:	be 02 00 00 00       	mov    $0x2,%esi
    30c1:	31 c0                	xor    %eax,%eax
    30c3:	48 8b 3d d6 9f 00 00 	mov    0x9fd6(%rip),%rdi        # d0a0 <stderr@GLIBC_2.2.5>
    30ca:	48 8d 15 4f 7f 00 00 	lea    0x7f4f(%rip),%rdx        # b020 <_IO_stdin_used+0x20>
    30d1:	e8 7a f5 ff ff       	call   2650 <__fprintf_chk@plt>
    30d6:	bf 65 00 00 00       	mov    $0x65,%edi
    30db:	e8 50 f5 ff ff       	call   2630 <exit@plt>

00000000000030e0 <fwp_now_ns>:
    30e0:	53                   	push   %rbx
    30e1:	bf 01 00 00 00       	mov    $0x1,%edi
    30e6:	48 83 ec 20          	sub    $0x20,%rsp
    30ea:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    30f1:	00 00 
    30f3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    30f8:	31 db                	xor    %ebx,%ebx
    30fa:	48 89 e6             	mov    %rsp,%rsi
    30fd:	e8 fe f2 ff ff       	call   2400 <clock_gettime@plt>
    3102:	85 c0                	test   %eax,%eax
    3104:	75 52                	jne    3158 <fwp_now_ns+0x78>
    3106:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    310b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3110:	48 f7 2c 24          	imulq  (%rsp)
    3114:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    311b:	48 89 f7             	mov    %rsi,%rdi
    311e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    3122:	48 01 f0             	add    %rsi,%rax
    3125:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    312c:	00 00 80 
    312f:	48 11 fa             	adc    %rdi,%rdx
    3132:	31 ff                	xor    %edi,%edi
    3134:	48 01 c6             	add    %rax,%rsi
    3137:	48 11 d7             	adc    %rdx,%rdi
    313a:	48 39 f1             	cmp    %rsi,%rcx
    313d:	48 19 fb             	sbb    %rdi,%rbx
    3140:	72 27                	jb     3169 <fwp_now_ns+0x89>
    3142:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3147:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    314e:	00 00 
    3150:	75 12                	jne    3164 <fwp_now_ns+0x84>
    3152:	48 83 c4 20          	add    $0x20,%rsp
    3156:	5b                   	pop    %rbx
    3157:	c3                   	ret
    3158:	48 8d 3d d0 7e 00 00 	lea    0x7ed0(%rip),%rdi        # b02f <_IO_stdin_used+0x2f>
    315f:	e8 4c ff ff ff       	call   30b0 <fwp_trap>
    3164:	e8 d7 f2 ff ff       	call   2440 <__stack_chk_fail@plt>
    3169:	48 8d 3d 30 80 00 00 	lea    0x8030(%rip),%rdi        # b1a0 <_IO_stdin_used+0x1a0>
    3170:	e8 3b ff ff ff       	call   30b0 <fwp_trap>
    3175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    317c:	00 00 00 00 

0000000000003180 <fwp_format_g.constprop.0>:
    3180:	41 57                	push   %r15
    3182:	b9 40 00 00 00       	mov    $0x40,%ecx
    3187:	ba 02 00 00 00       	mov    $0x2,%edx
    318c:	4c 8d 05 b8 7e 00 00 	lea    0x7eb8(%rip),%r8        # b04b <_IO_stdin_used+0x4b>
    3193:	41 56                	push   %r14
    3195:	b8 01 00 00 00       	mov    $0x1,%eax
    319a:	41 55                	push   %r13
    319c:	41 54                	push   %r12
    319e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    31a2:	55                   	push   %rbp
    31a3:	45 89 e1             	mov    %r12d,%r9d
    31a6:	53                   	push   %rbx
    31a7:	48 89 fb             	mov    %rdi,%rbx
    31aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    31b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    31b8:	00 00 
    31ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    31c1:	00 
    31c2:	41 89 f7             	mov    %esi,%r15d
    31c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    31ca:	be 40 00 00 00       	mov    $0x40,%esi
    31cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    31d4:	4c 89 f7             	mov    %r14,%rdi
    31d7:	e8 b4 f1 ff ff       	call   2390 <__snprintf_chk@plt>
    31dc:	be 65 00 00 00       	mov    $0x65,%esi
    31e1:	4c 89 f7             	mov    %r14,%rdi
    31e4:	e8 77 f2 ff ff       	call   2460 <strchr@plt>
    31e9:	31 f6                	xor    %esi,%esi
    31eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    31f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    31f4:	48 89 c5             	mov    %rax,%rbp
    31f7:	e8 64 f3 ff ff       	call   2560 <strtol@plt>
    31fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    3201:	49 89 c0             	mov    %rax,%r8
    3204:	83 c0 05             	add    $0x5,%eax
    3207:	83 f8 15             	cmp    $0x15,%eax
    320a:	0f 87 f0 01 00 00    	ja     3400 <fwp_format_g.constprop.0+0x280>
    3210:	45 89 e5             	mov    %r12d,%r13d
    3213:	45 29 c5             	sub    %r8d,%r13d
    3216:	45 85 ed             	test   %r13d,%r13d
    3219:	0f 8e 21 01 00 00    	jle    3340 <fwp_format_g.constprop.0+0x1c0>
    321f:	41 83 ff 01          	cmp    $0x1,%r15d
    3223:	0f 84 17 01 00 00    	je     3340 <fwp_format_g.constprop.0+0x1c0>
    3229:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    322e:	31 d2                	xor    %edx,%edx
    3230:	4d 63 df             	movslq %r15d,%r11
    3233:	3c 2d                	cmp    $0x2d,%al
    3235:	0f 94 c2             	sete   %dl
    3238:	4c 29 dd             	sub    %r11,%rbp
    323b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    323f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3243:	4d 89 f1             	mov    %r14,%r9
    3246:	4d 29 d1             	sub    %r10,%r9
    3249:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    324d:	3c 2d                	cmp    $0x2d,%al
    324f:	0f 84 0b 04 00 00    	je     3660 <fwp_format_g.constprop.0+0x4e0>
    3255:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    325a:	b9 48 00 00 00       	mov    $0x48,%ecx
    325f:	48 89 e8             	mov    %rbp,%rax
    3262:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3266:	49 8d 72 01          	lea    0x1(%r10),%rsi
    326a:	49 83 c1 47          	add    $0x47,%r9
    326e:	45 85 c0             	test   %r8d,%r8d
    3271:	0f 88 01 03 00 00    	js     3578 <fwp_format_g.constprop.0+0x3f8>
    3277:	45 0f b6 12          	movzbl (%r10),%r10d
    327b:	4d 63 e0             	movslq %r8d,%r12
    327e:	44 88 10             	mov    %r10b,(%rax)
    3281:	41 83 f8 07          	cmp    $0x7,%r8d
    3285:	0f 87 3d 02 00 00    	ja     34c8 <fwp_format_g.constprop.0+0x348>
    328b:	41 f6 c4 04          	test   $0x4,%r12b
    328f:	0f 85 02 04 00 00    	jne    3697 <fwp_format_g.constprop.0+0x517>
    3295:	45 85 e4             	test   %r12d,%r12d
    3298:	74 12                	je     32ac <fwp_format_g.constprop.0+0x12c>
    329a:	45 0f b6 06          	movzbl (%r14),%r8d
    329e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    32a2:	41 f6 c4 02          	test   $0x2,%r12b
    32a6:	0f 85 13 04 00 00    	jne    36bf <fwp_format_g.constprop.0+0x53f>
    32ac:	4c 29 e1             	sub    %r12,%rcx
    32af:	4c 01 e7             	add    %r12,%rdi
    32b2:	4c 89 fa             	mov    %r15,%rdx
    32b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    32ba:	48 83 e9 01          	sub    $0x1,%rcx
    32be:	4d 63 ed             	movslq %r13d,%r13
    32c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    32c5:	e8 76 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    32cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    32d3:	ba 48 00 00 00       	mov    $0x48,%edx
    32d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    32dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    32e0:	4c 89 c8             	mov    %r9,%rax
    32e3:	48 29 c8             	sub    %rcx,%rax
    32e6:	48 39 d0             	cmp    %rdx,%rax
    32e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    32ed:	4c 29 c9             	sub    %r9,%rcx
    32f0:	4c 89 ea             	mov    %r13,%rdx
    32f3:	48 01 c1             	add    %rax,%rcx
    32f6:	e8 45 f2 ff ff       	call   2540 <__memcpy_chk@plt>
    32fb:	4c 01 e8             	add    %r13,%rax
    32fe:	48 29 e8             	sub    %rbp,%rax
    3301:	ba 8f 01 00 00       	mov    $0x18f,%edx
    3306:	48 39 d0             	cmp    %rdx,%rax
    3309:	48 0f 47 c2          	cmova  %rdx,%rax
    330d:	89 c1                	mov    %eax,%ecx
    330f:	83 f8 08             	cmp    $0x8,%eax
    3312:	0f 83 28 02 00 00    	jae    3540 <fwp_format_g.constprop.0+0x3c0>
    3318:	a8 04                	test   $0x4,%al
    331a:	0f 85 64 03 00 00    	jne    3684 <fwp_format_g.constprop.0+0x504>
    3320:	85 c0                	test   %eax,%eax
    3322:	74 0f                	je     3333 <fwp_format_g.constprop.0+0x1b3>
    3324:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    3329:	88 13                	mov    %dl,(%rbx)
    332b:	a8 02                	test   $0x2,%al
    332d:	0f 85 7b 03 00 00    	jne    36ae <fwp_format_g.constprop.0+0x52e>
    3333:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3337:	eb 36                	jmp    336f <fwp_format_g.constprop.0+0x1ef>
    3339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3340:	45 31 c9             	xor    %r9d,%r9d
    3343:	45 85 ed             	test   %r13d,%r13d
    3346:	4c 8d 05 0d 7d 00 00 	lea    0x7d0d(%rip),%r8        # b05a <_IO_stdin_used+0x5a>
    334d:	48 89 df             	mov    %rbx,%rdi
    3350:	45 0f 49 cd          	cmovns %r13d,%r9d
    3354:	ba 02 00 00 00       	mov    $0x2,%edx
    3359:	be 90 01 00 00       	mov    $0x190,%esi
    335e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	e8 21 f0 ff ff       	call   2390 <__snprintf_chk@plt>
    336f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3374:	48 89 df             	mov    %rbx,%rdi
    3377:	e8 e4 f0 ff ff       	call   2460 <strchr@plt>
    337c:	48 85 c0             	test   %rax,%rax
    337f:	74 4f                	je     33d0 <fwp_format_g.constprop.0+0x250>
    3381:	48 89 df             	mov    %rbx,%rdi
    3384:	e8 a7 f0 ff ff       	call   2430 <strlen@plt>
    3389:	48 85 c0             	test   %rax,%rax
    338c:	75 1b                	jne    33a9 <fwp_format_g.constprop.0+0x229>
    338e:	eb 40                	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    3390:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    339c:	00 00 00 00 
    33a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    33a4:	48 85 c0             	test   %rax,%rax
    33a7:	74 27                	je     33d0 <fwp_format_g.constprop.0+0x250>
    33a9:	48 89 c2             	mov    %rax,%rdx
    33ac:	48 83 e8 01          	sub    $0x1,%rax
    33b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    33b4:	74 ea                	je     33a0 <fwp_format_g.constprop.0+0x220>
    33b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    33bb:	0f 84 6f 01 00 00    	je     3530 <fwp_format_g.constprop.0+0x3b0>
    33c1:	0f 1f 40 00          	nopl   0x0(%rax)
    33c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    33cc:	00 00 00 00 
    33d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    33d7:	00 
    33d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    33df:	00 00 
    33e1:	0f 85 ec 02 00 00    	jne    36d3 <fwp_format_g.constprop.0+0x553>
    33e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    33ee:	5b                   	pop    %rbx
    33ef:	5d                   	pop    %rbp
    33f0:	41 5c                	pop    %r12
    33f2:	41 5d                	pop    %r13
    33f4:	41 5e                	pop    %r14
    33f6:	41 5f                	pop    %r15
    33f8:	c3                   	ret
    33f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3400:	4c 29 f5             	sub    %r14,%rbp
    3403:	b9 40 00 00 00       	mov    $0x40,%ecx
    3408:	4c 89 f6             	mov    %r14,%rsi
    340b:	4c 89 04 24          	mov    %r8,(%rsp)
    340f:	49 89 ec             	mov    %rbp,%r12
    3412:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3417:	4c 89 e2             	mov    %r12,%rdx
    341a:	48 89 ef             	mov    %rbp,%rdi
    341d:	e8 1e f1 ff ff       	call   2540 <__memcpy_chk@plt>
    3422:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    3428:	be 2e 00 00 00       	mov    $0x2e,%esi
    342d:	48 89 ef             	mov    %rbp,%rdi
    3430:	e8 2b f0 ff ff       	call   2460 <strchr@plt>
    3435:	4c 8b 04 24          	mov    (%rsp),%r8
    3439:	48 85 c0             	test   %rax,%rax
    343c:	74 40                	je     347e <fwp_format_g.constprop.0+0x2fe>
    343e:	4d 85 e4             	test   %r12,%r12
    3441:	74 3b                	je     347e <fwp_format_g.constprop.0+0x2fe>
    3443:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3448:	eb 23                	jmp    346d <fwp_format_g.constprop.0+0x2ed>
    344a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3451:	00 00 00 00 
    3455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    345c:	00 00 00 00 
    3460:	c6 00 00             	movb   $0x0,(%rax)
    3463:	48 83 e8 01          	sub    $0x1,%rax
    3467:	49 83 ec 01          	sub    $0x1,%r12
    346b:	74 11                	je     347e <fwp_format_g.constprop.0+0x2fe>
    346d:	80 38 30             	cmpb   $0x30,(%rax)
    3470:	74 ee                	je     3460 <fwp_format_g.constprop.0+0x2e0>
    3472:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3478:	0f 84 fb 01 00 00    	je     3679 <fwp_format_g.constprop.0+0x4f9>
    347e:	44 89 c0             	mov    %r8d,%eax
    3481:	ba 02 00 00 00       	mov    $0x2,%edx
    3486:	49 89 e9             	mov    %rbp,%r9
    3489:	be 90 01 00 00       	mov    $0x190,%esi
    348e:	f7 d8                	neg    %eax
    3490:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3497:	48 89 df             	mov    %rbx,%rdi
    349a:	41 0f 48 c0          	cmovs  %r8d,%eax
    349e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    34a2:	41 83 e0 02          	and    $0x2,%r8d
    34a6:	41 83 c0 2b          	add    $0x2b,%r8d
    34aa:	50                   	push   %rax
    34ab:	31 c0                	xor    %eax,%eax
    34ad:	41 50                	push   %r8
    34af:	4c 8d 05 9a 7b 00 00 	lea    0x7b9a(%rip),%r8        # b050 <_IO_stdin_used+0x50>
    34b6:	e8 d5 ee ff ff       	call   2390 <__snprintf_chk@plt>
    34bb:	58                   	pop    %rax
    34bc:	5a                   	pop    %rdx
    34bd:	e9 0e ff ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    34c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    34c8:	4d 8b 06             	mov    (%r14),%r8
    34cb:	48 83 c0 09          	add    $0x9,%rax
    34cf:	4c 89 f2             	mov    %r14,%rdx
    34d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    34d6:	4c 89 07             	mov    %r8,(%rdi)
    34d9:	45 89 e0             	mov    %r12d,%r8d
    34dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    34e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    34e6:	49 89 f8             	mov    %rdi,%r8
    34e9:	49 29 c0             	sub    %rax,%r8
    34ec:	4c 29 c2             	sub    %r8,%rdx
    34ef:	45 01 e0             	add    %r12d,%r8d
    34f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    34f6:	41 83 f8 08          	cmp    $0x8,%r8d
    34fa:	0f 82 ac fd ff ff    	jb     32ac <fwp_format_g.constprop.0+0x12c>
    3500:	48 89 0c 24          	mov    %rcx,(%rsp)
    3504:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    3508:	45 31 d2             	xor    %r10d,%r10d
    350b:	45 89 d3             	mov    %r10d,%r11d
    350e:	41 83 c2 08          	add    $0x8,%r10d
    3512:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    3516:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    351a:	45 39 c2             	cmp    %r8d,%r10d
    351d:	72 ec                	jb     350b <fwp_format_g.constprop.0+0x38b>
    351f:	48 8b 0c 24          	mov    (%rsp),%rcx
    3523:	e9 84 fd ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    3528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    352f:	00 
    3530:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    3535:	e9 96 fe ff ff       	jmp    33d0 <fwp_format_g.constprop.0+0x250>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3540:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3545:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3549:	48 89 ee             	mov    %rbp,%rsi
    354c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3550:	48 89 13             	mov    %rdx,(%rbx)
    3553:	89 c2                	mov    %eax,%edx
    3555:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    355a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    355f:	48 89 d9             	mov    %rbx,%rcx
    3562:	48 29 f9             	sub    %rdi,%rcx
    3565:	48 29 ce             	sub    %rcx,%rsi
    3568:	01 c1                	add    %eax,%ecx
    356a:	c1 e9 03             	shr    $0x3,%ecx
    356d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3570:	e9 be fd ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3575:	0f 1f 00             	nopl   (%rax)
    3578:	c6 00 30             	movb   $0x30,(%rax)
    357b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    357f:	4c 89 fa             	mov    %r15,%rdx
    3582:	4c 89 e9             	mov    %r13,%rcx
    3585:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    358a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    358f:	4c 89 14 24          	mov    %r10,(%rsp)
    3593:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3598:	e8 a3 ef ff ff       	call   2540 <__memcpy_chk@plt>
    359d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    35a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    35a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    35ac:	48 89 c7             	mov    %rax,%rdi
    35af:	4c 8b 14 24          	mov    (%rsp),%r10
    35b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    35b8:	4c 89 c8             	mov    %r9,%rax
    35bb:	4c 29 e8             	sub    %r13,%rax
    35be:	48 39 c8             	cmp    %rcx,%rax
    35c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    35c5:	4d 29 cd             	sub    %r9,%r13
    35c8:	49 01 ff             	add    %rdi,%r15
    35cb:	4c 01 e8             	add    %r13,%rax
    35ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    35d2:	74 3d                	je     3611 <fwp_format_g.constprop.0+0x491>
    35d4:	41 f7 d0             	not    %r8d
    35d7:	31 f6                	xor    %esi,%esi
    35d9:	ba 48 00 00 00       	mov    $0x48,%edx
    35de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    35e3:	48 39 d0             	cmp    %rdx,%rax
    35e6:	48 0f 43 d0          	cmovae %rax,%rdx
    35ea:	48 89 d1             	mov    %rdx,%rcx
    35ed:	48 29 c1             	sub    %rax,%rcx
    35f0:	48 83 c1 01          	add    $0x1,%rcx
    35f4:	48 39 d1             	cmp    %rdx,%rcx
    35f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    35fb:	48 83 e8 01          	sub    $0x1,%rax
    35ff:	48 83 c6 01          	add    $0x1,%rsi
    3603:	48 29 d0             	sub    %rdx,%rax
    3606:	48 01 c8             	add    %rcx,%rax
    3609:	41 39 f0             	cmp    %esi,%r8d
    360c:	7f cb                	jg     35d9 <fwp_format_g.constprop.0+0x459>
    360e:	4d 01 c7             	add    %r8,%r15
    3611:	b9 48 00 00 00       	mov    $0x48,%ecx
    3616:	41 0f b6 12          	movzbl (%r10),%edx
    361a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    361e:	4c 89 f6             	mov    %r14,%rsi
    3621:	48 39 c8             	cmp    %rcx,%rax
    3624:	4c 89 1c 24          	mov    %r11,(%rsp)
    3628:	48 0f 43 c8          	cmovae %rax,%rcx
    362c:	41 88 17             	mov    %dl,(%r15)
    362f:	48 89 ca             	mov    %rcx,%rdx
    3632:	48 29 c2             	sub    %rax,%rdx
    3635:	48 83 c2 01          	add    $0x1,%rdx
    3639:	48 39 ca             	cmp    %rcx,%rdx
    363c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3640:	48 83 e8 01          	sub    $0x1,%rax
    3644:	48 29 c8             	sub    %rcx,%rax
    3647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    364b:	49 63 d4             	movslq %r12d,%rdx
    364e:	e8 ed ee ff ff       	call   2540 <__memcpy_chk@plt>
    3653:	4c 8b 1c 24          	mov    (%rsp),%r11
    3657:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    365b:	e9 9e fc ff ff       	jmp    32fe <fwp_format_g.constprop.0+0x17e>
    3660:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3665:	b9 47 00 00 00       	mov    $0x47,%ecx
    366a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    366f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3674:	e9 e9 fb ff ff       	jmp    3262 <fwp_format_g.constprop.0+0xe2>
    3679:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    367f:	e9 fa fd ff ff       	jmp    347e <fwp_format_g.constprop.0+0x2fe>
    3684:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3688:	89 13                	mov    %edx,(%rbx)
    368a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    368e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3692:	e9 9c fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    3697:	41 8b 06             	mov    (%r14),%eax
    369a:	89 07                	mov    %eax,(%rdi)
    369c:	44 89 e0             	mov    %r12d,%eax
    369f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    36a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    36a9:	e9 fe fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36ae:	89 c2                	mov    %eax,%edx
    36b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    36b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    36ba:	e9 74 fc ff ff       	jmp    3333 <fwp_format_g.constprop.0+0x1b3>
    36bf:	44 89 e0             	mov    %r12d,%eax
    36c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    36c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    36ce:	e9 d9 fb ff ff       	jmp    32ac <fwp_format_g.constprop.0+0x12c>
    36d3:	e8 68 ed ff ff       	call   2440 <__stack_chk_fail@plt>
    36d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36df:	00 

00000000000036e0 <fwp_heap_report>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	41 54                	push   %r12
    36e6:	48 8d 3d 72 79 00 00 	lea    0x7972(%rip),%rdi        # b05f <_IO_stdin_used+0x5f>
    36ed:	55                   	push   %rbp
    36ee:	53                   	push   %rbx
    36ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    36f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    36fd:	00 00 
    36ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    3706:	00 
    3707:	48 8d 35 fc 79 00 00 	lea    0x79fc(%rip),%rsi        # b10a <_IO_stdin_used+0x10a>
    370e:	e8 dd ee ff ff       	call   25f0 <fopen@plt>
    3713:	48 85 c0             	test   %rax,%rax
    3716:	0f 84 c5 00 00 00    	je     37e1 <fwp_heap_report+0x101>
    371c:	48 89 c5             	mov    %rax,%rbp
    371f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    3726:	48 89 e3             	mov    %rsp,%rbx
    3729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3730:	48 89 ea             	mov    %rbp,%rdx
    3733:	be 00 01 00 00       	mov    $0x100,%esi
    3738:	48 89 df             	mov    %rbx,%rdi
    373b:	e8 a0 ed ff ff       	call   24e0 <fgets@plt>
    3740:	48 85 c0             	test   %rax,%rax
    3743:	74 2b                	je     3770 <fwp_heap_report+0x90>
    3745:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    374b:	75 e3                	jne    3730 <fwp_heap_report+0x50>
    374d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3751:	75 dd                	jne    3730 <fwp_heap_report+0x50>
    3753:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3758:	75 d6                	jne    3730 <fwp_heap_report+0x50>
    375a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    375f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3764:	31 f6                	xor    %esi,%esi
    3766:	e8 f5 ed ff ff       	call   2560 <strtol@plt>
    376b:	49 89 c4             	mov    %rax,%r12
    376e:	eb c0                	jmp    3730 <fwp_heap_report+0x50>
    3770:	48 89 ef             	mov    %rbp,%rdi
    3773:	e8 a8 ec ff ff       	call   2420 <fclose@plt>
    3778:	48 83 ec 08          	sub    $0x8,%rsp
    377c:	4c 8b 0d 85 b3 01 00 	mov    0x1b385(%rip),%r9        # 1eb08 <fwp_heap+0x13c8>
    3783:	4c 8b 05 de b3 01 00 	mov    0x1b3de(%rip),%r8        # 1eb68 <fwp_heap+0x1428>
    378a:	48 8d 15 3f 7a 00 00 	lea    0x7a3f(%rip),%rdx        # b1d0 <_IO_stdin_used+0x1d0>
    3791:	41 54                	push   %r12
    3793:	48 8b 0d c6 b3 01 00 	mov    0x1b3c6(%rip),%rcx        # 1eb60 <fwp_heap+0x1420>
    379a:	be 02 00 00 00       	mov    $0x2,%esi
    379f:	b8 02 00 00 00       	mov    $0x2,%eax
    37a4:	f2 0f 10 0d d4 b3 01 	movsd  0x1b3d4(%rip),%xmm1        # 1eb80 <fwp_heap+0x1440>
    37ab:	00 
    37ac:	f2 0f 10 05 c4 b3 01 	movsd  0x1b3c4(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    37b3:	00 
    37b4:	48 8b 3d e5 98 00 00 	mov    0x98e5(%rip),%rdi        # d0a0 <stderr@GLIBC_2.2.5>
    37bb:	e8 90 ee ff ff       	call   2650 <__fprintf_chk@plt>
    37c0:	58                   	pop    %rax
    37c1:	5a                   	pop    %rdx
    37c2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    37c9:	00 
    37ca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    37d1:	00 00 
    37d3:	75 15                	jne    37ea <fwp_heap_report+0x10a>
    37d5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    37dc:	5b                   	pop    %rbx
    37dd:	5d                   	pop    %rbp
    37de:	41 5c                	pop    %r12
    37e0:	c3                   	ret
    37e1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    37e8:	eb 8e                	jmp    3778 <fwp_heap_report+0x98>
    37ea:	e8 51 ec ff ff       	call   2440 <__stack_chk_fail@plt>
    37ef:	90                   	nop

00000000000037f0 <fwp_heap_init>:
    37f0:	66 0f 6f 05 68 7c 00 	movdqa 0x7c68(%rip),%xmm0        # b460 <msg.3+0x20>
    37f7:	00 
    37f8:	41 54                	push   %r12
    37fa:	48 8d 05 7f ae 01 00 	lea    0x1ae7f(%rip),%rax        # 1e680 <fwp_heap+0xf40>
    3801:	ba 00 01 00 00       	mov    $0x100,%edx
    3806:	55                   	push   %rbp
    3807:	66 0f 6f 15 91 7c 00 	movdqa 0x7c91(%rip),%xmm2        # b4a0 <msg.3+0x60>
    380e:	00 
    380f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    3813:	53                   	push   %rbx
    3814:	0f 29 05 25 ae 01 00 	movaps %xmm0,0x1ae25(%rip)        # 1e640 <fwp_heap+0xf00>
    381b:	66 0f 6f 05 4d 7c 00 	movdqa 0x7c4d(%rip),%xmm0        # b470 <msg.3+0x30>
    3822:	00 
    3823:	66 0f 6f da          	movdqa %xmm2,%xmm3
    3827:	c7 05 b3 b2 01 00 01 	movl   $0x1,0x1b2b3(%rip)        # 1eae4 <fwp_heap+0x13a4>
    382e:	00 00 00 
    3831:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    3836:	0f 29 05 13 ae 01 00 	movaps %xmm0,0x1ae13(%rip)        # 1e650 <fwp_heap+0xf10>
    383d:	66 0f 6f 05 3b 7c 00 	movdqa 0x7c3b(%rip),%xmm0        # b480 <msg.3+0x40>
    3844:	00 
    3845:	0f 29 05 14 ae 01 00 	movaps %xmm0,0x1ae14(%rip)        # 1e660 <fwp_heap+0xf20>
    384c:	66 0f 6f 05 3c 7c 00 	movdqa 0x7c3c(%rip),%xmm0        # b490 <msg.3+0x50>
    3853:	00 
    3854:	0f 29 05 15 ae 01 00 	movaps %xmm0,0x1ae15(%rip)        # 1e670 <fwp_heap+0xf30>
    385b:	89 d3                	mov    %edx,%ebx
    385d:	66 0f 6e e2          	movd   %edx,%xmm4
    3861:	48 83 c0 10          	add    $0x10,%rax
    3865:	01 d2                	add    %edx,%edx
    3867:	c1 eb 02             	shr    $0x2,%ebx
    386a:	66 0f 6e c3          	movd   %ebx,%xmm0
    386e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3873:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3877:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    387c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3880:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3884:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3889:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    388e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3892:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3897:	66 0f fe c1          	paddd  %xmm1,%xmm0
    389b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    389f:	48 39 c7             	cmp    %rax,%rdi
    38a2:	75 b7                	jne    385b <fwp_heap_init+0x6b>
    38a4:	4c 8d 05 95 9e 01 00 	lea    0x19e95(%rip),%r8        # 1d740 <fwp_heap>
    38ab:	31 c9                	xor    %ecx,%ecx
    38ad:	31 c0                	xor    %eax,%eax
    38af:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    38b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    38bd:	00 00 00 
    38c0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    38c7:	00 
    38c8:	48 39 ca             	cmp    %rcx,%rdx
    38cb:	73 0f                	jae    38dc <fwp_heap_init+0xec>
    38cd:	0f 1f 00             	nopl   (%rax)
    38d0:	48 83 c0 01          	add    $0x1,%rax
    38d4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    38d7:	48 39 ca             	cmp    %rcx,%rdx
    38da:	72 f4                	jb     38d0 <fwp_heap_init+0xe0>
    38dc:	48 83 c1 10          	add    $0x10,%rcx
    38e0:	88 07                	mov    %al,(%rdi)
    38e2:	48 83 c7 01          	add    $0x1,%rdi
    38e6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    38ed:	75 d1                	jne    38c0 <fwp_heap_init+0xd0>
    38ef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    38f6:	00 00 00 
    38f9:	bd 05 00 00 00       	mov    $0x5,%ebp
    38fe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3905:	45 31 c9             	xor    %r9d,%r9d
    3908:	31 d2                	xor    %edx,%edx
    390a:	31 ff                	xor    %edi,%edi
    390c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3912:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3917:	4c 89 e6             	mov    %r12,%rsi
    391a:	e8 31 eb ff ff       	call   2450 <mmap@plt>
    391f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3923:	75 13                	jne    3938 <fwp_heap_init+0x148>
    3925:	48 c1 eb 02          	shr    $0x2,%rbx
    3929:	83 ed 01             	sub    $0x1,%ebp
    392c:	75 d0                	jne    38fe <fwp_heap_init+0x10e>
    392e:	e8 cd f2 ff ff       	call   2c00 <fwp_heap_oom>
    3933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3938:	48 85 c0             	test   %rax,%rax
    393b:	74 f1                	je     392e <fwp_heap_init+0x13e>
    393d:	48 c1 eb 10          	shr    $0x10,%rbx
    3941:	48 89 05 b0 b1 01 00 	mov    %rax,0x1b1b0(%rip)        # 1eaf8 <fwp_heap+0x13b8>
    3948:	45 31 c9             	xor    %r9d,%r9d
    394b:	31 d2                	xor    %edx,%edx
    394d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3953:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3957:	31 ff                	xor    %edi,%edi
    3959:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    395f:	66 31 c0             	xor    %ax,%ax
    3962:	48 c1 e6 03          	shl    $0x3,%rsi
    3966:	b9 22 40 00 00       	mov    $0x4022,%ecx
    396b:	4c 89 25 8e b1 01 00 	mov    %r12,0x1b18e(%rip)        # 1eb00 <fwp_heap+0x13c0>
    3972:	48 89 05 77 b1 01 00 	mov    %rax,0x1b177(%rip)        # 1eaf0 <fwp_heap+0x13b0>
    3979:	48 89 1d 90 b1 01 00 	mov    %rbx,0x1b190(%rip)        # 1eb10 <fwp_heap+0x13d0>
    3980:	48 89 35 b9 b1 01 00 	mov    %rsi,0x1b1b9(%rip)        # 1eb40 <fwp_heap+0x1400>
    3987:	e8 c4 ea ff ff       	call   2450 <mmap@plt>
    398c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3990:	74 9c                	je     392e <fwp_heap_init+0x13e>
    3992:	48 8d 3d fc 76 00 00 	lea    0x76fc(%rip),%rdi        # b095 <_IO_stdin_used+0x95>
    3999:	48 89 05 98 b1 01 00 	mov    %rax,0x1b198(%rip)        # 1eb38 <fwp_heap+0x13f8>
    39a0:	e8 db e9 ff ff       	call   2380 <getenv@plt>
    39a5:	48 89 c2             	mov    %rax,%rdx
    39a8:	31 c0                	xor    %eax,%eax
    39aa:	48 85 d2             	test   %rdx,%rdx
    39ad:	74 15                	je     39c4 <fwp_heap_init+0x1d4>
    39af:	80 3a 00             	cmpb   $0x0,(%rdx)
    39b2:	74 10                	je     39c4 <fwp_heap_init+0x1d4>
    39b4:	0f b6 02             	movzbl (%rdx),%eax
    39b7:	83 e8 30             	sub    $0x30,%eax
    39ba:	74 13                	je     39cf <fwp_heap_init+0x1df>
    39bc:	85 c0                	test   %eax,%eax
    39be:	0f 95 c0             	setne  %al
    39c1:	0f b6 c0             	movzbl %al,%eax
    39c4:	5b                   	pop    %rbx
    39c5:	5d                   	pop    %rbp
    39c6:	89 05 1c b1 01 00    	mov    %eax,0x1b11c(%rip)        # 1eae8 <fwp_heap+0x13a8>
    39cc:	41 5c                	pop    %r12
    39ce:	c3                   	ret
    39cf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    39d3:	85 c0                	test   %eax,%eax
    39d5:	0f 95 c0             	setne  %al
    39d8:	0f b6 c0             	movzbl %al,%eax
    39db:	eb e7                	jmp    39c4 <fwp_heap_init+0x1d4>
    39dd:	0f 1f 00             	nopl   (%rax)

00000000000039e0 <fwp_wake_io>:
    39e0:	48 8b 07             	mov    (%rdi),%rax
    39e3:	48 85 c0             	test   %rax,%rax
    39e6:	0f 84 f4 00 00 00    	je     3ae0 <fwp_wake_io+0x100>
    39ec:	53                   	push   %rbx
    39ed:	4c 8b 05 0c 9d 01 00 	mov    0x19d0c(%rip),%r8        # 1d700 <fwp_ready_tail>
    39f4:	49 89 f9             	mov    %rdi,%r9
    39f7:	48 89 c2             	mov    %rax,%rdx
    39fa:	45 31 db             	xor    %r11d,%r11d
    39fd:	45 31 d2             	xor    %r10d,%r10d
    3a00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3a04:	eb 71                	jmp    3a77 <fwp_wake_io+0x97>
    3a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a0d:	00 00 00 
    3a10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3a17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a1e:	48 85 c9             	test   %rcx,%rcx
    3a21:	74 07                	je     3a2a <fwp_wake_io+0x4a>
    3a23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3a2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3a31:	00 00 00 00 
    3a35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3a3c:	49 8b 01             	mov    (%r9),%rax
    3a3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3a43:	75 2a                	jne    3a6f <fwp_wake_io+0x8f>
    3a45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3a49:	75 24                	jne    3a6f <fwp_wake_io+0x8f>
    3a4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3a4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3a56:	00 00 00 00 
    3a5a:	4d 85 c0             	test   %r8,%r8
    3a5d:	74 51                	je     3ab0 <fwp_wake_io+0xd0>
    3a5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3a66:	49 89 d0             	mov    %rdx,%r8
    3a69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3a6f:	48 89 c2             	mov    %rax,%rdx
    3a72:	48 85 c0             	test   %rax,%rax
    3a75:	74 49                	je     3ac0 <fwp_wake_io+0xe0>
    3a77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3a7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3a82:	48 85 ff             	test   %rdi,%rdi
    3a85:	74 b8                	je     3a3f <fwp_wake_io+0x5f>
    3a87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3a8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3a95:	48 85 f6             	test   %rsi,%rsi
    3a98:	0f 85 72 ff ff ff    	jne    3a10 <fwp_wake_io+0x30>
    3a9e:	48 89 0f             	mov    %rcx,(%rdi)
    3aa1:	e9 78 ff ff ff       	jmp    3a1e <fwp_wake_io+0x3e>
    3aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aad:	00 00 00 
    3ab0:	48 89 d3             	mov    %rdx,%rbx
    3ab3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3ab9:	eb ab                	jmp    3a66 <fwp_wake_io+0x86>
    3abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ac0:	45 84 db             	test   %r11b,%r11b
    3ac3:	74 07                	je     3acc <fwp_wake_io+0xec>
    3ac5:	48 89 1d 3c 9c 01 00 	mov    %rbx,0x19c3c(%rip)        # 1d708 <fwp_ready_head>
    3acc:	45 84 d2             	test   %r10b,%r10b
    3acf:	74 07                	je     3ad8 <fwp_wake_io+0xf8>
    3ad1:	4c 89 05 28 9c 01 00 	mov    %r8,0x19c28(%rip)        # 1d700 <fwp_ready_tail>
    3ad8:	5b                   	pop    %rbx
    3ad9:	c3                   	ret
    3ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ae0:	c3                   	ret
    3ae1:	0f 1f 40 00          	nopl   0x0(%rax)
    3ae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3aec:	00 00 00 00 

0000000000003af0 <fwp_poll_events>:
    3af0:	53                   	push   %rbx
    3af1:	48 83 ec 20          	sub    $0x20,%rsp
    3af5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3afc:	00 00 
    3afe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3b03:	31 c0                	xor    %eax,%eax
    3b05:	e8 d6 f5 ff ff       	call   30e0 <fwp_now_ns>
    3b0a:	48 8b 1d e7 9b 01 00 	mov    0x19be7(%rip),%rbx        # 1d6f8 <fwp_timers>
    3b11:	48 85 db             	test   %rbx,%rbx
    3b14:	0f 84 e6 00 00 00    	je     3c00 <fwp_poll_events+0x110>
    3b1a:	48 89 c6             	mov    %rax,%rsi
    3b1d:	48 89 da             	mov    %rbx,%rdx
    3b20:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3b27:	eb 26                	jmp    3b4f <fwp_poll_events+0x5f>
    3b29:	90                   	nop
    3b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b31:	00 00 00 00 
    3b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b3c:	00 00 00 00 
    3b40:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b47:	48 89 c8             	mov    %rcx,%rax
    3b4a:	48 85 d2             	test   %rdx,%rdx
    3b4d:	74 31                	je     3b80 <fwp_poll_events+0x90>
    3b4f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b53:	48 85 c0             	test   %rax,%rax
    3b56:	78 e8                	js     3b40 <fwp_poll_events+0x50>
    3b58:	48 39 c1             	cmp    %rax,%rcx
    3b5b:	7c e3                	jl     3b40 <fwp_poll_events+0x50>
    3b5d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b64:	48 85 d2             	test   %rdx,%rdx
    3b67:	74 1c                	je     3b85 <fwp_poll_events+0x95>
    3b69:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3b6d:	48 39 c1             	cmp    %rax,%rcx
    3b70:	7c ce                	jl     3b40 <fwp_poll_events+0x50>
    3b72:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3b79:	48 85 d2             	test   %rdx,%rdx
    3b7c:	75 d1                	jne    3b4f <fwp_poll_events+0x5f>
    3b7e:	66 90                	xchg   %ax,%ax
    3b80:	48 85 c0             	test   %rax,%rax
    3b83:	78 7b                	js     3c00 <fwp_poll_events+0x110>
    3b85:	48 29 f0             	sub    %rsi,%rax
    3b88:	48 89 c1             	mov    %rax,%rcx
    3b8b:	48 85 c0             	test   %rax,%rax
    3b8e:	0f 8e 9c 00 00 00    	jle    3c30 <fwp_poll_events+0x140>
    3b94:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3b9b:	de 1b 43 
    3b9e:	48 f7 ea             	imul   %rdx
    3ba1:	48 89 c8             	mov    %rcx,%rax
    3ba4:	48 c1 f8 3f          	sar    $0x3f,%rax
    3ba8:	48 c1 fa 12          	sar    $0x12,%rdx
    3bac:	48 29 c2             	sub    %rax,%rdx
    3baf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3bb6:	48 39 c1             	cmp    %rax,%rcx
    3bb9:	0f 95 c0             	setne  %al
    3bbc:	0f b6 c0             	movzbl %al,%eax
    3bbf:	48 01 d0             	add    %rdx,%rax
    3bc2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3bc8:	0f 8f 32 01 00 00    	jg     3d00 <fwp_poll_events+0x210>
    3bce:	48 85 c0             	test   %rax,%rax
    3bd1:	74 5d                	je     3c30 <fwp_poll_events+0x140>
    3bd3:	89 c1                	mov    %eax,%ecx
    3bd5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3bdc:	48 c1 e9 26          	shr    $0x26,%rcx
    3be0:	48 63 d1             	movslq %ecx,%rdx
    3be3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3be9:	29 c8                	sub    %ecx,%eax
    3beb:	48 98                	cltq
    3bed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3bf4:	e9 11 01 00 00       	jmp    3d0a <fwp_poll_events+0x21a>
    3bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3c00:	e8 bb ef ff ff       	call   2bc0 <fwp_flush>
    3c05:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3c0a:	be 01 00 00 00       	mov    $0x1,%esi
    3c0f:	48 8b 0d 8a 94 00 00 	mov    0x948a(%rip),%rcx        # d0a0 <stderr@GLIBC_2.2.5>
    3c16:	48 8d 3d 3b 76 00 00 	lea    0x763b(%rip),%rdi        # b258 <_IO_stdin_used+0x258>
    3c1d:	e8 1e ea ff ff       	call   2640 <fwrite@plt>
    3c22:	bf 65 00 00 00       	mov    $0x65,%edi
    3c27:	e8 04 ea ff ff       	call   2630 <exit@plt>
    3c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    3c30:	e8 ab f4 ff ff       	call   30e0 <fwp_now_ns>
    3c35:	48 89 c1             	mov    %rax,%rcx
    3c38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3c3c:	eb 44                	jmp    3c82 <fwp_poll_events+0x192>
    3c3e:	66 90                	xchg   %ax,%ax
    3c40:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c44:	75 33                	jne    3c79 <fwp_poll_events+0x189>
    3c46:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c4a:	75 2d                	jne    3c79 <fwp_poll_events+0x189>
    3c4c:	48 8b 05 ad 9a 01 00 	mov    0x19aad(%rip),%rax        # 1d700 <fwp_ready_tail>
    3c53:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c57:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c5e:	00 00 00 00 
    3c62:	48 85 c0             	test   %rax,%rax
    3c65:	0f 84 05 01 00 00    	je     3d70 <fwp_poll_events+0x280>
    3c6b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3c72:	48 89 15 87 9a 01 00 	mov    %rdx,0x19a87(%rip)        # 1d700 <fwp_ready_tail>
    3c79:	48 85 db             	test   %rbx,%rbx
    3c7c:	0f 84 be 00 00 00    	je     3d40 <fwp_poll_events+0x250>
    3c82:	48 89 da             	mov    %rbx,%rdx
    3c85:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3c8c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3c90:	7f e7                	jg     3c79 <fwp_poll_events+0x189>
    3c92:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3c96:	74 2e                	je     3cc6 <fwp_poll_events+0x1d6>
    3c98:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3c9f:	48 85 c0             	test   %rax,%rax
    3ca2:	0f 84 b8 00 00 00    	je     3d60 <fwp_poll_events+0x270>
    3ca8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3caf:	48 85 db             	test   %rbx,%rbx
    3cb2:	74 07                	je     3cbb <fwp_poll_events+0x1cb>
    3cb4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3cbb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3cbf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3cc6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3cca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3cce:	48 85 c0             	test   %rax,%rax
    3cd1:	0f 84 69 ff ff ff    	je     3c40 <fwp_poll_events+0x150>
    3cd7:	48 39 c8             	cmp    %rcx,%rax
    3cda:	0f 8f 60 ff ff ff    	jg     3c40 <fwp_poll_events+0x150>
    3ce0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ce4:	0f 85 56 ff ff ff    	jne    3c40 <fwp_poll_events+0x150>
    3cea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3cee:	75 89                	jne    3c79 <fwp_poll_events+0x189>
    3cf0:	48 89 d7             	mov    %rdx,%rdi
    3cf3:	e8 c8 f2 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    3cf8:	e9 43 ff ff ff       	jmp    3c40 <fwp_poll_events+0x150>
    3cfd:	0f 1f 00             	nopl   (%rax)
    3d00:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3d05:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3d0a:	48 89 e7             	mov    %rsp,%rdi
    3d0d:	31 f6                	xor    %esi,%esi
    3d0f:	48 89 14 24          	mov    %rdx,(%rsp)
    3d13:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3d18:	e8 63 e7 ff ff       	call   2480 <nanosleep@plt>
    3d1d:	48 8b 1d d4 99 01 00 	mov    0x199d4(%rip),%rbx        # 1d6f8 <fwp_timers>
    3d24:	e8 b7 f3 ff ff       	call   30e0 <fwp_now_ns>
    3d29:	48 89 c1             	mov    %rax,%rcx
    3d2c:	48 85 db             	test   %rbx,%rbx
    3d2f:	0f 85 03 ff ff ff    	jne    3c38 <fwp_poll_events+0x148>
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 
    3d40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3d45:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3d4c:	00 00 
    3d4e:	75 2c                	jne    3d7c <fwp_poll_events+0x28c>
    3d50:	48 83 c4 20          	add    $0x20,%rsp
    3d54:	5b                   	pop    %rbx
    3d55:	c3                   	ret
    3d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d5d:	00 00 00 
    3d60:	48 89 1d 91 99 01 00 	mov    %rbx,0x19991(%rip)        # 1d6f8 <fwp_timers>
    3d67:	e9 43 ff ff ff       	jmp    3caf <fwp_poll_events+0x1bf>
    3d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    3d70:	48 89 15 91 99 01 00 	mov    %rdx,0x19991(%rip)        # 1d708 <fwp_ready_head>
    3d77:	e9 f6 fe ff ff       	jmp    3c72 <fwp_poll_events+0x182>
    3d7c:	e8 bf e6 ff ff       	call   2440 <__stack_chk_fail@plt>
    3d81:	0f 1f 40 00          	nopl   0x0(%rax)
    3d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d8c:	00 00 00 00 

0000000000003d90 <fwp_rc_forget_slot>:
    3d90:	80 3f ff             	cmpb   $0xff,(%rdi)
    3d93:	74 0b                	je     3da0 <fwp_rc_forget_slot+0x10>
    3d95:	c3                   	ret
    3d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3d9d:	00 00 00 
    3da0:	48 89 f8             	mov    %rdi,%rax
    3da3:	48 83 ec 08          	sub    $0x8,%rsp
    3da7:	48 89 fa             	mov    %rdi,%rdx
    3daa:	48 c1 e8 11          	shr    $0x11,%rax
    3dae:	48 31 f8             	xor    %rdi,%rax
    3db1:	48 89 c1             	mov    %rax,%rcx
    3db4:	48 c1 e9 09          	shr    $0x9,%rcx
    3db8:	48 31 c8             	xor    %rcx,%rax
    3dbb:	48 8d 0d 7e 99 01 00 	lea    0x1997e(%rip),%rcx        # 1d740 <fwp_heap>
    3dc2:	0f b6 c0             	movzbl %al,%eax
    3dc5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    3dcc:	00 
    3dcd:	48 85 ff             	test   %rdi,%rdi
    3dd0:	74 3c                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3dd2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    3dd9:	00 
    3dda:	48 8b 01             	mov    (%rcx),%rax
    3ddd:	eb 11                	jmp    3df0 <fwp_rc_forget_slot+0x60>
    3ddf:	90                   	nop
    3de0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3de4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    3de8:	48 85 ff             	test   %rdi,%rdi
    3deb:	74 21                	je     3e0e <fwp_rc_forget_slot+0x7e>
    3ded:	48 89 f8             	mov    %rdi,%rax
    3df0:	48 3b 10             	cmp    (%rax),%rdx
    3df3:	75 eb                	jne    3de0 <fwp_rc_forget_slot+0x50>
    3df5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3df9:	48 89 01             	mov    %rax,(%rcx)
    3dfc:	e8 9f e5 ff ff       	call   23a0 <free@plt>
    3e01:	48 83 2d 7f b5 01 00 	subq   $0x1,0x1b57f(%rip)        # 1f388 <fwp_heap+0x1c48>
    3e08:	01 
    3e09:	48 83 c4 08          	add    $0x8,%rsp
    3e0d:	c3                   	ret
    3e0e:	48 8d 3d 73 74 00 00 	lea    0x7473(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    3e15:	e8 96 f2 ff ff       	call   30b0 <fwp_trap>
    3e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003e20 <fwp_rc_prepare_chunk>:
    3e20:	48 83 3d 60 b5 01 00 	cmpq   $0x0,0x1b560(%rip)        # 1f388 <fwp_heap+0x1c48>
    3e27:	00 
    3e28:	41 54                	push   %r12
    3e2a:	49 89 f4             	mov    %rsi,%r12
    3e2d:	55                   	push   %rbp
    3e2e:	48 89 fd             	mov    %rdi,%rbp
    3e31:	53                   	push   %rbx
    3e32:	8b 47 1c             	mov    0x1c(%rdi),%eax
    3e35:	0f 84 7d 00 00 00    	je     3eb8 <fwp_rc_prepare_chunk+0x98>
    3e3b:	31 db                	xor    %ebx,%ebx
    3e3d:	85 c0                	test   %eax,%eax
    3e3f:	75 5f                	jne    3ea0 <fwp_rc_prepare_chunk+0x80>
    3e41:	48 85 f6             	test   %rsi,%rsi
    3e44:	74 7c                	je     3ec2 <fwp_rc_prepare_chunk+0xa2>
    3e46:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    3e4a:	e8 51 e5 ff ff       	call   23a0 <free@plt>
    3e4f:	90                   	nop
    3e50:	be 01 00 00 00       	mov    $0x1,%esi
    3e55:	4c 89 e7             	mov    %r12,%rdi
    3e58:	e8 a3 e6 ff ff       	call   2500 <calloc@plt>
    3e5d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    3e61:	48 85 c0             	test   %rax,%rax
    3e64:	0f 85 87 00 00 00    	jne    3ef1 <fwp_rc_prepare_chunk+0xd1>
    3e6a:	e8 91 ed ff ff       	call   2c00 <fwp_heap_oom>
    3e6f:	90                   	nop
    3e70:	e8 1b ff ff ff       	call   3d90 <fwp_rc_forget_slot>
    3e75:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3e78:	48 83 c3 01          	add    $0x1,%rbx
    3e7c:	48 39 c3             	cmp    %rax,%rbx
    3e7f:	73 37                	jae    3eb8 <fwp_rc_prepare_chunk+0x98>
    3e81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3e88:	00 00 
    3e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e91:	00 00 00 00 
    3e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e9c:	00 00 00 00 
    3ea0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ea4:	48 01 df             	add    %rbx,%rdi
    3ea7:	80 3f ff             	cmpb   $0xff,(%rdi)
    3eaa:	74 c4                	je     3e70 <fwp_rc_prepare_chunk+0x50>
    3eac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    3eaf:	48 83 c3 01          	add    $0x1,%rbx
    3eb3:	48 39 c3             	cmp    %rax,%rbx
    3eb6:	72 e8                	jb     3ea0 <fwp_rc_prepare_chunk+0x80>
    3eb8:	49 39 c4             	cmp    %rax,%r12
    3ebb:	75 13                	jne    3ed0 <fwp_rc_prepare_chunk+0xb0>
    3ebd:	4d 85 e4             	test   %r12,%r12
    3ec0:	75 46                	jne    3f08 <fwp_rc_prepare_chunk+0xe8>
    3ec2:	5b                   	pop    %rbx
    3ec3:	5d                   	pop    %rbp
    3ec4:	41 5c                	pop    %r12
    3ec6:	c3                   	ret
    3ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3ece:	00 00 
    3ed0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3ed4:	48 29 05 b5 b4 01 00 	sub    %rax,0x1b4b5(%rip)        # 1f390 <fwp_heap+0x1c50>
    3edb:	e8 c0 e4 ff ff       	call   23a0 <free@plt>
    3ee0:	4d 85 e4             	test   %r12,%r12
    3ee3:	0f 85 67 ff ff ff    	jne    3e50 <fwp_rc_prepare_chunk+0x30>
    3ee9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    3ef0:	00 
    3ef1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    3ef5:	5b                   	pop    %rbx
    3ef6:	4c 01 25 93 b4 01 00 	add    %r12,0x1b493(%rip)        # 1f390 <fwp_heap+0x1c50>
    3efd:	5d                   	pop    %rbp
    3efe:	41 5c                	pop    %r12
    3f00:	c3                   	ret
    3f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    3f0c:	5b                   	pop    %rbx
    3f0d:	4c 89 e2             	mov    %r12,%rdx
    3f10:	31 f6                	xor    %esi,%esi
    3f12:	5d                   	pop    %rbp
    3f13:	41 5c                	pop    %r12
    3f15:	e9 86 e5 ff ff       	jmp    24a0 <memset@plt>
    3f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003f20 <fwp_heap_refill>:
    3f20:	41 56                	push   %r14
    3f22:	41 89 d6             	mov    %edx,%r14d
    3f25:	41 55                	push   %r13
    3f27:	41 89 f5             	mov    %esi,%r13d
    3f2a:	41 54                	push   %r12
    3f2c:	49 89 fc             	mov    %rdi,%r12
    3f2f:	bf 01 00 00 00       	mov    $0x1,%edi
    3f34:	55                   	push   %rbp
    3f35:	53                   	push   %rbx
    3f36:	e8 f5 ed ff ff       	call   2d30 <fwp_heap_chunks>
    3f3b:	48 89 c3             	mov    %rax,%rbx
    3f3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f42:	48 8b 05 ef ab 01 00 	mov    0x1abef(%rip),%rax        # 1eb38 <fwp_heap+0x13f8>
    3f49:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    3f4d:	48 8d 05 ec 97 01 00 	lea    0x197ec(%rip),%rax        # 1d740 <fwp_heap>
    3f54:	31 d2                	xor    %edx,%edx
    3f56:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    3f5a:	48 89 ef             	mov    %rbp,%rdi
    3f5d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    3f61:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    3f65:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    3f6c:	00 
    3f6d:	b8 00 00 01 00       	mov    $0x10000,%eax
    3f72:	f7 f1                	div    %ecx
    3f74:	31 d2                	xor    %edx,%edx
    3f76:	66 0f 6e c1          	movd   %ecx,%xmm0
    3f7a:	66 0f 6e c8          	movd   %eax,%xmm1
    3f7e:	89 c6                	mov    %eax,%esi
    3f80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3f85:	48 01 c8             	add    %rcx,%rax
    3f88:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    3f8c:	48 f7 f1             	div    %rcx
    3f8f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    3f94:	89 45 18             	mov    %eax,0x18(%rbp)
    3f97:	e8 84 fe ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    3f9c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    3f9f:	48 89 d8             	mov    %rbx,%rax
    3fa2:	48 c1 e0 10          	shl    $0x10,%rax
    3fa6:	48 03 05 43 ab 01 00 	add    0x1ab43(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    3fad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    3fb1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    3fb6:	8b 55 08             	mov    0x8(%rbp),%edx
    3fb9:	48 0f af d1          	imul   %rcx,%rdx
    3fbd:	48 01 c2             	add    %rax,%rdx
    3fc0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    3fc5:	5b                   	pop    %rbx
    3fc6:	5d                   	pop    %rbp
    3fc7:	41 5c                	pop    %r12
    3fc9:	41 5d                	pop    %r13
    3fcb:	41 5e                	pop    %r14
    3fcd:	c3                   	ret
    3fce:	66 90                	xchg   %ax,%ax

0000000000003fd0 <fwp_mem_free>:
    3fd0:	48 85 ff             	test   %rdi,%rdi
    3fd3:	0f 84 17 02 00 00    	je     41f0 <fwp_mem_free+0x220>
    3fd9:	48 8b 35 10 ab 01 00 	mov    0x1ab10(%rip),%rsi        # 1eaf0 <fwp_heap+0x13b0>
    3fe0:	48 8b 05 31 ab 01 00 	mov    0x1ab31(%rip),%rax        # 1eb18 <fwp_heap+0x13d8>
    3fe7:	48 89 fa             	mov    %rdi,%rdx
    3fea:	48 29 f2             	sub    %rsi,%rdx
    3fed:	48 c1 e0 10          	shl    $0x10,%rax
    3ff1:	48 39 c2             	cmp    %rax,%rdx
    3ff4:	0f 83 f6 01 00 00    	jae    41f0 <fwp_mem_free+0x220>
    3ffa:	49 89 d1             	mov    %rdx,%r9
    3ffd:	49 c1 e9 10          	shr    $0x10,%r9
    4001:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4005:	48 c1 e0 03          	shl    $0x3,%rax
    4009:	49 89 c0             	mov    %rax,%r8
    400c:	4c 03 05 25 ab 01 00 	add    0x1ab25(%rip),%r8        # 1eb38 <fwp_heap+0x13f8>
    4013:	0f 84 d7 01 00 00    	je     41f0 <fwp_mem_free+0x220>
    4019:	48 83 ec 38          	sub    $0x38,%rsp
    401d:	48 89 f9             	mov    %rdi,%rcx
    4020:	41 0f b6 38          	movzbl (%r8),%edi
    4024:	40 80 ff 01          	cmp    $0x1,%dil
    4028:	74 16                	je     4040 <fwp_mem_free+0x70>
    402a:	40 80 ff 02          	cmp    $0x2,%dil
    402e:	0f 84 94 00 00 00    	je     40c8 <fwp_mem_free+0xf8>
    4034:	48 83 c4 38          	add    $0x38,%rsp
    4038:	c3                   	ret
    4039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4040:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4044:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4049:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    404e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4052:	4d 85 d2             	test   %r10,%r10
    4055:	74 1d                	je     4074 <fwp_mem_free+0xa4>
    4057:	0f b7 c1             	movzwl %cx,%eax
    405a:	31 d2                	xor    %edx,%edx
    405c:	48 f7 f7             	div    %rdi
    405f:	49 01 c2             	add    %rax,%r10
    4062:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4066:	0f 84 44 01 00 00    	je     41b0 <fwp_mem_free+0x1e0>
    406c:	41 c6 02 00          	movb   $0x0,(%r10)
    4070:	41 8b 78 04          	mov    0x4(%r8),%edi
    4074:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    407b:	49 63 c1             	movslq %r9d,%rax
    407e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4082:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4086:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    408b:	f2 0f 58 05 ed aa 01 	addsd  0x1aaed(%rip),%xmm0        # 1eb80 <fwp_heap+0x1440>
    4092:	00 
    4093:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4097:	48 8d 05 a2 96 01 00 	lea    0x196a2(%rip),%rax        # 1d740 <fwp_heap>
    409e:	48 01 d0             	add    %rdx,%rax
    40a1:	48 8b 10             	mov    (%rax),%rdx
    40a4:	48 f7 d2             	not    %rdx
    40a7:	48 89 11             	mov    %rdx,(%rcx)
    40aa:	48 89 08             	mov    %rcx,(%rax)
    40ad:	48 29 3d ac aa 01 00 	sub    %rdi,0x1aaac(%rip)        # 1eb60 <fwp_heap+0x1420>
    40b4:	f2 0f 11 05 c4 aa 01 	movsd  %xmm0,0x1aac4(%rip)        # 1eb80 <fwp_heap+0x1440>
    40bb:	00 
    40bc:	48 83 c4 38          	add    $0x38,%rsp
    40c0:	c3                   	ret
    40c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    40c8:	66 31 d2             	xor    %dx,%dx
    40cb:	48 01 d6             	add    %rdx,%rsi
    40ce:	48 39 f1             	cmp    %rsi,%rcx
    40d1:	0f 85 5d ff ff ff    	jne    4034 <fwp_mem_free+0x64>
    40d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    40db:	48 29 15 7e aa 01 00 	sub    %rdx,0x1aa7e(%rip)        # 1eb60 <fwp_heap+0x1420>
    40e2:	48 85 d2             	test   %rdx,%rdx
    40e5:	0f 88 a5 00 00 00    	js     4190 <fwp_mem_free+0x1c0>
    40eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    40f4:	f2 0f 58 05 84 aa 01 	addsd  0x1aa84(%rip),%xmm0        # 1eb80 <fwp_heap+0x1440>
    40fb:	00 
    40fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4100:	f2 0f 11 05 78 aa 01 	movsd  %xmm0,0x1aa78(%rip)        # 1eb80 <fwp_heap+0x1440>
    4107:	00 
    4108:	48 85 d2             	test   %rdx,%rdx
    410b:	74 0c                	je     4119 <fwp_mem_free+0x149>
    410d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4110:	0f 84 db 00 00 00    	je     41f1 <fwp_mem_free+0x221>
    4116:	c6 02 00             	movb   $0x0,(%rdx)
    4119:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    411d:	48 85 c9             	test   %rcx,%rcx
    4120:	74 3e                	je     4160 <fwp_mem_free+0x190>
    4122:	48 8b 15 0f aa 01 00 	mov    0x1aa0f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    4129:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    412d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4131:	48 01 d0             	add    %rdx,%rax
    4134:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4138:	48 89 d6             	mov    %rdx,%rsi
    413b:	48 29 c6             	sub    %rax,%rsi
    413e:	83 e6 08             	and    $0x8,%esi
    4141:	74 0d                	je     4150 <fwp_mem_free+0x180>
    4143:	c6 00 00             	movb   $0x0,(%rax)
    4146:	48 83 c0 28          	add    $0x28,%rax
    414a:	48 39 c2             	cmp    %rax,%rdx
    414d:	74 11                	je     4160 <fwp_mem_free+0x190>
    414f:	90                   	nop
    4150:	c6 00 00             	movb   $0x0,(%rax)
    4153:	48 83 c0 50          	add    $0x50,%rax
    4157:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    415b:	48 39 c2             	cmp    %rax,%rdx
    415e:	75 f0                	jne    4150 <fwp_mem_free+0x180>
    4160:	48 01 0d 09 aa 01 00 	add    %rcx,0x1aa09(%rip)        # 1eb70 <fwp_heap+0x1430>
    4167:	4c 3b 0d c2 a9 01 00 	cmp    0x1a9c2(%rip),%r9        # 1eb30 <fwp_heap+0x13f0>
    416e:	73 07                	jae    4177 <fwp_mem_free+0x1a7>
    4170:	4c 89 0d b9 a9 01 00 	mov    %r9,0x1a9b9(%rip)        # 1eb30 <fwp_heap+0x13f0>
    4177:	4c 3b 0d aa a9 01 00 	cmp    0x1a9aa(%rip),%r9        # 1eb28 <fwp_heap+0x13e8>
    417e:	0f 83 b0 fe ff ff    	jae    4034 <fwp_mem_free+0x64>
    4184:	4c 89 0d 9d a9 01 00 	mov    %r9,0x1a99d(%rip)        # 1eb28 <fwp_heap+0x13e8>
    418b:	e9 a4 fe ff ff       	jmp    4034 <fwp_mem_free+0x64>
    4190:	48 89 d1             	mov    %rdx,%rcx
    4193:	83 e2 01             	and    $0x1,%edx
    4196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    419a:	48 d1 e9             	shr    $1,%rcx
    419d:	48 09 d1             	or     %rdx,%rcx
    41a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    41a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    41a9:	e9 46 ff ff ff       	jmp    40f4 <fwp_mem_free+0x124>
    41ae:	66 90                	xchg   %ax,%ax
    41b0:	4c 89 d7             	mov    %r10,%rdi
    41b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    41b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    41bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    41c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    41c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    41cb:	e8 c0 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    41d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    41d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    41da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    41df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    41e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    41e9:	e9 7e fe ff ff       	jmp    406c <fwp_mem_free+0x9c>
    41ee:	66 90                	xchg   %ax,%ax
    41f0:	c3                   	ret
    41f1:	48 89 d7             	mov    %rdx,%rdi
    41f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    41f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    41fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4203:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4208:	e8 83 fb ff ff       	call   3d90 <fwp_rc_forget_slot>
    420d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4212:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4217:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    421c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4221:	e9 f0 fe ff ff       	jmp    4116 <fwp_mem_free+0x146>
    4226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    422d:	00 00 00 

0000000000004230 <fwp_heap_alloc_big>:
    4230:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4237:	00 00 40 
    423a:	41 57                	push   %r15
    423c:	41 56                	push   %r14
    423e:	41 55                	push   %r13
    4240:	41 54                	push   %r12
    4242:	55                   	push   %rbp
    4243:	53                   	push   %rbx
    4244:	48 83 ec 08          	sub    $0x8,%rsp
    4248:	48 39 f8             	cmp    %rdi,%rax
    424b:	0f 82 fa 00 00 00    	jb     434b <fwp_heap_alloc_big+0x11b>
    4251:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4258:	49 89 fd             	mov    %rdi,%r13
    425b:	41 89 f6             	mov    %esi,%r14d
    425e:	48 c1 ed 10          	shr    $0x10,%rbp
    4262:	48 89 ef             	mov    %rbp,%rdi
    4265:	e8 c6 ea ff ff       	call   2d30 <fwp_heap_chunks>
    426a:	be 01 00 00 00       	mov    $0x1,%esi
    426f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4273:	49 89 c4             	mov    %rax,%r12
    4276:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    427d:	00 
    427e:	48 03 3d b3 a8 01 00 	add    0x1a8b3(%rip),%rdi        # 1eb38 <fwp_heap+0x13f8>
    4285:	c6 07 02             	movb   $0x2,(%rdi)
    4288:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    428c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    428f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4293:	e8 88 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    4298:	48 83 fd 01          	cmp    $0x1,%rbp
    429c:	76 47                	jbe    42e5 <fwp_heap_alloc_big+0xb5>
    429e:	4c 01 e5             	add    %r12,%rbp
    42a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    42a8:	00 
    42a9:	4c 8d 3d 90 94 01 00 	lea    0x19490(%rip),%r15        # 1d740 <fwp_heap>
    42b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    42b5:	49 c1 e6 03          	shl    $0x3,%r14
    42b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    42c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    42c7:	31 f6                	xor    %esi,%esi
    42c9:	48 01 dd             	add    %rbx,%rbp
    42cc:	48 83 c3 28          	add    $0x28,%rbx
    42d0:	48 89 ef             	mov    %rbp,%rdi
    42d3:	e8 48 fb ff ff       	call   3e20 <fwp_rc_prepare_chunk>
    42d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    42dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    42e0:	49 39 de             	cmp    %rbx,%r14
    42e3:	75 db                	jne    42c0 <fwp_heap_alloc_big+0x90>
    42e5:	49 c1 e4 10          	shl    $0x10,%r12
    42e9:	4c 03 25 00 a8 01 00 	add    0x1a800(%rip),%r12        # 1eaf0 <fwp_heap+0x13b0>
    42f0:	4c 89 ea             	mov    %r13,%rdx
    42f3:	31 f6                	xor    %esi,%esi
    42f5:	4c 89 e7             	mov    %r12,%rdi
    42f8:	e8 a3 e1 ff ff       	call   24a0 <memset@plt>
    42fd:	4c 89 e8             	mov    %r13,%rax
    4300:	48 03 05 59 a8 01 00 	add    0x1a859(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    4307:	72 42                	jb     434b <fwp_heap_alloc_big+0x11b>
    4309:	48 39 05 58 a8 01 00 	cmp    %rax,0x1a858(%rip)        # 1eb68 <fwp_heap+0x1428>
    4310:	48 89 05 49 a8 01 00 	mov    %rax,0x1a849(%rip)        # 1eb60 <fwp_heap+0x1420>
    4317:	73 07                	jae    4320 <fwp_heap_alloc_big+0xf0>
    4319:	48 89 05 48 a8 01 00 	mov    %rax,0x1a848(%rip)        # 1eb68 <fwp_heap+0x1428>
    4320:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4324:	4c 89 e0             	mov    %r12,%rax
    4327:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    432c:	f2 0f 58 05 44 a8 01 	addsd  0x1a844(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    4333:	00 
    4334:	f2 0f 11 05 3c a8 01 	movsd  %xmm0,0x1a83c(%rip)        # 1eb78 <fwp_heap+0x1438>
    433b:	00 
    433c:	48 83 c4 08          	add    $0x8,%rsp
    4340:	5b                   	pop    %rbx
    4341:	5d                   	pop    %rbp
    4342:	41 5c                	pop    %r12
    4344:	41 5d                	pop    %r13
    4346:	41 5e                	pop    %r14
    4348:	41 5f                	pop    %r15
    434a:	c3                   	ret
    434b:	e8 b0 e8 ff ff       	call   2c00 <fwp_heap_oom>

0000000000004350 <fwp_heap_alloc_slow>:
    4350:	53                   	push   %rbx
    4351:	48 89 f9             	mov    %rdi,%rcx
    4354:	41 89 f1             	mov    %esi,%r9d
    4357:	48 83 ec 10          	sub    $0x10,%rsp
    435b:	8b 05 83 a7 01 00    	mov    0x1a783(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4361:	85 c0                	test   %eax,%eax
    4363:	0f 84 c7 00 00 00    	je     4430 <fwp_heap_alloc_slow+0xe0>
    4369:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4370:	0f 87 dd 00 00 00    	ja     4453 <fwp_heap_alloc_slow+0x103>
    4376:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    437a:	48 8d 3d bf 93 01 00 	lea    0x193bf(%rip),%rdi        # 1d740 <fwp_heap>
    4381:	49 63 f1             	movslq %r9d,%rsi
    4384:	48 c1 e8 04          	shr    $0x4,%rax
    4388:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    438f:	00 00 
    4391:	41 0f b6 c2          	movzbl %r10b,%eax
    4395:	4c 89 d2             	mov    %r10,%rdx
    4398:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    439c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    43a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    43aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    43ae:	48 01 f8             	add    %rdi,%rax
    43b1:	4c 8b 00             	mov    (%rax),%r8
    43b4:	4d 85 c0             	test   %r8,%r8
    43b7:	0f 84 ab 00 00 00    	je     4468 <fwp_heap_alloc_slow+0x118>
    43bd:	49 8b 10             	mov    (%r8),%rdx
    43c0:	48 f7 d2             	not    %rdx
    43c3:	48 89 10             	mov    %rdx,(%rax)
    43c6:	41 83 f9 01          	cmp    $0x1,%r9d
    43ca:	4c 89 c7             	mov    %r8,%rdi
    43cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    43d1:	31 f6                	xor    %esi,%esi
    43d3:	48 89 ca             	mov    %rcx,%rdx
    43d6:	e8 c5 e0 ff ff       	call   24a0 <memset@plt>
    43db:	49 89 c0             	mov    %rax,%r8
    43de:	48 89 d8             	mov    %rbx,%rax
    43e1:	48 03 05 78 a7 01 00 	add    0x1a778(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    43e8:	0f 82 d9 00 00 00    	jb     44c7 <fwp_heap_alloc_slow+0x177>
    43ee:	48 39 05 73 a7 01 00 	cmp    %rax,0x1a773(%rip)        # 1eb68 <fwp_heap+0x1428>
    43f5:	48 89 05 64 a7 01 00 	mov    %rax,0x1a764(%rip)        # 1eb60 <fwp_heap+0x1420>
    43fc:	73 07                	jae    4405 <fwp_heap_alloc_slow+0xb5>
    43fe:	48 89 05 63 a7 01 00 	mov    %rax,0x1a763(%rip)        # 1eb68 <fwp_heap+0x1428>
    4405:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4409:	4c 89 c0             	mov    %r8,%rax
    440c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4411:	f2 0f 58 05 5f a7 01 	addsd  0x1a75f(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    4418:	00 
    4419:	f2 0f 11 05 57 a7 01 	movsd  %xmm0,0x1a757(%rip)        # 1eb78 <fwp_heap+0x1438>
    4420:	00 
    4421:	48 83 c4 10          	add    $0x10,%rsp
    4425:	5b                   	pop    %rbx
    4426:	c3                   	ret
    4427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    442e:	00 00 
    4430:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4434:	48 89 3c 24          	mov    %rdi,(%rsp)
    4438:	e8 b3 f3 ff ff       	call   37f0 <fwp_heap_init>
    443d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4441:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4446:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    444d:	0f 86 23 ff ff ff    	jbe    4376 <fwp_heap_alloc_slow+0x26>
    4453:	48 83 c4 10          	add    $0x10,%rsp
    4457:	44 89 ce             	mov    %r9d,%esi
    445a:	48 89 cf             	mov    %rcx,%rdi
    445d:	5b                   	pop    %rbx
    445e:	e9 cd fd ff ff       	jmp    4230 <fwp_heap_alloc_big>
    4463:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4468:	4c 8b 40 08          	mov    0x8(%rax),%r8
    446c:	4d 85 c0             	test   %r8,%r8
    446f:	74 1f                	je     4490 <fwp_heap_alloc_slow+0x140>
    4471:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4475:	4d 29 c3             	sub    %r8,%r11
    4478:	49 39 db             	cmp    %rbx,%r11
    447b:	72 13                	jb     4490 <fwp_heap_alloc_slow+0x140>
    447d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4481:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4485:	e9 3c ff ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    448a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4490:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4497:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    449b:	44 89 ca             	mov    %r9d,%edx
    449e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    44a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    44a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    44ab:	44 89 d6             	mov    %r10d,%esi
    44ae:	48 01 c7             	add    %rax,%rdi
    44b1:	e8 6a fa ff ff       	call   3f20 <fwp_heap_refill>
    44b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    44bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    44bf:	49 89 c0             	mov    %rax,%r8
    44c2:	e9 ff fe ff ff       	jmp    43c6 <fwp_heap_alloc_slow+0x76>
    44c7:	e8 34 e7 ff ff       	call   2c00 <fwp_heap_oom>
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000044d0 <fwp_rc_fresh>:
    44d0:	48 8b 15 41 a6 01 00 	mov    0x1a641(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    44d7:	48 89 f8             	mov    %rdi,%rax
    44da:	48 89 fe             	mov    %rdi,%rsi
    44dd:	48 2b 05 0c a6 01 00 	sub    0x1a60c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    44e4:	48 c1 e2 10          	shl    $0x10,%rdx
    44e8:	48 39 d0             	cmp    %rdx,%rax
    44eb:	73 4f                	jae    453c <fwp_rc_fresh+0x6c>
    44ed:	48 89 c2             	mov    %rax,%rdx
    44f0:	48 c1 ea 10          	shr    $0x10,%rdx
    44f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    44f8:	48 8b 15 39 a6 01 00 	mov    0x1a639(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    44ff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4507:	48 85 d2             	test   %rdx,%rdx
    450a:	74 30                	je     453c <fwp_rc_fresh+0x6c>
    450c:	0f b6 39             	movzbl (%rcx),%edi
    450f:	40 80 ff 02          	cmp    $0x2,%dil
    4513:	74 2b                	je     4540 <fwp_rc_fresh+0x70>
    4515:	40 80 ff 01          	cmp    $0x1,%dil
    4519:	75 21                	jne    453c <fwp_rc_fresh+0x6c>
    451b:	8b 79 18             	mov    0x18(%rcx),%edi
    451e:	0f b7 c0             	movzwl %ax,%eax
    4521:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4524:	48 0f af c7          	imul   %rdi,%rax
    4528:	48 c1 e8 20          	shr    $0x20,%rax
    452c:	48 39 c8             	cmp    %rcx,%rax
    452f:	73 0b                	jae    453c <fwp_rc_fresh+0x6c>
    4531:	48 01 c2             	add    %rax,%rdx
    4534:	80 3a ff             	cmpb   $0xff,(%rdx)
    4537:	74 17                	je     4550 <fwp_rc_fresh+0x80>
    4539:	c6 02 01             	movb   $0x1,(%rdx)
    453c:	48 89 f0             	mov    %rsi,%rax
    453f:	c3                   	ret
    4540:	66 85 c0             	test   %ax,%ax
    4543:	74 ef                	je     4534 <fwp_rc_fresh+0x64>
    4545:	48 89 f0             	mov    %rsi,%rax
    4548:	c3                   	ret
    4549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4550:	48 83 ec 18          	sub    $0x18,%rsp
    4554:	48 89 d7             	mov    %rdx,%rdi
    4557:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    455c:	48 89 14 24          	mov    %rdx,(%rsp)
    4560:	e8 2b f8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4565:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    456a:	48 8b 14 24          	mov    (%rsp),%rdx
    456e:	48 89 f0             	mov    %rsi,%rax
    4571:	c6 02 01             	movb   $0x1,(%rdx)
    4574:	48 83 c4 18          	add    $0x18,%rsp
    4578:	c3                   	ret
    4579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004580 <fwp_rc_free_arr>:
    4580:	48 8b 15 91 a5 01 00 	mov    0x1a591(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4587:	48 89 f8             	mov    %rdi,%rax
    458a:	48 2b 05 5f a5 01 00 	sub    0x1a55f(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4591:	48 c1 e2 10          	shl    $0x10,%rdx
    4595:	48 39 d0             	cmp    %rdx,%rax
    4598:	73 5b                	jae    45f5 <fwp_rc_free_arr+0x75>
    459a:	48 89 c2             	mov    %rax,%rdx
    459d:	48 c1 ea 10          	shr    $0x10,%rdx
    45a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    45a5:	48 8b 15 8c a5 01 00 	mov    0x1a58c(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    45ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    45b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    45b4:	48 85 c9             	test   %rcx,%rcx
    45b7:	74 3c                	je     45f5 <fwp_rc_free_arr+0x75>
    45b9:	0f b6 32             	movzbl (%rdx),%esi
    45bc:	40 80 fe 02          	cmp    $0x2,%sil
    45c0:	74 2e                	je     45f0 <fwp_rc_free_arr+0x70>
    45c2:	40 80 fe 01          	cmp    $0x1,%sil
    45c6:	75 2d                	jne    45f5 <fwp_rc_free_arr+0x75>
    45c8:	8b 72 18             	mov    0x18(%rdx),%esi
    45cb:	0f b7 c0             	movzwl %ax,%eax
    45ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    45d1:	48 0f af c6          	imul   %rsi,%rax
    45d5:	48 c1 e8 20          	shr    $0x20,%rax
    45d9:	48 39 d0             	cmp    %rdx,%rax
    45dc:	73 17                	jae    45f5 <fwp_rc_free_arr+0x75>
    45de:	48 01 c1             	add    %rax,%rcx
    45e1:	80 39 01             	cmpb   $0x1,(%rcx)
    45e4:	75 0f                	jne    45f5 <fwp_rc_free_arr+0x75>
    45e6:	e9 e5 f9 ff ff       	jmp    3fd0 <fwp_mem_free>
    45eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    45f0:	66 85 c0             	test   %ax,%ax
    45f3:	74 ec                	je     45e1 <fwp_rc_free_arr+0x61>
    45f5:	c3                   	ret
    45f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    45fd:	00 00 00 

0000000000004600 <fwp_heap_alloc>:
    4600:	8b 05 de a4 01 00    	mov    0x1a4de(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4606:	48 89 fa             	mov    %rdi,%rdx
    4609:	89 f7                	mov    %esi,%edi
    460b:	85 c0                	test   %eax,%eax
    460d:	0f 84 f5 00 00 00    	je     4708 <fwp_heap_alloc+0x108>
    4613:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    461a:	0f 87 e8 00 00 00    	ja     4708 <fwp_heap_alloc+0x108>
    4620:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    4624:	48 8d 05 15 91 01 00 	lea    0x19115(%rip),%rax        # 1d740 <fwp_heap>
    462b:	48 83 ec 18          	sub    $0x18,%rsp
    462f:	41 89 f0             	mov    %esi,%r8d
    4632:	48 c1 e9 04          	shr    $0x4,%rcx
    4636:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    463d:	00 
    463e:	48 63 cf             	movslq %edi,%rcx
    4641:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    4648:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    464f:	00 
    4650:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    4654:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    4658:	48 01 c8             	add    %rcx,%rax
    465b:	48 8b 08             	mov    (%rax),%rcx
    465e:	48 85 c9             	test   %rcx,%rcx
    4661:	74 6d                	je     46d0 <fwp_heap_alloc+0xd0>
    4663:	48 8b 31             	mov    (%rcx),%rsi
    4666:	48 f7 d6             	not    %rsi
    4669:	48 89 30             	mov    %rsi,(%rax)
    466c:	41 83 f8 01          	cmp    $0x1,%r8d
    4670:	48 89 cf             	mov    %rcx,%rdi
    4673:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4678:	49 0f 45 d1          	cmovne %r9,%rdx
    467c:	31 f6                	xor    %esi,%esi
    467e:	e8 1d de ff ff       	call   24a0 <memset@plt>
    4683:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4688:	48 89 c1             	mov    %rax,%rcx
    468b:	4c 89 c8             	mov    %r9,%rax
    468e:	48 03 05 cb a4 01 00 	add    0x1a4cb(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    4695:	72 7b                	jb     4712 <fwp_heap_alloc+0x112>
    4697:	48 39 05 ca a4 01 00 	cmp    %rax,0x1a4ca(%rip)        # 1eb68 <fwp_heap+0x1428>
    469e:	48 89 05 bb a4 01 00 	mov    %rax,0x1a4bb(%rip)        # 1eb60 <fwp_heap+0x1420>
    46a5:	73 07                	jae    46ae <fwp_heap_alloc+0xae>
    46a7:	48 89 05 ba a4 01 00 	mov    %rax,0x1a4ba(%rip)        # 1eb68 <fwp_heap+0x1428>
    46ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    46b2:	48 89 c8             	mov    %rcx,%rax
    46b5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    46ba:	f2 0f 58 05 b6 a4 01 	addsd  0x1a4b6(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    46c1:	00 
    46c2:	f2 0f 11 05 ae a4 01 	movsd  %xmm0,0x1a4ae(%rip)        # 1eb78 <fwp_heap+0x1438>
    46c9:	00 
    46ca:	48 83 c4 18          	add    $0x18,%rsp
    46ce:	c3                   	ret
    46cf:	90                   	nop
    46d0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    46d4:	48 85 c9             	test   %rcx,%rcx
    46d7:	74 0c                	je     46e5 <fwp_heap_alloc+0xe5>
    46d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    46dd:	48 29 ce             	sub    %rcx,%rsi
    46e0:	4c 39 ce             	cmp    %r9,%rsi
    46e3:	73 13                	jae    46f8 <fwp_heap_alloc+0xf8>
    46e5:	89 fe                	mov    %edi,%esi
    46e7:	48 83 c4 18          	add    $0x18,%rsp
    46eb:	48 89 d7             	mov    %rdx,%rdi
    46ee:	e9 5d fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    46f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46f8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    46fc:	48 89 70 08          	mov    %rsi,0x8(%rax)
    4700:	e9 67 ff ff ff       	jmp    466c <fwp_heap_alloc+0x6c>
    4705:	0f 1f 00             	nopl   (%rax)
    4708:	89 fe                	mov    %edi,%esi
    470a:	48 89 d7             	mov    %rdx,%rdi
    470d:	e9 3e fc ff ff       	jmp    4350 <fwp_heap_alloc_slow>
    4712:	e8 e9 e4 ff ff       	call   2c00 <fwp_heap_oom>
    4717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    471e:	00 00 

0000000000004720 <fwp_data.part.0.constprop.0>:
    4720:	8b 05 be a3 01 00    	mov    0x1a3be(%rip),%eax        # 1eae4 <fwp_heap+0x13a4>
    4726:	41 54                	push   %r12
    4728:	49 89 fc             	mov    %rdi,%r12
    472b:	55                   	push   %rbp
    472c:	53                   	push   %rbx
    472d:	85 c0                	test   %eax,%eax
    472f:	0f 84 e3 00 00 00    	je     4818 <fwp_data.part.0.constprop.0+0xf8>
    4735:	0f b6 05 a6 9f 01 00 	movzbl 0x19fa6(%rip),%eax        # 1e6e2 <fwp_heap+0xfa2>
    473c:	48 8d 15 fd 8f 01 00 	lea    0x18ffd(%rip),%rdx        # 1d740 <fwp_heap>
    4743:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    474a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    474e:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    4752:	48 8b 18             	mov    (%rax),%rbx
    4755:	48 85 db             	test   %rbx,%rbx
    4758:	0f 84 92 00 00 00    	je     47f0 <fwp_data.part.0.constprop.0+0xd0>
    475e:	48 8b 13             	mov    (%rbx),%rdx
    4761:	48 f7 d2             	not    %rdx
    4764:	48 89 10             	mov    %rdx,(%rax)
    4767:	48 83 fd 18          	cmp    $0x18,%rbp
    476b:	76 1b                	jbe    4788 <fwp_data.part.0.constprop.0+0x68>
    476d:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    4771:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    4775:	31 f6                	xor    %esi,%esi
    4777:	48 c1 e8 03          	shr    $0x3,%rax
    477b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    4782:	00 
    4783:	e8 18 dd ff ff       	call   24a0 <memset@plt>
    4788:	48 89 e8             	mov    %rbp,%rax
    478b:	48 03 05 ce a3 01 00 	add    0x1a3ce(%rip),%rax        # 1eb60 <fwp_heap+0x1420>
    4792:	0f 82 91 00 00 00    	jb     4829 <fwp_data.part.0.constprop.0+0x109>
    4798:	48 39 05 c9 a3 01 00 	cmp    %rax,0x1a3c9(%rip)        # 1eb68 <fwp_heap+0x1428>
    479f:	48 89 05 ba a3 01 00 	mov    %rax,0x1a3ba(%rip)        # 1eb60 <fwp_heap+0x1420>
    47a6:	73 07                	jae    47af <fwp_data.part.0.constprop.0+0x8f>
    47a8:	48 89 05 b9 a3 01 00 	mov    %rax,0x1a3b9(%rip)        # 1eb68 <fwp_heap+0x1428>
    47af:	66 0f ef c0          	pxor   %xmm0,%xmm0
    47b3:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    47b8:	f2 0f 58 05 b8 a3 01 	addsd  0x1a3b8(%rip),%xmm0        # 1eb78 <fwp_heap+0x1438>
    47bf:	00 
    47c0:	f2 0f 11 05 b0 a3 01 	movsd  %xmm0,0x1a3b0(%rip)        # 1eb78 <fwp_heap+0x1438>
    47c7:	00 
    47c8:	48 8b 05 d1 6c 00 00 	mov    0x6cd1(%rip),%rax        # b4a0 <msg.3+0x60>
    47cf:	48 89 03             	mov    %rax,(%rbx)
    47d2:	49 8b 04 24          	mov    (%r12),%rax
    47d6:	48 89 43 08          	mov    %rax,0x8(%rbx)
    47da:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    47df:	48 89 43 10          	mov    %rax,0x10(%rbx)
    47e3:	48 89 d8             	mov    %rbx,%rax
    47e6:	5b                   	pop    %rbx
    47e7:	5d                   	pop    %rbp
    47e8:	41 5c                	pop    %r12
    47ea:	c3                   	ret
    47eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    47f0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    47f4:	48 85 db             	test   %rbx,%rbx
    47f7:	74 1f                	je     4818 <fwp_data.part.0.constprop.0+0xf8>
    47f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    47fd:	48 29 da             	sub    %rbx,%rdx
    4800:	48 39 ea             	cmp    %rbp,%rdx
    4803:	72 13                	jb     4818 <fwp_data.part.0.constprop.0+0xf8>
    4805:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    4809:	48 89 50 08          	mov    %rdx,0x8(%rax)
    480d:	e9 55 ff ff ff       	jmp    4767 <fwp_data.part.0.constprop.0+0x47>
    4812:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4818:	31 f6                	xor    %esi,%esi
    481a:	bf 18 00 00 00       	mov    $0x18,%edi
    481f:	e8 dc fd ff ff       	call   4600 <fwp_heap_alloc>
    4824:	48 89 c3             	mov    %rax,%rbx
    4827:	eb 9f                	jmp    47c8 <fwp_data.part.0.constprop.0+0xa8>
    4829:	e8 d2 e3 ff ff       	call   2c00 <fwp_heap_oom>
    482e:	66 90                	xchg   %ax,%ax

0000000000004830 <fwp_array_new_packed.constprop.0>:
    4830:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    4837:	ff ff 1f 
    483a:	53                   	push   %rbx
    483b:	48 39 f8             	cmp    %rdi,%rax
    483e:	72 1a                	jb     485a <fwp_array_new_packed.constprop.0+0x2a>
    4840:	48 89 fb             	mov    %rdi,%rbx
    4843:	be 01 00 00 00       	mov    $0x1,%esi
    4848:	48 8d 3c fd 08 00 00 	lea    0x8(,%rdi,8),%rdi
    484f:	00 
    4850:	e8 ab fd ff ff       	call   4600 <fwp_heap_alloc>
    4855:	48 89 18             	mov    %rbx,(%rax)
    4858:	5b                   	pop    %rbx
    4859:	c3                   	ret
    485a:	48 8d 3d 44 68 00 00 	lea    0x6844(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    4861:	e8 4a e8 ff ff       	call   30b0 <fwp_trap>
    4866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    486d:	00 00 00 

0000000000004870 <fwp_task_dispose>:
    4870:	53                   	push   %rbx
    4871:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4875:	0f 84 8b de ff ff    	je     2706 <fwp_task_dispose.cold>
    487b:	48 89 fb             	mov    %rdi,%rbx
    487e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4883:	0f 85 7d de ff ff    	jne    2706 <fwp_task_dispose.cold>
    4889:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    488d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4894:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    489b:	00 
    489c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    48a0:	48 85 ff             	test   %rdi,%rdi
    48a3:	74 07                	je     48ac <fwp_task_dispose+0x3c>
    48a5:	48 85 c0             	test   %rax,%rax
    48a8:	74 02                	je     48ac <fwp_task_dispose+0x3c>
    48aa:	ff d0                	call   *%rax
    48ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    48b3:	e8 18 f7 ff ff       	call   3fd0 <fwp_mem_free>
    48b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    48bf:	00 00 00 00 
    48c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    48c7:	74 6f                	je     4938 <fwp_task_dispose+0xc8>
    48c9:	48 8b 15 48 a2 01 00 	mov    0x1a248(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    48d0:	48 89 d8             	mov    %rbx,%rax
    48d3:	48 2b 05 16 a2 01 00 	sub    0x1a216(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    48da:	48 c1 e2 10          	shl    $0x10,%rdx
    48de:	48 39 d0             	cmp    %rdx,%rax
    48e1:	73 4c                	jae    492f <fwp_task_dispose+0xbf>
    48e3:	48 89 c2             	mov    %rax,%rdx
    48e6:	48 c1 ea 10          	shr    $0x10,%rdx
    48ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    48ee:	48 8b 15 43 a2 01 00 	mov    0x1a243(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    48f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    48f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    48fd:	48 85 c9             	test   %rcx,%rcx
    4900:	74 2d                	je     492f <fwp_task_dispose+0xbf>
    4902:	0f b6 32             	movzbl (%rdx),%esi
    4905:	40 80 fe 02          	cmp    $0x2,%sil
    4909:	74 3d                	je     4948 <fwp_task_dispose+0xd8>
    490b:	40 80 fe 01          	cmp    $0x1,%sil
    490f:	75 1e                	jne    492f <fwp_task_dispose+0xbf>
    4911:	8b 72 18             	mov    0x18(%rdx),%esi
    4914:	0f b7 c0             	movzwl %ax,%eax
    4917:	8b 52 1c             	mov    0x1c(%rdx),%edx
    491a:	48 0f af c6          	imul   %rsi,%rax
    491e:	48 c1 e8 20          	shr    $0x20,%rax
    4922:	48 39 d0             	cmp    %rdx,%rax
    4925:	73 08                	jae    492f <fwp_task_dispose+0xbf>
    4927:	48 01 c1             	add    %rax,%rcx
    492a:	80 39 01             	cmpb   $0x1,(%rcx)
    492d:	74 09                	je     4938 <fwp_task_dispose+0xc8>
    492f:	5b                   	pop    %rbx
    4930:	c3                   	ret
    4931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4938:	48 89 df             	mov    %rbx,%rdi
    493b:	5b                   	pop    %rbx
    493c:	e9 8f f6 ff ff       	jmp    3fd0 <fwp_mem_free>
    4941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4948:	66 85 c0             	test   %ax,%ax
    494b:	74 dd                	je     492a <fwp_task_dispose+0xba>
    494d:	5b                   	pop    %rbx
    494e:	c3                   	ret
    494f:	90                   	nop

0000000000004950 <fwp_free_zombie>:
    4950:	48 8b 15 b9 8d 01 00 	mov    0x18db9(%rip),%rdx        # 1d710 <fwp_zombie>
    4957:	48 85 d2             	test   %rdx,%rdx
    495a:	0f 84 98 00 00 00    	je     49f8 <fwp_free_zombie+0xa8>
    4960:	48 3b 15 b9 8d 01 00 	cmp    0x18db9(%rip),%rdx        # 1d720 <fwp_cur>
    4967:	0f 84 8b 00 00 00    	je     49f8 <fwp_free_zombie+0xa8>
    496d:	48 83 ec 18          	sub    $0x18,%rsp
    4971:	48 63 05 84 87 01 00 	movslq 0x18784(%rip),%rax        # 1d0fc <fwp_stack_pool_n>
    4978:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    497c:	83 f8 3f             	cmp    $0x3f,%eax
    497f:	7f 7f                	jg     4a00 <fwp_free_zombie+0xb0>
    4981:	8d 48 01             	lea    0x1(%rax),%ecx
    4984:	89 0d 72 87 01 00    	mov    %ecx,0x18772(%rip)        # 1d0fc <fwp_stack_pool_n>
    498a:	48 8d 0d 6f 87 01 00 	lea    0x1876f(%rip),%rcx        # 1d100 <fwp_stack_pool>
    4991:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4995:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    499c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    49a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    49ab:	48 85 c9             	test   %rcx,%rcx
    49ae:	0f 84 fc 00 00 00    	je     4ab0 <fwp_free_zombie+0x160>
    49b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    49bb:	48 85 c0             	test   %rax,%rax
    49be:	74 07                	je     49c7 <fwp_free_zombie+0x77>
    49c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    49c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    49ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    49ce:	48 c7 05 37 8d 01 00 	movq   $0x0,0x18d37(%rip)        # 1d710 <fwp_zombie>
    49d5:	00 00 00 00 
    49d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    49e0:	85 c0                	test   %eax,%eax
    49e2:	74 34                	je     4a18 <fwp_free_zombie+0xc8>
    49e4:	83 f8 01             	cmp    $0x1,%eax
    49e7:	0f 84 b3 00 00 00    	je     4aa0 <fwp_free_zombie+0x150>
    49ed:	48 83 c4 18          	add    $0x18,%rsp
    49f1:	c3                   	ret
    49f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    49f8:	c3                   	ret
    49f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a00:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4a04:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4a09:	e8 a2 db ff ff       	call   25b0 <munmap@plt>
    4a0e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4a13:	eb 80                	jmp    4995 <fwp_free_zombie+0x45>
    4a15:	0f 1f 00             	nopl   (%rax)
    4a18:	48 8b 0d f9 a0 01 00 	mov    0x1a0f9(%rip),%rcx        # 1eb18 <fwp_heap+0x13d8>
    4a1f:	48 89 d0             	mov    %rdx,%rax
    4a22:	48 2b 05 c7 a0 01 00 	sub    0x1a0c7(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4a29:	48 c1 e1 10          	shl    $0x10,%rcx
    4a2d:	48 39 c8             	cmp    %rcx,%rax
    4a30:	73 bb                	jae    49ed <fwp_free_zombie+0x9d>
    4a32:	48 89 c1             	mov    %rax,%rcx
    4a35:	48 c1 e9 10          	shr    $0x10,%rcx
    4a39:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4a3d:	48 8b 0d f4 a0 01 00 	mov    0x1a0f4(%rip),%rcx        # 1eb38 <fwp_heap+0x13f8>
    4a44:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4a48:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4a4c:	48 85 c9             	test   %rcx,%rcx
    4a4f:	74 9c                	je     49ed <fwp_free_zombie+0x9d>
    4a51:	0f b6 3e             	movzbl (%rsi),%edi
    4a54:	40 80 ff 02          	cmp    $0x2,%dil
    4a58:	74 66                	je     4ac0 <fwp_free_zombie+0x170>
    4a5a:	40 80 ff 01          	cmp    $0x1,%dil
    4a5e:	75 8d                	jne    49ed <fwp_free_zombie+0x9d>
    4a60:	8b 7e 18             	mov    0x18(%rsi),%edi
    4a63:	0f b7 c0             	movzwl %ax,%eax
    4a66:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4a69:	48 0f af c7          	imul   %rdi,%rax
    4a6d:	48 c1 e8 20          	shr    $0x20,%rax
    4a71:	48 39 f0             	cmp    %rsi,%rax
    4a74:	0f 83 73 ff ff ff    	jae    49ed <fwp_free_zombie+0x9d>
    4a7a:	48 01 c1             	add    %rax,%rcx
    4a7d:	0f b6 01             	movzbl (%rcx),%eax
    4a80:	84 c0                	test   %al,%al
    4a82:	0f 84 65 ff ff ff    	je     49ed <fwp_free_zombie+0x9d>
    4a88:	3c 01                	cmp    $0x1,%al
    4a8a:	74 14                	je     4aa0 <fwp_free_zombie+0x150>
    4a8c:	3c ff                	cmp    $0xff,%al
    4a8e:	74 3b                	je     4acb <fwp_free_zombie+0x17b>
    4a90:	83 e8 01             	sub    $0x1,%eax
    4a93:	88 01                	mov    %al,(%rcx)
    4a95:	e9 53 ff ff ff       	jmp    49ed <fwp_free_zombie+0x9d>
    4a9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa0:	48 89 d7             	mov    %rdx,%rdi
    4aa3:	48 83 c4 18          	add    $0x18,%rsp
    4aa7:	e9 c4 fd ff ff       	jmp    4870 <fwp_task_dispose>
    4aac:	0f 1f 40 00          	nopl   0x0(%rax)
    4ab0:	48 89 05 31 8c 01 00 	mov    %rax,0x18c31(%rip)        # 1d6e8 <fwp_tasks_active>
    4ab7:	e9 ff fe ff ff       	jmp    49bb <fwp_free_zombie+0x6b>
    4abc:	0f 1f 40 00          	nopl   0x0(%rax)
    4ac0:	66 85 c0             	test   %ax,%ax
    4ac3:	0f 85 24 ff ff ff    	jne    49ed <fwp_free_zombie+0x9d>
    4ac9:	eb b2                	jmp    4a7d <fwp_free_zombie+0x12d>
    4acb:	48 89 ca             	mov    %rcx,%rdx
    4ace:	48 8d 35 6b 8c 01 00 	lea    0x18c6b(%rip),%rsi        # 1d740 <fwp_heap>
    4ad5:	48 c1 ea 11          	shr    $0x11,%rdx
    4ad9:	48 31 ca             	xor    %rcx,%rdx
    4adc:	48 89 d0             	mov    %rdx,%rax
    4adf:	48 c1 e8 09          	shr    $0x9,%rax
    4ae3:	48 31 c2             	xor    %rax,%rdx
    4ae6:	0f b6 d2             	movzbl %dl,%edx
    4ae9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4af0:	00 
    4af1:	48 85 c0             	test   %rax,%rax
    4af4:	75 13                	jne    4b09 <fwp_free_zombie+0x1b9>
    4af6:	eb 4c                	jmp    4b44 <fwp_free_zombie+0x1f4>
    4af8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aff:	00 
    4b00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4b04:	48 85 c0             	test   %rax,%rax
    4b07:	74 3b                	je     4b44 <fwp_free_zombie+0x1f4>
    4b09:	48 89 c2             	mov    %rax,%rdx
    4b0c:	48 39 08             	cmp    %rcx,(%rax)
    4b0f:	75 ef                	jne    4b00 <fwp_free_zombie+0x1b0>
    4b11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4b15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4b19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4b1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4b24:	0f 85 c3 fe ff ff    	jne    49ed <fwp_free_zombie+0x9d>
    4b2a:	48 89 cf             	mov    %rcx,%rdi
    4b2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4b32:	e8 59 f2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    4b37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4b3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    4b3f:	e9 a9 fe ff ff       	jmp    49ed <fwp_free_zombie+0x9d>
    4b44:	48 8d 3d 3d 67 00 00 	lea    0x673d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4b4b:	e8 60 e5 ff ff       	call   30b0 <fwp_trap>

0000000000004b50 <fwp_block>:
    4b50:	48 83 ec 08          	sub    $0x8,%rsp
    4b54:	48 8b 05 ad 8b 01 00 	mov    0x18bad(%rip),%rax        # 1d708 <fwp_ready_head>
    4b5b:	48 85 c0             	test   %rax,%rax
    4b5e:	0f 84 1c 01 00 00    	je     4c80 <fwp_block+0x130>
    4b64:	90                   	nop
    4b65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4b6c:	00 00 00 00 
    4b70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4b77:	48 89 15 8a 8b 01 00 	mov    %rdx,0x18b8a(%rip)        # 1d708 <fwp_ready_head>
    4b7e:	48 85 d2             	test   %rdx,%rdx
    4b81:	0f 84 19 01 00 00    	je     4ca0 <fwp_block+0x150>
    4b87:	48 8b 15 92 8b 01 00 	mov    0x18b92(%rip),%rdx        # 1d720 <fwp_cur>
    4b8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4b92:	48 39 c2             	cmp    %rax,%rdx
    4b95:	0f 84 d5 00 00 00    	je     4c70 <fwp_block+0x120>
    4b9b:	48 8b 0d fe a7 01 00 	mov    0x1a7fe(%rip),%rcx        # 1f3a0 <fwp_state_owners>
    4ba2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4ba6:	48 89 05 73 8b 01 00 	mov    %rax,0x18b73(%rip)        # 1d720 <fwp_cur>
    4bad:	f3 0f 7e 05 13 a8 01 	movq   0x1a813(%rip),%xmm0        # 1f3c8 <fwp_foreign_callbacks>
    4bb4:	00 
    4bb5:	0f 16 05 fc a7 01 00 	movhps 0x1a7fc(%rip),%xmm0        # 1f3b8 <fwp_state>
    4bbc:	f3 0f 7e 0d fc a7 01 	movq   0x1a7fc(%rip),%xmm1        # 1f3c0 <fwp_handlers>
    4bc3:	00 
    4bc4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4bcb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4bd2:	0f 16 0d f7 a7 01 00 	movhps 0x1a7f7(%rip),%xmm1        # 1f3d0 <fwp_cleanups>
    4bd9:	f3 0f 7e 05 cf a7 01 	movq   0x1a7cf(%rip),%xmm0        # 1f3b0 <fwp_state_len>
    4be0:	00 
    4be1:	0f 16 05 c0 a7 01 00 	movhps 0x1a7c0(%rip),%xmm0        # 1f3a8 <fwp_state_cap>
    4be8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4bef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4bf6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4bfa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4c01:	48 89 0d b8 a7 01 00 	mov    %rcx,0x1a7b8(%rip)        # 1f3c0 <fwp_handlers>
    4c08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4c0f:	48 89 0d ba a7 01 00 	mov    %rcx,0x1a7ba(%rip)        # 1f3d0 <fwp_cleanups>
    4c16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4c1d:	48 89 0d a4 a7 01 00 	mov    %rcx,0x1a7a4(%rip)        # 1f3c8 <fwp_foreign_callbacks>
    4c24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4c2b:	48 89 0d 86 a7 01 00 	mov    %rcx,0x1a786(%rip)        # 1f3b8 <fwp_state>
    4c32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4c39:	48 89 0d 70 a7 01 00 	mov    %rcx,0x1a770(%rip)        # 1f3b0 <fwp_state_len>
    4c40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4c47:	48 89 0d 5a a7 01 00 	mov    %rcx,0x1a75a(%rip)        # 1f3a8 <fwp_state_cap>
    4c4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4c55:	48 89 0d 44 a7 01 00 	mov    %rcx,0x1a744(%rip)        # 1f3a0 <fwp_state_owners>
    4c5c:	e8 0f d8 ff ff       	call   2470 <swapcontext@plt>
    4c61:	f3 0f 1e fa          	endbr64
    4c65:	e8 e6 fc ff ff       	call   4950 <fwp_free_zombie>
    4c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c70:	8b 05 82 84 01 00    	mov    0x18482(%rip),%eax        # 1d0f8 <fwp_slice>
    4c76:	85 c0                	test   %eax,%eax
    4c78:	74 36                	je     4cb0 <fwp_block+0x160>
    4c7a:	48 83 c4 08          	add    $0x8,%rsp
    4c7e:	c3                   	ret
    4c7f:	90                   	nop
    4c80:	e8 6b ee ff ff       	call   3af0 <fwp_poll_events>
    4c85:	48 8b 05 7c 8a 01 00 	mov    0x18a7c(%rip),%rax        # 1d708 <fwp_ready_head>
    4c8c:	48 85 c0             	test   %rax,%rax
    4c8f:	0f 85 db fe ff ff    	jne    4b70 <fwp_block+0x20>
    4c95:	eb e9                	jmp    4c80 <fwp_block+0x130>
    4c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4c9e:	00 00 
    4ca0:	48 c7 05 55 8a 01 00 	movq   $0x0,0x18a55(%rip)        # 1d700 <fwp_ready_tail>
    4ca7:	00 00 00 00 
    4cab:	e9 d7 fe ff ff       	jmp    4b87 <fwp_block+0x37>
    4cb0:	48 8d 3d fe 63 00 00 	lea    0x63fe(%rip),%rdi        # b0b5 <_IO_stdin_used+0xb5>
    4cb7:	e8 c4 d6 ff ff       	call   2380 <getenv@plt>
    4cbc:	ba 10 27 00 00       	mov    $0x2710,%edx
    4cc1:	48 85 c0             	test   %rax,%rax
    4cc4:	74 05                	je     4ccb <fwp_block+0x17b>
    4cc6:	80 38 00             	cmpb   $0x0,(%rax)
    4cc9:	75 0b                	jne    4cd6 <fwp_block+0x186>
    4ccb:	89 15 27 84 01 00    	mov    %edx,0x18427(%rip)        # 1d0f8 <fwp_slice>
    4cd1:	48 83 c4 08          	add    $0x8,%rsp
    4cd5:	c3                   	ret
    4cd6:	ba 0a 00 00 00       	mov    $0xa,%edx
    4cdb:	31 f6                	xor    %esi,%esi
    4cdd:	48 89 c7             	mov    %rax,%rdi
    4ce0:	e8 4b d8 ff ff       	call   2530 <strtoll@plt>
    4ce5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4ce9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4cf0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4cf5:	0f 46 d0             	cmovbe %eax,%edx
    4cf8:	eb d1                	jmp    4ccb <fwp_block+0x17b>
    4cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004d00 <fwp_drop0>:
    4d00:	48 8b 15 11 9e 01 00 	mov    0x19e11(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4d07:	48 89 f8             	mov    %rdi,%rax
    4d0a:	48 2b 05 df 9d 01 00 	sub    0x19ddf(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4d11:	48 c1 e2 10          	shl    $0x10,%rdx
    4d15:	48 39 d0             	cmp    %rdx,%rax
    4d18:	0f 83 c2 00 00 00    	jae    4de0 <fwp_drop0+0xe0>
    4d1e:	48 83 ec 18          	sub    $0x18,%rsp
    4d22:	4c 8d 05 17 8a 01 00 	lea    0x18a17(%rip),%r8        # 1d740 <fwp_heap>
    4d29:	48 89 c2             	mov    %rax,%rdx
    4d2c:	48 c1 ea 10          	shr    $0x10,%rdx
    4d30:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4d34:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4d3b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4d3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4d43:	48 85 d2             	test   %rdx,%rdx
    4d46:	74 3c                	je     4d84 <fwp_drop0+0x84>
    4d48:	0f b6 31             	movzbl (%rcx),%esi
    4d4b:	40 80 fe 02          	cmp    $0x2,%sil
    4d4f:	74 3f                	je     4d90 <fwp_drop0+0x90>
    4d51:	40 80 fe 01          	cmp    $0x1,%sil
    4d55:	75 2d                	jne    4d84 <fwp_drop0+0x84>
    4d57:	8b 71 18             	mov    0x18(%rcx),%esi
    4d5a:	0f b7 c0             	movzwl %ax,%eax
    4d5d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4d60:	48 0f af c6          	imul   %rsi,%rax
    4d64:	48 c1 e8 20          	shr    $0x20,%rax
    4d68:	48 39 c8             	cmp    %rcx,%rax
    4d6b:	73 17                	jae    4d84 <fwp_drop0+0x84>
    4d6d:	48 01 c2             	add    %rax,%rdx
    4d70:	0f b6 02             	movzbl (%rdx),%eax
    4d73:	84 c0                	test   %al,%al
    4d75:	74 0d                	je     4d84 <fwp_drop0+0x84>
    4d77:	3c 01                	cmp    $0x1,%al
    4d79:	74 25                	je     4da0 <fwp_drop0+0xa0>
    4d7b:	3c ff                	cmp    $0xff,%al
    4d7d:	74 69                	je     4de8 <fwp_drop0+0xe8>
    4d7f:	83 e8 01             	sub    $0x1,%eax
    4d82:	88 02                	mov    %al,(%rdx)
    4d84:	48 83 c4 18          	add    $0x18,%rsp
    4d88:	c3                   	ret
    4d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d90:	66 85 c0             	test   %ax,%ax
    4d93:	74 db                	je     4d70 <fwp_drop0+0x70>
    4d95:	48 83 c4 18          	add    $0x18,%rsp
    4d99:	c3                   	ret
    4d9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4da0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4da4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4da9:	e8 d2 f7 ff ff       	call   4580 <fwp_rc_free_arr>
    4dae:	4c 8d 05 8b 89 01 00 	lea    0x1898b(%rip),%r8        # 1d740 <fwp_heap>
    4db5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4dba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4dc1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4dc8:	48 c1 e2 10          	shl    $0x10,%rdx
    4dcc:	48 39 d0             	cmp    %rdx,%rax
    4dcf:	73 b3                	jae    4d84 <fwp_drop0+0x84>
    4dd1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4dd6:	e9 4e ff ff ff       	jmp    4d29 <fwp_drop0+0x29>
    4ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4de0:	c3                   	ret
    4de1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4de8:	48 89 d0             	mov    %rdx,%rax
    4deb:	48 c1 e8 11          	shr    $0x11,%rax
    4def:	48 31 d0             	xor    %rdx,%rax
    4df2:	48 89 c1             	mov    %rax,%rcx
    4df5:	48 c1 e9 09          	shr    $0x9,%rcx
    4df9:	48 31 c8             	xor    %rcx,%rax
    4dfc:	0f b6 c8             	movzbl %al,%ecx
    4dff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4e06:	00 
    4e07:	48 85 c0             	test   %rax,%rax
    4e0a:	75 1d                	jne    4e29 <fwp_drop0+0x129>
    4e0c:	eb 56                	jmp    4e64 <fwp_drop0+0x164>
    4e0e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e1c:	00 00 00 00 
    4e20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4e24:	48 85 c0             	test   %rax,%rax
    4e27:	74 3b                	je     4e64 <fwp_drop0+0x164>
    4e29:	48 89 c1             	mov    %rax,%rcx
    4e2c:	48 39 10             	cmp    %rdx,(%rax)
    4e2f:	75 ef                	jne    4e20 <fwp_drop0+0x120>
    4e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4e35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4e39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4e3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4e44:	0f 85 3a ff ff ff    	jne    4d84 <fwp_drop0+0x84>
    4e4a:	48 89 d7             	mov    %rdx,%rdi
    4e4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4e52:	e8 39 ef ff ff       	call   3d90 <fwp_rc_forget_slot>
    4e57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4e5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    4e5f:	e9 20 ff ff ff       	jmp    4d84 <fwp_drop0+0x84>
    4e64:	48 8d 3d 1d 64 00 00 	lea    0x641d(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4e6b:	e8 40 e2 ff ff       	call   30b0 <fwp_trap>

0000000000004e70 <fwp_drop1>:
    4e70:	f3 0f 1e fa          	endbr64
    4e74:	48 8b 15 9d 9c 01 00 	mov    0x19c9d(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    4e7b:	48 89 f8             	mov    %rdi,%rax
    4e7e:	48 2b 05 6b 9c 01 00 	sub    0x19c6b(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    4e85:	48 c1 e2 10          	shl    $0x10,%rdx
    4e89:	48 39 d0             	cmp    %rdx,%rax
    4e8c:	0f 83 be 00 00 00    	jae    4f50 <fwp_drop1+0xe0>
    4e92:	48 83 ec 18          	sub    $0x18,%rsp
    4e96:	4c 8d 05 a3 88 01 00 	lea    0x188a3(%rip),%r8        # 1d740 <fwp_heap>
    4e9d:	48 89 c2             	mov    %rax,%rdx
    4ea0:	48 c1 ea 10          	shr    $0x10,%rdx
    4ea4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4ea8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    4eaf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    4eb3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4eb7:	48 85 d2             	test   %rdx,%rdx
    4eba:	74 3c                	je     4ef8 <fwp_drop1+0x88>
    4ebc:	0f b6 31             	movzbl (%rcx),%esi
    4ebf:	40 80 fe 02          	cmp    $0x2,%sil
    4ec3:	74 3b                	je     4f00 <fwp_drop1+0x90>
    4ec5:	40 80 fe 01          	cmp    $0x1,%sil
    4ec9:	75 2d                	jne    4ef8 <fwp_drop1+0x88>
    4ecb:	8b 71 18             	mov    0x18(%rcx),%esi
    4ece:	0f b7 c0             	movzwl %ax,%eax
    4ed1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4ed4:	48 0f af c6          	imul   %rsi,%rax
    4ed8:	48 c1 e8 20          	shr    $0x20,%rax
    4edc:	48 39 c8             	cmp    %rcx,%rax
    4edf:	73 17                	jae    4ef8 <fwp_drop1+0x88>
    4ee1:	48 01 c2             	add    %rax,%rdx
    4ee4:	0f b6 02             	movzbl (%rdx),%eax
    4ee7:	84 c0                	test   %al,%al
    4ee9:	74 0d                	je     4ef8 <fwp_drop1+0x88>
    4eeb:	3c 01                	cmp    $0x1,%al
    4eed:	74 21                	je     4f10 <fwp_drop1+0xa0>
    4eef:	3c ff                	cmp    $0xff,%al
    4ef1:	74 65                	je     4f58 <fwp_drop1+0xe8>
    4ef3:	83 e8 01             	sub    $0x1,%eax
    4ef6:	88 02                	mov    %al,(%rdx)
    4ef8:	48 83 c4 18          	add    $0x18,%rsp
    4efc:	c3                   	ret
    4efd:	0f 1f 00             	nopl   (%rax)
    4f00:	66 85 c0             	test   %ax,%ax
    4f03:	74 df                	je     4ee4 <fwp_drop1+0x74>
    4f05:	48 83 c4 18          	add    $0x18,%rsp
    4f09:	c3                   	ret
    4f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f10:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    4f14:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4f19:	e8 62 f6 ff ff       	call   4580 <fwp_rc_free_arr>
    4f1e:	4c 8d 05 1b 88 01 00 	lea    0x1881b(%rip),%r8        # 1d740 <fwp_heap>
    4f25:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4f2a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    4f31:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    4f38:	48 c1 e2 10          	shl    $0x10,%rdx
    4f3c:	48 39 d0             	cmp    %rdx,%rax
    4f3f:	73 b7                	jae    4ef8 <fwp_drop1+0x88>
    4f41:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    4f46:	e9 52 ff ff ff       	jmp    4e9d <fwp_drop1+0x2d>
    4f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f50:	c3                   	ret
    4f51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f58:	48 89 d0             	mov    %rdx,%rax
    4f5b:	48 c1 e8 11          	shr    $0x11,%rax
    4f5f:	48 31 d0             	xor    %rdx,%rax
    4f62:	48 89 c1             	mov    %rax,%rcx
    4f65:	48 c1 e9 09          	shr    $0x9,%rcx
    4f69:	48 31 c8             	xor    %rcx,%rax
    4f6c:	0f b6 c8             	movzbl %al,%ecx
    4f6f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    4f76:	00 
    4f77:	48 85 c0             	test   %rax,%rax
    4f7a:	75 0d                	jne    4f89 <fwp_drop1+0x119>
    4f7c:	eb 46                	jmp    4fc4 <fwp_drop1+0x154>
    4f7e:	66 90                	xchg   %ax,%ax
    4f80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    4f84:	48 85 c0             	test   %rax,%rax
    4f87:	74 3b                	je     4fc4 <fwp_drop1+0x154>
    4f89:	48 89 c1             	mov    %rax,%rcx
    4f8c:	48 39 10             	cmp    %rdx,(%rax)
    4f8f:	75 ef                	jne    4f80 <fwp_drop1+0x110>
    4f91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4f95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    4f99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    4f9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    4fa4:	0f 85 4e ff ff ff    	jne    4ef8 <fwp_drop1+0x88>
    4faa:	48 89 d7             	mov    %rdx,%rdi
    4fad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4fb2:	e8 d9 ed ff ff       	call   3d90 <fwp_rc_forget_slot>
    4fb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4fbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    4fbf:	e9 34 ff ff ff       	jmp    4ef8 <fwp_drop1+0x88>
    4fc4:	48 8d 3d bd 62 00 00 	lea    0x62bd(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    4fcb:	e8 e0 e0 ff ff       	call   30b0 <fwp_trap>

0000000000004fd0 <fwp_write.constprop.0>:
    4fd0:	41 57                	push   %r15
    4fd2:	41 56                	push   %r14
    4fd4:	41 55                	push   %r13
    4fd6:	41 54                	push   %r12
    4fd8:	55                   	push   %rbp
    4fd9:	53                   	push   %rbx
    4fda:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    4fe1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    4fe8:	00 00 
    4fea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    4ff1:	00 
    4ff2:	49 89 d4             	mov    %rdx,%r12
    4ff5:	8b 12                	mov    (%rdx),%edx
    4ff7:	83 fa 19             	cmp    $0x19,%edx
    4ffa:	77 64                	ja     5060 <fwp_write.constprop.0+0x90>
    4ffc:	48 8d 0d cd 63 00 00 	lea    0x63cd(%rip),%rcx        # b3d0 <_IO_stdin_used+0x3d0>
    5003:	89 d0                	mov    %edx,%eax
    5005:	48 89 fb             	mov    %rdi,%rbx
    5008:	48 89 f5             	mov    %rsi,%rbp
    500b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    500f:	48 01 c8             	add    %rcx,%rax
    5012:	3e ff e0             	notrack jmp *%rax
    5015:	0f 1f 00             	nopl   (%rax)
    5018:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
    501c:	48 8b 06             	mov    (%rsi),%rax
    501f:	48 89 ca             	mov    %rcx,%rdx
    5022:	48 85 c9             	test   %rcx,%rcx
    5025:	0f 88 b5 0c 00 00    	js     5ce0 <fwp_write.constprop.0+0xd10>
    502b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5032:	00 
    5033:	48 89 c6             	mov    %rax,%rsi
    5036:	4c 89 e7             	mov    %r12,%rdi
    5039:	e8 c2 d9 ff ff       	call   2a00 <fwp_fmt_u128>
    503e:	66 90                	xchg   %ax,%ax
    5040:	4c 89 e7             	mov    %r12,%rdi
    5043:	e8 e8 d3 ff ff       	call   2430 <strlen@plt>
    5048:	4c 89 e6             	mov    %r12,%rsi
    504b:	48 89 df             	mov    %rbx,%rdi
    504e:	48 89 c2             	mov    %rax,%rdx
    5051:	e8 2a df ff ff       	call   2f80 <buf_put>
    5056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    505d:	00 00 00 
    5060:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5067:	00 
    5068:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    506f:	00 00 
    5071:	0f 85 9e 04 00 00    	jne    5515 <fwp_write.constprop.0+0x545>
    5077:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    507e:	5b                   	pop    %rbx
    507f:	5d                   	pop    %rbp
    5080:	41 5c                	pop    %r12
    5082:	41 5d                	pop    %r13
    5084:	41 5e                	pop    %r14
    5086:	41 5f                	pop    %r15
    5088:	c3                   	ret
    5089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5090:	49 89 f1             	mov    %rsi,%r9
    5093:	4c 8d 05 43 60 00 00 	lea    0x6043(%rip),%r8        # b0dd <_IO_stdin_used+0xdd>
    509a:	b9 00 02 00 00       	mov    $0x200,%ecx
    509f:	ba 02 00 00 00       	mov    $0x2,%edx
    50a4:	be 00 02 00 00       	mov    $0x200,%esi
    50a9:	31 c0                	xor    %eax,%eax
    50ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50b2:	00 
    50b3:	e8 d8 d2 ff ff       	call   2390 <__snprintf_chk@plt>
    50b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    50bf:	00 
    50c0:	e8 6b d3 ff ff       	call   2430 <strlen@plt>
    50c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    50cc:	00 
    50cd:	48 89 df             	mov    %rbx,%rdi
    50d0:	48 89 c2             	mov    %rax,%rdx
    50d3:	e8 a8 de ff ff       	call   2f80 <buf_put>
    50d8:	eb 86                	jmp    5060 <fwp_write.constprop.0+0x90>
    50da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50e0:	49 89 f1             	mov    %rsi,%r9
    50e3:	4c 8d 05 ee 5f 00 00 	lea    0x5fee(%rip),%r8        # b0d8 <_IO_stdin_used+0xd8>
    50ea:	eb ae                	jmp    509a <fwp_write.constprop.0+0xca>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	83 fa 13             	cmp    $0x13,%edx
    50f3:	48 8d 05 d4 5f 00 00 	lea    0x5fd4(%rip),%rax        # b0ce <_IO_stdin_used+0xce>
    50fa:	48 8d 35 d2 5f 00 00 	lea    0x5fd2(%rip),%rsi        # b0d3 <_IO_stdin_used+0xd3>
    5101:	ba 04 00 00 00       	mov    $0x4,%edx
    5106:	48 0f 44 f0          	cmove  %rax,%rsi
    510a:	45 31 ed             	xor    %r13d,%r13d
    510d:	e8 6e de ff ff       	call   2f80 <buf_put>
    5112:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5117:	0f 84 b3 09 00 00    	je     5ad0 <fwp_write.constprop.0+0xb00>
    511d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    5122:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    5127:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    512c:	48 89 df             	mov    %rbx,%rdi
    512f:	49 0f 44 c5          	cmove  %r13,%rax
    5133:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    5138:	e8 93 fe ff ff       	call   4fd0 <fwp_write.constprop.0>
    513d:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    5142:	0f 84 80 0a 00 00    	je     5bc8 <fwp_write.constprop.0+0xbf8>
    5148:	49 83 c5 01          	add    $0x1,%r13
    514c:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    5150:	0f 83 7a 09 00 00    	jae    5ad0 <fwp_write.constprop.0+0xb00>
    5156:	ba 02 00 00 00       	mov    $0x2,%edx
    515b:	48 8d 35 bb 5f 00 00 	lea    0x5fbb(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5162:	48 89 df             	mov    %rbx,%rdi
    5165:	e8 16 de ff ff       	call   2f80 <buf_put>
    516a:	eb b1                	jmp    511d <fwp_write.constprop.0+0x14d>
    516c:	0f 1f 40 00          	nopl   0x0(%rax)
    5170:	ba 06 00 00 00       	mov    $0x6,%edx
    5175:	48 8d 35 7a 5f 00 00 	lea    0x5f7a(%rip),%rsi        # b0f6 <_IO_stdin_used+0xf6>
    517c:	48 83 c5 10          	add    $0x10,%rbp
    5180:	e8 fb dd ff ff       	call   2f80 <buf_put>
    5185:	48 89 ef             	mov    %rbp,%rdi
    5188:	e8 a3 d2 ff ff       	call   2430 <strlen@plt>
    518d:	48 89 ee             	mov    %rbp,%rsi
    5190:	48 89 df             	mov    %rbx,%rdi
    5193:	48 89 c2             	mov    %rax,%rdx
    5196:	e8 e5 dd ff ff       	call   2f80 <buf_put>
    519b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    51a0:	ba 01 00 00 00       	mov    $0x1,%edx
    51a5:	48 89 df             	mov    %rbx,%rdi
    51a8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    51ad:	e8 ce dd ff ff       	call   2f80 <buf_put>
    51b2:	e9 a9 fe ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    51c7:	00 
    51c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51cf:	00 00 
    51d1:	0f 85 3e 03 00 00    	jne    5515 <fwp_write.constprop.0+0x545>
    51d7:	ba 0a 00 00 00       	mov    $0xa,%edx
    51dc:	48 8d 35 ff 5e 00 00 	lea    0x5eff(%rip),%rsi        # b0e2 <_IO_stdin_used+0xe2>
    51e3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    51ea:	48 89 df             	mov    %rbx,%rdi
    51ed:	5b                   	pop    %rbx
    51ee:	5d                   	pop    %rbp
    51ef:	41 5c                	pop    %r12
    51f1:	41 5d                	pop    %r13
    51f3:	41 5e                	pop    %r14
    51f5:	41 5f                	pop    %r15
    51f7:	e9 84 dd ff ff       	jmp    2f80 <buf_put>
    51fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5200:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    5205:	4d 85 ed             	test   %r13,%r13
    5208:	0f 84 c2 0b 00 00    	je     5dd0 <fwp_write.constprop.0+0xe00>
    520e:	48 8d 35 15 5f 00 00 	lea    0x5f15(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5215:	4c 89 ef             	mov    %r13,%rdi
    5218:	e8 f3 d2 ff ff       	call   2510 <strcmp@plt>
    521d:	41 89 c1             	mov    %eax,%r9d
    5220:	85 c0                	test   %eax,%eax
    5222:	0f 84 2c 0c 00 00    	je     5e54 <fwp_write.constprop.0+0xe84>
    5228:	4c 89 ef             	mov    %r13,%rdi
    522b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5230:	e8 fb d1 ff ff       	call   2430 <strlen@plt>
    5235:	4c 89 ee             	mov    %r13,%rsi
    5238:	48 89 df             	mov    %rbx,%rdi
    523b:	48 89 c2             	mov    %rax,%rdx
    523e:	e8 3d dd ff ff       	call   2f80 <buf_put>
    5243:	ba 01 00 00 00       	mov    $0x1,%edx
    5248:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    524d:	48 89 df             	mov    %rbx,%rdi
    5250:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5255:	e8 26 dd ff ff       	call   2f80 <buf_put>
    525a:	ba 01 00 00 00       	mov    $0x1,%edx
    525f:	4c 89 fe             	mov    %r15,%rsi
    5262:	48 89 df             	mov    %rbx,%rdi
    5265:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    526a:	e8 11 dd ff ff       	call   2f80 <buf_put>
    526f:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    5274:	45 31 f6             	xor    %r14d,%r14d
    5277:	85 c0                	test   %eax,%eax
    5279:	0f 8e 91 0a 00 00    	jle    5d10 <fwp_write.constprop.0+0xd40>
    527f:	45 31 ed             	xor    %r13d,%r13d
    5282:	4d 85 ed             	test   %r13,%r13
    5285:	0f 85 d5 08 00 00    	jne    5b60 <fwp_write.constprop.0+0xb90>
    528b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5292:	00 
    5293:	45 85 f6             	test   %r14d,%r14d
    5296:	0f 84 74 08 00 00    	je     5b10 <fwp_write.constprop.0+0xb40>
    529c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    52a1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    52a6:	48 89 df             	mov    %rbx,%rdi
    52a9:	49 83 c5 01          	add    $0x1,%r13
    52ad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    52b1:	e8 1a fd ff ff       	call   4fd0 <fwp_write.constprop.0>
    52b6:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    52bb:	7f c5                	jg     5282 <fwp_write.constprop.0+0x2b2>
    52bd:	45 85 f6             	test   %r14d,%r14d
    52c0:	0f 84 4a 0a 00 00    	je     5d10 <fwp_write.constprop.0+0xd40>
    52c6:	b8 29 00 00 00       	mov    $0x29,%eax
    52cb:	ba 01 00 00 00       	mov    $0x1,%edx
    52d0:	4c 89 fe             	mov    %r15,%rsi
    52d3:	48 89 df             	mov    %rbx,%rdi
    52d6:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    52da:	e8 a1 dc ff ff       	call   2f80 <buf_put>
    52df:	e9 7c fd ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    52e4:	0f 1f 40 00          	nopl   0x0(%rax)
    52e8:	ba 01 00 00 00       	mov    $0x1,%edx
    52ed:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    52f2:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    52f7:	e8 84 dc ff ff       	call   2f80 <buf_put>
    52fc:	48 85 ed             	test   %rbp,%rbp
    52ff:	0f 84 8b 07 00 00    	je     5a90 <fwp_write.constprop.0+0xac0>
    5305:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    5309:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    530e:	48 89 df             	mov    %rbx,%rdi
    5311:	e8 ba fc ff ff       	call   4fd0 <fwp_write.constprop.0>
    5316:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    531a:	48 85 ed             	test   %rbp,%rbp
    531d:	0f 84 6d 07 00 00    	je     5a90 <fwp_write.constprop.0+0xac0>
    5323:	ba 02 00 00 00       	mov    $0x2,%edx
    5328:	48 8d 35 ee 5d 00 00 	lea    0x5dee(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    532f:	48 89 df             	mov    %rbx,%rdi
    5332:	e8 49 dc ff ff       	call   2f80 <buf_put>
    5337:	eb cc                	jmp    5305 <fwp_write.constprop.0+0x335>
    5339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5340:	4c 8b 2e             	mov    (%rsi),%r13
    5343:	ba 01 00 00 00       	mov    $0x1,%edx
    5348:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    534d:	48 83 c5 08          	add    $0x8,%rbp
    5351:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5356:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    535b:	e8 20 dc ff ff       	call   2f80 <buf_put>
    5360:	4d 8d 64 2d 00       	lea    0x0(%r13,%rbp,1),%r12
    5365:	4d 85 ed             	test   %r13,%r13
    5368:	75 43                	jne    53ad <fwp_write.constprop.0+0x3dd>
    536a:	e9 81 07 00 00       	jmp    5af0 <fwp_write.constprop.0+0xb20>
    536f:	90                   	nop
    5370:	41 80 f9 09          	cmp    $0x9,%r9b
    5374:	0f 84 f6 06 00 00    	je     5a70 <fwp_write.constprop.0+0xaa0>
    537a:	41 80 f9 0a          	cmp    $0xa,%r9b
    537e:	0f 85 bc 06 00 00    	jne    5a40 <fwp_write.constprop.0+0xa70>
    5384:	ba 02 00 00 00       	mov    $0x2,%edx
    5389:	48 8d 35 73 5d 00 00 	lea    0x5d73(%rip),%rsi        # b103 <_IO_stdin_used+0x103>
    5390:	48 89 df             	mov    %rbx,%rdi
    5393:	e8 e8 db ff ff       	call   2f80 <buf_put>
    5398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    539f:	00 
    53a0:	48 83 c5 01          	add    $0x1,%rbp
    53a4:	49 39 ec             	cmp    %rbp,%r12
    53a7:	0f 84 43 07 00 00    	je     5af0 <fwp_write.constprop.0+0xb20>
    53ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    53b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    53b6:	0f 84 64 06 00 00    	je     5a20 <fwp_write.constprop.0+0xa50>
    53bc:	7e b2                	jle    5370 <fwp_write.constprop.0+0x3a0>
    53be:	41 80 f9 22          	cmp    $0x22,%r9b
    53c2:	0f 84 38 06 00 00    	je     5a00 <fwp_write.constprop.0+0xa30>
    53c8:	41 80 f9 5c          	cmp    $0x5c,%r9b
    53cc:	0f 85 6e 06 00 00    	jne    5a40 <fwp_write.constprop.0+0xa70>
    53d2:	ba 02 00 00 00       	mov    $0x2,%edx
    53d7:	48 8d 35 22 5d 00 00 	lea    0x5d22(%rip),%rsi        # b100 <_IO_stdin_used+0x100>
    53de:	48 89 df             	mov    %rbx,%rdi
    53e1:	e8 9a db ff ff       	call   2f80 <buf_put>
    53e6:	eb b8                	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    53e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    53ef:	00 
    53f0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    53f5:	ba 01 00 00 00       	mov    $0x1,%edx
    53fa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    53ff:	48 89 ee             	mov    %rbp,%rsi
    5402:	e8 79 db ff ff       	call   2f80 <buf_put>
    5407:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    540c:	4c 89 e7             	mov    %r12,%rdi
    540f:	e8 1c d0 ff ff       	call   2430 <strlen@plt>
    5414:	4c 89 e6             	mov    %r12,%rsi
    5417:	48 89 df             	mov    %rbx,%rdi
    541a:	48 89 c2             	mov    %rax,%rdx
    541d:	e8 5e db ff ff       	call   2f80 <buf_put>
    5422:	ba 01 00 00 00       	mov    $0x1,%edx
    5427:	48 89 ee             	mov    %rbp,%rsi
    542a:	48 89 df             	mov    %rbx,%rdi
    542d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    5432:	e8 49 db ff ff       	call   2f80 <buf_put>
    5437:	e9 24 fc ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    543c:	0f 1f 40 00          	nopl   0x0(%rax)
    5440:	66 48 0f 6e ce       	movq   %rsi,%xmm1
    5445:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    5449:	0f 8a de 0a 00 00    	jp     5f2d <fwp_write.constprop.0+0xf5d>
    544f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5453:	66 0f 54 05 65 60 00 	andpd  0x6065(%rip),%xmm0        # b4c0 <msg.3+0x80>
    545a:	00 
    545b:	bd 01 00 00 00       	mov    $0x1,%ebp
    5460:	66 0f 2e 05 88 60 00 	ucomisd 0x6088(%rip),%xmm0        # b4f0 <msg.3+0xb0>
    5467:	00 
    5468:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    546f:	00 
    5470:	0f 87 02 09 00 00    	ja     5d78 <fwp_write.constprop.0+0xda8>
    5476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    547d:	00 00 00 
    5480:	66 0f 28 c1          	movapd %xmm1,%xmm0
    5484:	89 ee                	mov    %ebp,%esi
    5486:	4c 89 e7             	mov    %r12,%rdi
    5489:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    548e:	e8 ed dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    5493:	31 f6                	xor    %esi,%esi
    5495:	4c 89 e7             	mov    %r12,%rdi
    5498:	e8 53 cf ff ff       	call   23f0 <strtod@plt>
    549d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    54a2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    54a6:	7a 06                	jp     54ae <fwp_write.constprop.0+0x4de>
    54a8:	0f 84 09 03 00 00    	je     57b7 <fwp_write.constprop.0+0x7e7>
    54ae:	83 c5 01             	add    $0x1,%ebp
    54b1:	83 fd 12             	cmp    $0x12,%ebp
    54b4:	75 ca                	jne    5480 <fwp_write.constprop.0+0x4b0>
    54b6:	be 11 00 00 00       	mov    $0x11,%esi
    54bb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    54bf:	4c 89 e7             	mov    %r12,%rdi
    54c2:	e8 b9 dc ff ff       	call   3180 <fwp_format_g.constprop.0>
    54c7:	e9 eb 02 00 00       	jmp    57b7 <fwp_write.constprop.0+0x7e7>
    54cc:	0f 1f 40 00          	nopl   0x0(%rax)
    54d0:	48 83 fe 01          	cmp    $0x1,%rsi
    54d4:	0f 84 86 08 00 00    	je     5d60 <fwp_write.constprop.0+0xd90>
    54da:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    54de:	b8 02 00 00 00       	mov    $0x2,%eax
    54e3:	ba 01 00 00 00       	mov    $0x1,%edx
    54e8:	48 0f 44 d0          	cmove  %rax,%rdx
    54ec:	48 8d 35 d9 5b 00 00 	lea    0x5bd9(%rip),%rsi        # b0cc <_IO_stdin_used+0xcc>
    54f3:	48 8d 05 cf 5b 00 00 	lea    0x5bcf(%rip),%rax        # b0c9 <_IO_stdin_used+0xc9>
    54fa:	48 0f 44 f0          	cmove  %rax,%rsi
    54fe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5505:	00 
    5506:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    550d:	00 00 
    550f:	0f 84 ce fc ff ff    	je     51e3 <fwp_write.constprop.0+0x213>
    5515:	e8 26 cf ff ff       	call   2440 <__stack_chk_fail@plt>
    551a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5520:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    5525:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    552a:	e8 91 d9 ff ff       	call   2ec0 <buf_grow>
    552f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    5533:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    5539:	4c 03 0b             	add    (%rbx),%r9
    553c:	66 45 89 11          	mov    %r10w,(%r9)
    5540:	49 83 c1 01          	add    $0x1,%r9
    5544:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    554b:	55 55 55 
    554e:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    5555:	aa aa aa 
    5558:	4b 8d 3c 0c          	lea    (%r12,%r9,1),%rdi
    555c:	45 85 e4             	test   %r12d,%r12d
    555f:	7f 4c                	jg     55ad <fwp_write.constprop.0+0x5dd>
    5561:	e9 4a 05 00 00       	jmp    5ab0 <fwp_write.constprop.0+0xae0>
    5566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    556d:	00 00 00 
    5570:	be 01 00 00 00       	mov    $0x1,%esi
    5575:	b8 2d 00 00 00       	mov    $0x2d,%eax
    557a:	88 07                	mov    %al,(%rdi)
    557c:	48 89 e8             	mov    %rbp,%rax
    557f:	49 f7 e8             	imul   %r8
    5582:	48 89 e8             	mov    %rbp,%rax
    5585:	48 c1 f8 3f          	sar    $0x3f,%rax
    5589:	48 29 c2             	sub    %rax,%rdx
    558c:	48 85 c9             	test   %rcx,%rcx
    558f:	0f 95 c0             	setne  %al
    5592:	48 c1 ed 3f          	shr    $0x3f,%rbp
    5596:	48 83 ef 01          	sub    $0x1,%rdi
    559a:	48 21 c5             	and    %rax,%rbp
    559d:	48 29 ea             	sub    %rbp,%rdx
    55a0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    55a4:	49 39 f9             	cmp    %rdi,%r9
    55a7:	0f 84 03 05 00 00    	je     5ab0 <fwp_write.constprop.0+0xae0>
    55ad:	48 89 e8             	mov    %rbp,%rax
    55b0:	49 f7 e8             	imul   %r8
    55b3:	48 89 e8             	mov    %rbp,%rax
    55b6:	48 c1 f8 3f          	sar    $0x3f,%rax
    55ba:	48 89 d1             	mov    %rdx,%rcx
    55bd:	48 29 c1             	sub    %rax,%rcx
    55c0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    55c4:	48 89 e9             	mov    %rbp,%rcx
    55c7:	48 29 c1             	sub    %rax,%rcx
    55ca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    55ce:	49 f7 e2             	mul    %r10
    55d1:	b8 30 00 00 00       	mov    $0x30,%eax
    55d6:	48 89 d6             	mov    %rdx,%rsi
    55d9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    55dd:	48 d1 ee             	shr    $1,%rsi
    55e0:	48 01 f2             	add    %rsi,%rdx
    55e3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    55e7:	48 29 d6             	sub    %rdx,%rsi
    55ea:	74 8e                	je     557a <fwp_write.constprop.0+0x5aa>
    55ec:	48 83 fe 01          	cmp    $0x1,%rsi
    55f0:	0f 85 7a ff ff ff    	jne    5570 <fwp_write.constprop.0+0x5a0>
    55f6:	31 f6                	xor    %esi,%esi
    55f8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    55fd:	e9 78 ff ff ff       	jmp    557a <fwp_write.constprop.0+0x5aa>
    5602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5608:	ba 06 00 00 00       	mov    $0x6,%edx
    560d:	48 8d 35 0c 5b 00 00 	lea    0x5b0c(%rip),%rsi        # b120 <_IO_stdin_used+0x120>
    5614:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    561a:	e8 61 d9 ff ff       	call   2f80 <buf_put>
    561f:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    5626:	ff ff 7f 
    5629:	48 23 55 00          	and    0x0(%rbp),%rdx
    562d:	0f 84 4e 03 00 00    	je     5981 <fwp_write.constprop.0+0x9b1>
    5633:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    5638:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    563c:	48 85 d2             	test   %rdx,%rdx
    563f:	0f 84 a4 00 00 00    	je     56e9 <fwp_write.constprop.0+0x719>
    5645:	8b 0a                	mov    (%rdx),%ecx
    5647:	83 f9 1c             	cmp    $0x1c,%ecx
    564a:	0f 84 d0 06 00 00    	je     5d20 <fwp_write.constprop.0+0xd50>
    5650:	83 f9 1b             	cmp    $0x1b,%ecx
    5653:	0f 87 90 00 00 00    	ja     56e9 <fwp_write.constprop.0+0x719>
    5659:	be 01 00 00 00       	mov    $0x1,%esi
    565e:	48 d3 e6             	shl    %cl,%rsi
    5661:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    5667:	0f 85 13 06 00 00    	jne    5c80 <fwp_write.constprop.0+0xcb0>
    566d:	f7 c6 84 04 00 00    	test   $0x484,%esi
    5673:	0f 85 d7 05 00 00    	jne    5c50 <fwp_write.constprop.0+0xc80>
    5679:	83 e6 21             	and    $0x21,%esi
    567c:	74 6b                	je     56e9 <fwp_write.constprop.0+0x719>
    567e:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    5683:	48 85 ff             	test   %rdi,%rdi
    5686:	79 07                	jns    568f <fwp_write.constprop.0+0x6bf>
    5688:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    568c:	4c 01 ee             	add    %r13,%rsi
    568f:	48 0f be 3e          	movsbq (%rsi),%rdi
    5693:	85 c9                	test   %ecx,%ecx
    5695:	40 0f b6 f7          	movzbl %dil,%esi
    5699:	48 0f 44 f7          	cmove  %rdi,%rsi
    569d:	0f 1f 00             	nopl   (%rax)
    56a0:	48 89 df             	mov    %rbx,%rdi
    56a3:	49 83 c5 01          	add    $0x1,%r13
    56a7:	e8 24 f9 ff ff       	call   4fd0 <fwp_write.constprop.0>
    56ac:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    56b3:	ff ff 7f 
    56b6:	48 23 55 00          	and    0x0(%rbp),%rdx
    56ba:	49 39 d5             	cmp    %rdx,%r13
    56bd:	0f 83 be 02 00 00    	jae    5981 <fwp_write.constprop.0+0x9b1>
    56c3:	ba 02 00 00 00       	mov    $0x2,%edx
    56c8:	48 89 df             	mov    %rbx,%rdi
    56cb:	48 8d 35 4b 5a 00 00 	lea    0x5a4b(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    56d2:	e8 a9 d8 ff ff       	call   2f80 <buf_put>
    56d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    56dc:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    56e0:	48 85 d2             	test   %rdx,%rdx
    56e3:	0f 85 5c ff ff ff    	jne    5645 <fwp_write.constprop.0+0x675>
    56e9:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    56ee:	48 85 ff             	test   %rdi,%rdi
    56f1:	0f 88 51 06 00 00    	js     5d48 <fwp_write.constprop.0+0xd78>
    56f7:	48 8b 31             	mov    (%rcx),%rsi
    56fa:	eb a4                	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    56fc:	0f 1f 40 00          	nopl   0x0(%rax)
    5700:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5707:	00 
    5708:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    570f:	00 00 
    5711:	0f 85 fe fd ff ff    	jne    5515 <fwp_write.constprop.0+0x545>
    5717:	ba 08 00 00 00       	mov    $0x8,%edx
    571c:	48 8d 35 ca 59 00 00 	lea    0x59ca(%rip),%rsi        # b0ed <_IO_stdin_used+0xed>
    5723:	e9 bb fa ff ff       	jmp    51e3 <fwp_write.constprop.0+0x213>
    5728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    572f:	00 
    5730:	66 0f 6e ce          	movd   %esi,%xmm1
    5734:	0f 2e c9             	ucomiss %xmm1,%xmm1
    5737:	0f 8a f0 07 00 00    	jp     5f2d <fwp_write.constprop.0+0xf5d>
    573d:	0f 28 c1             	movaps %xmm1,%xmm0
    5740:	0f 54 05 69 5d 00 00 	andps  0x5d69(%rip),%xmm0        # b4b0 <msg.3+0x70>
    5747:	0f 2e 05 b6 58 00 00 	ucomiss 0x58b6(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    574e:	0f 87 4c 06 00 00    	ja     5da0 <fwp_write.constprop.0+0xdd0>
    5754:	66 0f ef d2          	pxor   %xmm2,%xmm2
    5758:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    575e:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5765:	00 
    5766:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    576a:	66 49 0f 7e d7       	movq   %xmm2,%r15
    576f:	90                   	nop
    5770:	44 89 ee             	mov    %r13d,%esi
    5773:	66 49 0f 6e c7       	movq   %r15,%xmm0
    5778:	4c 89 e7             	mov    %r12,%rdi
    577b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    5780:	e8 fb d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    5785:	31 f6                	xor    %esi,%esi
    5787:	4c 89 e7             	mov    %r12,%rdi
    578a:	e8 01 cd ff ff       	call   2490 <strtof@plt>
    578f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    5794:	0f 2e c8             	ucomiss %xmm0,%xmm1
    5797:	7a 02                	jp     579b <fwp_write.constprop.0+0x7cb>
    5799:	74 1c                	je     57b7 <fwp_write.constprop.0+0x7e7>
    579b:	41 83 c5 01          	add    $0x1,%r13d
    579f:	41 83 fd 0a          	cmp    $0xa,%r13d
    57a3:	75 cb                	jne    5770 <fwp_write.constprop.0+0x7a0>
    57a5:	be 09 00 00 00       	mov    $0x9,%esi
    57aa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    57af:	4c 89 e7             	mov    %r12,%rdi
    57b2:	e8 c9 d9 ff ff       	call   3180 <fwp_format_g.constprop.0>
    57b7:	4c 89 e7             	mov    %r12,%rdi
    57ba:	e8 81 d8 ff ff       	call   3040 <fwp_finish_float>
    57bf:	e9 7c f8 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    57c4:	0f 1f 40 00          	nopl   0x0(%rax)
    57c8:	89 f0                	mov    %esi,%eax
    57ca:	48 81 fe ff 0f 00 00 	cmp    $0xfff,%rsi
    57d1:	76 02                	jbe    57d5 <fwp_write.constprop.0+0x805>
    57d3:	8b 06                	mov    (%rsi),%eax
    57d5:	41 89 c6             	mov    %eax,%r14d
    57d8:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    57dd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    57e2:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    57e6:	4c 89 ef             	mov    %r13,%rdi
    57e9:	e8 42 cc ff ff       	call   2430 <strlen@plt>
    57ee:	4c 89 ee             	mov    %r13,%rsi
    57f1:	48 89 df             	mov    %rbx,%rdi
    57f4:	48 89 c2             	mov    %rax,%rdx
    57f7:	e8 84 d7 ff ff       	call   2f80 <buf_put>
    57fc:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    5801:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    5805:	85 f6                	test   %esi,%esi
    5807:	0f 8e 53 f8 ff ff    	jle    5060 <fwp_write.constprop.0+0x90>
    580d:	45 31 ed             	xor    %r13d,%r13d
    5810:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5815:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    581a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    581f:	4c 89 fe             	mov    %r15,%rsi
    5822:	48 89 df             	mov    %rbx,%rdi
    5825:	ba 01 00 00 00       	mov    $0x1,%edx
    582a:	48 89 04 24          	mov    %rax,(%rsp)
    582e:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    5833:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
    5837:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    583b:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    5840:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    5845:	e8 36 d7 ff ff       	call   2f80 <buf_put>
    584a:	41 8b 06             	mov    (%r14),%eax
    584d:	83 f8 0e             	cmp    $0xe,%eax
    5850:	0f 84 5a 03 00 00    	je     5bb0 <fwp_write.constprop.0+0xbe0>
    5856:	83 f8 10             	cmp    $0x10,%eax
    5859:	0f 84 21 03 00 00    	je     5b80 <fwp_write.constprop.0+0xbb0>
    585f:	83 f8 0a             	cmp    $0xa,%eax
    5862:	0f 84 68 04 00 00    	je     5cd0 <fwp_write.constprop.0+0xd00>
    5868:	0f 8f 32 01 00 00    	jg     59a0 <fwp_write.constprop.0+0x9d0>
    586e:	83 f8 03             	cmp    $0x3,%eax
    5871:	0f 8f 39 04 00 00    	jg     5cb0 <fwp_write.constprop.0+0xce0>
    5877:	85 c0                	test   %eax,%eax
    5879:	78 10                	js     588b <fwp_write.constprop.0+0x8bb>
    587b:	48 8b 04 24          	mov    (%rsp),%rax
    587f:	48 c1 e8 3f          	shr    $0x3f,%rax
    5883:	85 c0                	test   %eax,%eax
    5885:	0f 85 32 01 00 00    	jne    59bd <fwp_write.constprop.0+0x9ed>
    588b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5890:	48 8b 34 24          	mov    (%rsp),%rsi
    5894:	48 89 df             	mov    %rbx,%rdi
    5897:	e8 34 f7 ff ff       	call   4fd0 <fwp_write.constprop.0>
    589c:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    58a1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    58a6:	49 83 c5 01          	add    $0x1,%r13
    58aa:	44 39 2c 88          	cmp    %r13d,(%rax,%rcx,4)
    58ae:	0f 8f 61 ff ff ff    	jg     5815 <fwp_write.constprop.0+0x845>
    58b4:	e9 a7 f7 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    58b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58c0:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    58c4:	48 8b 36             	mov    (%rsi),%rsi
    58c7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    58ce:	00 
    58cf:	48 89 ef             	mov    %rbp,%rdi
    58d2:	e8 29 d1 ff ff       	call   2a00 <fwp_fmt_u128>
    58d7:	48 89 ef             	mov    %rbp,%rdi
    58da:	e8 51 cb ff ff       	call   2430 <strlen@plt>
    58df:	48 89 ee             	mov    %rbp,%rsi
    58e2:	48 89 df             	mov    %rbx,%rdi
    58e5:	48 89 c2             	mov    %rax,%rdx
    58e8:	e8 93 d6 ff ff       	call   2f80 <buf_put>
    58ed:	e9 6e f7 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    58f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    58f8:	ba 06 00 00 00       	mov    $0x6,%edx
    58fd:	48 8d 35 0f 58 00 00 	lea    0x580f(%rip),%rsi        # b113 <_IO_stdin_used+0x113>
    5904:	45 31 ed             	xor    %r13d,%r13d
    5907:	e8 74 d6 ff ff       	call   2f80 <buf_put>
    590c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    5911:	75 19                	jne    592c <fwp_write.constprop.0+0x95c>
    5913:	eb 6c                	jmp    5981 <fwp_write.constprop.0+0x9b1>
    5915:	0f 1f 00             	nopl   (%rax)
    5918:	ba 02 00 00 00       	mov    $0x2,%edx
    591d:	48 8d 35 f9 57 00 00 	lea    0x57f9(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5924:	48 89 df             	mov    %rbx,%rdi
    5927:	e8 54 d6 ff ff       	call   2f80 <buf_put>
    592c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    5932:	b9 00 02 00 00       	mov    $0x200,%ecx
    5937:	31 c0                	xor    %eax,%eax
    5939:	49 83 c5 01          	add    $0x1,%r13
    593d:	4c 8d 05 d6 57 00 00 	lea    0x57d6(%rip),%r8        # b11a <_IO_stdin_used+0x11a>
    5944:	ba 02 00 00 00       	mov    $0x2,%edx
    5949:	be 00 02 00 00       	mov    $0x200,%esi
    594e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5955:	00 
    5956:	e8 35 ca ff ff       	call   2390 <__snprintf_chk@plt>
    595b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5962:	00 
    5963:	e8 c8 ca ff ff       	call   2430 <strlen@plt>
    5968:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    596f:	00 
    5970:	48 89 df             	mov    %rbx,%rdi
    5973:	48 89 c2             	mov    %rax,%rdx
    5976:	e8 05 d6 ff ff       	call   2f80 <buf_put>
    597b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    597f:	72 97                	jb     5918 <fwp_write.constprop.0+0x948>
    5981:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5986:	ba 01 00 00 00       	mov    $0x1,%edx
    598b:	48 89 df             	mov    %rbx,%rdi
    598e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5993:	e8 e8 d5 ff ff       	call   2f80 <buf_put>
    5998:	e9 c3 f6 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    599d:	0f 1f 00             	nopl   (%rax)
    59a0:	83 f8 0b             	cmp    $0xb,%eax
    59a3:	0f 85 e2 fe ff ff    	jne    588b <fwp_write.constprop.0+0x8bb>
    59a9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    59ae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    59b2:	83 e0 01             	and    $0x1,%eax
    59b5:	85 c0                	test   %eax,%eax
    59b7:	0f 84 ce fe ff ff    	je     588b <fwp_write.constprop.0+0x8bb>
    59bd:	4c 89 fe             	mov    %r15,%rsi
    59c0:	48 89 df             	mov    %rbx,%rdi
    59c3:	ba 01 00 00 00       	mov    $0x1,%edx
    59c8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    59cd:	e8 ae d5 ff ff       	call   2f80 <buf_put>
    59d2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    59d7:	48 8b 34 24          	mov    (%rsp),%rsi
    59db:	48 89 df             	mov    %rbx,%rdi
    59de:	e8 ed f5 ff ff       	call   4fd0 <fwp_write.constprop.0>
    59e3:	ba 01 00 00 00       	mov    $0x1,%edx
    59e8:	4c 89 fe             	mov    %r15,%rsi
    59eb:	48 89 df             	mov    %rbx,%rdi
    59ee:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    59f3:	e8 88 d5 ff ff       	call   2f80 <buf_put>
    59f8:	e9 9f fe ff ff       	jmp    589c <fwp_write.constprop.0+0x8cc>
    59fd:	0f 1f 00             	nopl   (%rax)
    5a00:	ba 02 00 00 00       	mov    $0x2,%edx
    5a05:	48 8d 35 f1 56 00 00 	lea    0x56f1(%rip),%rsi        # b0fd <_IO_stdin_used+0xfd>
    5a0c:	48 89 df             	mov    %rbx,%rdi
    5a0f:	e8 6c d5 ff ff       	call   2f80 <buf_put>
    5a14:	e9 87 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a20:	ba 02 00 00 00       	mov    $0x2,%edx
    5a25:	48 8d 35 dd 56 00 00 	lea    0x56dd(%rip),%rsi        # b109 <_IO_stdin_used+0x109>
    5a2c:	48 89 df             	mov    %rbx,%rdi
    5a2f:	e8 4c d5 ff ff       	call   2f80 <buf_put>
    5a34:	e9 67 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    5a44:	0f 86 b6 01 00 00    	jbe    5c00 <fwp_write.constprop.0+0xc30>
    5a4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    5a4e:	0f 84 ac 01 00 00    	je     5c00 <fwp_write.constprop.0+0xc30>
    5a54:	ba 01 00 00 00       	mov    $0x1,%edx
    5a59:	4c 89 fe             	mov    %r15,%rsi
    5a5c:	48 89 df             	mov    %rbx,%rdi
    5a5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    5a64:	e8 17 d5 ff ff       	call   2f80 <buf_put>
    5a69:	e9 32 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a6e:	66 90                	xchg   %ax,%ax
    5a70:	ba 02 00 00 00       	mov    $0x2,%edx
    5a75:	48 8d 35 8a 56 00 00 	lea    0x568a(%rip),%rsi        # b106 <_IO_stdin_used+0x106>
    5a7c:	48 89 df             	mov    %rbx,%rdi
    5a7f:	e8 fc d4 ff ff       	call   2f80 <buf_put>
    5a84:	e9 17 f9 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a90:	ba 01 00 00 00       	mov    $0x1,%edx
    5a95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5a9a:	48 89 df             	mov    %rbx,%rdi
    5a9d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    5aa2:	e8 d9 d4 ff ff       	call   2f80 <buf_put>
    5aa7:	e9 b4 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)
    5ab0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    5ab4:	48 8b 13             	mov    (%rbx),%rdx
    5ab7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    5abc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5ac0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    5ac4:	e9 97 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ad0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5ad5:	ba 01 00 00 00       	mov    $0x1,%edx
    5ada:	48 89 df             	mov    %rbx,%rdi
    5add:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    5ae2:	e8 99 d4 ff ff       	call   2f80 <buf_put>
    5ae7:	e9 74 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5aec:	0f 1f 40 00          	nopl   0x0(%rax)
    5af0:	ba 01 00 00 00       	mov    $0x1,%edx
    5af5:	4c 89 fe             	mov    %r15,%rsi
    5af8:	48 89 df             	mov    %rbx,%rdi
    5afb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    5b00:	e8 7b d4 ff ff       	call   2f80 <buf_put>
    5b05:	e9 56 f5 ff ff       	jmp    5060 <fwp_write.constprop.0+0x90>
    5b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5b10:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    5b15:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5b1a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    5b1e:	48 89 f7             	mov    %rsi,%rdi
    5b21:	48 89 34 24          	mov    %rsi,(%rsp)
    5b25:	e8 06 c9 ff ff       	call   2430 <strlen@plt>
    5b2a:	48 8b 34 24          	mov    (%rsp),%rsi
    5b2e:	48 89 df             	mov    %rbx,%rdi
    5b31:	48 89 c2             	mov    %rax,%rdx
    5b34:	e8 47 d4 ff ff       	call   2f80 <buf_put>
    5b39:	ba 03 00 00 00       	mov    $0x3,%edx
    5b3e:	48 8d 35 fb 55 00 00 	lea    0x55fb(%rip),%rsi        # b140 <_IO_stdin_used+0x140>
    5b45:	48 89 df             	mov    %rbx,%rdi
    5b48:	e8 33 d4 ff ff       	call   2f80 <buf_put>
    5b4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5b52:	e9 45 f7 ff ff       	jmp    529c <fwp_write.constprop.0+0x2cc>
    5b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b5e:	00 00 
    5b60:	ba 02 00 00 00       	mov    $0x2,%edx
    5b65:	48 8d 35 b1 55 00 00 	lea    0x55b1(%rip),%rsi        # b11d <_IO_stdin_used+0x11d>
    5b6c:	48 89 df             	mov    %rbx,%rdi
    5b6f:	e8 0c d4 ff ff       	call   2f80 <buf_put>
    5b74:	e9 12 f7 ff ff       	jmp    528b <fwp_write.constprop.0+0x2bb>
    5b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    5b85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    5b89:	48 85 ff             	test   %rdi,%rdi
    5b8c:	0f 84 f9 fc ff ff    	je     588b <fwp_write.constprop.0+0x8bb>
    5b92:	48 8d 35 91 55 00 00 	lea    0x5591(%rip),%rsi        # b12a <_IO_stdin_used+0x12a>
    5b99:	e8 72 c9 ff ff       	call   2510 <strcmp@plt>
    5b9e:	85 c0                	test   %eax,%eax
    5ba0:	0f 95 c0             	setne  %al
    5ba3:	0f b6 c0             	movzbl %al,%eax
    5ba6:	e9 d8 fc ff ff       	jmp    5883 <fwp_write.constprop.0+0x8b3>
    5bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5bb0:	31 c0                	xor    %eax,%eax
    5bb2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    5bb9:	00 
    5bba:	0f 97 c0             	seta   %al
    5bbd:	e9 c1 fc ff ff       	jmp    5883 <fwp_write.constprop.0+0x8b3>
    5bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bc8:	48 89 df             	mov    %rbx,%rdi
    5bcb:	ba 02 00 00 00       	mov    $0x2,%edx
    5bd0:	48 8d 35 50 55 00 00 	lea    0x5550(%rip),%rsi        # b127 <_IO_stdin_used+0x127>
    5bd7:	e8 a4 d3 ff ff       	call   2f80 <buf_put>
    5bdc:	4c 89 e8             	mov    %r13,%rax
    5bdf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    5be4:	48 89 df             	mov    %rbx,%rdi
    5be7:	48 c1 e0 04          	shl    $0x4,%rax
    5beb:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    5bf0:	e8 db f3 ff ff       	call   4fd0 <fwp_write.constprop.0>
    5bf5:	e9 4e f5 ff ff       	jmp    5148 <fwp_write.constprop.0+0x178>
    5bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c00:	4c 8d 05 05 55 00 00 	lea    0x5505(%rip),%r8        # b10c <_IO_stdin_used+0x10c>
    5c07:	b9 10 00 00 00       	mov    $0x10,%ecx
    5c0c:	31 c0                	xor    %eax,%eax
    5c0e:	ba 02 00 00 00       	mov    $0x2,%edx
    5c13:	be 10 00 00 00       	mov    $0x10,%esi
    5c18:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c1f:	00 
    5c20:	e8 6b c7 ff ff       	call   2390 <__snprintf_chk@plt>
    5c25:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    5c2c:	00 
    5c2d:	e8 fe c7 ff ff       	call   2430 <strlen@plt>
    5c32:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    5c39:	00 
    5c3a:	48 89 df             	mov    %rbx,%rdi
    5c3d:	48 89 c2             	mov    %rax,%rdx
    5c40:	e8 3b d3 ff ff       	call   2f80 <buf_put>
    5c45:	e9 56 f7 ff ff       	jmp    53a0 <fwp_write.constprop.0+0x3d0>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    5c55:	48 85 ff             	test   %rdi,%rdi
    5c58:	79 0c                	jns    5c66 <fwp_write.constprop.0+0xc96>
    5c5a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    5c61:	00 
    5c62:	48 03 75 10          	add    0x10(%rbp),%rsi
    5c66:	48 63 3e             	movslq (%rsi),%rdi
    5c69:	83 f9 02             	cmp    $0x2,%ecx
    5c6c:	89 fe                	mov    %edi,%esi
    5c6e:	48 0f 44 f7          	cmove  %rdi,%rsi
    5c72:	e9 29 fa ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c7e:	00 00 
    5c80:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    5c85:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    5c8a:	48 85 ff             	test   %rdi,%rdi
    5c8d:	0f 88 6f 01 00 00    	js     5e02 <fwp_write.constprop.0+0xe32>
    5c93:	49 0f bf 38          	movswq (%r8),%rdi
    5c97:	83 f9 01             	cmp    $0x1,%ecx
    5c9a:	0f b7 f7             	movzwl %di,%esi
    5c9d:	48 0f 44 f7          	cmove  %rdi,%rsi
    5ca1:	e9 fa f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cad:	00 00 00 
    5cb0:	83 f8 04             	cmp    $0x4,%eax
    5cb3:	0f 85 d2 fb ff ff    	jne    588b <fwp_write.constprop.0+0x8bb>
    5cb9:	48 8b 04 24          	mov    (%rsp),%rax
    5cbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    5cc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5cc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    5cca:	e9 e6 fc ff ff       	jmp    59b5 <fwp_write.constprop.0+0x9e5>
    5ccf:	90                   	nop
    5cd0:	8b 0c 24             	mov    (%rsp),%ecx
    5cd3:	31 c0                	xor    %eax,%eax
    5cd5:	85 c9                	test   %ecx,%ecx
    5cd7:	0f 98 c0             	sets   %al
    5cda:	e9 d6 fc ff ff       	jmp    59b5 <fwp_write.constprop.0+0x9e5>
    5cdf:	90                   	nop
    5ce0:	48 f7 d8             	neg    %rax
    5ce3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    5cea:	00 
    5ceb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    5cf2:	2d 
    5cf3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5cfa:	00 
    5cfb:	48 83 d2 00          	adc    $0x0,%rdx
    5cff:	48 89 c6             	mov    %rax,%rsi
    5d02:	48 f7 da             	neg    %rdx
    5d05:	e8 f6 cc ff ff       	call   2a00 <fwp_fmt_u128>
    5d0a:	e9 31 f3 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5d0f:	90                   	nop
    5d10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    5d15:	e9 b1 f5 ff ff       	jmp    52cb <fwp_write.constprop.0+0x2fb>
    5d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5d20:	4c 89 e9             	mov    %r13,%rcx
    5d23:	48 c1 e1 04          	shl    $0x4,%rcx
    5d27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    5d2c:	48 85 ff             	test   %rdi,%rdi
    5d2f:	0f 89 6b f9 ff ff    	jns    56a0 <fwp_write.constprop.0+0x6d0>
    5d35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d39:	48 89 ce             	mov    %rcx,%rsi
    5d3c:	e9 5f f9 ff ff       	jmp    56a0 <fwp_write.constprop.0+0x6d0>
    5d41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    5d4f:	00 
    5d50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    5d54:	e9 9e f9 ff ff       	jmp    56f7 <fwp_write.constprop.0+0x727>
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	ba 02 00 00 00       	mov    $0x2,%edx
    5d65:	48 8d 35 5a 53 00 00 	lea    0x535a(%rip),%rsi        # b0c6 <_IO_stdin_used+0xc6>
    5d6c:	e9 8d f7 ff ff       	jmp    54fe <fwp_write.constprop.0+0x52e>
    5d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d7c:	48 8d 35 3f 53 00 00 	lea    0x533f(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5d83:	48 8d 05 37 53 00 00 	lea    0x5337(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5d8a:	4c 89 e7             	mov    %r12,%rdi
    5d8d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    5d91:	48 0f 46 f0          	cmovbe %rax,%rsi
    5d95:	e8 36 c6 ff ff       	call   23d0 <strcpy@plt>
    5d9a:	e9 a1 f2 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5d9f:	90                   	nop
    5da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da4:	48 8d 35 17 53 00 00 	lea    0x5317(%rip),%rsi        # b0c2 <_IO_stdin_used+0xc2>
    5dab:	48 8d 05 0f 53 00 00 	lea    0x530f(%rip),%rax        # b0c1 <_IO_stdin_used+0xc1>
    5db2:	0f 2f c8             	comiss %xmm0,%xmm1
    5db5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5dbc:	00 
    5dbd:	4c 89 e7             	mov    %r12,%rdi
    5dc0:	48 0f 46 f0          	cmovbe %rax,%rsi
    5dc4:	e8 07 c6 ff ff       	call   23d0 <strcpy@plt>
    5dc9:	e9 72 f2 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5dce:	66 90                	xchg   %ax,%ax
    5dd0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    5dd5:	45 85 c0             	test   %r8d,%r8d
    5dd8:	75 34                	jne    5e0e <fwp_write.constprop.0+0xe3e>
    5dda:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    5de1:	00 
    5de2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5de9:	00 00 
    5deb:	0f 85 24 f7 ff ff    	jne    5515 <fwp_write.constprop.0+0x545>
    5df1:	ba 02 00 00 00       	mov    $0x2,%edx
    5df6:	48 8d 35 40 53 00 00 	lea    0x5340(%rip),%rsi        # b13d <_IO_stdin_used+0x13d>
    5dfd:	e9 e1 f3 ff ff       	jmp    51e3 <fwp_write.constprop.0+0x213>
    5e02:	48 03 75 10          	add    0x10(%rbp),%rsi
    5e06:	49 89 f0             	mov    %rsi,%r8
    5e09:	e9 85 fe ff ff       	jmp    5c93 <fwp_write.constprop.0+0xcc3>
    5e0e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    5e13:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e18:	85 ff                	test   %edi,%edi
    5e1a:	0f 84 3a f4 ff ff    	je     525a <fwp_write.constprop.0+0x28a>
    5e20:	ba 01 00 00 00       	mov    $0x1,%edx
    5e25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    5e2a:	48 89 df             	mov    %rbx,%rdi
    5e2d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    5e32:	e8 49 d1 ff ff       	call   2f80 <buf_put>
    5e37:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    5e3c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    5e41:	41 be 01 00 00 00    	mov    $0x1,%r14d
    5e47:	85 d2                	test   %edx,%edx
    5e49:	0f 8f 30 f4 ff ff    	jg     527f <fwp_write.constprop.0+0x2af>
    5e4f:	e9 72 f4 ff ff       	jmp    52c6 <fwp_write.constprop.0+0x2f6>
    5e54:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e58:	49 89 c5             	mov    %rax,%r13
    5e5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5e60:	49 89 c4             	mov    %rax,%r12
    5e63:	49 c1 fd 3f          	sar    $0x3f,%r13
    5e67:	4c 09 e8             	or     %r13,%rax
    5e6a:	0f 84 a7 00 00 00    	je     5f17 <fwp_write.constprop.0+0xf47>
    5e70:	48 8d 2d e9 6c 00 00 	lea    0x6ce9(%rip),%rbp        # cb60 <units.0>
    5e77:	4d 89 e7             	mov    %r12,%r15
    5e7a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    5e7e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    5e83:	4c 89 ff             	mov    %r15,%rdi
    5e86:	4c 89 ee             	mov    %r13,%rsi
    5e89:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e8d:	48 99                	cqto
    5e8f:	48 89 d1             	mov    %rdx,%rcx
    5e92:	48 89 c2             	mov    %rax,%rdx
    5e95:	e8 36 42 00 00       	call   a0d0 <__divmodti4>
    5e9a:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e9e:	48 89 c1             	mov    %rax,%rcx
    5ea1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5ea6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    5eab:	0f 84 94 00 00 00    	je     5f45 <fwp_write.constprop.0+0xf75>
    5eb1:	41 83 c1 01          	add    $0x1,%r9d
    5eb5:	48 83 c5 10          	add    $0x10,%rbp
    5eb9:	41 83 f9 05          	cmp    $0x5,%r9d
    5ebd:	75 bb                	jne    5e7a <fwp_write.constprop.0+0xeaa>
    5ebf:	4d 85 ed             	test   %r13,%r13
    5ec2:	79 53                	jns    5f17 <fwp_write.constprop.0+0xf47>
    5ec4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5ec9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5ece:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5ed3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5ed8:	48 99                	cqto
    5eda:	48 f7 d8             	neg    %rax
    5edd:	48 83 d2 00          	adc    $0x0,%rdx
    5ee1:	48 89 c6             	mov    %rax,%rsi
    5ee4:	48 f7 da             	neg    %rdx
    5ee7:	e8 14 cb ff ff       	call   2a00 <fwp_fmt_u128>
    5eec:	49 89 e8             	mov    %rbp,%r8
    5eef:	ba 00 02 00 00       	mov    $0x200,%edx
    5ef4:	be 02 00 00 00       	mov    $0x2,%esi
    5ef9:	31 c0                	xor    %eax,%eax
    5efb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f02:	00 
    5f03:	48 8d 0d 2e 52 00 00 	lea    0x522e(%rip),%rcx        # b138 <_IO_stdin_used+0x138>
    5f0a:	4c 89 e7             	mov    %r12,%rdi
    5f0d:	e8 8e c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f12:	e9 29 f1 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5f17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5f21:	31 d2                	xor    %edx,%edx
    5f23:	48 89 ef             	mov    %rbp,%rdi
    5f26:	e8 d5 ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f2b:	eb bf                	jmp    5eec <fwp_write.constprop.0+0xf1c>
    5f2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    5f34:	4e 61 4e 00 
    5f38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f3f:	00 
    5f40:	e9 fb f0 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5f45:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f49:	48 89 c8             	mov    %rcx,%rax
    5f4c:	48 85 d2             	test   %rdx,%rdx
    5f4f:	78 51                	js     5fa2 <fwp_write.constprop.0+0xfd2>
    5f51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5f56:	48 89 c6             	mov    %rax,%rsi
    5f59:	48 89 ef             	mov    %rbp,%rdi
    5f5c:	e8 9f ca ff ff       	call   2a00 <fwp_fmt_u128>
    5f61:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f65:	49 63 c1             	movslq %r9d,%rax
    5f68:	49 89 e8             	mov    %rbp,%r8
    5f6b:	ba 00 02 00 00       	mov    $0x200,%edx
    5f70:	be 02 00 00 00       	mov    $0x2,%esi
    5f75:	48 c1 e0 04          	shl    $0x4,%rax
    5f79:	48 8d 0d e0 6b 00 00 	lea    0x6be0(%rip),%rcx        # cb60 <units.0>
    5f80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    5f87:	00 
    5f88:	4c 8b 0c 01          	mov    (%rcx,%rax,1),%r9
    5f8c:	4c 89 e7             	mov    %r12,%rdi
    5f8f:	48 8d 0d 9d 51 00 00 	lea    0x519d(%rip),%rcx        # b133 <_IO_stdin_used+0x133>
    5f96:	31 c0                	xor    %eax,%eax
    5f98:	e8 03 c7 ff ff       	call   26a0 <__sprintf_chk@plt>
    5f9d:	e9 9e f0 ff ff       	jmp    5040 <fwp_write.constprop.0+0x70>
    5fa2:	48 f7 d8             	neg    %rax
    5fa5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    5faa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    5faf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    5fb4:	48 83 d2 00          	adc    $0x0,%rdx
    5fb8:	48 89 c6             	mov    %rax,%rsi
    5fbb:	48 f7 da             	neg    %rdx
    5fbe:	e8 3d ca ff ff       	call   2a00 <fwp_fmt_u128>
    5fc3:	44 8b 0c 24          	mov    (%rsp),%r9d
    5fc7:	eb 9c                	jmp    5f65 <fwp_write.constprop.0+0xf95>
    5fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005fd0 <fwp_hof0.constprop.0>:
    5fd0:	41 57                	push   %r15
    5fd2:	41 56                	push   %r14
    5fd4:	41 55                	push   %r13
    5fd6:	41 54                	push   %r12
    5fd8:	4c 8d 25 61 77 01 00 	lea    0x17761(%rip),%r12        # 1d740 <fwp_heap>
    5fdf:	55                   	push   %rbp
    5fe0:	53                   	push   %rbx
    5fe1:	48 89 fb             	mov    %rdi,%rbx
    5fe4:	48 83 ec 38          	sub    $0x38,%rsp
    5fe8:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5fed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5ff4:	00 00 
    5ff6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    5ffb:	31 c0                	xor    %eax,%eax
    5ffd:	48 85 f6             	test   %rsi,%rsi
    6000:	0f 84 91 09 00 00    	je     6997 <fwp_hof0.constprop.0+0x9c7>
    6006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    600d:	00 00 00 
    6010:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6017:	00 
    6018:	48 89 d8             	mov    %rbx,%rax
    601b:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6022:	00 
    6023:	48 c1 e2 10          	shl    $0x10,%rdx
    6027:	48 39 d0             	cmp    %rdx,%rax
    602a:	73 62                	jae    608e <fwp_hof0.constprop.0+0xbe>
    602c:	48 89 c2             	mov    %rax,%rdx
    602f:	48 c1 ea 10          	shr    $0x10,%rdx
    6033:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6037:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    603e:	00 
    603f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6043:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    6047:	4d 85 ed             	test   %r13,%r13
    604a:	74 42                	je     608e <fwp_hof0.constprop.0+0xbe>
    604c:	0f b6 0a             	movzbl (%rdx),%ecx
    604f:	80 f9 02             	cmp    $0x2,%cl
    6052:	0f 84 88 0b 00 00    	je     6be0 <fwp_hof0.constprop.0+0xc10>
    6058:	80 f9 01             	cmp    $0x1,%cl
    605b:	75 31                	jne    608e <fwp_hof0.constprop.0+0xbe>
    605d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6060:	0f b7 c0             	movzwl %ax,%eax
    6063:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6066:	48 0f af c1          	imul   %rcx,%rax
    606a:	48 c1 e8 20          	shr    $0x20,%rax
    606e:	48 39 d0             	cmp    %rdx,%rax
    6071:	73 1b                	jae    608e <fwp_hof0.constprop.0+0xbe>
    6073:	49 01 c5             	add    %rax,%r13
    6076:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    607b:	84 c0                	test   %al,%al
    607d:	74 0f                	je     608e <fwp_hof0.constprop.0+0xbe>
    607f:	3c fd                	cmp    $0xfd,%al
    6081:	0f 87 b9 0d 00 00    	ja     6e40 <fwp_hof0.constprop.0+0xe70>
    6087:	83 c0 01             	add    $0x1,%eax
    608a:	41 88 45 00          	mov    %al,0x0(%r13)
    608e:	48 85 db             	test   %rbx,%rbx
    6091:	0f 84 5b 0b 00 00    	je     6bf2 <fwp_hof0.constprop.0+0xc22>
    6097:	48 89 d8             	mov    %rbx,%rax
    609a:	31 ff                	xor    %edi,%edi
    609c:	0f 1f 40 00          	nopl   0x0(%rax)
    60a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    60a4:	48 83 c7 01          	add    $0x1,%rdi
    60a8:	48 85 c0             	test   %rax,%rax
    60ab:	75 f3                	jne    60a0 <fwp_hof0.constprop.0+0xd0>
    60ad:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    60b4:	ff ff 1f 
    60b7:	48 39 f8             	cmp    %rdi,%rax
    60ba:	0f 82 3c 0e 00 00    	jb     6efc <fwp_hof0.constprop.0+0xf2c>
    60c0:	e8 6b e7 ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    60c5:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    60cc:	00 
    60cd:	49 89 c5             	mov    %rax,%r13
    60d0:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    60d7:	00 
    60d8:	48 c1 e2 10          	shl    $0x10,%rdx
    60dc:	48 39 d0             	cmp    %rdx,%rax
    60df:	73 61                	jae    6142 <fwp_hof0.constprop.0+0x172>
    60e1:	48 89 c2             	mov    %rax,%rdx
    60e4:	48 c1 ea 10          	shr    $0x10,%rdx
    60e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    60ec:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    60f3:	00 
    60f4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    60f8:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    60fc:	4d 85 f6             	test   %r14,%r14
    60ff:	74 41                	je     6142 <fwp_hof0.constprop.0+0x172>
    6101:	0f b6 0a             	movzbl (%rdx),%ecx
    6104:	80 f9 02             	cmp    $0x2,%cl
    6107:	0f 84 ab 0a 00 00    	je     6bb8 <fwp_hof0.constprop.0+0xbe8>
    610d:	80 f9 01             	cmp    $0x1,%cl
    6110:	75 27                	jne    6139 <fwp_hof0.constprop.0+0x169>
    6112:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6115:	0f b7 c0             	movzwl %ax,%eax
    6118:	8b 52 1c             	mov    0x1c(%rdx),%edx
    611b:	48 0f af c1          	imul   %rcx,%rax
    611f:	48 c1 e8 20          	shr    $0x20,%rax
    6123:	48 39 d0             	cmp    %rdx,%rax
    6126:	73 11                	jae    6139 <fwp_hof0.constprop.0+0x169>
    6128:	49 01 c6             	add    %rax,%r14
    612b:	41 80 3e ff          	cmpb   $0xff,(%r14)
    612f:	0f 84 96 0a 00 00    	je     6bcb <fwp_hof0.constprop.0+0xbfb>
    6135:	41 c6 06 01          	movb   $0x1,(%r14)
    6139:	48 85 db             	test   %rbx,%rbx
    613c:	0f 84 1e 0a 00 00    	je     6b60 <fwp_hof0.constprop.0+0xb90>
    6142:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    6146:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    614a:	49 89 d9             	mov    %rbx,%r9
    614d:	48 89 da             	mov    %rbx,%rdx
    6150:	49 89 d8             	mov    %rbx,%r8
    6153:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    6159:	49 8b b4 24 d8 13 00 	mov    0x13d8(%r12),%rsi
    6160:	00 
    6161:	48 89 d0             	mov    %rdx,%rax
    6164:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    616b:	00 
    616c:	48 c1 e6 10          	shl    $0x10,%rsi
    6170:	48 39 f0             	cmp    %rsi,%rax
    6173:	73 77                	jae    61ec <fwp_hof0.constprop.0+0x21c>
    6175:	48 89 c6             	mov    %rax,%rsi
    6178:	48 c1 ee 10          	shr    $0x10,%rsi
    617c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    6180:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6187:	00 
    6188:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    618c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    6190:	48 85 ff             	test   %rdi,%rdi
    6193:	74 57                	je     61ec <fwp_hof0.constprop.0+0x21c>
    6195:	44 0f b6 16          	movzbl (%rsi),%r10d
    6199:	41 80 fa 02          	cmp    $0x2,%r10b
    619d:	0f 84 7d 05 00 00    	je     6720 <fwp_hof0.constprop.0+0x750>
    61a3:	41 80 fa 01          	cmp    $0x1,%r10b
    61a7:	75 43                	jne    61ec <fwp_hof0.constprop.0+0x21c>
    61a9:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    61ad:	0f b7 c0             	movzwl %ax,%eax
    61b0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    61b3:	49 0f af c2          	imul   %r10,%rax
    61b7:	48 c1 e8 20          	shr    $0x20,%rax
    61bb:	48 39 f0             	cmp    %rsi,%rax
    61be:	73 2c                	jae    61ec <fwp_hof0.constprop.0+0x21c>
    61c0:	48 01 c7             	add    %rax,%rdi
    61c3:	80 3f 01             	cmpb   $0x1,(%rdi)
    61c6:	75 24                	jne    61ec <fwp_hof0.constprop.0+0x21c>
    61c8:	e9 9b 04 00 00       	jmp    6668 <fwp_hof0.constprop.0+0x698>
    61cd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61d4:	00 
    61d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61dc:	00 00 00 00 
    61e0:	49 8b 4e 08          	mov    0x8(%r14),%rcx
    61e4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    61e8:	49 83 c7 01          	add    $0x1,%r15
    61ec:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    61f1:	0f 88 f9 0c 00 00    	js     6ef0 <fwp_hof0.constprop.0+0xf20>
    61f7:	4b 89 4c fd 00       	mov    %rcx,0x0(%r13,%r15,8)
    61fc:	4d 85 f6             	test   %r14,%r14
    61ff:	75 df                	jne    61e0 <fwp_hof0.constprop.0+0x210>
    6201:	4c 89 c7             	mov    %r8,%rdi
    6204:	41 bf c6 00 00 00    	mov    $0xc6,%r15d
    620a:	e8 f1 ea ff ff       	call   4d00 <fwp_drop0>
    620f:	31 c0                	xor    %eax,%eax
    6211:	48 85 c0             	test   %rax,%rax
    6214:	0f 85 f1 c4 ff ff    	jne    270b <fwp_hof0.constprop.0.cold>
    621a:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    6221:	ff ff 7f 
    6224:	4d 23 75 00          	and    0x0(%r13),%r14
    6228:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    622f:	ff ff 1f 
    6232:	4c 39 f0             	cmp    %r14,%rax
    6235:	0f 82 c1 0c 00 00    	jb     6efc <fwp_hof0.constprop.0+0xf2c>
    623b:	4c 89 f7             	mov    %r14,%rdi
    623e:	e8 ed e5 ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    6243:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    624a:	00 
    624b:	f2 0f 10 25 a5 52 00 	movsd  0x52a5(%rip),%xmm4        # b4f8 <msg.3+0xb8>
    6252:	00 
    6253:	48 89 c5             	mov    %rax,%rbp
    6256:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    625d:	00 
    625e:	48 c1 e2 10          	shl    $0x10,%rdx
    6262:	48 39 d0             	cmp    %rdx,%rax
    6265:	73 58                	jae    62bf <fwp_hof0.constprop.0+0x2ef>
    6267:	48 89 c2             	mov    %rax,%rdx
    626a:	48 c1 ea 10          	shr    $0x10,%rdx
    626e:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6272:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6279:	00 
    627a:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    627e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    6282:	48 85 f6             	test   %rsi,%rsi
    6285:	74 38                	je     62bf <fwp_hof0.constprop.0+0x2ef>
    6287:	0f b6 3a             	movzbl (%rdx),%edi
    628a:	40 80 ff 02          	cmp    $0x2,%dil
    628e:	0f 84 64 08 00 00    	je     6af8 <fwp_hof0.constprop.0+0xb28>
    6294:	40 80 ff 01          	cmp    $0x1,%dil
    6298:	75 25                	jne    62bf <fwp_hof0.constprop.0+0x2ef>
    629a:	8b 7a 18             	mov    0x18(%rdx),%edi
    629d:	0f b7 c0             	movzwl %ax,%eax
    62a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    62a3:	48 0f af c7          	imul   %rdi,%rax
    62a7:	48 c1 e8 20          	shr    $0x20,%rax
    62ab:	48 39 d0             	cmp    %rdx,%rax
    62ae:	73 0f                	jae    62bf <fwp_hof0.constprop.0+0x2ef>
    62b0:	48 01 c6             	add    %rax,%rsi
    62b3:	80 3e ff             	cmpb   $0xff,(%rsi)
    62b6:	0f 84 4e 08 00 00    	je     6b0a <fwp_hof0.constprop.0+0xb3a>
    62bc:	c6 06 01             	movb   $0x1,(%rsi)
    62bf:	ba 08 00 00 00       	mov    $0x8,%edx
    62c4:	be 01 00 00 00       	mov    $0x1,%esi
    62c9:	31 c0                	xor    %eax,%eax
    62cb:	4d 85 f6             	test   %r14,%r14
    62ce:	0f 84 57 01 00 00    	je     642b <fwp_hof0.constprop.0+0x45b>
    62d4:	f2 0f 10 1d 24 52 00 	movsd  0x5224(%rip),%xmm3        # b500 <msg.3+0xc0>
    62db:	00 
    62dc:	f2 0f 10 2d 14 52 00 	movsd  0x5214(%rip),%xmm5        # b4f8 <msg.3+0xb8>
    62e3:	00 
    62e4:	49 8d 7d 08          	lea    0x8(%r13),%rdi
    62e8:	66 0f ef d2          	pxor   %xmm2,%xmm2
    62ec:	0f 1f 40 00          	nopl   0x0(%rax)
    62f0:	49 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r8
    62f7:	ff ff 7f 
    62fa:	4d 8b 55 00          	mov    0x0(%r13),%r10
    62fe:	4d 21 d0             	and    %r10,%r8
    6301:	4c 39 c0             	cmp    %r8,%rax
    6304:	0f 83 86 00 00 00    	jae    6390 <fwp_hof0.constprop.0+0x3c0>
    630a:	49 89 f9             	mov    %rdi,%r9
    630d:	4d 85 d2             	test   %r10,%r10
    6310:	0f 88 fa 03 00 00    	js     6710 <fwp_hof0.constprop.0+0x740>
    6316:	f3 41 0f 7e 34 c1    	movq   (%r9,%rax,8),%xmm6
    631c:	66 0f ef c9          	pxor   %xmm1,%xmm1
    6320:	48 85 c0             	test   %rax,%rax
    6323:	74 5d                	je     6382 <fwp_hof0.constprop.0+0x3b2>
    6325:	f2 41 0f 10 7c 11 f0 	movsd  -0x10(%r9,%rdx,1),%xmm7
    632c:	66 0f 28 c6          	movapd %xmm6,%xmm0
    6330:	66 0f 28 cf          	movapd %xmm7,%xmm1
    6334:	f2 0f 59 cf          	mulsd  %xmm7,%xmm1
    6338:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
    633c:	66 0f 28 cf          	movapd %xmm7,%xmm1
    6340:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
    6344:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6348:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
    634d:	66 0f 28 cc          	movapd %xmm4,%xmm1
    6351:	f2 41 0f 5c c8       	subsd  %xmm8,%xmm1
    6356:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    635a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    635e:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    6362:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6366:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
    636a:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
    636e:	66 0f 28 c4          	movapd %xmm4,%xmm0
    6372:	f2 0f 5c c7          	subsd  %xmm7,%xmm0
    6376:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    637a:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    637e:	f2 0f 58 c8          	addsd  %xmm0,%xmm1
    6382:	49 39 f0             	cmp    %rsi,%r8
    6385:	0f 84 15 02 00 00    	je     65a0 <fwp_hof0.constprop.0+0x5d0>
    638b:	4c 39 c6             	cmp    %r8,%rsi
    638e:	72 10                	jb     63a0 <fwp_hof0.constprop.0+0x3d0>
    6390:	48 8d 3d 91 6c 00 00 	lea    0x6c91(%rip),%rdi        # d028 <s0+0x8>
    6397:	e8 14 cd ff ff       	call   30b0 <fwp_trap>
    639c:	0f 1f 40 00          	nopl   0x0(%rax)
    63a0:	66 0f 28 c6          	movapd %xmm6,%xmm0
    63a4:	66 44 0f 28 ce       	movapd %xmm6,%xmm9
    63a9:	f3 41 0f 7e 3c 11    	movq   (%r9,%rdx,1),%xmm7
    63af:	f2 0f 59 c6          	mulsd  %xmm6,%xmm0
    63b3:	f2 44 0f 58 ce       	addsd  %xmm6,%xmm9
    63b8:	f2 0f 5c f8          	subsd  %xmm0,%xmm7
    63bc:	66 0f 28 c2          	movapd %xmm2,%xmm0
    63c0:	f2 41 0f 5c c1       	subsd  %xmm9,%xmm0
    63c5:	f2 0f 59 c7          	mulsd  %xmm7,%xmm0
    63c9:	f2 0f 59 ff          	mulsd  %xmm7,%xmm7
    63cd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    63d1:	f2 0f 59 fa          	mulsd  %xmm2,%xmm7
    63d5:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    63d9:	f2 0f 58 c7          	addsd  %xmm7,%xmm0
    63dd:	66 0f 28 fd          	movapd %xmm5,%xmm7
    63e1:	f2 0f 5c fe          	subsd  %xmm6,%xmm7
    63e5:	66 0f 57 3d e3 50 00 	xorpd  0x50e3(%rip),%xmm7        # b4d0 <msg.3+0x90>
    63ec:	00 
    63ed:	f2 0f 58 ff          	addsd  %xmm7,%xmm7
    63f1:	f2 0f 58 c7          	addsd  %xmm7,%xmm0
    63f5:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    63fa:	0f 88 f0 0a 00 00    	js     6ef0 <fwp_hof0.constprop.0+0xf20>
    6400:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6404:	f2 0f 59 05 fc 50 00 	mulsd  0x50fc(%rip),%xmm0        # b508 <msg.3+0xc8>
    640b:	00 
    640c:	48 83 c0 01          	add    $0x1,%rax
    6410:	48 83 c6 01          	add    $0x1,%rsi
    6414:	f2 0f 5c f0          	subsd  %xmm0,%xmm6
    6418:	f2 0f 11 74 15 00    	movsd  %xmm6,0x0(%rbp,%rdx,1)
    641e:	48 83 c2 08          	add    $0x8,%rdx
    6422:	49 39 c6             	cmp    %rax,%r14
    6425:	0f 85 c5 fe ff ff    	jne    62f0 <fwp_hof0.constprop.0+0x320>
    642b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6432:	00 
    6433:	4c 89 e8             	mov    %r13,%rax
    6436:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    643d:	00 
    643e:	48 c1 e2 10          	shl    $0x10,%rdx
    6442:	48 39 d0             	cmp    %rdx,%rax
    6445:	73 79                	jae    64c0 <fwp_hof0.constprop.0+0x4f0>
    6447:	48 89 c2             	mov    %rax,%rdx
    644a:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6451:	00 
    6452:	48 c1 ea 10          	shr    $0x10,%rdx
    6456:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    645a:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    645e:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6462:	4d 85 f6             	test   %r14,%r14
    6465:	74 59                	je     64c0 <fwp_hof0.constprop.0+0x4f0>
    6467:	0f b6 3a             	movzbl (%rdx),%edi
    646a:	40 80 ff 02          	cmp    $0x2,%dil
    646e:	0f 84 e4 05 00 00    	je     6a58 <fwp_hof0.constprop.0+0xa88>
    6474:	40 80 ff 01          	cmp    $0x1,%dil
    6478:	75 46                	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    647a:	8b 7a 18             	mov    0x18(%rdx),%edi
    647d:	0f b7 c0             	movzwl %ax,%eax
    6480:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6483:	48 0f af c7          	imul   %rdi,%rax
    6487:	48 c1 e8 20          	shr    $0x20,%rax
    648b:	48 39 d0             	cmp    %rdx,%rax
    648e:	73 30                	jae    64c0 <fwp_hof0.constprop.0+0x4f0>
    6490:	49 01 c6             	add    %rax,%r14
    6493:	41 0f b6 06          	movzbl (%r14),%eax
    6497:	84 c0                	test   %al,%al
    6499:	74 25                	je     64c0 <fwp_hof0.constprop.0+0x4f0>
    649b:	3c 01                	cmp    $0x1,%al
    649d:	0f 84 0d 01 00 00    	je     65b0 <fwp_hof0.constprop.0+0x5e0>
    64a3:	3c ff                	cmp    $0xff,%al
    64a5:	0f 84 11 08 00 00    	je     6cbc <fwp_hof0.constprop.0+0xcec>
    64ab:	83 e8 01             	sub    $0x1,%eax
    64ae:	41 88 06             	mov    %al,(%r14)
    64b1:	0f 1f 40 00          	nopl   0x0(%rax)
    64b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64bc:	00 00 00 00 
    64c0:	4d 85 ff             	test   %r15,%r15
    64c3:	0f 85 87 01 00 00    	jne    6650 <fwp_hof0.constprop.0+0x680>
    64c9:	4c 8d 6c 24 10       	lea    0x10(%rsp),%r13
    64ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64d2:	be 01 00 00 00       	mov    $0x1,%esi
    64d7:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    64de:	00 00 
    64e0:	4c 89 ef             	mov    %r13,%rdi
    64e3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    64e8:	49 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r14
    64ef:	ff ff 7f 
    64f2:	e8 c9 c9 ff ff       	call   2ec0 <buf_grow>
    64f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    64fc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6501:	c6 04 02 5b          	movb   $0x5b,(%rdx,%rax,1)
    6505:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    650a:	48 8d 50 01          	lea    0x1(%rax),%rdx
    650e:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    6513:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6518:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    651d:	48 8d 45 08          	lea    0x8(%rbp),%rax
    6521:	48 89 04 24          	mov    %rax,(%rsp)
    6525:	4c 23 75 00          	and    0x0(%rbp),%r14
    6529:	75 5c                	jne    6587 <fwp_hof0.constprop.0+0x5b7>
    652b:	e9 00 02 00 00       	jmp    6730 <fwp_hof0.constprop.0+0x760>
    6530:	4a 8b 34 fa          	mov    (%rdx,%r15,8),%rsi
    6534:	4c 89 ef             	mov    %r13,%rdi
    6537:	48 8d 15 82 66 00 00 	lea    0x6682(%rip),%rdx        # cbc0 <d0>
    653e:	49 83 c7 01          	add    $0x1,%r15
    6542:	e8 89 ea ff ff       	call   4fd0 <fwp_write.constprop.0>
    6547:	4d 39 fe             	cmp    %r15,%r14
    654a:	0f 84 e0 01 00 00    	je     6730 <fwp_hof0.constprop.0+0x760>
    6550:	be 02 00 00 00       	mov    $0x2,%esi
    6555:	4c 89 ef             	mov    %r13,%rdi
    6558:	e8 63 c9 ff ff       	call   2ec0 <buf_grow>
    655d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6562:	b8 2c 20 00 00       	mov    $0x202c,%eax
    6567:	48 03 54 24 10       	add    0x10(%rsp),%rdx
    656c:	66 89 02             	mov    %ax,(%rdx)
    656f:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6574:	48 8d 72 02          	lea    0x2(%rdx),%rsi
    6578:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    657d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6582:	c6 44 16 02 00       	movb   $0x0,0x2(%rsi,%rdx,1)
    6587:	48 8b 14 24          	mov    (%rsp),%rdx
    658b:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    6590:	79 9e                	jns    6530 <fwp_hof0.constprop.0+0x560>
    6592:	48 8b 55 10          	mov    0x10(%rbp),%rdx
    6596:	eb 98                	jmp    6530 <fwp_hof0.constprop.0+0x560>
    6598:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    659f:	00 
    65a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    65a4:	e9 4c fe ff ff       	jmp    63f5 <fwp_hof0.constprop.0+0x425>
    65a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65b0:	49 8b bc 24 b0 13 00 	mov    0x13b0(%r12),%rdi
    65b7:	00 
    65b8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    65bf:	00 
    65c0:	4c 89 e8             	mov    %r13,%rax
    65c3:	4d 89 e8             	mov    %r13,%r8
    65c6:	48 29 f8             	sub    %rdi,%rax
    65c9:	48 c1 e2 10          	shl    $0x10,%rdx
    65cd:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    65d2:	0f 88 98 04 00 00    	js     6a70 <fwp_hof0.constprop.0+0xaa0>
    65d8:	48 39 d0             	cmp    %rdx,%rax
    65db:	0f 83 df fe ff ff    	jae    64c0 <fwp_hof0.constprop.0+0x4f0>
    65e1:	48 89 c2             	mov    %rax,%rdx
    65e4:	48 c1 ea 10          	shr    $0x10,%rdx
    65e8:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    65ec:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    65f0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    65f4:	48 85 f6             	test   %rsi,%rsi
    65f7:	0f 84 c3 fe ff ff    	je     64c0 <fwp_hof0.constprop.0+0x4f0>
    65fd:	0f b6 3a             	movzbl (%rdx),%edi
    6600:	40 80 ff 02          	cmp    $0x2,%dil
    6604:	0f 84 26 05 00 00    	je     6b30 <fwp_hof0.constprop.0+0xb60>
    660a:	40 80 ff 01          	cmp    $0x1,%dil
    660e:	0f 85 ac fe ff ff    	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    6614:	8b 7a 18             	mov    0x18(%rdx),%edi
    6617:	0f b7 c0             	movzwl %ax,%eax
    661a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    661d:	48 0f af c7          	imul   %rdi,%rax
    6621:	48 c1 e8 20          	shr    $0x20,%rax
    6625:	48 39 d0             	cmp    %rdx,%rax
    6628:	0f 83 92 fe ff ff    	jae    64c0 <fwp_hof0.constprop.0+0x4f0>
    662e:	48 01 c6             	add    %rax,%rsi
    6631:	80 3e 01             	cmpb   $0x1,(%rsi)
    6634:	0f 85 86 fe ff ff    	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    663a:	4c 89 ef             	mov    %r13,%rdi
    663d:	e8 8e d9 ff ff       	call   3fd0 <fwp_mem_free>
    6642:	4d 85 ff             	test   %r15,%r15
    6645:	0f 84 7e fe ff ff    	je     64c9 <fwp_hof0.constprop.0+0x4f9>
    664b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6650:	31 c0                	xor    %eax,%eax
    6652:	49 83 ef 01          	sub    $0x1,%r15
    6656:	49 89 ed             	mov    %rbp,%r13
    6659:	0f 90 c0             	seto   %al
    665c:	e9 b0 fb ff ff       	jmp    6211 <fwp_hof0.constprop.0+0x241>
    6661:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6668:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    666d:	0f 88 7d 08 00 00    	js     6ef0 <fwp_hof0.constprop.0+0xf20>
    6673:	4b 89 4c fd 00       	mov    %rcx,0x0(%r13,%r15,8)
    6678:	49 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%rax
    667f:	00 
    6680:	49 2b 94 24 b0 13 00 	sub    0x13b0(%r12),%rdx
    6687:	00 
    6688:	48 c1 e0 10          	shl    $0x10,%rax
    668c:	48 39 c2             	cmp    %rax,%rdx
    668f:	73 59                	jae    66ea <fwp_hof0.constprop.0+0x71a>
    6691:	48 89 d0             	mov    %rdx,%rax
    6694:	48 c1 e8 10          	shr    $0x10,%rax
    6698:	48 8d 0c 80          	lea    (%rax,%rax,4),%rcx
    669c:	49 8b 84 24 f8 13 00 	mov    0x13f8(%r12),%rax
    66a3:	00 
    66a4:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
    66a8:	48 8b 48 20          	mov    0x20(%rax),%rcx
    66ac:	48 85 c9             	test   %rcx,%rcx
    66af:	74 39                	je     66ea <fwp_hof0.constprop.0+0x71a>
    66b1:	0f b6 30             	movzbl (%rax),%esi
    66b4:	40 80 fe 02          	cmp    $0x2,%sil
    66b8:	0f 84 82 04 00 00    	je     6b40 <fwp_hof0.constprop.0+0xb70>
    66be:	40 80 fe 01          	cmp    $0x1,%sil
    66c2:	75 26                	jne    66ea <fwp_hof0.constprop.0+0x71a>
    66c4:	8b 70 18             	mov    0x18(%rax),%esi
    66c7:	0f b7 d2             	movzwl %dx,%edx
    66ca:	8b 40 1c             	mov    0x1c(%rax),%eax
    66cd:	48 0f af d6          	imul   %rsi,%rdx
    66d1:	48 c1 ea 20          	shr    $0x20,%rdx
    66d5:	48 39 c2             	cmp    %rax,%rdx
    66d8:	73 10                	jae    66ea <fwp_hof0.constprop.0+0x71a>
    66da:	48 01 d1             	add    %rdx,%rcx
    66dd:	80 39 01             	cmpb   $0x1,(%rcx)
    66e0:	75 08                	jne    66ea <fwp_hof0.constprop.0+0x71a>
    66e2:	4c 89 cf             	mov    %r9,%rdi
    66e5:	e8 e6 d8 ff ff       	call   3fd0 <fwp_mem_free>
    66ea:	4d 85 f6             	test   %r14,%r14
    66ed:	0f 84 6d 04 00 00    	je     6b60 <fwp_hof0.constprop.0+0xb90>
    66f3:	49 8b 4e 08          	mov    0x8(%r14),%rcx
    66f7:	4d 89 f1             	mov    %r14,%r9
    66fa:	4c 89 f2             	mov    %r14,%rdx
    66fd:	4d 89 f0             	mov    %r14,%r8
    6700:	49 83 c7 01          	add    $0x1,%r15
    6704:	4d 8b 76 10          	mov    0x10(%r14),%r14
    6708:	e9 4c fa ff ff       	jmp    6159 <fwp_hof0.constprop.0+0x189>
    670d:	0f 1f 00             	nopl   (%rax)
    6710:	4d 8b 4d 10          	mov    0x10(%r13),%r9
    6714:	e9 fd fb ff ff       	jmp    6316 <fwp_hof0.constprop.0+0x346>
    6719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6720:	66 85 c0             	test   %ax,%ax
    6723:	0f 85 c3 fa ff ff    	jne    61ec <fwp_hof0.constprop.0+0x21c>
    6729:	e9 95 fa ff ff       	jmp    61c3 <fwp_hof0.constprop.0+0x1f3>
    672e:	66 90                	xchg   %ax,%ax
    6730:	be 01 00 00 00       	mov    $0x1,%esi
    6735:	4c 89 ef             	mov    %r13,%rdi
    6738:	e8 83 c7 ff ff       	call   2ec0 <buf_grow>
    673d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6742:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6747:	c6 04 02 5d          	movb   $0x5d,(%rdx,%rax,1)
    674b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6750:	48 8d 50 01          	lea    0x1(%rax),%rdx
    6754:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    6759:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    675e:	c6 44 02 01 00       	movb   $0x0,0x1(%rdx,%rax,1)
    6763:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6768:	48 8d 05 bf 48 00 00 	lea    0x48bf(%rip),%rax        # b02e <_IO_stdin_used+0x2e>
    676f:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    6774:	4d 85 c0             	test   %r8,%r8
    6777:	4c 0f 44 c0          	cmove  %rax,%r8
    677b:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    677f:	0f 87 b0 07 00 00    	ja     6f35 <fwp_hof0.constprop.0+0xf65>
    6785:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    6789:	be 01 00 00 00       	mov    $0x1,%esi
    678e:	4c 89 04 24          	mov    %r8,(%rsp)
    6792:	e8 69 de ff ff       	call   4600 <fwp_heap_alloc>
    6797:	48 8b 34 24          	mov    (%rsp),%rsi
    679b:	4c 89 fa             	mov    %r15,%rdx
    679e:	4c 89 38             	mov    %r15,(%rax)
    67a1:	4c 8d 68 08          	lea    0x8(%rax),%r13
    67a5:	49 89 c6             	mov    %rax,%r14
    67a8:	4c 89 ef             	mov    %r13,%rdi
    67ab:	e8 c0 bd ff ff       	call   2570 <memcpy@plt>
    67b0:	43 c6 44 3e 08 00    	movb   $0x0,0x8(%r14,%r15,1)
    67b6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    67bb:	e8 e0 bb ff ff       	call   23a0 <free@plt>
    67c0:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    67c7:	00 
    67c8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    67cf:	00 
    67d0:	4c 89 f0             	mov    %r14,%rax
    67d3:	48 29 f0             	sub    %rsi,%rax
    67d6:	48 c1 e2 10          	shl    $0x10,%rdx
    67da:	48 39 d0             	cmp    %rdx,%rax
    67dd:	73 70                	jae    684f <fwp_hof0.constprop.0+0x87f>
    67df:	48 89 c7             	mov    %rax,%rdi
    67e2:	48 c1 ef 10          	shr    $0x10,%rdi
    67e6:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    67ea:	49 8b bc 24 f8 13 00 	mov    0x13f8(%r12),%rdi
    67f1:	00 
    67f2:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    67f6:	4c 8b 7f 20          	mov    0x20(%rdi),%r15
    67fa:	4d 85 ff             	test   %r15,%r15
    67fd:	74 50                	je     684f <fwp_hof0.constprop.0+0x87f>
    67ff:	44 0f b6 07          	movzbl (%rdi),%r8d
    6803:	41 80 f8 02          	cmp    $0x2,%r8b
    6807:	0f 84 6b 04 00 00    	je     6c78 <fwp_hof0.constprop.0+0xca8>
    680d:	41 80 f8 01          	cmp    $0x1,%r8b
    6811:	75 3c                	jne    684f <fwp_hof0.constprop.0+0x87f>
    6813:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    6817:	0f b7 c0             	movzwl %ax,%eax
    681a:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    681d:	49 0f af c0          	imul   %r8,%rax
    6821:	48 c1 e8 20          	shr    $0x20,%rax
    6825:	48 39 f8             	cmp    %rdi,%rax
    6828:	73 25                	jae    684f <fwp_hof0.constprop.0+0x87f>
    682a:	49 01 c7             	add    %rax,%r15
    682d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6831:	0f 84 54 04 00 00    	je     6c8b <fwp_hof0.constprop.0+0xcbb>
    6837:	41 c6 07 01          	movb   $0x1,(%r15)
    683b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6842:	00 
    6843:	49 8b b4 24 b0 13 00 	mov    0x13b0(%r12),%rsi
    684a:	00 
    684b:	48 c1 e2 10          	shl    $0x10,%rdx
    684f:	48 89 e8             	mov    %rbp,%rax
    6852:	48 29 f0             	sub    %rsi,%rax
    6855:	48 39 d0             	cmp    %rdx,%rax
    6858:	73 76                	jae    68d0 <fwp_hof0.constprop.0+0x900>
    685a:	48 89 c2             	mov    %rax,%rdx
    685d:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    6864:	00 
    6865:	48 c1 ea 10          	shr    $0x10,%rdx
    6869:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    686d:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    6871:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    6875:	4d 85 ff             	test   %r15,%r15
    6878:	74 56                	je     68d0 <fwp_hof0.constprop.0+0x900>
    687a:	0f b6 3a             	movzbl (%rdx),%edi
    687d:	40 80 ff 02          	cmp    $0x2,%dil
    6881:	0f 84 e9 02 00 00    	je     6b70 <fwp_hof0.constprop.0+0xba0>
    6887:	40 80 ff 01          	cmp    $0x1,%dil
    688b:	75 43                	jne    68d0 <fwp_hof0.constprop.0+0x900>
    688d:	8b 7a 18             	mov    0x18(%rdx),%edi
    6890:	0f b7 c0             	movzwl %ax,%eax
    6893:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6896:	48 0f af c7          	imul   %rdi,%rax
    689a:	48 c1 e8 20          	shr    $0x20,%rax
    689e:	48 39 d0             	cmp    %rdx,%rax
    68a1:	73 2d                	jae    68d0 <fwp_hof0.constprop.0+0x900>
    68a3:	49 01 c7             	add    %rax,%r15
    68a6:	41 0f b6 07          	movzbl (%r15),%eax
    68aa:	84 c0                	test   %al,%al
    68ac:	74 22                	je     68d0 <fwp_hof0.constprop.0+0x900>
    68ae:	3c 01                	cmp    $0x1,%al
    68b0:	0f 84 0a 01 00 00    	je     69c0 <fwp_hof0.constprop.0+0x9f0>
    68b6:	3c ff                	cmp    $0xff,%al
    68b8:	0f 84 81 04 00 00    	je     6d3f <fwp_hof0.constprop.0+0xd6f>
    68be:	83 e8 01             	sub    $0x1,%eax
    68c1:	41 88 07             	mov    %al,(%r15)
    68c4:	90                   	nop
    68c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68cc:	00 00 00 00 
    68d0:	49 8b 16             	mov    (%r14),%rdx
    68d3:	48 8b 0d be 8a 01 00 	mov    0x18abe(%rip),%rcx        # 1f398 <fwp_prog_out>
    68da:	be 01 00 00 00       	mov    $0x1,%esi
    68df:	4c 89 ef             	mov    %r13,%rdi
    68e2:	e8 59 bd ff ff       	call   2640 <fwrite@plt>
    68e7:	48 8b 35 aa 8a 01 00 	mov    0x18aaa(%rip),%rsi        # 1f398 <fwp_prog_out>
    68ee:	bf 0a 00 00 00       	mov    $0xa,%edi
    68f3:	e8 c8 bb ff ff       	call   24c0 <fputc@plt>
    68f8:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    68ff:	00 
    6900:	4c 89 f0             	mov    %r14,%rax
    6903:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    690a:	00 
    690b:	48 c1 e2 10          	shl    $0x10,%rdx
    690f:	48 39 d0             	cmp    %rdx,%rax
    6912:	73 6c                	jae    6980 <fwp_hof0.constprop.0+0x9b0>
    6914:	48 89 c2             	mov    %rax,%rdx
    6917:	48 c1 ea 10          	shr    $0x10,%rdx
    691b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    691f:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6926:	00 
    6927:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    692b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    692f:	4d 85 ed             	test   %r13,%r13
    6932:	74 4c                	je     6980 <fwp_hof0.constprop.0+0x9b0>
    6934:	0f b6 0a             	movzbl (%rdx),%ecx
    6937:	80 f9 02             	cmp    $0x2,%cl
    693a:	0f 84 08 03 00 00    	je     6c48 <fwp_hof0.constprop.0+0xc78>
    6940:	80 f9 01             	cmp    $0x1,%cl
    6943:	75 3b                	jne    6980 <fwp_hof0.constprop.0+0x9b0>
    6945:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6948:	0f b7 c0             	movzwl %ax,%eax
    694b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    694e:	48 0f af c1          	imul   %rcx,%rax
    6952:	48 c1 e8 20          	shr    $0x20,%rax
    6956:	48 39 d0             	cmp    %rdx,%rax
    6959:	73 25                	jae    6980 <fwp_hof0.constprop.0+0x9b0>
    695b:	49 01 c5             	add    %rax,%r13
    695e:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    6963:	84 c0                	test   %al,%al
    6965:	74 19                	je     6980 <fwp_hof0.constprop.0+0x9b0>
    6967:	3c 01                	cmp    $0x1,%al
    6969:	0f 84 f7 02 00 00    	je     6c66 <fwp_hof0.constprop.0+0xc96>
    696f:	3c ff                	cmp    $0xff,%al
    6971:	0f 84 48 04 00 00    	je     6dbf <fwp_hof0.constprop.0+0xdef>
    6977:	83 e8 01             	sub    $0x1,%eax
    697a:	41 88 45 00          	mov    %al,0x0(%r13)
    697e:	66 90                	xchg   %ax,%ax
    6980:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6985:	48 8b 40 10          	mov    0x10(%rax),%rax
    6989:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    698e:	48 85 c0             	test   %rax,%rax
    6991:	0f 85 79 f6 ff ff    	jne    6010 <fwp_hof0.constprop.0+0x40>
    6997:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    699c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    69a3:	00 00 
    69a5:	0f 85 a7 05 00 00    	jne    6f52 <fwp_hof0.constprop.0+0xf82>
    69ab:	48 83 c4 38          	add    $0x38,%rsp
    69af:	31 c0                	xor    %eax,%eax
    69b1:	5b                   	pop    %rbx
    69b2:	5d                   	pop    %rbp
    69b3:	41 5c                	pop    %r12
    69b5:	41 5d                	pop    %r13
    69b7:	41 5e                	pop    %r14
    69b9:	41 5f                	pop    %r15
    69bb:	c3                   	ret
    69bc:	0f 1f 40 00          	nopl   0x0(%rax)
    69c0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    69c5:	0f 88 b5 01 00 00    	js     6b80 <fwp_hof0.constprop.0+0xbb0>
    69cb:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    69d2:	00 
    69d3:	48 89 e8             	mov    %rbp,%rax
    69d6:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    69dd:	00 
    69de:	48 c1 e2 10          	shl    $0x10,%rdx
    69e2:	48 39 d0             	cmp    %rdx,%rax
    69e5:	0f 83 e5 fe ff ff    	jae    68d0 <fwp_hof0.constprop.0+0x900>
    69eb:	48 89 c2             	mov    %rax,%rdx
    69ee:	48 c1 ea 10          	shr    $0x10,%rdx
    69f2:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    69f6:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    69fa:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    69fe:	48 85 f6             	test   %rsi,%rsi
    6a01:	0f 84 c9 fe ff ff    	je     68d0 <fwp_hof0.constprop.0+0x900>
    6a07:	0f b6 3a             	movzbl (%rdx),%edi
    6a0a:	40 80 ff 02          	cmp    $0x2,%dil
    6a0e:	0f 84 8c 02 00 00    	je     6ca0 <fwp_hof0.constprop.0+0xcd0>
    6a14:	40 80 ff 01          	cmp    $0x1,%dil
    6a18:	0f 85 b2 fe ff ff    	jne    68d0 <fwp_hof0.constprop.0+0x900>
    6a1e:	8b 7a 18             	mov    0x18(%rdx),%edi
    6a21:	0f b7 c0             	movzwl %ax,%eax
    6a24:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a27:	48 0f af c7          	imul   %rdi,%rax
    6a2b:	48 c1 e8 20          	shr    $0x20,%rax
    6a2f:	48 39 d0             	cmp    %rdx,%rax
    6a32:	0f 83 98 fe ff ff    	jae    68d0 <fwp_hof0.constprop.0+0x900>
    6a38:	48 01 c6             	add    %rax,%rsi
    6a3b:	80 3e 01             	cmpb   $0x1,(%rsi)
    6a3e:	0f 85 8c fe ff ff    	jne    68d0 <fwp_hof0.constprop.0+0x900>
    6a44:	48 89 ef             	mov    %rbp,%rdi
    6a47:	e8 84 d5 ff ff       	call   3fd0 <fwp_mem_free>
    6a4c:	e9 7f fe ff ff       	jmp    68d0 <fwp_hof0.constprop.0+0x900>
    6a51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a58:	66 85 c0             	test   %ax,%ax
    6a5b:	0f 85 5f fa ff ff    	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    6a61:	e9 2d fa ff ff       	jmp    6493 <fwp_hof0.constprop.0+0x4c3>
    6a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a6d:	00 00 00 
    6a70:	4d 8b 6d 08          	mov    0x8(%r13),%r13
    6a74:	48 39 d0             	cmp    %rdx,%rax
    6a77:	73 68                	jae    6ae1 <fwp_hof0.constprop.0+0xb11>
    6a79:	49 89 c1             	mov    %rax,%r9
    6a7c:	49 c1 e9 10          	shr    $0x10,%r9
    6a80:	4f 8d 0c 89          	lea    (%r9,%r9,4),%r9
    6a84:	4a 8d 34 ce          	lea    (%rsi,%r9,8),%rsi
    6a88:	4c 8b 4e 20          	mov    0x20(%rsi),%r9
    6a8c:	4d 85 c9             	test   %r9,%r9
    6a8f:	74 50                	je     6ae1 <fwp_hof0.constprop.0+0xb11>
    6a91:	44 0f b6 16          	movzbl (%rsi),%r10d
    6a95:	41 80 fa 02          	cmp    $0x2,%r10b
    6a99:	0f 84 0f 02 00 00    	je     6cae <fwp_hof0.constprop.0+0xcde>
    6a9f:	41 80 fa 01          	cmp    $0x1,%r10b
    6aa3:	75 3c                	jne    6ae1 <fwp_hof0.constprop.0+0xb11>
    6aa5:	44 8b 56 18          	mov    0x18(%rsi),%r10d
    6aa9:	0f b7 c0             	movzwl %ax,%eax
    6aac:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6aaf:	49 0f af c2          	imul   %r10,%rax
    6ab3:	48 c1 e8 20          	shr    $0x20,%rax
    6ab7:	48 39 f0             	cmp    %rsi,%rax
    6aba:	73 25                	jae    6ae1 <fwp_hof0.constprop.0+0xb11>
    6abc:	49 01 c1             	add    %rax,%r9
    6abf:	41 80 39 01          	cmpb   $0x1,(%r9)
    6ac3:	75 1c                	jne    6ae1 <fwp_hof0.constprop.0+0xb11>
    6ac5:	4c 89 c7             	mov    %r8,%rdi
    6ac8:	e8 03 d5 ff ff       	call   3fd0 <fwp_mem_free>
    6acd:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6ad4:	00 
    6ad5:	49 8b bc 24 b0 13 00 	mov    0x13b0(%r12),%rdi
    6adc:	00 
    6add:	48 c1 e2 10          	shl    $0x10,%rdx
    6ae1:	4c 89 e8             	mov    %r13,%rax
    6ae4:	48 29 f8             	sub    %rdi,%rax
    6ae7:	48 39 d0             	cmp    %rdx,%rax
    6aea:	0f 82 57 f9 ff ff    	jb     6447 <fwp_hof0.constprop.0+0x477>
    6af0:	e9 cb f9 ff ff       	jmp    64c0 <fwp_hof0.constprop.0+0x4f0>
    6af5:	0f 1f 00             	nopl   (%rax)
    6af8:	66 85 c0             	test   %ax,%ax
    6afb:	0f 85 be f7 ff ff    	jne    62bf <fwp_hof0.constprop.0+0x2ef>
    6b01:	80 3e ff             	cmpb   $0xff,(%rsi)
    6b04:	0f 85 b2 f7 ff ff    	jne    62bc <fwp_hof0.constprop.0+0x2ec>
    6b0a:	48 89 f7             	mov    %rsi,%rdi
    6b0d:	48 89 34 24          	mov    %rsi,(%rsp)
    6b11:	e8 7a d2 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6b16:	f2 0f 10 25 da 49 00 	movsd  0x49da(%rip),%xmm4        # b4f8 <msg.3+0xb8>
    6b1d:	00 
    6b1e:	48 8b 34 24          	mov    (%rsp),%rsi
    6b22:	e9 95 f7 ff ff       	jmp    62bc <fwp_hof0.constprop.0+0x2ec>
    6b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b2e:	00 00 
    6b30:	66 85 c0             	test   %ax,%ax
    6b33:	0f 85 87 f9 ff ff    	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    6b39:	e9 f3 fa ff ff       	jmp    6631 <fwp_hof0.constprop.0+0x661>
    6b3e:	66 90                	xchg   %ax,%ax
    6b40:	66 85 d2             	test   %dx,%dx
    6b43:	0f 84 94 fb ff ff    	je     66dd <fwp_hof0.constprop.0+0x70d>
    6b49:	4d 85 f6             	test   %r14,%r14
    6b4c:	0f 85 a1 fb ff ff    	jne    66f3 <fwp_hof0.constprop.0+0x723>
    6b52:	0f 1f 00             	nopl   (%rax)
    6b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b5c:	00 00 00 00 
    6b60:	45 31 c0             	xor    %r8d,%r8d
    6b63:	e9 99 f6 ff ff       	jmp    6201 <fwp_hof0.constprop.0+0x231>
    6b68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b6f:	00 
    6b70:	66 85 c0             	test   %ax,%ax
    6b73:	0f 85 57 fd ff ff    	jne    68d0 <fwp_hof0.constprop.0+0x900>
    6b79:	e9 28 fd ff ff       	jmp    68a6 <fwp_hof0.constprop.0+0x8d6>
    6b7e:	66 90                	xchg   %ax,%ax
    6b80:	48 89 ef             	mov    %rbp,%rdi
    6b83:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6b87:	e8 f4 d9 ff ff       	call   4580 <fwp_rc_free_arr>
    6b8c:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6b93:	00 
    6b94:	4c 89 f8             	mov    %r15,%rax
    6b97:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6b9e:	00 
    6b9f:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba3:	48 39 d0             	cmp    %rdx,%rax
    6ba6:	0f 83 24 fd ff ff    	jae    68d0 <fwp_hof0.constprop.0+0x900>
    6bac:	4c 89 fd             	mov    %r15,%rbp
    6baf:	e9 a6 fc ff ff       	jmp    685a <fwp_hof0.constprop.0+0x88a>
    6bb4:	0f 1f 40 00          	nopl   0x0(%rax)
    6bb8:	66 85 c0             	test   %ax,%ax
    6bbb:	0f 85 78 f5 ff ff    	jne    6139 <fwp_hof0.constprop.0+0x169>
    6bc1:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6bc5:	0f 85 6a f5 ff ff    	jne    6135 <fwp_hof0.constprop.0+0x165>
    6bcb:	4c 89 f7             	mov    %r14,%rdi
    6bce:	e8 bd d1 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6bd3:	e9 5d f5 ff ff       	jmp    6135 <fwp_hof0.constprop.0+0x165>
    6bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bdf:	00 
    6be0:	66 85 c0             	test   %ax,%ax
    6be3:	0f 84 8d f4 ff ff    	je     6076 <fwp_hof0.constprop.0+0xa6>
    6be9:	48 85 db             	test   %rbx,%rbx
    6bec:	0f 85 a5 f4 ff ff    	jne    6097 <fwp_hof0.constprop.0+0xc7>
    6bf2:	31 ff                	xor    %edi,%edi
    6bf4:	e8 37 dc ff ff       	call   4830 <fwp_array_new_packed.constprop.0>
    6bf9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6c00:	00 
    6c01:	49 89 c5             	mov    %rax,%r13
    6c04:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6c0b:	00 
    6c0c:	48 c1 e2 10          	shl    $0x10,%rdx
    6c10:	48 39 d0             	cmp    %rdx,%rax
    6c13:	0f 83 47 ff ff ff    	jae    6b60 <fwp_hof0.constprop.0+0xb90>
    6c19:	48 89 c2             	mov    %rax,%rdx
    6c1c:	48 c1 ea 10          	shr    $0x10,%rdx
    6c20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c24:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6c2b:	00 
    6c2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6c30:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6c34:	4d 85 f6             	test   %r14,%r14
    6c37:	0f 85 c4 f4 ff ff    	jne    6101 <fwp_hof0.constprop.0+0x131>
    6c3d:	e9 1e ff ff ff       	jmp    6b60 <fwp_hof0.constprop.0+0xb90>
    6c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c48:	66 85 c0             	test   %ax,%ax
    6c4b:	0f 85 2f fd ff ff    	jne    6980 <fwp_hof0.constprop.0+0x9b0>
    6c51:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    6c56:	84 c0                	test   %al,%al
    6c58:	0f 84 22 fd ff ff    	je     6980 <fwp_hof0.constprop.0+0x9b0>
    6c5e:	3c 01                	cmp    $0x1,%al
    6c60:	0f 85 09 fd ff ff    	jne    696f <fwp_hof0.constprop.0+0x99f>
    6c66:	4c 89 f7             	mov    %r14,%rdi
    6c69:	e8 62 d3 ff ff       	call   3fd0 <fwp_mem_free>
    6c6e:	e9 0d fd ff ff       	jmp    6980 <fwp_hof0.constprop.0+0x9b0>
    6c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c78:	66 85 c0             	test   %ax,%ax
    6c7b:	0f 85 ce fb ff ff    	jne    684f <fwp_hof0.constprop.0+0x87f>
    6c81:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6c85:	0f 85 ac fb ff ff    	jne    6837 <fwp_hof0.constprop.0+0x867>
    6c8b:	4c 89 ff             	mov    %r15,%rdi
    6c8e:	e8 fd d0 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6c93:	e9 9f fb ff ff       	jmp    6837 <fwp_hof0.constprop.0+0x867>
    6c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c9f:	00 
    6ca0:	66 85 c0             	test   %ax,%ax
    6ca3:	0f 85 27 fc ff ff    	jne    68d0 <fwp_hof0.constprop.0+0x900>
    6ca9:	e9 8d fd ff ff       	jmp    6a3b <fwp_hof0.constprop.0+0xa6b>
    6cae:	66 85 c0             	test   %ax,%ax
    6cb1:	0f 85 2a fe ff ff    	jne    6ae1 <fwp_hof0.constprop.0+0xb11>
    6cb7:	e9 03 fe ff ff       	jmp    6abf <fwp_hof0.constprop.0+0xaef>
    6cbc:	4c 89 f0             	mov    %r14,%rax
    6cbf:	48 c1 e8 11          	shr    $0x11,%rax
    6cc3:	4c 31 f0             	xor    %r14,%rax
    6cc6:	48 89 c2             	mov    %rax,%rdx
    6cc9:	48 c1 ea 09          	shr    $0x9,%rdx
    6ccd:	48 31 d0             	xor    %rdx,%rax
    6cd0:	0f b6 d0             	movzbl %al,%edx
    6cd3:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    6cda:	00 
    6cdb:	48 85 c0             	test   %rax,%rax
    6cde:	75 2d                	jne    6d0d <fwp_hof0.constprop.0+0xd3d>
    6ce0:	e9 44 02 00 00       	jmp    6f29 <fwp_hof0.constprop.0+0xf59>
    6ce5:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6cea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cf1:	00 00 00 00 
    6cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cfc:	00 00 00 00 
    6d00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	0f 84 1c 02 00 00    	je     6f29 <fwp_hof0.constprop.0+0xf59>
    6d0d:	48 89 c2             	mov    %rax,%rdx
    6d10:	4c 3b 30             	cmp    (%rax),%r14
    6d13:	75 eb                	jne    6d00 <fwp_hof0.constprop.0+0xd30>
    6d15:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6d19:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6d1d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d21:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6d28:	0f 85 92 f7 ff ff    	jne    64c0 <fwp_hof0.constprop.0+0x4f0>
    6d2e:	4c 89 f7             	mov    %r14,%rdi
    6d31:	e8 5a d0 ff ff       	call   3d90 <fwp_rc_forget_slot>
    6d36:	41 c6 06 fe          	movb   $0xfe,(%r14)
    6d3a:	e9 81 f7 ff ff       	jmp    64c0 <fwp_hof0.constprop.0+0x4f0>
    6d3f:	4c 89 fa             	mov    %r15,%rdx
    6d42:	48 c1 ea 11          	shr    $0x11,%rdx
    6d46:	4c 31 fa             	xor    %r15,%rdx
    6d49:	48 89 d0             	mov    %rdx,%rax
    6d4c:	48 c1 e8 09          	shr    $0x9,%rax
    6d50:	48 31 c2             	xor    %rax,%rdx
    6d53:	0f b6 d2             	movzbl %dl,%edx
    6d56:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    6d5d:	00 
    6d5e:	48 85 c0             	test   %rax,%rax
    6d61:	75 2a                	jne    6d8d <fwp_hof0.constprop.0+0xdbd>
    6d63:	e9 c1 01 00 00       	jmp    6f29 <fwp_hof0.constprop.0+0xf59>
    6d68:	66 90                	xchg   %ax,%ax
    6d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d71:	00 00 00 00 
    6d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d7c:	00 00 00 00 
    6d80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6d84:	48 85 c0             	test   %rax,%rax
    6d87:	0f 84 9c 01 00 00    	je     6f29 <fwp_hof0.constprop.0+0xf59>
    6d8d:	48 89 c2             	mov    %rax,%rdx
    6d90:	4c 3b 38             	cmp    (%rax),%r15
    6d93:	75 eb                	jne    6d80 <fwp_hof0.constprop.0+0xdb0>
    6d95:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6d99:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6d9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6da1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6da8:	0f 85 22 fb ff ff    	jne    68d0 <fwp_hof0.constprop.0+0x900>
    6dae:	4c 89 ff             	mov    %r15,%rdi
    6db1:	e8 da cf ff ff       	call   3d90 <fwp_rc_forget_slot>
    6db6:	41 c6 07 fe          	movb   $0xfe,(%r15)
    6dba:	e9 11 fb ff ff       	jmp    68d0 <fwp_hof0.constprop.0+0x900>
    6dbf:	4c 89 e8             	mov    %r13,%rax
    6dc2:	48 c1 e8 11          	shr    $0x11,%rax
    6dc6:	4c 31 e8             	xor    %r13,%rax
    6dc9:	48 89 c2             	mov    %rax,%rdx
    6dcc:	48 c1 ea 09          	shr    $0x9,%rdx
    6dd0:	48 31 d0             	xor    %rdx,%rax
    6dd3:	0f b6 d0             	movzbl %al,%edx
    6dd6:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    6ddd:	00 
    6dde:	48 85 c0             	test   %rax,%rax
    6de1:	75 2a                	jne    6e0d <fwp_hof0.constprop.0+0xe3d>
    6de3:	e9 41 01 00 00       	jmp    6f29 <fwp_hof0.constprop.0+0xf59>
    6de8:	66 90                	xchg   %ax,%ax
    6dea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6df1:	00 00 00 00 
    6df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dfc:	00 00 00 00 
    6e00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6e04:	48 85 c0             	test   %rax,%rax
    6e07:	0f 84 1c 01 00 00    	je     6f29 <fwp_hof0.constprop.0+0xf59>
    6e0d:	48 89 c2             	mov    %rax,%rdx
    6e10:	4c 39 28             	cmp    %r13,(%rax)
    6e13:	75 eb                	jne    6e00 <fwp_hof0.constprop.0+0xe30>
    6e15:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6e19:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    6e1d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e21:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6e28:	0f 85 52 fb ff ff    	jne    6980 <fwp_hof0.constprop.0+0x9b0>
    6e2e:	4c 89 ef             	mov    %r13,%rdi
    6e31:	e8 5a cf ff ff       	call   3d90 <fwp_rc_forget_slot>
    6e36:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    6e3b:	e9 40 fb ff ff       	jmp    6980 <fwp_hof0.constprop.0+0x9b0>
    6e40:	4c 89 e9             	mov    %r13,%rcx
    6e43:	48 c1 e9 11          	shr    $0x11,%rcx
    6e47:	4c 31 e9             	xor    %r13,%rcx
    6e4a:	48 89 ca             	mov    %rcx,%rdx
    6e4d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e51:	48 31 d1             	xor    %rdx,%rcx
    6e54:	0f b6 c9             	movzbl %cl,%ecx
    6e57:	4d 8d b4 cc 48 14 00 	lea    0x1448(%r12,%rcx,8),%r14
    6e5e:	00 
    6e5f:	49 8b 16             	mov    (%r14),%rdx
    6e62:	49 83 bc cc 48 14 00 	cmpq   $0x0,0x1448(%r12,%rcx,8)
    6e69:	00 00 
    6e6b:	75 1f                	jne    6e8c <fwp_hof0.constprop.0+0xebc>
    6e6d:	e9 96 00 00 00       	jmp    6f08 <fwp_hof0.constprop.0+0xf38>
    6e72:	0f 1f 00             	nopl   (%rax)
    6e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e7c:	00 00 00 00 
    6e80:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6e84:	48 85 c9             	test   %rcx,%rcx
    6e87:	74 27                	je     6eb0 <fwp_hof0.constprop.0+0xee0>
    6e89:	48 89 ca             	mov    %rcx,%rdx
    6e8c:	4c 39 2a             	cmp    %r13,(%rdx)
    6e8f:	75 ef                	jne    6e80 <fwp_hof0.constprop.0+0xeb0>
    6e91:	3c fe                	cmp    $0xfe,%al
    6e93:	74 7c                	je     6f11 <fwp_hof0.constprop.0+0xf41>
    6e95:	48 8b 42 08          	mov    0x8(%rdx),%rax
    6e99:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    6e9d:	0f 84 a3 00 00 00    	je     6f46 <fwp_hof0.constprop.0+0xf76>
    6ea3:	48 83 c0 01          	add    $0x1,%rax
    6ea7:	48 89 42 08          	mov    %rax,0x8(%rdx)
    6eab:	e9 de f1 ff ff       	jmp    608e <fwp_hof0.constprop.0+0xbe>
    6eb0:	3c fe                	cmp    $0xfe,%al
    6eb2:	75 75                	jne    6f29 <fwp_hof0.constprop.0+0xf59>
    6eb4:	4c 8d 72 10          	lea    0x10(%rdx),%r14
    6eb8:	bf 18 00 00 00       	mov    $0x18,%edi
    6ebd:	e8 be b6 ff ff       	call   2580 <malloc@plt>
    6ec2:	48 85 c0             	test   %rax,%rax
    6ec5:	74 7a                	je     6f41 <fwp_hof0.constprop.0+0xf71>
    6ec7:	4c 89 28             	mov    %r13,(%rax)
    6eca:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    6ed1:	00 
    6ed2:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    6ed9:	00 
    6eda:	49 89 06             	mov    %rax,(%r14)
    6edd:	41 c6 45 00 ff       	movb   $0xff,0x0(%r13)
    6ee2:	49 83 84 24 48 1c 00 	addq   $0x1,0x1c48(%r12)
    6ee9:	00 01 
    6eeb:	e9 9e f1 ff ff       	jmp    608e <fwp_hof0.constprop.0+0xbe>
    6ef0:	48 8d 3d e1 43 00 00 	lea    0x43e1(%rip),%rdi        # b2d8 <_IO_stdin_used+0x2d8>
    6ef7:	e8 b4 c1 ff ff       	call   30b0 <fwp_trap>
    6efc:	48 8d 3d a2 41 00 00 	lea    0x41a2(%rip),%rdi        # b0a5 <_IO_stdin_used+0xa5>
    6f03:	e8 a8 c1 ff ff       	call   30b0 <fwp_trap>
    6f08:	3c fe                	cmp    $0xfe,%al
    6f0a:	75 14                	jne    6f20 <fwp_hof0.constprop.0+0xf50>
    6f0c:	48 85 d2             	test   %rdx,%rdx
    6f0f:	74 a7                	je     6eb8 <fwp_hof0.constprop.0+0xee8>
    6f11:	48 8d 3d 98 43 00 00 	lea    0x4398(%rip),%rdi        # b2b0 <_IO_stdin_used+0x2b0>
    6f18:	e8 93 c1 ff ff       	call   30b0 <fwp_trap>
    6f1d:	0f 1f 00             	nopl   (%rax)
    6f20:	48 85 d2             	test   %rdx,%rdx
    6f23:	0f 85 6c ff ff ff    	jne    6e95 <fwp_hof0.constprop.0+0xec5>
    6f29:	48 8d 3d 58 43 00 00 	lea    0x4358(%rip),%rdi        # b288 <_IO_stdin_used+0x288>
    6f30:	e8 7b c1 ff ff       	call   30b0 <fwp_trap>
    6f35:	48 8d 3d 21 42 00 00 	lea    0x4221(%rip),%rdi        # b15d <_IO_stdin_used+0x15d>
    6f3c:	e8 6f c1 ff ff       	call   30b0 <fwp_trap>
    6f41:	e8 ba bc ff ff       	call   2c00 <fwp_heap_oom>
    6f46:	48 8d 3d f7 41 00 00 	lea    0x41f7(%rip),%rdi        # b144 <_IO_stdin_used+0x144>
    6f4d:	e8 5e c1 ff ff       	call   30b0 <fwp_trap>
    6f52:	e8 e9 b4 ff ff       	call   2440 <__stack_chk_fail@plt>
    6f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f5e:	00 00 

0000000000006f60 <f0>:
    6f60:	41 56                	push   %r14
    6f62:	4c 8d 35 d7 67 01 00 	lea    0x167d7(%rip),%r14        # 1d740 <fwp_heap>
    6f69:	41 55                	push   %r13
    6f6b:	41 54                	push   %r12
    6f6d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    6f73:	55                   	push   %rbp
    6f74:	53                   	push   %rbx
    6f75:	31 db                	xor    %ebx,%ebx
    6f77:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    6f7e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f85:	00 00 
    6f87:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    6f8e:	00 
    6f8f:	31 c0                	xor    %eax,%eax
    6f91:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    6f98:	00 
    6f99:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    6fa0:	00 00 
    6fa2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6fa7:	48 8d 05 c2 de ff ff 	lea    -0x213e(%rip),%rax        # 4e70 <fwp_drop1>
    6fae:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6fb3:	48 8b 05 16 84 01 00 	mov    0x18416(%rip),%rax        # 1f3d0 <fwp_cleanups>
    6fba:	48 89 25 0f 84 01 00 	mov    %rsp,0x1840f(%rip)        # 1f3d0 <fwp_cleanups>
    6fc1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6fc5:	48 89 04 24          	mov    %rax,(%rsp)
    6fc9:	48 8d 05 c0 bb ff ff 	lea    -0x4440(%rip),%rax        # 2b90 <fwp_range_release>
    6fd0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6fd5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    6fda:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6fdf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    6fe4:	eb 43                	jmp    7029 <f0+0xc9>
    6fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fed:	00 00 00 
    6ff0:	80 f9 01             	cmp    $0x1,%cl
    6ff3:	75 29                	jne    701e <f0+0xbe>
    6ff5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6ff8:	0f b7 c0             	movzwl %ax,%eax
    6ffb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ffe:	48 0f af c1          	imul   %rcx,%rax
    7002:	48 c1 e8 20          	shr    $0x20,%rax
    7006:	48 39 d0             	cmp    %rdx,%rax
    7009:	73 13                	jae    701e <f0+0xbe>
    700b:	49 01 c5             	add    %rax,%r13
    700e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    7013:	0f 84 2f 25 00 00    	je     9548 <f0+0x25e8>
    7019:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    701e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7023:	49 83 ec 01          	sub    $0x1,%r12
    7027:	72 77                	jb     70a0 <f0+0x140>
    7029:	48 89 ef             	mov    %rbp,%rdi
    702c:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    7033:	00 
    7034:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7039:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    7040:	00 
    7041:	e8 da d6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7046:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    704d:	48 89 c3             	mov    %rax,%rbx
    7050:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    7057:	48 c1 e2 10          	shl    $0x10,%rdx
    705b:	48 39 d0             	cmp    %rdx,%rax
    705e:	73 be                	jae    701e <f0+0xbe>
    7060:	48 89 c2             	mov    %rax,%rdx
    7063:	48 c1 ea 10          	shr    $0x10,%rdx
    7067:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    706b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    7072:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7076:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    707a:	4d 85 ed             	test   %r13,%r13
    707d:	74 9f                	je     701e <f0+0xbe>
    707f:	0f b6 0a             	movzbl (%rdx),%ecx
    7082:	80 f9 02             	cmp    $0x2,%cl
    7085:	0f 85 65 ff ff ff    	jne    6ff0 <f0+0x90>
    708b:	66 85 c0             	test   %ax,%ax
    708e:	0f 84 7a ff ff ff    	je     700e <f0+0xae>
    7094:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    7099:	49 83 ec 01          	sub    $0x1,%r12
    709d:	73 8a                	jae    7029 <f0+0xc9>
    709f:	90                   	nop
    70a0:	48 8b 04 24          	mov    (%rsp),%rax
    70a4:	66 0f 6f 05 34 44 00 	movdqa 0x4434(%rip),%xmm0        # b4e0 <msg.3+0xa0>
    70ab:	00 
    70ac:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
    70b1:	48 89 05 18 83 01 00 	mov    %rax,0x18318(%rip)        # 1f3d0 <fwp_cleanups>
    70b8:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    70bd:	e8 5e d6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    70c2:	48 8b 15 4f 7a 01 00 	mov    0x17a4f(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    70c9:	49 89 c5             	mov    %rax,%r13
    70cc:	48 2b 05 1d 7a 01 00 	sub    0x17a1d(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    70d3:	48 c1 e2 10          	shl    $0x10,%rdx
    70d7:	48 39 d0             	cmp    %rdx,%rax
    70da:	73 59                	jae    7135 <f0+0x1d5>
    70dc:	48 89 c2             	mov    %rax,%rdx
    70df:	48 c1 ea 10          	shr    $0x10,%rdx
    70e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70e7:	48 8b 15 4a 7a 01 00 	mov    0x17a4a(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    70ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    70f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    70f6:	4d 85 e4             	test   %r12,%r12
    70f9:	74 3a                	je     7135 <f0+0x1d5>
    70fb:	0f b6 0a             	movzbl (%rdx),%ecx
    70fe:	80 f9 02             	cmp    $0x2,%cl
    7101:	0f 84 f9 24 00 00    	je     9600 <f0+0x26a0>
    7107:	80 f9 01             	cmp    $0x1,%cl
    710a:	75 29                	jne    7135 <f0+0x1d5>
    710c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    710f:	0f b7 c0             	movzwl %ax,%eax
    7112:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7115:	48 0f af c1          	imul   %rcx,%rax
    7119:	48 c1 e8 20          	shr    $0x20,%rax
    711d:	48 39 d0             	cmp    %rdx,%rax
    7120:	73 13                	jae    7135 <f0+0x1d5>
    7122:	49 01 c4             	add    %rax,%r12
    7125:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    712a:	0f 84 ab 26 00 00    	je     97db <f0+0x287b>
    7130:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7135:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    713c:	00 f0 3f 
    713f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
    7144:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    7149:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    714e:	e8 cd d5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7153:	48 8b 15 be 79 01 00 	mov    0x179be(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    715a:	49 89 c5             	mov    %rax,%r13
    715d:	48 2b 05 8c 79 01 00 	sub    0x1798c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    7164:	48 c1 e2 10          	shl    $0x10,%rdx
    7168:	48 39 d0             	cmp    %rdx,%rax
    716b:	73 59                	jae    71c6 <f0+0x266>
    716d:	48 89 c2             	mov    %rax,%rdx
    7170:	48 c1 ea 10          	shr    $0x10,%rdx
    7174:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7178:	48 8b 15 b9 79 01 00 	mov    0x179b9(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    717f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7183:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7187:	4d 85 e4             	test   %r12,%r12
    718a:	74 3a                	je     71c6 <f0+0x266>
    718c:	0f b6 0a             	movzbl (%rdx),%ecx
    718f:	80 f9 02             	cmp    $0x2,%cl
    7192:	0f 84 58 24 00 00    	je     95f0 <f0+0x2690>
    7198:	80 f9 01             	cmp    $0x1,%cl
    719b:	75 29                	jne    71c6 <f0+0x266>
    719d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    71a0:	0f b7 c0             	movzwl %ax,%eax
    71a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71a6:	48 0f af c1          	imul   %rcx,%rax
    71aa:	48 c1 e8 20          	shr    $0x20,%rax
    71ae:	48 39 d0             	cmp    %rdx,%rax
    71b1:	73 13                	jae    71c6 <f0+0x266>
    71b3:	49 01 c4             	add    %rax,%r12
    71b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    71bb:	0f 84 27 26 00 00    	je     97e8 <f0+0x2888>
    71c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    71c6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    71cd:	33 f3 bf 
    71d0:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
    71d5:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    71da:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    71df:	e8 3c d5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    71e4:	48 8b 15 2d 79 01 00 	mov    0x1792d(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    71eb:	49 89 c5             	mov    %rax,%r13
    71ee:	48 2b 05 fb 78 01 00 	sub    0x178fb(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    71f5:	48 c1 e2 10          	shl    $0x10,%rdx
    71f9:	48 39 d0             	cmp    %rdx,%rax
    71fc:	73 59                	jae    7257 <f0+0x2f7>
    71fe:	48 89 c2             	mov    %rax,%rdx
    7201:	48 c1 ea 10          	shr    $0x10,%rdx
    7205:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7209:	48 8b 15 28 79 01 00 	mov    0x17928(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    7210:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7214:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    7218:	4d 85 e4             	test   %r12,%r12
    721b:	74 3a                	je     7257 <f0+0x2f7>
    721d:	0f b6 0a             	movzbl (%rdx),%ecx
    7220:	80 f9 02             	cmp    $0x2,%cl
    7223:	0f 84 b7 23 00 00    	je     95e0 <f0+0x2680>
    7229:	80 f9 01             	cmp    $0x1,%cl
    722c:	75 29                	jne    7257 <f0+0x2f7>
    722e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7231:	0f b7 c0             	movzwl %ax,%eax
    7234:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7237:	48 0f af c1          	imul   %rcx,%rax
    723b:	48 c1 e8 20          	shr    $0x20,%rax
    723f:	48 39 d0             	cmp    %rdx,%rax
    7242:	73 13                	jae    7257 <f0+0x2f7>
    7244:	49 01 c4             	add    %rax,%r12
    7247:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    724c:	0f 84 a3 25 00 00    	je     97f5 <f0+0x2895>
    7252:	41 c6 04 24 01       	movb   $0x1,(%r12)
    7257:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    725e:	00 f0 3f 
    7261:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
    7266:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    726b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7270:	e8 ab d4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7275:	48 8b 15 9c 78 01 00 	mov    0x1789c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    727c:	49 89 c5             	mov    %rax,%r13
    727f:	48 2b 05 6a 78 01 00 	sub    0x1786a(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    7286:	48 c1 e2 10          	shl    $0x10,%rdx
    728a:	48 39 d0             	cmp    %rdx,%rax
    728d:	73 59                	jae    72e8 <f0+0x388>
    728f:	48 89 c2             	mov    %rax,%rdx
    7292:	48 c1 ea 10          	shr    $0x10,%rdx
    7296:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    729a:	48 8b 15 97 78 01 00 	mov    0x17897(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    72a1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    72a5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    72a9:	4d 85 e4             	test   %r12,%r12
    72ac:	74 3a                	je     72e8 <f0+0x388>
    72ae:	0f b6 0a             	movzbl (%rdx),%ecx
    72b1:	80 f9 02             	cmp    $0x2,%cl
    72b4:	0f 84 86 23 00 00    	je     9640 <f0+0x26e0>
    72ba:	80 f9 01             	cmp    $0x1,%cl
    72bd:	75 29                	jne    72e8 <f0+0x388>
    72bf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    72c2:	0f b7 c0             	movzwl %ax,%eax
    72c5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72c8:	48 0f af c1          	imul   %rcx,%rax
    72cc:	48 c1 e8 20          	shr    $0x20,%rax
    72d0:	48 39 d0             	cmp    %rdx,%rax
    72d3:	73 13                	jae    72e8 <f0+0x388>
    72d5:	49 01 c4             	add    %rax,%r12
    72d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    72dd:	0f 84 1f 25 00 00    	je     9802 <f0+0x28a2>
    72e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    72e8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    72ef:	00 
    72f0:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    72f7:	00 
    72f8:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    72ff:	33 f3 bf 
    7302:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    7309:	00 f0 3f 
    730c:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    7313:	00 
    7314:	e8 07 d4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7319:	48 89 c7             	mov    %rax,%rdi
    731c:	e8 af d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7321:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
    7328:	00 
    7329:	4c 89 ac 24 90 00 00 	mov    %r13,0x90(%rsp)
    7330:	00 
    7331:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    7338:	00 
    7339:	e8 e2 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    733e:	48 89 c7             	mov    %rax,%rdi
    7341:	e8 8a d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7346:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
    734d:	00 
    734e:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    7355:	00 
    7356:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    735d:	00 
    735e:	e8 bd d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7363:	48 89 c7             	mov    %rax,%rdi
    7366:	e8 65 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    736b:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
    7372:	00 
    7373:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    737a:	00 
    737b:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    7382:	00 
    7383:	e8 98 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7388:	48 89 c7             	mov    %rax,%rdi
    738b:	e8 40 d1 ff ff       	call   44d0 <fwp_rc_fresh>
    7390:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
    7397:	00 
    7398:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    739f:	00 
    73a0:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    73a7:	00 
    73a8:	e8 73 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73ad:	48 89 c7             	mov    %rax,%rdi
    73b0:	e8 1b d1 ff ff       	call   44d0 <fwp_rc_fresh>
    73b5:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
    73bc:	00 
    73bd:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    73c4:	00 
    73c5:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    73cc:	00 
    73cd:	e8 4e d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73d2:	48 89 c7             	mov    %rax,%rdi
    73d5:	e8 f6 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    73da:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
    73e1:	00 
    73e2:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    73e9:	00 
    73ea:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    73f1:	00 
    73f2:	e8 29 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    73f7:	48 89 c7             	mov    %rax,%rdi
    73fa:	e8 d1 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    73ff:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
    7406:	00 
    7407:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    740e:	00 
    740f:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    7416:	00 
    7417:	e8 04 d3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    741c:	48 89 c7             	mov    %rax,%rdi
    741f:	e8 ac d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7424:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
    742b:	00 
    742c:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    7433:	00 
    7434:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    743b:	00 
    743c:	e8 df d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7441:	48 89 c7             	mov    %rax,%rdi
    7444:	e8 87 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7449:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
    7450:	00 
    7451:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    7458:	00 
    7459:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    7460:	00 
    7461:	e8 ba d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7466:	48 89 c7             	mov    %rax,%rdi
    7469:	e8 62 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    746e:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
    7475:	00 
    7476:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    747d:	00 
    747e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    7485:	00 
    7486:	e8 95 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    748b:	48 89 c7             	mov    %rax,%rdi
    748e:	e8 3d d0 ff ff       	call   44d0 <fwp_rc_fresh>
    7493:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
    749a:	00 
    749b:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    74a2:	00 
    74a3:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    74aa:	00 
    74ab:	e8 70 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74b0:	48 89 c7             	mov    %rax,%rdi
    74b3:	e8 18 d0 ff ff       	call   44d0 <fwp_rc_fresh>
    74b8:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
    74bf:	00 
    74c0:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    74c7:	00 
    74c8:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    74cf:	00 
    74d0:	e8 4b d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74d5:	48 89 c7             	mov    %rax,%rdi
    74d8:	e8 f3 cf ff ff       	call   44d0 <fwp_rc_fresh>
    74dd:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
    74e4:	00 
    74e5:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    74ec:	00 
    74ed:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    74f4:	00 
    74f5:	e8 26 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    74fa:	48 89 c7             	mov    %rax,%rdi
    74fd:	e8 ce cf ff ff       	call   44d0 <fwp_rc_fresh>
    7502:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
    7509:	00 
    750a:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    7511:	00 
    7512:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    7519:	00 
    751a:	e8 01 d2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    751f:	48 89 c7             	mov    %rax,%rdi
    7522:	e8 a9 cf ff ff       	call   44d0 <fwp_rc_fresh>
    7527:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
    752e:	00 
    752f:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    7536:	00 
    7537:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    753e:	00 
    753f:	e8 dc d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7544:	48 89 c7             	mov    %rax,%rdi
    7547:	e8 84 cf ff ff       	call   44d0 <fwp_rc_fresh>
    754c:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
    7553:	00 
    7554:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    755b:	00 
    755c:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    7563:	00 
    7564:	e8 b7 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7569:	48 89 c7             	mov    %rax,%rdi
    756c:	e8 5f cf ff ff       	call   44d0 <fwp_rc_fresh>
    7571:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
    7578:	00 
    7579:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    7580:	00 
    7581:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    7588:	00 
    7589:	e8 92 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    758e:	48 89 c7             	mov    %rax,%rdi
    7591:	e8 3a cf ff ff       	call   44d0 <fwp_rc_fresh>
    7596:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
    759d:	00 
    759e:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    75a5:	00 
    75a6:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    75ad:	00 
    75ae:	e8 6d d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75b3:	48 89 c7             	mov    %rax,%rdi
    75b6:	e8 15 cf ff ff       	call   44d0 <fwp_rc_fresh>
    75bb:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
    75c2:	00 
    75c3:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    75ca:	00 
    75cb:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    75d2:	00 
    75d3:	e8 48 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75d8:	48 89 c7             	mov    %rax,%rdi
    75db:	e8 f0 ce ff ff       	call   44d0 <fwp_rc_fresh>
    75e0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
    75e7:	00 
    75e8:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    75ef:	00 
    75f0:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    75f7:	00 
    75f8:	e8 23 d1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    75fd:	48 89 c7             	mov    %rax,%rdi
    7600:	e8 cb ce ff ff       	call   44d0 <fwp_rc_fresh>
    7605:	48 8d bc 24 d0 01 00 	lea    0x1d0(%rsp),%rdi
    760c:	00 
    760d:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    7614:	00 
    7615:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    761c:	00 
    761d:	e8 fe d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7622:	48 89 c7             	mov    %rax,%rdi
    7625:	e8 a6 ce ff ff       	call   44d0 <fwp_rc_fresh>
    762a:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
    7631:	00 
    7632:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    7639:	00 
    763a:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    7641:	00 
    7642:	e8 d9 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7647:	48 89 c7             	mov    %rax,%rdi
    764a:	e8 81 ce ff ff       	call   44d0 <fwp_rc_fresh>
    764f:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
    7656:	00 
    7657:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    765e:	00 
    765f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    7666:	00 
    7667:	e8 b4 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    766c:	48 89 c7             	mov    %rax,%rdi
    766f:	e8 5c ce ff ff       	call   44d0 <fwp_rc_fresh>
    7674:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
    767b:	00 
    767c:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    7683:	00 
    7684:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    768b:	00 
    768c:	e8 8f d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7691:	48 89 c7             	mov    %rax,%rdi
    7694:	e8 37 ce ff ff       	call   44d0 <fwp_rc_fresh>
    7699:	48 8d bc 24 10 02 00 	lea    0x210(%rsp),%rdi
    76a0:	00 
    76a1:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    76a8:	00 
    76a9:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    76b0:	00 
    76b1:	e8 6a d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76b6:	48 89 c7             	mov    %rax,%rdi
    76b9:	e8 12 ce ff ff       	call   44d0 <fwp_rc_fresh>
    76be:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
    76c5:	00 
    76c6:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    76cd:	00 
    76ce:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    76d5:	00 
    76d6:	e8 45 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    76db:	48 89 c7             	mov    %rax,%rdi
    76de:	e8 ed cd ff ff       	call   44d0 <fwp_rc_fresh>
    76e3:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
    76ea:	00 
    76eb:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    76f2:	00 
    76f3:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    76fa:	00 
    76fb:	e8 20 d0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7700:	48 89 c7             	mov    %rax,%rdi
    7703:	e8 c8 cd ff ff       	call   44d0 <fwp_rc_fresh>
    7708:	48 8d bc 24 40 02 00 	lea    0x240(%rsp),%rdi
    770f:	00 
    7710:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    7717:	00 
    7718:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    771f:	00 
    7720:	e8 fb cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7725:	48 89 c7             	mov    %rax,%rdi
    7728:	e8 a3 cd ff ff       	call   44d0 <fwp_rc_fresh>
    772d:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
    7734:	00 
    7735:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    773c:	00 
    773d:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    7744:	00 
    7745:	e8 d6 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    774a:	48 89 c7             	mov    %rax,%rdi
    774d:	e8 7e cd ff ff       	call   44d0 <fwp_rc_fresh>
    7752:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
    7759:	00 
    775a:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    7761:	00 
    7762:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    7769:	00 
    776a:	e8 b1 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    776f:	48 89 c7             	mov    %rax,%rdi
    7772:	e8 59 cd ff ff       	call   44d0 <fwp_rc_fresh>
    7777:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
    777e:	00 
    777f:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    7786:	00 
    7787:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    778e:	00 
    778f:	e8 8c cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7794:	48 89 c7             	mov    %rax,%rdi
    7797:	e8 34 cd ff ff       	call   44d0 <fwp_rc_fresh>
    779c:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
    77a3:	00 
    77a4:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    77ab:	00 
    77ac:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    77b3:	00 
    77b4:	e8 67 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77b9:	48 89 c7             	mov    %rax,%rdi
    77bc:	e8 0f cd ff ff       	call   44d0 <fwp_rc_fresh>
    77c1:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
    77c8:	00 
    77c9:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    77d0:	00 
    77d1:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    77d8:	00 
    77d9:	e8 42 cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    77de:	48 89 c7             	mov    %rax,%rdi
    77e1:	e8 ea cc ff ff       	call   44d0 <fwp_rc_fresh>
    77e6:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
    77ed:	00 
    77ee:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    77f5:	00 
    77f6:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    77fd:	00 
    77fe:	e8 1d cf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7803:	48 89 c7             	mov    %rax,%rdi
    7806:	e8 c5 cc ff ff       	call   44d0 <fwp_rc_fresh>
    780b:	48 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%rdi
    7812:	00 
    7813:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    781a:	00 
    781b:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    7822:	00 
    7823:	e8 f8 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7828:	48 89 c7             	mov    %rax,%rdi
    782b:	e8 a0 cc ff ff       	call   44d0 <fwp_rc_fresh>
    7830:	48 8d bc 24 c0 02 00 	lea    0x2c0(%rsp),%rdi
    7837:	00 
    7838:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    783f:	00 
    7840:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    7847:	00 
    7848:	e8 d3 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    784d:	48 89 c7             	mov    %rax,%rdi
    7850:	e8 7b cc ff ff       	call   44d0 <fwp_rc_fresh>
    7855:	48 8d bc 24 d0 02 00 	lea    0x2d0(%rsp),%rdi
    785c:	00 
    785d:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    7864:	00 
    7865:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    786c:	00 
    786d:	e8 ae ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7872:	48 89 c7             	mov    %rax,%rdi
    7875:	e8 56 cc ff ff       	call   44d0 <fwp_rc_fresh>
    787a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
    7881:	00 
    7882:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    7889:	00 
    788a:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    7891:	00 
    7892:	e8 89 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7897:	48 89 c7             	mov    %rax,%rdi
    789a:	e8 31 cc ff ff       	call   44d0 <fwp_rc_fresh>
    789f:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
    78a6:	00 
    78a7:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    78ae:	00 
    78af:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    78b6:	00 
    78b7:	e8 64 ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    78bc:	48 89 c7             	mov    %rax,%rdi
    78bf:	e8 0c cc ff ff       	call   44d0 <fwp_rc_fresh>
    78c4:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
    78cb:	00 
    78cc:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    78d3:	00 
    78d4:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    78db:	00 
    78dc:	e8 3f ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    78e1:	48 89 c7             	mov    %rax,%rdi
    78e4:	e8 e7 cb ff ff       	call   44d0 <fwp_rc_fresh>
    78e9:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
    78f0:	00 
    78f1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    78f8:	00 
    78f9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    7900:	00 
    7901:	e8 1a ce ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7906:	48 89 c7             	mov    %rax,%rdi
    7909:	e8 c2 cb ff ff       	call   44d0 <fwp_rc_fresh>
    790e:	48 8d bc 24 20 03 00 	lea    0x320(%rsp),%rdi
    7915:	00 
    7916:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    791d:	00 
    791e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    7925:	00 
    7926:	e8 f5 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    792b:	48 89 c7             	mov    %rax,%rdi
    792e:	e8 9d cb ff ff       	call   44d0 <fwp_rc_fresh>
    7933:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
    793a:	00 
    793b:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    7942:	00 
    7943:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    794a:	00 
    794b:	e8 d0 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7950:	48 89 c7             	mov    %rax,%rdi
    7953:	e8 78 cb ff ff       	call   44d0 <fwp_rc_fresh>
    7958:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
    795f:	00 
    7960:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    7967:	00 
    7968:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    796f:	00 
    7970:	e8 ab cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7975:	48 89 c7             	mov    %rax,%rdi
    7978:	e8 53 cb ff ff       	call   44d0 <fwp_rc_fresh>
    797d:	48 8d bc 24 50 03 00 	lea    0x350(%rsp),%rdi
    7984:	00 
    7985:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    798c:	00 
    798d:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    7994:	00 
    7995:	e8 86 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    799a:	48 89 c7             	mov    %rax,%rdi
    799d:	e8 2e cb ff ff       	call   44d0 <fwp_rc_fresh>
    79a2:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
    79a9:	00 
    79aa:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    79b1:	00 
    79b2:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    79b9:	00 
    79ba:	e8 61 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79bf:	48 89 c7             	mov    %rax,%rdi
    79c2:	e8 09 cb ff ff       	call   44d0 <fwp_rc_fresh>
    79c7:	48 8d bc 24 70 03 00 	lea    0x370(%rsp),%rdi
    79ce:	00 
    79cf:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    79d6:	00 
    79d7:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    79de:	00 
    79df:	e8 3c cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    79e4:	48 89 c7             	mov    %rax,%rdi
    79e7:	e8 e4 ca ff ff       	call   44d0 <fwp_rc_fresh>
    79ec:	48 8d bc 24 80 03 00 	lea    0x380(%rsp),%rdi
    79f3:	00 
    79f4:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    79fb:	00 
    79fc:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    7a03:	00 
    7a04:	e8 17 cd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a09:	48 89 c7             	mov    %rax,%rdi
    7a0c:	e8 bf ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a11:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
    7a18:	00 
    7a19:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    7a20:	00 
    7a21:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    7a28:	00 
    7a29:	e8 f2 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a2e:	48 89 c7             	mov    %rax,%rdi
    7a31:	e8 9a ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a36:	48 8d bc 24 a0 03 00 	lea    0x3a0(%rsp),%rdi
    7a3d:	00 
    7a3e:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    7a45:	00 
    7a46:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    7a4d:	00 
    7a4e:	e8 cd cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a53:	48 89 c7             	mov    %rax,%rdi
    7a56:	e8 75 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a5b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
    7a62:	00 
    7a63:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    7a6a:	00 
    7a6b:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    7a72:	00 
    7a73:	e8 a8 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a78:	48 89 c7             	mov    %rax,%rdi
    7a7b:	e8 50 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7a80:	48 8d bc 24 c0 03 00 	lea    0x3c0(%rsp),%rdi
    7a87:	00 
    7a88:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    7a8f:	00 
    7a90:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    7a97:	00 
    7a98:	e8 83 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7a9d:	48 89 c7             	mov    %rax,%rdi
    7aa0:	e8 2b ca ff ff       	call   44d0 <fwp_rc_fresh>
    7aa5:	48 8d bc 24 d0 03 00 	lea    0x3d0(%rsp),%rdi
    7aac:	00 
    7aad:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    7ab4:	00 
    7ab5:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    7abc:	00 
    7abd:	e8 5e cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ac2:	48 89 c7             	mov    %rax,%rdi
    7ac5:	e8 06 ca ff ff       	call   44d0 <fwp_rc_fresh>
    7aca:	48 8d bc 24 e0 03 00 	lea    0x3e0(%rsp),%rdi
    7ad1:	00 
    7ad2:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    7ad9:	00 
    7ada:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    7ae1:	00 
    7ae2:	e8 39 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ae7:	48 89 c7             	mov    %rax,%rdi
    7aea:	e8 e1 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7aef:	48 8d bc 24 f0 03 00 	lea    0x3f0(%rsp),%rdi
    7af6:	00 
    7af7:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    7afe:	00 
    7aff:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    7b06:	00 
    7b07:	e8 14 cc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b0c:	48 89 c7             	mov    %rax,%rdi
    7b0f:	e8 bc c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b14:	48 8d bc 24 00 04 00 	lea    0x400(%rsp),%rdi
    7b1b:	00 
    7b1c:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    7b23:	00 
    7b24:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    7b2b:	00 
    7b2c:	e8 ef cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b31:	48 89 c7             	mov    %rax,%rdi
    7b34:	e8 97 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b39:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
    7b40:	00 
    7b41:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    7b48:	00 
    7b49:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    7b50:	00 
    7b51:	e8 ca cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b56:	48 89 c7             	mov    %rax,%rdi
    7b59:	e8 72 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b5e:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
    7b65:	00 
    7b66:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    7b6d:	00 
    7b6e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    7b75:	00 
    7b76:	e8 a5 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7b7b:	48 89 c7             	mov    %rax,%rdi
    7b7e:	e8 4d c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7b83:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
    7b8a:	00 
    7b8b:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    7b92:	00 
    7b93:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    7b9a:	00 
    7b9b:	e8 80 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ba0:	48 89 c7             	mov    %rax,%rdi
    7ba3:	e8 28 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7ba8:	48 8d bc 24 40 04 00 	lea    0x440(%rsp),%rdi
    7baf:	00 
    7bb0:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    7bb7:	00 
    7bb8:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    7bbf:	00 
    7bc0:	e8 5b cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bc5:	48 89 c7             	mov    %rax,%rdi
    7bc8:	e8 03 c9 ff ff       	call   44d0 <fwp_rc_fresh>
    7bcd:	48 8d bc 24 50 04 00 	lea    0x450(%rsp),%rdi
    7bd4:	00 
    7bd5:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    7bdc:	00 
    7bdd:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    7be4:	00 
    7be5:	e8 36 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7bea:	48 89 c7             	mov    %rax,%rdi
    7bed:	e8 de c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7bf2:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
    7bf9:	00 
    7bfa:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    7c01:	00 
    7c02:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    7c09:	00 
    7c0a:	e8 11 cb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c0f:	48 89 c7             	mov    %rax,%rdi
    7c12:	e8 b9 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c17:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
    7c1e:	00 
    7c1f:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    7c26:	00 
    7c27:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    7c2e:	00 
    7c2f:	e8 ec ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c34:	48 89 c7             	mov    %rax,%rdi
    7c37:	e8 94 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c3c:	48 8d bc 24 80 04 00 	lea    0x480(%rsp),%rdi
    7c43:	00 
    7c44:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    7c4b:	00 
    7c4c:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    7c53:	00 
    7c54:	e8 c7 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c59:	48 89 c7             	mov    %rax,%rdi
    7c5c:	e8 6f c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c61:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
    7c68:	00 
    7c69:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    7c70:	00 
    7c71:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    7c78:	00 
    7c79:	e8 a2 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7c7e:	48 89 c7             	mov    %rax,%rdi
    7c81:	e8 4a c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7c86:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
    7c8d:	00 
    7c8e:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    7c95:	00 
    7c96:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    7c9d:	00 
    7c9e:	e8 7d ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ca3:	48 89 c7             	mov    %rax,%rdi
    7ca6:	e8 25 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7cab:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
    7cb2:	00 
    7cb3:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    7cba:	00 
    7cbb:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    7cc2:	00 
    7cc3:	e8 58 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7cc8:	48 89 c7             	mov    %rax,%rdi
    7ccb:	e8 00 c8 ff ff       	call   44d0 <fwp_rc_fresh>
    7cd0:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
    7cd7:	00 
    7cd8:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    7cdf:	00 
    7ce0:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    7ce7:	00 
    7ce8:	e8 33 ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ced:	48 89 c7             	mov    %rax,%rdi
    7cf0:	e8 db c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7cf5:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
    7cfc:	00 
    7cfd:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    7d04:	00 
    7d05:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    7d0c:	00 
    7d0d:	e8 0e ca ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d12:	48 89 c7             	mov    %rax,%rdi
    7d15:	e8 b6 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d1a:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
    7d21:	00 
    7d22:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    7d29:	00 
    7d2a:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    7d31:	00 
    7d32:	e8 e9 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d37:	48 89 c7             	mov    %rax,%rdi
    7d3a:	e8 91 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d3f:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
    7d46:	00 
    7d47:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    7d4e:	00 
    7d4f:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    7d56:	00 
    7d57:	e8 c4 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d5c:	48 89 c7             	mov    %rax,%rdi
    7d5f:	e8 6c c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d64:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
    7d6b:	00 
    7d6c:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    7d73:	00 
    7d74:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    7d7b:	00 
    7d7c:	e8 9f c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7d81:	48 89 c7             	mov    %rax,%rdi
    7d84:	e8 47 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7d89:	48 8d bc 24 10 05 00 	lea    0x510(%rsp),%rdi
    7d90:	00 
    7d91:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    7d98:	00 
    7d99:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    7da0:	00 
    7da1:	e8 7a c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7da6:	48 89 c7             	mov    %rax,%rdi
    7da9:	e8 22 c7 ff ff       	call   44d0 <fwp_rc_fresh>
    7dae:	48 8d bc 24 20 05 00 	lea    0x520(%rsp),%rdi
    7db5:	00 
    7db6:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    7dbd:	00 
    7dbe:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    7dc5:	00 
    7dc6:	e8 55 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7dcb:	48 89 c7             	mov    %rax,%rdi
    7dce:	e8 fd c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7dd3:	48 8d bc 24 30 05 00 	lea    0x530(%rsp),%rdi
    7dda:	00 
    7ddb:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    7de2:	00 
    7de3:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    7dea:	00 
    7deb:	e8 30 c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7df0:	48 89 c7             	mov    %rax,%rdi
    7df3:	e8 d8 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7df8:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
    7dff:	00 
    7e00:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    7e07:	00 
    7e08:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    7e0f:	00 
    7e10:	e8 0b c9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e15:	48 89 c7             	mov    %rax,%rdi
    7e18:	e8 b3 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e1d:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
    7e24:	00 
    7e25:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    7e2c:	00 
    7e2d:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    7e34:	00 
    7e35:	e8 e6 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e3a:	48 89 c7             	mov    %rax,%rdi
    7e3d:	e8 8e c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e42:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
    7e49:	00 
    7e4a:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    7e51:	00 
    7e52:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    7e59:	00 
    7e5a:	e8 c1 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e5f:	48 89 c7             	mov    %rax,%rdi
    7e62:	e8 69 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e67:	48 8d bc 24 70 05 00 	lea    0x570(%rsp),%rdi
    7e6e:	00 
    7e6f:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    7e76:	00 
    7e77:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    7e7e:	00 
    7e7f:	e8 9c c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7e84:	48 89 c7             	mov    %rax,%rdi
    7e87:	e8 44 c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7e8c:	48 8d bc 24 80 05 00 	lea    0x580(%rsp),%rdi
    7e93:	00 
    7e94:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    7e9b:	00 
    7e9c:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    7ea3:	00 
    7ea4:	e8 77 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ea9:	48 89 c7             	mov    %rax,%rdi
    7eac:	e8 1f c6 ff ff       	call   44d0 <fwp_rc_fresh>
    7eb1:	48 8d bc 24 90 05 00 	lea    0x590(%rsp),%rdi
    7eb8:	00 
    7eb9:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    7ec0:	00 
    7ec1:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    7ec8:	00 
    7ec9:	e8 52 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ece:	48 89 c7             	mov    %rax,%rdi
    7ed1:	e8 fa c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7ed6:	48 8d bc 24 a0 05 00 	lea    0x5a0(%rsp),%rdi
    7edd:	00 
    7ede:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    7ee5:	00 
    7ee6:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    7eed:	00 
    7eee:	e8 2d c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ef3:	48 89 c7             	mov    %rax,%rdi
    7ef6:	e8 d5 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7efb:	48 8d bc 24 b0 05 00 	lea    0x5b0(%rsp),%rdi
    7f02:	00 
    7f03:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    7f0a:	00 
    7f0b:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    7f12:	00 
    7f13:	e8 08 c8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f18:	48 89 c7             	mov    %rax,%rdi
    7f1b:	e8 b0 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f20:	48 8d bc 24 c0 05 00 	lea    0x5c0(%rsp),%rdi
    7f27:	00 
    7f28:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    7f2f:	00 
    7f30:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    7f37:	00 
    7f38:	e8 e3 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f3d:	48 89 c7             	mov    %rax,%rdi
    7f40:	e8 8b c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f45:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
    7f4c:	00 
    7f4d:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    7f54:	00 
    7f55:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    7f5c:	00 
    7f5d:	e8 be c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f62:	48 89 c7             	mov    %rax,%rdi
    7f65:	e8 66 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f6a:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
    7f71:	00 
    7f72:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    7f79:	00 
    7f7a:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    7f81:	00 
    7f82:	e8 99 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7f87:	48 89 c7             	mov    %rax,%rdi
    7f8a:	e8 41 c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7f8f:	48 8d bc 24 f0 05 00 	lea    0x5f0(%rsp),%rdi
    7f96:	00 
    7f97:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    7f9e:	00 
    7f9f:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    7fa6:	00 
    7fa7:	e8 74 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fac:	48 89 c7             	mov    %rax,%rdi
    7faf:	e8 1c c5 ff ff       	call   44d0 <fwp_rc_fresh>
    7fb4:	48 8d bc 24 00 06 00 	lea    0x600(%rsp),%rdi
    7fbb:	00 
    7fbc:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    7fc3:	00 
    7fc4:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    7fcb:	00 
    7fcc:	e8 4f c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7fd1:	48 89 c7             	mov    %rax,%rdi
    7fd4:	e8 f7 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    7fd9:	48 8d bc 24 10 06 00 	lea    0x610(%rsp),%rdi
    7fe0:	00 
    7fe1:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    7fe8:	00 
    7fe9:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    7ff0:	00 
    7ff1:	e8 2a c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    7ff6:	48 89 c7             	mov    %rax,%rdi
    7ff9:	e8 d2 c4 ff ff       	call   44d0 <fwp_rc_fresh>
    7ffe:	48 8d bc 24 20 06 00 	lea    0x620(%rsp),%rdi
    8005:	00 
    8006:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    800d:	00 
    800e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    8015:	00 
    8016:	e8 05 c7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    801b:	48 8b 15 f6 6a 01 00 	mov    0x16af6(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8022:	49 89 c5             	mov    %rax,%r13
    8025:	48 2b 05 c4 6a 01 00 	sub    0x16ac4(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    802c:	48 c1 e2 10          	shl    $0x10,%rdx
    8030:	48 39 d0             	cmp    %rdx,%rax
    8033:	73 59                	jae    808e <f0+0x112e>
    8035:	48 89 c2             	mov    %rax,%rdx
    8038:	48 c1 ea 10          	shr    $0x10,%rdx
    803c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8040:	48 8b 15 f1 6a 01 00 	mov    0x16af1(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8047:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    804b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    804f:	4d 85 e4             	test   %r12,%r12
    8052:	74 3a                	je     808e <f0+0x112e>
    8054:	0f b6 0a             	movzbl (%rdx),%ecx
    8057:	80 f9 02             	cmp    $0x2,%cl
    805a:	0f 84 d0 15 00 00    	je     9630 <f0+0x26d0>
    8060:	80 f9 01             	cmp    $0x1,%cl
    8063:	75 29                	jne    808e <f0+0x112e>
    8065:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8068:	0f b7 c0             	movzwl %ax,%eax
    806b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    806e:	48 0f af c1          	imul   %rcx,%rax
    8072:	48 c1 e8 20          	shr    $0x20,%rax
    8076:	48 39 d0             	cmp    %rdx,%rax
    8079:	73 13                	jae    808e <f0+0x112e>
    807b:	49 01 c4             	add    %rax,%r12
    807e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8083:	0f 84 86 17 00 00    	je     980f <f0+0x28af>
    8089:	41 c6 04 24 01       	movb   $0x1,(%r12)
    808e:	48 8d bc 24 30 06 00 	lea    0x630(%rsp),%rdi
    8095:	00 
    8096:	4c 89 ac 24 38 06 00 	mov    %r13,0x638(%rsp)
    809d:	00 
    809e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    80a5:	00 f0 3f 
    80a8:	48 89 84 24 30 06 00 	mov    %rax,0x630(%rsp)
    80af:	00 
    80b0:	e8 6b c6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    80b5:	48 8b 15 5c 6a 01 00 	mov    0x16a5c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    80bc:	49 89 c5             	mov    %rax,%r13
    80bf:	48 2b 05 2a 6a 01 00 	sub    0x16a2a(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    80c6:	48 c1 e2 10          	shl    $0x10,%rdx
    80ca:	48 39 d0             	cmp    %rdx,%rax
    80cd:	73 59                	jae    8128 <f0+0x11c8>
    80cf:	48 89 c2             	mov    %rax,%rdx
    80d2:	48 c1 ea 10          	shr    $0x10,%rdx
    80d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80da:	48 8b 15 57 6a 01 00 	mov    0x16a57(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    80e1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80e5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    80e9:	4d 85 e4             	test   %r12,%r12
    80ec:	74 3a                	je     8128 <f0+0x11c8>
    80ee:	0f b6 0a             	movzbl (%rdx),%ecx
    80f1:	80 f9 02             	cmp    $0x2,%cl
    80f4:	0f 84 26 15 00 00    	je     9620 <f0+0x26c0>
    80fa:	80 f9 01             	cmp    $0x1,%cl
    80fd:	75 29                	jne    8128 <f0+0x11c8>
    80ff:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8102:	0f b7 c0             	movzwl %ax,%eax
    8105:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8108:	48 0f af c1          	imul   %rcx,%rax
    810c:	48 c1 e8 20          	shr    $0x20,%rax
    8110:	48 39 d0             	cmp    %rdx,%rax
    8113:	73 13                	jae    8128 <f0+0x11c8>
    8115:	49 01 c4             	add    %rax,%r12
    8118:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    811d:	0f 84 f9 16 00 00    	je     981c <f0+0x28bc>
    8123:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8128:	48 8d bc 24 40 06 00 	lea    0x640(%rsp),%rdi
    812f:	00 
    8130:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    8137:	00 
    8138:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    813f:	33 f3 bf 
    8142:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    8149:	00 
    814a:	e8 d1 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    814f:	48 8b 15 c2 69 01 00 	mov    0x169c2(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8156:	49 89 c5             	mov    %rax,%r13
    8159:	48 2b 05 90 69 01 00 	sub    0x16990(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8160:	48 c1 e2 10          	shl    $0x10,%rdx
    8164:	48 39 d0             	cmp    %rdx,%rax
    8167:	73 59                	jae    81c2 <f0+0x1262>
    8169:	48 89 c2             	mov    %rax,%rdx
    816c:	48 c1 ea 10          	shr    $0x10,%rdx
    8170:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8174:	48 8b 15 bd 69 01 00 	mov    0x169bd(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    817b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    817f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8183:	4d 85 e4             	test   %r12,%r12
    8186:	74 3a                	je     81c2 <f0+0x1262>
    8188:	0f b6 0a             	movzbl (%rdx),%ecx
    818b:	80 f9 02             	cmp    $0x2,%cl
    818e:	0f 84 7c 14 00 00    	je     9610 <f0+0x26b0>
    8194:	80 f9 01             	cmp    $0x1,%cl
    8197:	75 29                	jne    81c2 <f0+0x1262>
    8199:	8b 4a 18             	mov    0x18(%rdx),%ecx
    819c:	0f b7 c0             	movzwl %ax,%eax
    819f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81a2:	48 0f af c1          	imul   %rcx,%rax
    81a6:	48 c1 e8 20          	shr    $0x20,%rax
    81aa:	48 39 d0             	cmp    %rdx,%rax
    81ad:	73 13                	jae    81c2 <f0+0x1262>
    81af:	49 01 c4             	add    %rax,%r12
    81b2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    81b7:	0f 84 6c 16 00 00    	je     9829 <f0+0x28c9>
    81bd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    81c2:	48 8d bc 24 50 06 00 	lea    0x650(%rsp),%rdi
    81c9:	00 
    81ca:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    81d1:	00 
    81d2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    81d9:	00 f0 3f 
    81dc:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    81e3:	00 
    81e4:	e8 37 c5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    81e9:	48 8b 15 28 69 01 00 	mov    0x16928(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    81f0:	49 89 c5             	mov    %rax,%r13
    81f3:	48 2b 05 f6 68 01 00 	sub    0x168f6(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    81fa:	48 c1 e2 10          	shl    $0x10,%rdx
    81fe:	48 39 d0             	cmp    %rdx,%rax
    8201:	73 59                	jae    825c <f0+0x12fc>
    8203:	48 89 c2             	mov    %rax,%rdx
    8206:	48 c1 ea 10          	shr    $0x10,%rdx
    820a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    820e:	48 8b 15 23 69 01 00 	mov    0x16923(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8215:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8219:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    821d:	4d 85 e4             	test   %r12,%r12
    8220:	74 3a                	je     825c <f0+0x12fc>
    8222:	0f b6 0a             	movzbl (%rdx),%ecx
    8225:	80 f9 02             	cmp    $0x2,%cl
    8228:	0f 84 92 14 00 00    	je     96c0 <f0+0x2760>
    822e:	80 f9 01             	cmp    $0x1,%cl
    8231:	75 29                	jne    825c <f0+0x12fc>
    8233:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8236:	0f b7 c0             	movzwl %ax,%eax
    8239:	8b 52 1c             	mov    0x1c(%rdx),%edx
    823c:	48 0f af c1          	imul   %rcx,%rax
    8240:	48 c1 e8 20          	shr    $0x20,%rax
    8244:	48 39 d0             	cmp    %rdx,%rax
    8247:	73 13                	jae    825c <f0+0x12fc>
    8249:	49 01 c4             	add    %rax,%r12
    824c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8251:	0f 84 df 15 00 00    	je     9836 <f0+0x28d6>
    8257:	41 c6 04 24 01       	movb   $0x1,(%r12)
    825c:	48 8d bc 24 60 06 00 	lea    0x660(%rsp),%rdi
    8263:	00 
    8264:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    826b:	00 
    826c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8273:	33 f3 bf 
    8276:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    827d:	00 
    827e:	e8 9d c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8283:	48 8b 15 8e 68 01 00 	mov    0x1688e(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    828a:	49 89 c5             	mov    %rax,%r13
    828d:	48 2b 05 5c 68 01 00 	sub    0x1685c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8294:	48 c1 e2 10          	shl    $0x10,%rdx
    8298:	48 39 d0             	cmp    %rdx,%rax
    829b:	73 59                	jae    82f6 <f0+0x1396>
    829d:	48 89 c2             	mov    %rax,%rdx
    82a0:	48 c1 ea 10          	shr    $0x10,%rdx
    82a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82a8:	48 8b 15 89 68 01 00 	mov    0x16889(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    82af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    82b7:	4d 85 e4             	test   %r12,%r12
    82ba:	74 3a                	je     82f6 <f0+0x1396>
    82bc:	0f b6 0a             	movzbl (%rdx),%ecx
    82bf:	80 f9 02             	cmp    $0x2,%cl
    82c2:	0f 84 e8 13 00 00    	je     96b0 <f0+0x2750>
    82c8:	80 f9 01             	cmp    $0x1,%cl
    82cb:	75 29                	jne    82f6 <f0+0x1396>
    82cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82d0:	0f b7 c0             	movzwl %ax,%eax
    82d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82d6:	48 0f af c1          	imul   %rcx,%rax
    82da:	48 c1 e8 20          	shr    $0x20,%rax
    82de:	48 39 d0             	cmp    %rdx,%rax
    82e1:	73 13                	jae    82f6 <f0+0x1396>
    82e3:	49 01 c4             	add    %rax,%r12
    82e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    82eb:	0f 84 52 15 00 00    	je     9843 <f0+0x28e3>
    82f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    82f6:	48 8d bc 24 70 06 00 	lea    0x670(%rsp),%rdi
    82fd:	00 
    82fe:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    8305:	00 
    8306:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    830d:	00 f0 3f 
    8310:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    8317:	00 
    8318:	e8 03 c4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    831d:	48 8b 15 f4 67 01 00 	mov    0x167f4(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8324:	49 89 c5             	mov    %rax,%r13
    8327:	48 2b 05 c2 67 01 00 	sub    0x167c2(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    832e:	48 c1 e2 10          	shl    $0x10,%rdx
    8332:	48 39 d0             	cmp    %rdx,%rax
    8335:	73 59                	jae    8390 <f0+0x1430>
    8337:	48 89 c2             	mov    %rax,%rdx
    833a:	48 c1 ea 10          	shr    $0x10,%rdx
    833e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8342:	48 8b 15 ef 67 01 00 	mov    0x167ef(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8349:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    834d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8351:	4d 85 e4             	test   %r12,%r12
    8354:	74 3a                	je     8390 <f0+0x1430>
    8356:	0f b6 0a             	movzbl (%rdx),%ecx
    8359:	80 f9 02             	cmp    $0x2,%cl
    835c:	0f 84 3e 13 00 00    	je     96a0 <f0+0x2740>
    8362:	80 f9 01             	cmp    $0x1,%cl
    8365:	75 29                	jne    8390 <f0+0x1430>
    8367:	8b 4a 18             	mov    0x18(%rdx),%ecx
    836a:	0f b7 c0             	movzwl %ax,%eax
    836d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8370:	48 0f af c1          	imul   %rcx,%rax
    8374:	48 c1 e8 20          	shr    $0x20,%rax
    8378:	48 39 d0             	cmp    %rdx,%rax
    837b:	73 13                	jae    8390 <f0+0x1430>
    837d:	49 01 c4             	add    %rax,%r12
    8380:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8385:	0f 84 c5 14 00 00    	je     9850 <f0+0x28f0>
    838b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8390:	48 8d bc 24 80 06 00 	lea    0x680(%rsp),%rdi
    8397:	00 
    8398:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    839f:	00 
    83a0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    83a7:	33 f3 bf 
    83aa:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    83b1:	00 
    83b2:	e8 69 c3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    83b7:	48 8b 15 5a 67 01 00 	mov    0x1675a(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    83be:	49 89 c5             	mov    %rax,%r13
    83c1:	48 2b 05 28 67 01 00 	sub    0x16728(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    83c8:	48 c1 e2 10          	shl    $0x10,%rdx
    83cc:	48 39 d0             	cmp    %rdx,%rax
    83cf:	73 59                	jae    842a <f0+0x14ca>
    83d1:	48 89 c2             	mov    %rax,%rdx
    83d4:	48 c1 ea 10          	shr    $0x10,%rdx
    83d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83dc:	48 8b 15 55 67 01 00 	mov    0x16755(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    83e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    83eb:	4d 85 e4             	test   %r12,%r12
    83ee:	74 3a                	je     842a <f0+0x14ca>
    83f0:	0f b6 0a             	movzbl (%rdx),%ecx
    83f3:	80 f9 02             	cmp    $0x2,%cl
    83f6:	0f 84 94 12 00 00    	je     9690 <f0+0x2730>
    83fc:	80 f9 01             	cmp    $0x1,%cl
    83ff:	75 29                	jne    842a <f0+0x14ca>
    8401:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8404:	0f b7 c0             	movzwl %ax,%eax
    8407:	8b 52 1c             	mov    0x1c(%rdx),%edx
    840a:	48 0f af c1          	imul   %rcx,%rax
    840e:	48 c1 e8 20          	shr    $0x20,%rax
    8412:	48 39 d0             	cmp    %rdx,%rax
    8415:	73 13                	jae    842a <f0+0x14ca>
    8417:	49 01 c4             	add    %rax,%r12
    841a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    841f:	0f 84 38 14 00 00    	je     985d <f0+0x28fd>
    8425:	41 c6 04 24 01       	movb   $0x1,(%r12)
    842a:	48 8d bc 24 90 06 00 	lea    0x690(%rsp),%rdi
    8431:	00 
    8432:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    8439:	00 
    843a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8441:	00 f0 3f 
    8444:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    844b:	00 
    844c:	e8 cf c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8451:	48 8b 15 c0 66 01 00 	mov    0x166c0(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8458:	49 89 c5             	mov    %rax,%r13
    845b:	48 2b 05 8e 66 01 00 	sub    0x1668e(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8462:	48 c1 e2 10          	shl    $0x10,%rdx
    8466:	48 39 d0             	cmp    %rdx,%rax
    8469:	73 59                	jae    84c4 <f0+0x1564>
    846b:	48 89 c2             	mov    %rax,%rdx
    846e:	48 c1 ea 10          	shr    $0x10,%rdx
    8472:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8476:	48 8b 15 bb 66 01 00 	mov    0x166bb(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    847d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8481:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8485:	4d 85 e4             	test   %r12,%r12
    8488:	74 3a                	je     84c4 <f0+0x1564>
    848a:	0f b6 0a             	movzbl (%rdx),%ecx
    848d:	80 f9 02             	cmp    $0x2,%cl
    8490:	0f 84 ea 11 00 00    	je     9680 <f0+0x2720>
    8496:	80 f9 01             	cmp    $0x1,%cl
    8499:	75 29                	jne    84c4 <f0+0x1564>
    849b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    849e:	0f b7 c0             	movzwl %ax,%eax
    84a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84a4:	48 0f af c1          	imul   %rcx,%rax
    84a8:	48 c1 e8 20          	shr    $0x20,%rax
    84ac:	48 39 d0             	cmp    %rdx,%rax
    84af:	73 13                	jae    84c4 <f0+0x1564>
    84b1:	49 01 c4             	add    %rax,%r12
    84b4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    84b9:	0f 84 ab 13 00 00    	je     986a <f0+0x290a>
    84bf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    84c4:	48 8d bc 24 a0 06 00 	lea    0x6a0(%rsp),%rdi
    84cb:	00 
    84cc:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    84d3:	00 
    84d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    84db:	33 f3 bf 
    84de:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    84e5:	00 
    84e6:	e8 35 c2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    84eb:	48 8b 15 26 66 01 00 	mov    0x16626(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    84f2:	49 89 c5             	mov    %rax,%r13
    84f5:	48 2b 05 f4 65 01 00 	sub    0x165f4(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    84fc:	48 c1 e2 10          	shl    $0x10,%rdx
    8500:	48 39 d0             	cmp    %rdx,%rax
    8503:	73 59                	jae    855e <f0+0x15fe>
    8505:	48 89 c2             	mov    %rax,%rdx
    8508:	48 c1 ea 10          	shr    $0x10,%rdx
    850c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8510:	48 8b 15 21 66 01 00 	mov    0x16621(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8517:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    851b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    851f:	4d 85 e4             	test   %r12,%r12
    8522:	74 3a                	je     855e <f0+0x15fe>
    8524:	0f b6 0a             	movzbl (%rdx),%ecx
    8527:	80 f9 02             	cmp    $0x2,%cl
    852a:	0f 84 40 11 00 00    	je     9670 <f0+0x2710>
    8530:	80 f9 01             	cmp    $0x1,%cl
    8533:	75 29                	jne    855e <f0+0x15fe>
    8535:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8538:	0f b7 c0             	movzwl %ax,%eax
    853b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    853e:	48 0f af c1          	imul   %rcx,%rax
    8542:	48 c1 e8 20          	shr    $0x20,%rax
    8546:	48 39 d0             	cmp    %rdx,%rax
    8549:	73 13                	jae    855e <f0+0x15fe>
    854b:	49 01 c4             	add    %rax,%r12
    854e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8553:	0f 84 1e 13 00 00    	je     9877 <f0+0x2917>
    8559:	41 c6 04 24 01       	movb   $0x1,(%r12)
    855e:	48 8d bc 24 b0 06 00 	lea    0x6b0(%rsp),%rdi
    8565:	00 
    8566:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    856d:	00 
    856e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8575:	00 f0 3f 
    8578:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    857f:	00 
    8580:	e8 9b c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8585:	48 8b 15 8c 65 01 00 	mov    0x1658c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    858c:	49 89 c5             	mov    %rax,%r13
    858f:	48 2b 05 5a 65 01 00 	sub    0x1655a(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8596:	48 c1 e2 10          	shl    $0x10,%rdx
    859a:	48 39 d0             	cmp    %rdx,%rax
    859d:	73 59                	jae    85f8 <f0+0x1698>
    859f:	48 89 c2             	mov    %rax,%rdx
    85a2:	48 c1 ea 10          	shr    $0x10,%rdx
    85a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85aa:	48 8b 15 87 65 01 00 	mov    0x16587(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    85b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    85b9:	4d 85 e4             	test   %r12,%r12
    85bc:	74 3a                	je     85f8 <f0+0x1698>
    85be:	0f b6 0a             	movzbl (%rdx),%ecx
    85c1:	80 f9 02             	cmp    $0x2,%cl
    85c4:	0f 84 96 10 00 00    	je     9660 <f0+0x2700>
    85ca:	80 f9 01             	cmp    $0x1,%cl
    85cd:	75 29                	jne    85f8 <f0+0x1698>
    85cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85d2:	0f b7 c0             	movzwl %ax,%eax
    85d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85d8:	48 0f af c1          	imul   %rcx,%rax
    85dc:	48 c1 e8 20          	shr    $0x20,%rax
    85e0:	48 39 d0             	cmp    %rdx,%rax
    85e3:	73 13                	jae    85f8 <f0+0x1698>
    85e5:	49 01 c4             	add    %rax,%r12
    85e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    85ed:	0f 84 91 12 00 00    	je     9884 <f0+0x2924>
    85f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    85f8:	48 8d bc 24 c0 06 00 	lea    0x6c0(%rsp),%rdi
    85ff:	00 
    8600:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    8607:	00 
    8608:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    860f:	33 f3 bf 
    8612:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    8619:	00 
    861a:	e8 01 c1 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    861f:	48 8b 15 f2 64 01 00 	mov    0x164f2(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8626:	49 89 c5             	mov    %rax,%r13
    8629:	48 2b 05 c0 64 01 00 	sub    0x164c0(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8630:	48 c1 e2 10          	shl    $0x10,%rdx
    8634:	48 39 d0             	cmp    %rdx,%rax
    8637:	73 59                	jae    8692 <f0+0x1732>
    8639:	48 89 c2             	mov    %rax,%rdx
    863c:	48 c1 ea 10          	shr    $0x10,%rdx
    8640:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8644:	48 8b 15 ed 64 01 00 	mov    0x164ed(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    864b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    864f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8653:	4d 85 e4             	test   %r12,%r12
    8656:	74 3a                	je     8692 <f0+0x1732>
    8658:	0f b6 0a             	movzbl (%rdx),%ecx
    865b:	80 f9 02             	cmp    $0x2,%cl
    865e:	0f 84 ec 0f 00 00    	je     9650 <f0+0x26f0>
    8664:	80 f9 01             	cmp    $0x1,%cl
    8667:	75 29                	jne    8692 <f0+0x1732>
    8669:	8b 4a 18             	mov    0x18(%rdx),%ecx
    866c:	0f b7 c0             	movzwl %ax,%eax
    866f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8672:	48 0f af c1          	imul   %rcx,%rax
    8676:	48 c1 e8 20          	shr    $0x20,%rax
    867a:	48 39 d0             	cmp    %rdx,%rax
    867d:	73 13                	jae    8692 <f0+0x1732>
    867f:	49 01 c4             	add    %rax,%r12
    8682:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8687:	0f 84 04 12 00 00    	je     9891 <f0+0x2931>
    868d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8692:	48 8d bc 24 d0 06 00 	lea    0x6d0(%rsp),%rdi
    8699:	00 
    869a:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    86a1:	00 
    86a2:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    86a9:	00 f0 3f 
    86ac:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    86b3:	00 
    86b4:	e8 67 c0 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    86b9:	48 8b 15 58 64 01 00 	mov    0x16458(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    86c0:	49 89 c5             	mov    %rax,%r13
    86c3:	48 2b 05 26 64 01 00 	sub    0x16426(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    86ca:	48 c1 e2 10          	shl    $0x10,%rdx
    86ce:	48 39 d0             	cmp    %rdx,%rax
    86d1:	73 59                	jae    872c <f0+0x17cc>
    86d3:	48 89 c2             	mov    %rax,%rdx
    86d6:	48 c1 ea 10          	shr    $0x10,%rdx
    86da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86de:	48 8b 15 53 64 01 00 	mov    0x16453(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    86e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86e9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    86ed:	4d 85 e4             	test   %r12,%r12
    86f0:	74 3a                	je     872c <f0+0x17cc>
    86f2:	0f b6 0a             	movzbl (%rdx),%ecx
    86f5:	80 f9 02             	cmp    $0x2,%cl
    86f8:	0f 84 d2 0e 00 00    	je     95d0 <f0+0x2670>
    86fe:	80 f9 01             	cmp    $0x1,%cl
    8701:	75 29                	jne    872c <f0+0x17cc>
    8703:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8706:	0f b7 c0             	movzwl %ax,%eax
    8709:	8b 52 1c             	mov    0x1c(%rdx),%edx
    870c:	48 0f af c1          	imul   %rcx,%rax
    8710:	48 c1 e8 20          	shr    $0x20,%rax
    8714:	48 39 d0             	cmp    %rdx,%rax
    8717:	73 13                	jae    872c <f0+0x17cc>
    8719:	49 01 c4             	add    %rax,%r12
    871c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8721:	0f 84 77 11 00 00    	je     989e <f0+0x293e>
    8727:	41 c6 04 24 01       	movb   $0x1,(%r12)
    872c:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
    8733:	00 
    8734:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    873b:	00 
    873c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8743:	33 f3 bf 
    8746:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    874d:	00 
    874e:	e8 cd bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8753:	48 8b 15 be 63 01 00 	mov    0x163be(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    875a:	49 89 c5             	mov    %rax,%r13
    875d:	48 2b 05 8c 63 01 00 	sub    0x1638c(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8764:	48 c1 e2 10          	shl    $0x10,%rdx
    8768:	48 39 d0             	cmp    %rdx,%rax
    876b:	73 59                	jae    87c6 <f0+0x1866>
    876d:	48 89 c2             	mov    %rax,%rdx
    8770:	48 c1 ea 10          	shr    $0x10,%rdx
    8774:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8778:	48 8b 15 b9 63 01 00 	mov    0x163b9(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    877f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8783:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8787:	4d 85 e4             	test   %r12,%r12
    878a:	74 3a                	je     87c6 <f0+0x1866>
    878c:	0f b6 0a             	movzbl (%rdx),%ecx
    878f:	80 f9 02             	cmp    $0x2,%cl
    8792:	0f 84 28 0e 00 00    	je     95c0 <f0+0x2660>
    8798:	80 f9 01             	cmp    $0x1,%cl
    879b:	75 29                	jne    87c6 <f0+0x1866>
    879d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87a0:	0f b7 c0             	movzwl %ax,%eax
    87a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87a6:	48 0f af c1          	imul   %rcx,%rax
    87aa:	48 c1 e8 20          	shr    $0x20,%rax
    87ae:	48 39 d0             	cmp    %rdx,%rax
    87b1:	73 13                	jae    87c6 <f0+0x1866>
    87b3:	49 01 c4             	add    %rax,%r12
    87b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    87bb:	0f 84 ea 10 00 00    	je     98ab <f0+0x294b>
    87c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    87c6:	48 8d bc 24 f0 06 00 	lea    0x6f0(%rsp),%rdi
    87cd:	00 
    87ce:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    87d5:	00 
    87d6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    87dd:	00 f0 3f 
    87e0:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    87e7:	00 
    87e8:	e8 33 bf ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    87ed:	48 8b 15 24 63 01 00 	mov    0x16324(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    87f4:	49 89 c5             	mov    %rax,%r13
    87f7:	48 2b 05 f2 62 01 00 	sub    0x162f2(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    87fe:	48 c1 e2 10          	shl    $0x10,%rdx
    8802:	48 39 d0             	cmp    %rdx,%rax
    8805:	73 59                	jae    8860 <f0+0x1900>
    8807:	48 89 c2             	mov    %rax,%rdx
    880a:	48 c1 ea 10          	shr    $0x10,%rdx
    880e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8812:	48 8b 15 1f 63 01 00 	mov    0x1631f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8819:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    881d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8821:	4d 85 e4             	test   %r12,%r12
    8824:	74 3a                	je     8860 <f0+0x1900>
    8826:	0f b6 0a             	movzbl (%rdx),%ecx
    8829:	80 f9 02             	cmp    $0x2,%cl
    882c:	0f 84 7e 0d 00 00    	je     95b0 <f0+0x2650>
    8832:	80 f9 01             	cmp    $0x1,%cl
    8835:	75 29                	jne    8860 <f0+0x1900>
    8837:	8b 4a 18             	mov    0x18(%rdx),%ecx
    883a:	0f b7 c0             	movzwl %ax,%eax
    883d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8840:	48 0f af c1          	imul   %rcx,%rax
    8844:	48 c1 e8 20          	shr    $0x20,%rax
    8848:	48 39 d0             	cmp    %rdx,%rax
    884b:	73 13                	jae    8860 <f0+0x1900>
    884d:	49 01 c4             	add    %rax,%r12
    8850:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8855:	0f 84 5d 10 00 00    	je     98b8 <f0+0x2958>
    885b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8860:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
    8867:	00 
    8868:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    886f:	00 
    8870:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8877:	33 f3 bf 
    887a:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    8881:	00 
    8882:	e8 99 be ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8887:	48 8b 15 8a 62 01 00 	mov    0x1628a(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    888e:	49 89 c5             	mov    %rax,%r13
    8891:	48 2b 05 58 62 01 00 	sub    0x16258(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8898:	48 c1 e2 10          	shl    $0x10,%rdx
    889c:	48 39 d0             	cmp    %rdx,%rax
    889f:	73 59                	jae    88fa <f0+0x199a>
    88a1:	48 89 c2             	mov    %rax,%rdx
    88a4:	48 c1 ea 10          	shr    $0x10,%rdx
    88a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88ac:	48 8b 15 85 62 01 00 	mov    0x16285(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    88b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    88bb:	4d 85 e4             	test   %r12,%r12
    88be:	74 3a                	je     88fa <f0+0x199a>
    88c0:	0f b6 0a             	movzbl (%rdx),%ecx
    88c3:	80 f9 02             	cmp    $0x2,%cl
    88c6:	0f 84 d4 0c 00 00    	je     95a0 <f0+0x2640>
    88cc:	80 f9 01             	cmp    $0x1,%cl
    88cf:	75 29                	jne    88fa <f0+0x199a>
    88d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88d4:	0f b7 c0             	movzwl %ax,%eax
    88d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88da:	48 0f af c1          	imul   %rcx,%rax
    88de:	48 c1 e8 20          	shr    $0x20,%rax
    88e2:	48 39 d0             	cmp    %rdx,%rax
    88e5:	73 13                	jae    88fa <f0+0x199a>
    88e7:	49 01 c4             	add    %rax,%r12
    88ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    88ef:	0f 84 d0 0f 00 00    	je     98c5 <f0+0x2965>
    88f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    88fa:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
    8901:	00 
    8902:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    8909:	00 
    890a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8911:	00 f0 3f 
    8914:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    891b:	00 
    891c:	e8 ff bd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8921:	48 8b 15 f0 61 01 00 	mov    0x161f0(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8928:	49 89 c5             	mov    %rax,%r13
    892b:	48 2b 05 be 61 01 00 	sub    0x161be(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8932:	48 c1 e2 10          	shl    $0x10,%rdx
    8936:	48 39 d0             	cmp    %rdx,%rax
    8939:	73 59                	jae    8994 <f0+0x1a34>
    893b:	48 89 c2             	mov    %rax,%rdx
    893e:	48 c1 ea 10          	shr    $0x10,%rdx
    8942:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8946:	48 8b 15 eb 61 01 00 	mov    0x161eb(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    894d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8951:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8955:	4d 85 e4             	test   %r12,%r12
    8958:	74 3a                	je     8994 <f0+0x1a34>
    895a:	0f b6 0a             	movzbl (%rdx),%ecx
    895d:	80 f9 02             	cmp    $0x2,%cl
    8960:	0f 84 2a 0c 00 00    	je     9590 <f0+0x2630>
    8966:	80 f9 01             	cmp    $0x1,%cl
    8969:	75 29                	jne    8994 <f0+0x1a34>
    896b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    896e:	0f b7 c0             	movzwl %ax,%eax
    8971:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8974:	48 0f af c1          	imul   %rcx,%rax
    8978:	48 c1 e8 20          	shr    $0x20,%rax
    897c:	48 39 d0             	cmp    %rdx,%rax
    897f:	73 13                	jae    8994 <f0+0x1a34>
    8981:	49 01 c4             	add    %rax,%r12
    8984:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8989:	0f 84 43 0f 00 00    	je     98d2 <f0+0x2972>
    898f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8994:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
    899b:	00 
    899c:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    89a3:	00 
    89a4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    89ab:	33 f3 bf 
    89ae:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    89b5:	00 
    89b6:	e8 65 bd ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    89bb:	48 8b 15 56 61 01 00 	mov    0x16156(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    89c2:	49 89 c5             	mov    %rax,%r13
    89c5:	48 2b 05 24 61 01 00 	sub    0x16124(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    89cc:	48 c1 e2 10          	shl    $0x10,%rdx
    89d0:	48 39 d0             	cmp    %rdx,%rax
    89d3:	73 59                	jae    8a2e <f0+0x1ace>
    89d5:	48 89 c2             	mov    %rax,%rdx
    89d8:	48 c1 ea 10          	shr    $0x10,%rdx
    89dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89e0:	48 8b 15 51 61 01 00 	mov    0x16151(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    89e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89eb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    89ef:	4d 85 e4             	test   %r12,%r12
    89f2:	74 3a                	je     8a2e <f0+0x1ace>
    89f4:	0f b6 0a             	movzbl (%rdx),%ecx
    89f7:	80 f9 02             	cmp    $0x2,%cl
    89fa:	0f 84 80 0b 00 00    	je     9580 <f0+0x2620>
    8a00:	80 f9 01             	cmp    $0x1,%cl
    8a03:	75 29                	jne    8a2e <f0+0x1ace>
    8a05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a08:	0f b7 c0             	movzwl %ax,%eax
    8a0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a0e:	48 0f af c1          	imul   %rcx,%rax
    8a12:	48 c1 e8 20          	shr    $0x20,%rax
    8a16:	48 39 d0             	cmp    %rdx,%rax
    8a19:	73 13                	jae    8a2e <f0+0x1ace>
    8a1b:	49 01 c4             	add    %rax,%r12
    8a1e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8a23:	0f 84 b6 0e 00 00    	je     98df <f0+0x297f>
    8a29:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8a2e:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
    8a35:	00 
    8a36:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    8a3d:	00 
    8a3e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8a45:	00 f0 3f 
    8a48:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    8a4f:	00 
    8a50:	e8 cb bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8a55:	48 8b 15 bc 60 01 00 	mov    0x160bc(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8a5c:	49 89 c5             	mov    %rax,%r13
    8a5f:	48 2b 05 8a 60 01 00 	sub    0x1608a(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8a66:	48 c1 e2 10          	shl    $0x10,%rdx
    8a6a:	48 39 d0             	cmp    %rdx,%rax
    8a6d:	73 59                	jae    8ac8 <f0+0x1b68>
    8a6f:	48 89 c2             	mov    %rax,%rdx
    8a72:	48 c1 ea 10          	shr    $0x10,%rdx
    8a76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a7a:	48 8b 15 b7 60 01 00 	mov    0x160b7(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8a81:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a85:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8a89:	4d 85 e4             	test   %r12,%r12
    8a8c:	74 3a                	je     8ac8 <f0+0x1b68>
    8a8e:	0f b6 0a             	movzbl (%rdx),%ecx
    8a91:	80 f9 02             	cmp    $0x2,%cl
    8a94:	0f 84 d6 0a 00 00    	je     9570 <f0+0x2610>
    8a9a:	80 f9 01             	cmp    $0x1,%cl
    8a9d:	75 29                	jne    8ac8 <f0+0x1b68>
    8a9f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8aa2:	0f b7 c0             	movzwl %ax,%eax
    8aa5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8aa8:	48 0f af c1          	imul   %rcx,%rax
    8aac:	48 c1 e8 20          	shr    $0x20,%rax
    8ab0:	48 39 d0             	cmp    %rdx,%rax
    8ab3:	73 13                	jae    8ac8 <f0+0x1b68>
    8ab5:	49 01 c4             	add    %rax,%r12
    8ab8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8abd:	0f 84 29 0e 00 00    	je     98ec <f0+0x298c>
    8ac3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8ac8:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
    8acf:	00 
    8ad0:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    8ad7:	00 
    8ad8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8adf:	33 f3 bf 
    8ae2:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    8ae9:	00 
    8aea:	e8 31 bc ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8aef:	48 8b 15 22 60 01 00 	mov    0x16022(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8af6:	49 89 c5             	mov    %rax,%r13
    8af9:	48 2b 05 f0 5f 01 00 	sub    0x15ff0(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8b00:	48 c1 e2 10          	shl    $0x10,%rdx
    8b04:	48 39 d0             	cmp    %rdx,%rax
    8b07:	73 59                	jae    8b62 <f0+0x1c02>
    8b09:	48 89 c2             	mov    %rax,%rdx
    8b0c:	48 c1 ea 10          	shr    $0x10,%rdx
    8b10:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b14:	48 8b 15 1d 60 01 00 	mov    0x1601d(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8b1b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b1f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8b23:	4d 85 e4             	test   %r12,%r12
    8b26:	74 3a                	je     8b62 <f0+0x1c02>
    8b28:	0f b6 0a             	movzbl (%rdx),%ecx
    8b2b:	80 f9 02             	cmp    $0x2,%cl
    8b2e:	0f 84 24 0a 00 00    	je     9558 <f0+0x25f8>
    8b34:	80 f9 01             	cmp    $0x1,%cl
    8b37:	75 29                	jne    8b62 <f0+0x1c02>
    8b39:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b3c:	0f b7 c0             	movzwl %ax,%eax
    8b3f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b42:	48 0f af c1          	imul   %rcx,%rax
    8b46:	48 c1 e8 20          	shr    $0x20,%rax
    8b4a:	48 39 d0             	cmp    %rdx,%rax
    8b4d:	73 13                	jae    8b62 <f0+0x1c02>
    8b4f:	49 01 c4             	add    %rax,%r12
    8b52:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8b57:	0f 84 9c 0d 00 00    	je     98f9 <f0+0x2999>
    8b5d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8b62:	48 8d bc 24 50 07 00 	lea    0x750(%rsp),%rdi
    8b69:	00 
    8b6a:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    8b71:	00 
    8b72:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8b79:	00 f0 3f 
    8b7c:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    8b83:	00 
    8b84:	e8 97 bb ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8b89:	48 8b 15 88 5f 01 00 	mov    0x15f88(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8b90:	49 89 c5             	mov    %rax,%r13
    8b93:	48 2b 05 56 5f 01 00 	sub    0x15f56(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8b9a:	48 c1 e2 10          	shl    $0x10,%rdx
    8b9e:	48 39 d0             	cmp    %rdx,%rax
    8ba1:	73 59                	jae    8bfc <f0+0x1c9c>
    8ba3:	48 89 c2             	mov    %rax,%rdx
    8ba6:	48 c1 ea 10          	shr    $0x10,%rdx
    8baa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bae:	48 8b 15 83 5f 01 00 	mov    0x15f83(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8bb5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8bb9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8bbd:	4d 85 e4             	test   %r12,%r12
    8bc0:	74 3a                	je     8bfc <f0+0x1c9c>
    8bc2:	0f b6 0a             	movzbl (%rdx),%ecx
    8bc5:	80 f9 02             	cmp    $0x2,%cl
    8bc8:	0f 84 f2 0b 00 00    	je     97c0 <f0+0x2860>
    8bce:	80 f9 01             	cmp    $0x1,%cl
    8bd1:	75 29                	jne    8bfc <f0+0x1c9c>
    8bd3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8bd6:	0f b7 c0             	movzwl %ax,%eax
    8bd9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bdc:	48 0f af c1          	imul   %rcx,%rax
    8be0:	48 c1 e8 20          	shr    $0x20,%rax
    8be4:	48 39 d0             	cmp    %rdx,%rax
    8be7:	73 13                	jae    8bfc <f0+0x1c9c>
    8be9:	49 01 c4             	add    %rax,%r12
    8bec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8bf1:	0f 84 0f 0d 00 00    	je     9906 <f0+0x29a6>
    8bf7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8bfc:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
    8c03:	00 
    8c04:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    8c0b:	00 
    8c0c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8c13:	33 f3 bf 
    8c16:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    8c1d:	00 
    8c1e:	e8 fd ba ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8c23:	48 8b 15 ee 5e 01 00 	mov    0x15eee(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8c2a:	49 89 c5             	mov    %rax,%r13
    8c2d:	48 2b 05 bc 5e 01 00 	sub    0x15ebc(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8c34:	48 c1 e2 10          	shl    $0x10,%rdx
    8c38:	48 39 d0             	cmp    %rdx,%rax
    8c3b:	73 59                	jae    8c96 <f0+0x1d36>
    8c3d:	48 89 c2             	mov    %rax,%rdx
    8c40:	48 c1 ea 10          	shr    $0x10,%rdx
    8c44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c48:	48 8b 15 e9 5e 01 00 	mov    0x15ee9(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8c4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c53:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8c57:	4d 85 e4             	test   %r12,%r12
    8c5a:	74 3a                	je     8c96 <f0+0x1d36>
    8c5c:	0f b6 0a             	movzbl (%rdx),%ecx
    8c5f:	80 f9 02             	cmp    $0x2,%cl
    8c62:	0f 84 48 0b 00 00    	je     97b0 <f0+0x2850>
    8c68:	80 f9 01             	cmp    $0x1,%cl
    8c6b:	75 29                	jne    8c96 <f0+0x1d36>
    8c6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c70:	0f b7 c0             	movzwl %ax,%eax
    8c73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c76:	48 0f af c1          	imul   %rcx,%rax
    8c7a:	48 c1 e8 20          	shr    $0x20,%rax
    8c7e:	48 39 d0             	cmp    %rdx,%rax
    8c81:	73 13                	jae    8c96 <f0+0x1d36>
    8c83:	49 01 c4             	add    %rax,%r12
    8c86:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8c8b:	0f 84 82 0c 00 00    	je     9913 <f0+0x29b3>
    8c91:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8c96:	48 8d bc 24 70 07 00 	lea    0x770(%rsp),%rdi
    8c9d:	00 
    8c9e:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    8ca5:	00 
    8ca6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8cad:	00 f0 3f 
    8cb0:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    8cb7:	00 
    8cb8:	e8 63 ba ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8cbd:	48 8b 15 54 5e 01 00 	mov    0x15e54(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8cc4:	49 89 c5             	mov    %rax,%r13
    8cc7:	48 2b 05 22 5e 01 00 	sub    0x15e22(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8cce:	48 c1 e2 10          	shl    $0x10,%rdx
    8cd2:	48 39 d0             	cmp    %rdx,%rax
    8cd5:	73 59                	jae    8d30 <f0+0x1dd0>
    8cd7:	48 89 c2             	mov    %rax,%rdx
    8cda:	48 c1 ea 10          	shr    $0x10,%rdx
    8cde:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ce2:	48 8b 15 4f 5e 01 00 	mov    0x15e4f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8ce9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ced:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8cf1:	4d 85 e4             	test   %r12,%r12
    8cf4:	74 3a                	je     8d30 <f0+0x1dd0>
    8cf6:	0f b6 0a             	movzbl (%rdx),%ecx
    8cf9:	80 f9 02             	cmp    $0x2,%cl
    8cfc:	0f 84 9e 0a 00 00    	je     97a0 <f0+0x2840>
    8d02:	80 f9 01             	cmp    $0x1,%cl
    8d05:	75 29                	jne    8d30 <f0+0x1dd0>
    8d07:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d0a:	0f b7 c0             	movzwl %ax,%eax
    8d0d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d10:	48 0f af c1          	imul   %rcx,%rax
    8d14:	48 c1 e8 20          	shr    $0x20,%rax
    8d18:	48 39 d0             	cmp    %rdx,%rax
    8d1b:	73 13                	jae    8d30 <f0+0x1dd0>
    8d1d:	49 01 c4             	add    %rax,%r12
    8d20:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8d25:	0f 84 f5 0b 00 00    	je     9920 <f0+0x29c0>
    8d2b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8d30:	48 8d bc 24 80 07 00 	lea    0x780(%rsp),%rdi
    8d37:	00 
    8d38:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    8d3f:	00 
    8d40:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8d47:	33 f3 bf 
    8d4a:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    8d51:	00 
    8d52:	e8 c9 b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8d57:	48 8b 15 ba 5d 01 00 	mov    0x15dba(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8d5e:	49 89 c5             	mov    %rax,%r13
    8d61:	48 2b 05 88 5d 01 00 	sub    0x15d88(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8d68:	48 c1 e2 10          	shl    $0x10,%rdx
    8d6c:	48 39 d0             	cmp    %rdx,%rax
    8d6f:	73 59                	jae    8dca <f0+0x1e6a>
    8d71:	48 89 c2             	mov    %rax,%rdx
    8d74:	48 c1 ea 10          	shr    $0x10,%rdx
    8d78:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d7c:	48 8b 15 b5 5d 01 00 	mov    0x15db5(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8d83:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d87:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8d8b:	4d 85 e4             	test   %r12,%r12
    8d8e:	74 3a                	je     8dca <f0+0x1e6a>
    8d90:	0f b6 0a             	movzbl (%rdx),%ecx
    8d93:	80 f9 02             	cmp    $0x2,%cl
    8d96:	0f 84 f4 09 00 00    	je     9790 <f0+0x2830>
    8d9c:	80 f9 01             	cmp    $0x1,%cl
    8d9f:	75 29                	jne    8dca <f0+0x1e6a>
    8da1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8da4:	0f b7 c0             	movzwl %ax,%eax
    8da7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8daa:	48 0f af c1          	imul   %rcx,%rax
    8dae:	48 c1 e8 20          	shr    $0x20,%rax
    8db2:	48 39 d0             	cmp    %rdx,%rax
    8db5:	73 13                	jae    8dca <f0+0x1e6a>
    8db7:	49 01 c4             	add    %rax,%r12
    8dba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8dbf:	0f 84 68 0b 00 00    	je     992d <f0+0x29cd>
    8dc5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8dca:	48 8d bc 24 90 07 00 	lea    0x790(%rsp),%rdi
    8dd1:	00 
    8dd2:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    8dd9:	00 
    8dda:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8de1:	00 f0 3f 
    8de4:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    8deb:	00 
    8dec:	e8 2f b9 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8df1:	48 8b 15 20 5d 01 00 	mov    0x15d20(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8df8:	49 89 c5             	mov    %rax,%r13
    8dfb:	48 2b 05 ee 5c 01 00 	sub    0x15cee(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8e02:	48 c1 e2 10          	shl    $0x10,%rdx
    8e06:	48 39 d0             	cmp    %rdx,%rax
    8e09:	73 59                	jae    8e64 <f0+0x1f04>
    8e0b:	48 89 c2             	mov    %rax,%rdx
    8e0e:	48 c1 ea 10          	shr    $0x10,%rdx
    8e12:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8e16:	48 8b 15 1b 5d 01 00 	mov    0x15d1b(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8e1d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8e21:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8e25:	4d 85 e4             	test   %r12,%r12
    8e28:	74 3a                	je     8e64 <f0+0x1f04>
    8e2a:	0f b6 0a             	movzbl (%rdx),%ecx
    8e2d:	80 f9 02             	cmp    $0x2,%cl
    8e30:	0f 84 4a 09 00 00    	je     9780 <f0+0x2820>
    8e36:	80 f9 01             	cmp    $0x1,%cl
    8e39:	75 29                	jne    8e64 <f0+0x1f04>
    8e3b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8e3e:	0f b7 c0             	movzwl %ax,%eax
    8e41:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e44:	48 0f af c1          	imul   %rcx,%rax
    8e48:	48 c1 e8 20          	shr    $0x20,%rax
    8e4c:	48 39 d0             	cmp    %rdx,%rax
    8e4f:	73 13                	jae    8e64 <f0+0x1f04>
    8e51:	49 01 c4             	add    %rax,%r12
    8e54:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8e59:	0f 84 db 0a 00 00    	je     993a <f0+0x29da>
    8e5f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8e64:	48 8d bc 24 a0 07 00 	lea    0x7a0(%rsp),%rdi
    8e6b:	00 
    8e6c:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    8e73:	00 
    8e74:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8e7b:	33 f3 bf 
    8e7e:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    8e85:	00 
    8e86:	e8 95 b8 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8e8b:	48 8b 15 86 5c 01 00 	mov    0x15c86(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8e92:	49 89 c5             	mov    %rax,%r13
    8e95:	48 2b 05 54 5c 01 00 	sub    0x15c54(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8e9c:	48 c1 e2 10          	shl    $0x10,%rdx
    8ea0:	48 39 d0             	cmp    %rdx,%rax
    8ea3:	73 59                	jae    8efe <f0+0x1f9e>
    8ea5:	48 89 c2             	mov    %rax,%rdx
    8ea8:	48 c1 ea 10          	shr    $0x10,%rdx
    8eac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8eb0:	48 8b 15 81 5c 01 00 	mov    0x15c81(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8eb7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ebb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ebf:	4d 85 e4             	test   %r12,%r12
    8ec2:	74 3a                	je     8efe <f0+0x1f9e>
    8ec4:	0f b6 0a             	movzbl (%rdx),%ecx
    8ec7:	80 f9 02             	cmp    $0x2,%cl
    8eca:	0f 84 a0 08 00 00    	je     9770 <f0+0x2810>
    8ed0:	80 f9 01             	cmp    $0x1,%cl
    8ed3:	75 29                	jne    8efe <f0+0x1f9e>
    8ed5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ed8:	0f b7 c0             	movzwl %ax,%eax
    8edb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ede:	48 0f af c1          	imul   %rcx,%rax
    8ee2:	48 c1 e8 20          	shr    $0x20,%rax
    8ee6:	48 39 d0             	cmp    %rdx,%rax
    8ee9:	73 13                	jae    8efe <f0+0x1f9e>
    8eeb:	49 01 c4             	add    %rax,%r12
    8eee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8ef3:	0f 84 4e 0a 00 00    	je     9947 <f0+0x29e7>
    8ef9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8efe:	48 8d bc 24 b0 07 00 	lea    0x7b0(%rsp),%rdi
    8f05:	00 
    8f06:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    8f0d:	00 
    8f0e:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8f15:	00 f0 3f 
    8f18:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    8f1f:	00 
    8f20:	e8 fb b7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8f25:	48 8b 15 ec 5b 01 00 	mov    0x15bec(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8f2c:	49 89 c5             	mov    %rax,%r13
    8f2f:	48 2b 05 ba 5b 01 00 	sub    0x15bba(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8f36:	48 c1 e2 10          	shl    $0x10,%rdx
    8f3a:	48 39 d0             	cmp    %rdx,%rax
    8f3d:	73 59                	jae    8f98 <f0+0x2038>
    8f3f:	48 89 c2             	mov    %rax,%rdx
    8f42:	48 c1 ea 10          	shr    $0x10,%rdx
    8f46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f4a:	48 8b 15 e7 5b 01 00 	mov    0x15be7(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8f51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8f59:	4d 85 e4             	test   %r12,%r12
    8f5c:	74 3a                	je     8f98 <f0+0x2038>
    8f5e:	0f b6 0a             	movzbl (%rdx),%ecx
    8f61:	80 f9 02             	cmp    $0x2,%cl
    8f64:	0f 84 f6 07 00 00    	je     9760 <f0+0x2800>
    8f6a:	80 f9 01             	cmp    $0x1,%cl
    8f6d:	75 29                	jne    8f98 <f0+0x2038>
    8f6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f72:	0f b7 c0             	movzwl %ax,%eax
    8f75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f78:	48 0f af c1          	imul   %rcx,%rax
    8f7c:	48 c1 e8 20          	shr    $0x20,%rax
    8f80:	48 39 d0             	cmp    %rdx,%rax
    8f83:	73 13                	jae    8f98 <f0+0x2038>
    8f85:	49 01 c4             	add    %rax,%r12
    8f88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8f8d:	0f 84 c1 09 00 00    	je     9954 <f0+0x29f4>
    8f93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8f98:	48 8d bc 24 c0 07 00 	lea    0x7c0(%rsp),%rdi
    8f9f:	00 
    8fa0:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    8fa7:	00 
    8fa8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    8faf:	33 f3 bf 
    8fb2:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    8fb9:	00 
    8fba:	e8 61 b7 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    8fbf:	48 8b 15 52 5b 01 00 	mov    0x15b52(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    8fc6:	49 89 c5             	mov    %rax,%r13
    8fc9:	48 2b 05 20 5b 01 00 	sub    0x15b20(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    8fd0:	48 c1 e2 10          	shl    $0x10,%rdx
    8fd4:	48 39 d0             	cmp    %rdx,%rax
    8fd7:	73 59                	jae    9032 <f0+0x20d2>
    8fd9:	48 89 c2             	mov    %rax,%rdx
    8fdc:	48 c1 ea 10          	shr    $0x10,%rdx
    8fe0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8fe4:	48 8b 15 4d 5b 01 00 	mov    0x15b4d(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    8feb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8fef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8ff3:	4d 85 e4             	test   %r12,%r12
    8ff6:	74 3a                	je     9032 <f0+0x20d2>
    8ff8:	0f b6 0a             	movzbl (%rdx),%ecx
    8ffb:	80 f9 02             	cmp    $0x2,%cl
    8ffe:	0f 84 4c 07 00 00    	je     9750 <f0+0x27f0>
    9004:	80 f9 01             	cmp    $0x1,%cl
    9007:	75 29                	jne    9032 <f0+0x20d2>
    9009:	8b 4a 18             	mov    0x18(%rdx),%ecx
    900c:	0f b7 c0             	movzwl %ax,%eax
    900f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9012:	48 0f af c1          	imul   %rcx,%rax
    9016:	48 c1 e8 20          	shr    $0x20,%rax
    901a:	48 39 d0             	cmp    %rdx,%rax
    901d:	73 13                	jae    9032 <f0+0x20d2>
    901f:	49 01 c4             	add    %rax,%r12
    9022:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9027:	0f 84 34 09 00 00    	je     9961 <f0+0x2a01>
    902d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9032:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
    9039:	00 
    903a:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    9041:	00 
    9042:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9049:	00 f0 3f 
    904c:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    9053:	00 
    9054:	e8 c7 b6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9059:	48 8b 15 b8 5a 01 00 	mov    0x15ab8(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9060:	49 89 c5             	mov    %rax,%r13
    9063:	48 2b 05 86 5a 01 00 	sub    0x15a86(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    906a:	48 c1 e2 10          	shl    $0x10,%rdx
    906e:	48 39 d0             	cmp    %rdx,%rax
    9071:	73 59                	jae    90cc <f0+0x216c>
    9073:	48 89 c2             	mov    %rax,%rdx
    9076:	48 c1 ea 10          	shr    $0x10,%rdx
    907a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    907e:	48 8b 15 b3 5a 01 00 	mov    0x15ab3(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9085:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9089:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    908d:	4d 85 e4             	test   %r12,%r12
    9090:	74 3a                	je     90cc <f0+0x216c>
    9092:	0f b6 0a             	movzbl (%rdx),%ecx
    9095:	80 f9 02             	cmp    $0x2,%cl
    9098:	0f 84 a2 06 00 00    	je     9740 <f0+0x27e0>
    909e:	80 f9 01             	cmp    $0x1,%cl
    90a1:	75 29                	jne    90cc <f0+0x216c>
    90a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90a6:	0f b7 c0             	movzwl %ax,%eax
    90a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90ac:	48 0f af c1          	imul   %rcx,%rax
    90b0:	48 c1 e8 20          	shr    $0x20,%rax
    90b4:	48 39 d0             	cmp    %rdx,%rax
    90b7:	73 13                	jae    90cc <f0+0x216c>
    90b9:	49 01 c4             	add    %rax,%r12
    90bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    90c1:	0f 84 a7 08 00 00    	je     996e <f0+0x2a0e>
    90c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    90cc:	48 8d bc 24 e0 07 00 	lea    0x7e0(%rsp),%rdi
    90d3:	00 
    90d4:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    90db:	00 
    90dc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    90e3:	33 f3 bf 
    90e6:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    90ed:	00 
    90ee:	e8 2d b6 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    90f3:	48 8b 15 1e 5a 01 00 	mov    0x15a1e(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    90fa:	49 89 c5             	mov    %rax,%r13
    90fd:	48 2b 05 ec 59 01 00 	sub    0x159ec(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9104:	48 c1 e2 10          	shl    $0x10,%rdx
    9108:	48 39 d0             	cmp    %rdx,%rax
    910b:	73 59                	jae    9166 <f0+0x2206>
    910d:	48 89 c2             	mov    %rax,%rdx
    9110:	48 c1 ea 10          	shr    $0x10,%rdx
    9114:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9118:	48 8b 15 19 5a 01 00 	mov    0x15a19(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    911f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9123:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9127:	4d 85 e4             	test   %r12,%r12
    912a:	74 3a                	je     9166 <f0+0x2206>
    912c:	0f b6 0a             	movzbl (%rdx),%ecx
    912f:	80 f9 02             	cmp    $0x2,%cl
    9132:	0f 84 f8 05 00 00    	je     9730 <f0+0x27d0>
    9138:	80 f9 01             	cmp    $0x1,%cl
    913b:	75 29                	jne    9166 <f0+0x2206>
    913d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9140:	0f b7 c0             	movzwl %ax,%eax
    9143:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9146:	48 0f af c1          	imul   %rcx,%rax
    914a:	48 c1 e8 20          	shr    $0x20,%rax
    914e:	48 39 d0             	cmp    %rdx,%rax
    9151:	73 13                	jae    9166 <f0+0x2206>
    9153:	49 01 c4             	add    %rax,%r12
    9156:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    915b:	0f 84 1a 08 00 00    	je     997b <f0+0x2a1b>
    9161:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9166:	48 8d bc 24 f0 07 00 	lea    0x7f0(%rsp),%rdi
    916d:	00 
    916e:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    9175:	00 
    9176:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    917d:	00 f0 3f 
    9180:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    9187:	00 
    9188:	e8 93 b5 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    918d:	48 8b 15 84 59 01 00 	mov    0x15984(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9194:	49 89 c5             	mov    %rax,%r13
    9197:	48 2b 05 52 59 01 00 	sub    0x15952(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    919e:	48 c1 e2 10          	shl    $0x10,%rdx
    91a2:	48 39 d0             	cmp    %rdx,%rax
    91a5:	73 59                	jae    9200 <f0+0x22a0>
    91a7:	48 89 c2             	mov    %rax,%rdx
    91aa:	48 c1 ea 10          	shr    $0x10,%rdx
    91ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    91b2:	48 8b 15 7f 59 01 00 	mov    0x1597f(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    91b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    91bd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    91c1:	4d 85 e4             	test   %r12,%r12
    91c4:	74 3a                	je     9200 <f0+0x22a0>
    91c6:	0f b6 0a             	movzbl (%rdx),%ecx
    91c9:	80 f9 02             	cmp    $0x2,%cl
    91cc:	0f 84 4e 05 00 00    	je     9720 <f0+0x27c0>
    91d2:	80 f9 01             	cmp    $0x1,%cl
    91d5:	75 29                	jne    9200 <f0+0x22a0>
    91d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91da:	0f b7 c0             	movzwl %ax,%eax
    91dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91e0:	48 0f af c1          	imul   %rcx,%rax
    91e4:	48 c1 e8 20          	shr    $0x20,%rax
    91e8:	48 39 d0             	cmp    %rdx,%rax
    91eb:	73 13                	jae    9200 <f0+0x22a0>
    91ed:	49 01 c4             	add    %rax,%r12
    91f0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    91f5:	0f 84 8d 07 00 00    	je     9988 <f0+0x2a28>
    91fb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9200:	48 8d bc 24 00 08 00 	lea    0x800(%rsp),%rdi
    9207:	00 
    9208:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    920f:	00 
    9210:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9217:	33 f3 bf 
    921a:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    9221:	00 
    9222:	e8 f9 b4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    9227:	48 8b 15 ea 58 01 00 	mov    0x158ea(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    922e:	49 89 c5             	mov    %rax,%r13
    9231:	48 2b 05 b8 58 01 00 	sub    0x158b8(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9238:	48 c1 e2 10          	shl    $0x10,%rdx
    923c:	48 39 d0             	cmp    %rdx,%rax
    923f:	73 59                	jae    929a <f0+0x233a>
    9241:	48 89 c2             	mov    %rax,%rdx
    9244:	48 c1 ea 10          	shr    $0x10,%rdx
    9248:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    924c:	48 8b 15 e5 58 01 00 	mov    0x158e5(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9253:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9257:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    925b:	4d 85 e4             	test   %r12,%r12
    925e:	74 3a                	je     929a <f0+0x233a>
    9260:	0f b6 0a             	movzbl (%rdx),%ecx
    9263:	80 f9 02             	cmp    $0x2,%cl
    9266:	0f 84 a4 04 00 00    	je     9710 <f0+0x27b0>
    926c:	80 f9 01             	cmp    $0x1,%cl
    926f:	75 29                	jne    929a <f0+0x233a>
    9271:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9274:	0f b7 c0             	movzwl %ax,%eax
    9277:	8b 52 1c             	mov    0x1c(%rdx),%edx
    927a:	48 0f af c1          	imul   %rcx,%rax
    927e:	48 c1 e8 20          	shr    $0x20,%rax
    9282:	48 39 d0             	cmp    %rdx,%rax
    9285:	73 13                	jae    929a <f0+0x233a>
    9287:	49 01 c4             	add    %rax,%r12
    928a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    928f:	0f 84 00 07 00 00    	je     9995 <f0+0x2a35>
    9295:	41 c6 04 24 01       	movb   $0x1,(%r12)
    929a:	48 8d bc 24 10 08 00 	lea    0x810(%rsp),%rdi
    92a1:	00 
    92a2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    92a9:	00 
    92aa:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    92b1:	00 f0 3f 
    92b4:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    92bb:	00 
    92bc:	e8 5f b4 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    92c1:	48 8b 15 50 58 01 00 	mov    0x15850(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    92c8:	49 89 c5             	mov    %rax,%r13
    92cb:	48 2b 05 1e 58 01 00 	sub    0x1581e(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    92d2:	48 c1 e2 10          	shl    $0x10,%rdx
    92d6:	48 39 d0             	cmp    %rdx,%rax
    92d9:	73 59                	jae    9334 <f0+0x23d4>
    92db:	48 89 c2             	mov    %rax,%rdx
    92de:	48 c1 ea 10          	shr    $0x10,%rdx
    92e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92e6:	48 8b 15 4b 58 01 00 	mov    0x1584b(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    92ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92f1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    92f5:	4d 85 e4             	test   %r12,%r12
    92f8:	74 3a                	je     9334 <f0+0x23d4>
    92fa:	0f b6 0a             	movzbl (%rdx),%ecx
    92fd:	80 f9 02             	cmp    $0x2,%cl
    9300:	0f 84 fa 03 00 00    	je     9700 <f0+0x27a0>
    9306:	80 f9 01             	cmp    $0x1,%cl
    9309:	75 29                	jne    9334 <f0+0x23d4>
    930b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    930e:	0f b7 c0             	movzwl %ax,%eax
    9311:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9314:	48 0f af c1          	imul   %rcx,%rax
    9318:	48 c1 e8 20          	shr    $0x20,%rax
    931c:	48 39 d0             	cmp    %rdx,%rax
    931f:	73 13                	jae    9334 <f0+0x23d4>
    9321:	49 01 c4             	add    %rax,%r12
    9324:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9329:	0f 84 73 06 00 00    	je     99a2 <f0+0x2a42>
    932f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9334:	48 8d bc 24 20 08 00 	lea    0x820(%rsp),%rdi
    933b:	00 
    933c:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    9343:	00 
    9344:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    934b:	33 f3 bf 
    934e:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    9355:	00 
    9356:	e8 c5 b3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    935b:	48 8b 15 b6 57 01 00 	mov    0x157b6(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9362:	49 89 c5             	mov    %rax,%r13
    9365:	48 2b 05 84 57 01 00 	sub    0x15784(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    936c:	48 c1 e2 10          	shl    $0x10,%rdx
    9370:	48 39 d0             	cmp    %rdx,%rax
    9373:	73 59                	jae    93ce <f0+0x246e>
    9375:	48 89 c2             	mov    %rax,%rdx
    9378:	48 c1 ea 10          	shr    $0x10,%rdx
    937c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9380:	48 8b 15 b1 57 01 00 	mov    0x157b1(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9387:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    938b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    938f:	4d 85 e4             	test   %r12,%r12
    9392:	74 3a                	je     93ce <f0+0x246e>
    9394:	0f b6 0a             	movzbl (%rdx),%ecx
    9397:	80 f9 02             	cmp    $0x2,%cl
    939a:	0f 84 50 03 00 00    	je     96f0 <f0+0x2790>
    93a0:	80 f9 01             	cmp    $0x1,%cl
    93a3:	75 29                	jne    93ce <f0+0x246e>
    93a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93a8:	0f b7 c0             	movzwl %ax,%eax
    93ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93ae:	48 0f af c1          	imul   %rcx,%rax
    93b2:	48 c1 e8 20          	shr    $0x20,%rax
    93b6:	48 39 d0             	cmp    %rdx,%rax
    93b9:	73 13                	jae    93ce <f0+0x246e>
    93bb:	49 01 c4             	add    %rax,%r12
    93be:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    93c3:	0f 84 e6 05 00 00    	je     99af <f0+0x2a4f>
    93c9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    93ce:	48 8d bc 24 30 08 00 	lea    0x830(%rsp),%rdi
    93d5:	00 
    93d6:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    93dd:	00 
    93de:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    93e5:	00 f0 3f 
    93e8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    93ef:	00 
    93f0:	e8 2b b3 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    93f5:	48 8b 15 1c 57 01 00 	mov    0x1571c(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    93fc:	49 89 c5             	mov    %rax,%r13
    93ff:	48 2b 05 ea 56 01 00 	sub    0x156ea(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    9406:	48 c1 e2 10          	shl    $0x10,%rdx
    940a:	48 39 d0             	cmp    %rdx,%rax
    940d:	73 59                	jae    9468 <f0+0x2508>
    940f:	48 89 c2             	mov    %rax,%rdx
    9412:	48 c1 ea 10          	shr    $0x10,%rdx
    9416:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    941a:	48 8b 15 17 57 01 00 	mov    0x15717(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    9421:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9425:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9429:	4d 85 e4             	test   %r12,%r12
    942c:	74 3a                	je     9468 <f0+0x2508>
    942e:	0f b6 0a             	movzbl (%rdx),%ecx
    9431:	80 f9 02             	cmp    $0x2,%cl
    9434:	0f 84 a6 02 00 00    	je     96e0 <f0+0x2780>
    943a:	80 f9 01             	cmp    $0x1,%cl
    943d:	75 29                	jne    9468 <f0+0x2508>
    943f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9442:	0f b7 c0             	movzwl %ax,%eax
    9445:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9448:	48 0f af c1          	imul   %rcx,%rax
    944c:	48 c1 e8 20          	shr    $0x20,%rax
    9450:	48 39 d0             	cmp    %rdx,%rax
    9453:	73 13                	jae    9468 <f0+0x2508>
    9455:	49 01 c4             	add    %rax,%r12
    9458:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    945d:	0f 84 59 05 00 00    	je     99bc <f0+0x2a5c>
    9463:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9468:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    946f:	33 f3 bf 
    9472:	48 89 ef             	mov    %rbp,%rdi
    9475:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    947c:	00 
    947d:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    9484:	00 
    9485:	e8 96 b2 ff ff       	call   4720 <fwp_data.part.0.constprop.0>
    948a:	48 8b 15 87 56 01 00 	mov    0x15687(%rip),%rdx        # 1eb18 <fwp_heap+0x13d8>
    9491:	48 89 c5             	mov    %rax,%rbp
    9494:	48 2b 05 55 56 01 00 	sub    0x15655(%rip),%rax        # 1eaf0 <fwp_heap+0x13b0>
    949b:	48 c1 e2 10          	shl    $0x10,%rdx
    949f:	48 39 d0             	cmp    %rdx,%rax
    94a2:	73 59                	jae    94fd <f0+0x259d>
    94a4:	48 89 c2             	mov    %rax,%rdx
    94a7:	48 c1 ea 10          	shr    $0x10,%rdx
    94ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94af:	48 8b 15 82 56 01 00 	mov    0x15682(%rip),%rdx        # 1eb38 <fwp_heap+0x13f8>
    94b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94ba:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    94be:	4d 85 e4             	test   %r12,%r12
    94c1:	74 3a                	je     94fd <f0+0x259d>
    94c3:	0f b6 0a             	movzbl (%rdx),%ecx
    94c6:	80 f9 02             	cmp    $0x2,%cl
    94c9:	0f 84 01 02 00 00    	je     96d0 <f0+0x2770>
    94cf:	80 f9 01             	cmp    $0x1,%cl
    94d2:	75 29                	jne    94fd <f0+0x259d>
    94d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94d7:	0f b7 c0             	movzwl %ax,%eax
    94da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94dd:	48 0f af c1          	imul   %rcx,%rax
    94e1:	48 c1 e8 20          	shr    $0x20,%rax
    94e5:	48 39 d0             	cmp    %rdx,%rax
    94e8:	73 13                	jae    94fd <f0+0x259d>
    94ea:	49 01 c4             	add    %rax,%r12
    94ed:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    94f2:	0f 84 d6 02 00 00    	je     97ce <f0+0x286e>
    94f8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    94fd:	48 89 de             	mov    %rbx,%rsi
    9500:	48 89 ef             	mov    %rbp,%rdi
    9503:	e8 c8 ca ff ff       	call   5fd0 <fwp_hof0.constprop.0>
    9508:	48 89 ef             	mov    %rbp,%rdi
    950b:	e8 f0 b7 ff ff       	call   4d00 <fwp_drop0>
    9510:	48 89 df             	mov    %rbx,%rdi
    9513:	e8 e8 b7 ff ff       	call   4d00 <fwp_drop0>
    9518:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    951f:	00 
    9520:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9527:	00 00 
    9529:	0f 85 9a 04 00 00    	jne    99c9 <f0+0x2a69>
    952f:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    9536:	31 c0                	xor    %eax,%eax
    9538:	5b                   	pop    %rbx
    9539:	5d                   	pop    %rbp
    953a:	41 5c                	pop    %r12
    953c:	41 5d                	pop    %r13
    953e:	41 5e                	pop    %r14
    9540:	c3                   	ret
    9541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9548:	4c 89 ef             	mov    %r13,%rdi
    954b:	e8 40 a8 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9550:	e9 c4 da ff ff       	jmp    7019 <f0+0xb9>
    9555:	0f 1f 00             	nopl   (%rax)
    9558:	66 85 c0             	test   %ax,%ax
    955b:	0f 85 01 f6 ff ff    	jne    8b62 <f0+0x1c02>
    9561:	e9 ec f5 ff ff       	jmp    8b52 <f0+0x1bf2>
    9566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    956d:	00 00 00 
    9570:	66 85 c0             	test   %ax,%ax
    9573:	0f 85 4f f5 ff ff    	jne    8ac8 <f0+0x1b68>
    9579:	e9 3a f5 ff ff       	jmp    8ab8 <f0+0x1b58>
    957e:	66 90                	xchg   %ax,%ax
    9580:	66 85 c0             	test   %ax,%ax
    9583:	0f 85 a5 f4 ff ff    	jne    8a2e <f0+0x1ace>
    9589:	e9 90 f4 ff ff       	jmp    8a1e <f0+0x1abe>
    958e:	66 90                	xchg   %ax,%ax
    9590:	66 85 c0             	test   %ax,%ax
    9593:	0f 85 fb f3 ff ff    	jne    8994 <f0+0x1a34>
    9599:	e9 e6 f3 ff ff       	jmp    8984 <f0+0x1a24>
    959e:	66 90                	xchg   %ax,%ax
    95a0:	66 85 c0             	test   %ax,%ax
    95a3:	0f 85 51 f3 ff ff    	jne    88fa <f0+0x199a>
    95a9:	e9 3c f3 ff ff       	jmp    88ea <f0+0x198a>
    95ae:	66 90                	xchg   %ax,%ax
    95b0:	66 85 c0             	test   %ax,%ax
    95b3:	0f 85 a7 f2 ff ff    	jne    8860 <f0+0x1900>
    95b9:	e9 92 f2 ff ff       	jmp    8850 <f0+0x18f0>
    95be:	66 90                	xchg   %ax,%ax
    95c0:	66 85 c0             	test   %ax,%ax
    95c3:	0f 85 fd f1 ff ff    	jne    87c6 <f0+0x1866>
    95c9:	e9 e8 f1 ff ff       	jmp    87b6 <f0+0x1856>
    95ce:	66 90                	xchg   %ax,%ax
    95d0:	66 85 c0             	test   %ax,%ax
    95d3:	0f 85 53 f1 ff ff    	jne    872c <f0+0x17cc>
    95d9:	e9 3e f1 ff ff       	jmp    871c <f0+0x17bc>
    95de:	66 90                	xchg   %ax,%ax
    95e0:	66 85 c0             	test   %ax,%ax
    95e3:	0f 85 6e dc ff ff    	jne    7257 <f0+0x2f7>
    95e9:	e9 59 dc ff ff       	jmp    7247 <f0+0x2e7>
    95ee:	66 90                	xchg   %ax,%ax
    95f0:	66 85 c0             	test   %ax,%ax
    95f3:	0f 85 cd db ff ff    	jne    71c6 <f0+0x266>
    95f9:	e9 b8 db ff ff       	jmp    71b6 <f0+0x256>
    95fe:	66 90                	xchg   %ax,%ax
    9600:	66 85 c0             	test   %ax,%ax
    9603:	0f 85 2c db ff ff    	jne    7135 <f0+0x1d5>
    9609:	e9 17 db ff ff       	jmp    7125 <f0+0x1c5>
    960e:	66 90                	xchg   %ax,%ax
    9610:	66 85 c0             	test   %ax,%ax
    9613:	0f 85 a9 eb ff ff    	jne    81c2 <f0+0x1262>
    9619:	e9 94 eb ff ff       	jmp    81b2 <f0+0x1252>
    961e:	66 90                	xchg   %ax,%ax
    9620:	66 85 c0             	test   %ax,%ax
    9623:	0f 85 ff ea ff ff    	jne    8128 <f0+0x11c8>
    9629:	e9 ea ea ff ff       	jmp    8118 <f0+0x11b8>
    962e:	66 90                	xchg   %ax,%ax
    9630:	66 85 c0             	test   %ax,%ax
    9633:	0f 85 55 ea ff ff    	jne    808e <f0+0x112e>
    9639:	e9 40 ea ff ff       	jmp    807e <f0+0x111e>
    963e:	66 90                	xchg   %ax,%ax
    9640:	66 85 c0             	test   %ax,%ax
    9643:	0f 85 9f dc ff ff    	jne    72e8 <f0+0x388>
    9649:	e9 8a dc ff ff       	jmp    72d8 <f0+0x378>
    964e:	66 90                	xchg   %ax,%ax
    9650:	66 85 c0             	test   %ax,%ax
    9653:	0f 85 39 f0 ff ff    	jne    8692 <f0+0x1732>
    9659:	e9 24 f0 ff ff       	jmp    8682 <f0+0x1722>
    965e:	66 90                	xchg   %ax,%ax
    9660:	66 85 c0             	test   %ax,%ax
    9663:	0f 85 8f ef ff ff    	jne    85f8 <f0+0x1698>
    9669:	e9 7a ef ff ff       	jmp    85e8 <f0+0x1688>
    966e:	66 90                	xchg   %ax,%ax
    9670:	66 85 c0             	test   %ax,%ax
    9673:	0f 85 e5 ee ff ff    	jne    855e <f0+0x15fe>
    9679:	e9 d0 ee ff ff       	jmp    854e <f0+0x15ee>
    967e:	66 90                	xchg   %ax,%ax
    9680:	66 85 c0             	test   %ax,%ax
    9683:	0f 85 3b ee ff ff    	jne    84c4 <f0+0x1564>
    9689:	e9 26 ee ff ff       	jmp    84b4 <f0+0x1554>
    968e:	66 90                	xchg   %ax,%ax
    9690:	66 85 c0             	test   %ax,%ax
    9693:	0f 85 91 ed ff ff    	jne    842a <f0+0x14ca>
    9699:	e9 7c ed ff ff       	jmp    841a <f0+0x14ba>
    969e:	66 90                	xchg   %ax,%ax
    96a0:	66 85 c0             	test   %ax,%ax
    96a3:	0f 85 e7 ec ff ff    	jne    8390 <f0+0x1430>
    96a9:	e9 d2 ec ff ff       	jmp    8380 <f0+0x1420>
    96ae:	66 90                	xchg   %ax,%ax
    96b0:	66 85 c0             	test   %ax,%ax
    96b3:	0f 85 3d ec ff ff    	jne    82f6 <f0+0x1396>
    96b9:	e9 28 ec ff ff       	jmp    82e6 <f0+0x1386>
    96be:	66 90                	xchg   %ax,%ax
    96c0:	66 85 c0             	test   %ax,%ax
    96c3:	0f 85 93 eb ff ff    	jne    825c <f0+0x12fc>
    96c9:	e9 7e eb ff ff       	jmp    824c <f0+0x12ec>
    96ce:	66 90                	xchg   %ax,%ax
    96d0:	66 85 c0             	test   %ax,%ax
    96d3:	0f 85 24 fe ff ff    	jne    94fd <f0+0x259d>
    96d9:	e9 0f fe ff ff       	jmp    94ed <f0+0x258d>
    96de:	66 90                	xchg   %ax,%ax
    96e0:	66 85 c0             	test   %ax,%ax
    96e3:	0f 85 7f fd ff ff    	jne    9468 <f0+0x2508>
    96e9:	e9 6a fd ff ff       	jmp    9458 <f0+0x24f8>
    96ee:	66 90                	xchg   %ax,%ax
    96f0:	66 85 c0             	test   %ax,%ax
    96f3:	0f 85 d5 fc ff ff    	jne    93ce <f0+0x246e>
    96f9:	e9 c0 fc ff ff       	jmp    93be <f0+0x245e>
    96fe:	66 90                	xchg   %ax,%ax
    9700:	66 85 c0             	test   %ax,%ax
    9703:	0f 85 2b fc ff ff    	jne    9334 <f0+0x23d4>
    9709:	e9 16 fc ff ff       	jmp    9324 <f0+0x23c4>
    970e:	66 90                	xchg   %ax,%ax
    9710:	66 85 c0             	test   %ax,%ax
    9713:	0f 85 81 fb ff ff    	jne    929a <f0+0x233a>
    9719:	e9 6c fb ff ff       	jmp    928a <f0+0x232a>
    971e:	66 90                	xchg   %ax,%ax
    9720:	66 85 c0             	test   %ax,%ax
    9723:	0f 85 d7 fa ff ff    	jne    9200 <f0+0x22a0>
    9729:	e9 c2 fa ff ff       	jmp    91f0 <f0+0x2290>
    972e:	66 90                	xchg   %ax,%ax
    9730:	66 85 c0             	test   %ax,%ax
    9733:	0f 85 2d fa ff ff    	jne    9166 <f0+0x2206>
    9739:	e9 18 fa ff ff       	jmp    9156 <f0+0x21f6>
    973e:	66 90                	xchg   %ax,%ax
    9740:	66 85 c0             	test   %ax,%ax
    9743:	0f 85 83 f9 ff ff    	jne    90cc <f0+0x216c>
    9749:	e9 6e f9 ff ff       	jmp    90bc <f0+0x215c>
    974e:	66 90                	xchg   %ax,%ax
    9750:	66 85 c0             	test   %ax,%ax
    9753:	0f 85 d9 f8 ff ff    	jne    9032 <f0+0x20d2>
    9759:	e9 c4 f8 ff ff       	jmp    9022 <f0+0x20c2>
    975e:	66 90                	xchg   %ax,%ax
    9760:	66 85 c0             	test   %ax,%ax
    9763:	0f 85 2f f8 ff ff    	jne    8f98 <f0+0x2038>
    9769:	e9 1a f8 ff ff       	jmp    8f88 <f0+0x2028>
    976e:	66 90                	xchg   %ax,%ax
    9770:	66 85 c0             	test   %ax,%ax
    9773:	0f 85 85 f7 ff ff    	jne    8efe <f0+0x1f9e>
    9779:	e9 70 f7 ff ff       	jmp    8eee <f0+0x1f8e>
    977e:	66 90                	xchg   %ax,%ax
    9780:	66 85 c0             	test   %ax,%ax
    9783:	0f 85 db f6 ff ff    	jne    8e64 <f0+0x1f04>
    9789:	e9 c6 f6 ff ff       	jmp    8e54 <f0+0x1ef4>
    978e:	66 90                	xchg   %ax,%ax
    9790:	66 85 c0             	test   %ax,%ax
    9793:	0f 85 31 f6 ff ff    	jne    8dca <f0+0x1e6a>
    9799:	e9 1c f6 ff ff       	jmp    8dba <f0+0x1e5a>
    979e:	66 90                	xchg   %ax,%ax
    97a0:	66 85 c0             	test   %ax,%ax
    97a3:	0f 85 87 f5 ff ff    	jne    8d30 <f0+0x1dd0>
    97a9:	e9 72 f5 ff ff       	jmp    8d20 <f0+0x1dc0>
    97ae:	66 90                	xchg   %ax,%ax
    97b0:	66 85 c0             	test   %ax,%ax
    97b3:	0f 85 dd f4 ff ff    	jne    8c96 <f0+0x1d36>
    97b9:	e9 c8 f4 ff ff       	jmp    8c86 <f0+0x1d26>
    97be:	66 90                	xchg   %ax,%ax
    97c0:	66 85 c0             	test   %ax,%ax
    97c3:	0f 85 33 f4 ff ff    	jne    8bfc <f0+0x1c9c>
    97c9:	e9 1e f4 ff ff       	jmp    8bec <f0+0x1c8c>
    97ce:	4c 89 e7             	mov    %r12,%rdi
    97d1:	e8 ba a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97d6:	e9 1d fd ff ff       	jmp    94f8 <f0+0x2598>
    97db:	4c 89 e7             	mov    %r12,%rdi
    97de:	e8 ad a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97e3:	e9 48 d9 ff ff       	jmp    7130 <f0+0x1d0>
    97e8:	4c 89 e7             	mov    %r12,%rdi
    97eb:	e8 a0 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97f0:	e9 cc d9 ff ff       	jmp    71c1 <f0+0x261>
    97f5:	4c 89 e7             	mov    %r12,%rdi
    97f8:	e8 93 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    97fd:	e9 50 da ff ff       	jmp    7252 <f0+0x2f2>
    9802:	4c 89 e7             	mov    %r12,%rdi
    9805:	e8 86 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    980a:	e9 d4 da ff ff       	jmp    72e3 <f0+0x383>
    980f:	4c 89 e7             	mov    %r12,%rdi
    9812:	e8 79 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9817:	e9 6d e8 ff ff       	jmp    8089 <f0+0x1129>
    981c:	4c 89 e7             	mov    %r12,%rdi
    981f:	e8 6c a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9824:	e9 fa e8 ff ff       	jmp    8123 <f0+0x11c3>
    9829:	4c 89 e7             	mov    %r12,%rdi
    982c:	e8 5f a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9831:	e9 87 e9 ff ff       	jmp    81bd <f0+0x125d>
    9836:	4c 89 e7             	mov    %r12,%rdi
    9839:	e8 52 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    983e:	e9 14 ea ff ff       	jmp    8257 <f0+0x12f7>
    9843:	4c 89 e7             	mov    %r12,%rdi
    9846:	e8 45 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    984b:	e9 a1 ea ff ff       	jmp    82f1 <f0+0x1391>
    9850:	4c 89 e7             	mov    %r12,%rdi
    9853:	e8 38 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9858:	e9 2e eb ff ff       	jmp    838b <f0+0x142b>
    985d:	4c 89 e7             	mov    %r12,%rdi
    9860:	e8 2b a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9865:	e9 bb eb ff ff       	jmp    8425 <f0+0x14c5>
    986a:	4c 89 e7             	mov    %r12,%rdi
    986d:	e8 1e a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9872:	e9 48 ec ff ff       	jmp    84bf <f0+0x155f>
    9877:	4c 89 e7             	mov    %r12,%rdi
    987a:	e8 11 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    987f:	e9 d5 ec ff ff       	jmp    8559 <f0+0x15f9>
    9884:	4c 89 e7             	mov    %r12,%rdi
    9887:	e8 04 a5 ff ff       	call   3d90 <fwp_rc_forget_slot>
    988c:	e9 62 ed ff ff       	jmp    85f3 <f0+0x1693>
    9891:	4c 89 e7             	mov    %r12,%rdi
    9894:	e8 f7 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9899:	e9 ef ed ff ff       	jmp    868d <f0+0x172d>
    989e:	4c 89 e7             	mov    %r12,%rdi
    98a1:	e8 ea a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98a6:	e9 7c ee ff ff       	jmp    8727 <f0+0x17c7>
    98ab:	4c 89 e7             	mov    %r12,%rdi
    98ae:	e8 dd a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98b3:	e9 09 ef ff ff       	jmp    87c1 <f0+0x1861>
    98b8:	4c 89 e7             	mov    %r12,%rdi
    98bb:	e8 d0 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98c0:	e9 96 ef ff ff       	jmp    885b <f0+0x18fb>
    98c5:	4c 89 e7             	mov    %r12,%rdi
    98c8:	e8 c3 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98cd:	e9 23 f0 ff ff       	jmp    88f5 <f0+0x1995>
    98d2:	4c 89 e7             	mov    %r12,%rdi
    98d5:	e8 b6 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98da:	e9 b0 f0 ff ff       	jmp    898f <f0+0x1a2f>
    98df:	4c 89 e7             	mov    %r12,%rdi
    98e2:	e8 a9 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98e7:	e9 3d f1 ff ff       	jmp    8a29 <f0+0x1ac9>
    98ec:	4c 89 e7             	mov    %r12,%rdi
    98ef:	e8 9c a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    98f4:	e9 ca f1 ff ff       	jmp    8ac3 <f0+0x1b63>
    98f9:	4c 89 e7             	mov    %r12,%rdi
    98fc:	e8 8f a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9901:	e9 57 f2 ff ff       	jmp    8b5d <f0+0x1bfd>
    9906:	4c 89 e7             	mov    %r12,%rdi
    9909:	e8 82 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    990e:	e9 e4 f2 ff ff       	jmp    8bf7 <f0+0x1c97>
    9913:	4c 89 e7             	mov    %r12,%rdi
    9916:	e8 75 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    991b:	e9 71 f3 ff ff       	jmp    8c91 <f0+0x1d31>
    9920:	4c 89 e7             	mov    %r12,%rdi
    9923:	e8 68 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9928:	e9 fe f3 ff ff       	jmp    8d2b <f0+0x1dcb>
    992d:	4c 89 e7             	mov    %r12,%rdi
    9930:	e8 5b a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9935:	e9 8b f4 ff ff       	jmp    8dc5 <f0+0x1e65>
    993a:	4c 89 e7             	mov    %r12,%rdi
    993d:	e8 4e a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9942:	e9 18 f5 ff ff       	jmp    8e5f <f0+0x1eff>
    9947:	4c 89 e7             	mov    %r12,%rdi
    994a:	e8 41 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    994f:	e9 a5 f5 ff ff       	jmp    8ef9 <f0+0x1f99>
    9954:	4c 89 e7             	mov    %r12,%rdi
    9957:	e8 34 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    995c:	e9 32 f6 ff ff       	jmp    8f93 <f0+0x2033>
    9961:	4c 89 e7             	mov    %r12,%rdi
    9964:	e8 27 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9969:	e9 bf f6 ff ff       	jmp    902d <f0+0x20cd>
    996e:	4c 89 e7             	mov    %r12,%rdi
    9971:	e8 1a a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9976:	e9 4c f7 ff ff       	jmp    90c7 <f0+0x2167>
    997b:	4c 89 e7             	mov    %r12,%rdi
    997e:	e8 0d a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9983:	e9 d9 f7 ff ff       	jmp    9161 <f0+0x2201>
    9988:	4c 89 e7             	mov    %r12,%rdi
    998b:	e8 00 a4 ff ff       	call   3d90 <fwp_rc_forget_slot>
    9990:	e9 66 f8 ff ff       	jmp    91fb <f0+0x229b>
    9995:	4c 89 e7             	mov    %r12,%rdi
    9998:	e8 f3 a3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    999d:	e9 f3 f8 ff ff       	jmp    9295 <f0+0x2335>
    99a2:	4c 89 e7             	mov    %r12,%rdi
    99a5:	e8 e6 a3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    99aa:	e9 80 f9 ff ff       	jmp    932f <f0+0x23cf>
    99af:	4c 89 e7             	mov    %r12,%rdi
    99b2:	e8 d9 a3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    99b7:	e9 0d fa ff ff       	jmp    93c9 <f0+0x2469>
    99bc:	4c 89 e7             	mov    %r12,%rdi
    99bf:	e8 cc a3 ff ff       	call   3d90 <fwp_rc_forget_slot>
    99c4:	e9 9a fa ff ff       	jmp    9463 <f0+0x2503>
    99c9:	e8 72 8a ff ff       	call   2440 <__stack_chk_fail@plt>
    99ce:	66 90                	xchg   %ax,%ax

00000000000099d0 <fwp_main_thread>:
    99d0:	f3 0f 1e fa          	endbr64
    99d4:	41 54                	push   %r12
    99d6:	55                   	push   %rbp
    99d7:	53                   	push   %rbx
    99d8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    99df:	8b 0d ff 50 01 00    	mov    0x150ff(%rip),%ecx        # 1eae4 <fwp_heap+0x13a4>
    99e5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    99ec:	00 00 
    99ee:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    99f5:	00 
    99f6:	31 c0                	xor    %eax,%eax
    99f8:	85 c9                	test   %ecx,%ecx
    99fa:	0f 84 68 06 00 00    	je     a068 <fwp_main_thread+0x698>
    9a00:	8b 15 e2 50 01 00    	mov    0x150e2(%rip),%edx        # 1eae8 <fwp_heap+0x13a8>
    9a06:	85 d2                	test   %edx,%edx
    9a08:	0f 85 42 06 00 00    	jne    a050 <fwp_main_thread+0x680>
    9a0e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    9a13:	31 f6                	xor    %esi,%esi
    9a15:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    9a1a:	48 c7 05 c3 36 01 00 	movq   $0x40000000,0x136c3(%rip)        # 1d0e8 <fwp_main_stack_size>
    9a21:	00 00 00 40 
    9a25:	48 89 05 c4 36 01 00 	mov    %rax,0x136c4(%rip)        # 1d0f0 <fwp_main_stack_top>
    9a2c:	48 8d 05 ad 36 00 00 	lea    0x36ad(%rip),%rax        # d0e0 <alt.4>
    9a33:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9a38:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    9a3f:	01 00 
    9a41:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    9a48:	00 
    9a49:	e8 32 8c ff ff       	call   2680 <sigaltstack@plt>
    9a4e:	85 c0                	test   %eax,%eax
    9a50:	0f 85 4a 06 00 00    	jne    a0a0 <fwp_main_thread+0x6d0>
    9a56:	31 c0                	xor    %eax,%eax
    9a58:	b9 12 00 00 00       	mov    $0x12,%ecx
    9a5d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9a62:	f3 48 ab             	rep stos %rax,(%rdi)
    9a65:	48 8d 05 d4 91 ff ff 	lea    -0x6e2c(%rip),%rax        # 2c40 <fwp_segv>
    9a6c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    9a71:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    9a78:	04 00 00 08 
    9a7c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9a81:	e8 ca 8a ff ff       	call   2550 <sigemptyset@plt>
    9a86:	85 c0                	test   %eax,%eax
    9a88:	0f 85 12 06 00 00    	jne    a0a0 <fwp_main_thread+0x6d0>
    9a8e:	31 d2                	xor    %edx,%edx
    9a90:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9a95:	bf 0b 00 00 00       	mov    $0xb,%edi
    9a9a:	e8 41 89 ff ff       	call   23e0 <sigaction@plt>
    9a9f:	85 c0                	test   %eax,%eax
    9aa1:	0f 85 f9 05 00 00    	jne    a0a0 <fwp_main_thread+0x6d0>
    9aa7:	31 d2                	xor    %edx,%edx
    9aa9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    9aae:	bf 07 00 00 00       	mov    $0x7,%edi
    9ab3:	e8 28 89 ff ff       	call   23e0 <sigaction@plt>
    9ab8:	85 c0                	test   %eax,%eax
    9aba:	0f 85 e0 05 00 00    	jne    a0a0 <fwp_main_thread+0x6d0>
    9ac0:	8b 05 02 36 00 00    	mov    0x3602(%rip),%eax        # d0c8 <st.2>
    9ac6:	85 c0                	test   %eax,%eax
    9ac8:	0f 84 62 05 00 00    	je     a030 <fwp_main_thread+0x660>
    9ace:	48 8b 2d 4b 3c 01 00 	mov    0x13c4b(%rip),%rbp        # 1d720 <fwp_cur>
    9ad5:	48 85 ed             	test   %rbp,%rbp
    9ad8:	0f 84 72 03 00 00    	je     9e50 <fwp_main_thread+0x480>
    9ade:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9ae3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9ae7:	48 89 eb             	mov    %rbp,%rbx
    9aea:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9aef:	0f 84 41 01 00 00    	je     9c36 <fwp_main_thread+0x266>
    9af5:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9afa:	0f 84 80 02 00 00    	je     9d80 <fwp_main_thread+0x3b0>
    9b00:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9b04:	0f 84 66 02 00 00    	je     9d70 <fwp_main_thread+0x3a0>
    9b0a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9b0e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9b12:	0f 85 e8 02 00 00    	jne    9e00 <fwp_main_thread+0x430>
    9b18:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9b1c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9b23:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9b27:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9b2e:	00 00 00 00 
    9b32:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9b39:	48 85 d2             	test   %rdx,%rdx
    9b3c:	74 07                	je     9b45 <fwp_main_thread+0x175>
    9b3e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9b45:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9b49:	48 85 c0             	test   %rax,%rax
    9b4c:	74 34                	je     9b82 <fwp_main_thread+0x1b2>
    9b4e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9b52:	48 8b 05 9f 3b 01 00 	mov    0x13b9f(%rip),%rax        # 1d6f8 <fwp_timers>
    9b59:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9b5d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9b64:	00 00 00 00 
    9b68:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9b6f:	48 85 c0             	test   %rax,%rax
    9b72:	74 07                	je     9b7b <fwp_main_thread+0x1ab>
    9b74:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9b7b:	48 89 1d 76 3b 01 00 	mov    %rbx,0x13b76(%rip)        # 1d6f8 <fwp_timers>
    9b82:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9b86:	e8 c5 af ff ff       	call   4b50 <fwp_block>
    9b8b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9b92:	48 85 c9             	test   %rcx,%rcx
    9b95:	74 47                	je     9bde <fwp_main_thread+0x20e>
    9b97:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9b9e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9ba5:	48 85 d2             	test   %rdx,%rdx
    9ba8:	0f 84 92 02 00 00    	je     9e40 <fwp_main_thread+0x470>
    9bae:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9bb5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9bbc:	48 85 c0             	test   %rax,%rax
    9bbf:	74 07                	je     9bc8 <fwp_main_thread+0x1f8>
    9bc1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9bc8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9bcf:	00 00 00 00 
    9bd3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9bd7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    9bde:	48 8b 0d 3b 3b 01 00 	mov    0x13b3b(%rip),%rcx        # 1d720 <fwp_cur>
    9be5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9be9:	0f 84 01 02 00 00    	je     9df0 <fwp_main_thread+0x420>
    9bef:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9bf6:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9bfd:	48 85 d2             	test   %rdx,%rdx
    9c00:	0f 84 fa 03 00 00    	je     a000 <fwp_main_thread+0x630>
    9c06:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9c0d:	48 85 c0             	test   %rax,%rax
    9c10:	74 07                	je     9c19 <fwp_main_thread+0x249>
    9c12:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9c19:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c1d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9c21:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    9c28:	48 89 cb             	mov    %rcx,%rbx
    9c2b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9c30:	0f 85 bf fe ff ff    	jne    9af5 <fwp_main_thread+0x125>
    9c36:	48 83 3d 72 57 01 00 	cmpq   $0x0,0x15772(%rip)        # 1f3b0 <fwp_state_len>
    9c3d:	00 
    9c3e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9c42:	0f 84 ba 00 00 00    	je     9d02 <fwp_main_thread+0x332>
    9c48:	48 39 1d c9 3a 01 00 	cmp    %rbx,0x13ac9(%rip)        # 1d718 <fwp_root>
    9c4f:	c7 05 87 34 01 00 00 	movl   $0x0,0x13487(%rip)        # 1d0e0 <fwp_exit_code>
    9c56:	00 00 00 
    9c59:	0f 85 5f 04 00 00    	jne    a0be <fwp_main_thread+0x6ee>
    9c5f:	48 85 db             	test   %rbx,%rbx
    9c62:	0f 84 0e 02 00 00    	je     9e76 <fwp_main_thread+0x4a6>
    9c68:	48 8b 15 79 3a 01 00 	mov    0x13a79(%rip),%rdx        # 1d6e8 <fwp_tasks_active>
    9c6f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9c73:	48 85 d2             	test   %rdx,%rdx
    9c76:	0f 84 fa 01 00 00    	je     9e76 <fwp_main_thread+0x4a6>
    9c7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c80:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9c84:	75 08                	jne    9c8e <fwp_main_thread+0x2be>
    9c86:	48 89 d7             	mov    %rdx,%rdi
    9c89:	e8 32 93 ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    9c8e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9c95:	48 85 d2             	test   %rdx,%rdx
    9c98:	75 e6                	jne    9c80 <fwp_main_thread+0x2b0>
    9c9a:	eb 31                	jmp    9ccd <fwp_main_thread+0x2fd>
    9c9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9ca0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9ca7:	48 89 1d 52 3a 01 00 	mov    %rbx,0x13a52(%rip)        # 1d700 <fwp_ready_tail>
    9cae:	e8 9d ae ff ff       	call   4b50 <fwp_block>
    9cb3:	e8 98 ac ff ff       	call   4950 <fwp_free_zombie>
    9cb8:	48 83 3d 28 3a 01 00 	cmpq   $0x0,0x13a28(%rip)        # 1d6e8 <fwp_tasks_active>
    9cbf:	00 
    9cc0:	0f 84 b0 01 00 00    	je     9e76 <fwp_main_thread+0x4a6>
    9cc6:	48 8b 1d 4b 3a 01 00 	mov    0x13a4b(%rip),%rbx        # 1d718 <fwp_root>
    9ccd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9cd1:	75 db                	jne    9cae <fwp_main_thread+0x2de>
    9cd3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9cd7:	75 d5                	jne    9cae <fwp_main_thread+0x2de>
    9cd9:	48 8b 05 20 3a 01 00 	mov    0x13a20(%rip),%rax        # 1d700 <fwp_ready_tail>
    9ce0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9ce4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9ceb:	00 00 00 00 
    9cef:	48 85 c0             	test   %rax,%rax
    9cf2:	75 ac                	jne    9ca0 <fwp_main_thread+0x2d0>
    9cf4:	48 89 1d 0d 3a 01 00 	mov    %rbx,0x13a0d(%rip)        # 1d708 <fwp_ready_head>
    9cfb:	eb aa                	jmp    9ca7 <fwp_main_thread+0x2d7>
    9cfd:	0f 1f 00             	nopl   (%rax)
    9d00:	31 db                	xor    %ebx,%ebx
    9d02:	48 83 3d 96 56 01 00 	cmpq   $0x0,0x15696(%rip)        # 1f3a0 <fwp_state_owners>
    9d09:	00 
    9d0a:	0f 85 38 ff ff ff    	jne    9c48 <fwp_main_thread+0x278>
    9d10:	48 8b 3d a1 56 01 00 	mov    0x156a1(%rip),%rdi        # 1f3b8 <fwp_state>
    9d17:	e8 b4 a2 ff ff       	call   3fd0 <fwp_mem_free>
    9d1c:	48 c7 05 91 56 01 00 	movq   $0x0,0x15691(%rip)        # 1f3b8 <fwp_state>
    9d23:	00 00 00 00 
    9d27:	48 c7 05 76 56 01 00 	movq   $0x0,0x15676(%rip)        # 1f3a8 <fwp_state_cap>
    9d2e:	00 00 00 00 
    9d32:	48 85 db             	test   %rbx,%rbx
    9d35:	0f 84 46 03 00 00    	je     a081 <fwp_main_thread+0x6b1>
    9d3b:	48 39 1d d6 39 01 00 	cmp    %rbx,0x139d6(%rip)        # 1d718 <fwp_root>
    9d42:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9d49:	00 00 00 00 
    9d4d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9d54:	00 00 00 00 
    9d58:	c7 05 7e 33 01 00 00 	movl   $0x0,0x1337e(%rip)        # 1d0e0 <fwp_exit_code>
    9d5f:	00 00 00 
    9d62:	0f 84 00 ff ff ff    	je     9c68 <fwp_main_thread+0x298>
    9d68:	e9 a3 89 ff ff       	jmp    2710 <fwp_main_thread.cold>
    9d6d:	0f 1f 00             	nopl   (%rax)
    9d70:	e8 6b 93 ff ff       	call   30e0 <fwp_now_ns>
    9d75:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9d79:	0f 8d 91 02 00 00    	jge    a010 <fwp_main_thread+0x640>
    9d7f:	90                   	nop
    9d80:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9d84:	0f 85 80 fd ff ff    	jne    9b0a <fwp_main_thread+0x13a>
    9d8a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9d8e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9d92:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9d96:	0f 85 80 fd ff ff    	jne    9b1c <fwp_main_thread+0x14c>
    9d9c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9da0:	48 85 c9             	test   %rcx,%rcx
    9da3:	0f 84 73 fd ff ff    	je     9b1c <fwp_main_thread+0x14c>
    9da9:	48 85 c0             	test   %rax,%rax
    9dac:	0f 84 ff 02 00 00    	je     a0b1 <fwp_main_thread+0x6e1>
    9db2:	48 39 c8             	cmp    %rcx,%rax
    9db5:	48 0f 4f c1          	cmovg  %rcx,%rax
    9db9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9dc0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9dc4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9dcb:	00 00 00 00 
    9dcf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9dd6:	48 85 d2             	test   %rdx,%rdx
    9dd9:	74 07                	je     9de2 <fwp_main_thread+0x412>
    9ddb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9de2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9de6:	e9 63 fd ff ff       	jmp    9b4e <fwp_main_thread+0x17e>
    9deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9df0:	48 89 cb             	mov    %rcx,%rbx
    9df3:	e9 f2 fc ff ff       	jmp    9aea <fwp_main_thread+0x11a>
    9df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9dff:	00 
    9e00:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9e04:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9e0b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9e12:	00 00 00 00 
    9e16:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9e1d:	48 85 c0             	test   %rax,%rax
    9e20:	0f 84 52 02 00 00    	je     a078 <fwp_main_thread+0x6a8>
    9e26:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9e2d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9e31:	e9 4c fd ff ff       	jmp    9b82 <fwp_main_thread+0x1b2>
    9e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e3d:	00 00 00 
    9e40:	48 89 01             	mov    %rax,(%rcx)
    9e43:	e9 74 fd ff ff       	jmp    9bbc <fwp_main_thread+0x1ec>
    9e48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e4f:	00 
    9e50:	48 83 3d 58 55 01 00 	cmpq   $0x0,0x15558(%rip)        # 1f3b0 <fwp_state_len>
    9e57:	00 
    9e58:	0f 84 a2 fe ff ff    	je     9d00 <fwp_main_thread+0x330>
    9e5e:	48 83 3d b2 38 01 00 	cmpq   $0x0,0x138b2(%rip)        # 1d718 <fwp_root>
    9e65:	00 
    9e66:	c7 05 70 32 01 00 00 	movl   $0x0,0x13270(%rip)        # 1d0e0 <fwp_exit_code>
    9e6d:	00 00 00 
    9e70:	0f 85 43 02 00 00    	jne    a0b9 <fwp_main_thread+0x6e9>
    9e76:	e8 d5 aa ff ff       	call   4950 <fwp_free_zombie>
    9e7b:	48 83 3d 85 38 01 00 	cmpq   $0x0,0x13885(%rip)        # 1d708 <fwp_ready_head>
    9e82:	00 
    9e83:	0f 85 87 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9e89:	48 83 3d 67 38 01 00 	cmpq   $0x0,0x13867(%rip)        # 1d6f8 <fwp_timers>
    9e90:	00 
    9e91:	0f 85 79 88 ff ff    	jne    2710 <fwp_main_thread.cold>
    9e97:	8b 1d 5f 32 01 00    	mov    0x1325f(%rip),%ebx        # 1d0fc <fwp_stack_pool_n>
    9e9d:	85 db                	test   %ebx,%ebx
    9e9f:	74 36                	je     9ed7 <fwp_main_thread+0x507>
    9ea1:	83 eb 01             	sub    $0x1,%ebx
    9ea4:	48 8d 05 55 32 01 00 	lea    0x13255(%rip),%rax        # 1d100 <fwp_stack_pool>
    9eab:	48 63 d3             	movslq %ebx,%rdx
    9eae:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    9eb2:	eb 07                	jmp    9ebb <fwp_main_thread+0x4eb>
    9eb4:	0f 1f 40 00          	nopl   0x0(%rax)
    9eb8:	83 eb 01             	sub    $0x1,%ebx
    9ebb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9ebf:	be 00 00 00 10       	mov    $0x10000000,%esi
    9ec4:	89 1d 32 32 01 00    	mov    %ebx,0x13232(%rip)        # 1d0fc <fwp_stack_pool_n>
    9eca:	48 83 ed 08          	sub    $0x8,%rbp
    9ece:	e8 dd 86 ff ff       	call   25b0 <munmap@plt>
    9ed3:	85 db                	test   %ebx,%ebx
    9ed5:	75 e1                	jne    9eb8 <fwp_main_thread+0x4e8>
    9ed7:	8b 3d 83 31 00 00    	mov    0x3183(%rip),%edi        # d060 <fwp_epfd>
    9edd:	85 ff                	test   %edi,%edi
    9edf:	78 05                	js     9ee6 <fwp_main_thread+0x516>
    9ee1:	e8 ca 85 ff ff       	call   24b0 <close@plt>
    9ee6:	4c 8b 25 13 34 01 00 	mov    0x13413(%rip),%r12        # 1d300 <fwp_nfdws>
    9eed:	48 8b 2d 14 34 01 00 	mov    0x13414(%rip),%rbp        # 1d308 <fwp_fdws>
    9ef4:	31 db                	xor    %ebx,%ebx
    9ef6:	c7 05 60 31 00 00 ff 	movl   $0xffffffff,0x3160(%rip)        # d060 <fwp_epfd>
    9efd:	ff ff ff 
    9f00:	4d 85 e4             	test   %r12,%r12
    9f03:	74 38                	je     9f3d <fwp_main_thread+0x56d>
    9f05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f0c:	00 00 00 00 
    9f10:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9f15:	48 85 ff             	test   %rdi,%rdi
    9f18:	74 1a                	je     9f34 <fwp_main_thread+0x564>
    9f1a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9f1e:	0f 85 ec 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f24:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9f29:	0f 85 e1 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f2f:	e8 9c a0 ff ff       	call   3fd0 <fwp_mem_free>
    9f34:	48 83 c3 01          	add    $0x1,%rbx
    9f38:	4c 39 e3             	cmp    %r12,%rbx
    9f3b:	75 d3                	jne    9f10 <fwp_main_thread+0x540>
    9f3d:	48 89 ef             	mov    %rbp,%rdi
    9f40:	e8 8b a0 ff ff       	call   3fd0 <fwp_mem_free>
    9f45:	48 8b 15 cc 37 01 00 	mov    0x137cc(%rip),%rdx        # 1d718 <fwp_root>
    9f4c:	48 c7 05 b1 33 01 00 	movq   $0x0,0x133b1(%rip)        # 1d308 <fwp_fdws>
    9f53:	00 00 00 00 
    9f57:	48 c7 05 9e 33 01 00 	movq   $0x0,0x1339e(%rip)        # 1d300 <fwp_nfdws>
    9f5e:	00 00 00 00 
    9f62:	48 85 d2             	test   %rdx,%rdx
    9f65:	74 4e                	je     9fb5 <fwp_main_thread+0x5e5>
    9f67:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9f6c:	0f 85 9e 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f72:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9f79:	00 
    9f7a:	0f 85 90 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f80:	48 83 3d 28 54 01 00 	cmpq   $0x0,0x15428(%rip)        # 1f3b0 <fwp_state_len>
    9f87:	00 
    9f88:	0f 85 82 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f8e:	48 83 3d 0a 54 01 00 	cmpq   $0x0,0x1540a(%rip)        # 1f3a0 <fwp_state_owners>
    9f95:	00 
    9f96:	0f 85 74 87 ff ff    	jne    2710 <fwp_main_thread.cold>
    9f9c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9fa1:	31 c0                	xor    %eax,%eax
    9fa3:	48 8d 3d 76 33 01 00 	lea    0x13376(%rip),%rdi        # 1d320 <fwp_root_context>
    9faa:	f3 48 ab             	rep stos %rax,(%rdi)
    9fad:	48 89 d7             	mov    %rdx,%rdi
    9fb0:	e8 1b a0 ff ff       	call   3fd0 <fwp_mem_free>
    9fb5:	48 8b 3d c4 30 00 00 	mov    0x30c4(%rip),%rdi        # d080 <stdout@GLIBC_2.2.5>
    9fbc:	48 c7 05 59 37 01 00 	movq   $0x0,0x13759(%rip)        # 1d720 <fwp_cur>
    9fc3:	00 00 00 00 
    9fc7:	48 c7 05 46 37 01 00 	movq   $0x0,0x13746(%rip)        # 1d718 <fwp_root>
    9fce:	00 00 00 00 
    9fd2:	e8 b9 85 ff ff       	call   2590 <fflush@plt>
    9fd7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    9fde:	00 
    9fdf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fe6:	00 00 
    9fe8:	0f 85 be 00 00 00    	jne    a0ac <fwp_main_thread+0x6dc>
    9fee:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    9ff5:	31 c0                	xor    %eax,%eax
    9ff7:	5b                   	pop    %rbx
    9ff8:	5d                   	pop    %rbp
    9ff9:	41 5c                	pop    %r12
    9ffb:	c3                   	ret
    9ffc:	0f 1f 40 00          	nopl   0x0(%rax)
    a000:	48 89 05 f1 36 01 00 	mov    %rax,0x136f1(%rip)        # 1d6f8 <fwp_timers>
    a007:	e9 01 fc ff ff       	jmp    9c0d <fwp_main_thread+0x23d>
    a00c:	0f 1f 40 00          	nopl   0x0(%rax)
    a010:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a014:	0f 85 66 fd ff ff    	jne    9d80 <fwp_main_thread+0x3b0>
    a01a:	48 89 ef             	mov    %rbp,%rdi
    a01d:	e8 9e 8f ff ff       	call   2fc0 <fwp_cancel_tree.part.0>
    a022:	e9 59 fd ff ff       	jmp    9d80 <fwp_main_thread+0x3b0>
    a027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a02e:	00 00 
    a030:	e8 2b cf ff ff       	call   6f60 <f0>
    a035:	48 c7 05 80 30 00 00 	movq   $0x0,0x3080(%rip)        # d0c0 <v.1>
    a03c:	00 00 00 00 
    a040:	c7 05 7e 30 00 00 01 	movl   $0x1,0x307e(%rip)        # d0c8 <st.2>
    a047:	00 00 00 
    a04a:	e9 7f fa ff ff       	jmp    9ace <fwp_main_thread+0xfe>
    a04f:	90                   	nop
    a050:	48 8d 3d 89 96 ff ff 	lea    -0x6977(%rip),%rdi        # 36e0 <fwp_heap_report>
    a057:	e8 84 02 00 00       	call   a2e0 <atexit>
    a05c:	e9 ad f9 ff ff       	jmp    9a0e <fwp_main_thread+0x3e>
    a061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a068:	e8 83 97 ff ff       	call   37f0 <fwp_heap_init>
    a06d:	e9 8e f9 ff ff       	jmp    9a00 <fwp_main_thread+0x30>
    a072:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a078:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a07c:	e9 01 fb ff ff       	jmp    9b82 <fwp_main_thread+0x1b2>
    a081:	48 83 3d 8f 36 01 00 	cmpq   $0x0,0x1368f(%rip)        # 1d718 <fwp_root>
    a088:	00 
    a089:	c7 05 4d 30 01 00 00 	movl   $0x0,0x1304d(%rip)        # 1d0e0 <fwp_exit_code>
    a090:	00 00 00 
    a093:	0f 84 dd fd ff ff    	je     9e76 <fwp_main_thread+0x4a6>
    a099:	e9 72 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a09e:	66 90                	xchg   %ax,%ax
    a0a0:	48 8d 3d 59 12 00 00 	lea    0x1259(%rip),%rdi        # b300 <_IO_stdin_used+0x300>
    a0a7:	e8 04 90 ff ff       	call   30b0 <fwp_trap>
    a0ac:	e8 8f 83 ff ff       	call   2440 <__stack_chk_fail@plt>
    a0b1:	48 89 c8             	mov    %rcx,%rax
    a0b4:	e9 00 fd ff ff       	jmp    9db9 <fwp_main_thread+0x3e9>
    a0b9:	e9 52 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a0be:	e9 4d 86 ff ff       	jmp    2710 <fwp_main_thread.cold>
    a0c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0ca:	00 00 00 
    a0cd:	0f 1f 00             	nopl   (%rax)

000000000000a0d0 <__divmodti4>:
    a0d0:	f3 0f 1e fa          	endbr64
    a0d4:	55                   	push   %rbp
    a0d5:	49 89 f1             	mov    %rsi,%r9
    a0d8:	49 89 d2             	mov    %rdx,%r10
    a0db:	48 89 fe             	mov    %rdi,%rsi
    a0de:	49 89 cb             	mov    %rcx,%r11
    a0e1:	48 89 e5             	mov    %rsp,%rbp
    a0e4:	41 57                	push   %r15
    a0e6:	41 56                	push   %r14
    a0e8:	41 55                	push   %r13
    a0ea:	41 54                	push   %r12
    a0ec:	53                   	push   %rbx
    a0ed:	4c 89 c3             	mov    %r8,%rbx
    a0f0:	45 31 c0             	xor    %r8d,%r8d
    a0f3:	4d 85 c9             	test   %r9,%r9
    a0f6:	79 12                	jns    a10a <__divmodti4+0x3a>
    a0f8:	31 ff                	xor    %edi,%edi
    a0fa:	48 f7 de             	neg    %rsi
    a0fd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a104:	4c 19 cf             	sbb    %r9,%rdi
    a107:	49 89 f9             	mov    %rdi,%r9
    a10a:	4c 89 d8             	mov    %r11,%rax
    a10d:	4d 85 db             	test   %r11,%r11
    a110:	0f 88 1a 01 00 00    	js     a230 <__divmodti4+0x160>
    a116:	4c 89 d9             	mov    %r11,%rcx
    a119:	49 89 f3             	mov    %rsi,%r11
    a11c:	75 62                	jne    a180 <__divmodti4+0xb0>
    a11e:	4d 89 c4             	mov    %r8,%r12
    a121:	4d 39 d1             	cmp    %r10,%r9
    a124:	0f 83 46 01 00 00    	jae    a270 <__divmodti4+0x1a0>
    a12a:	4c 89 d8             	mov    %r11,%rax
    a12d:	4c 89 ca             	mov    %r9,%rdx
    a130:	49 f7 f2             	div    %r10
    a133:	49 89 c3             	mov    %rax,%r11
    a136:	31 c0                	xor    %eax,%eax
    a138:	48 89 d6             	mov    %rdx,%rsi
    a13b:	31 ff                	xor    %edi,%edi
    a13d:	4c 89 d9             	mov    %r11,%rcx
    a140:	48 89 c2             	mov    %rax,%rdx
    a143:	48 89 c8             	mov    %rcx,%rax
    a146:	4d 85 e4             	test   %r12,%r12
    a149:	74 0a                	je     a155 <__divmodti4+0x85>
    a14b:	48 f7 d8             	neg    %rax
    a14e:	48 83 d2 00          	adc    $0x0,%rdx
    a152:	48 f7 da             	neg    %rdx
    a155:	4d 85 c0             	test   %r8,%r8
    a158:	74 0a                	je     a164 <__divmodti4+0x94>
    a15a:	48 f7 de             	neg    %rsi
    a15d:	48 83 d7 00          	adc    $0x0,%rdi
    a161:	48 f7 df             	neg    %rdi
    a164:	48 89 33             	mov    %rsi,(%rbx)
    a167:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a16b:	5b                   	pop    %rbx
    a16c:	41 5c                	pop    %r12
    a16e:	41 5d                	pop    %r13
    a170:	41 5e                	pop    %r14
    a172:	41 5f                	pop    %r15
    a174:	5d                   	pop    %rbp
    a175:	c3                   	ret
    a176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a17d:	00 00 00 
    a180:	4d 89 c4             	mov    %r8,%r12
    a183:	49 39 c1             	cmp    %rax,%r9
    a186:	0f 82 ce 00 00 00    	jb     a25a <__divmodti4+0x18a>
    a18c:	31 ff                	xor    %edi,%edi
    a18e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a193:	48 63 c7             	movslq %edi,%rax
    a196:	be 40 00 00 00       	mov    $0x40,%esi
    a19b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a1a0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a1a5:	48 29 c6             	sub    %rax,%rsi
    a1a8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a1ad:	48 09 c8             	or     %rcx,%rax
    a1b0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a1b5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a1ba:	49 89 c6             	mov    %rax,%r14
    a1bd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a1c1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a1c6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a1cb:	49 09 c1             	or     %rax,%r9
    a1ce:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a1d2:	4c 89 c8             	mov    %r9,%rax
    a1d5:	49 f7 f6             	div    %r14
    a1d8:	48 89 d1             	mov    %rdx,%rcx
    a1db:	49 89 c3             	mov    %rax,%r11
    a1de:	49 89 c1             	mov    %rax,%r9
    a1e1:	49 f7 e2             	mul    %r10
    a1e4:	49 89 c6             	mov    %rax,%r14
    a1e7:	49 89 d2             	mov    %rdx,%r10
    a1ea:	48 39 d1             	cmp    %rdx,%rcx
    a1ed:	72 07                	jb     a1f6 <__divmodti4+0x126>
    a1ef:	75 17                	jne    a208 <__divmodti4+0x138>
    a1f1:	49 39 c7             	cmp    %rax,%r15
    a1f4:	73 12                	jae    a208 <__divmodti4+0x138>
    a1f6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a1fa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a1fe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a202:	49 89 d2             	mov    %rdx,%r10
    a205:	49 89 c6             	mov    %rax,%r14
    a208:	4c 89 f8             	mov    %r15,%rax
    a20b:	4c 29 f0             	sub    %r14,%rax
    a20e:	4c 19 d1             	sbb    %r10,%rcx
    a211:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a216:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a21b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a220:	48 09 c6             	or     %rax,%rsi
    a223:	48 89 cf             	mov    %rcx,%rdi
    a226:	31 c0                	xor    %eax,%eax
    a228:	4c 89 c9             	mov    %r9,%rcx
    a22b:	e9 10 ff ff ff       	jmp    a140 <__divmodti4+0x70>
    a230:	4c 89 d0             	mov    %r10,%rax
    a233:	4c 89 da             	mov    %r11,%rdx
    a236:	4d 89 c4             	mov    %r8,%r12
    a239:	49 89 f3             	mov    %rsi,%r11
    a23c:	48 f7 d8             	neg    %rax
    a23f:	49 f7 d4             	not    %r12
    a242:	48 83 d2 00          	adc    $0x0,%rdx
    a246:	49 89 c2             	mov    %rax,%r10
    a249:	48 f7 da             	neg    %rdx
    a24c:	48 89 d1             	mov    %rdx,%rcx
    a24f:	0f 84 cc fe ff ff    	je     a121 <__divmodti4+0x51>
    a255:	49 39 d1             	cmp    %rdx,%r9
    a258:	73 46                	jae    a2a0 <__divmodti4+0x1d0>
    a25a:	4c 89 cf             	mov    %r9,%rdi
    a25d:	31 c0                	xor    %eax,%eax
    a25f:	31 c9                	xor    %ecx,%ecx
    a261:	e9 da fe ff ff       	jmp    a140 <__divmodti4+0x70>
    a266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a26d:	00 00 00 
    a270:	4d 85 d2             	test   %r10,%r10
    a273:	75 0d                	jne    a282 <__divmodti4+0x1b2>
    a275:	b8 01 00 00 00       	mov    $0x1,%eax
    a27a:	31 d2                	xor    %edx,%edx
    a27c:	49 f7 f2             	div    %r10
    a27f:	49 89 c2             	mov    %rax,%r10
    a282:	4c 89 c8             	mov    %r9,%rax
    a285:	31 d2                	xor    %edx,%edx
    a287:	49 f7 f2             	div    %r10
    a28a:	49 89 c1             	mov    %rax,%r9
    a28d:	4c 89 d8             	mov    %r11,%rax
    a290:	49 f7 f2             	div    %r10
    a293:	49 89 c3             	mov    %rax,%r11
    a296:	4c 89 c8             	mov    %r9,%rax
    a299:	e9 9a fe ff ff       	jmp    a138 <__divmodti4+0x68>
    a29e:	66 90                	xchg   %ax,%ax
    a2a0:	45 31 f6             	xor    %r14d,%r14d
    a2a3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a2a8:	44 89 f7             	mov    %r14d,%edi
    a2ab:	45 85 f6             	test   %r14d,%r14d
    a2ae:	0f 85 df fe ff ff    	jne    a193 <__divmodti4+0xc3>
    a2b4:	4c 39 ca             	cmp    %r9,%rdx
    a2b7:	72 17                	jb     a2d0 <__divmodti4+0x200>
    a2b9:	31 c9                	xor    %ecx,%ecx
    a2bb:	48 39 c6             	cmp    %rax,%rsi
    a2be:	73 10                	jae    a2d0 <__divmodti4+0x200>
    a2c0:	4c 89 cf             	mov    %r9,%rdi
    a2c3:	31 c0                	xor    %eax,%eax
    a2c5:	e9 76 fe ff ff       	jmp    a140 <__divmodti4+0x70>
    a2ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2d0:	4c 89 de             	mov    %r11,%rsi
    a2d3:	b9 01 00 00 00       	mov    $0x1,%ecx
    a2d8:	48 29 c6             	sub    %rax,%rsi
    a2db:	49 19 d1             	sbb    %rdx,%r9
    a2de:	eb e0                	jmp    a2c0 <__divmodti4+0x1f0>

000000000000a2e0 <atexit>:
    a2e0:	f3 0f 1e fa          	endbr64
    a2e4:	48 8b 15 1d 2d 00 00 	mov    0x2d1d(%rip),%rdx        # d008 <__dso_handle>
    a2eb:	31 f6                	xor    %esi,%esi
    a2ed:	e9 2e 83 ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a2f4 <_fini>:
    a2f4:	f3 0f 1e fa          	endbr64
    a2f8:	48 83 ec 08          	sub    $0x8,%rsp
    a2fc:	48 83 c4 08          	add    $0x8,%rsp
    a300:	c3                   	ret
