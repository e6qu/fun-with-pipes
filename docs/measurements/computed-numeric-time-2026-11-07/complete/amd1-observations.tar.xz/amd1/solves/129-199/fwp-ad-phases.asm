
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 fa fd 00 00    	push   0xfdfa(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 fc fd 00 00    	jmp    *0xfdfc(%rip)        # 12e28 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 76 fc 00 00    	jmp    *0xfc76(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 a6 fa 00 00    	jmp    *0xfaa6(%rip)        # 12e30 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 9e fa 00 00    	jmp    *0xfa9e(%rip)        # 12e38 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 96 fa 00 00    	jmp    *0xfa96(%rip)        # 12e40 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e48 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e50 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e58 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e60 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e68 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e70 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e78 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e80 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e88 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e90 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e98 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12ea0 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12ea8 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12eb0 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12eb8 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ec0 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ec8 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12ed0 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12ed8 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ee0 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ee8 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ef0 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ef8 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12f00 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12f08 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12f10 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12f18 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f20 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f28 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f30 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f38 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f40 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f48 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f50 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f58 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d 1d ba 00 00 	lea    0xba1d(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    36d7:	4c 8d 05 1a ba 00 00 	lea    0xba1a(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 aa 0c 00 00       	call   43b0 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_hof0.constprop.0.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>
    3710:	e8 ab ff ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>

0000000000003715 <fwp_main_thread.cold>:
    3715:	e8 96 fc ff ff       	call   33b0 <abort@plt>

000000000000371a <main.cold>:
    371a:	e8 91 fc ff ff       	call   33b0 <abort@plt>
    371f:	90                   	nop

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 e1 db 00 00 	lea    0xdbe1(%rip),%rax        # 11320 <fwp_fn_table>
    373f:	48 89 05 d2 1c 02 00 	mov    %rax,0x21cd2(%rip)        # 25418 <fwp_fns>
    3746:	48 8b 05 d3 f8 00 00 	mov    0xf8d3(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 cc 1c 02 00 	mov    %rax,0x21ccc(%rip)        # 25420 <fwp_prog_out>
    3754:	e8 c7 0d 00 00       	call   4520 <fwp_now_ns>
    3759:	48 8d 3d f7 ba 00 00 	lea    0xbaf7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 f8 00 00 	mov    0xf858(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 8f a6 00 00 	lea    0xa68f(%rip),%rdx        # deb0 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 e0 fe ff ff    	jne    371a <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 c4 fe ff ff    	jne    371a <main.cold>
    3856:	48 8b 3d c3 f7 00 00 	mov    0xf7c3(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 f8 01 00    	mov    0x1f818(%rip),%eax        # 23080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d a7 b9 00 00 	lea    0xb9a7(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38b9:	e8 f2 0a 00 00       	call   43b0 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d c6 c1 00 00 	lea    0xc1c6(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    38ca:	e8 e1 0a 00 00       	call   43b0 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 39 fe ff ff    	jne    371a <main.cold>
    38e1:	48 8d 3d 80 c1 00 00 	lea    0xc180(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    38e8:	e8 c3 0a 00 00       	call   43b0 <fwp_trap>
    38ed:	48 8d 3d 44 c1 00 00 	lea    0xc144(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    38f4:	e8 b7 0a 00 00       	call   43b0 <fwp_trap>
    38f9:	48 8d 3d 10 c1 00 00 	lea    0xc110(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3900:	e8 ab 0a 00 00       	call   43b0 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 9b f6 00 00    	call   *0xf69b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d9 f6 00 00 	lea    0xf6d9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3947:	48 8d 05 d2 f6 00 00 	lea    0xf6d2(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 7e f6 00 00 	mov    0xf67e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a9 f6 00 00 	lea    0xf6a9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3977:	48 8d 35 a2 f6 00 00 	lea    0xf6a2(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 4d f6 00 00 	mov    0xf64d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d f6 00 00 00 	cmpb   $0x0,0xf68d(%rip)        # 13048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 2a f6 00 00 	cmpq   $0x0,0xf62a(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 f6 00 00 	mov    0xf636(%rip),%rdi        # 13008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 f6 00 00 01 	movb   $0x1,0xf665(%rip)        # 13048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_tape_unlink_scope>:
    3bc0:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3bc4:	48 85 d2             	test   %rdx,%rdx
    3bc7:	74 3e                	je     3c07 <fwp_tape_unlink_scope+0x47>
    3bc9:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3bcc:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3bd0:	85 c9                	test   %ecx,%ecx
    3bd2:	78 3c                	js     3c10 <fwp_tape_unlink_scope+0x50>
    3bd4:	48 63 d1             	movslq %ecx,%rdx
    3bd7:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3bdb:	48 03 15 fe f4 01 00 	add    0x1f4fe(%rip),%rdx        # 230e0 <fwp_tapes>
    3be2:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3be5:	85 c0                	test   %eax,%eax
    3be7:	78 0e                	js     3bf7 <fwp_tape_unlink_scope+0x37>
    3be9:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3bed:	48 03 05 ec f4 01 00 	add    0x1f4ec(%rip),%rax        # 230e0 <fwp_tapes>
    3bf4:	89 48 48             	mov    %ecx,0x48(%rax)
    3bf7:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3bfe:	00 
    3bff:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c06:	ff 
    3c07:	c3                   	ret
    3c08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c0f:	00 
    3c10:	89 02                	mov    %eax,(%rdx)
    3c12:	eb d1                	jmp    3be5 <fwp_tape_unlink_scope+0x25>
    3c14:	90                   	nop
    3c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c1c:	00 00 00 00 

0000000000003c20 <fwp_args173>:
    3c20:	f3 0f 1e fa          	endbr64
    3c24:	c3                   	ret
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_flush>:
    3c30:	48 8b 3d e9 17 02 00 	mov    0x217e9(%rip),%rdi        # 25420 <fwp_prog_out>
    3c37:	48 85 ff             	test   %rdi,%rdi
    3c3a:	74 1c                	je     3c58 <fwp_flush+0x28>
    3c3c:	48 83 ec 08          	sub    $0x8,%rsp
    3c40:	e8 4b f9 ff ff       	call   3590 <fflush@plt>
    3c45:	48 8b 3d d4 f3 00 00 	mov    0xf3d4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c4c:	48 83 c4 08          	add    $0x8,%rsp
    3c50:	e9 3b f9 ff ff       	jmp    3590 <fflush@plt>
    3c55:	0f 1f 00             	nopl   (%rax)
    3c58:	48 8b 3d c1 f3 00 00 	mov    0xf3c1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c5f:	e9 2c f9 ff ff       	jmp    3590 <fflush@plt>
    3c64:	90                   	nop
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_heap_oom>:
    3c70:	50                   	push   %rax
    3c71:	58                   	pop    %rax
    3c72:	ba 13 00 00 00       	mov    $0x13,%edx
    3c77:	be 01 00 00 00       	mov    $0x1,%esi
    3c7c:	48 8d 3d 85 b3 00 00 	lea    0xb385(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3c83:	48 83 ec 08          	sub    $0x8,%rsp
    3c87:	48 8b 0d b2 f3 00 00 	mov    0xf3b2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3c8e:	e8 ad f9 ff ff       	call   3640 <fwrite@plt>
    3c93:	31 ff                	xor    %edi,%edi
    3c95:	e8 f6 f8 ff ff       	call   3590 <fflush@plt>
    3c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    3c9f:	e8 bc f9 ff ff       	call   3660 <_Exit@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_segv>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	48 83 ec 28          	sub    $0x28,%rsp
    3cb8:	48 8b 05 e1 fa 01 00 	mov    0x1fae1(%rip),%rax        # 237a0 <fwp_cur>
    3cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3cc3:	41 89 f8             	mov    %edi,%r8d
    3cc6:	48 85 c0             	test   %rax,%rax
    3cc9:	74 6d                	je     3d38 <fwp_segv+0x88>
    3ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3ccf:	48 85 d2             	test   %rdx,%rdx
    3cd2:	74 64                	je     3d38 <fwp_segv+0x88>
    3cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3ce7:	e8 14 f9 ff ff       	call   3600 <sysconf@plt>
    3cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3cfb:	48 01 d0             	add    %rdx,%rax
    3cfe:	48 39 c1             	cmp    %rax,%rcx
    3d01:	b8 00 00 00 00       	mov    $0x0,%eax
    3d06:	40 0f 92 c6          	setb   %sil
    3d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d15:	31 c0                	xor    %eax,%eax
    3d17:	48 39 d1             	cmp    %rdx,%rcx
    3d1a:	0f 93 c0             	setae  %al
    3d1d:	21 f0                	and    %esi,%eax
    3d1f:	85 c0                	test   %eax,%eax
    3d21:	75 4a                	jne    3d6d <fwp_segv+0xbd>
    3d23:	31 f6                	xor    %esi,%esi
    3d25:	44 89 c7             	mov    %r8d,%edi
    3d28:	48 83 c4 28          	add    $0x28,%rsp
    3d2c:	e9 ef f7 ff ff       	jmp    3520 <signal@plt>
    3d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d38:	48 8b 05 19 f4 01 00 	mov    0x1f419(%rip),%rax        # 23158 <fwp_main_stack_top>
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	74 df                	je     3d23 <fwp_segv+0x73>
    3d44:	48 2b 05 05 f4 01 00 	sub    0x1f405(%rip),%rax        # 23150 <fwp_main_stack_size>
    3d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d52:	48 39 d1             	cmp    %rdx,%rcx
    3d55:	0f 93 c2             	setae  %dl
    3d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d5e:	48 39 c1             	cmp    %rax,%rcx
    3d61:	0f 92 c0             	setb   %al
    3d64:	0f b6 c0             	movzbl %al,%eax
    3d67:	21 d0                	and    %edx,%eax
    3d69:	85 c0                	test   %eax,%eax
    3d6b:	74 b6                	je     3d23 <fwp_segv+0x73>
    3d6d:	e8 be fe ff ff       	call   3c30 <fwp_flush>
    3d72:	bf 02 00 00 00       	mov    $0x2,%edi
    3d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3d7c:	48 8d 35 ed bd 00 00 	lea    0xbded(%rip),%rsi        # fb70 <msg.4>
    3d83:	e8 88 f6 ff ff       	call   3410 <write@plt>
    3d88:	bf 65 00 00 00       	mov    $0x65,%edi
    3d8d:	e8 2e f6 ff ff       	call   33c0 <_exit@plt>
    3d92:	0f 1f 00             	nopl   (%rax)
    3d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d9c:	00 00 00 00 

0000000000003da0 <descent_phase_fail>:
    3da0:	50                   	push   %rax
    3da1:	58                   	pop    %rax
    3da2:	48 8d 3d c7 b8 00 00 	lea    0xb8c7(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3da9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dae:	be 01 00 00 00       	mov    $0x1,%esi
    3db3:	48 83 ec 08          	sub    $0x8,%rsp
    3db7:	48 8b 0d 82 f2 00 00 	mov    0xf282(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dbe:	e8 7d f8 ff ff       	call   3640 <fwrite@plt>
    3dc3:	bf e9 00 00 00       	mov    $0xe9,%edi
    3dc8:	e8 93 f8 ff ff       	call   3660 <_Exit@plt>
    3dcd:	0f 1f 00             	nopl   (%rax)

0000000000003dd0 <descent_phase_report>:
    3dd0:	f3 0f 1e fa          	endbr64
    3dd4:	41 54                	push   %r12
    3dd6:	55                   	push   %rbp
    3dd7:	53                   	push   %rbx
    3dd8:	48 83 ec 40          	sub    $0x40,%rsp
    3ddc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3de3:	00 00 
    3de5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3dea:	31 c0                	xor    %eax,%eax
    3dec:	83 3d 25 f2 00 00 ff 	cmpl   $0xffffffff,0xf225(%rip)        # 13018 <descent_active_phase>
    3df3:	0f 85 32 01 00 00    	jne    3f2b <descent_phase_report+0x15b>
    3df9:	48 8d 05 22 b2 00 00 	lea    0xb222(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e00:	4c 8b 0d f1 f2 01 00 	mov    0x1f2f1(%rip),%r9        # 230f8 <descent_nodes>
    3e07:	31 db                	xor    %ebx,%ebx
    3e09:	f3 0f 7e 05 ff ed 00 	movq   0xedff(%rip),%xmm0        # 12c10 <d0+0x70>
    3e10:	00 
    3e11:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e16:	48 8d 05 27 b2 00 00 	lea    0xb227(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e1d:	4c 8b 05 cc f2 01 00 	mov    0x1f2cc(%rip),%r8        # 230f0 <descent_inputs>
    3e24:	48 8b 0d d5 f2 01 00 	mov    0x1f2d5(%rip),%rcx        # 23100 <descent_updates>
    3e2b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e2f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e34:	48 89 e5             	mov    %rsp,%rbp
    3e37:	48 8b 3d 02 f2 00 00 	mov    0xf202(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e3e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e42:	48 8d 05 18 b2 00 00 	lea    0xb218(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e49:	f3 0f 7e 05 c7 ed 00 	movq   0xedc7(%rip),%xmm0        # 12c18 <d0+0x78>
    3e50:	00 
    3e51:	48 8d 15 60 b8 00 00 	lea    0xb860(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e58:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e5d:	be 02 00 00 00       	mov    $0x2,%esi
    3e62:	31 c0                	xor    %eax,%eax
    3e64:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3e68:	4c 8d 25 b1 f2 01 00 	lea    0x1f2b1(%rip),%r12        # 23120 <descent_phase_ns>
    3e6f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3e74:	f3 0f 7e 05 a4 ed 00 	movq   0xeda4(%rip),%xmm0        # 12c20 <d0+0x80>
    3e7b:	00 
    3e7c:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3e80:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3e85:	e8 c6 f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3e90:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3e94:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3e99:	48 85 db             	test   %rbx,%rbx
    3e9c:	74 62                	je     3f00 <descent_phase_report+0x130>
    3e9e:	48 8b 3d 9b f1 00 00 	mov    0xf19b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ea5:	be 02 00 00 00       	mov    $0x2,%esi
    3eaa:	31 c0                	xor    %eax,%eax
    3eac:	48 83 c3 01          	add    $0x1,%rbx
    3eb0:	48 8d 0d b5 b1 00 00 	lea    0xb1b5(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3eb7:	48 8d 15 b0 b1 00 00 	lea    0xb1b0(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3ebe:	e8 8d f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3ec3:	48 83 fb 06          	cmp    $0x6,%rbx
    3ec7:	75 c7                	jne    3e90 <descent_phase_report+0xc0>
    3ec9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3ece:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ed5:	00 00 
    3ed7:	75 57                	jne    3f30 <descent_phase_report+0x160>
    3ed9:	48 8b 0d 60 f1 00 00 	mov    0xf160(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3ee0:	48 83 c4 40          	add    $0x40,%rsp
    3ee4:	ba 04 00 00 00       	mov    $0x4,%edx
    3ee9:	be 01 00 00 00       	mov    $0x1,%esi
    3eee:	5b                   	pop    %rbx
    3eef:	48 8d 3d 84 b1 00 00 	lea    0xb184(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3ef6:	5d                   	pop    %rbp
    3ef7:	41 5c                	pop    %r12
    3ef9:	e9 42 f7 ff ff       	jmp    3640 <fwrite@plt>
    3efe:	66 90                	xchg   %ax,%ax
    3f00:	48 8b 3d 39 f1 00 00 	mov    0xf139(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f07:	48 8d 0d 83 b1 00 00 	lea    0xb183(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f0e:	48 8d 15 59 b1 00 00 	lea    0xb159(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f15:	31 c0                	xor    %eax,%eax
    3f17:	be 02 00 00 00       	mov    $0x2,%esi
    3f1c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f21:	e8 2a f7 ff ff       	call   3650 <__fprintf_chk@plt>
    3f26:	e9 65 ff ff ff       	jmp    3e90 <descent_phase_report+0xc0>
    3f2b:	e8 70 fe ff ff       	call   3da0 <descent_phase_fail>
    3f30:	e8 0b f5 ff ff       	call   3440 <__stack_chk_fail@plt>
    3f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f3c:	00 00 00 00 

0000000000003f40 <fwp_heap_chunks>:
    3f40:	41 54                	push   %r12
    3f42:	55                   	push   %rbp
    3f43:	53                   	push   %rbx
    3f44:	48 83 ff 01          	cmp    $0x1,%rdi
    3f48:	0f 84 62 01 00 00    	je     40b0 <fwp_heap_chunks+0x170>
    3f4e:	48 8b 05 5b 0c 02 00 	mov    0x20c5b(%rip),%rax        # 24bb0 <fwp_heap+0x13f0>
    3f55:	4c 8d 05 54 0c 02 00 	lea    0x20c54(%rip),%r8        # 24bb0 <fwp_heap+0x13f0>
    3f5c:	48 8b 1d 35 0c 02 00 	mov    0x20c35(%rip),%rbx        # 24b98 <fwp_heap+0x13d8>
    3f63:	48 39 d8             	cmp    %rbx,%rax
    3f66:	0f 83 57 01 00 00    	jae    40c3 <fwp_heap_chunks+0x183>
    3f6c:	48 8b 0d 45 0c 02 00 	mov    0x20c45(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    3f73:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3f77:	31 f6                	xor    %esi,%esi
    3f79:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3f7d:	eb 1e                	jmp    3f9d <fwp_heap_chunks+0x5d>
    3f7f:	90                   	nop
    3f80:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3f84:	48 39 cf             	cmp    %rcx,%rdi
    3f87:	0f 84 03 01 00 00    	je     4090 <fwp_heap_chunks+0x150>
    3f8d:	48 83 c0 01          	add    $0x1,%rax
    3f91:	48 89 ce             	mov    %rcx,%rsi
    3f94:	48 83 c2 28          	add    $0x28,%rdx
    3f98:	48 39 c3             	cmp    %rax,%rbx
    3f9b:	74 14                	je     3fb1 <fwp_heap_chunks+0x71>
    3f9d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fa0:	74 de                	je     3f80 <fwp_heap_chunks+0x40>
    3fa2:	48 83 c0 01          	add    $0x1,%rax
    3fa6:	31 f6                	xor    %esi,%esi
    3fa8:	48 83 c2 28          	add    $0x28,%rdx
    3fac:	48 39 c3             	cmp    %rax,%rbx
    3faf:	75 ec                	jne    3f9d <fwp_heap_chunks+0x5d>
    3fb1:	48 29 f3             	sub    %rsi,%rbx
    3fb4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3fb8:	48 8b 3d e1 0b 02 00 	mov    0x20be1(%rip),%rdi        # 24ba0 <fwp_heap+0x13e0>
    3fbf:	48 29 35 2a 0c 02 00 	sub    %rsi,0x20c2a(%rip)        # 24bf0 <fwp_heap+0x1430>
    3fc6:	48 39 ef             	cmp    %rbp,%rdi
    3fc9:	0f 83 96 00 00 00    	jae    4065 <fwp_heap_chunks+0x125>
    3fcf:	48 8b 05 ba 0b 02 00 	mov    0x20bba(%rip),%rax        # 24b90 <fwp_heap+0x13d0>
    3fd6:	48 39 e8             	cmp    %rbp,%rax
    3fd9:	0f 82 eb 00 00 00    	jb     40ca <fwp_heap_chunks+0x18a>
    3fdf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3fe3:	ba 03 00 00 00       	mov    $0x3,%edx
    3fe8:	49 39 c4             	cmp    %rax,%r12
    3feb:	4c 0f 47 e0          	cmova  %rax,%r12
    3fef:	4c 89 e6             	mov    %r12,%rsi
    3ff2:	48 29 fe             	sub    %rdi,%rsi
    3ff5:	48 c1 e7 10          	shl    $0x10,%rdi
    3ff9:	48 03 3d 70 0b 02 00 	add    0x20b70(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    4000:	48 c1 e6 10          	shl    $0x10,%rsi
    4004:	e8 d7 f5 ff ff       	call   35e0 <mprotect@plt>
    4009:	85 c0                	test   %eax,%eax
    400b:	0f 85 b9 00 00 00    	jne    40ca <fwp_heap_chunks+0x18a>
    4011:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4016:	e8 e5 f5 ff ff       	call   3600 <sysconf@plt>
    401b:	48 8b 35 7e 0b 02 00 	mov    0x20b7e(%rip),%rsi        # 24ba0 <fwp_heap+0x13e0>
    4022:	48 89 c1             	mov    %rax,%rcx
    4025:	48 8b 05 8c 0b 02 00 	mov    0x20b8c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    402c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4030:	48 89 ca             	mov    %rcx,%rdx
    4033:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4037:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    403b:	48 f7 da             	neg    %rdx
    403e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4043:	48 21 d7             	and    %rdx,%rdi
    4046:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    404a:	48 21 d6             	and    %rdx,%rsi
    404d:	ba 03 00 00 00       	mov    $0x3,%edx
    4052:	48 29 fe             	sub    %rdi,%rsi
    4055:	e8 86 f5 ff ff       	call   35e0 <mprotect@plt>
    405a:	85 c0                	test   %eax,%eax
    405c:	75 6c                	jne    40ca <fwp_heap_chunks+0x18a>
    405e:	4c 89 25 3b 0b 02 00 	mov    %r12,0x20b3b(%rip)        # 24ba0 <fwp_heap+0x13e0>
    4065:	48 89 ef             	mov    %rbp,%rdi
    4068:	48 89 2d 29 0b 02 00 	mov    %rbp,0x20b29(%rip)        # 24b98 <fwp_heap+0x13d8>
    406f:	48 c1 e7 10          	shl    $0x10,%rdi
    4073:	48 39 3d 0e 0b 02 00 	cmp    %rdi,0x20b0e(%rip)        # 24b88 <fwp_heap+0x13c8>
    407a:	73 07                	jae    4083 <fwp_heap_chunks+0x143>
    407c:	48 89 3d 05 0b 02 00 	mov    %rdi,0x20b05(%rip)        # 24b88 <fwp_heap+0x13c8>
    4083:	48 89 d8             	mov    %rbx,%rax
    4086:	5b                   	pop    %rbx
    4087:	5d                   	pop    %rbp
    4088:	41 5c                	pop    %r12
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 8d 50 01          	lea    0x1(%rax),%rdx
    4094:	48 29 f0             	sub    %rsi,%rax
    4097:	48 89 c3             	mov    %rax,%rbx
    409a:	49 89 10             	mov    %rdx,(%r8)
    409d:	48 89 d8             	mov    %rbx,%rax
    40a0:	48 29 3d 49 0b 02 00 	sub    %rdi,0x20b49(%rip)        # 24bf0 <fwp_heap+0x1430>
    40a7:	5b                   	pop    %rbx
    40a8:	5d                   	pop    %rbp
    40a9:	41 5c                	pop    %r12
    40ab:	c3                   	ret
    40ac:	0f 1f 40 00          	nopl   0x0(%rax)
    40b0:	48 8b 05 f1 0a 02 00 	mov    0x20af1(%rip),%rax        # 24ba8 <fwp_heap+0x13e8>
    40b7:	4c 8d 05 ea 0a 02 00 	lea    0x20aea(%rip),%r8        # 24ba8 <fwp_heap+0x13e8>
    40be:	e9 99 fe ff ff       	jmp    3f5c <fwp_heap_chunks+0x1c>
    40c3:	31 f6                	xor    %esi,%esi
    40c5:	e9 ea fe ff ff       	jmp    3fb4 <fwp_heap_chunks+0x74>
    40ca:	e8 a1 fb ff ff       	call   3c70 <fwp_heap_oom>
    40cf:	90                   	nop

00000000000040d0 <fwp_tape_buffers_dispose>:
    40d0:	53                   	push   %rbx
    40d1:	48 89 fb             	mov    %rdi,%rbx
    40d4:	48 8b 3f             	mov    (%rdi),%rdi
    40d7:	e8 c4 f2 ff ff       	call   33a0 <free@plt>
    40dc:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    40e0:	e8 bb f2 ff ff       	call   33a0 <free@plt>
    40e5:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    40e9:	e8 b2 f2 ff ff       	call   33a0 <free@plt>
    40ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
    40f2:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    40f9:	00 
    40fa:	0f 11 03             	movups %xmm0,(%rbx)
    40fd:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4101:	5b                   	pop    %rbx
    4102:	c3                   	ret
    4103:	66 90                	xchg   %ax,%ax
    4105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    410c:	00 00 00 00 

0000000000004110 <buf_grow>:
    4110:	48 83 ec 18          	sub    $0x18,%rsp
    4114:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4118:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    411c:	74 7e                	je     419c <buf_grow+0x8c>
    411e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4125:	48 29 c2             	sub    %rax,%rdx
    4128:	48 39 f2             	cmp    %rsi,%rdx
    412b:	72 6f                	jb     419c <buf_grow+0x8c>
    412d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4132:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4136:	48 89 f9             	mov    %rdi,%rcx
    4139:	48 39 d0             	cmp    %rdx,%rax
    413c:	73 48                	jae    4186 <buf_grow+0x76>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	75 15                	jne    4158 <buf_grow+0x48>
    4143:	48 83 fa 40          	cmp    $0x40,%rdx
    4147:	76 4c                	jbe    4195 <buf_grow+0x85>
    4149:	b8 40 00 00 00       	mov    $0x40,%eax
    414e:	eb 08                	jmp    4158 <buf_grow+0x48>
    4150:	48 01 c0             	add    %rax,%rax
    4153:	48 39 d0             	cmp    %rdx,%rax
    4156:	73 38                	jae    4190 <buf_grow+0x80>
    4158:	48 85 c0             	test   %rax,%rax
    415b:	79 f3                	jns    4150 <buf_grow+0x40>
    415d:	48 8b 39             	mov    (%rcx),%rdi
    4160:	48 89 d6             	mov    %rdx,%rsi
    4163:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4168:	48 89 14 24          	mov    %rdx,(%rsp)
    416c:	e8 2f f4 ff ff       	call   35a0 <realloc@plt>
    4171:	48 8b 14 24          	mov    (%rsp),%rdx
    4175:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    417a:	48 85 c0             	test   %rax,%rax
    417d:	74 1d                	je     419c <buf_grow+0x8c>
    417f:	48 89 01             	mov    %rax,(%rcx)
    4182:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4186:	48 83 c4 18          	add    $0x18,%rsp
    418a:	c3                   	ret
    418b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4190:	48 89 c2             	mov    %rax,%rdx
    4193:	eb c8                	jmp    415d <buf_grow+0x4d>
    4195:	ba 40 00 00 00       	mov    $0x40,%edx
    419a:	eb c1                	jmp    415d <buf_grow+0x4d>
    419c:	48 8b 0d 9d ee 00 00 	mov    0xee9d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41a3:	ba 13 00 00 00       	mov    $0x13,%edx
    41a8:	be 01 00 00 00       	mov    $0x1,%esi
    41ad:	48 8d 3d 54 ae 00 00 	lea    0xae54(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41b4:	e8 87 f4 ff ff       	call   3640 <fwrite@plt>
    41b9:	31 ff                	xor    %edi,%edi
    41bb:	e8 d0 f3 ff ff       	call   3590 <fflush@plt>
    41c0:	bf 66 00 00 00       	mov    $0x66,%edi
    41c5:	e8 96 f4 ff ff       	call   3660 <_Exit@plt>
    41ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041d0 <buf_put>:
    41d0:	41 54                	push   %r12
    41d2:	49 89 f4             	mov    %rsi,%r12
    41d5:	48 89 d6             	mov    %rdx,%rsi
    41d8:	55                   	push   %rbp
    41d9:	48 89 fd             	mov    %rdi,%rbp
    41dc:	53                   	push   %rbx
    41dd:	48 89 d3             	mov    %rdx,%rbx
    41e0:	e8 2b ff ff ff       	call   4110 <buf_grow>
    41e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    41e9:	48 89 da             	mov    %rbx,%rdx
    41ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    41f0:	4c 89 e6             	mov    %r12,%rsi
    41f3:	e8 78 f3 ff ff       	call   3570 <memcpy@plt>
    41f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    41fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4200:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4204:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4208:	5b                   	pop    %rbx
    4209:	5d                   	pop    %rbp
    420a:	41 5c                	pop    %r12
    420c:	c3                   	ret
    420d:	0f 1f 00             	nopl   (%rax)

0000000000004210 <descent_phase_step>:
    4210:	55                   	push   %rbp
    4211:	53                   	push   %rbx
    4212:	48 83 ec 28          	sub    $0x28,%rsp
    4216:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    421d:	00 00 
    421f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4224:	48 63 2d ed ed 00 00 	movslq 0xeded(%rip),%rbp        # 13018 <descent_active_phase>
    422b:	8d 45 01             	lea    0x1(%rbp),%eax
    422e:	39 f8                	cmp    %edi,%eax
    4230:	75 7c                	jne    42ae <descent_phase_step+0x9e>
    4232:	89 fb                	mov    %edi,%ebx
    4234:	48 89 e6             	mov    %rsp,%rsi
    4237:	bf 01 00 00 00       	mov    $0x1,%edi
    423c:	e8 bf f1 ff ff       	call   3400 <clock_gettime@plt>
    4241:	85 c0                	test   %eax,%eax
    4243:	75 69                	jne    42ae <descent_phase_step+0x9e>
    4245:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    424c:	3b 
    424d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4252:	83 fd ff             	cmp    $0xffffffff,%ebp
    4255:	74 21                	je     4278 <descent_phase_step+0x68>
    4257:	48 8b 35 aa ee 01 00 	mov    0x1eeaa(%rip),%rsi        # 23108 <descent_last_ns>
    425e:	48 39 f0             	cmp    %rsi,%rax
    4261:	72 4b                	jb     42ae <descent_phase_step+0x9e>
    4263:	48 8d 0d b6 ee 01 00 	lea    0x1eeb6(%rip),%rcx        # 23120 <descent_phase_ns>
    426a:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    426e:	48 29 f2             	sub    %rsi,%rdx
    4271:	48 01 c2             	add    %rax,%rdx
    4274:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    4278:	83 fb 06             	cmp    $0x6,%ebx
    427b:	75 0d                	jne    428a <descent_phase_step+0x7a>
    427d:	48 83 05 7b ee 01 00 	addq   $0x1,0x1ee7b(%rip)        # 23100 <descent_updates>
    4284:	01 
    4285:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    428a:	89 1d 88 ed 00 00    	mov    %ebx,0xed88(%rip)        # 13018 <descent_active_phase>
    4290:	48 89 05 71 ee 01 00 	mov    %rax,0x1ee71(%rip)        # 23108 <descent_last_ns>
    4297:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    429c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42a3:	00 00 
    42a5:	75 0c                	jne    42b3 <descent_phase_step+0xa3>
    42a7:	48 83 c4 28          	add    $0x28,%rsp
    42ab:	5b                   	pop    %rbx
    42ac:	5d                   	pop    %rbp
    42ad:	c3                   	ret
    42ae:	e8 ed fa ff ff       	call   3da0 <descent_phase_fail>
    42b3:	e8 88 f1 ff ff       	call   3440 <__stack_chk_fail@plt>
    42b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42bf:	00 

00000000000042c0 <fwp_cancel_tree.part.0>:
    42c0:	48 3b 3d d9 f4 01 00 	cmp    0x1f4d9(%rip),%rdi        # 237a0 <fwp_cur>
    42c7:	53                   	push   %rbx
    42c8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    42cc:	74 35                	je     4303 <fwp_cancel_tree.part.0+0x43>
    42ce:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    42d2:	75 2f                	jne    4303 <fwp_cancel_tree.part.0+0x43>
    42d4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    42d8:	75 29                	jne    4303 <fwp_cancel_tree.part.0+0x43>
    42da:	48 8b 05 9f f4 01 00 	mov    0x1f49f(%rip),%rax        # 23780 <fwp_ready_tail>
    42e1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    42e5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    42ec:	00 00 00 00 
    42f0:	48 85 c0             	test   %rax,%rax
    42f3:	74 33                	je     4328 <fwp_cancel_tree.part.0+0x68>
    42f5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    42fc:	48 89 3d 7d f4 01 00 	mov    %rdi,0x1f47d(%rip)        # 23780 <fwp_ready_tail>
    4303:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4307:	48 85 db             	test   %rbx,%rbx
    430a:	74 17                	je     4323 <fwp_cancel_tree.part.0+0x63>
    430c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4310:	75 08                	jne    431a <fwp_cancel_tree.part.0+0x5a>
    4312:	48 89 df             	mov    %rbx,%rdi
    4315:	e8 a6 ff ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    431a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    431e:	48 85 db             	test   %rbx,%rbx
    4321:	75 e9                	jne    430c <fwp_cancel_tree.part.0+0x4c>
    4323:	5b                   	pop    %rbx
    4324:	c3                   	ret
    4325:	0f 1f 00             	nopl   (%rax)
    4328:	48 89 3d 59 f4 01 00 	mov    %rdi,0x1f459(%rip)        # 23788 <fwp_ready_head>
    432f:	eb cb                	jmp    42fc <fwp_cancel_tree.part.0+0x3c>
    4331:	0f 1f 40 00          	nopl   0x0(%rax)
    4335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    433c:	00 00 00 00 

0000000000004340 <fwp_finish_float>:
    4340:	53                   	push   %rbx
    4341:	be 2e 00 00 00       	mov    $0x2e,%esi
    4346:	48 89 fb             	mov    %rdi,%rbx
    4349:	e8 12 f1 ff ff       	call   3460 <strchr@plt>
    434e:	48 85 c0             	test   %rax,%rax
    4351:	74 05                	je     4358 <fwp_finish_float+0x18>
    4353:	5b                   	pop    %rbx
    4354:	c3                   	ret
    4355:	0f 1f 00             	nopl   (%rax)
    4358:	be 65 00 00 00       	mov    $0x65,%esi
    435d:	48 89 df             	mov    %rbx,%rdi
    4360:	e8 fb f0 ff ff       	call   3460 <strchr@plt>
    4365:	48 85 c0             	test   %rax,%rax
    4368:	75 e9                	jne    4353 <fwp_finish_float+0x13>
    436a:	48 8d 35 2e ae 00 00 	lea    0xae2e(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    4371:	48 89 df             	mov    %rbx,%rdi
    4374:	e8 17 f3 ff ff       	call   3690 <strstr@plt>
    4379:	48 85 c0             	test   %rax,%rax
    437c:	75 d5                	jne    4353 <fwp_finish_float+0x13>
    437e:	48 8d 35 fa ac 00 00 	lea    0xacfa(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    4385:	48 89 df             	mov    %rbx,%rdi
    4388:	e8 03 f3 ff ff       	call   3690 <strstr@plt>
    438d:	48 85 c0             	test   %rax,%rax
    4390:	75 c1                	jne    4353 <fwp_finish_float+0x13>
    4392:	48 89 df             	mov    %rbx,%rdi
    4395:	e8 96 f0 ff ff       	call   3430 <strlen@plt>
    439a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    439f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43a3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43a8:	5b                   	pop    %rbx
    43a9:	c3                   	ret
    43aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043b0 <fwp_trap>:
    43b0:	55                   	push   %rbp
    43b1:	48 89 fd             	mov    %rdi,%rbp
    43b4:	53                   	push   %rbx
    43b5:	48 83 ec 08          	sub    $0x8,%rsp
    43b9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    43c0:	ff ff 
    43c2:	e8 69 f8 ff ff       	call   3c30 <fwp_flush>
    43c7:	31 c0                	xor    %eax,%eax
    43c9:	48 89 e9             	mov    %rbp,%rcx
    43cc:	be 02 00 00 00       	mov    $0x2,%esi
    43d1:	48 8b 3d 68 ec 00 00 	mov    0xec68(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43d8:	48 8d 15 a4 ac 00 00 	lea    0xaca4(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    43df:	e8 6c f2 ff ff       	call   3650 <__fprintf_chk@plt>
    43e4:	48 85 db             	test   %rbx,%rbx
    43e7:	74 16                	je     43ff <fwp_trap+0x4f>
    43e9:	48 8b 3d 50 ec 00 00 	mov    0xec50(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43f0:	e8 9b f1 ff ff       	call   3590 <fflush@plt>
    43f5:	bf 65 00 00 00       	mov    $0x65,%edi
    43fa:	e8 61 f2 ff ff       	call   3660 <_Exit@plt>
    43ff:	bf 65 00 00 00       	mov    $0x65,%edi
    4404:	e8 27 f2 ff ff       	call   3630 <exit@plt>
    4409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004410 <fwp_closure_drop_push>:
    4410:	41 56                	push   %r14
    4412:	41 54                	push   %r12
    4414:	49 89 f4             	mov    %rsi,%r12
    4417:	55                   	push   %rbp
    4418:	48 89 fd             	mov    %rdi,%rbp
    441b:	53                   	push   %rbx
    441c:	48 83 ec 18          	sub    $0x18,%rsp
    4420:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4424:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4428:	74 26                	je     4450 <fwp_closure_drop_push+0x40>
    442a:	4c 8b 07             	mov    (%rdi),%r8
    442d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4434:	00 
    4435:	48 83 c3 01          	add    $0x1,%rbx
    4439:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    443d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4441:	48 83 c4 18          	add    $0x18,%rsp
    4445:	5b                   	pop    %rbx
    4446:	5d                   	pop    %rbp
    4447:	41 5c                	pop    %r12
    4449:	41 5e                	pop    %r14
    444b:	c3                   	ret
    444c:	0f 1f 40 00          	nopl   0x0(%rax)
    4450:	48 89 d8             	mov    %rbx,%rax
    4453:	48 c1 e8 3c          	shr    $0x3c,%rax
    4457:	0f 85 a9 00 00 00    	jne    4506 <fwp_closure_drop_push+0xf6>
    445d:	48 89 d9             	mov    %rbx,%rcx
    4460:	48 c1 e1 04          	shl    $0x4,%rcx
    4464:	48 89 cf             	mov    %rcx,%rdi
    4467:	48 89 0c 24          	mov    %rcx,(%rsp)
    446b:	e8 10 f1 ff ff       	call   3580 <malloc@plt>
    4470:	48 8b 0c 24          	mov    (%rsp),%rcx
    4474:	48 85 c0             	test   %rax,%rax
    4477:	74 5f                	je     44d8 <fwp_closure_drop_push+0xc8>
    4479:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    447d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4484:	00 
    4485:	48 89 c7             	mov    %rax,%rdi
    4488:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    448c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4491:	48 89 34 24          	mov    %rsi,(%rsp)
    4495:	e8 a6 f0 ff ff       	call   3540 <__memcpy_chk@plt>
    449a:	48 8b 34 24          	mov    (%rsp),%rsi
    449e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44a3:	49 89 c0             	mov    %rax,%r8
    44a6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44aa:	48 39 c6             	cmp    %rax,%rsi
    44ad:	74 1c                	je     44cb <fwp_closure_drop_push+0xbb>
    44af:	48 89 f7             	mov    %rsi,%rdi
    44b2:	4c 89 04 24          	mov    %r8,(%rsp)
    44b6:	e8 e5 ee ff ff       	call   33a0 <free@plt>
    44bb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44bf:	4c 8b 04 24          	mov    (%rsp),%r8
    44c3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44ca:	00 
    44cb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    44cf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    44d3:	e9 5d ff ff ff       	jmp    4435 <fwp_closure_drop_push+0x25>
    44d8:	48 8b 0d 61 eb 00 00 	mov    0xeb61(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    44df:	ba 13 00 00 00       	mov    $0x13,%edx
    44e4:	be 01 00 00 00       	mov    $0x1,%esi
    44e9:	48 8d 3d 18 ab 00 00 	lea    0xab18(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    44f0:	e8 4b f1 ff ff       	call   3640 <fwrite@plt>
    44f5:	31 ff                	xor    %edi,%edi
    44f7:	e8 94 f0 ff ff       	call   3590 <fflush@plt>
    44fc:	bf 66 00 00 00       	mov    $0x66,%edi
    4501:	e8 5a f1 ff ff       	call   3660 <_Exit@plt>
    4506:	48 8d 3d 85 ab 00 00 	lea    0xab85(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    450d:	e8 9e fe ff ff       	call   43b0 <fwp_trap>
    4512:	0f 1f 00             	nopl   (%rax)
    4515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    451c:	00 00 00 00 

0000000000004520 <fwp_now_ns>:
    4520:	53                   	push   %rbx
    4521:	bf 01 00 00 00       	mov    $0x1,%edi
    4526:	48 83 ec 20          	sub    $0x20,%rsp
    452a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4531:	00 00 
    4533:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4538:	31 db                	xor    %ebx,%ebx
    453a:	48 89 e6             	mov    %rsp,%rsi
    453d:	e8 be ee ff ff       	call   3400 <clock_gettime@plt>
    4542:	85 c0                	test   %eax,%eax
    4544:	75 52                	jne    4598 <fwp_now_ns+0x78>
    4546:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    454b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4550:	48 f7 2c 24          	imulq  (%rsp)
    4554:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    455b:	48 89 f7             	mov    %rsi,%rdi
    455e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4562:	48 01 f0             	add    %rsi,%rax
    4565:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    456c:	00 00 80 
    456f:	48 11 fa             	adc    %rdi,%rdx
    4572:	31 ff                	xor    %edi,%edi
    4574:	48 01 c6             	add    %rax,%rsi
    4577:	48 11 d7             	adc    %rdx,%rdi
    457a:	48 39 f1             	cmp    %rsi,%rcx
    457d:	48 19 fb             	sbb    %rdi,%rbx
    4580:	72 27                	jb     45a9 <fwp_now_ns+0x89>
    4582:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4587:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    458e:	00 00 
    4590:	75 12                	jne    45a4 <fwp_now_ns+0x84>
    4592:	48 83 c4 20          	add    $0x20,%rsp
    4596:	5b                   	pop    %rbx
    4597:	c3                   	ret
    4598:	48 8d 3d 0d ab 00 00 	lea    0xab0d(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    459f:	e8 0c fe ff ff       	call   43b0 <fwp_trap>
    45a4:	e8 97 ee ff ff       	call   3440 <__stack_chk_fail@plt>
    45a9:	48 8d 3d 58 b1 00 00 	lea    0xb158(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45b0:	e8 fb fd ff ff       	call   43b0 <fwp_trap>
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_closure_drop.part.0>:
    45c0:	53                   	push   %rbx
    45c1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    45c8:	66 0f 6f 05 e0 b5 00 	movdqa 0xb5e0(%rip),%xmm0        # fbb0 <msg.4+0x40>
    45cf:	00 
    45d0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    45d7:	00 00 
    45d9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    45e0:	00 
    45e1:	48 89 fe             	mov    %rdi,%rsi
    45e4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    45e9:	48 89 e7             	mov    %rsp,%rdi
    45ec:	48 89 1c 24          	mov    %rbx,(%rsp)
    45f0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    45f5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    45fc:	ff ff 
    45fe:	e8 0d fe ff ff       	call   4410 <fwp_closure_drop_push>
    4603:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4608:	48 85 c0             	test   %rax,%rax
    460b:	74 39                	je     4646 <fwp_closure_drop.part.0+0x86>
    460d:	0f 1f 00             	nopl   (%rax)
    4610:	48 8b 14 24          	mov    (%rsp),%rdx
    4614:	48 83 e8 01          	sub    $0x1,%rax
    4618:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    461d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4621:	8b 07                	mov    (%rdi),%eax
    4623:	48 c1 e0 05          	shl    $0x5,%rax
    4627:	48 03 05 ea 0d 02 00 	add    0x20dea(%rip),%rax        # 25418 <fwp_fns>
    462e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4632:	48 85 c0             	test   %rax,%rax
    4635:	74 46                	je     467d <fwp_closure_drop.part.0+0xbd>
    4637:	31 f6                	xor    %esi,%esi
    4639:	ff 50 08             	call   *0x8(%rax)
    463c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4641:	48 85 c0             	test   %rax,%rax
    4644:	75 ca                	jne    4610 <fwp_closure_drop.part.0+0x50>
    4646:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    464d:	ff ff 00 00 00 00 
    4653:	48 8b 3c 24          	mov    (%rsp),%rdi
    4657:	48 39 df             	cmp    %rbx,%rdi
    465a:	74 05                	je     4661 <fwp_closure_drop.part.0+0xa1>
    465c:	e8 3f ed ff ff       	call   33a0 <free@plt>
    4661:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4668:	00 
    4669:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4670:	00 00 
    4672:	75 15                	jne    4689 <fwp_closure_drop.part.0+0xc9>
    4674:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    467b:	5b                   	pop    %rbx
    467c:	c3                   	ret
    467d:	48 8d 3d ac b0 00 00 	lea    0xb0ac(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4684:	e8 27 fd ff ff       	call   43b0 <fwp_trap>
    4689:	e8 b2 ed ff ff       	call   3440 <__stack_chk_fail@plt>
    468e:	66 90                	xchg   %ax,%ax

0000000000004690 <fwp_tape_of>:
    4690:	0f b7 d7             	movzwl %di,%edx
    4693:	48 85 d2             	test   %rdx,%rdx
    4696:	74 28                	je     46c0 <fwp_tape_of+0x30>
    4698:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    469c:	48 39 05 35 ea 01 00 	cmp    %rax,0x1ea35(%rip)        # 230d8 <fwp_ntapes>
    46a3:	7e 1b                	jle    46c0 <fwp_tape_of+0x30>
    46a5:	48 6b c0 58          	imul   $0x58,%rax,%rax
    46a9:	48 03 05 30 ea 01 00 	add    0x1ea30(%rip),%rax        # 230e0 <fwp_tapes>
    46b0:	8b 50 04             	mov    0x4(%rax),%edx
    46b3:	85 d2                	test   %edx,%edx
    46b5:	74 09                	je     46c0 <fwp_tape_of+0x30>
    46b7:	48 c1 ff 10          	sar    $0x10,%rdi
    46bb:	39 38                	cmp    %edi,(%rax)
    46bd:	75 01                	jne    46c0 <fwp_tape_of+0x30>
    46bf:	c3                   	ret
    46c0:	48 83 ec 08          	sub    $0x8,%rsp
    46c4:	48 8d 3d 95 b0 00 00 	lea    0xb095(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    46cb:	e8 e0 fc ff ff       	call   43b0 <fwp_trap>

00000000000046d0 <fwp_format_g.constprop.0>:
    46d0:	41 57                	push   %r15
    46d2:	b9 40 00 00 00       	mov    $0x40,%ecx
    46d7:	ba 02 00 00 00       	mov    $0x2,%edx
    46dc:	4c 8d 05 e5 a9 00 00 	lea    0xa9e5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    46e3:	41 56                	push   %r14
    46e5:	b8 01 00 00 00       	mov    $0x1,%eax
    46ea:	41 55                	push   %r13
    46ec:	41 54                	push   %r12
    46ee:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    46f2:	55                   	push   %rbp
    46f3:	45 89 e1             	mov    %r12d,%r9d
    46f6:	53                   	push   %rbx
    46f7:	48 89 fb             	mov    %rdi,%rbx
    46fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4701:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4708:	00 00 
    470a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4711:	00 
    4712:	41 89 f7             	mov    %esi,%r15d
    4715:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    471a:	be 40 00 00 00       	mov    $0x40,%esi
    471f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4724:	4c 89 f7             	mov    %r14,%rdi
    4727:	e8 64 ec ff ff       	call   3390 <__snprintf_chk@plt>
    472c:	be 65 00 00 00       	mov    $0x65,%esi
    4731:	4c 89 f7             	mov    %r14,%rdi
    4734:	e8 27 ed ff ff       	call   3460 <strchr@plt>
    4739:	31 f6                	xor    %esi,%esi
    473b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4740:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4744:	48 89 c5             	mov    %rax,%rbp
    4747:	e8 14 ee ff ff       	call   3560 <strtol@plt>
    474c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4751:	49 89 c0             	mov    %rax,%r8
    4754:	83 c0 05             	add    $0x5,%eax
    4757:	83 f8 15             	cmp    $0x15,%eax
    475a:	0f 87 e0 01 00 00    	ja     4940 <fwp_format_g.constprop.0+0x270>
    4760:	45 89 e5             	mov    %r12d,%r13d
    4763:	45 29 c5             	sub    %r8d,%r13d
    4766:	45 85 ed             	test   %r13d,%r13d
    4769:	0f 8e 21 01 00 00    	jle    4890 <fwp_format_g.constprop.0+0x1c0>
    476f:	41 83 ff 01          	cmp    $0x1,%r15d
    4773:	0f 84 17 01 00 00    	je     4890 <fwp_format_g.constprop.0+0x1c0>
    4779:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    477e:	31 d2                	xor    %edx,%edx
    4780:	4d 63 df             	movslq %r15d,%r11
    4783:	3c 2d                	cmp    $0x2d,%al
    4785:	0f 94 c2             	sete   %dl
    4788:	4c 29 dd             	sub    %r11,%rbp
    478b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    478f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4793:	4d 89 f1             	mov    %r14,%r9
    4796:	4d 29 d1             	sub    %r10,%r9
    4799:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    479d:	3c 2d                	cmp    $0x2d,%al
    479f:	0f 84 fb 03 00 00    	je     4ba0 <fwp_format_g.constprop.0+0x4d0>
    47a5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47aa:	b9 48 00 00 00       	mov    $0x48,%ecx
    47af:	48 89 e8             	mov    %rbp,%rax
    47b2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47b6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47ba:	49 83 c1 47          	add    $0x47,%r9
    47be:	45 85 c0             	test   %r8d,%r8d
    47c1:	0f 88 f1 02 00 00    	js     4ab8 <fwp_format_g.constprop.0+0x3e8>
    47c7:	45 0f b6 12          	movzbl (%r10),%r10d
    47cb:	4d 63 e0             	movslq %r8d,%r12
    47ce:	44 88 10             	mov    %r10b,(%rax)
    47d1:	41 83 f8 07          	cmp    $0x7,%r8d
    47d5:	0f 87 2d 02 00 00    	ja     4a08 <fwp_format_g.constprop.0+0x338>
    47db:	41 f6 c4 04          	test   $0x4,%r12b
    47df:	0f 85 f2 03 00 00    	jne    4bd7 <fwp_format_g.constprop.0+0x507>
    47e5:	45 85 e4             	test   %r12d,%r12d
    47e8:	74 12                	je     47fc <fwp_format_g.constprop.0+0x12c>
    47ea:	45 0f b6 06          	movzbl (%r14),%r8d
    47ee:	44 88 40 01          	mov    %r8b,0x1(%rax)
    47f2:	41 f6 c4 02          	test   $0x2,%r12b
    47f6:	0f 85 03 04 00 00    	jne    4bff <fwp_format_g.constprop.0+0x52f>
    47fc:	4c 29 e1             	sub    %r12,%rcx
    47ff:	4c 01 e7             	add    %r12,%rdi
    4802:	4c 89 fa             	mov    %r15,%rdx
    4805:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    480a:	48 83 e9 01          	sub    $0x1,%rcx
    480e:	4d 63 ed             	movslq %r13d,%r13
    4811:	48 89 0c 24          	mov    %rcx,(%rsp)
    4815:	e8 26 ed ff ff       	call   3540 <__memcpy_chk@plt>
    481a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    481f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4823:	ba 48 00 00 00       	mov    $0x48,%edx
    4828:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    482c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4830:	4c 89 c8             	mov    %r9,%rax
    4833:	48 29 c8             	sub    %rcx,%rax
    4836:	48 39 d0             	cmp    %rdx,%rax
    4839:	48 0f 42 c2          	cmovb  %rdx,%rax
    483d:	4c 29 c9             	sub    %r9,%rcx
    4840:	4c 89 ea             	mov    %r13,%rdx
    4843:	48 01 c1             	add    %rax,%rcx
    4846:	e8 f5 ec ff ff       	call   3540 <__memcpy_chk@plt>
    484b:	4c 01 e8             	add    %r13,%rax
    484e:	48 29 e8             	sub    %rbp,%rax
    4851:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4856:	48 39 d0             	cmp    %rdx,%rax
    4859:	48 0f 47 c2          	cmova  %rdx,%rax
    485d:	89 c1                	mov    %eax,%ecx
    485f:	83 f8 08             	cmp    $0x8,%eax
    4862:	0f 83 18 02 00 00    	jae    4a80 <fwp_format_g.constprop.0+0x3b0>
    4868:	a8 04                	test   $0x4,%al
    486a:	0f 85 54 03 00 00    	jne    4bc4 <fwp_format_g.constprop.0+0x4f4>
    4870:	85 c0                	test   %eax,%eax
    4872:	74 0f                	je     4883 <fwp_format_g.constprop.0+0x1b3>
    4874:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4879:	88 13                	mov    %dl,(%rbx)
    487b:	a8 02                	test   $0x2,%al
    487d:	0f 85 6b 03 00 00    	jne    4bee <fwp_format_g.constprop.0+0x51e>
    4883:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4887:	eb 36                	jmp    48bf <fwp_format_g.constprop.0+0x1ef>
    4889:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4890:	45 31 c9             	xor    %r9d,%r9d
    4893:	45 85 ed             	test   %r13d,%r13d
    4896:	4c 8d 05 3a a8 00 00 	lea    0xa83a(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    489d:	48 89 df             	mov    %rbx,%rdi
    48a0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48a4:	ba 02 00 00 00       	mov    $0x2,%edx
    48a9:	be 90 01 00 00       	mov    $0x190,%esi
    48ae:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48b5:	b8 01 00 00 00       	mov    $0x1,%eax
    48ba:	e8 d1 ea ff ff       	call   3390 <__snprintf_chk@plt>
    48bf:	be 2e 00 00 00       	mov    $0x2e,%esi
    48c4:	48 89 df             	mov    %rbx,%rdi
    48c7:	e8 94 eb ff ff       	call   3460 <strchr@plt>
    48cc:	48 85 c0             	test   %rax,%rax
    48cf:	74 3f                	je     4910 <fwp_format_g.constprop.0+0x240>
    48d1:	48 89 df             	mov    %rbx,%rdi
    48d4:	e8 57 eb ff ff       	call   3430 <strlen@plt>
    48d9:	48 85 c0             	test   %rax,%rax
    48dc:	75 0b                	jne    48e9 <fwp_format_g.constprop.0+0x219>
    48de:	eb 30                	jmp    4910 <fwp_format_g.constprop.0+0x240>
    48e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48e4:	48 85 c0             	test   %rax,%rax
    48e7:	74 27                	je     4910 <fwp_format_g.constprop.0+0x240>
    48e9:	48 89 c2             	mov    %rax,%rdx
    48ec:	48 83 e8 01          	sub    $0x1,%rax
    48f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    48f4:	74 ea                	je     48e0 <fwp_format_g.constprop.0+0x210>
    48f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    48fb:	0f 84 6f 01 00 00    	je     4a70 <fwp_format_g.constprop.0+0x3a0>
    4901:	0f 1f 40 00          	nopl   0x0(%rax)
    4905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    490c:	00 00 00 00 
    4910:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4917:	00 
    4918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    491f:	00 00 
    4921:	0f 85 ec 02 00 00    	jne    4c13 <fwp_format_g.constprop.0+0x543>
    4927:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    492e:	5b                   	pop    %rbx
    492f:	5d                   	pop    %rbp
    4930:	41 5c                	pop    %r12
    4932:	41 5d                	pop    %r13
    4934:	41 5e                	pop    %r14
    4936:	41 5f                	pop    %r15
    4938:	c3                   	ret
    4939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4940:	4c 29 f5             	sub    %r14,%rbp
    4943:	b9 40 00 00 00       	mov    $0x40,%ecx
    4948:	4c 89 f6             	mov    %r14,%rsi
    494b:	4c 89 04 24          	mov    %r8,(%rsp)
    494f:	49 89 ec             	mov    %rbp,%r12
    4952:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4957:	4c 89 e2             	mov    %r12,%rdx
    495a:	48 89 ef             	mov    %rbp,%rdi
    495d:	e8 de eb ff ff       	call   3540 <__memcpy_chk@plt>
    4962:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4968:	be 2e 00 00 00       	mov    $0x2e,%esi
    496d:	48 89 ef             	mov    %rbp,%rdi
    4970:	e8 eb ea ff ff       	call   3460 <strchr@plt>
    4975:	4c 8b 04 24          	mov    (%rsp),%r8
    4979:	48 85 c0             	test   %rax,%rax
    497c:	74 40                	je     49be <fwp_format_g.constprop.0+0x2ee>
    497e:	4d 85 e4             	test   %r12,%r12
    4981:	74 3b                	je     49be <fwp_format_g.constprop.0+0x2ee>
    4983:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4988:	eb 23                	jmp    49ad <fwp_format_g.constprop.0+0x2dd>
    498a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4991:	00 00 00 00 
    4995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    499c:	00 00 00 00 
    49a0:	c6 00 00             	movb   $0x0,(%rax)
    49a3:	48 83 e8 01          	sub    $0x1,%rax
    49a7:	49 83 ec 01          	sub    $0x1,%r12
    49ab:	74 11                	je     49be <fwp_format_g.constprop.0+0x2ee>
    49ad:	80 38 30             	cmpb   $0x30,(%rax)
    49b0:	74 ee                	je     49a0 <fwp_format_g.constprop.0+0x2d0>
    49b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49b8:	0f 84 fb 01 00 00    	je     4bb9 <fwp_format_g.constprop.0+0x4e9>
    49be:	44 89 c0             	mov    %r8d,%eax
    49c1:	ba 02 00 00 00       	mov    $0x2,%edx
    49c6:	49 89 e9             	mov    %rbp,%r9
    49c9:	be 90 01 00 00       	mov    $0x190,%esi
    49ce:	f7 d8                	neg    %eax
    49d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    49d7:	48 89 df             	mov    %rbx,%rdi
    49da:	41 0f 48 c0          	cmovs  %r8d,%eax
    49de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    49e2:	41 83 e0 02          	and    $0x2,%r8d
    49e6:	41 83 c0 2b          	add    $0x2b,%r8d
    49ea:	50                   	push   %rax
    49eb:	31 c0                	xor    %eax,%eax
    49ed:	41 50                	push   %r8
    49ef:	4c 8d 05 d7 a6 00 00 	lea    0xa6d7(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    49f6:	e8 95 e9 ff ff       	call   3390 <__snprintf_chk@plt>
    49fb:	58                   	pop    %rax
    49fc:	5a                   	pop    %rdx
    49fd:	e9 0e ff ff ff       	jmp    4910 <fwp_format_g.constprop.0+0x240>
    4a02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a08:	4d 8b 06             	mov    (%r14),%r8
    4a0b:	48 83 c0 09          	add    $0x9,%rax
    4a0f:	4c 89 f2             	mov    %r14,%rdx
    4a12:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a16:	4c 89 07             	mov    %r8,(%rdi)
    4a19:	45 89 e0             	mov    %r12d,%r8d
    4a1c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a21:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a26:	49 89 f8             	mov    %rdi,%r8
    4a29:	49 29 c0             	sub    %rax,%r8
    4a2c:	4c 29 c2             	sub    %r8,%rdx
    4a2f:	45 01 e0             	add    %r12d,%r8d
    4a32:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a36:	41 83 f8 08          	cmp    $0x8,%r8d
    4a3a:	0f 82 bc fd ff ff    	jb     47fc <fwp_format_g.constprop.0+0x12c>
    4a40:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a44:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a48:	45 31 d2             	xor    %r10d,%r10d
    4a4b:	45 89 d3             	mov    %r10d,%r11d
    4a4e:	41 83 c2 08          	add    $0x8,%r10d
    4a52:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a56:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a5a:	45 39 c2             	cmp    %r8d,%r10d
    4a5d:	72 ec                	jb     4a4b <fwp_format_g.constprop.0+0x37b>
    4a5f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4a63:	e9 94 fd ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4a68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a6f:	00 
    4a70:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4a75:	e9 96 fe ff ff       	jmp    4910 <fwp_format_g.constprop.0+0x240>
    4a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a80:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4a85:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4a89:	48 89 ee             	mov    %rbp,%rsi
    4a8c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4a90:	48 89 13             	mov    %rdx,(%rbx)
    4a93:	89 c2                	mov    %eax,%edx
    4a95:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4a9a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4a9f:	48 89 d9             	mov    %rbx,%rcx
    4aa2:	48 29 f9             	sub    %rdi,%rcx
    4aa5:	48 29 ce             	sub    %rcx,%rsi
    4aa8:	01 c1                	add    %eax,%ecx
    4aaa:	c1 e9 03             	shr    $0x3,%ecx
    4aad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4ab0:	e9 ce fd ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4ab5:	0f 1f 00             	nopl   (%rax)
    4ab8:	c6 00 30             	movb   $0x30,(%rax)
    4abb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4abf:	4c 89 fa             	mov    %r15,%rdx
    4ac2:	4c 89 e9             	mov    %r13,%rcx
    4ac5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4aca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4acf:	4c 89 14 24          	mov    %r10,(%rsp)
    4ad3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4ad8:	e8 63 ea ff ff       	call   3540 <__memcpy_chk@plt>
    4add:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4ae2:	b9 48 00 00 00       	mov    $0x48,%ecx
    4ae7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4aec:	48 89 c7             	mov    %rax,%rdi
    4aef:	4c 8b 14 24          	mov    (%rsp),%r10
    4af3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4af8:	4c 89 c8             	mov    %r9,%rax
    4afb:	4c 29 e8             	sub    %r13,%rax
    4afe:	48 39 c8             	cmp    %rcx,%rax
    4b01:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b05:	4d 29 cd             	sub    %r9,%r13
    4b08:	49 01 ff             	add    %rdi,%r15
    4b0b:	4c 01 e8             	add    %r13,%rax
    4b0e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b12:	74 3d                	je     4b51 <fwp_format_g.constprop.0+0x481>
    4b14:	41 f7 d0             	not    %r8d
    4b17:	31 f6                	xor    %esi,%esi
    4b19:	ba 48 00 00 00       	mov    $0x48,%edx
    4b1e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b23:	48 39 d0             	cmp    %rdx,%rax
    4b26:	48 0f 43 d0          	cmovae %rax,%rdx
    4b2a:	48 89 d1             	mov    %rdx,%rcx
    4b2d:	48 29 c1             	sub    %rax,%rcx
    4b30:	48 83 c1 01          	add    $0x1,%rcx
    4b34:	48 39 d1             	cmp    %rdx,%rcx
    4b37:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b3b:	48 83 e8 01          	sub    $0x1,%rax
    4b3f:	48 83 c6 01          	add    $0x1,%rsi
    4b43:	48 29 d0             	sub    %rdx,%rax
    4b46:	48 01 c8             	add    %rcx,%rax
    4b49:	41 39 f0             	cmp    %esi,%r8d
    4b4c:	7f cb                	jg     4b19 <fwp_format_g.constprop.0+0x449>
    4b4e:	4d 01 c7             	add    %r8,%r15
    4b51:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b56:	41 0f b6 12          	movzbl (%r10),%edx
    4b5a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b5e:	4c 89 f6             	mov    %r14,%rsi
    4b61:	48 39 c8             	cmp    %rcx,%rax
    4b64:	4c 89 1c 24          	mov    %r11,(%rsp)
    4b68:	48 0f 43 c8          	cmovae %rax,%rcx
    4b6c:	41 88 17             	mov    %dl,(%r15)
    4b6f:	48 89 ca             	mov    %rcx,%rdx
    4b72:	48 29 c2             	sub    %rax,%rdx
    4b75:	48 83 c2 01          	add    $0x1,%rdx
    4b79:	48 39 ca             	cmp    %rcx,%rdx
    4b7c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4b80:	48 83 e8 01          	sub    $0x1,%rax
    4b84:	48 29 c8             	sub    %rcx,%rax
    4b87:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4b8b:	49 63 d4             	movslq %r12d,%rdx
    4b8e:	e8 ad e9 ff ff       	call   3540 <__memcpy_chk@plt>
    4b93:	4c 8b 1c 24          	mov    (%rsp),%r11
    4b97:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4b9b:	e9 ae fc ff ff       	jmp    484e <fwp_format_g.constprop.0+0x17e>
    4ba0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4ba5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4baa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4baf:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bb4:	e9 f9 fb ff ff       	jmp    47b2 <fwp_format_g.constprop.0+0xe2>
    4bb9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bbf:	e9 fa fd ff ff       	jmp    49be <fwp_format_g.constprop.0+0x2ee>
    4bc4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4bc8:	89 13                	mov    %edx,(%rbx)
    4bca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4bce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4bd2:	e9 ac fc ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4bd7:	41 8b 06             	mov    (%r14),%eax
    4bda:	89 07                	mov    %eax,(%rdi)
    4bdc:	44 89 e0             	mov    %r12d,%eax
    4bdf:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4be4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4be9:	e9 0e fc ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4bee:	89 c2                	mov    %eax,%edx
    4bf0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4bf5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4bfa:	e9 84 fc ff ff       	jmp    4883 <fwp_format_g.constprop.0+0x1b3>
    4bff:	44 89 e0             	mov    %r12d,%eax
    4c02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c0e:	e9 e9 fb ff ff       	jmp    47fc <fwp_format_g.constprop.0+0x12c>
    4c13:	e8 28 e8 ff ff       	call   3440 <__stack_chk_fail@plt>
    4c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c1f:	00 

0000000000004c20 <fwp_heap_report>:
    4c20:	f3 0f 1e fa          	endbr64
    4c24:	41 54                	push   %r12
    4c26:	48 8d 3d af a4 00 00 	lea    0xa4af(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c2d:	55                   	push   %rbp
    4c2e:	53                   	push   %rbx
    4c2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c3d:	00 00 
    4c3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c46:	00 
    4c47:	48 8d 35 94 a5 00 00 	lea    0xa594(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c4e:	e8 9d e9 ff ff       	call   35f0 <fopen@plt>
    4c53:	48 85 c0             	test   %rax,%rax
    4c56:	0f 84 c5 00 00 00    	je     4d21 <fwp_heap_report+0x101>
    4c5c:	48 89 c5             	mov    %rax,%rbp
    4c5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4c66:	48 89 e3             	mov    %rsp,%rbx
    4c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4c70:	48 89 ea             	mov    %rbp,%rdx
    4c73:	be 00 01 00 00       	mov    $0x100,%esi
    4c78:	48 89 df             	mov    %rbx,%rdi
    4c7b:	e8 60 e8 ff ff       	call   34e0 <fgets@plt>
    4c80:	48 85 c0             	test   %rax,%rax
    4c83:	74 2b                	je     4cb0 <fwp_heap_report+0x90>
    4c85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4c8b:	75 e3                	jne    4c70 <fwp_heap_report+0x50>
    4c8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4c91:	75 dd                	jne    4c70 <fwp_heap_report+0x50>
    4c93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4c98:	75 d6                	jne    4c70 <fwp_heap_report+0x50>
    4c9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4c9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ca4:	31 f6                	xor    %esi,%esi
    4ca6:	e8 b5 e8 ff ff       	call   3560 <strtol@plt>
    4cab:	49 89 c4             	mov    %rax,%r12
    4cae:	eb c0                	jmp    4c70 <fwp_heap_report+0x50>
    4cb0:	48 89 ef             	mov    %rbp,%rdi
    4cb3:	e8 68 e7 ff ff       	call   3420 <fclose@plt>
    4cb8:	48 83 ec 08          	sub    $0x8,%rsp
    4cbc:	4c 8b 0d c5 fe 01 00 	mov    0x1fec5(%rip),%r9        # 24b88 <fwp_heap+0x13c8>
    4cc3:	4c 8b 05 1e ff 01 00 	mov    0x1ff1e(%rip),%r8        # 24be8 <fwp_heap+0x1428>
    4cca:	48 8d 15 df aa 00 00 	lea    0xaadf(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4cd1:	41 54                	push   %r12
    4cd3:	48 8b 0d 06 ff 01 00 	mov    0x1ff06(%rip),%rcx        # 24be0 <fwp_heap+0x1420>
    4cda:	be 02 00 00 00       	mov    $0x2,%esi
    4cdf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ce4:	f2 0f 10 0d 14 ff 01 	movsd  0x1ff14(%rip),%xmm1        # 24c00 <fwp_heap+0x1440>
    4ceb:	00 
    4cec:	f2 0f 10 05 04 ff 01 	movsd  0x1ff04(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    4cf3:	00 
    4cf4:	48 8b 3d 45 e3 00 00 	mov    0xe345(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4cfb:	e8 50 e9 ff ff       	call   3650 <__fprintf_chk@plt>
    4d00:	58                   	pop    %rax
    4d01:	5a                   	pop    %rdx
    4d02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d09:	00 
    4d0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d11:	00 00 
    4d13:	75 15                	jne    4d2a <fwp_heap_report+0x10a>
    4d15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d1c:	5b                   	pop    %rbx
    4d1d:	5d                   	pop    %rbp
    4d1e:	41 5c                	pop    %r12
    4d20:	c3                   	ret
    4d21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d28:	eb 8e                	jmp    4cb8 <fwp_heap_report+0x98>
    4d2a:	e8 11 e7 ff ff       	call   3440 <__stack_chk_fail@plt>
    4d2f:	90                   	nop

0000000000004d30 <fwp_heap_init>:
    4d30:	66 0f 6f 05 88 ae 00 	movdqa 0xae88(%rip),%xmm0        # fbc0 <msg.4+0x50>
    4d37:	00 
    4d38:	41 54                	push   %r12
    4d3a:	48 8d 05 bf f9 01 00 	lea    0x1f9bf(%rip),%rax        # 24700 <fwp_heap+0xf40>
    4d41:	ba 00 01 00 00       	mov    $0x100,%edx
    4d46:	55                   	push   %rbp
    4d47:	66 0f 6f 15 b1 ae 00 	movdqa 0xaeb1(%rip),%xmm2        # fc00 <msg.4+0x90>
    4d4e:	00 
    4d4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d53:	53                   	push   %rbx
    4d54:	0f 29 05 65 f9 01 00 	movaps %xmm0,0x1f965(%rip)        # 246c0 <fwp_heap+0xf00>
    4d5b:	66 0f 6f 05 6d ae 00 	movdqa 0xae6d(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4d62:	00 
    4d63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4d67:	c7 05 f3 fd 01 00 01 	movl   $0x1,0x1fdf3(%rip)        # 24b64 <fwp_heap+0x13a4>
    4d6e:	00 00 00 
    4d71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4d76:	0f 29 05 53 f9 01 00 	movaps %xmm0,0x1f953(%rip)        # 246d0 <fwp_heap+0xf10>
    4d7d:	66 0f 6f 05 5b ae 00 	movdqa 0xae5b(%rip),%xmm0        # fbe0 <msg.4+0x70>
    4d84:	00 
    4d85:	0f 29 05 54 f9 01 00 	movaps %xmm0,0x1f954(%rip)        # 246e0 <fwp_heap+0xf20>
    4d8c:	66 0f 6f 05 5c ae 00 	movdqa 0xae5c(%rip),%xmm0        # fbf0 <msg.4+0x80>
    4d93:	00 
    4d94:	0f 29 05 55 f9 01 00 	movaps %xmm0,0x1f955(%rip)        # 246f0 <fwp_heap+0xf30>
    4d9b:	89 d3                	mov    %edx,%ebx
    4d9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4da1:	48 83 c0 10          	add    $0x10,%rax
    4da5:	01 d2                	add    %edx,%edx
    4da7:	c1 eb 02             	shr    $0x2,%ebx
    4daa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4db3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4db7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4dc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4dc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4dc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4dce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4dd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4dd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4ddb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4ddf:	48 39 c7             	cmp    %rax,%rdi
    4de2:	75 b7                	jne    4d9b <fwp_heap_init+0x6b>
    4de4:	4c 8d 05 d5 e9 01 00 	lea    0x1e9d5(%rip),%r8        # 237c0 <fwp_heap>
    4deb:	31 c9                	xor    %ecx,%ecx
    4ded:	31 c0                	xor    %eax,%eax
    4def:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dfd:	00 00 00 
    4e00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e07:	00 
    4e08:	48 39 ca             	cmp    %rcx,%rdx
    4e0b:	73 0f                	jae    4e1c <fwp_heap_init+0xec>
    4e0d:	0f 1f 00             	nopl   (%rax)
    4e10:	48 83 c0 01          	add    $0x1,%rax
    4e14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e17:	48 39 ca             	cmp    %rcx,%rdx
    4e1a:	72 f4                	jb     4e10 <fwp_heap_init+0xe0>
    4e1c:	48 83 c1 10          	add    $0x10,%rcx
    4e20:	88 07                	mov    %al,(%rdi)
    4e22:	48 83 c7 01          	add    $0x1,%rdi
    4e26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e2d:	75 d1                	jne    4e00 <fwp_heap_init+0xd0>
    4e2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e36:	00 00 00 
    4e39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e45:	45 31 c9             	xor    %r9d,%r9d
    4e48:	31 d2                	xor    %edx,%edx
    4e4a:	31 ff                	xor    %edi,%edi
    4e4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e57:	4c 89 e6             	mov    %r12,%rsi
    4e5a:	e8 f1 e5 ff ff       	call   3450 <mmap@plt>
    4e5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4e63:	75 13                	jne    4e78 <fwp_heap_init+0x148>
    4e65:	48 c1 eb 02          	shr    $0x2,%rbx
    4e69:	83 ed 01             	sub    $0x1,%ebp
    4e6c:	75 d0                	jne    4e3e <fwp_heap_init+0x10e>
    4e6e:	e8 fd ed ff ff       	call   3c70 <fwp_heap_oom>
    4e73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e78:	48 85 c0             	test   %rax,%rax
    4e7b:	74 f1                	je     4e6e <fwp_heap_init+0x13e>
    4e7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4e81:	48 89 05 f0 fc 01 00 	mov    %rax,0x1fcf0(%rip)        # 24b78 <fwp_heap+0x13b8>
    4e88:	45 31 c9             	xor    %r9d,%r9d
    4e8b:	31 d2                	xor    %edx,%edx
    4e8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4e93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4e97:	31 ff                	xor    %edi,%edi
    4e99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e9f:	66 31 c0             	xor    %ax,%ax
    4ea2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ea6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eab:	4c 89 25 ce fc 01 00 	mov    %r12,0x1fcce(%rip)        # 24b80 <fwp_heap+0x13c0>
    4eb2:	48 89 05 b7 fc 01 00 	mov    %rax,0x1fcb7(%rip)        # 24b70 <fwp_heap+0x13b0>
    4eb9:	48 89 1d d0 fc 01 00 	mov    %rbx,0x1fcd0(%rip)        # 24b90 <fwp_heap+0x13d0>
    4ec0:	48 89 35 f9 fc 01 00 	mov    %rsi,0x1fcf9(%rip)        # 24bc0 <fwp_heap+0x1400>
    4ec7:	e8 84 e5 ff ff       	call   3450 <mmap@plt>
    4ecc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ed0:	74 9c                	je     4e6e <fwp_heap_init+0x13e>
    4ed2:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4ed9:	48 89 05 d8 fc 01 00 	mov    %rax,0x1fcd8(%rip)        # 24bb8 <fwp_heap+0x13f8>
    4ee0:	e8 9b e4 ff ff       	call   3380 <getenv@plt>
    4ee5:	48 89 c2             	mov    %rax,%rdx
    4ee8:	31 c0                	xor    %eax,%eax
    4eea:	48 85 d2             	test   %rdx,%rdx
    4eed:	74 15                	je     4f04 <fwp_heap_init+0x1d4>
    4eef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4ef2:	74 10                	je     4f04 <fwp_heap_init+0x1d4>
    4ef4:	0f b6 02             	movzbl (%rdx),%eax
    4ef7:	83 e8 30             	sub    $0x30,%eax
    4efa:	74 13                	je     4f0f <fwp_heap_init+0x1df>
    4efc:	85 c0                	test   %eax,%eax
    4efe:	0f 95 c0             	setne  %al
    4f01:	0f b6 c0             	movzbl %al,%eax
    4f04:	5b                   	pop    %rbx
    4f05:	5d                   	pop    %rbp
    4f06:	89 05 5c fc 01 00    	mov    %eax,0x1fc5c(%rip)        # 24b68 <fwp_heap+0x13a8>
    4f0c:	41 5c                	pop    %r12
    4f0e:	c3                   	ret
    4f0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f13:	85 c0                	test   %eax,%eax
    4f15:	0f 95 c0             	setne  %al
    4f18:	0f b6 c0             	movzbl %al,%eax
    4f1b:	eb e7                	jmp    4f04 <fwp_heap_init+0x1d4>
    4f1d:	0f 1f 00             	nopl   (%rax)

0000000000004f20 <fwp_wake_io>:
    4f20:	48 8b 07             	mov    (%rdi),%rax
    4f23:	48 85 c0             	test   %rax,%rax
    4f26:	0f 84 f4 00 00 00    	je     5020 <fwp_wake_io+0x100>
    4f2c:	53                   	push   %rbx
    4f2d:	4c 8b 05 4c e8 01 00 	mov    0x1e84c(%rip),%r8        # 23780 <fwp_ready_tail>
    4f34:	49 89 f9             	mov    %rdi,%r9
    4f37:	48 89 c2             	mov    %rax,%rdx
    4f3a:	45 31 db             	xor    %r11d,%r11d
    4f3d:	45 31 d2             	xor    %r10d,%r10d
    4f40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f44:	eb 71                	jmp    4fb7 <fwp_wake_io+0x97>
    4f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f4d:	00 00 00 
    4f50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f5e:	48 85 c9             	test   %rcx,%rcx
    4f61:	74 07                	je     4f6a <fwp_wake_io+0x4a>
    4f63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4f6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4f71:	00 00 00 00 
    4f75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4f7c:	49 8b 01             	mov    (%r9),%rax
    4f7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4f83:	75 2a                	jne    4faf <fwp_wake_io+0x8f>
    4f85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4f89:	75 24                	jne    4faf <fwp_wake_io+0x8f>
    4f8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4f8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4f96:	00 00 00 00 
    4f9a:	4d 85 c0             	test   %r8,%r8
    4f9d:	74 51                	je     4ff0 <fwp_wake_io+0xd0>
    4f9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fa6:	49 89 d0             	mov    %rdx,%r8
    4fa9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4faf:	48 89 c2             	mov    %rax,%rdx
    4fb2:	48 85 c0             	test   %rax,%rax
    4fb5:	74 49                	je     5000 <fwp_wake_io+0xe0>
    4fb7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4fbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4fc2:	48 85 ff             	test   %rdi,%rdi
    4fc5:	74 b8                	je     4f7f <fwp_wake_io+0x5f>
    4fc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4fce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fd5:	48 85 f6             	test   %rsi,%rsi
    4fd8:	0f 85 72 ff ff ff    	jne    4f50 <fwp_wake_io+0x30>
    4fde:	48 89 0f             	mov    %rcx,(%rdi)
    4fe1:	e9 78 ff ff ff       	jmp    4f5e <fwp_wake_io+0x3e>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 d3             	mov    %rdx,%rbx
    4ff3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4ff9:	eb ab                	jmp    4fa6 <fwp_wake_io+0x86>
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	45 84 db             	test   %r11b,%r11b
    5003:	74 07                	je     500c <fwp_wake_io+0xec>
    5005:	48 89 1d 7c e7 01 00 	mov    %rbx,0x1e77c(%rip)        # 23788 <fwp_ready_head>
    500c:	45 84 d2             	test   %r10b,%r10b
    500f:	74 07                	je     5018 <fwp_wake_io+0xf8>
    5011:	4c 89 05 68 e7 01 00 	mov    %r8,0x1e768(%rip)        # 23780 <fwp_ready_tail>
    5018:	5b                   	pop    %rbx
    5019:	c3                   	ret
    501a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5020:	c3                   	ret
    5021:	0f 1f 40 00          	nopl   0x0(%rax)
    5025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    502c:	00 00 00 00 

0000000000005030 <fwp_tape_buffers_release>:
    5030:	f3 0f 1e fa          	endbr64
    5034:	53                   	push   %rbx
    5035:	48 89 fb             	mov    %rdi,%rbx
    5038:	48 83 ec 10          	sub    $0x10,%rsp
    503c:	48 8b 47 18          	mov    0x18(%rdi),%rax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	0f 88 cf 00 00 00    	js     5118 <fwp_tape_buffers_release+0xe8>
    5049:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    504d:	48 85 d2             	test   %rdx,%rdx
    5050:	0f 88 c2 00 00 00    	js     5118 <fwp_tape_buffers_release+0xe8>
    5056:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    505c:	0f 87 b6 00 00 00    	ja     5118 <fwp_tape_buffers_release+0xe8>
    5062:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5066:	b8 00 00 08 00       	mov    $0x80000,%eax
    506b:	48 c1 e1 03          	shl    $0x3,%rcx
    506f:	48 29 c8             	sub    %rcx,%rax
    5072:	48 c1 e8 03          	shr    $0x3,%rax
    5076:	48 39 d0             	cmp    %rdx,%rax
    5079:	0f 82 99 00 00 00    	jb     5118 <fwp_tape_buffers_release+0xe8>
    507f:	48 8d 3d 9c a0 00 00 	lea    0xa09c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    5086:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    508b:	48 89 14 24          	mov    %rdx,(%rsp)
    508f:	e8 ec e2 ff ff       	call   3380 <getenv@plt>
    5094:	48 8b 14 24          	mov    (%rsp),%rdx
    5098:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    509d:	48 85 c0             	test   %rax,%rax
    50a0:	74 09                	je     50ab <fwp_tape_buffers_release+0x7b>
    50a2:	80 38 30             	cmpb   $0x30,(%rax)
    50a5:	0f 84 8d 00 00 00    	je     5138 <fwp_tape_buffers_release+0x108>
    50ab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50af:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50b3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50ba:	77 68                	ja     5124 <fwp_tape_buffers_release+0xf4>
    50bc:	48 8d 3d dd df 01 00 	lea    0x1dfdd(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    50c3:	48 89 04 24          	mov    %rax,(%rsp)
    50c7:	e8 04 f0 ff ff       	call   40d0 <fwp_tape_buffers_dispose>
    50cc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    50d0:	48 8b 04 24          	mov    (%rsp),%rax
    50d4:	0f 29 05 c5 df 01 00 	movaps %xmm0,0x1dfc5(%rip)        # 230a0 <fwp_tape_workspace>
    50db:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    50e0:	48 89 05 a1 df 01 00 	mov    %rax,0x1dfa1(%rip)        # 23088 <fwp_tape_cached_bytes>
    50e7:	0f 29 05 c2 df 01 00 	movaps %xmm0,0x1dfc2(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    50ee:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    50f2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50f6:	48 89 15 c3 df 01 00 	mov    %rdx,0x1dfc3(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    50fd:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    5104:	00 
    5105:	0f 11 03             	movups %xmm0,(%rbx)
    5108:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    510c:	48 83 c4 10          	add    $0x10,%rsp
    5110:	5b                   	pop    %rbx
    5111:	c3                   	ret
    5112:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5118:	48 8d 3d 03 a0 00 00 	lea    0xa003(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    511f:	e8 5c e2 ff ff       	call   3380 <getenv@plt>
    5124:	48 83 c4 10          	add    $0x10,%rsp
    5128:	48 89 df             	mov    %rbx,%rdi
    512b:	5b                   	pop    %rbx
    512c:	e9 9f ef ff ff       	jmp    40d0 <fwp_tape_buffers_dispose>
    5131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5138:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    513c:	0f 85 69 ff ff ff    	jne    50ab <fwp_tape_buffers_release+0x7b>
    5142:	48 83 c4 10          	add    $0x10,%rsp
    5146:	48 89 df             	mov    %rbx,%rdi
    5149:	5b                   	pop    %rbx
    514a:	e9 81 ef ff ff       	jmp    40d0 <fwp_tape_buffers_dispose>
    514f:	90                   	nop

0000000000005150 <fwp_poll_events>:
    5150:	53                   	push   %rbx
    5151:	48 83 ec 20          	sub    $0x20,%rsp
    5155:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    515c:	00 00 
    515e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5163:	31 c0                	xor    %eax,%eax
    5165:	e8 b6 f3 ff ff       	call   4520 <fwp_now_ns>
    516a:	48 8b 1d 07 e6 01 00 	mov    0x1e607(%rip),%rbx        # 23778 <fwp_timers>
    5171:	48 85 db             	test   %rbx,%rbx
    5174:	0f 84 e6 00 00 00    	je     5260 <fwp_poll_events+0x110>
    517a:	48 89 c6             	mov    %rax,%rsi
    517d:	48 89 da             	mov    %rbx,%rdx
    5180:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5187:	eb 26                	jmp    51af <fwp_poll_events+0x5f>
    5189:	90                   	nop
    518a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5191:	00 00 00 00 
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51a7:	48 89 c8             	mov    %rcx,%rax
    51aa:	48 85 d2             	test   %rdx,%rdx
    51ad:	74 31                	je     51e0 <fwp_poll_events+0x90>
    51af:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51b3:	48 85 c0             	test   %rax,%rax
    51b6:	78 e8                	js     51a0 <fwp_poll_events+0x50>
    51b8:	48 39 c1             	cmp    %rax,%rcx
    51bb:	7c e3                	jl     51a0 <fwp_poll_events+0x50>
    51bd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51c4:	48 85 d2             	test   %rdx,%rdx
    51c7:	74 1c                	je     51e5 <fwp_poll_events+0x95>
    51c9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51cd:	48 39 c1             	cmp    %rax,%rcx
    51d0:	7c ce                	jl     51a0 <fwp_poll_events+0x50>
    51d2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51d9:	48 85 d2             	test   %rdx,%rdx
    51dc:	75 d1                	jne    51af <fwp_poll_events+0x5f>
    51de:	66 90                	xchg   %ax,%ax
    51e0:	48 85 c0             	test   %rax,%rax
    51e3:	78 7b                	js     5260 <fwp_poll_events+0x110>
    51e5:	48 29 f0             	sub    %rsi,%rax
    51e8:	48 89 c1             	mov    %rax,%rcx
    51eb:	48 85 c0             	test   %rax,%rax
    51ee:	0f 8e 9c 00 00 00    	jle    5290 <fwp_poll_events+0x140>
    51f4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    51fb:	de 1b 43 
    51fe:	48 f7 ea             	imul   %rdx
    5201:	48 89 c8             	mov    %rcx,%rax
    5204:	48 c1 f8 3f          	sar    $0x3f,%rax
    5208:	48 c1 fa 12          	sar    $0x12,%rdx
    520c:	48 29 c2             	sub    %rax,%rdx
    520f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5216:	48 39 c1             	cmp    %rax,%rcx
    5219:	0f 95 c0             	setne  %al
    521c:	0f b6 c0             	movzbl %al,%eax
    521f:	48 01 d0             	add    %rdx,%rax
    5222:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5228:	0f 8f 32 01 00 00    	jg     5360 <fwp_poll_events+0x210>
    522e:	48 85 c0             	test   %rax,%rax
    5231:	74 5d                	je     5290 <fwp_poll_events+0x140>
    5233:	89 c1                	mov    %eax,%ecx
    5235:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    523c:	48 c1 e9 26          	shr    $0x26,%rcx
    5240:	48 63 d1             	movslq %ecx,%rdx
    5243:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5249:	29 c8                	sub    %ecx,%eax
    524b:	48 98                	cltq
    524d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5254:	e9 11 01 00 00       	jmp    536a <fwp_poll_events+0x21a>
    5259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5260:	e8 cb e9 ff ff       	call   3c30 <fwp_flush>
    5265:	ba 2b 00 00 00       	mov    $0x2b,%edx
    526a:	be 01 00 00 00       	mov    $0x1,%esi
    526f:	48 8b 0d ca dd 00 00 	mov    0xddca(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5276:	48 8d 3d bb a5 00 00 	lea    0xa5bb(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    527d:	e8 be e3 ff ff       	call   3640 <fwrite@plt>
    5282:	bf 65 00 00 00       	mov    $0x65,%edi
    5287:	e8 a4 e3 ff ff       	call   3630 <exit@plt>
    528c:	0f 1f 40 00          	nopl   0x0(%rax)
    5290:	e8 8b f2 ff ff       	call   4520 <fwp_now_ns>
    5295:	48 89 c1             	mov    %rax,%rcx
    5298:	66 0f ef c0          	pxor   %xmm0,%xmm0
    529c:	eb 44                	jmp    52e2 <fwp_poll_events+0x192>
    529e:	66 90                	xchg   %ax,%ax
    52a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52a4:	75 33                	jne    52d9 <fwp_poll_events+0x189>
    52a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52aa:	75 2d                	jne    52d9 <fwp_poll_events+0x189>
    52ac:	48 8b 05 cd e4 01 00 	mov    0x1e4cd(%rip),%rax        # 23780 <fwp_ready_tail>
    52b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52be:	00 00 00 00 
    52c2:	48 85 c0             	test   %rax,%rax
    52c5:	0f 84 05 01 00 00    	je     53d0 <fwp_poll_events+0x280>
    52cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    52d2:	48 89 15 a7 e4 01 00 	mov    %rdx,0x1e4a7(%rip)        # 23780 <fwp_ready_tail>
    52d9:	48 85 db             	test   %rbx,%rbx
    52dc:	0f 84 be 00 00 00    	je     53a0 <fwp_poll_events+0x250>
    52e2:	48 89 da             	mov    %rbx,%rdx
    52e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    52ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    52f0:	7f e7                	jg     52d9 <fwp_poll_events+0x189>
    52f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    52f6:	74 2e                	je     5326 <fwp_poll_events+0x1d6>
    52f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    52ff:	48 85 c0             	test   %rax,%rax
    5302:	0f 84 b8 00 00 00    	je     53c0 <fwp_poll_events+0x270>
    5308:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    530f:	48 85 db             	test   %rbx,%rbx
    5312:	74 07                	je     531b <fwp_poll_events+0x1cb>
    5314:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    531b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    531f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5326:	48 8b 42 60          	mov    0x60(%rdx),%rax
    532a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    532e:	48 85 c0             	test   %rax,%rax
    5331:	0f 84 69 ff ff ff    	je     52a0 <fwp_poll_events+0x150>
    5337:	48 39 c8             	cmp    %rcx,%rax
    533a:	0f 8f 60 ff ff ff    	jg     52a0 <fwp_poll_events+0x150>
    5340:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5344:	0f 85 56 ff ff ff    	jne    52a0 <fwp_poll_events+0x150>
    534a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534e:	75 89                	jne    52d9 <fwp_poll_events+0x189>
    5350:	48 89 d7             	mov    %rdx,%rdi
    5353:	e8 68 ef ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    5358:	e9 43 ff ff ff       	jmp    52a0 <fwp_poll_events+0x150>
    535d:	0f 1f 00             	nopl   (%rax)
    5360:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5365:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    536a:	48 89 e7             	mov    %rsp,%rdi
    536d:	31 f6                	xor    %esi,%esi
    536f:	48 89 14 24          	mov    %rdx,(%rsp)
    5373:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5378:	e8 03 e1 ff ff       	call   3480 <nanosleep@plt>
    537d:	48 8b 1d f4 e3 01 00 	mov    0x1e3f4(%rip),%rbx        # 23778 <fwp_timers>
    5384:	e8 97 f1 ff ff       	call   4520 <fwp_now_ns>
    5389:	48 89 c1             	mov    %rax,%rcx
    538c:	48 85 db             	test   %rbx,%rbx
    538f:	0f 85 03 ff ff ff    	jne    5298 <fwp_poll_events+0x148>
    5395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    539c:	00 00 00 00 
    53a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ac:	00 00 
    53ae:	75 2c                	jne    53dc <fwp_poll_events+0x28c>
    53b0:	48 83 c4 20          	add    $0x20,%rsp
    53b4:	5b                   	pop    %rbx
    53b5:	c3                   	ret
    53b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53bd:	00 00 00 
    53c0:	48 89 1d b1 e3 01 00 	mov    %rbx,0x1e3b1(%rip)        # 23778 <fwp_timers>
    53c7:	e9 43 ff ff ff       	jmp    530f <fwp_poll_events+0x1bf>
    53cc:	0f 1f 40 00          	nopl   0x0(%rax)
    53d0:	48 89 15 b1 e3 01 00 	mov    %rdx,0x1e3b1(%rip)        # 23788 <fwp_ready_head>
    53d7:	e9 f6 fe ff ff       	jmp    52d2 <fwp_poll_events+0x182>
    53dc:	e8 5f e0 ff ff       	call   3440 <__stack_chk_fail@plt>
    53e1:	0f 1f 40 00          	nopl   0x0(%rax)
    53e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53ec:	00 00 00 00 

00000000000053f0 <fwp_rc_wide_dup>:
    53f0:	48 89 fa             	mov    %rdi,%rdx
    53f3:	48 8d 35 c6 e3 01 00 	lea    0x1e3c6(%rip),%rsi        # 237c0 <fwp_heap>
    53fa:	48 83 ec 18          	sub    $0x18,%rsp
    53fe:	48 89 f9             	mov    %rdi,%rcx
    5401:	48 c1 ea 11          	shr    $0x11,%rdx
    5405:	48 31 fa             	xor    %rdi,%rdx
    5408:	48 89 d0             	mov    %rdx,%rax
    540b:	48 c1 e8 09          	shr    $0x9,%rax
    540f:	48 31 c2             	xor    %rax,%rdx
    5412:	0f b6 d2             	movzbl %dl,%edx
    5415:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    541c:	00 
    541d:	49 8b 00             	mov    (%r8),%rax
    5420:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5427:	00 00 
    5429:	75 21                	jne    544c <fwp_rc_wide_dup+0x5c>
    542b:	e9 98 00 00 00       	jmp    54c8 <fwp_rc_wide_dup+0xd8>
    5430:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5444:	48 85 d2             	test   %rdx,%rdx
    5447:	74 2f                	je     5478 <fwp_rc_wide_dup+0x88>
    5449:	48 89 d0             	mov    %rdx,%rax
    544c:	48 3b 08             	cmp    (%rax),%rcx
    544f:	75 ef                	jne    5440 <fwp_rc_wide_dup+0x50>
    5451:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5454:	74 7c                	je     54d2 <fwp_rc_wide_dup+0xe2>
    5456:	48 8b 50 08          	mov    0x8(%rax),%rdx
    545a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    545e:	0f 84 91 00 00 00    	je     54f5 <fwp_rc_wide_dup+0x105>
    5464:	48 83 c2 01          	add    $0x1,%rdx
    5468:	48 89 50 08          	mov    %rdx,0x8(%rax)
    546c:	48 83 c4 18          	add    $0x18,%rsp
    5470:	c3                   	ret
    5471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5478:	4c 8d 40 10          	lea    0x10(%rax),%r8
    547c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    547f:	75 68                	jne    54e9 <fwp_rc_wide_dup+0xf9>
    5481:	bf 18 00 00 00       	mov    $0x18,%edi
    5486:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    548b:	4c 89 04 24          	mov    %r8,(%rsp)
    548f:	e8 ec e0 ff ff       	call   3580 <malloc@plt>
    5494:	4c 8b 04 24          	mov    (%rsp),%r8
    5498:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    549d:	48 85 c0             	test   %rax,%rax
    54a0:	74 5f                	je     5501 <fwp_rc_wide_dup+0x111>
    54a2:	48 89 08             	mov    %rcx,(%rax)
    54a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ac:	00 
    54ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54b4:	00 
    54b5:	49 89 00             	mov    %rax,(%r8)
    54b8:	c6 01 ff             	movb   $0xff,(%rcx)
    54bb:	48 83 05 45 ff 01 00 	addq   $0x1,0x1ff45(%rip)        # 25408 <fwp_heap+0x1c48>
    54c2:	01 
    54c3:	48 83 c4 18          	add    $0x18,%rsp
    54c7:	c3                   	ret
    54c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    54cb:	75 13                	jne    54e0 <fwp_rc_wide_dup+0xf0>
    54cd:	48 85 c0             	test   %rax,%rax
    54d0:	74 af                	je     5481 <fwp_rc_wide_dup+0x91>
    54d2:	48 8d 3d 8f a3 00 00 	lea    0xa38f(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    54d9:	e8 d2 ee ff ff       	call   43b0 <fwp_trap>
    54de:	66 90                	xchg   %ax,%ax
    54e0:	48 85 c0             	test   %rax,%rax
    54e3:	0f 85 6d ff ff ff    	jne    5456 <fwp_rc_wide_dup+0x66>
    54e9:	48 8d 3d a0 a3 00 00 	lea    0xa3a0(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    54f0:	e8 bb ee ff ff       	call   43b0 <fwp_trap>
    54f5:	48 8d 3d 37 9c 00 00 	lea    0x9c37(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    54fc:	e8 af ee ff ff       	call   43b0 <fwp_trap>
    5501:	e8 6a e7 ff ff       	call   3c70 <fwp_heap_oom>
    5506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    550d:	00 00 00 

0000000000005510 <fwp_rc_forget_slot>:
    5510:	80 3f ff             	cmpb   $0xff,(%rdi)
    5513:	74 0b                	je     5520 <fwp_rc_forget_slot+0x10>
    5515:	c3                   	ret
    5516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    551d:	00 00 00 
    5520:	48 89 f8             	mov    %rdi,%rax
    5523:	48 83 ec 08          	sub    $0x8,%rsp
    5527:	48 89 fa             	mov    %rdi,%rdx
    552a:	48 c1 e8 11          	shr    $0x11,%rax
    552e:	48 31 f8             	xor    %rdi,%rax
    5531:	48 89 c1             	mov    %rax,%rcx
    5534:	48 c1 e9 09          	shr    $0x9,%rcx
    5538:	48 31 c8             	xor    %rcx,%rax
    553b:	48 8d 0d 7e e2 01 00 	lea    0x1e27e(%rip),%rcx        # 237c0 <fwp_heap>
    5542:	0f b6 c0             	movzbl %al,%eax
    5545:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    554c:	00 
    554d:	48 85 ff             	test   %rdi,%rdi
    5550:	74 3c                	je     558e <fwp_rc_forget_slot+0x7e>
    5552:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5559:	00 
    555a:	48 8b 01             	mov    (%rcx),%rax
    555d:	eb 11                	jmp    5570 <fwp_rc_forget_slot+0x60>
    555f:	90                   	nop
    5560:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5564:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5568:	48 85 ff             	test   %rdi,%rdi
    556b:	74 21                	je     558e <fwp_rc_forget_slot+0x7e>
    556d:	48 89 f8             	mov    %rdi,%rax
    5570:	48 3b 10             	cmp    (%rax),%rdx
    5573:	75 eb                	jne    5560 <fwp_rc_forget_slot+0x50>
    5575:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5579:	48 89 01             	mov    %rax,(%rcx)
    557c:	e8 1f de ff ff       	call   33a0 <free@plt>
    5581:	48 83 2d 7f fe 01 00 	subq   $0x1,0x1fe7f(%rip)        # 25408 <fwp_heap+0x1c48>
    5588:	01 
    5589:	48 83 c4 08          	add    $0x8,%rsp
    558d:	c3                   	ret
    558e:	48 8d 3d fb a2 00 00 	lea    0xa2fb(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5595:	e8 16 ee ff ff       	call   43b0 <fwp_trap>
    559a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055a0 <fwp_rc_prepare_chunk>:
    55a0:	48 83 3d 60 fe 01 00 	cmpq   $0x0,0x1fe60(%rip)        # 25408 <fwp_heap+0x1c48>
    55a7:	00 
    55a8:	41 54                	push   %r12
    55aa:	49 89 f4             	mov    %rsi,%r12
    55ad:	55                   	push   %rbp
    55ae:	48 89 fd             	mov    %rdi,%rbp
    55b1:	53                   	push   %rbx
    55b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55b5:	0f 84 7d 00 00 00    	je     5638 <fwp_rc_prepare_chunk+0x98>
    55bb:	31 db                	xor    %ebx,%ebx
    55bd:	85 c0                	test   %eax,%eax
    55bf:	75 5f                	jne    5620 <fwp_rc_prepare_chunk+0x80>
    55c1:	48 85 f6             	test   %rsi,%rsi
    55c4:	74 7c                	je     5642 <fwp_rc_prepare_chunk+0xa2>
    55c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    55ca:	e8 d1 dd ff ff       	call   33a0 <free@plt>
    55cf:	90                   	nop
    55d0:	be 01 00 00 00       	mov    $0x1,%esi
    55d5:	4c 89 e7             	mov    %r12,%rdi
    55d8:	e8 23 df ff ff       	call   3500 <calloc@plt>
    55dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    55e1:	48 85 c0             	test   %rax,%rax
    55e4:	0f 85 87 00 00 00    	jne    5671 <fwp_rc_prepare_chunk+0xd1>
    55ea:	e8 81 e6 ff ff       	call   3c70 <fwp_heap_oom>
    55ef:	90                   	nop
    55f0:	e8 1b ff ff ff       	call   5510 <fwp_rc_forget_slot>
    55f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    55f8:	48 83 c3 01          	add    $0x1,%rbx
    55fc:	48 39 c3             	cmp    %rax,%rbx
    55ff:	73 37                	jae    5638 <fwp_rc_prepare_chunk+0x98>
    5601:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5608:	00 00 
    560a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5611:	00 00 00 00 
    5615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    561c:	00 00 00 00 
    5620:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5624:	48 01 df             	add    %rbx,%rdi
    5627:	80 3f ff             	cmpb   $0xff,(%rdi)
    562a:	74 c4                	je     55f0 <fwp_rc_prepare_chunk+0x50>
    562c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    562f:	48 83 c3 01          	add    $0x1,%rbx
    5633:	48 39 c3             	cmp    %rax,%rbx
    5636:	72 e8                	jb     5620 <fwp_rc_prepare_chunk+0x80>
    5638:	49 39 c4             	cmp    %rax,%r12
    563b:	75 13                	jne    5650 <fwp_rc_prepare_chunk+0xb0>
    563d:	4d 85 e4             	test   %r12,%r12
    5640:	75 46                	jne    5688 <fwp_rc_prepare_chunk+0xe8>
    5642:	5b                   	pop    %rbx
    5643:	5d                   	pop    %rbp
    5644:	41 5c                	pop    %r12
    5646:	c3                   	ret
    5647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    564e:	00 00 
    5650:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5654:	48 29 05 b5 fd 01 00 	sub    %rax,0x1fdb5(%rip)        # 25410 <fwp_heap+0x1c50>
    565b:	e8 40 dd ff ff       	call   33a0 <free@plt>
    5660:	4d 85 e4             	test   %r12,%r12
    5663:	0f 85 67 ff ff ff    	jne    55d0 <fwp_rc_prepare_chunk+0x30>
    5669:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5670:	00 
    5671:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5675:	5b                   	pop    %rbx
    5676:	4c 01 25 93 fd 01 00 	add    %r12,0x1fd93(%rip)        # 25410 <fwp_heap+0x1c50>
    567d:	5d                   	pop    %rbp
    567e:	41 5c                	pop    %r12
    5680:	c3                   	ret
    5681:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5688:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    568c:	5b                   	pop    %rbx
    568d:	4c 89 e2             	mov    %r12,%rdx
    5690:	31 f6                	xor    %esi,%esi
    5692:	5d                   	pop    %rbp
    5693:	41 5c                	pop    %r12
    5695:	e9 06 de ff ff       	jmp    34a0 <memset@plt>
    569a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056a0 <fwp_heap_refill>:
    56a0:	41 56                	push   %r14
    56a2:	41 89 d6             	mov    %edx,%r14d
    56a5:	41 55                	push   %r13
    56a7:	41 89 f5             	mov    %esi,%r13d
    56aa:	41 54                	push   %r12
    56ac:	49 89 fc             	mov    %rdi,%r12
    56af:	bf 01 00 00 00       	mov    $0x1,%edi
    56b4:	55                   	push   %rbp
    56b5:	53                   	push   %rbx
    56b6:	e8 85 e8 ff ff       	call   3f40 <fwp_heap_chunks>
    56bb:	48 89 c3             	mov    %rax,%rbx
    56be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    56c2:	48 8b 05 ef f4 01 00 	mov    0x1f4ef(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    56c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    56cd:	48 8d 05 ec e0 01 00 	lea    0x1e0ec(%rip),%rax        # 237c0 <fwp_heap>
    56d4:	31 d2                	xor    %edx,%edx
    56d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    56da:	48 89 ef             	mov    %rbp,%rdi
    56dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    56e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    56e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    56ec:	00 
    56ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    56f2:	f7 f1                	div    %ecx
    56f4:	31 d2                	xor    %edx,%edx
    56f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    56fa:	66 0f 6e c8          	movd   %eax,%xmm1
    56fe:	89 c6                	mov    %eax,%esi
    5700:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5705:	48 01 c8             	add    %rcx,%rax
    5708:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    570c:	48 f7 f1             	div    %rcx
    570f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5714:	89 45 18             	mov    %eax,0x18(%rbp)
    5717:	e8 84 fe ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    571c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    571f:	48 89 d8             	mov    %rbx,%rax
    5722:	48 c1 e0 10          	shl    $0x10,%rax
    5726:	48 03 05 43 f4 01 00 	add    0x1f443(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    572d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5731:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5736:	8b 55 08             	mov    0x8(%rbp),%edx
    5739:	48 0f af d1          	imul   %rcx,%rdx
    573d:	48 01 c2             	add    %rax,%rdx
    5740:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5745:	5b                   	pop    %rbx
    5746:	5d                   	pop    %rbp
    5747:	41 5c                	pop    %r12
    5749:	41 5d                	pop    %r13
    574b:	41 5e                	pop    %r14
    574d:	c3                   	ret
    574e:	66 90                	xchg   %ax,%ax

0000000000005750 <fwp_mem_free>:
    5750:	48 85 ff             	test   %rdi,%rdi
    5753:	0f 84 17 02 00 00    	je     5970 <fwp_mem_free+0x220>
    5759:	48 8b 35 10 f4 01 00 	mov    0x1f410(%rip),%rsi        # 24b70 <fwp_heap+0x13b0>
    5760:	48 8b 05 31 f4 01 00 	mov    0x1f431(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    5767:	48 89 fa             	mov    %rdi,%rdx
    576a:	48 29 f2             	sub    %rsi,%rdx
    576d:	48 c1 e0 10          	shl    $0x10,%rax
    5771:	48 39 c2             	cmp    %rax,%rdx
    5774:	0f 83 f6 01 00 00    	jae    5970 <fwp_mem_free+0x220>
    577a:	49 89 d1             	mov    %rdx,%r9
    577d:	49 c1 e9 10          	shr    $0x10,%r9
    5781:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5785:	48 c1 e0 03          	shl    $0x3,%rax
    5789:	49 89 c0             	mov    %rax,%r8
    578c:	4c 03 05 25 f4 01 00 	add    0x1f425(%rip),%r8        # 24bb8 <fwp_heap+0x13f8>
    5793:	0f 84 d7 01 00 00    	je     5970 <fwp_mem_free+0x220>
    5799:	48 83 ec 38          	sub    $0x38,%rsp
    579d:	48 89 f9             	mov    %rdi,%rcx
    57a0:	41 0f b6 38          	movzbl (%r8),%edi
    57a4:	40 80 ff 01          	cmp    $0x1,%dil
    57a8:	74 16                	je     57c0 <fwp_mem_free+0x70>
    57aa:	40 80 ff 02          	cmp    $0x2,%dil
    57ae:	0f 84 94 00 00 00    	je     5848 <fwp_mem_free+0xf8>
    57b4:	48 83 c4 38          	add    $0x38,%rsp
    57b8:	c3                   	ret
    57b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    57c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    57c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    57c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    57ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    57d2:	4d 85 d2             	test   %r10,%r10
    57d5:	74 1d                	je     57f4 <fwp_mem_free+0xa4>
    57d7:	0f b7 c1             	movzwl %cx,%eax
    57da:	31 d2                	xor    %edx,%edx
    57dc:	48 f7 f7             	div    %rdi
    57df:	49 01 c2             	add    %rax,%r10
    57e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    57e6:	0f 84 44 01 00 00    	je     5930 <fwp_mem_free+0x1e0>
    57ec:	41 c6 02 00          	movb   $0x0,(%r10)
    57f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    57f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    57fb:	49 63 c1             	movslq %r9d,%rax
    57fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5802:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5806:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    580b:	f2 0f 58 05 ed f3 01 	addsd  0x1f3ed(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    5812:	00 
    5813:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5817:	48 8d 05 a2 df 01 00 	lea    0x1dfa2(%rip),%rax        # 237c0 <fwp_heap>
    581e:	48 01 d0             	add    %rdx,%rax
    5821:	48 8b 10             	mov    (%rax),%rdx
    5824:	48 f7 d2             	not    %rdx
    5827:	48 89 11             	mov    %rdx,(%rcx)
    582a:	48 89 08             	mov    %rcx,(%rax)
    582d:	48 29 3d ac f3 01 00 	sub    %rdi,0x1f3ac(%rip)        # 24be0 <fwp_heap+0x1420>
    5834:	f2 0f 11 05 c4 f3 01 	movsd  %xmm0,0x1f3c4(%rip)        # 24c00 <fwp_heap+0x1440>
    583b:	00 
    583c:	48 83 c4 38          	add    $0x38,%rsp
    5840:	c3                   	ret
    5841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5848:	66 31 d2             	xor    %dx,%dx
    584b:	48 01 d6             	add    %rdx,%rsi
    584e:	48 39 f1             	cmp    %rsi,%rcx
    5851:	0f 85 5d ff ff ff    	jne    57b4 <fwp_mem_free+0x64>
    5857:	49 8b 50 10          	mov    0x10(%r8),%rdx
    585b:	48 29 15 7e f3 01 00 	sub    %rdx,0x1f37e(%rip)        # 24be0 <fwp_heap+0x1420>
    5862:	48 85 d2             	test   %rdx,%rdx
    5865:	0f 88 a5 00 00 00    	js     5910 <fwp_mem_free+0x1c0>
    586b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    586f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5874:	f2 0f 58 05 84 f3 01 	addsd  0x1f384(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5880:	f2 0f 11 05 78 f3 01 	movsd  %xmm0,0x1f378(%rip)        # 24c00 <fwp_heap+0x1440>
    5887:	00 
    5888:	48 85 d2             	test   %rdx,%rdx
    588b:	74 0c                	je     5899 <fwp_mem_free+0x149>
    588d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5890:	0f 84 db 00 00 00    	je     5971 <fwp_mem_free+0x221>
    5896:	c6 02 00             	movb   $0x0,(%rdx)
    5899:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    589d:	48 85 c9             	test   %rcx,%rcx
    58a0:	74 3e                	je     58e0 <fwp_mem_free+0x190>
    58a2:	48 8b 15 0f f3 01 00 	mov    0x1f30f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    58a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58b1:	48 01 d0             	add    %rdx,%rax
    58b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58b8:	48 89 d6             	mov    %rdx,%rsi
    58bb:	48 29 c6             	sub    %rax,%rsi
    58be:	83 e6 08             	and    $0x8,%esi
    58c1:	74 0d                	je     58d0 <fwp_mem_free+0x180>
    58c3:	c6 00 00             	movb   $0x0,(%rax)
    58c6:	48 83 c0 28          	add    $0x28,%rax
    58ca:	48 39 c2             	cmp    %rax,%rdx
    58cd:	74 11                	je     58e0 <fwp_mem_free+0x190>
    58cf:	90                   	nop
    58d0:	c6 00 00             	movb   $0x0,(%rax)
    58d3:	48 83 c0 50          	add    $0x50,%rax
    58d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    58db:	48 39 c2             	cmp    %rax,%rdx
    58de:	75 f0                	jne    58d0 <fwp_mem_free+0x180>
    58e0:	48 01 0d 09 f3 01 00 	add    %rcx,0x1f309(%rip)        # 24bf0 <fwp_heap+0x1430>
    58e7:	4c 3b 0d c2 f2 01 00 	cmp    0x1f2c2(%rip),%r9        # 24bb0 <fwp_heap+0x13f0>
    58ee:	73 07                	jae    58f7 <fwp_mem_free+0x1a7>
    58f0:	4c 89 0d b9 f2 01 00 	mov    %r9,0x1f2b9(%rip)        # 24bb0 <fwp_heap+0x13f0>
    58f7:	4c 3b 0d aa f2 01 00 	cmp    0x1f2aa(%rip),%r9        # 24ba8 <fwp_heap+0x13e8>
    58fe:	0f 83 b0 fe ff ff    	jae    57b4 <fwp_mem_free+0x64>
    5904:	4c 89 0d 9d f2 01 00 	mov    %r9,0x1f29d(%rip)        # 24ba8 <fwp_heap+0x13e8>
    590b:	e9 a4 fe ff ff       	jmp    57b4 <fwp_mem_free+0x64>
    5910:	48 89 d1             	mov    %rdx,%rcx
    5913:	83 e2 01             	and    $0x1,%edx
    5916:	66 0f ef c0          	pxor   %xmm0,%xmm0
    591a:	48 d1 e9             	shr    $1,%rcx
    591d:	48 09 d1             	or     %rdx,%rcx
    5920:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5925:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5929:	e9 46 ff ff ff       	jmp    5874 <fwp_mem_free+0x124>
    592e:	66 90                	xchg   %ax,%ax
    5930:	4c 89 d7             	mov    %r10,%rdi
    5933:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5938:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    593d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5942:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5946:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    594b:	e8 c0 fb ff ff       	call   5510 <fwp_rc_forget_slot>
    5950:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5955:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    595a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    595f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5964:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5969:	e9 7e fe ff ff       	jmp    57ec <fwp_mem_free+0x9c>
    596e:	66 90                	xchg   %ax,%ax
    5970:	c3                   	ret
    5971:	48 89 d7             	mov    %rdx,%rdi
    5974:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5979:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    597e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5983:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5988:	e8 83 fb ff ff       	call   5510 <fwp_rc_forget_slot>
    598d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5992:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5997:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    599c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59a1:	e9 f0 fe ff ff       	jmp    5896 <fwp_mem_free+0x146>
    59a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ad:	00 00 00 

00000000000059b0 <fwp_heap_alloc_big>:
    59b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59b7:	00 00 40 
    59ba:	41 57                	push   %r15
    59bc:	41 56                	push   %r14
    59be:	41 55                	push   %r13
    59c0:	41 54                	push   %r12
    59c2:	55                   	push   %rbp
    59c3:	53                   	push   %rbx
    59c4:	48 83 ec 08          	sub    $0x8,%rsp
    59c8:	48 39 f8             	cmp    %rdi,%rax
    59cb:	0f 82 fa 00 00 00    	jb     5acb <fwp_heap_alloc_big+0x11b>
    59d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    59d8:	49 89 fd             	mov    %rdi,%r13
    59db:	41 89 f6             	mov    %esi,%r14d
    59de:	48 c1 ed 10          	shr    $0x10,%rbp
    59e2:	48 89 ef             	mov    %rbp,%rdi
    59e5:	e8 56 e5 ff ff       	call   3f40 <fwp_heap_chunks>
    59ea:	be 01 00 00 00       	mov    $0x1,%esi
    59ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    59f3:	49 89 c4             	mov    %rax,%r12
    59f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    59fd:	00 
    59fe:	48 03 3d b3 f1 01 00 	add    0x1f1b3(%rip),%rdi        # 24bb8 <fwp_heap+0x13f8>
    5a05:	c6 07 02             	movb   $0x2,(%rdi)
    5a08:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a0c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a0f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a13:	e8 88 fb ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    5a18:	48 83 fd 01          	cmp    $0x1,%rbp
    5a1c:	76 47                	jbe    5a65 <fwp_heap_alloc_big+0xb5>
    5a1e:	4c 01 e5             	add    %r12,%rbp
    5a21:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a28:	00 
    5a29:	4c 8d 3d 90 dd 01 00 	lea    0x1dd90(%rip),%r15        # 237c0 <fwp_heap>
    5a30:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a35:	49 c1 e6 03          	shl    $0x3,%r14
    5a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a40:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a47:	31 f6                	xor    %esi,%esi
    5a49:	48 01 dd             	add    %rbx,%rbp
    5a4c:	48 83 c3 28          	add    $0x28,%rbx
    5a50:	48 89 ef             	mov    %rbp,%rdi
    5a53:	e8 48 fb ff ff       	call   55a0 <fwp_rc_prepare_chunk>
    5a58:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a5c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5a60:	49 39 de             	cmp    %rbx,%r14
    5a63:	75 db                	jne    5a40 <fwp_heap_alloc_big+0x90>
    5a65:	49 c1 e4 10          	shl    $0x10,%r12
    5a69:	4c 03 25 00 f1 01 00 	add    0x1f100(%rip),%r12        # 24b70 <fwp_heap+0x13b0>
    5a70:	4c 89 ea             	mov    %r13,%rdx
    5a73:	31 f6                	xor    %esi,%esi
    5a75:	4c 89 e7             	mov    %r12,%rdi
    5a78:	e8 23 da ff ff       	call   34a0 <memset@plt>
    5a7d:	4c 89 e8             	mov    %r13,%rax
    5a80:	48 03 05 59 f1 01 00 	add    0x1f159(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5a87:	72 42                	jb     5acb <fwp_heap_alloc_big+0x11b>
    5a89:	48 39 05 58 f1 01 00 	cmp    %rax,0x1f158(%rip)        # 24be8 <fwp_heap+0x1428>
    5a90:	48 89 05 49 f1 01 00 	mov    %rax,0x1f149(%rip)        # 24be0 <fwp_heap+0x1420>
    5a97:	73 07                	jae    5aa0 <fwp_heap_alloc_big+0xf0>
    5a99:	48 89 05 48 f1 01 00 	mov    %rax,0x1f148(%rip)        # 24be8 <fwp_heap+0x1428>
    5aa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa4:	4c 89 e0             	mov    %r12,%rax
    5aa7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aac:	f2 0f 58 05 44 f1 01 	addsd  0x1f144(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5ab3:	00 
    5ab4:	f2 0f 11 05 3c f1 01 	movsd  %xmm0,0x1f13c(%rip)        # 24bf8 <fwp_heap+0x1438>
    5abb:	00 
    5abc:	48 83 c4 08          	add    $0x8,%rsp
    5ac0:	5b                   	pop    %rbx
    5ac1:	5d                   	pop    %rbp
    5ac2:	41 5c                	pop    %r12
    5ac4:	41 5d                	pop    %r13
    5ac6:	41 5e                	pop    %r14
    5ac8:	41 5f                	pop    %r15
    5aca:	c3                   	ret
    5acb:	e8 a0 e1 ff ff       	call   3c70 <fwp_heap_oom>

0000000000005ad0 <fwp_heap_alloc_slow>:
    5ad0:	53                   	push   %rbx
    5ad1:	48 89 f9             	mov    %rdi,%rcx
    5ad4:	41 89 f1             	mov    %esi,%r9d
    5ad7:	48 83 ec 10          	sub    $0x10,%rsp
    5adb:	8b 05 83 f0 01 00    	mov    0x1f083(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5ae1:	85 c0                	test   %eax,%eax
    5ae3:	0f 84 c7 00 00 00    	je     5bb0 <fwp_heap_alloc_slow+0xe0>
    5ae9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5af0:	0f 87 dd 00 00 00    	ja     5bd3 <fwp_heap_alloc_slow+0x103>
    5af6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5afa:	48 8d 3d bf dc 01 00 	lea    0x1dcbf(%rip),%rdi        # 237c0 <fwp_heap>
    5b01:	49 63 f1             	movslq %r9d,%rsi
    5b04:	48 c1 e8 04          	shr    $0x4,%rax
    5b08:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b0f:	00 00 
    5b11:	41 0f b6 c2          	movzbl %r10b,%eax
    5b15:	4c 89 d2             	mov    %r10,%rdx
    5b18:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b1c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b23:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b2a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b2e:	48 01 f8             	add    %rdi,%rax
    5b31:	4c 8b 00             	mov    (%rax),%r8
    5b34:	4d 85 c0             	test   %r8,%r8
    5b37:	0f 84 ab 00 00 00    	je     5be8 <fwp_heap_alloc_slow+0x118>
    5b3d:	49 8b 10             	mov    (%r8),%rdx
    5b40:	48 f7 d2             	not    %rdx
    5b43:	48 89 10             	mov    %rdx,(%rax)
    5b46:	41 83 f9 01          	cmp    $0x1,%r9d
    5b4a:	4c 89 c7             	mov    %r8,%rdi
    5b4d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b51:	31 f6                	xor    %esi,%esi
    5b53:	48 89 ca             	mov    %rcx,%rdx
    5b56:	e8 45 d9 ff ff       	call   34a0 <memset@plt>
    5b5b:	49 89 c0             	mov    %rax,%r8
    5b5e:	48 89 d8             	mov    %rbx,%rax
    5b61:	48 03 05 78 f0 01 00 	add    0x1f078(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5b68:	0f 82 d9 00 00 00    	jb     5c47 <fwp_heap_alloc_slow+0x177>
    5b6e:	48 39 05 73 f0 01 00 	cmp    %rax,0x1f073(%rip)        # 24be8 <fwp_heap+0x1428>
    5b75:	48 89 05 64 f0 01 00 	mov    %rax,0x1f064(%rip)        # 24be0 <fwp_heap+0x1420>
    5b7c:	73 07                	jae    5b85 <fwp_heap_alloc_slow+0xb5>
    5b7e:	48 89 05 63 f0 01 00 	mov    %rax,0x1f063(%rip)        # 24be8 <fwp_heap+0x1428>
    5b85:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b89:	4c 89 c0             	mov    %r8,%rax
    5b8c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5b91:	f2 0f 58 05 5f f0 01 	addsd  0x1f05f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5b98:	00 
    5b99:	f2 0f 11 05 57 f0 01 	movsd  %xmm0,0x1f057(%rip)        # 24bf8 <fwp_heap+0x1438>
    5ba0:	00 
    5ba1:	48 83 c4 10          	add    $0x10,%rsp
    5ba5:	5b                   	pop    %rbx
    5ba6:	c3                   	ret
    5ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bae:	00 00 
    5bb0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bb4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bb8:	e8 73 f1 ff ff       	call   4d30 <fwp_heap_init>
    5bbd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5bc1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5bc6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5bcd:	0f 86 23 ff ff ff    	jbe    5af6 <fwp_heap_alloc_slow+0x26>
    5bd3:	48 83 c4 10          	add    $0x10,%rsp
    5bd7:	44 89 ce             	mov    %r9d,%esi
    5bda:	48 89 cf             	mov    %rcx,%rdi
    5bdd:	5b                   	pop    %rbx
    5bde:	e9 cd fd ff ff       	jmp    59b0 <fwp_heap_alloc_big>
    5be3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5be8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5bec:	4d 85 c0             	test   %r8,%r8
    5bef:	74 1f                	je     5c10 <fwp_heap_alloc_slow+0x140>
    5bf1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5bf5:	4d 29 c3             	sub    %r8,%r11
    5bf8:	49 39 db             	cmp    %rbx,%r11
    5bfb:	72 13                	jb     5c10 <fwp_heap_alloc_slow+0x140>
    5bfd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c05:	e9 3c ff ff ff       	jmp    5b46 <fwp_heap_alloc_slow+0x76>
    5c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c1b:	44 89 ca             	mov    %r9d,%edx
    5c1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c2b:	44 89 d6             	mov    %r10d,%esi
    5c2e:	48 01 c7             	add    %rax,%rdi
    5c31:	e8 6a fa ff ff       	call   56a0 <fwp_heap_refill>
    5c36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c3f:	49 89 c0             	mov    %rax,%r8
    5c42:	e9 ff fe ff ff       	jmp    5b46 <fwp_heap_alloc_slow+0x76>
    5c47:	e8 24 e0 ff ff       	call   3c70 <fwp_heap_oom>
    5c4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c50 <fwp_heap_alloc>:
    5c50:	8b 05 0e ef 01 00    	mov    0x1ef0e(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5c56:	48 89 fa             	mov    %rdi,%rdx
    5c59:	89 f7                	mov    %esi,%edi
    5c5b:	85 c0                	test   %eax,%eax
    5c5d:	0f 84 f5 00 00 00    	je     5d58 <fwp_heap_alloc+0x108>
    5c63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5c6a:	0f 87 e8 00 00 00    	ja     5d58 <fwp_heap_alloc+0x108>
    5c70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5c74:	48 8d 05 45 db 01 00 	lea    0x1db45(%rip),%rax        # 237c0 <fwp_heap>
    5c7b:	48 83 ec 18          	sub    $0x18,%rsp
    5c7f:	41 89 f0             	mov    %esi,%r8d
    5c82:	48 c1 e9 04          	shr    $0x4,%rcx
    5c86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5c8d:	00 
    5c8e:	48 63 cf             	movslq %edi,%rcx
    5c91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5c98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5c9f:	00 
    5ca0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ca4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ca8:	48 01 c8             	add    %rcx,%rax
    5cab:	48 8b 08             	mov    (%rax),%rcx
    5cae:	48 85 c9             	test   %rcx,%rcx
    5cb1:	74 6d                	je     5d20 <fwp_heap_alloc+0xd0>
    5cb3:	48 8b 31             	mov    (%rcx),%rsi
    5cb6:	48 f7 d6             	not    %rsi
    5cb9:	48 89 30             	mov    %rsi,(%rax)
    5cbc:	41 83 f8 01          	cmp    $0x1,%r8d
    5cc0:	48 89 cf             	mov    %rcx,%rdi
    5cc3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5cc8:	49 0f 45 d1          	cmovne %r9,%rdx
    5ccc:	31 f6                	xor    %esi,%esi
    5cce:	e8 cd d7 ff ff       	call   34a0 <memset@plt>
    5cd3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5cd8:	48 89 c1             	mov    %rax,%rcx
    5cdb:	4c 89 c8             	mov    %r9,%rax
    5cde:	48 03 05 fb ee 01 00 	add    0x1eefb(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ce5:	72 7b                	jb     5d62 <fwp_heap_alloc+0x112>
    5ce7:	48 39 05 fa ee 01 00 	cmp    %rax,0x1eefa(%rip)        # 24be8 <fwp_heap+0x1428>
    5cee:	48 89 05 eb ee 01 00 	mov    %rax,0x1eeeb(%rip)        # 24be0 <fwp_heap+0x1420>
    5cf5:	73 07                	jae    5cfe <fwp_heap_alloc+0xae>
    5cf7:	48 89 05 ea ee 01 00 	mov    %rax,0x1eeea(%rip)        # 24be8 <fwp_heap+0x1428>
    5cfe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d02:	48 89 c8             	mov    %rcx,%rax
    5d05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d0a:	f2 0f 58 05 e6 ee 01 	addsd  0x1eee6(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5d11:	00 
    5d12:	f2 0f 11 05 de ee 01 	movsd  %xmm0,0x1eede(%rip)        # 24bf8 <fwp_heap+0x1438>
    5d19:	00 
    5d1a:	48 83 c4 18          	add    $0x18,%rsp
    5d1e:	c3                   	ret
    5d1f:	90                   	nop
    5d20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d24:	48 85 c9             	test   %rcx,%rcx
    5d27:	74 0c                	je     5d35 <fwp_heap_alloc+0xe5>
    5d29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d2d:	48 29 ce             	sub    %rcx,%rsi
    5d30:	4c 39 ce             	cmp    %r9,%rsi
    5d33:	73 13                	jae    5d48 <fwp_heap_alloc+0xf8>
    5d35:	89 fe                	mov    %edi,%esi
    5d37:	48 83 c4 18          	add    $0x18,%rsp
    5d3b:	48 89 d7             	mov    %rdx,%rdi
    5d3e:	e9 8d fd ff ff       	jmp    5ad0 <fwp_heap_alloc_slow>
    5d43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d50:	e9 67 ff ff ff       	jmp    5cbc <fwp_heap_alloc+0x6c>
    5d55:	0f 1f 00             	nopl   (%rax)
    5d58:	89 fe                	mov    %edi,%esi
    5d5a:	48 89 d7             	mov    %rdx,%rdi
    5d5d:	e9 6e fd ff ff       	jmp    5ad0 <fwp_heap_alloc_slow>
    5d62:	e8 09 df ff ff       	call   3c70 <fwp_heap_oom>
    5d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5d6e:	00 00 

0000000000005d70 <fwp_data.part.0.constprop.0>:
    5d70:	41 56                	push   %r14
    5d72:	41 89 fe             	mov    %edi,%r14d
    5d75:	41 54                	push   %r12
    5d77:	49 89 f4             	mov    %rsi,%r12
    5d7a:	55                   	push   %rbp
    5d7b:	53                   	push   %rbx
    5d7c:	48 83 ec 08          	sub    $0x8,%rsp
    5d80:	8b 05 de ed 01 00    	mov    0x1edde(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5d86:	85 c0                	test   %eax,%eax
    5d88:	0f 84 fa 00 00 00    	je     5e88 <fwp_data.part.0.constprop.0+0x118>
    5d8e:	0f b6 05 cd e9 01 00 	movzbl 0x1e9cd(%rip),%eax        # 24762 <fwp_heap+0xfa2>
    5d95:	48 8d 15 24 da 01 00 	lea    0x1da24(%rip),%rdx        # 237c0 <fwp_heap>
    5d9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5da3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5da7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5dab:	48 8b 18             	mov    (%rax),%rbx
    5dae:	48 85 db             	test   %rbx,%rbx
    5db1:	0f 84 a9 00 00 00    	je     5e60 <fwp_data.part.0.constprop.0+0xf0>
    5db7:	48 8b 13             	mov    (%rbx),%rdx
    5dba:	48 f7 d2             	not    %rdx
    5dbd:	48 89 10             	mov    %rdx,(%rax)
    5dc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5dc4:	76 1b                	jbe    5de1 <fwp_data.part.0.constprop.0+0x71>
    5dc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5dca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5dce:	31 f6                	xor    %esi,%esi
    5dd0:	48 c1 e8 03          	shr    $0x3,%rax
    5dd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5ddb:	00 
    5ddc:	e8 bf d6 ff ff       	call   34a0 <memset@plt>
    5de1:	48 89 e8             	mov    %rbp,%rax
    5de4:	48 03 05 f5 ed 01 00 	add    0x1edf5(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5deb:	0f 82 a8 00 00 00    	jb     5e99 <fwp_data.part.0.constprop.0+0x129>
    5df1:	48 39 05 f0 ed 01 00 	cmp    %rax,0x1edf0(%rip)        # 24be8 <fwp_heap+0x1428>
    5df8:	48 89 05 e1 ed 01 00 	mov    %rax,0x1ede1(%rip)        # 24be0 <fwp_heap+0x1420>
    5dff:	73 07                	jae    5e08 <fwp_data.part.0.constprop.0+0x98>
    5e01:	48 89 05 e0 ed 01 00 	mov    %rax,0x1ede0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e11:	f2 0f 58 05 df ed 01 	addsd  0x1eddf(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5e18:	00 
    5e19:	f2 0f 11 05 d7 ed 01 	movsd  %xmm0,0x1edd7(%rip)        # 24bf8 <fwp_heap+0x1438>
    5e20:	00 
    5e21:	b8 02 00 00 00       	mov    $0x2,%eax
    5e26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e37:	49 8b 04 24          	mov    (%r12),%rax
    5e3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e48:	48 83 c4 08          	add    $0x8,%rsp
    5e4c:	48 89 d8             	mov    %rbx,%rax
    5e4f:	5b                   	pop    %rbx
    5e50:	5d                   	pop    %rbp
    5e51:	41 5c                	pop    %r12
    5e53:	41 5e                	pop    %r14
    5e55:	c3                   	ret
    5e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e5d:	00 00 00 
    5e60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5e64:	48 85 db             	test   %rbx,%rbx
    5e67:	74 1f                	je     5e88 <fwp_data.part.0.constprop.0+0x118>
    5e69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5e6d:	48 29 da             	sub    %rbx,%rdx
    5e70:	48 39 ea             	cmp    %rbp,%rdx
    5e73:	72 13                	jb     5e88 <fwp_data.part.0.constprop.0+0x118>
    5e75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5e79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e7d:	e9 3e ff ff ff       	jmp    5dc0 <fwp_data.part.0.constprop.0+0x50>
    5e82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e88:	31 f6                	xor    %esi,%esi
    5e8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5e8f:	e8 bc fd ff ff       	call   5c50 <fwp_heap_alloc>
    5e94:	48 89 c3             	mov    %rax,%rbx
    5e97:	eb 88                	jmp    5e21 <fwp_data.part.0.constprop.0+0xb1>
    5e99:	e8 d2 dd ff ff       	call   3c70 <fwp_heap_oom>
    5e9e:	66 90                	xchg   %ax,%ax

0000000000005ea0 <fwp_tape_grow.constprop.0>:
    5ea0:	41 56                	push   %r14
    5ea2:	b8 40 00 00 00       	mov    $0x40,%eax
    5ea7:	41 55                	push   %r13
    5ea9:	41 54                	push   %r12
    5eab:	55                   	push   %rbp
    5eac:	48 89 fd             	mov    %rdi,%rbp
    5eaf:	53                   	push   %rbx
    5eb0:	48 83 ec 10          	sub    $0x10,%rsp
    5eb4:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5eb8:	48 85 db             	test   %rbx,%rbx
    5ebb:	48 0f 44 d8          	cmove  %rax,%rbx
    5ebf:	48 39 de             	cmp    %rbx,%rsi
    5ec2:	7e 12                	jle    5ed6 <fwp_tape_grow.constprop.0+0x36>
    5ec4:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5ecb:	0f 8e df 00 00 00    	jle    5fb0 <fwp_tape_grow.constprop.0+0x110>
    5ed1:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5ed6:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    5eda:	4d 85 e4             	test   %r12,%r12
    5edd:	0f 84 dd 00 00 00    	je     5fc0 <fwp_tape_grow.constprop.0+0x120>
    5ee3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ee7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    5eee:	00 
    5eef:	e8 ac d6 ff ff       	call   35a0 <realloc@plt>
    5ef4:	48 85 c0             	test   %rax,%rax
    5ef7:	0f 84 eb 00 00 00    	je     5fe8 <fwp_tape_grow.constprop.0+0x148>
    5efd:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    5f02:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5f06:	48 39 da             	cmp    %rbx,%rdx
    5f09:	0f 8d 8b 00 00 00    	jge    5f9a <fwp_tape_grow.constprop.0+0xfa>
    5f0f:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    5f16:	ff ff 07 
    5f19:	48 39 c3             	cmp    %rax,%rbx
    5f1c:	0f 8f ba 00 00 00    	jg     5fdc <fwp_tape_grow.constprop.0+0x13c>
    5f22:	48 89 d9             	mov    %rbx,%rcx
    5f25:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    5f2a:	be 02 00 00 00       	mov    $0x2,%esi
    5f2f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5f34:	48 c1 e1 04          	shl    $0x4,%rcx
    5f38:	48 89 cf             	mov    %rcx,%rdi
    5f3b:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f3f:	e8 0c fd ff ff       	call   5c50 <fwp_heap_alloc>
    5f44:	49 89 c5             	mov    %rax,%r13
    5f47:	4d 85 f6             	test   %r14,%r14
    5f4a:	74 27                	je     5f73 <fwp_tape_grow.constprop.0+0xd3>
    5f4c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5f51:	48 8b 0c 24          	mov    (%rsp),%rcx
    5f55:	48 89 c7             	mov    %rax,%rdi
    5f58:	4c 89 f6             	mov    %r14,%rsi
    5f5b:	48 c1 e2 04          	shl    $0x4,%rdx
    5f5f:	48 39 ca             	cmp    %rcx,%rdx
    5f62:	48 0f 47 d1          	cmova  %rcx,%rdx
    5f66:	e8 05 d6 ff ff       	call   3570 <memcpy@plt>
    5f6b:	4c 89 f7             	mov    %r14,%rdi
    5f6e:	e8 dd f7 ff ff       	call   5750 <fwp_mem_free>
    5f73:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    5f78:	48 89 da             	mov    %rbx,%rdx
    5f7b:	31 f6                	xor    %esi,%esi
    5f7d:	48 29 fa             	sub    %rdi,%rdx
    5f80:	48 c1 e7 04          	shl    $0x4,%rdi
    5f84:	48 c1 e2 04          	shl    $0x4,%rdx
    5f88:	4c 01 ef             	add    %r13,%rdi
    5f8b:	e8 10 d5 ff ff       	call   34a0 <memset@plt>
    5f90:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    5f95:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    5f9a:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5f9e:	48 83 c4 10          	add    $0x10,%rsp
    5fa2:	5b                   	pop    %rbx
    5fa3:	5d                   	pop    %rbp
    5fa4:	41 5c                	pop    %r12
    5fa6:	41 5d                	pop    %r13
    5fa8:	41 5e                	pop    %r14
    5faa:	c3                   	ret
    5fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fb0:	48 01 db             	add    %rbx,%rbx
    5fb3:	e9 07 ff ff ff       	jmp    5ebf <fwp_tape_grow.constprop.0+0x1f>
    5fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5fbf:	00 
    5fc0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    5fc4:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5fc8:	48 c1 e6 03          	shl    $0x3,%rsi
    5fcc:	e8 cf d5 ff ff       	call   35a0 <realloc@plt>
    5fd1:	48 85 c0             	test   %rax,%rax
    5fd4:	74 12                	je     5fe8 <fwp_tape_grow.constprop.0+0x148>
    5fd6:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5fda:	eb be                	jmp    5f9a <fwp_tape_grow.constprop.0+0xfa>
    5fdc:	48 8d 3d 69 91 00 00 	lea    0x9169(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    5fe3:	e8 c8 e3 ff ff       	call   43b0 <fwp_trap>
    5fe8:	48 89 ef             	mov    %rbp,%rdi
    5feb:	e8 d0 db ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    5ff0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5ff4:	e8 a7 d3 ff ff       	call   33a0 <free@plt>
    5ff9:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ffd:	e8 9e d3 ff ff       	call   33a0 <free@plt>
    6002:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6006:	e8 95 d3 ff ff       	call   33a0 <free@plt>
    600b:	31 c9                	xor    %ecx,%ecx
    600d:	31 c0                	xor    %eax,%eax
    600f:	31 d2                	xor    %edx,%edx
    6011:	89 55 04             	mov    %edx,0x4(%rbp)
    6014:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6018:	ba 13 00 00 00       	mov    $0x13,%edx
    601d:	be 01 00 00 00       	mov    $0x1,%esi
    6022:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    6026:	48 8d 3d db 8f 00 00 	lea    0x8fdb(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    602d:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6031:	48 8b 0d 08 d0 00 00 	mov    0xd008(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    6038:	48 89 45 30          	mov    %rax,0x30(%rbp)
    603c:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6040:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6044:	e8 f7 d5 ff ff       	call   3640 <fwrite@plt>
    6049:	31 ff                	xor    %edi,%edi
    604b:	e8 40 d5 ff ff       	call   3590 <fflush@plt>
    6050:	bf 66 00 00 00       	mov    $0x66,%edi
    6055:	e8 06 d6 ff ff       	call   3660 <_Exit@plt>
    605a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000006060 <w123>:
    6060:	41 56                	push   %r14
    6062:	55                   	push   %rbp
    6063:	53                   	push   %rbx
    6064:	48 83 ec 30          	sub    $0x30,%rsp
    6068:	48 85 f7             	test   %rsi,%rdi
    606b:	0f 88 a7 01 00 00    	js     6218 <w123+0x1b8>
    6071:	48 89 f8             	mov    %rdi,%rax
    6074:	48 89 fb             	mov    %rdi,%rbx
    6077:	48 89 f5             	mov    %rsi,%rbp
    607a:	48 09 f0             	or     %rsi,%rax
    607d:	0f 89 5d 01 00 00    	jns    61e0 <w123+0x180>
    6083:	48 85 ff             	test   %rdi,%rdi
    6086:	0f 88 a4 01 00 00    	js     6230 <w123+0x1d0>
    608c:	48 89 d9             	mov    %rbx,%rcx
    608f:	4c 8b 35 8a 9b 00 00 	mov    0x9b8a(%rip),%r14        # fc20 <msg.4+0xb0>
    6096:	48 c1 f9 20          	sar    $0x20,%rcx
    609a:	48 39 0a             	cmp    %rcx,(%rdx)
    609d:	0f 84 65 01 00 00    	je     6208 <w123+0x1a8>
    60a3:	48 89 cf             	mov    %rcx,%rdi
    60a6:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    60ab:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    60b0:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    60b6:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60bc:	e8 cf e5 ff ff       	call   4690 <fwp_tape_of>
    60c1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    60c6:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    60cc:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    60d1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    60d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    60dc:	0f 85 7f 01 00 00    	jne    6261 <w123+0x201>
    60e2:	48 89 0a             	mov    %rcx,(%rdx)
    60e5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    60e9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    60ed:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    60f4:	0f 8f 4f 01 00 00    	jg     6249 <w123+0x1e9>
    60fa:	89 da                	mov    %ebx,%edx
    60fc:	48 39 d1             	cmp    %rdx,%rcx
    60ff:	0f 8e 50 01 00 00    	jle    6255 <w123+0x1f5>
    6105:	48 85 ed             	test   %rbp,%rbp
    6108:	78 0b                	js     6115 <w123+0xb5>
    610a:	89 ea                	mov    %ebp,%edx
    610c:	48 39 d1             	cmp    %rdx,%rcx
    610f:	0f 8e 40 01 00 00    	jle    6255 <w123+0x1f5>
    6115:	48 89 ca             	mov    %rcx,%rdx
    6118:	48 2b 50 08          	sub    0x8(%rax),%rdx
    611c:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6120:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6127:	0f 87 1c 01 00 00    	ja     6249 <w123+0x1e9>
    612d:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6131:	7e 3e                	jle    6171 <w123+0x111>
    6133:	48 89 c7             	mov    %rax,%rdi
    6136:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    613b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6140:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6145:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    614b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6151:	e8 4a fd ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6156:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    615c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6162:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6167:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    616c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6171:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    6175:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6179:	48 85 ed             	test   %rbp,%rbp
    617c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    6181:	48 8b 3d 98 9a 00 00 	mov    0x9a98(%rip),%rdi        # fc20 <msg.4+0xb0>
    6188:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    618c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6190:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    6197:	48 0f 48 ee          	cmovs  %rsi,%rbp
    619b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    619f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    61a3:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    61a8:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    61ac:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    61b0:	66 0f d6 12          	movq   %xmm2,(%rdx)
    61b4:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    61b8:	48 89 50 10          	mov    %rdx,0x10(%rax)
    61bc:	48 83 c4 30          	add    $0x30,%rsp
    61c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    61c7:	ff ff ff 
    61ca:	48 21 c3             	and    %rax,%rbx
    61cd:	48 09 cb             	or     %rcx,%rbx
    61d0:	48 89 d8             	mov    %rbx,%rax
    61d3:	5b                   	pop    %rbx
    61d4:	5d                   	pop    %rbp
    61d5:	41 5e                	pop    %r14
    61d7:	c3                   	ret
    61d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61df:	00 
    61e0:	48 89 f9             	mov    %rdi,%rcx
    61e3:	48 89 f0             	mov    %rsi,%rax
    61e6:	48 c1 f9 20          	sar    $0x20,%rcx
    61ea:	48 c1 f8 20          	sar    $0x20,%rax
    61ee:	48 39 c1             	cmp    %rax,%rcx
    61f1:	0f 84 95 fe ff ff    	je     608c <w123+0x2c>
    61f7:	48 8d 3d ba 96 00 00 	lea    0x96ba(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    61fe:	e8 ad e1 ff ff       	call   43b0 <fwp_trap>
    6203:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6208:	48 8b 42 08          	mov    0x8(%rdx),%rax
    620c:	e9 d8 fe ff ff       	jmp    60e9 <w123+0x89>
    6211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6218:	48 83 c4 30          	add    $0x30,%rsp
    621c:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6223:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6227:	48 89 d8             	mov    %rbx,%rax
    622a:	5b                   	pop    %rbx
    622b:	5d                   	pop    %rbp
    622c:	41 5e                	pop    %r14
    622e:	c3                   	ret
    622f:	90                   	nop
    6230:	48 89 f1             	mov    %rsi,%rcx
    6233:	48 89 f3             	mov    %rsi,%rbx
    6236:	45 31 f6             	xor    %r14d,%r14d
    6239:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6240:	48 c1 f9 20          	sar    $0x20,%rcx
    6244:	e9 51 fe ff ff       	jmp    609a <w123+0x3a>
    6249:	48 8d 3d fc 8e 00 00 	lea    0x8efc(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    6250:	e8 5b e1 ff ff       	call   43b0 <fwp_trap>
    6255:	48 8d 3d 0b 8f 00 00 	lea    0x8f0b(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    625c:	e8 4f e1 ff ff       	call   43b0 <fwp_trap>
    6261:	48 8d 3d 98 96 00 00 	lea    0x9698(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    6268:	e8 43 e1 ff ff       	call   43b0 <fwp_trap>
    626d:	0f 1f 00             	nopl   (%rax)

0000000000006270 <w120>:
    6270:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6274:	41 57                	push   %r15
    6276:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    627a:	41 56                	push   %r14
    627c:	41 55                	push   %r13
    627e:	49 89 fd             	mov    %rdi,%r13
    6281:	41 54                	push   %r12
    6283:	49 89 d4             	mov    %rdx,%r12
    6286:	55                   	push   %rbp
    6287:	48 89 f5             	mov    %rsi,%rbp
    628a:	53                   	push   %rbx
    628b:	48 83 ec 48          	sub    $0x48,%rsp
    628f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6295:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    629a:	48 85 ff             	test   %rdi,%rdi
    629d:	0f 88 5d 06 00 00    	js     6900 <w120+0x690>
    62a3:	49 89 fe             	mov    %rdi,%r14
    62a6:	49 c1 fe 20          	sar    $0x20,%r14
    62aa:	4c 3b 32             	cmp    (%rdx),%r14
    62ad:	0f 84 ed 05 00 00    	je     68a0 <w120+0x630>
    62b3:	4c 89 f7             	mov    %r14,%rdi
    62b6:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    62bc:	e8 cf e3 ff ff       	call   4690 <fwp_tape_of>
    62c1:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    62c7:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    62cc:	48 89 c3             	mov    %rax,%rbx
    62cf:	0f 85 97 06 00 00    	jne    696c <w120+0x6fc>
    62d5:	4d 89 34 24          	mov    %r14,(%r12)
    62d9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    62de:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    62e2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    62e9:	0f 8f 71 06 00 00    	jg     6960 <w120+0x6f0>
    62ef:	44 89 e8             	mov    %r13d,%eax
    62f2:	49 39 c6             	cmp    %rax,%r14
    62f5:	0f 8e 4a 06 00 00    	jle    6945 <w120+0x6d5>
    62fb:	4c 89 f0             	mov    %r14,%rax
    62fe:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6302:	48 8d 70 01          	lea    0x1(%rax),%rsi
    6306:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    630d:	0f 87 4d 06 00 00    	ja     6960 <w120+0x6f0>
    6313:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    6319:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    631d:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    6321:	0f 8f 61 04 00 00    	jg     6788 <w120+0x518>
    6327:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    632b:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    6330:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6334:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    6339:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    633e:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6343:	49 8d 46 01          	lea    0x1(%r14),%rax
    6347:	48 89 43 10          	mov    %rax,0x10(%rbx)
    634b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6352:	ff ff ff 
    6355:	4c 21 eb             	and    %r13,%rbx
    6358:	4c 09 f3             	or     %r14,%rbx
    635b:	49 89 de             	mov    %rbx,%r14
    635e:	49 c1 fe 20          	sar    $0x20,%r14
    6362:	48 85 ed             	test   %rbp,%rbp
    6365:	78 10                	js     6377 <w120+0x107>
    6367:	48 89 e8             	mov    %rbp,%rax
    636a:	48 c1 f8 20          	sar    $0x20,%rax
    636e:	4c 39 f0             	cmp    %r14,%rax
    6371:	0f 85 da 05 00 00    	jne    6951 <w120+0x6e1>
    6377:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    637c:	66 0f 28 2d 8c 98 00 	movapd 0x988c(%rip),%xmm5        # fc10 <msg.4+0xa0>
    6383:	00 
    6384:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6389:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    638e:	4d 39 34 24          	cmp    %r14,(%r12)
    6392:	0f 84 18 05 00 00    	je     68b0 <w120+0x640>
    6398:	4c 89 f7             	mov    %r14,%rdi
    639b:	e8 f0 e2 ff ff       	call   4690 <fwp_tape_of>
    63a0:	48 89 c2             	mov    %rax,%rdx
    63a3:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    63a8:	0f 85 be 05 00 00    	jne    696c <w120+0x6fc>
    63ae:	4d 89 34 24          	mov    %r14,(%r12)
    63b2:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    63b7:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    63bb:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    63c2:	0f 8f 98 05 00 00    	jg     6960 <w120+0x6f0>
    63c8:	89 d8                	mov    %ebx,%eax
    63ca:	49 39 c6             	cmp    %rax,%r14
    63cd:	0f 8e 72 05 00 00    	jle    6945 <w120+0x6d5>
    63d3:	48 85 ed             	test   %rbp,%rbp
    63d6:	78 0b                	js     63e3 <w120+0x173>
    63d8:	89 e8                	mov    %ebp,%eax
    63da:	49 39 c6             	cmp    %rax,%r14
    63dd:	0f 8e 62 05 00 00    	jle    6945 <w120+0x6d5>
    63e3:	4c 89 f0             	mov    %r14,%rax
    63e6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    63ea:	48 8d 70 01          	lea    0x1(%rax),%rsi
    63ee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    63f5:	0f 87 65 05 00 00    	ja     6960 <w120+0x6f0>
    63fb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    63ff:	0f 8f bb 03 00 00    	jg     67c0 <w120+0x550>
    6405:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    6409:	48 8b 42 20          	mov    0x20(%rdx),%rax
    640d:	48 85 ed             	test   %rbp,%rbp
    6410:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    6416:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    641b:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    641f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6426:	48 0f 49 c5          	cmovns %rbp,%rax
    642a:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    642e:	66 48 0f 6e d8       	movq   %rax,%xmm3
    6433:	49 8d 46 01          	lea    0x1(%r14),%rax
    6437:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    643b:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    643f:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6443:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6447:	4d 85 ed             	test   %r13,%r13
    644a:	0f 88 4b 05 00 00    	js     699b <w120+0x72b>
    6450:	4c 89 ea             	mov    %r13,%rdx
    6453:	48 c1 fa 20          	sar    $0x20,%rdx
    6457:	49 3b 14 24          	cmp    (%r12),%rdx
    645b:	0f 84 5f 04 00 00    	je     68c0 <w120+0x650>
    6461:	48 89 d7             	mov    %rdx,%rdi
    6464:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6469:	e8 22 e2 ff ff       	call   4690 <fwp_tape_of>
    646e:	48 89 c5             	mov    %rax,%rbp
    6471:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6476:	0f 85 f0 04 00 00    	jne    696c <w120+0x6fc>
    647c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6481:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6486:	49 89 14 24          	mov    %rdx,(%r12)
    648a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    648e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6494:	0f 8f c6 04 00 00    	jg     6960 <w120+0x6f0>
    649a:	44 89 ea             	mov    %r13d,%edx
    649d:	48 39 d0             	cmp    %rdx,%rax
    64a0:	0f 8e 9f 04 00 00    	jle    6945 <w120+0x6d5>
    64a6:	48 89 c2             	mov    %rax,%rdx
    64a9:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    64ad:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    64b1:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    64b8:	0f 87 a2 04 00 00    	ja     6960 <w120+0x6f0>
    64be:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    64c2:	0f 8f 20 03 00 00    	jg     67e8 <w120+0x578>
    64c8:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    64cd:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    64d1:	66 0f 28 05 37 97 00 	movapd 0x9737(%rip),%xmm0        # fc10 <msg.4+0xa0>
    64d8:	00 
    64d9:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    64dd:	66 0f 28 ee          	movapd %xmm6,%xmm5
    64e1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    64e5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    64e9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    64f0:	ff 
    64f1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    64f6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    64fa:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    64fe:	4c 89 ed             	mov    %r13,%rbp
    6501:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6508:	ff ff ff 
    650b:	48 21 d5             	and    %rdx,%rbp
    650e:	48 09 c5             	or     %rax,%rbp
    6511:	66 49 0f 7e ef       	movq   %xmm5,%r15
    6516:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    651d:	ff ff ff 
    6520:	48 21 c3             	and    %rax,%rbx
    6523:	4c 09 f3             	or     %r14,%rbx
    6526:	49 89 de             	mov    %rbx,%r14
    6529:	49 c1 fe 20          	sar    $0x20,%r14
    652d:	4d 3b 34 24          	cmp    (%r12),%r14
    6531:	0f 84 99 03 00 00    	je     68d0 <w120+0x660>
    6537:	4c 89 f7             	mov    %r14,%rdi
    653a:	e8 51 e1 ff ff       	call   4690 <fwp_tape_of>
    653f:	49 89 c5             	mov    %rax,%r13
    6542:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6547:	0f 85 1f 04 00 00    	jne    696c <w120+0x6fc>
    654d:	4d 89 34 24          	mov    %r14,(%r12)
    6551:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6556:	4d 8b 75 10          	mov    0x10(%r13),%r14
    655a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6561:	0f 8f f9 03 00 00    	jg     6960 <w120+0x6f0>
    6567:	89 d8                	mov    %ebx,%eax
    6569:	49 39 c6             	cmp    %rax,%r14
    656c:	0f 8e d3 03 00 00    	jle    6945 <w120+0x6d5>
    6572:	4c 89 f0             	mov    %r14,%rax
    6575:	49 2b 45 08          	sub    0x8(%r13),%rax
    6579:	48 8d 70 01          	lea    0x1(%rax),%rsi
    657d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6584:	0f 87 d6 03 00 00    	ja     6960 <w120+0x6f0>
    658a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    658f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6593:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6597:	0f 8f 73 02 00 00    	jg     6810 <w120+0x5a0>
    659d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    65a1:	66 0f 6e eb          	movd   %ebx,%xmm5
    65a5:	49 8b 45 20          	mov    0x20(%r13),%rax
    65a9:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    65ae:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    65b3:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    65b8:	49 8d 46 01          	lea    0x1(%r14),%rax
    65bc:	49 89 45 10          	mov    %rax,0x10(%r13)
    65c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65c7:	ff ff ff 
    65ca:	48 21 c3             	and    %rax,%rbx
    65cd:	4c 09 f3             	or     %r14,%rbx
    65d0:	49 89 dd             	mov    %rbx,%r13
    65d3:	49 c1 fd 20          	sar    $0x20,%r13
    65d7:	4d 3b 2c 24          	cmp    (%r12),%r13
    65db:	0f 84 ff 02 00 00    	je     68e0 <w120+0x670>
    65e1:	4c 89 ef             	mov    %r13,%rdi
    65e4:	e8 a7 e0 ff ff       	call   4690 <fwp_tape_of>
    65e9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    65ee:	0f 85 78 03 00 00    	jne    696c <w120+0x6fc>
    65f4:	4d 89 2c 24          	mov    %r13,(%r12)
    65f8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    65fd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6601:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6608:	0f 8f 52 03 00 00    	jg     6960 <w120+0x6f0>
    660e:	89 da                	mov    %ebx,%edx
    6610:	49 39 d5             	cmp    %rdx,%r13
    6613:	0f 8e 2c 03 00 00    	jle    6945 <w120+0x6d5>
    6619:	4d 89 ee             	mov    %r13,%r14
    661c:	4c 2b 70 08          	sub    0x8(%rax),%r14
    6620:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6624:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    662b:	0f 87 2f 03 00 00    	ja     6960 <w120+0x6f0>
    6631:	f2 0f 10 15 e7 95 00 	movsd  0x95e7(%rip),%xmm2        # fc20 <msg.4+0xb0>
    6638:	00 
    6639:	66 49 0f 6e cf       	movq   %r15,%xmm1
    663e:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6644:	f2 0f 59 0d e4 95 00 	mulsd  0x95e4(%rip),%xmm1        # fc30 <msg.4+0xc0>
    664b:	00 
    664c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6650:	0f 8f da 01 00 00    	jg     6830 <w120+0x5c0>
    6656:	48 8b 50 20          	mov    0x20(%rax),%rdx
    665a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    665e:	f3 0f 7e 05 ca 95 00 	movq   0x95ca(%rip),%xmm0        # fc30 <msg.4+0xc0>
    6665:	00 
    6666:	48 89 ef             	mov    %rbp,%rdi
    6669:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    666c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6671:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6675:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    667c:	ff 
    667d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6681:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6685:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6689:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6690:	ff ff ff 
    6693:	48 21 c3             	and    %rax,%rbx
    6696:	4c 09 eb             	or     %r13,%rbx
    6699:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    669d:	0f 84 c8 00 00 00    	je     676b <w120+0x4fb>
    66a3:	49 89 ed             	mov    %rbp,%r13
    66a6:	49 c1 fd 20          	sar    $0x20,%r13
    66aa:	4d 39 2c 24          	cmp    %r13,(%r12)
    66ae:	0f 84 3c 02 00 00    	je     68f0 <w120+0x680>
    66b4:	4c 89 ef             	mov    %r13,%rdi
    66b7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66bd:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    66c2:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    66c8:	e8 c3 df ff ff       	call   4690 <fwp_tape_of>
    66cd:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    66d2:	0f 85 94 02 00 00    	jne    696c <w120+0x6fc>
    66d8:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    66de:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    66e3:	4d 89 2c 24          	mov    %r13,(%r12)
    66e7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    66ec:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    66f2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    66f6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    66fd:	0f 8f 5d 02 00 00    	jg     6960 <w120+0x6f0>
    6703:	89 e9                	mov    %ebp,%ecx
    6705:	4c 39 f1             	cmp    %r14,%rcx
    6708:	0f 8d 37 02 00 00    	jge    6945 <w120+0x6d5>
    670e:	4d 89 f5             	mov    %r14,%r13
    6711:	4c 2b 68 08          	sub    0x8(%rax),%r13
    6715:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6719:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6720:	0f 87 3a 02 00 00    	ja     6960 <w120+0x6f0>
    6726:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    672a:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    672e:	0f 8f 2c 01 00 00    	jg     6860 <w120+0x5f0>
    6734:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6738:	66 0f 6e dd          	movd   %ebp,%xmm3
    673c:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6741:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6748:	ff ff ff 
    674b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6750:	48 21 d5             	and    %rdx,%rbp
    6753:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6758:	48 89 ef             	mov    %rbp,%rdi
    675b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6760:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6764:	4c 09 f7             	or     %r14,%rdi
    6767:	48 89 48 10          	mov    %rcx,0x10(%rax)
    676b:	4c 89 e2             	mov    %r12,%rdx
    676e:	48 89 de             	mov    %rbx,%rsi
    6771:	e8 ea f8 ff ff       	call   6060 <w123>
    6776:	48 83 c4 48          	add    $0x48,%rsp
    677a:	5b                   	pop    %rbx
    677b:	5d                   	pop    %rbp
    677c:	41 5c                	pop    %r12
    677e:	41 5d                	pop    %r13
    6780:	41 5e                	pop    %r14
    6782:	41 5f                	pop    %r15
    6784:	c3                   	ret
    6785:	0f 1f 00             	nopl   (%rax)
    6788:	48 89 df             	mov    %rbx,%rdi
    678b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6790:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6796:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    679b:	e8 00 f7 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67a0:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    67a6:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    67ac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    67b1:	e9 71 fb ff ff       	jmp    6327 <w120+0xb7>
    67b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67bd:	00 00 00 
    67c0:	48 89 d7             	mov    %rdx,%rdi
    67c3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    67c8:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    67cd:	e8 ce f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67d2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    67d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    67dc:	e9 24 fc ff ff       	jmp    6405 <w120+0x195>
    67e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67e8:	48 89 ef             	mov    %rbp,%rdi
    67eb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    67f0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    67f5:	e8 a6 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    67fa:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    67ff:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6804:	e9 bf fc ff ff       	jmp    64c8 <w120+0x258>
    6809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6810:	4c 89 ef             	mov    %r13,%rdi
    6813:	48 89 04 24          	mov    %rax,(%rsp)
    6817:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    681c:	e8 7f f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6821:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    6827:	48 8b 04 24          	mov    (%rsp),%rax
    682b:	e9 6d fd ff ff       	jmp    659d <w120+0x32d>
    6830:	48 89 c7             	mov    %rax,%rdi
    6833:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6838:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    683e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6843:	e8 58 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    6848:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    684e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6853:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6858:	e9 f9 fd ff ff       	jmp    6656 <w120+0x3e6>
    685d:	0f 1f 00             	nopl   (%rax)
    6860:	48 89 c7             	mov    %rax,%rdi
    6863:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6868:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    686e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6874:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6878:	e8 23 f6 ff ff       	call   5ea0 <fwp_tape_grow.constprop.0>
    687d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6883:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6889:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    688e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6893:	e9 9c fe ff ff       	jmp    6734 <w120+0x4c4>
    6898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    689f:	00 
    68a0:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    68a4:	e9 35 fa ff ff       	jmp    62de <w120+0x6e>
    68a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b0:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    68b5:	e9 fd fa ff ff       	jmp    63b7 <w120+0x147>
    68ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c0:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    68c5:	e9 c0 fb ff ff       	jmp    648a <w120+0x21a>
    68ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    68d5:	e9 7c fc ff ff       	jmp    6556 <w120+0x2e6>
    68da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68e0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    68e5:	e9 13 fd ff ff       	jmp    65fd <w120+0x38d>
    68ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68f0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    68f5:	e9 f8 fd ff ff       	jmp    66f2 <w120+0x482>
    68fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6900:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    6905:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    690a:	48 85 f6             	test   %rsi,%rsi
    690d:	79 69                	jns    6978 <w120+0x708>
    690f:	f2 0f 10 05 09 93 00 	movsd  0x9309(%rip),%xmm0        # fc20 <msg.4+0xb0>
    6916:	00 
    6917:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    691c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6923:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    692a:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    6930:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6934:	f2 0f 59 0d f4 92 00 	mulsd  0x92f4(%rip),%xmm1        # fc30 <msg.4+0xc0>
    693b:	00 
    693c:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6940:	e9 26 fe ff ff       	jmp    676b <w120+0x4fb>
    6945:	48 8d 3d 1b 88 00 00 	lea    0x881b(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    694c:	e8 5f da ff ff       	call   43b0 <fwp_trap>
    6951:	48 8d 3d 60 8f 00 00 	lea    0x8f60(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    6958:	e8 53 da ff ff       	call   43b0 <fwp_trap>
    695d:	0f 1f 00             	nopl   (%rax)
    6960:	48 8d 3d e5 87 00 00 	lea    0x87e5(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    6967:	e8 44 da ff ff       	call   43b0 <fwp_trap>
    696c:	48 8d 3d 8d 8f 00 00 	lea    0x8f8d(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    6973:	e8 38 da ff ff       	call   43b0 <fwp_trap>
    6978:	49 89 f6             	mov    %rsi,%r14
    697b:	f3 0f 7e 3d 9d 92 00 	movq   0x929d(%rip),%xmm7        # fc20 <msg.4+0xb0>
    6982:	00 
    6983:	48 89 f3             	mov    %rsi,%rbx
    6986:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    698b:	49 c1 fe 20          	sar    $0x20,%r14
    698f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6996:	e9 f3 f9 ff ff       	jmp    638e <w120+0x11e>
    699b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    69a0:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    69a5:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    69ac:	66 49 0f 7e ff       	movq   %xmm7,%r15
    69b1:	e9 60 fb ff ff       	jmp    6516 <w120+0x2a6>
    69b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69bd:	00 00 00 

00000000000069c0 <w176.constprop.0>:
    69c0:	41 55                	push   %r13
    69c2:	41 54                	push   %r12
    69c4:	55                   	push   %rbp
    69c5:	53                   	push   %rbx
    69c6:	48 83 ec 28          	sub    $0x28,%rsp
    69ca:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    69d1:	00 00 
    69d3:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    69d8:	48 8b 2f             	mov    (%rdi),%rbp
    69db:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    69e2:	ff 
    69e3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    69ea:	00 00 
    69ec:	48 85 ed             	test   %rbp,%rbp
    69ef:	74 5f                	je     6a50 <w176.constprop.0+0x90>
    69f1:	49 89 fd             	mov    %rdi,%r13
    69f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69f8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    69ff:	31 db                	xor    %ebx,%ebx
    6a01:	0f 1f 40 00          	nopl   0x0(%rax)
    6a05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a0c:	00 00 00 00 
    6a10:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    6a15:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    6a1c:	48 89 e2             	mov    %rsp,%rdx
    6a1f:	48 83 c3 02          	add    $0x2,%rbx
    6a23:	e8 38 f6 ff ff       	call   6060 <w123>
    6a28:	48 89 c7             	mov    %rax,%rdi
    6a2b:	48 39 eb             	cmp    %rbp,%rbx
    6a2e:	72 e0                	jb     6a10 <w176.constprop.0+0x50>
    6a30:	48 89 f8             	mov    %rdi,%rax
    6a33:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6a38:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6a3f:	00 00 
    6a41:	75 1a                	jne    6a5d <w176.constprop.0+0x9d>
    6a43:	48 83 c4 28          	add    $0x28,%rsp
    6a47:	5b                   	pop    %rbx
    6a48:	5d                   	pop    %rbp
    6a49:	41 5c                	pop    %r12
    6a4b:	41 5d                	pop    %r13
    6a4d:	c3                   	ret
    6a4e:	66 90                	xchg   %ax,%ax
    6a50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a57:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a5b:	eb d3                	jmp    6a30 <w176.constprop.0+0x70>
    6a5d:	e8 de c9 ff ff       	call   3440 <__stack_chk_fail@plt>
    6a62:	0f 1f 00             	nopl   (%rax)
    6a65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a6c:	00 00 00 00 

0000000000006a70 <fwp_rc_share>:
    6a70:	48 8b 05 21 e1 01 00 	mov    0x1e121(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    6a77:	48 2b 3d f2 e0 01 00 	sub    0x1e0f2(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    6a7e:	48 c1 e0 10          	shl    $0x10,%rax
    6a82:	48 39 c7             	cmp    %rax,%rdi
    6a85:	73 4a                	jae    6ad1 <fwp_rc_share+0x61>
    6a87:	48 89 f8             	mov    %rdi,%rax
    6a8a:	48 c1 e8 10          	shr    $0x10,%rax
    6a8e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a92:	48 8b 05 1f e1 01 00 	mov    0x1e11f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    6a99:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a9d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6aa1:	48 85 d2             	test   %rdx,%rdx
    6aa4:	74 2b                	je     6ad1 <fwp_rc_share+0x61>
    6aa6:	0f b6 08             	movzbl (%rax),%ecx
    6aa9:	80 f9 02             	cmp    $0x2,%cl
    6aac:	74 2a                	je     6ad8 <fwp_rc_share+0x68>
    6aae:	80 f9 01             	cmp    $0x1,%cl
    6ab1:	75 1e                	jne    6ad1 <fwp_rc_share+0x61>
    6ab3:	8b 48 18             	mov    0x18(%rax),%ecx
    6ab6:	0f b7 ff             	movzwl %di,%edi
    6ab9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6abc:	48 0f af f9          	imul   %rcx,%rdi
    6ac0:	48 c1 ef 20          	shr    $0x20,%rdi
    6ac4:	48 39 c7             	cmp    %rax,%rdi
    6ac7:	73 08                	jae    6ad1 <fwp_rc_share+0x61>
    6ac9:	48 01 fa             	add    %rdi,%rdx
    6acc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6acf:	75 0d                	jne    6ade <fwp_rc_share+0x6e>
    6ad1:	c3                   	ret
    6ad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad8:	66 85 ff             	test   %di,%di
    6adb:	74 ef                	je     6acc <fwp_rc_share+0x5c>
    6add:	c3                   	ret
    6ade:	50                   	push   %rax
    6adf:	48 8d 3d 4a 8e 00 00 	lea    0x8e4a(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    6ae6:	e8 c5 d8 ff ff       	call   43b0 <fwp_trap>
    6aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006af0 <fwp_rc_fresh>:
    6af0:	48 8b 15 a1 e0 01 00 	mov    0x1e0a1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6af7:	48 89 f8             	mov    %rdi,%rax
    6afa:	48 89 fe             	mov    %rdi,%rsi
    6afd:	48 2b 05 6c e0 01 00 	sub    0x1e06c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6b04:	48 c1 e2 10          	shl    $0x10,%rdx
    6b08:	48 39 d0             	cmp    %rdx,%rax
    6b0b:	73 4f                	jae    6b5c <fwp_rc_fresh+0x6c>
    6b0d:	48 89 c2             	mov    %rax,%rdx
    6b10:	48 c1 ea 10          	shr    $0x10,%rdx
    6b14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b18:	48 8b 15 99 e0 01 00 	mov    0x1e099(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6b1f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b27:	48 85 d2             	test   %rdx,%rdx
    6b2a:	74 30                	je     6b5c <fwp_rc_fresh+0x6c>
    6b2c:	0f b6 39             	movzbl (%rcx),%edi
    6b2f:	40 80 ff 02          	cmp    $0x2,%dil
    6b33:	74 2b                	je     6b60 <fwp_rc_fresh+0x70>
    6b35:	40 80 ff 01          	cmp    $0x1,%dil
    6b39:	75 21                	jne    6b5c <fwp_rc_fresh+0x6c>
    6b3b:	8b 79 18             	mov    0x18(%rcx),%edi
    6b3e:	0f b7 c0             	movzwl %ax,%eax
    6b41:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b44:	48 0f af c7          	imul   %rdi,%rax
    6b48:	48 c1 e8 20          	shr    $0x20,%rax
    6b4c:	48 39 c8             	cmp    %rcx,%rax
    6b4f:	73 0b                	jae    6b5c <fwp_rc_fresh+0x6c>
    6b51:	48 01 c2             	add    %rax,%rdx
    6b54:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b57:	74 17                	je     6b70 <fwp_rc_fresh+0x80>
    6b59:	c6 02 01             	movb   $0x1,(%rdx)
    6b5c:	48 89 f0             	mov    %rsi,%rax
    6b5f:	c3                   	ret
    6b60:	66 85 c0             	test   %ax,%ax
    6b63:	74 ef                	je     6b54 <fwp_rc_fresh+0x64>
    6b65:	48 89 f0             	mov    %rsi,%rax
    6b68:	c3                   	ret
    6b69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b70:	48 83 ec 18          	sub    $0x18,%rsp
    6b74:	48 89 d7             	mov    %rdx,%rdi
    6b77:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b7c:	48 89 14 24          	mov    %rdx,(%rsp)
    6b80:	e8 8b e9 ff ff       	call   5510 <fwp_rc_forget_slot>
    6b85:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b8a:	48 8b 14 24          	mov    (%rsp),%rdx
    6b8e:	48 89 f0             	mov    %rsi,%rax
    6b91:	c6 02 01             	movb   $0x1,(%rdx)
    6b94:	48 83 c4 18          	add    $0x18,%rsp
    6b98:	c3                   	ret
    6b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006ba0 <fwp_rc_free_obj>:
    6ba0:	48 8b 15 f1 df 01 00 	mov    0x1dff1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6ba7:	48 89 f8             	mov    %rdi,%rax
    6baa:	48 2b 05 bf df 01 00 	sub    0x1dfbf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6bb1:	48 c1 e2 10          	shl    $0x10,%rdx
    6bb5:	48 39 d0             	cmp    %rdx,%rax
    6bb8:	73 5b                	jae    6c15 <fwp_rc_free_obj+0x75>
    6bba:	48 89 c2             	mov    %rax,%rdx
    6bbd:	48 c1 ea 10          	shr    $0x10,%rdx
    6bc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bc5:	48 8b 15 ec df 01 00 	mov    0x1dfec(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6bcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6bd0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6bd4:	48 85 c9             	test   %rcx,%rcx
    6bd7:	74 3c                	je     6c15 <fwp_rc_free_obj+0x75>
    6bd9:	0f b6 32             	movzbl (%rdx),%esi
    6bdc:	40 80 fe 02          	cmp    $0x2,%sil
    6be0:	74 2e                	je     6c10 <fwp_rc_free_obj+0x70>
    6be2:	40 80 fe 01          	cmp    $0x1,%sil
    6be6:	75 2d                	jne    6c15 <fwp_rc_free_obj+0x75>
    6be8:	8b 72 18             	mov    0x18(%rdx),%esi
    6beb:	0f b7 c0             	movzwl %ax,%eax
    6bee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bf1:	48 0f af c6          	imul   %rsi,%rax
    6bf5:	48 c1 e8 20          	shr    $0x20,%rax
    6bf9:	48 39 d0             	cmp    %rdx,%rax
    6bfc:	73 17                	jae    6c15 <fwp_rc_free_obj+0x75>
    6bfe:	48 01 c1             	add    %rax,%rcx
    6c01:	80 39 01             	cmpb   $0x1,(%rcx)
    6c04:	75 0f                	jne    6c15 <fwp_rc_free_obj+0x75>
    6c06:	e9 45 eb ff ff       	jmp    5750 <fwp_mem_free>
    6c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c10:	66 85 c0             	test   %ax,%ax
    6c13:	74 ec                	je     6c01 <fwp_rc_free_obj+0x61>
    6c15:	c3                   	ret
    6c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c1d:	00 00 00 

0000000000006c20 <fwp_rc_dup>:
    6c20:	f3 0f 1e fa          	endbr64
    6c24:	48 8b 05 6d df 01 00 	mov    0x1df6d(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    6c2b:	48 2b 3d 3e df 01 00 	sub    0x1df3e(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    6c32:	48 c1 e0 10          	shl    $0x10,%rax
    6c36:	48 39 c7             	cmp    %rax,%rdi
    6c39:	73 56                	jae    6c91 <fwp_rc_dup+0x71>
    6c3b:	48 89 f8             	mov    %rdi,%rax
    6c3e:	48 c1 e8 10          	shr    $0x10,%rax
    6c42:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c46:	48 8b 05 6b df 01 00 	mov    0x1df6b(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    6c4d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c51:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c55:	48 85 c0             	test   %rax,%rax
    6c58:	74 37                	je     6c91 <fwp_rc_dup+0x71>
    6c5a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c5d:	80 f9 02             	cmp    $0x2,%cl
    6c60:	74 36                	je     6c98 <fwp_rc_dup+0x78>
    6c62:	80 f9 01             	cmp    $0x1,%cl
    6c65:	75 2a                	jne    6c91 <fwp_rc_dup+0x71>
    6c67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c6a:	0f b7 ff             	movzwl %di,%edi
    6c6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c70:	48 0f af f9          	imul   %rcx,%rdi
    6c74:	48 c1 ef 20          	shr    $0x20,%rdi
    6c78:	48 39 d7             	cmp    %rdx,%rdi
    6c7b:	73 14                	jae    6c91 <fwp_rc_dup+0x71>
    6c7d:	48 01 f8             	add    %rdi,%rax
    6c80:	0f b6 10             	movzbl (%rax),%edx
    6c83:	84 d2                	test   %dl,%dl
    6c85:	74 0a                	je     6c91 <fwp_rc_dup+0x71>
    6c87:	80 fa fd             	cmp    $0xfd,%dl
    6c8a:	77 14                	ja     6ca0 <fwp_rc_dup+0x80>
    6c8c:	83 c2 01             	add    $0x1,%edx
    6c8f:	88 10                	mov    %dl,(%rax)
    6c91:	c3                   	ret
    6c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c98:	66 85 ff             	test   %di,%di
    6c9b:	74 e3                	je     6c80 <fwp_rc_dup+0x60>
    6c9d:	c3                   	ret
    6c9e:	66 90                	xchg   %ax,%ax
    6ca0:	48 89 c7             	mov    %rax,%rdi
    6ca3:	e9 48 e7 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    6ca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6caf:	00 

0000000000006cb0 <fwp_owned_entry173>:
    6cb0:	f3 0f 1e fa          	endbr64
    6cb4:	48 83 ec 38          	sub    $0x38,%rsp
    6cb8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cbd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cc4:	00 00 
    6cc6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6ccb:	31 c0                	xor    %eax,%eax
    6ccd:	48 8b 07             	mov    (%rdi),%rax
    6cd0:	48 03 47 10          	add    0x10(%rdi),%rax
    6cd4:	0f 80 c2 00 00 00    	jo     6d9c <fwp_owned_entry173+0xec>
    6cda:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6cdf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ce4:	31 ff                	xor    %edi,%edi
    6ce6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6cea:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6cef:	e8 7c f0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    6cf4:	48 8b 15 9d de 01 00 	mov    0x1de9d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6cfb:	48 89 c6             	mov    %rax,%rsi
    6cfe:	48 2b 05 6b de 01 00 	sub    0x1de6b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6d05:	48 c1 e2 10          	shl    $0x10,%rdx
    6d09:	48 39 d0             	cmp    %rdx,%rax
    6d0c:	73 4f                	jae    6d5d <fwp_owned_entry173+0xad>
    6d0e:	48 89 c2             	mov    %rax,%rdx
    6d11:	48 c1 ea 10          	shr    $0x10,%rdx
    6d15:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d19:	48 8b 15 98 de 01 00 	mov    0x1de98(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6d20:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d24:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d28:	48 85 d2             	test   %rdx,%rdx
    6d2b:	74 30                	je     6d5d <fwp_owned_entry173+0xad>
    6d2d:	0f b6 39             	movzbl (%rcx),%edi
    6d30:	40 80 ff 02          	cmp    $0x2,%dil
    6d34:	74 42                	je     6d78 <fwp_owned_entry173+0xc8>
    6d36:	40 80 ff 01          	cmp    $0x1,%dil
    6d3a:	75 21                	jne    6d5d <fwp_owned_entry173+0xad>
    6d3c:	8b 79 18             	mov    0x18(%rcx),%edi
    6d3f:	0f b7 c0             	movzwl %ax,%eax
    6d42:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d45:	48 0f af c7          	imul   %rdi,%rax
    6d49:	48 c1 e8 20          	shr    $0x20,%rax
    6d4d:	48 39 c8             	cmp    %rcx,%rax
    6d50:	73 0b                	jae    6d5d <fwp_owned_entry173+0xad>
    6d52:	48 01 c2             	add    %rax,%rdx
    6d55:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d58:	74 26                	je     6d80 <fwp_owned_entry173+0xd0>
    6d5a:	c6 02 01             	movb   $0x1,(%rdx)
    6d5d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d62:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d69:	00 00 
    6d6b:	75 34                	jne    6da1 <fwp_owned_entry173+0xf1>
    6d6d:	48 89 f0             	mov    %rsi,%rax
    6d70:	48 83 c4 38          	add    $0x38,%rsp
    6d74:	c3                   	ret
    6d75:	0f 1f 00             	nopl   (%rax)
    6d78:	66 85 c0             	test   %ax,%ax
    6d7b:	75 e0                	jne    6d5d <fwp_owned_entry173+0xad>
    6d7d:	eb d6                	jmp    6d55 <fwp_owned_entry173+0xa5>
    6d7f:	90                   	nop
    6d80:	48 89 d7             	mov    %rdx,%rdi
    6d83:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6d88:	48 89 14 24          	mov    %rdx,(%rsp)
    6d8c:	e8 7f e7 ff ff       	call   5510 <fwp_rc_forget_slot>
    6d91:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6d96:	48 8b 14 24          	mov    (%rsp),%rdx
    6d9a:	eb be                	jmp    6d5a <fwp_owned_entry173+0xaa>
    6d9c:	e8 1f c9 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6da1:	e8 9a c6 ff ff       	call   3440 <__stack_chk_fail@plt>
    6da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dad:	00 00 00 

0000000000006db0 <e173>:
    6db0:	f3 0f 1e fa          	endbr64
    6db4:	53                   	push   %rbx
    6db5:	48 83 ec 30          	sub    $0x30,%rsp
    6db9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6dbe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6dc5:	00 00 
    6dc7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6dcc:	31 c0                	xor    %eax,%eax
    6dce:	48 8b 07             	mov    (%rdi),%rax
    6dd1:	48 03 47 10          	add    0x10(%rdi),%rax
    6dd5:	0f 80 c9 00 00 00    	jo     6ea4 <e173+0xf4>
    6ddb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6de0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6de5:	31 ff                	xor    %edi,%edi
    6de7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6deb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6df0:	e8 7b ef ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    6df5:	48 8b 15 9c dd 01 00 	mov    0x1dd9c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6dfc:	48 89 c3             	mov    %rax,%rbx
    6dff:	48 2b 05 6a dd 01 00 	sub    0x1dd6a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6e06:	48 c1 e2 10          	shl    $0x10,%rdx
    6e0a:	48 39 d0             	cmp    %rdx,%rax
    6e0d:	73 4f                	jae    6e5e <e173+0xae>
    6e0f:	48 89 c2             	mov    %rax,%rdx
    6e12:	48 c1 ea 10          	shr    $0x10,%rdx
    6e16:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e1a:	48 8b 15 97 dd 01 00 	mov    0x1dd97(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6e21:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e25:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e29:	48 85 d2             	test   %rdx,%rdx
    6e2c:	74 30                	je     6e5e <e173+0xae>
    6e2e:	0f b6 31             	movzbl (%rcx),%esi
    6e31:	40 80 fe 02          	cmp    $0x2,%sil
    6e35:	74 49                	je     6e80 <e173+0xd0>
    6e37:	40 80 fe 01          	cmp    $0x1,%sil
    6e3b:	75 21                	jne    6e5e <e173+0xae>
    6e3d:	8b 71 18             	mov    0x18(%rcx),%esi
    6e40:	0f b7 c0             	movzwl %ax,%eax
    6e43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e46:	48 0f af c6          	imul   %rsi,%rax
    6e4a:	48 c1 e8 20          	shr    $0x20,%rax
    6e4e:	48 39 c8             	cmp    %rcx,%rax
    6e51:	73 0b                	jae    6e5e <e173+0xae>
    6e53:	48 01 c2             	add    %rax,%rdx
    6e56:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e59:	74 35                	je     6e90 <e173+0xe0>
    6e5b:	c6 02 01             	movb   $0x1,(%rdx)
    6e5e:	48 89 df             	mov    %rbx,%rdi
    6e61:	e8 0a fc ff ff       	call   6a70 <fwp_rc_share>
    6e66:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e6b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e72:	00 00 
    6e74:	75 33                	jne    6ea9 <e173+0xf9>
    6e76:	48 83 c4 30          	add    $0x30,%rsp
    6e7a:	48 89 d8             	mov    %rbx,%rax
    6e7d:	5b                   	pop    %rbx
    6e7e:	c3                   	ret
    6e7f:	90                   	nop
    6e80:	66 85 c0             	test   %ax,%ax
    6e83:	75 d9                	jne    6e5e <e173+0xae>
    6e85:	eb cf                	jmp    6e56 <e173+0xa6>
    6e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e8e:	00 00 
    6e90:	48 89 d7             	mov    %rdx,%rdi
    6e93:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e98:	e8 73 e6 ff ff       	call   5510 <fwp_rc_forget_slot>
    6e9d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ea2:	eb b7                	jmp    6e5b <e173+0xab>
    6ea4:	e8 17 c8 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6ea9:	e8 92 c5 ff ff       	call   3440 <__stack_chk_fail@plt>
    6eae:	66 90                	xchg   %ax,%ax

0000000000006eb0 <fwp_closure_drop>:
    6eb0:	48 8b 15 e1 dc 01 00 	mov    0x1dce1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6eb7:	48 89 f8             	mov    %rdi,%rax
    6eba:	48 2b 05 af dc 01 00 	sub    0x1dcaf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6ec1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ec5:	48 39 d0             	cmp    %rdx,%rax
    6ec8:	73 6b                	jae    6f35 <fwp_closure_drop+0x85>
    6eca:	48 89 c2             	mov    %rax,%rdx
    6ecd:	48 c1 ea 10          	shr    $0x10,%rdx
    6ed1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ed5:	48 8b 15 dc dc 01 00 	mov    0x1dcdc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6edc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ee0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ee4:	48 85 d2             	test   %rdx,%rdx
    6ee7:	74 4c                	je     6f35 <fwp_closure_drop+0x85>
    6ee9:	0f b6 31             	movzbl (%rcx),%esi
    6eec:	40 80 fe 02          	cmp    $0x2,%sil
    6ef0:	74 3e                	je     6f30 <fwp_closure_drop+0x80>
    6ef2:	40 80 fe 01          	cmp    $0x1,%sil
    6ef6:	75 3d                	jne    6f35 <fwp_closure_drop+0x85>
    6ef8:	8b 71 18             	mov    0x18(%rcx),%esi
    6efb:	0f b7 c0             	movzwl %ax,%eax
    6efe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f01:	48 0f af c6          	imul   %rsi,%rax
    6f05:	48 c1 e8 20          	shr    $0x20,%rax
    6f09:	48 39 c8             	cmp    %rcx,%rax
    6f0c:	73 27                	jae    6f35 <fwp_closure_drop+0x85>
    6f0e:	48 01 c2             	add    %rax,%rdx
    6f11:	0f b6 02             	movzbl (%rdx),%eax
    6f14:	84 c0                	test   %al,%al
    6f16:	74 1d                	je     6f35 <fwp_closure_drop+0x85>
    6f18:	3c 01                	cmp    $0x1,%al
    6f1a:	74 24                	je     6f40 <fwp_closure_drop+0x90>
    6f1c:	3c ff                	cmp    $0xff,%al
    6f1e:	74 48                	je     6f68 <fwp_closure_drop+0xb8>
    6f20:	83 e8 01             	sub    $0x1,%eax
    6f23:	88 02                	mov    %al,(%rdx)
    6f25:	c3                   	ret
    6f26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f2d:	00 00 00 
    6f30:	66 85 c0             	test   %ax,%ax
    6f33:	74 dc                	je     6f11 <fwp_closure_drop+0x61>
    6f35:	c3                   	ret
    6f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f3d:	00 00 00 
    6f40:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6f47:	ff ff 
    6f49:	48 85 c0             	test   %rax,%rax
    6f4c:	74 12                	je     6f60 <fwp_closure_drop+0xb0>
    6f4e:	48 89 fe             	mov    %rdi,%rsi
    6f51:	48 89 c7             	mov    %rax,%rdi
    6f54:	e9 b7 d4 ff ff       	jmp    4410 <fwp_closure_drop_push>
    6f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f60:	e9 5b d6 ff ff       	jmp    45c0 <fwp_closure_drop.part.0>
    6f65:	0f 1f 00             	nopl   (%rax)
    6f68:	48 89 d0             	mov    %rdx,%rax
    6f6b:	48 8d 35 4e c8 01 00 	lea    0x1c84e(%rip),%rsi        # 237c0 <fwp_heap>
    6f72:	48 83 ec 18          	sub    $0x18,%rsp
    6f76:	48 c1 e8 11          	shr    $0x11,%rax
    6f7a:	48 31 d0             	xor    %rdx,%rax
    6f7d:	48 89 c1             	mov    %rax,%rcx
    6f80:	48 c1 e9 09          	shr    $0x9,%rcx
    6f84:	48 31 c8             	xor    %rcx,%rax
    6f87:	0f b6 c8             	movzbl %al,%ecx
    6f8a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6f91:	00 
    6f92:	48 85 c0             	test   %rax,%rax
    6f95:	75 12                	jne    6fa9 <fwp_closure_drop+0xf9>
    6f97:	eb 49                	jmp    6fe2 <fwp_closure_drop+0x132>
    6f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6fa4:	48 85 c0             	test   %rax,%rax
    6fa7:	74 39                	je     6fe2 <fwp_closure_drop+0x132>
    6fa9:	48 89 c1             	mov    %rax,%rcx
    6fac:	48 39 10             	cmp    %rdx,(%rax)
    6faf:	75 ef                	jne    6fa0 <fwp_closure_drop+0xf0>
    6fb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6fb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6fb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6fbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6fc4:	74 05                	je     6fcb <fwp_closure_drop+0x11b>
    6fc6:	48 83 c4 18          	add    $0x18,%rsp
    6fca:	c3                   	ret
    6fcb:	48 89 d7             	mov    %rdx,%rdi
    6fce:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fd3:	e8 38 e5 ff ff       	call   5510 <fwp_rc_forget_slot>
    6fd8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fdd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6fe0:	eb e4                	jmp    6fc6 <fwp_closure_drop+0x116>
    6fe2:	48 8d 3d a7 88 00 00 	lea    0x88a7(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6fe9:	e8 c2 d3 ff ff       	call   43b0 <fwp_trap>
    6fee:	66 90                	xchg   %ax,%ax

0000000000006ff0 <fwp_owned_tape_release>:
    6ff0:	48 85 ff             	test   %rdi,%rdi
    6ff3:	0f 84 f7 00 00 00    	je     70f0 <fwp_owned_tape_release+0x100>
    6ff9:	41 54                	push   %r12
    6ffb:	55                   	push   %rbp
    6ffc:	53                   	push   %rbx
    6ffd:	48 8b 07             	mov    (%rdi),%rax
    7000:	48 85 c0             	test   %rax,%rax
    7003:	74 08                	je     700d <fwp_owned_tape_release+0x1d>
    7005:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7009:	48 89 50 08          	mov    %rdx,0x8(%rax)
    700d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7011:	48 85 d2             	test   %rdx,%rdx
    7014:	74 03                	je     7019 <fwp_owned_tape_release+0x29>
    7016:	48 89 02             	mov    %rax,(%rdx)
    7019:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    701d:	48 89 fb             	mov    %rdi,%rbx
    7020:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7024:	48 85 c0             	test   %rax,%rax
    7027:	0f 84 89 00 00 00    	je     70b6 <fwp_owned_tape_release+0xc6>
    702d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7031:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7035:	7e 47                	jle    707e <fwp_owned_tape_release+0x8e>
    7037:	31 ed                	xor    %ebp,%ebp
    7039:	eb 0d                	jmp    7048 <fwp_owned_tape_release+0x58>
    703b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7040:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7044:	48 8b 40 68          	mov    0x68(%rax),%rax
    7048:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    704c:	49 89 ec             	mov    %rbp,%r12
    704f:	48 83 c5 01          	add    $0x1,%rbp
    7053:	49 c1 e4 04          	shl    $0x4,%r12
    7057:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    705b:	ff d0                	call   *%rax
    705d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7061:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7066:	48 8b 43 10          	mov    0x10(%rbx),%rax
    706a:	ff 50 68             	call   *0x68(%rax)
    706d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7071:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7075:	48 39 e8             	cmp    %rbp,%rax
    7078:	7f c6                	jg     7040 <fwp_owned_tape_release+0x50>
    707a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    707e:	31 ed                	xor    %ebp,%ebp
    7080:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7085:	7e 28                	jle    70af <fwp_owned_tape_release+0xbf>
    7087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    708e:	00 00 
    7090:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7094:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7098:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    709c:	74 07                	je     70a5 <fwp_owned_tape_release+0xb5>
    709e:	ff 52 68             	call   *0x68(%rdx)
    70a1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    70a5:	48 83 c5 01          	add    $0x1,%rbp
    70a9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    70ad:	7f e1                	jg     7090 <fwp_owned_tape_release+0xa0>
    70af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    70b3:	ff 52 68             	call   *0x68(%rdx)
    70b6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    70ba:	e8 f1 fd ff ff       	call   6eb0 <fwp_closure_drop>
    70bf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    70c3:	e8 e8 fd ff ff       	call   6eb0 <fwp_closure_drop>
    70c8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    70cc:	e8 df fd ff ff       	call   6eb0 <fwp_closure_drop>
    70d1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    70d5:	e8 76 e6 ff ff       	call   5750 <fwp_mem_free>
    70da:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    70de:	e8 6d e6 ff ff       	call   5750 <fwp_mem_free>
    70e3:	48 89 df             	mov    %rbx,%rdi
    70e6:	5b                   	pop    %rbx
    70e7:	5d                   	pop    %rbp
    70e8:	41 5c                	pop    %r12
    70ea:	e9 61 e6 ff ff       	jmp    5750 <fwp_mem_free>
    70ef:	90                   	nop
    70f0:	c3                   	ret
    70f1:	0f 1f 40 00          	nopl   0x0(%rax)
    70f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70fc:	00 00 00 00 

0000000000007100 <fwp_tape_finish>:
    7100:	f3 0f 1e fa          	endbr64
    7104:	41 56                	push   %r14
    7106:	48 8d 3d 93 bf 01 00 	lea    0x1bf93(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    710d:	41 55                	push   %r13
    710f:	41 54                	push   %r12
    7111:	55                   	push   %rbp
    7112:	53                   	push   %rbx
    7113:	e8 b8 cf ff ff       	call   40d0 <fwp_tape_buffers_dispose>
    7118:	48 83 3d b8 bf 01 00 	cmpq   $0x0,0x1bfb8(%rip)        # 230d8 <fwp_ntapes>
    711f:	00 
    7120:	48 c7 05 5d bf 01 00 	movq   $0x0,0x1bf5d(%rip)        # 23088 <fwp_tape_cached_bytes>
    7127:	00 00 00 00 
    712b:	7e 68                	jle    7195 <fwp_tape_finish+0x95>
    712d:	45 31 e4             	xor    %r12d,%r12d
    7130:	31 ed                	xor    %ebp,%ebp
    7132:	0f 1f 00             	nopl   (%rax)
    7135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    713c:	00 00 00 00 
    7140:	48 8b 1d 99 bf 01 00 	mov    0x1bf99(%rip),%rbx        # 230e0 <fwp_tapes>
    7147:	48 83 c5 01          	add    $0x1,%rbp
    714b:	4c 01 e3             	add    %r12,%rbx
    714e:	49 83 c4 58          	add    $0x58,%r12
    7152:	48 89 df             	mov    %rbx,%rdi
    7155:	e8 66 ca ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    715a:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    715e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7162:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
    7166:	e8 35 c2 ff ff       	call   33a0 <free@plt>
    716b:	4c 89 f7             	mov    %r14,%rdi
    716e:	e8 2d c2 ff ff       	call   33a0 <free@plt>
    7173:	4c 89 ef             	mov    %r13,%rdi
    7176:	e8 25 c2 ff ff       	call   33a0 <free@plt>
    717b:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    717f:	e8 6c fe ff ff       	call   6ff0 <fwp_owned_tape_release>
    7184:	48 39 2d 4d bf 01 00 	cmp    %rbp,0x1bf4d(%rip)        # 230d8 <fwp_ntapes>
    718b:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    7192:	00 
    7193:	7f ab                	jg     7140 <fwp_tape_finish+0x40>
    7195:	48 8b 3d 44 bf 01 00 	mov    0x1bf44(%rip),%rdi        # 230e0 <fwp_tapes>
    719c:	e8 ff c1 ff ff       	call   33a0 <free@plt>
    71a1:	5b                   	pop    %rbx
    71a2:	5d                   	pop    %rbp
    71a3:	48 c7 05 32 bf 01 00 	movq   $0x0,0x1bf32(%rip)        # 230e0 <fwp_tapes>
    71aa:	00 00 00 00 
    71ae:	48 c7 05 17 bf 01 00 	movq   $0x0,0x1bf17(%rip)        # 230d0 <fwp_tapes_cap>
    71b5:	00 00 00 00 
    71b9:	41 5c                	pop    %r12
    71bb:	48 c7 05 12 bf 01 00 	movq   $0x0,0x1bf12(%rip)        # 230d8 <fwp_ntapes>
    71c2:	00 00 00 00 
    71c6:	41 5d                	pop    %r13
    71c8:	48 c7 05 f5 be 01 00 	movq   $0x0,0x1bef5(%rip)        # 230c8 <fwp_tape_next_slot>
    71cf:	00 00 00 00 
    71d3:	41 5e                	pop    %r14
    71d5:	c3                   	ret
    71d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71dd:	00 00 00 

00000000000071e0 <fwp_tape_scope_release>:
    71e0:	f3 0f 1e fa          	endbr64
    71e4:	41 55                	push   %r13
    71e6:	41 54                	push   %r12
    71e8:	55                   	push   %rbp
    71e9:	53                   	push   %rbx
    71ea:	48 83 ec 48          	sub    $0x48,%rsp
    71ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    71f5:	00 00 
    71f7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    71fc:	48 63 07             	movslq (%rdi),%rax
    71ff:	85 c0                	test   %eax,%eax
    7201:	0f 88 f8 00 00 00    	js     72ff <fwp_tape_scope_release+0x11f>
    7207:	48 bd a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%rbp
    720e:	a2 8b 2e 
    7211:	48 89 fb             	mov    %rdi,%rbx
    7214:	eb 3d                	jmp    7253 <fwp_tape_scope_release+0x73>
    7216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    721d:	00 00 00 
    7220:	66 48 0f 7e c7       	movq   %xmm0,%rdi
    7225:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7229:	e8 72 c1 ff ff       	call   33a0 <free@plt>
    722e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7233:	e8 68 c1 ff ff       	call   33a0 <free@plt>
    7238:	4c 89 ef             	mov    %r13,%rdi
    723b:	e8 60 c1 ff ff       	call   33a0 <free@plt>
    7240:	4c 89 e7             	mov    %r12,%rdi
    7243:	e8 a8 fd ff ff       	call   6ff0 <fwp_owned_tape_release>
    7248:	48 63 03             	movslq (%rbx),%rax
    724b:	85 c0                	test   %eax,%eax
    724d:	0f 88 ac 00 00 00    	js     72ff <fwp_tape_scope_release+0x11f>
    7253:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    7257:	48 8b 35 82 be 01 00 	mov    0x1be82(%rip),%rsi        # 230e0 <fwp_tapes>
    725e:	4c 01 c6             	add    %r8,%rsi
    7261:	48 89 f7             	mov    %rsi,%rdi
    7264:	e8 57 c9 ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    7269:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    726e:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
    7272:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7279:	f3 0f 7e 4e 18       	movq   0x18(%rsi),%xmm1
    727e:	0f 16 4e 38          	movhps 0x38(%rsi),%xmm1
    7282:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
    7287:	66 0f ef c9          	pxor   %xmm1,%xmm1
    728b:	4c 8b 66 50          	mov    0x50(%rsi),%r12
    728f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
    7294:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    729b:	00 
    729c:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    72a3:	00 
    72a4:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    72ab:	00 
    72ac:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    72b3:	00 
    72b4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    72b9:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    72bd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    72c1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    72c7:	77 18                	ja     72e1 <fwp_tape_scope_release+0x101>
    72c9:	49 c1 f8 03          	sar    $0x3,%r8
    72cd:	4c 0f af c5          	imul   %rbp,%r8
    72d1:	4c 3b 05 f0 bd 01 00 	cmp    0x1bdf0(%rip),%r8        # 230c8 <fwp_tape_next_slot>
    72d8:	7d 07                	jge    72e1 <fwp_tape_scope_release+0x101>
    72da:	4c 89 05 e7 bd 01 00 	mov    %r8,0x1bde7(%rip)        # 230c8 <fwp_tape_next_slot>
    72e1:	4d 85 e4             	test   %r12,%r12
    72e4:	0f 85 36 ff ff ff    	jne    7220 <fwp_tape_scope_release+0x40>
    72ea:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    72ef:	e8 3c dd ff ff       	call   5030 <fwp_tape_buffers_release>
    72f4:	48 63 03             	movslq (%rbx),%rax
    72f7:	85 c0                	test   %eax,%eax
    72f9:	0f 89 54 ff ff ff    	jns    7253 <fwp_tape_scope_release+0x73>
    72ff:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7304:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    730b:	00 00 
    730d:	75 0b                	jne    731a <fwp_tape_scope_release+0x13a>
    730f:	48 83 c4 48          	add    $0x48,%rsp
    7313:	5b                   	pop    %rbx
    7314:	5d                   	pop    %rbp
    7315:	41 5c                	pop    %r12
    7317:	41 5d                	pop    %r13
    7319:	c3                   	ret
    731a:	e8 21 c1 ff ff       	call   3440 <__stack_chk_fail@plt>
    731f:	90                   	nop

0000000000007320 <fwp_drop4>:
    7320:	48 8b 0d 71 d8 01 00 	mov    0x1d871(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7327:	48 89 f8             	mov    %rdi,%rax
    732a:	48 2b 05 3f d8 01 00 	sub    0x1d83f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7331:	48 c1 e1 10          	shl    $0x10,%rcx
    7335:	48 39 c8             	cmp    %rcx,%rax
    7338:	0f 83 42 01 00 00    	jae    7480 <fwp_drop4+0x160>
    733e:	48 83 ec 18          	sub    $0x18,%rsp
    7342:	48 89 fa             	mov    %rdi,%rdx
    7345:	4c 8d 05 74 c4 01 00 	lea    0x1c474(%rip),%r8        # 237c0 <fwp_heap>
    734c:	48 89 c1             	mov    %rax,%rcx
    734f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7356:	48 c1 e9 10          	shr    $0x10,%rcx
    735a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    735e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7362:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7366:	48 85 c9             	test   %rcx,%rcx
    7369:	74 40                	je     73ab <fwp_drop4+0x8b>
    736b:	0f b6 3e             	movzbl (%rsi),%edi
    736e:	40 80 ff 02          	cmp    $0x2,%dil
    7372:	74 3c                	je     73b0 <fwp_drop4+0x90>
    7374:	40 80 ff 01          	cmp    $0x1,%dil
    7378:	75 31                	jne    73ab <fwp_drop4+0x8b>
    737a:	8b 7e 18             	mov    0x18(%rsi),%edi
    737d:	0f b7 c0             	movzwl %ax,%eax
    7380:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7383:	48 0f af c7          	imul   %rdi,%rax
    7387:	48 c1 e8 20          	shr    $0x20,%rax
    738b:	48 39 f0             	cmp    %rsi,%rax
    738e:	73 1b                	jae    73ab <fwp_drop4+0x8b>
    7390:	48 01 c1             	add    %rax,%rcx
    7393:	0f b6 01             	movzbl (%rcx),%eax
    7396:	84 c0                	test   %al,%al
    7398:	74 11                	je     73ab <fwp_drop4+0x8b>
    739a:	3c 01                	cmp    $0x1,%al
    739c:	74 22                	je     73c0 <fwp_drop4+0xa0>
    739e:	3c ff                	cmp    $0xff,%al
    73a0:	0f 84 0a 01 00 00    	je     74b0 <fwp_drop4+0x190>
    73a6:	83 e8 01             	sub    $0x1,%eax
    73a9:	88 01                	mov    %al,(%rcx)
    73ab:	48 83 c4 18          	add    $0x18,%rsp
    73af:	c3                   	ret
    73b0:	66 85 c0             	test   %ax,%ax
    73b3:	74 de                	je     7393 <fwp_drop4+0x73>
    73b5:	48 83 c4 18          	add    $0x18,%rsp
    73b9:	c3                   	ret
    73ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73c0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    73c4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    73cb:	48 89 f8             	mov    %rdi,%rax
    73ce:	48 c1 e1 10          	shl    $0x10,%rcx
    73d2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73d9:	48 39 c8             	cmp    %rcx,%rax
    73dc:	73 62                	jae    7440 <fwp_drop4+0x120>
    73de:	48 89 c1             	mov    %rax,%rcx
    73e1:	48 c1 e9 10          	shr    $0x10,%rcx
    73e5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    73e9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    73ed:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    73f1:	48 85 c9             	test   %rcx,%rcx
    73f4:	74 4a                	je     7440 <fwp_drop4+0x120>
    73f6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    73fa:	41 80 f9 02          	cmp    $0x2,%r9b
    73fe:	0f 84 9c 00 00 00    	je     74a0 <fwp_drop4+0x180>
    7404:	41 80 f9 01          	cmp    $0x1,%r9b
    7408:	75 36                	jne    7440 <fwp_drop4+0x120>
    740a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    740e:	0f b7 c0             	movzwl %ax,%eax
    7411:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7414:	49 0f af c1          	imul   %r9,%rax
    7418:	48 c1 e8 20          	shr    $0x20,%rax
    741c:	48 39 f0             	cmp    %rsi,%rax
    741f:	73 1f                	jae    7440 <fwp_drop4+0x120>
    7421:	48 01 c1             	add    %rax,%rcx
    7424:	0f b6 01             	movzbl (%rcx),%eax
    7427:	84 c0                	test   %al,%al
    7429:	74 15                	je     7440 <fwp_drop4+0x120>
    742b:	3c 01                	cmp    $0x1,%al
    742d:	74 59                	je     7488 <fwp_drop4+0x168>
    742f:	3c ff                	cmp    $0xff,%al
    7431:	0f 84 ef 00 00 00    	je     7526 <fwp_drop4+0x206>
    7437:	83 e8 01             	sub    $0x1,%eax
    743a:	88 01                	mov    %al,(%rcx)
    743c:	0f 1f 40 00          	nopl   0x0(%rax)
    7440:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7444:	48 89 d7             	mov    %rdx,%rdi
    7447:	48 89 0c 24          	mov    %rcx,(%rsp)
    744b:	e8 50 f7 ff ff       	call   6ba0 <fwp_rc_free_obj>
    7450:	4c 8d 05 69 c3 01 00 	lea    0x1c369(%rip),%r8        # 237c0 <fwp_heap>
    7457:	48 8b 04 24          	mov    (%rsp),%rax
    745b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7462:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7469:	48 c1 e2 10          	shl    $0x10,%rdx
    746d:	48 39 d0             	cmp    %rdx,%rax
    7470:	0f 83 35 ff ff ff    	jae    73ab <fwp_drop4+0x8b>
    7476:	48 8b 14 24          	mov    (%rsp),%rdx
    747a:	e9 cd fe ff ff       	jmp    734c <fwp_drop4+0x2c>
    747f:	90                   	nop
    7480:	c3                   	ret
    7481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7488:	48 89 14 24          	mov    %rdx,(%rsp)
    748c:	e8 0f f7 ff ff       	call   6ba0 <fwp_rc_free_obj>
    7491:	48 8b 14 24          	mov    (%rsp),%rdx
    7495:	eb a9                	jmp    7440 <fwp_drop4+0x120>
    7497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    749e:	00 00 
    74a0:	66 85 c0             	test   %ax,%ax
    74a3:	75 9b                	jne    7440 <fwp_drop4+0x120>
    74a5:	e9 7a ff ff ff       	jmp    7424 <fwp_drop4+0x104>
    74aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74b0:	48 89 c8             	mov    %rcx,%rax
    74b3:	48 c1 e8 11          	shr    $0x11,%rax
    74b7:	48 31 c8             	xor    %rcx,%rax
    74ba:	48 89 c2             	mov    %rax,%rdx
    74bd:	48 c1 ea 09          	shr    $0x9,%rdx
    74c1:	48 31 d0             	xor    %rdx,%rax
    74c4:	0f b6 d0             	movzbl %al,%edx
    74c7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    74ce:	00 
    74cf:	48 85 c0             	test   %rax,%rax
    74d2:	75 19                	jne    74ed <fwp_drop4+0x1cd>
    74d4:	e9 d3 00 00 00       	jmp    75ac <fwp_drop4+0x28c>
    74d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    74e4:	48 85 c0             	test   %rax,%rax
    74e7:	0f 84 bf 00 00 00    	je     75ac <fwp_drop4+0x28c>
    74ed:	48 89 c2             	mov    %rax,%rdx
    74f0:	48 39 08             	cmp    %rcx,(%rax)
    74f3:	75 eb                	jne    74e0 <fwp_drop4+0x1c0>
    74f5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    74f9:	48 83 ea 01          	sub    $0x1,%rdx
    74fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7501:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7508:	0f 85 9d fe ff ff    	jne    73ab <fwp_drop4+0x8b>
    750e:	48 89 cf             	mov    %rcx,%rdi
    7511:	48 89 0c 24          	mov    %rcx,(%rsp)
    7515:	e8 f6 df ff ff       	call   5510 <fwp_rc_forget_slot>
    751a:	48 8b 0c 24          	mov    (%rsp),%rcx
    751e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7521:	e9 85 fe ff ff       	jmp    73ab <fwp_drop4+0x8b>
    7526:	48 89 ce             	mov    %rcx,%rsi
    7529:	48 c1 ee 11          	shr    $0x11,%rsi
    752d:	48 31 ce             	xor    %rcx,%rsi
    7530:	48 89 f0             	mov    %rsi,%rax
    7533:	48 c1 e8 09          	shr    $0x9,%rax
    7537:	48 31 c6             	xor    %rax,%rsi
    753a:	40 0f b6 f6          	movzbl %sil,%esi
    753e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7545:	00 
    7546:	48 85 c0             	test   %rax,%rax
    7549:	75 1e                	jne    7569 <fwp_drop4+0x249>
    754b:	eb 5f                	jmp    75ac <fwp_drop4+0x28c>
    754d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7554:	00 
    7555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    755c:	00 00 00 00 
    7560:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7564:	48 85 c0             	test   %rax,%rax
    7567:	74 43                	je     75ac <fwp_drop4+0x28c>
    7569:	48 89 c6             	mov    %rax,%rsi
    756c:	48 39 08             	cmp    %rcx,(%rax)
    756f:	75 ef                	jne    7560 <fwp_drop4+0x240>
    7571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7575:	48 83 ee 01          	sub    $0x1,%rsi
    7579:	48 89 70 08          	mov    %rsi,0x8(%rax)
    757d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7584:	0f 85 b6 fe ff ff    	jne    7440 <fwp_drop4+0x120>
    758a:	48 89 cf             	mov    %rcx,%rdi
    758d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7592:	48 89 0c 24          	mov    %rcx,(%rsp)
    7596:	e8 75 df ff ff       	call   5510 <fwp_rc_forget_slot>
    759b:	48 8b 0c 24          	mov    (%rsp),%rcx
    759f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75a4:	c6 01 fe             	movb   $0xfe,(%rcx)
    75a7:	e9 94 fe ff ff       	jmp    7440 <fwp_drop4+0x120>
    75ac:	48 8d 3d dd 82 00 00 	lea    0x82dd(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    75b3:	e8 f8 cd ff ff       	call   43b0 <fwp_trap>
    75b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75bf:	00 

00000000000075c0 <fwp_arg_drop37>:
    75c0:	f3 0f 1e fa          	endbr64
    75c4:	85 f6                	test   %esi,%esi
    75c6:	75 04                	jne    75cc <fwp_arg_drop37+0xc>
    75c8:	85 d2                	test   %edx,%edx
    75ca:	75 04                	jne    75d0 <fwp_arg_drop37+0x10>
    75cc:	c3                   	ret
    75cd:	0f 1f 00             	nopl   (%rax)
    75d0:	48 8b 3f             	mov    (%rdi),%rdi
    75d3:	e9 48 fd ff ff       	jmp    7320 <fwp_drop4>
    75d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75df:	00 

00000000000075e0 <fwp_task_dispose>:
    75e0:	53                   	push   %rbx
    75e1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    75e5:	0f 84 1b c1 ff ff    	je     3706 <fwp_task_dispose.cold>
    75eb:	48 89 fb             	mov    %rdi,%rbx
    75ee:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    75f3:	0f 85 0d c1 ff ff    	jne    3706 <fwp_task_dispose.cold>
    75f9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    75fd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7604:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    760b:	00 
    760c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7610:	48 85 ff             	test   %rdi,%rdi
    7613:	74 07                	je     761c <fwp_task_dispose+0x3c>
    7615:	48 85 c0             	test   %rax,%rax
    7618:	74 02                	je     761c <fwp_task_dispose+0x3c>
    761a:	ff d0                	call   *%rax
    761c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7623:	e8 28 e1 ff ff       	call   5750 <fwp_mem_free>
    7628:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    762f:	00 00 00 00 
    7633:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7637:	74 6f                	je     76a8 <fwp_task_dispose+0xc8>
    7639:	48 8b 15 58 d5 01 00 	mov    0x1d558(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7640:	48 89 d8             	mov    %rbx,%rax
    7643:	48 2b 05 26 d5 01 00 	sub    0x1d526(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    764a:	48 c1 e2 10          	shl    $0x10,%rdx
    764e:	48 39 d0             	cmp    %rdx,%rax
    7651:	73 4c                	jae    769f <fwp_task_dispose+0xbf>
    7653:	48 89 c2             	mov    %rax,%rdx
    7656:	48 c1 ea 10          	shr    $0x10,%rdx
    765a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    765e:	48 8b 15 53 d5 01 00 	mov    0x1d553(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7665:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7669:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    766d:	48 85 c9             	test   %rcx,%rcx
    7670:	74 2d                	je     769f <fwp_task_dispose+0xbf>
    7672:	0f b6 32             	movzbl (%rdx),%esi
    7675:	40 80 fe 02          	cmp    $0x2,%sil
    7679:	74 3d                	je     76b8 <fwp_task_dispose+0xd8>
    767b:	40 80 fe 01          	cmp    $0x1,%sil
    767f:	75 1e                	jne    769f <fwp_task_dispose+0xbf>
    7681:	8b 72 18             	mov    0x18(%rdx),%esi
    7684:	0f b7 c0             	movzwl %ax,%eax
    7687:	8b 52 1c             	mov    0x1c(%rdx),%edx
    768a:	48 0f af c6          	imul   %rsi,%rax
    768e:	48 c1 e8 20          	shr    $0x20,%rax
    7692:	48 39 d0             	cmp    %rdx,%rax
    7695:	73 08                	jae    769f <fwp_task_dispose+0xbf>
    7697:	48 01 c1             	add    %rax,%rcx
    769a:	80 39 01             	cmpb   $0x1,(%rcx)
    769d:	74 09                	je     76a8 <fwp_task_dispose+0xc8>
    769f:	5b                   	pop    %rbx
    76a0:	c3                   	ret
    76a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76a8:	48 89 df             	mov    %rbx,%rdi
    76ab:	5b                   	pop    %rbx
    76ac:	e9 9f e0 ff ff       	jmp    5750 <fwp_mem_free>
    76b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76b8:	66 85 c0             	test   %ax,%ax
    76bb:	74 dd                	je     769a <fwp_task_dispose+0xba>
    76bd:	5b                   	pop    %rbx
    76be:	c3                   	ret
    76bf:	90                   	nop

00000000000076c0 <fwp_free_zombie>:
    76c0:	48 8b 15 c9 c0 01 00 	mov    0x1c0c9(%rip),%rdx        # 23790 <fwp_zombie>
    76c7:	48 85 d2             	test   %rdx,%rdx
    76ca:	0f 84 98 00 00 00    	je     7768 <fwp_free_zombie+0xa8>
    76d0:	48 3b 15 c9 c0 01 00 	cmp    0x1c0c9(%rip),%rdx        # 237a0 <fwp_cur>
    76d7:	0f 84 8b 00 00 00    	je     7768 <fwp_free_zombie+0xa8>
    76dd:	48 83 ec 18          	sub    $0x18,%rsp
    76e1:	48 63 05 7c ba 01 00 	movslq 0x1ba7c(%rip),%rax        # 23164 <fwp_stack_pool_n>
    76e8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    76ec:	83 f8 3f             	cmp    $0x3f,%eax
    76ef:	7f 7f                	jg     7770 <fwp_free_zombie+0xb0>
    76f1:	8d 48 01             	lea    0x1(%rax),%ecx
    76f4:	89 0d 6a ba 01 00    	mov    %ecx,0x1ba6a(%rip)        # 23164 <fwp_stack_pool_n>
    76fa:	48 8d 0d 7f ba 01 00 	lea    0x1ba7f(%rip),%rcx        # 23180 <fwp_stack_pool>
    7701:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7705:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    770c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7710:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7717:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    771b:	48 85 c9             	test   %rcx,%rcx
    771e:	0f 84 fc 00 00 00    	je     7820 <fwp_free_zombie+0x160>
    7724:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    772b:	48 85 c0             	test   %rax,%rax
    772e:	74 07                	je     7737 <fwp_free_zombie+0x77>
    7730:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7737:	8b 42 5c             	mov    0x5c(%rdx),%eax
    773a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    773e:	48 c7 05 47 c0 01 00 	movq   $0x0,0x1c047(%rip)        # 23790 <fwp_zombie>
    7745:	00 00 00 00 
    7749:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7750:	85 c0                	test   %eax,%eax
    7752:	74 34                	je     7788 <fwp_free_zombie+0xc8>
    7754:	83 f8 01             	cmp    $0x1,%eax
    7757:	0f 84 b3 00 00 00    	je     7810 <fwp_free_zombie+0x150>
    775d:	48 83 c4 18          	add    $0x18,%rsp
    7761:	c3                   	ret
    7762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7768:	c3                   	ret
    7769:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7770:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7774:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7779:	e8 32 be ff ff       	call   35b0 <munmap@plt>
    777e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7783:	eb 80                	jmp    7705 <fwp_free_zombie+0x45>
    7785:	0f 1f 00             	nopl   (%rax)
    7788:	48 8b 0d 09 d4 01 00 	mov    0x1d409(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    778f:	48 89 d0             	mov    %rdx,%rax
    7792:	48 2b 05 d7 d3 01 00 	sub    0x1d3d7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7799:	48 c1 e1 10          	shl    $0x10,%rcx
    779d:	48 39 c8             	cmp    %rcx,%rax
    77a0:	73 bb                	jae    775d <fwp_free_zombie+0x9d>
    77a2:	48 89 c1             	mov    %rax,%rcx
    77a5:	48 c1 e9 10          	shr    $0x10,%rcx
    77a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77ad:	48 8b 0d 04 d4 01 00 	mov    0x1d404(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    77b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    77b8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    77bc:	48 85 c9             	test   %rcx,%rcx
    77bf:	74 9c                	je     775d <fwp_free_zombie+0x9d>
    77c1:	0f b6 3e             	movzbl (%rsi),%edi
    77c4:	40 80 ff 02          	cmp    $0x2,%dil
    77c8:	74 66                	je     7830 <fwp_free_zombie+0x170>
    77ca:	40 80 ff 01          	cmp    $0x1,%dil
    77ce:	75 8d                	jne    775d <fwp_free_zombie+0x9d>
    77d0:	8b 7e 18             	mov    0x18(%rsi),%edi
    77d3:	0f b7 c0             	movzwl %ax,%eax
    77d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    77d9:	48 0f af c7          	imul   %rdi,%rax
    77dd:	48 c1 e8 20          	shr    $0x20,%rax
    77e1:	48 39 f0             	cmp    %rsi,%rax
    77e4:	0f 83 73 ff ff ff    	jae    775d <fwp_free_zombie+0x9d>
    77ea:	48 01 c1             	add    %rax,%rcx
    77ed:	0f b6 01             	movzbl (%rcx),%eax
    77f0:	84 c0                	test   %al,%al
    77f2:	0f 84 65 ff ff ff    	je     775d <fwp_free_zombie+0x9d>
    77f8:	3c 01                	cmp    $0x1,%al
    77fa:	74 14                	je     7810 <fwp_free_zombie+0x150>
    77fc:	3c ff                	cmp    $0xff,%al
    77fe:	74 3b                	je     783b <fwp_free_zombie+0x17b>
    7800:	83 e8 01             	sub    $0x1,%eax
    7803:	88 01                	mov    %al,(%rcx)
    7805:	e9 53 ff ff ff       	jmp    775d <fwp_free_zombie+0x9d>
    780a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7810:	48 89 d7             	mov    %rdx,%rdi
    7813:	48 83 c4 18          	add    $0x18,%rsp
    7817:	e9 c4 fd ff ff       	jmp    75e0 <fwp_task_dispose>
    781c:	0f 1f 40 00          	nopl   0x0(%rax)
    7820:	48 89 05 41 bf 01 00 	mov    %rax,0x1bf41(%rip)        # 23768 <fwp_tasks_active>
    7827:	e9 ff fe ff ff       	jmp    772b <fwp_free_zombie+0x6b>
    782c:	0f 1f 40 00          	nopl   0x0(%rax)
    7830:	66 85 c0             	test   %ax,%ax
    7833:	0f 85 24 ff ff ff    	jne    775d <fwp_free_zombie+0x9d>
    7839:	eb b2                	jmp    77ed <fwp_free_zombie+0x12d>
    783b:	48 89 ca             	mov    %rcx,%rdx
    783e:	48 8d 35 7b bf 01 00 	lea    0x1bf7b(%rip),%rsi        # 237c0 <fwp_heap>
    7845:	48 c1 ea 11          	shr    $0x11,%rdx
    7849:	48 31 ca             	xor    %rcx,%rdx
    784c:	48 89 d0             	mov    %rdx,%rax
    784f:	48 c1 e8 09          	shr    $0x9,%rax
    7853:	48 31 c2             	xor    %rax,%rdx
    7856:	0f b6 d2             	movzbl %dl,%edx
    7859:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7860:	00 
    7861:	48 85 c0             	test   %rax,%rax
    7864:	75 23                	jne    7889 <fwp_free_zombie+0x1c9>
    7866:	eb 5c                	jmp    78c4 <fwp_free_zombie+0x204>
    7868:	66 90                	xchg   %ax,%ax
    786a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7871:	00 00 00 00 
    7875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    787c:	00 00 00 00 
    7880:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7884:	48 85 c0             	test   %rax,%rax
    7887:	74 3b                	je     78c4 <fwp_free_zombie+0x204>
    7889:	48 89 c2             	mov    %rax,%rdx
    788c:	48 39 08             	cmp    %rcx,(%rax)
    788f:	75 ef                	jne    7880 <fwp_free_zombie+0x1c0>
    7891:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7895:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7899:	48 89 50 08          	mov    %rdx,0x8(%rax)
    789d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    78a4:	0f 85 b3 fe ff ff    	jne    775d <fwp_free_zombie+0x9d>
    78aa:	48 89 cf             	mov    %rcx,%rdi
    78ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78b2:	e8 59 dc ff ff       	call   5510 <fwp_rc_forget_slot>
    78b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    78bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    78bf:	e9 99 fe ff ff       	jmp    775d <fwp_free_zombie+0x9d>
    78c4:	48 8d 3d c5 7f 00 00 	lea    0x7fc5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    78cb:	e8 e0 ca ff ff       	call   43b0 <fwp_trap>

00000000000078d0 <fwp_block>:
    78d0:	48 83 ec 08          	sub    $0x8,%rsp
    78d4:	48 8b 05 ad be 01 00 	mov    0x1bead(%rip),%rax        # 23788 <fwp_ready_head>
    78db:	48 85 c0             	test   %rax,%rax
    78de:	0f 84 1c 01 00 00    	je     7a00 <fwp_block+0x130>
    78e4:	90                   	nop
    78e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78ec:	00 00 00 00 
    78f0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    78f7:	48 89 15 8a be 01 00 	mov    %rdx,0x1be8a(%rip)        # 23788 <fwp_ready_head>
    78fe:	48 85 d2             	test   %rdx,%rdx
    7901:	0f 84 19 01 00 00    	je     7a20 <fwp_block+0x150>
    7907:	48 8b 15 92 be 01 00 	mov    0x1be92(%rip),%rdx        # 237a0 <fwp_cur>
    790e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7912:	48 39 c2             	cmp    %rax,%rdx
    7915:	0f 84 d5 00 00 00    	je     79f0 <fwp_block+0x120>
    791b:	48 8b 0d 06 db 01 00 	mov    0x1db06(%rip),%rcx        # 25428 <fwp_state_owners>
    7922:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7926:	48 89 05 73 be 01 00 	mov    %rax,0x1be73(%rip)        # 237a0 <fwp_cur>
    792d:	f3 0f 7e 05 1b db 01 	movq   0x1db1b(%rip),%xmm0        # 25450 <fwp_foreign_callbacks>
    7934:	00 
    7935:	0f 16 05 04 db 01 00 	movhps 0x1db04(%rip),%xmm0        # 25440 <fwp_state>
    793c:	f3 0f 7e 0d 04 db 01 	movq   0x1db04(%rip),%xmm1        # 25448 <fwp_handlers>
    7943:	00 
    7944:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    794b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7952:	0f 16 0d ff da 01 00 	movhps 0x1daff(%rip),%xmm1        # 25458 <fwp_cleanups>
    7959:	f3 0f 7e 05 d7 da 01 	movq   0x1dad7(%rip),%xmm0        # 25438 <fwp_state_len>
    7960:	00 
    7961:	0f 16 05 c8 da 01 00 	movhps 0x1dac8(%rip),%xmm0        # 25430 <fwp_state_cap>
    7968:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    796f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7976:	48 8b 70 08          	mov    0x8(%rax),%rsi
    797a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7981:	48 89 0d c0 da 01 00 	mov    %rcx,0x1dac0(%rip)        # 25448 <fwp_handlers>
    7988:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    798f:	48 89 0d c2 da 01 00 	mov    %rcx,0x1dac2(%rip)        # 25458 <fwp_cleanups>
    7996:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    799d:	48 89 0d ac da 01 00 	mov    %rcx,0x1daac(%rip)        # 25450 <fwp_foreign_callbacks>
    79a4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    79ab:	48 89 0d 8e da 01 00 	mov    %rcx,0x1da8e(%rip)        # 25440 <fwp_state>
    79b2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    79b9:	48 89 0d 78 da 01 00 	mov    %rcx,0x1da78(%rip)        # 25438 <fwp_state_len>
    79c0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    79c7:	48 89 0d 62 da 01 00 	mov    %rcx,0x1da62(%rip)        # 25430 <fwp_state_cap>
    79ce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    79d5:	48 89 0d 4c da 01 00 	mov    %rcx,0x1da4c(%rip)        # 25428 <fwp_state_owners>
    79dc:	e8 8f ba ff ff       	call   3470 <swapcontext@plt>
    79e1:	f3 0f 1e fa          	endbr64
    79e5:	e8 d6 fc ff ff       	call   76c0 <fwp_free_zombie>
    79ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79f0:	8b 05 6a b7 01 00    	mov    0x1b76a(%rip),%eax        # 23160 <fwp_slice>
    79f6:	85 c0                	test   %eax,%eax
    79f8:	74 36                	je     7a30 <fwp_block+0x160>
    79fa:	48 83 c4 08          	add    $0x8,%rsp
    79fe:	c3                   	ret
    79ff:	90                   	nop
    7a00:	e8 4b d7 ff ff       	call   5150 <fwp_poll_events>
    7a05:	48 8b 05 7c bd 01 00 	mov    0x1bd7c(%rip),%rax        # 23788 <fwp_ready_head>
    7a0c:	48 85 c0             	test   %rax,%rax
    7a0f:	0f 85 db fe ff ff    	jne    78f0 <fwp_block+0x20>
    7a15:	eb e9                	jmp    7a00 <fwp_block+0x130>
    7a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a1e:	00 00 
    7a20:	48 c7 05 55 bd 01 00 	movq   $0x0,0x1bd55(%rip)        # 23780 <fwp_ready_tail>
    7a27:	00 00 00 00 
    7a2b:	e9 d7 fe ff ff       	jmp    7907 <fwp_block+0x37>
    7a30:	48 8d 3d 4d 77 00 00 	lea    0x774d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7a37:	e8 44 b9 ff ff       	call   3380 <getenv@plt>
    7a3c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7a41:	48 85 c0             	test   %rax,%rax
    7a44:	74 05                	je     7a4b <fwp_block+0x17b>
    7a46:	80 38 00             	cmpb   $0x0,(%rax)
    7a49:	75 0b                	jne    7a56 <fwp_block+0x186>
    7a4b:	89 15 0f b7 01 00    	mov    %edx,0x1b70f(%rip)        # 23160 <fwp_slice>
    7a51:	48 83 c4 08          	add    $0x8,%rsp
    7a55:	c3                   	ret
    7a56:	ba 0a 00 00 00       	mov    $0xa,%edx
    7a5b:	31 f6                	xor    %esi,%esi
    7a5d:	48 89 c7             	mov    %rax,%rdi
    7a60:	e8 cb ba ff ff       	call   3530 <strtoll@plt>
    7a65:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7a69:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7a70:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7a75:	0f 46 d0             	cmovbe %eax,%edx
    7a78:	eb d1                	jmp    7a4b <fwp_block+0x17b>
    7a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007a80 <fwp_caps173>:
    7a80:	f3 0f 1e fa          	endbr64
    7a84:	85 f6                	test   %esi,%esi
    7a86:	74 08                	je     7a90 <fwp_caps173+0x10>
    7a88:	c3                   	ret
    7a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a90:	48 8b 15 01 d1 01 00 	mov    0x1d101(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7a97:	48 89 f8             	mov    %rdi,%rax
    7a9a:	48 2b 05 cf d0 01 00 	sub    0x1d0cf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    7aa5:	48 39 d0             	cmp    %rdx,%rax
    7aa8:	73 de                	jae    7a88 <fwp_caps173+0x8>
    7aaa:	48 89 c2             	mov    %rax,%rdx
    7aad:	48 c1 ea 10          	shr    $0x10,%rdx
    7ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ab5:	48 8b 15 fc d0 01 00 	mov    0x1d0fc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7abc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ac0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7ac4:	48 85 c9             	test   %rcx,%rcx
    7ac7:	74 bf                	je     7a88 <fwp_caps173+0x8>
    7ac9:	0f b6 32             	movzbl (%rdx),%esi
    7acc:	40 80 fe 02          	cmp    $0x2,%sil
    7ad0:	74 2e                	je     7b00 <fwp_caps173+0x80>
    7ad2:	40 80 fe 01          	cmp    $0x1,%sil
    7ad6:	75 b0                	jne    7a88 <fwp_caps173+0x8>
    7ad8:	8b 72 18             	mov    0x18(%rdx),%esi
    7adb:	0f b7 c0             	movzwl %ax,%eax
    7ade:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ae1:	48 0f af c6          	imul   %rsi,%rax
    7ae5:	48 c1 e8 20          	shr    $0x20,%rax
    7ae9:	48 39 d0             	cmp    %rdx,%rax
    7aec:	73 9a                	jae    7a88 <fwp_caps173+0x8>
    7aee:	48 01 c1             	add    %rax,%rcx
    7af1:	80 39 01             	cmpb   $0x1,(%rcx)
    7af4:	75 92                	jne    7a88 <fwp_caps173+0x8>
    7af6:	e9 55 dc ff ff       	jmp    5750 <fwp_mem_free>
    7afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b00:	66 85 c0             	test   %ax,%ax
    7b03:	74 ec                	je     7af1 <fwp_caps173+0x71>
    7b05:	c3                   	ret
    7b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b0d:	00 00 00 

0000000000007b10 <fwp_args37>:
    7b10:	f3 0f 1e fa          	endbr64
    7b14:	85 d2                	test   %edx,%edx
    7b16:	74 04                	je     7b1c <fwp_args37+0xc>
    7b18:	85 f6                	test   %esi,%esi
    7b1a:	74 04                	je     7b20 <fwp_args37+0x10>
    7b1c:	c3                   	ret
    7b1d:	0f 1f 00             	nopl   (%rax)
    7b20:	48 8b 15 71 d0 01 00 	mov    0x1d071(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7b27:	48 8b 07             	mov    (%rdi),%rax
    7b2a:	48 2b 05 3f d0 01 00 	sub    0x1d03f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7b31:	48 c1 e2 10          	shl    $0x10,%rdx
    7b35:	48 39 d0             	cmp    %rdx,%rax
    7b38:	73 e2                	jae    7b1c <fwp_args37+0xc>
    7b3a:	48 89 c2             	mov    %rax,%rdx
    7b3d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b45:	48 8b 15 6c d0 01 00 	mov    0x1d06c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7b4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b50:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b54:	48 85 ff             	test   %rdi,%rdi
    7b57:	74 c3                	je     7b1c <fwp_args37+0xc>
    7b59:	0f b6 0a             	movzbl (%rdx),%ecx
    7b5c:	80 f9 02             	cmp    $0x2,%cl
    7b5f:	74 2f                	je     7b90 <fwp_args37+0x80>
    7b61:	80 f9 01             	cmp    $0x1,%cl
    7b64:	75 b6                	jne    7b1c <fwp_args37+0xc>
    7b66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b69:	0f b7 c0             	movzwl %ax,%eax
    7b6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b6f:	48 0f af c1          	imul   %rcx,%rax
    7b73:	48 c1 e8 20          	shr    $0x20,%rax
    7b77:	48 39 d0             	cmp    %rdx,%rax
    7b7a:	73 a0                	jae    7b1c <fwp_args37+0xc>
    7b7c:	48 01 c7             	add    %rax,%rdi
    7b7f:	0f b6 07             	movzbl (%rdi),%eax
    7b82:	84 c0                	test   %al,%al
    7b84:	74 96                	je     7b1c <fwp_args37+0xc>
    7b86:	3c fd                	cmp    $0xfd,%al
    7b88:	77 0c                	ja     7b96 <fwp_args37+0x86>
    7b8a:	83 c0 01             	add    $0x1,%eax
    7b8d:	88 07                	mov    %al,(%rdi)
    7b8f:	c3                   	ret
    7b90:	66 85 c0             	test   %ax,%ax
    7b93:	74 ea                	je     7b7f <fwp_args37+0x6f>
    7b95:	c3                   	ret
    7b96:	e9 55 d8 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    7b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007ba0 <fwp_caps37>:
    7ba0:	f3 0f 1e fa          	endbr64
    7ba4:	48 83 ec 18          	sub    $0x18,%rsp
    7ba8:	8b 57 04             	mov    0x4(%rdi),%edx
    7bab:	48 89 f8             	mov    %rdi,%rax
    7bae:	85 d2                	test   %edx,%edx
    7bb0:	0f 84 9a 00 00 00    	je     7c50 <fwp_caps37+0xb0>
    7bb6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7bba:	85 f6                	test   %esi,%esi
    7bbc:	0f 85 9e 00 00 00    	jne    7c60 <fwp_caps37+0xc0>
    7bc2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7bc7:	e8 54 f7 ff ff       	call   7320 <fwp_drop4>
    7bcc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bd1:	48 8b 0d c0 cf 01 00 	mov    0x1cfc0(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7bd8:	48 89 c2             	mov    %rax,%rdx
    7bdb:	48 2b 15 8e cf 01 00 	sub    0x1cf8e(%rip),%rdx        # 24b70 <fwp_heap+0x13b0>
    7be2:	48 c1 e1 10          	shl    $0x10,%rcx
    7be6:	48 39 ca             	cmp    %rcx,%rdx
    7be9:	73 6d                	jae    7c58 <fwp_caps37+0xb8>
    7beb:	48 89 d1             	mov    %rdx,%rcx
    7bee:	48 c1 e9 10          	shr    $0x10,%rcx
    7bf2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7bf6:	48 8b 0d bb cf 01 00 	mov    0x1cfbb(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    7bfd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7c01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c05:	48 85 f6             	test   %rsi,%rsi
    7c08:	74 4e                	je     7c58 <fwp_caps37+0xb8>
    7c0a:	0f b6 39             	movzbl (%rcx),%edi
    7c0d:	40 80 ff 02          	cmp    $0x2,%dil
    7c11:	0f 84 b9 00 00 00    	je     7cd0 <fwp_caps37+0x130>
    7c17:	40 80 ff 01          	cmp    $0x1,%dil
    7c1b:	75 3b                	jne    7c58 <fwp_caps37+0xb8>
    7c1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7c20:	0f b7 d2             	movzwl %dx,%edx
    7c23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c26:	48 0f af d7          	imul   %rdi,%rdx
    7c2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7c2e:	48 39 ca             	cmp    %rcx,%rdx
    7c31:	73 25                	jae    7c58 <fwp_caps37+0xb8>
    7c33:	48 01 d6             	add    %rdx,%rsi
    7c36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7c39:	75 1d                	jne    7c58 <fwp_caps37+0xb8>
    7c3b:	48 89 c7             	mov    %rax,%rdi
    7c3e:	48 83 c4 18          	add    $0x18,%rsp
    7c42:	e9 09 db ff ff       	jmp    5750 <fwp_mem_free>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	85 f6                	test   %esi,%esi
    7c52:	0f 84 79 ff ff ff    	je     7bd1 <fwp_caps37+0x31>
    7c58:	48 83 c4 18          	add    $0x18,%rsp
    7c5c:	c3                   	ret
    7c5d:	0f 1f 00             	nopl   (%rax)
    7c60:	48 8b 05 31 cf 01 00 	mov    0x1cf31(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    7c67:	48 2b 3d 02 cf 01 00 	sub    0x1cf02(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    7c6e:	48 c1 e0 10          	shl    $0x10,%rax
    7c72:	48 39 c7             	cmp    %rax,%rdi
    7c75:	73 e1                	jae    7c58 <fwp_caps37+0xb8>
    7c77:	48 89 f8             	mov    %rdi,%rax
    7c7a:	48 c1 e8 10          	shr    $0x10,%rax
    7c7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c82:	48 8b 05 2f cf 01 00 	mov    0x1cf2f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    7c89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c91:	48 85 c0             	test   %rax,%rax
    7c94:	74 c2                	je     7c58 <fwp_caps37+0xb8>
    7c96:	0f b6 0a             	movzbl (%rdx),%ecx
    7c99:	80 f9 02             	cmp    $0x2,%cl
    7c9c:	74 42                	je     7ce0 <fwp_caps37+0x140>
    7c9e:	80 f9 01             	cmp    $0x1,%cl
    7ca1:	75 b5                	jne    7c58 <fwp_caps37+0xb8>
    7ca3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ca6:	0f b7 ff             	movzwl %di,%edi
    7ca9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cac:	48 0f af f9          	imul   %rcx,%rdi
    7cb0:	48 c1 ef 20          	shr    $0x20,%rdi
    7cb4:	48 39 d7             	cmp    %rdx,%rdi
    7cb7:	73 9f                	jae    7c58 <fwp_caps37+0xb8>
    7cb9:	48 01 f8             	add    %rdi,%rax
    7cbc:	0f b6 10             	movzbl (%rax),%edx
    7cbf:	84 d2                	test   %dl,%dl
    7cc1:	74 95                	je     7c58 <fwp_caps37+0xb8>
    7cc3:	80 fa fd             	cmp    $0xfd,%dl
    7cc6:	77 23                	ja     7ceb <fwp_caps37+0x14b>
    7cc8:	83 c2 01             	add    $0x1,%edx
    7ccb:	88 10                	mov    %dl,(%rax)
    7ccd:	eb 89                	jmp    7c58 <fwp_caps37+0xb8>
    7ccf:	90                   	nop
    7cd0:	66 85 d2             	test   %dx,%dx
    7cd3:	0f 85 7f ff ff ff    	jne    7c58 <fwp_caps37+0xb8>
    7cd9:	e9 58 ff ff ff       	jmp    7c36 <fwp_caps37+0x96>
    7cde:	66 90                	xchg   %ax,%ax
    7ce0:	66 85 ff             	test   %di,%di
    7ce3:	0f 85 6f ff ff ff    	jne    7c58 <fwp_caps37+0xb8>
    7ce9:	eb d1                	jmp    7cbc <fwp_caps37+0x11c>
    7ceb:	48 89 c7             	mov    %rax,%rdi
    7cee:	48 83 c4 18          	add    $0x18,%rsp
    7cf2:	e9 f9 d6 ff ff       	jmp    53f0 <fwp_rc_wide_dup>
    7cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cfe:	00 00 

0000000000007d00 <fwp_drop0>:
    7d00:	f3 0f 1e fa          	endbr64
    7d04:	48 8b 15 8d ce 01 00 	mov    0x1ce8d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7d0b:	48 89 f8             	mov    %rdi,%rax
    7d0e:	48 2b 05 5b ce 01 00 	sub    0x1ce5b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7d15:	48 c1 e2 10          	shl    $0x10,%rdx
    7d19:	48 39 d0             	cmp    %rdx,%rax
    7d1c:	0f 83 36 01 00 00    	jae    7e58 <fwp_drop0+0x158>
    7d22:	48 83 ec 18          	sub    $0x18,%rsp
    7d26:	48 8d 35 93 ba 01 00 	lea    0x1ba93(%rip),%rsi        # 237c0 <fwp_heap>
    7d2d:	48 89 c2             	mov    %rax,%rdx
    7d30:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d37:	48 c1 ea 10          	shr    $0x10,%rdx
    7d3b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d3f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d43:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d47:	48 85 d2             	test   %rdx,%rdx
    7d4a:	74 42                	je     7d8e <fwp_drop0+0x8e>
    7d4c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d50:	41 80 f8 02          	cmp    $0x2,%r8b
    7d54:	74 42                	je     7d98 <fwp_drop0+0x98>
    7d56:	41 80 f8 01          	cmp    $0x1,%r8b
    7d5a:	75 32                	jne    7d8e <fwp_drop0+0x8e>
    7d5c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d60:	0f b7 c0             	movzwl %ax,%eax
    7d63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d66:	49 0f af c0          	imul   %r8,%rax
    7d6a:	48 c1 e8 20          	shr    $0x20,%rax
    7d6e:	48 39 c8             	cmp    %rcx,%rax
    7d71:	73 1b                	jae    7d8e <fwp_drop0+0x8e>
    7d73:	48 01 c2             	add    %rax,%rdx
    7d76:	0f b6 02             	movzbl (%rdx),%eax
    7d79:	84 c0                	test   %al,%al
    7d7b:	74 11                	je     7d8e <fwp_drop0+0x8e>
    7d7d:	3c 01                	cmp    $0x1,%al
    7d7f:	74 27                	je     7da8 <fwp_drop0+0xa8>
    7d81:	3c ff                	cmp    $0xff,%al
    7d83:	0f 84 e7 00 00 00    	je     7e70 <fwp_drop0+0x170>
    7d89:	83 e8 01             	sub    $0x1,%eax
    7d8c:	88 02                	mov    %al,(%rdx)
    7d8e:	48 83 c4 18          	add    $0x18,%rsp
    7d92:	c3                   	ret
    7d93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d98:	66 85 c0             	test   %ax,%ax
    7d9b:	74 d9                	je     7d76 <fwp_drop0+0x76>
    7d9d:	48 83 c4 18          	add    $0x18,%rsp
    7da1:	c3                   	ret
    7da2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7da8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7daf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7db6:	48 89 f8             	mov    %rdi,%rax
    7db9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7dbd:	48 29 c8             	sub    %rcx,%rax
    7dc0:	48 c1 e2 10          	shl    $0x10,%rdx
    7dc4:	48 39 d0             	cmp    %rdx,%rax
    7dc7:	73 71                	jae    7e3a <fwp_drop0+0x13a>
    7dc9:	49 89 c2             	mov    %rax,%r10
    7dcc:	49 c1 ea 10          	shr    $0x10,%r10
    7dd0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7dd4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7dd8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7ddc:	4d 85 d2             	test   %r10,%r10
    7ddf:	74 59                	je     7e3a <fwp_drop0+0x13a>
    7de1:	45 0f b6 19          	movzbl (%r9),%r11d
    7de5:	41 80 fb 02          	cmp    $0x2,%r11b
    7de9:	74 75                	je     7e60 <fwp_drop0+0x160>
    7deb:	41 80 fb 01          	cmp    $0x1,%r11b
    7def:	75 49                	jne    7e3a <fwp_drop0+0x13a>
    7df1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7df5:	0f b7 c0             	movzwl %ax,%eax
    7df8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dfc:	49 0f af c3          	imul   %r11,%rax
    7e00:	48 c1 e8 20          	shr    $0x20,%rax
    7e04:	4c 39 c8             	cmp    %r9,%rax
    7e07:	73 31                	jae    7e3a <fwp_drop0+0x13a>
    7e09:	49 01 c2             	add    %rax,%r10
    7e0c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e10:	75 28                	jne    7e3a <fwp_drop0+0x13a>
    7e12:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e17:	e8 34 d9 ff ff       	call   5750 <fwp_mem_free>
    7e1c:	48 8d 35 9d b9 01 00 	lea    0x1b99d(%rip),%rsi        # 237c0 <fwp_heap>
    7e23:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e28:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e2f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e36:	48 c1 e2 10          	shl    $0x10,%rdx
    7e3a:	4c 89 c0             	mov    %r8,%rax
    7e3d:	48 29 c8             	sub    %rcx,%rax
    7e40:	48 39 d0             	cmp    %rdx,%rax
    7e43:	0f 83 45 ff ff ff    	jae    7d8e <fwp_drop0+0x8e>
    7e49:	4c 89 c7             	mov    %r8,%rdi
    7e4c:	e9 dc fe ff ff       	jmp    7d2d <fwp_drop0+0x2d>
    7e51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e58:	c3                   	ret
    7e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e60:	66 85 c0             	test   %ax,%ax
    7e63:	75 d5                	jne    7e3a <fwp_drop0+0x13a>
    7e65:	eb a5                	jmp    7e0c <fwp_drop0+0x10c>
    7e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e6e:	00 00 
    7e70:	48 89 d0             	mov    %rdx,%rax
    7e73:	48 c1 e8 11          	shr    $0x11,%rax
    7e77:	48 31 d0             	xor    %rdx,%rax
    7e7a:	48 89 c1             	mov    %rax,%rcx
    7e7d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e81:	48 31 c8             	xor    %rcx,%rax
    7e84:	0f b6 c8             	movzbl %al,%ecx
    7e87:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e8e:	00 
    7e8f:	48 85 c0             	test   %rax,%rax
    7e92:	75 15                	jne    7ea9 <fwp_drop0+0x1a9>
    7e94:	eb 4e                	jmp    7ee4 <fwp_drop0+0x1e4>
    7e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e9d:	00 00 00 
    7ea0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ea4:	48 85 c0             	test   %rax,%rax
    7ea7:	74 3b                	je     7ee4 <fwp_drop0+0x1e4>
    7ea9:	48 89 c1             	mov    %rax,%rcx
    7eac:	48 39 10             	cmp    %rdx,(%rax)
    7eaf:	75 ef                	jne    7ea0 <fwp_drop0+0x1a0>
    7eb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7eb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7eb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7ebd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ec4:	0f 85 c4 fe ff ff    	jne    7d8e <fwp_drop0+0x8e>
    7eca:	48 89 d7             	mov    %rdx,%rdi
    7ecd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ed2:	e8 39 d6 ff ff       	call   5510 <fwp_rc_forget_slot>
    7ed7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7edc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7edf:	e9 aa fe ff ff       	jmp    7d8e <fwp_drop0+0x8e>
    7ee4:	48 8d 3d a5 79 00 00 	lea    0x79a5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7eeb:	e8 c0 c4 ff ff       	call   43b0 <fwp_trap>

0000000000007ef0 <fwp_drop1>:
    7ef0:	f3 0f 1e fa          	endbr64
    7ef4:	48 8b 15 9d cc 01 00 	mov    0x1cc9d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7efb:	48 89 f8             	mov    %rdi,%rax
    7efe:	48 2b 05 6b cc 01 00 	sub    0x1cc6b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7f05:	48 c1 e2 10          	shl    $0x10,%rdx
    7f09:	48 39 d0             	cmp    %rdx,%rax
    7f0c:	0f 83 36 01 00 00    	jae    8048 <fwp_drop1+0x158>
    7f12:	48 83 ec 18          	sub    $0x18,%rsp
    7f16:	48 8d 35 a3 b8 01 00 	lea    0x1b8a3(%rip),%rsi        # 237c0 <fwp_heap>
    7f1d:	48 89 c2             	mov    %rax,%rdx
    7f20:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7f27:	48 c1 ea 10          	shr    $0x10,%rdx
    7f2b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7f2f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7f33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7f37:	48 85 d2             	test   %rdx,%rdx
    7f3a:	74 42                	je     7f7e <fwp_drop1+0x8e>
    7f3c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7f40:	41 80 f8 02          	cmp    $0x2,%r8b
    7f44:	74 42                	je     7f88 <fwp_drop1+0x98>
    7f46:	41 80 f8 01          	cmp    $0x1,%r8b
    7f4a:	75 32                	jne    7f7e <fwp_drop1+0x8e>
    7f4c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7f50:	0f b7 c0             	movzwl %ax,%eax
    7f53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f56:	49 0f af c0          	imul   %r8,%rax
    7f5a:	48 c1 e8 20          	shr    $0x20,%rax
    7f5e:	48 39 c8             	cmp    %rcx,%rax
    7f61:	73 1b                	jae    7f7e <fwp_drop1+0x8e>
    7f63:	48 01 c2             	add    %rax,%rdx
    7f66:	0f b6 02             	movzbl (%rdx),%eax
    7f69:	84 c0                	test   %al,%al
    7f6b:	74 11                	je     7f7e <fwp_drop1+0x8e>
    7f6d:	3c 01                	cmp    $0x1,%al
    7f6f:	74 27                	je     7f98 <fwp_drop1+0xa8>
    7f71:	3c ff                	cmp    $0xff,%al
    7f73:	0f 84 e7 00 00 00    	je     8060 <fwp_drop1+0x170>
    7f79:	83 e8 01             	sub    $0x1,%eax
    7f7c:	88 02                	mov    %al,(%rdx)
    7f7e:	48 83 c4 18          	add    $0x18,%rsp
    7f82:	c3                   	ret
    7f83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f88:	66 85 c0             	test   %ax,%ax
    7f8b:	74 d9                	je     7f66 <fwp_drop1+0x76>
    7f8d:	48 83 c4 18          	add    $0x18,%rsp
    7f91:	c3                   	ret
    7f92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f98:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7f9f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7fa6:	48 89 f8             	mov    %rdi,%rax
    7fa9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7fad:	48 29 c8             	sub    %rcx,%rax
    7fb0:	48 c1 e2 10          	shl    $0x10,%rdx
    7fb4:	48 39 d0             	cmp    %rdx,%rax
    7fb7:	73 71                	jae    802a <fwp_drop1+0x13a>
    7fb9:	49 89 c2             	mov    %rax,%r10
    7fbc:	49 c1 ea 10          	shr    $0x10,%r10
    7fc0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7fc4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7fc8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7fcc:	4d 85 d2             	test   %r10,%r10
    7fcf:	74 59                	je     802a <fwp_drop1+0x13a>
    7fd1:	45 0f b6 19          	movzbl (%r9),%r11d
    7fd5:	41 80 fb 02          	cmp    $0x2,%r11b
    7fd9:	74 75                	je     8050 <fwp_drop1+0x160>
    7fdb:	41 80 fb 01          	cmp    $0x1,%r11b
    7fdf:	75 49                	jne    802a <fwp_drop1+0x13a>
    7fe1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7fe5:	0f b7 c0             	movzwl %ax,%eax
    7fe8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7fec:	49 0f af c3          	imul   %r11,%rax
    7ff0:	48 c1 e8 20          	shr    $0x20,%rax
    7ff4:	4c 39 c8             	cmp    %r9,%rax
    7ff7:	73 31                	jae    802a <fwp_drop1+0x13a>
    7ff9:	49 01 c2             	add    %rax,%r10
    7ffc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8000:	75 28                	jne    802a <fwp_drop1+0x13a>
    8002:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8007:	e8 44 d7 ff ff       	call   5750 <fwp_mem_free>
    800c:	48 8d 35 ad b7 01 00 	lea    0x1b7ad(%rip),%rsi        # 237c0 <fwp_heap>
    8013:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8018:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    801f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8026:	48 c1 e2 10          	shl    $0x10,%rdx
    802a:	4c 89 c0             	mov    %r8,%rax
    802d:	48 29 c8             	sub    %rcx,%rax
    8030:	48 39 d0             	cmp    %rdx,%rax
    8033:	0f 83 45 ff ff ff    	jae    7f7e <fwp_drop1+0x8e>
    8039:	4c 89 c7             	mov    %r8,%rdi
    803c:	e9 dc fe ff ff       	jmp    7f1d <fwp_drop1+0x2d>
    8041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8048:	c3                   	ret
    8049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8050:	66 85 c0             	test   %ax,%ax
    8053:	75 d5                	jne    802a <fwp_drop1+0x13a>
    8055:	eb a5                	jmp    7ffc <fwp_drop1+0x10c>
    8057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    805e:	00 00 
    8060:	48 89 d0             	mov    %rdx,%rax
    8063:	48 c1 e8 11          	shr    $0x11,%rax
    8067:	48 31 d0             	xor    %rdx,%rax
    806a:	48 89 c1             	mov    %rax,%rcx
    806d:	48 c1 e9 09          	shr    $0x9,%rcx
    8071:	48 31 c8             	xor    %rcx,%rax
    8074:	0f b6 c8             	movzbl %al,%ecx
    8077:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    807e:	00 
    807f:	48 85 c0             	test   %rax,%rax
    8082:	75 25                	jne    80a9 <fwp_drop1+0x1b9>
    8084:	eb 5e                	jmp    80e4 <fwp_drop1+0x1f4>
    8086:	0f 1f 40 00          	nopl   0x0(%rax)
    808a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8091:	00 00 00 00 
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    80a4:	48 85 c0             	test   %rax,%rax
    80a7:	74 3b                	je     80e4 <fwp_drop1+0x1f4>
    80a9:	48 89 c1             	mov    %rax,%rcx
    80ac:	48 39 10             	cmp    %rdx,(%rax)
    80af:	75 ef                	jne    80a0 <fwp_drop1+0x1b0>
    80b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    80b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    80bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    80c4:	0f 85 b4 fe ff ff    	jne    7f7e <fwp_drop1+0x8e>
    80ca:	48 89 d7             	mov    %rdx,%rdi
    80cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    80d2:	e8 39 d4 ff ff       	call   5510 <fwp_rc_forget_slot>
    80d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    80df:	e9 9a fe ff ff       	jmp    7f7e <fwp_drop1+0x8e>
    80e4:	48 8d 3d a5 77 00 00 	lea    0x77a5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    80eb:	e8 c0 c2 ff ff       	call   43b0 <fwp_trap>

00000000000080f0 <fwp_drop10>:
    80f0:	48 8b 0d a1 ca 01 00 	mov    0x1caa1(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    80f7:	48 89 f8             	mov    %rdi,%rax
    80fa:	48 2b 05 6f ca 01 00 	sub    0x1ca6f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8101:	48 c1 e1 10          	shl    $0x10,%rcx
    8105:	48 39 c8             	cmp    %rcx,%rax
    8108:	0f 83 c2 01 00 00    	jae    82d0 <fwp_drop10+0x1e0>
    810e:	48 83 ec 18          	sub    $0x18,%rsp
    8112:	48 89 fa             	mov    %rdi,%rdx
    8115:	48 8d 35 a4 b6 01 00 	lea    0x1b6a4(%rip),%rsi        # 237c0 <fwp_heap>
    811c:	48 89 c1             	mov    %rax,%rcx
    811f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8126:	48 c1 e9 10          	shr    $0x10,%rcx
    812a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    812e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8132:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8136:	48 85 c9             	test   %rcx,%rcx
    8139:	74 46                	je     8181 <fwp_drop10+0x91>
    813b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    813f:	41 80 f9 02          	cmp    $0x2,%r9b
    8143:	0f 84 d7 00 00 00    	je     8220 <fwp_drop10+0x130>
    8149:	41 80 f9 01          	cmp    $0x1,%r9b
    814d:	75 32                	jne    8181 <fwp_drop10+0x91>
    814f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    8153:	0f b7 c0             	movzwl %ax,%eax
    8156:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    8159:	49 0f af c1          	imul   %r9,%rax
    815d:	48 c1 e8 20          	shr    $0x20,%rax
    8161:	48 39 f8             	cmp    %rdi,%rax
    8164:	73 1b                	jae    8181 <fwp_drop10+0x91>
    8166:	48 01 c1             	add    %rax,%rcx
    8169:	0f b6 01             	movzbl (%rcx),%eax
    816c:	84 c0                	test   %al,%al
    816e:	74 11                	je     8181 <fwp_drop10+0x91>
    8170:	3c 01                	cmp    $0x1,%al
    8172:	74 1c                	je     8190 <fwp_drop10+0xa0>
    8174:	3c ff                	cmp    $0xff,%al
    8176:	0f 84 5c 01 00 00    	je     82d8 <fwp_drop10+0x1e8>
    817c:	83 e8 01             	sub    $0x1,%eax
    817f:	88 01                	mov    %al,(%rcx)
    8181:	48 83 c4 18          	add    $0x18,%rsp
    8185:	c3                   	ret
    8186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    818d:	00 00 00 
    8190:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8197:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    819e:	48 89 d0             	mov    %rdx,%rax
    81a1:	49 89 d1             	mov    %rdx,%r9
    81a4:	48 c1 e1 10          	shl    $0x10,%rcx
    81a8:	48 29 f8             	sub    %rdi,%rax
    81ab:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    81af:	78 7f                	js     8230 <fwp_drop10+0x140>
    81b1:	48 39 c8             	cmp    %rcx,%rax
    81b4:	73 cb                	jae    8181 <fwp_drop10+0x91>
    81b6:	48 89 c1             	mov    %rax,%rcx
    81b9:	48 c1 e9 10          	shr    $0x10,%rcx
    81bd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    81c1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    81c5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    81c9:	48 85 f6             	test   %rsi,%rsi
    81cc:	74 b3                	je     8181 <fwp_drop10+0x91>
    81ce:	0f b6 39             	movzbl (%rcx),%edi
    81d1:	40 80 ff 02          	cmp    $0x2,%dil
    81d5:	74 39                	je     8210 <fwp_drop10+0x120>
    81d7:	40 80 ff 01          	cmp    $0x1,%dil
    81db:	75 a4                	jne    8181 <fwp_drop10+0x91>
    81dd:	8b 79 18             	mov    0x18(%rcx),%edi
    81e0:	0f b7 c0             	movzwl %ax,%eax
    81e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81e6:	48 0f af c7          	imul   %rdi,%rax
    81ea:	48 c1 e8 20          	shr    $0x20,%rax
    81ee:	48 39 c8             	cmp    %rcx,%rax
    81f1:	73 8e                	jae    8181 <fwp_drop10+0x91>
    81f3:	48 01 c6             	add    %rax,%rsi
    81f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    81f9:	75 86                	jne    8181 <fwp_drop10+0x91>
    81fb:	48 89 d7             	mov    %rdx,%rdi
    81fe:	48 83 c4 18          	add    $0x18,%rsp
    8202:	e9 49 d5 ff ff       	jmp    5750 <fwp_mem_free>
    8207:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    820e:	00 00 
    8210:	66 85 c0             	test   %ax,%ax
    8213:	74 e1                	je     81f6 <fwp_drop10+0x106>
    8215:	48 83 c4 18          	add    $0x18,%rsp
    8219:	c3                   	ret
    821a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8220:	66 85 c0             	test   %ax,%ax
    8223:	0f 84 40 ff ff ff    	je     8169 <fwp_drop10+0x79>
    8229:	48 83 c4 18          	add    $0x18,%rsp
    822d:	c3                   	ret
    822e:	66 90                	xchg   %ax,%ax
    8230:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8234:	48 39 c8             	cmp    %rcx,%rax
    8237:	73 74                	jae    82ad <fwp_drop10+0x1bd>
    8239:	49 89 c2             	mov    %rax,%r10
    823c:	49 c1 ea 10          	shr    $0x10,%r10
    8240:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8244:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8248:	4d 8b 50 20          	mov    0x20(%r8),%r10
    824c:	4d 85 d2             	test   %r10,%r10
    824f:	74 5c                	je     82ad <fwp_drop10+0x1bd>
    8251:	45 0f b6 18          	movzbl (%r8),%r11d
    8255:	41 80 fb 02          	cmp    $0x2,%r11b
    8259:	74 6d                	je     82c8 <fwp_drop10+0x1d8>
    825b:	41 80 fb 01          	cmp    $0x1,%r11b
    825f:	75 4c                	jne    82ad <fwp_drop10+0x1bd>
    8261:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8265:	0f b7 c0             	movzwl %ax,%eax
    8268:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    826c:	49 0f af c3          	imul   %r11,%rax
    8270:	48 c1 e8 20          	shr    $0x20,%rax
    8274:	4c 39 c0             	cmp    %r8,%rax
    8277:	73 34                	jae    82ad <fwp_drop10+0x1bd>
    8279:	49 01 c2             	add    %rax,%r10
    827c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8280:	75 2b                	jne    82ad <fwp_drop10+0x1bd>
    8282:	4c 89 cf             	mov    %r9,%rdi
    8285:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    828a:	e8 c1 d4 ff ff       	call   5750 <fwp_mem_free>
    828f:	48 8d 35 2a b5 01 00 	lea    0x1b52a(%rip),%rsi        # 237c0 <fwp_heap>
    8296:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    829b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    82a2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    82a9:	48 c1 e1 10          	shl    $0x10,%rcx
    82ad:	48 89 d0             	mov    %rdx,%rax
    82b0:	48 29 f8             	sub    %rdi,%rax
    82b3:	48 39 c8             	cmp    %rcx,%rax
    82b6:	0f 82 60 fe ff ff    	jb     811c <fwp_drop10+0x2c>
    82bc:	e9 c0 fe ff ff       	jmp    8181 <fwp_drop10+0x91>
    82c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82c8:	66 85 c0             	test   %ax,%ax
    82cb:	75 e0                	jne    82ad <fwp_drop10+0x1bd>
    82cd:	eb ad                	jmp    827c <fwp_drop10+0x18c>
    82cf:	90                   	nop
    82d0:	c3                   	ret
    82d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82d8:	48 89 c8             	mov    %rcx,%rax
    82db:	48 c1 e8 11          	shr    $0x11,%rax
    82df:	48 31 c8             	xor    %rcx,%rax
    82e2:	48 89 c2             	mov    %rax,%rdx
    82e5:	48 c1 ea 09          	shr    $0x9,%rdx
    82e9:	48 31 d0             	xor    %rdx,%rax
    82ec:	0f b6 d0             	movzbl %al,%edx
    82ef:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    82f6:	00 
    82f7:	48 85 c0             	test   %rax,%rax
    82fa:	75 0d                	jne    8309 <fwp_drop10+0x219>
    82fc:	eb 46                	jmp    8344 <fwp_drop10+0x254>
    82fe:	66 90                	xchg   %ax,%ax
    8300:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8304:	48 85 c0             	test   %rax,%rax
    8307:	74 3b                	je     8344 <fwp_drop10+0x254>
    8309:	48 89 c2             	mov    %rax,%rdx
    830c:	48 39 08             	cmp    %rcx,(%rax)
    830f:	75 ef                	jne    8300 <fwp_drop10+0x210>
    8311:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8315:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8319:	48 89 50 08          	mov    %rdx,0x8(%rax)
    831d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8324:	0f 85 57 fe ff ff    	jne    8181 <fwp_drop10+0x91>
    832a:	48 89 cf             	mov    %rcx,%rdi
    832d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8332:	e8 d9 d1 ff ff       	call   5510 <fwp_rc_forget_slot>
    8337:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    833c:	c6 01 fe             	movb   $0xfe,(%rcx)
    833f:	e9 3d fe ff ff       	jmp    8181 <fwp_drop10+0x91>
    8344:	48 8d 3d 45 75 00 00 	lea    0x7545(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    834b:	e8 60 c0 ff ff       	call   43b0 <fwp_trap>

0000000000008350 <f37>:
    8350:	41 57                	push   %r15
    8352:	41 56                	push   %r14
    8354:	41 55                	push   %r13
    8356:	41 54                	push   %r12
    8358:	55                   	push   %rbp
    8359:	53                   	push   %rbx
    835a:	48 83 ec 48          	sub    $0x48,%rsp
    835e:	48 8b 15 33 c8 01 00 	mov    0x1c833(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    8365:	48 89 3c 24          	mov    %rdi,(%rsp)
    8369:	48 c1 e2 10          	shl    $0x10,%rdx
    836d:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8374:	00 00 
    8376:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    837b:	48 8b 0d ee c7 01 00 	mov    0x1c7ee(%rip),%rcx        # 24b70 <fwp_heap+0x13b0>
    8382:	48 85 ff             	test   %rdi,%rdi
    8385:	0f 84 e3 02 00 00    	je     866e <f37+0x31e>
    838b:	48 8b 04 24          	mov    (%rsp),%rax
    838f:	48 8b 58 10          	mov    0x10(%rax),%rbx
    8393:	48 89 d8             	mov    %rbx,%rax
    8396:	48 29 c8             	sub    %rcx,%rax
    8399:	48 39 d0             	cmp    %rdx,%rax
    839c:	0f 83 8e 03 00 00    	jae    8730 <f37+0x3e0>
    83a2:	48 89 c2             	mov    %rax,%rdx
    83a5:	48 c1 ea 10          	shr    $0x10,%rdx
    83a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ad:	48 8b 15 04 c8 01 00 	mov    0x1c804(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    83b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83b8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    83bc:	48 85 ff             	test   %rdi,%rdi
    83bf:	0f 84 6b 03 00 00    	je     8730 <f37+0x3e0>
    83c5:	0f b6 0a             	movzbl (%rdx),%ecx
    83c8:	80 f9 02             	cmp    $0x2,%cl
    83cb:	0f 84 77 02 00 00    	je     8648 <f37+0x2f8>
    83d1:	80 f9 01             	cmp    $0x1,%cl
    83d4:	75 24                	jne    83fa <f37+0xaa>
    83d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83d9:	0f b7 c0             	movzwl %ax,%eax
    83dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83df:	48 0f af c1          	imul   %rcx,%rax
    83e3:	48 c1 e8 20          	shr    $0x20,%rax
    83e7:	48 39 d0             	cmp    %rdx,%rax
    83ea:	73 0e                	jae    83fa <f37+0xaa>
    83ec:	48 01 c7             	add    %rax,%rdi
    83ef:	0f b6 07             	movzbl (%rdi),%eax
    83f2:	84 c0                	test   %al,%al
    83f4:	0f 85 e6 02 00 00    	jne    86e0 <f37+0x390>
    83fa:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    83ff:	48 8b 04 24          	mov    (%rsp),%rax
    8403:	48 8b 58 10          	mov    0x10(%rax),%rbx
    8407:	ba 01 00 00 00       	mov    $0x1,%edx
    840c:	48 85 db             	test   %rbx,%rbx
    840f:	74 1c                	je     842d <f37+0xdd>
    8411:	0f 1f 40 00          	nopl   0x0(%rax)
    8415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    841c:	00 00 00 00 
    8420:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8424:	48 83 c2 01          	add    $0x1,%rdx
    8428:	48 85 db             	test   %rbx,%rbx
    842b:	75 f3                	jne    8420 <f37+0xd0>
    842d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8432:	48 85 c0             	test   %rax,%rax
    8435:	0f 84 25 03 00 00    	je     8760 <f37+0x410>
    843b:	31 db                	xor    %ebx,%ebx
    843d:	0f 1f 00             	nopl   (%rax)
    8440:	48 8b 40 10          	mov    0x10(%rax),%rax
    8444:	48 83 c3 01          	add    $0x1,%rbx
    8448:	48 85 c0             	test   %rax,%rax
    844b:	75 f3                	jne    8440 <f37+0xf0>
    844d:	48 39 d3             	cmp    %rdx,%rbx
    8450:	48 0f 47 da          	cmova  %rdx,%rbx
    8454:	48 89 d8             	mov    %rbx,%rax
    8457:	48 c1 e8 3c          	shr    $0x3c,%rax
    845b:	0f 85 9f 03 00 00    	jne    8800 <f37+0x4b0>
    8461:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8465:	be 02 00 00 00       	mov    $0x2,%esi
    846a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8471:	00 
    8472:	e8 d9 d7 ff ff       	call   5c50 <fwp_heap_alloc>
    8477:	48 89 28             	mov    %rbp,(%rax)
    847a:	48 8b 15 17 c7 01 00 	mov    0x1c717(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    8481:	49 89 c5             	mov    %rax,%r13
    8484:	48 2b 05 e5 c6 01 00 	sub    0x1c6e5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    848b:	48 c1 e2 10          	shl    $0x10,%rdx
    848f:	48 39 d0             	cmp    %rdx,%rax
    8492:	73 57                	jae    84eb <f37+0x19b>
    8494:	48 89 c2             	mov    %rax,%rdx
    8497:	48 c1 ea 10          	shr    $0x10,%rdx
    849b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    849f:	48 8b 15 12 c7 01 00 	mov    0x1c712(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    84a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84ae:	48 85 ed             	test   %rbp,%rbp
    84b1:	74 38                	je     84eb <f37+0x19b>
    84b3:	0f b6 0a             	movzbl (%rdx),%ecx
    84b6:	80 f9 02             	cmp    $0x2,%cl
    84b9:	0f 84 61 02 00 00    	je     8720 <f37+0x3d0>
    84bf:	80 f9 01             	cmp    $0x1,%cl
    84c2:	75 27                	jne    84eb <f37+0x19b>
    84c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84c7:	0f b7 c0             	movzwl %ax,%eax
    84ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84cd:	48 0f af c1          	imul   %rcx,%rax
    84d1:	48 c1 e8 20          	shr    $0x20,%rax
    84d5:	48 39 d0             	cmp    %rdx,%rax
    84d8:	73 11                	jae    84eb <f37+0x19b>
    84da:	48 01 c5             	add    %rax,%rbp
    84dd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    84e1:	0f 84 e5 02 00 00    	je     87cc <f37+0x47c>
    84e7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    84eb:	48 85 db             	test   %rbx,%rbx
    84ee:	74 74                	je     8564 <f37+0x214>
    84f0:	48 c1 e3 04          	shl    $0x4,%rbx
    84f4:	4c 8b 34 24          	mov    (%rsp),%r14
    84f8:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    84fd:	4c 89 ed             	mov    %r13,%rbp
    8500:	4c 01 eb             	add    %r13,%rbx
    8503:	66 90                	xchg   %ax,%ax
    8505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    850c:	00 00 00 00 
    8510:	49 8b 46 08          	mov    0x8(%r14),%rax
    8514:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8518:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    851d:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    8524:	ff ff 
    8526:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    852d:	00 00 
    852f:	48 83 c5 10          	add    $0x10,%rbp
    8533:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8538:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    853c:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8540:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    8545:	e8 26 dd ff ff       	call   6270 <w120>
    854a:	66 48 0f 6e d0       	movq   %rax,%xmm2
    854f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8553:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8557:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    855b:	4d 8b 76 10          	mov    0x10(%r14),%r14
    855f:	48 39 dd             	cmp    %rbx,%rbp
    8562:	75 ac                	jne    8510 <f37+0x1c0>
    8564:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8569:	e8 b2 ed ff ff       	call   7320 <fwp_drop4>
    856e:	48 8b 3c 24          	mov    (%rsp),%rdi
    8572:	e8 a9 ed ff ff       	call   7320 <fwp_drop4>
    8577:	4c 89 ef             	mov    %r13,%rdi
    857a:	e8 41 e4 ff ff       	call   69c0 <w176.constprop.0>
    857f:	4c 89 ef             	mov    %r13,%rdi
    8582:	48 89 c3             	mov    %rax,%rbx
    8585:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    858a:	e8 61 fb ff ff       	call   80f0 <fwp_drop10>
    858f:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    8594:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8599:	31 ff                	xor    %edi,%edi
    859b:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    85a0:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    85a4:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    85a9:	e8 c2 d7 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    85ae:	48 8b 15 e3 c5 01 00 	mov    0x1c5e3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    85b5:	48 89 c5             	mov    %rax,%rbp
    85b8:	48 2b 05 b1 c5 01 00 	sub    0x1c5b1(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    85bf:	48 c1 e2 10          	shl    $0x10,%rdx
    85c3:	48 39 d0             	cmp    %rdx,%rax
    85c6:	73 55                	jae    861d <f37+0x2cd>
    85c8:	48 89 c2             	mov    %rax,%rdx
    85cb:	48 c1 ea 10          	shr    $0x10,%rdx
    85cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85d3:	48 8b 15 de c5 01 00 	mov    0x1c5de(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    85da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85de:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    85e2:	48 85 db             	test   %rbx,%rbx
    85e5:	74 36                	je     861d <f37+0x2cd>
    85e7:	0f b6 0a             	movzbl (%rdx),%ecx
    85ea:	80 f9 02             	cmp    $0x2,%cl
    85ed:	0f 84 15 01 00 00    	je     8708 <f37+0x3b8>
    85f3:	80 f9 01             	cmp    $0x1,%cl
    85f6:	75 25                	jne    861d <f37+0x2cd>
    85f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85fb:	0f b7 c0             	movzwl %ax,%eax
    85fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8601:	48 0f af c1          	imul   %rcx,%rax
    8605:	48 c1 e8 20          	shr    $0x20,%rax
    8609:	48 39 d0             	cmp    %rdx,%rax
    860c:	73 0f                	jae    861d <f37+0x2cd>
    860e:	48 01 c3             	add    %rax,%rbx
    8611:	80 3b ff             	cmpb   $0xff,(%rbx)
    8614:	0f 84 a5 01 00 00    	je     87bf <f37+0x46f>
    861a:	c6 03 01             	movb   $0x1,(%rbx)
    861d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8622:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8629:	00 00 
    862b:	0f 85 ca 01 00 00    	jne    87fb <f37+0x4ab>
    8631:	48 83 c4 48          	add    $0x48,%rsp
    8635:	48 89 e8             	mov    %rbp,%rax
    8638:	5b                   	pop    %rbx
    8639:	5d                   	pop    %rbp
    863a:	41 5c                	pop    %r12
    863c:	41 5d                	pop    %r13
    863e:	41 5e                	pop    %r14
    8640:	41 5f                	pop    %r15
    8642:	c3                   	ret
    8643:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8648:	66 85 c0             	test   %ax,%ax
    864b:	0f 85 a9 fd ff ff    	jne    83fa <f37+0xaa>
    8651:	0f b6 07             	movzbl (%rdi),%eax
    8654:	84 c0                	test   %al,%al
    8656:	0f 84 9e fd ff ff    	je     83fa <f37+0xaa>
    865c:	3c fd                	cmp    $0xfd,%al
    865e:	0f 87 8d 01 00 00    	ja     87f1 <f37+0x4a1>
    8664:	83 c0 01             	add    $0x1,%eax
    8667:	88 07                	mov    %al,(%rdi)
    8669:	e9 8c fd ff ff       	jmp    83fa <f37+0xaa>
    866e:	48 f7 d9             	neg    %rcx
    8671:	48 39 d1             	cmp    %rdx,%rcx
    8674:	0f 83 e6 00 00 00    	jae    8760 <f37+0x410>
    867a:	48 89 c8             	mov    %rcx,%rax
    867d:	48 c1 e8 10          	shr    $0x10,%rax
    8681:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8685:	48 8b 05 2c c5 01 00 	mov    0x1c52c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    868c:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8690:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8694:	48 85 ff             	test   %rdi,%rdi
    8697:	0f 84 c3 00 00 00    	je     8760 <f37+0x410>
    869d:	0f b6 02             	movzbl (%rdx),%eax
    86a0:	3c 02                	cmp    $0x2,%al
    86a2:	0f 84 92 00 00 00    	je     873a <f37+0x3ea>
    86a8:	3c 01                	cmp    $0x1,%al
    86aa:	0f 85 b0 00 00 00    	jne    8760 <f37+0x410>
    86b0:	0f b7 c1             	movzwl %cx,%eax
    86b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86b9:	48 0f af c1          	imul   %rcx,%rax
    86bd:	48 c1 e8 20          	shr    $0x20,%rax
    86c1:	48 39 d0             	cmp    %rdx,%rax
    86c4:	0f 83 96 00 00 00    	jae    8760 <f37+0x410>
    86ca:	48 01 c7             	add    %rax,%rdi
    86cd:	0f b6 07             	movzbl (%rdi),%eax
    86d0:	84 c0                	test   %al,%al
    86d2:	0f 84 88 00 00 00    	je     8760 <f37+0x410>
    86d8:	31 db                	xor    %ebx,%ebx
    86da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86e0:	3c fd                	cmp    $0xfd,%al
    86e2:	0f 87 f1 00 00 00    	ja     87d9 <f37+0x489>
    86e8:	83 c0 01             	add    $0x1,%eax
    86eb:	88 07                	mov    %al,(%rdi)
    86ed:	31 d2                	xor    %edx,%edx
    86ef:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    86f4:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    86f9:	0f 85 00 fd ff ff    	jne    83ff <f37+0xaf>
    86ff:	e9 29 fd ff ff       	jmp    842d <f37+0xdd>
    8704:	0f 1f 40 00          	nopl   0x0(%rax)
    8708:	66 85 c0             	test   %ax,%ax
    870b:	0f 85 0c ff ff ff    	jne    861d <f37+0x2cd>
    8711:	e9 fb fe ff ff       	jmp    8611 <f37+0x2c1>
    8716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    871d:	00 00 00 
    8720:	66 85 c0             	test   %ax,%ax
    8723:	0f 85 c2 fd ff ff    	jne    84eb <f37+0x19b>
    8729:	e9 af fd ff ff       	jmp    84dd <f37+0x18d>
    872e:	66 90                	xchg   %ax,%ax
    8730:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8735:	e9 cd fc ff ff       	jmp    8407 <f37+0xb7>
    873a:	66 85 c9             	test   %cx,%cx
    873d:	75 21                	jne    8760 <f37+0x410>
    873f:	0f b6 07             	movzbl (%rdi),%eax
    8742:	84 c0                	test   %al,%al
    8744:	74 1a                	je     8760 <f37+0x410>
    8746:	3c fd                	cmp    $0xfd,%al
    8748:	0f 87 be 00 00 00    	ja     880c <f37+0x4bc>
    874e:	83 c0 01             	add    $0x1,%eax
    8751:	88 07                	mov    %al,(%rdi)
    8753:	66 90                	xchg   %ax,%ax
    8755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    875c:	00 00 00 00 
    8760:	be 02 00 00 00       	mov    $0x2,%esi
    8765:	bf 08 00 00 00       	mov    $0x8,%edi
    876a:	e8 e1 d4 ff ff       	call   5c50 <fwp_heap_alloc>
    876f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8776:	48 8b 15 1b c4 01 00 	mov    0x1c41b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    877d:	49 89 c5             	mov    %rax,%r13
    8780:	48 2b 05 e9 c3 01 00 	sub    0x1c3e9(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8787:	48 c1 e2 10          	shl    $0x10,%rdx
    878b:	48 39 d0             	cmp    %rdx,%rax
    878e:	73 53                	jae    87e3 <f37+0x493>
    8790:	48 89 c2             	mov    %rax,%rdx
    8793:	48 c1 ea 10          	shr    $0x10,%rdx
    8797:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    879b:	48 8b 15 16 c4 01 00 	mov    0x1c416(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    87a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87a6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    87aa:	48 85 ed             	test   %rbp,%rbp
    87ad:	74 34                	je     87e3 <f37+0x493>
    87af:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    87b6:	00 00 
    87b8:	31 db                	xor    %ebx,%ebx
    87ba:	e9 f4 fc ff ff       	jmp    84b3 <f37+0x163>
    87bf:	48 89 df             	mov    %rbx,%rdi
    87c2:	e8 49 cd ff ff       	call   5510 <fwp_rc_forget_slot>
    87c7:	e9 4e fe ff ff       	jmp    861a <f37+0x2ca>
    87cc:	48 89 ef             	mov    %rbp,%rdi
    87cf:	e8 3c cd ff ff       	call   5510 <fwp_rc_forget_slot>
    87d4:	e9 0e fd ff ff       	jmp    84e7 <f37+0x197>
    87d9:	e8 12 cc ff ff       	call   53f0 <fwp_rc_wide_dup>
    87de:	e9 0a ff ff ff       	jmp    86ed <f37+0x39d>
    87e3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    87ea:	00 00 
    87ec:	e9 73 fd ff ff       	jmp    8564 <f37+0x214>
    87f1:	e8 fa cb ff ff       	call   53f0 <fwp_rc_wide_dup>
    87f6:	e9 ff fb ff ff       	jmp    83fa <f37+0xaa>
    87fb:	e8 40 ac ff ff       	call   3440 <__stack_chk_fail@plt>
    8800:	48 8d 3d 89 69 00 00 	lea    0x6989(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    8807:	e8 a4 bb ff ff       	call   43b0 <fwp_trap>
    880c:	e8 df cb ff ff       	call   53f0 <fwp_rc_wide_dup>
    8811:	e9 4a ff ff ff       	jmp    8760 <f37+0x410>
    8816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    881d:	00 00 00 

0000000000008820 <fwp_owned_entry37>:
    8820:	f3 0f 1e fa          	endbr64
    8824:	48 8b 3f             	mov    (%rdi),%rdi
    8827:	e9 24 fb ff ff       	jmp    8350 <f37>
    882c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008830 <e37>:
    8830:	f3 0f 1e fa          	endbr64
    8834:	53                   	push   %rbx
    8835:	48 8b 1f             	mov    (%rdi),%rbx
    8838:	48 89 df             	mov    %rbx,%rdi
    883b:	e8 30 e2 ff ff       	call   6a70 <fwp_rc_share>
    8840:	48 89 df             	mov    %rbx,%rdi
    8843:	e8 08 fb ff ff       	call   8350 <f37>
    8848:	48 89 c3             	mov    %rax,%rbx
    884b:	48 89 c7             	mov    %rax,%rdi
    884e:	e8 1d e2 ff ff       	call   6a70 <fwp_rc_share>
    8853:	48 89 d8             	mov    %rbx,%rax
    8856:	5b                   	pop    %rbx
    8857:	c3                   	ret
    8858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    885f:	00 

0000000000008860 <fwp_write>:
    8860:	41 57                	push   %r15
    8862:	41 56                	push   %r14
    8864:	41 55                	push   %r13
    8866:	41 54                	push   %r12
    8868:	55                   	push   %rbp
    8869:	53                   	push   %rbx
    886a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8871:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8878:	00 00 
    887a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8881:	00 
    8882:	49 89 d4             	mov    %rdx,%r12
    8885:	8b 12                	mov    (%rdx),%edx
    8887:	83 fa 19             	cmp    $0x19,%edx
    888a:	77 6a                	ja     88f6 <fwp_write+0x96>
    888c:	48 89 f5             	mov    %rsi,%rbp
    888f:	89 d0                	mov    %edx,%eax
    8891:	89 ce                	mov    %ecx,%esi
    8893:	48 89 fb             	mov    %rdi,%rbx
    8896:	48 8d 0d 63 72 00 00 	lea    0x7263(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    889d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    88a1:	48 01 c8             	add    %rcx,%rax
    88a4:	3e ff e0             	notrack jmp *%rax
    88a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88ae:	00 00 
    88b0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    88b4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    88b8:	48 89 ca             	mov    %rcx,%rdx
    88bb:	48 85 c9             	test   %rcx,%rcx
    88be:	0f 88 9c 0c 00 00    	js     9560 <fwp_write+0xd00>
    88c4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    88cb:	00 
    88cc:	48 89 c6             	mov    %rax,%rsi
    88cf:	4c 89 e7             	mov    %r12,%rdi
    88d2:	e8 29 b1 ff ff       	call   3a00 <fwp_fmt_u128>
    88d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88de:	00 00 
    88e0:	4c 89 e7             	mov    %r12,%rdi
    88e3:	e8 48 ab ff ff       	call   3430 <strlen@plt>
    88e8:	4c 89 e6             	mov    %r12,%rsi
    88eb:	48 89 df             	mov    %rbx,%rdi
    88ee:	48 89 c2             	mov    %rax,%rdx
    88f1:	e8 da b8 ff ff       	call   41d0 <buf_put>
    88f6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88fd:	00 
    88fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8905:	00 00 
    8907:	0f 85 28 04 00 00    	jne    8d35 <fwp_write+0x4d5>
    890d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8914:	5b                   	pop    %rbx
    8915:	5d                   	pop    %rbp
    8916:	41 5c                	pop    %r12
    8918:	41 5d                	pop    %r13
    891a:	41 5e                	pop    %r14
    891c:	41 5f                	pop    %r15
    891e:	c3                   	ret
    891f:	90                   	nop
    8920:	49 89 e9             	mov    %rbp,%r9
    8923:	4c 8d 05 4b 67 00 00 	lea    0x674b(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    892a:	b9 00 02 00 00       	mov    $0x200,%ecx
    892f:	ba 02 00 00 00       	mov    $0x2,%edx
    8934:	be 00 02 00 00       	mov    $0x200,%esi
    8939:	31 c0                	xor    %eax,%eax
    893b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8942:	00 
    8943:	e8 48 aa ff ff       	call   3390 <__snprintf_chk@plt>
    8948:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    894f:	00 
    8950:	e8 db aa ff ff       	call   3430 <strlen@plt>
    8955:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    895c:	00 
    895d:	48 89 df             	mov    %rbx,%rdi
    8960:	48 89 c2             	mov    %rax,%rdx
    8963:	e8 68 b8 ff ff       	call   41d0 <buf_put>
    8968:	eb 8c                	jmp    88f6 <fwp_write+0x96>
    896a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8970:	49 89 e9             	mov    %rbp,%r9
    8973:	4c 8d 05 3b 68 00 00 	lea    0x683b(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    897a:	eb ae                	jmp    892a <fwp_write+0xca>
    897c:	0f 1f 40 00          	nopl   0x0(%rax)
    8980:	83 fa 13             	cmp    $0x13,%edx
    8983:	48 8d 05 21 68 00 00 	lea    0x6821(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    898a:	48 8d 35 1f 68 00 00 	lea    0x681f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8991:	ba 04 00 00 00       	mov    $0x4,%edx
    8996:	48 0f 44 f0          	cmove  %rax,%rsi
    899a:	45 31 ed             	xor    %r13d,%r13d
    899d:	e8 2e b8 ff ff       	call   41d0 <buf_put>
    89a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    89a7:	0f 84 a3 08 00 00    	je     9250 <fwp_write+0x9f0>
    89ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    89b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    89b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89bc:	48 89 df             	mov    %rbx,%rdi
    89bf:	49 0f 44 c5          	cmove  %r13,%rax
    89c3:	31 c9                	xor    %ecx,%ecx
    89c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    89ca:	e8 91 fe ff ff       	call   8860 <fwp_write>
    89cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    89d4:	0f 84 6e 09 00 00    	je     9348 <fwp_write+0xae8>
    89da:	49 83 c5 01          	add    $0x1,%r13
    89de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    89e2:	0f 83 68 08 00 00    	jae    9250 <fwp_write+0x9f0>
    89e8:	ba 02 00 00 00       	mov    $0x2,%edx
    89ed:	48 8d 35 01 68 00 00 	lea    0x6801(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    89f4:	48 89 df             	mov    %rbx,%rdi
    89f7:	e8 d4 b7 ff ff       	call   41d0 <buf_put>
    89fc:	eb af                	jmp    89ad <fwp_write+0x14d>
    89fe:	66 90                	xchg   %ax,%ax
    8a00:	ba 06 00 00 00       	mov    $0x6,%edx
    8a05:	48 8d 35 c2 67 00 00 	lea    0x67c2(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    8a0c:	48 83 c5 10          	add    $0x10,%rbp
    8a10:	e8 bb b7 ff ff       	call   41d0 <buf_put>
    8a15:	48 89 ef             	mov    %rbp,%rdi
    8a18:	e8 13 aa ff ff       	call   3430 <strlen@plt>
    8a1d:	48 89 ee             	mov    %rbp,%rsi
    8a20:	48 89 df             	mov    %rbx,%rdi
    8a23:	48 89 c2             	mov    %rax,%rdx
    8a26:	e8 a5 b7 ff ff       	call   41d0 <buf_put>
    8a2b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a30:	ba 01 00 00 00       	mov    $0x1,%edx
    8a35:	48 89 df             	mov    %rbx,%rdi
    8a38:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a3d:	e8 8e b7 ff ff       	call   41d0 <buf_put>
    8a42:	e9 af fe ff ff       	jmp    88f6 <fwp_write+0x96>
    8a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a4e:	00 00 
    8a50:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a57:	00 
    8a58:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a5f:	00 00 
    8a61:	0f 85 ce 02 00 00    	jne    8d35 <fwp_write+0x4d5>
    8a67:	ba 0a 00 00 00       	mov    $0xa,%edx
    8a6c:	48 8d 35 47 67 00 00 	lea    0x6747(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8a73:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8a7a:	48 89 df             	mov    %rbx,%rdi
    8a7d:	5b                   	pop    %rbx
    8a7e:	5d                   	pop    %rbp
    8a7f:	41 5c                	pop    %r12
    8a81:	41 5d                	pop    %r13
    8a83:	41 5e                	pop    %r14
    8a85:	41 5f                	pop    %r15
    8a87:	e9 44 b7 ff ff       	jmp    41d0 <buf_put>
    8a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a90:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8a95:	4d 85 ed             	test   %r13,%r13
    8a98:	0f 84 02 0c 00 00    	je     96a0 <fwp_write+0xe40>
    8a9e:	48 8d 35 5d 67 00 00 	lea    0x675d(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8aa5:	4c 89 ef             	mov    %r13,%rdi
    8aa8:	e8 63 aa ff ff       	call   3510 <strcmp@plt>
    8aad:	41 89 c1             	mov    %eax,%r9d
    8ab0:	85 c0                	test   %eax,%eax
    8ab2:	0f 84 6c 0c 00 00    	je     9724 <fwp_write+0xec4>
    8ab8:	4c 89 ef             	mov    %r13,%rdi
    8abb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ac0:	e8 6b a9 ff ff       	call   3430 <strlen@plt>
    8ac5:	4c 89 ee             	mov    %r13,%rsi
    8ac8:	48 89 df             	mov    %rbx,%rdi
    8acb:	48 89 c2             	mov    %rax,%rdx
    8ace:	e8 fd b6 ff ff       	call   41d0 <buf_put>
    8ad3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ad8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8add:	48 89 df             	mov    %rbx,%rdi
    8ae0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ae5:	e8 e6 b6 ff ff       	call   41d0 <buf_put>
    8aea:	ba 01 00 00 00       	mov    $0x1,%edx
    8aef:	4c 89 fe             	mov    %r15,%rsi
    8af2:	48 89 df             	mov    %rbx,%rdi
    8af5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8afa:	e8 d1 b6 ff ff       	call   41d0 <buf_put>
    8aff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8b04:	45 31 f6             	xor    %r14d,%r14d
    8b07:	85 d2                	test   %edx,%edx
    8b09:	0f 8e 81 0a 00 00    	jle    9590 <fwp_write+0xd30>
    8b0f:	45 31 ed             	xor    %r13d,%r13d
    8b12:	4d 85 ed             	test   %r13,%r13
    8b15:	0f 85 75 07 00 00    	jne    9290 <fwp_write+0xa30>
    8b1b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8b22:	00 
    8b23:	45 85 f6             	test   %r14d,%r14d
    8b26:	0f 84 84 07 00 00    	je     92b0 <fwp_write+0xa50>
    8b2c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8b31:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8b36:	48 89 df             	mov    %rbx,%rdi
    8b39:	49 83 c5 01          	add    $0x1,%r13
    8b3d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8b41:	31 c9                	xor    %ecx,%ecx
    8b43:	e8 18 fd ff ff       	call   8860 <fwp_write>
    8b48:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8b4d:	7f c3                	jg     8b12 <fwp_write+0x2b2>
    8b4f:	45 85 f6             	test   %r14d,%r14d
    8b52:	0f 84 38 0a 00 00    	je     9590 <fwp_write+0xd30>
    8b58:	b8 29 00 00 00       	mov    $0x29,%eax
    8b5d:	ba 01 00 00 00       	mov    $0x1,%edx
    8b62:	4c 89 fe             	mov    %r15,%rsi
    8b65:	48 89 df             	mov    %rbx,%rdi
    8b68:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8b6c:	e8 5f b6 ff ff       	call   41d0 <buf_put>
    8b71:	e9 80 fd ff ff       	jmp    88f6 <fwp_write+0x96>
    8b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b7d:	00 00 00 
    8b80:	ba 01 00 00 00       	mov    $0x1,%edx
    8b85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b8a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8b8f:	e8 3c b6 ff ff       	call   41d0 <buf_put>
    8b94:	48 85 ed             	test   %rbp,%rbp
    8b97:	0f 84 93 06 00 00    	je     9230 <fwp_write+0x9d0>
    8b9d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8ba1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ba6:	31 c9                	xor    %ecx,%ecx
    8ba8:	48 89 df             	mov    %rbx,%rdi
    8bab:	e8 b0 fc ff ff       	call   8860 <fwp_write>
    8bb0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8bb4:	48 85 ed             	test   %rbp,%rbp
    8bb7:	0f 84 73 06 00 00    	je     9230 <fwp_write+0x9d0>
    8bbd:	ba 02 00 00 00       	mov    $0x2,%edx
    8bc2:	48 8d 35 2c 66 00 00 	lea    0x662c(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8bc9:	48 89 df             	mov    %rbx,%rdi
    8bcc:	e8 ff b5 ff ff       	call   41d0 <buf_put>
    8bd1:	eb ca                	jmp    8b9d <fwp_write+0x33d>
    8bd3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bd8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8bdc:	85 f6                	test   %esi,%esi
    8bde:	0f 84 fc 07 00 00    	je     93e0 <fwp_write+0xb80>
    8be4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8beb:	00 
    8bec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bf3:	00 00 
    8bf5:	0f 85 3a 01 00 00    	jne    8d35 <fwp_write+0x4d5>
    8bfb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8bff:	4c 89 ea             	mov    %r13,%rdx
    8c02:	e9 6c fe ff ff       	jmp    8a73 <fwp_write+0x213>
    8c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c0e:	00 00 
    8c10:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8c15:	ba 01 00 00 00       	mov    $0x1,%edx
    8c1a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8c1f:	48 89 ee             	mov    %rbp,%rsi
    8c22:	e8 a9 b5 ff ff       	call   41d0 <buf_put>
    8c27:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8c2c:	4c 89 e7             	mov    %r12,%rdi
    8c2f:	e8 fc a7 ff ff       	call   3430 <strlen@plt>
    8c34:	4c 89 e6             	mov    %r12,%rsi
    8c37:	48 89 df             	mov    %rbx,%rdi
    8c3a:	48 89 c2             	mov    %rax,%rdx
    8c3d:	e8 8e b5 ff ff       	call   41d0 <buf_put>
    8c42:	ba 01 00 00 00       	mov    $0x1,%edx
    8c47:	48 89 ee             	mov    %rbp,%rsi
    8c4a:	48 89 df             	mov    %rbx,%rdi
    8c4d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8c52:	e8 79 b5 ff ff       	call   41d0 <buf_put>
    8c57:	e9 9a fc ff ff       	jmp    88f6 <fwp_write+0x96>
    8c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c60:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8c65:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8c69:	0f 8a 8e 0b 00 00    	jp     97fd <fwp_write+0xf9d>
    8c6f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c73:	66 0f 54 05 d5 6f 00 	andpd  0x6fd5(%rip),%xmm0        # fc50 <msg.4+0xe0>
    8c7a:	00 
    8c7b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8c80:	66 0f 2e 05 10 6f 00 	ucomisd 0x6f10(%rip),%xmm0        # fb98 <msg.4+0x28>
    8c87:	00 
    8c88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c8f:	00 
    8c90:	0f 87 b2 09 00 00    	ja     9648 <fwp_write+0xde8>
    8c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c9d:	00 00 00 
    8ca0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ca4:	89 ee                	mov    %ebp,%esi
    8ca6:	4c 89 e7             	mov    %r12,%rdi
    8ca9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8cae:	e8 1d ba ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8cb3:	31 f6                	xor    %esi,%esi
    8cb5:	4c 89 e7             	mov    %r12,%rdi
    8cb8:	e8 33 a7 ff ff       	call   33f0 <strtod@plt>
    8cbd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8cc2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8cc6:	7a 06                	jp     8cce <fwp_write+0x46e>
    8cc8:	0f 84 e9 01 00 00    	je     8eb7 <fwp_write+0x657>
    8cce:	83 c5 01             	add    $0x1,%ebp
    8cd1:	83 fd 12             	cmp    $0x12,%ebp
    8cd4:	75 ca                	jne    8ca0 <fwp_write+0x440>
    8cd6:	be 11 00 00 00       	mov    $0x11,%esi
    8cdb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8cdf:	4c 89 e7             	mov    %r12,%rdi
    8ce2:	e8 e9 b9 ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8ce7:	e9 cb 01 00 00       	jmp    8eb7 <fwp_write+0x657>
    8cec:	0f 1f 40 00          	nopl   0x0(%rax)
    8cf0:	48 83 fd 01          	cmp    $0x1,%rbp
    8cf4:	0f 84 e6 08 00 00    	je     95e0 <fwp_write+0xd80>
    8cfa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8cfe:	b8 02 00 00 00       	mov    $0x2,%eax
    8d03:	ba 01 00 00 00       	mov    $0x1,%edx
    8d08:	48 0f 44 d0          	cmove  %rax,%rdx
    8d0c:	48 8d 35 90 64 00 00 	lea    0x6490(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    8d13:	48 8d 05 8e 64 00 00 	lea    0x648e(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    8d1a:	48 0f 44 f0          	cmove  %rax,%rsi
    8d1e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d25:	00 
    8d26:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d2d:	00 00 
    8d2f:	0f 84 3e fd ff ff    	je     8a73 <fwp_write+0x213>
    8d35:	e8 06 a7 ff ff       	call   3440 <__stack_chk_fail@plt>
    8d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d40:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8d45:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8d4a:	e8 c1 b3 ff ff       	call   4110 <buf_grow>
    8d4f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8d53:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8d59:	4c 03 0b             	add    (%rbx),%r9
    8d5c:	66 45 89 11          	mov    %r10w,(%r9)
    8d60:	45 85 e4             	test   %r12d,%r12d
    8d63:	0f 8e 07 05 00 00    	jle    9270 <fwp_write+0xa10>
    8d69:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8d70:	55 55 55 
    8d73:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8d78:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8d7f:	aa aa aa 
    8d82:	49 83 c1 01          	add    $0x1,%r9
    8d86:	eb 45                	jmp    8dcd <fwp_write+0x56d>
    8d88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d8f:	00 
    8d90:	be 01 00 00 00       	mov    $0x1,%esi
    8d95:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8d9a:	88 07                	mov    %al,(%rdi)
    8d9c:	48 89 e8             	mov    %rbp,%rax
    8d9f:	49 f7 e8             	imul   %r8
    8da2:	48 89 e8             	mov    %rbp,%rax
    8da5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8da9:	48 29 c2             	sub    %rax,%rdx
    8dac:	48 85 c9             	test   %rcx,%rcx
    8daf:	0f 95 c0             	setne  %al
    8db2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8db6:	48 83 ef 01          	sub    $0x1,%rdi
    8dba:	48 21 c5             	and    %rax,%rbp
    8dbd:	48 29 ea             	sub    %rbp,%rdx
    8dc0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8dc4:	49 39 f9             	cmp    %rdi,%r9
    8dc7:	0f 84 a3 04 00 00    	je     9270 <fwp_write+0xa10>
    8dcd:	48 89 e8             	mov    %rbp,%rax
    8dd0:	49 f7 e8             	imul   %r8
    8dd3:	48 89 e8             	mov    %rbp,%rax
    8dd6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8dda:	48 89 d1             	mov    %rdx,%rcx
    8ddd:	48 29 c1             	sub    %rax,%rcx
    8de0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8de4:	48 89 e9             	mov    %rbp,%rcx
    8de7:	48 29 c1             	sub    %rax,%rcx
    8dea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8dee:	49 f7 e2             	mul    %r10
    8df1:	b8 30 00 00 00       	mov    $0x30,%eax
    8df6:	48 89 d6             	mov    %rdx,%rsi
    8df9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8dfd:	48 d1 ee             	shr    $1,%rsi
    8e00:	48 01 f2             	add    %rsi,%rdx
    8e03:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8e07:	48 29 d6             	sub    %rdx,%rsi
    8e0a:	74 8e                	je     8d9a <fwp_write+0x53a>
    8e0c:	48 83 fe 01          	cmp    $0x1,%rsi
    8e10:	0f 85 7a ff ff ff    	jne    8d90 <fwp_write+0x530>
    8e16:	31 f6                	xor    %esi,%esi
    8e18:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8e1d:	e9 78 ff ff ff       	jmp    8d9a <fwp_write+0x53a>
    8e22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e28:	66 0f 6e cd          	movd   %ebp,%xmm1
    8e2c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8e2f:	0f 8a c8 09 00 00    	jp     97fd <fwp_write+0xf9d>
    8e35:	0f 28 c1             	movaps %xmm1,%xmm0
    8e38:	0f 54 05 01 6e 00 00 	andps  0x6e01(%rip),%xmm0        # fc40 <msg.4+0xd0>
    8e3f:	0f 2e 05 be 61 00 00 	ucomiss 0x61be(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8e46:	0f 87 24 08 00 00    	ja     9670 <fwp_write+0xe10>
    8e4c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8e50:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8e56:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e5d:	00 
    8e5e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8e62:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e6e:	00 00 
    8e70:	44 89 ee             	mov    %r13d,%esi
    8e73:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8e78:	4c 89 e7             	mov    %r12,%rdi
    8e7b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8e80:	e8 4b b8 ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8e85:	31 f6                	xor    %esi,%esi
    8e87:	4c 89 e7             	mov    %r12,%rdi
    8e8a:	e8 01 a6 ff ff       	call   3490 <strtof@plt>
    8e8f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8e94:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8e97:	7a 02                	jp     8e9b <fwp_write+0x63b>
    8e99:	74 1c                	je     8eb7 <fwp_write+0x657>
    8e9b:	41 83 c5 01          	add    $0x1,%r13d
    8e9f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8ea3:	75 cb                	jne    8e70 <fwp_write+0x610>
    8ea5:	be 09 00 00 00       	mov    $0x9,%esi
    8eaa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8eaf:	4c 89 e7             	mov    %r12,%rdi
    8eb2:	e8 19 b8 ff ff       	call   46d0 <fwp_format_g.constprop.0>
    8eb7:	4c 89 e7             	mov    %r12,%rdi
    8eba:	e8 81 b4 ff ff       	call   4340 <fwp_finish_float>
    8ebf:	e9 1c fa ff ff       	jmp    88e0 <fwp_write+0x80>
    8ec4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ec8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8ecc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8ed0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8ed7:	00 
    8ed8:	48 89 ef             	mov    %rbp,%rdi
    8edb:	e8 20 ab ff ff       	call   3a00 <fwp_fmt_u128>
    8ee0:	48 89 ef             	mov    %rbp,%rdi
    8ee3:	e8 48 a5 ff ff       	call   3430 <strlen@plt>
    8ee8:	48 89 ee             	mov    %rbp,%rsi
    8eeb:	48 89 df             	mov    %rbx,%rdi
    8eee:	48 89 c2             	mov    %rax,%rdx
    8ef1:	e8 da b2 ff ff       	call   41d0 <buf_put>
    8ef6:	e9 fb f9 ff ff       	jmp    88f6 <fwp_write+0x96>
    8efb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f00:	ba 06 00 00 00       	mov    $0x6,%edx
    8f05:	48 8d 35 ec 62 00 00 	lea    0x62ec(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    8f0c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8f12:	e8 b9 b2 ff ff       	call   41d0 <buf_put>
    8f17:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8f1e:	ff ff 7f 
    8f21:	48 23 55 00          	and    0x0(%rbp),%rdx
    8f25:	0f 84 86 02 00 00    	je     91b1 <fwp_write+0x951>
    8f2b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f30:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8f34:	48 85 d2             	test   %rdx,%rdx
    8f37:	0f 84 ae 00 00 00    	je     8feb <fwp_write+0x78b>
    8f3d:	8b 0a                	mov    (%rdx),%ecx
    8f3f:	83 f9 1c             	cmp    $0x1c,%ecx
    8f42:	0f 84 58 06 00 00    	je     95a0 <fwp_write+0xd40>
    8f48:	83 f9 1b             	cmp    $0x1b,%ecx
    8f4b:	0f 87 9a 00 00 00    	ja     8feb <fwp_write+0x78b>
    8f51:	be 01 00 00 00       	mov    $0x1,%esi
    8f56:	48 d3 e6             	shl    %cl,%rsi
    8f59:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8f5f:	0f 85 4b 04 00 00    	jne    93b0 <fwp_write+0xb50>
    8f65:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8f6b:	0f 85 0f 04 00 00    	jne    9380 <fwp_write+0xb20>
    8f71:	83 e6 21             	and    $0x21,%esi
    8f74:	74 75                	je     8feb <fwp_write+0x78b>
    8f76:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8f7b:	48 85 ff             	test   %rdi,%rdi
    8f7e:	79 07                	jns    8f87 <fwp_write+0x727>
    8f80:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8f84:	4c 01 ee             	add    %r13,%rsi
    8f87:	48 0f be 3e          	movsbq (%rsi),%rdi
    8f8b:	85 c9                	test   %ecx,%ecx
    8f8d:	40 0f b6 f7          	movzbl %dil,%esi
    8f91:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f9c:	00 00 00 00 
    8fa0:	31 c9                	xor    %ecx,%ecx
    8fa2:	48 89 df             	mov    %rbx,%rdi
    8fa5:	49 83 c5 01          	add    $0x1,%r13
    8fa9:	e8 b2 f8 ff ff       	call   8860 <fwp_write>
    8fae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8fb5:	ff ff 7f 
    8fb8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8fbc:	49 39 d5             	cmp    %rdx,%r13
    8fbf:	0f 83 ec 01 00 00    	jae    91b1 <fwp_write+0x951>
    8fc5:	ba 02 00 00 00       	mov    $0x2,%edx
    8fca:	48 89 df             	mov    %rbx,%rdi
    8fcd:	48 8d 35 21 62 00 00 	lea    0x6221(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8fd4:	e8 f7 b1 ff ff       	call   41d0 <buf_put>
    8fd9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8fde:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8fe2:	48 85 d2             	test   %rdx,%rdx
    8fe5:	0f 85 52 ff ff ff    	jne    8f3d <fwp_write+0x6dd>
    8feb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8ff0:	48 85 ff             	test   %rdi,%rdi
    8ff3:	0f 88 cf 05 00 00    	js     95c8 <fwp_write+0xd68>
    8ff9:	48 8b 31             	mov    (%rcx),%rsi
    8ffc:	eb a2                	jmp    8fa0 <fwp_write+0x740>
    8ffe:	66 90                	xchg   %ax,%ax
    9000:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9007:	00 
    9008:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    900f:	00 00 
    9011:	0f 85 1e fd ff ff    	jne    8d35 <fwp_write+0x4d5>
    9017:	ba 08 00 00 00       	mov    $0x8,%edx
    901c:	48 8d 35 a2 61 00 00 	lea    0x61a2(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    9023:	e9 4b fa ff ff       	jmp    8a73 <fwp_write+0x213>
    9028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    902f:	00 
    9030:	89 e8                	mov    %ebp,%eax
    9032:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9039:	76 03                	jbe    903e <fwp_write+0x7de>
    903b:	8b 45 00             	mov    0x0(%rbp),%eax
    903e:	41 89 c6             	mov    %eax,%r14d
    9041:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9046:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    904b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    904f:	4c 89 ef             	mov    %r13,%rdi
    9052:	e8 d9 a3 ff ff       	call   3430 <strlen@plt>
    9057:	4c 89 ee             	mov    %r13,%rsi
    905a:	48 89 df             	mov    %rbx,%rdi
    905d:	48 89 c2             	mov    %rax,%rdx
    9060:	e8 6b b1 ff ff       	call   41d0 <buf_put>
    9065:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    906a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    906e:	85 f6                	test   %esi,%esi
    9070:	0f 8e 80 f8 ff ff    	jle    88f6 <fwp_write+0x96>
    9076:	45 31 ed             	xor    %r13d,%r13d
    9079:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    907e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9083:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9088:	ba 01 00 00 00       	mov    $0x1,%edx
    908d:	4c 89 fe             	mov    %r15,%rsi
    9090:	48 89 04 24          	mov    %rax,(%rsp)
    9094:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9099:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    909d:	48 89 df             	mov    %rbx,%rdi
    90a0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    90a4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    90a9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    90ae:	e8 1d b1 ff ff       	call   41d0 <buf_put>
    90b3:	41 8b 06             	mov    (%r14),%eax
    90b6:	83 f8 0e             	cmp    $0xe,%eax
    90b9:	0f 84 71 02 00 00    	je     9330 <fwp_write+0xad0>
    90bf:	83 f8 10             	cmp    $0x10,%eax
    90c2:	0f 84 38 02 00 00    	je     9300 <fwp_write+0xaa0>
    90c8:	83 f8 0a             	cmp    $0xa,%eax
    90cb:	0f 84 7f 04 00 00    	je     9550 <fwp_write+0xcf0>
    90d1:	0f 8f f9 00 00 00    	jg     91d0 <fwp_write+0x970>
    90d7:	83 f8 03             	cmp    $0x3,%eax
    90da:	0f 8f 50 04 00 00    	jg     9530 <fwp_write+0xcd0>
    90e0:	85 c0                	test   %eax,%eax
    90e2:	78 10                	js     90f4 <fwp_write+0x894>
    90e4:	48 8b 04 24          	mov    (%rsp),%rax
    90e8:	48 c1 e8 3f          	shr    $0x3f,%rax
    90ec:	85 c0                	test   %eax,%eax
    90ee:	0f 85 f9 00 00 00    	jne    91ed <fwp_write+0x98d>
    90f4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    90f9:	48 8b 34 24          	mov    (%rsp),%rsi
    90fd:	31 c9                	xor    %ecx,%ecx
    90ff:	48 89 df             	mov    %rbx,%rdi
    9102:	e8 59 f7 ff ff       	call   8860 <fwp_write>
    9107:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    910c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9111:	49 83 c5 01          	add    $0x1,%r13
    9115:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9119:	0f 8f 5f ff ff ff    	jg     907e <fwp_write+0x81e>
    911f:	e9 d2 f7 ff ff       	jmp    88f6 <fwp_write+0x96>
    9124:	0f 1f 40 00          	nopl   0x0(%rax)
    9128:	ba 06 00 00 00       	mov    $0x6,%edx
    912d:	48 8d 35 b7 60 00 00 	lea    0x60b7(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    9134:	45 31 ed             	xor    %r13d,%r13d
    9137:	e8 94 b0 ff ff       	call   41d0 <buf_put>
    913c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9141:	75 19                	jne    915c <fwp_write+0x8fc>
    9143:	eb 6c                	jmp    91b1 <fwp_write+0x951>
    9145:	0f 1f 00             	nopl   (%rax)
    9148:	ba 02 00 00 00       	mov    $0x2,%edx
    914d:	48 8d 35 a1 60 00 00 	lea    0x60a1(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    9154:	48 89 df             	mov    %rbx,%rdi
    9157:	e8 74 b0 ff ff       	call   41d0 <buf_put>
    915c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9162:	b9 00 02 00 00       	mov    $0x200,%ecx
    9167:	31 c0                	xor    %eax,%eax
    9169:	49 83 c5 01          	add    $0x1,%r13
    916d:	4c 8d 05 7e 60 00 00 	lea    0x607e(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    9174:	ba 02 00 00 00       	mov    $0x2,%edx
    9179:	be 00 02 00 00       	mov    $0x200,%esi
    917e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9185:	00 
    9186:	e8 05 a2 ff ff       	call   3390 <__snprintf_chk@plt>
    918b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9192:	00 
    9193:	e8 98 a2 ff ff       	call   3430 <strlen@plt>
    9198:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    919f:	00 
    91a0:	48 89 df             	mov    %rbx,%rdi
    91a3:	48 89 c2             	mov    %rax,%rdx
    91a6:	e8 25 b0 ff ff       	call   41d0 <buf_put>
    91ab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    91af:	72 97                	jb     9148 <fwp_write+0x8e8>
    91b1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91b6:	ba 01 00 00 00       	mov    $0x1,%edx
    91bb:	48 89 df             	mov    %rbx,%rdi
    91be:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    91c3:	e8 08 b0 ff ff       	call   41d0 <buf_put>
    91c8:	e9 29 f7 ff ff       	jmp    88f6 <fwp_write+0x96>
    91cd:	0f 1f 00             	nopl   (%rax)
    91d0:	83 f8 0b             	cmp    $0xb,%eax
    91d3:	0f 85 1b ff ff ff    	jne    90f4 <fwp_write+0x894>
    91d9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    91de:	66 0f 50 c3          	movmskpd %xmm3,%eax
    91e2:	83 e0 01             	and    $0x1,%eax
    91e5:	85 c0                	test   %eax,%eax
    91e7:	0f 84 07 ff ff ff    	je     90f4 <fwp_write+0x894>
    91ed:	4c 89 fe             	mov    %r15,%rsi
    91f0:	48 89 df             	mov    %rbx,%rdi
    91f3:	ba 01 00 00 00       	mov    $0x1,%edx
    91f8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    91fd:	e8 ce af ff ff       	call   41d0 <buf_put>
    9202:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9207:	48 8b 34 24          	mov    (%rsp),%rsi
    920b:	31 c9                	xor    %ecx,%ecx
    920d:	48 89 df             	mov    %rbx,%rdi
    9210:	e8 4b f6 ff ff       	call   8860 <fwp_write>
    9215:	ba 01 00 00 00       	mov    $0x1,%edx
    921a:	4c 89 fe             	mov    %r15,%rsi
    921d:	48 89 df             	mov    %rbx,%rdi
    9220:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9225:	e8 a6 af ff ff       	call   41d0 <buf_put>
    922a:	e9 d8 fe ff ff       	jmp    9107 <fwp_write+0x8a7>
    922f:	90                   	nop
    9230:	ba 01 00 00 00       	mov    $0x1,%edx
    9235:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    923a:	48 89 df             	mov    %rbx,%rdi
    923d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9242:	e8 89 af ff ff       	call   41d0 <buf_put>
    9247:	e9 aa f6 ff ff       	jmp    88f6 <fwp_write+0x96>
    924c:	0f 1f 40 00          	nopl   0x0(%rax)
    9250:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9255:	ba 01 00 00 00       	mov    $0x1,%edx
    925a:	48 89 df             	mov    %rbx,%rdi
    925d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9262:	e8 69 af ff ff       	call   41d0 <buf_put>
    9267:	e9 8a f6 ff ff       	jmp    88f6 <fwp_write+0x96>
    926c:	0f 1f 40 00          	nopl   0x0(%rax)
    9270:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9274:	48 8b 13             	mov    (%rbx),%rdx
    9277:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    927c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9280:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9284:	e9 6d f6 ff ff       	jmp    88f6 <fwp_write+0x96>
    9289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9290:	ba 02 00 00 00       	mov    $0x2,%edx
    9295:	48 8d 35 59 5f 00 00 	lea    0x5f59(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    929c:	48 89 df             	mov    %rbx,%rdi
    929f:	e8 2c af ff ff       	call   41d0 <buf_put>
    92a4:	e9 72 f8 ff ff       	jmp    8b1b <fwp_write+0x2bb>
    92a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    92b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    92ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    92be:	48 89 f7             	mov    %rsi,%rdi
    92c1:	48 89 34 24          	mov    %rsi,(%rsp)
    92c5:	e8 66 a1 ff ff       	call   3430 <strlen@plt>
    92ca:	48 8b 34 24          	mov    (%rsp),%rsi
    92ce:	48 89 df             	mov    %rbx,%rdi
    92d1:	48 89 c2             	mov    %rax,%rdx
    92d4:	e8 f7 ae ff ff       	call   41d0 <buf_put>
    92d9:	ba 03 00 00 00       	mov    $0x3,%edx
    92de:	48 8d 35 33 5f 00 00 	lea    0x5f33(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    92e5:	48 89 df             	mov    %rbx,%rdi
    92e8:	e8 e3 ae ff ff       	call   41d0 <buf_put>
    92ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    92f2:	e9 35 f8 ff ff       	jmp    8b2c <fwp_write+0x2cc>
    92f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    92fe:	00 00 
    9300:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9305:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9309:	48 85 ff             	test   %rdi,%rdi
    930c:	0f 84 e2 fd ff ff    	je     90f4 <fwp_write+0x894>
    9312:	48 8d 35 e9 5e 00 00 	lea    0x5ee9(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    9319:	e8 f2 a1 ff ff       	call   3510 <strcmp@plt>
    931e:	85 c0                	test   %eax,%eax
    9320:	0f 95 c0             	setne  %al
    9323:	0f b6 c0             	movzbl %al,%eax
    9326:	e9 c1 fd ff ff       	jmp    90ec <fwp_write+0x88c>
    932b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9330:	31 c0                	xor    %eax,%eax
    9332:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9339:	00 
    933a:	0f 97 c0             	seta   %al
    933d:	e9 aa fd ff ff       	jmp    90ec <fwp_write+0x88c>
    9342:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9348:	48 89 df             	mov    %rbx,%rdi
    934b:	ba 02 00 00 00       	mov    $0x2,%edx
    9350:	48 8d 35 a8 5e 00 00 	lea    0x5ea8(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    9357:	e8 74 ae ff ff       	call   41d0 <buf_put>
    935c:	4c 89 e8             	mov    %r13,%rax
    935f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9364:	31 c9                	xor    %ecx,%ecx
    9366:	48 c1 e0 04          	shl    $0x4,%rax
    936a:	48 89 df             	mov    %rbx,%rdi
    936d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9372:	e8 e9 f4 ff ff       	call   8860 <fwp_write>
    9377:	e9 5e f6 ff ff       	jmp    89da <fwp_write+0x17a>
    937c:	0f 1f 40 00          	nopl   0x0(%rax)
    9380:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9385:	48 85 ff             	test   %rdi,%rdi
    9388:	79 0c                	jns    9396 <fwp_write+0xb36>
    938a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9391:	00 
    9392:	48 03 75 10          	add    0x10(%rbp),%rsi
    9396:	48 63 3e             	movslq (%rsi),%rdi
    9399:	83 f9 02             	cmp    $0x2,%ecx
    939c:	89 fe                	mov    %edi,%esi
    939e:	48 0f 44 f7          	cmove  %rdi,%rsi
    93a2:	e9 f9 fb ff ff       	jmp    8fa0 <fwp_write+0x740>
    93a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    93ae:	00 00 
    93b0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    93b5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    93ba:	48 85 ff             	test   %rdi,%rdi
    93bd:	0f 88 0f 03 00 00    	js     96d2 <fwp_write+0xe72>
    93c3:	49 0f bf 38          	movswq (%r8),%rdi
    93c7:	83 f9 01             	cmp    $0x1,%ecx
    93ca:	0f b7 f7             	movzwl %di,%esi
    93cd:	48 0f 44 f7          	cmove  %rdi,%rsi
    93d1:	e9 ca fb ff ff       	jmp    8fa0 <fwp_write+0x740>
    93d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93dd:	00 00 00 
    93e0:	ba 01 00 00 00       	mov    $0x1,%edx
    93e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    93ea:	48 83 c5 08          	add    $0x8,%rbp
    93ee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    93f3:	e8 d8 ad ff ff       	call   41d0 <buf_put>
    93f8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    93fd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9402:	4d 85 ed             	test   %r13,%r13
    9405:	75 46                	jne    944d <fwp_write+0xbed>
    9407:	e9 04 01 00 00       	jmp    9510 <fwp_write+0xcb0>
    940c:	0f 1f 40 00          	nopl   0x0(%rax)
    9410:	41 80 f9 09          	cmp    $0x9,%r9b
    9414:	0f 84 d6 00 00 00    	je     94f0 <fwp_write+0xc90>
    941a:	41 80 f9 0a          	cmp    $0xa,%r9b
    941e:	0f 85 9c 00 00 00    	jne    94c0 <fwp_write+0xc60>
    9424:	ba 02 00 00 00       	mov    $0x2,%edx
    9429:	48 8d 35 ab 5d 00 00 	lea    0x5dab(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    9430:	48 89 df             	mov    %rbx,%rdi
    9433:	e8 98 ad ff ff       	call   41d0 <buf_put>
    9438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    943f:	00 
    9440:	48 83 c5 01          	add    $0x1,%rbp
    9444:	49 39 ec             	cmp    %rbp,%r12
    9447:	0f 84 c3 00 00 00    	je     9510 <fwp_write+0xcb0>
    944d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9452:	41 80 f9 0d          	cmp    $0xd,%r9b
    9456:	74 28                	je     9480 <fwp_write+0xc20>
    9458:	7e b6                	jle    9410 <fwp_write+0xbb0>
    945a:	41 80 f9 22          	cmp    $0x22,%r9b
    945e:	74 40                	je     94a0 <fwp_write+0xc40>
    9460:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9464:	75 5a                	jne    94c0 <fwp_write+0xc60>
    9466:	ba 02 00 00 00       	mov    $0x2,%edx
    946b:	48 8d 35 66 5d 00 00 	lea    0x5d66(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    9472:	48 89 df             	mov    %rbx,%rdi
    9475:	e8 56 ad ff ff       	call   41d0 <buf_put>
    947a:	eb c4                	jmp    9440 <fwp_write+0xbe0>
    947c:	0f 1f 40 00          	nopl   0x0(%rax)
    9480:	ba 02 00 00 00       	mov    $0x2,%edx
    9485:	48 8d 35 55 5d 00 00 	lea    0x5d55(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    948c:	48 89 df             	mov    %rbx,%rdi
    948f:	e8 3c ad ff ff       	call   41d0 <buf_put>
    9494:	eb aa                	jmp    9440 <fwp_write+0xbe0>
    9496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    949d:	00 00 00 
    94a0:	ba 02 00 00 00       	mov    $0x2,%edx
    94a5:	48 8d 35 29 5d 00 00 	lea    0x5d29(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    94ac:	48 89 df             	mov    %rbx,%rdi
    94af:	e8 1c ad ff ff       	call   41d0 <buf_put>
    94b4:	eb 8a                	jmp    9440 <fwp_write+0xbe0>
    94b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94bd:	00 00 00 
    94c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    94c4:	0f 86 2e 01 00 00    	jbe    95f8 <fwp_write+0xd98>
    94ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    94ce:	0f 84 24 01 00 00    	je     95f8 <fwp_write+0xd98>
    94d4:	ba 01 00 00 00       	mov    $0x1,%edx
    94d9:	4c 89 fe             	mov    %r15,%rsi
    94dc:	48 89 df             	mov    %rbx,%rdi
    94df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    94e4:	e8 e7 ac ff ff       	call   41d0 <buf_put>
    94e9:	e9 52 ff ff ff       	jmp    9440 <fwp_write+0xbe0>
    94ee:	66 90                	xchg   %ax,%ax
    94f0:	ba 02 00 00 00       	mov    $0x2,%edx
    94f5:	48 8d 35 e2 5c 00 00 	lea    0x5ce2(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    94fc:	48 89 df             	mov    %rbx,%rdi
    94ff:	e8 cc ac ff ff       	call   41d0 <buf_put>
    9504:	e9 37 ff ff ff       	jmp    9440 <fwp_write+0xbe0>
    9509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9510:	ba 01 00 00 00       	mov    $0x1,%edx
    9515:	4c 89 fe             	mov    %r15,%rsi
    9518:	48 89 df             	mov    %rbx,%rdi
    951b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9520:	e8 ab ac ff ff       	call   41d0 <buf_put>
    9525:	e9 cc f3 ff ff       	jmp    88f6 <fwp_write+0x96>
    952a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9530:	83 f8 04             	cmp    $0x4,%eax
    9533:	0f 85 bb fb ff ff    	jne    90f4 <fwp_write+0x894>
    9539:	48 8b 04 24          	mov    (%rsp),%rax
    953d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9541:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9546:	48 c1 e8 3f          	shr    $0x3f,%rax
    954a:	e9 96 fc ff ff       	jmp    91e5 <fwp_write+0x985>
    954f:	90                   	nop
    9550:	8b 0c 24             	mov    (%rsp),%ecx
    9553:	31 c0                	xor    %eax,%eax
    9555:	85 c9                	test   %ecx,%ecx
    9557:	0f 98 c0             	sets   %al
    955a:	e9 86 fc ff ff       	jmp    91e5 <fwp_write+0x985>
    955f:	90                   	nop
    9560:	48 f7 d8             	neg    %rax
    9563:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    956a:	00 
    956b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9572:	2d 
    9573:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    957a:	00 
    957b:	48 83 d2 00          	adc    $0x0,%rdx
    957f:	48 89 c6             	mov    %rax,%rsi
    9582:	48 f7 da             	neg    %rdx
    9585:	e8 76 a4 ff ff       	call   3a00 <fwp_fmt_u128>
    958a:	e9 51 f3 ff ff       	jmp    88e0 <fwp_write+0x80>
    958f:	90                   	nop
    9590:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9595:	e9 c3 f5 ff ff       	jmp    8b5d <fwp_write+0x2fd>
    959a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95a0:	4c 89 e9             	mov    %r13,%rcx
    95a3:	48 c1 e1 04          	shl    $0x4,%rcx
    95a7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    95ac:	48 85 ff             	test   %rdi,%rdi
    95af:	0f 89 eb f9 ff ff    	jns    8fa0 <fwp_write+0x740>
    95b5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    95b9:	48 89 ce             	mov    %rcx,%rsi
    95bc:	e9 df f9 ff ff       	jmp    8fa0 <fwp_write+0x740>
    95c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95c8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    95cf:	00 
    95d0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    95d4:	e9 20 fa ff ff       	jmp    8ff9 <fwp_write+0x799>
    95d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95e0:	ba 02 00 00 00       	mov    $0x2,%edx
    95e5:	48 8d 35 b9 5b 00 00 	lea    0x5bb9(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    95ec:	e9 2d f7 ff ff       	jmp    8d1e <fwp_write+0x4be>
    95f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95f8:	4c 8d 05 e5 5b 00 00 	lea    0x5be5(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    95ff:	b9 10 00 00 00       	mov    $0x10,%ecx
    9604:	31 c0                	xor    %eax,%eax
    9606:	ba 02 00 00 00       	mov    $0x2,%edx
    960b:	be 10 00 00 00       	mov    $0x10,%esi
    9610:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9617:	00 
    9618:	e8 73 9d ff ff       	call   3390 <__snprintf_chk@plt>
    961d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9624:	00 
    9625:	e8 06 9e ff ff       	call   3430 <strlen@plt>
    962a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9631:	00 
    9632:	48 89 df             	mov    %rbx,%rdi
    9635:	48 89 c2             	mov    %rax,%rdx
    9638:	e8 93 ab ff ff       	call   41d0 <buf_put>
    963d:	e9 fe fd ff ff       	jmp    9440 <fwp_write+0xbe0>
    9642:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9648:	66 0f ef c0          	pxor   %xmm0,%xmm0
    964c:	48 8d 35 4c 5b 00 00 	lea    0x5b4c(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    9653:	48 8d 05 44 5b 00 00 	lea    0x5b44(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    965a:	4c 89 e7             	mov    %r12,%rdi
    965d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9661:	48 0f 46 f0          	cmovbe %rax,%rsi
    9665:	e8 66 9d ff ff       	call   33d0 <strcpy@plt>
    966a:	e9 71 f2 ff ff       	jmp    88e0 <fwp_write+0x80>
    966f:	90                   	nop
    9670:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9674:	48 8d 35 24 5b 00 00 	lea    0x5b24(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    967b:	48 8d 05 1c 5b 00 00 	lea    0x5b1c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9682:	0f 2f c8             	comiss %xmm0,%xmm1
    9685:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    968c:	00 
    968d:	4c 89 e7             	mov    %r12,%rdi
    9690:	48 0f 46 f0          	cmovbe %rax,%rsi
    9694:	e8 37 9d ff ff       	call   33d0 <strcpy@plt>
    9699:	e9 42 f2 ff ff       	jmp    88e0 <fwp_write+0x80>
    969e:	66 90                	xchg   %ax,%ax
    96a0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    96a5:	45 85 c0             	test   %r8d,%r8d
    96a8:	75 34                	jne    96de <fwp_write+0xe7e>
    96aa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    96b1:	00 
    96b2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    96b9:	00 00 
    96bb:	0f 85 74 f6 ff ff    	jne    8d35 <fwp_write+0x4d5>
    96c1:	ba 02 00 00 00       	mov    $0x2,%edx
    96c6:	48 8d 35 48 5b 00 00 	lea    0x5b48(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    96cd:	e9 a1 f3 ff ff       	jmp    8a73 <fwp_write+0x213>
    96d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    96d6:	49 89 f0             	mov    %rsi,%r8
    96d9:	e9 e5 fc ff ff       	jmp    93c3 <fwp_write+0xb63>
    96de:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    96e3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    96e8:	85 ff                	test   %edi,%edi
    96ea:	0f 84 fa f3 ff ff    	je     8aea <fwp_write+0x28a>
    96f0:	ba 01 00 00 00       	mov    $0x1,%edx
    96f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    96fa:	48 89 df             	mov    %rbx,%rdi
    96fd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9702:	e8 c9 aa ff ff       	call   41d0 <buf_put>
    9707:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    970c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9711:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9717:	85 c0                	test   %eax,%eax
    9719:	0f 8f f0 f3 ff ff    	jg     8b0f <fwp_write+0x2af>
    971f:	e9 34 f4 ff ff       	jmp    8b58 <fwp_write+0x2f8>
    9724:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9728:	49 89 c5             	mov    %rax,%r13
    972b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9730:	49 89 c4             	mov    %rax,%r12
    9733:	49 c1 fd 3f          	sar    $0x3f,%r13
    9737:	4c 09 e8             	or     %r13,%rax
    973a:	0f 84 a7 00 00 00    	je     97e7 <fwp_write+0xf87>
    9740:	48 8d 2d 79 7b 00 00 	lea    0x7b79(%rip),%rbp        # 112c0 <units.0>
    9747:	4d 89 e7             	mov    %r12,%r15
    974a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    974e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9753:	4c 89 ff             	mov    %r15,%rdi
    9756:	4c 89 ee             	mov    %r13,%rsi
    9759:	44 89 0c 24          	mov    %r9d,(%rsp)
    975d:	48 99                	cqto
    975f:	48 89 d1             	mov    %rdx,%rcx
    9762:	48 89 c2             	mov    %rax,%rdx
    9765:	e8 86 4e 00 00       	call   e5f0 <__divmodti4>
    976a:	44 8b 0c 24          	mov    (%rsp),%r9d
    976e:	48 89 c1             	mov    %rax,%rcx
    9771:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9776:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    977b:	0f 84 94 00 00 00    	je     9815 <fwp_write+0xfb5>
    9781:	41 83 c1 01          	add    $0x1,%r9d
    9785:	48 83 c5 10          	add    $0x10,%rbp
    9789:	41 83 f9 05          	cmp    $0x5,%r9d
    978d:	75 bb                	jne    974a <fwp_write+0xeea>
    978f:	4d 85 ed             	test   %r13,%r13
    9792:	79 53                	jns    97e7 <fwp_write+0xf87>
    9794:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9799:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    979e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    97a3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97a8:	48 99                	cqto
    97aa:	48 f7 d8             	neg    %rax
    97ad:	48 83 d2 00          	adc    $0x0,%rdx
    97b1:	48 89 c6             	mov    %rax,%rsi
    97b4:	48 f7 da             	neg    %rdx
    97b7:	e8 44 a2 ff ff       	call   3a00 <fwp_fmt_u128>
    97bc:	49 89 e8             	mov    %rbp,%r8
    97bf:	ba 00 02 00 00       	mov    $0x200,%edx
    97c4:	be 02 00 00 00       	mov    $0x2,%esi
    97c9:	31 c0                	xor    %eax,%eax
    97cb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97d2:	00 
    97d3:	48 8d 0d 36 5a 00 00 	lea    0x5a36(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    97da:	4c 89 e7             	mov    %r12,%rdi
    97dd:	e8 be 9e ff ff       	call   36a0 <__sprintf_chk@plt>
    97e2:	e9 f9 f0 ff ff       	jmp    88e0 <fwp_write+0x80>
    97e7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    97f1:	31 d2                	xor    %edx,%edx
    97f3:	48 89 ef             	mov    %rbp,%rdi
    97f6:	e8 05 a2 ff ff       	call   3a00 <fwp_fmt_u128>
    97fb:	eb bf                	jmp    97bc <fwp_write+0xf5c>
    97fd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9804:	4e 61 4e 00 
    9808:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    980f:	00 
    9810:	e9 cb f0 ff ff       	jmp    88e0 <fwp_write+0x80>
    9815:	44 89 0c 24          	mov    %r9d,(%rsp)
    9819:	48 89 c8             	mov    %rcx,%rax
    981c:	48 85 d2             	test   %rdx,%rdx
    981f:	78 51                	js     9872 <fwp_write+0x1012>
    9821:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9826:	48 89 c6             	mov    %rax,%rsi
    9829:	48 89 ef             	mov    %rbp,%rdi
    982c:	e8 cf a1 ff ff       	call   3a00 <fwp_fmt_u128>
    9831:	44 8b 0c 24          	mov    (%rsp),%r9d
    9835:	49 63 c1             	movslq %r9d,%rax
    9838:	49 89 e8             	mov    %rbp,%r8
    983b:	ba 00 02 00 00       	mov    $0x200,%edx
    9840:	be 02 00 00 00       	mov    $0x2,%esi
    9845:	48 c1 e0 04          	shl    $0x4,%rax
    9849:	48 8d 3d 70 7a 00 00 	lea    0x7a70(%rip),%rdi        # 112c0 <units.0>
    9850:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9857:	00 
    9858:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    985c:	48 8d 0d a8 59 00 00 	lea    0x59a8(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    9863:	4c 89 e7             	mov    %r12,%rdi
    9866:	31 c0                	xor    %eax,%eax
    9868:	e8 33 9e ff ff       	call   36a0 <__sprintf_chk@plt>
    986d:	e9 6e f0 ff ff       	jmp    88e0 <fwp_write+0x80>
    9872:	48 f7 d8             	neg    %rax
    9875:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    987a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    987f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9884:	48 83 d2 00          	adc    $0x0,%rdx
    9888:	48 89 c6             	mov    %rax,%rsi
    988b:	48 f7 da             	neg    %rdx
    988e:	e8 6d a1 ff ff       	call   3a00 <fwp_fmt_u128>
    9893:	44 8b 0c 24          	mov    (%rsp),%r9d
    9897:	eb 9c                	jmp    9835 <fwp_write+0xfd5>
    9899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000098a0 <fwp_hof0.constprop.0>:
    98a0:	41 57                	push   %r15
    98a2:	41 56                	push   %r14
    98a4:	41 55                	push   %r13
    98a6:	41 54                	push   %r12
    98a8:	55                   	push   %rbp
    98a9:	53                   	push   %rbx
    98aa:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    98b1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    98b8:	00 00 
    98ba:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    98c1:	00 
    98c2:	31 c0                	xor    %eax,%eax
    98c4:	48 85 f6             	test   %rsi,%rsi
    98c7:	0f 84 6a 0f 00 00    	je     a837 <fwp_hof0.constprop.0+0xf97>
    98cd:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    98d2:	4c 8d 2d e7 9e 01 00 	lea    0x19ee7(%rip),%r13        # 237c0 <fwp_heap>
    98d9:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    98de:	66 90                	xchg   %ax,%ax
    98e0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    98e7:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    98ec:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    98f3:	48 c1 e2 10          	shl    $0x10,%rdx
    98f7:	48 39 d0             	cmp    %rdx,%rax
    98fa:	73 5d                	jae    9959 <fwp_hof0.constprop.0+0xb9>
    98fc:	48 89 c2             	mov    %rax,%rdx
    98ff:	48 c1 ea 10          	shr    $0x10,%rdx
    9903:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9907:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    990e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9912:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9916:	48 85 ff             	test   %rdi,%rdi
    9919:	74 3e                	je     9959 <fwp_hof0.constprop.0+0xb9>
    991b:	0f b6 0a             	movzbl (%rdx),%ecx
    991e:	80 f9 02             	cmp    $0x2,%cl
    9921:	0f 84 f9 14 00 00    	je     ae20 <fwp_hof0.constprop.0+0x1580>
    9927:	80 f9 01             	cmp    $0x1,%cl
    992a:	75 2d                	jne    9959 <fwp_hof0.constprop.0+0xb9>
    992c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    992f:	0f b7 c0             	movzwl %ax,%eax
    9932:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9935:	48 0f af c1          	imul   %rcx,%rax
    9939:	48 c1 e8 20          	shr    $0x20,%rax
    993d:	48 39 d0             	cmp    %rdx,%rax
    9940:	73 17                	jae    9959 <fwp_hof0.constprop.0+0xb9>
    9942:	48 01 c7             	add    %rax,%rdi
    9945:	0f b6 07             	movzbl (%rdi),%eax
    9948:	84 c0                	test   %al,%al
    994a:	74 0d                	je     9959 <fwp_hof0.constprop.0+0xb9>
    994c:	3c fd                	cmp    $0xfd,%al
    994e:	0f 87 07 17 00 00    	ja     b05b <fwp_hof0.constprop.0+0x17bb>
    9954:	83 c0 01             	add    $0x1,%eax
    9957:	88 07                	mov    %al,(%rdi)
    9959:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    995e:	45 31 c0             	xor    %r8d,%r8d
    9961:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    9968:	00 00 
    996a:	48 89 04 24          	mov    %rax,(%rsp)
    996e:	4c 89 c3             	mov    %r8,%rbx
    9971:	4d 85 c0             	test   %r8,%r8
    9974:	0f 85 96 9d ff ff    	jne    3710 <fwp_hof0.constprop.0.cold+0x5>
    997a:	48 8b 05 d7 ba 01 00 	mov    0x1bad7(%rip),%rax        # 25458 <fwp_cleanups>
    9981:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9988:	4c 8d 35 51 d8 ff ff 	lea    -0x27af(%rip),%r14        # 71e0 <fwp_tape_scope_release>
    998f:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    9996:	ff 
    9997:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    999c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    99a1:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    99a6:	48 c1 e2 10          	shl    $0x10,%rdx
    99aa:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    99af:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    99b4:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    99b9:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    99be:	48 89 05 93 ba 01 00 	mov    %rax,0x1ba93(%rip)        # 25458 <fwp_cleanups>
    99c5:	48 8d 05 44 96 00 00 	lea    0x9644(%rip),%rax        # 13010 <fc37>
    99cc:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    99d3:	48 39 d0             	cmp    %rdx,%rax
    99d6:	73 5d                	jae    9a35 <fwp_hof0.constprop.0+0x195>
    99d8:	48 89 c2             	mov    %rax,%rdx
    99db:	48 c1 ea 10          	shr    $0x10,%rdx
    99df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99e3:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    99ea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99ee:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99f2:	48 85 ff             	test   %rdi,%rdi
    99f5:	74 3e                	je     9a35 <fwp_hof0.constprop.0+0x195>
    99f7:	0f b6 0a             	movzbl (%rdx),%ecx
    99fa:	80 f9 02             	cmp    $0x2,%cl
    99fd:	0f 84 bd 12 00 00    	je     acc0 <fwp_hof0.constprop.0+0x1420>
    9a03:	80 f9 01             	cmp    $0x1,%cl
    9a06:	75 2d                	jne    9a35 <fwp_hof0.constprop.0+0x195>
    9a08:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a0b:	0f b7 c0             	movzwl %ax,%eax
    9a0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a11:	48 0f af c1          	imul   %rcx,%rax
    9a15:	48 c1 e8 20          	shr    $0x20,%rax
    9a19:	48 39 d0             	cmp    %rdx,%rax
    9a1c:	73 17                	jae    9a35 <fwp_hof0.constprop.0+0x195>
    9a1e:	48 01 c7             	add    %rax,%rdi
    9a21:	0f b6 07             	movzbl (%rdi),%eax
    9a24:	84 c0                	test   %al,%al
    9a26:	74 0d                	je     9a35 <fwp_hof0.constprop.0+0x195>
    9a28:	3c fd                	cmp    $0xfd,%al
    9a2a:	0f 87 73 15 00 00    	ja     afa3 <fwp_hof0.constprop.0+0x1703>
    9a30:	83 c0 01             	add    $0x1,%eax
    9a33:	88 07                	mov    %al,(%rdi)
    9a35:	48 8d 3d d4 95 00 00 	lea    0x95d4(%rip),%rdi        # 13010 <fc37>
    9a3c:	e8 6f d4 ff ff       	call   6eb0 <fwp_closure_drop>
    9a41:	48 8b 04 24          	mov    (%rsp),%rax
    9a45:	48 85 c0             	test   %rax,%rax
    9a48:	0f 84 41 14 00 00    	je     ae8f <fwp_hof0.constprop.0+0x15ef>
    9a4e:	31 ed                	xor    %ebp,%ebp
    9a50:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a54:	48 83 c5 01          	add    $0x1,%rbp
    9a58:	48 85 c0             	test   %rax,%rax
    9a5b:	75 f3                	jne    9a50 <fwp_hof0.constprop.0+0x1b0>
    9a5d:	31 ff                	xor    %edi,%edi
    9a5f:	e8 ac a7 ff ff       	call   4210 <descent_phase_step>
    9a64:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    9a6b:	0f 87 35 16 00 00    	ja     b0a6 <fwp_hof0.constprop.0+0x1806>
    9a71:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9a76:	8b 35 e4 95 00 00    	mov    0x95e4(%rip),%esi        # 13060 <registered_finish.1>
    9a7c:	85 f6                	test   %esi,%esi
    9a7e:	0f 84 04 12 00 00    	je     ac88 <fwp_hof0.constprop.0+0x13e8>
    9a84:	48 8b 15 3d 96 01 00 	mov    0x1963d(%rip),%rdx        # 230c8 <fwp_tape_next_slot>
    9a8b:	4c 8b 25 46 96 01 00 	mov    0x19646(%rip),%r12        # 230d8 <fwp_ntapes>
    9a92:	49 39 d4             	cmp    %rdx,%r12
    9a95:	0f 8e d5 10 00 00    	jle    ab70 <fwp_hof0.constprop.0+0x12d0>
    9a9b:	48 6b c2 58          	imul   $0x58,%rdx,%rax
    9a9f:	48 03 05 3a 96 01 00 	add    0x1963a(%rip),%rax        # 230e0 <fwp_tapes>
    9aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9aad:	00 00 00 
    9ab0:	8b 48 04             	mov    0x4(%rax),%ecx
    9ab3:	85 c9                	test   %ecx,%ecx
    9ab5:	75 0c                	jne    9ac3 <fwp_hof0.constprop.0+0x223>
    9ab7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9abd:	0f 86 ad 10 00 00    	jbe    ab70 <fwp_hof0.constprop.0+0x12d0>
    9ac3:	48 83 c2 01          	add    $0x1,%rdx
    9ac7:	48 83 c0 58          	add    $0x58,%rax
    9acb:	49 39 d4             	cmp    %rdx,%r12
    9ace:	75 e0                	jne    9ab0 <fwp_hof0.constprop.0+0x210>
    9ad0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9ad7:	0f 8f e1 15 00 00    	jg     b0be <fwp_hof0.constprop.0+0x181e>
    9add:	4c 3b 25 ec 95 01 00 	cmp    0x195ec(%rip),%r12        # 230d0 <fwp_tapes_cap>
    9ae4:	4c 8b 3d f5 95 01 00 	mov    0x195f5(%rip),%r15        # 230e0 <fwp_tapes>
    9aeb:	75 4b                	jne    9b38 <fwp_hof0.constprop.0+0x298>
    9aed:	4d 85 e4             	test   %r12,%r12
    9af0:	0f 84 8a 13 00 00    	je     ae80 <fwp_hof0.constprop.0+0x15e0>
    9af6:	4b 8d 2c 24          	lea    (%r12,%r12,1),%rbp
    9afa:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9aff:	48 39 c5             	cmp    %rax,%rbp
    9b02:	48 0f 4f e8          	cmovg  %rax,%rbp
    9b06:	48 6b f5 58          	imul   $0x58,%rbp,%rsi
    9b0a:	4c 89 ff             	mov    %r15,%rdi
    9b0d:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    9b13:	e8 88 9a ff ff       	call   35a0 <realloc@plt>
    9b18:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    9b1e:	48 85 c0             	test   %rax,%rax
    9b21:	49 89 c7             	mov    %rax,%r15
    9b24:	0f 84 c2 15 00 00    	je     b0ec <fwp_hof0.constprop.0+0x184c>
    9b2a:	48 89 05 af 95 01 00 	mov    %rax,0x195af(%rip)        # 230e0 <fwp_tapes>
    9b31:	48 89 2d 98 95 01 00 	mov    %rbp,0x19598(%rip)        # 230d0 <fwp_tapes_cap>
    9b38:	49 6b cc 58          	imul   $0x58,%r12,%rcx
    9b3c:	31 c0                	xor    %eax,%eax
    9b3e:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
    9b43:	4c 01 f9             	add    %r15,%rcx
    9b46:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9b4a:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9b51:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9b55:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    9b5c:	00 
    9b5d:	48 29 f9             	sub    %rdi,%rcx
    9b60:	83 c1 58             	add    $0x58,%ecx
    9b63:	c1 e9 03             	shr    $0x3,%ecx
    9b66:	f3 48 ab             	rep stos %rax,(%rdi)
    9b69:	48 89 2d 68 95 01 00 	mov    %rbp,0x19568(%rip)        # 230d8 <fwp_ntapes>
    9b70:	49 6b cc 58          	imul   $0x58,%r12,%rcx
    9b74:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9b78:	48 8d 3d a3 55 00 00 	lea    0x55a3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    9b7f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9b84:	4c 01 f9             	add    %r15,%rcx
    9b87:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    9b8e:	00 
    9b8f:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9b94:	e8 e7 97 ff ff       	call   3380 <getenv@plt>
    9b99:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9b9e:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9ba4:	48 85 c0             	test   %rax,%rax
    9ba7:	0f 84 a3 0d 00 00    	je     a950 <fwp_hof0.constprop.0+0x10b0>
    9bad:	80 38 30             	cmpb   $0x30,(%rax)
    9bb0:	0f 85 9a 0d 00 00    	jne    a950 <fwp_hof0.constprop.0+0x10b0>
    9bb6:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9bba:	0f 85 90 0d 00 00    	jne    a950 <fwp_hof0.constprop.0+0x10b0>
    9bc0:	8b 01                	mov    (%rcx),%eax
    9bc2:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    9bc9:	48 89 2d f8 94 01 00 	mov    %rbp,0x194f8(%rip)        # 230c8 <fwp_tape_next_slot>
    9bd0:	8d 50 01             	lea    0x1(%rax),%edx
    9bd3:	48 8b 05 b6 5f 00 00 	mov    0x5fb6(%rip),%rax        # fb90 <msg.4+0x20>
    9bda:	48 c7 41 40 00 00 00 	movq   $0x0,0x40(%rcx)
    9be1:	00 
    9be2:	89 11                	mov    %edx,(%rcx)
    9be4:	48 89 41 48          	mov    %rax,0x48(%rcx)
    9be8:	48 8b 05 69 b8 01 00 	mov    0x1b869(%rip),%rax        # 25458 <fwp_cleanups>
    9bef:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    9bf3:	48 85 c0             	test   %rax,%rax
    9bf6:	75 14                	jne    9c0c <fwp_hof0.constprop.0+0x36c>
    9bf8:	e9 e3 14 00 00       	jmp    b0e0 <fwp_hof0.constprop.0+0x1840>
    9bfd:	0f 1f 00             	nopl   (%rax)
    9c00:	48 8b 00             	mov    (%rax),%rax
    9c03:	48 85 c0             	test   %rax,%rax
    9c06:	0f 84 d4 14 00 00    	je     b0e0 <fwp_hof0.constprop.0+0x1840>
    9c0c:	4c 39 70 08          	cmp    %r14,0x8(%rax)
    9c10:	75 ee                	jne    9c00 <fwp_hof0.constprop.0+0x360>
    9c12:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9c16:	44 89 e6             	mov    %r12d,%esi
    9c19:	48 63 07             	movslq (%rdi),%rax
    9c1c:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    9c20:	89 41 4c             	mov    %eax,0x4c(%rcx)
    9c23:	85 c0                	test   %eax,%eax
    9c25:	78 09                	js     9c30 <fwp_hof0.constprop.0+0x390>
    9c27:	48 6b c0 58          	imul   $0x58,%rax,%rax
    9c2b:	45 89 64 07 48       	mov    %r12d,0x48(%r15,%rax,1)
    9c30:	89 37                	mov    %esi,(%rdi)
    9c32:	bf 01 00 00 00       	mov    $0x1,%edi
    9c37:	45 31 e4             	xor    %r12d,%r12d
    9c3a:	89 54 24 08          	mov    %edx,0x8(%rsp)
    9c3e:	e8 cd a5 ff ff       	call   4210 <descent_phase_step>
    9c43:	48 8b 3c 24          	mov    (%rsp),%rdi
    9c47:	8b 54 24 08          	mov    0x8(%rsp),%edx
    9c4b:	48 85 ff             	test   %rdi,%rdi
    9c4e:	48 89 f8             	mov    %rdi,%rax
    9c51:	0f 84 51 0e 00 00    	je     aaa8 <fwp_hof0.constprop.0+0x1208>
    9c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c5e:	00 00 
    9c60:	48 8b 40 10          	mov    0x10(%rax),%rax
    9c64:	49 83 c4 01          	add    $0x1,%r12
    9c68:	48 85 c0             	test   %rax,%rax
    9c6b:	75 f3                	jne    9c60 <fwp_hof0.constprop.0+0x3c0>
    9c6d:	48 8b 0c 24          	mov    (%rsp),%rcx
    9c71:	0f 1f 40 00          	nopl   0x0(%rax)
    9c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c7c:	00 00 00 00 
    9c80:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9c84:	48 83 c0 01          	add    $0x1,%rax
    9c88:	48 85 c9             	test   %rcx,%rcx
    9c8b:	75 f3                	jne    9c80 <fwp_hof0.constprop.0+0x3e0>
    9c8d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9c94:	ff ff 1f 
    9c97:	48 39 c1             	cmp    %rax,%rcx
    9c9a:	0f 82 fa 13 00 00    	jb     b09a <fwp_hof0.constprop.0+0x17fa>
    9ca0:	4d 85 e4             	test   %r12,%r12
    9ca3:	0f 8e ff 0d 00 00    	jle    aaa8 <fwp_hof0.constprop.0+0x1208>
    9ca9:	49 39 c4             	cmp    %rax,%r12
    9cac:	4c 0f 47 e0          	cmova  %rax,%r12
    9cb0:	4c 89 e0             	mov    %r12,%rax
    9cb3:	48 c1 e8 3c          	shr    $0x3c,%rax
    9cb7:	0f 85 dd 13 00 00    	jne    b09a <fwp_hof0.constprop.0+0x17fa>
    9cbd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9cc1:	48 c1 e2 10          	shl    $0x10,%rdx
    9cc5:	be 02 00 00 00       	mov    $0x2,%esi
    9cca:	48 09 ea             	or     %rbp,%rdx
    9ccd:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9cd4:	00 
    9cd5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9cda:	e8 71 bf ff ff       	call   5c50 <fwp_heap_alloc>
    9cdf:	4c 89 30             	mov    %r14,(%rax)
    9ce2:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9ce9:	48 89 c5             	mov    %rax,%rbp
    9cec:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9cf3:	48 c1 e2 10          	shl    $0x10,%rdx
    9cf7:	48 39 d0             	cmp    %rdx,%rax
    9cfa:	0f 83 50 0e 00 00    	jae    ab50 <fwp_hof0.constprop.0+0x12b0>
    9d00:	48 89 c2             	mov    %rax,%rdx
    9d03:	48 c1 ea 10          	shr    $0x10,%rdx
    9d07:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9d0b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9d12:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9d16:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9d1a:	4d 85 f6             	test   %r14,%r14
    9d1d:	74 3a                	je     9d59 <fwp_hof0.constprop.0+0x4b9>
    9d1f:	0f b6 32             	movzbl (%rdx),%esi
    9d22:	40 80 fe 02          	cmp    $0x2,%sil
    9d26:	0f 84 eb 0d 00 00    	je     ab17 <fwp_hof0.constprop.0+0x1277>
    9d2c:	40 80 fe 01          	cmp    $0x1,%sil
    9d30:	75 27                	jne    9d59 <fwp_hof0.constprop.0+0x4b9>
    9d32:	8b 72 18             	mov    0x18(%rdx),%esi
    9d35:	0f b7 c0             	movzwl %ax,%eax
    9d38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d3b:	48 0f af c6          	imul   %rsi,%rax
    9d3f:	48 c1 e8 20          	shr    $0x20,%rax
    9d43:	48 39 d0             	cmp    %rdx,%rax
    9d46:	73 11                	jae    9d59 <fwp_hof0.constprop.0+0x4b9>
    9d48:	49 01 c6             	add    %rax,%r14
    9d4b:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9d4f:	0f 84 d5 0d 00 00    	je     ab2a <fwp_hof0.constprop.0+0x128a>
    9d55:	41 c6 06 01          	movb   $0x1,(%r14)
    9d59:	4d 85 e4             	test   %r12,%r12
    9d5c:	74 55                	je     9db3 <fwp_hof0.constprop.0+0x513>
    9d5e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9d63:	48 8b 14 24          	mov    (%rsp),%rdx
    9d67:	31 c0                	xor    %eax,%eax
    9d69:	48 c1 e6 20          	shl    $0x20,%rsi
    9d6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d74:	00 
    9d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d7c:	00 00 00 00 
    9d80:	48 89 c1             	mov    %rax,%rcx
    9d83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9d88:	48 01 f1             	add    %rsi,%rcx
    9d8b:	0f 80 7f 99 ff ff    	jo     3710 <fwp_hof0.constprop.0.cold+0x5>
    9d91:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    9d96:	48 89 c1             	mov    %rax,%rcx
    9d99:	48 83 c0 01          	add    $0x1,%rax
    9d9d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9da1:	48 c1 e1 04          	shl    $0x4,%rcx
    9da5:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    9daa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9dae:	4c 39 e0             	cmp    %r12,%rax
    9db1:	72 cd                	jb     9d80 <fwp_hof0.constprop.0+0x4e0>
    9db3:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9db7:	48 d1 e8             	shr    $1,%rax
    9dba:	0f 84 a0 0d 00 00    	je     ab60 <fwp_hof0.constprop.0+0x12c0>
    9dc0:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9dc4:	48 89 f7             	mov    %rsi,%rdi
    9dc7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9dcb:	0f 85 c9 12 00 00    	jne    b09a <fwp_hof0.constprop.0+0x17fa>
    9dd1:	48 c7 84 24 a0 00 00 	movq   $0xffffffffffffffff,0xa0(%rsp)
    9dd8:	00 ff ff ff ff 
    9ddd:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9de1:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
    9de8:	00 00 00 00 00 
    9ded:	48 85 f6             	test   %rsi,%rsi
    9df0:	74 59                	je     9e4b <fwp_hof0.constprop.0+0x5ab>
    9df2:	48 c1 e0 04          	shl    $0x4,%rax
    9df6:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    9dfb:	49 89 d7             	mov    %rdx,%r15
    9dfe:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    9e02:	4c 8d 74 05 f8       	lea    -0x8(%rbp,%rax,1),%r14
    9e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e0e:	00 00 
    9e10:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9e14:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9e18:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
    9e1f:	00 
    9e20:	48 83 c3 10          	add    $0x10,%rbx
    9e24:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9e28:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9e2c:	e8 3f c4 ff ff       	call   6270 <w120>
    9e31:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9e36:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9e3a:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9e3e:	49 39 de             	cmp    %rbx,%r14
    9e41:	75 cd                	jne    9e10 <fwp_hof0.constprop.0+0x570>
    9e43:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9e48:	4c 89 fa             	mov    %r15,%rdx
    9e4b:	48 89 55 00          	mov    %rdx,0x0(%rbp)
    9e4f:	48 89 ef             	mov    %rbp,%rdi
    9e52:	e8 69 cb ff ff       	call   69c0 <w176.constprop.0>
    9e57:	48 89 ef             	mov    %rbp,%rdi
    9e5a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9e5f:	e8 8c e2 ff ff       	call   80f0 <fwp_drop10>
    9e64:	bf 02 00 00 00       	mov    $0x2,%edi
    9e69:	e8 a2 a3 ff ff       	call   4210 <descent_phase_step>
    9e6e:	4c 63 7c 24 08       	movslq 0x8(%rsp),%r15
    9e73:	4c 89 ff             	mov    %r15,%rdi
    9e76:	e8 15 a8 ff ff       	call   4690 <fwp_tape_of>
    9e7b:	48 89 c6             	mov    %rax,%rsi
    9e7e:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    9e83:	0f 85 0d 13 00 00    	jne    b196 <fwp_hof0.constprop.0+0x18f6>
    9e89:	48 89 c7             	mov    %rax,%rdi
    9e8c:	e8 2f 9d ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    9e91:	48 8b 56 38          	mov    0x38(%rsi),%rdx
    9e95:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9e99:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9ea0:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    9ea5:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9eaa:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    9eaf:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    9eb3:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    9eb7:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    9ebc:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9ec0:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9ec6:	77 1a                	ja     9ee2 <fwp_hof0.constprop.0+0x642>
    9ec8:	0f b7 44 24 08       	movzwl 0x8(%rsp),%eax
    9ecd:	83 e8 01             	sub    $0x1,%eax
    9ed0:	48 98                	cltq
    9ed2:	48 3b 05 ef 91 01 00 	cmp    0x191ef(%rip),%rax        # 230c8 <fwp_tape_next_slot>
    9ed9:	7d 07                	jge    9ee2 <fwp_hof0.constprop.0+0x642>
    9edb:	48 89 05 e6 91 01 00 	mov    %rax,0x191e6(%rip)        # 230c8 <fwp_tape_next_slot>
    9ee2:	48 8b 05 6f b5 01 00 	mov    0x1b56f(%rip),%rax        # 25458 <fwp_cleanups>
    9ee9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9eed:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    9ef4:	00 
    9ef5:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    9efc:	00 
    9efd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9f01:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    9f07:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    9f0e:	00 
    9f0f:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9f16:	00 
    9f17:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9f1b:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    9f20:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9f27:	00 
    9f28:	48 8d 05 01 b1 ff ff 	lea    -0x4eff(%rip),%rax        # 5030 <fwp_tape_buffers_release>
    9f2f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    9f36:	00 
    9f37:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9f3e:	00 
    9f3f:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    9f46:	00 
    9f47:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    9f4e:	00 
    9f4f:	48 89 05 02 b5 01 00 	mov    %rax,0x1b502(%rip)        # 25458 <fwp_cleanups>
    9f56:	0f 29 b4 24 a0 00 00 	movaps %xmm6,0xa0(%rsp)
    9f5d:	00 
    9f5e:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    9f65:	00 
    9f66:	48 85 f6             	test   %rsi,%rsi
    9f69:	0f 88 61 0d 00 00    	js     acd0 <fwp_hof0.constprop.0+0x1430>
    9f6f:	48 89 f0             	mov    %rsi,%rax
    9f72:	48 c1 f8 20          	sar    $0x20,%rax
    9f76:	49 39 c7             	cmp    %rax,%r15
    9f79:	0f 85 fa 10 00 00    	jne    b079 <fwp_hof0.constprop.0+0x17d9>
    9f7f:	41 89 f2             	mov    %esi,%r10d
    9f82:	4d 89 d7             	mov    %r10,%r15
    9f85:	4c 39 d7             	cmp    %r10,%rdi
    9f88:	0f 8e df 10 00 00    	jle    b06d <fwp_hof0.constprop.0+0x17cd>
    9f8e:	4d 39 d6             	cmp    %r10,%r14
    9f91:	0f 8e f9 0b 00 00    	jle    ab90 <fwp_hof0.constprop.0+0x12f0>
    9f97:	49 39 d6             	cmp    %rdx,%r14
    9f9a:	0f 8f 40 0c 00 00    	jg     abe0 <fwp_hof0.constprop.0+0x1340>
    9fa0:	48 85 c9             	test   %rcx,%rcx
    9fa3:	0f 84 7a 11 00 00    	je     b123 <fwp_hof0.constprop.0+0x1883>
    9fa9:	48 89 cf             	mov    %rcx,%rdi
    9fac:	31 f6                	xor    %esi,%esi
    9fae:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    9fb3:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9fb7:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9fbe:	00 
    9fbf:	e8 dc 94 ff ff       	call   34a0 <memset@plt>
    9fc4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    9fc9:	45 31 db             	xor    %r11d,%r11d
    9fcc:	48 89 c1             	mov    %rax,%rcx
    9fcf:	f2 0f 10 05 49 5c 00 	movsd  0x5c49(%rip),%xmm0        # fc20 <msg.4+0xb0>
    9fd6:	00 
    9fd7:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    9fdd:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    9fe3:	bf 03 00 00 00       	mov    $0x3,%edi
    9fe8:	4c 01 35 01 91 01 00 	add    %r14,0x19101(%rip)        # 230f0 <descent_inputs>
    9fef:	4c 01 1d 02 91 01 00 	add    %r11,0x19102(%rip)        # 230f8 <descent_nodes>
    9ff6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9ffb:	e8 10 a2 ff ff       	call   4210 <descent_phase_step>
    a000:	4d 39 fe             	cmp    %r15,%r14
    a003:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a008:	7f 68                	jg     a072 <fwp_hof0.constprop.0+0x7d2>
    a00a:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a00f:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
    a013:	4d 29 f7             	sub    %r14,%r15
    a016:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a01a:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
    a01e:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    a022:	eb 08                	jmp    a02c <fwp_hof0.constprop.0+0x78c>
    a024:	0f 1f 40 00          	nopl   0x0(%rax)
    a028:	48 83 e8 18          	sub    $0x18,%rax
    a02c:	f2 0f 10 02          	movsd  (%rdx),%xmm0
    a030:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a034:	7a 02                	jp     a038 <fwp_hof0.constprop.0+0x798>
    a036:	74 31                	je     a069 <fwp_hof0.constprop.0+0x7c9>
    a038:	48 63 38             	movslq (%rax),%rdi
    a03b:	85 ff                	test   %edi,%edi
    a03d:	78 13                	js     a052 <fwp_hof0.constprop.0+0x7b2>
    a03f:	f2 0f 10 48 08       	movsd  0x8(%rax),%xmm1
    a044:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a048:	f2 0f 58 0c f9       	addsd  (%rcx,%rdi,8),%xmm1
    a04d:	f2 0f 11 0c f9       	movsd  %xmm1,(%rcx,%rdi,8)
    a052:	48 63 78 04          	movslq 0x4(%rax),%rdi
    a056:	85 ff                	test   %edi,%edi
    a058:	78 0f                	js     a069 <fwp_hof0.constprop.0+0x7c9>
    a05a:	f2 0f 59 40 10       	mulsd  0x10(%rax),%xmm0
    a05f:	f2 0f 58 04 f9       	addsd  (%rcx,%rdi,8),%xmm0
    a064:	f2 0f 11 04 f9       	movsd  %xmm0,(%rcx,%rdi,8)
    a069:	48 83 ea 08          	sub    $0x8,%rdx
    a06d:	48 39 c6             	cmp    %rax,%rsi
    a070:	75 b6                	jne    a028 <fwp_hof0.constprop.0+0x788>
    a072:	bf 04 00 00 00       	mov    $0x4,%edi
    a077:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a07c:	e8 8f a1 ff ff       	call   4210 <descent_phase_step>
    a081:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a088:	ff ff 1f 
    a08b:	4c 39 f0             	cmp    %r14,%rax
    a08e:	0f 82 1e 10 00 00    	jb     b0b2 <fwp_hof0.constprop.0+0x1812>
    a094:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a09b:	00 
    a09c:	be 02 00 00 00       	mov    $0x2,%esi
    a0a1:	e8 aa bb ff ff       	call   5c50 <fwp_heap_alloc>
    a0a6:	4d 85 f6             	test   %r14,%r14
    a0a9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a0ae:	4c 89 30             	mov    %r14,(%rax)
    a0b1:	49 89 c7             	mov    %rax,%r15
    a0b4:	74 1c                	je     a0d2 <fwp_hof0.constprop.0+0x832>
    a0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0bd:	00 00 00 
    a0c0:	48 8b 04 d9          	mov    (%rcx,%rbx,8),%rax
    a0c4:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    a0c9:	48 83 c3 01          	add    $0x1,%rbx
    a0cd:	49 39 de             	cmp    %rbx,%r14
    a0d0:	75 ee                	jne    a0c0 <fwp_hof0.constprop.0+0x820>
    a0d2:	bf 05 00 00 00       	mov    $0x5,%edi
    a0d7:	e8 34 a1 ff ff       	call   4210 <descent_phase_step>
    a0dc:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
    a0e3:	00 
    a0e4:	4c 89 e7             	mov    %r12,%rdi
    a0e7:	4c 89 35 6a b3 01 00 	mov    %r14,0x1b36a(%rip)        # 25458 <fwp_cleanups>
    a0ee:	e8 3d af ff ff       	call   5030 <fwp_tape_buffers_release>
    a0f3:	bf 06 00 00 00       	mov    $0x6,%edi
    a0f8:	e8 13 a1 ff ff       	call   4210 <descent_phase_step>
    a0fd:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a104:	4c 89 f8             	mov    %r15,%rax
    a107:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a10e:	48 c1 e2 10          	shl    $0x10,%rdx
    a112:	48 39 d0             	cmp    %rdx,%rax
    a115:	73 57                	jae    a16e <fwp_hof0.constprop.0+0x8ce>
    a117:	48 89 c2             	mov    %rax,%rdx
    a11a:	48 c1 ea 10          	shr    $0x10,%rdx
    a11e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a122:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a129:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a12d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a131:	48 85 ed             	test   %rbp,%rbp
    a134:	74 38                	je     a16e <fwp_hof0.constprop.0+0x8ce>
    a136:	0f b6 0a             	movzbl (%rdx),%ecx
    a139:	80 f9 02             	cmp    $0x2,%cl
    a13c:	0f 84 be 0b 00 00    	je     ad00 <fwp_hof0.constprop.0+0x1460>
    a142:	80 f9 01             	cmp    $0x1,%cl
    a145:	75 27                	jne    a16e <fwp_hof0.constprop.0+0x8ce>
    a147:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a14a:	0f b7 c0             	movzwl %ax,%eax
    a14d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a150:	48 0f af c1          	imul   %rcx,%rax
    a154:	48 c1 e8 20          	shr    $0x20,%rax
    a158:	48 39 d0             	cmp    %rdx,%rax
    a15b:	73 11                	jae    a16e <fwp_hof0.constprop.0+0x8ce>
    a15d:	48 01 c5             	add    %rax,%rbp
    a160:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a164:	0f 84 a9 0b 00 00    	je     ad13 <fwp_hof0.constprop.0+0x1473>
    a16a:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a16e:	4c 3b 74 24 38       	cmp    0x38(%rsp),%r14
    a173:	0f 85 92 95 ff ff    	jne    370b <fwp_hof0.constprop.0.cold>
    a179:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    a17e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a183:	48 89 05 ce b2 01 00 	mov    %rax,0x1b2ce(%rip)        # 25458 <fwp_cleanups>
    a18a:	e8 51 d0 ff ff       	call   71e0 <fwp_tape_scope_release>
    a18f:	49 8b 07             	mov    (%r15),%rax
    a192:	48 89 c3             	mov    %rax,%rbx
    a195:	48 0f ba f3 3f       	btr    $0x3f,%rbx
    a19a:	48 85 c0             	test   %rax,%rax
    a19d:	0f 88 2d 08 00 00    	js     a9d0 <fwp_hof0.constprop.0+0x1130>
    a1a3:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a1aa:	4c 89 f8             	mov    %r15,%rax
    a1ad:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a1b4:	48 c1 e2 10          	shl    $0x10,%rdx
    a1b8:	48 39 d0             	cmp    %rdx,%rax
    a1bb:	0f 83 0f 08 00 00    	jae    a9d0 <fwp_hof0.constprop.0+0x1130>
    a1c1:	48 89 c2             	mov    %rax,%rdx
    a1c4:	48 c1 ea 10          	shr    $0x10,%rdx
    a1c8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1cc:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a1d3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1d7:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a1db:	48 85 c9             	test   %rcx,%rcx
    a1de:	0f 84 ec 07 00 00    	je     a9d0 <fwp_hof0.constprop.0+0x1130>
    a1e4:	0f b6 32             	movzbl (%rdx),%esi
    a1e7:	40 80 fe 02          	cmp    $0x2,%sil
    a1eb:	0f 84 cf 07 00 00    	je     a9c0 <fwp_hof0.constprop.0+0x1120>
    a1f1:	40 80 fe 01          	cmp    $0x1,%sil
    a1f5:	0f 85 d5 07 00 00    	jne    a9d0 <fwp_hof0.constprop.0+0x1130>
    a1fb:	8b 72 18             	mov    0x18(%rdx),%esi
    a1fe:	0f b7 c0             	movzwl %ax,%eax
    a201:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a204:	48 0f af c6          	imul   %rsi,%rax
    a208:	48 c1 e8 20          	shr    $0x20,%rax
    a20c:	48 39 d0             	cmp    %rdx,%rax
    a20f:	0f 83 bb 07 00 00    	jae    a9d0 <fwp_hof0.constprop.0+0x1130>
    a215:	48 01 c1             	add    %rax,%rcx
    a218:	80 39 01             	cmpb   $0x1,(%rcx)
    a21b:	0f 85 af 07 00 00    	jne    a9d0 <fwp_hof0.constprop.0+0x1130>
    a221:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    a226:	4c 89 fd             	mov    %r15,%rbp
    a229:	31 ff                	xor    %edi,%edi
    a22b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a230:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a234:	31 c0                	xor    %eax,%eax
    a236:	48 85 db             	test   %rbx,%rbx
    a239:	75 2f                	jne    a26a <fwp_hof0.constprop.0+0x9ca>
    a23b:	eb 43                	jmp    a280 <fwp_hof0.constprop.0+0x9e0>
    a23d:	0f 1f 00             	nopl   (%rax)
    a240:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a245:	0f 88 3a 0e 00 00    	js     b085 <fwp_hof0.constprop.0+0x17e5>
    a24b:	f2 0f 10 05 4d 59 00 	movsd  0x594d(%rip),%xmm0        # fba0 <msg.4+0x30>
    a252:	00 
    a253:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a258:	48 83 c0 01          	add    $0x1,%rax
    a25c:	48 83 c2 08          	add    $0x8,%rdx
    a260:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a265:	48 39 c3             	cmp    %rax,%rbx
    a268:	74 16                	je     a280 <fwp_hof0.constprop.0+0x9e0>
    a26a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a26e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a272:	79 cc                	jns    a240 <fwp_hof0.constprop.0+0x9a0>
    a274:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a278:	eb c6                	jmp    a240 <fwp_hof0.constprop.0+0x9a0>
    a27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a280:	e8 6b de ff ff       	call   80f0 <fwp_drop10>
    a285:	48 8b 1c 24          	mov    (%rsp),%rbx
    a289:	31 d2                	xor    %edx,%edx
    a28b:	48 89 d8             	mov    %rbx,%rax
    a28e:	48 85 db             	test   %rbx,%rbx
    a291:	0f 84 08 0c 00 00    	je     ae9f <fwp_hof0.constprop.0+0x15ff>
    a297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a29e:	00 00 
    a2a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a2a4:	48 83 c2 01          	add    $0x1,%rdx
    a2a8:	48 85 c0             	test   %rax,%rax
    a2ab:	75 f3                	jne    a2a0 <fwp_hof0.constprop.0+0xa00>
    a2ad:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a2b1:	49 89 c6             	mov    %rax,%r14
    a2b4:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a2b9:	48 85 c0             	test   %rax,%rax
    a2bc:	0f 88 ba 05 00 00    	js     a87c <fwp_hof0.constprop.0+0xfdc>
    a2c2:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    a2c9:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a2ce:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    a2d5:	48 c1 e0 10          	shl    $0x10,%rax
    a2d9:	48 39 c6             	cmp    %rax,%rsi
    a2dc:	0f 83 9a 05 00 00    	jae    a87c <fwp_hof0.constprop.0+0xfdc>
    a2e2:	48 89 f0             	mov    %rsi,%rax
    a2e5:	48 c1 e8 10          	shr    $0x10,%rax
    a2e9:	48 8d 3c 80          	lea    (%rax,%rax,4),%rdi
    a2ed:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    a2f4:	48 8d 3c f8          	lea    (%rax,%rdi,8),%rdi
    a2f8:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    a2fc:	4d 85 c0             	test   %r8,%r8
    a2ff:	0f 84 77 05 00 00    	je     a87c <fwp_hof0.constprop.0+0xfdc>
    a305:	0f b6 07             	movzbl (%rdi),%eax
    a308:	3c 02                	cmp    $0x2,%al
    a30a:	0f 84 58 05 00 00    	je     a868 <fwp_hof0.constprop.0+0xfc8>
    a310:	3c 01                	cmp    $0x1,%al
    a312:	0f 85 59 05 00 00    	jne    a871 <fwp_hof0.constprop.0+0xfd1>
    a318:	8b 47 18             	mov    0x18(%rdi),%eax
    a31b:	0f b7 f6             	movzwl %si,%esi
    a31e:	48 0f af f0          	imul   %rax,%rsi
    a322:	8b 47 1c             	mov    0x1c(%rdi),%eax
    a325:	48 c1 ee 20          	shr    $0x20,%rsi
    a329:	48 39 c6             	cmp    %rax,%rsi
    a32c:	0f 83 3f 05 00 00    	jae    a871 <fwp_hof0.constprop.0+0xfd1>
    a332:	49 01 f0             	add    %rsi,%r8
    a335:	41 80 38 01          	cmpb   $0x1,(%r8)
    a339:	0f 85 32 05 00 00    	jne    a871 <fwp_hof0.constprop.0+0xfd1>
    a33f:	4c 39 f2             	cmp    %r14,%rdx
    a342:	4c 89 f0             	mov    %r14,%rax
    a345:	48 0f 46 c2          	cmovbe %rdx,%rax
    a349:	48 85 c0             	test   %rax,%rax
    a34c:	0f 84 3f 0d 00 00    	je     b091 <fwp_hof0.constprop.0+0x17f1>
    a352:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    a359:	00 
    a35a:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    a35e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    a363:	48 8b 0c 24          	mov    (%rsp),%rcx
    a367:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a36e:	00 
    a36f:	31 d2                	xor    %edx,%edx
    a371:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a375:	eb 25                	jmp    a39c <fwp_hof0.constprop.0+0xafc>
    a377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a37e:	00 00 
    a380:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a385:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a38a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a38f:	48 83 c2 08          	add    $0x8,%rdx
    a393:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a397:	49 39 d1             	cmp    %rdx,%r9
    a39a:	74 14                	je     a3b0 <fwp_hof0.constprop.0+0xb10>
    a39c:	48 89 fe             	mov    %rdi,%rsi
    a39f:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a3a4:	79 da                	jns    a380 <fwp_hof0.constprop.0+0xae0>
    a3a6:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a3aa:	eb d4                	jmp    a380 <fwp_hof0.constprop.0+0xae0>
    a3ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a3b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    a3b4:	48 85 c9             	test   %rcx,%rcx
    a3b7:	0f 84 a8 0c 00 00    	je     b065 <fwp_hof0.constprop.0+0x17c5>
    a3bd:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    a3c4:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    a3cb:	45 31 ff             	xor    %r15d,%r15d
    a3ce:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    a3d5:	49 c1 e1 10          	shl    $0x10,%r9
    a3d9:	eb 1b                	jmp    a3f6 <fwp_hof0.constprop.0+0xb56>
    a3db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a3e0:	49 83 c7 01          	add    $0x1,%r15
    a3e4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a3e8:	49 39 c7             	cmp    %rax,%r15
    a3eb:	0f 83 5f 01 00 00    	jae    a550 <fwp_hof0.constprop.0+0xcb0>
    a3f1:	48 85 c9             	test   %rcx,%rcx
    a3f4:	74 56                	je     a44c <fwp_hof0.constprop.0+0xbac>
    a3f6:	48 89 ca             	mov    %rcx,%rdx
    a3f9:	4c 29 d2             	sub    %r10,%rdx
    a3fc:	4c 39 ca             	cmp    %r9,%rdx
    a3ff:	73 4b                	jae    a44c <fwp_hof0.constprop.0+0xbac>
    a401:	48 89 d6             	mov    %rdx,%rsi
    a404:	48 c1 ee 10          	shr    $0x10,%rsi
    a408:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a40c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a410:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a414:	48 85 ff             	test   %rdi,%rdi
    a417:	74 33                	je     a44c <fwp_hof0.constprop.0+0xbac>
    a419:	44 0f b6 06          	movzbl (%rsi),%r8d
    a41d:	41 80 f8 02          	cmp    $0x2,%r8b
    a421:	0f 84 11 01 00 00    	je     a538 <fwp_hof0.constprop.0+0xc98>
    a427:	41 80 f8 01          	cmp    $0x1,%r8b
    a42b:	75 1f                	jne    a44c <fwp_hof0.constprop.0+0xbac>
    a42d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a431:	0f b7 d2             	movzwl %dx,%edx
    a434:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a437:	49 0f af d0          	imul   %r8,%rdx
    a43b:	48 c1 ea 20          	shr    $0x20,%rdx
    a43f:	48 39 f2             	cmp    %rsi,%rdx
    a442:	73 08                	jae    a44c <fwp_hof0.constprop.0+0xbac>
    a444:	48 01 d7             	add    %rdx,%rdi
    a447:	80 3f 01             	cmpb   $0x1,(%rdi)
    a44a:	74 94                	je     a3e0 <fwp_hof0.constprop.0+0xb40>
    a44c:	49 39 c7             	cmp    %rax,%r15
    a44f:	0f 83 fb 00 00 00    	jae    a550 <fwp_hof0.constprop.0+0xcb0>
    a455:	49 89 c6             	mov    %rax,%r14
    a458:	31 c9                	xor    %ecx,%ecx
    a45a:	48 8d ac 24 d0 00 00 	lea    0xd0(%rsp),%rbp
    a461:	00 
    a462:	eb 38                	jmp    a49c <fwp_hof0.constprop.0+0xbfc>
    a464:	0f 1f 40 00          	nopl   0x0(%rax)
    a468:	40 80 ff 01          	cmp    $0x1,%dil
    a46c:	75 25                	jne    a493 <fwp_hof0.constprop.0+0xbf3>
    a46e:	8b 7e 18             	mov    0x18(%rsi),%edi
    a471:	0f b7 c0             	movzwl %ax,%eax
    a474:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a477:	48 0f af c7          	imul   %rdi,%rax
    a47b:	48 c1 e8 20          	shr    $0x20,%rax
    a47f:	48 39 f0             	cmp    %rsi,%rax
    a482:	73 0f                	jae    a493 <fwp_hof0.constprop.0+0xbf3>
    a484:	48 01 c2             	add    %rax,%rdx
    a487:	80 3a ff             	cmpb   $0xff,(%rdx)
    a48a:	0f 84 f0 05 00 00    	je     aa80 <fwp_hof0.constprop.0+0x11e0>
    a490:	c6 02 01             	movb   $0x1,(%rdx)
    a493:	4d 39 f7             	cmp    %r14,%r15
    a496:	0f 83 84 00 00 00    	jae    a520 <fwp_hof0.constprop.0+0xc80>
    a49c:	49 83 ee 01          	sub    $0x1,%r14
    a4a0:	66 48 0f 6e e9       	movq   %rcx,%xmm5
    a4a5:	48 89 ee             	mov    %rbp,%rsi
    a4a8:	bf 01 00 00 00       	mov    $0x1,%edi
    a4ad:	f3 42 0f 7e 04 f3    	movq   (%rbx,%r14,8),%xmm0
    a4b3:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a4b7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    a4be:	00 
    a4bf:	e8 ac b8 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    a4c4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a4cb:	48 89 c1             	mov    %rax,%rcx
    a4ce:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a4d5:	48 c1 e2 10          	shl    $0x10,%rdx
    a4d9:	48 39 d0             	cmp    %rdx,%rax
    a4dc:	73 b5                	jae    a493 <fwp_hof0.constprop.0+0xbf3>
    a4de:	48 89 c2             	mov    %rax,%rdx
    a4e1:	48 c1 ea 10          	shr    $0x10,%rdx
    a4e5:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a4e9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a4f0:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    a4f4:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    a4f8:	48 85 d2             	test   %rdx,%rdx
    a4fb:	74 96                	je     a493 <fwp_hof0.constprop.0+0xbf3>
    a4fd:	0f b6 3e             	movzbl (%rsi),%edi
    a500:	40 80 ff 02          	cmp    $0x2,%dil
    a504:	0f 85 5e ff ff ff    	jne    a468 <fwp_hof0.constprop.0+0xbc8>
    a50a:	66 85 c0             	test   %ax,%ax
    a50d:	0f 84 74 ff ff ff    	je     a487 <fwp_hof0.constprop.0+0xbe7>
    a513:	4d 39 f7             	cmp    %r14,%r15
    a516:	72 84                	jb     a49c <fwp_hof0.constprop.0+0xbfc>
    a518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a51f:	00 
    a520:	4d 85 ff             	test   %r15,%r15
    a523:	75 2d                	jne    a552 <fwp_hof0.constprop.0+0xcb2>
    a525:	8b 44 24 10          	mov    0x10(%rsp),%eax
    a529:	85 c0                	test   %eax,%eax
    a52b:	49 0f 45 df          	cmovne %r15,%rbx
    a52f:	eb 60                	jmp    a591 <fwp_hof0.constprop.0+0xcf1>
    a531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a538:	66 85 d2             	test   %dx,%dx
    a53b:	0f 84 06 ff ff ff    	je     a447 <fwp_hof0.constprop.0+0xba7>
    a541:	49 39 c7             	cmp    %rax,%r15
    a544:	0f 82 0b ff ff ff    	jb     a455 <fwp_hof0.constprop.0+0xbb5>
    a54a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a550:	31 c9                	xor    %ecx,%ecx
    a552:	48 8b 04 24          	mov    (%rsp),%rax
    a556:	48 89 da             	mov    %rbx,%rdx
    a559:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a55d:	0f 1f 00             	nopl   (%rax)
    a560:	48 8b 32             	mov    (%rdx),%rsi
    a563:	48 83 c2 08          	add    $0x8,%rdx
    a567:	48 89 c7             	mov    %rax,%rdi
    a56a:	48 89 70 08          	mov    %rsi,0x8(%rax)
    a56e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a572:	4c 39 ca             	cmp    %r9,%rdx
    a575:	75 e9                	jne    a560 <fwp_hof0.constprop.0+0xcc0>
    a577:	8b 54 24 10          	mov    0x10(%rsp),%edx
    a57b:	48 89 4f 10          	mov    %rcx,0x10(%rdi)
    a57f:	85 d2                	test   %edx,%edx
    a581:	0f 84 99 07 00 00    	je     ad20 <fwp_hof0.constprop.0+0x1480>
    a587:	48 8b 0c 24          	mov    (%rsp),%rcx
    a58b:	48 89 04 24          	mov    %rax,(%rsp)
    a58f:	31 db                	xor    %ebx,%ebx
    a591:	48 89 df             	mov    %rbx,%rdi
    a594:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a599:	e8 b2 b1 ff ff       	call   5750 <fwp_mem_free>
    a59e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a5a3:	e8 48 db ff ff       	call   80f0 <fwp_drop10>
    a5a8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a5af:	48 8b 04 24          	mov    (%rsp),%rax
    a5b3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a5ba:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a5bf:	48 c1 e2 10          	shl    $0x10,%rdx
    a5c3:	48 39 d0             	cmp    %rdx,%rax
    a5c6:	73 7f                	jae    a647 <fwp_hof0.constprop.0+0xda7>
    a5c8:	49 89 ce             	mov    %rcx,%r14
    a5cb:	48 89 c2             	mov    %rax,%rdx
    a5ce:	49 8b bd f8 13 00 00 	mov    0x13f8(%r13),%rdi
    a5d5:	48 c1 ea 10          	shr    $0x10,%rdx
    a5d9:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a5dd:	48 8d 14 d7          	lea    (%rdi,%rdx,8),%rdx
    a5e1:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a5e5:	48 85 ed             	test   %rbp,%rbp
    a5e8:	0f 84 2b 03 00 00    	je     a919 <fwp_hof0.constprop.0+0x1079>
    a5ee:	0f b6 32             	movzbl (%rdx),%esi
    a5f1:	40 80 fe 02          	cmp    $0x2,%sil
    a5f5:	0f 84 15 03 00 00    	je     a910 <fwp_hof0.constprop.0+0x1070>
    a5fb:	40 80 fe 01          	cmp    $0x1,%sil
    a5ff:	0f 85 14 03 00 00    	jne    a919 <fwp_hof0.constprop.0+0x1079>
    a605:	8b 72 18             	mov    0x18(%rdx),%esi
    a608:	0f b7 c0             	movzwl %ax,%eax
    a60b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a60e:	48 0f af c6          	imul   %rsi,%rax
    a612:	48 c1 e8 20          	shr    $0x20,%rax
    a616:	48 39 d0             	cmp    %rdx,%rax
    a619:	0f 83 fa 02 00 00    	jae    a919 <fwp_hof0.constprop.0+0x1079>
    a61f:	48 01 c5             	add    %rax,%rbp
    a622:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a626:	84 c0                	test   %al,%al
    a628:	0f 84 eb 02 00 00    	je     a919 <fwp_hof0.constprop.0+0x1079>
    a62e:	3c 01                	cmp    $0x1,%al
    a630:	0f 84 fa 06 00 00    	je     ad30 <fwp_hof0.constprop.0+0x1490>
    a636:	4c 89 f1             	mov    %r14,%rcx
    a639:	3c ff                	cmp    $0xff,%al
    a63b:	0f 84 dd 08 00 00    	je     af1e <fwp_hof0.constprop.0+0x167e>
    a641:	83 e8 01             	sub    $0x1,%eax
    a644:	88 45 00             	mov    %al,0x0(%rbp)
    a647:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a64d:	0f 85 d5 02 00 00    	jne    a928 <fwp_hof0.constprop.0+0x1088>
    a653:	66 90                	xchg   %ax,%ax
    a655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a65c:	00 00 00 00 
    a660:	48 89 cd             	mov    %rcx,%rbp
    a663:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a667:	4c 89 e7             	mov    %r12,%rdi
    a66a:	b9 01 00 00 00       	mov    $0x1,%ecx
    a66f:	48 8d 15 2a 85 00 00 	lea    0x852a(%rip),%rdx        # 12ba0 <d0>
    a676:	48 89 ee             	mov    %rbp,%rsi
    a679:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    a680:	00 00 00 00 00 
    a685:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    a68c:	00 
    a68d:	e8 ce e1 ff ff       	call   8860 <fwp_write>
    a692:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    a699:	00 
    a69a:	4c 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%r15
    a6a1:	00 
    a6a2:	48 8d 05 e8 49 00 00 	lea    0x49e8(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a6a9:	48 85 c9             	test   %rcx,%rcx
    a6ac:	48 0f 44 c8          	cmove  %rax,%rcx
    a6b0:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a6b4:	0f 87 15 0a 00 00    	ja     b0cf <fwp_hof0.constprop.0+0x182f>
    a6ba:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a6be:	be 01 00 00 00       	mov    $0x1,%esi
    a6c3:	48 89 0c 24          	mov    %rcx,(%rsp)
    a6c7:	e8 84 b5 ff ff       	call   5c50 <fwp_heap_alloc>
    a6cc:	48 8b 34 24          	mov    (%rsp),%rsi
    a6d0:	4c 89 fa             	mov    %r15,%rdx
    a6d3:	4c 89 38             	mov    %r15,(%rax)
    a6d6:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a6da:	48 89 c3             	mov    %rax,%rbx
    a6dd:	4c 89 f7             	mov    %r14,%rdi
    a6e0:	e8 8b 8e ff ff       	call   3570 <memcpy@plt>
    a6e5:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a6eb:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    a6f2:	00 
    a6f3:	e8 a8 8c ff ff       	call   33a0 <free@plt>
    a6f8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a6ff:	48 89 d8             	mov    %rbx,%rax
    a702:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a709:	48 c1 e2 10          	shl    $0x10,%rdx
    a70d:	48 39 d0             	cmp    %rdx,%rax
    a710:	73 57                	jae    a769 <fwp_hof0.constprop.0+0xec9>
    a712:	48 89 c2             	mov    %rax,%rdx
    a715:	48 c1 ea 10          	shr    $0x10,%rdx
    a719:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a71d:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a724:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a728:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a72c:	4d 85 ff             	test   %r15,%r15
    a72f:	74 38                	je     a769 <fwp_hof0.constprop.0+0xec9>
    a731:	0f b6 0a             	movzbl (%rdx),%ecx
    a734:	80 f9 02             	cmp    $0x2,%cl
    a737:	0f 84 f3 06 00 00    	je     ae30 <fwp_hof0.constprop.0+0x1590>
    a73d:	80 f9 01             	cmp    $0x1,%cl
    a740:	75 27                	jne    a769 <fwp_hof0.constprop.0+0xec9>
    a742:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a745:	0f b7 c0             	movzwl %ax,%eax
    a748:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a74b:	48 0f af c1          	imul   %rcx,%rax
    a74f:	48 c1 e8 20          	shr    $0x20,%rax
    a753:	48 39 d0             	cmp    %rdx,%rax
    a756:	73 11                	jae    a769 <fwp_hof0.constprop.0+0xec9>
    a758:	49 01 c7             	add    %rax,%r15
    a75b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a75f:	0f 84 de 06 00 00    	je     ae43 <fwp_hof0.constprop.0+0x15a3>
    a765:	41 c6 07 01          	movb   $0x1,(%r15)
    a769:	48 89 ef             	mov    %rbp,%rdi
    a76c:	e8 8f d5 ff ff       	call   7d00 <fwp_drop0>
    a771:	48 8b 13             	mov    (%rbx),%rdx
    a774:	be 01 00 00 00       	mov    $0x1,%esi
    a779:	4c 89 f7             	mov    %r14,%rdi
    a77c:	48 8b 0d 9d ac 01 00 	mov    0x1ac9d(%rip),%rcx        # 25420 <fwp_prog_out>
    a783:	e8 b8 8e ff ff       	call   3640 <fwrite@plt>
    a788:	48 8b 35 91 ac 01 00 	mov    0x1ac91(%rip),%rsi        # 25420 <fwp_prog_out>
    a78f:	bf 0a 00 00 00       	mov    $0xa,%edi
    a794:	e8 27 8d ff ff       	call   34c0 <fputc@plt>
    a799:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a7a0:	48 89 d8             	mov    %rbx,%rax
    a7a3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a7aa:	48 c1 e2 10          	shl    $0x10,%rdx
    a7ae:	48 39 d0             	cmp    %rdx,%rax
    a7b1:	73 6d                	jae    a820 <fwp_hof0.constprop.0+0xf80>
    a7b3:	48 89 c2             	mov    %rax,%rdx
    a7b6:	48 c1 ea 10          	shr    $0x10,%rdx
    a7ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7be:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a7c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a7c9:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a7cd:	48 85 ed             	test   %rbp,%rbp
    a7d0:	74 4e                	je     a820 <fwp_hof0.constprop.0+0xf80>
    a7d2:	0f b6 0a             	movzbl (%rdx),%ecx
    a7d5:	80 f9 02             	cmp    $0x2,%cl
    a7d8:	0f 84 72 06 00 00    	je     ae50 <fwp_hof0.constprop.0+0x15b0>
    a7de:	80 f9 01             	cmp    $0x1,%cl
    a7e1:	75 3d                	jne    a820 <fwp_hof0.constprop.0+0xf80>
    a7e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a7e6:	0f b7 c0             	movzwl %ax,%eax
    a7e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a7ec:	48 0f af c1          	imul   %rcx,%rax
    a7f0:	48 c1 e8 20          	shr    $0x20,%rax
    a7f4:	48 39 d0             	cmp    %rdx,%rax
    a7f7:	73 27                	jae    a820 <fwp_hof0.constprop.0+0xf80>
    a7f9:	48 01 c5             	add    %rax,%rbp
    a7fc:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a800:	84 c0                	test   %al,%al
    a802:	74 1c                	je     a820 <fwp_hof0.constprop.0+0xf80>
    a804:	3c 01                	cmp    $0x1,%al
    a806:	0f 84 61 06 00 00    	je     ae6d <fwp_hof0.constprop.0+0x15cd>
    a80c:	3c ff                	cmp    $0xff,%al
    a80e:	0f 84 99 07 00 00    	je     afad <fwp_hof0.constprop.0+0x170d>
    a814:	83 e8 01             	sub    $0x1,%eax
    a817:	88 45 00             	mov    %al,0x0(%rbp)
    a81a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a820:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a825:	48 8b 40 10          	mov    0x10(%rax),%rax
    a829:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a82e:	48 85 c0             	test   %rax,%rax
    a831:	0f 85 a9 f0 ff ff    	jne    98e0 <fwp_hof0.constprop.0+0x40>
    a837:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    a83e:	00 
    a83f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a846:	00 00 
    a848:	0f 85 7c 08 00 00    	jne    b0ca <fwp_hof0.constprop.0+0x182a>
    a84e:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    a855:	31 c0                	xor    %eax,%eax
    a857:	5b                   	pop    %rbx
    a858:	5d                   	pop    %rbp
    a859:	41 5c                	pop    %r12
    a85b:	41 5d                	pop    %r13
    a85d:	41 5e                	pop    %r14
    a85f:	41 5f                	pop    %r15
    a861:	c3                   	ret
    a862:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a868:	66 85 f6             	test   %si,%si
    a86b:	0f 84 c4 fa ff ff    	je     a335 <fwp_hof0.constprop.0+0xa95>
    a871:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    a876:	0f 84 bb 02 00 00    	je     ab37 <fwp_hof0.constprop.0+0x1297>
    a87c:	48 8b 04 24          	mov    (%rsp),%rax
    a880:	45 31 ff             	xor    %r15d,%r15d
    a883:	66 90                	xchg   %ax,%ax
    a885:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a88c:	00 00 00 00 
    a890:	48 8b 40 10          	mov    0x10(%rax),%rax
    a894:	4c 89 fa             	mov    %r15,%rdx
    a897:	49 83 c7 01          	add    $0x1,%r15
    a89b:	48 85 c0             	test   %rax,%rax
    a89e:	75 f0                	jne    a890 <fwp_hof0.constprop.0+0xff0>
    a8a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a8a7:	ff ff 1f 
    a8aa:	4c 39 f8             	cmp    %r15,%rax
    a8ad:	0f 82 e7 07 00 00    	jb     b09a <fwp_hof0.constprop.0+0x17fa>
    a8b3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a8ba:	00 
    a8bb:	be 02 00 00 00       	mov    $0x2,%esi
    a8c0:	e8 8b b3 ff ff       	call   5c50 <fwp_heap_alloc>
    a8c5:	4d 39 fe             	cmp    %r15,%r14
    a8c8:	48 8b 14 24          	mov    (%rsp),%rdx
    a8cc:	48 89 c3             	mov    %rax,%rbx
    a8cf:	4c 89 f8             	mov    %r15,%rax
    a8d2:	49 0f 46 c6          	cmovbe %r14,%rax
    a8d6:	48 89 d9             	mov    %rbx,%rcx
    a8d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8e0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a8e4:	48 83 c1 08          	add    $0x8,%rcx
    a8e8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a8ec:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a8f0:	48 85 d2             	test   %rdx,%rdx
    a8f3:	75 eb                	jne    a8e0 <fwp_hof0.constprop.0+0x1040>
    a8f5:	48 85 c0             	test   %rax,%rax
    a8f8:	0f 84 4b 02 00 00    	je     ab49 <fwp_hof0.constprop.0+0x12a9>
    a8fe:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a905:	00 
    a906:	e9 53 fa ff ff       	jmp    a35e <fwp_hof0.constprop.0+0xabe>
    a90b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a910:	66 85 c0             	test   %ax,%ax
    a913:	0f 84 09 fd ff ff    	je     a622 <fwp_hof0.constprop.0+0xd82>
    a919:	4c 89 f1             	mov    %r14,%rcx
    a91c:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a922:	0f 84 38 fd ff ff    	je     a660 <fwp_hof0.constprop.0+0xdc0>
    a928:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a92d:	45 31 c0             	xor    %r8d,%r8d
    a930:	48 89 0c 24          	mov    %rcx,(%rsp)
    a934:	48 83 e8 01          	sub    $0x1,%rax
    a938:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a93d:	41 0f 90 c0          	seto   %r8b
    a941:	e9 28 f0 ff ff       	jmp    996e <fwp_hof0.constprop.0+0xce>
    a946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a94d:	00 00 00 
    a950:	48 83 3d 30 87 01 00 	cmpq   $0x0,0x18730(%rip)        # 23088 <fwp_tape_cached_bytes>
    a957:	00 
    a958:	0f 84 62 f2 ff ff    	je     9bc0 <fwp_hof0.constprop.0+0x320>
    a95e:	48 8b 05 4b 87 01 00 	mov    0x1874b(%rip),%rax        # 230b0 <fwp_tape_workspace+0x10>
    a965:	66 0f 6f 0d 33 87 01 	movdqa 0x18733(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a96c:	00 
    a96d:	48 c7 05 10 87 01 00 	movq   $0x0,0x18710(%rip)        # 23088 <fwp_tape_cached_bytes>
    a974:	00 00 00 00 
    a978:	48 89 41 30          	mov    %rax,0x30(%rcx)
    a97c:	48 8b 05 35 87 01 00 	mov    0x18735(%rip),%rax        # 230b8 <fwp_tape_workspace+0x18>
    a983:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a987:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a98b:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a98f:	48 8b 05 2a 87 01 00 	mov    0x1872a(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a996:	0f 29 0d 03 87 01 00 	movaps %xmm1,0x18703(%rip)        # 230a0 <fwp_tape_workspace>
    a99d:	48 89 41 38          	mov    %rax,0x38(%rcx)
    a9a1:	0f 29 0d 08 87 01 00 	movaps %xmm1,0x18708(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a9a8:	48 c7 05 0d 87 01 00 	movq   $0x0,0x1870d(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a9af:	00 00 00 00 
    a9b3:	e9 08 f2 ff ff       	jmp    9bc0 <fwp_hof0.constprop.0+0x320>
    a9b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a9bf:	00 
    a9c0:	66 85 c0             	test   %ax,%ax
    a9c3:	0f 84 4f f8 ff ff    	je     a218 <fwp_hof0.constprop.0+0x978>
    a9c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9d0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a9d7:	ff ff 1f 
    a9da:	48 39 d8             	cmp    %rbx,%rax
    a9dd:	0f 82 cf 06 00 00    	jb     b0b2 <fwp_hof0.constprop.0+0x1812>
    a9e3:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    a9ea:	00 
    a9eb:	be 01 00 00 00       	mov    $0x1,%esi
    a9f0:	e8 5b b2 ff ff       	call   5c50 <fwp_heap_alloc>
    a9f5:	48 89 18             	mov    %rbx,(%rax)
    a9f8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a9ff:	48 89 c5             	mov    %rax,%rbp
    aa02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aa07:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    aa0e:	48 c1 e2 10          	shl    $0x10,%rdx
    aa12:	48 39 d0             	cmp    %rdx,%rax
    aa15:	73 59                	jae    aa70 <fwp_hof0.constprop.0+0x11d0>
    aa17:	48 89 c2             	mov    %rax,%rdx
    aa1a:	48 c1 ea 10          	shr    $0x10,%rdx
    aa1e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa22:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    aa29:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    aa2d:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    aa31:	4d 85 f6             	test   %r14,%r14
    aa34:	74 3a                	je     aa70 <fwp_hof0.constprop.0+0x11d0>
    aa36:	0f b6 31             	movzbl (%rcx),%esi
    aa39:	40 80 fe 02          	cmp    $0x2,%sil
    aa3d:	0f 84 95 03 00 00    	je     add8 <fwp_hof0.constprop.0+0x1538>
    aa43:	40 80 fe 01          	cmp    $0x1,%sil
    aa47:	75 27                	jne    aa70 <fwp_hof0.constprop.0+0x11d0>
    aa49:	8b 71 18             	mov    0x18(%rcx),%esi
    aa4c:	0f b7 c0             	movzwl %ax,%eax
    aa4f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa52:	48 0f af c6          	imul   %rsi,%rax
    aa56:	48 c1 e8 20          	shr    $0x20,%rax
    aa5a:	48 39 c8             	cmp    %rcx,%rax
    aa5d:	73 11                	jae    aa70 <fwp_hof0.constprop.0+0x11d0>
    aa5f:	49 01 c6             	add    %rax,%r14
    aa62:	41 80 3e ff          	cmpb   $0xff,(%r14)
    aa66:	0f 84 7f 03 00 00    	je     adeb <fwp_hof0.constprop.0+0x154b>
    aa6c:	41 c6 06 01          	movb   $0x1,(%r14)
    aa70:	4c 89 ff             	mov    %r15,%rdi
    aa73:	e9 b3 f7 ff ff       	jmp    a22b <fwp_hof0.constprop.0+0x98b>
    aa78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa7f:	00 
    aa80:	48 89 d7             	mov    %rdx,%rdi
    aa83:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    aa88:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    aa8d:	e8 7e aa ff ff       	call   5510 <fwp_rc_forget_slot>
    aa92:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    aa97:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    aa9c:	e9 ef f9 ff ff       	jmp    a490 <fwp_hof0.constprop.0+0xbf0>
    aaa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aaa8:	48 c1 e2 10          	shl    $0x10,%rdx
    aaac:	be 02 00 00 00       	mov    $0x2,%esi
    aab1:	bf 08 00 00 00       	mov    $0x8,%edi
    aab6:	48 09 ea             	or     %rbp,%rdx
    aab9:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    aabe:	e8 8d b1 ff ff       	call   5c50 <fwp_heap_alloc>
    aac3:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    aaca:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    aad1:	48 89 c5             	mov    %rax,%rbp
    aad4:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    aadb:	48 c1 e2 10          	shl    $0x10,%rdx
    aadf:	48 39 d0             	cmp    %rdx,%rax
    aae2:	73 7c                	jae    ab60 <fwp_hof0.constprop.0+0x12c0>
    aae4:	48 89 c2             	mov    %rax,%rdx
    aae7:	48 c1 ea 10          	shr    $0x10,%rdx
    aaeb:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    aaef:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    aaf6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    aafa:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    aafe:	4d 85 f6             	test   %r14,%r14
    ab01:	0f 84 ac f2 ff ff    	je     9db3 <fwp_hof0.constprop.0+0x513>
    ab07:	0f b6 32             	movzbl (%rdx),%esi
    ab0a:	45 31 e4             	xor    %r12d,%r12d
    ab0d:	40 80 fe 02          	cmp    $0x2,%sil
    ab11:	0f 85 15 f2 ff ff    	jne    9d2c <fwp_hof0.constprop.0+0x48c>
    ab17:	66 85 c0             	test   %ax,%ax
    ab1a:	0f 85 39 f2 ff ff    	jne    9d59 <fwp_hof0.constprop.0+0x4b9>
    ab20:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ab24:	0f 85 2b f2 ff ff    	jne    9d55 <fwp_hof0.constprop.0+0x4b5>
    ab2a:	4c 89 f7             	mov    %r14,%rdi
    ab2d:	e8 de a9 ff ff       	call   5510 <fwp_rc_forget_slot>
    ab32:	e9 1e f2 ff ff       	jmp    9d55 <fwp_hof0.constprop.0+0x4b5>
    ab37:	be 02 00 00 00       	mov    $0x2,%esi
    ab3c:	bf 08 00 00 00       	mov    $0x8,%edi
    ab41:	e8 0a b1 ff ff       	call   5c50 <fwp_heap_alloc>
    ab46:	48 89 c3             	mov    %rax,%rbx
    ab49:	31 c9                	xor    %ecx,%ecx
    ab4b:	e9 41 fa ff ff       	jmp    a591 <fwp_hof0.constprop.0+0xcf1>
    ab50:	4d 85 e4             	test   %r12,%r12
    ab53:	0f 85 05 f2 ff ff    	jne    9d5e <fwp_hof0.constprop.0+0x4be>
    ab59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab60:	31 d2                	xor    %edx,%edx
    ab62:	e9 e4 f2 ff ff       	jmp    9e4b <fwp_hof0.constprop.0+0x5ab>
    ab67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab6e:	00 00 
    ab70:	49 39 d4             	cmp    %rdx,%r12
    ab73:	0f 84 57 ef ff ff    	je     9ad0 <fwp_hof0.constprop.0+0x230>
    ab79:	4c 8b 3d 60 85 01 00 	mov    0x18560(%rip),%r15        # 230e0 <fwp_tapes>
    ab80:	49 89 d4             	mov    %rdx,%r12
    ab83:	48 8d 6a 01          	lea    0x1(%rdx),%rbp
    ab87:	e9 e4 ef ff ff       	jmp    9b70 <fwp_hof0.constprop.0+0x2d0>
    ab8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab90:	49 8d 6a 01          	lea    0x1(%r10),%rbp
    ab94:	48 39 ea             	cmp    %rbp,%rdx
    ab97:	7c 4a                	jl     abe3 <fwp_hof0.constprop.0+0x1343>
    ab99:	48 85 c9             	test   %rcx,%rcx
    ab9c:	0f 84 81 05 00 00    	je     b123 <fwp_hof0.constprop.0+0x1883>
    aba2:	49 89 eb             	mov    %rbp,%r11
    aba5:	48 89 cf             	mov    %rcx,%rdi
    aba8:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    abaf:	00 
    abb0:	31 f6                	xor    %esi,%esi
    abb2:	4d 29 f3             	sub    %r14,%r11
    abb5:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    abba:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    abbf:	e8 dc 88 ff ff       	call   34a0 <memset@plt>
    abc4:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    abc9:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    abce:	48 89 c1             	mov    %rax,%rcx
    abd1:	e9 f9 f3 ff ff       	jmp    9fcf <fwp_hof0.constprop.0+0x72f>
    abd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    abdd:	00 00 00 
    abe0:	4c 89 f5             	mov    %r14,%rbp
    abe3:	48 85 d2             	test   %rdx,%rdx
    abe6:	48 0f 44 d5          	cmove  %rbp,%rdx
    abea:	eb 29                	jmp    ac15 <fwp_hof0.constprop.0+0x1375>
    abec:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    abf3:	00 00 
    abf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    abfc:	00 00 00 00 
    ac00:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    ac04:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    ac0b:	48 89 e8             	mov    %rbp,%rax
    ac0e:	48 0f 4c c6          	cmovl  %rsi,%rax
    ac12:	48 89 c2             	mov    %rax,%rdx
    ac15:	48 39 ea             	cmp    %rbp,%rdx
    ac18:	7c e6                	jl     ac00 <fwp_hof0.constprop.0+0x1360>
    ac1a:	48 85 c9             	test   %rcx,%rcx
    ac1d:	0f 84 dd 01 00 00    	je     ae00 <fwp_hof0.constprop.0+0x1560>
    ac23:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    ac2a:	00 
    ac2b:	48 89 cf             	mov    %rcx,%rdi
    ac2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    ac33:	e8 68 89 ff ff       	call   35a0 <realloc@plt>
    ac38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    ac3d:	48 89 c1             	mov    %rax,%rcx
    ac40:	48 85 c9             	test   %rcx,%rcx
    ac43:	0f 84 d1 04 00 00    	je     b11a <fwp_hof0.constprop.0+0x187a>
    ac49:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    ac50:	00 
    ac51:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
    ac58:	00 
    ac59:	48 85 ed             	test   %rbp,%rbp
    ac5c:	0f 85 7e 03 00 00    	jne    afe0 <fwp_hof0.constprop.0+0x1740>
    ac62:	4d 89 f3             	mov    %r14,%r11
    ac65:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ac6c:	49 f7 db             	neg    %r11
    ac6f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ac74:	48 85 c0             	test   %rax,%rax
    ac77:	0f 88 66 f3 ff ff    	js     9fe3 <fwp_hof0.constprop.0+0x743>
    ac7d:	41 89 c2             	mov    %eax,%r10d
    ac80:	e9 4a f3 ff ff       	jmp    9fcf <fwp_hof0.constprop.0+0x72f>
    ac85:	0f 1f 00             	nopl   (%rax)
    ac88:	48 8d 3d 71 c4 ff ff 	lea    -0x3b8f(%rip),%rdi        # 7100 <fwp_tape_finish>
    ac8f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    ac95:	e8 66 3b 00 00       	call   e800 <atexit>
    ac9a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    aca0:	85 c0                	test   %eax,%eax
    aca2:	0f 85 c0 04 00 00    	jne    b168 <fwp_hof0.constprop.0+0x18c8>
    aca8:	c7 05 ae 83 00 00 01 	movl   $0x1,0x83ae(%rip)        # 13060 <registered_finish.1>
    acaf:	00 00 00 
    acb2:	e9 cd ed ff ff       	jmp    9a84 <fwp_hof0.constprop.0+0x1e4>
    acb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acbe:	00 00 
    acc0:	66 85 c0             	test   %ax,%ax
    acc3:	0f 85 6c ed ff ff    	jne    9a35 <fwp_hof0.constprop.0+0x195>
    acc9:	e9 53 ed ff ff       	jmp    9a21 <fwp_hof0.constprop.0+0x181>
    acce:	66 90                	xchg   %ax,%ax
    acd0:	49 39 d6             	cmp    %rdx,%r14
    acd3:	0f 8f 07 ff ff ff    	jg     abe0 <fwp_hof0.constprop.0+0x1340>
    acd9:	48 85 c9             	test   %rcx,%rcx
    acdc:	0f 84 1a 02 00 00    	je     aefc <fwp_hof0.constprop.0+0x165c>
    ace2:	4d 85 f6             	test   %r14,%r14
    ace5:	0f 85 f2 02 00 00    	jne    afdd <fwp_hof0.constprop.0+0x173d>
    aceb:	45 31 db             	xor    %r11d,%r11d
    acee:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    acf5:	e9 e9 f2 ff ff       	jmp    9fe3 <fwp_hof0.constprop.0+0x743>
    acfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad00:	66 85 c0             	test   %ax,%ax
    ad03:	0f 85 65 f4 ff ff    	jne    a16e <fwp_hof0.constprop.0+0x8ce>
    ad09:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    ad0d:	0f 85 57 f4 ff ff    	jne    a16a <fwp_hof0.constprop.0+0x8ca>
    ad13:	48 89 ef             	mov    %rbp,%rdi
    ad16:	e8 f5 a7 ff ff       	call   5510 <fwp_rc_forget_slot>
    ad1b:	e9 4a f4 ff ff       	jmp    a16a <fwp_hof0.constprop.0+0x8ca>
    ad20:	48 8b 0c 24          	mov    (%rsp),%rcx
    ad24:	48 89 04 24          	mov    %rax,(%rsp)
    ad28:	e9 64 f8 ff ff       	jmp    a591 <fwp_hof0.constprop.0+0xcf1>
    ad2d:	0f 1f 00             	nopl   (%rax)
    ad30:	48 8b 04 24          	mov    (%rsp),%rax
    ad34:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    ad3b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    ad42:	48 8b 58 10          	mov    0x10(%rax),%rbx
    ad46:	48 29 f0             	sub    %rsi,%rax
    ad49:	48 c1 e2 10          	shl    $0x10,%rdx
    ad4d:	48 39 d0             	cmp    %rdx,%rax
    ad50:	73 67                	jae    adb9 <fwp_hof0.constprop.0+0x1519>
    ad52:	49 89 c0             	mov    %rax,%r8
    ad55:	49 c1 e8 10          	shr    $0x10,%r8
    ad59:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    ad5d:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    ad61:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    ad65:	4d 85 c0             	test   %r8,%r8
    ad68:	74 4f                	je     adb9 <fwp_hof0.constprop.0+0x1519>
    ad6a:	44 0f b6 0f          	movzbl (%rdi),%r9d
    ad6e:	41 80 f9 02          	cmp    $0x2,%r9b
    ad72:	0f 84 98 01 00 00    	je     af10 <fwp_hof0.constprop.0+0x1670>
    ad78:	41 80 f9 01          	cmp    $0x1,%r9b
    ad7c:	75 3b                	jne    adb9 <fwp_hof0.constprop.0+0x1519>
    ad7e:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    ad82:	0f b7 c0             	movzwl %ax,%eax
    ad85:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    ad88:	49 0f af c1          	imul   %r9,%rax
    ad8c:	48 c1 e8 20          	shr    $0x20,%rax
    ad90:	48 39 f8             	cmp    %rdi,%rax
    ad93:	73 24                	jae    adb9 <fwp_hof0.constprop.0+0x1519>
    ad95:	49 01 c0             	add    %rax,%r8
    ad98:	41 80 38 01          	cmpb   $0x1,(%r8)
    ad9c:	75 1b                	jne    adb9 <fwp_hof0.constprop.0+0x1519>
    ad9e:	48 8b 3c 24          	mov    (%rsp),%rdi
    ada2:	e8 a9 a9 ff ff       	call   5750 <fwp_mem_free>
    ada7:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    adae:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    adb5:	48 c1 e2 10          	shl    $0x10,%rdx
    adb9:	48 89 d8             	mov    %rbx,%rax
    adbc:	48 29 f0             	sub    %rsi,%rax
    adbf:	48 39 d0             	cmp    %rdx,%rax
    adc2:	0f 83 51 fb ff ff    	jae    a919 <fwp_hof0.constprop.0+0x1079>
    adc8:	48 89 1c 24          	mov    %rbx,(%rsp)
    adcc:	e9 fa f7 ff ff       	jmp    a5cb <fwp_hof0.constprop.0+0xd2b>
    add1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    add8:	66 85 c0             	test   %ax,%ax
    addb:	0f 85 8f fc ff ff    	jne    aa70 <fwp_hof0.constprop.0+0x11d0>
    ade1:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ade5:	0f 85 81 fc ff ff    	jne    aa6c <fwp_hof0.constprop.0+0x11cc>
    adeb:	4c 89 f7             	mov    %r14,%rdi
    adee:	e8 1d a7 ff ff       	call   5510 <fwp_rc_forget_slot>
    adf3:	e9 74 fc ff ff       	jmp    aa6c <fwp_hof0.constprop.0+0x11cc>
    adf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    adff:	00 
    ae00:	48 89 d7             	mov    %rdx,%rdi
    ae03:	be 08 00 00 00       	mov    $0x8,%esi
    ae08:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    ae0d:	e8 ee 86 ff ff       	call   3500 <calloc@plt>
    ae12:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    ae17:	48 89 c1             	mov    %rax,%rcx
    ae1a:	e9 21 fe ff ff       	jmp    ac40 <fwp_hof0.constprop.0+0x13a0>
    ae1f:	90                   	nop
    ae20:	66 85 c0             	test   %ax,%ax
    ae23:	0f 85 30 eb ff ff    	jne    9959 <fwp_hof0.constprop.0+0xb9>
    ae29:	e9 17 eb ff ff       	jmp    9945 <fwp_hof0.constprop.0+0xa5>
    ae2e:	66 90                	xchg   %ax,%ax
    ae30:	66 85 c0             	test   %ax,%ax
    ae33:	0f 85 30 f9 ff ff    	jne    a769 <fwp_hof0.constprop.0+0xec9>
    ae39:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ae3d:	0f 85 22 f9 ff ff    	jne    a765 <fwp_hof0.constprop.0+0xec5>
    ae43:	4c 89 ff             	mov    %r15,%rdi
    ae46:	e8 c5 a6 ff ff       	call   5510 <fwp_rc_forget_slot>
    ae4b:	e9 15 f9 ff ff       	jmp    a765 <fwp_hof0.constprop.0+0xec5>
    ae50:	66 85 c0             	test   %ax,%ax
    ae53:	0f 85 c7 f9 ff ff    	jne    a820 <fwp_hof0.constprop.0+0xf80>
    ae59:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    ae5d:	84 c0                	test   %al,%al
    ae5f:	0f 84 bb f9 ff ff    	je     a820 <fwp_hof0.constprop.0+0xf80>
    ae65:	3c 01                	cmp    $0x1,%al
    ae67:	0f 85 9f f9 ff ff    	jne    a80c <fwp_hof0.constprop.0+0xf6c>
    ae6d:	48 89 df             	mov    %rbx,%rdi
    ae70:	e8 db a8 ff ff       	call   5750 <fwp_mem_free>
    ae75:	e9 a6 f9 ff ff       	jmp    a820 <fwp_hof0.constprop.0+0xf80>
    ae7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae80:	be 58 00 00 00       	mov    $0x58,%esi
    ae85:	bd 01 00 00 00       	mov    $0x1,%ebp
    ae8a:	e9 7b ec ff ff       	jmp    9b0a <fwp_hof0.constprop.0+0x26a>
    ae8f:	31 ff                	xor    %edi,%edi
    ae91:	e8 7a 93 ff ff       	call   4210 <descent_phase_step>
    ae96:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ae9a:	e9 d7 eb ff ff       	jmp    9a76 <fwp_hof0.constprop.0+0x1d6>
    ae9f:	48 8b 45 00          	mov    0x0(%rbp),%rax
    aea3:	48 85 c0             	test   %rax,%rax
    aea6:	0f 88 8b fc ff ff    	js     ab37 <fwp_hof0.constprop.0+0x1297>
    aeac:	49 8b bd d8 13 00 00 	mov    0x13d8(%r13),%rdi
    aeb3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    aeb8:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    aebf:	48 c1 e7 10          	shl    $0x10,%rdi
    aec3:	48 39 fe             	cmp    %rdi,%rsi
    aec6:	0f 83 6b fc ff ff    	jae    ab37 <fwp_hof0.constprop.0+0x1297>
    aecc:	48 89 f1             	mov    %rsi,%rcx
    aecf:	48 c1 e9 10          	shr    $0x10,%rcx
    aed3:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    aed7:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    aede:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    aee2:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    aee6:	4d 85 c0             	test   %r8,%r8
    aee9:	0f 84 48 fc ff ff    	je     ab37 <fwp_hof0.constprop.0+0x1297>
    aeef:	48 0f ba f0 3f       	btr    $0x3f,%rax
    aef4:	49 89 c6             	mov    %rax,%r14
    aef7:	e9 09 f4 ff ff       	jmp    a305 <fwp_hof0.constprop.0+0xa65>
    aefc:	4d 85 f6             	test   %r14,%r14
    aeff:	0f 84 e6 fd ff ff    	je     aceb <fwp_hof0.constprop.0+0x144b>
    af05:	e9 19 02 00 00       	jmp    b123 <fwp_hof0.constprop.0+0x1883>
    af0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af10:	66 85 c0             	test   %ax,%ax
    af13:	0f 85 a0 fe ff ff    	jne    adb9 <fwp_hof0.constprop.0+0x1519>
    af19:	e9 7a fe ff ff       	jmp    ad98 <fwp_hof0.constprop.0+0x14f8>
    af1e:	48 89 ea             	mov    %rbp,%rdx
    af21:	48 c1 ea 11          	shr    $0x11,%rdx
    af25:	48 31 ea             	xor    %rbp,%rdx
    af28:	48 89 d0             	mov    %rdx,%rax
    af2b:	48 c1 e8 09          	shr    $0x9,%rax
    af2f:	48 31 c2             	xor    %rax,%rdx
    af32:	0f b6 d2             	movzbl %dl,%edx
    af35:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    af3c:	00 
    af3d:	48 85 c0             	test   %rax,%rax
    af40:	75 27                	jne    af69 <fwp_hof0.constprop.0+0x16c9>
    af42:	e9 8a 00 00 00       	jmp    afd1 <fwp_hof0.constprop.0+0x1731>
    af47:	0f 1f 00             	nopl   (%rax)
    af4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af51:	00 00 00 00 
    af55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af5c:	00 00 00 00 
    af60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    af64:	48 85 c0             	test   %rax,%rax
    af67:	74 68                	je     afd1 <fwp_hof0.constprop.0+0x1731>
    af69:	48 89 c2             	mov    %rax,%rdx
    af6c:	48 39 28             	cmp    %rbp,(%rax)
    af6f:	75 ef                	jne    af60 <fwp_hof0.constprop.0+0x16c0>
    af71:	48 8b 58 08          	mov    0x8(%rax),%rbx
    af75:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    af79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    af7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    af84:	0f 85 bd f6 ff ff    	jne    a647 <fwp_hof0.constprop.0+0xda7>
    af8a:	48 89 ef             	mov    %rbp,%rdi
    af8d:	48 89 0c 24          	mov    %rcx,(%rsp)
    af91:	e8 7a a5 ff ff       	call   5510 <fwp_rc_forget_slot>
    af96:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    af9a:	48 8b 0c 24          	mov    (%rsp),%rcx
    af9e:	e9 a4 f6 ff ff       	jmp    a647 <fwp_hof0.constprop.0+0xda7>
    afa3:	e8 48 a4 ff ff       	call   53f0 <fwp_rc_wide_dup>
    afa8:	e9 88 ea ff ff       	jmp    9a35 <fwp_hof0.constprop.0+0x195>
    afad:	48 89 e8             	mov    %rbp,%rax
    afb0:	48 c1 e8 11          	shr    $0x11,%rax
    afb4:	48 31 e8             	xor    %rbp,%rax
    afb7:	48 89 c2             	mov    %rax,%rdx
    afba:	48 c1 ea 09          	shr    $0x9,%rdx
    afbe:	48 31 d0             	xor    %rdx,%rax
    afc1:	0f b6 d0             	movzbl %al,%edx
    afc4:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    afcb:	00 
    afcc:	48 85 c0             	test   %rax,%rax
    afcf:	75 58                	jne    b029 <fwp_hof0.constprop.0+0x1789>
    afd1:	48 8d 3d b8 48 00 00 	lea    0x48b8(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    afd8:	e8 d3 93 ff ff       	call   43b0 <fwp_trap>
    afdd:	4c 89 f5             	mov    %r14,%rbp
    afe0:	49 89 eb             	mov    %rbp,%r11
    afe3:	48 89 cf             	mov    %rcx,%rdi
    afe6:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    afed:	00 
    afee:	31 f6                	xor    %esi,%esi
    aff0:	4d 29 f3             	sub    %r14,%r11
    aff3:	4c 8d 7d ff          	lea    -0x1(%rbp),%r15
    aff7:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    affc:	e8 9f 84 ff ff       	call   34a0 <memset@plt>
    b001:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    b006:	48 89 c1             	mov    %rax,%rcx
    b009:	e9 61 fc ff ff       	jmp    ac6f <fwp_hof0.constprop.0+0x13cf>
    b00e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b01c:	00 00 00 00 
    b020:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b024:	48 85 c0             	test   %rax,%rax
    b027:	74 a8                	je     afd1 <fwp_hof0.constprop.0+0x1731>
    b029:	48 89 c2             	mov    %rax,%rdx
    b02c:	48 39 28             	cmp    %rbp,(%rax)
    b02f:	75 ef                	jne    b020 <fwp_hof0.constprop.0+0x1780>
    b031:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b035:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    b039:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b03d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b044:	0f 85 d6 f7 ff ff    	jne    a820 <fwp_hof0.constprop.0+0xf80>
    b04a:	48 89 ef             	mov    %rbp,%rdi
    b04d:	e8 be a4 ff ff       	call   5510 <fwp_rc_forget_slot>
    b052:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    b056:	e9 c5 f7 ff ff       	jmp    a820 <fwp_hof0.constprop.0+0xf80>
    b05b:	e8 90 a3 ff ff       	call   53f0 <fwp_rc_wide_dup>
    b060:	e9 f4 e8 ff ff       	jmp    9959 <fwp_hof0.constprop.0+0xb9>
    b065:	45 31 ff             	xor    %r15d,%r15d
    b068:	e9 e8 f3 ff ff       	jmp    a455 <fwp_hof0.constprop.0+0xbb5>
    b06d:	48 8d 3d f3 40 00 00 	lea    0x40f3(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    b074:	e8 37 93 ff ff       	call   43b0 <fwp_trap>
    b079:	48 8d 3d 38 48 00 00 	lea    0x4838(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    b080:	e8 2b 93 ff ff       	call   43b0 <fwp_trap>
    b085:	48 8d 3d 04 49 00 00 	lea    0x4904(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    b08c:	e8 1f 93 ff ff       	call   43b0 <fwp_trap>
    b091:	31 db                	xor    %ebx,%ebx
    b093:	31 c9                	xor    %ecx,%ecx
    b095:	e9 f7 f4 ff ff       	jmp    a591 <fwp_hof0.constprop.0+0xcf1>
    b09a:	48 8d 3d ef 40 00 00 	lea    0x40ef(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    b0a1:	e8 0a 93 ff ff       	call   43b0 <fwp_trap>
    b0a6:	48 8d 3d 6f 41 00 00 	lea    0x416f(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    b0ad:	e8 fe 92 ff ff       	call   43b0 <fwp_trap>
    b0b2:	48 8d 3d 7d 41 00 00 	lea    0x417d(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    b0b9:	e8 f2 92 ff ff       	call   43b0 <fwp_trap>
    b0be:	48 8d 3d 9b 48 00 00 	lea    0x489b(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    b0c5:	e8 e6 92 ff ff       	call   43b0 <fwp_trap>
    b0ca:	e8 71 83 ff ff       	call   3440 <__stack_chk_fail@plt>
    b0cf:	48 8d 3d 70 41 00 00 	lea    0x4170(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b0d6:	e8 d5 92 ff ff       	call   43b0 <fwp_trap>
    b0db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b0e0:	48 8d 3d d1 48 00 00 	lea    0x48d1(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    b0e7:	e8 c4 92 ff ff       	call   43b0 <fwp_trap>
    b0ec:	48 8b 0d 4d 7f 00 00 	mov    0x7f4d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b0f3:	ba 13 00 00 00       	mov    $0x13,%edx
    b0f8:	be 01 00 00 00       	mov    $0x1,%esi
    b0fd:	48 8d 3d 04 3f 00 00 	lea    0x3f04(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b104:	e8 37 85 ff ff       	call   3640 <fwrite@plt>
    b109:	31 ff                	xor    %edi,%edi
    b10b:	e8 80 84 ff ff       	call   3590 <fflush@plt>
    b110:	bf 66 00 00 00       	mov    $0x66,%edi
    b115:	e8 46 85 ff ff       	call   3660 <_Exit@plt>
    b11a:	48 85 ed             	test   %rbp,%rbp
    b11d:	0f 84 3f fb ff ff    	je     ac62 <fwp_hof0.constprop.0+0x13c2>
    b123:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    b12a:	00 
    b12b:	4c 89 e7             	mov    %r12,%rdi
    b12e:	48 89 05 23 a3 01 00 	mov    %rax,0x1a323(%rip)        # 25458 <fwp_cleanups>
    b135:	e8 f6 9e ff ff       	call   5030 <fwp_tape_buffers_release>
    b13a:	ba 13 00 00 00       	mov    $0x13,%edx
    b13f:	48 8b 0d fa 7e 00 00 	mov    0x7efa(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b146:	be 01 00 00 00       	mov    $0x1,%esi
    b14b:	48 8d 3d b6 3e 00 00 	lea    0x3eb6(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b152:	e8 e9 84 ff ff       	call   3640 <fwrite@plt>
    b157:	31 ff                	xor    %edi,%edi
    b159:	e8 32 84 ff ff       	call   3590 <fflush@plt>
    b15e:	bf 66 00 00 00       	mov    $0x66,%edi
    b163:	e8 f8 84 ff ff       	call   3660 <_Exit@plt>
    b168:	48 8b 0d d1 7e 00 00 	mov    0x7ed1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b16f:	ba 13 00 00 00       	mov    $0x13,%edx
    b174:	be 01 00 00 00       	mov    $0x1,%esi
    b179:	48 8d 3d 88 3e 00 00 	lea    0x3e88(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b180:	e8 bb 84 ff ff       	call   3640 <fwrite@plt>
    b185:	31 ff                	xor    %edi,%edi
    b187:	e8 04 84 ff ff       	call   3590 <fflush@plt>
    b18c:	bf 66 00 00 00       	mov    $0x66,%edi
    b191:	e8 ca 84 ff ff       	call   3660 <_Exit@plt>
    b196:	48 8d 3d 63 47 00 00 	lea    0x4763(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    b19d:	e8 0e 92 ff ff       	call   43b0 <fwp_trap>
    b1a2:	0f 1f 00             	nopl   (%rax)
    b1a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b1ac:	00 00 00 00 

000000000000b1b0 <f0>:
    b1b0:	41 56                	push   %r14
    b1b2:	4c 8d 35 07 86 01 00 	lea    0x18607(%rip),%r14        # 237c0 <fwp_heap>
    b1b9:	41 55                	push   %r13
    b1bb:	41 54                	push   %r12
    b1bd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b1c3:	55                   	push   %rbp
    b1c4:	53                   	push   %rbx
    b1c5:	31 db                	xor    %ebx,%ebx
    b1c7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b1ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b1d5:	00 00 
    b1d7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b1de:	00 
    b1df:	31 c0                	xor    %eax,%eax
    b1e1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b1e8:	00 
    b1e9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b1f0:	00 00 
    b1f2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b1f7:	48 8d 05 f2 cc ff ff 	lea    -0x330e(%rip),%rax        # 7ef0 <fwp_drop1>
    b1fe:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b203:	48 8b 05 4e a2 01 00 	mov    0x1a24e(%rip),%rax        # 25458 <fwp_cleanups>
    b20a:	48 89 25 47 a2 01 00 	mov    %rsp,0x1a247(%rip)        # 25458 <fwp_cleanups>
    b211:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b215:	48 89 04 24          	mov    %rax,(%rsp)
    b219:	48 8d 05 70 89 ff ff 	lea    -0x7690(%rip),%rax        # 3b90 <fwp_range_release>
    b220:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b225:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b22a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b22f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b234:	eb 47                	jmp    b27d <f0+0xcd>
    b236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b23d:	00 00 00 
    b240:	80 f9 01             	cmp    $0x1,%cl
    b243:	75 29                	jne    b26e <f0+0xbe>
    b245:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b248:	0f b7 c0             	movzwl %ax,%eax
    b24b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b24e:	48 0f af c1          	imul   %rcx,%rax
    b252:	48 c1 e8 20          	shr    $0x20,%rax
    b256:	48 39 d0             	cmp    %rdx,%rax
    b259:	73 13                	jae    b26e <f0+0xbe>
    b25b:	49 01 c5             	add    %rax,%r13
    b25e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b263:	0f 84 c7 27 00 00    	je     da30 <f0+0x2880>
    b269:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b26e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b273:	49 83 ec 01          	sub    $0x1,%r12
    b277:	0f 82 83 00 00 00    	jb     b300 <f0+0x150>
    b27d:	48 89 ee             	mov    %rbp,%rsi
    b280:	bf 01 00 00 00       	mov    $0x1,%edi
    b285:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b28c:	00 
    b28d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b292:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b299:	00 
    b29a:	e8 d1 aa ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b29f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b2a6:	48 89 c3             	mov    %rax,%rbx
    b2a9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b2b0:	48 c1 e2 10          	shl    $0x10,%rdx
    b2b4:	48 39 d0             	cmp    %rdx,%rax
    b2b7:	73 b5                	jae    b26e <f0+0xbe>
    b2b9:	48 89 c2             	mov    %rax,%rdx
    b2bc:	48 c1 ea 10          	shr    $0x10,%rdx
    b2c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2c4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b2cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2cf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b2d3:	4d 85 ed             	test   %r13,%r13
    b2d6:	74 96                	je     b26e <f0+0xbe>
    b2d8:	0f b6 0a             	movzbl (%rdx),%ecx
    b2db:	80 f9 02             	cmp    $0x2,%cl
    b2de:	0f 85 5c ff ff ff    	jne    b240 <f0+0x90>
    b2e4:	66 85 c0             	test   %ax,%ax
    b2e7:	0f 84 71 ff ff ff    	je     b25e <f0+0xae>
    b2ed:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b2f2:	49 83 ec 01          	sub    $0x1,%r12
    b2f6:	73 85                	jae    b27d <f0+0xcd>
    b2f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b2ff:	00 
    b300:	48 8b 04 24          	mov    (%rsp),%rax
    b304:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b309:	bf 01 00 00 00       	mov    $0x1,%edi
    b30e:	66 0f 6f 05 4a 49 00 	movdqa 0x494a(%rip),%xmm0        # fc60 <msg.4+0xf0>
    b315:	00 
    b316:	48 89 05 3b a1 01 00 	mov    %rax,0x1a13b(%rip)        # 25458 <fwp_cleanups>
    b31d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b322:	e8 49 aa ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b327:	48 8b 15 6a 98 01 00 	mov    0x1986a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b32e:	49 89 c5             	mov    %rax,%r13
    b331:	48 2b 05 38 98 01 00 	sub    0x19838(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b338:	48 c1 e2 10          	shl    $0x10,%rdx
    b33c:	48 39 d0             	cmp    %rdx,%rax
    b33f:	73 59                	jae    b39a <f0+0x1ea>
    b341:	48 89 c2             	mov    %rax,%rdx
    b344:	48 c1 ea 10          	shr    $0x10,%rdx
    b348:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b34c:	48 8b 15 65 98 01 00 	mov    0x19865(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b353:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b357:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b35b:	4d 85 e4             	test   %r12,%r12
    b35e:	74 3a                	je     b39a <f0+0x1ea>
    b360:	0f b6 0a             	movzbl (%rdx),%ecx
    b363:	80 f9 02             	cmp    $0x2,%cl
    b366:	0f 84 74 27 00 00    	je     dae0 <f0+0x2930>
    b36c:	80 f9 01             	cmp    $0x1,%cl
    b36f:	75 29                	jne    b39a <f0+0x1ea>
    b371:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b374:	0f b7 c0             	movzwl %ax,%eax
    b377:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b37a:	48 0f af c1          	imul   %rcx,%rax
    b37e:	48 c1 e8 20          	shr    $0x20,%rax
    b382:	48 39 d0             	cmp    %rdx,%rax
    b385:	73 13                	jae    b39a <f0+0x1ea>
    b387:	49 01 c4             	add    %rax,%r12
    b38a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b38f:	0f 84 26 29 00 00    	je     dcbb <f0+0x2b0b>
    b395:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b39a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b39f:	bf 01 00 00 00       	mov    $0x1,%edi
    b3a4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b3a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b3b0:	00 f0 3f 
    b3b3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b3b8:	e8 b3 a9 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b3bd:	48 8b 15 d4 97 01 00 	mov    0x197d4(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b3c4:	49 89 c5             	mov    %rax,%r13
    b3c7:	48 2b 05 a2 97 01 00 	sub    0x197a2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b3ce:	48 c1 e2 10          	shl    $0x10,%rdx
    b3d2:	48 39 d0             	cmp    %rdx,%rax
    b3d5:	73 59                	jae    b430 <f0+0x280>
    b3d7:	48 89 c2             	mov    %rax,%rdx
    b3da:	48 c1 ea 10          	shr    $0x10,%rdx
    b3de:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3e2:	48 8b 15 cf 97 01 00 	mov    0x197cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b3e9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3ed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b3f1:	4d 85 e4             	test   %r12,%r12
    b3f4:	74 3a                	je     b430 <f0+0x280>
    b3f6:	0f b6 0a             	movzbl (%rdx),%ecx
    b3f9:	80 f9 02             	cmp    $0x2,%cl
    b3fc:	0f 84 ce 26 00 00    	je     dad0 <f0+0x2920>
    b402:	80 f9 01             	cmp    $0x1,%cl
    b405:	75 29                	jne    b430 <f0+0x280>
    b407:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b40a:	0f b7 c0             	movzwl %ax,%eax
    b40d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b410:	48 0f af c1          	imul   %rcx,%rax
    b414:	48 c1 e8 20          	shr    $0x20,%rax
    b418:	48 39 d0             	cmp    %rdx,%rax
    b41b:	73 13                	jae    b430 <f0+0x280>
    b41d:	49 01 c4             	add    %rax,%r12
    b420:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b425:	0f 84 9d 28 00 00    	je     dcc8 <f0+0x2b18>
    b42b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b430:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b435:	bf 01 00 00 00       	mov    $0x1,%edi
    b43a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b43f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b446:	33 f3 bf 
    b449:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b44e:	e8 1d a9 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b453:	48 8b 15 3e 97 01 00 	mov    0x1973e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b45a:	49 89 c5             	mov    %rax,%r13
    b45d:	48 2b 05 0c 97 01 00 	sub    0x1970c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b464:	48 c1 e2 10          	shl    $0x10,%rdx
    b468:	48 39 d0             	cmp    %rdx,%rax
    b46b:	73 59                	jae    b4c6 <f0+0x316>
    b46d:	48 89 c2             	mov    %rax,%rdx
    b470:	48 c1 ea 10          	shr    $0x10,%rdx
    b474:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b478:	48 8b 15 39 97 01 00 	mov    0x19739(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b47f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b483:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b487:	4d 85 e4             	test   %r12,%r12
    b48a:	74 3a                	je     b4c6 <f0+0x316>
    b48c:	0f b6 0a             	movzbl (%rdx),%ecx
    b48f:	80 f9 02             	cmp    $0x2,%cl
    b492:	0f 84 28 26 00 00    	je     dac0 <f0+0x2910>
    b498:	80 f9 01             	cmp    $0x1,%cl
    b49b:	75 29                	jne    b4c6 <f0+0x316>
    b49d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4a0:	0f b7 c0             	movzwl %ax,%eax
    b4a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4a6:	48 0f af c1          	imul   %rcx,%rax
    b4aa:	48 c1 e8 20          	shr    $0x20,%rax
    b4ae:	48 39 d0             	cmp    %rdx,%rax
    b4b1:	73 13                	jae    b4c6 <f0+0x316>
    b4b3:	49 01 c4             	add    %rax,%r12
    b4b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4bb:	0f 84 14 28 00 00    	je     dcd5 <f0+0x2b25>
    b4c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4c6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b4cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b4d5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b4dc:	00 f0 3f 
    b4df:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b4e4:	e8 87 a8 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b4e9:	48 8b 15 a8 96 01 00 	mov    0x196a8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b4f0:	49 89 c5             	mov    %rax,%r13
    b4f3:	48 2b 05 76 96 01 00 	sub    0x19676(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b4fa:	48 c1 e2 10          	shl    $0x10,%rdx
    b4fe:	48 39 d0             	cmp    %rdx,%rax
    b501:	73 59                	jae    b55c <f0+0x3ac>
    b503:	48 89 c2             	mov    %rax,%rdx
    b506:	48 c1 ea 10          	shr    $0x10,%rdx
    b50a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b50e:	48 8b 15 a3 96 01 00 	mov    0x196a3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b515:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b519:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b51d:	4d 85 e4             	test   %r12,%r12
    b520:	74 3a                	je     b55c <f0+0x3ac>
    b522:	0f b6 0a             	movzbl (%rdx),%ecx
    b525:	80 f9 02             	cmp    $0x2,%cl
    b528:	0f 84 f2 25 00 00    	je     db20 <f0+0x2970>
    b52e:	80 f9 01             	cmp    $0x1,%cl
    b531:	75 29                	jne    b55c <f0+0x3ac>
    b533:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b536:	0f b7 c0             	movzwl %ax,%eax
    b539:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b53c:	48 0f af c1          	imul   %rcx,%rax
    b540:	48 c1 e8 20          	shr    $0x20,%rax
    b544:	48 39 d0             	cmp    %rdx,%rax
    b547:	73 13                	jae    b55c <f0+0x3ac>
    b549:	49 01 c4             	add    %rax,%r12
    b54c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b551:	0f 84 8b 27 00 00    	je     dce2 <f0+0x2b32>
    b557:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b55c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b563:	33 f3 bf 
    b566:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b56d:	00 
    b56e:	bf 01 00 00 00       	mov    $0x1,%edi
    b573:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b57a:	00 
    b57b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b582:	00 
    b583:	e8 e8 a7 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b588:	48 8b 15 09 96 01 00 	mov    0x19609(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b58f:	49 89 c5             	mov    %rax,%r13
    b592:	48 2b 05 d7 95 01 00 	sub    0x195d7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b599:	48 c1 e2 10          	shl    $0x10,%rdx
    b59d:	48 39 d0             	cmp    %rdx,%rax
    b5a0:	73 59                	jae    b5fb <f0+0x44b>
    b5a2:	48 89 c2             	mov    %rax,%rdx
    b5a5:	48 c1 ea 10          	shr    $0x10,%rdx
    b5a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5ad:	48 8b 15 04 96 01 00 	mov    0x19604(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b5b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5b8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b5bc:	4d 85 e4             	test   %r12,%r12
    b5bf:	74 3a                	je     b5fb <f0+0x44b>
    b5c1:	0f b6 0a             	movzbl (%rdx),%ecx
    b5c4:	80 f9 02             	cmp    $0x2,%cl
    b5c7:	0f 84 43 25 00 00    	je     db10 <f0+0x2960>
    b5cd:	80 f9 01             	cmp    $0x1,%cl
    b5d0:	75 29                	jne    b5fb <f0+0x44b>
    b5d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5d5:	0f b7 c0             	movzwl %ax,%eax
    b5d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5db:	48 0f af c1          	imul   %rcx,%rax
    b5df:	48 c1 e8 20          	shr    $0x20,%rax
    b5e3:	48 39 d0             	cmp    %rdx,%rax
    b5e6:	73 13                	jae    b5fb <f0+0x44b>
    b5e8:	49 01 c4             	add    %rax,%r12
    b5eb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b5f0:	0f 84 f9 26 00 00    	je     dcef <f0+0x2b3f>
    b5f6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b5fb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b602:	00 f0 3f 
    b605:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b60c:	00 
    b60d:	bf 01 00 00 00       	mov    $0x1,%edi
    b612:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b619:	00 
    b61a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b621:	00 
    b622:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b629:	33 f3 bf 
    b62c:	e8 3f a7 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b631:	48 89 c7             	mov    %rax,%rdi
    b634:	e8 b7 b4 ff ff       	call   6af0 <fwp_rc_fresh>
    b639:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b640:	00 
    b641:	bf 01 00 00 00       	mov    $0x1,%edi
    b646:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b64d:	00 
    b64e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b655:	00 
    b656:	e8 15 a7 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b65b:	48 89 c7             	mov    %rax,%rdi
    b65e:	e8 8d b4 ff ff       	call   6af0 <fwp_rc_fresh>
    b663:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b66a:	00 
    b66b:	bf 01 00 00 00       	mov    $0x1,%edi
    b670:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b677:	00 
    b678:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b67f:	00 
    b680:	e8 eb a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b685:	48 89 c7             	mov    %rax,%rdi
    b688:	e8 63 b4 ff ff       	call   6af0 <fwp_rc_fresh>
    b68d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b694:	00 
    b695:	bf 01 00 00 00       	mov    $0x1,%edi
    b69a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b6a1:	00 
    b6a2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b6a9:	00 
    b6aa:	e8 c1 a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b6af:	48 89 c7             	mov    %rax,%rdi
    b6b2:	e8 39 b4 ff ff       	call   6af0 <fwp_rc_fresh>
    b6b7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b6be:	00 
    b6bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b6cb:	00 
    b6cc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b6d3:	00 
    b6d4:	e8 97 a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b6d9:	48 89 c7             	mov    %rax,%rdi
    b6dc:	e8 0f b4 ff ff       	call   6af0 <fwp_rc_fresh>
    b6e1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b6e8:	00 
    b6e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ee:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b6f5:	00 
    b6f6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b6fd:	00 
    b6fe:	e8 6d a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b703:	48 89 c7             	mov    %rax,%rdi
    b706:	e8 e5 b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b70b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b712:	00 
    b713:	bf 01 00 00 00       	mov    $0x1,%edi
    b718:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b71f:	00 
    b720:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b727:	00 
    b728:	e8 43 a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b72d:	48 89 c7             	mov    %rax,%rdi
    b730:	e8 bb b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b735:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b73c:	00 
    b73d:	bf 01 00 00 00       	mov    $0x1,%edi
    b742:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b749:	00 
    b74a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b751:	00 
    b752:	e8 19 a6 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b757:	48 89 c7             	mov    %rax,%rdi
    b75a:	e8 91 b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b75f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b766:	00 
    b767:	bf 01 00 00 00       	mov    $0x1,%edi
    b76c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b773:	00 
    b774:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b77b:	00 
    b77c:	e8 ef a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b781:	48 89 c7             	mov    %rax,%rdi
    b784:	e8 67 b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b789:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b790:	00 
    b791:	bf 01 00 00 00       	mov    $0x1,%edi
    b796:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b79d:	00 
    b79e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b7a5:	00 
    b7a6:	e8 c5 a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b7ab:	48 89 c7             	mov    %rax,%rdi
    b7ae:	e8 3d b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b7b3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b7ba:	00 
    b7bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b7c7:	00 
    b7c8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b7cf:	00 
    b7d0:	e8 9b a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b7d5:	48 89 c7             	mov    %rax,%rdi
    b7d8:	e8 13 b3 ff ff       	call   6af0 <fwp_rc_fresh>
    b7dd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b7e4:	00 
    b7e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ea:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b7f1:	00 
    b7f2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b7f9:	00 
    b7fa:	e8 71 a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b7ff:	48 89 c7             	mov    %rax,%rdi
    b802:	e8 e9 b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b807:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b80e:	00 
    b80f:	bf 01 00 00 00       	mov    $0x1,%edi
    b814:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b81b:	00 
    b81c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b823:	00 
    b824:	e8 47 a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b829:	48 89 c7             	mov    %rax,%rdi
    b82c:	e8 bf b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b831:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b838:	00 
    b839:	bf 01 00 00 00       	mov    $0x1,%edi
    b83e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b845:	00 
    b846:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b84d:	00 
    b84e:	e8 1d a5 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b853:	48 89 c7             	mov    %rax,%rdi
    b856:	e8 95 b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b85b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b862:	00 
    b863:	bf 01 00 00 00       	mov    $0x1,%edi
    b868:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b86f:	00 
    b870:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b877:	00 
    b878:	e8 f3 a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b87d:	48 89 c7             	mov    %rax,%rdi
    b880:	e8 6b b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b885:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b88c:	00 
    b88d:	bf 01 00 00 00       	mov    $0x1,%edi
    b892:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b899:	00 
    b89a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b8a1:	00 
    b8a2:	e8 c9 a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b8a7:	48 89 c7             	mov    %rax,%rdi
    b8aa:	e8 41 b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b8af:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b8b6:	00 
    b8b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8bc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b8c3:	00 
    b8c4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b8cb:	00 
    b8cc:	e8 9f a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b8d1:	48 89 c7             	mov    %rax,%rdi
    b8d4:	e8 17 b2 ff ff       	call   6af0 <fwp_rc_fresh>
    b8d9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b8e0:	00 
    b8e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b8ed:	00 
    b8ee:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b8f5:	00 
    b8f6:	e8 75 a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b8fb:	48 89 c7             	mov    %rax,%rdi
    b8fe:	e8 ed b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b903:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b90a:	00 
    b90b:	bf 01 00 00 00       	mov    $0x1,%edi
    b910:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b917:	00 
    b918:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b91f:	00 
    b920:	e8 4b a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b925:	48 89 c7             	mov    %rax,%rdi
    b928:	e8 c3 b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b92d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b934:	00 
    b935:	bf 01 00 00 00       	mov    $0x1,%edi
    b93a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b941:	00 
    b942:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b949:	00 
    b94a:	e8 21 a4 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b94f:	48 89 c7             	mov    %rax,%rdi
    b952:	e8 99 b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b957:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b95e:	00 
    b95f:	bf 01 00 00 00       	mov    $0x1,%edi
    b964:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b96b:	00 
    b96c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b973:	00 
    b974:	e8 f7 a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b979:	48 89 c7             	mov    %rax,%rdi
    b97c:	e8 6f b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b981:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b988:	00 
    b989:	bf 01 00 00 00       	mov    $0x1,%edi
    b98e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b995:	00 
    b996:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b99d:	00 
    b99e:	e8 cd a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b9a3:	48 89 c7             	mov    %rax,%rdi
    b9a6:	e8 45 b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b9ab:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b9b2:	00 
    b9b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b9bf:	00 
    b9c0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b9c7:	00 
    b9c8:	e8 a3 a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b9cd:	48 89 c7             	mov    %rax,%rdi
    b9d0:	e8 1b b1 ff ff       	call   6af0 <fwp_rc_fresh>
    b9d5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b9dc:	00 
    b9dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b9e9:	00 
    b9ea:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b9f1:	00 
    b9f2:	e8 79 a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    b9f7:	48 89 c7             	mov    %rax,%rdi
    b9fa:	e8 f1 b0 ff ff       	call   6af0 <fwp_rc_fresh>
    b9ff:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    ba06:	00 
    ba07:	bf 01 00 00 00       	mov    $0x1,%edi
    ba0c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    ba13:	00 
    ba14:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    ba1b:	00 
    ba1c:	e8 4f a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ba21:	48 89 c7             	mov    %rax,%rdi
    ba24:	e8 c7 b0 ff ff       	call   6af0 <fwp_rc_fresh>
    ba29:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    ba30:	00 
    ba31:	bf 01 00 00 00       	mov    $0x1,%edi
    ba36:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    ba3d:	00 
    ba3e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    ba45:	00 
    ba46:	e8 25 a3 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ba4b:	48 89 c7             	mov    %rax,%rdi
    ba4e:	e8 9d b0 ff ff       	call   6af0 <fwp_rc_fresh>
    ba53:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    ba5a:	00 
    ba5b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba60:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    ba67:	00 
    ba68:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    ba6f:	00 
    ba70:	e8 fb a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ba75:	48 89 c7             	mov    %rax,%rdi
    ba78:	e8 73 b0 ff ff       	call   6af0 <fwp_rc_fresh>
    ba7d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    ba84:	00 
    ba85:	bf 01 00 00 00       	mov    $0x1,%edi
    ba8a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    ba91:	00 
    ba92:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    ba99:	00 
    ba9a:	e8 d1 a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ba9f:	48 89 c7             	mov    %rax,%rdi
    baa2:	e8 49 b0 ff ff       	call   6af0 <fwp_rc_fresh>
    baa7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    baae:	00 
    baaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bab4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    babb:	00 
    babc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bac3:	00 
    bac4:	e8 a7 a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bac9:	48 89 c7             	mov    %rax,%rdi
    bacc:	e8 1f b0 ff ff       	call   6af0 <fwp_rc_fresh>
    bad1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bad8:	00 
    bad9:	bf 01 00 00 00       	mov    $0x1,%edi
    bade:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bae5:	00 
    bae6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    baed:	00 
    baee:	e8 7d a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    baf3:	48 89 c7             	mov    %rax,%rdi
    baf6:	e8 f5 af ff ff       	call   6af0 <fwp_rc_fresh>
    bafb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bb02:	00 
    bb03:	bf 01 00 00 00       	mov    $0x1,%edi
    bb08:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bb0f:	00 
    bb10:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bb17:	00 
    bb18:	e8 53 a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bb1d:	48 89 c7             	mov    %rax,%rdi
    bb20:	e8 cb af ff ff       	call   6af0 <fwp_rc_fresh>
    bb25:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bb2c:	00 
    bb2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb32:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bb39:	00 
    bb3a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bb41:	00 
    bb42:	e8 29 a2 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bb47:	48 89 c7             	mov    %rax,%rdi
    bb4a:	e8 a1 af ff ff       	call   6af0 <fwp_rc_fresh>
    bb4f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bb56:	00 
    bb57:	bf 01 00 00 00       	mov    $0x1,%edi
    bb5c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bb63:	00 
    bb64:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bb6b:	00 
    bb6c:	e8 ff a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bb71:	48 89 c7             	mov    %rax,%rdi
    bb74:	e8 77 af ff ff       	call   6af0 <fwp_rc_fresh>
    bb79:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bb80:	00 
    bb81:	bf 01 00 00 00       	mov    $0x1,%edi
    bb86:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bb8d:	00 
    bb8e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bb95:	00 
    bb96:	e8 d5 a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bb9b:	48 89 c7             	mov    %rax,%rdi
    bb9e:	e8 4d af ff ff       	call   6af0 <fwp_rc_fresh>
    bba3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bbaa:	00 
    bbab:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bbb7:	00 
    bbb8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bbbf:	00 
    bbc0:	e8 ab a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bbc5:	48 89 c7             	mov    %rax,%rdi
    bbc8:	e8 23 af ff ff       	call   6af0 <fwp_rc_fresh>
    bbcd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bbd4:	00 
    bbd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbda:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bbe1:	00 
    bbe2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bbe9:	00 
    bbea:	e8 81 a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bbef:	48 89 c7             	mov    %rax,%rdi
    bbf2:	e8 f9 ae ff ff       	call   6af0 <fwp_rc_fresh>
    bbf7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bbfe:	00 
    bbff:	bf 01 00 00 00       	mov    $0x1,%edi
    bc04:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bc0b:	00 
    bc0c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bc13:	00 
    bc14:	e8 57 a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bc19:	48 89 c7             	mov    %rax,%rdi
    bc1c:	e8 cf ae ff ff       	call   6af0 <fwp_rc_fresh>
    bc21:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bc28:	00 
    bc29:	bf 01 00 00 00       	mov    $0x1,%edi
    bc2e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bc35:	00 
    bc36:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bc3d:	00 
    bc3e:	e8 2d a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bc43:	48 89 c7             	mov    %rax,%rdi
    bc46:	e8 a5 ae ff ff       	call   6af0 <fwp_rc_fresh>
    bc4b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bc52:	00 
    bc53:	bf 01 00 00 00       	mov    $0x1,%edi
    bc58:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bc5f:	00 
    bc60:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bc67:	00 
    bc68:	e8 03 a1 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bc6d:	48 89 c7             	mov    %rax,%rdi
    bc70:	e8 7b ae ff ff       	call   6af0 <fwp_rc_fresh>
    bc75:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bc7c:	00 
    bc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc82:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bc89:	00 
    bc8a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bc91:	00 
    bc92:	e8 d9 a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bc97:	48 89 c7             	mov    %rax,%rdi
    bc9a:	e8 51 ae ff ff       	call   6af0 <fwp_rc_fresh>
    bc9f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bca6:	00 
    bca7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcac:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bcb3:	00 
    bcb4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bcbb:	00 
    bcbc:	e8 af a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bcc1:	48 89 c7             	mov    %rax,%rdi
    bcc4:	e8 27 ae ff ff       	call   6af0 <fwp_rc_fresh>
    bcc9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bcd0:	00 
    bcd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bcdd:	00 
    bcde:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bce5:	00 
    bce6:	e8 85 a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bceb:	48 89 c7             	mov    %rax,%rdi
    bcee:	e8 fd ad ff ff       	call   6af0 <fwp_rc_fresh>
    bcf3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bcfa:	00 
    bcfb:	bf 01 00 00 00       	mov    $0x1,%edi
    bd00:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bd07:	00 
    bd08:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bd0f:	00 
    bd10:	e8 5b a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bd15:	48 89 c7             	mov    %rax,%rdi
    bd18:	e8 d3 ad ff ff       	call   6af0 <fwp_rc_fresh>
    bd1d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bd24:	00 
    bd25:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bd31:	00 
    bd32:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bd39:	00 
    bd3a:	e8 31 a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bd3f:	48 89 c7             	mov    %rax,%rdi
    bd42:	e8 a9 ad ff ff       	call   6af0 <fwp_rc_fresh>
    bd47:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bd4e:	00 
    bd4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd54:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bd5b:	00 
    bd5c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bd63:	00 
    bd64:	e8 07 a0 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bd69:	48 89 c7             	mov    %rax,%rdi
    bd6c:	e8 7f ad ff ff       	call   6af0 <fwp_rc_fresh>
    bd71:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bd78:	00 
    bd79:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bd85:	00 
    bd86:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bd8d:	00 
    bd8e:	e8 dd 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bd93:	48 89 c7             	mov    %rax,%rdi
    bd96:	e8 55 ad ff ff       	call   6af0 <fwp_rc_fresh>
    bd9b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bda2:	00 
    bda3:	bf 01 00 00 00       	mov    $0x1,%edi
    bda8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bdaf:	00 
    bdb0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bdb7:	00 
    bdb8:	e8 b3 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bdbd:	48 89 c7             	mov    %rax,%rdi
    bdc0:	e8 2b ad ff ff       	call   6af0 <fwp_rc_fresh>
    bdc5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bdcc:	00 
    bdcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bdd9:	00 
    bdda:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bde1:	00 
    bde2:	e8 89 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bde7:	48 89 c7             	mov    %rax,%rdi
    bdea:	e8 01 ad ff ff       	call   6af0 <fwp_rc_fresh>
    bdef:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bdf6:	00 
    bdf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdfc:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    be03:	00 
    be04:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    be0b:	00 
    be0c:	e8 5f 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    be11:	48 89 c7             	mov    %rax,%rdi
    be14:	e8 d7 ac ff ff       	call   6af0 <fwp_rc_fresh>
    be19:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    be20:	00 
    be21:	bf 01 00 00 00       	mov    $0x1,%edi
    be26:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    be2d:	00 
    be2e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    be35:	00 
    be36:	e8 35 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    be3b:	48 89 c7             	mov    %rax,%rdi
    be3e:	e8 ad ac ff ff       	call   6af0 <fwp_rc_fresh>
    be43:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    be4a:	00 
    be4b:	bf 01 00 00 00       	mov    $0x1,%edi
    be50:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    be57:	00 
    be58:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    be5f:	00 
    be60:	e8 0b 9f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    be65:	48 89 c7             	mov    %rax,%rdi
    be68:	e8 83 ac ff ff       	call   6af0 <fwp_rc_fresh>
    be6d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    be74:	00 
    be75:	bf 01 00 00 00       	mov    $0x1,%edi
    be7a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    be81:	00 
    be82:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    be89:	00 
    be8a:	e8 e1 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    be8f:	48 89 c7             	mov    %rax,%rdi
    be92:	e8 59 ac ff ff       	call   6af0 <fwp_rc_fresh>
    be97:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    be9e:	00 
    be9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bea4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    beab:	00 
    beac:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    beb3:	00 
    beb4:	e8 b7 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    beb9:	48 89 c7             	mov    %rax,%rdi
    bebc:	e8 2f ac ff ff       	call   6af0 <fwp_rc_fresh>
    bec1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bec8:	00 
    bec9:	bf 01 00 00 00       	mov    $0x1,%edi
    bece:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bed5:	00 
    bed6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bedd:	00 
    bede:	e8 8d 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bee3:	48 89 c7             	mov    %rax,%rdi
    bee6:	e8 05 ac ff ff       	call   6af0 <fwp_rc_fresh>
    beeb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bef2:	00 
    bef3:	bf 01 00 00 00       	mov    $0x1,%edi
    bef8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    beff:	00 
    bf00:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bf07:	00 
    bf08:	e8 63 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bf0d:	48 89 c7             	mov    %rax,%rdi
    bf10:	e8 db ab ff ff       	call   6af0 <fwp_rc_fresh>
    bf15:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bf1c:	00 
    bf1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf22:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bf29:	00 
    bf2a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bf31:	00 
    bf32:	e8 39 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bf37:	48 89 c7             	mov    %rax,%rdi
    bf3a:	e8 b1 ab ff ff       	call   6af0 <fwp_rc_fresh>
    bf3f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bf46:	00 
    bf47:	bf 01 00 00 00       	mov    $0x1,%edi
    bf4c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bf53:	00 
    bf54:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bf5b:	00 
    bf5c:	e8 0f 9e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bf61:	48 89 c7             	mov    %rax,%rdi
    bf64:	e8 87 ab ff ff       	call   6af0 <fwp_rc_fresh>
    bf69:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bf70:	00 
    bf71:	bf 01 00 00 00       	mov    $0x1,%edi
    bf76:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    bf7d:	00 
    bf7e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bf85:	00 
    bf86:	e8 e5 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bf8b:	48 89 c7             	mov    %rax,%rdi
    bf8e:	e8 5d ab ff ff       	call   6af0 <fwp_rc_fresh>
    bf93:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    bf9a:	00 
    bf9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    bfa7:	00 
    bfa8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    bfaf:	00 
    bfb0:	e8 bb 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bfb5:	48 89 c7             	mov    %rax,%rdi
    bfb8:	e8 33 ab ff ff       	call   6af0 <fwp_rc_fresh>
    bfbd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    bfc4:	00 
    bfc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfca:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bfd1:	00 
    bfd2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bfd9:	00 
    bfda:	e8 91 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    bfdf:	48 89 c7             	mov    %rax,%rdi
    bfe2:	e8 09 ab ff ff       	call   6af0 <fwp_rc_fresh>
    bfe7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bfee:	00 
    bfef:	bf 01 00 00 00       	mov    $0x1,%edi
    bff4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    bffb:	00 
    bffc:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c003:	00 
    c004:	e8 67 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c009:	48 89 c7             	mov    %rax,%rdi
    c00c:	e8 df aa ff ff       	call   6af0 <fwp_rc_fresh>
    c011:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c018:	00 
    c019:	bf 01 00 00 00       	mov    $0x1,%edi
    c01e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c025:	00 
    c026:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c02d:	00 
    c02e:	e8 3d 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c033:	48 89 c7             	mov    %rax,%rdi
    c036:	e8 b5 aa ff ff       	call   6af0 <fwp_rc_fresh>
    c03b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c042:	00 
    c043:	bf 01 00 00 00       	mov    $0x1,%edi
    c048:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c04f:	00 
    c050:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c057:	00 
    c058:	e8 13 9d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c05d:	48 89 c7             	mov    %rax,%rdi
    c060:	e8 8b aa ff ff       	call   6af0 <fwp_rc_fresh>
    c065:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c06c:	00 
    c06d:	bf 01 00 00 00       	mov    $0x1,%edi
    c072:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c079:	00 
    c07a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c081:	00 
    c082:	e8 e9 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c087:	48 89 c7             	mov    %rax,%rdi
    c08a:	e8 61 aa ff ff       	call   6af0 <fwp_rc_fresh>
    c08f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c096:	00 
    c097:	bf 01 00 00 00       	mov    $0x1,%edi
    c09c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c0a3:	00 
    c0a4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c0ab:	00 
    c0ac:	e8 bf 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c0b1:	48 89 c7             	mov    %rax,%rdi
    c0b4:	e8 37 aa ff ff       	call   6af0 <fwp_rc_fresh>
    c0b9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c0c0:	00 
    c0c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0c6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c0cd:	00 
    c0ce:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c0d5:	00 
    c0d6:	e8 95 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c0db:	48 89 c7             	mov    %rax,%rdi
    c0de:	e8 0d aa ff ff       	call   6af0 <fwp_rc_fresh>
    c0e3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c0ea:	00 
    c0eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c0f7:	00 
    c0f8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c0ff:	00 
    c100:	e8 6b 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c105:	48 89 c7             	mov    %rax,%rdi
    c108:	e8 e3 a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c10d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c114:	00 
    c115:	bf 01 00 00 00       	mov    $0x1,%edi
    c11a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c121:	00 
    c122:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c129:	00 
    c12a:	e8 41 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c12f:	48 89 c7             	mov    %rax,%rdi
    c132:	e8 b9 a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c137:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c13e:	00 
    c13f:	bf 01 00 00 00       	mov    $0x1,%edi
    c144:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c14b:	00 
    c14c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c153:	00 
    c154:	e8 17 9c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c159:	48 89 c7             	mov    %rax,%rdi
    c15c:	e8 8f a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c161:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c168:	00 
    c169:	bf 01 00 00 00       	mov    $0x1,%edi
    c16e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c175:	00 
    c176:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c17d:	00 
    c17e:	e8 ed 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c183:	48 89 c7             	mov    %rax,%rdi
    c186:	e8 65 a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c18b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c192:	00 
    c193:	bf 01 00 00 00       	mov    $0x1,%edi
    c198:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c19f:	00 
    c1a0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c1a7:	00 
    c1a8:	e8 c3 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c1ad:	48 89 c7             	mov    %rax,%rdi
    c1b0:	e8 3b a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c1b5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c1bc:	00 
    c1bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c1c9:	00 
    c1ca:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c1d1:	00 
    c1d2:	e8 99 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c1d7:	48 89 c7             	mov    %rax,%rdi
    c1da:	e8 11 a9 ff ff       	call   6af0 <fwp_rc_fresh>
    c1df:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c1e6:	00 
    c1e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ec:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c1f3:	00 
    c1f4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c1fb:	00 
    c1fc:	e8 6f 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c201:	48 89 c7             	mov    %rax,%rdi
    c204:	e8 e7 a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c209:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c210:	00 
    c211:	bf 01 00 00 00       	mov    $0x1,%edi
    c216:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c21d:	00 
    c21e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c225:	00 
    c226:	e8 45 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c22b:	48 89 c7             	mov    %rax,%rdi
    c22e:	e8 bd a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c233:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c23a:	00 
    c23b:	bf 01 00 00 00       	mov    $0x1,%edi
    c240:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c247:	00 
    c248:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c24f:	00 
    c250:	e8 1b 9b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c255:	48 89 c7             	mov    %rax,%rdi
    c258:	e8 93 a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c25d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c264:	00 
    c265:	bf 01 00 00 00       	mov    $0x1,%edi
    c26a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c271:	00 
    c272:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c279:	00 
    c27a:	e8 f1 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c27f:	48 89 c7             	mov    %rax,%rdi
    c282:	e8 69 a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c287:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c28e:	00 
    c28f:	bf 01 00 00 00       	mov    $0x1,%edi
    c294:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c29b:	00 
    c29c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c2a3:	00 
    c2a4:	e8 c7 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c2a9:	48 89 c7             	mov    %rax,%rdi
    c2ac:	e8 3f a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c2b1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c2b8:	00 
    c2b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2be:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c2c5:	00 
    c2c6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c2cd:	00 
    c2ce:	e8 9d 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c2d3:	48 89 c7             	mov    %rax,%rdi
    c2d6:	e8 15 a8 ff ff       	call   6af0 <fwp_rc_fresh>
    c2db:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c2e2:	00 
    c2e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c2ef:	00 
    c2f0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c2f7:	00 
    c2f8:	e8 73 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c2fd:	48 89 c7             	mov    %rax,%rdi
    c300:	e8 eb a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c305:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c30c:	00 
    c30d:	bf 01 00 00 00       	mov    $0x1,%edi
    c312:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c319:	00 
    c31a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c321:	00 
    c322:	e8 49 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c327:	48 89 c7             	mov    %rax,%rdi
    c32a:	e8 c1 a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c32f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c336:	00 
    c337:	bf 01 00 00 00       	mov    $0x1,%edi
    c33c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c343:	00 
    c344:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c34b:	00 
    c34c:	e8 1f 9a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c351:	48 89 c7             	mov    %rax,%rdi
    c354:	e8 97 a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c359:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c360:	00 
    c361:	bf 01 00 00 00       	mov    $0x1,%edi
    c366:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c36d:	00 
    c36e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c375:	00 
    c376:	e8 f5 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c37b:	48 89 c7             	mov    %rax,%rdi
    c37e:	e8 6d a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c383:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c38a:	00 
    c38b:	bf 01 00 00 00       	mov    $0x1,%edi
    c390:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c397:	00 
    c398:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c39f:	00 
    c3a0:	e8 cb 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c3a5:	48 89 c7             	mov    %rax,%rdi
    c3a8:	e8 43 a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c3ad:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c3b4:	00 
    c3b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ba:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c3c1:	00 
    c3c2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c3c9:	00 
    c3ca:	e8 a1 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c3cf:	48 89 c7             	mov    %rax,%rdi
    c3d2:	e8 19 a7 ff ff       	call   6af0 <fwp_rc_fresh>
    c3d7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c3de:	00 
    c3df:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c3eb:	00 
    c3ec:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c3f3:	00 
    c3f4:	e8 77 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c3f9:	48 89 c7             	mov    %rax,%rdi
    c3fc:	e8 ef a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c401:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c408:	00 
    c409:	bf 01 00 00 00       	mov    $0x1,%edi
    c40e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c415:	00 
    c416:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c41d:	00 
    c41e:	e8 4d 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c423:	48 89 c7             	mov    %rax,%rdi
    c426:	e8 c5 a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c42b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c432:	00 
    c433:	bf 01 00 00 00       	mov    $0x1,%edi
    c438:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c43f:	00 
    c440:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c447:	00 
    c448:	e8 23 99 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c44d:	48 89 c7             	mov    %rax,%rdi
    c450:	e8 9b a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c455:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c45c:	00 
    c45d:	bf 01 00 00 00       	mov    $0x1,%edi
    c462:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c469:	00 
    c46a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c471:	00 
    c472:	e8 f9 98 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c477:	48 89 c7             	mov    %rax,%rdi
    c47a:	e8 71 a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c47f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c486:	00 
    c487:	bf 01 00 00 00       	mov    $0x1,%edi
    c48c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c493:	00 
    c494:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c49b:	00 
    c49c:	e8 cf 98 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c4a1:	48 89 c7             	mov    %rax,%rdi
    c4a4:	e8 47 a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c4a9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c4b0:	00 
    c4b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c4bd:	00 
    c4be:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c4c5:	00 
    c4c6:	e8 a5 98 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c4cb:	48 89 c7             	mov    %rax,%rdi
    c4ce:	e8 1d a6 ff ff       	call   6af0 <fwp_rc_fresh>
    c4d3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c4da:	00 
    c4db:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c4e7:	00 
    c4e8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c4ef:	00 
    c4f0:	e8 7b 98 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c4f5:	48 8b 15 9c 86 01 00 	mov    0x1869c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c4fc:	49 89 c5             	mov    %rax,%r13
    c4ff:	48 2b 05 6a 86 01 00 	sub    0x1866a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c506:	48 c1 e2 10          	shl    $0x10,%rdx
    c50a:	48 39 d0             	cmp    %rdx,%rax
    c50d:	73 59                	jae    c568 <f0+0x13b8>
    c50f:	48 89 c2             	mov    %rax,%rdx
    c512:	48 c1 ea 10          	shr    $0x10,%rdx
    c516:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c51a:	48 8b 15 97 86 01 00 	mov    0x18697(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c521:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c525:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c529:	4d 85 e4             	test   %r12,%r12
    c52c:	74 3a                	je     c568 <f0+0x13b8>
    c52e:	0f b6 0a             	movzbl (%rdx),%ecx
    c531:	80 f9 02             	cmp    $0x2,%cl
    c534:	0f 84 c6 15 00 00    	je     db00 <f0+0x2950>
    c53a:	80 f9 01             	cmp    $0x1,%cl
    c53d:	75 29                	jne    c568 <f0+0x13b8>
    c53f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c542:	0f b7 c0             	movzwl %ax,%eax
    c545:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c548:	48 0f af c1          	imul   %rcx,%rax
    c54c:	48 c1 e8 20          	shr    $0x20,%rax
    c550:	48 39 d0             	cmp    %rdx,%rax
    c553:	73 13                	jae    c568 <f0+0x13b8>
    c555:	49 01 c4             	add    %rax,%r12
    c558:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c55d:	0f 84 99 17 00 00    	je     dcfc <f0+0x2b4c>
    c563:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c568:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c56f:	33 f3 bf 
    c572:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c579:	00 
    c57a:	bf 01 00 00 00       	mov    $0x1,%edi
    c57f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c586:	00 
    c587:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c58e:	00 
    c58f:	e8 dc 97 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c594:	48 8b 15 fd 85 01 00 	mov    0x185fd(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c59b:	49 89 c5             	mov    %rax,%r13
    c59e:	48 2b 05 cb 85 01 00 	sub    0x185cb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c5a5:	48 c1 e2 10          	shl    $0x10,%rdx
    c5a9:	48 39 d0             	cmp    %rdx,%rax
    c5ac:	73 59                	jae    c607 <f0+0x1457>
    c5ae:	48 89 c2             	mov    %rax,%rdx
    c5b1:	48 c1 ea 10          	shr    $0x10,%rdx
    c5b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5b9:	48 8b 15 f8 85 01 00 	mov    0x185f8(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c5c0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5c4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5c8:	4d 85 e4             	test   %r12,%r12
    c5cb:	74 3a                	je     c607 <f0+0x1457>
    c5cd:	0f b6 0a             	movzbl (%rdx),%ecx
    c5d0:	80 f9 02             	cmp    $0x2,%cl
    c5d3:	0f 84 17 15 00 00    	je     daf0 <f0+0x2940>
    c5d9:	80 f9 01             	cmp    $0x1,%cl
    c5dc:	75 29                	jne    c607 <f0+0x1457>
    c5de:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5e1:	0f b7 c0             	movzwl %ax,%eax
    c5e4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5e7:	48 0f af c1          	imul   %rcx,%rax
    c5eb:	48 c1 e8 20          	shr    $0x20,%rax
    c5ef:	48 39 d0             	cmp    %rdx,%rax
    c5f2:	73 13                	jae    c607 <f0+0x1457>
    c5f4:	49 01 c4             	add    %rax,%r12
    c5f7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5fc:	0f 84 07 17 00 00    	je     dd09 <f0+0x2b59>
    c602:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c607:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c60e:	00 f0 3f 
    c611:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c618:	00 
    c619:	bf 01 00 00 00       	mov    $0x1,%edi
    c61e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c625:	00 
    c626:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c62d:	00 
    c62e:	e8 3d 97 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c633:	48 8b 15 5e 85 01 00 	mov    0x1855e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c63a:	49 89 c5             	mov    %rax,%r13
    c63d:	48 2b 05 2c 85 01 00 	sub    0x1852c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c644:	48 c1 e2 10          	shl    $0x10,%rdx
    c648:	48 39 d0             	cmp    %rdx,%rax
    c64b:	73 59                	jae    c6a6 <f0+0x14f6>
    c64d:	48 89 c2             	mov    %rax,%rdx
    c650:	48 c1 ea 10          	shr    $0x10,%rdx
    c654:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c658:	48 8b 15 59 85 01 00 	mov    0x18559(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c65f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c663:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c667:	4d 85 e4             	test   %r12,%r12
    c66a:	74 3a                	je     c6a6 <f0+0x14f6>
    c66c:	0f b6 0a             	movzbl (%rdx),%ecx
    c66f:	80 f9 02             	cmp    $0x2,%cl
    c672:	0f 84 28 15 00 00    	je     dba0 <f0+0x29f0>
    c678:	80 f9 01             	cmp    $0x1,%cl
    c67b:	75 29                	jne    c6a6 <f0+0x14f6>
    c67d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c680:	0f b7 c0             	movzwl %ax,%eax
    c683:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c686:	48 0f af c1          	imul   %rcx,%rax
    c68a:	48 c1 e8 20          	shr    $0x20,%rax
    c68e:	48 39 d0             	cmp    %rdx,%rax
    c691:	73 13                	jae    c6a6 <f0+0x14f6>
    c693:	49 01 c4             	add    %rax,%r12
    c696:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c69b:	0f 84 75 16 00 00    	je     dd16 <f0+0x2b66>
    c6a1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6a6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6ad:	33 f3 bf 
    c6b0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c6b7:	00 
    c6b8:	bf 01 00 00 00       	mov    $0x1,%edi
    c6bd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c6c4:	00 
    c6c5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c6cc:	00 
    c6cd:	e8 9e 96 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c6d2:	48 8b 15 bf 84 01 00 	mov    0x184bf(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c6d9:	49 89 c5             	mov    %rax,%r13
    c6dc:	48 2b 05 8d 84 01 00 	sub    0x1848d(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c6e3:	48 c1 e2 10          	shl    $0x10,%rdx
    c6e7:	48 39 d0             	cmp    %rdx,%rax
    c6ea:	73 59                	jae    c745 <f0+0x1595>
    c6ec:	48 89 c2             	mov    %rax,%rdx
    c6ef:	48 c1 ea 10          	shr    $0x10,%rdx
    c6f3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6f7:	48 8b 15 ba 84 01 00 	mov    0x184ba(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c6fe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c702:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c706:	4d 85 e4             	test   %r12,%r12
    c709:	74 3a                	je     c745 <f0+0x1595>
    c70b:	0f b6 0a             	movzbl (%rdx),%ecx
    c70e:	80 f9 02             	cmp    $0x2,%cl
    c711:	0f 84 79 14 00 00    	je     db90 <f0+0x29e0>
    c717:	80 f9 01             	cmp    $0x1,%cl
    c71a:	75 29                	jne    c745 <f0+0x1595>
    c71c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c71f:	0f b7 c0             	movzwl %ax,%eax
    c722:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c725:	48 0f af c1          	imul   %rcx,%rax
    c729:	48 c1 e8 20          	shr    $0x20,%rax
    c72d:	48 39 d0             	cmp    %rdx,%rax
    c730:	73 13                	jae    c745 <f0+0x1595>
    c732:	49 01 c4             	add    %rax,%r12
    c735:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c73a:	0f 84 e3 15 00 00    	je     dd23 <f0+0x2b73>
    c740:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c745:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c74c:	00 f0 3f 
    c74f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c756:	00 
    c757:	bf 01 00 00 00       	mov    $0x1,%edi
    c75c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c763:	00 
    c764:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c76b:	00 
    c76c:	e8 ff 95 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c771:	48 8b 15 20 84 01 00 	mov    0x18420(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c778:	49 89 c5             	mov    %rax,%r13
    c77b:	48 2b 05 ee 83 01 00 	sub    0x183ee(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c782:	48 c1 e2 10          	shl    $0x10,%rdx
    c786:	48 39 d0             	cmp    %rdx,%rax
    c789:	73 59                	jae    c7e4 <f0+0x1634>
    c78b:	48 89 c2             	mov    %rax,%rdx
    c78e:	48 c1 ea 10          	shr    $0x10,%rdx
    c792:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c796:	48 8b 15 1b 84 01 00 	mov    0x1841b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c79d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7a1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7a5:	4d 85 e4             	test   %r12,%r12
    c7a8:	74 3a                	je     c7e4 <f0+0x1634>
    c7aa:	0f b6 0a             	movzbl (%rdx),%ecx
    c7ad:	80 f9 02             	cmp    $0x2,%cl
    c7b0:	0f 84 ca 13 00 00    	je     db80 <f0+0x29d0>
    c7b6:	80 f9 01             	cmp    $0x1,%cl
    c7b9:	75 29                	jne    c7e4 <f0+0x1634>
    c7bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7be:	0f b7 c0             	movzwl %ax,%eax
    c7c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7c4:	48 0f af c1          	imul   %rcx,%rax
    c7c8:	48 c1 e8 20          	shr    $0x20,%rax
    c7cc:	48 39 d0             	cmp    %rdx,%rax
    c7cf:	73 13                	jae    c7e4 <f0+0x1634>
    c7d1:	49 01 c4             	add    %rax,%r12
    c7d4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7d9:	0f 84 51 15 00 00    	je     dd30 <f0+0x2b80>
    c7df:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7e4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7eb:	33 f3 bf 
    c7ee:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c7f5:	00 
    c7f6:	bf 01 00 00 00       	mov    $0x1,%edi
    c7fb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c802:	00 
    c803:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c80a:	00 
    c80b:	e8 60 95 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c810:	48 8b 15 81 83 01 00 	mov    0x18381(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c817:	49 89 c5             	mov    %rax,%r13
    c81a:	48 2b 05 4f 83 01 00 	sub    0x1834f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c821:	48 c1 e2 10          	shl    $0x10,%rdx
    c825:	48 39 d0             	cmp    %rdx,%rax
    c828:	73 59                	jae    c883 <f0+0x16d3>
    c82a:	48 89 c2             	mov    %rax,%rdx
    c82d:	48 c1 ea 10          	shr    $0x10,%rdx
    c831:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c835:	48 8b 15 7c 83 01 00 	mov    0x1837c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c83c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c840:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c844:	4d 85 e4             	test   %r12,%r12
    c847:	74 3a                	je     c883 <f0+0x16d3>
    c849:	0f b6 0a             	movzbl (%rdx),%ecx
    c84c:	80 f9 02             	cmp    $0x2,%cl
    c84f:	0f 84 1b 13 00 00    	je     db70 <f0+0x29c0>
    c855:	80 f9 01             	cmp    $0x1,%cl
    c858:	75 29                	jne    c883 <f0+0x16d3>
    c85a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c85d:	0f b7 c0             	movzwl %ax,%eax
    c860:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c863:	48 0f af c1          	imul   %rcx,%rax
    c867:	48 c1 e8 20          	shr    $0x20,%rax
    c86b:	48 39 d0             	cmp    %rdx,%rax
    c86e:	73 13                	jae    c883 <f0+0x16d3>
    c870:	49 01 c4             	add    %rax,%r12
    c873:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c878:	0f 84 bf 14 00 00    	je     dd3d <f0+0x2b8d>
    c87e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c883:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c88a:	00 f0 3f 
    c88d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c894:	00 
    c895:	bf 01 00 00 00       	mov    $0x1,%edi
    c89a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c8a1:	00 
    c8a2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c8a9:	00 
    c8aa:	e8 c1 94 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c8af:	48 8b 15 e2 82 01 00 	mov    0x182e2(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c8b6:	49 89 c5             	mov    %rax,%r13
    c8b9:	48 2b 05 b0 82 01 00 	sub    0x182b0(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c8c0:	48 c1 e2 10          	shl    $0x10,%rdx
    c8c4:	48 39 d0             	cmp    %rdx,%rax
    c8c7:	73 59                	jae    c922 <f0+0x1772>
    c8c9:	48 89 c2             	mov    %rax,%rdx
    c8cc:	48 c1 ea 10          	shr    $0x10,%rdx
    c8d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8d4:	48 8b 15 dd 82 01 00 	mov    0x182dd(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c8db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8df:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8e3:	4d 85 e4             	test   %r12,%r12
    c8e6:	74 3a                	je     c922 <f0+0x1772>
    c8e8:	0f b6 0a             	movzbl (%rdx),%ecx
    c8eb:	80 f9 02             	cmp    $0x2,%cl
    c8ee:	0f 84 6c 12 00 00    	je     db60 <f0+0x29b0>
    c8f4:	80 f9 01             	cmp    $0x1,%cl
    c8f7:	75 29                	jne    c922 <f0+0x1772>
    c8f9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8fc:	0f b7 c0             	movzwl %ax,%eax
    c8ff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c902:	48 0f af c1          	imul   %rcx,%rax
    c906:	48 c1 e8 20          	shr    $0x20,%rax
    c90a:	48 39 d0             	cmp    %rdx,%rax
    c90d:	73 13                	jae    c922 <f0+0x1772>
    c90f:	49 01 c4             	add    %rax,%r12
    c912:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c917:	0f 84 2d 14 00 00    	je     dd4a <f0+0x2b9a>
    c91d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c922:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c929:	33 f3 bf 
    c92c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c933:	00 
    c934:	bf 01 00 00 00       	mov    $0x1,%edi
    c939:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c940:	00 
    c941:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c948:	00 
    c949:	e8 22 94 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c94e:	48 8b 15 43 82 01 00 	mov    0x18243(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c955:	49 89 c5             	mov    %rax,%r13
    c958:	48 2b 05 11 82 01 00 	sub    0x18211(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c95f:	48 c1 e2 10          	shl    $0x10,%rdx
    c963:	48 39 d0             	cmp    %rdx,%rax
    c966:	73 59                	jae    c9c1 <f0+0x1811>
    c968:	48 89 c2             	mov    %rax,%rdx
    c96b:	48 c1 ea 10          	shr    $0x10,%rdx
    c96f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c973:	48 8b 15 3e 82 01 00 	mov    0x1823e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c97a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c97e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c982:	4d 85 e4             	test   %r12,%r12
    c985:	74 3a                	je     c9c1 <f0+0x1811>
    c987:	0f b6 0a             	movzbl (%rdx),%ecx
    c98a:	80 f9 02             	cmp    $0x2,%cl
    c98d:	0f 84 bd 11 00 00    	je     db50 <f0+0x29a0>
    c993:	80 f9 01             	cmp    $0x1,%cl
    c996:	75 29                	jne    c9c1 <f0+0x1811>
    c998:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c99b:	0f b7 c0             	movzwl %ax,%eax
    c99e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9a1:	48 0f af c1          	imul   %rcx,%rax
    c9a5:	48 c1 e8 20          	shr    $0x20,%rax
    c9a9:	48 39 d0             	cmp    %rdx,%rax
    c9ac:	73 13                	jae    c9c1 <f0+0x1811>
    c9ae:	49 01 c4             	add    %rax,%r12
    c9b1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9b6:	0f 84 9b 13 00 00    	je     dd57 <f0+0x2ba7>
    c9bc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9c1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9c8:	00 f0 3f 
    c9cb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c9d2:	00 
    c9d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c9d8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c9df:	00 
    c9e0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c9e7:	00 
    c9e8:	e8 83 93 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    c9ed:	48 8b 15 a4 81 01 00 	mov    0x181a4(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c9f4:	49 89 c5             	mov    %rax,%r13
    c9f7:	48 2b 05 72 81 01 00 	sub    0x18172(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c9fe:	48 c1 e2 10          	shl    $0x10,%rdx
    ca02:	48 39 d0             	cmp    %rdx,%rax
    ca05:	73 59                	jae    ca60 <f0+0x18b0>
    ca07:	48 89 c2             	mov    %rax,%rdx
    ca0a:	48 c1 ea 10          	shr    $0x10,%rdx
    ca0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca12:	48 8b 15 9f 81 01 00 	mov    0x1819f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ca19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca1d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca21:	4d 85 e4             	test   %r12,%r12
    ca24:	74 3a                	je     ca60 <f0+0x18b0>
    ca26:	0f b6 0a             	movzbl (%rdx),%ecx
    ca29:	80 f9 02             	cmp    $0x2,%cl
    ca2c:	0f 84 0e 11 00 00    	je     db40 <f0+0x2990>
    ca32:	80 f9 01             	cmp    $0x1,%cl
    ca35:	75 29                	jne    ca60 <f0+0x18b0>
    ca37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca3a:	0f b7 c0             	movzwl %ax,%eax
    ca3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca40:	48 0f af c1          	imul   %rcx,%rax
    ca44:	48 c1 e8 20          	shr    $0x20,%rax
    ca48:	48 39 d0             	cmp    %rdx,%rax
    ca4b:	73 13                	jae    ca60 <f0+0x18b0>
    ca4d:	49 01 c4             	add    %rax,%r12
    ca50:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca55:	0f 84 09 13 00 00    	je     dd64 <f0+0x2bb4>
    ca5b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca60:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca67:	33 f3 bf 
    ca6a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    ca71:	00 
    ca72:	bf 01 00 00 00       	mov    $0x1,%edi
    ca77:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    ca7e:	00 
    ca7f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    ca86:	00 
    ca87:	e8 e4 92 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ca8c:	48 8b 15 05 81 01 00 	mov    0x18105(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ca93:	49 89 c5             	mov    %rax,%r13
    ca96:	48 2b 05 d3 80 01 00 	sub    0x180d3(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ca9d:	48 c1 e2 10          	shl    $0x10,%rdx
    caa1:	48 39 d0             	cmp    %rdx,%rax
    caa4:	73 59                	jae    caff <f0+0x194f>
    caa6:	48 89 c2             	mov    %rax,%rdx
    caa9:	48 c1 ea 10          	shr    $0x10,%rdx
    caad:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cab1:	48 8b 15 00 81 01 00 	mov    0x18100(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cab8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cabc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cac0:	4d 85 e4             	test   %r12,%r12
    cac3:	74 3a                	je     caff <f0+0x194f>
    cac5:	0f b6 0a             	movzbl (%rdx),%ecx
    cac8:	80 f9 02             	cmp    $0x2,%cl
    cacb:	0f 84 5f 10 00 00    	je     db30 <f0+0x2980>
    cad1:	80 f9 01             	cmp    $0x1,%cl
    cad4:	75 29                	jne    caff <f0+0x194f>
    cad6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cad9:	0f b7 c0             	movzwl %ax,%eax
    cadc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cadf:	48 0f af c1          	imul   %rcx,%rax
    cae3:	48 c1 e8 20          	shr    $0x20,%rax
    cae7:	48 39 d0             	cmp    %rdx,%rax
    caea:	73 13                	jae    caff <f0+0x194f>
    caec:	49 01 c4             	add    %rax,%r12
    caef:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caf4:	0f 84 77 12 00 00    	je     dd71 <f0+0x2bc1>
    cafa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    caff:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb06:	00 f0 3f 
    cb09:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cb10:	00 
    cb11:	bf 01 00 00 00       	mov    $0x1,%edi
    cb16:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cb1d:	00 
    cb1e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cb25:	00 
    cb26:	e8 45 92 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cb2b:	48 8b 15 66 80 01 00 	mov    0x18066(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cb32:	49 89 c5             	mov    %rax,%r13
    cb35:	48 2b 05 34 80 01 00 	sub    0x18034(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cb3c:	48 c1 e2 10          	shl    $0x10,%rdx
    cb40:	48 39 d0             	cmp    %rdx,%rax
    cb43:	73 59                	jae    cb9e <f0+0x19ee>
    cb45:	48 89 c2             	mov    %rax,%rdx
    cb48:	48 c1 ea 10          	shr    $0x10,%rdx
    cb4c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb50:	48 8b 15 61 80 01 00 	mov    0x18061(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cb57:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb5b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb5f:	4d 85 e4             	test   %r12,%r12
    cb62:	74 3a                	je     cb9e <f0+0x19ee>
    cb64:	0f b6 0a             	movzbl (%rdx),%ecx
    cb67:	80 f9 02             	cmp    $0x2,%cl
    cb6a:	0f 84 40 0f 00 00    	je     dab0 <f0+0x2900>
    cb70:	80 f9 01             	cmp    $0x1,%cl
    cb73:	75 29                	jne    cb9e <f0+0x19ee>
    cb75:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb78:	0f b7 c0             	movzwl %ax,%eax
    cb7b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb7e:	48 0f af c1          	imul   %rcx,%rax
    cb82:	48 c1 e8 20          	shr    $0x20,%rax
    cb86:	48 39 d0             	cmp    %rdx,%rax
    cb89:	73 13                	jae    cb9e <f0+0x19ee>
    cb8b:	49 01 c4             	add    %rax,%r12
    cb8e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb93:	0f 84 e5 11 00 00    	je     dd7e <f0+0x2bce>
    cb99:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb9e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cba5:	33 f3 bf 
    cba8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cbaf:	00 
    cbb0:	bf 01 00 00 00       	mov    $0x1,%edi
    cbb5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cbbc:	00 
    cbbd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cbc4:	00 
    cbc5:	e8 a6 91 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cbca:	48 8b 15 c7 7f 01 00 	mov    0x17fc7(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cbd1:	49 89 c5             	mov    %rax,%r13
    cbd4:	48 2b 05 95 7f 01 00 	sub    0x17f95(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cbdb:	48 c1 e2 10          	shl    $0x10,%rdx
    cbdf:	48 39 d0             	cmp    %rdx,%rax
    cbe2:	73 59                	jae    cc3d <f0+0x1a8d>
    cbe4:	48 89 c2             	mov    %rax,%rdx
    cbe7:	48 c1 ea 10          	shr    $0x10,%rdx
    cbeb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbef:	48 8b 15 c2 7f 01 00 	mov    0x17fc2(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cbf6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbfa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbfe:	4d 85 e4             	test   %r12,%r12
    cc01:	74 3a                	je     cc3d <f0+0x1a8d>
    cc03:	0f b6 0a             	movzbl (%rdx),%ecx
    cc06:	80 f9 02             	cmp    $0x2,%cl
    cc09:	0f 84 91 0e 00 00    	je     daa0 <f0+0x28f0>
    cc0f:	80 f9 01             	cmp    $0x1,%cl
    cc12:	75 29                	jne    cc3d <f0+0x1a8d>
    cc14:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc17:	0f b7 c0             	movzwl %ax,%eax
    cc1a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc1d:	48 0f af c1          	imul   %rcx,%rax
    cc21:	48 c1 e8 20          	shr    $0x20,%rax
    cc25:	48 39 d0             	cmp    %rdx,%rax
    cc28:	73 13                	jae    cc3d <f0+0x1a8d>
    cc2a:	49 01 c4             	add    %rax,%r12
    cc2d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc32:	0f 84 53 11 00 00    	je     dd8b <f0+0x2bdb>
    cc38:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc3d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc44:	00 f0 3f 
    cc47:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cc4e:	00 
    cc4f:	bf 01 00 00 00       	mov    $0x1,%edi
    cc54:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cc5b:	00 
    cc5c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cc63:	00 
    cc64:	e8 07 91 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cc69:	48 8b 15 28 7f 01 00 	mov    0x17f28(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cc70:	49 89 c5             	mov    %rax,%r13
    cc73:	48 2b 05 f6 7e 01 00 	sub    0x17ef6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cc7a:	48 c1 e2 10          	shl    $0x10,%rdx
    cc7e:	48 39 d0             	cmp    %rdx,%rax
    cc81:	73 59                	jae    ccdc <f0+0x1b2c>
    cc83:	48 89 c2             	mov    %rax,%rdx
    cc86:	48 c1 ea 10          	shr    $0x10,%rdx
    cc8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc8e:	48 8b 15 23 7f 01 00 	mov    0x17f23(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cc95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc99:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc9d:	4d 85 e4             	test   %r12,%r12
    cca0:	74 3a                	je     ccdc <f0+0x1b2c>
    cca2:	0f b6 0a             	movzbl (%rdx),%ecx
    cca5:	80 f9 02             	cmp    $0x2,%cl
    cca8:	0f 84 e2 0d 00 00    	je     da90 <f0+0x28e0>
    ccae:	80 f9 01             	cmp    $0x1,%cl
    ccb1:	75 29                	jne    ccdc <f0+0x1b2c>
    ccb3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccb6:	0f b7 c0             	movzwl %ax,%eax
    ccb9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccbc:	48 0f af c1          	imul   %rcx,%rax
    ccc0:	48 c1 e8 20          	shr    $0x20,%rax
    ccc4:	48 39 d0             	cmp    %rdx,%rax
    ccc7:	73 13                	jae    ccdc <f0+0x1b2c>
    ccc9:	49 01 c4             	add    %rax,%r12
    cccc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccd1:	0f 84 c1 10 00 00    	je     dd98 <f0+0x2be8>
    ccd7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccdc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cce3:	33 f3 bf 
    cce6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cced:	00 
    ccee:	bf 01 00 00 00       	mov    $0x1,%edi
    ccf3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    ccfa:	00 
    ccfb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cd02:	00 
    cd03:	e8 68 90 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cd08:	48 8b 15 89 7e 01 00 	mov    0x17e89(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cd0f:	49 89 c5             	mov    %rax,%r13
    cd12:	48 2b 05 57 7e 01 00 	sub    0x17e57(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cd19:	48 c1 e2 10          	shl    $0x10,%rdx
    cd1d:	48 39 d0             	cmp    %rdx,%rax
    cd20:	73 59                	jae    cd7b <f0+0x1bcb>
    cd22:	48 89 c2             	mov    %rax,%rdx
    cd25:	48 c1 ea 10          	shr    $0x10,%rdx
    cd29:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd2d:	48 8b 15 84 7e 01 00 	mov    0x17e84(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cd34:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd38:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd3c:	4d 85 e4             	test   %r12,%r12
    cd3f:	74 3a                	je     cd7b <f0+0x1bcb>
    cd41:	0f b6 0a             	movzbl (%rdx),%ecx
    cd44:	80 f9 02             	cmp    $0x2,%cl
    cd47:	0f 84 33 0d 00 00    	je     da80 <f0+0x28d0>
    cd4d:	80 f9 01             	cmp    $0x1,%cl
    cd50:	75 29                	jne    cd7b <f0+0x1bcb>
    cd52:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd55:	0f b7 c0             	movzwl %ax,%eax
    cd58:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd5b:	48 0f af c1          	imul   %rcx,%rax
    cd5f:	48 c1 e8 20          	shr    $0x20,%rax
    cd63:	48 39 d0             	cmp    %rdx,%rax
    cd66:	73 13                	jae    cd7b <f0+0x1bcb>
    cd68:	49 01 c4             	add    %rax,%r12
    cd6b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd70:	0f 84 2f 10 00 00    	je     dda5 <f0+0x2bf5>
    cd76:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd7b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd82:	00 f0 3f 
    cd85:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cd8c:	00 
    cd8d:	bf 01 00 00 00       	mov    $0x1,%edi
    cd92:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cd99:	00 
    cd9a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cda1:	00 
    cda2:	e8 c9 8f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cda7:	48 8b 15 ea 7d 01 00 	mov    0x17dea(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cdae:	49 89 c5             	mov    %rax,%r13
    cdb1:	48 2b 05 b8 7d 01 00 	sub    0x17db8(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cdb8:	48 c1 e2 10          	shl    $0x10,%rdx
    cdbc:	48 39 d0             	cmp    %rdx,%rax
    cdbf:	73 59                	jae    ce1a <f0+0x1c6a>
    cdc1:	48 89 c2             	mov    %rax,%rdx
    cdc4:	48 c1 ea 10          	shr    $0x10,%rdx
    cdc8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdcc:	48 8b 15 e5 7d 01 00 	mov    0x17de5(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cdd3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdd7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cddb:	4d 85 e4             	test   %r12,%r12
    cdde:	74 3a                	je     ce1a <f0+0x1c6a>
    cde0:	0f b6 0a             	movzbl (%rdx),%ecx
    cde3:	80 f9 02             	cmp    $0x2,%cl
    cde6:	0f 84 84 0c 00 00    	je     da70 <f0+0x28c0>
    cdec:	80 f9 01             	cmp    $0x1,%cl
    cdef:	75 29                	jne    ce1a <f0+0x1c6a>
    cdf1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdf4:	0f b7 c0             	movzwl %ax,%eax
    cdf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdfa:	48 0f af c1          	imul   %rcx,%rax
    cdfe:	48 c1 e8 20          	shr    $0x20,%rax
    ce02:	48 39 d0             	cmp    %rdx,%rax
    ce05:	73 13                	jae    ce1a <f0+0x1c6a>
    ce07:	49 01 c4             	add    %rax,%r12
    ce0a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce0f:	0f 84 9d 0f 00 00    	je     ddb2 <f0+0x2c02>
    ce15:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce1a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce21:	33 f3 bf 
    ce24:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    ce2b:	00 
    ce2c:	bf 01 00 00 00       	mov    $0x1,%edi
    ce31:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    ce38:	00 
    ce39:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    ce40:	00 
    ce41:	e8 2a 8f ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    ce46:	48 8b 15 4b 7d 01 00 	mov    0x17d4b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ce4d:	49 89 c5             	mov    %rax,%r13
    ce50:	48 2b 05 19 7d 01 00 	sub    0x17d19(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ce57:	48 c1 e2 10          	shl    $0x10,%rdx
    ce5b:	48 39 d0             	cmp    %rdx,%rax
    ce5e:	73 59                	jae    ceb9 <f0+0x1d09>
    ce60:	48 89 c2             	mov    %rax,%rdx
    ce63:	48 c1 ea 10          	shr    $0x10,%rdx
    ce67:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce6b:	48 8b 15 46 7d 01 00 	mov    0x17d46(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ce72:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce76:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce7a:	4d 85 e4             	test   %r12,%r12
    ce7d:	74 3a                	je     ceb9 <f0+0x1d09>
    ce7f:	0f b6 0a             	movzbl (%rdx),%ecx
    ce82:	80 f9 02             	cmp    $0x2,%cl
    ce85:	0f 84 d5 0b 00 00    	je     da60 <f0+0x28b0>
    ce8b:	80 f9 01             	cmp    $0x1,%cl
    ce8e:	75 29                	jne    ceb9 <f0+0x1d09>
    ce90:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce93:	0f b7 c0             	movzwl %ax,%eax
    ce96:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce99:	48 0f af c1          	imul   %rcx,%rax
    ce9d:	48 c1 e8 20          	shr    $0x20,%rax
    cea1:	48 39 d0             	cmp    %rdx,%rax
    cea4:	73 13                	jae    ceb9 <f0+0x1d09>
    cea6:	49 01 c4             	add    %rax,%r12
    cea9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ceae:	0f 84 0b 0f 00 00    	je     ddbf <f0+0x2c0f>
    ceb4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceb9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cec0:	00 f0 3f 
    cec3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    ceca:	00 
    cecb:	bf 01 00 00 00       	mov    $0x1,%edi
    ced0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    ced7:	00 
    ced8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cedf:	00 
    cee0:	e8 8b 8e ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cee5:	48 8b 15 ac 7c 01 00 	mov    0x17cac(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ceec:	49 89 c5             	mov    %rax,%r13
    ceef:	48 2b 05 7a 7c 01 00 	sub    0x17c7a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cef6:	48 c1 e2 10          	shl    $0x10,%rdx
    cefa:	48 39 d0             	cmp    %rdx,%rax
    cefd:	73 59                	jae    cf58 <f0+0x1da8>
    ceff:	48 89 c2             	mov    %rax,%rdx
    cf02:	48 c1 ea 10          	shr    $0x10,%rdx
    cf06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf0a:	48 8b 15 a7 7c 01 00 	mov    0x17ca7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cf11:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf15:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf19:	4d 85 e4             	test   %r12,%r12
    cf1c:	74 3a                	je     cf58 <f0+0x1da8>
    cf1e:	0f b6 0a             	movzbl (%rdx),%ecx
    cf21:	80 f9 02             	cmp    $0x2,%cl
    cf24:	0f 84 26 0b 00 00    	je     da50 <f0+0x28a0>
    cf2a:	80 f9 01             	cmp    $0x1,%cl
    cf2d:	75 29                	jne    cf58 <f0+0x1da8>
    cf2f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf32:	0f b7 c0             	movzwl %ax,%eax
    cf35:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf38:	48 0f af c1          	imul   %rcx,%rax
    cf3c:	48 c1 e8 20          	shr    $0x20,%rax
    cf40:	48 39 d0             	cmp    %rdx,%rax
    cf43:	73 13                	jae    cf58 <f0+0x1da8>
    cf45:	49 01 c4             	add    %rax,%r12
    cf48:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf4d:	0f 84 79 0e 00 00    	je     ddcc <f0+0x2c1c>
    cf53:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf58:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf5f:	33 f3 bf 
    cf62:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    cf69:	00 
    cf6a:	bf 01 00 00 00       	mov    $0x1,%edi
    cf6f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    cf76:	00 
    cf77:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    cf7e:	00 
    cf7f:	e8 ec 8d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    cf84:	48 8b 15 0d 7c 01 00 	mov    0x17c0d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cf8b:	49 89 c5             	mov    %rax,%r13
    cf8e:	48 2b 05 db 7b 01 00 	sub    0x17bdb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cf95:	48 c1 e2 10          	shl    $0x10,%rdx
    cf99:	48 39 d0             	cmp    %rdx,%rax
    cf9c:	73 59                	jae    cff7 <f0+0x1e47>
    cf9e:	48 89 c2             	mov    %rax,%rdx
    cfa1:	48 c1 ea 10          	shr    $0x10,%rdx
    cfa5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfa9:	48 8b 15 08 7c 01 00 	mov    0x17c08(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cfb0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfb4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfb8:	4d 85 e4             	test   %r12,%r12
    cfbb:	74 3a                	je     cff7 <f0+0x1e47>
    cfbd:	0f b6 0a             	movzbl (%rdx),%ecx
    cfc0:	80 f9 02             	cmp    $0x2,%cl
    cfc3:	0f 84 77 0a 00 00    	je     da40 <f0+0x2890>
    cfc9:	80 f9 01             	cmp    $0x1,%cl
    cfcc:	75 29                	jne    cff7 <f0+0x1e47>
    cfce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfd1:	0f b7 c0             	movzwl %ax,%eax
    cfd4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfd7:	48 0f af c1          	imul   %rcx,%rax
    cfdb:	48 c1 e8 20          	shr    $0x20,%rax
    cfdf:	48 39 d0             	cmp    %rdx,%rax
    cfe2:	73 13                	jae    cff7 <f0+0x1e47>
    cfe4:	49 01 c4             	add    %rax,%r12
    cfe7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfec:	0f 84 e7 0d 00 00    	je     ddd9 <f0+0x2c29>
    cff2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cff7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cffe:	00 f0 3f 
    d001:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d008:	00 
    d009:	bf 01 00 00 00       	mov    $0x1,%edi
    d00e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d015:	00 
    d016:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d01d:	00 
    d01e:	e8 4d 8d ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d023:	48 8b 15 6e 7b 01 00 	mov    0x17b6e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d02a:	49 89 c5             	mov    %rax,%r13
    d02d:	48 2b 05 3c 7b 01 00 	sub    0x17b3c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d034:	48 c1 e2 10          	shl    $0x10,%rdx
    d038:	48 39 d0             	cmp    %rdx,%rax
    d03b:	73 59                	jae    d096 <f0+0x1ee6>
    d03d:	48 89 c2             	mov    %rax,%rdx
    d040:	48 c1 ea 10          	shr    $0x10,%rdx
    d044:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d048:	48 8b 15 69 7b 01 00 	mov    0x17b69(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d04f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d053:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d057:	4d 85 e4             	test   %r12,%r12
    d05a:	74 3a                	je     d096 <f0+0x1ee6>
    d05c:	0f b6 0a             	movzbl (%rdx),%ecx
    d05f:	80 f9 02             	cmp    $0x2,%cl
    d062:	0f 84 38 0c 00 00    	je     dca0 <f0+0x2af0>
    d068:	80 f9 01             	cmp    $0x1,%cl
    d06b:	75 29                	jne    d096 <f0+0x1ee6>
    d06d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d070:	0f b7 c0             	movzwl %ax,%eax
    d073:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d076:	48 0f af c1          	imul   %rcx,%rax
    d07a:	48 c1 e8 20          	shr    $0x20,%rax
    d07e:	48 39 d0             	cmp    %rdx,%rax
    d081:	73 13                	jae    d096 <f0+0x1ee6>
    d083:	49 01 c4             	add    %rax,%r12
    d086:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d08b:	0f 84 55 0d 00 00    	je     dde6 <f0+0x2c36>
    d091:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d096:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d09d:	33 f3 bf 
    d0a0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d0a7:	00 
    d0a8:	bf 01 00 00 00       	mov    $0x1,%edi
    d0ad:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d0b4:	00 
    d0b5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d0bc:	00 
    d0bd:	e8 ae 8c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d0c2:	48 8b 15 cf 7a 01 00 	mov    0x17acf(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d0c9:	49 89 c5             	mov    %rax,%r13
    d0cc:	48 2b 05 9d 7a 01 00 	sub    0x17a9d(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d0d3:	48 c1 e2 10          	shl    $0x10,%rdx
    d0d7:	48 39 d0             	cmp    %rdx,%rax
    d0da:	73 59                	jae    d135 <f0+0x1f85>
    d0dc:	48 89 c2             	mov    %rax,%rdx
    d0df:	48 c1 ea 10          	shr    $0x10,%rdx
    d0e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0e7:	48 8b 15 ca 7a 01 00 	mov    0x17aca(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d0ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0f6:	4d 85 e4             	test   %r12,%r12
    d0f9:	74 3a                	je     d135 <f0+0x1f85>
    d0fb:	0f b6 0a             	movzbl (%rdx),%ecx
    d0fe:	80 f9 02             	cmp    $0x2,%cl
    d101:	0f 84 89 0b 00 00    	je     dc90 <f0+0x2ae0>
    d107:	80 f9 01             	cmp    $0x1,%cl
    d10a:	75 29                	jne    d135 <f0+0x1f85>
    d10c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d10f:	0f b7 c0             	movzwl %ax,%eax
    d112:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d115:	48 0f af c1          	imul   %rcx,%rax
    d119:	48 c1 e8 20          	shr    $0x20,%rax
    d11d:	48 39 d0             	cmp    %rdx,%rax
    d120:	73 13                	jae    d135 <f0+0x1f85>
    d122:	49 01 c4             	add    %rax,%r12
    d125:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d12a:	0f 84 c3 0c 00 00    	je     ddf3 <f0+0x2c43>
    d130:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d135:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d13c:	00 f0 3f 
    d13f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d146:	00 
    d147:	bf 01 00 00 00       	mov    $0x1,%edi
    d14c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d153:	00 
    d154:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d15b:	00 
    d15c:	e8 0f 8c ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d161:	48 8b 15 30 7a 01 00 	mov    0x17a30(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d168:	49 89 c5             	mov    %rax,%r13
    d16b:	48 2b 05 fe 79 01 00 	sub    0x179fe(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d172:	48 c1 e2 10          	shl    $0x10,%rdx
    d176:	48 39 d0             	cmp    %rdx,%rax
    d179:	73 59                	jae    d1d4 <f0+0x2024>
    d17b:	48 89 c2             	mov    %rax,%rdx
    d17e:	48 c1 ea 10          	shr    $0x10,%rdx
    d182:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d186:	48 8b 15 2b 7a 01 00 	mov    0x17a2b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d18d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d191:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d195:	4d 85 e4             	test   %r12,%r12
    d198:	74 3a                	je     d1d4 <f0+0x2024>
    d19a:	0f b6 0a             	movzbl (%rdx),%ecx
    d19d:	80 f9 02             	cmp    $0x2,%cl
    d1a0:	0f 84 da 0a 00 00    	je     dc80 <f0+0x2ad0>
    d1a6:	80 f9 01             	cmp    $0x1,%cl
    d1a9:	75 29                	jne    d1d4 <f0+0x2024>
    d1ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1ae:	0f b7 c0             	movzwl %ax,%eax
    d1b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1b4:	48 0f af c1          	imul   %rcx,%rax
    d1b8:	48 c1 e8 20          	shr    $0x20,%rax
    d1bc:	48 39 d0             	cmp    %rdx,%rax
    d1bf:	73 13                	jae    d1d4 <f0+0x2024>
    d1c1:	49 01 c4             	add    %rax,%r12
    d1c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1c9:	0f 84 31 0c 00 00    	je     de00 <f0+0x2c50>
    d1cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1db:	33 f3 bf 
    d1de:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d1e5:	00 
    d1e6:	bf 01 00 00 00       	mov    $0x1,%edi
    d1eb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d1f2:	00 
    d1f3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d1fa:	00 
    d1fb:	e8 70 8b ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d200:	48 8b 15 91 79 01 00 	mov    0x17991(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d207:	49 89 c5             	mov    %rax,%r13
    d20a:	48 2b 05 5f 79 01 00 	sub    0x1795f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d211:	48 c1 e2 10          	shl    $0x10,%rdx
    d215:	48 39 d0             	cmp    %rdx,%rax
    d218:	73 59                	jae    d273 <f0+0x20c3>
    d21a:	48 89 c2             	mov    %rax,%rdx
    d21d:	48 c1 ea 10          	shr    $0x10,%rdx
    d221:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d225:	48 8b 15 8c 79 01 00 	mov    0x1798c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d22c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d230:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d234:	4d 85 e4             	test   %r12,%r12
    d237:	74 3a                	je     d273 <f0+0x20c3>
    d239:	0f b6 0a             	movzbl (%rdx),%ecx
    d23c:	80 f9 02             	cmp    $0x2,%cl
    d23f:	0f 84 2b 0a 00 00    	je     dc70 <f0+0x2ac0>
    d245:	80 f9 01             	cmp    $0x1,%cl
    d248:	75 29                	jne    d273 <f0+0x20c3>
    d24a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d24d:	0f b7 c0             	movzwl %ax,%eax
    d250:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d253:	48 0f af c1          	imul   %rcx,%rax
    d257:	48 c1 e8 20          	shr    $0x20,%rax
    d25b:	48 39 d0             	cmp    %rdx,%rax
    d25e:	73 13                	jae    d273 <f0+0x20c3>
    d260:	49 01 c4             	add    %rax,%r12
    d263:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d268:	0f 84 9f 0b 00 00    	je     de0d <f0+0x2c5d>
    d26e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d273:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d27a:	00 f0 3f 
    d27d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d284:	00 
    d285:	bf 01 00 00 00       	mov    $0x1,%edi
    d28a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d291:	00 
    d292:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d299:	00 
    d29a:	e8 d1 8a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d29f:	48 8b 15 f2 78 01 00 	mov    0x178f2(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d2a6:	49 89 c5             	mov    %rax,%r13
    d2a9:	48 2b 05 c0 78 01 00 	sub    0x178c0(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d2b0:	48 c1 e2 10          	shl    $0x10,%rdx
    d2b4:	48 39 d0             	cmp    %rdx,%rax
    d2b7:	73 59                	jae    d312 <f0+0x2162>
    d2b9:	48 89 c2             	mov    %rax,%rdx
    d2bc:	48 c1 ea 10          	shr    $0x10,%rdx
    d2c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2c4:	48 8b 15 ed 78 01 00 	mov    0x178ed(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d2cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2d3:	4d 85 e4             	test   %r12,%r12
    d2d6:	74 3a                	je     d312 <f0+0x2162>
    d2d8:	0f b6 0a             	movzbl (%rdx),%ecx
    d2db:	80 f9 02             	cmp    $0x2,%cl
    d2de:	0f 84 7c 09 00 00    	je     dc60 <f0+0x2ab0>
    d2e4:	80 f9 01             	cmp    $0x1,%cl
    d2e7:	75 29                	jne    d312 <f0+0x2162>
    d2e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2ec:	0f b7 c0             	movzwl %ax,%eax
    d2ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2f2:	48 0f af c1          	imul   %rcx,%rax
    d2f6:	48 c1 e8 20          	shr    $0x20,%rax
    d2fa:	48 39 d0             	cmp    %rdx,%rax
    d2fd:	73 13                	jae    d312 <f0+0x2162>
    d2ff:	49 01 c4             	add    %rax,%r12
    d302:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d307:	0f 84 0d 0b 00 00    	je     de1a <f0+0x2c6a>
    d30d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d312:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d319:	33 f3 bf 
    d31c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d323:	00 
    d324:	bf 01 00 00 00       	mov    $0x1,%edi
    d329:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d330:	00 
    d331:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d338:	00 
    d339:	e8 32 8a ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d33e:	48 8b 15 53 78 01 00 	mov    0x17853(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d345:	49 89 c5             	mov    %rax,%r13
    d348:	48 2b 05 21 78 01 00 	sub    0x17821(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d34f:	48 c1 e2 10          	shl    $0x10,%rdx
    d353:	48 39 d0             	cmp    %rdx,%rax
    d356:	73 59                	jae    d3b1 <f0+0x2201>
    d358:	48 89 c2             	mov    %rax,%rdx
    d35b:	48 c1 ea 10          	shr    $0x10,%rdx
    d35f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d363:	48 8b 15 4e 78 01 00 	mov    0x1784e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d36a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d36e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d372:	4d 85 e4             	test   %r12,%r12
    d375:	74 3a                	je     d3b1 <f0+0x2201>
    d377:	0f b6 0a             	movzbl (%rdx),%ecx
    d37a:	80 f9 02             	cmp    $0x2,%cl
    d37d:	0f 84 cd 08 00 00    	je     dc50 <f0+0x2aa0>
    d383:	80 f9 01             	cmp    $0x1,%cl
    d386:	75 29                	jne    d3b1 <f0+0x2201>
    d388:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d38b:	0f b7 c0             	movzwl %ax,%eax
    d38e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d391:	48 0f af c1          	imul   %rcx,%rax
    d395:	48 c1 e8 20          	shr    $0x20,%rax
    d399:	48 39 d0             	cmp    %rdx,%rax
    d39c:	73 13                	jae    d3b1 <f0+0x2201>
    d39e:	49 01 c4             	add    %rax,%r12
    d3a1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3a6:	0f 84 7b 0a 00 00    	je     de27 <f0+0x2c77>
    d3ac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3b1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3b8:	00 f0 3f 
    d3bb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d3c2:	00 
    d3c3:	bf 01 00 00 00       	mov    $0x1,%edi
    d3c8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d3cf:	00 
    d3d0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d3d7:	00 
    d3d8:	e8 93 89 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d3dd:	48 8b 15 b4 77 01 00 	mov    0x177b4(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d3e4:	49 89 c5             	mov    %rax,%r13
    d3e7:	48 2b 05 82 77 01 00 	sub    0x17782(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d3ee:	48 c1 e2 10          	shl    $0x10,%rdx
    d3f2:	48 39 d0             	cmp    %rdx,%rax
    d3f5:	73 59                	jae    d450 <f0+0x22a0>
    d3f7:	48 89 c2             	mov    %rax,%rdx
    d3fa:	48 c1 ea 10          	shr    $0x10,%rdx
    d3fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d402:	48 8b 15 af 77 01 00 	mov    0x177af(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d409:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d40d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d411:	4d 85 e4             	test   %r12,%r12
    d414:	74 3a                	je     d450 <f0+0x22a0>
    d416:	0f b6 0a             	movzbl (%rdx),%ecx
    d419:	80 f9 02             	cmp    $0x2,%cl
    d41c:	0f 84 1e 08 00 00    	je     dc40 <f0+0x2a90>
    d422:	80 f9 01             	cmp    $0x1,%cl
    d425:	75 29                	jne    d450 <f0+0x22a0>
    d427:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d42a:	0f b7 c0             	movzwl %ax,%eax
    d42d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d430:	48 0f af c1          	imul   %rcx,%rax
    d434:	48 c1 e8 20          	shr    $0x20,%rax
    d438:	48 39 d0             	cmp    %rdx,%rax
    d43b:	73 13                	jae    d450 <f0+0x22a0>
    d43d:	49 01 c4             	add    %rax,%r12
    d440:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d445:	0f 84 e9 09 00 00    	je     de34 <f0+0x2c84>
    d44b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d450:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d457:	33 f3 bf 
    d45a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d461:	00 
    d462:	bf 01 00 00 00       	mov    $0x1,%edi
    d467:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d46e:	00 
    d46f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d476:	00 
    d477:	e8 f4 88 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d47c:	48 8b 15 15 77 01 00 	mov    0x17715(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d483:	49 89 c5             	mov    %rax,%r13
    d486:	48 2b 05 e3 76 01 00 	sub    0x176e3(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d48d:	48 c1 e2 10          	shl    $0x10,%rdx
    d491:	48 39 d0             	cmp    %rdx,%rax
    d494:	73 59                	jae    d4ef <f0+0x233f>
    d496:	48 89 c2             	mov    %rax,%rdx
    d499:	48 c1 ea 10          	shr    $0x10,%rdx
    d49d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4a1:	48 8b 15 10 77 01 00 	mov    0x17710(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d4a8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4ac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4b0:	4d 85 e4             	test   %r12,%r12
    d4b3:	74 3a                	je     d4ef <f0+0x233f>
    d4b5:	0f b6 0a             	movzbl (%rdx),%ecx
    d4b8:	80 f9 02             	cmp    $0x2,%cl
    d4bb:	0f 84 6f 07 00 00    	je     dc30 <f0+0x2a80>
    d4c1:	80 f9 01             	cmp    $0x1,%cl
    d4c4:	75 29                	jne    d4ef <f0+0x233f>
    d4c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4c9:	0f b7 c0             	movzwl %ax,%eax
    d4cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4cf:	48 0f af c1          	imul   %rcx,%rax
    d4d3:	48 c1 e8 20          	shr    $0x20,%rax
    d4d7:	48 39 d0             	cmp    %rdx,%rax
    d4da:	73 13                	jae    d4ef <f0+0x233f>
    d4dc:	49 01 c4             	add    %rax,%r12
    d4df:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4e4:	0f 84 57 09 00 00    	je     de41 <f0+0x2c91>
    d4ea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4ef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4f6:	00 f0 3f 
    d4f9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d500:	00 
    d501:	bf 01 00 00 00       	mov    $0x1,%edi
    d506:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d50d:	00 
    d50e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d515:	00 
    d516:	e8 55 88 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d51b:	48 8b 15 76 76 01 00 	mov    0x17676(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d522:	49 89 c5             	mov    %rax,%r13
    d525:	48 2b 05 44 76 01 00 	sub    0x17644(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d52c:	48 c1 e2 10          	shl    $0x10,%rdx
    d530:	48 39 d0             	cmp    %rdx,%rax
    d533:	73 59                	jae    d58e <f0+0x23de>
    d535:	48 89 c2             	mov    %rax,%rdx
    d538:	48 c1 ea 10          	shr    $0x10,%rdx
    d53c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d540:	48 8b 15 71 76 01 00 	mov    0x17671(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d547:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d54b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d54f:	4d 85 e4             	test   %r12,%r12
    d552:	74 3a                	je     d58e <f0+0x23de>
    d554:	0f b6 0a             	movzbl (%rdx),%ecx
    d557:	80 f9 02             	cmp    $0x2,%cl
    d55a:	0f 84 c0 06 00 00    	je     dc20 <f0+0x2a70>
    d560:	80 f9 01             	cmp    $0x1,%cl
    d563:	75 29                	jne    d58e <f0+0x23de>
    d565:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d568:	0f b7 c0             	movzwl %ax,%eax
    d56b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d56e:	48 0f af c1          	imul   %rcx,%rax
    d572:	48 c1 e8 20          	shr    $0x20,%rax
    d576:	48 39 d0             	cmp    %rdx,%rax
    d579:	73 13                	jae    d58e <f0+0x23de>
    d57b:	49 01 c4             	add    %rax,%r12
    d57e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d583:	0f 84 c5 08 00 00    	je     de4e <f0+0x2c9e>
    d589:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d58e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d595:	33 f3 bf 
    d598:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d59f:	00 
    d5a0:	bf 01 00 00 00       	mov    $0x1,%edi
    d5a5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d5ac:	00 
    d5ad:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d5b4:	00 
    d5b5:	e8 b6 87 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d5ba:	48 8b 15 d7 75 01 00 	mov    0x175d7(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d5c1:	49 89 c5             	mov    %rax,%r13
    d5c4:	48 2b 05 a5 75 01 00 	sub    0x175a5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d5cb:	48 c1 e2 10          	shl    $0x10,%rdx
    d5cf:	48 39 d0             	cmp    %rdx,%rax
    d5d2:	73 59                	jae    d62d <f0+0x247d>
    d5d4:	48 89 c2             	mov    %rax,%rdx
    d5d7:	48 c1 ea 10          	shr    $0x10,%rdx
    d5db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5df:	48 8b 15 d2 75 01 00 	mov    0x175d2(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d5e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5ea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5ee:	4d 85 e4             	test   %r12,%r12
    d5f1:	74 3a                	je     d62d <f0+0x247d>
    d5f3:	0f b6 0a             	movzbl (%rdx),%ecx
    d5f6:	80 f9 02             	cmp    $0x2,%cl
    d5f9:	0f 84 11 06 00 00    	je     dc10 <f0+0x2a60>
    d5ff:	80 f9 01             	cmp    $0x1,%cl
    d602:	75 29                	jne    d62d <f0+0x247d>
    d604:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d607:	0f b7 c0             	movzwl %ax,%eax
    d60a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d60d:	48 0f af c1          	imul   %rcx,%rax
    d611:	48 c1 e8 20          	shr    $0x20,%rax
    d615:	48 39 d0             	cmp    %rdx,%rax
    d618:	73 13                	jae    d62d <f0+0x247d>
    d61a:	49 01 c4             	add    %rax,%r12
    d61d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d622:	0f 84 33 08 00 00    	je     de5b <f0+0x2cab>
    d628:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d62d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d634:	00 f0 3f 
    d637:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d63e:	00 
    d63f:	bf 01 00 00 00       	mov    $0x1,%edi
    d644:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d64b:	00 
    d64c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d653:	00 
    d654:	e8 17 87 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d659:	48 8b 15 38 75 01 00 	mov    0x17538(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d660:	49 89 c5             	mov    %rax,%r13
    d663:	48 2b 05 06 75 01 00 	sub    0x17506(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d66a:	48 c1 e2 10          	shl    $0x10,%rdx
    d66e:	48 39 d0             	cmp    %rdx,%rax
    d671:	73 59                	jae    d6cc <f0+0x251c>
    d673:	48 89 c2             	mov    %rax,%rdx
    d676:	48 c1 ea 10          	shr    $0x10,%rdx
    d67a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d67e:	48 8b 15 33 75 01 00 	mov    0x17533(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d685:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d689:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d68d:	4d 85 e4             	test   %r12,%r12
    d690:	74 3a                	je     d6cc <f0+0x251c>
    d692:	0f b6 0a             	movzbl (%rdx),%ecx
    d695:	80 f9 02             	cmp    $0x2,%cl
    d698:	0f 84 62 05 00 00    	je     dc00 <f0+0x2a50>
    d69e:	80 f9 01             	cmp    $0x1,%cl
    d6a1:	75 29                	jne    d6cc <f0+0x251c>
    d6a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6a6:	0f b7 c0             	movzwl %ax,%eax
    d6a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6ac:	48 0f af c1          	imul   %rcx,%rax
    d6b0:	48 c1 e8 20          	shr    $0x20,%rax
    d6b4:	48 39 d0             	cmp    %rdx,%rax
    d6b7:	73 13                	jae    d6cc <f0+0x251c>
    d6b9:	49 01 c4             	add    %rax,%r12
    d6bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6c1:	0f 84 a1 07 00 00    	je     de68 <f0+0x2cb8>
    d6c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6d3:	33 f3 bf 
    d6d6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d6dd:	00 
    d6de:	bf 01 00 00 00       	mov    $0x1,%edi
    d6e3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d6ea:	00 
    d6eb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d6f2:	00 
    d6f3:	e8 78 86 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d6f8:	48 8b 15 99 74 01 00 	mov    0x17499(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d6ff:	49 89 c5             	mov    %rax,%r13
    d702:	48 2b 05 67 74 01 00 	sub    0x17467(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d709:	48 c1 e2 10          	shl    $0x10,%rdx
    d70d:	48 39 d0             	cmp    %rdx,%rax
    d710:	73 59                	jae    d76b <f0+0x25bb>
    d712:	48 89 c2             	mov    %rax,%rdx
    d715:	48 c1 ea 10          	shr    $0x10,%rdx
    d719:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d71d:	48 8b 15 94 74 01 00 	mov    0x17494(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d724:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d728:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d72c:	4d 85 e4             	test   %r12,%r12
    d72f:	74 3a                	je     d76b <f0+0x25bb>
    d731:	0f b6 0a             	movzbl (%rdx),%ecx
    d734:	80 f9 02             	cmp    $0x2,%cl
    d737:	0f 84 b3 04 00 00    	je     dbf0 <f0+0x2a40>
    d73d:	80 f9 01             	cmp    $0x1,%cl
    d740:	75 29                	jne    d76b <f0+0x25bb>
    d742:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d745:	0f b7 c0             	movzwl %ax,%eax
    d748:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d74b:	48 0f af c1          	imul   %rcx,%rax
    d74f:	48 c1 e8 20          	shr    $0x20,%rax
    d753:	48 39 d0             	cmp    %rdx,%rax
    d756:	73 13                	jae    d76b <f0+0x25bb>
    d758:	49 01 c4             	add    %rax,%r12
    d75b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d760:	0f 84 0f 07 00 00    	je     de75 <f0+0x2cc5>
    d766:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d76b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d772:	00 f0 3f 
    d775:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d77c:	00 
    d77d:	bf 01 00 00 00       	mov    $0x1,%edi
    d782:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d789:	00 
    d78a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d791:	00 
    d792:	e8 d9 85 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d797:	48 8b 15 fa 73 01 00 	mov    0x173fa(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d79e:	49 89 c5             	mov    %rax,%r13
    d7a1:	48 2b 05 c8 73 01 00 	sub    0x173c8(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d7a8:	48 c1 e2 10          	shl    $0x10,%rdx
    d7ac:	48 39 d0             	cmp    %rdx,%rax
    d7af:	73 59                	jae    d80a <f0+0x265a>
    d7b1:	48 89 c2             	mov    %rax,%rdx
    d7b4:	48 c1 ea 10          	shr    $0x10,%rdx
    d7b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7bc:	48 8b 15 f5 73 01 00 	mov    0x173f5(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d7c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7cb:	4d 85 e4             	test   %r12,%r12
    d7ce:	74 3a                	je     d80a <f0+0x265a>
    d7d0:	0f b6 0a             	movzbl (%rdx),%ecx
    d7d3:	80 f9 02             	cmp    $0x2,%cl
    d7d6:	0f 84 04 04 00 00    	je     dbe0 <f0+0x2a30>
    d7dc:	80 f9 01             	cmp    $0x1,%cl
    d7df:	75 29                	jne    d80a <f0+0x265a>
    d7e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7e4:	0f b7 c0             	movzwl %ax,%eax
    d7e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7ea:	48 0f af c1          	imul   %rcx,%rax
    d7ee:	48 c1 e8 20          	shr    $0x20,%rax
    d7f2:	48 39 d0             	cmp    %rdx,%rax
    d7f5:	73 13                	jae    d80a <f0+0x265a>
    d7f7:	49 01 c4             	add    %rax,%r12
    d7fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7ff:	0f 84 7d 06 00 00    	je     de82 <f0+0x2cd2>
    d805:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d80a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d811:	33 f3 bf 
    d814:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d81b:	00 
    d81c:	bf 01 00 00 00       	mov    $0x1,%edi
    d821:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d828:	00 
    d829:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d830:	00 
    d831:	e8 3a 85 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d836:	48 8b 15 5b 73 01 00 	mov    0x1735b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d83d:	49 89 c5             	mov    %rax,%r13
    d840:	48 2b 05 29 73 01 00 	sub    0x17329(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d847:	48 c1 e2 10          	shl    $0x10,%rdx
    d84b:	48 39 d0             	cmp    %rdx,%rax
    d84e:	73 59                	jae    d8a9 <f0+0x26f9>
    d850:	48 89 c2             	mov    %rax,%rdx
    d853:	48 c1 ea 10          	shr    $0x10,%rdx
    d857:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d85b:	48 8b 15 56 73 01 00 	mov    0x17356(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d862:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d866:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d86a:	4d 85 e4             	test   %r12,%r12
    d86d:	74 3a                	je     d8a9 <f0+0x26f9>
    d86f:	0f b6 0a             	movzbl (%rdx),%ecx
    d872:	80 f9 02             	cmp    $0x2,%cl
    d875:	0f 84 55 03 00 00    	je     dbd0 <f0+0x2a20>
    d87b:	80 f9 01             	cmp    $0x1,%cl
    d87e:	75 29                	jne    d8a9 <f0+0x26f9>
    d880:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d883:	0f b7 c0             	movzwl %ax,%eax
    d886:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d889:	48 0f af c1          	imul   %rcx,%rax
    d88d:	48 c1 e8 20          	shr    $0x20,%rax
    d891:	48 39 d0             	cmp    %rdx,%rax
    d894:	73 13                	jae    d8a9 <f0+0x26f9>
    d896:	49 01 c4             	add    %rax,%r12
    d899:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d89e:	0f 84 eb 05 00 00    	je     de8f <f0+0x2cdf>
    d8a4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8b0:	00 f0 3f 
    d8b3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d8ba:	00 
    d8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d8c0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d8c7:	00 
    d8c8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d8cf:	00 
    d8d0:	e8 9b 84 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d8d5:	48 8b 15 bc 72 01 00 	mov    0x172bc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d8dc:	49 89 c5             	mov    %rax,%r13
    d8df:	48 2b 05 8a 72 01 00 	sub    0x1728a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d8e6:	48 c1 e2 10          	shl    $0x10,%rdx
    d8ea:	48 39 d0             	cmp    %rdx,%rax
    d8ed:	73 59                	jae    d948 <f0+0x2798>
    d8ef:	48 89 c2             	mov    %rax,%rdx
    d8f2:	48 c1 ea 10          	shr    $0x10,%rdx
    d8f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8fa:	48 8b 15 b7 72 01 00 	mov    0x172b7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d901:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d905:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d909:	4d 85 e4             	test   %r12,%r12
    d90c:	74 3a                	je     d948 <f0+0x2798>
    d90e:	0f b6 0a             	movzbl (%rdx),%ecx
    d911:	80 f9 02             	cmp    $0x2,%cl
    d914:	0f 84 a6 02 00 00    	je     dbc0 <f0+0x2a10>
    d91a:	80 f9 01             	cmp    $0x1,%cl
    d91d:	75 29                	jne    d948 <f0+0x2798>
    d91f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d922:	0f b7 c0             	movzwl %ax,%eax
    d925:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d928:	48 0f af c1          	imul   %rcx,%rax
    d92c:	48 c1 e8 20          	shr    $0x20,%rax
    d930:	48 39 d0             	cmp    %rdx,%rax
    d933:	73 13                	jae    d948 <f0+0x2798>
    d935:	49 01 c4             	add    %rax,%r12
    d938:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d93d:	0f 84 59 05 00 00    	je     de9c <f0+0x2cec>
    d943:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d948:	48 89 ee             	mov    %rbp,%rsi
    d94b:	bf 01 00 00 00       	mov    $0x1,%edi
    d950:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d957:	33 f3 bf 
    d95a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d961:	00 
    d962:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d969:	00 
    d96a:	e8 01 84 ff ff       	call   5d70 <fwp_data.part.0.constprop.0>
    d96f:	48 8b 15 22 72 01 00 	mov    0x17222(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d976:	48 89 c5             	mov    %rax,%rbp
    d979:	48 2b 05 f0 71 01 00 	sub    0x171f0(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d980:	48 c1 e2 10          	shl    $0x10,%rdx
    d984:	48 39 d0             	cmp    %rdx,%rax
    d987:	73 59                	jae    d9e2 <f0+0x2832>
    d989:	48 89 c2             	mov    %rax,%rdx
    d98c:	48 c1 ea 10          	shr    $0x10,%rdx
    d990:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d994:	48 8b 15 1d 72 01 00 	mov    0x1721d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d99b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d99f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9a3:	4d 85 e4             	test   %r12,%r12
    d9a6:	74 3a                	je     d9e2 <f0+0x2832>
    d9a8:	0f b6 0a             	movzbl (%rdx),%ecx
    d9ab:	80 f9 02             	cmp    $0x2,%cl
    d9ae:	0f 84 fc 01 00 00    	je     dbb0 <f0+0x2a00>
    d9b4:	80 f9 01             	cmp    $0x1,%cl
    d9b7:	75 29                	jne    d9e2 <f0+0x2832>
    d9b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9bc:	0f b7 c0             	movzwl %ax,%eax
    d9bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9c2:	48 0f af c1          	imul   %rcx,%rax
    d9c6:	48 c1 e8 20          	shr    $0x20,%rax
    d9ca:	48 39 d0             	cmp    %rdx,%rax
    d9cd:	73 13                	jae    d9e2 <f0+0x2832>
    d9cf:	49 01 c4             	add    %rax,%r12
    d9d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9d7:	0f 84 d1 02 00 00    	je     dcae <f0+0x2afe>
    d9dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9e2:	48 89 de             	mov    %rbx,%rsi
    d9e5:	48 89 ef             	mov    %rbp,%rdi
    d9e8:	e8 b3 be ff ff       	call   98a0 <fwp_hof0.constprop.0>
    d9ed:	48 89 ef             	mov    %rbp,%rdi
    d9f0:	e8 0b a3 ff ff       	call   7d00 <fwp_drop0>
    d9f5:	48 89 df             	mov    %rbx,%rdi
    d9f8:	e8 03 a3 ff ff       	call   7d00 <fwp_drop0>
    d9fd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    da04:	00 
    da05:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    da0c:	00 00 
    da0e:	0f 85 95 04 00 00    	jne    dea9 <f0+0x2cf9>
    da14:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    da1b:	31 c0                	xor    %eax,%eax
    da1d:	5b                   	pop    %rbx
    da1e:	5d                   	pop    %rbp
    da1f:	41 5c                	pop    %r12
    da21:	41 5d                	pop    %r13
    da23:	41 5e                	pop    %r14
    da25:	c3                   	ret
    da26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    da2d:	00 00 00 
    da30:	4c 89 ef             	mov    %r13,%rdi
    da33:	e8 d8 7a ff ff       	call   5510 <fwp_rc_forget_slot>
    da38:	e9 2c d8 ff ff       	jmp    b269 <f0+0xb9>
    da3d:	0f 1f 00             	nopl   (%rax)
    da40:	66 85 c0             	test   %ax,%ax
    da43:	0f 85 ae f5 ff ff    	jne    cff7 <f0+0x1e47>
    da49:	e9 99 f5 ff ff       	jmp    cfe7 <f0+0x1e37>
    da4e:	66 90                	xchg   %ax,%ax
    da50:	66 85 c0             	test   %ax,%ax
    da53:	0f 85 ff f4 ff ff    	jne    cf58 <f0+0x1da8>
    da59:	e9 ea f4 ff ff       	jmp    cf48 <f0+0x1d98>
    da5e:	66 90                	xchg   %ax,%ax
    da60:	66 85 c0             	test   %ax,%ax
    da63:	0f 85 50 f4 ff ff    	jne    ceb9 <f0+0x1d09>
    da69:	e9 3b f4 ff ff       	jmp    cea9 <f0+0x1cf9>
    da6e:	66 90                	xchg   %ax,%ax
    da70:	66 85 c0             	test   %ax,%ax
    da73:	0f 85 a1 f3 ff ff    	jne    ce1a <f0+0x1c6a>
    da79:	e9 8c f3 ff ff       	jmp    ce0a <f0+0x1c5a>
    da7e:	66 90                	xchg   %ax,%ax
    da80:	66 85 c0             	test   %ax,%ax
    da83:	0f 85 f2 f2 ff ff    	jne    cd7b <f0+0x1bcb>
    da89:	e9 dd f2 ff ff       	jmp    cd6b <f0+0x1bbb>
    da8e:	66 90                	xchg   %ax,%ax
    da90:	66 85 c0             	test   %ax,%ax
    da93:	0f 85 43 f2 ff ff    	jne    ccdc <f0+0x1b2c>
    da99:	e9 2e f2 ff ff       	jmp    cccc <f0+0x1b1c>
    da9e:	66 90                	xchg   %ax,%ax
    daa0:	66 85 c0             	test   %ax,%ax
    daa3:	0f 85 94 f1 ff ff    	jne    cc3d <f0+0x1a8d>
    daa9:	e9 7f f1 ff ff       	jmp    cc2d <f0+0x1a7d>
    daae:	66 90                	xchg   %ax,%ax
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 e5 f0 ff ff    	jne    cb9e <f0+0x19ee>
    dab9:	e9 d0 f0 ff ff       	jmp    cb8e <f0+0x19de>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 fd d9 ff ff    	jne    b4c6 <f0+0x316>
    dac9:	e9 e8 d9 ff ff       	jmp    b4b6 <f0+0x306>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 57 d9 ff ff    	jne    b430 <f0+0x280>
    dad9:	e9 42 d9 ff ff       	jmp    b420 <f0+0x270>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 b1 d8 ff ff    	jne    b39a <f0+0x1ea>
    dae9:	e9 9c d8 ff ff       	jmp    b38a <f0+0x1da>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 0e eb ff ff    	jne    c607 <f0+0x1457>
    daf9:	e9 f9 ea ff ff       	jmp    c5f7 <f0+0x1447>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 5f ea ff ff    	jne    c568 <f0+0x13b8>
    db09:	e9 4a ea ff ff       	jmp    c558 <f0+0x13a8>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 e2 da ff ff    	jne    b5fb <f0+0x44b>
    db19:	e9 cd da ff ff       	jmp    b5eb <f0+0x43b>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 33 da ff ff    	jne    b55c <f0+0x3ac>
    db29:	e9 1e da ff ff       	jmp    b54c <f0+0x39c>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 c6 ef ff ff    	jne    caff <f0+0x194f>
    db39:	e9 b1 ef ff ff       	jmp    caef <f0+0x193f>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 17 ef ff ff    	jne    ca60 <f0+0x18b0>
    db49:	e9 02 ef ff ff       	jmp    ca50 <f0+0x18a0>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 68 ee ff ff    	jne    c9c1 <f0+0x1811>
    db59:	e9 53 ee ff ff       	jmp    c9b1 <f0+0x1801>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 b9 ed ff ff    	jne    c922 <f0+0x1772>
    db69:	e9 a4 ed ff ff       	jmp    c912 <f0+0x1762>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 0a ed ff ff    	jne    c883 <f0+0x16d3>
    db79:	e9 f5 ec ff ff       	jmp    c873 <f0+0x16c3>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 5b ec ff ff    	jne    c7e4 <f0+0x1634>
    db89:	e9 46 ec ff ff       	jmp    c7d4 <f0+0x1624>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 ac eb ff ff    	jne    c745 <f0+0x1595>
    db99:	e9 97 eb ff ff       	jmp    c735 <f0+0x1585>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 fd ea ff ff    	jne    c6a6 <f0+0x14f6>
    dba9:	e9 e8 ea ff ff       	jmp    c696 <f0+0x14e6>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 29 fe ff ff    	jne    d9e2 <f0+0x2832>
    dbb9:	e9 14 fe ff ff       	jmp    d9d2 <f0+0x2822>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 7f fd ff ff    	jne    d948 <f0+0x2798>
    dbc9:	e9 6a fd ff ff       	jmp    d938 <f0+0x2788>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 d0 fc ff ff    	jne    d8a9 <f0+0x26f9>
    dbd9:	e9 bb fc ff ff       	jmp    d899 <f0+0x26e9>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 21 fc ff ff    	jne    d80a <f0+0x265a>
    dbe9:	e9 0c fc ff ff       	jmp    d7fa <f0+0x264a>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 72 fb ff ff    	jne    d76b <f0+0x25bb>
    dbf9:	e9 5d fb ff ff       	jmp    d75b <f0+0x25ab>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 c3 fa ff ff    	jne    d6cc <f0+0x251c>
    dc09:	e9 ae fa ff ff       	jmp    d6bc <f0+0x250c>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 14 fa ff ff    	jne    d62d <f0+0x247d>
    dc19:	e9 ff f9 ff ff       	jmp    d61d <f0+0x246d>
    dc1e:	66 90                	xchg   %ax,%ax
    dc20:	66 85 c0             	test   %ax,%ax
    dc23:	0f 85 65 f9 ff ff    	jne    d58e <f0+0x23de>
    dc29:	e9 50 f9 ff ff       	jmp    d57e <f0+0x23ce>
    dc2e:	66 90                	xchg   %ax,%ax
    dc30:	66 85 c0             	test   %ax,%ax
    dc33:	0f 85 b6 f8 ff ff    	jne    d4ef <f0+0x233f>
    dc39:	e9 a1 f8 ff ff       	jmp    d4df <f0+0x232f>
    dc3e:	66 90                	xchg   %ax,%ax
    dc40:	66 85 c0             	test   %ax,%ax
    dc43:	0f 85 07 f8 ff ff    	jne    d450 <f0+0x22a0>
    dc49:	e9 f2 f7 ff ff       	jmp    d440 <f0+0x2290>
    dc4e:	66 90                	xchg   %ax,%ax
    dc50:	66 85 c0             	test   %ax,%ax
    dc53:	0f 85 58 f7 ff ff    	jne    d3b1 <f0+0x2201>
    dc59:	e9 43 f7 ff ff       	jmp    d3a1 <f0+0x21f1>
    dc5e:	66 90                	xchg   %ax,%ax
    dc60:	66 85 c0             	test   %ax,%ax
    dc63:	0f 85 a9 f6 ff ff    	jne    d312 <f0+0x2162>
    dc69:	e9 94 f6 ff ff       	jmp    d302 <f0+0x2152>
    dc6e:	66 90                	xchg   %ax,%ax
    dc70:	66 85 c0             	test   %ax,%ax
    dc73:	0f 85 fa f5 ff ff    	jne    d273 <f0+0x20c3>
    dc79:	e9 e5 f5 ff ff       	jmp    d263 <f0+0x20b3>
    dc7e:	66 90                	xchg   %ax,%ax
    dc80:	66 85 c0             	test   %ax,%ax
    dc83:	0f 85 4b f5 ff ff    	jne    d1d4 <f0+0x2024>
    dc89:	e9 36 f5 ff ff       	jmp    d1c4 <f0+0x2014>
    dc8e:	66 90                	xchg   %ax,%ax
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 9c f4 ff ff    	jne    d135 <f0+0x1f85>
    dc99:	e9 87 f4 ff ff       	jmp    d125 <f0+0x1f75>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 ed f3 ff ff    	jne    d096 <f0+0x1ee6>
    dca9:	e9 d8 f3 ff ff       	jmp    d086 <f0+0x1ed6>
    dcae:	4c 89 e7             	mov    %r12,%rdi
    dcb1:	e8 5a 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcb6:	e9 22 fd ff ff       	jmp    d9dd <f0+0x282d>
    dcbb:	4c 89 e7             	mov    %r12,%rdi
    dcbe:	e8 4d 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcc3:	e9 cd d6 ff ff       	jmp    b395 <f0+0x1e5>
    dcc8:	4c 89 e7             	mov    %r12,%rdi
    dccb:	e8 40 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcd0:	e9 56 d7 ff ff       	jmp    b42b <f0+0x27b>
    dcd5:	4c 89 e7             	mov    %r12,%rdi
    dcd8:	e8 33 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcdd:	e9 df d7 ff ff       	jmp    b4c1 <f0+0x311>
    dce2:	4c 89 e7             	mov    %r12,%rdi
    dce5:	e8 26 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcea:	e9 68 d8 ff ff       	jmp    b557 <f0+0x3a7>
    dcef:	4c 89 e7             	mov    %r12,%rdi
    dcf2:	e8 19 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dcf7:	e9 fa d8 ff ff       	jmp    b5f6 <f0+0x446>
    dcfc:	4c 89 e7             	mov    %r12,%rdi
    dcff:	e8 0c 78 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd04:	e9 5a e8 ff ff       	jmp    c563 <f0+0x13b3>
    dd09:	4c 89 e7             	mov    %r12,%rdi
    dd0c:	e8 ff 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd11:	e9 ec e8 ff ff       	jmp    c602 <f0+0x1452>
    dd16:	4c 89 e7             	mov    %r12,%rdi
    dd19:	e8 f2 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd1e:	e9 7e e9 ff ff       	jmp    c6a1 <f0+0x14f1>
    dd23:	4c 89 e7             	mov    %r12,%rdi
    dd26:	e8 e5 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd2b:	e9 10 ea ff ff       	jmp    c740 <f0+0x1590>
    dd30:	4c 89 e7             	mov    %r12,%rdi
    dd33:	e8 d8 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd38:	e9 a2 ea ff ff       	jmp    c7df <f0+0x162f>
    dd3d:	4c 89 e7             	mov    %r12,%rdi
    dd40:	e8 cb 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd45:	e9 34 eb ff ff       	jmp    c87e <f0+0x16ce>
    dd4a:	4c 89 e7             	mov    %r12,%rdi
    dd4d:	e8 be 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd52:	e9 c6 eb ff ff       	jmp    c91d <f0+0x176d>
    dd57:	4c 89 e7             	mov    %r12,%rdi
    dd5a:	e8 b1 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd5f:	e9 58 ec ff ff       	jmp    c9bc <f0+0x180c>
    dd64:	4c 89 e7             	mov    %r12,%rdi
    dd67:	e8 a4 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd6c:	e9 ea ec ff ff       	jmp    ca5b <f0+0x18ab>
    dd71:	4c 89 e7             	mov    %r12,%rdi
    dd74:	e8 97 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd79:	e9 7c ed ff ff       	jmp    cafa <f0+0x194a>
    dd7e:	4c 89 e7             	mov    %r12,%rdi
    dd81:	e8 8a 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd86:	e9 0e ee ff ff       	jmp    cb99 <f0+0x19e9>
    dd8b:	4c 89 e7             	mov    %r12,%rdi
    dd8e:	e8 7d 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dd93:	e9 a0 ee ff ff       	jmp    cc38 <f0+0x1a88>
    dd98:	4c 89 e7             	mov    %r12,%rdi
    dd9b:	e8 70 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dda0:	e9 32 ef ff ff       	jmp    ccd7 <f0+0x1b27>
    dda5:	4c 89 e7             	mov    %r12,%rdi
    dda8:	e8 63 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddad:	e9 c4 ef ff ff       	jmp    cd76 <f0+0x1bc6>
    ddb2:	4c 89 e7             	mov    %r12,%rdi
    ddb5:	e8 56 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddba:	e9 56 f0 ff ff       	jmp    ce15 <f0+0x1c65>
    ddbf:	4c 89 e7             	mov    %r12,%rdi
    ddc2:	e8 49 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddc7:	e9 e8 f0 ff ff       	jmp    ceb4 <f0+0x1d04>
    ddcc:	4c 89 e7             	mov    %r12,%rdi
    ddcf:	e8 3c 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddd4:	e9 7a f1 ff ff       	jmp    cf53 <f0+0x1da3>
    ddd9:	4c 89 e7             	mov    %r12,%rdi
    dddc:	e8 2f 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    dde1:	e9 0c f2 ff ff       	jmp    cff2 <f0+0x1e42>
    dde6:	4c 89 e7             	mov    %r12,%rdi
    dde9:	e8 22 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddee:	e9 9e f2 ff ff       	jmp    d091 <f0+0x1ee1>
    ddf3:	4c 89 e7             	mov    %r12,%rdi
    ddf6:	e8 15 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    ddfb:	e9 30 f3 ff ff       	jmp    d130 <f0+0x1f80>
    de00:	4c 89 e7             	mov    %r12,%rdi
    de03:	e8 08 77 ff ff       	call   5510 <fwp_rc_forget_slot>
    de08:	e9 c2 f3 ff ff       	jmp    d1cf <f0+0x201f>
    de0d:	4c 89 e7             	mov    %r12,%rdi
    de10:	e8 fb 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de15:	e9 54 f4 ff ff       	jmp    d26e <f0+0x20be>
    de1a:	4c 89 e7             	mov    %r12,%rdi
    de1d:	e8 ee 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de22:	e9 e6 f4 ff ff       	jmp    d30d <f0+0x215d>
    de27:	4c 89 e7             	mov    %r12,%rdi
    de2a:	e8 e1 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de2f:	e9 78 f5 ff ff       	jmp    d3ac <f0+0x21fc>
    de34:	4c 89 e7             	mov    %r12,%rdi
    de37:	e8 d4 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de3c:	e9 0a f6 ff ff       	jmp    d44b <f0+0x229b>
    de41:	4c 89 e7             	mov    %r12,%rdi
    de44:	e8 c7 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de49:	e9 9c f6 ff ff       	jmp    d4ea <f0+0x233a>
    de4e:	4c 89 e7             	mov    %r12,%rdi
    de51:	e8 ba 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de56:	e9 2e f7 ff ff       	jmp    d589 <f0+0x23d9>
    de5b:	4c 89 e7             	mov    %r12,%rdi
    de5e:	e8 ad 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de63:	e9 c0 f7 ff ff       	jmp    d628 <f0+0x2478>
    de68:	4c 89 e7             	mov    %r12,%rdi
    de6b:	e8 a0 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de70:	e9 52 f8 ff ff       	jmp    d6c7 <f0+0x2517>
    de75:	4c 89 e7             	mov    %r12,%rdi
    de78:	e8 93 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de7d:	e9 e4 f8 ff ff       	jmp    d766 <f0+0x25b6>
    de82:	4c 89 e7             	mov    %r12,%rdi
    de85:	e8 86 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de8a:	e9 76 f9 ff ff       	jmp    d805 <f0+0x2655>
    de8f:	4c 89 e7             	mov    %r12,%rdi
    de92:	e8 79 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    de97:	e9 08 fa ff ff       	jmp    d8a4 <f0+0x26f4>
    de9c:	4c 89 e7             	mov    %r12,%rdi
    de9f:	e8 6c 76 ff ff       	call   5510 <fwp_rc_forget_slot>
    dea4:	e9 9a fa ff ff       	jmp    d943 <f0+0x2793>
    dea9:	e8 92 55 ff ff       	call   3440 <__stack_chk_fail@plt>
    deae:	66 90                	xchg   %ax,%ax

000000000000deb0 <fwp_main_thread>:
    deb0:	f3 0f 1e fa          	endbr64
    deb4:	41 54                	push   %r12
    deb6:	55                   	push   %rbp
    deb7:	53                   	push   %rbx
    deb8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    debf:	8b 35 9f 6c 01 00    	mov    0x16c9f(%rip),%esi        # 24b64 <fwp_heap+0x13a4>
    dec5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    decc:	00 00 
    dece:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ded5:	00 
    ded6:	31 c0                	xor    %eax,%eax
    ded8:	85 f6                	test   %esi,%esi
    deda:	0f 84 a8 06 00 00    	je     e588 <fwp_main_thread+0x6d8>
    dee0:	8b 0d 82 6c 01 00    	mov    0x16c82(%rip),%ecx        # 24b68 <fwp_heap+0x13a8>
    dee6:	85 c9                	test   %ecx,%ecx
    dee8:	0f 85 82 06 00 00    	jne    e570 <fwp_main_thread+0x6c0>
    deee:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    def3:	31 f6                	xor    %esi,%esi
    def5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    defa:	48 c7 05 4b 52 01 00 	movq   $0x40000000,0x1524b(%rip)        # 23150 <fwp_main_stack_size>
    df01:	00 00 00 40 
    df05:	48 89 05 4c 52 01 00 	mov    %rax,0x1524c(%rip)        # 23158 <fwp_main_stack_top>
    df0c:	48 8d 05 6d 51 00 00 	lea    0x516d(%rip),%rax        # 13080 <alt.5>
    df13:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    df18:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    df1f:	01 00 
    df21:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    df28:	00 
    df29:	e8 52 57 ff ff       	call   3680 <sigaltstack@plt>
    df2e:	85 c0                	test   %eax,%eax
    df30:	0f 85 8a 06 00 00    	jne    e5c0 <fwp_main_thread+0x710>
    df36:	31 c0                	xor    %eax,%eax
    df38:	b9 12 00 00 00       	mov    $0x12,%ecx
    df3d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    df42:	f3 48 ab             	rep stos %rax,(%rdi)
    df45:	48 8d 05 64 5d ff ff 	lea    -0xa29c(%rip),%rax        # 3cb0 <fwp_segv>
    df4c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    df51:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    df58:	04 00 00 08 
    df5c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    df61:	e8 ea 55 ff ff       	call   3550 <sigemptyset@plt>
    df66:	85 c0                	test   %eax,%eax
    df68:	0f 85 52 06 00 00    	jne    e5c0 <fwp_main_thread+0x710>
    df6e:	31 d2                	xor    %edx,%edx
    df70:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    df75:	bf 0b 00 00 00       	mov    $0xb,%edi
    df7a:	e8 61 54 ff ff       	call   33e0 <sigaction@plt>
    df7f:	85 c0                	test   %eax,%eax
    df81:	0f 85 39 06 00 00    	jne    e5c0 <fwp_main_thread+0x710>
    df87:	31 d2                	xor    %edx,%edx
    df89:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    df8e:	bf 07 00 00 00       	mov    $0x7,%edi
    df93:	e8 48 54 ff ff       	call   33e0 <sigaction@plt>
    df98:	85 c0                	test   %eax,%eax
    df9a:	0f 85 20 06 00 00    	jne    e5c0 <fwp_main_thread+0x710>
    dfa0:	8b 15 42 51 01 00    	mov    0x15142(%rip),%edx        # 230e8 <descent_registered>
    dfa6:	85 d2                	test   %edx,%edx
    dfa8:	0f 84 72 05 00 00    	je     e520 <fwp_main_thread+0x670>
    dfae:	8b 05 bc 50 00 00    	mov    0x50bc(%rip),%eax        # 13070 <st.3>
    dfb4:	85 c0                	test   %eax,%eax
    dfb6:	0f 84 90 05 00 00    	je     e54c <fwp_main_thread+0x69c>
    dfbc:	48 8b 2d dd 57 01 00 	mov    0x157dd(%rip),%rbp        # 237a0 <fwp_cur>
    dfc3:	48 85 ed             	test   %rbp,%rbp
    dfc6:	0f 84 74 03 00 00    	je     e340 <fwp_main_thread+0x490>
    dfcc:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    dfd1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    dfd5:	48 89 eb             	mov    %rbp,%rbx
    dfd8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dfdd:	0f 84 41 01 00 00    	je     e124 <fwp_main_thread+0x274>
    dfe3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    dfe8:	0f 84 82 02 00 00    	je     e270 <fwp_main_thread+0x3c0>
    dfee:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dff2:	0f 84 68 02 00 00    	je     e260 <fwp_main_thread+0x3b0>
    dff8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dffc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e000:	0f 85 ea 02 00 00    	jne    e2f0 <fwp_main_thread+0x440>
    e006:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e00a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e011:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e015:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e01c:	00 00 00 00 
    e020:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e027:	48 85 d2             	test   %rdx,%rdx
    e02a:	74 07                	je     e033 <fwp_main_thread+0x183>
    e02c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e033:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e037:	48 85 c0             	test   %rax,%rax
    e03a:	74 34                	je     e070 <fwp_main_thread+0x1c0>
    e03c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e040:	48 8b 05 31 57 01 00 	mov    0x15731(%rip),%rax        # 23778 <fwp_timers>
    e047:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e04b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e052:	00 00 00 00 
    e056:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e05d:	48 85 c0             	test   %rax,%rax
    e060:	74 07                	je     e069 <fwp_main_thread+0x1b9>
    e062:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e069:	48 89 1d 08 57 01 00 	mov    %rbx,0x15708(%rip)        # 23778 <fwp_timers>
    e070:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e074:	e8 57 98 ff ff       	call   78d0 <fwp_block>
    e079:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e080:	48 85 c9             	test   %rcx,%rcx
    e083:	74 47                	je     e0cc <fwp_main_thread+0x21c>
    e085:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e08c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e093:	48 85 d2             	test   %rdx,%rdx
    e096:	0f 84 94 02 00 00    	je     e330 <fwp_main_thread+0x480>
    e09c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e0a3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e0aa:	48 85 c0             	test   %rax,%rax
    e0ad:	74 07                	je     e0b6 <fwp_main_thread+0x206>
    e0af:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e0b6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e0bd:	00 00 00 00 
    e0c1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e0c5:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e0cc:	48 8b 0d cd 56 01 00 	mov    0x156cd(%rip),%rcx        # 237a0 <fwp_cur>
    e0d3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e0d7:	0f 84 03 02 00 00    	je     e2e0 <fwp_main_thread+0x430>
    e0dd:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e0e4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e0eb:	48 85 d2             	test   %rdx,%rdx
    e0ee:	0f 84 fc 03 00 00    	je     e4f0 <fwp_main_thread+0x640>
    e0f4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e0fb:	48 85 c0             	test   %rax,%rax
    e0fe:	74 07                	je     e107 <fwp_main_thread+0x257>
    e100:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e107:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e10b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e10f:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e116:	48 89 cb             	mov    %rcx,%rbx
    e119:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e11e:	0f 85 bf fe ff ff    	jne    dfe3 <fwp_main_thread+0x133>
    e124:	48 83 3d 0c 73 01 00 	cmpq   $0x0,0x1730c(%rip)        # 25438 <fwp_state_len>
    e12b:	00 
    e12c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e130:	0f 84 bc 00 00 00    	je     e1f2 <fwp_main_thread+0x342>
    e136:	48 39 1d 5b 56 01 00 	cmp    %rbx,0x1565b(%rip)        # 23798 <fwp_root>
    e13d:	c7 05 39 4f 01 00 00 	movl   $0x0,0x14f39(%rip)        # 23080 <fwp_exit_code>
    e144:	00 00 00 
    e147:	0f 85 91 04 00 00    	jne    e5de <fwp_main_thread+0x72e>
    e14d:	48 85 db             	test   %rbx,%rbx
    e150:	0f 84 10 02 00 00    	je     e366 <fwp_main_thread+0x4b6>
    e156:	48 8b 15 0b 56 01 00 	mov    0x1560b(%rip),%rdx        # 23768 <fwp_tasks_active>
    e15d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e161:	48 85 d2             	test   %rdx,%rdx
    e164:	0f 84 fc 01 00 00    	je     e366 <fwp_main_thread+0x4b6>
    e16a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e170:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e174:	75 08                	jne    e17e <fwp_main_thread+0x2ce>
    e176:	48 89 d7             	mov    %rdx,%rdi
    e179:	e8 42 61 ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    e17e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e185:	48 85 d2             	test   %rdx,%rdx
    e188:	75 e6                	jne    e170 <fwp_main_thread+0x2c0>
    e18a:	eb 31                	jmp    e1bd <fwp_main_thread+0x30d>
    e18c:	0f 1f 40 00          	nopl   0x0(%rax)
    e190:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e197:	48 89 1d e2 55 01 00 	mov    %rbx,0x155e2(%rip)        # 23780 <fwp_ready_tail>
    e19e:	e8 2d 97 ff ff       	call   78d0 <fwp_block>
    e1a3:	e8 18 95 ff ff       	call   76c0 <fwp_free_zombie>
    e1a8:	48 83 3d b8 55 01 00 	cmpq   $0x0,0x155b8(%rip)        # 23768 <fwp_tasks_active>
    e1af:	00 
    e1b0:	0f 84 b0 01 00 00    	je     e366 <fwp_main_thread+0x4b6>
    e1b6:	48 8b 1d db 55 01 00 	mov    0x155db(%rip),%rbx        # 23798 <fwp_root>
    e1bd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e1c1:	75 db                	jne    e19e <fwp_main_thread+0x2ee>
    e1c3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e1c7:	75 d5                	jne    e19e <fwp_main_thread+0x2ee>
    e1c9:	48 8b 05 b0 55 01 00 	mov    0x155b0(%rip),%rax        # 23780 <fwp_ready_tail>
    e1d0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e1d4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e1db:	00 00 00 00 
    e1df:	48 85 c0             	test   %rax,%rax
    e1e2:	75 ac                	jne    e190 <fwp_main_thread+0x2e0>
    e1e4:	48 89 1d 9d 55 01 00 	mov    %rbx,0x1559d(%rip)        # 23788 <fwp_ready_head>
    e1eb:	eb aa                	jmp    e197 <fwp_main_thread+0x2e7>
    e1ed:	0f 1f 00             	nopl   (%rax)
    e1f0:	31 db                	xor    %ebx,%ebx
    e1f2:	48 83 3d 2e 72 01 00 	cmpq   $0x0,0x1722e(%rip)        # 25428 <fwp_state_owners>
    e1f9:	00 
    e1fa:	0f 85 36 ff ff ff    	jne    e136 <fwp_main_thread+0x286>
    e200:	48 8b 3d 39 72 01 00 	mov    0x17239(%rip),%rdi        # 25440 <fwp_state>
    e207:	e8 44 75 ff ff       	call   5750 <fwp_mem_free>
    e20c:	48 c7 05 29 72 01 00 	movq   $0x0,0x17229(%rip)        # 25440 <fwp_state>
    e213:	00 00 00 00 
    e217:	48 c7 05 0e 72 01 00 	movq   $0x0,0x1720e(%rip)        # 25430 <fwp_state_cap>
    e21e:	00 00 00 00 
    e222:	48 85 db             	test   %rbx,%rbx
    e225:	0f 84 76 03 00 00    	je     e5a1 <fwp_main_thread+0x6f1>
    e22b:	48 39 1d 66 55 01 00 	cmp    %rbx,0x15566(%rip)        # 23798 <fwp_root>
    e232:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e239:	00 00 00 00 
    e23d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e244:	00 00 00 00 
    e248:	c7 05 2e 4e 01 00 00 	movl   $0x0,0x14e2e(%rip)        # 23080 <fwp_exit_code>
    e24f:	00 00 00 
    e252:	0f 84 fe fe ff ff    	je     e156 <fwp_main_thread+0x2a6>
    e258:	e9 b8 54 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e25d:	0f 1f 00             	nopl   (%rax)
    e260:	e8 bb 62 ff ff       	call   4520 <fwp_now_ns>
    e265:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e269:	0f 8d 91 02 00 00    	jge    e500 <fwp_main_thread+0x650>
    e26f:	90                   	nop
    e270:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e274:	0f 85 7e fd ff ff    	jne    dff8 <fwp_main_thread+0x148>
    e27a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e27e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e282:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e286:	0f 85 7e fd ff ff    	jne    e00a <fwp_main_thread+0x15a>
    e28c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e290:	48 85 c9             	test   %rcx,%rcx
    e293:	0f 84 71 fd ff ff    	je     e00a <fwp_main_thread+0x15a>
    e299:	48 85 c0             	test   %rax,%rax
    e29c:	0f 84 2f 03 00 00    	je     e5d1 <fwp_main_thread+0x721>
    e2a2:	48 39 c8             	cmp    %rcx,%rax
    e2a5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e2a9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e2b0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e2b4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e2bb:	00 00 00 00 
    e2bf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e2c6:	48 85 d2             	test   %rdx,%rdx
    e2c9:	74 07                	je     e2d2 <fwp_main_thread+0x422>
    e2cb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e2d2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e2d6:	e9 61 fd ff ff       	jmp    e03c <fwp_main_thread+0x18c>
    e2db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e2e0:	48 89 cb             	mov    %rcx,%rbx
    e2e3:	e9 f0 fc ff ff       	jmp    dfd8 <fwp_main_thread+0x128>
    e2e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e2ef:	00 
    e2f0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e2f4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e2fb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e302:	00 00 00 00 
    e306:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e30d:	48 85 c0             	test   %rax,%rax
    e310:	0f 84 82 02 00 00    	je     e598 <fwp_main_thread+0x6e8>
    e316:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e31d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e321:	e9 4a fd ff ff       	jmp    e070 <fwp_main_thread+0x1c0>
    e326:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e32d:	00 00 00 
    e330:	48 89 01             	mov    %rax,(%rcx)
    e333:	e9 72 fd ff ff       	jmp    e0aa <fwp_main_thread+0x1fa>
    e338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e33f:	00 
    e340:	48 83 3d f0 70 01 00 	cmpq   $0x0,0x170f0(%rip)        # 25438 <fwp_state_len>
    e347:	00 
    e348:	0f 84 a2 fe ff ff    	je     e1f0 <fwp_main_thread+0x340>
    e34e:	48 83 3d 42 54 01 00 	cmpq   $0x0,0x15442(%rip)        # 23798 <fwp_root>
    e355:	00 
    e356:	c7 05 20 4d 01 00 00 	movl   $0x0,0x14d20(%rip)        # 23080 <fwp_exit_code>
    e35d:	00 00 00 
    e360:	0f 85 7d 02 00 00    	jne    e5e3 <fwp_main_thread+0x733>
    e366:	e8 55 93 ff ff       	call   76c0 <fwp_free_zombie>
    e36b:	48 83 3d 15 54 01 00 	cmpq   $0x0,0x15415(%rip)        # 23788 <fwp_ready_head>
    e372:	00 
    e373:	0f 85 9c 53 ff ff    	jne    3715 <fwp_main_thread.cold>
    e379:	48 83 3d f7 53 01 00 	cmpq   $0x0,0x153f7(%rip)        # 23778 <fwp_timers>
    e380:	00 
    e381:	0f 85 8e 53 ff ff    	jne    3715 <fwp_main_thread.cold>
    e387:	8b 1d d7 4d 01 00    	mov    0x14dd7(%rip),%ebx        # 23164 <fwp_stack_pool_n>
    e38d:	85 db                	test   %ebx,%ebx
    e38f:	74 36                	je     e3c7 <fwp_main_thread+0x517>
    e391:	83 eb 01             	sub    $0x1,%ebx
    e394:	48 8d 05 e5 4d 01 00 	lea    0x14de5(%rip),%rax        # 23180 <fwp_stack_pool>
    e39b:	48 63 d3             	movslq %ebx,%rdx
    e39e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e3a2:	eb 07                	jmp    e3ab <fwp_main_thread+0x4fb>
    e3a4:	0f 1f 40 00          	nopl   0x0(%rax)
    e3a8:	83 eb 01             	sub    $0x1,%ebx
    e3ab:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e3af:	be 00 00 00 10       	mov    $0x10000000,%esi
    e3b4:	89 1d aa 4d 01 00    	mov    %ebx,0x14daa(%rip)        # 23164 <fwp_stack_pool_n>
    e3ba:	48 83 ed 08          	sub    $0x8,%rbp
    e3be:	e8 ed 51 ff ff       	call   35b0 <munmap@plt>
    e3c3:	85 db                	test   %ebx,%ebx
    e3c5:	75 e1                	jne    e3a8 <fwp_main_thread+0x4f8>
    e3c7:	8b 3d 4f 4c 00 00    	mov    0x4c4f(%rip),%edi        # 1301c <fwp_epfd>
    e3cd:	85 ff                	test   %edi,%edi
    e3cf:	78 05                	js     e3d6 <fwp_main_thread+0x526>
    e3d1:	e8 da 50 ff ff       	call   34b0 <close@plt>
    e3d6:	4c 8b 25 a3 4f 01 00 	mov    0x14fa3(%rip),%r12        # 23380 <fwp_nfdws>
    e3dd:	48 8b 2d a4 4f 01 00 	mov    0x14fa4(%rip),%rbp        # 23388 <fwp_fdws>
    e3e4:	31 db                	xor    %ebx,%ebx
    e3e6:	c7 05 2c 4c 00 00 ff 	movl   $0xffffffff,0x4c2c(%rip)        # 1301c <fwp_epfd>
    e3ed:	ff ff ff 
    e3f0:	4d 85 e4             	test   %r12,%r12
    e3f3:	74 38                	je     e42d <fwp_main_thread+0x57d>
    e3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e3fc:	00 00 00 00 
    e400:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e405:	48 85 ff             	test   %rdi,%rdi
    e408:	74 1a                	je     e424 <fwp_main_thread+0x574>
    e40a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e40e:	0f 85 01 53 ff ff    	jne    3715 <fwp_main_thread.cold>
    e414:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e419:	0f 85 f6 52 ff ff    	jne    3715 <fwp_main_thread.cold>
    e41f:	e8 2c 73 ff ff       	call   5750 <fwp_mem_free>
    e424:	48 83 c3 01          	add    $0x1,%rbx
    e428:	4c 39 e3             	cmp    %r12,%rbx
    e42b:	75 d3                	jne    e400 <fwp_main_thread+0x550>
    e42d:	48 89 ef             	mov    %rbp,%rdi
    e430:	e8 1b 73 ff ff       	call   5750 <fwp_mem_free>
    e435:	48 8b 15 5c 53 01 00 	mov    0x1535c(%rip),%rdx        # 23798 <fwp_root>
    e43c:	48 c7 05 41 4f 01 00 	movq   $0x0,0x14f41(%rip)        # 23388 <fwp_fdws>
    e443:	00 00 00 00 
    e447:	48 c7 05 2e 4f 01 00 	movq   $0x0,0x14f2e(%rip)        # 23380 <fwp_nfdws>
    e44e:	00 00 00 00 
    e452:	48 85 d2             	test   %rdx,%rdx
    e455:	74 4e                	je     e4a5 <fwp_main_thread+0x5f5>
    e457:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e45c:	0f 85 b3 52 ff ff    	jne    3715 <fwp_main_thread.cold>
    e462:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e469:	00 
    e46a:	0f 85 a5 52 ff ff    	jne    3715 <fwp_main_thread.cold>
    e470:	48 83 3d c0 6f 01 00 	cmpq   $0x0,0x16fc0(%rip)        # 25438 <fwp_state_len>
    e477:	00 
    e478:	0f 85 97 52 ff ff    	jne    3715 <fwp_main_thread.cold>
    e47e:	48 83 3d a2 6f 01 00 	cmpq   $0x0,0x16fa2(%rip)        # 25428 <fwp_state_owners>
    e485:	00 
    e486:	0f 85 89 52 ff ff    	jne    3715 <fwp_main_thread.cold>
    e48c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e491:	31 c0                	xor    %eax,%eax
    e493:	48 8d 3d 06 4f 01 00 	lea    0x14f06(%rip),%rdi        # 233a0 <fwp_root_context>
    e49a:	f3 48 ab             	rep stos %rax,(%rdi)
    e49d:	48 89 d7             	mov    %rdx,%rdi
    e4a0:	e8 ab 72 ff ff       	call   5750 <fwp_mem_free>
    e4a5:	48 8b 3d 74 4b 00 00 	mov    0x4b74(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e4ac:	48 c7 05 e9 52 01 00 	movq   $0x0,0x152e9(%rip)        # 237a0 <fwp_cur>
    e4b3:	00 00 00 00 
    e4b7:	48 c7 05 d6 52 01 00 	movq   $0x0,0x152d6(%rip)        # 23798 <fwp_root>
    e4be:	00 00 00 00 
    e4c2:	e8 c9 50 ff ff       	call   3590 <fflush@plt>
    e4c7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e4ce:	00 
    e4cf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e4d6:	00 00 
    e4d8:	0f 85 fb 00 00 00    	jne    e5d9 <fwp_main_thread+0x729>
    e4de:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e4e5:	31 c0                	xor    %eax,%eax
    e4e7:	5b                   	pop    %rbx
    e4e8:	5d                   	pop    %rbp
    e4e9:	41 5c                	pop    %r12
    e4eb:	c3                   	ret
    e4ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e4f0:	48 89 05 81 52 01 00 	mov    %rax,0x15281(%rip)        # 23778 <fwp_timers>
    e4f7:	e9 ff fb ff ff       	jmp    e0fb <fwp_main_thread+0x24b>
    e4fc:	0f 1f 40 00          	nopl   0x0(%rax)
    e500:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e504:	0f 85 66 fd ff ff    	jne    e270 <fwp_main_thread+0x3c0>
    e50a:	48 89 ef             	mov    %rbp,%rdi
    e50d:	e8 ae 5d ff ff       	call   42c0 <fwp_cancel_tree.part.0>
    e512:	e9 59 fd ff ff       	jmp    e270 <fwp_main_thread+0x3c0>
    e517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e51e:	00 00 
    e520:	48 8d 3d a9 58 ff ff 	lea    -0xa757(%rip),%rdi        # 3dd0 <descent_phase_report>
    e527:	e8 d4 02 00 00       	call   e800 <atexit>
    e52c:	85 c0                	test   %eax,%eax
    e52e:	0f 85 98 00 00 00    	jne    e5cc <fwp_main_thread+0x71c>
    e534:	c7 05 aa 4b 01 00 01 	movl   $0x1,0x14baa(%rip)        # 230e8 <descent_registered>
    e53b:	00 00 00 
    e53e:	8b 05 2c 4b 00 00    	mov    0x4b2c(%rip),%eax        # 13070 <st.3>
    e544:	85 c0                	test   %eax,%eax
    e546:	0f 85 70 fa ff ff    	jne    dfbc <fwp_main_thread+0x10c>
    e54c:	e8 5f cc ff ff       	call   b1b0 <f0>
    e551:	48 c7 05 0c 4b 00 00 	movq   $0x0,0x4b0c(%rip)        # 13068 <v.2>
    e558:	00 00 00 00 
    e55c:	c7 05 0a 4b 00 00 01 	movl   $0x1,0x4b0a(%rip)        # 13070 <st.3>
    e563:	00 00 00 
    e566:	e9 51 fa ff ff       	jmp    dfbc <fwp_main_thread+0x10c>
    e56b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e570:	48 8d 3d a9 66 ff ff 	lea    -0x9957(%rip),%rdi        # 4c20 <fwp_heap_report>
    e577:	e8 84 02 00 00       	call   e800 <atexit>
    e57c:	e9 6d f9 ff ff       	jmp    deee <fwp_main_thread+0x3e>
    e581:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e588:	e8 a3 67 ff ff       	call   4d30 <fwp_heap_init>
    e58d:	e9 4e f9 ff ff       	jmp    dee0 <fwp_main_thread+0x30>
    e592:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e598:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e59c:	e9 cf fa ff ff       	jmp    e070 <fwp_main_thread+0x1c0>
    e5a1:	48 83 3d ef 51 01 00 	cmpq   $0x0,0x151ef(%rip)        # 23798 <fwp_root>
    e5a8:	00 
    e5a9:	c7 05 cd 4a 01 00 00 	movl   $0x0,0x14acd(%rip)        # 23080 <fwp_exit_code>
    e5b0:	00 00 00 
    e5b3:	0f 84 ad fd ff ff    	je     e366 <fwp_main_thread+0x4b6>
    e5b9:	e9 57 51 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e5be:	66 90                	xchg   %ax,%ax
    e5c0:	48 8d 3d 21 14 00 00 	lea    0x1421(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    e5c7:	e8 e4 5d ff ff       	call   43b0 <fwp_trap>
    e5cc:	e8 cf 57 ff ff       	call   3da0 <descent_phase_fail>
    e5d1:	48 89 c8             	mov    %rcx,%rax
    e5d4:	e9 d0 fc ff ff       	jmp    e2a9 <fwp_main_thread+0x3f9>
    e5d9:	e8 62 4e ff ff       	call   3440 <__stack_chk_fail@plt>
    e5de:	e9 32 51 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e5e3:	e9 2d 51 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e5e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e5ef:	00 

000000000000e5f0 <__divmodti4>:
    e5f0:	f3 0f 1e fa          	endbr64
    e5f4:	55                   	push   %rbp
    e5f5:	49 89 f1             	mov    %rsi,%r9
    e5f8:	49 89 d2             	mov    %rdx,%r10
    e5fb:	48 89 fe             	mov    %rdi,%rsi
    e5fe:	49 89 cb             	mov    %rcx,%r11
    e601:	48 89 e5             	mov    %rsp,%rbp
    e604:	41 57                	push   %r15
    e606:	41 56                	push   %r14
    e608:	41 55                	push   %r13
    e60a:	41 54                	push   %r12
    e60c:	53                   	push   %rbx
    e60d:	4c 89 c3             	mov    %r8,%rbx
    e610:	45 31 c0             	xor    %r8d,%r8d
    e613:	4d 85 c9             	test   %r9,%r9
    e616:	79 12                	jns    e62a <__divmodti4+0x3a>
    e618:	31 ff                	xor    %edi,%edi
    e61a:	48 f7 de             	neg    %rsi
    e61d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e624:	4c 19 cf             	sbb    %r9,%rdi
    e627:	49 89 f9             	mov    %rdi,%r9
    e62a:	4c 89 d8             	mov    %r11,%rax
    e62d:	4d 85 db             	test   %r11,%r11
    e630:	0f 88 1a 01 00 00    	js     e750 <__divmodti4+0x160>
    e636:	4c 89 d9             	mov    %r11,%rcx
    e639:	49 89 f3             	mov    %rsi,%r11
    e63c:	75 62                	jne    e6a0 <__divmodti4+0xb0>
    e63e:	4d 89 c4             	mov    %r8,%r12
    e641:	4d 39 d1             	cmp    %r10,%r9
    e644:	0f 83 46 01 00 00    	jae    e790 <__divmodti4+0x1a0>
    e64a:	4c 89 d8             	mov    %r11,%rax
    e64d:	4c 89 ca             	mov    %r9,%rdx
    e650:	49 f7 f2             	div    %r10
    e653:	49 89 c3             	mov    %rax,%r11
    e656:	31 c0                	xor    %eax,%eax
    e658:	48 89 d6             	mov    %rdx,%rsi
    e65b:	31 ff                	xor    %edi,%edi
    e65d:	4c 89 d9             	mov    %r11,%rcx
    e660:	48 89 c2             	mov    %rax,%rdx
    e663:	48 89 c8             	mov    %rcx,%rax
    e666:	4d 85 e4             	test   %r12,%r12
    e669:	74 0a                	je     e675 <__divmodti4+0x85>
    e66b:	48 f7 d8             	neg    %rax
    e66e:	48 83 d2 00          	adc    $0x0,%rdx
    e672:	48 f7 da             	neg    %rdx
    e675:	4d 85 c0             	test   %r8,%r8
    e678:	74 0a                	je     e684 <__divmodti4+0x94>
    e67a:	48 f7 de             	neg    %rsi
    e67d:	48 83 d7 00          	adc    $0x0,%rdi
    e681:	48 f7 df             	neg    %rdi
    e684:	48 89 33             	mov    %rsi,(%rbx)
    e687:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e68b:	5b                   	pop    %rbx
    e68c:	41 5c                	pop    %r12
    e68e:	41 5d                	pop    %r13
    e690:	41 5e                	pop    %r14
    e692:	41 5f                	pop    %r15
    e694:	5d                   	pop    %rbp
    e695:	c3                   	ret
    e696:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e69d:	00 00 00 
    e6a0:	4d 89 c4             	mov    %r8,%r12
    e6a3:	49 39 c1             	cmp    %rax,%r9
    e6a6:	0f 82 ce 00 00 00    	jb     e77a <__divmodti4+0x18a>
    e6ac:	31 ff                	xor    %edi,%edi
    e6ae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e6b3:	48 63 c7             	movslq %edi,%rax
    e6b6:	be 40 00 00 00       	mov    $0x40,%esi
    e6bb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e6c0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e6c5:	48 29 c6             	sub    %rax,%rsi
    e6c8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e6cd:	48 09 c8             	or     %rcx,%rax
    e6d0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e6d5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e6da:	49 89 c6             	mov    %rax,%r14
    e6dd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e6e1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e6e6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e6eb:	49 09 c1             	or     %rax,%r9
    e6ee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e6f2:	4c 89 c8             	mov    %r9,%rax
    e6f5:	49 f7 f6             	div    %r14
    e6f8:	48 89 d1             	mov    %rdx,%rcx
    e6fb:	49 89 c3             	mov    %rax,%r11
    e6fe:	49 89 c1             	mov    %rax,%r9
    e701:	49 f7 e2             	mul    %r10
    e704:	49 89 c6             	mov    %rax,%r14
    e707:	49 89 d2             	mov    %rdx,%r10
    e70a:	48 39 d1             	cmp    %rdx,%rcx
    e70d:	72 07                	jb     e716 <__divmodti4+0x126>
    e70f:	75 17                	jne    e728 <__divmodti4+0x138>
    e711:	49 39 c7             	cmp    %rax,%r15
    e714:	73 12                	jae    e728 <__divmodti4+0x138>
    e716:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e71a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e71e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e722:	49 89 d2             	mov    %rdx,%r10
    e725:	49 89 c6             	mov    %rax,%r14
    e728:	4c 89 f8             	mov    %r15,%rax
    e72b:	4c 29 f0             	sub    %r14,%rax
    e72e:	4c 19 d1             	sbb    %r10,%rcx
    e731:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e736:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e73b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e740:	48 09 c6             	or     %rax,%rsi
    e743:	48 89 cf             	mov    %rcx,%rdi
    e746:	31 c0                	xor    %eax,%eax
    e748:	4c 89 c9             	mov    %r9,%rcx
    e74b:	e9 10 ff ff ff       	jmp    e660 <__divmodti4+0x70>
    e750:	4c 89 d0             	mov    %r10,%rax
    e753:	4c 89 da             	mov    %r11,%rdx
    e756:	4d 89 c4             	mov    %r8,%r12
    e759:	49 89 f3             	mov    %rsi,%r11
    e75c:	48 f7 d8             	neg    %rax
    e75f:	49 f7 d4             	not    %r12
    e762:	48 83 d2 00          	adc    $0x0,%rdx
    e766:	49 89 c2             	mov    %rax,%r10
    e769:	48 f7 da             	neg    %rdx
    e76c:	48 89 d1             	mov    %rdx,%rcx
    e76f:	0f 84 cc fe ff ff    	je     e641 <__divmodti4+0x51>
    e775:	49 39 d1             	cmp    %rdx,%r9
    e778:	73 46                	jae    e7c0 <__divmodti4+0x1d0>
    e77a:	4c 89 cf             	mov    %r9,%rdi
    e77d:	31 c0                	xor    %eax,%eax
    e77f:	31 c9                	xor    %ecx,%ecx
    e781:	e9 da fe ff ff       	jmp    e660 <__divmodti4+0x70>
    e786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e78d:	00 00 00 
    e790:	4d 85 d2             	test   %r10,%r10
    e793:	75 0d                	jne    e7a2 <__divmodti4+0x1b2>
    e795:	b8 01 00 00 00       	mov    $0x1,%eax
    e79a:	31 d2                	xor    %edx,%edx
    e79c:	49 f7 f2             	div    %r10
    e79f:	49 89 c2             	mov    %rax,%r10
    e7a2:	4c 89 c8             	mov    %r9,%rax
    e7a5:	31 d2                	xor    %edx,%edx
    e7a7:	49 f7 f2             	div    %r10
    e7aa:	49 89 c1             	mov    %rax,%r9
    e7ad:	4c 89 d8             	mov    %r11,%rax
    e7b0:	49 f7 f2             	div    %r10
    e7b3:	49 89 c3             	mov    %rax,%r11
    e7b6:	4c 89 c8             	mov    %r9,%rax
    e7b9:	e9 9a fe ff ff       	jmp    e658 <__divmodti4+0x68>
    e7be:	66 90                	xchg   %ax,%ax
    e7c0:	45 31 f6             	xor    %r14d,%r14d
    e7c3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e7c8:	44 89 f7             	mov    %r14d,%edi
    e7cb:	45 85 f6             	test   %r14d,%r14d
    e7ce:	0f 85 df fe ff ff    	jne    e6b3 <__divmodti4+0xc3>
    e7d4:	4c 39 ca             	cmp    %r9,%rdx
    e7d7:	72 17                	jb     e7f0 <__divmodti4+0x200>
    e7d9:	31 c9                	xor    %ecx,%ecx
    e7db:	48 39 c6             	cmp    %rax,%rsi
    e7de:	73 10                	jae    e7f0 <__divmodti4+0x200>
    e7e0:	4c 89 cf             	mov    %r9,%rdi
    e7e3:	31 c0                	xor    %eax,%eax
    e7e5:	e9 76 fe ff ff       	jmp    e660 <__divmodti4+0x70>
    e7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e7f0:	4c 89 de             	mov    %r11,%rsi
    e7f3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e7f8:	48 29 c6             	sub    %rax,%rsi
    e7fb:	49 19 d1             	sbb    %rdx,%r9
    e7fe:	eb e0                	jmp    e7e0 <__divmodti4+0x1f0>

000000000000e800 <atexit>:
    e800:	f3 0f 1e fa          	endbr64
    e804:	48 8b 15 fd 47 00 00 	mov    0x47fd(%rip),%rdx        # 13008 <__dso_handle>
    e80b:	31 f6                	xor    %esi,%esi
    e80d:	e9 0e 4e ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e814 <_fini>:
    e814:	f3 0f 1e fa          	endbr64
    e818:	48 83 ec 08          	sub    $0x8,%rsp
    e81c:	48 83 c4 08          	add    $0x8,%rsp
    e820:	c3                   	ret
