
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d9 ff 00 00 	mov    0xffd9(%rip),%rax        # 12fe8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 02 fe 00 00    	push   0xfe02(%rip)        # 12e28 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 04 fe 00 00    	jmp    *0xfe04(%rip)        # 12e30 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 7e fc 00 00    	jmp    *0xfc7e(%rip)        # 12ff8 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 ae fa 00 00    	jmp    *0xfaae(%rip)        # 12e38 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 a6 fa 00 00    	jmp    *0xfaa6(%rip)        # 12e40 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 9e fa 00 00    	jmp    *0xfa9e(%rip)        # 12e48 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 96 fa 00 00    	jmp    *0xfa96(%rip)        # 12e50 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e58 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e60 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e68 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e70 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e78 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e80 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e88 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e90 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e98 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12ea0 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12ea8 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12eb0 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12eb8 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12ec0 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12ec8 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ed0 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ed8 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12ee0 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12ee8 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ef0 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ef8 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12f00 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12f08 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12f10 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12f18 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12f20 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12f28 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f30 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f38 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f40 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f48 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f50 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f58 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f60 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f68 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f70 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f78 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f80 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f88 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f90 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f98 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12fa0 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12fa8 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12fb0 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12fb8 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12fc0 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12fc8 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fd0 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d ba b9 00 00 	lea    0xb9ba(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    36d7:	4c 8d 05 b7 b9 00 00 	lea    0xb9b7(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 5a 0a 00 00       	call   4160 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_hof0.constprop.0.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>
    3710:	e8 ab ff ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>

0000000000003715 <fwp_main_thread.cold>:
    3715:	e8 96 fc ff ff       	call   33b0 <abort@plt>

000000000000371a <main.cold>:
    371a:	e8 91 fc ff ff       	call   33b0 <abort@plt>
    371f:	90                   	nop

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 01 dc 00 00 	lea    0xdc01(%rip),%rax        # 11340 <fwp_fn_table>
    373f:	48 89 05 52 1c 02 00 	mov    %rax,0x21c52(%rip)        # 25398 <fwp_fns>
    3746:	48 8b 05 d3 f8 00 00 	mov    0xf8d3(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 4c 1c 02 00 	mov    %rax,0x21c4c(%rip)        # 253a0 <fwp_prog_out>
    3754:	e8 77 0b 00 00       	call   42d0 <fwp_now_ns>
    3759:	48 8d 3d 99 ba 00 00 	lea    0xba99(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 f8 00 00 	mov    0xf858(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 ef a3 00 00 	lea    0xa3ef(%rip),%rdx        # dc10 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 e0 fe ff ff    	jne    371a <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 c4 fe ff ff    	jne    371a <main.cold>
    3856:	48 8b 3d c3 f7 00 00 	mov    0xf7c3(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 f8 01 00    	mov    0x1f818(%rip),%eax        # 23080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d 49 b9 00 00 	lea    0xb949(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38b9:	e8 a2 08 00 00       	call   4160 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d d6 c0 00 00 	lea    0xc0d6(%rip),%rdi        # f9a0 <_IO_stdin_used+0x9a0>
    38ca:	e8 91 08 00 00       	call   4160 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 39 fe ff ff    	jne    371a <main.cold>
    38e1:	48 8d 3d 90 c0 00 00 	lea    0xc090(%rip),%rdi        # f978 <_IO_stdin_used+0x978>
    38e8:	e8 73 08 00 00       	call   4160 <fwp_trap>
    38ed:	48 8d 3d 54 c0 00 00 	lea    0xc054(%rip),%rdi        # f948 <_IO_stdin_used+0x948>
    38f4:	e8 67 08 00 00       	call   4160 <fwp_trap>
    38f9:	48 8d 3d 20 c0 00 00 	lea    0xc020(%rip),%rdi        # f920 <_IO_stdin_used+0x920>
    3900:	e8 5b 08 00 00       	call   4160 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 a3 f6 00 00    	call   *0xf6a3(%rip)        # 12fd8 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d9 f6 00 00 	lea    0xf6d9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3947:	48 8d 05 d2 f6 00 00 	lea    0xf6d2(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 86 f6 00 00 	mov    0xf686(%rip),%rax        # 12fe0 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a9 f6 00 00 	lea    0xf6a9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3977:	48 8d 35 a2 f6 00 00 	lea    0xf6a2(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 55 f6 00 00 	mov    0xf655(%rip),%rax        # 12ff0 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d f6 00 00 00 	cmpb   $0x0,0xf68d(%rip)        # 13048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 32 f6 00 00 	cmpq   $0x0,0xf632(%rip)        # 12ff8 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 f6 00 00 	mov    0xf636(%rip),%rdi        # 13008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 f6 00 00 01 	movb   $0x1,0xf665(%rip)        # 13048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_tape_unlink_scope>:
    3bc0:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3bc4:	48 85 d2             	test   %rdx,%rdx
    3bc7:	74 3e                	je     3c07 <fwp_tape_unlink_scope+0x47>
    3bc9:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3bcc:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3bd0:	85 c9                	test   %ecx,%ecx
    3bd2:	78 3c                	js     3c10 <fwp_tape_unlink_scope+0x50>
    3bd4:	48 63 d1             	movslq %ecx,%rdx
    3bd7:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3bdb:	48 03 15 fe f4 01 00 	add    0x1f4fe(%rip),%rdx        # 230e0 <fwp_tapes>
    3be2:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3be5:	85 c0                	test   %eax,%eax
    3be7:	78 0e                	js     3bf7 <fwp_tape_unlink_scope+0x37>
    3be9:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3bed:	48 03 05 ec f4 01 00 	add    0x1f4ec(%rip),%rax        # 230e0 <fwp_tapes>
    3bf4:	89 48 48             	mov    %ecx,0x48(%rax)
    3bf7:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3bfe:	00 
    3bff:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c06:	ff 
    3c07:	c3                   	ret
    3c08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c0f:	00 
    3c10:	89 02                	mov    %eax,(%rdx)
    3c12:	eb d1                	jmp    3be5 <fwp_tape_unlink_scope+0x25>
    3c14:	90                   	nop
    3c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c1c:	00 00 00 00 

0000000000003c20 <fwp_args173>:
    3c20:	f3 0f 1e fa          	endbr64
    3c24:	c3                   	ret
    3c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c2c:	00 00 00 00 

0000000000003c30 <fwp_flush>:
    3c30:	48 8b 3d 69 17 02 00 	mov    0x21769(%rip),%rdi        # 253a0 <fwp_prog_out>
    3c37:	48 85 ff             	test   %rdi,%rdi
    3c3a:	74 1c                	je     3c58 <fwp_flush+0x28>
    3c3c:	48 83 ec 08          	sub    $0x8,%rsp
    3c40:	e8 4b f9 ff ff       	call   3590 <fflush@plt>
    3c45:	48 8b 3d d4 f3 00 00 	mov    0xf3d4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c4c:	48 83 c4 08          	add    $0x8,%rsp
    3c50:	e9 3b f9 ff ff       	jmp    3590 <fflush@plt>
    3c55:	0f 1f 00             	nopl   (%rax)
    3c58:	48 8b 3d c1 f3 00 00 	mov    0xf3c1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c5f:	e9 2c f9 ff ff       	jmp    3590 <fflush@plt>
    3c64:	90                   	nop
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_heap_oom>:
    3c70:	50                   	push   %rax
    3c71:	58                   	pop    %rax
    3c72:	ba 13 00 00 00       	mov    $0x13,%edx
    3c77:	be 01 00 00 00       	mov    $0x1,%esi
    3c7c:	48 8d 3d 85 b3 00 00 	lea    0xb385(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3c83:	48 83 ec 08          	sub    $0x8,%rsp
    3c87:	48 8b 0d b2 f3 00 00 	mov    0xf3b2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3c8e:	e8 ad f9 ff ff       	call   3640 <fwrite@plt>
    3c93:	31 ff                	xor    %edi,%edi
    3c95:	e8 f6 f8 ff ff       	call   3590 <fflush@plt>
    3c9a:	bf 66 00 00 00       	mov    $0x66,%edi
    3c9f:	e8 bc f9 ff ff       	call   3660 <_Exit@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_segv>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	48 83 ec 28          	sub    $0x28,%rsp
    3cb8:	48 8b 05 61 fa 01 00 	mov    0x1fa61(%rip),%rax        # 23720 <fwp_cur>
    3cbf:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3cc3:	41 89 f8             	mov    %edi,%r8d
    3cc6:	48 85 c0             	test   %rax,%rax
    3cc9:	74 6d                	je     3d38 <fwp_segv+0x88>
    3ccb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3ccf:	48 85 d2             	test   %rdx,%rdx
    3cd2:	74 64                	je     3d38 <fwp_segv+0x88>
    3cd4:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3cd8:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3cdd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3ce2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3ce7:	e8 14 f9 ff ff       	call   3600 <sysconf@plt>
    3cec:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3cf1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3cf6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3cfb:	48 01 d0             	add    %rdx,%rax
    3cfe:	48 39 c1             	cmp    %rax,%rcx
    3d01:	b8 00 00 00 00       	mov    $0x0,%eax
    3d06:	40 0f 92 c6          	setb   %sil
    3d0a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d11:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d15:	31 c0                	xor    %eax,%eax
    3d17:	48 39 d1             	cmp    %rdx,%rcx
    3d1a:	0f 93 c0             	setae  %al
    3d1d:	21 f0                	and    %esi,%eax
    3d1f:	85 c0                	test   %eax,%eax
    3d21:	75 4a                	jne    3d6d <fwp_segv+0xbd>
    3d23:	31 f6                	xor    %esi,%esi
    3d25:	44 89 c7             	mov    %r8d,%edi
    3d28:	48 83 c4 28          	add    $0x28,%rsp
    3d2c:	e9 ef f7 ff ff       	jmp    3520 <signal@plt>
    3d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d38:	48 8b 05 b1 f3 01 00 	mov    0x1f3b1(%rip),%rax        # 230f0 <fwp_main_stack_top>
    3d3f:	48 85 c0             	test   %rax,%rax
    3d42:	74 df                	je     3d23 <fwp_segv+0x73>
    3d44:	48 2b 05 9d f3 01 00 	sub    0x1f39d(%rip),%rax        # 230e8 <fwp_main_stack_size>
    3d4b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d52:	48 39 d1             	cmp    %rdx,%rcx
    3d55:	0f 93 c2             	setae  %dl
    3d58:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d5e:	48 39 c1             	cmp    %rax,%rcx
    3d61:	0f 92 c0             	setb   %al
    3d64:	0f b6 c0             	movzbl %al,%eax
    3d67:	21 d0                	and    %edx,%eax
    3d69:	85 c0                	test   %eax,%eax
    3d6b:	74 b6                	je     3d23 <fwp_segv+0x73>
    3d6d:	e8 be fe ff ff       	call   3c30 <fwp_flush>
    3d72:	bf 02 00 00 00       	mov    $0x2,%edi
    3d77:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3d7c:	48 8d 35 fd bc 00 00 	lea    0xbcfd(%rip),%rsi        # fa80 <msg.4>
    3d83:	e8 88 f6 ff ff       	call   3410 <write@plt>
    3d88:	bf 65 00 00 00       	mov    $0x65,%edi
    3d8d:	e8 2e f6 ff ff       	call   33c0 <_exit@plt>
    3d92:	0f 1f 00             	nopl   (%rax)
    3d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d9c:	00 00 00 00 

0000000000003da0 <fwp_heap_chunks>:
    3da0:	41 54                	push   %r12
    3da2:	55                   	push   %rbp
    3da3:	53                   	push   %rbx
    3da4:	48 83 ff 01          	cmp    $0x1,%rdi
    3da8:	0f 84 62 01 00 00    	je     3f10 <fwp_heap_chunks+0x170>
    3dae:	48 8b 05 7b 0d 02 00 	mov    0x20d7b(%rip),%rax        # 24b30 <fwp_heap+0x13f0>
    3db5:	4c 8d 05 74 0d 02 00 	lea    0x20d74(%rip),%r8        # 24b30 <fwp_heap+0x13f0>
    3dbc:	48 8b 1d 55 0d 02 00 	mov    0x20d55(%rip),%rbx        # 24b18 <fwp_heap+0x13d8>
    3dc3:	48 39 d8             	cmp    %rbx,%rax
    3dc6:	0f 83 57 01 00 00    	jae    3f23 <fwp_heap_chunks+0x183>
    3dcc:	48 8b 0d 65 0d 02 00 	mov    0x20d65(%rip),%rcx        # 24b38 <fwp_heap+0x13f8>
    3dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3dd7:	31 f6                	xor    %esi,%esi
    3dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ddd:	eb 1e                	jmp    3dfd <fwp_heap_chunks+0x5d>
    3ddf:	90                   	nop
    3de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3de4:	48 39 cf             	cmp    %rcx,%rdi
    3de7:	0f 84 03 01 00 00    	je     3ef0 <fwp_heap_chunks+0x150>
    3ded:	48 83 c0 01          	add    $0x1,%rax
    3df1:	48 89 ce             	mov    %rcx,%rsi
    3df4:	48 83 c2 28          	add    $0x28,%rdx
    3df8:	48 39 c3             	cmp    %rax,%rbx
    3dfb:	74 14                	je     3e11 <fwp_heap_chunks+0x71>
    3dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e00:	74 de                	je     3de0 <fwp_heap_chunks+0x40>
    3e02:	48 83 c0 01          	add    $0x1,%rax
    3e06:	31 f6                	xor    %esi,%esi
    3e08:	48 83 c2 28          	add    $0x28,%rdx
    3e0c:	48 39 c3             	cmp    %rax,%rbx
    3e0f:	75 ec                	jne    3dfd <fwp_heap_chunks+0x5d>
    3e11:	48 29 f3             	sub    %rsi,%rbx
    3e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e18:	48 8b 3d 01 0d 02 00 	mov    0x20d01(%rip),%rdi        # 24b20 <fwp_heap+0x13e0>
    3e1f:	48 29 35 4a 0d 02 00 	sub    %rsi,0x20d4a(%rip)        # 24b70 <fwp_heap+0x1430>
    3e26:	48 39 ef             	cmp    %rbp,%rdi
    3e29:	0f 83 96 00 00 00    	jae    3ec5 <fwp_heap_chunks+0x125>
    3e2f:	48 8b 05 da 0c 02 00 	mov    0x20cda(%rip),%rax        # 24b10 <fwp_heap+0x13d0>
    3e36:	48 39 e8             	cmp    %rbp,%rax
    3e39:	0f 82 eb 00 00 00    	jb     3f2a <fwp_heap_chunks+0x18a>
    3e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e43:	ba 03 00 00 00       	mov    $0x3,%edx
    3e48:	49 39 c4             	cmp    %rax,%r12
    3e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e4f:	4c 89 e6             	mov    %r12,%rsi
    3e52:	48 29 fe             	sub    %rdi,%rsi
    3e55:	48 c1 e7 10          	shl    $0x10,%rdi
    3e59:	48 03 3d 90 0c 02 00 	add    0x20c90(%rip),%rdi        # 24af0 <fwp_heap+0x13b0>
    3e60:	48 c1 e6 10          	shl    $0x10,%rsi
    3e64:	e8 77 f7 ff ff       	call   35e0 <mprotect@plt>
    3e69:	85 c0                	test   %eax,%eax
    3e6b:	0f 85 b9 00 00 00    	jne    3f2a <fwp_heap_chunks+0x18a>
    3e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3e76:	e8 85 f7 ff ff       	call   3600 <sysconf@plt>
    3e7b:	48 8b 35 9e 0c 02 00 	mov    0x20c9e(%rip),%rsi        # 24b20 <fwp_heap+0x13e0>
    3e82:	48 89 c1             	mov    %rax,%rcx
    3e85:	48 8b 05 ac 0c 02 00 	mov    0x20cac(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    3e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3e90:	48 89 ca             	mov    %rcx,%rdx
    3e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3e9b:	48 f7 da             	neg    %rdx
    3e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ea3:	48 21 d7             	and    %rdx,%rdi
    3ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eaa:	48 21 d6             	and    %rdx,%rsi
    3ead:	ba 03 00 00 00       	mov    $0x3,%edx
    3eb2:	48 29 fe             	sub    %rdi,%rsi
    3eb5:	e8 26 f7 ff ff       	call   35e0 <mprotect@plt>
    3eba:	85 c0                	test   %eax,%eax
    3ebc:	75 6c                	jne    3f2a <fwp_heap_chunks+0x18a>
    3ebe:	4c 89 25 5b 0c 02 00 	mov    %r12,0x20c5b(%rip)        # 24b20 <fwp_heap+0x13e0>
    3ec5:	48 89 ef             	mov    %rbp,%rdi
    3ec8:	48 89 2d 49 0c 02 00 	mov    %rbp,0x20c49(%rip)        # 24b18 <fwp_heap+0x13d8>
    3ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    3ed3:	48 39 3d 2e 0c 02 00 	cmp    %rdi,0x20c2e(%rip)        # 24b08 <fwp_heap+0x13c8>
    3eda:	73 07                	jae    3ee3 <fwp_heap_chunks+0x143>
    3edc:	48 89 3d 25 0c 02 00 	mov    %rdi,0x20c25(%rip)        # 24b08 <fwp_heap+0x13c8>
    3ee3:	48 89 d8             	mov    %rbx,%rax
    3ee6:	5b                   	pop    %rbx
    3ee7:	5d                   	pop    %rbp
    3ee8:	41 5c                	pop    %r12
    3eea:	c3                   	ret
    3eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3ef4:	48 29 f0             	sub    %rsi,%rax
    3ef7:	48 89 c3             	mov    %rax,%rbx
    3efa:	49 89 10             	mov    %rdx,(%r8)
    3efd:	48 89 d8             	mov    %rbx,%rax
    3f00:	48 29 3d 69 0c 02 00 	sub    %rdi,0x20c69(%rip)        # 24b70 <fwp_heap+0x1430>
    3f07:	5b                   	pop    %rbx
    3f08:	5d                   	pop    %rbp
    3f09:	41 5c                	pop    %r12
    3f0b:	c3                   	ret
    3f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f10:	48 8b 05 11 0c 02 00 	mov    0x20c11(%rip),%rax        # 24b28 <fwp_heap+0x13e8>
    3f17:	4c 8d 05 0a 0c 02 00 	lea    0x20c0a(%rip),%r8        # 24b28 <fwp_heap+0x13e8>
    3f1e:	e9 99 fe ff ff       	jmp    3dbc <fwp_heap_chunks+0x1c>
    3f23:	31 f6                	xor    %esi,%esi
    3f25:	e9 ea fe ff ff       	jmp    3e14 <fwp_heap_chunks+0x74>
    3f2a:	e8 41 fd ff ff       	call   3c70 <fwp_heap_oom>
    3f2f:	90                   	nop

0000000000003f30 <fwp_tape_buffers_dispose>:
    3f30:	53                   	push   %rbx
    3f31:	48 89 fb             	mov    %rdi,%rbx
    3f34:	48 8b 3f             	mov    (%rdi),%rdi
    3f37:	e8 64 f4 ff ff       	call   33a0 <free@plt>
    3f3c:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    3f40:	e8 5b f4 ff ff       	call   33a0 <free@plt>
    3f45:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f49:	e8 52 f4 ff ff       	call   33a0 <free@plt>
    3f4e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f52:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    3f59:	00 
    3f5a:	0f 11 03             	movups %xmm0,(%rbx)
    3f5d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3f61:	5b                   	pop    %rbx
    3f62:	c3                   	ret
    3f63:	66 90                	xchg   %ax,%ax
    3f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f6c:	00 00 00 00 

0000000000003f70 <buf_grow>:
    3f70:	48 83 ec 18          	sub    $0x18,%rsp
    3f74:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3f78:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3f7c:	74 7e                	je     3ffc <buf_grow+0x8c>
    3f7e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3f85:	48 29 c2             	sub    %rax,%rdx
    3f88:	48 39 f2             	cmp    %rsi,%rdx
    3f8b:	72 6f                	jb     3ffc <buf_grow+0x8c>
    3f8d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3f92:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3f96:	48 89 f9             	mov    %rdi,%rcx
    3f99:	48 39 d0             	cmp    %rdx,%rax
    3f9c:	73 48                	jae    3fe6 <buf_grow+0x76>
    3f9e:	48 85 c0             	test   %rax,%rax
    3fa1:	75 15                	jne    3fb8 <buf_grow+0x48>
    3fa3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fa7:	76 4c                	jbe    3ff5 <buf_grow+0x85>
    3fa9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fae:	eb 08                	jmp    3fb8 <buf_grow+0x48>
    3fb0:	48 01 c0             	add    %rax,%rax
    3fb3:	48 39 d0             	cmp    %rdx,%rax
    3fb6:	73 38                	jae    3ff0 <buf_grow+0x80>
    3fb8:	48 85 c0             	test   %rax,%rax
    3fbb:	79 f3                	jns    3fb0 <buf_grow+0x40>
    3fbd:	48 8b 39             	mov    (%rcx),%rdi
    3fc0:	48 89 d6             	mov    %rdx,%rsi
    3fc3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3fc8:	48 89 14 24          	mov    %rdx,(%rsp)
    3fcc:	e8 cf f5 ff ff       	call   35a0 <realloc@plt>
    3fd1:	48 8b 14 24          	mov    (%rsp),%rdx
    3fd5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3fda:	48 85 c0             	test   %rax,%rax
    3fdd:	74 1d                	je     3ffc <buf_grow+0x8c>
    3fdf:	48 89 01             	mov    %rax,(%rcx)
    3fe2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    3fe6:	48 83 c4 18          	add    $0x18,%rsp
    3fea:	c3                   	ret
    3feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ff0:	48 89 c2             	mov    %rax,%rdx
    3ff3:	eb c8                	jmp    3fbd <buf_grow+0x4d>
    3ff5:	ba 40 00 00 00       	mov    $0x40,%edx
    3ffa:	eb c1                	jmp    3fbd <buf_grow+0x4d>
    3ffc:	48 8b 0d 3d f0 00 00 	mov    0xf03d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    4003:	ba 13 00 00 00       	mov    $0x13,%edx
    4008:	be 01 00 00 00       	mov    $0x1,%esi
    400d:	48 8d 3d f4 af 00 00 	lea    0xaff4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4014:	e8 27 f6 ff ff       	call   3640 <fwrite@plt>
    4019:	31 ff                	xor    %edi,%edi
    401b:	e8 70 f5 ff ff       	call   3590 <fflush@plt>
    4020:	bf 66 00 00 00       	mov    $0x66,%edi
    4025:	e8 36 f6 ff ff       	call   3660 <_Exit@plt>
    402a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004030 <buf_put>:
    4030:	41 54                	push   %r12
    4032:	49 89 f4             	mov    %rsi,%r12
    4035:	48 89 d6             	mov    %rdx,%rsi
    4038:	55                   	push   %rbp
    4039:	48 89 fd             	mov    %rdi,%rbp
    403c:	53                   	push   %rbx
    403d:	48 89 d3             	mov    %rdx,%rbx
    4040:	e8 2b ff ff ff       	call   3f70 <buf_grow>
    4045:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4049:	48 89 da             	mov    %rbx,%rdx
    404c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4050:	4c 89 e6             	mov    %r12,%rsi
    4053:	e8 18 f5 ff ff       	call   3570 <memcpy@plt>
    4058:	48 8b 45 00          	mov    0x0(%rbp),%rax
    405c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4060:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4064:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4068:	5b                   	pop    %rbx
    4069:	5d                   	pop    %rbp
    406a:	41 5c                	pop    %r12
    406c:	c3                   	ret
    406d:	0f 1f 00             	nopl   (%rax)

0000000000004070 <fwp_cancel_tree.part.0>:
    4070:	48 3b 3d a9 f6 01 00 	cmp    0x1f6a9(%rip),%rdi        # 23720 <fwp_cur>
    4077:	53                   	push   %rbx
    4078:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    407c:	74 35                	je     40b3 <fwp_cancel_tree.part.0+0x43>
    407e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4082:	75 2f                	jne    40b3 <fwp_cancel_tree.part.0+0x43>
    4084:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4088:	75 29                	jne    40b3 <fwp_cancel_tree.part.0+0x43>
    408a:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 23700 <fwp_ready_tail>
    4091:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4095:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    409c:	00 00 00 00 
    40a0:	48 85 c0             	test   %rax,%rax
    40a3:	74 33                	je     40d8 <fwp_cancel_tree.part.0+0x68>
    40a5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ac:	48 89 3d 4d f6 01 00 	mov    %rdi,0x1f64d(%rip)        # 23700 <fwp_ready_tail>
    40b3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40b7:	48 85 db             	test   %rbx,%rbx
    40ba:	74 17                	je     40d3 <fwp_cancel_tree.part.0+0x63>
    40bc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    40c0:	75 08                	jne    40ca <fwp_cancel_tree.part.0+0x5a>
    40c2:	48 89 df             	mov    %rbx,%rdi
    40c5:	e8 a6 ff ff ff       	call   4070 <fwp_cancel_tree.part.0>
    40ca:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    40ce:	48 85 db             	test   %rbx,%rbx
    40d1:	75 e9                	jne    40bc <fwp_cancel_tree.part.0+0x4c>
    40d3:	5b                   	pop    %rbx
    40d4:	c3                   	ret
    40d5:	0f 1f 00             	nopl   (%rax)
    40d8:	48 89 3d 29 f6 01 00 	mov    %rdi,0x1f629(%rip)        # 23708 <fwp_ready_head>
    40df:	eb cb                	jmp    40ac <fwp_cancel_tree.part.0+0x3c>
    40e1:	0f 1f 40 00          	nopl   0x0(%rax)
    40e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    40ec:	00 00 00 00 

00000000000040f0 <fwp_finish_float>:
    40f0:	53                   	push   %rbx
    40f1:	be 2e 00 00 00       	mov    $0x2e,%esi
    40f6:	48 89 fb             	mov    %rdi,%rbx
    40f9:	e8 62 f3 ff ff       	call   3460 <strchr@plt>
    40fe:	48 85 c0             	test   %rax,%rax
    4101:	74 05                	je     4108 <fwp_finish_float+0x18>
    4103:	5b                   	pop    %rbx
    4104:	c3                   	ret
    4105:	0f 1f 00             	nopl   (%rax)
    4108:	be 65 00 00 00       	mov    $0x65,%esi
    410d:	48 89 df             	mov    %rbx,%rdi
    4110:	e8 4b f3 ff ff       	call   3460 <strchr@plt>
    4115:	48 85 c0             	test   %rax,%rax
    4118:	75 e9                	jne    4103 <fwp_finish_float+0x13>
    411a:	48 8d 35 1b b0 00 00 	lea    0xb01b(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    4121:	48 89 df             	mov    %rbx,%rdi
    4124:	e8 67 f5 ff ff       	call   3690 <strstr@plt>
    4129:	48 85 c0             	test   %rax,%rax
    412c:	75 d5                	jne    4103 <fwp_finish_float+0x13>
    412e:	48 8d 35 e7 ae 00 00 	lea    0xaee7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4135:	48 89 df             	mov    %rbx,%rdi
    4138:	e8 53 f5 ff ff       	call   3690 <strstr@plt>
    413d:	48 85 c0             	test   %rax,%rax
    4140:	75 c1                	jne    4103 <fwp_finish_float+0x13>
    4142:	48 89 df             	mov    %rbx,%rdi
    4145:	e8 e6 f2 ff ff       	call   3430 <strlen@plt>
    414a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    414f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4153:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4158:	5b                   	pop    %rbx
    4159:	c3                   	ret
    415a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004160 <fwp_trap>:
    4160:	55                   	push   %rbp
    4161:	48 89 fd             	mov    %rdi,%rbp
    4164:	53                   	push   %rbx
    4165:	48 83 ec 08          	sub    $0x8,%rsp
    4169:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4170:	ff ff 
    4172:	e8 b9 fa ff ff       	call   3c30 <fwp_flush>
    4177:	31 c0                	xor    %eax,%eax
    4179:	48 89 e9             	mov    %rbp,%rcx
    417c:	be 02 00 00 00       	mov    $0x2,%esi
    4181:	48 8b 3d b8 ee 00 00 	mov    0xeeb8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4188:	48 8d 15 91 ae 00 00 	lea    0xae91(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    418f:	e8 bc f4 ff ff       	call   3650 <__fprintf_chk@plt>
    4194:	48 85 db             	test   %rbx,%rbx
    4197:	74 16                	je     41af <fwp_trap+0x4f>
    4199:	48 8b 3d a0 ee 00 00 	mov    0xeea0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    41a0:	e8 eb f3 ff ff       	call   3590 <fflush@plt>
    41a5:	bf 65 00 00 00       	mov    $0x65,%edi
    41aa:	e8 b1 f4 ff ff       	call   3660 <_Exit@plt>
    41af:	bf 65 00 00 00       	mov    $0x65,%edi
    41b4:	e8 77 f4 ff ff       	call   3630 <exit@plt>
    41b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000041c0 <fwp_closure_drop_push>:
    41c0:	41 56                	push   %r14
    41c2:	41 54                	push   %r12
    41c4:	49 89 f4             	mov    %rsi,%r12
    41c7:	55                   	push   %rbp
    41c8:	48 89 fd             	mov    %rdi,%rbp
    41cb:	53                   	push   %rbx
    41cc:	48 83 ec 18          	sub    $0x18,%rsp
    41d0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    41d4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    41d8:	74 26                	je     4200 <fwp_closure_drop_push+0x40>
    41da:	4c 8b 07             	mov    (%rdi),%r8
    41dd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    41e4:	00 
    41e5:	48 83 c3 01          	add    $0x1,%rbx
    41e9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    41ed:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    41f1:	48 83 c4 18          	add    $0x18,%rsp
    41f5:	5b                   	pop    %rbx
    41f6:	5d                   	pop    %rbp
    41f7:	41 5c                	pop    %r12
    41f9:	41 5e                	pop    %r14
    41fb:	c3                   	ret
    41fc:	0f 1f 40 00          	nopl   0x0(%rax)
    4200:	48 89 d8             	mov    %rbx,%rax
    4203:	48 c1 e8 3c          	shr    $0x3c,%rax
    4207:	0f 85 a9 00 00 00    	jne    42b6 <fwp_closure_drop_push+0xf6>
    420d:	48 89 d9             	mov    %rbx,%rcx
    4210:	48 c1 e1 04          	shl    $0x4,%rcx
    4214:	48 89 cf             	mov    %rcx,%rdi
    4217:	48 89 0c 24          	mov    %rcx,(%rsp)
    421b:	e8 60 f3 ff ff       	call   3580 <malloc@plt>
    4220:	48 8b 0c 24          	mov    (%rsp),%rcx
    4224:	48 85 c0             	test   %rax,%rax
    4227:	74 5f                	je     4288 <fwp_closure_drop_push+0xc8>
    4229:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    422d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4234:	00 
    4235:	48 89 c7             	mov    %rax,%rdi
    4238:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    423c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4241:	48 89 34 24          	mov    %rsi,(%rsp)
    4245:	e8 f6 f2 ff ff       	call   3540 <__memcpy_chk@plt>
    424a:	48 8b 34 24          	mov    (%rsp),%rsi
    424e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4253:	49 89 c0             	mov    %rax,%r8
    4256:	48 8d 45 18          	lea    0x18(%rbp),%rax
    425a:	48 39 c6             	cmp    %rax,%rsi
    425d:	74 1c                	je     427b <fwp_closure_drop_push+0xbb>
    425f:	48 89 f7             	mov    %rsi,%rdi
    4262:	4c 89 04 24          	mov    %r8,(%rsp)
    4266:	e8 35 f1 ff ff       	call   33a0 <free@plt>
    426b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    426f:	4c 8b 04 24          	mov    (%rsp),%r8
    4273:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    427a:	00 
    427b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    427f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4283:	e9 5d ff ff ff       	jmp    41e5 <fwp_closure_drop_push+0x25>
    4288:	48 8b 0d b1 ed 00 00 	mov    0xedb1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    428f:	ba 13 00 00 00       	mov    $0x13,%edx
    4294:	be 01 00 00 00       	mov    $0x1,%esi
    4299:	48 8d 3d 68 ad 00 00 	lea    0xad68(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42a0:	e8 9b f3 ff ff       	call   3640 <fwrite@plt>
    42a5:	31 ff                	xor    %edi,%edi
    42a7:	e8 e4 f2 ff ff       	call   3590 <fflush@plt>
    42ac:	bf 66 00 00 00       	mov    $0x66,%edi
    42b1:	e8 aa f3 ff ff       	call   3660 <_Exit@plt>
    42b6:	48 8d 3d 72 ad 00 00 	lea    0xad72(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42bd:	e8 9e fe ff ff       	call   4160 <fwp_trap>
    42c2:	0f 1f 00             	nopl   (%rax)
    42c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    42cc:	00 00 00 00 

00000000000042d0 <fwp_now_ns>:
    42d0:	53                   	push   %rbx
    42d1:	bf 01 00 00 00       	mov    $0x1,%edi
    42d6:	48 83 ec 20          	sub    $0x20,%rsp
    42da:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    42e1:	00 00 
    42e3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    42e8:	31 db                	xor    %ebx,%ebx
    42ea:	48 89 e6             	mov    %rsp,%rsi
    42ed:	e8 0e f1 ff ff       	call   3400 <clock_gettime@plt>
    42f2:	85 c0                	test   %eax,%eax
    42f4:	75 52                	jne    4348 <fwp_now_ns+0x78>
    42f6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    42fb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4300:	48 f7 2c 24          	imulq  (%rsp)
    4304:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    430b:	48 89 f7             	mov    %rsi,%rdi
    430e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4312:	48 01 f0             	add    %rsi,%rax
    4315:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    431c:	00 00 80 
    431f:	48 11 fa             	adc    %rdi,%rdx
    4322:	31 ff                	xor    %edi,%edi
    4324:	48 01 c6             	add    %rax,%rsi
    4327:	48 11 d7             	adc    %rdx,%rdi
    432a:	48 39 f1             	cmp    %rsi,%rcx
    432d:	48 19 fb             	sbb    %rdi,%rbx
    4330:	72 27                	jb     4359 <fwp_now_ns+0x89>
    4332:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4337:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    433e:	00 00 
    4340:	75 12                	jne    4354 <fwp_now_ns+0x84>
    4342:	48 83 c4 20          	add    $0x20,%rsp
    4346:	5b                   	pop    %rbx
    4347:	c3                   	ret
    4348:	48 8d 3d fa ac 00 00 	lea    0xacfa(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    434f:	e8 0c fe ff ff       	call   4160 <fwp_trap>
    4354:	e8 e7 f0 ff ff       	call   3440 <__stack_chk_fail@plt>
    4359:	48 8d 3d b0 b2 00 00 	lea    0xb2b0(%rip),%rdi        # f610 <_IO_stdin_used+0x610>
    4360:	e8 fb fd ff ff       	call   4160 <fwp_trap>
    4365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    436c:	00 00 00 00 

0000000000004370 <fwp_closure_drop.part.0>:
    4370:	53                   	push   %rbx
    4371:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4378:	66 0f 6f 05 40 b7 00 	movdqa 0xb740(%rip),%xmm0        # fac0 <msg.4+0x40>
    437f:	00 
    4380:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4387:	00 00 
    4389:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4390:	00 
    4391:	48 89 fe             	mov    %rdi,%rsi
    4394:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4399:	48 89 e7             	mov    %rsp,%rdi
    439c:	48 89 1c 24          	mov    %rbx,(%rsp)
    43a0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43a5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ac:	ff ff 
    43ae:	e8 0d fe ff ff       	call   41c0 <fwp_closure_drop_push>
    43b3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43b8:	48 85 c0             	test   %rax,%rax
    43bb:	74 39                	je     43f6 <fwp_closure_drop.part.0+0x86>
    43bd:	0f 1f 00             	nopl   (%rax)
    43c0:	48 8b 14 24          	mov    (%rsp),%rdx
    43c4:	48 83 e8 01          	sub    $0x1,%rax
    43c8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    43cd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    43d1:	8b 07                	mov    (%rdi),%eax
    43d3:	48 c1 e0 05          	shl    $0x5,%rax
    43d7:	48 03 05 ba 0f 02 00 	add    0x20fba(%rip),%rax        # 25398 <fwp_fns>
    43de:	48 8b 40 18          	mov    0x18(%rax),%rax
    43e2:	48 85 c0             	test   %rax,%rax
    43e5:	74 46                	je     442d <fwp_closure_drop.part.0+0xbd>
    43e7:	31 f6                	xor    %esi,%esi
    43e9:	ff 50 08             	call   *0x8(%rax)
    43ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f1:	48 85 c0             	test   %rax,%rax
    43f4:	75 ca                	jne    43c0 <fwp_closure_drop.part.0+0x50>
    43f6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    43fd:	ff ff 00 00 00 00 
    4403:	48 8b 3c 24          	mov    (%rsp),%rdi
    4407:	48 39 df             	cmp    %rbx,%rdi
    440a:	74 05                	je     4411 <fwp_closure_drop.part.0+0xa1>
    440c:	e8 8f ef ff ff       	call   33a0 <free@plt>
    4411:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4418:	00 
    4419:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4420:	00 00 
    4422:	75 15                	jne    4439 <fwp_closure_drop.part.0+0xc9>
    4424:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    442b:	5b                   	pop    %rbx
    442c:	c3                   	ret
    442d:	48 8d 3d 0c b2 00 00 	lea    0xb20c(%rip),%rdi        # f640 <_IO_stdin_used+0x640>
    4434:	e8 27 fd ff ff       	call   4160 <fwp_trap>
    4439:	e8 02 f0 ff ff       	call   3440 <__stack_chk_fail@plt>
    443e:	66 90                	xchg   %ax,%ax

0000000000004440 <fwp_tape_of>:
    4440:	0f b7 d7             	movzwl %di,%edx
    4443:	48 85 d2             	test   %rdx,%rdx
    4446:	74 28                	je     4470 <fwp_tape_of+0x30>
    4448:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    444c:	48 39 05 85 ec 01 00 	cmp    %rax,0x1ec85(%rip)        # 230d8 <fwp_ntapes>
    4453:	7e 1b                	jle    4470 <fwp_tape_of+0x30>
    4455:	48 6b c0 58          	imul   $0x58,%rax,%rax
    4459:	48 03 05 80 ec 01 00 	add    0x1ec80(%rip),%rax        # 230e0 <fwp_tapes>
    4460:	8b 50 04             	mov    0x4(%rax),%edx
    4463:	85 d2                	test   %edx,%edx
    4465:	74 09                	je     4470 <fwp_tape_of+0x30>
    4467:	48 c1 ff 10          	sar    $0x10,%rdi
    446b:	39 38                	cmp    %edi,(%rax)
    446d:	75 01                	jne    4470 <fwp_tape_of+0x30>
    446f:	c3                   	ret
    4470:	48 83 ec 08          	sub    $0x8,%rsp
    4474:	48 8d 3d f5 b1 00 00 	lea    0xb1f5(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    447b:	e8 e0 fc ff ff       	call   4160 <fwp_trap>

0000000000004480 <fwp_format_g.constprop.0>:
    4480:	41 57                	push   %r15
    4482:	b9 40 00 00 00       	mov    $0x40,%ecx
    4487:	ba 02 00 00 00       	mov    $0x2,%edx
    448c:	4c 8d 05 d2 ab 00 00 	lea    0xabd2(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    4493:	41 56                	push   %r14
    4495:	b8 01 00 00 00       	mov    $0x1,%eax
    449a:	41 55                	push   %r13
    449c:	41 54                	push   %r12
    449e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44a2:	55                   	push   %rbp
    44a3:	45 89 e1             	mov    %r12d,%r9d
    44a6:	53                   	push   %rbx
    44a7:	48 89 fb             	mov    %rdi,%rbx
    44aa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44b1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44b8:	00 00 
    44ba:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    44c1:	00 
    44c2:	41 89 f7             	mov    %esi,%r15d
    44c5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    44ca:	be 40 00 00 00       	mov    $0x40,%esi
    44cf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    44d4:	4c 89 f7             	mov    %r14,%rdi
    44d7:	e8 b4 ee ff ff       	call   3390 <__snprintf_chk@plt>
    44dc:	be 65 00 00 00       	mov    $0x65,%esi
    44e1:	4c 89 f7             	mov    %r14,%rdi
    44e4:	e8 77 ef ff ff       	call   3460 <strchr@plt>
    44e9:	31 f6                	xor    %esi,%esi
    44eb:	ba 0a 00 00 00       	mov    $0xa,%edx
    44f0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    44f4:	48 89 c5             	mov    %rax,%rbp
    44f7:	e8 64 f0 ff ff       	call   3560 <strtol@plt>
    44fc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4501:	49 89 c0             	mov    %rax,%r8
    4504:	83 c0 05             	add    $0x5,%eax
    4507:	83 f8 15             	cmp    $0x15,%eax
    450a:	0f 87 f0 01 00 00    	ja     4700 <fwp_format_g.constprop.0+0x280>
    4510:	45 89 e5             	mov    %r12d,%r13d
    4513:	45 29 c5             	sub    %r8d,%r13d
    4516:	45 85 ed             	test   %r13d,%r13d
    4519:	0f 8e 21 01 00 00    	jle    4640 <fwp_format_g.constprop.0+0x1c0>
    451f:	41 83 ff 01          	cmp    $0x1,%r15d
    4523:	0f 84 17 01 00 00    	je     4640 <fwp_format_g.constprop.0+0x1c0>
    4529:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    452e:	31 d2                	xor    %edx,%edx
    4530:	4d 63 df             	movslq %r15d,%r11
    4533:	3c 2d                	cmp    $0x2d,%al
    4535:	0f 94 c2             	sete   %dl
    4538:	4c 29 dd             	sub    %r11,%rbp
    453b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    453f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4543:	4d 89 f1             	mov    %r14,%r9
    4546:	4d 29 d1             	sub    %r10,%r9
    4549:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    454d:	3c 2d                	cmp    $0x2d,%al
    454f:	0f 84 0b 04 00 00    	je     4960 <fwp_format_g.constprop.0+0x4e0>
    4555:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    455a:	b9 48 00 00 00       	mov    $0x48,%ecx
    455f:	48 89 e8             	mov    %rbp,%rax
    4562:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4566:	49 8d 72 01          	lea    0x1(%r10),%rsi
    456a:	49 83 c1 47          	add    $0x47,%r9
    456e:	45 85 c0             	test   %r8d,%r8d
    4571:	0f 88 01 03 00 00    	js     4878 <fwp_format_g.constprop.0+0x3f8>
    4577:	45 0f b6 12          	movzbl (%r10),%r10d
    457b:	4d 63 e0             	movslq %r8d,%r12
    457e:	44 88 10             	mov    %r10b,(%rax)
    4581:	41 83 f8 07          	cmp    $0x7,%r8d
    4585:	0f 87 3d 02 00 00    	ja     47c8 <fwp_format_g.constprop.0+0x348>
    458b:	41 f6 c4 04          	test   $0x4,%r12b
    458f:	0f 85 02 04 00 00    	jne    4997 <fwp_format_g.constprop.0+0x517>
    4595:	45 85 e4             	test   %r12d,%r12d
    4598:	74 12                	je     45ac <fwp_format_g.constprop.0+0x12c>
    459a:	45 0f b6 06          	movzbl (%r14),%r8d
    459e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45a2:	41 f6 c4 02          	test   $0x2,%r12b
    45a6:	0f 85 13 04 00 00    	jne    49bf <fwp_format_g.constprop.0+0x53f>
    45ac:	4c 29 e1             	sub    %r12,%rcx
    45af:	4c 01 e7             	add    %r12,%rdi
    45b2:	4c 89 fa             	mov    %r15,%rdx
    45b5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45ba:	48 83 e9 01          	sub    $0x1,%rcx
    45be:	4d 63 ed             	movslq %r13d,%r13
    45c1:	48 89 0c 24          	mov    %rcx,(%rsp)
    45c5:	e8 76 ef ff ff       	call   3540 <__memcpy_chk@plt>
    45ca:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    45cf:	48 8b 0c 24          	mov    (%rsp),%rcx
    45d3:	ba 48 00 00 00       	mov    $0x48,%edx
    45d8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    45dc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    45e0:	4c 89 c8             	mov    %r9,%rax
    45e3:	48 29 c8             	sub    %rcx,%rax
    45e6:	48 39 d0             	cmp    %rdx,%rax
    45e9:	48 0f 42 c2          	cmovb  %rdx,%rax
    45ed:	4c 29 c9             	sub    %r9,%rcx
    45f0:	4c 89 ea             	mov    %r13,%rdx
    45f3:	48 01 c1             	add    %rax,%rcx
    45f6:	e8 45 ef ff ff       	call   3540 <__memcpy_chk@plt>
    45fb:	4c 01 e8             	add    %r13,%rax
    45fe:	48 29 e8             	sub    %rbp,%rax
    4601:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4606:	48 39 d0             	cmp    %rdx,%rax
    4609:	48 0f 47 c2          	cmova  %rdx,%rax
    460d:	89 c1                	mov    %eax,%ecx
    460f:	83 f8 08             	cmp    $0x8,%eax
    4612:	0f 83 28 02 00 00    	jae    4840 <fwp_format_g.constprop.0+0x3c0>
    4618:	a8 04                	test   $0x4,%al
    461a:	0f 85 64 03 00 00    	jne    4984 <fwp_format_g.constprop.0+0x504>
    4620:	85 c0                	test   %eax,%eax
    4622:	74 0f                	je     4633 <fwp_format_g.constprop.0+0x1b3>
    4624:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4629:	88 13                	mov    %dl,(%rbx)
    462b:	a8 02                	test   $0x2,%al
    462d:	0f 85 7b 03 00 00    	jne    49ae <fwp_format_g.constprop.0+0x52e>
    4633:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4637:	eb 36                	jmp    466f <fwp_format_g.constprop.0+0x1ef>
    4639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4640:	45 31 c9             	xor    %r9d,%r9d
    4643:	45 85 ed             	test   %r13d,%r13d
    4646:	4c 8d 05 27 aa 00 00 	lea    0xaa27(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    464d:	48 89 df             	mov    %rbx,%rdi
    4650:	45 0f 49 cd          	cmovns %r13d,%r9d
    4654:	ba 02 00 00 00       	mov    $0x2,%edx
    4659:	be 90 01 00 00       	mov    $0x190,%esi
    465e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4665:	b8 01 00 00 00       	mov    $0x1,%eax
    466a:	e8 21 ed ff ff       	call   3390 <__snprintf_chk@plt>
    466f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4674:	48 89 df             	mov    %rbx,%rdi
    4677:	e8 e4 ed ff ff       	call   3460 <strchr@plt>
    467c:	48 85 c0             	test   %rax,%rax
    467f:	74 4f                	je     46d0 <fwp_format_g.constprop.0+0x250>
    4681:	48 89 df             	mov    %rbx,%rdi
    4684:	e8 a7 ed ff ff       	call   3430 <strlen@plt>
    4689:	48 85 c0             	test   %rax,%rax
    468c:	75 1b                	jne    46a9 <fwp_format_g.constprop.0+0x229>
    468e:	eb 40                	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    4690:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    469c:	00 00 00 00 
    46a0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46a4:	48 85 c0             	test   %rax,%rax
    46a7:	74 27                	je     46d0 <fwp_format_g.constprop.0+0x250>
    46a9:	48 89 c2             	mov    %rax,%rdx
    46ac:	48 83 e8 01          	sub    $0x1,%rax
    46b0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46b4:	74 ea                	je     46a0 <fwp_format_g.constprop.0+0x220>
    46b6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46bb:	0f 84 6f 01 00 00    	je     4830 <fwp_format_g.constprop.0+0x3b0>
    46c1:	0f 1f 40 00          	nopl   0x0(%rax)
    46c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46cc:	00 00 00 00 
    46d0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    46d7:	00 
    46d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46df:	00 00 
    46e1:	0f 85 ec 02 00 00    	jne    49d3 <fwp_format_g.constprop.0+0x553>
    46e7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    46ee:	5b                   	pop    %rbx
    46ef:	5d                   	pop    %rbp
    46f0:	41 5c                	pop    %r12
    46f2:	41 5d                	pop    %r13
    46f4:	41 5e                	pop    %r14
    46f6:	41 5f                	pop    %r15
    46f8:	c3                   	ret
    46f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4700:	4c 29 f5             	sub    %r14,%rbp
    4703:	b9 40 00 00 00       	mov    $0x40,%ecx
    4708:	4c 89 f6             	mov    %r14,%rsi
    470b:	4c 89 04 24          	mov    %r8,(%rsp)
    470f:	49 89 ec             	mov    %rbp,%r12
    4712:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4717:	4c 89 e2             	mov    %r12,%rdx
    471a:	48 89 ef             	mov    %rbp,%rdi
    471d:	e8 1e ee ff ff       	call   3540 <__memcpy_chk@plt>
    4722:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4728:	be 2e 00 00 00       	mov    $0x2e,%esi
    472d:	48 89 ef             	mov    %rbp,%rdi
    4730:	e8 2b ed ff ff       	call   3460 <strchr@plt>
    4735:	4c 8b 04 24          	mov    (%rsp),%r8
    4739:	48 85 c0             	test   %rax,%rax
    473c:	74 40                	je     477e <fwp_format_g.constprop.0+0x2fe>
    473e:	4d 85 e4             	test   %r12,%r12
    4741:	74 3b                	je     477e <fwp_format_g.constprop.0+0x2fe>
    4743:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4748:	eb 23                	jmp    476d <fwp_format_g.constprop.0+0x2ed>
    474a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4751:	00 00 00 00 
    4755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    475c:	00 00 00 00 
    4760:	c6 00 00             	movb   $0x0,(%rax)
    4763:	48 83 e8 01          	sub    $0x1,%rax
    4767:	49 83 ec 01          	sub    $0x1,%r12
    476b:	74 11                	je     477e <fwp_format_g.constprop.0+0x2fe>
    476d:	80 38 30             	cmpb   $0x30,(%rax)
    4770:	74 ee                	je     4760 <fwp_format_g.constprop.0+0x2e0>
    4772:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4778:	0f 84 fb 01 00 00    	je     4979 <fwp_format_g.constprop.0+0x4f9>
    477e:	44 89 c0             	mov    %r8d,%eax
    4781:	ba 02 00 00 00       	mov    $0x2,%edx
    4786:	49 89 e9             	mov    %rbp,%r9
    4789:	be 90 01 00 00       	mov    $0x190,%esi
    478e:	f7 d8                	neg    %eax
    4790:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4797:	48 89 df             	mov    %rbx,%rdi
    479a:	41 0f 48 c0          	cmovs  %r8d,%eax
    479e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47a2:	41 83 e0 02          	and    $0x2,%r8d
    47a6:	41 83 c0 2b          	add    $0x2b,%r8d
    47aa:	50                   	push   %rax
    47ab:	31 c0                	xor    %eax,%eax
    47ad:	41 50                	push   %r8
    47af:	4c 8d 05 b4 a8 00 00 	lea    0xa8b4(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47b6:	e8 d5 eb ff ff       	call   3390 <__snprintf_chk@plt>
    47bb:	58                   	pop    %rax
    47bc:	5a                   	pop    %rdx
    47bd:	e9 0e ff ff ff       	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    47c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    47c8:	4d 8b 06             	mov    (%r14),%r8
    47cb:	48 83 c0 09          	add    $0x9,%rax
    47cf:	4c 89 f2             	mov    %r14,%rdx
    47d2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    47d6:	4c 89 07             	mov    %r8,(%rdi)
    47d9:	45 89 e0             	mov    %r12d,%r8d
    47dc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    47e1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    47e6:	49 89 f8             	mov    %rdi,%r8
    47e9:	49 29 c0             	sub    %rax,%r8
    47ec:	4c 29 c2             	sub    %r8,%rdx
    47ef:	45 01 e0             	add    %r12d,%r8d
    47f2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    47f6:	41 83 f8 08          	cmp    $0x8,%r8d
    47fa:	0f 82 ac fd ff ff    	jb     45ac <fwp_format_g.constprop.0+0x12c>
    4800:	48 89 0c 24          	mov    %rcx,(%rsp)
    4804:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4808:	45 31 d2             	xor    %r10d,%r10d
    480b:	45 89 d3             	mov    %r10d,%r11d
    480e:	41 83 c2 08          	add    $0x8,%r10d
    4812:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4816:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    481a:	45 39 c2             	cmp    %r8d,%r10d
    481d:	72 ec                	jb     480b <fwp_format_g.constprop.0+0x38b>
    481f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4823:	e9 84 fd ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    4828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    482f:	00 
    4830:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4835:	e9 96 fe ff ff       	jmp    46d0 <fwp_format_g.constprop.0+0x250>
    483a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4840:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4845:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4849:	48 89 ee             	mov    %rbp,%rsi
    484c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4850:	48 89 13             	mov    %rdx,(%rbx)
    4853:	89 c2                	mov    %eax,%edx
    4855:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    485a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    485f:	48 89 d9             	mov    %rbx,%rcx
    4862:	48 29 f9             	sub    %rdi,%rcx
    4865:	48 29 ce             	sub    %rcx,%rsi
    4868:	01 c1                	add    %eax,%ecx
    486a:	c1 e9 03             	shr    $0x3,%ecx
    486d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4870:	e9 be fd ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    4875:	0f 1f 00             	nopl   (%rax)
    4878:	c6 00 30             	movb   $0x30,(%rax)
    487b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    487f:	4c 89 fa             	mov    %r15,%rdx
    4882:	4c 89 e9             	mov    %r13,%rcx
    4885:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    488a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488f:	4c 89 14 24          	mov    %r10,(%rsp)
    4893:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4898:	e8 a3 ec ff ff       	call   3540 <__memcpy_chk@plt>
    489d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48a2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ac:	48 89 c7             	mov    %rax,%rdi
    48af:	4c 8b 14 24          	mov    (%rsp),%r10
    48b3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48b8:	4c 89 c8             	mov    %r9,%rax
    48bb:	4c 29 e8             	sub    %r13,%rax
    48be:	48 39 c8             	cmp    %rcx,%rax
    48c1:	48 0f 42 c1          	cmovb  %rcx,%rax
    48c5:	4d 29 cd             	sub    %r9,%r13
    48c8:	49 01 ff             	add    %rdi,%r15
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    48d2:	74 3d                	je     4911 <fwp_format_g.constprop.0+0x491>
    48d4:	41 f7 d0             	not    %r8d
    48d7:	31 f6                	xor    %esi,%esi
    48d9:	ba 48 00 00 00       	mov    $0x48,%edx
    48de:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    48e3:	48 39 d0             	cmp    %rdx,%rax
    48e6:	48 0f 43 d0          	cmovae %rax,%rdx
    48ea:	48 89 d1             	mov    %rdx,%rcx
    48ed:	48 29 c1             	sub    %rax,%rcx
    48f0:	48 83 c1 01          	add    $0x1,%rcx
    48f4:	48 39 d1             	cmp    %rdx,%rcx
    48f7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    48fb:	48 83 e8 01          	sub    $0x1,%rax
    48ff:	48 83 c6 01          	add    $0x1,%rsi
    4903:	48 29 d0             	sub    %rdx,%rax
    4906:	48 01 c8             	add    %rcx,%rax
    4909:	41 39 f0             	cmp    %esi,%r8d
    490c:	7f cb                	jg     48d9 <fwp_format_g.constprop.0+0x459>
    490e:	4d 01 c7             	add    %r8,%r15
    4911:	b9 48 00 00 00       	mov    $0x48,%ecx
    4916:	41 0f b6 12          	movzbl (%r10),%edx
    491a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    491e:	4c 89 f6             	mov    %r14,%rsi
    4921:	48 39 c8             	cmp    %rcx,%rax
    4924:	4c 89 1c 24          	mov    %r11,(%rsp)
    4928:	48 0f 43 c8          	cmovae %rax,%rcx
    492c:	41 88 17             	mov    %dl,(%r15)
    492f:	48 89 ca             	mov    %rcx,%rdx
    4932:	48 29 c2             	sub    %rax,%rdx
    4935:	48 83 c2 01          	add    $0x1,%rdx
    4939:	48 39 ca             	cmp    %rcx,%rdx
    493c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4940:	48 83 e8 01          	sub    $0x1,%rax
    4944:	48 29 c8             	sub    %rcx,%rax
    4947:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    494b:	49 63 d4             	movslq %r12d,%rdx
    494e:	e8 ed eb ff ff       	call   3540 <__memcpy_chk@plt>
    4953:	4c 8b 1c 24          	mov    (%rsp),%r11
    4957:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    495b:	e9 9e fc ff ff       	jmp    45fe <fwp_format_g.constprop.0+0x17e>
    4960:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4965:	b9 47 00 00 00       	mov    $0x47,%ecx
    496a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    496f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4974:	e9 e9 fb ff ff       	jmp    4562 <fwp_format_g.constprop.0+0xe2>
    4979:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    497f:	e9 fa fd ff ff       	jmp    477e <fwp_format_g.constprop.0+0x2fe>
    4984:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4988:	89 13                	mov    %edx,(%rbx)
    498a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    498e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4992:	e9 9c fc ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    4997:	41 8b 06             	mov    (%r14),%eax
    499a:	89 07                	mov    %eax,(%rdi)
    499c:	44 89 e0             	mov    %r12d,%eax
    499f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49a4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49a9:	e9 fe fb ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    49ae:	89 c2                	mov    %eax,%edx
    49b0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49b5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49ba:	e9 74 fc ff ff       	jmp    4633 <fwp_format_g.constprop.0+0x1b3>
    49bf:	44 89 e0             	mov    %r12d,%eax
    49c2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    49c8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    49ce:	e9 d9 fb ff ff       	jmp    45ac <fwp_format_g.constprop.0+0x12c>
    49d3:	e8 68 ea ff ff       	call   3440 <__stack_chk_fail@plt>
    49d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    49df:	00 

00000000000049e0 <fwp_heap_report>:
    49e0:	f3 0f 1e fa          	endbr64
    49e4:	41 54                	push   %r12
    49e6:	48 8d 3d 8c a6 00 00 	lea    0xa68c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    49ed:	55                   	push   %rbp
    49ee:	53                   	push   %rbx
    49ef:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    49f6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    49fd:	00 00 
    49ff:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a06:	00 
    4a07:	48 8d 35 76 a7 00 00 	lea    0xa776(%rip),%rsi        # f184 <_IO_stdin_used+0x184>
    4a0e:	e8 dd eb ff ff       	call   35f0 <fopen@plt>
    4a13:	48 85 c0             	test   %rax,%rax
    4a16:	0f 84 c5 00 00 00    	je     4ae1 <fwp_heap_report+0x101>
    4a1c:	48 89 c5             	mov    %rax,%rbp
    4a1f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a26:	48 89 e3             	mov    %rsp,%rbx
    4a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a30:	48 89 ea             	mov    %rbp,%rdx
    4a33:	be 00 01 00 00       	mov    $0x100,%esi
    4a38:	48 89 df             	mov    %rbx,%rdi
    4a3b:	e8 a0 ea ff ff       	call   34e0 <fgets@plt>
    4a40:	48 85 c0             	test   %rax,%rax
    4a43:	74 2b                	je     4a70 <fwp_heap_report+0x90>
    4a45:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a4b:	75 e3                	jne    4a30 <fwp_heap_report+0x50>
    4a4d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a51:	75 dd                	jne    4a30 <fwp_heap_report+0x50>
    4a53:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a58:	75 d6                	jne    4a30 <fwp_heap_report+0x50>
    4a5a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a5f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4a64:	31 f6                	xor    %esi,%esi
    4a66:	e8 f5 ea ff ff       	call   3560 <strtol@plt>
    4a6b:	49 89 c4             	mov    %rax,%r12
    4a6e:	eb c0                	jmp    4a30 <fwp_heap_report+0x50>
    4a70:	48 89 ef             	mov    %rbp,%rdi
    4a73:	e8 a8 e9 ff ff       	call   3420 <fclose@plt>
    4a78:	48 83 ec 08          	sub    $0x8,%rsp
    4a7c:	4c 8b 0d 85 00 02 00 	mov    0x20085(%rip),%r9        # 24b08 <fwp_heap+0x13c8>
    4a83:	4c 8b 05 de 00 02 00 	mov    0x200de(%rip),%r8        # 24b68 <fwp_heap+0x1428>
    4a8a:	48 8d 15 2f ac 00 00 	lea    0xac2f(%rip),%rdx        # f6c0 <_IO_stdin_used+0x6c0>
    4a91:	41 54                	push   %r12
    4a93:	48 8b 0d c6 00 02 00 	mov    0x200c6(%rip),%rcx        # 24b60 <fwp_heap+0x1420>
    4a9a:	be 02 00 00 00       	mov    $0x2,%esi
    4a9f:	b8 02 00 00 00       	mov    $0x2,%eax
    4aa4:	f2 0f 10 0d d4 00 02 	movsd  0x200d4(%rip),%xmm1        # 24b80 <fwp_heap+0x1440>
    4aab:	00 
    4aac:	f2 0f 10 05 c4 00 02 	movsd  0x200c4(%rip),%xmm0        # 24b78 <fwp_heap+0x1438>
    4ab3:	00 
    4ab4:	48 8b 3d 85 e5 00 00 	mov    0xe585(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4abb:	e8 90 eb ff ff       	call   3650 <__fprintf_chk@plt>
    4ac0:	58                   	pop    %rax
    4ac1:	5a                   	pop    %rdx
    4ac2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4ac9:	00 
    4aca:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4ad1:	00 00 
    4ad3:	75 15                	jne    4aea <fwp_heap_report+0x10a>
    4ad5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4adc:	5b                   	pop    %rbx
    4add:	5d                   	pop    %rbp
    4ade:	41 5c                	pop    %r12
    4ae0:	c3                   	ret
    4ae1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ae8:	eb 8e                	jmp    4a78 <fwp_heap_report+0x98>
    4aea:	e8 51 e9 ff ff       	call   3440 <__stack_chk_fail@plt>
    4aef:	90                   	nop

0000000000004af0 <fwp_heap_init>:
    4af0:	66 0f 6f 05 d8 af 00 	movdqa 0xafd8(%rip),%xmm0        # fad0 <msg.4+0x50>
    4af7:	00 
    4af8:	41 54                	push   %r12
    4afa:	48 8d 05 7f fb 01 00 	lea    0x1fb7f(%rip),%rax        # 24680 <fwp_heap+0xf40>
    4b01:	ba 00 01 00 00       	mov    $0x100,%edx
    4b06:	55                   	push   %rbp
    4b07:	66 0f 6f 15 01 b0 00 	movdqa 0xb001(%rip),%xmm2        # fb10 <msg.4+0x90>
    4b0e:	00 
    4b0f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b13:	53                   	push   %rbx
    4b14:	0f 29 05 25 fb 01 00 	movaps %xmm0,0x1fb25(%rip)        # 24640 <fwp_heap+0xf00>
    4b1b:	66 0f 6f 05 bd af 00 	movdqa 0xafbd(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b22:	00 
    4b23:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b27:	c7 05 b3 ff 01 00 01 	movl   $0x1,0x1ffb3(%rip)        # 24ae4 <fwp_heap+0x13a4>
    4b2e:	00 00 00 
    4b31:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b36:	0f 29 05 13 fb 01 00 	movaps %xmm0,0x1fb13(%rip)        # 24650 <fwp_heap+0xf10>
    4b3d:	66 0f 6f 05 ab af 00 	movdqa 0xafab(%rip),%xmm0        # faf0 <msg.4+0x70>
    4b44:	00 
    4b45:	0f 29 05 14 fb 01 00 	movaps %xmm0,0x1fb14(%rip)        # 24660 <fwp_heap+0xf20>
    4b4c:	66 0f 6f 05 ac af 00 	movdqa 0xafac(%rip),%xmm0        # fb00 <msg.4+0x80>
    4b53:	00 
    4b54:	0f 29 05 15 fb 01 00 	movaps %xmm0,0x1fb15(%rip)        # 24670 <fwp_heap+0xf30>
    4b5b:	89 d3                	mov    %edx,%ebx
    4b5d:	66 0f 6e e2          	movd   %edx,%xmm4
    4b61:	48 83 c0 10          	add    $0x10,%rax
    4b65:	01 d2                	add    %edx,%edx
    4b67:	c1 eb 02             	shr    $0x2,%ebx
    4b6a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4b6e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4b73:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4b77:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4b7c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4b80:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4b84:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4b89:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4b8e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4b92:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4b97:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4b9b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4b9f:	48 39 c7             	cmp    %rax,%rdi
    4ba2:	75 b7                	jne    4b5b <fwp_heap_init+0x6b>
    4ba4:	4c 8d 05 95 eb 01 00 	lea    0x1eb95(%rip),%r8        # 23740 <fwp_heap>
    4bab:	31 c9                	xor    %ecx,%ecx
    4bad:	31 c0                	xor    %eax,%eax
    4baf:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bbd:	00 00 00 
    4bc0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4bc7:	00 
    4bc8:	48 39 ca             	cmp    %rcx,%rdx
    4bcb:	73 0f                	jae    4bdc <fwp_heap_init+0xec>
    4bcd:	0f 1f 00             	nopl   (%rax)
    4bd0:	48 83 c0 01          	add    $0x1,%rax
    4bd4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4bd7:	48 39 ca             	cmp    %rcx,%rdx
    4bda:	72 f4                	jb     4bd0 <fwp_heap_init+0xe0>
    4bdc:	48 83 c1 10          	add    $0x10,%rcx
    4be0:	88 07                	mov    %al,(%rdi)
    4be2:	48 83 c7 01          	add    $0x1,%rdi
    4be6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4bed:	75 d1                	jne    4bc0 <fwp_heap_init+0xd0>
    4bef:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4bf6:	00 00 00 
    4bf9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4bfe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c05:	45 31 c9             	xor    %r9d,%r9d
    4c08:	31 d2                	xor    %edx,%edx
    4c0a:	31 ff                	xor    %edi,%edi
    4c0c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c12:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c17:	4c 89 e6             	mov    %r12,%rsi
    4c1a:	e8 31 e8 ff ff       	call   3450 <mmap@plt>
    4c1f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c23:	75 13                	jne    4c38 <fwp_heap_init+0x148>
    4c25:	48 c1 eb 02          	shr    $0x2,%rbx
    4c29:	83 ed 01             	sub    $0x1,%ebp
    4c2c:	75 d0                	jne    4bfe <fwp_heap_init+0x10e>
    4c2e:	e8 3d f0 ff ff       	call   3c70 <fwp_heap_oom>
    4c33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c38:	48 85 c0             	test   %rax,%rax
    4c3b:	74 f1                	je     4c2e <fwp_heap_init+0x13e>
    4c3d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c41:	48 89 05 b0 fe 01 00 	mov    %rax,0x1feb0(%rip)        # 24af8 <fwp_heap+0x13b8>
    4c48:	45 31 c9             	xor    %r9d,%r9d
    4c4b:	31 d2                	xor    %edx,%edx
    4c4d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c53:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c57:	31 ff                	xor    %edi,%edi
    4c59:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c5f:	66 31 c0             	xor    %ax,%ax
    4c62:	48 c1 e6 03          	shl    $0x3,%rsi
    4c66:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c6b:	4c 89 25 8e fe 01 00 	mov    %r12,0x1fe8e(%rip)        # 24b00 <fwp_heap+0x13c0>
    4c72:	48 89 05 77 fe 01 00 	mov    %rax,0x1fe77(%rip)        # 24af0 <fwp_heap+0x13b0>
    4c79:	48 89 1d 90 fe 01 00 	mov    %rbx,0x1fe90(%rip)        # 24b10 <fwp_heap+0x13d0>
    4c80:	48 89 35 b9 fe 01 00 	mov    %rsi,0x1feb9(%rip)        # 24b40 <fwp_heap+0x1400>
    4c87:	e8 c4 e7 ff ff       	call   3450 <mmap@plt>
    4c8c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c90:	74 9c                	je     4c2e <fwp_heap_init+0x13e>
    4c92:	48 8d 3d 16 a4 00 00 	lea    0xa416(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4c99:	48 89 05 98 fe 01 00 	mov    %rax,0x1fe98(%rip)        # 24b38 <fwp_heap+0x13f8>
    4ca0:	e8 db e6 ff ff       	call   3380 <getenv@plt>
    4ca5:	48 89 c2             	mov    %rax,%rdx
    4ca8:	31 c0                	xor    %eax,%eax
    4caa:	48 85 d2             	test   %rdx,%rdx
    4cad:	74 15                	je     4cc4 <fwp_heap_init+0x1d4>
    4caf:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cb2:	74 10                	je     4cc4 <fwp_heap_init+0x1d4>
    4cb4:	0f b6 02             	movzbl (%rdx),%eax
    4cb7:	83 e8 30             	sub    $0x30,%eax
    4cba:	74 13                	je     4ccf <fwp_heap_init+0x1df>
    4cbc:	85 c0                	test   %eax,%eax
    4cbe:	0f 95 c0             	setne  %al
    4cc1:	0f b6 c0             	movzbl %al,%eax
    4cc4:	5b                   	pop    %rbx
    4cc5:	5d                   	pop    %rbp
    4cc6:	89 05 1c fe 01 00    	mov    %eax,0x1fe1c(%rip)        # 24ae8 <fwp_heap+0x13a8>
    4ccc:	41 5c                	pop    %r12
    4cce:	c3                   	ret
    4ccf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4cd3:	85 c0                	test   %eax,%eax
    4cd5:	0f 95 c0             	setne  %al
    4cd8:	0f b6 c0             	movzbl %al,%eax
    4cdb:	eb e7                	jmp    4cc4 <fwp_heap_init+0x1d4>
    4cdd:	0f 1f 00             	nopl   (%rax)

0000000000004ce0 <fwp_wake_io>:
    4ce0:	48 8b 07             	mov    (%rdi),%rax
    4ce3:	48 85 c0             	test   %rax,%rax
    4ce6:	0f 84 f4 00 00 00    	je     4de0 <fwp_wake_io+0x100>
    4cec:	53                   	push   %rbx
    4ced:	4c 8b 05 0c ea 01 00 	mov    0x1ea0c(%rip),%r8        # 23700 <fwp_ready_tail>
    4cf4:	49 89 f9             	mov    %rdi,%r9
    4cf7:	48 89 c2             	mov    %rax,%rdx
    4cfa:	45 31 db             	xor    %r11d,%r11d
    4cfd:	45 31 d2             	xor    %r10d,%r10d
    4d00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d04:	eb 71                	jmp    4d77 <fwp_wake_io+0x97>
    4d06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d0d:	00 00 00 
    4d10:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d17:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d1e:	48 85 c9             	test   %rcx,%rcx
    4d21:	74 07                	je     4d2a <fwp_wake_io+0x4a>
    4d23:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d2a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d31:	00 00 00 00 
    4d35:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d3c:	49 8b 01             	mov    (%r9),%rax
    4d3f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d43:	75 2a                	jne    4d6f <fwp_wake_io+0x8f>
    4d45:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d49:	75 24                	jne    4d6f <fwp_wake_io+0x8f>
    4d4b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d4f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d56:	00 00 00 00 
    4d5a:	4d 85 c0             	test   %r8,%r8
    4d5d:	74 51                	je     4db0 <fwp_wake_io+0xd0>
    4d5f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4d66:	49 89 d0             	mov    %rdx,%r8
    4d69:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4d6f:	48 89 c2             	mov    %rax,%rdx
    4d72:	48 85 c0             	test   %rax,%rax
    4d75:	74 49                	je     4dc0 <fwp_wake_io+0xe0>
    4d77:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4d7e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4d82:	48 85 ff             	test   %rdi,%rdi
    4d85:	74 b8                	je     4d3f <fwp_wake_io+0x5f>
    4d87:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4d8e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d95:	48 85 f6             	test   %rsi,%rsi
    4d98:	0f 85 72 ff ff ff    	jne    4d10 <fwp_wake_io+0x30>
    4d9e:	48 89 0f             	mov    %rcx,(%rdi)
    4da1:	e9 78 ff ff ff       	jmp    4d1e <fwp_wake_io+0x3e>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 d3             	mov    %rdx,%rbx
    4db3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4db9:	eb ab                	jmp    4d66 <fwp_wake_io+0x86>
    4dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4dc0:	45 84 db             	test   %r11b,%r11b
    4dc3:	74 07                	je     4dcc <fwp_wake_io+0xec>
    4dc5:	48 89 1d 3c e9 01 00 	mov    %rbx,0x1e93c(%rip)        # 23708 <fwp_ready_head>
    4dcc:	45 84 d2             	test   %r10b,%r10b
    4dcf:	74 07                	je     4dd8 <fwp_wake_io+0xf8>
    4dd1:	4c 89 05 28 e9 01 00 	mov    %r8,0x1e928(%rip)        # 23700 <fwp_ready_tail>
    4dd8:	5b                   	pop    %rbx
    4dd9:	c3                   	ret
    4dda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4de0:	c3                   	ret
    4de1:	0f 1f 40 00          	nopl   0x0(%rax)
    4de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4dec:	00 00 00 00 

0000000000004df0 <fwp_tape_buffers_release>:
    4df0:	f3 0f 1e fa          	endbr64
    4df4:	53                   	push   %rbx
    4df5:	48 89 fb             	mov    %rdi,%rbx
    4df8:	48 83 ec 10          	sub    $0x10,%rsp
    4dfc:	48 8b 47 18          	mov    0x18(%rdi),%rax
    4e00:	48 85 c0             	test   %rax,%rax
    4e03:	0f 88 cf 00 00 00    	js     4ed8 <fwp_tape_buffers_release+0xe8>
    4e09:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    4e0d:	48 85 d2             	test   %rdx,%rdx
    4e10:	0f 88 c2 00 00 00    	js     4ed8 <fwp_tape_buffers_release+0xe8>
    4e16:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e1c:	0f 87 b6 00 00 00    	ja     4ed8 <fwp_tape_buffers_release+0xe8>
    4e22:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e26:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e2b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e2f:	48 29 c8             	sub    %rcx,%rax
    4e32:	48 c1 e8 03          	shr    $0x3,%rax
    4e36:	48 39 d0             	cmp    %rdx,%rax
    4e39:	0f 82 99 00 00 00    	jb     4ed8 <fwp_tape_buffers_release+0xe8>
    4e3f:	48 8d 3d 79 a2 00 00 	lea    0xa279(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e46:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e4b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e4f:	e8 2c e5 ff ff       	call   3380 <getenv@plt>
    4e54:	48 8b 14 24          	mov    (%rsp),%rdx
    4e58:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e5d:	48 85 c0             	test   %rax,%rax
    4e60:	74 09                	je     4e6b <fwp_tape_buffers_release+0x7b>
    4e62:	80 38 30             	cmpb   $0x30,(%rax)
    4e65:	0f 84 8d 00 00 00    	je     4ef8 <fwp_tape_buffers_release+0x108>
    4e6b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4e6f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4e73:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4e7a:	77 68                	ja     4ee4 <fwp_tape_buffers_release+0xf4>
    4e7c:	48 8d 3d 1d e2 01 00 	lea    0x1e21d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    4e83:	48 89 04 24          	mov    %rax,(%rsp)
    4e87:	e8 a4 f0 ff ff       	call   3f30 <fwp_tape_buffers_dispose>
    4e8c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4e90:	48 8b 04 24          	mov    (%rsp),%rax
    4e94:	0f 29 05 05 e2 01 00 	movaps %xmm0,0x1e205(%rip)        # 230a0 <fwp_tape_workspace>
    4e9b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ea0:	48 89 05 e1 e1 01 00 	mov    %rax,0x1e1e1(%rip)        # 23088 <fwp_tape_cached_bytes>
    4ea7:	0f 29 05 02 e2 01 00 	movaps %xmm0,0x1e202(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    4eae:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    4eb2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4eb6:	48 89 15 03 e2 01 00 	mov    %rdx,0x1e203(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    4ebd:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    4ec4:	00 
    4ec5:	0f 11 03             	movups %xmm0,(%rbx)
    4ec8:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4ecc:	48 83 c4 10          	add    $0x10,%rsp
    4ed0:	5b                   	pop    %rbx
    4ed1:	c3                   	ret
    4ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ed8:	48 8d 3d e0 a1 00 00 	lea    0xa1e0(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4edf:	e8 9c e4 ff ff       	call   3380 <getenv@plt>
    4ee4:	48 83 c4 10          	add    $0x10,%rsp
    4ee8:	48 89 df             	mov    %rbx,%rdi
    4eeb:	5b                   	pop    %rbx
    4eec:	e9 3f f0 ff ff       	jmp    3f30 <fwp_tape_buffers_dispose>
    4ef1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ef8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4efc:	0f 85 69 ff ff ff    	jne    4e6b <fwp_tape_buffers_release+0x7b>
    4f02:	48 83 c4 10          	add    $0x10,%rsp
    4f06:	48 89 df             	mov    %rbx,%rdi
    4f09:	5b                   	pop    %rbx
    4f0a:	e9 21 f0 ff ff       	jmp    3f30 <fwp_tape_buffers_dispose>
    4f0f:	90                   	nop

0000000000004f10 <fwp_poll_events>:
    4f10:	53                   	push   %rbx
    4f11:	48 83 ec 20          	sub    $0x20,%rsp
    4f15:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f1c:	00 00 
    4f1e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f23:	31 c0                	xor    %eax,%eax
    4f25:	e8 a6 f3 ff ff       	call   42d0 <fwp_now_ns>
    4f2a:	48 8b 1d c7 e7 01 00 	mov    0x1e7c7(%rip),%rbx        # 236f8 <fwp_timers>
    4f31:	48 85 db             	test   %rbx,%rbx
    4f34:	0f 84 e6 00 00 00    	je     5020 <fwp_poll_events+0x110>
    4f3a:	48 89 c6             	mov    %rax,%rsi
    4f3d:	48 89 da             	mov    %rbx,%rdx
    4f40:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f47:	eb 26                	jmp    4f6f <fwp_poll_events+0x5f>
    4f49:	90                   	nop
    4f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4f51:	00 00 00 00 
    4f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4f5c:	00 00 00 00 
    4f60:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f67:	48 89 c8             	mov    %rcx,%rax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 31                	je     4fa0 <fwp_poll_events+0x90>
    4f6f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4f73:	48 85 c0             	test   %rax,%rax
    4f76:	78 e8                	js     4f60 <fwp_poll_events+0x50>
    4f78:	48 39 c1             	cmp    %rax,%rcx
    4f7b:	7c e3                	jl     4f60 <fwp_poll_events+0x50>
    4f7d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f84:	48 85 d2             	test   %rdx,%rdx
    4f87:	74 1c                	je     4fa5 <fwp_poll_events+0x95>
    4f89:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4f8d:	48 39 c1             	cmp    %rax,%rcx
    4f90:	7c ce                	jl     4f60 <fwp_poll_events+0x50>
    4f92:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4f99:	48 85 d2             	test   %rdx,%rdx
    4f9c:	75 d1                	jne    4f6f <fwp_poll_events+0x5f>
    4f9e:	66 90                	xchg   %ax,%ax
    4fa0:	48 85 c0             	test   %rax,%rax
    4fa3:	78 7b                	js     5020 <fwp_poll_events+0x110>
    4fa5:	48 29 f0             	sub    %rsi,%rax
    4fa8:	48 89 c1             	mov    %rax,%rcx
    4fab:	48 85 c0             	test   %rax,%rax
    4fae:	0f 8e 9c 00 00 00    	jle    5050 <fwp_poll_events+0x140>
    4fb4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4fbb:	de 1b 43 
    4fbe:	48 f7 ea             	imul   %rdx
    4fc1:	48 89 c8             	mov    %rcx,%rax
    4fc4:	48 c1 f8 3f          	sar    $0x3f,%rax
    4fc8:	48 c1 fa 12          	sar    $0x12,%rdx
    4fcc:	48 29 c2             	sub    %rax,%rdx
    4fcf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    4fd6:	48 39 c1             	cmp    %rax,%rcx
    4fd9:	0f 95 c0             	setne  %al
    4fdc:	0f b6 c0             	movzbl %al,%eax
    4fdf:	48 01 d0             	add    %rdx,%rax
    4fe2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    4fe8:	0f 8f 32 01 00 00    	jg     5120 <fwp_poll_events+0x210>
    4fee:	48 85 c0             	test   %rax,%rax
    4ff1:	74 5d                	je     5050 <fwp_poll_events+0x140>
    4ff3:	89 c1                	mov    %eax,%ecx
    4ff5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    4ffc:	48 c1 e9 26          	shr    $0x26,%rcx
    5000:	48 63 d1             	movslq %ecx,%rdx
    5003:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5009:	29 c8                	sub    %ecx,%eax
    500b:	48 98                	cltq
    500d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5014:	e9 11 01 00 00       	jmp    512a <fwp_poll_events+0x21a>
    5019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5020:	e8 0b ec ff ff       	call   3c30 <fwp_flush>
    5025:	ba 2b 00 00 00       	mov    $0x2b,%edx
    502a:	be 01 00 00 00       	mov    $0x1,%esi
    502f:	48 8b 0d 0a e0 00 00 	mov    0xe00a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5036:	48 8d 3d 0b a7 00 00 	lea    0xa70b(%rip),%rdi        # f748 <_IO_stdin_used+0x748>
    503d:	e8 fe e5 ff ff       	call   3640 <fwrite@plt>
    5042:	bf 65 00 00 00       	mov    $0x65,%edi
    5047:	e8 e4 e5 ff ff       	call   3630 <exit@plt>
    504c:	0f 1f 40 00          	nopl   0x0(%rax)
    5050:	e8 7b f2 ff ff       	call   42d0 <fwp_now_ns>
    5055:	48 89 c1             	mov    %rax,%rcx
    5058:	66 0f ef c0          	pxor   %xmm0,%xmm0
    505c:	eb 44                	jmp    50a2 <fwp_poll_events+0x192>
    505e:	66 90                	xchg   %ax,%ax
    5060:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5064:	75 33                	jne    5099 <fwp_poll_events+0x189>
    5066:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    506a:	75 2d                	jne    5099 <fwp_poll_events+0x189>
    506c:	48 8b 05 8d e6 01 00 	mov    0x1e68d(%rip),%rax        # 23700 <fwp_ready_tail>
    5073:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5077:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    507e:	00 00 00 00 
    5082:	48 85 c0             	test   %rax,%rax
    5085:	0f 84 05 01 00 00    	je     5190 <fwp_poll_events+0x280>
    508b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5092:	48 89 15 67 e6 01 00 	mov    %rdx,0x1e667(%rip)        # 23700 <fwp_ready_tail>
    5099:	48 85 db             	test   %rbx,%rbx
    509c:	0f 84 be 00 00 00    	je     5160 <fwp_poll_events+0x250>
    50a2:	48 89 da             	mov    %rbx,%rdx
    50a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50b0:	7f e7                	jg     5099 <fwp_poll_events+0x189>
    50b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50b6:	74 2e                	je     50e6 <fwp_poll_events+0x1d6>
    50b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50bf:	48 85 c0             	test   %rax,%rax
    50c2:	0f 84 b8 00 00 00    	je     5180 <fwp_poll_events+0x270>
    50c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    50cf:	48 85 db             	test   %rbx,%rbx
    50d2:	74 07                	je     50db <fwp_poll_events+0x1cb>
    50d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    50db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    50df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    50e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    50ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    50ee:	48 85 c0             	test   %rax,%rax
    50f1:	0f 84 69 ff ff ff    	je     5060 <fwp_poll_events+0x150>
    50f7:	48 39 c8             	cmp    %rcx,%rax
    50fa:	0f 8f 60 ff ff ff    	jg     5060 <fwp_poll_events+0x150>
    5100:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5104:	0f 85 56 ff ff ff    	jne    5060 <fwp_poll_events+0x150>
    510a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510e:	75 89                	jne    5099 <fwp_poll_events+0x189>
    5110:	48 89 d7             	mov    %rdx,%rdi
    5113:	e8 58 ef ff ff       	call   4070 <fwp_cancel_tree.part.0>
    5118:	e9 43 ff ff ff       	jmp    5060 <fwp_poll_events+0x150>
    511d:	0f 1f 00             	nopl   (%rax)
    5120:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5125:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    512a:	48 89 e7             	mov    %rsp,%rdi
    512d:	31 f6                	xor    %esi,%esi
    512f:	48 89 14 24          	mov    %rdx,(%rsp)
    5133:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5138:	e8 43 e3 ff ff       	call   3480 <nanosleep@plt>
    513d:	48 8b 1d b4 e5 01 00 	mov    0x1e5b4(%rip),%rbx        # 236f8 <fwp_timers>
    5144:	e8 87 f1 ff ff       	call   42d0 <fwp_now_ns>
    5149:	48 89 c1             	mov    %rax,%rcx
    514c:	48 85 db             	test   %rbx,%rbx
    514f:	0f 85 03 ff ff ff    	jne    5058 <fwp_poll_events+0x148>
    5155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    515c:	00 00 00 00 
    5160:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5165:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    516c:	00 00 
    516e:	75 2c                	jne    519c <fwp_poll_events+0x28c>
    5170:	48 83 c4 20          	add    $0x20,%rsp
    5174:	5b                   	pop    %rbx
    5175:	c3                   	ret
    5176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    517d:	00 00 00 
    5180:	48 89 1d 71 e5 01 00 	mov    %rbx,0x1e571(%rip)        # 236f8 <fwp_timers>
    5187:	e9 43 ff ff ff       	jmp    50cf <fwp_poll_events+0x1bf>
    518c:	0f 1f 40 00          	nopl   0x0(%rax)
    5190:	48 89 15 71 e5 01 00 	mov    %rdx,0x1e571(%rip)        # 23708 <fwp_ready_head>
    5197:	e9 f6 fe ff ff       	jmp    5092 <fwp_poll_events+0x182>
    519c:	e8 9f e2 ff ff       	call   3440 <__stack_chk_fail@plt>
    51a1:	0f 1f 40 00          	nopl   0x0(%rax)
    51a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ac:	00 00 00 00 

00000000000051b0 <fwp_rc_wide_dup>:
    51b0:	48 89 fa             	mov    %rdi,%rdx
    51b3:	48 8d 35 86 e5 01 00 	lea    0x1e586(%rip),%rsi        # 23740 <fwp_heap>
    51ba:	48 83 ec 18          	sub    $0x18,%rsp
    51be:	48 89 f9             	mov    %rdi,%rcx
    51c1:	48 c1 ea 11          	shr    $0x11,%rdx
    51c5:	48 31 fa             	xor    %rdi,%rdx
    51c8:	48 89 d0             	mov    %rdx,%rax
    51cb:	48 c1 e8 09          	shr    $0x9,%rax
    51cf:	48 31 c2             	xor    %rax,%rdx
    51d2:	0f b6 d2             	movzbl %dl,%edx
    51d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    51dc:	00 
    51dd:	49 8b 00             	mov    (%r8),%rax
    51e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    51e7:	00 00 
    51e9:	75 21                	jne    520c <fwp_rc_wide_dup+0x5c>
    51eb:	e9 98 00 00 00       	jmp    5288 <fwp_rc_wide_dup+0xd8>
    51f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 2f                	je     5238 <fwp_rc_wide_dup+0x88>
    5209:	48 89 d0             	mov    %rdx,%rax
    520c:	48 3b 08             	cmp    (%rax),%rcx
    520f:	75 ef                	jne    5200 <fwp_rc_wide_dup+0x50>
    5211:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5214:	74 7c                	je     5292 <fwp_rc_wide_dup+0xe2>
    5216:	48 8b 50 08          	mov    0x8(%rax),%rdx
    521a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    521e:	0f 84 91 00 00 00    	je     52b5 <fwp_rc_wide_dup+0x105>
    5224:	48 83 c2 01          	add    $0x1,%rdx
    5228:	48 89 50 08          	mov    %rdx,0x8(%rax)
    522c:	48 83 c4 18          	add    $0x18,%rsp
    5230:	c3                   	ret
    5231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5238:	4c 8d 40 10          	lea    0x10(%rax),%r8
    523c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    523f:	75 68                	jne    52a9 <fwp_rc_wide_dup+0xf9>
    5241:	bf 18 00 00 00       	mov    $0x18,%edi
    5246:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    524b:	4c 89 04 24          	mov    %r8,(%rsp)
    524f:	e8 2c e3 ff ff       	call   3580 <malloc@plt>
    5254:	4c 8b 04 24          	mov    (%rsp),%r8
    5258:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    525d:	48 85 c0             	test   %rax,%rax
    5260:	74 5f                	je     52c1 <fwp_rc_wide_dup+0x111>
    5262:	48 89 08             	mov    %rcx,(%rax)
    5265:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    526c:	00 
    526d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5274:	00 
    5275:	49 89 00             	mov    %rax,(%r8)
    5278:	c6 01 ff             	movb   $0xff,(%rcx)
    527b:	48 83 05 05 01 02 00 	addq   $0x1,0x20105(%rip)        # 25388 <fwp_heap+0x1c48>
    5282:	01 
    5283:	48 83 c4 18          	add    $0x18,%rsp
    5287:	c3                   	ret
    5288:	80 3f fe             	cmpb   $0xfe,(%rdi)
    528b:	75 13                	jne    52a0 <fwp_rc_wide_dup+0xf0>
    528d:	48 85 c0             	test   %rax,%rax
    5290:	74 af                	je     5241 <fwp_rc_wide_dup+0x91>
    5292:	48 8d 3d df a4 00 00 	lea    0xa4df(%rip),%rdi        # f778 <_IO_stdin_used+0x778>
    5299:	e8 c2 ee ff ff       	call   4160 <fwp_trap>
    529e:	66 90                	xchg   %ax,%ax
    52a0:	48 85 c0             	test   %rax,%rax
    52a3:	0f 85 6d ff ff ff    	jne    5216 <fwp_rc_wide_dup+0x66>
    52a9:	48 8d 3d f0 a4 00 00 	lea    0xa4f0(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    52b0:	e8 ab ee ff ff       	call   4160 <fwp_trap>
    52b5:	48 8d 3d 14 9e 00 00 	lea    0x9e14(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52bc:	e8 9f ee ff ff       	call   4160 <fwp_trap>
    52c1:	e8 aa e9 ff ff       	call   3c70 <fwp_heap_oom>
    52c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    52cd:	00 00 00 

00000000000052d0 <fwp_rc_forget_slot>:
    52d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    52d3:	74 0b                	je     52e0 <fwp_rc_forget_slot+0x10>
    52d5:	c3                   	ret
    52d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    52dd:	00 00 00 
    52e0:	48 89 f8             	mov    %rdi,%rax
    52e3:	48 83 ec 08          	sub    $0x8,%rsp
    52e7:	48 89 fa             	mov    %rdi,%rdx
    52ea:	48 c1 e8 11          	shr    $0x11,%rax
    52ee:	48 31 f8             	xor    %rdi,%rax
    52f1:	48 89 c1             	mov    %rax,%rcx
    52f4:	48 c1 e9 09          	shr    $0x9,%rcx
    52f8:	48 31 c8             	xor    %rcx,%rax
    52fb:	48 8d 0d 3e e4 01 00 	lea    0x1e43e(%rip),%rcx        # 23740 <fwp_heap>
    5302:	0f b6 c0             	movzbl %al,%eax
    5305:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    530c:	00 
    530d:	48 85 ff             	test   %rdi,%rdi
    5310:	74 3c                	je     534e <fwp_rc_forget_slot+0x7e>
    5312:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5319:	00 
    531a:	48 8b 01             	mov    (%rcx),%rax
    531d:	eb 11                	jmp    5330 <fwp_rc_forget_slot+0x60>
    531f:	90                   	nop
    5320:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5324:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5328:	48 85 ff             	test   %rdi,%rdi
    532b:	74 21                	je     534e <fwp_rc_forget_slot+0x7e>
    532d:	48 89 f8             	mov    %rdi,%rax
    5330:	48 3b 10             	cmp    (%rax),%rdx
    5333:	75 eb                	jne    5320 <fwp_rc_forget_slot+0x50>
    5335:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5339:	48 89 01             	mov    %rax,(%rcx)
    533c:	e8 5f e0 ff ff       	call   33a0 <free@plt>
    5341:	48 83 2d 3f 00 02 00 	subq   $0x1,0x2003f(%rip)        # 25388 <fwp_heap+0x1c48>
    5348:	01 
    5349:	48 83 c4 08          	add    $0x8,%rsp
    534d:	c3                   	ret
    534e:	48 8d 3d 4b a4 00 00 	lea    0xa44b(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    5355:	e8 06 ee ff ff       	call   4160 <fwp_trap>
    535a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005360 <fwp_rc_prepare_chunk>:
    5360:	48 83 3d 20 00 02 00 	cmpq   $0x0,0x20020(%rip)        # 25388 <fwp_heap+0x1c48>
    5367:	00 
    5368:	41 54                	push   %r12
    536a:	49 89 f4             	mov    %rsi,%r12
    536d:	55                   	push   %rbp
    536e:	48 89 fd             	mov    %rdi,%rbp
    5371:	53                   	push   %rbx
    5372:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5375:	0f 84 7d 00 00 00    	je     53f8 <fwp_rc_prepare_chunk+0x98>
    537b:	31 db                	xor    %ebx,%ebx
    537d:	85 c0                	test   %eax,%eax
    537f:	75 5f                	jne    53e0 <fwp_rc_prepare_chunk+0x80>
    5381:	48 85 f6             	test   %rsi,%rsi
    5384:	74 7c                	je     5402 <fwp_rc_prepare_chunk+0xa2>
    5386:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    538a:	e8 11 e0 ff ff       	call   33a0 <free@plt>
    538f:	90                   	nop
    5390:	be 01 00 00 00       	mov    $0x1,%esi
    5395:	4c 89 e7             	mov    %r12,%rdi
    5398:	e8 63 e1 ff ff       	call   3500 <calloc@plt>
    539d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53a1:	48 85 c0             	test   %rax,%rax
    53a4:	0f 85 87 00 00 00    	jne    5431 <fwp_rc_prepare_chunk+0xd1>
    53aa:	e8 c1 e8 ff ff       	call   3c70 <fwp_heap_oom>
    53af:	90                   	nop
    53b0:	e8 1b ff ff ff       	call   52d0 <fwp_rc_forget_slot>
    53b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53b8:	48 83 c3 01          	add    $0x1,%rbx
    53bc:	48 39 c3             	cmp    %rax,%rbx
    53bf:	73 37                	jae    53f8 <fwp_rc_prepare_chunk+0x98>
    53c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53c8:	00 00 
    53ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53d1:	00 00 00 00 
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    53e4:	48 01 df             	add    %rbx,%rdi
    53e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    53ea:	74 c4                	je     53b0 <fwp_rc_prepare_chunk+0x50>
    53ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53ef:	48 83 c3 01          	add    $0x1,%rbx
    53f3:	48 39 c3             	cmp    %rax,%rbx
    53f6:	72 e8                	jb     53e0 <fwp_rc_prepare_chunk+0x80>
    53f8:	49 39 c4             	cmp    %rax,%r12
    53fb:	75 13                	jne    5410 <fwp_rc_prepare_chunk+0xb0>
    53fd:	4d 85 e4             	test   %r12,%r12
    5400:	75 46                	jne    5448 <fwp_rc_prepare_chunk+0xe8>
    5402:	5b                   	pop    %rbx
    5403:	5d                   	pop    %rbp
    5404:	41 5c                	pop    %r12
    5406:	c3                   	ret
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 
    5410:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5414:	48 29 05 75 ff 01 00 	sub    %rax,0x1ff75(%rip)        # 25390 <fwp_heap+0x1c50>
    541b:	e8 80 df ff ff       	call   33a0 <free@plt>
    5420:	4d 85 e4             	test   %r12,%r12
    5423:	0f 85 67 ff ff ff    	jne    5390 <fwp_rc_prepare_chunk+0x30>
    5429:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5430:	00 
    5431:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5435:	5b                   	pop    %rbx
    5436:	4c 01 25 53 ff 01 00 	add    %r12,0x1ff53(%rip)        # 25390 <fwp_heap+0x1c50>
    543d:	5d                   	pop    %rbp
    543e:	41 5c                	pop    %r12
    5440:	c3                   	ret
    5441:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5448:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    544c:	5b                   	pop    %rbx
    544d:	4c 89 e2             	mov    %r12,%rdx
    5450:	31 f6                	xor    %esi,%esi
    5452:	5d                   	pop    %rbp
    5453:	41 5c                	pop    %r12
    5455:	e9 46 e0 ff ff       	jmp    34a0 <memset@plt>
    545a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005460 <fwp_heap_refill>:
    5460:	41 56                	push   %r14
    5462:	41 89 d6             	mov    %edx,%r14d
    5465:	41 55                	push   %r13
    5467:	41 89 f5             	mov    %esi,%r13d
    546a:	41 54                	push   %r12
    546c:	49 89 fc             	mov    %rdi,%r12
    546f:	bf 01 00 00 00       	mov    $0x1,%edi
    5474:	55                   	push   %rbp
    5475:	53                   	push   %rbx
    5476:	e8 25 e9 ff ff       	call   3da0 <fwp_heap_chunks>
    547b:	48 89 c3             	mov    %rax,%rbx
    547e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5482:	48 8b 05 af f6 01 00 	mov    0x1f6af(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    5489:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    548d:	48 8d 05 ac e2 01 00 	lea    0x1e2ac(%rip),%rax        # 23740 <fwp_heap>
    5494:	31 d2                	xor    %edx,%edx
    5496:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    549a:	48 89 ef             	mov    %rbp,%rdi
    549d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ac:	00 
    54ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    54b2:	f7 f1                	div    %ecx
    54b4:	31 d2                	xor    %edx,%edx
    54b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54ba:	66 0f 6e c8          	movd   %eax,%xmm1
    54be:	89 c6                	mov    %eax,%esi
    54c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    54c5:	48 01 c8             	add    %rcx,%rax
    54c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    54cc:	48 f7 f1             	div    %rcx
    54cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    54d4:	89 45 18             	mov    %eax,0x18(%rbp)
    54d7:	e8 84 fe ff ff       	call   5360 <fwp_rc_prepare_chunk>
    54dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    54df:	48 89 d8             	mov    %rbx,%rax
    54e2:	48 c1 e0 10          	shl    $0x10,%rax
    54e6:	48 03 05 03 f6 01 00 	add    0x1f603(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    54ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    54f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    54f6:	8b 55 08             	mov    0x8(%rbp),%edx
    54f9:	48 0f af d1          	imul   %rcx,%rdx
    54fd:	48 01 c2             	add    %rax,%rdx
    5500:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5505:	5b                   	pop    %rbx
    5506:	5d                   	pop    %rbp
    5507:	41 5c                	pop    %r12
    5509:	41 5d                	pop    %r13
    550b:	41 5e                	pop    %r14
    550d:	c3                   	ret
    550e:	66 90                	xchg   %ax,%ax

0000000000005510 <fwp_mem_free>:
    5510:	48 85 ff             	test   %rdi,%rdi
    5513:	0f 84 17 02 00 00    	je     5730 <fwp_mem_free+0x220>
    5519:	48 8b 35 d0 f5 01 00 	mov    0x1f5d0(%rip),%rsi        # 24af0 <fwp_heap+0x13b0>
    5520:	48 8b 05 f1 f5 01 00 	mov    0x1f5f1(%rip),%rax        # 24b18 <fwp_heap+0x13d8>
    5527:	48 89 fa             	mov    %rdi,%rdx
    552a:	48 29 f2             	sub    %rsi,%rdx
    552d:	48 c1 e0 10          	shl    $0x10,%rax
    5531:	48 39 c2             	cmp    %rax,%rdx
    5534:	0f 83 f6 01 00 00    	jae    5730 <fwp_mem_free+0x220>
    553a:	49 89 d1             	mov    %rdx,%r9
    553d:	49 c1 e9 10          	shr    $0x10,%r9
    5541:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5545:	48 c1 e0 03          	shl    $0x3,%rax
    5549:	49 89 c0             	mov    %rax,%r8
    554c:	4c 03 05 e5 f5 01 00 	add    0x1f5e5(%rip),%r8        # 24b38 <fwp_heap+0x13f8>
    5553:	0f 84 d7 01 00 00    	je     5730 <fwp_mem_free+0x220>
    5559:	48 83 ec 38          	sub    $0x38,%rsp
    555d:	48 89 f9             	mov    %rdi,%rcx
    5560:	41 0f b6 38          	movzbl (%r8),%edi
    5564:	40 80 ff 01          	cmp    $0x1,%dil
    5568:	74 16                	je     5580 <fwp_mem_free+0x70>
    556a:	40 80 ff 02          	cmp    $0x2,%dil
    556e:	0f 84 94 00 00 00    	je     5608 <fwp_mem_free+0xf8>
    5574:	48 83 c4 38          	add    $0x38,%rsp
    5578:	c3                   	ret
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5584:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5589:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    558e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5592:	4d 85 d2             	test   %r10,%r10
    5595:	74 1d                	je     55b4 <fwp_mem_free+0xa4>
    5597:	0f b7 c1             	movzwl %cx,%eax
    559a:	31 d2                	xor    %edx,%edx
    559c:	48 f7 f7             	div    %rdi
    559f:	49 01 c2             	add    %rax,%r10
    55a2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55a6:	0f 84 44 01 00 00    	je     56f0 <fwp_mem_free+0x1e0>
    55ac:	41 c6 02 00          	movb   $0x0,(%r10)
    55b0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55b4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55bb:	49 63 c1             	movslq %r9d,%rax
    55be:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55c2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    55c6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    55cb:	f2 0f 58 05 ad f5 01 	addsd  0x1f5ad(%rip),%xmm0        # 24b80 <fwp_heap+0x1440>
    55d2:	00 
    55d3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    55d7:	48 8d 05 62 e1 01 00 	lea    0x1e162(%rip),%rax        # 23740 <fwp_heap>
    55de:	48 01 d0             	add    %rdx,%rax
    55e1:	48 8b 10             	mov    (%rax),%rdx
    55e4:	48 f7 d2             	not    %rdx
    55e7:	48 89 11             	mov    %rdx,(%rcx)
    55ea:	48 89 08             	mov    %rcx,(%rax)
    55ed:	48 29 3d 6c f5 01 00 	sub    %rdi,0x1f56c(%rip)        # 24b60 <fwp_heap+0x1420>
    55f4:	f2 0f 11 05 84 f5 01 	movsd  %xmm0,0x1f584(%rip)        # 24b80 <fwp_heap+0x1440>
    55fb:	00 
    55fc:	48 83 c4 38          	add    $0x38,%rsp
    5600:	c3                   	ret
    5601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5608:	66 31 d2             	xor    %dx,%dx
    560b:	48 01 d6             	add    %rdx,%rsi
    560e:	48 39 f1             	cmp    %rsi,%rcx
    5611:	0f 85 5d ff ff ff    	jne    5574 <fwp_mem_free+0x64>
    5617:	49 8b 50 10          	mov    0x10(%r8),%rdx
    561b:	48 29 15 3e f5 01 00 	sub    %rdx,0x1f53e(%rip)        # 24b60 <fwp_heap+0x1420>
    5622:	48 85 d2             	test   %rdx,%rdx
    5625:	0f 88 a5 00 00 00    	js     56d0 <fwp_mem_free+0x1c0>
    562b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    562f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5634:	f2 0f 58 05 44 f5 01 	addsd  0x1f544(%rip),%xmm0        # 24b80 <fwp_heap+0x1440>
    563b:	00 
    563c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5640:	f2 0f 11 05 38 f5 01 	movsd  %xmm0,0x1f538(%rip)        # 24b80 <fwp_heap+0x1440>
    5647:	00 
    5648:	48 85 d2             	test   %rdx,%rdx
    564b:	74 0c                	je     5659 <fwp_mem_free+0x149>
    564d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5650:	0f 84 db 00 00 00    	je     5731 <fwp_mem_free+0x221>
    5656:	c6 02 00             	movb   $0x0,(%rdx)
    5659:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    565d:	48 85 c9             	test   %rcx,%rcx
    5660:	74 3e                	je     56a0 <fwp_mem_free+0x190>
    5662:	48 8b 15 cf f4 01 00 	mov    0x1f4cf(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    5669:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    566d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5671:	48 01 d0             	add    %rdx,%rax
    5674:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5678:	48 89 d6             	mov    %rdx,%rsi
    567b:	48 29 c6             	sub    %rax,%rsi
    567e:	83 e6 08             	and    $0x8,%esi
    5681:	74 0d                	je     5690 <fwp_mem_free+0x180>
    5683:	c6 00 00             	movb   $0x0,(%rax)
    5686:	48 83 c0 28          	add    $0x28,%rax
    568a:	48 39 c2             	cmp    %rax,%rdx
    568d:	74 11                	je     56a0 <fwp_mem_free+0x190>
    568f:	90                   	nop
    5690:	c6 00 00             	movb   $0x0,(%rax)
    5693:	48 83 c0 50          	add    $0x50,%rax
    5697:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    569b:	48 39 c2             	cmp    %rax,%rdx
    569e:	75 f0                	jne    5690 <fwp_mem_free+0x180>
    56a0:	48 01 0d c9 f4 01 00 	add    %rcx,0x1f4c9(%rip)        # 24b70 <fwp_heap+0x1430>
    56a7:	4c 3b 0d 82 f4 01 00 	cmp    0x1f482(%rip),%r9        # 24b30 <fwp_heap+0x13f0>
    56ae:	73 07                	jae    56b7 <fwp_mem_free+0x1a7>
    56b0:	4c 89 0d 79 f4 01 00 	mov    %r9,0x1f479(%rip)        # 24b30 <fwp_heap+0x13f0>
    56b7:	4c 3b 0d 6a f4 01 00 	cmp    0x1f46a(%rip),%r9        # 24b28 <fwp_heap+0x13e8>
    56be:	0f 83 b0 fe ff ff    	jae    5574 <fwp_mem_free+0x64>
    56c4:	4c 89 0d 5d f4 01 00 	mov    %r9,0x1f45d(%rip)        # 24b28 <fwp_heap+0x13e8>
    56cb:	e9 a4 fe ff ff       	jmp    5574 <fwp_mem_free+0x64>
    56d0:	48 89 d1             	mov    %rdx,%rcx
    56d3:	83 e2 01             	and    $0x1,%edx
    56d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56da:	48 d1 e9             	shr    $1,%rcx
    56dd:	48 09 d1             	or     %rdx,%rcx
    56e0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    56e5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    56e9:	e9 46 ff ff ff       	jmp    5634 <fwp_mem_free+0x124>
    56ee:	66 90                	xchg   %ax,%ax
    56f0:	4c 89 d7             	mov    %r10,%rdi
    56f3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    56f8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    56fd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5702:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5706:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    570b:	e8 c0 fb ff ff       	call   52d0 <fwp_rc_forget_slot>
    5710:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5715:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    571a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    571f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5724:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5729:	e9 7e fe ff ff       	jmp    55ac <fwp_mem_free+0x9c>
    572e:	66 90                	xchg   %ax,%ax
    5730:	c3                   	ret
    5731:	48 89 d7             	mov    %rdx,%rdi
    5734:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5739:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    573e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5743:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5748:	e8 83 fb ff ff       	call   52d0 <fwp_rc_forget_slot>
    574d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5752:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5757:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    575c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5761:	e9 f0 fe ff ff       	jmp    5656 <fwp_mem_free+0x146>
    5766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    576d:	00 00 00 

0000000000005770 <fwp_heap_alloc_big>:
    5770:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5777:	00 00 40 
    577a:	41 57                	push   %r15
    577c:	41 56                	push   %r14
    577e:	41 55                	push   %r13
    5780:	41 54                	push   %r12
    5782:	55                   	push   %rbp
    5783:	53                   	push   %rbx
    5784:	48 83 ec 08          	sub    $0x8,%rsp
    5788:	48 39 f8             	cmp    %rdi,%rax
    578b:	0f 82 fa 00 00 00    	jb     588b <fwp_heap_alloc_big+0x11b>
    5791:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5798:	49 89 fd             	mov    %rdi,%r13
    579b:	41 89 f6             	mov    %esi,%r14d
    579e:	48 c1 ed 10          	shr    $0x10,%rbp
    57a2:	48 89 ef             	mov    %rbp,%rdi
    57a5:	e8 f6 e5 ff ff       	call   3da0 <fwp_heap_chunks>
    57aa:	be 01 00 00 00       	mov    $0x1,%esi
    57af:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57b3:	49 89 c4             	mov    %rax,%r12
    57b6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57bd:	00 
    57be:	48 03 3d 73 f3 01 00 	add    0x1f373(%rip),%rdi        # 24b38 <fwp_heap+0x13f8>
    57c5:	c6 07 02             	movb   $0x2,(%rdi)
    57c8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    57cc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    57cf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    57d3:	e8 88 fb ff ff       	call   5360 <fwp_rc_prepare_chunk>
    57d8:	48 83 fd 01          	cmp    $0x1,%rbp
    57dc:	76 47                	jbe    5825 <fwp_heap_alloc_big+0xb5>
    57de:	4c 01 e5             	add    %r12,%rbp
    57e1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    57e8:	00 
    57e9:	4c 8d 3d 50 df 01 00 	lea    0x1df50(%rip),%r15        # 23740 <fwp_heap>
    57f0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    57f5:	49 c1 e6 03          	shl    $0x3,%r14
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5807:	31 f6                	xor    %esi,%esi
    5809:	48 01 dd             	add    %rbx,%rbp
    580c:	48 83 c3 28          	add    $0x28,%rbx
    5810:	48 89 ef             	mov    %rbp,%rdi
    5813:	e8 48 fb ff ff       	call   5360 <fwp_rc_prepare_chunk>
    5818:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    581c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5820:	49 39 de             	cmp    %rbx,%r14
    5823:	75 db                	jne    5800 <fwp_heap_alloc_big+0x90>
    5825:	49 c1 e4 10          	shl    $0x10,%r12
    5829:	4c 03 25 c0 f2 01 00 	add    0x1f2c0(%rip),%r12        # 24af0 <fwp_heap+0x13b0>
    5830:	4c 89 ea             	mov    %r13,%rdx
    5833:	31 f6                	xor    %esi,%esi
    5835:	4c 89 e7             	mov    %r12,%rdi
    5838:	e8 63 dc ff ff       	call   34a0 <memset@plt>
    583d:	4c 89 e8             	mov    %r13,%rax
    5840:	48 03 05 19 f3 01 00 	add    0x1f319(%rip),%rax        # 24b60 <fwp_heap+0x1420>
    5847:	72 42                	jb     588b <fwp_heap_alloc_big+0x11b>
    5849:	48 39 05 18 f3 01 00 	cmp    %rax,0x1f318(%rip)        # 24b68 <fwp_heap+0x1428>
    5850:	48 89 05 09 f3 01 00 	mov    %rax,0x1f309(%rip)        # 24b60 <fwp_heap+0x1420>
    5857:	73 07                	jae    5860 <fwp_heap_alloc_big+0xf0>
    5859:	48 89 05 08 f3 01 00 	mov    %rax,0x1f308(%rip)        # 24b68 <fwp_heap+0x1428>
    5860:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5864:	4c 89 e0             	mov    %r12,%rax
    5867:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    586c:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24b78 <fwp_heap+0x1438>
    5873:	00 
    5874:	f2 0f 11 05 fc f2 01 	movsd  %xmm0,0x1f2fc(%rip)        # 24b78 <fwp_heap+0x1438>
    587b:	00 
    587c:	48 83 c4 08          	add    $0x8,%rsp
    5880:	5b                   	pop    %rbx
    5881:	5d                   	pop    %rbp
    5882:	41 5c                	pop    %r12
    5884:	41 5d                	pop    %r13
    5886:	41 5e                	pop    %r14
    5888:	41 5f                	pop    %r15
    588a:	c3                   	ret
    588b:	e8 e0 e3 ff ff       	call   3c70 <fwp_heap_oom>

0000000000005890 <fwp_heap_alloc_slow>:
    5890:	53                   	push   %rbx
    5891:	48 89 f9             	mov    %rdi,%rcx
    5894:	41 89 f1             	mov    %esi,%r9d
    5897:	48 83 ec 10          	sub    $0x10,%rsp
    589b:	8b 05 43 f2 01 00    	mov    0x1f243(%rip),%eax        # 24ae4 <fwp_heap+0x13a4>
    58a1:	85 c0                	test   %eax,%eax
    58a3:	0f 84 c7 00 00 00    	je     5970 <fwp_heap_alloc_slow+0xe0>
    58a9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58b0:	0f 87 dd 00 00 00    	ja     5993 <fwp_heap_alloc_slow+0x103>
    58b6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58ba:	48 8d 3d 7f de 01 00 	lea    0x1de7f(%rip),%rdi        # 23740 <fwp_heap>
    58c1:	49 63 f1             	movslq %r9d,%rsi
    58c4:	48 c1 e8 04          	shr    $0x4,%rax
    58c8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    58cf:	00 00 
    58d1:	41 0f b6 c2          	movzbl %r10b,%eax
    58d5:	4c 89 d2             	mov    %r10,%rdx
    58d8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    58dc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    58e3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    58ea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    58ee:	48 01 f8             	add    %rdi,%rax
    58f1:	4c 8b 00             	mov    (%rax),%r8
    58f4:	4d 85 c0             	test   %r8,%r8
    58f7:	0f 84 ab 00 00 00    	je     59a8 <fwp_heap_alloc_slow+0x118>
    58fd:	49 8b 10             	mov    (%r8),%rdx
    5900:	48 f7 d2             	not    %rdx
    5903:	48 89 10             	mov    %rdx,(%rax)
    5906:	41 83 f9 01          	cmp    $0x1,%r9d
    590a:	4c 89 c7             	mov    %r8,%rdi
    590d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5911:	31 f6                	xor    %esi,%esi
    5913:	48 89 ca             	mov    %rcx,%rdx
    5916:	e8 85 db ff ff       	call   34a0 <memset@plt>
    591b:	49 89 c0             	mov    %rax,%r8
    591e:	48 89 d8             	mov    %rbx,%rax
    5921:	48 03 05 38 f2 01 00 	add    0x1f238(%rip),%rax        # 24b60 <fwp_heap+0x1420>
    5928:	0f 82 d9 00 00 00    	jb     5a07 <fwp_heap_alloc_slow+0x177>
    592e:	48 39 05 33 f2 01 00 	cmp    %rax,0x1f233(%rip)        # 24b68 <fwp_heap+0x1428>
    5935:	48 89 05 24 f2 01 00 	mov    %rax,0x1f224(%rip)        # 24b60 <fwp_heap+0x1420>
    593c:	73 07                	jae    5945 <fwp_heap_alloc_slow+0xb5>
    593e:	48 89 05 23 f2 01 00 	mov    %rax,0x1f223(%rip)        # 24b68 <fwp_heap+0x1428>
    5945:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5949:	4c 89 c0             	mov    %r8,%rax
    594c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5951:	f2 0f 58 05 1f f2 01 	addsd  0x1f21f(%rip),%xmm0        # 24b78 <fwp_heap+0x1438>
    5958:	00 
    5959:	f2 0f 11 05 17 f2 01 	movsd  %xmm0,0x1f217(%rip)        # 24b78 <fwp_heap+0x1438>
    5960:	00 
    5961:	48 83 c4 10          	add    $0x10,%rsp
    5965:	5b                   	pop    %rbx
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5974:	48 89 3c 24          	mov    %rdi,(%rsp)
    5978:	e8 73 f1 ff ff       	call   4af0 <fwp_heap_init>
    597d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5981:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5986:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    598d:	0f 86 23 ff ff ff    	jbe    58b6 <fwp_heap_alloc_slow+0x26>
    5993:	48 83 c4 10          	add    $0x10,%rsp
    5997:	44 89 ce             	mov    %r9d,%esi
    599a:	48 89 cf             	mov    %rcx,%rdi
    599d:	5b                   	pop    %rbx
    599e:	e9 cd fd ff ff       	jmp    5770 <fwp_heap_alloc_big>
    59a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59a8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ac:	4d 85 c0             	test   %r8,%r8
    59af:	74 1f                	je     59d0 <fwp_heap_alloc_slow+0x140>
    59b1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59b5:	4d 29 c3             	sub    %r8,%r11
    59b8:	49 39 db             	cmp    %rbx,%r11
    59bb:	72 13                	jb     59d0 <fwp_heap_alloc_slow+0x140>
    59bd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    59c1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    59c5:	e9 3c ff ff ff       	jmp    5906 <fwp_heap_alloc_slow+0x76>
    59ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    59d0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    59d7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    59db:	44 89 ca             	mov    %r9d,%edx
    59de:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    59e3:	44 89 0c 24          	mov    %r9d,(%rsp)
    59e7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    59eb:	44 89 d6             	mov    %r10d,%esi
    59ee:	48 01 c7             	add    %rax,%rdi
    59f1:	e8 6a fa ff ff       	call   5460 <fwp_heap_refill>
    59f6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    59fb:	44 8b 0c 24          	mov    (%rsp),%r9d
    59ff:	49 89 c0             	mov    %rax,%r8
    5a02:	e9 ff fe ff ff       	jmp    5906 <fwp_heap_alloc_slow+0x76>
    5a07:	e8 64 e2 ff ff       	call   3c70 <fwp_heap_oom>
    5a0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a10 <fwp_heap_alloc>:
    5a10:	8b 05 ce f0 01 00    	mov    0x1f0ce(%rip),%eax        # 24ae4 <fwp_heap+0x13a4>
    5a16:	48 89 fa             	mov    %rdi,%rdx
    5a19:	89 f7                	mov    %esi,%edi
    5a1b:	85 c0                	test   %eax,%eax
    5a1d:	0f 84 f5 00 00 00    	je     5b18 <fwp_heap_alloc+0x108>
    5a23:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a2a:	0f 87 e8 00 00 00    	ja     5b18 <fwp_heap_alloc+0x108>
    5a30:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a34:	48 8d 05 05 dd 01 00 	lea    0x1dd05(%rip),%rax        # 23740 <fwp_heap>
    5a3b:	48 83 ec 18          	sub    $0x18,%rsp
    5a3f:	41 89 f0             	mov    %esi,%r8d
    5a42:	48 c1 e9 04          	shr    $0x4,%rcx
    5a46:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a4d:	00 
    5a4e:	48 63 cf             	movslq %edi,%rcx
    5a51:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a58:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a5f:	00 
    5a60:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5a64:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5a68:	48 01 c8             	add    %rcx,%rax
    5a6b:	48 8b 08             	mov    (%rax),%rcx
    5a6e:	48 85 c9             	test   %rcx,%rcx
    5a71:	74 6d                	je     5ae0 <fwp_heap_alloc+0xd0>
    5a73:	48 8b 31             	mov    (%rcx),%rsi
    5a76:	48 f7 d6             	not    %rsi
    5a79:	48 89 30             	mov    %rsi,(%rax)
    5a7c:	41 83 f8 01          	cmp    $0x1,%r8d
    5a80:	48 89 cf             	mov    %rcx,%rdi
    5a83:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5a88:	49 0f 45 d1          	cmovne %r9,%rdx
    5a8c:	31 f6                	xor    %esi,%esi
    5a8e:	e8 0d da ff ff       	call   34a0 <memset@plt>
    5a93:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5a98:	48 89 c1             	mov    %rax,%rcx
    5a9b:	4c 89 c8             	mov    %r9,%rax
    5a9e:	48 03 05 bb f0 01 00 	add    0x1f0bb(%rip),%rax        # 24b60 <fwp_heap+0x1420>
    5aa5:	72 7b                	jb     5b22 <fwp_heap_alloc+0x112>
    5aa7:	48 39 05 ba f0 01 00 	cmp    %rax,0x1f0ba(%rip)        # 24b68 <fwp_heap+0x1428>
    5aae:	48 89 05 ab f0 01 00 	mov    %rax,0x1f0ab(%rip)        # 24b60 <fwp_heap+0x1420>
    5ab5:	73 07                	jae    5abe <fwp_heap_alloc+0xae>
    5ab7:	48 89 05 aa f0 01 00 	mov    %rax,0x1f0aa(%rip)        # 24b68 <fwp_heap+0x1428>
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 89 c8             	mov    %rcx,%rax
    5ac5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5aca:	f2 0f 58 05 a6 f0 01 	addsd  0x1f0a6(%rip),%xmm0        # 24b78 <fwp_heap+0x1438>
    5ad1:	00 
    5ad2:	f2 0f 11 05 9e f0 01 	movsd  %xmm0,0x1f09e(%rip)        # 24b78 <fwp_heap+0x1438>
    5ad9:	00 
    5ada:	48 83 c4 18          	add    $0x18,%rsp
    5ade:	c3                   	ret
    5adf:	90                   	nop
    5ae0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5ae4:	48 85 c9             	test   %rcx,%rcx
    5ae7:	74 0c                	je     5af5 <fwp_heap_alloc+0xe5>
    5ae9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5aed:	48 29 ce             	sub    %rcx,%rsi
    5af0:	4c 39 ce             	cmp    %r9,%rsi
    5af3:	73 13                	jae    5b08 <fwp_heap_alloc+0xf8>
    5af5:	89 fe                	mov    %edi,%esi
    5af7:	48 83 c4 18          	add    $0x18,%rsp
    5afb:	48 89 d7             	mov    %rdx,%rdi
    5afe:	e9 8d fd ff ff       	jmp    5890 <fwp_heap_alloc_slow>
    5b03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b08:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b0c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b10:	e9 67 ff ff ff       	jmp    5a7c <fwp_heap_alloc+0x6c>
    5b15:	0f 1f 00             	nopl   (%rax)
    5b18:	89 fe                	mov    %edi,%esi
    5b1a:	48 89 d7             	mov    %rdx,%rdi
    5b1d:	e9 6e fd ff ff       	jmp    5890 <fwp_heap_alloc_slow>
    5b22:	e8 49 e1 ff ff       	call   3c70 <fwp_heap_oom>
    5b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b2e:	00 00 

0000000000005b30 <fwp_data.part.0.constprop.0>:
    5b30:	41 56                	push   %r14
    5b32:	41 89 fe             	mov    %edi,%r14d
    5b35:	41 54                	push   %r12
    5b37:	49 89 f4             	mov    %rsi,%r12
    5b3a:	55                   	push   %rbp
    5b3b:	53                   	push   %rbx
    5b3c:	48 83 ec 08          	sub    $0x8,%rsp
    5b40:	8b 05 9e ef 01 00    	mov    0x1ef9e(%rip),%eax        # 24ae4 <fwp_heap+0x13a4>
    5b46:	85 c0                	test   %eax,%eax
    5b48:	0f 84 fa 00 00 00    	je     5c48 <fwp_data.part.0.constprop.0+0x118>
    5b4e:	0f b6 05 8d eb 01 00 	movzbl 0x1eb8d(%rip),%eax        # 246e2 <fwp_heap+0xfa2>
    5b55:	48 8d 15 e4 db 01 00 	lea    0x1dbe4(%rip),%rdx        # 23740 <fwp_heap>
    5b5c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5b63:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b67:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5b6b:	48 8b 18             	mov    (%rax),%rbx
    5b6e:	48 85 db             	test   %rbx,%rbx
    5b71:	0f 84 a9 00 00 00    	je     5c20 <fwp_data.part.0.constprop.0+0xf0>
    5b77:	48 8b 13             	mov    (%rbx),%rdx
    5b7a:	48 f7 d2             	not    %rdx
    5b7d:	48 89 10             	mov    %rdx,(%rax)
    5b80:	48 83 fd 18          	cmp    $0x18,%rbp
    5b84:	76 1b                	jbe    5ba1 <fwp_data.part.0.constprop.0+0x71>
    5b86:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5b8a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5b8e:	31 f6                	xor    %esi,%esi
    5b90:	48 c1 e8 03          	shr    $0x3,%rax
    5b94:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5b9b:	00 
    5b9c:	e8 ff d8 ff ff       	call   34a0 <memset@plt>
    5ba1:	48 89 e8             	mov    %rbp,%rax
    5ba4:	48 03 05 b5 ef 01 00 	add    0x1efb5(%rip),%rax        # 24b60 <fwp_heap+0x1420>
    5bab:	0f 82 a8 00 00 00    	jb     5c59 <fwp_data.part.0.constprop.0+0x129>
    5bb1:	48 39 05 b0 ef 01 00 	cmp    %rax,0x1efb0(%rip)        # 24b68 <fwp_heap+0x1428>
    5bb8:	48 89 05 a1 ef 01 00 	mov    %rax,0x1efa1(%rip)        # 24b60 <fwp_heap+0x1420>
    5bbf:	73 07                	jae    5bc8 <fwp_data.part.0.constprop.0+0x98>
    5bc1:	48 89 05 a0 ef 01 00 	mov    %rax,0x1efa0(%rip)        # 24b68 <fwp_heap+0x1428>
    5bc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bcc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5bd1:	f2 0f 58 05 9f ef 01 	addsd  0x1ef9f(%rip),%xmm0        # 24b78 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 97 ef 01 	movsd  %xmm0,0x1ef97(%rip)        # 24b78 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	b8 02 00 00 00       	mov    $0x2,%eax
    5be6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5beb:	66 0f 6e c8          	movd   %eax,%xmm1
    5bef:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5bf3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5bf7:	49 8b 04 24          	mov    (%r12),%rax
    5bfb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5bff:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c04:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c08:	48 83 c4 08          	add    $0x8,%rsp
    5c0c:	48 89 d8             	mov    %rbx,%rax
    5c0f:	5b                   	pop    %rbx
    5c10:	5d                   	pop    %rbp
    5c11:	41 5c                	pop    %r12
    5c13:	41 5e                	pop    %r14
    5c15:	c3                   	ret
    5c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c1d:	00 00 00 
    5c20:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c24:	48 85 db             	test   %rbx,%rbx
    5c27:	74 1f                	je     5c48 <fwp_data.part.0.constprop.0+0x118>
    5c29:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c2d:	48 29 da             	sub    %rbx,%rdx
    5c30:	48 39 ea             	cmp    %rbp,%rdx
    5c33:	72 13                	jb     5c48 <fwp_data.part.0.constprop.0+0x118>
    5c35:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c3d:	e9 3e ff ff ff       	jmp    5b80 <fwp_data.part.0.constprop.0+0x50>
    5c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c48:	31 f6                	xor    %esi,%esi
    5c4a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c4f:	e8 bc fd ff ff       	call   5a10 <fwp_heap_alloc>
    5c54:	48 89 c3             	mov    %rax,%rbx
    5c57:	eb 88                	jmp    5be1 <fwp_data.part.0.constprop.0+0xb1>
    5c59:	e8 12 e0 ff ff       	call   3c70 <fwp_heap_oom>
    5c5e:	66 90                	xchg   %ax,%ax

0000000000005c60 <fwp_tape_grow.constprop.0>:
    5c60:	41 56                	push   %r14
    5c62:	b8 40 00 00 00       	mov    $0x40,%eax
    5c67:	41 55                	push   %r13
    5c69:	41 54                	push   %r12
    5c6b:	55                   	push   %rbp
    5c6c:	48 89 fd             	mov    %rdi,%rbp
    5c6f:	53                   	push   %rbx
    5c70:	48 83 ec 10          	sub    $0x10,%rsp
    5c74:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5c78:	48 85 db             	test   %rbx,%rbx
    5c7b:	48 0f 44 d8          	cmove  %rax,%rbx
    5c7f:	48 39 de             	cmp    %rbx,%rsi
    5c82:	7e 12                	jle    5c96 <fwp_tape_grow.constprop.0+0x36>
    5c84:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5c8b:	0f 8e df 00 00 00    	jle    5d70 <fwp_tape_grow.constprop.0+0x110>
    5c91:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5c96:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    5c9a:	4d 85 e4             	test   %r12,%r12
    5c9d:	0f 84 dd 00 00 00    	je     5d80 <fwp_tape_grow.constprop.0+0x120>
    5ca3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5ca7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    5cae:	00 
    5caf:	e8 ec d8 ff ff       	call   35a0 <realloc@plt>
    5cb4:	48 85 c0             	test   %rax,%rax
    5cb7:	0f 84 eb 00 00 00    	je     5da8 <fwp_tape_grow.constprop.0+0x148>
    5cbd:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    5cc2:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5cc6:	48 39 da             	cmp    %rbx,%rdx
    5cc9:	0f 8d 8b 00 00 00    	jge    5d5a <fwp_tape_grow.constprop.0+0xfa>
    5ccf:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    5cd6:	ff ff 07 
    5cd9:	48 39 c3             	cmp    %rax,%rbx
    5cdc:	0f 8f ba 00 00 00    	jg     5d9c <fwp_tape_grow.constprop.0+0x13c>
    5ce2:	48 89 d9             	mov    %rbx,%rcx
    5ce5:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    5cea:	be 02 00 00 00       	mov    $0x2,%esi
    5cef:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5cf4:	48 c1 e1 04          	shl    $0x4,%rcx
    5cf8:	48 89 cf             	mov    %rcx,%rdi
    5cfb:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cff:	e8 0c fd ff ff       	call   5a10 <fwp_heap_alloc>
    5d04:	49 89 c5             	mov    %rax,%r13
    5d07:	4d 85 f6             	test   %r14,%r14
    5d0a:	74 27                	je     5d33 <fwp_tape_grow.constprop.0+0xd3>
    5d0c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d11:	48 8b 0c 24          	mov    (%rsp),%rcx
    5d15:	48 89 c7             	mov    %rax,%rdi
    5d18:	4c 89 f6             	mov    %r14,%rsi
    5d1b:	48 c1 e2 04          	shl    $0x4,%rdx
    5d1f:	48 39 ca             	cmp    %rcx,%rdx
    5d22:	48 0f 47 d1          	cmova  %rcx,%rdx
    5d26:	e8 45 d8 ff ff       	call   3570 <memcpy@plt>
    5d2b:	4c 89 f7             	mov    %r14,%rdi
    5d2e:	e8 dd f7 ff ff       	call   5510 <fwp_mem_free>
    5d33:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    5d38:	48 89 da             	mov    %rbx,%rdx
    5d3b:	31 f6                	xor    %esi,%esi
    5d3d:	48 29 fa             	sub    %rdi,%rdx
    5d40:	48 c1 e7 04          	shl    $0x4,%rdi
    5d44:	48 c1 e2 04          	shl    $0x4,%rdx
    5d48:	4c 01 ef             	add    %r13,%rdi
    5d4b:	e8 50 d7 ff ff       	call   34a0 <memset@plt>
    5d50:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    5d55:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    5d5a:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5d5e:	48 83 c4 10          	add    $0x10,%rsp
    5d62:	5b                   	pop    %rbx
    5d63:	5d                   	pop    %rbp
    5d64:	41 5c                	pop    %r12
    5d66:	41 5d                	pop    %r13
    5d68:	41 5e                	pop    %r14
    5d6a:	c3                   	ret
    5d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d70:	48 01 db             	add    %rbx,%rbx
    5d73:	e9 07 ff ff ff       	jmp    5c7f <fwp_tape_grow.constprop.0+0x1f>
    5d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5d7f:	00 
    5d80:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    5d84:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5d88:	48 c1 e6 03          	shl    $0x3,%rsi
    5d8c:	e8 0f d8 ff ff       	call   35a0 <realloc@plt>
    5d91:	48 85 c0             	test   %rax,%rax
    5d94:	74 12                	je     5da8 <fwp_tape_grow.constprop.0+0x148>
    5d96:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5d9a:	eb be                	jmp    5d5a <fwp_tape_grow.constprop.0+0xfa>
    5d9c:	48 8d 3d 46 93 00 00 	lea    0x9346(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    5da3:	e8 b8 e3 ff ff       	call   4160 <fwp_trap>
    5da8:	48 89 ef             	mov    %rbp,%rdi
    5dab:	e8 10 de ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    5db0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5db4:	e8 e7 d5 ff ff       	call   33a0 <free@plt>
    5db9:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    5dbd:	e8 de d5 ff ff       	call   33a0 <free@plt>
    5dc2:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5dc6:	e8 d5 d5 ff ff       	call   33a0 <free@plt>
    5dcb:	31 c9                	xor    %ecx,%ecx
    5dcd:	31 c0                	xor    %eax,%eax
    5dcf:	31 d2                	xor    %edx,%edx
    5dd1:	89 55 04             	mov    %edx,0x4(%rbp)
    5dd4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dd8:	ba 13 00 00 00       	mov    $0x13,%edx
    5ddd:	be 01 00 00 00       	mov    $0x1,%esi
    5de2:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    5de6:	48 8d 3d 1b 92 00 00 	lea    0x921b(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    5ded:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5df1:	48 8b 0d 48 d2 00 00 	mov    0xd248(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5df8:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5dfc:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    5e00:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    5e04:	e8 37 d8 ff ff       	call   3640 <fwrite@plt>
    5e09:	31 ff                	xor    %edi,%edi
    5e0b:	e8 80 d7 ff ff       	call   3590 <fflush@plt>
    5e10:	bf 66 00 00 00       	mov    $0x66,%edi
    5e15:	e8 46 d8 ff ff       	call   3660 <_Exit@plt>
    5e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005e20 <w123>:
    5e20:	41 56                	push   %r14
    5e22:	55                   	push   %rbp
    5e23:	53                   	push   %rbx
    5e24:	48 83 ec 30          	sub    $0x30,%rsp
    5e28:	48 85 f7             	test   %rsi,%rdi
    5e2b:	0f 88 a7 01 00 00    	js     5fd8 <w123+0x1b8>
    5e31:	48 89 f8             	mov    %rdi,%rax
    5e34:	48 89 fb             	mov    %rdi,%rbx
    5e37:	48 89 f5             	mov    %rsi,%rbp
    5e3a:	48 09 f0             	or     %rsi,%rax
    5e3d:	0f 89 5d 01 00 00    	jns    5fa0 <w123+0x180>
    5e43:	48 85 ff             	test   %rdi,%rdi
    5e46:	0f 88 a4 01 00 00    	js     5ff0 <w123+0x1d0>
    5e4c:	48 89 d9             	mov    %rbx,%rcx
    5e4f:	4c 8b 35 da 9c 00 00 	mov    0x9cda(%rip),%r14        # fb30 <msg.4+0xb0>
    5e56:	48 c1 f9 20          	sar    $0x20,%rcx
    5e5a:	48 39 0a             	cmp    %rcx,(%rdx)
    5e5d:	0f 84 65 01 00 00    	je     5fc8 <w123+0x1a8>
    5e63:	48 89 cf             	mov    %rcx,%rdi
    5e66:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    5e6b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e70:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    5e76:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    5e7c:	e8 bf e5 ff ff       	call   4440 <fwp_tape_of>
    5e81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e86:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    5e8c:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    5e91:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    5e97:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    5e9c:	0f 85 7f 01 00 00    	jne    6021 <w123+0x201>
    5ea2:	48 89 0a             	mov    %rcx,(%rdx)
    5ea5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    5ea9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5ead:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    5eb4:	0f 8f 4f 01 00 00    	jg     6009 <w123+0x1e9>
    5eba:	89 da                	mov    %ebx,%edx
    5ebc:	48 39 d1             	cmp    %rdx,%rcx
    5ebf:	0f 8e 50 01 00 00    	jle    6015 <w123+0x1f5>
    5ec5:	48 85 ed             	test   %rbp,%rbp
    5ec8:	78 0b                	js     5ed5 <w123+0xb5>
    5eca:	89 ea                	mov    %ebp,%edx
    5ecc:	48 39 d1             	cmp    %rdx,%rcx
    5ecf:	0f 8e 40 01 00 00    	jle    6015 <w123+0x1f5>
    5ed5:	48 89 ca             	mov    %rcx,%rdx
    5ed8:	48 2b 50 08          	sub    0x8(%rax),%rdx
    5edc:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    5ee0:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5ee7:	0f 87 1c 01 00 00    	ja     6009 <w123+0x1e9>
    5eed:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    5ef1:	7e 3e                	jle    5f31 <w123+0x111>
    5ef3:	48 89 c7             	mov    %rax,%rdi
    5ef6:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    5efb:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    5f00:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5f05:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    5f0b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    5f11:	e8 4a fd ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    5f16:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    5f1c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    5f22:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    5f27:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    5f2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    5f31:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    5f35:	48 8b 50 20          	mov    0x20(%rax),%rdx
    5f39:	48 85 ed             	test   %rbp,%rbp
    5f3c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    5f41:	48 8b 3d e8 9b 00 00 	mov    0x9be8(%rip),%rdi        # fb30 <msg.4+0xb0>
    5f48:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    5f4c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5f50:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    5f57:	48 0f 48 ee          	cmovs  %rsi,%rbp
    5f5b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    5f5f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    5f63:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    5f68:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    5f6c:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    5f70:	66 0f d6 12          	movq   %xmm2,(%rdx)
    5f74:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    5f78:	48 89 50 10          	mov    %rdx,0x10(%rax)
    5f7c:	48 83 c4 30          	add    $0x30,%rsp
    5f80:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f87:	ff ff ff 
    5f8a:	48 21 c3             	and    %rax,%rbx
    5f8d:	48 09 cb             	or     %rcx,%rbx
    5f90:	48 89 d8             	mov    %rbx,%rax
    5f93:	5b                   	pop    %rbx
    5f94:	5d                   	pop    %rbp
    5f95:	41 5e                	pop    %r14
    5f97:	c3                   	ret
    5f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5f9f:	00 
    5fa0:	48 89 f9             	mov    %rdi,%rcx
    5fa3:	48 89 f0             	mov    %rsi,%rax
    5fa6:	48 c1 f9 20          	sar    $0x20,%rcx
    5faa:	48 c1 f8 20          	sar    $0x20,%rax
    5fae:	48 39 c1             	cmp    %rax,%rcx
    5fb1:	0f 84 95 fe ff ff    	je     5e4c <w123+0x2c>
    5fb7:	48 8d 3d 0a 98 00 00 	lea    0x980a(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    5fbe:	e8 9d e1 ff ff       	call   4160 <fwp_trap>
    5fc3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fc8:	48 8b 42 08          	mov    0x8(%rdx),%rax
    5fcc:	e9 d8 fe ff ff       	jmp    5ea9 <w123+0x89>
    5fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fd8:	48 83 c4 30          	add    $0x30,%rsp
    5fdc:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    5fe3:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    5fe7:	48 89 d8             	mov    %rbx,%rax
    5fea:	5b                   	pop    %rbx
    5feb:	5d                   	pop    %rbp
    5fec:	41 5e                	pop    %r14
    5fee:	c3                   	ret
    5fef:	90                   	nop
    5ff0:	48 89 f1             	mov    %rsi,%rcx
    5ff3:	48 89 f3             	mov    %rsi,%rbx
    5ff6:	45 31 f6             	xor    %r14d,%r14d
    5ff9:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6000:	48 c1 f9 20          	sar    $0x20,%rcx
    6004:	e9 51 fe ff ff       	jmp    5e5a <w123+0x3a>
    6009:	48 8d 3d d9 90 00 00 	lea    0x90d9(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    6010:	e8 4b e1 ff ff       	call   4160 <fwp_trap>
    6015:	48 8d 3d e8 90 00 00 	lea    0x90e8(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    601c:	e8 3f e1 ff ff       	call   4160 <fwp_trap>
    6021:	48 8d 3d e8 97 00 00 	lea    0x97e8(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    6028:	e8 33 e1 ff ff       	call   4160 <fwp_trap>
    602d:	0f 1f 00             	nopl   (%rax)

0000000000006030 <w120>:
    6030:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6034:	41 57                	push   %r15
    6036:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    603a:	41 56                	push   %r14
    603c:	41 55                	push   %r13
    603e:	49 89 fd             	mov    %rdi,%r13
    6041:	41 54                	push   %r12
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	55                   	push   %rbp
    6047:	48 89 f5             	mov    %rsi,%rbp
    604a:	53                   	push   %rbx
    604b:	48 83 ec 48          	sub    $0x48,%rsp
    604f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6055:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    605a:	48 85 ff             	test   %rdi,%rdi
    605d:	0f 88 5d 06 00 00    	js     66c0 <w120+0x690>
    6063:	49 89 fe             	mov    %rdi,%r14
    6066:	49 c1 fe 20          	sar    $0x20,%r14
    606a:	4c 3b 32             	cmp    (%rdx),%r14
    606d:	0f 84 ed 05 00 00    	je     6660 <w120+0x630>
    6073:	4c 89 f7             	mov    %r14,%rdi
    6076:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    607c:	e8 bf e3 ff ff       	call   4440 <fwp_tape_of>
    6081:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6087:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    608c:	48 89 c3             	mov    %rax,%rbx
    608f:	0f 85 97 06 00 00    	jne    672c <w120+0x6fc>
    6095:	4d 89 34 24          	mov    %r14,(%r12)
    6099:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    609e:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    60a2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    60a9:	0f 8f 71 06 00 00    	jg     6720 <w120+0x6f0>
    60af:	44 89 e8             	mov    %r13d,%eax
    60b2:	49 39 c6             	cmp    %rax,%r14
    60b5:	0f 8e 4a 06 00 00    	jle    6705 <w120+0x6d5>
    60bb:	4c 89 f0             	mov    %r14,%rax
    60be:	48 2b 43 08          	sub    0x8(%rbx),%rax
    60c2:	48 8d 70 01          	lea    0x1(%rax),%rsi
    60c6:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    60cd:	0f 87 4d 06 00 00    	ja     6720 <w120+0x6f0>
    60d3:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    60d9:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    60dd:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    60e1:	0f 8f 61 04 00 00    	jg     6548 <w120+0x518>
    60e7:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    60eb:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    60f0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60f4:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    60f9:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    60fe:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6103:	49 8d 46 01          	lea    0x1(%r14),%rax
    6107:	48 89 43 10          	mov    %rax,0x10(%rbx)
    610b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6112:	ff ff ff 
    6115:	4c 21 eb             	and    %r13,%rbx
    6118:	4c 09 f3             	or     %r14,%rbx
    611b:	49 89 de             	mov    %rbx,%r14
    611e:	49 c1 fe 20          	sar    $0x20,%r14
    6122:	48 85 ed             	test   %rbp,%rbp
    6125:	78 10                	js     6137 <w120+0x107>
    6127:	48 89 e8             	mov    %rbp,%rax
    612a:	48 c1 f8 20          	sar    $0x20,%rax
    612e:	4c 39 f0             	cmp    %r14,%rax
    6131:	0f 85 da 05 00 00    	jne    6711 <w120+0x6e1>
    6137:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    613c:	66 0f 28 2d dc 99 00 	movapd 0x99dc(%rip),%xmm5        # fb20 <msg.4+0xa0>
    6143:	00 
    6144:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6149:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    614e:	4d 39 34 24          	cmp    %r14,(%r12)
    6152:	0f 84 18 05 00 00    	je     6670 <w120+0x640>
    6158:	4c 89 f7             	mov    %r14,%rdi
    615b:	e8 e0 e2 ff ff       	call   4440 <fwp_tape_of>
    6160:	48 89 c2             	mov    %rax,%rdx
    6163:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6168:	0f 85 be 05 00 00    	jne    672c <w120+0x6fc>
    616e:	4d 89 34 24          	mov    %r14,(%r12)
    6172:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6177:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    617b:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6182:	0f 8f 98 05 00 00    	jg     6720 <w120+0x6f0>
    6188:	89 d8                	mov    %ebx,%eax
    618a:	49 39 c6             	cmp    %rax,%r14
    618d:	0f 8e 72 05 00 00    	jle    6705 <w120+0x6d5>
    6193:	48 85 ed             	test   %rbp,%rbp
    6196:	78 0b                	js     61a3 <w120+0x173>
    6198:	89 e8                	mov    %ebp,%eax
    619a:	49 39 c6             	cmp    %rax,%r14
    619d:	0f 8e 62 05 00 00    	jle    6705 <w120+0x6d5>
    61a3:	4c 89 f0             	mov    %r14,%rax
    61a6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    61aa:	48 8d 70 01          	lea    0x1(%rax),%rsi
    61ae:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    61b5:	0f 87 65 05 00 00    	ja     6720 <w120+0x6f0>
    61bb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    61bf:	0f 8f bb 03 00 00    	jg     6580 <w120+0x550>
    61c5:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    61c9:	48 8b 42 20          	mov    0x20(%rdx),%rax
    61cd:	48 85 ed             	test   %rbp,%rbp
    61d0:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    61d6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    61db:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    61df:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61e6:	48 0f 49 c5          	cmovns %rbp,%rax
    61ea:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    61ee:	66 48 0f 6e d8       	movq   %rax,%xmm3
    61f3:	49 8d 46 01          	lea    0x1(%r14),%rax
    61f7:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    61fb:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    61ff:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6203:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6207:	4d 85 ed             	test   %r13,%r13
    620a:	0f 88 4b 05 00 00    	js     675b <w120+0x72b>
    6210:	4c 89 ea             	mov    %r13,%rdx
    6213:	48 c1 fa 20          	sar    $0x20,%rdx
    6217:	49 3b 14 24          	cmp    (%r12),%rdx
    621b:	0f 84 5f 04 00 00    	je     6680 <w120+0x650>
    6221:	48 89 d7             	mov    %rdx,%rdi
    6224:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6229:	e8 12 e2 ff ff       	call   4440 <fwp_tape_of>
    622e:	48 89 c5             	mov    %rax,%rbp
    6231:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6236:	0f 85 f0 04 00 00    	jne    672c <w120+0x6fc>
    623c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6241:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6246:	49 89 14 24          	mov    %rdx,(%r12)
    624a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    624e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6254:	0f 8f c6 04 00 00    	jg     6720 <w120+0x6f0>
    625a:	44 89 ea             	mov    %r13d,%edx
    625d:	48 39 d0             	cmp    %rdx,%rax
    6260:	0f 8e 9f 04 00 00    	jle    6705 <w120+0x6d5>
    6266:	48 89 c2             	mov    %rax,%rdx
    6269:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    626d:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6271:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6278:	0f 87 a2 04 00 00    	ja     6720 <w120+0x6f0>
    627e:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    6282:	0f 8f 20 03 00 00    	jg     65a8 <w120+0x578>
    6288:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    628d:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    6291:	66 0f 28 05 87 98 00 	movapd 0x9887(%rip),%xmm0        # fb20 <msg.4+0xa0>
    6298:	00 
    6299:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    629d:	66 0f 28 ee          	movapd %xmm6,%xmm5
    62a1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    62a5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    62a9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    62b0:	ff 
    62b1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    62b6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    62ba:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    62be:	4c 89 ed             	mov    %r13,%rbp
    62c1:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    62c8:	ff ff ff 
    62cb:	48 21 d5             	and    %rdx,%rbp
    62ce:	48 09 c5             	or     %rax,%rbp
    62d1:	66 49 0f 7e ef       	movq   %xmm5,%r15
    62d6:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    62dd:	ff ff ff 
    62e0:	48 21 c3             	and    %rax,%rbx
    62e3:	4c 09 f3             	or     %r14,%rbx
    62e6:	49 89 de             	mov    %rbx,%r14
    62e9:	49 c1 fe 20          	sar    $0x20,%r14
    62ed:	4d 3b 34 24          	cmp    (%r12),%r14
    62f1:	0f 84 99 03 00 00    	je     6690 <w120+0x660>
    62f7:	4c 89 f7             	mov    %r14,%rdi
    62fa:	e8 41 e1 ff ff       	call   4440 <fwp_tape_of>
    62ff:	49 89 c5             	mov    %rax,%r13
    6302:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6307:	0f 85 1f 04 00 00    	jne    672c <w120+0x6fc>
    630d:	4d 89 34 24          	mov    %r14,(%r12)
    6311:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6316:	4d 8b 75 10          	mov    0x10(%r13),%r14
    631a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6321:	0f 8f f9 03 00 00    	jg     6720 <w120+0x6f0>
    6327:	89 d8                	mov    %ebx,%eax
    6329:	49 39 c6             	cmp    %rax,%r14
    632c:	0f 8e d3 03 00 00    	jle    6705 <w120+0x6d5>
    6332:	4c 89 f0             	mov    %r14,%rax
    6335:	49 2b 45 08          	sub    0x8(%r13),%rax
    6339:	48 8d 70 01          	lea    0x1(%rax),%rsi
    633d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6344:	0f 87 d6 03 00 00    	ja     6720 <w120+0x6f0>
    634a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    634f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6353:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6357:	0f 8f 73 02 00 00    	jg     65d0 <w120+0x5a0>
    635d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    6361:	66 0f 6e eb          	movd   %ebx,%xmm5
    6365:	49 8b 45 20          	mov    0x20(%r13),%rax
    6369:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    636e:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    6373:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6378:	49 8d 46 01          	lea    0x1(%r14),%rax
    637c:	49 89 45 10          	mov    %rax,0x10(%r13)
    6380:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6387:	ff ff ff 
    638a:	48 21 c3             	and    %rax,%rbx
    638d:	4c 09 f3             	or     %r14,%rbx
    6390:	49 89 dd             	mov    %rbx,%r13
    6393:	49 c1 fd 20          	sar    $0x20,%r13
    6397:	4d 3b 2c 24          	cmp    (%r12),%r13
    639b:	0f 84 ff 02 00 00    	je     66a0 <w120+0x670>
    63a1:	4c 89 ef             	mov    %r13,%rdi
    63a4:	e8 97 e0 ff ff       	call   4440 <fwp_tape_of>
    63a9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    63ae:	0f 85 78 03 00 00    	jne    672c <w120+0x6fc>
    63b4:	4d 89 2c 24          	mov    %r13,(%r12)
    63b8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    63bd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    63c1:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    63c8:	0f 8f 52 03 00 00    	jg     6720 <w120+0x6f0>
    63ce:	89 da                	mov    %ebx,%edx
    63d0:	49 39 d5             	cmp    %rdx,%r13
    63d3:	0f 8e 2c 03 00 00    	jle    6705 <w120+0x6d5>
    63d9:	4d 89 ee             	mov    %r13,%r14
    63dc:	4c 2b 70 08          	sub    0x8(%rax),%r14
    63e0:	49 8d 76 01          	lea    0x1(%r14),%rsi
    63e4:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    63eb:	0f 87 2f 03 00 00    	ja     6720 <w120+0x6f0>
    63f1:	f2 0f 10 15 37 97 00 	movsd  0x9737(%rip),%xmm2        # fb30 <msg.4+0xb0>
    63f8:	00 
    63f9:	66 49 0f 6e cf       	movq   %r15,%xmm1
    63fe:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6404:	f2 0f 59 0d 34 97 00 	mulsd  0x9734(%rip),%xmm1        # fb40 <msg.4+0xc0>
    640b:	00 
    640c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6410:	0f 8f da 01 00 00    	jg     65f0 <w120+0x5c0>
    6416:	48 8b 50 20          	mov    0x20(%rax),%rdx
    641a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    641e:	f3 0f 7e 05 1a 97 00 	movq   0x971a(%rip),%xmm0        # fb40 <msg.4+0xc0>
    6425:	00 
    6426:	48 89 ef             	mov    %rbp,%rdi
    6429:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    642c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6431:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6435:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    643c:	ff 
    643d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6441:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6445:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6449:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6450:	ff ff ff 
    6453:	48 21 c3             	and    %rax,%rbx
    6456:	4c 09 eb             	or     %r13,%rbx
    6459:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    645d:	0f 84 c8 00 00 00    	je     652b <w120+0x4fb>
    6463:	49 89 ed             	mov    %rbp,%r13
    6466:	49 c1 fd 20          	sar    $0x20,%r13
    646a:	4d 39 2c 24          	cmp    %r13,(%r12)
    646e:	0f 84 3c 02 00 00    	je     66b0 <w120+0x680>
    6474:	4c 89 ef             	mov    %r13,%rdi
    6477:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    647d:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6482:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    6488:	e8 b3 df ff ff       	call   4440 <fwp_tape_of>
    648d:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6492:	0f 85 94 02 00 00    	jne    672c <w120+0x6fc>
    6498:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    649e:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    64a3:	4d 89 2c 24          	mov    %r13,(%r12)
    64a7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    64ac:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    64b2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    64b6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    64bd:	0f 8f 5d 02 00 00    	jg     6720 <w120+0x6f0>
    64c3:	89 e9                	mov    %ebp,%ecx
    64c5:	4c 39 f1             	cmp    %r14,%rcx
    64c8:	0f 8d 37 02 00 00    	jge    6705 <w120+0x6d5>
    64ce:	4d 89 f5             	mov    %r14,%r13
    64d1:	4c 2b 68 08          	sub    0x8(%rax),%r13
    64d5:	49 8d 75 01          	lea    0x1(%r13),%rsi
    64d9:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    64e0:	0f 87 3a 02 00 00    	ja     6720 <w120+0x6f0>
    64e6:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    64ea:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    64ee:	0f 8f 2c 01 00 00    	jg     6620 <w120+0x5f0>
    64f4:	48 8b 48 20          	mov    0x20(%rax),%rcx
    64f8:	66 0f 6e dd          	movd   %ebp,%xmm3
    64fc:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6501:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6508:	ff ff ff 
    650b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6510:	48 21 d5             	and    %rdx,%rbp
    6513:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6518:	48 89 ef             	mov    %rbp,%rdi
    651b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6520:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6524:	4c 09 f7             	or     %r14,%rdi
    6527:	48 89 48 10          	mov    %rcx,0x10(%rax)
    652b:	4c 89 e2             	mov    %r12,%rdx
    652e:	48 89 de             	mov    %rbx,%rsi
    6531:	e8 ea f8 ff ff       	call   5e20 <w123>
    6536:	48 83 c4 48          	add    $0x48,%rsp
    653a:	5b                   	pop    %rbx
    653b:	5d                   	pop    %rbp
    653c:	41 5c                	pop    %r12
    653e:	41 5d                	pop    %r13
    6540:	41 5e                	pop    %r14
    6542:	41 5f                	pop    %r15
    6544:	c3                   	ret
    6545:	0f 1f 00             	nopl   (%rax)
    6548:	48 89 df             	mov    %rbx,%rdi
    654b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6550:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6556:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    655b:	e8 00 f7 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6560:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    6566:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    656c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6571:	e9 71 fb ff ff       	jmp    60e7 <w120+0xb7>
    6576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    657d:	00 00 00 
    6580:	48 89 d7             	mov    %rdx,%rdi
    6583:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6588:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    658d:	e8 ce f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6592:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6597:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    659c:	e9 24 fc ff ff       	jmp    61c5 <w120+0x195>
    65a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65a8:	48 89 ef             	mov    %rbp,%rdi
    65ab:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    65b0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    65b5:	e8 a6 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    65ba:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    65bf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    65c4:	e9 bf fc ff ff       	jmp    6288 <w120+0x258>
    65c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65d0:	4c 89 ef             	mov    %r13,%rdi
    65d3:	48 89 04 24          	mov    %rax,(%rsp)
    65d7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    65dc:	e8 7f f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    65e1:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    65e7:	48 8b 04 24          	mov    (%rsp),%rax
    65eb:	e9 6d fd ff ff       	jmp    635d <w120+0x32d>
    65f0:	48 89 c7             	mov    %rax,%rdi
    65f3:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    65f8:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    65fe:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6603:	e8 58 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    6608:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    660e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6613:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6618:	e9 f9 fd ff ff       	jmp    6416 <w120+0x3e6>
    661d:	0f 1f 00             	nopl   (%rax)
    6620:	48 89 c7             	mov    %rax,%rdi
    6623:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6628:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    662e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6634:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6638:	e8 23 f6 ff ff       	call   5c60 <fwp_tape_grow.constprop.0>
    663d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6643:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6649:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    664e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6653:	e9 9c fe ff ff       	jmp    64f4 <w120+0x4c4>
    6658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    665f:	00 
    6660:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    6664:	e9 35 fa ff ff       	jmp    609e <w120+0x6e>
    6669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6670:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    6675:	e9 fd fa ff ff       	jmp    6177 <w120+0x147>
    667a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6680:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    6685:	e9 c0 fb ff ff       	jmp    624a <w120+0x21a>
    668a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6690:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6695:	e9 7c fc ff ff       	jmp    6316 <w120+0x2e6>
    669a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66a0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66a5:	e9 13 fd ff ff       	jmp    63bd <w120+0x38d>
    66aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66b0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66b5:	e9 f8 fd ff ff       	jmp    64b2 <w120+0x482>
    66ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66c0:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    66c5:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    66ca:	48 85 f6             	test   %rsi,%rsi
    66cd:	79 69                	jns    6738 <w120+0x708>
    66cf:	f2 0f 10 05 59 94 00 	movsd  0x9459(%rip),%xmm0        # fb30 <msg.4+0xb0>
    66d6:	00 
    66d7:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    66dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66e3:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    66ea:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    66f0:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    66f4:	f2 0f 59 0d 44 94 00 	mulsd  0x9444(%rip),%xmm1        # fb40 <msg.4+0xc0>
    66fb:	00 
    66fc:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6700:	e9 26 fe ff ff       	jmp    652b <w120+0x4fb>
    6705:	48 8d 3d f8 89 00 00 	lea    0x89f8(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    670c:	e8 4f da ff ff       	call   4160 <fwp_trap>
    6711:	48 8d 3d b0 90 00 00 	lea    0x90b0(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    6718:	e8 43 da ff ff       	call   4160 <fwp_trap>
    671d:	0f 1f 00             	nopl   (%rax)
    6720:	48 8d 3d c2 89 00 00 	lea    0x89c2(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    6727:	e8 34 da ff ff       	call   4160 <fwp_trap>
    672c:	48 8d 3d dd 90 00 00 	lea    0x90dd(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    6733:	e8 28 da ff ff       	call   4160 <fwp_trap>
    6738:	49 89 f6             	mov    %rsi,%r14
    673b:	f3 0f 7e 3d ed 93 00 	movq   0x93ed(%rip),%xmm7        # fb30 <msg.4+0xb0>
    6742:	00 
    6743:	48 89 f3             	mov    %rsi,%rbx
    6746:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    674b:	49 c1 fe 20          	sar    $0x20,%r14
    674f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6756:	e9 f3 f9 ff ff       	jmp    614e <w120+0x11e>
    675b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    6760:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    6765:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    676c:	66 49 0f 7e ff       	movq   %xmm7,%r15
    6771:	e9 60 fb ff ff       	jmp    62d6 <w120+0x2a6>
    6776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    677d:	00 00 00 

0000000000006780 <w176.constprop.0>:
    6780:	41 55                	push   %r13
    6782:	41 54                	push   %r12
    6784:	55                   	push   %rbp
    6785:	53                   	push   %rbx
    6786:	48 83 ec 28          	sub    $0x28,%rsp
    678a:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    6791:	00 00 
    6793:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    6798:	48 8b 2f             	mov    (%rdi),%rbp
    679b:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    67a2:	ff 
    67a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    67aa:	00 00 
    67ac:	48 85 ed             	test   %rbp,%rbp
    67af:	74 5f                	je     6810 <w176.constprop.0+0x90>
    67b1:	49 89 fd             	mov    %rdi,%r13
    67b4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67b8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67bf:	31 db                	xor    %ebx,%ebx
    67c1:	0f 1f 40 00          	nopl   0x0(%rax)
    67c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67cc:	00 00 00 00 
    67d0:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    67d5:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    67dc:	48 89 e2             	mov    %rsp,%rdx
    67df:	48 83 c3 02          	add    $0x2,%rbx
    67e3:	e8 38 f6 ff ff       	call   5e20 <w123>
    67e8:	48 89 c7             	mov    %rax,%rdi
    67eb:	48 39 eb             	cmp    %rbp,%rbx
    67ee:	72 e0                	jb     67d0 <w176.constprop.0+0x50>
    67f0:	48 89 f8             	mov    %rdi,%rax
    67f3:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    67f8:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    67ff:	00 00 
    6801:	75 1a                	jne    681d <w176.constprop.0+0x9d>
    6803:	48 83 c4 28          	add    $0x28,%rsp
    6807:	5b                   	pop    %rbx
    6808:	5d                   	pop    %rbp
    6809:	41 5c                	pop    %r12
    680b:	41 5d                	pop    %r13
    680d:	c3                   	ret
    680e:	66 90                	xchg   %ax,%ax
    6810:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6817:	66 0f ef c0          	pxor   %xmm0,%xmm0
    681b:	eb d3                	jmp    67f0 <w176.constprop.0+0x70>
    681d:	e8 1e cc ff ff       	call   3440 <__stack_chk_fail@plt>
    6822:	0f 1f 00             	nopl   (%rax)
    6825:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    682c:	00 00 00 00 

0000000000006830 <fwp_rc_share>:
    6830:	48 8b 05 e1 e2 01 00 	mov    0x1e2e1(%rip),%rax        # 24b18 <fwp_heap+0x13d8>
    6837:	48 2b 3d b2 e2 01 00 	sub    0x1e2b2(%rip),%rdi        # 24af0 <fwp_heap+0x13b0>
    683e:	48 c1 e0 10          	shl    $0x10,%rax
    6842:	48 39 c7             	cmp    %rax,%rdi
    6845:	73 4a                	jae    6891 <fwp_rc_share+0x61>
    6847:	48 89 f8             	mov    %rdi,%rax
    684a:	48 c1 e8 10          	shr    $0x10,%rax
    684e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6852:	48 8b 05 df e2 01 00 	mov    0x1e2df(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    6859:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    685d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6861:	48 85 d2             	test   %rdx,%rdx
    6864:	74 2b                	je     6891 <fwp_rc_share+0x61>
    6866:	0f b6 08             	movzbl (%rax),%ecx
    6869:	80 f9 02             	cmp    $0x2,%cl
    686c:	74 2a                	je     6898 <fwp_rc_share+0x68>
    686e:	80 f9 01             	cmp    $0x1,%cl
    6871:	75 1e                	jne    6891 <fwp_rc_share+0x61>
    6873:	8b 48 18             	mov    0x18(%rax),%ecx
    6876:	0f b7 ff             	movzwl %di,%edi
    6879:	8b 40 1c             	mov    0x1c(%rax),%eax
    687c:	48 0f af f9          	imul   %rcx,%rdi
    6880:	48 c1 ef 20          	shr    $0x20,%rdi
    6884:	48 39 c7             	cmp    %rax,%rdi
    6887:	73 08                	jae    6891 <fwp_rc_share+0x61>
    6889:	48 01 fa             	add    %rdi,%rdx
    688c:	80 3a 00             	cmpb   $0x0,(%rdx)
    688f:	75 0d                	jne    689e <fwp_rc_share+0x6e>
    6891:	c3                   	ret
    6892:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6898:	66 85 ff             	test   %di,%di
    689b:	74 ef                	je     688c <fwp_rc_share+0x5c>
    689d:	c3                   	ret
    689e:	50                   	push   %rax
    689f:	48 8d 3d 9a 8f 00 00 	lea    0x8f9a(%rip),%rdi        # f840 <_IO_stdin_used+0x840>
    68a6:	e8 b5 d8 ff ff       	call   4160 <fwp_trap>
    68ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068b0 <fwp_rc_fresh>:
    68b0:	48 8b 15 61 e2 01 00 	mov    0x1e261(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    68b7:	48 89 f8             	mov    %rdi,%rax
    68ba:	48 89 fe             	mov    %rdi,%rsi
    68bd:	48 2b 05 2c e2 01 00 	sub    0x1e22c(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    68c4:	48 c1 e2 10          	shl    $0x10,%rdx
    68c8:	48 39 d0             	cmp    %rdx,%rax
    68cb:	73 4f                	jae    691c <fwp_rc_fresh+0x6c>
    68cd:	48 89 c2             	mov    %rax,%rdx
    68d0:	48 c1 ea 10          	shr    $0x10,%rdx
    68d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68d8:	48 8b 15 59 e2 01 00 	mov    0x1e259(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    68df:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68e7:	48 85 d2             	test   %rdx,%rdx
    68ea:	74 30                	je     691c <fwp_rc_fresh+0x6c>
    68ec:	0f b6 39             	movzbl (%rcx),%edi
    68ef:	40 80 ff 02          	cmp    $0x2,%dil
    68f3:	74 2b                	je     6920 <fwp_rc_fresh+0x70>
    68f5:	40 80 ff 01          	cmp    $0x1,%dil
    68f9:	75 21                	jne    691c <fwp_rc_fresh+0x6c>
    68fb:	8b 79 18             	mov    0x18(%rcx),%edi
    68fe:	0f b7 c0             	movzwl %ax,%eax
    6901:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6904:	48 0f af c7          	imul   %rdi,%rax
    6908:	48 c1 e8 20          	shr    $0x20,%rax
    690c:	48 39 c8             	cmp    %rcx,%rax
    690f:	73 0b                	jae    691c <fwp_rc_fresh+0x6c>
    6911:	48 01 c2             	add    %rax,%rdx
    6914:	80 3a ff             	cmpb   $0xff,(%rdx)
    6917:	74 17                	je     6930 <fwp_rc_fresh+0x80>
    6919:	c6 02 01             	movb   $0x1,(%rdx)
    691c:	48 89 f0             	mov    %rsi,%rax
    691f:	c3                   	ret
    6920:	66 85 c0             	test   %ax,%ax
    6923:	74 ef                	je     6914 <fwp_rc_fresh+0x64>
    6925:	48 89 f0             	mov    %rsi,%rax
    6928:	c3                   	ret
    6929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6930:	48 83 ec 18          	sub    $0x18,%rsp
    6934:	48 89 d7             	mov    %rdx,%rdi
    6937:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    693c:	48 89 14 24          	mov    %rdx,(%rsp)
    6940:	e8 8b e9 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6945:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    694a:	48 8b 14 24          	mov    (%rsp),%rdx
    694e:	48 89 f0             	mov    %rsi,%rax
    6951:	c6 02 01             	movb   $0x1,(%rdx)
    6954:	48 83 c4 18          	add    $0x18,%rsp
    6958:	c3                   	ret
    6959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006960 <fwp_rc_free_obj>:
    6960:	48 8b 15 b1 e1 01 00 	mov    0x1e1b1(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    6967:	48 89 f8             	mov    %rdi,%rax
    696a:	48 2b 05 7f e1 01 00 	sub    0x1e17f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    6971:	48 c1 e2 10          	shl    $0x10,%rdx
    6975:	48 39 d0             	cmp    %rdx,%rax
    6978:	73 5b                	jae    69d5 <fwp_rc_free_obj+0x75>
    697a:	48 89 c2             	mov    %rax,%rdx
    697d:	48 c1 ea 10          	shr    $0x10,%rdx
    6981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6985:	48 8b 15 ac e1 01 00 	mov    0x1e1ac(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    698c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6990:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6994:	48 85 c9             	test   %rcx,%rcx
    6997:	74 3c                	je     69d5 <fwp_rc_free_obj+0x75>
    6999:	0f b6 32             	movzbl (%rdx),%esi
    699c:	40 80 fe 02          	cmp    $0x2,%sil
    69a0:	74 2e                	je     69d0 <fwp_rc_free_obj+0x70>
    69a2:	40 80 fe 01          	cmp    $0x1,%sil
    69a6:	75 2d                	jne    69d5 <fwp_rc_free_obj+0x75>
    69a8:	8b 72 18             	mov    0x18(%rdx),%esi
    69ab:	0f b7 c0             	movzwl %ax,%eax
    69ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69b1:	48 0f af c6          	imul   %rsi,%rax
    69b5:	48 c1 e8 20          	shr    $0x20,%rax
    69b9:	48 39 d0             	cmp    %rdx,%rax
    69bc:	73 17                	jae    69d5 <fwp_rc_free_obj+0x75>
    69be:	48 01 c1             	add    %rax,%rcx
    69c1:	80 39 01             	cmpb   $0x1,(%rcx)
    69c4:	75 0f                	jne    69d5 <fwp_rc_free_obj+0x75>
    69c6:	e9 45 eb ff ff       	jmp    5510 <fwp_mem_free>
    69cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69d0:	66 85 c0             	test   %ax,%ax
    69d3:	74 ec                	je     69c1 <fwp_rc_free_obj+0x61>
    69d5:	c3                   	ret
    69d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69dd:	00 00 00 

00000000000069e0 <fwp_rc_dup>:
    69e0:	f3 0f 1e fa          	endbr64
    69e4:	48 8b 05 2d e1 01 00 	mov    0x1e12d(%rip),%rax        # 24b18 <fwp_heap+0x13d8>
    69eb:	48 2b 3d fe e0 01 00 	sub    0x1e0fe(%rip),%rdi        # 24af0 <fwp_heap+0x13b0>
    69f2:	48 c1 e0 10          	shl    $0x10,%rax
    69f6:	48 39 c7             	cmp    %rax,%rdi
    69f9:	73 56                	jae    6a51 <fwp_rc_dup+0x71>
    69fb:	48 89 f8             	mov    %rdi,%rax
    69fe:	48 c1 e8 10          	shr    $0x10,%rax
    6a02:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a06:	48 8b 05 2b e1 01 00 	mov    0x1e12b(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    6a0d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a11:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a15:	48 85 c0             	test   %rax,%rax
    6a18:	74 37                	je     6a51 <fwp_rc_dup+0x71>
    6a1a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a1d:	80 f9 02             	cmp    $0x2,%cl
    6a20:	74 36                	je     6a58 <fwp_rc_dup+0x78>
    6a22:	80 f9 01             	cmp    $0x1,%cl
    6a25:	75 2a                	jne    6a51 <fwp_rc_dup+0x71>
    6a27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a2a:	0f b7 ff             	movzwl %di,%edi
    6a2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a30:	48 0f af f9          	imul   %rcx,%rdi
    6a34:	48 c1 ef 20          	shr    $0x20,%rdi
    6a38:	48 39 d7             	cmp    %rdx,%rdi
    6a3b:	73 14                	jae    6a51 <fwp_rc_dup+0x71>
    6a3d:	48 01 f8             	add    %rdi,%rax
    6a40:	0f b6 10             	movzbl (%rax),%edx
    6a43:	84 d2                	test   %dl,%dl
    6a45:	74 0a                	je     6a51 <fwp_rc_dup+0x71>
    6a47:	80 fa fd             	cmp    $0xfd,%dl
    6a4a:	77 14                	ja     6a60 <fwp_rc_dup+0x80>
    6a4c:	83 c2 01             	add    $0x1,%edx
    6a4f:	88 10                	mov    %dl,(%rax)
    6a51:	c3                   	ret
    6a52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a58:	66 85 ff             	test   %di,%di
    6a5b:	74 e3                	je     6a40 <fwp_rc_dup+0x60>
    6a5d:	c3                   	ret
    6a5e:	66 90                	xchg   %ax,%ax
    6a60:	48 89 c7             	mov    %rax,%rdi
    6a63:	e9 48 e7 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    6a68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a6f:	00 

0000000000006a70 <fwp_owned_entry173>:
    6a70:	f3 0f 1e fa          	endbr64
    6a74:	48 83 ec 38          	sub    $0x38,%rsp
    6a78:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a7d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a84:	00 00 
    6a86:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a8b:	31 c0                	xor    %eax,%eax
    6a8d:	48 8b 07             	mov    (%rdi),%rax
    6a90:	48 03 47 10          	add    0x10(%rdi),%rax
    6a94:	0f 80 c2 00 00 00    	jo     6b5c <fwp_owned_entry173+0xec>
    6a9a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a9f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6aa4:	31 ff                	xor    %edi,%edi
    6aa6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6aaa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6aaf:	e8 7c f0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    6ab4:	48 8b 15 5d e0 01 00 	mov    0x1e05d(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    6abb:	48 89 c6             	mov    %rax,%rsi
    6abe:	48 2b 05 2b e0 01 00 	sub    0x1e02b(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    6ac5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac9:	48 39 d0             	cmp    %rdx,%rax
    6acc:	73 4f                	jae    6b1d <fwp_owned_entry173+0xad>
    6ace:	48 89 c2             	mov    %rax,%rdx
    6ad1:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad9:	48 8b 15 58 e0 01 00 	mov    0x1e058(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    6ae0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ae4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ae8:	48 85 d2             	test   %rdx,%rdx
    6aeb:	74 30                	je     6b1d <fwp_owned_entry173+0xad>
    6aed:	0f b6 39             	movzbl (%rcx),%edi
    6af0:	40 80 ff 02          	cmp    $0x2,%dil
    6af4:	74 42                	je     6b38 <fwp_owned_entry173+0xc8>
    6af6:	40 80 ff 01          	cmp    $0x1,%dil
    6afa:	75 21                	jne    6b1d <fwp_owned_entry173+0xad>
    6afc:	8b 79 18             	mov    0x18(%rcx),%edi
    6aff:	0f b7 c0             	movzwl %ax,%eax
    6b02:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b05:	48 0f af c7          	imul   %rdi,%rax
    6b09:	48 c1 e8 20          	shr    $0x20,%rax
    6b0d:	48 39 c8             	cmp    %rcx,%rax
    6b10:	73 0b                	jae    6b1d <fwp_owned_entry173+0xad>
    6b12:	48 01 c2             	add    %rax,%rdx
    6b15:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b18:	74 26                	je     6b40 <fwp_owned_entry173+0xd0>
    6b1a:	c6 02 01             	movb   $0x1,(%rdx)
    6b1d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b29:	00 00 
    6b2b:	75 34                	jne    6b61 <fwp_owned_entry173+0xf1>
    6b2d:	48 89 f0             	mov    %rsi,%rax
    6b30:	48 83 c4 38          	add    $0x38,%rsp
    6b34:	c3                   	ret
    6b35:	0f 1f 00             	nopl   (%rax)
    6b38:	66 85 c0             	test   %ax,%ax
    6b3b:	75 e0                	jne    6b1d <fwp_owned_entry173+0xad>
    6b3d:	eb d6                	jmp    6b15 <fwp_owned_entry173+0xa5>
    6b3f:	90                   	nop
    6b40:	48 89 d7             	mov    %rdx,%rdi
    6b43:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b48:	48 89 14 24          	mov    %rdx,(%rsp)
    6b4c:	e8 7f e7 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6b51:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b56:	48 8b 14 24          	mov    (%rsp),%rdx
    6b5a:	eb be                	jmp    6b1a <fwp_owned_entry173+0xaa>
    6b5c:	e8 5f cb ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6b61:	e8 da c8 ff ff       	call   3440 <__stack_chk_fail@plt>
    6b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b6d:	00 00 00 

0000000000006b70 <e173>:
    6b70:	f3 0f 1e fa          	endbr64
    6b74:	53                   	push   %rbx
    6b75:	48 83 ec 30          	sub    $0x30,%rsp
    6b79:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b7e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b85:	00 00 
    6b87:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b8c:	31 c0                	xor    %eax,%eax
    6b8e:	48 8b 07             	mov    (%rdi),%rax
    6b91:	48 03 47 10          	add    0x10(%rdi),%rax
    6b95:	0f 80 c9 00 00 00    	jo     6c64 <e173+0xf4>
    6b9b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6ba0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ba5:	31 ff                	xor    %edi,%edi
    6ba7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bab:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6bb0:	e8 7b ef ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    6bb5:	48 8b 15 5c df 01 00 	mov    0x1df5c(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    6bbc:	48 89 c3             	mov    %rax,%rbx
    6bbf:	48 2b 05 2a df 01 00 	sub    0x1df2a(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    6bc6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bca:	48 39 d0             	cmp    %rdx,%rax
    6bcd:	73 4f                	jae    6c1e <e173+0xae>
    6bcf:	48 89 c2             	mov    %rax,%rdx
    6bd2:	48 c1 ea 10          	shr    $0x10,%rdx
    6bd6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bda:	48 8b 15 57 df 01 00 	mov    0x1df57(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    6be1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6be5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6be9:	48 85 d2             	test   %rdx,%rdx
    6bec:	74 30                	je     6c1e <e173+0xae>
    6bee:	0f b6 31             	movzbl (%rcx),%esi
    6bf1:	40 80 fe 02          	cmp    $0x2,%sil
    6bf5:	74 49                	je     6c40 <e173+0xd0>
    6bf7:	40 80 fe 01          	cmp    $0x1,%sil
    6bfb:	75 21                	jne    6c1e <e173+0xae>
    6bfd:	8b 71 18             	mov    0x18(%rcx),%esi
    6c00:	0f b7 c0             	movzwl %ax,%eax
    6c03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c06:	48 0f af c6          	imul   %rsi,%rax
    6c0a:	48 c1 e8 20          	shr    $0x20,%rax
    6c0e:	48 39 c8             	cmp    %rcx,%rax
    6c11:	73 0b                	jae    6c1e <e173+0xae>
    6c13:	48 01 c2             	add    %rax,%rdx
    6c16:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c19:	74 35                	je     6c50 <e173+0xe0>
    6c1b:	c6 02 01             	movb   $0x1,(%rdx)
    6c1e:	48 89 df             	mov    %rbx,%rdi
    6c21:	e8 0a fc ff ff       	call   6830 <fwp_rc_share>
    6c26:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c2b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c32:	00 00 
    6c34:	75 33                	jne    6c69 <e173+0xf9>
    6c36:	48 83 c4 30          	add    $0x30,%rsp
    6c3a:	48 89 d8             	mov    %rbx,%rax
    6c3d:	5b                   	pop    %rbx
    6c3e:	c3                   	ret
    6c3f:	90                   	nop
    6c40:	66 85 c0             	test   %ax,%ax
    6c43:	75 d9                	jne    6c1e <e173+0xae>
    6c45:	eb cf                	jmp    6c16 <e173+0xa6>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	48 89 d7             	mov    %rdx,%rdi
    6c53:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c58:	e8 73 e6 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6c5d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c62:	eb b7                	jmp    6c1b <e173+0xab>
    6c64:	e8 57 ca ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    6c69:	e8 d2 c7 ff ff       	call   3440 <__stack_chk_fail@plt>
    6c6e:	66 90                	xchg   %ax,%ax

0000000000006c70 <fwp_closure_drop>:
    6c70:	48 8b 15 a1 de 01 00 	mov    0x1dea1(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    6c77:	48 89 f8             	mov    %rdi,%rax
    6c7a:	48 2b 05 6f de 01 00 	sub    0x1de6f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    6c81:	48 c1 e2 10          	shl    $0x10,%rdx
    6c85:	48 39 d0             	cmp    %rdx,%rax
    6c88:	73 6b                	jae    6cf5 <fwp_closure_drop+0x85>
    6c8a:	48 89 c2             	mov    %rax,%rdx
    6c8d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c95:	48 8b 15 9c de 01 00 	mov    0x1de9c(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    6c9c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ca0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ca4:	48 85 d2             	test   %rdx,%rdx
    6ca7:	74 4c                	je     6cf5 <fwp_closure_drop+0x85>
    6ca9:	0f b6 31             	movzbl (%rcx),%esi
    6cac:	40 80 fe 02          	cmp    $0x2,%sil
    6cb0:	74 3e                	je     6cf0 <fwp_closure_drop+0x80>
    6cb2:	40 80 fe 01          	cmp    $0x1,%sil
    6cb6:	75 3d                	jne    6cf5 <fwp_closure_drop+0x85>
    6cb8:	8b 71 18             	mov    0x18(%rcx),%esi
    6cbb:	0f b7 c0             	movzwl %ax,%eax
    6cbe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cc1:	48 0f af c6          	imul   %rsi,%rax
    6cc5:	48 c1 e8 20          	shr    $0x20,%rax
    6cc9:	48 39 c8             	cmp    %rcx,%rax
    6ccc:	73 27                	jae    6cf5 <fwp_closure_drop+0x85>
    6cce:	48 01 c2             	add    %rax,%rdx
    6cd1:	0f b6 02             	movzbl (%rdx),%eax
    6cd4:	84 c0                	test   %al,%al
    6cd6:	74 1d                	je     6cf5 <fwp_closure_drop+0x85>
    6cd8:	3c 01                	cmp    $0x1,%al
    6cda:	74 24                	je     6d00 <fwp_closure_drop+0x90>
    6cdc:	3c ff                	cmp    $0xff,%al
    6cde:	74 48                	je     6d28 <fwp_closure_drop+0xb8>
    6ce0:	83 e8 01             	sub    $0x1,%eax
    6ce3:	88 02                	mov    %al,(%rdx)
    6ce5:	c3                   	ret
    6ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ced:	00 00 00 
    6cf0:	66 85 c0             	test   %ax,%ax
    6cf3:	74 dc                	je     6cd1 <fwp_closure_drop+0x61>
    6cf5:	c3                   	ret
    6cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cfd:	00 00 00 
    6d00:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6d07:	ff ff 
    6d09:	48 85 c0             	test   %rax,%rax
    6d0c:	74 12                	je     6d20 <fwp_closure_drop+0xb0>
    6d0e:	48 89 fe             	mov    %rdi,%rsi
    6d11:	48 89 c7             	mov    %rax,%rdi
    6d14:	e9 a7 d4 ff ff       	jmp    41c0 <fwp_closure_drop_push>
    6d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d20:	e9 4b d6 ff ff       	jmp    4370 <fwp_closure_drop.part.0>
    6d25:	0f 1f 00             	nopl   (%rax)
    6d28:	48 89 d0             	mov    %rdx,%rax
    6d2b:	48 8d 35 0e ca 01 00 	lea    0x1ca0e(%rip),%rsi        # 23740 <fwp_heap>
    6d32:	48 83 ec 18          	sub    $0x18,%rsp
    6d36:	48 c1 e8 11          	shr    $0x11,%rax
    6d3a:	48 31 d0             	xor    %rdx,%rax
    6d3d:	48 89 c1             	mov    %rax,%rcx
    6d40:	48 c1 e9 09          	shr    $0x9,%rcx
    6d44:	48 31 c8             	xor    %rcx,%rax
    6d47:	0f b6 c8             	movzbl %al,%ecx
    6d4a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6d51:	00 
    6d52:	48 85 c0             	test   %rax,%rax
    6d55:	75 12                	jne    6d69 <fwp_closure_drop+0xf9>
    6d57:	eb 49                	jmp    6da2 <fwp_closure_drop+0x132>
    6d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d64:	48 85 c0             	test   %rax,%rax
    6d67:	74 39                	je     6da2 <fwp_closure_drop+0x132>
    6d69:	48 89 c1             	mov    %rax,%rcx
    6d6c:	48 39 10             	cmp    %rdx,(%rax)
    6d6f:	75 ef                	jne    6d60 <fwp_closure_drop+0xf0>
    6d71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d84:	74 05                	je     6d8b <fwp_closure_drop+0x11b>
    6d86:	48 83 c4 18          	add    $0x18,%rsp
    6d8a:	c3                   	ret
    6d8b:	48 89 d7             	mov    %rdx,%rdi
    6d8e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d93:	e8 38 e5 ff ff       	call   52d0 <fwp_rc_forget_slot>
    6d98:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d9d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6da0:	eb e4                	jmp    6d86 <fwp_closure_drop+0x116>
    6da2:	48 8d 3d f7 89 00 00 	lea    0x89f7(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    6da9:	e8 b2 d3 ff ff       	call   4160 <fwp_trap>
    6dae:	66 90                	xchg   %ax,%ax

0000000000006db0 <fwp_owned_tape_release>:
    6db0:	48 85 ff             	test   %rdi,%rdi
    6db3:	0f 84 f7 00 00 00    	je     6eb0 <fwp_owned_tape_release+0x100>
    6db9:	41 54                	push   %r12
    6dbb:	55                   	push   %rbp
    6dbc:	53                   	push   %rbx
    6dbd:	48 8b 07             	mov    (%rdi),%rax
    6dc0:	48 85 c0             	test   %rax,%rax
    6dc3:	74 08                	je     6dcd <fwp_owned_tape_release+0x1d>
    6dc5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6dc9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6dcd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6dd1:	48 85 d2             	test   %rdx,%rdx
    6dd4:	74 03                	je     6dd9 <fwp_owned_tape_release+0x29>
    6dd6:	48 89 02             	mov    %rax,(%rdx)
    6dd9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ddd:	48 89 fb             	mov    %rdi,%rbx
    6de0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6de4:	48 85 c0             	test   %rax,%rax
    6de7:	0f 84 89 00 00 00    	je     6e76 <fwp_owned_tape_release+0xc6>
    6ded:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6df1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6df5:	7e 47                	jle    6e3e <fwp_owned_tape_release+0x8e>
    6df7:	31 ed                	xor    %ebp,%ebp
    6df9:	eb 0d                	jmp    6e08 <fwp_owned_tape_release+0x58>
    6dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e0c:	49 89 ec             	mov    %rbp,%r12
    6e0f:	48 83 c5 01          	add    $0x1,%rbp
    6e13:	49 c1 e4 04          	shl    $0x4,%r12
    6e17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e1b:	ff d0                	call   *%rax
    6e1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e2a:	ff 50 68             	call   *0x68(%rax)
    6e2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e35:	48 39 e8             	cmp    %rbp,%rax
    6e38:	7f c6                	jg     6e00 <fwp_owned_tape_release+0x50>
    6e3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e3e:	31 ed                	xor    %ebp,%ebp
    6e40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6e45:	7e 28                	jle    6e6f <fwp_owned_tape_release+0xbf>
    6e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e4e:	00 00 
    6e50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6e54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6e58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6e5c:	74 07                	je     6e65 <fwp_owned_tape_release+0xb5>
    6e5e:	ff 52 68             	call   *0x68(%rdx)
    6e61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e65:	48 83 c5 01          	add    $0x1,%rbp
    6e69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e6d:	7f e1                	jg     6e50 <fwp_owned_tape_release+0xa0>
    6e6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e73:	ff 52 68             	call   *0x68(%rdx)
    6e76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e7a:	e8 f1 fd ff ff       	call   6c70 <fwp_closure_drop>
    6e7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e83:	e8 e8 fd ff ff       	call   6c70 <fwp_closure_drop>
    6e88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e8c:	e8 df fd ff ff       	call   6c70 <fwp_closure_drop>
    6e91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e95:	e8 76 e6 ff ff       	call   5510 <fwp_mem_free>
    6e9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e9e:	e8 6d e6 ff ff       	call   5510 <fwp_mem_free>
    6ea3:	48 89 df             	mov    %rbx,%rdi
    6ea6:	5b                   	pop    %rbx
    6ea7:	5d                   	pop    %rbp
    6ea8:	41 5c                	pop    %r12
    6eaa:	e9 61 e6 ff ff       	jmp    5510 <fwp_mem_free>
    6eaf:	90                   	nop
    6eb0:	c3                   	ret
    6eb1:	0f 1f 40 00          	nopl   0x0(%rax)
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 

0000000000006ec0 <fwp_tape_finish>:
    6ec0:	f3 0f 1e fa          	endbr64
    6ec4:	41 56                	push   %r14
    6ec6:	48 8d 3d d3 c1 01 00 	lea    0x1c1d3(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6ecd:	41 55                	push   %r13
    6ecf:	41 54                	push   %r12
    6ed1:	55                   	push   %rbp
    6ed2:	53                   	push   %rbx
    6ed3:	e8 58 d0 ff ff       	call   3f30 <fwp_tape_buffers_dispose>
    6ed8:	48 83 3d f8 c1 01 00 	cmpq   $0x0,0x1c1f8(%rip)        # 230d8 <fwp_ntapes>
    6edf:	00 
    6ee0:	48 c7 05 9d c1 01 00 	movq   $0x0,0x1c19d(%rip)        # 23088 <fwp_tape_cached_bytes>
    6ee7:	00 00 00 00 
    6eeb:	7e 68                	jle    6f55 <fwp_tape_finish+0x95>
    6eed:	45 31 e4             	xor    %r12d,%r12d
    6ef0:	31 ed                	xor    %ebp,%ebp
    6ef2:	0f 1f 00             	nopl   (%rax)
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 1d d9 c1 01 00 	mov    0x1c1d9(%rip),%rbx        # 230e0 <fwp_tapes>
    6f07:	48 83 c5 01          	add    $0x1,%rbp
    6f0b:	4c 01 e3             	add    %r12,%rbx
    6f0e:	49 83 c4 58          	add    $0x58,%r12
    6f12:	48 89 df             	mov    %rbx,%rdi
    6f15:	e8 a6 cc ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    6f1a:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6f1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f22:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
    6f26:	e8 75 c4 ff ff       	call   33a0 <free@plt>
    6f2b:	4c 89 f7             	mov    %r14,%rdi
    6f2e:	e8 6d c4 ff ff       	call   33a0 <free@plt>
    6f33:	4c 89 ef             	mov    %r13,%rdi
    6f36:	e8 65 c4 ff ff       	call   33a0 <free@plt>
    6f3b:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    6f3f:	e8 6c fe ff ff       	call   6db0 <fwp_owned_tape_release>
    6f44:	48 39 2d 8d c1 01 00 	cmp    %rbp,0x1c18d(%rip)        # 230d8 <fwp_ntapes>
    6f4b:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    6f52:	00 
    6f53:	7f ab                	jg     6f00 <fwp_tape_finish+0x40>
    6f55:	48 8b 3d 84 c1 01 00 	mov    0x1c184(%rip),%rdi        # 230e0 <fwp_tapes>
    6f5c:	e8 3f c4 ff ff       	call   33a0 <free@plt>
    6f61:	5b                   	pop    %rbx
    6f62:	5d                   	pop    %rbp
    6f63:	48 c7 05 72 c1 01 00 	movq   $0x0,0x1c172(%rip)        # 230e0 <fwp_tapes>
    6f6a:	00 00 00 00 
    6f6e:	48 c7 05 57 c1 01 00 	movq   $0x0,0x1c157(%rip)        # 230d0 <fwp_tapes_cap>
    6f75:	00 00 00 00 
    6f79:	41 5c                	pop    %r12
    6f7b:	48 c7 05 52 c1 01 00 	movq   $0x0,0x1c152(%rip)        # 230d8 <fwp_ntapes>
    6f82:	00 00 00 00 
    6f86:	41 5d                	pop    %r13
    6f88:	48 c7 05 35 c1 01 00 	movq   $0x0,0x1c135(%rip)        # 230c8 <fwp_tape_next_slot>
    6f8f:	00 00 00 00 
    6f93:	41 5e                	pop    %r14
    6f95:	c3                   	ret
    6f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f9d:	00 00 00 

0000000000006fa0 <fwp_tape_scope_release>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	41 55                	push   %r13
    6fa6:	41 54                	push   %r12
    6fa8:	55                   	push   %rbp
    6fa9:	53                   	push   %rbx
    6faa:	48 83 ec 48          	sub    $0x48,%rsp
    6fae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6fb5:	00 00 
    6fb7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6fbc:	48 63 07             	movslq (%rdi),%rax
    6fbf:	85 c0                	test   %eax,%eax
    6fc1:	0f 88 f8 00 00 00    	js     70bf <fwp_tape_scope_release+0x11f>
    6fc7:	48 bd a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%rbp
    6fce:	a2 8b 2e 
    6fd1:	48 89 fb             	mov    %rdi,%rbx
    6fd4:	eb 3d                	jmp    7013 <fwp_tape_scope_release+0x73>
    6fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fdd:	00 00 00 
    6fe0:	66 48 0f 7e c7       	movq   %xmm0,%rdi
    6fe5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6fe9:	e8 b2 c3 ff ff       	call   33a0 <free@plt>
    6fee:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ff3:	e8 a8 c3 ff ff       	call   33a0 <free@plt>
    6ff8:	4c 89 ef             	mov    %r13,%rdi
    6ffb:	e8 a0 c3 ff ff       	call   33a0 <free@plt>
    7000:	4c 89 e7             	mov    %r12,%rdi
    7003:	e8 a8 fd ff ff       	call   6db0 <fwp_owned_tape_release>
    7008:	48 63 03             	movslq (%rbx),%rax
    700b:	85 c0                	test   %eax,%eax
    700d:	0f 88 ac 00 00 00    	js     70bf <fwp_tape_scope_release+0x11f>
    7013:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    7017:	48 8b 35 c2 c0 01 00 	mov    0x1c0c2(%rip),%rsi        # 230e0 <fwp_tapes>
    701e:	4c 01 c6             	add    %r8,%rsi
    7021:	48 89 f7             	mov    %rsi,%rdi
    7024:	e8 97 cb ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    7029:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    702e:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
    7032:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7039:	f3 0f 7e 4e 18       	movq   0x18(%rsi),%xmm1
    703e:	0f 16 4e 38          	movhps 0x38(%rsi),%xmm1
    7042:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
    7047:	66 0f ef c9          	pxor   %xmm1,%xmm1
    704b:	4c 8b 66 50          	mov    0x50(%rsi),%r12
    704f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
    7054:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    705b:	00 
    705c:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    7063:	00 
    7064:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    706b:	00 
    706c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7073:	00 
    7074:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7079:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    707d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    7081:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7087:	77 18                	ja     70a1 <fwp_tape_scope_release+0x101>
    7089:	49 c1 f8 03          	sar    $0x3,%r8
    708d:	4c 0f af c5          	imul   %rbp,%r8
    7091:	4c 3b 05 30 c0 01 00 	cmp    0x1c030(%rip),%r8        # 230c8 <fwp_tape_next_slot>
    7098:	7d 07                	jge    70a1 <fwp_tape_scope_release+0x101>
    709a:	4c 89 05 27 c0 01 00 	mov    %r8,0x1c027(%rip)        # 230c8 <fwp_tape_next_slot>
    70a1:	4d 85 e4             	test   %r12,%r12
    70a4:	0f 85 36 ff ff ff    	jne    6fe0 <fwp_tape_scope_release+0x40>
    70aa:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    70af:	e8 3c dd ff ff       	call   4df0 <fwp_tape_buffers_release>
    70b4:	48 63 03             	movslq (%rbx),%rax
    70b7:	85 c0                	test   %eax,%eax
    70b9:	0f 89 54 ff ff ff    	jns    7013 <fwp_tape_scope_release+0x73>
    70bf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    70c4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    70cb:	00 00 
    70cd:	75 0b                	jne    70da <fwp_tape_scope_release+0x13a>
    70cf:	48 83 c4 48          	add    $0x48,%rsp
    70d3:	5b                   	pop    %rbx
    70d4:	5d                   	pop    %rbp
    70d5:	41 5c                	pop    %r12
    70d7:	41 5d                	pop    %r13
    70d9:	c3                   	ret
    70da:	e8 61 c3 ff ff       	call   3440 <__stack_chk_fail@plt>
    70df:	90                   	nop

00000000000070e0 <fwp_drop4>:
    70e0:	48 8b 0d 31 da 01 00 	mov    0x1da31(%rip),%rcx        # 24b18 <fwp_heap+0x13d8>
    70e7:	48 89 f8             	mov    %rdi,%rax
    70ea:	48 2b 05 ff d9 01 00 	sub    0x1d9ff(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    70f1:	48 c1 e1 10          	shl    $0x10,%rcx
    70f5:	48 39 c8             	cmp    %rcx,%rax
    70f8:	0f 83 42 01 00 00    	jae    7240 <fwp_drop4+0x160>
    70fe:	48 83 ec 18          	sub    $0x18,%rsp
    7102:	48 89 fa             	mov    %rdi,%rdx
    7105:	4c 8d 05 34 c6 01 00 	lea    0x1c634(%rip),%r8        # 23740 <fwp_heap>
    710c:	48 89 c1             	mov    %rax,%rcx
    710f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7116:	48 c1 e9 10          	shr    $0x10,%rcx
    711a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    711e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7122:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7126:	48 85 c9             	test   %rcx,%rcx
    7129:	74 40                	je     716b <fwp_drop4+0x8b>
    712b:	0f b6 3e             	movzbl (%rsi),%edi
    712e:	40 80 ff 02          	cmp    $0x2,%dil
    7132:	74 3c                	je     7170 <fwp_drop4+0x90>
    7134:	40 80 ff 01          	cmp    $0x1,%dil
    7138:	75 31                	jne    716b <fwp_drop4+0x8b>
    713a:	8b 7e 18             	mov    0x18(%rsi),%edi
    713d:	0f b7 c0             	movzwl %ax,%eax
    7140:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7143:	48 0f af c7          	imul   %rdi,%rax
    7147:	48 c1 e8 20          	shr    $0x20,%rax
    714b:	48 39 f0             	cmp    %rsi,%rax
    714e:	73 1b                	jae    716b <fwp_drop4+0x8b>
    7150:	48 01 c1             	add    %rax,%rcx
    7153:	0f b6 01             	movzbl (%rcx),%eax
    7156:	84 c0                	test   %al,%al
    7158:	74 11                	je     716b <fwp_drop4+0x8b>
    715a:	3c 01                	cmp    $0x1,%al
    715c:	74 22                	je     7180 <fwp_drop4+0xa0>
    715e:	3c ff                	cmp    $0xff,%al
    7160:	0f 84 0a 01 00 00    	je     7270 <fwp_drop4+0x190>
    7166:	83 e8 01             	sub    $0x1,%eax
    7169:	88 01                	mov    %al,(%rcx)
    716b:	48 83 c4 18          	add    $0x18,%rsp
    716f:	c3                   	ret
    7170:	66 85 c0             	test   %ax,%ax
    7173:	74 de                	je     7153 <fwp_drop4+0x73>
    7175:	48 83 c4 18          	add    $0x18,%rsp
    7179:	c3                   	ret
    717a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7180:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7184:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    718b:	48 89 f8             	mov    %rdi,%rax
    718e:	48 c1 e1 10          	shl    $0x10,%rcx
    7192:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7199:	48 39 c8             	cmp    %rcx,%rax
    719c:	73 62                	jae    7200 <fwp_drop4+0x120>
    719e:	48 89 c1             	mov    %rax,%rcx
    71a1:	48 c1 e9 10          	shr    $0x10,%rcx
    71a5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71a9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71ad:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71b1:	48 85 c9             	test   %rcx,%rcx
    71b4:	74 4a                	je     7200 <fwp_drop4+0x120>
    71b6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    71ba:	41 80 f9 02          	cmp    $0x2,%r9b
    71be:	0f 84 9c 00 00 00    	je     7260 <fwp_drop4+0x180>
    71c4:	41 80 f9 01          	cmp    $0x1,%r9b
    71c8:	75 36                	jne    7200 <fwp_drop4+0x120>
    71ca:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    71ce:	0f b7 c0             	movzwl %ax,%eax
    71d1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71d4:	49 0f af c1          	imul   %r9,%rax
    71d8:	48 c1 e8 20          	shr    $0x20,%rax
    71dc:	48 39 f0             	cmp    %rsi,%rax
    71df:	73 1f                	jae    7200 <fwp_drop4+0x120>
    71e1:	48 01 c1             	add    %rax,%rcx
    71e4:	0f b6 01             	movzbl (%rcx),%eax
    71e7:	84 c0                	test   %al,%al
    71e9:	74 15                	je     7200 <fwp_drop4+0x120>
    71eb:	3c 01                	cmp    $0x1,%al
    71ed:	74 59                	je     7248 <fwp_drop4+0x168>
    71ef:	3c ff                	cmp    $0xff,%al
    71f1:	0f 84 ef 00 00 00    	je     72e6 <fwp_drop4+0x206>
    71f7:	83 e8 01             	sub    $0x1,%eax
    71fa:	88 01                	mov    %al,(%rcx)
    71fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7200:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7204:	48 89 d7             	mov    %rdx,%rdi
    7207:	48 89 0c 24          	mov    %rcx,(%rsp)
    720b:	e8 50 f7 ff ff       	call   6960 <fwp_rc_free_obj>
    7210:	4c 8d 05 29 c5 01 00 	lea    0x1c529(%rip),%r8        # 23740 <fwp_heap>
    7217:	48 8b 04 24          	mov    (%rsp),%rax
    721b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7222:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7229:	48 c1 e2 10          	shl    $0x10,%rdx
    722d:	48 39 d0             	cmp    %rdx,%rax
    7230:	0f 83 35 ff ff ff    	jae    716b <fwp_drop4+0x8b>
    7236:	48 8b 14 24          	mov    (%rsp),%rdx
    723a:	e9 cd fe ff ff       	jmp    710c <fwp_drop4+0x2c>
    723f:	90                   	nop
    7240:	c3                   	ret
    7241:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7248:	48 89 14 24          	mov    %rdx,(%rsp)
    724c:	e8 0f f7 ff ff       	call   6960 <fwp_rc_free_obj>
    7251:	48 8b 14 24          	mov    (%rsp),%rdx
    7255:	eb a9                	jmp    7200 <fwp_drop4+0x120>
    7257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    725e:	00 00 
    7260:	66 85 c0             	test   %ax,%ax
    7263:	75 9b                	jne    7200 <fwp_drop4+0x120>
    7265:	e9 7a ff ff ff       	jmp    71e4 <fwp_drop4+0x104>
    726a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7270:	48 89 c8             	mov    %rcx,%rax
    7273:	48 c1 e8 11          	shr    $0x11,%rax
    7277:	48 31 c8             	xor    %rcx,%rax
    727a:	48 89 c2             	mov    %rax,%rdx
    727d:	48 c1 ea 09          	shr    $0x9,%rdx
    7281:	48 31 d0             	xor    %rdx,%rax
    7284:	0f b6 d0             	movzbl %al,%edx
    7287:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    728e:	00 
    728f:	48 85 c0             	test   %rax,%rax
    7292:	75 19                	jne    72ad <fwp_drop4+0x1cd>
    7294:	e9 d3 00 00 00       	jmp    736c <fwp_drop4+0x28c>
    7299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    72a4:	48 85 c0             	test   %rax,%rax
    72a7:	0f 84 bf 00 00 00    	je     736c <fwp_drop4+0x28c>
    72ad:	48 89 c2             	mov    %rax,%rdx
    72b0:	48 39 08             	cmp    %rcx,(%rax)
    72b3:	75 eb                	jne    72a0 <fwp_drop4+0x1c0>
    72b5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    72b9:	48 83 ea 01          	sub    $0x1,%rdx
    72bd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72c1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72c8:	0f 85 9d fe ff ff    	jne    716b <fwp_drop4+0x8b>
    72ce:	48 89 cf             	mov    %rcx,%rdi
    72d1:	48 89 0c 24          	mov    %rcx,(%rsp)
    72d5:	e8 f6 df ff ff       	call   52d0 <fwp_rc_forget_slot>
    72da:	48 8b 0c 24          	mov    (%rsp),%rcx
    72de:	c6 01 fe             	movb   $0xfe,(%rcx)
    72e1:	e9 85 fe ff ff       	jmp    716b <fwp_drop4+0x8b>
    72e6:	48 89 ce             	mov    %rcx,%rsi
    72e9:	48 c1 ee 11          	shr    $0x11,%rsi
    72ed:	48 31 ce             	xor    %rcx,%rsi
    72f0:	48 89 f0             	mov    %rsi,%rax
    72f3:	48 c1 e8 09          	shr    $0x9,%rax
    72f7:	48 31 c6             	xor    %rax,%rsi
    72fa:	40 0f b6 f6          	movzbl %sil,%esi
    72fe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7305:	00 
    7306:	48 85 c0             	test   %rax,%rax
    7309:	75 1e                	jne    7329 <fwp_drop4+0x249>
    730b:	eb 5f                	jmp    736c <fwp_drop4+0x28c>
    730d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7314:	00 
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 
    7320:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	74 43                	je     736c <fwp_drop4+0x28c>
    7329:	48 89 c6             	mov    %rax,%rsi
    732c:	48 39 08             	cmp    %rcx,(%rax)
    732f:	75 ef                	jne    7320 <fwp_drop4+0x240>
    7331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7335:	48 83 ee 01          	sub    $0x1,%rsi
    7339:	48 89 70 08          	mov    %rsi,0x8(%rax)
    733d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7344:	0f 85 b6 fe ff ff    	jne    7200 <fwp_drop4+0x120>
    734a:	48 89 cf             	mov    %rcx,%rdi
    734d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7352:	48 89 0c 24          	mov    %rcx,(%rsp)
    7356:	e8 75 df ff ff       	call   52d0 <fwp_rc_forget_slot>
    735b:	48 8b 0c 24          	mov    (%rsp),%rcx
    735f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7364:	c6 01 fe             	movb   $0xfe,(%rcx)
    7367:	e9 94 fe ff ff       	jmp    7200 <fwp_drop4+0x120>
    736c:	48 8d 3d 2d 84 00 00 	lea    0x842d(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7373:	e8 e8 cd ff ff       	call   4160 <fwp_trap>
    7378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    737f:	00 

0000000000007380 <fwp_arg_drop37>:
    7380:	f3 0f 1e fa          	endbr64
    7384:	85 f6                	test   %esi,%esi
    7386:	75 04                	jne    738c <fwp_arg_drop37+0xc>
    7388:	85 d2                	test   %edx,%edx
    738a:	75 04                	jne    7390 <fwp_arg_drop37+0x10>
    738c:	c3                   	ret
    738d:	0f 1f 00             	nopl   (%rax)
    7390:	48 8b 3f             	mov    (%rdi),%rdi
    7393:	e9 48 fd ff ff       	jmp    70e0 <fwp_drop4>
    7398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    739f:	00 

00000000000073a0 <fwp_task_dispose>:
    73a0:	53                   	push   %rbx
    73a1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    73a5:	0f 84 5b c3 ff ff    	je     3706 <fwp_task_dispose.cold>
    73ab:	48 89 fb             	mov    %rdi,%rbx
    73ae:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    73b3:	0f 85 4d c3 ff ff    	jne    3706 <fwp_task_dispose.cold>
    73b9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    73bd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    73c4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    73cb:	00 
    73cc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    73d0:	48 85 ff             	test   %rdi,%rdi
    73d3:	74 07                	je     73dc <fwp_task_dispose+0x3c>
    73d5:	48 85 c0             	test   %rax,%rax
    73d8:	74 02                	je     73dc <fwp_task_dispose+0x3c>
    73da:	ff d0                	call   *%rax
    73dc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    73e3:	e8 28 e1 ff ff       	call   5510 <fwp_mem_free>
    73e8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    73ef:	00 00 00 00 
    73f3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    73f7:	74 6f                	je     7468 <fwp_task_dispose+0xc8>
    73f9:	48 8b 15 18 d7 01 00 	mov    0x1d718(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    7400:	48 89 d8             	mov    %rbx,%rax
    7403:	48 2b 05 e6 d6 01 00 	sub    0x1d6e6(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    740a:	48 c1 e2 10          	shl    $0x10,%rdx
    740e:	48 39 d0             	cmp    %rdx,%rax
    7411:	73 4c                	jae    745f <fwp_task_dispose+0xbf>
    7413:	48 89 c2             	mov    %rax,%rdx
    7416:	48 c1 ea 10          	shr    $0x10,%rdx
    741a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    741e:	48 8b 15 13 d7 01 00 	mov    0x1d713(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    7425:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7429:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    742d:	48 85 c9             	test   %rcx,%rcx
    7430:	74 2d                	je     745f <fwp_task_dispose+0xbf>
    7432:	0f b6 32             	movzbl (%rdx),%esi
    7435:	40 80 fe 02          	cmp    $0x2,%sil
    7439:	74 3d                	je     7478 <fwp_task_dispose+0xd8>
    743b:	40 80 fe 01          	cmp    $0x1,%sil
    743f:	75 1e                	jne    745f <fwp_task_dispose+0xbf>
    7441:	8b 72 18             	mov    0x18(%rdx),%esi
    7444:	0f b7 c0             	movzwl %ax,%eax
    7447:	8b 52 1c             	mov    0x1c(%rdx),%edx
    744a:	48 0f af c6          	imul   %rsi,%rax
    744e:	48 c1 e8 20          	shr    $0x20,%rax
    7452:	48 39 d0             	cmp    %rdx,%rax
    7455:	73 08                	jae    745f <fwp_task_dispose+0xbf>
    7457:	48 01 c1             	add    %rax,%rcx
    745a:	80 39 01             	cmpb   $0x1,(%rcx)
    745d:	74 09                	je     7468 <fwp_task_dispose+0xc8>
    745f:	5b                   	pop    %rbx
    7460:	c3                   	ret
    7461:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7468:	48 89 df             	mov    %rbx,%rdi
    746b:	5b                   	pop    %rbx
    746c:	e9 9f e0 ff ff       	jmp    5510 <fwp_mem_free>
    7471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7478:	66 85 c0             	test   %ax,%ax
    747b:	74 dd                	je     745a <fwp_task_dispose+0xba>
    747d:	5b                   	pop    %rbx
    747e:	c3                   	ret
    747f:	90                   	nop

0000000000007480 <fwp_free_zombie>:
    7480:	48 8b 15 89 c2 01 00 	mov    0x1c289(%rip),%rdx        # 23710 <fwp_zombie>
    7487:	48 85 d2             	test   %rdx,%rdx
    748a:	0f 84 98 00 00 00    	je     7528 <fwp_free_zombie+0xa8>
    7490:	48 3b 15 89 c2 01 00 	cmp    0x1c289(%rip),%rdx        # 23720 <fwp_cur>
    7497:	0f 84 8b 00 00 00    	je     7528 <fwp_free_zombie+0xa8>
    749d:	48 83 ec 18          	sub    $0x18,%rsp
    74a1:	48 63 05 54 bc 01 00 	movslq 0x1bc54(%rip),%rax        # 230fc <fwp_stack_pool_n>
    74a8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    74ac:	83 f8 3f             	cmp    $0x3f,%eax
    74af:	7f 7f                	jg     7530 <fwp_free_zombie+0xb0>
    74b1:	8d 48 01             	lea    0x1(%rax),%ecx
    74b4:	89 0d 42 bc 01 00    	mov    %ecx,0x1bc42(%rip)        # 230fc <fwp_stack_pool_n>
    74ba:	48 8d 0d 3f bc 01 00 	lea    0x1bc3f(%rip),%rcx        # 23100 <fwp_stack_pool>
    74c1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    74c5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    74cc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74d0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    74d7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    74db:	48 85 c9             	test   %rcx,%rcx
    74de:	0f 84 fc 00 00 00    	je     75e0 <fwp_free_zombie+0x160>
    74e4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    74eb:	48 85 c0             	test   %rax,%rax
    74ee:	74 07                	je     74f7 <fwp_free_zombie+0x77>
    74f0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    74f7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    74fa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74fe:	48 c7 05 07 c2 01 00 	movq   $0x0,0x1c207(%rip)        # 23710 <fwp_zombie>
    7505:	00 00 00 00 
    7509:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7510:	85 c0                	test   %eax,%eax
    7512:	74 34                	je     7548 <fwp_free_zombie+0xc8>
    7514:	83 f8 01             	cmp    $0x1,%eax
    7517:	0f 84 b3 00 00 00    	je     75d0 <fwp_free_zombie+0x150>
    751d:	48 83 c4 18          	add    $0x18,%rsp
    7521:	c3                   	ret
    7522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7528:	c3                   	ret
    7529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7530:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7534:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7539:	e8 72 c0 ff ff       	call   35b0 <munmap@plt>
    753e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7543:	eb 80                	jmp    74c5 <fwp_free_zombie+0x45>
    7545:	0f 1f 00             	nopl   (%rax)
    7548:	48 8b 0d c9 d5 01 00 	mov    0x1d5c9(%rip),%rcx        # 24b18 <fwp_heap+0x13d8>
    754f:	48 89 d0             	mov    %rdx,%rax
    7552:	48 2b 05 97 d5 01 00 	sub    0x1d597(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    7559:	48 c1 e1 10          	shl    $0x10,%rcx
    755d:	48 39 c8             	cmp    %rcx,%rax
    7560:	73 bb                	jae    751d <fwp_free_zombie+0x9d>
    7562:	48 89 c1             	mov    %rax,%rcx
    7565:	48 c1 e9 10          	shr    $0x10,%rcx
    7569:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    756d:	48 8b 0d c4 d5 01 00 	mov    0x1d5c4(%rip),%rcx        # 24b38 <fwp_heap+0x13f8>
    7574:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7578:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    757c:	48 85 c9             	test   %rcx,%rcx
    757f:	74 9c                	je     751d <fwp_free_zombie+0x9d>
    7581:	0f b6 3e             	movzbl (%rsi),%edi
    7584:	40 80 ff 02          	cmp    $0x2,%dil
    7588:	74 66                	je     75f0 <fwp_free_zombie+0x170>
    758a:	40 80 ff 01          	cmp    $0x1,%dil
    758e:	75 8d                	jne    751d <fwp_free_zombie+0x9d>
    7590:	8b 7e 18             	mov    0x18(%rsi),%edi
    7593:	0f b7 c0             	movzwl %ax,%eax
    7596:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7599:	48 0f af c7          	imul   %rdi,%rax
    759d:	48 c1 e8 20          	shr    $0x20,%rax
    75a1:	48 39 f0             	cmp    %rsi,%rax
    75a4:	0f 83 73 ff ff ff    	jae    751d <fwp_free_zombie+0x9d>
    75aa:	48 01 c1             	add    %rax,%rcx
    75ad:	0f b6 01             	movzbl (%rcx),%eax
    75b0:	84 c0                	test   %al,%al
    75b2:	0f 84 65 ff ff ff    	je     751d <fwp_free_zombie+0x9d>
    75b8:	3c 01                	cmp    $0x1,%al
    75ba:	74 14                	je     75d0 <fwp_free_zombie+0x150>
    75bc:	3c ff                	cmp    $0xff,%al
    75be:	74 3b                	je     75fb <fwp_free_zombie+0x17b>
    75c0:	83 e8 01             	sub    $0x1,%eax
    75c3:	88 01                	mov    %al,(%rcx)
    75c5:	e9 53 ff ff ff       	jmp    751d <fwp_free_zombie+0x9d>
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	48 89 d7             	mov    %rdx,%rdi
    75d3:	48 83 c4 18          	add    $0x18,%rsp
    75d7:	e9 c4 fd ff ff       	jmp    73a0 <fwp_task_dispose>
    75dc:	0f 1f 40 00          	nopl   0x0(%rax)
    75e0:	48 89 05 01 c1 01 00 	mov    %rax,0x1c101(%rip)        # 236e8 <fwp_tasks_active>
    75e7:	e9 ff fe ff ff       	jmp    74eb <fwp_free_zombie+0x6b>
    75ec:	0f 1f 40 00          	nopl   0x0(%rax)
    75f0:	66 85 c0             	test   %ax,%ax
    75f3:	0f 85 24 ff ff ff    	jne    751d <fwp_free_zombie+0x9d>
    75f9:	eb b2                	jmp    75ad <fwp_free_zombie+0x12d>
    75fb:	48 89 ca             	mov    %rcx,%rdx
    75fe:	48 8d 35 3b c1 01 00 	lea    0x1c13b(%rip),%rsi        # 23740 <fwp_heap>
    7605:	48 c1 ea 11          	shr    $0x11,%rdx
    7609:	48 31 ca             	xor    %rcx,%rdx
    760c:	48 89 d0             	mov    %rdx,%rax
    760f:	48 c1 e8 09          	shr    $0x9,%rax
    7613:	48 31 c2             	xor    %rax,%rdx
    7616:	0f b6 d2             	movzbl %dl,%edx
    7619:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7620:	00 
    7621:	48 85 c0             	test   %rax,%rax
    7624:	75 23                	jne    7649 <fwp_free_zombie+0x1c9>
    7626:	eb 5c                	jmp    7684 <fwp_free_zombie+0x204>
    7628:	66 90                	xchg   %ax,%ax
    762a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7631:	00 00 00 00 
    7635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    763c:	00 00 00 00 
    7640:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7644:	48 85 c0             	test   %rax,%rax
    7647:	74 3b                	je     7684 <fwp_free_zombie+0x204>
    7649:	48 89 c2             	mov    %rax,%rdx
    764c:	48 39 08             	cmp    %rcx,(%rax)
    764f:	75 ef                	jne    7640 <fwp_free_zombie+0x1c0>
    7651:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7655:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7659:	48 89 50 08          	mov    %rdx,0x8(%rax)
    765d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7664:	0f 85 b3 fe ff ff    	jne    751d <fwp_free_zombie+0x9d>
    766a:	48 89 cf             	mov    %rcx,%rdi
    766d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7672:	e8 59 dc ff ff       	call   52d0 <fwp_rc_forget_slot>
    7677:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    767c:	c6 01 fe             	movb   $0xfe,(%rcx)
    767f:	e9 99 fe ff ff       	jmp    751d <fwp_free_zombie+0x9d>
    7684:	48 8d 3d 15 81 00 00 	lea    0x8115(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    768b:	e8 d0 ca ff ff       	call   4160 <fwp_trap>

0000000000007690 <fwp_block>:
    7690:	48 83 ec 08          	sub    $0x8,%rsp
    7694:	48 8b 05 6d c0 01 00 	mov    0x1c06d(%rip),%rax        # 23708 <fwp_ready_head>
    769b:	48 85 c0             	test   %rax,%rax
    769e:	0f 84 1c 01 00 00    	je     77c0 <fwp_block+0x130>
    76a4:	90                   	nop
    76a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76ac:	00 00 00 00 
    76b0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    76b7:	48 89 15 4a c0 01 00 	mov    %rdx,0x1c04a(%rip)        # 23708 <fwp_ready_head>
    76be:	48 85 d2             	test   %rdx,%rdx
    76c1:	0f 84 19 01 00 00    	je     77e0 <fwp_block+0x150>
    76c7:	48 8b 15 52 c0 01 00 	mov    0x1c052(%rip),%rdx        # 23720 <fwp_cur>
    76ce:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    76d2:	48 39 c2             	cmp    %rax,%rdx
    76d5:	0f 84 d5 00 00 00    	je     77b0 <fwp_block+0x120>
    76db:	48 8b 0d c6 dc 01 00 	mov    0x1dcc6(%rip),%rcx        # 253a8 <fwp_state_owners>
    76e2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    76e6:	48 89 05 33 c0 01 00 	mov    %rax,0x1c033(%rip)        # 23720 <fwp_cur>
    76ed:	f3 0f 7e 05 db dc 01 	movq   0x1dcdb(%rip),%xmm0        # 253d0 <fwp_foreign_callbacks>
    76f4:	00 
    76f5:	0f 16 05 c4 dc 01 00 	movhps 0x1dcc4(%rip),%xmm0        # 253c0 <fwp_state>
    76fc:	f3 0f 7e 0d c4 dc 01 	movq   0x1dcc4(%rip),%xmm1        # 253c8 <fwp_handlers>
    7703:	00 
    7704:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    770b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7712:	0f 16 0d bf dc 01 00 	movhps 0x1dcbf(%rip),%xmm1        # 253d8 <fwp_cleanups>
    7719:	f3 0f 7e 05 97 dc 01 	movq   0x1dc97(%rip),%xmm0        # 253b8 <fwp_state_len>
    7720:	00 
    7721:	0f 16 05 88 dc 01 00 	movhps 0x1dc88(%rip),%xmm0        # 253b0 <fwp_state_cap>
    7728:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    772f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7736:	48 8b 70 08          	mov    0x8(%rax),%rsi
    773a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7741:	48 89 0d 80 dc 01 00 	mov    %rcx,0x1dc80(%rip)        # 253c8 <fwp_handlers>
    7748:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    774f:	48 89 0d 82 dc 01 00 	mov    %rcx,0x1dc82(%rip)        # 253d8 <fwp_cleanups>
    7756:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    775d:	48 89 0d 6c dc 01 00 	mov    %rcx,0x1dc6c(%rip)        # 253d0 <fwp_foreign_callbacks>
    7764:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    776b:	48 89 0d 4e dc 01 00 	mov    %rcx,0x1dc4e(%rip)        # 253c0 <fwp_state>
    7772:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7779:	48 89 0d 38 dc 01 00 	mov    %rcx,0x1dc38(%rip)        # 253b8 <fwp_state_len>
    7780:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7787:	48 89 0d 22 dc 01 00 	mov    %rcx,0x1dc22(%rip)        # 253b0 <fwp_state_cap>
    778e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7795:	48 89 0d 0c dc 01 00 	mov    %rcx,0x1dc0c(%rip)        # 253a8 <fwp_state_owners>
    779c:	e8 cf bc ff ff       	call   3470 <swapcontext@plt>
    77a1:	f3 0f 1e fa          	endbr64
    77a5:	e8 d6 fc ff ff       	call   7480 <fwp_free_zombie>
    77aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77b0:	8b 05 42 b9 01 00    	mov    0x1b942(%rip),%eax        # 230f8 <fwp_slice>
    77b6:	85 c0                	test   %eax,%eax
    77b8:	74 36                	je     77f0 <fwp_block+0x160>
    77ba:	48 83 c4 08          	add    $0x8,%rsp
    77be:	c3                   	ret
    77bf:	90                   	nop
    77c0:	e8 4b d7 ff ff       	call   4f10 <fwp_poll_events>
    77c5:	48 8b 05 3c bf 01 00 	mov    0x1bf3c(%rip),%rax        # 23708 <fwp_ready_head>
    77cc:	48 85 c0             	test   %rax,%rax
    77cf:	0f 85 db fe ff ff    	jne    76b0 <fwp_block+0x20>
    77d5:	eb e9                	jmp    77c0 <fwp_block+0x130>
    77d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77de:	00 00 
    77e0:	48 c7 05 15 bf 01 00 	movq   $0x0,0x1bf15(%rip)        # 23700 <fwp_ready_tail>
    77e7:	00 00 00 00 
    77eb:	e9 d7 fe ff ff       	jmp    76c7 <fwp_block+0x37>
    77f0:	48 8d 3d 2a 79 00 00 	lea    0x792a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    77f7:	e8 84 bb ff ff       	call   3380 <getenv@plt>
    77fc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7801:	48 85 c0             	test   %rax,%rax
    7804:	74 05                	je     780b <fwp_block+0x17b>
    7806:	80 38 00             	cmpb   $0x0,(%rax)
    7809:	75 0b                	jne    7816 <fwp_block+0x186>
    780b:	89 15 e7 b8 01 00    	mov    %edx,0x1b8e7(%rip)        # 230f8 <fwp_slice>
    7811:	48 83 c4 08          	add    $0x8,%rsp
    7815:	c3                   	ret
    7816:	ba 0a 00 00 00       	mov    $0xa,%edx
    781b:	31 f6                	xor    %esi,%esi
    781d:	48 89 c7             	mov    %rax,%rdi
    7820:	e8 0b bd ff ff       	call   3530 <strtoll@plt>
    7825:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7829:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7830:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7835:	0f 46 d0             	cmovbe %eax,%edx
    7838:	eb d1                	jmp    780b <fwp_block+0x17b>
    783a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007840 <fwp_caps173>:
    7840:	f3 0f 1e fa          	endbr64
    7844:	85 f6                	test   %esi,%esi
    7846:	74 08                	je     7850 <fwp_caps173+0x10>
    7848:	c3                   	ret
    7849:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7850:	48 8b 15 c1 d2 01 00 	mov    0x1d2c1(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    7857:	48 89 f8             	mov    %rdi,%rax
    785a:	48 2b 05 8f d2 01 00 	sub    0x1d28f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    7861:	48 c1 e2 10          	shl    $0x10,%rdx
    7865:	48 39 d0             	cmp    %rdx,%rax
    7868:	73 de                	jae    7848 <fwp_caps173+0x8>
    786a:	48 89 c2             	mov    %rax,%rdx
    786d:	48 c1 ea 10          	shr    $0x10,%rdx
    7871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7875:	48 8b 15 bc d2 01 00 	mov    0x1d2bc(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    787c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7880:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7884:	48 85 c9             	test   %rcx,%rcx
    7887:	74 bf                	je     7848 <fwp_caps173+0x8>
    7889:	0f b6 32             	movzbl (%rdx),%esi
    788c:	40 80 fe 02          	cmp    $0x2,%sil
    7890:	74 2e                	je     78c0 <fwp_caps173+0x80>
    7892:	40 80 fe 01          	cmp    $0x1,%sil
    7896:	75 b0                	jne    7848 <fwp_caps173+0x8>
    7898:	8b 72 18             	mov    0x18(%rdx),%esi
    789b:	0f b7 c0             	movzwl %ax,%eax
    789e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78a1:	48 0f af c6          	imul   %rsi,%rax
    78a5:	48 c1 e8 20          	shr    $0x20,%rax
    78a9:	48 39 d0             	cmp    %rdx,%rax
    78ac:	73 9a                	jae    7848 <fwp_caps173+0x8>
    78ae:	48 01 c1             	add    %rax,%rcx
    78b1:	80 39 01             	cmpb   $0x1,(%rcx)
    78b4:	75 92                	jne    7848 <fwp_caps173+0x8>
    78b6:	e9 55 dc ff ff       	jmp    5510 <fwp_mem_free>
    78bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78c0:	66 85 c0             	test   %ax,%ax
    78c3:	74 ec                	je     78b1 <fwp_caps173+0x71>
    78c5:	c3                   	ret
    78c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78cd:	00 00 00 

00000000000078d0 <fwp_args37>:
    78d0:	f3 0f 1e fa          	endbr64
    78d4:	85 d2                	test   %edx,%edx
    78d6:	74 04                	je     78dc <fwp_args37+0xc>
    78d8:	85 f6                	test   %esi,%esi
    78da:	74 04                	je     78e0 <fwp_args37+0x10>
    78dc:	c3                   	ret
    78dd:	0f 1f 00             	nopl   (%rax)
    78e0:	48 8b 15 31 d2 01 00 	mov    0x1d231(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    78e7:	48 8b 07             	mov    (%rdi),%rax
    78ea:	48 2b 05 ff d1 01 00 	sub    0x1d1ff(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    78f1:	48 c1 e2 10          	shl    $0x10,%rdx
    78f5:	48 39 d0             	cmp    %rdx,%rax
    78f8:	73 e2                	jae    78dc <fwp_args37+0xc>
    78fa:	48 89 c2             	mov    %rax,%rdx
    78fd:	48 c1 ea 10          	shr    $0x10,%rdx
    7901:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7905:	48 8b 15 2c d2 01 00 	mov    0x1d22c(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    790c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7910:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7914:	48 85 ff             	test   %rdi,%rdi
    7917:	74 c3                	je     78dc <fwp_args37+0xc>
    7919:	0f b6 0a             	movzbl (%rdx),%ecx
    791c:	80 f9 02             	cmp    $0x2,%cl
    791f:	74 2f                	je     7950 <fwp_args37+0x80>
    7921:	80 f9 01             	cmp    $0x1,%cl
    7924:	75 b6                	jne    78dc <fwp_args37+0xc>
    7926:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7929:	0f b7 c0             	movzwl %ax,%eax
    792c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    792f:	48 0f af c1          	imul   %rcx,%rax
    7933:	48 c1 e8 20          	shr    $0x20,%rax
    7937:	48 39 d0             	cmp    %rdx,%rax
    793a:	73 a0                	jae    78dc <fwp_args37+0xc>
    793c:	48 01 c7             	add    %rax,%rdi
    793f:	0f b6 07             	movzbl (%rdi),%eax
    7942:	84 c0                	test   %al,%al
    7944:	74 96                	je     78dc <fwp_args37+0xc>
    7946:	3c fd                	cmp    $0xfd,%al
    7948:	77 0c                	ja     7956 <fwp_args37+0x86>
    794a:	83 c0 01             	add    $0x1,%eax
    794d:	88 07                	mov    %al,(%rdi)
    794f:	c3                   	ret
    7950:	66 85 c0             	test   %ax,%ax
    7953:	74 ea                	je     793f <fwp_args37+0x6f>
    7955:	c3                   	ret
    7956:	e9 55 d8 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    795b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007960 <fwp_caps37>:
    7960:	f3 0f 1e fa          	endbr64
    7964:	48 83 ec 18          	sub    $0x18,%rsp
    7968:	8b 57 04             	mov    0x4(%rdi),%edx
    796b:	48 89 f8             	mov    %rdi,%rax
    796e:	85 d2                	test   %edx,%edx
    7970:	0f 84 9a 00 00 00    	je     7a10 <fwp_caps37+0xb0>
    7976:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    797a:	85 f6                	test   %esi,%esi
    797c:	0f 85 9e 00 00 00    	jne    7a20 <fwp_caps37+0xc0>
    7982:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7987:	e8 54 f7 ff ff       	call   70e0 <fwp_drop4>
    798c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7991:	48 8b 0d 80 d1 01 00 	mov    0x1d180(%rip),%rcx        # 24b18 <fwp_heap+0x13d8>
    7998:	48 89 c2             	mov    %rax,%rdx
    799b:	48 2b 15 4e d1 01 00 	sub    0x1d14e(%rip),%rdx        # 24af0 <fwp_heap+0x13b0>
    79a2:	48 c1 e1 10          	shl    $0x10,%rcx
    79a6:	48 39 ca             	cmp    %rcx,%rdx
    79a9:	73 6d                	jae    7a18 <fwp_caps37+0xb8>
    79ab:	48 89 d1             	mov    %rdx,%rcx
    79ae:	48 c1 e9 10          	shr    $0x10,%rcx
    79b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79b6:	48 8b 0d 7b d1 01 00 	mov    0x1d17b(%rip),%rcx        # 24b38 <fwp_heap+0x13f8>
    79bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    79c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    79c5:	48 85 f6             	test   %rsi,%rsi
    79c8:	74 4e                	je     7a18 <fwp_caps37+0xb8>
    79ca:	0f b6 39             	movzbl (%rcx),%edi
    79cd:	40 80 ff 02          	cmp    $0x2,%dil
    79d1:	0f 84 b9 00 00 00    	je     7a90 <fwp_caps37+0x130>
    79d7:	40 80 ff 01          	cmp    $0x1,%dil
    79db:	75 3b                	jne    7a18 <fwp_caps37+0xb8>
    79dd:	8b 79 18             	mov    0x18(%rcx),%edi
    79e0:	0f b7 d2             	movzwl %dx,%edx
    79e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79e6:	48 0f af d7          	imul   %rdi,%rdx
    79ea:	48 c1 ea 20          	shr    $0x20,%rdx
    79ee:	48 39 ca             	cmp    %rcx,%rdx
    79f1:	73 25                	jae    7a18 <fwp_caps37+0xb8>
    79f3:	48 01 d6             	add    %rdx,%rsi
    79f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    79f9:	75 1d                	jne    7a18 <fwp_caps37+0xb8>
    79fb:	48 89 c7             	mov    %rax,%rdi
    79fe:	48 83 c4 18          	add    $0x18,%rsp
    7a02:	e9 09 db ff ff       	jmp    5510 <fwp_mem_free>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	85 f6                	test   %esi,%esi
    7a12:	0f 84 79 ff ff ff    	je     7991 <fwp_caps37+0x31>
    7a18:	48 83 c4 18          	add    $0x18,%rsp
    7a1c:	c3                   	ret
    7a1d:	0f 1f 00             	nopl   (%rax)
    7a20:	48 8b 05 f1 d0 01 00 	mov    0x1d0f1(%rip),%rax        # 24b18 <fwp_heap+0x13d8>
    7a27:	48 2b 3d c2 d0 01 00 	sub    0x1d0c2(%rip),%rdi        # 24af0 <fwp_heap+0x13b0>
    7a2e:	48 c1 e0 10          	shl    $0x10,%rax
    7a32:	48 39 c7             	cmp    %rax,%rdi
    7a35:	73 e1                	jae    7a18 <fwp_caps37+0xb8>
    7a37:	48 89 f8             	mov    %rdi,%rax
    7a3a:	48 c1 e8 10          	shr    $0x10,%rax
    7a3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a42:	48 8b 05 ef d0 01 00 	mov    0x1d0ef(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    7a49:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a4d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a51:	48 85 c0             	test   %rax,%rax
    7a54:	74 c2                	je     7a18 <fwp_caps37+0xb8>
    7a56:	0f b6 0a             	movzbl (%rdx),%ecx
    7a59:	80 f9 02             	cmp    $0x2,%cl
    7a5c:	74 42                	je     7aa0 <fwp_caps37+0x140>
    7a5e:	80 f9 01             	cmp    $0x1,%cl
    7a61:	75 b5                	jne    7a18 <fwp_caps37+0xb8>
    7a63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a66:	0f b7 ff             	movzwl %di,%edi
    7a69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a6c:	48 0f af f9          	imul   %rcx,%rdi
    7a70:	48 c1 ef 20          	shr    $0x20,%rdi
    7a74:	48 39 d7             	cmp    %rdx,%rdi
    7a77:	73 9f                	jae    7a18 <fwp_caps37+0xb8>
    7a79:	48 01 f8             	add    %rdi,%rax
    7a7c:	0f b6 10             	movzbl (%rax),%edx
    7a7f:	84 d2                	test   %dl,%dl
    7a81:	74 95                	je     7a18 <fwp_caps37+0xb8>
    7a83:	80 fa fd             	cmp    $0xfd,%dl
    7a86:	77 23                	ja     7aab <fwp_caps37+0x14b>
    7a88:	83 c2 01             	add    $0x1,%edx
    7a8b:	88 10                	mov    %dl,(%rax)
    7a8d:	eb 89                	jmp    7a18 <fwp_caps37+0xb8>
    7a8f:	90                   	nop
    7a90:	66 85 d2             	test   %dx,%dx
    7a93:	0f 85 7f ff ff ff    	jne    7a18 <fwp_caps37+0xb8>
    7a99:	e9 58 ff ff ff       	jmp    79f6 <fwp_caps37+0x96>
    7a9e:	66 90                	xchg   %ax,%ax
    7aa0:	66 85 ff             	test   %di,%di
    7aa3:	0f 85 6f ff ff ff    	jne    7a18 <fwp_caps37+0xb8>
    7aa9:	eb d1                	jmp    7a7c <fwp_caps37+0x11c>
    7aab:	48 89 c7             	mov    %rax,%rdi
    7aae:	48 83 c4 18          	add    $0x18,%rsp
    7ab2:	e9 f9 d6 ff ff       	jmp    51b0 <fwp_rc_wide_dup>
    7ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7abe:	00 00 

0000000000007ac0 <fwp_drop0>:
    7ac0:	f3 0f 1e fa          	endbr64
    7ac4:	48 8b 15 4d d0 01 00 	mov    0x1d04d(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    7acb:	48 89 f8             	mov    %rdi,%rax
    7ace:	48 2b 05 1b d0 01 00 	sub    0x1d01b(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    7ad5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ad9:	48 39 d0             	cmp    %rdx,%rax
    7adc:	0f 83 36 01 00 00    	jae    7c18 <fwp_drop0+0x158>
    7ae2:	48 83 ec 18          	sub    $0x18,%rsp
    7ae6:	48 8d 35 53 bc 01 00 	lea    0x1bc53(%rip),%rsi        # 23740 <fwp_heap>
    7aed:	48 89 c2             	mov    %rax,%rdx
    7af0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7af7:	48 c1 ea 10          	shr    $0x10,%rdx
    7afb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7aff:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b03:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b07:	48 85 d2             	test   %rdx,%rdx
    7b0a:	74 42                	je     7b4e <fwp_drop0+0x8e>
    7b0c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b10:	41 80 f8 02          	cmp    $0x2,%r8b
    7b14:	74 42                	je     7b58 <fwp_drop0+0x98>
    7b16:	41 80 f8 01          	cmp    $0x1,%r8b
    7b1a:	75 32                	jne    7b4e <fwp_drop0+0x8e>
    7b1c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b20:	0f b7 c0             	movzwl %ax,%eax
    7b23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b26:	49 0f af c0          	imul   %r8,%rax
    7b2a:	48 c1 e8 20          	shr    $0x20,%rax
    7b2e:	48 39 c8             	cmp    %rcx,%rax
    7b31:	73 1b                	jae    7b4e <fwp_drop0+0x8e>
    7b33:	48 01 c2             	add    %rax,%rdx
    7b36:	0f b6 02             	movzbl (%rdx),%eax
    7b39:	84 c0                	test   %al,%al
    7b3b:	74 11                	je     7b4e <fwp_drop0+0x8e>
    7b3d:	3c 01                	cmp    $0x1,%al
    7b3f:	74 27                	je     7b68 <fwp_drop0+0xa8>
    7b41:	3c ff                	cmp    $0xff,%al
    7b43:	0f 84 e7 00 00 00    	je     7c30 <fwp_drop0+0x170>
    7b49:	83 e8 01             	sub    $0x1,%eax
    7b4c:	88 02                	mov    %al,(%rdx)
    7b4e:	48 83 c4 18          	add    $0x18,%rsp
    7b52:	c3                   	ret
    7b53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b58:	66 85 c0             	test   %ax,%ax
    7b5b:	74 d9                	je     7b36 <fwp_drop0+0x76>
    7b5d:	48 83 c4 18          	add    $0x18,%rsp
    7b61:	c3                   	ret
    7b62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b68:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b6f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b76:	48 89 f8             	mov    %rdi,%rax
    7b79:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b7d:	48 29 c8             	sub    %rcx,%rax
    7b80:	48 c1 e2 10          	shl    $0x10,%rdx
    7b84:	48 39 d0             	cmp    %rdx,%rax
    7b87:	73 71                	jae    7bfa <fwp_drop0+0x13a>
    7b89:	49 89 c2             	mov    %rax,%r10
    7b8c:	49 c1 ea 10          	shr    $0x10,%r10
    7b90:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b94:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7b98:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7b9c:	4d 85 d2             	test   %r10,%r10
    7b9f:	74 59                	je     7bfa <fwp_drop0+0x13a>
    7ba1:	45 0f b6 19          	movzbl (%r9),%r11d
    7ba5:	41 80 fb 02          	cmp    $0x2,%r11b
    7ba9:	74 75                	je     7c20 <fwp_drop0+0x160>
    7bab:	41 80 fb 01          	cmp    $0x1,%r11b
    7baf:	75 49                	jne    7bfa <fwp_drop0+0x13a>
    7bb1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7bb5:	0f b7 c0             	movzwl %ax,%eax
    7bb8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7bbc:	49 0f af c3          	imul   %r11,%rax
    7bc0:	48 c1 e8 20          	shr    $0x20,%rax
    7bc4:	4c 39 c8             	cmp    %r9,%rax
    7bc7:	73 31                	jae    7bfa <fwp_drop0+0x13a>
    7bc9:	49 01 c2             	add    %rax,%r10
    7bcc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7bd0:	75 28                	jne    7bfa <fwp_drop0+0x13a>
    7bd2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7bd7:	e8 34 d9 ff ff       	call   5510 <fwp_mem_free>
    7bdc:	48 8d 35 5d bb 01 00 	lea    0x1bb5d(%rip),%rsi        # 23740 <fwp_heap>
    7be3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7be8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7bef:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7bf6:	48 c1 e2 10          	shl    $0x10,%rdx
    7bfa:	4c 89 c0             	mov    %r8,%rax
    7bfd:	48 29 c8             	sub    %rcx,%rax
    7c00:	48 39 d0             	cmp    %rdx,%rax
    7c03:	0f 83 45 ff ff ff    	jae    7b4e <fwp_drop0+0x8e>
    7c09:	4c 89 c7             	mov    %r8,%rdi
    7c0c:	e9 dc fe ff ff       	jmp    7aed <fwp_drop0+0x2d>
    7c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c18:	c3                   	ret
    7c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c20:	66 85 c0             	test   %ax,%ax
    7c23:	75 d5                	jne    7bfa <fwp_drop0+0x13a>
    7c25:	eb a5                	jmp    7bcc <fwp_drop0+0x10c>
    7c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c2e:	00 00 
    7c30:	48 89 d0             	mov    %rdx,%rax
    7c33:	48 c1 e8 11          	shr    $0x11,%rax
    7c37:	48 31 d0             	xor    %rdx,%rax
    7c3a:	48 89 c1             	mov    %rax,%rcx
    7c3d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c41:	48 31 c8             	xor    %rcx,%rax
    7c44:	0f b6 c8             	movzbl %al,%ecx
    7c47:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c4e:	00 
    7c4f:	48 85 c0             	test   %rax,%rax
    7c52:	75 15                	jne    7c69 <fwp_drop0+0x1a9>
    7c54:	eb 4e                	jmp    7ca4 <fwp_drop0+0x1e4>
    7c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c5d:	00 00 00 
    7c60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c64:	48 85 c0             	test   %rax,%rax
    7c67:	74 3b                	je     7ca4 <fwp_drop0+0x1e4>
    7c69:	48 89 c1             	mov    %rax,%rcx
    7c6c:	48 39 10             	cmp    %rdx,(%rax)
    7c6f:	75 ef                	jne    7c60 <fwp_drop0+0x1a0>
    7c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c84:	0f 85 c4 fe ff ff    	jne    7b4e <fwp_drop0+0x8e>
    7c8a:	48 89 d7             	mov    %rdx,%rdi
    7c8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c92:	e8 39 d6 ff ff       	call   52d0 <fwp_rc_forget_slot>
    7c97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c9f:	e9 aa fe ff ff       	jmp    7b4e <fwp_drop0+0x8e>
    7ca4:	48 8d 3d f5 7a 00 00 	lea    0x7af5(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7cab:	e8 b0 c4 ff ff       	call   4160 <fwp_trap>

0000000000007cb0 <fwp_drop1>:
    7cb0:	f3 0f 1e fa          	endbr64
    7cb4:	48 8b 15 5d ce 01 00 	mov    0x1ce5d(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    7cbb:	48 89 f8             	mov    %rdi,%rax
    7cbe:	48 2b 05 2b ce 01 00 	sub    0x1ce2b(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    7cc5:	48 c1 e2 10          	shl    $0x10,%rdx
    7cc9:	48 39 d0             	cmp    %rdx,%rax
    7ccc:	0f 83 36 01 00 00    	jae    7e08 <fwp_drop1+0x158>
    7cd2:	48 83 ec 18          	sub    $0x18,%rsp
    7cd6:	48 8d 35 63 ba 01 00 	lea    0x1ba63(%rip),%rsi        # 23740 <fwp_heap>
    7cdd:	48 89 c2             	mov    %rax,%rdx
    7ce0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7ce7:	48 c1 ea 10          	shr    $0x10,%rdx
    7ceb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7cef:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7cf3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7cf7:	48 85 d2             	test   %rdx,%rdx
    7cfa:	74 42                	je     7d3e <fwp_drop1+0x8e>
    7cfc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d00:	41 80 f8 02          	cmp    $0x2,%r8b
    7d04:	74 42                	je     7d48 <fwp_drop1+0x98>
    7d06:	41 80 f8 01          	cmp    $0x1,%r8b
    7d0a:	75 32                	jne    7d3e <fwp_drop1+0x8e>
    7d0c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d10:	0f b7 c0             	movzwl %ax,%eax
    7d13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d16:	49 0f af c0          	imul   %r8,%rax
    7d1a:	48 c1 e8 20          	shr    $0x20,%rax
    7d1e:	48 39 c8             	cmp    %rcx,%rax
    7d21:	73 1b                	jae    7d3e <fwp_drop1+0x8e>
    7d23:	48 01 c2             	add    %rax,%rdx
    7d26:	0f b6 02             	movzbl (%rdx),%eax
    7d29:	84 c0                	test   %al,%al
    7d2b:	74 11                	je     7d3e <fwp_drop1+0x8e>
    7d2d:	3c 01                	cmp    $0x1,%al
    7d2f:	74 27                	je     7d58 <fwp_drop1+0xa8>
    7d31:	3c ff                	cmp    $0xff,%al
    7d33:	0f 84 e7 00 00 00    	je     7e20 <fwp_drop1+0x170>
    7d39:	83 e8 01             	sub    $0x1,%eax
    7d3c:	88 02                	mov    %al,(%rdx)
    7d3e:	48 83 c4 18          	add    $0x18,%rsp
    7d42:	c3                   	ret
    7d43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d48:	66 85 c0             	test   %ax,%ax
    7d4b:	74 d9                	je     7d26 <fwp_drop1+0x76>
    7d4d:	48 83 c4 18          	add    $0x18,%rsp
    7d51:	c3                   	ret
    7d52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d58:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d5f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d66:	48 89 f8             	mov    %rdi,%rax
    7d69:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d6d:	48 29 c8             	sub    %rcx,%rax
    7d70:	48 c1 e2 10          	shl    $0x10,%rdx
    7d74:	48 39 d0             	cmp    %rdx,%rax
    7d77:	73 71                	jae    7dea <fwp_drop1+0x13a>
    7d79:	49 89 c2             	mov    %rax,%r10
    7d7c:	49 c1 ea 10          	shr    $0x10,%r10
    7d80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d84:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d88:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d8c:	4d 85 d2             	test   %r10,%r10
    7d8f:	74 59                	je     7dea <fwp_drop1+0x13a>
    7d91:	45 0f b6 19          	movzbl (%r9),%r11d
    7d95:	41 80 fb 02          	cmp    $0x2,%r11b
    7d99:	74 75                	je     7e10 <fwp_drop1+0x160>
    7d9b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d9f:	75 49                	jne    7dea <fwp_drop1+0x13a>
    7da1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7da5:	0f b7 c0             	movzwl %ax,%eax
    7da8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dac:	49 0f af c3          	imul   %r11,%rax
    7db0:	48 c1 e8 20          	shr    $0x20,%rax
    7db4:	4c 39 c8             	cmp    %r9,%rax
    7db7:	73 31                	jae    7dea <fwp_drop1+0x13a>
    7db9:	49 01 c2             	add    %rax,%r10
    7dbc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7dc0:	75 28                	jne    7dea <fwp_drop1+0x13a>
    7dc2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7dc7:	e8 44 d7 ff ff       	call   5510 <fwp_mem_free>
    7dcc:	48 8d 35 6d b9 01 00 	lea    0x1b96d(%rip),%rsi        # 23740 <fwp_heap>
    7dd3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7dd8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ddf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7de6:	48 c1 e2 10          	shl    $0x10,%rdx
    7dea:	4c 89 c0             	mov    %r8,%rax
    7ded:	48 29 c8             	sub    %rcx,%rax
    7df0:	48 39 d0             	cmp    %rdx,%rax
    7df3:	0f 83 45 ff ff ff    	jae    7d3e <fwp_drop1+0x8e>
    7df9:	4c 89 c7             	mov    %r8,%rdi
    7dfc:	e9 dc fe ff ff       	jmp    7cdd <fwp_drop1+0x2d>
    7e01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e08:	c3                   	ret
    7e09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e10:	66 85 c0             	test   %ax,%ax
    7e13:	75 d5                	jne    7dea <fwp_drop1+0x13a>
    7e15:	eb a5                	jmp    7dbc <fwp_drop1+0x10c>
    7e17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e1e:	00 00 
    7e20:	48 89 d0             	mov    %rdx,%rax
    7e23:	48 c1 e8 11          	shr    $0x11,%rax
    7e27:	48 31 d0             	xor    %rdx,%rax
    7e2a:	48 89 c1             	mov    %rax,%rcx
    7e2d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e31:	48 31 c8             	xor    %rcx,%rax
    7e34:	0f b6 c8             	movzbl %al,%ecx
    7e37:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e3e:	00 
    7e3f:	48 85 c0             	test   %rax,%rax
    7e42:	75 25                	jne    7e69 <fwp_drop1+0x1b9>
    7e44:	eb 5e                	jmp    7ea4 <fwp_drop1+0x1f4>
    7e46:	0f 1f 40 00          	nopl   0x0(%rax)
    7e4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e51:	00 00 00 00 
    7e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 00 
    7e60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e64:	48 85 c0             	test   %rax,%rax
    7e67:	74 3b                	je     7ea4 <fwp_drop1+0x1f4>
    7e69:	48 89 c1             	mov    %rax,%rcx
    7e6c:	48 39 10             	cmp    %rdx,(%rax)
    7e6f:	75 ef                	jne    7e60 <fwp_drop1+0x1b0>
    7e71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e84:	0f 85 b4 fe ff ff    	jne    7d3e <fwp_drop1+0x8e>
    7e8a:	48 89 d7             	mov    %rdx,%rdi
    7e8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e92:	e8 39 d4 ff ff       	call   52d0 <fwp_rc_forget_slot>
    7e97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e9f:	e9 9a fe ff ff       	jmp    7d3e <fwp_drop1+0x8e>
    7ea4:	48 8d 3d f5 78 00 00 	lea    0x78f5(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7eab:	e8 b0 c2 ff ff       	call   4160 <fwp_trap>

0000000000007eb0 <fwp_drop10>:
    7eb0:	48 8b 0d 61 cc 01 00 	mov    0x1cc61(%rip),%rcx        # 24b18 <fwp_heap+0x13d8>
    7eb7:	48 89 f8             	mov    %rdi,%rax
    7eba:	48 2b 05 2f cc 01 00 	sub    0x1cc2f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    7ec1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ec5:	48 39 c8             	cmp    %rcx,%rax
    7ec8:	0f 83 c2 01 00 00    	jae    8090 <fwp_drop10+0x1e0>
    7ece:	48 83 ec 18          	sub    $0x18,%rsp
    7ed2:	48 89 fa             	mov    %rdi,%rdx
    7ed5:	48 8d 35 64 b8 01 00 	lea    0x1b864(%rip),%rsi        # 23740 <fwp_heap>
    7edc:	48 89 c1             	mov    %rax,%rcx
    7edf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7ee6:	48 c1 e9 10          	shr    $0x10,%rcx
    7eea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7eee:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7ef2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7ef6:	48 85 c9             	test   %rcx,%rcx
    7ef9:	74 46                	je     7f41 <fwp_drop10+0x91>
    7efb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7eff:	41 80 f9 02          	cmp    $0x2,%r9b
    7f03:	0f 84 d7 00 00 00    	je     7fe0 <fwp_drop10+0x130>
    7f09:	41 80 f9 01          	cmp    $0x1,%r9b
    7f0d:	75 32                	jne    7f41 <fwp_drop10+0x91>
    7f0f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7f13:	0f b7 c0             	movzwl %ax,%eax
    7f16:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7f19:	49 0f af c1          	imul   %r9,%rax
    7f1d:	48 c1 e8 20          	shr    $0x20,%rax
    7f21:	48 39 f8             	cmp    %rdi,%rax
    7f24:	73 1b                	jae    7f41 <fwp_drop10+0x91>
    7f26:	48 01 c1             	add    %rax,%rcx
    7f29:	0f b6 01             	movzbl (%rcx),%eax
    7f2c:	84 c0                	test   %al,%al
    7f2e:	74 11                	je     7f41 <fwp_drop10+0x91>
    7f30:	3c 01                	cmp    $0x1,%al
    7f32:	74 1c                	je     7f50 <fwp_drop10+0xa0>
    7f34:	3c ff                	cmp    $0xff,%al
    7f36:	0f 84 5c 01 00 00    	je     8098 <fwp_drop10+0x1e8>
    7f3c:	83 e8 01             	sub    $0x1,%eax
    7f3f:	88 01                	mov    %al,(%rcx)
    7f41:	48 83 c4 18          	add    $0x18,%rsp
    7f45:	c3                   	ret
    7f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f4d:	00 00 00 
    7f50:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7f57:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7f5e:	48 89 d0             	mov    %rdx,%rax
    7f61:	49 89 d1             	mov    %rdx,%r9
    7f64:	48 c1 e1 10          	shl    $0x10,%rcx
    7f68:	48 29 f8             	sub    %rdi,%rax
    7f6b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7f6f:	78 7f                	js     7ff0 <fwp_drop10+0x140>
    7f71:	48 39 c8             	cmp    %rcx,%rax
    7f74:	73 cb                	jae    7f41 <fwp_drop10+0x91>
    7f76:	48 89 c1             	mov    %rax,%rcx
    7f79:	48 c1 e9 10          	shr    $0x10,%rcx
    7f7d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f81:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7f85:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f89:	48 85 f6             	test   %rsi,%rsi
    7f8c:	74 b3                	je     7f41 <fwp_drop10+0x91>
    7f8e:	0f b6 39             	movzbl (%rcx),%edi
    7f91:	40 80 ff 02          	cmp    $0x2,%dil
    7f95:	74 39                	je     7fd0 <fwp_drop10+0x120>
    7f97:	40 80 ff 01          	cmp    $0x1,%dil
    7f9b:	75 a4                	jne    7f41 <fwp_drop10+0x91>
    7f9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7fa0:	0f b7 c0             	movzwl %ax,%eax
    7fa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fa6:	48 0f af c7          	imul   %rdi,%rax
    7faa:	48 c1 e8 20          	shr    $0x20,%rax
    7fae:	48 39 c8             	cmp    %rcx,%rax
    7fb1:	73 8e                	jae    7f41 <fwp_drop10+0x91>
    7fb3:	48 01 c6             	add    %rax,%rsi
    7fb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7fb9:	75 86                	jne    7f41 <fwp_drop10+0x91>
    7fbb:	48 89 d7             	mov    %rdx,%rdi
    7fbe:	48 83 c4 18          	add    $0x18,%rsp
    7fc2:	e9 49 d5 ff ff       	jmp    5510 <fwp_mem_free>
    7fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fce:	00 00 
    7fd0:	66 85 c0             	test   %ax,%ax
    7fd3:	74 e1                	je     7fb6 <fwp_drop10+0x106>
    7fd5:	48 83 c4 18          	add    $0x18,%rsp
    7fd9:	c3                   	ret
    7fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7fe0:	66 85 c0             	test   %ax,%ax
    7fe3:	0f 84 40 ff ff ff    	je     7f29 <fwp_drop10+0x79>
    7fe9:	48 83 c4 18          	add    $0x18,%rsp
    7fed:	c3                   	ret
    7fee:	66 90                	xchg   %ax,%ax
    7ff0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7ff4:	48 39 c8             	cmp    %rcx,%rax
    7ff7:	73 74                	jae    806d <fwp_drop10+0x1bd>
    7ff9:	49 89 c2             	mov    %rax,%r10
    7ffc:	49 c1 ea 10          	shr    $0x10,%r10
    8000:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8004:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8008:	4d 8b 50 20          	mov    0x20(%r8),%r10
    800c:	4d 85 d2             	test   %r10,%r10
    800f:	74 5c                	je     806d <fwp_drop10+0x1bd>
    8011:	45 0f b6 18          	movzbl (%r8),%r11d
    8015:	41 80 fb 02          	cmp    $0x2,%r11b
    8019:	74 6d                	je     8088 <fwp_drop10+0x1d8>
    801b:	41 80 fb 01          	cmp    $0x1,%r11b
    801f:	75 4c                	jne    806d <fwp_drop10+0x1bd>
    8021:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8025:	0f b7 c0             	movzwl %ax,%eax
    8028:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    802c:	49 0f af c3          	imul   %r11,%rax
    8030:	48 c1 e8 20          	shr    $0x20,%rax
    8034:	4c 39 c0             	cmp    %r8,%rax
    8037:	73 34                	jae    806d <fwp_drop10+0x1bd>
    8039:	49 01 c2             	add    %rax,%r10
    803c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8040:	75 2b                	jne    806d <fwp_drop10+0x1bd>
    8042:	4c 89 cf             	mov    %r9,%rdi
    8045:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    804a:	e8 c1 d4 ff ff       	call   5510 <fwp_mem_free>
    804f:	48 8d 35 ea b6 01 00 	lea    0x1b6ea(%rip),%rsi        # 23740 <fwp_heap>
    8056:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    805b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8062:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8069:	48 c1 e1 10          	shl    $0x10,%rcx
    806d:	48 89 d0             	mov    %rdx,%rax
    8070:	48 29 f8             	sub    %rdi,%rax
    8073:	48 39 c8             	cmp    %rcx,%rax
    8076:	0f 82 60 fe ff ff    	jb     7edc <fwp_drop10+0x2c>
    807c:	e9 c0 fe ff ff       	jmp    7f41 <fwp_drop10+0x91>
    8081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8088:	66 85 c0             	test   %ax,%ax
    808b:	75 e0                	jne    806d <fwp_drop10+0x1bd>
    808d:	eb ad                	jmp    803c <fwp_drop10+0x18c>
    808f:	90                   	nop
    8090:	c3                   	ret
    8091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8098:	48 89 c8             	mov    %rcx,%rax
    809b:	48 c1 e8 11          	shr    $0x11,%rax
    809f:	48 31 c8             	xor    %rcx,%rax
    80a2:	48 89 c2             	mov    %rax,%rdx
    80a5:	48 c1 ea 09          	shr    $0x9,%rdx
    80a9:	48 31 d0             	xor    %rdx,%rax
    80ac:	0f b6 d0             	movzbl %al,%edx
    80af:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    80b6:	00 
    80b7:	48 85 c0             	test   %rax,%rax
    80ba:	75 0d                	jne    80c9 <fwp_drop10+0x219>
    80bc:	eb 46                	jmp    8104 <fwp_drop10+0x254>
    80be:	66 90                	xchg   %ax,%ax
    80c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    80c4:	48 85 c0             	test   %rax,%rax
    80c7:	74 3b                	je     8104 <fwp_drop10+0x254>
    80c9:	48 89 c2             	mov    %rax,%rdx
    80cc:	48 39 08             	cmp    %rcx,(%rax)
    80cf:	75 ef                	jne    80c0 <fwp_drop10+0x210>
    80d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    80d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    80dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    80e4:	0f 85 57 fe ff ff    	jne    7f41 <fwp_drop10+0x91>
    80ea:	48 89 cf             	mov    %rcx,%rdi
    80ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    80f2:	e8 d9 d1 ff ff       	call   52d0 <fwp_rc_forget_slot>
    80f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    80fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    80ff:	e9 3d fe ff ff       	jmp    7f41 <fwp_drop10+0x91>
    8104:	48 8d 3d 95 76 00 00 	lea    0x7695(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    810b:	e8 50 c0 ff ff       	call   4160 <fwp_trap>

0000000000008110 <f37>:
    8110:	41 57                	push   %r15
    8112:	41 56                	push   %r14
    8114:	41 55                	push   %r13
    8116:	41 54                	push   %r12
    8118:	55                   	push   %rbp
    8119:	53                   	push   %rbx
    811a:	48 83 ec 48          	sub    $0x48,%rsp
    811e:	48 8b 15 f3 c9 01 00 	mov    0x1c9f3(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    8125:	48 89 3c 24          	mov    %rdi,(%rsp)
    8129:	48 c1 e2 10          	shl    $0x10,%rdx
    812d:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8134:	00 00 
    8136:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    813b:	48 8b 0d ae c9 01 00 	mov    0x1c9ae(%rip),%rcx        # 24af0 <fwp_heap+0x13b0>
    8142:	48 85 ff             	test   %rdi,%rdi
    8145:	0f 84 e3 02 00 00    	je     842e <f37+0x31e>
    814b:	48 8b 04 24          	mov    (%rsp),%rax
    814f:	48 8b 58 10          	mov    0x10(%rax),%rbx
    8153:	48 89 d8             	mov    %rbx,%rax
    8156:	48 29 c8             	sub    %rcx,%rax
    8159:	48 39 d0             	cmp    %rdx,%rax
    815c:	0f 83 8e 03 00 00    	jae    84f0 <f37+0x3e0>
    8162:	48 89 c2             	mov    %rax,%rdx
    8165:	48 c1 ea 10          	shr    $0x10,%rdx
    8169:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    816d:	48 8b 15 c4 c9 01 00 	mov    0x1c9c4(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    8174:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8178:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    817c:	48 85 ff             	test   %rdi,%rdi
    817f:	0f 84 6b 03 00 00    	je     84f0 <f37+0x3e0>
    8185:	0f b6 0a             	movzbl (%rdx),%ecx
    8188:	80 f9 02             	cmp    $0x2,%cl
    818b:	0f 84 77 02 00 00    	je     8408 <f37+0x2f8>
    8191:	80 f9 01             	cmp    $0x1,%cl
    8194:	75 24                	jne    81ba <f37+0xaa>
    8196:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8199:	0f b7 c0             	movzwl %ax,%eax
    819c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    819f:	48 0f af c1          	imul   %rcx,%rax
    81a3:	48 c1 e8 20          	shr    $0x20,%rax
    81a7:	48 39 d0             	cmp    %rdx,%rax
    81aa:	73 0e                	jae    81ba <f37+0xaa>
    81ac:	48 01 c7             	add    %rax,%rdi
    81af:	0f b6 07             	movzbl (%rdi),%eax
    81b2:	84 c0                	test   %al,%al
    81b4:	0f 85 e6 02 00 00    	jne    84a0 <f37+0x390>
    81ba:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    81bf:	48 8b 04 24          	mov    (%rsp),%rax
    81c3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    81c7:	ba 01 00 00 00       	mov    $0x1,%edx
    81cc:	48 85 db             	test   %rbx,%rbx
    81cf:	74 1c                	je     81ed <f37+0xdd>
    81d1:	0f 1f 40 00          	nopl   0x0(%rax)
    81d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81dc:	00 00 00 00 
    81e0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    81e4:	48 83 c2 01          	add    $0x1,%rdx
    81e8:	48 85 db             	test   %rbx,%rbx
    81eb:	75 f3                	jne    81e0 <f37+0xd0>
    81ed:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81f2:	48 85 c0             	test   %rax,%rax
    81f5:	0f 84 25 03 00 00    	je     8520 <f37+0x410>
    81fb:	31 db                	xor    %ebx,%ebx
    81fd:	0f 1f 00             	nopl   (%rax)
    8200:	48 8b 40 10          	mov    0x10(%rax),%rax
    8204:	48 83 c3 01          	add    $0x1,%rbx
    8208:	48 85 c0             	test   %rax,%rax
    820b:	75 f3                	jne    8200 <f37+0xf0>
    820d:	48 39 d3             	cmp    %rdx,%rbx
    8210:	48 0f 47 da          	cmova  %rdx,%rbx
    8214:	48 89 d8             	mov    %rbx,%rax
    8217:	48 c1 e8 3c          	shr    $0x3c,%rax
    821b:	0f 85 9f 03 00 00    	jne    85c0 <f37+0x4b0>
    8221:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8225:	be 02 00 00 00       	mov    $0x2,%esi
    822a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8231:	00 
    8232:	e8 d9 d7 ff ff       	call   5a10 <fwp_heap_alloc>
    8237:	48 89 28             	mov    %rbp,(%rax)
    823a:	48 8b 15 d7 c8 01 00 	mov    0x1c8d7(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    8241:	49 89 c5             	mov    %rax,%r13
    8244:	48 2b 05 a5 c8 01 00 	sub    0x1c8a5(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    824b:	48 c1 e2 10          	shl    $0x10,%rdx
    824f:	48 39 d0             	cmp    %rdx,%rax
    8252:	73 57                	jae    82ab <f37+0x19b>
    8254:	48 89 c2             	mov    %rax,%rdx
    8257:	48 c1 ea 10          	shr    $0x10,%rdx
    825b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    825f:	48 8b 15 d2 c8 01 00 	mov    0x1c8d2(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    8266:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    826a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    826e:	48 85 ed             	test   %rbp,%rbp
    8271:	74 38                	je     82ab <f37+0x19b>
    8273:	0f b6 0a             	movzbl (%rdx),%ecx
    8276:	80 f9 02             	cmp    $0x2,%cl
    8279:	0f 84 61 02 00 00    	je     84e0 <f37+0x3d0>
    827f:	80 f9 01             	cmp    $0x1,%cl
    8282:	75 27                	jne    82ab <f37+0x19b>
    8284:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8287:	0f b7 c0             	movzwl %ax,%eax
    828a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    828d:	48 0f af c1          	imul   %rcx,%rax
    8291:	48 c1 e8 20          	shr    $0x20,%rax
    8295:	48 39 d0             	cmp    %rdx,%rax
    8298:	73 11                	jae    82ab <f37+0x19b>
    829a:	48 01 c5             	add    %rax,%rbp
    829d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    82a1:	0f 84 e5 02 00 00    	je     858c <f37+0x47c>
    82a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    82ab:	48 85 db             	test   %rbx,%rbx
    82ae:	74 74                	je     8324 <f37+0x214>
    82b0:	48 c1 e3 04          	shl    $0x4,%rbx
    82b4:	4c 8b 34 24          	mov    (%rsp),%r14
    82b8:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    82bd:	4c 89 ed             	mov    %r13,%rbp
    82c0:	4c 01 eb             	add    %r13,%rbx
    82c3:	66 90                	xchg   %ax,%ax
    82c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82cc:	00 00 00 00 
    82d0:	49 8b 46 08          	mov    0x8(%r14),%rax
    82d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    82d8:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    82dd:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    82e4:	ff ff 
    82e6:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    82ed:	00 00 
    82ef:	48 83 c5 10          	add    $0x10,%rbp
    82f3:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    82f8:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    82fc:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8300:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    8305:	e8 26 dd ff ff       	call   6030 <w120>
    830a:	66 48 0f 6e d0       	movq   %rax,%xmm2
    830f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8313:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8317:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    831b:	4d 8b 76 10          	mov    0x10(%r14),%r14
    831f:	48 39 dd             	cmp    %rbx,%rbp
    8322:	75 ac                	jne    82d0 <f37+0x1c0>
    8324:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8329:	e8 b2 ed ff ff       	call   70e0 <fwp_drop4>
    832e:	48 8b 3c 24          	mov    (%rsp),%rdi
    8332:	e8 a9 ed ff ff       	call   70e0 <fwp_drop4>
    8337:	4c 89 ef             	mov    %r13,%rdi
    833a:	e8 41 e4 ff ff       	call   6780 <w176.constprop.0>
    833f:	4c 89 ef             	mov    %r13,%rdi
    8342:	48 89 c3             	mov    %rax,%rbx
    8345:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    834a:	e8 61 fb ff ff       	call   7eb0 <fwp_drop10>
    834f:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    8354:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8359:	31 ff                	xor    %edi,%edi
    835b:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    8360:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8364:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    8369:	e8 c2 d7 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    836e:	48 8b 15 a3 c7 01 00 	mov    0x1c7a3(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    8375:	48 89 c5             	mov    %rax,%rbp
    8378:	48 2b 05 71 c7 01 00 	sub    0x1c771(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    837f:	48 c1 e2 10          	shl    $0x10,%rdx
    8383:	48 39 d0             	cmp    %rdx,%rax
    8386:	73 55                	jae    83dd <f37+0x2cd>
    8388:	48 89 c2             	mov    %rax,%rdx
    838b:	48 c1 ea 10          	shr    $0x10,%rdx
    838f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8393:	48 8b 15 9e c7 01 00 	mov    0x1c79e(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    839a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    839e:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    83a2:	48 85 db             	test   %rbx,%rbx
    83a5:	74 36                	je     83dd <f37+0x2cd>
    83a7:	0f b6 0a             	movzbl (%rdx),%ecx
    83aa:	80 f9 02             	cmp    $0x2,%cl
    83ad:	0f 84 15 01 00 00    	je     84c8 <f37+0x3b8>
    83b3:	80 f9 01             	cmp    $0x1,%cl
    83b6:	75 25                	jne    83dd <f37+0x2cd>
    83b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83bb:	0f b7 c0             	movzwl %ax,%eax
    83be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83c1:	48 0f af c1          	imul   %rcx,%rax
    83c5:	48 c1 e8 20          	shr    $0x20,%rax
    83c9:	48 39 d0             	cmp    %rdx,%rax
    83cc:	73 0f                	jae    83dd <f37+0x2cd>
    83ce:	48 01 c3             	add    %rax,%rbx
    83d1:	80 3b ff             	cmpb   $0xff,(%rbx)
    83d4:	0f 84 a5 01 00 00    	je     857f <f37+0x46f>
    83da:	c6 03 01             	movb   $0x1,(%rbx)
    83dd:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    83e2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83e9:	00 00 
    83eb:	0f 85 ca 01 00 00    	jne    85bb <f37+0x4ab>
    83f1:	48 83 c4 48          	add    $0x48,%rsp
    83f5:	48 89 e8             	mov    %rbp,%rax
    83f8:	5b                   	pop    %rbx
    83f9:	5d                   	pop    %rbp
    83fa:	41 5c                	pop    %r12
    83fc:	41 5d                	pop    %r13
    83fe:	41 5e                	pop    %r14
    8400:	41 5f                	pop    %r15
    8402:	c3                   	ret
    8403:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8408:	66 85 c0             	test   %ax,%ax
    840b:	0f 85 a9 fd ff ff    	jne    81ba <f37+0xaa>
    8411:	0f b6 07             	movzbl (%rdi),%eax
    8414:	84 c0                	test   %al,%al
    8416:	0f 84 9e fd ff ff    	je     81ba <f37+0xaa>
    841c:	3c fd                	cmp    $0xfd,%al
    841e:	0f 87 8d 01 00 00    	ja     85b1 <f37+0x4a1>
    8424:	83 c0 01             	add    $0x1,%eax
    8427:	88 07                	mov    %al,(%rdi)
    8429:	e9 8c fd ff ff       	jmp    81ba <f37+0xaa>
    842e:	48 f7 d9             	neg    %rcx
    8431:	48 39 d1             	cmp    %rdx,%rcx
    8434:	0f 83 e6 00 00 00    	jae    8520 <f37+0x410>
    843a:	48 89 c8             	mov    %rcx,%rax
    843d:	48 c1 e8 10          	shr    $0x10,%rax
    8441:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8445:	48 8b 05 ec c6 01 00 	mov    0x1c6ec(%rip),%rax        # 24b38 <fwp_heap+0x13f8>
    844c:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8450:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8454:	48 85 ff             	test   %rdi,%rdi
    8457:	0f 84 c3 00 00 00    	je     8520 <f37+0x410>
    845d:	0f b6 02             	movzbl (%rdx),%eax
    8460:	3c 02                	cmp    $0x2,%al
    8462:	0f 84 92 00 00 00    	je     84fa <f37+0x3ea>
    8468:	3c 01                	cmp    $0x1,%al
    846a:	0f 85 b0 00 00 00    	jne    8520 <f37+0x410>
    8470:	0f b7 c1             	movzwl %cx,%eax
    8473:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8476:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8479:	48 0f af c1          	imul   %rcx,%rax
    847d:	48 c1 e8 20          	shr    $0x20,%rax
    8481:	48 39 d0             	cmp    %rdx,%rax
    8484:	0f 83 96 00 00 00    	jae    8520 <f37+0x410>
    848a:	48 01 c7             	add    %rax,%rdi
    848d:	0f b6 07             	movzbl (%rdi),%eax
    8490:	84 c0                	test   %al,%al
    8492:	0f 84 88 00 00 00    	je     8520 <f37+0x410>
    8498:	31 db                	xor    %ebx,%ebx
    849a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84a0:	3c fd                	cmp    $0xfd,%al
    84a2:	0f 87 f1 00 00 00    	ja     8599 <f37+0x489>
    84a8:	83 c0 01             	add    $0x1,%eax
    84ab:	88 07                	mov    %al,(%rdi)
    84ad:	31 d2                	xor    %edx,%edx
    84af:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    84b4:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    84b9:	0f 85 00 fd ff ff    	jne    81bf <f37+0xaf>
    84bf:	e9 29 fd ff ff       	jmp    81ed <f37+0xdd>
    84c4:	0f 1f 40 00          	nopl   0x0(%rax)
    84c8:	66 85 c0             	test   %ax,%ax
    84cb:	0f 85 0c ff ff ff    	jne    83dd <f37+0x2cd>
    84d1:	e9 fb fe ff ff       	jmp    83d1 <f37+0x2c1>
    84d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84dd:	00 00 00 
    84e0:	66 85 c0             	test   %ax,%ax
    84e3:	0f 85 c2 fd ff ff    	jne    82ab <f37+0x19b>
    84e9:	e9 af fd ff ff       	jmp    829d <f37+0x18d>
    84ee:	66 90                	xchg   %ax,%ax
    84f0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    84f5:	e9 cd fc ff ff       	jmp    81c7 <f37+0xb7>
    84fa:	66 85 c9             	test   %cx,%cx
    84fd:	75 21                	jne    8520 <f37+0x410>
    84ff:	0f b6 07             	movzbl (%rdi),%eax
    8502:	84 c0                	test   %al,%al
    8504:	74 1a                	je     8520 <f37+0x410>
    8506:	3c fd                	cmp    $0xfd,%al
    8508:	0f 87 be 00 00 00    	ja     85cc <f37+0x4bc>
    850e:	83 c0 01             	add    $0x1,%eax
    8511:	88 07                	mov    %al,(%rdi)
    8513:	66 90                	xchg   %ax,%ax
    8515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    851c:	00 00 00 00 
    8520:	be 02 00 00 00       	mov    $0x2,%esi
    8525:	bf 08 00 00 00       	mov    $0x8,%edi
    852a:	e8 e1 d4 ff ff       	call   5a10 <fwp_heap_alloc>
    852f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8536:	48 8b 15 db c5 01 00 	mov    0x1c5db(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    853d:	49 89 c5             	mov    %rax,%r13
    8540:	48 2b 05 a9 c5 01 00 	sub    0x1c5a9(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    8547:	48 c1 e2 10          	shl    $0x10,%rdx
    854b:	48 39 d0             	cmp    %rdx,%rax
    854e:	73 53                	jae    85a3 <f37+0x493>
    8550:	48 89 c2             	mov    %rax,%rdx
    8553:	48 c1 ea 10          	shr    $0x10,%rdx
    8557:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    855b:	48 8b 15 d6 c5 01 00 	mov    0x1c5d6(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    8562:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8566:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    856a:	48 85 ed             	test   %rbp,%rbp
    856d:	74 34                	je     85a3 <f37+0x493>
    856f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8576:	00 00 
    8578:	31 db                	xor    %ebx,%ebx
    857a:	e9 f4 fc ff ff       	jmp    8273 <f37+0x163>
    857f:	48 89 df             	mov    %rbx,%rdi
    8582:	e8 49 cd ff ff       	call   52d0 <fwp_rc_forget_slot>
    8587:	e9 4e fe ff ff       	jmp    83da <f37+0x2ca>
    858c:	48 89 ef             	mov    %rbp,%rdi
    858f:	e8 3c cd ff ff       	call   52d0 <fwp_rc_forget_slot>
    8594:	e9 0e fd ff ff       	jmp    82a7 <f37+0x197>
    8599:	e8 12 cc ff ff       	call   51b0 <fwp_rc_wide_dup>
    859e:	e9 0a ff ff ff       	jmp    84ad <f37+0x39d>
    85a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    85aa:	00 00 
    85ac:	e9 73 fd ff ff       	jmp    8324 <f37+0x214>
    85b1:	e8 fa cb ff ff       	call   51b0 <fwp_rc_wide_dup>
    85b6:	e9 ff fb ff ff       	jmp    81ba <f37+0xaa>
    85bb:	e8 80 ae ff ff       	call   3440 <__stack_chk_fail@plt>
    85c0:	48 8d 3d 66 6b 00 00 	lea    0x6b66(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    85c7:	e8 94 bb ff ff       	call   4160 <fwp_trap>
    85cc:	e8 df cb ff ff       	call   51b0 <fwp_rc_wide_dup>
    85d1:	e9 4a ff ff ff       	jmp    8520 <f37+0x410>
    85d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85dd:	00 00 00 

00000000000085e0 <fwp_owned_entry37>:
    85e0:	f3 0f 1e fa          	endbr64
    85e4:	48 8b 3f             	mov    (%rdi),%rdi
    85e7:	e9 24 fb ff ff       	jmp    8110 <f37>
    85ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000085f0 <e37>:
    85f0:	f3 0f 1e fa          	endbr64
    85f4:	53                   	push   %rbx
    85f5:	48 8b 1f             	mov    (%rdi),%rbx
    85f8:	48 89 df             	mov    %rbx,%rdi
    85fb:	e8 30 e2 ff ff       	call   6830 <fwp_rc_share>
    8600:	48 89 df             	mov    %rbx,%rdi
    8603:	e8 08 fb ff ff       	call   8110 <f37>
    8608:	48 89 c3             	mov    %rax,%rbx
    860b:	48 89 c7             	mov    %rax,%rdi
    860e:	e8 1d e2 ff ff       	call   6830 <fwp_rc_share>
    8613:	48 89 d8             	mov    %rbx,%rax
    8616:	5b                   	pop    %rbx
    8617:	c3                   	ret
    8618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    861f:	00 

0000000000008620 <fwp_write>:
    8620:	41 57                	push   %r15
    8622:	41 56                	push   %r14
    8624:	41 55                	push   %r13
    8626:	41 54                	push   %r12
    8628:	55                   	push   %rbp
    8629:	53                   	push   %rbx
    862a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8631:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8638:	00 00 
    863a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8641:	00 
    8642:	49 89 d4             	mov    %rdx,%r12
    8645:	8b 12                	mov    (%rdx),%edx
    8647:	83 fa 19             	cmp    $0x19,%edx
    864a:	77 6a                	ja     86b6 <fwp_write+0x96>
    864c:	48 89 f5             	mov    %rsi,%rbp
    864f:	89 d0                	mov    %edx,%eax
    8651:	89 ce                	mov    %ecx,%esi
    8653:	48 89 fb             	mov    %rdi,%rbx
    8656:	48 8d 0d b3 73 00 00 	lea    0x73b3(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    865d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8661:	48 01 c8             	add    %rcx,%rax
    8664:	3e ff e0             	notrack jmp *%rax
    8667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    866e:	00 00 
    8670:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8674:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8678:	48 89 ca             	mov    %rcx,%rdx
    867b:	48 85 c9             	test   %rcx,%rcx
    867e:	0f 88 9c 0c 00 00    	js     9320 <fwp_write+0xd00>
    8684:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    868b:	00 
    868c:	48 89 c6             	mov    %rax,%rsi
    868f:	4c 89 e7             	mov    %r12,%rdi
    8692:	e8 69 b3 ff ff       	call   3a00 <fwp_fmt_u128>
    8697:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    869e:	00 00 
    86a0:	4c 89 e7             	mov    %r12,%rdi
    86a3:	e8 88 ad ff ff       	call   3430 <strlen@plt>
    86a8:	4c 89 e6             	mov    %r12,%rsi
    86ab:	48 89 df             	mov    %rbx,%rdi
    86ae:	48 89 c2             	mov    %rax,%rdx
    86b1:	e8 7a b9 ff ff       	call   4030 <buf_put>
    86b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86bd:	00 
    86be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86c5:	00 00 
    86c7:	0f 85 28 04 00 00    	jne    8af5 <fwp_write+0x4d5>
    86cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    86d4:	5b                   	pop    %rbx
    86d5:	5d                   	pop    %rbp
    86d6:	41 5c                	pop    %r12
    86d8:	41 5d                	pop    %r13
    86da:	41 5e                	pop    %r14
    86dc:	41 5f                	pop    %r15
    86de:	c3                   	ret
    86df:	90                   	nop
    86e0:	49 89 e9             	mov    %rbp,%r9
    86e3:	4c 8d 05 6d 6a 00 00 	lea    0x6a6d(%rip),%r8        # f157 <_IO_stdin_used+0x157>
    86ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    86ef:	ba 02 00 00 00       	mov    $0x2,%edx
    86f4:	be 00 02 00 00       	mov    $0x200,%esi
    86f9:	31 c0                	xor    %eax,%eax
    86fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8702:	00 
    8703:	e8 88 ac ff ff       	call   3390 <__snprintf_chk@plt>
    8708:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    870f:	00 
    8710:	e8 1b ad ff ff       	call   3430 <strlen@plt>
    8715:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    871c:	00 
    871d:	48 89 df             	mov    %rbx,%rdi
    8720:	48 89 c2             	mov    %rax,%rdx
    8723:	e8 08 b9 ff ff       	call   4030 <buf_put>
    8728:	eb 8c                	jmp    86b6 <fwp_write+0x96>
    872a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8730:	49 89 e9             	mov    %rbp,%r9
    8733:	4c 8d 05 18 6a 00 00 	lea    0x6a18(%rip),%r8        # f152 <_IO_stdin_used+0x152>
    873a:	eb ae                	jmp    86ea <fwp_write+0xca>
    873c:	0f 1f 40 00          	nopl   0x0(%rax)
    8740:	83 fa 13             	cmp    $0x13,%edx
    8743:	48 8d 05 fe 69 00 00 	lea    0x69fe(%rip),%rax        # f148 <_IO_stdin_used+0x148>
    874a:	48 8d 35 fc 69 00 00 	lea    0x69fc(%rip),%rsi        # f14d <_IO_stdin_used+0x14d>
    8751:	ba 04 00 00 00       	mov    $0x4,%edx
    8756:	48 0f 44 f0          	cmove  %rax,%rsi
    875a:	45 31 ed             	xor    %r13d,%r13d
    875d:	e8 ce b8 ff ff       	call   4030 <buf_put>
    8762:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8767:	0f 84 a3 08 00 00    	je     9010 <fwp_write+0x9f0>
    876d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8772:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8777:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    877c:	48 89 df             	mov    %rbx,%rdi
    877f:	49 0f 44 c5          	cmove  %r13,%rax
    8783:	31 c9                	xor    %ecx,%ecx
    8785:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    878a:	e8 91 fe ff ff       	call   8620 <fwp_write>
    878f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8794:	0f 84 6e 09 00 00    	je     9108 <fwp_write+0xae8>
    879a:	49 83 c5 01          	add    $0x1,%r13
    879e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    87a2:	0f 83 68 08 00 00    	jae    9010 <fwp_write+0x9f0>
    87a8:	ba 02 00 00 00       	mov    $0x2,%edx
    87ad:	48 8d 35 e3 69 00 00 	lea    0x69e3(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    87b4:	48 89 df             	mov    %rbx,%rdi
    87b7:	e8 74 b8 ff ff       	call   4030 <buf_put>
    87bc:	eb af                	jmp    876d <fwp_write+0x14d>
    87be:	66 90                	xchg   %ax,%ax
    87c0:	ba 06 00 00 00       	mov    $0x6,%edx
    87c5:	48 8d 35 a4 69 00 00 	lea    0x69a4(%rip),%rsi        # f170 <_IO_stdin_used+0x170>
    87cc:	48 83 c5 10          	add    $0x10,%rbp
    87d0:	e8 5b b8 ff ff       	call   4030 <buf_put>
    87d5:	48 89 ef             	mov    %rbp,%rdi
    87d8:	e8 53 ac ff ff       	call   3430 <strlen@plt>
    87dd:	48 89 ee             	mov    %rbp,%rsi
    87e0:	48 89 df             	mov    %rbx,%rdi
    87e3:	48 89 c2             	mov    %rax,%rdx
    87e6:	e8 45 b8 ff ff       	call   4030 <buf_put>
    87eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87f0:	ba 01 00 00 00       	mov    $0x1,%edx
    87f5:	48 89 df             	mov    %rbx,%rdi
    87f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    87fd:	e8 2e b8 ff ff       	call   4030 <buf_put>
    8802:	e9 af fe ff ff       	jmp    86b6 <fwp_write+0x96>
    8807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    880e:	00 00 
    8810:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8817:	00 
    8818:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    881f:	00 00 
    8821:	0f 85 ce 02 00 00    	jne    8af5 <fwp_write+0x4d5>
    8827:	ba 0a 00 00 00       	mov    $0xa,%edx
    882c:	48 8d 35 29 69 00 00 	lea    0x6929(%rip),%rsi        # f15c <_IO_stdin_used+0x15c>
    8833:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    883a:	48 89 df             	mov    %rbx,%rdi
    883d:	5b                   	pop    %rbx
    883e:	5d                   	pop    %rbp
    883f:	41 5c                	pop    %r12
    8841:	41 5d                	pop    %r13
    8843:	41 5e                	pop    %r14
    8845:	41 5f                	pop    %r15
    8847:	e9 e4 b7 ff ff       	jmp    4030 <buf_put>
    884c:	0f 1f 40 00          	nopl   0x0(%rax)
    8850:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8855:	4d 85 ed             	test   %r13,%r13
    8858:	0f 84 02 0c 00 00    	je     9460 <fwp_write+0xe40>
    885e:	48 8d 35 3f 69 00 00 	lea    0x693f(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    8865:	4c 89 ef             	mov    %r13,%rdi
    8868:	e8 a3 ac ff ff       	call   3510 <strcmp@plt>
    886d:	41 89 c1             	mov    %eax,%r9d
    8870:	85 c0                	test   %eax,%eax
    8872:	0f 84 6c 0c 00 00    	je     94e4 <fwp_write+0xec4>
    8878:	4c 89 ef             	mov    %r13,%rdi
    887b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8880:	e8 ab ab ff ff       	call   3430 <strlen@plt>
    8885:	4c 89 ee             	mov    %r13,%rsi
    8888:	48 89 df             	mov    %rbx,%rdi
    888b:	48 89 c2             	mov    %rax,%rdx
    888e:	e8 9d b7 ff ff       	call   4030 <buf_put>
    8893:	ba 01 00 00 00       	mov    $0x1,%edx
    8898:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    889d:	48 89 df             	mov    %rbx,%rdi
    88a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    88a5:	e8 86 b7 ff ff       	call   4030 <buf_put>
    88aa:	ba 01 00 00 00       	mov    $0x1,%edx
    88af:	4c 89 fe             	mov    %r15,%rsi
    88b2:	48 89 df             	mov    %rbx,%rdi
    88b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    88ba:	e8 71 b7 ff ff       	call   4030 <buf_put>
    88bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    88c4:	45 31 f6             	xor    %r14d,%r14d
    88c7:	85 d2                	test   %edx,%edx
    88c9:	0f 8e 81 0a 00 00    	jle    9350 <fwp_write+0xd30>
    88cf:	45 31 ed             	xor    %r13d,%r13d
    88d2:	4d 85 ed             	test   %r13,%r13
    88d5:	0f 85 75 07 00 00    	jne    9050 <fwp_write+0xa30>
    88db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    88e2:	00 
    88e3:	45 85 f6             	test   %r14d,%r14d
    88e6:	0f 84 84 07 00 00    	je     9070 <fwp_write+0xa50>
    88ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    88f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    88f6:	48 89 df             	mov    %rbx,%rdi
    88f9:	49 83 c5 01          	add    $0x1,%r13
    88fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8901:	31 c9                	xor    %ecx,%ecx
    8903:	e8 18 fd ff ff       	call   8620 <fwp_write>
    8908:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    890d:	7f c3                	jg     88d2 <fwp_write+0x2b2>
    890f:	45 85 f6             	test   %r14d,%r14d
    8912:	0f 84 38 0a 00 00    	je     9350 <fwp_write+0xd30>
    8918:	b8 29 00 00 00       	mov    $0x29,%eax
    891d:	ba 01 00 00 00       	mov    $0x1,%edx
    8922:	4c 89 fe             	mov    %r15,%rsi
    8925:	48 89 df             	mov    %rbx,%rdi
    8928:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    892c:	e8 ff b6 ff ff       	call   4030 <buf_put>
    8931:	e9 80 fd ff ff       	jmp    86b6 <fwp_write+0x96>
    8936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    893d:	00 00 00 
    8940:	ba 01 00 00 00       	mov    $0x1,%edx
    8945:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    894a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    894f:	e8 dc b6 ff ff       	call   4030 <buf_put>
    8954:	48 85 ed             	test   %rbp,%rbp
    8957:	0f 84 93 06 00 00    	je     8ff0 <fwp_write+0x9d0>
    895d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8961:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8966:	31 c9                	xor    %ecx,%ecx
    8968:	48 89 df             	mov    %rbx,%rdi
    896b:	e8 b0 fc ff ff       	call   8620 <fwp_write>
    8970:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8974:	48 85 ed             	test   %rbp,%rbp
    8977:	0f 84 73 06 00 00    	je     8ff0 <fwp_write+0x9d0>
    897d:	ba 02 00 00 00       	mov    $0x2,%edx
    8982:	48 8d 35 0e 68 00 00 	lea    0x680e(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8989:	48 89 df             	mov    %rbx,%rdi
    898c:	e8 9f b6 ff ff       	call   4030 <buf_put>
    8991:	eb ca                	jmp    895d <fwp_write+0x33d>
    8993:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8998:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    899c:	85 f6                	test   %esi,%esi
    899e:	0f 84 fc 07 00 00    	je     91a0 <fwp_write+0xb80>
    89a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89ab:	00 
    89ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89b3:	00 00 
    89b5:	0f 85 3a 01 00 00    	jne    8af5 <fwp_write+0x4d5>
    89bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    89bf:	4c 89 ea             	mov    %r13,%rdx
    89c2:	e9 6c fe ff ff       	jmp    8833 <fwp_write+0x213>
    89c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ce:	00 00 
    89d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    89d5:	ba 01 00 00 00       	mov    $0x1,%edx
    89da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    89df:	48 89 ee             	mov    %rbp,%rsi
    89e2:	e8 49 b6 ff ff       	call   4030 <buf_put>
    89e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    89ec:	4c 89 e7             	mov    %r12,%rdi
    89ef:	e8 3c aa ff ff       	call   3430 <strlen@plt>
    89f4:	4c 89 e6             	mov    %r12,%rsi
    89f7:	48 89 df             	mov    %rbx,%rdi
    89fa:	48 89 c2             	mov    %rax,%rdx
    89fd:	e8 2e b6 ff ff       	call   4030 <buf_put>
    8a02:	ba 01 00 00 00       	mov    $0x1,%edx
    8a07:	48 89 ee             	mov    %rbp,%rsi
    8a0a:	48 89 df             	mov    %rbx,%rdi
    8a0d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a12:	e8 19 b6 ff ff       	call   4030 <buf_put>
    8a17:	e9 9a fc ff ff       	jmp    86b6 <fwp_write+0x96>
    8a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a20:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8a25:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8a29:	0f 8a 8e 0b 00 00    	jp     95bd <fwp_write+0xf9d>
    8a2f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a33:	66 0f 54 05 25 71 00 	andpd  0x7125(%rip),%xmm0        # fb60 <msg.4+0xe0>
    8a3a:	00 
    8a3b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8a40:	66 0f 2e 05 60 70 00 	ucomisd 0x7060(%rip),%xmm0        # faa8 <msg.4+0x28>
    8a47:	00 
    8a48:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a4f:	00 
    8a50:	0f 87 b2 09 00 00    	ja     9408 <fwp_write+0xde8>
    8a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a5d:	00 00 00 
    8a60:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a64:	89 ee                	mov    %ebp,%esi
    8a66:	4c 89 e7             	mov    %r12,%rdi
    8a69:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8a6e:	e8 0d ba ff ff       	call   4480 <fwp_format_g.constprop.0>
    8a73:	31 f6                	xor    %esi,%esi
    8a75:	4c 89 e7             	mov    %r12,%rdi
    8a78:	e8 73 a9 ff ff       	call   33f0 <strtod@plt>
    8a7d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8a82:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8a86:	7a 06                	jp     8a8e <fwp_write+0x46e>
    8a88:	0f 84 e9 01 00 00    	je     8c77 <fwp_write+0x657>
    8a8e:	83 c5 01             	add    $0x1,%ebp
    8a91:	83 fd 12             	cmp    $0x12,%ebp
    8a94:	75 ca                	jne    8a60 <fwp_write+0x440>
    8a96:	be 11 00 00 00       	mov    $0x11,%esi
    8a9b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a9f:	4c 89 e7             	mov    %r12,%rdi
    8aa2:	e8 d9 b9 ff ff       	call   4480 <fwp_format_g.constprop.0>
    8aa7:	e9 cb 01 00 00       	jmp    8c77 <fwp_write+0x657>
    8aac:	0f 1f 40 00          	nopl   0x0(%rax)
    8ab0:	48 83 fd 01          	cmp    $0x1,%rbp
    8ab4:	0f 84 e6 08 00 00    	je     93a0 <fwp_write+0xd80>
    8aba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8abe:	b8 02 00 00 00       	mov    $0x2,%eax
    8ac3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ac8:	48 0f 44 d0          	cmove  %rax,%rdx
    8acc:	48 8d 35 6d 66 00 00 	lea    0x666d(%rip),%rsi        # f140 <_IO_stdin_used+0x140>
    8ad3:	48 8d 05 6b 66 00 00 	lea    0x666b(%rip),%rax        # f145 <_IO_stdin_used+0x145>
    8ada:	48 0f 44 f0          	cmove  %rax,%rsi
    8ade:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ae5:	00 
    8ae6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8aed:	00 00 
    8aef:	0f 84 3e fd ff ff    	je     8833 <fwp_write+0x213>
    8af5:	e8 46 a9 ff ff       	call   3440 <__stack_chk_fail@plt>
    8afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b00:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8b05:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8b0a:	e8 61 b4 ff ff       	call   3f70 <buf_grow>
    8b0f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8b13:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8b19:	4c 03 0b             	add    (%rbx),%r9
    8b1c:	66 45 89 11          	mov    %r10w,(%r9)
    8b20:	45 85 e4             	test   %r12d,%r12d
    8b23:	0f 8e 07 05 00 00    	jle    9030 <fwp_write+0xa10>
    8b29:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8b30:	55 55 55 
    8b33:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8b38:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8b3f:	aa aa aa 
    8b42:	49 83 c1 01          	add    $0x1,%r9
    8b46:	eb 45                	jmp    8b8d <fwp_write+0x56d>
    8b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b4f:	00 
    8b50:	be 01 00 00 00       	mov    $0x1,%esi
    8b55:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8b5a:	88 07                	mov    %al,(%rdi)
    8b5c:	48 89 e8             	mov    %rbp,%rax
    8b5f:	49 f7 e8             	imul   %r8
    8b62:	48 89 e8             	mov    %rbp,%rax
    8b65:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b69:	48 29 c2             	sub    %rax,%rdx
    8b6c:	48 85 c9             	test   %rcx,%rcx
    8b6f:	0f 95 c0             	setne  %al
    8b72:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8b76:	48 83 ef 01          	sub    $0x1,%rdi
    8b7a:	48 21 c5             	and    %rax,%rbp
    8b7d:	48 29 ea             	sub    %rbp,%rdx
    8b80:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8b84:	49 39 f9             	cmp    %rdi,%r9
    8b87:	0f 84 a3 04 00 00    	je     9030 <fwp_write+0xa10>
    8b8d:	48 89 e8             	mov    %rbp,%rax
    8b90:	49 f7 e8             	imul   %r8
    8b93:	48 89 e8             	mov    %rbp,%rax
    8b96:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b9a:	48 89 d1             	mov    %rdx,%rcx
    8b9d:	48 29 c1             	sub    %rax,%rcx
    8ba0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8ba4:	48 89 e9             	mov    %rbp,%rcx
    8ba7:	48 29 c1             	sub    %rax,%rcx
    8baa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8bae:	49 f7 e2             	mul    %r10
    8bb1:	b8 30 00 00 00       	mov    $0x30,%eax
    8bb6:	48 89 d6             	mov    %rdx,%rsi
    8bb9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8bbd:	48 d1 ee             	shr    $1,%rsi
    8bc0:	48 01 f2             	add    %rsi,%rdx
    8bc3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8bc7:	48 29 d6             	sub    %rdx,%rsi
    8bca:	74 8e                	je     8b5a <fwp_write+0x53a>
    8bcc:	48 83 fe 01          	cmp    $0x1,%rsi
    8bd0:	0f 85 7a ff ff ff    	jne    8b50 <fwp_write+0x530>
    8bd6:	31 f6                	xor    %esi,%esi
    8bd8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8bdd:	e9 78 ff ff ff       	jmp    8b5a <fwp_write+0x53a>
    8be2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8be8:	66 0f 6e cd          	movd   %ebp,%xmm1
    8bec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8bef:	0f 8a c8 09 00 00    	jp     95bd <fwp_write+0xf9d>
    8bf5:	0f 28 c1             	movaps %xmm1,%xmm0
    8bf8:	0f 54 05 51 6f 00 00 	andps  0x6f51(%rip),%xmm0        # fb50 <msg.4+0xd0>
    8bff:	0f 2e 05 fe 63 00 00 	ucomiss 0x63fe(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8c06:	0f 87 24 08 00 00    	ja     9430 <fwp_write+0xe10>
    8c0c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8c10:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8c16:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c1d:	00 
    8c1e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8c22:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c2e:	00 00 
    8c30:	44 89 ee             	mov    %r13d,%esi
    8c33:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c38:	4c 89 e7             	mov    %r12,%rdi
    8c3b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8c40:	e8 3b b8 ff ff       	call   4480 <fwp_format_g.constprop.0>
    8c45:	31 f6                	xor    %esi,%esi
    8c47:	4c 89 e7             	mov    %r12,%rdi
    8c4a:	e8 41 a8 ff ff       	call   3490 <strtof@plt>
    8c4f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8c54:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8c57:	7a 02                	jp     8c5b <fwp_write+0x63b>
    8c59:	74 1c                	je     8c77 <fwp_write+0x657>
    8c5b:	41 83 c5 01          	add    $0x1,%r13d
    8c5f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8c63:	75 cb                	jne    8c30 <fwp_write+0x610>
    8c65:	be 09 00 00 00       	mov    $0x9,%esi
    8c6a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c6f:	4c 89 e7             	mov    %r12,%rdi
    8c72:	e8 09 b8 ff ff       	call   4480 <fwp_format_g.constprop.0>
    8c77:	4c 89 e7             	mov    %r12,%rdi
    8c7a:	e8 71 b4 ff ff       	call   40f0 <fwp_finish_float>
    8c7f:	e9 1c fa ff ff       	jmp    86a0 <fwp_write+0x80>
    8c84:	0f 1f 40 00          	nopl   0x0(%rax)
    8c88:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8c8c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8c90:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8c97:	00 
    8c98:	48 89 ef             	mov    %rbp,%rdi
    8c9b:	e8 60 ad ff ff       	call   3a00 <fwp_fmt_u128>
    8ca0:	48 89 ef             	mov    %rbp,%rdi
    8ca3:	e8 88 a7 ff ff       	call   3430 <strlen@plt>
    8ca8:	48 89 ee             	mov    %rbp,%rsi
    8cab:	48 89 df             	mov    %rbx,%rdi
    8cae:	48 89 c2             	mov    %rax,%rdx
    8cb1:	e8 7a b3 ff ff       	call   4030 <buf_put>
    8cb6:	e9 fb f9 ff ff       	jmp    86b6 <fwp_write+0x96>
    8cbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cc0:	ba 06 00 00 00       	mov    $0x6,%edx
    8cc5:	48 8d 35 ce 64 00 00 	lea    0x64ce(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    8ccc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8cd2:	e8 59 b3 ff ff       	call   4030 <buf_put>
    8cd7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8cde:	ff ff 7f 
    8ce1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ce5:	0f 84 86 02 00 00    	je     8f71 <fwp_write+0x951>
    8ceb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8cf0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8cf4:	48 85 d2             	test   %rdx,%rdx
    8cf7:	0f 84 ae 00 00 00    	je     8dab <fwp_write+0x78b>
    8cfd:	8b 0a                	mov    (%rdx),%ecx
    8cff:	83 f9 1c             	cmp    $0x1c,%ecx
    8d02:	0f 84 58 06 00 00    	je     9360 <fwp_write+0xd40>
    8d08:	83 f9 1b             	cmp    $0x1b,%ecx
    8d0b:	0f 87 9a 00 00 00    	ja     8dab <fwp_write+0x78b>
    8d11:	be 01 00 00 00       	mov    $0x1,%esi
    8d16:	48 d3 e6             	shl    %cl,%rsi
    8d19:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8d1f:	0f 85 4b 04 00 00    	jne    9170 <fwp_write+0xb50>
    8d25:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8d2b:	0f 85 0f 04 00 00    	jne    9140 <fwp_write+0xb20>
    8d31:	83 e6 21             	and    $0x21,%esi
    8d34:	74 75                	je     8dab <fwp_write+0x78b>
    8d36:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8d3b:	48 85 ff             	test   %rdi,%rdi
    8d3e:	79 07                	jns    8d47 <fwp_write+0x727>
    8d40:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8d44:	4c 01 ee             	add    %r13,%rsi
    8d47:	48 0f be 3e          	movsbq (%rsi),%rdi
    8d4b:	85 c9                	test   %ecx,%ecx
    8d4d:	40 0f b6 f7          	movzbl %dil,%esi
    8d51:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d5c:	00 00 00 00 
    8d60:	31 c9                	xor    %ecx,%ecx
    8d62:	48 89 df             	mov    %rbx,%rdi
    8d65:	49 83 c5 01          	add    $0x1,%r13
    8d69:	e8 b2 f8 ff ff       	call   8620 <fwp_write>
    8d6e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d75:	ff ff 7f 
    8d78:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d7c:	49 39 d5             	cmp    %rdx,%r13
    8d7f:	0f 83 ec 01 00 00    	jae    8f71 <fwp_write+0x951>
    8d85:	ba 02 00 00 00       	mov    $0x2,%edx
    8d8a:	48 89 df             	mov    %rbx,%rdi
    8d8d:	48 8d 35 03 64 00 00 	lea    0x6403(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8d94:	e8 97 b2 ff ff       	call   4030 <buf_put>
    8d99:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d9e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8da2:	48 85 d2             	test   %rdx,%rdx
    8da5:	0f 85 52 ff ff ff    	jne    8cfd <fwp_write+0x6dd>
    8dab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8db0:	48 85 ff             	test   %rdi,%rdi
    8db3:	0f 88 cf 05 00 00    	js     9388 <fwp_write+0xd68>
    8db9:	48 8b 31             	mov    (%rcx),%rsi
    8dbc:	eb a2                	jmp    8d60 <fwp_write+0x740>
    8dbe:	66 90                	xchg   %ax,%ax
    8dc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8dc7:	00 
    8dc8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8dcf:	00 00 
    8dd1:	0f 85 1e fd ff ff    	jne    8af5 <fwp_write+0x4d5>
    8dd7:	ba 08 00 00 00       	mov    $0x8,%edx
    8ddc:	48 8d 35 84 63 00 00 	lea    0x6384(%rip),%rsi        # f167 <_IO_stdin_used+0x167>
    8de3:	e9 4b fa ff ff       	jmp    8833 <fwp_write+0x213>
    8de8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8def:	00 
    8df0:	89 e8                	mov    %ebp,%eax
    8df2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8df9:	76 03                	jbe    8dfe <fwp_write+0x7de>
    8dfb:	8b 45 00             	mov    0x0(%rbp),%eax
    8dfe:	41 89 c6             	mov    %eax,%r14d
    8e01:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e06:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8e0b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8e0f:	4c 89 ef             	mov    %r13,%rdi
    8e12:	e8 19 a6 ff ff       	call   3430 <strlen@plt>
    8e17:	4c 89 ee             	mov    %r13,%rsi
    8e1a:	48 89 df             	mov    %rbx,%rdi
    8e1d:	48 89 c2             	mov    %rax,%rdx
    8e20:	e8 0b b2 ff ff       	call   4030 <buf_put>
    8e25:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e2a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8e2e:	85 f6                	test   %esi,%esi
    8e30:	0f 8e 80 f8 ff ff    	jle    86b6 <fwp_write+0x96>
    8e36:	45 31 ed             	xor    %r13d,%r13d
    8e39:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e3e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8e43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e48:	ba 01 00 00 00       	mov    $0x1,%edx
    8e4d:	4c 89 fe             	mov    %r15,%rsi
    8e50:	48 89 04 24          	mov    %rax,(%rsp)
    8e54:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8e59:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8e5d:	48 89 df             	mov    %rbx,%rdi
    8e60:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8e64:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8e69:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8e6e:	e8 bd b1 ff ff       	call   4030 <buf_put>
    8e73:	41 8b 06             	mov    (%r14),%eax
    8e76:	83 f8 0e             	cmp    $0xe,%eax
    8e79:	0f 84 71 02 00 00    	je     90f0 <fwp_write+0xad0>
    8e7f:	83 f8 10             	cmp    $0x10,%eax
    8e82:	0f 84 38 02 00 00    	je     90c0 <fwp_write+0xaa0>
    8e88:	83 f8 0a             	cmp    $0xa,%eax
    8e8b:	0f 84 7f 04 00 00    	je     9310 <fwp_write+0xcf0>
    8e91:	0f 8f f9 00 00 00    	jg     8f90 <fwp_write+0x970>
    8e97:	83 f8 03             	cmp    $0x3,%eax
    8e9a:	0f 8f 50 04 00 00    	jg     92f0 <fwp_write+0xcd0>
    8ea0:	85 c0                	test   %eax,%eax
    8ea2:	78 10                	js     8eb4 <fwp_write+0x894>
    8ea4:	48 8b 04 24          	mov    (%rsp),%rax
    8ea8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8eac:	85 c0                	test   %eax,%eax
    8eae:	0f 85 f9 00 00 00    	jne    8fad <fwp_write+0x98d>
    8eb4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8eb9:	48 8b 34 24          	mov    (%rsp),%rsi
    8ebd:	31 c9                	xor    %ecx,%ecx
    8ebf:	48 89 df             	mov    %rbx,%rdi
    8ec2:	e8 59 f7 ff ff       	call   8620 <fwp_write>
    8ec7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8ecc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ed1:	49 83 c5 01          	add    $0x1,%r13
    8ed5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8ed9:	0f 8f 5f ff ff ff    	jg     8e3e <fwp_write+0x81e>
    8edf:	e9 d2 f7 ff ff       	jmp    86b6 <fwp_write+0x96>
    8ee4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ee8:	ba 06 00 00 00       	mov    $0x6,%edx
    8eed:	48 8d 35 99 62 00 00 	lea    0x6299(%rip),%rsi        # f18d <_IO_stdin_used+0x18d>
    8ef4:	45 31 ed             	xor    %r13d,%r13d
    8ef7:	e8 34 b1 ff ff       	call   4030 <buf_put>
    8efc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8f01:	75 19                	jne    8f1c <fwp_write+0x8fc>
    8f03:	eb 6c                	jmp    8f71 <fwp_write+0x951>
    8f05:	0f 1f 00             	nopl   (%rax)
    8f08:	ba 02 00 00 00       	mov    $0x2,%edx
    8f0d:	48 8d 35 83 62 00 00 	lea    0x6283(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8f14:	48 89 df             	mov    %rbx,%rdi
    8f17:	e8 14 b1 ff ff       	call   4030 <buf_put>
    8f1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8f22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8f27:	31 c0                	xor    %eax,%eax
    8f29:	49 83 c5 01          	add    $0x1,%r13
    8f2d:	4c 8d 05 60 62 00 00 	lea    0x6260(%rip),%r8        # f194 <_IO_stdin_used+0x194>
    8f34:	ba 02 00 00 00       	mov    $0x2,%edx
    8f39:	be 00 02 00 00       	mov    $0x200,%esi
    8f3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f45:	00 
    8f46:	e8 45 a4 ff ff       	call   3390 <__snprintf_chk@plt>
    8f4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f52:	00 
    8f53:	e8 d8 a4 ff ff       	call   3430 <strlen@plt>
    8f58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f5f:	00 
    8f60:	48 89 df             	mov    %rbx,%rdi
    8f63:	48 89 c2             	mov    %rax,%rdx
    8f66:	e8 c5 b0 ff ff       	call   4030 <buf_put>
    8f6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8f6f:	72 97                	jb     8f08 <fwp_write+0x8e8>
    8f71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f76:	ba 01 00 00 00       	mov    $0x1,%edx
    8f7b:	48 89 df             	mov    %rbx,%rdi
    8f7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f83:	e8 a8 b0 ff ff       	call   4030 <buf_put>
    8f88:	e9 29 f7 ff ff       	jmp    86b6 <fwp_write+0x96>
    8f8d:	0f 1f 00             	nopl   (%rax)
    8f90:	83 f8 0b             	cmp    $0xb,%eax
    8f93:	0f 85 1b ff ff ff    	jne    8eb4 <fwp_write+0x894>
    8f99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8f9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8fa2:	83 e0 01             	and    $0x1,%eax
    8fa5:	85 c0                	test   %eax,%eax
    8fa7:	0f 84 07 ff ff ff    	je     8eb4 <fwp_write+0x894>
    8fad:	4c 89 fe             	mov    %r15,%rsi
    8fb0:	48 89 df             	mov    %rbx,%rdi
    8fb3:	ba 01 00 00 00       	mov    $0x1,%edx
    8fb8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8fbd:	e8 6e b0 ff ff       	call   4030 <buf_put>
    8fc2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8fc7:	48 8b 34 24          	mov    (%rsp),%rsi
    8fcb:	31 c9                	xor    %ecx,%ecx
    8fcd:	48 89 df             	mov    %rbx,%rdi
    8fd0:	e8 4b f6 ff ff       	call   8620 <fwp_write>
    8fd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8fda:	4c 89 fe             	mov    %r15,%rsi
    8fdd:	48 89 df             	mov    %rbx,%rdi
    8fe0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8fe5:	e8 46 b0 ff ff       	call   4030 <buf_put>
    8fea:	e9 d8 fe ff ff       	jmp    8ec7 <fwp_write+0x8a7>
    8fef:	90                   	nop
    8ff0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ff5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ffa:	48 89 df             	mov    %rbx,%rdi
    8ffd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9002:	e8 29 b0 ff ff       	call   4030 <buf_put>
    9007:	e9 aa f6 ff ff       	jmp    86b6 <fwp_write+0x96>
    900c:	0f 1f 40 00          	nopl   0x0(%rax)
    9010:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9015:	ba 01 00 00 00       	mov    $0x1,%edx
    901a:	48 89 df             	mov    %rbx,%rdi
    901d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9022:	e8 09 b0 ff ff       	call   4030 <buf_put>
    9027:	e9 8a f6 ff ff       	jmp    86b6 <fwp_write+0x96>
    902c:	0f 1f 40 00          	nopl   0x0(%rax)
    9030:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9034:	48 8b 13             	mov    (%rbx),%rdx
    9037:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    903c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9040:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9044:	e9 6d f6 ff ff       	jmp    86b6 <fwp_write+0x96>
    9049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9050:	ba 02 00 00 00       	mov    $0x2,%edx
    9055:	48 8d 35 3b 61 00 00 	lea    0x613b(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    905c:	48 89 df             	mov    %rbx,%rdi
    905f:	e8 cc af ff ff       	call   4030 <buf_put>
    9064:	e9 72 f8 ff ff       	jmp    88db <fwp_write+0x2bb>
    9069:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9070:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9075:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    907a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    907e:	48 89 f7             	mov    %rsi,%rdi
    9081:	48 89 34 24          	mov    %rsi,(%rsp)
    9085:	e8 a6 a3 ff ff       	call   3430 <strlen@plt>
    908a:	48 8b 34 24          	mov    (%rsp),%rsi
    908e:	48 89 df             	mov    %rbx,%rdi
    9091:	48 89 c2             	mov    %rax,%rdx
    9094:	e8 97 af ff ff       	call   4030 <buf_put>
    9099:	ba 03 00 00 00       	mov    $0x3,%edx
    909e:	48 8d 35 15 61 00 00 	lea    0x6115(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    90a5:	48 89 df             	mov    %rbx,%rdi
    90a8:	e8 83 af ff ff       	call   4030 <buf_put>
    90ad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    90b2:	e9 35 f8 ff ff       	jmp    88ec <fwp_write+0x2cc>
    90b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90be:	00 00 
    90c0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    90c5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    90c9:	48 85 ff             	test   %rdi,%rdi
    90cc:	0f 84 e2 fd ff ff    	je     8eb4 <fwp_write+0x894>
    90d2:	48 8d 35 cb 60 00 00 	lea    0x60cb(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    90d9:	e8 32 a4 ff ff       	call   3510 <strcmp@plt>
    90de:	85 c0                	test   %eax,%eax
    90e0:	0f 95 c0             	setne  %al
    90e3:	0f b6 c0             	movzbl %al,%eax
    90e6:	e9 c1 fd ff ff       	jmp    8eac <fwp_write+0x88c>
    90eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90f0:	31 c0                	xor    %eax,%eax
    90f2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    90f9:	00 
    90fa:	0f 97 c0             	seta   %al
    90fd:	e9 aa fd ff ff       	jmp    8eac <fwp_write+0x88c>
    9102:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9108:	48 89 df             	mov    %rbx,%rdi
    910b:	ba 02 00 00 00       	mov    $0x2,%edx
    9110:	48 8d 35 8a 60 00 00 	lea    0x608a(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    9117:	e8 14 af ff ff       	call   4030 <buf_put>
    911c:	4c 89 e8             	mov    %r13,%rax
    911f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9124:	31 c9                	xor    %ecx,%ecx
    9126:	48 c1 e0 04          	shl    $0x4,%rax
    912a:	48 89 df             	mov    %rbx,%rdi
    912d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9132:	e8 e9 f4 ff ff       	call   8620 <fwp_write>
    9137:	e9 5e f6 ff ff       	jmp    879a <fwp_write+0x17a>
    913c:	0f 1f 40 00          	nopl   0x0(%rax)
    9140:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9145:	48 85 ff             	test   %rdi,%rdi
    9148:	79 0c                	jns    9156 <fwp_write+0xb36>
    914a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9151:	00 
    9152:	48 03 75 10          	add    0x10(%rbp),%rsi
    9156:	48 63 3e             	movslq (%rsi),%rdi
    9159:	83 f9 02             	cmp    $0x2,%ecx
    915c:	89 fe                	mov    %edi,%esi
    915e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9162:	e9 f9 fb ff ff       	jmp    8d60 <fwp_write+0x740>
    9167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    916e:	00 00 
    9170:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9175:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    917a:	48 85 ff             	test   %rdi,%rdi
    917d:	0f 88 0f 03 00 00    	js     9492 <fwp_write+0xe72>
    9183:	49 0f bf 38          	movswq (%r8),%rdi
    9187:	83 f9 01             	cmp    $0x1,%ecx
    918a:	0f b7 f7             	movzwl %di,%esi
    918d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9191:	e9 ca fb ff ff       	jmp    8d60 <fwp_write+0x740>
    9196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    919d:	00 00 00 
    91a0:	ba 01 00 00 00       	mov    $0x1,%edx
    91a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91aa:	48 83 c5 08          	add    $0x8,%rbp
    91ae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    91b3:	e8 78 ae ff ff       	call   4030 <buf_put>
    91b8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    91bd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    91c2:	4d 85 ed             	test   %r13,%r13
    91c5:	75 46                	jne    920d <fwp_write+0xbed>
    91c7:	e9 04 01 00 00       	jmp    92d0 <fwp_write+0xcb0>
    91cc:	0f 1f 40 00          	nopl   0x0(%rax)
    91d0:	41 80 f9 09          	cmp    $0x9,%r9b
    91d4:	0f 84 d6 00 00 00    	je     92b0 <fwp_write+0xc90>
    91da:	41 80 f9 0a          	cmp    $0xa,%r9b
    91de:	0f 85 9c 00 00 00    	jne    9280 <fwp_write+0xc60>
    91e4:	ba 02 00 00 00       	mov    $0x2,%edx
    91e9:	48 8d 35 8d 5f 00 00 	lea    0x5f8d(%rip),%rsi        # f17d <_IO_stdin_used+0x17d>
    91f0:	48 89 df             	mov    %rbx,%rdi
    91f3:	e8 38 ae ff ff       	call   4030 <buf_put>
    91f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91ff:	00 
    9200:	48 83 c5 01          	add    $0x1,%rbp
    9204:	49 39 ec             	cmp    %rbp,%r12
    9207:	0f 84 c3 00 00 00    	je     92d0 <fwp_write+0xcb0>
    920d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9212:	41 80 f9 0d          	cmp    $0xd,%r9b
    9216:	74 28                	je     9240 <fwp_write+0xc20>
    9218:	7e b6                	jle    91d0 <fwp_write+0xbb0>
    921a:	41 80 f9 22          	cmp    $0x22,%r9b
    921e:	74 40                	je     9260 <fwp_write+0xc40>
    9220:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9224:	75 5a                	jne    9280 <fwp_write+0xc60>
    9226:	ba 02 00 00 00       	mov    $0x2,%edx
    922b:	48 8d 35 48 5f 00 00 	lea    0x5f48(%rip),%rsi        # f17a <_IO_stdin_used+0x17a>
    9232:	48 89 df             	mov    %rbx,%rdi
    9235:	e8 f6 ad ff ff       	call   4030 <buf_put>
    923a:	eb c4                	jmp    9200 <fwp_write+0xbe0>
    923c:	0f 1f 40 00          	nopl   0x0(%rax)
    9240:	ba 02 00 00 00       	mov    $0x2,%edx
    9245:	48 8d 35 37 5f 00 00 	lea    0x5f37(%rip),%rsi        # f183 <_IO_stdin_used+0x183>
    924c:	48 89 df             	mov    %rbx,%rdi
    924f:	e8 dc ad ff ff       	call   4030 <buf_put>
    9254:	eb aa                	jmp    9200 <fwp_write+0xbe0>
    9256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    925d:	00 00 00 
    9260:	ba 02 00 00 00       	mov    $0x2,%edx
    9265:	48 8d 35 0b 5f 00 00 	lea    0x5f0b(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    926c:	48 89 df             	mov    %rbx,%rdi
    926f:	e8 bc ad ff ff       	call   4030 <buf_put>
    9274:	eb 8a                	jmp    9200 <fwp_write+0xbe0>
    9276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    927d:	00 00 00 
    9280:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9284:	0f 86 2e 01 00 00    	jbe    93b8 <fwp_write+0xd98>
    928a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    928e:	0f 84 24 01 00 00    	je     93b8 <fwp_write+0xd98>
    9294:	ba 01 00 00 00       	mov    $0x1,%edx
    9299:	4c 89 fe             	mov    %r15,%rsi
    929c:	48 89 df             	mov    %rbx,%rdi
    929f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    92a4:	e8 87 ad ff ff       	call   4030 <buf_put>
    92a9:	e9 52 ff ff ff       	jmp    9200 <fwp_write+0xbe0>
    92ae:	66 90                	xchg   %ax,%ax
    92b0:	ba 02 00 00 00       	mov    $0x2,%edx
    92b5:	48 8d 35 c4 5e 00 00 	lea    0x5ec4(%rip),%rsi        # f180 <_IO_stdin_used+0x180>
    92bc:	48 89 df             	mov    %rbx,%rdi
    92bf:	e8 6c ad ff ff       	call   4030 <buf_put>
    92c4:	e9 37 ff ff ff       	jmp    9200 <fwp_write+0xbe0>
    92c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92d0:	ba 01 00 00 00       	mov    $0x1,%edx
    92d5:	4c 89 fe             	mov    %r15,%rsi
    92d8:	48 89 df             	mov    %rbx,%rdi
    92db:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    92e0:	e8 4b ad ff ff       	call   4030 <buf_put>
    92e5:	e9 cc f3 ff ff       	jmp    86b6 <fwp_write+0x96>
    92ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92f0:	83 f8 04             	cmp    $0x4,%eax
    92f3:	0f 85 bb fb ff ff    	jne    8eb4 <fwp_write+0x894>
    92f9:	48 8b 04 24          	mov    (%rsp),%rax
    92fd:	48 8b 40 08          	mov    0x8(%rax),%rax
    9301:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9306:	48 c1 e8 3f          	shr    $0x3f,%rax
    930a:	e9 96 fc ff ff       	jmp    8fa5 <fwp_write+0x985>
    930f:	90                   	nop
    9310:	8b 0c 24             	mov    (%rsp),%ecx
    9313:	31 c0                	xor    %eax,%eax
    9315:	85 c9                	test   %ecx,%ecx
    9317:	0f 98 c0             	sets   %al
    931a:	e9 86 fc ff ff       	jmp    8fa5 <fwp_write+0x985>
    931f:	90                   	nop
    9320:	48 f7 d8             	neg    %rax
    9323:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    932a:	00 
    932b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9332:	2d 
    9333:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    933a:	00 
    933b:	48 83 d2 00          	adc    $0x0,%rdx
    933f:	48 89 c6             	mov    %rax,%rsi
    9342:	48 f7 da             	neg    %rdx
    9345:	e8 b6 a6 ff ff       	call   3a00 <fwp_fmt_u128>
    934a:	e9 51 f3 ff ff       	jmp    86a0 <fwp_write+0x80>
    934f:	90                   	nop
    9350:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9355:	e9 c3 f5 ff ff       	jmp    891d <fwp_write+0x2fd>
    935a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9360:	4c 89 e9             	mov    %r13,%rcx
    9363:	48 c1 e1 04          	shl    $0x4,%rcx
    9367:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    936c:	48 85 ff             	test   %rdi,%rdi
    936f:	0f 89 eb f9 ff ff    	jns    8d60 <fwp_write+0x740>
    9375:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9379:	48 89 ce             	mov    %rcx,%rsi
    937c:	e9 df f9 ff ff       	jmp    8d60 <fwp_write+0x740>
    9381:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9388:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    938f:	00 
    9390:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9394:	e9 20 fa ff ff       	jmp    8db9 <fwp_write+0x799>
    9399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93a0:	ba 02 00 00 00       	mov    $0x2,%edx
    93a5:	48 8d 35 96 5d 00 00 	lea    0x5d96(%rip),%rsi        # f142 <_IO_stdin_used+0x142>
    93ac:	e9 2d f7 ff ff       	jmp    8ade <fwp_write+0x4be>
    93b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93b8:	4c 8d 05 c7 5d 00 00 	lea    0x5dc7(%rip),%r8        # f186 <_IO_stdin_used+0x186>
    93bf:	b9 10 00 00 00       	mov    $0x10,%ecx
    93c4:	31 c0                	xor    %eax,%eax
    93c6:	ba 02 00 00 00       	mov    $0x2,%edx
    93cb:	be 10 00 00 00       	mov    $0x10,%esi
    93d0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93d7:	00 
    93d8:	e8 b3 9f ff ff       	call   3390 <__snprintf_chk@plt>
    93dd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93e4:	00 
    93e5:	e8 46 a0 ff ff       	call   3430 <strlen@plt>
    93ea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    93f1:	00 
    93f2:	48 89 df             	mov    %rbx,%rdi
    93f5:	48 89 c2             	mov    %rax,%rdx
    93f8:	e8 33 ac ff ff       	call   4030 <buf_put>
    93fd:	e9 fe fd ff ff       	jmp    9200 <fwp_write+0xbe0>
    9402:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9408:	66 0f ef c0          	pxor   %xmm0,%xmm0
    940c:	48 8d 35 29 5d 00 00 	lea    0x5d29(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    9413:	48 8d 05 21 5d 00 00 	lea    0x5d21(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    941a:	4c 89 e7             	mov    %r12,%rdi
    941d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9421:	48 0f 46 f0          	cmovbe %rax,%rsi
    9425:	e8 a6 9f ff ff       	call   33d0 <strcpy@plt>
    942a:	e9 71 f2 ff ff       	jmp    86a0 <fwp_write+0x80>
    942f:	90                   	nop
    9430:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9434:	48 8d 35 01 5d 00 00 	lea    0x5d01(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    943b:	48 8d 05 f9 5c 00 00 	lea    0x5cf9(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    9442:	0f 2f c8             	comiss %xmm0,%xmm1
    9445:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    944c:	00 
    944d:	4c 89 e7             	mov    %r12,%rdi
    9450:	48 0f 46 f0          	cmovbe %rax,%rsi
    9454:	e8 77 9f ff ff       	call   33d0 <strcpy@plt>
    9459:	e9 42 f2 ff ff       	jmp    86a0 <fwp_write+0x80>
    945e:	66 90                	xchg   %ax,%ax
    9460:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9465:	45 85 c0             	test   %r8d,%r8d
    9468:	75 34                	jne    949e <fwp_write+0xe7e>
    946a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9471:	00 
    9472:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9479:	00 00 
    947b:	0f 85 74 f6 ff ff    	jne    8af5 <fwp_write+0x4d5>
    9481:	ba 02 00 00 00       	mov    $0x2,%edx
    9486:	48 8d 35 2a 5d 00 00 	lea    0x5d2a(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    948d:	e9 a1 f3 ff ff       	jmp    8833 <fwp_write+0x213>
    9492:	48 03 75 10          	add    0x10(%rbp),%rsi
    9496:	49 89 f0             	mov    %rsi,%r8
    9499:	e9 e5 fc ff ff       	jmp    9183 <fwp_write+0xb63>
    949e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    94a3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    94a8:	85 ff                	test   %edi,%edi
    94aa:	0f 84 fa f3 ff ff    	je     88aa <fwp_write+0x28a>
    94b0:	ba 01 00 00 00       	mov    $0x1,%edx
    94b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94ba:	48 89 df             	mov    %rbx,%rdi
    94bd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    94c2:	e8 69 ab ff ff       	call   4030 <buf_put>
    94c7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    94cc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    94d1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    94d7:	85 c0                	test   %eax,%eax
    94d9:	0f 8f f0 f3 ff ff    	jg     88cf <fwp_write+0x2af>
    94df:	e9 34 f4 ff ff       	jmp    8918 <fwp_write+0x2f8>
    94e4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94e8:	49 89 c5             	mov    %rax,%r13
    94eb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    94f0:	49 89 c4             	mov    %rax,%r12
    94f3:	49 c1 fd 3f          	sar    $0x3f,%r13
    94f7:	4c 09 e8             	or     %r13,%rax
    94fa:	0f 84 a7 00 00 00    	je     95a7 <fwp_write+0xf87>
    9500:	48 8d 2d d9 7d 00 00 	lea    0x7dd9(%rip),%rbp        # 112e0 <units.0>
    9507:	4d 89 e7             	mov    %r12,%r15
    950a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    950e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9513:	4c 89 ff             	mov    %r15,%rdi
    9516:	4c 89 ee             	mov    %r13,%rsi
    9519:	44 89 0c 24          	mov    %r9d,(%rsp)
    951d:	48 99                	cqto
    951f:	48 89 d1             	mov    %rdx,%rcx
    9522:	48 89 c2             	mov    %rax,%rdx
    9525:	e8 e6 4d 00 00       	call   e310 <__divmodti4>
    952a:	44 8b 0c 24          	mov    (%rsp),%r9d
    952e:	48 89 c1             	mov    %rax,%rcx
    9531:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9536:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    953b:	0f 84 94 00 00 00    	je     95d5 <fwp_write+0xfb5>
    9541:	41 83 c1 01          	add    $0x1,%r9d
    9545:	48 83 c5 10          	add    $0x10,%rbp
    9549:	41 83 f9 05          	cmp    $0x5,%r9d
    954d:	75 bb                	jne    950a <fwp_write+0xeea>
    954f:	4d 85 ed             	test   %r13,%r13
    9552:	79 53                	jns    95a7 <fwp_write+0xf87>
    9554:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9559:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    955e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9563:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9568:	48 99                	cqto
    956a:	48 f7 d8             	neg    %rax
    956d:	48 83 d2 00          	adc    $0x0,%rdx
    9571:	48 89 c6             	mov    %rax,%rsi
    9574:	48 f7 da             	neg    %rdx
    9577:	e8 84 a4 ff ff       	call   3a00 <fwp_fmt_u128>
    957c:	49 89 e8             	mov    %rbp,%r8
    957f:	ba 00 02 00 00       	mov    $0x200,%edx
    9584:	be 02 00 00 00       	mov    $0x2,%esi
    9589:	31 c0                	xor    %eax,%eax
    958b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9592:	00 
    9593:	48 8d 0d 18 5c 00 00 	lea    0x5c18(%rip),%rcx        # f1b2 <_IO_stdin_used+0x1b2>
    959a:	4c 89 e7             	mov    %r12,%rdi
    959d:	e8 fe a0 ff ff       	call   36a0 <__sprintf_chk@plt>
    95a2:	e9 f9 f0 ff ff       	jmp    86a0 <fwp_write+0x80>
    95a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    95b1:	31 d2                	xor    %edx,%edx
    95b3:	48 89 ef             	mov    %rbp,%rdi
    95b6:	e8 45 a4 ff ff       	call   3a00 <fwp_fmt_u128>
    95bb:	eb bf                	jmp    957c <fwp_write+0xf5c>
    95bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    95c4:	4e 61 4e 00 
    95c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95cf:	00 
    95d0:	e9 cb f0 ff ff       	jmp    86a0 <fwp_write+0x80>
    95d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    95d9:	48 89 c8             	mov    %rcx,%rax
    95dc:	48 85 d2             	test   %rdx,%rdx
    95df:	78 51                	js     9632 <fwp_write+0x1012>
    95e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95e6:	48 89 c6             	mov    %rax,%rsi
    95e9:	48 89 ef             	mov    %rbp,%rdi
    95ec:	e8 0f a4 ff ff       	call   3a00 <fwp_fmt_u128>
    95f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    95f5:	49 63 c1             	movslq %r9d,%rax
    95f8:	49 89 e8             	mov    %rbp,%r8
    95fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9600:	be 02 00 00 00       	mov    $0x2,%esi
    9605:	48 c1 e0 04          	shl    $0x4,%rax
    9609:	48 8d 3d d0 7c 00 00 	lea    0x7cd0(%rip),%rdi        # 112e0 <units.0>
    9610:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9617:	00 
    9618:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    961c:	48 8d 0d 8a 5b 00 00 	lea    0x5b8a(%rip),%rcx        # f1ad <_IO_stdin_used+0x1ad>
    9623:	4c 89 e7             	mov    %r12,%rdi
    9626:	31 c0                	xor    %eax,%eax
    9628:	e8 73 a0 ff ff       	call   36a0 <__sprintf_chk@plt>
    962d:	e9 6e f0 ff ff       	jmp    86a0 <fwp_write+0x80>
    9632:	48 f7 d8             	neg    %rax
    9635:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    963a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    963f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9644:	48 83 d2 00          	adc    $0x0,%rdx
    9648:	48 89 c6             	mov    %rax,%rsi
    964b:	48 f7 da             	neg    %rdx
    964e:	e8 ad a3 ff ff       	call   3a00 <fwp_fmt_u128>
    9653:	44 8b 0c 24          	mov    (%rsp),%r9d
    9657:	eb 9c                	jmp    95f5 <fwp_write+0xfd5>
    9659:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009660 <fwp_hof0.constprop.0>:
    9660:	41 57                	push   %r15
    9662:	41 56                	push   %r14
    9664:	41 55                	push   %r13
    9666:	41 54                	push   %r12
    9668:	55                   	push   %rbp
    9669:	53                   	push   %rbx
    966a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    9671:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9678:	00 00 
    967a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    9681:	00 
    9682:	31 c0                	xor    %eax,%eax
    9684:	48 85 f6             	test   %rsi,%rsi
    9687:	0f 84 2a 0f 00 00    	je     a5b7 <fwp_hof0.constprop.0+0xf57>
    968d:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
    9692:	4c 8d 2d a7 a0 01 00 	lea    0x1a0a7(%rip),%r13        # 23740 <fwp_heap>
    9699:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
    969e:	66 90                	xchg   %ax,%ax
    96a0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    96a7:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    96ac:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    96b3:	48 c1 e2 10          	shl    $0x10,%rdx
    96b7:	48 39 d0             	cmp    %rdx,%rax
    96ba:	73 5d                	jae    9719 <fwp_hof0.constprop.0+0xb9>
    96bc:	48 89 c2             	mov    %rax,%rdx
    96bf:	48 c1 ea 10          	shr    $0x10,%rdx
    96c3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96c7:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    96ce:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96d2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    96d6:	48 85 ff             	test   %rdi,%rdi
    96d9:	74 3e                	je     9719 <fwp_hof0.constprop.0+0xb9>
    96db:	0f b6 0a             	movzbl (%rdx),%ecx
    96de:	80 f9 02             	cmp    $0x2,%cl
    96e1:	0f 84 b9 14 00 00    	je     aba0 <fwp_hof0.constprop.0+0x1540>
    96e7:	80 f9 01             	cmp    $0x1,%cl
    96ea:	75 2d                	jne    9719 <fwp_hof0.constprop.0+0xb9>
    96ec:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96ef:	0f b7 c0             	movzwl %ax,%eax
    96f2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96f5:	48 0f af c1          	imul   %rcx,%rax
    96f9:	48 c1 e8 20          	shr    $0x20,%rax
    96fd:	48 39 d0             	cmp    %rdx,%rax
    9700:	73 17                	jae    9719 <fwp_hof0.constprop.0+0xb9>
    9702:	48 01 c7             	add    %rax,%rdi
    9705:	0f b6 07             	movzbl (%rdi),%eax
    9708:	84 c0                	test   %al,%al
    970a:	74 0d                	je     9719 <fwp_hof0.constprop.0+0xb9>
    970c:	3c fd                	cmp    $0xfd,%al
    970e:	0f 87 a7 16 00 00    	ja     adbb <fwp_hof0.constprop.0+0x175b>
    9714:	83 c0 01             	add    $0x1,%eax
    9717:	88 07                	mov    %al,(%rdi)
    9719:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    971e:	45 31 c0             	xor    %r8d,%r8d
    9721:	48 c7 44 24 20 c6 00 	movq   $0xc6,0x20(%rsp)
    9728:	00 00 
    972a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    972f:	4c 89 c3             	mov    %r8,%rbx
    9732:	4d 85 c0             	test   %r8,%r8
    9735:	0f 85 d5 9f ff ff    	jne    3710 <fwp_hof0.constprop.0.cold+0x5>
    973b:	48 8b 05 96 bc 01 00 	mov    0x1bc96(%rip),%rax        # 253d8 <fwp_cleanups>
    9742:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9749:	4c 8d 25 50 d8 ff ff 	lea    -0x27b0(%rip),%r12        # 6fa0 <fwp_tape_scope_release>
    9750:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9757:	ff 
    9758:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
    975f:	00 
    9760:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9767:	00 
    9768:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    976d:	48 c1 e2 10          	shl    $0x10,%rdx
    9771:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9776:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    977d:	00 
    977e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9785:	00 
    9786:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    978b:	48 89 05 46 bc 01 00 	mov    %rax,0x1bc46(%rip)        # 253d8 <fwp_cleanups>
    9792:	48 8d 05 77 98 00 00 	lea    0x9877(%rip),%rax        # 13010 <fc37>
    9799:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    97a0:	48 39 d0             	cmp    %rdx,%rax
    97a3:	73 5d                	jae    9802 <fwp_hof0.constprop.0+0x1a2>
    97a5:	48 89 c2             	mov    %rax,%rdx
    97a8:	48 c1 ea 10          	shr    $0x10,%rdx
    97ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97b0:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    97b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97bb:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    97bf:	48 85 ff             	test   %rdi,%rdi
    97c2:	74 3e                	je     9802 <fwp_hof0.constprop.0+0x1a2>
    97c4:	0f b6 0a             	movzbl (%rdx),%ecx
    97c7:	80 f9 02             	cmp    $0x2,%cl
    97ca:	0f 84 60 12 00 00    	je     aa30 <fwp_hof0.constprop.0+0x13d0>
    97d0:	80 f9 01             	cmp    $0x1,%cl
    97d3:	75 2d                	jne    9802 <fwp_hof0.constprop.0+0x1a2>
    97d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97d8:	0f b7 c0             	movzwl %ax,%eax
    97db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97de:	48 0f af c1          	imul   %rcx,%rax
    97e2:	48 c1 e8 20          	shr    $0x20,%rax
    97e6:	48 39 d0             	cmp    %rdx,%rax
    97e9:	73 17                	jae    9802 <fwp_hof0.constprop.0+0x1a2>
    97eb:	48 01 c7             	add    %rax,%rdi
    97ee:	0f b6 07             	movzbl (%rdi),%eax
    97f1:	84 c0                	test   %al,%al
    97f3:	74 0d                	je     9802 <fwp_hof0.constprop.0+0x1a2>
    97f5:	3c fd                	cmp    $0xfd,%al
    97f7:	0f 87 08 15 00 00    	ja     ad05 <fwp_hof0.constprop.0+0x16a5>
    97fd:	83 c0 01             	add    $0x1,%eax
    9800:	88 07                	mov    %al,(%rdi)
    9802:	48 8d 3d 07 98 00 00 	lea    0x9807(%rip),%rdi        # 13010 <fc37>
    9809:	e8 62 d4 ff ff       	call   6c70 <fwp_closure_drop>
    980e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9813:	48 85 c0             	test   %rax,%rax
    9816:	0f 84 e4 13 00 00    	je     ac00 <fwp_hof0.constprop.0+0x15a0>
    981c:	31 d2                	xor    %edx,%edx
    981e:	66 90                	xchg   %ax,%ax
    9820:	48 8b 40 10          	mov    0x10(%rax),%rax
    9824:	48 83 c2 01          	add    $0x1,%rdx
    9828:	48 85 c0             	test   %rax,%rax
    982b:	75 f3                	jne    9820 <fwp_hof0.constprop.0+0x1c0>
    982d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9834:	0f 87 cc 15 00 00    	ja     ae06 <fwp_hof0.constprop.0+0x17a6>
    983a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    983f:	8b 35 1b 98 00 00    	mov    0x981b(%rip),%esi        # 13060 <registered_finish.1>
    9845:	85 f6                	test   %esi,%esi
    9847:	0f 84 b3 11 00 00    	je     aa00 <fwp_hof0.constprop.0+0x13a0>
    984d:	4c 8b 35 74 98 01 00 	mov    0x19874(%rip),%r14        # 230c8 <fwp_tape_next_slot>
    9854:	48 8b 2d 7d 98 01 00 	mov    0x1987d(%rip),%rbp        # 230d8 <fwp_ntapes>
    985b:	4c 39 f5             	cmp    %r14,%rbp
    985e:	0f 8e 6c 0e 00 00    	jle    a6d0 <fwp_hof0.constprop.0+0x1070>
    9864:	49 6b c6 58          	imul   $0x58,%r14,%rax
    9868:	48 03 05 71 98 01 00 	add    0x19871(%rip),%rax        # 230e0 <fwp_tapes>
    986f:	90                   	nop
    9870:	8b 48 04             	mov    0x4(%rax),%ecx
    9873:	85 c9                	test   %ecx,%ecx
    9875:	75 0c                	jne    9883 <fwp_hof0.constprop.0+0x223>
    9877:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    987d:	0f 86 4d 0e 00 00    	jbe    a6d0 <fwp_hof0.constprop.0+0x1070>
    9883:	49 83 c6 01          	add    $0x1,%r14
    9887:	48 83 c0 58          	add    $0x58,%rax
    988b:	4c 39 f5             	cmp    %r14,%rbp
    988e:	75 e0                	jne    9870 <fwp_hof0.constprop.0+0x210>
    9890:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9897:	0f 8f 81 15 00 00    	jg     ae1e <fwp_hof0.constprop.0+0x17be>
    989d:	48 3b 2d 2c 98 01 00 	cmp    0x1982c(%rip),%rbp        # 230d0 <fwp_tapes_cap>
    98a4:	4c 8b 3d 35 98 01 00 	mov    0x19835(%rip),%r15        # 230e0 <fwp_tapes>
    98ab:	75 4c                	jne    98f9 <fwp_hof0.constprop.0+0x299>
    98ad:	48 85 ed             	test   %rbp,%rbp
    98b0:	0f 84 b0 13 00 00    	je     ac66 <fwp_hof0.constprop.0+0x1606>
    98b6:	4c 8d 74 2d 00       	lea    0x0(%rbp,%rbp,1),%r14
    98bb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    98c0:	49 39 c6             	cmp    %rax,%r14
    98c3:	4c 0f 4f f0          	cmovg  %rax,%r14
    98c7:	49 6b f6 58          	imul   $0x58,%r14,%rsi
    98cb:	4c 89 ff             	mov    %r15,%rdi
    98ce:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    98d4:	e8 c7 9c ff ff       	call   35a0 <realloc@plt>
    98d9:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    98df:	48 85 c0             	test   %rax,%rax
    98e2:	49 89 c7             	mov    %rax,%r15
    98e5:	0f 84 61 15 00 00    	je     ae4c <fwp_hof0.constprop.0+0x17ec>
    98eb:	48 89 05 ee 97 01 00 	mov    %rax,0x197ee(%rip)        # 230e0 <fwp_tapes>
    98f2:	4c 89 35 d7 97 01 00 	mov    %r14,0x197d7(%rip)        # 230d0 <fwp_tapes_cap>
    98f9:	48 6b cd 58          	imul   $0x58,%rbp,%rcx
    98fd:	31 c0                	xor    %eax,%eax
    98ff:	49 89 ee             	mov    %rbp,%r14
    9902:	4c 01 f9             	add    %r15,%rcx
    9905:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9909:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9910:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9914:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    991b:	00 
    991c:	48 29 f9             	sub    %rdi,%rcx
    991f:	83 c1 58             	add    $0x58,%ecx
    9922:	c1 e9 03             	shr    $0x3,%ecx
    9925:	f3 48 ab             	rep stos %rax,(%rdi)
    9928:	48 8d 45 01          	lea    0x1(%rbp),%rax
    992c:	48 89 05 a5 97 01 00 	mov    %rax,0x197a5(%rip)        # 230d8 <fwp_ntapes>
    9933:	49 6b ee 58          	imul   $0x58,%r14,%rbp
    9937:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    993b:	48 8d 3d 7d 57 00 00 	lea    0x577d(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    9942:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9947:	4c 01 fd             	add    %r15,%rbp
    994a:	48 c7 45 50 00 00 00 	movq   $0x0,0x50(%rbp)
    9951:	00 
    9952:	e8 29 9a ff ff       	call   3380 <getenv@plt>
    9957:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    995d:	48 85 c0             	test   %rax,%rax
    9960:	0f 84 82 0d 00 00    	je     a6e8 <fwp_hof0.constprop.0+0x1088>
    9966:	80 38 30             	cmpb   $0x30,(%rax)
    9969:	0f 85 79 0d 00 00    	jne    a6e8 <fwp_hof0.constprop.0+0x1088>
    996f:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9973:	0f 85 6f 0d 00 00    	jne    a6e8 <fwp_hof0.constprop.0+0x1088>
    9979:	8b 45 00             	mov    0x0(%rbp),%eax
    997c:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    9980:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    9984:	c7 45 04 01 00 00 00 	movl   $0x1,0x4(%rbp)
    998b:	8d 50 01             	lea    0x1(%rax),%edx
    998e:	48 8b 05 0b 61 00 00 	mov    0x610b(%rip),%rax        # faa0 <msg.4+0x20>
    9995:	48 89 0d 2c 97 01 00 	mov    %rcx,0x1972c(%rip)        # 230c8 <fwp_tape_next_slot>
    999c:	89 55 00             	mov    %edx,0x0(%rbp)
    999f:	48 89 45 48          	mov    %rax,0x48(%rbp)
    99a3:	48 8b 05 2e ba 01 00 	mov    0x1ba2e(%rip),%rax        # 253d8 <fwp_cleanups>
    99aa:	48 c7 45 40 00 00 00 	movq   $0x0,0x40(%rbp)
    99b1:	00 
    99b2:	48 85 c0             	test   %rax,%rax
    99b5:	75 15                	jne    99cc <fwp_hof0.constprop.0+0x36c>
    99b7:	e9 84 14 00 00       	jmp    ae40 <fwp_hof0.constprop.0+0x17e0>
    99bc:	0f 1f 40 00          	nopl   0x0(%rax)
    99c0:	48 8b 00             	mov    (%rax),%rax
    99c3:	48 85 c0             	test   %rax,%rax
    99c6:	0f 84 74 14 00 00    	je     ae40 <fwp_hof0.constprop.0+0x17e0>
    99cc:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    99d0:	75 ee                	jne    99c0 <fwp_hof0.constprop.0+0x360>
    99d2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    99d6:	44 89 f6             	mov    %r14d,%esi
    99d9:	48 63 07             	movslq (%rdi),%rax
    99dc:	48 89 7d 40          	mov    %rdi,0x40(%rbp)
    99e0:	89 45 4c             	mov    %eax,0x4c(%rbp)
    99e3:	85 c0                	test   %eax,%eax
    99e5:	78 09                	js     99f0 <fwp_hof0.constprop.0+0x390>
    99e7:	48 6b c0 58          	imul   $0x58,%rax,%rax
    99eb:	45 89 74 07 48       	mov    %r14d,0x48(%r15,%rax,1)
    99f0:	89 37                	mov    %esi,(%rdi)
    99f2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    99f7:	45 31 e4             	xor    %r12d,%r12d
    99fa:	48 89 f8             	mov    %rdi,%rax
    99fd:	48 85 ff             	test   %rdi,%rdi
    9a00:	0f 84 32 0e 00 00    	je     a838 <fwp_hof0.constprop.0+0x11d8>
    9a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a0d:	00 00 00 
    9a10:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a14:	49 83 c4 01          	add    $0x1,%r12
    9a18:	48 85 c0             	test   %rax,%rax
    9a1b:	75 f3                	jne    9a10 <fwp_hof0.constprop.0+0x3b0>
    9a1d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9a22:	0f 1f 00             	nopl   (%rax)
    9a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a2c:	00 00 00 00 
    9a30:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    9a34:	48 83 c0 01          	add    $0x1,%rax
    9a38:	48 85 f6             	test   %rsi,%rsi
    9a3b:	75 f3                	jne    9a30 <fwp_hof0.constprop.0+0x3d0>
    9a3d:	48 be fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rsi
    9a44:	ff ff 1f 
    9a47:	48 39 c6             	cmp    %rax,%rsi
    9a4a:	0f 82 aa 13 00 00    	jb     adfa <fwp_hof0.constprop.0+0x179a>
    9a50:	4d 85 e4             	test   %r12,%r12
    9a53:	0f 8e df 0d 00 00    	jle    a838 <fwp_hof0.constprop.0+0x11d8>
    9a59:	49 39 c4             	cmp    %rax,%r12
    9a5c:	4c 0f 47 e0          	cmova  %rax,%r12
    9a60:	4c 89 e0             	mov    %r12,%rax
    9a63:	48 c1 e8 3c          	shr    $0x3c,%rax
    9a67:	0f 85 8d 13 00 00    	jne    adfa <fwp_hof0.constprop.0+0x179a>
    9a6d:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9a71:	48 c1 e2 10          	shl    $0x10,%rdx
    9a75:	be 02 00 00 00       	mov    $0x2,%esi
    9a7a:	48 09 ca             	or     %rcx,%rdx
    9a7d:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9a84:	00 
    9a85:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9a8a:	e8 81 bf ff ff       	call   5a10 <fwp_heap_alloc>
    9a8f:	4c 89 30             	mov    %r14,(%rax)
    9a92:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9a99:	48 89 c5             	mov    %rax,%rbp
    9a9c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9aa3:	48 c1 e2 10          	shl    $0x10,%rdx
    9aa7:	48 39 d0             	cmp    %rdx,%rax
    9aaa:	0f 83 30 0e 00 00    	jae    a8e0 <fwp_hof0.constprop.0+0x1280>
    9ab0:	48 89 c2             	mov    %rax,%rdx
    9ab3:	48 c1 ea 10          	shr    $0x10,%rdx
    9ab7:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9abb:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9ac2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9ac6:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9aca:	4d 85 f6             	test   %r14,%r14
    9acd:	74 3a                	je     9b09 <fwp_hof0.constprop.0+0x4a9>
    9acf:	0f b6 32             	movzbl (%rdx),%esi
    9ad2:	40 80 fe 02          	cmp    $0x2,%sil
    9ad6:	0f 84 cb 0d 00 00    	je     a8a7 <fwp_hof0.constprop.0+0x1247>
    9adc:	40 80 fe 01          	cmp    $0x1,%sil
    9ae0:	75 27                	jne    9b09 <fwp_hof0.constprop.0+0x4a9>
    9ae2:	8b 72 18             	mov    0x18(%rdx),%esi
    9ae5:	0f b7 c0             	movzwl %ax,%eax
    9ae8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9aeb:	48 0f af c6          	imul   %rsi,%rax
    9aef:	48 c1 e8 20          	shr    $0x20,%rax
    9af3:	48 39 d0             	cmp    %rdx,%rax
    9af6:	73 11                	jae    9b09 <fwp_hof0.constprop.0+0x4a9>
    9af8:	49 01 c6             	add    %rax,%r14
    9afb:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9aff:	0f 84 b5 0d 00 00    	je     a8ba <fwp_hof0.constprop.0+0x125a>
    9b05:	41 c6 06 01          	movb   $0x1,(%r14)
    9b09:	4d 85 e4             	test   %r12,%r12
    9b0c:	74 65                	je     9b73 <fwp_hof0.constprop.0+0x513>
    9b0e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9b13:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9b18:	31 c0                	xor    %eax,%eax
    9b1a:	48 c1 e6 20          	shl    $0x20,%rsi
    9b1e:	90                   	nop
    9b1f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b26:	00 00 00 00 
    9b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b31:	00 00 00 00 
    9b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b3c:	00 00 00 00 
    9b40:	48 89 c1             	mov    %rax,%rcx
    9b43:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9b48:	48 01 f1             	add    %rsi,%rcx
    9b4b:	0f 80 bf 9b ff ff    	jo     3710 <fwp_hof0.constprop.0.cold+0x5>
    9b51:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    9b56:	48 89 c1             	mov    %rax,%rcx
    9b59:	48 83 c0 01          	add    $0x1,%rax
    9b5d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9b61:	48 c1 e1 04          	shl    $0x4,%rcx
    9b65:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    9b6a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9b6e:	4c 39 e0             	cmp    %r12,%rax
    9b71:	72 cd                	jb     9b40 <fwp_hof0.constprop.0+0x4e0>
    9b73:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9b77:	48 d1 e8             	shr    $1,%rax
    9b7a:	0f 84 70 0d 00 00    	je     a8f0 <fwp_hof0.constprop.0+0x1290>
    9b80:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9b84:	48 89 f7             	mov    %rsi,%rdi
    9b87:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9b8b:	0f 85 69 12 00 00    	jne    adfa <fwp_hof0.constprop.0+0x179a>
    9b91:	48 c7 84 24 c0 00 00 	movq   $0xffffffffffffffff,0xc0(%rsp)
    9b98:	00 ff ff ff ff 
    9b9d:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9ba1:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
    9ba8:	00 00 00 00 00 
    9bad:	48 85 f6             	test   %rsi,%rsi
    9bb0:	74 59                	je     9c0b <fwp_hof0.constprop.0+0x5ab>
    9bb2:	48 c1 e0 04          	shl    $0x4,%rax
    9bb6:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    9bbb:	49 89 d7             	mov    %rdx,%r15
    9bbe:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    9bc2:	4c 8d 74 05 f8       	lea    -0x8(%rbp,%rax,1),%r14
    9bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bce:	00 00 
    9bd0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9bd4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9bd8:	48 8d 94 24 c0 00 00 	lea    0xc0(%rsp),%rdx
    9bdf:	00 
    9be0:	48 83 c3 10          	add    $0x10,%rbx
    9be4:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9be8:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9bec:	e8 3f c4 ff ff       	call   6030 <w120>
    9bf1:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9bf6:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9bfa:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9bfe:	49 39 de             	cmp    %rbx,%r14
    9c01:	75 cd                	jne    9bd0 <fwp_hof0.constprop.0+0x570>
    9c03:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    9c08:	4c 89 fa             	mov    %r15,%rdx
    9c0b:	48 89 55 00          	mov    %rdx,0x0(%rbp)
    9c0f:	48 89 ef             	mov    %rbp,%rdi
    9c12:	e8 69 cb ff ff       	call   6780 <w176.constprop.0>
    9c17:	48 89 ef             	mov    %rbp,%rdi
    9c1a:	49 89 c6             	mov    %rax,%r14
    9c1d:	e8 8e e2 ff ff       	call   7eb0 <fwp_drop10>
    9c22:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    9c27:	4c 89 ff             	mov    %r15,%rdi
    9c2a:	e8 11 a8 ff ff       	call   4440 <fwp_tape_of>
    9c2f:	48 89 c6             	mov    %rax,%rsi
    9c32:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    9c37:	0f 85 b9 12 00 00    	jne    aef6 <fwp_hof0.constprop.0+0x1896>
    9c3d:	48 89 c7             	mov    %rax,%rdi
    9c40:	e8 7b 9f ff ff       	call   3bc0 <fwp_tape_unlink_scope>
    9c45:	48 8b 56 38          	mov    0x38(%rsi),%rdx
    9c49:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9c4e:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9c55:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    9c59:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    9c5d:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    9c62:	f3 0f 6f 56 20       	movdqu 0x20(%rsi),%xmm2
    9c67:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    9c6b:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9c6f:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9c75:	77 1a                	ja     9c91 <fwp_hof0.constprop.0+0x631>
    9c77:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    9c7c:	83 e8 01             	sub    $0x1,%eax
    9c7f:	48 98                	cltq
    9c81:	48 3b 05 40 94 01 00 	cmp    0x19440(%rip),%rax        # 230c8 <fwp_tape_next_slot>
    9c88:	7d 07                	jge    9c91 <fwp_hof0.constprop.0+0x631>
    9c8a:	48 89 05 37 94 01 00 	mov    %rax,0x19437(%rip)        # 230c8 <fwp_tape_next_slot>
    9c91:	48 8b 05 40 b7 01 00 	mov    0x1b740(%rip),%rax        # 253d8 <fwp_cleanups>
    9c98:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c9c:	4c 8d a4 24 c0 00 00 	lea    0xc0(%rsp),%r12
    9ca3:	00 
    9ca4:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    9cab:	00 
    9cac:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9cb0:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9cb7:	00 
    9cb8:	48 8d 05 31 b1 ff ff 	lea    -0x4ecf(%rip),%rax        # 4df0 <fwp_tape_buffers_release>
    9cbf:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9cc6:	00 
    9cc7:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9cce:	00 
    9ccf:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    9cd6:	00 
    9cd7:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9cde:	00 
    9cdf:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9ce3:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    9cea:	00 
    9ceb:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    9cf2:	00 
    9cf3:	48 89 05 de b6 01 00 	mov    %rax,0x1b6de(%rip)        # 253d8 <fwp_cleanups>
    9cfa:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    9d01:	00 
    9d02:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    9d09:	00 
    9d0a:	4d 85 f6             	test   %r14,%r14
    9d0d:	0f 88 2d 0d 00 00    	js     aa40 <fwp_hof0.constprop.0+0x13e0>
    9d13:	4c 89 f0             	mov    %r14,%rax
    9d16:	48 c1 f8 20          	sar    $0x20,%rax
    9d1a:	49 39 c7             	cmp    %rax,%r15
    9d1d:	0f 85 b6 10 00 00    	jne    add9 <fwp_hof0.constprop.0+0x1779>
    9d23:	45 89 f7             	mov    %r14d,%r15d
    9d26:	4c 89 fd             	mov    %r15,%rbp
    9d29:	4c 39 ff             	cmp    %r15,%rdi
    9d2c:	0f 8e 9b 10 00 00    	jle    adcd <fwp_hof0.constprop.0+0x176d>
    9d32:	4d 39 f9             	cmp    %r15,%r9
    9d35:	0f 8e c5 0b 00 00    	jle    a900 <fwp_hof0.constprop.0+0x12a0>
    9d3b:	49 39 d1             	cmp    %rdx,%r9
    9d3e:	0f 8f 04 0c 00 00    	jg     a948 <fwp_hof0.constprop.0+0x12e8>
    9d44:	48 85 c9             	test   %rcx,%rcx
    9d47:	0f 84 36 11 00 00    	je     ae83 <fwp_hof0.constprop.0+0x1823>
    9d4d:	48 89 cf             	mov    %rcx,%rdi
    9d50:	31 f6                	xor    %esi,%esi
    9d52:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    9d57:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    9d5b:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    9d62:	00 
    9d63:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9d68:	e8 33 97 ff ff       	call   34a0 <memset@plt>
    9d6d:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9d72:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    9d78:	48 89 c1             	mov    %rax,%rcx
    9d7b:	f2 0f 10 05 ad 5d 00 	movsd  0x5dad(%rip),%xmm0        # fb30 <msg.4+0xb0>
    9d82:	00 
    9d83:	f2 42 0f 58 04 f9    	addsd  (%rcx,%r15,8),%xmm0
    9d89:	f2 42 0f 11 04 f9    	movsd  %xmm0,(%rcx,%r15,8)
    9d8f:	4c 39 cd             	cmp    %r9,%rbp
    9d92:	7c 66                	jl     9dfa <fwp_hof0.constprop.0+0x79a>
    9d94:	48 8d 14 e9          	lea    (%rcx,%rbp,8),%rdx
    9d98:	4c 29 cd             	sub    %r9,%rbp
    9d9b:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    9da0:	48 8d 44 6d 00       	lea    0x0(%rbp,%rbp,2),%rax
    9da5:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9da9:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    9dad:	eb 05                	jmp    9db4 <fwp_hof0.constprop.0+0x754>
    9daf:	90                   	nop
    9db0:	48 83 e8 18          	sub    $0x18,%rax
    9db4:	f2 0f 10 02          	movsd  (%rdx),%xmm0
    9db8:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9dbc:	7a 02                	jp     9dc0 <fwp_hof0.constprop.0+0x760>
    9dbe:	74 31                	je     9df1 <fwp_hof0.constprop.0+0x791>
    9dc0:	48 63 38             	movslq (%rax),%rdi
    9dc3:	85 ff                	test   %edi,%edi
    9dc5:	78 13                	js     9dda <fwp_hof0.constprop.0+0x77a>
    9dc7:	f2 0f 10 48 08       	movsd  0x8(%rax),%xmm1
    9dcc:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9dd0:	f2 0f 58 0c f9       	addsd  (%rcx,%rdi,8),%xmm1
    9dd5:	f2 0f 11 0c f9       	movsd  %xmm1,(%rcx,%rdi,8)
    9dda:	48 63 78 04          	movslq 0x4(%rax),%rdi
    9dde:	85 ff                	test   %edi,%edi
    9de0:	78 0f                	js     9df1 <fwp_hof0.constprop.0+0x791>
    9de2:	f2 0f 59 40 10       	mulsd  0x10(%rax),%xmm0
    9de7:	f2 0f 58 04 f9       	addsd  (%rcx,%rdi,8),%xmm0
    9dec:	f2 0f 11 04 f9       	movsd  %xmm0,(%rcx,%rdi,8)
    9df1:	48 83 ea 08          	sub    $0x8,%rdx
    9df5:	48 39 c6             	cmp    %rax,%rsi
    9df8:	75 b6                	jne    9db0 <fwp_hof0.constprop.0+0x750>
    9dfa:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9e01:	ff ff 1f 
    9e04:	4c 39 c8             	cmp    %r9,%rax
    9e07:	0f 82 05 10 00 00    	jb     ae12 <fwp_hof0.constprop.0+0x17b2>
    9e0d:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    9e14:	00 
    9e15:	be 02 00 00 00       	mov    $0x2,%esi
    9e1a:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    9e1f:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    9e24:	e8 e7 bb ff ff       	call   5a10 <fwp_heap_alloc>
    9e29:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9e2e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9e33:	49 89 c7             	mov    %rax,%r15
    9e36:	4d 85 c9             	test   %r9,%r9
    9e39:	4c 89 08             	mov    %r9,(%rax)
    9e3c:	74 14                	je     9e52 <fwp_hof0.constprop.0+0x7f2>
    9e3e:	66 90                	xchg   %ax,%ax
    9e40:	48 8b 04 d9          	mov    (%rcx,%rbx,8),%rax
    9e44:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    9e49:	48 83 c3 01          	add    $0x1,%rbx
    9e4d:	49 39 d9             	cmp    %rbx,%r9
    9e50:	75 ee                	jne    9e40 <fwp_hof0.constprop.0+0x7e0>
    9e52:	4c 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%r14
    9e59:	00 
    9e5a:	4c 89 e7             	mov    %r12,%rdi
    9e5d:	4c 89 35 74 b5 01 00 	mov    %r14,0x1b574(%rip)        # 253d8 <fwp_cleanups>
    9e64:	e8 87 af ff ff       	call   4df0 <fwp_tape_buffers_release>
    9e69:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9e70:	4c 89 f8             	mov    %r15,%rax
    9e73:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9e7a:	48 c1 e2 10          	shl    $0x10,%rdx
    9e7e:	48 39 d0             	cmp    %rdx,%rax
    9e81:	73 57                	jae    9eda <fwp_hof0.constprop.0+0x87a>
    9e83:	48 89 c2             	mov    %rax,%rdx
    9e86:	48 c1 ea 10          	shr    $0x10,%rdx
    9e8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e8e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9e95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e99:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9e9d:	48 85 ed             	test   %rbp,%rbp
    9ea0:	74 38                	je     9eda <fwp_hof0.constprop.0+0x87a>
    9ea2:	0f b6 0a             	movzbl (%rdx),%ecx
    9ea5:	80 f9 02             	cmp    $0x2,%cl
    9ea8:	0f 84 c2 0b 00 00    	je     aa70 <fwp_hof0.constprop.0+0x1410>
    9eae:	80 f9 01             	cmp    $0x1,%cl
    9eb1:	75 27                	jne    9eda <fwp_hof0.constprop.0+0x87a>
    9eb3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9eb6:	0f b7 c0             	movzwl %ax,%eax
    9eb9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ebc:	48 0f af c1          	imul   %rcx,%rax
    9ec0:	48 c1 e8 20          	shr    $0x20,%rax
    9ec4:	48 39 d0             	cmp    %rdx,%rax
    9ec7:	73 11                	jae    9eda <fwp_hof0.constprop.0+0x87a>
    9ec9:	48 01 c5             	add    %rax,%rbp
    9ecc:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9ed0:	0f 84 ad 0b 00 00    	je     aa83 <fwp_hof0.constprop.0+0x1423>
    9ed6:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9eda:	4c 3b 74 24 40       	cmp    0x40(%rsp),%r14
    9edf:	0f 85 26 98 ff ff    	jne    370b <fwp_hof0.constprop.0.cold>
    9ee5:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9eec:	00 
    9eed:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    9ef2:	48 89 05 df b4 01 00 	mov    %rax,0x1b4df(%rip)        # 253d8 <fwp_cleanups>
    9ef9:	e8 a2 d0 ff ff       	call   6fa0 <fwp_tape_scope_release>
    9efe:	49 8b 07             	mov    (%r15),%rax
    9f01:	48 89 c3             	mov    %rax,%rbx
    9f04:	48 0f ba f3 3f       	btr    $0x3f,%rbx
    9f09:	48 85 c0             	test   %rax,%rax
    9f0c:	0f 88 4e 08 00 00    	js     a760 <fwp_hof0.constprop.0+0x1100>
    9f12:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9f19:	4c 89 f8             	mov    %r15,%rax
    9f1c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9f23:	48 c1 e2 10          	shl    $0x10,%rdx
    9f27:	48 39 d0             	cmp    %rdx,%rax
    9f2a:	0f 83 30 08 00 00    	jae    a760 <fwp_hof0.constprop.0+0x1100>
    9f30:	48 89 c2             	mov    %rax,%rdx
    9f33:	48 c1 ea 10          	shr    $0x10,%rdx
    9f37:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f3b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9f42:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f46:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9f4a:	48 85 c9             	test   %rcx,%rcx
    9f4d:	0f 84 0d 08 00 00    	je     a760 <fwp_hof0.constprop.0+0x1100>
    9f53:	0f b6 32             	movzbl (%rdx),%esi
    9f56:	40 80 fe 02          	cmp    $0x2,%sil
    9f5a:	0f 84 f0 07 00 00    	je     a750 <fwp_hof0.constprop.0+0x10f0>
    9f60:	40 80 fe 01          	cmp    $0x1,%sil
    9f64:	0f 85 f6 07 00 00    	jne    a760 <fwp_hof0.constprop.0+0x1100>
    9f6a:	8b 72 18             	mov    0x18(%rdx),%esi
    9f6d:	0f b7 c0             	movzwl %ax,%eax
    9f70:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f73:	48 0f af c6          	imul   %rsi,%rax
    9f77:	48 c1 e8 20          	shr    $0x20,%rax
    9f7b:	48 39 d0             	cmp    %rdx,%rax
    9f7e:	0f 83 dc 07 00 00    	jae    a760 <fwp_hof0.constprop.0+0x1100>
    9f84:	48 01 c1             	add    %rax,%rcx
    9f87:	80 39 01             	cmpb   $0x1,(%rcx)
    9f8a:	0f 85 d0 07 00 00    	jne    a760 <fwp_hof0.constprop.0+0x1100>
    9f90:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    9f95:	4c 89 fd             	mov    %r15,%rbp
    9f98:	31 ff                	xor    %edi,%edi
    9f9a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9f9f:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9fa3:	31 c0                	xor    %eax,%eax
    9fa5:	48 85 db             	test   %rbx,%rbx
    9fa8:	75 30                	jne    9fda <fwp_hof0.constprop.0+0x97a>
    9faa:	eb 44                	jmp    9ff0 <fwp_hof0.constprop.0+0x990>
    9fac:	0f 1f 40 00          	nopl   0x0(%rax)
    9fb0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9fb5:	0f 88 2a 0e 00 00    	js     ade5 <fwp_hof0.constprop.0+0x1785>
    9fbb:	f2 0f 10 05 ed 5a 00 	movsd  0x5aed(%rip),%xmm0        # fab0 <msg.4+0x30>
    9fc2:	00 
    9fc3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9fc8:	48 83 c0 01          	add    $0x1,%rax
    9fcc:	48 83 c2 08          	add    $0x8,%rdx
    9fd0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9fd5:	48 39 c3             	cmp    %rax,%rbx
    9fd8:	74 16                	je     9ff0 <fwp_hof0.constprop.0+0x990>
    9fda:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9fde:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9fe2:	79 cc                	jns    9fb0 <fwp_hof0.constprop.0+0x950>
    9fe4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9fe8:	eb c6                	jmp    9fb0 <fwp_hof0.constprop.0+0x950>
    9fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ff0:	e8 bb de ff ff       	call   7eb0 <fwp_drop10>
    9ff5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9ffa:	31 d2                	xor    %edx,%edx
    9ffc:	48 89 d8             	mov    %rbx,%rax
    9fff:	48 85 db             	test   %rbx,%rbx
    a002:	0f 84 01 0c 00 00    	je     ac09 <fwp_hof0.constprop.0+0x15a9>
    a008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a00f:	00 
    a010:	48 8b 40 10          	mov    0x10(%rax),%rax
    a014:	48 83 c2 01          	add    $0x1,%rdx
    a018:	48 85 c0             	test   %rax,%rax
    a01b:	75 f3                	jne    a010 <fwp_hof0.constprop.0+0x9b0>
    a01d:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a021:	49 89 c6             	mov    %rax,%r14
    a024:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a029:	48 85 c0             	test   %rax,%rax
    a02c:	0f 88 cb 05 00 00    	js     a5fd <fwp_hof0.constprop.0+0xf9d>
    a032:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    a039:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a03e:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    a045:	48 c1 e0 10          	shl    $0x10,%rax
    a049:	48 39 c6             	cmp    %rax,%rsi
    a04c:	0f 83 ab 05 00 00    	jae    a5fd <fwp_hof0.constprop.0+0xf9d>
    a052:	48 89 f0             	mov    %rsi,%rax
    a055:	48 c1 e8 10          	shr    $0x10,%rax
    a059:	48 8d 3c 80          	lea    (%rax,%rax,4),%rdi
    a05d:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    a064:	48 8d 3c f8          	lea    (%rax,%rdi,8),%rdi
    a068:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    a06c:	4d 85 c0             	test   %r8,%r8
    a06f:	0f 84 88 05 00 00    	je     a5fd <fwp_hof0.constprop.0+0xf9d>
    a075:	0f b6 07             	movzbl (%rdi),%eax
    a078:	3c 02                	cmp    $0x2,%al
    a07a:	0f 84 68 05 00 00    	je     a5e8 <fwp_hof0.constprop.0+0xf88>
    a080:	3c 01                	cmp    $0x1,%al
    a082:	0f 85 69 05 00 00    	jne    a5f1 <fwp_hof0.constprop.0+0xf91>
    a088:	8b 47 18             	mov    0x18(%rdi),%eax
    a08b:	0f b7 f6             	movzwl %si,%esi
    a08e:	48 0f af f0          	imul   %rax,%rsi
    a092:	8b 47 1c             	mov    0x1c(%rdi),%eax
    a095:	48 c1 ee 20          	shr    $0x20,%rsi
    a099:	48 39 c6             	cmp    %rax,%rsi
    a09c:	0f 83 4f 05 00 00    	jae    a5f1 <fwp_hof0.constprop.0+0xf91>
    a0a2:	49 01 f0             	add    %rsi,%r8
    a0a5:	41 80 38 01          	cmpb   $0x1,(%r8)
    a0a9:	0f 85 42 05 00 00    	jne    a5f1 <fwp_hof0.constprop.0+0xf91>
    a0af:	4c 39 f2             	cmp    %r14,%rdx
    a0b2:	4c 89 f0             	mov    %r14,%rax
    a0b5:	48 0f 46 c2          	cmovbe %rdx,%rax
    a0b9:	48 85 c0             	test   %rax,%rax
    a0bc:	0f 84 2f 0d 00 00    	je     adf1 <fwp_hof0.constprop.0+0x1791>
    a0c2:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    a0c9:	00 
    a0ca:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    a0ce:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a0d3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a0d8:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a0df:	00 
    a0e0:	31 d2                	xor    %edx,%edx
    a0e2:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a0e6:	eb 34                	jmp    a11c <fwp_hof0.constprop.0+0xabc>
    a0e8:	66 90                	xchg   %ax,%ax
    a0ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0f1:	00 00 00 00 
    a0f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0fc:	00 00 00 00 
    a100:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a105:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a10a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a10f:	48 83 c2 08          	add    $0x8,%rdx
    a113:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a117:	49 39 d1             	cmp    %rdx,%r9
    a11a:	74 14                	je     a130 <fwp_hof0.constprop.0+0xad0>
    a11c:	48 89 fe             	mov    %rdi,%rsi
    a11f:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a124:	79 da                	jns    a100 <fwp_hof0.constprop.0+0xaa0>
    a126:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a12a:	eb d4                	jmp    a100 <fwp_hof0.constprop.0+0xaa0>
    a12c:	0f 1f 40 00          	nopl   0x0(%rax)
    a130:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a135:	48 85 c9             	test   %rcx,%rcx
    a138:	0f 84 87 0c 00 00    	je     adc5 <fwp_hof0.constprop.0+0x1765>
    a13e:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    a145:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    a14c:	45 31 ff             	xor    %r15d,%r15d
    a14f:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    a156:	49 c1 e1 10          	shl    $0x10,%r9
    a15a:	eb 1a                	jmp    a176 <fwp_hof0.constprop.0+0xb16>
    a15c:	0f 1f 40 00          	nopl   0x0(%rax)
    a160:	49 83 c7 01          	add    $0x1,%r15
    a164:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a168:	49 39 c7             	cmp    %rax,%r15
    a16b:	0f 83 5f 01 00 00    	jae    a2d0 <fwp_hof0.constprop.0+0xc70>
    a171:	48 85 c9             	test   %rcx,%rcx
    a174:	74 56                	je     a1cc <fwp_hof0.constprop.0+0xb6c>
    a176:	48 89 ca             	mov    %rcx,%rdx
    a179:	4c 29 d2             	sub    %r10,%rdx
    a17c:	4c 39 ca             	cmp    %r9,%rdx
    a17f:	73 4b                	jae    a1cc <fwp_hof0.constprop.0+0xb6c>
    a181:	48 89 d6             	mov    %rdx,%rsi
    a184:	48 c1 ee 10          	shr    $0x10,%rsi
    a188:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a18c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a190:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a194:	48 85 ff             	test   %rdi,%rdi
    a197:	74 33                	je     a1cc <fwp_hof0.constprop.0+0xb6c>
    a199:	44 0f b6 06          	movzbl (%rsi),%r8d
    a19d:	41 80 f8 02          	cmp    $0x2,%r8b
    a1a1:	0f 84 11 01 00 00    	je     a2b8 <fwp_hof0.constprop.0+0xc58>
    a1a7:	41 80 f8 01          	cmp    $0x1,%r8b
    a1ab:	75 1f                	jne    a1cc <fwp_hof0.constprop.0+0xb6c>
    a1ad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a1b1:	0f b7 d2             	movzwl %dx,%edx
    a1b4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a1b7:	49 0f af d0          	imul   %r8,%rdx
    a1bb:	48 c1 ea 20          	shr    $0x20,%rdx
    a1bf:	48 39 f2             	cmp    %rsi,%rdx
    a1c2:	73 08                	jae    a1cc <fwp_hof0.constprop.0+0xb6c>
    a1c4:	48 01 d7             	add    %rdx,%rdi
    a1c7:	80 3f 01             	cmpb   $0x1,(%rdi)
    a1ca:	74 94                	je     a160 <fwp_hof0.constprop.0+0xb00>
    a1cc:	49 39 c7             	cmp    %rax,%r15
    a1cf:	0f 83 fb 00 00 00    	jae    a2d0 <fwp_hof0.constprop.0+0xc70>
    a1d5:	49 89 c6             	mov    %rax,%r14
    a1d8:	31 c9                	xor    %ecx,%ecx
    a1da:	48 8d ac 24 f0 00 00 	lea    0xf0(%rsp),%rbp
    a1e1:	00 
    a1e2:	eb 38                	jmp    a21c <fwp_hof0.constprop.0+0xbbc>
    a1e4:	0f 1f 40 00          	nopl   0x0(%rax)
    a1e8:	40 80 ff 01          	cmp    $0x1,%dil
    a1ec:	75 25                	jne    a213 <fwp_hof0.constprop.0+0xbb3>
    a1ee:	8b 7e 18             	mov    0x18(%rsi),%edi
    a1f1:	0f b7 c0             	movzwl %ax,%eax
    a1f4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a1f7:	48 0f af c7          	imul   %rdi,%rax
    a1fb:	48 c1 e8 20          	shr    $0x20,%rax
    a1ff:	48 39 f0             	cmp    %rsi,%rax
    a202:	73 0f                	jae    a213 <fwp_hof0.constprop.0+0xbb3>
    a204:	48 01 c2             	add    %rax,%rdx
    a207:	80 3a ff             	cmpb   $0xff,(%rdx)
    a20a:	0f 84 00 06 00 00    	je     a810 <fwp_hof0.constprop.0+0x11b0>
    a210:	c6 02 01             	movb   $0x1,(%rdx)
    a213:	4d 39 f7             	cmp    %r14,%r15
    a216:	0f 83 84 00 00 00    	jae    a2a0 <fwp_hof0.constprop.0+0xc40>
    a21c:	49 83 ee 01          	sub    $0x1,%r14
    a220:	66 48 0f 6e e9       	movq   %rcx,%xmm5
    a225:	48 89 ee             	mov    %rbp,%rsi
    a228:	bf 01 00 00 00       	mov    $0x1,%edi
    a22d:	f3 42 0f 7e 04 f3    	movq   (%rbx,%r14,8),%xmm0
    a233:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a237:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    a23e:	00 
    a23f:	e8 ec b8 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    a244:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a24b:	48 89 c1             	mov    %rax,%rcx
    a24e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a255:	48 c1 e2 10          	shl    $0x10,%rdx
    a259:	48 39 d0             	cmp    %rdx,%rax
    a25c:	73 b5                	jae    a213 <fwp_hof0.constprop.0+0xbb3>
    a25e:	48 89 c2             	mov    %rax,%rdx
    a261:	48 c1 ea 10          	shr    $0x10,%rdx
    a265:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a269:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a270:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    a274:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    a278:	48 85 d2             	test   %rdx,%rdx
    a27b:	74 96                	je     a213 <fwp_hof0.constprop.0+0xbb3>
    a27d:	0f b6 3e             	movzbl (%rsi),%edi
    a280:	40 80 ff 02          	cmp    $0x2,%dil
    a284:	0f 85 5e ff ff ff    	jne    a1e8 <fwp_hof0.constprop.0+0xb88>
    a28a:	66 85 c0             	test   %ax,%ax
    a28d:	0f 84 74 ff ff ff    	je     a207 <fwp_hof0.constprop.0+0xba7>
    a293:	4d 39 f7             	cmp    %r14,%r15
    a296:	72 84                	jb     a21c <fwp_hof0.constprop.0+0xbbc>
    a298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a29f:	00 
    a2a0:	4d 85 ff             	test   %r15,%r15
    a2a3:	75 2d                	jne    a2d2 <fwp_hof0.constprop.0+0xc72>
    a2a5:	8b 44 24 28          	mov    0x28(%rsp),%eax
    a2a9:	85 c0                	test   %eax,%eax
    a2ab:	49 0f 45 df          	cmovne %r15,%rbx
    a2af:	eb 62                	jmp    a313 <fwp_hof0.constprop.0+0xcb3>
    a2b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2b8:	66 85 d2             	test   %dx,%dx
    a2bb:	0f 84 06 ff ff ff    	je     a1c7 <fwp_hof0.constprop.0+0xb67>
    a2c1:	49 39 c7             	cmp    %rax,%r15
    a2c4:	0f 82 0b ff ff ff    	jb     a1d5 <fwp_hof0.constprop.0+0xb75>
    a2ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2d0:	31 c9                	xor    %ecx,%ecx
    a2d2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a2d7:	48 89 da             	mov    %rbx,%rdx
    a2da:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a2de:	66 90                	xchg   %ax,%ax
    a2e0:	48 8b 32             	mov    (%rdx),%rsi
    a2e3:	48 83 c2 08          	add    $0x8,%rdx
    a2e7:	48 89 c7             	mov    %rax,%rdi
    a2ea:	48 89 70 08          	mov    %rsi,0x8(%rax)
    a2ee:	48 8b 40 10          	mov    0x10(%rax),%rax
    a2f2:	4c 39 ca             	cmp    %r9,%rdx
    a2f5:	75 e9                	jne    a2e0 <fwp_hof0.constprop.0+0xc80>
    a2f7:	8b 54 24 28          	mov    0x28(%rsp),%edx
    a2fb:	48 89 4f 10          	mov    %rcx,0x10(%rdi)
    a2ff:	85 d2                	test   %edx,%edx
    a301:	0f 84 89 07 00 00    	je     aa90 <fwp_hof0.constprop.0+0x1430>
    a307:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a30c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a311:	31 db                	xor    %ebx,%ebx
    a313:	48 89 df             	mov    %rbx,%rdi
    a316:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    a31b:	e8 f0 b1 ff ff       	call   5510 <fwp_mem_free>
    a320:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a325:	e8 86 db ff ff       	call   7eb0 <fwp_drop10>
    a32a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a32f:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    a334:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a33b:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a342:	48 c1 e2 10          	shl    $0x10,%rdx
    a346:	48 39 d0             	cmp    %rdx,%rax
    a349:	73 7f                	jae    a3ca <fwp_hof0.constprop.0+0xd6a>
    a34b:	49 89 ce             	mov    %rcx,%r14
    a34e:	48 89 c2             	mov    %rax,%rdx
    a351:	49 8b bd f8 13 00 00 	mov    0x13f8(%r13),%rdi
    a358:	48 c1 ea 10          	shr    $0x10,%rdx
    a35c:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a360:	48 8d 14 d7          	lea    (%rdi,%rdx,8),%rdx
    a364:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a368:	48 85 ed             	test   %rbp,%rbp
    a36b:	0f 84 28 03 00 00    	je     a699 <fwp_hof0.constprop.0+0x1039>
    a371:	0f b6 32             	movzbl (%rdx),%esi
    a374:	40 80 fe 02          	cmp    $0x2,%sil
    a378:	0f 84 12 03 00 00    	je     a690 <fwp_hof0.constprop.0+0x1030>
    a37e:	40 80 fe 01          	cmp    $0x1,%sil
    a382:	0f 85 11 03 00 00    	jne    a699 <fwp_hof0.constprop.0+0x1039>
    a388:	8b 72 18             	mov    0x18(%rdx),%esi
    a38b:	0f b7 c0             	movzwl %ax,%eax
    a38e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a391:	48 0f af c6          	imul   %rsi,%rax
    a395:	48 c1 e8 20          	shr    $0x20,%rax
    a399:	48 39 d0             	cmp    %rdx,%rax
    a39c:	0f 83 f7 02 00 00    	jae    a699 <fwp_hof0.constprop.0+0x1039>
    a3a2:	48 01 c5             	add    %rax,%rbp
    a3a5:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a3a9:	84 c0                	test   %al,%al
    a3ab:	0f 84 e8 02 00 00    	je     a699 <fwp_hof0.constprop.0+0x1039>
    a3b1:	3c 01                	cmp    $0x1,%al
    a3b3:	0f 84 e7 06 00 00    	je     aaa0 <fwp_hof0.constprop.0+0x1440>
    a3b9:	4c 89 f1             	mov    %r14,%rcx
    a3bc:	3c ff                	cmp    $0xff,%al
    a3be:	0f 84 c0 08 00 00    	je     ac84 <fwp_hof0.constprop.0+0x1624>
    a3c4:	83 e8 01             	sub    $0x1,%eax
    a3c7:	88 45 00             	mov    %al,0x0(%rbp)
    a3ca:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
    a3d0:	0f 85 d2 02 00 00    	jne    a6a8 <fwp_hof0.constprop.0+0x1048>
    a3d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3dd:	00 00 00 
    a3e0:	48 89 cd             	mov    %rcx,%rbp
    a3e3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a3e7:	4c 89 e7             	mov    %r12,%rdi
    a3ea:	b9 01 00 00 00       	mov    $0x1,%ecx
    a3ef:	48 8d 15 ca 87 00 00 	lea    0x87ca(%rip),%rdx        # 12bc0 <d0>
    a3f6:	48 89 ee             	mov    %rbp,%rsi
    a3f9:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a400:	00 00 00 00 00 
    a405:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a40c:	00 
    a40d:	e8 0e e2 ff ff       	call   8620 <fwp_write>
    a412:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a419:	00 
    a41a:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a421:	00 
    a422:	48 8d 05 05 4c 00 00 	lea    0x4c05(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    a429:	48 85 c9             	test   %rcx,%rcx
    a42c:	48 0f 44 c8          	cmove  %rax,%rcx
    a430:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a434:	0f 87 f5 09 00 00    	ja     ae2f <fwp_hof0.constprop.0+0x17cf>
    a43a:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a43e:	be 01 00 00 00       	mov    $0x1,%esi
    a443:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a448:	e8 c3 b5 ff ff       	call   5a10 <fwp_heap_alloc>
    a44d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a452:	4c 89 fa             	mov    %r15,%rdx
    a455:	4c 89 38             	mov    %r15,(%rax)
    a458:	4c 8d 60 08          	lea    0x8(%rax),%r12
    a45c:	48 89 c3             	mov    %rax,%rbx
    a45f:	4c 89 e7             	mov    %r12,%rdi
    a462:	e8 09 91 ff ff       	call   3570 <memcpy@plt>
    a467:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a46d:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a474:	00 
    a475:	e8 26 8f ff ff       	call   33a0 <free@plt>
    a47a:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a481:	48 89 d8             	mov    %rbx,%rax
    a484:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a48b:	48 c1 e2 10          	shl    $0x10,%rdx
    a48f:	48 39 d0             	cmp    %rdx,%rax
    a492:	73 57                	jae    a4eb <fwp_hof0.constprop.0+0xe8b>
    a494:	48 89 c2             	mov    %rax,%rdx
    a497:	48 c1 ea 10          	shr    $0x10,%rdx
    a49b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a49f:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a4a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4aa:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a4ae:	4d 85 ff             	test   %r15,%r15
    a4b1:	74 38                	je     a4eb <fwp_hof0.constprop.0+0xe8b>
    a4b3:	0f b6 0a             	movzbl (%rdx),%ecx
    a4b6:	80 f9 02             	cmp    $0x2,%cl
    a4b9:	0f 84 21 07 00 00    	je     abe0 <fwp_hof0.constprop.0+0x1580>
    a4bf:	80 f9 01             	cmp    $0x1,%cl
    a4c2:	75 27                	jne    a4eb <fwp_hof0.constprop.0+0xe8b>
    a4c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4c7:	0f b7 c0             	movzwl %ax,%eax
    a4ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4cd:	48 0f af c1          	imul   %rcx,%rax
    a4d1:	48 c1 e8 20          	shr    $0x20,%rax
    a4d5:	48 39 d0             	cmp    %rdx,%rax
    a4d8:	73 11                	jae    a4eb <fwp_hof0.constprop.0+0xe8b>
    a4da:	49 01 c7             	add    %rax,%r15
    a4dd:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a4e1:	0f 84 0c 07 00 00    	je     abf3 <fwp_hof0.constprop.0+0x1593>
    a4e7:	41 c6 07 01          	movb   $0x1,(%r15)
    a4eb:	48 89 ef             	mov    %rbp,%rdi
    a4ee:	e8 cd d5 ff ff       	call   7ac0 <fwp_drop0>
    a4f3:	48 8b 13             	mov    (%rbx),%rdx
    a4f6:	be 01 00 00 00       	mov    $0x1,%esi
    a4fb:	4c 89 e7             	mov    %r12,%rdi
    a4fe:	48 8b 0d 9b ae 01 00 	mov    0x1ae9b(%rip),%rcx        # 253a0 <fwp_prog_out>
    a505:	e8 36 91 ff ff       	call   3640 <fwrite@plt>
    a50a:	48 8b 35 8f ae 01 00 	mov    0x1ae8f(%rip),%rsi        # 253a0 <fwp_prog_out>
    a511:	bf 0a 00 00 00       	mov    $0xa,%edi
    a516:	e8 a5 8f ff ff       	call   34c0 <fputc@plt>
    a51b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a522:	48 89 d8             	mov    %rbx,%rax
    a525:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a52c:	48 c1 e2 10          	shl    $0x10,%rdx
    a530:	48 39 d0             	cmp    %rdx,%rax
    a533:	73 6b                	jae    a5a0 <fwp_hof0.constprop.0+0xf40>
    a535:	48 89 c2             	mov    %rax,%rdx
    a538:	48 c1 ea 10          	shr    $0x10,%rdx
    a53c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a540:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a547:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a54b:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a54f:	48 85 ed             	test   %rbp,%rbp
    a552:	74 4c                	je     a5a0 <fwp_hof0.constprop.0+0xf40>
    a554:	0f b6 0a             	movzbl (%rdx),%ecx
    a557:	80 f9 02             	cmp    $0x2,%cl
    a55a:	0f 84 50 06 00 00    	je     abb0 <fwp_hof0.constprop.0+0x1550>
    a560:	80 f9 01             	cmp    $0x1,%cl
    a563:	75 3b                	jne    a5a0 <fwp_hof0.constprop.0+0xf40>
    a565:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a568:	0f b7 c0             	movzwl %ax,%eax
    a56b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a56e:	48 0f af c1          	imul   %rcx,%rax
    a572:	48 c1 e8 20          	shr    $0x20,%rax
    a576:	48 39 d0             	cmp    %rdx,%rax
    a579:	73 25                	jae    a5a0 <fwp_hof0.constprop.0+0xf40>
    a57b:	48 01 c5             	add    %rax,%rbp
    a57e:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a582:	84 c0                	test   %al,%al
    a584:	74 1a                	je     a5a0 <fwp_hof0.constprop.0+0xf40>
    a586:	3c 01                	cmp    $0x1,%al
    a588:	0f 84 3f 06 00 00    	je     abcd <fwp_hof0.constprop.0+0x156d>
    a58e:	3c ff                	cmp    $0xff,%al
    a590:	0f 84 79 07 00 00    	je     ad0f <fwp_hof0.constprop.0+0x16af>
    a596:	83 e8 01             	sub    $0x1,%eax
    a599:	88 45 00             	mov    %al,0x0(%rbp)
    a59c:	0f 1f 40 00          	nopl   0x0(%rax)
    a5a0:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a5a5:	48 8b 40 10          	mov    0x10(%rax),%rax
    a5a9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    a5ae:	48 85 c0             	test   %rax,%rax
    a5b1:	0f 85 e9 f0 ff ff    	jne    96a0 <fwp_hof0.constprop.0+0x40>
    a5b7:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    a5be:	00 
    a5bf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a5c6:	00 00 
    a5c8:	0f 85 5c 08 00 00    	jne    ae2a <fwp_hof0.constprop.0+0x17ca>
    a5ce:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    a5d5:	31 c0                	xor    %eax,%eax
    a5d7:	5b                   	pop    %rbx
    a5d8:	5d                   	pop    %rbp
    a5d9:	41 5c                	pop    %r12
    a5db:	41 5d                	pop    %r13
    a5dd:	41 5e                	pop    %r14
    a5df:	41 5f                	pop    %r15
    a5e1:	c3                   	ret
    a5e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5e8:	66 85 f6             	test   %si,%si
    a5eb:	0f 84 b4 fa ff ff    	je     a0a5 <fwp_hof0.constprop.0+0xa45>
    a5f1:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a5f7:	0f 84 ca 02 00 00    	je     a8c7 <fwp_hof0.constprop.0+0x1267>
    a5fd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a602:	45 31 ff             	xor    %r15d,%r15d
    a605:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a60c:	00 00 00 00 
    a610:	48 8b 40 10          	mov    0x10(%rax),%rax
    a614:	4c 89 fa             	mov    %r15,%rdx
    a617:	49 83 c7 01          	add    $0x1,%r15
    a61b:	48 85 c0             	test   %rax,%rax
    a61e:	75 f0                	jne    a610 <fwp_hof0.constprop.0+0xfb0>
    a620:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a627:	ff ff 1f 
    a62a:	4c 39 f8             	cmp    %r15,%rax
    a62d:	0f 82 c7 07 00 00    	jb     adfa <fwp_hof0.constprop.0+0x179a>
    a633:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a63a:	00 
    a63b:	be 02 00 00 00       	mov    $0x2,%esi
    a640:	e8 cb b3 ff ff       	call   5a10 <fwp_heap_alloc>
    a645:	4d 39 f7             	cmp    %r14,%r15
    a648:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a64d:	48 89 c3             	mov    %rax,%rbx
    a650:	4c 89 f0             	mov    %r14,%rax
    a653:	49 0f 46 c7          	cmovbe %r15,%rax
    a657:	48 89 d9             	mov    %rbx,%rcx
    a65a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a660:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a664:	48 83 c1 08          	add    $0x8,%rcx
    a668:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a66c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a670:	48 85 d2             	test   %rdx,%rdx
    a673:	75 eb                	jne    a660 <fwp_hof0.constprop.0+0x1000>
    a675:	48 85 c0             	test   %rax,%rax
    a678:	0f 84 5b 02 00 00    	je     a8d9 <fwp_hof0.constprop.0+0x1279>
    a67e:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    a685:	00 
    a686:	e9 43 fa ff ff       	jmp    a0ce <fwp_hof0.constprop.0+0xa6e>
    a68b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a690:	66 85 c0             	test   %ax,%ax
    a693:	0f 84 0c fd ff ff    	je     a3a5 <fwp_hof0.constprop.0+0xd45>
    a699:	4c 89 f1             	mov    %r14,%rcx
    a69c:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
    a6a2:	0f 84 38 fd ff ff    	je     a3e0 <fwp_hof0.constprop.0+0xd80>
    a6a8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a6ad:	45 31 c0             	xor    %r8d,%r8d
    a6b0:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a6b5:	48 83 e8 01          	sub    $0x1,%rax
    a6b9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a6be:	41 0f 90 c0          	seto   %r8b
    a6c2:	e9 68 f0 ff ff       	jmp    972f <fwp_hof0.constprop.0+0xcf>
    a6c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a6ce:	00 00 
    a6d0:	4c 39 f5             	cmp    %r14,%rbp
    a6d3:	0f 84 b7 f1 ff ff    	je     9890 <fwp_hof0.constprop.0+0x230>
    a6d9:	4c 8b 3d 00 8a 01 00 	mov    0x18a00(%rip),%r15        # 230e0 <fwp_tapes>
    a6e0:	e9 4e f2 ff ff       	jmp    9933 <fwp_hof0.constprop.0+0x2d3>
    a6e5:	0f 1f 00             	nopl   (%rax)
    a6e8:	48 83 3d 98 89 01 00 	cmpq   $0x0,0x18998(%rip)        # 23088 <fwp_tape_cached_bytes>
    a6ef:	00 
    a6f0:	0f 84 83 f2 ff ff    	je     9979 <fwp_hof0.constprop.0+0x319>
    a6f6:	48 8b 05 b3 89 01 00 	mov    0x189b3(%rip),%rax        # 230b0 <fwp_tape_workspace+0x10>
    a6fd:	66 0f 6f 0d 9b 89 01 	movdqa 0x1899b(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a704:	00 
    a705:	48 c7 05 78 89 01 00 	movq   $0x0,0x18978(%rip)        # 23088 <fwp_tape_cached_bytes>
    a70c:	00 00 00 00 
    a710:	48 89 45 30          	mov    %rax,0x30(%rbp)
    a714:	48 8b 05 9d 89 01 00 	mov    0x1899d(%rip),%rax        # 230b8 <fwp_tape_workspace+0x18>
    a71b:	0f 11 4d 20          	movups %xmm1,0x20(%rbp)
    a71f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a723:	48 89 45 18          	mov    %rax,0x18(%rbp)
    a727:	48 8b 05 92 89 01 00 	mov    0x18992(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a72e:	0f 29 0d 6b 89 01 00 	movaps %xmm1,0x1896b(%rip)        # 230a0 <fwp_tape_workspace>
    a735:	48 89 45 38          	mov    %rax,0x38(%rbp)
    a739:	0f 29 0d 70 89 01 00 	movaps %xmm1,0x18970(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a740:	48 c7 05 75 89 01 00 	movq   $0x0,0x18975(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a747:	00 00 00 00 
    a74b:	e9 29 f2 ff ff       	jmp    9979 <fwp_hof0.constprop.0+0x319>
    a750:	66 85 c0             	test   %ax,%ax
    a753:	0f 84 2e f8 ff ff    	je     9f87 <fwp_hof0.constprop.0+0x927>
    a759:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a760:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a767:	ff ff 1f 
    a76a:	48 39 d8             	cmp    %rbx,%rax
    a76d:	0f 82 9f 06 00 00    	jb     ae12 <fwp_hof0.constprop.0+0x17b2>
    a773:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    a77a:	00 
    a77b:	be 01 00 00 00       	mov    $0x1,%esi
    a780:	e8 8b b2 ff ff       	call   5a10 <fwp_heap_alloc>
    a785:	48 89 18             	mov    %rbx,(%rax)
    a788:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a78f:	48 89 c5             	mov    %rax,%rbp
    a792:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a797:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a79e:	48 c1 e2 10          	shl    $0x10,%rdx
    a7a2:	48 39 d0             	cmp    %rdx,%rax
    a7a5:	73 59                	jae    a800 <fwp_hof0.constprop.0+0x11a0>
    a7a7:	48 89 c2             	mov    %rax,%rdx
    a7aa:	48 c1 ea 10          	shr    $0x10,%rdx
    a7ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7b2:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a7b9:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a7bd:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    a7c1:	4d 85 f6             	test   %r14,%r14
    a7c4:	74 3a                	je     a800 <fwp_hof0.constprop.0+0x11a0>
    a7c6:	0f b6 31             	movzbl (%rcx),%esi
    a7c9:	40 80 fe 02          	cmp    $0x2,%sil
    a7cd:	0f 84 75 03 00 00    	je     ab48 <fwp_hof0.constprop.0+0x14e8>
    a7d3:	40 80 fe 01          	cmp    $0x1,%sil
    a7d7:	75 27                	jne    a800 <fwp_hof0.constprop.0+0x11a0>
    a7d9:	8b 71 18             	mov    0x18(%rcx),%esi
    a7dc:	0f b7 c0             	movzwl %ax,%eax
    a7df:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a7e2:	48 0f af c6          	imul   %rsi,%rax
    a7e6:	48 c1 e8 20          	shr    $0x20,%rax
    a7ea:	48 39 c8             	cmp    %rcx,%rax
    a7ed:	73 11                	jae    a800 <fwp_hof0.constprop.0+0x11a0>
    a7ef:	49 01 c6             	add    %rax,%r14
    a7f2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a7f6:	0f 84 5f 03 00 00    	je     ab5b <fwp_hof0.constprop.0+0x14fb>
    a7fc:	41 c6 06 01          	movb   $0x1,(%r14)
    a800:	4c 89 ff             	mov    %r15,%rdi
    a803:	e9 92 f7 ff ff       	jmp    9f9a <fwp_hof0.constprop.0+0x93a>
    a808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a80f:	00 
    a810:	48 89 d7             	mov    %rdx,%rdi
    a813:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    a818:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    a81d:	e8 ae aa ff ff       	call   52d0 <fwp_rc_forget_slot>
    a822:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    a827:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    a82c:	e9 df f9 ff ff       	jmp    a210 <fwp_hof0.constprop.0+0xbb0>
    a831:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a838:	48 c1 e2 10          	shl    $0x10,%rdx
    a83c:	be 02 00 00 00       	mov    $0x2,%esi
    a841:	bf 08 00 00 00       	mov    $0x8,%edi
    a846:	48 09 ca             	or     %rcx,%rdx
    a849:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a84e:	e8 bd b1 ff ff       	call   5a10 <fwp_heap_alloc>
    a853:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a85a:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a861:	48 89 c5             	mov    %rax,%rbp
    a864:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a86b:	48 c1 e2 10          	shl    $0x10,%rdx
    a86f:	48 39 d0             	cmp    %rdx,%rax
    a872:	73 7c                	jae    a8f0 <fwp_hof0.constprop.0+0x1290>
    a874:	48 89 c2             	mov    %rax,%rdx
    a877:	48 c1 ea 10          	shr    $0x10,%rdx
    a87b:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a87f:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a886:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a88a:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a88e:	4d 85 f6             	test   %r14,%r14
    a891:	0f 84 dc f2 ff ff    	je     9b73 <fwp_hof0.constprop.0+0x513>
    a897:	0f b6 32             	movzbl (%rdx),%esi
    a89a:	45 31 e4             	xor    %r12d,%r12d
    a89d:	40 80 fe 02          	cmp    $0x2,%sil
    a8a1:	0f 85 35 f2 ff ff    	jne    9adc <fwp_hof0.constprop.0+0x47c>
    a8a7:	66 85 c0             	test   %ax,%ax
    a8aa:	0f 85 59 f2 ff ff    	jne    9b09 <fwp_hof0.constprop.0+0x4a9>
    a8b0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a8b4:	0f 85 4b f2 ff ff    	jne    9b05 <fwp_hof0.constprop.0+0x4a5>
    a8ba:	4c 89 f7             	mov    %r14,%rdi
    a8bd:	e8 0e aa ff ff       	call   52d0 <fwp_rc_forget_slot>
    a8c2:	e9 3e f2 ff ff       	jmp    9b05 <fwp_hof0.constprop.0+0x4a5>
    a8c7:	be 02 00 00 00       	mov    $0x2,%esi
    a8cc:	bf 08 00 00 00       	mov    $0x8,%edi
    a8d1:	e8 3a b1 ff ff       	call   5a10 <fwp_heap_alloc>
    a8d6:	48 89 c3             	mov    %rax,%rbx
    a8d9:	31 c9                	xor    %ecx,%ecx
    a8db:	e9 33 fa ff ff       	jmp    a313 <fwp_hof0.constprop.0+0xcb3>
    a8e0:	4d 85 e4             	test   %r12,%r12
    a8e3:	0f 85 25 f2 ff ff    	jne    9b0e <fwp_hof0.constprop.0+0x4ae>
    a8e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8f0:	31 d2                	xor    %edx,%edx
    a8f2:	e9 14 f3 ff ff       	jmp    9c0b <fwp_hof0.constprop.0+0x5ab>
    a8f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8fe:	00 00 
    a900:	4d 8d 57 01          	lea    0x1(%r15),%r10
    a904:	4c 39 d2             	cmp    %r10,%rdx
    a907:	7c 42                	jl     a94b <fwp_hof0.constprop.0+0x12eb>
    a909:	48 85 c9             	test   %rcx,%rcx
    a90c:	0f 84 71 05 00 00    	je     ae83 <fwp_hof0.constprop.0+0x1823>
    a912:	48 89 cf             	mov    %rcx,%rdi
    a915:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a91c:	00 
    a91d:	31 f6                	xor    %esi,%esi
    a91f:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a924:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a929:	e8 72 8b ff ff       	call   34a0 <memset@plt>
    a92e:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a933:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a939:	48 89 c1             	mov    %rax,%rcx
    a93c:	e9 3a f4 ff ff       	jmp    9d7b <fwp_hof0.constprop.0+0x71b>
    a941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a948:	4d 89 ca             	mov    %r9,%r10
    a94b:	48 85 d2             	test   %rdx,%rdx
    a94e:	49 0f 44 d2          	cmove  %r10,%rdx
    a952:	eb 21                	jmp    a975 <fwp_hof0.constprop.0+0x1315>
    a954:	90                   	nop
    a955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a95c:	00 00 00 00 
    a960:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    a964:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a96b:	4c 89 d0             	mov    %r10,%rax
    a96e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a972:	48 89 c2             	mov    %rax,%rdx
    a975:	4c 39 d2             	cmp    %r10,%rdx
    a978:	7c e6                	jl     a960 <fwp_hof0.constprop.0+0x1300>
    a97a:	4c 89 54 24 58       	mov    %r10,0x58(%rsp)
    a97f:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
    a984:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    a989:	48 85 c9             	test   %rcx,%rcx
    a98c:	0f 84 de 01 00 00    	je     ab70 <fwp_hof0.constprop.0+0x1510>
    a992:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a999:	00 
    a99a:	48 89 cf             	mov    %rcx,%rdi
    a99d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a9a2:	e8 f9 8b ff ff       	call   35a0 <realloc@plt>
    a9a7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a9ac:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    a9b1:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    a9b6:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a9bc:	48 89 c1             	mov    %rax,%rcx
    a9bf:	48 85 c9             	test   %rcx,%rcx
    a9c2:	0f 84 b2 04 00 00    	je     ae7a <fwp_hof0.constprop.0+0x181a>
    a9c8:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    a9cf:	00 
    a9d0:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
    a9d7:	00 
    a9d8:	4d 85 d2             	test   %r10,%r10
    a9db:	0f 85 61 03 00 00    	jne    ad42 <fwp_hof0.constprop.0+0x16e2>
    a9e1:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a9e8:	4d 85 f6             	test   %r14,%r14
    a9eb:	0f 88 9e f3 ff ff    	js     9d8f <fwp_hof0.constprop.0+0x72f>
    a9f1:	45 89 f7             	mov    %r14d,%r15d
    a9f4:	e9 82 f3 ff ff       	jmp    9d7b <fwp_hof0.constprop.0+0x71b>
    a9f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa00:	48 8d 3d b9 c4 ff ff 	lea    -0x3b47(%rip),%rdi        # 6ec0 <fwp_tape_finish>
    aa07:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    aa0d:	e8 0e 3b 00 00       	call   e520 <atexit>
    aa12:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    aa18:	85 c0                	test   %eax,%eax
    aa1a:	0f 85 a8 04 00 00    	jne    aec8 <fwp_hof0.constprop.0+0x1868>
    aa20:	c7 05 36 86 00 00 01 	movl   $0x1,0x8636(%rip)        # 13060 <registered_finish.1>
    aa27:	00 00 00 
    aa2a:	e9 1e ee ff ff       	jmp    984d <fwp_hof0.constprop.0+0x1ed>
    aa2f:	90                   	nop
    aa30:	66 85 c0             	test   %ax,%ax
    aa33:	0f 85 c9 ed ff ff    	jne    9802 <fwp_hof0.constprop.0+0x1a2>
    aa39:	e9 b0 ed ff ff       	jmp    97ee <fwp_hof0.constprop.0+0x18e>
    aa3e:	66 90                	xchg   %ax,%ax
    aa40:	49 39 d1             	cmp    %rdx,%r9
    aa43:	0f 8f ff fe ff ff    	jg     a948 <fwp_hof0.constprop.0+0x12e8>
    aa49:	4d 85 c9             	test   %r9,%r9
    aa4c:	74 12                	je     aa60 <fwp_hof0.constprop.0+0x1400>
    aa4e:	48 85 c9             	test   %rcx,%rcx
    aa51:	0f 84 2c 04 00 00    	je     ae83 <fwp_hof0.constprop.0+0x1823>
    aa57:	4d 85 c9             	test   %r9,%r9
    aa5a:	0f 85 df 02 00 00    	jne    ad3f <fwp_hof0.constprop.0+0x16df>
    aa60:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    aa67:	e9 23 f3 ff ff       	jmp    9d8f <fwp_hof0.constprop.0+0x72f>
    aa6c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa70:	66 85 c0             	test   %ax,%ax
    aa73:	0f 85 61 f4 ff ff    	jne    9eda <fwp_hof0.constprop.0+0x87a>
    aa79:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    aa7d:	0f 85 53 f4 ff ff    	jne    9ed6 <fwp_hof0.constprop.0+0x876>
    aa83:	48 89 ef             	mov    %rbp,%rdi
    aa86:	e8 45 a8 ff ff       	call   52d0 <fwp_rc_forget_slot>
    aa8b:	e9 46 f4 ff ff       	jmp    9ed6 <fwp_hof0.constprop.0+0x876>
    aa90:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    aa95:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aa9a:	e9 74 f8 ff ff       	jmp    a313 <fwp_hof0.constprop.0+0xcb3>
    aa9f:	90                   	nop
    aaa0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    aaa5:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    aaac:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    aab3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    aab7:	48 29 f0             	sub    %rsi,%rax
    aaba:	48 c1 e2 10          	shl    $0x10,%rdx
    aabe:	48 39 d0             	cmp    %rdx,%rax
    aac1:	73 68                	jae    ab2b <fwp_hof0.constprop.0+0x14cb>
    aac3:	49 89 c0             	mov    %rax,%r8
    aac6:	49 c1 e8 10          	shr    $0x10,%r8
    aaca:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    aace:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    aad2:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    aad6:	4d 85 c0             	test   %r8,%r8
    aad9:	74 50                	je     ab2b <fwp_hof0.constprop.0+0x14cb>
    aadb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    aadf:	41 80 f9 02          	cmp    $0x2,%r9b
    aae3:	0f 84 8d 01 00 00    	je     ac76 <fwp_hof0.constprop.0+0x1616>
    aae9:	41 80 f9 01          	cmp    $0x1,%r9b
    aaed:	75 3c                	jne    ab2b <fwp_hof0.constprop.0+0x14cb>
    aaef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    aaf3:	0f b7 c0             	movzwl %ax,%eax
    aaf6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    aaf9:	49 0f af c1          	imul   %r9,%rax
    aafd:	48 c1 e8 20          	shr    $0x20,%rax
    ab01:	48 39 f8             	cmp    %rdi,%rax
    ab04:	73 25                	jae    ab2b <fwp_hof0.constprop.0+0x14cb>
    ab06:	49 01 c0             	add    %rax,%r8
    ab09:	41 80 38 01          	cmpb   $0x1,(%r8)
    ab0d:	75 1c                	jne    ab2b <fwp_hof0.constprop.0+0x14cb>
    ab0f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    ab14:	e8 f7 a9 ff ff       	call   5510 <fwp_mem_free>
    ab19:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    ab20:	49 8b b5 b0 13 00 00 	mov    0x13b0(%r13),%rsi
    ab27:	48 c1 e2 10          	shl    $0x10,%rdx
    ab2b:	48 89 d8             	mov    %rbx,%rax
    ab2e:	48 29 f0             	sub    %rsi,%rax
    ab31:	48 39 d0             	cmp    %rdx,%rax
    ab34:	0f 83 5f fb ff ff    	jae    a699 <fwp_hof0.constprop.0+0x1039>
    ab3a:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    ab3f:	e9 0a f8 ff ff       	jmp    a34e <fwp_hof0.constprop.0+0xcee>
    ab44:	0f 1f 40 00          	nopl   0x0(%rax)
    ab48:	66 85 c0             	test   %ax,%ax
    ab4b:	0f 85 af fc ff ff    	jne    a800 <fwp_hof0.constprop.0+0x11a0>
    ab51:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ab55:	0f 85 a1 fc ff ff    	jne    a7fc <fwp_hof0.constprop.0+0x119c>
    ab5b:	4c 89 f7             	mov    %r14,%rdi
    ab5e:	e8 6d a7 ff ff       	call   52d0 <fwp_rc_forget_slot>
    ab63:	e9 94 fc ff ff       	jmp    a7fc <fwp_hof0.constprop.0+0x119c>
    ab68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ab6f:	00 
    ab70:	48 89 d7             	mov    %rdx,%rdi
    ab73:	be 08 00 00 00       	mov    $0x8,%esi
    ab78:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    ab7d:	e8 7e 89 ff ff       	call   3500 <calloc@plt>
    ab82:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    ab88:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    ab8d:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    ab92:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    ab97:	48 89 c1             	mov    %rax,%rcx
    ab9a:	e9 20 fe ff ff       	jmp    a9bf <fwp_hof0.constprop.0+0x135f>
    ab9f:	90                   	nop
    aba0:	66 85 c0             	test   %ax,%ax
    aba3:	0f 85 70 eb ff ff    	jne    9719 <fwp_hof0.constprop.0+0xb9>
    aba9:	e9 57 eb ff ff       	jmp    9705 <fwp_hof0.constprop.0+0xa5>
    abae:	66 90                	xchg   %ax,%ax
    abb0:	66 85 c0             	test   %ax,%ax
    abb3:	0f 85 e7 f9 ff ff    	jne    a5a0 <fwp_hof0.constprop.0+0xf40>
    abb9:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    abbd:	84 c0                	test   %al,%al
    abbf:	0f 84 db f9 ff ff    	je     a5a0 <fwp_hof0.constprop.0+0xf40>
    abc5:	3c 01                	cmp    $0x1,%al
    abc7:	0f 85 c1 f9 ff ff    	jne    a58e <fwp_hof0.constprop.0+0xf2e>
    abcd:	48 89 df             	mov    %rbx,%rdi
    abd0:	e8 3b a9 ff ff       	call   5510 <fwp_mem_free>
    abd5:	e9 c6 f9 ff ff       	jmp    a5a0 <fwp_hof0.constprop.0+0xf40>
    abda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abe0:	66 85 c0             	test   %ax,%ax
    abe3:	0f 85 02 f9 ff ff    	jne    a4eb <fwp_hof0.constprop.0+0xe8b>
    abe9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    abed:	0f 85 f4 f8 ff ff    	jne    a4e7 <fwp_hof0.constprop.0+0xe87>
    abf3:	4c 89 ff             	mov    %r15,%rdi
    abf6:	e8 d5 a6 ff ff       	call   52d0 <fwp_rc_forget_slot>
    abfb:	e9 e7 f8 ff ff       	jmp    a4e7 <fwp_hof0.constprop.0+0xe87>
    ac00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac04:	e9 36 ec ff ff       	jmp    983f <fwp_hof0.constprop.0+0x1df>
    ac09:	48 8b 45 00          	mov    0x0(%rbp),%rax
    ac0d:	48 85 c0             	test   %rax,%rax
    ac10:	0f 88 b1 fc ff ff    	js     a8c7 <fwp_hof0.constprop.0+0x1267>
    ac16:	49 8b bd d8 13 00 00 	mov    0x13d8(%r13),%rdi
    ac1d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    ac22:	49 2b b5 b0 13 00 00 	sub    0x13b0(%r13),%rsi
    ac29:	48 c1 e7 10          	shl    $0x10,%rdi
    ac2d:	48 39 fe             	cmp    %rdi,%rsi
    ac30:	0f 83 91 fc ff ff    	jae    a8c7 <fwp_hof0.constprop.0+0x1267>
    ac36:	48 89 f1             	mov    %rsi,%rcx
    ac39:	48 c1 e9 10          	shr    $0x10,%rcx
    ac3d:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    ac41:	49 8b 8d f8 13 00 00 	mov    0x13f8(%r13),%rcx
    ac48:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    ac4c:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    ac50:	4d 85 c0             	test   %r8,%r8
    ac53:	0f 84 6e fc ff ff    	je     a8c7 <fwp_hof0.constprop.0+0x1267>
    ac59:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ac5e:	49 89 c6             	mov    %rax,%r14
    ac61:	e9 0f f4 ff ff       	jmp    a075 <fwp_hof0.constprop.0+0xa15>
    ac66:	be 58 00 00 00       	mov    $0x58,%esi
    ac6b:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ac71:	e9 55 ec ff ff       	jmp    98cb <fwp_hof0.constprop.0+0x26b>
    ac76:	66 85 c0             	test   %ax,%ax
    ac79:	0f 85 ac fe ff ff    	jne    ab2b <fwp_hof0.constprop.0+0x14cb>
    ac7f:	e9 85 fe ff ff       	jmp    ab09 <fwp_hof0.constprop.0+0x14a9>
    ac84:	48 89 ea             	mov    %rbp,%rdx
    ac87:	48 c1 ea 11          	shr    $0x11,%rdx
    ac8b:	48 31 ea             	xor    %rbp,%rdx
    ac8e:	48 89 d0             	mov    %rdx,%rax
    ac91:	48 c1 e8 09          	shr    $0x9,%rax
    ac95:	48 31 c2             	xor    %rax,%rdx
    ac98:	0f b6 d2             	movzbl %dl,%edx
    ac9b:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    aca2:	00 
    aca3:	48 85 c0             	test   %rax,%rax
    aca6:	75 21                	jne    acc9 <fwp_hof0.constprop.0+0x1669>
    aca8:	e9 86 00 00 00       	jmp    ad33 <fwp_hof0.constprop.0+0x16d3>
    acad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    acb4:	00 
    acb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    acbc:	00 00 00 00 
    acc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    acc4:	48 85 c0             	test   %rax,%rax
    acc7:	74 6a                	je     ad33 <fwp_hof0.constprop.0+0x16d3>
    acc9:	48 89 c2             	mov    %rax,%rdx
    accc:	48 39 28             	cmp    %rbp,(%rax)
    accf:	75 ef                	jne    acc0 <fwp_hof0.constprop.0+0x1660>
    acd1:	48 8b 58 08          	mov    0x8(%rax),%rbx
    acd5:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    acd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    acdd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ace4:	0f 85 e0 f6 ff ff    	jne    a3ca <fwp_hof0.constprop.0+0xd6a>
    acea:	48 89 ef             	mov    %rbp,%rdi
    aced:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    acf2:	e8 d9 a5 ff ff       	call   52d0 <fwp_rc_forget_slot>
    acf7:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    acfb:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    ad00:	e9 c5 f6 ff ff       	jmp    a3ca <fwp_hof0.constprop.0+0xd6a>
    ad05:	e8 a6 a4 ff ff       	call   51b0 <fwp_rc_wide_dup>
    ad0a:	e9 f3 ea ff ff       	jmp    9802 <fwp_hof0.constprop.0+0x1a2>
    ad0f:	48 89 e8             	mov    %rbp,%rax
    ad12:	48 c1 e8 11          	shr    $0x11,%rax
    ad16:	48 31 e8             	xor    %rbp,%rax
    ad19:	48 89 c2             	mov    %rax,%rdx
    ad1c:	48 c1 ea 09          	shr    $0x9,%rdx
    ad20:	48 31 d0             	xor    %rdx,%rax
    ad23:	0f b6 d0             	movzbl %al,%edx
    ad26:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    ad2d:	00 
    ad2e:	48 85 c0             	test   %rax,%rax
    ad31:	75 56                	jne    ad89 <fwp_hof0.constprop.0+0x1729>
    ad33:	48 8d 3d 66 4a 00 00 	lea    0x4a66(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    ad3a:	e8 21 94 ff ff       	call   4160 <fwp_trap>
    ad3f:	4d 89 ca             	mov    %r9,%r10
    ad42:	48 89 cf             	mov    %rcx,%rdi
    ad45:	31 f6                	xor    %esi,%esi
    ad47:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    ad4c:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
    ad50:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    ad57:	00 
    ad58:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    ad5d:	e8 3e 87 ff ff       	call   34a0 <memset@plt>
    ad62:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    ad67:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    ad6d:	48 89 c1             	mov    %rax,%rcx
    ad70:	e9 73 fc ff ff       	jmp    a9e8 <fwp_hof0.constprop.0+0x1388>
    ad75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad7c:	00 00 00 00 
    ad80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ad84:	48 85 c0             	test   %rax,%rax
    ad87:	74 aa                	je     ad33 <fwp_hof0.constprop.0+0x16d3>
    ad89:	48 89 c2             	mov    %rax,%rdx
    ad8c:	48 3b 28             	cmp    (%rax),%rbp
    ad8f:	75 ef                	jne    ad80 <fwp_hof0.constprop.0+0x1720>
    ad91:	48 8b 58 08          	mov    0x8(%rax),%rbx
    ad95:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    ad99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ad9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ada4:	0f 85 f6 f7 ff ff    	jne    a5a0 <fwp_hof0.constprop.0+0xf40>
    adaa:	48 89 ef             	mov    %rbp,%rdi
    adad:	e8 1e a5 ff ff       	call   52d0 <fwp_rc_forget_slot>
    adb2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    adb6:	e9 e5 f7 ff ff       	jmp    a5a0 <fwp_hof0.constprop.0+0xf40>
    adbb:	e8 f0 a3 ff ff       	call   51b0 <fwp_rc_wide_dup>
    adc0:	e9 54 e9 ff ff       	jmp    9719 <fwp_hof0.constprop.0+0xb9>
    adc5:	45 31 ff             	xor    %r15d,%r15d
    adc8:	e9 08 f4 ff ff       	jmp    a1d5 <fwp_hof0.constprop.0+0xb75>
    adcd:	48 8d 3d 30 43 00 00 	lea    0x4330(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    add4:	e8 87 93 ff ff       	call   4160 <fwp_trap>
    add9:	48 8d 3d e8 49 00 00 	lea    0x49e8(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    ade0:	e8 7b 93 ff ff       	call   4160 <fwp_trap>
    ade5:	48 8d 3d b4 4a 00 00 	lea    0x4ab4(%rip),%rdi        # f8a0 <_IO_stdin_used+0x8a0>
    adec:	e8 6f 93 ff ff       	call   4160 <fwp_trap>
    adf1:	31 db                	xor    %ebx,%ebx
    adf3:	31 c9                	xor    %ecx,%ecx
    adf5:	e9 19 f5 ff ff       	jmp    a313 <fwp_hof0.constprop.0+0xcb3>
    adfa:	48 8d 3d 2c 43 00 00 	lea    0x432c(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    ae01:	e8 5a 93 ff ff       	call   4160 <fwp_trap>
    ae06:	48 8d 3d b1 43 00 00 	lea    0x43b1(%rip),%rdi        # f1be <_IO_stdin_used+0x1be>
    ae0d:	e8 4e 93 ff ff       	call   4160 <fwp_trap>
    ae12:	48 8d 3d bf 43 00 00 	lea    0x43bf(%rip),%rdi        # f1d8 <_IO_stdin_used+0x1d8>
    ae19:	e8 42 93 ff ff       	call   4160 <fwp_trap>
    ae1e:	48 8d 3d 4b 4a 00 00 	lea    0x4a4b(%rip),%rdi        # f870 <_IO_stdin_used+0x870>
    ae25:	e8 36 93 ff ff       	call   4160 <fwp_trap>
    ae2a:	e8 11 86 ff ff       	call   3440 <__stack_chk_fail@plt>
    ae2f:	48 8d 3d b2 43 00 00 	lea    0x43b2(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    ae36:	e8 25 93 ff ff       	call   4160 <fwp_trap>
    ae3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ae40:	48 8d 3d 81 4a 00 00 	lea    0x4a81(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    ae47:	e8 14 93 ff ff       	call   4160 <fwp_trap>
    ae4c:	48 8b 0d ed 81 00 00 	mov    0x81ed(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ae53:	ba 13 00 00 00       	mov    $0x13,%edx
    ae58:	be 01 00 00 00       	mov    $0x1,%esi
    ae5d:	48 8d 3d a4 41 00 00 	lea    0x41a4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ae64:	e8 d7 87 ff ff       	call   3640 <fwrite@plt>
    ae69:	31 ff                	xor    %edi,%edi
    ae6b:	e8 20 87 ff ff       	call   3590 <fflush@plt>
    ae70:	bf 66 00 00 00       	mov    $0x66,%edi
    ae75:	e8 e6 87 ff ff       	call   3660 <_Exit@plt>
    ae7a:	4d 85 d2             	test   %r10,%r10
    ae7d:	0f 84 5e fb ff ff    	je     a9e1 <fwp_hof0.constprop.0+0x1381>
    ae83:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    ae8a:	00 
    ae8b:	4c 89 e7             	mov    %r12,%rdi
    ae8e:	48 89 05 43 a5 01 00 	mov    %rax,0x1a543(%rip)        # 253d8 <fwp_cleanups>
    ae95:	e8 56 9f ff ff       	call   4df0 <fwp_tape_buffers_release>
    ae9a:	ba 13 00 00 00       	mov    $0x13,%edx
    ae9f:	48 8b 0d 9a 81 00 00 	mov    0x819a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aea6:	be 01 00 00 00       	mov    $0x1,%esi
    aeab:	48 8d 3d 56 41 00 00 	lea    0x4156(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aeb2:	e8 89 87 ff ff       	call   3640 <fwrite@plt>
    aeb7:	31 ff                	xor    %edi,%edi
    aeb9:	e8 d2 86 ff ff       	call   3590 <fflush@plt>
    aebe:	bf 66 00 00 00       	mov    $0x66,%edi
    aec3:	e8 98 87 ff ff       	call   3660 <_Exit@plt>
    aec8:	48 8b 0d 71 81 00 00 	mov    0x8171(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aecf:	ba 13 00 00 00       	mov    $0x13,%edx
    aed4:	be 01 00 00 00       	mov    $0x1,%esi
    aed9:	48 8d 3d 28 41 00 00 	lea    0x4128(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aee0:	e8 5b 87 ff ff       	call   3640 <fwrite@plt>
    aee5:	31 ff                	xor    %edi,%edi
    aee7:	e8 a4 86 ff ff       	call   3590 <fflush@plt>
    aeec:	bf 66 00 00 00       	mov    $0x66,%edi
    aef1:	e8 6a 87 ff ff       	call   3660 <_Exit@plt>
    aef6:	48 8d 3d 13 49 00 00 	lea    0x4913(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    aefd:	e8 5e 92 ff ff       	call   4160 <fwp_trap>
    af02:	0f 1f 00             	nopl   (%rax)
    af05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af0c:	00 00 00 00 

000000000000af10 <f0>:
    af10:	41 56                	push   %r14
    af12:	4c 8d 35 27 88 01 00 	lea    0x18827(%rip),%r14        # 23740 <fwp_heap>
    af19:	41 55                	push   %r13
    af1b:	41 54                	push   %r12
    af1d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    af23:	55                   	push   %rbp
    af24:	53                   	push   %rbx
    af25:	31 db                	xor    %ebx,%ebx
    af27:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    af2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    af35:	00 00 
    af37:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    af3e:	00 
    af3f:	31 c0                	xor    %eax,%eax
    af41:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    af48:	00 
    af49:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    af50:	00 00 
    af52:	66 48 0f 6e c0       	movq   %rax,%xmm0
    af57:	48 8d 05 52 cd ff ff 	lea    -0x32ae(%rip),%rax        # 7cb0 <fwp_drop1>
    af5e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    af63:	48 8b 05 6e a4 01 00 	mov    0x1a46e(%rip),%rax        # 253d8 <fwp_cleanups>
    af6a:	48 89 25 67 a4 01 00 	mov    %rsp,0x1a467(%rip)        # 253d8 <fwp_cleanups>
    af71:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    af75:	48 89 04 24          	mov    %rax,(%rsp)
    af79:	48 8d 05 10 8c ff ff 	lea    -0x73f0(%rip),%rax        # 3b90 <fwp_range_release>
    af80:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    af85:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    af8a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    af8f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    af94:	eb 47                	jmp    afdd <f0+0xcd>
    af96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    af9d:	00 00 00 
    afa0:	80 f9 01             	cmp    $0x1,%cl
    afa3:	75 29                	jne    afce <f0+0xbe>
    afa5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    afa8:	0f b7 c0             	movzwl %ax,%eax
    afab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    afae:	48 0f af c1          	imul   %rcx,%rax
    afb2:	48 c1 e8 20          	shr    $0x20,%rax
    afb6:	48 39 d0             	cmp    %rdx,%rax
    afb9:	73 13                	jae    afce <f0+0xbe>
    afbb:	49 01 c5             	add    %rax,%r13
    afbe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    afc3:	0f 84 c7 27 00 00    	je     d790 <f0+0x2880>
    afc9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    afce:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    afd3:	49 83 ec 01          	sub    $0x1,%r12
    afd7:	0f 82 83 00 00 00    	jb     b060 <f0+0x150>
    afdd:	48 89 ee             	mov    %rbp,%rsi
    afe0:	bf 01 00 00 00       	mov    $0x1,%edi
    afe5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    afec:	00 
    afed:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    aff2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    aff9:	00 
    affa:	e8 31 ab ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    afff:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b006:	48 89 c3             	mov    %rax,%rbx
    b009:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b010:	48 c1 e2 10          	shl    $0x10,%rdx
    b014:	48 39 d0             	cmp    %rdx,%rax
    b017:	73 b5                	jae    afce <f0+0xbe>
    b019:	48 89 c2             	mov    %rax,%rdx
    b01c:	48 c1 ea 10          	shr    $0x10,%rdx
    b020:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b024:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b02b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b02f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b033:	4d 85 ed             	test   %r13,%r13
    b036:	74 96                	je     afce <f0+0xbe>
    b038:	0f b6 0a             	movzbl (%rdx),%ecx
    b03b:	80 f9 02             	cmp    $0x2,%cl
    b03e:	0f 85 5c ff ff ff    	jne    afa0 <f0+0x90>
    b044:	66 85 c0             	test   %ax,%ax
    b047:	0f 84 71 ff ff ff    	je     afbe <f0+0xae>
    b04d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b052:	49 83 ec 01          	sub    $0x1,%r12
    b056:	73 85                	jae    afdd <f0+0xcd>
    b058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b05f:	00 
    b060:	48 8b 04 24          	mov    (%rsp),%rax
    b064:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b069:	bf 01 00 00 00       	mov    $0x1,%edi
    b06e:	66 0f 6f 05 fa 4a 00 	movdqa 0x4afa(%rip),%xmm0        # fb70 <msg.4+0xf0>
    b075:	00 
    b076:	48 89 05 5b a3 01 00 	mov    %rax,0x1a35b(%rip)        # 253d8 <fwp_cleanups>
    b07d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b082:	e8 a9 aa ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b087:	48 8b 15 8a 9a 01 00 	mov    0x19a8a(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    b08e:	49 89 c5             	mov    %rax,%r13
    b091:	48 2b 05 58 9a 01 00 	sub    0x19a58(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    b098:	48 c1 e2 10          	shl    $0x10,%rdx
    b09c:	48 39 d0             	cmp    %rdx,%rax
    b09f:	73 59                	jae    b0fa <f0+0x1ea>
    b0a1:	48 89 c2             	mov    %rax,%rdx
    b0a4:	48 c1 ea 10          	shr    $0x10,%rdx
    b0a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0ac:	48 8b 15 85 9a 01 00 	mov    0x19a85(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    b0b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b0bb:	4d 85 e4             	test   %r12,%r12
    b0be:	74 3a                	je     b0fa <f0+0x1ea>
    b0c0:	0f b6 0a             	movzbl (%rdx),%ecx
    b0c3:	80 f9 02             	cmp    $0x2,%cl
    b0c6:	0f 84 74 27 00 00    	je     d840 <f0+0x2930>
    b0cc:	80 f9 01             	cmp    $0x1,%cl
    b0cf:	75 29                	jne    b0fa <f0+0x1ea>
    b0d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0d4:	0f b7 c0             	movzwl %ax,%eax
    b0d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0da:	48 0f af c1          	imul   %rcx,%rax
    b0de:	48 c1 e8 20          	shr    $0x20,%rax
    b0e2:	48 39 d0             	cmp    %rdx,%rax
    b0e5:	73 13                	jae    b0fa <f0+0x1ea>
    b0e7:	49 01 c4             	add    %rax,%r12
    b0ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0ef:	0f 84 26 29 00 00    	je     da1b <f0+0x2b0b>
    b0f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b0fa:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b0ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b104:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b109:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b110:	00 f0 3f 
    b113:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b118:	e8 13 aa ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b11d:	48 8b 15 f4 99 01 00 	mov    0x199f4(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    b124:	49 89 c5             	mov    %rax,%r13
    b127:	48 2b 05 c2 99 01 00 	sub    0x199c2(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    b12e:	48 c1 e2 10          	shl    $0x10,%rdx
    b132:	48 39 d0             	cmp    %rdx,%rax
    b135:	73 59                	jae    b190 <f0+0x280>
    b137:	48 89 c2             	mov    %rax,%rdx
    b13a:	48 c1 ea 10          	shr    $0x10,%rdx
    b13e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b142:	48 8b 15 ef 99 01 00 	mov    0x199ef(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    b149:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b14d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b151:	4d 85 e4             	test   %r12,%r12
    b154:	74 3a                	je     b190 <f0+0x280>
    b156:	0f b6 0a             	movzbl (%rdx),%ecx
    b159:	80 f9 02             	cmp    $0x2,%cl
    b15c:	0f 84 ce 26 00 00    	je     d830 <f0+0x2920>
    b162:	80 f9 01             	cmp    $0x1,%cl
    b165:	75 29                	jne    b190 <f0+0x280>
    b167:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b16a:	0f b7 c0             	movzwl %ax,%eax
    b16d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b170:	48 0f af c1          	imul   %rcx,%rax
    b174:	48 c1 e8 20          	shr    $0x20,%rax
    b178:	48 39 d0             	cmp    %rdx,%rax
    b17b:	73 13                	jae    b190 <f0+0x280>
    b17d:	49 01 c4             	add    %rax,%r12
    b180:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b185:	0f 84 9d 28 00 00    	je     da28 <f0+0x2b18>
    b18b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b190:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b195:	bf 01 00 00 00       	mov    $0x1,%edi
    b19a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b19f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b1a6:	33 f3 bf 
    b1a9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b1ae:	e8 7d a9 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b1b3:	48 8b 15 5e 99 01 00 	mov    0x1995e(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    b1ba:	49 89 c5             	mov    %rax,%r13
    b1bd:	48 2b 05 2c 99 01 00 	sub    0x1992c(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    b1c4:	48 c1 e2 10          	shl    $0x10,%rdx
    b1c8:	48 39 d0             	cmp    %rdx,%rax
    b1cb:	73 59                	jae    b226 <f0+0x316>
    b1cd:	48 89 c2             	mov    %rax,%rdx
    b1d0:	48 c1 ea 10          	shr    $0x10,%rdx
    b1d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1d8:	48 8b 15 59 99 01 00 	mov    0x19959(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    b1df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1e3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b1e7:	4d 85 e4             	test   %r12,%r12
    b1ea:	74 3a                	je     b226 <f0+0x316>
    b1ec:	0f b6 0a             	movzbl (%rdx),%ecx
    b1ef:	80 f9 02             	cmp    $0x2,%cl
    b1f2:	0f 84 28 26 00 00    	je     d820 <f0+0x2910>
    b1f8:	80 f9 01             	cmp    $0x1,%cl
    b1fb:	75 29                	jne    b226 <f0+0x316>
    b1fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b200:	0f b7 c0             	movzwl %ax,%eax
    b203:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b206:	48 0f af c1          	imul   %rcx,%rax
    b20a:	48 c1 e8 20          	shr    $0x20,%rax
    b20e:	48 39 d0             	cmp    %rdx,%rax
    b211:	73 13                	jae    b226 <f0+0x316>
    b213:	49 01 c4             	add    %rax,%r12
    b216:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b21b:	0f 84 14 28 00 00    	je     da35 <f0+0x2b25>
    b221:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b226:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b22b:	bf 01 00 00 00       	mov    $0x1,%edi
    b230:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b235:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b23c:	00 f0 3f 
    b23f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b244:	e8 e7 a8 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b249:	48 8b 15 c8 98 01 00 	mov    0x198c8(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    b250:	49 89 c5             	mov    %rax,%r13
    b253:	48 2b 05 96 98 01 00 	sub    0x19896(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    b25a:	48 c1 e2 10          	shl    $0x10,%rdx
    b25e:	48 39 d0             	cmp    %rdx,%rax
    b261:	73 59                	jae    b2bc <f0+0x3ac>
    b263:	48 89 c2             	mov    %rax,%rdx
    b266:	48 c1 ea 10          	shr    $0x10,%rdx
    b26a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b26e:	48 8b 15 c3 98 01 00 	mov    0x198c3(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    b275:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b279:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b27d:	4d 85 e4             	test   %r12,%r12
    b280:	74 3a                	je     b2bc <f0+0x3ac>
    b282:	0f b6 0a             	movzbl (%rdx),%ecx
    b285:	80 f9 02             	cmp    $0x2,%cl
    b288:	0f 84 f2 25 00 00    	je     d880 <f0+0x2970>
    b28e:	80 f9 01             	cmp    $0x1,%cl
    b291:	75 29                	jne    b2bc <f0+0x3ac>
    b293:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b296:	0f b7 c0             	movzwl %ax,%eax
    b299:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b29c:	48 0f af c1          	imul   %rcx,%rax
    b2a0:	48 c1 e8 20          	shr    $0x20,%rax
    b2a4:	48 39 d0             	cmp    %rdx,%rax
    b2a7:	73 13                	jae    b2bc <f0+0x3ac>
    b2a9:	49 01 c4             	add    %rax,%r12
    b2ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b2b1:	0f 84 8b 27 00 00    	je     da42 <f0+0x2b32>
    b2b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b2bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b2c3:	33 f3 bf 
    b2c6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b2cd:	00 
    b2ce:	bf 01 00 00 00       	mov    $0x1,%edi
    b2d3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b2da:	00 
    b2db:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b2e2:	00 
    b2e3:	e8 48 a8 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b2e8:	48 8b 15 29 98 01 00 	mov    0x19829(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    b2ef:	49 89 c5             	mov    %rax,%r13
    b2f2:	48 2b 05 f7 97 01 00 	sub    0x197f7(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    b2f9:	48 c1 e2 10          	shl    $0x10,%rdx
    b2fd:	48 39 d0             	cmp    %rdx,%rax
    b300:	73 59                	jae    b35b <f0+0x44b>
    b302:	48 89 c2             	mov    %rax,%rdx
    b305:	48 c1 ea 10          	shr    $0x10,%rdx
    b309:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b30d:	48 8b 15 24 98 01 00 	mov    0x19824(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    b314:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b318:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b31c:	4d 85 e4             	test   %r12,%r12
    b31f:	74 3a                	je     b35b <f0+0x44b>
    b321:	0f b6 0a             	movzbl (%rdx),%ecx
    b324:	80 f9 02             	cmp    $0x2,%cl
    b327:	0f 84 43 25 00 00    	je     d870 <f0+0x2960>
    b32d:	80 f9 01             	cmp    $0x1,%cl
    b330:	75 29                	jne    b35b <f0+0x44b>
    b332:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b335:	0f b7 c0             	movzwl %ax,%eax
    b338:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b33b:	48 0f af c1          	imul   %rcx,%rax
    b33f:	48 c1 e8 20          	shr    $0x20,%rax
    b343:	48 39 d0             	cmp    %rdx,%rax
    b346:	73 13                	jae    b35b <f0+0x44b>
    b348:	49 01 c4             	add    %rax,%r12
    b34b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b350:	0f 84 f9 26 00 00    	je     da4f <f0+0x2b3f>
    b356:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b35b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b362:	00 f0 3f 
    b365:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b36c:	00 
    b36d:	bf 01 00 00 00       	mov    $0x1,%edi
    b372:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b379:	00 
    b37a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b381:	00 
    b382:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b389:	33 f3 bf 
    b38c:	e8 9f a7 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b391:	48 89 c7             	mov    %rax,%rdi
    b394:	e8 17 b5 ff ff       	call   68b0 <fwp_rc_fresh>
    b399:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b3a0:	00 
    b3a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b3a6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b3ad:	00 
    b3ae:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b3b5:	00 
    b3b6:	e8 75 a7 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b3bb:	48 89 c7             	mov    %rax,%rdi
    b3be:	e8 ed b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b3c3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b3ca:	00 
    b3cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b3d7:	00 
    b3d8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b3df:	00 
    b3e0:	e8 4b a7 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b3e5:	48 89 c7             	mov    %rax,%rdi
    b3e8:	e8 c3 b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b3ed:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b3f4:	00 
    b3f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b3fa:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b401:	00 
    b402:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b409:	00 
    b40a:	e8 21 a7 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b40f:	48 89 c7             	mov    %rax,%rdi
    b412:	e8 99 b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b417:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b41e:	00 
    b41f:	bf 01 00 00 00       	mov    $0x1,%edi
    b424:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b42b:	00 
    b42c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b433:	00 
    b434:	e8 f7 a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b439:	48 89 c7             	mov    %rax,%rdi
    b43c:	e8 6f b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b441:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b448:	00 
    b449:	bf 01 00 00 00       	mov    $0x1,%edi
    b44e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b455:	00 
    b456:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b45d:	00 
    b45e:	e8 cd a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b463:	48 89 c7             	mov    %rax,%rdi
    b466:	e8 45 b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b46b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b472:	00 
    b473:	bf 01 00 00 00       	mov    $0x1,%edi
    b478:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b47f:	00 
    b480:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b487:	00 
    b488:	e8 a3 a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b48d:	48 89 c7             	mov    %rax,%rdi
    b490:	e8 1b b4 ff ff       	call   68b0 <fwp_rc_fresh>
    b495:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b49c:	00 
    b49d:	bf 01 00 00 00       	mov    $0x1,%edi
    b4a2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b4a9:	00 
    b4aa:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b4b1:	00 
    b4b2:	e8 79 a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b4b7:	48 89 c7             	mov    %rax,%rdi
    b4ba:	e8 f1 b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b4bf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b4c6:	00 
    b4c7:	bf 01 00 00 00       	mov    $0x1,%edi
    b4cc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b4d3:	00 
    b4d4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b4db:	00 
    b4dc:	e8 4f a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b4e1:	48 89 c7             	mov    %rax,%rdi
    b4e4:	e8 c7 b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b4e9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b4f0:	00 
    b4f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4f6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b4fd:	00 
    b4fe:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b505:	00 
    b506:	e8 25 a6 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b50b:	48 89 c7             	mov    %rax,%rdi
    b50e:	e8 9d b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b513:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b51a:	00 
    b51b:	bf 01 00 00 00       	mov    $0x1,%edi
    b520:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b527:	00 
    b528:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b52f:	00 
    b530:	e8 fb a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b535:	48 89 c7             	mov    %rax,%rdi
    b538:	e8 73 b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b53d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b544:	00 
    b545:	bf 01 00 00 00       	mov    $0x1,%edi
    b54a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b551:	00 
    b552:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b559:	00 
    b55a:	e8 d1 a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b55f:	48 89 c7             	mov    %rax,%rdi
    b562:	e8 49 b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b567:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b56e:	00 
    b56f:	bf 01 00 00 00       	mov    $0x1,%edi
    b574:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b57b:	00 
    b57c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b583:	00 
    b584:	e8 a7 a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b589:	48 89 c7             	mov    %rax,%rdi
    b58c:	e8 1f b3 ff ff       	call   68b0 <fwp_rc_fresh>
    b591:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b598:	00 
    b599:	bf 01 00 00 00       	mov    $0x1,%edi
    b59e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b5a5:	00 
    b5a6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b5ad:	00 
    b5ae:	e8 7d a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b5b3:	48 89 c7             	mov    %rax,%rdi
    b5b6:	e8 f5 b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b5bb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b5c2:	00 
    b5c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b5c8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b5cf:	00 
    b5d0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b5d7:	00 
    b5d8:	e8 53 a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b5dd:	48 89 c7             	mov    %rax,%rdi
    b5e0:	e8 cb b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b5e5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b5ec:	00 
    b5ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b5f2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b5f9:	00 
    b5fa:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b601:	00 
    b602:	e8 29 a5 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b607:	48 89 c7             	mov    %rax,%rdi
    b60a:	e8 a1 b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b60f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b616:	00 
    b617:	bf 01 00 00 00       	mov    $0x1,%edi
    b61c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b623:	00 
    b624:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b62b:	00 
    b62c:	e8 ff a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b631:	48 89 c7             	mov    %rax,%rdi
    b634:	e8 77 b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b639:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b640:	00 
    b641:	bf 01 00 00 00       	mov    $0x1,%edi
    b646:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b64d:	00 
    b64e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b655:	00 
    b656:	e8 d5 a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b65b:	48 89 c7             	mov    %rax,%rdi
    b65e:	e8 4d b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b663:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b66a:	00 
    b66b:	bf 01 00 00 00       	mov    $0x1,%edi
    b670:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b677:	00 
    b678:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b67f:	00 
    b680:	e8 ab a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b685:	48 89 c7             	mov    %rax,%rdi
    b688:	e8 23 b2 ff ff       	call   68b0 <fwp_rc_fresh>
    b68d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b694:	00 
    b695:	bf 01 00 00 00       	mov    $0x1,%edi
    b69a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b6a1:	00 
    b6a2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b6a9:	00 
    b6aa:	e8 81 a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b6af:	48 89 c7             	mov    %rax,%rdi
    b6b2:	e8 f9 b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b6b7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b6be:	00 
    b6bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b6cb:	00 
    b6cc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b6d3:	00 
    b6d4:	e8 57 a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b6d9:	48 89 c7             	mov    %rax,%rdi
    b6dc:	e8 cf b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b6e1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b6e8:	00 
    b6e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ee:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b6f5:	00 
    b6f6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b6fd:	00 
    b6fe:	e8 2d a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b703:	48 89 c7             	mov    %rax,%rdi
    b706:	e8 a5 b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b70b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b712:	00 
    b713:	bf 01 00 00 00       	mov    $0x1,%edi
    b718:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b71f:	00 
    b720:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b727:	00 
    b728:	e8 03 a4 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b72d:	48 89 c7             	mov    %rax,%rdi
    b730:	e8 7b b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b735:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b73c:	00 
    b73d:	bf 01 00 00 00       	mov    $0x1,%edi
    b742:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b749:	00 
    b74a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b751:	00 
    b752:	e8 d9 a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b757:	48 89 c7             	mov    %rax,%rdi
    b75a:	e8 51 b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b75f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b766:	00 
    b767:	bf 01 00 00 00       	mov    $0x1,%edi
    b76c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b773:	00 
    b774:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b77b:	00 
    b77c:	e8 af a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b781:	48 89 c7             	mov    %rax,%rdi
    b784:	e8 27 b1 ff ff       	call   68b0 <fwp_rc_fresh>
    b789:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b790:	00 
    b791:	bf 01 00 00 00       	mov    $0x1,%edi
    b796:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b79d:	00 
    b79e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b7a5:	00 
    b7a6:	e8 85 a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b7ab:	48 89 c7             	mov    %rax,%rdi
    b7ae:	e8 fd b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b7b3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b7ba:	00 
    b7bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b7c7:	00 
    b7c8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b7cf:	00 
    b7d0:	e8 5b a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b7d5:	48 89 c7             	mov    %rax,%rdi
    b7d8:	e8 d3 b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b7dd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b7e4:	00 
    b7e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ea:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b7f1:	00 
    b7f2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b7f9:	00 
    b7fa:	e8 31 a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b7ff:	48 89 c7             	mov    %rax,%rdi
    b802:	e8 a9 b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b807:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b80e:	00 
    b80f:	bf 01 00 00 00       	mov    $0x1,%edi
    b814:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b81b:	00 
    b81c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b823:	00 
    b824:	e8 07 a3 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b829:	48 89 c7             	mov    %rax,%rdi
    b82c:	e8 7f b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b831:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b838:	00 
    b839:	bf 01 00 00 00       	mov    $0x1,%edi
    b83e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b845:	00 
    b846:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b84d:	00 
    b84e:	e8 dd a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b853:	48 89 c7             	mov    %rax,%rdi
    b856:	e8 55 b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b85b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b862:	00 
    b863:	bf 01 00 00 00       	mov    $0x1,%edi
    b868:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b86f:	00 
    b870:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b877:	00 
    b878:	e8 b3 a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b87d:	48 89 c7             	mov    %rax,%rdi
    b880:	e8 2b b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b885:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b88c:	00 
    b88d:	bf 01 00 00 00       	mov    $0x1,%edi
    b892:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b899:	00 
    b89a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b8a1:	00 
    b8a2:	e8 89 a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b8a7:	48 89 c7             	mov    %rax,%rdi
    b8aa:	e8 01 b0 ff ff       	call   68b0 <fwp_rc_fresh>
    b8af:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b8b6:	00 
    b8b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8bc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b8c3:	00 
    b8c4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b8cb:	00 
    b8cc:	e8 5f a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b8d1:	48 89 c7             	mov    %rax,%rdi
    b8d4:	e8 d7 af ff ff       	call   68b0 <fwp_rc_fresh>
    b8d9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b8e0:	00 
    b8e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b8ed:	00 
    b8ee:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b8f5:	00 
    b8f6:	e8 35 a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b8fb:	48 89 c7             	mov    %rax,%rdi
    b8fe:	e8 ad af ff ff       	call   68b0 <fwp_rc_fresh>
    b903:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b90a:	00 
    b90b:	bf 01 00 00 00       	mov    $0x1,%edi
    b910:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b917:	00 
    b918:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b91f:	00 
    b920:	e8 0b a2 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b925:	48 89 c7             	mov    %rax,%rdi
    b928:	e8 83 af ff ff       	call   68b0 <fwp_rc_fresh>
    b92d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b934:	00 
    b935:	bf 01 00 00 00       	mov    $0x1,%edi
    b93a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b941:	00 
    b942:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b949:	00 
    b94a:	e8 e1 a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b94f:	48 89 c7             	mov    %rax,%rdi
    b952:	e8 59 af ff ff       	call   68b0 <fwp_rc_fresh>
    b957:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b95e:	00 
    b95f:	bf 01 00 00 00       	mov    $0x1,%edi
    b964:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b96b:	00 
    b96c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b973:	00 
    b974:	e8 b7 a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b979:	48 89 c7             	mov    %rax,%rdi
    b97c:	e8 2f af ff ff       	call   68b0 <fwp_rc_fresh>
    b981:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b988:	00 
    b989:	bf 01 00 00 00       	mov    $0x1,%edi
    b98e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b995:	00 
    b996:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b99d:	00 
    b99e:	e8 8d a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b9a3:	48 89 c7             	mov    %rax,%rdi
    b9a6:	e8 05 af ff ff       	call   68b0 <fwp_rc_fresh>
    b9ab:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b9b2:	00 
    b9b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b9bf:	00 
    b9c0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b9c7:	00 
    b9c8:	e8 63 a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b9cd:	48 89 c7             	mov    %rax,%rdi
    b9d0:	e8 db ae ff ff       	call   68b0 <fwp_rc_fresh>
    b9d5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b9dc:	00 
    b9dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b9e9:	00 
    b9ea:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b9f1:	00 
    b9f2:	e8 39 a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    b9f7:	48 89 c7             	mov    %rax,%rdi
    b9fa:	e8 b1 ae ff ff       	call   68b0 <fwp_rc_fresh>
    b9ff:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    ba06:	00 
    ba07:	bf 01 00 00 00       	mov    $0x1,%edi
    ba0c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    ba13:	00 
    ba14:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    ba1b:	00 
    ba1c:	e8 0f a1 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ba21:	48 89 c7             	mov    %rax,%rdi
    ba24:	e8 87 ae ff ff       	call   68b0 <fwp_rc_fresh>
    ba29:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    ba30:	00 
    ba31:	bf 01 00 00 00       	mov    $0x1,%edi
    ba36:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    ba3d:	00 
    ba3e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    ba45:	00 
    ba46:	e8 e5 a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ba4b:	48 89 c7             	mov    %rax,%rdi
    ba4e:	e8 5d ae ff ff       	call   68b0 <fwp_rc_fresh>
    ba53:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    ba5a:	00 
    ba5b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba60:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    ba67:	00 
    ba68:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    ba6f:	00 
    ba70:	e8 bb a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ba75:	48 89 c7             	mov    %rax,%rdi
    ba78:	e8 33 ae ff ff       	call   68b0 <fwp_rc_fresh>
    ba7d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    ba84:	00 
    ba85:	bf 01 00 00 00       	mov    $0x1,%edi
    ba8a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    ba91:	00 
    ba92:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    ba99:	00 
    ba9a:	e8 91 a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ba9f:	48 89 c7             	mov    %rax,%rdi
    baa2:	e8 09 ae ff ff       	call   68b0 <fwp_rc_fresh>
    baa7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    baae:	00 
    baaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bab4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    babb:	00 
    babc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bac3:	00 
    bac4:	e8 67 a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bac9:	48 89 c7             	mov    %rax,%rdi
    bacc:	e8 df ad ff ff       	call   68b0 <fwp_rc_fresh>
    bad1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bad8:	00 
    bad9:	bf 01 00 00 00       	mov    $0x1,%edi
    bade:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bae5:	00 
    bae6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    baed:	00 
    baee:	e8 3d a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    baf3:	48 89 c7             	mov    %rax,%rdi
    baf6:	e8 b5 ad ff ff       	call   68b0 <fwp_rc_fresh>
    bafb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bb02:	00 
    bb03:	bf 01 00 00 00       	mov    $0x1,%edi
    bb08:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bb0f:	00 
    bb10:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bb17:	00 
    bb18:	e8 13 a0 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bb1d:	48 89 c7             	mov    %rax,%rdi
    bb20:	e8 8b ad ff ff       	call   68b0 <fwp_rc_fresh>
    bb25:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bb2c:	00 
    bb2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb32:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bb39:	00 
    bb3a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bb41:	00 
    bb42:	e8 e9 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bb47:	48 89 c7             	mov    %rax,%rdi
    bb4a:	e8 61 ad ff ff       	call   68b0 <fwp_rc_fresh>
    bb4f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bb56:	00 
    bb57:	bf 01 00 00 00       	mov    $0x1,%edi
    bb5c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bb63:	00 
    bb64:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bb6b:	00 
    bb6c:	e8 bf 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bb71:	48 89 c7             	mov    %rax,%rdi
    bb74:	e8 37 ad ff ff       	call   68b0 <fwp_rc_fresh>
    bb79:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bb80:	00 
    bb81:	bf 01 00 00 00       	mov    $0x1,%edi
    bb86:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bb8d:	00 
    bb8e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bb95:	00 
    bb96:	e8 95 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bb9b:	48 89 c7             	mov    %rax,%rdi
    bb9e:	e8 0d ad ff ff       	call   68b0 <fwp_rc_fresh>
    bba3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bbaa:	00 
    bbab:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bbb7:	00 
    bbb8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bbbf:	00 
    bbc0:	e8 6b 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bbc5:	48 89 c7             	mov    %rax,%rdi
    bbc8:	e8 e3 ac ff ff       	call   68b0 <fwp_rc_fresh>
    bbcd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bbd4:	00 
    bbd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbda:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bbe1:	00 
    bbe2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bbe9:	00 
    bbea:	e8 41 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bbef:	48 89 c7             	mov    %rax,%rdi
    bbf2:	e8 b9 ac ff ff       	call   68b0 <fwp_rc_fresh>
    bbf7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bbfe:	00 
    bbff:	bf 01 00 00 00       	mov    $0x1,%edi
    bc04:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bc0b:	00 
    bc0c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bc13:	00 
    bc14:	e8 17 9f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bc19:	48 89 c7             	mov    %rax,%rdi
    bc1c:	e8 8f ac ff ff       	call   68b0 <fwp_rc_fresh>
    bc21:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bc28:	00 
    bc29:	bf 01 00 00 00       	mov    $0x1,%edi
    bc2e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bc35:	00 
    bc36:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bc3d:	00 
    bc3e:	e8 ed 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bc43:	48 89 c7             	mov    %rax,%rdi
    bc46:	e8 65 ac ff ff       	call   68b0 <fwp_rc_fresh>
    bc4b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bc52:	00 
    bc53:	bf 01 00 00 00       	mov    $0x1,%edi
    bc58:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bc5f:	00 
    bc60:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bc67:	00 
    bc68:	e8 c3 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bc6d:	48 89 c7             	mov    %rax,%rdi
    bc70:	e8 3b ac ff ff       	call   68b0 <fwp_rc_fresh>
    bc75:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bc7c:	00 
    bc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc82:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bc89:	00 
    bc8a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bc91:	00 
    bc92:	e8 99 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bc97:	48 89 c7             	mov    %rax,%rdi
    bc9a:	e8 11 ac ff ff       	call   68b0 <fwp_rc_fresh>
    bc9f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bca6:	00 
    bca7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcac:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bcb3:	00 
    bcb4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bcbb:	00 
    bcbc:	e8 6f 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bcc1:	48 89 c7             	mov    %rax,%rdi
    bcc4:	e8 e7 ab ff ff       	call   68b0 <fwp_rc_fresh>
    bcc9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bcd0:	00 
    bcd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    bcdd:	00 
    bcde:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bce5:	00 
    bce6:	e8 45 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bceb:	48 89 c7             	mov    %rax,%rdi
    bcee:	e8 bd ab ff ff       	call   68b0 <fwp_rc_fresh>
    bcf3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    bcfa:	00 
    bcfb:	bf 01 00 00 00       	mov    $0x1,%edi
    bd00:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    bd07:	00 
    bd08:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    bd0f:	00 
    bd10:	e8 1b 9e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bd15:	48 89 c7             	mov    %rax,%rdi
    bd18:	e8 93 ab ff ff       	call   68b0 <fwp_rc_fresh>
    bd1d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    bd24:	00 
    bd25:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bd31:	00 
    bd32:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bd39:	00 
    bd3a:	e8 f1 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bd3f:	48 89 c7             	mov    %rax,%rdi
    bd42:	e8 69 ab ff ff       	call   68b0 <fwp_rc_fresh>
    bd47:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bd4e:	00 
    bd4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd54:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    bd5b:	00 
    bd5c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bd63:	00 
    bd64:	e8 c7 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bd69:	48 89 c7             	mov    %rax,%rdi
    bd6c:	e8 3f ab ff ff       	call   68b0 <fwp_rc_fresh>
    bd71:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bd78:	00 
    bd79:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bd85:	00 
    bd86:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bd8d:	00 
    bd8e:	e8 9d 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bd93:	48 89 c7             	mov    %rax,%rdi
    bd96:	e8 15 ab ff ff       	call   68b0 <fwp_rc_fresh>
    bd9b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bda2:	00 
    bda3:	bf 01 00 00 00       	mov    $0x1,%edi
    bda8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bdaf:	00 
    bdb0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bdb7:	00 
    bdb8:	e8 73 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bdbd:	48 89 c7             	mov    %rax,%rdi
    bdc0:	e8 eb aa ff ff       	call   68b0 <fwp_rc_fresh>
    bdc5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bdcc:	00 
    bdcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bdd9:	00 
    bdda:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bde1:	00 
    bde2:	e8 49 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bde7:	48 89 c7             	mov    %rax,%rdi
    bdea:	e8 c1 aa ff ff       	call   68b0 <fwp_rc_fresh>
    bdef:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bdf6:	00 
    bdf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdfc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    be03:	00 
    be04:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    be0b:	00 
    be0c:	e8 1f 9d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    be11:	48 89 c7             	mov    %rax,%rdi
    be14:	e8 97 aa ff ff       	call   68b0 <fwp_rc_fresh>
    be19:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    be20:	00 
    be21:	bf 01 00 00 00       	mov    $0x1,%edi
    be26:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    be2d:	00 
    be2e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    be35:	00 
    be36:	e8 f5 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    be3b:	48 89 c7             	mov    %rax,%rdi
    be3e:	e8 6d aa ff ff       	call   68b0 <fwp_rc_fresh>
    be43:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    be4a:	00 
    be4b:	bf 01 00 00 00       	mov    $0x1,%edi
    be50:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    be57:	00 
    be58:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    be5f:	00 
    be60:	e8 cb 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    be65:	48 89 c7             	mov    %rax,%rdi
    be68:	e8 43 aa ff ff       	call   68b0 <fwp_rc_fresh>
    be6d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    be74:	00 
    be75:	bf 01 00 00 00       	mov    $0x1,%edi
    be7a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    be81:	00 
    be82:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    be89:	00 
    be8a:	e8 a1 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    be8f:	48 89 c7             	mov    %rax,%rdi
    be92:	e8 19 aa ff ff       	call   68b0 <fwp_rc_fresh>
    be97:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    be9e:	00 
    be9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bea4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    beab:	00 
    beac:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    beb3:	00 
    beb4:	e8 77 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    beb9:	48 89 c7             	mov    %rax,%rdi
    bebc:	e8 ef a9 ff ff       	call   68b0 <fwp_rc_fresh>
    bec1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bec8:	00 
    bec9:	bf 01 00 00 00       	mov    $0x1,%edi
    bece:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bed5:	00 
    bed6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bedd:	00 
    bede:	e8 4d 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bee3:	48 89 c7             	mov    %rax,%rdi
    bee6:	e8 c5 a9 ff ff       	call   68b0 <fwp_rc_fresh>
    beeb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bef2:	00 
    bef3:	bf 01 00 00 00       	mov    $0x1,%edi
    bef8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    beff:	00 
    bf00:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bf07:	00 
    bf08:	e8 23 9c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bf0d:	48 89 c7             	mov    %rax,%rdi
    bf10:	e8 9b a9 ff ff       	call   68b0 <fwp_rc_fresh>
    bf15:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bf1c:	00 
    bf1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf22:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bf29:	00 
    bf2a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bf31:	00 
    bf32:	e8 f9 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bf37:	48 89 c7             	mov    %rax,%rdi
    bf3a:	e8 71 a9 ff ff       	call   68b0 <fwp_rc_fresh>
    bf3f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bf46:	00 
    bf47:	bf 01 00 00 00       	mov    $0x1,%edi
    bf4c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bf53:	00 
    bf54:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bf5b:	00 
    bf5c:	e8 cf 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bf61:	48 89 c7             	mov    %rax,%rdi
    bf64:	e8 47 a9 ff ff       	call   68b0 <fwp_rc_fresh>
    bf69:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bf70:	00 
    bf71:	bf 01 00 00 00       	mov    $0x1,%edi
    bf76:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bf7d:	00 
    bf7e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bf85:	00 
    bf86:	e8 a5 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bf8b:	48 89 c7             	mov    %rax,%rdi
    bf8e:	e8 1d a9 ff ff       	call   68b0 <fwp_rc_fresh>
    bf93:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bf9a:	00 
    bf9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bfa7:	00 
    bfa8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bfaf:	00 
    bfb0:	e8 7b 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bfb5:	48 89 c7             	mov    %rax,%rdi
    bfb8:	e8 f3 a8 ff ff       	call   68b0 <fwp_rc_fresh>
    bfbd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bfc4:	00 
    bfc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfca:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bfd1:	00 
    bfd2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bfd9:	00 
    bfda:	e8 51 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    bfdf:	48 89 c7             	mov    %rax,%rdi
    bfe2:	e8 c9 a8 ff ff       	call   68b0 <fwp_rc_fresh>
    bfe7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bfee:	00 
    bfef:	bf 01 00 00 00       	mov    $0x1,%edi
    bff4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bffb:	00 
    bffc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c003:	00 
    c004:	e8 27 9b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c009:	48 89 c7             	mov    %rax,%rdi
    c00c:	e8 9f a8 ff ff       	call   68b0 <fwp_rc_fresh>
    c011:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c018:	00 
    c019:	bf 01 00 00 00       	mov    $0x1,%edi
    c01e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c025:	00 
    c026:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c02d:	00 
    c02e:	e8 fd 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c033:	48 89 c7             	mov    %rax,%rdi
    c036:	e8 75 a8 ff ff       	call   68b0 <fwp_rc_fresh>
    c03b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c042:	00 
    c043:	bf 01 00 00 00       	mov    $0x1,%edi
    c048:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c04f:	00 
    c050:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c057:	00 
    c058:	e8 d3 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c05d:	48 89 c7             	mov    %rax,%rdi
    c060:	e8 4b a8 ff ff       	call   68b0 <fwp_rc_fresh>
    c065:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c06c:	00 
    c06d:	bf 01 00 00 00       	mov    $0x1,%edi
    c072:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c079:	00 
    c07a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c081:	00 
    c082:	e8 a9 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c087:	48 89 c7             	mov    %rax,%rdi
    c08a:	e8 21 a8 ff ff       	call   68b0 <fwp_rc_fresh>
    c08f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c096:	00 
    c097:	bf 01 00 00 00       	mov    $0x1,%edi
    c09c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c0a3:	00 
    c0a4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c0ab:	00 
    c0ac:	e8 7f 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c0b1:	48 89 c7             	mov    %rax,%rdi
    c0b4:	e8 f7 a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c0b9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c0c0:	00 
    c0c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0c6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c0cd:	00 
    c0ce:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c0d5:	00 
    c0d6:	e8 55 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c0db:	48 89 c7             	mov    %rax,%rdi
    c0de:	e8 cd a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c0e3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c0ea:	00 
    c0eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c0f7:	00 
    c0f8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c0ff:	00 
    c100:	e8 2b 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c105:	48 89 c7             	mov    %rax,%rdi
    c108:	e8 a3 a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c10d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c114:	00 
    c115:	bf 01 00 00 00       	mov    $0x1,%edi
    c11a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c121:	00 
    c122:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c129:	00 
    c12a:	e8 01 9a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c12f:	48 89 c7             	mov    %rax,%rdi
    c132:	e8 79 a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c137:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c13e:	00 
    c13f:	bf 01 00 00 00       	mov    $0x1,%edi
    c144:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c14b:	00 
    c14c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c153:	00 
    c154:	e8 d7 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c159:	48 89 c7             	mov    %rax,%rdi
    c15c:	e8 4f a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c161:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c168:	00 
    c169:	bf 01 00 00 00       	mov    $0x1,%edi
    c16e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c175:	00 
    c176:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c17d:	00 
    c17e:	e8 ad 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c183:	48 89 c7             	mov    %rax,%rdi
    c186:	e8 25 a7 ff ff       	call   68b0 <fwp_rc_fresh>
    c18b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c192:	00 
    c193:	bf 01 00 00 00       	mov    $0x1,%edi
    c198:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c19f:	00 
    c1a0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c1a7:	00 
    c1a8:	e8 83 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c1ad:	48 89 c7             	mov    %rax,%rdi
    c1b0:	e8 fb a6 ff ff       	call   68b0 <fwp_rc_fresh>
    c1b5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c1bc:	00 
    c1bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c1c9:	00 
    c1ca:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c1d1:	00 
    c1d2:	e8 59 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c1d7:	48 89 c7             	mov    %rax,%rdi
    c1da:	e8 d1 a6 ff ff       	call   68b0 <fwp_rc_fresh>
    c1df:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c1e6:	00 
    c1e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ec:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c1f3:	00 
    c1f4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c1fb:	00 
    c1fc:	e8 2f 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c201:	48 89 c7             	mov    %rax,%rdi
    c204:	e8 a7 a6 ff ff       	call   68b0 <fwp_rc_fresh>
    c209:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c210:	00 
    c211:	bf 01 00 00 00       	mov    $0x1,%edi
    c216:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c21d:	00 
    c21e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c225:	00 
    c226:	e8 05 99 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c22b:	48 89 c7             	mov    %rax,%rdi
    c22e:	e8 7d a6 ff ff       	call   68b0 <fwp_rc_fresh>
    c233:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c23a:	00 
    c23b:	bf 01 00 00 00       	mov    $0x1,%edi
    c240:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c247:	00 
    c248:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c24f:	00 
    c250:	e8 db 98 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c255:	48 8b 15 bc 88 01 00 	mov    0x188bc(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c25c:	49 89 c5             	mov    %rax,%r13
    c25f:	48 2b 05 8a 88 01 00 	sub    0x1888a(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c266:	48 c1 e2 10          	shl    $0x10,%rdx
    c26a:	48 39 d0             	cmp    %rdx,%rax
    c26d:	73 59                	jae    c2c8 <f0+0x13b8>
    c26f:	48 89 c2             	mov    %rax,%rdx
    c272:	48 c1 ea 10          	shr    $0x10,%rdx
    c276:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c27a:	48 8b 15 b7 88 01 00 	mov    0x188b7(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c281:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c285:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c289:	4d 85 e4             	test   %r12,%r12
    c28c:	74 3a                	je     c2c8 <f0+0x13b8>
    c28e:	0f b6 0a             	movzbl (%rdx),%ecx
    c291:	80 f9 02             	cmp    $0x2,%cl
    c294:	0f 84 c6 15 00 00    	je     d860 <f0+0x2950>
    c29a:	80 f9 01             	cmp    $0x1,%cl
    c29d:	75 29                	jne    c2c8 <f0+0x13b8>
    c29f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2a2:	0f b7 c0             	movzwl %ax,%eax
    c2a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2a8:	48 0f af c1          	imul   %rcx,%rax
    c2ac:	48 c1 e8 20          	shr    $0x20,%rax
    c2b0:	48 39 d0             	cmp    %rdx,%rax
    c2b3:	73 13                	jae    c2c8 <f0+0x13b8>
    c2b5:	49 01 c4             	add    %rax,%r12
    c2b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2bd:	0f 84 99 17 00 00    	je     da5c <f0+0x2b4c>
    c2c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2c8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c2cf:	33 f3 bf 
    c2d2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c2d9:	00 
    c2da:	bf 01 00 00 00       	mov    $0x1,%edi
    c2df:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c2e6:	00 
    c2e7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c2ee:	00 
    c2ef:	e8 3c 98 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c2f4:	48 8b 15 1d 88 01 00 	mov    0x1881d(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c2fb:	49 89 c5             	mov    %rax,%r13
    c2fe:	48 2b 05 eb 87 01 00 	sub    0x187eb(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c305:	48 c1 e2 10          	shl    $0x10,%rdx
    c309:	48 39 d0             	cmp    %rdx,%rax
    c30c:	73 59                	jae    c367 <f0+0x1457>
    c30e:	48 89 c2             	mov    %rax,%rdx
    c311:	48 c1 ea 10          	shr    $0x10,%rdx
    c315:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c319:	48 8b 15 18 88 01 00 	mov    0x18818(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c320:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c324:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c328:	4d 85 e4             	test   %r12,%r12
    c32b:	74 3a                	je     c367 <f0+0x1457>
    c32d:	0f b6 0a             	movzbl (%rdx),%ecx
    c330:	80 f9 02             	cmp    $0x2,%cl
    c333:	0f 84 17 15 00 00    	je     d850 <f0+0x2940>
    c339:	80 f9 01             	cmp    $0x1,%cl
    c33c:	75 29                	jne    c367 <f0+0x1457>
    c33e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c341:	0f b7 c0             	movzwl %ax,%eax
    c344:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c347:	48 0f af c1          	imul   %rcx,%rax
    c34b:	48 c1 e8 20          	shr    $0x20,%rax
    c34f:	48 39 d0             	cmp    %rdx,%rax
    c352:	73 13                	jae    c367 <f0+0x1457>
    c354:	49 01 c4             	add    %rax,%r12
    c357:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c35c:	0f 84 07 17 00 00    	je     da69 <f0+0x2b59>
    c362:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c367:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c36e:	00 f0 3f 
    c371:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c378:	00 
    c379:	bf 01 00 00 00       	mov    $0x1,%edi
    c37e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c385:	00 
    c386:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c38d:	00 
    c38e:	e8 9d 97 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c393:	48 8b 15 7e 87 01 00 	mov    0x1877e(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c39a:	49 89 c5             	mov    %rax,%r13
    c39d:	48 2b 05 4c 87 01 00 	sub    0x1874c(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c3a4:	48 c1 e2 10          	shl    $0x10,%rdx
    c3a8:	48 39 d0             	cmp    %rdx,%rax
    c3ab:	73 59                	jae    c406 <f0+0x14f6>
    c3ad:	48 89 c2             	mov    %rax,%rdx
    c3b0:	48 c1 ea 10          	shr    $0x10,%rdx
    c3b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3b8:	48 8b 15 79 87 01 00 	mov    0x18779(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c3bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3c3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3c7:	4d 85 e4             	test   %r12,%r12
    c3ca:	74 3a                	je     c406 <f0+0x14f6>
    c3cc:	0f b6 0a             	movzbl (%rdx),%ecx
    c3cf:	80 f9 02             	cmp    $0x2,%cl
    c3d2:	0f 84 28 15 00 00    	je     d900 <f0+0x29f0>
    c3d8:	80 f9 01             	cmp    $0x1,%cl
    c3db:	75 29                	jne    c406 <f0+0x14f6>
    c3dd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3e0:	0f b7 c0             	movzwl %ax,%eax
    c3e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3e6:	48 0f af c1          	imul   %rcx,%rax
    c3ea:	48 c1 e8 20          	shr    $0x20,%rax
    c3ee:	48 39 d0             	cmp    %rdx,%rax
    c3f1:	73 13                	jae    c406 <f0+0x14f6>
    c3f3:	49 01 c4             	add    %rax,%r12
    c3f6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3fb:	0f 84 75 16 00 00    	je     da76 <f0+0x2b66>
    c401:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c406:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c40d:	33 f3 bf 
    c410:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c417:	00 
    c418:	bf 01 00 00 00       	mov    $0x1,%edi
    c41d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c424:	00 
    c425:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c42c:	00 
    c42d:	e8 fe 96 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c432:	48 8b 15 df 86 01 00 	mov    0x186df(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c439:	49 89 c5             	mov    %rax,%r13
    c43c:	48 2b 05 ad 86 01 00 	sub    0x186ad(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c443:	48 c1 e2 10          	shl    $0x10,%rdx
    c447:	48 39 d0             	cmp    %rdx,%rax
    c44a:	73 59                	jae    c4a5 <f0+0x1595>
    c44c:	48 89 c2             	mov    %rax,%rdx
    c44f:	48 c1 ea 10          	shr    $0x10,%rdx
    c453:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c457:	48 8b 15 da 86 01 00 	mov    0x186da(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c45e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c462:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c466:	4d 85 e4             	test   %r12,%r12
    c469:	74 3a                	je     c4a5 <f0+0x1595>
    c46b:	0f b6 0a             	movzbl (%rdx),%ecx
    c46e:	80 f9 02             	cmp    $0x2,%cl
    c471:	0f 84 79 14 00 00    	je     d8f0 <f0+0x29e0>
    c477:	80 f9 01             	cmp    $0x1,%cl
    c47a:	75 29                	jne    c4a5 <f0+0x1595>
    c47c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c47f:	0f b7 c0             	movzwl %ax,%eax
    c482:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c485:	48 0f af c1          	imul   %rcx,%rax
    c489:	48 c1 e8 20          	shr    $0x20,%rax
    c48d:	48 39 d0             	cmp    %rdx,%rax
    c490:	73 13                	jae    c4a5 <f0+0x1595>
    c492:	49 01 c4             	add    %rax,%r12
    c495:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c49a:	0f 84 e3 15 00 00    	je     da83 <f0+0x2b73>
    c4a0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4a5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4ac:	00 f0 3f 
    c4af:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c4b6:	00 
    c4b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c4bc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c4c3:	00 
    c4c4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c4cb:	00 
    c4cc:	e8 5f 96 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c4d1:	48 8b 15 40 86 01 00 	mov    0x18640(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c4d8:	49 89 c5             	mov    %rax,%r13
    c4db:	48 2b 05 0e 86 01 00 	sub    0x1860e(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c4e2:	48 c1 e2 10          	shl    $0x10,%rdx
    c4e6:	48 39 d0             	cmp    %rdx,%rax
    c4e9:	73 59                	jae    c544 <f0+0x1634>
    c4eb:	48 89 c2             	mov    %rax,%rdx
    c4ee:	48 c1 ea 10          	shr    $0x10,%rdx
    c4f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4f6:	48 8b 15 3b 86 01 00 	mov    0x1863b(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c4fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c501:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c505:	4d 85 e4             	test   %r12,%r12
    c508:	74 3a                	je     c544 <f0+0x1634>
    c50a:	0f b6 0a             	movzbl (%rdx),%ecx
    c50d:	80 f9 02             	cmp    $0x2,%cl
    c510:	0f 84 ca 13 00 00    	je     d8e0 <f0+0x29d0>
    c516:	80 f9 01             	cmp    $0x1,%cl
    c519:	75 29                	jne    c544 <f0+0x1634>
    c51b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c51e:	0f b7 c0             	movzwl %ax,%eax
    c521:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c524:	48 0f af c1          	imul   %rcx,%rax
    c528:	48 c1 e8 20          	shr    $0x20,%rax
    c52c:	48 39 d0             	cmp    %rdx,%rax
    c52f:	73 13                	jae    c544 <f0+0x1634>
    c531:	49 01 c4             	add    %rax,%r12
    c534:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c539:	0f 84 51 15 00 00    	je     da90 <f0+0x2b80>
    c53f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c544:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c54b:	33 f3 bf 
    c54e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c555:	00 
    c556:	bf 01 00 00 00       	mov    $0x1,%edi
    c55b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c562:	00 
    c563:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c56a:	00 
    c56b:	e8 c0 95 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c570:	48 8b 15 a1 85 01 00 	mov    0x185a1(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c577:	49 89 c5             	mov    %rax,%r13
    c57a:	48 2b 05 6f 85 01 00 	sub    0x1856f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c581:	48 c1 e2 10          	shl    $0x10,%rdx
    c585:	48 39 d0             	cmp    %rdx,%rax
    c588:	73 59                	jae    c5e3 <f0+0x16d3>
    c58a:	48 89 c2             	mov    %rax,%rdx
    c58d:	48 c1 ea 10          	shr    $0x10,%rdx
    c591:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c595:	48 8b 15 9c 85 01 00 	mov    0x1859c(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c59c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5a0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5a4:	4d 85 e4             	test   %r12,%r12
    c5a7:	74 3a                	je     c5e3 <f0+0x16d3>
    c5a9:	0f b6 0a             	movzbl (%rdx),%ecx
    c5ac:	80 f9 02             	cmp    $0x2,%cl
    c5af:	0f 84 1b 13 00 00    	je     d8d0 <f0+0x29c0>
    c5b5:	80 f9 01             	cmp    $0x1,%cl
    c5b8:	75 29                	jne    c5e3 <f0+0x16d3>
    c5ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5bd:	0f b7 c0             	movzwl %ax,%eax
    c5c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5c3:	48 0f af c1          	imul   %rcx,%rax
    c5c7:	48 c1 e8 20          	shr    $0x20,%rax
    c5cb:	48 39 d0             	cmp    %rdx,%rax
    c5ce:	73 13                	jae    c5e3 <f0+0x16d3>
    c5d0:	49 01 c4             	add    %rax,%r12
    c5d3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5d8:	0f 84 bf 14 00 00    	je     da9d <f0+0x2b8d>
    c5de:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5e3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c5ea:	00 f0 3f 
    c5ed:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c5f4:	00 
    c5f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c5fa:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c601:	00 
    c602:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c609:	00 
    c60a:	e8 21 95 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c60f:	48 8b 15 02 85 01 00 	mov    0x18502(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c616:	49 89 c5             	mov    %rax,%r13
    c619:	48 2b 05 d0 84 01 00 	sub    0x184d0(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c620:	48 c1 e2 10          	shl    $0x10,%rdx
    c624:	48 39 d0             	cmp    %rdx,%rax
    c627:	73 59                	jae    c682 <f0+0x1772>
    c629:	48 89 c2             	mov    %rax,%rdx
    c62c:	48 c1 ea 10          	shr    $0x10,%rdx
    c630:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c634:	48 8b 15 fd 84 01 00 	mov    0x184fd(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c63b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c63f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c643:	4d 85 e4             	test   %r12,%r12
    c646:	74 3a                	je     c682 <f0+0x1772>
    c648:	0f b6 0a             	movzbl (%rdx),%ecx
    c64b:	80 f9 02             	cmp    $0x2,%cl
    c64e:	0f 84 6c 12 00 00    	je     d8c0 <f0+0x29b0>
    c654:	80 f9 01             	cmp    $0x1,%cl
    c657:	75 29                	jne    c682 <f0+0x1772>
    c659:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c65c:	0f b7 c0             	movzwl %ax,%eax
    c65f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c662:	48 0f af c1          	imul   %rcx,%rax
    c666:	48 c1 e8 20          	shr    $0x20,%rax
    c66a:	48 39 d0             	cmp    %rdx,%rax
    c66d:	73 13                	jae    c682 <f0+0x1772>
    c66f:	49 01 c4             	add    %rax,%r12
    c672:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c677:	0f 84 2d 14 00 00    	je     daaa <f0+0x2b9a>
    c67d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c682:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c689:	33 f3 bf 
    c68c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c693:	00 
    c694:	bf 01 00 00 00       	mov    $0x1,%edi
    c699:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c6a0:	00 
    c6a1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c6a8:	00 
    c6a9:	e8 82 94 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c6ae:	48 8b 15 63 84 01 00 	mov    0x18463(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c6b5:	49 89 c5             	mov    %rax,%r13
    c6b8:	48 2b 05 31 84 01 00 	sub    0x18431(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c6bf:	48 c1 e2 10          	shl    $0x10,%rdx
    c6c3:	48 39 d0             	cmp    %rdx,%rax
    c6c6:	73 59                	jae    c721 <f0+0x1811>
    c6c8:	48 89 c2             	mov    %rax,%rdx
    c6cb:	48 c1 ea 10          	shr    $0x10,%rdx
    c6cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6d3:	48 8b 15 5e 84 01 00 	mov    0x1845e(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c6da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6de:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6e2:	4d 85 e4             	test   %r12,%r12
    c6e5:	74 3a                	je     c721 <f0+0x1811>
    c6e7:	0f b6 0a             	movzbl (%rdx),%ecx
    c6ea:	80 f9 02             	cmp    $0x2,%cl
    c6ed:	0f 84 bd 11 00 00    	je     d8b0 <f0+0x29a0>
    c6f3:	80 f9 01             	cmp    $0x1,%cl
    c6f6:	75 29                	jne    c721 <f0+0x1811>
    c6f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6fb:	0f b7 c0             	movzwl %ax,%eax
    c6fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c701:	48 0f af c1          	imul   %rcx,%rax
    c705:	48 c1 e8 20          	shr    $0x20,%rax
    c709:	48 39 d0             	cmp    %rdx,%rax
    c70c:	73 13                	jae    c721 <f0+0x1811>
    c70e:	49 01 c4             	add    %rax,%r12
    c711:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c716:	0f 84 9b 13 00 00    	je     dab7 <f0+0x2ba7>
    c71c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c721:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c728:	00 f0 3f 
    c72b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c732:	00 
    c733:	bf 01 00 00 00       	mov    $0x1,%edi
    c738:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c73f:	00 
    c740:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c747:	00 
    c748:	e8 e3 93 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c74d:	48 8b 15 c4 83 01 00 	mov    0x183c4(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c754:	49 89 c5             	mov    %rax,%r13
    c757:	48 2b 05 92 83 01 00 	sub    0x18392(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c75e:	48 c1 e2 10          	shl    $0x10,%rdx
    c762:	48 39 d0             	cmp    %rdx,%rax
    c765:	73 59                	jae    c7c0 <f0+0x18b0>
    c767:	48 89 c2             	mov    %rax,%rdx
    c76a:	48 c1 ea 10          	shr    $0x10,%rdx
    c76e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c772:	48 8b 15 bf 83 01 00 	mov    0x183bf(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c779:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c77d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c781:	4d 85 e4             	test   %r12,%r12
    c784:	74 3a                	je     c7c0 <f0+0x18b0>
    c786:	0f b6 0a             	movzbl (%rdx),%ecx
    c789:	80 f9 02             	cmp    $0x2,%cl
    c78c:	0f 84 0e 11 00 00    	je     d8a0 <f0+0x2990>
    c792:	80 f9 01             	cmp    $0x1,%cl
    c795:	75 29                	jne    c7c0 <f0+0x18b0>
    c797:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c79a:	0f b7 c0             	movzwl %ax,%eax
    c79d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7a0:	48 0f af c1          	imul   %rcx,%rax
    c7a4:	48 c1 e8 20          	shr    $0x20,%rax
    c7a8:	48 39 d0             	cmp    %rdx,%rax
    c7ab:	73 13                	jae    c7c0 <f0+0x18b0>
    c7ad:	49 01 c4             	add    %rax,%r12
    c7b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7b5:	0f 84 09 13 00 00    	je     dac4 <f0+0x2bb4>
    c7bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7c7:	33 f3 bf 
    c7ca:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c7d1:	00 
    c7d2:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c7de:	00 
    c7df:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c7e6:	00 
    c7e7:	e8 44 93 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c7ec:	48 8b 15 25 83 01 00 	mov    0x18325(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c7f3:	49 89 c5             	mov    %rax,%r13
    c7f6:	48 2b 05 f3 82 01 00 	sub    0x182f3(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c7fd:	48 c1 e2 10          	shl    $0x10,%rdx
    c801:	48 39 d0             	cmp    %rdx,%rax
    c804:	73 59                	jae    c85f <f0+0x194f>
    c806:	48 89 c2             	mov    %rax,%rdx
    c809:	48 c1 ea 10          	shr    $0x10,%rdx
    c80d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c811:	48 8b 15 20 83 01 00 	mov    0x18320(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c818:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c81c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c820:	4d 85 e4             	test   %r12,%r12
    c823:	74 3a                	je     c85f <f0+0x194f>
    c825:	0f b6 0a             	movzbl (%rdx),%ecx
    c828:	80 f9 02             	cmp    $0x2,%cl
    c82b:	0f 84 5f 10 00 00    	je     d890 <f0+0x2980>
    c831:	80 f9 01             	cmp    $0x1,%cl
    c834:	75 29                	jne    c85f <f0+0x194f>
    c836:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c839:	0f b7 c0             	movzwl %ax,%eax
    c83c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c83f:	48 0f af c1          	imul   %rcx,%rax
    c843:	48 c1 e8 20          	shr    $0x20,%rax
    c847:	48 39 d0             	cmp    %rdx,%rax
    c84a:	73 13                	jae    c85f <f0+0x194f>
    c84c:	49 01 c4             	add    %rax,%r12
    c84f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c854:	0f 84 77 12 00 00    	je     dad1 <f0+0x2bc1>
    c85a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c85f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c866:	00 f0 3f 
    c869:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c870:	00 
    c871:	bf 01 00 00 00       	mov    $0x1,%edi
    c876:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c87d:	00 
    c87e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c885:	00 
    c886:	e8 a5 92 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c88b:	48 8b 15 86 82 01 00 	mov    0x18286(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c892:	49 89 c5             	mov    %rax,%r13
    c895:	48 2b 05 54 82 01 00 	sub    0x18254(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c89c:	48 c1 e2 10          	shl    $0x10,%rdx
    c8a0:	48 39 d0             	cmp    %rdx,%rax
    c8a3:	73 59                	jae    c8fe <f0+0x19ee>
    c8a5:	48 89 c2             	mov    %rax,%rdx
    c8a8:	48 c1 ea 10          	shr    $0x10,%rdx
    c8ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8b0:	48 8b 15 81 82 01 00 	mov    0x18281(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c8b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8bf:	4d 85 e4             	test   %r12,%r12
    c8c2:	74 3a                	je     c8fe <f0+0x19ee>
    c8c4:	0f b6 0a             	movzbl (%rdx),%ecx
    c8c7:	80 f9 02             	cmp    $0x2,%cl
    c8ca:	0f 84 40 0f 00 00    	je     d810 <f0+0x2900>
    c8d0:	80 f9 01             	cmp    $0x1,%cl
    c8d3:	75 29                	jne    c8fe <f0+0x19ee>
    c8d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8d8:	0f b7 c0             	movzwl %ax,%eax
    c8db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8de:	48 0f af c1          	imul   %rcx,%rax
    c8e2:	48 c1 e8 20          	shr    $0x20,%rax
    c8e6:	48 39 d0             	cmp    %rdx,%rax
    c8e9:	73 13                	jae    c8fe <f0+0x19ee>
    c8eb:	49 01 c4             	add    %rax,%r12
    c8ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8f3:	0f 84 e5 11 00 00    	je     dade <f0+0x2bce>
    c8f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8fe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c905:	33 f3 bf 
    c908:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c90f:	00 
    c910:	bf 01 00 00 00       	mov    $0x1,%edi
    c915:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c91c:	00 
    c91d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c924:	00 
    c925:	e8 06 92 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c92a:	48 8b 15 e7 81 01 00 	mov    0x181e7(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c931:	49 89 c5             	mov    %rax,%r13
    c934:	48 2b 05 b5 81 01 00 	sub    0x181b5(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c93b:	48 c1 e2 10          	shl    $0x10,%rdx
    c93f:	48 39 d0             	cmp    %rdx,%rax
    c942:	73 59                	jae    c99d <f0+0x1a8d>
    c944:	48 89 c2             	mov    %rax,%rdx
    c947:	48 c1 ea 10          	shr    $0x10,%rdx
    c94b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c94f:	48 8b 15 e2 81 01 00 	mov    0x181e2(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c956:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c95a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c95e:	4d 85 e4             	test   %r12,%r12
    c961:	74 3a                	je     c99d <f0+0x1a8d>
    c963:	0f b6 0a             	movzbl (%rdx),%ecx
    c966:	80 f9 02             	cmp    $0x2,%cl
    c969:	0f 84 91 0e 00 00    	je     d800 <f0+0x28f0>
    c96f:	80 f9 01             	cmp    $0x1,%cl
    c972:	75 29                	jne    c99d <f0+0x1a8d>
    c974:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c977:	0f b7 c0             	movzwl %ax,%eax
    c97a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c97d:	48 0f af c1          	imul   %rcx,%rax
    c981:	48 c1 e8 20          	shr    $0x20,%rax
    c985:	48 39 d0             	cmp    %rdx,%rax
    c988:	73 13                	jae    c99d <f0+0x1a8d>
    c98a:	49 01 c4             	add    %rax,%r12
    c98d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c992:	0f 84 53 11 00 00    	je     daeb <f0+0x2bdb>
    c998:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c99d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9a4:	00 f0 3f 
    c9a7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c9ae:	00 
    c9af:	bf 01 00 00 00       	mov    $0x1,%edi
    c9b4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c9bb:	00 
    c9bc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c9c3:	00 
    c9c4:	e8 67 91 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    c9c9:	48 8b 15 48 81 01 00 	mov    0x18148(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    c9d0:	49 89 c5             	mov    %rax,%r13
    c9d3:	48 2b 05 16 81 01 00 	sub    0x18116(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    c9da:	48 c1 e2 10          	shl    $0x10,%rdx
    c9de:	48 39 d0             	cmp    %rdx,%rax
    c9e1:	73 59                	jae    ca3c <f0+0x1b2c>
    c9e3:	48 89 c2             	mov    %rax,%rdx
    c9e6:	48 c1 ea 10          	shr    $0x10,%rdx
    c9ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9ee:	48 8b 15 43 81 01 00 	mov    0x18143(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    c9f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9fd:	4d 85 e4             	test   %r12,%r12
    ca00:	74 3a                	je     ca3c <f0+0x1b2c>
    ca02:	0f b6 0a             	movzbl (%rdx),%ecx
    ca05:	80 f9 02             	cmp    $0x2,%cl
    ca08:	0f 84 e2 0d 00 00    	je     d7f0 <f0+0x28e0>
    ca0e:	80 f9 01             	cmp    $0x1,%cl
    ca11:	75 29                	jne    ca3c <f0+0x1b2c>
    ca13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca16:	0f b7 c0             	movzwl %ax,%eax
    ca19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca1c:	48 0f af c1          	imul   %rcx,%rax
    ca20:	48 c1 e8 20          	shr    $0x20,%rax
    ca24:	48 39 d0             	cmp    %rdx,%rax
    ca27:	73 13                	jae    ca3c <f0+0x1b2c>
    ca29:	49 01 c4             	add    %rax,%r12
    ca2c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca31:	0f 84 c1 10 00 00    	je     daf8 <f0+0x2be8>
    ca37:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca3c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca43:	33 f3 bf 
    ca46:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    ca4d:	00 
    ca4e:	bf 01 00 00 00       	mov    $0x1,%edi
    ca53:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    ca5a:	00 
    ca5b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    ca62:	00 
    ca63:	e8 c8 90 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ca68:	48 8b 15 a9 80 01 00 	mov    0x180a9(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    ca6f:	49 89 c5             	mov    %rax,%r13
    ca72:	48 2b 05 77 80 01 00 	sub    0x18077(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    ca79:	48 c1 e2 10          	shl    $0x10,%rdx
    ca7d:	48 39 d0             	cmp    %rdx,%rax
    ca80:	73 59                	jae    cadb <f0+0x1bcb>
    ca82:	48 89 c2             	mov    %rax,%rdx
    ca85:	48 c1 ea 10          	shr    $0x10,%rdx
    ca89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca8d:	48 8b 15 a4 80 01 00 	mov    0x180a4(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    ca94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca98:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca9c:	4d 85 e4             	test   %r12,%r12
    ca9f:	74 3a                	je     cadb <f0+0x1bcb>
    caa1:	0f b6 0a             	movzbl (%rdx),%ecx
    caa4:	80 f9 02             	cmp    $0x2,%cl
    caa7:	0f 84 33 0d 00 00    	je     d7e0 <f0+0x28d0>
    caad:	80 f9 01             	cmp    $0x1,%cl
    cab0:	75 29                	jne    cadb <f0+0x1bcb>
    cab2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cab5:	0f b7 c0             	movzwl %ax,%eax
    cab8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cabb:	48 0f af c1          	imul   %rcx,%rax
    cabf:	48 c1 e8 20          	shr    $0x20,%rax
    cac3:	48 39 d0             	cmp    %rdx,%rax
    cac6:	73 13                	jae    cadb <f0+0x1bcb>
    cac8:	49 01 c4             	add    %rax,%r12
    cacb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cad0:	0f 84 2f 10 00 00    	je     db05 <f0+0x2bf5>
    cad6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cadb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cae2:	00 f0 3f 
    cae5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    caec:	00 
    caed:	bf 01 00 00 00       	mov    $0x1,%edi
    caf2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    caf9:	00 
    cafa:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cb01:	00 
    cb02:	e8 29 90 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cb07:	48 8b 15 0a 80 01 00 	mov    0x1800a(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cb0e:	49 89 c5             	mov    %rax,%r13
    cb11:	48 2b 05 d8 7f 01 00 	sub    0x17fd8(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    cb18:	48 c1 e2 10          	shl    $0x10,%rdx
    cb1c:	48 39 d0             	cmp    %rdx,%rax
    cb1f:	73 59                	jae    cb7a <f0+0x1c6a>
    cb21:	48 89 c2             	mov    %rax,%rdx
    cb24:	48 c1 ea 10          	shr    $0x10,%rdx
    cb28:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb2c:	48 8b 15 05 80 01 00 	mov    0x18005(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cb33:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb37:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb3b:	4d 85 e4             	test   %r12,%r12
    cb3e:	74 3a                	je     cb7a <f0+0x1c6a>
    cb40:	0f b6 0a             	movzbl (%rdx),%ecx
    cb43:	80 f9 02             	cmp    $0x2,%cl
    cb46:	0f 84 84 0c 00 00    	je     d7d0 <f0+0x28c0>
    cb4c:	80 f9 01             	cmp    $0x1,%cl
    cb4f:	75 29                	jne    cb7a <f0+0x1c6a>
    cb51:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb54:	0f b7 c0             	movzwl %ax,%eax
    cb57:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb5a:	48 0f af c1          	imul   %rcx,%rax
    cb5e:	48 c1 e8 20          	shr    $0x20,%rax
    cb62:	48 39 d0             	cmp    %rdx,%rax
    cb65:	73 13                	jae    cb7a <f0+0x1c6a>
    cb67:	49 01 c4             	add    %rax,%r12
    cb6a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb6f:	0f 84 9d 0f 00 00    	je     db12 <f0+0x2c02>
    cb75:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb7a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb81:	33 f3 bf 
    cb84:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cb8b:	00 
    cb8c:	bf 01 00 00 00       	mov    $0x1,%edi
    cb91:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cb98:	00 
    cb99:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cba0:	00 
    cba1:	e8 8a 8f ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cba6:	48 8b 15 6b 7f 01 00 	mov    0x17f6b(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cbad:	49 89 c5             	mov    %rax,%r13
    cbb0:	48 2b 05 39 7f 01 00 	sub    0x17f39(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    cbb7:	48 c1 e2 10          	shl    $0x10,%rdx
    cbbb:	48 39 d0             	cmp    %rdx,%rax
    cbbe:	73 59                	jae    cc19 <f0+0x1d09>
    cbc0:	48 89 c2             	mov    %rax,%rdx
    cbc3:	48 c1 ea 10          	shr    $0x10,%rdx
    cbc7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbcb:	48 8b 15 66 7f 01 00 	mov    0x17f66(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cbd2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbd6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbda:	4d 85 e4             	test   %r12,%r12
    cbdd:	74 3a                	je     cc19 <f0+0x1d09>
    cbdf:	0f b6 0a             	movzbl (%rdx),%ecx
    cbe2:	80 f9 02             	cmp    $0x2,%cl
    cbe5:	0f 84 d5 0b 00 00    	je     d7c0 <f0+0x28b0>
    cbeb:	80 f9 01             	cmp    $0x1,%cl
    cbee:	75 29                	jne    cc19 <f0+0x1d09>
    cbf0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbf3:	0f b7 c0             	movzwl %ax,%eax
    cbf6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbf9:	48 0f af c1          	imul   %rcx,%rax
    cbfd:	48 c1 e8 20          	shr    $0x20,%rax
    cc01:	48 39 d0             	cmp    %rdx,%rax
    cc04:	73 13                	jae    cc19 <f0+0x1d09>
    cc06:	49 01 c4             	add    %rax,%r12
    cc09:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc0e:	0f 84 0b 0f 00 00    	je     db1f <f0+0x2c0f>
    cc14:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc19:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc20:	00 f0 3f 
    cc23:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cc2a:	00 
    cc2b:	bf 01 00 00 00       	mov    $0x1,%edi
    cc30:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cc37:	00 
    cc38:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cc3f:	00 
    cc40:	e8 eb 8e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cc45:	48 8b 15 cc 7e 01 00 	mov    0x17ecc(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cc4c:	49 89 c5             	mov    %rax,%r13
    cc4f:	48 2b 05 9a 7e 01 00 	sub    0x17e9a(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    cc56:	48 c1 e2 10          	shl    $0x10,%rdx
    cc5a:	48 39 d0             	cmp    %rdx,%rax
    cc5d:	73 59                	jae    ccb8 <f0+0x1da8>
    cc5f:	48 89 c2             	mov    %rax,%rdx
    cc62:	48 c1 ea 10          	shr    $0x10,%rdx
    cc66:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc6a:	48 8b 15 c7 7e 01 00 	mov    0x17ec7(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cc71:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc75:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc79:	4d 85 e4             	test   %r12,%r12
    cc7c:	74 3a                	je     ccb8 <f0+0x1da8>
    cc7e:	0f b6 0a             	movzbl (%rdx),%ecx
    cc81:	80 f9 02             	cmp    $0x2,%cl
    cc84:	0f 84 26 0b 00 00    	je     d7b0 <f0+0x28a0>
    cc8a:	80 f9 01             	cmp    $0x1,%cl
    cc8d:	75 29                	jne    ccb8 <f0+0x1da8>
    cc8f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc92:	0f b7 c0             	movzwl %ax,%eax
    cc95:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc98:	48 0f af c1          	imul   %rcx,%rax
    cc9c:	48 c1 e8 20          	shr    $0x20,%rax
    cca0:	48 39 d0             	cmp    %rdx,%rax
    cca3:	73 13                	jae    ccb8 <f0+0x1da8>
    cca5:	49 01 c4             	add    %rax,%r12
    cca8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccad:	0f 84 79 0e 00 00    	je     db2c <f0+0x2c1c>
    ccb3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccb8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccbf:	33 f3 bf 
    ccc2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ccc9:	00 
    ccca:	bf 01 00 00 00       	mov    $0x1,%edi
    cccf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    ccd6:	00 
    ccd7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    ccde:	00 
    ccdf:	e8 4c 8e ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cce4:	48 8b 15 2d 7e 01 00 	mov    0x17e2d(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cceb:	49 89 c5             	mov    %rax,%r13
    ccee:	48 2b 05 fb 7d 01 00 	sub    0x17dfb(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    ccf5:	48 c1 e2 10          	shl    $0x10,%rdx
    ccf9:	48 39 d0             	cmp    %rdx,%rax
    ccfc:	73 59                	jae    cd57 <f0+0x1e47>
    ccfe:	48 89 c2             	mov    %rax,%rdx
    cd01:	48 c1 ea 10          	shr    $0x10,%rdx
    cd05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd09:	48 8b 15 28 7e 01 00 	mov    0x17e28(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cd10:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd14:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd18:	4d 85 e4             	test   %r12,%r12
    cd1b:	74 3a                	je     cd57 <f0+0x1e47>
    cd1d:	0f b6 0a             	movzbl (%rdx),%ecx
    cd20:	80 f9 02             	cmp    $0x2,%cl
    cd23:	0f 84 77 0a 00 00    	je     d7a0 <f0+0x2890>
    cd29:	80 f9 01             	cmp    $0x1,%cl
    cd2c:	75 29                	jne    cd57 <f0+0x1e47>
    cd2e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd31:	0f b7 c0             	movzwl %ax,%eax
    cd34:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd37:	48 0f af c1          	imul   %rcx,%rax
    cd3b:	48 c1 e8 20          	shr    $0x20,%rax
    cd3f:	48 39 d0             	cmp    %rdx,%rax
    cd42:	73 13                	jae    cd57 <f0+0x1e47>
    cd44:	49 01 c4             	add    %rax,%r12
    cd47:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd4c:	0f 84 e7 0d 00 00    	je     db39 <f0+0x2c29>
    cd52:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd57:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd5e:	00 f0 3f 
    cd61:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cd68:	00 
    cd69:	bf 01 00 00 00       	mov    $0x1,%edi
    cd6e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cd75:	00 
    cd76:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cd7d:	00 
    cd7e:	e8 ad 8d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cd83:	48 8b 15 8e 7d 01 00 	mov    0x17d8e(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cd8a:	49 89 c5             	mov    %rax,%r13
    cd8d:	48 2b 05 5c 7d 01 00 	sub    0x17d5c(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    cd94:	48 c1 e2 10          	shl    $0x10,%rdx
    cd98:	48 39 d0             	cmp    %rdx,%rax
    cd9b:	73 59                	jae    cdf6 <f0+0x1ee6>
    cd9d:	48 89 c2             	mov    %rax,%rdx
    cda0:	48 c1 ea 10          	shr    $0x10,%rdx
    cda4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cda8:	48 8b 15 89 7d 01 00 	mov    0x17d89(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cdaf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdb3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdb7:	4d 85 e4             	test   %r12,%r12
    cdba:	74 3a                	je     cdf6 <f0+0x1ee6>
    cdbc:	0f b6 0a             	movzbl (%rdx),%ecx
    cdbf:	80 f9 02             	cmp    $0x2,%cl
    cdc2:	0f 84 38 0c 00 00    	je     da00 <f0+0x2af0>
    cdc8:	80 f9 01             	cmp    $0x1,%cl
    cdcb:	75 29                	jne    cdf6 <f0+0x1ee6>
    cdcd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdd0:	0f b7 c0             	movzwl %ax,%eax
    cdd3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdd6:	48 0f af c1          	imul   %rcx,%rax
    cdda:	48 c1 e8 20          	shr    $0x20,%rax
    cdde:	48 39 d0             	cmp    %rdx,%rax
    cde1:	73 13                	jae    cdf6 <f0+0x1ee6>
    cde3:	49 01 c4             	add    %rax,%r12
    cde6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cdeb:	0f 84 55 0d 00 00    	je     db46 <f0+0x2c36>
    cdf1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdf6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cdfd:	33 f3 bf 
    ce00:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    ce07:	00 
    ce08:	bf 01 00 00 00       	mov    $0x1,%edi
    ce0d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    ce14:	00 
    ce15:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    ce1c:	00 
    ce1d:	e8 0e 8d ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    ce22:	48 8b 15 ef 7c 01 00 	mov    0x17cef(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    ce29:	49 89 c5             	mov    %rax,%r13
    ce2c:	48 2b 05 bd 7c 01 00 	sub    0x17cbd(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    ce33:	48 c1 e2 10          	shl    $0x10,%rdx
    ce37:	48 39 d0             	cmp    %rdx,%rax
    ce3a:	73 59                	jae    ce95 <f0+0x1f85>
    ce3c:	48 89 c2             	mov    %rax,%rdx
    ce3f:	48 c1 ea 10          	shr    $0x10,%rdx
    ce43:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce47:	48 8b 15 ea 7c 01 00 	mov    0x17cea(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    ce4e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce52:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce56:	4d 85 e4             	test   %r12,%r12
    ce59:	74 3a                	je     ce95 <f0+0x1f85>
    ce5b:	0f b6 0a             	movzbl (%rdx),%ecx
    ce5e:	80 f9 02             	cmp    $0x2,%cl
    ce61:	0f 84 89 0b 00 00    	je     d9f0 <f0+0x2ae0>
    ce67:	80 f9 01             	cmp    $0x1,%cl
    ce6a:	75 29                	jne    ce95 <f0+0x1f85>
    ce6c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce6f:	0f b7 c0             	movzwl %ax,%eax
    ce72:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce75:	48 0f af c1          	imul   %rcx,%rax
    ce79:	48 c1 e8 20          	shr    $0x20,%rax
    ce7d:	48 39 d0             	cmp    %rdx,%rax
    ce80:	73 13                	jae    ce95 <f0+0x1f85>
    ce82:	49 01 c4             	add    %rax,%r12
    ce85:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce8a:	0f 84 c3 0c 00 00    	je     db53 <f0+0x2c43>
    ce90:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce95:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce9c:	00 f0 3f 
    ce9f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cea6:	00 
    cea7:	bf 01 00 00 00       	mov    $0x1,%edi
    ceac:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    ceb3:	00 
    ceb4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cebb:	00 
    cebc:	e8 6f 8c ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cec1:	48 8b 15 50 7c 01 00 	mov    0x17c50(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cec8:	49 89 c5             	mov    %rax,%r13
    cecb:	48 2b 05 1e 7c 01 00 	sub    0x17c1e(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    ced2:	48 c1 e2 10          	shl    $0x10,%rdx
    ced6:	48 39 d0             	cmp    %rdx,%rax
    ced9:	73 59                	jae    cf34 <f0+0x2024>
    cedb:	48 89 c2             	mov    %rax,%rdx
    cede:	48 c1 ea 10          	shr    $0x10,%rdx
    cee2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cee6:	48 8b 15 4b 7c 01 00 	mov    0x17c4b(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    ceed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cef1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cef5:	4d 85 e4             	test   %r12,%r12
    cef8:	74 3a                	je     cf34 <f0+0x2024>
    cefa:	0f b6 0a             	movzbl (%rdx),%ecx
    cefd:	80 f9 02             	cmp    $0x2,%cl
    cf00:	0f 84 da 0a 00 00    	je     d9e0 <f0+0x2ad0>
    cf06:	80 f9 01             	cmp    $0x1,%cl
    cf09:	75 29                	jne    cf34 <f0+0x2024>
    cf0b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf0e:	0f b7 c0             	movzwl %ax,%eax
    cf11:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf14:	48 0f af c1          	imul   %rcx,%rax
    cf18:	48 c1 e8 20          	shr    $0x20,%rax
    cf1c:	48 39 d0             	cmp    %rdx,%rax
    cf1f:	73 13                	jae    cf34 <f0+0x2024>
    cf21:	49 01 c4             	add    %rax,%r12
    cf24:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf29:	0f 84 31 0c 00 00    	je     db60 <f0+0x2c50>
    cf2f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf34:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf3b:	33 f3 bf 
    cf3e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cf45:	00 
    cf46:	bf 01 00 00 00       	mov    $0x1,%edi
    cf4b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cf52:	00 
    cf53:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cf5a:	00 
    cf5b:	e8 d0 8b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cf60:	48 8b 15 b1 7b 01 00 	mov    0x17bb1(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    cf67:	49 89 c5             	mov    %rax,%r13
    cf6a:	48 2b 05 7f 7b 01 00 	sub    0x17b7f(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    cf71:	48 c1 e2 10          	shl    $0x10,%rdx
    cf75:	48 39 d0             	cmp    %rdx,%rax
    cf78:	73 59                	jae    cfd3 <f0+0x20c3>
    cf7a:	48 89 c2             	mov    %rax,%rdx
    cf7d:	48 c1 ea 10          	shr    $0x10,%rdx
    cf81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf85:	48 8b 15 ac 7b 01 00 	mov    0x17bac(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    cf8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf90:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf94:	4d 85 e4             	test   %r12,%r12
    cf97:	74 3a                	je     cfd3 <f0+0x20c3>
    cf99:	0f b6 0a             	movzbl (%rdx),%ecx
    cf9c:	80 f9 02             	cmp    $0x2,%cl
    cf9f:	0f 84 2b 0a 00 00    	je     d9d0 <f0+0x2ac0>
    cfa5:	80 f9 01             	cmp    $0x1,%cl
    cfa8:	75 29                	jne    cfd3 <f0+0x20c3>
    cfaa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfad:	0f b7 c0             	movzwl %ax,%eax
    cfb0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfb3:	48 0f af c1          	imul   %rcx,%rax
    cfb7:	48 c1 e8 20          	shr    $0x20,%rax
    cfbb:	48 39 d0             	cmp    %rdx,%rax
    cfbe:	73 13                	jae    cfd3 <f0+0x20c3>
    cfc0:	49 01 c4             	add    %rax,%r12
    cfc3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfc8:	0f 84 9f 0b 00 00    	je     db6d <f0+0x2c5d>
    cfce:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfd3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfda:	00 f0 3f 
    cfdd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cfe4:	00 
    cfe5:	bf 01 00 00 00       	mov    $0x1,%edi
    cfea:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    cff1:	00 
    cff2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    cff9:	00 
    cffa:	e8 31 8b ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    cfff:	48 8b 15 12 7b 01 00 	mov    0x17b12(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d006:	49 89 c5             	mov    %rax,%r13
    d009:	48 2b 05 e0 7a 01 00 	sub    0x17ae0(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d010:	48 c1 e2 10          	shl    $0x10,%rdx
    d014:	48 39 d0             	cmp    %rdx,%rax
    d017:	73 59                	jae    d072 <f0+0x2162>
    d019:	48 89 c2             	mov    %rax,%rdx
    d01c:	48 c1 ea 10          	shr    $0x10,%rdx
    d020:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d024:	48 8b 15 0d 7b 01 00 	mov    0x17b0d(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d02b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d02f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d033:	4d 85 e4             	test   %r12,%r12
    d036:	74 3a                	je     d072 <f0+0x2162>
    d038:	0f b6 0a             	movzbl (%rdx),%ecx
    d03b:	80 f9 02             	cmp    $0x2,%cl
    d03e:	0f 84 7c 09 00 00    	je     d9c0 <f0+0x2ab0>
    d044:	80 f9 01             	cmp    $0x1,%cl
    d047:	75 29                	jne    d072 <f0+0x2162>
    d049:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d04c:	0f b7 c0             	movzwl %ax,%eax
    d04f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d052:	48 0f af c1          	imul   %rcx,%rax
    d056:	48 c1 e8 20          	shr    $0x20,%rax
    d05a:	48 39 d0             	cmp    %rdx,%rax
    d05d:	73 13                	jae    d072 <f0+0x2162>
    d05f:	49 01 c4             	add    %rax,%r12
    d062:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d067:	0f 84 0d 0b 00 00    	je     db7a <f0+0x2c6a>
    d06d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d072:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d079:	33 f3 bf 
    d07c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d083:	00 
    d084:	bf 01 00 00 00       	mov    $0x1,%edi
    d089:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d090:	00 
    d091:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d098:	00 
    d099:	e8 92 8a ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d09e:	48 8b 15 73 7a 01 00 	mov    0x17a73(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d0a5:	49 89 c5             	mov    %rax,%r13
    d0a8:	48 2b 05 41 7a 01 00 	sub    0x17a41(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d0af:	48 c1 e2 10          	shl    $0x10,%rdx
    d0b3:	48 39 d0             	cmp    %rdx,%rax
    d0b6:	73 59                	jae    d111 <f0+0x2201>
    d0b8:	48 89 c2             	mov    %rax,%rdx
    d0bb:	48 c1 ea 10          	shr    $0x10,%rdx
    d0bf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0c3:	48 8b 15 6e 7a 01 00 	mov    0x17a6e(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d0ca:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0ce:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0d2:	4d 85 e4             	test   %r12,%r12
    d0d5:	74 3a                	je     d111 <f0+0x2201>
    d0d7:	0f b6 0a             	movzbl (%rdx),%ecx
    d0da:	80 f9 02             	cmp    $0x2,%cl
    d0dd:	0f 84 cd 08 00 00    	je     d9b0 <f0+0x2aa0>
    d0e3:	80 f9 01             	cmp    $0x1,%cl
    d0e6:	75 29                	jne    d111 <f0+0x2201>
    d0e8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0eb:	0f b7 c0             	movzwl %ax,%eax
    d0ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0f1:	48 0f af c1          	imul   %rcx,%rax
    d0f5:	48 c1 e8 20          	shr    $0x20,%rax
    d0f9:	48 39 d0             	cmp    %rdx,%rax
    d0fc:	73 13                	jae    d111 <f0+0x2201>
    d0fe:	49 01 c4             	add    %rax,%r12
    d101:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d106:	0f 84 7b 0a 00 00    	je     db87 <f0+0x2c77>
    d10c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d111:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d118:	00 f0 3f 
    d11b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d122:	00 
    d123:	bf 01 00 00 00       	mov    $0x1,%edi
    d128:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d12f:	00 
    d130:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d137:	00 
    d138:	e8 f3 89 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d13d:	48 8b 15 d4 79 01 00 	mov    0x179d4(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d144:	49 89 c5             	mov    %rax,%r13
    d147:	48 2b 05 a2 79 01 00 	sub    0x179a2(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d14e:	48 c1 e2 10          	shl    $0x10,%rdx
    d152:	48 39 d0             	cmp    %rdx,%rax
    d155:	73 59                	jae    d1b0 <f0+0x22a0>
    d157:	48 89 c2             	mov    %rax,%rdx
    d15a:	48 c1 ea 10          	shr    $0x10,%rdx
    d15e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d162:	48 8b 15 cf 79 01 00 	mov    0x179cf(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d169:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d16d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d171:	4d 85 e4             	test   %r12,%r12
    d174:	74 3a                	je     d1b0 <f0+0x22a0>
    d176:	0f b6 0a             	movzbl (%rdx),%ecx
    d179:	80 f9 02             	cmp    $0x2,%cl
    d17c:	0f 84 1e 08 00 00    	je     d9a0 <f0+0x2a90>
    d182:	80 f9 01             	cmp    $0x1,%cl
    d185:	75 29                	jne    d1b0 <f0+0x22a0>
    d187:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d18a:	0f b7 c0             	movzwl %ax,%eax
    d18d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d190:	48 0f af c1          	imul   %rcx,%rax
    d194:	48 c1 e8 20          	shr    $0x20,%rax
    d198:	48 39 d0             	cmp    %rdx,%rax
    d19b:	73 13                	jae    d1b0 <f0+0x22a0>
    d19d:	49 01 c4             	add    %rax,%r12
    d1a0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1a5:	0f 84 e9 09 00 00    	je     db94 <f0+0x2c84>
    d1ab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1b0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1b7:	33 f3 bf 
    d1ba:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d1c1:	00 
    d1c2:	bf 01 00 00 00       	mov    $0x1,%edi
    d1c7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d1ce:	00 
    d1cf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d1d6:	00 
    d1d7:	e8 54 89 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d1dc:	48 8b 15 35 79 01 00 	mov    0x17935(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d1e3:	49 89 c5             	mov    %rax,%r13
    d1e6:	48 2b 05 03 79 01 00 	sub    0x17903(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d1ed:	48 c1 e2 10          	shl    $0x10,%rdx
    d1f1:	48 39 d0             	cmp    %rdx,%rax
    d1f4:	73 59                	jae    d24f <f0+0x233f>
    d1f6:	48 89 c2             	mov    %rax,%rdx
    d1f9:	48 c1 ea 10          	shr    $0x10,%rdx
    d1fd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d201:	48 8b 15 30 79 01 00 	mov    0x17930(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d208:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d20c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d210:	4d 85 e4             	test   %r12,%r12
    d213:	74 3a                	je     d24f <f0+0x233f>
    d215:	0f b6 0a             	movzbl (%rdx),%ecx
    d218:	80 f9 02             	cmp    $0x2,%cl
    d21b:	0f 84 6f 07 00 00    	je     d990 <f0+0x2a80>
    d221:	80 f9 01             	cmp    $0x1,%cl
    d224:	75 29                	jne    d24f <f0+0x233f>
    d226:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d229:	0f b7 c0             	movzwl %ax,%eax
    d22c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d22f:	48 0f af c1          	imul   %rcx,%rax
    d233:	48 c1 e8 20          	shr    $0x20,%rax
    d237:	48 39 d0             	cmp    %rdx,%rax
    d23a:	73 13                	jae    d24f <f0+0x233f>
    d23c:	49 01 c4             	add    %rax,%r12
    d23f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d244:	0f 84 57 09 00 00    	je     dba1 <f0+0x2c91>
    d24a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d24f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d256:	00 f0 3f 
    d259:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d260:	00 
    d261:	bf 01 00 00 00       	mov    $0x1,%edi
    d266:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d26d:	00 
    d26e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d275:	00 
    d276:	e8 b5 88 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d27b:	48 8b 15 96 78 01 00 	mov    0x17896(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d282:	49 89 c5             	mov    %rax,%r13
    d285:	48 2b 05 64 78 01 00 	sub    0x17864(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d28c:	48 c1 e2 10          	shl    $0x10,%rdx
    d290:	48 39 d0             	cmp    %rdx,%rax
    d293:	73 59                	jae    d2ee <f0+0x23de>
    d295:	48 89 c2             	mov    %rax,%rdx
    d298:	48 c1 ea 10          	shr    $0x10,%rdx
    d29c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2a0:	48 8b 15 91 78 01 00 	mov    0x17891(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d2a7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2ab:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2af:	4d 85 e4             	test   %r12,%r12
    d2b2:	74 3a                	je     d2ee <f0+0x23de>
    d2b4:	0f b6 0a             	movzbl (%rdx),%ecx
    d2b7:	80 f9 02             	cmp    $0x2,%cl
    d2ba:	0f 84 c0 06 00 00    	je     d980 <f0+0x2a70>
    d2c0:	80 f9 01             	cmp    $0x1,%cl
    d2c3:	75 29                	jne    d2ee <f0+0x23de>
    d2c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2c8:	0f b7 c0             	movzwl %ax,%eax
    d2cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2ce:	48 0f af c1          	imul   %rcx,%rax
    d2d2:	48 c1 e8 20          	shr    $0x20,%rax
    d2d6:	48 39 d0             	cmp    %rdx,%rax
    d2d9:	73 13                	jae    d2ee <f0+0x23de>
    d2db:	49 01 c4             	add    %rax,%r12
    d2de:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2e3:	0f 84 c5 08 00 00    	je     dbae <f0+0x2c9e>
    d2e9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2ee:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2f5:	33 f3 bf 
    d2f8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d2ff:	00 
    d300:	bf 01 00 00 00       	mov    $0x1,%edi
    d305:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d30c:	00 
    d30d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d314:	00 
    d315:	e8 16 88 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d31a:	48 8b 15 f7 77 01 00 	mov    0x177f7(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d321:	49 89 c5             	mov    %rax,%r13
    d324:	48 2b 05 c5 77 01 00 	sub    0x177c5(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d32b:	48 c1 e2 10          	shl    $0x10,%rdx
    d32f:	48 39 d0             	cmp    %rdx,%rax
    d332:	73 59                	jae    d38d <f0+0x247d>
    d334:	48 89 c2             	mov    %rax,%rdx
    d337:	48 c1 ea 10          	shr    $0x10,%rdx
    d33b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d33f:	48 8b 15 f2 77 01 00 	mov    0x177f2(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d346:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d34a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d34e:	4d 85 e4             	test   %r12,%r12
    d351:	74 3a                	je     d38d <f0+0x247d>
    d353:	0f b6 0a             	movzbl (%rdx),%ecx
    d356:	80 f9 02             	cmp    $0x2,%cl
    d359:	0f 84 11 06 00 00    	je     d970 <f0+0x2a60>
    d35f:	80 f9 01             	cmp    $0x1,%cl
    d362:	75 29                	jne    d38d <f0+0x247d>
    d364:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d367:	0f b7 c0             	movzwl %ax,%eax
    d36a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d36d:	48 0f af c1          	imul   %rcx,%rax
    d371:	48 c1 e8 20          	shr    $0x20,%rax
    d375:	48 39 d0             	cmp    %rdx,%rax
    d378:	73 13                	jae    d38d <f0+0x247d>
    d37a:	49 01 c4             	add    %rax,%r12
    d37d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d382:	0f 84 33 08 00 00    	je     dbbb <f0+0x2cab>
    d388:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d38d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d394:	00 f0 3f 
    d397:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d39e:	00 
    d39f:	bf 01 00 00 00       	mov    $0x1,%edi
    d3a4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d3ab:	00 
    d3ac:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d3b3:	00 
    d3b4:	e8 77 87 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d3b9:	48 8b 15 58 77 01 00 	mov    0x17758(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d3c0:	49 89 c5             	mov    %rax,%r13
    d3c3:	48 2b 05 26 77 01 00 	sub    0x17726(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d3ca:	48 c1 e2 10          	shl    $0x10,%rdx
    d3ce:	48 39 d0             	cmp    %rdx,%rax
    d3d1:	73 59                	jae    d42c <f0+0x251c>
    d3d3:	48 89 c2             	mov    %rax,%rdx
    d3d6:	48 c1 ea 10          	shr    $0x10,%rdx
    d3da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3de:	48 8b 15 53 77 01 00 	mov    0x17753(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d3e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3e9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3ed:	4d 85 e4             	test   %r12,%r12
    d3f0:	74 3a                	je     d42c <f0+0x251c>
    d3f2:	0f b6 0a             	movzbl (%rdx),%ecx
    d3f5:	80 f9 02             	cmp    $0x2,%cl
    d3f8:	0f 84 62 05 00 00    	je     d960 <f0+0x2a50>
    d3fe:	80 f9 01             	cmp    $0x1,%cl
    d401:	75 29                	jne    d42c <f0+0x251c>
    d403:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d406:	0f b7 c0             	movzwl %ax,%eax
    d409:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d40c:	48 0f af c1          	imul   %rcx,%rax
    d410:	48 c1 e8 20          	shr    $0x20,%rax
    d414:	48 39 d0             	cmp    %rdx,%rax
    d417:	73 13                	jae    d42c <f0+0x251c>
    d419:	49 01 c4             	add    %rax,%r12
    d41c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d421:	0f 84 a1 07 00 00    	je     dbc8 <f0+0x2cb8>
    d427:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d42c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d433:	33 f3 bf 
    d436:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d43d:	00 
    d43e:	bf 01 00 00 00       	mov    $0x1,%edi
    d443:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d44a:	00 
    d44b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d452:	00 
    d453:	e8 d8 86 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d458:	48 8b 15 b9 76 01 00 	mov    0x176b9(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d45f:	49 89 c5             	mov    %rax,%r13
    d462:	48 2b 05 87 76 01 00 	sub    0x17687(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d469:	48 c1 e2 10          	shl    $0x10,%rdx
    d46d:	48 39 d0             	cmp    %rdx,%rax
    d470:	73 59                	jae    d4cb <f0+0x25bb>
    d472:	48 89 c2             	mov    %rax,%rdx
    d475:	48 c1 ea 10          	shr    $0x10,%rdx
    d479:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d47d:	48 8b 15 b4 76 01 00 	mov    0x176b4(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d484:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d488:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d48c:	4d 85 e4             	test   %r12,%r12
    d48f:	74 3a                	je     d4cb <f0+0x25bb>
    d491:	0f b6 0a             	movzbl (%rdx),%ecx
    d494:	80 f9 02             	cmp    $0x2,%cl
    d497:	0f 84 b3 04 00 00    	je     d950 <f0+0x2a40>
    d49d:	80 f9 01             	cmp    $0x1,%cl
    d4a0:	75 29                	jne    d4cb <f0+0x25bb>
    d4a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4a5:	0f b7 c0             	movzwl %ax,%eax
    d4a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4ab:	48 0f af c1          	imul   %rcx,%rax
    d4af:	48 c1 e8 20          	shr    $0x20,%rax
    d4b3:	48 39 d0             	cmp    %rdx,%rax
    d4b6:	73 13                	jae    d4cb <f0+0x25bb>
    d4b8:	49 01 c4             	add    %rax,%r12
    d4bb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4c0:	0f 84 0f 07 00 00    	je     dbd5 <f0+0x2cc5>
    d4c6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4cb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4d2:	00 f0 3f 
    d4d5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d4dc:	00 
    d4dd:	bf 01 00 00 00       	mov    $0x1,%edi
    d4e2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d4e9:	00 
    d4ea:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d4f1:	00 
    d4f2:	e8 39 86 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d4f7:	48 8b 15 1a 76 01 00 	mov    0x1761a(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d4fe:	49 89 c5             	mov    %rax,%r13
    d501:	48 2b 05 e8 75 01 00 	sub    0x175e8(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d508:	48 c1 e2 10          	shl    $0x10,%rdx
    d50c:	48 39 d0             	cmp    %rdx,%rax
    d50f:	73 59                	jae    d56a <f0+0x265a>
    d511:	48 89 c2             	mov    %rax,%rdx
    d514:	48 c1 ea 10          	shr    $0x10,%rdx
    d518:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d51c:	48 8b 15 15 76 01 00 	mov    0x17615(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d523:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d527:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d52b:	4d 85 e4             	test   %r12,%r12
    d52e:	74 3a                	je     d56a <f0+0x265a>
    d530:	0f b6 0a             	movzbl (%rdx),%ecx
    d533:	80 f9 02             	cmp    $0x2,%cl
    d536:	0f 84 04 04 00 00    	je     d940 <f0+0x2a30>
    d53c:	80 f9 01             	cmp    $0x1,%cl
    d53f:	75 29                	jne    d56a <f0+0x265a>
    d541:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d544:	0f b7 c0             	movzwl %ax,%eax
    d547:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d54a:	48 0f af c1          	imul   %rcx,%rax
    d54e:	48 c1 e8 20          	shr    $0x20,%rax
    d552:	48 39 d0             	cmp    %rdx,%rax
    d555:	73 13                	jae    d56a <f0+0x265a>
    d557:	49 01 c4             	add    %rax,%r12
    d55a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d55f:	0f 84 7d 06 00 00    	je     dbe2 <f0+0x2cd2>
    d565:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d56a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d571:	33 f3 bf 
    d574:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d57b:	00 
    d57c:	bf 01 00 00 00       	mov    $0x1,%edi
    d581:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d588:	00 
    d589:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d590:	00 
    d591:	e8 9a 85 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d596:	48 8b 15 7b 75 01 00 	mov    0x1757b(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d59d:	49 89 c5             	mov    %rax,%r13
    d5a0:	48 2b 05 49 75 01 00 	sub    0x17549(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d5a7:	48 c1 e2 10          	shl    $0x10,%rdx
    d5ab:	48 39 d0             	cmp    %rdx,%rax
    d5ae:	73 59                	jae    d609 <f0+0x26f9>
    d5b0:	48 89 c2             	mov    %rax,%rdx
    d5b3:	48 c1 ea 10          	shr    $0x10,%rdx
    d5b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5bb:	48 8b 15 76 75 01 00 	mov    0x17576(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d5c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5c6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5ca:	4d 85 e4             	test   %r12,%r12
    d5cd:	74 3a                	je     d609 <f0+0x26f9>
    d5cf:	0f b6 0a             	movzbl (%rdx),%ecx
    d5d2:	80 f9 02             	cmp    $0x2,%cl
    d5d5:	0f 84 55 03 00 00    	je     d930 <f0+0x2a20>
    d5db:	80 f9 01             	cmp    $0x1,%cl
    d5de:	75 29                	jne    d609 <f0+0x26f9>
    d5e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5e3:	0f b7 c0             	movzwl %ax,%eax
    d5e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5e9:	48 0f af c1          	imul   %rcx,%rax
    d5ed:	48 c1 e8 20          	shr    $0x20,%rax
    d5f1:	48 39 d0             	cmp    %rdx,%rax
    d5f4:	73 13                	jae    d609 <f0+0x26f9>
    d5f6:	49 01 c4             	add    %rax,%r12
    d5f9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5fe:	0f 84 eb 05 00 00    	je     dbef <f0+0x2cdf>
    d604:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d609:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d610:	00 f0 3f 
    d613:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d61a:	00 
    d61b:	bf 01 00 00 00       	mov    $0x1,%edi
    d620:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d627:	00 
    d628:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d62f:	00 
    d630:	e8 fb 84 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d635:	48 8b 15 dc 74 01 00 	mov    0x174dc(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d63c:	49 89 c5             	mov    %rax,%r13
    d63f:	48 2b 05 aa 74 01 00 	sub    0x174aa(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d646:	48 c1 e2 10          	shl    $0x10,%rdx
    d64a:	48 39 d0             	cmp    %rdx,%rax
    d64d:	73 59                	jae    d6a8 <f0+0x2798>
    d64f:	48 89 c2             	mov    %rax,%rdx
    d652:	48 c1 ea 10          	shr    $0x10,%rdx
    d656:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d65a:	48 8b 15 d7 74 01 00 	mov    0x174d7(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d661:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d665:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d669:	4d 85 e4             	test   %r12,%r12
    d66c:	74 3a                	je     d6a8 <f0+0x2798>
    d66e:	0f b6 0a             	movzbl (%rdx),%ecx
    d671:	80 f9 02             	cmp    $0x2,%cl
    d674:	0f 84 a6 02 00 00    	je     d920 <f0+0x2a10>
    d67a:	80 f9 01             	cmp    $0x1,%cl
    d67d:	75 29                	jne    d6a8 <f0+0x2798>
    d67f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d682:	0f b7 c0             	movzwl %ax,%eax
    d685:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d688:	48 0f af c1          	imul   %rcx,%rax
    d68c:	48 c1 e8 20          	shr    $0x20,%rax
    d690:	48 39 d0             	cmp    %rdx,%rax
    d693:	73 13                	jae    d6a8 <f0+0x2798>
    d695:	49 01 c4             	add    %rax,%r12
    d698:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d69d:	0f 84 59 05 00 00    	je     dbfc <f0+0x2cec>
    d6a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6a8:	48 89 ee             	mov    %rbp,%rsi
    d6ab:	bf 01 00 00 00       	mov    $0x1,%edi
    d6b0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6b7:	33 f3 bf 
    d6ba:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d6c1:	00 
    d6c2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d6c9:	00 
    d6ca:	e8 61 84 ff ff       	call   5b30 <fwp_data.part.0.constprop.0>
    d6cf:	48 8b 15 42 74 01 00 	mov    0x17442(%rip),%rdx        # 24b18 <fwp_heap+0x13d8>
    d6d6:	48 89 c5             	mov    %rax,%rbp
    d6d9:	48 2b 05 10 74 01 00 	sub    0x17410(%rip),%rax        # 24af0 <fwp_heap+0x13b0>
    d6e0:	48 c1 e2 10          	shl    $0x10,%rdx
    d6e4:	48 39 d0             	cmp    %rdx,%rax
    d6e7:	73 59                	jae    d742 <f0+0x2832>
    d6e9:	48 89 c2             	mov    %rax,%rdx
    d6ec:	48 c1 ea 10          	shr    $0x10,%rdx
    d6f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6f4:	48 8b 15 3d 74 01 00 	mov    0x1743d(%rip),%rdx        # 24b38 <fwp_heap+0x13f8>
    d6fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d703:	4d 85 e4             	test   %r12,%r12
    d706:	74 3a                	je     d742 <f0+0x2832>
    d708:	0f b6 0a             	movzbl (%rdx),%ecx
    d70b:	80 f9 02             	cmp    $0x2,%cl
    d70e:	0f 84 fc 01 00 00    	je     d910 <f0+0x2a00>
    d714:	80 f9 01             	cmp    $0x1,%cl
    d717:	75 29                	jne    d742 <f0+0x2832>
    d719:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d71c:	0f b7 c0             	movzwl %ax,%eax
    d71f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d722:	48 0f af c1          	imul   %rcx,%rax
    d726:	48 c1 e8 20          	shr    $0x20,%rax
    d72a:	48 39 d0             	cmp    %rdx,%rax
    d72d:	73 13                	jae    d742 <f0+0x2832>
    d72f:	49 01 c4             	add    %rax,%r12
    d732:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d737:	0f 84 d1 02 00 00    	je     da0e <f0+0x2afe>
    d73d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d742:	48 89 de             	mov    %rbx,%rsi
    d745:	48 89 ef             	mov    %rbp,%rdi
    d748:	e8 13 bf ff ff       	call   9660 <fwp_hof0.constprop.0>
    d74d:	48 89 ef             	mov    %rbp,%rdi
    d750:	e8 6b a3 ff ff       	call   7ac0 <fwp_drop0>
    d755:	48 89 df             	mov    %rbx,%rdi
    d758:	e8 63 a3 ff ff       	call   7ac0 <fwp_drop0>
    d75d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d764:	00 
    d765:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d76c:	00 00 
    d76e:	0f 85 95 04 00 00    	jne    dc09 <f0+0x2cf9>
    d774:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d77b:	31 c0                	xor    %eax,%eax
    d77d:	5b                   	pop    %rbx
    d77e:	5d                   	pop    %rbp
    d77f:	41 5c                	pop    %r12
    d781:	41 5d                	pop    %r13
    d783:	41 5e                	pop    %r14
    d785:	c3                   	ret
    d786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d78d:	00 00 00 
    d790:	4c 89 ef             	mov    %r13,%rdi
    d793:	e8 38 7b ff ff       	call   52d0 <fwp_rc_forget_slot>
    d798:	e9 2c d8 ff ff       	jmp    afc9 <f0+0xb9>
    d79d:	0f 1f 00             	nopl   (%rax)
    d7a0:	66 85 c0             	test   %ax,%ax
    d7a3:	0f 85 ae f5 ff ff    	jne    cd57 <f0+0x1e47>
    d7a9:	e9 99 f5 ff ff       	jmp    cd47 <f0+0x1e37>
    d7ae:	66 90                	xchg   %ax,%ax
    d7b0:	66 85 c0             	test   %ax,%ax
    d7b3:	0f 85 ff f4 ff ff    	jne    ccb8 <f0+0x1da8>
    d7b9:	e9 ea f4 ff ff       	jmp    cca8 <f0+0x1d98>
    d7be:	66 90                	xchg   %ax,%ax
    d7c0:	66 85 c0             	test   %ax,%ax
    d7c3:	0f 85 50 f4 ff ff    	jne    cc19 <f0+0x1d09>
    d7c9:	e9 3b f4 ff ff       	jmp    cc09 <f0+0x1cf9>
    d7ce:	66 90                	xchg   %ax,%ax
    d7d0:	66 85 c0             	test   %ax,%ax
    d7d3:	0f 85 a1 f3 ff ff    	jne    cb7a <f0+0x1c6a>
    d7d9:	e9 8c f3 ff ff       	jmp    cb6a <f0+0x1c5a>
    d7de:	66 90                	xchg   %ax,%ax
    d7e0:	66 85 c0             	test   %ax,%ax
    d7e3:	0f 85 f2 f2 ff ff    	jne    cadb <f0+0x1bcb>
    d7e9:	e9 dd f2 ff ff       	jmp    cacb <f0+0x1bbb>
    d7ee:	66 90                	xchg   %ax,%ax
    d7f0:	66 85 c0             	test   %ax,%ax
    d7f3:	0f 85 43 f2 ff ff    	jne    ca3c <f0+0x1b2c>
    d7f9:	e9 2e f2 ff ff       	jmp    ca2c <f0+0x1b1c>
    d7fe:	66 90                	xchg   %ax,%ax
    d800:	66 85 c0             	test   %ax,%ax
    d803:	0f 85 94 f1 ff ff    	jne    c99d <f0+0x1a8d>
    d809:	e9 7f f1 ff ff       	jmp    c98d <f0+0x1a7d>
    d80e:	66 90                	xchg   %ax,%ax
    d810:	66 85 c0             	test   %ax,%ax
    d813:	0f 85 e5 f0 ff ff    	jne    c8fe <f0+0x19ee>
    d819:	e9 d0 f0 ff ff       	jmp    c8ee <f0+0x19de>
    d81e:	66 90                	xchg   %ax,%ax
    d820:	66 85 c0             	test   %ax,%ax
    d823:	0f 85 fd d9 ff ff    	jne    b226 <f0+0x316>
    d829:	e9 e8 d9 ff ff       	jmp    b216 <f0+0x306>
    d82e:	66 90                	xchg   %ax,%ax
    d830:	66 85 c0             	test   %ax,%ax
    d833:	0f 85 57 d9 ff ff    	jne    b190 <f0+0x280>
    d839:	e9 42 d9 ff ff       	jmp    b180 <f0+0x270>
    d83e:	66 90                	xchg   %ax,%ax
    d840:	66 85 c0             	test   %ax,%ax
    d843:	0f 85 b1 d8 ff ff    	jne    b0fa <f0+0x1ea>
    d849:	e9 9c d8 ff ff       	jmp    b0ea <f0+0x1da>
    d84e:	66 90                	xchg   %ax,%ax
    d850:	66 85 c0             	test   %ax,%ax
    d853:	0f 85 0e eb ff ff    	jne    c367 <f0+0x1457>
    d859:	e9 f9 ea ff ff       	jmp    c357 <f0+0x1447>
    d85e:	66 90                	xchg   %ax,%ax
    d860:	66 85 c0             	test   %ax,%ax
    d863:	0f 85 5f ea ff ff    	jne    c2c8 <f0+0x13b8>
    d869:	e9 4a ea ff ff       	jmp    c2b8 <f0+0x13a8>
    d86e:	66 90                	xchg   %ax,%ax
    d870:	66 85 c0             	test   %ax,%ax
    d873:	0f 85 e2 da ff ff    	jne    b35b <f0+0x44b>
    d879:	e9 cd da ff ff       	jmp    b34b <f0+0x43b>
    d87e:	66 90                	xchg   %ax,%ax
    d880:	66 85 c0             	test   %ax,%ax
    d883:	0f 85 33 da ff ff    	jne    b2bc <f0+0x3ac>
    d889:	e9 1e da ff ff       	jmp    b2ac <f0+0x39c>
    d88e:	66 90                	xchg   %ax,%ax
    d890:	66 85 c0             	test   %ax,%ax
    d893:	0f 85 c6 ef ff ff    	jne    c85f <f0+0x194f>
    d899:	e9 b1 ef ff ff       	jmp    c84f <f0+0x193f>
    d89e:	66 90                	xchg   %ax,%ax
    d8a0:	66 85 c0             	test   %ax,%ax
    d8a3:	0f 85 17 ef ff ff    	jne    c7c0 <f0+0x18b0>
    d8a9:	e9 02 ef ff ff       	jmp    c7b0 <f0+0x18a0>
    d8ae:	66 90                	xchg   %ax,%ax
    d8b0:	66 85 c0             	test   %ax,%ax
    d8b3:	0f 85 68 ee ff ff    	jne    c721 <f0+0x1811>
    d8b9:	e9 53 ee ff ff       	jmp    c711 <f0+0x1801>
    d8be:	66 90                	xchg   %ax,%ax
    d8c0:	66 85 c0             	test   %ax,%ax
    d8c3:	0f 85 b9 ed ff ff    	jne    c682 <f0+0x1772>
    d8c9:	e9 a4 ed ff ff       	jmp    c672 <f0+0x1762>
    d8ce:	66 90                	xchg   %ax,%ax
    d8d0:	66 85 c0             	test   %ax,%ax
    d8d3:	0f 85 0a ed ff ff    	jne    c5e3 <f0+0x16d3>
    d8d9:	e9 f5 ec ff ff       	jmp    c5d3 <f0+0x16c3>
    d8de:	66 90                	xchg   %ax,%ax
    d8e0:	66 85 c0             	test   %ax,%ax
    d8e3:	0f 85 5b ec ff ff    	jne    c544 <f0+0x1634>
    d8e9:	e9 46 ec ff ff       	jmp    c534 <f0+0x1624>
    d8ee:	66 90                	xchg   %ax,%ax
    d8f0:	66 85 c0             	test   %ax,%ax
    d8f3:	0f 85 ac eb ff ff    	jne    c4a5 <f0+0x1595>
    d8f9:	e9 97 eb ff ff       	jmp    c495 <f0+0x1585>
    d8fe:	66 90                	xchg   %ax,%ax
    d900:	66 85 c0             	test   %ax,%ax
    d903:	0f 85 fd ea ff ff    	jne    c406 <f0+0x14f6>
    d909:	e9 e8 ea ff ff       	jmp    c3f6 <f0+0x14e6>
    d90e:	66 90                	xchg   %ax,%ax
    d910:	66 85 c0             	test   %ax,%ax
    d913:	0f 85 29 fe ff ff    	jne    d742 <f0+0x2832>
    d919:	e9 14 fe ff ff       	jmp    d732 <f0+0x2822>
    d91e:	66 90                	xchg   %ax,%ax
    d920:	66 85 c0             	test   %ax,%ax
    d923:	0f 85 7f fd ff ff    	jne    d6a8 <f0+0x2798>
    d929:	e9 6a fd ff ff       	jmp    d698 <f0+0x2788>
    d92e:	66 90                	xchg   %ax,%ax
    d930:	66 85 c0             	test   %ax,%ax
    d933:	0f 85 d0 fc ff ff    	jne    d609 <f0+0x26f9>
    d939:	e9 bb fc ff ff       	jmp    d5f9 <f0+0x26e9>
    d93e:	66 90                	xchg   %ax,%ax
    d940:	66 85 c0             	test   %ax,%ax
    d943:	0f 85 21 fc ff ff    	jne    d56a <f0+0x265a>
    d949:	e9 0c fc ff ff       	jmp    d55a <f0+0x264a>
    d94e:	66 90                	xchg   %ax,%ax
    d950:	66 85 c0             	test   %ax,%ax
    d953:	0f 85 72 fb ff ff    	jne    d4cb <f0+0x25bb>
    d959:	e9 5d fb ff ff       	jmp    d4bb <f0+0x25ab>
    d95e:	66 90                	xchg   %ax,%ax
    d960:	66 85 c0             	test   %ax,%ax
    d963:	0f 85 c3 fa ff ff    	jne    d42c <f0+0x251c>
    d969:	e9 ae fa ff ff       	jmp    d41c <f0+0x250c>
    d96e:	66 90                	xchg   %ax,%ax
    d970:	66 85 c0             	test   %ax,%ax
    d973:	0f 85 14 fa ff ff    	jne    d38d <f0+0x247d>
    d979:	e9 ff f9 ff ff       	jmp    d37d <f0+0x246d>
    d97e:	66 90                	xchg   %ax,%ax
    d980:	66 85 c0             	test   %ax,%ax
    d983:	0f 85 65 f9 ff ff    	jne    d2ee <f0+0x23de>
    d989:	e9 50 f9 ff ff       	jmp    d2de <f0+0x23ce>
    d98e:	66 90                	xchg   %ax,%ax
    d990:	66 85 c0             	test   %ax,%ax
    d993:	0f 85 b6 f8 ff ff    	jne    d24f <f0+0x233f>
    d999:	e9 a1 f8 ff ff       	jmp    d23f <f0+0x232f>
    d99e:	66 90                	xchg   %ax,%ax
    d9a0:	66 85 c0             	test   %ax,%ax
    d9a3:	0f 85 07 f8 ff ff    	jne    d1b0 <f0+0x22a0>
    d9a9:	e9 f2 f7 ff ff       	jmp    d1a0 <f0+0x2290>
    d9ae:	66 90                	xchg   %ax,%ax
    d9b0:	66 85 c0             	test   %ax,%ax
    d9b3:	0f 85 58 f7 ff ff    	jne    d111 <f0+0x2201>
    d9b9:	e9 43 f7 ff ff       	jmp    d101 <f0+0x21f1>
    d9be:	66 90                	xchg   %ax,%ax
    d9c0:	66 85 c0             	test   %ax,%ax
    d9c3:	0f 85 a9 f6 ff ff    	jne    d072 <f0+0x2162>
    d9c9:	e9 94 f6 ff ff       	jmp    d062 <f0+0x2152>
    d9ce:	66 90                	xchg   %ax,%ax
    d9d0:	66 85 c0             	test   %ax,%ax
    d9d3:	0f 85 fa f5 ff ff    	jne    cfd3 <f0+0x20c3>
    d9d9:	e9 e5 f5 ff ff       	jmp    cfc3 <f0+0x20b3>
    d9de:	66 90                	xchg   %ax,%ax
    d9e0:	66 85 c0             	test   %ax,%ax
    d9e3:	0f 85 4b f5 ff ff    	jne    cf34 <f0+0x2024>
    d9e9:	e9 36 f5 ff ff       	jmp    cf24 <f0+0x2014>
    d9ee:	66 90                	xchg   %ax,%ax
    d9f0:	66 85 c0             	test   %ax,%ax
    d9f3:	0f 85 9c f4 ff ff    	jne    ce95 <f0+0x1f85>
    d9f9:	e9 87 f4 ff ff       	jmp    ce85 <f0+0x1f75>
    d9fe:	66 90                	xchg   %ax,%ax
    da00:	66 85 c0             	test   %ax,%ax
    da03:	0f 85 ed f3 ff ff    	jne    cdf6 <f0+0x1ee6>
    da09:	e9 d8 f3 ff ff       	jmp    cde6 <f0+0x1ed6>
    da0e:	4c 89 e7             	mov    %r12,%rdi
    da11:	e8 ba 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da16:	e9 22 fd ff ff       	jmp    d73d <f0+0x282d>
    da1b:	4c 89 e7             	mov    %r12,%rdi
    da1e:	e8 ad 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da23:	e9 cd d6 ff ff       	jmp    b0f5 <f0+0x1e5>
    da28:	4c 89 e7             	mov    %r12,%rdi
    da2b:	e8 a0 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da30:	e9 56 d7 ff ff       	jmp    b18b <f0+0x27b>
    da35:	4c 89 e7             	mov    %r12,%rdi
    da38:	e8 93 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da3d:	e9 df d7 ff ff       	jmp    b221 <f0+0x311>
    da42:	4c 89 e7             	mov    %r12,%rdi
    da45:	e8 86 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da4a:	e9 68 d8 ff ff       	jmp    b2b7 <f0+0x3a7>
    da4f:	4c 89 e7             	mov    %r12,%rdi
    da52:	e8 79 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da57:	e9 fa d8 ff ff       	jmp    b356 <f0+0x446>
    da5c:	4c 89 e7             	mov    %r12,%rdi
    da5f:	e8 6c 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da64:	e9 5a e8 ff ff       	jmp    c2c3 <f0+0x13b3>
    da69:	4c 89 e7             	mov    %r12,%rdi
    da6c:	e8 5f 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da71:	e9 ec e8 ff ff       	jmp    c362 <f0+0x1452>
    da76:	4c 89 e7             	mov    %r12,%rdi
    da79:	e8 52 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da7e:	e9 7e e9 ff ff       	jmp    c401 <f0+0x14f1>
    da83:	4c 89 e7             	mov    %r12,%rdi
    da86:	e8 45 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da8b:	e9 10 ea ff ff       	jmp    c4a0 <f0+0x1590>
    da90:	4c 89 e7             	mov    %r12,%rdi
    da93:	e8 38 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    da98:	e9 a2 ea ff ff       	jmp    c53f <f0+0x162f>
    da9d:	4c 89 e7             	mov    %r12,%rdi
    daa0:	e8 2b 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    daa5:	e9 34 eb ff ff       	jmp    c5de <f0+0x16ce>
    daaa:	4c 89 e7             	mov    %r12,%rdi
    daad:	e8 1e 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dab2:	e9 c6 eb ff ff       	jmp    c67d <f0+0x176d>
    dab7:	4c 89 e7             	mov    %r12,%rdi
    daba:	e8 11 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dabf:	e9 58 ec ff ff       	jmp    c71c <f0+0x180c>
    dac4:	4c 89 e7             	mov    %r12,%rdi
    dac7:	e8 04 78 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dacc:	e9 ea ec ff ff       	jmp    c7bb <f0+0x18ab>
    dad1:	4c 89 e7             	mov    %r12,%rdi
    dad4:	e8 f7 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dad9:	e9 7c ed ff ff       	jmp    c85a <f0+0x194a>
    dade:	4c 89 e7             	mov    %r12,%rdi
    dae1:	e8 ea 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dae6:	e9 0e ee ff ff       	jmp    c8f9 <f0+0x19e9>
    daeb:	4c 89 e7             	mov    %r12,%rdi
    daee:	e8 dd 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    daf3:	e9 a0 ee ff ff       	jmp    c998 <f0+0x1a88>
    daf8:	4c 89 e7             	mov    %r12,%rdi
    dafb:	e8 d0 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db00:	e9 32 ef ff ff       	jmp    ca37 <f0+0x1b27>
    db05:	4c 89 e7             	mov    %r12,%rdi
    db08:	e8 c3 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db0d:	e9 c4 ef ff ff       	jmp    cad6 <f0+0x1bc6>
    db12:	4c 89 e7             	mov    %r12,%rdi
    db15:	e8 b6 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db1a:	e9 56 f0 ff ff       	jmp    cb75 <f0+0x1c65>
    db1f:	4c 89 e7             	mov    %r12,%rdi
    db22:	e8 a9 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db27:	e9 e8 f0 ff ff       	jmp    cc14 <f0+0x1d04>
    db2c:	4c 89 e7             	mov    %r12,%rdi
    db2f:	e8 9c 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db34:	e9 7a f1 ff ff       	jmp    ccb3 <f0+0x1da3>
    db39:	4c 89 e7             	mov    %r12,%rdi
    db3c:	e8 8f 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db41:	e9 0c f2 ff ff       	jmp    cd52 <f0+0x1e42>
    db46:	4c 89 e7             	mov    %r12,%rdi
    db49:	e8 82 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db4e:	e9 9e f2 ff ff       	jmp    cdf1 <f0+0x1ee1>
    db53:	4c 89 e7             	mov    %r12,%rdi
    db56:	e8 75 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db5b:	e9 30 f3 ff ff       	jmp    ce90 <f0+0x1f80>
    db60:	4c 89 e7             	mov    %r12,%rdi
    db63:	e8 68 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db68:	e9 c2 f3 ff ff       	jmp    cf2f <f0+0x201f>
    db6d:	4c 89 e7             	mov    %r12,%rdi
    db70:	e8 5b 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db75:	e9 54 f4 ff ff       	jmp    cfce <f0+0x20be>
    db7a:	4c 89 e7             	mov    %r12,%rdi
    db7d:	e8 4e 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db82:	e9 e6 f4 ff ff       	jmp    d06d <f0+0x215d>
    db87:	4c 89 e7             	mov    %r12,%rdi
    db8a:	e8 41 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db8f:	e9 78 f5 ff ff       	jmp    d10c <f0+0x21fc>
    db94:	4c 89 e7             	mov    %r12,%rdi
    db97:	e8 34 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    db9c:	e9 0a f6 ff ff       	jmp    d1ab <f0+0x229b>
    dba1:	4c 89 e7             	mov    %r12,%rdi
    dba4:	e8 27 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dba9:	e9 9c f6 ff ff       	jmp    d24a <f0+0x233a>
    dbae:	4c 89 e7             	mov    %r12,%rdi
    dbb1:	e8 1a 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbb6:	e9 2e f7 ff ff       	jmp    d2e9 <f0+0x23d9>
    dbbb:	4c 89 e7             	mov    %r12,%rdi
    dbbe:	e8 0d 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbc3:	e9 c0 f7 ff ff       	jmp    d388 <f0+0x2478>
    dbc8:	4c 89 e7             	mov    %r12,%rdi
    dbcb:	e8 00 77 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbd0:	e9 52 f8 ff ff       	jmp    d427 <f0+0x2517>
    dbd5:	4c 89 e7             	mov    %r12,%rdi
    dbd8:	e8 f3 76 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbdd:	e9 e4 f8 ff ff       	jmp    d4c6 <f0+0x25b6>
    dbe2:	4c 89 e7             	mov    %r12,%rdi
    dbe5:	e8 e6 76 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbea:	e9 76 f9 ff ff       	jmp    d565 <f0+0x2655>
    dbef:	4c 89 e7             	mov    %r12,%rdi
    dbf2:	e8 d9 76 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dbf7:	e9 08 fa ff ff       	jmp    d604 <f0+0x26f4>
    dbfc:	4c 89 e7             	mov    %r12,%rdi
    dbff:	e8 cc 76 ff ff       	call   52d0 <fwp_rc_forget_slot>
    dc04:	e9 9a fa ff ff       	jmp    d6a3 <f0+0x2793>
    dc09:	e8 32 58 ff ff       	call   3440 <__stack_chk_fail@plt>
    dc0e:	66 90                	xchg   %ax,%ax

000000000000dc10 <fwp_main_thread>:
    dc10:	f3 0f 1e fa          	endbr64
    dc14:	41 54                	push   %r12
    dc16:	55                   	push   %rbp
    dc17:	53                   	push   %rbx
    dc18:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    dc1f:	8b 0d bf 6e 01 00    	mov    0x16ebf(%rip),%ecx        # 24ae4 <fwp_heap+0x13a4>
    dc25:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    dc2c:	00 00 
    dc2e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    dc35:	00 
    dc36:	31 c0                	xor    %eax,%eax
    dc38:	85 c9                	test   %ecx,%ecx
    dc3a:	0f 84 68 06 00 00    	je     e2a8 <fwp_main_thread+0x698>
    dc40:	8b 15 a2 6e 01 00    	mov    0x16ea2(%rip),%edx        # 24ae8 <fwp_heap+0x13a8>
    dc46:	85 d2                	test   %edx,%edx
    dc48:	0f 85 42 06 00 00    	jne    e290 <fwp_main_thread+0x680>
    dc4e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    dc53:	31 f6                	xor    %esi,%esi
    dc55:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    dc5a:	48 c7 05 83 54 01 00 	movq   $0x40000000,0x15483(%rip)        # 230e8 <fwp_main_stack_size>
    dc61:	00 00 00 40 
    dc65:	48 89 05 84 54 01 00 	mov    %rax,0x15484(%rip)        # 230f0 <fwp_main_stack_top>
    dc6c:	48 8d 05 0d 54 00 00 	lea    0x540d(%rip),%rax        # 13080 <alt.5>
    dc73:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    dc78:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    dc7f:	01 00 
    dc81:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    dc88:	00 
    dc89:	e8 f2 59 ff ff       	call   3680 <sigaltstack@plt>
    dc8e:	85 c0                	test   %eax,%eax
    dc90:	0f 85 4a 06 00 00    	jne    e2e0 <fwp_main_thread+0x6d0>
    dc96:	31 c0                	xor    %eax,%eax
    dc98:	b9 12 00 00 00       	mov    $0x12,%ecx
    dc9d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dca2:	f3 48 ab             	rep stos %rax,(%rdi)
    dca5:	48 8d 05 04 60 ff ff 	lea    -0x9ffc(%rip),%rax        # 3cb0 <fwp_segv>
    dcac:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dcb1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    dcb8:	04 00 00 08 
    dcbc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    dcc1:	e8 8a 58 ff ff       	call   3550 <sigemptyset@plt>
    dcc6:	85 c0                	test   %eax,%eax
    dcc8:	0f 85 12 06 00 00    	jne    e2e0 <fwp_main_thread+0x6d0>
    dcce:	31 d2                	xor    %edx,%edx
    dcd0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dcd5:	bf 0b 00 00 00       	mov    $0xb,%edi
    dcda:	e8 01 57 ff ff       	call   33e0 <sigaction@plt>
    dcdf:	85 c0                	test   %eax,%eax
    dce1:	0f 85 f9 05 00 00    	jne    e2e0 <fwp_main_thread+0x6d0>
    dce7:	31 d2                	xor    %edx,%edx
    dce9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dcee:	bf 07 00 00 00       	mov    $0x7,%edi
    dcf3:	e8 e8 56 ff ff       	call   33e0 <sigaction@plt>
    dcf8:	85 c0                	test   %eax,%eax
    dcfa:	0f 85 e0 05 00 00    	jne    e2e0 <fwp_main_thread+0x6d0>
    dd00:	8b 05 6a 53 00 00    	mov    0x536a(%rip),%eax        # 13070 <st.3>
    dd06:	85 c0                	test   %eax,%eax
    dd08:	0f 84 62 05 00 00    	je     e270 <fwp_main_thread+0x660>
    dd0e:	48 8b 2d 0b 5a 01 00 	mov    0x15a0b(%rip),%rbp        # 23720 <fwp_cur>
    dd15:	48 85 ed             	test   %rbp,%rbp
    dd18:	0f 84 72 03 00 00    	je     e090 <fwp_main_thread+0x480>
    dd1e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    dd23:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    dd27:	48 89 eb             	mov    %rbp,%rbx
    dd2a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dd2f:	0f 84 41 01 00 00    	je     de76 <fwp_main_thread+0x266>
    dd35:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    dd3a:	0f 84 80 02 00 00    	je     dfc0 <fwp_main_thread+0x3b0>
    dd40:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dd44:	0f 84 66 02 00 00    	je     dfb0 <fwp_main_thread+0x3a0>
    dd4a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dd4e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dd52:	0f 85 e8 02 00 00    	jne    e040 <fwp_main_thread+0x430>
    dd58:	48 8b 43 60          	mov    0x60(%rbx),%rax
    dd5c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dd63:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dd67:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dd6e:	00 00 00 00 
    dd72:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dd79:	48 85 d2             	test   %rdx,%rdx
    dd7c:	74 07                	je     dd85 <fwp_main_thread+0x175>
    dd7e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dd85:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dd89:	48 85 c0             	test   %rax,%rax
    dd8c:	74 34                	je     ddc2 <fwp_main_thread+0x1b2>
    dd8e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    dd92:	48 8b 05 5f 59 01 00 	mov    0x1595f(%rip),%rax        # 236f8 <fwp_timers>
    dd99:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    dd9d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    dda4:	00 00 00 00 
    dda8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ddaf:	48 85 c0             	test   %rax,%rax
    ddb2:	74 07                	je     ddbb <fwp_main_thread+0x1ab>
    ddb4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ddbb:	48 89 1d 36 59 01 00 	mov    %rbx,0x15936(%rip)        # 236f8 <fwp_timers>
    ddc2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ddc6:	e8 c5 98 ff ff       	call   7690 <fwp_block>
    ddcb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    ddd2:	48 85 c9             	test   %rcx,%rcx
    ddd5:	74 47                	je     de1e <fwp_main_thread+0x20e>
    ddd7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ddde:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dde5:	48 85 d2             	test   %rdx,%rdx
    dde8:	0f 84 92 02 00 00    	je     e080 <fwp_main_thread+0x470>
    ddee:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ddf5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ddfc:	48 85 c0             	test   %rax,%rax
    ddff:	74 07                	je     de08 <fwp_main_thread+0x1f8>
    de01:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    de08:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    de0f:	00 00 00 00 
    de13:	66 0f ef c0          	pxor   %xmm0,%xmm0
    de17:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    de1e:	48 8b 0d fb 58 01 00 	mov    0x158fb(%rip),%rcx        # 23720 <fwp_cur>
    de25:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    de29:	0f 84 01 02 00 00    	je     e030 <fwp_main_thread+0x420>
    de2f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    de36:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    de3d:	48 85 d2             	test   %rdx,%rdx
    de40:	0f 84 fa 03 00 00    	je     e240 <fwp_main_thread+0x630>
    de46:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    de4d:	48 85 c0             	test   %rax,%rax
    de50:	74 07                	je     de59 <fwp_main_thread+0x249>
    de52:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    de59:	66 0f ef c9          	pxor   %xmm1,%xmm1
    de5d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    de61:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    de68:	48 89 cb             	mov    %rcx,%rbx
    de6b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    de70:	0f 85 bf fe ff ff    	jne    dd35 <fwp_main_thread+0x125>
    de76:	48 83 3d 3a 75 01 00 	cmpq   $0x0,0x1753a(%rip)        # 253b8 <fwp_state_len>
    de7d:	00 
    de7e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    de82:	0f 84 ba 00 00 00    	je     df42 <fwp_main_thread+0x332>
    de88:	48 39 1d 89 58 01 00 	cmp    %rbx,0x15889(%rip)        # 23718 <fwp_root>
    de8f:	c7 05 e7 51 01 00 00 	movl   $0x0,0x151e7(%rip)        # 23080 <fwp_exit_code>
    de96:	00 00 00 
    de99:	0f 85 5f 04 00 00    	jne    e2fe <fwp_main_thread+0x6ee>
    de9f:	48 85 db             	test   %rbx,%rbx
    dea2:	0f 84 0e 02 00 00    	je     e0b6 <fwp_main_thread+0x4a6>
    dea8:	48 8b 15 39 58 01 00 	mov    0x15839(%rip),%rdx        # 236e8 <fwp_tasks_active>
    deaf:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    deb3:	48 85 d2             	test   %rdx,%rdx
    deb6:	0f 84 fa 01 00 00    	je     e0b6 <fwp_main_thread+0x4a6>
    debc:	0f 1f 40 00          	nopl   0x0(%rax)
    dec0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    dec4:	75 08                	jne    dece <fwp_main_thread+0x2be>
    dec6:	48 89 d7             	mov    %rdx,%rdi
    dec9:	e8 a2 61 ff ff       	call   4070 <fwp_cancel_tree.part.0>
    dece:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ded5:	48 85 d2             	test   %rdx,%rdx
    ded8:	75 e6                	jne    dec0 <fwp_main_thread+0x2b0>
    deda:	eb 31                	jmp    df0d <fwp_main_thread+0x2fd>
    dedc:	0f 1f 40 00          	nopl   0x0(%rax)
    dee0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    dee7:	48 89 1d 12 58 01 00 	mov    %rbx,0x15812(%rip)        # 23700 <fwp_ready_tail>
    deee:	e8 9d 97 ff ff       	call   7690 <fwp_block>
    def3:	e8 88 95 ff ff       	call   7480 <fwp_free_zombie>
    def8:	48 83 3d e8 57 01 00 	cmpq   $0x0,0x157e8(%rip)        # 236e8 <fwp_tasks_active>
    deff:	00 
    df00:	0f 84 b0 01 00 00    	je     e0b6 <fwp_main_thread+0x4a6>
    df06:	48 8b 1d 0b 58 01 00 	mov    0x1580b(%rip),%rbx        # 23718 <fwp_root>
    df0d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    df11:	75 db                	jne    deee <fwp_main_thread+0x2de>
    df13:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    df17:	75 d5                	jne    deee <fwp_main_thread+0x2de>
    df19:	48 8b 05 e0 57 01 00 	mov    0x157e0(%rip),%rax        # 23700 <fwp_ready_tail>
    df20:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    df24:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    df2b:	00 00 00 00 
    df2f:	48 85 c0             	test   %rax,%rax
    df32:	75 ac                	jne    dee0 <fwp_main_thread+0x2d0>
    df34:	48 89 1d cd 57 01 00 	mov    %rbx,0x157cd(%rip)        # 23708 <fwp_ready_head>
    df3b:	eb aa                	jmp    dee7 <fwp_main_thread+0x2d7>
    df3d:	0f 1f 00             	nopl   (%rax)
    df40:	31 db                	xor    %ebx,%ebx
    df42:	48 83 3d 5e 74 01 00 	cmpq   $0x0,0x1745e(%rip)        # 253a8 <fwp_state_owners>
    df49:	00 
    df4a:	0f 85 38 ff ff ff    	jne    de88 <fwp_main_thread+0x278>
    df50:	48 8b 3d 69 74 01 00 	mov    0x17469(%rip),%rdi        # 253c0 <fwp_state>
    df57:	e8 b4 75 ff ff       	call   5510 <fwp_mem_free>
    df5c:	48 c7 05 59 74 01 00 	movq   $0x0,0x17459(%rip)        # 253c0 <fwp_state>
    df63:	00 00 00 00 
    df67:	48 c7 05 3e 74 01 00 	movq   $0x0,0x1743e(%rip)        # 253b0 <fwp_state_cap>
    df6e:	00 00 00 00 
    df72:	48 85 db             	test   %rbx,%rbx
    df75:	0f 84 46 03 00 00    	je     e2c1 <fwp_main_thread+0x6b1>
    df7b:	48 39 1d 96 57 01 00 	cmp    %rbx,0x15796(%rip)        # 23718 <fwp_root>
    df82:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    df89:	00 00 00 00 
    df8d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    df94:	00 00 00 00 
    df98:	c7 05 de 50 01 00 00 	movl   $0x0,0x150de(%rip)        # 23080 <fwp_exit_code>
    df9f:	00 00 00 
    dfa2:	0f 84 00 ff ff ff    	je     dea8 <fwp_main_thread+0x298>
    dfa8:	e9 68 57 ff ff       	jmp    3715 <fwp_main_thread.cold>
    dfad:	0f 1f 00             	nopl   (%rax)
    dfb0:	e8 1b 63 ff ff       	call   42d0 <fwp_now_ns>
    dfb5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    dfb9:	0f 8d 91 02 00 00    	jge    e250 <fwp_main_thread+0x640>
    dfbf:	90                   	nop
    dfc0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dfc4:	0f 85 80 fd ff ff    	jne    dd4a <fwp_main_thread+0x13a>
    dfca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    dfce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dfd2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dfd6:	0f 85 80 fd ff ff    	jne    dd5c <fwp_main_thread+0x14c>
    dfdc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dfe0:	48 85 c9             	test   %rcx,%rcx
    dfe3:	0f 84 73 fd ff ff    	je     dd5c <fwp_main_thread+0x14c>
    dfe9:	48 85 c0             	test   %rax,%rax
    dfec:	0f 84 ff 02 00 00    	je     e2f1 <fwp_main_thread+0x6e1>
    dff2:	48 39 c8             	cmp    %rcx,%rax
    dff5:	48 0f 4f c1          	cmovg  %rcx,%rax
    dff9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e000:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e004:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e00b:	00 00 00 00 
    e00f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e016:	48 85 d2             	test   %rdx,%rdx
    e019:	74 07                	je     e022 <fwp_main_thread+0x412>
    e01b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e022:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e026:	e9 63 fd ff ff       	jmp    dd8e <fwp_main_thread+0x17e>
    e02b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e030:	48 89 cb             	mov    %rcx,%rbx
    e033:	e9 f2 fc ff ff       	jmp    dd2a <fwp_main_thread+0x11a>
    e038:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e03f:	00 
    e040:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e044:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e04b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e052:	00 00 00 00 
    e056:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e05d:	48 85 c0             	test   %rax,%rax
    e060:	0f 84 52 02 00 00    	je     e2b8 <fwp_main_thread+0x6a8>
    e066:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e06d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e071:	e9 4c fd ff ff       	jmp    ddc2 <fwp_main_thread+0x1b2>
    e076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e07d:	00 00 00 
    e080:	48 89 01             	mov    %rax,(%rcx)
    e083:	e9 74 fd ff ff       	jmp    ddfc <fwp_main_thread+0x1ec>
    e088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e08f:	00 
    e090:	48 83 3d 20 73 01 00 	cmpq   $0x0,0x17320(%rip)        # 253b8 <fwp_state_len>
    e097:	00 
    e098:	0f 84 a2 fe ff ff    	je     df40 <fwp_main_thread+0x330>
    e09e:	48 83 3d 72 56 01 00 	cmpq   $0x0,0x15672(%rip)        # 23718 <fwp_root>
    e0a5:	00 
    e0a6:	c7 05 d0 4f 01 00 00 	movl   $0x0,0x14fd0(%rip)        # 23080 <fwp_exit_code>
    e0ad:	00 00 00 
    e0b0:	0f 85 43 02 00 00    	jne    e2f9 <fwp_main_thread+0x6e9>
    e0b6:	e8 c5 93 ff ff       	call   7480 <fwp_free_zombie>
    e0bb:	48 83 3d 45 56 01 00 	cmpq   $0x0,0x15645(%rip)        # 23708 <fwp_ready_head>
    e0c2:	00 
    e0c3:	0f 85 4c 56 ff ff    	jne    3715 <fwp_main_thread.cold>
    e0c9:	48 83 3d 27 56 01 00 	cmpq   $0x0,0x15627(%rip)        # 236f8 <fwp_timers>
    e0d0:	00 
    e0d1:	0f 85 3e 56 ff ff    	jne    3715 <fwp_main_thread.cold>
    e0d7:	8b 1d 1f 50 01 00    	mov    0x1501f(%rip),%ebx        # 230fc <fwp_stack_pool_n>
    e0dd:	85 db                	test   %ebx,%ebx
    e0df:	74 36                	je     e117 <fwp_main_thread+0x507>
    e0e1:	83 eb 01             	sub    $0x1,%ebx
    e0e4:	48 8d 05 15 50 01 00 	lea    0x15015(%rip),%rax        # 23100 <fwp_stack_pool>
    e0eb:	48 63 d3             	movslq %ebx,%rdx
    e0ee:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e0f2:	eb 07                	jmp    e0fb <fwp_main_thread+0x4eb>
    e0f4:	0f 1f 40 00          	nopl   0x0(%rax)
    e0f8:	83 eb 01             	sub    $0x1,%ebx
    e0fb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e0ff:	be 00 00 00 10       	mov    $0x10000000,%esi
    e104:	89 1d f2 4f 01 00    	mov    %ebx,0x14ff2(%rip)        # 230fc <fwp_stack_pool_n>
    e10a:	48 83 ed 08          	sub    $0x8,%rbp
    e10e:	e8 9d 54 ff ff       	call   35b0 <munmap@plt>
    e113:	85 db                	test   %ebx,%ebx
    e115:	75 e1                	jne    e0f8 <fwp_main_thread+0x4e8>
    e117:	8b 3d fb 4e 00 00    	mov    0x4efb(%rip),%edi        # 13018 <fwp_epfd>
    e11d:	85 ff                	test   %edi,%edi
    e11f:	78 05                	js     e126 <fwp_main_thread+0x516>
    e121:	e8 8a 53 ff ff       	call   34b0 <close@plt>
    e126:	4c 8b 25 d3 51 01 00 	mov    0x151d3(%rip),%r12        # 23300 <fwp_nfdws>
    e12d:	48 8b 2d d4 51 01 00 	mov    0x151d4(%rip),%rbp        # 23308 <fwp_fdws>
    e134:	31 db                	xor    %ebx,%ebx
    e136:	c7 05 d8 4e 00 00 ff 	movl   $0xffffffff,0x4ed8(%rip)        # 13018 <fwp_epfd>
    e13d:	ff ff ff 
    e140:	4d 85 e4             	test   %r12,%r12
    e143:	74 38                	je     e17d <fwp_main_thread+0x56d>
    e145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e14c:	00 00 00 00 
    e150:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e155:	48 85 ff             	test   %rdi,%rdi
    e158:	74 1a                	je     e174 <fwp_main_thread+0x564>
    e15a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e15e:	0f 85 b1 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e164:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e169:	0f 85 a6 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e16f:	e8 9c 73 ff ff       	call   5510 <fwp_mem_free>
    e174:	48 83 c3 01          	add    $0x1,%rbx
    e178:	4c 39 e3             	cmp    %r12,%rbx
    e17b:	75 d3                	jne    e150 <fwp_main_thread+0x540>
    e17d:	48 89 ef             	mov    %rbp,%rdi
    e180:	e8 8b 73 ff ff       	call   5510 <fwp_mem_free>
    e185:	48 8b 15 8c 55 01 00 	mov    0x1558c(%rip),%rdx        # 23718 <fwp_root>
    e18c:	48 c7 05 71 51 01 00 	movq   $0x0,0x15171(%rip)        # 23308 <fwp_fdws>
    e193:	00 00 00 00 
    e197:	48 c7 05 5e 51 01 00 	movq   $0x0,0x1515e(%rip)        # 23300 <fwp_nfdws>
    e19e:	00 00 00 00 
    e1a2:	48 85 d2             	test   %rdx,%rdx
    e1a5:	74 4e                	je     e1f5 <fwp_main_thread+0x5e5>
    e1a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e1ac:	0f 85 63 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e1b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e1b9:	00 
    e1ba:	0f 85 55 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e1c0:	48 83 3d f0 71 01 00 	cmpq   $0x0,0x171f0(%rip)        # 253b8 <fwp_state_len>
    e1c7:	00 
    e1c8:	0f 85 47 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e1ce:	48 83 3d d2 71 01 00 	cmpq   $0x0,0x171d2(%rip)        # 253a8 <fwp_state_owners>
    e1d5:	00 
    e1d6:	0f 85 39 55 ff ff    	jne    3715 <fwp_main_thread.cold>
    e1dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e1e1:	31 c0                	xor    %eax,%eax
    e1e3:	48 8d 3d 36 51 01 00 	lea    0x15136(%rip),%rdi        # 23320 <fwp_root_context>
    e1ea:	f3 48 ab             	rep stos %rax,(%rdi)
    e1ed:	48 89 d7             	mov    %rdx,%rdi
    e1f0:	e8 1b 73 ff ff       	call   5510 <fwp_mem_free>
    e1f5:	48 8b 3d 24 4e 00 00 	mov    0x4e24(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e1fc:	48 c7 05 19 55 01 00 	movq   $0x0,0x15519(%rip)        # 23720 <fwp_cur>
    e203:	00 00 00 00 
    e207:	48 c7 05 06 55 01 00 	movq   $0x0,0x15506(%rip)        # 23718 <fwp_root>
    e20e:	00 00 00 00 
    e212:	e8 79 53 ff ff       	call   3590 <fflush@plt>
    e217:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e21e:	00 
    e21f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e226:	00 00 
    e228:	0f 85 be 00 00 00    	jne    e2ec <fwp_main_thread+0x6dc>
    e22e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e235:	31 c0                	xor    %eax,%eax
    e237:	5b                   	pop    %rbx
    e238:	5d                   	pop    %rbp
    e239:	41 5c                	pop    %r12
    e23b:	c3                   	ret
    e23c:	0f 1f 40 00          	nopl   0x0(%rax)
    e240:	48 89 05 b1 54 01 00 	mov    %rax,0x154b1(%rip)        # 236f8 <fwp_timers>
    e247:	e9 01 fc ff ff       	jmp    de4d <fwp_main_thread+0x23d>
    e24c:	0f 1f 40 00          	nopl   0x0(%rax)
    e250:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e254:	0f 85 66 fd ff ff    	jne    dfc0 <fwp_main_thread+0x3b0>
    e25a:	48 89 ef             	mov    %rbp,%rdi
    e25d:	e8 0e 5e ff ff       	call   4070 <fwp_cancel_tree.part.0>
    e262:	e9 59 fd ff ff       	jmp    dfc0 <fwp_main_thread+0x3b0>
    e267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e26e:	00 00 
    e270:	e8 9b cc ff ff       	call   af10 <f0>
    e275:	48 c7 05 e8 4d 00 00 	movq   $0x0,0x4de8(%rip)        # 13068 <v.2>
    e27c:	00 00 00 00 
    e280:	c7 05 e6 4d 00 00 01 	movl   $0x1,0x4de6(%rip)        # 13070 <st.3>
    e287:	00 00 00 
    e28a:	e9 7f fa ff ff       	jmp    dd0e <fwp_main_thread+0xfe>
    e28f:	90                   	nop
    e290:	48 8d 3d 49 67 ff ff 	lea    -0x98b7(%rip),%rdi        # 49e0 <fwp_heap_report>
    e297:	e8 84 02 00 00       	call   e520 <atexit>
    e29c:	e9 ad f9 ff ff       	jmp    dc4e <fwp_main_thread+0x3e>
    e2a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e2a8:	e8 43 68 ff ff       	call   4af0 <fwp_heap_init>
    e2ad:	e9 8e f9 ff ff       	jmp    dc40 <fwp_main_thread+0x30>
    e2b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e2b8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e2bc:	e9 01 fb ff ff       	jmp    ddc2 <fwp_main_thread+0x1b2>
    e2c1:	48 83 3d 4f 54 01 00 	cmpq   $0x0,0x1544f(%rip)        # 23718 <fwp_root>
    e2c8:	00 
    e2c9:	c7 05 ad 4d 01 00 00 	movl   $0x0,0x14dad(%rip)        # 23080 <fwp_exit_code>
    e2d0:	00 00 00 
    e2d3:	0f 84 dd fd ff ff    	je     e0b6 <fwp_main_thread+0x4a6>
    e2d9:	e9 37 54 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e2de:	66 90                	xchg   %ax,%ax
    e2e0:	48 8d 3d 11 16 00 00 	lea    0x1611(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    e2e7:	e8 74 5e ff ff       	call   4160 <fwp_trap>
    e2ec:	e8 4f 51 ff ff       	call   3440 <__stack_chk_fail@plt>
    e2f1:	48 89 c8             	mov    %rcx,%rax
    e2f4:	e9 00 fd ff ff       	jmp    dff9 <fwp_main_thread+0x3e9>
    e2f9:	e9 17 54 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e2fe:	e9 12 54 ff ff       	jmp    3715 <fwp_main_thread.cold>
    e303:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e30a:	00 00 00 
    e30d:	0f 1f 00             	nopl   (%rax)

000000000000e310 <__divmodti4>:
    e310:	f3 0f 1e fa          	endbr64
    e314:	55                   	push   %rbp
    e315:	49 89 f1             	mov    %rsi,%r9
    e318:	49 89 d2             	mov    %rdx,%r10
    e31b:	48 89 fe             	mov    %rdi,%rsi
    e31e:	49 89 cb             	mov    %rcx,%r11
    e321:	48 89 e5             	mov    %rsp,%rbp
    e324:	41 57                	push   %r15
    e326:	41 56                	push   %r14
    e328:	41 55                	push   %r13
    e32a:	41 54                	push   %r12
    e32c:	53                   	push   %rbx
    e32d:	4c 89 c3             	mov    %r8,%rbx
    e330:	45 31 c0             	xor    %r8d,%r8d
    e333:	4d 85 c9             	test   %r9,%r9
    e336:	79 12                	jns    e34a <__divmodti4+0x3a>
    e338:	31 ff                	xor    %edi,%edi
    e33a:	48 f7 de             	neg    %rsi
    e33d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e344:	4c 19 cf             	sbb    %r9,%rdi
    e347:	49 89 f9             	mov    %rdi,%r9
    e34a:	4c 89 d8             	mov    %r11,%rax
    e34d:	4d 85 db             	test   %r11,%r11
    e350:	0f 88 1a 01 00 00    	js     e470 <__divmodti4+0x160>
    e356:	4c 89 d9             	mov    %r11,%rcx
    e359:	49 89 f3             	mov    %rsi,%r11
    e35c:	75 62                	jne    e3c0 <__divmodti4+0xb0>
    e35e:	4d 89 c4             	mov    %r8,%r12
    e361:	4d 39 d1             	cmp    %r10,%r9
    e364:	0f 83 46 01 00 00    	jae    e4b0 <__divmodti4+0x1a0>
    e36a:	4c 89 d8             	mov    %r11,%rax
    e36d:	4c 89 ca             	mov    %r9,%rdx
    e370:	49 f7 f2             	div    %r10
    e373:	49 89 c3             	mov    %rax,%r11
    e376:	31 c0                	xor    %eax,%eax
    e378:	48 89 d6             	mov    %rdx,%rsi
    e37b:	31 ff                	xor    %edi,%edi
    e37d:	4c 89 d9             	mov    %r11,%rcx
    e380:	48 89 c2             	mov    %rax,%rdx
    e383:	48 89 c8             	mov    %rcx,%rax
    e386:	4d 85 e4             	test   %r12,%r12
    e389:	74 0a                	je     e395 <__divmodti4+0x85>
    e38b:	48 f7 d8             	neg    %rax
    e38e:	48 83 d2 00          	adc    $0x0,%rdx
    e392:	48 f7 da             	neg    %rdx
    e395:	4d 85 c0             	test   %r8,%r8
    e398:	74 0a                	je     e3a4 <__divmodti4+0x94>
    e39a:	48 f7 de             	neg    %rsi
    e39d:	48 83 d7 00          	adc    $0x0,%rdi
    e3a1:	48 f7 df             	neg    %rdi
    e3a4:	48 89 33             	mov    %rsi,(%rbx)
    e3a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e3ab:	5b                   	pop    %rbx
    e3ac:	41 5c                	pop    %r12
    e3ae:	41 5d                	pop    %r13
    e3b0:	41 5e                	pop    %r14
    e3b2:	41 5f                	pop    %r15
    e3b4:	5d                   	pop    %rbp
    e3b5:	c3                   	ret
    e3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e3bd:	00 00 00 
    e3c0:	4d 89 c4             	mov    %r8,%r12
    e3c3:	49 39 c1             	cmp    %rax,%r9
    e3c6:	0f 82 ce 00 00 00    	jb     e49a <__divmodti4+0x18a>
    e3cc:	31 ff                	xor    %edi,%edi
    e3ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e3d3:	48 63 c7             	movslq %edi,%rax
    e3d6:	be 40 00 00 00       	mov    $0x40,%esi
    e3db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e3e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e3e5:	48 29 c6             	sub    %rax,%rsi
    e3e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e3ed:	48 09 c8             	or     %rcx,%rax
    e3f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e3f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e3fa:	49 89 c6             	mov    %rax,%r14
    e3fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e401:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e406:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e40b:	49 09 c1             	or     %rax,%r9
    e40e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e412:	4c 89 c8             	mov    %r9,%rax
    e415:	49 f7 f6             	div    %r14
    e418:	48 89 d1             	mov    %rdx,%rcx
    e41b:	49 89 c3             	mov    %rax,%r11
    e41e:	49 89 c1             	mov    %rax,%r9
    e421:	49 f7 e2             	mul    %r10
    e424:	49 89 c6             	mov    %rax,%r14
    e427:	49 89 d2             	mov    %rdx,%r10
    e42a:	48 39 d1             	cmp    %rdx,%rcx
    e42d:	72 07                	jb     e436 <__divmodti4+0x126>
    e42f:	75 17                	jne    e448 <__divmodti4+0x138>
    e431:	49 39 c7             	cmp    %rax,%r15
    e434:	73 12                	jae    e448 <__divmodti4+0x138>
    e436:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e43a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e43e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e442:	49 89 d2             	mov    %rdx,%r10
    e445:	49 89 c6             	mov    %rax,%r14
    e448:	4c 89 f8             	mov    %r15,%rax
    e44b:	4c 29 f0             	sub    %r14,%rax
    e44e:	4c 19 d1             	sbb    %r10,%rcx
    e451:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e456:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e45b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e460:	48 09 c6             	or     %rax,%rsi
    e463:	48 89 cf             	mov    %rcx,%rdi
    e466:	31 c0                	xor    %eax,%eax
    e468:	4c 89 c9             	mov    %r9,%rcx
    e46b:	e9 10 ff ff ff       	jmp    e380 <__divmodti4+0x70>
    e470:	4c 89 d0             	mov    %r10,%rax
    e473:	4c 89 da             	mov    %r11,%rdx
    e476:	4d 89 c4             	mov    %r8,%r12
    e479:	49 89 f3             	mov    %rsi,%r11
    e47c:	48 f7 d8             	neg    %rax
    e47f:	49 f7 d4             	not    %r12
    e482:	48 83 d2 00          	adc    $0x0,%rdx
    e486:	49 89 c2             	mov    %rax,%r10
    e489:	48 f7 da             	neg    %rdx
    e48c:	48 89 d1             	mov    %rdx,%rcx
    e48f:	0f 84 cc fe ff ff    	je     e361 <__divmodti4+0x51>
    e495:	49 39 d1             	cmp    %rdx,%r9
    e498:	73 46                	jae    e4e0 <__divmodti4+0x1d0>
    e49a:	4c 89 cf             	mov    %r9,%rdi
    e49d:	31 c0                	xor    %eax,%eax
    e49f:	31 c9                	xor    %ecx,%ecx
    e4a1:	e9 da fe ff ff       	jmp    e380 <__divmodti4+0x70>
    e4a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e4ad:	00 00 00 
    e4b0:	4d 85 d2             	test   %r10,%r10
    e4b3:	75 0d                	jne    e4c2 <__divmodti4+0x1b2>
    e4b5:	b8 01 00 00 00       	mov    $0x1,%eax
    e4ba:	31 d2                	xor    %edx,%edx
    e4bc:	49 f7 f2             	div    %r10
    e4bf:	49 89 c2             	mov    %rax,%r10
    e4c2:	4c 89 c8             	mov    %r9,%rax
    e4c5:	31 d2                	xor    %edx,%edx
    e4c7:	49 f7 f2             	div    %r10
    e4ca:	49 89 c1             	mov    %rax,%r9
    e4cd:	4c 89 d8             	mov    %r11,%rax
    e4d0:	49 f7 f2             	div    %r10
    e4d3:	49 89 c3             	mov    %rax,%r11
    e4d6:	4c 89 c8             	mov    %r9,%rax
    e4d9:	e9 9a fe ff ff       	jmp    e378 <__divmodti4+0x68>
    e4de:	66 90                	xchg   %ax,%ax
    e4e0:	45 31 f6             	xor    %r14d,%r14d
    e4e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e4e8:	44 89 f7             	mov    %r14d,%edi
    e4eb:	45 85 f6             	test   %r14d,%r14d
    e4ee:	0f 85 df fe ff ff    	jne    e3d3 <__divmodti4+0xc3>
    e4f4:	4c 39 ca             	cmp    %r9,%rdx
    e4f7:	72 17                	jb     e510 <__divmodti4+0x200>
    e4f9:	31 c9                	xor    %ecx,%ecx
    e4fb:	48 39 c6             	cmp    %rax,%rsi
    e4fe:	73 10                	jae    e510 <__divmodti4+0x200>
    e500:	4c 89 cf             	mov    %r9,%rdi
    e503:	31 c0                	xor    %eax,%eax
    e505:	e9 76 fe ff ff       	jmp    e380 <__divmodti4+0x70>
    e50a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e510:	4c 89 de             	mov    %r11,%rsi
    e513:	b9 01 00 00 00       	mov    $0x1,%ecx
    e518:	48 29 c6             	sub    %rax,%rsi
    e51b:	49 19 d1             	sbb    %rdx,%r9
    e51e:	eb e0                	jmp    e500 <__divmodti4+0x1f0>

000000000000e520 <atexit>:
    e520:	f3 0f 1e fa          	endbr64
    e524:	48 8b 15 dd 4a 00 00 	mov    0x4add(%rip),%rdx        # 13008 <__dso_handle>
    e52b:	31 f6                	xor    %esi,%esi
    e52d:	e9 ee 50 ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e534 <_fini>:
    e534:	f3 0f 1e fa          	endbr64
    e538:	48 83 ec 08          	sub    $0x8,%rsp
    e53c:	48 83 c4 08          	add    $0x8,%rsp
    e540:	c3                   	ret
