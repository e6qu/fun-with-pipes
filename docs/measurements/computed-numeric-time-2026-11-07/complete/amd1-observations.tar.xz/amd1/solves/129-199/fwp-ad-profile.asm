
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003370 <__cxa_finalize@plt>:
    3370:	f3 0f 1e fa          	endbr64
    3374:	ff 25 6e fc 00 00    	jmp    *0xfc6e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    337a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003380 <getenv@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 9e fa 00 00    	jmp    *0xfa9e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003390 <__snprintf_chk@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 96 fa 00 00    	jmp    *0xfa96(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <free@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <abort@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <_exit@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <strcpy@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <sigaction@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strtod@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <clock_gettime@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <write@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e70 <write@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <fclose@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <strlen@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <__stack_chk_fail@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <mmap@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <strchr@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <swapcontext@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <nanosleep@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <strtof@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <memset@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <close@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <fputc@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <pthread_attr_init@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fgets@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <strtoull@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <calloc@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strcmp@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <signal@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strtoll@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <__memcpy_chk@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <sigemptyset@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <strtol@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <memcpy@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <malloc@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <fflush@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <realloc@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <munmap@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <setvbuf@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <pthread_create@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <mprotect@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <fopen@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <sysconf@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <pthread_attr_destroy@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <__cxa_atexit@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <exit@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <fwrite@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <__fprintf_chk@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <_Exit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <pthread_join@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <sigaltstack@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <strstr@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <__sprintf_chk@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_attr_setstacksize@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036c0 <fwp_trap_overflow.constprop.0>:
    36c0:	53                   	push   %rbx
    36c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36c6:	ba 02 00 00 00       	mov    $0x2,%edx
    36cb:	be 60 00 00 00       	mov    $0x60,%esi
    36d0:	4c 8d 0d fa b9 00 00 	lea    0xb9fa(%rip),%r9        # f0d1 <_IO_stdin_used+0xd1>
    36d7:	4c 8d 05 f7 b9 00 00 	lea    0xb9f7(%rip),%r8        # f0d5 <_IO_stdin_used+0xd5>
    36de:	48 83 ec 70          	sub    $0x70,%rsp
    36e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    36e9:	00 00 
    36eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    36f0:	31 c0                	xor    %eax,%eax
    36f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    36f7:	e8 94 fc ff ff       	call   3390 <__snprintf_chk@plt>
    36fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3701:	e8 0a 0d 00 00       	call   4410 <fwp_trap>

0000000000003706 <fwp_task_dispose.cold>:
    3706:	e8 a5 fc ff ff       	call   33b0 <abort@plt>

000000000000370b <fwp_hof0.constprop.0.cold>:
    370b:	e8 a0 fc ff ff       	call   33b0 <abort@plt>
    3710:	e8 ab ff ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>

0000000000003715 <fwp_main_thread.cold>:
    3715:	e8 96 fc ff ff       	call   33b0 <abort@plt>

000000000000371a <main.cold>:
    371a:	e8 91 fc ff ff       	call   33b0 <abort@plt>
    371f:	90                   	nop

0000000000003720 <main>:
    3720:	f3 0f 1e fa          	endbr64
    3724:	55                   	push   %rbp
    3725:	53                   	push   %rbx
    3726:	48 83 ec 68          	sub    $0x68,%rsp
    372a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3731:	00 00 
    3733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3738:	48 8d 05 e1 db 00 00 	lea    0xdbe1(%rip),%rax        # 11320 <fwp_fn_table>
    373f:	48 89 05 12 9d 06 00 	mov    %rax,0x69d12(%rip)        # 6d458 <fwp_fns>
    3746:	48 8b 05 d3 f8 00 00 	mov    0xf8d3(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    374d:	48 89 05 0c 9d 06 00 	mov    %rax,0x69d0c(%rip)        # 6d460 <fwp_prog_out>
    3754:	e8 27 0e 00 00       	call   4580 <fwp_now_ns>
    3759:	48 8d 3d 90 bb 00 00 	lea    0xbb90(%rip),%rdi        # f2f0 <_IO_stdin_used+0x2f0>
    3760:	e8 1b fc ff ff       	call   3380 <getenv@plt>
    3765:	48 85 c0             	test   %rax,%rax
    3768:	74 0c                	je     3776 <main+0x56>
    376a:	48 89 c3             	mov    %rax,%rbx
    376d:	80 38 00             	cmpb   $0x0,(%rax)
    3770:	0f 85 09 01 00 00    	jne    387f <main+0x15f>
    3776:	31 ff                	xor    %edi,%edi
    3778:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    377d:	e8 7e fc ff ff       	call   3400 <clock_gettime@plt>
    3782:	85 c0                	test   %eax,%eax
    3784:	0f 85 28 01 00 00    	jne    38b2 <main+0x192>
    378a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    378f:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    3794:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    3799:	48 89 cb             	mov    %rcx,%rbx
    379c:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37a0:	48 01 c8             	add    %rcx,%rax
    37a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37aa:	00 00 80 
    37ad:	48 11 da             	adc    %rbx,%rdx
    37b0:	31 db                	xor    %ebx,%ebx
    37b2:	48 01 c8             	add    %rcx,%rax
    37b5:	48 11 da             	adc    %rbx,%rdx
    37b8:	48 85 d2             	test   %rdx,%rdx
    37bb:	0f 85 38 01 00 00    	jne    38f9 <main+0x1d9>
    37c1:	48 8b 3d 58 f8 00 00 	mov    0xf858(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    37c8:	31 d2                	xor    %edx,%edx
    37ca:	31 f6                	xor    %esi,%esi
    37cc:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37d1:	e8 ea fd ff ff       	call   35c0 <setvbuf@plt>
    37d6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37db:	be 01 00 00 00       	mov    $0x1,%esi
    37e0:	e8 3b fd ff ff       	call   3520 <signal@plt>
    37e5:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    37ea:	e8 e1 fc ff ff       	call   34d0 <pthread_attr_init@plt>
    37ef:	85 c0                	test   %eax,%eax
    37f1:	0f 85 f6 00 00 00    	jne    38ed <main+0x1cd>
    37f7:	be 00 00 00 40       	mov    $0x40000000,%esi
    37fc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3801:	e8 aa fe ff ff       	call   36b0 <pthread_attr_setstacksize@plt>
    3806:	85 c0                	test   %eax,%eax
    3808:	0f 85 c1 00 00 00    	jne    38cf <main+0x1af>
    380e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3813:	31 c9                	xor    %ecx,%ecx
    3815:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    381a:	48 8d 15 bf ab 00 00 	lea    0xabbf(%rip),%rdx        # e3e0 <fwp_main_thread>
    3821:	e8 aa fd ff ff       	call   35d0 <pthread_create@plt>
    3826:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382b:	89 c5                	mov    %eax,%ebp
    382d:	e8 de fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    3832:	85 c0                	test   %eax,%eax
    3834:	0f 85 e0 fe ff ff    	jne    371a <main.cold>
    383a:	85 ed                	test   %ebp,%ebp
    383c:	0f 85 81 00 00 00    	jne    38c3 <main+0x1a3>
    3842:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3847:	31 f6                	xor    %esi,%esi
    3849:	e8 22 fe ff ff       	call   3670 <pthread_join@plt>
    384e:	85 c0                	test   %eax,%eax
    3850:	0f 85 c4 fe ff ff    	jne    371a <main.cold>
    3856:	48 8b 3d c3 f7 00 00 	mov    0xf7c3(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    385d:	e8 2e fd ff ff       	call   3590 <fflush@plt>
    3862:	8b 05 18 f8 01 00    	mov    0x1f818(%rip),%eax        # 23080 <fwp_exit_code>
    3868:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    386d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3874:	00 00 
    3876:	75 46                	jne    38be <main+0x19e>
    3878:	48 83 c4 68          	add    $0x68,%rsp
    387c:	5b                   	pop    %rbx
    387d:	5d                   	pop    %rbp
    387e:	c3                   	ret
    387f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    3884:	ba 0a 00 00 00       	mov    $0xa,%edx
    3889:	48 89 c7             	mov    %rax,%rdi
    388c:	e8 5f fc ff ff       	call   34f0 <strtoull@plt>
    3891:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3896:	80 38 00             	cmpb   $0x0,(%rax)
    3899:	0f 85 d7 fe ff ff    	jne    3776 <main+0x56>
    389f:	0f b6 03             	movzbl (%rbx),%eax
    38a2:	83 e8 2b             	sub    $0x2b,%eax
    38a5:	a8 fd                	test   $0xfd,%al
    38a7:	0f 84 c9 fe ff ff    	je     3776 <main+0x56>
    38ad:	e9 0f ff ff ff       	jmp    37c1 <main+0xa1>
    38b2:	48 8d 3d 40 ba 00 00 	lea    0xba40(%rip),%rdi        # f2f9 <_IO_stdin_used+0x2f9>
    38b9:	e8 52 0b 00 00       	call   4410 <fwp_trap>
    38be:	e8 7d fb ff ff       	call   3440 <__stack_chk_fail@plt>
    38c3:	48 8d 3d 96 c3 00 00 	lea    0xc396(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    38ca:	e8 41 0b 00 00       	call   4410 <fwp_trap>
    38cf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38d4:	e8 37 fd ff ff       	call   3610 <pthread_attr_destroy@plt>
    38d9:	85 c0                	test   %eax,%eax
    38db:	0f 85 39 fe ff ff    	jne    371a <main.cold>
    38e1:	48 8d 3d 50 c3 00 00 	lea    0xc350(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    38e8:	e8 23 0b 00 00       	call   4410 <fwp_trap>
    38ed:	48 8d 3d 14 c3 00 00 	lea    0xc314(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    38f4:	e8 17 0b 00 00       	call   4410 <fwp_trap>
    38f9:	48 8d 3d e0 c2 00 00 	lea    0xc2e0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3900:	e8 0b 0b 00 00       	call   4410 <fwp_trap>
    3905:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    390c:	00 00 00 
    390f:	90                   	nop

0000000000003910 <_start>:
    3910:	f3 0f 1e fa          	endbr64
    3914:	31 ed                	xor    %ebp,%ebp
    3916:	49 89 d1             	mov    %rdx,%r9
    3919:	5e                   	pop    %rsi
    391a:	48 89 e2             	mov    %rsp,%rdx
    391d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3921:	50                   	push   %rax
    3922:	54                   	push   %rsp
    3923:	45 31 c0             	xor    %r8d,%r8d
    3926:	31 c9                	xor    %ecx,%ecx
    3928:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3720 <main>
    392f:	ff 15 93 f6 00 00    	call   *0xf693(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3935:	f4                   	hlt
    3936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    393d:	00 00 00 

0000000000003940 <deregister_tm_clones>:
    3940:	48 8d 3d d9 f6 00 00 	lea    0xf6d9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3947:	48 8d 05 d2 f6 00 00 	lea    0xf6d2(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    394e:	48 39 f8             	cmp    %rdi,%rax
    3951:	74 15                	je     3968 <deregister_tm_clones+0x28>
    3953:	48 8b 05 76 f6 00 00 	mov    0xf676(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    395a:	48 85 c0             	test   %rax,%rax
    395d:	74 09                	je     3968 <deregister_tm_clones+0x28>
    395f:	ff e0                	jmp    *%rax
    3961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3968:	c3                   	ret
    3969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003970 <register_tm_clones>:
    3970:	48 8d 3d a9 f6 00 00 	lea    0xf6a9(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3977:	48 8d 35 a2 f6 00 00 	lea    0xf6a2(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    397e:	48 29 fe             	sub    %rdi,%rsi
    3981:	48 89 f0             	mov    %rsi,%rax
    3984:	48 c1 ee 3f          	shr    $0x3f,%rsi
    3988:	48 c1 f8 03          	sar    $0x3,%rax
    398c:	48 01 c6             	add    %rax,%rsi
    398f:	48 d1 fe             	sar    $1,%rsi
    3992:	74 14                	je     39a8 <register_tm_clones+0x38>
    3994:	48 8b 05 45 f6 00 00 	mov    0xf645(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    399b:	48 85 c0             	test   %rax,%rax
    399e:	74 08                	je     39a8 <register_tm_clones+0x38>
    39a0:	ff e0                	jmp    *%rax
    39a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <__do_global_dtors_aux>:
    39b0:	f3 0f 1e fa          	endbr64
    39b4:	80 3d 8d f6 00 00 00 	cmpb   $0x0,0xf68d(%rip)        # 13048 <completed.0>
    39bb:	75 2b                	jne    39e8 <__do_global_dtors_aux+0x38>
    39bd:	55                   	push   %rbp
    39be:	48 83 3d 22 f6 00 00 	cmpq   $0x0,0xf622(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    39c5:	00 
    39c6:	48 89 e5             	mov    %rsp,%rbp
    39c9:	74 0c                	je     39d7 <__do_global_dtors_aux+0x27>
    39cb:	48 8b 3d 36 f6 00 00 	mov    0xf636(%rip),%rdi        # 13008 <__dso_handle>
    39d2:	e8 99 f9 ff ff       	call   3370 <__cxa_finalize@plt>
    39d7:	e8 64 ff ff ff       	call   3940 <deregister_tm_clones>
    39dc:	c6 05 65 f6 00 00 01 	movb   $0x1,0xf665(%rip)        # 13048 <completed.0>
    39e3:	5d                   	pop    %rbp
    39e4:	c3                   	ret
    39e5:	0f 1f 00             	nopl   (%rax)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <frame_dummy>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	e9 77 ff ff ff       	jmp    3970 <register_tm_clones>
    39f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a00 <fwp_fmt_u128>:
    3a00:	41 57                	push   %r15
    3a02:	41 56                	push   %r14
    3a04:	41 55                	push   %r13
    3a06:	41 54                	push   %r12
    3a08:	55                   	push   %rbp
    3a09:	53                   	push   %rbx
    3a0a:	48 83 ec 68          	sub    $0x68,%rsp
    3a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a15:	00 00 
    3a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a1c:	48 89 f0             	mov    %rsi,%rax
    3a1f:	48 09 d0             	or     %rdx,%rax
    3a22:	75 7c                	jne    3aa0 <fwp_fmt_u128+0xa0>
    3a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a36:	48 89 f8             	mov    %rdi,%rax
    3a39:	49 01 d4             	add    %rdx,%r12
    3a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a48:	00 00 
    3a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a51:	00 00 00 00 
    3a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a5c:	00 00 00 00 
    3a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a65:	48 83 c0 01          	add    $0x1,%rax
    3a69:	49 83 ec 01          	sub    $0x1,%r12
    3a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a70:	48 39 c8             	cmp    %rcx,%rax
    3a73:	75 eb                	jne    3a60 <fwp_fmt_u128+0x60>
    3a75:	48 63 ed             	movslq %ebp,%rbp
    3a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3a88:	00 00 
    3a8a:	0f 85 ef 00 00 00    	jne    3b7f <fwp_fmt_u128+0x17f>
    3a90:	48 83 c4 68          	add    $0x68,%rsp
    3a94:	5b                   	pop    %rbx
    3a95:	5d                   	pop    %rbp
    3a96:	41 5c                	pop    %r12
    3a98:	41 5d                	pop    %r13
    3a9a:	41 5e                	pop    %r14
    3a9c:	41 5f                	pop    %r15
    3a9e:	c3                   	ret
    3a9f:	90                   	nop
    3aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3aa5:	49 89 f2             	mov    %rsi,%r10
    3aa8:	49 89 d3             	mov    %rdx,%r11
    3aab:	31 ed                	xor    %ebp,%ebp
    3aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ab2:	4c 89 e3             	mov    %r12,%rbx
    3ab5:	45 31 f6             	xor    %r14d,%r14d
    3ab8:	49 89 f9             	mov    %rdi,%r9
    3abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ac2:	cc cc cc 
    3ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3ad2:	cc cc cc 
    3ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ae0:	4c 89 d6             	mov    %r10,%rsi
    3ae3:	4c 89 df             	mov    %r11,%rdi
    3ae6:	4c 01 de             	add    %r11,%rsi
    3ae9:	48 83 d6 00          	adc    $0x0,%rsi
    3aed:	45 31 ed             	xor    %r13d,%r13d
    3af0:	48 89 f0             	mov    %rsi,%rax
    3af3:	48 f7 e1             	mul    %rcx
    3af6:	48 89 d0             	mov    %rdx,%rax
    3af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3afd:	48 c1 e8 02          	shr    $0x2,%rax
    3b01:	48 01 c2             	add    %rax,%rdx
    3b04:	48 8b 04 24          	mov    (%rsp),%rax
    3b08:	48 29 d6             	sub    %rdx,%rsi
    3b0b:	49 89 f4             	mov    %rsi,%r12
    3b0e:	4c 89 d6             	mov    %r10,%rsi
    3b11:	4c 29 e6             	sub    %r12,%rsi
    3b14:	4c 19 ef             	sbb    %r13,%rdi
    3b17:	48 0f af c6          	imul   %rsi,%rax
    3b1b:	49 89 f8             	mov    %rdi,%r8
    3b1e:	4c 0f af c1          	imul   %rcx,%r8
    3b22:	49 01 c0             	add    %rax,%r8
    3b25:	48 89 f0             	mov    %rsi,%rax
    3b28:	48 f7 e1             	mul    %rcx
    3b2b:	48 89 c6             	mov    %rax,%rsi
    3b2e:	83 e0 01             	and    $0x1,%eax
    3b31:	49 01 d0             	add    %rdx,%r8
    3b34:	49 f7 e7             	mul    %r15
    3b37:	4c 89 c7             	mov    %r8,%rdi
    3b3a:	4c 89 d2             	mov    %r10,%rdx
    3b3d:	4c 01 e0             	add    %r12,%rax
    3b40:	48 d1 ef             	shr    $1,%rdi
    3b43:	83 c5 01             	add    $0x1,%ebp
    3b46:	48 83 c3 01          	add    $0x1,%rbx
    3b4a:	83 c0 30             	add    $0x30,%eax
    3b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b55:	4c 89 d8             	mov    %r11,%rax
    3b58:	49 89 fb             	mov    %rdi,%r11
    3b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b60:	48 39 d7             	cmp    %rdx,%rdi
    3b63:	4c 89 f7             	mov    %r14,%rdi
    3b66:	49 89 f2             	mov    %rsi,%r10
    3b69:	48 19 c7             	sbb    %rax,%rdi
    3b6c:	0f 82 6e ff ff ff    	jb     3ae0 <fwp_fmt_u128+0xe0>
    3b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b77:	4c 89 cf             	mov    %r9,%rdi
    3b7a:	e9 b4 fe ff ff       	jmp    3a33 <fwp_fmt_u128+0x33>
    3b7f:	e8 bc f8 ff ff       	call   3440 <__stack_chk_fail@plt>
    3b84:	90                   	nop
    3b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b8c:	00 00 00 00 

0000000000003b90 <fwp_range_release>:
    3b90:	f3 0f 1e fa          	endbr64
    3b94:	53                   	push   %rbx
    3b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3b99:	48 89 fb             	mov    %rdi,%rbx
    3b9c:	48 85 c0             	test   %rax,%rax
    3b9f:	74 06                	je     3ba7 <fwp_range_release+0x17>
    3ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3ba5:	ff d0                	call   *%rax
    3ba7:	48 8b 3b             	mov    (%rbx),%rdi
    3baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bae:	5b                   	pop    %rbx
    3baf:	ff e0                	jmp    *%rax
    3bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <ad_raw_record>:
    3bc0:	89 c8                	mov    %ecx,%eax
    3bc2:	4c 8d 05 b7 f5 04 00 	lea    0x4f5b7(%rip),%r8        # 53180 <ad_raw_live>
    3bc9:	49 89 f1             	mov    %rsi,%r9
    3bcc:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bd3:	00 
    3bd4:	48 89 d6             	mov    %rdx,%rsi
    3bd7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bda:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bde:	48 8d 0d 5b f5 04 00 	lea    0x4f55b(%rip),%rcx        # 53140 <ad_raw_requests>
    3be5:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3bea:	48 8d 0d 2f f5 04 00 	lea    0x4f52f(%rip),%rcx        # 53120 <ad_raw_bytes>
    3bf1:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3bf5:	48 01 f2             	add    %rsi,%rdx
    3bf8:	48 8d 0d 61 f5 04 00 	lea    0x4f561(%rip),%rcx        # 53160 <ad_raw_peak>
    3bff:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c03:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c07:	4c 89 0f             	mov    %r9,(%rdi)
    3c0a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c0e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c12:	73 04                	jae    3c18 <ad_raw_record+0x58>
    3c14:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c18:	66 0f 6f 05 70 f5 04 	movdqa 0x4f570(%rip),%xmm0        # 53190 <ad_raw_live+0x10>
    3c1f:	00 
    3c20:	66 0f d4 05 58 f5 04 	paddq  0x4f558(%rip),%xmm0        # 53180 <ad_raw_live>
    3c27:	00 
    3c28:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c2c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c31:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c35:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c3a:	48 39 05 bf f4 04 00 	cmp    %rax,0x4f4bf(%rip)        # 53100 <ad_raw_total_peak>
    3c41:	73 08                	jae    3c4b <ad_raw_record+0x8b>
    3c43:	66 0f d6 05 b5 f4 04 	movq   %xmm0,0x4f4b5(%rip)        # 53100 <ad_raw_total_peak>
    3c4a:	00 
    3c4b:	c3                   	ret
    3c4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c50 <fwp_tape_unlink_scope>:
    3c50:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    3c54:	48 85 d2             	test   %rdx,%rdx
    3c57:	74 3e                	je     3c97 <fwp_tape_unlink_scope+0x47>
    3c59:	8b 4f 48             	mov    0x48(%rdi),%ecx
    3c5c:	48 63 47 4c          	movslq 0x4c(%rdi),%rax
    3c60:	85 c9                	test   %ecx,%ecx
    3c62:	78 3c                	js     3ca0 <fwp_tape_unlink_scope+0x50>
    3c64:	48 63 d1             	movslq %ecx,%rdx
    3c67:	48 6b d2 58          	imul   $0x58,%rdx,%rdx
    3c6b:	48 03 15 6e f4 01 00 	add    0x1f46e(%rip),%rdx        # 230e0 <fwp_tapes>
    3c72:	89 42 4c             	mov    %eax,0x4c(%rdx)
    3c75:	85 c0                	test   %eax,%eax
    3c77:	78 0e                	js     3c87 <fwp_tape_unlink_scope+0x37>
    3c79:	48 6b c0 58          	imul   $0x58,%rax,%rax
    3c7d:	48 03 05 5c f4 01 00 	add    0x1f45c(%rip),%rax        # 230e0 <fwp_tapes>
    3c84:	89 48 48             	mov    %ecx,0x48(%rax)
    3c87:	48 c7 47 40 00 00 00 	movq   $0x0,0x40(%rdi)
    3c8e:	00 
    3c8f:	48 c7 47 48 ff ff ff 	movq   $0xffffffffffffffff,0x48(%rdi)
    3c96:	ff 
    3c97:	c3                   	ret
    3c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c9f:	00 
    3ca0:	89 02                	mov    %eax,(%rdx)
    3ca2:	eb d1                	jmp    3c75 <fwp_tape_unlink_scope+0x25>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_args173>:
    3cb0:	f3 0f 1e fa          	endbr64
    3cb4:	c3                   	ret
    3cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cbc:	00 00 00 00 

0000000000003cc0 <fwp_flush>:
    3cc0:	48 8b 3d 99 97 06 00 	mov    0x69799(%rip),%rdi        # 6d460 <fwp_prog_out>
    3cc7:	48 85 ff             	test   %rdi,%rdi
    3cca:	74 1c                	je     3ce8 <fwp_flush+0x28>
    3ccc:	48 83 ec 08          	sub    $0x8,%rsp
    3cd0:	e8 bb f8 ff ff       	call   3590 <fflush@plt>
    3cd5:	48 8b 3d 44 f3 00 00 	mov    0xf344(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3cdc:	48 83 c4 08          	add    $0x8,%rsp
    3ce0:	e9 ab f8 ff ff       	jmp    3590 <fflush@plt>
    3ce5:	0f 1f 00             	nopl   (%rax)
    3ce8:	48 8b 3d 31 f3 00 00 	mov    0xf331(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3cef:	e9 9c f8 ff ff       	jmp    3590 <fflush@plt>
    3cf4:	90                   	nop
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_segv>:
    3d00:	f3 0f 1e fa          	endbr64
    3d04:	48 83 ec 28          	sub    $0x28,%rsp
    3d08:	48 8b 05 d1 7a 06 00 	mov    0x67ad1(%rip),%rax        # 6b7e0 <fwp_cur>
    3d0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d13:	41 89 f8             	mov    %edi,%r8d
    3d16:	48 85 c0             	test   %rax,%rax
    3d19:	74 6d                	je     3d88 <fwp_segv+0x88>
    3d1b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d1f:	48 85 d2             	test   %rdx,%rdx
    3d22:	74 64                	je     3d88 <fwp_segv+0x88>
    3d24:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d28:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d32:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d37:	e8 c4 f8 ff ff       	call   3600 <sysconf@plt>
    3d3c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d41:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d46:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d4b:	48 01 d0             	add    %rdx,%rax
    3d4e:	48 39 c1             	cmp    %rax,%rcx
    3d51:	b8 00 00 00 00       	mov    $0x0,%eax
    3d56:	40 0f 92 c6          	setb   %sil
    3d5a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d61:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d65:	31 c0                	xor    %eax,%eax
    3d67:	48 39 d1             	cmp    %rdx,%rcx
    3d6a:	0f 93 c0             	setae  %al
    3d6d:	21 f0                	and    %esi,%eax
    3d6f:	85 c0                	test   %eax,%eax
    3d71:	75 4a                	jne    3dbd <fwp_segv+0xbd>
    3d73:	31 f6                	xor    %esi,%esi
    3d75:	44 89 c7             	mov    %r8d,%edi
    3d78:	48 83 c4 28          	add    $0x28,%rsp
    3d7c:	e9 9f f7 ff ff       	jmp    3520 <signal@plt>
    3d81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d88:	48 8b 05 19 74 06 00 	mov    0x67419(%rip),%rax        # 6b1a8 <fwp_main_stack_top>
    3d8f:	48 85 c0             	test   %rax,%rax
    3d92:	74 df                	je     3d73 <fwp_segv+0x73>
    3d94:	48 2b 05 05 74 06 00 	sub    0x67405(%rip),%rax        # 6b1a0 <fwp_main_stack_size>
    3d9b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3da2:	48 39 d1             	cmp    %rdx,%rcx
    3da5:	0f 93 c2             	setae  %dl
    3da8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dae:	48 39 c1             	cmp    %rax,%rcx
    3db1:	0f 92 c0             	setb   %al
    3db4:	0f b6 c0             	movzbl %al,%eax
    3db7:	21 d0                	and    %edx,%eax
    3db9:	85 c0                	test   %eax,%eax
    3dbb:	74 b6                	je     3d73 <fwp_segv+0x73>
    3dbd:	e8 fe fe ff ff       	call   3cc0 <fwp_flush>
    3dc2:	bf 02 00 00 00       	mov    $0x2,%edi
    3dc7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dcc:	48 8d 35 6d bf 00 00 	lea    0xbf6d(%rip),%rsi        # fd40 <msg.4>
    3dd3:	e8 38 f6 ff ff       	call   3410 <write@plt>
    3dd8:	bf 65 00 00 00       	mov    $0x65,%edi
    3ddd:	e8 de f5 ff ff       	call   33c0 <_exit@plt>
    3de2:	0f 1f 00             	nopl   (%rax)
    3de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3dec:	00 00 00 00 

0000000000003df0 <fwp_heap_oom>:
    3df0:	50                   	push   %rax
    3df1:	58                   	pop    %rax
    3df2:	ba 13 00 00 00       	mov    $0x13,%edx
    3df7:	be 01 00 00 00       	mov    $0x1,%esi
    3dfc:	48 8d 3d 05 b2 00 00 	lea    0xb205(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e03:	48 83 ec 08          	sub    $0x8,%rsp
    3e07:	48 8b 0d 32 f2 00 00 	mov    0xf232(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e0e:	e8 2d f8 ff ff       	call   3640 <fwrite@plt>
    3e13:	31 ff                	xor    %edi,%edi
    3e15:	e8 76 f7 ff ff       	call   3590 <fflush@plt>
    3e1a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e1f:	e8 3c f8 ff ff       	call   3660 <_Exit@plt>
    3e24:	90                   	nop
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_chunks>:
    3e30:	41 54                	push   %r12
    3e32:	55                   	push   %rbp
    3e33:	53                   	push   %rbx
    3e34:	48 83 ff 01          	cmp    $0x1,%rdi
    3e38:	0f 84 62 01 00 00    	je     3fa0 <fwp_heap_chunks+0x170>
    3e3e:	48 8b 05 ab 8d 06 00 	mov    0x68dab(%rip),%rax        # 6cbf0 <fwp_heap+0x13f0>
    3e45:	4c 8d 05 a4 8d 06 00 	lea    0x68da4(%rip),%r8        # 6cbf0 <fwp_heap+0x13f0>
    3e4c:	48 8b 1d 85 8d 06 00 	mov    0x68d85(%rip),%rbx        # 6cbd8 <fwp_heap+0x13d8>
    3e53:	48 39 d8             	cmp    %rbx,%rax
    3e56:	0f 83 57 01 00 00    	jae    3fb3 <fwp_heap_chunks+0x183>
    3e5c:	48 8b 0d 95 8d 06 00 	mov    0x68d95(%rip),%rcx        # 6cbf8 <fwp_heap+0x13f8>
    3e63:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e67:	31 f6                	xor    %esi,%esi
    3e69:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e6d:	eb 1e                	jmp    3e8d <fwp_heap_chunks+0x5d>
    3e6f:	90                   	nop
    3e70:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e74:	48 39 cf             	cmp    %rcx,%rdi
    3e77:	0f 84 03 01 00 00    	je     3f80 <fwp_heap_chunks+0x150>
    3e7d:	48 83 c0 01          	add    $0x1,%rax
    3e81:	48 89 ce             	mov    %rcx,%rsi
    3e84:	48 83 c2 28          	add    $0x28,%rdx
    3e88:	48 39 c3             	cmp    %rax,%rbx
    3e8b:	74 14                	je     3ea1 <fwp_heap_chunks+0x71>
    3e8d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e90:	74 de                	je     3e70 <fwp_heap_chunks+0x40>
    3e92:	48 83 c0 01          	add    $0x1,%rax
    3e96:	31 f6                	xor    %esi,%esi
    3e98:	48 83 c2 28          	add    $0x28,%rdx
    3e9c:	48 39 c3             	cmp    %rax,%rbx
    3e9f:	75 ec                	jne    3e8d <fwp_heap_chunks+0x5d>
    3ea1:	48 29 f3             	sub    %rsi,%rbx
    3ea4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ea8:	48 8b 3d 31 8d 06 00 	mov    0x68d31(%rip),%rdi        # 6cbe0 <fwp_heap+0x13e0>
    3eaf:	48 29 35 7a 8d 06 00 	sub    %rsi,0x68d7a(%rip)        # 6cc30 <fwp_heap+0x1430>
    3eb6:	48 39 ef             	cmp    %rbp,%rdi
    3eb9:	0f 83 96 00 00 00    	jae    3f55 <fwp_heap_chunks+0x125>
    3ebf:	48 8b 05 0a 8d 06 00 	mov    0x68d0a(%rip),%rax        # 6cbd0 <fwp_heap+0x13d0>
    3ec6:	48 39 e8             	cmp    %rbp,%rax
    3ec9:	0f 82 eb 00 00 00    	jb     3fba <fwp_heap_chunks+0x18a>
    3ecf:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ed3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ed8:	49 39 c4             	cmp    %rax,%r12
    3edb:	4c 0f 47 e0          	cmova  %rax,%r12
    3edf:	4c 89 e6             	mov    %r12,%rsi
    3ee2:	48 29 fe             	sub    %rdi,%rsi
    3ee5:	48 c1 e7 10          	shl    $0x10,%rdi
    3ee9:	48 03 3d c0 8c 06 00 	add    0x68cc0(%rip),%rdi        # 6cbb0 <fwp_heap+0x13b0>
    3ef0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ef4:	e8 e7 f6 ff ff       	call   35e0 <mprotect@plt>
    3ef9:	85 c0                	test   %eax,%eax
    3efb:	0f 85 b9 00 00 00    	jne    3fba <fwp_heap_chunks+0x18a>
    3f01:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f06:	e8 f5 f6 ff ff       	call   3600 <sysconf@plt>
    3f0b:	48 8b 35 ce 8c 06 00 	mov    0x68cce(%rip),%rsi        # 6cbe0 <fwp_heap+0x13e0>
    3f12:	48 89 c1             	mov    %rax,%rcx
    3f15:	48 8b 05 dc 8c 06 00 	mov    0x68cdc(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    3f1c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f20:	48 89 ca             	mov    %rcx,%rdx
    3f23:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f27:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f2b:	48 f7 da             	neg    %rdx
    3f2e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f33:	48 21 d7             	and    %rdx,%rdi
    3f36:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f3a:	48 21 d6             	and    %rdx,%rsi
    3f3d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f42:	48 29 fe             	sub    %rdi,%rsi
    3f45:	e8 96 f6 ff ff       	call   35e0 <mprotect@plt>
    3f4a:	85 c0                	test   %eax,%eax
    3f4c:	75 6c                	jne    3fba <fwp_heap_chunks+0x18a>
    3f4e:	4c 89 25 8b 8c 06 00 	mov    %r12,0x68c8b(%rip)        # 6cbe0 <fwp_heap+0x13e0>
    3f55:	48 89 ef             	mov    %rbp,%rdi
    3f58:	48 89 2d 79 8c 06 00 	mov    %rbp,0x68c79(%rip)        # 6cbd8 <fwp_heap+0x13d8>
    3f5f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f63:	48 39 3d 5e 8c 06 00 	cmp    %rdi,0x68c5e(%rip)        # 6cbc8 <fwp_heap+0x13c8>
    3f6a:	73 07                	jae    3f73 <fwp_heap_chunks+0x143>
    3f6c:	48 89 3d 55 8c 06 00 	mov    %rdi,0x68c55(%rip)        # 6cbc8 <fwp_heap+0x13c8>
    3f73:	48 89 d8             	mov    %rbx,%rax
    3f76:	5b                   	pop    %rbx
    3f77:	5d                   	pop    %rbp
    3f78:	41 5c                	pop    %r12
    3f7a:	c3                   	ret
    3f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f80:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f84:	48 29 f0             	sub    %rsi,%rax
    3f87:	48 89 c3             	mov    %rax,%rbx
    3f8a:	49 89 10             	mov    %rdx,(%r8)
    3f8d:	48 89 d8             	mov    %rbx,%rax
    3f90:	48 29 3d 99 8c 06 00 	sub    %rdi,0x68c99(%rip)        # 6cc30 <fwp_heap+0x1430>
    3f97:	5b                   	pop    %rbx
    3f98:	5d                   	pop    %rbp
    3f99:	41 5c                	pop    %r12
    3f9b:	c3                   	ret
    3f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    3fa0:	48 8b 05 41 8c 06 00 	mov    0x68c41(%rip),%rax        # 6cbe8 <fwp_heap+0x13e8>
    3fa7:	4c 8d 05 3a 8c 06 00 	lea    0x68c3a(%rip),%r8        # 6cbe8 <fwp_heap+0x13e8>
    3fae:	e9 99 fe ff ff       	jmp    3e4c <fwp_heap_chunks+0x1c>
    3fb3:	31 f6                	xor    %esi,%esi
    3fb5:	e9 ea fe ff ff       	jmp    3ea4 <fwp_heap_chunks+0x74>
    3fba:	e8 31 fe ff ff       	call   3df0 <fwp_heap_oom>
    3fbf:	90                   	nop

0000000000003fc0 <ad_raw_fail>:
    3fc0:	50                   	push   %rax
    3fc1:	58                   	pop    %rax
    3fc2:	48 8d 15 3f b7 00 00 	lea    0xb73f(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    3fc9:	be 02 00 00 00       	mov    $0x2,%esi
    3fce:	31 c0                	xor    %eax,%eax
    3fd0:	48 83 ec 08          	sub    $0x8,%rsp
    3fd4:	48 89 f9             	mov    %rdi,%rcx
    3fd7:	48 8b 3d 62 f0 00 00 	mov    0xf062(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3fde:	e8 6d f6 ff ff       	call   3650 <__fprintf_chk@plt>
    3fe3:	bf e8 00 00 00       	mov    $0xe8,%edi
    3fe8:	e8 43 f6 ff ff       	call   3630 <exit@plt>
    3fed:	0f 1f 00             	nopl   (%rax)

0000000000003ff0 <buf_grow>:
    3ff0:	48 83 ec 18          	sub    $0x18,%rsp
    3ff4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3ff8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ffc:	74 7e                	je     407c <buf_grow+0x8c>
    3ffe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4005:	48 29 c2             	sub    %rax,%rdx
    4008:	48 39 f2             	cmp    %rsi,%rdx
    400b:	72 6f                	jb     407c <buf_grow+0x8c>
    400d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4012:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4016:	48 89 f9             	mov    %rdi,%rcx
    4019:	48 39 d0             	cmp    %rdx,%rax
    401c:	73 48                	jae    4066 <buf_grow+0x76>
    401e:	48 85 c0             	test   %rax,%rax
    4021:	75 15                	jne    4038 <buf_grow+0x48>
    4023:	48 83 fa 40          	cmp    $0x40,%rdx
    4027:	76 4c                	jbe    4075 <buf_grow+0x85>
    4029:	b8 40 00 00 00       	mov    $0x40,%eax
    402e:	eb 08                	jmp    4038 <buf_grow+0x48>
    4030:	48 01 c0             	add    %rax,%rax
    4033:	48 39 d0             	cmp    %rdx,%rax
    4036:	73 38                	jae    4070 <buf_grow+0x80>
    4038:	48 85 c0             	test   %rax,%rax
    403b:	79 f3                	jns    4030 <buf_grow+0x40>
    403d:	48 8b 39             	mov    (%rcx),%rdi
    4040:	48 89 d6             	mov    %rdx,%rsi
    4043:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4048:	48 89 14 24          	mov    %rdx,(%rsp)
    404c:	e8 4f f5 ff ff       	call   35a0 <realloc@plt>
    4051:	48 8b 14 24          	mov    (%rsp),%rdx
    4055:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    405a:	48 85 c0             	test   %rax,%rax
    405d:	74 1d                	je     407c <buf_grow+0x8c>
    405f:	48 89 01             	mov    %rax,(%rcx)
    4062:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4066:	48 83 c4 18          	add    $0x18,%rsp
    406a:	c3                   	ret
    406b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4070:	48 89 c2             	mov    %rax,%rdx
    4073:	eb c8                	jmp    403d <buf_grow+0x4d>
    4075:	ba 40 00 00 00       	mov    $0x40,%edx
    407a:	eb c1                	jmp    403d <buf_grow+0x4d>
    407c:	48 8b 0d bd ef 00 00 	mov    0xefbd(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    4083:	ba 13 00 00 00       	mov    $0x13,%edx
    4088:	be 01 00 00 00       	mov    $0x1,%esi
    408d:	48 8d 3d 74 af 00 00 	lea    0xaf74(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4094:	e8 a7 f5 ff ff       	call   3640 <fwrite@plt>
    4099:	31 ff                	xor    %edi,%edi
    409b:	e8 f0 f4 ff ff       	call   3590 <fflush@plt>
    40a0:	bf 66 00 00 00       	mov    $0x66,%edi
    40a5:	e8 b6 f5 ff ff       	call   3660 <_Exit@plt>
    40aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040b0 <buf_put>:
    40b0:	41 54                	push   %r12
    40b2:	49 89 f4             	mov    %rsi,%r12
    40b5:	48 89 d6             	mov    %rdx,%rsi
    40b8:	55                   	push   %rbp
    40b9:	48 89 fd             	mov    %rdi,%rbp
    40bc:	53                   	push   %rbx
    40bd:	48 89 d3             	mov    %rdx,%rbx
    40c0:	e8 2b ff ff ff       	call   3ff0 <buf_grow>
    40c5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40c9:	48 89 da             	mov    %rbx,%rdx
    40cc:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40d0:	4c 89 e6             	mov    %r12,%rsi
    40d3:	e8 98 f4 ff ff       	call   3570 <memcpy@plt>
    40d8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40dc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40e0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40e4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40e8:	5b                   	pop    %rbx
    40e9:	5d                   	pop    %rbp
    40ea:	41 5c                	pop    %r12
    40ec:	c3                   	ret
    40ed:	0f 1f 00             	nopl   (%rax)

00000000000040f0 <fwp_cancel_tree.part.0>:
    40f0:	48 3b 3d e9 76 06 00 	cmp    0x676e9(%rip),%rdi        # 6b7e0 <fwp_cur>
    40f7:	53                   	push   %rbx
    40f8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40fc:	74 35                	je     4133 <fwp_cancel_tree.part.0+0x43>
    40fe:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4102:	75 2f                	jne    4133 <fwp_cancel_tree.part.0+0x43>
    4104:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4108:	75 29                	jne    4133 <fwp_cancel_tree.part.0+0x43>
    410a:	48 8b 05 af 76 06 00 	mov    0x676af(%rip),%rax        # 6b7c0 <fwp_ready_tail>
    4111:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4115:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    411c:	00 00 00 00 
    4120:	48 85 c0             	test   %rax,%rax
    4123:	74 33                	je     4158 <fwp_cancel_tree.part.0+0x68>
    4125:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    412c:	48 89 3d 8d 76 06 00 	mov    %rdi,0x6768d(%rip)        # 6b7c0 <fwp_ready_tail>
    4133:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4137:	48 85 db             	test   %rbx,%rbx
    413a:	74 17                	je     4153 <fwp_cancel_tree.part.0+0x63>
    413c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4140:	75 08                	jne    414a <fwp_cancel_tree.part.0+0x5a>
    4142:	48 89 df             	mov    %rbx,%rdi
    4145:	e8 a6 ff ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    414a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    414e:	48 85 db             	test   %rbx,%rbx
    4151:	75 e9                	jne    413c <fwp_cancel_tree.part.0+0x4c>
    4153:	5b                   	pop    %rbx
    4154:	c3                   	ret
    4155:	0f 1f 00             	nopl   (%rax)
    4158:	48 89 3d 69 76 06 00 	mov    %rdi,0x67669(%rip)        # 6b7c8 <fwp_ready_head>
    415f:	eb cb                	jmp    412c <fwp_cancel_tree.part.0+0x3c>
    4161:	0f 1f 40 00          	nopl   0x0(%rax)
    4165:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    416c:	00 00 00 00 

0000000000004170 <fwp_finish_float>:
    4170:	53                   	push   %rbx
    4171:	be 2e 00 00 00       	mov    $0x2e,%esi
    4176:	48 89 fb             	mov    %rdi,%rbx
    4179:	e8 e2 f2 ff ff       	call   3460 <strchr@plt>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	74 05                	je     4188 <fwp_finish_float+0x18>
    4183:	5b                   	pop    %rbx
    4184:	c3                   	ret
    4185:	0f 1f 00             	nopl   (%rax)
    4188:	be 65 00 00 00       	mov    $0x65,%esi
    418d:	48 89 df             	mov    %rbx,%rdi
    4190:	e8 cb f2 ff ff       	call   3460 <strchr@plt>
    4195:	48 85 c0             	test   %rax,%rax
    4198:	75 e9                	jne    4183 <fwp_finish_float+0x13>
    419a:	48 8d 35 5b b0 00 00 	lea    0xb05b(%rip),%rsi        # f1fc <_IO_stdin_used+0x1fc>
    41a1:	48 89 df             	mov    %rbx,%rdi
    41a4:	e8 e7 f4 ff ff       	call   3690 <strstr@plt>
    41a9:	48 85 c0             	test   %rax,%rax
    41ac:	75 d5                	jne    4183 <fwp_finish_float+0x13>
    41ae:	48 8d 35 67 ae 00 00 	lea    0xae67(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41b5:	48 89 df             	mov    %rbx,%rdi
    41b8:	e8 d3 f4 ff ff       	call   3690 <strstr@plt>
    41bd:	48 85 c0             	test   %rax,%rax
    41c0:	75 c1                	jne    4183 <fwp_finish_float+0x13>
    41c2:	48 89 df             	mov    %rbx,%rdi
    41c5:	e8 66 f2 ff ff       	call   3430 <strlen@plt>
    41ca:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41cf:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41d3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41d8:	5b                   	pop    %rbx
    41d9:	c3                   	ret
    41da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041e0 <ad_raw_report>:
    41e0:	f3 0f 1e fa          	endbr64
    41e4:	41 57                	push   %r15
    41e6:	41 56                	push   %r14
    41e8:	41 55                	push   %r13
    41ea:	41 54                	push   %r12
    41ec:	55                   	push   %rbp
    41ed:	53                   	push   %rbx
    41ee:	48 83 ec 38          	sub    $0x38,%rsp
    41f2:	66 0f 6f 05 96 ef 04 	movdqa 0x4ef96(%rip),%xmm0        # 53190 <ad_raw_live+0x10>
    41f9:	00 
    41fa:	66 0f d4 05 7e ef 04 	paddq  0x4ef7e(%rip),%xmm0        # 53180 <ad_raw_live>
    4201:	00 
    4202:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4209:	00 00 
    420b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4210:	31 c0                	xor    %eax,%eax
    4212:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4216:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    421b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    421f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4224:	48 85 ed             	test   %rbp,%rbp
    4227:	0f 85 d2 01 00 00    	jne    43ff <ad_raw_report+0x21f>
    422d:	4c 8b 05 b4 ee 01 00 	mov    0x1eeb4(%rip),%r8        # 230e8 <ad_raw_before_shutdown>
    4234:	45 31 c9             	xor    %r9d,%r9d
    4237:	31 c0                	xor    %eax,%eax
    4239:	31 db                	xor    %ebx,%ebx
    423b:	48 8b 0d be ee 04 00 	mov    0x4eebe(%rip),%rcx        # 53100 <ad_raw_total_peak>
    4242:	48 8b 3d f7 ed 00 00 	mov    0xedf7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4249:	49 89 e4             	mov    %rsp,%r12
    424c:	48 8d 15 05 b5 00 00 	lea    0xb505(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4253:	be 02 00 00 00       	mov    $0x2,%esi
    4258:	4c 8d 3d 01 ef 04 00 	lea    0x4ef01(%rip),%r15        # 53160 <ad_raw_peak>
    425f:	4c 8d 35 ba ee 04 00 	lea    0x4eeba(%rip),%r14        # 53120 <ad_raw_bytes>
    4266:	e8 e5 f3 ff ff       	call   3650 <__fprintf_chk@plt>
    426b:	48 8d 05 b9 ad 00 00 	lea    0xadb9(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    4272:	f3 0f 7e 05 96 e9 00 	movq   0xe996(%rip),%xmm0        # 12c10 <d0+0x70>
    4279:	00 
    427a:	4c 8d 2d bf ee 04 00 	lea    0x4eebf(%rip),%r13        # 53140 <ad_raw_requests>
    4281:	66 48 0f 6e d0       	movq   %rax,%xmm2
    4286:	48 8d 05 b1 ad 00 00 	lea    0xadb1(%rip),%rax        # f03e <_IO_stdin_used+0x3e>
    428d:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    4291:	66 48 0f 6e d8       	movq   %rax,%xmm3
    4296:	0f 29 04 24          	movaps %xmm0,(%rsp)
    429a:	f3 0f 7e 05 76 e9 00 	movq   0xe976(%rip),%xmm0        # 12c18 <d0+0x78>
    42a1:	00 
    42a2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42a6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42ab:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42af:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42b3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42b8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42bc:	48 85 db             	test   %rbx,%rbx
    42bf:	0f 84 0b 01 00 00    	je     43d0 <ad_raw_report+0x1f0>
    42c5:	52                   	push   %rdx
    42c6:	48 8b 3d 73 ed 00 00 	mov    0xed73(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    42cd:	48 8d 0d 4c ad 00 00 	lea    0xad4c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    42d4:	48 8d 15 dd b4 00 00 	lea    0xb4dd(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    42db:	50                   	push   %rax
    42dc:	be 02 00 00 00       	mov    $0x2,%esi
    42e1:	31 c0                	xor    %eax,%eax
    42e3:	48 83 c3 01          	add    $0x1,%rbx
    42e7:	e8 64 f3 ff ff       	call   3650 <__fprintf_chk@plt>
    42ec:	5f                   	pop    %rdi
    42ed:	41 58                	pop    %r8
    42ef:	48 83 fb 04          	cmp    $0x4,%rbx
    42f3:	75 b6                	jne    42ab <ad_raw_report+0xcb>
    42f5:	48 8b 0d 44 ed 00 00 	mov    0xed44(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    42fc:	ba 13 00 00 00       	mov    $0x13,%edx
    4301:	be 01 00 00 00       	mov    $0x1,%esi
    4306:	48 8d 3d 3a ad 00 00 	lea    0xad3a(%rip),%rdi        # f047 <_IO_stdin_used+0x47>
    430d:	e8 2e f3 ff ff       	call   3640 <fwrite@plt>
    4312:	48 83 3d d6 ed 01 00 	cmpq   $0x0,0x1edd6(%rip)        # 230f0 <ad_raw_checkpoint_count>
    4319:	00 
    431a:	74 75                	je     4391 <ad_raw_report+0x1b1>
    431c:	4c 8b 05 dd ed 01 00 	mov    0x1eddd(%rip),%r8        # 23100 <ad_raw_checkpoints>
    4323:	4c 8b 0d de ed 01 00 	mov    0x1edde(%rip),%r9        # 23108 <ad_raw_checkpoints+0x8>
    432a:	48 8d 1d cf ed 01 00 	lea    0x1edcf(%rip),%rbx        # 23100 <ad_raw_checkpoints>
    4331:	48 8d 0d 36 ad 00 00 	lea    0xad36(%rip),%rcx        # f06e <_IO_stdin_used+0x6e>
    4338:	48 8b 05 d1 ed 01 00 	mov    0x1edd1(%rip),%rax        # 23110 <ad_raw_checkpoints+0x10>
    433f:	4c 8d 25 da ac 00 00 	lea    0xacda(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4346:	eb 1b                	jmp    4363 <ad_raw_report+0x183>
    4348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    434f:	00 
    4350:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4354:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4358:	48 83 c3 18          	add    $0x18,%rbx
    435c:	4c 89 e1             	mov    %r12,%rcx
    435f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4363:	48 83 ec 08          	sub    $0x8,%rsp
    4367:	be 02 00 00 00       	mov    $0x2,%esi
    436c:	48 83 c5 01          	add    $0x1,%rbp
    4370:	48 8b 3d c9 ec 00 00 	mov    0xecc9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4377:	50                   	push   %rax
    4378:	48 8d 15 79 b4 00 00 	lea    0xb479(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    437f:	31 c0                	xor    %eax,%eax
    4381:	e8 ca f2 ff ff       	call   3650 <__fprintf_chk@plt>
    4386:	48 3b 2d 63 ed 01 00 	cmp    0x1ed63(%rip),%rbp        # 230f0 <ad_raw_checkpoint_count>
    438d:	59                   	pop    %rcx
    438e:	5e                   	pop    %rsi
    438f:	72 bf                	jb     4350 <ad_raw_report+0x170>
    4391:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    4396:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    439d:	00 00 
    439f:	75 6a                	jne    440b <ad_raw_report+0x22b>
    43a1:	48 8b 0d 98 ec 00 00 	mov    0xec98(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43a8:	48 83 c4 38          	add    $0x38,%rsp
    43ac:	ba 04 00 00 00       	mov    $0x4,%edx
    43b1:	be 01 00 00 00       	mov    $0x1,%esi
    43b6:	5b                   	pop    %rbx
    43b7:	48 8d 3d 9d ac 00 00 	lea    0xac9d(%rip),%rdi        # f05b <_IO_stdin_used+0x5b>
    43be:	5d                   	pop    %rbp
    43bf:	41 5c                	pop    %r12
    43c1:	41 5d                	pop    %r13
    43c3:	41 5e                	pop    %r14
    43c5:	41 5f                	pop    %r15
    43c7:	e9 74 f2 ff ff       	jmp    3640 <fwrite@plt>
    43cc:	0f 1f 40 00          	nopl   0x0(%rax)
    43d0:	52                   	push   %rdx
    43d1:	be 02 00 00 00       	mov    $0x2,%esi
    43d6:	48 8b 3d 63 ec 00 00 	mov    0xec63(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43dd:	48 8d 15 d4 b3 00 00 	lea    0xb3d4(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    43e4:	50                   	push   %rax
    43e5:	48 8d 0d 82 ac 00 00 	lea    0xac82(%rip),%rcx        # f06e <_IO_stdin_used+0x6e>
    43ec:	31 c0                	xor    %eax,%eax
    43ee:	bb 01 00 00 00       	mov    $0x1,%ebx
    43f3:	e8 58 f2 ff ff       	call   3650 <__fprintf_chk@plt>
    43f8:	58                   	pop    %rax
    43f9:	5a                   	pop    %rdx
    43fa:	e9 ac fe ff ff       	jmp    42ab <ad_raw_report+0xcb>
    43ff:	48 8d 3d 2a b3 00 00 	lea    0xb32a(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4406:	e8 b5 fb ff ff       	call   3fc0 <ad_raw_fail>
    440b:	e8 30 f0 ff ff       	call   3440 <__stack_chk_fail@plt>

0000000000004410 <fwp_trap>:
    4410:	55                   	push   %rbp
    4411:	48 89 fd             	mov    %rdi,%rbp
    4414:	53                   	push   %rbx
    4415:	48 83 ec 08          	sub    $0x8,%rsp
    4419:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4420:	ff ff 
    4422:	e8 99 f8 ff ff       	call   3cc0 <fwp_flush>
    4427:	31 c0                	xor    %eax,%eax
    4429:	48 89 e9             	mov    %rbp,%rcx
    442c:	be 02 00 00 00       	mov    $0x2,%esi
    4431:	48 8b 3d 08 ec 00 00 	mov    0xec08(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4438:	48 8d 15 21 ac 00 00 	lea    0xac21(%rip),%rdx        # f060 <_IO_stdin_used+0x60>
    443f:	e8 0c f2 ff ff       	call   3650 <__fprintf_chk@plt>
    4444:	48 85 db             	test   %rbx,%rbx
    4447:	74 16                	je     445f <fwp_trap+0x4f>
    4449:	48 8b 3d f0 eb 00 00 	mov    0xebf0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4450:	e8 3b f1 ff ff       	call   3590 <fflush@plt>
    4455:	bf 65 00 00 00       	mov    $0x65,%edi
    445a:	e8 01 f2 ff ff       	call   3660 <_Exit@plt>
    445f:	bf 65 00 00 00       	mov    $0x65,%edi
    4464:	e8 c7 f1 ff ff       	call   3630 <exit@plt>
    4469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004470 <fwp_closure_drop_push>:
    4470:	41 56                	push   %r14
    4472:	41 54                	push   %r12
    4474:	49 89 f4             	mov    %rsi,%r12
    4477:	55                   	push   %rbp
    4478:	48 89 fd             	mov    %rdi,%rbp
    447b:	53                   	push   %rbx
    447c:	48 83 ec 18          	sub    $0x18,%rsp
    4480:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4484:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4488:	74 26                	je     44b0 <fwp_closure_drop_push+0x40>
    448a:	4c 8b 07             	mov    (%rdi),%r8
    448d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4494:	00 
    4495:	48 83 c3 01          	add    $0x1,%rbx
    4499:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    449d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44a1:	48 83 c4 18          	add    $0x18,%rsp
    44a5:	5b                   	pop    %rbx
    44a6:	5d                   	pop    %rbp
    44a7:	41 5c                	pop    %r12
    44a9:	41 5e                	pop    %r14
    44ab:	c3                   	ret
    44ac:	0f 1f 40 00          	nopl   0x0(%rax)
    44b0:	48 89 d8             	mov    %rbx,%rax
    44b3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44b7:	0f 85 a9 00 00 00    	jne    4566 <fwp_closure_drop_push+0xf6>
    44bd:	48 89 d9             	mov    %rbx,%rcx
    44c0:	48 c1 e1 04          	shl    $0x4,%rcx
    44c4:	48 89 cf             	mov    %rcx,%rdi
    44c7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44cb:	e8 b0 f0 ff ff       	call   3580 <malloc@plt>
    44d0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44d4:	48 85 c0             	test   %rax,%rax
    44d7:	74 5f                	je     4538 <fwp_closure_drop_push+0xc8>
    44d9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44dd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44e4:	00 
    44e5:	48 89 c7             	mov    %rax,%rdi
    44e8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44ec:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44f1:	48 89 34 24          	mov    %rsi,(%rsp)
    44f5:	e8 46 f0 ff ff       	call   3540 <__memcpy_chk@plt>
    44fa:	48 8b 34 24          	mov    (%rsp),%rsi
    44fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4503:	49 89 c0             	mov    %rax,%r8
    4506:	48 8d 45 18          	lea    0x18(%rbp),%rax
    450a:	48 39 c6             	cmp    %rax,%rsi
    450d:	74 1c                	je     452b <fwp_closure_drop_push+0xbb>
    450f:	48 89 f7             	mov    %rsi,%rdi
    4512:	4c 89 04 24          	mov    %r8,(%rsp)
    4516:	e8 85 ee ff ff       	call   33a0 <free@plt>
    451b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    451f:	4c 8b 04 24          	mov    (%rsp),%r8
    4523:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    452a:	00 
    452b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    452f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4533:	e9 5d ff ff ff       	jmp    4495 <fwp_closure_drop_push+0x25>
    4538:	48 8b 0d 01 eb 00 00 	mov    0xeb01(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    453f:	ba 13 00 00 00       	mov    $0x13,%edx
    4544:	be 01 00 00 00       	mov    $0x1,%esi
    4549:	48 8d 3d b8 aa 00 00 	lea    0xaab8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4550:	e8 eb f0 ff ff       	call   3640 <fwrite@plt>
    4555:	31 ff                	xor    %edi,%edi
    4557:	e8 34 f0 ff ff       	call   3590 <fflush@plt>
    455c:	bf 66 00 00 00       	mov    $0x66,%edi
    4561:	e8 fa f0 ff ff       	call   3660 <_Exit@plt>
    4566:	48 8d 3d 02 ab 00 00 	lea    0xab02(%rip),%rdi        # f06f <_IO_stdin_used+0x6f>
    456d:	e8 9e fe ff ff       	call   4410 <fwp_trap>
    4572:	0f 1f 00             	nopl   (%rax)
    4575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    457c:	00 00 00 00 

0000000000004580 <fwp_now_ns>:
    4580:	53                   	push   %rbx
    4581:	bf 01 00 00 00       	mov    $0x1,%edi
    4586:	48 83 ec 20          	sub    $0x20,%rsp
    458a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4591:	00 00 
    4593:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4598:	31 db                	xor    %ebx,%ebx
    459a:	48 89 e6             	mov    %rsp,%rsi
    459d:	e8 5e ee ff ff       	call   3400 <clock_gettime@plt>
    45a2:	85 c0                	test   %eax,%eax
    45a4:	75 52                	jne    45f8 <fwp_now_ns+0x78>
    45a6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45ab:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45b0:	48 f7 2c 24          	imulq  (%rsp)
    45b4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45bb:	48 89 f7             	mov    %rsi,%rdi
    45be:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45c2:	48 01 f0             	add    %rsi,%rax
    45c5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45cc:	00 00 80 
    45cf:	48 11 fa             	adc    %rdi,%rdx
    45d2:	31 ff                	xor    %edi,%edi
    45d4:	48 01 c6             	add    %rax,%rsi
    45d7:	48 11 d7             	adc    %rdx,%rdi
    45da:	48 39 f1             	cmp    %rsi,%rcx
    45dd:	48 19 fb             	sbb    %rdi,%rbx
    45e0:	72 27                	jb     4609 <fwp_now_ns+0x89>
    45e2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45e7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ee:	00 00 
    45f0:	75 12                	jne    4604 <fwp_now_ns+0x84>
    45f2:	48 83 c4 20          	add    $0x20,%rsp
    45f6:	5b                   	pop    %rbx
    45f7:	c3                   	ret
    45f8:	48 8d 3d 8a aa 00 00 	lea    0xaa8a(%rip),%rdi        # f089 <_IO_stdin_used+0x89>
    45ff:	e8 0c fe ff ff       	call   4410 <fwp_trap>
    4604:	e8 37 ee ff ff       	call   3440 <__stack_chk_fail@plt>
    4609:	48 8d 3d 28 b2 00 00 	lea    0xb228(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4610:	e8 fb fd ff ff       	call   4410 <fwp_trap>
    4615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    461c:	00 00 00 00 

0000000000004620 <fwp_closure_drop.part.0>:
    4620:	53                   	push   %rbx
    4621:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4628:	66 0f 6f 05 50 b7 00 	movdqa 0xb750(%rip),%xmm0        # fd80 <msg.4+0x40>
    462f:	00 
    4630:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4637:	00 00 
    4639:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4640:	00 
    4641:	48 89 fe             	mov    %rdi,%rsi
    4644:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4649:	48 89 e7             	mov    %rsp,%rdi
    464c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4650:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4655:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    465c:	ff ff 
    465e:	e8 0d fe ff ff       	call   4470 <fwp_closure_drop_push>
    4663:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4668:	48 85 c0             	test   %rax,%rax
    466b:	74 39                	je     46a6 <fwp_closure_drop.part.0+0x86>
    466d:	0f 1f 00             	nopl   (%rax)
    4670:	48 8b 14 24          	mov    (%rsp),%rdx
    4674:	48 83 e8 01          	sub    $0x1,%rax
    4678:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    467d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4681:	8b 07                	mov    (%rdi),%eax
    4683:	48 c1 e0 05          	shl    $0x5,%rax
    4687:	48 03 05 ca 8d 06 00 	add    0x68dca(%rip),%rax        # 6d458 <fwp_fns>
    468e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4692:	48 85 c0             	test   %rax,%rax
    4695:	74 46                	je     46dd <fwp_closure_drop.part.0+0xbd>
    4697:	31 f6                	xor    %esi,%esi
    4699:	ff 50 08             	call   *0x8(%rax)
    469c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a1:	48 85 c0             	test   %rax,%rax
    46a4:	75 ca                	jne    4670 <fwp_closure_drop.part.0+0x50>
    46a6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ad:	ff ff 00 00 00 00 
    46b3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46b7:	48 39 df             	cmp    %rbx,%rdi
    46ba:	74 05                	je     46c1 <fwp_closure_drop.part.0+0xa1>
    46bc:	e8 df ec ff ff       	call   33a0 <free@plt>
    46c1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46c8:	00 
    46c9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46d0:	00 00 
    46d2:	75 15                	jne    46e9 <fwp_closure_drop.part.0+0xc9>
    46d4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46db:	5b                   	pop    %rbx
    46dc:	c3                   	ret
    46dd:	48 8d 3d 7c b1 00 00 	lea    0xb17c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    46e4:	e8 27 fd ff ff       	call   4410 <fwp_trap>
    46e9:	e8 52 ed ff ff       	call   3440 <__stack_chk_fail@plt>
    46ee:	66 90                	xchg   %ax,%ax

00000000000046f0 <fwp_tape_of>:
    46f0:	0f b7 d7             	movzwl %di,%edx
    46f3:	48 85 d2             	test   %rdx,%rdx
    46f6:	74 28                	je     4720 <fwp_tape_of+0x30>
    46f8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46fc:	48 39 05 d5 e9 01 00 	cmp    %rax,0x1e9d5(%rip)        # 230d8 <fwp_ntapes>
    4703:	7e 1b                	jle    4720 <fwp_tape_of+0x30>
    4705:	48 6b c0 58          	imul   $0x58,%rax,%rax
    4709:	48 03 05 d0 e9 01 00 	add    0x1e9d0(%rip),%rax        # 230e0 <fwp_tapes>
    4710:	8b 50 04             	mov    0x4(%rax),%edx
    4713:	85 d2                	test   %edx,%edx
    4715:	74 09                	je     4720 <fwp_tape_of+0x30>
    4717:	48 c1 ff 10          	sar    $0x10,%rdi
    471b:	39 38                	cmp    %edi,(%rax)
    471d:	75 01                	jne    4720 <fwp_tape_of+0x30>
    471f:	c3                   	ret
    4720:	48 83 ec 08          	sub    $0x8,%rsp
    4724:	48 8d 3d 65 b1 00 00 	lea    0xb165(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    472b:	e8 e0 fc ff ff       	call   4410 <fwp_trap>

0000000000004730 <fwp_format_g.constprop.0>:
    4730:	41 57                	push   %r15
    4732:	b9 40 00 00 00       	mov    $0x40,%ecx
    4737:	ba 02 00 00 00       	mov    $0x2,%edx
    473c:	4c 8d 05 62 a9 00 00 	lea    0xa962(%rip),%r8        # f0a5 <_IO_stdin_used+0xa5>
    4743:	41 56                	push   %r14
    4745:	b8 01 00 00 00       	mov    $0x1,%eax
    474a:	41 55                	push   %r13
    474c:	41 54                	push   %r12
    474e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4752:	55                   	push   %rbp
    4753:	45 89 e1             	mov    %r12d,%r9d
    4756:	53                   	push   %rbx
    4757:	48 89 fb             	mov    %rdi,%rbx
    475a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4761:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4768:	00 00 
    476a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4771:	00 
    4772:	41 89 f7             	mov    %esi,%r15d
    4775:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    477a:	be 40 00 00 00       	mov    $0x40,%esi
    477f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4784:	4c 89 f7             	mov    %r14,%rdi
    4787:	e8 04 ec ff ff       	call   3390 <__snprintf_chk@plt>
    478c:	be 65 00 00 00       	mov    $0x65,%esi
    4791:	4c 89 f7             	mov    %r14,%rdi
    4794:	e8 c7 ec ff ff       	call   3460 <strchr@plt>
    4799:	31 f6                	xor    %esi,%esi
    479b:	ba 0a 00 00 00       	mov    $0xa,%edx
    47a0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47a4:	48 89 c5             	mov    %rax,%rbp
    47a7:	e8 b4 ed ff ff       	call   3560 <strtol@plt>
    47ac:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47b1:	49 89 c0             	mov    %rax,%r8
    47b4:	83 c0 05             	add    $0x5,%eax
    47b7:	83 f8 15             	cmp    $0x15,%eax
    47ba:	0f 87 e0 01 00 00    	ja     49a0 <fwp_format_g.constprop.0+0x270>
    47c0:	45 89 e5             	mov    %r12d,%r13d
    47c3:	45 29 c5             	sub    %r8d,%r13d
    47c6:	45 85 ed             	test   %r13d,%r13d
    47c9:	0f 8e 21 01 00 00    	jle    48f0 <fwp_format_g.constprop.0+0x1c0>
    47cf:	41 83 ff 01          	cmp    $0x1,%r15d
    47d3:	0f 84 17 01 00 00    	je     48f0 <fwp_format_g.constprop.0+0x1c0>
    47d9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47de:	31 d2                	xor    %edx,%edx
    47e0:	4d 63 df             	movslq %r15d,%r11
    47e3:	3c 2d                	cmp    $0x2d,%al
    47e5:	0f 94 c2             	sete   %dl
    47e8:	4c 29 dd             	sub    %r11,%rbp
    47eb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47ef:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47f3:	4d 89 f1             	mov    %r14,%r9
    47f6:	4d 29 d1             	sub    %r10,%r9
    47f9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47fd:	3c 2d                	cmp    $0x2d,%al
    47ff:	0f 84 fb 03 00 00    	je     4c00 <fwp_format_g.constprop.0+0x4d0>
    4805:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    480a:	b9 48 00 00 00       	mov    $0x48,%ecx
    480f:	48 89 e8             	mov    %rbp,%rax
    4812:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4816:	49 8d 72 01          	lea    0x1(%r10),%rsi
    481a:	49 83 c1 47          	add    $0x47,%r9
    481e:	45 85 c0             	test   %r8d,%r8d
    4821:	0f 88 f1 02 00 00    	js     4b18 <fwp_format_g.constprop.0+0x3e8>
    4827:	45 0f b6 12          	movzbl (%r10),%r10d
    482b:	4d 63 e0             	movslq %r8d,%r12
    482e:	44 88 10             	mov    %r10b,(%rax)
    4831:	41 83 f8 07          	cmp    $0x7,%r8d
    4835:	0f 87 2d 02 00 00    	ja     4a68 <fwp_format_g.constprop.0+0x338>
    483b:	41 f6 c4 04          	test   $0x4,%r12b
    483f:	0f 85 f2 03 00 00    	jne    4c37 <fwp_format_g.constprop.0+0x507>
    4845:	45 85 e4             	test   %r12d,%r12d
    4848:	74 12                	je     485c <fwp_format_g.constprop.0+0x12c>
    484a:	45 0f b6 06          	movzbl (%r14),%r8d
    484e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4852:	41 f6 c4 02          	test   $0x2,%r12b
    4856:	0f 85 03 04 00 00    	jne    4c5f <fwp_format_g.constprop.0+0x52f>
    485c:	4c 29 e1             	sub    %r12,%rcx
    485f:	4c 01 e7             	add    %r12,%rdi
    4862:	4c 89 fa             	mov    %r15,%rdx
    4865:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    486a:	48 83 e9 01          	sub    $0x1,%rcx
    486e:	4d 63 ed             	movslq %r13d,%r13
    4871:	48 89 0c 24          	mov    %rcx,(%rsp)
    4875:	e8 c6 ec ff ff       	call   3540 <__memcpy_chk@plt>
    487a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    487f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4883:	ba 48 00 00 00       	mov    $0x48,%edx
    4888:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    488c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4890:	4c 89 c8             	mov    %r9,%rax
    4893:	48 29 c8             	sub    %rcx,%rax
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 42 c2          	cmovb  %rdx,%rax
    489d:	4c 29 c9             	sub    %r9,%rcx
    48a0:	4c 89 ea             	mov    %r13,%rdx
    48a3:	48 01 c1             	add    %rax,%rcx
    48a6:	e8 95 ec ff ff       	call   3540 <__memcpy_chk@plt>
    48ab:	4c 01 e8             	add    %r13,%rax
    48ae:	48 29 e8             	sub    %rbp,%rax
    48b1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 47 c2          	cmova  %rdx,%rax
    48bd:	89 c1                	mov    %eax,%ecx
    48bf:	83 f8 08             	cmp    $0x8,%eax
    48c2:	0f 83 18 02 00 00    	jae    4ae0 <fwp_format_g.constprop.0+0x3b0>
    48c8:	a8 04                	test   $0x4,%al
    48ca:	0f 85 54 03 00 00    	jne    4c24 <fwp_format_g.constprop.0+0x4f4>
    48d0:	85 c0                	test   %eax,%eax
    48d2:	74 0f                	je     48e3 <fwp_format_g.constprop.0+0x1b3>
    48d4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48d9:	88 13                	mov    %dl,(%rbx)
    48db:	a8 02                	test   $0x2,%al
    48dd:	0f 85 6b 03 00 00    	jne    4c4e <fwp_format_g.constprop.0+0x51e>
    48e3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48e7:	eb 36                	jmp    491f <fwp_format_g.constprop.0+0x1ef>
    48e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48f0:	45 31 c9             	xor    %r9d,%r9d
    48f3:	45 85 ed             	test   %r13d,%r13d
    48f6:	4c 8d 05 b7 a7 00 00 	lea    0xa7b7(%rip),%r8        # f0b4 <_IO_stdin_used+0xb4>
    48fd:	48 89 df             	mov    %rbx,%rdi
    4900:	45 0f 49 cd          	cmovns %r13d,%r9d
    4904:	ba 02 00 00 00       	mov    $0x2,%edx
    4909:	be 90 01 00 00       	mov    $0x190,%esi
    490e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4915:	b8 01 00 00 00       	mov    $0x1,%eax
    491a:	e8 71 ea ff ff       	call   3390 <__snprintf_chk@plt>
    491f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4924:	48 89 df             	mov    %rbx,%rdi
    4927:	e8 34 eb ff ff       	call   3460 <strchr@plt>
    492c:	48 85 c0             	test   %rax,%rax
    492f:	74 3f                	je     4970 <fwp_format_g.constprop.0+0x240>
    4931:	48 89 df             	mov    %rbx,%rdi
    4934:	e8 f7 ea ff ff       	call   3430 <strlen@plt>
    4939:	48 85 c0             	test   %rax,%rax
    493c:	75 0b                	jne    4949 <fwp_format_g.constprop.0+0x219>
    493e:	eb 30                	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4940:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4944:	48 85 c0             	test   %rax,%rax
    4947:	74 27                	je     4970 <fwp_format_g.constprop.0+0x240>
    4949:	48 89 c2             	mov    %rax,%rdx
    494c:	48 83 e8 01          	sub    $0x1,%rax
    4950:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4954:	74 ea                	je     4940 <fwp_format_g.constprop.0+0x210>
    4956:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    495b:	0f 84 6f 01 00 00    	je     4ad0 <fwp_format_g.constprop.0+0x3a0>
    4961:	0f 1f 40 00          	nopl   0x0(%rax)
    4965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    496c:	00 00 00 00 
    4970:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4977:	00 
    4978:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    497f:	00 00 
    4981:	0f 85 ec 02 00 00    	jne    4c73 <fwp_format_g.constprop.0+0x543>
    4987:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    498e:	5b                   	pop    %rbx
    498f:	5d                   	pop    %rbp
    4990:	41 5c                	pop    %r12
    4992:	41 5d                	pop    %r13
    4994:	41 5e                	pop    %r14
    4996:	41 5f                	pop    %r15
    4998:	c3                   	ret
    4999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49a0:	4c 29 f5             	sub    %r14,%rbp
    49a3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49a8:	4c 89 f6             	mov    %r14,%rsi
    49ab:	4c 89 04 24          	mov    %r8,(%rsp)
    49af:	49 89 ec             	mov    %rbp,%r12
    49b2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b7:	4c 89 e2             	mov    %r12,%rdx
    49ba:	48 89 ef             	mov    %rbp,%rdi
    49bd:	e8 7e eb ff ff       	call   3540 <__memcpy_chk@plt>
    49c2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49c8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49cd:	48 89 ef             	mov    %rbp,%rdi
    49d0:	e8 8b ea ff ff       	call   3460 <strchr@plt>
    49d5:	4c 8b 04 24          	mov    (%rsp),%r8
    49d9:	48 85 c0             	test   %rax,%rax
    49dc:	74 40                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    49de:	4d 85 e4             	test   %r12,%r12
    49e1:	74 3b                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    49e3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49e8:	eb 23                	jmp    4a0d <fwp_format_g.constprop.0+0x2dd>
    49ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49f1:	00 00 00 00 
    49f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49fc:	00 00 00 00 
    4a00:	c6 00 00             	movb   $0x0,(%rax)
    4a03:	48 83 e8 01          	sub    $0x1,%rax
    4a07:	49 83 ec 01          	sub    $0x1,%r12
    4a0b:	74 11                	je     4a1e <fwp_format_g.constprop.0+0x2ee>
    4a0d:	80 38 30             	cmpb   $0x30,(%rax)
    4a10:	74 ee                	je     4a00 <fwp_format_g.constprop.0+0x2d0>
    4a12:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a18:	0f 84 fb 01 00 00    	je     4c19 <fwp_format_g.constprop.0+0x4e9>
    4a1e:	44 89 c0             	mov    %r8d,%eax
    4a21:	ba 02 00 00 00       	mov    $0x2,%edx
    4a26:	49 89 e9             	mov    %rbp,%r9
    4a29:	be 90 01 00 00       	mov    $0x190,%esi
    4a2e:	f7 d8                	neg    %eax
    4a30:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a37:	48 89 df             	mov    %rbx,%rdi
    4a3a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a3e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a42:	41 83 e0 02          	and    $0x2,%r8d
    4a46:	41 83 c0 2b          	add    $0x2b,%r8d
    4a4a:	50                   	push   %rax
    4a4b:	31 c0                	xor    %eax,%eax
    4a4d:	41 50                	push   %r8
    4a4f:	4c 8d 05 54 a6 00 00 	lea    0xa654(%rip),%r8        # f0aa <_IO_stdin_used+0xaa>
    4a56:	e8 35 e9 ff ff       	call   3390 <__snprintf_chk@plt>
    4a5b:	58                   	pop    %rax
    4a5c:	5a                   	pop    %rdx
    4a5d:	e9 0e ff ff ff       	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4a62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a68:	4d 8b 06             	mov    (%r14),%r8
    4a6b:	48 83 c0 09          	add    $0x9,%rax
    4a6f:	4c 89 f2             	mov    %r14,%rdx
    4a72:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a76:	4c 89 07             	mov    %r8,(%rdi)
    4a79:	45 89 e0             	mov    %r12d,%r8d
    4a7c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a81:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a86:	49 89 f8             	mov    %rdi,%r8
    4a89:	49 29 c0             	sub    %rax,%r8
    4a8c:	4c 29 c2             	sub    %r8,%rdx
    4a8f:	45 01 e0             	add    %r12d,%r8d
    4a92:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a96:	41 83 f8 08          	cmp    $0x8,%r8d
    4a9a:	0f 82 bc fd ff ff    	jb     485c <fwp_format_g.constprop.0+0x12c>
    4aa0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4aa4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4aa8:	45 31 d2             	xor    %r10d,%r10d
    4aab:	45 89 d3             	mov    %r10d,%r11d
    4aae:	41 83 c2 08          	add    $0x8,%r10d
    4ab2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ab6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4aba:	45 39 c2             	cmp    %r8d,%r10d
    4abd:	72 ec                	jb     4aab <fwp_format_g.constprop.0+0x37b>
    4abf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ac3:	e9 94 fd ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4ac8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4acf:	00 
    4ad0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ad5:	e9 96 fe ff ff       	jmp    4970 <fwp_format_g.constprop.0+0x240>
    4ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ae0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ae5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ae9:	48 89 ee             	mov    %rbp,%rsi
    4aec:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4af0:	48 89 13             	mov    %rdx,(%rbx)
    4af3:	89 c2                	mov    %eax,%edx
    4af5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4afa:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4aff:	48 89 d9             	mov    %rbx,%rcx
    4b02:	48 29 f9             	sub    %rdi,%rcx
    4b05:	48 29 ce             	sub    %rcx,%rsi
    4b08:	01 c1                	add    %eax,%ecx
    4b0a:	c1 e9 03             	shr    $0x3,%ecx
    4b0d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b10:	e9 ce fd ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4b15:	0f 1f 00             	nopl   (%rax)
    4b18:	c6 00 30             	movb   $0x30,(%rax)
    4b1b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b1f:	4c 89 fa             	mov    %r15,%rdx
    4b22:	4c 89 e9             	mov    %r13,%rcx
    4b25:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b2a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b2f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b33:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b38:	e8 03 ea ff ff       	call   3540 <__memcpy_chk@plt>
    4b3d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b42:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b47:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b4c:	48 89 c7             	mov    %rax,%rdi
    4b4f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b53:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b58:	4c 89 c8             	mov    %r9,%rax
    4b5b:	4c 29 e8             	sub    %r13,%rax
    4b5e:	48 39 c8             	cmp    %rcx,%rax
    4b61:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b65:	4d 29 cd             	sub    %r9,%r13
    4b68:	49 01 ff             	add    %rdi,%r15
    4b6b:	4c 01 e8             	add    %r13,%rax
    4b6e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b72:	74 3d                	je     4bb1 <fwp_format_g.constprop.0+0x481>
    4b74:	41 f7 d0             	not    %r8d
    4b77:	31 f6                	xor    %esi,%esi
    4b79:	ba 48 00 00 00       	mov    $0x48,%edx
    4b7e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b83:	48 39 d0             	cmp    %rdx,%rax
    4b86:	48 0f 43 d0          	cmovae %rax,%rdx
    4b8a:	48 89 d1             	mov    %rdx,%rcx
    4b8d:	48 29 c1             	sub    %rax,%rcx
    4b90:	48 83 c1 01          	add    $0x1,%rcx
    4b94:	48 39 d1             	cmp    %rdx,%rcx
    4b97:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b9b:	48 83 e8 01          	sub    $0x1,%rax
    4b9f:	48 83 c6 01          	add    $0x1,%rsi
    4ba3:	48 29 d0             	sub    %rdx,%rax
    4ba6:	48 01 c8             	add    %rcx,%rax
    4ba9:	41 39 f0             	cmp    %esi,%r8d
    4bac:	7f cb                	jg     4b79 <fwp_format_g.constprop.0+0x449>
    4bae:	4d 01 c7             	add    %r8,%r15
    4bb1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bb6:	41 0f b6 12          	movzbl (%r10),%edx
    4bba:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bbe:	4c 89 f6             	mov    %r14,%rsi
    4bc1:	48 39 c8             	cmp    %rcx,%rax
    4bc4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4bc8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bcc:	41 88 17             	mov    %dl,(%r15)
    4bcf:	48 89 ca             	mov    %rcx,%rdx
    4bd2:	48 29 c2             	sub    %rax,%rdx
    4bd5:	48 83 c2 01          	add    $0x1,%rdx
    4bd9:	48 39 ca             	cmp    %rcx,%rdx
    4bdc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4be0:	48 83 e8 01          	sub    $0x1,%rax
    4be4:	48 29 c8             	sub    %rcx,%rax
    4be7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4beb:	49 63 d4             	movslq %r12d,%rdx
    4bee:	e8 4d e9 ff ff       	call   3540 <__memcpy_chk@plt>
    4bf3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bf7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bfb:	e9 ae fc ff ff       	jmp    48ae <fwp_format_g.constprop.0+0x17e>
    4c00:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c05:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c0a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c0f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c14:	e9 f9 fb ff ff       	jmp    4812 <fwp_format_g.constprop.0+0xe2>
    4c19:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c1f:	e9 fa fd ff ff       	jmp    4a1e <fwp_format_g.constprop.0+0x2ee>
    4c24:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c28:	89 13                	mov    %edx,(%rbx)
    4c2a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c2e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c32:	e9 ac fc ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4c37:	41 8b 06             	mov    (%r14),%eax
    4c3a:	89 07                	mov    %eax,(%rdi)
    4c3c:	44 89 e0             	mov    %r12d,%eax
    4c3f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c44:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c49:	e9 0e fc ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4c4e:	89 c2                	mov    %eax,%edx
    4c50:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c55:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c5a:	e9 84 fc ff ff       	jmp    48e3 <fwp_format_g.constprop.0+0x1b3>
    4c5f:	44 89 e0             	mov    %r12d,%eax
    4c62:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c68:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c6e:	e9 e9 fb ff ff       	jmp    485c <fwp_format_g.constprop.0+0x12c>
    4c73:	e8 c8 e7 ff ff       	call   3440 <__stack_chk_fail@plt>
    4c78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c7f:	00 

0000000000004c80 <fwp_heap_report>:
    4c80:	f3 0f 1e fa          	endbr64
    4c84:	41 54                	push   %r12
    4c86:	48 8d 3d 2c a4 00 00 	lea    0xa42c(%rip),%rdi        # f0b9 <_IO_stdin_used+0xb9>
    4c8d:	55                   	push   %rbp
    4c8e:	53                   	push   %rbx
    4c8f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c96:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c9d:	00 00 
    4c9f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ca6:	00 
    4ca7:	48 8d 35 96 a5 00 00 	lea    0xa596(%rip),%rsi        # f244 <_IO_stdin_used+0x244>
    4cae:	e8 3d e9 ff ff       	call   35f0 <fopen@plt>
    4cb3:	48 85 c0             	test   %rax,%rax
    4cb6:	0f 84 c5 00 00 00    	je     4d81 <fwp_heap_report+0x101>
    4cbc:	48 89 c5             	mov    %rax,%rbp
    4cbf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4cc6:	48 89 e3             	mov    %rsp,%rbx
    4cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cd0:	48 89 ea             	mov    %rbp,%rdx
    4cd3:	be 00 01 00 00       	mov    $0x100,%esi
    4cd8:	48 89 df             	mov    %rbx,%rdi
    4cdb:	e8 00 e8 ff ff       	call   34e0 <fgets@plt>
    4ce0:	48 85 c0             	test   %rax,%rax
    4ce3:	74 2b                	je     4d10 <fwp_heap_report+0x90>
    4ce5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ceb:	75 e3                	jne    4cd0 <fwp_heap_report+0x50>
    4ced:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cf1:	75 dd                	jne    4cd0 <fwp_heap_report+0x50>
    4cf3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cf8:	75 d6                	jne    4cd0 <fwp_heap_report+0x50>
    4cfa:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cff:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d04:	31 f6                	xor    %esi,%esi
    4d06:	e8 55 e8 ff ff       	call   3560 <strtol@plt>
    4d0b:	49 89 c4             	mov    %rax,%r12
    4d0e:	eb c0                	jmp    4cd0 <fwp_heap_report+0x50>
    4d10:	48 89 ef             	mov    %rbp,%rdi
    4d13:	e8 08 e7 ff ff       	call   3420 <fclose@plt>
    4d18:	48 83 ec 08          	sub    $0x8,%rsp
    4d1c:	4c 8b 0d a5 7e 06 00 	mov    0x67ea5(%rip),%r9        # 6cbc8 <fwp_heap+0x13c8>
    4d23:	4c 8b 05 fe 7e 06 00 	mov    0x67efe(%rip),%r8        # 6cc28 <fwp_heap+0x1428>
    4d2a:	48 8d 15 af ab 00 00 	lea    0xabaf(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d31:	41 54                	push   %r12
    4d33:	48 8b 0d e6 7e 06 00 	mov    0x67ee6(%rip),%rcx        # 6cc20 <fwp_heap+0x1420>
    4d3a:	be 02 00 00 00       	mov    $0x2,%esi
    4d3f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d44:	f2 0f 10 0d f4 7e 06 	movsd  0x67ef4(%rip),%xmm1        # 6cc40 <fwp_heap+0x1440>
    4d4b:	00 
    4d4c:	f2 0f 10 05 e4 7e 06 	movsd  0x67ee4(%rip),%xmm0        # 6cc38 <fwp_heap+0x1438>
    4d53:	00 
    4d54:	48 8b 3d e5 e2 00 00 	mov    0xe2e5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d5b:	e8 f0 e8 ff ff       	call   3650 <__fprintf_chk@plt>
    4d60:	58                   	pop    %rax
    4d61:	5a                   	pop    %rdx
    4d62:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d69:	00 
    4d6a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d71:	00 00 
    4d73:	75 15                	jne    4d8a <fwp_heap_report+0x10a>
    4d75:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d7c:	5b                   	pop    %rbx
    4d7d:	5d                   	pop    %rbp
    4d7e:	41 5c                	pop    %r12
    4d80:	c3                   	ret
    4d81:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d88:	eb 8e                	jmp    4d18 <fwp_heap_report+0x98>
    4d8a:	e8 b1 e6 ff ff       	call   3440 <__stack_chk_fail@plt>
    4d8f:	90                   	nop

0000000000004d90 <fwp_heap_init>:
    4d90:	66 0f 6f 05 f8 af 00 	movdqa 0xaff8(%rip),%xmm0        # fd90 <msg.4+0x50>
    4d97:	00 
    4d98:	41 54                	push   %r12
    4d9a:	48 8d 05 9f 79 06 00 	lea    0x6799f(%rip),%rax        # 6c740 <fwp_heap+0xf40>
    4da1:	ba 00 01 00 00       	mov    $0x100,%edx
    4da6:	55                   	push   %rbp
    4da7:	66 0f 6f 15 21 b0 00 	movdqa 0xb021(%rip),%xmm2        # fdd0 <msg.4+0x90>
    4dae:	00 
    4daf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4db3:	53                   	push   %rbx
    4db4:	0f 29 05 45 79 06 00 	movaps %xmm0,0x67945(%rip)        # 6c700 <fwp_heap+0xf00>
    4dbb:	66 0f 6f 05 dd af 00 	movdqa 0xafdd(%rip),%xmm0        # fda0 <msg.4+0x60>
    4dc2:	00 
    4dc3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4dc7:	c7 05 d3 7d 06 00 01 	movl   $0x1,0x67dd3(%rip)        # 6cba4 <fwp_heap+0x13a4>
    4dce:	00 00 00 
    4dd1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4dd6:	0f 29 05 33 79 06 00 	movaps %xmm0,0x67933(%rip)        # 6c710 <fwp_heap+0xf10>
    4ddd:	66 0f 6f 05 cb af 00 	movdqa 0xafcb(%rip),%xmm0        # fdb0 <msg.4+0x70>
    4de4:	00 
    4de5:	0f 29 05 34 79 06 00 	movaps %xmm0,0x67934(%rip)        # 6c720 <fwp_heap+0xf20>
    4dec:	66 0f 6f 05 cc af 00 	movdqa 0xafcc(%rip),%xmm0        # fdc0 <msg.4+0x80>
    4df3:	00 
    4df4:	0f 29 05 35 79 06 00 	movaps %xmm0,0x67935(%rip)        # 6c730 <fwp_heap+0xf30>
    4dfb:	89 d3                	mov    %edx,%ebx
    4dfd:	66 0f 6e e2          	movd   %edx,%xmm4
    4e01:	48 83 c0 10          	add    $0x10,%rax
    4e05:	01 d2                	add    %edx,%edx
    4e07:	c1 eb 02             	shr    $0x2,%ebx
    4e0a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e0e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e13:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e17:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e1c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e20:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e24:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e29:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e2e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e32:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e37:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e3b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e3f:	48 39 c7             	cmp    %rax,%rdi
    4e42:	75 b7                	jne    4dfb <fwp_heap_init+0x6b>
    4e44:	4c 8d 05 b5 69 06 00 	lea    0x669b5(%rip),%r8        # 6b800 <fwp_heap>
    4e4b:	31 c9                	xor    %ecx,%ecx
    4e4d:	31 c0                	xor    %eax,%eax
    4e4f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e5d:	00 00 00 
    4e60:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e67:	00 
    4e68:	48 39 ca             	cmp    %rcx,%rdx
    4e6b:	73 0f                	jae    4e7c <fwp_heap_init+0xec>
    4e6d:	0f 1f 00             	nopl   (%rax)
    4e70:	48 83 c0 01          	add    $0x1,%rax
    4e74:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e77:	48 39 ca             	cmp    %rcx,%rdx
    4e7a:	72 f4                	jb     4e70 <fwp_heap_init+0xe0>
    4e7c:	48 83 c1 10          	add    $0x10,%rcx
    4e80:	88 07                	mov    %al,(%rdi)
    4e82:	48 83 c7 01          	add    $0x1,%rdi
    4e86:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e8d:	75 d1                	jne    4e60 <fwp_heap_init+0xd0>
    4e8f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e96:	00 00 00 
    4e99:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e9e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ea5:	45 31 c9             	xor    %r9d,%r9d
    4ea8:	31 d2                	xor    %edx,%edx
    4eaa:	31 ff                	xor    %edi,%edi
    4eac:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4eb2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eb7:	4c 89 e6             	mov    %r12,%rsi
    4eba:	e8 91 e5 ff ff       	call   3450 <mmap@plt>
    4ebf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ec3:	75 13                	jne    4ed8 <fwp_heap_init+0x148>
    4ec5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ec9:	83 ed 01             	sub    $0x1,%ebp
    4ecc:	75 d0                	jne    4e9e <fwp_heap_init+0x10e>
    4ece:	e8 1d ef ff ff       	call   3df0 <fwp_heap_oom>
    4ed3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ed8:	48 85 c0             	test   %rax,%rax
    4edb:	74 f1                	je     4ece <fwp_heap_init+0x13e>
    4edd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ee1:	48 89 05 d0 7c 06 00 	mov    %rax,0x67cd0(%rip)        # 6cbb8 <fwp_heap+0x13b8>
    4ee8:	45 31 c9             	xor    %r9d,%r9d
    4eeb:	31 d2                	xor    %edx,%edx
    4eed:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ef3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ef7:	31 ff                	xor    %edi,%edi
    4ef9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4eff:	66 31 c0             	xor    %ax,%ax
    4f02:	48 c1 e6 03          	shl    $0x3,%rsi
    4f06:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f0b:	4c 89 25 ae 7c 06 00 	mov    %r12,0x67cae(%rip)        # 6cbc0 <fwp_heap+0x13c0>
    4f12:	48 89 05 97 7c 06 00 	mov    %rax,0x67c97(%rip)        # 6cbb0 <fwp_heap+0x13b0>
    4f19:	48 89 1d b0 7c 06 00 	mov    %rbx,0x67cb0(%rip)        # 6cbd0 <fwp_heap+0x13d0>
    4f20:	48 89 35 d9 7c 06 00 	mov    %rsi,0x67cd9(%rip)        # 6cc00 <fwp_heap+0x1400>
    4f27:	e8 24 e5 ff ff       	call   3450 <mmap@plt>
    4f2c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f30:	74 9c                	je     4ece <fwp_heap_init+0x13e>
    4f32:	48 8d 3d b6 a1 00 00 	lea    0xa1b6(%rip),%rdi        # f0ef <_IO_stdin_used+0xef>
    4f39:	48 89 05 b8 7c 06 00 	mov    %rax,0x67cb8(%rip)        # 6cbf8 <fwp_heap+0x13f8>
    4f40:	e8 3b e4 ff ff       	call   3380 <getenv@plt>
    4f45:	48 89 c2             	mov    %rax,%rdx
    4f48:	31 c0                	xor    %eax,%eax
    4f4a:	48 85 d2             	test   %rdx,%rdx
    4f4d:	74 15                	je     4f64 <fwp_heap_init+0x1d4>
    4f4f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f52:	74 10                	je     4f64 <fwp_heap_init+0x1d4>
    4f54:	0f b6 02             	movzbl (%rdx),%eax
    4f57:	83 e8 30             	sub    $0x30,%eax
    4f5a:	74 13                	je     4f6f <fwp_heap_init+0x1df>
    4f5c:	85 c0                	test   %eax,%eax
    4f5e:	0f 95 c0             	setne  %al
    4f61:	0f b6 c0             	movzbl %al,%eax
    4f64:	5b                   	pop    %rbx
    4f65:	5d                   	pop    %rbp
    4f66:	89 05 3c 7c 06 00    	mov    %eax,0x67c3c(%rip)        # 6cba8 <fwp_heap+0x13a8>
    4f6c:	41 5c                	pop    %r12
    4f6e:	c3                   	ret
    4f6f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f73:	85 c0                	test   %eax,%eax
    4f75:	0f 95 c0             	setne  %al
    4f78:	0f b6 c0             	movzbl %al,%eax
    4f7b:	eb e7                	jmp    4f64 <fwp_heap_init+0x1d4>
    4f7d:	0f 1f 00             	nopl   (%rax)

0000000000004f80 <fwp_wake_io>:
    4f80:	48 8b 07             	mov    (%rdi),%rax
    4f83:	48 85 c0             	test   %rax,%rax
    4f86:	0f 84 f4 00 00 00    	je     5080 <fwp_wake_io+0x100>
    4f8c:	53                   	push   %rbx
    4f8d:	4c 8b 05 2c 68 06 00 	mov    0x6682c(%rip),%r8        # 6b7c0 <fwp_ready_tail>
    4f94:	49 89 f9             	mov    %rdi,%r9
    4f97:	48 89 c2             	mov    %rax,%rdx
    4f9a:	45 31 db             	xor    %r11d,%r11d
    4f9d:	45 31 d2             	xor    %r10d,%r10d
    4fa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fa4:	eb 71                	jmp    5017 <fwp_wake_io+0x97>
    4fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fad:	00 00 00 
    4fb0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fb7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fbe:	48 85 c9             	test   %rcx,%rcx
    4fc1:	74 07                	je     4fca <fwp_wake_io+0x4a>
    4fc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fd1:	00 00 00 00 
    4fd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fdc:	49 8b 01             	mov    (%r9),%rax
    4fdf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fe3:	75 2a                	jne    500f <fwp_wake_io+0x8f>
    4fe5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fe9:	75 24                	jne    500f <fwp_wake_io+0x8f>
    4feb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fef:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4ff6:	00 00 00 00 
    4ffa:	4d 85 c0             	test   %r8,%r8
    4ffd:	74 51                	je     5050 <fwp_wake_io+0xd0>
    4fff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5006:	49 89 d0             	mov    %rdx,%r8
    5009:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    500f:	48 89 c2             	mov    %rax,%rdx
    5012:	48 85 c0             	test   %rax,%rax
    5015:	74 49                	je     5060 <fwp_wake_io+0xe0>
    5017:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    501e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5022:	48 85 ff             	test   %rdi,%rdi
    5025:	74 b8                	je     4fdf <fwp_wake_io+0x5f>
    5027:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    502e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5035:	48 85 f6             	test   %rsi,%rsi
    5038:	0f 85 72 ff ff ff    	jne    4fb0 <fwp_wake_io+0x30>
    503e:	48 89 0f             	mov    %rcx,(%rdi)
    5041:	e9 78 ff ff ff       	jmp    4fbe <fwp_wake_io+0x3e>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 d3             	mov    %rdx,%rbx
    5053:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5059:	eb ab                	jmp    5006 <fwp_wake_io+0x86>
    505b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5060:	45 84 db             	test   %r11b,%r11b
    5063:	74 07                	je     506c <fwp_wake_io+0xec>
    5065:	48 89 1d 5c 67 06 00 	mov    %rbx,0x6675c(%rip)        # 6b7c8 <fwp_ready_head>
    506c:	45 84 d2             	test   %r10b,%r10b
    506f:	74 07                	je     5078 <fwp_wake_io+0xf8>
    5071:	4c 89 05 48 67 06 00 	mov    %r8,0x66748(%rip)        # 6b7c0 <fwp_ready_tail>
    5078:	5b                   	pop    %rbx
    5079:	c3                   	ret
    507a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5080:	c3                   	ret
    5081:	0f 1f 40 00          	nopl   0x0(%rax)
    5085:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    508c:	00 00 00 00 

0000000000005090 <ad_raw_free.part.0>:
    5090:	48 8d 0d 09 e1 04 00 	lea    0x4e109(%rip),%rcx        # 531a0 <ad_raw_blocks>
    5097:	31 c0                	xor    %eax,%eax
    5099:	48 89 ca             	mov    %rcx,%rdx
    509c:	eb 12                	jmp    50b0 <ad_raw_free.part.0+0x20>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	48 83 c0 01          	add    $0x1,%rax
    50a4:	48 83 c2 18          	add    $0x18,%rdx
    50a8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ae:	74 40                	je     50f0 <ad_raw_free.part.0+0x60>
    50b0:	48 3b 3a             	cmp    (%rdx),%rdi
    50b3:	75 eb                	jne    50a0 <ad_raw_free.part.0+0x10>
    50b5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50b9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50bd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50c1:	48 8d 0d b8 e0 04 00 	lea    0x4e0b8(%rip),%rcx        # 53180 <ad_raw_live>
    50c8:	8b 70 10             	mov    0x10(%rax),%esi
    50cb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50d2:	00 
    50d3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50d7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50db:	0f 11 00             	movups %xmm0,(%rax)
    50de:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    50e2:	e9 b9 e2 ff ff       	jmp    33a0 <free@plt>
    50e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    50ee:	00 00 
    50f0:	48 83 ec 08          	sub    $0x8,%rsp
    50f4:	48 8d 3d 04 a0 00 00 	lea    0xa004(%rip),%rdi        # f0ff <_IO_stdin_used+0xff>
    50fb:	e8 c0 ee ff ff       	call   3fc0 <ad_raw_fail>

0000000000005100 <fwp_tape_buffers_dispose>:
    5100:	53                   	push   %rbx
    5101:	48 89 fb             	mov    %rdi,%rbx
    5104:	48 8b 3f             	mov    (%rdi),%rdi
    5107:	48 85 ff             	test   %rdi,%rdi
    510a:	74 05                	je     5111 <fwp_tape_buffers_dispose+0x11>
    510c:	e8 7f ff ff ff       	call   5090 <ad_raw_free.part.0>
    5111:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    5115:	48 85 ff             	test   %rdi,%rdi
    5118:	74 05                	je     511f <fwp_tape_buffers_dispose+0x1f>
    511a:	e8 71 ff ff ff       	call   5090 <ad_raw_free.part.0>
    511f:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5123:	48 85 ff             	test   %rdi,%rdi
    5126:	74 05                	je     512d <fwp_tape_buffers_dispose+0x2d>
    5128:	e8 63 ff ff ff       	call   5090 <ad_raw_free.part.0>
    512d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5131:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    5138:	00 
    5139:	0f 11 03             	movups %xmm0,(%rbx)
    513c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5140:	5b                   	pop    %rbx
    5141:	c3                   	ret
    5142:	0f 1f 00             	nopl   (%rax)
    5145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    514c:	00 00 00 00 

0000000000005150 <ad_raw_realloc>:
    5150:	41 55                	push   %r13
    5152:	41 54                	push   %r12
    5154:	55                   	push   %rbp
    5155:	53                   	push   %rbx
    5156:	48 83 ec 08          	sub    $0x8,%rsp
    515a:	48 85 f6             	test   %rsi,%rsi
    515d:	0f 84 a6 00 00 00    	je     5209 <ad_raw_realloc+0xb9>
    5163:	4c 8d 25 36 e0 04 00 	lea    0x4e036(%rip),%r12        # 531a0 <ad_raw_blocks>
    516a:	48 89 f5             	mov    %rsi,%rbp
    516d:	41 89 d5             	mov    %edx,%r13d
    5170:	31 db                	xor    %ebx,%ebx
    5172:	4c 89 e0             	mov    %r12,%rax
    5175:	eb 1a                	jmp    5191 <ad_raw_realloc+0x41>
    5177:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    517e:	00 00 
    5180:	48 83 c3 01          	add    $0x1,%rbx
    5184:	48 83 c0 18          	add    $0x18,%rax
    5188:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    518f:	74 4f                	je     51e0 <ad_raw_realloc+0x90>
    5191:	48 3b 38             	cmp    (%rax),%rdi
    5194:	75 ea                	jne    5180 <ad_raw_realloc+0x30>
    5196:	48 85 ff             	test   %rdi,%rdi
    5199:	74 0b                	je     51a6 <ad_raw_realloc+0x56>
    519b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    519f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51a4:	75 57                	jne    51fd <ad_raw_realloc+0xad>
    51a6:	48 89 ee             	mov    %rbp,%rsi
    51a9:	e8 f2 e3 ff ff       	call   35a0 <realloc@plt>
    51ae:	49 89 c2             	mov    %rax,%r10
    51b1:	48 85 c0             	test   %rax,%rax
    51b4:	74 16                	je     51cc <ad_raw_realloc+0x7c>
    51b6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51ba:	44 89 e9             	mov    %r13d,%ecx
    51bd:	48 89 ea             	mov    %rbp,%rdx
    51c0:	4c 89 d6             	mov    %r10,%rsi
    51c3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51c7:	e8 f4 e9 ff ff       	call   3bc0 <ad_raw_record>
    51cc:	48 83 c4 08          	add    $0x8,%rsp
    51d0:	4c 89 d0             	mov    %r10,%rax
    51d3:	5b                   	pop    %rbx
    51d4:	5d                   	pop    %rbp
    51d5:	41 5c                	pop    %r12
    51d7:	41 5d                	pop    %r13
    51d9:	c3                   	ret
    51da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51e0:	48 85 ff             	test   %rdi,%rdi
    51e3:	48 8d 05 2a 9f 00 00 	lea    0x9f2a(%rip),%rax        # f114 <_IO_stdin_used+0x114>
    51ea:	48 8d 15 0e 9f 00 00 	lea    0x9f0e(%rip),%rdx        # f0ff <_IO_stdin_used+0xff>
    51f1:	48 0f 45 c2          	cmovne %rdx,%rax
    51f5:	48 89 c7             	mov    %rax,%rdi
    51f8:	e8 c3 ed ff ff       	call   3fc0 <ad_raw_fail>
    51fd:	48 8d 3d 46 9f 00 00 	lea    0x9f46(%rip),%rdi        # f14a <_IO_stdin_used+0x14a>
    5204:	e8 b7 ed ff ff       	call   3fc0 <ad_raw_fail>
    5209:	48 8d 3d 1f 9f 00 00 	lea    0x9f1f(%rip),%rdi        # f12f <_IO_stdin_used+0x12f>
    5210:	e8 ab ed ff ff       	call   3fc0 <ad_raw_fail>
    5215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    521c:	00 00 00 00 

0000000000005220 <fwp_tape_buffers_release>:
    5220:	f3 0f 1e fa          	endbr64
    5224:	53                   	push   %rbx
    5225:	48 89 fb             	mov    %rdi,%rbx
    5228:	48 83 ec 10          	sub    $0x10,%rsp
    522c:	48 8b 47 18          	mov    0x18(%rdi),%rax
    5230:	48 85 c0             	test   %rax,%rax
    5233:	0f 88 c7 00 00 00    	js     5300 <fwp_tape_buffers_release+0xe0>
    5239:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    523d:	48 85 d2             	test   %rdx,%rdx
    5240:	0f 88 ba 00 00 00    	js     5300 <fwp_tape_buffers_release+0xe0>
    5246:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    524c:	0f 87 ae 00 00 00    	ja     5300 <fwp_tape_buffers_release+0xe0>
    5252:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5256:	b8 00 00 08 00       	mov    $0x80000,%eax
    525b:	48 c1 e1 03          	shl    $0x3,%rcx
    525f:	48 29 c8             	sub    %rcx,%rax
    5262:	48 c1 e8 03          	shr    $0x3,%rax
    5266:	48 39 d0             	cmp    %rdx,%rax
    5269:	0f 82 91 00 00 00    	jb     5300 <fwp_tape_buffers_release+0xe0>
    526f:	48 8d 3d ec 9e 00 00 	lea    0x9eec(%rip),%rdi        # f162 <_IO_stdin_used+0x162>
    5276:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    527b:	48 89 14 24          	mov    %rdx,(%rsp)
    527f:	e8 fc e0 ff ff       	call   3380 <getenv@plt>
    5284:	48 8b 14 24          	mov    (%rsp),%rdx
    5288:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    528d:	48 85 c0             	test   %rax,%rax
    5290:	74 09                	je     529b <fwp_tape_buffers_release+0x7b>
    5292:	80 38 30             	cmpb   $0x30,(%rax)
    5295:	0f 84 f5 00 00 00    	je     5390 <fwp_tape_buffers_release+0x170>
    529b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    529f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52a3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52a9:	77 61                	ja     530c <fwp_tape_buffers_release+0xec>
    52ab:	48 8d 3d ee dd 01 00 	lea    0x1ddee(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    52b2:	48 89 34 24          	mov    %rsi,(%rsp)
    52b6:	e8 45 fe ff ff       	call   5100 <fwp_tape_buffers_dispose>
    52bb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52bf:	48 8b 34 24          	mov    (%rsp),%rsi
    52c3:	0f 29 05 d6 dd 01 00 	movaps %xmm0,0x1ddd6(%rip)        # 230a0 <fwp_tape_workspace>
    52ca:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52cf:	48 89 35 b2 dd 01 00 	mov    %rsi,0x1ddb2(%rip)        # 23088 <fwp_tape_cached_bytes>
    52d6:	0f 29 05 d3 dd 01 00 	movaps %xmm0,0x1ddd3(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    52dd:	48 8b 43 20          	mov    0x20(%rbx),%rax
    52e1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52e5:	48 89 05 d4 dd 01 00 	mov    %rax,0x1ddd4(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    52ec:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
    52f3:	00 
    52f4:	0f 11 03             	movups %xmm0,(%rbx)
    52f7:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    52fb:	eb 1e                	jmp    531b <fwp_tape_buffers_release+0xfb>
    52fd:	0f 1f 00             	nopl   (%rax)
    5300:	48 8d 3d 5b 9e 00 00 	lea    0x9e5b(%rip),%rdi        # f162 <_IO_stdin_used+0x162>
    5307:	e8 74 e0 ff ff       	call   3380 <getenv@plt>
    530c:	48 89 df             	mov    %rbx,%rdi
    530f:	e8 ec fd ff ff       	call   5100 <fwp_tape_buffers_dispose>
    5314:	48 8b 35 6d dd 01 00 	mov    0x1dd6d(%rip),%rsi        # 23088 <fwp_tape_cached_bytes>
    531b:	48 6b 15 ad dd 01 00 	imul   $0x58,0x1ddad(%rip),%rdx        # 230d0 <fwp_tapes_cap>
    5322:	58 
    5323:	48 3b 15 56 de 04 00 	cmp    0x4de56(%rip),%rdx        # 53180 <ad_raw_live>
    532a:	75 73                	jne    539f <fwp_tape_buffers_release+0x17f>
    532c:	48 8b 05 55 de 04 00 	mov    0x4de55(%rip),%rax        # 53188 <ad_raw_live+0x8>
    5333:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5337:	48 01 d0             	add    %rdx,%rax
    533a:	48 03 05 4f de 04 00 	add    0x4de4f(%rip),%rax        # 53190 <ad_raw_live+0x10>
    5341:	48 03 05 50 de 04 00 	add    0x4de50(%rip),%rax        # 53198 <ad_raw_live+0x18>
    5348:	48 39 c8             	cmp    %rcx,%rax
    534b:	72 52                	jb     539f <fwp_tape_buffers_release+0x17f>
    534d:	48 8b 0d 9c dd 01 00 	mov    0x1dd9c(%rip),%rcx        # 230f0 <ad_raw_checkpoint_count>
    5354:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    535b:	74 4e                	je     53ab <fwp_tape_buffers_release+0x18b>
    535d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5361:	48 29 d0             	sub    %rdx,%rax
    5364:	48 89 3d 85 dd 01 00 	mov    %rdi,0x1dd85(%rip)        # 230f0 <ad_raw_checkpoint_count>
    536b:	48 29 f0             	sub    %rsi,%rax
    536e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5372:	48 8d 0d 87 dd 01 00 	lea    0x1dd87(%rip),%rcx        # 23100 <ad_raw_checkpoints>
    5379:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    537d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5382:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5387:	48 83 c4 10          	add    $0x10,%rsp
    538b:	5b                   	pop    %rbx
    538c:	c3                   	ret
    538d:	0f 1f 00             	nopl   (%rax)
    5390:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5394:	0f 84 72 ff ff ff    	je     530c <fwp_tape_buffers_release+0xec>
    539a:	e9 fc fe ff ff       	jmp    529b <fwp_tape_buffers_release+0x7b>
    539f:	48 8d 3d c2 a5 00 00 	lea    0xa5c2(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    53a6:	e8 15 ec ff ff       	call   3fc0 <ad_raw_fail>
    53ab:	48 8d 3d c1 9d 00 00 	lea    0x9dc1(%rip),%rdi        # f173 <_IO_stdin_used+0x173>
    53b2:	e8 09 ec ff ff       	call   3fc0 <ad_raw_fail>
    53b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53be:	00 00 

00000000000053c0 <fwp_poll_events>:
    53c0:	53                   	push   %rbx
    53c1:	48 83 ec 20          	sub    $0x20,%rsp
    53c5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53cc:	00 00 
    53ce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    53d3:	31 c0                	xor    %eax,%eax
    53d5:	e8 a6 f1 ff ff       	call   4580 <fwp_now_ns>
    53da:	48 8b 1d d7 63 06 00 	mov    0x663d7(%rip),%rbx        # 6b7b8 <fwp_timers>
    53e1:	48 85 db             	test   %rbx,%rbx
    53e4:	0f 84 d6 00 00 00    	je     54c0 <fwp_poll_events+0x100>
    53ea:	48 89 c6             	mov    %rax,%rsi
    53ed:	48 89 da             	mov    %rbx,%rdx
    53f0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    53f7:	eb 16                	jmp    540f <fwp_poll_events+0x4f>
    53f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5400:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5407:	48 89 c8             	mov    %rcx,%rax
    540a:	48 85 d2             	test   %rdx,%rdx
    540d:	74 31                	je     5440 <fwp_poll_events+0x80>
    540f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5413:	48 85 c0             	test   %rax,%rax
    5416:	78 e8                	js     5400 <fwp_poll_events+0x40>
    5418:	48 39 c1             	cmp    %rax,%rcx
    541b:	7c e3                	jl     5400 <fwp_poll_events+0x40>
    541d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5424:	48 85 d2             	test   %rdx,%rdx
    5427:	74 1c                	je     5445 <fwp_poll_events+0x85>
    5429:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    542d:	48 39 c1             	cmp    %rax,%rcx
    5430:	7c ce                	jl     5400 <fwp_poll_events+0x40>
    5432:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5439:	48 85 d2             	test   %rdx,%rdx
    543c:	75 d1                	jne    540f <fwp_poll_events+0x4f>
    543e:	66 90                	xchg   %ax,%ax
    5440:	48 85 c0             	test   %rax,%rax
    5443:	78 7b                	js     54c0 <fwp_poll_events+0x100>
    5445:	48 29 f0             	sub    %rsi,%rax
    5448:	48 89 c1             	mov    %rax,%rcx
    544b:	48 85 c0             	test   %rax,%rax
    544e:	0f 8e 9c 00 00 00    	jle    54f0 <fwp_poll_events+0x130>
    5454:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    545b:	de 1b 43 
    545e:	48 f7 ea             	imul   %rdx
    5461:	48 89 c8             	mov    %rcx,%rax
    5464:	48 c1 f8 3f          	sar    $0x3f,%rax
    5468:	48 c1 fa 12          	sar    $0x12,%rdx
    546c:	48 29 c2             	sub    %rax,%rdx
    546f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5476:	48 39 c1             	cmp    %rax,%rcx
    5479:	0f 95 c0             	setne  %al
    547c:	0f b6 c0             	movzbl %al,%eax
    547f:	48 01 d0             	add    %rdx,%rax
    5482:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5488:	0f 8f 32 01 00 00    	jg     55c0 <fwp_poll_events+0x200>
    548e:	48 85 c0             	test   %rax,%rax
    5491:	74 5d                	je     54f0 <fwp_poll_events+0x130>
    5493:	89 c1                	mov    %eax,%ecx
    5495:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    549c:	48 c1 e9 26          	shr    $0x26,%rcx
    54a0:	48 63 d1             	movslq %ecx,%rdx
    54a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54a9:	29 c8                	sub    %ecx,%eax
    54ab:	48 98                	cltq
    54ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54b4:	e9 11 01 00 00       	jmp    55ca <fwp_poll_events+0x20a>
    54b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54c0:	e8 fb e7 ff ff       	call   3cc0 <fwp_flush>
    54c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    54ca:	be 01 00 00 00       	mov    $0x1,%esi
    54cf:	48 8b 0d 6a db 00 00 	mov    0xdb6a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    54d6:	48 8d 3d bb a4 00 00 	lea    0xa4bb(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    54dd:	e8 5e e1 ff ff       	call   3640 <fwrite@plt>
    54e2:	bf 65 00 00 00       	mov    $0x65,%edi
    54e7:	e8 44 e1 ff ff       	call   3630 <exit@plt>
    54ec:	0f 1f 40 00          	nopl   0x0(%rax)
    54f0:	e8 8b f0 ff ff       	call   4580 <fwp_now_ns>
    54f5:	48 89 c1             	mov    %rax,%rcx
    54f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    54fc:	eb 44                	jmp    5542 <fwp_poll_events+0x182>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5504:	75 33                	jne    5539 <fwp_poll_events+0x179>
    5506:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    550a:	75 2d                	jne    5539 <fwp_poll_events+0x179>
    550c:	48 8b 05 ad 62 06 00 	mov    0x662ad(%rip),%rax        # 6b7c0 <fwp_ready_tail>
    5513:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5517:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    551e:	00 00 00 00 
    5522:	48 85 c0             	test   %rax,%rax
    5525:	0f 84 05 01 00 00    	je     5630 <fwp_poll_events+0x270>
    552b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5532:	48 89 15 87 62 06 00 	mov    %rdx,0x66287(%rip)        # 6b7c0 <fwp_ready_tail>
    5539:	48 85 db             	test   %rbx,%rbx
    553c:	0f 84 be 00 00 00    	je     5600 <fwp_poll_events+0x240>
    5542:	48 89 da             	mov    %rbx,%rdx
    5545:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    554c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5550:	7f e7                	jg     5539 <fwp_poll_events+0x179>
    5552:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5556:	74 2e                	je     5586 <fwp_poll_events+0x1c6>
    5558:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    555f:	48 85 c0             	test   %rax,%rax
    5562:	0f 84 b8 00 00 00    	je     5620 <fwp_poll_events+0x260>
    5568:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    556f:	48 85 db             	test   %rbx,%rbx
    5572:	74 07                	je     557b <fwp_poll_events+0x1bb>
    5574:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    557b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    557f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5586:	48 8b 42 60          	mov    0x60(%rdx),%rax
    558a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    558e:	48 85 c0             	test   %rax,%rax
    5591:	0f 84 69 ff ff ff    	je     5500 <fwp_poll_events+0x140>
    5597:	48 39 c8             	cmp    %rcx,%rax
    559a:	0f 8f 60 ff ff ff    	jg     5500 <fwp_poll_events+0x140>
    55a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55a4:	0f 85 56 ff ff ff    	jne    5500 <fwp_poll_events+0x140>
    55aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ae:	75 89                	jne    5539 <fwp_poll_events+0x179>
    55b0:	48 89 d7             	mov    %rdx,%rdi
    55b3:	e8 38 eb ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    55b8:	e9 43 ff ff ff       	jmp    5500 <fwp_poll_events+0x140>
    55bd:	0f 1f 00             	nopl   (%rax)
    55c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    55c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    55ca:	48 89 e7             	mov    %rsp,%rdi
    55cd:	31 f6                	xor    %esi,%esi
    55cf:	48 89 14 24          	mov    %rdx,(%rsp)
    55d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    55d8:	e8 a3 de ff ff       	call   3480 <nanosleep@plt>
    55dd:	48 8b 1d d4 61 06 00 	mov    0x661d4(%rip),%rbx        # 6b7b8 <fwp_timers>
    55e4:	e8 97 ef ff ff       	call   4580 <fwp_now_ns>
    55e9:	48 89 c1             	mov    %rax,%rcx
    55ec:	48 85 db             	test   %rbx,%rbx
    55ef:	0f 85 03 ff ff ff    	jne    54f8 <fwp_poll_events+0x138>
    55f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    55fc:	00 00 00 00 
    5600:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5605:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    560c:	00 00 
    560e:	75 2c                	jne    563c <fwp_poll_events+0x27c>
    5610:	48 83 c4 20          	add    $0x20,%rsp
    5614:	5b                   	pop    %rbx
    5615:	c3                   	ret
    5616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    561d:	00 00 00 
    5620:	48 89 1d 91 61 06 00 	mov    %rbx,0x66191(%rip)        # 6b7b8 <fwp_timers>
    5627:	e9 43 ff ff ff       	jmp    556f <fwp_poll_events+0x1af>
    562c:	0f 1f 40 00          	nopl   0x0(%rax)
    5630:	48 89 15 91 61 06 00 	mov    %rdx,0x66191(%rip)        # 6b7c8 <fwp_ready_head>
    5637:	e9 f6 fe ff ff       	jmp    5532 <fwp_poll_events+0x172>
    563c:	e8 ff dd ff ff       	call   3440 <__stack_chk_fail@plt>
    5641:	0f 1f 40 00          	nopl   0x0(%rax)
    5645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    564c:	00 00 00 00 

0000000000005650 <fwp_rc_wide_dup>:
    5650:	48 89 fa             	mov    %rdi,%rdx
    5653:	48 8d 35 a6 61 06 00 	lea    0x661a6(%rip),%rsi        # 6b800 <fwp_heap>
    565a:	48 83 ec 18          	sub    $0x18,%rsp
    565e:	48 89 f9             	mov    %rdi,%rcx
    5661:	48 c1 ea 11          	shr    $0x11,%rdx
    5665:	48 31 fa             	xor    %rdi,%rdx
    5668:	48 89 d0             	mov    %rdx,%rax
    566b:	48 c1 e8 09          	shr    $0x9,%rax
    566f:	48 31 c2             	xor    %rax,%rdx
    5672:	0f b6 d2             	movzbl %dl,%edx
    5675:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    567c:	00 
    567d:	49 8b 00             	mov    (%r8),%rax
    5680:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5687:	00 00 
    5689:	75 21                	jne    56ac <fwp_rc_wide_dup+0x5c>
    568b:	e9 98 00 00 00       	jmp    5728 <fwp_rc_wide_dup+0xd8>
    5690:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    569c:	00 00 00 00 
    56a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56a4:	48 85 d2             	test   %rdx,%rdx
    56a7:	74 2f                	je     56d8 <fwp_rc_wide_dup+0x88>
    56a9:	48 89 d0             	mov    %rdx,%rax
    56ac:	48 3b 08             	cmp    (%rax),%rcx
    56af:	75 ef                	jne    56a0 <fwp_rc_wide_dup+0x50>
    56b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56b4:	74 7c                	je     5732 <fwp_rc_wide_dup+0xe2>
    56b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56be:	0f 84 91 00 00 00    	je     5755 <fwp_rc_wide_dup+0x105>
    56c4:	48 83 c2 01          	add    $0x1,%rdx
    56c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    56cc:	48 83 c4 18          	add    $0x18,%rsp
    56d0:	c3                   	ret
    56d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    56dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56df:	75 68                	jne    5749 <fwp_rc_wide_dup+0xf9>
    56e1:	bf 18 00 00 00       	mov    $0x18,%edi
    56e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    56eb:	4c 89 04 24          	mov    %r8,(%rsp)
    56ef:	e8 8c de ff ff       	call   3580 <malloc@plt>
    56f4:	4c 8b 04 24          	mov    (%rsp),%r8
    56f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    56fd:	48 85 c0             	test   %rax,%rax
    5700:	74 5f                	je     5761 <fwp_rc_wide_dup+0x111>
    5702:	48 89 08             	mov    %rcx,(%rax)
    5705:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    570c:	00 
    570d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5714:	00 
    5715:	49 89 00             	mov    %rax,(%r8)
    5718:	c6 01 ff             	movb   $0xff,(%rcx)
    571b:	48 83 05 25 7d 06 00 	addq   $0x1,0x67d25(%rip)        # 6d448 <fwp_heap+0x1c48>
    5722:	01 
    5723:	48 83 c4 18          	add    $0x18,%rsp
    5727:	c3                   	ret
    5728:	80 3f fe             	cmpb   $0xfe,(%rdi)
    572b:	75 13                	jne    5740 <fwp_rc_wide_dup+0xf0>
    572d:	48 85 c0             	test   %rax,%rax
    5730:	74 af                	je     56e1 <fwp_rc_wide_dup+0x91>
    5732:	48 8d 3d 8f a2 00 00 	lea    0xa28f(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    5739:	e8 d2 ec ff ff       	call   4410 <fwp_trap>
    573e:	66 90                	xchg   %ax,%ax
    5740:	48 85 c0             	test   %rax,%rax
    5743:	0f 85 6d ff ff ff    	jne    56b6 <fwp_rc_wide_dup+0x66>
    5749:	48 8d 3d a0 a2 00 00 	lea    0xa2a0(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5750:	e8 bb ec ff ff       	call   4410 <fwp_trap>
    5755:	48 8d 3d 34 9a 00 00 	lea    0x9a34(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    575c:	e8 af ec ff ff       	call   4410 <fwp_trap>
    5761:	e8 8a e6 ff ff       	call   3df0 <fwp_heap_oom>
    5766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    576d:	00 00 00 

0000000000005770 <fwp_rc_forget_slot>:
    5770:	80 3f ff             	cmpb   $0xff,(%rdi)
    5773:	74 0b                	je     5780 <fwp_rc_forget_slot+0x10>
    5775:	c3                   	ret
    5776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    577d:	00 00 00 
    5780:	48 89 f8             	mov    %rdi,%rax
    5783:	48 83 ec 08          	sub    $0x8,%rsp
    5787:	48 89 fa             	mov    %rdi,%rdx
    578a:	48 c1 e8 11          	shr    $0x11,%rax
    578e:	48 31 f8             	xor    %rdi,%rax
    5791:	48 89 c1             	mov    %rax,%rcx
    5794:	48 c1 e9 09          	shr    $0x9,%rcx
    5798:	48 31 c8             	xor    %rcx,%rax
    579b:	48 8d 0d 5e 60 06 00 	lea    0x6605e(%rip),%rcx        # 6b800 <fwp_heap>
    57a2:	0f b6 c0             	movzbl %al,%eax
    57a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ac:	00 
    57ad:	48 85 ff             	test   %rdi,%rdi
    57b0:	74 3c                	je     57ee <fwp_rc_forget_slot+0x7e>
    57b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57b9:	00 
    57ba:	48 8b 01             	mov    (%rcx),%rax
    57bd:	eb 11                	jmp    57d0 <fwp_rc_forget_slot+0x60>
    57bf:	90                   	nop
    57c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    57c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    57c8:	48 85 ff             	test   %rdi,%rdi
    57cb:	74 21                	je     57ee <fwp_rc_forget_slot+0x7e>
    57cd:	48 89 f8             	mov    %rdi,%rax
    57d0:	48 3b 10             	cmp    (%rax),%rdx
    57d3:	75 eb                	jne    57c0 <fwp_rc_forget_slot+0x50>
    57d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    57d9:	48 89 01             	mov    %rax,(%rcx)
    57dc:	e8 bf db ff ff       	call   33a0 <free@plt>
    57e1:	48 83 2d 5f 7c 06 00 	subq   $0x1,0x67c5f(%rip)        # 6d448 <fwp_heap+0x1c48>
    57e8:	01 
    57e9:	48 83 c4 08          	add    $0x8,%rsp
    57ed:	c3                   	ret
    57ee:	48 8d 3d fb a1 00 00 	lea    0xa1fb(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    57f5:	e8 16 ec ff ff       	call   4410 <fwp_trap>
    57fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005800 <fwp_rc_prepare_chunk>:
    5800:	48 83 3d 40 7c 06 00 	cmpq   $0x0,0x67c40(%rip)        # 6d448 <fwp_heap+0x1c48>
    5807:	00 
    5808:	41 54                	push   %r12
    580a:	49 89 f4             	mov    %rsi,%r12
    580d:	55                   	push   %rbp
    580e:	48 89 fd             	mov    %rdi,%rbp
    5811:	53                   	push   %rbx
    5812:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5815:	0f 84 7d 00 00 00    	je     5898 <fwp_rc_prepare_chunk+0x98>
    581b:	31 db                	xor    %ebx,%ebx
    581d:	85 c0                	test   %eax,%eax
    581f:	75 5f                	jne    5880 <fwp_rc_prepare_chunk+0x80>
    5821:	48 85 f6             	test   %rsi,%rsi
    5824:	74 7c                	je     58a2 <fwp_rc_prepare_chunk+0xa2>
    5826:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    582a:	e8 71 db ff ff       	call   33a0 <free@plt>
    582f:	90                   	nop
    5830:	be 01 00 00 00       	mov    $0x1,%esi
    5835:	4c 89 e7             	mov    %r12,%rdi
    5838:	e8 c3 dc ff ff       	call   3500 <calloc@plt>
    583d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5841:	48 85 c0             	test   %rax,%rax
    5844:	0f 85 87 00 00 00    	jne    58d1 <fwp_rc_prepare_chunk+0xd1>
    584a:	e8 a1 e5 ff ff       	call   3df0 <fwp_heap_oom>
    584f:	90                   	nop
    5850:	e8 1b ff ff ff       	call   5770 <fwp_rc_forget_slot>
    5855:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5858:	48 83 c3 01          	add    $0x1,%rbx
    585c:	48 39 c3             	cmp    %rax,%rbx
    585f:	73 37                	jae    5898 <fwp_rc_prepare_chunk+0x98>
    5861:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5868:	00 00 
    586a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5871:	00 00 00 00 
    5875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    587c:	00 00 00 00 
    5880:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5884:	48 01 df             	add    %rbx,%rdi
    5887:	80 3f ff             	cmpb   $0xff,(%rdi)
    588a:	74 c4                	je     5850 <fwp_rc_prepare_chunk+0x50>
    588c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    588f:	48 83 c3 01          	add    $0x1,%rbx
    5893:	48 39 c3             	cmp    %rax,%rbx
    5896:	72 e8                	jb     5880 <fwp_rc_prepare_chunk+0x80>
    5898:	49 39 c4             	cmp    %rax,%r12
    589b:	75 13                	jne    58b0 <fwp_rc_prepare_chunk+0xb0>
    589d:	4d 85 e4             	test   %r12,%r12
    58a0:	75 46                	jne    58e8 <fwp_rc_prepare_chunk+0xe8>
    58a2:	5b                   	pop    %rbx
    58a3:	5d                   	pop    %rbp
    58a4:	41 5c                	pop    %r12
    58a6:	c3                   	ret
    58a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ae:	00 00 
    58b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58b4:	48 29 05 95 7b 06 00 	sub    %rax,0x67b95(%rip)        # 6d450 <fwp_heap+0x1c50>
    58bb:	e8 e0 da ff ff       	call   33a0 <free@plt>
    58c0:	4d 85 e4             	test   %r12,%r12
    58c3:	0f 85 67 ff ff ff    	jne    5830 <fwp_rc_prepare_chunk+0x30>
    58c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    58d0:	00 
    58d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    58d5:	5b                   	pop    %rbx
    58d6:	4c 01 25 73 7b 06 00 	add    %r12,0x67b73(%rip)        # 6d450 <fwp_heap+0x1c50>
    58dd:	5d                   	pop    %rbp
    58de:	41 5c                	pop    %r12
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58ec:	5b                   	pop    %rbx
    58ed:	4c 89 e2             	mov    %r12,%rdx
    58f0:	31 f6                	xor    %esi,%esi
    58f2:	5d                   	pop    %rbp
    58f3:	41 5c                	pop    %r12
    58f5:	e9 a6 db ff ff       	jmp    34a0 <memset@plt>
    58fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005900 <fwp_heap_refill>:
    5900:	41 56                	push   %r14
    5902:	41 89 d6             	mov    %edx,%r14d
    5905:	41 55                	push   %r13
    5907:	41 89 f5             	mov    %esi,%r13d
    590a:	41 54                	push   %r12
    590c:	49 89 fc             	mov    %rdi,%r12
    590f:	bf 01 00 00 00       	mov    $0x1,%edi
    5914:	55                   	push   %rbp
    5915:	53                   	push   %rbx
    5916:	e8 15 e5 ff ff       	call   3e30 <fwp_heap_chunks>
    591b:	48 89 c3             	mov    %rax,%rbx
    591e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5922:	48 8b 05 cf 72 06 00 	mov    0x672cf(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    5929:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    592d:	48 8d 05 cc 5e 06 00 	lea    0x65ecc(%rip),%rax        # 6b800 <fwp_heap>
    5934:	31 d2                	xor    %edx,%edx
    5936:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    593a:	48 89 ef             	mov    %rbp,%rdi
    593d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5941:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5945:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    594c:	00 
    594d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5952:	f7 f1                	div    %ecx
    5954:	31 d2                	xor    %edx,%edx
    5956:	66 0f 6e c1          	movd   %ecx,%xmm0
    595a:	66 0f 6e c8          	movd   %eax,%xmm1
    595e:	89 c6                	mov    %eax,%esi
    5960:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5965:	48 01 c8             	add    %rcx,%rax
    5968:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    596c:	48 f7 f1             	div    %rcx
    596f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5974:	89 45 18             	mov    %eax,0x18(%rbp)
    5977:	e8 84 fe ff ff       	call   5800 <fwp_rc_prepare_chunk>
    597c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    597f:	48 89 d8             	mov    %rbx,%rax
    5982:	48 c1 e0 10          	shl    $0x10,%rax
    5986:	48 03 05 23 72 06 00 	add    0x67223(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    598d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5991:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5996:	8b 55 08             	mov    0x8(%rbp),%edx
    5999:	48 0f af d1          	imul   %rcx,%rdx
    599d:	48 01 c2             	add    %rax,%rdx
    59a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59a5:	5b                   	pop    %rbx
    59a6:	5d                   	pop    %rbp
    59a7:	41 5c                	pop    %r12
    59a9:	41 5d                	pop    %r13
    59ab:	41 5e                	pop    %r14
    59ad:	c3                   	ret
    59ae:	66 90                	xchg   %ax,%ax

00000000000059b0 <fwp_mem_free>:
    59b0:	48 85 ff             	test   %rdi,%rdi
    59b3:	0f 84 17 02 00 00    	je     5bd0 <fwp_mem_free+0x220>
    59b9:	48 8b 35 f0 71 06 00 	mov    0x671f0(%rip),%rsi        # 6cbb0 <fwp_heap+0x13b0>
    59c0:	48 8b 05 11 72 06 00 	mov    0x67211(%rip),%rax        # 6cbd8 <fwp_heap+0x13d8>
    59c7:	48 89 fa             	mov    %rdi,%rdx
    59ca:	48 29 f2             	sub    %rsi,%rdx
    59cd:	48 c1 e0 10          	shl    $0x10,%rax
    59d1:	48 39 c2             	cmp    %rax,%rdx
    59d4:	0f 83 f6 01 00 00    	jae    5bd0 <fwp_mem_free+0x220>
    59da:	49 89 d1             	mov    %rdx,%r9
    59dd:	49 c1 e9 10          	shr    $0x10,%r9
    59e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    59e5:	48 c1 e0 03          	shl    $0x3,%rax
    59e9:	49 89 c0             	mov    %rax,%r8
    59ec:	4c 03 05 05 72 06 00 	add    0x67205(%rip),%r8        # 6cbf8 <fwp_heap+0x13f8>
    59f3:	0f 84 d7 01 00 00    	je     5bd0 <fwp_mem_free+0x220>
    59f9:	48 83 ec 38          	sub    $0x38,%rsp
    59fd:	48 89 f9             	mov    %rdi,%rcx
    5a00:	41 0f b6 38          	movzbl (%r8),%edi
    5a04:	40 80 ff 01          	cmp    $0x1,%dil
    5a08:	74 16                	je     5a20 <fwp_mem_free+0x70>
    5a0a:	40 80 ff 02          	cmp    $0x2,%dil
    5a0e:	0f 84 94 00 00 00    	je     5aa8 <fwp_mem_free+0xf8>
    5a14:	48 83 c4 38          	add    $0x38,%rsp
    5a18:	c3                   	ret
    5a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a20:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a24:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a29:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a2e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a32:	4d 85 d2             	test   %r10,%r10
    5a35:	74 1d                	je     5a54 <fwp_mem_free+0xa4>
    5a37:	0f b7 c1             	movzwl %cx,%eax
    5a3a:	31 d2                	xor    %edx,%edx
    5a3c:	48 f7 f7             	div    %rdi
    5a3f:	49 01 c2             	add    %rax,%r10
    5a42:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a46:	0f 84 44 01 00 00    	je     5b90 <fwp_mem_free+0x1e0>
    5a4c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a50:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a54:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a5b:	49 63 c1             	movslq %r9d,%rax
    5a5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5a62:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5a66:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5a6b:	f2 0f 58 05 cd 71 06 	addsd  0x671cd(%rip),%xmm0        # 6cc40 <fwp_heap+0x1440>
    5a72:	00 
    5a73:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5a77:	48 8d 05 82 5d 06 00 	lea    0x65d82(%rip),%rax        # 6b800 <fwp_heap>
    5a7e:	48 01 d0             	add    %rdx,%rax
    5a81:	48 8b 10             	mov    (%rax),%rdx
    5a84:	48 f7 d2             	not    %rdx
    5a87:	48 89 11             	mov    %rdx,(%rcx)
    5a8a:	48 89 08             	mov    %rcx,(%rax)
    5a8d:	48 29 3d 8c 71 06 00 	sub    %rdi,0x6718c(%rip)        # 6cc20 <fwp_heap+0x1420>
    5a94:	f2 0f 11 05 a4 71 06 	movsd  %xmm0,0x671a4(%rip)        # 6cc40 <fwp_heap+0x1440>
    5a9b:	00 
    5a9c:	48 83 c4 38          	add    $0x38,%rsp
    5aa0:	c3                   	ret
    5aa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5aa8:	66 31 d2             	xor    %dx,%dx
    5aab:	48 01 d6             	add    %rdx,%rsi
    5aae:	48 39 f1             	cmp    %rsi,%rcx
    5ab1:	0f 85 5d ff ff ff    	jne    5a14 <fwp_mem_free+0x64>
    5ab7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5abb:	48 29 15 5e 71 06 00 	sub    %rdx,0x6715e(%rip)        # 6cc20 <fwp_heap+0x1420>
    5ac2:	48 85 d2             	test   %rdx,%rdx
    5ac5:	0f 88 a5 00 00 00    	js     5b70 <fwp_mem_free+0x1c0>
    5acb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5acf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5ad4:	f2 0f 58 05 64 71 06 	addsd  0x67164(%rip),%xmm0        # 6cc40 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ae0:	f2 0f 11 05 58 71 06 	movsd  %xmm0,0x67158(%rip)        # 6cc40 <fwp_heap+0x1440>
    5ae7:	00 
    5ae8:	48 85 d2             	test   %rdx,%rdx
    5aeb:	74 0c                	je     5af9 <fwp_mem_free+0x149>
    5aed:	80 3a ff             	cmpb   $0xff,(%rdx)
    5af0:	0f 84 db 00 00 00    	je     5bd1 <fwp_mem_free+0x221>
    5af6:	c6 02 00             	movb   $0x0,(%rdx)
    5af9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5afd:	48 85 c9             	test   %rcx,%rcx
    5b00:	74 3e                	je     5b40 <fwp_mem_free+0x190>
    5b02:	48 8b 15 ef 70 06 00 	mov    0x670ef(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    5b09:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b0d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b11:	48 01 d0             	add    %rdx,%rax
    5b14:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b18:	48 89 d6             	mov    %rdx,%rsi
    5b1b:	48 29 c6             	sub    %rax,%rsi
    5b1e:	83 e6 08             	and    $0x8,%esi
    5b21:	74 0d                	je     5b30 <fwp_mem_free+0x180>
    5b23:	c6 00 00             	movb   $0x0,(%rax)
    5b26:	48 83 c0 28          	add    $0x28,%rax
    5b2a:	48 39 c2             	cmp    %rax,%rdx
    5b2d:	74 11                	je     5b40 <fwp_mem_free+0x190>
    5b2f:	90                   	nop
    5b30:	c6 00 00             	movb   $0x0,(%rax)
    5b33:	48 83 c0 50          	add    $0x50,%rax
    5b37:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b3b:	48 39 c2             	cmp    %rax,%rdx
    5b3e:	75 f0                	jne    5b30 <fwp_mem_free+0x180>
    5b40:	48 01 0d e9 70 06 00 	add    %rcx,0x670e9(%rip)        # 6cc30 <fwp_heap+0x1430>
    5b47:	4c 3b 0d a2 70 06 00 	cmp    0x670a2(%rip),%r9        # 6cbf0 <fwp_heap+0x13f0>
    5b4e:	73 07                	jae    5b57 <fwp_mem_free+0x1a7>
    5b50:	4c 89 0d 99 70 06 00 	mov    %r9,0x67099(%rip)        # 6cbf0 <fwp_heap+0x13f0>
    5b57:	4c 3b 0d 8a 70 06 00 	cmp    0x6708a(%rip),%r9        # 6cbe8 <fwp_heap+0x13e8>
    5b5e:	0f 83 b0 fe ff ff    	jae    5a14 <fwp_mem_free+0x64>
    5b64:	4c 89 0d 7d 70 06 00 	mov    %r9,0x6707d(%rip)        # 6cbe8 <fwp_heap+0x13e8>
    5b6b:	e9 a4 fe ff ff       	jmp    5a14 <fwp_mem_free+0x64>
    5b70:	48 89 d1             	mov    %rdx,%rcx
    5b73:	83 e2 01             	and    $0x1,%edx
    5b76:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b7a:	48 d1 e9             	shr    $1,%rcx
    5b7d:	48 09 d1             	or     %rdx,%rcx
    5b80:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5b85:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5b89:	e9 46 ff ff ff       	jmp    5ad4 <fwp_mem_free+0x124>
    5b8e:	66 90                	xchg   %ax,%ax
    5b90:	4c 89 d7             	mov    %r10,%rdi
    5b93:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5b98:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5b9d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5ba2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5ba6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5bab:	e8 c0 fb ff ff       	call   5770 <fwp_rc_forget_slot>
    5bb0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bb5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bbf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5bc4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5bc9:	e9 7e fe ff ff       	jmp    5a4c <fwp_mem_free+0x9c>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	c3                   	ret
    5bd1:	48 89 d7             	mov    %rdx,%rdi
    5bd4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5bd9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5bde:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5be3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5be8:	e8 83 fb ff ff       	call   5770 <fwp_rc_forget_slot>
    5bed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5bf2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5bf7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5bfc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c01:	e9 f0 fe ff ff       	jmp    5af6 <fwp_mem_free+0x146>
    5c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c0d:	00 00 00 

0000000000005c10 <fwp_heap_alloc_big>:
    5c10:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c17:	00 00 40 
    5c1a:	41 57                	push   %r15
    5c1c:	41 56                	push   %r14
    5c1e:	41 55                	push   %r13
    5c20:	41 54                	push   %r12
    5c22:	55                   	push   %rbp
    5c23:	53                   	push   %rbx
    5c24:	48 83 ec 08          	sub    $0x8,%rsp
    5c28:	48 39 f8             	cmp    %rdi,%rax
    5c2b:	0f 82 fa 00 00 00    	jb     5d2b <fwp_heap_alloc_big+0x11b>
    5c31:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c38:	49 89 fd             	mov    %rdi,%r13
    5c3b:	41 89 f6             	mov    %esi,%r14d
    5c3e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c42:	48 89 ef             	mov    %rbp,%rdi
    5c45:	e8 e6 e1 ff ff       	call   3e30 <fwp_heap_chunks>
    5c4a:	be 01 00 00 00       	mov    $0x1,%esi
    5c4f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c53:	49 89 c4             	mov    %rax,%r12
    5c56:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c5d:	00 
    5c5e:	48 03 3d 93 6f 06 00 	add    0x66f93(%rip),%rdi        # 6cbf8 <fwp_heap+0x13f8>
    5c65:	c6 07 02             	movb   $0x2,(%rdi)
    5c68:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5c6c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5c6f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5c73:	e8 88 fb ff ff       	call   5800 <fwp_rc_prepare_chunk>
    5c78:	48 83 fd 01          	cmp    $0x1,%rbp
    5c7c:	76 47                	jbe    5cc5 <fwp_heap_alloc_big+0xb5>
    5c7e:	4c 01 e5             	add    %r12,%rbp
    5c81:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5c88:	00 
    5c89:	4c 8d 3d 70 5b 06 00 	lea    0x65b70(%rip),%r15        # 6b800 <fwp_heap>
    5c90:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5c95:	49 c1 e6 03          	shl    $0x3,%r14
    5c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ca0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ca7:	31 f6                	xor    %esi,%esi
    5ca9:	48 01 dd             	add    %rbx,%rbp
    5cac:	48 83 c3 28          	add    $0x28,%rbx
    5cb0:	48 89 ef             	mov    %rbp,%rdi
    5cb3:	e8 48 fb ff ff       	call   5800 <fwp_rc_prepare_chunk>
    5cb8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cbc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5cc0:	49 39 de             	cmp    %rbx,%r14
    5cc3:	75 db                	jne    5ca0 <fwp_heap_alloc_big+0x90>
    5cc5:	49 c1 e4 10          	shl    $0x10,%r12
    5cc9:	4c 03 25 e0 6e 06 00 	add    0x66ee0(%rip),%r12        # 6cbb0 <fwp_heap+0x13b0>
    5cd0:	4c 89 ea             	mov    %r13,%rdx
    5cd3:	31 f6                	xor    %esi,%esi
    5cd5:	4c 89 e7             	mov    %r12,%rdi
    5cd8:	e8 c3 d7 ff ff       	call   34a0 <memset@plt>
    5cdd:	4c 89 e8             	mov    %r13,%rax
    5ce0:	48 03 05 39 6f 06 00 	add    0x66f39(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    5ce7:	72 42                	jb     5d2b <fwp_heap_alloc_big+0x11b>
    5ce9:	48 39 05 38 6f 06 00 	cmp    %rax,0x66f38(%rip)        # 6cc28 <fwp_heap+0x1428>
    5cf0:	48 89 05 29 6f 06 00 	mov    %rax,0x66f29(%rip)        # 6cc20 <fwp_heap+0x1420>
    5cf7:	73 07                	jae    5d00 <fwp_heap_alloc_big+0xf0>
    5cf9:	48 89 05 28 6f 06 00 	mov    %rax,0x66f28(%rip)        # 6cc28 <fwp_heap+0x1428>
    5d00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d04:	4c 89 e0             	mov    %r12,%rax
    5d07:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d0c:	f2 0f 58 05 24 6f 06 	addsd  0x66f24(%rip),%xmm0        # 6cc38 <fwp_heap+0x1438>
    5d13:	00 
    5d14:	f2 0f 11 05 1c 6f 06 	movsd  %xmm0,0x66f1c(%rip)        # 6cc38 <fwp_heap+0x1438>
    5d1b:	00 
    5d1c:	48 83 c4 08          	add    $0x8,%rsp
    5d20:	5b                   	pop    %rbx
    5d21:	5d                   	pop    %rbp
    5d22:	41 5c                	pop    %r12
    5d24:	41 5d                	pop    %r13
    5d26:	41 5e                	pop    %r14
    5d28:	41 5f                	pop    %r15
    5d2a:	c3                   	ret
    5d2b:	e8 c0 e0 ff ff       	call   3df0 <fwp_heap_oom>

0000000000005d30 <fwp_heap_alloc_slow>:
    5d30:	53                   	push   %rbx
    5d31:	48 89 f9             	mov    %rdi,%rcx
    5d34:	41 89 f1             	mov    %esi,%r9d
    5d37:	48 83 ec 10          	sub    $0x10,%rsp
    5d3b:	8b 05 63 6e 06 00    	mov    0x66e63(%rip),%eax        # 6cba4 <fwp_heap+0x13a4>
    5d41:	85 c0                	test   %eax,%eax
    5d43:	0f 84 c7 00 00 00    	je     5e10 <fwp_heap_alloc_slow+0xe0>
    5d49:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d50:	0f 87 dd 00 00 00    	ja     5e33 <fwp_heap_alloc_slow+0x103>
    5d56:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d5a:	48 8d 3d 9f 5a 06 00 	lea    0x65a9f(%rip),%rdi        # 6b800 <fwp_heap>
    5d61:	49 63 f1             	movslq %r9d,%rsi
    5d64:	48 c1 e8 04          	shr    $0x4,%rax
    5d68:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5d6f:	00 00 
    5d71:	41 0f b6 c2          	movzbl %r10b,%eax
    5d75:	4c 89 d2             	mov    %r10,%rdx
    5d78:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5d7c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5d83:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5d8a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5d8e:	48 01 f8             	add    %rdi,%rax
    5d91:	4c 8b 00             	mov    (%rax),%r8
    5d94:	4d 85 c0             	test   %r8,%r8
    5d97:	0f 84 ab 00 00 00    	je     5e48 <fwp_heap_alloc_slow+0x118>
    5d9d:	49 8b 10             	mov    (%r8),%rdx
    5da0:	48 f7 d2             	not    %rdx
    5da3:	48 89 10             	mov    %rdx,(%rax)
    5da6:	41 83 f9 01          	cmp    $0x1,%r9d
    5daa:	4c 89 c7             	mov    %r8,%rdi
    5dad:	48 0f 45 cb          	cmovne %rbx,%rcx
    5db1:	31 f6                	xor    %esi,%esi
    5db3:	48 89 ca             	mov    %rcx,%rdx
    5db6:	e8 e5 d6 ff ff       	call   34a0 <memset@plt>
    5dbb:	49 89 c0             	mov    %rax,%r8
    5dbe:	48 89 d8             	mov    %rbx,%rax
    5dc1:	48 03 05 58 6e 06 00 	add    0x66e58(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    5dc8:	0f 82 d9 00 00 00    	jb     5ea7 <fwp_heap_alloc_slow+0x177>
    5dce:	48 39 05 53 6e 06 00 	cmp    %rax,0x66e53(%rip)        # 6cc28 <fwp_heap+0x1428>
    5dd5:	48 89 05 44 6e 06 00 	mov    %rax,0x66e44(%rip)        # 6cc20 <fwp_heap+0x1420>
    5ddc:	73 07                	jae    5de5 <fwp_heap_alloc_slow+0xb5>
    5dde:	48 89 05 43 6e 06 00 	mov    %rax,0x66e43(%rip)        # 6cc28 <fwp_heap+0x1428>
    5de5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5de9:	4c 89 c0             	mov    %r8,%rax
    5dec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5df1:	f2 0f 58 05 3f 6e 06 	addsd  0x66e3f(%rip),%xmm0        # 6cc38 <fwp_heap+0x1438>
    5df8:	00 
    5df9:	f2 0f 11 05 37 6e 06 	movsd  %xmm0,0x66e37(%rip)        # 6cc38 <fwp_heap+0x1438>
    5e00:	00 
    5e01:	48 83 c4 10          	add    $0x10,%rsp
    5e05:	5b                   	pop    %rbx
    5e06:	c3                   	ret
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 
    5e10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e18:	e8 73 ef ff ff       	call   4d90 <fwp_heap_init>
    5e1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e2d:	0f 86 23 ff ff ff    	jbe    5d56 <fwp_heap_alloc_slow+0x26>
    5e33:	48 83 c4 10          	add    $0x10,%rsp
    5e37:	44 89 ce             	mov    %r9d,%esi
    5e3a:	48 89 cf             	mov    %rcx,%rdi
    5e3d:	5b                   	pop    %rbx
    5e3e:	e9 cd fd ff ff       	jmp    5c10 <fwp_heap_alloc_big>
    5e43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e4c:	4d 85 c0             	test   %r8,%r8
    5e4f:	74 1f                	je     5e70 <fwp_heap_alloc_slow+0x140>
    5e51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e55:	4d 29 c3             	sub    %r8,%r11
    5e58:	49 39 db             	cmp    %rbx,%r11
    5e5b:	72 13                	jb     5e70 <fwp_heap_alloc_slow+0x140>
    5e5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5e61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5e65:	e9 3c ff ff ff       	jmp    5da6 <fwp_heap_alloc_slow+0x76>
    5e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5e77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5e7b:	44 89 ca             	mov    %r9d,%edx
    5e7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5e83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5e87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5e8b:	44 89 d6             	mov    %r10d,%esi
    5e8e:	48 01 c7             	add    %rax,%rdi
    5e91:	e8 6a fa ff ff       	call   5900 <fwp_heap_refill>
    5e96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5e9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5e9f:	49 89 c0             	mov    %rax,%r8
    5ea2:	e9 ff fe ff ff       	jmp    5da6 <fwp_heap_alloc_slow+0x76>
    5ea7:	e8 44 df ff ff       	call   3df0 <fwp_heap_oom>
    5eac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005eb0 <fwp_heap_alloc>:
    5eb0:	53                   	push   %rbx
    5eb1:	48 89 fa             	mov    %rdi,%rdx
    5eb4:	48 83 ec 10          	sub    $0x10,%rsp
    5eb8:	8b 1d 0a 76 06 00    	mov    0x6760a(%rip),%ebx        # 6d4c8 <iteration_active>
    5ebe:	8b 05 e0 6c 06 00    	mov    0x66ce0(%rip),%eax        # 6cba4 <fwp_heap+0x13a4>
    5ec4:	85 db                	test   %ebx,%ebx
    5ec6:	0f 85 04 01 00 00    	jne    5fd0 <fwp_heap_alloc+0x120>
    5ecc:	85 c0                	test   %eax,%eax
    5ece:	0f 84 ac 01 00 00    	je     6080 <fwp_heap_alloc+0x1d0>
    5ed4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5edb:	0f 87 9f 01 00 00    	ja     6080 <fwp_heap_alloc+0x1d0>
    5ee1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ee5:	48 8d 05 14 59 06 00 	lea    0x65914(%rip),%rax        # 6b800 <fwp_heap>
    5eec:	48 c1 e9 04          	shr    $0x4,%rcx
    5ef0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5ef7:	00 
    5ef8:	48 63 ce             	movslq %esi,%rcx
    5efb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f02:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f09:	00 
    5f0a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f0e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f12:	48 01 c8             	add    %rcx,%rax
    5f15:	48 8b 08             	mov    (%rax),%rcx
    5f18:	48 85 c9             	test   %rcx,%rcx
    5f1b:	0f 84 ff 00 00 00    	je     6020 <fwp_heap_alloc+0x170>
    5f21:	48 8b 39             	mov    (%rcx),%rdi
    5f24:	48 f7 d7             	not    %rdi
    5f27:	48 89 38             	mov    %rdi,(%rax)
    5f2a:	83 fe 01             	cmp    $0x1,%esi
    5f2d:	48 89 cf             	mov    %rcx,%rdi
    5f30:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f35:	49 0f 45 d0          	cmovne %r8,%rdx
    5f39:	31 f6                	xor    %esi,%esi
    5f3b:	e8 60 d5 ff ff       	call   34a0 <memset@plt>
    5f40:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f45:	48 89 c1             	mov    %rax,%rcx
    5f48:	4c 89 c0             	mov    %r8,%rax
    5f4b:	48 03 05 ce 6c 06 00 	add    0x66cce(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    5f52:	0f 82 35 01 00 00    	jb     608d <fwp_heap_alloc+0x1dd>
    5f58:	48 39 05 c9 6c 06 00 	cmp    %rax,0x66cc9(%rip)        # 6cc28 <fwp_heap+0x1428>
    5f5f:	48 89 05 ba 6c 06 00 	mov    %rax,0x66cba(%rip)        # 6cc20 <fwp_heap+0x1420>
    5f66:	73 07                	jae    5f6f <fwp_heap_alloc+0xbf>
    5f68:	48 89 05 b9 6c 06 00 	mov    %rax,0x66cb9(%rip)        # 6cc28 <fwp_heap+0x1428>
    5f6f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5f73:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5f78:	f2 0f 58 05 b8 6c 06 	addsd  0x66cb8(%rip),%xmm0        # 6cc38 <fwp_heap+0x1438>
    5f7f:	00 
    5f80:	f2 0f 11 05 b0 6c 06 	movsd  %xmm0,0x66cb0(%rip)        # 6cc38 <fwp_heap+0x1438>
    5f87:	00 
    5f88:	85 db                	test   %ebx,%ebx
    5f8a:	74 33                	je     5fbf <fwp_heap_alloc+0x10f>
    5f8c:	48 8b 05 8d 6c 06 00 	mov    0x66c8d(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    5f93:	48 85 c0             	test   %rax,%rax
    5f96:	0f 88 ac 00 00 00    	js     6048 <fwp_heap_alloc+0x198>
    5f9c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fa0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fa5:	f2 0f 5c 05 fb 74 06 	subsd  0x674fb(%rip),%xmm0        # 6d4a8 <iteration_start_charge>
    5fac:	00 
    5fad:	66 0f 2f 05 eb 74 06 	comisd 0x674eb(%rip),%xmm0        # 6d4a0 <iteration_peak>
    5fb4:	00 
    5fb5:	76 08                	jbe    5fbf <fwp_heap_alloc+0x10f>
    5fb7:	f2 0f 11 05 e1 74 06 	movsd  %xmm0,0x674e1(%rip)        # 6d4a0 <iteration_peak>
    5fbe:	00 
    5fbf:	48 83 c4 10          	add    $0x10,%rsp
    5fc3:	48 89 c8             	mov    %rcx,%rax
    5fc6:	5b                   	pop    %rbx
    5fc7:	c3                   	ret
    5fc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5fcf:	00 
    5fd0:	85 f6                	test   %esi,%esi
    5fd2:	74 34                	je     6008 <fwp_heap_alloc+0x158>
    5fd4:	48 83 05 e4 74 06 00 	addq   $0x1,0x674e4(%rip)        # 6d4c0 <iteration_requests>
    5fdb:	01 
    5fdc:	48 01 3d d5 74 06 00 	add    %rdi,0x674d5(%rip)        # 6d4b8 <iteration_bytes>
    5fe3:	85 c0                	test   %eax,%eax
    5fe5:	74 0d                	je     5ff4 <fwp_heap_alloc+0x144>
    5fe7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5fee:	0f 86 ed fe ff ff    	jbe    5ee1 <fwp_heap_alloc+0x31>
    5ff4:	48 89 d7             	mov    %rdx,%rdi
    5ff7:	e8 34 fd ff ff       	call   5d30 <fwp_heap_alloc_slow>
    5ffc:	48 89 c1             	mov    %rax,%rcx
    5fff:	eb 8b                	jmp    5f8c <fwp_heap_alloc+0xdc>
    6001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6008:	85 c0                	test   %eax,%eax
    600a:	74 0d                	je     6019 <fwp_heap_alloc+0x169>
    600c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6013:	0f 86 c8 fe ff ff    	jbe    5ee1 <fwp_heap_alloc+0x31>
    6019:	31 f6                	xor    %esi,%esi
    601b:	eb d7                	jmp    5ff4 <fwp_heap_alloc+0x144>
    601d:	0f 1f 00             	nopl   (%rax)
    6020:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6024:	48 85 c9             	test   %rcx,%rcx
    6027:	74 0c                	je     6035 <fwp_heap_alloc+0x185>
    6029:	48 8b 78 10          	mov    0x10(%rax),%rdi
    602d:	48 29 cf             	sub    %rcx,%rdi
    6030:	4c 39 c7             	cmp    %r8,%rdi
    6033:	73 3b                	jae    6070 <fwp_heap_alloc+0x1c0>
    6035:	48 89 d7             	mov    %rdx,%rdi
    6038:	e8 f3 fc ff ff       	call   5d30 <fwp_heap_alloc_slow>
    603d:	48 89 c1             	mov    %rax,%rcx
    6040:	e9 43 ff ff ff       	jmp    5f88 <fwp_heap_alloc+0xd8>
    6045:	0f 1f 00             	nopl   (%rax)
    6048:	48 89 c2             	mov    %rax,%rdx
    604b:	83 e0 01             	and    $0x1,%eax
    604e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6052:	48 d1 ea             	shr    $1,%rdx
    6055:	48 09 c2             	or     %rax,%rdx
    6058:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    605d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6061:	e9 3f ff ff ff       	jmp    5fa5 <fwp_heap_alloc+0xf5>
    6066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    606d:	00 00 00 
    6070:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6074:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6078:	e9 ad fe ff ff       	jmp    5f2a <fwp_heap_alloc+0x7a>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 83 c4 10          	add    $0x10,%rsp
    6084:	48 89 d7             	mov    %rdx,%rdi
    6087:	5b                   	pop    %rbx
    6088:	e9 a3 fc ff ff       	jmp    5d30 <fwp_heap_alloc_slow>
    608d:	e8 5e dd ff ff       	call   3df0 <fwp_heap_oom>
    6092:	0f 1f 00             	nopl   (%rax)
    6095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    609c:	00 00 00 00 

00000000000060a0 <fwp_data.part.0.constprop.0>:
    60a0:	41 56                	push   %r14
    60a2:	8b 05 fc 6a 06 00    	mov    0x66afc(%rip),%eax        # 6cba4 <fwp_heap+0x13a4>
    60a8:	41 89 fe             	mov    %edi,%r14d
    60ab:	41 55                	push   %r13
    60ad:	44 8b 2d 14 74 06 00 	mov    0x67414(%rip),%r13d        # 6d4c8 <iteration_active>
    60b4:	41 54                	push   %r12
    60b6:	49 89 f4             	mov    %rsi,%r12
    60b9:	55                   	push   %rbp
    60ba:	53                   	push   %rbx
    60bb:	45 85 ed             	test   %r13d,%r13d
    60be:	0f 84 1c 01 00 00    	je     61e0 <fwp_data.part.0.constprop.0+0x140>
    60c4:	48 83 05 f4 73 06 00 	addq   $0x1,0x673f4(%rip)        # 6d4c0 <iteration_requests>
    60cb:	01 
    60cc:	48 83 05 e4 73 06 00 	addq   $0x18,0x673e4(%rip)        # 6d4b8 <iteration_bytes>
    60d3:	18 
    60d4:	85 c0                	test   %eax,%eax
    60d6:	0f 84 8c 01 00 00    	je     6268 <fwp_data.part.0.constprop.0+0x1c8>
    60dc:	0f b6 05 bf 66 06 00 	movzbl 0x666bf(%rip),%eax        # 6c7a2 <fwp_heap+0xfa2>
    60e3:	48 8d 15 16 57 06 00 	lea    0x65716(%rip),%rdx        # 6b800 <fwp_heap>
    60ea:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    60f1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    60f5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    60f9:	48 8b 18             	mov    (%rax),%rbx
    60fc:	48 85 db             	test   %rbx,%rbx
    60ff:	0f 84 fb 00 00 00    	je     6200 <fwp_data.part.0.constprop.0+0x160>
    6105:	48 8b 13             	mov    (%rbx),%rdx
    6108:	48 f7 d2             	not    %rdx
    610b:	48 89 10             	mov    %rdx,(%rax)
    610e:	48 83 fd 18          	cmp    $0x18,%rbp
    6112:	76 1b                	jbe    612f <fwp_data.part.0.constprop.0+0x8f>
    6114:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6118:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    611c:	31 f6                	xor    %esi,%esi
    611e:	48 c1 e8 03          	shr    $0x3,%rax
    6122:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6129:	00 
    612a:	e8 71 d3 ff ff       	call   34a0 <memset@plt>
    612f:	48 89 e8             	mov    %rbp,%rax
    6132:	48 03 05 e7 6a 06 00 	add    0x66ae7(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    6139:	0f 82 3d 01 00 00    	jb     627c <fwp_data.part.0.constprop.0+0x1dc>
    613f:	48 39 05 e2 6a 06 00 	cmp    %rax,0x66ae2(%rip)        # 6cc28 <fwp_heap+0x1428>
    6146:	48 89 05 d3 6a 06 00 	mov    %rax,0x66ad3(%rip)        # 6cc20 <fwp_heap+0x1420>
    614d:	73 07                	jae    6156 <fwp_data.part.0.constprop.0+0xb6>
    614f:	48 89 05 d2 6a 06 00 	mov    %rax,0x66ad2(%rip)        # 6cc28 <fwp_heap+0x1428>
    6156:	66 0f ef c0          	pxor   %xmm0,%xmm0
    615a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    615f:	f2 0f 58 05 d1 6a 06 	addsd  0x66ad1(%rip),%xmm0        # 6cc38 <fwp_heap+0x1438>
    6166:	00 
    6167:	f2 0f 11 05 c9 6a 06 	movsd  %xmm0,0x66ac9(%rip)        # 6cc38 <fwp_heap+0x1438>
    616e:	00 
    616f:	45 85 ed             	test   %r13d,%r13d
    6172:	74 33                	je     61a7 <fwp_data.part.0.constprop.0+0x107>
    6174:	48 8b 05 a5 6a 06 00 	mov    0x66aa5(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    617b:	48 85 c0             	test   %rax,%rax
    617e:	0f 88 a4 00 00 00    	js     6228 <fwp_data.part.0.constprop.0+0x188>
    6184:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6188:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    618d:	f2 0f 5c 05 13 73 06 	subsd  0x67313(%rip),%xmm0        # 6d4a8 <iteration_start_charge>
    6194:	00 
    6195:	66 0f 2f 05 03 73 06 	comisd 0x67303(%rip),%xmm0        # 6d4a0 <iteration_peak>
    619c:	00 
    619d:	76 08                	jbe    61a7 <fwp_data.part.0.constprop.0+0x107>
    619f:	f2 0f 11 05 f9 72 06 	movsd  %xmm0,0x672f9(%rip)        # 6d4a0 <iteration_peak>
    61a6:	00 
    61a7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ac:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61b1:	66 0f 6e c8          	movd   %eax,%xmm1
    61b5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61b9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61bd:	49 8b 04 24          	mov    (%r12),%rax
    61c1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    61c5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    61ca:	48 89 43 10          	mov    %rax,0x10(%rbx)
    61ce:	48 89 d8             	mov    %rbx,%rax
    61d1:	5b                   	pop    %rbx
    61d2:	5d                   	pop    %rbp
    61d3:	41 5c                	pop    %r12
    61d5:	41 5d                	pop    %r13
    61d7:	41 5e                	pop    %r14
    61d9:	c3                   	ret
    61da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61e0:	85 c0                	test   %eax,%eax
    61e2:	0f 85 f4 fe ff ff    	jne    60dc <fwp_data.part.0.constprop.0+0x3c>
    61e8:	31 f6                	xor    %esi,%esi
    61ea:	bf 18 00 00 00       	mov    $0x18,%edi
    61ef:	e8 bc fc ff ff       	call   5eb0 <fwp_heap_alloc>
    61f4:	48 89 c3             	mov    %rax,%rbx
    61f7:	eb ae                	jmp    61a7 <fwp_data.part.0.constprop.0+0x107>
    61f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6200:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6204:	48 85 db             	test   %rbx,%rbx
    6207:	74 47                	je     6250 <fwp_data.part.0.constprop.0+0x1b0>
    6209:	48 8b 50 10          	mov    0x10(%rax),%rdx
    620d:	48 29 da             	sub    %rbx,%rdx
    6210:	48 39 ea             	cmp    %rbp,%rdx
    6213:	72 3b                	jb     6250 <fwp_data.part.0.constprop.0+0x1b0>
    6215:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6219:	48 89 50 08          	mov    %rdx,0x8(%rax)
    621d:	e9 ec fe ff ff       	jmp    610e <fwp_data.part.0.constprop.0+0x6e>
    6222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6228:	48 89 c2             	mov    %rax,%rdx
    622b:	83 e0 01             	and    $0x1,%eax
    622e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6232:	48 d1 ea             	shr    $1,%rdx
    6235:	48 09 c2             	or     %rax,%rdx
    6238:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    623d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6241:	e9 47 ff ff ff       	jmp    618d <fwp_data.part.0.constprop.0+0xed>
    6246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    624d:	00 00 00 
    6250:	31 f6                	xor    %esi,%esi
    6252:	bf 18 00 00 00       	mov    $0x18,%edi
    6257:	e8 54 fc ff ff       	call   5eb0 <fwp_heap_alloc>
    625c:	48 89 c3             	mov    %rax,%rbx
    625f:	e9 0b ff ff ff       	jmp    616f <fwp_data.part.0.constprop.0+0xcf>
    6264:	0f 1f 40 00          	nopl   0x0(%rax)
    6268:	31 f6                	xor    %esi,%esi
    626a:	bf 18 00 00 00       	mov    $0x18,%edi
    626f:	e8 3c fc ff ff       	call   5eb0 <fwp_heap_alloc>
    6274:	48 89 c3             	mov    %rax,%rbx
    6277:	e9 f8 fe ff ff       	jmp    6174 <fwp_data.part.0.constprop.0+0xd4>
    627c:	e8 6f db ff ff       	call   3df0 <fwp_heap_oom>
    6281:	0f 1f 40 00          	nopl   0x0(%rax)
    6285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    628c:	00 00 00 00 

0000000000006290 <fwp_tape_grow.constprop.0>:
    6290:	41 56                	push   %r14
    6292:	b8 40 00 00 00       	mov    $0x40,%eax
    6297:	41 55                	push   %r13
    6299:	41 54                	push   %r12
    629b:	55                   	push   %rbp
    629c:	48 89 fd             	mov    %rdi,%rbp
    629f:	53                   	push   %rbx
    62a0:	48 83 ec 10          	sub    $0x10,%rsp
    62a4:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    62a8:	48 85 db             	test   %rbx,%rbx
    62ab:	48 0f 44 d8          	cmove  %rax,%rbx
    62af:	48 39 de             	cmp    %rbx,%rsi
    62b2:	7e 12                	jle    62c6 <fwp_tape_grow.constprop.0+0x36>
    62b4:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    62bb:	0f 8e df 00 00 00    	jle    63a0 <fwp_tape_grow.constprop.0+0x110>
    62c1:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    62c6:	4c 8b 65 50          	mov    0x50(%rbp),%r12
    62ca:	4d 85 e4             	test   %r12,%r12
    62cd:	0f 84 dd 00 00 00    	je     63b0 <fwp_tape_grow.constprop.0+0x120>
    62d3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    62d7:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    62de:	00 
    62df:	ba 01 00 00 00       	mov    $0x1,%edx
    62e4:	e8 67 ee ff ff       	call   5150 <ad_raw_realloc>
    62e9:	48 85 c0             	test   %rax,%rax
    62ec:	0f 84 eb 00 00 00    	je     63dd <fwp_tape_grow.constprop.0+0x14d>
    62f2:	49 8b 54 24 60       	mov    0x60(%r12),%rdx
    62f7:	48 89 45 28          	mov    %rax,0x28(%rbp)
    62fb:	48 39 da             	cmp    %rbx,%rdx
    62fe:	0f 8d 8b 00 00 00    	jge    638f <fwp_tape_grow.constprop.0+0xff>
    6304:	48 b8 ff ff ff ff ff 	movabs $0x7ffffffffffffff,%rax
    630b:	ff ff 07 
    630e:	48 39 c3             	cmp    %rax,%rbx
    6311:	0f 8f ba 00 00 00    	jg     63d1 <fwp_tape_grow.constprop.0+0x141>
    6317:	48 89 d9             	mov    %rbx,%rcx
    631a:	4d 8b 74 24 40       	mov    0x40(%r12),%r14
    631f:	be 02 00 00 00       	mov    $0x2,%esi
    6324:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6329:	48 c1 e1 04          	shl    $0x4,%rcx
    632d:	48 89 cf             	mov    %rcx,%rdi
    6330:	48 89 0c 24          	mov    %rcx,(%rsp)
    6334:	e8 77 fb ff ff       	call   5eb0 <fwp_heap_alloc>
    6339:	49 89 c5             	mov    %rax,%r13
    633c:	4d 85 f6             	test   %r14,%r14
    633f:	74 27                	je     6368 <fwp_tape_grow.constprop.0+0xd8>
    6341:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6346:	48 8b 0c 24          	mov    (%rsp),%rcx
    634a:	48 89 c7             	mov    %rax,%rdi
    634d:	4c 89 f6             	mov    %r14,%rsi
    6350:	48 c1 e2 04          	shl    $0x4,%rdx
    6354:	48 39 ca             	cmp    %rcx,%rdx
    6357:	48 0f 47 d1          	cmova  %rcx,%rdx
    635b:	e8 10 d2 ff ff       	call   3570 <memcpy@plt>
    6360:	4c 89 f7             	mov    %r14,%rdi
    6363:	e8 48 f6 ff ff       	call   59b0 <fwp_mem_free>
    6368:	49 8b 7c 24 60       	mov    0x60(%r12),%rdi
    636d:	48 89 da             	mov    %rbx,%rdx
    6370:	31 f6                	xor    %esi,%esi
    6372:	48 29 fa             	sub    %rdi,%rdx
    6375:	48 c1 e7 04          	shl    $0x4,%rdi
    6379:	48 c1 e2 04          	shl    $0x4,%rdx
    637d:	4c 01 ef             	add    %r13,%rdi
    6380:	e8 1b d1 ff ff       	call   34a0 <memset@plt>
    6385:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    638a:	49 89 5c 24 60       	mov    %rbx,0x60(%r12)
    638f:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    6393:	48 83 c4 10          	add    $0x10,%rsp
    6397:	5b                   	pop    %rbx
    6398:	5d                   	pop    %rbp
    6399:	41 5c                	pop    %r12
    639b:	41 5d                	pop    %r13
    639d:	41 5e                	pop    %r14
    639f:	c3                   	ret
    63a0:	48 01 db             	add    %rbx,%rbx
    63a3:	e9 07 ff ff ff       	jmp    62af <fwp_tape_grow.constprop.0+0x1f>
    63a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63af:	00 
    63b0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
    63b4:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63b8:	ba 02 00 00 00       	mov    $0x2,%edx
    63bd:	48 c1 e6 03          	shl    $0x3,%rsi
    63c1:	e8 8a ed ff ff       	call   5150 <ad_raw_realloc>
    63c6:	48 85 c0             	test   %rax,%rax
    63c9:	74 12                	je     63dd <fwp_tape_grow.constprop.0+0x14d>
    63cb:	48 89 45 20          	mov    %rax,0x20(%rbp)
    63cf:	eb be                	jmp    638f <fwp_tape_grow.constprop.0+0xff>
    63d1:	48 8d 3d d1 8d 00 00 	lea    0x8dd1(%rip),%rdi        # f1a9 <_IO_stdin_used+0x1a9>
    63d8:	e8 33 e0 ff ff       	call   4410 <fwp_trap>
    63dd:	48 89 ef             	mov    %rbp,%rdi
    63e0:	e8 6b d8 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    63e5:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63e9:	48 85 ff             	test   %rdi,%rdi
    63ec:	74 05                	je     63f3 <fwp_tape_grow.constprop.0+0x163>
    63ee:	e8 9d ec ff ff       	call   5090 <ad_raw_free.part.0>
    63f3:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
    63f7:	48 85 ff             	test   %rdi,%rdi
    63fa:	74 05                	je     6401 <fwp_tape_grow.constprop.0+0x171>
    63fc:	e8 8f ec ff ff       	call   5090 <ad_raw_free.part.0>
    6401:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6405:	48 85 ff             	test   %rdi,%rdi
    6408:	74 05                	je     640f <fwp_tape_grow.constprop.0+0x17f>
    640a:	e8 81 ec ff ff       	call   5090 <ad_raw_free.part.0>
    640f:	31 c9                	xor    %ecx,%ecx
    6411:	31 c0                	xor    %eax,%eax
    6413:	31 d2                	xor    %edx,%edx
    6415:	be 01 00 00 00       	mov    $0x1,%esi
    641a:	89 55 04             	mov    %edx,0x4(%rbp)
    641d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6421:	ba 13 00 00 00       	mov    $0x13,%edx
    6426:	48 8d 3d db 8b 00 00 	lea    0x8bdb(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    642d:	48 89 4d 38          	mov    %rcx,0x38(%rbp)
    6431:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6435:	48 8b 0d 04 cc 00 00 	mov    0xcc04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    643c:	48 89 45 30          	mov    %rax,0x30(%rbp)
    6440:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6444:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6448:	e8 f3 d1 ff ff       	call   3640 <fwrite@plt>
    644d:	31 ff                	xor    %edi,%edi
    644f:	e8 3c d1 ff ff       	call   3590 <fflush@plt>
    6454:	bf 66 00 00 00       	mov    $0x66,%edi
    6459:	e8 02 d2 ff ff       	call   3660 <_Exit@plt>
    645e:	66 90                	xchg   %ax,%ax

0000000000006460 <w123>:
    6460:	41 56                	push   %r14
    6462:	55                   	push   %rbp
    6463:	53                   	push   %rbx
    6464:	48 83 ec 30          	sub    $0x30,%rsp
    6468:	48 85 f7             	test   %rsi,%rdi
    646b:	0f 88 a7 01 00 00    	js     6618 <w123+0x1b8>
    6471:	48 89 f8             	mov    %rdi,%rax
    6474:	48 89 fb             	mov    %rdi,%rbx
    6477:	48 89 f5             	mov    %rsi,%rbp
    647a:	48 09 f0             	or     %rsi,%rax
    647d:	0f 89 5d 01 00 00    	jns    65e0 <w123+0x180>
    6483:	48 85 ff             	test   %rdi,%rdi
    6486:	0f 88 a4 01 00 00    	js     6630 <w123+0x1d0>
    648c:	48 89 d9             	mov    %rbx,%rcx
    648f:	4c 8b 35 5a 99 00 00 	mov    0x995a(%rip),%r14        # fdf0 <msg.4+0xb0>
    6496:	48 c1 f9 20          	sar    $0x20,%rcx
    649a:	48 39 0a             	cmp    %rcx,(%rdx)
    649d:	0f 84 65 01 00 00    	je     6608 <w123+0x1a8>
    64a3:	48 89 cf             	mov    %rcx,%rdi
    64a6:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    64ab:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    64b0:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    64b6:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    64bc:	e8 2f e2 ff ff       	call   46f0 <fwp_tape_of>
    64c1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    64c6:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    64cc:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    64d1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    64d7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    64dc:	0f 85 7f 01 00 00    	jne    6661 <w123+0x201>
    64e2:	48 89 0a             	mov    %rcx,(%rdx)
    64e5:	48 89 42 08          	mov    %rax,0x8(%rdx)
    64e9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    64ed:	48 81 f9 fe ff ff 7f 	cmp    $0x7ffffffe,%rcx
    64f4:	0f 8f 4f 01 00 00    	jg     6649 <w123+0x1e9>
    64fa:	89 da                	mov    %ebx,%edx
    64fc:	48 39 d1             	cmp    %rdx,%rcx
    64ff:	0f 8e 50 01 00 00    	jle    6655 <w123+0x1f5>
    6505:	48 85 ed             	test   %rbp,%rbp
    6508:	78 0b                	js     6515 <w123+0xb5>
    650a:	89 ea                	mov    %ebp,%edx
    650c:	48 39 d1             	cmp    %rdx,%rcx
    650f:	0f 8e 40 01 00 00    	jle    6655 <w123+0x1f5>
    6515:	48 89 ca             	mov    %rcx,%rdx
    6518:	48 2b 50 08          	sub    0x8(%rax),%rdx
    651c:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    6520:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6527:	0f 87 1c 01 00 00    	ja     6649 <w123+0x1e9>
    652d:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6531:	7e 3e                	jle    6571 <w123+0x111>
    6533:	48 89 c7             	mov    %rax,%rdi
    6536:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    653b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6540:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6545:	f2 0f 11 4c 24 28    	movsd  %xmm1,0x28(%rsp)
    654b:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6551:	e8 3a fd ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6556:	f2 0f 10 4c 24 28    	movsd  0x28(%rsp),%xmm1
    655c:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6562:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6567:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    656c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6571:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
    6575:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6579:	48 85 ed             	test   %rbp,%rbp
    657c:	66 48 0f 6e d3       	movq   %rbx,%xmm2
    6581:	48 8b 3d 68 98 00 00 	mov    0x9868(%rip),%rdi        # fdf0 <msg.4+0xb0>
    6588:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    658c:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6590:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
    6597:	48 0f 48 ee          	cmovs  %rsi,%rbp
    659b:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    659f:	4c 89 72 10          	mov    %r14,0x10(%rdx)
    65a3:	66 48 0f 6e dd       	movq   %rbp,%xmm3
    65a8:	66 0f 6c d3          	punpcklqdq %xmm3,%xmm2
    65ac:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
    65b0:	66 0f d6 12          	movq   %xmm2,(%rdx)
    65b4:	48 8d 51 01          	lea    0x1(%rcx),%rdx
    65b8:	48 89 50 10          	mov    %rdx,0x10(%rax)
    65bc:	48 83 c4 30          	add    $0x30,%rsp
    65c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65c7:	ff ff ff 
    65ca:	48 21 c3             	and    %rax,%rbx
    65cd:	48 09 cb             	or     %rcx,%rbx
    65d0:	48 89 d8             	mov    %rbx,%rax
    65d3:	5b                   	pop    %rbx
    65d4:	5d                   	pop    %rbp
    65d5:	41 5e                	pop    %r14
    65d7:	c3                   	ret
    65d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65df:	00 
    65e0:	48 89 f9             	mov    %rdi,%rcx
    65e3:	48 89 f0             	mov    %rsi,%rax
    65e6:	48 c1 f9 20          	sar    $0x20,%rcx
    65ea:	48 c1 f8 20          	sar    $0x20,%rax
    65ee:	48 39 c1             	cmp    %rax,%rcx
    65f1:	0f 84 95 fe ff ff    	je     648c <w123+0x2c>
    65f7:	48 8d 3d 1a 94 00 00 	lea    0x941a(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    65fe:	e8 0d de ff ff       	call   4410 <fwp_trap>
    6603:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6608:	48 8b 42 08          	mov    0x8(%rdx),%rax
    660c:	e9 d8 fe ff ff       	jmp    64e9 <w123+0x89>
    6611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6618:	48 83 c4 30          	add    $0x30,%rsp
    661c:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6623:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    6627:	48 89 d8             	mov    %rbx,%rax
    662a:	5b                   	pop    %rbx
    662b:	5d                   	pop    %rbp
    662c:	41 5e                	pop    %r14
    662e:	c3                   	ret
    662f:	90                   	nop
    6630:	48 89 f1             	mov    %rsi,%rcx
    6633:	48 89 f3             	mov    %rsi,%rbx
    6636:	45 31 f6             	xor    %r14d,%r14d
    6639:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6640:	48 c1 f9 20          	sar    $0x20,%rcx
    6644:	e9 51 fe ff ff       	jmp    649a <w123+0x3a>
    6649:	48 8d 3d 59 8b 00 00 	lea    0x8b59(%rip),%rdi        # f1a9 <_IO_stdin_used+0x1a9>
    6650:	e8 bb dd ff ff       	call   4410 <fwp_trap>
    6655:	48 8d 3d 68 8b 00 00 	lea    0x8b68(%rip),%rdi        # f1c4 <_IO_stdin_used+0x1c4>
    665c:	e8 af dd ff ff       	call   4410 <fwp_trap>
    6661:	48 8d 3d f8 93 00 00 	lea    0x93f8(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    6668:	e8 a3 dd ff ff       	call   4410 <fwp_trap>
    666d:	0f 1f 00             	nopl   (%rax)

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 57                	push   %r15
    6676:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667a:	41 56                	push   %r14
    667c:	41 55                	push   %r13
    667e:	49 89 fd             	mov    %rdi,%r13
    6681:	41 54                	push   %r12
    6683:	49 89 d4             	mov    %rdx,%r12
    6686:	55                   	push   %rbp
    6687:	48 89 f5             	mov    %rsi,%rbp
    668a:	53                   	push   %rbx
    668b:	48 83 ec 48          	sub    $0x48,%rsp
    668f:	f2 0f 11 44 24 30    	movsd  %xmm0,0x30(%rsp)
    6695:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
    669a:	48 85 ff             	test   %rdi,%rdi
    669d:	0f 88 5d 06 00 00    	js     6d00 <w120+0x690>
    66a3:	49 89 fe             	mov    %rdi,%r14
    66a6:	49 c1 fe 20          	sar    $0x20,%r14
    66aa:	4c 3b 32             	cmp    (%rdx),%r14
    66ad:	0f 84 ed 05 00 00    	je     6ca0 <w120+0x630>
    66b3:	4c 89 f7             	mov    %r14,%rdi
    66b6:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    66bc:	e8 2f e0 ff ff       	call   46f0 <fwp_tape_of>
    66c1:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    66c7:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    66cc:	48 89 c3             	mov    %rax,%rbx
    66cf:	0f 85 97 06 00 00    	jne    6d6c <w120+0x6fc>
    66d5:	4d 89 34 24          	mov    %r14,(%r12)
    66d9:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    66de:	4c 8b 73 10          	mov    0x10(%rbx),%r14
    66e2:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    66e9:	0f 8f 71 06 00 00    	jg     6d60 <w120+0x6f0>
    66ef:	44 89 e8             	mov    %r13d,%eax
    66f2:	49 39 c6             	cmp    %rax,%r14
    66f5:	0f 8e 4a 06 00 00    	jle    6d45 <w120+0x6d5>
    66fb:	4c 89 f0             	mov    %r14,%rax
    66fe:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6702:	48 8d 70 01          	lea    0x1(%rax),%rsi
    6706:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    670d:	0f 87 4d 06 00 00    	ja     6d60 <w120+0x6f0>
    6713:	f2 0f 10 44 24 30    	movsd  0x30(%rsp),%xmm0
    6719:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    671d:	48 3b 73 18          	cmp    0x18(%rbx),%rsi
    6721:	0f 8f 61 04 00 00    	jg     6b88 <w120+0x518>
    6727:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    672b:	66 41 0f 6e fd       	movd   %r13d,%xmm7
    6730:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6734:	66 0f 70 d7 e0       	pshufd $0xe0,%xmm7,%xmm2
    6739:	66 0f d6 14 d0       	movq   %xmm2,(%rax,%rdx,8)
    673e:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    6743:	49 8d 46 01          	lea    0x1(%r14),%rax
    6747:	48 89 43 10          	mov    %rax,0x10(%rbx)
    674b:	48 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbx
    6752:	ff ff ff 
    6755:	4c 21 eb             	and    %r13,%rbx
    6758:	4c 09 f3             	or     %r14,%rbx
    675b:	49 89 de             	mov    %rbx,%r14
    675e:	49 c1 fe 20          	sar    $0x20,%r14
    6762:	48 85 ed             	test   %rbp,%rbp
    6765:	78 10                	js     6777 <w120+0x107>
    6767:	48 89 e8             	mov    %rbp,%rax
    676a:	48 c1 f8 20          	sar    $0x20,%rax
    676e:	4c 39 f0             	cmp    %r14,%rax
    6771:	0f 85 da 05 00 00    	jne    6d51 <w120+0x6e1>
    6777:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    677c:	66 0f 28 2d 5c 96 00 	movapd 0x965c(%rip),%xmm5        # fde0 <msg.4+0xa0>
    6783:	00 
    6784:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6789:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    678e:	4d 39 34 24          	cmp    %r14,(%r12)
    6792:	0f 84 18 05 00 00    	je     6cb0 <w120+0x640>
    6798:	4c 89 f7             	mov    %r14,%rdi
    679b:	e8 50 df ff ff       	call   46f0 <fwp_tape_of>
    67a0:	48 89 c2             	mov    %rax,%rdx
    67a3:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    67a8:	0f 85 be 05 00 00    	jne    6d6c <w120+0x6fc>
    67ae:	4d 89 34 24          	mov    %r14,(%r12)
    67b2:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    67b7:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    67bb:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    67c2:	0f 8f 98 05 00 00    	jg     6d60 <w120+0x6f0>
    67c8:	89 d8                	mov    %ebx,%eax
    67ca:	49 39 c6             	cmp    %rax,%r14
    67cd:	0f 8e 72 05 00 00    	jle    6d45 <w120+0x6d5>
    67d3:	48 85 ed             	test   %rbp,%rbp
    67d6:	78 0b                	js     67e3 <w120+0x173>
    67d8:	89 e8                	mov    %ebp,%eax
    67da:	49 39 c6             	cmp    %rax,%r14
    67dd:	0f 8e 62 05 00 00    	jle    6d45 <w120+0x6d5>
    67e3:	4c 89 f0             	mov    %r14,%rax
    67e6:	48 2b 42 08          	sub    0x8(%rdx),%rax
    67ea:	48 8d 70 01          	lea    0x1(%rax),%rsi
    67ee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    67f5:	0f 87 65 05 00 00    	ja     6d60 <w120+0x6f0>
    67fb:	48 3b 72 18          	cmp    0x18(%rdx),%rsi
    67ff:	0f 8f bb 03 00 00    	jg     6bc0 <w120+0x550>
    6805:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    6809:	48 8b 42 20          	mov    0x20(%rdx),%rax
    680d:	48 85 ed             	test   %rbp,%rbp
    6810:	66 0f 28 7c 24 10    	movapd 0x10(%rsp),%xmm7
    6816:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    681b:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
    681f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6826:	48 0f 49 c5          	cmovns %rbp,%rax
    682a:	0f 11 79 08          	movups %xmm7,0x8(%rcx)
    682e:	66 48 0f 6e d8       	movq   %rax,%xmm3
    6833:	49 8d 46 01          	lea    0x1(%r14),%rax
    6837:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    683b:	0f c6 c0 e8          	shufps $0xe8,%xmm0,%xmm0
    683f:	66 0f d6 01          	movq   %xmm0,(%rcx)
    6843:	48 89 42 10          	mov    %rax,0x10(%rdx)
    6847:	4d 85 ed             	test   %r13,%r13
    684a:	0f 88 4b 05 00 00    	js     6d9b <w120+0x72b>
    6850:	4c 89 ea             	mov    %r13,%rdx
    6853:	48 c1 fa 20          	sar    $0x20,%rdx
    6857:	49 3b 14 24          	cmp    (%r12),%rdx
    685b:	0f 84 5f 04 00 00    	je     6cc0 <w120+0x650>
    6861:	48 89 d7             	mov    %rdx,%rdi
    6864:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6869:	e8 82 de ff ff       	call   46f0 <fwp_tape_of>
    686e:	48 89 c5             	mov    %rax,%rbp
    6871:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6876:	0f 85 f0 04 00 00    	jne    6d6c <w120+0x6fc>
    687c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6881:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6886:	49 89 14 24          	mov    %rdx,(%r12)
    688a:	48 8b 45 10          	mov    0x10(%rbp),%rax
    688e:	48 3d fe ff ff 7f    	cmp    $0x7ffffffe,%rax
    6894:	0f 8f c6 04 00 00    	jg     6d60 <w120+0x6f0>
    689a:	44 89 ea             	mov    %r13d,%edx
    689d:	48 39 d0             	cmp    %rdx,%rax
    68a0:	0f 8e 9f 04 00 00    	jle    6d45 <w120+0x6d5>
    68a6:	48 89 c2             	mov    %rax,%rdx
    68a9:	48 2b 55 08          	sub    0x8(%rbp),%rdx
    68ad:	48 8d 72 01          	lea    0x1(%rdx),%rsi
    68b1:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    68b8:	0f 87 a2 04 00 00    	ja     6d60 <w120+0x6f0>
    68be:	48 3b 75 18          	cmp    0x18(%rbp),%rsi
    68c2:	0f 8f 20 03 00 00    	jg     6be8 <w120+0x578>
    68c8:	f2 0f 10 34 24       	movsd  (%rsp),%xmm6
    68cd:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
    68d1:	66 0f 28 05 07 95 00 	movapd 0x9507(%rip),%xmm0        # fde0 <msg.4+0xa0>
    68d8:	00 
    68d9:	48 8b 55 20          	mov    0x20(%rbp),%rdx
    68dd:	66 0f 28 ee          	movapd %xmm6,%xmm5
    68e1:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    68e5:	44 89 2c ca          	mov    %r13d,(%rdx,%rcx,8)
    68e9:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    68f0:	ff 
    68f1:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    68f6:	48 8d 50 01          	lea    0x1(%rax),%rdx
    68fa:	48 89 55 10          	mov    %rdx,0x10(%rbp)
    68fe:	4c 89 ed             	mov    %r13,%rbp
    6901:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6908:	ff ff ff 
    690b:	48 21 d5             	and    %rdx,%rbp
    690e:	48 09 c5             	or     %rax,%rbp
    6911:	66 49 0f 7e ef       	movq   %xmm5,%r15
    6916:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    691d:	ff ff ff 
    6920:	48 21 c3             	and    %rax,%rbx
    6923:	4c 09 f3             	or     %r14,%rbx
    6926:	49 89 de             	mov    %rbx,%r14
    6929:	49 c1 fe 20          	sar    $0x20,%r14
    692d:	4d 3b 34 24          	cmp    (%r12),%r14
    6931:	0f 84 99 03 00 00    	je     6cd0 <w120+0x660>
    6937:	4c 89 f7             	mov    %r14,%rdi
    693a:	e8 b1 dd ff ff       	call   46f0 <fwp_tape_of>
    693f:	49 89 c5             	mov    %rax,%r13
    6942:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6947:	0f 85 1f 04 00 00    	jne    6d6c <w120+0x6fc>
    694d:	4d 89 34 24          	mov    %r14,(%r12)
    6951:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6956:	4d 8b 75 10          	mov    0x10(%r13),%r14
    695a:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6961:	0f 8f f9 03 00 00    	jg     6d60 <w120+0x6f0>
    6967:	89 d8                	mov    %ebx,%eax
    6969:	49 39 c6             	cmp    %rax,%r14
    696c:	0f 8e d3 03 00 00    	jle    6d45 <w120+0x6d5>
    6972:	4c 89 f0             	mov    %r14,%rax
    6975:	49 2b 45 08          	sub    0x8(%r13),%rax
    6979:	48 8d 70 01          	lea    0x1(%rax),%rsi
    697d:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6984:	0f 87 d6 03 00 00    	ja     6d60 <w120+0x6f0>
    698a:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    698f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
    6993:	49 3b 75 18          	cmp    0x18(%r13),%rsi
    6997:	0f 8f 73 02 00 00    	jg     6c10 <w120+0x5a0>
    699d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
    69a1:	66 0f 6e eb          	movd   %ebx,%xmm5
    69a5:	49 8b 45 20          	mov    0x20(%r13),%rax
    69a9:	66 0f 70 cd e0       	pshufd $0xe0,%xmm5,%xmm1
    69ae:	66 0f d6 0c d0       	movq   %xmm1,(%rax,%rdx,8)
    69b3:	0f 11 44 d0 08       	movups %xmm0,0x8(%rax,%rdx,8)
    69b8:	49 8d 46 01          	lea    0x1(%r14),%rax
    69bc:	49 89 45 10          	mov    %rax,0x10(%r13)
    69c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69c7:	ff ff ff 
    69ca:	48 21 c3             	and    %rax,%rbx
    69cd:	4c 09 f3             	or     %r14,%rbx
    69d0:	49 89 dd             	mov    %rbx,%r13
    69d3:	49 c1 fd 20          	sar    $0x20,%r13
    69d7:	4d 3b 2c 24          	cmp    (%r12),%r13
    69db:	0f 84 ff 02 00 00    	je     6ce0 <w120+0x670>
    69e1:	4c 89 ef             	mov    %r13,%rdi
    69e4:	e8 07 dd ff ff       	call   46f0 <fwp_tape_of>
    69e9:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    69ee:	0f 85 78 03 00 00    	jne    6d6c <w120+0x6fc>
    69f4:	4d 89 2c 24          	mov    %r13,(%r12)
    69f8:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    69fd:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6a01:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6a08:	0f 8f 52 03 00 00    	jg     6d60 <w120+0x6f0>
    6a0e:	89 da                	mov    %ebx,%edx
    6a10:	49 39 d5             	cmp    %rdx,%r13
    6a13:	0f 8e 2c 03 00 00    	jle    6d45 <w120+0x6d5>
    6a19:	4d 89 ee             	mov    %r13,%r14
    6a1c:	4c 2b 70 08          	sub    0x8(%rax),%r14
    6a20:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6a24:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6a2b:	0f 87 2f 03 00 00    	ja     6d60 <w120+0x6f0>
    6a31:	f2 0f 10 15 b7 93 00 	movsd  0x93b7(%rip),%xmm2        # fdf0 <msg.4+0xb0>
    6a38:	00 
    6a39:	66 49 0f 6e cf       	movq   %r15,%xmm1
    6a3e:	f2 0f 5c 54 24 30    	subsd  0x30(%rsp),%xmm2
    6a44:	f2 0f 59 0d b4 93 00 	mulsd  0x93b4(%rip),%xmm1        # fe00 <msg.4+0xc0>
    6a4b:	00 
    6a4c:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6a50:	0f 8f da 01 00 00    	jg     6c30 <w120+0x5c0>
    6a56:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a5a:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
    6a5e:	f3 0f 7e 05 9a 93 00 	movq   0x939a(%rip),%xmm0        # fe00 <msg.4+0xc0>
    6a65:	00 
    6a66:	48 89 ef             	mov    %rbp,%rdi
    6a69:	89 1c ca             	mov    %ebx,(%rdx,%rcx,8)
    6a6c:	0f 11 44 ca 08       	movups %xmm0,0x8(%rdx,%rcx,8)
    6a71:	66 0f 28 c2          	movapd %xmm2,%xmm0
    6a75:	c7 44 ca 04 ff ff ff 	movl   $0xffffffff,0x4(%rdx,%rcx,8)
    6a7c:	ff 
    6a7d:	49 8d 55 01          	lea    0x1(%r13),%rdx
    6a81:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
    6a85:	48 89 50 10          	mov    %rdx,0x10(%rax)
    6a89:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a90:	ff ff ff 
    6a93:	48 21 c3             	and    %rax,%rbx
    6a96:	4c 09 eb             	or     %r13,%rbx
    6a99:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6a9d:	0f 84 c8 00 00 00    	je     6b6b <w120+0x4fb>
    6aa3:	49 89 ed             	mov    %rbp,%r13
    6aa6:	49 c1 fd 20          	sar    $0x20,%r13
    6aaa:	4d 39 2c 24          	cmp    %r13,(%r12)
    6aae:	0f 84 3c 02 00 00    	je     6cf0 <w120+0x680>
    6ab4:	4c 89 ef             	mov    %r13,%rdi
    6ab7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6abd:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6ac2:	f2 0f 11 54 24 30    	movsd  %xmm2,0x30(%rsp)
    6ac8:	e8 23 dc ff ff       	call   46f0 <fwp_tape_of>
    6acd:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    6ad2:	0f 85 94 02 00 00    	jne    6d6c <w120+0x6fc>
    6ad8:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6ade:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6ae3:	4d 89 2c 24          	mov    %r13,(%r12)
    6ae7:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    6aec:	f2 0f 10 54 24 30    	movsd  0x30(%rsp),%xmm2
    6af2:	4c 8b 70 10          	mov    0x10(%rax),%r14
    6af6:	49 81 fe fe ff ff 7f 	cmp    $0x7ffffffe,%r14
    6afd:	0f 8f 5d 02 00 00    	jg     6d60 <w120+0x6f0>
    6b03:	89 e9                	mov    %ebp,%ecx
    6b05:	4c 39 f1             	cmp    %r14,%rcx
    6b08:	0f 8d 37 02 00 00    	jge    6d45 <w120+0x6d5>
    6b0e:	4d 89 f5             	mov    %r14,%r13
    6b11:	4c 2b 68 08          	sub    0x8(%rax),%r13
    6b15:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6b19:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6b20:	0f 87 3a 02 00 00    	ja     6d60 <w120+0x6f0>
    6b26:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
    6b2a:	48 3b 70 18          	cmp    0x18(%rax),%rsi
    6b2e:	0f 8f 2c 01 00 00    	jg     6c60 <w120+0x5f0>
    6b34:	48 8b 48 20          	mov    0x20(%rax),%rcx
    6b38:	66 0f 6e dd          	movd   %ebp,%xmm3
    6b3c:	4b 8d 74 6d 00       	lea    0x0(%r13,%r13,2),%rsi
    6b41:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    6b48:	ff ff ff 
    6b4b:	66 0f 70 db e0       	pshufd $0xe0,%xmm3,%xmm3
    6b50:	48 21 d5             	and    %rdx,%rbp
    6b53:	66 0f d6 1c f1       	movq   %xmm3,(%rcx,%rsi,8)
    6b58:	48 89 ef             	mov    %rbp,%rdi
    6b5b:	0f 11 54 f1 08       	movups %xmm2,0x8(%rcx,%rsi,8)
    6b60:	49 8d 4e 01          	lea    0x1(%r14),%rcx
    6b64:	4c 09 f7             	or     %r14,%rdi
    6b67:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6b6b:	4c 89 e2             	mov    %r12,%rdx
    6b6e:	48 89 de             	mov    %rbx,%rsi
    6b71:	e8 ea f8 ff ff       	call   6460 <w123>
    6b76:	48 83 c4 48          	add    $0x48,%rsp
    6b7a:	5b                   	pop    %rbx
    6b7b:	5d                   	pop    %rbp
    6b7c:	41 5c                	pop    %r12
    6b7e:	41 5d                	pop    %r13
    6b80:	41 5e                	pop    %r14
    6b82:	41 5f                	pop    %r15
    6b84:	c3                   	ret
    6b85:	0f 1f 00             	nopl   (%rax)
    6b88:	48 89 df             	mov    %rbx,%rdi
    6b8b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6b90:	f2 0f 11 4c 24 38    	movsd  %xmm1,0x38(%rsp)
    6b96:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6b9b:	e8 f0 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6ba0:	f2 0f 10 4c 24 38    	movsd  0x38(%rsp),%xmm1
    6ba6:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
    6bac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6bb1:	e9 71 fb ff ff       	jmp    6727 <w120+0xb7>
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	48 89 d7             	mov    %rdx,%rdi
    6bc3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6bc8:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6bcd:	e8 be f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6bd2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6bd7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6bdc:	e9 24 fc ff ff       	jmp    6805 <w120+0x195>
    6be1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6be8:	48 89 ef             	mov    %rbp,%rdi
    6beb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    6bf0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6bf5:	e8 96 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6bfa:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    6bff:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    6c04:	e9 bf fc ff ff       	jmp    68c8 <w120+0x258>
    6c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c10:	4c 89 ef             	mov    %r13,%rdi
    6c13:	48 89 04 24          	mov    %rax,(%rsp)
    6c17:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c1c:	e8 6f f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c21:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
    6c27:	48 8b 04 24          	mov    (%rsp),%rax
    6c2b:	e9 6d fd ff ff       	jmp    699d <w120+0x32d>
    6c30:	48 89 c7             	mov    %rax,%rdi
    6c33:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6c38:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6c3e:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
    6c43:	e8 48 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c48:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6c4e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6c53:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6c58:	e9 f9 fd ff ff       	jmp    6a56 <w120+0x3e6>
    6c5d:	0f 1f 00             	nopl   (%rax)
    6c60:	48 89 c7             	mov    %rax,%rdi
    6c63:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    6c68:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
    6c6e:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6c74:	0f 29 14 24          	movaps %xmm2,(%rsp)
    6c78:	e8 13 f6 ff ff       	call   6290 <fwp_tape_grow.constprop.0>
    6c7d:	f2 0f 10 44 24 20    	movsd  0x20(%rsp),%xmm0
    6c83:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6c89:	66 0f 28 14 24       	movapd (%rsp),%xmm2
    6c8e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    6c93:	e9 9c fe ff ff       	jmp    6b34 <w120+0x4c4>
    6c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c9f:	00 
    6ca0:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    6ca4:	e9 35 fa ff ff       	jmp    66de <w120+0x6e>
    6ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cb0:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
    6cb5:	e9 fd fa ff ff       	jmp    67b7 <w120+0x147>
    6cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cc0:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
    6cc5:	e9 c0 fb ff ff       	jmp    688a <w120+0x21a>
    6cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cd0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    6cd5:	e9 7c fc ff ff       	jmp    6956 <w120+0x2e6>
    6cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6ce5:	e9 13 fd ff ff       	jmp    69fd <w120+0x38d>
    6cea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cf0:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6cf5:	e9 f8 fd ff ff       	jmp    6af2 <w120+0x482>
    6cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d00:	f2 0f 5c 0c 24       	subsd  (%rsp),%xmm1
    6d05:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    6d0a:	48 85 f6             	test   %rsi,%rsi
    6d0d:	79 69                	jns    6d78 <w120+0x708>
    6d0f:	f2 0f 10 05 d9 90 00 	movsd  0x90d9(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    6d16:	00 
    6d17:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    6d1c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6d23:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    6d2a:	f2 0f 5c 44 24 30    	subsd  0x30(%rsp),%xmm0
    6d30:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6d34:	f2 0f 59 0d c4 90 00 	mulsd  0x90c4(%rip),%xmm1        # fe00 <msg.4+0xc0>
    6d3b:	00 
    6d3c:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6d40:	e9 26 fe ff ff       	jmp    6b6b <w120+0x4fb>
    6d45:	48 8d 3d 78 84 00 00 	lea    0x8478(%rip),%rdi        # f1c4 <_IO_stdin_used+0x1c4>
    6d4c:	e8 bf d6 ff ff       	call   4410 <fwp_trap>
    6d51:	48 8d 3d c0 8c 00 00 	lea    0x8cc0(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    6d58:	e8 b3 d6 ff ff       	call   4410 <fwp_trap>
    6d5d:	0f 1f 00             	nopl   (%rax)
    6d60:	48 8d 3d 42 84 00 00 	lea    0x8442(%rip),%rdi        # f1a9 <_IO_stdin_used+0x1a9>
    6d67:	e8 a4 d6 ff ff       	call   4410 <fwp_trap>
    6d6c:	48 8d 3d ed 8c 00 00 	lea    0x8ced(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    6d73:	e8 98 d6 ff ff       	call   4410 <fwp_trap>
    6d78:	49 89 f6             	mov    %rsi,%r14
    6d7b:	f3 0f 7e 3d 6d 90 00 	movq   0x906d(%rip),%xmm7        # fdf0 <msg.4+0xb0>
    6d82:	00 
    6d83:	48 89 f3             	mov    %rsi,%rbx
    6d86:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    6d8b:	49 c1 fe 20          	sar    $0x20,%r14
    6d8f:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6d96:	e9 f3 f9 ff ff       	jmp    678e <w120+0x11e>
    6d9b:	f2 0f 10 3c 24       	movsd  (%rsp),%xmm7
    6da0:	f2 0f 59 3c 24       	mulsd  (%rsp),%xmm7
    6da5:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6dac:	66 49 0f 7e ff       	movq   %xmm7,%r15
    6db1:	e9 60 fb ff ff       	jmp    6916 <w120+0x2a6>
    6db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dbd:	00 00 00 

0000000000006dc0 <w176.constprop.0>:
    6dc0:	41 55                	push   %r13
    6dc2:	41 54                	push   %r12
    6dc4:	55                   	push   %rbp
    6dc5:	53                   	push   %rbx
    6dc6:	48 83 ec 28          	sub    $0x28,%rsp
    6dca:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    6dd1:	00 00 
    6dd3:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    6dd8:	48 8b 2f             	mov    (%rdi),%rbp
    6ddb:	48 c7 04 24 ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
    6de2:	ff 
    6de3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6dea:	00 00 
    6dec:	48 85 ed             	test   %rbp,%rbp
    6def:	74 5f                	je     6e50 <w176.constprop.0+0x90>
    6df1:	49 89 fd             	mov    %rdi,%r13
    6df4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6df8:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6dff:	31 db                	xor    %ebx,%ebx
    6e01:	0f 1f 40 00          	nopl   0x0(%rax)
    6e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e0c:	00 00 00 00 
    6e10:	49 8b 74 dd 10       	mov    0x10(%r13,%rbx,8),%rsi
    6e15:	f2 41 0f 10 4c dd 08 	movsd  0x8(%r13,%rbx,8),%xmm1
    6e1c:	48 89 e2             	mov    %rsp,%rdx
    6e1f:	48 83 c3 02          	add    $0x2,%rbx
    6e23:	e8 38 f6 ff ff       	call   6460 <w123>
    6e28:	48 89 c7             	mov    %rax,%rdi
    6e2b:	48 39 eb             	cmp    %rbp,%rbx
    6e2e:	72 e0                	jb     6e10 <w176.constprop.0+0x50>
    6e30:	48 89 f8             	mov    %rdi,%rax
    6e33:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    6e38:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6e3f:	00 00 
    6e41:	75 1a                	jne    6e5d <w176.constprop.0+0x9d>
    6e43:	48 83 c4 28          	add    $0x28,%rsp
    6e47:	5b                   	pop    %rbx
    6e48:	5d                   	pop    %rbp
    6e49:	41 5c                	pop    %r12
    6e4b:	41 5d                	pop    %r13
    6e4d:	c3                   	ret
    6e4e:	66 90                	xchg   %ax,%ax
    6e50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6e57:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e5b:	eb d3                	jmp    6e30 <w176.constprop.0+0x70>
    6e5d:	e8 de c5 ff ff       	call   3440 <__stack_chk_fail@plt>
    6e62:	0f 1f 00             	nopl   (%rax)
    6e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e6c:	00 00 00 00 

0000000000006e70 <fwp_rc_share>:
    6e70:	48 8b 05 61 5d 06 00 	mov    0x65d61(%rip),%rax        # 6cbd8 <fwp_heap+0x13d8>
    6e77:	48 2b 3d 32 5d 06 00 	sub    0x65d32(%rip),%rdi        # 6cbb0 <fwp_heap+0x13b0>
    6e7e:	48 c1 e0 10          	shl    $0x10,%rax
    6e82:	48 39 c7             	cmp    %rax,%rdi
    6e85:	73 4a                	jae    6ed1 <fwp_rc_share+0x61>
    6e87:	48 89 f8             	mov    %rdi,%rax
    6e8a:	48 c1 e8 10          	shr    $0x10,%rax
    6e8e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6e92:	48 8b 05 5f 5d 06 00 	mov    0x65d5f(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    6e99:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6e9d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6ea1:	48 85 d2             	test   %rdx,%rdx
    6ea4:	74 2b                	je     6ed1 <fwp_rc_share+0x61>
    6ea6:	0f b6 08             	movzbl (%rax),%ecx
    6ea9:	80 f9 02             	cmp    $0x2,%cl
    6eac:	74 2a                	je     6ed8 <fwp_rc_share+0x68>
    6eae:	80 f9 01             	cmp    $0x1,%cl
    6eb1:	75 1e                	jne    6ed1 <fwp_rc_share+0x61>
    6eb3:	8b 48 18             	mov    0x18(%rax),%ecx
    6eb6:	0f b7 ff             	movzwl %di,%edi
    6eb9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6ebc:	48 0f af f9          	imul   %rcx,%rdi
    6ec0:	48 c1 ef 20          	shr    $0x20,%rdi
    6ec4:	48 39 c7             	cmp    %rax,%rdi
    6ec7:	73 08                	jae    6ed1 <fwp_rc_share+0x61>
    6ec9:	48 01 fa             	add    %rdi,%rdx
    6ecc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6ecf:	75 0d                	jne    6ede <fwp_rc_share+0x6e>
    6ed1:	c3                   	ret
    6ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed8:	66 85 ff             	test   %di,%di
    6edb:	74 ef                	je     6ecc <fwp_rc_share+0x5c>
    6edd:	c3                   	ret
    6ede:	50                   	push   %rax
    6edf:	48 8d 3d aa 8b 00 00 	lea    0x8baa(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    6ee6:	e8 25 d5 ff ff       	call   4410 <fwp_trap>
    6eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ef0 <fwp_rc_fresh>:
    6ef0:	48 8b 15 e1 5c 06 00 	mov    0x65ce1(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    6ef7:	48 89 f8             	mov    %rdi,%rax
    6efa:	48 89 fe             	mov    %rdi,%rsi
    6efd:	48 2b 05 ac 5c 06 00 	sub    0x65cac(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    6f04:	48 c1 e2 10          	shl    $0x10,%rdx
    6f08:	48 39 d0             	cmp    %rdx,%rax
    6f0b:	73 4f                	jae    6f5c <fwp_rc_fresh+0x6c>
    6f0d:	48 89 c2             	mov    %rax,%rdx
    6f10:	48 c1 ea 10          	shr    $0x10,%rdx
    6f14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f18:	48 8b 15 d9 5c 06 00 	mov    0x65cd9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    6f1f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f27:	48 85 d2             	test   %rdx,%rdx
    6f2a:	74 30                	je     6f5c <fwp_rc_fresh+0x6c>
    6f2c:	0f b6 39             	movzbl (%rcx),%edi
    6f2f:	40 80 ff 02          	cmp    $0x2,%dil
    6f33:	74 2b                	je     6f60 <fwp_rc_fresh+0x70>
    6f35:	40 80 ff 01          	cmp    $0x1,%dil
    6f39:	75 21                	jne    6f5c <fwp_rc_fresh+0x6c>
    6f3b:	8b 79 18             	mov    0x18(%rcx),%edi
    6f3e:	0f b7 c0             	movzwl %ax,%eax
    6f41:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f44:	48 0f af c7          	imul   %rdi,%rax
    6f48:	48 c1 e8 20          	shr    $0x20,%rax
    6f4c:	48 39 c8             	cmp    %rcx,%rax
    6f4f:	73 0b                	jae    6f5c <fwp_rc_fresh+0x6c>
    6f51:	48 01 c2             	add    %rax,%rdx
    6f54:	80 3a ff             	cmpb   $0xff,(%rdx)
    6f57:	74 17                	je     6f70 <fwp_rc_fresh+0x80>
    6f59:	c6 02 01             	movb   $0x1,(%rdx)
    6f5c:	48 89 f0             	mov    %rsi,%rax
    6f5f:	c3                   	ret
    6f60:	66 85 c0             	test   %ax,%ax
    6f63:	74 ef                	je     6f54 <fwp_rc_fresh+0x64>
    6f65:	48 89 f0             	mov    %rsi,%rax
    6f68:	c3                   	ret
    6f69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f70:	48 83 ec 18          	sub    $0x18,%rsp
    6f74:	48 89 d7             	mov    %rdx,%rdi
    6f77:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6f7c:	48 89 14 24          	mov    %rdx,(%rsp)
    6f80:	e8 eb e7 ff ff       	call   5770 <fwp_rc_forget_slot>
    6f85:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6f8a:	48 8b 14 24          	mov    (%rsp),%rdx
    6f8e:	48 89 f0             	mov    %rsi,%rax
    6f91:	c6 02 01             	movb   $0x1,(%rdx)
    6f94:	48 83 c4 18          	add    $0x18,%rsp
    6f98:	c3                   	ret
    6f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006fa0 <fwp_rc_free_obj>:
    6fa0:	48 8b 15 31 5c 06 00 	mov    0x65c31(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    6fa7:	48 89 f8             	mov    %rdi,%rax
    6faa:	48 2b 05 ff 5b 06 00 	sub    0x65bff(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    6fb1:	48 c1 e2 10          	shl    $0x10,%rdx
    6fb5:	48 39 d0             	cmp    %rdx,%rax
    6fb8:	73 5b                	jae    7015 <fwp_rc_free_obj+0x75>
    6fba:	48 89 c2             	mov    %rax,%rdx
    6fbd:	48 c1 ea 10          	shr    $0x10,%rdx
    6fc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fc5:	48 8b 15 2c 5c 06 00 	mov    0x65c2c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    6fcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6fd0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6fd4:	48 85 c9             	test   %rcx,%rcx
    6fd7:	74 3c                	je     7015 <fwp_rc_free_obj+0x75>
    6fd9:	0f b6 32             	movzbl (%rdx),%esi
    6fdc:	40 80 fe 02          	cmp    $0x2,%sil
    6fe0:	74 2e                	je     7010 <fwp_rc_free_obj+0x70>
    6fe2:	40 80 fe 01          	cmp    $0x1,%sil
    6fe6:	75 2d                	jne    7015 <fwp_rc_free_obj+0x75>
    6fe8:	8b 72 18             	mov    0x18(%rdx),%esi
    6feb:	0f b7 c0             	movzwl %ax,%eax
    6fee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ff1:	48 0f af c6          	imul   %rsi,%rax
    6ff5:	48 c1 e8 20          	shr    $0x20,%rax
    6ff9:	48 39 d0             	cmp    %rdx,%rax
    6ffc:	73 17                	jae    7015 <fwp_rc_free_obj+0x75>
    6ffe:	48 01 c1             	add    %rax,%rcx
    7001:	80 39 01             	cmpb   $0x1,(%rcx)
    7004:	75 0f                	jne    7015 <fwp_rc_free_obj+0x75>
    7006:	e9 a5 e9 ff ff       	jmp    59b0 <fwp_mem_free>
    700b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7010:	66 85 c0             	test   %ax,%ax
    7013:	74 ec                	je     7001 <fwp_rc_free_obj+0x61>
    7015:	c3                   	ret
    7016:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    701d:	00 00 00 

0000000000007020 <fwp_rc_dup>:
    7020:	f3 0f 1e fa          	endbr64
    7024:	48 8b 05 ad 5b 06 00 	mov    0x65bad(%rip),%rax        # 6cbd8 <fwp_heap+0x13d8>
    702b:	48 2b 3d 7e 5b 06 00 	sub    0x65b7e(%rip),%rdi        # 6cbb0 <fwp_heap+0x13b0>
    7032:	48 c1 e0 10          	shl    $0x10,%rax
    7036:	48 39 c7             	cmp    %rax,%rdi
    7039:	73 60                	jae    709b <fwp_rc_dup+0x7b>
    703b:	48 89 f8             	mov    %rdi,%rax
    703e:	48 c1 e8 10          	shr    $0x10,%rax
    7042:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7046:	48 8b 05 ab 5b 06 00 	mov    0x65bab(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    704d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7051:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7055:	48 85 c0             	test   %rax,%rax
    7058:	74 41                	je     709b <fwp_rc_dup+0x7b>
    705a:	0f b6 0a             	movzbl (%rdx),%ecx
    705d:	80 f9 02             	cmp    $0x2,%cl
    7060:	74 3e                	je     70a0 <fwp_rc_dup+0x80>
    7062:	80 f9 01             	cmp    $0x1,%cl
    7065:	75 34                	jne    709b <fwp_rc_dup+0x7b>
    7067:	8b 4a 18             	mov    0x18(%rdx),%ecx
    706a:	0f b7 ff             	movzwl %di,%edi
    706d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7070:	48 0f af f9          	imul   %rcx,%rdi
    7074:	48 c1 ef 20          	shr    $0x20,%rdi
    7078:	48 39 d7             	cmp    %rdx,%rdi
    707b:	73 1e                	jae    709b <fwp_rc_dup+0x7b>
    707d:	48 01 f8             	add    %rdi,%rax
    7080:	0f b6 10             	movzbl (%rax),%edx
    7083:	84 d2                	test   %dl,%dl
    7085:	74 14                	je     709b <fwp_rc_dup+0x7b>
    7087:	8b 0d 3b 64 06 00    	mov    0x6643b(%rip),%ecx        # 6d4c8 <iteration_active>
    708d:	85 c9                	test   %ecx,%ecx
    708f:	75 1f                	jne    70b0 <fwp_rc_dup+0x90>
    7091:	80 fa fd             	cmp    $0xfd,%dl
    7094:	77 2a                	ja     70c0 <fwp_rc_dup+0xa0>
    7096:	83 c2 01             	add    $0x1,%edx
    7099:	88 10                	mov    %dl,(%rax)
    709b:	c3                   	ret
    709c:	0f 1f 40 00          	nopl   0x0(%rax)
    70a0:	66 85 ff             	test   %di,%di
    70a3:	74 db                	je     7080 <fwp_rc_dup+0x60>
    70a5:	c3                   	ret
    70a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70ad:	00 00 00 
    70b0:	48 83 05 f8 63 06 00 	addq   $0x1,0x663f8(%rip)        # 6d4b0 <iteration_retains>
    70b7:	01 
    70b8:	eb d7                	jmp    7091 <fwp_rc_dup+0x71>
    70ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70c0:	48 89 c7             	mov    %rax,%rdi
    70c3:	e9 88 e5 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    70c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70cf:	00 

00000000000070d0 <fwp_owned_entry173>:
    70d0:	f3 0f 1e fa          	endbr64
    70d4:	48 83 ec 38          	sub    $0x38,%rsp
    70d8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    70dd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    70e4:	00 00 
    70e6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    70eb:	31 c0                	xor    %eax,%eax
    70ed:	48 8b 07             	mov    (%rdi),%rax
    70f0:	48 03 47 10          	add    0x10(%rdi),%rax
    70f4:	0f 80 c2 00 00 00    	jo     71bc <fwp_owned_entry173+0xec>
    70fa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    70ff:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7104:	31 ff                	xor    %edi,%edi
    7106:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    710a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    710f:	e8 8c ef ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    7114:	48 8b 15 bd 5a 06 00 	mov    0x65abd(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    711b:	48 89 c6             	mov    %rax,%rsi
    711e:	48 2b 05 8b 5a 06 00 	sub    0x65a8b(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7125:	48 c1 e2 10          	shl    $0x10,%rdx
    7129:	48 39 d0             	cmp    %rdx,%rax
    712c:	73 4f                	jae    717d <fwp_owned_entry173+0xad>
    712e:	48 89 c2             	mov    %rax,%rdx
    7131:	48 c1 ea 10          	shr    $0x10,%rdx
    7135:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7139:	48 8b 15 b8 5a 06 00 	mov    0x65ab8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    7140:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7144:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7148:	48 85 d2             	test   %rdx,%rdx
    714b:	74 30                	je     717d <fwp_owned_entry173+0xad>
    714d:	0f b6 39             	movzbl (%rcx),%edi
    7150:	40 80 ff 02          	cmp    $0x2,%dil
    7154:	74 42                	je     7198 <fwp_owned_entry173+0xc8>
    7156:	40 80 ff 01          	cmp    $0x1,%dil
    715a:	75 21                	jne    717d <fwp_owned_entry173+0xad>
    715c:	8b 79 18             	mov    0x18(%rcx),%edi
    715f:	0f b7 c0             	movzwl %ax,%eax
    7162:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7165:	48 0f af c7          	imul   %rdi,%rax
    7169:	48 c1 e8 20          	shr    $0x20,%rax
    716d:	48 39 c8             	cmp    %rcx,%rax
    7170:	73 0b                	jae    717d <fwp_owned_entry173+0xad>
    7172:	48 01 c2             	add    %rax,%rdx
    7175:	80 3a ff             	cmpb   $0xff,(%rdx)
    7178:	74 26                	je     71a0 <fwp_owned_entry173+0xd0>
    717a:	c6 02 01             	movb   $0x1,(%rdx)
    717d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7182:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7189:	00 00 
    718b:	75 34                	jne    71c1 <fwp_owned_entry173+0xf1>
    718d:	48 89 f0             	mov    %rsi,%rax
    7190:	48 83 c4 38          	add    $0x38,%rsp
    7194:	c3                   	ret
    7195:	0f 1f 00             	nopl   (%rax)
    7198:	66 85 c0             	test   %ax,%ax
    719b:	75 e0                	jne    717d <fwp_owned_entry173+0xad>
    719d:	eb d6                	jmp    7175 <fwp_owned_entry173+0xa5>
    719f:	90                   	nop
    71a0:	48 89 d7             	mov    %rdx,%rdi
    71a3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    71a8:	48 89 14 24          	mov    %rdx,(%rsp)
    71ac:	e8 bf e5 ff ff       	call   5770 <fwp_rc_forget_slot>
    71b1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    71b6:	48 8b 14 24          	mov    (%rsp),%rdx
    71ba:	eb be                	jmp    717a <fwp_owned_entry173+0xaa>
    71bc:	e8 ff c4 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    71c1:	e8 7a c2 ff ff       	call   3440 <__stack_chk_fail@plt>
    71c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71cd:	00 00 00 

00000000000071d0 <e173>:
    71d0:	f3 0f 1e fa          	endbr64
    71d4:	53                   	push   %rbx
    71d5:	48 83 ec 30          	sub    $0x30,%rsp
    71d9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    71de:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    71e5:	00 00 
    71e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    71ec:	31 c0                	xor    %eax,%eax
    71ee:	48 8b 07             	mov    (%rdi),%rax
    71f1:	48 03 47 10          	add    0x10(%rdi),%rax
    71f5:	0f 80 c9 00 00 00    	jo     72c4 <e173+0xf4>
    71fb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7200:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7205:	31 ff                	xor    %edi,%edi
    7207:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    720b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7210:	e8 8b ee ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    7215:	48 8b 15 bc 59 06 00 	mov    0x659bc(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    721c:	48 89 c3             	mov    %rax,%rbx
    721f:	48 2b 05 8a 59 06 00 	sub    0x6598a(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7226:	48 c1 e2 10          	shl    $0x10,%rdx
    722a:	48 39 d0             	cmp    %rdx,%rax
    722d:	73 4f                	jae    727e <e173+0xae>
    722f:	48 89 c2             	mov    %rax,%rdx
    7232:	48 c1 ea 10          	shr    $0x10,%rdx
    7236:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    723a:	48 8b 15 b7 59 06 00 	mov    0x659b7(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    7241:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7245:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7249:	48 85 d2             	test   %rdx,%rdx
    724c:	74 30                	je     727e <e173+0xae>
    724e:	0f b6 31             	movzbl (%rcx),%esi
    7251:	40 80 fe 02          	cmp    $0x2,%sil
    7255:	74 49                	je     72a0 <e173+0xd0>
    7257:	40 80 fe 01          	cmp    $0x1,%sil
    725b:	75 21                	jne    727e <e173+0xae>
    725d:	8b 71 18             	mov    0x18(%rcx),%esi
    7260:	0f b7 c0             	movzwl %ax,%eax
    7263:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7266:	48 0f af c6          	imul   %rsi,%rax
    726a:	48 c1 e8 20          	shr    $0x20,%rax
    726e:	48 39 c8             	cmp    %rcx,%rax
    7271:	73 0b                	jae    727e <e173+0xae>
    7273:	48 01 c2             	add    %rax,%rdx
    7276:	80 3a ff             	cmpb   $0xff,(%rdx)
    7279:	74 35                	je     72b0 <e173+0xe0>
    727b:	c6 02 01             	movb   $0x1,(%rdx)
    727e:	48 89 df             	mov    %rbx,%rdi
    7281:	e8 ea fb ff ff       	call   6e70 <fwp_rc_share>
    7286:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    728b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7292:	00 00 
    7294:	75 33                	jne    72c9 <e173+0xf9>
    7296:	48 83 c4 30          	add    $0x30,%rsp
    729a:	48 89 d8             	mov    %rbx,%rax
    729d:	5b                   	pop    %rbx
    729e:	c3                   	ret
    729f:	90                   	nop
    72a0:	66 85 c0             	test   %ax,%ax
    72a3:	75 d9                	jne    727e <e173+0xae>
    72a5:	eb cf                	jmp    7276 <e173+0xa6>
    72a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ae:	00 00 
    72b0:	48 89 d7             	mov    %rdx,%rdi
    72b3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72b8:	e8 b3 e4 ff ff       	call   5770 <fwp_rc_forget_slot>
    72bd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72c2:	eb b7                	jmp    727b <e173+0xab>
    72c4:	e8 f7 c3 ff ff       	call   36c0 <fwp_trap_overflow.constprop.0>
    72c9:	e8 72 c1 ff ff       	call   3440 <__stack_chk_fail@plt>
    72ce:	66 90                	xchg   %ax,%ax

00000000000072d0 <fwp_closure_drop>:
    72d0:	48 8b 15 01 59 06 00 	mov    0x65901(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    72d7:	48 89 f8             	mov    %rdi,%rax
    72da:	48 2b 05 cf 58 06 00 	sub    0x658cf(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    72e1:	48 c1 e2 10          	shl    $0x10,%rdx
    72e5:	48 39 d0             	cmp    %rdx,%rax
    72e8:	73 6b                	jae    7355 <fwp_closure_drop+0x85>
    72ea:	48 89 c2             	mov    %rax,%rdx
    72ed:	48 c1 ea 10          	shr    $0x10,%rdx
    72f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72f5:	48 8b 15 fc 58 06 00 	mov    0x658fc(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    72fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7300:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7304:	48 85 d2             	test   %rdx,%rdx
    7307:	74 4c                	je     7355 <fwp_closure_drop+0x85>
    7309:	0f b6 31             	movzbl (%rcx),%esi
    730c:	40 80 fe 02          	cmp    $0x2,%sil
    7310:	74 3e                	je     7350 <fwp_closure_drop+0x80>
    7312:	40 80 fe 01          	cmp    $0x1,%sil
    7316:	75 3d                	jne    7355 <fwp_closure_drop+0x85>
    7318:	8b 71 18             	mov    0x18(%rcx),%esi
    731b:	0f b7 c0             	movzwl %ax,%eax
    731e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7321:	48 0f af c6          	imul   %rsi,%rax
    7325:	48 c1 e8 20          	shr    $0x20,%rax
    7329:	48 39 c8             	cmp    %rcx,%rax
    732c:	73 27                	jae    7355 <fwp_closure_drop+0x85>
    732e:	48 01 c2             	add    %rax,%rdx
    7331:	0f b6 02             	movzbl (%rdx),%eax
    7334:	84 c0                	test   %al,%al
    7336:	74 1d                	je     7355 <fwp_closure_drop+0x85>
    7338:	3c 01                	cmp    $0x1,%al
    733a:	74 24                	je     7360 <fwp_closure_drop+0x90>
    733c:	3c ff                	cmp    $0xff,%al
    733e:	74 48                	je     7388 <fwp_closure_drop+0xb8>
    7340:	83 e8 01             	sub    $0x1,%eax
    7343:	88 02                	mov    %al,(%rdx)
    7345:	c3                   	ret
    7346:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    734d:	00 00 00 
    7350:	66 85 c0             	test   %ax,%ax
    7353:	74 dc                	je     7331 <fwp_closure_drop+0x61>
    7355:	c3                   	ret
    7356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    735d:	00 00 00 
    7360:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7367:	ff ff 
    7369:	48 85 c0             	test   %rax,%rax
    736c:	74 12                	je     7380 <fwp_closure_drop+0xb0>
    736e:	48 89 fe             	mov    %rdi,%rsi
    7371:	48 89 c7             	mov    %rax,%rdi
    7374:	e9 f7 d0 ff ff       	jmp    4470 <fwp_closure_drop_push>
    7379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7380:	e9 9b d2 ff ff       	jmp    4620 <fwp_closure_drop.part.0>
    7385:	0f 1f 00             	nopl   (%rax)
    7388:	48 89 d0             	mov    %rdx,%rax
    738b:	48 8d 35 6e 44 06 00 	lea    0x6446e(%rip),%rsi        # 6b800 <fwp_heap>
    7392:	48 83 ec 18          	sub    $0x18,%rsp
    7396:	48 c1 e8 11          	shr    $0x11,%rax
    739a:	48 31 d0             	xor    %rdx,%rax
    739d:	48 89 c1             	mov    %rax,%rcx
    73a0:	48 c1 e9 09          	shr    $0x9,%rcx
    73a4:	48 31 c8             	xor    %rcx,%rax
    73a7:	0f b6 c8             	movzbl %al,%ecx
    73aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    73b1:	00 
    73b2:	48 85 c0             	test   %rax,%rax
    73b5:	75 12                	jne    73c9 <fwp_closure_drop+0xf9>
    73b7:	eb 49                	jmp    7402 <fwp_closure_drop+0x132>
    73b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    73c4:	48 85 c0             	test   %rax,%rax
    73c7:	74 39                	je     7402 <fwp_closure_drop+0x132>
    73c9:	48 89 c1             	mov    %rax,%rcx
    73cc:	48 39 10             	cmp    %rdx,(%rax)
    73cf:	75 ef                	jne    73c0 <fwp_closure_drop+0xf0>
    73d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    73d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    73dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    73e4:	74 05                	je     73eb <fwp_closure_drop+0x11b>
    73e6:	48 83 c4 18          	add    $0x18,%rsp
    73ea:	c3                   	ret
    73eb:	48 89 d7             	mov    %rdx,%rdi
    73ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73f3:	e8 78 e3 ff ff       	call   5770 <fwp_rc_forget_slot>
    73f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7400:	eb e4                	jmp    73e6 <fwp_closure_drop+0x116>
    7402:	48 8d 3d e7 85 00 00 	lea    0x85e7(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7409:	e8 02 d0 ff ff       	call   4410 <fwp_trap>
    740e:	66 90                	xchg   %ax,%ax

0000000000007410 <fwp_owned_tape_release>:
    7410:	48 85 ff             	test   %rdi,%rdi
    7413:	0f 84 f7 00 00 00    	je     7510 <fwp_owned_tape_release+0x100>
    7419:	41 54                	push   %r12
    741b:	55                   	push   %rbp
    741c:	53                   	push   %rbx
    741d:	48 8b 07             	mov    (%rdi),%rax
    7420:	48 85 c0             	test   %rax,%rax
    7423:	74 08                	je     742d <fwp_owned_tape_release+0x1d>
    7425:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7429:	48 89 50 08          	mov    %rdx,0x8(%rax)
    742d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7431:	48 85 d2             	test   %rdx,%rdx
    7434:	74 03                	je     7439 <fwp_owned_tape_release+0x29>
    7436:	48 89 02             	mov    %rax,(%rdx)
    7439:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    743d:	48 89 fb             	mov    %rdi,%rbx
    7440:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7444:	48 85 c0             	test   %rax,%rax
    7447:	0f 84 89 00 00 00    	je     74d6 <fwp_owned_tape_release+0xc6>
    744d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7451:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7455:	7e 47                	jle    749e <fwp_owned_tape_release+0x8e>
    7457:	31 ed                	xor    %ebp,%ebp
    7459:	eb 0d                	jmp    7468 <fwp_owned_tape_release+0x58>
    745b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7460:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7464:	48 8b 40 68          	mov    0x68(%rax),%rax
    7468:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    746c:	49 89 ec             	mov    %rbp,%r12
    746f:	48 83 c5 01          	add    $0x1,%rbp
    7473:	49 c1 e4 04          	shl    $0x4,%r12
    7477:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    747b:	ff d0                	call   *%rax
    747d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7481:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7486:	48 8b 43 10          	mov    0x10(%rbx),%rax
    748a:	ff 50 68             	call   *0x68(%rax)
    748d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7491:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7495:	48 39 e8             	cmp    %rbp,%rax
    7498:	7f c6                	jg     7460 <fwp_owned_tape_release+0x50>
    749a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    749e:	31 ed                	xor    %ebp,%ebp
    74a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    74a5:	7e 28                	jle    74cf <fwp_owned_tape_release+0xbf>
    74a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74ae:	00 00 
    74b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    74b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    74b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    74bc:	74 07                	je     74c5 <fwp_owned_tape_release+0xb5>
    74be:	ff 52 68             	call   *0x68(%rdx)
    74c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    74c5:	48 83 c5 01          	add    $0x1,%rbp
    74c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    74cd:	7f e1                	jg     74b0 <fwp_owned_tape_release+0xa0>
    74cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    74d3:	ff 52 68             	call   *0x68(%rdx)
    74d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    74da:	e8 f1 fd ff ff       	call   72d0 <fwp_closure_drop>
    74df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    74e3:	e8 e8 fd ff ff       	call   72d0 <fwp_closure_drop>
    74e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    74ec:	e8 df fd ff ff       	call   72d0 <fwp_closure_drop>
    74f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    74f5:	e8 b6 e4 ff ff       	call   59b0 <fwp_mem_free>
    74fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    74fe:	e8 ad e4 ff ff       	call   59b0 <fwp_mem_free>
    7503:	48 89 df             	mov    %rbx,%rdi
    7506:	5b                   	pop    %rbx
    7507:	5d                   	pop    %rbp
    7508:	41 5c                	pop    %r12
    750a:	e9 a1 e4 ff ff       	jmp    59b0 <fwp_mem_free>
    750f:	90                   	nop
    7510:	c3                   	ret
    7511:	0f 1f 40 00          	nopl   0x0(%rax)
    7515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    751c:	00 00 00 00 

0000000000007520 <fwp_tape_finish>:
    7520:	f3 0f 1e fa          	endbr64
    7524:	41 55                	push   %r13
    7526:	41 54                	push   %r12
    7528:	55                   	push   %rbp
    7529:	53                   	push   %rbx
    752a:	48 83 ec 38          	sub    $0x38,%rsp
    752e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7535:	00 00 
    7537:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    753c:	48 8d 3d 5d bb 01 00 	lea    0x1bb5d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    7543:	e8 b8 db ff ff       	call   5100 <fwp_tape_buffers_dispose>
    7548:	48 83 3d 88 bb 01 00 	cmpq   $0x0,0x1bb88(%rip)        # 230d8 <fwp_ntapes>
    754f:	00 
    7550:	48 c7 05 2d bb 01 00 	movq   $0x0,0x1bb2d(%rip)        # 23088 <fwp_tape_cached_bytes>
    7557:	00 00 00 00 
    755b:	7e 6f                	jle    75cc <fwp_tape_finish+0xac>
    755d:	45 31 e4             	xor    %r12d,%r12d
    7560:	31 ed                	xor    %ebp,%ebp
    7562:	0f 1f 00             	nopl   (%rax)
    7565:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    756c:	00 00 00 00 
    7570:	48 8b 1d 69 bb 01 00 	mov    0x1bb69(%rip),%rbx        # 230e0 <fwp_tapes>
    7577:	48 83 c5 01          	add    $0x1,%rbp
    757b:	4c 01 e3             	add    %r12,%rbx
    757e:	49 83 c4 58          	add    $0x58,%r12
    7582:	48 89 df             	mov    %rbx,%rdi
    7585:	e8 c6 c6 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    758a:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    758f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    7593:	48 89 e7             	mov    %rsp,%rdi
    7596:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    759b:	0f 29 04 24          	movaps %xmm0,(%rsp)
    759f:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    75a4:	0f 16 43 38          	movhps 0x38(%rbx),%xmm0
    75a8:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
    75ad:	e8 4e db ff ff       	call   5100 <fwp_tape_buffers_dispose>
    75b2:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
    75b6:	e8 55 fe ff ff       	call   7410 <fwp_owned_tape_release>
    75bb:	48 39 2d 16 bb 01 00 	cmp    %rbp,0x1bb16(%rip)        # 230d8 <fwp_ntapes>
    75c2:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    75c9:	00 
    75ca:	7f a4                	jg     7570 <fwp_tape_finish+0x50>
    75cc:	48 8b 3d 0d bb 01 00 	mov    0x1bb0d(%rip),%rdi        # 230e0 <fwp_tapes>
    75d3:	48 85 ff             	test   %rdi,%rdi
    75d6:	74 05                	je     75dd <fwp_tape_finish+0xbd>
    75d8:	e8 b3 da ff ff       	call   5090 <ad_raw_free.part.0>
    75dd:	48 c7 05 f8 ba 01 00 	movq   $0x0,0x1baf8(%rip)        # 230e0 <fwp_tapes>
    75e4:	00 00 00 00 
    75e8:	48 c7 05 dd ba 01 00 	movq   $0x0,0x1badd(%rip)        # 230d0 <fwp_tapes_cap>
    75ef:	00 00 00 00 
    75f3:	48 c7 05 da ba 01 00 	movq   $0x0,0x1bada(%rip)        # 230d8 <fwp_ntapes>
    75fa:	00 00 00 00 
    75fe:	48 c7 05 bf ba 01 00 	movq   $0x0,0x1babf(%rip)        # 230c8 <fwp_tape_next_slot>
    7605:	00 00 00 00 
    7609:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    760e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7615:	00 00 
    7617:	75 0b                	jne    7624 <fwp_tape_finish+0x104>
    7619:	48 83 c4 38          	add    $0x38,%rsp
    761d:	5b                   	pop    %rbx
    761e:	5d                   	pop    %rbp
    761f:	41 5c                	pop    %r12
    7621:	41 5d                	pop    %r13
    7623:	c3                   	ret
    7624:	e8 17 be ff ff       	call   3440 <__stack_chk_fail@plt>
    7629:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007630 <fwp_tape_scope_release>:
    7630:	f3 0f 1e fa          	endbr64
    7634:	41 55                	push   %r13
    7636:	41 54                	push   %r12
    7638:	55                   	push   %rbp
    7639:	53                   	push   %rbx
    763a:	48 83 ec 38          	sub    $0x38,%rsp
    763e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7645:	00 00 
    7647:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    764c:	48 63 07             	movslq (%rdi),%rax
    764f:	85 c0                	test   %eax,%eax
    7651:	0f 88 da 00 00 00    	js     7731 <fwp_tape_scope_release+0x101>
    7657:	49 bc a3 8b 2e ba e8 	movabs $0x2e8ba2e8ba2e8ba3,%r12
    765e:	a2 8b 2e 
    7661:	48 89 fb             	mov    %rdi,%rbx
    7664:	48 89 e5             	mov    %rsp,%rbp
    7667:	eb 1f                	jmp    7688 <fwp_tape_scope_release+0x58>
    7669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7670:	e8 8b da ff ff       	call   5100 <fwp_tape_buffers_dispose>
    7675:	4c 89 ef             	mov    %r13,%rdi
    7678:	e8 93 fd ff ff       	call   7410 <fwp_owned_tape_release>
    767d:	48 63 03             	movslq (%rbx),%rax
    7680:	85 c0                	test   %eax,%eax
    7682:	0f 88 a9 00 00 00    	js     7731 <fwp_tape_scope_release+0x101>
    7688:	4c 6b c0 58          	imul   $0x58,%rax,%r8
    768c:	48 8b 35 4d ba 01 00 	mov    0x1ba4d(%rip),%rsi        # 230e0 <fwp_tapes>
    7693:	4c 01 c6             	add    %r8,%rsi
    7696:	48 89 f7             	mov    %rsi,%rdi
    7699:	e8 b2 c5 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    769e:	f3 0f 6f 46 20       	movdqu 0x20(%rsi),%xmm0
    76a3:	48 8b 46 30          	mov    0x30(%rsi),%rax
    76a7:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    76ae:	4c 8b 6e 50          	mov    0x50(%rsi),%r13
    76b2:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    76b9:	00 
    76ba:	0f 29 04 24          	movaps %xmm0,(%rsp)
    76be:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    76c3:	0f 16 46 38          	movhps 0x38(%rsi),%xmm0
    76c7:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
    76cc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76d0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    76d5:	48 c7 46 50 00 00 00 	movq   $0x0,0x50(%rsi)
    76dc:	00 
    76dd:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    76e4:	00 
    76e5:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    76ec:	00 
    76ed:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    76f1:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    76f5:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    76fb:	77 18                	ja     7715 <fwp_tape_scope_release+0xe5>
    76fd:	49 c1 f8 03          	sar    $0x3,%r8
    7701:	4d 0f af c4          	imul   %r12,%r8
    7705:	4c 3b 05 bc b9 01 00 	cmp    0x1b9bc(%rip),%r8        # 230c8 <fwp_tape_next_slot>
    770c:	7d 07                	jge    7715 <fwp_tape_scope_release+0xe5>
    770e:	4c 89 05 b3 b9 01 00 	mov    %r8,0x1b9b3(%rip)        # 230c8 <fwp_tape_next_slot>
    7715:	48 89 ef             	mov    %rbp,%rdi
    7718:	4d 85 ed             	test   %r13,%r13
    771b:	0f 85 4f ff ff ff    	jne    7670 <fwp_tape_scope_release+0x40>
    7721:	e8 fa da ff ff       	call   5220 <fwp_tape_buffers_release>
    7726:	48 63 03             	movslq (%rbx),%rax
    7729:	85 c0                	test   %eax,%eax
    772b:	0f 89 57 ff ff ff    	jns    7688 <fwp_tape_scope_release+0x58>
    7731:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7736:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    773d:	00 00 
    773f:	75 0b                	jne    774c <fwp_tape_scope_release+0x11c>
    7741:	48 83 c4 38          	add    $0x38,%rsp
    7745:	5b                   	pop    %rbx
    7746:	5d                   	pop    %rbp
    7747:	41 5c                	pop    %r12
    7749:	41 5d                	pop    %r13
    774b:	c3                   	ret
    774c:	e8 ef bc ff ff       	call   3440 <__stack_chk_fail@plt>
    7751:	0f 1f 40 00          	nopl   0x0(%rax)
    7755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    775c:	00 00 00 00 

0000000000007760 <fwp_drop4>:
    7760:	48 8b 0d 71 54 06 00 	mov    0x65471(%rip),%rcx        # 6cbd8 <fwp_heap+0x13d8>
    7767:	48 89 f8             	mov    %rdi,%rax
    776a:	48 2b 05 3f 54 06 00 	sub    0x6543f(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7771:	48 c1 e1 10          	shl    $0x10,%rcx
    7775:	48 39 c8             	cmp    %rcx,%rax
    7778:	0f 83 42 01 00 00    	jae    78c0 <fwp_drop4+0x160>
    777e:	48 83 ec 18          	sub    $0x18,%rsp
    7782:	48 89 fa             	mov    %rdi,%rdx
    7785:	4c 8d 05 74 40 06 00 	lea    0x64074(%rip),%r8        # 6b800 <fwp_heap>
    778c:	48 89 c1             	mov    %rax,%rcx
    778f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7796:	48 c1 e9 10          	shr    $0x10,%rcx
    779a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    779e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    77a2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    77a6:	48 85 c9             	test   %rcx,%rcx
    77a9:	74 40                	je     77eb <fwp_drop4+0x8b>
    77ab:	0f b6 3e             	movzbl (%rsi),%edi
    77ae:	40 80 ff 02          	cmp    $0x2,%dil
    77b2:	74 3c                	je     77f0 <fwp_drop4+0x90>
    77b4:	40 80 ff 01          	cmp    $0x1,%dil
    77b8:	75 31                	jne    77eb <fwp_drop4+0x8b>
    77ba:	8b 7e 18             	mov    0x18(%rsi),%edi
    77bd:	0f b7 c0             	movzwl %ax,%eax
    77c0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    77c3:	48 0f af c7          	imul   %rdi,%rax
    77c7:	48 c1 e8 20          	shr    $0x20,%rax
    77cb:	48 39 f0             	cmp    %rsi,%rax
    77ce:	73 1b                	jae    77eb <fwp_drop4+0x8b>
    77d0:	48 01 c1             	add    %rax,%rcx
    77d3:	0f b6 01             	movzbl (%rcx),%eax
    77d6:	84 c0                	test   %al,%al
    77d8:	74 11                	je     77eb <fwp_drop4+0x8b>
    77da:	3c 01                	cmp    $0x1,%al
    77dc:	74 22                	je     7800 <fwp_drop4+0xa0>
    77de:	3c ff                	cmp    $0xff,%al
    77e0:	0f 84 0a 01 00 00    	je     78f0 <fwp_drop4+0x190>
    77e6:	83 e8 01             	sub    $0x1,%eax
    77e9:	88 01                	mov    %al,(%rcx)
    77eb:	48 83 c4 18          	add    $0x18,%rsp
    77ef:	c3                   	ret
    77f0:	66 85 c0             	test   %ax,%ax
    77f3:	74 de                	je     77d3 <fwp_drop4+0x73>
    77f5:	48 83 c4 18          	add    $0x18,%rsp
    77f9:	c3                   	ret
    77fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7800:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7804:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    780b:	48 89 f8             	mov    %rdi,%rax
    780e:	48 c1 e1 10          	shl    $0x10,%rcx
    7812:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7819:	48 39 c8             	cmp    %rcx,%rax
    781c:	73 62                	jae    7880 <fwp_drop4+0x120>
    781e:	48 89 c1             	mov    %rax,%rcx
    7821:	48 c1 e9 10          	shr    $0x10,%rcx
    7825:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7829:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    782d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7831:	48 85 c9             	test   %rcx,%rcx
    7834:	74 4a                	je     7880 <fwp_drop4+0x120>
    7836:	44 0f b6 0e          	movzbl (%rsi),%r9d
    783a:	41 80 f9 02          	cmp    $0x2,%r9b
    783e:	0f 84 9c 00 00 00    	je     78e0 <fwp_drop4+0x180>
    7844:	41 80 f9 01          	cmp    $0x1,%r9b
    7848:	75 36                	jne    7880 <fwp_drop4+0x120>
    784a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    784e:	0f b7 c0             	movzwl %ax,%eax
    7851:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7854:	49 0f af c1          	imul   %r9,%rax
    7858:	48 c1 e8 20          	shr    $0x20,%rax
    785c:	48 39 f0             	cmp    %rsi,%rax
    785f:	73 1f                	jae    7880 <fwp_drop4+0x120>
    7861:	48 01 c1             	add    %rax,%rcx
    7864:	0f b6 01             	movzbl (%rcx),%eax
    7867:	84 c0                	test   %al,%al
    7869:	74 15                	je     7880 <fwp_drop4+0x120>
    786b:	3c 01                	cmp    $0x1,%al
    786d:	74 59                	je     78c8 <fwp_drop4+0x168>
    786f:	3c ff                	cmp    $0xff,%al
    7871:	0f 84 ef 00 00 00    	je     7966 <fwp_drop4+0x206>
    7877:	83 e8 01             	sub    $0x1,%eax
    787a:	88 01                	mov    %al,(%rcx)
    787c:	0f 1f 40 00          	nopl   0x0(%rax)
    7880:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7884:	48 89 d7             	mov    %rdx,%rdi
    7887:	48 89 0c 24          	mov    %rcx,(%rsp)
    788b:	e8 10 f7 ff ff       	call   6fa0 <fwp_rc_free_obj>
    7890:	4c 8d 05 69 3f 06 00 	lea    0x63f69(%rip),%r8        # 6b800 <fwp_heap>
    7897:	48 8b 04 24          	mov    (%rsp),%rax
    789b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    78a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    78a9:	48 c1 e2 10          	shl    $0x10,%rdx
    78ad:	48 39 d0             	cmp    %rdx,%rax
    78b0:	0f 83 35 ff ff ff    	jae    77eb <fwp_drop4+0x8b>
    78b6:	48 8b 14 24          	mov    (%rsp),%rdx
    78ba:	e9 cd fe ff ff       	jmp    778c <fwp_drop4+0x2c>
    78bf:	90                   	nop
    78c0:	c3                   	ret
    78c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78c8:	48 89 14 24          	mov    %rdx,(%rsp)
    78cc:	e8 cf f6 ff ff       	call   6fa0 <fwp_rc_free_obj>
    78d1:	48 8b 14 24          	mov    (%rsp),%rdx
    78d5:	eb a9                	jmp    7880 <fwp_drop4+0x120>
    78d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78de:	00 00 
    78e0:	66 85 c0             	test   %ax,%ax
    78e3:	75 9b                	jne    7880 <fwp_drop4+0x120>
    78e5:	e9 7a ff ff ff       	jmp    7864 <fwp_drop4+0x104>
    78ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78f0:	48 89 c8             	mov    %rcx,%rax
    78f3:	48 c1 e8 11          	shr    $0x11,%rax
    78f7:	48 31 c8             	xor    %rcx,%rax
    78fa:	48 89 c2             	mov    %rax,%rdx
    78fd:	48 c1 ea 09          	shr    $0x9,%rdx
    7901:	48 31 d0             	xor    %rdx,%rax
    7904:	0f b6 d0             	movzbl %al,%edx
    7907:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    790e:	00 
    790f:	48 85 c0             	test   %rax,%rax
    7912:	75 19                	jne    792d <fwp_drop4+0x1cd>
    7914:	e9 d3 00 00 00       	jmp    79ec <fwp_drop4+0x28c>
    7919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7920:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7924:	48 85 c0             	test   %rax,%rax
    7927:	0f 84 bf 00 00 00    	je     79ec <fwp_drop4+0x28c>
    792d:	48 89 c2             	mov    %rax,%rdx
    7930:	48 39 08             	cmp    %rcx,(%rax)
    7933:	75 eb                	jne    7920 <fwp_drop4+0x1c0>
    7935:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7939:	48 83 ea 01          	sub    $0x1,%rdx
    793d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7941:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7948:	0f 85 9d fe ff ff    	jne    77eb <fwp_drop4+0x8b>
    794e:	48 89 cf             	mov    %rcx,%rdi
    7951:	48 89 0c 24          	mov    %rcx,(%rsp)
    7955:	e8 16 de ff ff       	call   5770 <fwp_rc_forget_slot>
    795a:	48 8b 0c 24          	mov    (%rsp),%rcx
    795e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7961:	e9 85 fe ff ff       	jmp    77eb <fwp_drop4+0x8b>
    7966:	48 89 ce             	mov    %rcx,%rsi
    7969:	48 c1 ee 11          	shr    $0x11,%rsi
    796d:	48 31 ce             	xor    %rcx,%rsi
    7970:	48 89 f0             	mov    %rsi,%rax
    7973:	48 c1 e8 09          	shr    $0x9,%rax
    7977:	48 31 c6             	xor    %rax,%rsi
    797a:	40 0f b6 f6          	movzbl %sil,%esi
    797e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7985:	00 
    7986:	48 85 c0             	test   %rax,%rax
    7989:	75 1e                	jne    79a9 <fwp_drop4+0x249>
    798b:	eb 5f                	jmp    79ec <fwp_drop4+0x28c>
    798d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7994:	00 
    7995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    799c:	00 00 00 00 
    79a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    79a4:	48 85 c0             	test   %rax,%rax
    79a7:	74 43                	je     79ec <fwp_drop4+0x28c>
    79a9:	48 89 c6             	mov    %rax,%rsi
    79ac:	48 39 08             	cmp    %rcx,(%rax)
    79af:	75 ef                	jne    79a0 <fwp_drop4+0x240>
    79b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79b5:	48 83 ee 01          	sub    $0x1,%rsi
    79b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    79bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    79c4:	0f 85 b6 fe ff ff    	jne    7880 <fwp_drop4+0x120>
    79ca:	48 89 cf             	mov    %rcx,%rdi
    79cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    79d6:	e8 95 dd ff ff       	call   5770 <fwp_rc_forget_slot>
    79db:	48 8b 0c 24          	mov    (%rsp),%rcx
    79df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    79e7:	e9 94 fe ff ff       	jmp    7880 <fwp_drop4+0x120>
    79ec:	48 8d 3d fd 7f 00 00 	lea    0x7ffd(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    79f3:	e8 18 ca ff ff       	call   4410 <fwp_trap>
    79f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    79ff:	00 

0000000000007a00 <fwp_arg_drop37>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	85 f6                	test   %esi,%esi
    7a06:	75 04                	jne    7a0c <fwp_arg_drop37+0xc>
    7a08:	85 d2                	test   %edx,%edx
    7a0a:	75 04                	jne    7a10 <fwp_arg_drop37+0x10>
    7a0c:	c3                   	ret
    7a0d:	0f 1f 00             	nopl   (%rax)
    7a10:	48 8b 3f             	mov    (%rdi),%rdi
    7a13:	e9 48 fd ff ff       	jmp    7760 <fwp_drop4>
    7a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7a1f:	00 

0000000000007a20 <fwp_task_dispose>:
    7a20:	53                   	push   %rbx
    7a21:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7a25:	0f 84 db bc ff ff    	je     3706 <fwp_task_dispose.cold>
    7a2b:	48 89 fb             	mov    %rdi,%rbx
    7a2e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7a33:	0f 85 cd bc ff ff    	jne    3706 <fwp_task_dispose.cold>
    7a39:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    7a3d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7a44:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    7a4b:	00 
    7a4c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7a50:	48 85 ff             	test   %rdi,%rdi
    7a53:	74 07                	je     7a5c <fwp_task_dispose+0x3c>
    7a55:	48 85 c0             	test   %rax,%rax
    7a58:	74 02                	je     7a5c <fwp_task_dispose+0x3c>
    7a5a:	ff d0                	call   *%rax
    7a5c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7a63:	e8 48 df ff ff       	call   59b0 <fwp_mem_free>
    7a68:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    7a6f:	00 00 00 00 
    7a73:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7a77:	74 6f                	je     7ae8 <fwp_task_dispose+0xc8>
    7a79:	48 8b 15 58 51 06 00 	mov    0x65158(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    7a80:	48 89 d8             	mov    %rbx,%rax
    7a83:	48 2b 05 26 51 06 00 	sub    0x65126(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7a8a:	48 c1 e2 10          	shl    $0x10,%rdx
    7a8e:	48 39 d0             	cmp    %rdx,%rax
    7a91:	73 4c                	jae    7adf <fwp_task_dispose+0xbf>
    7a93:	48 89 c2             	mov    %rax,%rdx
    7a96:	48 c1 ea 10          	shr    $0x10,%rdx
    7a9a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a9e:	48 8b 15 53 51 06 00 	mov    0x65153(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    7aa5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7aa9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7aad:	48 85 c9             	test   %rcx,%rcx
    7ab0:	74 2d                	je     7adf <fwp_task_dispose+0xbf>
    7ab2:	0f b6 32             	movzbl (%rdx),%esi
    7ab5:	40 80 fe 02          	cmp    $0x2,%sil
    7ab9:	74 3d                	je     7af8 <fwp_task_dispose+0xd8>
    7abb:	40 80 fe 01          	cmp    $0x1,%sil
    7abf:	75 1e                	jne    7adf <fwp_task_dispose+0xbf>
    7ac1:	8b 72 18             	mov    0x18(%rdx),%esi
    7ac4:	0f b7 c0             	movzwl %ax,%eax
    7ac7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aca:	48 0f af c6          	imul   %rsi,%rax
    7ace:	48 c1 e8 20          	shr    $0x20,%rax
    7ad2:	48 39 d0             	cmp    %rdx,%rax
    7ad5:	73 08                	jae    7adf <fwp_task_dispose+0xbf>
    7ad7:	48 01 c1             	add    %rax,%rcx
    7ada:	80 39 01             	cmpb   $0x1,(%rcx)
    7add:	74 09                	je     7ae8 <fwp_task_dispose+0xc8>
    7adf:	5b                   	pop    %rbx
    7ae0:	c3                   	ret
    7ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ae8:	48 89 df             	mov    %rbx,%rdi
    7aeb:	5b                   	pop    %rbx
    7aec:	e9 bf de ff ff       	jmp    59b0 <fwp_mem_free>
    7af1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7af8:	66 85 c0             	test   %ax,%ax
    7afb:	74 dd                	je     7ada <fwp_task_dispose+0xba>
    7afd:	5b                   	pop    %rbx
    7afe:	c3                   	ret
    7aff:	90                   	nop

0000000000007b00 <fwp_free_zombie>:
    7b00:	48 8b 15 c9 3c 06 00 	mov    0x63cc9(%rip),%rdx        # 6b7d0 <fwp_zombie>
    7b07:	48 85 d2             	test   %rdx,%rdx
    7b0a:	0f 84 98 00 00 00    	je     7ba8 <fwp_free_zombie+0xa8>
    7b10:	48 3b 15 c9 3c 06 00 	cmp    0x63cc9(%rip),%rdx        # 6b7e0 <fwp_cur>
    7b17:	0f 84 8b 00 00 00    	je     7ba8 <fwp_free_zombie+0xa8>
    7b1d:	48 83 ec 18          	sub    $0x18,%rsp
    7b21:	48 63 05 8c 36 06 00 	movslq 0x6368c(%rip),%rax        # 6b1b4 <fwp_stack_pool_n>
    7b28:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    7b2c:	83 f8 3f             	cmp    $0x3f,%eax
    7b2f:	7f 7f                	jg     7bb0 <fwp_free_zombie+0xb0>
    7b31:	8d 48 01             	lea    0x1(%rax),%ecx
    7b34:	89 0d 7a 36 06 00    	mov    %ecx,0x6367a(%rip)        # 6b1b4 <fwp_stack_pool_n>
    7b3a:	48 8d 0d 7f 36 06 00 	lea    0x6367f(%rip),%rcx        # 6b1c0 <fwp_stack_pool>
    7b41:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7b45:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    7b4c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7b50:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7b57:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    7b5b:	48 85 c9             	test   %rcx,%rcx
    7b5e:	0f 84 fc 00 00 00    	je     7c60 <fwp_free_zombie+0x160>
    7b64:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    7b6b:	48 85 c0             	test   %rax,%rax
    7b6e:	74 07                	je     7b77 <fwp_free_zombie+0x77>
    7b70:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7b77:	8b 42 5c             	mov    0x5c(%rdx),%eax
    7b7a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7b7e:	48 c7 05 47 3c 06 00 	movq   $0x0,0x63c47(%rip)        # 6b7d0 <fwp_zombie>
    7b85:	00 00 00 00 
    7b89:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7b90:	85 c0                	test   %eax,%eax
    7b92:	74 34                	je     7bc8 <fwp_free_zombie+0xc8>
    7b94:	83 f8 01             	cmp    $0x1,%eax
    7b97:	0f 84 b3 00 00 00    	je     7c50 <fwp_free_zombie+0x150>
    7b9d:	48 83 c4 18          	add    $0x18,%rsp
    7ba1:	c3                   	ret
    7ba2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ba8:	c3                   	ret
    7ba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bb0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7bb4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bb9:	e8 f2 b9 ff ff       	call   35b0 <munmap@plt>
    7bbe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bc3:	eb 80                	jmp    7b45 <fwp_free_zombie+0x45>
    7bc5:	0f 1f 00             	nopl   (%rax)
    7bc8:	48 8b 0d 09 50 06 00 	mov    0x65009(%rip),%rcx        # 6cbd8 <fwp_heap+0x13d8>
    7bcf:	48 89 d0             	mov    %rdx,%rax
    7bd2:	48 2b 05 d7 4f 06 00 	sub    0x64fd7(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7bd9:	48 c1 e1 10          	shl    $0x10,%rcx
    7bdd:	48 39 c8             	cmp    %rcx,%rax
    7be0:	73 bb                	jae    7b9d <fwp_free_zombie+0x9d>
    7be2:	48 89 c1             	mov    %rax,%rcx
    7be5:	48 c1 e9 10          	shr    $0x10,%rcx
    7be9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7bed:	48 8b 0d 04 50 06 00 	mov    0x65004(%rip),%rcx        # 6cbf8 <fwp_heap+0x13f8>
    7bf4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7bf8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7bfc:	48 85 c9             	test   %rcx,%rcx
    7bff:	74 9c                	je     7b9d <fwp_free_zombie+0x9d>
    7c01:	0f b6 3e             	movzbl (%rsi),%edi
    7c04:	40 80 ff 02          	cmp    $0x2,%dil
    7c08:	74 66                	je     7c70 <fwp_free_zombie+0x170>
    7c0a:	40 80 ff 01          	cmp    $0x1,%dil
    7c0e:	75 8d                	jne    7b9d <fwp_free_zombie+0x9d>
    7c10:	8b 7e 18             	mov    0x18(%rsi),%edi
    7c13:	0f b7 c0             	movzwl %ax,%eax
    7c16:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7c19:	48 0f af c7          	imul   %rdi,%rax
    7c1d:	48 c1 e8 20          	shr    $0x20,%rax
    7c21:	48 39 f0             	cmp    %rsi,%rax
    7c24:	0f 83 73 ff ff ff    	jae    7b9d <fwp_free_zombie+0x9d>
    7c2a:	48 01 c1             	add    %rax,%rcx
    7c2d:	0f b6 01             	movzbl (%rcx),%eax
    7c30:	84 c0                	test   %al,%al
    7c32:	0f 84 65 ff ff ff    	je     7b9d <fwp_free_zombie+0x9d>
    7c38:	3c 01                	cmp    $0x1,%al
    7c3a:	74 14                	je     7c50 <fwp_free_zombie+0x150>
    7c3c:	3c ff                	cmp    $0xff,%al
    7c3e:	74 3b                	je     7c7b <fwp_free_zombie+0x17b>
    7c40:	83 e8 01             	sub    $0x1,%eax
    7c43:	88 01                	mov    %al,(%rcx)
    7c45:	e9 53 ff ff ff       	jmp    7b9d <fwp_free_zombie+0x9d>
    7c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c50:	48 89 d7             	mov    %rdx,%rdi
    7c53:	48 83 c4 18          	add    $0x18,%rsp
    7c57:	e9 c4 fd ff ff       	jmp    7a20 <fwp_task_dispose>
    7c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c60:	48 89 05 41 3b 06 00 	mov    %rax,0x63b41(%rip)        # 6b7a8 <fwp_tasks_active>
    7c67:	e9 ff fe ff ff       	jmp    7b6b <fwp_free_zombie+0x6b>
    7c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c70:	66 85 c0             	test   %ax,%ax
    7c73:	0f 85 24 ff ff ff    	jne    7b9d <fwp_free_zombie+0x9d>
    7c79:	eb b2                	jmp    7c2d <fwp_free_zombie+0x12d>
    7c7b:	48 89 ca             	mov    %rcx,%rdx
    7c7e:	48 8d 35 7b 3b 06 00 	lea    0x63b7b(%rip),%rsi        # 6b800 <fwp_heap>
    7c85:	48 c1 ea 11          	shr    $0x11,%rdx
    7c89:	48 31 ca             	xor    %rcx,%rdx
    7c8c:	48 89 d0             	mov    %rdx,%rax
    7c8f:	48 c1 e8 09          	shr    $0x9,%rax
    7c93:	48 31 c2             	xor    %rax,%rdx
    7c96:	0f b6 d2             	movzbl %dl,%edx
    7c99:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7ca0:	00 
    7ca1:	48 85 c0             	test   %rax,%rax
    7ca4:	75 23                	jne    7cc9 <fwp_free_zombie+0x1c9>
    7ca6:	eb 5c                	jmp    7d04 <fwp_free_zombie+0x204>
    7ca8:	66 90                	xchg   %ax,%ax
    7caa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cb1:	00 00 00 00 
    7cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cbc:	00 00 00 00 
    7cc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7cc4:	48 85 c0             	test   %rax,%rax
    7cc7:	74 3b                	je     7d04 <fwp_free_zombie+0x204>
    7cc9:	48 89 c2             	mov    %rax,%rdx
    7ccc:	48 39 08             	cmp    %rcx,(%rax)
    7ccf:	75 ef                	jne    7cc0 <fwp_free_zombie+0x1c0>
    7cd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cd5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7cd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7cdd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ce4:	0f 85 b3 fe ff ff    	jne    7b9d <fwp_free_zombie+0x9d>
    7cea:	48 89 cf             	mov    %rcx,%rdi
    7ced:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7cf2:	e8 79 da ff ff       	call   5770 <fwp_rc_forget_slot>
    7cf7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7cfc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7cff:	e9 99 fe ff ff       	jmp    7b9d <fwp_free_zombie+0x9d>
    7d04:	48 8d 3d e5 7c 00 00 	lea    0x7ce5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7d0b:	e8 00 c7 ff ff       	call   4410 <fwp_trap>

0000000000007d10 <fwp_block>:
    7d10:	48 83 ec 08          	sub    $0x8,%rsp
    7d14:	48 8b 05 ad 3a 06 00 	mov    0x63aad(%rip),%rax        # 6b7c8 <fwp_ready_head>
    7d1b:	48 85 c0             	test   %rax,%rax
    7d1e:	0f 84 1c 01 00 00    	je     7e40 <fwp_block+0x130>
    7d24:	90                   	nop
    7d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d2c:	00 00 00 00 
    7d30:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7d37:	48 89 15 8a 3a 06 00 	mov    %rdx,0x63a8a(%rip)        # 6b7c8 <fwp_ready_head>
    7d3e:	48 85 d2             	test   %rdx,%rdx
    7d41:	0f 84 19 01 00 00    	je     7e60 <fwp_block+0x150>
    7d47:	48 8b 15 92 3a 06 00 	mov    0x63a92(%rip),%rdx        # 6b7e0 <fwp_cur>
    7d4e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7d52:	48 39 c2             	cmp    %rax,%rdx
    7d55:	0f 84 d5 00 00 00    	je     7e30 <fwp_block+0x120>
    7d5b:	48 8b 0d 06 57 06 00 	mov    0x65706(%rip),%rcx        # 6d468 <fwp_state_owners>
    7d62:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7d66:	48 89 05 73 3a 06 00 	mov    %rax,0x63a73(%rip)        # 6b7e0 <fwp_cur>
    7d6d:	f3 0f 7e 05 1b 57 06 	movq   0x6571b(%rip),%xmm0        # 6d490 <fwp_foreign_callbacks>
    7d74:	00 
    7d75:	0f 16 05 04 57 06 00 	movhps 0x65704(%rip),%xmm0        # 6d480 <fwp_state>
    7d7c:	f3 0f 7e 0d 04 57 06 	movq   0x65704(%rip),%xmm1        # 6d488 <fwp_handlers>
    7d83:	00 
    7d84:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7d8b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7d92:	0f 16 0d ff 56 06 00 	movhps 0x656ff(%rip),%xmm1        # 6d498 <fwp_cleanups>
    7d99:	f3 0f 7e 05 d7 56 06 	movq   0x656d7(%rip),%xmm0        # 6d478 <fwp_state_len>
    7da0:	00 
    7da1:	0f 16 05 c8 56 06 00 	movhps 0x656c8(%rip),%xmm0        # 6d470 <fwp_state_cap>
    7da8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7daf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7db6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7dba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7dc1:	48 89 0d c0 56 06 00 	mov    %rcx,0x656c0(%rip)        # 6d488 <fwp_handlers>
    7dc8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7dcf:	48 89 0d c2 56 06 00 	mov    %rcx,0x656c2(%rip)        # 6d498 <fwp_cleanups>
    7dd6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7ddd:	48 89 0d ac 56 06 00 	mov    %rcx,0x656ac(%rip)        # 6d490 <fwp_foreign_callbacks>
    7de4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7deb:	48 89 0d 8e 56 06 00 	mov    %rcx,0x6568e(%rip)        # 6d480 <fwp_state>
    7df2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7df9:	48 89 0d 78 56 06 00 	mov    %rcx,0x65678(%rip)        # 6d478 <fwp_state_len>
    7e00:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7e07:	48 89 0d 62 56 06 00 	mov    %rcx,0x65662(%rip)        # 6d470 <fwp_state_cap>
    7e0e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7e15:	48 89 0d 4c 56 06 00 	mov    %rcx,0x6564c(%rip)        # 6d468 <fwp_state_owners>
    7e1c:	e8 4f b6 ff ff       	call   3470 <swapcontext@plt>
    7e21:	f3 0f 1e fa          	endbr64
    7e25:	e8 d6 fc ff ff       	call   7b00 <fwp_free_zombie>
    7e2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e30:	8b 05 7a 33 06 00    	mov    0x6337a(%rip),%eax        # 6b1b0 <fwp_slice>
    7e36:	85 c0                	test   %eax,%eax
    7e38:	74 36                	je     7e70 <fwp_block+0x160>
    7e3a:	48 83 c4 08          	add    $0x8,%rsp
    7e3e:	c3                   	ret
    7e3f:	90                   	nop
    7e40:	e8 7b d5 ff ff       	call   53c0 <fwp_poll_events>
    7e45:	48 8b 05 7c 39 06 00 	mov    0x6397c(%rip),%rax        # 6b7c8 <fwp_ready_head>
    7e4c:	48 85 c0             	test   %rax,%rax
    7e4f:	0f 85 db fe ff ff    	jne    7d30 <fwp_block+0x20>
    7e55:	eb e9                	jmp    7e40 <fwp_block+0x130>
    7e57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e5e:	00 00 
    7e60:	48 c7 05 55 39 06 00 	movq   $0x0,0x63955(%rip)        # 6b7c0 <fwp_ready_tail>
    7e67:	00 00 00 00 
    7e6b:	e9 d7 fe ff ff       	jmp    7d47 <fwp_block+0x37>
    7e70:	48 8d 3d 6a 73 00 00 	lea    0x736a(%rip),%rdi        # f1e1 <_IO_stdin_used+0x1e1>
    7e77:	e8 04 b5 ff ff       	call   3380 <getenv@plt>
    7e7c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7e81:	48 85 c0             	test   %rax,%rax
    7e84:	74 05                	je     7e8b <fwp_block+0x17b>
    7e86:	80 38 00             	cmpb   $0x0,(%rax)
    7e89:	75 0b                	jne    7e96 <fwp_block+0x186>
    7e8b:	89 15 1f 33 06 00    	mov    %edx,0x6331f(%rip)        # 6b1b0 <fwp_slice>
    7e91:	48 83 c4 08          	add    $0x8,%rsp
    7e95:	c3                   	ret
    7e96:	ba 0a 00 00 00       	mov    $0xa,%edx
    7e9b:	31 f6                	xor    %esi,%esi
    7e9d:	48 89 c7             	mov    %rax,%rdi
    7ea0:	e8 8b b6 ff ff       	call   3530 <strtoll@plt>
    7ea5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ea9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7eb0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7eb5:	0f 46 d0             	cmovbe %eax,%edx
    7eb8:	eb d1                	jmp    7e8b <fwp_block+0x17b>
    7eba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007ec0 <fwp_caps173>:
    7ec0:	f3 0f 1e fa          	endbr64
    7ec4:	85 f6                	test   %esi,%esi
    7ec6:	74 08                	je     7ed0 <fwp_caps173+0x10>
    7ec8:	c3                   	ret
    7ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ed0:	48 8b 15 01 4d 06 00 	mov    0x64d01(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    7ed7:	48 89 f8             	mov    %rdi,%rax
    7eda:	48 2b 05 cf 4c 06 00 	sub    0x64ccf(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7ee1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ee5:	48 39 d0             	cmp    %rdx,%rax
    7ee8:	73 de                	jae    7ec8 <fwp_caps173+0x8>
    7eea:	48 89 c2             	mov    %rax,%rdx
    7eed:	48 c1 ea 10          	shr    $0x10,%rdx
    7ef1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ef5:	48 8b 15 fc 4c 06 00 	mov    0x64cfc(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    7efc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f00:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7f04:	48 85 c9             	test   %rcx,%rcx
    7f07:	74 bf                	je     7ec8 <fwp_caps173+0x8>
    7f09:	0f b6 32             	movzbl (%rdx),%esi
    7f0c:	40 80 fe 02          	cmp    $0x2,%sil
    7f10:	74 2e                	je     7f40 <fwp_caps173+0x80>
    7f12:	40 80 fe 01          	cmp    $0x1,%sil
    7f16:	75 b0                	jne    7ec8 <fwp_caps173+0x8>
    7f18:	8b 72 18             	mov    0x18(%rdx),%esi
    7f1b:	0f b7 c0             	movzwl %ax,%eax
    7f1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f21:	48 0f af c6          	imul   %rsi,%rax
    7f25:	48 c1 e8 20          	shr    $0x20,%rax
    7f29:	48 39 d0             	cmp    %rdx,%rax
    7f2c:	73 9a                	jae    7ec8 <fwp_caps173+0x8>
    7f2e:	48 01 c1             	add    %rax,%rcx
    7f31:	80 39 01             	cmpb   $0x1,(%rcx)
    7f34:	75 92                	jne    7ec8 <fwp_caps173+0x8>
    7f36:	e9 75 da ff ff       	jmp    59b0 <fwp_mem_free>
    7f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f40:	66 85 c0             	test   %ax,%ax
    7f43:	74 ec                	je     7f31 <fwp_caps173+0x71>
    7f45:	c3                   	ret
    7f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f4d:	00 00 00 

0000000000007f50 <fwp_args37>:
    7f50:	f3 0f 1e fa          	endbr64
    7f54:	85 d2                	test   %edx,%edx
    7f56:	74 04                	je     7f5c <fwp_args37+0xc>
    7f58:	85 f6                	test   %esi,%esi
    7f5a:	74 04                	je     7f60 <fwp_args37+0x10>
    7f5c:	c3                   	ret
    7f5d:	0f 1f 00             	nopl   (%rax)
    7f60:	48 8b 15 71 4c 06 00 	mov    0x64c71(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    7f67:	48 8b 07             	mov    (%rdi),%rax
    7f6a:	48 2b 05 3f 4c 06 00 	sub    0x64c3f(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    7f71:	48 c1 e2 10          	shl    $0x10,%rdx
    7f75:	48 39 d0             	cmp    %rdx,%rax
    7f78:	73 e2                	jae    7f5c <fwp_args37+0xc>
    7f7a:	48 89 c2             	mov    %rax,%rdx
    7f7d:	48 c1 ea 10          	shr    $0x10,%rdx
    7f81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f85:	48 8b 15 6c 4c 06 00 	mov    0x64c6c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    7f8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f90:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f94:	48 85 ff             	test   %rdi,%rdi
    7f97:	74 c3                	je     7f5c <fwp_args37+0xc>
    7f99:	0f b6 0a             	movzbl (%rdx),%ecx
    7f9c:	80 f9 02             	cmp    $0x2,%cl
    7f9f:	74 4f                	je     7ff0 <fwp_args37+0xa0>
    7fa1:	80 f9 01             	cmp    $0x1,%cl
    7fa4:	75 b6                	jne    7f5c <fwp_args37+0xc>
    7fa6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fa9:	0f b7 c0             	movzwl %ax,%eax
    7fac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7faf:	48 0f af c1          	imul   %rcx,%rax
    7fb3:	48 c1 e8 20          	shr    $0x20,%rax
    7fb7:	48 39 d0             	cmp    %rdx,%rax
    7fba:	73 a0                	jae    7f5c <fwp_args37+0xc>
    7fbc:	48 01 c7             	add    %rax,%rdi
    7fbf:	0f b6 07             	movzbl (%rdi),%eax
    7fc2:	84 c0                	test   %al,%al
    7fc4:	74 96                	je     7f5c <fwp_args37+0xc>
    7fc6:	8b 15 fc 54 06 00    	mov    0x654fc(%rip),%edx        # 6d4c8 <iteration_active>
    7fcc:	85 d2                	test   %edx,%edx
    7fce:	75 10                	jne    7fe0 <fwp_args37+0x90>
    7fd0:	3c fd                	cmp    $0xfd,%al
    7fd2:	77 22                	ja     7ff6 <fwp_args37+0xa6>
    7fd4:	83 c0 01             	add    $0x1,%eax
    7fd7:	88 07                	mov    %al,(%rdi)
    7fd9:	c3                   	ret
    7fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7fe0:	48 83 05 c8 54 06 00 	addq   $0x1,0x654c8(%rip)        # 6d4b0 <iteration_retains>
    7fe7:	01 
    7fe8:	eb e6                	jmp    7fd0 <fwp_args37+0x80>
    7fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ff0:	66 85 c0             	test   %ax,%ax
    7ff3:	74 ca                	je     7fbf <fwp_args37+0x6f>
    7ff5:	c3                   	ret
    7ff6:	e9 55 d6 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    7ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008000 <fwp_caps37>:
    8000:	f3 0f 1e fa          	endbr64
    8004:	48 83 ec 18          	sub    $0x18,%rsp
    8008:	48 89 f8             	mov    %rdi,%rax
    800b:	8b 7f 04             	mov    0x4(%rdi),%edi
    800e:	85 ff                	test   %edi,%edi
    8010:	0f 84 9a 00 00 00    	je     80b0 <fwp_caps37+0xb0>
    8016:	48 8b 78 08          	mov    0x8(%rax),%rdi
    801a:	85 f6                	test   %esi,%esi
    801c:	0f 85 9e 00 00 00    	jne    80c0 <fwp_caps37+0xc0>
    8022:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8027:	e8 34 f7 ff ff       	call   7760 <fwp_drop4>
    802c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8031:	48 8b 0d a0 4b 06 00 	mov    0x64ba0(%rip),%rcx        # 6cbd8 <fwp_heap+0x13d8>
    8038:	48 89 c2             	mov    %rax,%rdx
    803b:	48 2b 15 6e 4b 06 00 	sub    0x64b6e(%rip),%rdx        # 6cbb0 <fwp_heap+0x13b0>
    8042:	48 c1 e1 10          	shl    $0x10,%rcx
    8046:	48 39 ca             	cmp    %rcx,%rdx
    8049:	73 6d                	jae    80b8 <fwp_caps37+0xb8>
    804b:	48 89 d1             	mov    %rdx,%rcx
    804e:	48 c1 e9 10          	shr    $0x10,%rcx
    8052:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8056:	48 8b 0d 9b 4b 06 00 	mov    0x64b9b(%rip),%rcx        # 6cbf8 <fwp_heap+0x13f8>
    805d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8061:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8065:	48 85 f6             	test   %rsi,%rsi
    8068:	74 4e                	je     80b8 <fwp_caps37+0xb8>
    806a:	0f b6 39             	movzbl (%rcx),%edi
    806d:	40 80 ff 02          	cmp    $0x2,%dil
    8071:	0f 84 c9 00 00 00    	je     8140 <fwp_caps37+0x140>
    8077:	40 80 ff 01          	cmp    $0x1,%dil
    807b:	75 3b                	jne    80b8 <fwp_caps37+0xb8>
    807d:	8b 79 18             	mov    0x18(%rcx),%edi
    8080:	0f b7 d2             	movzwl %dx,%edx
    8083:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8086:	48 0f af d7          	imul   %rdi,%rdx
    808a:	48 c1 ea 20          	shr    $0x20,%rdx
    808e:	48 39 ca             	cmp    %rcx,%rdx
    8091:	73 25                	jae    80b8 <fwp_caps37+0xb8>
    8093:	48 01 d6             	add    %rdx,%rsi
    8096:	80 3e 01             	cmpb   $0x1,(%rsi)
    8099:	75 1d                	jne    80b8 <fwp_caps37+0xb8>
    809b:	48 89 c7             	mov    %rax,%rdi
    809e:	48 83 c4 18          	add    $0x18,%rsp
    80a2:	e9 09 d9 ff ff       	jmp    59b0 <fwp_mem_free>
    80a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ae:	00 00 
    80b0:	85 f6                	test   %esi,%esi
    80b2:	0f 84 79 ff ff ff    	je     8031 <fwp_caps37+0x31>
    80b8:	48 83 c4 18          	add    $0x18,%rsp
    80bc:	c3                   	ret
    80bd:	0f 1f 00             	nopl   (%rax)
    80c0:	48 8b 05 11 4b 06 00 	mov    0x64b11(%rip),%rax        # 6cbd8 <fwp_heap+0x13d8>
    80c7:	48 2b 3d e2 4a 06 00 	sub    0x64ae2(%rip),%rdi        # 6cbb0 <fwp_heap+0x13b0>
    80ce:	48 c1 e0 10          	shl    $0x10,%rax
    80d2:	48 39 c7             	cmp    %rax,%rdi
    80d5:	73 e1                	jae    80b8 <fwp_caps37+0xb8>
    80d7:	48 89 f8             	mov    %rdi,%rax
    80da:	48 c1 e8 10          	shr    $0x10,%rax
    80de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    80e2:	48 8b 05 0f 4b 06 00 	mov    0x64b0f(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    80e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    80ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    80f1:	48 85 c0             	test   %rax,%rax
    80f4:	74 c2                	je     80b8 <fwp_caps37+0xb8>
    80f6:	0f b6 0a             	movzbl (%rdx),%ecx
    80f9:	80 f9 02             	cmp    $0x2,%cl
    80fc:	74 52                	je     8150 <fwp_caps37+0x150>
    80fe:	80 f9 01             	cmp    $0x1,%cl
    8101:	75 b5                	jne    80b8 <fwp_caps37+0xb8>
    8103:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8106:	0f b7 ff             	movzwl %di,%edi
    8109:	8b 52 1c             	mov    0x1c(%rdx),%edx
    810c:	48 0f af f9          	imul   %rcx,%rdi
    8110:	48 c1 ef 20          	shr    $0x20,%rdi
    8114:	48 39 d7             	cmp    %rdx,%rdi
    8117:	73 9f                	jae    80b8 <fwp_caps37+0xb8>
    8119:	48 01 f8             	add    %rdi,%rax
    811c:	0f b6 10             	movzbl (%rax),%edx
    811f:	84 d2                	test   %dl,%dl
    8121:	74 95                	je     80b8 <fwp_caps37+0xb8>
    8123:	8b 0d 9f 53 06 00    	mov    0x6539f(%rip),%ecx        # 6d4c8 <iteration_active>
    8129:	85 c9                	test   %ecx,%ecx
    812b:	75 33                	jne    8160 <fwp_caps37+0x160>
    812d:	80 fa fd             	cmp    $0xfd,%dl
    8130:	77 38                	ja     816a <fwp_caps37+0x16a>
    8132:	83 c2 01             	add    $0x1,%edx
    8135:	88 10                	mov    %dl,(%rax)
    8137:	e9 7c ff ff ff       	jmp    80b8 <fwp_caps37+0xb8>
    813c:	0f 1f 40 00          	nopl   0x0(%rax)
    8140:	66 85 d2             	test   %dx,%dx
    8143:	0f 85 6f ff ff ff    	jne    80b8 <fwp_caps37+0xb8>
    8149:	e9 48 ff ff ff       	jmp    8096 <fwp_caps37+0x96>
    814e:	66 90                	xchg   %ax,%ax
    8150:	66 85 ff             	test   %di,%di
    8153:	0f 85 5f ff ff ff    	jne    80b8 <fwp_caps37+0xb8>
    8159:	eb c1                	jmp    811c <fwp_caps37+0x11c>
    815b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8160:	48 83 05 48 53 06 00 	addq   $0x1,0x65348(%rip)        # 6d4b0 <iteration_retains>
    8167:	01 
    8168:	eb c3                	jmp    812d <fwp_caps37+0x12d>
    816a:	48 89 c7             	mov    %rax,%rdi
    816d:	48 83 c4 18          	add    $0x18,%rsp
    8171:	e9 da d4 ff ff       	jmp    5650 <fwp_rc_wide_dup>
    8176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    817d:	00 00 00 

0000000000008180 <fwp_drop0>:
    8180:	f3 0f 1e fa          	endbr64
    8184:	48 8b 15 4d 4a 06 00 	mov    0x64a4d(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    818b:	48 89 f8             	mov    %rdi,%rax
    818e:	48 2b 05 1b 4a 06 00 	sub    0x64a1b(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    8195:	48 c1 e2 10          	shl    $0x10,%rdx
    8199:	48 39 d0             	cmp    %rdx,%rax
    819c:	0f 83 36 01 00 00    	jae    82d8 <fwp_drop0+0x158>
    81a2:	48 83 ec 18          	sub    $0x18,%rsp
    81a6:	48 8d 35 53 36 06 00 	lea    0x63653(%rip),%rsi        # 6b800 <fwp_heap>
    81ad:	48 89 c2             	mov    %rax,%rdx
    81b0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    81b7:	48 c1 ea 10          	shr    $0x10,%rdx
    81bb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    81bf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    81c3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    81c7:	48 85 d2             	test   %rdx,%rdx
    81ca:	74 42                	je     820e <fwp_drop0+0x8e>
    81cc:	44 0f b6 01          	movzbl (%rcx),%r8d
    81d0:	41 80 f8 02          	cmp    $0x2,%r8b
    81d4:	74 42                	je     8218 <fwp_drop0+0x98>
    81d6:	41 80 f8 01          	cmp    $0x1,%r8b
    81da:	75 32                	jne    820e <fwp_drop0+0x8e>
    81dc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    81e0:	0f b7 c0             	movzwl %ax,%eax
    81e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81e6:	49 0f af c0          	imul   %r8,%rax
    81ea:	48 c1 e8 20          	shr    $0x20,%rax
    81ee:	48 39 c8             	cmp    %rcx,%rax
    81f1:	73 1b                	jae    820e <fwp_drop0+0x8e>
    81f3:	48 01 c2             	add    %rax,%rdx
    81f6:	0f b6 02             	movzbl (%rdx),%eax
    81f9:	84 c0                	test   %al,%al
    81fb:	74 11                	je     820e <fwp_drop0+0x8e>
    81fd:	3c 01                	cmp    $0x1,%al
    81ff:	74 27                	je     8228 <fwp_drop0+0xa8>
    8201:	3c ff                	cmp    $0xff,%al
    8203:	0f 84 e7 00 00 00    	je     82f0 <fwp_drop0+0x170>
    8209:	83 e8 01             	sub    $0x1,%eax
    820c:	88 02                	mov    %al,(%rdx)
    820e:	48 83 c4 18          	add    $0x18,%rsp
    8212:	c3                   	ret
    8213:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8218:	66 85 c0             	test   %ax,%ax
    821b:	74 d9                	je     81f6 <fwp_drop0+0x76>
    821d:	48 83 c4 18          	add    $0x18,%rsp
    8221:	c3                   	ret
    8222:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8228:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    822f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8236:	48 89 f8             	mov    %rdi,%rax
    8239:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    823d:	48 29 c8             	sub    %rcx,%rax
    8240:	48 c1 e2 10          	shl    $0x10,%rdx
    8244:	48 39 d0             	cmp    %rdx,%rax
    8247:	73 71                	jae    82ba <fwp_drop0+0x13a>
    8249:	49 89 c2             	mov    %rax,%r10
    824c:	49 c1 ea 10          	shr    $0x10,%r10
    8250:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8254:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8258:	4d 8b 51 20          	mov    0x20(%r9),%r10
    825c:	4d 85 d2             	test   %r10,%r10
    825f:	74 59                	je     82ba <fwp_drop0+0x13a>
    8261:	45 0f b6 19          	movzbl (%r9),%r11d
    8265:	41 80 fb 02          	cmp    $0x2,%r11b
    8269:	74 75                	je     82e0 <fwp_drop0+0x160>
    826b:	41 80 fb 01          	cmp    $0x1,%r11b
    826f:	75 49                	jne    82ba <fwp_drop0+0x13a>
    8271:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8275:	0f b7 c0             	movzwl %ax,%eax
    8278:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    827c:	49 0f af c3          	imul   %r11,%rax
    8280:	48 c1 e8 20          	shr    $0x20,%rax
    8284:	4c 39 c8             	cmp    %r9,%rax
    8287:	73 31                	jae    82ba <fwp_drop0+0x13a>
    8289:	49 01 c2             	add    %rax,%r10
    828c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8290:	75 28                	jne    82ba <fwp_drop0+0x13a>
    8292:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8297:	e8 14 d7 ff ff       	call   59b0 <fwp_mem_free>
    829c:	48 8d 35 5d 35 06 00 	lea    0x6355d(%rip),%rsi        # 6b800 <fwp_heap>
    82a3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    82a8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    82af:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    82b6:	48 c1 e2 10          	shl    $0x10,%rdx
    82ba:	4c 89 c0             	mov    %r8,%rax
    82bd:	48 29 c8             	sub    %rcx,%rax
    82c0:	48 39 d0             	cmp    %rdx,%rax
    82c3:	0f 83 45 ff ff ff    	jae    820e <fwp_drop0+0x8e>
    82c9:	4c 89 c7             	mov    %r8,%rdi
    82cc:	e9 dc fe ff ff       	jmp    81ad <fwp_drop0+0x2d>
    82d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82d8:	c3                   	ret
    82d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82e0:	66 85 c0             	test   %ax,%ax
    82e3:	75 d5                	jne    82ba <fwp_drop0+0x13a>
    82e5:	eb a5                	jmp    828c <fwp_drop0+0x10c>
    82e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82ee:	00 00 
    82f0:	48 89 d0             	mov    %rdx,%rax
    82f3:	48 c1 e8 11          	shr    $0x11,%rax
    82f7:	48 31 d0             	xor    %rdx,%rax
    82fa:	48 89 c1             	mov    %rax,%rcx
    82fd:	48 c1 e9 09          	shr    $0x9,%rcx
    8301:	48 31 c8             	xor    %rcx,%rax
    8304:	0f b6 c8             	movzbl %al,%ecx
    8307:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    830e:	00 
    830f:	48 85 c0             	test   %rax,%rax
    8312:	75 15                	jne    8329 <fwp_drop0+0x1a9>
    8314:	eb 4e                	jmp    8364 <fwp_drop0+0x1e4>
    8316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    831d:	00 00 00 
    8320:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8324:	48 85 c0             	test   %rax,%rax
    8327:	74 3b                	je     8364 <fwp_drop0+0x1e4>
    8329:	48 89 c1             	mov    %rax,%rcx
    832c:	48 39 10             	cmp    %rdx,(%rax)
    832f:	75 ef                	jne    8320 <fwp_drop0+0x1a0>
    8331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8335:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8339:	48 89 48 08          	mov    %rcx,0x8(%rax)
    833d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8344:	0f 85 c4 fe ff ff    	jne    820e <fwp_drop0+0x8e>
    834a:	48 89 d7             	mov    %rdx,%rdi
    834d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8352:	e8 19 d4 ff ff       	call   5770 <fwp_rc_forget_slot>
    8357:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    835c:	c6 02 fe             	movb   $0xfe,(%rdx)
    835f:	e9 aa fe ff ff       	jmp    820e <fwp_drop0+0x8e>
    8364:	48 8d 3d 85 76 00 00 	lea    0x7685(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    836b:	e8 a0 c0 ff ff       	call   4410 <fwp_trap>

0000000000008370 <fwp_drop1>:
    8370:	f3 0f 1e fa          	endbr64
    8374:	48 8b 15 5d 48 06 00 	mov    0x6485d(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    837b:	48 89 f8             	mov    %rdi,%rax
    837e:	48 2b 05 2b 48 06 00 	sub    0x6482b(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    8385:	48 c1 e2 10          	shl    $0x10,%rdx
    8389:	48 39 d0             	cmp    %rdx,%rax
    838c:	0f 83 36 01 00 00    	jae    84c8 <fwp_drop1+0x158>
    8392:	48 83 ec 18          	sub    $0x18,%rsp
    8396:	48 8d 35 63 34 06 00 	lea    0x63463(%rip),%rsi        # 6b800 <fwp_heap>
    839d:	48 89 c2             	mov    %rax,%rdx
    83a0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    83a7:	48 c1 ea 10          	shr    $0x10,%rdx
    83ab:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    83af:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    83b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    83b7:	48 85 d2             	test   %rdx,%rdx
    83ba:	74 42                	je     83fe <fwp_drop1+0x8e>
    83bc:	44 0f b6 01          	movzbl (%rcx),%r8d
    83c0:	41 80 f8 02          	cmp    $0x2,%r8b
    83c4:	74 42                	je     8408 <fwp_drop1+0x98>
    83c6:	41 80 f8 01          	cmp    $0x1,%r8b
    83ca:	75 32                	jne    83fe <fwp_drop1+0x8e>
    83cc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    83d0:	0f b7 c0             	movzwl %ax,%eax
    83d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    83d6:	49 0f af c0          	imul   %r8,%rax
    83da:	48 c1 e8 20          	shr    $0x20,%rax
    83de:	48 39 c8             	cmp    %rcx,%rax
    83e1:	73 1b                	jae    83fe <fwp_drop1+0x8e>
    83e3:	48 01 c2             	add    %rax,%rdx
    83e6:	0f b6 02             	movzbl (%rdx),%eax
    83e9:	84 c0                	test   %al,%al
    83eb:	74 11                	je     83fe <fwp_drop1+0x8e>
    83ed:	3c 01                	cmp    $0x1,%al
    83ef:	74 27                	je     8418 <fwp_drop1+0xa8>
    83f1:	3c ff                	cmp    $0xff,%al
    83f3:	0f 84 e7 00 00 00    	je     84e0 <fwp_drop1+0x170>
    83f9:	83 e8 01             	sub    $0x1,%eax
    83fc:	88 02                	mov    %al,(%rdx)
    83fe:	48 83 c4 18          	add    $0x18,%rsp
    8402:	c3                   	ret
    8403:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8408:	66 85 c0             	test   %ax,%ax
    840b:	74 d9                	je     83e6 <fwp_drop1+0x76>
    840d:	48 83 c4 18          	add    $0x18,%rsp
    8411:	c3                   	ret
    8412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8418:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    841f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8426:	48 89 f8             	mov    %rdi,%rax
    8429:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    842d:	48 29 c8             	sub    %rcx,%rax
    8430:	48 c1 e2 10          	shl    $0x10,%rdx
    8434:	48 39 d0             	cmp    %rdx,%rax
    8437:	73 71                	jae    84aa <fwp_drop1+0x13a>
    8439:	49 89 c2             	mov    %rax,%r10
    843c:	49 c1 ea 10          	shr    $0x10,%r10
    8440:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8444:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8448:	4d 8b 51 20          	mov    0x20(%r9),%r10
    844c:	4d 85 d2             	test   %r10,%r10
    844f:	74 59                	je     84aa <fwp_drop1+0x13a>
    8451:	45 0f b6 19          	movzbl (%r9),%r11d
    8455:	41 80 fb 02          	cmp    $0x2,%r11b
    8459:	74 75                	je     84d0 <fwp_drop1+0x160>
    845b:	41 80 fb 01          	cmp    $0x1,%r11b
    845f:	75 49                	jne    84aa <fwp_drop1+0x13a>
    8461:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8465:	0f b7 c0             	movzwl %ax,%eax
    8468:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    846c:	49 0f af c3          	imul   %r11,%rax
    8470:	48 c1 e8 20          	shr    $0x20,%rax
    8474:	4c 39 c8             	cmp    %r9,%rax
    8477:	73 31                	jae    84aa <fwp_drop1+0x13a>
    8479:	49 01 c2             	add    %rax,%r10
    847c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8480:	75 28                	jne    84aa <fwp_drop1+0x13a>
    8482:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8487:	e8 24 d5 ff ff       	call   59b0 <fwp_mem_free>
    848c:	48 8d 35 6d 33 06 00 	lea    0x6336d(%rip),%rsi        # 6b800 <fwp_heap>
    8493:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8498:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    849f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    84a6:	48 c1 e2 10          	shl    $0x10,%rdx
    84aa:	4c 89 c0             	mov    %r8,%rax
    84ad:	48 29 c8             	sub    %rcx,%rax
    84b0:	48 39 d0             	cmp    %rdx,%rax
    84b3:	0f 83 45 ff ff ff    	jae    83fe <fwp_drop1+0x8e>
    84b9:	4c 89 c7             	mov    %r8,%rdi
    84bc:	e9 dc fe ff ff       	jmp    839d <fwp_drop1+0x2d>
    84c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    84c8:	c3                   	ret
    84c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    84d0:	66 85 c0             	test   %ax,%ax
    84d3:	75 d5                	jne    84aa <fwp_drop1+0x13a>
    84d5:	eb a5                	jmp    847c <fwp_drop1+0x10c>
    84d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    84de:	00 00 
    84e0:	48 89 d0             	mov    %rdx,%rax
    84e3:	48 c1 e8 11          	shr    $0x11,%rax
    84e7:	48 31 d0             	xor    %rdx,%rax
    84ea:	48 89 c1             	mov    %rax,%rcx
    84ed:	48 c1 e9 09          	shr    $0x9,%rcx
    84f1:	48 31 c8             	xor    %rcx,%rax
    84f4:	0f b6 c8             	movzbl %al,%ecx
    84f7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    84fe:	00 
    84ff:	48 85 c0             	test   %rax,%rax
    8502:	75 25                	jne    8529 <fwp_drop1+0x1b9>
    8504:	eb 5e                	jmp    8564 <fwp_drop1+0x1f4>
    8506:	0f 1f 40 00          	nopl   0x0(%rax)
    850a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8511:	00 00 00 00 
    8515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    851c:	00 00 00 00 
    8520:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8524:	48 85 c0             	test   %rax,%rax
    8527:	74 3b                	je     8564 <fwp_drop1+0x1f4>
    8529:	48 89 c1             	mov    %rax,%rcx
    852c:	48 39 10             	cmp    %rdx,(%rax)
    852f:	75 ef                	jne    8520 <fwp_drop1+0x1b0>
    8531:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8535:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8539:	48 89 48 08          	mov    %rcx,0x8(%rax)
    853d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8544:	0f 85 b4 fe ff ff    	jne    83fe <fwp_drop1+0x8e>
    854a:	48 89 d7             	mov    %rdx,%rdi
    854d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8552:	e8 19 d2 ff ff       	call   5770 <fwp_rc_forget_slot>
    8557:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    855c:	c6 02 fe             	movb   $0xfe,(%rdx)
    855f:	e9 9a fe ff ff       	jmp    83fe <fwp_drop1+0x8e>
    8564:	48 8d 3d 85 74 00 00 	lea    0x7485(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    856b:	e8 a0 be ff ff       	call   4410 <fwp_trap>

0000000000008570 <fwp_drop10>:
    8570:	48 8b 0d 61 46 06 00 	mov    0x64661(%rip),%rcx        # 6cbd8 <fwp_heap+0x13d8>
    8577:	48 89 f8             	mov    %rdi,%rax
    857a:	48 2b 05 2f 46 06 00 	sub    0x6462f(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    8581:	48 c1 e1 10          	shl    $0x10,%rcx
    8585:	48 39 c8             	cmp    %rcx,%rax
    8588:	0f 83 c2 01 00 00    	jae    8750 <fwp_drop10+0x1e0>
    858e:	48 83 ec 18          	sub    $0x18,%rsp
    8592:	48 89 fa             	mov    %rdi,%rdx
    8595:	48 8d 35 64 32 06 00 	lea    0x63264(%rip),%rsi        # 6b800 <fwp_heap>
    859c:	48 89 c1             	mov    %rax,%rcx
    859f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    85a6:	48 c1 e9 10          	shr    $0x10,%rcx
    85aa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    85ae:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    85b2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    85b6:	48 85 c9             	test   %rcx,%rcx
    85b9:	74 46                	je     8601 <fwp_drop10+0x91>
    85bb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    85bf:	41 80 f9 02          	cmp    $0x2,%r9b
    85c3:	0f 84 d7 00 00 00    	je     86a0 <fwp_drop10+0x130>
    85c9:	41 80 f9 01          	cmp    $0x1,%r9b
    85cd:	75 32                	jne    8601 <fwp_drop10+0x91>
    85cf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    85d3:	0f b7 c0             	movzwl %ax,%eax
    85d6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    85d9:	49 0f af c1          	imul   %r9,%rax
    85dd:	48 c1 e8 20          	shr    $0x20,%rax
    85e1:	48 39 f8             	cmp    %rdi,%rax
    85e4:	73 1b                	jae    8601 <fwp_drop10+0x91>
    85e6:	48 01 c1             	add    %rax,%rcx
    85e9:	0f b6 01             	movzbl (%rcx),%eax
    85ec:	84 c0                	test   %al,%al
    85ee:	74 11                	je     8601 <fwp_drop10+0x91>
    85f0:	3c 01                	cmp    $0x1,%al
    85f2:	74 1c                	je     8610 <fwp_drop10+0xa0>
    85f4:	3c ff                	cmp    $0xff,%al
    85f6:	0f 84 5c 01 00 00    	je     8758 <fwp_drop10+0x1e8>
    85fc:	83 e8 01             	sub    $0x1,%eax
    85ff:	88 01                	mov    %al,(%rcx)
    8601:	48 83 c4 18          	add    $0x18,%rsp
    8605:	c3                   	ret
    8606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    860d:	00 00 00 
    8610:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8617:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    861e:	48 89 d0             	mov    %rdx,%rax
    8621:	49 89 d1             	mov    %rdx,%r9
    8624:	48 c1 e1 10          	shl    $0x10,%rcx
    8628:	48 29 f8             	sub    %rdi,%rax
    862b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    862f:	78 7f                	js     86b0 <fwp_drop10+0x140>
    8631:	48 39 c8             	cmp    %rcx,%rax
    8634:	73 cb                	jae    8601 <fwp_drop10+0x91>
    8636:	48 89 c1             	mov    %rax,%rcx
    8639:	48 c1 e9 10          	shr    $0x10,%rcx
    863d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8641:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8645:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8649:	48 85 f6             	test   %rsi,%rsi
    864c:	74 b3                	je     8601 <fwp_drop10+0x91>
    864e:	0f b6 39             	movzbl (%rcx),%edi
    8651:	40 80 ff 02          	cmp    $0x2,%dil
    8655:	74 39                	je     8690 <fwp_drop10+0x120>
    8657:	40 80 ff 01          	cmp    $0x1,%dil
    865b:	75 a4                	jne    8601 <fwp_drop10+0x91>
    865d:	8b 79 18             	mov    0x18(%rcx),%edi
    8660:	0f b7 c0             	movzwl %ax,%eax
    8663:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8666:	48 0f af c7          	imul   %rdi,%rax
    866a:	48 c1 e8 20          	shr    $0x20,%rax
    866e:	48 39 c8             	cmp    %rcx,%rax
    8671:	73 8e                	jae    8601 <fwp_drop10+0x91>
    8673:	48 01 c6             	add    %rax,%rsi
    8676:	80 3e 01             	cmpb   $0x1,(%rsi)
    8679:	75 86                	jne    8601 <fwp_drop10+0x91>
    867b:	48 89 d7             	mov    %rdx,%rdi
    867e:	48 83 c4 18          	add    $0x18,%rsp
    8682:	e9 29 d3 ff ff       	jmp    59b0 <fwp_mem_free>
    8687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    868e:	00 00 
    8690:	66 85 c0             	test   %ax,%ax
    8693:	74 e1                	je     8676 <fwp_drop10+0x106>
    8695:	48 83 c4 18          	add    $0x18,%rsp
    8699:	c3                   	ret
    869a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86a0:	66 85 c0             	test   %ax,%ax
    86a3:	0f 84 40 ff ff ff    	je     85e9 <fwp_drop10+0x79>
    86a9:	48 83 c4 18          	add    $0x18,%rsp
    86ad:	c3                   	ret
    86ae:	66 90                	xchg   %ax,%ax
    86b0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    86b4:	48 39 c8             	cmp    %rcx,%rax
    86b7:	73 74                	jae    872d <fwp_drop10+0x1bd>
    86b9:	49 89 c2             	mov    %rax,%r10
    86bc:	49 c1 ea 10          	shr    $0x10,%r10
    86c0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    86c4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    86c8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    86cc:	4d 85 d2             	test   %r10,%r10
    86cf:	74 5c                	je     872d <fwp_drop10+0x1bd>
    86d1:	45 0f b6 18          	movzbl (%r8),%r11d
    86d5:	41 80 fb 02          	cmp    $0x2,%r11b
    86d9:	74 6d                	je     8748 <fwp_drop10+0x1d8>
    86db:	41 80 fb 01          	cmp    $0x1,%r11b
    86df:	75 4c                	jne    872d <fwp_drop10+0x1bd>
    86e1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    86e5:	0f b7 c0             	movzwl %ax,%eax
    86e8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    86ec:	49 0f af c3          	imul   %r11,%rax
    86f0:	48 c1 e8 20          	shr    $0x20,%rax
    86f4:	4c 39 c0             	cmp    %r8,%rax
    86f7:	73 34                	jae    872d <fwp_drop10+0x1bd>
    86f9:	49 01 c2             	add    %rax,%r10
    86fc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8700:	75 2b                	jne    872d <fwp_drop10+0x1bd>
    8702:	4c 89 cf             	mov    %r9,%rdi
    8705:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    870a:	e8 a1 d2 ff ff       	call   59b0 <fwp_mem_free>
    870f:	48 8d 35 ea 30 06 00 	lea    0x630ea(%rip),%rsi        # 6b800 <fwp_heap>
    8716:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    871b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8722:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8729:	48 c1 e1 10          	shl    $0x10,%rcx
    872d:	48 89 d0             	mov    %rdx,%rax
    8730:	48 29 f8             	sub    %rdi,%rax
    8733:	48 39 c8             	cmp    %rcx,%rax
    8736:	0f 82 60 fe ff ff    	jb     859c <fwp_drop10+0x2c>
    873c:	e9 c0 fe ff ff       	jmp    8601 <fwp_drop10+0x91>
    8741:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8748:	66 85 c0             	test   %ax,%ax
    874b:	75 e0                	jne    872d <fwp_drop10+0x1bd>
    874d:	eb ad                	jmp    86fc <fwp_drop10+0x18c>
    874f:	90                   	nop
    8750:	c3                   	ret
    8751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8758:	48 89 c8             	mov    %rcx,%rax
    875b:	48 c1 e8 11          	shr    $0x11,%rax
    875f:	48 31 c8             	xor    %rcx,%rax
    8762:	48 89 c2             	mov    %rax,%rdx
    8765:	48 c1 ea 09          	shr    $0x9,%rdx
    8769:	48 31 d0             	xor    %rdx,%rax
    876c:	0f b6 d0             	movzbl %al,%edx
    876f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8776:	00 
    8777:	48 85 c0             	test   %rax,%rax
    877a:	75 0d                	jne    8789 <fwp_drop10+0x219>
    877c:	eb 46                	jmp    87c4 <fwp_drop10+0x254>
    877e:	66 90                	xchg   %ax,%ax
    8780:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8784:	48 85 c0             	test   %rax,%rax
    8787:	74 3b                	je     87c4 <fwp_drop10+0x254>
    8789:	48 89 c2             	mov    %rax,%rdx
    878c:	48 39 08             	cmp    %rcx,(%rax)
    878f:	75 ef                	jne    8780 <fwp_drop10+0x210>
    8791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8795:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8799:	48 89 50 08          	mov    %rdx,0x8(%rax)
    879d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    87a4:	0f 85 57 fe ff ff    	jne    8601 <fwp_drop10+0x91>
    87aa:	48 89 cf             	mov    %rcx,%rdi
    87ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    87b2:	e8 b9 cf ff ff       	call   5770 <fwp_rc_forget_slot>
    87b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    87bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    87bf:	e9 3d fe ff ff       	jmp    8601 <fwp_drop10+0x91>
    87c4:	48 8d 3d 25 72 00 00 	lea    0x7225(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    87cb:	e8 40 bc ff ff       	call   4410 <fwp_trap>

00000000000087d0 <f37>:
    87d0:	41 57                	push   %r15
    87d2:	41 56                	push   %r14
    87d4:	41 55                	push   %r13
    87d6:	41 54                	push   %r12
    87d8:	55                   	push   %rbp
    87d9:	53                   	push   %rbx
    87da:	48 83 ec 48          	sub    $0x48,%rsp
    87de:	48 8b 15 f3 43 06 00 	mov    0x643f3(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    87e5:	48 89 3c 24          	mov    %rdi,(%rsp)
    87e9:	48 c1 e2 10          	shl    $0x10,%rdx
    87ed:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    87f4:	00 00 
    87f6:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    87fb:	48 8b 0d ae 43 06 00 	mov    0x643ae(%rip),%rcx        # 6cbb0 <fwp_heap+0x13b0>
    8802:	48 85 ff             	test   %rdi,%rdi
    8805:	0f 84 2f 03 00 00    	je     8b3a <f37+0x36a>
    880b:	48 8b 04 24          	mov    (%rsp),%rax
    880f:	48 8b 40 10          	mov    0x10(%rax),%rax
    8813:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8818:	48 29 c8             	sub    %rcx,%rax
    881b:	48 39 d0             	cmp    %rdx,%rax
    881e:	0f 83 fc 02 00 00    	jae    8b20 <f37+0x350>
    8824:	48 89 c2             	mov    %rax,%rdx
    8827:	48 c1 ea 10          	shr    $0x10,%rdx
    882b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    882f:	48 8b 15 c2 43 06 00 	mov    0x643c2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    8836:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    883a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    883e:	48 85 ff             	test   %rdi,%rdi
    8841:	0f 84 d9 02 00 00    	je     8b20 <f37+0x350>
    8847:	0f b6 0a             	movzbl (%rdx),%ecx
    884a:	80 f9 02             	cmp    $0x2,%cl
    884d:	0f 84 65 02 00 00    	je     8ab8 <f37+0x2e8>
    8853:	80 f9 01             	cmp    $0x1,%cl
    8856:	75 24                	jne    887c <f37+0xac>
    8858:	8b 4a 18             	mov    0x18(%rdx),%ecx
    885b:	0f b7 c0             	movzwl %ax,%eax
    885e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8861:	48 0f af c1          	imul   %rcx,%rax
    8865:	48 c1 e8 20          	shr    $0x20,%rax
    8869:	48 39 d0             	cmp    %rdx,%rax
    886c:	73 0e                	jae    887c <f37+0xac>
    886e:	48 01 c7             	add    %rax,%rdi
    8871:	0f b6 07             	movzbl (%rdi),%eax
    8874:	84 c0                	test   %al,%al
    8876:	0f 85 54 02 00 00    	jne    8ad0 <f37+0x300>
    887c:	48 8b 04 24          	mov    (%rsp),%rax
    8880:	48 8b 40 10          	mov    0x10(%rax),%rax
    8884:	ba 01 00 00 00       	mov    $0x1,%edx
    8889:	48 85 c0             	test   %rax,%rax
    888c:	74 0f                	je     889d <f37+0xcd>
    888e:	66 90                	xchg   %ax,%ax
    8890:	48 8b 40 10          	mov    0x10(%rax),%rax
    8894:	48 83 c2 01          	add    $0x1,%rdx
    8898:	48 85 c0             	test   %rax,%rax
    889b:	75 f3                	jne    8890 <f37+0xc0>
    889d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    88a2:	48 85 c0             	test   %rax,%rax
    88a5:	0f 84 a5 02 00 00    	je     8b50 <f37+0x380>
    88ab:	31 db                	xor    %ebx,%ebx
    88ad:	0f 1f 00             	nopl   (%rax)
    88b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    88b4:	48 83 c3 01          	add    $0x1,%rbx
    88b8:	48 85 c0             	test   %rax,%rax
    88bb:	75 f3                	jne    88b0 <f37+0xe0>
    88bd:	48 39 d3             	cmp    %rdx,%rbx
    88c0:	48 0f 47 da          	cmova  %rdx,%rbx
    88c4:	48 89 d8             	mov    %rbx,%rax
    88c7:	48 c1 e8 3c          	shr    $0x3c,%rax
    88cb:	0f 85 a1 03 00 00    	jne    8c72 <f37+0x4a2>
    88d1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    88d5:	be 02 00 00 00       	mov    $0x2,%esi
    88da:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    88e1:	00 
    88e2:	e8 c9 d5 ff ff       	call   5eb0 <fwp_heap_alloc>
    88e7:	48 89 28             	mov    %rbp,(%rax)
    88ea:	48 8b 15 e7 42 06 00 	mov    0x642e7(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    88f1:	49 89 c5             	mov    %rax,%r13
    88f4:	48 2b 05 b5 42 06 00 	sub    0x642b5(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    88fb:	48 c1 e2 10          	shl    $0x10,%rdx
    88ff:	48 39 d0             	cmp    %rdx,%rax
    8902:	73 57                	jae    895b <f37+0x18b>
    8904:	48 89 c2             	mov    %rax,%rdx
    8907:	48 c1 ea 10          	shr    $0x10,%rdx
    890b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    890f:	48 8b 15 e2 42 06 00 	mov    0x642e2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    8916:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    891a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    891e:	48 85 ed             	test   %rbp,%rbp
    8921:	74 38                	je     895b <f37+0x18b>
    8923:	0f b6 0a             	movzbl (%rdx),%ecx
    8926:	80 f9 02             	cmp    $0x2,%cl
    8929:	0f 84 e1 01 00 00    	je     8b10 <f37+0x340>
    892f:	80 f9 01             	cmp    $0x1,%cl
    8932:	75 27                	jne    895b <f37+0x18b>
    8934:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8937:	0f b7 c0             	movzwl %ax,%eax
    893a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    893d:	48 0f af c1          	imul   %rcx,%rax
    8941:	48 c1 e8 20          	shr    $0x20,%rax
    8945:	48 39 d0             	cmp    %rdx,%rax
    8948:	73 11                	jae    895b <f37+0x18b>
    894a:	48 01 c5             	add    %rax,%rbp
    894d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8951:	0f 84 6d 02 00 00    	je     8bc4 <f37+0x3f4>
    8957:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    895b:	48 85 db             	test   %rbx,%rbx
    895e:	74 74                	je     89d4 <f37+0x204>
    8960:	48 c1 e3 04          	shl    $0x4,%rbx
    8964:	4c 8b 34 24          	mov    (%rsp),%r14
    8968:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    896d:	4c 89 ed             	mov    %r13,%rbp
    8970:	4c 01 eb             	add    %r13,%rbx
    8973:	66 90                	xchg   %ax,%ax
    8975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    897c:	00 00 00 00 
    8980:	49 8b 46 08          	mov    0x8(%r14),%rax
    8984:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8988:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
    898d:	48 c7 44 24 10 ff ff 	movq   $0xffffffffffffffff,0x10(%rsp)
    8994:	ff ff 
    8996:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    899d:	00 00 
    899f:	48 83 c5 10          	add    $0x10,%rbp
    89a3:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    89a8:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    89ac:	48 8b 78 10          	mov    0x10(%rax),%rdi
    89b0:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    89b5:	e8 b6 dc ff ff       	call   6670 <w120>
    89ba:	66 48 0f 6e d0       	movq   %rax,%xmm2
    89bf:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    89c3:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    89c7:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    89cb:	4d 8b 76 10          	mov    0x10(%r14),%r14
    89cf:	48 39 dd             	cmp    %rbx,%rbp
    89d2:	75 ac                	jne    8980 <f37+0x1b0>
    89d4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    89d9:	e8 82 ed ff ff       	call   7760 <fwp_drop4>
    89de:	48 8b 3c 24          	mov    (%rsp),%rdi
    89e2:	e8 79 ed ff ff       	call   7760 <fwp_drop4>
    89e7:	4c 89 ef             	mov    %r13,%rdi
    89ea:	e8 d1 e3 ff ff       	call   6dc0 <w176.constprop.0>
    89ef:	4c 89 ef             	mov    %r13,%rdi
    89f2:	48 89 c3             	mov    %rax,%rbx
    89f5:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    89fa:	e8 71 fb ff ff       	call   8570 <fwp_drop10>
    89ff:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    8a04:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8a09:	31 ff                	xor    %edi,%edi
    8a0b:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    8a10:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8a14:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    8a19:	e8 82 d6 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    8a1e:	48 8b 15 b3 41 06 00 	mov    0x641b3(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    8a25:	48 89 c5             	mov    %rax,%rbp
    8a28:	48 2b 05 81 41 06 00 	sub    0x64181(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    8a2f:	48 c1 e2 10          	shl    $0x10,%rdx
    8a33:	48 39 d0             	cmp    %rdx,%rax
    8a36:	73 55                	jae    8a8d <f37+0x2bd>
    8a38:	48 89 c2             	mov    %rax,%rdx
    8a3b:	48 c1 ea 10          	shr    $0x10,%rdx
    8a3f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a43:	48 8b 15 ae 41 06 00 	mov    0x641ae(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    8a4a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a4e:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8a52:	48 85 db             	test   %rbx,%rbx
    8a55:	74 36                	je     8a8d <f37+0x2bd>
    8a57:	0f b6 0a             	movzbl (%rdx),%ecx
    8a5a:	80 f9 02             	cmp    $0x2,%cl
    8a5d:	0f 84 9d 00 00 00    	je     8b00 <f37+0x330>
    8a63:	80 f9 01             	cmp    $0x1,%cl
    8a66:	75 25                	jne    8a8d <f37+0x2bd>
    8a68:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a6b:	0f b7 c0             	movzwl %ax,%eax
    8a6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a71:	48 0f af c1          	imul   %rcx,%rax
    8a75:	48 c1 e8 20          	shr    $0x20,%rax
    8a79:	48 39 d0             	cmp    %rdx,%rax
    8a7c:	73 0f                	jae    8a8d <f37+0x2bd>
    8a7e:	48 01 c3             	add    %rax,%rbx
    8a81:	80 3b ff             	cmpb   $0xff,(%rbx)
    8a84:	0f 84 2d 01 00 00    	je     8bb7 <f37+0x3e7>
    8a8a:	c6 03 01             	movb   $0x1,(%rbx)
    8a8d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8a92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a99:	00 00 
    8a9b:	0f 85 dd 01 00 00    	jne    8c7e <f37+0x4ae>
    8aa1:	48 83 c4 48          	add    $0x48,%rsp
    8aa5:	48 89 e8             	mov    %rbp,%rax
    8aa8:	5b                   	pop    %rbx
    8aa9:	5d                   	pop    %rbp
    8aaa:	41 5c                	pop    %r12
    8aac:	41 5d                	pop    %r13
    8aae:	41 5e                	pop    %r14
    8ab0:	41 5f                	pop    %r15
    8ab2:	c3                   	ret
    8ab3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ab8:	66 85 c0             	test   %ax,%ax
    8abb:	0f 85 bb fd ff ff    	jne    887c <f37+0xac>
    8ac1:	0f b6 07             	movzbl (%rdi),%eax
    8ac4:	84 c0                	test   %al,%al
    8ac6:	0f 84 b0 fd ff ff    	je     887c <f37+0xac>
    8acc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ad0:	8b 15 f2 49 06 00    	mov    0x649f2(%rip),%edx        # 6d4c8 <iteration_active>
    8ad6:	85 d2                	test   %edx,%edx
    8ad8:	75 56                	jne    8b30 <f37+0x360>
    8ada:	3c fd                	cmp    $0xfd,%al
    8adc:	0f 87 57 01 00 00    	ja     8c39 <f37+0x469>
    8ae2:	83 c0 01             	add    $0x1,%eax
    8ae5:	88 07                	mov    %al,(%rdi)
    8ae7:	31 d2                	xor    %edx,%edx
    8ae9:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    8aee:	0f 85 88 fd ff ff    	jne    887c <f37+0xac>
    8af4:	e9 a4 fd ff ff       	jmp    889d <f37+0xcd>
    8af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b00:	66 85 c0             	test   %ax,%ax
    8b03:	75 88                	jne    8a8d <f37+0x2bd>
    8b05:	e9 77 ff ff ff       	jmp    8a81 <f37+0x2b1>
    8b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b10:	66 85 c0             	test   %ax,%ax
    8b13:	0f 85 42 fe ff ff    	jne    895b <f37+0x18b>
    8b19:	e9 2f fe ff ff       	jmp    894d <f37+0x17d>
    8b1e:	66 90                	xchg   %ax,%ax
    8b20:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8b25:	e9 5a fd ff ff       	jmp    8884 <f37+0xb4>
    8b2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b30:	48 83 05 78 49 06 00 	addq   $0x1,0x64978(%rip)        # 6d4b0 <iteration_retains>
    8b37:	01 
    8b38:	eb a0                	jmp    8ada <f37+0x30a>
    8b3a:	48 f7 d9             	neg    %rcx
    8b3d:	48 39 d1             	cmp    %rdx,%rcx
    8b40:	0f 82 8b 00 00 00    	jb     8bd1 <f37+0x401>
    8b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b4d:	00 00 00 
    8b50:	be 02 00 00 00       	mov    $0x2,%esi
    8b55:	bf 08 00 00 00       	mov    $0x8,%edi
    8b5a:	e8 51 d3 ff ff       	call   5eb0 <fwp_heap_alloc>
    8b5f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8b66:	48 8b 15 6b 40 06 00 	mov    0x6406b(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    8b6d:	49 89 c5             	mov    %rax,%r13
    8b70:	48 2b 05 39 40 06 00 	sub    0x64039(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    8b77:	48 c1 e2 10          	shl    $0x10,%rdx
    8b7b:	48 39 d0             	cmp    %rdx,%rax
    8b7e:	0f 83 bf 00 00 00    	jae    8c43 <f37+0x473>
    8b84:	48 89 c2             	mov    %rax,%rdx
    8b87:	48 c1 ea 10          	shr    $0x10,%rdx
    8b8b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b8f:	48 8b 15 62 40 06 00 	mov    0x64062(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    8b96:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b9a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8b9e:	48 85 ed             	test   %rbp,%rbp
    8ba1:	0f 84 9c 00 00 00    	je     8c43 <f37+0x473>
    8ba7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8bae:	00 00 
    8bb0:	31 db                	xor    %ebx,%ebx
    8bb2:	e9 6c fd ff ff       	jmp    8923 <f37+0x153>
    8bb7:	48 89 df             	mov    %rbx,%rdi
    8bba:	e8 b1 cb ff ff       	call   5770 <fwp_rc_forget_slot>
    8bbf:	e9 c6 fe ff ff       	jmp    8a8a <f37+0x2ba>
    8bc4:	48 89 ef             	mov    %rbp,%rdi
    8bc7:	e8 a4 cb ff ff       	call   5770 <fwp_rc_forget_slot>
    8bcc:	e9 86 fd ff ff       	jmp    8957 <f37+0x187>
    8bd1:	48 89 c8             	mov    %rcx,%rax
    8bd4:	48 c1 e8 10          	shr    $0x10,%rax
    8bd8:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8bdc:	48 8b 05 15 40 06 00 	mov    0x64015(%rip),%rax        # 6cbf8 <fwp_heap+0x13f8>
    8be3:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8be7:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8beb:	48 85 ff             	test   %rdi,%rdi
    8bee:	0f 84 5c ff ff ff    	je     8b50 <f37+0x380>
    8bf4:	0f b6 02             	movzbl (%rdx),%eax
    8bf7:	3c 02                	cmp    $0x2,%al
    8bf9:	74 56                	je     8c51 <f37+0x481>
    8bfb:	3c 01                	cmp    $0x1,%al
    8bfd:	0f 85 4d ff ff ff    	jne    8b50 <f37+0x380>
    8c03:	0f b7 c1             	movzwl %cx,%eax
    8c06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c0c:	48 0f af c1          	imul   %rcx,%rax
    8c10:	48 c1 e8 20          	shr    $0x20,%rax
    8c14:	48 39 d0             	cmp    %rdx,%rax
    8c17:	0f 83 33 ff ff ff    	jae    8b50 <f37+0x380>
    8c1d:	48 01 c7             	add    %rax,%rdi
    8c20:	0f b6 07             	movzbl (%rdi),%eax
    8c23:	84 c0                	test   %al,%al
    8c25:	0f 84 25 ff ff ff    	je     8b50 <f37+0x380>
    8c2b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8c32:	00 00 
    8c34:	e9 97 fe ff ff       	jmp    8ad0 <f37+0x300>
    8c39:	e8 12 ca ff ff       	call   5650 <fwp_rc_wide_dup>
    8c3e:	e9 a4 fe ff ff       	jmp    8ae7 <f37+0x317>
    8c43:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8c4a:	00 00 
    8c4c:	e9 83 fd ff ff       	jmp    89d4 <f37+0x204>
    8c51:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8c57:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c5c:	0f 85 ee fe ff ff    	jne    8b50 <f37+0x380>
    8c62:	0f b6 07             	movzbl (%rdi),%eax
    8c65:	84 c0                	test   %al,%al
    8c67:	0f 85 63 fe ff ff    	jne    8ad0 <f37+0x300>
    8c6d:	e9 de fe ff ff       	jmp    8b50 <f37+0x380>
    8c72:	48 8d 3d 74 65 00 00 	lea    0x6574(%rip),%rdi        # f1ed <_IO_stdin_used+0x1ed>
    8c79:	e8 92 b7 ff ff       	call   4410 <fwp_trap>
    8c7e:	e8 bd a7 ff ff       	call   3440 <__stack_chk_fail@plt>
    8c83:	66 90                	xchg   %ax,%ax
    8c85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c8c:	00 00 00 00 

0000000000008c90 <fwp_owned_entry37>:
    8c90:	f3 0f 1e fa          	endbr64
    8c94:	48 8b 3f             	mov    (%rdi),%rdi
    8c97:	e9 34 fb ff ff       	jmp    87d0 <f37>
    8c9c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008ca0 <e37>:
    8ca0:	f3 0f 1e fa          	endbr64
    8ca4:	53                   	push   %rbx
    8ca5:	48 8b 1f             	mov    (%rdi),%rbx
    8ca8:	48 89 df             	mov    %rbx,%rdi
    8cab:	e8 c0 e1 ff ff       	call   6e70 <fwp_rc_share>
    8cb0:	48 89 df             	mov    %rbx,%rdi
    8cb3:	e8 18 fb ff ff       	call   87d0 <f37>
    8cb8:	48 89 c3             	mov    %rax,%rbx
    8cbb:	48 89 c7             	mov    %rax,%rdi
    8cbe:	e8 ad e1 ff ff       	call   6e70 <fwp_rc_share>
    8cc3:	48 89 d8             	mov    %rbx,%rax
    8cc6:	5b                   	pop    %rbx
    8cc7:	c3                   	ret
    8cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ccf:	00 

0000000000008cd0 <fwp_write>:
    8cd0:	41 57                	push   %r15
    8cd2:	41 56                	push   %r14
    8cd4:	41 55                	push   %r13
    8cd6:	41 54                	push   %r12
    8cd8:	55                   	push   %rbp
    8cd9:	53                   	push   %rbx
    8cda:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8ce1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8ce8:	00 00 
    8cea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8cf1:	00 
    8cf2:	49 89 d4             	mov    %rdx,%r12
    8cf5:	8b 12                	mov    (%rdx),%edx
    8cf7:	83 fa 19             	cmp    $0x19,%edx
    8cfa:	77 6a                	ja     8d66 <fwp_write+0x96>
    8cfc:	48 89 f5             	mov    %rsi,%rbp
    8cff:	89 d0                	mov    %edx,%eax
    8d01:	89 ce                	mov    %ecx,%esi
    8d03:	48 89 fb             	mov    %rdi,%rbx
    8d06:	48 8d 0d c3 6f 00 00 	lea    0x6fc3(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    8d0d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8d11:	48 01 c8             	add    %rcx,%rax
    8d14:	3e ff e0             	notrack jmp *%rax
    8d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d1e:	00 00 
    8d20:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8d24:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8d28:	48 89 ca             	mov    %rcx,%rdx
    8d2b:	48 85 c9             	test   %rcx,%rcx
    8d2e:	0f 88 9c 0c 00 00    	js     99d0 <fwp_write+0xd00>
    8d34:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8d3b:	00 
    8d3c:	48 89 c6             	mov    %rax,%rsi
    8d3f:	4c 89 e7             	mov    %r12,%rdi
    8d42:	e8 b9 ac ff ff       	call   3a00 <fwp_fmt_u128>
    8d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d4e:	00 00 
    8d50:	4c 89 e7             	mov    %r12,%rdi
    8d53:	e8 d8 a6 ff ff       	call   3430 <strlen@plt>
    8d58:	4c 89 e6             	mov    %r12,%rsi
    8d5b:	48 89 df             	mov    %rbx,%rdi
    8d5e:	48 89 c2             	mov    %rax,%rdx
    8d61:	e8 4a b3 ff ff       	call   40b0 <buf_put>
    8d66:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d6d:	00 
    8d6e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d75:	00 00 
    8d77:	0f 85 28 04 00 00    	jne    91a5 <fwp_write+0x4d5>
    8d7d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8d84:	5b                   	pop    %rbx
    8d85:	5d                   	pop    %rbp
    8d86:	41 5c                	pop    %r12
    8d88:	41 5d                	pop    %r13
    8d8a:	41 5e                	pop    %r14
    8d8c:	41 5f                	pop    %r15
    8d8e:	c3                   	ret
    8d8f:	90                   	nop
    8d90:	49 89 e9             	mov    %rbp,%r9
    8d93:	4c 8d 05 7d 64 00 00 	lea    0x647d(%rip),%r8        # f217 <_IO_stdin_used+0x217>
    8d9a:	b9 00 02 00 00       	mov    $0x200,%ecx
    8d9f:	ba 02 00 00 00       	mov    $0x2,%edx
    8da4:	be 00 02 00 00       	mov    $0x200,%esi
    8da9:	31 c0                	xor    %eax,%eax
    8dab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8db2:	00 
    8db3:	e8 d8 a5 ff ff       	call   3390 <__snprintf_chk@plt>
    8db8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8dbf:	00 
    8dc0:	e8 6b a6 ff ff       	call   3430 <strlen@plt>
    8dc5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8dcc:	00 
    8dcd:	48 89 df             	mov    %rbx,%rdi
    8dd0:	48 89 c2             	mov    %rax,%rdx
    8dd3:	e8 d8 b2 ff ff       	call   40b0 <buf_put>
    8dd8:	eb 8c                	jmp    8d66 <fwp_write+0x96>
    8dda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8de0:	49 89 e9             	mov    %rbp,%r9
    8de3:	4c 8d 05 28 64 00 00 	lea    0x6428(%rip),%r8        # f212 <_IO_stdin_used+0x212>
    8dea:	eb ae                	jmp    8d9a <fwp_write+0xca>
    8dec:	0f 1f 40 00          	nopl   0x0(%rax)
    8df0:	83 fa 13             	cmp    $0x13,%edx
    8df3:	48 8d 05 0e 64 00 00 	lea    0x640e(%rip),%rax        # f208 <_IO_stdin_used+0x208>
    8dfa:	48 8d 35 0c 64 00 00 	lea    0x640c(%rip),%rsi        # f20d <_IO_stdin_used+0x20d>
    8e01:	ba 04 00 00 00       	mov    $0x4,%edx
    8e06:	48 0f 44 f0          	cmove  %rax,%rsi
    8e0a:	45 31 ed             	xor    %r13d,%r13d
    8e0d:	e8 9e b2 ff ff       	call   40b0 <buf_put>
    8e12:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8e17:	0f 84 a3 08 00 00    	je     96c0 <fwp_write+0x9f0>
    8e1d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8e22:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8e27:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e2c:	48 89 df             	mov    %rbx,%rdi
    8e2f:	49 0f 44 c5          	cmove  %r13,%rax
    8e33:	31 c9                	xor    %ecx,%ecx
    8e35:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    8e3a:	e8 91 fe ff ff       	call   8cd0 <fwp_write>
    8e3f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8e44:	0f 84 6e 09 00 00    	je     97b8 <fwp_write+0xae8>
    8e4a:	49 83 c5 01          	add    $0x1,%r13
    8e4e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8e52:	0f 83 68 08 00 00    	jae    96c0 <fwp_write+0x9f0>
    8e58:	ba 02 00 00 00       	mov    $0x2,%edx
    8e5d:	48 8d 35 f3 63 00 00 	lea    0x63f3(%rip),%rsi        # f257 <_IO_stdin_used+0x257>
    8e64:	48 89 df             	mov    %rbx,%rdi
    8e67:	e8 44 b2 ff ff       	call   40b0 <buf_put>
    8e6c:	eb af                	jmp    8e1d <fwp_write+0x14d>
    8e6e:	66 90                	xchg   %ax,%ax
    8e70:	ba 06 00 00 00       	mov    $0x6,%edx
    8e75:	48 8d 35 b4 63 00 00 	lea    0x63b4(%rip),%rsi        # f230 <_IO_stdin_used+0x230>
    8e7c:	48 83 c5 10          	add    $0x10,%rbp
    8e80:	e8 2b b2 ff ff       	call   40b0 <buf_put>
    8e85:	48 89 ef             	mov    %rbp,%rdi
    8e88:	e8 a3 a5 ff ff       	call   3430 <strlen@plt>
    8e8d:	48 89 ee             	mov    %rbp,%rsi
    8e90:	48 89 df             	mov    %rbx,%rdi
    8e93:	48 89 c2             	mov    %rax,%rdx
    8e96:	e8 15 b2 ff ff       	call   40b0 <buf_put>
    8e9b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ea0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ea5:	48 89 df             	mov    %rbx,%rdi
    8ea8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8ead:	e8 fe b1 ff ff       	call   40b0 <buf_put>
    8eb2:	e9 af fe ff ff       	jmp    8d66 <fwp_write+0x96>
    8eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ebe:	00 00 
    8ec0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ec7:	00 
    8ec8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8ecf:	00 00 
    8ed1:	0f 85 ce 02 00 00    	jne    91a5 <fwp_write+0x4d5>
    8ed7:	ba 0a 00 00 00       	mov    $0xa,%edx
    8edc:	48 8d 35 39 63 00 00 	lea    0x6339(%rip),%rsi        # f21c <_IO_stdin_used+0x21c>
    8ee3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8eea:	48 89 df             	mov    %rbx,%rdi
    8eed:	5b                   	pop    %rbx
    8eee:	5d                   	pop    %rbp
    8eef:	41 5c                	pop    %r12
    8ef1:	41 5d                	pop    %r13
    8ef3:	41 5e                	pop    %r14
    8ef5:	41 5f                	pop    %r15
    8ef7:	e9 b4 b1 ff ff       	jmp    40b0 <buf_put>
    8efc:	0f 1f 40 00          	nopl   0x0(%rax)
    8f00:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8f05:	4d 85 ed             	test   %r13,%r13
    8f08:	0f 84 02 0c 00 00    	je     9b10 <fwp_write+0xe40>
    8f0e:	48 8d 35 4f 63 00 00 	lea    0x634f(%rip),%rsi        # f264 <_IO_stdin_used+0x264>
    8f15:	4c 89 ef             	mov    %r13,%rdi
    8f18:	e8 f3 a5 ff ff       	call   3510 <strcmp@plt>
    8f1d:	41 89 c1             	mov    %eax,%r9d
    8f20:	85 c0                	test   %eax,%eax
    8f22:	0f 84 6c 0c 00 00    	je     9b94 <fwp_write+0xec4>
    8f28:	4c 89 ef             	mov    %r13,%rdi
    8f2b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8f30:	e8 fb a4 ff ff       	call   3430 <strlen@plt>
    8f35:	4c 89 ee             	mov    %r13,%rsi
    8f38:	48 89 df             	mov    %rbx,%rdi
    8f3b:	48 89 c2             	mov    %rax,%rdx
    8f3e:	e8 6d b1 ff ff       	call   40b0 <buf_put>
    8f43:	ba 01 00 00 00       	mov    $0x1,%edx
    8f48:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f4d:	48 89 df             	mov    %rbx,%rdi
    8f50:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8f55:	e8 56 b1 ff ff       	call   40b0 <buf_put>
    8f5a:	ba 01 00 00 00       	mov    $0x1,%edx
    8f5f:	4c 89 fe             	mov    %r15,%rsi
    8f62:	48 89 df             	mov    %rbx,%rdi
    8f65:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8f6a:	e8 41 b1 ff ff       	call   40b0 <buf_put>
    8f6f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8f74:	45 31 f6             	xor    %r14d,%r14d
    8f77:	85 d2                	test   %edx,%edx
    8f79:	0f 8e 81 0a 00 00    	jle    9a00 <fwp_write+0xd30>
    8f7f:	45 31 ed             	xor    %r13d,%r13d
    8f82:	4d 85 ed             	test   %r13,%r13
    8f85:	0f 85 75 07 00 00    	jne    9700 <fwp_write+0xa30>
    8f8b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f92:	00 
    8f93:	45 85 f6             	test   %r14d,%r14d
    8f96:	0f 84 84 07 00 00    	je     9720 <fwp_write+0xa50>
    8f9c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8fa1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8fa6:	48 89 df             	mov    %rbx,%rdi
    8fa9:	49 83 c5 01          	add    $0x1,%r13
    8fad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8fb1:	31 c9                	xor    %ecx,%ecx
    8fb3:	e8 18 fd ff ff       	call   8cd0 <fwp_write>
    8fb8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8fbd:	7f c3                	jg     8f82 <fwp_write+0x2b2>
    8fbf:	45 85 f6             	test   %r14d,%r14d
    8fc2:	0f 84 38 0a 00 00    	je     9a00 <fwp_write+0xd30>
    8fc8:	b8 29 00 00 00       	mov    $0x29,%eax
    8fcd:	ba 01 00 00 00       	mov    $0x1,%edx
    8fd2:	4c 89 fe             	mov    %r15,%rsi
    8fd5:	48 89 df             	mov    %rbx,%rdi
    8fd8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8fdc:	e8 cf b0 ff ff       	call   40b0 <buf_put>
    8fe1:	e9 80 fd ff ff       	jmp    8d66 <fwp_write+0x96>
    8fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fed:	00 00 00 
    8ff0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ff5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ffa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8fff:	e8 ac b0 ff ff       	call   40b0 <buf_put>
    9004:	48 85 ed             	test   %rbp,%rbp
    9007:	0f 84 93 06 00 00    	je     96a0 <fwp_write+0x9d0>
    900d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9011:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9016:	31 c9                	xor    %ecx,%ecx
    9018:	48 89 df             	mov    %rbx,%rdi
    901b:	e8 b0 fc ff ff       	call   8cd0 <fwp_write>
    9020:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9024:	48 85 ed             	test   %rbp,%rbp
    9027:	0f 84 73 06 00 00    	je     96a0 <fwp_write+0x9d0>
    902d:	ba 02 00 00 00       	mov    $0x2,%edx
    9032:	48 8d 35 1e 62 00 00 	lea    0x621e(%rip),%rsi        # f257 <_IO_stdin_used+0x257>
    9039:	48 89 df             	mov    %rbx,%rdi
    903c:	e8 6f b0 ff ff       	call   40b0 <buf_put>
    9041:	eb ca                	jmp    900d <fwp_write+0x33d>
    9043:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9048:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    904c:	85 f6                	test   %esi,%esi
    904e:	0f 84 fc 07 00 00    	je     9850 <fwp_write+0xb80>
    9054:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    905b:	00 
    905c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9063:	00 00 
    9065:	0f 85 3a 01 00 00    	jne    91a5 <fwp_write+0x4d5>
    906b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    906f:	4c 89 ea             	mov    %r13,%rdx
    9072:	e9 6c fe ff ff       	jmp    8ee3 <fwp_write+0x213>
    9077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    907e:	00 00 
    9080:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9085:	ba 01 00 00 00       	mov    $0x1,%edx
    908a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    908f:	48 89 ee             	mov    %rbp,%rsi
    9092:	e8 19 b0 ff ff       	call   40b0 <buf_put>
    9097:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    909c:	4c 89 e7             	mov    %r12,%rdi
    909f:	e8 8c a3 ff ff       	call   3430 <strlen@plt>
    90a4:	4c 89 e6             	mov    %r12,%rsi
    90a7:	48 89 df             	mov    %rbx,%rdi
    90aa:	48 89 c2             	mov    %rax,%rdx
    90ad:	e8 fe af ff ff       	call   40b0 <buf_put>
    90b2:	ba 01 00 00 00       	mov    $0x1,%edx
    90b7:	48 89 ee             	mov    %rbp,%rsi
    90ba:	48 89 df             	mov    %rbx,%rdi
    90bd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    90c2:	e8 e9 af ff ff       	call   40b0 <buf_put>
    90c7:	e9 9a fc ff ff       	jmp    8d66 <fwp_write+0x96>
    90cc:	0f 1f 40 00          	nopl   0x0(%rax)
    90d0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    90d5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    90d9:	0f 8a 8e 0b 00 00    	jp     9c6d <fwp_write+0xf9d>
    90df:	66 0f 28 c1          	movapd %xmm1,%xmm0
    90e3:	66 0f 54 05 35 6d 00 	andpd  0x6d35(%rip),%xmm0        # fe20 <msg.4+0xe0>
    90ea:	00 
    90eb:	bd 01 00 00 00       	mov    $0x1,%ebp
    90f0:	66 0f 2e 05 70 6c 00 	ucomisd 0x6c70(%rip),%xmm0        # fd68 <msg.4+0x28>
    90f7:	00 
    90f8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    90ff:	00 
    9100:	0f 87 b2 09 00 00    	ja     9ab8 <fwp_write+0xde8>
    9106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    910d:	00 00 00 
    9110:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9114:	89 ee                	mov    %ebp,%esi
    9116:	4c 89 e7             	mov    %r12,%rdi
    9119:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    911e:	e8 0d b6 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9123:	31 f6                	xor    %esi,%esi
    9125:	4c 89 e7             	mov    %r12,%rdi
    9128:	e8 c3 a2 ff ff       	call   33f0 <strtod@plt>
    912d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9132:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9136:	7a 06                	jp     913e <fwp_write+0x46e>
    9138:	0f 84 e9 01 00 00    	je     9327 <fwp_write+0x657>
    913e:	83 c5 01             	add    $0x1,%ebp
    9141:	83 fd 12             	cmp    $0x12,%ebp
    9144:	75 ca                	jne    9110 <fwp_write+0x440>
    9146:	be 11 00 00 00       	mov    $0x11,%esi
    914b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    914f:	4c 89 e7             	mov    %r12,%rdi
    9152:	e8 d9 b5 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9157:	e9 cb 01 00 00       	jmp    9327 <fwp_write+0x657>
    915c:	0f 1f 40 00          	nopl   0x0(%rax)
    9160:	48 83 fd 01          	cmp    $0x1,%rbp
    9164:	0f 84 e6 08 00 00    	je     9a50 <fwp_write+0xd80>
    916a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    916e:	b8 02 00 00 00       	mov    $0x2,%eax
    9173:	ba 01 00 00 00       	mov    $0x1,%edx
    9178:	48 0f 44 d0          	cmove  %rax,%rdx
    917c:	48 8d 35 7d 60 00 00 	lea    0x607d(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    9183:	48 8d 05 7b 60 00 00 	lea    0x607b(%rip),%rax        # f205 <_IO_stdin_used+0x205>
    918a:	48 0f 44 f0          	cmove  %rax,%rsi
    918e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9195:	00 
    9196:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    919d:	00 00 
    919f:	0f 84 3e fd ff ff    	je     8ee3 <fwp_write+0x213>
    91a5:	e8 96 a2 ff ff       	call   3440 <__stack_chk_fail@plt>
    91aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91b0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    91b5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    91ba:	e8 31 ae ff ff       	call   3ff0 <buf_grow>
    91bf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    91c3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    91c9:	4c 03 0b             	add    (%rbx),%r9
    91cc:	66 45 89 11          	mov    %r10w,(%r9)
    91d0:	45 85 e4             	test   %r12d,%r12d
    91d3:	0f 8e 07 05 00 00    	jle    96e0 <fwp_write+0xa10>
    91d9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    91e0:	55 55 55 
    91e3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    91e8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    91ef:	aa aa aa 
    91f2:	49 83 c1 01          	add    $0x1,%r9
    91f6:	eb 45                	jmp    923d <fwp_write+0x56d>
    91f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91ff:	00 
    9200:	be 01 00 00 00       	mov    $0x1,%esi
    9205:	b8 2d 00 00 00       	mov    $0x2d,%eax
    920a:	88 07                	mov    %al,(%rdi)
    920c:	48 89 e8             	mov    %rbp,%rax
    920f:	49 f7 e8             	imul   %r8
    9212:	48 89 e8             	mov    %rbp,%rax
    9215:	48 c1 f8 3f          	sar    $0x3f,%rax
    9219:	48 29 c2             	sub    %rax,%rdx
    921c:	48 85 c9             	test   %rcx,%rcx
    921f:	0f 95 c0             	setne  %al
    9222:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9226:	48 83 ef 01          	sub    $0x1,%rdi
    922a:	48 21 c5             	and    %rax,%rbp
    922d:	48 29 ea             	sub    %rbp,%rdx
    9230:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9234:	49 39 f9             	cmp    %rdi,%r9
    9237:	0f 84 a3 04 00 00    	je     96e0 <fwp_write+0xa10>
    923d:	48 89 e8             	mov    %rbp,%rax
    9240:	49 f7 e8             	imul   %r8
    9243:	48 89 e8             	mov    %rbp,%rax
    9246:	48 c1 f8 3f          	sar    $0x3f,%rax
    924a:	48 89 d1             	mov    %rdx,%rcx
    924d:	48 29 c1             	sub    %rax,%rcx
    9250:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9254:	48 89 e9             	mov    %rbp,%rcx
    9257:	48 29 c1             	sub    %rax,%rcx
    925a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    925e:	49 f7 e2             	mul    %r10
    9261:	b8 30 00 00 00       	mov    $0x30,%eax
    9266:	48 89 d6             	mov    %rdx,%rsi
    9269:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    926d:	48 d1 ee             	shr    $1,%rsi
    9270:	48 01 f2             	add    %rsi,%rdx
    9273:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9277:	48 29 d6             	sub    %rdx,%rsi
    927a:	74 8e                	je     920a <fwp_write+0x53a>
    927c:	48 83 fe 01          	cmp    $0x1,%rsi
    9280:	0f 85 7a ff ff ff    	jne    9200 <fwp_write+0x530>
    9286:	31 f6                	xor    %esi,%esi
    9288:	b8 2b 00 00 00       	mov    $0x2b,%eax
    928d:	e9 78 ff ff ff       	jmp    920a <fwp_write+0x53a>
    9292:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9298:	66 0f 6e cd          	movd   %ebp,%xmm1
    929c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    929f:	0f 8a c8 09 00 00    	jp     9c6d <fwp_write+0xf9d>
    92a5:	0f 28 c1             	movaps %xmm1,%xmm0
    92a8:	0f 54 05 61 6b 00 00 	andps  0x6b61(%rip),%xmm0        # fe10 <msg.4+0xd0>
    92af:	0f 2e 05 4e 5d 00 00 	ucomiss 0x5d4e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    92b6:	0f 87 24 08 00 00    	ja     9ae0 <fwp_write+0xe10>
    92bc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    92c0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    92c6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92cd:	00 
    92ce:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    92d2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    92d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    92de:	00 00 
    92e0:	44 89 ee             	mov    %r13d,%esi
    92e3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    92e8:	4c 89 e7             	mov    %r12,%rdi
    92eb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    92f0:	e8 3b b4 ff ff       	call   4730 <fwp_format_g.constprop.0>
    92f5:	31 f6                	xor    %esi,%esi
    92f7:	4c 89 e7             	mov    %r12,%rdi
    92fa:	e8 91 a1 ff ff       	call   3490 <strtof@plt>
    92ff:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9304:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9307:	7a 02                	jp     930b <fwp_write+0x63b>
    9309:	74 1c                	je     9327 <fwp_write+0x657>
    930b:	41 83 c5 01          	add    $0x1,%r13d
    930f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9313:	75 cb                	jne    92e0 <fwp_write+0x610>
    9315:	be 09 00 00 00       	mov    $0x9,%esi
    931a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    931f:	4c 89 e7             	mov    %r12,%rdi
    9322:	e8 09 b4 ff ff       	call   4730 <fwp_format_g.constprop.0>
    9327:	4c 89 e7             	mov    %r12,%rdi
    932a:	e8 41 ae ff ff       	call   4170 <fwp_finish_float>
    932f:	e9 1c fa ff ff       	jmp    8d50 <fwp_write+0x80>
    9334:	0f 1f 40 00          	nopl   0x0(%rax)
    9338:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    933c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9340:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9347:	00 
    9348:	48 89 ef             	mov    %rbp,%rdi
    934b:	e8 b0 a6 ff ff       	call   3a00 <fwp_fmt_u128>
    9350:	48 89 ef             	mov    %rbp,%rdi
    9353:	e8 d8 a0 ff ff       	call   3430 <strlen@plt>
    9358:	48 89 ee             	mov    %rbp,%rsi
    935b:	48 89 df             	mov    %rbx,%rdi
    935e:	48 89 c2             	mov    %rax,%rdx
    9361:	e8 4a ad ff ff       	call   40b0 <buf_put>
    9366:	e9 fb f9 ff ff       	jmp    8d66 <fwp_write+0x96>
    936b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9370:	ba 06 00 00 00       	mov    $0x6,%edx
    9375:	48 8d 35 de 5e 00 00 	lea    0x5ede(%rip),%rsi        # f25a <_IO_stdin_used+0x25a>
    937c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9382:	e8 29 ad ff ff       	call   40b0 <buf_put>
    9387:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    938e:	ff ff 7f 
    9391:	48 23 55 00          	and    0x0(%rbp),%rdx
    9395:	0f 84 86 02 00 00    	je     9621 <fwp_write+0x951>
    939b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    93a0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    93a4:	48 85 d2             	test   %rdx,%rdx
    93a7:	0f 84 ae 00 00 00    	je     945b <fwp_write+0x78b>
    93ad:	8b 0a                	mov    (%rdx),%ecx
    93af:	83 f9 1c             	cmp    $0x1c,%ecx
    93b2:	0f 84 58 06 00 00    	je     9a10 <fwp_write+0xd40>
    93b8:	83 f9 1b             	cmp    $0x1b,%ecx
    93bb:	0f 87 9a 00 00 00    	ja     945b <fwp_write+0x78b>
    93c1:	be 01 00 00 00       	mov    $0x1,%esi
    93c6:	48 d3 e6             	shl    %cl,%rsi
    93c9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    93cf:	0f 85 4b 04 00 00    	jne    9820 <fwp_write+0xb50>
    93d5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    93db:	0f 85 0f 04 00 00    	jne    97f0 <fwp_write+0xb20>
    93e1:	83 e6 21             	and    $0x21,%esi
    93e4:	74 75                	je     945b <fwp_write+0x78b>
    93e6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    93eb:	48 85 ff             	test   %rdi,%rdi
    93ee:	79 07                	jns    93f7 <fwp_write+0x727>
    93f0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    93f4:	4c 01 ee             	add    %r13,%rsi
    93f7:	48 0f be 3e          	movsbq (%rsi),%rdi
    93fb:	85 c9                	test   %ecx,%ecx
    93fd:	40 0f b6 f7          	movzbl %dil,%esi
    9401:	48 0f 44 f7          	cmove  %rdi,%rsi
    9405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    940c:	00 00 00 00 
    9410:	31 c9                	xor    %ecx,%ecx
    9412:	48 89 df             	mov    %rbx,%rdi
    9415:	49 83 c5 01          	add    $0x1,%r13
    9419:	e8 b2 f8 ff ff       	call   8cd0 <fwp_write>
    941e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9425:	ff ff 7f 
    9428:	48 23 55 00          	and    0x0(%rbp),%rdx
    942c:	49 39 d5             	cmp    %rdx,%r13
    942f:	0f 83 ec 01 00 00    	jae    9621 <fwp_write+0x951>
    9435:	ba 02 00 00 00       	mov    $0x2,%edx
    943a:	48 89 df             	mov    %rbx,%rdi
    943d:	48 8d 35 13 5e 00 00 	lea    0x5e13(%rip),%rsi        # f257 <_IO_stdin_used+0x257>
    9444:	e8 67 ac ff ff       	call   40b0 <buf_put>
    9449:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    944e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9452:	48 85 d2             	test   %rdx,%rdx
    9455:	0f 85 52 ff ff ff    	jne    93ad <fwp_write+0x6dd>
    945b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9460:	48 85 ff             	test   %rdi,%rdi
    9463:	0f 88 cf 05 00 00    	js     9a38 <fwp_write+0xd68>
    9469:	48 8b 31             	mov    (%rcx),%rsi
    946c:	eb a2                	jmp    9410 <fwp_write+0x740>
    946e:	66 90                	xchg   %ax,%ax
    9470:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9477:	00 
    9478:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    947f:	00 00 
    9481:	0f 85 1e fd ff ff    	jne    91a5 <fwp_write+0x4d5>
    9487:	ba 08 00 00 00       	mov    $0x8,%edx
    948c:	48 8d 35 94 5d 00 00 	lea    0x5d94(%rip),%rsi        # f227 <_IO_stdin_used+0x227>
    9493:	e9 4b fa ff ff       	jmp    8ee3 <fwp_write+0x213>
    9498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    949f:	00 
    94a0:	89 e8                	mov    %ebp,%eax
    94a2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    94a9:	76 03                	jbe    94ae <fwp_write+0x7de>
    94ab:	8b 45 00             	mov    0x0(%rbp),%eax
    94ae:	41 89 c6             	mov    %eax,%r14d
    94b1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    94b6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    94bb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    94bf:	4c 89 ef             	mov    %r13,%rdi
    94c2:	e8 69 9f ff ff       	call   3430 <strlen@plt>
    94c7:	4c 89 ee             	mov    %r13,%rsi
    94ca:	48 89 df             	mov    %rbx,%rdi
    94cd:	48 89 c2             	mov    %rax,%rdx
    94d0:	e8 db ab ff ff       	call   40b0 <buf_put>
    94d5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    94da:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    94de:	85 f6                	test   %esi,%esi
    94e0:	0f 8e 80 f8 ff ff    	jle    8d66 <fwp_write+0x96>
    94e6:	45 31 ed             	xor    %r13d,%r13d
    94e9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    94ee:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    94f3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    94f8:	ba 01 00 00 00       	mov    $0x1,%edx
    94fd:	4c 89 fe             	mov    %r15,%rsi
    9500:	48 89 04 24          	mov    %rax,(%rsp)
    9504:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9509:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    950d:	48 89 df             	mov    %rbx,%rdi
    9510:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9514:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9519:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    951e:	e8 8d ab ff ff       	call   40b0 <buf_put>
    9523:	41 8b 06             	mov    (%r14),%eax
    9526:	83 f8 0e             	cmp    $0xe,%eax
    9529:	0f 84 71 02 00 00    	je     97a0 <fwp_write+0xad0>
    952f:	83 f8 10             	cmp    $0x10,%eax
    9532:	0f 84 38 02 00 00    	je     9770 <fwp_write+0xaa0>
    9538:	83 f8 0a             	cmp    $0xa,%eax
    953b:	0f 84 7f 04 00 00    	je     99c0 <fwp_write+0xcf0>
    9541:	0f 8f f9 00 00 00    	jg     9640 <fwp_write+0x970>
    9547:	83 f8 03             	cmp    $0x3,%eax
    954a:	0f 8f 50 04 00 00    	jg     99a0 <fwp_write+0xcd0>
    9550:	85 c0                	test   %eax,%eax
    9552:	78 10                	js     9564 <fwp_write+0x894>
    9554:	48 8b 04 24          	mov    (%rsp),%rax
    9558:	48 c1 e8 3f          	shr    $0x3f,%rax
    955c:	85 c0                	test   %eax,%eax
    955e:	0f 85 f9 00 00 00    	jne    965d <fwp_write+0x98d>
    9564:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9569:	48 8b 34 24          	mov    (%rsp),%rsi
    956d:	31 c9                	xor    %ecx,%ecx
    956f:	48 89 df             	mov    %rbx,%rdi
    9572:	e8 59 f7 ff ff       	call   8cd0 <fwp_write>
    9577:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    957c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9581:	49 83 c5 01          	add    $0x1,%r13
    9585:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9589:	0f 8f 5f ff ff ff    	jg     94ee <fwp_write+0x81e>
    958f:	e9 d2 f7 ff ff       	jmp    8d66 <fwp_write+0x96>
    9594:	0f 1f 40 00          	nopl   0x0(%rax)
    9598:	ba 06 00 00 00       	mov    $0x6,%edx
    959d:	48 8d 35 a9 5c 00 00 	lea    0x5ca9(%rip),%rsi        # f24d <_IO_stdin_used+0x24d>
    95a4:	45 31 ed             	xor    %r13d,%r13d
    95a7:	e8 04 ab ff ff       	call   40b0 <buf_put>
    95ac:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    95b1:	75 19                	jne    95cc <fwp_write+0x8fc>
    95b3:	eb 6c                	jmp    9621 <fwp_write+0x951>
    95b5:	0f 1f 00             	nopl   (%rax)
    95b8:	ba 02 00 00 00       	mov    $0x2,%edx
    95bd:	48 8d 35 93 5c 00 00 	lea    0x5c93(%rip),%rsi        # f257 <_IO_stdin_used+0x257>
    95c4:	48 89 df             	mov    %rbx,%rdi
    95c7:	e8 e4 aa ff ff       	call   40b0 <buf_put>
    95cc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    95d2:	b9 00 02 00 00       	mov    $0x200,%ecx
    95d7:	31 c0                	xor    %eax,%eax
    95d9:	49 83 c5 01          	add    $0x1,%r13
    95dd:	4c 8d 05 70 5c 00 00 	lea    0x5c70(%rip),%r8        # f254 <_IO_stdin_used+0x254>
    95e4:	ba 02 00 00 00       	mov    $0x2,%edx
    95e9:	be 00 02 00 00       	mov    $0x200,%esi
    95ee:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    95f5:	00 
    95f6:	e8 95 9d ff ff       	call   3390 <__snprintf_chk@plt>
    95fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9602:	00 
    9603:	e8 28 9e ff ff       	call   3430 <strlen@plt>
    9608:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    960f:	00 
    9610:	48 89 df             	mov    %rbx,%rdi
    9613:	48 89 c2             	mov    %rax,%rdx
    9616:	e8 95 aa ff ff       	call   40b0 <buf_put>
    961b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    961f:	72 97                	jb     95b8 <fwp_write+0x8e8>
    9621:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9626:	ba 01 00 00 00       	mov    $0x1,%edx
    962b:	48 89 df             	mov    %rbx,%rdi
    962e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9633:	e8 78 aa ff ff       	call   40b0 <buf_put>
    9638:	e9 29 f7 ff ff       	jmp    8d66 <fwp_write+0x96>
    963d:	0f 1f 00             	nopl   (%rax)
    9640:	83 f8 0b             	cmp    $0xb,%eax
    9643:	0f 85 1b ff ff ff    	jne    9564 <fwp_write+0x894>
    9649:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    964e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9652:	83 e0 01             	and    $0x1,%eax
    9655:	85 c0                	test   %eax,%eax
    9657:	0f 84 07 ff ff ff    	je     9564 <fwp_write+0x894>
    965d:	4c 89 fe             	mov    %r15,%rsi
    9660:	48 89 df             	mov    %rbx,%rdi
    9663:	ba 01 00 00 00       	mov    $0x1,%edx
    9668:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    966d:	e8 3e aa ff ff       	call   40b0 <buf_put>
    9672:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9677:	48 8b 34 24          	mov    (%rsp),%rsi
    967b:	31 c9                	xor    %ecx,%ecx
    967d:	48 89 df             	mov    %rbx,%rdi
    9680:	e8 4b f6 ff ff       	call   8cd0 <fwp_write>
    9685:	ba 01 00 00 00       	mov    $0x1,%edx
    968a:	4c 89 fe             	mov    %r15,%rsi
    968d:	48 89 df             	mov    %rbx,%rdi
    9690:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9695:	e8 16 aa ff ff       	call   40b0 <buf_put>
    969a:	e9 d8 fe ff ff       	jmp    9577 <fwp_write+0x8a7>
    969f:	90                   	nop
    96a0:	ba 01 00 00 00       	mov    $0x1,%edx
    96a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    96aa:	48 89 df             	mov    %rbx,%rdi
    96ad:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    96b2:	e8 f9 a9 ff ff       	call   40b0 <buf_put>
    96b7:	e9 aa f6 ff ff       	jmp    8d66 <fwp_write+0x96>
    96bc:	0f 1f 40 00          	nopl   0x0(%rax)
    96c0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    96c5:	ba 01 00 00 00       	mov    $0x1,%edx
    96ca:	48 89 df             	mov    %rbx,%rdi
    96cd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    96d2:	e8 d9 a9 ff ff       	call   40b0 <buf_put>
    96d7:	e9 8a f6 ff ff       	jmp    8d66 <fwp_write+0x96>
    96dc:	0f 1f 40 00          	nopl   0x0(%rax)
    96e0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    96e4:	48 8b 13             	mov    (%rbx),%rdx
    96e7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    96ec:	48 89 43 08          	mov    %rax,0x8(%rbx)
    96f0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    96f4:	e9 6d f6 ff ff       	jmp    8d66 <fwp_write+0x96>
    96f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9700:	ba 02 00 00 00       	mov    $0x2,%edx
    9705:	48 8d 35 4b 5b 00 00 	lea    0x5b4b(%rip),%rsi        # f257 <_IO_stdin_used+0x257>
    970c:	48 89 df             	mov    %rbx,%rdi
    970f:	e8 9c a9 ff ff       	call   40b0 <buf_put>
    9714:	e9 72 f8 ff ff       	jmp    8f8b <fwp_write+0x2bb>
    9719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9720:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9725:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    972a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    972e:	48 89 f7             	mov    %rsi,%rdi
    9731:	48 89 34 24          	mov    %rsi,(%rsp)
    9735:	e8 f6 9c ff ff       	call   3430 <strlen@plt>
    973a:	48 8b 34 24          	mov    (%rsp),%rsi
    973e:	48 89 df             	mov    %rbx,%rdi
    9741:	48 89 c2             	mov    %rax,%rdx
    9744:	e8 67 a9 ff ff       	call   40b0 <buf_put>
    9749:	ba 03 00 00 00       	mov    $0x3,%edx
    974e:	48 8d 35 25 5b 00 00 	lea    0x5b25(%rip),%rsi        # f27a <_IO_stdin_used+0x27a>
    9755:	48 89 df             	mov    %rbx,%rdi
    9758:	e8 53 a9 ff ff       	call   40b0 <buf_put>
    975d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9762:	e9 35 f8 ff ff       	jmp    8f9c <fwp_write+0x2cc>
    9767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    976e:	00 00 
    9770:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9775:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9779:	48 85 ff             	test   %rdi,%rdi
    977c:	0f 84 e2 fd ff ff    	je     9564 <fwp_write+0x894>
    9782:	48 8d 35 db 5a 00 00 	lea    0x5adb(%rip),%rsi        # f264 <_IO_stdin_used+0x264>
    9789:	e8 82 9d ff ff       	call   3510 <strcmp@plt>
    978e:	85 c0                	test   %eax,%eax
    9790:	0f 95 c0             	setne  %al
    9793:	0f b6 c0             	movzbl %al,%eax
    9796:	e9 c1 fd ff ff       	jmp    955c <fwp_write+0x88c>
    979b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    97a0:	31 c0                	xor    %eax,%eax
    97a2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    97a9:	00 
    97aa:	0f 97 c0             	seta   %al
    97ad:	e9 aa fd ff ff       	jmp    955c <fwp_write+0x88c>
    97b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97b8:	48 89 df             	mov    %rbx,%rdi
    97bb:	ba 02 00 00 00       	mov    $0x2,%edx
    97c0:	48 8d 35 9a 5a 00 00 	lea    0x5a9a(%rip),%rsi        # f261 <_IO_stdin_used+0x261>
    97c7:	e8 e4 a8 ff ff       	call   40b0 <buf_put>
    97cc:	4c 89 e8             	mov    %r13,%rax
    97cf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    97d4:	31 c9                	xor    %ecx,%ecx
    97d6:	48 c1 e0 04          	shl    $0x4,%rax
    97da:	48 89 df             	mov    %rbx,%rdi
    97dd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    97e2:	e8 e9 f4 ff ff       	call   8cd0 <fwp_write>
    97e7:	e9 5e f6 ff ff       	jmp    8e4a <fwp_write+0x17a>
    97ec:	0f 1f 40 00          	nopl   0x0(%rax)
    97f0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    97f5:	48 85 ff             	test   %rdi,%rdi
    97f8:	79 0c                	jns    9806 <fwp_write+0xb36>
    97fa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9801:	00 
    9802:	48 03 75 10          	add    0x10(%rbp),%rsi
    9806:	48 63 3e             	movslq (%rsi),%rdi
    9809:	83 f9 02             	cmp    $0x2,%ecx
    980c:	89 fe                	mov    %edi,%esi
    980e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9812:	e9 f9 fb ff ff       	jmp    9410 <fwp_write+0x740>
    9817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    981e:	00 00 
    9820:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9825:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    982a:	48 85 ff             	test   %rdi,%rdi
    982d:	0f 88 0f 03 00 00    	js     9b42 <fwp_write+0xe72>
    9833:	49 0f bf 38          	movswq (%r8),%rdi
    9837:	83 f9 01             	cmp    $0x1,%ecx
    983a:	0f b7 f7             	movzwl %di,%esi
    983d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9841:	e9 ca fb ff ff       	jmp    9410 <fwp_write+0x740>
    9846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    984d:	00 00 00 
    9850:	ba 01 00 00 00       	mov    $0x1,%edx
    9855:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    985a:	48 83 c5 08          	add    $0x8,%rbp
    985e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9863:	e8 48 a8 ff ff       	call   40b0 <buf_put>
    9868:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    986d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9872:	4d 85 ed             	test   %r13,%r13
    9875:	75 46                	jne    98bd <fwp_write+0xbed>
    9877:	e9 04 01 00 00       	jmp    9980 <fwp_write+0xcb0>
    987c:	0f 1f 40 00          	nopl   0x0(%rax)
    9880:	41 80 f9 09          	cmp    $0x9,%r9b
    9884:	0f 84 d6 00 00 00    	je     9960 <fwp_write+0xc90>
    988a:	41 80 f9 0a          	cmp    $0xa,%r9b
    988e:	0f 85 9c 00 00 00    	jne    9930 <fwp_write+0xc60>
    9894:	ba 02 00 00 00       	mov    $0x2,%edx
    9899:	48 8d 35 9d 59 00 00 	lea    0x599d(%rip),%rsi        # f23d <_IO_stdin_used+0x23d>
    98a0:	48 89 df             	mov    %rbx,%rdi
    98a3:	e8 08 a8 ff ff       	call   40b0 <buf_put>
    98a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98af:	00 
    98b0:	48 83 c5 01          	add    $0x1,%rbp
    98b4:	49 39 ec             	cmp    %rbp,%r12
    98b7:	0f 84 c3 00 00 00    	je     9980 <fwp_write+0xcb0>
    98bd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    98c2:	41 80 f9 0d          	cmp    $0xd,%r9b
    98c6:	74 28                	je     98f0 <fwp_write+0xc20>
    98c8:	7e b6                	jle    9880 <fwp_write+0xbb0>
    98ca:	41 80 f9 22          	cmp    $0x22,%r9b
    98ce:	74 40                	je     9910 <fwp_write+0xc40>
    98d0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    98d4:	75 5a                	jne    9930 <fwp_write+0xc60>
    98d6:	ba 02 00 00 00       	mov    $0x2,%edx
    98db:	48 8d 35 58 59 00 00 	lea    0x5958(%rip),%rsi        # f23a <_IO_stdin_used+0x23a>
    98e2:	48 89 df             	mov    %rbx,%rdi
    98e5:	e8 c6 a7 ff ff       	call   40b0 <buf_put>
    98ea:	eb c4                	jmp    98b0 <fwp_write+0xbe0>
    98ec:	0f 1f 40 00          	nopl   0x0(%rax)
    98f0:	ba 02 00 00 00       	mov    $0x2,%edx
    98f5:	48 8d 35 47 59 00 00 	lea    0x5947(%rip),%rsi        # f243 <_IO_stdin_used+0x243>
    98fc:	48 89 df             	mov    %rbx,%rdi
    98ff:	e8 ac a7 ff ff       	call   40b0 <buf_put>
    9904:	eb aa                	jmp    98b0 <fwp_write+0xbe0>
    9906:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    990d:	00 00 00 
    9910:	ba 02 00 00 00       	mov    $0x2,%edx
    9915:	48 8d 35 1b 59 00 00 	lea    0x591b(%rip),%rsi        # f237 <_IO_stdin_used+0x237>
    991c:	48 89 df             	mov    %rbx,%rdi
    991f:	e8 8c a7 ff ff       	call   40b0 <buf_put>
    9924:	eb 8a                	jmp    98b0 <fwp_write+0xbe0>
    9926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    992d:	00 00 00 
    9930:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9934:	0f 86 2e 01 00 00    	jbe    9a68 <fwp_write+0xd98>
    993a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    993e:	0f 84 24 01 00 00    	je     9a68 <fwp_write+0xd98>
    9944:	ba 01 00 00 00       	mov    $0x1,%edx
    9949:	4c 89 fe             	mov    %r15,%rsi
    994c:	48 89 df             	mov    %rbx,%rdi
    994f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9954:	e8 57 a7 ff ff       	call   40b0 <buf_put>
    9959:	e9 52 ff ff ff       	jmp    98b0 <fwp_write+0xbe0>
    995e:	66 90                	xchg   %ax,%ax
    9960:	ba 02 00 00 00       	mov    $0x2,%edx
    9965:	48 8d 35 d4 58 00 00 	lea    0x58d4(%rip),%rsi        # f240 <_IO_stdin_used+0x240>
    996c:	48 89 df             	mov    %rbx,%rdi
    996f:	e8 3c a7 ff ff       	call   40b0 <buf_put>
    9974:	e9 37 ff ff ff       	jmp    98b0 <fwp_write+0xbe0>
    9979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9980:	ba 01 00 00 00       	mov    $0x1,%edx
    9985:	4c 89 fe             	mov    %r15,%rsi
    9988:	48 89 df             	mov    %rbx,%rdi
    998b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9990:	e8 1b a7 ff ff       	call   40b0 <buf_put>
    9995:	e9 cc f3 ff ff       	jmp    8d66 <fwp_write+0x96>
    999a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99a0:	83 f8 04             	cmp    $0x4,%eax
    99a3:	0f 85 bb fb ff ff    	jne    9564 <fwp_write+0x894>
    99a9:	48 8b 04 24          	mov    (%rsp),%rax
    99ad:	48 8b 40 08          	mov    0x8(%rax),%rax
    99b1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    99b6:	48 c1 e8 3f          	shr    $0x3f,%rax
    99ba:	e9 96 fc ff ff       	jmp    9655 <fwp_write+0x985>
    99bf:	90                   	nop
    99c0:	8b 0c 24             	mov    (%rsp),%ecx
    99c3:	31 c0                	xor    %eax,%eax
    99c5:	85 c9                	test   %ecx,%ecx
    99c7:	0f 98 c0             	sets   %al
    99ca:	e9 86 fc ff ff       	jmp    9655 <fwp_write+0x985>
    99cf:	90                   	nop
    99d0:	48 f7 d8             	neg    %rax
    99d3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    99da:	00 
    99db:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    99e2:	2d 
    99e3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    99ea:	00 
    99eb:	48 83 d2 00          	adc    $0x0,%rdx
    99ef:	48 89 c6             	mov    %rax,%rsi
    99f2:	48 f7 da             	neg    %rdx
    99f5:	e8 06 a0 ff ff       	call   3a00 <fwp_fmt_u128>
    99fa:	e9 51 f3 ff ff       	jmp    8d50 <fwp_write+0x80>
    99ff:	90                   	nop
    9a00:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9a05:	e9 c3 f5 ff ff       	jmp    8fcd <fwp_write+0x2fd>
    9a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a10:	4c 89 e9             	mov    %r13,%rcx
    9a13:	48 c1 e1 04          	shl    $0x4,%rcx
    9a17:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    9a1c:	48 85 ff             	test   %rdi,%rdi
    9a1f:	0f 89 eb f9 ff ff    	jns    9410 <fwp_write+0x740>
    9a25:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9a29:	48 89 ce             	mov    %rcx,%rsi
    9a2c:	e9 df f9 ff ff       	jmp    9410 <fwp_write+0x740>
    9a31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a38:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9a3f:	00 
    9a40:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9a44:	e9 20 fa ff ff       	jmp    9469 <fwp_write+0x799>
    9a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a50:	ba 02 00 00 00       	mov    $0x2,%edx
    9a55:	48 8d 35 a6 57 00 00 	lea    0x57a6(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    9a5c:	e9 2d f7 ff ff       	jmp    918e <fwp_write+0x4be>
    9a61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a68:	4c 8d 05 d7 57 00 00 	lea    0x57d7(%rip),%r8        # f246 <_IO_stdin_used+0x246>
    9a6f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9a74:	31 c0                	xor    %eax,%eax
    9a76:	ba 02 00 00 00       	mov    $0x2,%edx
    9a7b:	be 10 00 00 00       	mov    $0x10,%esi
    9a80:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9a87:	00 
    9a88:	e8 03 99 ff ff       	call   3390 <__snprintf_chk@plt>
    9a8d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9a94:	00 
    9a95:	e8 96 99 ff ff       	call   3430 <strlen@plt>
    9a9a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9aa1:	00 
    9aa2:	48 89 df             	mov    %rbx,%rdi
    9aa5:	48 89 c2             	mov    %rax,%rdx
    9aa8:	e8 03 a6 ff ff       	call   40b0 <buf_put>
    9aad:	e9 fe fd ff ff       	jmp    98b0 <fwp_write+0xbe0>
    9ab2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ab8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9abc:	48 8d 35 39 57 00 00 	lea    0x5739(%rip),%rsi        # f1fc <_IO_stdin_used+0x1fc>
    9ac3:	48 8d 05 31 57 00 00 	lea    0x5731(%rip),%rax        # f1fb <_IO_stdin_used+0x1fb>
    9aca:	4c 89 e7             	mov    %r12,%rdi
    9acd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9ad1:	48 0f 46 f0          	cmovbe %rax,%rsi
    9ad5:	e8 f6 98 ff ff       	call   33d0 <strcpy@plt>
    9ada:	e9 71 f2 ff ff       	jmp    8d50 <fwp_write+0x80>
    9adf:	90                   	nop
    9ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9ae4:	48 8d 35 11 57 00 00 	lea    0x5711(%rip),%rsi        # f1fc <_IO_stdin_used+0x1fc>
    9aeb:	48 8d 05 09 57 00 00 	lea    0x5709(%rip),%rax        # f1fb <_IO_stdin_used+0x1fb>
    9af2:	0f 2f c8             	comiss %xmm0,%xmm1
    9af5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9afc:	00 
    9afd:	4c 89 e7             	mov    %r12,%rdi
    9b00:	48 0f 46 f0          	cmovbe %rax,%rsi
    9b04:	e8 c7 98 ff ff       	call   33d0 <strcpy@plt>
    9b09:	e9 42 f2 ff ff       	jmp    8d50 <fwp_write+0x80>
    9b0e:	66 90                	xchg   %ax,%ax
    9b10:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9b15:	45 85 c0             	test   %r8d,%r8d
    9b18:	75 34                	jne    9b4e <fwp_write+0xe7e>
    9b1a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9b21:	00 
    9b22:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9b29:	00 00 
    9b2b:	0f 85 74 f6 ff ff    	jne    91a5 <fwp_write+0x4d5>
    9b31:	ba 02 00 00 00       	mov    $0x2,%edx
    9b36:	48 8d 35 3a 57 00 00 	lea    0x573a(%rip),%rsi        # f277 <_IO_stdin_used+0x277>
    9b3d:	e9 a1 f3 ff ff       	jmp    8ee3 <fwp_write+0x213>
    9b42:	48 03 75 10          	add    0x10(%rbp),%rsi
    9b46:	49 89 f0             	mov    %rsi,%r8
    9b49:	e9 e5 fc ff ff       	jmp    9833 <fwp_write+0xb63>
    9b4e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9b53:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9b58:	85 ff                	test   %edi,%edi
    9b5a:	0f 84 fa f3 ff ff    	je     8f5a <fwp_write+0x28a>
    9b60:	ba 01 00 00 00       	mov    $0x1,%edx
    9b65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9b6a:	48 89 df             	mov    %rbx,%rdi
    9b6d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9b72:	e8 39 a5 ff ff       	call   40b0 <buf_put>
    9b77:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    9b7c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9b81:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9b87:	85 c0                	test   %eax,%eax
    9b89:	0f 8f f0 f3 ff ff    	jg     8f7f <fwp_write+0x2af>
    9b8f:	e9 34 f4 ff ff       	jmp    8fc8 <fwp_write+0x2f8>
    9b94:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9b98:	49 89 c5             	mov    %rax,%r13
    9b9b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9ba0:	49 89 c4             	mov    %rax,%r12
    9ba3:	49 c1 fd 3f          	sar    $0x3f,%r13
    9ba7:	4c 09 e8             	or     %r13,%rax
    9baa:	0f 84 a7 00 00 00    	je     9c57 <fwp_write+0xf87>
    9bb0:	48 8d 2d 09 77 00 00 	lea    0x7709(%rip),%rbp        # 112c0 <units.0>
    9bb7:	4d 89 e7             	mov    %r12,%r15
    9bba:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9bbe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9bc3:	4c 89 ff             	mov    %r15,%rdi
    9bc6:	4c 89 ee             	mov    %r13,%rsi
    9bc9:	44 89 0c 24          	mov    %r9d,(%rsp)
    9bcd:	48 99                	cqto
    9bcf:	48 89 d1             	mov    %rdx,%rcx
    9bd2:	48 89 c2             	mov    %rax,%rdx
    9bd5:	e8 26 50 00 00       	call   ec00 <__divmodti4>
    9bda:	44 8b 0c 24          	mov    (%rsp),%r9d
    9bde:	48 89 c1             	mov    %rax,%rcx
    9be1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9be6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    9beb:	0f 84 94 00 00 00    	je     9c85 <fwp_write+0xfb5>
    9bf1:	41 83 c1 01          	add    $0x1,%r9d
    9bf5:	48 83 c5 10          	add    $0x10,%rbp
    9bf9:	41 83 f9 05          	cmp    $0x5,%r9d
    9bfd:	75 bb                	jne    9bba <fwp_write+0xeea>
    9bff:	4d 85 ed             	test   %r13,%r13
    9c02:	79 53                	jns    9c57 <fwp_write+0xf87>
    9c04:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9c09:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9c0e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9c13:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9c18:	48 99                	cqto
    9c1a:	48 f7 d8             	neg    %rax
    9c1d:	48 83 d2 00          	adc    $0x0,%rdx
    9c21:	48 89 c6             	mov    %rax,%rsi
    9c24:	48 f7 da             	neg    %rdx
    9c27:	e8 d4 9d ff ff       	call   3a00 <fwp_fmt_u128>
    9c2c:	49 89 e8             	mov    %rbp,%r8
    9c2f:	ba 00 02 00 00       	mov    $0x200,%edx
    9c34:	be 02 00 00 00       	mov    $0x2,%esi
    9c39:	31 c0                	xor    %eax,%eax
    9c3b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c42:	00 
    9c43:	48 8d 0d 28 56 00 00 	lea    0x5628(%rip),%rcx        # f272 <_IO_stdin_used+0x272>
    9c4a:	4c 89 e7             	mov    %r12,%rdi
    9c4d:	e8 4e 9a ff ff       	call   36a0 <__sprintf_chk@plt>
    9c52:	e9 f9 f0 ff ff       	jmp    8d50 <fwp_write+0x80>
    9c57:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9c5c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9c61:	31 d2                	xor    %edx,%edx
    9c63:	48 89 ef             	mov    %rbp,%rdi
    9c66:	e8 95 9d ff ff       	call   3a00 <fwp_fmt_u128>
    9c6b:	eb bf                	jmp    9c2c <fwp_write+0xf5c>
    9c6d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9c74:	4e 61 4e 00 
    9c78:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c7f:	00 
    9c80:	e9 cb f0 ff ff       	jmp    8d50 <fwp_write+0x80>
    9c85:	44 89 0c 24          	mov    %r9d,(%rsp)
    9c89:	48 89 c8             	mov    %rcx,%rax
    9c8c:	48 85 d2             	test   %rdx,%rdx
    9c8f:	78 51                	js     9ce2 <fwp_write+0x1012>
    9c91:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9c96:	48 89 c6             	mov    %rax,%rsi
    9c99:	48 89 ef             	mov    %rbp,%rdi
    9c9c:	e8 5f 9d ff ff       	call   3a00 <fwp_fmt_u128>
    9ca1:	44 8b 0c 24          	mov    (%rsp),%r9d
    9ca5:	49 63 c1             	movslq %r9d,%rax
    9ca8:	49 89 e8             	mov    %rbp,%r8
    9cab:	ba 00 02 00 00       	mov    $0x200,%edx
    9cb0:	be 02 00 00 00       	mov    $0x2,%esi
    9cb5:	48 c1 e0 04          	shl    $0x4,%rax
    9cb9:	48 8d 3d 00 76 00 00 	lea    0x7600(%rip),%rdi        # 112c0 <units.0>
    9cc0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9cc7:	00 
    9cc8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    9ccc:	48 8d 0d 9a 55 00 00 	lea    0x559a(%rip),%rcx        # f26d <_IO_stdin_used+0x26d>
    9cd3:	4c 89 e7             	mov    %r12,%rdi
    9cd6:	31 c0                	xor    %eax,%eax
    9cd8:	e8 c3 99 ff ff       	call   36a0 <__sprintf_chk@plt>
    9cdd:	e9 6e f0 ff ff       	jmp    8d50 <fwp_write+0x80>
    9ce2:	48 f7 d8             	neg    %rax
    9ce5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9cea:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9cef:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9cf4:	48 83 d2 00          	adc    $0x0,%rdx
    9cf8:	48 89 c6             	mov    %rax,%rsi
    9cfb:	48 f7 da             	neg    %rdx
    9cfe:	e8 fd 9c ff ff       	call   3a00 <fwp_fmt_u128>
    9d03:	44 8b 0c 24          	mov    (%rsp),%r9d
    9d07:	eb 9c                	jmp    9ca5 <fwp_write+0xfd5>
    9d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009d10 <fwp_hof0.constprop.0>:
    9d10:	41 57                	push   %r15
    9d12:	41 56                	push   %r14
    9d14:	41 55                	push   %r13
    9d16:	41 54                	push   %r12
    9d18:	55                   	push   %rbp
    9d19:	53                   	push   %rbx
    9d1a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    9d21:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    9d26:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9d2d:	00 00 
    9d2f:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    9d36:	00 
    9d37:	31 c0                	xor    %eax,%eax
    9d39:	48 85 f6             	test   %rsi,%rsi
    9d3c:	0f 84 75 0f 00 00    	je     acb7 <fwp_hof0.constprop.0+0xfa7>
    9d42:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9d47:	48 8d 2d b2 1a 06 00 	lea    0x61ab2(%rip),%rbp        # 6b800 <fwp_heap>
    9d4e:	66 90                	xchg   %ax,%ax
    9d50:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9d57:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9d5c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9d63:	48 c1 e2 10          	shl    $0x10,%rdx
    9d67:	48 39 d0             	cmp    %rdx,%rax
    9d6a:	73 71                	jae    9ddd <fwp_hof0.constprop.0+0xcd>
    9d6c:	48 89 c2             	mov    %rax,%rdx
    9d6f:	48 c1 ea 10          	shr    $0x10,%rdx
    9d73:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d77:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9d7e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d82:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9d86:	48 85 ff             	test   %rdi,%rdi
    9d89:	74 52                	je     9ddd <fwp_hof0.constprop.0+0xcd>
    9d8b:	0f b6 0a             	movzbl (%rdx),%ecx
    9d8e:	80 f9 02             	cmp    $0x2,%cl
    9d91:	0f 84 a9 15 00 00    	je     b340 <fwp_hof0.constprop.0+0x1630>
    9d97:	80 f9 01             	cmp    $0x1,%cl
    9d9a:	75 41                	jne    9ddd <fwp_hof0.constprop.0+0xcd>
    9d9c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d9f:	0f b7 c0             	movzwl %ax,%eax
    9da2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9da5:	48 0f af c1          	imul   %rcx,%rax
    9da9:	48 c1 e8 20          	shr    $0x20,%rax
    9dad:	48 39 d0             	cmp    %rdx,%rax
    9db0:	73 2b                	jae    9ddd <fwp_hof0.constprop.0+0xcd>
    9db2:	48 01 c7             	add    %rax,%rdi
    9db5:	0f b6 07             	movzbl (%rdi),%eax
    9db8:	84 c0                	test   %al,%al
    9dba:	74 21                	je     9ddd <fwp_hof0.constprop.0+0xcd>
    9dbc:	44 8b 0d 05 37 06 00 	mov    0x63705(%rip),%r9d        # 6d4c8 <iteration_active>
    9dc3:	45 85 c9             	test   %r9d,%r9d
    9dc6:	74 08                	je     9dd0 <fwp_hof0.constprop.0+0xc0>
    9dc8:	48 83 05 e0 36 06 00 	addq   $0x1,0x636e0(%rip)        # 6d4b0 <iteration_retains>
    9dcf:	01 
    9dd0:	3c fd                	cmp    $0xfd,%al
    9dd2:	0f 87 45 17 00 00    	ja     b51d <fwp_hof0.constprop.0+0x180d>
    9dd8:	83 c0 01             	add    $0x1,%eax
    9ddb:	88 07                	mov    %al,(%rdi)
    9ddd:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9de2:	45 31 c9             	xor    %r9d,%r9d
    9de5:	48 c7 44 24 18 c6 00 	movq   $0xc6,0x18(%rsp)
    9dec:	00 00 
    9dee:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9df3:	4c 89 cb             	mov    %r9,%rbx
    9df6:	4d 85 c9             	test   %r9,%r9
    9df9:	0f 85 11 99 ff ff    	jne    3710 <fwp_hof0.constprop.0.cold+0x5>
    9dff:	48 8b 05 92 36 06 00 	mov    0x63692(%rip),%rax        # 6d498 <fwp_cleanups>
    9e06:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9e0d:	4c 8d 2d 1c d8 ff ff 	lea    -0x27e4(%rip),%r13        # 7630 <fwp_tape_scope_release>
    9e14:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    9e1b:	ff 
    9e1c:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    9e21:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9e26:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    9e2b:	48 c1 e2 10          	shl    $0x10,%rdx
    9e2f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9e34:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9e3b:	00 
    9e3c:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    9e41:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9e46:	48 89 05 4b 36 06 00 	mov    %rax,0x6364b(%rip)        # 6d498 <fwp_cleanups>
    9e4d:	48 8d 05 bc 91 00 00 	lea    0x91bc(%rip),%rax        # 13010 <fc37>
    9e54:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9e5b:	48 39 d0             	cmp    %rdx,%rax
    9e5e:	73 71                	jae    9ed1 <fwp_hof0.constprop.0+0x1c1>
    9e60:	48 89 c2             	mov    %rax,%rdx
    9e63:	48 c1 ea 10          	shr    $0x10,%rdx
    9e67:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e6b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9e72:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e76:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9e7a:	48 85 ff             	test   %rdi,%rdi
    9e7d:	74 52                	je     9ed1 <fwp_hof0.constprop.0+0x1c1>
    9e7f:	0f b6 0a             	movzbl (%rdx),%ecx
    9e82:	80 f9 02             	cmp    $0x2,%cl
    9e85:	0f 84 9d 12 00 00    	je     b128 <fwp_hof0.constprop.0+0x1418>
    9e8b:	80 f9 01             	cmp    $0x1,%cl
    9e8e:	75 41                	jne    9ed1 <fwp_hof0.constprop.0+0x1c1>
    9e90:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e93:	0f b7 c0             	movzwl %ax,%eax
    9e96:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e99:	48 0f af c1          	imul   %rcx,%rax
    9e9d:	48 c1 e8 20          	shr    $0x20,%rax
    9ea1:	48 39 d0             	cmp    %rdx,%rax
    9ea4:	73 2b                	jae    9ed1 <fwp_hof0.constprop.0+0x1c1>
    9ea6:	48 01 c7             	add    %rax,%rdi
    9ea9:	0f b6 07             	movzbl (%rdi),%eax
    9eac:	84 c0                	test   %al,%al
    9eae:	74 21                	je     9ed1 <fwp_hof0.constprop.0+0x1c1>
    9eb0:	44 8b 05 11 36 06 00 	mov    0x63611(%rip),%r8d        # 6d4c8 <iteration_active>
    9eb7:	45 85 c0             	test   %r8d,%r8d
    9eba:	74 08                	je     9ec4 <fwp_hof0.constprop.0+0x1b4>
    9ebc:	48 83 05 ec 35 06 00 	addq   $0x1,0x635ec(%rip)        # 6d4b0 <iteration_retains>
    9ec3:	01 
    9ec4:	3c fd                	cmp    $0xfd,%al
    9ec6:	0f 87 fa 15 00 00    	ja     b4c6 <fwp_hof0.constprop.0+0x17b6>
    9ecc:	83 c0 01             	add    $0x1,%eax
    9ecf:	88 07                	mov    %al,(%rdi)
    9ed1:	48 8d 3d 38 91 00 00 	lea    0x9138(%rip),%rdi        # 13010 <fc37>
    9ed8:	e8 f3 d3 ff ff       	call   72d0 <fwp_closure_drop>
    9edd:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9ee2:	48 85 c0             	test   %rax,%rax
    9ee5:	0f 84 d0 14 00 00    	je     b3bb <fwp_hof0.constprop.0+0x16ab>
    9eeb:	31 d2                	xor    %edx,%edx
    9eed:	0f 1f 00             	nopl   (%rax)
    9ef0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ef4:	48 83 c2 01          	add    $0x1,%rdx
    9ef8:	48 85 c0             	test   %rax,%rax
    9efb:	75 f3                	jne    9ef0 <fwp_hof0.constprop.0+0x1e0>
    9efd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9f04:	0f 87 cb 16 00 00    	ja     b5d5 <fwp_hof0.constprop.0+0x18c5>
    9f0a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    9f0f:	8b 35 4b 91 00 00    	mov    0x914b(%rip),%esi        # 13060 <registered_finish.1>
    9f15:	85 f6                	test   %esi,%esi
    9f17:	0f 84 db 11 00 00    	je     b0f8 <fwp_hof0.constprop.0+0x13e8>
    9f1d:	4c 8b 3d a4 91 01 00 	mov    0x191a4(%rip),%r15        # 230c8 <fwp_tape_next_slot>
    9f24:	4c 8b 25 ad 91 01 00 	mov    0x191ad(%rip),%r12        # 230d8 <fwp_ntapes>
    9f2b:	4d 39 fc             	cmp    %r15,%r12
    9f2e:	0f 8e 9c 0e 00 00    	jle    add0 <fwp_hof0.constprop.0+0x10c0>
    9f34:	49 6b c7 58          	imul   $0x58,%r15,%rax
    9f38:	48 03 05 a1 91 01 00 	add    0x191a1(%rip),%rax        # 230e0 <fwp_tapes>
    9f3f:	90                   	nop
    9f40:	8b 48 04             	mov    0x4(%rax),%ecx
    9f43:	85 c9                	test   %ecx,%ecx
    9f45:	75 0c                	jne    9f53 <fwp_hof0.constprop.0+0x243>
    9f47:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9f4d:	0f 86 7d 0e 00 00    	jbe    add0 <fwp_hof0.constprop.0+0x10c0>
    9f53:	49 83 c7 01          	add    $0x1,%r15
    9f57:	48 83 c0 58          	add    $0x58,%rax
    9f5b:	4d 39 fc             	cmp    %r15,%r12
    9f5e:	75 e0                	jne    9f40 <fwp_hof0.constprop.0+0x230>
    9f60:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9f67:	0f 8f d5 16 00 00    	jg     b642 <fwp_hof0.constprop.0+0x1932>
    9f6d:	4c 3b 25 5c 91 01 00 	cmp    0x1915c(%rip),%r12        # 230d0 <fwp_tapes_cap>
    9f74:	4c 8b 35 65 91 01 00 	mov    0x19165(%rip),%r14        # 230e0 <fwp_tapes>
    9f7b:	75 4b                	jne    9fc8 <fwp_hof0.constprop.0+0x2b8>
    9f7d:	4d 85 e4             	test   %r12,%r12
    9f80:	0f 84 9a 14 00 00    	je     b420 <fwp_hof0.constprop.0+0x1710>
    9f86:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9f8a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9f8f:	49 39 c7             	cmp    %rax,%r15
    9f92:	4c 0f 4f f8          	cmovg  %rax,%r15
    9f96:	49 6b f7 58          	imul   $0x58,%r15,%rsi
    9f9a:	31 d2                	xor    %edx,%edx
    9f9c:	4c 89 f7             	mov    %r14,%rdi
    9f9f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9fa4:	e8 a7 b1 ff ff       	call   5150 <ad_raw_realloc>
    9fa9:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9fae:	48 85 c0             	test   %rax,%rax
    9fb1:	49 89 c6             	mov    %rax,%r14
    9fb4:	0f 84 5a 16 00 00    	je     b614 <fwp_hof0.constprop.0+0x1904>
    9fba:	48 89 05 1f 91 01 00 	mov    %rax,0x1911f(%rip)        # 230e0 <fwp_tapes>
    9fc1:	4c 89 3d 08 91 01 00 	mov    %r15,0x19108(%rip)        # 230d0 <fwp_tapes_cap>
    9fc8:	49 6b cc 58          	imul   $0x58,%r12,%rcx
    9fcc:	31 c0                	xor    %eax,%eax
    9fce:	4d 89 e7             	mov    %r12,%r15
    9fd1:	4c 01 f1             	add    %r14,%rcx
    9fd4:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9fd8:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9fdf:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9fe3:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    9fea:	00 
    9feb:	48 29 f9             	sub    %rdi,%rcx
    9fee:	83 c1 58             	add    $0x58,%ecx
    9ff1:	c1 e9 03             	shr    $0x3,%ecx
    9ff4:	f3 48 ab             	rep stos %rax,(%rdi)
    9ff7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    9ffc:	48 89 05 d5 90 01 00 	mov    %rax,0x190d5(%rip)        # 230d8 <fwp_ntapes>
    a003:	4d 6b e7 58          	imul   $0x58,%r15,%r12
    a007:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a00b:	48 8d 3d 50 51 00 00 	lea    0x5150(%rip),%rdi        # f162 <_IO_stdin_used+0x162>
    a012:	0f 29 04 24          	movaps %xmm0,(%rsp)
    a016:	4d 01 f4             	add    %r14,%r12
    a019:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    a020:	00 00 
    a022:	e8 59 93 ff ff       	call   3380 <getenv@plt>
    a027:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    a02c:	48 85 c0             	test   %rax,%rax
    a02f:	0f 84 b3 0d 00 00    	je     ade8 <fwp_hof0.constprop.0+0x10d8>
    a035:	80 38 30             	cmpb   $0x30,(%rax)
    a038:	0f 85 aa 0d 00 00    	jne    ade8 <fwp_hof0.constprop.0+0x10d8>
    a03e:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a042:	0f 85 a0 0d 00 00    	jne    ade8 <fwp_hof0.constprop.0+0x10d8>
    a048:	41 8b 04 24          	mov    (%r12),%eax
    a04c:	49 8d 4f 01          	lea    0x1(%r15),%rcx
    a050:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    a057:	00 00 
    a059:	48 89 0d 68 90 01 00 	mov    %rcx,0x19068(%rip)        # 230c8 <fwp_tape_next_slot>
    a060:	8d 50 01             	lea    0x1(%rax),%edx
    a063:	48 8b 05 f6 5c 00 00 	mov    0x5cf6(%rip),%rax        # fd60 <msg.4+0x20>
    a06a:	49 c7 44 24 40 00 00 	movq   $0x0,0x40(%r12)
    a071:	00 00 
    a073:	41 89 14 24          	mov    %edx,(%r12)
    a077:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a07c:	48 8b 05 15 34 06 00 	mov    0x63415(%rip),%rax        # 6d498 <fwp_cleanups>
    a083:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    a089:	48 85 c0             	test   %rax,%rax
    a08c:	75 1e                	jne    a0ac <fwp_hof0.constprop.0+0x39c>
    a08e:	e9 75 15 00 00       	jmp    b608 <fwp_hof0.constprop.0+0x18f8>
    a093:	66 90                	xchg   %ax,%ax
    a095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a09c:	00 00 00 00 
    a0a0:	48 8b 00             	mov    (%rax),%rax
    a0a3:	48 85 c0             	test   %rax,%rax
    a0a6:	0f 84 5c 15 00 00    	je     b608 <fwp_hof0.constprop.0+0x18f8>
    a0ac:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    a0b0:	75 ee                	jne    a0a0 <fwp_hof0.constprop.0+0x390>
    a0b2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    a0b6:	44 89 fe             	mov    %r15d,%esi
    a0b9:	48 63 07             	movslq (%rdi),%rax
    a0bc:	49 89 7c 24 40       	mov    %rdi,0x40(%r12)
    a0c1:	41 89 44 24 4c       	mov    %eax,0x4c(%r12)
    a0c6:	85 c0                	test   %eax,%eax
    a0c8:	78 09                	js     a0d3 <fwp_hof0.constprop.0+0x3c3>
    a0ca:	48 6b c0 58          	imul   $0x58,%rax,%rax
    a0ce:	45 89 7c 06 48       	mov    %r15d,0x48(%r14,%rax,1)
    a0d3:	89 37                	mov    %esi,(%rdi)
    a0d5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a0da:	45 31 ed             	xor    %r13d,%r13d
    a0dd:	48 89 f8             	mov    %rdi,%rax
    a0e0:	48 85 ff             	test   %rdi,%rdi
    a0e3:	0f 84 37 0e 00 00    	je     af20 <fwp_hof0.constprop.0+0x1210>
    a0e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a0f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a0f4:	49 83 c5 01          	add    $0x1,%r13
    a0f8:	48 85 c0             	test   %rax,%rax
    a0fb:	75 f3                	jne    a0f0 <fwp_hof0.constprop.0+0x3e0>
    a0fd:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a102:	0f 1f 00             	nopl   (%rax)
    a105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a10c:	00 00 00 00 
    a110:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    a114:	48 83 c0 01          	add    $0x1,%rax
    a118:	48 85 f6             	test   %rsi,%rsi
    a11b:	75 f3                	jne    a110 <fwp_hof0.constprop.0+0x400>
    a11d:	48 be fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rsi
    a124:	ff ff 1f 
    a127:	48 39 c6             	cmp    %rax,%rsi
    a12a:	0f 82 bd 14 00 00    	jb     b5ed <fwp_hof0.constprop.0+0x18dd>
    a130:	4d 85 ed             	test   %r13,%r13
    a133:	0f 8e e7 0d 00 00    	jle    af20 <fwp_hof0.constprop.0+0x1210>
    a139:	49 39 c5             	cmp    %rax,%r13
    a13c:	4c 0f 47 e8          	cmova  %rax,%r13
    a140:	4c 89 e8             	mov    %r13,%rax
    a143:	48 c1 e8 3c          	shr    $0x3c,%rax
    a147:	0f 85 a0 14 00 00    	jne    b5ed <fwp_hof0.constprop.0+0x18dd>
    a14d:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    a152:	48 c1 e2 10          	shl    $0x10,%rdx
    a156:	be 02 00 00 00       	mov    $0x2,%esi
    a15b:	48 09 ca             	or     %rcx,%rdx
    a15e:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a165:	00 
    a166:	48 89 14 24          	mov    %rdx,(%rsp)
    a16a:	e8 41 bd ff ff       	call   5eb0 <fwp_heap_alloc>
    a16f:	4c 89 30             	mov    %r14,(%rax)
    a172:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a179:	49 89 c4             	mov    %rax,%r12
    a17c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a183:	48 c1 e2 10          	shl    $0x10,%rdx
    a187:	48 39 d0             	cmp    %rdx,%rax
    a18a:	0f 83 50 0e 00 00    	jae    afe0 <fwp_hof0.constprop.0+0x12d0>
    a190:	48 89 c2             	mov    %rax,%rdx
    a193:	48 c1 ea 10          	shr    $0x10,%rdx
    a197:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a19b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a1a2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a1a6:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a1aa:	4d 85 f6             	test   %r14,%r14
    a1ad:	74 3a                	je     a1e9 <fwp_hof0.constprop.0+0x4d9>
    a1af:	0f b6 32             	movzbl (%rdx),%esi
    a1b2:	40 80 fe 02          	cmp    $0x2,%sil
    a1b6:	0f 84 d6 0d 00 00    	je     af92 <fwp_hof0.constprop.0+0x1282>
    a1bc:	40 80 fe 01          	cmp    $0x1,%sil
    a1c0:	75 27                	jne    a1e9 <fwp_hof0.constprop.0+0x4d9>
    a1c2:	8b 72 18             	mov    0x18(%rdx),%esi
    a1c5:	0f b7 c0             	movzwl %ax,%eax
    a1c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1cb:	48 0f af c6          	imul   %rsi,%rax
    a1cf:	48 c1 e8 20          	shr    $0x20,%rax
    a1d3:	48 39 d0             	cmp    %rdx,%rax
    a1d6:	73 11                	jae    a1e9 <fwp_hof0.constprop.0+0x4d9>
    a1d8:	49 01 c6             	add    %rax,%r14
    a1db:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a1df:	0f 84 c0 0d 00 00    	je     afa5 <fwp_hof0.constprop.0+0x1295>
    a1e5:	41 c6 06 01          	movb   $0x1,(%r14)
    a1e9:	4d 85 ed             	test   %r13,%r13
    a1ec:	74 46                	je     a234 <fwp_hof0.constprop.0+0x524>
    a1ee:	48 8b 34 24          	mov    (%rsp),%rsi
    a1f2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a1f7:	31 c0                	xor    %eax,%eax
    a1f9:	48 c1 e6 20          	shl    $0x20,%rsi
    a1fd:	0f 1f 00             	nopl   (%rax)
    a200:	48 89 c1             	mov    %rax,%rcx
    a203:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a208:	48 01 f1             	add    %rsi,%rcx
    a20b:	0f 80 ff 94 ff ff    	jo     3710 <fwp_hof0.constprop.0.cold+0x5>
    a211:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    a216:	48 89 c1             	mov    %rax,%rcx
    a219:	48 83 c0 01          	add    $0x1,%rax
    a21d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a221:	48 c1 e1 04          	shl    $0x4,%rcx
    a225:	41 0f 11 44 0c 08    	movups %xmm0,0x8(%r12,%rcx,1)
    a22b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a22f:	4c 39 e8             	cmp    %r13,%rax
    a232:	72 cc                	jb     a200 <fwp_hof0.constprop.0+0x4f0>
    a234:	49 8b 04 24          	mov    (%r12),%rax
    a238:	48 d1 e8             	shr    $1,%rax
    a23b:	0f 84 af 0d 00 00    	je     aff0 <fwp_hof0.constprop.0+0x12e0>
    a241:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    a245:	48 89 f7             	mov    %rsi,%rdi
    a248:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a24c:	0f 85 9b 13 00 00    	jne    b5ed <fwp_hof0.constprop.0+0x18dd>
    a252:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
    a259:	00 ff ff ff ff 
    a25e:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    a262:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
    a269:	00 00 00 00 00 
    a26e:	48 85 f6             	test   %rsi,%rsi
    a271:	74 58                	je     a2cb <fwp_hof0.constprop.0+0x5bb>
    a273:	48 c1 e0 04          	shl    $0x4,%rax
    a277:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    a27c:	49 89 d7             	mov    %rdx,%r15
    a27f:	49 8d 5c 24 08       	lea    0x8(%r12),%rbx
    a284:	4d 8d 74 04 f8       	lea    -0x8(%r12,%rax,1),%r14
    a289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a290:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a294:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a298:	48 8d 94 24 b0 00 00 	lea    0xb0(%rsp),%rdx
    a29f:	00 
    a2a0:	48 83 c3 10          	add    $0x10,%rbx
    a2a4:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a2a8:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a2ac:	e8 bf c3 ff ff       	call   6670 <w120>
    a2b1:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a2b6:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a2ba:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a2be:	49 39 de             	cmp    %rbx,%r14
    a2c1:	75 cd                	jne    a290 <fwp_hof0.constprop.0+0x580>
    a2c3:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    a2c8:	4c 89 fa             	mov    %r15,%rdx
    a2cb:	49 89 14 24          	mov    %rdx,(%r12)
    a2cf:	4c 89 e7             	mov    %r12,%rdi
    a2d2:	e8 e9 ca ff ff       	call   6dc0 <w176.constprop.0>
    a2d7:	4c 89 e7             	mov    %r12,%rdi
    a2da:	49 89 c6             	mov    %rax,%r14
    a2dd:	e8 8e e2 ff ff       	call   8570 <fwp_drop10>
    a2e2:	4c 63 3c 24          	movslq (%rsp),%r15
    a2e6:	4c 89 ff             	mov    %r15,%rdi
    a2e9:	e8 02 a4 ff ff       	call   46f0 <fwp_tape_of>
    a2ee:	48 89 c6             	mov    %rax,%rsi
    a2f1:	48 83 78 50 00       	cmpq   $0x0,0x50(%rax)
    a2f6:	0f 85 fd 12 00 00    	jne    b5f9 <fwp_hof0.constprop.0+0x18e9>
    a2fc:	48 89 c7             	mov    %rax,%rdi
    a2ff:	e8 4c 99 ff ff       	call   3c50 <fwp_tape_unlink_scope>
    a304:	4c 8b 46 38          	mov    0x38(%rsi),%r8
    a308:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a30d:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a314:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
    a318:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a31c:	66 49 0f 6e f0       	movq   %r8,%xmm6
    a321:	f3 0f 6f 56 20       	movdqu 0x20(%rsi),%xmm2
    a326:	4c 8b 56 30          	mov    0x30(%rsi),%r10
    a32a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a32e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a334:	77 19                	ja     a34f <fwp_hof0.constprop.0+0x63f>
    a336:	0f b7 04 24          	movzwl (%rsp),%eax
    a33a:	83 e8 01             	sub    $0x1,%eax
    a33d:	48 98                	cltq
    a33f:	48 3b 05 82 8d 01 00 	cmp    0x18d82(%rip),%rax        # 230c8 <fwp_tape_next_slot>
    a346:	7d 07                	jge    a34f <fwp_hof0.constprop.0+0x63f>
    a348:	48 89 05 79 8d 01 00 	mov    %rax,0x18d79(%rip)        # 230c8 <fwp_tape_next_slot>
    a34f:	48 8b 05 42 31 06 00 	mov    0x63142(%rip),%rax        # 6d498 <fwp_cleanups>
    a356:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a35a:	4c 8d ac 24 b0 00 00 	lea    0xb0(%rsp),%r13
    a361:	00 
    a362:	48 c7 46 30 00 00 00 	movq   $0x0,0x30(%rsi)
    a369:	00 
    a36a:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a36e:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    a375:	00 
    a376:	48 8d 05 a3 ae ff ff 	lea    -0x515d(%rip),%rax        # 5220 <fwp_tape_buffers_release>
    a37d:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    a384:	00 
    a385:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a38c:	00 
    a38d:	48 c7 46 38 00 00 00 	movq   $0x0,0x38(%rsi)
    a394:	00 
    a395:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a39c:	00 
    a39d:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a3a1:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    a3a8:	00 
    a3a9:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
    a3b0:	00 
    a3b1:	48 89 05 e0 30 06 00 	mov    %rax,0x630e0(%rip)        # 6d498 <fwp_cleanups>
    a3b8:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    a3bf:	00 
    a3c0:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    a3c7:	00 
    a3c8:	4d 85 f6             	test   %r14,%r14
    a3cb:	0f 88 6f 0d 00 00    	js     b140 <fwp_hof0.constprop.0+0x1430>
    a3d1:	4c 89 f0             	mov    %r14,%rax
    a3d4:	48 c1 f8 20          	sar    $0x20,%rax
    a3d8:	49 39 c7             	cmp    %rax,%r15
    a3db:	0f 85 c7 11 00 00    	jne    b5a8 <fwp_hof0.constprop.0+0x1898>
    a3e1:	44 89 f1             	mov    %r14d,%ecx
    a3e4:	49 89 cf             	mov    %rcx,%r15
    a3e7:	48 39 ca             	cmp    %rcx,%rdx
    a3ea:	0f 8e c4 11 00 00    	jle    b5b4 <fwp_hof0.constprop.0+0x18a4>
    a3f0:	49 39 cb             	cmp    %rcx,%r11
    a3f3:	0f 8e 17 0c 00 00    	jle    b010 <fwp_hof0.constprop.0+0x1300>
    a3f9:	4d 39 c3             	cmp    %r8,%r11
    a3fc:	0f 8f 46 0c 00 00    	jg     b048 <fwp_hof0.constprop.0+0x1338>
    a402:	4d 85 d2             	test   %r10,%r10
    a405:	0f 84 43 12 00 00    	je     b64e <fwp_hof0.constprop.0+0x193e>
    a40b:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    a410:	4d 8d 7b ff          	lea    -0x1(%r11),%r15
    a414:	31 f6                	xor    %esi,%esi
    a416:	4c 89 d7             	mov    %r10,%rdi
    a419:	4c 89 1c 24          	mov    %r11,(%rsp)
    a41d:	4a 8d 14 dd 00 00 00 	lea    0x0(,%r11,8),%rdx
    a424:	00 
    a425:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a42a:	e8 71 90 ff ff       	call   34a0 <memset@plt>
    a42f:	4c 8b 1c 24          	mov    (%rsp),%r11
    a433:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a439:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    a43e:	49 89 c2             	mov    %rax,%r10
    a441:	f2 0f 10 05 a7 59 00 	movsd  0x59a7(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    a448:	00 
    a449:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    a44f:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    a455:	4d 39 df             	cmp    %r11,%r15
    a458:	7c 6c                	jl     a4c6 <fwp_hof0.constprop.0+0x7b6>
    a45a:	4b 8d 14 fa          	lea    (%r10,%r15,8),%rdx
    a45e:	4d 29 df             	sub    %r11,%r15
    a461:	66 48 0f 7e d1       	movq   %xmm2,%rcx
    a466:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
    a46a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a46e:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    a472:	eb 08                	jmp    a47c <fwp_hof0.constprop.0+0x76c>
    a474:	0f 1f 40 00          	nopl   0x0(%rax)
    a478:	48 83 e8 18          	sub    $0x18,%rax
    a47c:	f2 0f 10 02          	movsd  (%rdx),%xmm0
    a480:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a484:	7a 02                	jp     a488 <fwp_hof0.constprop.0+0x778>
    a486:	74 35                	je     a4bd <fwp_hof0.constprop.0+0x7ad>
    a488:	48 63 30             	movslq (%rax),%rsi
    a48b:	85 f6                	test   %esi,%esi
    a48d:	78 15                	js     a4a4 <fwp_hof0.constprop.0+0x794>
    a48f:	f2 0f 10 48 08       	movsd  0x8(%rax),%xmm1
    a494:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a498:	f2 41 0f 58 0c f2    	addsd  (%r10,%rsi,8),%xmm1
    a49e:	f2 41 0f 11 0c f2    	movsd  %xmm1,(%r10,%rsi,8)
    a4a4:	48 63 70 04          	movslq 0x4(%rax),%rsi
    a4a8:	85 f6                	test   %esi,%esi
    a4aa:	78 11                	js     a4bd <fwp_hof0.constprop.0+0x7ad>
    a4ac:	f2 0f 59 40 10       	mulsd  0x10(%rax),%xmm0
    a4b1:	f2 41 0f 58 04 f2    	addsd  (%r10,%rsi,8),%xmm0
    a4b7:	f2 41 0f 11 04 f2    	movsd  %xmm0,(%r10,%rsi,8)
    a4bd:	48 83 ea 08          	sub    $0x8,%rdx
    a4c1:	48 39 c1             	cmp    %rax,%rcx
    a4c4:	75 b2                	jne    a478 <fwp_hof0.constprop.0+0x768>
    a4c6:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a4cd:	ff ff 1f 
    a4d0:	4c 39 d8             	cmp    %r11,%rax
    a4d3:	0f 82 08 11 00 00    	jb     b5e1 <fwp_hof0.constprop.0+0x18d1>
    a4d9:	4a 8d 3c dd 08 00 00 	lea    0x8(,%r11,8),%rdi
    a4e0:	00 
    a4e1:	be 02 00 00 00       	mov    $0x2,%esi
    a4e6:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
    a4eb:	4c 89 1c 24          	mov    %r11,(%rsp)
    a4ef:	e8 bc b9 ff ff       	call   5eb0 <fwp_heap_alloc>
    a4f4:	4c 8b 1c 24          	mov    (%rsp),%r11
    a4f8:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    a4fd:	49 89 c7             	mov    %rax,%r15
    a500:	4d 85 db             	test   %r11,%r11
    a503:	4c 89 18             	mov    %r11,(%rax)
    a506:	74 2a                	je     a532 <fwp_hof0.constprop.0+0x822>
    a508:	66 90                	xchg   %ax,%ax
    a50a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a511:	00 00 00 00 
    a515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a51c:	00 00 00 00 
    a520:	49 8b 04 da          	mov    (%r10,%rbx,8),%rax
    a524:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    a529:	48 83 c3 01          	add    $0x1,%rbx
    a52d:	49 39 db             	cmp    %rbx,%r11
    a530:	75 ee                	jne    a520 <fwp_hof0.constprop.0+0x810>
    a532:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
    a539:	00 
    a53a:	4c 89 ef             	mov    %r13,%rdi
    a53d:	4c 89 35 54 2f 06 00 	mov    %r14,0x62f54(%rip)        # 6d498 <fwp_cleanups>
    a544:	e8 d7 ac ff ff       	call   5220 <fwp_tape_buffers_release>
    a549:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a550:	4c 89 f8             	mov    %r15,%rax
    a553:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a55a:	48 c1 e2 10          	shl    $0x10,%rdx
    a55e:	48 39 d0             	cmp    %rdx,%rax
    a561:	73 59                	jae    a5bc <fwp_hof0.constprop.0+0x8ac>
    a563:	48 89 c2             	mov    %rax,%rdx
    a566:	48 c1 ea 10          	shr    $0x10,%rdx
    a56a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a56e:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a575:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a579:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a57d:	4d 85 e4             	test   %r12,%r12
    a580:	74 3a                	je     a5bc <fwp_hof0.constprop.0+0x8ac>
    a582:	0f b6 0a             	movzbl (%rdx),%ecx
    a585:	80 f9 02             	cmp    $0x2,%cl
    a588:	0f 84 e2 0b 00 00    	je     b170 <fwp_hof0.constprop.0+0x1460>
    a58e:	80 f9 01             	cmp    $0x1,%cl
    a591:	75 29                	jne    a5bc <fwp_hof0.constprop.0+0x8ac>
    a593:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a596:	0f b7 c0             	movzwl %ax,%eax
    a599:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a59c:	48 0f af c1          	imul   %rcx,%rax
    a5a0:	48 c1 e8 20          	shr    $0x20,%rax
    a5a4:	48 39 d0             	cmp    %rdx,%rax
    a5a7:	73 13                	jae    a5bc <fwp_hof0.constprop.0+0x8ac>
    a5a9:	49 01 c4             	add    %rax,%r12
    a5ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a5b1:	0f 84 cd 0b 00 00    	je     b184 <fwp_hof0.constprop.0+0x1474>
    a5b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a5bc:	4c 3b 74 24 28       	cmp    0x28(%rsp),%r14
    a5c1:	0f 85 44 91 ff ff    	jne    370b <fwp_hof0.constprop.0.cold>
    a5c7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    a5cc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a5d1:	48 89 05 c0 2e 06 00 	mov    %rax,0x62ec0(%rip)        # 6d498 <fwp_cleanups>
    a5d8:	e8 53 d0 ff ff       	call   7630 <fwp_tape_scope_release>
    a5dd:	49 8b 07             	mov    (%r15),%rax
    a5e0:	48 89 c3             	mov    %rax,%rbx
    a5e3:	48 0f ba f3 3f       	btr    $0x3f,%rbx
    a5e8:	48 85 c0             	test   %rax,%rax
    a5eb:	0f 88 7f 08 00 00    	js     ae70 <fwp_hof0.constprop.0+0x1160>
    a5f1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5f8:	4c 89 f8             	mov    %r15,%rax
    a5fb:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a602:	48 c1 e2 10          	shl    $0x10,%rdx
    a606:	48 39 d0             	cmp    %rdx,%rax
    a609:	0f 83 61 08 00 00    	jae    ae70 <fwp_hof0.constprop.0+0x1160>
    a60f:	48 89 c2             	mov    %rax,%rdx
    a612:	48 c1 ea 10          	shr    $0x10,%rdx
    a616:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a61a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a621:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a625:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a629:	48 85 c9             	test   %rcx,%rcx
    a62c:	0f 84 3e 08 00 00    	je     ae70 <fwp_hof0.constprop.0+0x1160>
    a632:	0f b6 32             	movzbl (%rdx),%esi
    a635:	40 80 fe 02          	cmp    $0x2,%sil
    a639:	0f 84 19 08 00 00    	je     ae58 <fwp_hof0.constprop.0+0x1148>
    a63f:	40 80 fe 01          	cmp    $0x1,%sil
    a643:	0f 85 27 08 00 00    	jne    ae70 <fwp_hof0.constprop.0+0x1160>
    a649:	8b 72 18             	mov    0x18(%rdx),%esi
    a64c:	0f b7 c0             	movzwl %ax,%eax
    a64f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a652:	48 0f af c6          	imul   %rsi,%rax
    a656:	48 c1 e8 20          	shr    $0x20,%rax
    a65a:	48 39 d0             	cmp    %rdx,%rax
    a65d:	0f 83 0d 08 00 00    	jae    ae70 <fwp_hof0.constprop.0+0x1160>
    a663:	48 01 c1             	add    %rax,%rcx
    a666:	80 39 01             	cmpb   $0x1,(%rcx)
    a669:	0f 85 01 08 00 00    	jne    ae70 <fwp_hof0.constprop.0+0x1160>
    a66f:	4c 89 3c 24          	mov    %r15,(%rsp)
    a673:	4d 89 fc             	mov    %r15,%r12
    a676:	31 ff                	xor    %edi,%edi
    a678:	48 8b 04 24          	mov    (%rsp),%rax
    a67c:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a680:	31 c0                	xor    %eax,%eax
    a682:	48 85 db             	test   %rbx,%rbx
    a685:	75 33                	jne    a6ba <fwp_hof0.constprop.0+0x9aa>
    a687:	eb 47                	jmp    a6d0 <fwp_hof0.constprop.0+0x9c0>
    a689:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a690:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a695:	0f 88 25 0f 00 00    	js     b5c0 <fwp_hof0.constprop.0+0x18b0>
    a69b:	f2 0f 10 05 cd 56 00 	movsd  0x56cd(%rip),%xmm0        # fd70 <msg.4+0x30>
    a6a2:	00 
    a6a3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a6a8:	48 83 c0 01          	add    $0x1,%rax
    a6ac:	48 83 c2 08          	add    $0x8,%rdx
    a6b0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a6b5:	48 39 c3             	cmp    %rax,%rbx
    a6b8:	74 16                	je     a6d0 <fwp_hof0.constprop.0+0x9c0>
    a6ba:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a6be:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a6c2:	79 cc                	jns    a690 <fwp_hof0.constprop.0+0x980>
    a6c4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a6c8:	eb c6                	jmp    a690 <fwp_hof0.constprop.0+0x980>
    a6ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6d0:	e8 9b de ff ff       	call   8570 <fwp_drop10>
    a6d5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a6da:	31 d2                	xor    %edx,%edx
    a6dc:	48 89 f8             	mov    %rdi,%rax
    a6df:	48 85 ff             	test   %rdi,%rdi
    a6e2:	0f 84 dc 0c 00 00    	je     b3c4 <fwp_hof0.constprop.0+0x16b4>
    a6e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a6ef:	00 
    a6f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a6f4:	48 83 c2 01          	add    $0x1,%rdx
    a6f8:	48 85 c0             	test   %rax,%rax
    a6fb:	75 f3                	jne    a6f0 <fwp_hof0.constprop.0+0x9e0>
    a6fd:	49 8b 04 24          	mov    (%r12),%rax
    a701:	49 89 c6             	mov    %rax,%r14
    a704:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a709:	48 85 c0             	test   %rax,%rax
    a70c:	0f 88 eb 05 00 00    	js     acfd <fwp_hof0.constprop.0+0xfed>
    a712:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a719:	48 8b 34 24          	mov    (%rsp),%rsi
    a71d:	48 2b b5 b0 13 00 00 	sub    0x13b0(%rbp),%rsi
    a724:	48 c1 e0 10          	shl    $0x10,%rax
    a728:	48 39 c6             	cmp    %rax,%rsi
    a72b:	0f 83 cc 05 00 00    	jae    acfd <fwp_hof0.constprop.0+0xfed>
    a731:	48 89 f0             	mov    %rsi,%rax
    a734:	48 c1 e8 10          	shr    $0x10,%rax
    a738:	48 8d 3c 80          	lea    (%rax,%rax,4),%rdi
    a73c:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a743:	48 8d 3c f8          	lea    (%rax,%rdi,8),%rdi
    a747:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    a74b:	4d 85 c0             	test   %r8,%r8
    a74e:	0f 84 a9 05 00 00    	je     acfd <fwp_hof0.constprop.0+0xfed>
    a754:	0f b6 07             	movzbl (%rdi),%eax
    a757:	3c 02                	cmp    $0x2,%al
    a759:	0f 84 89 05 00 00    	je     ace8 <fwp_hof0.constprop.0+0xfd8>
    a75f:	3c 01                	cmp    $0x1,%al
    a761:	0f 85 8a 05 00 00    	jne    acf1 <fwp_hof0.constprop.0+0xfe1>
    a767:	8b 47 18             	mov    0x18(%rdi),%eax
    a76a:	0f b7 f6             	movzwl %si,%esi
    a76d:	48 0f af f0          	imul   %rax,%rsi
    a771:	8b 47 1c             	mov    0x1c(%rdi),%eax
    a774:	48 c1 ee 20          	shr    $0x20,%rsi
    a778:	48 39 c6             	cmp    %rax,%rsi
    a77b:	0f 83 70 05 00 00    	jae    acf1 <fwp_hof0.constprop.0+0xfe1>
    a781:	49 01 f0             	add    %rsi,%r8
    a784:	41 80 38 01          	cmpb   $0x1,(%r8)
    a788:	0f 85 63 05 00 00    	jne    acf1 <fwp_hof0.constprop.0+0xfe1>
    a78e:	4c 39 f2             	cmp    %r14,%rdx
    a791:	4c 89 f0             	mov    %r14,%rax
    a794:	48 0f 46 c2          	cmovbe %rdx,%rax
    a798:	48 85 c0             	test   %rax,%rax
    a79b:	0f 84 2b 0e 00 00    	je     b5cc <fwp_hof0.constprop.0+0x18bc>
    a7a1:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    a7a8:	00 
    a7a9:	49 8d 5c 24 08       	lea    0x8(%r12),%rbx
    a7ae:	4c 8b 04 24          	mov    (%rsp),%r8
    a7b2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a7b7:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a7be:	00 
    a7bf:	31 d2                	xor    %edx,%edx
    a7c1:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a7c5:	eb 55                	jmp    a81c <fwp_hof0.constprop.0+0xb0c>
    a7c7:	66 90                	xchg   %ax,%ax
    a7c9:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a7d0:	00 00 00 00 
    a7d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a7db:	00 00 00 00 
    a7df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a7e6:	00 00 00 00 
    a7ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a7f1:	00 00 00 00 
    a7f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a7fc:	00 00 00 00 
    a800:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a805:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a80a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a80f:	48 83 c2 08          	add    $0x8,%rdx
    a813:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a817:	49 39 d1             	cmp    %rdx,%r9
    a81a:	74 14                	je     a830 <fwp_hof0.constprop.0+0xb20>
    a81c:	48 89 fe             	mov    %rdi,%rsi
    a81f:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a824:	79 da                	jns    a800 <fwp_hof0.constprop.0+0xaf0>
    a826:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a82a:	eb d4                	jmp    a800 <fwp_hof0.constprop.0+0xaf0>
    a82c:	0f 1f 40 00          	nopl   0x0(%rax)
    a830:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a835:	48 85 c9             	test   %rcx,%rcx
    a838:	0f 84 62 0d 00 00    	je     b5a0 <fwp_hof0.constprop.0+0x1890>
    a83e:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a845:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a84c:	45 31 ff             	xor    %r15d,%r15d
    a84f:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a856:	49 c1 e1 10          	shl    $0x10,%r9
    a85a:	eb 1a                	jmp    a876 <fwp_hof0.constprop.0+0xb66>
    a85c:	0f 1f 40 00          	nopl   0x0(%rax)
    a860:	49 83 c7 01          	add    $0x1,%r15
    a864:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a868:	49 39 c7             	cmp    %rax,%r15
    a86b:	0f 83 5f 01 00 00    	jae    a9d0 <fwp_hof0.constprop.0+0xcc0>
    a871:	48 85 c9             	test   %rcx,%rcx
    a874:	74 56                	je     a8cc <fwp_hof0.constprop.0+0xbbc>
    a876:	48 89 ca             	mov    %rcx,%rdx
    a879:	4c 29 d2             	sub    %r10,%rdx
    a87c:	4c 39 ca             	cmp    %r9,%rdx
    a87f:	73 4b                	jae    a8cc <fwp_hof0.constprop.0+0xbbc>
    a881:	48 89 d6             	mov    %rdx,%rsi
    a884:	48 c1 ee 10          	shr    $0x10,%rsi
    a888:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a88c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a890:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a894:	48 85 ff             	test   %rdi,%rdi
    a897:	74 33                	je     a8cc <fwp_hof0.constprop.0+0xbbc>
    a899:	44 0f b6 06          	movzbl (%rsi),%r8d
    a89d:	41 80 f8 02          	cmp    $0x2,%r8b
    a8a1:	0f 84 11 01 00 00    	je     a9b8 <fwp_hof0.constprop.0+0xca8>
    a8a7:	41 80 f8 01          	cmp    $0x1,%r8b
    a8ab:	75 1f                	jne    a8cc <fwp_hof0.constprop.0+0xbbc>
    a8ad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a8b1:	0f b7 d2             	movzwl %dx,%edx
    a8b4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a8b7:	49 0f af d0          	imul   %r8,%rdx
    a8bb:	48 c1 ea 20          	shr    $0x20,%rdx
    a8bf:	48 39 f2             	cmp    %rsi,%rdx
    a8c2:	73 08                	jae    a8cc <fwp_hof0.constprop.0+0xbbc>
    a8c4:	48 01 d7             	add    %rdx,%rdi
    a8c7:	80 3f 01             	cmpb   $0x1,(%rdi)
    a8ca:	74 94                	je     a860 <fwp_hof0.constprop.0+0xb50>
    a8cc:	49 39 c7             	cmp    %rax,%r15
    a8cf:	0f 83 fb 00 00 00    	jae    a9d0 <fwp_hof0.constprop.0+0xcc0>
    a8d5:	49 89 c6             	mov    %rax,%r14
    a8d8:	31 c9                	xor    %ecx,%ecx
    a8da:	eb 38                	jmp    a914 <fwp_hof0.constprop.0+0xc04>
    a8dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a8e0:	40 80 ff 01          	cmp    $0x1,%dil
    a8e4:	75 25                	jne    a90b <fwp_hof0.constprop.0+0xbfb>
    a8e6:	8b 7e 18             	mov    0x18(%rsi),%edi
    a8e9:	0f b7 c0             	movzwl %ax,%eax
    a8ec:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a8ef:	48 0f af c7          	imul   %rdi,%rax
    a8f3:	48 c1 e8 20          	shr    $0x20,%rax
    a8f7:	48 39 f0             	cmp    %rsi,%rax
    a8fa:	73 0f                	jae    a90b <fwp_hof0.constprop.0+0xbfb>
    a8fc:	48 01 c2             	add    %rax,%rdx
    a8ff:	80 3a ff             	cmpb   $0xff,(%rdx)
    a902:	0f 84 b0 06 00 00    	je     afb8 <fwp_hof0.constprop.0+0x12a8>
    a908:	c6 02 01             	movb   $0x1,(%rdx)
    a90b:	4d 39 f7             	cmp    %r14,%r15
    a90e:	0f 83 8c 00 00 00    	jae    a9a0 <fwp_hof0.constprop.0+0xc90>
    a914:	49 83 ee 01          	sub    $0x1,%r14
    a918:	66 48 0f 6e e9       	movq   %rcx,%xmm5
    a91d:	bf 01 00 00 00       	mov    $0x1,%edi
    a922:	f3 42 0f 7e 04 f3    	movq   (%rbx,%r14,8),%xmm0
    a928:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    a92f:	00 
    a930:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a934:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    a93b:	00 
    a93c:	e8 5f b7 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    a941:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a948:	48 89 c1             	mov    %rax,%rcx
    a94b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a952:	48 c1 e2 10          	shl    $0x10,%rdx
    a956:	48 39 d0             	cmp    %rdx,%rax
    a959:	73 b0                	jae    a90b <fwp_hof0.constprop.0+0xbfb>
    a95b:	48 89 c2             	mov    %rax,%rdx
    a95e:	48 c1 ea 10          	shr    $0x10,%rdx
    a962:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a966:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a96d:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    a971:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    a975:	48 85 d2             	test   %rdx,%rdx
    a978:	74 91                	je     a90b <fwp_hof0.constprop.0+0xbfb>
    a97a:	0f b6 3e             	movzbl (%rsi),%edi
    a97d:	40 80 ff 02          	cmp    $0x2,%dil
    a981:	0f 85 59 ff ff ff    	jne    a8e0 <fwp_hof0.constprop.0+0xbd0>
    a987:	66 85 c0             	test   %ax,%ax
    a98a:	0f 84 6f ff ff ff    	je     a8ff <fwp_hof0.constprop.0+0xbef>
    a990:	4d 39 f7             	cmp    %r14,%r15
    a993:	0f 82 7b ff ff ff    	jb     a914 <fwp_hof0.constprop.0+0xc04>
    a999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9a0:	4d 85 ff             	test   %r15,%r15
    a9a3:	75 2d                	jne    a9d2 <fwp_hof0.constprop.0+0xcc2>
    a9a5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    a9a9:	85 c0                	test   %eax,%eax
    a9ab:	49 0f 45 df          	cmovne %r15,%rbx
    a9af:	eb 62                	jmp    aa13 <fwp_hof0.constprop.0+0xd03>
    a9b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9b8:	66 85 d2             	test   %dx,%dx
    a9bb:	0f 84 06 ff ff ff    	je     a8c7 <fwp_hof0.constprop.0+0xbb7>
    a9c1:	49 39 c7             	cmp    %rax,%r15
    a9c4:	0f 82 0b ff ff ff    	jb     a8d5 <fwp_hof0.constprop.0+0xbc5>
    a9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9d0:	31 c9                	xor    %ecx,%ecx
    a9d2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a9d7:	48 89 da             	mov    %rbx,%rdx
    a9da:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a9de:	66 90                	xchg   %ax,%ax
    a9e0:	48 8b 32             	mov    (%rdx),%rsi
    a9e3:	48 83 c2 08          	add    $0x8,%rdx
    a9e7:	48 89 c7             	mov    %rax,%rdi
    a9ea:	48 89 70 08          	mov    %rsi,0x8(%rax)
    a9ee:	48 8b 40 10          	mov    0x10(%rax),%rax
    a9f2:	49 39 d1             	cmp    %rdx,%r9
    a9f5:	75 e9                	jne    a9e0 <fwp_hof0.constprop.0+0xcd0>
    a9f7:	8b 54 24 20          	mov    0x20(%rsp),%edx
    a9fb:	48 89 4f 10          	mov    %rcx,0x10(%rdi)
    a9ff:	85 d2                	test   %edx,%edx
    aa01:	0f 84 91 07 00 00    	je     b198 <fwp_hof0.constprop.0+0x1488>
    aa07:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    aa0c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    aa11:	31 db                	xor    %ebx,%ebx
    aa13:	48 89 df             	mov    %rbx,%rdi
    aa16:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    aa1b:	e8 90 af ff ff       	call   59b0 <fwp_mem_free>
    aa20:	48 8b 3c 24          	mov    (%rsp),%rdi
    aa24:	e8 47 db ff ff       	call   8570 <fwp_drop10>
    aa29:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aa2e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    aa33:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa3a:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa41:	48 c1 e2 10          	shl    $0x10,%rdx
    aa45:	48 39 d0             	cmp    %rdx,%rax
    aa48:	0f 83 81 00 00 00    	jae    aacf <fwp_hof0.constprop.0+0xdbf>
    aa4e:	49 89 ce             	mov    %rcx,%r14
    aa51:	48 89 c2             	mov    %rax,%rdx
    aa54:	48 8b bd f8 13 00 00 	mov    0x13f8(%rbp),%rdi
    aa5b:	48 c1 ea 10          	shr    $0x10,%rdx
    aa5f:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    aa63:	48 8d 14 d7          	lea    (%rdi,%rdx,8),%rdx
    aa67:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aa6b:	4d 85 e4             	test   %r12,%r12
    aa6e:	0f 84 25 03 00 00    	je     ad99 <fwp_hof0.constprop.0+0x1089>
    aa74:	0f b6 32             	movzbl (%rdx),%esi
    aa77:	40 80 fe 02          	cmp    $0x2,%sil
    aa7b:	0f 84 0f 03 00 00    	je     ad90 <fwp_hof0.constprop.0+0x1080>
    aa81:	40 80 fe 01          	cmp    $0x1,%sil
    aa85:	0f 85 0e 03 00 00    	jne    ad99 <fwp_hof0.constprop.0+0x1089>
    aa8b:	8b 72 18             	mov    0x18(%rdx),%esi
    aa8e:	0f b7 c0             	movzwl %ax,%eax
    aa91:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa94:	48 0f af c6          	imul   %rsi,%rax
    aa98:	48 c1 e8 20          	shr    $0x20,%rax
    aa9c:	48 39 d0             	cmp    %rdx,%rax
    aa9f:	0f 83 f4 02 00 00    	jae    ad99 <fwp_hof0.constprop.0+0x1089>
    aaa5:	49 01 c4             	add    %rax,%r12
    aaa8:	41 0f b6 04 24       	movzbl (%r12),%eax
    aaad:	84 c0                	test   %al,%al
    aaaf:	0f 84 e4 02 00 00    	je     ad99 <fwp_hof0.constprop.0+0x1089>
    aab5:	3c 01                	cmp    $0x1,%al
    aab7:	0f 84 f3 06 00 00    	je     b1b0 <fwp_hof0.constprop.0+0x14a0>
    aabd:	4c 89 f1             	mov    %r14,%rcx
    aac0:	3c ff                	cmp    $0xff,%al
    aac2:	0f 84 76 09 00 00    	je     b43e <fwp_hof0.constprop.0+0x172e>
    aac8:	83 e8 01             	sub    $0x1,%eax
    aacb:	41 88 04 24          	mov    %al,(%r12)
    aacf:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
    aad5:	0f 85 cd 02 00 00    	jne    ada8 <fwp_hof0.constprop.0+0x1098>
    aadb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aae0:	49 89 cc             	mov    %rcx,%r12
    aae3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aae7:	4c 89 ef             	mov    %r13,%rdi
    aaea:	b9 01 00 00 00       	mov    $0x1,%ecx
    aaef:	48 8d 15 aa 80 00 00 	lea    0x80aa(%rip),%rdx        # 12ba0 <d0>
    aaf6:	4c 89 e6             	mov    %r12,%rsi
    aaf9:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
    ab00:	00 00 00 00 00 
    ab05:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    ab0c:	00 
    ab0d:	e8 be e1 ff ff       	call   8cd0 <fwp_write>
    ab12:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
    ab19:	00 
    ab1a:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    ab21:	00 
    ab22:	48 8d 05 45 45 00 00 	lea    0x4545(%rip),%rax        # f06e <_IO_stdin_used+0x6e>
    ab29:	4d 85 f6             	test   %r14,%r14
    ab2c:	4c 0f 44 f0          	cmove  %rax,%r14
    ab30:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    ab34:	0f 87 6a 0b 00 00    	ja     b6a4 <fwp_hof0.constprop.0+0x1994>
    ab3a:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    ab3e:	be 01 00 00 00       	mov    $0x1,%esi
    ab43:	e8 68 b3 ff ff       	call   5eb0 <fwp_heap_alloc>
    ab48:	4c 89 fa             	mov    %r15,%rdx
    ab4b:	4c 89 f6             	mov    %r14,%rsi
    ab4e:	4c 89 38             	mov    %r15,(%rax)
    ab51:	48 89 c3             	mov    %rax,%rbx
    ab54:	48 8d 78 08          	lea    0x8(%rax),%rdi
    ab58:	4c 8d 68 08          	lea    0x8(%rax),%r13
    ab5c:	e8 0f 8a ff ff       	call   3570 <memcpy@plt>
    ab61:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    ab67:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
    ab6e:	00 
    ab6f:	e8 2c 88 ff ff       	call   33a0 <free@plt>
    ab74:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ab7b:	48 89 d8             	mov    %rbx,%rax
    ab7e:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ab85:	48 c1 e2 10          	shl    $0x10,%rdx
    ab89:	48 39 d0             	cmp    %rdx,%rax
    ab8c:	73 57                	jae    abe5 <fwp_hof0.constprop.0+0xed5>
    ab8e:	48 89 c2             	mov    %rax,%rdx
    ab91:	48 c1 ea 10          	shr    $0x10,%rdx
    ab95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab99:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aba0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aba4:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    aba8:	4d 85 ff             	test   %r15,%r15
    abab:	74 38                	je     abe5 <fwp_hof0.constprop.0+0xed5>
    abad:	0f b6 0a             	movzbl (%rdx),%ecx
    abb0:	80 f9 02             	cmp    $0x2,%cl
    abb3:	0f 84 af 07 00 00    	je     b368 <fwp_hof0.constprop.0+0x1658>
    abb9:	80 f9 01             	cmp    $0x1,%cl
    abbc:	75 27                	jne    abe5 <fwp_hof0.constprop.0+0xed5>
    abbe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    abc1:	0f b7 c0             	movzwl %ax,%eax
    abc4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    abc7:	48 0f af c1          	imul   %rcx,%rax
    abcb:	48 c1 e8 20          	shr    $0x20,%rax
    abcf:	48 39 d0             	cmp    %rdx,%rax
    abd2:	73 11                	jae    abe5 <fwp_hof0.constprop.0+0xed5>
    abd4:	49 01 c7             	add    %rax,%r15
    abd7:	41 80 3f ff          	cmpb   $0xff,(%r15)
    abdb:	0f 84 9a 07 00 00    	je     b37b <fwp_hof0.constprop.0+0x166b>
    abe1:	41 c6 07 01          	movb   $0x1,(%r15)
    abe5:	4c 89 e7             	mov    %r12,%rdi
    abe8:	e8 93 d5 ff ff       	call   8180 <fwp_drop0>
    abed:	48 8b 13             	mov    (%rbx),%rdx
    abf0:	be 01 00 00 00       	mov    $0x1,%esi
    abf5:	4c 89 ef             	mov    %r13,%rdi
    abf8:	48 8b 0d 61 28 06 00 	mov    0x62861(%rip),%rcx        # 6d460 <fwp_prog_out>
    abff:	e8 3c 8a ff ff       	call   3640 <fwrite@plt>
    ac04:	48 8b 35 55 28 06 00 	mov    0x62855(%rip),%rsi        # 6d460 <fwp_prog_out>
    ac0b:	bf 0a 00 00 00       	mov    $0xa,%edi
    ac10:	e8 ab 88 ff ff       	call   34c0 <fputc@plt>
    ac15:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ac1c:	48 89 d8             	mov    %rbx,%rax
    ac1f:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ac26:	48 c1 e2 10          	shl    $0x10,%rdx
    ac2a:	48 39 d0             	cmp    %rdx,%rax
    ac2d:	73 71                	jae    aca0 <fwp_hof0.constprop.0+0xf90>
    ac2f:	48 89 c2             	mov    %rax,%rdx
    ac32:	48 c1 ea 10          	shr    $0x10,%rdx
    ac36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac3a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ac41:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac45:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac49:	4d 85 e4             	test   %r12,%r12
    ac4c:	74 52                	je     aca0 <fwp_hof0.constprop.0+0xf90>
    ac4e:	0f b6 0a             	movzbl (%rdx),%ecx
    ac51:	80 f9 02             	cmp    $0x2,%cl
    ac54:	0f 84 36 07 00 00    	je     b390 <fwp_hof0.constprop.0+0x1680>
    ac5a:	80 f9 01             	cmp    $0x1,%cl
    ac5d:	75 41                	jne    aca0 <fwp_hof0.constprop.0+0xf90>
    ac5f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac62:	0f b7 c0             	movzwl %ax,%eax
    ac65:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac68:	48 0f af c1          	imul   %rcx,%rax
    ac6c:	48 c1 e8 20          	shr    $0x20,%rax
    ac70:	48 39 d0             	cmp    %rdx,%rax
    ac73:	73 2b                	jae    aca0 <fwp_hof0.constprop.0+0xf90>
    ac75:	49 01 c4             	add    %rax,%r12
    ac78:	41 0f b6 04 24       	movzbl (%r12),%eax
    ac7d:	84 c0                	test   %al,%al
    ac7f:	74 1f                	je     aca0 <fwp_hof0.constprop.0+0xf90>
    ac81:	3c 01                	cmp    $0x1,%al
    ac83:	0f 84 25 07 00 00    	je     b3ae <fwp_hof0.constprop.0+0x169e>
    ac89:	3c ff                	cmp    $0xff,%al
    ac8b:	0f 84 96 08 00 00    	je     b527 <fwp_hof0.constprop.0+0x1817>
    ac91:	83 e8 01             	sub    $0x1,%eax
    ac94:	41 88 04 24          	mov    %al,(%r12)
    ac98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac9f:	00 
    aca0:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    aca5:	48 8b 40 10          	mov    0x10(%rax),%rax
    aca9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    acae:	48 85 c0             	test   %rax,%rax
    acb1:	0f 85 99 f0 ff ff    	jne    9d50 <fwp_hof0.constprop.0+0x40>
    acb7:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    acbe:	00 
    acbf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    acc6:	00 00 
    acc8:	0f 85 d1 09 00 00    	jne    b69f <fwp_hof0.constprop.0+0x198f>
    acce:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    acd5:	31 c0                	xor    %eax,%eax
    acd7:	5b                   	pop    %rbx
    acd8:	5d                   	pop    %rbp
    acd9:	41 5c                	pop    %r12
    acdb:	41 5d                	pop    %r13
    acdd:	41 5e                	pop    %r14
    acdf:	41 5f                	pop    %r15
    ace1:	c3                   	ret
    ace2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ace8:	66 85 f6             	test   %si,%si
    aceb:	0f 84 93 fa ff ff    	je     a784 <fwp_hof0.constprop.0+0xa74>
    acf1:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    acf7:	0f 84 fa 02 00 00    	je     aff7 <fwp_hof0.constprop.0+0x12e7>
    acfd:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ad02:	45 31 ff             	xor    %r15d,%r15d
    ad05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad0c:	00 00 00 00 
    ad10:	48 8b 40 10          	mov    0x10(%rax),%rax
    ad14:	4c 89 fa             	mov    %r15,%rdx
    ad17:	49 83 c7 01          	add    $0x1,%r15
    ad1b:	48 85 c0             	test   %rax,%rax
    ad1e:	75 f0                	jne    ad10 <fwp_hof0.constprop.0+0x1000>
    ad20:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ad27:	ff ff 1f 
    ad2a:	4c 39 f8             	cmp    %r15,%rax
    ad2d:	0f 82 ba 08 00 00    	jb     b5ed <fwp_hof0.constprop.0+0x18dd>
    ad33:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    ad3a:	00 
    ad3b:	be 02 00 00 00       	mov    $0x2,%esi
    ad40:	e8 6b b1 ff ff       	call   5eb0 <fwp_heap_alloc>
    ad45:	4d 39 fe             	cmp    %r15,%r14
    ad48:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    ad4d:	48 89 c3             	mov    %rax,%rbx
    ad50:	4c 89 f8             	mov    %r15,%rax
    ad53:	49 0f 46 c6          	cmovbe %r14,%rax
    ad57:	48 89 d9             	mov    %rbx,%rcx
    ad5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad60:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    ad64:	48 83 c1 08          	add    $0x8,%rcx
    ad68:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    ad6c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ad70:	48 85 d2             	test   %rdx,%rdx
    ad73:	75 eb                	jne    ad60 <fwp_hof0.constprop.0+0x1050>
    ad75:	48 85 c0             	test   %rax,%rax
    ad78:	0f 84 8b 02 00 00    	je     b009 <fwp_hof0.constprop.0+0x12f9>
    ad7e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    ad85:	00 
    ad86:	e9 23 fa ff ff       	jmp    a7ae <fwp_hof0.constprop.0+0xa9e>
    ad8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad90:	66 85 c0             	test   %ax,%ax
    ad93:	0f 84 0f fd ff ff    	je     aaa8 <fwp_hof0.constprop.0+0xd98>
    ad99:	4c 89 f1             	mov    %r14,%rcx
    ad9c:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
    ada2:	0f 84 38 fd ff ff    	je     aae0 <fwp_hof0.constprop.0+0xdd0>
    ada8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    adad:	45 31 c9             	xor    %r9d,%r9d
    adb0:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    adb5:	48 83 e8 01          	sub    $0x1,%rax
    adb9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    adbe:	41 0f 90 c1          	seto   %r9b
    adc2:	e9 2c f0 ff ff       	jmp    9df3 <fwp_hof0.constprop.0+0xe3>
    adc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    adce:	00 00 
    add0:	4d 39 fc             	cmp    %r15,%r12
    add3:	0f 84 87 f1 ff ff    	je     9f60 <fwp_hof0.constprop.0+0x250>
    add9:	4c 8b 35 00 83 01 00 	mov    0x18300(%rip),%r14        # 230e0 <fwp_tapes>
    ade0:	e9 1e f2 ff ff       	jmp    a003 <fwp_hof0.constprop.0+0x2f3>
    ade5:	0f 1f 00             	nopl   (%rax)
    ade8:	48 83 3d 98 82 01 00 	cmpq   $0x0,0x18298(%rip)        # 23088 <fwp_tape_cached_bytes>
    adef:	00 
    adf0:	0f 84 52 f2 ff ff    	je     a048 <fwp_hof0.constprop.0+0x338>
    adf6:	48 8b 05 b3 82 01 00 	mov    0x182b3(%rip),%rax        # 230b0 <fwp_tape_workspace+0x10>
    adfd:	66 0f 6f 0d 9b 82 01 	movdqa 0x1829b(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    ae04:	00 
    ae05:	48 c7 05 78 82 01 00 	movq   $0x0,0x18278(%rip)        # 23088 <fwp_tape_cached_bytes>
    ae0c:	00 00 00 00 
    ae10:	49 89 44 24 30       	mov    %rax,0x30(%r12)
    ae15:	48 8b 05 9c 82 01 00 	mov    0x1829c(%rip),%rax        # 230b8 <fwp_tape_workspace+0x18>
    ae1c:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    ae22:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ae26:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    ae2b:	48 8b 05 8e 82 01 00 	mov    0x1828e(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    ae32:	0f 29 0d 67 82 01 00 	movaps %xmm1,0x18267(%rip)        # 230a0 <fwp_tape_workspace>
    ae39:	49 89 44 24 38       	mov    %rax,0x38(%r12)
    ae3e:	0f 29 0d 6b 82 01 00 	movaps %xmm1,0x1826b(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    ae45:	48 c7 05 70 82 01 00 	movq   $0x0,0x18270(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    ae4c:	00 00 00 00 
    ae50:	e9 f3 f1 ff ff       	jmp    a048 <fwp_hof0.constprop.0+0x338>
    ae55:	0f 1f 00             	nopl   (%rax)
    ae58:	66 85 c0             	test   %ax,%ax
    ae5b:	0f 84 05 f8 ff ff    	je     a666 <fwp_hof0.constprop.0+0x956>
    ae61:	0f 1f 40 00          	nopl   0x0(%rax)
    ae65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae6c:	00 00 00 00 
    ae70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ae77:	ff ff 1f 
    ae7a:	48 39 d8             	cmp    %rbx,%rax
    ae7d:	0f 82 5e 07 00 00    	jb     b5e1 <fwp_hof0.constprop.0+0x18d1>
    ae83:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    ae8a:	00 
    ae8b:	be 01 00 00 00       	mov    $0x1,%esi
    ae90:	e8 1b b0 ff ff       	call   5eb0 <fwp_heap_alloc>
    ae95:	48 89 18             	mov    %rbx,(%rax)
    ae98:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ae9f:	49 89 c4             	mov    %rax,%r12
    aea2:	48 89 04 24          	mov    %rax,(%rsp)
    aea6:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aead:	48 c1 e2 10          	shl    $0x10,%rdx
    aeb1:	48 39 d0             	cmp    %rdx,%rax
    aeb4:	73 59                	jae    af0f <fwp_hof0.constprop.0+0x11ff>
    aeb6:	48 89 c2             	mov    %rax,%rdx
    aeb9:	48 c1 ea 10          	shr    $0x10,%rdx
    aebd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aec1:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aec8:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    aecc:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    aed0:	4d 85 f6             	test   %r14,%r14
    aed3:	74 3a                	je     af0f <fwp_hof0.constprop.0+0x11ff>
    aed5:	0f b6 31             	movzbl (%rcx),%esi
    aed8:	40 80 fe 02          	cmp    $0x2,%sil
    aedc:	0f 84 76 03 00 00    	je     b258 <fwp_hof0.constprop.0+0x1548>
    aee2:	40 80 fe 01          	cmp    $0x1,%sil
    aee6:	75 27                	jne    af0f <fwp_hof0.constprop.0+0x11ff>
    aee8:	8b 71 18             	mov    0x18(%rcx),%esi
    aeeb:	0f b7 c0             	movzwl %ax,%eax
    aeee:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aef1:	48 0f af c6          	imul   %rsi,%rax
    aef5:	48 c1 e8 20          	shr    $0x20,%rax
    aef9:	48 39 c8             	cmp    %rcx,%rax
    aefc:	73 11                	jae    af0f <fwp_hof0.constprop.0+0x11ff>
    aefe:	49 01 c6             	add    %rax,%r14
    af01:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af05:	0f 84 60 03 00 00    	je     b26b <fwp_hof0.constprop.0+0x155b>
    af0b:	41 c6 06 01          	movb   $0x1,(%r14)
    af0f:	4c 89 ff             	mov    %r15,%rdi
    af12:	e9 61 f7 ff ff       	jmp    a678 <fwp_hof0.constprop.0+0x968>
    af17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    af1e:	00 00 
    af20:	48 c1 e2 10          	shl    $0x10,%rdx
    af24:	be 02 00 00 00       	mov    $0x2,%esi
    af29:	bf 08 00 00 00       	mov    $0x8,%edi
    af2e:	48 09 ca             	or     %rcx,%rdx
    af31:	48 89 14 24          	mov    %rdx,(%rsp)
    af35:	e8 76 af ff ff       	call   5eb0 <fwp_heap_alloc>
    af3a:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    af41:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    af48:	49 89 c4             	mov    %rax,%r12
    af4b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    af52:	48 c1 e2 10          	shl    $0x10,%rdx
    af56:	48 39 d0             	cmp    %rdx,%rax
    af59:	0f 83 91 00 00 00    	jae    aff0 <fwp_hof0.constprop.0+0x12e0>
    af5f:	48 89 c2             	mov    %rax,%rdx
    af62:	48 c1 ea 10          	shr    $0x10,%rdx
    af66:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    af6a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    af71:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    af75:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    af79:	4d 85 f6             	test   %r14,%r14
    af7c:	0f 84 b2 f2 ff ff    	je     a234 <fwp_hof0.constprop.0+0x524>
    af82:	0f b6 32             	movzbl (%rdx),%esi
    af85:	45 31 ed             	xor    %r13d,%r13d
    af88:	40 80 fe 02          	cmp    $0x2,%sil
    af8c:	0f 85 2a f2 ff ff    	jne    a1bc <fwp_hof0.constprop.0+0x4ac>
    af92:	66 85 c0             	test   %ax,%ax
    af95:	0f 85 4e f2 ff ff    	jne    a1e9 <fwp_hof0.constprop.0+0x4d9>
    af9b:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af9f:	0f 85 40 f2 ff ff    	jne    a1e5 <fwp_hof0.constprop.0+0x4d5>
    afa5:	4c 89 f7             	mov    %r14,%rdi
    afa8:	e8 c3 a7 ff ff       	call   5770 <fwp_rc_forget_slot>
    afad:	e9 33 f2 ff ff       	jmp    a1e5 <fwp_hof0.constprop.0+0x4d5>
    afb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    afb8:	48 89 d7             	mov    %rdx,%rdi
    afbb:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    afc0:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
    afc5:	e8 a6 a7 ff ff       	call   5770 <fwp_rc_forget_slot>
    afca:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    afcf:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    afd4:	e9 2f f9 ff ff       	jmp    a908 <fwp_hof0.constprop.0+0xbf8>
    afd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afe0:	4d 85 ed             	test   %r13,%r13
    afe3:	0f 85 05 f2 ff ff    	jne    a1ee <fwp_hof0.constprop.0+0x4de>
    afe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aff0:	31 d2                	xor    %edx,%edx
    aff2:	e9 d4 f2 ff ff       	jmp    a2cb <fwp_hof0.constprop.0+0x5bb>
    aff7:	be 02 00 00 00       	mov    $0x2,%esi
    affc:	bf 08 00 00 00       	mov    $0x8,%edi
    b001:	e8 aa ae ff ff       	call   5eb0 <fwp_heap_alloc>
    b006:	48 89 c3             	mov    %rax,%rbx
    b009:	31 c9                	xor    %ecx,%ecx
    b00b:	e9 03 fa ff ff       	jmp    aa13 <fwp_hof0.constprop.0+0xd03>
    b010:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    b014:	4d 39 e0             	cmp    %r12,%r8
    b017:	7c 32                	jl     b04b <fwp_hof0.constprop.0+0x133b>
    b019:	4d 85 d2             	test   %r10,%r10
    b01c:	0f 84 2c 06 00 00    	je     b64e <fwp_hof0.constprop.0+0x193e>
    b022:	4c 89 1c 24          	mov    %r11,(%rsp)
    b026:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    b02d:	00 
    b02e:	31 f6                	xor    %esi,%esi
    b030:	4c 89 d7             	mov    %r10,%rdi
    b033:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    b038:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b03d:	e9 e8 f3 ff ff       	jmp    a42a <fwp_hof0.constprop.0+0x71a>
    b042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b048:	4d 89 dc             	mov    %r11,%r12
    b04b:	4d 85 c0             	test   %r8,%r8
    b04e:	4d 0f 44 c4          	cmove  %r12,%r8
    b052:	eb 21                	jmp    b075 <fwp_hof0.constprop.0+0x1365>
    b054:	90                   	nop
    b055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b05c:	00 00 00 00 
    b060:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    b064:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    b06b:	4c 89 e0             	mov    %r12,%rax
    b06e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b072:	49 89 c0             	mov    %rax,%r8
    b075:	4d 39 e0             	cmp    %r12,%r8
    b078:	7c e6                	jl     b060 <fwp_hof0.constprop.0+0x1350>
    b07a:	4d 85 d2             	test   %r10,%r10
    b07d:	0f 84 fd 01 00 00    	je     b280 <fwp_hof0.constprop.0+0x1570>
    b083:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    b08a:	00 
    b08b:	4c 89 d7             	mov    %r10,%rdi
    b08e:	ba 03 00 00 00       	mov    $0x3,%edx
    b093:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
    b098:	4c 89 04 24          	mov    %r8,(%rsp)
    b09c:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    b0a1:	e8 aa a0 ff ff       	call   5150 <ad_raw_realloc>
    b0a6:	4c 8b 04 24          	mov    (%rsp),%r8
    b0aa:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
    b0af:	48 85 c0             	test   %rax,%rax
    b0b2:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    b0b8:	49 89 c2             	mov    %rax,%r10
    b0bb:	0f 84 8f 02 00 00    	je     b350 <fwp_hof0.constprop.0+0x1640>
    b0c1:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
    b0c8:	00 
    b0c9:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
    b0d0:	00 
    b0d1:	4d 85 e4             	test   %r12,%r12
    b0d4:	0f 85 05 04 00 00    	jne    b4df <fwp_hof0.constprop.0+0x17cf>
    b0da:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    b0e1:	4d 85 f6             	test   %r14,%r14
    b0e4:	0f 88 6b f3 ff ff    	js     a455 <fwp_hof0.constprop.0+0x745>
    b0ea:	44 89 f1             	mov    %r14d,%ecx
    b0ed:	e9 4f f3 ff ff       	jmp    a441 <fwp_hof0.constprop.0+0x731>
    b0f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b0f8:	48 8d 3d 21 c4 ff ff 	lea    -0x3bdf(%rip),%rdi        # 7520 <fwp_tape_finish>
    b0ff:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    b104:	e8 07 3d 00 00       	call   ee10 <atexit>
    b109:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    b10e:	85 c0                	test   %eax,%eax
    b110:	0f 85 9a 05 00 00    	jne    b6b0 <fwp_hof0.constprop.0+0x19a0>
    b116:	c7 05 40 7f 00 00 01 	movl   $0x1,0x7f40(%rip)        # 13060 <registered_finish.1>
    b11d:	00 00 00 
    b120:	e9 f8 ed ff ff       	jmp    9f1d <fwp_hof0.constprop.0+0x20d>
    b125:	0f 1f 00             	nopl   (%rax)
    b128:	66 85 c0             	test   %ax,%ax
    b12b:	0f 85 a0 ed ff ff    	jne    9ed1 <fwp_hof0.constprop.0+0x1c1>
    b131:	e9 73 ed ff ff       	jmp    9ea9 <fwp_hof0.constprop.0+0x199>
    b136:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b13d:	00 00 00 
    b140:	4d 39 c3             	cmp    %r8,%r11
    b143:	0f 8f ff fe ff ff    	jg     b048 <fwp_hof0.constprop.0+0x1338>
    b149:	4d 85 db             	test   %r11,%r11
    b14c:	74 12                	je     b160 <fwp_hof0.constprop.0+0x1450>
    b14e:	4d 85 d2             	test   %r10,%r10
    b151:	0f 84 f7 04 00 00    	je     b64e <fwp_hof0.constprop.0+0x193e>
    b157:	4d 85 db             	test   %r11,%r11
    b15a:	0f 85 7c 03 00 00    	jne    b4dc <fwp_hof0.constprop.0+0x17cc>
    b160:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    b167:	e9 e9 f2 ff ff       	jmp    a455 <fwp_hof0.constprop.0+0x745>
    b16c:	0f 1f 40 00          	nopl   0x0(%rax)
    b170:	66 85 c0             	test   %ax,%ax
    b173:	0f 85 43 f4 ff ff    	jne    a5bc <fwp_hof0.constprop.0+0x8ac>
    b179:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b17e:	0f 85 33 f4 ff ff    	jne    a5b7 <fwp_hof0.constprop.0+0x8a7>
    b184:	4c 89 e7             	mov    %r12,%rdi
    b187:	e8 e4 a5 ff ff       	call   5770 <fwp_rc_forget_slot>
    b18c:	e9 26 f4 ff ff       	jmp    a5b7 <fwp_hof0.constprop.0+0x8a7>
    b191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b198:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    b19d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b1a2:	e9 6c f8 ff ff       	jmp    aa13 <fwp_hof0.constprop.0+0xd03>
    b1a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b1ae:	00 00 
    b1b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    b1b5:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    b1bc:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b1c3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    b1c7:	48 29 f0             	sub    %rsi,%rax
    b1ca:	48 c1 e2 10          	shl    $0x10,%rdx
    b1ce:	48 39 d0             	cmp    %rdx,%rax
    b1d1:	73 68                	jae    b23b <fwp_hof0.constprop.0+0x152b>
    b1d3:	49 89 c0             	mov    %rax,%r8
    b1d6:	49 c1 e8 10          	shr    $0x10,%r8
    b1da:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
    b1de:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
    b1e2:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    b1e6:	4d 85 c0             	test   %r8,%r8
    b1e9:	74 50                	je     b23b <fwp_hof0.constprop.0+0x152b>
    b1eb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    b1ef:	41 80 f9 02          	cmp    $0x2,%r9b
    b1f3:	0f 84 37 02 00 00    	je     b430 <fwp_hof0.constprop.0+0x1720>
    b1f9:	41 80 f9 01          	cmp    $0x1,%r9b
    b1fd:	75 3c                	jne    b23b <fwp_hof0.constprop.0+0x152b>
    b1ff:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    b203:	0f b7 c0             	movzwl %ax,%eax
    b206:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    b209:	49 0f af c1          	imul   %r9,%rax
    b20d:	48 c1 e8 20          	shr    $0x20,%rax
    b211:	48 39 f8             	cmp    %rdi,%rax
    b214:	73 25                	jae    b23b <fwp_hof0.constprop.0+0x152b>
    b216:	49 01 c0             	add    %rax,%r8
    b219:	41 80 38 01          	cmpb   $0x1,(%r8)
    b21d:	75 1c                	jne    b23b <fwp_hof0.constprop.0+0x152b>
    b21f:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    b224:	e8 87 a7 ff ff       	call   59b0 <fwp_mem_free>
    b229:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b230:	48 8b b5 b0 13 00 00 	mov    0x13b0(%rbp),%rsi
    b237:	48 c1 e2 10          	shl    $0x10,%rdx
    b23b:	48 89 d8             	mov    %rbx,%rax
    b23e:	48 29 f0             	sub    %rsi,%rax
    b241:	48 39 d0             	cmp    %rdx,%rax
    b244:	0f 83 4f fb ff ff    	jae    ad99 <fwp_hof0.constprop.0+0x1089>
    b24a:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    b24f:	e9 fd f7 ff ff       	jmp    aa51 <fwp_hof0.constprop.0+0xd41>
    b254:	0f 1f 40 00          	nopl   0x0(%rax)
    b258:	66 85 c0             	test   %ax,%ax
    b25b:	0f 85 ae fc ff ff    	jne    af0f <fwp_hof0.constprop.0+0x11ff>
    b261:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b265:	0f 85 a0 fc ff ff    	jne    af0b <fwp_hof0.constprop.0+0x11fb>
    b26b:	4c 89 f7             	mov    %r14,%rdi
    b26e:	e8 fd a4 ff ff       	call   5770 <fwp_rc_forget_slot>
    b273:	e9 93 fc ff ff       	jmp    af0b <fwp_hof0.constprop.0+0x11fb>
    b278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b27f:	00 
    b280:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b287:	ff ff 1f 
    b28a:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    b28e:	48 39 c2             	cmp    %rax,%rdx
    b291:	0f 82 fc 03 00 00    	jb     b693 <fwp_hof0.constprop.0+0x1983>
    b297:	48 8d 05 02 7f 04 00 	lea    0x47f02(%rip),%rax        # 531a0 <ad_raw_blocks>
    b29e:	45 31 ff             	xor    %r15d,%r15d
    b2a1:	eb 32                	jmp    b2d5 <fwp_hof0.constprop.0+0x15c5>
    b2a3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b2aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b2b1:	00 00 00 00 
    b2b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b2bc:	00 00 00 00 
    b2c0:	49 83 c7 01          	add    $0x1,%r15
    b2c4:	48 83 c0 18          	add    $0x18,%rax
    b2c8:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    b2cf:	0f 84 3c 02 00 00    	je     b511 <fwp_hof0.constprop.0+0x1801>
    b2d5:	48 83 38 00          	cmpq   $0x0,(%rax)
    b2d9:	75 e5                	jne    b2c0 <fwp_hof0.constprop.0+0x15b0>
    b2db:	4c 89 c7             	mov    %r8,%rdi
    b2de:	be 08 00 00 00       	mov    $0x8,%esi
    b2e3:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
    b2e8:	4c 89 04 24          	mov    %r8,(%rsp)
    b2ec:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    b2f1:	e8 0a 82 ff ff       	call   3500 <calloc@plt>
    b2f6:	4c 8b 04 24          	mov    (%rsp),%r8
    b2fa:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
    b2ff:	48 8d 15 9a 7e 04 00 	lea    0x47e9a(%rip),%rdx        # 531a0 <ad_raw_blocks>
    b306:	48 85 c0             	test   %rax,%rax
    b309:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    b30f:	49 89 c2             	mov    %rax,%r10
    b312:	74 3c                	je     b350 <fwp_hof0.constprop.0+0x1640>
    b314:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    b318:	48 89 c6             	mov    %rax,%rsi
    b31b:	4c 89 04 24          	mov    %r8,(%rsp)
    b31f:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b323:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    b32a:	00 
    b32b:	b9 03 00 00 00       	mov    $0x3,%ecx
    b330:	e8 8b 88 ff ff       	call   3bc0 <ad_raw_record>
    b335:	4c 8b 04 24          	mov    (%rsp),%r8
    b339:	e9 83 fd ff ff       	jmp    b0c1 <fwp_hof0.constprop.0+0x13b1>
    b33e:	66 90                	xchg   %ax,%ax
    b340:	66 85 c0             	test   %ax,%ax
    b343:	0f 85 94 ea ff ff    	jne    9ddd <fwp_hof0.constprop.0+0xcd>
    b349:	e9 67 ea ff ff       	jmp    9db5 <fwp_hof0.constprop.0+0xa5>
    b34e:	66 90                	xchg   %ax,%ax
    b350:	4d 85 e4             	test   %r12,%r12
    b353:	0f 85 f5 02 00 00    	jne    b64e <fwp_hof0.constprop.0+0x193e>
    b359:	45 31 d2             	xor    %r10d,%r10d
    b35c:	e9 79 fd ff ff       	jmp    b0da <fwp_hof0.constprop.0+0x13ca>
    b361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b368:	66 85 c0             	test   %ax,%ax
    b36b:	0f 85 74 f8 ff ff    	jne    abe5 <fwp_hof0.constprop.0+0xed5>
    b371:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b375:	0f 85 66 f8 ff ff    	jne    abe1 <fwp_hof0.constprop.0+0xed1>
    b37b:	4c 89 ff             	mov    %r15,%rdi
    b37e:	e8 ed a3 ff ff       	call   5770 <fwp_rc_forget_slot>
    b383:	e9 59 f8 ff ff       	jmp    abe1 <fwp_hof0.constprop.0+0xed1>
    b388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b38f:	00 
    b390:	66 85 c0             	test   %ax,%ax
    b393:	0f 85 07 f9 ff ff    	jne    aca0 <fwp_hof0.constprop.0+0xf90>
    b399:	41 0f b6 04 24       	movzbl (%r12),%eax
    b39e:	84 c0                	test   %al,%al
    b3a0:	0f 84 fa f8 ff ff    	je     aca0 <fwp_hof0.constprop.0+0xf90>
    b3a6:	3c 01                	cmp    $0x1,%al
    b3a8:	0f 85 db f8 ff ff    	jne    ac89 <fwp_hof0.constprop.0+0xf79>
    b3ae:	48 89 df             	mov    %rbx,%rdi
    b3b1:	e8 fa a5 ff ff       	call   59b0 <fwp_mem_free>
    b3b6:	e9 e5 f8 ff ff       	jmp    aca0 <fwp_hof0.constprop.0+0xf90>
    b3bb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b3bf:	e9 4b eb ff ff       	jmp    9f0f <fwp_hof0.constprop.0+0x1ff>
    b3c4:	49 8b 04 24          	mov    (%r12),%rax
    b3c8:	48 85 c0             	test   %rax,%rax
    b3cb:	0f 88 26 fc ff ff    	js     aff7 <fwp_hof0.constprop.0+0x12e7>
    b3d1:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    b3d8:	48 8b 34 24          	mov    (%rsp),%rsi
    b3dc:	48 2b b5 b0 13 00 00 	sub    0x13b0(%rbp),%rsi
    b3e3:	48 c1 e7 10          	shl    $0x10,%rdi
    b3e7:	48 39 fe             	cmp    %rdi,%rsi
    b3ea:	0f 83 07 fc ff ff    	jae    aff7 <fwp_hof0.constprop.0+0x12e7>
    b3f0:	48 89 f1             	mov    %rsi,%rcx
    b3f3:	48 c1 e9 10          	shr    $0x10,%rcx
    b3f7:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    b3fb:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    b402:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    b406:	4c 8b 47 20          	mov    0x20(%rdi),%r8
    b40a:	4d 85 c0             	test   %r8,%r8
    b40d:	0f 84 e4 fb ff ff    	je     aff7 <fwp_hof0.constprop.0+0x12e7>
    b413:	48 0f ba f0 3f       	btr    $0x3f,%rax
    b418:	49 89 c6             	mov    %rax,%r14
    b41b:	e9 34 f3 ff ff       	jmp    a754 <fwp_hof0.constprop.0+0xa44>
    b420:	be 58 00 00 00       	mov    $0x58,%esi
    b425:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    b42b:	e9 6a eb ff ff       	jmp    9f9a <fwp_hof0.constprop.0+0x28a>
    b430:	66 85 c0             	test   %ax,%ax
    b433:	0f 85 02 fe ff ff    	jne    b23b <fwp_hof0.constprop.0+0x152b>
    b439:	e9 db fd ff ff       	jmp    b219 <fwp_hof0.constprop.0+0x1509>
    b43e:	4c 89 e2             	mov    %r12,%rdx
    b441:	48 c1 ea 11          	shr    $0x11,%rdx
    b445:	4c 31 e2             	xor    %r12,%rdx
    b448:	48 89 d0             	mov    %rdx,%rax
    b44b:	48 c1 e8 09          	shr    $0x9,%rax
    b44f:	48 31 c2             	xor    %rax,%rdx
    b452:	0f b6 d2             	movzbl %dl,%edx
    b455:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b45c:	00 
    b45d:	48 85 c0             	test   %rax,%rax
    b460:	75 27                	jne    b489 <fwp_hof0.constprop.0+0x1779>
    b462:	eb 6c                	jmp    b4d0 <fwp_hof0.constprop.0+0x17c0>
    b464:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b46a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b471:	00 00 00 00 
    b475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b47c:	00 00 00 00 
    b480:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b484:	48 85 c0             	test   %rax,%rax
    b487:	74 47                	je     b4d0 <fwp_hof0.constprop.0+0x17c0>
    b489:	48 89 c2             	mov    %rax,%rdx
    b48c:	4c 39 20             	cmp    %r12,(%rax)
    b48f:	75 ef                	jne    b480 <fwp_hof0.constprop.0+0x1770>
    b491:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b495:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b499:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b49d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b4a4:	0f 85 25 f6 ff ff    	jne    aacf <fwp_hof0.constprop.0+0xdbf>
    b4aa:	4c 89 e7             	mov    %r12,%rdi
    b4ad:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    b4b2:	e8 b9 a2 ff ff       	call   5770 <fwp_rc_forget_slot>
    b4b7:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b4bc:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    b4c1:	e9 09 f6 ff ff       	jmp    aacf <fwp_hof0.constprop.0+0xdbf>
    b4c6:	e8 85 a1 ff ff       	call   5650 <fwp_rc_wide_dup>
    b4cb:	e9 01 ea ff ff       	jmp    9ed1 <fwp_hof0.constprop.0+0x1c1>
    b4d0:	48 8d 3d 19 45 00 00 	lea    0x4519(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    b4d7:	e8 34 8f ff ff       	call   4410 <fwp_trap>
    b4dc:	4d 89 dc             	mov    %r11,%r12
    b4df:	4c 89 d7             	mov    %r10,%rdi
    b4e2:	31 f6                	xor    %esi,%esi
    b4e4:	4c 89 1c 24          	mov    %r11,(%rsp)
    b4e8:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    b4ed:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    b4f4:	00 
    b4f5:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b4fa:	e8 a1 7f ff ff       	call   34a0 <memset@plt>
    b4ff:	4c 8b 1c 24          	mov    (%rsp),%r11
    b503:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b509:	49 89 c2             	mov    %rax,%r10
    b50c:	e9 d0 fb ff ff       	jmp    b0e1 <fwp_hof0.constprop.0+0x13d1>
    b511:	48 8d 3d fc 3b 00 00 	lea    0x3bfc(%rip),%rdi        # f114 <_IO_stdin_used+0x114>
    b518:	e8 a3 8a ff ff       	call   3fc0 <ad_raw_fail>
    b51d:	e8 2e a1 ff ff       	call   5650 <fwp_rc_wide_dup>
    b522:	e9 b6 e8 ff ff       	jmp    9ddd <fwp_hof0.constprop.0+0xcd>
    b527:	4c 89 e0             	mov    %r12,%rax
    b52a:	48 c1 e8 11          	shr    $0x11,%rax
    b52e:	4c 31 e0             	xor    %r12,%rax
    b531:	48 89 c2             	mov    %rax,%rdx
    b534:	48 c1 ea 09          	shr    $0x9,%rdx
    b538:	48 31 d0             	xor    %rdx,%rax
    b53b:	0f b6 d0             	movzbl %al,%edx
    b53e:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b545:	00 
    b546:	48 85 c0             	test   %rax,%rax
    b549:	75 22                	jne    b56d <fwp_hof0.constprop.0+0x185d>
    b54b:	eb 83                	jmp    b4d0 <fwp_hof0.constprop.0+0x17c0>
    b54d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b554:	00 
    b555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b55c:	00 00 00 00 
    b560:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b564:	48 85 c0             	test   %rax,%rax
    b567:	0f 84 63 ff ff ff    	je     b4d0 <fwp_hof0.constprop.0+0x17c0>
    b56d:	48 89 c2             	mov    %rax,%rdx
    b570:	4c 3b 20             	cmp    (%rax),%r12
    b573:	75 eb                	jne    b560 <fwp_hof0.constprop.0+0x1850>
    b575:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b579:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b57d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b581:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b588:	0f 85 12 f7 ff ff    	jne    aca0 <fwp_hof0.constprop.0+0xf90>
    b58e:	4c 89 e7             	mov    %r12,%rdi
    b591:	e8 da a1 ff ff       	call   5770 <fwp_rc_forget_slot>
    b596:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b59b:	e9 00 f7 ff ff       	jmp    aca0 <fwp_hof0.constprop.0+0xf90>
    b5a0:	45 31 ff             	xor    %r15d,%r15d
    b5a3:	e9 2d f3 ff ff       	jmp    a8d5 <fwp_hof0.constprop.0+0xbc5>
    b5a8:	48 8d 3d 69 44 00 00 	lea    0x4469(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    b5af:	e8 5c 8e ff ff       	call   4410 <fwp_trap>
    b5b4:	48 8d 3d 09 3c 00 00 	lea    0x3c09(%rip),%rdi        # f1c4 <_IO_stdin_used+0x1c4>
    b5bb:	e8 50 8e ff ff       	call   4410 <fwp_trap>
    b5c0:	48 8d 3d 29 45 00 00 	lea    0x4529(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    b5c7:	e8 44 8e ff ff       	call   4410 <fwp_trap>
    b5cc:	31 db                	xor    %ebx,%ebx
    b5ce:	31 c9                	xor    %ecx,%ecx
    b5d0:	e9 3e f4 ff ff       	jmp    aa13 <fwp_hof0.constprop.0+0xd03>
    b5d5:	48 8d 3d a2 3c 00 00 	lea    0x3ca2(%rip),%rdi        # f27e <_IO_stdin_used+0x27e>
    b5dc:	e8 2f 8e ff ff       	call   4410 <fwp_trap>
    b5e1:	48 8d 3d cc 3c 00 00 	lea    0x3ccc(%rip),%rdi        # f2b4 <_IO_stdin_used+0x2b4>
    b5e8:	e8 23 8e ff ff       	call   4410 <fwp_trap>
    b5ed:	48 8d 3d f9 3b 00 00 	lea    0x3bf9(%rip),%rdi        # f1ed <_IO_stdin_used+0x1ed>
    b5f4:	e8 17 8e ff ff       	call   4410 <fwp_trap>
    b5f9:	48 8d 3d 60 44 00 00 	lea    0x4460(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b600:	e8 0b 8e ff ff       	call   4410 <fwp_trap>
    b605:	0f 1f 00             	nopl   (%rax)
    b608:	48 8d 3d 09 45 00 00 	lea    0x4509(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b60f:	e8 fc 8d ff ff       	call   4410 <fwp_trap>
    b614:	48 8b 0d 25 7a 00 00 	mov    0x7a25(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b61b:	ba 13 00 00 00       	mov    $0x13,%edx
    b620:	be 01 00 00 00       	mov    $0x1,%esi
    b625:	48 8d 3d dc 39 00 00 	lea    0x39dc(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b62c:	e8 0f 80 ff ff       	call   3640 <fwrite@plt>
    b631:	31 ff                	xor    %edi,%edi
    b633:	e8 58 7f ff ff       	call   3590 <fflush@plt>
    b638:	bf 66 00 00 00       	mov    $0x66,%edi
    b63d:	e8 1e 80 ff ff       	call   3660 <_Exit@plt>
    b642:	48 8d 3d 77 44 00 00 	lea    0x4477(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    b649:	e8 c2 8d ff ff       	call   4410 <fwp_trap>
    b64e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    b655:	00 
    b656:	4c 89 ef             	mov    %r13,%rdi
    b659:	48 89 05 38 1e 06 00 	mov    %rax,0x61e38(%rip)        # 6d498 <fwp_cleanups>
    b660:	e8 bb 9b ff ff       	call   5220 <fwp_tape_buffers_release>
    b665:	ba 13 00 00 00       	mov    $0x13,%edx
    b66a:	48 8b 0d cf 79 00 00 	mov    0x79cf(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b671:	be 01 00 00 00       	mov    $0x1,%esi
    b676:	48 8d 3d 8b 39 00 00 	lea    0x398b(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b67d:	e8 be 7f ff ff       	call   3640 <fwrite@plt>
    b682:	31 ff                	xor    %edi,%edi
    b684:	e8 07 7f ff ff       	call   3590 <fflush@plt>
    b689:	bf 66 00 00 00       	mov    $0x66,%edi
    b68e:	e8 cd 7f ff ff       	call   3660 <_Exit@plt>
    b693:	48 8d 3d fe 3b 00 00 	lea    0x3bfe(%rip),%rdi        # f298 <_IO_stdin_used+0x298>
    b69a:	e8 21 89 ff ff       	call   3fc0 <ad_raw_fail>
    b69f:	e8 9c 7d ff ff       	call   3440 <__stack_chk_fail@plt>
    b6a4:	48 8d 3d 19 3c 00 00 	lea    0x3c19(%rip),%rdi        # f2c4 <_IO_stdin_used+0x2c4>
    b6ab:	e8 60 8d ff ff       	call   4410 <fwp_trap>
    b6b0:	48 8b 0d 89 79 00 00 	mov    0x7989(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b6b7:	ba 13 00 00 00       	mov    $0x13,%edx
    b6bc:	be 01 00 00 00       	mov    $0x1,%esi
    b6c1:	48 8d 3d 40 39 00 00 	lea    0x3940(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b6c8:	e8 73 7f ff ff       	call   3640 <fwrite@plt>
    b6cd:	31 ff                	xor    %edi,%edi
    b6cf:	e8 bc 7e ff ff       	call   3590 <fflush@plt>
    b6d4:	bf 66 00 00 00       	mov    $0x66,%edi
    b6d9:	e8 82 7f ff ff       	call   3660 <_Exit@plt>
    b6de:	66 90                	xchg   %ax,%ax

000000000000b6e0 <f0>:
    b6e0:	41 56                	push   %r14
    b6e2:	4c 8d 35 17 01 06 00 	lea    0x60117(%rip),%r14        # 6b800 <fwp_heap>
    b6e9:	41 55                	push   %r13
    b6eb:	41 54                	push   %r12
    b6ed:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b6f3:	55                   	push   %rbp
    b6f4:	53                   	push   %rbx
    b6f5:	31 db                	xor    %ebx,%ebx
    b6f7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b6fe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b705:	00 00 
    b707:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b70e:	00 
    b70f:	31 c0                	xor    %eax,%eax
    b711:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b718:	00 
    b719:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b720:	00 00 
    b722:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b727:	48 8d 05 42 cc ff ff 	lea    -0x33be(%rip),%rax        # 8370 <fwp_drop1>
    b72e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b733:	48 8b 05 5e 1d 06 00 	mov    0x61d5e(%rip),%rax        # 6d498 <fwp_cleanups>
    b73a:	48 89 25 57 1d 06 00 	mov    %rsp,0x61d57(%rip)        # 6d498 <fwp_cleanups>
    b741:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b745:	48 89 04 24          	mov    %rax,(%rsp)
    b749:	48 8d 05 40 84 ff ff 	lea    -0x7bc0(%rip),%rax        # 3b90 <fwp_range_release>
    b750:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b755:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b75a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b75f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b764:	eb 47                	jmp    b7ad <f0+0xcd>
    b766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b76d:	00 00 00 
    b770:	80 f9 01             	cmp    $0x1,%cl
    b773:	75 29                	jne    b79e <f0+0xbe>
    b775:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b778:	0f b7 c0             	movzwl %ax,%eax
    b77b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b77e:	48 0f af c1          	imul   %rcx,%rax
    b782:	48 c1 e8 20          	shr    $0x20,%rax
    b786:	48 39 d0             	cmp    %rdx,%rax
    b789:	73 13                	jae    b79e <f0+0xbe>
    b78b:	49 01 c5             	add    %rax,%r13
    b78e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b793:	0f 84 c7 27 00 00    	je     df60 <f0+0x2880>
    b799:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b79e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b7a3:	49 83 ec 01          	sub    $0x1,%r12
    b7a7:	0f 82 83 00 00 00    	jb     b830 <f0+0x150>
    b7ad:	48 89 ee             	mov    %rbp,%rsi
    b7b0:	bf 01 00 00 00       	mov    $0x1,%edi
    b7b5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b7bc:	00 
    b7bd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b7c2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b7c9:	00 
    b7ca:	e8 d1 a8 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    b7cf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b7d6:	48 89 c3             	mov    %rax,%rbx
    b7d9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b7e0:	48 c1 e2 10          	shl    $0x10,%rdx
    b7e4:	48 39 d0             	cmp    %rdx,%rax
    b7e7:	73 b5                	jae    b79e <f0+0xbe>
    b7e9:	48 89 c2             	mov    %rax,%rdx
    b7ec:	48 c1 ea 10          	shr    $0x10,%rdx
    b7f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7f4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b7fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7ff:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b803:	4d 85 ed             	test   %r13,%r13
    b806:	74 96                	je     b79e <f0+0xbe>
    b808:	0f b6 0a             	movzbl (%rdx),%ecx
    b80b:	80 f9 02             	cmp    $0x2,%cl
    b80e:	0f 85 5c ff ff ff    	jne    b770 <f0+0x90>
    b814:	66 85 c0             	test   %ax,%ax
    b817:	0f 84 71 ff ff ff    	je     b78e <f0+0xae>
    b81d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b822:	49 83 ec 01          	sub    $0x1,%r12
    b826:	73 85                	jae    b7ad <f0+0xcd>
    b828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b82f:	00 
    b830:	48 8b 04 24          	mov    (%rsp),%rax
    b834:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b839:	bf 01 00 00 00       	mov    $0x1,%edi
    b83e:	66 0f 6f 05 ea 45 00 	movdqa 0x45ea(%rip),%xmm0        # fe30 <msg.4+0xf0>
    b845:	00 
    b846:	48 89 05 4b 1c 06 00 	mov    %rax,0x61c4b(%rip)        # 6d498 <fwp_cleanups>
    b84d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b852:	e8 49 a8 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    b857:	48 8b 15 7a 13 06 00 	mov    0x6137a(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    b85e:	49 89 c5             	mov    %rax,%r13
    b861:	48 2b 05 48 13 06 00 	sub    0x61348(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    b868:	48 c1 e2 10          	shl    $0x10,%rdx
    b86c:	48 39 d0             	cmp    %rdx,%rax
    b86f:	73 59                	jae    b8ca <f0+0x1ea>
    b871:	48 89 c2             	mov    %rax,%rdx
    b874:	48 c1 ea 10          	shr    $0x10,%rdx
    b878:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b87c:	48 8b 15 75 13 06 00 	mov    0x61375(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    b883:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b887:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b88b:	4d 85 e4             	test   %r12,%r12
    b88e:	74 3a                	je     b8ca <f0+0x1ea>
    b890:	0f b6 0a             	movzbl (%rdx),%ecx
    b893:	80 f9 02             	cmp    $0x2,%cl
    b896:	0f 84 74 27 00 00    	je     e010 <f0+0x2930>
    b89c:	80 f9 01             	cmp    $0x1,%cl
    b89f:	75 29                	jne    b8ca <f0+0x1ea>
    b8a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8a4:	0f b7 c0             	movzwl %ax,%eax
    b8a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8aa:	48 0f af c1          	imul   %rcx,%rax
    b8ae:	48 c1 e8 20          	shr    $0x20,%rax
    b8b2:	48 39 d0             	cmp    %rdx,%rax
    b8b5:	73 13                	jae    b8ca <f0+0x1ea>
    b8b7:	49 01 c4             	add    %rax,%r12
    b8ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b8bf:	0f 84 26 29 00 00    	je     e1eb <f0+0x2b0b>
    b8c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b8ca:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b8cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b8d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b8e0:	00 f0 3f 
    b8e3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b8e8:	e8 b3 a7 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    b8ed:	48 8b 15 e4 12 06 00 	mov    0x612e4(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    b8f4:	49 89 c5             	mov    %rax,%r13
    b8f7:	48 2b 05 b2 12 06 00 	sub    0x612b2(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    b8fe:	48 c1 e2 10          	shl    $0x10,%rdx
    b902:	48 39 d0             	cmp    %rdx,%rax
    b905:	73 59                	jae    b960 <f0+0x280>
    b907:	48 89 c2             	mov    %rax,%rdx
    b90a:	48 c1 ea 10          	shr    $0x10,%rdx
    b90e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b912:	48 8b 15 df 12 06 00 	mov    0x612df(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    b919:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b91d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b921:	4d 85 e4             	test   %r12,%r12
    b924:	74 3a                	je     b960 <f0+0x280>
    b926:	0f b6 0a             	movzbl (%rdx),%ecx
    b929:	80 f9 02             	cmp    $0x2,%cl
    b92c:	0f 84 ce 26 00 00    	je     e000 <f0+0x2920>
    b932:	80 f9 01             	cmp    $0x1,%cl
    b935:	75 29                	jne    b960 <f0+0x280>
    b937:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b93a:	0f b7 c0             	movzwl %ax,%eax
    b93d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b940:	48 0f af c1          	imul   %rcx,%rax
    b944:	48 c1 e8 20          	shr    $0x20,%rax
    b948:	48 39 d0             	cmp    %rdx,%rax
    b94b:	73 13                	jae    b960 <f0+0x280>
    b94d:	49 01 c4             	add    %rax,%r12
    b950:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b955:	0f 84 9d 28 00 00    	je     e1f8 <f0+0x2b18>
    b95b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b960:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b965:	bf 01 00 00 00       	mov    $0x1,%edi
    b96a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b96f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b976:	33 f3 bf 
    b979:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b97e:	e8 1d a7 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    b983:	48 8b 15 4e 12 06 00 	mov    0x6124e(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    b98a:	49 89 c5             	mov    %rax,%r13
    b98d:	48 2b 05 1c 12 06 00 	sub    0x6121c(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    b994:	48 c1 e2 10          	shl    $0x10,%rdx
    b998:	48 39 d0             	cmp    %rdx,%rax
    b99b:	73 59                	jae    b9f6 <f0+0x316>
    b99d:	48 89 c2             	mov    %rax,%rdx
    b9a0:	48 c1 ea 10          	shr    $0x10,%rdx
    b9a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9a8:	48 8b 15 49 12 06 00 	mov    0x61249(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    b9af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b9b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b9b7:	4d 85 e4             	test   %r12,%r12
    b9ba:	74 3a                	je     b9f6 <f0+0x316>
    b9bc:	0f b6 0a             	movzbl (%rdx),%ecx
    b9bf:	80 f9 02             	cmp    $0x2,%cl
    b9c2:	0f 84 28 26 00 00    	je     dff0 <f0+0x2910>
    b9c8:	80 f9 01             	cmp    $0x1,%cl
    b9cb:	75 29                	jne    b9f6 <f0+0x316>
    b9cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b9d0:	0f b7 c0             	movzwl %ax,%eax
    b9d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b9d6:	48 0f af c1          	imul   %rcx,%rax
    b9da:	48 c1 e8 20          	shr    $0x20,%rax
    b9de:	48 39 d0             	cmp    %rdx,%rax
    b9e1:	73 13                	jae    b9f6 <f0+0x316>
    b9e3:	49 01 c4             	add    %rax,%r12
    b9e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b9eb:	0f 84 14 28 00 00    	je     e205 <f0+0x2b25>
    b9f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b9f6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b9fb:	bf 01 00 00 00       	mov    $0x1,%edi
    ba00:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ba05:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ba0c:	00 f0 3f 
    ba0f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ba14:	e8 87 a6 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    ba19:	48 8b 15 b8 11 06 00 	mov    0x611b8(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    ba20:	49 89 c5             	mov    %rax,%r13
    ba23:	48 2b 05 86 11 06 00 	sub    0x61186(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    ba2a:	48 c1 e2 10          	shl    $0x10,%rdx
    ba2e:	48 39 d0             	cmp    %rdx,%rax
    ba31:	73 59                	jae    ba8c <f0+0x3ac>
    ba33:	48 89 c2             	mov    %rax,%rdx
    ba36:	48 c1 ea 10          	shr    $0x10,%rdx
    ba3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba3e:	48 8b 15 b3 11 06 00 	mov    0x611b3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    ba45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba49:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ba4d:	4d 85 e4             	test   %r12,%r12
    ba50:	74 3a                	je     ba8c <f0+0x3ac>
    ba52:	0f b6 0a             	movzbl (%rdx),%ecx
    ba55:	80 f9 02             	cmp    $0x2,%cl
    ba58:	0f 84 f2 25 00 00    	je     e050 <f0+0x2970>
    ba5e:	80 f9 01             	cmp    $0x1,%cl
    ba61:	75 29                	jne    ba8c <f0+0x3ac>
    ba63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba66:	0f b7 c0             	movzwl %ax,%eax
    ba69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba6c:	48 0f af c1          	imul   %rcx,%rax
    ba70:	48 c1 e8 20          	shr    $0x20,%rax
    ba74:	48 39 d0             	cmp    %rdx,%rax
    ba77:	73 13                	jae    ba8c <f0+0x3ac>
    ba79:	49 01 c4             	add    %rax,%r12
    ba7c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ba81:	0f 84 8b 27 00 00    	je     e212 <f0+0x2b32>
    ba87:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ba8c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ba93:	33 f3 bf 
    ba96:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ba9d:	00 
    ba9e:	bf 01 00 00 00       	mov    $0x1,%edi
    baa3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    baaa:	00 
    baab:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    bab2:	00 
    bab3:	e8 e8 a5 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bab8:	48 8b 15 19 11 06 00 	mov    0x61119(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    babf:	49 89 c5             	mov    %rax,%r13
    bac2:	48 2b 05 e7 10 06 00 	sub    0x610e7(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    bac9:	48 c1 e2 10          	shl    $0x10,%rdx
    bacd:	48 39 d0             	cmp    %rdx,%rax
    bad0:	73 59                	jae    bb2b <f0+0x44b>
    bad2:	48 89 c2             	mov    %rax,%rdx
    bad5:	48 c1 ea 10          	shr    $0x10,%rdx
    bad9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    badd:	48 8b 15 14 11 06 00 	mov    0x61114(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    bae4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bae8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    baec:	4d 85 e4             	test   %r12,%r12
    baef:	74 3a                	je     bb2b <f0+0x44b>
    baf1:	0f b6 0a             	movzbl (%rdx),%ecx
    baf4:	80 f9 02             	cmp    $0x2,%cl
    baf7:	0f 84 43 25 00 00    	je     e040 <f0+0x2960>
    bafd:	80 f9 01             	cmp    $0x1,%cl
    bb00:	75 29                	jne    bb2b <f0+0x44b>
    bb02:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb05:	0f b7 c0             	movzwl %ax,%eax
    bb08:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb0b:	48 0f af c1          	imul   %rcx,%rax
    bb0f:	48 c1 e8 20          	shr    $0x20,%rax
    bb13:	48 39 d0             	cmp    %rdx,%rax
    bb16:	73 13                	jae    bb2b <f0+0x44b>
    bb18:	49 01 c4             	add    %rax,%r12
    bb1b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bb20:	0f 84 f9 26 00 00    	je     e21f <f0+0x2b3f>
    bb26:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bb2b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    bb32:	00 f0 3f 
    bb35:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    bb3c:	00 
    bb3d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb42:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    bb49:	00 
    bb4a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    bb51:	00 
    bb52:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    bb59:	33 f3 bf 
    bb5c:	e8 3f a5 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bb61:	48 89 c7             	mov    %rax,%rdi
    bb64:	e8 87 b3 ff ff       	call   6ef0 <fwp_rc_fresh>
    bb69:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    bb70:	00 
    bb71:	bf 01 00 00 00       	mov    $0x1,%edi
    bb76:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    bb7d:	00 
    bb7e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    bb85:	00 
    bb86:	e8 15 a5 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bb8b:	48 89 c7             	mov    %rax,%rdi
    bb8e:	e8 5d b3 ff ff       	call   6ef0 <fwp_rc_fresh>
    bb93:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    bb9a:	00 
    bb9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bba0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    bba7:	00 
    bba8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    bbaf:	00 
    bbb0:	e8 eb a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bbb5:	48 89 c7             	mov    %rax,%rdi
    bbb8:	e8 33 b3 ff ff       	call   6ef0 <fwp_rc_fresh>
    bbbd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    bbc4:	00 
    bbc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbca:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    bbd1:	00 
    bbd2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    bbd9:	00 
    bbda:	e8 c1 a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bbdf:	48 89 c7             	mov    %rax,%rdi
    bbe2:	e8 09 b3 ff ff       	call   6ef0 <fwp_rc_fresh>
    bbe7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    bbee:	00 
    bbef:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    bbfb:	00 
    bbfc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    bc03:	00 
    bc04:	e8 97 a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bc09:	48 89 c7             	mov    %rax,%rdi
    bc0c:	e8 df b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bc11:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    bc18:	00 
    bc19:	bf 01 00 00 00       	mov    $0x1,%edi
    bc1e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    bc25:	00 
    bc26:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    bc2d:	00 
    bc2e:	e8 6d a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bc33:	48 89 c7             	mov    %rax,%rdi
    bc36:	e8 b5 b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bc3b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    bc42:	00 
    bc43:	bf 01 00 00 00       	mov    $0x1,%edi
    bc48:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    bc4f:	00 
    bc50:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bc57:	00 
    bc58:	e8 43 a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bc5d:	48 89 c7             	mov    %rax,%rdi
    bc60:	e8 8b b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bc65:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bc6c:	00 
    bc6d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc72:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bc79:	00 
    bc7a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bc81:	00 
    bc82:	e8 19 a4 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bc87:	48 89 c7             	mov    %rax,%rdi
    bc8a:	e8 61 b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bc8f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    bc96:	00 
    bc97:	bf 01 00 00 00       	mov    $0x1,%edi
    bc9c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bca3:	00 
    bca4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bcab:	00 
    bcac:	e8 ef a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bcb1:	48 89 c7             	mov    %rax,%rdi
    bcb4:	e8 37 b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bcb9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bcc0:	00 
    bcc1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bccd:	00 
    bcce:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bcd5:	00 
    bcd6:	e8 c5 a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bcdb:	48 89 c7             	mov    %rax,%rdi
    bcde:	e8 0d b2 ff ff       	call   6ef0 <fwp_rc_fresh>
    bce3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bcea:	00 
    bceb:	bf 01 00 00 00       	mov    $0x1,%edi
    bcf0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bcf7:	00 
    bcf8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bcff:	00 
    bd00:	e8 9b a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bd05:	48 89 c7             	mov    %rax,%rdi
    bd08:	e8 e3 b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bd0d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bd14:	00 
    bd15:	bf 01 00 00 00       	mov    $0x1,%edi
    bd1a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bd21:	00 
    bd22:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bd29:	00 
    bd2a:	e8 71 a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bd2f:	48 89 c7             	mov    %rax,%rdi
    bd32:	e8 b9 b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bd37:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bd3e:	00 
    bd3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd44:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bd4b:	00 
    bd4c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bd53:	00 
    bd54:	e8 47 a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bd59:	48 89 c7             	mov    %rax,%rdi
    bd5c:	e8 8f b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bd61:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bd68:	00 
    bd69:	bf 01 00 00 00       	mov    $0x1,%edi
    bd6e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bd75:	00 
    bd76:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bd7d:	00 
    bd7e:	e8 1d a3 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bd83:	48 89 c7             	mov    %rax,%rdi
    bd86:	e8 65 b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bd8b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bd92:	00 
    bd93:	bf 01 00 00 00       	mov    $0x1,%edi
    bd98:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bd9f:	00 
    bda0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bda7:	00 
    bda8:	e8 f3 a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bdad:	48 89 c7             	mov    %rax,%rdi
    bdb0:	e8 3b b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bdb5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bdbc:	00 
    bdbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdc2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bdc9:	00 
    bdca:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bdd1:	00 
    bdd2:	e8 c9 a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bdd7:	48 89 c7             	mov    %rax,%rdi
    bdda:	e8 11 b1 ff ff       	call   6ef0 <fwp_rc_fresh>
    bddf:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bde6:	00 
    bde7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdec:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bdf3:	00 
    bdf4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bdfb:	00 
    bdfc:	e8 9f a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    be01:	48 89 c7             	mov    %rax,%rdi
    be04:	e8 e7 b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    be09:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    be10:	00 
    be11:	bf 01 00 00 00       	mov    $0x1,%edi
    be16:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    be1d:	00 
    be1e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    be25:	00 
    be26:	e8 75 a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    be2b:	48 89 c7             	mov    %rax,%rdi
    be2e:	e8 bd b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    be33:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    be3a:	00 
    be3b:	bf 01 00 00 00       	mov    $0x1,%edi
    be40:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    be47:	00 
    be48:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    be4f:	00 
    be50:	e8 4b a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    be55:	48 89 c7             	mov    %rax,%rdi
    be58:	e8 93 b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    be5d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    be64:	00 
    be65:	bf 01 00 00 00       	mov    $0x1,%edi
    be6a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    be71:	00 
    be72:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    be79:	00 
    be7a:	e8 21 a2 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    be7f:	48 89 c7             	mov    %rax,%rdi
    be82:	e8 69 b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    be87:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    be8e:	00 
    be8f:	bf 01 00 00 00       	mov    $0x1,%edi
    be94:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    be9b:	00 
    be9c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bea3:	00 
    bea4:	e8 f7 a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bea9:	48 89 c7             	mov    %rax,%rdi
    beac:	e8 3f b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    beb1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    beb8:	00 
    beb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bebe:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bec5:	00 
    bec6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    becd:	00 
    bece:	e8 cd a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bed3:	48 89 c7             	mov    %rax,%rdi
    bed6:	e8 15 b0 ff ff       	call   6ef0 <fwp_rc_fresh>
    bedb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bee2:	00 
    bee3:	bf 01 00 00 00       	mov    $0x1,%edi
    bee8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    beef:	00 
    bef0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bef7:	00 
    bef8:	e8 a3 a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    befd:	48 89 c7             	mov    %rax,%rdi
    bf00:	e8 eb af ff ff       	call   6ef0 <fwp_rc_fresh>
    bf05:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bf0c:	00 
    bf0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf12:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bf19:	00 
    bf1a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bf21:	00 
    bf22:	e8 79 a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bf27:	48 89 c7             	mov    %rax,%rdi
    bf2a:	e8 c1 af ff ff       	call   6ef0 <fwp_rc_fresh>
    bf2f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bf36:	00 
    bf37:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bf43:	00 
    bf44:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bf4b:	00 
    bf4c:	e8 4f a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bf51:	48 89 c7             	mov    %rax,%rdi
    bf54:	e8 97 af ff ff       	call   6ef0 <fwp_rc_fresh>
    bf59:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bf60:	00 
    bf61:	bf 01 00 00 00       	mov    $0x1,%edi
    bf66:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bf6d:	00 
    bf6e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bf75:	00 
    bf76:	e8 25 a1 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bf7b:	48 89 c7             	mov    %rax,%rdi
    bf7e:	e8 6d af ff ff       	call   6ef0 <fwp_rc_fresh>
    bf83:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bf8a:	00 
    bf8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf90:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bf97:	00 
    bf98:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bf9f:	00 
    bfa0:	e8 fb a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bfa5:	48 89 c7             	mov    %rax,%rdi
    bfa8:	e8 43 af ff ff       	call   6ef0 <fwp_rc_fresh>
    bfad:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bfb4:	00 
    bfb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfba:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bfc1:	00 
    bfc2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bfc9:	00 
    bfca:	e8 d1 a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bfcf:	48 89 c7             	mov    %rax,%rdi
    bfd2:	e8 19 af ff ff       	call   6ef0 <fwp_rc_fresh>
    bfd7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bfde:	00 
    bfdf:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bfeb:	00 
    bfec:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bff3:	00 
    bff4:	e8 a7 a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    bff9:	48 89 c7             	mov    %rax,%rdi
    bffc:	e8 ef ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c001:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c008:	00 
    c009:	bf 01 00 00 00       	mov    $0x1,%edi
    c00e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    c015:	00 
    c016:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c01d:	00 
    c01e:	e8 7d a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c023:	48 89 c7             	mov    %rax,%rdi
    c026:	e8 c5 ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c02b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c032:	00 
    c033:	bf 01 00 00 00       	mov    $0x1,%edi
    c038:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    c03f:	00 
    c040:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c047:	00 
    c048:	e8 53 a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c04d:	48 89 c7             	mov    %rax,%rdi
    c050:	e8 9b ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c055:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c05c:	00 
    c05d:	bf 01 00 00 00       	mov    $0x1,%edi
    c062:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    c069:	00 
    c06a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c071:	00 
    c072:	e8 29 a0 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c077:	48 89 c7             	mov    %rax,%rdi
    c07a:	e8 71 ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c07f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c086:	00 
    c087:	bf 01 00 00 00       	mov    $0x1,%edi
    c08c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    c093:	00 
    c094:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c09b:	00 
    c09c:	e8 ff 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c0a1:	48 89 c7             	mov    %rax,%rdi
    c0a4:	e8 47 ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c0a9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c0b0:	00 
    c0b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    c0bd:	00 
    c0be:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c0c5:	00 
    c0c6:	e8 d5 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c0cb:	48 89 c7             	mov    %rax,%rdi
    c0ce:	e8 1d ae ff ff       	call   6ef0 <fwp_rc_fresh>
    c0d3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c0da:	00 
    c0db:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    c0e7:	00 
    c0e8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c0ef:	00 
    c0f0:	e8 ab 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c0f5:	48 89 c7             	mov    %rax,%rdi
    c0f8:	e8 f3 ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c0fd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c104:	00 
    c105:	bf 01 00 00 00       	mov    $0x1,%edi
    c10a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    c111:	00 
    c112:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c119:	00 
    c11a:	e8 81 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c11f:	48 89 c7             	mov    %rax,%rdi
    c122:	e8 c9 ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c127:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c12e:	00 
    c12f:	bf 01 00 00 00       	mov    $0x1,%edi
    c134:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    c13b:	00 
    c13c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c143:	00 
    c144:	e8 57 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c149:	48 89 c7             	mov    %rax,%rdi
    c14c:	e8 9f ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c151:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c158:	00 
    c159:	bf 01 00 00 00       	mov    $0x1,%edi
    c15e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    c165:	00 
    c166:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c16d:	00 
    c16e:	e8 2d 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c173:	48 89 c7             	mov    %rax,%rdi
    c176:	e8 75 ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c17b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c182:	00 
    c183:	bf 01 00 00 00       	mov    $0x1,%edi
    c188:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    c18f:	00 
    c190:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c197:	00 
    c198:	e8 03 9f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c19d:	48 89 c7             	mov    %rax,%rdi
    c1a0:	e8 4b ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c1a5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c1ac:	00 
    c1ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c1b9:	00 
    c1ba:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c1c1:	00 
    c1c2:	e8 d9 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c1c7:	48 89 c7             	mov    %rax,%rdi
    c1ca:	e8 21 ad ff ff       	call   6ef0 <fwp_rc_fresh>
    c1cf:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c1d6:	00 
    c1d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1dc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c1e3:	00 
    c1e4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c1eb:	00 
    c1ec:	e8 af 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c1f1:	48 89 c7             	mov    %rax,%rdi
    c1f4:	e8 f7 ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c1f9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c200:	00 
    c201:	bf 01 00 00 00       	mov    $0x1,%edi
    c206:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c20d:	00 
    c20e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c215:	00 
    c216:	e8 85 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c21b:	48 89 c7             	mov    %rax,%rdi
    c21e:	e8 cd ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c223:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c22a:	00 
    c22b:	bf 01 00 00 00       	mov    $0x1,%edi
    c230:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c237:	00 
    c238:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c23f:	00 
    c240:	e8 5b 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c245:	48 89 c7             	mov    %rax,%rdi
    c248:	e8 a3 ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c24d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c254:	00 
    c255:	bf 01 00 00 00       	mov    $0x1,%edi
    c25a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c261:	00 
    c262:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c269:	00 
    c26a:	e8 31 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c26f:	48 89 c7             	mov    %rax,%rdi
    c272:	e8 79 ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c277:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c27e:	00 
    c27f:	bf 01 00 00 00       	mov    $0x1,%edi
    c284:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c28b:	00 
    c28c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c293:	00 
    c294:	e8 07 9e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c299:	48 89 c7             	mov    %rax,%rdi
    c29c:	e8 4f ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c2a1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c2a8:	00 
    c2a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ae:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c2b5:	00 
    c2b6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c2bd:	00 
    c2be:	e8 dd 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c2c3:	48 89 c7             	mov    %rax,%rdi
    c2c6:	e8 25 ac ff ff       	call   6ef0 <fwp_rc_fresh>
    c2cb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c2d2:	00 
    c2d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c2df:	00 
    c2e0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c2e7:	00 
    c2e8:	e8 b3 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c2ed:	48 89 c7             	mov    %rax,%rdi
    c2f0:	e8 fb ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c2f5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c2fc:	00 
    c2fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c302:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c309:	00 
    c30a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c311:	00 
    c312:	e8 89 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c317:	48 89 c7             	mov    %rax,%rdi
    c31a:	e8 d1 ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c31f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c326:	00 
    c327:	bf 01 00 00 00       	mov    $0x1,%edi
    c32c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c333:	00 
    c334:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c33b:	00 
    c33c:	e8 5f 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c341:	48 89 c7             	mov    %rax,%rdi
    c344:	e8 a7 ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c349:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c350:	00 
    c351:	bf 01 00 00 00       	mov    $0x1,%edi
    c356:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c35d:	00 
    c35e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c365:	00 
    c366:	e8 35 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c36b:	48 89 c7             	mov    %rax,%rdi
    c36e:	e8 7d ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c373:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c37a:	00 
    c37b:	bf 01 00 00 00       	mov    $0x1,%edi
    c380:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c387:	00 
    c388:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c38f:	00 
    c390:	e8 0b 9d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c395:	48 89 c7             	mov    %rax,%rdi
    c398:	e8 53 ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c39d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c3a4:	00 
    c3a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3aa:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c3b1:	00 
    c3b2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c3b9:	00 
    c3ba:	e8 e1 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c3bf:	48 89 c7             	mov    %rax,%rdi
    c3c2:	e8 29 ab ff ff       	call   6ef0 <fwp_rc_fresh>
    c3c7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c3ce:	00 
    c3cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c3db:	00 
    c3dc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c3e3:	00 
    c3e4:	e8 b7 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c3e9:	48 89 c7             	mov    %rax,%rdi
    c3ec:	e8 ff aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c3f1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c3f8:	00 
    c3f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3fe:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c405:	00 
    c406:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c40d:	00 
    c40e:	e8 8d 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c413:	48 89 c7             	mov    %rax,%rdi
    c416:	e8 d5 aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c41b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c422:	00 
    c423:	bf 01 00 00 00       	mov    $0x1,%edi
    c428:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c42f:	00 
    c430:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c437:	00 
    c438:	e8 63 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c43d:	48 89 c7             	mov    %rax,%rdi
    c440:	e8 ab aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c445:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c44c:	00 
    c44d:	bf 01 00 00 00       	mov    $0x1,%edi
    c452:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c459:	00 
    c45a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c461:	00 
    c462:	e8 39 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c467:	48 89 c7             	mov    %rax,%rdi
    c46a:	e8 81 aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c46f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c476:	00 
    c477:	bf 01 00 00 00       	mov    $0x1,%edi
    c47c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c483:	00 
    c484:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c48b:	00 
    c48c:	e8 0f 9c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c491:	48 89 c7             	mov    %rax,%rdi
    c494:	e8 57 aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c499:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c4a0:	00 
    c4a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4a6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c4ad:	00 
    c4ae:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c4b5:	00 
    c4b6:	e8 e5 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c4bb:	48 89 c7             	mov    %rax,%rdi
    c4be:	e8 2d aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c4c3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c4ca:	00 
    c4cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c4d7:	00 
    c4d8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c4df:	00 
    c4e0:	e8 bb 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c4e5:	48 89 c7             	mov    %rax,%rdi
    c4e8:	e8 03 aa ff ff       	call   6ef0 <fwp_rc_fresh>
    c4ed:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c4f4:	00 
    c4f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4fa:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c501:	00 
    c502:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c509:	00 
    c50a:	e8 91 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c50f:	48 89 c7             	mov    %rax,%rdi
    c512:	e8 d9 a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c517:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c51e:	00 
    c51f:	bf 01 00 00 00       	mov    $0x1,%edi
    c524:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c52b:	00 
    c52c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c533:	00 
    c534:	e8 67 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c539:	48 89 c7             	mov    %rax,%rdi
    c53c:	e8 af a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c541:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c548:	00 
    c549:	bf 01 00 00 00       	mov    $0x1,%edi
    c54e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c555:	00 
    c556:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c55d:	00 
    c55e:	e8 3d 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c563:	48 89 c7             	mov    %rax,%rdi
    c566:	e8 85 a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c56b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c572:	00 
    c573:	bf 01 00 00 00       	mov    $0x1,%edi
    c578:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c57f:	00 
    c580:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c587:	00 
    c588:	e8 13 9b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c58d:	48 89 c7             	mov    %rax,%rdi
    c590:	e8 5b a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c595:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c59c:	00 
    c59d:	bf 01 00 00 00       	mov    $0x1,%edi
    c5a2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c5a9:	00 
    c5aa:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c5b1:	00 
    c5b2:	e8 e9 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c5b7:	48 89 c7             	mov    %rax,%rdi
    c5ba:	e8 31 a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c5bf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c5c6:	00 
    c5c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5cc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c5d3:	00 
    c5d4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c5db:	00 
    c5dc:	e8 bf 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c5e1:	48 89 c7             	mov    %rax,%rdi
    c5e4:	e8 07 a9 ff ff       	call   6ef0 <fwp_rc_fresh>
    c5e9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c5f0:	00 
    c5f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5f6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c5fd:	00 
    c5fe:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c605:	00 
    c606:	e8 95 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c60b:	48 89 c7             	mov    %rax,%rdi
    c60e:	e8 dd a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c613:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c61a:	00 
    c61b:	bf 01 00 00 00       	mov    $0x1,%edi
    c620:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c627:	00 
    c628:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c62f:	00 
    c630:	e8 6b 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c635:	48 89 c7             	mov    %rax,%rdi
    c638:	e8 b3 a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c63d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c644:	00 
    c645:	bf 01 00 00 00       	mov    $0x1,%edi
    c64a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c651:	00 
    c652:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c659:	00 
    c65a:	e8 41 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c65f:	48 89 c7             	mov    %rax,%rdi
    c662:	e8 89 a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c667:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c66e:	00 
    c66f:	bf 01 00 00 00       	mov    $0x1,%edi
    c674:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c67b:	00 
    c67c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c683:	00 
    c684:	e8 17 9a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c689:	48 89 c7             	mov    %rax,%rdi
    c68c:	e8 5f a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c691:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c698:	00 
    c699:	bf 01 00 00 00       	mov    $0x1,%edi
    c69e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c6a5:	00 
    c6a6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c6ad:	00 
    c6ae:	e8 ed 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c6b3:	48 89 c7             	mov    %rax,%rdi
    c6b6:	e8 35 a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c6bb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c6c2:	00 
    c6c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c6c8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c6cf:	00 
    c6d0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c6d7:	00 
    c6d8:	e8 c3 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c6dd:	48 89 c7             	mov    %rax,%rdi
    c6e0:	e8 0b a8 ff ff       	call   6ef0 <fwp_rc_fresh>
    c6e5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c6ec:	00 
    c6ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c6f2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c6f9:	00 
    c6fa:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c701:	00 
    c702:	e8 99 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c707:	48 89 c7             	mov    %rax,%rdi
    c70a:	e8 e1 a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c70f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c716:	00 
    c717:	bf 01 00 00 00       	mov    $0x1,%edi
    c71c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c723:	00 
    c724:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c72b:	00 
    c72c:	e8 6f 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c731:	48 89 c7             	mov    %rax,%rdi
    c734:	e8 b7 a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c739:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c740:	00 
    c741:	bf 01 00 00 00       	mov    $0x1,%edi
    c746:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c74d:	00 
    c74e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c755:	00 
    c756:	e8 45 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c75b:	48 89 c7             	mov    %rax,%rdi
    c75e:	e8 8d a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c763:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c76a:	00 
    c76b:	bf 01 00 00 00       	mov    $0x1,%edi
    c770:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c777:	00 
    c778:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c77f:	00 
    c780:	e8 1b 99 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c785:	48 89 c7             	mov    %rax,%rdi
    c788:	e8 63 a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c78d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c794:	00 
    c795:	bf 01 00 00 00       	mov    $0x1,%edi
    c79a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c7a1:	00 
    c7a2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c7a9:	00 
    c7aa:	e8 f1 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c7af:	48 89 c7             	mov    %rax,%rdi
    c7b2:	e8 39 a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c7b7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c7be:	00 
    c7bf:	bf 01 00 00 00       	mov    $0x1,%edi
    c7c4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c7cb:	00 
    c7cc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c7d3:	00 
    c7d4:	e8 c7 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c7d9:	48 89 c7             	mov    %rax,%rdi
    c7dc:	e8 0f a7 ff ff       	call   6ef0 <fwp_rc_fresh>
    c7e1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c7e8:	00 
    c7e9:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ee:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c7f5:	00 
    c7f6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c7fd:	00 
    c7fe:	e8 9d 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c803:	48 89 c7             	mov    %rax,%rdi
    c806:	e8 e5 a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c80b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c812:	00 
    c813:	bf 01 00 00 00       	mov    $0x1,%edi
    c818:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c81f:	00 
    c820:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c827:	00 
    c828:	e8 73 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c82d:	48 89 c7             	mov    %rax,%rdi
    c830:	e8 bb a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c835:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c83c:	00 
    c83d:	bf 01 00 00 00       	mov    $0x1,%edi
    c842:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c849:	00 
    c84a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c851:	00 
    c852:	e8 49 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c857:	48 89 c7             	mov    %rax,%rdi
    c85a:	e8 91 a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c85f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c866:	00 
    c867:	bf 01 00 00 00       	mov    $0x1,%edi
    c86c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c873:	00 
    c874:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c87b:	00 
    c87c:	e8 1f 98 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c881:	48 89 c7             	mov    %rax,%rdi
    c884:	e8 67 a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c889:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c890:	00 
    c891:	bf 01 00 00 00       	mov    $0x1,%edi
    c896:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c89d:	00 
    c89e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c8a5:	00 
    c8a6:	e8 f5 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c8ab:	48 89 c7             	mov    %rax,%rdi
    c8ae:	e8 3d a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c8b3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c8ba:	00 
    c8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    c8c0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c8c7:	00 
    c8c8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c8cf:	00 
    c8d0:	e8 cb 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c8d5:	48 89 c7             	mov    %rax,%rdi
    c8d8:	e8 13 a6 ff ff       	call   6ef0 <fwp_rc_fresh>
    c8dd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c8e4:	00 
    c8e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ea:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c8f1:	00 
    c8f2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c8f9:	00 
    c8fa:	e8 a1 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c8ff:	48 89 c7             	mov    %rax,%rdi
    c902:	e8 e9 a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c907:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c90e:	00 
    c90f:	bf 01 00 00 00       	mov    $0x1,%edi
    c914:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c91b:	00 
    c91c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c923:	00 
    c924:	e8 77 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c929:	48 89 c7             	mov    %rax,%rdi
    c92c:	e8 bf a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c931:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c938:	00 
    c939:	bf 01 00 00 00       	mov    $0x1,%edi
    c93e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c945:	00 
    c946:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c94d:	00 
    c94e:	e8 4d 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c953:	48 89 c7             	mov    %rax,%rdi
    c956:	e8 95 a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c95b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c962:	00 
    c963:	bf 01 00 00 00       	mov    $0x1,%edi
    c968:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c96f:	00 
    c970:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c977:	00 
    c978:	e8 23 97 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c97d:	48 89 c7             	mov    %rax,%rdi
    c980:	e8 6b a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c985:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c98c:	00 
    c98d:	bf 01 00 00 00       	mov    $0x1,%edi
    c992:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c999:	00 
    c99a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c9a1:	00 
    c9a2:	e8 f9 96 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c9a7:	48 89 c7             	mov    %rax,%rdi
    c9aa:	e8 41 a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c9af:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c9b6:	00 
    c9b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c9bc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c9c3:	00 
    c9c4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c9cb:	00 
    c9cc:	e8 cf 96 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c9d1:	48 89 c7             	mov    %rax,%rdi
    c9d4:	e8 17 a5 ff ff       	call   6ef0 <fwp_rc_fresh>
    c9d9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c9e0:	00 
    c9e1:	bf 01 00 00 00       	mov    $0x1,%edi
    c9e6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c9ed:	00 
    c9ee:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c9f5:	00 
    c9f6:	e8 a5 96 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    c9fb:	48 89 c7             	mov    %rax,%rdi
    c9fe:	e8 ed a4 ff ff       	call   6ef0 <fwp_rc_fresh>
    ca03:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    ca0a:	00 
    ca0b:	bf 01 00 00 00       	mov    $0x1,%edi
    ca10:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    ca17:	00 
    ca18:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    ca1f:	00 
    ca20:	e8 7b 96 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    ca25:	48 8b 15 ac 01 06 00 	mov    0x601ac(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    ca2c:	49 89 c5             	mov    %rax,%r13
    ca2f:	48 2b 05 7a 01 06 00 	sub    0x6017a(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    ca36:	48 c1 e2 10          	shl    $0x10,%rdx
    ca3a:	48 39 d0             	cmp    %rdx,%rax
    ca3d:	73 59                	jae    ca98 <f0+0x13b8>
    ca3f:	48 89 c2             	mov    %rax,%rdx
    ca42:	48 c1 ea 10          	shr    $0x10,%rdx
    ca46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca4a:	48 8b 15 a7 01 06 00 	mov    0x601a7(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    ca51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca59:	4d 85 e4             	test   %r12,%r12
    ca5c:	74 3a                	je     ca98 <f0+0x13b8>
    ca5e:	0f b6 0a             	movzbl (%rdx),%ecx
    ca61:	80 f9 02             	cmp    $0x2,%cl
    ca64:	0f 84 c6 15 00 00    	je     e030 <f0+0x2950>
    ca6a:	80 f9 01             	cmp    $0x1,%cl
    ca6d:	75 29                	jne    ca98 <f0+0x13b8>
    ca6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca72:	0f b7 c0             	movzwl %ax,%eax
    ca75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca78:	48 0f af c1          	imul   %rcx,%rax
    ca7c:	48 c1 e8 20          	shr    $0x20,%rax
    ca80:	48 39 d0             	cmp    %rdx,%rax
    ca83:	73 13                	jae    ca98 <f0+0x13b8>
    ca85:	49 01 c4             	add    %rax,%r12
    ca88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca8d:	0f 84 99 17 00 00    	je     e22c <f0+0x2b4c>
    ca93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca98:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca9f:	33 f3 bf 
    caa2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    caa9:	00 
    caaa:	bf 01 00 00 00       	mov    $0x1,%edi
    caaf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    cab6:	00 
    cab7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    cabe:	00 
    cabf:	e8 dc 95 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cac4:	48 8b 15 0d 01 06 00 	mov    0x6010d(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cacb:	49 89 c5             	mov    %rax,%r13
    cace:	48 2b 05 db 00 06 00 	sub    0x600db(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cad5:	48 c1 e2 10          	shl    $0x10,%rdx
    cad9:	48 39 d0             	cmp    %rdx,%rax
    cadc:	73 59                	jae    cb37 <f0+0x1457>
    cade:	48 89 c2             	mov    %rax,%rdx
    cae1:	48 c1 ea 10          	shr    $0x10,%rdx
    cae5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cae9:	48 8b 15 08 01 06 00 	mov    0x60108(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    caf0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caf4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caf8:	4d 85 e4             	test   %r12,%r12
    cafb:	74 3a                	je     cb37 <f0+0x1457>
    cafd:	0f b6 0a             	movzbl (%rdx),%ecx
    cb00:	80 f9 02             	cmp    $0x2,%cl
    cb03:	0f 84 17 15 00 00    	je     e020 <f0+0x2940>
    cb09:	80 f9 01             	cmp    $0x1,%cl
    cb0c:	75 29                	jne    cb37 <f0+0x1457>
    cb0e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb11:	0f b7 c0             	movzwl %ax,%eax
    cb14:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb17:	48 0f af c1          	imul   %rcx,%rax
    cb1b:	48 c1 e8 20          	shr    $0x20,%rax
    cb1f:	48 39 d0             	cmp    %rdx,%rax
    cb22:	73 13                	jae    cb37 <f0+0x1457>
    cb24:	49 01 c4             	add    %rax,%r12
    cb27:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb2c:	0f 84 07 17 00 00    	je     e239 <f0+0x2b59>
    cb32:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb37:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb3e:	00 f0 3f 
    cb41:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    cb48:	00 
    cb49:	bf 01 00 00 00       	mov    $0x1,%edi
    cb4e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    cb55:	00 
    cb56:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    cb5d:	00 
    cb5e:	e8 3d 95 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cb63:	48 8b 15 6e 00 06 00 	mov    0x6006e(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cb6a:	49 89 c5             	mov    %rax,%r13
    cb6d:	48 2b 05 3c 00 06 00 	sub    0x6003c(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cb74:	48 c1 e2 10          	shl    $0x10,%rdx
    cb78:	48 39 d0             	cmp    %rdx,%rax
    cb7b:	73 59                	jae    cbd6 <f0+0x14f6>
    cb7d:	48 89 c2             	mov    %rax,%rdx
    cb80:	48 c1 ea 10          	shr    $0x10,%rdx
    cb84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb88:	48 8b 15 69 00 06 00 	mov    0x60069(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cb8f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb93:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb97:	4d 85 e4             	test   %r12,%r12
    cb9a:	74 3a                	je     cbd6 <f0+0x14f6>
    cb9c:	0f b6 0a             	movzbl (%rdx),%ecx
    cb9f:	80 f9 02             	cmp    $0x2,%cl
    cba2:	0f 84 28 15 00 00    	je     e0d0 <f0+0x29f0>
    cba8:	80 f9 01             	cmp    $0x1,%cl
    cbab:	75 29                	jne    cbd6 <f0+0x14f6>
    cbad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbb0:	0f b7 c0             	movzwl %ax,%eax
    cbb3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbb6:	48 0f af c1          	imul   %rcx,%rax
    cbba:	48 c1 e8 20          	shr    $0x20,%rax
    cbbe:	48 39 d0             	cmp    %rdx,%rax
    cbc1:	73 13                	jae    cbd6 <f0+0x14f6>
    cbc3:	49 01 c4             	add    %rax,%r12
    cbc6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbcb:	0f 84 75 16 00 00    	je     e246 <f0+0x2b66>
    cbd1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbd6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbdd:	33 f3 bf 
    cbe0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    cbe7:	00 
    cbe8:	bf 01 00 00 00       	mov    $0x1,%edi
    cbed:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    cbf4:	00 
    cbf5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    cbfc:	00 
    cbfd:	e8 9e 94 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cc02:	48 8b 15 cf ff 05 00 	mov    0x5ffcf(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cc09:	49 89 c5             	mov    %rax,%r13
    cc0c:	48 2b 05 9d ff 05 00 	sub    0x5ff9d(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cc13:	48 c1 e2 10          	shl    $0x10,%rdx
    cc17:	48 39 d0             	cmp    %rdx,%rax
    cc1a:	73 59                	jae    cc75 <f0+0x1595>
    cc1c:	48 89 c2             	mov    %rax,%rdx
    cc1f:	48 c1 ea 10          	shr    $0x10,%rdx
    cc23:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc27:	48 8b 15 ca ff 05 00 	mov    0x5ffca(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cc2e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc32:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc36:	4d 85 e4             	test   %r12,%r12
    cc39:	74 3a                	je     cc75 <f0+0x1595>
    cc3b:	0f b6 0a             	movzbl (%rdx),%ecx
    cc3e:	80 f9 02             	cmp    $0x2,%cl
    cc41:	0f 84 79 14 00 00    	je     e0c0 <f0+0x29e0>
    cc47:	80 f9 01             	cmp    $0x1,%cl
    cc4a:	75 29                	jne    cc75 <f0+0x1595>
    cc4c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc4f:	0f b7 c0             	movzwl %ax,%eax
    cc52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc55:	48 0f af c1          	imul   %rcx,%rax
    cc59:	48 c1 e8 20          	shr    $0x20,%rax
    cc5d:	48 39 d0             	cmp    %rdx,%rax
    cc60:	73 13                	jae    cc75 <f0+0x1595>
    cc62:	49 01 c4             	add    %rax,%r12
    cc65:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc6a:	0f 84 e3 15 00 00    	je     e253 <f0+0x2b73>
    cc70:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc75:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc7c:	00 f0 3f 
    cc7f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cc86:	00 
    cc87:	bf 01 00 00 00       	mov    $0x1,%edi
    cc8c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    cc93:	00 
    cc94:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cc9b:	00 
    cc9c:	e8 ff 93 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cca1:	48 8b 15 30 ff 05 00 	mov    0x5ff30(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cca8:	49 89 c5             	mov    %rax,%r13
    ccab:	48 2b 05 fe fe 05 00 	sub    0x5fefe(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    ccb2:	48 c1 e2 10          	shl    $0x10,%rdx
    ccb6:	48 39 d0             	cmp    %rdx,%rax
    ccb9:	73 59                	jae    cd14 <f0+0x1634>
    ccbb:	48 89 c2             	mov    %rax,%rdx
    ccbe:	48 c1 ea 10          	shr    $0x10,%rdx
    ccc2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccc6:	48 8b 15 2b ff 05 00 	mov    0x5ff2b(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cccd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccd1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccd5:	4d 85 e4             	test   %r12,%r12
    ccd8:	74 3a                	je     cd14 <f0+0x1634>
    ccda:	0f b6 0a             	movzbl (%rdx),%ecx
    ccdd:	80 f9 02             	cmp    $0x2,%cl
    cce0:	0f 84 ca 13 00 00    	je     e0b0 <f0+0x29d0>
    cce6:	80 f9 01             	cmp    $0x1,%cl
    cce9:	75 29                	jne    cd14 <f0+0x1634>
    cceb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccee:	0f b7 c0             	movzwl %ax,%eax
    ccf1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccf4:	48 0f af c1          	imul   %rcx,%rax
    ccf8:	48 c1 e8 20          	shr    $0x20,%rax
    ccfc:	48 39 d0             	cmp    %rdx,%rax
    ccff:	73 13                	jae    cd14 <f0+0x1634>
    cd01:	49 01 c4             	add    %rax,%r12
    cd04:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd09:	0f 84 51 15 00 00    	je     e260 <f0+0x2b80>
    cd0f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd14:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd1b:	33 f3 bf 
    cd1e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cd25:	00 
    cd26:	bf 01 00 00 00       	mov    $0x1,%edi
    cd2b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cd32:	00 
    cd33:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cd3a:	00 
    cd3b:	e8 60 93 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cd40:	48 8b 15 91 fe 05 00 	mov    0x5fe91(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cd47:	49 89 c5             	mov    %rax,%r13
    cd4a:	48 2b 05 5f fe 05 00 	sub    0x5fe5f(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cd51:	48 c1 e2 10          	shl    $0x10,%rdx
    cd55:	48 39 d0             	cmp    %rdx,%rax
    cd58:	73 59                	jae    cdb3 <f0+0x16d3>
    cd5a:	48 89 c2             	mov    %rax,%rdx
    cd5d:	48 c1 ea 10          	shr    $0x10,%rdx
    cd61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd65:	48 8b 15 8c fe 05 00 	mov    0x5fe8c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cd6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd70:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd74:	4d 85 e4             	test   %r12,%r12
    cd77:	74 3a                	je     cdb3 <f0+0x16d3>
    cd79:	0f b6 0a             	movzbl (%rdx),%ecx
    cd7c:	80 f9 02             	cmp    $0x2,%cl
    cd7f:	0f 84 1b 13 00 00    	je     e0a0 <f0+0x29c0>
    cd85:	80 f9 01             	cmp    $0x1,%cl
    cd88:	75 29                	jne    cdb3 <f0+0x16d3>
    cd8a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd8d:	0f b7 c0             	movzwl %ax,%eax
    cd90:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd93:	48 0f af c1          	imul   %rcx,%rax
    cd97:	48 c1 e8 20          	shr    $0x20,%rax
    cd9b:	48 39 d0             	cmp    %rdx,%rax
    cd9e:	73 13                	jae    cdb3 <f0+0x16d3>
    cda0:	49 01 c4             	add    %rax,%r12
    cda3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cda8:	0f 84 bf 14 00 00    	je     e26d <f0+0x2b8d>
    cdae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdb3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdba:	00 f0 3f 
    cdbd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cdc4:	00 
    cdc5:	bf 01 00 00 00       	mov    $0x1,%edi
    cdca:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cdd1:	00 
    cdd2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cdd9:	00 
    cdda:	e8 c1 92 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cddf:	48 8b 15 f2 fd 05 00 	mov    0x5fdf2(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cde6:	49 89 c5             	mov    %rax,%r13
    cde9:	48 2b 05 c0 fd 05 00 	sub    0x5fdc0(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cdf0:	48 c1 e2 10          	shl    $0x10,%rdx
    cdf4:	48 39 d0             	cmp    %rdx,%rax
    cdf7:	73 59                	jae    ce52 <f0+0x1772>
    cdf9:	48 89 c2             	mov    %rax,%rdx
    cdfc:	48 c1 ea 10          	shr    $0x10,%rdx
    ce00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce04:	48 8b 15 ed fd 05 00 	mov    0x5fded(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    ce0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce0f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce13:	4d 85 e4             	test   %r12,%r12
    ce16:	74 3a                	je     ce52 <f0+0x1772>
    ce18:	0f b6 0a             	movzbl (%rdx),%ecx
    ce1b:	80 f9 02             	cmp    $0x2,%cl
    ce1e:	0f 84 6c 12 00 00    	je     e090 <f0+0x29b0>
    ce24:	80 f9 01             	cmp    $0x1,%cl
    ce27:	75 29                	jne    ce52 <f0+0x1772>
    ce29:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce2c:	0f b7 c0             	movzwl %ax,%eax
    ce2f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce32:	48 0f af c1          	imul   %rcx,%rax
    ce36:	48 c1 e8 20          	shr    $0x20,%rax
    ce3a:	48 39 d0             	cmp    %rdx,%rax
    ce3d:	73 13                	jae    ce52 <f0+0x1772>
    ce3f:	49 01 c4             	add    %rax,%r12
    ce42:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce47:	0f 84 2d 14 00 00    	je     e27a <f0+0x2b9a>
    ce4d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce52:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce59:	33 f3 bf 
    ce5c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    ce63:	00 
    ce64:	bf 01 00 00 00       	mov    $0x1,%edi
    ce69:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    ce70:	00 
    ce71:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    ce78:	00 
    ce79:	e8 22 92 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    ce7e:	48 8b 15 53 fd 05 00 	mov    0x5fd53(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    ce85:	49 89 c5             	mov    %rax,%r13
    ce88:	48 2b 05 21 fd 05 00 	sub    0x5fd21(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    ce8f:	48 c1 e2 10          	shl    $0x10,%rdx
    ce93:	48 39 d0             	cmp    %rdx,%rax
    ce96:	73 59                	jae    cef1 <f0+0x1811>
    ce98:	48 89 c2             	mov    %rax,%rdx
    ce9b:	48 c1 ea 10          	shr    $0x10,%rdx
    ce9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cea3:	48 8b 15 4e fd 05 00 	mov    0x5fd4e(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    ceaa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ceae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceb2:	4d 85 e4             	test   %r12,%r12
    ceb5:	74 3a                	je     cef1 <f0+0x1811>
    ceb7:	0f b6 0a             	movzbl (%rdx),%ecx
    ceba:	80 f9 02             	cmp    $0x2,%cl
    cebd:	0f 84 bd 11 00 00    	je     e080 <f0+0x29a0>
    cec3:	80 f9 01             	cmp    $0x1,%cl
    cec6:	75 29                	jne    cef1 <f0+0x1811>
    cec8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cecb:	0f b7 c0             	movzwl %ax,%eax
    cece:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ced1:	48 0f af c1          	imul   %rcx,%rax
    ced5:	48 c1 e8 20          	shr    $0x20,%rax
    ced9:	48 39 d0             	cmp    %rdx,%rax
    cedc:	73 13                	jae    cef1 <f0+0x1811>
    cede:	49 01 c4             	add    %rax,%r12
    cee1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cee6:	0f 84 9b 13 00 00    	je     e287 <f0+0x2ba7>
    ceec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cef1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cef8:	00 f0 3f 
    cefb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cf02:	00 
    cf03:	bf 01 00 00 00       	mov    $0x1,%edi
    cf08:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cf0f:	00 
    cf10:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cf17:	00 
    cf18:	e8 83 91 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cf1d:	48 8b 15 b4 fc 05 00 	mov    0x5fcb4(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cf24:	49 89 c5             	mov    %rax,%r13
    cf27:	48 2b 05 82 fc 05 00 	sub    0x5fc82(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cf2e:	48 c1 e2 10          	shl    $0x10,%rdx
    cf32:	48 39 d0             	cmp    %rdx,%rax
    cf35:	73 59                	jae    cf90 <f0+0x18b0>
    cf37:	48 89 c2             	mov    %rax,%rdx
    cf3a:	48 c1 ea 10          	shr    $0x10,%rdx
    cf3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf42:	48 8b 15 af fc 05 00 	mov    0x5fcaf(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cf49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf51:	4d 85 e4             	test   %r12,%r12
    cf54:	74 3a                	je     cf90 <f0+0x18b0>
    cf56:	0f b6 0a             	movzbl (%rdx),%ecx
    cf59:	80 f9 02             	cmp    $0x2,%cl
    cf5c:	0f 84 0e 11 00 00    	je     e070 <f0+0x2990>
    cf62:	80 f9 01             	cmp    $0x1,%cl
    cf65:	75 29                	jne    cf90 <f0+0x18b0>
    cf67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf6a:	0f b7 c0             	movzwl %ax,%eax
    cf6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf70:	48 0f af c1          	imul   %rcx,%rax
    cf74:	48 c1 e8 20          	shr    $0x20,%rax
    cf78:	48 39 d0             	cmp    %rdx,%rax
    cf7b:	73 13                	jae    cf90 <f0+0x18b0>
    cf7d:	49 01 c4             	add    %rax,%r12
    cf80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf85:	0f 84 09 13 00 00    	je     e294 <f0+0x2bb4>
    cf8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf90:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf97:	33 f3 bf 
    cf9a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cfa1:	00 
    cfa2:	bf 01 00 00 00       	mov    $0x1,%edi
    cfa7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cfae:	00 
    cfaf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cfb6:	00 
    cfb7:	e8 e4 90 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    cfbc:	48 8b 15 15 fc 05 00 	mov    0x5fc15(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    cfc3:	49 89 c5             	mov    %rax,%r13
    cfc6:	48 2b 05 e3 fb 05 00 	sub    0x5fbe3(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    cfcd:	48 c1 e2 10          	shl    $0x10,%rdx
    cfd1:	48 39 d0             	cmp    %rdx,%rax
    cfd4:	73 59                	jae    d02f <f0+0x194f>
    cfd6:	48 89 c2             	mov    %rax,%rdx
    cfd9:	48 c1 ea 10          	shr    $0x10,%rdx
    cfdd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfe1:	48 8b 15 10 fc 05 00 	mov    0x5fc10(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    cfe8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cff0:	4d 85 e4             	test   %r12,%r12
    cff3:	74 3a                	je     d02f <f0+0x194f>
    cff5:	0f b6 0a             	movzbl (%rdx),%ecx
    cff8:	80 f9 02             	cmp    $0x2,%cl
    cffb:	0f 84 5f 10 00 00    	je     e060 <f0+0x2980>
    d001:	80 f9 01             	cmp    $0x1,%cl
    d004:	75 29                	jne    d02f <f0+0x194f>
    d006:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d009:	0f b7 c0             	movzwl %ax,%eax
    d00c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d00f:	48 0f af c1          	imul   %rcx,%rax
    d013:	48 c1 e8 20          	shr    $0x20,%rax
    d017:	48 39 d0             	cmp    %rdx,%rax
    d01a:	73 13                	jae    d02f <f0+0x194f>
    d01c:	49 01 c4             	add    %rax,%r12
    d01f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d024:	0f 84 77 12 00 00    	je     e2a1 <f0+0x2bc1>
    d02a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d02f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d036:	00 f0 3f 
    d039:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d040:	00 
    d041:	bf 01 00 00 00       	mov    $0x1,%edi
    d046:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d04d:	00 
    d04e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d055:	00 
    d056:	e8 45 90 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d05b:	48 8b 15 76 fb 05 00 	mov    0x5fb76(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d062:	49 89 c5             	mov    %rax,%r13
    d065:	48 2b 05 44 fb 05 00 	sub    0x5fb44(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d06c:	48 c1 e2 10          	shl    $0x10,%rdx
    d070:	48 39 d0             	cmp    %rdx,%rax
    d073:	73 59                	jae    d0ce <f0+0x19ee>
    d075:	48 89 c2             	mov    %rax,%rdx
    d078:	48 c1 ea 10          	shr    $0x10,%rdx
    d07c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d080:	48 8b 15 71 fb 05 00 	mov    0x5fb71(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d087:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d08b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d08f:	4d 85 e4             	test   %r12,%r12
    d092:	74 3a                	je     d0ce <f0+0x19ee>
    d094:	0f b6 0a             	movzbl (%rdx),%ecx
    d097:	80 f9 02             	cmp    $0x2,%cl
    d09a:	0f 84 40 0f 00 00    	je     dfe0 <f0+0x2900>
    d0a0:	80 f9 01             	cmp    $0x1,%cl
    d0a3:	75 29                	jne    d0ce <f0+0x19ee>
    d0a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0a8:	0f b7 c0             	movzwl %ax,%eax
    d0ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0ae:	48 0f af c1          	imul   %rcx,%rax
    d0b2:	48 c1 e8 20          	shr    $0x20,%rax
    d0b6:	48 39 d0             	cmp    %rdx,%rax
    d0b9:	73 13                	jae    d0ce <f0+0x19ee>
    d0bb:	49 01 c4             	add    %rax,%r12
    d0be:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0c3:	0f 84 e5 11 00 00    	je     e2ae <f0+0x2bce>
    d0c9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ce:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0d5:	33 f3 bf 
    d0d8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d0df:	00 
    d0e0:	bf 01 00 00 00       	mov    $0x1,%edi
    d0e5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d0ec:	00 
    d0ed:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d0f4:	00 
    d0f5:	e8 a6 8f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d0fa:	48 8b 15 d7 fa 05 00 	mov    0x5fad7(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d101:	49 89 c5             	mov    %rax,%r13
    d104:	48 2b 05 a5 fa 05 00 	sub    0x5faa5(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d10b:	48 c1 e2 10          	shl    $0x10,%rdx
    d10f:	48 39 d0             	cmp    %rdx,%rax
    d112:	73 59                	jae    d16d <f0+0x1a8d>
    d114:	48 89 c2             	mov    %rax,%rdx
    d117:	48 c1 ea 10          	shr    $0x10,%rdx
    d11b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d11f:	48 8b 15 d2 fa 05 00 	mov    0x5fad2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d126:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d12a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d12e:	4d 85 e4             	test   %r12,%r12
    d131:	74 3a                	je     d16d <f0+0x1a8d>
    d133:	0f b6 0a             	movzbl (%rdx),%ecx
    d136:	80 f9 02             	cmp    $0x2,%cl
    d139:	0f 84 91 0e 00 00    	je     dfd0 <f0+0x28f0>
    d13f:	80 f9 01             	cmp    $0x1,%cl
    d142:	75 29                	jne    d16d <f0+0x1a8d>
    d144:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d147:	0f b7 c0             	movzwl %ax,%eax
    d14a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d14d:	48 0f af c1          	imul   %rcx,%rax
    d151:	48 c1 e8 20          	shr    $0x20,%rax
    d155:	48 39 d0             	cmp    %rdx,%rax
    d158:	73 13                	jae    d16d <f0+0x1a8d>
    d15a:	49 01 c4             	add    %rax,%r12
    d15d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d162:	0f 84 53 11 00 00    	je     e2bb <f0+0x2bdb>
    d168:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d16d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d174:	00 f0 3f 
    d177:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d17e:	00 
    d17f:	bf 01 00 00 00       	mov    $0x1,%edi
    d184:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d18b:	00 
    d18c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d193:	00 
    d194:	e8 07 8f ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d199:	48 8b 15 38 fa 05 00 	mov    0x5fa38(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d1a0:	49 89 c5             	mov    %rax,%r13
    d1a3:	48 2b 05 06 fa 05 00 	sub    0x5fa06(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d1aa:	48 c1 e2 10          	shl    $0x10,%rdx
    d1ae:	48 39 d0             	cmp    %rdx,%rax
    d1b1:	73 59                	jae    d20c <f0+0x1b2c>
    d1b3:	48 89 c2             	mov    %rax,%rdx
    d1b6:	48 c1 ea 10          	shr    $0x10,%rdx
    d1ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1be:	48 8b 15 33 fa 05 00 	mov    0x5fa33(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d1c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1cd:	4d 85 e4             	test   %r12,%r12
    d1d0:	74 3a                	je     d20c <f0+0x1b2c>
    d1d2:	0f b6 0a             	movzbl (%rdx),%ecx
    d1d5:	80 f9 02             	cmp    $0x2,%cl
    d1d8:	0f 84 e2 0d 00 00    	je     dfc0 <f0+0x28e0>
    d1de:	80 f9 01             	cmp    $0x1,%cl
    d1e1:	75 29                	jne    d20c <f0+0x1b2c>
    d1e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1e6:	0f b7 c0             	movzwl %ax,%eax
    d1e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1ec:	48 0f af c1          	imul   %rcx,%rax
    d1f0:	48 c1 e8 20          	shr    $0x20,%rax
    d1f4:	48 39 d0             	cmp    %rdx,%rax
    d1f7:	73 13                	jae    d20c <f0+0x1b2c>
    d1f9:	49 01 c4             	add    %rax,%r12
    d1fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d201:	0f 84 c1 10 00 00    	je     e2c8 <f0+0x2be8>
    d207:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d20c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d213:	33 f3 bf 
    d216:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d21d:	00 
    d21e:	bf 01 00 00 00       	mov    $0x1,%edi
    d223:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d22a:	00 
    d22b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d232:	00 
    d233:	e8 68 8e ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d238:	48 8b 15 99 f9 05 00 	mov    0x5f999(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d23f:	49 89 c5             	mov    %rax,%r13
    d242:	48 2b 05 67 f9 05 00 	sub    0x5f967(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d249:	48 c1 e2 10          	shl    $0x10,%rdx
    d24d:	48 39 d0             	cmp    %rdx,%rax
    d250:	73 59                	jae    d2ab <f0+0x1bcb>
    d252:	48 89 c2             	mov    %rax,%rdx
    d255:	48 c1 ea 10          	shr    $0x10,%rdx
    d259:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d25d:	48 8b 15 94 f9 05 00 	mov    0x5f994(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d264:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d268:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d26c:	4d 85 e4             	test   %r12,%r12
    d26f:	74 3a                	je     d2ab <f0+0x1bcb>
    d271:	0f b6 0a             	movzbl (%rdx),%ecx
    d274:	80 f9 02             	cmp    $0x2,%cl
    d277:	0f 84 33 0d 00 00    	je     dfb0 <f0+0x28d0>
    d27d:	80 f9 01             	cmp    $0x1,%cl
    d280:	75 29                	jne    d2ab <f0+0x1bcb>
    d282:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d285:	0f b7 c0             	movzwl %ax,%eax
    d288:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d28b:	48 0f af c1          	imul   %rcx,%rax
    d28f:	48 c1 e8 20          	shr    $0x20,%rax
    d293:	48 39 d0             	cmp    %rdx,%rax
    d296:	73 13                	jae    d2ab <f0+0x1bcb>
    d298:	49 01 c4             	add    %rax,%r12
    d29b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2a0:	0f 84 2f 10 00 00    	je     e2d5 <f0+0x2bf5>
    d2a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2b2:	00 f0 3f 
    d2b5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d2bc:	00 
    d2bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d2c2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d2c9:	00 
    d2ca:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d2d1:	00 
    d2d2:	e8 c9 8d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d2d7:	48 8b 15 fa f8 05 00 	mov    0x5f8fa(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d2de:	49 89 c5             	mov    %rax,%r13
    d2e1:	48 2b 05 c8 f8 05 00 	sub    0x5f8c8(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d2e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d2ec:	48 39 d0             	cmp    %rdx,%rax
    d2ef:	73 59                	jae    d34a <f0+0x1c6a>
    d2f1:	48 89 c2             	mov    %rax,%rdx
    d2f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d2f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2fc:	48 8b 15 f5 f8 05 00 	mov    0x5f8f5(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d303:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d307:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d30b:	4d 85 e4             	test   %r12,%r12
    d30e:	74 3a                	je     d34a <f0+0x1c6a>
    d310:	0f b6 0a             	movzbl (%rdx),%ecx
    d313:	80 f9 02             	cmp    $0x2,%cl
    d316:	0f 84 84 0c 00 00    	je     dfa0 <f0+0x28c0>
    d31c:	80 f9 01             	cmp    $0x1,%cl
    d31f:	75 29                	jne    d34a <f0+0x1c6a>
    d321:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d324:	0f b7 c0             	movzwl %ax,%eax
    d327:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d32a:	48 0f af c1          	imul   %rcx,%rax
    d32e:	48 c1 e8 20          	shr    $0x20,%rax
    d332:	48 39 d0             	cmp    %rdx,%rax
    d335:	73 13                	jae    d34a <f0+0x1c6a>
    d337:	49 01 c4             	add    %rax,%r12
    d33a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d33f:	0f 84 9d 0f 00 00    	je     e2e2 <f0+0x2c02>
    d345:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d34a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d351:	33 f3 bf 
    d354:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d35b:	00 
    d35c:	bf 01 00 00 00       	mov    $0x1,%edi
    d361:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d368:	00 
    d369:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d370:	00 
    d371:	e8 2a 8d ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d376:	48 8b 15 5b f8 05 00 	mov    0x5f85b(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d37d:	49 89 c5             	mov    %rax,%r13
    d380:	48 2b 05 29 f8 05 00 	sub    0x5f829(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d387:	48 c1 e2 10          	shl    $0x10,%rdx
    d38b:	48 39 d0             	cmp    %rdx,%rax
    d38e:	73 59                	jae    d3e9 <f0+0x1d09>
    d390:	48 89 c2             	mov    %rax,%rdx
    d393:	48 c1 ea 10          	shr    $0x10,%rdx
    d397:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d39b:	48 8b 15 56 f8 05 00 	mov    0x5f856(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d3a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3aa:	4d 85 e4             	test   %r12,%r12
    d3ad:	74 3a                	je     d3e9 <f0+0x1d09>
    d3af:	0f b6 0a             	movzbl (%rdx),%ecx
    d3b2:	80 f9 02             	cmp    $0x2,%cl
    d3b5:	0f 84 d5 0b 00 00    	je     df90 <f0+0x28b0>
    d3bb:	80 f9 01             	cmp    $0x1,%cl
    d3be:	75 29                	jne    d3e9 <f0+0x1d09>
    d3c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3c3:	0f b7 c0             	movzwl %ax,%eax
    d3c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3c9:	48 0f af c1          	imul   %rcx,%rax
    d3cd:	48 c1 e8 20          	shr    $0x20,%rax
    d3d1:	48 39 d0             	cmp    %rdx,%rax
    d3d4:	73 13                	jae    d3e9 <f0+0x1d09>
    d3d6:	49 01 c4             	add    %rax,%r12
    d3d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3de:	0f 84 0b 0f 00 00    	je     e2ef <f0+0x2c0f>
    d3e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3f0:	00 f0 3f 
    d3f3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d3fa:	00 
    d3fb:	bf 01 00 00 00       	mov    $0x1,%edi
    d400:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d407:	00 
    d408:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d40f:	00 
    d410:	e8 8b 8c ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d415:	48 8b 15 bc f7 05 00 	mov    0x5f7bc(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d41c:	49 89 c5             	mov    %rax,%r13
    d41f:	48 2b 05 8a f7 05 00 	sub    0x5f78a(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d426:	48 c1 e2 10          	shl    $0x10,%rdx
    d42a:	48 39 d0             	cmp    %rdx,%rax
    d42d:	73 59                	jae    d488 <f0+0x1da8>
    d42f:	48 89 c2             	mov    %rax,%rdx
    d432:	48 c1 ea 10          	shr    $0x10,%rdx
    d436:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d43a:	48 8b 15 b7 f7 05 00 	mov    0x5f7b7(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d441:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d445:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d449:	4d 85 e4             	test   %r12,%r12
    d44c:	74 3a                	je     d488 <f0+0x1da8>
    d44e:	0f b6 0a             	movzbl (%rdx),%ecx
    d451:	80 f9 02             	cmp    $0x2,%cl
    d454:	0f 84 26 0b 00 00    	je     df80 <f0+0x28a0>
    d45a:	80 f9 01             	cmp    $0x1,%cl
    d45d:	75 29                	jne    d488 <f0+0x1da8>
    d45f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d462:	0f b7 c0             	movzwl %ax,%eax
    d465:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d468:	48 0f af c1          	imul   %rcx,%rax
    d46c:	48 c1 e8 20          	shr    $0x20,%rax
    d470:	48 39 d0             	cmp    %rdx,%rax
    d473:	73 13                	jae    d488 <f0+0x1da8>
    d475:	49 01 c4             	add    %rax,%r12
    d478:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d47d:	0f 84 79 0e 00 00    	je     e2fc <f0+0x2c1c>
    d483:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d488:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d48f:	33 f3 bf 
    d492:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d499:	00 
    d49a:	bf 01 00 00 00       	mov    $0x1,%edi
    d49f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d4a6:	00 
    d4a7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d4ae:	00 
    d4af:	e8 ec 8b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d4b4:	48 8b 15 1d f7 05 00 	mov    0x5f71d(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d4bb:	49 89 c5             	mov    %rax,%r13
    d4be:	48 2b 05 eb f6 05 00 	sub    0x5f6eb(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d4c5:	48 c1 e2 10          	shl    $0x10,%rdx
    d4c9:	48 39 d0             	cmp    %rdx,%rax
    d4cc:	73 59                	jae    d527 <f0+0x1e47>
    d4ce:	48 89 c2             	mov    %rax,%rdx
    d4d1:	48 c1 ea 10          	shr    $0x10,%rdx
    d4d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4d9:	48 8b 15 18 f7 05 00 	mov    0x5f718(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d4e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4e4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4e8:	4d 85 e4             	test   %r12,%r12
    d4eb:	74 3a                	je     d527 <f0+0x1e47>
    d4ed:	0f b6 0a             	movzbl (%rdx),%ecx
    d4f0:	80 f9 02             	cmp    $0x2,%cl
    d4f3:	0f 84 77 0a 00 00    	je     df70 <f0+0x2890>
    d4f9:	80 f9 01             	cmp    $0x1,%cl
    d4fc:	75 29                	jne    d527 <f0+0x1e47>
    d4fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d501:	0f b7 c0             	movzwl %ax,%eax
    d504:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d507:	48 0f af c1          	imul   %rcx,%rax
    d50b:	48 c1 e8 20          	shr    $0x20,%rax
    d50f:	48 39 d0             	cmp    %rdx,%rax
    d512:	73 13                	jae    d527 <f0+0x1e47>
    d514:	49 01 c4             	add    %rax,%r12
    d517:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d51c:	0f 84 e7 0d 00 00    	je     e309 <f0+0x2c29>
    d522:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d527:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d52e:	00 f0 3f 
    d531:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d538:	00 
    d539:	bf 01 00 00 00       	mov    $0x1,%edi
    d53e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d545:	00 
    d546:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d54d:	00 
    d54e:	e8 4d 8b ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d553:	48 8b 15 7e f6 05 00 	mov    0x5f67e(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d55a:	49 89 c5             	mov    %rax,%r13
    d55d:	48 2b 05 4c f6 05 00 	sub    0x5f64c(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d564:	48 c1 e2 10          	shl    $0x10,%rdx
    d568:	48 39 d0             	cmp    %rdx,%rax
    d56b:	73 59                	jae    d5c6 <f0+0x1ee6>
    d56d:	48 89 c2             	mov    %rax,%rdx
    d570:	48 c1 ea 10          	shr    $0x10,%rdx
    d574:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d578:	48 8b 15 79 f6 05 00 	mov    0x5f679(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d57f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d583:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d587:	4d 85 e4             	test   %r12,%r12
    d58a:	74 3a                	je     d5c6 <f0+0x1ee6>
    d58c:	0f b6 0a             	movzbl (%rdx),%ecx
    d58f:	80 f9 02             	cmp    $0x2,%cl
    d592:	0f 84 38 0c 00 00    	je     e1d0 <f0+0x2af0>
    d598:	80 f9 01             	cmp    $0x1,%cl
    d59b:	75 29                	jne    d5c6 <f0+0x1ee6>
    d59d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5a0:	0f b7 c0             	movzwl %ax,%eax
    d5a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5a6:	48 0f af c1          	imul   %rcx,%rax
    d5aa:	48 c1 e8 20          	shr    $0x20,%rax
    d5ae:	48 39 d0             	cmp    %rdx,%rax
    d5b1:	73 13                	jae    d5c6 <f0+0x1ee6>
    d5b3:	49 01 c4             	add    %rax,%r12
    d5b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5bb:	0f 84 55 0d 00 00    	je     e316 <f0+0x2c36>
    d5c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5c6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5cd:	33 f3 bf 
    d5d0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d5d7:	00 
    d5d8:	bf 01 00 00 00       	mov    $0x1,%edi
    d5dd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d5e4:	00 
    d5e5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d5ec:	00 
    d5ed:	e8 ae 8a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d5f2:	48 8b 15 df f5 05 00 	mov    0x5f5df(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d5f9:	49 89 c5             	mov    %rax,%r13
    d5fc:	48 2b 05 ad f5 05 00 	sub    0x5f5ad(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d603:	48 c1 e2 10          	shl    $0x10,%rdx
    d607:	48 39 d0             	cmp    %rdx,%rax
    d60a:	73 59                	jae    d665 <f0+0x1f85>
    d60c:	48 89 c2             	mov    %rax,%rdx
    d60f:	48 c1 ea 10          	shr    $0x10,%rdx
    d613:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d617:	48 8b 15 da f5 05 00 	mov    0x5f5da(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d61e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d622:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d626:	4d 85 e4             	test   %r12,%r12
    d629:	74 3a                	je     d665 <f0+0x1f85>
    d62b:	0f b6 0a             	movzbl (%rdx),%ecx
    d62e:	80 f9 02             	cmp    $0x2,%cl
    d631:	0f 84 89 0b 00 00    	je     e1c0 <f0+0x2ae0>
    d637:	80 f9 01             	cmp    $0x1,%cl
    d63a:	75 29                	jne    d665 <f0+0x1f85>
    d63c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d63f:	0f b7 c0             	movzwl %ax,%eax
    d642:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d645:	48 0f af c1          	imul   %rcx,%rax
    d649:	48 c1 e8 20          	shr    $0x20,%rax
    d64d:	48 39 d0             	cmp    %rdx,%rax
    d650:	73 13                	jae    d665 <f0+0x1f85>
    d652:	49 01 c4             	add    %rax,%r12
    d655:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d65a:	0f 84 c3 0c 00 00    	je     e323 <f0+0x2c43>
    d660:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d665:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d66c:	00 f0 3f 
    d66f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d676:	00 
    d677:	bf 01 00 00 00       	mov    $0x1,%edi
    d67c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d683:	00 
    d684:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d68b:	00 
    d68c:	e8 0f 8a ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d691:	48 8b 15 40 f5 05 00 	mov    0x5f540(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d698:	49 89 c5             	mov    %rax,%r13
    d69b:	48 2b 05 0e f5 05 00 	sub    0x5f50e(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d6a2:	48 c1 e2 10          	shl    $0x10,%rdx
    d6a6:	48 39 d0             	cmp    %rdx,%rax
    d6a9:	73 59                	jae    d704 <f0+0x2024>
    d6ab:	48 89 c2             	mov    %rax,%rdx
    d6ae:	48 c1 ea 10          	shr    $0x10,%rdx
    d6b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6b6:	48 8b 15 3b f5 05 00 	mov    0x5f53b(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d6bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6c1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6c5:	4d 85 e4             	test   %r12,%r12
    d6c8:	74 3a                	je     d704 <f0+0x2024>
    d6ca:	0f b6 0a             	movzbl (%rdx),%ecx
    d6cd:	80 f9 02             	cmp    $0x2,%cl
    d6d0:	0f 84 da 0a 00 00    	je     e1b0 <f0+0x2ad0>
    d6d6:	80 f9 01             	cmp    $0x1,%cl
    d6d9:	75 29                	jne    d704 <f0+0x2024>
    d6db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6de:	0f b7 c0             	movzwl %ax,%eax
    d6e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6e4:	48 0f af c1          	imul   %rcx,%rax
    d6e8:	48 c1 e8 20          	shr    $0x20,%rax
    d6ec:	48 39 d0             	cmp    %rdx,%rax
    d6ef:	73 13                	jae    d704 <f0+0x2024>
    d6f1:	49 01 c4             	add    %rax,%r12
    d6f4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6f9:	0f 84 31 0c 00 00    	je     e330 <f0+0x2c50>
    d6ff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d704:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d70b:	33 f3 bf 
    d70e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d715:	00 
    d716:	bf 01 00 00 00       	mov    $0x1,%edi
    d71b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d722:	00 
    d723:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d72a:	00 
    d72b:	e8 70 89 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d730:	48 8b 15 a1 f4 05 00 	mov    0x5f4a1(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d737:	49 89 c5             	mov    %rax,%r13
    d73a:	48 2b 05 6f f4 05 00 	sub    0x5f46f(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d741:	48 c1 e2 10          	shl    $0x10,%rdx
    d745:	48 39 d0             	cmp    %rdx,%rax
    d748:	73 59                	jae    d7a3 <f0+0x20c3>
    d74a:	48 89 c2             	mov    %rax,%rdx
    d74d:	48 c1 ea 10          	shr    $0x10,%rdx
    d751:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d755:	48 8b 15 9c f4 05 00 	mov    0x5f49c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d75c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d760:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d764:	4d 85 e4             	test   %r12,%r12
    d767:	74 3a                	je     d7a3 <f0+0x20c3>
    d769:	0f b6 0a             	movzbl (%rdx),%ecx
    d76c:	80 f9 02             	cmp    $0x2,%cl
    d76f:	0f 84 2b 0a 00 00    	je     e1a0 <f0+0x2ac0>
    d775:	80 f9 01             	cmp    $0x1,%cl
    d778:	75 29                	jne    d7a3 <f0+0x20c3>
    d77a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d77d:	0f b7 c0             	movzwl %ax,%eax
    d780:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d783:	48 0f af c1          	imul   %rcx,%rax
    d787:	48 c1 e8 20          	shr    $0x20,%rax
    d78b:	48 39 d0             	cmp    %rdx,%rax
    d78e:	73 13                	jae    d7a3 <f0+0x20c3>
    d790:	49 01 c4             	add    %rax,%r12
    d793:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d798:	0f 84 9f 0b 00 00    	je     e33d <f0+0x2c5d>
    d79e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7a3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7aa:	00 f0 3f 
    d7ad:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d7b4:	00 
    d7b5:	bf 01 00 00 00       	mov    $0x1,%edi
    d7ba:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d7c1:	00 
    d7c2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d7c9:	00 
    d7ca:	e8 d1 88 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d7cf:	48 8b 15 02 f4 05 00 	mov    0x5f402(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d7d6:	49 89 c5             	mov    %rax,%r13
    d7d9:	48 2b 05 d0 f3 05 00 	sub    0x5f3d0(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d7e0:	48 c1 e2 10          	shl    $0x10,%rdx
    d7e4:	48 39 d0             	cmp    %rdx,%rax
    d7e7:	73 59                	jae    d842 <f0+0x2162>
    d7e9:	48 89 c2             	mov    %rax,%rdx
    d7ec:	48 c1 ea 10          	shr    $0x10,%rdx
    d7f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7f4:	48 8b 15 fd f3 05 00 	mov    0x5f3fd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d7fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d803:	4d 85 e4             	test   %r12,%r12
    d806:	74 3a                	je     d842 <f0+0x2162>
    d808:	0f b6 0a             	movzbl (%rdx),%ecx
    d80b:	80 f9 02             	cmp    $0x2,%cl
    d80e:	0f 84 7c 09 00 00    	je     e190 <f0+0x2ab0>
    d814:	80 f9 01             	cmp    $0x1,%cl
    d817:	75 29                	jne    d842 <f0+0x2162>
    d819:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d81c:	0f b7 c0             	movzwl %ax,%eax
    d81f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d822:	48 0f af c1          	imul   %rcx,%rax
    d826:	48 c1 e8 20          	shr    $0x20,%rax
    d82a:	48 39 d0             	cmp    %rdx,%rax
    d82d:	73 13                	jae    d842 <f0+0x2162>
    d82f:	49 01 c4             	add    %rax,%r12
    d832:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d837:	0f 84 0d 0b 00 00    	je     e34a <f0+0x2c6a>
    d83d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d842:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d849:	33 f3 bf 
    d84c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d853:	00 
    d854:	bf 01 00 00 00       	mov    $0x1,%edi
    d859:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d860:	00 
    d861:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d868:	00 
    d869:	e8 32 88 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d86e:	48 8b 15 63 f3 05 00 	mov    0x5f363(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d875:	49 89 c5             	mov    %rax,%r13
    d878:	48 2b 05 31 f3 05 00 	sub    0x5f331(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d87f:	48 c1 e2 10          	shl    $0x10,%rdx
    d883:	48 39 d0             	cmp    %rdx,%rax
    d886:	73 59                	jae    d8e1 <f0+0x2201>
    d888:	48 89 c2             	mov    %rax,%rdx
    d88b:	48 c1 ea 10          	shr    $0x10,%rdx
    d88f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d893:	48 8b 15 5e f3 05 00 	mov    0x5f35e(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d89a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d89e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8a2:	4d 85 e4             	test   %r12,%r12
    d8a5:	74 3a                	je     d8e1 <f0+0x2201>
    d8a7:	0f b6 0a             	movzbl (%rdx),%ecx
    d8aa:	80 f9 02             	cmp    $0x2,%cl
    d8ad:	0f 84 cd 08 00 00    	je     e180 <f0+0x2aa0>
    d8b3:	80 f9 01             	cmp    $0x1,%cl
    d8b6:	75 29                	jne    d8e1 <f0+0x2201>
    d8b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8bb:	0f b7 c0             	movzwl %ax,%eax
    d8be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8c1:	48 0f af c1          	imul   %rcx,%rax
    d8c5:	48 c1 e8 20          	shr    $0x20,%rax
    d8c9:	48 39 d0             	cmp    %rdx,%rax
    d8cc:	73 13                	jae    d8e1 <f0+0x2201>
    d8ce:	49 01 c4             	add    %rax,%r12
    d8d1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8d6:	0f 84 7b 0a 00 00    	je     e357 <f0+0x2c77>
    d8dc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8e1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8e8:	00 f0 3f 
    d8eb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d8f2:	00 
    d8f3:	bf 01 00 00 00       	mov    $0x1,%edi
    d8f8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d8ff:	00 
    d900:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d907:	00 
    d908:	e8 93 87 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d90d:	48 8b 15 c4 f2 05 00 	mov    0x5f2c4(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d914:	49 89 c5             	mov    %rax,%r13
    d917:	48 2b 05 92 f2 05 00 	sub    0x5f292(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d91e:	48 c1 e2 10          	shl    $0x10,%rdx
    d922:	48 39 d0             	cmp    %rdx,%rax
    d925:	73 59                	jae    d980 <f0+0x22a0>
    d927:	48 89 c2             	mov    %rax,%rdx
    d92a:	48 c1 ea 10          	shr    $0x10,%rdx
    d92e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d932:	48 8b 15 bf f2 05 00 	mov    0x5f2bf(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d939:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d93d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d941:	4d 85 e4             	test   %r12,%r12
    d944:	74 3a                	je     d980 <f0+0x22a0>
    d946:	0f b6 0a             	movzbl (%rdx),%ecx
    d949:	80 f9 02             	cmp    $0x2,%cl
    d94c:	0f 84 1e 08 00 00    	je     e170 <f0+0x2a90>
    d952:	80 f9 01             	cmp    $0x1,%cl
    d955:	75 29                	jne    d980 <f0+0x22a0>
    d957:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d95a:	0f b7 c0             	movzwl %ax,%eax
    d95d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d960:	48 0f af c1          	imul   %rcx,%rax
    d964:	48 c1 e8 20          	shr    $0x20,%rax
    d968:	48 39 d0             	cmp    %rdx,%rax
    d96b:	73 13                	jae    d980 <f0+0x22a0>
    d96d:	49 01 c4             	add    %rax,%r12
    d970:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d975:	0f 84 e9 09 00 00    	je     e364 <f0+0x2c84>
    d97b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d980:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d987:	33 f3 bf 
    d98a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d991:	00 
    d992:	bf 01 00 00 00       	mov    $0x1,%edi
    d997:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d99e:	00 
    d99f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d9a6:	00 
    d9a7:	e8 f4 86 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    d9ac:	48 8b 15 25 f2 05 00 	mov    0x5f225(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    d9b3:	49 89 c5             	mov    %rax,%r13
    d9b6:	48 2b 05 f3 f1 05 00 	sub    0x5f1f3(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    d9bd:	48 c1 e2 10          	shl    $0x10,%rdx
    d9c1:	48 39 d0             	cmp    %rdx,%rax
    d9c4:	73 59                	jae    da1f <f0+0x233f>
    d9c6:	48 89 c2             	mov    %rax,%rdx
    d9c9:	48 c1 ea 10          	shr    $0x10,%rdx
    d9cd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9d1:	48 8b 15 20 f2 05 00 	mov    0x5f220(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    d9d8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9dc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9e0:	4d 85 e4             	test   %r12,%r12
    d9e3:	74 3a                	je     da1f <f0+0x233f>
    d9e5:	0f b6 0a             	movzbl (%rdx),%ecx
    d9e8:	80 f9 02             	cmp    $0x2,%cl
    d9eb:	0f 84 6f 07 00 00    	je     e160 <f0+0x2a80>
    d9f1:	80 f9 01             	cmp    $0x1,%cl
    d9f4:	75 29                	jne    da1f <f0+0x233f>
    d9f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9f9:	0f b7 c0             	movzwl %ax,%eax
    d9fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9ff:	48 0f af c1          	imul   %rcx,%rax
    da03:	48 c1 e8 20          	shr    $0x20,%rax
    da07:	48 39 d0             	cmp    %rdx,%rax
    da0a:	73 13                	jae    da1f <f0+0x233f>
    da0c:	49 01 c4             	add    %rax,%r12
    da0f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da14:	0f 84 57 09 00 00    	je     e371 <f0+0x2c91>
    da1a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da1f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da26:	00 f0 3f 
    da29:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    da30:	00 
    da31:	bf 01 00 00 00       	mov    $0x1,%edi
    da36:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    da3d:	00 
    da3e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    da45:	00 
    da46:	e8 55 86 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    da4b:	48 8b 15 86 f1 05 00 	mov    0x5f186(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    da52:	49 89 c5             	mov    %rax,%r13
    da55:	48 2b 05 54 f1 05 00 	sub    0x5f154(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    da5c:	48 c1 e2 10          	shl    $0x10,%rdx
    da60:	48 39 d0             	cmp    %rdx,%rax
    da63:	73 59                	jae    dabe <f0+0x23de>
    da65:	48 89 c2             	mov    %rax,%rdx
    da68:	48 c1 ea 10          	shr    $0x10,%rdx
    da6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da70:	48 8b 15 81 f1 05 00 	mov    0x5f181(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    da77:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da7b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da7f:	4d 85 e4             	test   %r12,%r12
    da82:	74 3a                	je     dabe <f0+0x23de>
    da84:	0f b6 0a             	movzbl (%rdx),%ecx
    da87:	80 f9 02             	cmp    $0x2,%cl
    da8a:	0f 84 c0 06 00 00    	je     e150 <f0+0x2a70>
    da90:	80 f9 01             	cmp    $0x1,%cl
    da93:	75 29                	jne    dabe <f0+0x23de>
    da95:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da98:	0f b7 c0             	movzwl %ax,%eax
    da9b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da9e:	48 0f af c1          	imul   %rcx,%rax
    daa2:	48 c1 e8 20          	shr    $0x20,%rax
    daa6:	48 39 d0             	cmp    %rdx,%rax
    daa9:	73 13                	jae    dabe <f0+0x23de>
    daab:	49 01 c4             	add    %rax,%r12
    daae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dab3:	0f 84 c5 08 00 00    	je     e37e <f0+0x2c9e>
    dab9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dabe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dac5:	33 f3 bf 
    dac8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    dacf:	00 
    dad0:	bf 01 00 00 00       	mov    $0x1,%edi
    dad5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    dadc:	00 
    dadd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    dae4:	00 
    dae5:	e8 b6 85 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    daea:	48 8b 15 e7 f0 05 00 	mov    0x5f0e7(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    daf1:	49 89 c5             	mov    %rax,%r13
    daf4:	48 2b 05 b5 f0 05 00 	sub    0x5f0b5(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    dafb:	48 c1 e2 10          	shl    $0x10,%rdx
    daff:	48 39 d0             	cmp    %rdx,%rax
    db02:	73 59                	jae    db5d <f0+0x247d>
    db04:	48 89 c2             	mov    %rax,%rdx
    db07:	48 c1 ea 10          	shr    $0x10,%rdx
    db0b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db0f:	48 8b 15 e2 f0 05 00 	mov    0x5f0e2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    db16:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db1a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db1e:	4d 85 e4             	test   %r12,%r12
    db21:	74 3a                	je     db5d <f0+0x247d>
    db23:	0f b6 0a             	movzbl (%rdx),%ecx
    db26:	80 f9 02             	cmp    $0x2,%cl
    db29:	0f 84 11 06 00 00    	je     e140 <f0+0x2a60>
    db2f:	80 f9 01             	cmp    $0x1,%cl
    db32:	75 29                	jne    db5d <f0+0x247d>
    db34:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db37:	0f b7 c0             	movzwl %ax,%eax
    db3a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db3d:	48 0f af c1          	imul   %rcx,%rax
    db41:	48 c1 e8 20          	shr    $0x20,%rax
    db45:	48 39 d0             	cmp    %rdx,%rax
    db48:	73 13                	jae    db5d <f0+0x247d>
    db4a:	49 01 c4             	add    %rax,%r12
    db4d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db52:	0f 84 33 08 00 00    	je     e38b <f0+0x2cab>
    db58:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db5d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db64:	00 f0 3f 
    db67:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    db6e:	00 
    db6f:	bf 01 00 00 00       	mov    $0x1,%edi
    db74:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    db7b:	00 
    db7c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    db83:	00 
    db84:	e8 17 85 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    db89:	48 8b 15 48 f0 05 00 	mov    0x5f048(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    db90:	49 89 c5             	mov    %rax,%r13
    db93:	48 2b 05 16 f0 05 00 	sub    0x5f016(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    db9a:	48 c1 e2 10          	shl    $0x10,%rdx
    db9e:	48 39 d0             	cmp    %rdx,%rax
    dba1:	73 59                	jae    dbfc <f0+0x251c>
    dba3:	48 89 c2             	mov    %rax,%rdx
    dba6:	48 c1 ea 10          	shr    $0x10,%rdx
    dbaa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbae:	48 8b 15 43 f0 05 00 	mov    0x5f043(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    dbb5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbb9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbbd:	4d 85 e4             	test   %r12,%r12
    dbc0:	74 3a                	je     dbfc <f0+0x251c>
    dbc2:	0f b6 0a             	movzbl (%rdx),%ecx
    dbc5:	80 f9 02             	cmp    $0x2,%cl
    dbc8:	0f 84 62 05 00 00    	je     e130 <f0+0x2a50>
    dbce:	80 f9 01             	cmp    $0x1,%cl
    dbd1:	75 29                	jne    dbfc <f0+0x251c>
    dbd3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbd6:	0f b7 c0             	movzwl %ax,%eax
    dbd9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbdc:	48 0f af c1          	imul   %rcx,%rax
    dbe0:	48 c1 e8 20          	shr    $0x20,%rax
    dbe4:	48 39 d0             	cmp    %rdx,%rax
    dbe7:	73 13                	jae    dbfc <f0+0x251c>
    dbe9:	49 01 c4             	add    %rax,%r12
    dbec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbf1:	0f 84 a1 07 00 00    	je     e398 <f0+0x2cb8>
    dbf7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dbfc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc03:	33 f3 bf 
    dc06:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    dc0d:	00 
    dc0e:	bf 01 00 00 00       	mov    $0x1,%edi
    dc13:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    dc1a:	00 
    dc1b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    dc22:	00 
    dc23:	e8 78 84 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    dc28:	48 8b 15 a9 ef 05 00 	mov    0x5efa9(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    dc2f:	49 89 c5             	mov    %rax,%r13
    dc32:	48 2b 05 77 ef 05 00 	sub    0x5ef77(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    dc39:	48 c1 e2 10          	shl    $0x10,%rdx
    dc3d:	48 39 d0             	cmp    %rdx,%rax
    dc40:	73 59                	jae    dc9b <f0+0x25bb>
    dc42:	48 89 c2             	mov    %rax,%rdx
    dc45:	48 c1 ea 10          	shr    $0x10,%rdx
    dc49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc4d:	48 8b 15 a4 ef 05 00 	mov    0x5efa4(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    dc54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc58:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc5c:	4d 85 e4             	test   %r12,%r12
    dc5f:	74 3a                	je     dc9b <f0+0x25bb>
    dc61:	0f b6 0a             	movzbl (%rdx),%ecx
    dc64:	80 f9 02             	cmp    $0x2,%cl
    dc67:	0f 84 b3 04 00 00    	je     e120 <f0+0x2a40>
    dc6d:	80 f9 01             	cmp    $0x1,%cl
    dc70:	75 29                	jne    dc9b <f0+0x25bb>
    dc72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc75:	0f b7 c0             	movzwl %ax,%eax
    dc78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc7b:	48 0f af c1          	imul   %rcx,%rax
    dc7f:	48 c1 e8 20          	shr    $0x20,%rax
    dc83:	48 39 d0             	cmp    %rdx,%rax
    dc86:	73 13                	jae    dc9b <f0+0x25bb>
    dc88:	49 01 c4             	add    %rax,%r12
    dc8b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc90:	0f 84 0f 07 00 00    	je     e3a5 <f0+0x2cc5>
    dc96:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc9b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dca2:	00 f0 3f 
    dca5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    dcac:	00 
    dcad:	bf 01 00 00 00       	mov    $0x1,%edi
    dcb2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    dcb9:	00 
    dcba:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    dcc1:	00 
    dcc2:	e8 d9 83 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    dcc7:	48 8b 15 0a ef 05 00 	mov    0x5ef0a(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    dcce:	49 89 c5             	mov    %rax,%r13
    dcd1:	48 2b 05 d8 ee 05 00 	sub    0x5eed8(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    dcd8:	48 c1 e2 10          	shl    $0x10,%rdx
    dcdc:	48 39 d0             	cmp    %rdx,%rax
    dcdf:	73 59                	jae    dd3a <f0+0x265a>
    dce1:	48 89 c2             	mov    %rax,%rdx
    dce4:	48 c1 ea 10          	shr    $0x10,%rdx
    dce8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcec:	48 8b 15 05 ef 05 00 	mov    0x5ef05(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    dcf3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dcf7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dcfb:	4d 85 e4             	test   %r12,%r12
    dcfe:	74 3a                	je     dd3a <f0+0x265a>
    dd00:	0f b6 0a             	movzbl (%rdx),%ecx
    dd03:	80 f9 02             	cmp    $0x2,%cl
    dd06:	0f 84 04 04 00 00    	je     e110 <f0+0x2a30>
    dd0c:	80 f9 01             	cmp    $0x1,%cl
    dd0f:	75 29                	jne    dd3a <f0+0x265a>
    dd11:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd14:	0f b7 c0             	movzwl %ax,%eax
    dd17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd1a:	48 0f af c1          	imul   %rcx,%rax
    dd1e:	48 c1 e8 20          	shr    $0x20,%rax
    dd22:	48 39 d0             	cmp    %rdx,%rax
    dd25:	73 13                	jae    dd3a <f0+0x265a>
    dd27:	49 01 c4             	add    %rax,%r12
    dd2a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd2f:	0f 84 7d 06 00 00    	je     e3b2 <f0+0x2cd2>
    dd35:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd3a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd41:	33 f3 bf 
    dd44:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dd4b:	00 
    dd4c:	bf 01 00 00 00       	mov    $0x1,%edi
    dd51:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dd58:	00 
    dd59:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    dd60:	00 
    dd61:	e8 3a 83 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    dd66:	48 8b 15 6b ee 05 00 	mov    0x5ee6b(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    dd6d:	49 89 c5             	mov    %rax,%r13
    dd70:	48 2b 05 39 ee 05 00 	sub    0x5ee39(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    dd77:	48 c1 e2 10          	shl    $0x10,%rdx
    dd7b:	48 39 d0             	cmp    %rdx,%rax
    dd7e:	73 59                	jae    ddd9 <f0+0x26f9>
    dd80:	48 89 c2             	mov    %rax,%rdx
    dd83:	48 c1 ea 10          	shr    $0x10,%rdx
    dd87:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd8b:	48 8b 15 66 ee 05 00 	mov    0x5ee66(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    dd92:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd96:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd9a:	4d 85 e4             	test   %r12,%r12
    dd9d:	74 3a                	je     ddd9 <f0+0x26f9>
    dd9f:	0f b6 0a             	movzbl (%rdx),%ecx
    dda2:	80 f9 02             	cmp    $0x2,%cl
    dda5:	0f 84 55 03 00 00    	je     e100 <f0+0x2a20>
    ddab:	80 f9 01             	cmp    $0x1,%cl
    ddae:	75 29                	jne    ddd9 <f0+0x26f9>
    ddb0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddb3:	0f b7 c0             	movzwl %ax,%eax
    ddb6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ddb9:	48 0f af c1          	imul   %rcx,%rax
    ddbd:	48 c1 e8 20          	shr    $0x20,%rax
    ddc1:	48 39 d0             	cmp    %rdx,%rax
    ddc4:	73 13                	jae    ddd9 <f0+0x26f9>
    ddc6:	49 01 c4             	add    %rax,%r12
    ddc9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddce:	0f 84 eb 05 00 00    	je     e3bf <f0+0x2cdf>
    ddd4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ddd9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dde0:	00 f0 3f 
    dde3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    ddea:	00 
    ddeb:	bf 01 00 00 00       	mov    $0x1,%edi
    ddf0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    ddf7:	00 
    ddf8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    ddff:	00 
    de00:	e8 9b 82 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    de05:	48 8b 15 cc ed 05 00 	mov    0x5edcc(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    de0c:	49 89 c5             	mov    %rax,%r13
    de0f:	48 2b 05 9a ed 05 00 	sub    0x5ed9a(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    de16:	48 c1 e2 10          	shl    $0x10,%rdx
    de1a:	48 39 d0             	cmp    %rdx,%rax
    de1d:	73 59                	jae    de78 <f0+0x2798>
    de1f:	48 89 c2             	mov    %rax,%rdx
    de22:	48 c1 ea 10          	shr    $0x10,%rdx
    de26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de2a:	48 8b 15 c7 ed 05 00 	mov    0x5edc7(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    de31:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de35:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de39:	4d 85 e4             	test   %r12,%r12
    de3c:	74 3a                	je     de78 <f0+0x2798>
    de3e:	0f b6 0a             	movzbl (%rdx),%ecx
    de41:	80 f9 02             	cmp    $0x2,%cl
    de44:	0f 84 a6 02 00 00    	je     e0f0 <f0+0x2a10>
    de4a:	80 f9 01             	cmp    $0x1,%cl
    de4d:	75 29                	jne    de78 <f0+0x2798>
    de4f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de52:	0f b7 c0             	movzwl %ax,%eax
    de55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de58:	48 0f af c1          	imul   %rcx,%rax
    de5c:	48 c1 e8 20          	shr    $0x20,%rax
    de60:	48 39 d0             	cmp    %rdx,%rax
    de63:	73 13                	jae    de78 <f0+0x2798>
    de65:	49 01 c4             	add    %rax,%r12
    de68:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de6d:	0f 84 59 05 00 00    	je     e3cc <f0+0x2cec>
    de73:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de78:	48 89 ee             	mov    %rbp,%rsi
    de7b:	bf 01 00 00 00       	mov    $0x1,%edi
    de80:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de87:	33 f3 bf 
    de8a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    de91:	00 
    de92:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    de99:	00 
    de9a:	e8 01 82 ff ff       	call   60a0 <fwp_data.part.0.constprop.0>
    de9f:	48 8b 15 32 ed 05 00 	mov    0x5ed32(%rip),%rdx        # 6cbd8 <fwp_heap+0x13d8>
    dea6:	48 89 c5             	mov    %rax,%rbp
    dea9:	48 2b 05 00 ed 05 00 	sub    0x5ed00(%rip),%rax        # 6cbb0 <fwp_heap+0x13b0>
    deb0:	48 c1 e2 10          	shl    $0x10,%rdx
    deb4:	48 39 d0             	cmp    %rdx,%rax
    deb7:	73 59                	jae    df12 <f0+0x2832>
    deb9:	48 89 c2             	mov    %rax,%rdx
    debc:	48 c1 ea 10          	shr    $0x10,%rdx
    dec0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dec4:	48 8b 15 2d ed 05 00 	mov    0x5ed2d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13f8>
    decb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    decf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ded3:	4d 85 e4             	test   %r12,%r12
    ded6:	74 3a                	je     df12 <f0+0x2832>
    ded8:	0f b6 0a             	movzbl (%rdx),%ecx
    dedb:	80 f9 02             	cmp    $0x2,%cl
    dede:	0f 84 fc 01 00 00    	je     e0e0 <f0+0x2a00>
    dee4:	80 f9 01             	cmp    $0x1,%cl
    dee7:	75 29                	jne    df12 <f0+0x2832>
    dee9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    deec:	0f b7 c0             	movzwl %ax,%eax
    deef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    def2:	48 0f af c1          	imul   %rcx,%rax
    def6:	48 c1 e8 20          	shr    $0x20,%rax
    defa:	48 39 d0             	cmp    %rdx,%rax
    defd:	73 13                	jae    df12 <f0+0x2832>
    deff:	49 01 c4             	add    %rax,%r12
    df02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df07:	0f 84 d1 02 00 00    	je     e1de <f0+0x2afe>
    df0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df12:	48 89 de             	mov    %rbx,%rsi
    df15:	48 89 ef             	mov    %rbp,%rdi
    df18:	e8 f3 bd ff ff       	call   9d10 <fwp_hof0.constprop.0>
    df1d:	48 89 ef             	mov    %rbp,%rdi
    df20:	e8 5b a2 ff ff       	call   8180 <fwp_drop0>
    df25:	48 89 df             	mov    %rbx,%rdi
    df28:	e8 53 a2 ff ff       	call   8180 <fwp_drop0>
    df2d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    df34:	00 
    df35:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    df3c:	00 00 
    df3e:	0f 85 95 04 00 00    	jne    e3d9 <f0+0x2cf9>
    df44:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    df4b:	31 c0                	xor    %eax,%eax
    df4d:	5b                   	pop    %rbx
    df4e:	5d                   	pop    %rbp
    df4f:	41 5c                	pop    %r12
    df51:	41 5d                	pop    %r13
    df53:	41 5e                	pop    %r14
    df55:	c3                   	ret
    df56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df5d:	00 00 00 
    df60:	4c 89 ef             	mov    %r13,%rdi
    df63:	e8 08 78 ff ff       	call   5770 <fwp_rc_forget_slot>
    df68:	e9 2c d8 ff ff       	jmp    b799 <f0+0xb9>
    df6d:	0f 1f 00             	nopl   (%rax)
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 ae f5 ff ff    	jne    d527 <f0+0x1e47>
    df79:	e9 99 f5 ff ff       	jmp    d517 <f0+0x1e37>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 ff f4 ff ff    	jne    d488 <f0+0x1da8>
    df89:	e9 ea f4 ff ff       	jmp    d478 <f0+0x1d98>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 50 f4 ff ff    	jne    d3e9 <f0+0x1d09>
    df99:	e9 3b f4 ff ff       	jmp    d3d9 <f0+0x1cf9>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 a1 f3 ff ff    	jne    d34a <f0+0x1c6a>
    dfa9:	e9 8c f3 ff ff       	jmp    d33a <f0+0x1c5a>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 f2 f2 ff ff    	jne    d2ab <f0+0x1bcb>
    dfb9:	e9 dd f2 ff ff       	jmp    d29b <f0+0x1bbb>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 43 f2 ff ff    	jne    d20c <f0+0x1b2c>
    dfc9:	e9 2e f2 ff ff       	jmp    d1fc <f0+0x1b1c>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 94 f1 ff ff    	jne    d16d <f0+0x1a8d>
    dfd9:	e9 7f f1 ff ff       	jmp    d15d <f0+0x1a7d>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	66 85 c0             	test   %ax,%ax
    dfe3:	0f 85 e5 f0 ff ff    	jne    d0ce <f0+0x19ee>
    dfe9:	e9 d0 f0 ff ff       	jmp    d0be <f0+0x19de>
    dfee:	66 90                	xchg   %ax,%ax
    dff0:	66 85 c0             	test   %ax,%ax
    dff3:	0f 85 fd d9 ff ff    	jne    b9f6 <f0+0x316>
    dff9:	e9 e8 d9 ff ff       	jmp    b9e6 <f0+0x306>
    dffe:	66 90                	xchg   %ax,%ax
    e000:	66 85 c0             	test   %ax,%ax
    e003:	0f 85 57 d9 ff ff    	jne    b960 <f0+0x280>
    e009:	e9 42 d9 ff ff       	jmp    b950 <f0+0x270>
    e00e:	66 90                	xchg   %ax,%ax
    e010:	66 85 c0             	test   %ax,%ax
    e013:	0f 85 b1 d8 ff ff    	jne    b8ca <f0+0x1ea>
    e019:	e9 9c d8 ff ff       	jmp    b8ba <f0+0x1da>
    e01e:	66 90                	xchg   %ax,%ax
    e020:	66 85 c0             	test   %ax,%ax
    e023:	0f 85 0e eb ff ff    	jne    cb37 <f0+0x1457>
    e029:	e9 f9 ea ff ff       	jmp    cb27 <f0+0x1447>
    e02e:	66 90                	xchg   %ax,%ax
    e030:	66 85 c0             	test   %ax,%ax
    e033:	0f 85 5f ea ff ff    	jne    ca98 <f0+0x13b8>
    e039:	e9 4a ea ff ff       	jmp    ca88 <f0+0x13a8>
    e03e:	66 90                	xchg   %ax,%ax
    e040:	66 85 c0             	test   %ax,%ax
    e043:	0f 85 e2 da ff ff    	jne    bb2b <f0+0x44b>
    e049:	e9 cd da ff ff       	jmp    bb1b <f0+0x43b>
    e04e:	66 90                	xchg   %ax,%ax
    e050:	66 85 c0             	test   %ax,%ax
    e053:	0f 85 33 da ff ff    	jne    ba8c <f0+0x3ac>
    e059:	e9 1e da ff ff       	jmp    ba7c <f0+0x39c>
    e05e:	66 90                	xchg   %ax,%ax
    e060:	66 85 c0             	test   %ax,%ax
    e063:	0f 85 c6 ef ff ff    	jne    d02f <f0+0x194f>
    e069:	e9 b1 ef ff ff       	jmp    d01f <f0+0x193f>
    e06e:	66 90                	xchg   %ax,%ax
    e070:	66 85 c0             	test   %ax,%ax
    e073:	0f 85 17 ef ff ff    	jne    cf90 <f0+0x18b0>
    e079:	e9 02 ef ff ff       	jmp    cf80 <f0+0x18a0>
    e07e:	66 90                	xchg   %ax,%ax
    e080:	66 85 c0             	test   %ax,%ax
    e083:	0f 85 68 ee ff ff    	jne    cef1 <f0+0x1811>
    e089:	e9 53 ee ff ff       	jmp    cee1 <f0+0x1801>
    e08e:	66 90                	xchg   %ax,%ax
    e090:	66 85 c0             	test   %ax,%ax
    e093:	0f 85 b9 ed ff ff    	jne    ce52 <f0+0x1772>
    e099:	e9 a4 ed ff ff       	jmp    ce42 <f0+0x1762>
    e09e:	66 90                	xchg   %ax,%ax
    e0a0:	66 85 c0             	test   %ax,%ax
    e0a3:	0f 85 0a ed ff ff    	jne    cdb3 <f0+0x16d3>
    e0a9:	e9 f5 ec ff ff       	jmp    cda3 <f0+0x16c3>
    e0ae:	66 90                	xchg   %ax,%ax
    e0b0:	66 85 c0             	test   %ax,%ax
    e0b3:	0f 85 5b ec ff ff    	jne    cd14 <f0+0x1634>
    e0b9:	e9 46 ec ff ff       	jmp    cd04 <f0+0x1624>
    e0be:	66 90                	xchg   %ax,%ax
    e0c0:	66 85 c0             	test   %ax,%ax
    e0c3:	0f 85 ac eb ff ff    	jne    cc75 <f0+0x1595>
    e0c9:	e9 97 eb ff ff       	jmp    cc65 <f0+0x1585>
    e0ce:	66 90                	xchg   %ax,%ax
    e0d0:	66 85 c0             	test   %ax,%ax
    e0d3:	0f 85 fd ea ff ff    	jne    cbd6 <f0+0x14f6>
    e0d9:	e9 e8 ea ff ff       	jmp    cbc6 <f0+0x14e6>
    e0de:	66 90                	xchg   %ax,%ax
    e0e0:	66 85 c0             	test   %ax,%ax
    e0e3:	0f 85 29 fe ff ff    	jne    df12 <f0+0x2832>
    e0e9:	e9 14 fe ff ff       	jmp    df02 <f0+0x2822>
    e0ee:	66 90                	xchg   %ax,%ax
    e0f0:	66 85 c0             	test   %ax,%ax
    e0f3:	0f 85 7f fd ff ff    	jne    de78 <f0+0x2798>
    e0f9:	e9 6a fd ff ff       	jmp    de68 <f0+0x2788>
    e0fe:	66 90                	xchg   %ax,%ax
    e100:	66 85 c0             	test   %ax,%ax
    e103:	0f 85 d0 fc ff ff    	jne    ddd9 <f0+0x26f9>
    e109:	e9 bb fc ff ff       	jmp    ddc9 <f0+0x26e9>
    e10e:	66 90                	xchg   %ax,%ax
    e110:	66 85 c0             	test   %ax,%ax
    e113:	0f 85 21 fc ff ff    	jne    dd3a <f0+0x265a>
    e119:	e9 0c fc ff ff       	jmp    dd2a <f0+0x264a>
    e11e:	66 90                	xchg   %ax,%ax
    e120:	66 85 c0             	test   %ax,%ax
    e123:	0f 85 72 fb ff ff    	jne    dc9b <f0+0x25bb>
    e129:	e9 5d fb ff ff       	jmp    dc8b <f0+0x25ab>
    e12e:	66 90                	xchg   %ax,%ax
    e130:	66 85 c0             	test   %ax,%ax
    e133:	0f 85 c3 fa ff ff    	jne    dbfc <f0+0x251c>
    e139:	e9 ae fa ff ff       	jmp    dbec <f0+0x250c>
    e13e:	66 90                	xchg   %ax,%ax
    e140:	66 85 c0             	test   %ax,%ax
    e143:	0f 85 14 fa ff ff    	jne    db5d <f0+0x247d>
    e149:	e9 ff f9 ff ff       	jmp    db4d <f0+0x246d>
    e14e:	66 90                	xchg   %ax,%ax
    e150:	66 85 c0             	test   %ax,%ax
    e153:	0f 85 65 f9 ff ff    	jne    dabe <f0+0x23de>
    e159:	e9 50 f9 ff ff       	jmp    daae <f0+0x23ce>
    e15e:	66 90                	xchg   %ax,%ax
    e160:	66 85 c0             	test   %ax,%ax
    e163:	0f 85 b6 f8 ff ff    	jne    da1f <f0+0x233f>
    e169:	e9 a1 f8 ff ff       	jmp    da0f <f0+0x232f>
    e16e:	66 90                	xchg   %ax,%ax
    e170:	66 85 c0             	test   %ax,%ax
    e173:	0f 85 07 f8 ff ff    	jne    d980 <f0+0x22a0>
    e179:	e9 f2 f7 ff ff       	jmp    d970 <f0+0x2290>
    e17e:	66 90                	xchg   %ax,%ax
    e180:	66 85 c0             	test   %ax,%ax
    e183:	0f 85 58 f7 ff ff    	jne    d8e1 <f0+0x2201>
    e189:	e9 43 f7 ff ff       	jmp    d8d1 <f0+0x21f1>
    e18e:	66 90                	xchg   %ax,%ax
    e190:	66 85 c0             	test   %ax,%ax
    e193:	0f 85 a9 f6 ff ff    	jne    d842 <f0+0x2162>
    e199:	e9 94 f6 ff ff       	jmp    d832 <f0+0x2152>
    e19e:	66 90                	xchg   %ax,%ax
    e1a0:	66 85 c0             	test   %ax,%ax
    e1a3:	0f 85 fa f5 ff ff    	jne    d7a3 <f0+0x20c3>
    e1a9:	e9 e5 f5 ff ff       	jmp    d793 <f0+0x20b3>
    e1ae:	66 90                	xchg   %ax,%ax
    e1b0:	66 85 c0             	test   %ax,%ax
    e1b3:	0f 85 4b f5 ff ff    	jne    d704 <f0+0x2024>
    e1b9:	e9 36 f5 ff ff       	jmp    d6f4 <f0+0x2014>
    e1be:	66 90                	xchg   %ax,%ax
    e1c0:	66 85 c0             	test   %ax,%ax
    e1c3:	0f 85 9c f4 ff ff    	jne    d665 <f0+0x1f85>
    e1c9:	e9 87 f4 ff ff       	jmp    d655 <f0+0x1f75>
    e1ce:	66 90                	xchg   %ax,%ax
    e1d0:	66 85 c0             	test   %ax,%ax
    e1d3:	0f 85 ed f3 ff ff    	jne    d5c6 <f0+0x1ee6>
    e1d9:	e9 d8 f3 ff ff       	jmp    d5b6 <f0+0x1ed6>
    e1de:	4c 89 e7             	mov    %r12,%rdi
    e1e1:	e8 8a 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e1e6:	e9 22 fd ff ff       	jmp    df0d <f0+0x282d>
    e1eb:	4c 89 e7             	mov    %r12,%rdi
    e1ee:	e8 7d 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e1f3:	e9 cd d6 ff ff       	jmp    b8c5 <f0+0x1e5>
    e1f8:	4c 89 e7             	mov    %r12,%rdi
    e1fb:	e8 70 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e200:	e9 56 d7 ff ff       	jmp    b95b <f0+0x27b>
    e205:	4c 89 e7             	mov    %r12,%rdi
    e208:	e8 63 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e20d:	e9 df d7 ff ff       	jmp    b9f1 <f0+0x311>
    e212:	4c 89 e7             	mov    %r12,%rdi
    e215:	e8 56 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e21a:	e9 68 d8 ff ff       	jmp    ba87 <f0+0x3a7>
    e21f:	4c 89 e7             	mov    %r12,%rdi
    e222:	e8 49 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e227:	e9 fa d8 ff ff       	jmp    bb26 <f0+0x446>
    e22c:	4c 89 e7             	mov    %r12,%rdi
    e22f:	e8 3c 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e234:	e9 5a e8 ff ff       	jmp    ca93 <f0+0x13b3>
    e239:	4c 89 e7             	mov    %r12,%rdi
    e23c:	e8 2f 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e241:	e9 ec e8 ff ff       	jmp    cb32 <f0+0x1452>
    e246:	4c 89 e7             	mov    %r12,%rdi
    e249:	e8 22 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e24e:	e9 7e e9 ff ff       	jmp    cbd1 <f0+0x14f1>
    e253:	4c 89 e7             	mov    %r12,%rdi
    e256:	e8 15 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e25b:	e9 10 ea ff ff       	jmp    cc70 <f0+0x1590>
    e260:	4c 89 e7             	mov    %r12,%rdi
    e263:	e8 08 75 ff ff       	call   5770 <fwp_rc_forget_slot>
    e268:	e9 a2 ea ff ff       	jmp    cd0f <f0+0x162f>
    e26d:	4c 89 e7             	mov    %r12,%rdi
    e270:	e8 fb 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e275:	e9 34 eb ff ff       	jmp    cdae <f0+0x16ce>
    e27a:	4c 89 e7             	mov    %r12,%rdi
    e27d:	e8 ee 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e282:	e9 c6 eb ff ff       	jmp    ce4d <f0+0x176d>
    e287:	4c 89 e7             	mov    %r12,%rdi
    e28a:	e8 e1 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e28f:	e9 58 ec ff ff       	jmp    ceec <f0+0x180c>
    e294:	4c 89 e7             	mov    %r12,%rdi
    e297:	e8 d4 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e29c:	e9 ea ec ff ff       	jmp    cf8b <f0+0x18ab>
    e2a1:	4c 89 e7             	mov    %r12,%rdi
    e2a4:	e8 c7 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2a9:	e9 7c ed ff ff       	jmp    d02a <f0+0x194a>
    e2ae:	4c 89 e7             	mov    %r12,%rdi
    e2b1:	e8 ba 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2b6:	e9 0e ee ff ff       	jmp    d0c9 <f0+0x19e9>
    e2bb:	4c 89 e7             	mov    %r12,%rdi
    e2be:	e8 ad 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2c3:	e9 a0 ee ff ff       	jmp    d168 <f0+0x1a88>
    e2c8:	4c 89 e7             	mov    %r12,%rdi
    e2cb:	e8 a0 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2d0:	e9 32 ef ff ff       	jmp    d207 <f0+0x1b27>
    e2d5:	4c 89 e7             	mov    %r12,%rdi
    e2d8:	e8 93 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2dd:	e9 c4 ef ff ff       	jmp    d2a6 <f0+0x1bc6>
    e2e2:	4c 89 e7             	mov    %r12,%rdi
    e2e5:	e8 86 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2ea:	e9 56 f0 ff ff       	jmp    d345 <f0+0x1c65>
    e2ef:	4c 89 e7             	mov    %r12,%rdi
    e2f2:	e8 79 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e2f7:	e9 e8 f0 ff ff       	jmp    d3e4 <f0+0x1d04>
    e2fc:	4c 89 e7             	mov    %r12,%rdi
    e2ff:	e8 6c 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e304:	e9 7a f1 ff ff       	jmp    d483 <f0+0x1da3>
    e309:	4c 89 e7             	mov    %r12,%rdi
    e30c:	e8 5f 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e311:	e9 0c f2 ff ff       	jmp    d522 <f0+0x1e42>
    e316:	4c 89 e7             	mov    %r12,%rdi
    e319:	e8 52 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e31e:	e9 9e f2 ff ff       	jmp    d5c1 <f0+0x1ee1>
    e323:	4c 89 e7             	mov    %r12,%rdi
    e326:	e8 45 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e32b:	e9 30 f3 ff ff       	jmp    d660 <f0+0x1f80>
    e330:	4c 89 e7             	mov    %r12,%rdi
    e333:	e8 38 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e338:	e9 c2 f3 ff ff       	jmp    d6ff <f0+0x201f>
    e33d:	4c 89 e7             	mov    %r12,%rdi
    e340:	e8 2b 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e345:	e9 54 f4 ff ff       	jmp    d79e <f0+0x20be>
    e34a:	4c 89 e7             	mov    %r12,%rdi
    e34d:	e8 1e 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e352:	e9 e6 f4 ff ff       	jmp    d83d <f0+0x215d>
    e357:	4c 89 e7             	mov    %r12,%rdi
    e35a:	e8 11 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e35f:	e9 78 f5 ff ff       	jmp    d8dc <f0+0x21fc>
    e364:	4c 89 e7             	mov    %r12,%rdi
    e367:	e8 04 74 ff ff       	call   5770 <fwp_rc_forget_slot>
    e36c:	e9 0a f6 ff ff       	jmp    d97b <f0+0x229b>
    e371:	4c 89 e7             	mov    %r12,%rdi
    e374:	e8 f7 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e379:	e9 9c f6 ff ff       	jmp    da1a <f0+0x233a>
    e37e:	4c 89 e7             	mov    %r12,%rdi
    e381:	e8 ea 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e386:	e9 2e f7 ff ff       	jmp    dab9 <f0+0x23d9>
    e38b:	4c 89 e7             	mov    %r12,%rdi
    e38e:	e8 dd 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e393:	e9 c0 f7 ff ff       	jmp    db58 <f0+0x2478>
    e398:	4c 89 e7             	mov    %r12,%rdi
    e39b:	e8 d0 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e3a0:	e9 52 f8 ff ff       	jmp    dbf7 <f0+0x2517>
    e3a5:	4c 89 e7             	mov    %r12,%rdi
    e3a8:	e8 c3 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e3ad:	e9 e4 f8 ff ff       	jmp    dc96 <f0+0x25b6>
    e3b2:	4c 89 e7             	mov    %r12,%rdi
    e3b5:	e8 b6 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e3ba:	e9 76 f9 ff ff       	jmp    dd35 <f0+0x2655>
    e3bf:	4c 89 e7             	mov    %r12,%rdi
    e3c2:	e8 a9 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e3c7:	e9 08 fa ff ff       	jmp    ddd4 <f0+0x26f4>
    e3cc:	4c 89 e7             	mov    %r12,%rdi
    e3cf:	e8 9c 73 ff ff       	call   5770 <fwp_rc_forget_slot>
    e3d4:	e9 9a fa ff ff       	jmp    de73 <f0+0x2793>
    e3d9:	e8 62 50 ff ff       	call   3440 <__stack_chk_fail@plt>
    e3de:	66 90                	xchg   %ax,%ax

000000000000e3e0 <fwp_main_thread>:
    e3e0:	f3 0f 1e fa          	endbr64
    e3e4:	41 54                	push   %r12
    e3e6:	55                   	push   %rbp
    e3e7:	53                   	push   %rbx
    e3e8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e3ef:	8b 0d af e7 05 00    	mov    0x5e7af(%rip),%ecx        # 6cba4 <fwp_heap+0x13a4>
    e3f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e3fc:	00 00 
    e3fe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e405:	00 
    e406:	31 c0                	xor    %eax,%eax
    e408:	85 c9                	test   %ecx,%ecx
    e40a:	0f 84 58 07 00 00    	je     eb68 <fwp_main_thread+0x788>
    e410:	8b 15 92 e7 05 00    	mov    0x5e792(%rip),%edx        # 6cba8 <fwp_heap+0x13a8>
    e416:	85 d2                	test   %edx,%edx
    e418:	0f 85 32 07 00 00    	jne    eb50 <fwp_main_thread+0x770>
    e41e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e423:	31 f6                	xor    %esi,%esi
    e425:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e42a:	48 c7 05 6b cd 05 00 	movq   $0x40000000,0x5cd6b(%rip)        # 6b1a0 <fwp_main_stack_size>
    e431:	00 00 00 40 
    e435:	48 89 05 6c cd 05 00 	mov    %rax,0x5cd6c(%rip)        # 6b1a8 <fwp_main_stack_top>
    e43c:	48 8d 05 3d 4c 00 00 	lea    0x4c3d(%rip),%rax        # 13080 <alt.5>
    e443:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e448:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e44f:	01 00 
    e451:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e458:	00 
    e459:	e8 22 52 ff ff       	call   3680 <sigaltstack@plt>
    e45e:	85 c0                	test   %eax,%eax
    e460:	0f 85 6a 07 00 00    	jne    ebd0 <fwp_main_thread+0x7f0>
    e466:	31 c0                	xor    %eax,%eax
    e468:	b9 12 00 00 00       	mov    $0x12,%ecx
    e46d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e472:	f3 48 ab             	rep stos %rax,(%rdi)
    e475:	48 8d 05 84 58 ff ff 	lea    -0xa77c(%rip),%rax        # 3d00 <fwp_segv>
    e47c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e481:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e488:	04 00 00 08 
    e48c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e491:	e8 ba 50 ff ff       	call   3550 <sigemptyset@plt>
    e496:	85 c0                	test   %eax,%eax
    e498:	0f 85 32 07 00 00    	jne    ebd0 <fwp_main_thread+0x7f0>
    e49e:	31 d2                	xor    %edx,%edx
    e4a0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e4a5:	bf 0b 00 00 00       	mov    $0xb,%edi
    e4aa:	e8 31 4f ff ff       	call   33e0 <sigaction@plt>
    e4af:	85 c0                	test   %eax,%eax
    e4b1:	0f 85 19 07 00 00    	jne    ebd0 <fwp_main_thread+0x7f0>
    e4b7:	31 d2                	xor    %edx,%edx
    e4b9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e4be:	bf 07 00 00 00       	mov    $0x7,%edi
    e4c3:	e8 18 4f ff ff       	call   33e0 <sigaction@plt>
    e4c8:	85 c0                	test   %eax,%eax
    e4ca:	0f 85 00 07 00 00    	jne    ebd0 <fwp_main_thread+0x7f0>
    e4d0:	48 8b 05 49 e7 05 00 	mov    0x5e749(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    e4d7:	48 85 c0             	test   %rax,%rax
    e4da:	0f 88 50 06 00 00    	js     eb30 <fwp_main_thread+0x750>
    e4e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e4e4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    e4e9:	48 8d 3d f0 5c ff ff 	lea    -0xa310(%rip),%rdi        # 41e0 <ad_raw_report>
    e4f0:	f2 0f 11 05 b0 ef 05 	movsd  %xmm0,0x5efb0(%rip)        # 6d4a8 <iteration_start_charge>
    e4f7:	00 
    e4f8:	c7 05 c6 ef 05 00 01 	movl   $0x1,0x5efc6(%rip)        # 6d4c8 <iteration_active>
    e4ff:	00 00 00 
    e502:	e8 09 09 00 00       	call   ee10 <atexit>
    e507:	85 c0                	test   %eax,%eax
    e509:	0f 85 cd 06 00 00    	jne    ebdc <fwp_main_thread+0x7fc>
    e50f:	8b 05 5b 4b 00 00    	mov    0x4b5b(%rip),%eax        # 13070 <st.3>
    e515:	85 c0                	test   %eax,%eax
    e517:	0f 84 5b 06 00 00    	je     eb78 <fwp_main_thread+0x798>
    e51d:	48 8b 2d bc d2 05 00 	mov    0x5d2bc(%rip),%rbp        # 6b7e0 <fwp_cur>
    e524:	48 85 ed             	test   %rbp,%rbp
    e527:	0f 84 03 03 00 00    	je     e830 <fwp_main_thread+0x450>
    e52d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e532:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e536:	48 89 eb             	mov    %rbp,%rbx
    e539:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e53e:	0f 84 41 01 00 00    	je     e685 <fwp_main_thread+0x2a5>
    e544:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e549:	0f 84 11 02 00 00    	je     e760 <fwp_main_thread+0x380>
    e54f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e553:	0f 84 f7 01 00 00    	je     e750 <fwp_main_thread+0x370>
    e559:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e55d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e561:	0f 85 79 02 00 00    	jne    e7e0 <fwp_main_thread+0x400>
    e567:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e56b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e572:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e576:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e57d:	00 00 00 00 
    e581:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e588:	48 85 d2             	test   %rdx,%rdx
    e58b:	74 07                	je     e594 <fwp_main_thread+0x1b4>
    e58d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e594:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e598:	48 85 c0             	test   %rax,%rax
    e59b:	74 34                	je     e5d1 <fwp_main_thread+0x1f1>
    e59d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e5a1:	48 8b 05 10 d2 05 00 	mov    0x5d210(%rip),%rax        # 6b7b8 <fwp_timers>
    e5a8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e5ac:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e5b3:	00 00 00 00 
    e5b7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e5be:	48 85 c0             	test   %rax,%rax
    e5c1:	74 07                	je     e5ca <fwp_main_thread+0x1ea>
    e5c3:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e5ca:	48 89 1d e7 d1 05 00 	mov    %rbx,0x5d1e7(%rip)        # 6b7b8 <fwp_timers>
    e5d1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e5d5:	e8 36 97 ff ff       	call   7d10 <fwp_block>
    e5da:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e5e1:	48 85 c9             	test   %rcx,%rcx
    e5e4:	74 47                	je     e62d <fwp_main_thread+0x24d>
    e5e6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e5ed:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e5f4:	48 85 d2             	test   %rdx,%rdx
    e5f7:	0f 84 23 02 00 00    	je     e820 <fwp_main_thread+0x440>
    e5fd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e604:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e60b:	48 85 c0             	test   %rax,%rax
    e60e:	74 07                	je     e617 <fwp_main_thread+0x237>
    e610:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e617:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e61e:	00 00 00 00 
    e622:	66 0f ef d2          	pxor   %xmm2,%xmm2
    e626:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    e62d:	48 8b 0d ac d1 05 00 	mov    0x5d1ac(%rip),%rcx        # 6b7e0 <fwp_cur>
    e634:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e638:	0f 84 92 01 00 00    	je     e7d0 <fwp_main_thread+0x3f0>
    e63e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e645:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e64c:	48 85 d2             	test   %rdx,%rdx
    e64f:	0f 84 1b 04 00 00    	je     ea70 <fwp_main_thread+0x690>
    e655:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e65c:	48 85 c0             	test   %rax,%rax
    e65f:	74 07                	je     e668 <fwp_main_thread+0x288>
    e661:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e668:	66 0f ef db          	pxor   %xmm3,%xmm3
    e66c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e670:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e677:	48 89 cb             	mov    %rcx,%rbx
    e67a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e67f:	0f 85 bf fe ff ff    	jne    e544 <fwp_main_thread+0x164>
    e685:	48 83 3d eb ed 05 00 	cmpq   $0x0,0x5edeb(%rip)        # 6d478 <fwp_state_len>
    e68c:	00 
    e68d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e691:	0f 84 0b 04 00 00    	je     eaa2 <fwp_main_thread+0x6c2>
    e697:	48 3b 1d 3a d1 05 00 	cmp    0x5d13a(%rip),%rbx        # 6b7d8 <fwp_root>
    e69e:	c7 05 d8 49 01 00 00 	movl   $0x0,0x149d8(%rip)        # 23080 <fwp_exit_code>
    e6a5:	00 00 00 
    e6a8:	0f 85 4c 05 00 00    	jne    ebfa <fwp_main_thread+0x81a>
    e6ae:	48 85 db             	test   %rbx,%rbx
    e6b1:	0f 84 9f 01 00 00    	je     e856 <fwp_main_thread+0x476>
    e6b7:	48 8b 15 ea d0 05 00 	mov    0x5d0ea(%rip),%rdx        # 6b7a8 <fwp_tasks_active>
    e6be:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e6c2:	48 85 d2             	test   %rdx,%rdx
    e6c5:	0f 84 8b 01 00 00    	je     e856 <fwp_main_thread+0x476>
    e6cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e6d0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e6d4:	75 08                	jne    e6de <fwp_main_thread+0x2fe>
    e6d6:	48 89 d7             	mov    %rdx,%rdi
    e6d9:	e8 12 5a ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    e6de:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e6e5:	48 85 d2             	test   %rdx,%rdx
    e6e8:	75 e6                	jne    e6d0 <fwp_main_thread+0x2f0>
    e6ea:	eb 31                	jmp    e71d <fwp_main_thread+0x33d>
    e6ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e6f0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e6f7:	48 89 1d c2 d0 05 00 	mov    %rbx,0x5d0c2(%rip)        # 6b7c0 <fwp_ready_tail>
    e6fe:	e8 0d 96 ff ff       	call   7d10 <fwp_block>
    e703:	e8 f8 93 ff ff       	call   7b00 <fwp_free_zombie>
    e708:	48 83 3d 98 d0 05 00 	cmpq   $0x0,0x5d098(%rip)        # 6b7a8 <fwp_tasks_active>
    e70f:	00 
    e710:	0f 84 40 01 00 00    	je     e856 <fwp_main_thread+0x476>
    e716:	48 8b 1d bb d0 05 00 	mov    0x5d0bb(%rip),%rbx        # 6b7d8 <fwp_root>
    e71d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e721:	75 db                	jne    e6fe <fwp_main_thread+0x31e>
    e723:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e727:	75 d5                	jne    e6fe <fwp_main_thread+0x31e>
    e729:	48 8b 05 90 d0 05 00 	mov    0x5d090(%rip),%rax        # 6b7c0 <fwp_ready_tail>
    e730:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e734:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e73b:	00 00 00 00 
    e73f:	48 85 c0             	test   %rax,%rax
    e742:	75 ac                	jne    e6f0 <fwp_main_thread+0x310>
    e744:	48 89 1d 7d d0 05 00 	mov    %rbx,0x5d07d(%rip)        # 6b7c8 <fwp_ready_head>
    e74b:	eb aa                	jmp    e6f7 <fwp_main_thread+0x317>
    e74d:	0f 1f 00             	nopl   (%rax)
    e750:	e8 2b 5e ff ff       	call   4580 <fwp_now_ns>
    e755:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e759:	0f 8d 21 03 00 00    	jge    ea80 <fwp_main_thread+0x6a0>
    e75f:	90                   	nop
    e760:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e764:	0f 85 ef fd ff ff    	jne    e559 <fwp_main_thread+0x179>
    e76a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e76e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e772:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e776:	0f 85 ef fd ff ff    	jne    e56b <fwp_main_thread+0x18b>
    e77c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e780:	48 85 c9             	test   %rcx,%rcx
    e783:	0f 84 e2 fd ff ff    	je     e56b <fwp_main_thread+0x18b>
    e789:	48 85 c0             	test   %rax,%rax
    e78c:	0f 84 5b 04 00 00    	je     ebed <fwp_main_thread+0x80d>
    e792:	48 39 c8             	cmp    %rcx,%rax
    e795:	48 0f 4f c1          	cmovg  %rcx,%rax
    e799:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7a0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e7a4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7ab:	00 00 00 00 
    e7af:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e7b6:	48 85 d2             	test   %rdx,%rdx
    e7b9:	74 07                	je     e7c2 <fwp_main_thread+0x3e2>
    e7bb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e7c2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e7c6:	e9 d2 fd ff ff       	jmp    e59d <fwp_main_thread+0x1bd>
    e7cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e7d0:	48 89 cb             	mov    %rcx,%rbx
    e7d3:	e9 61 fd ff ff       	jmp    e539 <fwp_main_thread+0x159>
    e7d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e7df:	00 
    e7e0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e7e4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7eb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7f2:	00 00 00 00 
    e7f6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e7fd:	48 85 c0             	test   %rax,%rax
    e800:	0f 84 9a 03 00 00    	je     eba0 <fwp_main_thread+0x7c0>
    e806:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e80d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e811:	e9 bb fd ff ff       	jmp    e5d1 <fwp_main_thread+0x1f1>
    e816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e81d:	00 00 00 
    e820:	48 89 01             	mov    %rax,(%rcx)
    e823:	e9 e3 fd ff ff       	jmp    e60b <fwp_main_thread+0x22b>
    e828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e82f:	00 
    e830:	48 83 3d 40 ec 05 00 	cmpq   $0x0,0x5ec40(%rip)        # 6d478 <fwp_state_len>
    e837:	00 
    e838:	0f 84 62 02 00 00    	je     eaa0 <fwp_main_thread+0x6c0>
    e83e:	48 83 3d 92 cf 05 00 	cmpq   $0x0,0x5cf92(%rip)        # 6b7d8 <fwp_root>
    e845:	00 
    e846:	c7 05 30 48 01 00 00 	movl   $0x0,0x14830(%rip)        # 23080 <fwp_exit_code>
    e84d:	00 00 00 
    e850:	0f 85 9f 03 00 00    	jne    ebf5 <fwp_main_thread+0x815>
    e856:	e8 a5 92 ff ff       	call   7b00 <fwp_free_zombie>
    e85b:	48 83 3d 65 cf 05 00 	cmpq   $0x0,0x5cf65(%rip)        # 6b7c8 <fwp_ready_head>
    e862:	00 
    e863:	0f 85 ac 4e ff ff    	jne    3715 <fwp_main_thread.cold>
    e869:	48 83 3d 47 cf 05 00 	cmpq   $0x0,0x5cf47(%rip)        # 6b7b8 <fwp_timers>
    e870:	00 
    e871:	0f 85 9e 4e ff ff    	jne    3715 <fwp_main_thread.cold>
    e877:	8b 1d 37 c9 05 00    	mov    0x5c937(%rip),%ebx        # 6b1b4 <fwp_stack_pool_n>
    e87d:	85 db                	test   %ebx,%ebx
    e87f:	74 36                	je     e8b7 <fwp_main_thread+0x4d7>
    e881:	83 eb 01             	sub    $0x1,%ebx
    e884:	48 8d 05 35 c9 05 00 	lea    0x5c935(%rip),%rax        # 6b1c0 <fwp_stack_pool>
    e88b:	48 63 d3             	movslq %ebx,%rdx
    e88e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e892:	eb 07                	jmp    e89b <fwp_main_thread+0x4bb>
    e894:	0f 1f 40 00          	nopl   0x0(%rax)
    e898:	83 eb 01             	sub    $0x1,%ebx
    e89b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e89f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e8a4:	89 1d 0a c9 05 00    	mov    %ebx,0x5c90a(%rip)        # 6b1b4 <fwp_stack_pool_n>
    e8aa:	48 83 ed 08          	sub    $0x8,%rbp
    e8ae:	e8 fd 4c ff ff       	call   35b0 <munmap@plt>
    e8b3:	85 db                	test   %ebx,%ebx
    e8b5:	75 e1                	jne    e898 <fwp_main_thread+0x4b8>
    e8b7:	8b 3d 5b 47 00 00    	mov    0x475b(%rip),%edi        # 13018 <fwp_epfd>
    e8bd:	85 ff                	test   %edi,%edi
    e8bf:	78 05                	js     e8c6 <fwp_main_thread+0x4e6>
    e8c1:	e8 ea 4b ff ff       	call   34b0 <close@plt>
    e8c6:	4c 8b 25 f3 ca 05 00 	mov    0x5caf3(%rip),%r12        # 6b3c0 <fwp_nfdws>
    e8cd:	48 8b 2d f4 ca 05 00 	mov    0x5caf4(%rip),%rbp        # 6b3c8 <fwp_fdws>
    e8d4:	31 db                	xor    %ebx,%ebx
    e8d6:	c7 05 38 47 00 00 ff 	movl   $0xffffffff,0x4738(%rip)        # 13018 <fwp_epfd>
    e8dd:	ff ff ff 
    e8e0:	4d 85 e4             	test   %r12,%r12
    e8e3:	74 38                	je     e91d <fwp_main_thread+0x53d>
    e8e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e8ec:	00 00 00 00 
    e8f0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e8f5:	48 85 ff             	test   %rdi,%rdi
    e8f8:	74 1a                	je     e914 <fwp_main_thread+0x534>
    e8fa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e8fe:	0f 85 11 4e ff ff    	jne    3715 <fwp_main_thread.cold>
    e904:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e909:	0f 85 06 4e ff ff    	jne    3715 <fwp_main_thread.cold>
    e90f:	e8 9c 70 ff ff       	call   59b0 <fwp_mem_free>
    e914:	48 83 c3 01          	add    $0x1,%rbx
    e918:	49 39 dc             	cmp    %rbx,%r12
    e91b:	75 d3                	jne    e8f0 <fwp_main_thread+0x510>
    e91d:	48 89 ef             	mov    %rbp,%rdi
    e920:	e8 8b 70 ff ff       	call   59b0 <fwp_mem_free>
    e925:	48 8b 15 ac ce 05 00 	mov    0x5ceac(%rip),%rdx        # 6b7d8 <fwp_root>
    e92c:	48 c7 05 91 ca 05 00 	movq   $0x0,0x5ca91(%rip)        # 6b3c8 <fwp_fdws>
    e933:	00 00 00 00 
    e937:	48 c7 05 7e ca 05 00 	movq   $0x0,0x5ca7e(%rip)        # 6b3c0 <fwp_nfdws>
    e93e:	00 00 00 00 
    e942:	48 85 d2             	test   %rdx,%rdx
    e945:	74 4e                	je     e995 <fwp_main_thread+0x5b5>
    e947:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e94c:	0f 85 c3 4d ff ff    	jne    3715 <fwp_main_thread.cold>
    e952:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e959:	00 
    e95a:	0f 85 b5 4d ff ff    	jne    3715 <fwp_main_thread.cold>
    e960:	48 83 3d 10 eb 05 00 	cmpq   $0x0,0x5eb10(%rip)        # 6d478 <fwp_state_len>
    e967:	00 
    e968:	0f 85 a7 4d ff ff    	jne    3715 <fwp_main_thread.cold>
    e96e:	48 83 3d f2 ea 05 00 	cmpq   $0x0,0x5eaf2(%rip)        # 6d468 <fwp_state_owners>
    e975:	00 
    e976:	0f 85 99 4d ff ff    	jne    3715 <fwp_main_thread.cold>
    e97c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e981:	31 c0                	xor    %eax,%eax
    e983:	48 8d 3d 56 ca 05 00 	lea    0x5ca56(%rip),%rdi        # 6b3e0 <fwp_root_context>
    e98a:	f3 48 ab             	rep stos %rax,(%rdi)
    e98d:	48 89 d7             	mov    %rdx,%rdi
    e990:	e8 1b 70 ff ff       	call   59b0 <fwp_mem_free>
    e995:	66 0f 6f 05 f3 47 04 	movdqa 0x447f3(%rip),%xmm0        # 53190 <ad_raw_live+0x10>
    e99c:	00 
    e99d:	66 0f d4 05 db 47 04 	paddq  0x447db(%rip),%xmm0        # 53180 <ad_raw_live>
    e9a4:	00 
    e9a5:	48 c7 05 30 ce 05 00 	movq   $0x0,0x5ce30(%rip)        # 6b7e0 <fwp_cur>
    e9ac:	00 00 00 00 
    e9b0:	48 8b 05 69 e2 05 00 	mov    0x5e269(%rip),%rax        # 6cc20 <fwp_heap+0x1420>
    e9b7:	48 c7 05 16 ce 05 00 	movq   $0x0,0x5ce16(%rip)        # 6b7d8 <fwp_root>
    e9be:	00 00 00 00 
    e9c2:	c7 05 fc ea 05 00 00 	movl   $0x0,0x5eafc(%rip)        # 6d4c8 <iteration_active>
    e9c9:	00 00 00 
    e9cc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e9d0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e9d5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e9d9:	66 0f d6 05 07 47 01 	movq   %xmm0,0x14707(%rip)        # 230e8 <ad_raw_before_shutdown>
    e9e0:	00 
    e9e1:	48 85 c0             	test   %rax,%rax
    e9e4:	0f 88 26 01 00 00    	js     eb10 <fwp_main_thread+0x730>
    e9ea:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e9ee:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e9f3:	f2 0f 5c 0d ad ea 05 	subsd  0x5eaad(%rip),%xmm1        # 6d4a8 <iteration_start_charge>
    e9fa:	00 
    e9fb:	48 8b 3d 3e 46 00 00 	mov    0x463e(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    ea02:	48 8d 15 67 11 00 00 	lea    0x1167(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    ea09:	be 02 00 00 00       	mov    $0x2,%esi
    ea0e:	f2 0f 10 05 8a ea 05 	movsd  0x5ea8a(%rip),%xmm0        # 6d4a0 <iteration_peak>
    ea15:	00 
    ea16:	4c 8b 0d 93 ea 05 00 	mov    0x5ea93(%rip),%r9        # 6d4b0 <iteration_retains>
    ea1d:	b8 02 00 00 00       	mov    $0x2,%eax
    ea22:	4c 8b 05 8f ea 05 00 	mov    0x5ea8f(%rip),%r8        # 6d4b8 <iteration_bytes>
    ea29:	48 8b 0d 90 ea 05 00 	mov    0x5ea90(%rip),%rcx        # 6d4c0 <iteration_requests>
    ea30:	e8 1b 4c ff ff       	call   3650 <__fprintf_chk@plt>
    ea35:	48 8b 3d e4 45 00 00 	mov    0x45e4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    ea3c:	e8 4f 4b ff ff       	call   3590 <fflush@plt>
    ea41:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    ea48:	00 
    ea49:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ea50:	00 00 
    ea52:	0f 85 90 01 00 00    	jne    ebe8 <fwp_main_thread+0x808>
    ea58:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    ea5f:	31 c0                	xor    %eax,%eax
    ea61:	5b                   	pop    %rbx
    ea62:	5d                   	pop    %rbp
    ea63:	41 5c                	pop    %r12
    ea65:	c3                   	ret
    ea66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ea6d:	00 00 00 
    ea70:	48 89 05 41 cd 05 00 	mov    %rax,0x5cd41(%rip)        # 6b7b8 <fwp_timers>
    ea77:	e9 e0 fb ff ff       	jmp    e65c <fwp_main_thread+0x27c>
    ea7c:	0f 1f 40 00          	nopl   0x0(%rax)
    ea80:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ea84:	0f 85 d6 fc ff ff    	jne    e760 <fwp_main_thread+0x380>
    ea8a:	48 89 ef             	mov    %rbp,%rdi
    ea8d:	e8 5e 56 ff ff       	call   40f0 <fwp_cancel_tree.part.0>
    ea92:	e9 c9 fc ff ff       	jmp    e760 <fwp_main_thread+0x380>
    ea97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ea9e:	00 00 
    eaa0:	31 db                	xor    %ebx,%ebx
    eaa2:	48 83 3d be e9 05 00 	cmpq   $0x0,0x5e9be(%rip)        # 6d468 <fwp_state_owners>
    eaa9:	00 
    eaaa:	0f 85 e7 fb ff ff    	jne    e697 <fwp_main_thread+0x2b7>
    eab0:	48 8b 3d c9 e9 05 00 	mov    0x5e9c9(%rip),%rdi        # 6d480 <fwp_state>
    eab7:	e8 f4 6e ff ff       	call   59b0 <fwp_mem_free>
    eabc:	48 c7 05 b9 e9 05 00 	movq   $0x0,0x5e9b9(%rip)        # 6d480 <fwp_state>
    eac3:	00 00 00 00 
    eac7:	48 c7 05 9e e9 05 00 	movq   $0x0,0x5e99e(%rip)        # 6d470 <fwp_state_cap>
    eace:	00 00 00 00 
    ead2:	48 85 db             	test   %rbx,%rbx
    ead5:	0f 84 ce 00 00 00    	je     eba9 <fwp_main_thread+0x7c9>
    eadb:	48 39 1d f6 cc 05 00 	cmp    %rbx,0x5ccf6(%rip)        # 6b7d8 <fwp_root>
    eae2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    eae9:	00 00 00 00 
    eaed:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    eaf4:	00 00 00 00 
    eaf8:	c7 05 7e 45 01 00 00 	movl   $0x0,0x1457e(%rip)        # 23080 <fwp_exit_code>
    eaff:	00 00 00 
    eb02:	0f 84 af fb ff ff    	je     e6b7 <fwp_main_thread+0x2d7>
    eb08:	e9 08 4c ff ff       	jmp    3715 <fwp_main_thread.cold>
    eb0d:	0f 1f 00             	nopl   (%rax)
    eb10:	48 89 c2             	mov    %rax,%rdx
    eb13:	83 e0 01             	and    $0x1,%eax
    eb16:	66 0f ef c9          	pxor   %xmm1,%xmm1
    eb1a:	48 d1 ea             	shr    $1,%rdx
    eb1d:	48 09 c2             	or     %rax,%rdx
    eb20:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    eb25:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    eb29:	e9 c5 fe ff ff       	jmp    e9f3 <fwp_main_thread+0x613>
    eb2e:	66 90                	xchg   %ax,%ax
    eb30:	48 89 c2             	mov    %rax,%rdx
    eb33:	83 e0 01             	and    $0x1,%eax
    eb36:	66 0f ef c0          	pxor   %xmm0,%xmm0
    eb3a:	48 d1 ea             	shr    $1,%rdx
    eb3d:	48 09 c2             	or     %rax,%rdx
    eb40:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    eb45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    eb49:	e9 9b f9 ff ff       	jmp    e4e9 <fwp_main_thread+0x109>
    eb4e:	66 90                	xchg   %ax,%ax
    eb50:	48 8d 3d 29 61 ff ff 	lea    -0x9ed7(%rip),%rdi        # 4c80 <fwp_heap_report>
    eb57:	e8 b4 02 00 00       	call   ee10 <atexit>
    eb5c:	e9 bd f8 ff ff       	jmp    e41e <fwp_main_thread+0x3e>
    eb61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    eb68:	e8 23 62 ff ff       	call   4d90 <fwp_heap_init>
    eb6d:	e9 9e f8 ff ff       	jmp    e410 <fwp_main_thread+0x30>
    eb72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    eb78:	e8 63 cb ff ff       	call   b6e0 <f0>
    eb7d:	48 c7 05 e0 44 00 00 	movq   $0x0,0x44e0(%rip)        # 13068 <v.2>
    eb84:	00 00 00 00 
    eb88:	c7 05 de 44 00 00 01 	movl   $0x1,0x44de(%rip)        # 13070 <st.3>
    eb8f:	00 00 00 
    eb92:	e9 86 f9 ff ff       	jmp    e51d <fwp_main_thread+0x13d>
    eb97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    eb9e:	00 00 
    eba0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eba4:	e9 28 fa ff ff       	jmp    e5d1 <fwp_main_thread+0x1f1>
    eba9:	48 83 3d 27 cc 05 00 	cmpq   $0x0,0x5cc27(%rip)        # 6b7d8 <fwp_root>
    ebb0:	00 
    ebb1:	c7 05 c5 44 01 00 00 	movl   $0x0,0x144c5(%rip)        # 23080 <fwp_exit_code>
    ebb8:	00 00 00 
    ebbb:	0f 84 95 fc ff ff    	je     e856 <fwp_main_thread+0x476>
    ebc1:	e9 4f 4b ff ff       	jmp    3715 <fwp_main_thread.cold>
    ebc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ebcd:	00 00 00 
    ebd0:	48 8d 3d 71 0f 00 00 	lea    0xf71(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    ebd7:	e8 34 58 ff ff       	call   4410 <fwp_trap>
    ebdc:	48 8d 3d f2 06 00 00 	lea    0x6f2(%rip),%rdi        # f2d5 <_IO_stdin_used+0x2d5>
    ebe3:	e8 d8 53 ff ff       	call   3fc0 <ad_raw_fail>
    ebe8:	e8 53 48 ff ff       	call   3440 <__stack_chk_fail@plt>
    ebed:	48 89 c8             	mov    %rcx,%rax
    ebf0:	e9 a4 fb ff ff       	jmp    e799 <fwp_main_thread+0x3b9>
    ebf5:	e9 1b 4b ff ff       	jmp    3715 <fwp_main_thread.cold>
    ebfa:	e9 16 4b ff ff       	jmp    3715 <fwp_main_thread.cold>
    ebff:	90                   	nop

000000000000ec00 <__divmodti4>:
    ec00:	f3 0f 1e fa          	endbr64
    ec04:	55                   	push   %rbp
    ec05:	49 89 f1             	mov    %rsi,%r9
    ec08:	49 89 d2             	mov    %rdx,%r10
    ec0b:	48 89 fe             	mov    %rdi,%rsi
    ec0e:	49 89 cb             	mov    %rcx,%r11
    ec11:	48 89 e5             	mov    %rsp,%rbp
    ec14:	41 57                	push   %r15
    ec16:	41 56                	push   %r14
    ec18:	41 55                	push   %r13
    ec1a:	41 54                	push   %r12
    ec1c:	53                   	push   %rbx
    ec1d:	4c 89 c3             	mov    %r8,%rbx
    ec20:	45 31 c0             	xor    %r8d,%r8d
    ec23:	4d 85 c9             	test   %r9,%r9
    ec26:	79 12                	jns    ec3a <__divmodti4+0x3a>
    ec28:	31 ff                	xor    %edi,%edi
    ec2a:	48 f7 de             	neg    %rsi
    ec2d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    ec34:	4c 19 cf             	sbb    %r9,%rdi
    ec37:	49 89 f9             	mov    %rdi,%r9
    ec3a:	4c 89 d8             	mov    %r11,%rax
    ec3d:	4d 85 db             	test   %r11,%r11
    ec40:	0f 88 1a 01 00 00    	js     ed60 <__divmodti4+0x160>
    ec46:	4c 89 d9             	mov    %r11,%rcx
    ec49:	49 89 f3             	mov    %rsi,%r11
    ec4c:	75 62                	jne    ecb0 <__divmodti4+0xb0>
    ec4e:	4d 89 c4             	mov    %r8,%r12
    ec51:	4d 39 d1             	cmp    %r10,%r9
    ec54:	0f 83 46 01 00 00    	jae    eda0 <__divmodti4+0x1a0>
    ec5a:	4c 89 d8             	mov    %r11,%rax
    ec5d:	4c 89 ca             	mov    %r9,%rdx
    ec60:	49 f7 f2             	div    %r10
    ec63:	49 89 c3             	mov    %rax,%r11
    ec66:	31 c0                	xor    %eax,%eax
    ec68:	48 89 d6             	mov    %rdx,%rsi
    ec6b:	31 ff                	xor    %edi,%edi
    ec6d:	4c 89 d9             	mov    %r11,%rcx
    ec70:	48 89 c2             	mov    %rax,%rdx
    ec73:	48 89 c8             	mov    %rcx,%rax
    ec76:	4d 85 e4             	test   %r12,%r12
    ec79:	74 0a                	je     ec85 <__divmodti4+0x85>
    ec7b:	48 f7 d8             	neg    %rax
    ec7e:	48 83 d2 00          	adc    $0x0,%rdx
    ec82:	48 f7 da             	neg    %rdx
    ec85:	4d 85 c0             	test   %r8,%r8
    ec88:	74 0a                	je     ec94 <__divmodti4+0x94>
    ec8a:	48 f7 de             	neg    %rsi
    ec8d:	48 83 d7 00          	adc    $0x0,%rdi
    ec91:	48 f7 df             	neg    %rdi
    ec94:	48 89 33             	mov    %rsi,(%rbx)
    ec97:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ec9b:	5b                   	pop    %rbx
    ec9c:	41 5c                	pop    %r12
    ec9e:	41 5d                	pop    %r13
    eca0:	41 5e                	pop    %r14
    eca2:	41 5f                	pop    %r15
    eca4:	5d                   	pop    %rbp
    eca5:	c3                   	ret
    eca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ecad:	00 00 00 
    ecb0:	4d 89 c4             	mov    %r8,%r12
    ecb3:	49 39 c1             	cmp    %rax,%r9
    ecb6:	0f 82 ce 00 00 00    	jb     ed8a <__divmodti4+0x18a>
    ecbc:	31 ff                	xor    %edi,%edi
    ecbe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ecc3:	48 63 c7             	movslq %edi,%rax
    ecc6:	be 40 00 00 00       	mov    $0x40,%esi
    eccb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ecd0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ecd5:	48 29 c6             	sub    %rax,%rsi
    ecd8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ecdd:	48 09 c8             	or     %rcx,%rax
    ece0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ece5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ecea:	49 89 c6             	mov    %rax,%r14
    eced:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ecf1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ecf6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ecfb:	49 09 c1             	or     %rax,%r9
    ecfe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ed02:	4c 89 c8             	mov    %r9,%rax
    ed05:	49 f7 f6             	div    %r14
    ed08:	48 89 d1             	mov    %rdx,%rcx
    ed0b:	49 89 c3             	mov    %rax,%r11
    ed0e:	49 89 c1             	mov    %rax,%r9
    ed11:	49 f7 e2             	mul    %r10
    ed14:	49 89 c6             	mov    %rax,%r14
    ed17:	49 89 d2             	mov    %rdx,%r10
    ed1a:	48 39 d1             	cmp    %rdx,%rcx
    ed1d:	72 07                	jb     ed26 <__divmodti4+0x126>
    ed1f:	75 17                	jne    ed38 <__divmodti4+0x138>
    ed21:	49 39 c7             	cmp    %rax,%r15
    ed24:	73 12                	jae    ed38 <__divmodti4+0x138>
    ed26:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ed2a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ed2e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ed32:	49 89 d2             	mov    %rdx,%r10
    ed35:	49 89 c6             	mov    %rax,%r14
    ed38:	4c 89 f8             	mov    %r15,%rax
    ed3b:	4c 29 f0             	sub    %r14,%rax
    ed3e:	4c 19 d1             	sbb    %r10,%rcx
    ed41:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ed46:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ed4b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ed50:	48 09 c6             	or     %rax,%rsi
    ed53:	48 89 cf             	mov    %rcx,%rdi
    ed56:	31 c0                	xor    %eax,%eax
    ed58:	4c 89 c9             	mov    %r9,%rcx
    ed5b:	e9 10 ff ff ff       	jmp    ec70 <__divmodti4+0x70>
    ed60:	4c 89 d0             	mov    %r10,%rax
    ed63:	4c 89 da             	mov    %r11,%rdx
    ed66:	4d 89 c4             	mov    %r8,%r12
    ed69:	49 89 f3             	mov    %rsi,%r11
    ed6c:	48 f7 d8             	neg    %rax
    ed6f:	49 f7 d4             	not    %r12
    ed72:	48 83 d2 00          	adc    $0x0,%rdx
    ed76:	49 89 c2             	mov    %rax,%r10
    ed79:	48 f7 da             	neg    %rdx
    ed7c:	48 89 d1             	mov    %rdx,%rcx
    ed7f:	0f 84 cc fe ff ff    	je     ec51 <__divmodti4+0x51>
    ed85:	49 39 d1             	cmp    %rdx,%r9
    ed88:	73 46                	jae    edd0 <__divmodti4+0x1d0>
    ed8a:	4c 89 cf             	mov    %r9,%rdi
    ed8d:	31 c0                	xor    %eax,%eax
    ed8f:	31 c9                	xor    %ecx,%ecx
    ed91:	e9 da fe ff ff       	jmp    ec70 <__divmodti4+0x70>
    ed96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ed9d:	00 00 00 
    eda0:	4d 85 d2             	test   %r10,%r10
    eda3:	75 0d                	jne    edb2 <__divmodti4+0x1b2>
    eda5:	b8 01 00 00 00       	mov    $0x1,%eax
    edaa:	31 d2                	xor    %edx,%edx
    edac:	49 f7 f2             	div    %r10
    edaf:	49 89 c2             	mov    %rax,%r10
    edb2:	4c 89 c8             	mov    %r9,%rax
    edb5:	31 d2                	xor    %edx,%edx
    edb7:	49 f7 f2             	div    %r10
    edba:	49 89 c1             	mov    %rax,%r9
    edbd:	4c 89 d8             	mov    %r11,%rax
    edc0:	49 f7 f2             	div    %r10
    edc3:	49 89 c3             	mov    %rax,%r11
    edc6:	4c 89 c8             	mov    %r9,%rax
    edc9:	e9 9a fe ff ff       	jmp    ec68 <__divmodti4+0x68>
    edce:	66 90                	xchg   %ax,%ax
    edd0:	45 31 f6             	xor    %r14d,%r14d
    edd3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    edd8:	44 89 f7             	mov    %r14d,%edi
    eddb:	45 85 f6             	test   %r14d,%r14d
    edde:	0f 85 df fe ff ff    	jne    ecc3 <__divmodti4+0xc3>
    ede4:	4c 39 ca             	cmp    %r9,%rdx
    ede7:	72 17                	jb     ee00 <__divmodti4+0x200>
    ede9:	31 c9                	xor    %ecx,%ecx
    edeb:	48 39 c6             	cmp    %rax,%rsi
    edee:	73 10                	jae    ee00 <__divmodti4+0x200>
    edf0:	4c 89 cf             	mov    %r9,%rdi
    edf3:	31 c0                	xor    %eax,%eax
    edf5:	e9 76 fe ff ff       	jmp    ec70 <__divmodti4+0x70>
    edfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ee00:	4c 89 de             	mov    %r11,%rsi
    ee03:	b9 01 00 00 00       	mov    $0x1,%ecx
    ee08:	48 29 c6             	sub    %rax,%rsi
    ee0b:	49 19 d1             	sbb    %rdx,%r9
    ee0e:	eb e0                	jmp    edf0 <__divmodti4+0x1f0>

000000000000ee10 <atexit>:
    ee10:	f3 0f 1e fa          	endbr64
    ee14:	48 8b 15 ed 41 00 00 	mov    0x41ed(%rip),%rdx        # 13008 <__dso_handle>
    ee1b:	31 f6                	xor    %esi,%esi
    ee1d:	e9 fe 47 ff ff       	jmp    3620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ee24 <_fini>:
    ee24:	f3 0f 1e fa          	endbr64
    ee28:	48 83 ec 08          	sub    $0x8,%rsp
    ee2c:	48 83 c4 08          	add    $0x8,%rsp
    ee30:	c3                   	ret
