
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-explicit-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000002000 <_init>:
    2000:	f3 0f 1e fa          	endbr64
    2004:	48 83 ec 08          	sub    $0x8,%rsp
    2008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # efe0 <__gmon_start__>
    200f:	48 85 c0             	test   %rax,%rax
    2012:	74 02                	je     2016 <_init+0x16>
    2014:	ff d0                	call   *%rax
    2016:	48 83 c4 08          	add    $0x8,%rsp
    201a:	c3                   	ret

Disassembly of section .plt:

0000000000002020 <.plt>:
    2020:	ff 35 fa cd 00 00    	push   0xcdfa(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x8>
    2026:	ff 25 fc cd 00 00    	jmp    *0xcdfc(%rip)        # ee28 <_GLOBAL_OFFSET_TABLE_+0x10>
    202c:	0f 1f 40 00          	nopl   0x0(%rax)
    2030:	f3 0f 1e fa          	endbr64
    2034:	68 00 00 00 00       	push   $0x0
    2039:	e9 e2 ff ff ff       	jmp    2020 <_init+0x20>
    203e:	66 90                	xchg   %ax,%ax
    2040:	f3 0f 1e fa          	endbr64
    2044:	68 01 00 00 00       	push   $0x1
    2049:	e9 d2 ff ff ff       	jmp    2020 <_init+0x20>
    204e:	66 90                	xchg   %ax,%ax
    2050:	f3 0f 1e fa          	endbr64
    2054:	68 02 00 00 00       	push   $0x2
    2059:	e9 c2 ff ff ff       	jmp    2020 <_init+0x20>
    205e:	66 90                	xchg   %ax,%ax
    2060:	f3 0f 1e fa          	endbr64
    2064:	68 03 00 00 00       	push   $0x3
    2069:	e9 b2 ff ff ff       	jmp    2020 <_init+0x20>
    206e:	66 90                	xchg   %ax,%ax
    2070:	f3 0f 1e fa          	endbr64
    2074:	68 04 00 00 00       	push   $0x4
    2079:	e9 a2 ff ff ff       	jmp    2020 <_init+0x20>
    207e:	66 90                	xchg   %ax,%ax
    2080:	f3 0f 1e fa          	endbr64
    2084:	68 05 00 00 00       	push   $0x5
    2089:	e9 92 ff ff ff       	jmp    2020 <_init+0x20>
    208e:	66 90                	xchg   %ax,%ax
    2090:	f3 0f 1e fa          	endbr64
    2094:	68 06 00 00 00       	push   $0x6
    2099:	e9 82 ff ff ff       	jmp    2020 <_init+0x20>
    209e:	66 90                	xchg   %ax,%ax
    20a0:	f3 0f 1e fa          	endbr64
    20a4:	68 07 00 00 00       	push   $0x7
    20a9:	e9 72 ff ff ff       	jmp    2020 <_init+0x20>
    20ae:	66 90                	xchg   %ax,%ax
    20b0:	f3 0f 1e fa          	endbr64
    20b4:	68 08 00 00 00       	push   $0x8
    20b9:	e9 62 ff ff ff       	jmp    2020 <_init+0x20>
    20be:	66 90                	xchg   %ax,%ax
    20c0:	f3 0f 1e fa          	endbr64
    20c4:	68 09 00 00 00       	push   $0x9
    20c9:	e9 52 ff ff ff       	jmp    2020 <_init+0x20>
    20ce:	66 90                	xchg   %ax,%ax
    20d0:	f3 0f 1e fa          	endbr64
    20d4:	68 0a 00 00 00       	push   $0xa
    20d9:	e9 42 ff ff ff       	jmp    2020 <_init+0x20>
    20de:	66 90                	xchg   %ax,%ax
    20e0:	f3 0f 1e fa          	endbr64
    20e4:	68 0b 00 00 00       	push   $0xb
    20e9:	e9 32 ff ff ff       	jmp    2020 <_init+0x20>
    20ee:	66 90                	xchg   %ax,%ax
    20f0:	f3 0f 1e fa          	endbr64
    20f4:	68 0c 00 00 00       	push   $0xc
    20f9:	e9 22 ff ff ff       	jmp    2020 <_init+0x20>
    20fe:	66 90                	xchg   %ax,%ax
    2100:	f3 0f 1e fa          	endbr64
    2104:	68 0d 00 00 00       	push   $0xd
    2109:	e9 12 ff ff ff       	jmp    2020 <_init+0x20>
    210e:	66 90                	xchg   %ax,%ax
    2110:	f3 0f 1e fa          	endbr64
    2114:	68 0e 00 00 00       	push   $0xe
    2119:	e9 02 ff ff ff       	jmp    2020 <_init+0x20>
    211e:	66 90                	xchg   %ax,%ax
    2120:	f3 0f 1e fa          	endbr64
    2124:	68 0f 00 00 00       	push   $0xf
    2129:	e9 f2 fe ff ff       	jmp    2020 <_init+0x20>
    212e:	66 90                	xchg   %ax,%ax
    2130:	f3 0f 1e fa          	endbr64
    2134:	68 10 00 00 00       	push   $0x10
    2139:	e9 e2 fe ff ff       	jmp    2020 <_init+0x20>
    213e:	66 90                	xchg   %ax,%ax
    2140:	f3 0f 1e fa          	endbr64
    2144:	68 11 00 00 00       	push   $0x11
    2149:	e9 d2 fe ff ff       	jmp    2020 <_init+0x20>
    214e:	66 90                	xchg   %ax,%ax
    2150:	f3 0f 1e fa          	endbr64
    2154:	68 12 00 00 00       	push   $0x12
    2159:	e9 c2 fe ff ff       	jmp    2020 <_init+0x20>
    215e:	66 90                	xchg   %ax,%ax
    2160:	f3 0f 1e fa          	endbr64
    2164:	68 13 00 00 00       	push   $0x13
    2169:	e9 b2 fe ff ff       	jmp    2020 <_init+0x20>
    216e:	66 90                	xchg   %ax,%ax
    2170:	f3 0f 1e fa          	endbr64
    2174:	68 14 00 00 00       	push   $0x14
    2179:	e9 a2 fe ff ff       	jmp    2020 <_init+0x20>
    217e:	66 90                	xchg   %ax,%ax
    2180:	f3 0f 1e fa          	endbr64
    2184:	68 15 00 00 00       	push   $0x15
    2189:	e9 92 fe ff ff       	jmp    2020 <_init+0x20>
    218e:	66 90                	xchg   %ax,%ax
    2190:	f3 0f 1e fa          	endbr64
    2194:	68 16 00 00 00       	push   $0x16
    2199:	e9 82 fe ff ff       	jmp    2020 <_init+0x20>
    219e:	66 90                	xchg   %ax,%ax
    21a0:	f3 0f 1e fa          	endbr64
    21a4:	68 17 00 00 00       	push   $0x17
    21a9:	e9 72 fe ff ff       	jmp    2020 <_init+0x20>
    21ae:	66 90                	xchg   %ax,%ax
    21b0:	f3 0f 1e fa          	endbr64
    21b4:	68 18 00 00 00       	push   $0x18
    21b9:	e9 62 fe ff ff       	jmp    2020 <_init+0x20>
    21be:	66 90                	xchg   %ax,%ax
    21c0:	f3 0f 1e fa          	endbr64
    21c4:	68 19 00 00 00       	push   $0x19
    21c9:	e9 52 fe ff ff       	jmp    2020 <_init+0x20>
    21ce:	66 90                	xchg   %ax,%ax
    21d0:	f3 0f 1e fa          	endbr64
    21d4:	68 1a 00 00 00       	push   $0x1a
    21d9:	e9 42 fe ff ff       	jmp    2020 <_init+0x20>
    21de:	66 90                	xchg   %ax,%ax
    21e0:	f3 0f 1e fa          	endbr64
    21e4:	68 1b 00 00 00       	push   $0x1b
    21e9:	e9 32 fe ff ff       	jmp    2020 <_init+0x20>
    21ee:	66 90                	xchg   %ax,%ax
    21f0:	f3 0f 1e fa          	endbr64
    21f4:	68 1c 00 00 00       	push   $0x1c
    21f9:	e9 22 fe ff ff       	jmp    2020 <_init+0x20>
    21fe:	66 90                	xchg   %ax,%ax
    2200:	f3 0f 1e fa          	endbr64
    2204:	68 1d 00 00 00       	push   $0x1d
    2209:	e9 12 fe ff ff       	jmp    2020 <_init+0x20>
    220e:	66 90                	xchg   %ax,%ax
    2210:	f3 0f 1e fa          	endbr64
    2214:	68 1e 00 00 00       	push   $0x1e
    2219:	e9 02 fe ff ff       	jmp    2020 <_init+0x20>
    221e:	66 90                	xchg   %ax,%ax
    2220:	f3 0f 1e fa          	endbr64
    2224:	68 1f 00 00 00       	push   $0x1f
    2229:	e9 f2 fd ff ff       	jmp    2020 <_init+0x20>
    222e:	66 90                	xchg   %ax,%ax
    2230:	f3 0f 1e fa          	endbr64
    2234:	68 20 00 00 00       	push   $0x20
    2239:	e9 e2 fd ff ff       	jmp    2020 <_init+0x20>
    223e:	66 90                	xchg   %ax,%ax
    2240:	f3 0f 1e fa          	endbr64
    2244:	68 21 00 00 00       	push   $0x21
    2249:	e9 d2 fd ff ff       	jmp    2020 <_init+0x20>
    224e:	66 90                	xchg   %ax,%ax
    2250:	f3 0f 1e fa          	endbr64
    2254:	68 22 00 00 00       	push   $0x22
    2259:	e9 c2 fd ff ff       	jmp    2020 <_init+0x20>
    225e:	66 90                	xchg   %ax,%ax
    2260:	f3 0f 1e fa          	endbr64
    2264:	68 23 00 00 00       	push   $0x23
    2269:	e9 b2 fd ff ff       	jmp    2020 <_init+0x20>
    226e:	66 90                	xchg   %ax,%ax
    2270:	f3 0f 1e fa          	endbr64
    2274:	68 24 00 00 00       	push   $0x24
    2279:	e9 a2 fd ff ff       	jmp    2020 <_init+0x20>
    227e:	66 90                	xchg   %ax,%ax
    2280:	f3 0f 1e fa          	endbr64
    2284:	68 25 00 00 00       	push   $0x25
    2289:	e9 92 fd ff ff       	jmp    2020 <_init+0x20>
    228e:	66 90                	xchg   %ax,%ax
    2290:	f3 0f 1e fa          	endbr64
    2294:	68 26 00 00 00       	push   $0x26
    2299:	e9 82 fd ff ff       	jmp    2020 <_init+0x20>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	f3 0f 1e fa          	endbr64
    22a4:	68 27 00 00 00       	push   $0x27
    22a9:	e9 72 fd ff ff       	jmp    2020 <_init+0x20>
    22ae:	66 90                	xchg   %ax,%ax
    22b0:	f3 0f 1e fa          	endbr64
    22b4:	68 28 00 00 00       	push   $0x28
    22b9:	e9 62 fd ff ff       	jmp    2020 <_init+0x20>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	f3 0f 1e fa          	endbr64
    22c4:	68 29 00 00 00       	push   $0x29
    22c9:	e9 52 fd ff ff       	jmp    2020 <_init+0x20>
    22ce:	66 90                	xchg   %ax,%ax
    22d0:	f3 0f 1e fa          	endbr64
    22d4:	68 2a 00 00 00       	push   $0x2a
    22d9:	e9 42 fd ff ff       	jmp    2020 <_init+0x20>
    22de:	66 90                	xchg   %ax,%ax
    22e0:	f3 0f 1e fa          	endbr64
    22e4:	68 2b 00 00 00       	push   $0x2b
    22e9:	e9 32 fd ff ff       	jmp    2020 <_init+0x20>
    22ee:	66 90                	xchg   %ax,%ax
    22f0:	f3 0f 1e fa          	endbr64
    22f4:	68 2c 00 00 00       	push   $0x2c
    22f9:	e9 22 fd ff ff       	jmp    2020 <_init+0x20>
    22fe:	66 90                	xchg   %ax,%ax
    2300:	f3 0f 1e fa          	endbr64
    2304:	68 2d 00 00 00       	push   $0x2d
    2309:	e9 12 fd ff ff       	jmp    2020 <_init+0x20>
    230e:	66 90                	xchg   %ax,%ax
    2310:	f3 0f 1e fa          	endbr64
    2314:	68 2e 00 00 00       	push   $0x2e
    2319:	e9 02 fd ff ff       	jmp    2020 <_init+0x20>
    231e:	66 90                	xchg   %ax,%ax
    2320:	f3 0f 1e fa          	endbr64
    2324:	68 2f 00 00 00       	push   $0x2f
    2329:	e9 f2 fc ff ff       	jmp    2020 <_init+0x20>
    232e:	66 90                	xchg   %ax,%ax
    2330:	f3 0f 1e fa          	endbr64
    2334:	68 30 00 00 00       	push   $0x30
    2339:	e9 e2 fc ff ff       	jmp    2020 <_init+0x20>
    233e:	66 90                	xchg   %ax,%ax
    2340:	f3 0f 1e fa          	endbr64
    2344:	68 31 00 00 00       	push   $0x31
    2349:	e9 d2 fc ff ff       	jmp    2020 <_init+0x20>
    234e:	66 90                	xchg   %ax,%ax
    2350:	f3 0f 1e fa          	endbr64
    2354:	68 32 00 00 00       	push   $0x32
    2359:	e9 c2 fc ff ff       	jmp    2020 <_init+0x20>
    235e:	66 90                	xchg   %ax,%ax
    2360:	f3 0f 1e fa          	endbr64
    2364:	68 33 00 00 00       	push   $0x33
    2369:	e9 b2 fc ff ff       	jmp    2020 <_init+0x20>
    236e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000002370 <__cxa_finalize@plt>:
    2370:	f3 0f 1e fa          	endbr64
    2374:	ff 25 76 cc 00 00    	jmp    *0xcc76(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    237a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000002380 <getenv@plt>:
    2380:	f3 0f 1e fa          	endbr64
    2384:	ff 25 a6 ca 00 00    	jmp    *0xcaa6(%rip)        # ee30 <getenv@GLIBC_2.2.5>
    238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002390 <__snprintf_chk@plt>:
    2390:	f3 0f 1e fa          	endbr64
    2394:	ff 25 9e ca 00 00    	jmp    *0xca9e(%rip)        # ee38 <__snprintf_chk@GLIBC_2.3.4>
    239a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023a0 <free@plt>:
    23a0:	f3 0f 1e fa          	endbr64
    23a4:	ff 25 96 ca 00 00    	jmp    *0xca96(%rip)        # ee40 <free@GLIBC_2.2.5>
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023b0 <abort@plt>:
    23b0:	f3 0f 1e fa          	endbr64
    23b4:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # ee48 <abort@GLIBC_2.2.5>
    23ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023c0 <_exit@plt>:
    23c0:	f3 0f 1e fa          	endbr64
    23c4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # ee50 <_exit@GLIBC_2.2.5>
    23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023d0 <strcpy@plt>:
    23d0:	f3 0f 1e fa          	endbr64
    23d4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # ee58 <strcpy@GLIBC_2.2.5>
    23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023e0 <sigaction@plt>:
    23e0:	f3 0f 1e fa          	endbr64
    23e4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # ee60 <sigaction@GLIBC_2.2.5>
    23ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000023f0 <strtod@plt>:
    23f0:	f3 0f 1e fa          	endbr64
    23f4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # ee68 <strtod@GLIBC_2.2.5>
    23fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002400 <clock_gettime@plt>:
    2400:	f3 0f 1e fa          	endbr64
    2404:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # ee70 <clock_gettime@GLIBC_2.17>
    240a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002410 <write@plt>:
    2410:	f3 0f 1e fa          	endbr64
    2414:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # ee78 <write@GLIBC_2.2.5>
    241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002420 <fclose@plt>:
    2420:	f3 0f 1e fa          	endbr64
    2424:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # ee80 <fclose@GLIBC_2.2.5>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002430 <strlen@plt>:
    2430:	f3 0f 1e fa          	endbr64
    2434:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # ee88 <strlen@GLIBC_2.2.5>
    243a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002440 <__stack_chk_fail@plt>:
    2440:	f3 0f 1e fa          	endbr64
    2444:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # ee90 <__stack_chk_fail@GLIBC_2.4>
    244a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002450 <mmap@plt>:
    2450:	f3 0f 1e fa          	endbr64
    2454:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # ee98 <mmap@GLIBC_2.2.5>
    245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002460 <strchr@plt>:
    2460:	f3 0f 1e fa          	endbr64
    2464:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # eea0 <strchr@GLIBC_2.2.5>
    246a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002470 <swapcontext@plt>:
    2470:	f3 0f 1e fa          	endbr64
    2474:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # eea8 <swapcontext@GLIBC_2.2.5>
    247a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002480 <nanosleep@plt>:
    2480:	f3 0f 1e fa          	endbr64
    2484:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # eeb0 <nanosleep@GLIBC_2.2.5>
    248a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002490 <strtof@plt>:
    2490:	f3 0f 1e fa          	endbr64
    2494:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # eeb8 <strtof@GLIBC_2.2.5>
    249a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024a0 <memset@plt>:
    24a0:	f3 0f 1e fa          	endbr64
    24a4:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # eec0 <memset@GLIBC_2.2.5>
    24aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024b0 <close@plt>:
    24b0:	f3 0f 1e fa          	endbr64
    24b4:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # eec8 <close@GLIBC_2.2.5>
    24ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024c0 <fputc@plt>:
    24c0:	f3 0f 1e fa          	endbr64
    24c4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # eed0 <fputc@GLIBC_2.2.5>
    24ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024d0 <pthread_attr_init@plt>:
    24d0:	f3 0f 1e fa          	endbr64
    24d4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # eed8 <pthread_attr_init@GLIBC_2.2.5>
    24da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024e0 <fgets@plt>:
    24e0:	f3 0f 1e fa          	endbr64
    24e4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # eee0 <fgets@GLIBC_2.2.5>
    24ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000024f0 <strtoull@plt>:
    24f0:	f3 0f 1e fa          	endbr64
    24f4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # eee8 <strtoull@GLIBC_2.2.5>
    24fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002500 <calloc@plt>:
    2500:	f3 0f 1e fa          	endbr64
    2504:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # eef0 <calloc@GLIBC_2.2.5>
    250a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002510 <strcmp@plt>:
    2510:	f3 0f 1e fa          	endbr64
    2514:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # eef8 <strcmp@GLIBC_2.2.5>
    251a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002520 <signal@plt>:
    2520:	f3 0f 1e fa          	endbr64
    2524:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # ef00 <signal@GLIBC_2.2.5>
    252a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002530 <strtoll@plt>:
    2530:	f3 0f 1e fa          	endbr64
    2534:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # ef08 <strtoll@GLIBC_2.2.5>
    253a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002540 <__memcpy_chk@plt>:
    2540:	f3 0f 1e fa          	endbr64
    2544:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # ef10 <__memcpy_chk@GLIBC_2.3.4>
    254a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002550 <sigemptyset@plt>:
    2550:	f3 0f 1e fa          	endbr64
    2554:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # ef18 <sigemptyset@GLIBC_2.2.5>
    255a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002560 <strtol@plt>:
    2560:	f3 0f 1e fa          	endbr64
    2564:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ef20 <strtol@GLIBC_2.2.5>
    256a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002570 <memcpy@plt>:
    2570:	f3 0f 1e fa          	endbr64
    2574:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ef28 <memcpy@GLIBC_2.14>
    257a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002580 <malloc@plt>:
    2580:	f3 0f 1e fa          	endbr64
    2584:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ef30 <malloc@GLIBC_2.2.5>
    258a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002590 <fflush@plt>:
    2590:	f3 0f 1e fa          	endbr64
    2594:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ef38 <fflush@GLIBC_2.2.5>
    259a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025a0 <realloc@plt>:
    25a0:	f3 0f 1e fa          	endbr64
    25a4:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ef40 <realloc@GLIBC_2.2.5>
    25aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025b0 <munmap@plt>:
    25b0:	f3 0f 1e fa          	endbr64
    25b4:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ef48 <munmap@GLIBC_2.2.5>
    25ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025c0 <setvbuf@plt>:
    25c0:	f3 0f 1e fa          	endbr64
    25c4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ef50 <setvbuf@GLIBC_2.2.5>
    25ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025d0 <pthread_create@plt>:
    25d0:	f3 0f 1e fa          	endbr64
    25d4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ef58 <pthread_create@GLIBC_2.34>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025e0 <mprotect@plt>:
    25e0:	f3 0f 1e fa          	endbr64
    25e4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    25ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000025f0 <fopen@plt>:
    25f0:	f3 0f 1e fa          	endbr64
    25f4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    25fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002600 <sysconf@plt>:
    2600:	f3 0f 1e fa          	endbr64
    2604:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    260a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002610 <pthread_attr_destroy@plt>:
    2610:	f3 0f 1e fa          	endbr64
    2614:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    261a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002620 <__cxa_atexit@plt>:
    2620:	f3 0f 1e fa          	endbr64
    2624:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    262a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002630 <exit@plt>:
    2630:	f3 0f 1e fa          	endbr64
    2634:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    263a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002640 <fwrite@plt>:
    2640:	f3 0f 1e fa          	endbr64
    2644:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002650 <__fprintf_chk@plt>:
    2650:	f3 0f 1e fa          	endbr64
    2654:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    265a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002660 <_Exit@plt>:
    2660:	f3 0f 1e fa          	endbr64
    2664:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    266a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002670 <pthread_join@plt>:
    2670:	f3 0f 1e fa          	endbr64
    2674:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    267a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002680 <sigaltstack@plt>:
    2680:	f3 0f 1e fa          	endbr64
    2684:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    268a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002690 <strstr@plt>:
    2690:	f3 0f 1e fa          	endbr64
    2694:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    269a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	f3 0f 1e fa          	endbr64
    26a4:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    26aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000026b0 <pthread_attr_setstacksize@plt>:
    26b0:	f3 0f 1e fa          	endbr64
    26b4:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    26ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000026c0 <fwp_trap_overflow.constprop.0>:
    26c0:	53                   	push   %rbx
    26c1:	b9 60 00 00 00       	mov    $0x60,%ecx
    26c6:	ba 02 00 00 00       	mov    $0x2,%edx
    26cb:	be 60 00 00 00       	mov    $0x60,%esi
    26d0:	4c 8d 0d e0 99 00 00 	lea    0x99e0(%rip),%r9        # c0b7 <_IO_stdin_used+0xb7>
    26d7:	4c 8d 05 dd 99 00 00 	lea    0x99dd(%rip),%r8        # c0bb <_IO_stdin_used+0xbb>
    26de:	48 83 ec 70          	sub    $0x70,%rsp
    26e2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    26e9:	00 00 
    26eb:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    26f0:	31 c0                	xor    %eax,%eax
    26f2:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    26f7:	e8 94 fc ff ff       	call   2390 <__snprintf_chk@plt>
    26fc:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    2701:	e8 6a 0b 00 00       	call   3270 <fwp_trap>

0000000000002706 <fwp_task_dispose.cold>:
    2706:	e8 a5 fc ff ff       	call   23b0 <abort@plt>

000000000000270b <fwp_loop_fields68.constprop.0.cold>:
    270b:	e8 b0 ff ff ff       	call   26c0 <fwp_trap_overflow.constprop.0>

0000000000002710 <fwp_main_thread.cold>:
    2710:	e8 9b fc ff ff       	call   23b0 <abort@plt>

0000000000002715 <main.cold>:
    2715:	e8 96 fc ff ff       	call   23b0 <abort@plt>
    271a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000002720 <main>:
    2720:	f3 0f 1e fa          	endbr64
    2724:	55                   	push   %rbp
    2725:	53                   	push   %rbx
    2726:	48 83 ec 68          	sub    $0x68,%rsp
    272a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2731:	00 00 
    2733:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2738:	48 8b 05 e1 c8 00 00 	mov    0xc8e1(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    273f:	48 89 05 12 ec 01 00 	mov    %rax,0x1ec12(%rip)        # 21358 <fwp_prog_out>
    2746:	e8 55 0b 00 00       	call   32a0 <fwp_now_ns>
    274b:	48 8d 3d 75 9a 00 00 	lea    0x9a75(%rip),%rdi        # c1c7 <_IO_stdin_used+0x1c7>
    2752:	e8 29 fc ff ff       	call   2380 <getenv@plt>
    2757:	48 85 c0             	test   %rax,%rax
    275a:	74 0c                	je     2768 <main+0x48>
    275c:	48 89 c3             	mov    %rax,%rbx
    275f:	80 38 00             	cmpb   $0x0,(%rax)
    2762:	0f 85 09 01 00 00    	jne    2871 <main+0x151>
    2768:	31 ff                	xor    %edi,%edi
    276a:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    276f:	e8 8c fc ff ff       	call   2400 <clock_gettime@plt>
    2774:	85 c0                	test   %eax,%eax
    2776:	0f 85 28 01 00 00    	jne    28a4 <main+0x184>
    277c:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2781:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    2786:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    278b:	48 89 cb             	mov    %rcx,%rbx
    278e:	48 c1 fb 3f          	sar    $0x3f,%rbx
    2792:	48 01 c8             	add    %rcx,%rax
    2795:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    279c:	00 00 80 
    279f:	48 11 da             	adc    %rbx,%rdx
    27a2:	31 db                	xor    %ebx,%ebx
    27a4:	48 01 c8             	add    %rcx,%rax
    27a7:	48 11 da             	adc    %rbx,%rdx
    27aa:	48 85 d2             	test   %rdx,%rdx
    27ad:	0f 85 38 01 00 00    	jne    28eb <main+0x1cb>
    27b3:	48 8b 3d 66 c8 00 00 	mov    0xc866(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    27ba:	31 d2                	xor    %edx,%edx
    27bc:	31 f6                	xor    %esi,%esi
    27be:	b9 00 00 01 00       	mov    $0x10000,%ecx
    27c3:	e8 f8 fd ff ff       	call   25c0 <setvbuf@plt>
    27c8:	bf 0d 00 00 00       	mov    $0xd,%edi
    27cd:	be 01 00 00 00       	mov    $0x1,%esi
    27d2:	e8 49 fd ff ff       	call   2520 <signal@plt>
    27d7:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27dc:	e8 ef fc ff ff       	call   24d0 <pthread_attr_init@plt>
    27e1:	85 c0                	test   %eax,%eax
    27e3:	0f 85 f6 00 00 00    	jne    28df <main+0x1bf>
    27e9:	be 00 00 00 40       	mov    $0x40000000,%esi
    27ee:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    27f3:	e8 b8 fe ff ff       	call   26b0 <pthread_attr_setstacksize@plt>
    27f8:	85 c0                	test   %eax,%eax
    27fa:	0f 85 c1 00 00 00    	jne    28c1 <main+0x1a1>
    2800:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    2805:	31 c9                	xor    %ecx,%ecx
    2807:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    280c:	48 8d 15 1d 89 00 00 	lea    0x891d(%rip),%rdx        # b130 <fwp_main_thread>
    2813:	e8 b8 fd ff ff       	call   25d0 <pthread_create@plt>
    2818:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    281d:	89 c5                	mov    %eax,%ebp
    281f:	e8 ec fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    2824:	85 c0                	test   %eax,%eax
    2826:	0f 85 e9 fe ff ff    	jne    2715 <main.cold>
    282c:	85 ed                	test   %ebp,%ebp
    282e:	0f 85 81 00 00 00    	jne    28b5 <main+0x195>
    2834:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2839:	31 f6                	xor    %esi,%esi
    283b:	e8 30 fe ff ff       	call   2670 <pthread_join@plt>
    2840:	85 c0                	test   %eax,%eax
    2842:	0f 85 cd fe ff ff    	jne    2715 <main.cold>
    2848:	48 8b 3d d1 c7 00 00 	mov    0xc7d1(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    284f:	e8 3c fd ff ff       	call   2590 <fflush@plt>
    2854:	8b 05 26 c8 01 00    	mov    0x1c826(%rip),%eax        # 1f080 <fwp_exit_code>
    285a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    285f:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    2866:	00 00 
    2868:	75 46                	jne    28b0 <main+0x190>
    286a:	48 83 c4 68          	add    $0x68,%rsp
    286e:	5b                   	pop    %rbx
    286f:	5d                   	pop    %rbp
    2870:	c3                   	ret
    2871:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    2876:	ba 0a 00 00 00       	mov    $0xa,%edx
    287b:	48 89 c7             	mov    %rax,%rdi
    287e:	e8 6d fc ff ff       	call   24f0 <strtoull@plt>
    2883:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2888:	80 38 00             	cmpb   $0x0,(%rax)
    288b:	0f 85 d7 fe ff ff    	jne    2768 <main+0x48>
    2891:	0f b6 03             	movzbl (%rbx),%eax
    2894:	83 e8 2b             	sub    $0x2b,%eax
    2897:	a8 fd                	test   $0xfd,%al
    2899:	0f 84 c9 fe ff ff    	je     2768 <main+0x48>
    289f:	e9 0f ff ff ff       	jmp    27b3 <main+0x93>
    28a4:	48 8d 3d 25 99 00 00 	lea    0x9925(%rip),%rdi        # c1d0 <_IO_stdin_used+0x1d0>
    28ab:	e8 c0 09 00 00       	call   3270 <fwp_trap>
    28b0:	e8 8b fb ff ff       	call   2440 <__stack_chk_fail@plt>
    28b5:	48 8d 3d 7c 9c 00 00 	lea    0x9c7c(%rip),%rdi        # c538 <_IO_stdin_used+0x538>
    28bc:	e8 af 09 00 00       	call   3270 <fwp_trap>
    28c1:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    28c6:	e8 45 fd ff ff       	call   2610 <pthread_attr_destroy@plt>
    28cb:	85 c0                	test   %eax,%eax
    28cd:	0f 85 42 fe ff ff    	jne    2715 <main.cold>
    28d3:	48 8d 3d 36 9c 00 00 	lea    0x9c36(%rip),%rdi        # c510 <_IO_stdin_used+0x510>
    28da:	e8 91 09 00 00       	call   3270 <fwp_trap>
    28df:	48 8d 3d fa 9b 00 00 	lea    0x9bfa(%rip),%rdi        # c4e0 <_IO_stdin_used+0x4e0>
    28e6:	e8 85 09 00 00       	call   3270 <fwp_trap>
    28eb:	48 8d 3d c6 9b 00 00 	lea    0x9bc6(%rip),%rdi        # c4b8 <_IO_stdin_used+0x4b8>
    28f2:	e8 79 09 00 00       	call   3270 <fwp_trap>
    28f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    28fe:	00 00 

0000000000002900 <_start>:
    2900:	f3 0f 1e fa          	endbr64
    2904:	31 ed                	xor    %ebp,%ebp
    2906:	49 89 d1             	mov    %rdx,%r9
    2909:	5e                   	pop    %rsi
    290a:	48 89 e2             	mov    %rsp,%rdx
    290d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    2911:	50                   	push   %rax
    2912:	54                   	push   %rsp
    2913:	45 31 c0             	xor    %r8d,%r8d
    2916:	31 c9                	xor    %ecx,%ecx
    2918:	48 8d 3d 01 fe ff ff 	lea    -0x1ff(%rip),%rdi        # 2720 <main>
    291f:	ff 15 ab c6 00 00    	call   *0xc6ab(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    2925:	f4                   	hlt
    2926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    292d:	00 00 00 

0000000000002930 <deregister_tm_clones>:
    2930:	48 8d 3d e1 c6 00 00 	lea    0xc6e1(%rip),%rdi        # f018 <__TMC_END__>
    2937:	48 8d 05 da c6 00 00 	lea    0xc6da(%rip),%rax        # f018 <__TMC_END__>
    293e:	48 39 f8             	cmp    %rdi,%rax
    2941:	74 15                	je     2958 <deregister_tm_clones+0x28>
    2943:	48 8b 05 8e c6 00 00 	mov    0xc68e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    294a:	48 85 c0             	test   %rax,%rax
    294d:	74 09                	je     2958 <deregister_tm_clones+0x28>
    294f:	ff e0                	jmp    *%rax
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	c3                   	ret
    2959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000002960 <register_tm_clones>:
    2960:	48 8d 3d b1 c6 00 00 	lea    0xc6b1(%rip),%rdi        # f018 <__TMC_END__>
    2967:	48 8d 35 aa c6 00 00 	lea    0xc6aa(%rip),%rsi        # f018 <__TMC_END__>
    296e:	48 29 fe             	sub    %rdi,%rsi
    2971:	48 89 f0             	mov    %rsi,%rax
    2974:	48 c1 ee 3f          	shr    $0x3f,%rsi
    2978:	48 c1 f8 03          	sar    $0x3,%rax
    297c:	48 01 c6             	add    %rax,%rsi
    297f:	48 d1 fe             	sar    $1,%rsi
    2982:	74 14                	je     2998 <register_tm_clones+0x38>
    2984:	48 8b 05 5d c6 00 00 	mov    0xc65d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    298b:	48 85 c0             	test   %rax,%rax
    298e:	74 08                	je     2998 <register_tm_clones+0x38>
    2990:	ff e0                	jmp    *%rax
    2992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2998:	c3                   	ret
    2999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029a0 <__do_global_dtors_aux>:
    29a0:	f3 0f 1e fa          	endbr64
    29a4:	80 3d 9d c6 00 00 00 	cmpb   $0x0,0xc69d(%rip)        # f048 <completed.0>
    29ab:	75 2b                	jne    29d8 <__do_global_dtors_aux+0x38>
    29ad:	55                   	push   %rbp
    29ae:	48 83 3d 3a c6 00 00 	cmpq   $0x0,0xc63a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    29b5:	00 
    29b6:	48 89 e5             	mov    %rsp,%rbp
    29b9:	74 0c                	je     29c7 <__do_global_dtors_aux+0x27>
    29bb:	48 8b 3d 46 c6 00 00 	mov    0xc646(%rip),%rdi        # f008 <__dso_handle>
    29c2:	e8 a9 f9 ff ff       	call   2370 <__cxa_finalize@plt>
    29c7:	e8 64 ff ff ff       	call   2930 <deregister_tm_clones>
    29cc:	c6 05 75 c6 00 00 01 	movb   $0x1,0xc675(%rip)        # f048 <completed.0>
    29d3:	5d                   	pop    %rbp
    29d4:	c3                   	ret
    29d5:	0f 1f 00             	nopl   (%rax)
    29d8:	c3                   	ret
    29d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000029e0 <frame_dummy>:
    29e0:	f3 0f 1e fa          	endbr64
    29e4:	e9 77 ff ff ff       	jmp    2960 <register_tm_clones>
    29e9:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29f0:	00 00 00 
    29f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    29fa:	00 00 00 
    29fd:	0f 1f 00             	nopl   (%rax)

0000000000002a00 <fwp_fmt_u128>:
    2a00:	41 57                	push   %r15
    2a02:	41 56                	push   %r14
    2a04:	41 55                	push   %r13
    2a06:	41 54                	push   %r12
    2a08:	55                   	push   %rbp
    2a09:	53                   	push   %rbx
    2a0a:	48 83 ec 68          	sub    $0x68,%rsp
    2a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    2a15:	00 00 
    2a17:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    2a1c:	48 89 f0             	mov    %rsi,%rax
    2a1f:	48 09 d0             	or     %rdx,%rax
    2a22:	75 7c                	jne    2aa0 <fwp_fmt_u128+0xa0>
    2a24:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    2a29:	bd 01 00 00 00       	mov    $0x1,%ebp
    2a2e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2a33:	8d 55 ff             	lea    -0x1(%rbp),%edx
    2a36:	48 89 f8             	mov    %rdi,%rax
    2a39:	49 01 d4             	add    %rdx,%r12
    2a3c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    2a41:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a48:	00 00 
    2a4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a51:	00 00 00 00 
    2a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2a5c:	00 00 00 00 
    2a60:	41 0f b6 14 24       	movzbl (%r12),%edx
    2a65:	48 83 c0 01          	add    $0x1,%rax
    2a69:	49 83 ec 01          	sub    $0x1,%r12
    2a6d:	88 50 ff             	mov    %dl,-0x1(%rax)
    2a70:	48 39 c8             	cmp    %rcx,%rax
    2a73:	75 eb                	jne    2a60 <fwp_fmt_u128+0x60>
    2a75:	48 63 ed             	movslq %ebp,%rbp
    2a78:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    2a7c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    2a81:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    2a88:	00 00 
    2a8a:	0f 85 ef 00 00 00    	jne    2b7f <fwp_fmt_u128+0x17f>
    2a90:	48 83 c4 68          	add    $0x68,%rsp
    2a94:	5b                   	pop    %rbx
    2a95:	5d                   	pop    %rbp
    2a96:	41 5c                	pop    %r12
    2a98:	41 5d                	pop    %r13
    2a9a:	41 5e                	pop    %r14
    2a9c:	41 5f                	pop    %r15
    2a9e:	c3                   	ret
    2a9f:	90                   	nop
    2aa0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    2aa5:	49 89 f2             	mov    %rsi,%r10
    2aa8:	49 89 d3             	mov    %rdx,%r11
    2aab:	31 ed                	xor    %ebp,%ebp
    2aad:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    2ab2:	4c 89 e3             	mov    %r12,%rbx
    2ab5:	45 31 f6             	xor    %r14d,%r14d
    2ab8:	49 89 f9             	mov    %rdi,%r9
    2abb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    2ac2:	cc cc cc 
    2ac5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    2acb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    2ad2:	cc cc cc 
    2ad5:	4c 89 2c 24          	mov    %r13,(%rsp)
    2ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ae0:	4c 89 d6             	mov    %r10,%rsi
    2ae3:	4c 89 df             	mov    %r11,%rdi
    2ae6:	4c 01 de             	add    %r11,%rsi
    2ae9:	48 83 d6 00          	adc    $0x0,%rsi
    2aed:	45 31 ed             	xor    %r13d,%r13d
    2af0:	48 89 f0             	mov    %rsi,%rax
    2af3:	48 f7 e1             	mul    %rcx
    2af6:	48 89 d0             	mov    %rdx,%rax
    2af9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    2afd:	48 c1 e8 02          	shr    $0x2,%rax
    2b01:	48 01 c2             	add    %rax,%rdx
    2b04:	48 8b 04 24          	mov    (%rsp),%rax
    2b08:	48 29 d6             	sub    %rdx,%rsi
    2b0b:	49 89 f4             	mov    %rsi,%r12
    2b0e:	4c 89 d6             	mov    %r10,%rsi
    2b11:	4c 29 e6             	sub    %r12,%rsi
    2b14:	4c 19 ef             	sbb    %r13,%rdi
    2b17:	48 0f af c6          	imul   %rsi,%rax
    2b1b:	49 89 f8             	mov    %rdi,%r8
    2b1e:	4c 0f af c1          	imul   %rcx,%r8
    2b22:	49 01 c0             	add    %rax,%r8
    2b25:	48 89 f0             	mov    %rsi,%rax
    2b28:	48 f7 e1             	mul    %rcx
    2b2b:	48 89 c6             	mov    %rax,%rsi
    2b2e:	83 e0 01             	and    $0x1,%eax
    2b31:	49 01 d0             	add    %rdx,%r8
    2b34:	49 f7 e7             	mul    %r15
    2b37:	4c 89 c7             	mov    %r8,%rdi
    2b3a:	4c 89 d2             	mov    %r10,%rdx
    2b3d:	4c 01 e0             	add    %r12,%rax
    2b40:	48 d1 ef             	shr    $1,%rdi
    2b43:	83 c5 01             	add    $0x1,%ebp
    2b46:	48 83 c3 01          	add    $0x1,%rbx
    2b4a:	83 c0 30             	add    $0x30,%eax
    2b4d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    2b52:	88 43 ff             	mov    %al,-0x1(%rbx)
    2b55:	4c 89 d8             	mov    %r11,%rax
    2b58:	49 89 fb             	mov    %rdi,%r11
    2b5b:	bf 09 00 00 00       	mov    $0x9,%edi
    2b60:	48 39 d7             	cmp    %rdx,%rdi
    2b63:	4c 89 f7             	mov    %r14,%rdi
    2b66:	49 89 f2             	mov    %rsi,%r10
    2b69:	48 19 c7             	sbb    %rax,%rdi
    2b6c:	0f 82 6e ff ff ff    	jb     2ae0 <fwp_fmt_u128+0xe0>
    2b72:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    2b77:	4c 89 cf             	mov    %r9,%rdi
    2b7a:	e9 b4 fe ff ff       	jmp    2a33 <fwp_fmt_u128+0x33>
    2b7f:	e8 bc f8 ff ff       	call   2440 <__stack_chk_fail@plt>
    2b84:	90                   	nop
    2b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2b8c:	00 00 00 00 

0000000000002b90 <fwp_range_release>:
    2b90:	f3 0f 1e fa          	endbr64
    2b94:	53                   	push   %rbx
    2b95:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2b99:	48 89 fb             	mov    %rdi,%rbx
    2b9c:	48 85 c0             	test   %rax,%rax
    2b9f:	74 06                	je     2ba7 <fwp_range_release+0x17>
    2ba1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    2ba5:	ff d0                	call   *%rax
    2ba7:	48 8b 3b             	mov    (%rbx),%rdi
    2baa:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2bae:	5b                   	pop    %rbx
    2baf:	ff e0                	jmp    *%rax
    2bb1:	0f 1f 40 00          	nopl   0x0(%rax)
    2bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bbc:	00 00 00 00 

0000000000002bc0 <fwp_owned_entry32>:
    2bc0:	f3 0f 1e fa          	endbr64
    2bc4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bc9:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    2bcd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2bd2:	c3                   	ret
    2bd3:	66 90                	xchg   %ax,%ax
    2bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bdc:	00 00 00 00 

0000000000002be0 <fwp_args32>:
    2be0:	f3 0f 1e fa          	endbr64
    2be4:	c3                   	ret
    2be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2bec:	00 00 00 00 

0000000000002bf0 <fwp_owned_entry45>:
    2bf0:	f3 0f 1e fa          	endbr64
    2bf4:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    2bf9:	f2 0f 58 07          	addsd  (%rdi),%xmm0
    2bfd:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c02:	c3                   	ret
    2c03:	66 90                	xchg   %ax,%ax
    2c05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c0c:	00 00 00 00 

0000000000002c10 <fwp_owned_entry69>:
    2c10:	f3 0f 1e fa          	endbr64
    2c14:	f2 0f 10 05 d4 99 00 	movsd  0x99d4(%rip),%xmm0        # c5f0 <msg.3+0x20>
    2c1b:	00 
    2c1c:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    2c20:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2c25:	c3                   	ret
    2c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2c2d:	00 00 00 

0000000000002c30 <fwp_flush>:
    2c30:	48 8b 3d 21 e7 01 00 	mov    0x1e721(%rip),%rdi        # 21358 <fwp_prog_out>
    2c37:	48 85 ff             	test   %rdi,%rdi
    2c3a:	74 1c                	je     2c58 <fwp_flush+0x28>
    2c3c:	48 83 ec 08          	sub    $0x8,%rsp
    2c40:	e8 4b f9 ff ff       	call   2590 <fflush@plt>
    2c45:	48 8b 3d d4 c3 00 00 	mov    0xc3d4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    2c4c:	48 83 c4 08          	add    $0x8,%rsp
    2c50:	e9 3b f9 ff ff       	jmp    2590 <fflush@plt>
    2c55:	0f 1f 00             	nopl   (%rax)
    2c58:	48 8b 3d c1 c3 00 00 	mov    0xc3c1(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    2c5f:	e9 2c f9 ff ff       	jmp    2590 <fflush@plt>
    2c64:	90                   	nop
    2c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2c6c:	00 00 00 00 

0000000000002c70 <fwp_segv>:
    2c70:	f3 0f 1e fa          	endbr64
    2c74:	48 83 ec 28          	sub    $0x28,%rsp
    2c78:	48 8b 05 61 ca 01 00 	mov    0x1ca61(%rip),%rax        # 1f6e0 <fwp_cur>
    2c7f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2c83:	41 89 f8             	mov    %edi,%r8d
    2c86:	48 85 c0             	test   %rax,%rax
    2c89:	74 6d                	je     2cf8 <fwp_segv+0x88>
    2c8b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2c8f:	48 85 d2             	test   %rdx,%rdx
    2c92:	74 64                	je     2cf8 <fwp_segv+0x88>
    2c94:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    2c98:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2c9d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2ca2:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    2ca7:	e8 54 f9 ff ff       	call   2600 <sysconf@plt>
    2cac:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cb1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2cb6:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    2cbb:	48 01 d0             	add    %rdx,%rax
    2cbe:	48 39 c1             	cmp    %rax,%rcx
    2cc1:	b8 00 00 00 00       	mov    $0x0,%eax
    2cc6:	40 0f 92 c6          	setb   %sil
    2cca:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    2cd1:	48 0f 42 d0          	cmovb  %rax,%rdx
    2cd5:	31 c0                	xor    %eax,%eax
    2cd7:	48 39 d1             	cmp    %rdx,%rcx
    2cda:	0f 93 c0             	setae  %al
    2cdd:	21 f0                	and    %esi,%eax
    2cdf:	85 c0                	test   %eax,%eax
    2ce1:	75 4a                	jne    2d2d <fwp_segv+0xbd>
    2ce3:	31 f6                	xor    %esi,%esi
    2ce5:	44 89 c7             	mov    %r8d,%edi
    2ce8:	48 83 c4 28          	add    $0x28,%rsp
    2cec:	e9 2f f8 ff ff       	jmp    2520 <signal@plt>
    2cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2cf8:	48 8b 05 99 c3 01 00 	mov    0x1c399(%rip),%rax        # 1f098 <fwp_main_stack_top>
    2cff:	48 85 c0             	test   %rax,%rax
    2d02:	74 df                	je     2ce3 <fwp_segv+0x73>
    2d04:	48 2b 05 85 c3 01 00 	sub    0x1c385(%rip),%rax        # 1f090 <fwp_main_stack_size>
    2d0b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    2d12:	48 39 d1             	cmp    %rdx,%rcx
    2d15:	0f 93 c2             	setae  %dl
    2d18:	48 05 00 00 10 00    	add    $0x100000,%rax
    2d1e:	48 39 c1             	cmp    %rax,%rcx
    2d21:	0f 92 c0             	setb   %al
    2d24:	0f b6 c0             	movzbl %al,%eax
    2d27:	21 d0                	and    %edx,%eax
    2d29:	85 c0                	test   %eax,%eax
    2d2b:	74 b6                	je     2ce3 <fwp_segv+0x73>
    2d2d:	e8 fe fe ff ff       	call   2c30 <fwp_flush>
    2d32:	bf 02 00 00 00       	mov    $0x2,%edi
    2d37:	ba 1a 00 00 00       	mov    $0x1a,%edx
    2d3c:	48 8d 35 8d 98 00 00 	lea    0x988d(%rip),%rsi        # c5d0 <msg.3>
    2d43:	e8 c8 f6 ff ff       	call   2410 <write@plt>
    2d48:	bf 65 00 00 00       	mov    $0x65,%edi
    2d4d:	e8 6e f6 ff ff       	call   23c0 <_exit@plt>
    2d52:	0f 1f 00             	nopl   (%rax)
    2d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d5c:	00 00 00 00 

0000000000002d60 <fwp_heap_oom>:
    2d60:	50                   	push   %rax
    2d61:	58                   	pop    %rax
    2d62:	ba 13 00 00 00       	mov    $0x13,%edx
    2d67:	be 01 00 00 00       	mov    $0x1,%esi
    2d6c:	48 8d 3d 95 92 00 00 	lea    0x9295(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    2d73:	48 83 ec 08          	sub    $0x8,%rsp
    2d77:	48 8b 0d c2 c2 00 00 	mov    0xc2c2(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    2d7e:	e8 bd f8 ff ff       	call   2640 <fwrite@plt>
    2d83:	31 ff                	xor    %edi,%edi
    2d85:	e8 06 f8 ff ff       	call   2590 <fflush@plt>
    2d8a:	bf 66 00 00 00       	mov    $0x66,%edi
    2d8f:	e8 cc f8 ff ff       	call   2660 <_Exit@plt>
    2d94:	90                   	nop
    2d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2d9c:	00 00 00 00 

0000000000002da0 <fwp_heap_chunks>:
    2da0:	41 54                	push   %r12
    2da2:	55                   	push   %rbp
    2da3:	53                   	push   %rbx
    2da4:	48 83 ff 01          	cmp    $0x1,%rdi
    2da8:	0f 84 62 01 00 00    	je     2f10 <fwp_heap_chunks+0x170>
    2dae:	48 8b 05 3b dd 01 00 	mov    0x1dd3b(%rip),%rax        # 20af0 <fwp_heap+0x13f0>
    2db5:	4c 8d 05 34 dd 01 00 	lea    0x1dd34(%rip),%r8        # 20af0 <fwp_heap+0x13f0>
    2dbc:	48 8b 1d 15 dd 01 00 	mov    0x1dd15(%rip),%rbx        # 20ad8 <fwp_heap+0x13d8>
    2dc3:	48 39 d8             	cmp    %rbx,%rax
    2dc6:	0f 83 57 01 00 00    	jae    2f23 <fwp_heap_chunks+0x183>
    2dcc:	48 8b 0d 25 dd 01 00 	mov    0x1dd25(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    2dd3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    2dd7:	31 f6                	xor    %esi,%esi
    2dd9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    2ddd:	eb 1e                	jmp    2dfd <fwp_heap_chunks+0x5d>
    2ddf:	90                   	nop
    2de0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    2de4:	48 39 cf             	cmp    %rcx,%rdi
    2de7:	0f 84 03 01 00 00    	je     2ef0 <fwp_heap_chunks+0x150>
    2ded:	48 83 c0 01          	add    $0x1,%rax
    2df1:	48 89 ce             	mov    %rcx,%rsi
    2df4:	48 83 c2 28          	add    $0x28,%rdx
    2df8:	48 39 c3             	cmp    %rax,%rbx
    2dfb:	74 14                	je     2e11 <fwp_heap_chunks+0x71>
    2dfd:	80 3a 00             	cmpb   $0x0,(%rdx)
    2e00:	74 de                	je     2de0 <fwp_heap_chunks+0x40>
    2e02:	48 83 c0 01          	add    $0x1,%rax
    2e06:	31 f6                	xor    %esi,%esi
    2e08:	48 83 c2 28          	add    $0x28,%rdx
    2e0c:	48 39 c3             	cmp    %rax,%rbx
    2e0f:	75 ec                	jne    2dfd <fwp_heap_chunks+0x5d>
    2e11:	48 29 f3             	sub    %rsi,%rbx
    2e14:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    2e18:	48 8b 3d c1 dc 01 00 	mov    0x1dcc1(%rip),%rdi        # 20ae0 <fwp_heap+0x13e0>
    2e1f:	48 29 35 0a dd 01 00 	sub    %rsi,0x1dd0a(%rip)        # 20b30 <fwp_heap+0x1430>
    2e26:	48 39 ef             	cmp    %rbp,%rdi
    2e29:	0f 83 96 00 00 00    	jae    2ec5 <fwp_heap_chunks+0x125>
    2e2f:	48 8b 05 9a dc 01 00 	mov    0x1dc9a(%rip),%rax        # 20ad0 <fwp_heap+0x13d0>
    2e36:	48 39 e8             	cmp    %rbp,%rax
    2e39:	0f 82 eb 00 00 00    	jb     2f2a <fwp_heap_chunks+0x18a>
    2e3f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    2e43:	ba 03 00 00 00       	mov    $0x3,%edx
    2e48:	49 39 c4             	cmp    %rax,%r12
    2e4b:	4c 0f 47 e0          	cmova  %rax,%r12
    2e4f:	4c 89 e6             	mov    %r12,%rsi
    2e52:	48 29 fe             	sub    %rdi,%rsi
    2e55:	48 c1 e7 10          	shl    $0x10,%rdi
    2e59:	48 03 3d 50 dc 01 00 	add    0x1dc50(%rip),%rdi        # 20ab0 <fwp_heap+0x13b0>
    2e60:	48 c1 e6 10          	shl    $0x10,%rsi
    2e64:	e8 77 f7 ff ff       	call   25e0 <mprotect@plt>
    2e69:	85 c0                	test   %eax,%eax
    2e6b:	0f 85 b9 00 00 00    	jne    2f2a <fwp_heap_chunks+0x18a>
    2e71:	bf 1e 00 00 00       	mov    $0x1e,%edi
    2e76:	e8 85 f7 ff ff       	call   2600 <sysconf@plt>
    2e7b:	48 8b 35 5e dc 01 00 	mov    0x1dc5e(%rip),%rsi        # 20ae0 <fwp_heap+0x13e0>
    2e82:	48 89 c1             	mov    %rax,%rcx
    2e85:	48 8b 05 6c dc 01 00 	mov    0x1dc6c(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    2e8c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    2e90:	48 89 ca             	mov    %rcx,%rdx
    2e93:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    2e97:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    2e9b:	48 f7 da             	neg    %rdx
    2e9e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    2ea3:	48 21 d7             	and    %rdx,%rdi
    2ea6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    2eaa:	48 21 d6             	and    %rdx,%rsi
    2ead:	ba 03 00 00 00       	mov    $0x3,%edx
    2eb2:	48 29 fe             	sub    %rdi,%rsi
    2eb5:	e8 26 f7 ff ff       	call   25e0 <mprotect@plt>
    2eba:	85 c0                	test   %eax,%eax
    2ebc:	75 6c                	jne    2f2a <fwp_heap_chunks+0x18a>
    2ebe:	4c 89 25 1b dc 01 00 	mov    %r12,0x1dc1b(%rip)        # 20ae0 <fwp_heap+0x13e0>
    2ec5:	48 89 ef             	mov    %rbp,%rdi
    2ec8:	48 89 2d 09 dc 01 00 	mov    %rbp,0x1dc09(%rip)        # 20ad8 <fwp_heap+0x13d8>
    2ecf:	48 c1 e7 10          	shl    $0x10,%rdi
    2ed3:	48 39 3d ee db 01 00 	cmp    %rdi,0x1dbee(%rip)        # 20ac8 <fwp_heap+0x13c8>
    2eda:	73 07                	jae    2ee3 <fwp_heap_chunks+0x143>
    2edc:	48 89 3d e5 db 01 00 	mov    %rdi,0x1dbe5(%rip)        # 20ac8 <fwp_heap+0x13c8>
    2ee3:	48 89 d8             	mov    %rbx,%rax
    2ee6:	5b                   	pop    %rbx
    2ee7:	5d                   	pop    %rbp
    2ee8:	41 5c                	pop    %r12
    2eea:	c3                   	ret
    2eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ef0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    2ef4:	48 29 f0             	sub    %rsi,%rax
    2ef7:	48 89 c3             	mov    %rax,%rbx
    2efa:	49 89 10             	mov    %rdx,(%r8)
    2efd:	48 89 d8             	mov    %rbx,%rax
    2f00:	48 29 3d 29 dc 01 00 	sub    %rdi,0x1dc29(%rip)        # 20b30 <fwp_heap+0x1430>
    2f07:	5b                   	pop    %rbx
    2f08:	5d                   	pop    %rbp
    2f09:	41 5c                	pop    %r12
    2f0b:	c3                   	ret
    2f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    2f10:	48 8b 05 d1 db 01 00 	mov    0x1dbd1(%rip),%rax        # 20ae8 <fwp_heap+0x13e8>
    2f17:	4c 8d 05 ca db 01 00 	lea    0x1dbca(%rip),%r8        # 20ae8 <fwp_heap+0x13e8>
    2f1e:	e9 99 fe ff ff       	jmp    2dbc <fwp_heap_chunks+0x1c>
    2f23:	31 f6                	xor    %esi,%esi
    2f25:	e9 ea fe ff ff       	jmp    2e14 <fwp_heap_chunks+0x74>
    2f2a:	e8 31 fe ff ff       	call   2d60 <fwp_heap_oom>
    2f2f:	90                   	nop

0000000000002f30 <ad_raw_fail>:
    2f30:	50                   	push   %rax
    2f31:	58                   	pop    %rax
    2f32:	48 8d 15 bf 92 00 00 	lea    0x92bf(%rip),%rdx        # c1f8 <_IO_stdin_used+0x1f8>
    2f39:	be 02 00 00 00       	mov    $0x2,%esi
    2f3e:	31 c0                	xor    %eax,%eax
    2f40:	48 83 ec 08          	sub    $0x8,%rsp
    2f44:	48 89 f9             	mov    %rdi,%rcx
    2f47:	48 8b 3d f2 c0 00 00 	mov    0xc0f2(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    2f4e:	e8 fd f6 ff ff       	call   2650 <__fprintf_chk@plt>
    2f53:	bf e8 00 00 00       	mov    $0xe8,%edi
    2f58:	e8 d3 f6 ff ff       	call   2630 <exit@plt>
    2f5d:	0f 1f 00             	nopl   (%rax)

0000000000002f60 <buf_grow>:
    2f60:	48 83 ec 18          	sub    $0x18,%rsp
    2f64:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2f68:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    2f6c:	74 7e                	je     2fec <buf_grow+0x8c>
    2f6e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    2f75:	48 29 c2             	sub    %rax,%rdx
    2f78:	48 39 f2             	cmp    %rsi,%rdx
    2f7b:	72 6f                	jb     2fec <buf_grow+0x8c>
    2f7d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    2f82:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2f86:	48 89 f9             	mov    %rdi,%rcx
    2f89:	48 39 d0             	cmp    %rdx,%rax
    2f8c:	73 48                	jae    2fd6 <buf_grow+0x76>
    2f8e:	48 85 c0             	test   %rax,%rax
    2f91:	75 15                	jne    2fa8 <buf_grow+0x48>
    2f93:	48 83 fa 40          	cmp    $0x40,%rdx
    2f97:	76 4c                	jbe    2fe5 <buf_grow+0x85>
    2f99:	b8 40 00 00 00       	mov    $0x40,%eax
    2f9e:	eb 08                	jmp    2fa8 <buf_grow+0x48>
    2fa0:	48 01 c0             	add    %rax,%rax
    2fa3:	48 39 d0             	cmp    %rdx,%rax
    2fa6:	73 38                	jae    2fe0 <buf_grow+0x80>
    2fa8:	48 85 c0             	test   %rax,%rax
    2fab:	79 f3                	jns    2fa0 <buf_grow+0x40>
    2fad:	48 8b 39             	mov    (%rcx),%rdi
    2fb0:	48 89 d6             	mov    %rdx,%rsi
    2fb3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    2fb8:	48 89 14 24          	mov    %rdx,(%rsp)
    2fbc:	e8 df f5 ff ff       	call   25a0 <realloc@plt>
    2fc1:	48 8b 14 24          	mov    (%rsp),%rdx
    2fc5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2fca:	48 85 c0             	test   %rax,%rax
    2fcd:	74 1d                	je     2fec <buf_grow+0x8c>
    2fcf:	48 89 01             	mov    %rax,(%rcx)
    2fd2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    2fd6:	48 83 c4 18          	add    $0x18,%rsp
    2fda:	c3                   	ret
    2fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fe0:	48 89 c2             	mov    %rax,%rdx
    2fe3:	eb c8                	jmp    2fad <buf_grow+0x4d>
    2fe5:	ba 40 00 00 00       	mov    $0x40,%edx
    2fea:	eb c1                	jmp    2fad <buf_grow+0x4d>
    2fec:	48 8b 0d 4d c0 00 00 	mov    0xc04d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    2ff3:	ba 13 00 00 00       	mov    $0x13,%edx
    2ff8:	be 01 00 00 00       	mov    $0x1,%esi
    2ffd:	48 8d 3d 04 90 00 00 	lea    0x9004(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3004:	e8 37 f6 ff ff       	call   2640 <fwrite@plt>
    3009:	31 ff                	xor    %edi,%edi
    300b:	e8 80 f5 ff ff       	call   2590 <fflush@plt>
    3010:	bf 66 00 00 00       	mov    $0x66,%edi
    3015:	e8 46 f6 ff ff       	call   2660 <_Exit@plt>
    301a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003020 <buf_put>:
    3020:	41 54                	push   %r12
    3022:	49 89 f4             	mov    %rsi,%r12
    3025:	48 89 d6             	mov    %rdx,%rsi
    3028:	55                   	push   %rbp
    3029:	48 89 fd             	mov    %rdi,%rbp
    302c:	53                   	push   %rbx
    302d:	48 89 d3             	mov    %rdx,%rbx
    3030:	e8 2b ff ff ff       	call   2f60 <buf_grow>
    3035:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    3039:	48 89 da             	mov    %rbx,%rdx
    303c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    3040:	4c 89 e6             	mov    %r12,%rsi
    3043:	e8 28 f5 ff ff       	call   2570 <memcpy@plt>
    3048:	48 8b 45 00          	mov    0x0(%rbp),%rax
    304c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    3050:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    3054:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    3058:	5b                   	pop    %rbx
    3059:	5d                   	pop    %rbp
    305a:	41 5c                	pop    %r12
    305c:	c3                   	ret
    305d:	0f 1f 00             	nopl   (%rax)

0000000000003060 <fwp_cancel_tree.part.0>:
    3060:	48 3b 3d 79 c6 01 00 	cmp    0x1c679(%rip),%rdi        # 1f6e0 <fwp_cur>
    3067:	53                   	push   %rbx
    3068:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    306c:	74 35                	je     30a3 <fwp_cancel_tree.part.0+0x43>
    306e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    3072:	75 2f                	jne    30a3 <fwp_cancel_tree.part.0+0x43>
    3074:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    3078:	75 29                	jne    30a3 <fwp_cancel_tree.part.0+0x43>
    307a:	48 8b 05 3f c6 01 00 	mov    0x1c63f(%rip),%rax        # 1f6c0 <fwp_ready_tail>
    3081:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    3085:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    308c:	00 00 00 00 
    3090:	48 85 c0             	test   %rax,%rax
    3093:	74 33                	je     30c8 <fwp_cancel_tree.part.0+0x68>
    3095:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    309c:	48 89 3d 1d c6 01 00 	mov    %rdi,0x1c61d(%rip)        # 1f6c0 <fwp_ready_tail>
    30a3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    30a7:	48 85 db             	test   %rbx,%rbx
    30aa:	74 17                	je     30c3 <fwp_cancel_tree.part.0+0x63>
    30ac:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    30b0:	75 08                	jne    30ba <fwp_cancel_tree.part.0+0x5a>
    30b2:	48 89 df             	mov    %rbx,%rdi
    30b5:	e8 a6 ff ff ff       	call   3060 <fwp_cancel_tree.part.0>
    30ba:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    30be:	48 85 db             	test   %rbx,%rbx
    30c1:	75 e9                	jne    30ac <fwp_cancel_tree.part.0+0x4c>
    30c3:	5b                   	pop    %rbx
    30c4:	c3                   	ret
    30c5:	0f 1f 00             	nopl   (%rax)
    30c8:	48 89 3d f9 c5 01 00 	mov    %rdi,0x1c5f9(%rip)        # 1f6c8 <fwp_ready_head>
    30cf:	eb cb                	jmp    309c <fwp_cancel_tree.part.0+0x3c>
    30d1:	0f 1f 40 00          	nopl   0x0(%rax)
    30d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    30dc:	00 00 00 00 

00000000000030e0 <fwp_finish_float>:
    30e0:	53                   	push   %rbx
    30e1:	be 2e 00 00 00       	mov    $0x2e,%esi
    30e6:	48 89 fb             	mov    %rdi,%rbx
    30e9:	e8 72 f3 ff ff       	call   2460 <strchr@plt>
    30ee:	48 85 c0             	test   %rax,%rax
    30f1:	74 05                	je     30f8 <fwp_finish_float+0x18>
    30f3:	5b                   	pop    %rbx
    30f4:	c3                   	ret
    30f5:	0f 1f 00             	nopl   (%rax)
    30f8:	be 65 00 00 00       	mov    $0x65,%esi
    30fd:	48 89 df             	mov    %rbx,%rdi
    3100:	e8 5b f3 ff ff       	call   2460 <strchr@plt>
    3105:	48 85 c0             	test   %rax,%rax
    3108:	75 e9                	jne    30f3 <fwp_finish_float+0x13>
    310a:	48 8d 35 08 90 00 00 	lea    0x9008(%rip),%rsi        # c119 <_IO_stdin_used+0x119>
    3111:	48 89 df             	mov    %rbx,%rdi
    3114:	e8 77 f5 ff ff       	call   2690 <strstr@plt>
    3119:	48 85 c0             	test   %rax,%rax
    311c:	75 d5                	jne    30f3 <fwp_finish_float+0x13>
    311e:	48 8d 35 f7 8e 00 00 	lea    0x8ef7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    3125:	48 89 df             	mov    %rbx,%rdi
    3128:	e8 63 f5 ff ff       	call   2690 <strstr@plt>
    312d:	48 85 c0             	test   %rax,%rax
    3130:	75 c1                	jne    30f3 <fwp_finish_float+0x13>
    3132:	48 89 df             	mov    %rbx,%rdi
    3135:	e8 f6 f2 ff ff       	call   2430 <strlen@plt>
    313a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    313f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    3143:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    3148:	5b                   	pop    %rbx
    3149:	c3                   	ret
    314a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003150 <ad_raw_report>:
    3150:	f3 0f 1e fa          	endbr64
    3154:	55                   	push   %rbp
    3155:	31 c9                	xor    %ecx,%ecx
    3157:	45 31 c9             	xor    %r9d,%r9d
    315a:	48 8d 15 bf 90 00 00 	lea    0x90bf(%rip),%rdx        # c220 <_IO_stdin_used+0x220>
    3161:	53                   	push   %rbx
    3162:	be 02 00 00 00       	mov    $0x2,%esi
    3167:	31 db                	xor    %ebx,%ebx
    3169:	48 83 ec 38          	sub    $0x38,%rsp
    316d:	4c 8b 05 14 bf 01 00 	mov    0x1bf14(%rip),%r8        # 1f088 <ad_raw_before_shutdown>
    3174:	48 8b 3d c5 be 00 00 	mov    0xbec5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    317b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3182:	00 00 
    3184:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    3189:	31 c0                	xor    %eax,%eax
    318b:	48 89 e5             	mov    %rsp,%rbp
    318e:	e8 bd f4 ff ff       	call   2650 <__fprintf_chk@plt>
    3193:	48 8d 05 91 8e 00 00 	lea    0x8e91(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    319a:	f3 0f 7e 05 6e ba 00 	movq   0xba6e(%rip),%xmm0        # ec10 <d0+0x70>
    31a1:	00 
    31a2:	48 8d 0d c5 8e 00 00 	lea    0x8ec5(%rip),%rcx        # c06e <_IO_stdin_used+0x6e>
    31a9:	66 48 0f 6e c8       	movq   %rax,%xmm1
    31ae:	48 8d 05 89 8e 00 00 	lea    0x8e89(%rip),%rax        # c03e <_IO_stdin_used+0x3e>
    31b5:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    31b9:	66 48 0f 6e d0       	movq   %rax,%xmm2
    31be:	66 49 0f 7e c0       	movq   %xmm0,%r8
    31c3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    31c7:	f3 0f 7e 05 49 ba 00 	movq   0xba49(%rip),%xmm0        # ec18 <d0+0x78>
    31ce:	00 
    31cf:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    31d3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    31d8:	6a 00                	push   $0x0
    31da:	48 8b 3d 5f be 00 00 	mov    0xbe5f(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    31e1:	45 31 c9             	xor    %r9d,%r9d
    31e4:	31 c0                	xor    %eax,%eax
    31e6:	6a 00                	push   $0x0
    31e8:	48 8d 15 91 90 00 00 	lea    0x9091(%rip),%rdx        # c280 <_IO_stdin_used+0x280>
    31ef:	be 02 00 00 00       	mov    $0x2,%esi
    31f4:	83 c3 01             	add    $0x1,%ebx
    31f7:	e8 54 f4 ff ff       	call   2650 <__fprintf_chk@plt>
    31fc:	58                   	pop    %rax
    31fd:	5a                   	pop    %rdx
    31fe:	83 fb 04             	cmp    $0x4,%ebx
    3201:	74 15                	je     3218 <ad_raw_report+0xc8>
    3203:	48 83 c5 08          	add    $0x8,%rbp
    3207:	48 8d 0d 12 8e 00 00 	lea    0x8e12(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    320e:	4c 8b 45 00          	mov    0x0(%rbp),%r8
    3212:	eb c4                	jmp    31d8 <ad_raw_report+0x88>
    3214:	0f 1f 40 00          	nopl   0x0(%rax)
    3218:	48 8b 0d 21 be 00 00 	mov    0xbe21(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    321f:	ba 13 00 00 00       	mov    $0x13,%edx
    3224:	be 01 00 00 00       	mov    $0x1,%esi
    3229:	48 8d 3d 17 8e 00 00 	lea    0x8e17(%rip),%rdi        # c047 <_IO_stdin_used+0x47>
    3230:	e8 0b f4 ff ff       	call   2640 <fwrite@plt>
    3235:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    323a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3241:	00 00 
    3243:	75 23                	jne    3268 <ad_raw_report+0x118>
    3245:	48 8b 0d f4 bd 00 00 	mov    0xbdf4(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    324c:	48 83 c4 38          	add    $0x38,%rsp
    3250:	ba 04 00 00 00       	mov    $0x4,%edx
    3255:	be 01 00 00 00       	mov    $0x1,%esi
    325a:	5b                   	pop    %rbx
    325b:	48 8d 3d f9 8d 00 00 	lea    0x8df9(%rip),%rdi        # c05b <_IO_stdin_used+0x5b>
    3262:	5d                   	pop    %rbp
    3263:	e9 d8 f3 ff ff       	jmp    2640 <fwrite@plt>
    3268:	e8 d3 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    326d:	0f 1f 00             	nopl   (%rax)

0000000000003270 <fwp_trap>:
    3270:	53                   	push   %rbx
    3271:	48 89 fb             	mov    %rdi,%rbx
    3274:	e8 b7 f9 ff ff       	call   2c30 <fwp_flush>
    3279:	48 89 d9             	mov    %rbx,%rcx
    327c:	be 02 00 00 00       	mov    $0x2,%esi
    3281:	31 c0                	xor    %eax,%eax
    3283:	48 8b 3d b6 bd 00 00 	mov    0xbdb6(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    328a:	48 8d 15 cf 8d 00 00 	lea    0x8dcf(%rip),%rdx        # c060 <_IO_stdin_used+0x60>
    3291:	e8 ba f3 ff ff       	call   2650 <__fprintf_chk@plt>
    3296:	bf 65 00 00 00       	mov    $0x65,%edi
    329b:	e8 90 f3 ff ff       	call   2630 <exit@plt>

00000000000032a0 <fwp_now_ns>:
    32a0:	53                   	push   %rbx
    32a1:	bf 01 00 00 00       	mov    $0x1,%edi
    32a6:	48 83 ec 20          	sub    $0x20,%rsp
    32aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    32b1:	00 00 
    32b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    32b8:	31 db                	xor    %ebx,%ebx
    32ba:	48 89 e6             	mov    %rsp,%rsi
    32bd:	e8 3e f1 ff ff       	call   2400 <clock_gettime@plt>
    32c2:	85 c0                	test   %eax,%eax
    32c4:	75 52                	jne    3318 <fwp_now_ns+0x78>
    32c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    32cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    32d0:	48 f7 2c 24          	imulq  (%rsp)
    32d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    32db:	48 89 f7             	mov    %rsi,%rdi
    32de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    32e2:	48 01 f0             	add    %rsi,%rax
    32e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    32ec:	00 00 80 
    32ef:	48 11 fa             	adc    %rdi,%rdx
    32f2:	31 ff                	xor    %edi,%edi
    32f4:	48 01 c6             	add    %rax,%rsi
    32f7:	48 11 d7             	adc    %rdx,%rdi
    32fa:	48 39 f1             	cmp    %rsi,%rcx
    32fd:	48 19 fb             	sbb    %rdi,%rbx
    3300:	72 27                	jb     3329 <fwp_now_ns+0x89>
    3302:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3307:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    330e:	00 00 
    3310:	75 12                	jne    3324 <fwp_now_ns+0x84>
    3312:	48 83 c4 20          	add    $0x20,%rsp
    3316:	5b                   	pop    %rbx
    3317:	c3                   	ret
    3318:	48 8d 3d 50 8d 00 00 	lea    0x8d50(%rip),%rdi        # c06f <_IO_stdin_used+0x6f>
    331f:	e8 4c ff ff ff       	call   3270 <fwp_trap>
    3324:	e8 17 f1 ff ff       	call   2440 <__stack_chk_fail@plt>
    3329:	48 8d 3d 90 8f 00 00 	lea    0x8f90(%rip),%rdi        # c2c0 <_IO_stdin_used+0x2c0>
    3330:	e8 3b ff ff ff       	call   3270 <fwp_trap>
    3335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    333c:	00 00 00 00 

0000000000003340 <fwp_args74>:
    3340:	f3 0f 1e fa          	endbr64
    3344:	c3                   	ret
    3345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    334c:	00 00 00 00 

0000000000003350 <fwp_format_g.constprop.0>:
    3350:	41 57                	push   %r15
    3352:	b9 40 00 00 00       	mov    $0x40,%ecx
    3357:	ba 02 00 00 00       	mov    $0x2,%edx
    335c:	4c 8d 05 28 8d 00 00 	lea    0x8d28(%rip),%r8        # c08b <_IO_stdin_used+0x8b>
    3363:	41 56                	push   %r14
    3365:	b8 01 00 00 00       	mov    $0x1,%eax
    336a:	41 55                	push   %r13
    336c:	41 54                	push   %r12
    336e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    3372:	55                   	push   %rbp
    3373:	45 89 e1             	mov    %r12d,%r9d
    3376:	53                   	push   %rbx
    3377:	48 89 fb             	mov    %rdi,%rbx
    337a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    3381:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    3388:	00 00 
    338a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    3391:	00 
    3392:	41 89 f7             	mov    %esi,%r15d
    3395:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    339a:	be 40 00 00 00       	mov    $0x40,%esi
    339f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    33a4:	4c 89 f7             	mov    %r14,%rdi
    33a7:	e8 e4 ef ff ff       	call   2390 <__snprintf_chk@plt>
    33ac:	be 65 00 00 00       	mov    $0x65,%esi
    33b1:	4c 89 f7             	mov    %r14,%rdi
    33b4:	e8 a7 f0 ff ff       	call   2460 <strchr@plt>
    33b9:	31 f6                	xor    %esi,%esi
    33bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    33c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    33c4:	48 89 c5             	mov    %rax,%rbp
    33c7:	e8 94 f1 ff ff       	call   2560 <strtol@plt>
    33cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    33d1:	49 89 c0             	mov    %rax,%r8
    33d4:	83 c0 05             	add    $0x5,%eax
    33d7:	83 f8 15             	cmp    $0x15,%eax
    33da:	0f 87 e0 01 00 00    	ja     35c0 <fwp_format_g.constprop.0+0x270>
    33e0:	45 89 e5             	mov    %r12d,%r13d
    33e3:	45 29 c5             	sub    %r8d,%r13d
    33e6:	45 85 ed             	test   %r13d,%r13d
    33e9:	0f 8e 21 01 00 00    	jle    3510 <fwp_format_g.constprop.0+0x1c0>
    33ef:	41 83 ff 01          	cmp    $0x1,%r15d
    33f3:	0f 84 17 01 00 00    	je     3510 <fwp_format_g.constprop.0+0x1c0>
    33f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    33fe:	31 d2                	xor    %edx,%edx
    3400:	4d 63 df             	movslq %r15d,%r11
    3403:	3c 2d                	cmp    $0x2d,%al
    3405:	0f 94 c2             	sete   %dl
    3408:	4c 29 dd             	sub    %r11,%rbp
    340b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    340f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    3413:	4d 89 f1             	mov    %r14,%r9
    3416:	4d 29 d1             	sub    %r10,%r9
    3419:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    341d:	3c 2d                	cmp    $0x2d,%al
    341f:	0f 84 fb 03 00 00    	je     3820 <fwp_format_g.constprop.0+0x4d0>
    3425:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    342a:	b9 48 00 00 00       	mov    $0x48,%ecx
    342f:	48 89 e8             	mov    %rbp,%rax
    3432:	48 8d 78 01          	lea    0x1(%rax),%rdi
    3436:	49 8d 72 01          	lea    0x1(%r10),%rsi
    343a:	49 83 c1 47          	add    $0x47,%r9
    343e:	45 85 c0             	test   %r8d,%r8d
    3441:	0f 88 f1 02 00 00    	js     3738 <fwp_format_g.constprop.0+0x3e8>
    3447:	45 0f b6 12          	movzbl (%r10),%r10d
    344b:	4d 63 e0             	movslq %r8d,%r12
    344e:	44 88 10             	mov    %r10b,(%rax)
    3451:	41 83 f8 07          	cmp    $0x7,%r8d
    3455:	0f 87 2d 02 00 00    	ja     3688 <fwp_format_g.constprop.0+0x338>
    345b:	41 f6 c4 04          	test   $0x4,%r12b
    345f:	0f 85 f2 03 00 00    	jne    3857 <fwp_format_g.constprop.0+0x507>
    3465:	45 85 e4             	test   %r12d,%r12d
    3468:	74 12                	je     347c <fwp_format_g.constprop.0+0x12c>
    346a:	45 0f b6 06          	movzbl (%r14),%r8d
    346e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    3472:	41 f6 c4 02          	test   $0x2,%r12b
    3476:	0f 85 03 04 00 00    	jne    387f <fwp_format_g.constprop.0+0x52f>
    347c:	4c 29 e1             	sub    %r12,%rcx
    347f:	4c 01 e7             	add    %r12,%rdi
    3482:	4c 89 fa             	mov    %r15,%rdx
    3485:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    348a:	48 83 e9 01          	sub    $0x1,%rcx
    348e:	4d 63 ed             	movslq %r13d,%r13
    3491:	48 89 0c 24          	mov    %rcx,(%rsp)
    3495:	e8 a6 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    349a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    349f:	48 8b 0c 24          	mov    (%rsp),%rcx
    34a3:	ba 48 00 00 00       	mov    $0x48,%edx
    34a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    34ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    34b0:	4c 89 c8             	mov    %r9,%rax
    34b3:	48 29 c8             	sub    %rcx,%rax
    34b6:	48 39 d0             	cmp    %rdx,%rax
    34b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    34bd:	4c 29 c9             	sub    %r9,%rcx
    34c0:	4c 89 ea             	mov    %r13,%rdx
    34c3:	48 01 c1             	add    %rax,%rcx
    34c6:	e8 75 f0 ff ff       	call   2540 <__memcpy_chk@plt>
    34cb:	4c 01 e8             	add    %r13,%rax
    34ce:	48 29 e8             	sub    %rbp,%rax
    34d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    34d6:	48 39 d0             	cmp    %rdx,%rax
    34d9:	48 0f 47 c2          	cmova  %rdx,%rax
    34dd:	89 c1                	mov    %eax,%ecx
    34df:	83 f8 08             	cmp    $0x8,%eax
    34e2:	0f 83 18 02 00 00    	jae    3700 <fwp_format_g.constprop.0+0x3b0>
    34e8:	a8 04                	test   $0x4,%al
    34ea:	0f 85 54 03 00 00    	jne    3844 <fwp_format_g.constprop.0+0x4f4>
    34f0:	85 c0                	test   %eax,%eax
    34f2:	74 0f                	je     3503 <fwp_format_g.constprop.0+0x1b3>
    34f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    34f9:	88 13                	mov    %dl,(%rbx)
    34fb:	a8 02                	test   $0x2,%al
    34fd:	0f 85 6b 03 00 00    	jne    386e <fwp_format_g.constprop.0+0x51e>
    3503:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3507:	eb 36                	jmp    353f <fwp_format_g.constprop.0+0x1ef>
    3509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3510:	45 31 c9             	xor    %r9d,%r9d
    3513:	45 85 ed             	test   %r13d,%r13d
    3516:	4c 8d 05 7d 8b 00 00 	lea    0x8b7d(%rip),%r8        # c09a <_IO_stdin_used+0x9a>
    351d:	48 89 df             	mov    %rbx,%rdi
    3520:	45 0f 49 cd          	cmovns %r13d,%r9d
    3524:	ba 02 00 00 00       	mov    $0x2,%edx
    3529:	be 90 01 00 00       	mov    $0x190,%esi
    352e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3535:	b8 01 00 00 00       	mov    $0x1,%eax
    353a:	e8 51 ee ff ff       	call   2390 <__snprintf_chk@plt>
    353f:	be 2e 00 00 00       	mov    $0x2e,%esi
    3544:	48 89 df             	mov    %rbx,%rdi
    3547:	e8 14 ef ff ff       	call   2460 <strchr@plt>
    354c:	48 85 c0             	test   %rax,%rax
    354f:	74 3f                	je     3590 <fwp_format_g.constprop.0+0x240>
    3551:	48 89 df             	mov    %rbx,%rdi
    3554:	e8 d7 ee ff ff       	call   2430 <strlen@plt>
    3559:	48 85 c0             	test   %rax,%rax
    355c:	75 0b                	jne    3569 <fwp_format_g.constprop.0+0x219>
    355e:	eb 30                	jmp    3590 <fwp_format_g.constprop.0+0x240>
    3560:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    3564:	48 85 c0             	test   %rax,%rax
    3567:	74 27                	je     3590 <fwp_format_g.constprop.0+0x240>
    3569:	48 89 c2             	mov    %rax,%rdx
    356c:	48 83 e8 01          	sub    $0x1,%rax
    3570:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    3574:	74 ea                	je     3560 <fwp_format_g.constprop.0+0x210>
    3576:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    357b:	0f 84 6f 01 00 00    	je     36f0 <fwp_format_g.constprop.0+0x3a0>
    3581:	0f 1f 40 00          	nopl   0x0(%rax)
    3585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    358c:	00 00 00 00 
    3590:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    3597:	00 
    3598:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    359f:	00 00 
    35a1:	0f 85 ec 02 00 00    	jne    3893 <fwp_format_g.constprop.0+0x543>
    35a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    35ae:	5b                   	pop    %rbx
    35af:	5d                   	pop    %rbp
    35b0:	41 5c                	pop    %r12
    35b2:	41 5d                	pop    %r13
    35b4:	41 5e                	pop    %r14
    35b6:	41 5f                	pop    %r15
    35b8:	c3                   	ret
    35b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    35c0:	4c 29 f5             	sub    %r14,%rbp
    35c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    35c8:	4c 89 f6             	mov    %r14,%rsi
    35cb:	4c 89 04 24          	mov    %r8,(%rsp)
    35cf:	49 89 ec             	mov    %rbp,%r12
    35d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    35d7:	4c 89 e2             	mov    %r12,%rdx
    35da:	48 89 ef             	mov    %rbp,%rdi
    35dd:	e8 5e ef ff ff       	call   2540 <__memcpy_chk@plt>
    35e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    35e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    35ed:	48 89 ef             	mov    %rbp,%rdi
    35f0:	e8 6b ee ff ff       	call   2460 <strchr@plt>
    35f5:	4c 8b 04 24          	mov    (%rsp),%r8
    35f9:	48 85 c0             	test   %rax,%rax
    35fc:	74 40                	je     363e <fwp_format_g.constprop.0+0x2ee>
    35fe:	4d 85 e4             	test   %r12,%r12
    3601:	74 3b                	je     363e <fwp_format_g.constprop.0+0x2ee>
    3603:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    3608:	eb 23                	jmp    362d <fwp_format_g.constprop.0+0x2dd>
    360a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3611:	00 00 00 00 
    3615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    361c:	00 00 00 00 
    3620:	c6 00 00             	movb   $0x0,(%rax)
    3623:	48 83 e8 01          	sub    $0x1,%rax
    3627:	49 83 ec 01          	sub    $0x1,%r12
    362b:	74 11                	je     363e <fwp_format_g.constprop.0+0x2ee>
    362d:	80 38 30             	cmpb   $0x30,(%rax)
    3630:	74 ee                	je     3620 <fwp_format_g.constprop.0+0x2d0>
    3632:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    3638:	0f 84 fb 01 00 00    	je     3839 <fwp_format_g.constprop.0+0x4e9>
    363e:	44 89 c0             	mov    %r8d,%eax
    3641:	ba 02 00 00 00       	mov    $0x2,%edx
    3646:	49 89 e9             	mov    %rbp,%r9
    3649:	be 90 01 00 00       	mov    $0x190,%esi
    364e:	f7 d8                	neg    %eax
    3650:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    3657:	48 89 df             	mov    %rbx,%rdi
    365a:	41 0f 48 c0          	cmovs  %r8d,%eax
    365e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    3662:	41 83 e0 02          	and    $0x2,%r8d
    3666:	41 83 c0 2b          	add    $0x2b,%r8d
    366a:	50                   	push   %rax
    366b:	31 c0                	xor    %eax,%eax
    366d:	41 50                	push   %r8
    366f:	4c 8d 05 1a 8a 00 00 	lea    0x8a1a(%rip),%r8        # c090 <_IO_stdin_used+0x90>
    3676:	e8 15 ed ff ff       	call   2390 <__snprintf_chk@plt>
    367b:	58                   	pop    %rax
    367c:	5a                   	pop    %rdx
    367d:	e9 0e ff ff ff       	jmp    3590 <fwp_format_g.constprop.0+0x240>
    3682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3688:	4d 8b 06             	mov    (%r14),%r8
    368b:	48 83 c0 09          	add    $0x9,%rax
    368f:	4c 89 f2             	mov    %r14,%rdx
    3692:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    3696:	4c 89 07             	mov    %r8,(%rdi)
    3699:	45 89 e0             	mov    %r12d,%r8d
    369c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    36a1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    36a6:	49 89 f8             	mov    %rdi,%r8
    36a9:	49 29 c0             	sub    %rax,%r8
    36ac:	4c 29 c2             	sub    %r8,%rdx
    36af:	45 01 e0             	add    %r12d,%r8d
    36b2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    36b6:	41 83 f8 08          	cmp    $0x8,%r8d
    36ba:	0f 82 bc fd ff ff    	jb     347c <fwp_format_g.constprop.0+0x12c>
    36c0:	48 89 0c 24          	mov    %rcx,(%rsp)
    36c4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    36c8:	45 31 d2             	xor    %r10d,%r10d
    36cb:	45 89 d3             	mov    %r10d,%r11d
    36ce:	41 83 c2 08          	add    $0x8,%r10d
    36d2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    36d6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    36da:	45 39 c2             	cmp    %r8d,%r10d
    36dd:	72 ec                	jb     36cb <fwp_format_g.constprop.0+0x37b>
    36df:	48 8b 0c 24          	mov    (%rsp),%rcx
    36e3:	e9 94 fd ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    36e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    36ef:	00 
    36f0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    36f5:	e9 96 fe ff ff       	jmp    3590 <fwp_format_g.constprop.0+0x240>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3700:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3705:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    3709:	48 89 ee             	mov    %rbp,%rsi
    370c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    3710:	48 89 13             	mov    %rdx,(%rbx)
    3713:	89 c2                	mov    %eax,%edx
    3715:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    371a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    371f:	48 89 d9             	mov    %rbx,%rcx
    3722:	48 29 f9             	sub    %rdi,%rcx
    3725:	48 29 ce             	sub    %rcx,%rsi
    3728:	01 c1                	add    %eax,%ecx
    372a:	c1 e9 03             	shr    $0x3,%ecx
    372d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    3730:	e9 ce fd ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    3735:	0f 1f 00             	nopl   (%rax)
    3738:	c6 00 30             	movb   $0x30,(%rax)
    373b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    373f:	4c 89 fa             	mov    %r15,%rdx
    3742:	4c 89 e9             	mov    %r13,%rcx
    3745:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    374a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    374f:	4c 89 14 24          	mov    %r10,(%rsp)
    3753:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    3758:	e8 e3 ed ff ff       	call   2540 <__memcpy_chk@plt>
    375d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    3762:	b9 48 00 00 00       	mov    $0x48,%ecx
    3767:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    376c:	48 89 c7             	mov    %rax,%rdi
    376f:	4c 8b 14 24          	mov    (%rsp),%r10
    3773:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    3778:	4c 89 c8             	mov    %r9,%rax
    377b:	4c 29 e8             	sub    %r13,%rax
    377e:	48 39 c8             	cmp    %rcx,%rax
    3781:	48 0f 42 c1          	cmovb  %rcx,%rax
    3785:	4d 29 cd             	sub    %r9,%r13
    3788:	49 01 ff             	add    %rdi,%r15
    378b:	4c 01 e8             	add    %r13,%rax
    378e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    3792:	74 3d                	je     37d1 <fwp_format_g.constprop.0+0x481>
    3794:	41 f7 d0             	not    %r8d
    3797:	31 f6                	xor    %esi,%esi
    3799:	ba 48 00 00 00       	mov    $0x48,%edx
    379e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    37a3:	48 39 d0             	cmp    %rdx,%rax
    37a6:	48 0f 43 d0          	cmovae %rax,%rdx
    37aa:	48 89 d1             	mov    %rdx,%rcx
    37ad:	48 29 c1             	sub    %rax,%rcx
    37b0:	48 83 c1 01          	add    $0x1,%rcx
    37b4:	48 39 d1             	cmp    %rdx,%rcx
    37b7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    37bb:	48 83 e8 01          	sub    $0x1,%rax
    37bf:	48 83 c6 01          	add    $0x1,%rsi
    37c3:	48 29 d0             	sub    %rdx,%rax
    37c6:	48 01 c8             	add    %rcx,%rax
    37c9:	41 39 f0             	cmp    %esi,%r8d
    37cc:	7f cb                	jg     3799 <fwp_format_g.constprop.0+0x449>
    37ce:	4d 01 c7             	add    %r8,%r15
    37d1:	b9 48 00 00 00       	mov    $0x48,%ecx
    37d6:	41 0f b6 12          	movzbl (%r10),%edx
    37da:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    37de:	4c 89 f6             	mov    %r14,%rsi
    37e1:	48 39 c8             	cmp    %rcx,%rax
    37e4:	4c 89 1c 24          	mov    %r11,(%rsp)
    37e8:	48 0f 43 c8          	cmovae %rax,%rcx
    37ec:	41 88 17             	mov    %dl,(%r15)
    37ef:	48 89 ca             	mov    %rcx,%rdx
    37f2:	48 29 c2             	sub    %rax,%rdx
    37f5:	48 83 c2 01          	add    $0x1,%rdx
    37f9:	48 39 ca             	cmp    %rcx,%rdx
    37fc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    3800:	48 83 e8 01          	sub    $0x1,%rax
    3804:	48 29 c8             	sub    %rcx,%rax
    3807:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    380b:	49 63 d4             	movslq %r12d,%rdx
    380e:	e8 2d ed ff ff       	call   2540 <__memcpy_chk@plt>
    3813:	4c 8b 1c 24          	mov    (%rsp),%r11
    3817:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    381b:	e9 ae fc ff ff       	jmp    34ce <fwp_format_g.constprop.0+0x17e>
    3820:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    3825:	b9 47 00 00 00       	mov    $0x47,%ecx
    382a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    382f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    3834:	e9 f9 fb ff ff       	jmp    3432 <fwp_format_g.constprop.0+0xe2>
    3839:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    383f:	e9 fa fd ff ff       	jmp    363e <fwp_format_g.constprop.0+0x2ee>
    3844:	8b 54 24 60          	mov    0x60(%rsp),%edx
    3848:	89 13                	mov    %edx,(%rbx)
    384a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    384e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    3852:	e9 ac fc ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    3857:	41 8b 06             	mov    (%r14),%eax
    385a:	89 07                	mov    %eax,(%rdi)
    385c:	44 89 e0             	mov    %r12d,%eax
    385f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    3864:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    3869:	e9 0e fc ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    386e:	89 c2                	mov    %eax,%edx
    3870:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    3875:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    387a:	e9 84 fc ff ff       	jmp    3503 <fwp_format_g.constprop.0+0x1b3>
    387f:	44 89 e0             	mov    %r12d,%eax
    3882:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    3888:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    388e:	e9 e9 fb ff ff       	jmp    347c <fwp_format_g.constprop.0+0x12c>
    3893:	e8 a8 eb ff ff       	call   2440 <__stack_chk_fail@plt>
    3898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    389f:	00 

00000000000038a0 <fwp_heap_report>:
    38a0:	f3 0f 1e fa          	endbr64
    38a4:	41 54                	push   %r12
    38a6:	48 8d 3d f2 87 00 00 	lea    0x87f2(%rip),%rdi        # c09f <_IO_stdin_used+0x9f>
    38ad:	55                   	push   %rbp
    38ae:	53                   	push   %rbx
    38af:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    38b6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    38bd:	00 00 
    38bf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    38c6:	00 
    38c7:	48 8d 35 93 88 00 00 	lea    0x8893(%rip),%rsi        # c161 <_IO_stdin_used+0x161>
    38ce:	e8 1d ed ff ff       	call   25f0 <fopen@plt>
    38d3:	48 85 c0             	test   %rax,%rax
    38d6:	0f 84 c5 00 00 00    	je     39a1 <fwp_heap_report+0x101>
    38dc:	48 89 c5             	mov    %rax,%rbp
    38df:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    38e6:	48 89 e3             	mov    %rsp,%rbx
    38e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    38f0:	48 89 ea             	mov    %rbp,%rdx
    38f3:	be 00 01 00 00       	mov    $0x100,%esi
    38f8:	48 89 df             	mov    %rbx,%rdi
    38fb:	e8 e0 eb ff ff       	call   24e0 <fgets@plt>
    3900:	48 85 c0             	test   %rax,%rax
    3903:	74 2b                	je     3930 <fwp_heap_report+0x90>
    3905:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    390b:	75 e3                	jne    38f0 <fwp_heap_report+0x50>
    390d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    3911:	75 dd                	jne    38f0 <fwp_heap_report+0x50>
    3913:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    3918:	75 d6                	jne    38f0 <fwp_heap_report+0x50>
    391a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    391f:	ba 0a 00 00 00       	mov    $0xa,%edx
    3924:	31 f6                	xor    %esi,%esi
    3926:	e8 35 ec ff ff       	call   2560 <strtol@plt>
    392b:	49 89 c4             	mov    %rax,%r12
    392e:	eb c0                	jmp    38f0 <fwp_heap_report+0x50>
    3930:	48 89 ef             	mov    %rbp,%rdi
    3933:	e8 e8 ea ff ff       	call   2420 <fclose@plt>
    3938:	48 83 ec 08          	sub    $0x8,%rsp
    393c:	4c 8b 0d 85 d1 01 00 	mov    0x1d185(%rip),%r9        # 20ac8 <fwp_heap+0x13c8>
    3943:	4c 8b 05 de d1 01 00 	mov    0x1d1de(%rip),%r8        # 20b28 <fwp_heap+0x1428>
    394a:	48 8d 15 97 89 00 00 	lea    0x8997(%rip),%rdx        # c2e8 <_IO_stdin_used+0x2e8>
    3951:	41 54                	push   %r12
    3953:	48 8b 0d c6 d1 01 00 	mov    0x1d1c6(%rip),%rcx        # 20b20 <fwp_heap+0x1420>
    395a:	be 02 00 00 00       	mov    $0x2,%esi
    395f:	b8 02 00 00 00       	mov    $0x2,%eax
    3964:	f2 0f 10 0d d4 d1 01 	movsd  0x1d1d4(%rip),%xmm1        # 20b40 <fwp_heap+0x1440>
    396b:	00 
    396c:	f2 0f 10 05 c4 d1 01 	movsd  0x1d1c4(%rip),%xmm0        # 20b38 <fwp_heap+0x1438>
    3973:	00 
    3974:	48 8b 3d c5 b6 00 00 	mov    0xb6c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    397b:	e8 d0 ec ff ff       	call   2650 <__fprintf_chk@plt>
    3980:	58                   	pop    %rax
    3981:	5a                   	pop    %rdx
    3982:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    3989:	00 
    398a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3991:	00 00 
    3993:	75 15                	jne    39aa <fwp_heap_report+0x10a>
    3995:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    399c:	5b                   	pop    %rbx
    399d:	5d                   	pop    %rbp
    399e:	41 5c                	pop    %r12
    39a0:	c3                   	ret
    39a1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    39a8:	eb 8e                	jmp    3938 <fwp_heap_report+0x98>
    39aa:	e8 91 ea ff ff       	call   2440 <__stack_chk_fail@plt>
    39af:	90                   	nop

00000000000039b0 <fwp_heap_init>:
    39b0:	66 0f 6f 05 68 8c 00 	movdqa 0x8c68(%rip),%xmm0        # c620 <msg.3+0x50>
    39b7:	00 
    39b8:	41 54                	push   %r12
    39ba:	48 8d 05 7f cc 01 00 	lea    0x1cc7f(%rip),%rax        # 20640 <fwp_heap+0xf40>
    39c1:	ba 00 01 00 00       	mov    $0x100,%edx
    39c6:	55                   	push   %rbp
    39c7:	66 0f 6f 15 91 8c 00 	movdqa 0x8c91(%rip),%xmm2        # c660 <msg.3+0x90>
    39ce:	00 
    39cf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    39d3:	53                   	push   %rbx
    39d4:	0f 29 05 25 cc 01 00 	movaps %xmm0,0x1cc25(%rip)        # 20600 <fwp_heap+0xf00>
    39db:	66 0f 6f 05 4d 8c 00 	movdqa 0x8c4d(%rip),%xmm0        # c630 <msg.3+0x60>
    39e2:	00 
    39e3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    39e7:	c7 05 b3 d0 01 00 01 	movl   $0x1,0x1d0b3(%rip)        # 20aa4 <fwp_heap+0x13a4>
    39ee:	00 00 00 
    39f1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    39f6:	0f 29 05 13 cc 01 00 	movaps %xmm0,0x1cc13(%rip)        # 20610 <fwp_heap+0xf10>
    39fd:	66 0f 6f 05 3b 8c 00 	movdqa 0x8c3b(%rip),%xmm0        # c640 <msg.3+0x70>
    3a04:	00 
    3a05:	0f 29 05 14 cc 01 00 	movaps %xmm0,0x1cc14(%rip)        # 20620 <fwp_heap+0xf20>
    3a0c:	66 0f 6f 05 3c 8c 00 	movdqa 0x8c3c(%rip),%xmm0        # c650 <msg.3+0x80>
    3a13:	00 
    3a14:	0f 29 05 15 cc 01 00 	movaps %xmm0,0x1cc15(%rip)        # 20630 <fwp_heap+0xf30>
    3a1b:	89 d3                	mov    %edx,%ebx
    3a1d:	66 0f 6e e2          	movd   %edx,%xmm4
    3a21:	48 83 c0 10          	add    $0x10,%rax
    3a25:	01 d2                	add    %edx,%edx
    3a27:	c1 eb 02             	shr    $0x2,%ebx
    3a2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    3a2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    3a33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3a37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    3a3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    3a40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    3a44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    3a49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    3a4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    3a52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    3a57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    3a5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    3a5f:	48 39 c7             	cmp    %rax,%rdi
    3a62:	75 b7                	jne    3a1b <fwp_heap_init+0x6b>
    3a64:	4c 8d 05 95 bc 01 00 	lea    0x1bc95(%rip),%r8        # 1f700 <fwp_heap>
    3a6b:	31 c9                	xor    %ecx,%ecx
    3a6d:	31 c0                	xor    %eax,%eax
    3a6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    3a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3a7d:	00 00 00 
    3a80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    3a87:	00 
    3a88:	48 39 ca             	cmp    %rcx,%rdx
    3a8b:	73 0f                	jae    3a9c <fwp_heap_init+0xec>
    3a8d:	0f 1f 00             	nopl   (%rax)
    3a90:	48 83 c0 01          	add    $0x1,%rax
    3a94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    3a97:	48 39 ca             	cmp    %rcx,%rdx
    3a9a:	72 f4                	jb     3a90 <fwp_heap_init+0xe0>
    3a9c:	48 83 c1 10          	add    $0x10,%rcx
    3aa0:	88 07                	mov    %al,(%rdi)
    3aa2:	48 83 c7 01          	add    $0x1,%rdi
    3aa6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    3aad:	75 d1                	jne    3a80 <fwp_heap_init+0xd0>
    3aaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    3ab6:	00 00 00 
    3ab9:	bd 05 00 00 00       	mov    $0x5,%ebp
    3abe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    3ac5:	45 31 c9             	xor    %r9d,%r9d
    3ac8:	31 d2                	xor    %edx,%edx
    3aca:	31 ff                	xor    %edi,%edi
    3acc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3ad2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3ad7:	4c 89 e6             	mov    %r12,%rsi
    3ada:	e8 71 e9 ff ff       	call   2450 <mmap@plt>
    3adf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3ae3:	75 13                	jne    3af8 <fwp_heap_init+0x148>
    3ae5:	48 c1 eb 02          	shr    $0x2,%rbx
    3ae9:	83 ed 01             	sub    $0x1,%ebp
    3aec:	75 d0                	jne    3abe <fwp_heap_init+0x10e>
    3aee:	e8 6d f2 ff ff       	call   2d60 <fwp_heap_oom>
    3af3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3af8:	48 85 c0             	test   %rax,%rax
    3afb:	74 f1                	je     3aee <fwp_heap_init+0x13e>
    3afd:	48 c1 eb 10          	shr    $0x10,%rbx
    3b01:	48 89 05 b0 cf 01 00 	mov    %rax,0x1cfb0(%rip)        # 20ab8 <fwp_heap+0x13b8>
    3b08:	45 31 c9             	xor    %r9d,%r9d
    3b0b:	31 d2                	xor    %edx,%edx
    3b0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    3b13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    3b17:	31 ff                	xor    %edi,%edi
    3b19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3b1f:	66 31 c0             	xor    %ax,%ax
    3b22:	48 c1 e6 03          	shl    $0x3,%rsi
    3b26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    3b2b:	4c 89 25 8e cf 01 00 	mov    %r12,0x1cf8e(%rip)        # 20ac0 <fwp_heap+0x13c0>
    3b32:	48 89 05 77 cf 01 00 	mov    %rax,0x1cf77(%rip)        # 20ab0 <fwp_heap+0x13b0>
    3b39:	48 89 1d 90 cf 01 00 	mov    %rbx,0x1cf90(%rip)        # 20ad0 <fwp_heap+0x13d0>
    3b40:	48 89 35 b9 cf 01 00 	mov    %rsi,0x1cfb9(%rip)        # 20b00 <fwp_heap+0x1400>
    3b47:	e8 04 e9 ff ff       	call   2450 <mmap@plt>
    3b4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3b50:	74 9c                	je     3aee <fwp_heap_init+0x13e>
    3b52:	48 8d 3d 7c 85 00 00 	lea    0x857c(%rip),%rdi        # c0d5 <_IO_stdin_used+0xd5>
    3b59:	48 89 05 98 cf 01 00 	mov    %rax,0x1cf98(%rip)        # 20af8 <fwp_heap+0x13f8>
    3b60:	e8 1b e8 ff ff       	call   2380 <getenv@plt>
    3b65:	48 89 c2             	mov    %rax,%rdx
    3b68:	31 c0                	xor    %eax,%eax
    3b6a:	48 85 d2             	test   %rdx,%rdx
    3b6d:	74 15                	je     3b84 <fwp_heap_init+0x1d4>
    3b6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    3b72:	74 10                	je     3b84 <fwp_heap_init+0x1d4>
    3b74:	0f b6 02             	movzbl (%rdx),%eax
    3b77:	83 e8 30             	sub    $0x30,%eax
    3b7a:	74 13                	je     3b8f <fwp_heap_init+0x1df>
    3b7c:	85 c0                	test   %eax,%eax
    3b7e:	0f 95 c0             	setne  %al
    3b81:	0f b6 c0             	movzbl %al,%eax
    3b84:	5b                   	pop    %rbx
    3b85:	5d                   	pop    %rbp
    3b86:	89 05 1c cf 01 00    	mov    %eax,0x1cf1c(%rip)        # 20aa8 <fwp_heap+0x13a8>
    3b8c:	41 5c                	pop    %r12
    3b8e:	c3                   	ret
    3b8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    3b93:	85 c0                	test   %eax,%eax
    3b95:	0f 95 c0             	setne  %al
    3b98:	0f b6 c0             	movzbl %al,%eax
    3b9b:	eb e7                	jmp    3b84 <fwp_heap_init+0x1d4>
    3b9d:	0f 1f 00             	nopl   (%rax)

0000000000003ba0 <fwp_args45>:
    3ba0:	f3 0f 1e fa          	endbr64
    3ba4:	c3                   	ret
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_args69>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	c3                   	ret
    3bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bbc:	00 00 00 00 

0000000000003bc0 <fwp_wake_io>:
    3bc0:	48 8b 07             	mov    (%rdi),%rax
    3bc3:	48 85 c0             	test   %rax,%rax
    3bc6:	0f 84 f4 00 00 00    	je     3cc0 <fwp_wake_io+0x100>
    3bcc:	53                   	push   %rbx
    3bcd:	4c 8b 05 ec ba 01 00 	mov    0x1baec(%rip),%r8        # 1f6c0 <fwp_ready_tail>
    3bd4:	49 89 f9             	mov    %rdi,%r9
    3bd7:	48 89 c2             	mov    %rax,%rdx
    3bda:	45 31 db             	xor    %r11d,%r11d
    3bdd:	45 31 d2             	xor    %r10d,%r10d
    3be0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3be4:	eb 71                	jmp    3c57 <fwp_wake_io+0x97>
    3be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3bed:	00 00 00 
    3bf0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    3bf7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3bfe:	48 85 c9             	test   %rcx,%rcx
    3c01:	74 07                	je     3c0a <fwp_wake_io+0x4a>
    3c03:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    3c0a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    3c11:	00 00 00 00 
    3c15:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    3c1c:	49 8b 01             	mov    (%r9),%rax
    3c1f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3c23:	75 2a                	jne    3c4f <fwp_wake_io+0x8f>
    3c25:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3c29:	75 24                	jne    3c4f <fwp_wake_io+0x8f>
    3c2b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3c2f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3c36:	00 00 00 00 
    3c3a:	4d 85 c0             	test   %r8,%r8
    3c3d:	74 51                	je     3c90 <fwp_wake_io+0xd0>
    3c3f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    3c46:	49 89 d0             	mov    %rdx,%r8
    3c49:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3c4f:	48 89 c2             	mov    %rax,%rdx
    3c52:	48 85 c0             	test   %rax,%rax
    3c55:	74 49                	je     3ca0 <fwp_wake_io+0xe0>
    3c57:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    3c5e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    3c62:	48 85 ff             	test   %rdi,%rdi
    3c65:	74 b8                	je     3c1f <fwp_wake_io+0x5f>
    3c67:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    3c6e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    3c75:	48 85 f6             	test   %rsi,%rsi
    3c78:	0f 85 72 ff ff ff    	jne    3bf0 <fwp_wake_io+0x30>
    3c7e:	48 89 0f             	mov    %rcx,(%rdi)
    3c81:	e9 78 ff ff ff       	jmp    3bfe <fwp_wake_io+0x3e>
    3c86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3c8d:	00 00 00 
    3c90:	48 89 d3             	mov    %rdx,%rbx
    3c93:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3c99:	eb ab                	jmp    3c46 <fwp_wake_io+0x86>
    3c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3ca0:	45 84 db             	test   %r11b,%r11b
    3ca3:	74 07                	je     3cac <fwp_wake_io+0xec>
    3ca5:	48 89 1d 1c ba 01 00 	mov    %rbx,0x1ba1c(%rip)        # 1f6c8 <fwp_ready_head>
    3cac:	45 84 d2             	test   %r10b,%r10b
    3caf:	74 07                	je     3cb8 <fwp_wake_io+0xf8>
    3cb1:	4c 89 05 08 ba 01 00 	mov    %r8,0x1ba08(%rip)        # 1f6c0 <fwp_ready_tail>
    3cb8:	5b                   	pop    %rbx
    3cb9:	c3                   	ret
    3cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3cc0:	c3                   	ret
    3cc1:	0f 1f 40 00          	nopl   0x0(%rax)
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_poll_events>:
    3cd0:	53                   	push   %rbx
    3cd1:	48 83 ec 20          	sub    $0x20,%rsp
    3cd5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3cdc:	00 00 
    3cde:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    3ce3:	31 c0                	xor    %eax,%eax
    3ce5:	e8 b6 f5 ff ff       	call   32a0 <fwp_now_ns>
    3cea:	48 8b 1d c7 b9 01 00 	mov    0x1b9c7(%rip),%rbx        # 1f6b8 <fwp_timers>
    3cf1:	48 85 db             	test   %rbx,%rbx
    3cf4:	0f 84 e6 00 00 00    	je     3de0 <fwp_poll_events+0x110>
    3cfa:	48 89 c6             	mov    %rax,%rsi
    3cfd:	48 89 da             	mov    %rbx,%rdx
    3d00:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    3d07:	eb 26                	jmp    3d2f <fwp_poll_events+0x5f>
    3d09:	90                   	nop
    3d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d11:	00 00 00 00 
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 
    3d20:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d27:	48 89 c8             	mov    %rcx,%rax
    3d2a:	48 85 d2             	test   %rdx,%rdx
    3d2d:	74 31                	je     3d60 <fwp_poll_events+0x90>
    3d2f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3d33:	48 85 c0             	test   %rax,%rax
    3d36:	78 e8                	js     3d20 <fwp_poll_events+0x50>
    3d38:	48 39 c1             	cmp    %rax,%rcx
    3d3b:	7c e3                	jl     3d20 <fwp_poll_events+0x50>
    3d3d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d44:	48 85 d2             	test   %rdx,%rdx
    3d47:	74 1c                	je     3d65 <fwp_poll_events+0x95>
    3d49:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    3d4d:	48 39 c1             	cmp    %rax,%rcx
    3d50:	7c ce                	jl     3d20 <fwp_poll_events+0x50>
    3d52:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    3d59:	48 85 d2             	test   %rdx,%rdx
    3d5c:	75 d1                	jne    3d2f <fwp_poll_events+0x5f>
    3d5e:	66 90                	xchg   %ax,%ax
    3d60:	48 85 c0             	test   %rax,%rax
    3d63:	78 7b                	js     3de0 <fwp_poll_events+0x110>
    3d65:	48 29 f0             	sub    %rsi,%rax
    3d68:	48 89 c1             	mov    %rax,%rcx
    3d6b:	48 85 c0             	test   %rax,%rax
    3d6e:	0f 8e 9c 00 00 00    	jle    3e10 <fwp_poll_events+0x140>
    3d74:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    3d7b:	de 1b 43 
    3d7e:	48 f7 ea             	imul   %rdx
    3d81:	48 89 c8             	mov    %rcx,%rax
    3d84:	48 c1 f8 3f          	sar    $0x3f,%rax
    3d88:	48 c1 fa 12          	sar    $0x12,%rdx
    3d8c:	48 29 c2             	sub    %rax,%rdx
    3d8f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    3d96:	48 39 c1             	cmp    %rax,%rcx
    3d99:	0f 95 c0             	setne  %al
    3d9c:	0f b6 c0             	movzbl %al,%eax
    3d9f:	48 01 d0             	add    %rdx,%rax
    3da2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    3da8:	0f 8f 32 01 00 00    	jg     3ee0 <fwp_poll_events+0x210>
    3dae:	48 85 c0             	test   %rax,%rax
    3db1:	74 5d                	je     3e10 <fwp_poll_events+0x140>
    3db3:	89 c1                	mov    %eax,%ecx
    3db5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    3dbc:	48 c1 e9 26          	shr    $0x26,%rcx
    3dc0:	48 63 d1             	movslq %ecx,%rdx
    3dc3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    3dc9:	29 c8                	sub    %ecx,%eax
    3dcb:	48 98                	cltq
    3dcd:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    3dd4:	e9 11 01 00 00       	jmp    3eea <fwp_poll_events+0x21a>
    3dd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3de0:	e8 4b ee ff ff       	call   2c30 <fwp_flush>
    3de5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    3dea:	be 01 00 00 00       	mov    $0x1,%esi
    3def:	48 8b 0d 4a b2 00 00 	mov    0xb24a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3df6:	48 8d 3d 73 85 00 00 	lea    0x8573(%rip),%rdi        # c370 <_IO_stdin_used+0x370>
    3dfd:	e8 3e e8 ff ff       	call   2640 <fwrite@plt>
    3e02:	bf 65 00 00 00       	mov    $0x65,%edi
    3e07:	e8 24 e8 ff ff       	call   2630 <exit@plt>
    3e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    3e10:	e8 8b f4 ff ff       	call   32a0 <fwp_now_ns>
    3e15:	48 89 c1             	mov    %rax,%rcx
    3e18:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3e1c:	eb 44                	jmp    3e62 <fwp_poll_events+0x192>
    3e1e:	66 90                	xchg   %ax,%ax
    3e20:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    3e24:	75 33                	jne    3e59 <fwp_poll_events+0x189>
    3e26:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3e2a:	75 2d                	jne    3e59 <fwp_poll_events+0x189>
    3e2c:	48 8b 05 8d b8 01 00 	mov    0x1b88d(%rip),%rax        # 1f6c0 <fwp_ready_tail>
    3e33:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    3e37:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    3e3e:	00 00 00 00 
    3e42:	48 85 c0             	test   %rax,%rax
    3e45:	0f 84 05 01 00 00    	je     3f50 <fwp_poll_events+0x280>
    3e4b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    3e52:	48 89 15 67 b8 01 00 	mov    %rdx,0x1b867(%rip)        # 1f6c0 <fwp_ready_tail>
    3e59:	48 85 db             	test   %rbx,%rbx
    3e5c:	0f 84 be 00 00 00    	je     3f20 <fwp_poll_events+0x250>
    3e62:	48 89 da             	mov    %rbx,%rdx
    3e65:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    3e6c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    3e70:	7f e7                	jg     3e59 <fwp_poll_events+0x189>
    3e72:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    3e76:	74 2e                	je     3ea6 <fwp_poll_events+0x1d6>
    3e78:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    3e7f:	48 85 c0             	test   %rax,%rax
    3e82:	0f 84 b8 00 00 00    	je     3f40 <fwp_poll_events+0x270>
    3e88:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    3e8f:	48 85 db             	test   %rbx,%rbx
    3e92:	74 07                	je     3e9b <fwp_poll_events+0x1cb>
    3e94:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    3e9b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    3e9f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    3ea6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    3eaa:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    3eae:	48 85 c0             	test   %rax,%rax
    3eb1:	0f 84 69 ff ff ff    	je     3e20 <fwp_poll_events+0x150>
    3eb7:	48 39 c8             	cmp    %rcx,%rax
    3eba:	0f 8f 60 ff ff ff    	jg     3e20 <fwp_poll_events+0x150>
    3ec0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    3ec4:	0f 85 56 ff ff ff    	jne    3e20 <fwp_poll_events+0x150>
    3eca:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3ece:	75 89                	jne    3e59 <fwp_poll_events+0x189>
    3ed0:	48 89 d7             	mov    %rdx,%rdi
    3ed3:	e8 88 f1 ff ff       	call   3060 <fwp_cancel_tree.part.0>
    3ed8:	e9 43 ff ff ff       	jmp    3e20 <fwp_poll_events+0x150>
    3edd:	0f 1f 00             	nopl   (%rax)
    3ee0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    3ee5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    3eea:	48 89 e7             	mov    %rsp,%rdi
    3eed:	31 f6                	xor    %esi,%esi
    3eef:	48 89 14 24          	mov    %rdx,(%rsp)
    3ef3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    3ef8:	e8 83 e5 ff ff       	call   2480 <nanosleep@plt>
    3efd:	48 8b 1d b4 b7 01 00 	mov    0x1b7b4(%rip),%rbx        # 1f6b8 <fwp_timers>
    3f04:	e8 97 f3 ff ff       	call   32a0 <fwp_now_ns>
    3f09:	48 89 c1             	mov    %rax,%rcx
    3f0c:	48 85 db             	test   %rbx,%rbx
    3f0f:	0f 85 03 ff ff ff    	jne    3e18 <fwp_poll_events+0x148>
    3f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f1c:	00 00 00 00 
    3f20:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    3f25:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f2c:	00 00 
    3f2e:	75 2c                	jne    3f5c <fwp_poll_events+0x28c>
    3f30:	48 83 c4 20          	add    $0x20,%rsp
    3f34:	5b                   	pop    %rbx
    3f35:	c3                   	ret
    3f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3f3d:	00 00 00 
    3f40:	48 89 1d 71 b7 01 00 	mov    %rbx,0x1b771(%rip)        # 1f6b8 <fwp_timers>
    3f47:	e9 43 ff ff ff       	jmp    3e8f <fwp_poll_events+0x1bf>
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 89 15 71 b7 01 00 	mov    %rdx,0x1b771(%rip)        # 1f6c8 <fwp_ready_head>
    3f57:	e9 f6 fe ff ff       	jmp    3e52 <fwp_poll_events+0x182>
    3f5c:	e8 df e4 ff ff       	call   2440 <__stack_chk_fail@plt>
    3f61:	0f 1f 40 00          	nopl   0x0(%rax)
    3f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f6c:	00 00 00 00 

0000000000003f70 <fwp_rc_wide_dup>:
    3f70:	48 89 fa             	mov    %rdi,%rdx
    3f73:	48 8d 35 86 b7 01 00 	lea    0x1b786(%rip),%rsi        # 1f700 <fwp_heap>
    3f7a:	48 83 ec 18          	sub    $0x18,%rsp
    3f7e:	48 89 f9             	mov    %rdi,%rcx
    3f81:	48 c1 ea 11          	shr    $0x11,%rdx
    3f85:	48 31 fa             	xor    %rdi,%rdx
    3f88:	48 89 d0             	mov    %rdx,%rax
    3f8b:	48 c1 e8 09          	shr    $0x9,%rax
    3f8f:	48 31 c2             	xor    %rax,%rdx
    3f92:	0f b6 d2             	movzbl %dl,%edx
    3f95:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    3f9c:	00 
    3f9d:	49 8b 00             	mov    (%r8),%rax
    3fa0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    3fa7:	00 00 
    3fa9:	75 21                	jne    3fcc <fwp_rc_wide_dup+0x5c>
    3fab:	e9 98 00 00 00       	jmp    4048 <fwp_rc_wide_dup+0xd8>
    3fb0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3fbc:	00 00 00 00 
    3fc0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3fc4:	48 85 d2             	test   %rdx,%rdx
    3fc7:	74 2f                	je     3ff8 <fwp_rc_wide_dup+0x88>
    3fc9:	48 89 d0             	mov    %rdx,%rax
    3fcc:	48 3b 08             	cmp    (%rax),%rcx
    3fcf:	75 ef                	jne    3fc0 <fwp_rc_wide_dup+0x50>
    3fd1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3fd4:	74 7c                	je     4052 <fwp_rc_wide_dup+0xe2>
    3fd6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3fda:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    3fde:	0f 84 91 00 00 00    	je     4075 <fwp_rc_wide_dup+0x105>
    3fe4:	48 83 c2 01          	add    $0x1,%rdx
    3fe8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    3fec:	48 83 c4 18          	add    $0x18,%rsp
    3ff0:	c3                   	ret
    3ff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3ff8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    3ffc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    3fff:	75 68                	jne    4069 <fwp_rc_wide_dup+0xf9>
    4001:	bf 18 00 00 00       	mov    $0x18,%edi
    4006:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    400b:	4c 89 04 24          	mov    %r8,(%rsp)
    400f:	e8 6c e5 ff ff       	call   2580 <malloc@plt>
    4014:	4c 8b 04 24          	mov    (%rsp),%r8
    4018:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401d:	48 85 c0             	test   %rax,%rax
    4020:	74 5f                	je     4081 <fwp_rc_wide_dup+0x111>
    4022:	48 89 08             	mov    %rcx,(%rax)
    4025:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    402c:	00 
    402d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    4034:	00 
    4035:	49 89 00             	mov    %rax,(%r8)
    4038:	c6 01 ff             	movb   $0xff,(%rcx)
    403b:	48 83 05 05 d3 01 00 	addq   $0x1,0x1d305(%rip)        # 21348 <fwp_heap+0x1c48>
    4042:	01 
    4043:	48 83 c4 18          	add    $0x18,%rsp
    4047:	c3                   	ret
    4048:	80 3f fe             	cmpb   $0xfe,(%rdi)
    404b:	75 13                	jne    4060 <fwp_rc_wide_dup+0xf0>
    404d:	48 85 c0             	test   %rax,%rax
    4050:	74 af                	je     4001 <fwp_rc_wide_dup+0x91>
    4052:	48 8d 3d 47 83 00 00 	lea    0x8347(%rip),%rdi        # c3a0 <_IO_stdin_used+0x3a0>
    4059:	e8 12 f2 ff ff       	call   3270 <fwp_trap>
    405e:	66 90                	xchg   %ax,%ax
    4060:	48 85 c0             	test   %rax,%rax
    4063:	0f 85 6d ff ff ff    	jne    3fd6 <fwp_rc_wide_dup+0x66>
    4069:	48 8d 3d 58 83 00 00 	lea    0x8358(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    4070:	e8 fb f1 ff ff       	call   3270 <fwp_trap>
    4075:	48 8d 3d 69 80 00 00 	lea    0x8069(%rip),%rdi        # c0e5 <_IO_stdin_used+0xe5>
    407c:	e8 ef f1 ff ff       	call   3270 <fwp_trap>
    4081:	e8 da ec ff ff       	call   2d60 <fwp_heap_oom>
    4086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    408d:	00 00 00 

0000000000004090 <fwp_rc_forget_slot>:
    4090:	80 3f ff             	cmpb   $0xff,(%rdi)
    4093:	74 0b                	je     40a0 <fwp_rc_forget_slot+0x10>
    4095:	c3                   	ret
    4096:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    409d:	00 00 00 
    40a0:	48 89 f8             	mov    %rdi,%rax
    40a3:	48 83 ec 08          	sub    $0x8,%rsp
    40a7:	48 89 fa             	mov    %rdi,%rdx
    40aa:	48 c1 e8 11          	shr    $0x11,%rax
    40ae:	48 31 f8             	xor    %rdi,%rax
    40b1:	48 89 c1             	mov    %rax,%rcx
    40b4:	48 c1 e9 09          	shr    $0x9,%rcx
    40b8:	48 31 c8             	xor    %rcx,%rax
    40bb:	48 8d 0d 3e b6 01 00 	lea    0x1b63e(%rip),%rcx        # 1f700 <fwp_heap>
    40c2:	0f b6 c0             	movzbl %al,%eax
    40c5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    40cc:	00 
    40cd:	48 85 ff             	test   %rdi,%rdi
    40d0:	74 3c                	je     410e <fwp_rc_forget_slot+0x7e>
    40d2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    40d9:	00 
    40da:	48 8b 01             	mov    (%rcx),%rax
    40dd:	eb 11                	jmp    40f0 <fwp_rc_forget_slot+0x60>
    40df:	90                   	nop
    40e0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    40e4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    40e8:	48 85 ff             	test   %rdi,%rdi
    40eb:	74 21                	je     410e <fwp_rc_forget_slot+0x7e>
    40ed:	48 89 f8             	mov    %rdi,%rax
    40f0:	48 3b 10             	cmp    (%rax),%rdx
    40f3:	75 eb                	jne    40e0 <fwp_rc_forget_slot+0x50>
    40f5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    40f9:	48 89 01             	mov    %rax,(%rcx)
    40fc:	e8 9f e2 ff ff       	call   23a0 <free@plt>
    4101:	48 83 2d 3f d2 01 00 	subq   $0x1,0x1d23f(%rip)        # 21348 <fwp_heap+0x1c48>
    4108:	01 
    4109:	48 83 c4 08          	add    $0x8,%rsp
    410d:	c3                   	ret
    410e:	48 8d 3d b3 82 00 00 	lea    0x82b3(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    4115:	e8 56 f1 ff ff       	call   3270 <fwp_trap>
    411a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004120 <fwp_rc_prepare_chunk>:
    4120:	48 83 3d 20 d2 01 00 	cmpq   $0x0,0x1d220(%rip)        # 21348 <fwp_heap+0x1c48>
    4127:	00 
    4128:	41 54                	push   %r12
    412a:	49 89 f4             	mov    %rsi,%r12
    412d:	55                   	push   %rbp
    412e:	48 89 fd             	mov    %rdi,%rbp
    4131:	53                   	push   %rbx
    4132:	8b 47 1c             	mov    0x1c(%rdi),%eax
    4135:	0f 84 7d 00 00 00    	je     41b8 <fwp_rc_prepare_chunk+0x98>
    413b:	31 db                	xor    %ebx,%ebx
    413d:	85 c0                	test   %eax,%eax
    413f:	75 5f                	jne    41a0 <fwp_rc_prepare_chunk+0x80>
    4141:	48 85 f6             	test   %rsi,%rsi
    4144:	74 7c                	je     41c2 <fwp_rc_prepare_chunk+0xa2>
    4146:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    414a:	e8 51 e2 ff ff       	call   23a0 <free@plt>
    414f:	90                   	nop
    4150:	be 01 00 00 00       	mov    $0x1,%esi
    4155:	4c 89 e7             	mov    %r12,%rdi
    4158:	e8 a3 e3 ff ff       	call   2500 <calloc@plt>
    415d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    4161:	48 85 c0             	test   %rax,%rax
    4164:	0f 85 87 00 00 00    	jne    41f1 <fwp_rc_prepare_chunk+0xd1>
    416a:	e8 f1 eb ff ff       	call   2d60 <fwp_heap_oom>
    416f:	90                   	nop
    4170:	e8 1b ff ff ff       	call   4090 <fwp_rc_forget_slot>
    4175:	8b 45 1c             	mov    0x1c(%rbp),%eax
    4178:	48 83 c3 01          	add    $0x1,%rbx
    417c:	48 39 c3             	cmp    %rax,%rbx
    417f:	73 37                	jae    41b8 <fwp_rc_prepare_chunk+0x98>
    4181:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4188:	00 00 
    418a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4191:	00 00 00 00 
    4195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    419c:	00 00 00 00 
    41a0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    41a4:	48 01 df             	add    %rbx,%rdi
    41a7:	80 3f ff             	cmpb   $0xff,(%rdi)
    41aa:	74 c4                	je     4170 <fwp_rc_prepare_chunk+0x50>
    41ac:	8b 45 1c             	mov    0x1c(%rbp),%eax
    41af:	48 83 c3 01          	add    $0x1,%rbx
    41b3:	48 39 c3             	cmp    %rax,%rbx
    41b6:	72 e8                	jb     41a0 <fwp_rc_prepare_chunk+0x80>
    41b8:	49 39 c4             	cmp    %rax,%r12
    41bb:	75 13                	jne    41d0 <fwp_rc_prepare_chunk+0xb0>
    41bd:	4d 85 e4             	test   %r12,%r12
    41c0:	75 46                	jne    4208 <fwp_rc_prepare_chunk+0xe8>
    41c2:	5b                   	pop    %rbx
    41c3:	5d                   	pop    %rbp
    41c4:	41 5c                	pop    %r12
    41c6:	c3                   	ret
    41c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    41ce:	00 00 
    41d0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    41d4:	48 29 05 75 d1 01 00 	sub    %rax,0x1d175(%rip)        # 21350 <fwp_heap+0x1c50>
    41db:	e8 c0 e1 ff ff       	call   23a0 <free@plt>
    41e0:	4d 85 e4             	test   %r12,%r12
    41e3:	0f 85 67 ff ff ff    	jne    4150 <fwp_rc_prepare_chunk+0x30>
    41e9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    41f0:	00 
    41f1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    41f5:	5b                   	pop    %rbx
    41f6:	4c 01 25 53 d1 01 00 	add    %r12,0x1d153(%rip)        # 21350 <fwp_heap+0x1c50>
    41fd:	5d                   	pop    %rbp
    41fe:	41 5c                	pop    %r12
    4200:	c3                   	ret
    4201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4208:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    420c:	5b                   	pop    %rbx
    420d:	4c 89 e2             	mov    %r12,%rdx
    4210:	31 f6                	xor    %esi,%esi
    4212:	5d                   	pop    %rbp
    4213:	41 5c                	pop    %r12
    4215:	e9 86 e2 ff ff       	jmp    24a0 <memset@plt>
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <fwp_heap_refill>:
    4220:	41 56                	push   %r14
    4222:	41 89 d6             	mov    %edx,%r14d
    4225:	41 55                	push   %r13
    4227:	41 89 f5             	mov    %esi,%r13d
    422a:	41 54                	push   %r12
    422c:	49 89 fc             	mov    %rdi,%r12
    422f:	bf 01 00 00 00       	mov    $0x1,%edi
    4234:	55                   	push   %rbp
    4235:	53                   	push   %rbx
    4236:	e8 65 eb ff ff       	call   2da0 <fwp_heap_chunks>
    423b:	48 89 c3             	mov    %rax,%rbx
    423e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4242:	48 8b 05 af c8 01 00 	mov    0x1c8af(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    4249:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    424d:	48 8d 05 ac b4 01 00 	lea    0x1b4ac(%rip),%rax        # 1f700 <fwp_heap>
    4254:	31 d2                	xor    %edx,%edx
    4256:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    425a:	48 89 ef             	mov    %rbp,%rdi
    425d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    4261:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    4265:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    426c:	00 
    426d:	b8 00 00 01 00       	mov    $0x10000,%eax
    4272:	f7 f1                	div    %ecx
    4274:	31 d2                	xor    %edx,%edx
    4276:	66 0f 6e c1          	movd   %ecx,%xmm0
    427a:	66 0f 6e c8          	movd   %eax,%xmm1
    427e:	89 c6                	mov    %eax,%esi
    4280:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4285:	48 01 c8             	add    %rcx,%rax
    4288:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    428c:	48 f7 f1             	div    %rcx
    428f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    4294:	89 45 18             	mov    %eax,0x18(%rbp)
    4297:	e8 84 fe ff ff       	call   4120 <fwp_rc_prepare_chunk>
    429c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    429f:	48 89 d8             	mov    %rbx,%rax
    42a2:	48 c1 e0 10          	shl    $0x10,%rax
    42a6:	48 03 05 03 c8 01 00 	add    0x1c803(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    42ad:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    42b1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    42b6:	8b 55 08             	mov    0x8(%rbp),%edx
    42b9:	48 0f af d1          	imul   %rcx,%rdx
    42bd:	48 01 c2             	add    %rax,%rdx
    42c0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    42c5:	5b                   	pop    %rbx
    42c6:	5d                   	pop    %rbp
    42c7:	41 5c                	pop    %r12
    42c9:	41 5d                	pop    %r13
    42cb:	41 5e                	pop    %r14
    42cd:	c3                   	ret
    42ce:	66 90                	xchg   %ax,%ax

00000000000042d0 <fwp_mem_free>:
    42d0:	48 85 ff             	test   %rdi,%rdi
    42d3:	0f 84 17 02 00 00    	je     44f0 <fwp_mem_free+0x220>
    42d9:	48 8b 35 d0 c7 01 00 	mov    0x1c7d0(%rip),%rsi        # 20ab0 <fwp_heap+0x13b0>
    42e0:	48 8b 05 f1 c7 01 00 	mov    0x1c7f1(%rip),%rax        # 20ad8 <fwp_heap+0x13d8>
    42e7:	48 89 fa             	mov    %rdi,%rdx
    42ea:	48 29 f2             	sub    %rsi,%rdx
    42ed:	48 c1 e0 10          	shl    $0x10,%rax
    42f1:	48 39 c2             	cmp    %rax,%rdx
    42f4:	0f 83 f6 01 00 00    	jae    44f0 <fwp_mem_free+0x220>
    42fa:	49 89 d1             	mov    %rdx,%r9
    42fd:	49 c1 e9 10          	shr    $0x10,%r9
    4301:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    4305:	48 c1 e0 03          	shl    $0x3,%rax
    4309:	49 89 c0             	mov    %rax,%r8
    430c:	4c 03 05 e5 c7 01 00 	add    0x1c7e5(%rip),%r8        # 20af8 <fwp_heap+0x13f8>
    4313:	0f 84 d7 01 00 00    	je     44f0 <fwp_mem_free+0x220>
    4319:	48 83 ec 38          	sub    $0x38,%rsp
    431d:	48 89 f9             	mov    %rdi,%rcx
    4320:	41 0f b6 38          	movzbl (%r8),%edi
    4324:	40 80 ff 01          	cmp    $0x1,%dil
    4328:	74 16                	je     4340 <fwp_mem_free+0x70>
    432a:	40 80 ff 02          	cmp    $0x2,%dil
    432e:	0f 84 94 00 00 00    	je     43c8 <fwp_mem_free+0xf8>
    4334:	48 83 c4 38          	add    $0x38,%rsp
    4338:	c3                   	ret
    4339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4340:	4d 8b 50 20          	mov    0x20(%r8),%r10
    4344:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    4349:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    434e:	41 8b 78 04          	mov    0x4(%r8),%edi
    4352:	4d 85 d2             	test   %r10,%r10
    4355:	74 1d                	je     4374 <fwp_mem_free+0xa4>
    4357:	0f b7 c1             	movzwl %cx,%eax
    435a:	31 d2                	xor    %edx,%edx
    435c:	48 f7 f7             	div    %rdi
    435f:	49 01 c2             	add    %rax,%r10
    4362:	41 80 3a ff          	cmpb   $0xff,(%r10)
    4366:	0f 84 44 01 00 00    	je     44b0 <fwp_mem_free+0x1e0>
    436c:	41 c6 02 00          	movb   $0x0,(%r10)
    4370:	41 8b 78 04          	mov    0x4(%r8),%edi
    4374:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    437b:	49 63 c1             	movslq %r9d,%rax
    437e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4382:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4386:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    438b:	f2 0f 58 05 ad c7 01 	addsd  0x1c7ad(%rip),%xmm0        # 20b40 <fwp_heap+0x1440>
    4392:	00 
    4393:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    4397:	48 8d 05 62 b3 01 00 	lea    0x1b362(%rip),%rax        # 1f700 <fwp_heap>
    439e:	48 01 d0             	add    %rdx,%rax
    43a1:	48 8b 10             	mov    (%rax),%rdx
    43a4:	48 f7 d2             	not    %rdx
    43a7:	48 89 11             	mov    %rdx,(%rcx)
    43aa:	48 89 08             	mov    %rcx,(%rax)
    43ad:	48 29 3d 6c c7 01 00 	sub    %rdi,0x1c76c(%rip)        # 20b20 <fwp_heap+0x1420>
    43b4:	f2 0f 11 05 84 c7 01 	movsd  %xmm0,0x1c784(%rip)        # 20b40 <fwp_heap+0x1440>
    43bb:	00 
    43bc:	48 83 c4 38          	add    $0x38,%rsp
    43c0:	c3                   	ret
    43c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    43c8:	66 31 d2             	xor    %dx,%dx
    43cb:	48 01 d6             	add    %rdx,%rsi
    43ce:	48 39 f1             	cmp    %rsi,%rcx
    43d1:	0f 85 5d ff ff ff    	jne    4334 <fwp_mem_free+0x64>
    43d7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    43db:	48 29 15 3e c7 01 00 	sub    %rdx,0x1c73e(%rip)        # 20b20 <fwp_heap+0x1420>
    43e2:	48 85 d2             	test   %rdx,%rdx
    43e5:	0f 88 a5 00 00 00    	js     4490 <fwp_mem_free+0x1c0>
    43eb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    43ef:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    43f4:	f2 0f 58 05 44 c7 01 	addsd  0x1c744(%rip),%xmm0        # 20b40 <fwp_heap+0x1440>
    43fb:	00 
    43fc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    4400:	f2 0f 11 05 38 c7 01 	movsd  %xmm0,0x1c738(%rip)        # 20b40 <fwp_heap+0x1440>
    4407:	00 
    4408:	48 85 d2             	test   %rdx,%rdx
    440b:	74 0c                	je     4419 <fwp_mem_free+0x149>
    440d:	80 3a ff             	cmpb   $0xff,(%rdx)
    4410:	0f 84 db 00 00 00    	je     44f1 <fwp_mem_free+0x221>
    4416:	c6 02 00             	movb   $0x0,(%rdx)
    4419:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    441d:	48 85 c9             	test   %rcx,%rcx
    4420:	74 3e                	je     4460 <fwp_mem_free+0x190>
    4422:	48 8b 15 cf c6 01 00 	mov    0x1c6cf(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    4429:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    442d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4431:	48 01 d0             	add    %rdx,%rax
    4434:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    4438:	48 89 d6             	mov    %rdx,%rsi
    443b:	48 29 c6             	sub    %rax,%rsi
    443e:	83 e6 08             	and    $0x8,%esi
    4441:	74 0d                	je     4450 <fwp_mem_free+0x180>
    4443:	c6 00 00             	movb   $0x0,(%rax)
    4446:	48 83 c0 28          	add    $0x28,%rax
    444a:	48 39 c2             	cmp    %rax,%rdx
    444d:	74 11                	je     4460 <fwp_mem_free+0x190>
    444f:	90                   	nop
    4450:	c6 00 00             	movb   $0x0,(%rax)
    4453:	48 83 c0 50          	add    $0x50,%rax
    4457:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    445b:	48 39 c2             	cmp    %rax,%rdx
    445e:	75 f0                	jne    4450 <fwp_mem_free+0x180>
    4460:	48 01 0d c9 c6 01 00 	add    %rcx,0x1c6c9(%rip)        # 20b30 <fwp_heap+0x1430>
    4467:	4c 3b 0d 82 c6 01 00 	cmp    0x1c682(%rip),%r9        # 20af0 <fwp_heap+0x13f0>
    446e:	73 07                	jae    4477 <fwp_mem_free+0x1a7>
    4470:	4c 89 0d 79 c6 01 00 	mov    %r9,0x1c679(%rip)        # 20af0 <fwp_heap+0x13f0>
    4477:	4c 3b 0d 6a c6 01 00 	cmp    0x1c66a(%rip),%r9        # 20ae8 <fwp_heap+0x13e8>
    447e:	0f 83 b0 fe ff ff    	jae    4334 <fwp_mem_free+0x64>
    4484:	4c 89 0d 5d c6 01 00 	mov    %r9,0x1c65d(%rip)        # 20ae8 <fwp_heap+0x13e8>
    448b:	e9 a4 fe ff ff       	jmp    4334 <fwp_mem_free+0x64>
    4490:	48 89 d1             	mov    %rdx,%rcx
    4493:	83 e2 01             	and    $0x1,%edx
    4496:	66 0f ef c0          	pxor   %xmm0,%xmm0
    449a:	48 d1 e9             	shr    $1,%rcx
    449d:	48 09 d1             	or     %rdx,%rcx
    44a0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    44a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    44a9:	e9 46 ff ff ff       	jmp    43f4 <fwp_mem_free+0x124>
    44ae:	66 90                	xchg   %ax,%ax
    44b0:	4c 89 d7             	mov    %r10,%rdi
    44b3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    44b8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    44bd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    44c2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    44c6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    44cb:	e8 c0 fb ff ff       	call   4090 <fwp_rc_forget_slot>
    44d0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    44d5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    44da:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    44df:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    44e4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    44e9:	e9 7e fe ff ff       	jmp    436c <fwp_mem_free+0x9c>
    44ee:	66 90                	xchg   %ax,%ax
    44f0:	c3                   	ret
    44f1:	48 89 d7             	mov    %rdx,%rdi
    44f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    44f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    44fe:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    4503:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4508:	e8 83 fb ff ff       	call   4090 <fwp_rc_forget_slot>
    450d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    4512:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    4517:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    451c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4521:	e9 f0 fe ff ff       	jmp    4416 <fwp_mem_free+0x146>
    4526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    452d:	00 00 00 

0000000000004530 <fwp_heap_alloc_big>:
    4530:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    4537:	00 00 40 
    453a:	41 57                	push   %r15
    453c:	41 56                	push   %r14
    453e:	41 55                	push   %r13
    4540:	41 54                	push   %r12
    4542:	55                   	push   %rbp
    4543:	53                   	push   %rbx
    4544:	48 83 ec 08          	sub    $0x8,%rsp
    4548:	48 39 f8             	cmp    %rdi,%rax
    454b:	0f 82 fa 00 00 00    	jb     464b <fwp_heap_alloc_big+0x11b>
    4551:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    4558:	49 89 fd             	mov    %rdi,%r13
    455b:	41 89 f6             	mov    %esi,%r14d
    455e:	48 c1 ed 10          	shr    $0x10,%rbp
    4562:	48 89 ef             	mov    %rbp,%rdi
    4565:	e8 36 e8 ff ff       	call   2da0 <fwp_heap_chunks>
    456a:	be 01 00 00 00       	mov    $0x1,%esi
    456f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    4573:	49 89 c4             	mov    %rax,%r12
    4576:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    457d:	00 
    457e:	48 03 3d 73 c5 01 00 	add    0x1c573(%rip),%rdi        # 20af8 <fwp_heap+0x13f8>
    4585:	c6 07 02             	movb   $0x2,(%rdi)
    4588:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    458c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    458f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    4593:	e8 88 fb ff ff       	call   4120 <fwp_rc_prepare_chunk>
    4598:	48 83 fd 01          	cmp    $0x1,%rbp
    459c:	76 47                	jbe    45e5 <fwp_heap_alloc_big+0xb5>
    459e:	4c 01 e5             	add    %r12,%rbp
    45a1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    45a8:	00 
    45a9:	4c 8d 3d 50 b1 01 00 	lea    0x1b150(%rip),%r15        # 1f700 <fwp_heap>
    45b0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    45b5:	49 c1 e6 03          	shl    $0x3,%r14
    45b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    45c0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    45c7:	31 f6                	xor    %esi,%esi
    45c9:	48 01 dd             	add    %rbx,%rbp
    45cc:	48 83 c3 28          	add    $0x28,%rbx
    45d0:	48 89 ef             	mov    %rbp,%rdi
    45d3:	e8 48 fb ff ff       	call   4120 <fwp_rc_prepare_chunk>
    45d8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    45dc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    45e0:	49 39 de             	cmp    %rbx,%r14
    45e3:	75 db                	jne    45c0 <fwp_heap_alloc_big+0x90>
    45e5:	49 c1 e4 10          	shl    $0x10,%r12
    45e9:	4c 03 25 c0 c4 01 00 	add    0x1c4c0(%rip),%r12        # 20ab0 <fwp_heap+0x13b0>
    45f0:	4c 89 ea             	mov    %r13,%rdx
    45f3:	31 f6                	xor    %esi,%esi
    45f5:	4c 89 e7             	mov    %r12,%rdi
    45f8:	e8 a3 de ff ff       	call   24a0 <memset@plt>
    45fd:	4c 89 e8             	mov    %r13,%rax
    4600:	48 03 05 19 c5 01 00 	add    0x1c519(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    4607:	72 42                	jb     464b <fwp_heap_alloc_big+0x11b>
    4609:	48 39 05 18 c5 01 00 	cmp    %rax,0x1c518(%rip)        # 20b28 <fwp_heap+0x1428>
    4610:	48 89 05 09 c5 01 00 	mov    %rax,0x1c509(%rip)        # 20b20 <fwp_heap+0x1420>
    4617:	73 07                	jae    4620 <fwp_heap_alloc_big+0xf0>
    4619:	48 89 05 08 c5 01 00 	mov    %rax,0x1c508(%rip)        # 20b28 <fwp_heap+0x1428>
    4620:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4624:	4c 89 e0             	mov    %r12,%rax
    4627:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    462c:	f2 0f 58 05 04 c5 01 	addsd  0x1c504(%rip),%xmm0        # 20b38 <fwp_heap+0x1438>
    4633:	00 
    4634:	f2 0f 11 05 fc c4 01 	movsd  %xmm0,0x1c4fc(%rip)        # 20b38 <fwp_heap+0x1438>
    463b:	00 
    463c:	48 83 c4 08          	add    $0x8,%rsp
    4640:	5b                   	pop    %rbx
    4641:	5d                   	pop    %rbp
    4642:	41 5c                	pop    %r12
    4644:	41 5d                	pop    %r13
    4646:	41 5e                	pop    %r14
    4648:	41 5f                	pop    %r15
    464a:	c3                   	ret
    464b:	e8 10 e7 ff ff       	call   2d60 <fwp_heap_oom>

0000000000004650 <fwp_heap_alloc_slow>:
    4650:	53                   	push   %rbx
    4651:	48 89 f9             	mov    %rdi,%rcx
    4654:	41 89 f1             	mov    %esi,%r9d
    4657:	48 83 ec 10          	sub    $0x10,%rsp
    465b:	8b 05 43 c4 01 00    	mov    0x1c443(%rip),%eax        # 20aa4 <fwp_heap+0x13a4>
    4661:	85 c0                	test   %eax,%eax
    4663:	0f 84 c7 00 00 00    	je     4730 <fwp_heap_alloc_slow+0xe0>
    4669:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    4670:	0f 87 dd 00 00 00    	ja     4753 <fwp_heap_alloc_slow+0x103>
    4676:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    467a:	48 8d 3d 7f b0 01 00 	lea    0x1b07f(%rip),%rdi        # 1f700 <fwp_heap>
    4681:	49 63 f1             	movslq %r9d,%rsi
    4684:	48 c1 e8 04          	shr    $0x4,%rax
    4688:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    468f:	00 00 
    4691:	41 0f b6 c2          	movzbl %r10b,%eax
    4695:	4c 89 d2             	mov    %r10,%rdx
    4698:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    469c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    46a3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    46aa:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    46ae:	48 01 f8             	add    %rdi,%rax
    46b1:	4c 8b 00             	mov    (%rax),%r8
    46b4:	4d 85 c0             	test   %r8,%r8
    46b7:	0f 84 ab 00 00 00    	je     4768 <fwp_heap_alloc_slow+0x118>
    46bd:	49 8b 10             	mov    (%r8),%rdx
    46c0:	48 f7 d2             	not    %rdx
    46c3:	48 89 10             	mov    %rdx,(%rax)
    46c6:	41 83 f9 01          	cmp    $0x1,%r9d
    46ca:	4c 89 c7             	mov    %r8,%rdi
    46cd:	48 0f 45 cb          	cmovne %rbx,%rcx
    46d1:	31 f6                	xor    %esi,%esi
    46d3:	48 89 ca             	mov    %rcx,%rdx
    46d6:	e8 c5 dd ff ff       	call   24a0 <memset@plt>
    46db:	49 89 c0             	mov    %rax,%r8
    46de:	48 89 d8             	mov    %rbx,%rax
    46e1:	48 03 05 38 c4 01 00 	add    0x1c438(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    46e8:	0f 82 d9 00 00 00    	jb     47c7 <fwp_heap_alloc_slow+0x177>
    46ee:	48 39 05 33 c4 01 00 	cmp    %rax,0x1c433(%rip)        # 20b28 <fwp_heap+0x1428>
    46f5:	48 89 05 24 c4 01 00 	mov    %rax,0x1c424(%rip)        # 20b20 <fwp_heap+0x1420>
    46fc:	73 07                	jae    4705 <fwp_heap_alloc_slow+0xb5>
    46fe:	48 89 05 23 c4 01 00 	mov    %rax,0x1c423(%rip)        # 20b28 <fwp_heap+0x1428>
    4705:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4709:	4c 89 c0             	mov    %r8,%rax
    470c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    4711:	f2 0f 58 05 1f c4 01 	addsd  0x1c41f(%rip),%xmm0        # 20b38 <fwp_heap+0x1438>
    4718:	00 
    4719:	f2 0f 11 05 17 c4 01 	movsd  %xmm0,0x1c417(%rip)        # 20b38 <fwp_heap+0x1438>
    4720:	00 
    4721:	48 83 c4 10          	add    $0x10,%rsp
    4725:	5b                   	pop    %rbx
    4726:	c3                   	ret
    4727:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    472e:	00 00 
    4730:	89 74 24 08          	mov    %esi,0x8(%rsp)
    4734:	48 89 3c 24          	mov    %rdi,(%rsp)
    4738:	e8 73 f2 ff ff       	call   39b0 <fwp_heap_init>
    473d:	48 8b 0c 24          	mov    (%rsp),%rcx
    4741:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    4746:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    474d:	0f 86 23 ff ff ff    	jbe    4676 <fwp_heap_alloc_slow+0x26>
    4753:	48 83 c4 10          	add    $0x10,%rsp
    4757:	44 89 ce             	mov    %r9d,%esi
    475a:	48 89 cf             	mov    %rcx,%rdi
    475d:	5b                   	pop    %rbx
    475e:	e9 cd fd ff ff       	jmp    4530 <fwp_heap_alloc_big>
    4763:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4768:	4c 8b 40 08          	mov    0x8(%rax),%r8
    476c:	4d 85 c0             	test   %r8,%r8
    476f:	74 1f                	je     4790 <fwp_heap_alloc_slow+0x140>
    4771:	4c 8b 58 10          	mov    0x10(%rax),%r11
    4775:	4d 29 c3             	sub    %r8,%r11
    4778:	49 39 db             	cmp    %rbx,%r11
    477b:	72 13                	jb     4790 <fwp_heap_alloc_slow+0x140>
    477d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    4781:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4785:	e9 3c ff ff ff       	jmp    46c6 <fwp_heap_alloc_slow+0x76>
    478a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4790:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    4797:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    479b:	44 89 ca             	mov    %r9d,%edx
    479e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    47a3:	44 89 0c 24          	mov    %r9d,(%rsp)
    47a7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    47ab:	44 89 d6             	mov    %r10d,%esi
    47ae:	48 01 c7             	add    %rax,%rdi
    47b1:	e8 6a fa ff ff       	call   4220 <fwp_heap_refill>
    47b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    47bb:	44 8b 0c 24          	mov    (%rsp),%r9d
    47bf:	49 89 c0             	mov    %rax,%r8
    47c2:	e9 ff fe ff ff       	jmp    46c6 <fwp_heap_alloc_slow+0x76>
    47c7:	e8 94 e5 ff ff       	call   2d60 <fwp_heap_oom>
    47cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000047d0 <fwp_rc_share>:
    47d0:	48 8b 05 01 c3 01 00 	mov    0x1c301(%rip),%rax        # 20ad8 <fwp_heap+0x13d8>
    47d7:	48 2b 3d d2 c2 01 00 	sub    0x1c2d2(%rip),%rdi        # 20ab0 <fwp_heap+0x13b0>
    47de:	48 c1 e0 10          	shl    $0x10,%rax
    47e2:	48 39 c7             	cmp    %rax,%rdi
    47e5:	73 4a                	jae    4831 <fwp_rc_share+0x61>
    47e7:	48 89 f8             	mov    %rdi,%rax
    47ea:	48 c1 e8 10          	shr    $0x10,%rax
    47ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    47f2:	48 8b 05 ff c2 01 00 	mov    0x1c2ff(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    47f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    47fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    4801:	48 85 d2             	test   %rdx,%rdx
    4804:	74 2b                	je     4831 <fwp_rc_share+0x61>
    4806:	0f b6 08             	movzbl (%rax),%ecx
    4809:	80 f9 02             	cmp    $0x2,%cl
    480c:	74 2a                	je     4838 <fwp_rc_share+0x68>
    480e:	80 f9 01             	cmp    $0x1,%cl
    4811:	75 1e                	jne    4831 <fwp_rc_share+0x61>
    4813:	8b 48 18             	mov    0x18(%rax),%ecx
    4816:	0f b7 ff             	movzwl %di,%edi
    4819:	8b 40 1c             	mov    0x1c(%rax),%eax
    481c:	48 0f af f9          	imul   %rcx,%rdi
    4820:	48 c1 ef 20          	shr    $0x20,%rdi
    4824:	48 39 c7             	cmp    %rax,%rdi
    4827:	73 08                	jae    4831 <fwp_rc_share+0x61>
    4829:	48 01 fa             	add    %rdi,%rdx
    482c:	80 3a 00             	cmpb   $0x0,(%rdx)
    482f:	75 0d                	jne    483e <fwp_rc_share+0x6e>
    4831:	c3                   	ret
    4832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4838:	66 85 ff             	test   %di,%di
    483b:	74 ef                	je     482c <fwp_rc_share+0x5c>
    483d:	c3                   	ret
    483e:	50                   	push   %rax
    483f:	48 8d 3d aa 7b 00 00 	lea    0x7baa(%rip),%rdi        # c3f0 <_IO_stdin_used+0x3f0>
    4846:	e8 25 ea ff ff       	call   3270 <fwp_trap>
    484b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000004850 <e69>:
    4850:	f3 0f 1e fa          	endbr64
    4854:	53                   	push   %rbx
    4855:	f2 0f 10 05 93 7d 00 	movsd  0x7d93(%rip),%xmm0        # c5f0 <msg.3+0x20>
    485c:	00 
    485d:	f2 0f 59 07          	mulsd  (%rdi),%xmm0
    4861:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4866:	48 89 df             	mov    %rbx,%rdi
    4869:	e8 62 ff ff ff       	call   47d0 <fwp_rc_share>
    486e:	48 89 d8             	mov    %rbx,%rax
    4871:	5b                   	pop    %rbx
    4872:	c3                   	ret
    4873:	66 90                	xchg   %ax,%ax
    4875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    487c:	00 00 00 00 

0000000000004880 <e45>:
    4880:	f3 0f 1e fa          	endbr64
    4884:	53                   	push   %rbx
    4885:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4889:	f2 0f 58 47 08       	addsd  0x8(%rdi),%xmm0
    488e:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    4893:	48 89 df             	mov    %rbx,%rdi
    4896:	e8 35 ff ff ff       	call   47d0 <fwp_rc_share>
    489b:	48 89 d8             	mov    %rbx,%rax
    489e:	5b                   	pop    %rbx
    489f:	c3                   	ret

00000000000048a0 <e32>:
    48a0:	f3 0f 1e fa          	endbr64
    48a4:	53                   	push   %rbx
    48a5:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    48aa:	f2 0f 5c 07          	subsd  (%rdi),%xmm0
    48ae:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    48b3:	48 89 df             	mov    %rbx,%rdi
    48b6:	e8 15 ff ff ff       	call   47d0 <fwp_rc_share>
    48bb:	48 89 d8             	mov    %rbx,%rax
    48be:	5b                   	pop    %rbx
    48bf:	c3                   	ret

00000000000048c0 <fwp_rc_fresh>:
    48c0:	48 8b 15 11 c2 01 00 	mov    0x1c211(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    48c7:	48 89 f8             	mov    %rdi,%rax
    48ca:	48 89 fe             	mov    %rdi,%rsi
    48cd:	48 2b 05 dc c1 01 00 	sub    0x1c1dc(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    48d4:	48 c1 e2 10          	shl    $0x10,%rdx
    48d8:	48 39 d0             	cmp    %rdx,%rax
    48db:	73 4f                	jae    492c <fwp_rc_fresh+0x6c>
    48dd:	48 89 c2             	mov    %rax,%rdx
    48e0:	48 c1 ea 10          	shr    $0x10,%rdx
    48e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    48e8:	48 8b 15 09 c2 01 00 	mov    0x1c209(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    48ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    48f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    48f7:	48 85 d2             	test   %rdx,%rdx
    48fa:	74 30                	je     492c <fwp_rc_fresh+0x6c>
    48fc:	0f b6 39             	movzbl (%rcx),%edi
    48ff:	40 80 ff 02          	cmp    $0x2,%dil
    4903:	74 2b                	je     4930 <fwp_rc_fresh+0x70>
    4905:	40 80 ff 01          	cmp    $0x1,%dil
    4909:	75 21                	jne    492c <fwp_rc_fresh+0x6c>
    490b:	8b 79 18             	mov    0x18(%rcx),%edi
    490e:	0f b7 c0             	movzwl %ax,%eax
    4911:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    4914:	48 0f af c7          	imul   %rdi,%rax
    4918:	48 c1 e8 20          	shr    $0x20,%rax
    491c:	48 39 c8             	cmp    %rcx,%rax
    491f:	73 0b                	jae    492c <fwp_rc_fresh+0x6c>
    4921:	48 01 c2             	add    %rax,%rdx
    4924:	80 3a ff             	cmpb   $0xff,(%rdx)
    4927:	74 17                	je     4940 <fwp_rc_fresh+0x80>
    4929:	c6 02 01             	movb   $0x1,(%rdx)
    492c:	48 89 f0             	mov    %rsi,%rax
    492f:	c3                   	ret
    4930:	66 85 c0             	test   %ax,%ax
    4933:	74 ef                	je     4924 <fwp_rc_fresh+0x64>
    4935:	48 89 f0             	mov    %rsi,%rax
    4938:	c3                   	ret
    4939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4940:	48 83 ec 18          	sub    $0x18,%rsp
    4944:	48 89 d7             	mov    %rdx,%rdi
    4947:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    494c:	48 89 14 24          	mov    %rdx,(%rsp)
    4950:	e8 3b f7 ff ff       	call   4090 <fwp_rc_forget_slot>
    4955:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    495a:	48 8b 14 24          	mov    (%rsp),%rdx
    495e:	48 89 f0             	mov    %rsi,%rax
    4961:	c6 02 01             	movb   $0x1,(%rdx)
    4964:	48 83 c4 18          	add    $0x18,%rsp
    4968:	c3                   	ret
    4969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004970 <fwp_rc_dup>:
    4970:	f3 0f 1e fa          	endbr64
    4974:	48 8b 05 5d c1 01 00 	mov    0x1c15d(%rip),%rax        # 20ad8 <fwp_heap+0x13d8>
    497b:	48 2b 3d 2e c1 01 00 	sub    0x1c12e(%rip),%rdi        # 20ab0 <fwp_heap+0x13b0>
    4982:	48 c1 e0 10          	shl    $0x10,%rax
    4986:	48 39 c7             	cmp    %rax,%rdi
    4989:	73 60                	jae    49eb <fwp_rc_dup+0x7b>
    498b:	48 89 f8             	mov    %rdi,%rax
    498e:	48 c1 e8 10          	shr    $0x10,%rax
    4992:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    4996:	48 8b 05 5b c1 01 00 	mov    0x1c15b(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    499d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    49a1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    49a5:	48 85 c0             	test   %rax,%rax
    49a8:	74 41                	je     49eb <fwp_rc_dup+0x7b>
    49aa:	0f b6 0a             	movzbl (%rdx),%ecx
    49ad:	80 f9 02             	cmp    $0x2,%cl
    49b0:	74 3e                	je     49f0 <fwp_rc_dup+0x80>
    49b2:	80 f9 01             	cmp    $0x1,%cl
    49b5:	75 34                	jne    49eb <fwp_rc_dup+0x7b>
    49b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    49ba:	0f b7 ff             	movzwl %di,%edi
    49bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    49c0:	48 0f af f9          	imul   %rcx,%rdi
    49c4:	48 c1 ef 20          	shr    $0x20,%rdi
    49c8:	48 39 d7             	cmp    %rdx,%rdi
    49cb:	73 1e                	jae    49eb <fwp_rc_dup+0x7b>
    49cd:	48 01 f8             	add    %rdi,%rax
    49d0:	0f b6 10             	movzbl (%rax),%edx
    49d3:	84 d2                	test   %dl,%dl
    49d5:	74 14                	je     49eb <fwp_rc_dup+0x7b>
    49d7:	8b 0d e3 c9 01 00    	mov    0x1c9e3(%rip),%ecx        # 213c0 <iteration_active>
    49dd:	85 c9                	test   %ecx,%ecx
    49df:	75 1f                	jne    4a00 <fwp_rc_dup+0x90>
    49e1:	80 fa fd             	cmp    $0xfd,%dl
    49e4:	77 2a                	ja     4a10 <fwp_rc_dup+0xa0>
    49e6:	83 c2 01             	add    $0x1,%edx
    49e9:	88 10                	mov    %dl,(%rax)
    49eb:	c3                   	ret
    49ec:	0f 1f 40 00          	nopl   0x0(%rax)
    49f0:	66 85 ff             	test   %di,%di
    49f3:	74 db                	je     49d0 <fwp_rc_dup+0x60>
    49f5:	c3                   	ret
    49f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    49fd:	00 00 00 
    4a00:	48 83 05 a0 c9 01 00 	addq   $0x1,0x1c9a0(%rip)        # 213a8 <iteration_retains>
    4a07:	01 
    4a08:	eb d7                	jmp    49e1 <fwp_rc_dup+0x71>
    4a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a10:	48 89 c7             	mov    %rax,%rdi
    4a13:	e9 58 f5 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_task_dispose>:
    4a20:	53                   	push   %rbx
    4a21:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4a25:	0f 84 db dc ff ff    	je     2706 <fwp_task_dispose.cold>
    4a2b:	48 89 fb             	mov    %rdi,%rbx
    4a2e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    4a33:	0f 85 cd dc ff ff    	jne    2706 <fwp_task_dispose.cold>
    4a39:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    4a3d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    4a44:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    4a4b:	00 
    4a4c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    4a50:	48 85 ff             	test   %rdi,%rdi
    4a53:	74 07                	je     4a5c <fwp_task_dispose+0x3c>
    4a55:	48 85 c0             	test   %rax,%rax
    4a58:	74 02                	je     4a5c <fwp_task_dispose+0x3c>
    4a5a:	ff d0                	call   *%rax
    4a5c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    4a63:	e8 68 f8 ff ff       	call   42d0 <fwp_mem_free>
    4a68:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    4a6f:	00 00 00 00 
    4a73:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    4a77:	74 6f                	je     4ae8 <fwp_task_dispose+0xc8>
    4a79:	48 8b 15 58 c0 01 00 	mov    0x1c058(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    4a80:	48 89 d8             	mov    %rbx,%rax
    4a83:	48 2b 05 26 c0 01 00 	sub    0x1c026(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    4a8a:	48 c1 e2 10          	shl    $0x10,%rdx
    4a8e:	48 39 d0             	cmp    %rdx,%rax
    4a91:	73 4c                	jae    4adf <fwp_task_dispose+0xbf>
    4a93:	48 89 c2             	mov    %rax,%rdx
    4a96:	48 c1 ea 10          	shr    $0x10,%rdx
    4a9a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4a9e:	48 8b 15 53 c0 01 00 	mov    0x1c053(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    4aa5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4aa9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4aad:	48 85 c9             	test   %rcx,%rcx
    4ab0:	74 2d                	je     4adf <fwp_task_dispose+0xbf>
    4ab2:	0f b6 32             	movzbl (%rdx),%esi
    4ab5:	40 80 fe 02          	cmp    $0x2,%sil
    4ab9:	74 3d                	je     4af8 <fwp_task_dispose+0xd8>
    4abb:	40 80 fe 01          	cmp    $0x1,%sil
    4abf:	75 1e                	jne    4adf <fwp_task_dispose+0xbf>
    4ac1:	8b 72 18             	mov    0x18(%rdx),%esi
    4ac4:	0f b7 c0             	movzwl %ax,%eax
    4ac7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4aca:	48 0f af c6          	imul   %rsi,%rax
    4ace:	48 c1 e8 20          	shr    $0x20,%rax
    4ad2:	48 39 d0             	cmp    %rdx,%rax
    4ad5:	73 08                	jae    4adf <fwp_task_dispose+0xbf>
    4ad7:	48 01 c1             	add    %rax,%rcx
    4ada:	80 39 01             	cmpb   $0x1,(%rcx)
    4add:	74 09                	je     4ae8 <fwp_task_dispose+0xc8>
    4adf:	5b                   	pop    %rbx
    4ae0:	c3                   	ret
    4ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ae8:	48 89 df             	mov    %rbx,%rdi
    4aeb:	5b                   	pop    %rbx
    4aec:	e9 df f7 ff ff       	jmp    42d0 <fwp_mem_free>
    4af1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4af8:	66 85 c0             	test   %ax,%ax
    4afb:	74 dd                	je     4ada <fwp_task_dispose+0xba>
    4afd:	5b                   	pop    %rbx
    4afe:	c3                   	ret
    4aff:	90                   	nop

0000000000004b00 <fwp_free_zombie>:
    4b00:	48 8b 15 c9 ab 01 00 	mov    0x1abc9(%rip),%rdx        # 1f6d0 <fwp_zombie>
    4b07:	48 85 d2             	test   %rdx,%rdx
    4b0a:	0f 84 98 00 00 00    	je     4ba8 <fwp_free_zombie+0xa8>
    4b10:	48 3b 15 c9 ab 01 00 	cmp    0x1abc9(%rip),%rdx        # 1f6e0 <fwp_cur>
    4b17:	0f 84 8b 00 00 00    	je     4ba8 <fwp_free_zombie+0xa8>
    4b1d:	48 83 ec 18          	sub    $0x18,%rsp
    4b21:	48 63 05 7c a5 01 00 	movslq 0x1a57c(%rip),%rax        # 1f0a4 <fwp_stack_pool_n>
    4b28:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    4b2c:	83 f8 3f             	cmp    $0x3f,%eax
    4b2f:	7f 7f                	jg     4bb0 <fwp_free_zombie+0xb0>
    4b31:	8d 48 01             	lea    0x1(%rax),%ecx
    4b34:	89 0d 6a a5 01 00    	mov    %ecx,0x1a56a(%rip)        # 1f0a4 <fwp_stack_pool_n>
    4b3a:	48 8d 0d 7f a5 01 00 	lea    0x1a57f(%rip),%rcx        # 1f0c0 <fwp_stack_pool>
    4b41:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    4b45:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    4b4c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4b50:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    4b57:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    4b5b:	48 85 c9             	test   %rcx,%rcx
    4b5e:	0f 84 fc 00 00 00    	je     4c60 <fwp_free_zombie+0x160>
    4b64:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    4b6b:	48 85 c0             	test   %rax,%rax
    4b6e:	74 07                	je     4b77 <fwp_free_zombie+0x77>
    4b70:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    4b77:	8b 42 5c             	mov    0x5c(%rdx),%eax
    4b7a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4b7e:	48 c7 05 47 ab 01 00 	movq   $0x0,0x1ab47(%rip)        # 1f6d0 <fwp_zombie>
    4b85:	00 00 00 00 
    4b89:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    4b90:	85 c0                	test   %eax,%eax
    4b92:	74 34                	je     4bc8 <fwp_free_zombie+0xc8>
    4b94:	83 f8 01             	cmp    $0x1,%eax
    4b97:	0f 84 b3 00 00 00    	je     4c50 <fwp_free_zombie+0x150>
    4b9d:	48 83 c4 18          	add    $0x18,%rsp
    4ba1:	c3                   	ret
    4ba2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ba8:	c3                   	ret
    4ba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4bb0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    4bb4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4bb9:	e8 f2 d9 ff ff       	call   25b0 <munmap@plt>
    4bbe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4bc3:	eb 80                	jmp    4b45 <fwp_free_zombie+0x45>
    4bc5:	0f 1f 00             	nopl   (%rax)
    4bc8:	48 8b 0d 09 bf 01 00 	mov    0x1bf09(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    4bcf:	48 89 d0             	mov    %rdx,%rax
    4bd2:	48 2b 05 d7 be 01 00 	sub    0x1bed7(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    4bd9:	48 c1 e1 10          	shl    $0x10,%rcx
    4bdd:	48 39 c8             	cmp    %rcx,%rax
    4be0:	73 bb                	jae    4b9d <fwp_free_zombie+0x9d>
    4be2:	48 89 c1             	mov    %rax,%rcx
    4be5:	48 c1 e9 10          	shr    $0x10,%rcx
    4be9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    4bed:	48 8b 0d 04 bf 01 00 	mov    0x1bf04(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    4bf4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    4bf8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    4bfc:	48 85 c9             	test   %rcx,%rcx
    4bff:	74 9c                	je     4b9d <fwp_free_zombie+0x9d>
    4c01:	0f b6 3e             	movzbl (%rsi),%edi
    4c04:	40 80 ff 02          	cmp    $0x2,%dil
    4c08:	74 66                	je     4c70 <fwp_free_zombie+0x170>
    4c0a:	40 80 ff 01          	cmp    $0x1,%dil
    4c0e:	75 8d                	jne    4b9d <fwp_free_zombie+0x9d>
    4c10:	8b 7e 18             	mov    0x18(%rsi),%edi
    4c13:	0f b7 c0             	movzwl %ax,%eax
    4c16:	8b 76 1c             	mov    0x1c(%rsi),%esi
    4c19:	48 0f af c7          	imul   %rdi,%rax
    4c1d:	48 c1 e8 20          	shr    $0x20,%rax
    4c21:	48 39 f0             	cmp    %rsi,%rax
    4c24:	0f 83 73 ff ff ff    	jae    4b9d <fwp_free_zombie+0x9d>
    4c2a:	48 01 c1             	add    %rax,%rcx
    4c2d:	0f b6 01             	movzbl (%rcx),%eax
    4c30:	84 c0                	test   %al,%al
    4c32:	0f 84 65 ff ff ff    	je     4b9d <fwp_free_zombie+0x9d>
    4c38:	3c 01                	cmp    $0x1,%al
    4c3a:	74 14                	je     4c50 <fwp_free_zombie+0x150>
    4c3c:	3c ff                	cmp    $0xff,%al
    4c3e:	74 3b                	je     4c7b <fwp_free_zombie+0x17b>
    4c40:	83 e8 01             	sub    $0x1,%eax
    4c43:	88 01                	mov    %al,(%rcx)
    4c45:	e9 53 ff ff ff       	jmp    4b9d <fwp_free_zombie+0x9d>
    4c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4c50:	48 89 d7             	mov    %rdx,%rdi
    4c53:	48 83 c4 18          	add    $0x18,%rsp
    4c57:	e9 c4 fd ff ff       	jmp    4a20 <fwp_task_dispose>
    4c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    4c60:	48 89 05 41 aa 01 00 	mov    %rax,0x1aa41(%rip)        # 1f6a8 <fwp_tasks_active>
    4c67:	e9 ff fe ff ff       	jmp    4b6b <fwp_free_zombie+0x6b>
    4c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    4c70:	66 85 c0             	test   %ax,%ax
    4c73:	0f 85 24 ff ff ff    	jne    4b9d <fwp_free_zombie+0x9d>
    4c79:	eb b2                	jmp    4c2d <fwp_free_zombie+0x12d>
    4c7b:	48 89 ca             	mov    %rcx,%rdx
    4c7e:	48 8d 35 7b aa 01 00 	lea    0x1aa7b(%rip),%rsi        # 1f700 <fwp_heap>
    4c85:	48 c1 ea 11          	shr    $0x11,%rdx
    4c89:	48 31 ca             	xor    %rcx,%rdx
    4c8c:	48 89 d0             	mov    %rdx,%rax
    4c8f:	48 c1 e8 09          	shr    $0x9,%rax
    4c93:	48 31 c2             	xor    %rax,%rdx
    4c96:	0f b6 d2             	movzbl %dl,%edx
    4c99:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    4ca0:	00 
    4ca1:	48 85 c0             	test   %rax,%rax
    4ca4:	75 23                	jne    4cc9 <fwp_free_zombie+0x1c9>
    4ca6:	eb 5c                	jmp    4d04 <fwp_free_zombie+0x204>
    4ca8:	66 90                	xchg   %ax,%ax
    4caa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4cb1:	00 00 00 00 
    4cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4cbc:	00 00 00 00 
    4cc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    4cc4:	48 85 c0             	test   %rax,%rax
    4cc7:	74 3b                	je     4d04 <fwp_free_zombie+0x204>
    4cc9:	48 89 c2             	mov    %rax,%rdx
    4ccc:	48 39 08             	cmp    %rcx,(%rax)
    4ccf:	75 ef                	jne    4cc0 <fwp_free_zombie+0x1c0>
    4cd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4cd5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    4cd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    4cdd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    4ce4:	0f 85 b3 fe ff ff    	jne    4b9d <fwp_free_zombie+0x9d>
    4cea:	48 89 cf             	mov    %rcx,%rdi
    4ced:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4cf2:	e8 99 f3 ff ff       	call   4090 <fwp_rc_forget_slot>
    4cf7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4cfc:	c6 01 fe             	movb   $0xfe,(%rcx)
    4cff:	e9 99 fe ff ff       	jmp    4b9d <fwp_free_zombie+0x9d>
    4d04:	48 8d 3d bd 76 00 00 	lea    0x76bd(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    4d0b:	e8 60 e5 ff ff       	call   3270 <fwp_trap>

0000000000004d10 <fwp_block>:
    4d10:	48 83 ec 08          	sub    $0x8,%rsp
    4d14:	48 8b 05 ad a9 01 00 	mov    0x1a9ad(%rip),%rax        # 1f6c8 <fwp_ready_head>
    4d1b:	48 85 c0             	test   %rax,%rax
    4d1e:	0f 84 1c 01 00 00    	je     4e40 <fwp_block+0x130>
    4d24:	90                   	nop
    4d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4d2c:	00 00 00 00 
    4d30:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    4d37:	48 89 15 8a a9 01 00 	mov    %rdx,0x1a98a(%rip)        # 1f6c8 <fwp_ready_head>
    4d3e:	48 85 d2             	test   %rdx,%rdx
    4d41:	0f 84 19 01 00 00    	je     4e60 <fwp_block+0x150>
    4d47:	48 8b 15 92 a9 01 00 	mov    0x1a992(%rip),%rdx        # 1f6e0 <fwp_cur>
    4d4e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    4d52:	48 39 c2             	cmp    %rax,%rdx
    4d55:	0f 84 d5 00 00 00    	je     4e30 <fwp_block+0x120>
    4d5b:	48 8b 0d fe c5 01 00 	mov    0x1c5fe(%rip),%rcx        # 21360 <fwp_state_owners>
    4d62:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    4d66:	48 89 05 73 a9 01 00 	mov    %rax,0x1a973(%rip)        # 1f6e0 <fwp_cur>
    4d6d:	f3 0f 7e 05 13 c6 01 	movq   0x1c613(%rip),%xmm0        # 21388 <fwp_foreign_callbacks>
    4d74:	00 
    4d75:	0f 16 05 fc c5 01 00 	movhps 0x1c5fc(%rip),%xmm0        # 21378 <fwp_state>
    4d7c:	f3 0f 7e 0d fc c5 01 	movq   0x1c5fc(%rip),%xmm1        # 21380 <fwp_handlers>
    4d83:	00 
    4d84:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    4d8b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    4d92:	0f 16 0d f7 c5 01 00 	movhps 0x1c5f7(%rip),%xmm1        # 21390 <fwp_cleanups>
    4d99:	f3 0f 7e 05 cf c5 01 	movq   0x1c5cf(%rip),%xmm0        # 21370 <fwp_state_len>
    4da0:	00 
    4da1:	0f 16 05 c0 c5 01 00 	movhps 0x1c5c0(%rip),%xmm0        # 21368 <fwp_state_cap>
    4da8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    4daf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    4db6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    4dba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    4dc1:	48 89 0d b8 c5 01 00 	mov    %rcx,0x1c5b8(%rip)        # 21380 <fwp_handlers>
    4dc8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    4dcf:	48 89 0d ba c5 01 00 	mov    %rcx,0x1c5ba(%rip)        # 21390 <fwp_cleanups>
    4dd6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    4ddd:	48 89 0d a4 c5 01 00 	mov    %rcx,0x1c5a4(%rip)        # 21388 <fwp_foreign_callbacks>
    4de4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    4deb:	48 89 0d 86 c5 01 00 	mov    %rcx,0x1c586(%rip)        # 21378 <fwp_state>
    4df2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    4df9:	48 89 0d 70 c5 01 00 	mov    %rcx,0x1c570(%rip)        # 21370 <fwp_state_len>
    4e00:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    4e07:	48 89 0d 5a c5 01 00 	mov    %rcx,0x1c55a(%rip)        # 21368 <fwp_state_cap>
    4e0e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    4e15:	48 89 0d 44 c5 01 00 	mov    %rcx,0x1c544(%rip)        # 21360 <fwp_state_owners>
    4e1c:	e8 4f d6 ff ff       	call   2470 <swapcontext@plt>
    4e21:	f3 0f 1e fa          	endbr64
    4e25:	e8 d6 fc ff ff       	call   4b00 <fwp_free_zombie>
    4e2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e30:	8b 05 6a a2 01 00    	mov    0x1a26a(%rip),%eax        # 1f0a0 <fwp_slice>
    4e36:	85 c0                	test   %eax,%eax
    4e38:	74 36                	je     4e70 <fwp_block+0x160>
    4e3a:	48 83 c4 08          	add    $0x8,%rsp
    4e3e:	c3                   	ret
    4e3f:	90                   	nop
    4e40:	e8 8b ee ff ff       	call   3cd0 <fwp_poll_events>
    4e45:	48 8b 05 7c a8 01 00 	mov    0x1a87c(%rip),%rax        # 1f6c8 <fwp_ready_head>
    4e4c:	48 85 c0             	test   %rax,%rax
    4e4f:	0f 85 db fe ff ff    	jne    4d30 <fwp_block+0x20>
    4e55:	eb e9                	jmp    4e40 <fwp_block+0x130>
    4e57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    4e5e:	00 00 
    4e60:	48 c7 05 55 a8 01 00 	movq   $0x0,0x1a855(%rip)        # 1f6c0 <fwp_ready_tail>
    4e67:	00 00 00 00 
    4e6b:	e9 d7 fe ff ff       	jmp    4d47 <fwp_block+0x37>
    4e70:	48 8d 3d 87 72 00 00 	lea    0x7287(%rip),%rdi        # c0fe <_IO_stdin_used+0xfe>
    4e77:	e8 04 d5 ff ff       	call   2380 <getenv@plt>
    4e7c:	ba 10 27 00 00       	mov    $0x2710,%edx
    4e81:	48 85 c0             	test   %rax,%rax
    4e84:	74 05                	je     4e8b <fwp_block+0x17b>
    4e86:	80 38 00             	cmpb   $0x0,(%rax)
    4e89:	75 0b                	jne    4e96 <fwp_block+0x186>
    4e8b:	89 15 0f a2 01 00    	mov    %edx,0x1a20f(%rip)        # 1f0a0 <fwp_slice>
    4e91:	48 83 c4 08          	add    $0x8,%rsp
    4e95:	c3                   	ret
    4e96:	ba 0a 00 00 00       	mov    $0xa,%edx
    4e9b:	31 f6                	xor    %esi,%esi
    4e9d:	48 89 c7             	mov    %rax,%rdi
    4ea0:	e8 8b d6 ff ff       	call   2530 <strtoll@plt>
    4ea5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4ea9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    4eb0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    4eb5:	0f 46 d0             	cmovbe %eax,%edx
    4eb8:	eb d1                	jmp    4e8b <fwp_block+0x17b>
    4eba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004ec0 <fwp_caps32>:
    4ec0:	f3 0f 1e fa          	endbr64
    4ec4:	85 f6                	test   %esi,%esi
    4ec6:	74 08                	je     4ed0 <fwp_caps32+0x10>
    4ec8:	c3                   	ret
    4ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ed0:	48 8b 15 01 bc 01 00 	mov    0x1bc01(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    4ed7:	48 89 f8             	mov    %rdi,%rax
    4eda:	48 2b 05 cf bb 01 00 	sub    0x1bbcf(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    4ee1:	48 c1 e2 10          	shl    $0x10,%rdx
    4ee5:	48 39 d0             	cmp    %rdx,%rax
    4ee8:	73 de                	jae    4ec8 <fwp_caps32+0x8>
    4eea:	48 89 c2             	mov    %rax,%rdx
    4eed:	48 c1 ea 10          	shr    $0x10,%rdx
    4ef1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4ef5:	48 8b 15 fc bb 01 00 	mov    0x1bbfc(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    4efc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f00:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f04:	48 85 c9             	test   %rcx,%rcx
    4f07:	74 bf                	je     4ec8 <fwp_caps32+0x8>
    4f09:	0f b6 32             	movzbl (%rdx),%esi
    4f0c:	40 80 fe 02          	cmp    $0x2,%sil
    4f10:	74 2e                	je     4f40 <fwp_caps32+0x80>
    4f12:	40 80 fe 01          	cmp    $0x1,%sil
    4f16:	75 b0                	jne    4ec8 <fwp_caps32+0x8>
    4f18:	8b 72 18             	mov    0x18(%rdx),%esi
    4f1b:	0f b7 c0             	movzwl %ax,%eax
    4f1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4f21:	48 0f af c6          	imul   %rsi,%rax
    4f25:	48 c1 e8 20          	shr    $0x20,%rax
    4f29:	48 39 d0             	cmp    %rdx,%rax
    4f2c:	73 9a                	jae    4ec8 <fwp_caps32+0x8>
    4f2e:	48 01 c1             	add    %rax,%rcx
    4f31:	80 39 01             	cmpb   $0x1,(%rcx)
    4f34:	75 92                	jne    4ec8 <fwp_caps32+0x8>
    4f36:	e9 95 f3 ff ff       	jmp    42d0 <fwp_mem_free>
    4f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f40:	66 85 c0             	test   %ax,%ax
    4f43:	74 ec                	je     4f31 <fwp_caps32+0x71>
    4f45:	c3                   	ret
    4f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f4d:	00 00 00 

0000000000004f50 <fwp_caps45>:
    4f50:	f3 0f 1e fa          	endbr64
    4f54:	85 f6                	test   %esi,%esi
    4f56:	74 08                	je     4f60 <fwp_caps45+0x10>
    4f58:	c3                   	ret
    4f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f60:	48 8b 15 71 bb 01 00 	mov    0x1bb71(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    4f67:	48 89 f8             	mov    %rdi,%rax
    4f6a:	48 2b 05 3f bb 01 00 	sub    0x1bb3f(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    4f71:	48 c1 e2 10          	shl    $0x10,%rdx
    4f75:	48 39 d0             	cmp    %rdx,%rax
    4f78:	73 de                	jae    4f58 <fwp_caps45+0x8>
    4f7a:	48 89 c2             	mov    %rax,%rdx
    4f7d:	48 c1 ea 10          	shr    $0x10,%rdx
    4f81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    4f85:	48 8b 15 6c bb 01 00 	mov    0x1bb6c(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    4f8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    4f90:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    4f94:	48 85 c9             	test   %rcx,%rcx
    4f97:	74 bf                	je     4f58 <fwp_caps45+0x8>
    4f99:	0f b6 32             	movzbl (%rdx),%esi
    4f9c:	40 80 fe 02          	cmp    $0x2,%sil
    4fa0:	74 2e                	je     4fd0 <fwp_caps45+0x80>
    4fa2:	40 80 fe 01          	cmp    $0x1,%sil
    4fa6:	75 b0                	jne    4f58 <fwp_caps45+0x8>
    4fa8:	8b 72 18             	mov    0x18(%rdx),%esi
    4fab:	0f b7 c0             	movzwl %ax,%eax
    4fae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    4fb1:	48 0f af c6          	imul   %rsi,%rax
    4fb5:	48 c1 e8 20          	shr    $0x20,%rax
    4fb9:	48 39 d0             	cmp    %rdx,%rax
    4fbc:	73 9a                	jae    4f58 <fwp_caps45+0x8>
    4fbe:	48 01 c1             	add    %rax,%rcx
    4fc1:	80 39 01             	cmpb   $0x1,(%rcx)
    4fc4:	75 92                	jne    4f58 <fwp_caps45+0x8>
    4fc6:	e9 05 f3 ff ff       	jmp    42d0 <fwp_mem_free>
    4fcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fd0:	66 85 c0             	test   %ax,%ax
    4fd3:	74 ec                	je     4fc1 <fwp_caps45+0x71>
    4fd5:	c3                   	ret
    4fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fdd:	00 00 00 

0000000000004fe0 <fwp_caps69>:
    4fe0:	f3 0f 1e fa          	endbr64
    4fe4:	85 f6                	test   %esi,%esi
    4fe6:	74 08                	je     4ff0 <fwp_caps69+0x10>
    4fe8:	c3                   	ret
    4fe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4ff0:	48 8b 15 e1 ba 01 00 	mov    0x1bae1(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    4ff7:	48 89 f8             	mov    %rdi,%rax
    4ffa:	48 2b 05 af ba 01 00 	sub    0x1baaf(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5001:	48 c1 e2 10          	shl    $0x10,%rdx
    5005:	48 39 d0             	cmp    %rdx,%rax
    5008:	73 de                	jae    4fe8 <fwp_caps69+0x8>
    500a:	48 89 c2             	mov    %rax,%rdx
    500d:	48 c1 ea 10          	shr    $0x10,%rdx
    5011:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5015:	48 8b 15 dc ba 01 00 	mov    0x1badc(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    501c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5020:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    5024:	48 85 c9             	test   %rcx,%rcx
    5027:	74 bf                	je     4fe8 <fwp_caps69+0x8>
    5029:	0f b6 32             	movzbl (%rdx),%esi
    502c:	40 80 fe 02          	cmp    $0x2,%sil
    5030:	74 2e                	je     5060 <fwp_caps69+0x80>
    5032:	40 80 fe 01          	cmp    $0x1,%sil
    5036:	75 b0                	jne    4fe8 <fwp_caps69+0x8>
    5038:	8b 72 18             	mov    0x18(%rdx),%esi
    503b:	0f b7 c0             	movzwl %ax,%eax
    503e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5041:	48 0f af c6          	imul   %rsi,%rax
    5045:	48 c1 e8 20          	shr    $0x20,%rax
    5049:	48 39 d0             	cmp    %rdx,%rax
    504c:	73 9a                	jae    4fe8 <fwp_caps69+0x8>
    504e:	48 01 c1             	add    %rax,%rcx
    5051:	80 39 01             	cmpb   $0x1,(%rcx)
    5054:	75 92                	jne    4fe8 <fwp_caps69+0x8>
    5056:	e9 75 f2 ff ff       	jmp    42d0 <fwp_mem_free>
    505b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5060:	66 85 c0             	test   %ax,%ax
    5063:	74 ec                	je     5051 <fwp_caps69+0x71>
    5065:	c3                   	ret
    5066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    506d:	00 00 00 

0000000000005070 <fwp_caps74>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	85 f6                	test   %esi,%esi
    5076:	74 08                	je     5080 <fwp_caps74+0x10>
    5078:	c3                   	ret
    5079:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5080:	48 8b 15 51 ba 01 00 	mov    0x1ba51(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    5087:	48 89 f8             	mov    %rdi,%rax
    508a:	48 2b 05 1f ba 01 00 	sub    0x1ba1f(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5091:	48 c1 e2 10          	shl    $0x10,%rdx
    5095:	48 39 d0             	cmp    %rdx,%rax
    5098:	73 de                	jae    5078 <fwp_caps74+0x8>
    509a:	48 89 c2             	mov    %rax,%rdx
    509d:	48 c1 ea 10          	shr    $0x10,%rdx
    50a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    50a5:	48 8b 15 4c ba 01 00 	mov    0x1ba4c(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    50ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    50b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    50b4:	48 85 c9             	test   %rcx,%rcx
    50b7:	74 bf                	je     5078 <fwp_caps74+0x8>
    50b9:	0f b6 32             	movzbl (%rdx),%esi
    50bc:	40 80 fe 02          	cmp    $0x2,%sil
    50c0:	74 2e                	je     50f0 <fwp_caps74+0x80>
    50c2:	40 80 fe 01          	cmp    $0x1,%sil
    50c6:	75 b0                	jne    5078 <fwp_caps74+0x8>
    50c8:	8b 72 18             	mov    0x18(%rdx),%esi
    50cb:	0f b7 c0             	movzwl %ax,%eax
    50ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    50d1:	48 0f af c6          	imul   %rsi,%rax
    50d5:	48 c1 e8 20          	shr    $0x20,%rax
    50d9:	48 39 d0             	cmp    %rdx,%rax
    50dc:	73 9a                	jae    5078 <fwp_caps74+0x8>
    50de:	48 01 c1             	add    %rax,%rcx
    50e1:	80 39 01             	cmpb   $0x1,(%rcx)
    50e4:	75 92                	jne    5078 <fwp_caps74+0x8>
    50e6:	e9 e5 f1 ff ff       	jmp    42d0 <fwp_mem_free>
    50eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50f0:	66 85 c0             	test   %ax,%ax
    50f3:	74 ec                	je     50e1 <fwp_caps74+0x71>
    50f5:	c3                   	ret
    50f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50fd:	00 00 00 

0000000000005100 <fwp_data.part.0.constprop.0>:
    5100:	41 56                	push   %r14
    5102:	8b 05 9c b9 01 00    	mov    0x1b99c(%rip),%eax        # 20aa4 <fwp_heap+0x13a4>
    5108:	41 89 fe             	mov    %edi,%r14d
    510b:	41 55                	push   %r13
    510d:	44 8b 2d ac c2 01 00 	mov    0x1c2ac(%rip),%r13d        # 213c0 <iteration_active>
    5114:	41 54                	push   %r12
    5116:	49 89 f4             	mov    %rsi,%r12
    5119:	55                   	push   %rbp
    511a:	53                   	push   %rbx
    511b:	45 85 ed             	test   %r13d,%r13d
    511e:	0f 85 04 01 00 00    	jne    5228 <fwp_data.part.0.constprop.0+0x128>
    5124:	85 c0                	test   %eax,%eax
    5126:	0f 84 9c 01 00 00    	je     52c8 <fwp_data.part.0.constprop.0+0x1c8>
    512c:	0f b6 05 6f b5 01 00 	movzbl 0x1b56f(%rip),%eax        # 206a2 <fwp_heap+0xfa2>
    5133:	48 8d 15 c6 a5 01 00 	lea    0x1a5c6(%rip),%rdx        # 1f700 <fwp_heap>
    513a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5141:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5145:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5149:	48 8b 18             	mov    (%rax),%rbx
    514c:	48 85 db             	test   %rbx,%rbx
    514f:	0f 84 03 01 00 00    	je     5258 <fwp_data.part.0.constprop.0+0x158>
    5155:	48 8b 13             	mov    (%rbx),%rdx
    5158:	48 f7 d2             	not    %rdx
    515b:	48 89 10             	mov    %rdx,(%rax)
    515e:	48 83 fd 18          	cmp    $0x18,%rbp
    5162:	76 1b                	jbe    517f <fwp_data.part.0.constprop.0+0x7f>
    5164:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5168:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    516c:	31 f6                	xor    %esi,%esi
    516e:	48 c1 e8 03          	shr    $0x3,%rax
    5172:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5179:	00 
    517a:	e8 21 d3 ff ff       	call   24a0 <memset@plt>
    517f:	48 89 e8             	mov    %rbp,%rax
    5182:	48 03 05 97 b9 01 00 	add    0x1b997(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    5189:	0f 82 4d 01 00 00    	jb     52dc <fwp_data.part.0.constprop.0+0x1dc>
    518f:	48 39 05 92 b9 01 00 	cmp    %rax,0x1b992(%rip)        # 20b28 <fwp_heap+0x1428>
    5196:	48 89 05 83 b9 01 00 	mov    %rax,0x1b983(%rip)        # 20b20 <fwp_heap+0x1420>
    519d:	73 07                	jae    51a6 <fwp_data.part.0.constprop.0+0xa6>
    519f:	48 89 05 82 b9 01 00 	mov    %rax,0x1b982(%rip)        # 20b28 <fwp_heap+0x1428>
    51a6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51aa:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    51af:	f2 0f 58 05 81 b9 01 	addsd  0x1b981(%rip),%xmm0        # 20b38 <fwp_heap+0x1438>
    51b6:	00 
    51b7:	f2 0f 11 05 79 b9 01 	movsd  %xmm0,0x1b979(%rip)        # 20b38 <fwp_heap+0x1438>
    51be:	00 
    51bf:	45 85 ed             	test   %r13d,%r13d
    51c2:	74 2c                	je     51f0 <fwp_data.part.0.constprop.0+0xf0>
    51c4:	48 85 c0             	test   %rax,%rax
    51c7:	0f 88 c8 00 00 00    	js     5295 <fwp_data.part.0.constprop.0+0x195>
    51cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51d1:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    51d6:	f2 0f 5c 05 c2 c1 01 	subsd  0x1c1c2(%rip),%xmm0        # 213a0 <iteration_start_charge>
    51dd:	00 
    51de:	66 0f 2f 05 b2 c1 01 	comisd 0x1c1b2(%rip),%xmm0        # 21398 <iteration_peak>
    51e5:	00 
    51e6:	76 08                	jbe    51f0 <fwp_data.part.0.constprop.0+0xf0>
    51e8:	f2 0f 11 05 a8 c1 01 	movsd  %xmm0,0x1c1a8(%rip)        # 21398 <iteration_peak>
    51ef:	00 
    51f0:	b8 02 00 00 00       	mov    $0x2,%eax
    51f5:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    51fa:	66 0f 6e c8          	movd   %eax,%xmm1
    51fe:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5202:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5206:	49 8b 04 24          	mov    (%r12),%rax
    520a:	48 89 43 08          	mov    %rax,0x8(%rbx)
    520e:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5213:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5217:	48 89 d8             	mov    %rbx,%rax
    521a:	5b                   	pop    %rbx
    521b:	5d                   	pop    %rbp
    521c:	41 5c                	pop    %r12
    521e:	41 5d                	pop    %r13
    5220:	41 5e                	pop    %r14
    5222:	c3                   	ret
    5223:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5228:	48 83 05 88 c1 01 00 	addq   $0x1,0x1c188(%rip)        # 213b8 <iteration_requests>
    522f:	01 
    5230:	48 83 05 78 c1 01 00 	addq   $0x18,0x1c178(%rip)        # 213b0 <iteration_bytes>
    5237:	18 
    5238:	85 c0                	test   %eax,%eax
    523a:	0f 85 ec fe ff ff    	jne    512c <fwp_data.part.0.constprop.0+0x2c>
    5240:	31 f6                	xor    %esi,%esi
    5242:	bf 18 00 00 00       	mov    $0x18,%edi
    5247:	e8 04 f4 ff ff       	call   4650 <fwp_heap_alloc_slow>
    524c:	48 89 c3             	mov    %rax,%rbx
    524f:	eb 34                	jmp    5285 <fwp_data.part.0.constprop.0+0x185>
    5251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5258:	48 8b 58 08          	mov    0x8(%rax),%rbx
    525c:	48 85 db             	test   %rbx,%rbx
    525f:	74 0c                	je     526d <fwp_data.part.0.constprop.0+0x16d>
    5261:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5265:	48 29 da             	sub    %rbx,%rdx
    5268:	48 39 ea             	cmp    %rbp,%rdx
    526b:	73 4b                	jae    52b8 <fwp_data.part.0.constprop.0+0x1b8>
    526d:	31 f6                	xor    %esi,%esi
    526f:	bf 18 00 00 00       	mov    $0x18,%edi
    5274:	e8 d7 f3 ff ff       	call   4650 <fwp_heap_alloc_slow>
    5279:	48 89 c3             	mov    %rax,%rbx
    527c:	45 85 ed             	test   %r13d,%r13d
    527f:	0f 84 6b ff ff ff    	je     51f0 <fwp_data.part.0.constprop.0+0xf0>
    5285:	48 8b 05 94 b8 01 00 	mov    0x1b894(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    528c:	48 85 c0             	test   %rax,%rax
    528f:	0f 89 38 ff ff ff    	jns    51cd <fwp_data.part.0.constprop.0+0xcd>
    5295:	48 89 c2             	mov    %rax,%rdx
    5298:	83 e0 01             	and    $0x1,%eax
    529b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    529f:	48 d1 ea             	shr    $1,%rdx
    52a2:	48 09 c2             	or     %rax,%rdx
    52a5:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    52aa:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    52ae:	e9 23 ff ff ff       	jmp    51d6 <fwp_data.part.0.constprop.0+0xd6>
    52b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    52b8:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    52bc:	48 89 50 08          	mov    %rdx,0x8(%rax)
    52c0:	e9 99 fe ff ff       	jmp    515e <fwp_data.part.0.constprop.0+0x5e>
    52c5:	0f 1f 00             	nopl   (%rax)
    52c8:	31 f6                	xor    %esi,%esi
    52ca:	bf 18 00 00 00       	mov    $0x18,%edi
    52cf:	e8 7c f3 ff ff       	call   4650 <fwp_heap_alloc_slow>
    52d4:	48 89 c3             	mov    %rax,%rbx
    52d7:	e9 14 ff ff ff       	jmp    51f0 <fwp_data.part.0.constprop.0+0xf0>
    52dc:	e8 7f da ff ff       	call   2d60 <fwp_heap_oom>
    52e1:	0f 1f 40 00          	nopl   0x0(%rax)
    52e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52ec:	00 00 00 00 

00000000000052f0 <fwp_map_finish_protected.isra.0>:
    52f0:	41 55                	push   %r13
    52f2:	41 54                	push   %r12
    52f4:	55                   	push   %rbp
    52f5:	53                   	push   %rbx
    52f6:	48 83 ec 38          	sub    $0x38,%rsp
    52fa:	48 8b 47 08          	mov    0x8(%rdi),%rax
    52fe:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    5302:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    5309:	00 00 
    530b:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    5310:	49 89 fc             	mov    %rdi,%r12
    5313:	48 85 c0             	test   %rax,%rax
    5316:	0f 84 d4 00 00 00    	je     53f0 <fwp_map_finish_protected.isra.0+0x100>
    531c:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
    5321:	4c 8d 2d d8 a3 01 00 	lea    0x1a3d8(%rip),%r13        # 1f700 <fwp_heap>
    5328:	eb 4a                	jmp    5374 <fwp_map_finish_protected.isra.0+0x84>
    532a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5330:	40 80 fe 01          	cmp    $0x1,%sil
    5334:	75 25                	jne    535b <fwp_map_finish_protected.isra.0+0x6b>
    5336:	8b 71 18             	mov    0x18(%rcx),%esi
    5339:	0f b7 c0             	movzwl %ax,%eax
    533c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    533f:	48 0f af c6          	imul   %rsi,%rax
    5343:	48 c1 e8 20          	shr    $0x20,%rax
    5347:	48 39 c8             	cmp    %rcx,%rax
    534a:	73 0f                	jae    535b <fwp_map_finish_protected.isra.0+0x6b>
    534c:	48 01 c2             	add    %rax,%rdx
    534f:	80 3a ff             	cmpb   $0xff,(%rdx)
    5352:	0f 84 c8 00 00 00    	je     5420 <fwp_map_finish_protected.isra.0+0x130>
    5358:	c6 02 01             	movb   $0x1,(%rdx)
    535b:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5360:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
    5365:	48 83 e8 01          	sub    $0x1,%rax
    5369:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    536e:	0f 84 7c 00 00 00    	je     53f0 <fwp_map_finish_protected.isra.0+0x100>
    5374:	49 8b 14 24          	mov    (%r12),%rdx
    5378:	66 48 0f 6e cb       	movq   %rbx,%xmm1
    537d:	48 89 ee             	mov    %rbp,%rsi
    5380:	bf 01 00 00 00       	mov    $0x1,%edi
    5385:	f3 0f 7e 44 c2 f8    	movq   -0x8(%rdx,%rax,8),%xmm0
    538b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    538f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5394:	e8 67 fd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    5399:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    53a0:	48 89 c3             	mov    %rax,%rbx
    53a3:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    53aa:	48 c1 e2 10          	shl    $0x10,%rdx
    53ae:	48 39 d0             	cmp    %rdx,%rax
    53b1:	73 a8                	jae    535b <fwp_map_finish_protected.isra.0+0x6b>
    53b3:	48 89 c2             	mov    %rax,%rdx
    53b6:	48 c1 ea 10          	shr    $0x10,%rdx
    53ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    53be:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    53c5:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    53c9:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    53cd:	48 85 d2             	test   %rdx,%rdx
    53d0:	74 89                	je     535b <fwp_map_finish_protected.isra.0+0x6b>
    53d2:	0f b6 31             	movzbl (%rcx),%esi
    53d5:	40 80 fe 02          	cmp    $0x2,%sil
    53d9:	0f 85 51 ff ff ff    	jne    5330 <fwp_map_finish_protected.isra.0+0x40>
    53df:	66 85 c0             	test   %ax,%ax
    53e2:	0f 85 73 ff ff ff    	jne    535b <fwp_map_finish_protected.isra.0+0x6b>
    53e8:	e9 62 ff ff ff       	jmp    534f <fwp_map_finish_protected.isra.0+0x5f>
    53ed:	0f 1f 00             	nopl   (%rax)
    53f0:	49 8b 3c 24          	mov    (%r12),%rdi
    53f4:	e8 d7 ee ff ff       	call   42d0 <fwp_mem_free>
    53f9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    53fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5405:	00 00 
    5407:	75 2e                	jne    5437 <fwp_map_finish_protected.isra.0+0x147>
    5409:	48 83 c4 38          	add    $0x38,%rsp
    540d:	48 89 d8             	mov    %rbx,%rax
    5410:	5b                   	pop    %rbx
    5411:	5d                   	pop    %rbp
    5412:	41 5c                	pop    %r12
    5414:	41 5d                	pop    %r13
    5416:	c3                   	ret
    5417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    541e:	00 00 
    5420:	48 89 d7             	mov    %rdx,%rdi
    5423:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5428:	e8 63 ec ff ff       	call   4090 <fwp_rc_forget_slot>
    542d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5432:	e9 21 ff ff ff       	jmp    5358 <fwp_map_finish_protected.isra.0+0x68>
    5437:	e8 04 d0 ff ff       	call   2440 <__stack_chk_fail@plt>
    543c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005440 <fwp_map_items>:
    5440:	55                   	push   %rbp
    5441:	53                   	push   %rbx
    5442:	48 89 fb             	mov    %rdi,%rbx
    5445:	48 83 ec 18          	sub    $0x18,%rsp
    5449:	48 85 ff             	test   %rdi,%rdi
    544c:	0f 84 0e 02 00 00    	je     5660 <fwp_map_items+0x220>
    5452:	48 89 fa             	mov    %rdi,%rdx
    5455:	31 c0                	xor    %eax,%eax
    5457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    545e:	00 00 
    5460:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    5464:	48 89 c1             	mov    %rax,%rcx
    5467:	48 83 c0 01          	add    $0x1,%rax
    546b:	48 85 d2             	test   %rdx,%rdx
    546e:	75 f0                	jne    5460 <fwp_map_items+0x20>
    5470:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    5477:	ff ff 1f 
    547a:	48 89 06             	mov    %rax,(%rsi)
    547d:	48 39 c2             	cmp    %rax,%rdx
    5480:	0f 82 54 02 00 00    	jb     56da <fwp_map_items+0x29a>
    5486:	8b 2d 34 bf 01 00    	mov    0x1bf34(%rip),%ebp        # 213c0 <iteration_active>
    548c:	8b 05 12 b6 01 00    	mov    0x1b612(%rip),%eax        # 20aa4 <fwp_heap+0x13a4>
    5492:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    5499:	00 
    549a:	85 ed                	test   %ebp,%ebp
    549c:	0f 85 1e 01 00 00    	jne    55c0 <fwp_map_items+0x180>
    54a2:	85 c0                	test   %eax,%eax
    54a4:	0f 84 0c 02 00 00    	je     56b6 <fwp_map_items+0x276>
    54aa:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    54b1:	0f 87 11 02 00 00    	ja     56c8 <fwp_map_items+0x288>
    54b7:	48 8d 57 0f          	lea    0xf(%rdi),%rdx
    54bb:	48 8d 05 3e a2 01 00 	lea    0x1a23e(%rip),%rax        # 1f700 <fwp_heap>
    54c2:	48 c1 ea 04          	shr    $0x4,%rdx
    54c6:	0f b6 94 10 a0 0f 00 	movzbl 0xfa0(%rax,%rdx,1),%edx
    54cd:	00 
    54ce:	44 8b 84 90 00 0f 00 	mov    0xf00(%rax,%rdx,4),%r8d
    54d5:	00 
    54d6:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    54da:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    54de:	48 8b 88 80 07 00 00 	mov    0x780(%rax),%rcx
    54e5:	48 85 c9             	test   %rcx,%rcx
    54e8:	0f 84 0a 01 00 00    	je     55f8 <fwp_map_items+0x1b8>
    54ee:	48 8b 11             	mov    (%rcx),%rdx
    54f1:	48 f7 d2             	not    %rdx
    54f4:	48 89 90 80 07 00 00 	mov    %rdx,0x780(%rax)
    54fb:	4c 89 c2             	mov    %r8,%rdx
    54fe:	48 89 cf             	mov    %rcx,%rdi
    5501:	31 f6                	xor    %esi,%esi
    5503:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5508:	e8 93 cf ff ff       	call   24a0 <memset@plt>
    550d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5512:	48 89 c1             	mov    %rax,%rcx
    5515:	4c 89 c0             	mov    %r8,%rax
    5518:	48 03 05 01 b6 01 00 	add    0x1b601(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    551f:	0f 82 c1 01 00 00    	jb     56e6 <fwp_map_items+0x2a6>
    5525:	48 39 05 fc b5 01 00 	cmp    %rax,0x1b5fc(%rip)        # 20b28 <fwp_heap+0x1428>
    552c:	48 89 05 ed b5 01 00 	mov    %rax,0x1b5ed(%rip)        # 20b20 <fwp_heap+0x1420>
    5533:	73 07                	jae    553c <fwp_map_items+0xfc>
    5535:	48 89 05 ec b5 01 00 	mov    %rax,0x1b5ec(%rip)        # 20b28 <fwp_heap+0x1428>
    553c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5540:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5545:	f2 0f 58 05 eb b5 01 	addsd  0x1b5eb(%rip),%xmm0        # 20b38 <fwp_heap+0x1438>
    554c:	00 
    554d:	f2 0f 11 05 e3 b5 01 	movsd  %xmm0,0x1b5e3(%rip)        # 20b38 <fwp_heap+0x1438>
    5554:	00 
    5555:	85 ed                	test   %ebp,%ebp
    5557:	74 33                	je     558c <fwp_map_items+0x14c>
    5559:	48 8b 05 c0 b5 01 00 	mov    0x1b5c0(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    5560:	48 85 c0             	test   %rax,%rax
    5563:	0f 88 bf 00 00 00    	js     5628 <fwp_map_items+0x1e8>
    5569:	66 0f ef c0          	pxor   %xmm0,%xmm0
    556d:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5572:	f2 0f 5c 05 26 be 01 	subsd  0x1be26(%rip),%xmm0        # 213a0 <iteration_start_charge>
    5579:	00 
    557a:	66 0f 2f 05 16 be 01 	comisd 0x1be16(%rip),%xmm0        # 21398 <iteration_peak>
    5581:	00 
    5582:	76 08                	jbe    558c <fwp_map_items+0x14c>
    5584:	f2 0f 11 05 0c be 01 	movsd  %xmm0,0x1be0c(%rip)        # 21398 <iteration_peak>
    558b:	00 
    558c:	48 85 db             	test   %rbx,%rbx
    558f:	74 24                	je     55b5 <fwp_map_items+0x175>
    5591:	48 89 c8             	mov    %rcx,%rax
    5594:	90                   	nop
    5595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    559c:	00 00 00 00 
    55a0:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    55a4:	48 83 c0 08          	add    $0x8,%rax
    55a8:	48 89 50 f8          	mov    %rdx,-0x8(%rax)
    55ac:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    55b0:	48 85 db             	test   %rbx,%rbx
    55b3:	75 eb                	jne    55a0 <fwp_map_items+0x160>
    55b5:	48 83 c4 18          	add    $0x18,%rsp
    55b9:	48 89 c8             	mov    %rcx,%rax
    55bc:	5b                   	pop    %rbx
    55bd:	5d                   	pop    %rbp
    55be:	c3                   	ret
    55bf:	90                   	nop
    55c0:	48 83 05 f0 bd 01 00 	addq   $0x1,0x1bdf0(%rip)        # 213b8 <iteration_requests>
    55c7:	01 
    55c8:	48 01 3d e1 bd 01 00 	add    %rdi,0x1bde1(%rip)        # 213b0 <iteration_bytes>
    55cf:	85 c0                	test   %eax,%eax
    55d1:	74 0d                	je     55e0 <fwp_map_items+0x1a0>
    55d3:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    55da:	0f 86 d7 fe ff ff    	jbe    54b7 <fwp_map_items+0x77>
    55e0:	be 02 00 00 00       	mov    $0x2,%esi
    55e5:	e8 66 f0 ff ff       	call   4650 <fwp_heap_alloc_slow>
    55ea:	48 89 c1             	mov    %rax,%rcx
    55ed:	e9 67 ff ff ff       	jmp    5559 <fwp_map_items+0x119>
    55f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    55f8:	48 8b 88 88 07 00 00 	mov    0x788(%rax),%rcx
    55ff:	48 85 c9             	test   %rcx,%rcx
    5602:	74 0f                	je     5613 <fwp_map_items+0x1d3>
    5604:	48 8b 90 90 07 00 00 	mov    0x790(%rax),%rdx
    560b:	48 29 ca             	sub    %rcx,%rdx
    560e:	4c 39 c2             	cmp    %r8,%rdx
    5611:	73 33                	jae    5646 <fwp_map_items+0x206>
    5613:	be 02 00 00 00       	mov    $0x2,%esi
    5618:	e8 33 f0 ff ff       	call   4650 <fwp_heap_alloc_slow>
    561d:	48 89 c1             	mov    %rax,%rcx
    5620:	e9 30 ff ff ff       	jmp    5555 <fwp_map_items+0x115>
    5625:	0f 1f 00             	nopl   (%rax)
    5628:	48 89 c2             	mov    %rax,%rdx
    562b:	83 e0 01             	and    $0x1,%eax
    562e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5632:	48 d1 ea             	shr    $1,%rdx
    5635:	48 09 c2             	or     %rax,%rdx
    5638:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    563d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5641:	e9 2c ff ff ff       	jmp    5572 <fwp_map_items+0x132>
    5646:	4a 8d 14 01          	lea    (%rcx,%r8,1),%rdx
    564a:	48 89 90 88 07 00 00 	mov    %rdx,0x788(%rax)
    5651:	e9 a5 fe ff ff       	jmp    54fb <fwp_map_items+0xbb>
    5656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    565d:	00 00 00 
    5660:	8b 2d 5a bd 01 00    	mov    0x1bd5a(%rip),%ebp        # 213c0 <iteration_active>
    5666:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    566d:	8b 05 31 b4 01 00    	mov    0x1b431(%rip),%eax        # 20aa4 <fwp_heap+0x13a4>
    5673:	85 ed                	test   %ebp,%ebp
    5675:	75 1d                	jne    5694 <fwp_map_items+0x254>
    5677:	bf 08 00 00 00       	mov    $0x8,%edi
    567c:	85 c0                	test   %eax,%eax
    567e:	0f 85 33 fe ff ff    	jne    54b7 <fwp_map_items+0x77>
    5684:	48 83 c4 18          	add    $0x18,%rsp
    5688:	be 02 00 00 00       	mov    $0x2,%esi
    568d:	5b                   	pop    %rbx
    568e:	5d                   	pop    %rbp
    568f:	e9 bc ef ff ff       	jmp    4650 <fwp_heap_alloc_slow>
    5694:	48 83 05 1c bd 01 00 	addq   $0x1,0x1bd1c(%rip)        # 213b8 <iteration_requests>
    569b:	01 
    569c:	bf 08 00 00 00       	mov    $0x8,%edi
    56a1:	48 83 05 07 bd 01 00 	addq   $0x8,0x1bd07(%rip)        # 213b0 <iteration_bytes>
    56a8:	08 
    56a9:	85 c0                	test   %eax,%eax
    56ab:	0f 85 06 fe ff ff    	jne    54b7 <fwp_map_items+0x77>
    56b1:	e9 2a ff ff ff       	jmp    55e0 <fwp_map_items+0x1a0>
    56b6:	be 02 00 00 00       	mov    $0x2,%esi
    56bb:	e8 90 ef ff ff       	call   4650 <fwp_heap_alloc_slow>
    56c0:	48 89 c1             	mov    %rax,%rcx
    56c3:	e9 c9 fe ff ff       	jmp    5591 <fwp_map_items+0x151>
    56c8:	be 02 00 00 00       	mov    $0x2,%esi
    56cd:	e8 7e ef ff ff       	call   4650 <fwp_heap_alloc_slow>
    56d2:	48 89 c1             	mov    %rax,%rcx
    56d5:	e9 b2 fe ff ff       	jmp    558c <fwp_map_items+0x14c>
    56da:	48 8d 3d 29 6a 00 00 	lea    0x6a29(%rip),%rdi        # c10a <_IO_stdin_used+0x10a>
    56e1:	e8 8a db ff ff       	call   3270 <fwp_trap>
    56e6:	e8 75 d6 ff ff       	call   2d60 <fwp_heap_oom>
    56eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000056f0 <fwp_drop4>:
    56f0:	f3 0f 1e fa          	endbr64
    56f4:	48 8b 15 dd b3 01 00 	mov    0x1b3dd(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    56fb:	48 89 f8             	mov    %rdi,%rax
    56fe:	48 2b 05 ab b3 01 00 	sub    0x1b3ab(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5705:	48 c1 e2 10          	shl    $0x10,%rdx
    5709:	48 39 d0             	cmp    %rdx,%rax
    570c:	73 67                	jae    5775 <fwp_drop4+0x85>
    570e:	48 89 c2             	mov    %rax,%rdx
    5711:	48 c1 ea 10          	shr    $0x10,%rdx
    5715:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5719:	48 8b 15 d8 b3 01 00 	mov    0x1b3d8(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    5720:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5724:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5728:	48 85 d2             	test   %rdx,%rdx
    572b:	74 48                	je     5775 <fwp_drop4+0x85>
    572d:	0f b6 31             	movzbl (%rcx),%esi
    5730:	40 80 fe 02          	cmp    $0x2,%sil
    5734:	74 3a                	je     5770 <fwp_drop4+0x80>
    5736:	40 80 fe 01          	cmp    $0x1,%sil
    573a:	75 39                	jne    5775 <fwp_drop4+0x85>
    573c:	8b 71 18             	mov    0x18(%rcx),%esi
    573f:	0f b7 c0             	movzwl %ax,%eax
    5742:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5745:	48 0f af c6          	imul   %rsi,%rax
    5749:	48 c1 e8 20          	shr    $0x20,%rax
    574d:	48 39 c8             	cmp    %rcx,%rax
    5750:	73 23                	jae    5775 <fwp_drop4+0x85>
    5752:	48 01 c2             	add    %rax,%rdx
    5755:	0f b6 02             	movzbl (%rdx),%eax
    5758:	84 c0                	test   %al,%al
    575a:	74 19                	je     5775 <fwp_drop4+0x85>
    575c:	3c 01                	cmp    $0x1,%al
    575e:	74 20                	je     5780 <fwp_drop4+0x90>
    5760:	3c ff                	cmp    $0xff,%al
    5762:	74 24                	je     5788 <fwp_drop4+0x98>
    5764:	83 e8 01             	sub    $0x1,%eax
    5767:	88 02                	mov    %al,(%rdx)
    5769:	c3                   	ret
    576a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5770:	66 85 c0             	test   %ax,%ax
    5773:	74 e0                	je     5755 <fwp_drop4+0x65>
    5775:	c3                   	ret
    5776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    577d:	00 00 00 
    5780:	e9 4b eb ff ff       	jmp    42d0 <fwp_mem_free>
    5785:	0f 1f 00             	nopl   (%rax)
    5788:	48 89 d0             	mov    %rdx,%rax
    578b:	48 8d 35 6e 9f 01 00 	lea    0x19f6e(%rip),%rsi        # 1f700 <fwp_heap>
    5792:	48 83 ec 18          	sub    $0x18,%rsp
    5796:	48 c1 e8 11          	shr    $0x11,%rax
    579a:	48 31 d0             	xor    %rdx,%rax
    579d:	48 89 c1             	mov    %rax,%rcx
    57a0:	48 c1 e9 09          	shr    $0x9,%rcx
    57a4:	48 31 c8             	xor    %rcx,%rax
    57a7:	0f b6 c8             	movzbl %al,%ecx
    57aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    57b1:	00 
    57b2:	48 85 c0             	test   %rax,%rax
    57b5:	75 12                	jne    57c9 <fwp_drop4+0xd9>
    57b7:	eb 49                	jmp    5802 <fwp_drop4+0x112>
    57b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    57c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    57c4:	48 85 c0             	test   %rax,%rax
    57c7:	74 39                	je     5802 <fwp_drop4+0x112>
    57c9:	48 89 c1             	mov    %rax,%rcx
    57cc:	48 39 10             	cmp    %rdx,(%rax)
    57cf:	75 ef                	jne    57c0 <fwp_drop4+0xd0>
    57d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    57d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    57d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    57dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    57e4:	74 05                	je     57eb <fwp_drop4+0xfb>
    57e6:	48 83 c4 18          	add    $0x18,%rsp
    57ea:	c3                   	ret
    57eb:	48 89 d7             	mov    %rdx,%rdi
    57ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    57f3:	e8 98 e8 ff ff       	call   4090 <fwp_rc_forget_slot>
    57f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    5800:	eb e4                	jmp    57e6 <fwp_drop4+0xf6>
    5802:	48 8d 3d bf 6b 00 00 	lea    0x6bbf(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    5809:	e8 62 da ff ff       	call   3270 <fwp_trap>
    580e:	66 90                	xchg   %ax,%ax

0000000000005810 <fwp_owned_entry50>:
    5810:	f3 0f 1e fa          	endbr64
    5814:	53                   	push   %rbx
    5815:	48 8b 3f             	mov    (%rdi),%rdi
    5818:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
    581c:	e8 cf fe ff ff       	call   56f0 <fwp_drop4>
    5821:	48 89 d8             	mov    %rbx,%rax
    5824:	5b                   	pop    %rbx
    5825:	c3                   	ret
    5826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    582d:	00 00 00 

0000000000005830 <fwp_owned_entry47>:
    5830:	f3 0f 1e fa          	endbr64
    5834:	53                   	push   %rbx
    5835:	48 8b 3f             	mov    (%rdi),%rdi
    5838:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    583c:	e8 af fe ff ff       	call   56f0 <fwp_drop4>
    5841:	48 89 d8             	mov    %rbx,%rax
    5844:	5b                   	pop    %rbx
    5845:	c3                   	ret
    5846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    584d:	00 00 00 

0000000000005850 <fwp_arg_drop47>:
    5850:	f3 0f 1e fa          	endbr64
    5854:	85 f6                	test   %esi,%esi
    5856:	75 04                	jne    585c <fwp_arg_drop47+0xc>
    5858:	85 d2                	test   %edx,%edx
    585a:	75 04                	jne    5860 <fwp_arg_drop47+0x10>
    585c:	c3                   	ret
    585d:	0f 1f 00             	nopl   (%rax)
    5860:	48 8b 3f             	mov    (%rdi),%rdi
    5863:	e9 88 fe ff ff       	jmp    56f0 <fwp_drop4>
    5868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    586f:	00 

0000000000005870 <e50>:
    5870:	f3 0f 1e fa          	endbr64
    5874:	55                   	push   %rbp
    5875:	53                   	push   %rbx
    5876:	48 83 ec 08          	sub    $0x8,%rsp
    587a:	48 8b 1f             	mov    (%rdi),%rbx
    587d:	48 89 df             	mov    %rbx,%rdi
    5880:	e8 4b ef ff ff       	call   47d0 <fwp_rc_share>
    5885:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
    5889:	48 89 df             	mov    %rbx,%rdi
    588c:	e8 5f fe ff ff       	call   56f0 <fwp_drop4>
    5891:	48 89 ef             	mov    %rbp,%rdi
    5894:	e8 37 ef ff ff       	call   47d0 <fwp_rc_share>
    5899:	48 83 c4 08          	add    $0x8,%rsp
    589d:	48 89 e8             	mov    %rbp,%rax
    58a0:	5b                   	pop    %rbx
    58a1:	5d                   	pop    %rbp
    58a2:	c3                   	ret
    58a3:	66 90                	xchg   %ax,%ax
    58a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58ac:	00 00 00 00 

00000000000058b0 <e47>:
    58b0:	f3 0f 1e fa          	endbr64
    58b4:	55                   	push   %rbp
    58b5:	53                   	push   %rbx
    58b6:	48 83 ec 08          	sub    $0x8,%rsp
    58ba:	48 8b 1f             	mov    (%rdi),%rbx
    58bd:	48 89 df             	mov    %rbx,%rdi
    58c0:	e8 0b ef ff ff       	call   47d0 <fwp_rc_share>
    58c5:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
    58c9:	48 89 df             	mov    %rbx,%rdi
    58cc:	e8 1f fe ff ff       	call   56f0 <fwp_drop4>
    58d1:	48 89 ef             	mov    %rbp,%rdi
    58d4:	e8 f7 ee ff ff       	call   47d0 <fwp_rc_share>
    58d9:	48 83 c4 08          	add    $0x8,%rsp
    58dd:	48 89 e8             	mov    %rbp,%rax
    58e0:	5b                   	pop    %rbx
    58e1:	5d                   	pop    %rbp
    58e2:	c3                   	ret
    58e3:	66 90                	xchg   %ax,%ax
    58e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58ec:	00 00 00 00 

00000000000058f0 <fwp_arg_drop50>:
    58f0:	f3 0f 1e fa          	endbr64
    58f4:	85 f6                	test   %esi,%esi
    58f6:	75 04                	jne    58fc <fwp_arg_drop50+0xc>
    58f8:	85 d2                	test   %edx,%edx
    58fa:	75 04                	jne    5900 <fwp_arg_drop50+0x10>
    58fc:	c3                   	ret
    58fd:	0f 1f 00             	nopl   (%rax)
    5900:	48 8b 3f             	mov    (%rdi),%rdi
    5903:	e9 e8 fd ff ff       	jmp    56f0 <fwp_drop4>
    5908:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    590f:	00 

0000000000005910 <fwp_drop0>:
    5910:	f3 0f 1e fa          	endbr64
    5914:	48 8b 15 bd b1 01 00 	mov    0x1b1bd(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    591b:	48 89 f8             	mov    %rdi,%rax
    591e:	48 2b 05 8b b1 01 00 	sub    0x1b18b(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5925:	48 c1 e2 10          	shl    $0x10,%rdx
    5929:	48 39 d0             	cmp    %rdx,%rax
    592c:	0f 83 36 01 00 00    	jae    5a68 <fwp_drop0+0x158>
    5932:	48 83 ec 18          	sub    $0x18,%rsp
    5936:	48 8d 35 c3 9d 01 00 	lea    0x19dc3(%rip),%rsi        # 1f700 <fwp_heap>
    593d:	48 89 c2             	mov    %rax,%rdx
    5940:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    5947:	48 c1 ea 10          	shr    $0x10,%rdx
    594b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    594f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    5953:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5957:	48 85 d2             	test   %rdx,%rdx
    595a:	74 42                	je     599e <fwp_drop0+0x8e>
    595c:	44 0f b6 01          	movzbl (%rcx),%r8d
    5960:	41 80 f8 02          	cmp    $0x2,%r8b
    5964:	74 42                	je     59a8 <fwp_drop0+0x98>
    5966:	41 80 f8 01          	cmp    $0x1,%r8b
    596a:	75 32                	jne    599e <fwp_drop0+0x8e>
    596c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    5970:	0f b7 c0             	movzwl %ax,%eax
    5973:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5976:	49 0f af c0          	imul   %r8,%rax
    597a:	48 c1 e8 20          	shr    $0x20,%rax
    597e:	48 39 c8             	cmp    %rcx,%rax
    5981:	73 1b                	jae    599e <fwp_drop0+0x8e>
    5983:	48 01 c2             	add    %rax,%rdx
    5986:	0f b6 02             	movzbl (%rdx),%eax
    5989:	84 c0                	test   %al,%al
    598b:	74 11                	je     599e <fwp_drop0+0x8e>
    598d:	3c 01                	cmp    $0x1,%al
    598f:	74 27                	je     59b8 <fwp_drop0+0xa8>
    5991:	3c ff                	cmp    $0xff,%al
    5993:	0f 84 e7 00 00 00    	je     5a80 <fwp_drop0+0x170>
    5999:	83 e8 01             	sub    $0x1,%eax
    599c:	88 02                	mov    %al,(%rdx)
    599e:	48 83 c4 18          	add    $0x18,%rsp
    59a2:	c3                   	ret
    59a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59a8:	66 85 c0             	test   %ax,%ax
    59ab:	74 d9                	je     5986 <fwp_drop0+0x76>
    59ad:	48 83 c4 18          	add    $0x18,%rsp
    59b1:	c3                   	ret
    59b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    59b8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    59bf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    59c6:	48 89 f8             	mov    %rdi,%rax
    59c9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    59cd:	48 29 c8             	sub    %rcx,%rax
    59d0:	48 c1 e2 10          	shl    $0x10,%rdx
    59d4:	48 39 d0             	cmp    %rdx,%rax
    59d7:	73 71                	jae    5a4a <fwp_drop0+0x13a>
    59d9:	49 89 c2             	mov    %rax,%r10
    59dc:	49 c1 ea 10          	shr    $0x10,%r10
    59e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    59e4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    59e8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    59ec:	4d 85 d2             	test   %r10,%r10
    59ef:	74 59                	je     5a4a <fwp_drop0+0x13a>
    59f1:	45 0f b6 19          	movzbl (%r9),%r11d
    59f5:	41 80 fb 02          	cmp    $0x2,%r11b
    59f9:	74 75                	je     5a70 <fwp_drop0+0x160>
    59fb:	41 80 fb 01          	cmp    $0x1,%r11b
    59ff:	75 49                	jne    5a4a <fwp_drop0+0x13a>
    5a01:	45 8b 59 18          	mov    0x18(%r9),%r11d
    5a05:	0f b7 c0             	movzwl %ax,%eax
    5a08:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    5a0c:	49 0f af c3          	imul   %r11,%rax
    5a10:	48 c1 e8 20          	shr    $0x20,%rax
    5a14:	4c 39 c8             	cmp    %r9,%rax
    5a17:	73 31                	jae    5a4a <fwp_drop0+0x13a>
    5a19:	49 01 c2             	add    %rax,%r10
    5a1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5a20:	75 28                	jne    5a4a <fwp_drop0+0x13a>
    5a22:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5a27:	e8 a4 e8 ff ff       	call   42d0 <fwp_mem_free>
    5a2c:	48 8d 35 cd 9c 01 00 	lea    0x19ccd(%rip),%rsi        # 1f700 <fwp_heap>
    5a33:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5a38:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    5a3f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    5a46:	48 c1 e2 10          	shl    $0x10,%rdx
    5a4a:	4c 89 c0             	mov    %r8,%rax
    5a4d:	48 29 c8             	sub    %rcx,%rax
    5a50:	48 39 d0             	cmp    %rdx,%rax
    5a53:	0f 83 45 ff ff ff    	jae    599e <fwp_drop0+0x8e>
    5a59:	4c 89 c7             	mov    %r8,%rdi
    5a5c:	e9 dc fe ff ff       	jmp    593d <fwp_drop0+0x2d>
    5a61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a68:	c3                   	ret
    5a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a70:	66 85 c0             	test   %ax,%ax
    5a73:	75 d5                	jne    5a4a <fwp_drop0+0x13a>
    5a75:	eb a5                	jmp    5a1c <fwp_drop0+0x10c>
    5a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a7e:	00 00 
    5a80:	48 89 d0             	mov    %rdx,%rax
    5a83:	48 c1 e8 11          	shr    $0x11,%rax
    5a87:	48 31 d0             	xor    %rdx,%rax
    5a8a:	48 89 c1             	mov    %rax,%rcx
    5a8d:	48 c1 e9 09          	shr    $0x9,%rcx
    5a91:	48 31 c8             	xor    %rcx,%rax
    5a94:	0f b6 c8             	movzbl %al,%ecx
    5a97:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    5a9e:	00 
    5a9f:	48 85 c0             	test   %rax,%rax
    5aa2:	75 25                	jne    5ac9 <fwp_drop0+0x1b9>
    5aa4:	eb 5e                	jmp    5b04 <fwp_drop0+0x1f4>
    5aa6:	0f 1f 40 00          	nopl   0x0(%rax)
    5aaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ab1:	00 00 00 00 
    5ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5abc:	00 00 00 00 
    5ac0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5ac4:	48 85 c0             	test   %rax,%rax
    5ac7:	74 3b                	je     5b04 <fwp_drop0+0x1f4>
    5ac9:	48 89 c1             	mov    %rax,%rcx
    5acc:	48 39 10             	cmp    %rdx,(%rax)
    5acf:	75 ef                	jne    5ac0 <fwp_drop0+0x1b0>
    5ad1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    5ad5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    5ad9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    5add:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    5ae4:	0f 85 b4 fe ff ff    	jne    599e <fwp_drop0+0x8e>
    5aea:	48 89 d7             	mov    %rdx,%rdi
    5aed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5af2:	e8 99 e5 ff ff       	call   4090 <fwp_rc_forget_slot>
    5af7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5afc:	c6 02 fe             	movb   $0xfe,(%rdx)
    5aff:	e9 9a fe ff ff       	jmp    599e <fwp_drop0+0x8e>
    5b04:	48 8d 3d bd 68 00 00 	lea    0x68bd(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    5b0b:	e8 60 d7 ff ff       	call   3270 <fwp_trap>

0000000000005b10 <fwp_drop1>:
    5b10:	f3 0f 1e fa          	endbr64
    5b14:	e9 f7 fd ff ff       	jmp    5910 <fwp_drop0>
    5b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005b20 <fwp_drop6>:
    5b20:	f3 0f 1e fa          	endbr64
    5b24:	48 8b 0d ad af 01 00 	mov    0x1afad(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    5b2b:	48 89 f8             	mov    %rdi,%rax
    5b2e:	48 2b 05 7b af 01 00 	sub    0x1af7b(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5b35:	48 c1 e1 10          	shl    $0x10,%rcx
    5b39:	48 39 c8             	cmp    %rcx,%rax
    5b3c:	0f 83 56 01 00 00    	jae    5c98 <fwp_drop6+0x178>
    5b42:	48 83 ec 18          	sub    $0x18,%rsp
    5b46:	48 89 fa             	mov    %rdi,%rdx
    5b49:	4c 8d 05 b0 9b 01 00 	lea    0x19bb0(%rip),%r8        # 1f700 <fwp_heap>
    5b50:	48 89 c1             	mov    %rax,%rcx
    5b53:	48 c1 e9 10          	shr    $0x10,%rcx
    5b57:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    5b5b:	49 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%rcx
    5b62:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    5b66:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    5b6a:	48 85 c9             	test   %rcx,%rcx
    5b6d:	74 40                	je     5baf <fwp_drop6+0x8f>
    5b6f:	0f b6 3e             	movzbl (%rsi),%edi
    5b72:	40 80 ff 02          	cmp    $0x2,%dil
    5b76:	74 40                	je     5bb8 <fwp_drop6+0x98>
    5b78:	40 80 ff 01          	cmp    $0x1,%dil
    5b7c:	75 31                	jne    5baf <fwp_drop6+0x8f>
    5b7e:	8b 7e 18             	mov    0x18(%rsi),%edi
    5b81:	0f b7 c0             	movzwl %ax,%eax
    5b84:	8b 76 1c             	mov    0x1c(%rsi),%esi
    5b87:	48 0f af c7          	imul   %rdi,%rax
    5b8b:	48 c1 e8 20          	shr    $0x20,%rax
    5b8f:	48 39 f0             	cmp    %rsi,%rax
    5b92:	73 1b                	jae    5baf <fwp_drop6+0x8f>
    5b94:	48 01 c1             	add    %rax,%rcx
    5b97:	0f b6 01             	movzbl (%rcx),%eax
    5b9a:	84 c0                	test   %al,%al
    5b9c:	74 11                	je     5baf <fwp_drop6+0x8f>
    5b9e:	3c 01                	cmp    $0x1,%al
    5ba0:	74 26                	je     5bc8 <fwp_drop6+0xa8>
    5ba2:	3c ff                	cmp    $0xff,%al
    5ba4:	0f 84 06 01 00 00    	je     5cb0 <fwp_drop6+0x190>
    5baa:	83 e8 01             	sub    $0x1,%eax
    5bad:	88 01                	mov    %al,(%rcx)
    5baf:	48 83 c4 18          	add    $0x18,%rsp
    5bb3:	c3                   	ret
    5bb4:	0f 1f 40 00          	nopl   0x0(%rax)
    5bb8:	66 85 c0             	test   %ax,%ax
    5bbb:	74 da                	je     5b97 <fwp_drop6+0x77>
    5bbd:	48 83 c4 18          	add    $0x18,%rsp
    5bc1:	c3                   	ret
    5bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5bc8:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    5bcc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5bd1:	e8 1a fb ff ff       	call   56f0 <fwp_drop4>
    5bd6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5bdb:	4c 8d 05 1e 9b 01 00 	lea    0x19b1e(%rip),%r8        # 1f700 <fwp_heap>
    5be2:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5be9:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5bf0:	48 89 d0             	mov    %rdx,%rax
    5bf3:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    5bf7:	48 29 f0             	sub    %rsi,%rax
    5bfa:	48 c1 e1 10          	shl    $0x10,%rcx
    5bfe:	48 39 c8             	cmp    %rcx,%rax
    5c01:	73 7a                	jae    5c7d <fwp_drop6+0x15d>
    5c03:	48 89 c7             	mov    %rax,%rdi
    5c06:	48 c1 ef 10          	shr    $0x10,%rdi
    5c0a:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
    5c0e:	49 8b b8 f8 13 00 00 	mov    0x13f8(%r8),%rdi
    5c15:	4a 8d 3c d7          	lea    (%rdi,%r10,8),%rdi
    5c19:	4c 8b 57 20          	mov    0x20(%rdi),%r10
    5c1d:	4d 85 d2             	test   %r10,%r10
    5c20:	74 5b                	je     5c7d <fwp_drop6+0x15d>
    5c22:	44 0f b6 1f          	movzbl (%rdi),%r11d
    5c26:	41 80 fb 02          	cmp    $0x2,%r11b
    5c2a:	74 74                	je     5ca0 <fwp_drop6+0x180>
    5c2c:	41 80 fb 01          	cmp    $0x1,%r11b
    5c30:	75 4b                	jne    5c7d <fwp_drop6+0x15d>
    5c32:	44 8b 5f 18          	mov    0x18(%rdi),%r11d
    5c36:	0f b7 c0             	movzwl %ax,%eax
    5c39:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    5c3c:	49 0f af c3          	imul   %r11,%rax
    5c40:	48 c1 e8 20          	shr    $0x20,%rax
    5c44:	48 39 f8             	cmp    %rdi,%rax
    5c47:	73 34                	jae    5c7d <fwp_drop6+0x15d>
    5c49:	49 01 c2             	add    %rax,%r10
    5c4c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    5c50:	75 2b                	jne    5c7d <fwp_drop6+0x15d>
    5c52:	48 89 d7             	mov    %rdx,%rdi
    5c55:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5c5a:	e8 71 e6 ff ff       	call   42d0 <fwp_mem_free>
    5c5f:	4c 8d 05 9a 9a 01 00 	lea    0x19a9a(%rip),%r8        # 1f700 <fwp_heap>
    5c66:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5c6b:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    5c72:	49 8b b0 b0 13 00 00 	mov    0x13b0(%r8),%rsi
    5c79:	48 c1 e1 10          	shl    $0x10,%rcx
    5c7d:	4c 89 c8             	mov    %r9,%rax
    5c80:	48 29 f0             	sub    %rsi,%rax
    5c83:	48 39 c8             	cmp    %rcx,%rax
    5c86:	0f 83 23 ff ff ff    	jae    5baf <fwp_drop6+0x8f>
    5c8c:	4c 89 ca             	mov    %r9,%rdx
    5c8f:	e9 bc fe ff ff       	jmp    5b50 <fwp_drop6+0x30>
    5c94:	0f 1f 40 00          	nopl   0x0(%rax)
    5c98:	c3                   	ret
    5c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ca0:	66 85 c0             	test   %ax,%ax
    5ca3:	75 d8                	jne    5c7d <fwp_drop6+0x15d>
    5ca5:	eb a5                	jmp    5c4c <fwp_drop6+0x12c>
    5ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5cae:	00 00 
    5cb0:	48 89 c8             	mov    %rcx,%rax
    5cb3:	48 c1 e8 11          	shr    $0x11,%rax
    5cb7:	48 31 c8             	xor    %rcx,%rax
    5cba:	48 89 c2             	mov    %rax,%rdx
    5cbd:	48 c1 ea 09          	shr    $0x9,%rdx
    5cc1:	48 31 d0             	xor    %rdx,%rax
    5cc4:	0f b6 d0             	movzbl %al,%edx
    5cc7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    5cce:	00 
    5ccf:	48 85 c0             	test   %rax,%rax
    5cd2:	75 15                	jne    5ce9 <fwp_drop6+0x1c9>
    5cd4:	eb 4e                	jmp    5d24 <fwp_drop6+0x204>
    5cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5cdd:	00 00 00 
    5ce0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    5ce4:	48 85 c0             	test   %rax,%rax
    5ce7:	74 3b                	je     5d24 <fwp_drop6+0x204>
    5ce9:	48 89 c2             	mov    %rax,%rdx
    5cec:	48 39 08             	cmp    %rcx,(%rax)
    5cef:	75 ef                	jne    5ce0 <fwp_drop6+0x1c0>
    5cf1:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5cf5:	48 83 ea 01          	sub    $0x1,%rdx
    5cf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5cfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    5d04:	0f 85 a5 fe ff ff    	jne    5baf <fwp_drop6+0x8f>
    5d0a:	48 89 cf             	mov    %rcx,%rdi
    5d0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5d12:	e8 79 e3 ff ff       	call   4090 <fwp_rc_forget_slot>
    5d17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5d1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    5d1f:	e9 8b fe ff ff       	jmp    5baf <fwp_drop6+0x8f>
    5d24:	48 8d 3d 9d 66 00 00 	lea    0x669d(%rip),%rdi        # c3c8 <_IO_stdin_used+0x3c8>
    5d2b:	e8 40 d5 ff ff       	call   3270 <fwp_trap>

0000000000005d30 <fwp_args47>:
    5d30:	f3 0f 1e fa          	endbr64
    5d34:	85 d2                	test   %edx,%edx
    5d36:	74 04                	je     5d3c <fwp_args47+0xc>
    5d38:	85 f6                	test   %esi,%esi
    5d3a:	74 04                	je     5d40 <fwp_args47+0x10>
    5d3c:	c3                   	ret
    5d3d:	0f 1f 00             	nopl   (%rax)
    5d40:	48 8b 15 91 ad 01 00 	mov    0x1ad91(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    5d47:	48 8b 07             	mov    (%rdi),%rax
    5d4a:	48 2b 05 5f ad 01 00 	sub    0x1ad5f(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5d51:	48 c1 e2 10          	shl    $0x10,%rdx
    5d55:	48 39 d0             	cmp    %rdx,%rax
    5d58:	73 e2                	jae    5d3c <fwp_args47+0xc>
    5d5a:	48 89 c2             	mov    %rax,%rdx
    5d5d:	48 c1 ea 10          	shr    $0x10,%rdx
    5d61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5d65:	48 8b 15 8c ad 01 00 	mov    0x1ad8c(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    5d6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5d70:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5d74:	48 85 ff             	test   %rdi,%rdi
    5d77:	74 c3                	je     5d3c <fwp_args47+0xc>
    5d79:	0f b6 0a             	movzbl (%rdx),%ecx
    5d7c:	80 f9 02             	cmp    $0x2,%cl
    5d7f:	74 4f                	je     5dd0 <fwp_args47+0xa0>
    5d81:	80 f9 01             	cmp    $0x1,%cl
    5d84:	75 b6                	jne    5d3c <fwp_args47+0xc>
    5d86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5d89:	0f b7 c0             	movzwl %ax,%eax
    5d8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5d8f:	48 0f af c1          	imul   %rcx,%rax
    5d93:	48 c1 e8 20          	shr    $0x20,%rax
    5d97:	48 39 d0             	cmp    %rdx,%rax
    5d9a:	73 a0                	jae    5d3c <fwp_args47+0xc>
    5d9c:	48 01 c7             	add    %rax,%rdi
    5d9f:	0f b6 07             	movzbl (%rdi),%eax
    5da2:	84 c0                	test   %al,%al
    5da4:	74 96                	je     5d3c <fwp_args47+0xc>
    5da6:	8b 15 14 b6 01 00    	mov    0x1b614(%rip),%edx        # 213c0 <iteration_active>
    5dac:	85 d2                	test   %edx,%edx
    5dae:	75 10                	jne    5dc0 <fwp_args47+0x90>
    5db0:	3c fd                	cmp    $0xfd,%al
    5db2:	77 22                	ja     5dd6 <fwp_args47+0xa6>
    5db4:	83 c0 01             	add    $0x1,%eax
    5db7:	88 07                	mov    %al,(%rdi)
    5db9:	c3                   	ret
    5dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5dc0:	48 83 05 e0 b5 01 00 	addq   $0x1,0x1b5e0(%rip)        # 213a8 <iteration_retains>
    5dc7:	01 
    5dc8:	eb e6                	jmp    5db0 <fwp_args47+0x80>
    5dca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5dd0:	66 85 c0             	test   %ax,%ax
    5dd3:	74 ca                	je     5d9f <fwp_args47+0x6f>
    5dd5:	c3                   	ret
    5dd6:	e9 95 e1 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    5ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005de0 <fwp_args50>:
    5de0:	f3 0f 1e fa          	endbr64
    5de4:	85 d2                	test   %edx,%edx
    5de6:	74 04                	je     5dec <fwp_args50+0xc>
    5de8:	85 f6                	test   %esi,%esi
    5dea:	74 04                	je     5df0 <fwp_args50+0x10>
    5dec:	c3                   	ret
    5ded:	0f 1f 00             	nopl   (%rax)
    5df0:	48 8b 15 e1 ac 01 00 	mov    0x1ace1(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    5df7:	48 8b 07             	mov    (%rdi),%rax
    5dfa:	48 2b 05 af ac 01 00 	sub    0x1acaf(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5e01:	48 c1 e2 10          	shl    $0x10,%rdx
    5e05:	48 39 d0             	cmp    %rdx,%rax
    5e08:	73 e2                	jae    5dec <fwp_args50+0xc>
    5e0a:	48 89 c2             	mov    %rax,%rdx
    5e0d:	48 c1 ea 10          	shr    $0x10,%rdx
    5e11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5e15:	48 8b 15 dc ac 01 00 	mov    0x1acdc(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    5e1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    5e20:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    5e24:	48 85 ff             	test   %rdi,%rdi
    5e27:	74 c3                	je     5dec <fwp_args50+0xc>
    5e29:	0f b6 0a             	movzbl (%rdx),%ecx
    5e2c:	80 f9 02             	cmp    $0x2,%cl
    5e2f:	74 4f                	je     5e80 <fwp_args50+0xa0>
    5e31:	80 f9 01             	cmp    $0x1,%cl
    5e34:	75 b6                	jne    5dec <fwp_args50+0xc>
    5e36:	8b 4a 18             	mov    0x18(%rdx),%ecx
    5e39:	0f b7 c0             	movzwl %ax,%eax
    5e3c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    5e3f:	48 0f af c1          	imul   %rcx,%rax
    5e43:	48 c1 e8 20          	shr    $0x20,%rax
    5e47:	48 39 d0             	cmp    %rdx,%rax
    5e4a:	73 a0                	jae    5dec <fwp_args50+0xc>
    5e4c:	48 01 c7             	add    %rax,%rdi
    5e4f:	0f b6 07             	movzbl (%rdi),%eax
    5e52:	84 c0                	test   %al,%al
    5e54:	74 96                	je     5dec <fwp_args50+0xc>
    5e56:	8b 15 64 b5 01 00    	mov    0x1b564(%rip),%edx        # 213c0 <iteration_active>
    5e5c:	85 d2                	test   %edx,%edx
    5e5e:	75 10                	jne    5e70 <fwp_args50+0x90>
    5e60:	3c fd                	cmp    $0xfd,%al
    5e62:	77 22                	ja     5e86 <fwp_args50+0xa6>
    5e64:	83 c0 01             	add    $0x1,%eax
    5e67:	88 07                	mov    %al,(%rdi)
    5e69:	c3                   	ret
    5e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e70:	48 83 05 30 b5 01 00 	addq   $0x1,0x1b530(%rip)        # 213a8 <iteration_retains>
    5e77:	01 
    5e78:	eb e6                	jmp    5e60 <fwp_args50+0x80>
    5e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5e80:	66 85 c0             	test   %ax,%ax
    5e83:	74 ca                	je     5e4f <fwp_args50+0x6f>
    5e85:	c3                   	ret
    5e86:	e9 e5 e0 ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    5e8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000005e90 <fwp_owned_entry74>:
    5e90:	f3 0f 1e fa          	endbr64
    5e94:	48 83 ec 38          	sub    $0x38,%rsp
    5e98:	f2 0f 10 1f          	movsd  (%rdi),%xmm3
    5e9c:	f3 0f 7e 4f 08       	movq   0x8(%rdi),%xmm1
    5ea1:	31 ff                	xor    %edi,%edi
    5ea3:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5eaa:	00 00 
    5eac:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    5eb1:	31 c0                	xor    %eax,%eax
    5eb3:	f2 0f 10 15 45 67 00 	movsd  0x6745(%rip),%xmm2        # c600 <msg.3+0x30>
    5eba:	00 
    5ebb:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    5ec0:	66 0f 28 c3          	movapd %xmm3,%xmm0
    5ec4:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5ec8:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    5ecc:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    5ed0:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    5ed4:	f2 0f 10 05 1c 67 00 	movsd  0x671c(%rip),%xmm0        # c5f8 <msg.3+0x28>
    5edb:	00 
    5edc:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5ee0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    5ee4:	f2 0f 59 0d 1c 67 00 	mulsd  0x671c(%rip),%xmm1        # c608 <msg.3+0x38>
    5eeb:	00 
    5eec:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    5ef0:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    5ef4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    5ef9:	e8 02 f2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    5efe:	48 8b 15 d3 ab 01 00 	mov    0x1abd3(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    5f05:	48 89 c6             	mov    %rax,%rsi
    5f08:	48 2b 05 a1 ab 01 00 	sub    0x1aba1(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    5f0f:	48 c1 e2 10          	shl    $0x10,%rdx
    5f13:	48 39 d0             	cmp    %rdx,%rax
    5f16:	73 4f                	jae    5f67 <fwp_owned_entry74+0xd7>
    5f18:	48 89 c2             	mov    %rax,%rdx
    5f1b:	48 c1 ea 10          	shr    $0x10,%rdx
    5f1f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    5f23:	48 8b 15 ce ab 01 00 	mov    0x1abce(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    5f2a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    5f2e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5f32:	48 85 d2             	test   %rdx,%rdx
    5f35:	74 30                	je     5f67 <fwp_owned_entry74+0xd7>
    5f37:	0f b6 39             	movzbl (%rcx),%edi
    5f3a:	40 80 ff 02          	cmp    $0x2,%dil
    5f3e:	74 40                	je     5f80 <fwp_owned_entry74+0xf0>
    5f40:	40 80 ff 01          	cmp    $0x1,%dil
    5f44:	75 21                	jne    5f67 <fwp_owned_entry74+0xd7>
    5f46:	8b 79 18             	mov    0x18(%rcx),%edi
    5f49:	0f b7 c0             	movzwl %ax,%eax
    5f4c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    5f4f:	48 0f af c7          	imul   %rdi,%rax
    5f53:	48 c1 e8 20          	shr    $0x20,%rax
    5f57:	48 39 c8             	cmp    %rcx,%rax
    5f5a:	73 0b                	jae    5f67 <fwp_owned_entry74+0xd7>
    5f5c:	48 01 c2             	add    %rax,%rdx
    5f5f:	80 3a ff             	cmpb   $0xff,(%rdx)
    5f62:	74 2c                	je     5f90 <fwp_owned_entry74+0x100>
    5f64:	c6 02 01             	movb   $0x1,(%rdx)
    5f67:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    5f6c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f73:	00 00 
    5f75:	75 35                	jne    5fac <fwp_owned_entry74+0x11c>
    5f77:	48 89 f0             	mov    %rsi,%rax
    5f7a:	48 83 c4 38          	add    $0x38,%rsp
    5f7e:	c3                   	ret
    5f7f:	90                   	nop
    5f80:	66 85 c0             	test   %ax,%ax
    5f83:	75 e2                	jne    5f67 <fwp_owned_entry74+0xd7>
    5f85:	eb d8                	jmp    5f5f <fwp_owned_entry74+0xcf>
    5f87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f8e:	00 00 
    5f90:	48 89 d7             	mov    %rdx,%rdi
    5f93:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5f98:	48 89 14 24          	mov    %rdx,(%rsp)
    5f9c:	e8 ef e0 ff ff       	call   4090 <fwp_rc_forget_slot>
    5fa1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    5fa6:	48 8b 14 24          	mov    (%rsp),%rdx
    5faa:	eb b8                	jmp    5f64 <fwp_owned_entry74+0xd4>
    5fac:	e8 8f c4 ff ff       	call   2440 <__stack_chk_fail@plt>
    5fb1:	0f 1f 40 00          	nopl   0x0(%rax)
    5fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fbc:	00 00 00 00 

0000000000005fc0 <e74>:
    5fc0:	f3 0f 1e fa          	endbr64
    5fc4:	53                   	push   %rbx
    5fc5:	48 83 ec 30          	sub    $0x30,%rsp
    5fc9:	f2 0f 10 1f          	movsd  (%rdi),%xmm3
    5fcd:	f3 0f 7e 4f 08       	movq   0x8(%rdi),%xmm1
    5fd2:	31 ff                	xor    %edi,%edi
    5fd4:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    5fdb:	00 00 
    5fdd:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    5fe2:	31 c0                	xor    %eax,%eax
    5fe4:	f2 0f 10 15 14 66 00 	movsd  0x6614(%rip),%xmm2        # c600 <msg.3+0x30>
    5feb:	00 
    5fec:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    5ff1:	66 0f 28 c3          	movapd %xmm3,%xmm0
    5ff5:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    5ff9:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    5ffd:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    6001:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    6005:	f2 0f 10 05 eb 65 00 	movsd  0x65eb(%rip),%xmm0        # c5f8 <msg.3+0x28>
    600c:	00 
    600d:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    6011:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    6015:	f2 0f 59 0d eb 65 00 	mulsd  0x65eb(%rip),%xmm1        # c608 <msg.3+0x38>
    601c:	00 
    601d:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    6021:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    6025:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    602a:	e8 d1 f0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    602f:	48 8b 15 a2 aa 01 00 	mov    0x1aaa2(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    6036:	48 89 c3             	mov    %rax,%rbx
    6039:	48 2b 05 70 aa 01 00 	sub    0x1aa70(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    6040:	48 c1 e2 10          	shl    $0x10,%rdx
    6044:	48 39 d0             	cmp    %rdx,%rax
    6047:	73 4f                	jae    6098 <e74+0xd8>
    6049:	48 89 c2             	mov    %rax,%rdx
    604c:	48 c1 ea 10          	shr    $0x10,%rdx
    6050:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6054:	48 8b 15 9d aa 01 00 	mov    0x1aa9d(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    605b:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    605f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6063:	48 85 d2             	test   %rdx,%rdx
    6066:	74 30                	je     6098 <e74+0xd8>
    6068:	0f b6 31             	movzbl (%rcx),%esi
    606b:	40 80 fe 02          	cmp    $0x2,%sil
    606f:	74 4f                	je     60c0 <e74+0x100>
    6071:	40 80 fe 01          	cmp    $0x1,%sil
    6075:	75 21                	jne    6098 <e74+0xd8>
    6077:	8b 71 18             	mov    0x18(%rcx),%esi
    607a:	0f b7 c0             	movzwl %ax,%eax
    607d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6080:	48 0f af c6          	imul   %rsi,%rax
    6084:	48 c1 e8 20          	shr    $0x20,%rax
    6088:	48 39 c8             	cmp    %rcx,%rax
    608b:	73 0b                	jae    6098 <e74+0xd8>
    608d:	48 01 c2             	add    %rax,%rdx
    6090:	80 3a ff             	cmpb   $0xff,(%rdx)
    6093:	74 3b                	je     60d0 <e74+0x110>
    6095:	c6 02 01             	movb   $0x1,(%rdx)
    6098:	48 89 df             	mov    %rbx,%rdi
    609b:	e8 30 e7 ff ff       	call   47d0 <fwp_rc_share>
    60a0:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    60a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    60ac:	00 00 
    60ae:	75 34                	jne    60e4 <e74+0x124>
    60b0:	48 83 c4 30          	add    $0x30,%rsp
    60b4:	48 89 d8             	mov    %rbx,%rax
    60b7:	5b                   	pop    %rbx
    60b8:	c3                   	ret
    60b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c0:	66 85 c0             	test   %ax,%ax
    60c3:	75 d3                	jne    6098 <e74+0xd8>
    60c5:	eb c9                	jmp    6090 <e74+0xd0>
    60c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    60ce:	00 00 
    60d0:	48 89 d7             	mov    %rdx,%rdi
    60d3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    60d8:	e8 b3 df ff ff       	call   4090 <fwp_rc_forget_slot>
    60dd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    60e2:	eb b1                	jmp    6095 <e74+0xd5>
    60e4:	e8 57 c3 ff ff       	call   2440 <__stack_chk_fail@plt>
    60e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000060f0 <fwp_caps47>:
    60f0:	f3 0f 1e fa          	endbr64
    60f4:	48 83 ec 18          	sub    $0x18,%rsp
    60f8:	48 89 f8             	mov    %rdi,%rax
    60fb:	8b 7f 04             	mov    0x4(%rdi),%edi
    60fe:	85 ff                	test   %edi,%edi
    6100:	0f 84 9a 00 00 00    	je     61a0 <fwp_caps47+0xb0>
    6106:	48 8b 78 08          	mov    0x8(%rax),%rdi
    610a:	85 f6                	test   %esi,%esi
    610c:	0f 85 9e 00 00 00    	jne    61b0 <fwp_caps47+0xc0>
    6112:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6117:	e8 d4 f5 ff ff       	call   56f0 <fwp_drop4>
    611c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6121:	48 8b 0d b0 a9 01 00 	mov    0x1a9b0(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    6128:	48 89 c2             	mov    %rax,%rdx
    612b:	48 2b 15 7e a9 01 00 	sub    0x1a97e(%rip),%rdx        # 20ab0 <fwp_heap+0x13b0>
    6132:	48 c1 e1 10          	shl    $0x10,%rcx
    6136:	48 39 ca             	cmp    %rcx,%rdx
    6139:	73 6d                	jae    61a8 <fwp_caps47+0xb8>
    613b:	48 89 d1             	mov    %rdx,%rcx
    613e:	48 c1 e9 10          	shr    $0x10,%rcx
    6142:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6146:	48 8b 0d ab a9 01 00 	mov    0x1a9ab(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    614d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    6151:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    6155:	48 85 f6             	test   %rsi,%rsi
    6158:	74 4e                	je     61a8 <fwp_caps47+0xb8>
    615a:	0f b6 39             	movzbl (%rcx),%edi
    615d:	40 80 ff 02          	cmp    $0x2,%dil
    6161:	0f 84 c9 00 00 00    	je     6230 <fwp_caps47+0x140>
    6167:	40 80 ff 01          	cmp    $0x1,%dil
    616b:	75 3b                	jne    61a8 <fwp_caps47+0xb8>
    616d:	8b 79 18             	mov    0x18(%rcx),%edi
    6170:	0f b7 d2             	movzwl %dx,%edx
    6173:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6176:	48 0f af d7          	imul   %rdi,%rdx
    617a:	48 c1 ea 20          	shr    $0x20,%rdx
    617e:	48 39 ca             	cmp    %rcx,%rdx
    6181:	73 25                	jae    61a8 <fwp_caps47+0xb8>
    6183:	48 01 d6             	add    %rdx,%rsi
    6186:	80 3e 01             	cmpb   $0x1,(%rsi)
    6189:	75 1d                	jne    61a8 <fwp_caps47+0xb8>
    618b:	48 89 c7             	mov    %rax,%rdi
    618e:	48 83 c4 18          	add    $0x18,%rsp
    6192:	e9 39 e1 ff ff       	jmp    42d0 <fwp_mem_free>
    6197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    619e:	00 00 
    61a0:	85 f6                	test   %esi,%esi
    61a2:	0f 84 79 ff ff ff    	je     6121 <fwp_caps47+0x31>
    61a8:	48 83 c4 18          	add    $0x18,%rsp
    61ac:	c3                   	ret
    61ad:	0f 1f 00             	nopl   (%rax)
    61b0:	48 8b 05 21 a9 01 00 	mov    0x1a921(%rip),%rax        # 20ad8 <fwp_heap+0x13d8>
    61b7:	48 2b 3d f2 a8 01 00 	sub    0x1a8f2(%rip),%rdi        # 20ab0 <fwp_heap+0x13b0>
    61be:	48 c1 e0 10          	shl    $0x10,%rax
    61c2:	48 39 c7             	cmp    %rax,%rdi
    61c5:	73 e1                	jae    61a8 <fwp_caps47+0xb8>
    61c7:	48 89 f8             	mov    %rdi,%rax
    61ca:	48 c1 e8 10          	shr    $0x10,%rax
    61ce:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    61d2:	48 8b 05 1f a9 01 00 	mov    0x1a91f(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    61d9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    61dd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    61e1:	48 85 c0             	test   %rax,%rax
    61e4:	74 c2                	je     61a8 <fwp_caps47+0xb8>
    61e6:	0f b6 0a             	movzbl (%rdx),%ecx
    61e9:	80 f9 02             	cmp    $0x2,%cl
    61ec:	74 52                	je     6240 <fwp_caps47+0x150>
    61ee:	80 f9 01             	cmp    $0x1,%cl
    61f1:	75 b5                	jne    61a8 <fwp_caps47+0xb8>
    61f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    61f6:	0f b7 ff             	movzwl %di,%edi
    61f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    61fc:	48 0f af f9          	imul   %rcx,%rdi
    6200:	48 c1 ef 20          	shr    $0x20,%rdi
    6204:	48 39 d7             	cmp    %rdx,%rdi
    6207:	73 9f                	jae    61a8 <fwp_caps47+0xb8>
    6209:	48 01 f8             	add    %rdi,%rax
    620c:	0f b6 10             	movzbl (%rax),%edx
    620f:	84 d2                	test   %dl,%dl
    6211:	74 95                	je     61a8 <fwp_caps47+0xb8>
    6213:	8b 0d a7 b1 01 00    	mov    0x1b1a7(%rip),%ecx        # 213c0 <iteration_active>
    6219:	85 c9                	test   %ecx,%ecx
    621b:	75 33                	jne    6250 <fwp_caps47+0x160>
    621d:	80 fa fd             	cmp    $0xfd,%dl
    6220:	77 38                	ja     625a <fwp_caps47+0x16a>
    6222:	83 c2 01             	add    $0x1,%edx
    6225:	88 10                	mov    %dl,(%rax)
    6227:	e9 7c ff ff ff       	jmp    61a8 <fwp_caps47+0xb8>
    622c:	0f 1f 40 00          	nopl   0x0(%rax)
    6230:	66 85 d2             	test   %dx,%dx
    6233:	0f 85 6f ff ff ff    	jne    61a8 <fwp_caps47+0xb8>
    6239:	e9 48 ff ff ff       	jmp    6186 <fwp_caps47+0x96>
    623e:	66 90                	xchg   %ax,%ax
    6240:	66 85 ff             	test   %di,%di
    6243:	0f 85 5f ff ff ff    	jne    61a8 <fwp_caps47+0xb8>
    6249:	eb c1                	jmp    620c <fwp_caps47+0x11c>
    624b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6250:	48 83 05 50 b1 01 00 	addq   $0x1,0x1b150(%rip)        # 213a8 <iteration_retains>
    6257:	01 
    6258:	eb c3                	jmp    621d <fwp_caps47+0x12d>
    625a:	48 89 c7             	mov    %rax,%rdi
    625d:	48 83 c4 18          	add    $0x18,%rsp
    6261:	e9 0a dd ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    6266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    626d:	00 00 00 

0000000000006270 <fwp_caps50>:
    6270:	f3 0f 1e fa          	endbr64
    6274:	48 83 ec 18          	sub    $0x18,%rsp
    6278:	48 89 f8             	mov    %rdi,%rax
    627b:	8b 7f 04             	mov    0x4(%rdi),%edi
    627e:	85 ff                	test   %edi,%edi
    6280:	0f 84 9a 00 00 00    	je     6320 <fwp_caps50+0xb0>
    6286:	48 8b 78 08          	mov    0x8(%rax),%rdi
    628a:	85 f6                	test   %esi,%esi
    628c:	0f 85 9e 00 00 00    	jne    6330 <fwp_caps50+0xc0>
    6292:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    6297:	e8 54 f4 ff ff       	call   56f0 <fwp_drop4>
    629c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    62a1:	48 8b 0d 30 a8 01 00 	mov    0x1a830(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    62a8:	48 89 c2             	mov    %rax,%rdx
    62ab:	48 2b 15 fe a7 01 00 	sub    0x1a7fe(%rip),%rdx        # 20ab0 <fwp_heap+0x13b0>
    62b2:	48 c1 e1 10          	shl    $0x10,%rcx
    62b6:	48 39 ca             	cmp    %rcx,%rdx
    62b9:	73 6d                	jae    6328 <fwp_caps50+0xb8>
    62bb:	48 89 d1             	mov    %rdx,%rcx
    62be:	48 c1 e9 10          	shr    $0x10,%rcx
    62c2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    62c6:	48 8b 0d 2b a8 01 00 	mov    0x1a82b(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    62cd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    62d1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    62d5:	48 85 f6             	test   %rsi,%rsi
    62d8:	74 4e                	je     6328 <fwp_caps50+0xb8>
    62da:	0f b6 39             	movzbl (%rcx),%edi
    62dd:	40 80 ff 02          	cmp    $0x2,%dil
    62e1:	0f 84 c9 00 00 00    	je     63b0 <fwp_caps50+0x140>
    62e7:	40 80 ff 01          	cmp    $0x1,%dil
    62eb:	75 3b                	jne    6328 <fwp_caps50+0xb8>
    62ed:	8b 79 18             	mov    0x18(%rcx),%edi
    62f0:	0f b7 d2             	movzwl %dx,%edx
    62f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    62f6:	48 0f af d7          	imul   %rdi,%rdx
    62fa:	48 c1 ea 20          	shr    $0x20,%rdx
    62fe:	48 39 ca             	cmp    %rcx,%rdx
    6301:	73 25                	jae    6328 <fwp_caps50+0xb8>
    6303:	48 01 d6             	add    %rdx,%rsi
    6306:	80 3e 01             	cmpb   $0x1,(%rsi)
    6309:	75 1d                	jne    6328 <fwp_caps50+0xb8>
    630b:	48 89 c7             	mov    %rax,%rdi
    630e:	48 83 c4 18          	add    $0x18,%rsp
    6312:	e9 b9 df ff ff       	jmp    42d0 <fwp_mem_free>
    6317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    631e:	00 00 
    6320:	85 f6                	test   %esi,%esi
    6322:	0f 84 79 ff ff ff    	je     62a1 <fwp_caps50+0x31>
    6328:	48 83 c4 18          	add    $0x18,%rsp
    632c:	c3                   	ret
    632d:	0f 1f 00             	nopl   (%rax)
    6330:	48 8b 05 a1 a7 01 00 	mov    0x1a7a1(%rip),%rax        # 20ad8 <fwp_heap+0x13d8>
    6337:	48 2b 3d 72 a7 01 00 	sub    0x1a772(%rip),%rdi        # 20ab0 <fwp_heap+0x13b0>
    633e:	48 c1 e0 10          	shl    $0x10,%rax
    6342:	48 39 c7             	cmp    %rax,%rdi
    6345:	73 e1                	jae    6328 <fwp_caps50+0xb8>
    6347:	48 89 f8             	mov    %rdi,%rax
    634a:	48 c1 e8 10          	shr    $0x10,%rax
    634e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6352:	48 8b 05 9f a7 01 00 	mov    0x1a79f(%rip),%rax        # 20af8 <fwp_heap+0x13f8>
    6359:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    635d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6361:	48 85 c0             	test   %rax,%rax
    6364:	74 c2                	je     6328 <fwp_caps50+0xb8>
    6366:	0f b6 0a             	movzbl (%rdx),%ecx
    6369:	80 f9 02             	cmp    $0x2,%cl
    636c:	74 52                	je     63c0 <fwp_caps50+0x150>
    636e:	80 f9 01             	cmp    $0x1,%cl
    6371:	75 b5                	jne    6328 <fwp_caps50+0xb8>
    6373:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6376:	0f b7 ff             	movzwl %di,%edi
    6379:	8b 52 1c             	mov    0x1c(%rdx),%edx
    637c:	48 0f af f9          	imul   %rcx,%rdi
    6380:	48 c1 ef 20          	shr    $0x20,%rdi
    6384:	48 39 d7             	cmp    %rdx,%rdi
    6387:	73 9f                	jae    6328 <fwp_caps50+0xb8>
    6389:	48 01 f8             	add    %rdi,%rax
    638c:	0f b6 10             	movzbl (%rax),%edx
    638f:	84 d2                	test   %dl,%dl
    6391:	74 95                	je     6328 <fwp_caps50+0xb8>
    6393:	8b 0d 27 b0 01 00    	mov    0x1b027(%rip),%ecx        # 213c0 <iteration_active>
    6399:	85 c9                	test   %ecx,%ecx
    639b:	75 33                	jne    63d0 <fwp_caps50+0x160>
    639d:	80 fa fd             	cmp    $0xfd,%dl
    63a0:	77 38                	ja     63da <fwp_caps50+0x16a>
    63a2:	83 c2 01             	add    $0x1,%edx
    63a5:	88 10                	mov    %dl,(%rax)
    63a7:	e9 7c ff ff ff       	jmp    6328 <fwp_caps50+0xb8>
    63ac:	0f 1f 40 00          	nopl   0x0(%rax)
    63b0:	66 85 d2             	test   %dx,%dx
    63b3:	0f 85 6f ff ff ff    	jne    6328 <fwp_caps50+0xb8>
    63b9:	e9 48 ff ff ff       	jmp    6306 <fwp_caps50+0x96>
    63be:	66 90                	xchg   %ax,%ax
    63c0:	66 85 ff             	test   %di,%di
    63c3:	0f 85 5f ff ff ff    	jne    6328 <fwp_caps50+0xb8>
    63c9:	eb c1                	jmp    638c <fwp_caps50+0x11c>
    63cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    63d0:	48 83 05 d0 af 01 00 	addq   $0x1,0x1afd0(%rip)        # 213a8 <iteration_retains>
    63d7:	01 
    63d8:	eb c3                	jmp    639d <fwp_caps50+0x12d>
    63da:	48 89 c7             	mov    %rax,%rdi
    63dd:	48 83 c4 18          	add    $0x18,%rsp
    63e1:	e9 8a db ff ff       	jmp    3f70 <fwp_rc_wide_dup>
    63e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    63ed:	00 00 00 

00000000000063f0 <fwp_loop_fields68.constprop.0>:
    63f0:	41 57                	push   %r15
    63f2:	48 8d 05 17 f5 ff ff 	lea    -0xae9(%rip),%rax        # 5910 <fwp_drop0>
    63f9:	41 56                	push   %r14
    63fb:	66 48 0f 6e f0       	movq   %rax,%xmm6
    6400:	48 8d 05 19 f7 ff ff 	lea    -0x8e7(%rip),%rax        # 5b20 <fwp_drop6>
    6407:	41 55                	push   %r13
    6409:	66 48 0f 6e f8       	movq   %rax,%xmm7
    640e:	31 c0                	xor    %eax,%eax
    6410:	41 54                	push   %r12
    6412:	55                   	push   %rbp
    6413:	53                   	push   %rbx
    6414:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    641b:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    6420:	64 48 8b 14 25 28 00 	mov    %fs:0x28,%rdx
    6427:	00 00 
    6429:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
    6430:	00 
    6431:	31 d2                	xor    %edx,%edx
    6433:	48 c7 44 24 38 c6 00 	movq   $0xc6,0x38(%rsp)
    643a:	00 00 
    643c:	66 48 0f 6e ea       	movq   %rdx,%xmm5
    6441:	66 0f 6c ee          	punpcklqdq %xmm6,%xmm5
    6445:	f3 0f 7e 35 d3 87 00 	movq   0x87d3(%rip),%xmm6        # ec20 <d0+0x80>
    644c:	00 
    644d:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
    6452:	66 0f 6c f7          	punpcklqdq %xmm7,%xmm6
    6456:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
    645b:	48 85 c0             	test   %rax,%rax
    645e:	0f 85 a7 c2 ff ff    	jne    270b <fwp_loop_fields68.constprop.0.cold>
    6464:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6469:	48 85 c0             	test   %rax,%rax
    646c:	0f 84 d9 0a 00 00    	je     6f4b <fwp_loop_fields68.constprop.0+0xb5b>
    6472:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6476:	48 8b 0d 5b a6 01 00 	mov    0x1a65b(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    647d:	4c 89 f8             	mov    %r15,%rax
    6480:	48 2b 05 29 a6 01 00 	sub    0x1a629(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    6487:	4c 8d 25 72 92 01 00 	lea    0x19272(%rip),%r12        # 1f700 <fwp_heap>
    648e:	48 c1 e1 10          	shl    $0x10,%rcx
    6492:	48 39 c8             	cmp    %rcx,%rax
    6495:	73 6f                	jae    6506 <fwp_loop_fields68.constprop.0+0x116>
    6497:	48 89 c1             	mov    %rax,%rcx
    649a:	48 c1 e9 10          	shr    $0x10,%rcx
    649e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    64a2:	48 8b 0d 4f a6 01 00 	mov    0x1a64f(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    64a9:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    64ad:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    64b1:	48 85 ff             	test   %rdi,%rdi
    64b4:	74 50                	je     6506 <fwp_loop_fields68.constprop.0+0x116>
    64b6:	0f b6 31             	movzbl (%rcx),%esi
    64b9:	40 80 fe 02          	cmp    $0x2,%sil
    64bd:	0f 84 2d 0a 00 00    	je     6ef0 <fwp_loop_fields68.constprop.0+0xb00>
    64c3:	40 80 fe 01          	cmp    $0x1,%sil
    64c7:	75 3d                	jne    6506 <fwp_loop_fields68.constprop.0+0x116>
    64c9:	8b 71 18             	mov    0x18(%rcx),%esi
    64cc:	0f b7 c0             	movzwl %ax,%eax
    64cf:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64d2:	48 0f af c6          	imul   %rsi,%rax
    64d6:	48 c1 e8 20          	shr    $0x20,%rax
    64da:	48 39 c8             	cmp    %rcx,%rax
    64dd:	73 27                	jae    6506 <fwp_loop_fields68.constprop.0+0x116>
    64df:	48 01 c7             	add    %rax,%rdi
    64e2:	0f b6 07             	movzbl (%rdi),%eax
    64e5:	84 c0                	test   %al,%al
    64e7:	74 1d                	je     6506 <fwp_loop_fields68.constprop.0+0x116>
    64e9:	44 8b 05 d0 ae 01 00 	mov    0x1aed0(%rip),%r8d        # 213c0 <iteration_active>
    64f0:	45 85 c0             	test   %r8d,%r8d
    64f3:	0f 85 17 0a 00 00    	jne    6f10 <fwp_loop_fields68.constprop.0+0xb20>
    64f9:	3c fd                	cmp    $0xfd,%al
    64fb:	0f 87 5c 0a 00 00    	ja     6f5d <fwp_loop_fields68.constprop.0+0xb6d>
    6501:	83 c0 01             	add    $0x1,%eax
    6504:	88 07                	mov    %al,(%rdi)
    6506:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    650b:	4c 89 ff             	mov    %r15,%rdi
    650e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
    6513:	e8 28 ef ff ff       	call   5440 <fwp_map_items>
    6518:	66 0f 6f 7c 24 50    	movdqa 0x50(%rsp),%xmm7
    651e:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6523:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    652a:	00 00 00 00 00 
    652f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6534:	49 89 c5             	mov    %rax,%r13
    6537:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
    653c:	48 89 c6             	mov    %rax,%rsi
    653f:	48 89 04 24          	mov    %rax,(%rsp)
    6543:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    654a:	00 
    654b:	e8 f0 ee ff ff       	call   5440 <fwp_map_items>
    6550:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
    6555:	49 89 c6             	mov    %rax,%r14
    6558:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    655d:	49 39 c1             	cmp    %rax,%r9
    6560:	49 0f 46 c1          	cmovbe %r9,%rax
    6564:	48 89 c2             	mov    %rax,%rdx
    6567:	48 85 c0             	test   %rax,%rax
    656a:	0f 84 00 09 00 00    	je     6e70 <fwp_loop_fields68.constprop.0+0xa80>
    6570:	31 ed                	xor    %ebp,%ebp
    6572:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    6577:	48 8d 9c 24 b0 00 00 	lea    0xb0(%rsp),%rbx
    657e:	00 
    657f:	4d 89 f7             	mov    %r14,%r15
    6582:	4d 89 ee             	mov    %r13,%r14
    6585:	49 89 ed             	mov    %rbp,%r13
    6588:	48 89 c5             	mov    %rax,%rbp
    658b:	eb 40                	jmp    65cd <fwp_loop_fields68.constprop.0+0x1dd>
    658d:	0f 1f 00             	nopl   (%rax)
    6590:	41 80 f8 01          	cmp    $0x1,%r8b
    6594:	75 26                	jne    65bc <fwp_loop_fields68.constprop.0+0x1cc>
    6596:	44 8b 47 18          	mov    0x18(%rdi),%r8d
    659a:	0f b7 c0             	movzwl %ax,%eax
    659d:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    65a0:	49 0f af c0          	imul   %r8,%rax
    65a4:	48 c1 e8 20          	shr    $0x20,%rax
    65a8:	48 39 f8             	cmp    %rdi,%rax
    65ab:	73 0f                	jae    65bc <fwp_loop_fields68.constprop.0+0x1cc>
    65ad:	48 01 c1             	add    %rax,%rcx
    65b0:	80 39 ff             	cmpb   $0xff,(%rcx)
    65b3:	0f 84 57 08 00 00    	je     6e10 <fwp_loop_fields68.constprop.0+0xa20>
    65b9:	c6 01 01             	movb   $0x1,(%rcx)
    65bc:	4b 89 34 ee          	mov    %rsi,(%r14,%r13,8)
    65c0:	49 83 c5 01          	add    $0x1,%r13
    65c4:	4c 39 ed             	cmp    %r13,%rbp
    65c7:	0f 84 d3 00 00 00    	je     66a0 <fwp_loop_fields68.constprop.0+0x2b0>
    65cd:	f2 43 0f 10 1c ef    	movsd  (%r15,%r13,8),%xmm3
    65d3:	f2 43 0f 10 0c ee    	movsd  (%r14,%r13,8),%xmm1
    65d9:	48 89 de             	mov    %rbx,%rsi
    65dc:	31 ff                	xor    %edi,%edi
    65de:	f2 0f 10 15 1a 60 00 	movsd  0x601a(%rip),%xmm2        # c600 <msg.3+0x30>
    65e5:	00 
    65e6:	66 0f 28 c3          	movapd %xmm3,%xmm0
    65ea:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    65ee:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
    65f2:	f2 0f 58 d2          	addsd  %xmm2,%xmm2
    65f6:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
    65fa:	f2 0f 10 05 f6 5f 00 	movsd  0x5ff6(%rip),%xmm0        # c5f8 <msg.3+0x28>
    6601:	00 
    6602:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
    6606:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    660a:	f2 0f 59 0d f6 5f 00 	mulsd  0x5ff6(%rip),%xmm1        # c608 <msg.3+0x38>
    6611:	00 
    6612:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    6616:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
    661a:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    6621:	00 
    6622:	e8 d9 ea ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    6627:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    662e:	00 
    662f:	48 89 c6             	mov    %rax,%rsi
    6632:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6639:	00 
    663a:	48 c1 e1 10          	shl    $0x10,%rcx
    663e:	48 39 c8             	cmp    %rcx,%rax
    6641:	0f 83 75 ff ff ff    	jae    65bc <fwp_loop_fields68.constprop.0+0x1cc>
    6647:	48 89 c1             	mov    %rax,%rcx
    664a:	48 c1 e9 10          	shr    $0x10,%rcx
    664e:	48 8d 3c 89          	lea    (%rcx,%rcx,4),%rdi
    6652:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    6659:	00 
    665a:	48 8d 3c f9          	lea    (%rcx,%rdi,8),%rdi
    665e:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    6662:	48 85 c9             	test   %rcx,%rcx
    6665:	0f 84 51 ff ff ff    	je     65bc <fwp_loop_fields68.constprop.0+0x1cc>
    666b:	44 0f b6 07          	movzbl (%rdi),%r8d
    666f:	41 80 f8 02          	cmp    $0x2,%r8b
    6673:	0f 85 17 ff ff ff    	jne    6590 <fwp_loop_fields68.constprop.0+0x1a0>
    6679:	66 85 c0             	test   %ax,%ax
    667c:	0f 84 2e ff ff ff    	je     65b0 <fwp_loop_fields68.constprop.0+0x1c0>
    6682:	4b 89 34 ee          	mov    %rsi,(%r14,%r13,8)
    6686:	49 83 c5 01          	add    $0x1,%r13
    668a:	4c 39 ed             	cmp    %r13,%rbp
    668d:	0f 85 3a ff ff ff    	jne    65cd <fwp_loop_fields68.constprop.0+0x1dd>
    6693:	66 90                	xchg   %ax,%ax
    6695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    669c:	00 00 00 00 
    66a0:	4d 89 fe             	mov    %r15,%r14
    66a3:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    66a8:	48 89 ea             	mov    %rbp,%rdx
    66ab:	4c 89 f7             	mov    %r14,%rdi
    66ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    66b3:	e8 18 dc ff ff       	call   42d0 <fwp_mem_free>
    66b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    66bd:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    66c2:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    66c7:	48 89 c7             	mov    %rax,%rdi
    66ca:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    66cf:	e8 1c ec ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    66d4:	4c 89 ff             	mov    %r15,%rdi
    66d7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    66dc:	e8 2f f2 ff ff       	call   5910 <fwp_drop0>
    66e1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    66e5:	bf 01 00 00 00       	mov    $0x1,%edi
    66ea:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    66f1:	00 
    66f2:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    66f9:	00 
    66fa:	e8 01 ea ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    66ff:	48 8b 0d d2 a3 01 00 	mov    0x1a3d2(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    6706:	49 89 c6             	mov    %rax,%r14
    6709:	48 2b 05 a0 a3 01 00 	sub    0x1a3a0(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    6710:	48 c1 e1 10          	shl    $0x10,%rcx
    6714:	48 39 c8             	cmp    %rcx,%rax
    6717:	73 59                	jae    6772 <fwp_loop_fields68.constprop.0+0x382>
    6719:	48 89 c1             	mov    %rax,%rcx
    671c:	48 c1 e9 10          	shr    $0x10,%rcx
    6720:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6724:	48 8b 0d cd a3 01 00 	mov    0x1a3cd(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    672b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    672f:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    6733:	4d 85 ff             	test   %r15,%r15
    6736:	74 3a                	je     6772 <fwp_loop_fields68.constprop.0+0x382>
    6738:	0f b6 31             	movzbl (%rcx),%esi
    673b:	40 80 fe 02          	cmp    $0x2,%sil
    673f:	0f 84 6b 07 00 00    	je     6eb0 <fwp_loop_fields68.constprop.0+0xac0>
    6745:	40 80 fe 01          	cmp    $0x1,%sil
    6749:	75 27                	jne    6772 <fwp_loop_fields68.constprop.0+0x382>
    674b:	8b 71 18             	mov    0x18(%rcx),%esi
    674e:	0f b7 c0             	movzwl %ax,%eax
    6751:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6754:	48 0f af c6          	imul   %rsi,%rax
    6758:	48 c1 e8 20          	shr    $0x20,%rax
    675c:	48 39 c8             	cmp    %rcx,%rax
    675f:	73 11                	jae    6772 <fwp_loop_fields68.constprop.0+0x382>
    6761:	49 01 c7             	add    %rax,%r15
    6764:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6768:	0f 84 55 07 00 00    	je     6ec3 <fwp_loop_fields68.constprop.0+0xad3>
    676e:	41 c6 07 01          	movb   $0x1,(%r15)
    6772:	48 8b 34 24          	mov    (%rsp),%rsi
    6776:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    677b:	e8 c0 ec ff ff       	call   5440 <fwp_map_items>
    6780:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    6786:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
    678b:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6792:	00 00 00 00 00 
    6797:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    679c:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    67a3:	00 
    67a4:	48 85 ed             	test   %rbp,%rbp
    67a7:	0f 84 d5 00 00 00    	je     6882 <fwp_loop_fields68.constprop.0+0x492>
    67ad:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    67b2:	45 31 ff             	xor    %r15d,%r15d
    67b5:	48 89 c3             	mov    %rax,%rbx
    67b8:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    67bd:	eb 5f                	jmp    681e <fwp_loop_fields68.constprop.0+0x42e>
    67bf:	90                   	nop
    67c0:	40 80 fe 01          	cmp    $0x1,%sil
    67c4:	75 3f                	jne    6805 <fwp_loop_fields68.constprop.0+0x415>
    67c6:	8b 72 18             	mov    0x18(%rdx),%esi
    67c9:	0f b7 c0             	movzwl %ax,%eax
    67cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67cf:	48 0f af c6          	imul   %rsi,%rax
    67d3:	48 c1 e8 20          	shr    $0x20,%rax
    67d7:	48 39 d0             	cmp    %rdx,%rax
    67da:	73 29                	jae    6805 <fwp_loop_fields68.constprop.0+0x415>
    67dc:	48 01 c7             	add    %rax,%rdi
    67df:	0f b6 07             	movzbl (%rdi),%eax
    67e2:	84 c0                	test   %al,%al
    67e4:	74 1f                	je     6805 <fwp_loop_fields68.constprop.0+0x415>
    67e6:	8b 35 d4 ab 01 00    	mov    0x1abd4(%rip),%esi        # 213c0 <iteration_active>
    67ec:	85 f6                	test   %esi,%esi
    67ee:	74 08                	je     67f8 <fwp_loop_fields68.constprop.0+0x408>
    67f0:	48 83 05 b0 ab 01 00 	addq   $0x1,0x1abb0(%rip)        # 213a8 <iteration_retains>
    67f7:	01 
    67f8:	3c fd                	cmp    $0xfd,%al
    67fa:	0f 87 a0 06 00 00    	ja     6ea0 <fwp_loop_fields68.constprop.0+0xab0>
    6800:	83 c0 01             	add    $0x1,%eax
    6803:	88 07                	mov    %al,(%rdi)
    6805:	4d 8b 75 08          	mov    0x8(%r13),%r14
    6809:	4c 89 ef             	mov    %r13,%rdi
    680c:	e8 df ee ff ff       	call   56f0 <fwp_drop4>
    6811:	4e 89 34 fb          	mov    %r14,(%rbx,%r15,8)
    6815:	49 83 c7 01          	add    $0x1,%r15
    6819:	49 39 ef             	cmp    %rbp,%r15
    681c:	74 5a                	je     6878 <fwp_loop_fields68.constprop.0+0x488>
    681e:	4e 8b 2c fb          	mov    (%rbx,%r15,8),%r13
    6822:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6829:	00 
    682a:	4c 89 e8             	mov    %r13,%rax
    682d:	48 c1 e2 10          	shl    $0x10,%rdx
    6831:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6838:	00 
    6839:	48 39 d0             	cmp    %rdx,%rax
    683c:	73 c7                	jae    6805 <fwp_loop_fields68.constprop.0+0x415>
    683e:	48 89 c2             	mov    %rax,%rdx
    6841:	48 c1 ea 10          	shr    $0x10,%rdx
    6845:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6849:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6850:	00 
    6851:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6855:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    6859:	48 85 ff             	test   %rdi,%rdi
    685c:	74 a7                	je     6805 <fwp_loop_fields68.constprop.0+0x415>
    685e:	0f b6 32             	movzbl (%rdx),%esi
    6861:	40 80 fe 02          	cmp    $0x2,%sil
    6865:	0f 85 55 ff ff ff    	jne    67c0 <fwp_loop_fields68.constprop.0+0x3d0>
    686b:	66 85 c0             	test   %ax,%ax
    686e:	75 95                	jne    6805 <fwp_loop_fields68.constprop.0+0x415>
    6870:	e9 6a ff ff ff       	jmp    67df <fwp_loop_fields68.constprop.0+0x3ef>
    6875:	0f 1f 00             	nopl   (%rax)
    6878:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    687d:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    6882:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    6887:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
    688c:	4c 89 ff             	mov    %r15,%rdi
    688f:	e8 5c ea ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    6894:	4c 89 fe             	mov    %r15,%rsi
    6897:	48 89 c7             	mov    %rax,%rdi
    689a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    689f:	e8 9c eb ff ff       	call   5440 <fwp_map_items>
    68a4:	48 8b 0d 2d a2 01 00 	mov    0x1a22d(%rip),%rcx        # 20ad8 <fwp_heap+0x13d8>
    68ab:	48 89 c5             	mov    %rax,%rbp
    68ae:	4c 89 f0             	mov    %r14,%rax
    68b1:	48 2b 05 f8 a1 01 00 	sub    0x1a1f8(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    68b8:	48 c1 e1 10          	shl    $0x10,%rcx
    68bc:	48 39 c8             	cmp    %rcx,%rax
    68bf:	73 6d                	jae    692e <fwp_loop_fields68.constprop.0+0x53e>
    68c1:	48 89 c1             	mov    %rax,%rcx
    68c4:	48 c1 e9 10          	shr    $0x10,%rcx
    68c8:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    68cc:	48 8b 0d 25 a2 01 00 	mov    0x1a225(%rip),%rcx        # 20af8 <fwp_heap+0x13f8>
    68d3:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    68d7:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    68db:	48 85 ff             	test   %rdi,%rdi
    68de:	74 4e                	je     692e <fwp_loop_fields68.constprop.0+0x53e>
    68e0:	0f b6 31             	movzbl (%rcx),%esi
    68e3:	40 80 fe 02          	cmp    $0x2,%sil
    68e7:	0f 84 f3 05 00 00    	je     6ee0 <fwp_loop_fields68.constprop.0+0xaf0>
    68ed:	40 80 fe 01          	cmp    $0x1,%sil
    68f1:	75 3b                	jne    692e <fwp_loop_fields68.constprop.0+0x53e>
    68f3:	8b 71 18             	mov    0x18(%rcx),%esi
    68f6:	0f b7 c0             	movzwl %ax,%eax
    68f9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68fc:	48 0f af c6          	imul   %rsi,%rax
    6900:	48 c1 e8 20          	shr    $0x20,%rax
    6904:	48 39 c8             	cmp    %rcx,%rax
    6907:	73 25                	jae    692e <fwp_loop_fields68.constprop.0+0x53e>
    6909:	48 01 c7             	add    %rax,%rdi
    690c:	0f b6 07             	movzbl (%rdi),%eax
    690f:	84 c0                	test   %al,%al
    6911:	74 1b                	je     692e <fwp_loop_fields68.constprop.0+0x53e>
    6913:	8b 0d a7 aa 01 00    	mov    0x1aaa7(%rip),%ecx        # 213c0 <iteration_active>
    6919:	85 c9                	test   %ecx,%ecx
    691b:	0f 85 df 05 00 00    	jne    6f00 <fwp_loop_fields68.constprop.0+0xb10>
    6921:	3c fd                	cmp    $0xfd,%al
    6923:	0f 87 2a 06 00 00    	ja     6f53 <fwp_loop_fields68.constprop.0+0xb63>
    6929:	83 c0 01             	add    $0x1,%eax
    692c:	88 07                	mov    %al,(%rdi)
    692e:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
    6933:	4d 89 f5             	mov    %r14,%r13
    6936:	4d 85 ff             	test   %r15,%r15
    6939:	0f 84 19 05 00 00    	je     6e58 <fwp_loop_fields68.constprop.0+0xa68>
    693f:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    6944:	49 89 ee             	mov    %rbp,%r14
    6947:	eb 3d                	jmp    6986 <fwp_loop_fields68.constprop.0+0x596>
    6949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6950:	40 80 fe 01          	cmp    $0x1,%sil
    6954:	75 27                	jne    697d <fwp_loop_fields68.constprop.0+0x58d>
    6956:	8b 72 18             	mov    0x18(%rdx),%esi
    6959:	0f b7 c0             	movzwl %ax,%eax
    695c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    695f:	48 0f af c6          	imul   %rsi,%rax
    6963:	48 c1 e8 20          	shr    $0x20,%rax
    6967:	48 39 d0             	cmp    %rdx,%rax
    696a:	73 11                	jae    697d <fwp_loop_fields68.constprop.0+0x58d>
    696c:	48 01 c5             	add    %rax,%rbp
    696f:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    6973:	0f 84 87 04 00 00    	je     6e00 <fwp_loop_fields68.constprop.0+0xa10>
    6979:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    697d:	4d 85 ff             	test   %r15,%r15
    6980:	0f 84 8a 00 00 00    	je     6a10 <fwp_loop_fields68.constprop.0+0x620>
    6986:	49 83 ef 01          	sub    $0x1,%r15
    698a:	66 49 0f 6e e5       	movq   %r13,%xmm4
    698f:	48 89 de             	mov    %rbx,%rsi
    6992:	bf 01 00 00 00       	mov    $0x1,%edi
    6997:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    699d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    69a1:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    69a8:	00 
    69a9:	e8 52 e7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    69ae:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    69b5:	00 
    69b6:	49 89 c5             	mov    %rax,%r13
    69b9:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    69c0:	00 
    69c1:	48 c1 e2 10          	shl    $0x10,%rdx
    69c5:	48 39 d0             	cmp    %rdx,%rax
    69c8:	73 b3                	jae    697d <fwp_loop_fields68.constprop.0+0x58d>
    69ca:	48 89 c2             	mov    %rax,%rdx
    69cd:	48 c1 ea 10          	shr    $0x10,%rdx
    69d1:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    69d5:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    69dc:	00 
    69dd:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    69e1:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    69e5:	48 85 ed             	test   %rbp,%rbp
    69e8:	74 93                	je     697d <fwp_loop_fields68.constprop.0+0x58d>
    69ea:	0f b6 32             	movzbl (%rdx),%esi
    69ed:	40 80 fe 02          	cmp    $0x2,%sil
    69f1:	0f 85 59 ff ff ff    	jne    6950 <fwp_loop_fields68.constprop.0+0x560>
    69f7:	66 85 c0             	test   %ax,%ax
    69fa:	0f 84 6f ff ff ff    	je     696f <fwp_loop_fields68.constprop.0+0x57f>
    6a00:	4d 85 ff             	test   %r15,%r15
    6a03:	75 81                	jne    6986 <fwp_loop_fields68.constprop.0+0x596>
    6a05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a0c:	00 00 00 00 
    6a10:	4c 89 f5             	mov    %r14,%rbp
    6a13:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    6a18:	48 89 ef             	mov    %rbp,%rdi
    6a1b:	e8 b0 d8 ff ff       	call   42d0 <fwp_mem_free>
    6a20:	4c 89 f7             	mov    %r14,%rdi
    6a23:	e8 e8 ee ff ff       	call   5910 <fwp_drop0>
    6a28:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    6a2d:	e8 de ee ff ff       	call   5910 <fwp_drop0>
    6a32:	48 8b 34 24          	mov    (%rsp),%rsi
    6a36:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    6a3b:	e8 00 ea ff ff       	call   5440 <fwp_map_items>
    6a40:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    6a46:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    6a4b:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6a52:	00 00 00 00 00 
    6a57:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6a5c:	0f 11 ac 24 88 00 00 	movups %xmm5,0x88(%rsp)
    6a63:	00 
    6a64:	48 85 d2             	test   %rdx,%rdx
    6a67:	0f 84 e0 00 00 00    	je     6b4d <fwp_loop_fields68.constprop.0+0x75d>
    6a6d:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
    6a72:	45 31 f6             	xor    %r14d,%r14d
    6a75:	49 89 d7             	mov    %rdx,%r15
    6a78:	48 89 c3             	mov    %rax,%rbx
    6a7b:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
    6a80:	eb 64                	jmp    6ae6 <fwp_loop_fields68.constprop.0+0x6f6>
    6a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a88:	40 80 fe 01          	cmp    $0x1,%sil
    6a8c:	75 3f                	jne    6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6a8e:	8b 72 18             	mov    0x18(%rdx),%esi
    6a91:	0f b7 c0             	movzwl %ax,%eax
    6a94:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a97:	48 0f af c6          	imul   %rsi,%rax
    6a9b:	48 c1 e8 20          	shr    $0x20,%rax
    6a9f:	48 39 d0             	cmp    %rdx,%rax
    6aa2:	73 29                	jae    6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6aa4:	48 01 c7             	add    %rax,%rdi
    6aa7:	0f b6 07             	movzbl (%rdi),%eax
    6aaa:	84 c0                	test   %al,%al
    6aac:	74 1f                	je     6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6aae:	8b 15 0c a9 01 00    	mov    0x1a90c(%rip),%edx        # 213c0 <iteration_active>
    6ab4:	85 d2                	test   %edx,%edx
    6ab6:	74 08                	je     6ac0 <fwp_loop_fields68.constprop.0+0x6d0>
    6ab8:	48 83 05 e8 a8 01 00 	addq   $0x1,0x1a8e8(%rip)        # 213a8 <iteration_retains>
    6abf:	01 
    6ac0:	3c fd                	cmp    $0xfd,%al
    6ac2:	0f 87 c8 03 00 00    	ja     6e90 <fwp_loop_fields68.constprop.0+0xaa0>
    6ac8:	83 c0 01             	add    $0x1,%eax
    6acb:	88 07                	mov    %al,(%rdi)
    6acd:	4c 8b 6d 10          	mov    0x10(%rbp),%r13
    6ad1:	48 89 ef             	mov    %rbp,%rdi
    6ad4:	e8 17 ec ff ff       	call   56f0 <fwp_drop4>
    6ad9:	4e 89 2c f3          	mov    %r13,(%rbx,%r14,8)
    6add:	49 83 c6 01          	add    $0x1,%r14
    6ae1:	4d 39 fe             	cmp    %r15,%r14
    6ae4:	74 5a                	je     6b40 <fwp_loop_fields68.constprop.0+0x750>
    6ae6:	4a 8b 2c f3          	mov    (%rbx,%r14,8),%rbp
    6aea:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    6af1:	00 
    6af2:	48 89 e8             	mov    %rbp,%rax
    6af5:	48 c1 e2 10          	shl    $0x10,%rdx
    6af9:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    6b00:	00 
    6b01:	48 39 d0             	cmp    %rdx,%rax
    6b04:	73 c7                	jae    6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6b06:	48 89 c2             	mov    %rax,%rdx
    6b09:	48 c1 ea 10          	shr    $0x10,%rdx
    6b0d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6b11:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    6b18:	00 
    6b19:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6b1d:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    6b21:	48 85 ff             	test   %rdi,%rdi
    6b24:	74 a7                	je     6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6b26:	0f b6 32             	movzbl (%rdx),%esi
    6b29:	40 80 fe 02          	cmp    $0x2,%sil
    6b2d:	0f 85 55 ff ff ff    	jne    6a88 <fwp_loop_fields68.constprop.0+0x698>
    6b33:	66 85 c0             	test   %ax,%ax
    6b36:	75 95                	jne    6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6b38:	e9 6a ff ff ff       	jmp    6aa7 <fwp_loop_fields68.constprop.0+0x6b7>
    6b3d:	0f 1f 00             	nopl   (%rax)
    6b40:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
    6b45:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
    6b4a:	4c 89 fa             	mov    %r15,%rdx
    6b4d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b52:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    6b57:	e8 94 e7 ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    6b5c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    6b61:	49 89 c6             	mov    %rax,%r14
    6b64:	e8 b7 ef ff ff       	call   5b20 <fwp_drop6>
    6b69:	48 89 de             	mov    %rbx,%rsi
    6b6c:	bf 01 00 00 00       	mov    $0x1,%edi
    6b71:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
    6b78:	00 00 00 00 00 
    6b7d:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
    6b84:	00 
    6b85:	e8 76 e5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    6b8a:	48 8b 15 47 9f 01 00 	mov    0x19f47(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    6b91:	48 89 c3             	mov    %rax,%rbx
    6b94:	48 2b 05 15 9f 01 00 	sub    0x19f15(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    6b9b:	48 c1 e2 10          	shl    $0x10,%rdx
    6b9f:	48 39 d0             	cmp    %rdx,%rax
    6ba2:	73 59                	jae    6bfd <fwp_loop_fields68.constprop.0+0x80d>
    6ba4:	48 89 c2             	mov    %rax,%rdx
    6ba7:	48 c1 ea 10          	shr    $0x10,%rdx
    6bab:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    6baf:	48 8b 15 42 9f 01 00 	mov    0x19f42(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    6bb6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    6bba:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    6bbe:	4d 85 f6             	test   %r14,%r14
    6bc1:	74 3a                	je     6bfd <fwp_loop_fields68.constprop.0+0x80d>
    6bc3:	0f b6 32             	movzbl (%rdx),%esi
    6bc6:	40 80 fe 02          	cmp    $0x2,%sil
    6bca:	0f 84 00 03 00 00    	je     6ed0 <fwp_loop_fields68.constprop.0+0xae0>
    6bd0:	40 80 fe 01          	cmp    $0x1,%sil
    6bd4:	75 27                	jne    6bfd <fwp_loop_fields68.constprop.0+0x80d>
    6bd6:	8b 72 18             	mov    0x18(%rdx),%esi
    6bd9:	0f b7 c0             	movzwl %ax,%eax
    6bdc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bdf:	48 0f af c6          	imul   %rsi,%rax
    6be3:	48 c1 e8 20          	shr    $0x20,%rax
    6be7:	48 39 d0             	cmp    %rdx,%rax
    6bea:	73 11                	jae    6bfd <fwp_loop_fields68.constprop.0+0x80d>
    6bec:	49 01 c6             	add    %rax,%r14
    6bef:	41 80 3e ff          	cmpb   $0xff,(%r14)
    6bf3:	0f 84 45 03 00 00    	je     6f3e <fwp_loop_fields68.constprop.0+0xb4e>
    6bf9:	41 c6 06 01          	movb   $0x1,(%r14)
    6bfd:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    6c02:	48 89 df             	mov    %rbx,%rdi
    6c05:	e8 36 e8 ff ff       	call   5440 <fwp_map_items>
    6c0a:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    6c10:	48 8b 34 24          	mov    (%rsp),%rsi
    6c14:	4c 89 ef             	mov    %r13,%rdi
    6c17:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6c1c:	49 89 c6             	mov    %rax,%r14
    6c1f:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6c26:	00 00 00 00 00 
    6c2b:	0f 11 b4 24 88 00 00 	movups %xmm6,0x88(%rsp)
    6c32:	00 
    6c33:	e8 08 e8 ff ff       	call   5440 <fwp_map_items>
    6c38:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
    6c3d:	48 89 c7             	mov    %rax,%rdi
    6c40:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    6c45:	49 39 c7             	cmp    %rax,%r15
    6c48:	4c 0f 47 f8          	cmova  %rax,%r15
    6c4c:	4d 85 ff             	test   %r15,%r15
    6c4f:	0f 84 db 02 00 00    	je     6f30 <fwp_loop_fields68.constprop.0+0xb40>
    6c55:	31 c0                	xor    %eax,%eax
    6c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c5e:	00 00 
    6c60:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    6c66:	f2 0f 58 04 c7       	addsd  (%rdi,%rax,8),%xmm0
    6c6b:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    6c71:	48 83 c0 01          	add    $0x1,%rax
    6c75:	49 39 c7             	cmp    %rax,%r15
    6c78:	75 e6                	jne    6c60 <fwp_loop_fields68.constprop.0+0x870>
    6c7a:	e8 51 d6 ff ff       	call   42d0 <fwp_mem_free>
    6c7f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6c84:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
    6c89:	e8 62 e6 ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    6c8e:	4c 89 ef             	mov    %r13,%rdi
    6c91:	49 89 c6             	mov    %rax,%r14
    6c94:	e8 77 ec ff ff       	call   5910 <fwp_drop0>
    6c99:	48 89 df             	mov    %rbx,%rdi
    6c9c:	e8 6f ec ff ff       	call   5910 <fwp_drop0>
    6ca1:	48 8b 34 24          	mov    (%rsp),%rsi
    6ca5:	4c 89 f7             	mov    %r14,%rdi
    6ca8:	e8 93 e7 ff ff       	call   5440 <fwp_map_items>
    6cad:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    6cb3:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    6cb8:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6cbf:	00 00 00 00 00 
    6cc4:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6cc9:	0f 11 bc 24 88 00 00 	movups %xmm7,0x88(%rsp)
    6cd0:	00 
    6cd1:	48 85 c9             	test   %rcx,%rcx
    6cd4:	74 24                	je     6cfa <fwp_loop_fields68.constprop.0+0x90a>
    6cd6:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
    6cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce0:	f2 0f 10 05 08 59 00 	movsd  0x5908(%rip),%xmm0        # c5f0 <msg.3+0x20>
    6ce7:	00 
    6ce8:	f2 0f 59 00          	mulsd  (%rax),%xmm0
    6cec:	48 83 c0 08          	add    $0x8,%rax
    6cf0:	f2 0f 11 40 f8       	movsd  %xmm0,-0x8(%rax)
    6cf5:	48 39 c2             	cmp    %rax,%rdx
    6cf8:	75 e6                	jne    6ce0 <fwp_loop_fields68.constprop.0+0x8f0>
    6cfa:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6cff:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
    6d04:	e8 e7 e5 ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    6d09:	4c 89 f7             	mov    %r14,%rdi
    6d0c:	48 89 c3             	mov    %rax,%rbx
    6d0f:	e8 fc eb ff ff       	call   5910 <fwp_drop0>
    6d14:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    6d19:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6d1e:	e8 1d e7 ff ff       	call   5440 <fwp_map_items>
    6d23:	66 0f 6f 6c 24 10    	movdqa 0x10(%rsp),%xmm5
    6d29:	48 8b 34 24          	mov    (%rsp),%rsi
    6d2d:	48 89 df             	mov    %rbx,%rdi
    6d30:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    6d35:	49 89 c6             	mov    %rax,%r14
    6d38:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
    6d3f:	00 00 00 00 00 
    6d44:	0f 11 ac 24 88 00 00 	movups %xmm5,0x88(%rsp)
    6d4b:	00 
    6d4c:	e8 ef e6 ff ff       	call   5440 <fwp_map_items>
    6d51:	4c 8b 64 24 68       	mov    0x68(%rsp),%r12
    6d56:	48 89 c7             	mov    %rax,%rdi
    6d59:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    6d5e:	49 39 c4             	cmp    %rax,%r12
    6d61:	4c 0f 47 e0          	cmova  %rax,%r12
    6d65:	4d 85 e4             	test   %r12,%r12
    6d68:	0f 84 b2 01 00 00    	je     6f20 <fwp_loop_fields68.constprop.0+0xb30>
    6d6e:	31 c0                	xor    %eax,%eax
    6d70:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d7c:	00 00 00 00 
    6d80:	f2 41 0f 10 04 c6    	movsd  (%r14,%rax,8),%xmm0
    6d86:	f2 0f 5c 04 c7       	subsd  (%rdi,%rax,8),%xmm0
    6d8b:	f2 41 0f 11 04 c6    	movsd  %xmm0,(%r14,%rax,8)
    6d91:	48 83 c0 01          	add    $0x1,%rax
    6d95:	49 39 c4             	cmp    %rax,%r12
    6d98:	75 e6                	jne    6d80 <fwp_loop_fields68.constprop.0+0x990>
    6d9a:	e8 31 d5 ff ff       	call   42d0 <fwp_mem_free>
    6d9f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6da4:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    6da9:	e8 42 e5 ff ff       	call   52f0 <fwp_map_finish_protected.isra.0>
    6dae:	48 89 df             	mov    %rbx,%rdi
    6db1:	48 89 c5             	mov    %rax,%rbp
    6db4:	e8 57 eb ff ff       	call   5910 <fwp_drop0>
    6db9:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    6dbe:	e8 4d eb ff ff       	call   5910 <fwp_drop0>
    6dc3:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
    6dc9:	75 6d                	jne    6e38 <fwp_loop_fields68.constprop.0+0xa48>
    6dcb:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    6dd2:	00 
    6dd3:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6dda:	00 00 
    6ddc:	0f 85 85 01 00 00    	jne    6f67 <fwp_loop_fields68.constprop.0+0xb77>
    6de2:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    6de9:	48 89 e8             	mov    %rbp,%rax
    6dec:	5b                   	pop    %rbx
    6ded:	5d                   	pop    %rbp
    6dee:	41 5c                	pop    %r12
    6df0:	41 5d                	pop    %r13
    6df2:	41 5e                	pop    %r14
    6df4:	41 5f                	pop    %r15
    6df6:	c3                   	ret
    6df7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dfe:	00 00 
    6e00:	48 89 ef             	mov    %rbp,%rdi
    6e03:	e8 88 d2 ff ff       	call   4090 <fwp_rc_forget_slot>
    6e08:	e9 6c fb ff ff       	jmp    6979 <fwp_loop_fields68.constprop.0+0x589>
    6e0d:	0f 1f 00             	nopl   (%rax)
    6e10:	48 89 cf             	mov    %rcx,%rdi
    6e13:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
    6e18:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6e1d:	e8 6e d2 ff ff       	call   4090 <fwp_rc_forget_slot>
    6e22:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    6e27:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6e2c:	e9 88 f7 ff ff       	jmp    65b9 <fwp_loop_fields68.constprop.0+0x1c9>
    6e31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e38:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    6e3d:	31 c0                	xor    %eax,%eax
    6e3f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
    6e44:	48 83 c2 ff          	add    $0xffffffffffffffff,%rdx
    6e48:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6e4d:	0f 90 c0             	seto   %al
    6e50:	e9 06 f6 ff ff       	jmp    645b <fwp_loop_fields68.constprop.0+0x6b>
    6e55:	0f 1f 00             	nopl   (%rax)
    6e58:	48 85 ed             	test   %rbp,%rbp
    6e5b:	0f 84 bf fb ff ff    	je     6a20 <fwp_loop_fields68.constprop.0+0x630>
    6e61:	e9 b2 fb ff ff       	jmp    6a18 <fwp_loop_fields68.constprop.0+0x628>
    6e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e6d:	00 00 00 
    6e70:	48 8d 9c 24 b0 00 00 	lea    0xb0(%rsp),%rbx
    6e77:	00 
    6e78:	4d 85 f6             	test   %r14,%r14
    6e7b:	0f 84 3c f8 ff ff    	je     66bd <fwp_loop_fields68.constprop.0+0x2cd>
    6e81:	e9 25 f8 ff ff       	jmp    66ab <fwp_loop_fields68.constprop.0+0x2bb>
    6e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e8d:	00 00 00 
    6e90:	e8 db d0 ff ff       	call   3f70 <fwp_rc_wide_dup>
    6e95:	e9 33 fc ff ff       	jmp    6acd <fwp_loop_fields68.constprop.0+0x6dd>
    6e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ea0:	e8 cb d0 ff ff       	call   3f70 <fwp_rc_wide_dup>
    6ea5:	e9 5b f9 ff ff       	jmp    6805 <fwp_loop_fields68.constprop.0+0x415>
    6eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6eb0:	66 85 c0             	test   %ax,%ax
    6eb3:	0f 85 b9 f8 ff ff    	jne    6772 <fwp_loop_fields68.constprop.0+0x382>
    6eb9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    6ebd:	0f 85 ab f8 ff ff    	jne    676e <fwp_loop_fields68.constprop.0+0x37e>
    6ec3:	4c 89 ff             	mov    %r15,%rdi
    6ec6:	e8 c5 d1 ff ff       	call   4090 <fwp_rc_forget_slot>
    6ecb:	e9 9e f8 ff ff       	jmp    676e <fwp_loop_fields68.constprop.0+0x37e>
    6ed0:	66 85 c0             	test   %ax,%ax
    6ed3:	0f 85 24 fd ff ff    	jne    6bfd <fwp_loop_fields68.constprop.0+0x80d>
    6ed9:	e9 11 fd ff ff       	jmp    6bef <fwp_loop_fields68.constprop.0+0x7ff>
    6ede:	66 90                	xchg   %ax,%ax
    6ee0:	66 85 c0             	test   %ax,%ax
    6ee3:	0f 85 45 fa ff ff    	jne    692e <fwp_loop_fields68.constprop.0+0x53e>
    6ee9:	e9 1e fa ff ff       	jmp    690c <fwp_loop_fields68.constprop.0+0x51c>
    6eee:	66 90                	xchg   %ax,%ax
    6ef0:	66 85 c0             	test   %ax,%ax
    6ef3:	0f 85 0d f6 ff ff    	jne    6506 <fwp_loop_fields68.constprop.0+0x116>
    6ef9:	e9 e4 f5 ff ff       	jmp    64e2 <fwp_loop_fields68.constprop.0+0xf2>
    6efe:	66 90                	xchg   %ax,%ax
    6f00:	48 83 05 a0 a4 01 00 	addq   $0x1,0x1a4a0(%rip)        # 213a8 <iteration_retains>
    6f07:	01 
    6f08:	e9 14 fa ff ff       	jmp    6921 <fwp_loop_fields68.constprop.0+0x531>
    6f0d:	0f 1f 00             	nopl   (%rax)
    6f10:	48 83 05 90 a4 01 00 	addq   $0x1,0x1a490(%rip)        # 213a8 <iteration_retains>
    6f17:	01 
    6f18:	e9 dc f5 ff ff       	jmp    64f9 <fwp_loop_fields68.constprop.0+0x109>
    6f1d:	0f 1f 00             	nopl   (%rax)
    6f20:	48 85 ff             	test   %rdi,%rdi
    6f23:	0f 84 76 fe ff ff    	je     6d9f <fwp_loop_fields68.constprop.0+0x9af>
    6f29:	e9 6c fe ff ff       	jmp    6d9a <fwp_loop_fields68.constprop.0+0x9aa>
    6f2e:	66 90                	xchg   %ax,%ax
    6f30:	48 85 ff             	test   %rdi,%rdi
    6f33:	0f 84 46 fd ff ff    	je     6c7f <fwp_loop_fields68.constprop.0+0x88f>
    6f39:	e9 3c fd ff ff       	jmp    6c7a <fwp_loop_fields68.constprop.0+0x88a>
    6f3e:	4c 89 f7             	mov    %r14,%rdi
    6f41:	e8 4a d1 ff ff       	call   4090 <fwp_rc_forget_slot>
    6f46:	e9 ae fc ff ff       	jmp    6bf9 <fwp_loop_fields68.constprop.0+0x809>
    6f4b:	45 31 ff             	xor    %r15d,%r15d
    6f4e:	e9 23 f5 ff ff       	jmp    6476 <fwp_loop_fields68.constprop.0+0x86>
    6f53:	e8 18 d0 ff ff       	call   3f70 <fwp_rc_wide_dup>
    6f58:	e9 d1 f9 ff ff       	jmp    692e <fwp_loop_fields68.constprop.0+0x53e>
    6f5d:	e8 0e d0 ff ff       	call   3f70 <fwp_rc_wide_dup>
    6f62:	e9 9f f5 ff ff       	jmp    6506 <fwp_loop_fields68.constprop.0+0x116>
    6f67:	e8 d4 b4 ff ff       	call   2440 <__stack_chk_fail@plt>
    6f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f70 <fwp_write>:
    6f70:	41 57                	push   %r15
    6f72:	41 56                	push   %r14
    6f74:	41 55                	push   %r13
    6f76:	41 54                	push   %r12
    6f78:	55                   	push   %rbp
    6f79:	53                   	push   %rbx
    6f7a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    6f81:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    6f88:	00 00 
    6f8a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    6f91:	00 
    6f92:	49 89 d4             	mov    %rdx,%r12
    6f95:	8b 12                	mov    (%rdx),%edx
    6f97:	83 fa 19             	cmp    $0x19,%edx
    6f9a:	77 6a                	ja     7006 <fwp_write+0x96>
    6f9c:	48 89 f5             	mov    %rsi,%rbp
    6f9f:	89 d0                	mov    %edx,%eax
    6fa1:	89 ce                	mov    %ecx,%esi
    6fa3:	48 89 fb             	mov    %rdi,%rbx
    6fa6:	48 8d 0d b3 55 00 00 	lea    0x55b3(%rip),%rcx        # c560 <_IO_stdin_used+0x560>
    6fad:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    6fb1:	48 01 c8             	add    %rcx,%rax
    6fb4:	3e ff e0             	notrack jmp *%rax
    6fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fbe:	00 00 
    6fc0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    6fc4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    6fc8:	48 89 ca             	mov    %rcx,%rdx
    6fcb:	48 85 c9             	test   %rcx,%rcx
    6fce:	0f 88 9c 0c 00 00    	js     7c70 <fwp_write+0xd00>
    6fd4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    6fdb:	00 
    6fdc:	48 89 c6             	mov    %rax,%rsi
    6fdf:	4c 89 e7             	mov    %r12,%rdi
    6fe2:	e8 19 ba ff ff       	call   2a00 <fwp_fmt_u128>
    6fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fee:	00 00 
    6ff0:	4c 89 e7             	mov    %r12,%rdi
    6ff3:	e8 38 b4 ff ff       	call   2430 <strlen@plt>
    6ff8:	4c 89 e6             	mov    %r12,%rsi
    6ffb:	48 89 df             	mov    %rbx,%rdi
    6ffe:	48 89 c2             	mov    %rax,%rdx
    7001:	e8 1a c0 ff ff       	call   3020 <buf_put>
    7006:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    700d:	00 
    700e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7015:	00 00 
    7017:	0f 85 28 04 00 00    	jne    7445 <fwp_write+0x4d5>
    701d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    7024:	5b                   	pop    %rbx
    7025:	5d                   	pop    %rbp
    7026:	41 5c                	pop    %r12
    7028:	41 5d                	pop    %r13
    702a:	41 5e                	pop    %r14
    702c:	41 5f                	pop    %r15
    702e:	c3                   	ret
    702f:	90                   	nop
    7030:	49 89 e9             	mov    %rbp,%r9
    7033:	4c 8d 05 fa 50 00 00 	lea    0x50fa(%rip),%r8        # c134 <_IO_stdin_used+0x134>
    703a:	b9 00 02 00 00       	mov    $0x200,%ecx
    703f:	ba 02 00 00 00       	mov    $0x2,%edx
    7044:	be 00 02 00 00       	mov    $0x200,%esi
    7049:	31 c0                	xor    %eax,%eax
    704b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7052:	00 
    7053:	e8 38 b3 ff ff       	call   2390 <__snprintf_chk@plt>
    7058:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    705f:	00 
    7060:	e8 cb b3 ff ff       	call   2430 <strlen@plt>
    7065:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    706c:	00 
    706d:	48 89 df             	mov    %rbx,%rdi
    7070:	48 89 c2             	mov    %rax,%rdx
    7073:	e8 a8 bf ff ff       	call   3020 <buf_put>
    7078:	eb 8c                	jmp    7006 <fwp_write+0x96>
    707a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7080:	49 89 e9             	mov    %rbp,%r9
    7083:	4c 8d 05 a5 50 00 00 	lea    0x50a5(%rip),%r8        # c12f <_IO_stdin_used+0x12f>
    708a:	eb ae                	jmp    703a <fwp_write+0xca>
    708c:	0f 1f 40 00          	nopl   0x0(%rax)
    7090:	83 fa 13             	cmp    $0x13,%edx
    7093:	48 8d 05 8b 50 00 00 	lea    0x508b(%rip),%rax        # c125 <_IO_stdin_used+0x125>
    709a:	48 8d 35 89 50 00 00 	lea    0x5089(%rip),%rsi        # c12a <_IO_stdin_used+0x12a>
    70a1:	ba 04 00 00 00       	mov    $0x4,%edx
    70a6:	48 0f 44 f0          	cmove  %rax,%rsi
    70aa:	45 31 ed             	xor    %r13d,%r13d
    70ad:	e8 6e bf ff ff       	call   3020 <buf_put>
    70b2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    70b7:	0f 84 a3 08 00 00    	je     7960 <fwp_write+0x9f0>
    70bd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    70c2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    70c7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    70cc:	48 89 df             	mov    %rbx,%rdi
    70cf:	49 0f 44 c5          	cmove  %r13,%rax
    70d3:	31 c9                	xor    %ecx,%ecx
    70d5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    70da:	e8 91 fe ff ff       	call   6f70 <fwp_write>
    70df:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    70e4:	0f 84 6e 09 00 00    	je     7a58 <fwp_write+0xae8>
    70ea:	49 83 c5 01          	add    $0x1,%r13
    70ee:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    70f2:	0f 83 68 08 00 00    	jae    7960 <fwp_write+0x9f0>
    70f8:	ba 02 00 00 00       	mov    $0x2,%edx
    70fd:	48 8d 35 70 50 00 00 	lea    0x5070(%rip),%rsi        # c174 <_IO_stdin_used+0x174>
    7104:	48 89 df             	mov    %rbx,%rdi
    7107:	e8 14 bf ff ff       	call   3020 <buf_put>
    710c:	eb af                	jmp    70bd <fwp_write+0x14d>
    710e:	66 90                	xchg   %ax,%ax
    7110:	ba 06 00 00 00       	mov    $0x6,%edx
    7115:	48 8d 35 31 50 00 00 	lea    0x5031(%rip),%rsi        # c14d <_IO_stdin_used+0x14d>
    711c:	48 83 c5 10          	add    $0x10,%rbp
    7120:	e8 fb be ff ff       	call   3020 <buf_put>
    7125:	48 89 ef             	mov    %rbp,%rdi
    7128:	e8 03 b3 ff ff       	call   2430 <strlen@plt>
    712d:	48 89 ee             	mov    %rbp,%rsi
    7130:	48 89 df             	mov    %rbx,%rdi
    7133:	48 89 c2             	mov    %rax,%rdx
    7136:	e8 e5 be ff ff       	call   3020 <buf_put>
    713b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7140:	ba 01 00 00 00       	mov    $0x1,%edx
    7145:	48 89 df             	mov    %rbx,%rdi
    7148:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    714d:	e8 ce be ff ff       	call   3020 <buf_put>
    7152:	e9 af fe ff ff       	jmp    7006 <fwp_write+0x96>
    7157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    715e:	00 00 
    7160:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7167:	00 
    7168:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    716f:	00 00 
    7171:	0f 85 ce 02 00 00    	jne    7445 <fwp_write+0x4d5>
    7177:	ba 0a 00 00 00       	mov    $0xa,%edx
    717c:	48 8d 35 b6 4f 00 00 	lea    0x4fb6(%rip),%rsi        # c139 <_IO_stdin_used+0x139>
    7183:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    718a:	48 89 df             	mov    %rbx,%rdi
    718d:	5b                   	pop    %rbx
    718e:	5d                   	pop    %rbp
    718f:	41 5c                	pop    %r12
    7191:	41 5d                	pop    %r13
    7193:	41 5e                	pop    %r14
    7195:	41 5f                	pop    %r15
    7197:	e9 84 be ff ff       	jmp    3020 <buf_put>
    719c:	0f 1f 40 00          	nopl   0x0(%rax)
    71a0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    71a5:	4d 85 ed             	test   %r13,%r13
    71a8:	0f 84 02 0c 00 00    	je     7db0 <fwp_write+0xe40>
    71ae:	48 8d 35 cc 4f 00 00 	lea    0x4fcc(%rip),%rsi        # c181 <_IO_stdin_used+0x181>
    71b5:	4c 89 ef             	mov    %r13,%rdi
    71b8:	e8 53 b3 ff ff       	call   2510 <strcmp@plt>
    71bd:	41 89 c1             	mov    %eax,%r9d
    71c0:	85 c0                	test   %eax,%eax
    71c2:	0f 84 6c 0c 00 00    	je     7e34 <fwp_write+0xec4>
    71c8:	4c 89 ef             	mov    %r13,%rdi
    71cb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    71d0:	e8 5b b2 ff ff       	call   2430 <strlen@plt>
    71d5:	4c 89 ee             	mov    %r13,%rsi
    71d8:	48 89 df             	mov    %rbx,%rdi
    71db:	48 89 c2             	mov    %rax,%rdx
    71de:	e8 3d be ff ff       	call   3020 <buf_put>
    71e3:	ba 01 00 00 00       	mov    $0x1,%edx
    71e8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    71ed:	48 89 df             	mov    %rbx,%rdi
    71f0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    71f5:	e8 26 be ff ff       	call   3020 <buf_put>
    71fa:	ba 01 00 00 00       	mov    $0x1,%edx
    71ff:	4c 89 fe             	mov    %r15,%rsi
    7202:	48 89 df             	mov    %rbx,%rdi
    7205:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    720a:	e8 11 be ff ff       	call   3020 <buf_put>
    720f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    7214:	45 31 f6             	xor    %r14d,%r14d
    7217:	85 d2                	test   %edx,%edx
    7219:	0f 8e 81 0a 00 00    	jle    7ca0 <fwp_write+0xd30>
    721f:	45 31 ed             	xor    %r13d,%r13d
    7222:	4d 85 ed             	test   %r13,%r13
    7225:	0f 85 75 07 00 00    	jne    79a0 <fwp_write+0xa30>
    722b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    7232:	00 
    7233:	45 85 f6             	test   %r14d,%r14d
    7236:	0f 84 84 07 00 00    	je     79c0 <fwp_write+0xa50>
    723c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    7241:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    7246:	48 89 df             	mov    %rbx,%rdi
    7249:	49 83 c5 01          	add    $0x1,%r13
    724d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    7251:	31 c9                	xor    %ecx,%ecx
    7253:	e8 18 fd ff ff       	call   6f70 <fwp_write>
    7258:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    725d:	7f c3                	jg     7222 <fwp_write+0x2b2>
    725f:	45 85 f6             	test   %r14d,%r14d
    7262:	0f 84 38 0a 00 00    	je     7ca0 <fwp_write+0xd30>
    7268:	b8 29 00 00 00       	mov    $0x29,%eax
    726d:	ba 01 00 00 00       	mov    $0x1,%edx
    7272:	4c 89 fe             	mov    %r15,%rsi
    7275:	48 89 df             	mov    %rbx,%rdi
    7278:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    727c:	e8 9f bd ff ff       	call   3020 <buf_put>
    7281:	e9 80 fd ff ff       	jmp    7006 <fwp_write+0x96>
    7286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    728d:	00 00 00 
    7290:	ba 01 00 00 00       	mov    $0x1,%edx
    7295:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    729a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    729f:	e8 7c bd ff ff       	call   3020 <buf_put>
    72a4:	48 85 ed             	test   %rbp,%rbp
    72a7:	0f 84 93 06 00 00    	je     7940 <fwp_write+0x9d0>
    72ad:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    72b1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    72b6:	31 c9                	xor    %ecx,%ecx
    72b8:	48 89 df             	mov    %rbx,%rdi
    72bb:	e8 b0 fc ff ff       	call   6f70 <fwp_write>
    72c0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    72c4:	48 85 ed             	test   %rbp,%rbp
    72c7:	0f 84 73 06 00 00    	je     7940 <fwp_write+0x9d0>
    72cd:	ba 02 00 00 00       	mov    $0x2,%edx
    72d2:	48 8d 35 9b 4e 00 00 	lea    0x4e9b(%rip),%rsi        # c174 <_IO_stdin_used+0x174>
    72d9:	48 89 df             	mov    %rbx,%rdi
    72dc:	e8 3f bd ff ff       	call   3020 <buf_put>
    72e1:	eb ca                	jmp    72ad <fwp_write+0x33d>
    72e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72e8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    72ec:	85 f6                	test   %esi,%esi
    72ee:	0f 84 fc 07 00 00    	je     7af0 <fwp_write+0xb80>
    72f4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    72fb:	00 
    72fc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7303:	00 00 
    7305:	0f 85 3a 01 00 00    	jne    7445 <fwp_write+0x4d5>
    730b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    730f:	4c 89 ea             	mov    %r13,%rdx
    7312:	e9 6c fe ff ff       	jmp    7183 <fwp_write+0x213>
    7317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    731e:	00 00 
    7320:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    7325:	ba 01 00 00 00       	mov    $0x1,%edx
    732a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    732f:	48 89 ee             	mov    %rbp,%rsi
    7332:	e8 e9 bc ff ff       	call   3020 <buf_put>
    7337:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    733c:	4c 89 e7             	mov    %r12,%rdi
    733f:	e8 ec b0 ff ff       	call   2430 <strlen@plt>
    7344:	4c 89 e6             	mov    %r12,%rsi
    7347:	48 89 df             	mov    %rbx,%rdi
    734a:	48 89 c2             	mov    %rax,%rdx
    734d:	e8 ce bc ff ff       	call   3020 <buf_put>
    7352:	ba 01 00 00 00       	mov    $0x1,%edx
    7357:	48 89 ee             	mov    %rbp,%rsi
    735a:	48 89 df             	mov    %rbx,%rdi
    735d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    7362:	e8 b9 bc ff ff       	call   3020 <buf_put>
    7367:	e9 9a fc ff ff       	jmp    7006 <fwp_write+0x96>
    736c:	0f 1f 40 00          	nopl   0x0(%rax)
    7370:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    7375:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    7379:	0f 8a 8e 0b 00 00    	jp     7f0d <fwp_write+0xf9d>
    737f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    7383:	66 0f 54 05 f5 52 00 	andpd  0x52f5(%rip),%xmm0        # c680 <msg.3+0xb0>
    738a:	00 
    738b:	bd 01 00 00 00       	mov    $0x1,%ebp
    7390:	66 0f 2e 05 78 52 00 	ucomisd 0x5278(%rip),%xmm0        # c610 <msg.3+0x40>
    7397:	00 
    7398:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    739f:	00 
    73a0:	0f 87 b2 09 00 00    	ja     7d58 <fwp_write+0xde8>
    73a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    73ad:	00 00 00 
    73b0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    73b4:	89 ee                	mov    %ebp,%esi
    73b6:	4c 89 e7             	mov    %r12,%rdi
    73b9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    73be:	e8 8d bf ff ff       	call   3350 <fwp_format_g.constprop.0>
    73c3:	31 f6                	xor    %esi,%esi
    73c5:	4c 89 e7             	mov    %r12,%rdi
    73c8:	e8 23 b0 ff ff       	call   23f0 <strtod@plt>
    73cd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    73d2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    73d6:	7a 06                	jp     73de <fwp_write+0x46e>
    73d8:	0f 84 e9 01 00 00    	je     75c7 <fwp_write+0x657>
    73de:	83 c5 01             	add    $0x1,%ebp
    73e1:	83 fd 12             	cmp    $0x12,%ebp
    73e4:	75 ca                	jne    73b0 <fwp_write+0x440>
    73e6:	be 11 00 00 00       	mov    $0x11,%esi
    73eb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    73ef:	4c 89 e7             	mov    %r12,%rdi
    73f2:	e8 59 bf ff ff       	call   3350 <fwp_format_g.constprop.0>
    73f7:	e9 cb 01 00 00       	jmp    75c7 <fwp_write+0x657>
    73fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7400:	48 83 fd 01          	cmp    $0x1,%rbp
    7404:	0f 84 e6 08 00 00    	je     7cf0 <fwp_write+0xd80>
    740a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    740e:	b8 02 00 00 00       	mov    $0x2,%eax
    7413:	ba 01 00 00 00       	mov    $0x1,%edx
    7418:	48 0f 44 d0          	cmove  %rax,%rdx
    741c:	48 8d 35 fa 4c 00 00 	lea    0x4cfa(%rip),%rsi        # c11d <_IO_stdin_used+0x11d>
    7423:	48 8d 05 f8 4c 00 00 	lea    0x4cf8(%rip),%rax        # c122 <_IO_stdin_used+0x122>
    742a:	48 0f 44 f0          	cmove  %rax,%rsi
    742e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7435:	00 
    7436:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    743d:	00 00 
    743f:	0f 84 3e fd ff ff    	je     7183 <fwp_write+0x213>
    7445:	e8 f6 af ff ff       	call   2440 <__stack_chk_fail@plt>
    744a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7450:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    7455:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    745a:	e8 01 bb ff ff       	call   2f60 <buf_grow>
    745f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    7463:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    7469:	4c 03 0b             	add    (%rbx),%r9
    746c:	66 45 89 11          	mov    %r10w,(%r9)
    7470:	45 85 e4             	test   %r12d,%r12d
    7473:	0f 8e 07 05 00 00    	jle    7980 <fwp_write+0xa10>
    7479:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    7480:	55 55 55 
    7483:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    7488:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    748f:	aa aa aa 
    7492:	49 83 c1 01          	add    $0x1,%r9
    7496:	eb 45                	jmp    74dd <fwp_write+0x56d>
    7498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    749f:	00 
    74a0:	be 01 00 00 00       	mov    $0x1,%esi
    74a5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    74aa:	88 07                	mov    %al,(%rdi)
    74ac:	48 89 e8             	mov    %rbp,%rax
    74af:	49 f7 e8             	imul   %r8
    74b2:	48 89 e8             	mov    %rbp,%rax
    74b5:	48 c1 f8 3f          	sar    $0x3f,%rax
    74b9:	48 29 c2             	sub    %rax,%rdx
    74bc:	48 85 c9             	test   %rcx,%rcx
    74bf:	0f 95 c0             	setne  %al
    74c2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    74c6:	48 83 ef 01          	sub    $0x1,%rdi
    74ca:	48 21 c5             	and    %rax,%rbp
    74cd:	48 29 ea             	sub    %rbp,%rdx
    74d0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    74d4:	49 39 f9             	cmp    %rdi,%r9
    74d7:	0f 84 a3 04 00 00    	je     7980 <fwp_write+0xa10>
    74dd:	48 89 e8             	mov    %rbp,%rax
    74e0:	49 f7 e8             	imul   %r8
    74e3:	48 89 e8             	mov    %rbp,%rax
    74e6:	48 c1 f8 3f          	sar    $0x3f,%rax
    74ea:	48 89 d1             	mov    %rdx,%rcx
    74ed:	48 29 c1             	sub    %rax,%rcx
    74f0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    74f4:	48 89 e9             	mov    %rbp,%rcx
    74f7:	48 29 c1             	sub    %rax,%rcx
    74fa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    74fe:	49 f7 e2             	mul    %r10
    7501:	b8 30 00 00 00       	mov    $0x30,%eax
    7506:	48 89 d6             	mov    %rdx,%rsi
    7509:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    750d:	48 d1 ee             	shr    $1,%rsi
    7510:	48 01 f2             	add    %rsi,%rdx
    7513:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    7517:	48 29 d6             	sub    %rdx,%rsi
    751a:	74 8e                	je     74aa <fwp_write+0x53a>
    751c:	48 83 fe 01          	cmp    $0x1,%rsi
    7520:	0f 85 7a ff ff ff    	jne    74a0 <fwp_write+0x530>
    7526:	31 f6                	xor    %esi,%esi
    7528:	b8 2b 00 00 00       	mov    $0x2b,%eax
    752d:	e9 78 ff ff ff       	jmp    74aa <fwp_write+0x53a>
    7532:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7538:	66 0f 6e cd          	movd   %ebp,%xmm1
    753c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    753f:	0f 8a c8 09 00 00    	jp     7f0d <fwp_write+0xf9d>
    7545:	0f 28 c1             	movaps %xmm1,%xmm0
    7548:	0f 54 05 21 51 00 00 	andps  0x5121(%rip),%xmm0        # c670 <msg.3+0xa0>
    754f:	0f 2e 05 ae 4a 00 00 	ucomiss 0x4aae(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    7556:	0f 87 24 08 00 00    	ja     7d80 <fwp_write+0xe10>
    755c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    7560:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    7566:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    756d:	00 
    756e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    7572:	66 49 0f 7e d7       	movq   %xmm2,%r15
    7577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    757e:	00 00 
    7580:	44 89 ee             	mov    %r13d,%esi
    7583:	66 49 0f 6e c7       	movq   %r15,%xmm0
    7588:	4c 89 e7             	mov    %r12,%rdi
    758b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    7590:	e8 bb bd ff ff       	call   3350 <fwp_format_g.constprop.0>
    7595:	31 f6                	xor    %esi,%esi
    7597:	4c 89 e7             	mov    %r12,%rdi
    759a:	e8 f1 ae ff ff       	call   2490 <strtof@plt>
    759f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    75a4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    75a7:	7a 02                	jp     75ab <fwp_write+0x63b>
    75a9:	74 1c                	je     75c7 <fwp_write+0x657>
    75ab:	41 83 c5 01          	add    $0x1,%r13d
    75af:	41 83 fd 0a          	cmp    $0xa,%r13d
    75b3:	75 cb                	jne    7580 <fwp_write+0x610>
    75b5:	be 09 00 00 00       	mov    $0x9,%esi
    75ba:	66 49 0f 6e c7       	movq   %r15,%xmm0
    75bf:	4c 89 e7             	mov    %r12,%rdi
    75c2:	e8 89 bd ff ff       	call   3350 <fwp_format_g.constprop.0>
    75c7:	4c 89 e7             	mov    %r12,%rdi
    75ca:	e8 11 bb ff ff       	call   30e0 <fwp_finish_float>
    75cf:	e9 1c fa ff ff       	jmp    6ff0 <fwp_write+0x80>
    75d4:	0f 1f 40 00          	nopl   0x0(%rax)
    75d8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    75dc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    75e0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    75e7:	00 
    75e8:	48 89 ef             	mov    %rbp,%rdi
    75eb:	e8 10 b4 ff ff       	call   2a00 <fwp_fmt_u128>
    75f0:	48 89 ef             	mov    %rbp,%rdi
    75f3:	e8 38 ae ff ff       	call   2430 <strlen@plt>
    75f8:	48 89 ee             	mov    %rbp,%rsi
    75fb:	48 89 df             	mov    %rbx,%rdi
    75fe:	48 89 c2             	mov    %rax,%rdx
    7601:	e8 1a ba ff ff       	call   3020 <buf_put>
    7606:	e9 fb f9 ff ff       	jmp    7006 <fwp_write+0x96>
    760b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7610:	ba 06 00 00 00       	mov    $0x6,%edx
    7615:	48 8d 35 5b 4b 00 00 	lea    0x4b5b(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    761c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    7622:	e8 f9 b9 ff ff       	call   3020 <buf_put>
    7627:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    762e:	ff ff 7f 
    7631:	48 23 55 00          	and    0x0(%rbp),%rdx
    7635:	0f 84 86 02 00 00    	je     78c1 <fwp_write+0x951>
    763b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    7640:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    7644:	48 85 d2             	test   %rdx,%rdx
    7647:	0f 84 ae 00 00 00    	je     76fb <fwp_write+0x78b>
    764d:	8b 0a                	mov    (%rdx),%ecx
    764f:	83 f9 1c             	cmp    $0x1c,%ecx
    7652:	0f 84 58 06 00 00    	je     7cb0 <fwp_write+0xd40>
    7658:	83 f9 1b             	cmp    $0x1b,%ecx
    765b:	0f 87 9a 00 00 00    	ja     76fb <fwp_write+0x78b>
    7661:	be 01 00 00 00       	mov    $0x1,%esi
    7666:	48 d3 e6             	shl    %cl,%rsi
    7669:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    766f:	0f 85 4b 04 00 00    	jne    7ac0 <fwp_write+0xb50>
    7675:	f7 c6 84 04 00 00    	test   $0x484,%esi
    767b:	0f 85 0f 04 00 00    	jne    7a90 <fwp_write+0xb20>
    7681:	83 e6 21             	and    $0x21,%esi
    7684:	74 75                	je     76fb <fwp_write+0x78b>
    7686:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    768b:	48 85 ff             	test   %rdi,%rdi
    768e:	79 07                	jns    7697 <fwp_write+0x727>
    7690:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    7694:	4c 01 ee             	add    %r13,%rsi
    7697:	48 0f be 3e          	movsbq (%rsi),%rdi
    769b:	85 c9                	test   %ecx,%ecx
    769d:	40 0f b6 f7          	movzbl %dil,%esi
    76a1:	48 0f 44 f7          	cmove  %rdi,%rsi
    76a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76ac:	00 00 00 00 
    76b0:	31 c9                	xor    %ecx,%ecx
    76b2:	48 89 df             	mov    %rbx,%rdi
    76b5:	49 83 c5 01          	add    $0x1,%r13
    76b9:	e8 b2 f8 ff ff       	call   6f70 <fwp_write>
    76be:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    76c5:	ff ff 7f 
    76c8:	48 23 55 00          	and    0x0(%rbp),%rdx
    76cc:	49 39 d5             	cmp    %rdx,%r13
    76cf:	0f 83 ec 01 00 00    	jae    78c1 <fwp_write+0x951>
    76d5:	ba 02 00 00 00       	mov    $0x2,%edx
    76da:	48 89 df             	mov    %rbx,%rdi
    76dd:	48 8d 35 90 4a 00 00 	lea    0x4a90(%rip),%rsi        # c174 <_IO_stdin_used+0x174>
    76e4:	e8 37 b9 ff ff       	call   3020 <buf_put>
    76e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    76ee:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    76f2:	48 85 d2             	test   %rdx,%rdx
    76f5:	0f 85 52 ff ff ff    	jne    764d <fwp_write+0x6dd>
    76fb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    7700:	48 85 ff             	test   %rdi,%rdi
    7703:	0f 88 cf 05 00 00    	js     7cd8 <fwp_write+0xd68>
    7709:	48 8b 31             	mov    (%rcx),%rsi
    770c:	eb a2                	jmp    76b0 <fwp_write+0x740>
    770e:	66 90                	xchg   %ax,%ax
    7710:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7717:	00 
    7718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    771f:	00 00 
    7721:	0f 85 1e fd ff ff    	jne    7445 <fwp_write+0x4d5>
    7727:	ba 08 00 00 00       	mov    $0x8,%edx
    772c:	48 8d 35 11 4a 00 00 	lea    0x4a11(%rip),%rsi        # c144 <_IO_stdin_used+0x144>
    7733:	e9 4b fa ff ff       	jmp    7183 <fwp_write+0x213>
    7738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    773f:	00 
    7740:	89 e8                	mov    %ebp,%eax
    7742:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    7749:	76 03                	jbe    774e <fwp_write+0x7de>
    774b:	8b 45 00             	mov    0x0(%rbp),%eax
    774e:	41 89 c6             	mov    %eax,%r14d
    7751:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    7756:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    775b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    775f:	4c 89 ef             	mov    %r13,%rdi
    7762:	e8 c9 ac ff ff       	call   2430 <strlen@plt>
    7767:	4c 89 ee             	mov    %r13,%rsi
    776a:	48 89 df             	mov    %rbx,%rdi
    776d:	48 89 c2             	mov    %rax,%rdx
    7770:	e8 ab b8 ff ff       	call   3020 <buf_put>
    7775:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    777a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    777e:	85 f6                	test   %esi,%esi
    7780:	0f 8e 80 f8 ff ff    	jle    7006 <fwp_write+0x96>
    7786:	45 31 ed             	xor    %r13d,%r13d
    7789:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    778e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    7793:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7798:	ba 01 00 00 00       	mov    $0x1,%edx
    779d:	4c 89 fe             	mov    %r15,%rsi
    77a0:	48 89 04 24          	mov    %rax,(%rsp)
    77a4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    77a9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    77ad:	48 89 df             	mov    %rbx,%rdi
    77b0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    77b4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    77b9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    77be:	e8 5d b8 ff ff       	call   3020 <buf_put>
    77c3:	41 8b 06             	mov    (%r14),%eax
    77c6:	83 f8 0e             	cmp    $0xe,%eax
    77c9:	0f 84 71 02 00 00    	je     7a40 <fwp_write+0xad0>
    77cf:	83 f8 10             	cmp    $0x10,%eax
    77d2:	0f 84 38 02 00 00    	je     7a10 <fwp_write+0xaa0>
    77d8:	83 f8 0a             	cmp    $0xa,%eax
    77db:	0f 84 7f 04 00 00    	je     7c60 <fwp_write+0xcf0>
    77e1:	0f 8f f9 00 00 00    	jg     78e0 <fwp_write+0x970>
    77e7:	83 f8 03             	cmp    $0x3,%eax
    77ea:	0f 8f 50 04 00 00    	jg     7c40 <fwp_write+0xcd0>
    77f0:	85 c0                	test   %eax,%eax
    77f2:	78 10                	js     7804 <fwp_write+0x894>
    77f4:	48 8b 04 24          	mov    (%rsp),%rax
    77f8:	48 c1 e8 3f          	shr    $0x3f,%rax
    77fc:	85 c0                	test   %eax,%eax
    77fe:	0f 85 f9 00 00 00    	jne    78fd <fwp_write+0x98d>
    7804:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7809:	48 8b 34 24          	mov    (%rsp),%rsi
    780d:	31 c9                	xor    %ecx,%ecx
    780f:	48 89 df             	mov    %rbx,%rdi
    7812:	e8 59 f7 ff ff       	call   6f70 <fwp_write>
    7817:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    781c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7821:	49 83 c5 01          	add    $0x1,%r13
    7825:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    7829:	0f 8f 5f ff ff ff    	jg     778e <fwp_write+0x81e>
    782f:	e9 d2 f7 ff ff       	jmp    7006 <fwp_write+0x96>
    7834:	0f 1f 40 00          	nopl   0x0(%rax)
    7838:	ba 06 00 00 00       	mov    $0x6,%edx
    783d:	48 8d 35 26 49 00 00 	lea    0x4926(%rip),%rsi        # c16a <_IO_stdin_used+0x16a>
    7844:	45 31 ed             	xor    %r13d,%r13d
    7847:	e8 d4 b7 ff ff       	call   3020 <buf_put>
    784c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    7851:	75 19                	jne    786c <fwp_write+0x8fc>
    7853:	eb 6c                	jmp    78c1 <fwp_write+0x951>
    7855:	0f 1f 00             	nopl   (%rax)
    7858:	ba 02 00 00 00       	mov    $0x2,%edx
    785d:	48 8d 35 10 49 00 00 	lea    0x4910(%rip),%rsi        # c174 <_IO_stdin_used+0x174>
    7864:	48 89 df             	mov    %rbx,%rdi
    7867:	e8 b4 b7 ff ff       	call   3020 <buf_put>
    786c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    7872:	b9 00 02 00 00       	mov    $0x200,%ecx
    7877:	31 c0                	xor    %eax,%eax
    7879:	49 83 c5 01          	add    $0x1,%r13
    787d:	4c 8d 05 ed 48 00 00 	lea    0x48ed(%rip),%r8        # c171 <_IO_stdin_used+0x171>
    7884:	ba 02 00 00 00       	mov    $0x2,%edx
    7889:	be 00 02 00 00       	mov    $0x200,%esi
    788e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7895:	00 
    7896:	e8 f5 aa ff ff       	call   2390 <__snprintf_chk@plt>
    789b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    78a2:	00 
    78a3:	e8 88 ab ff ff       	call   2430 <strlen@plt>
    78a8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    78af:	00 
    78b0:	48 89 df             	mov    %rbx,%rdi
    78b3:	48 89 c2             	mov    %rax,%rdx
    78b6:	e8 65 b7 ff ff       	call   3020 <buf_put>
    78bb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    78bf:	72 97                	jb     7858 <fwp_write+0x8e8>
    78c1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    78c6:	ba 01 00 00 00       	mov    $0x1,%edx
    78cb:	48 89 df             	mov    %rbx,%rdi
    78ce:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    78d3:	e8 48 b7 ff ff       	call   3020 <buf_put>
    78d8:	e9 29 f7 ff ff       	jmp    7006 <fwp_write+0x96>
    78dd:	0f 1f 00             	nopl   (%rax)
    78e0:	83 f8 0b             	cmp    $0xb,%eax
    78e3:	0f 85 1b ff ff ff    	jne    7804 <fwp_write+0x894>
    78e9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    78ee:	66 0f 50 c3          	movmskpd %xmm3,%eax
    78f2:	83 e0 01             	and    $0x1,%eax
    78f5:	85 c0                	test   %eax,%eax
    78f7:	0f 84 07 ff ff ff    	je     7804 <fwp_write+0x894>
    78fd:	4c 89 fe             	mov    %r15,%rsi
    7900:	48 89 df             	mov    %rbx,%rdi
    7903:	ba 01 00 00 00       	mov    $0x1,%edx
    7908:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    790d:	e8 0e b7 ff ff       	call   3020 <buf_put>
    7912:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    7917:	48 8b 34 24          	mov    (%rsp),%rsi
    791b:	31 c9                	xor    %ecx,%ecx
    791d:	48 89 df             	mov    %rbx,%rdi
    7920:	e8 4b f6 ff ff       	call   6f70 <fwp_write>
    7925:	ba 01 00 00 00       	mov    $0x1,%edx
    792a:	4c 89 fe             	mov    %r15,%rsi
    792d:	48 89 df             	mov    %rbx,%rdi
    7930:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    7935:	e8 e6 b6 ff ff       	call   3020 <buf_put>
    793a:	e9 d8 fe ff ff       	jmp    7817 <fwp_write+0x8a7>
    793f:	90                   	nop
    7940:	ba 01 00 00 00       	mov    $0x1,%edx
    7945:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    794a:	48 89 df             	mov    %rbx,%rdi
    794d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    7952:	e8 c9 b6 ff ff       	call   3020 <buf_put>
    7957:	e9 aa f6 ff ff       	jmp    7006 <fwp_write+0x96>
    795c:	0f 1f 40 00          	nopl   0x0(%rax)
    7960:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7965:	ba 01 00 00 00       	mov    $0x1,%edx
    796a:	48 89 df             	mov    %rbx,%rdi
    796d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    7972:	e8 a9 b6 ff ff       	call   3020 <buf_put>
    7977:	e9 8a f6 ff ff       	jmp    7006 <fwp_write+0x96>
    797c:	0f 1f 40 00          	nopl   0x0(%rax)
    7980:	48 8b 43 08          	mov    0x8(%rbx),%rax
    7984:	48 8b 13             	mov    (%rbx),%rdx
    7987:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    798c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    7990:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    7994:	e9 6d f6 ff ff       	jmp    7006 <fwp_write+0x96>
    7999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79a0:	ba 02 00 00 00       	mov    $0x2,%edx
    79a5:	48 8d 35 c8 47 00 00 	lea    0x47c8(%rip),%rsi        # c174 <_IO_stdin_used+0x174>
    79ac:	48 89 df             	mov    %rbx,%rdi
    79af:	e8 6c b6 ff ff       	call   3020 <buf_put>
    79b4:	e9 72 f8 ff ff       	jmp    722b <fwp_write+0x2bb>
    79b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79c0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    79c5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    79ca:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    79ce:	48 89 f7             	mov    %rsi,%rdi
    79d1:	48 89 34 24          	mov    %rsi,(%rsp)
    79d5:	e8 56 aa ff ff       	call   2430 <strlen@plt>
    79da:	48 8b 34 24          	mov    (%rsp),%rsi
    79de:	48 89 df             	mov    %rbx,%rdi
    79e1:	48 89 c2             	mov    %rax,%rdx
    79e4:	e8 37 b6 ff ff       	call   3020 <buf_put>
    79e9:	ba 03 00 00 00       	mov    $0x3,%edx
    79ee:	48 8d 35 a2 47 00 00 	lea    0x47a2(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    79f5:	48 89 df             	mov    %rbx,%rdi
    79f8:	e8 23 b6 ff ff       	call   3020 <buf_put>
    79fd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7a02:	e9 35 f8 ff ff       	jmp    723c <fwp_write+0x2cc>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    7a15:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7a19:	48 85 ff             	test   %rdi,%rdi
    7a1c:	0f 84 e2 fd ff ff    	je     7804 <fwp_write+0x894>
    7a22:	48 8d 35 58 47 00 00 	lea    0x4758(%rip),%rsi        # c181 <_IO_stdin_used+0x181>
    7a29:	e8 e2 aa ff ff       	call   2510 <strcmp@plt>
    7a2e:	85 c0                	test   %eax,%eax
    7a30:	0f 95 c0             	setne  %al
    7a33:	0f b6 c0             	movzbl %al,%eax
    7a36:	e9 c1 fd ff ff       	jmp    77fc <fwp_write+0x88c>
    7a3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a40:	31 c0                	xor    %eax,%eax
    7a42:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    7a49:	00 
    7a4a:	0f 97 c0             	seta   %al
    7a4d:	e9 aa fd ff ff       	jmp    77fc <fwp_write+0x88c>
    7a52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a58:	48 89 df             	mov    %rbx,%rdi
    7a5b:	ba 02 00 00 00       	mov    $0x2,%edx
    7a60:	48 8d 35 17 47 00 00 	lea    0x4717(%rip),%rsi        # c17e <_IO_stdin_used+0x17e>
    7a67:	e8 b4 b5 ff ff       	call   3020 <buf_put>
    7a6c:	4c 89 e8             	mov    %r13,%rax
    7a6f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    7a74:	31 c9                	xor    %ecx,%ecx
    7a76:	48 c1 e0 04          	shl    $0x4,%rax
    7a7a:	48 89 df             	mov    %rbx,%rdi
    7a7d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    7a82:	e8 e9 f4 ff ff       	call   6f70 <fwp_write>
    7a87:	e9 5e f6 ff ff       	jmp    70ea <fwp_write+0x17a>
    7a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a90:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    7a95:	48 85 ff             	test   %rdi,%rdi
    7a98:	79 0c                	jns    7aa6 <fwp_write+0xb36>
    7a9a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    7aa1:	00 
    7aa2:	48 03 75 10          	add    0x10(%rbp),%rsi
    7aa6:	48 63 3e             	movslq (%rsi),%rdi
    7aa9:	83 f9 02             	cmp    $0x2,%ecx
    7aac:	89 fe                	mov    %edi,%esi
    7aae:	48 0f 44 f7          	cmove  %rdi,%rsi
    7ab2:	e9 f9 fb ff ff       	jmp    76b0 <fwp_write+0x740>
    7ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7abe:	00 00 
    7ac0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    7ac5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    7aca:	48 85 ff             	test   %rdi,%rdi
    7acd:	0f 88 0f 03 00 00    	js     7de2 <fwp_write+0xe72>
    7ad3:	49 0f bf 38          	movswq (%r8),%rdi
    7ad7:	83 f9 01             	cmp    $0x1,%ecx
    7ada:	0f b7 f7             	movzwl %di,%esi
    7add:	48 0f 44 f7          	cmove  %rdi,%rsi
    7ae1:	e9 ca fb ff ff       	jmp    76b0 <fwp_write+0x740>
    7ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7aed:	00 00 00 
    7af0:	ba 01 00 00 00       	mov    $0x1,%edx
    7af5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7afa:	48 83 c5 08          	add    $0x8,%rbp
    7afe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    7b03:	e8 18 b5 ff ff       	call   3020 <buf_put>
    7b08:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    7b0d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    7b12:	4d 85 ed             	test   %r13,%r13
    7b15:	75 46                	jne    7b5d <fwp_write+0xbed>
    7b17:	e9 04 01 00 00       	jmp    7c20 <fwp_write+0xcb0>
    7b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b20:	41 80 f9 09          	cmp    $0x9,%r9b
    7b24:	0f 84 d6 00 00 00    	je     7c00 <fwp_write+0xc90>
    7b2a:	41 80 f9 0a          	cmp    $0xa,%r9b
    7b2e:	0f 85 9c 00 00 00    	jne    7bd0 <fwp_write+0xc60>
    7b34:	ba 02 00 00 00       	mov    $0x2,%edx
    7b39:	48 8d 35 1a 46 00 00 	lea    0x461a(%rip),%rsi        # c15a <_IO_stdin_used+0x15a>
    7b40:	48 89 df             	mov    %rbx,%rdi
    7b43:	e8 d8 b4 ff ff       	call   3020 <buf_put>
    7b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7b4f:	00 
    7b50:	48 83 c5 01          	add    $0x1,%rbp
    7b54:	49 39 ec             	cmp    %rbp,%r12
    7b57:	0f 84 c3 00 00 00    	je     7c20 <fwp_write+0xcb0>
    7b5d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    7b62:	41 80 f9 0d          	cmp    $0xd,%r9b
    7b66:	74 28                	je     7b90 <fwp_write+0xc20>
    7b68:	7e b6                	jle    7b20 <fwp_write+0xbb0>
    7b6a:	41 80 f9 22          	cmp    $0x22,%r9b
    7b6e:	74 40                	je     7bb0 <fwp_write+0xc40>
    7b70:	41 80 f9 5c          	cmp    $0x5c,%r9b
    7b74:	75 5a                	jne    7bd0 <fwp_write+0xc60>
    7b76:	ba 02 00 00 00       	mov    $0x2,%edx
    7b7b:	48 8d 35 d5 45 00 00 	lea    0x45d5(%rip),%rsi        # c157 <_IO_stdin_used+0x157>
    7b82:	48 89 df             	mov    %rbx,%rdi
    7b85:	e8 96 b4 ff ff       	call   3020 <buf_put>
    7b8a:	eb c4                	jmp    7b50 <fwp_write+0xbe0>
    7b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b90:	ba 02 00 00 00       	mov    $0x2,%edx
    7b95:	48 8d 35 c4 45 00 00 	lea    0x45c4(%rip),%rsi        # c160 <_IO_stdin_used+0x160>
    7b9c:	48 89 df             	mov    %rbx,%rdi
    7b9f:	e8 7c b4 ff ff       	call   3020 <buf_put>
    7ba4:	eb aa                	jmp    7b50 <fwp_write+0xbe0>
    7ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bad:	00 00 00 
    7bb0:	ba 02 00 00 00       	mov    $0x2,%edx
    7bb5:	48 8d 35 98 45 00 00 	lea    0x4598(%rip),%rsi        # c154 <_IO_stdin_used+0x154>
    7bbc:	48 89 df             	mov    %rbx,%rdi
    7bbf:	e8 5c b4 ff ff       	call   3020 <buf_put>
    7bc4:	eb 8a                	jmp    7b50 <fwp_write+0xbe0>
    7bc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bcd:	00 00 00 
    7bd0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    7bd4:	0f 86 2e 01 00 00    	jbe    7d08 <fwp_write+0xd98>
    7bda:	41 80 f9 7f          	cmp    $0x7f,%r9b
    7bde:	0f 84 24 01 00 00    	je     7d08 <fwp_write+0xd98>
    7be4:	ba 01 00 00 00       	mov    $0x1,%edx
    7be9:	4c 89 fe             	mov    %r15,%rsi
    7bec:	48 89 df             	mov    %rbx,%rdi
    7bef:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    7bf4:	e8 27 b4 ff ff       	call   3020 <buf_put>
    7bf9:	e9 52 ff ff ff       	jmp    7b50 <fwp_write+0xbe0>
    7bfe:	66 90                	xchg   %ax,%ax
    7c00:	ba 02 00 00 00       	mov    $0x2,%edx
    7c05:	48 8d 35 51 45 00 00 	lea    0x4551(%rip),%rsi        # c15d <_IO_stdin_used+0x15d>
    7c0c:	48 89 df             	mov    %rbx,%rdi
    7c0f:	e8 0c b4 ff ff       	call   3020 <buf_put>
    7c14:	e9 37 ff ff ff       	jmp    7b50 <fwp_write+0xbe0>
    7c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c20:	ba 01 00 00 00       	mov    $0x1,%edx
    7c25:	4c 89 fe             	mov    %r15,%rsi
    7c28:	48 89 df             	mov    %rbx,%rdi
    7c2b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    7c30:	e8 eb b3 ff ff       	call   3020 <buf_put>
    7c35:	e9 cc f3 ff ff       	jmp    7006 <fwp_write+0x96>
    7c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c40:	83 f8 04             	cmp    $0x4,%eax
    7c43:	0f 85 bb fb ff ff    	jne    7804 <fwp_write+0x894>
    7c49:	48 8b 04 24          	mov    (%rsp),%rax
    7c4d:	48 8b 40 08          	mov    0x8(%rax),%rax
    7c51:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7c56:	48 c1 e8 3f          	shr    $0x3f,%rax
    7c5a:	e9 96 fc ff ff       	jmp    78f5 <fwp_write+0x985>
    7c5f:	90                   	nop
    7c60:	8b 0c 24             	mov    (%rsp),%ecx
    7c63:	31 c0                	xor    %eax,%eax
    7c65:	85 c9                	test   %ecx,%ecx
    7c67:	0f 98 c0             	sets   %al
    7c6a:	e9 86 fc ff ff       	jmp    78f5 <fwp_write+0x985>
    7c6f:	90                   	nop
    7c70:	48 f7 d8             	neg    %rax
    7c73:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    7c7a:	00 
    7c7b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    7c82:	2d 
    7c83:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7c8a:	00 
    7c8b:	48 83 d2 00          	adc    $0x0,%rdx
    7c8f:	48 89 c6             	mov    %rax,%rsi
    7c92:	48 f7 da             	neg    %rdx
    7c95:	e8 66 ad ff ff       	call   2a00 <fwp_fmt_u128>
    7c9a:	e9 51 f3 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7c9f:	90                   	nop
    7ca0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    7ca5:	e9 c3 f5 ff ff       	jmp    726d <fwp_write+0x2fd>
    7caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cb0:	4c 89 e9             	mov    %r13,%rcx
    7cb3:	48 c1 e1 04          	shl    $0x4,%rcx
    7cb7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    7cbc:	48 85 ff             	test   %rdi,%rdi
    7cbf:	0f 89 eb f9 ff ff    	jns    76b0 <fwp_write+0x740>
    7cc5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    7cc9:	48 89 ce             	mov    %rcx,%rsi
    7ccc:	e9 df f9 ff ff       	jmp    76b0 <fwp_write+0x740>
    7cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cd8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    7cdf:	00 
    7ce0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    7ce4:	e9 20 fa ff ff       	jmp    7709 <fwp_write+0x799>
    7ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cf0:	ba 02 00 00 00       	mov    $0x2,%edx
    7cf5:	48 8d 35 23 44 00 00 	lea    0x4423(%rip),%rsi        # c11f <_IO_stdin_used+0x11f>
    7cfc:	e9 2d f7 ff ff       	jmp    742e <fwp_write+0x4be>
    7d01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d08:	4c 8d 05 54 44 00 00 	lea    0x4454(%rip),%r8        # c163 <_IO_stdin_used+0x163>
    7d0f:	b9 10 00 00 00       	mov    $0x10,%ecx
    7d14:	31 c0                	xor    %eax,%eax
    7d16:	ba 02 00 00 00       	mov    $0x2,%edx
    7d1b:	be 10 00 00 00       	mov    $0x10,%esi
    7d20:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7d27:	00 
    7d28:	e8 63 a6 ff ff       	call   2390 <__snprintf_chk@plt>
    7d2d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    7d34:	00 
    7d35:	e8 f6 a6 ff ff       	call   2430 <strlen@plt>
    7d3a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    7d41:	00 
    7d42:	48 89 df             	mov    %rbx,%rdi
    7d45:	48 89 c2             	mov    %rax,%rdx
    7d48:	e8 d3 b2 ff ff       	call   3020 <buf_put>
    7d4d:	e9 fe fd ff ff       	jmp    7b50 <fwp_write+0xbe0>
    7d52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d58:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7d5c:	48 8d 35 b6 43 00 00 	lea    0x43b6(%rip),%rsi        # c119 <_IO_stdin_used+0x119>
    7d63:	48 8d 05 ae 43 00 00 	lea    0x43ae(%rip),%rax        # c118 <_IO_stdin_used+0x118>
    7d6a:	4c 89 e7             	mov    %r12,%rdi
    7d6d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    7d71:	48 0f 46 f0          	cmovbe %rax,%rsi
    7d75:	e8 56 a6 ff ff       	call   23d0 <strcpy@plt>
    7d7a:	e9 71 f2 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7d7f:	90                   	nop
    7d80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7d84:	48 8d 35 8e 43 00 00 	lea    0x438e(%rip),%rsi        # c119 <_IO_stdin_used+0x119>
    7d8b:	48 8d 05 86 43 00 00 	lea    0x4386(%rip),%rax        # c118 <_IO_stdin_used+0x118>
    7d92:	0f 2f c8             	comiss %xmm0,%xmm1
    7d95:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7d9c:	00 
    7d9d:	4c 89 e7             	mov    %r12,%rdi
    7da0:	48 0f 46 f0          	cmovbe %rax,%rsi
    7da4:	e8 27 a6 ff ff       	call   23d0 <strcpy@plt>
    7da9:	e9 42 f2 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7dae:	66 90                	xchg   %ax,%ax
    7db0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    7db5:	45 85 c0             	test   %r8d,%r8d
    7db8:	75 34                	jne    7dee <fwp_write+0xe7e>
    7dba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7dc1:	00 
    7dc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7dc9:	00 00 
    7dcb:	0f 85 74 f6 ff ff    	jne    7445 <fwp_write+0x4d5>
    7dd1:	ba 02 00 00 00       	mov    $0x2,%edx
    7dd6:	48 8d 35 b7 43 00 00 	lea    0x43b7(%rip),%rsi        # c194 <_IO_stdin_used+0x194>
    7ddd:	e9 a1 f3 ff ff       	jmp    7183 <fwp_write+0x213>
    7de2:	48 03 75 10          	add    0x10(%rbp),%rsi
    7de6:	49 89 f0             	mov    %rsi,%r8
    7de9:	e9 e5 fc ff ff       	jmp    7ad3 <fwp_write+0xb63>
    7dee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    7df3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    7df8:	85 ff                	test   %edi,%edi
    7dfa:	0f 84 fa f3 ff ff    	je     71fa <fwp_write+0x28a>
    7e00:	ba 01 00 00 00       	mov    $0x1,%edx
    7e05:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    7e0a:	48 89 df             	mov    %rbx,%rdi
    7e0d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    7e12:	e8 09 b2 ff ff       	call   3020 <buf_put>
    7e17:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    7e1c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    7e21:	41 be 01 00 00 00    	mov    $0x1,%r14d
    7e27:	85 c0                	test   %eax,%eax
    7e29:	0f 8f f0 f3 ff ff    	jg     721f <fwp_write+0x2af>
    7e2f:	e9 34 f4 ff ff       	jmp    7268 <fwp_write+0x2f8>
    7e34:	48 8b 45 08          	mov    0x8(%rbp),%rax
    7e38:	49 89 c5             	mov    %rax,%r13
    7e3b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e40:	49 89 c4             	mov    %rax,%r12
    7e43:	49 c1 fd 3f          	sar    $0x3f,%r13
    7e47:	4c 09 e8             	or     %r13,%rax
    7e4a:	0f 84 a7 00 00 00    	je     7ef7 <fwp_write+0xf87>
    7e50:	48 8d 2d 69 6c 00 00 	lea    0x6c69(%rip),%rbp        # eac0 <units.0>
    7e57:	4d 89 e7             	mov    %r12,%r15
    7e5a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    7e5e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    7e63:	4c 89 ff             	mov    %r15,%rdi
    7e66:	4c 89 ee             	mov    %r13,%rsi
    7e69:	44 89 0c 24          	mov    %r9d,(%rsp)
    7e6d:	48 99                	cqto
    7e6f:	48 89 d1             	mov    %rdx,%rcx
    7e72:	48 89 c2             	mov    %rax,%rdx
    7e75:	e8 76 3a 00 00       	call   b8f0 <__divmodti4>
    7e7a:	44 8b 0c 24          	mov    (%rsp),%r9d
    7e7e:	48 89 c1             	mov    %rax,%rcx
    7e81:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    7e86:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    7e8b:	0f 84 94 00 00 00    	je     7f25 <fwp_write+0xfb5>
    7e91:	41 83 c1 01          	add    $0x1,%r9d
    7e95:	48 83 c5 10          	add    $0x10,%rbp
    7e99:	41 83 f9 05          	cmp    $0x5,%r9d
    7e9d:	75 bb                	jne    7e5a <fwp_write+0xeea>
    7e9f:	4d 85 ed             	test   %r13,%r13
    7ea2:	79 53                	jns    7ef7 <fwp_write+0xf87>
    7ea4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7ea9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    7eae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    7eb3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7eb8:	48 99                	cqto
    7eba:	48 f7 d8             	neg    %rax
    7ebd:	48 83 d2 00          	adc    $0x0,%rdx
    7ec1:	48 89 c6             	mov    %rax,%rsi
    7ec4:	48 f7 da             	neg    %rdx
    7ec7:	e8 34 ab ff ff       	call   2a00 <fwp_fmt_u128>
    7ecc:	49 89 e8             	mov    %rbp,%r8
    7ecf:	ba 00 02 00 00       	mov    $0x200,%edx
    7ed4:	be 02 00 00 00       	mov    $0x2,%esi
    7ed9:	31 c0                	xor    %eax,%eax
    7edb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7ee2:	00 
    7ee3:	48 8d 0d a5 42 00 00 	lea    0x42a5(%rip),%rcx        # c18f <_IO_stdin_used+0x18f>
    7eea:	4c 89 e7             	mov    %r12,%rdi
    7eed:	e8 ae a7 ff ff       	call   26a0 <__sprintf_chk@plt>
    7ef2:	e9 f9 f0 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7ef7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7efc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7f01:	31 d2                	xor    %edx,%edx
    7f03:	48 89 ef             	mov    %rbp,%rdi
    7f06:	e8 f5 aa ff ff       	call   2a00 <fwp_fmt_u128>
    7f0b:	eb bf                	jmp    7ecc <fwp_write+0xf5c>
    7f0d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    7f14:	4e 61 4e 00 
    7f18:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7f1f:	00 
    7f20:	e9 cb f0 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7f25:	44 89 0c 24          	mov    %r9d,(%rsp)
    7f29:	48 89 c8             	mov    %rcx,%rax
    7f2c:	48 85 d2             	test   %rdx,%rdx
    7f2f:	78 51                	js     7f82 <fwp_write+0x1012>
    7f31:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7f36:	48 89 c6             	mov    %rax,%rsi
    7f39:	48 89 ef             	mov    %rbp,%rdi
    7f3c:	e8 bf aa ff ff       	call   2a00 <fwp_fmt_u128>
    7f41:	44 8b 0c 24          	mov    (%rsp),%r9d
    7f45:	49 63 c1             	movslq %r9d,%rax
    7f48:	49 89 e8             	mov    %rbp,%r8
    7f4b:	ba 00 02 00 00       	mov    $0x200,%edx
    7f50:	be 02 00 00 00       	mov    $0x2,%esi
    7f55:	48 c1 e0 04          	shl    $0x4,%rax
    7f59:	48 8d 3d 60 6b 00 00 	lea    0x6b60(%rip),%rdi        # eac0 <units.0>
    7f60:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7f67:	00 
    7f68:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    7f6c:	48 8d 0d 17 42 00 00 	lea    0x4217(%rip),%rcx        # c18a <_IO_stdin_used+0x18a>
    7f73:	4c 89 e7             	mov    %r12,%rdi
    7f76:	31 c0                	xor    %eax,%eax
    7f78:	e8 23 a7 ff ff       	call   26a0 <__sprintf_chk@plt>
    7f7d:	e9 6e f0 ff ff       	jmp    6ff0 <fwp_write+0x80>
    7f82:	48 f7 d8             	neg    %rax
    7f85:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    7f8a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    7f8f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    7f94:	48 83 d2 00          	adc    $0x0,%rdx
    7f98:	48 89 c6             	mov    %rax,%rsi
    7f9b:	48 f7 da             	neg    %rdx
    7f9e:	e8 5d aa ff ff       	call   2a00 <fwp_fmt_u128>
    7fa3:	44 8b 0c 24          	mov    (%rsp),%r9d
    7fa7:	eb 9c                	jmp    7f45 <fwp_write+0xfd5>
    7fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007fb0 <fwp_hof0.constprop.0>:
    7fb0:	41 57                	push   %r15
    7fb2:	41 56                	push   %r14
    7fb4:	41 55                	push   %r13
    7fb6:	41 54                	push   %r12
    7fb8:	55                   	push   %rbp
    7fb9:	53                   	push   %rbx
    7fba:	48 83 ec 48          	sub    $0x48,%rsp
    7fbe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7fc5:	00 00 
    7fc7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7fcc:	31 c0                	xor    %eax,%eax
    7fce:	48 85 f6             	test   %rsi,%rsi
    7fd1:	0f 84 a9 03 00 00    	je     8380 <fwp_hof0.constprop.0+0x3d0>
    7fd7:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    7fdc:	49 89 fd             	mov    %rdi,%r13
    7fdf:	48 89 f3             	mov    %rsi,%rbx
    7fe2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7fe7:	4c 8d 3d 12 77 01 00 	lea    0x17712(%rip),%r15        # 1f700 <fwp_heap>
    7fee:	e9 db 01 00 00       	jmp    81ce <fwp_hof0.constprop.0+0x21e>
    7ff3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ff8:	48 83 05 b8 93 01 00 	addq   $0x1,0x193b8(%rip)        # 213b8 <iteration_requests>
    7fff:	01 
    8000:	48 01 15 a9 93 01 00 	add    %rdx,0x193a9(%rip)        # 213b0 <iteration_bytes>
    8007:	85 c0                	test   %eax,%eax
    8009:	0f 84 99 03 00 00    	je     83a8 <fwp_hof0.constprop.0+0x3f8>
    800f:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    8016:	0f 87 8c 03 00 00    	ja     83a8 <fwp_hof0.constprop.0+0x3f8>
    801c:	48 8d 45 18          	lea    0x18(%rbp),%rax
    8020:	48 c1 e8 04          	shr    $0x4,%rax
    8024:	41 0f b6 84 07 a0 0f 	movzbl 0xfa0(%r15,%rax,1),%eax
    802b:	00 00 
    802d:	45 8b 9c 87 00 0f 00 	mov    0xf00(%r15,%rax,4),%r11d
    8034:	00 
    8035:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8039:	49 8d 04 c7          	lea    (%r15,%rax,8),%rax
    803d:	4c 8b b0 c0 03 00 00 	mov    0x3c0(%rax),%r14
    8044:	4d 85 f6             	test   %r14,%r14
    8047:	0f 84 b3 02 00 00    	je     8300 <fwp_hof0.constprop.0+0x350>
    804d:	49 8b 36             	mov    (%r14),%rsi
    8050:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    8055:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
    805a:	48 f7 d6             	not    %rsi
    805d:	48 89 b0 c0 03 00 00 	mov    %rsi,0x3c0(%rax)
    8064:	31 f6                	xor    %esi,%esi
    8066:	4c 89 f7             	mov    %r14,%rdi
    8069:	e8 32 a4 ff ff       	call   24a0 <memset@plt>
    806e:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    8073:	4c 89 d8             	mov    %r11,%rax
    8076:	49 03 87 20 14 00 00 	add    0x1420(%r15),%rax
    807d:	0f 82 a3 03 00 00    	jb     8426 <fwp_hof0.constprop.0+0x476>
    8083:	49 39 87 28 14 00 00 	cmp    %rax,0x1428(%r15)
    808a:	49 89 87 20 14 00 00 	mov    %rax,0x1420(%r15)
    8091:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
    8096:	73 07                	jae    809f <fwp_hof0.constprop.0+0xef>
    8098:	49 89 87 28 14 00 00 	mov    %rax,0x1428(%r15)
    809f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    80a3:	f2 49 0f 2a c3       	cvtsi2sd %r11,%xmm0
    80a8:	f2 41 0f 58 87 38 14 	addsd  0x1438(%r15),%xmm0
    80af:	00 00 
    80b1:	f2 41 0f 11 87 38 14 	movsd  %xmm0,0x1438(%r15)
    80b8:	00 00 
    80ba:	45 85 e4             	test   %r12d,%r12d
    80bd:	74 33                	je     80f2 <fwp_hof0.constprop.0+0x142>
    80bf:	49 8b 87 20 14 00 00 	mov    0x1420(%r15),%rax
    80c6:	48 85 c0             	test   %rax,%rax
    80c9:	0f 88 91 02 00 00    	js     8360 <fwp_hof0.constprop.0+0x3b0>
    80cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    80d3:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    80d8:	f2 0f 5c 05 c0 92 01 	subsd  0x192c0(%rip),%xmm0        # 213a0 <iteration_start_charge>
    80df:	00 
    80e0:	66 0f 2f 05 b0 92 01 	comisd 0x192b0(%rip),%xmm0        # 21398 <iteration_peak>
    80e7:	00 
    80e8:	76 08                	jbe    80f2 <fwp_hof0.constprop.0+0x142>
    80ea:	f2 0f 11 05 a6 92 01 	movsd  %xmm0,0x192a6(%rip)        # 21398 <iteration_peak>
    80f1:	00 
    80f2:	49 89 2e             	mov    %rbp,(%r14)
    80f5:	4d 8d 66 08          	lea    0x8(%r14),%r12
    80f9:	48 89 ea             	mov    %rbp,%rdx
    80fc:	4c 89 d6             	mov    %r10,%rsi
    80ff:	4c 89 e7             	mov    %r12,%rdi
    8102:	e8 69 a4 ff ff       	call   2570 <memcpy@plt>
    8107:	41 c6 44 2e 08 00    	movb   $0x0,0x8(%r14,%rbp,1)
    810d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8112:	e8 89 a2 ff ff       	call   23a0 <free@plt>
    8117:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    811e:	4c 89 f0             	mov    %r14,%rax
    8121:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    8128:	48 c1 e2 10          	shl    $0x10,%rdx
    812c:	48 39 d0             	cmp    %rdx,%rax
    812f:	73 57                	jae    8188 <fwp_hof0.constprop.0+0x1d8>
    8131:	48 89 c2             	mov    %rax,%rdx
    8134:	48 c1 ea 10          	shr    $0x10,%rdx
    8138:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    813c:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    8143:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8147:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    814b:	48 85 d2             	test   %rdx,%rdx
    814e:	74 38                	je     8188 <fwp_hof0.constprop.0+0x1d8>
    8150:	0f b6 31             	movzbl (%rcx),%esi
    8153:	40 80 fe 02          	cmp    $0x2,%sil
    8157:	0f 84 f3 01 00 00    	je     8350 <fwp_hof0.constprop.0+0x3a0>
    815d:	40 80 fe 01          	cmp    $0x1,%sil
    8161:	75 25                	jne    8188 <fwp_hof0.constprop.0+0x1d8>
    8163:	8b 71 18             	mov    0x18(%rcx),%esi
    8166:	0f b7 c0             	movzwl %ax,%eax
    8169:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    816c:	48 0f af c6          	imul   %rsi,%rax
    8170:	48 c1 e8 20          	shr    $0x20,%rax
    8174:	48 39 c8             	cmp    %rcx,%rax
    8177:	73 0f                	jae    8188 <fwp_hof0.constprop.0+0x1d8>
    8179:	48 01 c2             	add    %rax,%rdx
    817c:	80 3a ff             	cmpb   $0xff,(%rdx)
    817f:	0f 84 6b 02 00 00    	je     83f0 <fwp_hof0.constprop.0+0x440>
    8185:	c6 02 01             	movb   $0x1,(%rdx)
    8188:	48 8b 3c 24          	mov    (%rsp),%rdi
    818c:	e8 7f d7 ff ff       	call   5910 <fwp_drop0>
    8191:	49 8b 16             	mov    (%r14),%rdx
    8194:	be 01 00 00 00       	mov    $0x1,%esi
    8199:	4c 89 e7             	mov    %r12,%rdi
    819c:	48 8b 0d b5 91 01 00 	mov    0x191b5(%rip),%rcx        # 21358 <fwp_prog_out>
    81a3:	e8 98 a4 ff ff       	call   2640 <fwrite@plt>
    81a8:	48 8b 35 a9 91 01 00 	mov    0x191a9(%rip),%rsi        # 21358 <fwp_prog_out>
    81af:	bf 0a 00 00 00       	mov    $0xa,%edi
    81b4:	e8 07 a3 ff ff       	call   24c0 <fputc@plt>
    81b9:	4c 89 f7             	mov    %r14,%rdi
    81bc:	e8 2f d5 ff ff       	call   56f0 <fwp_drop4>
    81c1:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    81c5:	48 85 db             	test   %rbx,%rbx
    81c8:	0f 84 b2 01 00 00    	je     8380 <fwp_hof0.constprop.0+0x3d0>
    81ce:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    81d5:	4c 89 e8             	mov    %r13,%rax
    81d8:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    81df:	48 c1 e2 10          	shl    $0x10,%rdx
    81e3:	48 39 d0             	cmp    %rdx,%rax
    81e6:	73 6f                	jae    8257 <fwp_hof0.constprop.0+0x2a7>
    81e8:	48 89 c2             	mov    %rax,%rdx
    81eb:	48 c1 ea 10          	shr    $0x10,%rdx
    81ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81f3:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    81fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81fe:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8202:	48 85 ff             	test   %rdi,%rdi
    8205:	74 50                	je     8257 <fwp_hof0.constprop.0+0x2a7>
    8207:	0f b6 0a             	movzbl (%rdx),%ecx
    820a:	80 f9 02             	cmp    $0x2,%cl
    820d:	0f 84 2d 01 00 00    	je     8340 <fwp_hof0.constprop.0+0x390>
    8213:	80 f9 01             	cmp    $0x1,%cl
    8216:	75 3f                	jne    8257 <fwp_hof0.constprop.0+0x2a7>
    8218:	8b 4a 18             	mov    0x18(%rdx),%ecx
    821b:	0f b7 c0             	movzwl %ax,%eax
    821e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8221:	48 0f af c1          	imul   %rcx,%rax
    8225:	48 c1 e8 20          	shr    $0x20,%rax
    8229:	48 39 d0             	cmp    %rdx,%rax
    822c:	73 29                	jae    8257 <fwp_hof0.constprop.0+0x2a7>
    822e:	48 01 c7             	add    %rax,%rdi
    8231:	0f b6 07             	movzbl (%rdi),%eax
    8234:	84 c0                	test   %al,%al
    8236:	74 1f                	je     8257 <fwp_hof0.constprop.0+0x2a7>
    8238:	8b 15 82 91 01 00    	mov    0x19182(%rip),%edx        # 213c0 <iteration_active>
    823e:	85 d2                	test   %edx,%edx
    8240:	74 08                	je     824a <fwp_hof0.constprop.0+0x29a>
    8242:	48 83 05 5e 91 01 00 	addq   $0x1,0x1915e(%rip)        # 213a8 <iteration_retains>
    8249:	01 
    824a:	3c fd                	cmp    $0xfd,%al
    824c:	0f 87 be 01 00 00    	ja     8410 <fwp_hof0.constprop.0+0x460>
    8252:	83 c0 01             	add    $0x1,%eax
    8255:	88 07                	mov    %al,(%rdi)
    8257:	4c 89 ef             	mov    %r13,%rdi
    825a:	e8 91 e1 ff ff       	call   63f0 <fwp_loop_fields68.constprop.0>
    825f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8264:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8268:	b9 01 00 00 00       	mov    $0x1,%ecx
    826d:	48 89 c6             	mov    %rax,%rsi
    8270:	48 8d 15 29 69 00 00 	lea    0x6929(%rip),%rdx        # eba0 <d0>
    8277:	48 89 04 24          	mov    %rax,(%rsp)
    827b:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
    8282:	00 00 
    8284:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    8289:	e8 e2 ec ff ff       	call   6f70 <fwp_write>
    828e:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    8293:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
    8298:	48 8d 05 cf 3d 00 00 	lea    0x3dcf(%rip),%rax        # c06e <_IO_stdin_used+0x6e>
    829f:	4d 85 d2             	test   %r10,%r10
    82a2:	4c 0f 44 d0          	cmove  %rax,%r10
    82a6:	48 83 fd f6          	cmp    $0xfffffffffffffff6,%rbp
    82aa:	0f 87 6a 01 00 00    	ja     841a <fwp_hof0.constprop.0+0x46a>
    82b0:	44 8b 25 09 91 01 00 	mov    0x19109(%rip),%r12d        # 213c0 <iteration_active>
    82b7:	41 8b 87 a4 13 00 00 	mov    0x13a4(%r15),%eax
    82be:	48 8d 55 09          	lea    0x9(%rbp),%rdx
    82c2:	45 85 e4             	test   %r12d,%r12d
    82c5:	0f 85 2d fd ff ff    	jne    7ff8 <fwp_hof0.constprop.0+0x48>
    82cb:	85 c0                	test   %eax,%eax
    82cd:	74 0d                	je     82dc <fwp_hof0.constprop.0+0x32c>
    82cf:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    82d6:	0f 86 40 fd ff ff    	jbe    801c <fwp_hof0.constprop.0+0x6c>
    82dc:	be 01 00 00 00       	mov    $0x1,%esi
    82e1:	48 89 d7             	mov    %rdx,%rdi
    82e4:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    82e9:	e8 62 c3 ff ff       	call   4650 <fwp_heap_alloc_slow>
    82ee:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    82f3:	49 89 c6             	mov    %rax,%r14
    82f6:	e9 f7 fd ff ff       	jmp    80f2 <fwp_hof0.constprop.0+0x142>
    82fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8300:	4c 8b b0 c8 03 00 00 	mov    0x3c8(%rax),%r14
    8307:	4d 85 f6             	test   %r14,%r14
    830a:	74 13                	je     831f <fwp_hof0.constprop.0+0x36f>
    830c:	48 8b b0 d0 03 00 00 	mov    0x3d0(%rax),%rsi
    8313:	4c 29 f6             	sub    %r14,%rsi
    8316:	4c 39 de             	cmp    %r11,%rsi
    8319:	0f 83 b1 00 00 00    	jae    83d0 <fwp_hof0.constprop.0+0x420>
    831f:	be 01 00 00 00       	mov    $0x1,%esi
    8324:	48 89 d7             	mov    %rdx,%rdi
    8327:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    832c:	e8 1f c3 ff ff       	call   4650 <fwp_heap_alloc_slow>
    8331:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    8336:	49 89 c6             	mov    %rax,%r14
    8339:	e9 7c fd ff ff       	jmp    80ba <fwp_hof0.constprop.0+0x10a>
    833e:	66 90                	xchg   %ax,%ax
    8340:	66 85 c0             	test   %ax,%ax
    8343:	0f 85 0e ff ff ff    	jne    8257 <fwp_hof0.constprop.0+0x2a7>
    8349:	e9 e3 fe ff ff       	jmp    8231 <fwp_hof0.constprop.0+0x281>
    834e:	66 90                	xchg   %ax,%ax
    8350:	66 85 c0             	test   %ax,%ax
    8353:	0f 85 2f fe ff ff    	jne    8188 <fwp_hof0.constprop.0+0x1d8>
    8359:	e9 1e fe ff ff       	jmp    817c <fwp_hof0.constprop.0+0x1cc>
    835e:	66 90                	xchg   %ax,%ax
    8360:	48 89 c2             	mov    %rax,%rdx
    8363:	83 e0 01             	and    $0x1,%eax
    8366:	66 0f ef c0          	pxor   %xmm0,%xmm0
    836a:	48 d1 ea             	shr    $1,%rdx
    836d:	48 09 c2             	or     %rax,%rdx
    8370:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    8375:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    8379:	e9 5a fd ff ff       	jmp    80d8 <fwp_hof0.constprop.0+0x128>
    837e:	66 90                	xchg   %ax,%ax
    8380:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8385:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    838c:	00 00 
    838e:	0f 85 97 00 00 00    	jne    842b <fwp_hof0.constprop.0+0x47b>
    8394:	48 83 c4 48          	add    $0x48,%rsp
    8398:	31 c0                	xor    %eax,%eax
    839a:	5b                   	pop    %rbx
    839b:	5d                   	pop    %rbp
    839c:	41 5c                	pop    %r12
    839e:	41 5d                	pop    %r13
    83a0:	41 5e                	pop    %r14
    83a2:	41 5f                	pop    %r15
    83a4:	c3                   	ret
    83a5:	0f 1f 00             	nopl   (%rax)
    83a8:	be 01 00 00 00       	mov    $0x1,%esi
    83ad:	48 89 d7             	mov    %rdx,%rdi
    83b0:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    83b5:	e8 96 c2 ff ff       	call   4650 <fwp_heap_alloc_slow>
    83ba:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    83bf:	49 89 c6             	mov    %rax,%r14
    83c2:	e9 f8 fc ff ff       	jmp    80bf <fwp_hof0.constprop.0+0x10f>
    83c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ce:	00 00 
    83d0:	4b 8d 34 1e          	lea    (%r14,%r11,1),%rsi
    83d4:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
    83d9:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    83de:	48 89 b0 c8 03 00 00 	mov    %rsi,0x3c8(%rax)
    83e5:	e9 7a fc ff ff       	jmp    8064 <fwp_hof0.constprop.0+0xb4>
    83ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    83f0:	48 89 d7             	mov    %rdx,%rdi
    83f3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    83f8:	e8 93 bc ff ff       	call   4090 <fwp_rc_forget_slot>
    83fd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8402:	e9 7e fd ff ff       	jmp    8185 <fwp_hof0.constprop.0+0x1d5>
    8407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    840e:	00 00 
    8410:	e8 5b bb ff ff       	call   3f70 <fwp_rc_wide_dup>
    8415:	e9 3d fe ff ff       	jmp    8257 <fwp_hof0.constprop.0+0x2a7>
    841a:	48 8d 3d 7a 3d 00 00 	lea    0x3d7a(%rip),%rdi        # c19b <_IO_stdin_used+0x19b>
    8421:	e8 4a ae ff ff       	call   3270 <fwp_trap>
    8426:	e8 35 a9 ff ff       	call   2d60 <fwp_heap_oom>
    842b:	e8 10 a0 ff ff       	call   2440 <__stack_chk_fail@plt>

0000000000008430 <f0>:
    8430:	41 56                	push   %r14
    8432:	4c 8d 35 c7 72 01 00 	lea    0x172c7(%rip),%r14        # 1f700 <fwp_heap>
    8439:	41 55                	push   %r13
    843b:	41 54                	push   %r12
    843d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    8443:	55                   	push   %rbp
    8444:	53                   	push   %rbx
    8445:	31 db                	xor    %ebx,%ebx
    8447:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    844e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    8455:	00 00 
    8457:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    845e:	00 
    845f:	31 c0                	xor    %eax,%eax
    8461:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    8468:	00 
    8469:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    8470:	00 00 
    8472:	66 48 0f 6e c0       	movq   %rax,%xmm0
    8477:	48 8d 05 92 d6 ff ff 	lea    -0x296e(%rip),%rax        # 5b10 <fwp_drop1>
    847e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    8483:	48 8b 05 06 8f 01 00 	mov    0x18f06(%rip),%rax        # 21390 <fwp_cleanups>
    848a:	48 89 25 ff 8e 01 00 	mov    %rsp,0x18eff(%rip)        # 21390 <fwp_cleanups>
    8491:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    8495:	48 89 04 24          	mov    %rax,(%rsp)
    8499:	48 8d 05 f0 a6 ff ff 	lea    -0x5910(%rip),%rax        # 2b90 <fwp_range_release>
    84a0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    84a5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    84aa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    84af:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    84b4:	eb 47                	jmp    84fd <f0+0xcd>
    84b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84bd:	00 00 00 
    84c0:	80 f9 01             	cmp    $0x1,%cl
    84c3:	75 29                	jne    84ee <f0+0xbe>
    84c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84c8:	0f b7 c0             	movzwl %ax,%eax
    84cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84ce:	48 0f af c1          	imul   %rcx,%rax
    84d2:	48 c1 e8 20          	shr    $0x20,%rax
    84d6:	48 39 d0             	cmp    %rdx,%rax
    84d9:	73 13                	jae    84ee <f0+0xbe>
    84db:	49 01 c5             	add    %rax,%r13
    84de:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    84e3:	0f 84 c7 27 00 00    	je     acb0 <f0+0x2880>
    84e9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    84ee:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    84f3:	49 83 ec 01          	sub    $0x1,%r12
    84f7:	0f 82 83 00 00 00    	jb     8580 <f0+0x150>
    84fd:	48 89 ee             	mov    %rbp,%rsi
    8500:	bf 01 00 00 00       	mov    $0x1,%edi
    8505:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    850c:	00 
    850d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    8512:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    8519:	00 
    851a:	e8 e1 cb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    851f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    8526:	48 89 c3             	mov    %rax,%rbx
    8529:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    8530:	48 c1 e2 10          	shl    $0x10,%rdx
    8534:	48 39 d0             	cmp    %rdx,%rax
    8537:	73 b5                	jae    84ee <f0+0xbe>
    8539:	48 89 c2             	mov    %rax,%rdx
    853c:	48 c1 ea 10          	shr    $0x10,%rdx
    8540:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8544:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    854b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    854f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    8553:	4d 85 ed             	test   %r13,%r13
    8556:	74 96                	je     84ee <f0+0xbe>
    8558:	0f b6 0a             	movzbl (%rdx),%ecx
    855b:	80 f9 02             	cmp    $0x2,%cl
    855e:	0f 85 5c ff ff ff    	jne    84c0 <f0+0x90>
    8564:	66 85 c0             	test   %ax,%ax
    8567:	0f 84 71 ff ff ff    	je     84de <f0+0xae>
    856d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    8572:	49 83 ec 01          	sub    $0x1,%r12
    8576:	73 85                	jae    84fd <f0+0xcd>
    8578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    857f:	00 
    8580:	48 8b 04 24          	mov    (%rsp),%rax
    8584:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    8589:	bf 01 00 00 00       	mov    $0x1,%edi
    858e:	66 0f 6f 05 fa 40 00 	movdqa 0x40fa(%rip),%xmm0        # c690 <msg.3+0xc0>
    8595:	00 
    8596:	48 89 05 f3 8d 01 00 	mov    %rax,0x18df3(%rip)        # 21390 <fwp_cleanups>
    859d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    85a2:	e8 59 cb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    85a7:	48 8b 15 2a 85 01 00 	mov    0x1852a(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    85ae:	49 89 c5             	mov    %rax,%r13
    85b1:	48 2b 05 f8 84 01 00 	sub    0x184f8(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    85b8:	48 c1 e2 10          	shl    $0x10,%rdx
    85bc:	48 39 d0             	cmp    %rdx,%rax
    85bf:	73 59                	jae    861a <f0+0x1ea>
    85c1:	48 89 c2             	mov    %rax,%rdx
    85c4:	48 c1 ea 10          	shr    $0x10,%rdx
    85c8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85cc:	48 8b 15 25 85 01 00 	mov    0x18525(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    85d3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85d7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    85db:	4d 85 e4             	test   %r12,%r12
    85de:	74 3a                	je     861a <f0+0x1ea>
    85e0:	0f b6 0a             	movzbl (%rdx),%ecx
    85e3:	80 f9 02             	cmp    $0x2,%cl
    85e6:	0f 84 74 27 00 00    	je     ad60 <f0+0x2930>
    85ec:	80 f9 01             	cmp    $0x1,%cl
    85ef:	75 29                	jne    861a <f0+0x1ea>
    85f1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85f4:	0f b7 c0             	movzwl %ax,%eax
    85f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85fa:	48 0f af c1          	imul   %rcx,%rax
    85fe:	48 c1 e8 20          	shr    $0x20,%rax
    8602:	48 39 d0             	cmp    %rdx,%rax
    8605:	73 13                	jae    861a <f0+0x1ea>
    8607:	49 01 c4             	add    %rax,%r12
    860a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    860f:	0f 84 26 29 00 00    	je     af3b <f0+0x2b0b>
    8615:	41 c6 04 24 01       	movb   $0x1,(%r12)
    861a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    861f:	bf 01 00 00 00       	mov    $0x1,%edi
    8624:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    8629:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    8630:	00 f0 3f 
    8633:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    8638:	e8 c3 ca ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    863d:	48 8b 15 94 84 01 00 	mov    0x18494(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    8644:	49 89 c5             	mov    %rax,%r13
    8647:	48 2b 05 62 84 01 00 	sub    0x18462(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    864e:	48 c1 e2 10          	shl    $0x10,%rdx
    8652:	48 39 d0             	cmp    %rdx,%rax
    8655:	73 59                	jae    86b0 <f0+0x280>
    8657:	48 89 c2             	mov    %rax,%rdx
    865a:	48 c1 ea 10          	shr    $0x10,%rdx
    865e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8662:	48 8b 15 8f 84 01 00 	mov    0x1848f(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    8669:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    866d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8671:	4d 85 e4             	test   %r12,%r12
    8674:	74 3a                	je     86b0 <f0+0x280>
    8676:	0f b6 0a             	movzbl (%rdx),%ecx
    8679:	80 f9 02             	cmp    $0x2,%cl
    867c:	0f 84 ce 26 00 00    	je     ad50 <f0+0x2920>
    8682:	80 f9 01             	cmp    $0x1,%cl
    8685:	75 29                	jne    86b0 <f0+0x280>
    8687:	8b 4a 18             	mov    0x18(%rdx),%ecx
    868a:	0f b7 c0             	movzwl %ax,%eax
    868d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8690:	48 0f af c1          	imul   %rcx,%rax
    8694:	48 c1 e8 20          	shr    $0x20,%rax
    8698:	48 39 d0             	cmp    %rdx,%rax
    869b:	73 13                	jae    86b0 <f0+0x280>
    869d:	49 01 c4             	add    %rax,%r12
    86a0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    86a5:	0f 84 9d 28 00 00    	je     af48 <f0+0x2b18>
    86ab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    86b0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    86b5:	bf 01 00 00 00       	mov    $0x1,%edi
    86ba:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    86bf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    86c6:	33 f3 bf 
    86c9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    86ce:	e8 2d ca ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    86d3:	48 8b 15 fe 83 01 00 	mov    0x183fe(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    86da:	49 89 c5             	mov    %rax,%r13
    86dd:	48 2b 05 cc 83 01 00 	sub    0x183cc(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    86e4:	48 c1 e2 10          	shl    $0x10,%rdx
    86e8:	48 39 d0             	cmp    %rdx,%rax
    86eb:	73 59                	jae    8746 <f0+0x316>
    86ed:	48 89 c2             	mov    %rax,%rdx
    86f0:	48 c1 ea 10          	shr    $0x10,%rdx
    86f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86f8:	48 8b 15 f9 83 01 00 	mov    0x183f9(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    86ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8703:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8707:	4d 85 e4             	test   %r12,%r12
    870a:	74 3a                	je     8746 <f0+0x316>
    870c:	0f b6 0a             	movzbl (%rdx),%ecx
    870f:	80 f9 02             	cmp    $0x2,%cl
    8712:	0f 84 28 26 00 00    	je     ad40 <f0+0x2910>
    8718:	80 f9 01             	cmp    $0x1,%cl
    871b:	75 29                	jne    8746 <f0+0x316>
    871d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8720:	0f b7 c0             	movzwl %ax,%eax
    8723:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8726:	48 0f af c1          	imul   %rcx,%rax
    872a:	48 c1 e8 20          	shr    $0x20,%rax
    872e:	48 39 d0             	cmp    %rdx,%rax
    8731:	73 13                	jae    8746 <f0+0x316>
    8733:	49 01 c4             	add    %rax,%r12
    8736:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    873b:	0f 84 14 28 00 00    	je     af55 <f0+0x2b25>
    8741:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8746:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    874b:	bf 01 00 00 00       	mov    $0x1,%edi
    8750:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    8755:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    875c:	00 f0 3f 
    875f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    8764:	e8 97 c9 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8769:	48 8b 15 68 83 01 00 	mov    0x18368(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    8770:	49 89 c5             	mov    %rax,%r13
    8773:	48 2b 05 36 83 01 00 	sub    0x18336(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    877a:	48 c1 e2 10          	shl    $0x10,%rdx
    877e:	48 39 d0             	cmp    %rdx,%rax
    8781:	73 59                	jae    87dc <f0+0x3ac>
    8783:	48 89 c2             	mov    %rax,%rdx
    8786:	48 c1 ea 10          	shr    $0x10,%rdx
    878a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    878e:	48 8b 15 63 83 01 00 	mov    0x18363(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    8795:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8799:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    879d:	4d 85 e4             	test   %r12,%r12
    87a0:	74 3a                	je     87dc <f0+0x3ac>
    87a2:	0f b6 0a             	movzbl (%rdx),%ecx
    87a5:	80 f9 02             	cmp    $0x2,%cl
    87a8:	0f 84 f2 25 00 00    	je     ada0 <f0+0x2970>
    87ae:	80 f9 01             	cmp    $0x1,%cl
    87b1:	75 29                	jne    87dc <f0+0x3ac>
    87b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87b6:	0f b7 c0             	movzwl %ax,%eax
    87b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87bc:	48 0f af c1          	imul   %rcx,%rax
    87c0:	48 c1 e8 20          	shr    $0x20,%rax
    87c4:	48 39 d0             	cmp    %rdx,%rax
    87c7:	73 13                	jae    87dc <f0+0x3ac>
    87c9:	49 01 c4             	add    %rax,%r12
    87cc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    87d1:	0f 84 8b 27 00 00    	je     af62 <f0+0x2b32>
    87d7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    87dc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    87e3:	33 f3 bf 
    87e6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    87ed:	00 
    87ee:	bf 01 00 00 00       	mov    $0x1,%edi
    87f3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    87fa:	00 
    87fb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8802:	00 
    8803:	e8 f8 c8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8808:	48 8b 15 c9 82 01 00 	mov    0x182c9(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    880f:	49 89 c5             	mov    %rax,%r13
    8812:	48 2b 05 97 82 01 00 	sub    0x18297(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    8819:	48 c1 e2 10          	shl    $0x10,%rdx
    881d:	48 39 d0             	cmp    %rdx,%rax
    8820:	73 59                	jae    887b <f0+0x44b>
    8822:	48 89 c2             	mov    %rax,%rdx
    8825:	48 c1 ea 10          	shr    $0x10,%rdx
    8829:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    882d:	48 8b 15 c4 82 01 00 	mov    0x182c4(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    8834:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8838:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    883c:	4d 85 e4             	test   %r12,%r12
    883f:	74 3a                	je     887b <f0+0x44b>
    8841:	0f b6 0a             	movzbl (%rdx),%ecx
    8844:	80 f9 02             	cmp    $0x2,%cl
    8847:	0f 84 43 25 00 00    	je     ad90 <f0+0x2960>
    884d:	80 f9 01             	cmp    $0x1,%cl
    8850:	75 29                	jne    887b <f0+0x44b>
    8852:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8855:	0f b7 c0             	movzwl %ax,%eax
    8858:	8b 52 1c             	mov    0x1c(%rdx),%edx
    885b:	48 0f af c1          	imul   %rcx,%rax
    885f:	48 c1 e8 20          	shr    $0x20,%rax
    8863:	48 39 d0             	cmp    %rdx,%rax
    8866:	73 13                	jae    887b <f0+0x44b>
    8868:	49 01 c4             	add    %rax,%r12
    886b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8870:	0f 84 f9 26 00 00    	je     af6f <f0+0x2b3f>
    8876:	41 c6 04 24 01       	movb   $0x1,(%r12)
    887b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    8882:	00 f0 3f 
    8885:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    888c:	00 
    888d:	bf 01 00 00 00       	mov    $0x1,%edi
    8892:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    8899:	00 
    889a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    88a1:	00 
    88a2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    88a9:	33 f3 bf 
    88ac:	e8 4f c8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    88b1:	48 89 c7             	mov    %rax,%rdi
    88b4:	e8 07 c0 ff ff       	call   48c0 <fwp_rc_fresh>
    88b9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    88c0:	00 
    88c1:	bf 01 00 00 00       	mov    $0x1,%edi
    88c6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    88cd:	00 
    88ce:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    88d5:	00 
    88d6:	e8 25 c8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    88db:	48 89 c7             	mov    %rax,%rdi
    88de:	e8 dd bf ff ff       	call   48c0 <fwp_rc_fresh>
    88e3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    88ea:	00 
    88eb:	bf 01 00 00 00       	mov    $0x1,%edi
    88f0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    88f7:	00 
    88f8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    88ff:	00 
    8900:	e8 fb c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8905:	48 89 c7             	mov    %rax,%rdi
    8908:	e8 b3 bf ff ff       	call   48c0 <fwp_rc_fresh>
    890d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    8914:	00 
    8915:	bf 01 00 00 00       	mov    $0x1,%edi
    891a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    8921:	00 
    8922:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    8929:	00 
    892a:	e8 d1 c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    892f:	48 89 c7             	mov    %rax,%rdi
    8932:	e8 89 bf ff ff       	call   48c0 <fwp_rc_fresh>
    8937:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    893e:	00 
    893f:	bf 01 00 00 00       	mov    $0x1,%edi
    8944:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    894b:	00 
    894c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    8953:	00 
    8954:	e8 a7 c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8959:	48 89 c7             	mov    %rax,%rdi
    895c:	e8 5f bf ff ff       	call   48c0 <fwp_rc_fresh>
    8961:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    8968:	00 
    8969:	bf 01 00 00 00       	mov    $0x1,%edi
    896e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    8975:	00 
    8976:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    897d:	00 
    897e:	e8 7d c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8983:	48 89 c7             	mov    %rax,%rdi
    8986:	e8 35 bf ff ff       	call   48c0 <fwp_rc_fresh>
    898b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    8992:	00 
    8993:	bf 01 00 00 00       	mov    $0x1,%edi
    8998:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    899f:	00 
    89a0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    89a7:	00 
    89a8:	e8 53 c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    89ad:	48 89 c7             	mov    %rax,%rdi
    89b0:	e8 0b bf ff ff       	call   48c0 <fwp_rc_fresh>
    89b5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    89bc:	00 
    89bd:	bf 01 00 00 00       	mov    $0x1,%edi
    89c2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    89c9:	00 
    89ca:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    89d1:	00 
    89d2:	e8 29 c7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    89d7:	48 89 c7             	mov    %rax,%rdi
    89da:	e8 e1 be ff ff       	call   48c0 <fwp_rc_fresh>
    89df:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    89e6:	00 
    89e7:	bf 01 00 00 00       	mov    $0x1,%edi
    89ec:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    89f3:	00 
    89f4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    89fb:	00 
    89fc:	e8 ff c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8a01:	48 89 c7             	mov    %rax,%rdi
    8a04:	e8 b7 be ff ff       	call   48c0 <fwp_rc_fresh>
    8a09:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    8a10:	00 
    8a11:	bf 01 00 00 00       	mov    $0x1,%edi
    8a16:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    8a1d:	00 
    8a1e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    8a25:	00 
    8a26:	e8 d5 c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8a2b:	48 89 c7             	mov    %rax,%rdi
    8a2e:	e8 8d be ff ff       	call   48c0 <fwp_rc_fresh>
    8a33:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    8a3a:	00 
    8a3b:	bf 01 00 00 00       	mov    $0x1,%edi
    8a40:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    8a47:	00 
    8a48:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    8a4f:	00 
    8a50:	e8 ab c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8a55:	48 89 c7             	mov    %rax,%rdi
    8a58:	e8 63 be ff ff       	call   48c0 <fwp_rc_fresh>
    8a5d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    8a64:	00 
    8a65:	bf 01 00 00 00       	mov    $0x1,%edi
    8a6a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    8a71:	00 
    8a72:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    8a79:	00 
    8a7a:	e8 81 c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8a7f:	48 89 c7             	mov    %rax,%rdi
    8a82:	e8 39 be ff ff       	call   48c0 <fwp_rc_fresh>
    8a87:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    8a8e:	00 
    8a8f:	bf 01 00 00 00       	mov    $0x1,%edi
    8a94:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    8a9b:	00 
    8a9c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    8aa3:	00 
    8aa4:	e8 57 c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8aa9:	48 89 c7             	mov    %rax,%rdi
    8aac:	e8 0f be ff ff       	call   48c0 <fwp_rc_fresh>
    8ab1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    8ab8:	00 
    8ab9:	bf 01 00 00 00       	mov    $0x1,%edi
    8abe:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    8ac5:	00 
    8ac6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    8acd:	00 
    8ace:	e8 2d c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8ad3:	48 89 c7             	mov    %rax,%rdi
    8ad6:	e8 e5 bd ff ff       	call   48c0 <fwp_rc_fresh>
    8adb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    8ae2:	00 
    8ae3:	bf 01 00 00 00       	mov    $0x1,%edi
    8ae8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    8aef:	00 
    8af0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    8af7:	00 
    8af8:	e8 03 c6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8afd:	48 89 c7             	mov    %rax,%rdi
    8b00:	e8 bb bd ff ff       	call   48c0 <fwp_rc_fresh>
    8b05:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    8b0c:	00 
    8b0d:	bf 01 00 00 00       	mov    $0x1,%edi
    8b12:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    8b19:	00 
    8b1a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    8b21:	00 
    8b22:	e8 d9 c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8b27:	48 89 c7             	mov    %rax,%rdi
    8b2a:	e8 91 bd ff ff       	call   48c0 <fwp_rc_fresh>
    8b2f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    8b36:	00 
    8b37:	bf 01 00 00 00       	mov    $0x1,%edi
    8b3c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    8b43:	00 
    8b44:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    8b4b:	00 
    8b4c:	e8 af c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8b51:	48 89 c7             	mov    %rax,%rdi
    8b54:	e8 67 bd ff ff       	call   48c0 <fwp_rc_fresh>
    8b59:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    8b60:	00 
    8b61:	bf 01 00 00 00       	mov    $0x1,%edi
    8b66:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    8b6d:	00 
    8b6e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    8b75:	00 
    8b76:	e8 85 c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8b7b:	48 89 c7             	mov    %rax,%rdi
    8b7e:	e8 3d bd ff ff       	call   48c0 <fwp_rc_fresh>
    8b83:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    8b8a:	00 
    8b8b:	bf 01 00 00 00       	mov    $0x1,%edi
    8b90:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    8b97:	00 
    8b98:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    8b9f:	00 
    8ba0:	e8 5b c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8ba5:	48 89 c7             	mov    %rax,%rdi
    8ba8:	e8 13 bd ff ff       	call   48c0 <fwp_rc_fresh>
    8bad:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    8bb4:	00 
    8bb5:	bf 01 00 00 00       	mov    $0x1,%edi
    8bba:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    8bc1:	00 
    8bc2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    8bc9:	00 
    8bca:	e8 31 c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8bcf:	48 89 c7             	mov    %rax,%rdi
    8bd2:	e8 e9 bc ff ff       	call   48c0 <fwp_rc_fresh>
    8bd7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    8bde:	00 
    8bdf:	bf 01 00 00 00       	mov    $0x1,%edi
    8be4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    8beb:	00 
    8bec:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    8bf3:	00 
    8bf4:	e8 07 c5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8bf9:	48 89 c7             	mov    %rax,%rdi
    8bfc:	e8 bf bc ff ff       	call   48c0 <fwp_rc_fresh>
    8c01:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    8c08:	00 
    8c09:	bf 01 00 00 00       	mov    $0x1,%edi
    8c0e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    8c15:	00 
    8c16:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    8c1d:	00 
    8c1e:	e8 dd c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8c23:	48 89 c7             	mov    %rax,%rdi
    8c26:	e8 95 bc ff ff       	call   48c0 <fwp_rc_fresh>
    8c2b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    8c32:	00 
    8c33:	bf 01 00 00 00       	mov    $0x1,%edi
    8c38:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    8c3f:	00 
    8c40:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    8c47:	00 
    8c48:	e8 b3 c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8c4d:	48 89 c7             	mov    %rax,%rdi
    8c50:	e8 6b bc ff ff       	call   48c0 <fwp_rc_fresh>
    8c55:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    8c5c:	00 
    8c5d:	bf 01 00 00 00       	mov    $0x1,%edi
    8c62:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    8c69:	00 
    8c6a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    8c71:	00 
    8c72:	e8 89 c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8c77:	48 89 c7             	mov    %rax,%rdi
    8c7a:	e8 41 bc ff ff       	call   48c0 <fwp_rc_fresh>
    8c7f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    8c86:	00 
    8c87:	bf 01 00 00 00       	mov    $0x1,%edi
    8c8c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    8c93:	00 
    8c94:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    8c9b:	00 
    8c9c:	e8 5f c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8ca1:	48 89 c7             	mov    %rax,%rdi
    8ca4:	e8 17 bc ff ff       	call   48c0 <fwp_rc_fresh>
    8ca9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    8cb0:	00 
    8cb1:	bf 01 00 00 00       	mov    $0x1,%edi
    8cb6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    8cbd:	00 
    8cbe:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    8cc5:	00 
    8cc6:	e8 35 c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8ccb:	48 89 c7             	mov    %rax,%rdi
    8cce:	e8 ed bb ff ff       	call   48c0 <fwp_rc_fresh>
    8cd3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    8cda:	00 
    8cdb:	bf 01 00 00 00       	mov    $0x1,%edi
    8ce0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    8ce7:	00 
    8ce8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    8cef:	00 
    8cf0:	e8 0b c4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8cf5:	48 89 c7             	mov    %rax,%rdi
    8cf8:	e8 c3 bb ff ff       	call   48c0 <fwp_rc_fresh>
    8cfd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    8d04:	00 
    8d05:	bf 01 00 00 00       	mov    $0x1,%edi
    8d0a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    8d11:	00 
    8d12:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    8d19:	00 
    8d1a:	e8 e1 c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8d1f:	48 89 c7             	mov    %rax,%rdi
    8d22:	e8 99 bb ff ff       	call   48c0 <fwp_rc_fresh>
    8d27:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    8d2e:	00 
    8d2f:	bf 01 00 00 00       	mov    $0x1,%edi
    8d34:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    8d3b:	00 
    8d3c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    8d43:	00 
    8d44:	e8 b7 c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8d49:	48 89 c7             	mov    %rax,%rdi
    8d4c:	e8 6f bb ff ff       	call   48c0 <fwp_rc_fresh>
    8d51:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    8d58:	00 
    8d59:	bf 01 00 00 00       	mov    $0x1,%edi
    8d5e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    8d65:	00 
    8d66:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    8d6d:	00 
    8d6e:	e8 8d c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8d73:	48 89 c7             	mov    %rax,%rdi
    8d76:	e8 45 bb ff ff       	call   48c0 <fwp_rc_fresh>
    8d7b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    8d82:	00 
    8d83:	bf 01 00 00 00       	mov    $0x1,%edi
    8d88:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    8d8f:	00 
    8d90:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    8d97:	00 
    8d98:	e8 63 c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8d9d:	48 89 c7             	mov    %rax,%rdi
    8da0:	e8 1b bb ff ff       	call   48c0 <fwp_rc_fresh>
    8da5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    8dac:	00 
    8dad:	bf 01 00 00 00       	mov    $0x1,%edi
    8db2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    8db9:	00 
    8dba:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    8dc1:	00 
    8dc2:	e8 39 c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8dc7:	48 89 c7             	mov    %rax,%rdi
    8dca:	e8 f1 ba ff ff       	call   48c0 <fwp_rc_fresh>
    8dcf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    8dd6:	00 
    8dd7:	bf 01 00 00 00       	mov    $0x1,%edi
    8ddc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    8de3:	00 
    8de4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    8deb:	00 
    8dec:	e8 0f c3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8df1:	48 89 c7             	mov    %rax,%rdi
    8df4:	e8 c7 ba ff ff       	call   48c0 <fwp_rc_fresh>
    8df9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    8e00:	00 
    8e01:	bf 01 00 00 00       	mov    $0x1,%edi
    8e06:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    8e0d:	00 
    8e0e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    8e15:	00 
    8e16:	e8 e5 c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8e1b:	48 89 c7             	mov    %rax,%rdi
    8e1e:	e8 9d ba ff ff       	call   48c0 <fwp_rc_fresh>
    8e23:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    8e2a:	00 
    8e2b:	bf 01 00 00 00       	mov    $0x1,%edi
    8e30:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    8e37:	00 
    8e38:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    8e3f:	00 
    8e40:	e8 bb c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8e45:	48 89 c7             	mov    %rax,%rdi
    8e48:	e8 73 ba ff ff       	call   48c0 <fwp_rc_fresh>
    8e4d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    8e54:	00 
    8e55:	bf 01 00 00 00       	mov    $0x1,%edi
    8e5a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    8e61:	00 
    8e62:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    8e69:	00 
    8e6a:	e8 91 c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8e6f:	48 89 c7             	mov    %rax,%rdi
    8e72:	e8 49 ba ff ff       	call   48c0 <fwp_rc_fresh>
    8e77:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    8e7e:	00 
    8e7f:	bf 01 00 00 00       	mov    $0x1,%edi
    8e84:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    8e8b:	00 
    8e8c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    8e93:	00 
    8e94:	e8 67 c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8e99:	48 89 c7             	mov    %rax,%rdi
    8e9c:	e8 1f ba ff ff       	call   48c0 <fwp_rc_fresh>
    8ea1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    8ea8:	00 
    8ea9:	bf 01 00 00 00       	mov    $0x1,%edi
    8eae:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    8eb5:	00 
    8eb6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    8ebd:	00 
    8ebe:	e8 3d c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8ec3:	48 89 c7             	mov    %rax,%rdi
    8ec6:	e8 f5 b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8ecb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    8ed2:	00 
    8ed3:	bf 01 00 00 00       	mov    $0x1,%edi
    8ed8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    8edf:	00 
    8ee0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    8ee7:	00 
    8ee8:	e8 13 c2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8eed:	48 89 c7             	mov    %rax,%rdi
    8ef0:	e8 cb b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8ef5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    8efc:	00 
    8efd:	bf 01 00 00 00       	mov    $0x1,%edi
    8f02:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    8f09:	00 
    8f0a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    8f11:	00 
    8f12:	e8 e9 c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8f17:	48 89 c7             	mov    %rax,%rdi
    8f1a:	e8 a1 b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8f1f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    8f26:	00 
    8f27:	bf 01 00 00 00       	mov    $0x1,%edi
    8f2c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    8f33:	00 
    8f34:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    8f3b:	00 
    8f3c:	e8 bf c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8f41:	48 89 c7             	mov    %rax,%rdi
    8f44:	e8 77 b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8f49:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    8f50:	00 
    8f51:	bf 01 00 00 00       	mov    $0x1,%edi
    8f56:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    8f5d:	00 
    8f5e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    8f65:	00 
    8f66:	e8 95 c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8f6b:	48 89 c7             	mov    %rax,%rdi
    8f6e:	e8 4d b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8f73:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    8f7a:	00 
    8f7b:	bf 01 00 00 00       	mov    $0x1,%edi
    8f80:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    8f87:	00 
    8f88:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    8f8f:	00 
    8f90:	e8 6b c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8f95:	48 89 c7             	mov    %rax,%rdi
    8f98:	e8 23 b9 ff ff       	call   48c0 <fwp_rc_fresh>
    8f9d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    8fa4:	00 
    8fa5:	bf 01 00 00 00       	mov    $0x1,%edi
    8faa:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    8fb1:	00 
    8fb2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    8fb9:	00 
    8fba:	e8 41 c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8fbf:	48 89 c7             	mov    %rax,%rdi
    8fc2:	e8 f9 b8 ff ff       	call   48c0 <fwp_rc_fresh>
    8fc7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    8fce:	00 
    8fcf:	bf 01 00 00 00       	mov    $0x1,%edi
    8fd4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    8fdb:	00 
    8fdc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    8fe3:	00 
    8fe4:	e8 17 c1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    8fe9:	48 89 c7             	mov    %rax,%rdi
    8fec:	e8 cf b8 ff ff       	call   48c0 <fwp_rc_fresh>
    8ff1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    8ff8:	00 
    8ff9:	bf 01 00 00 00       	mov    $0x1,%edi
    8ffe:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    9005:	00 
    9006:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    900d:	00 
    900e:	e8 ed c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9013:	48 89 c7             	mov    %rax,%rdi
    9016:	e8 a5 b8 ff ff       	call   48c0 <fwp_rc_fresh>
    901b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    9022:	00 
    9023:	bf 01 00 00 00       	mov    $0x1,%edi
    9028:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    902f:	00 
    9030:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    9037:	00 
    9038:	e8 c3 c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    903d:	48 89 c7             	mov    %rax,%rdi
    9040:	e8 7b b8 ff ff       	call   48c0 <fwp_rc_fresh>
    9045:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    904c:	00 
    904d:	bf 01 00 00 00       	mov    $0x1,%edi
    9052:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    9059:	00 
    905a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    9061:	00 
    9062:	e8 99 c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9067:	48 89 c7             	mov    %rax,%rdi
    906a:	e8 51 b8 ff ff       	call   48c0 <fwp_rc_fresh>
    906f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    9076:	00 
    9077:	bf 01 00 00 00       	mov    $0x1,%edi
    907c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    9083:	00 
    9084:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    908b:	00 
    908c:	e8 6f c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9091:	48 89 c7             	mov    %rax,%rdi
    9094:	e8 27 b8 ff ff       	call   48c0 <fwp_rc_fresh>
    9099:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    90a0:	00 
    90a1:	bf 01 00 00 00       	mov    $0x1,%edi
    90a6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    90ad:	00 
    90ae:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    90b5:	00 
    90b6:	e8 45 c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    90bb:	48 89 c7             	mov    %rax,%rdi
    90be:	e8 fd b7 ff ff       	call   48c0 <fwp_rc_fresh>
    90c3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    90ca:	00 
    90cb:	bf 01 00 00 00       	mov    $0x1,%edi
    90d0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    90d7:	00 
    90d8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    90df:	00 
    90e0:	e8 1b c0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    90e5:	48 89 c7             	mov    %rax,%rdi
    90e8:	e8 d3 b7 ff ff       	call   48c0 <fwp_rc_fresh>
    90ed:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    90f4:	00 
    90f5:	bf 01 00 00 00       	mov    $0x1,%edi
    90fa:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    9101:	00 
    9102:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    9109:	00 
    910a:	e8 f1 bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    910f:	48 89 c7             	mov    %rax,%rdi
    9112:	e8 a9 b7 ff ff       	call   48c0 <fwp_rc_fresh>
    9117:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    911e:	00 
    911f:	bf 01 00 00 00       	mov    $0x1,%edi
    9124:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    912b:	00 
    912c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    9133:	00 
    9134:	e8 c7 bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9139:	48 89 c7             	mov    %rax,%rdi
    913c:	e8 7f b7 ff ff       	call   48c0 <fwp_rc_fresh>
    9141:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    9148:	00 
    9149:	bf 01 00 00 00       	mov    $0x1,%edi
    914e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    9155:	00 
    9156:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    915d:	00 
    915e:	e8 9d bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9163:	48 89 c7             	mov    %rax,%rdi
    9166:	e8 55 b7 ff ff       	call   48c0 <fwp_rc_fresh>
    916b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    9172:	00 
    9173:	bf 01 00 00 00       	mov    $0x1,%edi
    9178:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    917f:	00 
    9180:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    9187:	00 
    9188:	e8 73 bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    918d:	48 89 c7             	mov    %rax,%rdi
    9190:	e8 2b b7 ff ff       	call   48c0 <fwp_rc_fresh>
    9195:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    919c:	00 
    919d:	bf 01 00 00 00       	mov    $0x1,%edi
    91a2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    91a9:	00 
    91aa:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    91b1:	00 
    91b2:	e8 49 bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    91b7:	48 89 c7             	mov    %rax,%rdi
    91ba:	e8 01 b7 ff ff       	call   48c0 <fwp_rc_fresh>
    91bf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    91c6:	00 
    91c7:	bf 01 00 00 00       	mov    $0x1,%edi
    91cc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    91d3:	00 
    91d4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    91db:	00 
    91dc:	e8 1f bf ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    91e1:	48 89 c7             	mov    %rax,%rdi
    91e4:	e8 d7 b6 ff ff       	call   48c0 <fwp_rc_fresh>
    91e9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    91f0:	00 
    91f1:	bf 01 00 00 00       	mov    $0x1,%edi
    91f6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    91fd:	00 
    91fe:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    9205:	00 
    9206:	e8 f5 be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    920b:	48 89 c7             	mov    %rax,%rdi
    920e:	e8 ad b6 ff ff       	call   48c0 <fwp_rc_fresh>
    9213:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    921a:	00 
    921b:	bf 01 00 00 00       	mov    $0x1,%edi
    9220:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    9227:	00 
    9228:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    922f:	00 
    9230:	e8 cb be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9235:	48 89 c7             	mov    %rax,%rdi
    9238:	e8 83 b6 ff ff       	call   48c0 <fwp_rc_fresh>
    923d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    9244:	00 
    9245:	bf 01 00 00 00       	mov    $0x1,%edi
    924a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    9251:	00 
    9252:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    9259:	00 
    925a:	e8 a1 be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    925f:	48 89 c7             	mov    %rax,%rdi
    9262:	e8 59 b6 ff ff       	call   48c0 <fwp_rc_fresh>
    9267:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    926e:	00 
    926f:	bf 01 00 00 00       	mov    $0x1,%edi
    9274:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    927b:	00 
    927c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    9283:	00 
    9284:	e8 77 be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9289:	48 89 c7             	mov    %rax,%rdi
    928c:	e8 2f b6 ff ff       	call   48c0 <fwp_rc_fresh>
    9291:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    9298:	00 
    9299:	bf 01 00 00 00       	mov    $0x1,%edi
    929e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    92a5:	00 
    92a6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    92ad:	00 
    92ae:	e8 4d be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    92b3:	48 89 c7             	mov    %rax,%rdi
    92b6:	e8 05 b6 ff ff       	call   48c0 <fwp_rc_fresh>
    92bb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    92c2:	00 
    92c3:	bf 01 00 00 00       	mov    $0x1,%edi
    92c8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    92cf:	00 
    92d0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    92d7:	00 
    92d8:	e8 23 be ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    92dd:	48 89 c7             	mov    %rax,%rdi
    92e0:	e8 db b5 ff ff       	call   48c0 <fwp_rc_fresh>
    92e5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    92ec:	00 
    92ed:	bf 01 00 00 00       	mov    $0x1,%edi
    92f2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    92f9:	00 
    92fa:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    9301:	00 
    9302:	e8 f9 bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9307:	48 89 c7             	mov    %rax,%rdi
    930a:	e8 b1 b5 ff ff       	call   48c0 <fwp_rc_fresh>
    930f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    9316:	00 
    9317:	bf 01 00 00 00       	mov    $0x1,%edi
    931c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    9323:	00 
    9324:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    932b:	00 
    932c:	e8 cf bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9331:	48 89 c7             	mov    %rax,%rdi
    9334:	e8 87 b5 ff ff       	call   48c0 <fwp_rc_fresh>
    9339:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    9340:	00 
    9341:	bf 01 00 00 00       	mov    $0x1,%edi
    9346:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    934d:	00 
    934e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    9355:	00 
    9356:	e8 a5 bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    935b:	48 89 c7             	mov    %rax,%rdi
    935e:	e8 5d b5 ff ff       	call   48c0 <fwp_rc_fresh>
    9363:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    936a:	00 
    936b:	bf 01 00 00 00       	mov    $0x1,%edi
    9370:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    9377:	00 
    9378:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    937f:	00 
    9380:	e8 7b bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9385:	48 89 c7             	mov    %rax,%rdi
    9388:	e8 33 b5 ff ff       	call   48c0 <fwp_rc_fresh>
    938d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    9394:	00 
    9395:	bf 01 00 00 00       	mov    $0x1,%edi
    939a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    93a1:	00 
    93a2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    93a9:	00 
    93aa:	e8 51 bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    93af:	48 89 c7             	mov    %rax,%rdi
    93b2:	e8 09 b5 ff ff       	call   48c0 <fwp_rc_fresh>
    93b7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    93be:	00 
    93bf:	bf 01 00 00 00       	mov    $0x1,%edi
    93c4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    93cb:	00 
    93cc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    93d3:	00 
    93d4:	e8 27 bd ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    93d9:	48 89 c7             	mov    %rax,%rdi
    93dc:	e8 df b4 ff ff       	call   48c0 <fwp_rc_fresh>
    93e1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    93e8:	00 
    93e9:	bf 01 00 00 00       	mov    $0x1,%edi
    93ee:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    93f5:	00 
    93f6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    93fd:	00 
    93fe:	e8 fd bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9403:	48 89 c7             	mov    %rax,%rdi
    9406:	e8 b5 b4 ff ff       	call   48c0 <fwp_rc_fresh>
    940b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    9412:	00 
    9413:	bf 01 00 00 00       	mov    $0x1,%edi
    9418:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    941f:	00 
    9420:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    9427:	00 
    9428:	e8 d3 bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    942d:	48 89 c7             	mov    %rax,%rdi
    9430:	e8 8b b4 ff ff       	call   48c0 <fwp_rc_fresh>
    9435:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    943c:	00 
    943d:	bf 01 00 00 00       	mov    $0x1,%edi
    9442:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    9449:	00 
    944a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    9451:	00 
    9452:	e8 a9 bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9457:	48 89 c7             	mov    %rax,%rdi
    945a:	e8 61 b4 ff ff       	call   48c0 <fwp_rc_fresh>
    945f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    9466:	00 
    9467:	bf 01 00 00 00       	mov    $0x1,%edi
    946c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    9473:	00 
    9474:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    947b:	00 
    947c:	e8 7f bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9481:	48 89 c7             	mov    %rax,%rdi
    9484:	e8 37 b4 ff ff       	call   48c0 <fwp_rc_fresh>
    9489:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    9490:	00 
    9491:	bf 01 00 00 00       	mov    $0x1,%edi
    9496:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    949d:	00 
    949e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    94a5:	00 
    94a6:	e8 55 bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    94ab:	48 89 c7             	mov    %rax,%rdi
    94ae:	e8 0d b4 ff ff       	call   48c0 <fwp_rc_fresh>
    94b3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    94ba:	00 
    94bb:	bf 01 00 00 00       	mov    $0x1,%edi
    94c0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    94c7:	00 
    94c8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    94cf:	00 
    94d0:	e8 2b bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    94d5:	48 89 c7             	mov    %rax,%rdi
    94d8:	e8 e3 b3 ff ff       	call   48c0 <fwp_rc_fresh>
    94dd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    94e4:	00 
    94e5:	bf 01 00 00 00       	mov    $0x1,%edi
    94ea:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    94f1:	00 
    94f2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    94f9:	00 
    94fa:	e8 01 bc ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    94ff:	48 89 c7             	mov    %rax,%rdi
    9502:	e8 b9 b3 ff ff       	call   48c0 <fwp_rc_fresh>
    9507:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    950e:	00 
    950f:	bf 01 00 00 00       	mov    $0x1,%edi
    9514:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    951b:	00 
    951c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    9523:	00 
    9524:	e8 d7 bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9529:	48 89 c7             	mov    %rax,%rdi
    952c:	e8 8f b3 ff ff       	call   48c0 <fwp_rc_fresh>
    9531:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    9538:	00 
    9539:	bf 01 00 00 00       	mov    $0x1,%edi
    953e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    9545:	00 
    9546:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    954d:	00 
    954e:	e8 ad bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9553:	48 89 c7             	mov    %rax,%rdi
    9556:	e8 65 b3 ff ff       	call   48c0 <fwp_rc_fresh>
    955b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    9562:	00 
    9563:	bf 01 00 00 00       	mov    $0x1,%edi
    9568:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    956f:	00 
    9570:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    9577:	00 
    9578:	e8 83 bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    957d:	48 89 c7             	mov    %rax,%rdi
    9580:	e8 3b b3 ff ff       	call   48c0 <fwp_rc_fresh>
    9585:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    958c:	00 
    958d:	bf 01 00 00 00       	mov    $0x1,%edi
    9592:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    9599:	00 
    959a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    95a1:	00 
    95a2:	e8 59 bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    95a7:	48 89 c7             	mov    %rax,%rdi
    95aa:	e8 11 b3 ff ff       	call   48c0 <fwp_rc_fresh>
    95af:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    95b6:	00 
    95b7:	bf 01 00 00 00       	mov    $0x1,%edi
    95bc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    95c3:	00 
    95c4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    95cb:	00 
    95cc:	e8 2f bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    95d1:	48 89 c7             	mov    %rax,%rdi
    95d4:	e8 e7 b2 ff ff       	call   48c0 <fwp_rc_fresh>
    95d9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    95e0:	00 
    95e1:	bf 01 00 00 00       	mov    $0x1,%edi
    95e6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    95ed:	00 
    95ee:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    95f5:	00 
    95f6:	e8 05 bb ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    95fb:	48 89 c7             	mov    %rax,%rdi
    95fe:	e8 bd b2 ff ff       	call   48c0 <fwp_rc_fresh>
    9603:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    960a:	00 
    960b:	bf 01 00 00 00       	mov    $0x1,%edi
    9610:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    9617:	00 
    9618:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    961f:	00 
    9620:	e8 db ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9625:	48 89 c7             	mov    %rax,%rdi
    9628:	e8 93 b2 ff ff       	call   48c0 <fwp_rc_fresh>
    962d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    9634:	00 
    9635:	bf 01 00 00 00       	mov    $0x1,%edi
    963a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    9641:	00 
    9642:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    9649:	00 
    964a:	e8 b1 ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    964f:	48 89 c7             	mov    %rax,%rdi
    9652:	e8 69 b2 ff ff       	call   48c0 <fwp_rc_fresh>
    9657:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    965e:	00 
    965f:	bf 01 00 00 00       	mov    $0x1,%edi
    9664:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    966b:	00 
    966c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    9673:	00 
    9674:	e8 87 ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9679:	48 89 c7             	mov    %rax,%rdi
    967c:	e8 3f b2 ff ff       	call   48c0 <fwp_rc_fresh>
    9681:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    9688:	00 
    9689:	bf 01 00 00 00       	mov    $0x1,%edi
    968e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    9695:	00 
    9696:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    969d:	00 
    969e:	e8 5d ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    96a3:	48 89 c7             	mov    %rax,%rdi
    96a6:	e8 15 b2 ff ff       	call   48c0 <fwp_rc_fresh>
    96ab:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    96b2:	00 
    96b3:	bf 01 00 00 00       	mov    $0x1,%edi
    96b8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    96bf:	00 
    96c0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    96c7:	00 
    96c8:	e8 33 ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    96cd:	48 89 c7             	mov    %rax,%rdi
    96d0:	e8 eb b1 ff ff       	call   48c0 <fwp_rc_fresh>
    96d5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    96dc:	00 
    96dd:	bf 01 00 00 00       	mov    $0x1,%edi
    96e2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    96e9:	00 
    96ea:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    96f1:	00 
    96f2:	e8 09 ba ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    96f7:	48 89 c7             	mov    %rax,%rdi
    96fa:	e8 c1 b1 ff ff       	call   48c0 <fwp_rc_fresh>
    96ff:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    9706:	00 
    9707:	bf 01 00 00 00       	mov    $0x1,%edi
    970c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    9713:	00 
    9714:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    971b:	00 
    971c:	e8 df b9 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9721:	48 89 c7             	mov    %rax,%rdi
    9724:	e8 97 b1 ff ff       	call   48c0 <fwp_rc_fresh>
    9729:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    9730:	00 
    9731:	bf 01 00 00 00       	mov    $0x1,%edi
    9736:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    973d:	00 
    973e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    9745:	00 
    9746:	e8 b5 b9 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    974b:	48 89 c7             	mov    %rax,%rdi
    974e:	e8 6d b1 ff ff       	call   48c0 <fwp_rc_fresh>
    9753:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    975a:	00 
    975b:	bf 01 00 00 00       	mov    $0x1,%edi
    9760:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    9767:	00 
    9768:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    976f:	00 
    9770:	e8 8b b9 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9775:	48 8b 15 5c 73 01 00 	mov    0x1735c(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    977c:	49 89 c5             	mov    %rax,%r13
    977f:	48 2b 05 2a 73 01 00 	sub    0x1732a(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9786:	48 c1 e2 10          	shl    $0x10,%rdx
    978a:	48 39 d0             	cmp    %rdx,%rax
    978d:	73 59                	jae    97e8 <f0+0x13b8>
    978f:	48 89 c2             	mov    %rax,%rdx
    9792:	48 c1 ea 10          	shr    $0x10,%rdx
    9796:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    979a:	48 8b 15 57 73 01 00 	mov    0x17357(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    97a1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97a5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    97a9:	4d 85 e4             	test   %r12,%r12
    97ac:	74 3a                	je     97e8 <f0+0x13b8>
    97ae:	0f b6 0a             	movzbl (%rdx),%ecx
    97b1:	80 f9 02             	cmp    $0x2,%cl
    97b4:	0f 84 c6 15 00 00    	je     ad80 <f0+0x2950>
    97ba:	80 f9 01             	cmp    $0x1,%cl
    97bd:	75 29                	jne    97e8 <f0+0x13b8>
    97bf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97c2:	0f b7 c0             	movzwl %ax,%eax
    97c5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97c8:	48 0f af c1          	imul   %rcx,%rax
    97cc:	48 c1 e8 20          	shr    $0x20,%rax
    97d0:	48 39 d0             	cmp    %rdx,%rax
    97d3:	73 13                	jae    97e8 <f0+0x13b8>
    97d5:	49 01 c4             	add    %rax,%r12
    97d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    97dd:	0f 84 99 17 00 00    	je     af7c <f0+0x2b4c>
    97e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    97e8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    97ef:	33 f3 bf 
    97f2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    97f9:	00 
    97fa:	bf 01 00 00 00       	mov    $0x1,%edi
    97ff:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    9806:	00 
    9807:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    980e:	00 
    980f:	e8 ec b8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9814:	48 8b 15 bd 72 01 00 	mov    0x172bd(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    981b:	49 89 c5             	mov    %rax,%r13
    981e:	48 2b 05 8b 72 01 00 	sub    0x1728b(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9825:	48 c1 e2 10          	shl    $0x10,%rdx
    9829:	48 39 d0             	cmp    %rdx,%rax
    982c:	73 59                	jae    9887 <f0+0x1457>
    982e:	48 89 c2             	mov    %rax,%rdx
    9831:	48 c1 ea 10          	shr    $0x10,%rdx
    9835:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9839:	48 8b 15 b8 72 01 00 	mov    0x172b8(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9840:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9844:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9848:	4d 85 e4             	test   %r12,%r12
    984b:	74 3a                	je     9887 <f0+0x1457>
    984d:	0f b6 0a             	movzbl (%rdx),%ecx
    9850:	80 f9 02             	cmp    $0x2,%cl
    9853:	0f 84 17 15 00 00    	je     ad70 <f0+0x2940>
    9859:	80 f9 01             	cmp    $0x1,%cl
    985c:	75 29                	jne    9887 <f0+0x1457>
    985e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9861:	0f b7 c0             	movzwl %ax,%eax
    9864:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9867:	48 0f af c1          	imul   %rcx,%rax
    986b:	48 c1 e8 20          	shr    $0x20,%rax
    986f:	48 39 d0             	cmp    %rdx,%rax
    9872:	73 13                	jae    9887 <f0+0x1457>
    9874:	49 01 c4             	add    %rax,%r12
    9877:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    987c:	0f 84 07 17 00 00    	je     af89 <f0+0x2b59>
    9882:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9887:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    988e:	00 f0 3f 
    9891:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    9898:	00 
    9899:	bf 01 00 00 00       	mov    $0x1,%edi
    989e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    98a5:	00 
    98a6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    98ad:	00 
    98ae:	e8 4d b8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    98b3:	48 8b 15 1e 72 01 00 	mov    0x1721e(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    98ba:	49 89 c5             	mov    %rax,%r13
    98bd:	48 2b 05 ec 71 01 00 	sub    0x171ec(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    98c4:	48 c1 e2 10          	shl    $0x10,%rdx
    98c8:	48 39 d0             	cmp    %rdx,%rax
    98cb:	73 59                	jae    9926 <f0+0x14f6>
    98cd:	48 89 c2             	mov    %rax,%rdx
    98d0:	48 c1 ea 10          	shr    $0x10,%rdx
    98d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98d8:	48 8b 15 19 72 01 00 	mov    0x17219(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    98df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98e3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    98e7:	4d 85 e4             	test   %r12,%r12
    98ea:	74 3a                	je     9926 <f0+0x14f6>
    98ec:	0f b6 0a             	movzbl (%rdx),%ecx
    98ef:	80 f9 02             	cmp    $0x2,%cl
    98f2:	0f 84 28 15 00 00    	je     ae20 <f0+0x29f0>
    98f8:	80 f9 01             	cmp    $0x1,%cl
    98fb:	75 29                	jne    9926 <f0+0x14f6>
    98fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9900:	0f b7 c0             	movzwl %ax,%eax
    9903:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9906:	48 0f af c1          	imul   %rcx,%rax
    990a:	48 c1 e8 20          	shr    $0x20,%rax
    990e:	48 39 d0             	cmp    %rdx,%rax
    9911:	73 13                	jae    9926 <f0+0x14f6>
    9913:	49 01 c4             	add    %rax,%r12
    9916:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    991b:	0f 84 75 16 00 00    	je     af96 <f0+0x2b66>
    9921:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9926:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    992d:	33 f3 bf 
    9930:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    9937:	00 
    9938:	bf 01 00 00 00       	mov    $0x1,%edi
    993d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    9944:	00 
    9945:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    994c:	00 
    994d:	e8 ae b7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9952:	48 8b 15 7f 71 01 00 	mov    0x1717f(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9959:	49 89 c5             	mov    %rax,%r13
    995c:	48 2b 05 4d 71 01 00 	sub    0x1714d(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9963:	48 c1 e2 10          	shl    $0x10,%rdx
    9967:	48 39 d0             	cmp    %rdx,%rax
    996a:	73 59                	jae    99c5 <f0+0x1595>
    996c:	48 89 c2             	mov    %rax,%rdx
    996f:	48 c1 ea 10          	shr    $0x10,%rdx
    9973:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9977:	48 8b 15 7a 71 01 00 	mov    0x1717a(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    997e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9982:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9986:	4d 85 e4             	test   %r12,%r12
    9989:	74 3a                	je     99c5 <f0+0x1595>
    998b:	0f b6 0a             	movzbl (%rdx),%ecx
    998e:	80 f9 02             	cmp    $0x2,%cl
    9991:	0f 84 79 14 00 00    	je     ae10 <f0+0x29e0>
    9997:	80 f9 01             	cmp    $0x1,%cl
    999a:	75 29                	jne    99c5 <f0+0x1595>
    999c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    999f:	0f b7 c0             	movzwl %ax,%eax
    99a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99a5:	48 0f af c1          	imul   %rcx,%rax
    99a9:	48 c1 e8 20          	shr    $0x20,%rax
    99ad:	48 39 d0             	cmp    %rdx,%rax
    99b0:	73 13                	jae    99c5 <f0+0x1595>
    99b2:	49 01 c4             	add    %rax,%r12
    99b5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    99ba:	0f 84 e3 15 00 00    	je     afa3 <f0+0x2b73>
    99c0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    99c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    99cc:	00 f0 3f 
    99cf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    99d6:	00 
    99d7:	bf 01 00 00 00       	mov    $0x1,%edi
    99dc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    99e3:	00 
    99e4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    99eb:	00 
    99ec:	e8 0f b7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    99f1:	48 8b 15 e0 70 01 00 	mov    0x170e0(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    99f8:	49 89 c5             	mov    %rax,%r13
    99fb:	48 2b 05 ae 70 01 00 	sub    0x170ae(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9a02:	48 c1 e2 10          	shl    $0x10,%rdx
    9a06:	48 39 d0             	cmp    %rdx,%rax
    9a09:	73 59                	jae    9a64 <f0+0x1634>
    9a0b:	48 89 c2             	mov    %rax,%rdx
    9a0e:	48 c1 ea 10          	shr    $0x10,%rdx
    9a12:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a16:	48 8b 15 db 70 01 00 	mov    0x170db(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9a1d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a21:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9a25:	4d 85 e4             	test   %r12,%r12
    9a28:	74 3a                	je     9a64 <f0+0x1634>
    9a2a:	0f b6 0a             	movzbl (%rdx),%ecx
    9a2d:	80 f9 02             	cmp    $0x2,%cl
    9a30:	0f 84 ca 13 00 00    	je     ae00 <f0+0x29d0>
    9a36:	80 f9 01             	cmp    $0x1,%cl
    9a39:	75 29                	jne    9a64 <f0+0x1634>
    9a3b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a3e:	0f b7 c0             	movzwl %ax,%eax
    9a41:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a44:	48 0f af c1          	imul   %rcx,%rax
    9a48:	48 c1 e8 20          	shr    $0x20,%rax
    9a4c:	48 39 d0             	cmp    %rdx,%rax
    9a4f:	73 13                	jae    9a64 <f0+0x1634>
    9a51:	49 01 c4             	add    %rax,%r12
    9a54:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9a59:	0f 84 51 15 00 00    	je     afb0 <f0+0x2b80>
    9a5f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9a64:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9a6b:	33 f3 bf 
    9a6e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    9a75:	00 
    9a76:	bf 01 00 00 00       	mov    $0x1,%edi
    9a7b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    9a82:	00 
    9a83:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    9a8a:	00 
    9a8b:	e8 70 b6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9a90:	48 8b 15 41 70 01 00 	mov    0x17041(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9a97:	49 89 c5             	mov    %rax,%r13
    9a9a:	48 2b 05 0f 70 01 00 	sub    0x1700f(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    9aa5:	48 39 d0             	cmp    %rdx,%rax
    9aa8:	73 59                	jae    9b03 <f0+0x16d3>
    9aaa:	48 89 c2             	mov    %rax,%rdx
    9aad:	48 c1 ea 10          	shr    $0x10,%rdx
    9ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ab5:	48 8b 15 3c 70 01 00 	mov    0x1703c(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9abc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ac0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9ac4:	4d 85 e4             	test   %r12,%r12
    9ac7:	74 3a                	je     9b03 <f0+0x16d3>
    9ac9:	0f b6 0a             	movzbl (%rdx),%ecx
    9acc:	80 f9 02             	cmp    $0x2,%cl
    9acf:	0f 84 1b 13 00 00    	je     adf0 <f0+0x29c0>
    9ad5:	80 f9 01             	cmp    $0x1,%cl
    9ad8:	75 29                	jne    9b03 <f0+0x16d3>
    9ada:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9add:	0f b7 c0             	movzwl %ax,%eax
    9ae0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ae3:	48 0f af c1          	imul   %rcx,%rax
    9ae7:	48 c1 e8 20          	shr    $0x20,%rax
    9aeb:	48 39 d0             	cmp    %rdx,%rax
    9aee:	73 13                	jae    9b03 <f0+0x16d3>
    9af0:	49 01 c4             	add    %rax,%r12
    9af3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9af8:	0f 84 bf 14 00 00    	je     afbd <f0+0x2b8d>
    9afe:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9b03:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9b0a:	00 f0 3f 
    9b0d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    9b14:	00 
    9b15:	bf 01 00 00 00       	mov    $0x1,%edi
    9b1a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    9b21:	00 
    9b22:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    9b29:	00 
    9b2a:	e8 d1 b5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9b2f:	48 8b 15 a2 6f 01 00 	mov    0x16fa2(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9b36:	49 89 c5             	mov    %rax,%r13
    9b39:	48 2b 05 70 6f 01 00 	sub    0x16f70(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9b40:	48 c1 e2 10          	shl    $0x10,%rdx
    9b44:	48 39 d0             	cmp    %rdx,%rax
    9b47:	73 59                	jae    9ba2 <f0+0x1772>
    9b49:	48 89 c2             	mov    %rax,%rdx
    9b4c:	48 c1 ea 10          	shr    $0x10,%rdx
    9b50:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b54:	48 8b 15 9d 6f 01 00 	mov    0x16f9d(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9b5b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b5f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9b63:	4d 85 e4             	test   %r12,%r12
    9b66:	74 3a                	je     9ba2 <f0+0x1772>
    9b68:	0f b6 0a             	movzbl (%rdx),%ecx
    9b6b:	80 f9 02             	cmp    $0x2,%cl
    9b6e:	0f 84 6c 12 00 00    	je     ade0 <f0+0x29b0>
    9b74:	80 f9 01             	cmp    $0x1,%cl
    9b77:	75 29                	jne    9ba2 <f0+0x1772>
    9b79:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b7c:	0f b7 c0             	movzwl %ax,%eax
    9b7f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b82:	48 0f af c1          	imul   %rcx,%rax
    9b86:	48 c1 e8 20          	shr    $0x20,%rax
    9b8a:	48 39 d0             	cmp    %rdx,%rax
    9b8d:	73 13                	jae    9ba2 <f0+0x1772>
    9b8f:	49 01 c4             	add    %rax,%r12
    9b92:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9b97:	0f 84 2d 14 00 00    	je     afca <f0+0x2b9a>
    9b9d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ba2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9ba9:	33 f3 bf 
    9bac:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    9bb3:	00 
    9bb4:	bf 01 00 00 00       	mov    $0x1,%edi
    9bb9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    9bc0:	00 
    9bc1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    9bc8:	00 
    9bc9:	e8 32 b5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9bce:	48 8b 15 03 6f 01 00 	mov    0x16f03(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9bd5:	49 89 c5             	mov    %rax,%r13
    9bd8:	48 2b 05 d1 6e 01 00 	sub    0x16ed1(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9bdf:	48 c1 e2 10          	shl    $0x10,%rdx
    9be3:	48 39 d0             	cmp    %rdx,%rax
    9be6:	73 59                	jae    9c41 <f0+0x1811>
    9be8:	48 89 c2             	mov    %rax,%rdx
    9beb:	48 c1 ea 10          	shr    $0x10,%rdx
    9bef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bf3:	48 8b 15 fe 6e 01 00 	mov    0x16efe(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9bfa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bfe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9c02:	4d 85 e4             	test   %r12,%r12
    9c05:	74 3a                	je     9c41 <f0+0x1811>
    9c07:	0f b6 0a             	movzbl (%rdx),%ecx
    9c0a:	80 f9 02             	cmp    $0x2,%cl
    9c0d:	0f 84 bd 11 00 00    	je     add0 <f0+0x29a0>
    9c13:	80 f9 01             	cmp    $0x1,%cl
    9c16:	75 29                	jne    9c41 <f0+0x1811>
    9c18:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c1b:	0f b7 c0             	movzwl %ax,%eax
    9c1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c21:	48 0f af c1          	imul   %rcx,%rax
    9c25:	48 c1 e8 20          	shr    $0x20,%rax
    9c29:	48 39 d0             	cmp    %rdx,%rax
    9c2c:	73 13                	jae    9c41 <f0+0x1811>
    9c2e:	49 01 c4             	add    %rax,%r12
    9c31:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9c36:	0f 84 9b 13 00 00    	je     afd7 <f0+0x2ba7>
    9c3c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9c41:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9c48:	00 f0 3f 
    9c4b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    9c52:	00 
    9c53:	bf 01 00 00 00       	mov    $0x1,%edi
    9c58:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    9c5f:	00 
    9c60:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    9c67:	00 
    9c68:	e8 93 b4 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9c6d:	48 8b 15 64 6e 01 00 	mov    0x16e64(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9c74:	49 89 c5             	mov    %rax,%r13
    9c77:	48 2b 05 32 6e 01 00 	sub    0x16e32(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9c7e:	48 c1 e2 10          	shl    $0x10,%rdx
    9c82:	48 39 d0             	cmp    %rdx,%rax
    9c85:	73 59                	jae    9ce0 <f0+0x18b0>
    9c87:	48 89 c2             	mov    %rax,%rdx
    9c8a:	48 c1 ea 10          	shr    $0x10,%rdx
    9c8e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c92:	48 8b 15 5f 6e 01 00 	mov    0x16e5f(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9c99:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c9d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9ca1:	4d 85 e4             	test   %r12,%r12
    9ca4:	74 3a                	je     9ce0 <f0+0x18b0>
    9ca6:	0f b6 0a             	movzbl (%rdx),%ecx
    9ca9:	80 f9 02             	cmp    $0x2,%cl
    9cac:	0f 84 0e 11 00 00    	je     adc0 <f0+0x2990>
    9cb2:	80 f9 01             	cmp    $0x1,%cl
    9cb5:	75 29                	jne    9ce0 <f0+0x18b0>
    9cb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cba:	0f b7 c0             	movzwl %ax,%eax
    9cbd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cc0:	48 0f af c1          	imul   %rcx,%rax
    9cc4:	48 c1 e8 20          	shr    $0x20,%rax
    9cc8:	48 39 d0             	cmp    %rdx,%rax
    9ccb:	73 13                	jae    9ce0 <f0+0x18b0>
    9ccd:	49 01 c4             	add    %rax,%r12
    9cd0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9cd5:	0f 84 09 13 00 00    	je     afe4 <f0+0x2bb4>
    9cdb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ce0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9ce7:	33 f3 bf 
    9cea:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    9cf1:	00 
    9cf2:	bf 01 00 00 00       	mov    $0x1,%edi
    9cf7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    9cfe:	00 
    9cff:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    9d06:	00 
    9d07:	e8 f4 b3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9d0c:	48 8b 15 c5 6d 01 00 	mov    0x16dc5(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9d13:	49 89 c5             	mov    %rax,%r13
    9d16:	48 2b 05 93 6d 01 00 	sub    0x16d93(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9d1d:	48 c1 e2 10          	shl    $0x10,%rdx
    9d21:	48 39 d0             	cmp    %rdx,%rax
    9d24:	73 59                	jae    9d7f <f0+0x194f>
    9d26:	48 89 c2             	mov    %rax,%rdx
    9d29:	48 c1 ea 10          	shr    $0x10,%rdx
    9d2d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d31:	48 8b 15 c0 6d 01 00 	mov    0x16dc0(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9d38:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d3c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9d40:	4d 85 e4             	test   %r12,%r12
    9d43:	74 3a                	je     9d7f <f0+0x194f>
    9d45:	0f b6 0a             	movzbl (%rdx),%ecx
    9d48:	80 f9 02             	cmp    $0x2,%cl
    9d4b:	0f 84 5f 10 00 00    	je     adb0 <f0+0x2980>
    9d51:	80 f9 01             	cmp    $0x1,%cl
    9d54:	75 29                	jne    9d7f <f0+0x194f>
    9d56:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d59:	0f b7 c0             	movzwl %ax,%eax
    9d5c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d5f:	48 0f af c1          	imul   %rcx,%rax
    9d63:	48 c1 e8 20          	shr    $0x20,%rax
    9d67:	48 39 d0             	cmp    %rdx,%rax
    9d6a:	73 13                	jae    9d7f <f0+0x194f>
    9d6c:	49 01 c4             	add    %rax,%r12
    9d6f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9d74:	0f 84 77 12 00 00    	je     aff1 <f0+0x2bc1>
    9d7a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9d7f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9d86:	00 f0 3f 
    9d89:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    9d90:	00 
    9d91:	bf 01 00 00 00       	mov    $0x1,%edi
    9d96:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    9d9d:	00 
    9d9e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    9da5:	00 
    9da6:	e8 55 b3 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9dab:	48 8b 15 26 6d 01 00 	mov    0x16d26(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9db2:	49 89 c5             	mov    %rax,%r13
    9db5:	48 2b 05 f4 6c 01 00 	sub    0x16cf4(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9dbc:	48 c1 e2 10          	shl    $0x10,%rdx
    9dc0:	48 39 d0             	cmp    %rdx,%rax
    9dc3:	73 59                	jae    9e1e <f0+0x19ee>
    9dc5:	48 89 c2             	mov    %rax,%rdx
    9dc8:	48 c1 ea 10          	shr    $0x10,%rdx
    9dcc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9dd0:	48 8b 15 21 6d 01 00 	mov    0x16d21(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9dd7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ddb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9ddf:	4d 85 e4             	test   %r12,%r12
    9de2:	74 3a                	je     9e1e <f0+0x19ee>
    9de4:	0f b6 0a             	movzbl (%rdx),%ecx
    9de7:	80 f9 02             	cmp    $0x2,%cl
    9dea:	0f 84 40 0f 00 00    	je     ad30 <f0+0x2900>
    9df0:	80 f9 01             	cmp    $0x1,%cl
    9df3:	75 29                	jne    9e1e <f0+0x19ee>
    9df5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9df8:	0f b7 c0             	movzwl %ax,%eax
    9dfb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dfe:	48 0f af c1          	imul   %rcx,%rax
    9e02:	48 c1 e8 20          	shr    $0x20,%rax
    9e06:	48 39 d0             	cmp    %rdx,%rax
    9e09:	73 13                	jae    9e1e <f0+0x19ee>
    9e0b:	49 01 c4             	add    %rax,%r12
    9e0e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9e13:	0f 84 e5 11 00 00    	je     affe <f0+0x2bce>
    9e19:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9e1e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9e25:	33 f3 bf 
    9e28:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    9e2f:	00 
    9e30:	bf 01 00 00 00       	mov    $0x1,%edi
    9e35:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    9e3c:	00 
    9e3d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    9e44:	00 
    9e45:	e8 b6 b2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9e4a:	48 8b 15 87 6c 01 00 	mov    0x16c87(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9e51:	49 89 c5             	mov    %rax,%r13
    9e54:	48 2b 05 55 6c 01 00 	sub    0x16c55(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9e5b:	48 c1 e2 10          	shl    $0x10,%rdx
    9e5f:	48 39 d0             	cmp    %rdx,%rax
    9e62:	73 59                	jae    9ebd <f0+0x1a8d>
    9e64:	48 89 c2             	mov    %rax,%rdx
    9e67:	48 c1 ea 10          	shr    $0x10,%rdx
    9e6b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e6f:	48 8b 15 82 6c 01 00 	mov    0x16c82(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9e76:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e7a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9e7e:	4d 85 e4             	test   %r12,%r12
    9e81:	74 3a                	je     9ebd <f0+0x1a8d>
    9e83:	0f b6 0a             	movzbl (%rdx),%ecx
    9e86:	80 f9 02             	cmp    $0x2,%cl
    9e89:	0f 84 91 0e 00 00    	je     ad20 <f0+0x28f0>
    9e8f:	80 f9 01             	cmp    $0x1,%cl
    9e92:	75 29                	jne    9ebd <f0+0x1a8d>
    9e94:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e97:	0f b7 c0             	movzwl %ax,%eax
    9e9a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e9d:	48 0f af c1          	imul   %rcx,%rax
    9ea1:	48 c1 e8 20          	shr    $0x20,%rax
    9ea5:	48 39 d0             	cmp    %rdx,%rax
    9ea8:	73 13                	jae    9ebd <f0+0x1a8d>
    9eaa:	49 01 c4             	add    %rax,%r12
    9ead:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9eb2:	0f 84 53 11 00 00    	je     b00b <f0+0x2bdb>
    9eb8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ebd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9ec4:	00 f0 3f 
    9ec7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    9ece:	00 
    9ecf:	bf 01 00 00 00       	mov    $0x1,%edi
    9ed4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    9edb:	00 
    9edc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    9ee3:	00 
    9ee4:	e8 17 b2 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9ee9:	48 8b 15 e8 6b 01 00 	mov    0x16be8(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9ef0:	49 89 c5             	mov    %rax,%r13
    9ef3:	48 2b 05 b6 6b 01 00 	sub    0x16bb6(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9efa:	48 c1 e2 10          	shl    $0x10,%rdx
    9efe:	48 39 d0             	cmp    %rdx,%rax
    9f01:	73 59                	jae    9f5c <f0+0x1b2c>
    9f03:	48 89 c2             	mov    %rax,%rdx
    9f06:	48 c1 ea 10          	shr    $0x10,%rdx
    9f0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f0e:	48 8b 15 e3 6b 01 00 	mov    0x16be3(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9f15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f19:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9f1d:	4d 85 e4             	test   %r12,%r12
    9f20:	74 3a                	je     9f5c <f0+0x1b2c>
    9f22:	0f b6 0a             	movzbl (%rdx),%ecx
    9f25:	80 f9 02             	cmp    $0x2,%cl
    9f28:	0f 84 e2 0d 00 00    	je     ad10 <f0+0x28e0>
    9f2e:	80 f9 01             	cmp    $0x1,%cl
    9f31:	75 29                	jne    9f5c <f0+0x1b2c>
    9f33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f36:	0f b7 c0             	movzwl %ax,%eax
    9f39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f3c:	48 0f af c1          	imul   %rcx,%rax
    9f40:	48 c1 e8 20          	shr    $0x20,%rax
    9f44:	48 39 d0             	cmp    %rdx,%rax
    9f47:	73 13                	jae    9f5c <f0+0x1b2c>
    9f49:	49 01 c4             	add    %rax,%r12
    9f4c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9f51:	0f 84 c1 10 00 00    	je     b018 <f0+0x2be8>
    9f57:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9f5c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9f63:	33 f3 bf 
    9f66:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    9f6d:	00 
    9f6e:	bf 01 00 00 00       	mov    $0x1,%edi
    9f73:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    9f7a:	00 
    9f7b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    9f82:	00 
    9f83:	e8 78 b1 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    9f88:	48 8b 15 49 6b 01 00 	mov    0x16b49(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    9f8f:	49 89 c5             	mov    %rax,%r13
    9f92:	48 2b 05 17 6b 01 00 	sub    0x16b17(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    9f99:	48 c1 e2 10          	shl    $0x10,%rdx
    9f9d:	48 39 d0             	cmp    %rdx,%rax
    9fa0:	73 59                	jae    9ffb <f0+0x1bcb>
    9fa2:	48 89 c2             	mov    %rax,%rdx
    9fa5:	48 c1 ea 10          	shr    $0x10,%rdx
    9fa9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fad:	48 8b 15 44 6b 01 00 	mov    0x16b44(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    9fb4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fb8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9fbc:	4d 85 e4             	test   %r12,%r12
    9fbf:	74 3a                	je     9ffb <f0+0x1bcb>
    9fc1:	0f b6 0a             	movzbl (%rdx),%ecx
    9fc4:	80 f9 02             	cmp    $0x2,%cl
    9fc7:	0f 84 33 0d 00 00    	je     ad00 <f0+0x28d0>
    9fcd:	80 f9 01             	cmp    $0x1,%cl
    9fd0:	75 29                	jne    9ffb <f0+0x1bcb>
    9fd2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fd5:	0f b7 c0             	movzwl %ax,%eax
    9fd8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fdb:	48 0f af c1          	imul   %rcx,%rax
    9fdf:	48 c1 e8 20          	shr    $0x20,%rax
    9fe3:	48 39 d0             	cmp    %rdx,%rax
    9fe6:	73 13                	jae    9ffb <f0+0x1bcb>
    9fe8:	49 01 c4             	add    %rax,%r12
    9feb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9ff0:	0f 84 2f 10 00 00    	je     b025 <f0+0x2bf5>
    9ff6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ffb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a002:	00 f0 3f 
    a005:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    a00c:	00 
    a00d:	bf 01 00 00 00       	mov    $0x1,%edi
    a012:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    a019:	00 
    a01a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    a021:	00 
    a022:	e8 d9 b0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a027:	48 8b 15 aa 6a 01 00 	mov    0x16aaa(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a02e:	49 89 c5             	mov    %rax,%r13
    a031:	48 2b 05 78 6a 01 00 	sub    0x16a78(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a038:	48 c1 e2 10          	shl    $0x10,%rdx
    a03c:	48 39 d0             	cmp    %rdx,%rax
    a03f:	73 59                	jae    a09a <f0+0x1c6a>
    a041:	48 89 c2             	mov    %rax,%rdx
    a044:	48 c1 ea 10          	shr    $0x10,%rdx
    a048:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a04c:	48 8b 15 a5 6a 01 00 	mov    0x16aa5(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a053:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a057:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a05b:	4d 85 e4             	test   %r12,%r12
    a05e:	74 3a                	je     a09a <f0+0x1c6a>
    a060:	0f b6 0a             	movzbl (%rdx),%ecx
    a063:	80 f9 02             	cmp    $0x2,%cl
    a066:	0f 84 84 0c 00 00    	je     acf0 <f0+0x28c0>
    a06c:	80 f9 01             	cmp    $0x1,%cl
    a06f:	75 29                	jne    a09a <f0+0x1c6a>
    a071:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a074:	0f b7 c0             	movzwl %ax,%eax
    a077:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a07a:	48 0f af c1          	imul   %rcx,%rax
    a07e:	48 c1 e8 20          	shr    $0x20,%rax
    a082:	48 39 d0             	cmp    %rdx,%rax
    a085:	73 13                	jae    a09a <f0+0x1c6a>
    a087:	49 01 c4             	add    %rax,%r12
    a08a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a08f:	0f 84 9d 0f 00 00    	je     b032 <f0+0x2c02>
    a095:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a09a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a0a1:	33 f3 bf 
    a0a4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    a0ab:	00 
    a0ac:	bf 01 00 00 00       	mov    $0x1,%edi
    a0b1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    a0b8:	00 
    a0b9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    a0c0:	00 
    a0c1:	e8 3a b0 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a0c6:	48 8b 15 0b 6a 01 00 	mov    0x16a0b(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a0cd:	49 89 c5             	mov    %rax,%r13
    a0d0:	48 2b 05 d9 69 01 00 	sub    0x169d9(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a0d7:	48 c1 e2 10          	shl    $0x10,%rdx
    a0db:	48 39 d0             	cmp    %rdx,%rax
    a0de:	73 59                	jae    a139 <f0+0x1d09>
    a0e0:	48 89 c2             	mov    %rax,%rdx
    a0e3:	48 c1 ea 10          	shr    $0x10,%rdx
    a0e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0eb:	48 8b 15 06 6a 01 00 	mov    0x16a06(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a0f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0f6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a0fa:	4d 85 e4             	test   %r12,%r12
    a0fd:	74 3a                	je     a139 <f0+0x1d09>
    a0ff:	0f b6 0a             	movzbl (%rdx),%ecx
    a102:	80 f9 02             	cmp    $0x2,%cl
    a105:	0f 84 d5 0b 00 00    	je     ace0 <f0+0x28b0>
    a10b:	80 f9 01             	cmp    $0x1,%cl
    a10e:	75 29                	jne    a139 <f0+0x1d09>
    a110:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a113:	0f b7 c0             	movzwl %ax,%eax
    a116:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a119:	48 0f af c1          	imul   %rcx,%rax
    a11d:	48 c1 e8 20          	shr    $0x20,%rax
    a121:	48 39 d0             	cmp    %rdx,%rax
    a124:	73 13                	jae    a139 <f0+0x1d09>
    a126:	49 01 c4             	add    %rax,%r12
    a129:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a12e:	0f 84 0b 0f 00 00    	je     b03f <f0+0x2c0f>
    a134:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a139:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a140:	00 f0 3f 
    a143:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    a14a:	00 
    a14b:	bf 01 00 00 00       	mov    $0x1,%edi
    a150:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    a157:	00 
    a158:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    a15f:	00 
    a160:	e8 9b af ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a165:	48 8b 15 6c 69 01 00 	mov    0x1696c(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a16c:	49 89 c5             	mov    %rax,%r13
    a16f:	48 2b 05 3a 69 01 00 	sub    0x1693a(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a176:	48 c1 e2 10          	shl    $0x10,%rdx
    a17a:	48 39 d0             	cmp    %rdx,%rax
    a17d:	73 59                	jae    a1d8 <f0+0x1da8>
    a17f:	48 89 c2             	mov    %rax,%rdx
    a182:	48 c1 ea 10          	shr    $0x10,%rdx
    a186:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a18a:	48 8b 15 67 69 01 00 	mov    0x16967(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a191:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a195:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a199:	4d 85 e4             	test   %r12,%r12
    a19c:	74 3a                	je     a1d8 <f0+0x1da8>
    a19e:	0f b6 0a             	movzbl (%rdx),%ecx
    a1a1:	80 f9 02             	cmp    $0x2,%cl
    a1a4:	0f 84 26 0b 00 00    	je     acd0 <f0+0x28a0>
    a1aa:	80 f9 01             	cmp    $0x1,%cl
    a1ad:	75 29                	jne    a1d8 <f0+0x1da8>
    a1af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1b2:	0f b7 c0             	movzwl %ax,%eax
    a1b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1b8:	48 0f af c1          	imul   %rcx,%rax
    a1bc:	48 c1 e8 20          	shr    $0x20,%rax
    a1c0:	48 39 d0             	cmp    %rdx,%rax
    a1c3:	73 13                	jae    a1d8 <f0+0x1da8>
    a1c5:	49 01 c4             	add    %rax,%r12
    a1c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a1cd:	0f 84 79 0e 00 00    	je     b04c <f0+0x2c1c>
    a1d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a1d8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a1df:	33 f3 bf 
    a1e2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    a1e9:	00 
    a1ea:	bf 01 00 00 00       	mov    $0x1,%edi
    a1ef:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    a1f6:	00 
    a1f7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    a1fe:	00 
    a1ff:	e8 fc ae ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a204:	48 8b 15 cd 68 01 00 	mov    0x168cd(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a20b:	49 89 c5             	mov    %rax,%r13
    a20e:	48 2b 05 9b 68 01 00 	sub    0x1689b(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a215:	48 c1 e2 10          	shl    $0x10,%rdx
    a219:	48 39 d0             	cmp    %rdx,%rax
    a21c:	73 59                	jae    a277 <f0+0x1e47>
    a21e:	48 89 c2             	mov    %rax,%rdx
    a221:	48 c1 ea 10          	shr    $0x10,%rdx
    a225:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a229:	48 8b 15 c8 68 01 00 	mov    0x168c8(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a230:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a234:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a238:	4d 85 e4             	test   %r12,%r12
    a23b:	74 3a                	je     a277 <f0+0x1e47>
    a23d:	0f b6 0a             	movzbl (%rdx),%ecx
    a240:	80 f9 02             	cmp    $0x2,%cl
    a243:	0f 84 77 0a 00 00    	je     acc0 <f0+0x2890>
    a249:	80 f9 01             	cmp    $0x1,%cl
    a24c:	75 29                	jne    a277 <f0+0x1e47>
    a24e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a251:	0f b7 c0             	movzwl %ax,%eax
    a254:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a257:	48 0f af c1          	imul   %rcx,%rax
    a25b:	48 c1 e8 20          	shr    $0x20,%rax
    a25f:	48 39 d0             	cmp    %rdx,%rax
    a262:	73 13                	jae    a277 <f0+0x1e47>
    a264:	49 01 c4             	add    %rax,%r12
    a267:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a26c:	0f 84 e7 0d 00 00    	je     b059 <f0+0x2c29>
    a272:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a277:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a27e:	00 f0 3f 
    a281:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    a288:	00 
    a289:	bf 01 00 00 00       	mov    $0x1,%edi
    a28e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    a295:	00 
    a296:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    a29d:	00 
    a29e:	e8 5d ae ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a2a3:	48 8b 15 2e 68 01 00 	mov    0x1682e(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a2aa:	49 89 c5             	mov    %rax,%r13
    a2ad:	48 2b 05 fc 67 01 00 	sub    0x167fc(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a2b4:	48 c1 e2 10          	shl    $0x10,%rdx
    a2b8:	48 39 d0             	cmp    %rdx,%rax
    a2bb:	73 59                	jae    a316 <f0+0x1ee6>
    a2bd:	48 89 c2             	mov    %rax,%rdx
    a2c0:	48 c1 ea 10          	shr    $0x10,%rdx
    a2c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2c8:	48 8b 15 29 68 01 00 	mov    0x16829(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a2cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a2d7:	4d 85 e4             	test   %r12,%r12
    a2da:	74 3a                	je     a316 <f0+0x1ee6>
    a2dc:	0f b6 0a             	movzbl (%rdx),%ecx
    a2df:	80 f9 02             	cmp    $0x2,%cl
    a2e2:	0f 84 38 0c 00 00    	je     af20 <f0+0x2af0>
    a2e8:	80 f9 01             	cmp    $0x1,%cl
    a2eb:	75 29                	jne    a316 <f0+0x1ee6>
    a2ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2f0:	0f b7 c0             	movzwl %ax,%eax
    a2f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2f6:	48 0f af c1          	imul   %rcx,%rax
    a2fa:	48 c1 e8 20          	shr    $0x20,%rax
    a2fe:	48 39 d0             	cmp    %rdx,%rax
    a301:	73 13                	jae    a316 <f0+0x1ee6>
    a303:	49 01 c4             	add    %rax,%r12
    a306:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a30b:	0f 84 55 0d 00 00    	je     b066 <f0+0x2c36>
    a311:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a316:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a31d:	33 f3 bf 
    a320:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    a327:	00 
    a328:	bf 01 00 00 00       	mov    $0x1,%edi
    a32d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    a334:	00 
    a335:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    a33c:	00 
    a33d:	e8 be ad ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a342:	48 8b 15 8f 67 01 00 	mov    0x1678f(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a349:	49 89 c5             	mov    %rax,%r13
    a34c:	48 2b 05 5d 67 01 00 	sub    0x1675d(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a353:	48 c1 e2 10          	shl    $0x10,%rdx
    a357:	48 39 d0             	cmp    %rdx,%rax
    a35a:	73 59                	jae    a3b5 <f0+0x1f85>
    a35c:	48 89 c2             	mov    %rax,%rdx
    a35f:	48 c1 ea 10          	shr    $0x10,%rdx
    a363:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a367:	48 8b 15 8a 67 01 00 	mov    0x1678a(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a36e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a372:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a376:	4d 85 e4             	test   %r12,%r12
    a379:	74 3a                	je     a3b5 <f0+0x1f85>
    a37b:	0f b6 0a             	movzbl (%rdx),%ecx
    a37e:	80 f9 02             	cmp    $0x2,%cl
    a381:	0f 84 89 0b 00 00    	je     af10 <f0+0x2ae0>
    a387:	80 f9 01             	cmp    $0x1,%cl
    a38a:	75 29                	jne    a3b5 <f0+0x1f85>
    a38c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a38f:	0f b7 c0             	movzwl %ax,%eax
    a392:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a395:	48 0f af c1          	imul   %rcx,%rax
    a399:	48 c1 e8 20          	shr    $0x20,%rax
    a39d:	48 39 d0             	cmp    %rdx,%rax
    a3a0:	73 13                	jae    a3b5 <f0+0x1f85>
    a3a2:	49 01 c4             	add    %rax,%r12
    a3a5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a3aa:	0f 84 c3 0c 00 00    	je     b073 <f0+0x2c43>
    a3b0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a3b5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a3bc:	00 f0 3f 
    a3bf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    a3c6:	00 
    a3c7:	bf 01 00 00 00       	mov    $0x1,%edi
    a3cc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    a3d3:	00 
    a3d4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    a3db:	00 
    a3dc:	e8 1f ad ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a3e1:	48 8b 15 f0 66 01 00 	mov    0x166f0(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a3e8:	49 89 c5             	mov    %rax,%r13
    a3eb:	48 2b 05 be 66 01 00 	sub    0x166be(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a3f2:	48 c1 e2 10          	shl    $0x10,%rdx
    a3f6:	48 39 d0             	cmp    %rdx,%rax
    a3f9:	73 59                	jae    a454 <f0+0x2024>
    a3fb:	48 89 c2             	mov    %rax,%rdx
    a3fe:	48 c1 ea 10          	shr    $0x10,%rdx
    a402:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a406:	48 8b 15 eb 66 01 00 	mov    0x166eb(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a40d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a411:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a415:	4d 85 e4             	test   %r12,%r12
    a418:	74 3a                	je     a454 <f0+0x2024>
    a41a:	0f b6 0a             	movzbl (%rdx),%ecx
    a41d:	80 f9 02             	cmp    $0x2,%cl
    a420:	0f 84 da 0a 00 00    	je     af00 <f0+0x2ad0>
    a426:	80 f9 01             	cmp    $0x1,%cl
    a429:	75 29                	jne    a454 <f0+0x2024>
    a42b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a42e:	0f b7 c0             	movzwl %ax,%eax
    a431:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a434:	48 0f af c1          	imul   %rcx,%rax
    a438:	48 c1 e8 20          	shr    $0x20,%rax
    a43c:	48 39 d0             	cmp    %rdx,%rax
    a43f:	73 13                	jae    a454 <f0+0x2024>
    a441:	49 01 c4             	add    %rax,%r12
    a444:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a449:	0f 84 31 0c 00 00    	je     b080 <f0+0x2c50>
    a44f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a454:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a45b:	33 f3 bf 
    a45e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    a465:	00 
    a466:	bf 01 00 00 00       	mov    $0x1,%edi
    a46b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    a472:	00 
    a473:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    a47a:	00 
    a47b:	e8 80 ac ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a480:	48 8b 15 51 66 01 00 	mov    0x16651(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a487:	49 89 c5             	mov    %rax,%r13
    a48a:	48 2b 05 1f 66 01 00 	sub    0x1661f(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a491:	48 c1 e2 10          	shl    $0x10,%rdx
    a495:	48 39 d0             	cmp    %rdx,%rax
    a498:	73 59                	jae    a4f3 <f0+0x20c3>
    a49a:	48 89 c2             	mov    %rax,%rdx
    a49d:	48 c1 ea 10          	shr    $0x10,%rdx
    a4a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4a5:	48 8b 15 4c 66 01 00 	mov    0x1664c(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a4ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4b0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a4b4:	4d 85 e4             	test   %r12,%r12
    a4b7:	74 3a                	je     a4f3 <f0+0x20c3>
    a4b9:	0f b6 0a             	movzbl (%rdx),%ecx
    a4bc:	80 f9 02             	cmp    $0x2,%cl
    a4bf:	0f 84 2b 0a 00 00    	je     aef0 <f0+0x2ac0>
    a4c5:	80 f9 01             	cmp    $0x1,%cl
    a4c8:	75 29                	jne    a4f3 <f0+0x20c3>
    a4ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4cd:	0f b7 c0             	movzwl %ax,%eax
    a4d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4d3:	48 0f af c1          	imul   %rcx,%rax
    a4d7:	48 c1 e8 20          	shr    $0x20,%rax
    a4db:	48 39 d0             	cmp    %rdx,%rax
    a4de:	73 13                	jae    a4f3 <f0+0x20c3>
    a4e0:	49 01 c4             	add    %rax,%r12
    a4e3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a4e8:	0f 84 9f 0b 00 00    	je     b08d <f0+0x2c5d>
    a4ee:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a4f3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a4fa:	00 f0 3f 
    a4fd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    a504:	00 
    a505:	bf 01 00 00 00       	mov    $0x1,%edi
    a50a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    a511:	00 
    a512:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    a519:	00 
    a51a:	e8 e1 ab ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a51f:	48 8b 15 b2 65 01 00 	mov    0x165b2(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a526:	49 89 c5             	mov    %rax,%r13
    a529:	48 2b 05 80 65 01 00 	sub    0x16580(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a530:	48 c1 e2 10          	shl    $0x10,%rdx
    a534:	48 39 d0             	cmp    %rdx,%rax
    a537:	73 59                	jae    a592 <f0+0x2162>
    a539:	48 89 c2             	mov    %rax,%rdx
    a53c:	48 c1 ea 10          	shr    $0x10,%rdx
    a540:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a544:	48 8b 15 ad 65 01 00 	mov    0x165ad(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a54b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a54f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a553:	4d 85 e4             	test   %r12,%r12
    a556:	74 3a                	je     a592 <f0+0x2162>
    a558:	0f b6 0a             	movzbl (%rdx),%ecx
    a55b:	80 f9 02             	cmp    $0x2,%cl
    a55e:	0f 84 7c 09 00 00    	je     aee0 <f0+0x2ab0>
    a564:	80 f9 01             	cmp    $0x1,%cl
    a567:	75 29                	jne    a592 <f0+0x2162>
    a569:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a56c:	0f b7 c0             	movzwl %ax,%eax
    a56f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a572:	48 0f af c1          	imul   %rcx,%rax
    a576:	48 c1 e8 20          	shr    $0x20,%rax
    a57a:	48 39 d0             	cmp    %rdx,%rax
    a57d:	73 13                	jae    a592 <f0+0x2162>
    a57f:	49 01 c4             	add    %rax,%r12
    a582:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a587:	0f 84 0d 0b 00 00    	je     b09a <f0+0x2c6a>
    a58d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a592:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a599:	33 f3 bf 
    a59c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    a5a3:	00 
    a5a4:	bf 01 00 00 00       	mov    $0x1,%edi
    a5a9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    a5b0:	00 
    a5b1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    a5b8:	00 
    a5b9:	e8 42 ab ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a5be:	48 8b 15 13 65 01 00 	mov    0x16513(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a5c5:	49 89 c5             	mov    %rax,%r13
    a5c8:	48 2b 05 e1 64 01 00 	sub    0x164e1(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a5cf:	48 c1 e2 10          	shl    $0x10,%rdx
    a5d3:	48 39 d0             	cmp    %rdx,%rax
    a5d6:	73 59                	jae    a631 <f0+0x2201>
    a5d8:	48 89 c2             	mov    %rax,%rdx
    a5db:	48 c1 ea 10          	shr    $0x10,%rdx
    a5df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5e3:	48 8b 15 0e 65 01 00 	mov    0x1650e(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a5ea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a5ee:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a5f2:	4d 85 e4             	test   %r12,%r12
    a5f5:	74 3a                	je     a631 <f0+0x2201>
    a5f7:	0f b6 0a             	movzbl (%rdx),%ecx
    a5fa:	80 f9 02             	cmp    $0x2,%cl
    a5fd:	0f 84 cd 08 00 00    	je     aed0 <f0+0x2aa0>
    a603:	80 f9 01             	cmp    $0x1,%cl
    a606:	75 29                	jne    a631 <f0+0x2201>
    a608:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a60b:	0f b7 c0             	movzwl %ax,%eax
    a60e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a611:	48 0f af c1          	imul   %rcx,%rax
    a615:	48 c1 e8 20          	shr    $0x20,%rax
    a619:	48 39 d0             	cmp    %rdx,%rax
    a61c:	73 13                	jae    a631 <f0+0x2201>
    a61e:	49 01 c4             	add    %rax,%r12
    a621:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a626:	0f 84 7b 0a 00 00    	je     b0a7 <f0+0x2c77>
    a62c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a631:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a638:	00 f0 3f 
    a63b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    a642:	00 
    a643:	bf 01 00 00 00       	mov    $0x1,%edi
    a648:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    a64f:	00 
    a650:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    a657:	00 
    a658:	e8 a3 aa ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a65d:	48 8b 15 74 64 01 00 	mov    0x16474(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a664:	49 89 c5             	mov    %rax,%r13
    a667:	48 2b 05 42 64 01 00 	sub    0x16442(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a66e:	48 c1 e2 10          	shl    $0x10,%rdx
    a672:	48 39 d0             	cmp    %rdx,%rax
    a675:	73 59                	jae    a6d0 <f0+0x22a0>
    a677:	48 89 c2             	mov    %rax,%rdx
    a67a:	48 c1 ea 10          	shr    $0x10,%rdx
    a67e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a682:	48 8b 15 6f 64 01 00 	mov    0x1646f(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a689:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a68d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a691:	4d 85 e4             	test   %r12,%r12
    a694:	74 3a                	je     a6d0 <f0+0x22a0>
    a696:	0f b6 0a             	movzbl (%rdx),%ecx
    a699:	80 f9 02             	cmp    $0x2,%cl
    a69c:	0f 84 1e 08 00 00    	je     aec0 <f0+0x2a90>
    a6a2:	80 f9 01             	cmp    $0x1,%cl
    a6a5:	75 29                	jne    a6d0 <f0+0x22a0>
    a6a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a6aa:	0f b7 c0             	movzwl %ax,%eax
    a6ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a6b0:	48 0f af c1          	imul   %rcx,%rax
    a6b4:	48 c1 e8 20          	shr    $0x20,%rax
    a6b8:	48 39 d0             	cmp    %rdx,%rax
    a6bb:	73 13                	jae    a6d0 <f0+0x22a0>
    a6bd:	49 01 c4             	add    %rax,%r12
    a6c0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a6c5:	0f 84 e9 09 00 00    	je     b0b4 <f0+0x2c84>
    a6cb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a6d0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a6d7:	33 f3 bf 
    a6da:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    a6e1:	00 
    a6e2:	bf 01 00 00 00       	mov    $0x1,%edi
    a6e7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    a6ee:	00 
    a6ef:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    a6f6:	00 
    a6f7:	e8 04 aa ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a6fc:	48 8b 15 d5 63 01 00 	mov    0x163d5(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a703:	49 89 c5             	mov    %rax,%r13
    a706:	48 2b 05 a3 63 01 00 	sub    0x163a3(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a70d:	48 c1 e2 10          	shl    $0x10,%rdx
    a711:	48 39 d0             	cmp    %rdx,%rax
    a714:	73 59                	jae    a76f <f0+0x233f>
    a716:	48 89 c2             	mov    %rax,%rdx
    a719:	48 c1 ea 10          	shr    $0x10,%rdx
    a71d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a721:	48 8b 15 d0 63 01 00 	mov    0x163d0(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a728:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a72c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a730:	4d 85 e4             	test   %r12,%r12
    a733:	74 3a                	je     a76f <f0+0x233f>
    a735:	0f b6 0a             	movzbl (%rdx),%ecx
    a738:	80 f9 02             	cmp    $0x2,%cl
    a73b:	0f 84 6f 07 00 00    	je     aeb0 <f0+0x2a80>
    a741:	80 f9 01             	cmp    $0x1,%cl
    a744:	75 29                	jne    a76f <f0+0x233f>
    a746:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a749:	0f b7 c0             	movzwl %ax,%eax
    a74c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a74f:	48 0f af c1          	imul   %rcx,%rax
    a753:	48 c1 e8 20          	shr    $0x20,%rax
    a757:	48 39 d0             	cmp    %rdx,%rax
    a75a:	73 13                	jae    a76f <f0+0x233f>
    a75c:	49 01 c4             	add    %rax,%r12
    a75f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a764:	0f 84 57 09 00 00    	je     b0c1 <f0+0x2c91>
    a76a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a76f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a776:	00 f0 3f 
    a779:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    a780:	00 
    a781:	bf 01 00 00 00       	mov    $0x1,%edi
    a786:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    a78d:	00 
    a78e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    a795:	00 
    a796:	e8 65 a9 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a79b:	48 8b 15 36 63 01 00 	mov    0x16336(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a7a2:	49 89 c5             	mov    %rax,%r13
    a7a5:	48 2b 05 04 63 01 00 	sub    0x16304(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a7ac:	48 c1 e2 10          	shl    $0x10,%rdx
    a7b0:	48 39 d0             	cmp    %rdx,%rax
    a7b3:	73 59                	jae    a80e <f0+0x23de>
    a7b5:	48 89 c2             	mov    %rax,%rdx
    a7b8:	48 c1 ea 10          	shr    $0x10,%rdx
    a7bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7c0:	48 8b 15 31 63 01 00 	mov    0x16331(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a7c7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a7cb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a7cf:	4d 85 e4             	test   %r12,%r12
    a7d2:	74 3a                	je     a80e <f0+0x23de>
    a7d4:	0f b6 0a             	movzbl (%rdx),%ecx
    a7d7:	80 f9 02             	cmp    $0x2,%cl
    a7da:	0f 84 c0 06 00 00    	je     aea0 <f0+0x2a70>
    a7e0:	80 f9 01             	cmp    $0x1,%cl
    a7e3:	75 29                	jne    a80e <f0+0x23de>
    a7e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a7e8:	0f b7 c0             	movzwl %ax,%eax
    a7eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a7ee:	48 0f af c1          	imul   %rcx,%rax
    a7f2:	48 c1 e8 20          	shr    $0x20,%rax
    a7f6:	48 39 d0             	cmp    %rdx,%rax
    a7f9:	73 13                	jae    a80e <f0+0x23de>
    a7fb:	49 01 c4             	add    %rax,%r12
    a7fe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a803:	0f 84 c5 08 00 00    	je     b0ce <f0+0x2c9e>
    a809:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a80e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a815:	33 f3 bf 
    a818:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    a81f:	00 
    a820:	bf 01 00 00 00       	mov    $0x1,%edi
    a825:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    a82c:	00 
    a82d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    a834:	00 
    a835:	e8 c6 a8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a83a:	48 8b 15 97 62 01 00 	mov    0x16297(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a841:	49 89 c5             	mov    %rax,%r13
    a844:	48 2b 05 65 62 01 00 	sub    0x16265(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a84b:	48 c1 e2 10          	shl    $0x10,%rdx
    a84f:	48 39 d0             	cmp    %rdx,%rax
    a852:	73 59                	jae    a8ad <f0+0x247d>
    a854:	48 89 c2             	mov    %rax,%rdx
    a857:	48 c1 ea 10          	shr    $0x10,%rdx
    a85b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a85f:	48 8b 15 92 62 01 00 	mov    0x16292(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a866:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a86a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a86e:	4d 85 e4             	test   %r12,%r12
    a871:	74 3a                	je     a8ad <f0+0x247d>
    a873:	0f b6 0a             	movzbl (%rdx),%ecx
    a876:	80 f9 02             	cmp    $0x2,%cl
    a879:	0f 84 11 06 00 00    	je     ae90 <f0+0x2a60>
    a87f:	80 f9 01             	cmp    $0x1,%cl
    a882:	75 29                	jne    a8ad <f0+0x247d>
    a884:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a887:	0f b7 c0             	movzwl %ax,%eax
    a88a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a88d:	48 0f af c1          	imul   %rcx,%rax
    a891:	48 c1 e8 20          	shr    $0x20,%rax
    a895:	48 39 d0             	cmp    %rdx,%rax
    a898:	73 13                	jae    a8ad <f0+0x247d>
    a89a:	49 01 c4             	add    %rax,%r12
    a89d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a8a2:	0f 84 33 08 00 00    	je     b0db <f0+0x2cab>
    a8a8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a8ad:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a8b4:	00 f0 3f 
    a8b7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    a8be:	00 
    a8bf:	bf 01 00 00 00       	mov    $0x1,%edi
    a8c4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    a8cb:	00 
    a8cc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    a8d3:	00 
    a8d4:	e8 27 a8 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a8d9:	48 8b 15 f8 61 01 00 	mov    0x161f8(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a8e0:	49 89 c5             	mov    %rax,%r13
    a8e3:	48 2b 05 c6 61 01 00 	sub    0x161c6(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a8ea:	48 c1 e2 10          	shl    $0x10,%rdx
    a8ee:	48 39 d0             	cmp    %rdx,%rax
    a8f1:	73 59                	jae    a94c <f0+0x251c>
    a8f3:	48 89 c2             	mov    %rax,%rdx
    a8f6:	48 c1 ea 10          	shr    $0x10,%rdx
    a8fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8fe:	48 8b 15 f3 61 01 00 	mov    0x161f3(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a905:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a909:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a90d:	4d 85 e4             	test   %r12,%r12
    a910:	74 3a                	je     a94c <f0+0x251c>
    a912:	0f b6 0a             	movzbl (%rdx),%ecx
    a915:	80 f9 02             	cmp    $0x2,%cl
    a918:	0f 84 62 05 00 00    	je     ae80 <f0+0x2a50>
    a91e:	80 f9 01             	cmp    $0x1,%cl
    a921:	75 29                	jne    a94c <f0+0x251c>
    a923:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a926:	0f b7 c0             	movzwl %ax,%eax
    a929:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a92c:	48 0f af c1          	imul   %rcx,%rax
    a930:	48 c1 e8 20          	shr    $0x20,%rax
    a934:	48 39 d0             	cmp    %rdx,%rax
    a937:	73 13                	jae    a94c <f0+0x251c>
    a939:	49 01 c4             	add    %rax,%r12
    a93c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a941:	0f 84 a1 07 00 00    	je     b0e8 <f0+0x2cb8>
    a947:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a94c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a953:	33 f3 bf 
    a956:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    a95d:	00 
    a95e:	bf 01 00 00 00       	mov    $0x1,%edi
    a963:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    a96a:	00 
    a96b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    a972:	00 
    a973:	e8 88 a7 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    a978:	48 8b 15 59 61 01 00 	mov    0x16159(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    a97f:	49 89 c5             	mov    %rax,%r13
    a982:	48 2b 05 27 61 01 00 	sub    0x16127(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    a989:	48 c1 e2 10          	shl    $0x10,%rdx
    a98d:	48 39 d0             	cmp    %rdx,%rax
    a990:	73 59                	jae    a9eb <f0+0x25bb>
    a992:	48 89 c2             	mov    %rax,%rdx
    a995:	48 c1 ea 10          	shr    $0x10,%rdx
    a999:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a99d:	48 8b 15 54 61 01 00 	mov    0x16154(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    a9a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9a8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a9ac:	4d 85 e4             	test   %r12,%r12
    a9af:	74 3a                	je     a9eb <f0+0x25bb>
    a9b1:	0f b6 0a             	movzbl (%rdx),%ecx
    a9b4:	80 f9 02             	cmp    $0x2,%cl
    a9b7:	0f 84 b3 04 00 00    	je     ae70 <f0+0x2a40>
    a9bd:	80 f9 01             	cmp    $0x1,%cl
    a9c0:	75 29                	jne    a9eb <f0+0x25bb>
    a9c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9c5:	0f b7 c0             	movzwl %ax,%eax
    a9c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9cb:	48 0f af c1          	imul   %rcx,%rax
    a9cf:	48 c1 e8 20          	shr    $0x20,%rax
    a9d3:	48 39 d0             	cmp    %rdx,%rax
    a9d6:	73 13                	jae    a9eb <f0+0x25bb>
    a9d8:	49 01 c4             	add    %rax,%r12
    a9db:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a9e0:	0f 84 0f 07 00 00    	je     b0f5 <f0+0x2cc5>
    a9e6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a9eb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a9f2:	00 f0 3f 
    a9f5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    a9fc:	00 
    a9fd:	bf 01 00 00 00       	mov    $0x1,%edi
    aa02:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    aa09:	00 
    aa0a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    aa11:	00 
    aa12:	e8 e9 a6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    aa17:	48 8b 15 ba 60 01 00 	mov    0x160ba(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    aa1e:	49 89 c5             	mov    %rax,%r13
    aa21:	48 2b 05 88 60 01 00 	sub    0x16088(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    aa28:	48 c1 e2 10          	shl    $0x10,%rdx
    aa2c:	48 39 d0             	cmp    %rdx,%rax
    aa2f:	73 59                	jae    aa8a <f0+0x265a>
    aa31:	48 89 c2             	mov    %rax,%rdx
    aa34:	48 c1 ea 10          	shr    $0x10,%rdx
    aa38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa3c:	48 8b 15 b5 60 01 00 	mov    0x160b5(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    aa43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa47:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aa4b:	4d 85 e4             	test   %r12,%r12
    aa4e:	74 3a                	je     aa8a <f0+0x265a>
    aa50:	0f b6 0a             	movzbl (%rdx),%ecx
    aa53:	80 f9 02             	cmp    $0x2,%cl
    aa56:	0f 84 04 04 00 00    	je     ae60 <f0+0x2a30>
    aa5c:	80 f9 01             	cmp    $0x1,%cl
    aa5f:	75 29                	jne    aa8a <f0+0x265a>
    aa61:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa64:	0f b7 c0             	movzwl %ax,%eax
    aa67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa6a:	48 0f af c1          	imul   %rcx,%rax
    aa6e:	48 c1 e8 20          	shr    $0x20,%rax
    aa72:	48 39 d0             	cmp    %rdx,%rax
    aa75:	73 13                	jae    aa8a <f0+0x265a>
    aa77:	49 01 c4             	add    %rax,%r12
    aa7a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aa7f:	0f 84 7d 06 00 00    	je     b102 <f0+0x2cd2>
    aa85:	41 c6 04 24 01       	movb   $0x1,(%r12)
    aa8a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    aa91:	33 f3 bf 
    aa94:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    aa9b:	00 
    aa9c:	bf 01 00 00 00       	mov    $0x1,%edi
    aaa1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    aaa8:	00 
    aaa9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    aab0:	00 
    aab1:	e8 4a a6 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    aab6:	48 8b 15 1b 60 01 00 	mov    0x1601b(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    aabd:	49 89 c5             	mov    %rax,%r13
    aac0:	48 2b 05 e9 5f 01 00 	sub    0x15fe9(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    aac7:	48 c1 e2 10          	shl    $0x10,%rdx
    aacb:	48 39 d0             	cmp    %rdx,%rax
    aace:	73 59                	jae    ab29 <f0+0x26f9>
    aad0:	48 89 c2             	mov    %rax,%rdx
    aad3:	48 c1 ea 10          	shr    $0x10,%rdx
    aad7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aadb:	48 8b 15 16 60 01 00 	mov    0x16016(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    aae2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aae6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aaea:	4d 85 e4             	test   %r12,%r12
    aaed:	74 3a                	je     ab29 <f0+0x26f9>
    aaef:	0f b6 0a             	movzbl (%rdx),%ecx
    aaf2:	80 f9 02             	cmp    $0x2,%cl
    aaf5:	0f 84 55 03 00 00    	je     ae50 <f0+0x2a20>
    aafb:	80 f9 01             	cmp    $0x1,%cl
    aafe:	75 29                	jne    ab29 <f0+0x26f9>
    ab00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab03:	0f b7 c0             	movzwl %ax,%eax
    ab06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab09:	48 0f af c1          	imul   %rcx,%rax
    ab0d:	48 c1 e8 20          	shr    $0x20,%rax
    ab11:	48 39 d0             	cmp    %rdx,%rax
    ab14:	73 13                	jae    ab29 <f0+0x26f9>
    ab16:	49 01 c4             	add    %rax,%r12
    ab19:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ab1e:	0f 84 eb 05 00 00    	je     b10f <f0+0x2cdf>
    ab24:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ab29:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ab30:	00 f0 3f 
    ab33:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    ab3a:	00 
    ab3b:	bf 01 00 00 00       	mov    $0x1,%edi
    ab40:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    ab47:	00 
    ab48:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    ab4f:	00 
    ab50:	e8 ab a5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    ab55:	48 8b 15 7c 5f 01 00 	mov    0x15f7c(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    ab5c:	49 89 c5             	mov    %rax,%r13
    ab5f:	48 2b 05 4a 5f 01 00 	sub    0x15f4a(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    ab66:	48 c1 e2 10          	shl    $0x10,%rdx
    ab6a:	48 39 d0             	cmp    %rdx,%rax
    ab6d:	73 59                	jae    abc8 <f0+0x2798>
    ab6f:	48 89 c2             	mov    %rax,%rdx
    ab72:	48 c1 ea 10          	shr    $0x10,%rdx
    ab76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab7a:	48 8b 15 77 5f 01 00 	mov    0x15f77(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    ab81:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab85:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ab89:	4d 85 e4             	test   %r12,%r12
    ab8c:	74 3a                	je     abc8 <f0+0x2798>
    ab8e:	0f b6 0a             	movzbl (%rdx),%ecx
    ab91:	80 f9 02             	cmp    $0x2,%cl
    ab94:	0f 84 a6 02 00 00    	je     ae40 <f0+0x2a10>
    ab9a:	80 f9 01             	cmp    $0x1,%cl
    ab9d:	75 29                	jne    abc8 <f0+0x2798>
    ab9f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aba2:	0f b7 c0             	movzwl %ax,%eax
    aba5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aba8:	48 0f af c1          	imul   %rcx,%rax
    abac:	48 c1 e8 20          	shr    $0x20,%rax
    abb0:	48 39 d0             	cmp    %rdx,%rax
    abb3:	73 13                	jae    abc8 <f0+0x2798>
    abb5:	49 01 c4             	add    %rax,%r12
    abb8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    abbd:	0f 84 59 05 00 00    	je     b11c <f0+0x2cec>
    abc3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    abc8:	48 89 ee             	mov    %rbp,%rsi
    abcb:	bf 01 00 00 00       	mov    $0x1,%edi
    abd0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    abd7:	33 f3 bf 
    abda:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    abe1:	00 
    abe2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    abe9:	00 
    abea:	e8 11 a5 ff ff       	call   5100 <fwp_data.part.0.constprop.0>
    abef:	48 8b 15 e2 5e 01 00 	mov    0x15ee2(%rip),%rdx        # 20ad8 <fwp_heap+0x13d8>
    abf6:	48 89 c5             	mov    %rax,%rbp
    abf9:	48 2b 05 b0 5e 01 00 	sub    0x15eb0(%rip),%rax        # 20ab0 <fwp_heap+0x13b0>
    ac00:	48 c1 e2 10          	shl    $0x10,%rdx
    ac04:	48 39 d0             	cmp    %rdx,%rax
    ac07:	73 59                	jae    ac62 <f0+0x2832>
    ac09:	48 89 c2             	mov    %rax,%rdx
    ac0c:	48 c1 ea 10          	shr    $0x10,%rdx
    ac10:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac14:	48 8b 15 dd 5e 01 00 	mov    0x15edd(%rip),%rdx        # 20af8 <fwp_heap+0x13f8>
    ac1b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac1f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac23:	4d 85 e4             	test   %r12,%r12
    ac26:	74 3a                	je     ac62 <f0+0x2832>
    ac28:	0f b6 0a             	movzbl (%rdx),%ecx
    ac2b:	80 f9 02             	cmp    $0x2,%cl
    ac2e:	0f 84 fc 01 00 00    	je     ae30 <f0+0x2a00>
    ac34:	80 f9 01             	cmp    $0x1,%cl
    ac37:	75 29                	jne    ac62 <f0+0x2832>
    ac39:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac3c:	0f b7 c0             	movzwl %ax,%eax
    ac3f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac42:	48 0f af c1          	imul   %rcx,%rax
    ac46:	48 c1 e8 20          	shr    $0x20,%rax
    ac4a:	48 39 d0             	cmp    %rdx,%rax
    ac4d:	73 13                	jae    ac62 <f0+0x2832>
    ac4f:	49 01 c4             	add    %rax,%r12
    ac52:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ac57:	0f 84 d1 02 00 00    	je     af2e <f0+0x2afe>
    ac5d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ac62:	48 89 de             	mov    %rbx,%rsi
    ac65:	48 89 ef             	mov    %rbp,%rdi
    ac68:	e8 43 d3 ff ff       	call   7fb0 <fwp_hof0.constprop.0>
    ac6d:	48 89 ef             	mov    %rbp,%rdi
    ac70:	e8 9b ac ff ff       	call   5910 <fwp_drop0>
    ac75:	48 89 df             	mov    %rbx,%rdi
    ac78:	e8 93 ac ff ff       	call   5910 <fwp_drop0>
    ac7d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    ac84:	00 
    ac85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ac8c:	00 00 
    ac8e:	0f 85 95 04 00 00    	jne    b129 <f0+0x2cf9>
    ac94:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    ac9b:	31 c0                	xor    %eax,%eax
    ac9d:	5b                   	pop    %rbx
    ac9e:	5d                   	pop    %rbp
    ac9f:	41 5c                	pop    %r12
    aca1:	41 5d                	pop    %r13
    aca3:	41 5e                	pop    %r14
    aca5:	c3                   	ret
    aca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    acad:	00 00 00 
    acb0:	4c 89 ef             	mov    %r13,%rdi
    acb3:	e8 d8 93 ff ff       	call   4090 <fwp_rc_forget_slot>
    acb8:	e9 2c d8 ff ff       	jmp    84e9 <f0+0xb9>
    acbd:	0f 1f 00             	nopl   (%rax)
    acc0:	66 85 c0             	test   %ax,%ax
    acc3:	0f 85 ae f5 ff ff    	jne    a277 <f0+0x1e47>
    acc9:	e9 99 f5 ff ff       	jmp    a267 <f0+0x1e37>
    acce:	66 90                	xchg   %ax,%ax
    acd0:	66 85 c0             	test   %ax,%ax
    acd3:	0f 85 ff f4 ff ff    	jne    a1d8 <f0+0x1da8>
    acd9:	e9 ea f4 ff ff       	jmp    a1c8 <f0+0x1d98>
    acde:	66 90                	xchg   %ax,%ax
    ace0:	66 85 c0             	test   %ax,%ax
    ace3:	0f 85 50 f4 ff ff    	jne    a139 <f0+0x1d09>
    ace9:	e9 3b f4 ff ff       	jmp    a129 <f0+0x1cf9>
    acee:	66 90                	xchg   %ax,%ax
    acf0:	66 85 c0             	test   %ax,%ax
    acf3:	0f 85 a1 f3 ff ff    	jne    a09a <f0+0x1c6a>
    acf9:	e9 8c f3 ff ff       	jmp    a08a <f0+0x1c5a>
    acfe:	66 90                	xchg   %ax,%ax
    ad00:	66 85 c0             	test   %ax,%ax
    ad03:	0f 85 f2 f2 ff ff    	jne    9ffb <f0+0x1bcb>
    ad09:	e9 dd f2 ff ff       	jmp    9feb <f0+0x1bbb>
    ad0e:	66 90                	xchg   %ax,%ax
    ad10:	66 85 c0             	test   %ax,%ax
    ad13:	0f 85 43 f2 ff ff    	jne    9f5c <f0+0x1b2c>
    ad19:	e9 2e f2 ff ff       	jmp    9f4c <f0+0x1b1c>
    ad1e:	66 90                	xchg   %ax,%ax
    ad20:	66 85 c0             	test   %ax,%ax
    ad23:	0f 85 94 f1 ff ff    	jne    9ebd <f0+0x1a8d>
    ad29:	e9 7f f1 ff ff       	jmp    9ead <f0+0x1a7d>
    ad2e:	66 90                	xchg   %ax,%ax
    ad30:	66 85 c0             	test   %ax,%ax
    ad33:	0f 85 e5 f0 ff ff    	jne    9e1e <f0+0x19ee>
    ad39:	e9 d0 f0 ff ff       	jmp    9e0e <f0+0x19de>
    ad3e:	66 90                	xchg   %ax,%ax
    ad40:	66 85 c0             	test   %ax,%ax
    ad43:	0f 85 fd d9 ff ff    	jne    8746 <f0+0x316>
    ad49:	e9 e8 d9 ff ff       	jmp    8736 <f0+0x306>
    ad4e:	66 90                	xchg   %ax,%ax
    ad50:	66 85 c0             	test   %ax,%ax
    ad53:	0f 85 57 d9 ff ff    	jne    86b0 <f0+0x280>
    ad59:	e9 42 d9 ff ff       	jmp    86a0 <f0+0x270>
    ad5e:	66 90                	xchg   %ax,%ax
    ad60:	66 85 c0             	test   %ax,%ax
    ad63:	0f 85 b1 d8 ff ff    	jne    861a <f0+0x1ea>
    ad69:	e9 9c d8 ff ff       	jmp    860a <f0+0x1da>
    ad6e:	66 90                	xchg   %ax,%ax
    ad70:	66 85 c0             	test   %ax,%ax
    ad73:	0f 85 0e eb ff ff    	jne    9887 <f0+0x1457>
    ad79:	e9 f9 ea ff ff       	jmp    9877 <f0+0x1447>
    ad7e:	66 90                	xchg   %ax,%ax
    ad80:	66 85 c0             	test   %ax,%ax
    ad83:	0f 85 5f ea ff ff    	jne    97e8 <f0+0x13b8>
    ad89:	e9 4a ea ff ff       	jmp    97d8 <f0+0x13a8>
    ad8e:	66 90                	xchg   %ax,%ax
    ad90:	66 85 c0             	test   %ax,%ax
    ad93:	0f 85 e2 da ff ff    	jne    887b <f0+0x44b>
    ad99:	e9 cd da ff ff       	jmp    886b <f0+0x43b>
    ad9e:	66 90                	xchg   %ax,%ax
    ada0:	66 85 c0             	test   %ax,%ax
    ada3:	0f 85 33 da ff ff    	jne    87dc <f0+0x3ac>
    ada9:	e9 1e da ff ff       	jmp    87cc <f0+0x39c>
    adae:	66 90                	xchg   %ax,%ax
    adb0:	66 85 c0             	test   %ax,%ax
    adb3:	0f 85 c6 ef ff ff    	jne    9d7f <f0+0x194f>
    adb9:	e9 b1 ef ff ff       	jmp    9d6f <f0+0x193f>
    adbe:	66 90                	xchg   %ax,%ax
    adc0:	66 85 c0             	test   %ax,%ax
    adc3:	0f 85 17 ef ff ff    	jne    9ce0 <f0+0x18b0>
    adc9:	e9 02 ef ff ff       	jmp    9cd0 <f0+0x18a0>
    adce:	66 90                	xchg   %ax,%ax
    add0:	66 85 c0             	test   %ax,%ax
    add3:	0f 85 68 ee ff ff    	jne    9c41 <f0+0x1811>
    add9:	e9 53 ee ff ff       	jmp    9c31 <f0+0x1801>
    adde:	66 90                	xchg   %ax,%ax
    ade0:	66 85 c0             	test   %ax,%ax
    ade3:	0f 85 b9 ed ff ff    	jne    9ba2 <f0+0x1772>
    ade9:	e9 a4 ed ff ff       	jmp    9b92 <f0+0x1762>
    adee:	66 90                	xchg   %ax,%ax
    adf0:	66 85 c0             	test   %ax,%ax
    adf3:	0f 85 0a ed ff ff    	jne    9b03 <f0+0x16d3>
    adf9:	e9 f5 ec ff ff       	jmp    9af3 <f0+0x16c3>
    adfe:	66 90                	xchg   %ax,%ax
    ae00:	66 85 c0             	test   %ax,%ax
    ae03:	0f 85 5b ec ff ff    	jne    9a64 <f0+0x1634>
    ae09:	e9 46 ec ff ff       	jmp    9a54 <f0+0x1624>
    ae0e:	66 90                	xchg   %ax,%ax
    ae10:	66 85 c0             	test   %ax,%ax
    ae13:	0f 85 ac eb ff ff    	jne    99c5 <f0+0x1595>
    ae19:	e9 97 eb ff ff       	jmp    99b5 <f0+0x1585>
    ae1e:	66 90                	xchg   %ax,%ax
    ae20:	66 85 c0             	test   %ax,%ax
    ae23:	0f 85 fd ea ff ff    	jne    9926 <f0+0x14f6>
    ae29:	e9 e8 ea ff ff       	jmp    9916 <f0+0x14e6>
    ae2e:	66 90                	xchg   %ax,%ax
    ae30:	66 85 c0             	test   %ax,%ax
    ae33:	0f 85 29 fe ff ff    	jne    ac62 <f0+0x2832>
    ae39:	e9 14 fe ff ff       	jmp    ac52 <f0+0x2822>
    ae3e:	66 90                	xchg   %ax,%ax
    ae40:	66 85 c0             	test   %ax,%ax
    ae43:	0f 85 7f fd ff ff    	jne    abc8 <f0+0x2798>
    ae49:	e9 6a fd ff ff       	jmp    abb8 <f0+0x2788>
    ae4e:	66 90                	xchg   %ax,%ax
    ae50:	66 85 c0             	test   %ax,%ax
    ae53:	0f 85 d0 fc ff ff    	jne    ab29 <f0+0x26f9>
    ae59:	e9 bb fc ff ff       	jmp    ab19 <f0+0x26e9>
    ae5e:	66 90                	xchg   %ax,%ax
    ae60:	66 85 c0             	test   %ax,%ax
    ae63:	0f 85 21 fc ff ff    	jne    aa8a <f0+0x265a>
    ae69:	e9 0c fc ff ff       	jmp    aa7a <f0+0x264a>
    ae6e:	66 90                	xchg   %ax,%ax
    ae70:	66 85 c0             	test   %ax,%ax
    ae73:	0f 85 72 fb ff ff    	jne    a9eb <f0+0x25bb>
    ae79:	e9 5d fb ff ff       	jmp    a9db <f0+0x25ab>
    ae7e:	66 90                	xchg   %ax,%ax
    ae80:	66 85 c0             	test   %ax,%ax
    ae83:	0f 85 c3 fa ff ff    	jne    a94c <f0+0x251c>
    ae89:	e9 ae fa ff ff       	jmp    a93c <f0+0x250c>
    ae8e:	66 90                	xchg   %ax,%ax
    ae90:	66 85 c0             	test   %ax,%ax
    ae93:	0f 85 14 fa ff ff    	jne    a8ad <f0+0x247d>
    ae99:	e9 ff f9 ff ff       	jmp    a89d <f0+0x246d>
    ae9e:	66 90                	xchg   %ax,%ax
    aea0:	66 85 c0             	test   %ax,%ax
    aea3:	0f 85 65 f9 ff ff    	jne    a80e <f0+0x23de>
    aea9:	e9 50 f9 ff ff       	jmp    a7fe <f0+0x23ce>
    aeae:	66 90                	xchg   %ax,%ax
    aeb0:	66 85 c0             	test   %ax,%ax
    aeb3:	0f 85 b6 f8 ff ff    	jne    a76f <f0+0x233f>
    aeb9:	e9 a1 f8 ff ff       	jmp    a75f <f0+0x232f>
    aebe:	66 90                	xchg   %ax,%ax
    aec0:	66 85 c0             	test   %ax,%ax
    aec3:	0f 85 07 f8 ff ff    	jne    a6d0 <f0+0x22a0>
    aec9:	e9 f2 f7 ff ff       	jmp    a6c0 <f0+0x2290>
    aece:	66 90                	xchg   %ax,%ax
    aed0:	66 85 c0             	test   %ax,%ax
    aed3:	0f 85 58 f7 ff ff    	jne    a631 <f0+0x2201>
    aed9:	e9 43 f7 ff ff       	jmp    a621 <f0+0x21f1>
    aede:	66 90                	xchg   %ax,%ax
    aee0:	66 85 c0             	test   %ax,%ax
    aee3:	0f 85 a9 f6 ff ff    	jne    a592 <f0+0x2162>
    aee9:	e9 94 f6 ff ff       	jmp    a582 <f0+0x2152>
    aeee:	66 90                	xchg   %ax,%ax
    aef0:	66 85 c0             	test   %ax,%ax
    aef3:	0f 85 fa f5 ff ff    	jne    a4f3 <f0+0x20c3>
    aef9:	e9 e5 f5 ff ff       	jmp    a4e3 <f0+0x20b3>
    aefe:	66 90                	xchg   %ax,%ax
    af00:	66 85 c0             	test   %ax,%ax
    af03:	0f 85 4b f5 ff ff    	jne    a454 <f0+0x2024>
    af09:	e9 36 f5 ff ff       	jmp    a444 <f0+0x2014>
    af0e:	66 90                	xchg   %ax,%ax
    af10:	66 85 c0             	test   %ax,%ax
    af13:	0f 85 9c f4 ff ff    	jne    a3b5 <f0+0x1f85>
    af19:	e9 87 f4 ff ff       	jmp    a3a5 <f0+0x1f75>
    af1e:	66 90                	xchg   %ax,%ax
    af20:	66 85 c0             	test   %ax,%ax
    af23:	0f 85 ed f3 ff ff    	jne    a316 <f0+0x1ee6>
    af29:	e9 d8 f3 ff ff       	jmp    a306 <f0+0x1ed6>
    af2e:	4c 89 e7             	mov    %r12,%rdi
    af31:	e8 5a 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af36:	e9 22 fd ff ff       	jmp    ac5d <f0+0x282d>
    af3b:	4c 89 e7             	mov    %r12,%rdi
    af3e:	e8 4d 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af43:	e9 cd d6 ff ff       	jmp    8615 <f0+0x1e5>
    af48:	4c 89 e7             	mov    %r12,%rdi
    af4b:	e8 40 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af50:	e9 56 d7 ff ff       	jmp    86ab <f0+0x27b>
    af55:	4c 89 e7             	mov    %r12,%rdi
    af58:	e8 33 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af5d:	e9 df d7 ff ff       	jmp    8741 <f0+0x311>
    af62:	4c 89 e7             	mov    %r12,%rdi
    af65:	e8 26 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af6a:	e9 68 d8 ff ff       	jmp    87d7 <f0+0x3a7>
    af6f:	4c 89 e7             	mov    %r12,%rdi
    af72:	e8 19 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af77:	e9 fa d8 ff ff       	jmp    8876 <f0+0x446>
    af7c:	4c 89 e7             	mov    %r12,%rdi
    af7f:	e8 0c 91 ff ff       	call   4090 <fwp_rc_forget_slot>
    af84:	e9 5a e8 ff ff       	jmp    97e3 <f0+0x13b3>
    af89:	4c 89 e7             	mov    %r12,%rdi
    af8c:	e8 ff 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    af91:	e9 ec e8 ff ff       	jmp    9882 <f0+0x1452>
    af96:	4c 89 e7             	mov    %r12,%rdi
    af99:	e8 f2 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    af9e:	e9 7e e9 ff ff       	jmp    9921 <f0+0x14f1>
    afa3:	4c 89 e7             	mov    %r12,%rdi
    afa6:	e8 e5 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afab:	e9 10 ea ff ff       	jmp    99c0 <f0+0x1590>
    afb0:	4c 89 e7             	mov    %r12,%rdi
    afb3:	e8 d8 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afb8:	e9 a2 ea ff ff       	jmp    9a5f <f0+0x162f>
    afbd:	4c 89 e7             	mov    %r12,%rdi
    afc0:	e8 cb 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afc5:	e9 34 eb ff ff       	jmp    9afe <f0+0x16ce>
    afca:	4c 89 e7             	mov    %r12,%rdi
    afcd:	e8 be 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afd2:	e9 c6 eb ff ff       	jmp    9b9d <f0+0x176d>
    afd7:	4c 89 e7             	mov    %r12,%rdi
    afda:	e8 b1 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afdf:	e9 58 ec ff ff       	jmp    9c3c <f0+0x180c>
    afe4:	4c 89 e7             	mov    %r12,%rdi
    afe7:	e8 a4 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    afec:	e9 ea ec ff ff       	jmp    9cdb <f0+0x18ab>
    aff1:	4c 89 e7             	mov    %r12,%rdi
    aff4:	e8 97 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    aff9:	e9 7c ed ff ff       	jmp    9d7a <f0+0x194a>
    affe:	4c 89 e7             	mov    %r12,%rdi
    b001:	e8 8a 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b006:	e9 0e ee ff ff       	jmp    9e19 <f0+0x19e9>
    b00b:	4c 89 e7             	mov    %r12,%rdi
    b00e:	e8 7d 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b013:	e9 a0 ee ff ff       	jmp    9eb8 <f0+0x1a88>
    b018:	4c 89 e7             	mov    %r12,%rdi
    b01b:	e8 70 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b020:	e9 32 ef ff ff       	jmp    9f57 <f0+0x1b27>
    b025:	4c 89 e7             	mov    %r12,%rdi
    b028:	e8 63 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b02d:	e9 c4 ef ff ff       	jmp    9ff6 <f0+0x1bc6>
    b032:	4c 89 e7             	mov    %r12,%rdi
    b035:	e8 56 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b03a:	e9 56 f0 ff ff       	jmp    a095 <f0+0x1c65>
    b03f:	4c 89 e7             	mov    %r12,%rdi
    b042:	e8 49 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b047:	e9 e8 f0 ff ff       	jmp    a134 <f0+0x1d04>
    b04c:	4c 89 e7             	mov    %r12,%rdi
    b04f:	e8 3c 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b054:	e9 7a f1 ff ff       	jmp    a1d3 <f0+0x1da3>
    b059:	4c 89 e7             	mov    %r12,%rdi
    b05c:	e8 2f 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b061:	e9 0c f2 ff ff       	jmp    a272 <f0+0x1e42>
    b066:	4c 89 e7             	mov    %r12,%rdi
    b069:	e8 22 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b06e:	e9 9e f2 ff ff       	jmp    a311 <f0+0x1ee1>
    b073:	4c 89 e7             	mov    %r12,%rdi
    b076:	e8 15 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b07b:	e9 30 f3 ff ff       	jmp    a3b0 <f0+0x1f80>
    b080:	4c 89 e7             	mov    %r12,%rdi
    b083:	e8 08 90 ff ff       	call   4090 <fwp_rc_forget_slot>
    b088:	e9 c2 f3 ff ff       	jmp    a44f <f0+0x201f>
    b08d:	4c 89 e7             	mov    %r12,%rdi
    b090:	e8 fb 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b095:	e9 54 f4 ff ff       	jmp    a4ee <f0+0x20be>
    b09a:	4c 89 e7             	mov    %r12,%rdi
    b09d:	e8 ee 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0a2:	e9 e6 f4 ff ff       	jmp    a58d <f0+0x215d>
    b0a7:	4c 89 e7             	mov    %r12,%rdi
    b0aa:	e8 e1 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0af:	e9 78 f5 ff ff       	jmp    a62c <f0+0x21fc>
    b0b4:	4c 89 e7             	mov    %r12,%rdi
    b0b7:	e8 d4 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0bc:	e9 0a f6 ff ff       	jmp    a6cb <f0+0x229b>
    b0c1:	4c 89 e7             	mov    %r12,%rdi
    b0c4:	e8 c7 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0c9:	e9 9c f6 ff ff       	jmp    a76a <f0+0x233a>
    b0ce:	4c 89 e7             	mov    %r12,%rdi
    b0d1:	e8 ba 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0d6:	e9 2e f7 ff ff       	jmp    a809 <f0+0x23d9>
    b0db:	4c 89 e7             	mov    %r12,%rdi
    b0de:	e8 ad 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0e3:	e9 c0 f7 ff ff       	jmp    a8a8 <f0+0x2478>
    b0e8:	4c 89 e7             	mov    %r12,%rdi
    b0eb:	e8 a0 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0f0:	e9 52 f8 ff ff       	jmp    a947 <f0+0x2517>
    b0f5:	4c 89 e7             	mov    %r12,%rdi
    b0f8:	e8 93 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b0fd:	e9 e4 f8 ff ff       	jmp    a9e6 <f0+0x25b6>
    b102:	4c 89 e7             	mov    %r12,%rdi
    b105:	e8 86 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b10a:	e9 76 f9 ff ff       	jmp    aa85 <f0+0x2655>
    b10f:	4c 89 e7             	mov    %r12,%rdi
    b112:	e8 79 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b117:	e9 08 fa ff ff       	jmp    ab24 <f0+0x26f4>
    b11c:	4c 89 e7             	mov    %r12,%rdi
    b11f:	e8 6c 8f ff ff       	call   4090 <fwp_rc_forget_slot>
    b124:	e9 9a fa ff ff       	jmp    abc3 <f0+0x2793>
    b129:	e8 12 73 ff ff       	call   2440 <__stack_chk_fail@plt>
    b12e:	66 90                	xchg   %ax,%ax

000000000000b130 <fwp_main_thread>:
    b130:	f3 0f 1e fa          	endbr64
    b134:	41 54                	push   %r12
    b136:	55                   	push   %rbp
    b137:	53                   	push   %rbx
    b138:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    b13f:	8b 0d 5f 59 01 00    	mov    0x1595f(%rip),%ecx        # 20aa4 <fwp_heap+0x13a4>
    b145:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b14c:	00 00 
    b14e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b155:	00 
    b156:	31 c0                	xor    %eax,%eax
    b158:	85 c9                	test   %ecx,%ecx
    b15a:	0f 84 18 07 00 00    	je     b878 <fwp_main_thread+0x748>
    b160:	8b 15 42 59 01 00    	mov    0x15942(%rip),%edx        # 20aa8 <fwp_heap+0x13a8>
    b166:	85 d2                	test   %edx,%edx
    b168:	0f 85 f2 06 00 00    	jne    b860 <fwp_main_thread+0x730>
    b16e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    b173:	31 f6                	xor    %esi,%esi
    b175:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    b17a:	48 c7 05 0b 3f 01 00 	movq   $0x40000000,0x13f0b(%rip)        # 1f090 <fwp_main_stack_size>
    b181:	00 00 00 40 
    b185:	48 89 05 0c 3f 01 00 	mov    %rax,0x13f0c(%rip)        # 1f098 <fwp_main_stack_top>
    b18c:	48 8d 05 ed 3e 00 00 	lea    0x3eed(%rip),%rax        # f080 <alt.4>
    b193:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b198:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    b19f:	01 00 
    b1a1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    b1a8:	00 
    b1a9:	e8 d2 74 ff ff       	call   2680 <sigaltstack@plt>
    b1ae:	85 c0                	test   %eax,%eax
    b1b0:	0f 85 03 07 00 00    	jne    b8b9 <fwp_main_thread+0x789>
    b1b6:	31 c0                	xor    %eax,%eax
    b1b8:	b9 12 00 00 00       	mov    $0x12,%ecx
    b1bd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    b1c2:	f3 48 ab             	rep stos %rax,(%rdi)
    b1c5:	48 8d 05 a4 7a ff ff 	lea    -0x855c(%rip),%rax        # 2c70 <fwp_segv>
    b1cc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    b1d1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    b1d8:	04 00 00 08 
    b1dc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b1e1:	e8 6a 73 ff ff       	call   2550 <sigemptyset@plt>
    b1e6:	85 c0                	test   %eax,%eax
    b1e8:	0f 85 cb 06 00 00    	jne    b8b9 <fwp_main_thread+0x789>
    b1ee:	31 d2                	xor    %edx,%edx
    b1f0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    b1f5:	bf 0b 00 00 00       	mov    $0xb,%edi
    b1fa:	e8 e1 71 ff ff       	call   23e0 <sigaction@plt>
    b1ff:	85 c0                	test   %eax,%eax
    b201:	0f 85 b2 06 00 00    	jne    b8b9 <fwp_main_thread+0x789>
    b207:	31 d2                	xor    %edx,%edx
    b209:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    b20e:	bf 07 00 00 00       	mov    $0x7,%edi
    b213:	e8 c8 71 ff ff       	call   23e0 <sigaction@plt>
    b218:	85 c0                	test   %eax,%eax
    b21a:	0f 85 99 06 00 00    	jne    b8b9 <fwp_main_thread+0x789>
    b220:	48 8b 05 f9 58 01 00 	mov    0x158f9(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    b227:	48 85 c0             	test   %rax,%rax
    b22a:	0f 88 10 06 00 00    	js     b840 <fwp_main_thread+0x710>
    b230:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b234:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b239:	48 8d 3d 10 7f ff ff 	lea    -0x80f0(%rip),%rdi        # 3150 <ad_raw_report>
    b240:	f2 0f 11 05 58 61 01 	movsd  %xmm0,0x16158(%rip)        # 213a0 <iteration_start_charge>
    b247:	00 
    b248:	c7 05 6e 61 01 00 01 	movl   $0x1,0x1616e(%rip)        # 213c0 <iteration_active>
    b24f:	00 00 00 
    b252:	e8 a9 08 00 00       	call   bb00 <atexit>
    b257:	85 c0                	test   %eax,%eax
    b259:	0f 85 66 06 00 00    	jne    b8c5 <fwp_main_thread+0x795>
    b25f:	8b 05 03 3e 00 00    	mov    0x3e03(%rip),%eax        # f068 <st.2>
    b265:	85 c0                	test   %eax,%eax
    b267:	0f 84 1b 06 00 00    	je     b888 <fwp_main_thread+0x758>
    b26d:	48 8b 2d 6c 44 01 00 	mov    0x1446c(%rip),%rbp        # 1f6e0 <fwp_cur>
    b274:	48 85 ed             	test   %rbp,%rbp
    b277:	0f 84 5f 01 00 00    	je     b3dc <fwp_main_thread+0x2ac>
    b27d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    b282:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    b286:	48 89 eb             	mov    %rbp,%rbx
    b289:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b28e:	0f 84 41 01 00 00    	je     b3d5 <fwp_main_thread+0x2a5>
    b294:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    b299:	0f 84 21 02 00 00    	je     b4c0 <fwp_main_thread+0x390>
    b29f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b2a3:	0f 84 07 02 00 00    	je     b4b0 <fwp_main_thread+0x380>
    b2a9:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b2ad:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b2b1:	0f 85 89 02 00 00    	jne    b540 <fwp_main_thread+0x410>
    b2b7:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b2bb:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b2c2:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b2c6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b2cd:	00 00 00 00 
    b2d1:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b2d8:	48 85 d2             	test   %rdx,%rdx
    b2db:	74 07                	je     b2e4 <fwp_main_thread+0x1b4>
    b2dd:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b2e4:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b2e8:	48 85 c0             	test   %rax,%rax
    b2eb:	74 34                	je     b321 <fwp_main_thread+0x1f1>
    b2ed:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b2f1:	48 8b 05 c0 43 01 00 	mov    0x143c0(%rip),%rax        # 1f6b8 <fwp_timers>
    b2f8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b2fc:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b303:	00 00 00 00 
    b307:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b30e:	48 85 c0             	test   %rax,%rax
    b311:	74 07                	je     b31a <fwp_main_thread+0x1ea>
    b313:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b31a:	48 89 1d 97 43 01 00 	mov    %rbx,0x14397(%rip)        # 1f6b8 <fwp_timers>
    b321:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b325:	e8 e6 99 ff ff       	call   4d10 <fwp_block>
    b32a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b331:	48 85 c9             	test   %rcx,%rcx
    b334:	74 47                	je     b37d <fwp_main_thread+0x24d>
    b336:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b33d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b344:	48 85 d2             	test   %rdx,%rdx
    b347:	0f 84 33 02 00 00    	je     b580 <fwp_main_thread+0x450>
    b34d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b354:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b35b:	48 85 c0             	test   %rax,%rax
    b35e:	74 07                	je     b367 <fwp_main_thread+0x237>
    b360:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b367:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b36e:	00 00 00 00 
    b372:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b376:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b37d:	48 8b 0d 5c 43 01 00 	mov    0x1435c(%rip),%rcx        # 1f6e0 <fwp_cur>
    b384:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b388:	0f 84 a2 01 00 00    	je     b530 <fwp_main_thread+0x400>
    b38e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b395:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b39c:	48 85 d2             	test   %rdx,%rdx
    b39f:	0f 84 db 03 00 00    	je     b780 <fwp_main_thread+0x650>
    b3a5:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b3ac:	48 85 c0             	test   %rax,%rax
    b3af:	74 07                	je     b3b8 <fwp_main_thread+0x288>
    b3b1:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b3b8:	66 0f ef db          	pxor   %xmm3,%xmm3
    b3bc:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b3c0:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b3c7:	48 89 cb             	mov    %rcx,%rbx
    b3ca:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b3cf:	0f 85 bf fe ff ff    	jne    b294 <fwp_main_thread+0x164>
    b3d5:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b3d9:	48 89 dd             	mov    %rbx,%rbp
    b3dc:	48 83 3d 8c 5f 01 00 	cmpq   $0x0,0x15f8c(%rip)        # 21370 <fwp_state_len>
    b3e3:	00 
    b3e4:	0f 84 a6 03 00 00    	je     b790 <fwp_main_thread+0x660>
    b3ea:	48 8b 15 e7 42 01 00 	mov    0x142e7(%rip),%rdx        # 1f6d8 <fwp_root>
    b3f1:	c7 05 85 3c 01 00 00 	movl   $0x0,0x13c85(%rip)        # 1f080 <fwp_exit_code>
    b3f8:	00 00 00 
    b3fb:	48 39 d5             	cmp    %rdx,%rbp
    b3fe:	0f 85 da 04 00 00    	jne    b8de <fwp_main_thread+0x7ae>
    b404:	48 85 d2             	test   %rdx,%rdx
    b407:	0f 84 83 01 00 00    	je     b590 <fwp_main_thread+0x460>
    b40d:	48 8b 0d 94 42 01 00 	mov    0x14294(%rip),%rcx        # 1f6a8 <fwp_tasks_active>
    b414:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    b418:	48 85 c9             	test   %rcx,%rcx
    b41b:	0f 84 6f 01 00 00    	je     b590 <fwp_main_thread+0x460>
    b421:	0f 1f 40 00          	nopl   0x0(%rax)
    b425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b42c:	00 00 00 00 
    b430:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    b434:	75 08                	jne    b43e <fwp_main_thread+0x30e>
    b436:	48 89 cf             	mov    %rcx,%rdi
    b439:	e8 22 7c ff ff       	call   3060 <fwp_cancel_tree.part.0>
    b43e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    b445:	48 85 c9             	test   %rcx,%rcx
    b448:	75 e6                	jne    b430 <fwp_main_thread+0x300>
    b44a:	eb 31                	jmp    b47d <fwp_main_thread+0x34d>
    b44c:	0f 1f 40 00          	nopl   0x0(%rax)
    b450:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    b457:	48 89 15 62 42 01 00 	mov    %rdx,0x14262(%rip)        # 1f6c0 <fwp_ready_tail>
    b45e:	e8 ad 98 ff ff       	call   4d10 <fwp_block>
    b463:	e8 98 96 ff ff       	call   4b00 <fwp_free_zombie>
    b468:	48 83 3d 38 42 01 00 	cmpq   $0x0,0x14238(%rip)        # 1f6a8 <fwp_tasks_active>
    b46f:	00 
    b470:	0f 84 1a 01 00 00    	je     b590 <fwp_main_thread+0x460>
    b476:	48 8b 15 5b 42 01 00 	mov    0x1425b(%rip),%rdx        # 1f6d8 <fwp_root>
    b47d:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    b481:	75 db                	jne    b45e <fwp_main_thread+0x32e>
    b483:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b487:	75 d5                	jne    b45e <fwp_main_thread+0x32e>
    b489:	48 8b 05 30 42 01 00 	mov    0x14230(%rip),%rax        # 1f6c0 <fwp_ready_tail>
    b490:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    b494:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    b49b:	00 00 00 00 
    b49f:	48 85 c0             	test   %rax,%rax
    b4a2:	75 ac                	jne    b450 <fwp_main_thread+0x320>
    b4a4:	48 89 15 1d 42 01 00 	mov    %rdx,0x1421d(%rip)        # 1f6c8 <fwp_ready_head>
    b4ab:	eb aa                	jmp    b457 <fwp_main_thread+0x327>
    b4ad:	0f 1f 00             	nopl   (%rax)
    b4b0:	e8 eb 7d ff ff       	call   32a0 <fwp_now_ns>
    b4b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b4b9:	0f 8d 41 03 00 00    	jge    b800 <fwp_main_thread+0x6d0>
    b4bf:	90                   	nop
    b4c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b4c4:	0f 85 df fd ff ff    	jne    b2a9 <fwp_main_thread+0x179>
    b4ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b4ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b4d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b4d6:	0f 85 df fd ff ff    	jne    b2bb <fwp_main_thread+0x18b>
    b4dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b4e0:	48 85 c9             	test   %rcx,%rcx
    b4e3:	0f 84 d2 fd ff ff    	je     b2bb <fwp_main_thread+0x18b>
    b4e9:	48 85 c0             	test   %rax,%rax
    b4ec:	0f 84 df 03 00 00    	je     b8d1 <fwp_main_thread+0x7a1>
    b4f2:	48 39 c8             	cmp    %rcx,%rax
    b4f5:	48 0f 4f c1          	cmovg  %rcx,%rax
    b4f9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b500:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b504:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b50b:	00 00 00 00 
    b50f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b516:	48 85 d2             	test   %rdx,%rdx
    b519:	74 07                	je     b522 <fwp_main_thread+0x3f2>
    b51b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b522:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b526:	e9 c2 fd ff ff       	jmp    b2ed <fwp_main_thread+0x1bd>
    b52b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b530:	48 89 cb             	mov    %rcx,%rbx
    b533:	e9 51 fd ff ff       	jmp    b289 <fwp_main_thread+0x159>
    b538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b53f:	00 
    b540:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b544:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b54b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b552:	00 00 00 00 
    b556:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b55d:	48 85 c0             	test   %rax,%rax
    b560:	0f 84 4a 03 00 00    	je     b8b0 <fwp_main_thread+0x780>
    b566:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b56d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b571:	e9 ab fd ff ff       	jmp    b321 <fwp_main_thread+0x1f1>
    b576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b57d:	00 00 00 
    b580:	48 89 01             	mov    %rax,(%rcx)
    b583:	e9 d3 fd ff ff       	jmp    b35b <fwp_main_thread+0x22b>
    b588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b58f:	00 
    b590:	e8 6b 95 ff ff       	call   4b00 <fwp_free_zombie>
    b595:	48 83 3d 2b 41 01 00 	cmpq   $0x0,0x1412b(%rip)        # 1f6c8 <fwp_ready_head>
    b59c:	00 
    b59d:	0f 85 6d 71 ff ff    	jne    2710 <fwp_main_thread.cold>
    b5a3:	48 83 3d 0d 41 01 00 	cmpq   $0x0,0x1410d(%rip)        # 1f6b8 <fwp_timers>
    b5aa:	00 
    b5ab:	0f 85 5f 71 ff ff    	jne    2710 <fwp_main_thread.cold>
    b5b1:	8b 1d ed 3a 01 00    	mov    0x13aed(%rip),%ebx        # 1f0a4 <fwp_stack_pool_n>
    b5b7:	85 db                	test   %ebx,%ebx
    b5b9:	74 34                	je     b5ef <fwp_main_thread+0x4bf>
    b5bb:	83 eb 01             	sub    $0x1,%ebx
    b5be:	48 8d 05 fb 3a 01 00 	lea    0x13afb(%rip),%rax        # 1f0c0 <fwp_stack_pool>
    b5c5:	48 63 d3             	movslq %ebx,%rdx
    b5c8:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    b5cc:	eb 05                	jmp    b5d3 <fwp_main_thread+0x4a3>
    b5ce:	66 90                	xchg   %ax,%ax
    b5d0:	83 eb 01             	sub    $0x1,%ebx
    b5d3:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    b5d7:	be 00 00 00 10       	mov    $0x10000000,%esi
    b5dc:	89 1d c2 3a 01 00    	mov    %ebx,0x13ac2(%rip)        # 1f0a4 <fwp_stack_pool_n>
    b5e2:	48 83 ed 08          	sub    $0x8,%rbp
    b5e6:	e8 c5 6f ff ff       	call   25b0 <munmap@plt>
    b5eb:	85 db                	test   %ebx,%ebx
    b5ed:	75 e1                	jne    b5d0 <fwp_main_thread+0x4a0>
    b5ef:	8b 3d 1b 3a 00 00    	mov    0x3a1b(%rip),%edi        # f010 <fwp_epfd>
    b5f5:	85 ff                	test   %edi,%edi
    b5f7:	78 05                	js     b5fe <fwp_main_thread+0x4ce>
    b5f9:	e8 b2 6e ff ff       	call   24b0 <close@plt>
    b5fe:	4c 8b 25 bb 3c 01 00 	mov    0x13cbb(%rip),%r12        # 1f2c0 <fwp_nfdws>
    b605:	48 8b 2d bc 3c 01 00 	mov    0x13cbc(%rip),%rbp        # 1f2c8 <fwp_fdws>
    b60c:	31 db                	xor    %ebx,%ebx
    b60e:	c7 05 f8 39 00 00 ff 	movl   $0xffffffff,0x39f8(%rip)        # f010 <fwp_epfd>
    b615:	ff ff ff 
    b618:	4d 85 e4             	test   %r12,%r12
    b61b:	74 30                	je     b64d <fwp_main_thread+0x51d>
    b61d:	0f 1f 00             	nopl   (%rax)
    b620:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b625:	48 85 ff             	test   %rdi,%rdi
    b628:	74 1a                	je     b644 <fwp_main_thread+0x514>
    b62a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b62e:	0f 85 dc 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b634:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b639:	0f 85 d1 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b63f:	e8 8c 8c ff ff       	call   42d0 <fwp_mem_free>
    b644:	48 83 c3 01          	add    $0x1,%rbx
    b648:	49 39 dc             	cmp    %rbx,%r12
    b64b:	75 d3                	jne    b620 <fwp_main_thread+0x4f0>
    b64d:	48 89 ef             	mov    %rbp,%rdi
    b650:	e8 7b 8c ff ff       	call   42d0 <fwp_mem_free>
    b655:	48 8b 15 7c 40 01 00 	mov    0x1407c(%rip),%rdx        # 1f6d8 <fwp_root>
    b65c:	48 c7 05 61 3c 01 00 	movq   $0x0,0x13c61(%rip)        # 1f2c8 <fwp_fdws>
    b663:	00 00 00 00 
    b667:	48 c7 05 4e 3c 01 00 	movq   $0x0,0x13c4e(%rip)        # 1f2c0 <fwp_nfdws>
    b66e:	00 00 00 00 
    b672:	48 85 d2             	test   %rdx,%rdx
    b675:	74 4e                	je     b6c5 <fwp_main_thread+0x595>
    b677:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b67c:	0f 85 8e 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b682:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b689:	00 
    b68a:	0f 85 80 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b690:	48 83 3d d8 5c 01 00 	cmpq   $0x0,0x15cd8(%rip)        # 21370 <fwp_state_len>
    b697:	00 
    b698:	0f 85 72 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b69e:	48 83 3d ba 5c 01 00 	cmpq   $0x0,0x15cba(%rip)        # 21360 <fwp_state_owners>
    b6a5:	00 
    b6a6:	0f 85 64 70 ff ff    	jne    2710 <fwp_main_thread.cold>
    b6ac:	b9 79 00 00 00       	mov    $0x79,%ecx
    b6b1:	31 c0                	xor    %eax,%eax
    b6b3:	48 8d 3d 26 3c 01 00 	lea    0x13c26(%rip),%rdi        # 1f2e0 <fwp_root_context>
    b6ba:	f3 48 ab             	rep stos %rax,(%rdi)
    b6bd:	48 89 d7             	mov    %rdx,%rdi
    b6c0:	e8 0b 8c ff ff       	call   42d0 <fwp_mem_free>
    b6c5:	48 8b 05 54 54 01 00 	mov    0x15454(%rip),%rax        # 20b20 <fwp_heap+0x1420>
    b6cc:	48 c7 05 09 40 01 00 	movq   $0x0,0x14009(%rip)        # 1f6e0 <fwp_cur>
    b6d3:	00 00 00 00 
    b6d7:	48 c7 05 f6 3f 01 00 	movq   $0x0,0x13ff6(%rip)        # 1f6d8 <fwp_root>
    b6de:	00 00 00 00 
    b6e2:	48 c7 05 9b 39 01 00 	movq   $0x0,0x1399b(%rip)        # 1f088 <ad_raw_before_shutdown>
    b6e9:	00 00 00 00 
    b6ed:	c7 05 c9 5c 01 00 00 	movl   $0x0,0x15cc9(%rip)        # 213c0 <iteration_active>
    b6f4:	00 00 00 
    b6f7:	48 85 c0             	test   %rax,%rax
    b6fa:	0f 88 20 01 00 00    	js     b820 <fwp_main_thread+0x6f0>
    b700:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b704:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b709:	f2 0f 5c 0d 8f 5c 01 	subsd  0x15c8f(%rip),%xmm1        # 213a0 <iteration_start_charge>
    b710:	00 
    b711:	48 8b 3d 28 39 00 00 	mov    0x3928(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    b718:	48 8d 15 29 0d 00 00 	lea    0xd29(%rip),%rdx        # c448 <_IO_stdin_used+0x448>
    b71f:	be 02 00 00 00       	mov    $0x2,%esi
    b724:	f2 0f 10 05 6c 5c 01 	movsd  0x15c6c(%rip),%xmm0        # 21398 <iteration_peak>
    b72b:	00 
    b72c:	4c 8b 0d 75 5c 01 00 	mov    0x15c75(%rip),%r9        # 213a8 <iteration_retains>
    b733:	b8 02 00 00 00       	mov    $0x2,%eax
    b738:	4c 8b 05 71 5c 01 00 	mov    0x15c71(%rip),%r8        # 213b0 <iteration_bytes>
    b73f:	48 8b 0d 72 5c 01 00 	mov    0x15c72(%rip),%rcx        # 213b8 <iteration_requests>
    b746:	e8 05 6f ff ff       	call   2650 <__fprintf_chk@plt>
    b74b:	48 8b 3d ce 38 00 00 	mov    0x38ce(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    b752:	e8 39 6e ff ff       	call   2590 <fflush@plt>
    b757:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    b75e:	00 
    b75f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b766:	00 00 
    b768:	0f 85 6b 01 00 00    	jne    b8d9 <fwp_main_thread+0x7a9>
    b76e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    b775:	31 c0                	xor    %eax,%eax
    b777:	5b                   	pop    %rbx
    b778:	5d                   	pop    %rbp
    b779:	41 5c                	pop    %r12
    b77b:	c3                   	ret
    b77c:	0f 1f 40 00          	nopl   0x0(%rax)
    b780:	48 89 05 31 3f 01 00 	mov    %rax,0x13f31(%rip)        # 1f6b8 <fwp_timers>
    b787:	e9 20 fc ff ff       	jmp    b3ac <fwp_main_thread+0x27c>
    b78c:	0f 1f 40 00          	nopl   0x0(%rax)
    b790:	48 83 3d c8 5b 01 00 	cmpq   $0x0,0x15bc8(%rip)        # 21360 <fwp_state_owners>
    b797:	00 
    b798:	0f 85 4c fc ff ff    	jne    b3ea <fwp_main_thread+0x2ba>
    b79e:	48 8b 3d d3 5b 01 00 	mov    0x15bd3(%rip),%rdi        # 21378 <fwp_state>
    b7a5:	e8 26 8b ff ff       	call   42d0 <fwp_mem_free>
    b7aa:	48 c7 05 c3 5b 01 00 	movq   $0x0,0x15bc3(%rip)        # 21378 <fwp_state>
    b7b1:	00 00 00 00 
    b7b5:	48 c7 05 a8 5b 01 00 	movq   $0x0,0x15ba8(%rip)        # 21368 <fwp_state_cap>
    b7bc:	00 00 00 00 
    b7c0:	48 85 ed             	test   %rbp,%rbp
    b7c3:	0f 84 21 fc ff ff    	je     b3ea <fwp_main_thread+0x2ba>
    b7c9:	48 8b 15 08 3f 01 00 	mov    0x13f08(%rip),%rdx        # 1f6d8 <fwp_root>
    b7d0:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    b7d7:	00 00 00 00 
    b7db:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    b7e2:	00 00 00 00 
    b7e6:	c7 05 90 38 01 00 00 	movl   $0x0,0x13890(%rip)        # 1f080 <fwp_exit_code>
    b7ed:	00 00 00 
    b7f0:	48 39 d5             	cmp    %rdx,%rbp
    b7f3:	0f 84 14 fc ff ff    	je     b40d <fwp_main_thread+0x2dd>
    b7f9:	e9 12 6f ff ff       	jmp    2710 <fwp_main_thread.cold>
    b7fe:	66 90                	xchg   %ax,%ax
    b800:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b804:	0f 85 b6 fc ff ff    	jne    b4c0 <fwp_main_thread+0x390>
    b80a:	48 89 ef             	mov    %rbp,%rdi
    b80d:	e8 4e 78 ff ff       	call   3060 <fwp_cancel_tree.part.0>
    b812:	e9 a9 fc ff ff       	jmp    b4c0 <fwp_main_thread+0x390>
    b817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b81e:	00 00 
    b820:	48 89 c2             	mov    %rax,%rdx
    b823:	83 e0 01             	and    $0x1,%eax
    b826:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b82a:	48 d1 ea             	shr    $1,%rdx
    b82d:	48 09 c2             	or     %rax,%rdx
    b830:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    b835:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    b839:	e9 cb fe ff ff       	jmp    b709 <fwp_main_thread+0x5d9>
    b83e:	66 90                	xchg   %ax,%ax
    b840:	48 89 c2             	mov    %rax,%rdx
    b843:	83 e0 01             	and    $0x1,%eax
    b846:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b84a:	48 d1 ea             	shr    $1,%rdx
    b84d:	48 09 c2             	or     %rax,%rdx
    b850:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b855:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b859:	e9 db f9 ff ff       	jmp    b239 <fwp_main_thread+0x109>
    b85e:	66 90                	xchg   %ax,%ax
    b860:	48 8d 3d 39 80 ff ff 	lea    -0x7fc7(%rip),%rdi        # 38a0 <fwp_heap_report>
    b867:	e8 94 02 00 00       	call   bb00 <atexit>
    b86c:	e9 fd f8 ff ff       	jmp    b16e <fwp_main_thread+0x3e>
    b871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b878:	e8 33 81 ff ff       	call   39b0 <fwp_heap_init>
    b87d:	e9 de f8 ff ff       	jmp    b160 <fwp_main_thread+0x30>
    b882:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b888:	e8 a3 cb ff ff       	call   8430 <f0>
    b88d:	48 c7 05 c8 37 00 00 	movq   $0x0,0x37c8(%rip)        # f060 <v.1>
    b894:	00 00 00 00 
    b898:	c7 05 c6 37 00 00 01 	movl   $0x1,0x37c6(%rip)        # f068 <st.2>
    b89f:	00 00 00 
    b8a2:	e9 c6 f9 ff ff       	jmp    b26d <fwp_main_thread+0x13d>
    b8a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b8ae:	00 00 
    b8b0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b8b4:	e9 68 fa ff ff       	jmp    b321 <fwp_main_thread+0x1f1>
    b8b9:	48 8d 3d 60 0b 00 00 	lea    0xb60(%rip),%rdi        # c420 <_IO_stdin_used+0x420>
    b8c0:	e8 ab 79 ff ff       	call   3270 <fwp_trap>
    b8c5:	48 8d 3d e0 08 00 00 	lea    0x8e0(%rip),%rdi        # c1ac <_IO_stdin_used+0x1ac>
    b8cc:	e8 5f 76 ff ff       	call   2f30 <ad_raw_fail>
    b8d1:	48 89 c8             	mov    %rcx,%rax
    b8d4:	e9 20 fc ff ff       	jmp    b4f9 <fwp_main_thread+0x3c9>
    b8d9:	e8 62 6b ff ff       	call   2440 <__stack_chk_fail@plt>
    b8de:	e9 2d 6e ff ff       	jmp    2710 <fwp_main_thread.cold>
    b8e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b8ea:	00 00 00 
    b8ed:	0f 1f 00             	nopl   (%rax)

000000000000b8f0 <__divmodti4>:
    b8f0:	f3 0f 1e fa          	endbr64
    b8f4:	55                   	push   %rbp
    b8f5:	49 89 f1             	mov    %rsi,%r9
    b8f8:	49 89 d2             	mov    %rdx,%r10
    b8fb:	48 89 fe             	mov    %rdi,%rsi
    b8fe:	49 89 cb             	mov    %rcx,%r11
    b901:	48 89 e5             	mov    %rsp,%rbp
    b904:	41 57                	push   %r15
    b906:	41 56                	push   %r14
    b908:	41 55                	push   %r13
    b90a:	41 54                	push   %r12
    b90c:	53                   	push   %rbx
    b90d:	4c 89 c3             	mov    %r8,%rbx
    b910:	45 31 c0             	xor    %r8d,%r8d
    b913:	4d 85 c9             	test   %r9,%r9
    b916:	79 12                	jns    b92a <__divmodti4+0x3a>
    b918:	31 ff                	xor    %edi,%edi
    b91a:	48 f7 de             	neg    %rsi
    b91d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b924:	4c 19 cf             	sbb    %r9,%rdi
    b927:	49 89 f9             	mov    %rdi,%r9
    b92a:	4c 89 d8             	mov    %r11,%rax
    b92d:	4d 85 db             	test   %r11,%r11
    b930:	0f 88 1a 01 00 00    	js     ba50 <__divmodti4+0x160>
    b936:	4c 89 d9             	mov    %r11,%rcx
    b939:	49 89 f3             	mov    %rsi,%r11
    b93c:	75 62                	jne    b9a0 <__divmodti4+0xb0>
    b93e:	4d 89 c4             	mov    %r8,%r12
    b941:	4d 39 d1             	cmp    %r10,%r9
    b944:	0f 83 46 01 00 00    	jae    ba90 <__divmodti4+0x1a0>
    b94a:	4c 89 d8             	mov    %r11,%rax
    b94d:	4c 89 ca             	mov    %r9,%rdx
    b950:	49 f7 f2             	div    %r10
    b953:	49 89 c3             	mov    %rax,%r11
    b956:	31 c0                	xor    %eax,%eax
    b958:	48 89 d6             	mov    %rdx,%rsi
    b95b:	31 ff                	xor    %edi,%edi
    b95d:	4c 89 d9             	mov    %r11,%rcx
    b960:	48 89 c2             	mov    %rax,%rdx
    b963:	48 89 c8             	mov    %rcx,%rax
    b966:	4d 85 e4             	test   %r12,%r12
    b969:	74 0a                	je     b975 <__divmodti4+0x85>
    b96b:	48 f7 d8             	neg    %rax
    b96e:	48 83 d2 00          	adc    $0x0,%rdx
    b972:	48 f7 da             	neg    %rdx
    b975:	4d 85 c0             	test   %r8,%r8
    b978:	74 0a                	je     b984 <__divmodti4+0x94>
    b97a:	48 f7 de             	neg    %rsi
    b97d:	48 83 d7 00          	adc    $0x0,%rdi
    b981:	48 f7 df             	neg    %rdi
    b984:	48 89 33             	mov    %rsi,(%rbx)
    b987:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b98b:	5b                   	pop    %rbx
    b98c:	41 5c                	pop    %r12
    b98e:	41 5d                	pop    %r13
    b990:	41 5e                	pop    %r14
    b992:	41 5f                	pop    %r15
    b994:	5d                   	pop    %rbp
    b995:	c3                   	ret
    b996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b99d:	00 00 00 
    b9a0:	4d 89 c4             	mov    %r8,%r12
    b9a3:	49 39 c1             	cmp    %rax,%r9
    b9a6:	0f 82 ce 00 00 00    	jb     ba7a <__divmodti4+0x18a>
    b9ac:	31 ff                	xor    %edi,%edi
    b9ae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b9b3:	48 63 c7             	movslq %edi,%rax
    b9b6:	be 40 00 00 00       	mov    $0x40,%esi
    b9bb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b9c0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b9c5:	48 29 c6             	sub    %rax,%rsi
    b9c8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b9cd:	48 09 c8             	or     %rcx,%rax
    b9d0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b9d5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b9da:	49 89 c6             	mov    %rax,%r14
    b9dd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b9e1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b9e6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b9eb:	49 09 c1             	or     %rax,%r9
    b9ee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b9f2:	4c 89 c8             	mov    %r9,%rax
    b9f5:	49 f7 f6             	div    %r14
    b9f8:	48 89 d1             	mov    %rdx,%rcx
    b9fb:	49 89 c3             	mov    %rax,%r11
    b9fe:	49 89 c1             	mov    %rax,%r9
    ba01:	49 f7 e2             	mul    %r10
    ba04:	49 89 c6             	mov    %rax,%r14
    ba07:	49 89 d2             	mov    %rdx,%r10
    ba0a:	48 39 d1             	cmp    %rdx,%rcx
    ba0d:	72 07                	jb     ba16 <__divmodti4+0x126>
    ba0f:	75 17                	jne    ba28 <__divmodti4+0x138>
    ba11:	49 39 c7             	cmp    %rax,%r15
    ba14:	73 12                	jae    ba28 <__divmodti4+0x138>
    ba16:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ba1a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ba1e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ba22:	49 89 d2             	mov    %rdx,%r10
    ba25:	49 89 c6             	mov    %rax,%r14
    ba28:	4c 89 f8             	mov    %r15,%rax
    ba2b:	4c 29 f0             	sub    %r14,%rax
    ba2e:	4c 19 d1             	sbb    %r10,%rcx
    ba31:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ba36:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ba3b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ba40:	48 09 c6             	or     %rax,%rsi
    ba43:	48 89 cf             	mov    %rcx,%rdi
    ba46:	31 c0                	xor    %eax,%eax
    ba48:	4c 89 c9             	mov    %r9,%rcx
    ba4b:	e9 10 ff ff ff       	jmp    b960 <__divmodti4+0x70>
    ba50:	4c 89 d0             	mov    %r10,%rax
    ba53:	4c 89 da             	mov    %r11,%rdx
    ba56:	4d 89 c4             	mov    %r8,%r12
    ba59:	49 89 f3             	mov    %rsi,%r11
    ba5c:	48 f7 d8             	neg    %rax
    ba5f:	49 f7 d4             	not    %r12
    ba62:	48 83 d2 00          	adc    $0x0,%rdx
    ba66:	49 89 c2             	mov    %rax,%r10
    ba69:	48 f7 da             	neg    %rdx
    ba6c:	48 89 d1             	mov    %rdx,%rcx
    ba6f:	0f 84 cc fe ff ff    	je     b941 <__divmodti4+0x51>
    ba75:	49 39 d1             	cmp    %rdx,%r9
    ba78:	73 46                	jae    bac0 <__divmodti4+0x1d0>
    ba7a:	4c 89 cf             	mov    %r9,%rdi
    ba7d:	31 c0                	xor    %eax,%eax
    ba7f:	31 c9                	xor    %ecx,%ecx
    ba81:	e9 da fe ff ff       	jmp    b960 <__divmodti4+0x70>
    ba86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba8d:	00 00 00 
    ba90:	4d 85 d2             	test   %r10,%r10
    ba93:	75 0d                	jne    baa2 <__divmodti4+0x1b2>
    ba95:	b8 01 00 00 00       	mov    $0x1,%eax
    ba9a:	31 d2                	xor    %edx,%edx
    ba9c:	49 f7 f2             	div    %r10
    ba9f:	49 89 c2             	mov    %rax,%r10
    baa2:	4c 89 c8             	mov    %r9,%rax
    baa5:	31 d2                	xor    %edx,%edx
    baa7:	49 f7 f2             	div    %r10
    baaa:	49 89 c1             	mov    %rax,%r9
    baad:	4c 89 d8             	mov    %r11,%rax
    bab0:	49 f7 f2             	div    %r10
    bab3:	49 89 c3             	mov    %rax,%r11
    bab6:	4c 89 c8             	mov    %r9,%rax
    bab9:	e9 9a fe ff ff       	jmp    b958 <__divmodti4+0x68>
    babe:	66 90                	xchg   %ax,%ax
    bac0:	45 31 f6             	xor    %r14d,%r14d
    bac3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bac8:	44 89 f7             	mov    %r14d,%edi
    bacb:	45 85 f6             	test   %r14d,%r14d
    bace:	0f 85 df fe ff ff    	jne    b9b3 <__divmodti4+0xc3>
    bad4:	4c 39 ca             	cmp    %r9,%rdx
    bad7:	72 17                	jb     baf0 <__divmodti4+0x200>
    bad9:	31 c9                	xor    %ecx,%ecx
    badb:	48 39 c6             	cmp    %rax,%rsi
    bade:	73 10                	jae    baf0 <__divmodti4+0x200>
    bae0:	4c 89 cf             	mov    %r9,%rdi
    bae3:	31 c0                	xor    %eax,%eax
    bae5:	e9 76 fe ff ff       	jmp    b960 <__divmodti4+0x70>
    baea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    baf0:	4c 89 de             	mov    %r11,%rsi
    baf3:	b9 01 00 00 00       	mov    $0x1,%ecx
    baf8:	48 29 c6             	sub    %rax,%rsi
    bafb:	49 19 d1             	sbb    %rdx,%r9
    bafe:	eb e0                	jmp    bae0 <__divmodti4+0x1f0>

000000000000bb00 <atexit>:
    bb00:	f3 0f 1e fa          	endbr64
    bb04:	48 8b 15 fd 34 00 00 	mov    0x34fd(%rip),%rdx        # f008 <__dso_handle>
    bb0b:	31 f6                	xor    %esi,%esi
    bb0d:	e9 0e 6b ff ff       	jmp    2620 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bb14 <_fini>:
    bb14:	f3 0f 1e fa          	endbr64
    bb18:	48 83 ec 08          	sub    $0x8,%rsp
    bb1c:	48 83 c4 08          	add    $0x8,%rsp
    bb20:	c3                   	ret
