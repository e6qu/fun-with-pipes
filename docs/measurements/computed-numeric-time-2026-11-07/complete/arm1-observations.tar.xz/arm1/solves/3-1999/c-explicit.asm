
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1999/c-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000000710 <_init>:
 710:	d503201f 	nop
 714:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 718:	910003fd 	mov	x29, sp
 71c:	940000e6 	bl	ab4 <call_weak_fn>
 720:	a8c17bfd 	ldp	x29, x30, [sp], #16
 724:	d65f03c0 	ret

Disassembly of section .plt:

0000000000000730 <.plt>:
 730:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 734:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 738:	f947ba11 	ldr	x17, [x16, #3952]
 73c:	913dc210 	add	x16, x16, #0xf70
 740:	d61f0220 	br	x17
 744:	d503201f 	nop
 748:	d503201f 	nop
 74c:	d503201f 	nop

0000000000000750 <__libc_start_main@plt>:
 750:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 754:	f947be11 	ldr	x17, [x16, #3960]
 758:	913de210 	add	x16, x16, #0xf78
 75c:	d61f0220 	br	x17

0000000000000760 <__cxa_finalize@plt>:
 760:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 764:	f947c211 	ldr	x17, [x16, #3968]
 768:	913e0210 	add	x16, x16, #0xf80
 76c:	d61f0220 	br	x17

0000000000000770 <putc@plt>:
 770:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 774:	f947c611 	ldr	x17, [x16, #3976]
 778:	913e2210 	add	x16, x16, #0xf88
 77c:	d61f0220 	br	x17

0000000000000780 <malloc@plt>:
 780:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 784:	f947ca11 	ldr	x17, [x16, #3984]
 788:	913e4210 	add	x16, x16, #0xf90
 78c:	d61f0220 	br	x17

0000000000000790 <__printf_chk@plt>:
 790:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 794:	f947ce11 	ldr	x17, [x16, #3992]
 798:	913e6210 	add	x16, x16, #0xf98
 79c:	d61f0220 	br	x17

00000000000007a0 <__gmon_start__@plt>:
 7a0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 7a4:	f947d211 	ldr	x17, [x16, #4000]
 7a8:	913e8210 	add	x16, x16, #0xfa0
 7ac:	d61f0220 	br	x17

00000000000007b0 <abort@plt>:
 7b0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 7b4:	f947d611 	ldr	x17, [x16, #4008]
 7b8:	913ea210 	add	x16, x16, #0xfa8
 7bc:	d61f0220 	br	x17

00000000000007c0 <puts@plt>:
 7c0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 7c4:	f947da11 	ldr	x17, [x16, #4016]
 7c8:	913ec210 	add	x16, x16, #0xfb0
 7cc:	d61f0220 	br	x17

00000000000007d0 <free@plt>:
 7d0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 7d4:	f947de11 	ldr	x17, [x16, #4024]
 7d8:	913ee210 	add	x16, x16, #0xfb8
 7dc:	d61f0220 	br	x17

00000000000007e0 <ferror@plt>:
 7e0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e2dc>
 7e4:	f947e211 	ldr	x17, [x16, #4032]
 7e8:	913f0210 	add	x16, x16, #0xfc0
 7ec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000800 <main>:
 800:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 804:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
 808:	910003fd 	mov	x29, sp
 80c:	6d0427e8 	stp	d8, d9, [sp, #64]
 810:	9e670009 	fmov	d9, x0
 814:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 818:	a9025bf5 	stp	x21, x22, [sp, #32]
 81c:	d2800095 	mov	x21, #0x4                   	// #4
 820:	f00000f6 	adrp	x22, 1f000 <__FRAME_END__+0x1e2dc>
 824:	f947f2d6 	ldr	x22, [x22, #4064]
 828:	6d052fea 	stp	d10, d11, [sp, #80]
 82c:	fd45e80a 	ldr	d10, [x0, #3024]
 830:	a90153f3 	stp	x19, x20, [sp, #16]
 834:	f9001bf7 	str	x23, [sp, #48]
 838:	fd001fec 	str	d12, [sp, #56]
 83c:	d2800300 	mov	x0, #0x18                  	// #24
 840:	97ffffd0 	bl	780 <malloc@plt>
 844:	aa0003f3 	mov	x19, x0
 848:	d2800300 	mov	x0, #0x18                  	// #24
 84c:	97ffffcd 	bl	780 <malloc@plt>
 850:	aa0003f4 	mov	x20, x0
 854:	f100027f 	cmp	x19, #0x0
 858:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
 85c:	54000e80 	b.eq	a2c <main+0x22c>  // b.none
 860:	b200e7e0 	mov	x0, #0x3333333333333333    	// #3689348814741910323
 864:	d2e80d21 	mov	x1, #0x4069000000000000    	// #4641240890982006784
 868:	f2f7fe60 	movk	x0, #0xbff3, lsl #48
 86c:	9e670008 	fmov	d8, x0
 870:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 874:	9e670027 	fmov	d7, x1
 878:	6f00e406 	movi	v6.2d, #0x0
 87c:	d280f9e1 	mov	x1, #0x7cf                 	// #1999
 880:	3dc2f800 	ldr	q0, [x0, #3040]
 884:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 888:	1e6e1010 	fmov	d16, #1.000000000000000000e+00
 88c:	3d800260 	str	q0, [x19]
 890:	fd45f000 	ldr	d0, [x0, #3040]
 894:	fd000a60 	str	d0, [x19, #16]
 898:	6d408261 	ldp	d1, d0, [x19, #8]
 89c:	1e680911 	fmul	d17, d8, d8
 8a0:	1e690903 	fmul	d3, d8, d9
 8a4:	1e683a08 	fsub	d8, d16, d8
 8a8:	d2800000 	mov	x0, #0x0                   	// #0
 8ac:	1e610825 	fmul	d5, d1, d1
 8b0:	1e690822 	fmul	d2, d1, d9
 8b4:	1e613a04 	fsub	d4, d16, d1
 8b8:	1e713821 	fsub	d1, d1, d17
 8bc:	1e682908 	fadd	d8, d8, d8
 8c0:	1e653800 	fsub	d0, d0, d5
 8c4:	1e610863 	fmul	d3, d3, d1
 8c8:	1e670825 	fmul	d5, d1, d7
 8cc:	1e642884 	fadd	d4, d4, d4
 8d0:	1e600841 	fmul	d1, d2, d0
 8d4:	1e670800 	fmul	d0, d0, d7
 8d8:	1e6628a2 	fadd	d2, d5, d6
 8dc:	1e683863 	fsub	d3, d3, d8
 8e0:	1e643821 	fsub	d1, d1, d4
 8e4:	1e662800 	fadd	d0, d0, d6
 8e8:	1e662863 	fadd	d3, d3, d6
 8ec:	1e622821 	fadd	d1, d1, d2
 8f0:	fd000a80 	str	d0, [x20, #16]
 8f4:	6d000683 	stp	d3, d1, [x20]
 8f8:	fc607a81 	ldr	d1, [x20, x0, lsl #3]
 8fc:	fc607a60 	ldr	d0, [x19, x0, lsl #3]
 900:	1e6a0821 	fmul	d1, d1, d10
 904:	1e613800 	fsub	d0, d0, d1
 908:	fc207a60 	str	d0, [x19, x0, lsl #3]
 90c:	91000400 	add	x0, x0, #0x1
 910:	f1000c1f 	cmp	x0, #0x3
 914:	54ffff21 	b.ne	8f8 <main+0xf8>  // b.any
 918:	fd400268 	ldr	d8, [x19]
 91c:	f1000421 	subs	x1, x1, #0x1
 920:	54fffbc1 	b.ne	898 <main+0x98>  // b.any
 924:	1e60c101 	fabs	d1, d8
 928:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
 92c:	9e670000 	fmov	d0, x0
 930:	1e602020 	fcmp	d1, d0
 934:	54000708 	b.hi	a14 <main+0x214>  // b.pmore
 938:	fd40066c 	ldr	d12, [x19, #8]
 93c:	1e60c181 	fabs	d1, d12
 940:	1e602020 	fcmp	d1, d0
 944:	54000688 	b.hi	a14 <main+0x214>  // b.pmore
 948:	fd400a6b 	ldr	d11, [x19, #16]
 94c:	1e60c161 	fabs	d1, d11
 950:	1e602020 	fcmp	d1, d0
 954:	54000608 	b.hi	a14 <main+0x214>  // b.pmore
 958:	f94002c1 	ldr	x1, [x22]
 95c:	52800b60 	mov	w0, #0x5b                  	// #91
 960:	90000017 	adrp	x23, 0 <__abi_tag-0x278>
 964:	912f02f7 	add	x23, x23, #0xbc0
 968:	97ffff82 	bl	770 <putc@plt>
 96c:	1e604100 	fmov	d0, d8
 970:	90000001 	adrp	x1, 0 <__abi_tag-0x278>
 974:	52800040 	mov	w0, #0x2                   	// #2
 978:	912ee021 	add	x1, x1, #0xbb8
 97c:	97ffff85 	bl	790 <__printf_chk@plt>
 980:	1e604180 	fmov	d0, d12
 984:	aa1703e1 	mov	x1, x23
 988:	52800040 	mov	w0, #0x2                   	// #2
 98c:	97ffff81 	bl	790 <__printf_chk@plt>
 990:	1e604160 	fmov	d0, d11
 994:	aa1703e1 	mov	x1, x23
 998:	52800040 	mov	w0, #0x2                   	// #2
 99c:	97ffff7d 	bl	790 <__printf_chk@plt>
 9a0:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 9a4:	912f2000 	add	x0, x0, #0xbc8
 9a8:	97ffff86 	bl	7c0 <puts@plt>
 9ac:	aa1303e0 	mov	x0, x19
 9b0:	97ffff88 	bl	7d0 <free@plt>
 9b4:	aa1403e0 	mov	x0, x20
 9b8:	97ffff86 	bl	7d0 <free@plt>
 9bc:	f94002c0 	ldr	x0, [x22]
 9c0:	97ffff88 	bl	7e0 <ferror@plt>
 9c4:	35000160 	cbnz	w0, 9f0 <main+0x1f0>
 9c8:	f10006b5 	subs	x21, x21, #0x1
 9cc:	54fff381 	b.ne	83c <main+0x3c>  // b.any
 9d0:	a94153f3 	ldp	x19, x20, [sp, #16]
 9d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9d8:	f9401bf7 	ldr	x23, [sp, #48]
 9dc:	fd401fec 	ldr	d12, [sp, #56]
 9e0:	6d4427e8 	ldp	d8, d9, [sp, #64]
 9e4:	6d452fea 	ldp	d10, d11, [sp, #80]
 9e8:	a8c67bfd 	ldp	x29, x30, [sp], #96
 9ec:	d65f03c0 	ret
 9f0:	a94153f3 	ldp	x19, x20, [sp, #16]
 9f4:	52800080 	mov	w0, #0x4                   	// #4
 9f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9fc:	f9401bf7 	ldr	x23, [sp, #48]
 a00:	fd401fec 	ldr	d12, [sp, #56]
 a04:	6d4427e8 	ldp	d8, d9, [sp, #64]
 a08:	6d452fea 	ldp	d10, d11, [sp, #80]
 a0c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a10:	d65f03c0 	ret
 a14:	aa1303e0 	mov	x0, x19
 a18:	97ffff6e 	bl	7d0 <free@plt>
 a1c:	aa1403e0 	mov	x0, x20
 a20:	97ffff6c 	bl	7d0 <free@plt>
 a24:	52800060 	mov	w0, #0x3                   	// #3
 a28:	17ffffea 	b	9d0 <main+0x1d0>
 a2c:	aa1303e0 	mov	x0, x19
 a30:	97ffff68 	bl	7d0 <free@plt>
 a34:	aa1403e0 	mov	x0, x20
 a38:	97ffff66 	bl	7d0 <free@plt>
 a3c:	52800040 	mov	w0, #0x2                   	// #2
 a40:	17ffffe4 	b	9d0 <main+0x1d0>
 a44:	d503201f 	nop
 a48:	d503201f 	nop
 a4c:	d503201f 	nop
 a50:	d503201f 	nop
 a54:	d503201f 	nop
 a58:	d503201f 	nop
 a5c:	d503201f 	nop
 a60:	d503201f 	nop
 a64:	d503201f 	nop
 a68:	d503201f 	nop
 a6c:	d503201f 	nop
 a70:	d503201f 	nop
 a74:	d503201f 	nop
 a78:	d503201f 	nop
 a7c:	d503201f 	nop

0000000000000a80 <_start>:
 a80:	d503201f 	nop
 a84:	d280001d 	mov	x29, #0x0                   	// #0
 a88:	d280001e 	mov	x30, #0x0                   	// #0
 a8c:	aa0003e5 	mov	x5, x0
 a90:	f94003e1 	ldr	x1, [sp]
 a94:	910023e2 	add	x2, sp, #0x8
 a98:	910003e6 	mov	x6, sp
 a9c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e2dc>
 aa0:	f947f800 	ldr	x0, [x0, #4080]
 aa4:	d2800003 	mov	x3, #0x0                   	// #0
 aa8:	d2800004 	mov	x4, #0x0                   	// #0
 aac:	97ffff29 	bl	750 <__libc_start_main@plt>
 ab0:	97ffff40 	bl	7b0 <abort@plt>

0000000000000ab4 <call_weak_fn>:
 ab4:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e2dc>
 ab8:	f947f400 	ldr	x0, [x0, #4072]
 abc:	b4000040 	cbz	x0, ac4 <call_weak_fn+0x10>
 ac0:	17ffff38 	b	7a0 <__gmon_start__@plt>
 ac4:	d65f03c0 	ret
 ac8:	d503201f 	nop
 acc:	d503201f 	nop

0000000000000ad0 <deregister_tm_clones>:
 ad0:	90000100 	adrp	x0, 20000 <__data_start>
 ad4:	91004000 	add	x0, x0, #0x10
 ad8:	90000101 	adrp	x1, 20000 <__data_start>
 adc:	91004021 	add	x1, x1, #0x10
 ae0:	eb00003f 	cmp	x1, x0
 ae4:	540000c0 	b.eq	afc <deregister_tm_clones+0x2c>  // b.none
 ae8:	f00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x1e2dc>
 aec:	f947e821 	ldr	x1, [x1, #4048]
 af0:	b4000061 	cbz	x1, afc <deregister_tm_clones+0x2c>
 af4:	aa0103f0 	mov	x16, x1
 af8:	d61f0200 	br	x16
 afc:	d65f03c0 	ret

0000000000000b00 <register_tm_clones>:
 b00:	90000100 	adrp	x0, 20000 <__data_start>
 b04:	91004000 	add	x0, x0, #0x10
 b08:	90000101 	adrp	x1, 20000 <__data_start>
 b0c:	91004021 	add	x1, x1, #0x10
 b10:	cb000021 	sub	x1, x1, x0
 b14:	d37ffc22 	lsr	x2, x1, #63
 b18:	8b810c41 	add	x1, x2, x1, asr #3
 b1c:	9341fc21 	asr	x1, x1, #1
 b20:	b40000c1 	cbz	x1, b38 <register_tm_clones+0x38>
 b24:	f00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x1e2dc>
 b28:	f947fc42 	ldr	x2, [x2, #4088]
 b2c:	b4000062 	cbz	x2, b38 <register_tm_clones+0x38>
 b30:	aa0203f0 	mov	x16, x2
 b34:	d61f0200 	br	x16
 b38:	d65f03c0 	ret
 b3c:	d503201f 	nop

0000000000000b40 <__do_global_dtors_aux>:
 b40:	d503233f 	paciasp
 b44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 b48:	910003fd 	mov	x29, sp
 b4c:	f9000bf3 	str	x19, [sp, #16]
 b50:	90000113 	adrp	x19, 20000 <__data_start>
 b54:	39404260 	ldrb	w0, [x19, #16]
 b58:	37000140 	tbnz	w0, #0, b80 <__do_global_dtors_aux+0x40>
 b5c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e2dc>
 b60:	f947ec00 	ldr	x0, [x0, #4056]
 b64:	b4000080 	cbz	x0, b74 <__do_global_dtors_aux+0x34>
 b68:	90000100 	adrp	x0, 20000 <__data_start>
 b6c:	f9400400 	ldr	x0, [x0, #8]
 b70:	97fffefc 	bl	760 <__cxa_finalize@plt>
 b74:	97ffffd7 	bl	ad0 <deregister_tm_clones>
 b78:	52800020 	mov	w0, #0x1                   	// #1
 b7c:	39004260 	strb	w0, [x19, #16]
 b80:	f9400bf3 	ldr	x19, [sp, #16]
 b84:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b88:	d50323bf 	autiasp
 b8c:	d65f03c0 	ret

0000000000000b90 <frame_dummy>:
 b90:	d503245f 	bti	c
 b94:	17ffffdb 	b	b00 <register_tm_clones>

Disassembly of section .fini:

0000000000000b98 <_fini>:
 b98:	d503201f 	nop
 b9c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 ba0:	910003fd 	mov	x29, sp
 ba4:	a8c17bfd 	ldp	x29, x30, [sp], #16
 ba8:	d65f03c0 	ret
