
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-packed:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000012c8 <_init>:
    12c8:	d503201f 	nop
    12cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    12d0:	910003fd 	mov	x29, sp
    12d4:	94000188 	bl	18f4 <call_weak_fn>
    12d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    12dc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000012e0 <.plt>:
    12e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    12e4:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    12e8:	f946fe11 	ldr	x17, [x16, #3576]
    12ec:	9137e210 	add	x16, x16, #0xdf8
    12f0:	d61f0220 	br	x17
    12f4:	d503201f 	nop
    12f8:	d503201f 	nop
    12fc:	d503201f 	nop

0000000000001300 <memcpy@plt>:
    1300:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1304:	f9470211 	ldr	x17, [x16, #3584]
    1308:	91380210 	add	x16, x16, #0xe00
    130c:	d61f0220 	br	x17

0000000000001310 <sigaltstack@plt>:
    1310:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1314:	f9470611 	ldr	x17, [x16, #3592]
    1318:	91382210 	add	x16, x16, #0xe08
    131c:	d61f0220 	br	x17

0000000000001320 <_exit@plt>:
    1320:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1324:	f9470a11 	ldr	x17, [x16, #3600]
    1328:	91384210 	add	x16, x16, #0xe10
    132c:	d61f0220 	br	x17

0000000000001330 <strlen@plt>:
    1330:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1334:	f9470e11 	ldr	x17, [x16, #3608]
    1338:	91386210 	add	x16, x16, #0xe18
    133c:	d61f0220 	br	x17

0000000000001340 <__sprintf_chk@plt>:
    1340:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1344:	f9471211 	ldr	x17, [x16, #3616]
    1348:	91388210 	add	x16, x16, #0xe20
    134c:	d61f0220 	br	x17

0000000000001350 <exit@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1354:	f9471611 	ldr	x17, [x16, #3624]
    1358:	9138a210 	add	x16, x16, #0xe28
    135c:	d61f0220 	br	x17

0000000000001360 <__libc_start_main@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1364:	f9471a11 	ldr	x17, [x16, #3632]
    1368:	9138c210 	add	x16, x16, #0xe30
    136c:	d61f0220 	br	x17

0000000000001370 <strtoll@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1374:	f9471e11 	ldr	x17, [x16, #3640]
    1378:	9138e210 	add	x16, x16, #0xe38
    137c:	d61f0220 	br	x17

0000000000001380 <strtod@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1384:	f9472211 	ldr	x17, [x16, #3648]
    1388:	91390210 	add	x16, x16, #0xe40
    138c:	d61f0220 	br	x17

0000000000001390 <__cxa_finalize@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1394:	f9472611 	ldr	x17, [x16, #3656]
    1398:	91392210 	add	x16, x16, #0xe48
    139c:	d61f0220 	br	x17

00000000000013a0 <__cxa_atexit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13a4:	f9472a11 	ldr	x17, [x16, #3664]
    13a8:	91394210 	add	x16, x16, #0xe50
    13ac:	d61f0220 	br	x17

00000000000013b0 <pthread_attr_init@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13b4:	f9472e11 	ldr	x17, [x16, #3672]
    13b8:	91396210 	add	x16, x16, #0xe58
    13bc:	d61f0220 	br	x17

00000000000013c0 <fputc@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13c4:	f9473211 	ldr	x17, [x16, #3680]
    13c8:	91398210 	add	x16, x16, #0xe60
    13cc:	d61f0220 	br	x17

00000000000013d0 <clock_gettime@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13d4:	f9473611 	ldr	x17, [x16, #3688]
    13d8:	9139a210 	add	x16, x16, #0xe68
    13dc:	d61f0220 	br	x17

00000000000013e0 <setvbuf@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13e4:	f9473a11 	ldr	x17, [x16, #3696]
    13e8:	9139c210 	add	x16, x16, #0xe70
    13ec:	d61f0220 	br	x17

00000000000013f0 <__memcpy_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    13f4:	f9473e11 	ldr	x17, [x16, #3704]
    13f8:	9139e210 	add	x16, x16, #0xe78
    13fc:	d61f0220 	br	x17

0000000000001400 <signal@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1404:	f9474211 	ldr	x17, [x16, #3712]
    1408:	913a0210 	add	x16, x16, #0xe80
    140c:	d61f0220 	br	x17

0000000000001410 <__snprintf_chk@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1414:	f9474611 	ldr	x17, [x16, #3720]
    1418:	913a2210 	add	x16, x16, #0xe88
    141c:	d61f0220 	br	x17

0000000000001420 <fclose@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1424:	f9474a11 	ldr	x17, [x16, #3728]
    1428:	913a4210 	add	x16, x16, #0xe90
    142c:	d61f0220 	br	x17

0000000000001430 <fopen@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1434:	f9474e11 	ldr	x17, [x16, #3736]
    1438:	913a6210 	add	x16, x16, #0xe98
    143c:	d61f0220 	br	x17

0000000000001440 <malloc@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1444:	f9475211 	ldr	x17, [x16, #3744]
    1448:	913a8210 	add	x16, x16, #0xea0
    144c:	d61f0220 	br	x17

0000000000001450 <pthread_attr_destroy@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1454:	f9475611 	ldr	x17, [x16, #3752]
    1458:	913aa210 	add	x16, x16, #0xea8
    145c:	d61f0220 	br	x17

0000000000001460 <sigemptyset@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1464:	f9475a11 	ldr	x17, [x16, #3760]
    1468:	913ac210 	add	x16, x16, #0xeb0
    146c:	d61f0220 	br	x17

0000000000001470 <memset@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1474:	f9475e11 	ldr	x17, [x16, #3768]
    1478:	913ae210 	add	x16, x16, #0xeb8
    147c:	d61f0220 	br	x17

0000000000001480 <calloc@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1484:	f9476211 	ldr	x17, [x16, #3776]
    1488:	913b0210 	add	x16, x16, #0xec0
    148c:	d61f0220 	br	x17

0000000000001490 <realloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1494:	f9476611 	ldr	x17, [x16, #3784]
    1498:	913b2210 	add	x16, x16, #0xec8
    149c:	d61f0220 	br	x17

00000000000014a0 <__stack_chk_fail@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14a4:	f9476a11 	ldr	x17, [x16, #3792]
    14a8:	913b4210 	add	x16, x16, #0xed0
    14ac:	d61f0220 	br	x17

00000000000014b0 <close@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14b4:	f9476e11 	ldr	x17, [x16, #3800]
    14b8:	913b6210 	add	x16, x16, #0xed8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigaction@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14c4:	f9477211 	ldr	x17, [x16, #3808]
    14c8:	913b8210 	add	x16, x16, #0xee0
    14cc:	d61f0220 	br	x17

00000000000014d0 <__gmon_start__@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14d4:	f9477611 	ldr	x17, [x16, #3816]
    14d8:	913ba210 	add	x16, x16, #0xee8
    14dc:	d61f0220 	br	x17

00000000000014e0 <write@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14e4:	f9477a11 	ldr	x17, [x16, #3824]
    14e8:	913bc210 	add	x16, x16, #0xef0
    14ec:	d61f0220 	br	x17

00000000000014f0 <abort@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    14f4:	f9477e11 	ldr	x17, [x16, #3832]
    14f8:	913be210 	add	x16, x16, #0xef8
    14fc:	d61f0220 	br	x17

0000000000001500 <swapcontext@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1504:	f9478211 	ldr	x17, [x16, #3840]
    1508:	913c0210 	add	x16, x16, #0xf00
    150c:	d61f0220 	br	x17

0000000000001510 <__fprintf_chk@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1514:	f9478611 	ldr	x17, [x16, #3848]
    1518:	913c2210 	add	x16, x16, #0xf08
    151c:	d61f0220 	br	x17

0000000000001520 <strcmp@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1524:	f9478a11 	ldr	x17, [x16, #3856]
    1528:	913c4210 	add	x16, x16, #0xf10
    152c:	d61f0220 	br	x17

0000000000001530 <mmap@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1534:	f9478e11 	ldr	x17, [x16, #3864]
    1538:	913c6210 	add	x16, x16, #0xf18
    153c:	d61f0220 	br	x17

0000000000001540 <strtol@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1544:	f9479211 	ldr	x17, [x16, #3872]
    1548:	913c8210 	add	x16, x16, #0xf20
    154c:	d61f0220 	br	x17

0000000000001550 <strtof@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1554:	f9479611 	ldr	x17, [x16, #3880]
    1558:	913ca210 	add	x16, x16, #0xf28
    155c:	d61f0220 	br	x17

0000000000001560 <free@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1564:	f9479a11 	ldr	x17, [x16, #3888]
    1568:	913cc210 	add	x16, x16, #0xf30
    156c:	d61f0220 	br	x17

0000000000001570 <nanosleep@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1574:	f9479e11 	ldr	x17, [x16, #3896]
    1578:	913ce210 	add	x16, x16, #0xf38
    157c:	d61f0220 	br	x17

0000000000001580 <strchr@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1584:	f947a211 	ldr	x17, [x16, #3904]
    1588:	913d0210 	add	x16, x16, #0xf40
    158c:	d61f0220 	br	x17

0000000000001590 <strtoull@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1594:	f947a611 	ldr	x17, [x16, #3912]
    1598:	913d2210 	add	x16, x16, #0xf48
    159c:	d61f0220 	br	x17

00000000000015a0 <fwrite@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15a4:	f947aa11 	ldr	x17, [x16, #3920]
    15a8:	913d4210 	add	x16, x16, #0xf50
    15ac:	d61f0220 	br	x17

00000000000015b0 <pthread_create@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15b4:	f947ae11 	ldr	x17, [x16, #3928]
    15b8:	913d6210 	add	x16, x16, #0xf58
    15bc:	d61f0220 	br	x17

00000000000015c0 <munmap@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15c4:	f947b211 	ldr	x17, [x16, #3936]
    15c8:	913d8210 	add	x16, x16, #0xf60
    15cc:	d61f0220 	br	x17

00000000000015d0 <fflush@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15d4:	f947b611 	ldr	x17, [x16, #3944]
    15d8:	913da210 	add	x16, x16, #0xf68
    15dc:	d61f0220 	br	x17

00000000000015e0 <strcpy@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15e4:	f947ba11 	ldr	x17, [x16, #3952]
    15e8:	913dc210 	add	x16, x16, #0xf70
    15ec:	d61f0220 	br	x17

00000000000015f0 <sysconf@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    15f4:	f947be11 	ldr	x17, [x16, #3960]
    15f8:	913de210 	add	x16, x16, #0xf78
    15fc:	d61f0220 	br	x17

0000000000001600 <strstr@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1604:	f947c211 	ldr	x17, [x16, #3968]
    1608:	913e0210 	add	x16, x16, #0xf80
    160c:	d61f0220 	br	x17

0000000000001610 <_Exit@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1614:	f947c611 	ldr	x17, [x16, #3976]
    1618:	913e2210 	add	x16, x16, #0xf88
    161c:	d61f0220 	br	x17

0000000000001620 <pthread_join@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1624:	f947ca11 	ldr	x17, [x16, #3984]
    1628:	913e4210 	add	x16, x16, #0xf90
    162c:	d61f0220 	br	x17

0000000000001630 <getenv@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1634:	f947ce11 	ldr	x17, [x16, #3992]
    1638:	913e6210 	add	x16, x16, #0xf98
    163c:	d61f0220 	br	x17

0000000000001640 <mprotect@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1644:	f947d211 	ldr	x17, [x16, #4000]
    1648:	913e8210 	add	x16, x16, #0xfa0
    164c:	d61f0220 	br	x17

0000000000001650 <fgets@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1654:	f947d611 	ldr	x17, [x16, #4008]
    1658:	913ea210 	add	x16, x16, #0xfa8
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_attr_setstacksize@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152d8>
    1664:	f947da11 	ldr	x17, [x16, #4016]
    1668:	913ec210 	add	x16, x16, #0xfb0
    166c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001680 <fwp_trap_overflow.constprop.0>:
    1680:	d10243ff 	sub	sp, sp, #0x90
    1684:	d2800c03 	mov	x3, #0x60                  	// #96
    1688:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    168c:	f947f421 	ldr	x1, [x1, #4072]
    1690:	f0000025 	adrp	x5, 8000 <fwp_main_thread+0x1a0>
    1694:	a9077bfd 	stp	x29, x30, [sp, #112]
    1698:	9101c3fd 	add	x29, sp, #0x70
    169c:	913080a5 	add	x5, x5, #0xc20
    16a0:	f0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    16a4:	f90043f3 	str	x19, [sp, #128]
    16a8:	9130a084 	add	x4, x4, #0xc28
    16ac:	910023f3 	add	x19, sp, #0x8
    16b0:	f9400022 	ldr	x2, [x1]
    16b4:	f90037e2 	str	x2, [sp, #104]
    16b8:	d2800002 	mov	x2, #0x0                   	// #0
    16bc:	aa0303e1 	mov	x1, x3
    16c0:	52800042 	mov	w2, #0x2                   	// #2
    16c4:	aa1303e0 	mov	x0, x19
    16c8:	97ffff52 	bl	1410 <__snprintf_chk@plt>
    16cc:	aa1303e0 	mov	x0, x19
    16d0:	94000274 	bl	20a0 <fwp_trap>
    16d4:	d503201f 	nop
    16d8:	d503201f 	nop
    16dc:	d503201f 	nop

00000000000016e0 <main>:
    16e0:	d10243ff 	sub	sp, sp, #0x90
    16e4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    16e8:	f947f400 	ldr	x0, [x0, #4072]
    16ec:	a9067bfd 	stp	x29, x30, [sp, #96]
    16f0:	910183fd 	add	x29, sp, #0x60
    16f4:	a90753f3 	stp	x19, x20, [sp, #112]
    16f8:	f00000f3 	adrp	x19, 20000 <__data_start>
    16fc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x152d8>
    1700:	f947ee94 	ldr	x20, [x20, #4056]
    1704:	f9400281 	ldr	x1, [x20]
    1708:	f90043f5 	str	x21, [sp, #128]
    170c:	f9400002 	ldr	x2, [x0]
    1710:	f9002fe2 	str	x2, [sp, #88]
    1714:	d2800002 	mov	x2, #0x0                   	// #0
    1718:	f9003261 	str	x1, [x19, #96]
    171c:	94000271 	bl	20e0 <fwp_now_ns>
    1720:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    1724:	9139c000 	add	x0, x0, #0xe70
    1728:	97ffffc2 	bl	1630 <getenv@plt>
    172c:	b4000080 	cbz	x0, 173c <main+0x5c>
    1730:	39400001 	ldrb	w1, [x0]
    1734:	aa0003f5 	mov	x21, x0
    1738:	35000801 	cbnz	w1, 1838 <main+0x158>
    173c:	910023e1 	add	x1, sp, #0x8
    1740:	52800000 	mov	w0, #0x0                   	// #0
    1744:	97ffff23 	bl	13d0 <clock_gettime@plt>
    1748:	35000900 	cbnz	w0, 1868 <main+0x188>
    174c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1750:	d2994003 	mov	x3, #0xca00                	// #51712
    1754:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1758:	9b037c01 	mul	x1, x0, x3
    175c:	9b437c00 	smulh	x0, x0, x3
    1760:	ab020021 	adds	x1, x1, x2
    1764:	937ffc42 	asr	x2, x2, #63
    1768:	9a020000 	adc	x0, x0, x2
    176c:	f100003f 	cmp	x1, #0x0
    1770:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1774:	b50009a0 	cbnz	x0, 18a8 <main+0x1c8>
    1778:	f9400280 	ldr	x0, [x20]
    177c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1780:	52800002 	mov	w2, #0x0                   	// #0
    1784:	d2800001 	mov	x1, #0x0                   	// #0
    1788:	910063f5 	add	x21, sp, #0x18
    178c:	97ffff15 	bl	13e0 <setvbuf@plt>
    1790:	d2800021 	mov	x1, #0x1                   	// #1
    1794:	528001a0 	mov	w0, #0xd                   	// #13
    1798:	97ffff1a 	bl	1400 <signal@plt>
    179c:	aa1503e0 	mov	x0, x21
    17a0:	97ffff04 	bl	13b0 <pthread_attr_init@plt>
    17a4:	350007c0 	cbnz	w0, 189c <main+0x1bc>
    17a8:	aa1503e0 	mov	x0, x21
    17ac:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17b0:	97ffffac 	bl	1660 <pthread_attr_setstacksize@plt>
    17b4:	35000680 	cbnz	w0, 1884 <main+0x1a4>
    17b8:	aa1503e1 	mov	x1, x21
    17bc:	910023e0 	add	x0, sp, #0x8
    17c0:	d0000022 	adrp	x2, 7000 <f0+0x1610>
    17c4:	d2800003 	mov	x3, #0x0                   	// #0
    17c8:	91398042 	add	x2, x2, #0xe60
    17cc:	97ffff79 	bl	15b0 <pthread_create@plt>
    17d0:	2a0003e1 	mov	w1, w0
    17d4:	aa1503e0 	mov	x0, x21
    17d8:	2a0103f5 	mov	w21, w1
    17dc:	97ffff1d 	bl	1450 <pthread_attr_destroy@plt>
    17e0:	350006a0 	cbnz	w0, 18b4 <main+0x1d4>
    17e4:	350004b5 	cbnz	w21, 1878 <main+0x198>
    17e8:	f94007e0 	ldr	x0, [sp, #8]
    17ec:	d2800001 	mov	x1, #0x0                   	// #0
    17f0:	97ffff8c 	bl	1620 <pthread_join@plt>
    17f4:	35000600 	cbnz	w0, 18b4 <main+0x1d4>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	91018273 	add	x19, x19, #0x60
    1800:	97ffff74 	bl	15d0 <fflush@plt>
    1804:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    1808:	f947f421 	ldr	x1, [x1, #4072]
    180c:	b942a260 	ldr	w0, [x19, #672]
    1810:	f9402fe3 	ldr	x3, [sp, #88]
    1814:	f9400022 	ldr	x2, [x1]
    1818:	eb020063 	subs	x3, x3, x2
    181c:	d2800002 	mov	x2, #0x0                   	// #0
    1820:	540002a1 	b.ne	1874 <main+0x194>  // b.any
    1824:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1828:	a94753f3 	ldp	x19, x20, [sp, #112]
    182c:	f94043f5 	ldr	x21, [sp, #128]
    1830:	910243ff 	add	sp, sp, #0x90
    1834:	d65f03c0 	ret
    1838:	910003e1 	mov	x1, sp
    183c:	52800142 	mov	w2, #0xa                   	// #10
    1840:	97ffff54 	bl	1590 <strtoull@plt>
    1844:	f94003e0 	ldr	x0, [sp]
    1848:	39400000 	ldrb	w0, [x0]
    184c:	35fff780 	cbnz	w0, 173c <main+0x5c>
    1850:	394002a0 	ldrb	w0, [x21]
    1854:	52801fa1 	mov	w1, #0xfd                  	// #253
    1858:	5100ac00 	sub	w0, w0, #0x2b
    185c:	6a01001f 	tst	w0, w1
    1860:	54fff6e0 	b.eq	173c <main+0x5c>  // b.none
    1864:	17ffffc5 	b	1778 <main+0x98>
    1868:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    186c:	913a0000 	add	x0, x0, #0xe80
    1870:	9400020c 	bl	20a0 <fwp_trap>
    1874:	97ffff0b 	bl	14a0 <__stack_chk_fail@plt>
    1878:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    187c:	913c8000 	add	x0, x0, #0xf20
    1880:	94000208 	bl	20a0 <fwp_trap>
    1884:	aa1503e0 	mov	x0, x21
    1888:	97fffef2 	bl	1450 <pthread_attr_destroy@plt>
    188c:	35000140 	cbnz	w0, 18b4 <main+0x1d4>
    1890:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    1894:	913be000 	add	x0, x0, #0xef8
    1898:	94000202 	bl	20a0 <fwp_trap>
    189c:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    18a0:	913b2000 	add	x0, x0, #0xec8
    18a4:	940001ff 	bl	20a0 <fwp_trap>
    18a8:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    18ac:	913a8000 	add	x0, x0, #0xea0
    18b0:	940001fc 	bl	20a0 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <abort@plt>
    18b8:	d503201f 	nop
    18bc:	d503201f 	nop

00000000000018c0 <_start>:
    18c0:	d503201f 	nop
    18c4:	d280001d 	mov	x29, #0x0                   	// #0
    18c8:	d280001e 	mov	x30, #0x0                   	// #0
    18cc:	aa0003e5 	mov	x5, x0
    18d0:	f94003e1 	ldr	x1, [sp]
    18d4:	910023e2 	add	x2, sp, #0x8
    18d8:	910003e6 	mov	x6, sp
    18dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    18e0:	f947f800 	ldr	x0, [x0, #4080]
    18e4:	d2800003 	mov	x3, #0x0                   	// #0
    18e8:	d2800004 	mov	x4, #0x0                   	// #0
    18ec:	97fffe9d 	bl	1360 <__libc_start_main@plt>
    18f0:	97ffff00 	bl	14f0 <abort@plt>

00000000000018f4 <call_weak_fn>:
    18f4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    18f8:	f947f000 	ldr	x0, [x0, #4064]
    18fc:	b4000040 	cbz	x0, 1904 <call_weak_fn+0x10>
    1900:	17fffef4 	b	14d0 <__gmon_start__@plt>
    1904:	d65f03c0 	ret
    1908:	d503201f 	nop
    190c:	d503201f 	nop

0000000000001910 <deregister_tm_clones>:
    1910:	f00000e0 	adrp	x0, 20000 <__data_start>
    1914:	91012000 	add	x0, x0, #0x48
    1918:	f00000e1 	adrp	x1, 20000 <__data_start>
    191c:	91012021 	add	x1, x1, #0x48
    1920:	eb00003f 	cmp	x1, x0
    1924:	540000c0 	b.eq	193c <deregister_tm_clones+0x2c>  // b.none
    1928:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    192c:	f947e021 	ldr	x1, [x1, #4032]
    1930:	b4000061 	cbz	x1, 193c <deregister_tm_clones+0x2c>
    1934:	aa0103f0 	mov	x16, x1
    1938:	d61f0200 	br	x16
    193c:	d65f03c0 	ret

0000000000001940 <register_tm_clones>:
    1940:	f00000e0 	adrp	x0, 20000 <__data_start>
    1944:	91012000 	add	x0, x0, #0x48
    1948:	f00000e1 	adrp	x1, 20000 <__data_start>
    194c:	91012021 	add	x1, x1, #0x48
    1950:	cb000021 	sub	x1, x1, x0
    1954:	d37ffc22 	lsr	x2, x1, #63
    1958:	8b810c41 	add	x1, x2, x1, asr #3
    195c:	9341fc21 	asr	x1, x1, #1
    1960:	b40000c1 	cbz	x1, 1978 <register_tm_clones+0x38>
    1964:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152d8>
    1968:	f947fc42 	ldr	x2, [x2, #4088]
    196c:	b4000062 	cbz	x2, 1978 <register_tm_clones+0x38>
    1970:	aa0203f0 	mov	x16, x2
    1974:	d61f0200 	br	x16
    1978:	d65f03c0 	ret
    197c:	d503201f 	nop

0000000000001980 <__do_global_dtors_aux>:
    1980:	d503233f 	paciasp
    1984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1988:	910003fd 	mov	x29, sp
    198c:	f9000bf3 	str	x19, [sp, #16]
    1990:	f00000f3 	adrp	x19, 20000 <__data_start>
    1994:	39414260 	ldrb	w0, [x19, #80]
    1998:	37000140 	tbnz	w0, #0, 19c0 <__do_global_dtors_aux+0x40>
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    19a0:	f947e400 	ldr	x0, [x0, #4040]
    19a4:	b4000080 	cbz	x0, 19b4 <__do_global_dtors_aux+0x34>
    19a8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ac:	f9400400 	ldr	x0, [x0, #8]
    19b0:	97fffe78 	bl	1390 <__cxa_finalize@plt>
    19b4:	97ffffd7 	bl	1910 <deregister_tm_clones>
    19b8:	52800020 	mov	w0, #0x1                   	// #1
    19bc:	39014260 	strb	w0, [x19, #80]
    19c0:	f9400bf3 	ldr	x19, [sp, #16]
    19c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19c8:	d50323bf 	autiasp
    19cc:	d65f03c0 	ret

00000000000019d0 <frame_dummy>:
    19d0:	d503245f 	bti	c
    19d4:	17ffffdb 	b	1940 <register_tm_clones>
    19d8:	d503201f 	nop
    19dc:	d503201f 	nop

00000000000019e0 <fwp_fmt_u128>:
    19e0:	d10183ff 	sub	sp, sp, #0x60
    19e4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    19e8:	f947f421 	ldr	x1, [x1, #4072]
    19ec:	a9057bfd 	stp	x29, x30, [sp, #80]
    19f0:	910143fd 	add	x29, sp, #0x50
    19f4:	f9400024 	ldr	x4, [x1]
    19f8:	f90027e4 	str	x4, [sp, #72]
    19fc:	d2800004 	mov	x4, #0x0                   	// #0
    1a00:	aa030041 	orr	x1, x2, x3
    1a04:	b5000361 	cbnz	x1, 1a70 <fwp_fmt_u128+0x90>
    1a08:	910023e9 	add	x9, sp, #0x8
    1a0c:	52800601 	mov	w1, #0x30                  	// #48
    1a10:	5280002d 	mov	w13, #0x1                   	// #1
    1a14:	390023e1 	strb	w1, [sp, #8]
    1a18:	93407dad 	sxtw	x13, w13
    1a1c:	aa0d03e1 	mov	x1, x13
    1a20:	8b0d0004 	add	x4, x0, x13
    1a24:	d503201f 	nop
    1a28:	8b010123 	add	x3, x9, x1
    1a2c:	cb0103e2 	neg	x2, x1
    1a30:	d1000421 	sub	x1, x1, #0x1
    1a34:	385ff063 	ldurb	w3, [x3, #-1]
    1a38:	38226883 	strb	w3, [x4, x2]
    1a3c:	35ffff61 	cbnz	w1, 1a28 <fwp_fmt_u128+0x48>
    1a40:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    1a44:	f947f421 	ldr	x1, [x1, #4072]
    1a48:	382d681f 	strb	wzr, [x0, x13]
    1a4c:	aa0103e0 	mov	x0, x1
    1a50:	f94027e2 	ldr	x2, [sp, #72]
    1a54:	f9400001 	ldr	x1, [x0]
    1a58:	eb010042 	subs	x2, x2, x1
    1a5c:	d2800001 	mov	x1, #0x0                   	// #0
    1a60:	54000561 	b.ne	1b0c <fwp_fmt_u128+0x12c>  // b.any
    1a64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1a68:	910183ff 	add	sp, sp, #0x60
    1a6c:	d65f03c0 	ret
    1a70:	f0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    1a74:	913f4021 	add	x1, x1, #0xfd0
    1a78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1a7c:	910023e9 	add	x9, sp, #0x8
    1a80:	d2800027 	mov	x7, #0x1                   	// #1
    1a84:	f29999af 	movk	x15, #0xcccd
    1a88:	a9402826 	ldp	x6, x10, [x1]
    1a8c:	d503201f 	nop
    1a90:	ab030041 	adds	x1, x2, x3
    1a94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1a98:	aa0303eb 	mov	x11, x3
    1a9c:	8b070128 	add	x8, x9, x7
    1aa0:	aa0203ee 	mov	x14, x2
    1aa4:	aa0703ed 	mov	x13, x7
    1aa8:	910004e7 	add	x7, x7, #0x1
    1aac:	9bcf7c24 	umulh	x4, x1, x15
    1ab0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1ab4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1ab8:	cb040021 	sub	x1, x1, x4
    1abc:	eb010041 	subs	x1, x2, x1
    1ac0:	da1f0063 	sbc	x3, x3, xzr
    1ac4:	9bc67c24 	umulh	x4, x1, x6
    1ac8:	9b061064 	madd	x4, x3, x6, x4
    1acc:	9b067c2c 	mul	x12, x1, x6
    1ad0:	9b0a1024 	madd	x4, x1, x10, x4
    1ad4:	9bc67c25 	umulh	x5, x1, x6
    1ad8:	9b061465 	madd	x5, x3, x6, x5
    1adc:	9b0a1425 	madd	x5, x1, x10, x5
    1ae0:	93cc0484 	extr	x4, x4, x12, #1
    1ae4:	8b040884 	add	x4, x4, x4, lsl #2
    1ae8:	d341fca3 	lsr	x3, x5, #1
    1aec:	cb040444 	sub	x4, x2, x4, lsl #1
    1af0:	93cc04a2 	extr	x2, x5, x12, #1
    1af4:	1100c084 	add	w4, w4, #0x30
    1af8:	381ff104 	sturb	w4, [x8, #-1]
    1afc:	b5fffcab 	cbnz	x11, 1a90 <fwp_fmt_u128+0xb0>
    1b00:	f10025df 	cmp	x14, #0x9
    1b04:	54fffc68 	b.hi	1a90 <fwp_fmt_u128+0xb0>  // b.pmore
    1b08:	17ffffc4 	b	1a18 <fwp_fmt_u128+0x38>
    1b0c:	97fffe65 	bl	14a0 <__stack_chk_fail@plt>

0000000000001b10 <fwp_range_release>:
    1b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b14:	910003fd 	mov	x29, sp
    1b18:	f9400801 	ldr	x1, [x0, #16]
    1b1c:	f9000bf3 	str	x19, [sp, #16]
    1b20:	aa0003f3 	mov	x19, x0
    1b24:	b4000061 	cbz	x1, 1b30 <fwp_range_release+0x20>
    1b28:	f9400400 	ldr	x0, [x0, #8]
    1b2c:	d63f0020 	blr	x1
    1b30:	f9400260 	ldr	x0, [x19]
    1b34:	f9400e61 	ldr	x1, [x19, #24]
    1b38:	f9400bf3 	ldr	x19, [sp, #16]
    1b3c:	aa0103f0 	mov	x16, x1
    1b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b44:	d61f0200 	br	x16
    1b48:	d503201f 	nop
    1b4c:	d503201f 	nop

0000000000001b50 <fwp_flush>:
    1b50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1b54:	f9403000 	ldr	x0, [x0, #96]
    1b58:	b4000120 	cbz	x0, 1b7c <fwp_flush+0x2c>
    1b5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b60:	910003fd 	mov	x29, sp
    1b64:	97fffe9b 	bl	15d0 <fflush@plt>
    1b68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    1b6c:	f947ec00 	ldr	x0, [x0, #4056]
    1b70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1b74:	f9400000 	ldr	x0, [x0]
    1b78:	17fffe96 	b	15d0 <fflush@plt>
    1b7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    1b80:	f947ec00 	ldr	x0, [x0, #4056]
    1b84:	f9400000 	ldr	x0, [x0]
    1b88:	17fffe92 	b	15d0 <fflush@plt>
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_heap_oom>:
    1b90:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152d8>
    1b94:	f947e863 	ldr	x3, [x3, #4048]
    1b98:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b9c:	d2800262 	mov	x2, #0x13                  	// #19
    1ba0:	910003fd 	mov	x29, sp
    1ba4:	f9400063 	ldr	x3, [x3]
    1ba8:	d2800021 	mov	x1, #0x1                   	// #1
    1bac:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    1bb0:	912b2000 	add	x0, x0, #0xac8
    1bb4:	97fffe7b 	bl	15a0 <fwrite@plt>
    1bb8:	d2800000 	mov	x0, #0x0                   	// #0
    1bbc:	97fffe85 	bl	15d0 <fflush@plt>
    1bc0:	52800cc0 	mov	w0, #0x66                  	// #102
    1bc4:	97fffe93 	bl	1610 <_Exit@plt>
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_segv>:
    1bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1bd4:	f00000e2 	adrp	x2, 20000 <__data_start>
    1bd8:	91018043 	add	x3, x2, #0x60
    1bdc:	910003fd 	mov	x29, sp
    1be0:	a90153f3 	stp	x19, x20, [sp, #16]
    1be4:	2a0003f3 	mov	w19, w0
    1be8:	f9400460 	ldr	x0, [x3, #8]
    1bec:	f90013f5 	str	x21, [sp, #32]
    1bf0:	f9400835 	ldr	x21, [x1, #16]
    1bf4:	b4000280 	cbz	x0, 1c44 <fwp_segv+0x74>
    1bf8:	f9400814 	ldr	x20, [x0, #16]
    1bfc:	b4000254 	cbz	x20, 1c44 <fwp_segv+0x74>
    1c00:	528003c0 	mov	w0, #0x1e                  	// #30
    1c04:	97fffe7b 	bl	15f0 <sysconf@plt>
    1c08:	f144029f 	cmp	x20, #0x100, lsl #12
    1c0c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c10:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c14:	8b000294 	add	x20, x20, x0
    1c18:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c1c:	eb0102bf 	cmp	x21, x1
    1c20:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c24:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c28:	35000240 	cbnz	w0, 1c70 <fwp_segv+0xa0>
    1c2c:	f94013f5 	ldr	x21, [sp, #32]
    1c30:	2a1303e0 	mov	w0, w19
    1c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c38:	d2800001 	mov	x1, #0x0                   	// #0
    1c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c40:	17fffdf0 	b	1400 <signal@plt>
    1c44:	91018042 	add	x2, x2, #0x60
    1c48:	f9400840 	ldr	x0, [x2, #16]
    1c4c:	b4ffff00 	cbz	x0, 1c2c <fwp_segv+0x5c>
    1c50:	f9400c41 	ldr	x1, [x2, #24]
    1c54:	cb010000 	sub	x0, x0, x1
    1c58:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c5c:	91440000 	add	x0, x0, #0x100, lsl #12
    1c60:	eb15003f 	cmp	x1, x21
    1c64:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1c68:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c6c:	34fffe00 	cbz	w0, 1c2c <fwp_segv+0x5c>
    1c70:	97ffffb8 	bl	1b50 <fwp_flush>
    1c74:	f0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    1c78:	913ec021 	add	x1, x1, #0xfb0
    1c7c:	d2800342 	mov	x2, #0x1a                  	// #26
    1c80:	52800040 	mov	w0, #0x2                   	// #2
    1c84:	97fffe17 	bl	14e0 <write@plt>
    1c88:	52800ca0 	mov	w0, #0x65                  	// #101
    1c8c:	97fffda5 	bl	1320 <_exit@plt>

0000000000001c90 <fwp_heap_chunks>:
    1c90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c94:	910003fd 	mov	x29, sp
    1c98:	a90153f3 	stp	x19, x20, [sp, #16]
    1c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ca0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xce0>
    1ca4:	911402a1 	add	x1, x21, #0x500
    1ca8:	f100041f 	cmp	x0, #0x1
    1cac:	54000ca0 	b.eq	1e40 <fwp_heap_chunks+0x1b0>  // b.none
    1cb0:	f949f822 	ldr	x2, [x1, #5104]
    1cb4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb00>
    1cb8:	9123c0a5 	add	x5, x5, #0x8f0
    1cbc:	911402a1 	add	x1, x21, #0x500
    1cc0:	f949ec34 	ldr	x20, [x1, #5080]
    1cc4:	eb14005f 	cmp	x2, x20
    1cc8:	54000c42 	b.cs	1e50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1ccc:	f949fc23 	ldr	x3, [x1, #5112]
    1cd0:	8b020841 	add	x1, x2, x2, lsl #2
    1cd4:	d2800004 	mov	x4, #0x0                   	// #0
    1cd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1cdc:	14000009 	b	1d00 <fwp_heap_chunks+0x70>
    1ce0:	91000483 	add	x3, x4, #0x1
    1ce4:	eb03001f 	cmp	x0, x3
    1ce8:	54000940 	b.eq	1e10 <fwp_heap_chunks+0x180>  // b.none
    1cec:	91000442 	add	x2, x2, #0x1
    1cf0:	aa0303e4 	mov	x4, x3
    1cf4:	9100a021 	add	x1, x1, #0x28
    1cf8:	eb02029f 	cmp	x20, x2
    1cfc:	54000100 	b.eq	1d1c <fwp_heap_chunks+0x8c>  // b.none
    1d00:	39400023 	ldrb	w3, [x1]
    1d04:	34fffee3 	cbz	w3, 1ce0 <fwp_heap_chunks+0x50>
    1d08:	91000442 	add	x2, x2, #0x1
    1d0c:	9100a021 	add	x1, x1, #0x28
    1d10:	d2800004 	mov	x4, #0x0                   	// #0
    1d14:	eb02029f 	cmp	x20, x2
    1d18:	54ffff41 	b.ne	1d00 <fwp_heap_chunks+0x70>  // b.any
    1d1c:	cb040294 	sub	x20, x20, x4
    1d20:	f9001bf7 	str	x23, [sp, #48]
    1d24:	911402b7 	add	x23, x21, #0x500
    1d28:	8b140013 	add	x19, x0, x20
    1d2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1d30:	f949f2e0 	ldr	x0, [x23, #5088]
    1d34:	cb040021 	sub	x1, x1, x4
    1d38:	f90a1ae1 	str	x1, [x23, #5168]
    1d3c:	eb00027f 	cmp	x19, x0
    1d40:	54000429 	b.ls	1dc4 <fwp_heap_chunks+0x134>  // b.plast
    1d44:	f949eae1 	ldr	x1, [x23, #5072]
    1d48:	eb01027f 	cmp	x19, x1
    1d4c:	54000888 	b.hi	1e5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1d50:	91010276 	add	x22, x19, #0x40
    1d54:	52800062 	mov	w2, #0x3                   	// #3
    1d58:	f949dae3 	ldr	x3, [x23, #5040]
    1d5c:	eb0102df 	cmp	x22, x1
    1d60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1d64:	cb0002c1 	sub	x1, x22, x0
    1d68:	8b004060 	add	x0, x3, x0, lsl #16
    1d6c:	d370bc21 	lsl	x1, x1, #16
    1d70:	97fffe34 	bl	1640 <mprotect@plt>
    1d74:	35000740 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1d78:	528003c0 	mov	w0, #0x1e                  	// #30
    1d7c:	97fffe1d 	bl	15f0 <sysconf@plt>
    1d80:	f949f2e2 	ldr	x2, [x23, #5088]
    1d84:	cb0003e5 	neg	x5, x0
    1d88:	aa0003e4 	mov	x4, x0
    1d8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1d90:	f949fee0 	ldr	x0, [x23, #5112]
    1d94:	8b020843 	add	x3, x2, x2, lsl #2
    1d98:	52800062 	mov	w2, #0x3                   	// #3
    1d9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1da0:	8b030c03 	add	x3, x0, x3, lsl #3
    1da4:	d1000421 	sub	x1, x1, #0x1
    1da8:	8a050060 	and	x0, x3, x5
    1dac:	8b040021 	add	x1, x1, x4
    1db0:	8a050021 	and	x1, x1, x5
    1db4:	cb000021 	sub	x1, x1, x0
    1db8:	97fffe22 	bl	1640 <mprotect@plt>
    1dbc:	35000500 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1dc0:	f909f2f6 	str	x22, [x23, #5088]
    1dc4:	911402b5 	add	x21, x21, #0x500
    1dc8:	d370be60 	lsl	x0, x19, #16
    1dcc:	f949e6a1 	ldr	x1, [x21, #5064]
    1dd0:	f909eeb3 	str	x19, [x21, #5080]
    1dd4:	eb01001f 	cmp	x0, x1
    1dd8:	540000e8 	b.hi	1df4 <fwp_heap_chunks+0x164>  // b.pmore
    1ddc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1de0:	aa1403e0 	mov	x0, x20
    1de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1de8:	f9401bf7 	ldr	x23, [sp, #48]
    1dec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1df0:	d65f03c0 	ret
    1df4:	f9401bf7 	ldr	x23, [sp, #48]
    1df8:	f909e6a0 	str	x0, [x21, #5064]
    1dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e00:	aa1403e0 	mov	x0, x20
    1e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e0c:	d65f03c0 	ret
    1e10:	911402b5 	add	x21, x21, #0x500
    1e14:	91000441 	add	x1, x2, #0x1
    1e18:	f90000a1 	str	x1, [x5]
    1e1c:	cb040054 	sub	x20, x2, x4
    1e20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1e24:	cb000020 	sub	x0, x1, x0
    1e28:	f90a1aa0 	str	x0, [x21, #5168]
    1e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e30:	aa1403e0 	mov	x0, x20
    1e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e3c:	d65f03c0 	ret
    1e40:	f949f422 	ldr	x2, [x1, #5096]
    1e44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb00>
    1e48:	9123a0a5 	add	x5, x5, #0x8e8
    1e4c:	17ffff9c 	b	1cbc <fwp_heap_chunks+0x2c>
    1e50:	d2800004 	mov	x4, #0x0                   	// #0
    1e54:	f9001bf7 	str	x23, [sp, #48]
    1e58:	17ffffb3 	b	1d24 <fwp_heap_chunks+0x94>
    1e5c:	97ffff4d 	bl	1b90 <fwp_heap_oom>

0000000000001e60 <buf_grow>:
    1e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1e64:	910003fd 	mov	x29, sp
    1e68:	a90153f3 	stp	x19, x20, [sp, #16]
    1e6c:	aa0003f4 	mov	x20, x0
    1e70:	f9400400 	ldr	x0, [x0, #8]
    1e74:	b100041f 	cmn	x0, #0x1
    1e78:	54000400 	b.eq	1ef8 <buf_grow+0x98>  // b.none
    1e7c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1e80:	cb000042 	sub	x2, x2, x0
    1e84:	eb01005f 	cmp	x2, x1
    1e88:	54000383 	b.cc	1ef8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1e8c:	f9400a82 	ldr	x2, [x20, #16]
    1e90:	91000421 	add	x1, x1, #0x1
    1e94:	8b000033 	add	x19, x1, x0
    1e98:	eb13005f 	cmp	x2, x19
    1e9c:	54000242 	b.cs	1ee4 <buf_grow+0x84>  // b.hs, b.nlast
    1ea0:	f100005f 	cmp	x2, #0x0
    1ea4:	b5000262 	cbnz	x2, 1ef0 <buf_grow+0x90>
    1ea8:	d2800802 	mov	x2, #0x40                  	// #64
    1eac:	eb02027f 	cmp	x19, x2
    1eb0:	54000068 	b.hi	1ebc <buf_grow+0x5c>  // b.pmore
    1eb4:	14000005 	b	1ec8 <buf_grow+0x68>
    1eb8:	b7f800a2 	tbnz	x2, #63, 1ecc <buf_grow+0x6c>
    1ebc:	d37ff842 	lsl	x2, x2, #1
    1ec0:	eb02027f 	cmp	x19, x2
    1ec4:	54ffffa8 	b.hi	1eb8 <buf_grow+0x58>  // b.pmore
    1ec8:	aa0203f3 	mov	x19, x2
    1ecc:	f9400280 	ldr	x0, [x20]
    1ed0:	aa1303e1 	mov	x1, x19
    1ed4:	97fffd6f 	bl	1490 <realloc@plt>
    1ed8:	b4000100 	cbz	x0, 1ef8 <buf_grow+0x98>
    1edc:	f9000280 	str	x0, [x20]
    1ee0:	f9000a93 	str	x19, [x20, #16]
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1eec:	d65f03c0 	ret
    1ef0:	54fffe6a 	b.ge	1ebc <buf_grow+0x5c>  // b.tcont
    1ef4:	17fffff6 	b	1ecc <buf_grow+0x6c>
    1ef8:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152d8>
    1efc:	f947e863 	ldr	x3, [x3, #4048]
    1f00:	d2800262 	mov	x2, #0x13                  	// #19
    1f04:	d2800021 	mov	x1, #0x1                   	// #1
    1f08:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    1f0c:	912b2000 	add	x0, x0, #0xac8
    1f10:	f9400063 	ldr	x3, [x3]
    1f14:	97fffda3 	bl	15a0 <fwrite@plt>
    1f18:	d2800000 	mov	x0, #0x0                   	// #0
    1f1c:	97fffdad 	bl	15d0 <fflush@plt>
    1f20:	52800cc0 	mov	w0, #0x66                  	// #102
    1f24:	97fffdbb 	bl	1610 <_Exit@plt>
    1f28:	d503201f 	nop
    1f2c:	d503201f 	nop

0000000000001f30 <buf_put>:
    1f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1f34:	910003fd 	mov	x29, sp
    1f38:	a90153f3 	stp	x19, x20, [sp, #16]
    1f3c:	aa0003f4 	mov	x20, x0
    1f40:	aa0203f3 	mov	x19, x2
    1f44:	f90013f5 	str	x21, [sp, #32]
    1f48:	aa0103f5 	mov	x21, x1
    1f4c:	aa0203e1 	mov	x1, x2
    1f50:	97ffffc4 	bl	1e60 <buf_grow>
    1f54:	a9400283 	ldp	x3, x0, [x20]
    1f58:	aa1503e1 	mov	x1, x21
    1f5c:	aa1303e2 	mov	x2, x19
    1f60:	8b000060 	add	x0, x3, x0
    1f64:	97fffce7 	bl	1300 <memcpy@plt>
    1f68:	a9400680 	ldp	x0, x1, [x20]
    1f6c:	8b010273 	add	x19, x19, x1
    1f70:	f9000693 	str	x19, [x20, #8]
    1f74:	3833681f 	strb	wzr, [x0, x19]
    1f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f7c:	f94013f5 	ldr	x21, [sp, #32]
    1f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1f84:	d65f03c0 	ret
    1f88:	d503201f 	nop
    1f8c:	d503201f 	nop

0000000000001f90 <fwp_cancel_tree.part.0>:
    1f90:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f94:	91018022 	add	x2, x1, #0x60
    1f98:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1f9c:	52800023 	mov	w3, #0x1                   	// #1
    1fa0:	910003fd 	mov	x29, sp
    1fa4:	f9400444 	ldr	x4, [x2, #8]
    1fa8:	f9000bf3 	str	x19, [sp, #16]
    1fac:	39014403 	strb	w3, [x0, #81]
    1fb0:	eb04001f 	cmp	x0, x4
    1fb4:	54000160 	b.eq	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.none
    1fb8:	f9402804 	ldr	x4, [x0, #80]
    1fbc:	f2001c9f 	tst	x4, #0xff000000ff
    1fc0:	54000101 	b.ne	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.any
    1fc4:	f9401044 	ldr	x4, [x2, #32]
    1fc8:	39015003 	strb	w3, [x0, #84]
    1fcc:	f900801f 	str	xzr, [x0, #256]
    1fd0:	b40001e4 	cbz	x4, 200c <fwp_cancel_tree.part.0+0x7c>
    1fd4:	f9008080 	str	x0, [x4, #256]
    1fd8:	91018021 	add	x1, x1, #0x60
    1fdc:	f9001020 	str	x0, [x1, #32]
    1fe0:	f9401413 	ldr	x19, [x0, #40]
    1fe4:	b40000f3 	cbz	x19, 2000 <fwp_cancel_tree.part.0+0x70>
    1fe8:	39414261 	ldrb	w1, [x19, #80]
    1fec:	aa1303e0 	mov	x0, x19
    1ff0:	37000041 	tbnz	w1, #0, 1ff8 <fwp_cancel_tree.part.0+0x68>
    1ff4:	97ffffe7 	bl	1f90 <fwp_cancel_tree.part.0>
    1ff8:	f9401a73 	ldr	x19, [x19, #48]
    1ffc:	b5ffff73 	cbnz	x19, 1fe8 <fwp_cancel_tree.part.0+0x58>
    2000:	f9400bf3 	ldr	x19, [sp, #16]
    2004:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2008:	d65f03c0 	ret
    200c:	f9001440 	str	x0, [x2, #40]
    2010:	17fffff2 	b	1fd8 <fwp_cancel_tree.part.0+0x48>

0000000000002014 <fwp_finish_float>:
    2014:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2018:	528005c1 	mov	w1, #0x2e                  	// #46
    201c:	910003fd 	mov	x29, sp
    2020:	f9000bf3 	str	x19, [sp, #16]
    2024:	aa0003f3 	mov	x19, x0
    2028:	97fffd56 	bl	1580 <strchr@plt>
    202c:	b4000080 	cbz	x0, 203c <fwp_finish_float+0x28>
    2030:	f9400bf3 	ldr	x19, [sp, #16]
    2034:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2038:	d65f03c0 	ret
    203c:	aa1303e0 	mov	x0, x19
    2040:	52800ca1 	mov	w1, #0x65                  	// #101
    2044:	97fffd4f 	bl	1580 <strchr@plt>
    2048:	b5ffff40 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    204c:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    2050:	aa1303e0 	mov	x0, x19
    2054:	912b8021 	add	x1, x1, #0xae0
    2058:	97fffd6a 	bl	1600 <strstr@plt>
    205c:	b5fffea0 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2060:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    2064:	aa1303e0 	mov	x0, x19
    2068:	912ba021 	add	x1, x1, #0xae8
    206c:	97fffd65 	bl	1600 <strstr@plt>
    2070:	b5fffe00 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2074:	aa1303e0 	mov	x0, x19
    2078:	97fffcae 	bl	1330 <strlen@plt>
    207c:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    2080:	912bc021 	add	x1, x1, #0xaf0
    2084:	8b000262 	add	x2, x19, x0
    2088:	79400023 	ldrh	w3, [x1]
    208c:	39400821 	ldrb	w1, [x1, #2]
    2090:	78206a63 	strh	w3, [x19, x0]
    2094:	39000841 	strb	w1, [x2, #2]
    2098:	17ffffe6 	b	2030 <fwp_finish_float+0x1c>
    209c:	d503201f 	nop

00000000000020a0 <fwp_trap>:
    20a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20a4:	910003fd 	mov	x29, sp
    20a8:	f9000bf3 	str	x19, [sp, #16]
    20ac:	aa0003f3 	mov	x19, x0
    20b0:	97fffea8 	bl	1b50 <fwp_flush>
    20b4:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x152d8>
    20b8:	f947e884 	ldr	x4, [x4, #4048]
    20bc:	aa1303e3 	mov	x3, x19
    20c0:	d0000022 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    20c4:	912be042 	add	x2, x2, #0xaf8
    20c8:	52800041 	mov	w1, #0x2                   	// #2
    20cc:	f9400080 	ldr	x0, [x4]
    20d0:	97fffd10 	bl	1510 <__fprintf_chk@plt>
    20d4:	52800ca0 	mov	w0, #0x65                  	// #101
    20d8:	97fffc9e 	bl	1350 <exit@plt>
    20dc:	d503201f 	nop

00000000000020e0 <fwp_now_ns>:
    20e0:	d100c3ff 	sub	sp, sp, #0x30
    20e4:	52800020 	mov	w0, #0x1                   	// #1
    20e8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152d8>
    20ec:	f947f442 	ldr	x2, [x2, #4072]
    20f0:	910023e1 	add	x1, sp, #0x8
    20f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    20f8:	910083fd 	add	x29, sp, #0x20
    20fc:	f9400043 	ldr	x3, [x2]
    2100:	f9000fe3 	str	x3, [sp, #24]
    2104:	d2800003 	mov	x3, #0x0                   	// #0
    2108:	97fffcb2 	bl	13d0 <clock_gettime@plt>
    210c:	350002c0 	cbnz	w0, 2164 <fwp_now_ns+0x84>
    2110:	a9408be1 	ldp	x1, x2, [sp, #8]
    2114:	d2994003 	mov	x3, #0xca00                	// #51712
    2118:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    211c:	9b037c20 	mul	x0, x1, x3
    2120:	9b437c21 	smulh	x1, x1, x3
    2124:	ab020000 	adds	x0, x0, x2
    2128:	937ffc42 	asr	x2, x2, #63
    212c:	9a020021 	adc	x1, x1, x2
    2130:	f100001f 	cmp	x0, #0x0
    2134:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2138:	b50001e1 	cbnz	x1, 2174 <fwp_now_ns+0x94>
    213c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    2140:	f947f421 	ldr	x1, [x1, #4072]
    2144:	f9400fe3 	ldr	x3, [sp, #24]
    2148:	f9400022 	ldr	x2, [x1]
    214c:	eb020063 	subs	x3, x3, x2
    2150:	d2800002 	mov	x2, #0x0                   	// #0
    2154:	540000e1 	b.ne	2170 <fwp_now_ns+0x90>  // b.any
    2158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    215c:	9100c3ff 	add	sp, sp, #0x30
    2160:	d65f03c0 	ret
    2164:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    2168:	912c2000 	add	x0, x0, #0xb08
    216c:	97ffffcd 	bl	20a0 <fwp_trap>
    2170:	97fffccc 	bl	14a0 <__stack_chk_fail@plt>
    2174:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    2178:	912ca000 	add	x0, x0, #0xb28
    217c:	97ffffc9 	bl	20a0 <fwp_trap>

0000000000002180 <fwp_format_g.constprop.0>:
    2180:	d10483ff 	sub	sp, sp, #0x120
    2184:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    2188:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152d8>
    218c:	f947f442 	ldr	x2, [x2, #4072]
    2190:	912d4084 	add	x4, x4, #0xb50
    2194:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2198:	9102c3fd 	add	x29, sp, #0xb0
    219c:	d2800803 	mov	x3, #0x40                  	// #64
    21a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    21a4:	93407c38 	sxtw	x24, w1
    21a8:	aa0303e1 	mov	x1, x3
    21ac:	fd008be8 	str	d8, [sp, #272]
    21b0:	1e604008 	fmov	d8, d0
    21b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    21b8:	910083f4 	add	x20, sp, #0x20
    21bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    21c0:	aa0003f5 	mov	x21, x0
    21c4:	a91073fb 	stp	x27, x28, [sp, #256]
    21c8:	5100071c 	sub	w28, w24, #0x1
    21cc:	2a1c03e5 	mov	w5, w28
    21d0:	f9400040 	ldr	x0, [x2]
    21d4:	f90057e0 	str	x0, [sp, #168]
    21d8:	d2800000 	mov	x0, #0x0                   	// #0
    21dc:	52800042 	mov	w2, #0x2                   	// #2
    21e0:	aa1403e0 	mov	x0, x20
    21e4:	97fffc8b 	bl	1410 <__snprintf_chk@plt>
    21e8:	52800ca1 	mov	w1, #0x65                  	// #101
    21ec:	aa1403e0 	mov	x0, x20
    21f0:	97fffce4 	bl	1580 <strchr@plt>
    21f4:	aa0003f3 	mov	x19, x0
    21f8:	52800142 	mov	w2, #0xa                   	// #10
    21fc:	91000400 	add	x0, x0, #0x1
    2200:	d2800001 	mov	x1, #0x0                   	// #0
    2204:	97fffccf 	bl	1540 <strtol@plt>
    2208:	aa0003f7 	mov	x23, x0
    220c:	11001400 	add	w0, w0, #0x5
    2210:	7100541f 	cmp	w0, #0x15
    2214:	54000d68 	b.hi	23c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    2218:	4b170385 	sub	w5, w28, w23
    221c:	710000bf 	cmp	w5, #0x0
    2220:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2224:	54000b80 	b.eq	2394 <fwp_format_g.constprop.0+0x214>  // b.none
    2228:	394083e0 	ldrb	w0, [sp, #32]
    222c:	cb180273 	sub	x19, x19, x24
    2230:	91000673 	add	x19, x19, #0x1
    2234:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2238:	7100b41f 	cmp	w0, #0x2d
    223c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2240:	1a9f17e4 	cset	w4, eq	// eq = none
    2244:	cb010266 	sub	x6, x19, x1
    2248:	d10004da 	sub	x26, x6, #0x1
    224c:	540018a0 	b.eq	2560 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2250:	910183f9 	add	x25, sp, #0x60
    2254:	d280091b 	mov	x27, #0x48                  	// #72
    2258:	aa1903e7 	mov	x7, x25
    225c:	91000423 	add	x3, x1, #0x1
    2260:	91011cc6 	add	x6, x6, #0x47
    2264:	910004f6 	add	x22, x7, #0x1
    2268:	37f80ff7 	tbnz	w23, #31, 2464 <fwp_format_g.constprop.0+0x2e4>
    226c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2270:	93407ef7 	sxtw	x23, w23
    2274:	390000e4 	strb	w4, [x7]
    2278:	aa1303e1 	mov	x1, x19
    227c:	aa1703e2 	mov	x2, x23
    2280:	aa1603e0 	mov	x0, x22
    2284:	b9000be5 	str	w5, [sp, #8]
    2288:	cb170374 	sub	x20, x27, x23
    228c:	a9011be3 	stp	x3, x6, [sp, #16]
    2290:	97fffc1c 	bl	1300 <memcpy@plt>
    2294:	d1000694 	sub	x20, x20, #0x1
    2298:	f9400be3 	ldr	x3, [sp, #16]
    229c:	8b1702d6 	add	x22, x22, x23
    22a0:	aa1603e0 	mov	x0, x22
    22a4:	aa1a03e2 	mov	x2, x26
    22a8:	aa0303e1 	mov	x1, x3
    22ac:	aa1403e3 	mov	x3, x20
    22b0:	97fffc50 	bl	13f0 <__memcpy_chk@plt>
    22b4:	8b1a02d6 	add	x22, x22, x26
    22b8:	f9400fe6 	ldr	x6, [sp, #24]
    22bc:	d2800900 	mov	x0, #0x48                  	// #72
    22c0:	b9400be5 	ldr	w5, [sp, #8]
    22c4:	8b170261 	add	x1, x19, x23
    22c8:	cb1400c3 	sub	x3, x6, x20
    22cc:	cb060294 	sub	x20, x20, x6
    22d0:	f101207f 	cmp	x3, #0x48
    22d4:	93407cb8 	sxtw	x24, w5
    22d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    22dc:	aa1803e2 	mov	x2, x24
    22e0:	8b1802d3 	add	x19, x22, x24
    22e4:	8b140063 	add	x3, x3, x20
    22e8:	aa1603e0 	mov	x0, x22
    22ec:	97fffc41 	bl	13f0 <__memcpy_chk@plt>
    22f0:	cb190273 	sub	x19, x19, x25
    22f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    22f8:	eb00027f 	cmp	x19, x0
    22fc:	aa1903e1 	mov	x1, x25
    2300:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2304:	aa1503e0 	mov	x0, x21
    2308:	aa1303e2 	mov	x2, x19
    230c:	97fffbfd 	bl	1300 <memcpy@plt>
    2310:	38336abf 	strb	wzr, [x21, x19]
    2314:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2318:	aa1503e0 	mov	x0, x21
    231c:	97fffc05 	bl	1330 <strlen@plt>
    2320:	aa0003f3 	mov	x19, x0
    2324:	528005c1 	mov	w1, #0x2e                  	// #46
    2328:	aa1503e0 	mov	x0, x21
    232c:	97fffc95 	bl	1580 <strchr@plt>
    2330:	b4000140 	cbz	x0, 2358 <fwp_format_g.constprop.0+0x1d8>
    2334:	b4000133 	cbz	x19, 2358 <fwp_format_g.constprop.0+0x1d8>
    2338:	aa1303e1 	mov	x1, x19
    233c:	d1000673 	sub	x19, x19, #0x1
    2340:	38736aa0 	ldrb	w0, [x21, x19]
    2344:	7100c01f 	cmp	w0, #0x30
    2348:	54001001 	b.ne	2548 <fwp_format_g.constprop.0+0x3c8>  // b.any
    234c:	38336abf 	strb	wzr, [x21, x19]
    2350:	b5ffff53 	cbnz	x19, 2338 <fwp_format_g.constprop.0+0x1b8>
    2354:	d503201f 	nop
    2358:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    235c:	f947f400 	ldr	x0, [x0, #4072]
    2360:	f94057e2 	ldr	x2, [sp, #168]
    2364:	f9400001 	ldr	x1, [x0]
    2368:	eb010042 	subs	x2, x2, x1
    236c:	d2800001 	mov	x1, #0x0                   	// #0
    2370:	54001061 	b.ne	257c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2374:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2378:	a94c53f3 	ldp	x19, x20, [sp, #192]
    237c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2380:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2384:	a95073fb 	ldp	x27, x28, [sp, #256]
    2388:	fd408be8 	ldr	d8, [sp, #272]
    238c:	910483ff 	add	sp, sp, #0x120
    2390:	d65f03c0 	ret
    2394:	1e604100 	fmov	d0, d8
    2398:	710000bf 	cmp	w5, #0x0
    239c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    23a0:	aa1503e0 	mov	x0, x21
    23a4:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    23a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    23ac:	912da084 	add	x4, x4, #0xb68
    23b0:	52800042 	mov	w2, #0x2                   	// #2
    23b4:	d2803201 	mov	x1, #0x190                 	// #400
    23b8:	97fffc16 	bl	1410 <__snprintf_chk@plt>
    23bc:	17ffffd7 	b	2318 <fwp_format_g.constprop.0+0x198>
    23c0:	cb140273 	sub	x19, x19, x20
    23c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    23c8:	910183f9 	add	x25, sp, #0x60
    23cc:	aa1303e2 	mov	x2, x19
    23d0:	aa1403e1 	mov	x1, x20
    23d4:	aa1903e0 	mov	x0, x25
    23d8:	d2800803 	mov	x3, #0x40                  	// #64
    23dc:	97fffc05 	bl	13f0 <__memcpy_chk@plt>
    23e0:	38336b3f 	strb	wzr, [x25, x19]
    23e4:	aa1903e0 	mov	x0, x25
    23e8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ec:	97fffc65 	bl	1580 <strchr@plt>
    23f0:	b40001c0 	cbz	x0, 2428 <fwp_format_g.constprop.0+0x2a8>
    23f4:	b50000b3 	cbnz	x19, 2408 <fwp_format_g.constprop.0+0x288>
    23f8:	1400000c 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    23fc:	381ff01f 	sturb	wzr, [x0, #-1]
    2400:	f1000673 	subs	x19, x19, #0x1
    2404:	54000120 	b.eq	2428 <fwp_format_g.constprop.0+0x2a8>  // b.none
    2408:	8b130320 	add	x0, x25, x19
    240c:	385ff001 	ldurb	w1, [x0, #-1]
    2410:	7100c03f 	cmp	w1, #0x30
    2414:	54ffff40 	b.eq	23fc <fwp_format_g.constprop.0+0x27c>  // b.none
    2418:	d1000673 	sub	x19, x19, #0x1
    241c:	38736b20 	ldrb	w0, [x25, x19]
    2420:	7100b81f 	cmp	w0, #0x2e
    2424:	54000a80 	b.eq	2574 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2428:	710002ff 	cmp	w23, #0x0
    242c:	528005a1 	mov	w1, #0x2d                  	// #45
    2430:	aa1903e5 	mov	x5, x25
    2434:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2438:	aa1503e0 	mov	x0, x21
    243c:	52800566 	mov	w6, #0x2b                  	// #43
    2440:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    2444:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2448:	912d6084 	add	x4, x4, #0xb58
    244c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2450:	52800042 	mov	w2, #0x2                   	// #2
    2454:	d2803201 	mov	x1, #0x190                 	// #400
    2458:	97fffbee 	bl	1410 <__snprintf_chk@plt>
    245c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2460:	17ffffbe 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2464:	52800605 	mov	w5, #0x30                  	// #48
    2468:	390000e5 	strb	w5, [x7]
    246c:	d100077b 	sub	x27, x27, #0x1
    2470:	aa0303e1 	mov	x1, x3
    2474:	aa1603e0 	mov	x0, x22
    2478:	aa1b03e3 	mov	x3, x27
    247c:	aa1a03e2 	mov	x2, x26
    2480:	f90007e6 	str	x6, [sp, #8]
    2484:	b90013e4 	str	w4, [sp, #16]
    2488:	8b1a02d6 	add	x22, x22, x26
    248c:	b9001be5 	str	w5, [sp, #24]
    2490:	97fffbd8 	bl	13f0 <__memcpy_chk@plt>
    2494:	f94007e6 	ldr	x6, [sp, #8]
    2498:	2a3703e7 	mvn	w7, w23
    249c:	b94013e4 	ldr	w4, [sp, #16]
    24a0:	cb1b00c1 	sub	x1, x6, x27
    24a4:	cb06037b 	sub	x27, x27, x6
    24a8:	f101203f 	cmp	x1, #0x48
    24ac:	d2800906 	mov	x6, #0x48                  	// #72
    24b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    24b4:	8b1b0023 	add	x3, x1, x27
    24b8:	310006ff 	cmn	w23, #0x1
    24bc:	54000220 	b.eq	2500 <fwp_format_g.constprop.0+0x380>  // b.none
    24c0:	b9401be5 	ldr	w5, [sp, #24]
    24c4:	d2800001 	mov	x1, #0x0                   	// #0
    24c8:	f101207f 	cmp	x3, #0x48
    24cc:	d1000462 	sub	x2, x3, #0x1
    24d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    24d4:	38216ac5 	strb	w5, [x22, x1]
    24d8:	cb030003 	sub	x3, x0, x3
    24dc:	91000421 	add	x1, x1, #0x1
    24e0:	91000463 	add	x3, x3, #0x1
    24e4:	eb00007f 	cmp	x3, x0
    24e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24ec:	cb000063 	sub	x3, x3, x0
    24f0:	8b020063 	add	x3, x3, x2
    24f4:	6b0100ff 	cmp	w7, w1
    24f8:	54fffe8c 	b.gt	24c8 <fwp_format_g.constprop.0+0x348>
    24fc:	8b2742d6 	add	x22, x22, w7, uxtw
    2500:	f101207f 	cmp	x3, #0x48
    2504:	d2800905 	mov	x5, #0x48                  	// #72
    2508:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    250c:	aa1603e0 	mov	x0, x22
    2510:	cb0300a1 	sub	x1, x5, x3
    2514:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2518:	91000421 	add	x1, x1, #0x1
    251c:	d1000463 	sub	x3, x3, #0x1
    2520:	eb05003f 	cmp	x1, x5
    2524:	38001402 	strb	w2, [x0], #1
    2528:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    252c:	93407f82 	sxtw	x2, w28
    2530:	cb050025 	sub	x5, x1, x5
    2534:	aa1303e1 	mov	x1, x19
    2538:	8b0300a3 	add	x3, x5, x3
    253c:	8b1802d3 	add	x19, x22, x24
    2540:	97fffbac 	bl	13f0 <__memcpy_chk@plt>
    2544:	17ffff6b 	b	22f0 <fwp_format_g.constprop.0+0x170>
    2548:	d1000421 	sub	x1, x1, #0x1
    254c:	38616aa0 	ldrb	w0, [x21, x1]
    2550:	7100b81f 	cmp	w0, #0x2e
    2554:	54fff021 	b.ne	2358 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2558:	38216abf 	strb	wzr, [x21, x1]
    255c:	17ffff7f 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2560:	910187e7 	add	x7, sp, #0x61
    2564:	910183f9 	add	x25, sp, #0x60
    2568:	d28008fb 	mov	x27, #0x47                  	// #71
    256c:	390183e0 	strb	w0, [sp, #96]
    2570:	17ffff3b 	b	225c <fwp_format_g.constprop.0+0xdc>
    2574:	38336b3f 	strb	wzr, [x25, x19]
    2578:	17ffffac 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    257c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2580:	97fffbc8 	bl	14a0 <__stack_chk_fail@plt>

0000000000002584 <fwp_heap_report>:
    2584:	d105c3ff 	sub	sp, sp, #0x170
    2588:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xce0>
    258c:	91140042 	add	x2, x2, #0x500
    2590:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152d8>
    2594:	f947e821 	ldr	x1, [x1, #4048]
    2598:	a9117bfd 	stp	x29, x30, [sp, #272]
    259c:	910443fd 	add	x29, sp, #0x110
    25a0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    25a4:	f947f400 	ldr	x0, [x0, #4072]
    25a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    25ac:	a91463f7 	stp	x23, x24, [sp, #320]
    25b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    25b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    25b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    25bc:	fd4a2049 	ldr	d9, [x2, #5184]
    25c0:	f9400036 	ldr	x22, [x1]
    25c4:	f9400001 	ldr	x1, [x0]
    25c8:	f90087e1 	str	x1, [sp, #264]
    25cc:	d2800001 	mov	x1, #0x0                   	// #0
    25d0:	f949e459 	ldr	x25, [x2, #5064]
    25d4:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    25d8:	f94a1057 	ldr	x23, [x2, #5152]
    25dc:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    25e0:	f94a1458 	ldr	x24, [x2, #5160]
    25e4:	912dc021 	add	x1, x1, #0xb70
    25e8:	912de000 	add	x0, x0, #0xb78
    25ec:	97fffb91 	bl	1430 <fopen@plt>
    25f0:	b4000760 	cbz	x0, 26dc <fwp_heap_report+0x158>
    25f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    25f8:	a91253f3 	stp	x19, x20, [sp, #288]
    25fc:	aa0003f4 	mov	x20, x0
    2600:	910023f3 	add	x19, sp, #0x8
    2604:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2608:	72aae915 	movk	w21, #0x5748, lsl #16
    260c:	d503201f 	nop
    2610:	aa1403e2 	mov	x2, x20
    2614:	aa1303e0 	mov	x0, x19
    2618:	52802001 	mov	w1, #0x100                 	// #256
    261c:	97fffc0d 	bl	1650 <fgets@plt>
    2620:	b4000280 	cbz	x0, 2670 <fwp_heap_report+0xec>
    2624:	b9400261 	ldr	w1, [x19]
    2628:	6b15003f 	cmp	w1, w21
    262c:	54ffff21 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2630:	39401260 	ldrb	w0, [x19, #4]
    2634:	7101341f 	cmp	w0, #0x4d
    2638:	54fffec1 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    263c:	394037e0 	ldrb	w0, [sp, #13]
    2640:	7100e81f 	cmp	w0, #0x3a
    2644:	54fffe61 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2648:	52800142 	mov	w2, #0xa                   	// #10
    264c:	d2800001 	mov	x1, #0x0                   	// #0
    2650:	91003be0 	add	x0, sp, #0xe
    2654:	97fffbbb 	bl	1540 <strtol@plt>
    2658:	aa1403e2 	mov	x2, x20
    265c:	aa0003fa 	mov	x26, x0
    2660:	52802001 	mov	w1, #0x100                 	// #256
    2664:	aa1303e0 	mov	x0, x19
    2668:	97fffbfa 	bl	1650 <fgets@plt>
    266c:	b5fffdc0 	cbnz	x0, 2624 <fwp_heap_report+0xa0>
    2670:	aa1403e0 	mov	x0, x20
    2674:	97fffb6b 	bl	1420 <fclose@plt>
    2678:	a95253f3 	ldp	x19, x20, [sp, #288]
    267c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    2680:	f947f400 	ldr	x0, [x0, #4072]
    2684:	f94087e2 	ldr	x2, [sp, #264]
    2688:	f9400001 	ldr	x1, [x0]
    268c:	eb010042 	subs	x2, x2, x1
    2690:	d2800001 	mov	x1, #0x0                   	// #0
    2694:	54000281 	b.ne	26e4 <fwp_heap_report+0x160>  // b.any
    2698:	a9517bfd 	ldp	x29, x30, [sp, #272]
    269c:	aa1a03e6 	mov	x6, x26
    26a0:	aa1903e5 	mov	x5, x25
    26a4:	aa1803e4 	mov	x4, x24
    26a8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    26ac:	aa1703e3 	mov	x3, x23
    26b0:	a95463f7 	ldp	x23, x24, [sp, #320]
    26b4:	aa1603e0 	mov	x0, x22
    26b8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    26bc:	1e604121 	fmov	d1, d9
    26c0:	1e604100 	fmov	d0, d8
    26c4:	d0000022 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    26c8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    26cc:	912e6042 	add	x2, x2, #0xb98
    26d0:	9105c3ff 	add	sp, sp, #0x170
    26d4:	52800041 	mov	w1, #0x2                   	// #2
    26d8:	17fffb8e 	b	1510 <__fprintf_chk@plt>
    26dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    26e0:	17ffffe7 	b	267c <fwp_heap_report+0xf8>
    26e4:	a91253f3 	stp	x19, x20, [sp, #288]
    26e8:	97fffb6e 	bl	14a0 <__stack_chk_fail@plt>
    26ec:	d503201f 	nop

00000000000026f0 <fwp_heap_init>:
    26f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    26f4:	90000183 	adrp	x3, 32000 <fwp_heap+0xb00>
    26f8:	91100061 	add	x1, x3, #0x400
    26fc:	910003fd 	mov	x29, sp
    2700:	a90153f3 	stp	x19, x20, [sp, #16]
    2704:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xce0>
    2708:	91140262 	add	x2, x19, #0x500
    270c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2710:	52800024 	mov	w4, #0x1                   	// #1
    2714:	52800200 	mov	w0, #0x10                  	// #16
    2718:	b913a444 	str	w4, [x2, #5028]
    271c:	d503201f 	nop
    2720:	b8004420 	str	w0, [x1], #4
    2724:	11004000 	add	w0, w0, #0x10
    2728:	7104401f 	cmp	w0, #0x110
    272c:	54ffffa1 	b.ne	2720 <fwp_heap_init+0x30>  // b.any
    2730:	d0000022 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    2734:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2738:	90000181 	adrp	x1, 32000 <fwp_heap+0xb00>
    273c:	91110021 	add	x1, x1, #0x440
    2740:	3dc3f843 	ldr	q3, [x2, #4064]
    2744:	d2800000 	mov	x0, #0x0                   	// #0
    2748:	4e040401 	dup	v1.4s, v0.s[0]
    274c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2750:	0f215400 	shl	v0.2s, v0.2s, #1
    2754:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2758:	3ca06821 	str	q1, [x1, x0]
    275c:	91004000 	add	x0, x0, #0x10
    2760:	f101801f 	cmp	x0, #0x60
    2764:	54ffff21 	b.ne	2748 <fwp_heap_init+0x58>  // b.any
    2768:	90000184 	adrp	x4, 32000 <fwp_heap+0xb00>
    276c:	91100063 	add	x3, x3, #0x400
    2770:	91128084 	add	x4, x4, #0x4a0
    2774:	91140266 	add	x6, x19, #0x500
    2778:	d2800002 	mov	x2, #0x0                   	// #0
    277c:	d2800000 	mov	x0, #0x0                   	// #0
    2780:	d2880205 	mov	x5, #0x4010                	// #16400
    2784:	d503201f 	nop
    2788:	910f0001 	add	x1, x0, #0x3c0
    278c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2790:	eb02003f 	cmp	x1, x2
    2794:	540000a2 	b.cs	27a8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2798:	91000400 	add	x0, x0, #0x1
    279c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    27a0:	eb02003f 	cmp	x1, x2
    27a4:	54ffffa3 	b.cc	2798 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    27a8:	91004042 	add	x2, x2, #0x10
    27ac:	38001480 	strb	w0, [x4], #1
    27b0:	eb05005f 	cmp	x2, x5
    27b4:	54fffea1 	b.ne	2788 <fwp_heap_init+0x98>  // b.any
    27b8:	528000b5 	mov	w21, #0x5                   	// #5
    27bc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    27c0:	14000004 	b	27d0 <fwp_heap_init+0xe0>
    27c4:	d342fe94 	lsr	x20, x20, #2
    27c8:	710006b5 	subs	w21, w21, #0x1
    27cc:	54000720 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    27d0:	91404296 	add	x22, x20, #0x10, lsl #12
    27d4:	d2800005 	mov	x5, #0x0                   	// #0
    27d8:	aa1603e1 	mov	x1, x22
    27dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    27e0:	52880443 	mov	w3, #0x4022                	// #16418
    27e4:	52800002 	mov	w2, #0x0                   	// #0
    27e8:	d2800000 	mov	x0, #0x0                   	// #0
    27ec:	97fffb51 	bl	1530 <mmap@plt>
    27f0:	aa0003e6 	mov	x6, x0
    27f4:	b100041f 	cmn	x0, #0x1
    27f8:	54fffe60 	b.eq	27c4 <fwp_heap_init+0xd4>  // b.none
    27fc:	b40005a0 	cbz	x0, 28b0 <fwp_heap_init+0x1c0>
    2800:	d350fe94 	lsr	x20, x20, #16
    2804:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2808:	8b0000c7 	add	x7, x6, x0
    280c:	91140275 	add	x21, x19, #0x500
    2810:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2814:	8b140a81 	add	x1, x20, x20, lsl #2
    2818:	d2800005 	mov	x5, #0x0                   	// #0
    281c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2820:	d37df021 	lsl	x1, x1, #3
    2824:	52880443 	mov	w3, #0x4022                	// #16418
    2828:	52800002 	mov	w2, #0x0                   	// #0
    282c:	d2800000 	mov	x0, #0x0                   	// #0
    2830:	f909daa7 	str	x7, [x21, #5040]
    2834:	f909dea6 	str	x6, [x21, #5048]
    2838:	f909e2b6 	str	x22, [x21, #5056]
    283c:	f909eab4 	str	x20, [x21, #5072]
    2840:	f90a02a1 	str	x1, [x21, #5120]
    2844:	97fffb3b 	bl	1530 <mmap@plt>
    2848:	aa0003e1 	mov	x1, x0
    284c:	b100041f 	cmn	x0, #0x1
    2850:	54000300 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    2854:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    2858:	91312000 	add	x0, x0, #0xc48
    285c:	f909fea1 	str	x1, [x21, #5112]
    2860:	97fffb74 	bl	1630 <getenv@plt>
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	aa0003e1 	mov	x1, x0
    286c:	b40000e0 	cbz	x0, 2888 <fwp_heap_init+0x198>
    2870:	39400000 	ldrb	w0, [x0]
    2874:	340000a0 	cbz	w0, 2888 <fwp_heap_init+0x198>
    2878:	7100c000 	subs	w0, w0, #0x30
    287c:	54000120 	b.eq	28a0 <fwp_heap_init+0x1b0>  // b.none
    2880:	7100001f 	cmp	w0, #0x0
    2884:	1a9f07e2 	cset	w2, ne	// ne = any
    2888:	91140273 	add	x19, x19, #0x500
    288c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2890:	b913aa62 	str	w2, [x19, #5032]
    2894:	a94153f3 	ldp	x19, x20, [sp, #16]
    2898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    289c:	d65f03c0 	ret
    28a0:	39400420 	ldrb	w0, [x1, #1]
    28a4:	7100001f 	cmp	w0, #0x0
    28a8:	1a9f07e2 	cset	w2, ne	// ne = any
    28ac:	17fffff7 	b	2888 <fwp_heap_init+0x198>
    28b0:	97fffcb8 	bl	1b90 <fwp_heap_oom>

00000000000028b4 <fwp_wake_io>:
    28b4:	d00000e9 	adrp	x9, 20000 <__data_start>
    28b8:	91018122 	add	x2, x9, #0x60
    28bc:	f9400001 	ldr	x1, [x0]
    28c0:	5280000a 	mov	w10, #0x0                   	// #0
    28c4:	f9401046 	ldr	x6, [x2, #32]
    28c8:	52800008 	mov	w8, #0x0                   	// #0
    28cc:	4f000400 	movi	v0.4s, #0x0
    28d0:	52800027 	mov	w7, #0x1                   	// #1
    28d4:	aa0103e2 	mov	x2, x1
    28d8:	b4000321 	cbz	x1, 293c <fwp_wake_io+0x88>
    28dc:	f9408c25 	ldr	x5, [x1, #280]
    28e0:	39015c27 	strb	w7, [x1, #87]
    28e4:	b4000165 	cbz	x5, 2910 <fwp_wake_io+0x5c>
    28e8:	a9520c24 	ldp	x4, x3, [x1, #288]
    28ec:	b4000364 	cbz	x4, 2958 <fwp_wake_io+0xa4>
    28f0:	f9009483 	str	x3, [x4, #296]
    28f4:	f9409423 	ldr	x3, [x1, #296]
    28f8:	b4000043 	cbz	x3, 2900 <fwp_wake_io+0x4c>
    28fc:	f9009064 	str	x4, [x3, #288]
    2900:	91080023 	add	x3, x1, #0x200
    2904:	f900943f 	str	xzr, [x1, #296]
    2908:	3c918060 	stur	q0, [x3, #-232]
    290c:	f9400001 	ldr	x1, [x0]
    2910:	f9402843 	ldr	x3, [x2, #80]
    2914:	f2001c7f 	tst	x3, #0xff000000ff
    2918:	54fffde1 	b.ne	28d4 <fwp_wake_io+0x20>  // b.any
    291c:	39015047 	strb	w7, [x2, #84]
    2920:	f900805f 	str	xzr, [x2, #256]
    2924:	b40001e6 	cbz	x6, 2960 <fwp_wake_io+0xac>
    2928:	f90080c2 	str	x2, [x6, #256]
    292c:	aa0203e6 	mov	x6, x2
    2930:	52800028 	mov	w8, #0x1                   	// #1
    2934:	aa0103e2 	mov	x2, x1
    2938:	b5fffd21 	cbnz	x1, 28dc <fwp_wake_io+0x28>
    293c:	3400006a 	cbz	w10, 2948 <fwp_wake_io+0x94>
    2940:	91018120 	add	x0, x9, #0x60
    2944:	f900140b 	str	x11, [x0, #40]
    2948:	34000068 	cbz	w8, 2954 <fwp_wake_io+0xa0>
    294c:	91018129 	add	x9, x9, #0x60
    2950:	f9001126 	str	x6, [x9, #32]
    2954:	d65f03c0 	ret
    2958:	f90000a3 	str	x3, [x5]
    295c:	17ffffe7 	b	28f8 <fwp_wake_io+0x44>
    2960:	aa0203eb 	mov	x11, x2
    2964:	5280002a 	mov	w10, #0x1                   	// #1
    2968:	17fffff1 	b	292c <fwp_wake_io+0x78>
    296c:	d503201f 	nop

0000000000002970 <fwp_poll_events>:
    2970:	d10103ff 	sub	sp, sp, #0x40
    2974:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    2978:	f947f400 	ldr	x0, [x0, #4072]
    297c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2980:	910083fd 	add	x29, sp, #0x20
    2984:	a90353f3 	stp	x19, x20, [sp, #48]
    2988:	d00000f4 	adrp	x20, 20000 <__data_start>
    298c:	f9400001 	ldr	x1, [x0]
    2990:	f9000fe1 	str	x1, [sp, #24]
    2994:	d2800001 	mov	x1, #0x0                   	// #0
    2998:	97fffdd2 	bl	20e0 <fwp_now_ns>
    299c:	91018281 	add	x1, x20, #0x60
    29a0:	f9401833 	ldr	x19, [x1, #48]
    29a4:	b4000e93 	cbz	x19, 2b74 <fwp_poll_events+0x204>
    29a8:	aa1303e1 	mov	x1, x19
    29ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    29b0:	14000005 	b	29c4 <fwp_poll_events+0x54>
    29b4:	f9408821 	ldr	x1, [x1, #272]
    29b8:	eb03005f 	cmp	x2, x3
    29bc:	9a83d042 	csel	x2, x2, x3, le
    29c0:	b40000c1 	cbz	x1, 29d8 <fwp_poll_events+0x68>
    29c4:	f9403423 	ldr	x3, [x1, #104]
    29c8:	b6ffff62 	tbz	x2, #63, 29b4 <fwp_poll_events+0x44>
    29cc:	f9408821 	ldr	x1, [x1, #272]
    29d0:	aa0303e2 	mov	x2, x3
    29d4:	b5ffff81 	cbnz	x1, 29c4 <fwp_poll_events+0x54>
    29d8:	b7f80ce2 	tbnz	x2, #63, 2b74 <fwp_poll_events+0x204>
    29dc:	cb000042 	sub	x2, x2, x0
    29e0:	f100005f 	cmp	x2, #0x0
    29e4:	540005cd 	b.le	2a9c <fwp_poll_events+0x12c>
    29e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    29ec:	d2884801 	mov	x1, #0x4240                	// #16960
    29f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    29f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    29f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    29fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a00:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a04:	9b407c40 	smulh	x0, x2, x0
    2a08:	9352fc00 	asr	x0, x0, #18
    2a0c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2a10:	9b018802 	msub	x2, x0, x1, x2
    2a14:	f100005f 	cmp	x2, #0x0
    2a18:	9a800400 	cinc	x0, x0, ne	// ne = any
    2a1c:	eb03001f 	cmp	x0, x3
    2a20:	54000a0c 	b.gt	2b60 <fwp_poll_events+0x1f0>
    2a24:	340003c0 	cbz	w0, 2a9c <fwp_poll_events+0x12c>
    2a28:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2a2c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2a30:	72a20c42 	movk	w2, #0x1062, lsl #16
    2a34:	9ba27c02 	umull	x2, w0, w2
    2a38:	d366fc43 	lsr	x3, x2, #38
    2a3c:	aa0303e2 	mov	x2, x3
    2a40:	1b048063 	msub	w3, w3, w4, w0
    2a44:	9b217c63 	smull	x3, w3, w1
    2a48:	d2800001 	mov	x1, #0x0                   	// #0
    2a4c:	910023e0 	add	x0, sp, #0x8
    2a50:	a9008fe2 	stp	x2, x3, [sp, #8]
    2a54:	97fffac7 	bl	1570 <nanosleep@plt>
    2a58:	91018280 	add	x0, x20, #0x60
    2a5c:	f9401813 	ldr	x19, [x0, #48]
    2a60:	97fffda0 	bl	20e0 <fwp_now_ns>
    2a64:	aa0003e6 	mov	x6, x0
    2a68:	b50001f3 	cbnz	x19, 2aa4 <fwp_poll_events+0x134>
    2a6c:	d503201f 	nop
    2a70:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    2a74:	f947f400 	ldr	x0, [x0, #4072]
    2a78:	f9400fe2 	ldr	x2, [sp, #24]
    2a7c:	f9400001 	ldr	x1, [x0]
    2a80:	eb010042 	subs	x2, x2, x1
    2a84:	d2800001 	mov	x1, #0x0                   	// #0
    2a88:	540008c1 	b.ne	2ba0 <fwp_poll_events+0x230>  // b.any
    2a8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2a90:	a94353f3 	ldp	x19, x20, [sp, #48]
    2a94:	910103ff 	add	sp, sp, #0x40
    2a98:	d65f03c0 	ret
    2a9c:	97fffd91 	bl	20e0 <fwp_now_ns>
    2aa0:	aa0003e6 	mov	x6, x0
    2aa4:	4f000400 	movi	v0.4s, #0x0
    2aa8:	91018288 	add	x8, x20, #0x60
    2aac:	52800027 	mov	w7, #0x1                   	// #1
    2ab0:	f9403661 	ldr	x1, [x19, #104]
    2ab4:	aa1303e5 	mov	x5, x19
    2ab8:	f9408a73 	ldr	x19, [x19, #272]
    2abc:	eb06003f 	cmp	x1, x6
    2ac0:	5400032c 	b.gt	2b24 <fwp_poll_events+0x1b4>
    2ac4:	394154a0 	ldrb	w0, [x5, #85]
    2ac8:	36000120 	tbz	w0, #0, 2aec <fwp_poll_events+0x17c>
    2acc:	f94084a0 	ldr	x0, [x5, #264]
    2ad0:	b40003c0 	cbz	x0, 2b48 <fwp_poll_events+0x1d8>
    2ad4:	f9008813 	str	x19, [x0, #272]
    2ad8:	b4000053 	cbz	x19, 2ae0 <fwp_poll_events+0x170>
    2adc:	f9008660 	str	x0, [x19, #264]
    2ae0:	910800a0 	add	x0, x5, #0x200
    2ae4:	390154bf 	strb	wzr, [x5, #85]
    2ae8:	3c908000 	stur	q0, [x0, #-248]
    2aec:	f94030a0 	ldr	x0, [x5, #96]
    2af0:	390158a7 	strb	w7, [x5, #86]
    2af4:	f100001f 	cmp	x0, #0x0
    2af8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2afc:	5400018d 	b.le	2b2c <fwp_poll_events+0x1bc>
    2b00:	f94028a0 	ldr	x0, [x5, #80]
    2b04:	f2001c1f 	tst	x0, #0xff000000ff
    2b08:	540000e1 	b.ne	2b24 <fwp_poll_events+0x1b4>  // b.any
    2b0c:	f9401100 	ldr	x0, [x8, #32]
    2b10:	390150a7 	strb	w7, [x5, #84]
    2b14:	f90080bf 	str	xzr, [x5, #256]
    2b18:	b40001e0 	cbz	x0, 2b54 <fwp_poll_events+0x1e4>
    2b1c:	f9001105 	str	x5, [x8, #32]
    2b20:	f9008005 	str	x5, [x0, #256]
    2b24:	b5fffc73 	cbnz	x19, 2ab0 <fwp_poll_events+0x140>
    2b28:	17ffffd2 	b	2a70 <fwp_poll_events+0x100>
    2b2c:	394144a0 	ldrb	w0, [x5, #81]
    2b30:	3707fe80 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b34:	394140a0 	ldrb	w0, [x5, #80]
    2b38:	3707fe40 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b3c:	aa0503e0 	mov	x0, x5
    2b40:	97fffd14 	bl	1f90 <fwp_cancel_tree.part.0>
    2b44:	17ffffef 	b	2b00 <fwp_poll_events+0x190>
    2b48:	91018281 	add	x1, x20, #0x60
    2b4c:	f9001833 	str	x19, [x1, #48]
    2b50:	17ffffe2 	b	2ad8 <fwp_poll_events+0x168>
    2b54:	f9001105 	str	x5, [x8, #32]
    2b58:	f9001505 	str	x5, [x8, #40]
    2b5c:	17fffff2 	b	2b24 <fwp_poll_events+0x1b4>
    2b60:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2b64:	d2989362 	mov	x2, #0xc49b                	// #50331
    2b68:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2b6c:	f2a00402 	movk	x2, #0x20, lsl #16
    2b70:	17ffffb6 	b	2a48 <fwp_poll_events+0xd8>
    2b74:	97fffbf7 	bl	1b50 <fwp_flush>
    2b78:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152d8>
    2b7c:	f947e863 	ldr	x3, [x3, #4048]
    2b80:	d2800562 	mov	x2, #0x2b                  	// #43
    2b84:	d2800021 	mov	x1, #0x1                   	// #1
    2b88:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    2b8c:	91316000 	add	x0, x0, #0xc58
    2b90:	f9400063 	ldr	x3, [x3]
    2b94:	97fffa83 	bl	15a0 <fwrite@plt>
    2b98:	52800ca0 	mov	w0, #0x65                  	// #101
    2b9c:	97fff9ed 	bl	1350 <exit@plt>
    2ba0:	97fffa40 	bl	14a0 <__stack_chk_fail@plt>

0000000000002ba4 <fwp_rc_forget_slot>:
    2ba4:	aa0003e1 	mov	x1, x0
    2ba8:	39400000 	ldrb	w0, [x0]
    2bac:	7103fc1f 	cmp	w0, #0xff
    2bb0:	54000040 	b.eq	2bb8 <fwp_rc_forget_slot+0x14>  // b.none
    2bb4:	d65f03c0 	ret
    2bb8:	ca414420 	eor	x0, x1, x1, lsr #17
    2bbc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    2bc4:	910003fd 	mov	x29, sp
    2bc8:	92401c00 	and	x0, x0, #0xff
    2bcc:	f9000bf3 	str	x19, [sp, #16]
    2bd0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xce0>
    2bd4:	91140262 	add	x2, x19, #0x500
    2bd8:	910a2403 	add	x3, x0, #0x289
    2bdc:	8b000c40 	add	x0, x2, x0, lsl #3
    2be0:	8b030c43 	add	x3, x2, x3, lsl #3
    2be4:	f94a2400 	ldr	x0, [x0, #5192]
    2be8:	b50000a0 	cbnz	x0, 2bfc <fwp_rc_forget_slot+0x58>
    2bec:	14000011 	b	2c30 <fwp_rc_forget_slot+0x8c>
    2bf0:	91004003 	add	x3, x0, #0x10
    2bf4:	f9400800 	ldr	x0, [x0, #16]
    2bf8:	b40001c0 	cbz	x0, 2c30 <fwp_rc_forget_slot+0x8c>
    2bfc:	f9400002 	ldr	x2, [x0]
    2c00:	eb02003f 	cmp	x1, x2
    2c04:	54ffff61 	b.ne	2bf0 <fwp_rc_forget_slot+0x4c>  // b.any
    2c08:	f9400801 	ldr	x1, [x0, #16]
    2c0c:	91140273 	add	x19, x19, #0x500
    2c10:	f9000061 	str	x1, [x3]
    2c14:	97fffa53 	bl	1560 <free@plt>
    2c18:	f94e2660 	ldr	x0, [x19, #7240]
    2c1c:	d1000400 	sub	x0, x0, #0x1
    2c20:	f90e2660 	str	x0, [x19, #7240]
    2c24:	f9400bf3 	ldr	x19, [sp, #16]
    2c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2c2c:	d65f03c0 	ret
    2c30:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    2c34:	91322000 	add	x0, x0, #0xc88
    2c38:	97fffd1a 	bl	20a0 <fwp_trap>
    2c3c:	d503201f 	nop

0000000000002c40 <fwp_rc_prepare_chunk>:
    2c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c44:	910003fd 	mov	x29, sp
    2c48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c4c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xce0>
    2c50:	911402c2 	add	x2, x22, #0x500
    2c54:	b9401c03 	ldr	w3, [x0, #28]
    2c58:	aa0103f5 	mov	x21, x1
    2c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c60:	aa0003f4 	mov	x20, x0
    2c64:	f94e2440 	ldr	x0, [x2, #7240]
    2c68:	b4000440 	cbz	x0, 2cf0 <fwp_rc_prepare_chunk+0xb0>
    2c6c:	d2800013 	mov	x19, #0x0                   	// #0
    2c70:	35000203 	cbnz	w3, 2cb0 <fwp_rc_prepare_chunk+0x70>
    2c74:	b4000361 	cbz	x1, 2ce0 <fwp_rc_prepare_chunk+0xa0>
    2c78:	f9401280 	ldr	x0, [x20, #32]
    2c7c:	97fffa39 	bl	1560 <free@plt>
    2c80:	aa1503e0 	mov	x0, x21
    2c84:	d2800021 	mov	x1, #0x1                   	// #1
    2c88:	97fff9fe 	bl	1480 <calloc@plt>
    2c8c:	f9001280 	str	x0, [x20, #32]
    2c90:	b5000460 	cbnz	x0, 2d1c <fwp_rc_prepare_chunk+0xdc>
    2c94:	97fffbbf 	bl	1b90 <fwp_heap_oom>
    2c98:	97ffffc3 	bl	2ba4 <fwp_rc_forget_slot>
    2c9c:	91000673 	add	x19, x19, #0x1
    2ca0:	b9401e83 	ldr	w3, [x20, #28]
    2ca4:	eb13007f 	cmp	x3, x19
    2ca8:	54000169 	b.ls	2cd4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2cac:	d503201f 	nop
    2cb0:	f9401283 	ldr	x3, [x20, #32]
    2cb4:	8b130060 	add	x0, x3, x19
    2cb8:	38736863 	ldrb	w3, [x3, x19]
    2cbc:	7103fc7f 	cmp	w3, #0xff
    2cc0:	54fffec0 	b.eq	2c98 <fwp_rc_prepare_chunk+0x58>  // b.none
    2cc4:	b9401e83 	ldr	w3, [x20, #28]
    2cc8:	91000673 	add	x19, x19, #0x1
    2ccc:	eb13007f 	cmp	x3, x19
    2cd0:	54ffff08 	b.hi	2cb0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2cd4:	eb0302bf 	cmp	x21, x3
    2cd8:	54000121 	b.ne	2cfc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2cdc:	b5000335 	cbnz	x21, 2d40 <fwp_rc_prepare_chunk+0x100>
    2ce0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ce4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ce8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cec:	d65f03c0 	ret
    2cf0:	2a0303e3 	mov	w3, w3
    2cf4:	eb0302bf 	cmp	x21, x3
    2cf8:	54ffff20 	b.eq	2cdc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2cfc:	911402c2 	add	x2, x22, #0x500
    2d00:	f9401280 	ldr	x0, [x20, #32]
    2d04:	f94e2841 	ldr	x1, [x2, #7248]
    2d08:	cb030021 	sub	x1, x1, x3
    2d0c:	f90e2841 	str	x1, [x2, #7248]
    2d10:	97fffa14 	bl	1560 <free@plt>
    2d14:	b5fffb75 	cbnz	x21, 2c80 <fwp_rc_prepare_chunk+0x40>
    2d18:	f900129f 	str	xzr, [x20, #32]
    2d1c:	911402d6 	add	x22, x22, #0x500
    2d20:	f94e2ac0 	ldr	x0, [x22, #7248]
    2d24:	b9001e95 	str	w21, [x20, #28]
    2d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d2c:	8b150000 	add	x0, x0, x21
    2d30:	f90e2ac0 	str	x0, [x22, #7248]
    2d34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d3c:	d65f03c0 	ret
    2d40:	f9401280 	ldr	x0, [x20, #32]
    2d44:	aa1503e2 	mov	x2, x21
    2d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d4c:	52800001 	mov	w1, #0x0                   	// #0
    2d50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d58:	17fff9c6 	b	1470 <memset@plt>
    2d5c:	d503201f 	nop

0000000000002d60 <fwp_heap_refill>:
    2d60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d64:	910003fd 	mov	x29, sp
    2d68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d6c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xce0>
    2d70:	911402b5 	add	x21, x21, #0x500
    2d74:	aa0003f6 	mov	x22, x0
    2d78:	d2800020 	mov	x0, #0x1                   	// #1
    2d7c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d80:	a90363f7 	stp	x23, x24, [sp, #48]
    2d84:	2a0103f7 	mov	w23, w1
    2d88:	2a0203f8 	mov	w24, w2
    2d8c:	97fffbc1 	bl	1c90 <fwp_heap_chunks>
    2d90:	aa0003f3 	mov	x19, x0
    2d94:	f949fea2 	ldr	x2, [x21, #5112]
    2d98:	8b000800 	add	x0, x0, x0, lsl #2
    2d9c:	2a1703e1 	mov	w1, w23
    2da0:	52800025 	mov	w5, #0x1                   	// #1
    2da4:	d37df000 	lsl	x0, x0, #3
    2da8:	910f0021 	add	x1, x1, #0x3c0
    2dac:	8b000054 	add	x20, x2, x0
    2db0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2db4:	52a00024 	mov	w4, #0x10000               	// #65536
    2db8:	38206845 	strb	w5, [x2, x0]
    2dbc:	aa1403e0 	mov	x0, x20
    2dc0:	39000698 	strb	w24, [x20, #1]
    2dc4:	39000a97 	strb	w23, [x20, #2]
    2dc8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2dcc:	b9000681 	str	w1, [x20, #4]
    2dd0:	2a0103e5 	mov	w5, w1
    2dd4:	8b0300a2 	add	x2, x5, x3
    2dd8:	1ac10881 	udiv	w1, w4, w1
    2ddc:	9ac50842 	udiv	x2, x2, x5
    2de0:	b9000a81 	str	w1, [x20, #8]
    2de4:	92404021 	and	x1, x1, #0x1ffff
    2de8:	b9001a82 	str	w2, [x20, #24]
    2dec:	97ffff95 	bl	2c40 <fwp_rc_prepare_chunk>
    2df0:	f949daa0 	ldr	x0, [x21, #5040]
    2df4:	29408a81 	ldp	w1, w2, [x20, #4]
    2df8:	8b134000 	add	x0, x0, x19, lsl #16
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	8b214003 	add	x3, x0, w1, uxtw
    2e04:	9ba20021 	umaddl	x1, w1, w2, x0
    2e08:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e0c:	a90086c3 	stp	x3, x1, [x22, #8]
    2e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e14:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e18:	d65f03c0 	ret
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_mem_free>:
    2e20:	b40003c0 	cbz	x0, 2e98 <fwp_mem_free+0x78>
    2e24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2e28:	910003fd 	mov	x29, sp
    2e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e30:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xce0>
    2e34:	911402a1 	add	x1, x21, #0x500
    2e38:	a90153f3 	stp	x19, x20, [sp, #16]
    2e3c:	aa0003f3 	mov	x19, x0
    2e40:	f949d823 	ldr	x3, [x1, #5040]
    2e44:	f949ec22 	ldr	x2, [x1, #5080]
    2e48:	cb030000 	sub	x0, x0, x3
    2e4c:	eb02401f 	cmp	x0, x2, lsl #16
    2e50:	540001c2 	b.cs	2e88 <fwp_mem_free+0x68>  // b.hs, b.nlast
    2e54:	d350fc16 	lsr	x22, x0, #16
    2e58:	a90363f7 	stp	x23, x24, [sp, #48]
    2e5c:	f949fc22 	ldr	x2, [x1, #5112]
    2e60:	8b160ad4 	add	x20, x22, x22, lsl #2
    2e64:	d37df294 	lsl	x20, x20, #3
    2e68:	ab140057 	adds	x23, x2, x20
    2e6c:	540000c0 	b.eq	2e84 <fwp_mem_free+0x64>  // b.none
    2e70:	38746842 	ldrb	w2, [x2, x20]
    2e74:	7100045f 	cmp	w2, #0x1
    2e78:	54000120 	b.eq	2e9c <fwp_mem_free+0x7c>  // b.none
    2e7c:	7100085f 	cmp	w2, #0x2
    2e80:	540005e0 	b.eq	2f3c <fwp_mem_free+0x11c>  // b.none
    2e84:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e90:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2e94:	d65f03c0 	ret
    2e98:	d65f03c0 	ret
    2e9c:	f94012f8 	ldr	x24, [x23, #32]
    2ea0:	b94006e1 	ldr	w1, [x23, #4]
    2ea4:	f90023f9 	str	x25, [sp, #64]
    2ea8:	2a0103e2 	mov	w2, w1
    2eac:	394006f9 	ldrb	w25, [x23, #1]
    2eb0:	39400af4 	ldrb	w20, [x23, #2]
    2eb4:	b4000158 	cbz	x24, 2edc <fwp_mem_free+0xbc>
    2eb8:	92403e76 	and	x22, x19, #0xffff
    2ebc:	9ac20ad6 	udiv	x22, x22, x2
    2ec0:	38766b01 	ldrb	w1, [x24, x22]
    2ec4:	8b160300 	add	x0, x24, x22
    2ec8:	7103fc3f 	cmp	w1, #0xff
    2ecc:	54000980 	b.eq	2ffc <fwp_mem_free+0x1dc>  // b.none
    2ed0:	38366b1f 	strb	wzr, [x24, x22]
    2ed4:	b94006e1 	ldr	w1, [x23, #4]
    2ed8:	2a0103e2 	mov	w2, w1
    2edc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    2ee0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    2ee4:	cb390000 	sub	x0, x0, w25, uxtb
    2ee8:	8b340074 	add	x20, x3, w20, uxtb
    2eec:	911402b5 	add	x21, x21, #0x500
    2ef0:	1e630021 	ucvtf	d1, w1
    2ef4:	d37ae400 	lsl	x0, x0, #6
    2ef8:	8b140c14 	add	x20, x0, x20, lsl #3
    2efc:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f00:	f8746aa0 	ldr	x0, [x21, x20]
    2f04:	f94023f9 	ldr	x25, [sp, #64]
    2f08:	aa2003e0 	mvn	x0, x0
    2f0c:	fd4a22a0 	ldr	d0, [x21, #5184]
    2f10:	f9000260 	str	x0, [x19]
    2f14:	f8346ab3 	str	x19, [x21, x20]
    2f18:	f94a12a0 	ldr	x0, [x21, #5152]
    2f1c:	1e612800 	fadd	d0, d0, d1
    2f20:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f24:	cb020000 	sub	x0, x0, x2
    2f28:	f90a12a0 	str	x0, [x21, #5152]
    2f2c:	fd0a22a0 	str	d0, [x21, #5184]
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2f38:	d65f03c0 	ret
    2f3c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    2f40:	8b000063 	add	x3, x3, x0
    2f44:	eb03027f 	cmp	x19, x3
    2f48:	54fff9e1 	b.ne	2e84 <fwp_mem_free+0x64>  // b.any
    2f4c:	fd400ae1 	ldr	d1, [x23, #16]
    2f50:	fd4a2020 	ldr	d0, [x1, #5184]
    2f54:	f9400ae0 	ldr	x0, [x23, #16]
    2f58:	7e61d821 	ucvtf	d1, d1
    2f5c:	f94a1022 	ldr	x2, [x1, #5152]
    2f60:	f94012f3 	ldr	x19, [x23, #32]
    2f64:	1e612800 	fadd	d0, d0, d1
    2f68:	cb000042 	sub	x2, x2, x0
    2f6c:	f90a1022 	str	x2, [x1, #5152]
    2f70:	fd0a2020 	str	d0, [x1, #5184]
    2f74:	b40000b3 	cbz	x19, 2f88 <fwp_mem_free+0x168>
    2f78:	39400260 	ldrb	w0, [x19]
    2f7c:	7103fc1f 	cmp	w0, #0xff
    2f80:	54000380 	b.eq	2ff0 <fwp_mem_free+0x1d0>  // b.none
    2f84:	3900027f 	strb	wzr, [x19]
    2f88:	b9400ee2 	ldr	w2, [x23, #12]
    2f8c:	b4000142 	cbz	x2, 2fb4 <fwp_mem_free+0x194>
    2f90:	911402a1 	add	x1, x21, #0x500
    2f94:	8b160040 	add	x0, x2, x22
    2f98:	8b000800 	add	x0, x0, x0, lsl #2
    2f9c:	f949fc21 	ldr	x1, [x1, #5112]
    2fa0:	8b140034 	add	x20, x1, x20
    2fa4:	8b000c20 	add	x0, x1, x0, lsl #3
    2fa8:	3802869f 	strb	wzr, [x20], #40
    2fac:	eb00029f 	cmp	x20, x0
    2fb0:	54ffffc1 	b.ne	2fa8 <fwp_mem_free+0x188>  // b.any
    2fb4:	911402a0 	add	x0, x21, #0x500
    2fb8:	f94a1801 	ldr	x1, [x0, #5168]
    2fbc:	f949f803 	ldr	x3, [x0, #5104]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f90a1801 	str	x1, [x0, #5168]
    2fc8:	eb16007f 	cmp	x3, x22
    2fcc:	54000049 	b.ls	2fd4 <fwp_mem_free+0x1b4>  // b.plast
    2fd0:	f909f816 	str	x22, [x0, #5104]
    2fd4:	911402b5 	add	x21, x21, #0x500
    2fd8:	f949f6a0 	ldr	x0, [x21, #5096]
    2fdc:	eb16001f 	cmp	x0, x22
    2fe0:	54fff529 	b.ls	2e84 <fwp_mem_free+0x64>  // b.plast
    2fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fe8:	f909f6b6 	str	x22, [x21, #5096]
    2fec:	17ffffa7 	b	2e88 <fwp_mem_free+0x68>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	97fffeec 	bl	2ba4 <fwp_rc_forget_slot>
    2ff8:	17ffffe3 	b	2f84 <fwp_mem_free+0x164>
    2ffc:	97fffeea 	bl	2ba4 <fwp_rc_forget_slot>
    3000:	17ffffb4 	b	2ed0 <fwp_mem_free+0xb0>

0000000000003004 <fwp_heap_alloc_big>:
    3004:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3008:	910003fd 	mov	x29, sp
    300c:	a90153f3 	stp	x19, x20, [sp, #16]
    3010:	a9025bf5 	stp	x21, x22, [sp, #32]
    3014:	a90363f7 	stp	x23, x24, [sp, #48]
    3018:	aa0003f7 	mov	x23, x0
    301c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3020:	a9046bf9 	stp	x25, x26, [sp, #64]
    3024:	eb0002ff 	cmp	x23, x0
    3028:	54000888 	b.hi	3138 <fwp_heap_alloc_big+0x134>  // b.pmore
    302c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3030:	8b0002f4 	add	x20, x23, x0
    3034:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xce0>
    3038:	91140359 	add	x25, x26, #0x500
    303c:	d350fe94 	lsr	x20, x20, #16
    3040:	2a0103f5 	mov	w21, w1
    3044:	aa1403e0 	mov	x0, x20
    3048:	97fffb12 	bl	1c90 <fwp_heap_chunks>
    304c:	f949ff22 	ldr	x2, [x25, #5112]
    3050:	8b000813 	add	x19, x0, x0, lsl #2
    3054:	aa0003f8 	mov	x24, x0
    3058:	52800043 	mov	w3, #0x2                   	// #2
    305c:	d37df273 	lsl	x19, x19, #3
    3060:	d2800021 	mov	x1, #0x1                   	// #1
    3064:	8b130040 	add	x0, x2, x19
    3068:	38336843 	strb	w3, [x2, x19]
    306c:	39000415 	strb	w21, [x0, #1]
    3070:	b9000c14 	str	w20, [x0, #12]
    3074:	f9000817 	str	x23, [x0, #16]
    3078:	97fffef2 	bl	2c40 <fwp_rc_prepare_chunk>
    307c:	f100069f 	cmp	x20, #0x1
    3080:	54000269 	b.ls	30cc <fwp_heap_alloc_big+0xc8>  // b.plast
    3084:	8b180294 	add	x20, x20, x24
    3088:	9100a273 	add	x19, x19, #0x28
    308c:	a90573fb 	stp	x27, x28, [sp, #80]
    3090:	5280007b 	mov	w27, #0x3                   	// #3
    3094:	8b140a94 	add	x20, x20, x20, lsl #2
    3098:	2a1803fc 	mov	w28, w24
    309c:	9adb2296 	lsl	x22, x20, x27
    30a0:	f949ff35 	ldr	x21, [x25, #5112]
    30a4:	d2800001 	mov	x1, #0x0                   	// #0
    30a8:	8b1302b4 	add	x20, x21, x19
    30ac:	aa1403e0 	mov	x0, x20
    30b0:	97fffee4 	bl	2c40 <fwp_rc_prepare_chunk>
    30b4:	38336abb 	strb	w27, [x21, x19]
    30b8:	9100a273 	add	x19, x19, #0x28
    30bc:	b9000e9c 	str	w28, [x20, #12]
    30c0:	eb1302df 	cmp	x22, x19
    30c4:	54fffee1 	b.ne	30a0 <fwp_heap_alloc_big+0x9c>  // b.any
    30c8:	a94573fb 	ldp	x27, x28, [sp, #80]
    30cc:	91140353 	add	x19, x26, #0x500
    30d0:	aa1703e2 	mov	x2, x23
    30d4:	52800001 	mov	w1, #0x0                   	// #0
    30d8:	f949da60 	ldr	x0, [x19, #5040]
    30dc:	8b184018 	add	x24, x0, x24, lsl #16
    30e0:	aa1803e0 	mov	x0, x24
    30e4:	97fff8e3 	bl	1470 <memset@plt>
    30e8:	f94a1260 	ldr	x0, [x19, #5152]
    30ec:	ab170000 	adds	x0, x0, x23
    30f0:	54000242 	b.cs	3138 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    30f4:	f94a1661 	ldr	x1, [x19, #5160]
    30f8:	f90a1260 	str	x0, [x19, #5152]
    30fc:	eb01001f 	cmp	x0, x1
    3100:	54000049 	b.ls	3108 <fwp_heap_alloc_big+0x104>  // b.plast
    3104:	f90a1660 	str	x0, [x19, #5160]
    3108:	9114035a 	add	x26, x26, #0x500
    310c:	9e6202e0 	scvtf	d0, x23
    3110:	a94153f3 	ldp	x19, x20, [sp, #16]
    3114:	aa1803e0 	mov	x0, x24
    3118:	fd4a1f41 	ldr	d1, [x26, #5176]
    311c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3120:	1e602820 	fadd	d0, d1, d0
    3124:	a94363f7 	ldp	x23, x24, [sp, #48]
    3128:	fd0a1f40 	str	d0, [x26, #5176]
    312c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3130:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3134:	d65f03c0 	ret
    3138:	a90573fb 	stp	x27, x28, [sp, #80]
    313c:	97fffa95 	bl	1b90 <fwp_heap_oom>

0000000000003140 <fwp_heap_alloc_slow>:
    3140:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3144:	910003fd 	mov	x29, sp
    3148:	a90153f3 	stp	x19, x20, [sp, #16]
    314c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xce0>
    3150:	91140262 	add	x2, x19, #0x500
    3154:	a9025bf5 	stp	x21, x22, [sp, #32]
    3158:	aa0003f5 	mov	x21, x0
    315c:	2a0103f4 	mov	w20, w1
    3160:	b953a440 	ldr	w0, [x2, #5028]
    3164:	34000600 	cbz	w0, 3224 <fwp_heap_alloc_slow+0xe4>
    3168:	f14012bf 	cmp	x21, #0x4, lsl #12
    316c:	54000628 	b.hi	3230 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3170:	91003ea0 	add	x0, x21, #0xf
    3174:	91140262 	add	x2, x19, #0x500
    3178:	f9001bf7 	str	x23, [sp, #48]
    317c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3180:	8b401040 	add	x0, x2, x0, lsr #4
    3184:	cb34c084 	sub	x4, x4, w20, sxtw
    3188:	d37ae484 	lsl	x4, x4, #6
    318c:	397e8003 	ldrb	w3, [x0, #4000]
    3190:	910f0060 	add	x0, x3, #0x3c0
    3194:	aa0303e1 	mov	x1, x3
    3198:	8b030463 	add	x3, x3, x3, lsl #1
    319c:	8b030c83 	add	x3, x4, x3, lsl #3
    31a0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    31a4:	2a1703f6 	mov	w22, w23
    31a8:	f8636844 	ldr	x4, [x2, x3]
    31ac:	b40004e4 	cbz	x4, 3248 <fwp_heap_alloc_slow+0x108>
    31b0:	f9400080 	ldr	x0, [x4]
    31b4:	aa2003e0 	mvn	x0, x0
    31b8:	f8236840 	str	x0, [x2, x3]
    31bc:	7100069f 	cmp	w20, #0x1
    31c0:	aa0403e0 	mov	x0, x4
    31c4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    31c8:	52800001 	mov	w1, #0x0                   	// #0
    31cc:	97fff8a9 	bl	1470 <memset@plt>
    31d0:	aa0003e4 	mov	x4, x0
    31d4:	91140260 	add	x0, x19, #0x500
    31d8:	f94a1001 	ldr	x1, [x0, #5152]
    31dc:	ab160021 	adds	x1, x1, x22
    31e0:	540005c2 	b.cs	3298 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    31e4:	f94a1402 	ldr	x2, [x0, #5160]
    31e8:	f90a1001 	str	x1, [x0, #5152]
    31ec:	eb02003f 	cmp	x1, x2
    31f0:	54000049 	b.ls	31f8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    31f4:	f90a1401 	str	x1, [x0, #5160]
    31f8:	91140273 	add	x19, x19, #0x500
    31fc:	1e6302e1 	ucvtf	d1, w23
    3200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3204:	aa0403e0 	mov	x0, x4
    3208:	fd4a1e60 	ldr	d0, [x19, #5176]
    320c:	f9401bf7 	ldr	x23, [sp, #48]
    3210:	1e612800 	fadd	d0, d0, d1
    3214:	fd0a1e60 	str	d0, [x19, #5176]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3220:	d65f03c0 	ret
    3224:	97fffd33 	bl	26f0 <fwp_heap_init>
    3228:	f14012bf 	cmp	x21, #0x4, lsl #12
    322c:	54fffa29 	b.ls	3170 <fwp_heap_alloc_slow+0x30>  // b.plast
    3230:	2a1403e1 	mov	w1, w20
    3234:	aa1503e0 	mov	x0, x21
    3238:	a94153f3 	ldp	x19, x20, [sp, #16]
    323c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3240:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3244:	17ffff70 	b	3004 <fwp_heap_alloc_big>
    3248:	8b030042 	add	x2, x2, x3
    324c:	f9400444 	ldr	x4, [x2, #8]
    3250:	b4000104 	cbz	x4, 3270 <fwp_heap_alloc_slow+0x130>
    3254:	f9400840 	ldr	x0, [x2, #16]
    3258:	cb040000 	sub	x0, x0, x4
    325c:	eb16001f 	cmp	x0, x22
    3260:	54000083 	b.cc	3270 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3264:	8b160080 	add	x0, x4, x22
    3268:	f9000440 	str	x0, [x2, #8]
    326c:	17ffffd4 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3270:	52800302 	mov	w2, #0x18                  	// #24
    3274:	52807804 	mov	w4, #0x3c0                 	// #960
    3278:	91140260 	add	x0, x19, #0x500
    327c:	9ba27c23 	umull	x3, w1, w2
    3280:	2a1403e2 	mov	w2, w20
    3284:	9b240e84 	smaddl	x4, w20, w4, x3
    3288:	8b040000 	add	x0, x0, x4
    328c:	97fffeb5 	bl	2d60 <fwp_heap_refill>
    3290:	aa0003e4 	mov	x4, x0
    3294:	17ffffca 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3298:	97fffa3e 	bl	1b90 <fwp_heap_oom>
    329c:	d503201f 	nop

00000000000032a0 <fwp_rc_fresh>:
    32a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32a4:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xce0>
    32a8:	91140063 	add	x3, x3, #0x500
    32ac:	910003fd 	mov	x29, sp
    32b0:	a90153f3 	stp	x19, x20, [sp, #16]
    32b4:	aa0003f3 	mov	x19, x0
    32b8:	f949d861 	ldr	x1, [x3, #5040]
    32bc:	f949ec60 	ldr	x0, [x3, #5080]
    32c0:	cb010261 	sub	x1, x19, x1
    32c4:	eb00403f 	cmp	x1, x0, lsl #16
    32c8:	54000322 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    32cc:	d350fc22 	lsr	x2, x1, #16
    32d0:	f949fc63 	ldr	x3, [x3, #5112]
    32d4:	8b020842 	add	x2, x2, x2, lsl #2
    32d8:	d37df042 	lsl	x2, x2, #3
    32dc:	8b020060 	add	x0, x3, x2
    32e0:	f9401014 	ldr	x20, [x0, #32]
    32e4:	b4000254 	cbz	x20, 332c <fwp_rc_fresh+0x8c>
    32e8:	38626862 	ldrb	w2, [x3, x2]
    32ec:	7100085f 	cmp	w2, #0x2
    32f0:	54000260 	b.eq	333c <fwp_rc_fresh+0x9c>  // b.none
    32f4:	7100045f 	cmp	w2, #0x1
    32f8:	540001a1 	b.ne	332c <fwp_rc_fresh+0x8c>  // b.any
    32fc:	29430002 	ldp	w2, w0, [x0, #24]
    3300:	92403c21 	and	x1, x1, #0xffff
    3304:	9b027c21 	mul	x1, x1, x2
    3308:	d360fc21 	lsr	x1, x1, #32
    330c:	eb00003f 	cmp	x1, x0
    3310:	540000e2 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    3314:	8b010294 	add	x20, x20, x1
    3318:	39400280 	ldrb	w0, [x20]
    331c:	7103fc1f 	cmp	w0, #0xff
    3320:	540001a0 	b.eq	3354 <fwp_rc_fresh+0xb4>  // b.none
    3324:	52800020 	mov	w0, #0x1                   	// #1
    3328:	39000280 	strb	w0, [x20]
    332c:	aa1303e0 	mov	x0, x19
    3330:	a94153f3 	ldp	x19, x20, [sp, #16]
    3334:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3338:	d65f03c0 	ret
    333c:	72003c3f 	tst	w1, #0xffff
    3340:	54fffec0 	b.eq	3318 <fwp_rc_fresh+0x78>  // b.none
    3344:	aa1303e0 	mov	x0, x19
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	aa1403e0 	mov	x0, x20
    3358:	97fffe13 	bl	2ba4 <fwp_rc_forget_slot>
    335c:	17fffff2 	b	3324 <fwp_rc_fresh+0x84>

0000000000003360 <fwp_rc_free_arr>:
    3360:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xce0>
    3364:	91140063 	add	x3, x3, #0x500
    3368:	f949d861 	ldr	x1, [x3, #5040]
    336c:	f949ec62 	ldr	x2, [x3, #5080]
    3370:	cb010001 	sub	x1, x0, x1
    3374:	eb02403f 	cmp	x1, x2, lsl #16
    3378:	54000342 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    337c:	d350fc22 	lsr	x2, x1, #16
    3380:	f949fc65 	ldr	x5, [x3, #5112]
    3384:	8b020842 	add	x2, x2, x2, lsl #2
    3388:	d37df042 	lsl	x2, x2, #3
    338c:	8b0200a4 	add	x4, x5, x2
    3390:	f9401083 	ldr	x3, [x4, #32]
    3394:	b4000263 	cbz	x3, 33e0 <fwp_rc_free_arr+0x80>
    3398:	386268a2 	ldrb	w2, [x5, x2]
    339c:	7100085f 	cmp	w2, #0x2
    33a0:	540001c0 	b.eq	33d8 <fwp_rc_free_arr+0x78>  // b.none
    33a4:	7100045f 	cmp	w2, #0x1
    33a8:	540001c1 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33ac:	29430885 	ldp	w5, w2, [x4, #24]
    33b0:	92403c21 	and	x1, x1, #0xffff
    33b4:	9b057c21 	mul	x1, x1, x5
    33b8:	d360fc21 	lsr	x1, x1, #32
    33bc:	eb02003f 	cmp	x1, x2
    33c0:	54000102 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    33c4:	8b010063 	add	x3, x3, x1
    33c8:	39400061 	ldrb	w1, [x3]
    33cc:	7100043f 	cmp	w1, #0x1
    33d0:	54000081 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33d4:	17fffe93 	b	2e20 <fwp_mem_free>
    33d8:	72003c3f 	tst	w1, #0xffff
    33dc:	54ffff60 	b.eq	33c8 <fwp_rc_free_arr+0x68>  // b.none
    33e0:	d65f03c0 	ret

00000000000033e4 <fwp_heap_alloc>:
    33e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    33e8:	f140101f 	cmp	x0, #0x4, lsl #12
    33ec:	910003fd 	mov	x29, sp
    33f0:	a90153f3 	stp	x19, x20, [sp, #16]
    33f4:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xce0>
    33f8:	91140293 	add	x19, x20, #0x500
    33fc:	b953a662 	ldr	w2, [x19, #5028]
    3400:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3404:	54000640 	b.eq	34cc <fwp_heap_alloc+0xe8>  // b.none
    3408:	91003c03 	add	x3, x0, #0xf
    340c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3410:	937c7c22 	sbfiz	x2, x1, #4, #32
    3414:	8b431263 	add	x3, x19, x3, lsr #4
    3418:	cb21c042 	sub	x2, x2, w1, sxtw
    341c:	d37ae442 	lsl	x2, x2, #6
    3420:	397e8063 	ldrb	w3, [x3, #4000]
    3424:	910f0064 	add	x4, x3, #0x3c0
    3428:	8b030463 	add	x3, x3, x3, lsl #1
    342c:	8b030c43 	add	x3, x2, x3, lsl #3
    3430:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3434:	2a1603f5 	mov	w21, w22
    3438:	f8636a64 	ldr	x4, [x19, x3]
    343c:	b4000384 	cbz	x4, 34ac <fwp_heap_alloc+0xc8>
    3440:	f9400085 	ldr	x5, [x4]
    3444:	7100043f 	cmp	w1, #0x1
    3448:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    344c:	aa0403e0 	mov	x0, x4
    3450:	aa2503e5 	mvn	x5, x5
    3454:	52800001 	mov	w1, #0x0                   	// #0
    3458:	f8236a65 	str	x5, [x19, x3]
    345c:	97fff805 	bl	1470 <memset@plt>
    3460:	aa0003e4 	mov	x4, x0
    3464:	f94a1260 	ldr	x0, [x19, #5152]
    3468:	ab150000 	adds	x0, x0, x21
    346c:	54000442 	b.cs	34f4 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    3470:	f94a1661 	ldr	x1, [x19, #5160]
    3474:	f90a1260 	str	x0, [x19, #5152]
    3478:	eb01001f 	cmp	x0, x1
    347c:	54000049 	b.ls	3484 <fwp_heap_alloc+0xa0>  // b.plast
    3480:	f90a1660 	str	x0, [x19, #5160]
    3484:	91140294 	add	x20, x20, #0x500
    3488:	1e6302c1 	ucvtf	d1, w22
    348c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3490:	aa0403e0 	mov	x0, x4
    3494:	fd4a1e80 	ldr	d0, [x20, #5176]
    3498:	1e612800 	fadd	d0, d0, d1
    349c:	fd0a1e80 	str	d0, [x20, #5176]
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34a8:	d65f03c0 	ret
    34ac:	8b030263 	add	x3, x19, x3
    34b0:	f9400464 	ldr	x4, [x3, #8]
    34b4:	b40000a4 	cbz	x4, 34c8 <fwp_heap_alloc+0xe4>
    34b8:	f9400862 	ldr	x2, [x3, #16]
    34bc:	cb040042 	sub	x2, x2, x4
    34c0:	eb15005f 	cmp	x2, x21
    34c4:	540000a2 	b.cs	34d8 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    34c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34d4:	17ffff1b 	b	3140 <fwp_heap_alloc_slow>
    34d8:	7100043f 	cmp	w1, #0x1
    34dc:	8b150085 	add	x5, x4, x21
    34e0:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    34e4:	52800001 	mov	w1, #0x0                   	// #0
    34e8:	aa0403e0 	mov	x0, x4
    34ec:	f9000465 	str	x5, [x3, #8]
    34f0:	17ffffdb 	b	345c <fwp_heap_alloc+0x78>
    34f4:	97fff9a7 	bl	1b90 <fwp_heap_oom>
    34f8:	d503201f 	nop
    34fc:	d503201f 	nop

0000000000003500 <fwp_data.part.0.constprop.0>:
    3500:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3504:	910003fd 	mov	x29, sp
    3508:	a90153f3 	stp	x19, x20, [sp, #16]
    350c:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xce0>
    3510:	91140282 	add	x2, x20, #0x500
    3514:	a9025bf5 	stp	x21, x22, [sp, #32]
    3518:	aa0003f5 	mov	x21, x0
    351c:	b953a440 	ldr	w0, [x2, #5028]
    3520:	34000700 	cbz	w0, 3600 <fwp_data.part.0.constprop.0+0x100>
    3524:	f9001bf7 	str	x23, [sp, #48]
    3528:	397e8841 	ldrb	w1, [x2, #4002]
    352c:	910f0020 	add	x0, x1, #0x3c0
    3530:	8b010421 	add	x1, x1, x1, lsl #1
    3534:	d37df021 	lsl	x1, x1, #3
    3538:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    353c:	2a1703f6 	mov	w22, w23
    3540:	f8616853 	ldr	x19, [x2, x1]
    3544:	b40004f3 	cbz	x19, 35e0 <fwp_data.part.0.constprop.0+0xe0>
    3548:	f9400260 	ldr	x0, [x19]
    354c:	aa2003e0 	mvn	x0, x0
    3550:	f8216840 	str	x0, [x2, x1]
    3554:	f10062df 	cmp	x22, #0x18
    3558:	540000e9 	b.ls	3574 <fwp_data.part.0.constprop.0+0x74>  // b.plast
    355c:	d10066c2 	sub	x2, x22, #0x19
    3560:	91006260 	add	x0, x19, #0x18
    3564:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3568:	52800001 	mov	w1, #0x0                   	// #0
    356c:	91002042 	add	x2, x2, #0x8
    3570:	97fff7c0 	bl	1470 <memset@plt>
    3574:	91140281 	add	x1, x20, #0x500
    3578:	f94a1020 	ldr	x0, [x1, #5152]
    357c:	ab160000 	adds	x0, x0, x22
    3580:	54000502 	b.cs	3620 <fwp_data.part.0.constprop.0+0x120>  // b.hs, b.nlast
    3584:	f94a1422 	ldr	x2, [x1, #5160]
    3588:	f90a1020 	str	x0, [x1, #5152]
    358c:	eb02001f 	cmp	x0, x2
    3590:	54000049 	b.ls	3598 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    3594:	f90a1420 	str	x0, [x1, #5160]
    3598:	91140294 	add	x20, x20, #0x500
    359c:	1e6302e1 	ucvtf	d1, w23
    35a0:	f9401bf7 	ldr	x23, [sp, #48]
    35a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    35a8:	1e612800 	fadd	d0, d0, d1
    35ac:	fd0a1e80 	str	d0, [x20, #5176]
    35b0:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    35b4:	fd47f000 	ldr	d0, [x0, #4064]
    35b8:	aa1303e0 	mov	x0, x19
    35bc:	fd000260 	str	d0, [x19]
    35c0:	f94002a1 	ldr	x1, [x21]
    35c4:	f9000661 	str	x1, [x19, #8]
    35c8:	f94006a1 	ldr	x1, [x21, #8]
    35cc:	f9000a61 	str	x1, [x19, #16]
    35d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    35d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35dc:	d65f03c0 	ret
    35e0:	8b010042 	add	x2, x2, x1
    35e4:	f9400453 	ldr	x19, [x2, #8]
    35e8:	b40000b3 	cbz	x19, 35fc <fwp_data.part.0.constprop.0+0xfc>
    35ec:	f9400840 	ldr	x0, [x2, #16]
    35f0:	cb130000 	sub	x0, x0, x19
    35f4:	eb0002df 	cmp	x22, x0
    35f8:	540000e9 	b.ls	3614 <fwp_data.part.0.constprop.0+0x114>  // b.plast
    35fc:	f9401bf7 	ldr	x23, [sp, #48]
    3600:	52800001 	mov	w1, #0x0                   	// #0
    3604:	d2800300 	mov	x0, #0x18                  	// #24
    3608:	97ffff77 	bl	33e4 <fwp_heap_alloc>
    360c:	aa0003f3 	mov	x19, x0
    3610:	17ffffe8 	b	35b0 <fwp_data.part.0.constprop.0+0xb0>
    3614:	8b160260 	add	x0, x19, x22
    3618:	f9000440 	str	x0, [x2, #8]
    361c:	17ffffce 	b	3554 <fwp_data.part.0.constprop.0+0x54>
    3620:	97fff95c 	bl	1b90 <fwp_heap_oom>

0000000000003624 <fwp_array_new_packed.constprop.0>:
    3624:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3628:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    362c:	910003fd 	mov	x29, sp
    3630:	f9000bf3 	str	x19, [sp, #16]
    3634:	eb01001f 	cmp	x0, x1
    3638:	54000148 	b.hi	3660 <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    363c:	aa0003f3 	mov	x19, x0
    3640:	91000400 	add	x0, x0, #0x1
    3644:	52800021 	mov	w1, #0x1                   	// #1
    3648:	d37df000 	lsl	x0, x0, #3
    364c:	97ffff66 	bl	33e4 <fwp_heap_alloc>
    3650:	f9000013 	str	x19, [x0]
    3654:	f9400bf3 	ldr	x19, [sp, #16]
    3658:	a8c27bfd 	ldp	x29, x30, [sp], #32
    365c:	d65f03c0 	ret
    3660:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    3664:	9132c000 	add	x0, x0, #0xcb0
    3668:	97fffa8e 	bl	20a0 <fwp_trap>
    366c:	d503201f 	nop

0000000000003670 <fwp_drop0>:
    3670:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3674:	910003fd 	mov	x29, sp
    3678:	a90153f3 	stp	x19, x20, [sp, #16]
    367c:	f90013f5 	str	x21, [sp, #32]
    3680:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xce0>
    3684:	911402b4 	add	x20, x21, #0x500
    3688:	f949da81 	ldr	x1, [x20, #5040]
    368c:	f949ee82 	ldr	x2, [x20, #5080]
    3690:	cb010001 	sub	x1, x0, x1
    3694:	eb02403f 	cmp	x1, x2, lsl #16
    3698:	54000382 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    369c:	d350fc22 	lsr	x2, x1, #16
    36a0:	f949fe84 	ldr	x4, [x20, #5112]
    36a4:	8b020842 	add	x2, x2, x2, lsl #2
    36a8:	d37df042 	lsl	x2, x2, #3
    36ac:	8b020083 	add	x3, x4, x2
    36b0:	f9401073 	ldr	x19, [x3, #32]
    36b4:	b40002b3 	cbz	x19, 3708 <fwp_drop0+0x98>
    36b8:	38626882 	ldrb	w2, [x4, x2]
    36bc:	7100085f 	cmp	w2, #0x2
    36c0:	540002c0 	b.eq	3718 <fwp_drop0+0xa8>  // b.none
    36c4:	7100045f 	cmp	w2, #0x1
    36c8:	54000201 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    36cc:	29430864 	ldp	w4, w2, [x3, #24]
    36d0:	92403c21 	and	x1, x1, #0xffff
    36d4:	9b047c21 	mul	x1, x1, x4
    36d8:	d360fc21 	lsr	x1, x1, #32
    36dc:	eb02003f 	cmp	x1, x2
    36e0:	54000142 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    36e4:	8b010273 	add	x19, x19, x1
    36e8:	39400261 	ldrb	w1, [x19]
    36ec:	340000e1 	cbz	w1, 3708 <fwp_drop0+0x98>
    36f0:	7100043f 	cmp	w1, #0x1
    36f4:	540001e0 	b.eq	3730 <fwp_drop0+0xc0>  // b.none
    36f8:	7103fc3f 	cmp	w1, #0xff
    36fc:	540002e0 	b.eq	3758 <fwp_drop0+0xe8>  // b.none
    3700:	51000421 	sub	w1, w1, #0x1
    3704:	39000261 	strb	w1, [x19]
    3708:	a94153f3 	ldp	x19, x20, [sp, #16]
    370c:	f94013f5 	ldr	x21, [sp, #32]
    3710:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3714:	d65f03c0 	ret
    3718:	72003c3f 	tst	w1, #0xffff
    371c:	54fffe60 	b.eq	36e8 <fwp_drop0+0x78>  // b.none
    3720:	a94153f3 	ldp	x19, x20, [sp, #16]
    3724:	f94013f5 	ldr	x21, [sp, #32]
    3728:	a8c37bfd 	ldp	x29, x30, [sp], #48
    372c:	d65f03c0 	ret
    3730:	f9400813 	ldr	x19, [x0, #16]
    3734:	97ffff0b 	bl	3360 <fwp_rc_free_arr>
    3738:	911402a0 	add	x0, x21, #0x500
    373c:	f949d801 	ldr	x1, [x0, #5040]
    3740:	f949ec00 	ldr	x0, [x0, #5080]
    3744:	cb010261 	sub	x1, x19, x1
    3748:	eb00403f 	cmp	x1, x0, lsl #16
    374c:	54fffde2 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    3750:	aa1303e0 	mov	x0, x19
    3754:	17ffffd2 	b	369c <fwp_drop0+0x2c>
    3758:	ca534660 	eor	x0, x19, x19, lsr #17
    375c:	911402b5 	add	x21, x21, #0x500
    3760:	ca402400 	eor	x0, x0, x0, lsr #9
    3764:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3768:	f94a2400 	ldr	x0, [x0, #5192]
    376c:	b5000080 	cbnz	x0, 377c <fwp_drop0+0x10c>
    3770:	14000010 	b	37b0 <fwp_drop0+0x140>
    3774:	f9400800 	ldr	x0, [x0, #16]
    3778:	b40001c0 	cbz	x0, 37b0 <fwp_drop0+0x140>
    377c:	f9400001 	ldr	x1, [x0]
    3780:	eb13003f 	cmp	x1, x19
    3784:	54ffff81 	b.ne	3774 <fwp_drop0+0x104>  // b.any
    3788:	f9400401 	ldr	x1, [x0, #8]
    378c:	d1000421 	sub	x1, x1, #0x1
    3790:	f9000401 	str	x1, [x0, #8]
    3794:	f103f83f 	cmp	x1, #0xfe
    3798:	54fffb81 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    379c:	aa1303e0 	mov	x0, x19
    37a0:	97fffd01 	bl	2ba4 <fwp_rc_forget_slot>
    37a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    37a8:	39000260 	strb	w0, [x19]
    37ac:	17ffffd7 	b	3708 <fwp_drop0+0x98>
    37b0:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    37b4:	91322000 	add	x0, x0, #0xc88
    37b8:	97fffa3a 	bl	20a0 <fwp_trap>
    37bc:	d503201f 	nop

00000000000037c0 <fwp_drop1>:
    37c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37c4:	910003fd 	mov	x29, sp
    37c8:	a90153f3 	stp	x19, x20, [sp, #16]
    37cc:	f90013f5 	str	x21, [sp, #32]
    37d0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xce0>
    37d4:	911402b4 	add	x20, x21, #0x500
    37d8:	f949da81 	ldr	x1, [x20, #5040]
    37dc:	f949ee82 	ldr	x2, [x20, #5080]
    37e0:	cb010001 	sub	x1, x0, x1
    37e4:	eb02403f 	cmp	x1, x2, lsl #16
    37e8:	54000382 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    37ec:	d350fc22 	lsr	x2, x1, #16
    37f0:	f949fe84 	ldr	x4, [x20, #5112]
    37f4:	8b020842 	add	x2, x2, x2, lsl #2
    37f8:	d37df042 	lsl	x2, x2, #3
    37fc:	8b020083 	add	x3, x4, x2
    3800:	f9401073 	ldr	x19, [x3, #32]
    3804:	b40002b3 	cbz	x19, 3858 <fwp_drop1+0x98>
    3808:	38626882 	ldrb	w2, [x4, x2]
    380c:	7100085f 	cmp	w2, #0x2
    3810:	540002c0 	b.eq	3868 <fwp_drop1+0xa8>  // b.none
    3814:	7100045f 	cmp	w2, #0x1
    3818:	54000201 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    381c:	29430864 	ldp	w4, w2, [x3, #24]
    3820:	92403c21 	and	x1, x1, #0xffff
    3824:	9b047c21 	mul	x1, x1, x4
    3828:	d360fc21 	lsr	x1, x1, #32
    382c:	eb02003f 	cmp	x1, x2
    3830:	54000142 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    3834:	8b010273 	add	x19, x19, x1
    3838:	39400261 	ldrb	w1, [x19]
    383c:	340000e1 	cbz	w1, 3858 <fwp_drop1+0x98>
    3840:	7100043f 	cmp	w1, #0x1
    3844:	540001e0 	b.eq	3880 <fwp_drop1+0xc0>  // b.none
    3848:	7103fc3f 	cmp	w1, #0xff
    384c:	540002e0 	b.eq	38a8 <fwp_drop1+0xe8>  // b.none
    3850:	51000421 	sub	w1, w1, #0x1
    3854:	39000261 	strb	w1, [x19]
    3858:	a94153f3 	ldp	x19, x20, [sp, #16]
    385c:	f94013f5 	ldr	x21, [sp, #32]
    3860:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3864:	d65f03c0 	ret
    3868:	72003c3f 	tst	w1, #0xffff
    386c:	54fffe60 	b.eq	3838 <fwp_drop1+0x78>  // b.none
    3870:	a94153f3 	ldp	x19, x20, [sp, #16]
    3874:	f94013f5 	ldr	x21, [sp, #32]
    3878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    387c:	d65f03c0 	ret
    3880:	f9400813 	ldr	x19, [x0, #16]
    3884:	97fffeb7 	bl	3360 <fwp_rc_free_arr>
    3888:	911402a0 	add	x0, x21, #0x500
    388c:	f949d801 	ldr	x1, [x0, #5040]
    3890:	f949ec00 	ldr	x0, [x0, #5080]
    3894:	cb010261 	sub	x1, x19, x1
    3898:	eb00403f 	cmp	x1, x0, lsl #16
    389c:	54fffde2 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    38a0:	aa1303e0 	mov	x0, x19
    38a4:	17ffffd2 	b	37ec <fwp_drop1+0x2c>
    38a8:	ca534660 	eor	x0, x19, x19, lsr #17
    38ac:	911402b5 	add	x21, x21, #0x500
    38b0:	ca402400 	eor	x0, x0, x0, lsr #9
    38b4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    38b8:	f94a2400 	ldr	x0, [x0, #5192]
    38bc:	b5000080 	cbnz	x0, 38cc <fwp_drop1+0x10c>
    38c0:	14000010 	b	3900 <fwp_drop1+0x140>
    38c4:	f9400800 	ldr	x0, [x0, #16]
    38c8:	b40001c0 	cbz	x0, 3900 <fwp_drop1+0x140>
    38cc:	f9400001 	ldr	x1, [x0]
    38d0:	eb13003f 	cmp	x1, x19
    38d4:	54ffff81 	b.ne	38c4 <fwp_drop1+0x104>  // b.any
    38d8:	f9400401 	ldr	x1, [x0, #8]
    38dc:	d1000421 	sub	x1, x1, #0x1
    38e0:	f9000401 	str	x1, [x0, #8]
    38e4:	f103f83f 	cmp	x1, #0xfe
    38e8:	54fffb81 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    38ec:	aa1303e0 	mov	x0, x19
    38f0:	97fffcad 	bl	2ba4 <fwp_rc_forget_slot>
    38f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    38f8:	39000260 	strb	w0, [x19]
    38fc:	17ffffd7 	b	3858 <fwp_drop1+0x98>
    3900:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    3904:	91322000 	add	x0, x0, #0xc88
    3908:	97fff9e6 	bl	20a0 <fwp_trap>
    390c:	d503201f 	nop

0000000000003910 <fwp_task_dispose>:
    3910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3914:	910003fd 	mov	x29, sp
    3918:	f9000bf3 	str	x19, [sp, #16]
    391c:	aa0003f3 	mov	x19, x0
    3920:	39414000 	ldrb	w0, [x0, #80]
    3924:	36000720 	tbz	w0, #0, 3a08 <fwp_task_dispose+0xf8>
    3928:	f9400a60 	ldr	x0, [x19, #16]
    392c:	b50006e0 	cbnz	x0, 3a08 <fwp_task_dispose+0xf8>
    3930:	a9478660 	ldp	x0, x1, [x19, #120]
    3934:	39014e7f 	strb	wzr, [x19, #83]
    3938:	f9003e7f 	str	xzr, [x19, #120]
    393c:	f100003f 	cmp	x1, #0x0
    3940:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3944:	54000040 	b.eq	394c <fwp_task_dispose+0x3c>  // b.none
    3948:	d63f0020 	blr	x1
    394c:	f9405660 	ldr	x0, [x19, #168]
    3950:	97fffd34 	bl	2e20 <fwp_mem_free>
    3954:	f900567f 	str	xzr, [x19, #168]
    3958:	b9405e60 	ldr	w0, [x19, #92]
    395c:	7100041f 	cmp	w0, #0x1
    3960:	54000420 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    3964:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xce0>
    3968:	91140042 	add	x2, x2, #0x500
    396c:	f949d840 	ldr	x0, [x2, #5040]
    3970:	f949ec41 	ldr	x1, [x2, #5080]
    3974:	cb000260 	sub	x0, x19, x0
    3978:	eb01401f 	cmp	x0, x1, lsl #16
    397c:	540002e2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3980:	d350fc01 	lsr	x1, x0, #16
    3984:	f949fc44 	ldr	x4, [x2, #5112]
    3988:	8b010821 	add	x1, x1, x1, lsl #2
    398c:	d37df021 	lsl	x1, x1, #3
    3990:	8b010083 	add	x3, x4, x1
    3994:	f9401062 	ldr	x2, [x3, #32]
    3998:	b4000202 	cbz	x2, 39d8 <fwp_task_dispose+0xc8>
    399c:	38616881 	ldrb	w1, [x4, x1]
    39a0:	7100083f 	cmp	w1, #0x2
    39a4:	54000280 	b.eq	39f4 <fwp_task_dispose+0xe4>  // b.none
    39a8:	7100043f 	cmp	w1, #0x1
    39ac:	54000161 	b.ne	39d8 <fwp_task_dispose+0xc8>  // b.any
    39b0:	29430464 	ldp	w4, w1, [x3, #24]
    39b4:	92403c00 	and	x0, x0, #0xffff
    39b8:	9b047c00 	mul	x0, x0, x4
    39bc:	d360fc00 	lsr	x0, x0, #32
    39c0:	eb01001f 	cmp	x0, x1
    39c4:	540000a2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    39c8:	8b000042 	add	x2, x2, x0
    39cc:	39400040 	ldrb	w0, [x2]
    39d0:	7100041f 	cmp	w0, #0x1
    39d4:	54000080 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    39d8:	f9400bf3 	ldr	x19, [sp, #16]
    39dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39e0:	d65f03c0 	ret
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	f9400bf3 	ldr	x19, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	17fffd0c 	b	2e20 <fwp_mem_free>
    39f4:	72003c1f 	tst	w0, #0xffff
    39f8:	54fffea0 	b.eq	39cc <fwp_task_dispose+0xbc>  // b.none
    39fc:	f9400bf3 	ldr	x19, [sp, #16]
    3a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a04:	d65f03c0 	ret
    3a08:	97fff6ba 	bl	14f0 <abort@plt>
    3a0c:	d503201f 	nop

0000000000003a10 <fwp_free_zombie>:
    3a10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3a14:	910003fd 	mov	x29, sp
    3a18:	a90153f3 	stp	x19, x20, [sp, #16]
    3a1c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3a20:	91018281 	add	x1, x20, #0x60
    3a24:	f9401c33 	ldr	x19, [x1, #56]
    3a28:	b4000333 	cbz	x19, 3a8c <fwp_free_zombie+0x7c>
    3a2c:	f9400420 	ldr	x0, [x1, #8]
    3a30:	eb00027f 	cmp	x19, x0
    3a34:	540002c0 	b.eq	3a8c <fwp_free_zombie+0x7c>  // b.none
    3a38:	b9404022 	ldr	w2, [x1, #64]
    3a3c:	f9400a60 	ldr	x0, [x19, #16]
    3a40:	7100fc5f 	cmp	w2, #0x3f
    3a44:	5400078c 	b.gt	3b34 <fwp_free_zombie+0x124>
    3a48:	91014023 	add	x3, x1, #0x50
    3a4c:	11000444 	add	w4, w2, #0x1
    3a50:	b9004024 	str	w4, [x1, #64]
    3a54:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a58:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3a5c:	a9530261 	ldp	x1, x0, [x19, #304]
    3a60:	b4000741 	cbz	x1, 3b48 <fwp_free_zombie+0x138>
    3a64:	f9009c20 	str	x0, [x1, #312]
    3a68:	b4000040 	cbz	x0, 3a70 <fwp_free_zombie+0x60>
    3a6c:	f9009801 	str	x1, [x0, #304]
    3a70:	91018294 	add	x20, x20, #0x60
    3a74:	b9405e60 	ldr	w0, [x19, #92]
    3a78:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3a7c:	f9001e9f 	str	xzr, [x20, #56]
    3a80:	34000140 	cbz	w0, 3aa8 <fwp_free_zombie+0x98>
    3a84:	7100041f 	cmp	w0, #0x1
    3a88:	54000080 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3a8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a94:	d65f03c0 	ret
    3a98:	aa1303e0 	mov	x0, x19
    3a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3aa4:	17ffff9b 	b	3910 <fwp_task_dispose>
    3aa8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xce0>
    3aac:	91140082 	add	x2, x4, #0x500
    3ab0:	f949d841 	ldr	x1, [x2, #5040]
    3ab4:	f949ec40 	ldr	x0, [x2, #5080]
    3ab8:	cb010261 	sub	x1, x19, x1
    3abc:	eb00403f 	cmp	x1, x0, lsl #16
    3ac0:	54fffe62 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3ac4:	d350fc20 	lsr	x0, x1, #16
    3ac8:	f949fc43 	ldr	x3, [x2, #5112]
    3acc:	8b000800 	add	x0, x0, x0, lsl #2
    3ad0:	d37df000 	lsl	x0, x0, #3
    3ad4:	8b000062 	add	x2, x3, x0
    3ad8:	f9401054 	ldr	x20, [x2, #32]
    3adc:	b4fffd94 	cbz	x20, 3a8c <fwp_free_zombie+0x7c>
    3ae0:	38606860 	ldrb	w0, [x3, x0]
    3ae4:	7100081f 	cmp	w0, #0x2
    3ae8:	54000360 	b.eq	3b54 <fwp_free_zombie+0x144>  // b.none
    3aec:	7100041f 	cmp	w0, #0x1
    3af0:	54fffce1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3af4:	29430043 	ldp	w3, w0, [x2, #24]
    3af8:	92403c21 	and	x1, x1, #0xffff
    3afc:	9b037c21 	mul	x1, x1, x3
    3b00:	d360fc21 	lsr	x1, x1, #32
    3b04:	eb00003f 	cmp	x1, x0
    3b08:	54fffc22 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3b0c:	8b010294 	add	x20, x20, x1
    3b10:	39400280 	ldrb	w0, [x20]
    3b14:	34fffbc0 	cbz	w0, 3a8c <fwp_free_zombie+0x7c>
    3b18:	7100041f 	cmp	w0, #0x1
    3b1c:	54fffbe0 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3b20:	7103fc1f 	cmp	w0, #0xff
    3b24:	540001e0 	b.eq	3b60 <fwp_free_zombie+0x150>  // b.none
    3b28:	51000400 	sub	w0, w0, #0x1
    3b2c:	39000280 	strb	w0, [x20]
    3b30:	17ffffd7 	b	3a8c <fwp_free_zombie+0x7c>
    3b34:	f9400e61 	ldr	x1, [x19, #24]
    3b38:	97fff6a2 	bl	15c0 <munmap@plt>
    3b3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3b40:	a9530261 	ldp	x1, x0, [x19, #304]
    3b44:	b5fff901 	cbnz	x1, 3a64 <fwp_free_zombie+0x54>
    3b48:	91018282 	add	x2, x20, #0x60
    3b4c:	f9012840 	str	x0, [x2, #592]
    3b50:	17ffffc6 	b	3a68 <fwp_free_zombie+0x58>
    3b54:	72003c3f 	tst	w1, #0xffff
    3b58:	54fff9a1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3b5c:	17ffffed 	b	3b10 <fwp_free_zombie+0x100>
    3b60:	ca544680 	eor	x0, x20, x20, lsr #17
    3b64:	91140084 	add	x4, x4, #0x500
    3b68:	ca402400 	eor	x0, x0, x0, lsr #9
    3b6c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3b70:	f94a2400 	ldr	x0, [x0, #5192]
    3b74:	b5000080 	cbnz	x0, 3b84 <fwp_free_zombie+0x174>
    3b78:	14000010 	b	3bb8 <fwp_free_zombie+0x1a8>
    3b7c:	f9400800 	ldr	x0, [x0, #16]
    3b80:	b40001c0 	cbz	x0, 3bb8 <fwp_free_zombie+0x1a8>
    3b84:	f9400001 	ldr	x1, [x0]
    3b88:	eb14003f 	cmp	x1, x20
    3b8c:	54ffff81 	b.ne	3b7c <fwp_free_zombie+0x16c>  // b.any
    3b90:	f9400401 	ldr	x1, [x0, #8]
    3b94:	d1000421 	sub	x1, x1, #0x1
    3b98:	f9000401 	str	x1, [x0, #8]
    3b9c:	f103f83f 	cmp	x1, #0xfe
    3ba0:	54fff761 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3ba4:	aa1403e0 	mov	x0, x20
    3ba8:	97fffbff 	bl	2ba4 <fwp_rc_forget_slot>
    3bac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3bb0:	39000280 	strb	w0, [x20]
    3bb4:	17ffffb6 	b	3a8c <fwp_free_zombie+0x7c>
    3bb8:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    3bbc:	91322000 	add	x0, x0, #0xc88
    3bc0:	97fff938 	bl	20a0 <fwp_trap>

0000000000003bc4 <fwp_block>:
    3bc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bc8:	910003fd 	mov	x29, sp
    3bcc:	a90153f3 	stp	x19, x20, [sp, #16]
    3bd0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3bd4:	91018274 	add	x20, x19, #0x60
    3bd8:	f9401682 	ldr	x2, [x20, #40]
    3bdc:	b4000622 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3be0:	91018261 	add	x1, x19, #0x60
    3be4:	f9408040 	ldr	x0, [x2, #256]
    3be8:	f9001420 	str	x0, [x1, #40]
    3bec:	b4000680 	cbz	x0, 3cbc <fwp_block+0xf8>
    3bf0:	91018263 	add	x3, x19, #0x60
    3bf4:	3901505f 	strb	wzr, [x2, #84]
    3bf8:	f9400464 	ldr	x4, [x3, #8]
    3bfc:	eb02009f 	cmp	x4, x2
    3c00:	54000440 	b.eq	3c88 <fwp_block+0xc4>  // b.none
    3c04:	f9412c65 	ldr	x5, [x3, #600]
    3c08:	f9000462 	str	x2, [x3, #8]
    3c0c:	f9400441 	ldr	x1, [x2, #8]
    3c10:	f9004885 	str	x5, [x4, #144]
    3c14:	f9413065 	ldr	x5, [x3, #608]
    3c18:	f9004c85 	str	x5, [x4, #152]
    3c1c:	f9413465 	ldr	x5, [x3, #616]
    3c20:	f9005085 	str	x5, [x4, #160]
    3c24:	f9413865 	ldr	x5, [x3, #624]
    3c28:	f9005485 	str	x5, [x4, #168]
    3c2c:	f9413c65 	ldr	x5, [x3, #632]
    3c30:	f9005885 	str	x5, [x4, #176]
    3c34:	f9414065 	ldr	x5, [x3, #640]
    3c38:	f9005c85 	str	x5, [x4, #184]
    3c3c:	f9414465 	ldr	x5, [x3, #648]
    3c40:	f9006085 	str	x5, [x4, #192]
    3c44:	f9400480 	ldr	x0, [x4, #8]
    3c48:	f9404844 	ldr	x4, [x2, #144]
    3c4c:	f9012c64 	str	x4, [x3, #600]
    3c50:	f9404c44 	ldr	x4, [x2, #152]
    3c54:	f9013064 	str	x4, [x3, #608]
    3c58:	f9405044 	ldr	x4, [x2, #160]
    3c5c:	f9013464 	str	x4, [x3, #616]
    3c60:	f9405444 	ldr	x4, [x2, #168]
    3c64:	f9013864 	str	x4, [x3, #624]
    3c68:	f9405844 	ldr	x4, [x2, #176]
    3c6c:	f9013c64 	str	x4, [x3, #632]
    3c70:	a94b8844 	ldp	x4, x2, [x2, #184]
    3c74:	f9014064 	str	x4, [x3, #640]
    3c78:	f9014462 	str	x2, [x3, #648]
    3c7c:	97fff621 	bl	1500 <swapcontext@plt>
    3c80:	97ffff64 	bl	3a10 <fwp_free_zombie>
    3c84:	d503201f 	nop
    3c88:	91018260 	add	x0, x19, #0x60
    3c8c:	b9429000 	ldr	w0, [x0, #656]
    3c90:	340001a0 	cbz	w0, 3cc4 <fwp_block+0x100>
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c9c:	d65f03c0 	ret
    3ca0:	97fffb34 	bl	2970 <fwp_poll_events>
    3ca4:	f9401682 	ldr	x2, [x20, #40]
    3ca8:	b4ffffc2 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3cac:	91018261 	add	x1, x19, #0x60
    3cb0:	f9408040 	ldr	x0, [x2, #256]
    3cb4:	f9001420 	str	x0, [x1, #40]
    3cb8:	b5fff9c0 	cbnz	x0, 3bf0 <fwp_block+0x2c>
    3cbc:	f900103f 	str	xzr, [x1, #32]
    3cc0:	17ffffcc 	b	3bf0 <fwp_block+0x2c>
    3cc4:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    3cc8:	91330000 	add	x0, x0, #0xcc0
    3ccc:	97fff659 	bl	1630 <getenv@plt>
    3cd0:	5284e202 	mov	w2, #0x2710                	// #10000
    3cd4:	b4000060 	cbz	x0, 3ce0 <fwp_block+0x11c>
    3cd8:	39400001 	ldrb	w1, [x0]
    3cdc:	350000c1 	cbnz	w1, 3cf4 <fwp_block+0x130>
    3ce0:	91018273 	add	x19, x19, #0x60
    3ce4:	b9029262 	str	w2, [x19, #656]
    3ce8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cf0:	d65f03c0 	ret
    3cf4:	52800142 	mov	w2, #0xa                   	// #10
    3cf8:	d2800001 	mov	x1, #0x0                   	// #0
    3cfc:	97fff59d 	bl	1370 <strtoll@plt>
    3d00:	d1000403 	sub	x3, x0, #0x1
    3d04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3d08:	eb02007f 	cmp	x3, x2
    3d0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3d10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3d14:	17fffff3 	b	3ce0 <fwp_block+0x11c>
    3d18:	d503201f 	nop
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_write.constprop.0>:
    3d20:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3d24:	910003fd 	mov	x29, sp
    3d28:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152d8>
    3d2c:	f947f463 	ldr	x3, [x3, #4072]
    3d30:	a90153f3 	stp	x19, x20, [sp, #16]
    3d34:	d10943ff 	sub	sp, sp, #0x250
    3d38:	aa0003f4 	mov	x20, x0
    3d3c:	b9400040 	ldr	w0, [x2]
    3d40:	aa0103f3 	mov	x19, x1
    3d44:	f9400061 	ldr	x1, [x3]
    3d48:	f90127e1 	str	x1, [sp, #584]
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	7100641f 	cmp	w0, #0x19
    3d54:	540003e8 	b.hi	3dd0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3d58:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    3d5c:	913dc021 	add	x1, x1, #0xf70
    3d60:	f9013bf5 	str	x21, [sp, #624]
    3d64:	f9013ff6 	str	x22, [sp, #632]
    3d68:	f90153fb 	str	x27, [sp, #672]
    3d6c:	f90157fc 	str	x28, [sp, #680]
    3d70:	aa0203fc 	mov	x28, x2
    3d74:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3d78:	10000062 	adr	x2, 3d84 <fwp_write.constprop.0+0x64>
    3d7c:	8b21a841 	add	x1, x2, w1, sxth #2
    3d80:	d61f0020 	br	x1
    3d84:	910123e0 	add	x0, sp, #0x48
    3d88:	aa1303e5 	mov	x5, x19
    3d8c:	b0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    3d90:	aa0003f3 	mov	x19, x0
    3d94:	91342084 	add	x4, x4, #0xd08
    3d98:	d2804003 	mov	x3, #0x200                 	// #512
    3d9c:	aa0303e1 	mov	x1, x3
    3da0:	52800042 	mov	w2, #0x2                   	// #2
    3da4:	97fff59b 	bl	1410 <__snprintf_chk@plt>
    3da8:	aa1303e0 	mov	x0, x19
    3dac:	97fff561 	bl	1330 <strlen@plt>
    3db0:	aa1303e1 	mov	x1, x19
    3db4:	aa0003e2 	mov	x2, x0
    3db8:	aa1403e0 	mov	x0, x20
    3dbc:	97fff85d 	bl	1f30 <buf_put>
    3dc0:	f9413bf5 	ldr	x21, [sp, #624]
    3dc4:	f9413ff6 	ldr	x22, [sp, #632]
    3dc8:	f94153fb 	ldr	x27, [sp, #672]
    3dcc:	f94157fc 	ldr	x28, [sp, #680]
    3dd0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    3dd4:	f947f400 	ldr	x0, [x0, #4072]
    3dd8:	f94127e2 	ldr	x2, [sp, #584]
    3ddc:	f9400001 	ldr	x1, [x0]
    3de0:	eb010042 	subs	x2, x2, x1
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	540074a1 	b.ne	4c7c <fwp_write.constprop.0+0xf5c>  // b.any
    3dec:	910943ff 	add	sp, sp, #0x250
    3df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3df4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3df8:	d65f03c0 	ret
    3dfc:	910123e0 	add	x0, sp, #0x48
    3e00:	aa1303e5 	mov	x5, x19
    3e04:	b0000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    3e08:	aa0003f3 	mov	x19, x0
    3e0c:	91340084 	add	x4, x4, #0xd00
    3e10:	d2804003 	mov	x3, #0x200                 	// #512
    3e14:	17ffffe2 	b	3d9c <fwp_write.constprop.0+0x7c>
    3e18:	71004c1f 	cmp	w0, #0x13
    3e1c:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    3e20:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    3e24:	9133e021 	add	x1, x1, #0xcf8
    3e28:	9133c000 	add	x0, x0, #0xcf0
    3e2c:	d2800082 	mov	x2, #0x4                   	// #4
    3e30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    3e34:	aa1403e0 	mov	x0, x20
    3e38:	f90143f7 	str	x23, [sp, #640]
    3e3c:	d2800016 	mov	x22, #0x0                   	// #0
    3e40:	f90147f8 	str	x24, [sp, #648]
    3e44:	97fff83b 	bl	1f30 <buf_put>
    3e48:	f9400260 	ldr	x0, [x19]
    3e4c:	b0000037 	adrp	x23, 8000 <fwp_main_thread+0x1a0>
    3e50:	d2800015 	mov	x21, #0x0                   	// #0
    3e54:	9135e2f7 	add	x23, x23, #0xd78
    3e58:	b4004e40 	cbz	x0, 4820 <fwp_write.constprop.0+0xb00>
    3e5c:	b9400381 	ldr	w1, [x28]
    3e60:	aa1403e0 	mov	x0, x20
    3e64:	f9401f82 	ldr	x2, [x28, #56]
    3e68:	71004c3f 	cmp	w1, #0x13
    3e6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    3e70:	8b010e61 	add	x1, x19, x1, lsl #3
    3e74:	f9400421 	ldr	x1, [x1, #8]
    3e78:	97ffffaa 	bl	3d20 <fwp_write.constprop.0>
    3e7c:	b9400380 	ldr	w0, [x28]
    3e80:	7100481f 	cmp	w0, #0x12
    3e84:	540050c0 	b.eq	489c <fwp_write.constprop.0+0xb7c>  // b.none
    3e88:	f9400260 	ldr	x0, [x19]
    3e8c:	910006b5 	add	x21, x21, #0x1
    3e90:	91000ad6 	add	x22, x22, #0x2
    3e94:	eb0002bf 	cmp	x21, x0
    3e98:	54004c42 	b.cs	4820 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    3e9c:	aa1703e1 	mov	x1, x23
    3ea0:	aa1403e0 	mov	x0, x20
    3ea4:	d2800042 	mov	x2, #0x2                   	// #2
    3ea8:	97fff822 	bl	1f30 <buf_put>
    3eac:	17ffffec 	b	3e5c <fwp_write.constprop.0+0x13c>
    3eb0:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    3eb4:	9134c021 	add	x1, x1, #0xd30
    3eb8:	d28000c2 	mov	x2, #0x6                   	// #6
    3ebc:	aa1403e0 	mov	x0, x20
    3ec0:	91004273 	add	x19, x19, #0x10
    3ec4:	97fff81b 	bl	1f30 <buf_put>
    3ec8:	aa1303e0 	mov	x0, x19
    3ecc:	97fff519 	bl	1330 <strlen@plt>
    3ed0:	aa1303e1 	mov	x1, x19
    3ed4:	aa0003e2 	mov	x2, x0
    3ed8:	aa1403e0 	mov	x0, x20
    3edc:	97fff815 	bl	1f30 <buf_put>
    3ee0:	528007c3 	mov	w3, #0x3e                  	// #62
    3ee4:	aa1403e0 	mov	x0, x20
    3ee8:	91001fe1 	add	x1, sp, #0x7
    3eec:	d2800022 	mov	x2, #0x1                   	// #1
    3ef0:	39001fe3 	strb	w3, [sp, #7]
    3ef4:	17ffffb2 	b	3dbc <fwp_write.constprop.0+0x9c>
    3ef8:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    3efc:	f947f400 	ldr	x0, [x0, #4072]
    3f00:	f94127e2 	ldr	x2, [sp, #584]
    3f04:	f9400001 	ldr	x1, [x0]
    3f08:	eb010042 	subs	x2, x2, x1
    3f0c:	d2800001 	mov	x1, #0x0                   	// #0
    3f10:	54006cc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    3f14:	f9413bf5 	ldr	x21, [sp, #624]
    3f18:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    3f1c:	f9413ff6 	ldr	x22, [sp, #632]
    3f20:	aa1403e0 	mov	x0, x20
    3f24:	91344021 	add	x1, x1, #0xd10
    3f28:	d2800142 	mov	x2, #0xa                   	// #10
    3f2c:	f94153fb 	ldr	x27, [sp, #672]
    3f30:	f94157fc 	ldr	x28, [sp, #680]
    3f34:	910943ff 	add	sp, sp, #0x250
    3f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f3c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3f40:	17fff7fc 	b	1f30 <buf_put>
    3f44:	f9400796 	ldr	x22, [x28, #8]
    3f48:	f90143f7 	str	x23, [sp, #640]
    3f4c:	f90147f8 	str	x24, [sp, #648]
    3f50:	b4005816 	cbz	x22, 4a50 <fwp_write.constprop.0+0xd30>
    3f54:	aa1603e0 	mov	x0, x22
    3f58:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    3f5c:	91364021 	add	x1, x1, #0xd90
    3f60:	97fff570 	bl	1520 <strcmp@plt>
    3f64:	2a0003f5 	mov	w21, w0
    3f68:	34005ce0 	cbz	w0, 4b04 <fwp_write.constprop.0+0xde4>
    3f6c:	aa1603e0 	mov	x0, x22
    3f70:	97fff4f0 	bl	1330 <strlen@plt>
    3f74:	aa1603e1 	mov	x1, x22
    3f78:	aa0003e2 	mov	x2, x0
    3f7c:	aa1403e0 	mov	x0, x20
    3f80:	97fff7ec 	bl	1f30 <buf_put>
    3f84:	52800403 	mov	w3, #0x20                  	// #32
    3f88:	91001ff5 	add	x21, sp, #0x7
    3f8c:	aa1503e1 	mov	x1, x21
    3f90:	aa1403e0 	mov	x0, x20
    3f94:	d2800022 	mov	x2, #0x1                   	// #1
    3f98:	39001fe3 	strb	w3, [sp, #7]
    3f9c:	97fff7e5 	bl	1f30 <buf_put>
    3fa0:	52800f63 	mov	w3, #0x7b                  	// #123
    3fa4:	aa1403e0 	mov	x0, x20
    3fa8:	aa1503e1 	mov	x1, x21
    3fac:	d2800022 	mov	x2, #0x1                   	// #1
    3fb0:	39001fe3 	strb	w3, [sp, #7]
    3fb4:	97fff7df 	bl	1f30 <buf_put>
    3fb8:	b9401380 	ldr	w0, [x28, #16]
    3fbc:	52800018 	mov	w24, #0x0                   	// #0
    3fc0:	7100001f 	cmp	w0, #0x0
    3fc4:	54003d8d 	b.le	4774 <fwp_write.constprop.0+0xa54>
    3fc8:	f9014bf9 	str	x25, [sp, #656]
    3fcc:	b0000039 	adrp	x25, 8000 <fwp_main_thread+0x1a0>
    3fd0:	9136e339 	add	x25, x25, #0xdb8
    3fd4:	f9014ffa 	str	x26, [sp, #664]
    3fd8:	b000003a 	adrp	x26, 8000 <fwp_main_thread+0x1a0>
    3fdc:	9135e35a 	add	x26, x26, #0xd78
    3fe0:	91002276 	add	x22, x19, #0x8
    3fe4:	d2800013 	mov	x19, #0x0                   	// #0
    3fe8:	b5004413 	cbnz	x19, 4868 <fwp_write.constprop.0+0xb48>
    3fec:	d37df277 	lsl	x23, x19, #3
    3ff0:	34004238 	cbz	w24, 4834 <fwp_write.constprop.0+0xb14>
    3ff4:	f9401382 	ldr	x2, [x28, #32]
    3ff8:	aa1403e0 	mov	x0, x20
    3ffc:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    4000:	91000673 	add	x19, x19, #0x1
    4004:	f8776842 	ldr	x2, [x2, x23]
    4008:	97ffff46 	bl	3d20 <fwp_write.constprop.0>
    400c:	b9401380 	ldr	w0, [x28, #16]
    4010:	6b13001f 	cmp	w0, w19
    4014:	54fffeac 	b.gt	3fe8 <fwp_write.constprop.0+0x2c8>
    4018:	f9414bf9 	ldr	x25, [sp, #656]
    401c:	f9414ffa 	ldr	x26, [sp, #664]
    4020:	34003ab8 	cbz	w24, 4774 <fwp_write.constprop.0+0xa54>
    4024:	52800523 	mov	w3, #0x29                  	// #41
    4028:	aa1503e1 	mov	x1, x21
    402c:	aa1403e0 	mov	x0, x20
    4030:	d2800022 	mov	x2, #0x1                   	// #1
    4034:	39001fe3 	strb	w3, [sp, #7]
    4038:	97fff7be 	bl	1f30 <buf_put>
    403c:	f9413bf5 	ldr	x21, [sp, #624]
    4040:	f9413ff6 	ldr	x22, [sp, #632]
    4044:	f94143f7 	ldr	x23, [sp, #640]
    4048:	f94147f8 	ldr	x24, [sp, #648]
    404c:	f94153fb 	ldr	x27, [sp, #672]
    4050:	f94157fc 	ldr	x28, [sp, #680]
    4054:	17ffff5f 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4058:	b9404b95 	ldr	w21, [x28, #72]
    405c:	aa1403e0 	mov	x0, x20
    4060:	93407eb6 	sxtw	x22, w21
    4064:	91000ac1 	add	x1, x22, #0x2
    4068:	97fff77e 	bl	1e60 <buf_grow>
    406c:	a9400281 	ldp	x1, x0, [x20]
    4070:	528e8603 	mov	w3, #0x7430                	// #29744
    4074:	78206823 	strh	w3, [x1, x0]
    4078:	8b000022 	add	x2, x1, x0
    407c:	710002bf 	cmp	w21, #0x0
    4080:	54003bcd 	b.le	47f8 <fwp_write.constprop.0+0xad8>
    4084:	110006a3 	add	w3, w21, #0x1
    4088:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    408c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4090:	91000449 	add	x9, x2, #0x1
    4094:	8b23c043 	add	x3, x2, w3, sxtw
    4098:	f28aaac6 	movk	x6, #0x5556
    409c:	f2955568 	movk	x8, #0xaaab
    40a0:	1400000d 	b	40d4 <fwp_write.constprop.0+0x3b4>
    40a4:	d2800021 	mov	x1, #0x1                   	// #1
    40a8:	528005a5 	mov	w5, #0x2d                  	// #45
    40ac:	f100001f 	cmp	x0, #0x0
    40b0:	9b467e60 	smulh	x0, x19, x6
    40b4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    40b8:	381ff465 	strb	w5, [x3], #-1
    40bc:	cb040000 	sub	x0, x0, x4
    40c0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    40c4:	cb020000 	sub	x0, x0, x2
    40c8:	8b010013 	add	x19, x0, x1
    40cc:	eb03013f 	cmp	x9, x3
    40d0:	54003940 	b.eq	47f8 <fwp_write.constprop.0+0xad8>  // b.none
    40d4:	9b467e60 	smulh	x0, x19, x6
    40d8:	937ffe64 	asr	x4, x19, #63
    40dc:	52800605 	mov	w5, #0x30                  	// #48
    40e0:	cb040000 	sub	x0, x0, x4
    40e4:	8b000400 	add	x0, x0, x0, lsl #1
    40e8:	cb000260 	sub	x0, x19, x0
    40ec:	91000c01 	add	x1, x0, #0x3
    40f0:	9bc87c22 	umulh	x2, x1, x8
    40f4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    40f8:	8b4204e2 	add	x2, x7, x2, lsr #1
    40fc:	eb020021 	subs	x1, x1, x2
    4100:	54fffd60 	b.eq	40ac <fwp_write.constprop.0+0x38c>  // b.none
    4104:	f100043f 	cmp	x1, #0x1
    4108:	54fffce1 	b.ne	40a4 <fwp_write.constprop.0+0x384>  // b.any
    410c:	d2800001 	mov	x1, #0x0                   	// #0
    4110:	52800565 	mov	w5, #0x2b                  	// #43
    4114:	17ffffe6 	b	40ac <fwp_write.constprop.0+0x38c>
    4118:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    411c:	f947f400 	ldr	x0, [x0, #4072]
    4120:	f94127e2 	ldr	x2, [sp, #584]
    4124:	f9400001 	ldr	x1, [x0]
    4128:	eb010042 	subs	x2, x2, x1
    412c:	d2800001 	mov	x1, #0x0                   	// #0
    4130:	54005bc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4134:	f9413bf5 	ldr	x21, [sp, #624]
    4138:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    413c:	f9413ff6 	ldr	x22, [sp, #632]
    4140:	aa1403e0 	mov	x0, x20
    4144:	91348021 	add	x1, x1, #0xd20
    4148:	d2800102 	mov	x2, #0x8                   	// #8
    414c:	17ffff78 	b	3f2c <fwp_write.constprop.0+0x20c>
    4150:	aa1403e0 	mov	x0, x20
    4154:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4158:	d28000c2 	mov	x2, #0x6                   	// #6
    415c:	91360021 	add	x1, x1, #0xd80
    4160:	97fff774 	bl	1f30 <buf_put>
    4164:	d2800015 	mov	x21, #0x0                   	// #0
    4168:	f9400263 	ldr	x3, [x19]
    416c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4170:	540026a0 	b.eq	4644 <fwp_write.constprop.0+0x924>  // b.none
    4174:	f9401f82 	ldr	x2, [x28, #56]
    4178:	f90143f7 	str	x23, [sp, #640]
    417c:	f90147f8 	str	x24, [sp, #648]
    4180:	d2800857 	mov	x23, #0x42                  	// #66
    4184:	f9014bf9 	str	x25, [sp, #656]
    4188:	90000036 	adrp	x22, 8000 <fwp_main_thread+0x1a0>
    418c:	f9014ffa 	str	x26, [sp, #664]
    4190:	9135e2d6 	add	x22, x22, #0xd78
    4194:	d2800038 	mov	x24, #0x1                   	// #1
    4198:	f2a18017 	movk	x23, #0xc00, lsl #16
    419c:	d2809099 	mov	x25, #0x484                 	// #1156
    41a0:	b4000482 	cbz	x2, 4230 <fwp_write.constprop.0+0x510>
    41a4:	b9400040 	ldr	w0, [x2]
    41a8:	7100701f 	cmp	w0, #0x1c
    41ac:	540042e0 	b.eq	4a08 <fwp_write.constprop.0+0xce8>  // b.none
    41b0:	71006c1f 	cmp	w0, #0x1b
    41b4:	540003e8 	b.hi	4230 <fwp_write.constprop.0+0x510>  // b.pmore
    41b8:	9ac02301 	lsl	x1, x24, x0
    41bc:	ea17003f 	tst	x1, x23
    41c0:	54003f21 	b.ne	49a4 <fwp_write.constprop.0+0xc84>  // b.any
    41c4:	ea19003f 	tst	x1, x25
    41c8:	54003da1 	b.ne	497c <fwp_write.constprop.0+0xc5c>  // b.any
    41cc:	d2800425 	mov	x5, #0x21                  	// #33
    41d0:	ea05003f 	tst	x1, x5
    41d4:	540002e0 	b.eq	4230 <fwp_write.constprop.0+0x510>  // b.none
    41d8:	b7f84743 	tbnz	x3, #63, 4ac0 <fwp_write.constprop.0+0xda0>
    41dc:	91002261 	add	x1, x19, #0x8
    41e0:	8b150021 	add	x1, x1, x21
    41e4:	39400021 	ldrb	w1, [x1]
    41e8:	7100001f 	cmp	w0, #0x0
    41ec:	93401c23 	sxtb	x3, w1
    41f0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    41f4:	d503201f 	nop
    41f8:	aa1403e0 	mov	x0, x20
    41fc:	97fffec9 	bl	3d20 <fwp_write.constprop.0>
    4200:	f9400260 	ldr	x0, [x19]
    4204:	910006b5 	add	x21, x21, #0x1
    4208:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    420c:	eb0002bf 	cmp	x21, x0
    4210:	54002122 	b.cs	4634 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4214:	d2800042 	mov	x2, #0x2                   	// #2
    4218:	aa1603e1 	mov	x1, x22
    421c:	aa1403e0 	mov	x0, x20
    4220:	97fff744 	bl	1f30 <buf_put>
    4224:	f9401f82 	ldr	x2, [x28, #56]
    4228:	f9400263 	ldr	x3, [x19]
    422c:	b5fffbc2 	cbnz	x2, 41a4 <fwp_write.constprop.0+0x484>
    4230:	d37df2a0 	lsl	x0, x21, #3
    4234:	b7f83f43 	tbnz	x3, #63, 4a1c <fwp_write.constprop.0+0xcfc>
    4238:	91002261 	add	x1, x19, #0x8
    423c:	8b000020 	add	x0, x1, x0
    4240:	f9400001 	ldr	x1, [x0]
    4244:	17ffffed 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4248:	a9400e62 	ldp	x2, x3, [x19]
    424c:	b7f83ce3 	tbnz	x3, #63, 49e8 <fwp_write.constprop.0+0xcc8>
    4250:	910123f5 	add	x21, sp, #0x48
    4254:	aa1503e0 	mov	x0, x21
    4258:	97fff5e2 	bl	19e0 <fwp_fmt_u128>
    425c:	aa1503e0 	mov	x0, x21
    4260:	97fff434 	bl	1330 <strlen@plt>
    4264:	aa1503e1 	mov	x1, x21
    4268:	aa0003e2 	mov	x2, x0
    426c:	17fffed3 	b	3db8 <fwp_write.constprop.0+0x98>
    4270:	fd015be8 	str	d8, [sp, #688]
    4274:	1e270268 	fmov	s8, w19
    4278:	fd015fe9 	str	d9, [sp, #696]
    427c:	1e282100 	fcmp	s8, s8
    4280:	54004a66 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    4284:	1e20c101 	fabs	s1, s8
    4288:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    428c:	1e270000 	fmov	s0, w0
    4290:	1e202020 	fcmp	s1, s0
    4294:	540034ad 	b.le	4928 <fwp_write.constprop.0+0xc08>
    4298:	1e202118 	fcmpe	s8, #0.0
    429c:	90000022 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    42a0:	912b8042 	add	x2, x2, #0xae0
    42a4:	910123f5 	add	x21, sp, #0x48
    42a8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    42ac:	91334021 	add	x1, x1, #0xcd0
    42b0:	aa1503e0 	mov	x0, x21
    42b4:	9a81c041 	csel	x1, x2, x1, gt
    42b8:	97fff4ca 	bl	15e0 <strcpy@plt>
    42bc:	d503201f 	nop
    42c0:	aa1503e0 	mov	x0, x21
    42c4:	97fff41b 	bl	1330 <strlen@plt>
    42c8:	aa1503e1 	mov	x1, x21
    42cc:	aa0003e2 	mov	x2, x0
    42d0:	aa1403e0 	mov	x0, x20
    42d4:	97fff717 	bl	1f30 <buf_put>
    42d8:	f9413bf5 	ldr	x21, [sp, #624]
    42dc:	f9413ff6 	ldr	x22, [sp, #632]
    42e0:	f94153fb 	ldr	x27, [sp, #672]
    42e4:	f94157fc 	ldr	x28, [sp, #680]
    42e8:	fd415be8 	ldr	d8, [sp, #688]
    42ec:	fd415fe9 	ldr	d9, [sp, #696]
    42f0:	17fffeb8 	b	3dd0 <fwp_write.constprop.0+0xb0>
    42f4:	f90143f7 	str	x23, [sp, #640]
    42f8:	52800443 	mov	w3, #0x22                  	// #34
    42fc:	f90147f8 	str	x24, [sp, #648]
    4300:	91001ff5 	add	x21, sp, #0x7
    4304:	aa1503e1 	mov	x1, x21
    4308:	aa1403e0 	mov	x0, x20
    430c:	f8408677 	ldr	x23, [x19], #8
    4310:	d2800022 	mov	x2, #0x1                   	// #1
    4314:	39001fe3 	strb	w3, [sp, #7]
    4318:	97fff706 	bl	1f30 <buf_put>
    431c:	8b1302f6 	add	x22, x23, x19
    4320:	b4002657 	cbz	x23, 47e8 <fwp_write.constprop.0+0xac8>
    4324:	90000038 	adrp	x24, 8000 <fwp_main_thread+0x1a0>
    4328:	9134e318 	add	x24, x24, #0xd38
    432c:	f9014bf9 	str	x25, [sp, #656]
    4330:	90000039 	adrp	x25, 8000 <fwp_main_thread+0x1a0>
    4334:	91356339 	add	x25, x25, #0xd58
    4338:	f9014ffa 	str	x26, [sp, #664]
    433c:	1400000e 	b	4374 <fwp_write.constprop.0+0x654>
    4340:	710024bf 	cmp	w5, #0x9
    4344:	54002380 	b.eq	47b4 <fwp_write.constprop.0+0xa94>  // b.none
    4348:	710028bf 	cmp	w5, #0xa
    434c:	54002be1 	b.ne	48c8 <fwp_write.constprop.0+0xba8>  // b.any
    4350:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4354:	aa1403e0 	mov	x0, x20
    4358:	91352021 	add	x1, x1, #0xd48
    435c:	d2800042 	mov	x2, #0x2                   	// #2
    4360:	97fff6f4 	bl	1f30 <buf_put>
    4364:	d503201f 	nop
    4368:	91000673 	add	x19, x19, #0x1
    436c:	eb16027f 	cmp	x19, x22
    4370:	54002380 	b.eq	47e0 <fwp_write.constprop.0+0xac0>  // b.none
    4374:	39400265 	ldrb	w5, [x19]
    4378:	710034bf 	cmp	w5, #0xd
    437c:	54002120 	b.eq	47a0 <fwp_write.constprop.0+0xa80>  // b.none
    4380:	54fffe09 	b.ls	4340 <fwp_write.constprop.0+0x620>  // b.plast
    4384:	710088bf 	cmp	w5, #0x22
    4388:	54002220 	b.eq	47cc <fwp_write.constprop.0+0xaac>  // b.none
    438c:	710170bf 	cmp	w5, #0x5c
    4390:	54002ba1 	b.ne	4904 <fwp_write.constprop.0+0xbe4>  // b.any
    4394:	aa1403e0 	mov	x0, x20
    4398:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    439c:	d2800042 	mov	x2, #0x2                   	// #2
    43a0:	91350021 	add	x1, x1, #0xd40
    43a4:	97fff6e3 	bl	1f30 <buf_put>
    43a8:	17fffff0 	b	4368 <fwp_write.constprop.0+0x648>
    43ac:	fd015be8 	str	d8, [sp, #688]
    43b0:	9e670268 	fmov	d8, x19
    43b4:	fd015fe9 	str	d9, [sp, #696]
    43b8:	1e682100 	fcmp	d8, d8
    43bc:	54004086 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    43c0:	1e60c101 	fabs	d1, d8
    43c4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    43c8:	9e670000 	fmov	d0, x0
    43cc:	910123f5 	add	x21, sp, #0x48
    43d0:	52800033 	mov	w19, #0x1                   	// #1
    43d4:	1e602020 	fcmp	d1, d0
    43d8:	540001ad 	b.le	440c <fwp_write.constprop.0+0x6ec>
    43dc:	1e602118 	fcmpe	d8, #0.0
    43e0:	90000022 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    43e4:	912b8042 	add	x2, x2, #0xae0
    43e8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    43ec:	91334021 	add	x1, x1, #0xcd0
    43f0:	aa1503e0 	mov	x0, x21
    43f4:	9a81c041 	csel	x1, x2, x1, gt
    43f8:	97fff47a 	bl	15e0 <strcpy@plt>
    43fc:	17ffffb1 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4400:	11000673 	add	w19, w19, #0x1
    4404:	71004a7f 	cmp	w19, #0x12
    4408:	540031a0 	b.eq	4a3c <fwp_write.constprop.0+0xd1c>  // b.none
    440c:	1e604100 	fmov	d0, d8
    4410:	2a1303e1 	mov	w1, w19
    4414:	aa1503e0 	mov	x0, x21
    4418:	97fff75a 	bl	2180 <fwp_format_g.constprop.0>
    441c:	aa1503e0 	mov	x0, x21
    4420:	d2800001 	mov	x1, #0x0                   	// #0
    4424:	97fff3d7 	bl	1380 <strtod@plt>
    4428:	1e602100 	fcmp	d8, d0
    442c:	54fffea1 	b.ne	4400 <fwp_write.constprop.0+0x6e0>  // b.any
    4430:	aa1503e0 	mov	x0, x21
    4434:	97fff6f8 	bl	2014 <fwp_finish_float>
    4438:	17ffffa2 	b	42c0 <fwp_write.constprop.0+0x5a0>
    443c:	a9400e62 	ldp	x2, x3, [x19]
    4440:	910123f3 	add	x19, sp, #0x48
    4444:	aa1303e0 	mov	x0, x19
    4448:	97fff566 	bl	19e0 <fwp_fmt_u128>
    444c:	17fffe57 	b	3da8 <fwp_write.constprop.0+0x88>
    4450:	f90143f7 	str	x23, [sp, #640]
    4454:	f90147f8 	str	x24, [sp, #648]
    4458:	2a1303f8 	mov	w24, w19
    445c:	f9014bf9 	str	x25, [sp, #656]
    4460:	f9014ffa 	str	x26, [sp, #664]
    4464:	f13ffe7f 	cmp	x19, #0xfff
    4468:	54000049 	b.ls	4470 <fwp_write.constprop.0+0x750>  // b.plast
    446c:	b9400278 	ldr	w24, [x19]
    4470:	f9400f80 	ldr	x0, [x28, #24]
    4474:	2a1803f5 	mov	w21, w24
    4478:	d37d7f18 	ubfiz	x24, x24, #3, #32
    447c:	d37ef6b9 	lsl	x25, x21, #2
    4480:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4484:	aa1603e0 	mov	x0, x22
    4488:	97fff3aa 	bl	1330 <strlen@plt>
    448c:	aa1603e1 	mov	x1, x22
    4490:	aa0003e2 	mov	x2, x0
    4494:	aa1403e0 	mov	x0, x20
    4498:	97fff6a6 	bl	1f30 <buf_put>
    449c:	f9401780 	ldr	x0, [x28, #40]
    44a0:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    44a4:	7100001f 	cmp	w0, #0x0
    44a8:	5400064d 	b.le	4570 <fwp_write.constprop.0+0x850>
    44ac:	91002276 	add	x22, x19, #0x8
    44b0:	91001ff5 	add	x21, sp, #0x7
    44b4:	d280001b 	mov	x27, #0x0                   	// #0
    44b8:	5280041a 	mov	w26, #0x20                  	// #32
    44bc:	f9401b80 	ldr	x0, [x28, #48]
    44c0:	aa1503e1 	mov	x1, x21
    44c4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    44c8:	d2800022 	mov	x2, #0x1                   	// #1
    44cc:	f8786805 	ldr	x5, [x0, x24]
    44d0:	aa1403e0 	mov	x0, x20
    44d4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    44d8:	39001ffa 	strb	w26, [sp, #7]
    44dc:	97fff695 	bl	1f30 <buf_put>
    44e0:	f13ffeff 	cmp	x23, #0xfff
    44e4:	b9400261 	ldr	w1, [x19]
    44e8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    44ec:	7100383f 	cmp	w1, #0xe
    44f0:	54000140 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    44f4:	7100403f 	cmp	w1, #0x10
    44f8:	54001c20 	b.eq	487c <fwp_write.constprop.0+0xb5c>  // b.none
    44fc:	7100283f 	cmp	w1, #0xa
    4500:	540026e0 	b.eq	49dc <fwp_write.constprop.0+0xcbc>  // b.none
    4504:	540013cc 	b.gt	477c <fwp_write.constprop.0+0xa5c>
    4508:	71000c3f 	cmp	w1, #0x3
    450c:	540025ec 	b.gt	49c8 <fwp_write.constprop.0+0xca8>
    4510:	d37ffee0 	lsr	x0, x23, #63
    4514:	37f813c1 	tbnz	w1, #31, 478c <fwp_write.constprop.0+0xa6c>
    4518:	340013a0 	cbz	w0, 478c <fwp_write.constprop.0+0xa6c>
    451c:	52800503 	mov	w3, #0x28                  	// #40
    4520:	aa1503e1 	mov	x1, x21
    4524:	aa1403e0 	mov	x0, x20
    4528:	d2800022 	mov	x2, #0x1                   	// #1
    452c:	39001fe3 	strb	w3, [sp, #7]
    4530:	97fff680 	bl	1f30 <buf_put>
    4534:	aa1303e2 	mov	x2, x19
    4538:	aa1703e1 	mov	x1, x23
    453c:	aa1403e0 	mov	x0, x20
    4540:	97fffdf8 	bl	3d20 <fwp_write.constprop.0>
    4544:	52800523 	mov	w3, #0x29                  	// #41
    4548:	aa1503e1 	mov	x1, x21
    454c:	aa1403e0 	mov	x0, x20
    4550:	d2800022 	mov	x2, #0x1                   	// #1
    4554:	39001fe3 	strb	w3, [sp, #7]
    4558:	97fff676 	bl	1f30 <buf_put>
    455c:	f9401780 	ldr	x0, [x28, #40]
    4560:	9100077b 	add	x27, x27, #0x1
    4564:	b8796800 	ldr	w0, [x0, x25]
    4568:	6b1b001f 	cmp	w0, w27
    456c:	54fffa8c 	b.gt	44bc <fwp_write.constprop.0+0x79c>
    4570:	f9413bf5 	ldr	x21, [sp, #624]
    4574:	f9413ff6 	ldr	x22, [sp, #632]
    4578:	f94143f7 	ldr	x23, [sp, #640]
    457c:	f94147f8 	ldr	x24, [sp, #648]
    4580:	f9414bf9 	ldr	x25, [sp, #656]
    4584:	f9414ffa 	ldr	x26, [sp, #664]
    4588:	f94153fb 	ldr	x27, [sp, #672]
    458c:	f94157fc 	ldr	x28, [sp, #680]
    4590:	17fffe10 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4594:	aa1403e0 	mov	x0, x20
    4598:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    459c:	d28000c2 	mov	x2, #0x6                   	// #6
    45a0:	9135a021 	add	x1, x1, #0xd68
    45a4:	97fff663 	bl	1f30 <buf_put>
    45a8:	f9400260 	ldr	x0, [x19]
    45ac:	b40004c0 	cbz	x0, 4644 <fwp_write.constprop.0+0x924>
    45b0:	910123f5 	add	x21, sp, #0x48
    45b4:	91002276 	add	x22, x19, #0x8
    45b8:	f90143f7 	str	x23, [sp, #640]
    45bc:	d2800017 	mov	x23, #0x0                   	// #0
    45c0:	f90147f8 	str	x24, [sp, #648]
    45c4:	90000038 	adrp	x24, 8000 <fwp_main_thread+0x1a0>
    45c8:	9135c318 	add	x24, x24, #0xd70
    45cc:	f9014bf9 	str	x25, [sp, #656]
    45d0:	90000039 	adrp	x25, 8000 <fwp_main_thread+0x1a0>
    45d4:	9135e339 	add	x25, x25, #0xd78
    45d8:	f9014ffa 	str	x26, [sp, #664]
    45dc:	14000005 	b	45f0 <fwp_write.constprop.0+0x8d0>
    45e0:	aa1903e1 	mov	x1, x25
    45e4:	aa1403e0 	mov	x0, x20
    45e8:	d2800042 	mov	x2, #0x2                   	// #2
    45ec:	97fff651 	bl	1f30 <buf_put>
    45f0:	38776ac5 	ldrb	w5, [x22, x23]
    45f4:	d2804003 	mov	x3, #0x200                 	// #512
    45f8:	aa1803e4 	mov	x4, x24
    45fc:	aa0303e1 	mov	x1, x3
    4600:	52800042 	mov	w2, #0x2                   	// #2
    4604:	aa1503e0 	mov	x0, x21
    4608:	910006f7 	add	x23, x23, #0x1
    460c:	97fff381 	bl	1410 <__snprintf_chk@plt>
    4610:	aa1503e0 	mov	x0, x21
    4614:	97fff347 	bl	1330 <strlen@plt>
    4618:	aa1503e1 	mov	x1, x21
    461c:	aa0003e2 	mov	x2, x0
    4620:	aa1403e0 	mov	x0, x20
    4624:	97fff643 	bl	1f30 <buf_put>
    4628:	f9400260 	ldr	x0, [x19]
    462c:	eb0002ff 	cmp	x23, x0
    4630:	54fffd83 	b.cc	45e0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4634:	f94143f7 	ldr	x23, [sp, #640]
    4638:	f94147f8 	ldr	x24, [sp, #648]
    463c:	f9414bf9 	ldr	x25, [sp, #656]
    4640:	f9414ffa 	ldr	x26, [sp, #664]
    4644:	52800ba3 	mov	w3, #0x5d                  	// #93
    4648:	aa1403e0 	mov	x0, x20
    464c:	91001fe1 	add	x1, sp, #0x7
    4650:	d2800022 	mov	x2, #0x1                   	// #1
    4654:	39001fe3 	strb	w3, [sp, #7]
    4658:	17fffdd9 	b	3dbc <fwp_write.constprop.0+0x9c>
    465c:	52800b63 	mov	w3, #0x5b                  	// #91
    4660:	91001ff5 	add	x21, sp, #0x7
    4664:	aa1503e1 	mov	x1, x21
    4668:	aa1403e0 	mov	x0, x20
    466c:	d2800022 	mov	x2, #0x1                   	// #1
    4670:	90000036 	adrp	x22, 8000 <fwp_main_thread+0x1a0>
    4674:	9135e2d6 	add	x22, x22, #0xd78
    4678:	39001fe3 	strb	w3, [sp, #7]
    467c:	97fff62d 	bl	1f30 <buf_put>
    4680:	b4000233 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    4684:	f9400661 	ldr	x1, [x19, #8]
    4688:	aa1403e0 	mov	x0, x20
    468c:	f9401f82 	ldr	x2, [x28, #56]
    4690:	97fffda4 	bl	3d20 <fwp_write.constprop.0>
    4694:	f9400a73 	ldr	x19, [x19, #16]
    4698:	b4000173 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    469c:	aa1603e1 	mov	x1, x22
    46a0:	aa1403e0 	mov	x0, x20
    46a4:	d2800042 	mov	x2, #0x2                   	// #2
    46a8:	97fff622 	bl	1f30 <buf_put>
    46ac:	f9400661 	ldr	x1, [x19, #8]
    46b0:	aa1403e0 	mov	x0, x20
    46b4:	f9401f82 	ldr	x2, [x28, #56]
    46b8:	97fffd9a 	bl	3d20 <fwp_write.constprop.0>
    46bc:	f9400a73 	ldr	x19, [x19, #16]
    46c0:	b5fffef3 	cbnz	x19, 469c <fwp_write.constprop.0+0x97c>
    46c4:	52800ba3 	mov	w3, #0x5d                  	// #93
    46c8:	aa1503e1 	mov	x1, x21
    46cc:	aa1403e0 	mov	x0, x20
    46d0:	d2800022 	mov	x2, #0x1                   	// #1
    46d4:	39001fe3 	strb	w3, [sp, #7]
    46d8:	17fffdb9 	b	3dbc <fwp_write.constprop.0+0x9c>
    46dc:	52800783 	mov	w3, #0x3c                  	// #60
    46e0:	91001ff3 	add	x19, sp, #0x7
    46e4:	aa1303e1 	mov	x1, x19
    46e8:	d2800022 	mov	x2, #0x1                   	// #1
    46ec:	aa1403e0 	mov	x0, x20
    46f0:	39001fe3 	strb	w3, [sp, #7]
    46f4:	97fff60f 	bl	1f30 <buf_put>
    46f8:	f9400795 	ldr	x21, [x28, #8]
    46fc:	aa1503e0 	mov	x0, x21
    4700:	97fff30c 	bl	1330 <strlen@plt>
    4704:	aa1503e1 	mov	x1, x21
    4708:	aa0003e2 	mov	x2, x0
    470c:	aa1403e0 	mov	x0, x20
    4710:	97fff608 	bl	1f30 <buf_put>
    4714:	528007c3 	mov	w3, #0x3e                  	// #62
    4718:	aa1303e1 	mov	x1, x19
    471c:	aa1403e0 	mov	x0, x20
    4720:	d2800022 	mov	x2, #0x1                   	// #1
    4724:	39001fe3 	strb	w3, [sp, #7]
    4728:	17fffda5 	b	3dbc <fwp_write.constprop.0+0x9c>
    472c:	f100067f 	cmp	x19, #0x1
    4730:	540017e0 	b.eq	4a2c <fwp_write.constprop.0+0xd0c>  // b.none
    4734:	b100067f 	cmn	x19, #0x1
    4738:	54001b00 	b.eq	4a98 <fwp_write.constprop.0+0xd78>  // b.none
    473c:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4740:	9133a021 	add	x1, x1, #0xce8
    4744:	d2800022 	mov	x2, #0x1                   	// #1
    4748:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    474c:	f947f400 	ldr	x0, [x0, #4072]
    4750:	f94127e4 	ldr	x4, [sp, #584]
    4754:	f9400003 	ldr	x3, [x0]
    4758:	eb030084 	subs	x4, x4, x3
    475c:	d2800003 	mov	x3, #0x0                   	// #0
    4760:	54002a41 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4764:	f9413bf5 	ldr	x21, [sp, #624]
    4768:	aa1403e0 	mov	x0, x20
    476c:	f9413ff6 	ldr	x22, [sp, #632]
    4770:	17fffdef 	b	3f2c <fwp_write.constprop.0+0x20c>
    4774:	52800fa3 	mov	w3, #0x7d                  	// #125
    4778:	17fffe2c 	b	4028 <fwp_write.constprop.0+0x308>
    477c:	f10002ff 	cmp	x23, #0x0
    4780:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4784:	71002c3f 	cmp	w1, #0xb
    4788:	54ffec80 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    478c:	aa1303e2 	mov	x2, x19
    4790:	aa1703e1 	mov	x1, x23
    4794:	aa1403e0 	mov	x0, x20
    4798:	97fffd62 	bl	3d20 <fwp_write.constprop.0>
    479c:	17ffff70 	b	455c <fwp_write.constprop.0+0x83c>
    47a0:	aa1903e1 	mov	x1, x25
    47a4:	aa1403e0 	mov	x0, x20
    47a8:	d2800042 	mov	x2, #0x2                   	// #2
    47ac:	97fff5e1 	bl	1f30 <buf_put>
    47b0:	17fffeee 	b	4368 <fwp_write.constprop.0+0x648>
    47b4:	aa1403e0 	mov	x0, x20
    47b8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    47bc:	d2800042 	mov	x2, #0x2                   	// #2
    47c0:	91354021 	add	x1, x1, #0xd50
    47c4:	97fff5db 	bl	1f30 <buf_put>
    47c8:	17fffee8 	b	4368 <fwp_write.constprop.0+0x648>
    47cc:	aa1803e1 	mov	x1, x24
    47d0:	aa1403e0 	mov	x0, x20
    47d4:	d2800042 	mov	x2, #0x2                   	// #2
    47d8:	97fff5d6 	bl	1f30 <buf_put>
    47dc:	17fffee3 	b	4368 <fwp_write.constprop.0+0x648>
    47e0:	f9414bf9 	ldr	x25, [sp, #656]
    47e4:	f9414ffa 	ldr	x26, [sp, #664]
    47e8:	aa1503e1 	mov	x1, x21
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	52800443 	mov	w3, #0x22                  	// #34
    47f4:	17fffe0f 	b	4030 <fwp_write.constprop.0+0x310>
    47f8:	a9400281 	ldp	x1, x0, [x20]
    47fc:	91000800 	add	x0, x0, #0x2
    4800:	8b160000 	add	x0, x0, x22
    4804:	f9000680 	str	x0, [x20, #8]
    4808:	3820683f 	strb	wzr, [x1, x0]
    480c:	f9413bf5 	ldr	x21, [sp, #624]
    4810:	f9413ff6 	ldr	x22, [sp, #632]
    4814:	f94153fb 	ldr	x27, [sp, #672]
    4818:	f94157fc 	ldr	x28, [sp, #680]
    481c:	17fffd6d 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4820:	aa1403e0 	mov	x0, x20
    4824:	91001fe1 	add	x1, sp, #0x7
    4828:	52800fa3 	mov	w3, #0x7d                  	// #125
    482c:	d2800022 	mov	x2, #0x1                   	// #1
    4830:	17fffe01 	b	4034 <fwp_write.constprop.0+0x314>
    4834:	f9400f80 	ldr	x0, [x28, #24]
    4838:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    483c:	aa1b03e0 	mov	x0, x27
    4840:	97fff2bc 	bl	1330 <strlen@plt>
    4844:	aa1b03e1 	mov	x1, x27
    4848:	aa0003e2 	mov	x2, x0
    484c:	aa1403e0 	mov	x0, x20
    4850:	97fff5b8 	bl	1f30 <buf_put>
    4854:	aa1903e1 	mov	x1, x25
    4858:	aa1403e0 	mov	x0, x20
    485c:	d2800062 	mov	x2, #0x3                   	// #3
    4860:	97fff5b4 	bl	1f30 <buf_put>
    4864:	17fffde4 	b	3ff4 <fwp_write.constprop.0+0x2d4>
    4868:	aa1a03e1 	mov	x1, x26
    486c:	aa1403e0 	mov	x0, x20
    4870:	d2800042 	mov	x2, #0x2                   	// #2
    4874:	97fff5af 	bl	1f30 <buf_put>
    4878:	17fffddd 	b	3fec <fwp_write.constprop.0+0x2cc>
    487c:	f9400660 	ldr	x0, [x19, #8]
    4880:	b4fff860 	cbz	x0, 478c <fwp_write.constprop.0+0xa6c>
    4884:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4888:	91364021 	add	x1, x1, #0xd90
    488c:	97fff325 	bl	1520 <strcmp@plt>
    4890:	7100001f 	cmp	w0, #0x0
    4894:	1a9f07e0 	cset	w0, ne	// ne = any
    4898:	17ffff20 	b	4518 <fwp_write.constprop.0+0x7f8>
    489c:	aa1403e0 	mov	x0, x20
    48a0:	d2800042 	mov	x2, #0x2                   	// #2
    48a4:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    48a8:	91362021 	add	x1, x1, #0xd88
    48ac:	97fff5a1 	bl	1f30 <buf_put>
    48b0:	91004261 	add	x1, x19, #0x10
    48b4:	aa1403e0 	mov	x0, x20
    48b8:	f9402382 	ldr	x2, [x28, #64]
    48bc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    48c0:	97fffd18 	bl	3d20 <fwp_write.constprop.0>
    48c4:	17fffd71 	b	3e88 <fwp_write.constprop.0+0x168>
    48c8:	d2800203 	mov	x3, #0x10                  	// #16
    48cc:	90000024 	adrp	x4, 8000 <fwp_main_thread+0x1a0>
    48d0:	aa0303e1 	mov	x1, x3
    48d4:	91358084 	add	x4, x4, #0xd60
    48d8:	910123f7 	add	x23, sp, #0x48
    48dc:	52800042 	mov	w2, #0x2                   	// #2
    48e0:	aa1703e0 	mov	x0, x23
    48e4:	97fff2cb 	bl	1410 <__snprintf_chk@plt>
    48e8:	aa1703e0 	mov	x0, x23
    48ec:	97fff291 	bl	1330 <strlen@plt>
    48f0:	aa1703e1 	mov	x1, x23
    48f4:	aa0003e2 	mov	x2, x0
    48f8:	aa1403e0 	mov	x0, x20
    48fc:	97fff58d 	bl	1f30 <buf_put>
    4900:	17fffe9a 	b	4368 <fwp_write.constprop.0+0x648>
    4904:	7101fcbf 	cmp	w5, #0x7f
    4908:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    490c:	54fffde9 	b.ls	48c8 <fwp_write.constprop.0+0xba8>  // b.plast
    4910:	aa1503e1 	mov	x1, x21
    4914:	aa1403e0 	mov	x0, x20
    4918:	d2800022 	mov	x2, #0x1                   	// #1
    491c:	39001fe5 	strb	w5, [sp, #7]
    4920:	97fff584 	bl	1f30 <buf_put>
    4924:	17fffe91 	b	4368 <fwp_write.constprop.0+0x648>
    4928:	1e22c109 	fcvt	d9, s8
    492c:	910123f5 	add	x21, sp, #0x48
    4930:	52800033 	mov	w19, #0x1                   	// #1
    4934:	d503201f 	nop
    4938:	1e604120 	fmov	d0, d9
    493c:	2a1303e1 	mov	w1, w19
    4940:	aa1503e0 	mov	x0, x21
    4944:	97fff60f 	bl	2180 <fwp_format_g.constprop.0>
    4948:	aa1503e0 	mov	x0, x21
    494c:	d2800001 	mov	x1, #0x0                   	// #0
    4950:	97fff300 	bl	1550 <strtof@plt>
    4954:	1e202100 	fcmp	s8, s0
    4958:	54ffd6c0 	b.eq	4430 <fwp_write.constprop.0+0x710>  // b.none
    495c:	11000673 	add	w19, w19, #0x1
    4960:	71002a7f 	cmp	w19, #0xa
    4964:	54fffea1 	b.ne	4938 <fwp_write.constprop.0+0xc18>  // b.any
    4968:	1e604120 	fmov	d0, d9
    496c:	aa1503e0 	mov	x0, x21
    4970:	52800121 	mov	w1, #0x9                   	// #9
    4974:	97fff603 	bl	2180 <fwp_format_g.constprop.0>
    4978:	17fffeae 	b	4430 <fwp_write.constprop.0+0x710>
    497c:	d37ef6a1 	lsl	x1, x21, #2
    4980:	b7f809a3 	tbnz	x3, #63, 4ab4 <fwp_write.constprop.0+0xd94>
    4984:	91002263 	add	x3, x19, #0x8
    4988:	8b010061 	add	x1, x3, x1
    498c:	b9400023 	ldr	w3, [x1]
    4990:	7100081f 	cmp	w0, #0x2
    4994:	2a0303e1 	mov	w1, w3
    4998:	93407c63 	sxtw	x3, w3
    499c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49a0:	17fffe16 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49a4:	d37ffaa1 	lsl	x1, x21, #1
    49a8:	b7f80803 	tbnz	x3, #63, 4aa8 <fwp_write.constprop.0+0xd88>
    49ac:	91002263 	add	x3, x19, #0x8
    49b0:	8b010061 	add	x1, x3, x1
    49b4:	79400021 	ldrh	w1, [x1]
    49b8:	7100041f 	cmp	w0, #0x1
    49bc:	93403c23 	sxth	x3, w1
    49c0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49c4:	17fffe0d 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49c8:	7100103f 	cmp	w1, #0x4
    49cc:	54ffee01 	b.ne	478c <fwp_write.constprop.0+0xa6c>  // b.any
    49d0:	f94006e0 	ldr	x0, [x23, #8]
    49d4:	d37ffc00 	lsr	x0, x0, #63
    49d8:	17fffed0 	b	4518 <fwp_write.constprop.0+0x7f8>
    49dc:	710002ff 	cmp	w23, #0x0
    49e0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    49e4:	17fffecd 	b	4518 <fwp_write.constprop.0+0x7f8>
    49e8:	528005a1 	mov	w1, #0x2d                  	// #45
    49ec:	eb0203e2 	negs	x2, x2
    49f0:	da0303e3 	ngc	x3, x3
    49f4:	910127e0 	add	x0, sp, #0x49
    49f8:	910123f5 	add	x21, sp, #0x48
    49fc:	390123e1 	strb	w1, [sp, #72]
    4a00:	97fff3f8 	bl	19e0 <fwp_fmt_u128>
    4a04:	17fffe16 	b	425c <fwp_write.constprop.0+0x53c>
    4a08:	d37ceea1 	lsl	x1, x21, #4
    4a0c:	b7f80da3 	tbnz	x3, #63, 4bc0 <fwp_write.constprop.0+0xea0>
    4a10:	91002260 	add	x0, x19, #0x8
    4a14:	8b010001 	add	x1, x0, x1
    4a18:	17fffdf8 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a1c:	f9400a61 	ldr	x1, [x19, #16]
    4a20:	8b010000 	add	x0, x0, x1
    4a24:	f9400001 	ldr	x1, [x0]
    4a28:	17fffdf4 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a2c:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4a30:	d2800042 	mov	x2, #0x2                   	// #2
    4a34:	91336021 	add	x1, x1, #0xcd8
    4a38:	17ffff44 	b	4748 <fwp_write.constprop.0+0xa28>
    4a3c:	1e604100 	fmov	d0, d8
    4a40:	aa1503e0 	mov	x0, x21
    4a44:	52800221 	mov	w1, #0x11                  	// #17
    4a48:	97fff5ce 	bl	2180 <fwp_format_g.constprop.0>
    4a4c:	17fffe79 	b	4430 <fwp_write.constprop.0+0x710>
    4a50:	b9401380 	ldr	w0, [x28, #16]
    4a54:	350003c0 	cbnz	w0, 4acc <fwp_write.constprop.0+0xdac>
    4a58:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    4a5c:	f947f400 	ldr	x0, [x0, #4072]
    4a60:	f94127e2 	ldr	x2, [sp, #584]
    4a64:	f9400001 	ldr	x1, [x0]
    4a68:	eb010042 	subs	x2, x2, x1
    4a6c:	d2800001 	mov	x1, #0x0                   	// #0
    4a70:	54001201 	b.ne	4cb0 <fwp_write.constprop.0+0xf90>  // b.any
    4a74:	f9413bf5 	ldr	x21, [sp, #624]
    4a78:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4a7c:	f9413ff6 	ldr	x22, [sp, #632]
    4a80:	aa1403e0 	mov	x0, x20
    4a84:	f94143f7 	ldr	x23, [sp, #640]
    4a88:	9136c021 	add	x1, x1, #0xdb0
    4a8c:	f94147f8 	ldr	x24, [sp, #648]
    4a90:	d2800042 	mov	x2, #0x2                   	// #2
    4a94:	17fffd26 	b	3f2c <fwp_write.constprop.0+0x20c>
    4a98:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x1a0>
    4a9c:	d2800042 	mov	x2, #0x2                   	// #2
    4aa0:	91338021 	add	x1, x1, #0xce0
    4aa4:	17ffff29 	b	4748 <fwp_write.constprop.0+0xa28>
    4aa8:	f9400a63 	ldr	x3, [x19, #16]
    4aac:	8b030021 	add	x1, x1, x3
    4ab0:	17ffffc1 	b	49b4 <fwp_write.constprop.0+0xc94>
    4ab4:	f9400a63 	ldr	x3, [x19, #16]
    4ab8:	8b030021 	add	x1, x1, x3
    4abc:	17ffffb4 	b	498c <fwp_write.constprop.0+0xc6c>
    4ac0:	f9400a61 	ldr	x1, [x19, #16]
    4ac4:	8b0102a1 	add	x1, x21, x1
    4ac8:	17fffdc7 	b	41e4 <fwp_write.constprop.0+0x4c4>
    4acc:	b9404b80 	ldr	w0, [x28, #72]
    4ad0:	91001ff5 	add	x21, sp, #0x7
    4ad4:	34ffa660 	cbz	w0, 3fa0 <fwp_write.constprop.0+0x280>
    4ad8:	52800503 	mov	w3, #0x28                  	// #40
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	aa1503e1 	mov	x1, x21
    4ae4:	d2800022 	mov	x2, #0x1                   	// #1
    4ae8:	39001fe3 	strb	w3, [sp, #7]
    4aec:	97fff511 	bl	1f30 <buf_put>
    4af0:	b9401380 	ldr	w0, [x28, #16]
    4af4:	52800038 	mov	w24, #0x1                   	// #1
    4af8:	7100001f 	cmp	w0, #0x0
    4afc:	54ffa66c 	b.gt	3fc8 <fwp_write.constprop.0+0x2a8>
    4b00:	17fffd49 	b	4024 <fwp_write.constprop.0+0x304>
    4b04:	f9014bf9 	str	x25, [sp, #656]
    4b08:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x152d8>
    4b0c:	f9014ffa 	str	x26, [sp, #664]
    4b10:	f9400676 	ldr	x22, [x19, #8]
    4b14:	912ca333 	add	x19, x25, #0xb28
    4b18:	91002273 	add	x19, x19, #0x8
    4b1c:	937ffed8 	asr	x24, x22, #63
    4b20:	aa1802c0 	orr	x0, x22, x24
    4b24:	b5000320 	cbnz	x0, 4b88 <fwp_write.constprop.0+0xe68>
    4b28:	110006b5 	add	w21, w21, #0x1
    4b2c:	710016bf 	cmp	w21, #0x5
    4b30:	54ffffc1 	b.ne	4b28 <fwp_write.constprop.0+0xe08>  // b.any
    4b34:	b7f80578 	tbnz	x24, #63, 4be0 <fwp_write.constprop.0+0xec0>
    4b38:	910023f3 	add	x19, sp, #0x8
    4b3c:	aa1603e2 	mov	x2, x22
    4b40:	aa1303e0 	mov	x0, x19
    4b44:	d2800003 	mov	x3, #0x0                   	// #0
    4b48:	97fff3a6 	bl	19e0 <fwp_fmt_u128>
    4b4c:	910123f5 	add	x21, sp, #0x48
    4b50:	90000023 	adrp	x3, 8000 <fwp_main_thread+0x1a0>
    4b54:	aa1303e4 	mov	x4, x19
    4b58:	aa1503e0 	mov	x0, x21
    4b5c:	9136a063 	add	x3, x3, #0xda8
    4b60:	d2804002 	mov	x2, #0x200                 	// #512
    4b64:	52800041 	mov	w1, #0x2                   	// #2
    4b68:	97fff1f6 	bl	1340 <__sprintf_chk@plt>
    4b6c:	aa1503e0 	mov	x0, x21
    4b70:	97fff1f0 	bl	1330 <strlen@plt>
    4b74:	aa1503e1 	mov	x1, x21
    4b78:	aa0003e2 	mov	x2, x0
    4b7c:	aa1403e0 	mov	x0, x20
    4b80:	97fff4ec 	bl	1f30 <buf_put>
    4b84:	17fffe7b 	b	4570 <fwp_write.constprop.0+0x850>
    4b88:	f9400277 	ldr	x23, [x19]
    4b8c:	aa1603e0 	mov	x0, x22
    4b90:	aa1803e1 	mov	x1, x24
    4b94:	aa1703e2 	mov	x2, x23
    4b98:	937ffefa 	asr	x26, x23, #63
    4b9c:	aa1a03e3 	mov	x3, x26
    4ba0:	94000ee0 	bl	8720 <__modti3>
    4ba4:	aa010000 	orr	x0, x0, x1
    4ba8:	b40002c0 	cbz	x0, 4c00 <fwp_write.constprop.0+0xee0>
    4bac:	110006b5 	add	w21, w21, #0x1
    4bb0:	91004273 	add	x19, x19, #0x10
    4bb4:	710016bf 	cmp	w21, #0x5
    4bb8:	54fffe81 	b.ne	4b88 <fwp_write.constprop.0+0xe68>  // b.any
    4bbc:	17ffffde 	b	4b34 <fwp_write.constprop.0+0xe14>
    4bc0:	f9400a60 	ldr	x0, [x19, #16]
    4bc4:	8b000021 	add	x1, x1, x0
    4bc8:	17fffd8c 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4bcc:	528c29c0 	mov	w0, #0x614e                	// #24910
    4bd0:	910123f5 	add	x21, sp, #0x48
    4bd4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4bd8:	b9004be0 	str	w0, [sp, #72]
    4bdc:	17fffdb9 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4be0:	528005a1 	mov	w1, #0x2d                  	// #45
    4be4:	eb1603e2 	negs	x2, x22
    4be8:	da1803e3 	ngc	x3, x24
    4bec:	910027e0 	add	x0, sp, #0x9
    4bf0:	910023f3 	add	x19, sp, #0x8
    4bf4:	390023e1 	strb	w1, [sp, #8]
    4bf8:	97fff37a 	bl	19e0 <fwp_fmt_u128>
    4bfc:	17ffffd4 	b	4b4c <fwp_write.constprop.0+0xe2c>
    4c00:	aa1703e2 	mov	x2, x23
    4c04:	aa1a03e3 	mov	x3, x26
    4c08:	aa1603e0 	mov	x0, x22
    4c0c:	aa1803e1 	mov	x1, x24
    4c10:	94000de4 	bl	83a0 <__divti3>
    4c14:	aa0003e2 	mov	x2, x0
    4c18:	aa0103e3 	mov	x3, x1
    4c1c:	b7f80201 	tbnz	x1, #63, 4c5c <fwp_write.constprop.0+0xf3c>
    4c20:	910023f3 	add	x19, sp, #0x8
    4c24:	aa1303e0 	mov	x0, x19
    4c28:	97fff36e 	bl	19e0 <fwp_fmt_u128>
    4c2c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4c30:	912ca339 	add	x25, x25, #0xb28
    4c34:	910123f5 	add	x21, sp, #0x48
    4c38:	aa1303e4 	mov	x4, x19
    4c3c:	aa1503e0 	mov	x0, x21
    4c40:	90000023 	adrp	x3, 8000 <fwp_main_thread+0x1a0>
    4c44:	f8616b25 	ldr	x5, [x25, x1]
    4c48:	91368063 	add	x3, x3, #0xda0
    4c4c:	d2804002 	mov	x2, #0x200                 	// #512
    4c50:	52800041 	mov	w1, #0x2                   	// #2
    4c54:	97fff1bb 	bl	1340 <__sprintf_chk@plt>
    4c58:	17ffffc5 	b	4b6c <fwp_write.constprop.0+0xe4c>
    4c5c:	528005a4 	mov	w4, #0x2d                  	// #45
    4c60:	eb0003e2 	negs	x2, x0
    4c64:	da0103e3 	ngc	x3, x1
    4c68:	910027e0 	add	x0, sp, #0x9
    4c6c:	910023f3 	add	x19, sp, #0x8
    4c70:	390023e4 	strb	w4, [sp, #8]
    4c74:	97fff35b 	bl	19e0 <fwp_fmt_u128>
    4c78:	17ffffed 	b	4c2c <fwp_write.constprop.0+0xf0c>
    4c7c:	f9013bf5 	str	x21, [sp, #624]
    4c80:	f9013ff6 	str	x22, [sp, #632]
    4c84:	f90143f7 	str	x23, [sp, #640]
    4c88:	f90147f8 	str	x24, [sp, #648]
    4c8c:	f9014bf9 	str	x25, [sp, #656]
    4c90:	f9014ffa 	str	x26, [sp, #664]
    4c94:	f90153fb 	str	x27, [sp, #672]
    4c98:	f90157fc 	str	x28, [sp, #680]
    4c9c:	fd015be8 	str	d8, [sp, #688]
    4ca0:	fd015fe9 	str	d9, [sp, #696]
    4ca4:	97fff1ff 	bl	14a0 <__stack_chk_fail@plt>
    4ca8:	f90143f7 	str	x23, [sp, #640]
    4cac:	f90147f8 	str	x24, [sp, #648]
    4cb0:	f9014bf9 	str	x25, [sp, #656]
    4cb4:	f9014ffa 	str	x26, [sp, #664]
    4cb8:	fd015be8 	str	d8, [sp, #688]
    4cbc:	fd015fe9 	str	d9, [sp, #696]
    4cc0:	97fff1f8 	bl	14a0 <__stack_chk_fail@plt>

0000000000004cc4 <fwp_hof0.constprop.0>:
    4cc4:	d10303ff 	sub	sp, sp, #0xc0
    4cc8:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x152d8>
    4ccc:	f947f442 	ldr	x2, [x2, #4072]
    4cd0:	a9047bfd 	stp	x29, x30, [sp, #64]
    4cd4:	910103fd 	add	x29, sp, #0x40
    4cd8:	a9065bf5 	stp	x21, x22, [sp, #96]
    4cdc:	aa0003f5 	mov	x21, x0
    4ce0:	f9400040 	ldr	x0, [x2]
    4ce4:	f9001fe0 	str	x0, [sp, #56]
    4ce8:	d2800000 	mov	x0, #0x0                   	// #0
    4cec:	f90007e1 	str	x1, [sp, #8]
    4cf0:	b4004401 	cbz	x1, 5570 <fwp_hof0.constprop.0+0x8ac>
    4cf4:	b0000021 	adrp	x1, 9000 <msg.3+0x50>
    4cf8:	6d0a27e8 	stp	d8, d9, [sp, #160]
    4cfc:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4d00:	fd400029 	ldr	d9, [x1]
    4d04:	9e670008 	fmov	d8, x0
    4d08:	a90553f3 	stp	x19, x20, [sp, #80]
    4d0c:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xce0>
    4d10:	a90763f7 	stp	x23, x24, [sp, #112]
    4d14:	a9086bf9 	stp	x25, x26, [sp, #128]
    4d18:	a90973fb 	stp	x27, x28, [sp, #144]
    4d1c:	fd005bea 	str	d10, [sp, #176]
    4d20:	91140282 	add	x2, x20, #0x500
    4d24:	f949d840 	ldr	x0, [x2, #5040]
    4d28:	f949ec41 	ldr	x1, [x2, #5080]
    4d2c:	cb0002a0 	sub	x0, x21, x0
    4d30:	eb01401f 	cmp	x0, x1, lsl #16
    4d34:	54000342 	b.cs	4d9c <fwp_hof0.constprop.0+0xd8>  // b.hs, b.nlast
    4d38:	d350fc01 	lsr	x1, x0, #16
    4d3c:	f949fc43 	ldr	x3, [x2, #5112]
    4d40:	8b010821 	add	x1, x1, x1, lsl #2
    4d44:	d37df021 	lsl	x1, x1, #3
    4d48:	8b010062 	add	x2, x3, x1
    4d4c:	f9401053 	ldr	x19, [x2, #32]
    4d50:	b4000273 	cbz	x19, 4d9c <fwp_hof0.constprop.0+0xd8>
    4d54:	38616861 	ldrb	w1, [x3, x1]
    4d58:	7100083f 	cmp	w1, #0x2
    4d5c:	54004d20 	b.eq	5700 <fwp_hof0.constprop.0+0xa3c>  // b.none
    4d60:	7100043f 	cmp	w1, #0x1
    4d64:	540001c1 	b.ne	4d9c <fwp_hof0.constprop.0+0xd8>  // b.any
    4d68:	29430443 	ldp	w3, w1, [x2, #24]
    4d6c:	92403c00 	and	x0, x0, #0xffff
    4d70:	9b037c00 	mul	x0, x0, x3
    4d74:	d360fc00 	lsr	x0, x0, #32
    4d78:	eb01001f 	cmp	x0, x1
    4d7c:	54000102 	b.cs	4d9c <fwp_hof0.constprop.0+0xd8>  // b.hs, b.nlast
    4d80:	8b000273 	add	x19, x19, x0
    4d84:	39400260 	ldrb	w0, [x19]
    4d88:	340000a0 	cbz	w0, 4d9c <fwp_hof0.constprop.0+0xd8>
    4d8c:	7103f41f 	cmp	w0, #0xfd
    4d90:	54005668 	b.hi	585c <fwp_hof0.constprop.0+0xb98>  // b.pmore
    4d94:	11000400 	add	w0, w0, #0x1
    4d98:	39000260 	strb	w0, [x19]
    4d9c:	b4004b95 	cbz	x21, 570c <fwp_hof0.constprop.0+0xa48>
    4da0:	aa1503e1 	mov	x1, x21
    4da4:	d2800000 	mov	x0, #0x0                   	// #0
    4da8:	f9400821 	ldr	x1, [x1, #16]
    4dac:	91000400 	add	x0, x0, #0x1
    4db0:	b5ffffc1 	cbnz	x1, 4da8 <fwp_hof0.constprop.0+0xe4>
    4db4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    4db8:	eb01001f 	cmp	x0, x1
    4dbc:	54005e48 	b.hi	5984 <fwp_hof0.constprop.0+0xcc0>  // b.pmore
    4dc0:	97fffa19 	bl	3624 <fwp_array_new_packed.constprop.0>
    4dc4:	aa0003f7 	mov	x23, x0
    4dc8:	91140281 	add	x1, x20, #0x500
    4dcc:	aa0103e0 	mov	x0, x1
    4dd0:	f949d821 	ldr	x1, [x1, #5040]
    4dd4:	f949ec00 	ldr	x0, [x0, #5080]
    4dd8:	cb0102e1 	sub	x1, x23, x1
    4ddc:	eb00403f 	cmp	x1, x0, lsl #16
    4de0:	54000362 	b.cs	4e4c <fwp_hof0.constprop.0+0x188>  // b.hs, b.nlast
    4de4:	91140282 	add	x2, x20, #0x500
    4de8:	d350fc20 	lsr	x0, x1, #16
    4dec:	8b000800 	add	x0, x0, x0, lsl #2
    4df0:	f949fc43 	ldr	x3, [x2, #5112]
    4df4:	d37df002 	lsl	x2, x0, #3
    4df8:	8b020060 	add	x0, x3, x2
    4dfc:	f9401013 	ldr	x19, [x0, #32]
    4e00:	b4000253 	cbz	x19, 4e48 <fwp_hof0.constprop.0+0x184>
    4e04:	38626862 	ldrb	w2, [x3, x2]
    4e08:	7100085f 	cmp	w2, #0x2
    4e0c:	54004980 	b.eq	573c <fwp_hof0.constprop.0+0xa78>  // b.none
    4e10:	7100045f 	cmp	w2, #0x1
    4e14:	540001a1 	b.ne	4e48 <fwp_hof0.constprop.0+0x184>  // b.any
    4e18:	29430002 	ldp	w2, w0, [x0, #24]
    4e1c:	92403c21 	and	x1, x1, #0xffff
    4e20:	9b027c21 	mul	x1, x1, x2
    4e24:	d360fc21 	lsr	x1, x1, #32
    4e28:	eb00003f 	cmp	x1, x0
    4e2c:	540000e2 	b.cs	4e48 <fwp_hof0.constprop.0+0x184>  // b.hs, b.nlast
    4e30:	8b010273 	add	x19, x19, x1
    4e34:	39400260 	ldrb	w0, [x19]
    4e38:	7103fc1f 	cmp	w0, #0xff
    4e3c:	540048a0 	b.eq	5750 <fwp_hof0.constprop.0+0xa8c>  // b.none
    4e40:	52800020 	mov	w0, #0x1                   	// #1
    4e44:	39000260 	strb	w0, [x19]
    4e48:	b4004775 	cbz	x21, 5734 <fwp_hof0.constprop.0+0xa70>
    4e4c:	910022f8 	add	x24, x23, #0x8
    4e50:	aa1503e0 	mov	x0, x21
    4e54:	aa1503f3 	mov	x19, x21
    4e58:	91140299 	add	x25, x20, #0x500
    4e5c:	5280003a 	mov	w26, #0x1                   	// #1
    4e60:	14000014 	b	4eb0 <fwp_hof0.constprop.0+0x1ec>
    4e64:	7100045f 	cmp	w2, #0x1
    4e68:	54000181 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4e6c:	294308e8 	ldp	w8, w2, [x7, #24]
    4e70:	92403c21 	and	x1, x1, #0xffff
    4e74:	9b087c21 	mul	x1, x1, x8
    4e78:	d360fc21 	lsr	x1, x1, #32
    4e7c:	eb02003f 	cmp	x1, x2
    4e80:	540000c2 	b.cs	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.hs, b.nlast
    4e84:	8b0100c6 	add	x6, x6, x1
    4e88:	394000c1 	ldrb	w1, [x6]
    4e8c:	7100043f 	cmp	w1, #0x1
    4e90:	54000400 	b.eq	4f10 <fwp_hof0.constprop.0+0x24c>  // b.none
    4e94:	d503201f 	nop
    4e98:	f94002e1 	ldr	x1, [x23]
    4e9c:	b7f85401 	tbnz	x1, #63, 591c <fwp_hof0.constprop.0+0xc58>
    4ea0:	f9000304 	str	x4, [x24]
    4ea4:	5280001a 	mov	w26, #0x0                   	// #0
    4ea8:	91002318 	add	x24, x24, #0x8
    4eac:	b4000773 	cbz	x19, 4f98 <fwp_hof0.constprop.0+0x2d4>
    4eb0:	aa1303e5 	mov	x5, x19
    4eb4:	aa1303e3 	mov	x3, x19
    4eb8:	a940ce64 	ldp	x4, x19, [x19, #8]
    4ebc:	34fffefa 	cbz	w26, 4e98 <fwp_hof0.constprop.0+0x1d4>
    4ec0:	f949db21 	ldr	x1, [x25, #5040]
    4ec4:	f949ef22 	ldr	x2, [x25, #5080]
    4ec8:	cb0100a1 	sub	x1, x5, x1
    4ecc:	eb02403f 	cmp	x1, x2, lsl #16
    4ed0:	54fffe42 	b.cs	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.hs, b.nlast
    4ed4:	d350fc22 	lsr	x2, x1, #16
    4ed8:	f949ff28 	ldr	x8, [x25, #5112]
    4edc:	8b020842 	add	x2, x2, x2, lsl #2
    4ee0:	d37df042 	lsl	x2, x2, #3
    4ee4:	8b020107 	add	x7, x8, x2
    4ee8:	f94010e6 	ldr	x6, [x7, #32]
    4eec:	b4fffd66 	cbz	x6, 4e98 <fwp_hof0.constprop.0+0x1d4>
    4ef0:	38626902 	ldrb	w2, [x8, x2]
    4ef4:	7100085f 	cmp	w2, #0x2
    4ef8:	54fffb61 	b.ne	4e64 <fwp_hof0.constprop.0+0x1a0>  // b.any
    4efc:	72003c3f 	tst	w1, #0xffff
    4f00:	54fffcc1 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4f04:	394000c1 	ldrb	w1, [x6]
    4f08:	7100043f 	cmp	w1, #0x1
    4f0c:	54fffc61 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4f10:	f94002e0 	ldr	x0, [x23]
    4f14:	b7f85040 	tbnz	x0, #63, 591c <fwp_hof0.constprop.0+0xc58>
    4f18:	f9000304 	str	x4, [x24]
    4f1c:	f949db21 	ldr	x1, [x25, #5040]
    4f20:	f949ef20 	ldr	x0, [x25, #5080]
    4f24:	cb010063 	sub	x3, x3, x1
    4f28:	eb00407f 	cmp	x3, x0, lsl #16
    4f2c:	540002e2 	b.cs	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.hs, b.nlast
    4f30:	d350fc60 	lsr	x0, x3, #16
    4f34:	f949ff21 	ldr	x1, [x25, #5112]
    4f38:	8b000800 	add	x0, x0, x0, lsl #2
    4f3c:	d37df000 	lsl	x0, x0, #3
    4f40:	8b000024 	add	x4, x1, x0
    4f44:	f9401082 	ldr	x2, [x4, #32]
    4f48:	b4000202 	cbz	x2, 4f88 <fwp_hof0.constprop.0+0x2c4>
    4f4c:	38606820 	ldrb	w0, [x1, x0]
    4f50:	7100081f 	cmp	w0, #0x2
    4f54:	54003b20 	b.eq	56b8 <fwp_hof0.constprop.0+0x9f4>  // b.none
    4f58:	7100041f 	cmp	w0, #0x1
    4f5c:	54000161 	b.ne	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.any
    4f60:	29430086 	ldp	w6, w0, [x4, #24]
    4f64:	92403c61 	and	x1, x3, #0xffff
    4f68:	9b067c21 	mul	x1, x1, x6
    4f6c:	d360fc21 	lsr	x1, x1, #32
    4f70:	eb00003f 	cmp	x1, x0
    4f74:	540000a2 	b.cs	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.hs, b.nlast
    4f78:	8b010042 	add	x2, x2, x1
    4f7c:	39400040 	ldrb	w0, [x2]
    4f80:	7100041f 	cmp	w0, #0x1
    4f84:	54000e40 	b.eq	514c <fwp_hof0.constprop.0+0x488>  // b.none
    4f88:	aa1303e0 	mov	x0, x19
    4f8c:	91002318 	add	x24, x24, #0x8
    4f90:	b5fff913 	cbnz	x19, 4eb0 <fwp_hof0.constprop.0+0x1ec>
    4f94:	d503201f 	nop
    4f98:	97fff9b6 	bl	3670 <fwp_drop0>
    4f9c:	d28018d9 	mov	x25, #0xc6                  	// #198
    4fa0:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    4fa4:	9e67000a 	fmov	d10, x0
    4fa8:	f94002f8 	ldr	x24, [x23]
    4fac:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    4fb0:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    4fb4:	eb00031f 	cmp	x24, x0
    4fb8:	54004e68 	b.hi	5984 <fwp_hof0.constprop.0+0xcc0>  // b.pmore
    4fbc:	aa1803e0 	mov	x0, x24
    4fc0:	97fff999 	bl	3624 <fwp_array_new_packed.constprop.0>
    4fc4:	91140282 	add	x2, x20, #0x500
    4fc8:	aa0003f3 	mov	x19, x0
    4fcc:	f949d841 	ldr	x1, [x2, #5040]
    4fd0:	f949ec40 	ldr	x0, [x2, #5080]
    4fd4:	cb010261 	sub	x1, x19, x1
    4fd8:	eb00403f 	cmp	x1, x0, lsl #16
    4fdc:	54000322 	b.cs	5040 <fwp_hof0.constprop.0+0x37c>  // b.hs, b.nlast
    4fe0:	d350fc20 	lsr	x0, x1, #16
    4fe4:	f949fc43 	ldr	x3, [x2, #5112]
    4fe8:	8b000800 	add	x0, x0, x0, lsl #2
    4fec:	d37df002 	lsl	x2, x0, #3
    4ff0:	8b020060 	add	x0, x3, x2
    4ff4:	f940101a 	ldr	x26, [x0, #32]
    4ff8:	b400025a 	cbz	x26, 5040 <fwp_hof0.constprop.0+0x37c>
    4ffc:	38626862 	ldrb	w2, [x3, x2]
    5000:	7100085f 	cmp	w2, #0x2
    5004:	54003040 	b.eq	560c <fwp_hof0.constprop.0+0x948>  // b.none
    5008:	7100045f 	cmp	w2, #0x1
    500c:	540001a1 	b.ne	5040 <fwp_hof0.constprop.0+0x37c>  // b.any
    5010:	29430002 	ldp	w2, w0, [x0, #24]
    5014:	92403c21 	and	x1, x1, #0xffff
    5018:	9b027c21 	mul	x1, x1, x2
    501c:	d360fc21 	lsr	x1, x1, #32
    5020:	eb00003f 	cmp	x1, x0
    5024:	540000e2 	b.cs	5040 <fwp_hof0.constprop.0+0x37c>  // b.hs, b.nlast
    5028:	8b01035a 	add	x26, x26, x1
    502c:	39400340 	ldrb	w0, [x26]
    5030:	7103fc1f 	cmp	w0, #0xff
    5034:	54002f60 	b.eq	5620 <fwp_hof0.constprop.0+0x95c>  // b.none
    5038:	52800020 	mov	w0, #0x1                   	// #1
    503c:	39000340 	strb	w0, [x26]
    5040:	b40008f8 	cbz	x24, 515c <fwp_hof0.constprop.0+0x498>
    5044:	aa1703e8 	mov	x8, x23
    5048:	d2800004 	mov	x4, #0x0                   	// #0
    504c:	d2800025 	mov	x5, #0x1                   	// #1
    5050:	d2800003 	mov	x3, #0x0                   	// #0
    5054:	9e6703e1 	fmov	d1, xzr
    5058:	1e6e1005 	fmov	d5, #1.000000000000000000e+00
    505c:	f8408506 	ldr	x6, [x8], #8
    5060:	9240f8c2 	and	x2, x6, #0x7fffffffffffffff
    5064:	aa0803e7 	mov	x7, x8
    5068:	eb0200bf 	cmp	x5, x2
    506c:	54000640 	b.eq	5134 <fwp_hof0.constprop.0+0x470>  // b.none
    5070:	eb02009f 	cmp	x4, x2
    5074:	54000642 	b.cs	513c <fwp_hof0.constprop.0+0x478>  // b.hs, b.nlast
    5078:	b7f82a46 	tbnz	x6, #63, 55c0 <fwp_hof0.constprop.0+0x8fc>
    507c:	fd4000e2 	ldr	d2, [x7]
    5080:	aa0803e0 	mov	x0, x8
    5084:	1e6238a3 	fsub	d3, d5, d2
    5088:	1e6a0844 	fmul	d4, d2, d10
    508c:	1e632863 	fadd	d3, d3, d3
    5090:	1e620842 	fmul	d2, d2, d2
    5094:	eb0200bf 	cmp	x5, x2
    5098:	54000522 	b.cs	513c <fwp_hof0.constprop.0+0x478>  // b.hs, b.nlast
    509c:	8b030000 	add	x0, x0, x3
    50a0:	fd400400 	ldr	d0, [x0, #8]
    50a4:	1e623800 	fsub	d0, d0, d2
    50a8:	1e640800 	fmul	d0, d0, d4
    50ac:	1e633800 	fsub	d0, d0, d3
    50b0:	1e612800 	fadd	d0, d0, d1
    50b4:	1e690800 	fmul	d0, d0, d9
    50b8:	aa0803e0 	mov	x0, x8
    50bc:	b7f82726 	tbnz	x6, #63, 55a0 <fwp_hof0.constprop.0+0x8dc>
    50c0:	fc636801 	ldr	d1, [x0, x3]
    50c4:	f9400260 	ldr	x0, [x19]
    50c8:	1e603821 	fsub	d1, d1, d0
    50cc:	b7f84280 	tbnz	x0, #63, 591c <fwp_hof0.constprop.0+0xc58>
    50d0:	8b130062 	add	x2, x3, x19
    50d4:	91000481 	add	x1, x4, #0x1
    50d8:	fd000441 	str	d1, [x2, #8]
    50dc:	eb01031f 	cmp	x24, x1
    50e0:	540003e0 	b.eq	515c <fwp_hof0.constprop.0+0x498>  // b.none
    50e4:	f94002e6 	ldr	x6, [x23]
    50e8:	9240f8c2 	and	x2, x6, #0x7fffffffffffffff
    50ec:	eb04005f 	cmp	x2, x4
    50f0:	54000269 	b.ls	513c <fwp_hof0.constprop.0+0x478>  // b.plast
    50f4:	91002060 	add	x0, x3, #0x8
    50f8:	b7f82586 	tbnz	x6, #63, 55a8 <fwp_hof0.constprop.0+0x8e4>
    50fc:	fc776800 	ldr	d0, [x0, x23]
    5100:	aa0803e4 	mov	x4, x8
    5104:	1e600800 	fmul	d0, d0, d0
    5108:	eb02003f 	cmp	x1, x2
    510c:	54000182 	b.cs	513c <fwp_hof0.constprop.0+0x478>  // b.hs, b.nlast
    5110:	fc606881 	ldr	d1, [x4, x0]
    5114:	910004a5 	add	x5, x5, #0x1
    5118:	910020e7 	add	x7, x7, #0x8
    511c:	aa0103e4 	mov	x4, x1
    5120:	aa0003e3 	mov	x3, x0
    5124:	1e603821 	fsub	d1, d1, d0
    5128:	1e680821 	fmul	d1, d1, d8
    512c:	eb0200bf 	cmp	x5, x2
    5130:	54fffa01 	b.ne	5070 <fwp_hof0.constprop.0+0x3ac>  // b.any
    5134:	eb05009f 	cmp	x4, x5
    5138:	540043e3 	b.cc	59b4 <fwp_hof0.constprop.0+0xcf0>  // b.lo, b.ul, b.last
    513c:	f00000c0 	adrp	x0, 20000 <__data_start>
    5140:	91004000 	add	x0, x0, #0x10
    5144:	91002000 	add	x0, x0, #0x8
    5148:	97fff3d6 	bl	20a0 <fwp_trap>
    514c:	aa0503e0 	mov	x0, x5
    5150:	97fff734 	bl	2e20 <fwp_mem_free>
    5154:	aa1303e0 	mov	x0, x19
    5158:	17ffff8d 	b	4f8c <fwp_hof0.constprop.0+0x2c8>
    515c:	9114029a 	add	x26, x20, #0x500
    5160:	f949db41 	ldr	x1, [x26, #5040]
    5164:	f949ef40 	ldr	x0, [x26, #5080]
    5168:	cb0102e1 	sub	x1, x23, x1
    516c:	eb00403f 	cmp	x1, x0, lsl #16
    5170:	54000382 	b.cs	51e0 <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    5174:	d350fc20 	lsr	x0, x1, #16
    5178:	f949ff42 	ldr	x2, [x26, #5112]
    517c:	8b000800 	add	x0, x0, x0, lsl #2
    5180:	d37df000 	lsl	x0, x0, #3
    5184:	8b000043 	add	x3, x2, x0
    5188:	f9401078 	ldr	x24, [x3, #32]
    518c:	b40002b8 	cbz	x24, 51e0 <fwp_hof0.constprop.0+0x51c>
    5190:	38606840 	ldrb	w0, [x2, x0]
    5194:	7100081f 	cmp	w0, #0x2
    5198:	540021e0 	b.eq	55d4 <fwp_hof0.constprop.0+0x910>  // b.none
    519c:	7100041f 	cmp	w0, #0x1
    51a0:	54000201 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    51a4:	29430064 	ldp	w4, w0, [x3, #24]
    51a8:	92403c21 	and	x1, x1, #0xffff
    51ac:	9b047c21 	mul	x1, x1, x4
    51b0:	d360fc21 	lsr	x1, x1, #32
    51b4:	eb00003f 	cmp	x1, x0
    51b8:	54000142 	b.cs	51e0 <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    51bc:	8b010318 	add	x24, x24, x1
    51c0:	39400300 	ldrb	w0, [x24]
    51c4:	340000e0 	cbz	w0, 51e0 <fwp_hof0.constprop.0+0x51c>
    51c8:	7100041f 	cmp	w0, #0x1
    51cc:	54000140 	b.eq	51f4 <fwp_hof0.constprop.0+0x530>  // b.none
    51d0:	7103fc1f 	cmp	w0, #0xff
    51d4:	54002c40 	b.eq	575c <fwp_hof0.constprop.0+0xa98>  // b.none
    51d8:	51000400 	sub	w0, w0, #0x1
    51dc:	39000300 	strb	w0, [x24]
    51e0:	b40004d9 	cbz	x25, 5278 <fwp_hof0.constprop.0+0x5b4>
    51e4:	f1000739 	subs	x25, x25, #0x1
    51e8:	54004006 	b.vs	59e8 <fwp_hof0.constprop.0+0xd24>
    51ec:	aa1303f7 	mov	x23, x19
    51f0:	17ffff6e 	b	4fa8 <fwp_hof0.constprop.0+0x2e4>
    51f4:	f94002e0 	ldr	x0, [x23]
    51f8:	b7f81f40 	tbnz	x0, #63, 55e0 <fwp_hof0.constprop.0+0x91c>
    51fc:	91140281 	add	x1, x20, #0x500
    5200:	f949d820 	ldr	x0, [x1, #5040]
    5204:	f949ec21 	ldr	x1, [x1, #5080]
    5208:	cb0002e0 	sub	x0, x23, x0
    520c:	eb01401f 	cmp	x0, x1, lsl #16
    5210:	54fffe82 	b.cs	51e0 <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    5214:	d350fc01 	lsr	x1, x0, #16
    5218:	8b010821 	add	x1, x1, x1, lsl #2
    521c:	d37df021 	lsl	x1, x1, #3
    5220:	8b010044 	add	x4, x2, x1
    5224:	f9401083 	ldr	x3, [x4, #32]
    5228:	b4fffdc3 	cbz	x3, 51e0 <fwp_hof0.constprop.0+0x51c>
    522c:	38616841 	ldrb	w1, [x2, x1]
    5230:	7100083f 	cmp	w1, #0x2
    5234:	54001fc0 	b.eq	562c <fwp_hof0.constprop.0+0x968>  // b.none
    5238:	7100043f 	cmp	w1, #0x1
    523c:	54fffd21 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    5240:	29430482 	ldp	w2, w1, [x4, #24]
    5244:	92403c00 	and	x0, x0, #0xffff
    5248:	9b027c00 	mul	x0, x0, x2
    524c:	d360fc00 	lsr	x0, x0, #32
    5250:	eb01001f 	cmp	x0, x1
    5254:	54fffc62 	b.cs	51e0 <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    5258:	8b000063 	add	x3, x3, x0
    525c:	39400060 	ldrb	w0, [x3]
    5260:	7100041f 	cmp	w0, #0x1
    5264:	54fffbe1 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    5268:	aa1703e0 	mov	x0, x23
    526c:	97fff6ed 	bl	2e20 <fwp_mem_free>
    5270:	b5fffbb9 	cbnz	x25, 51e4 <fwp_hof0.constprop.0+0x520>
    5274:	d503201f 	nop
    5278:	52800b63 	mov	w3, #0x5b                  	// #91
    527c:	91007ffc 	add	x28, sp, #0x1f
    5280:	910083f7 	add	x23, sp, #0x20
    5284:	aa1c03e1 	mov	x1, x28
    5288:	aa1703e0 	mov	x0, x23
    528c:	d2800022 	mov	x2, #0x1                   	// #1
    5290:	39007fe3 	strb	w3, [sp, #31]
    5294:	d2800016 	mov	x22, #0x0                   	// #0
    5298:	a9027fff 	stp	xzr, xzr, [sp, #32]
    529c:	d00000d8 	adrp	x24, 1f000 <__FRAME_END__+0x152d8>
    52a0:	f9001bff 	str	xzr, [sp, #48]
    52a4:	97fff323 	bl	1f30 <buf_put>
    52a8:	f9400260 	ldr	x0, [x19]
    52ac:	f240f81a 	ands	x26, x0, #0x7fffffffffffffff
    52b0:	540003c0 	b.eq	5328 <fwp_hof0.constprop.0+0x664>  // b.none
    52b4:	912ca318 	add	x24, x24, #0xb28
    52b8:	f0000019 	adrp	x25, 8000 <fwp_main_thread+0x1a0>
    52bc:	91014318 	add	x24, x24, #0x50
    52c0:	9135e339 	add	x25, x25, #0xd78
    52c4:	9100227b 	add	x27, x19, #0x8
    52c8:	1400000d 	b	52fc <fwp_hof0.constprop.0+0x638>
    52cc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    52d0:	aa1803e2 	mov	x2, x24
    52d4:	aa1703e0 	mov	x0, x23
    52d8:	910006d6 	add	x22, x22, #0x1
    52dc:	97fffa91 	bl	3d20 <fwp_write.constprop.0>
    52e0:	eb16035f 	cmp	x26, x22
    52e4:	54000220 	b.eq	5328 <fwp_hof0.constprop.0+0x664>  // b.none
    52e8:	aa1703e0 	mov	x0, x23
    52ec:	aa1903e1 	mov	x1, x25
    52f0:	d2800042 	mov	x2, #0x2                   	// #2
    52f4:	97fff30f 	bl	1f30 <buf_put>
    52f8:	f9400260 	ldr	x0, [x19]
    52fc:	aa1b03e1 	mov	x1, x27
    5300:	b6fffe60 	tbz	x0, #63, 52cc <fwp_hof0.constprop.0+0x608>
    5304:	f9400a61 	ldr	x1, [x19, #16]
    5308:	aa1803e2 	mov	x2, x24
    530c:	aa1703e0 	mov	x0, x23
    5310:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    5314:	910006d6 	add	x22, x22, #0x1
    5318:	97fffa82 	bl	3d20 <fwp_write.constprop.0>
    531c:	eb16035f 	cmp	x26, x22
    5320:	54fffe41 	b.ne	52e8 <fwp_hof0.constprop.0+0x624>  // b.any
    5324:	d503201f 	nop
    5328:	52800ba3 	mov	w3, #0x5d                  	// #93
    532c:	aa1703e0 	mov	x0, x23
    5330:	aa1c03e1 	mov	x1, x28
    5334:	d2800022 	mov	x2, #0x1                   	// #1
    5338:	39007fe3 	strb	w3, [sp, #31]
    533c:	97fff2fd 	bl	1f30 <buf_put>
    5340:	a94263f9 	ldp	x25, x24, [sp, #32]
    5344:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5348:	9134a000 	add	x0, x0, #0xd28
    534c:	f100033f 	cmp	x25, #0x0
    5350:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    5354:	b1002b1f 	cmn	x24, #0xa
    5358:	540031c8 	b.hi	5990 <fwp_hof0.constprop.0+0xccc>  // b.pmore
    535c:	91002700 	add	x0, x24, #0x9
    5360:	52800021 	mov	w1, #0x1                   	// #1
    5364:	97fff820 	bl	33e4 <fwp_heap_alloc>
    5368:	aa0003f7 	mov	x23, x0
    536c:	aa1903e1 	mov	x1, x25
    5370:	aa0003f9 	mov	x25, x0
    5374:	aa1803e2 	mov	x2, x24
    5378:	f8008738 	str	x24, [x25], #8
    537c:	8b1802f8 	add	x24, x23, x24
    5380:	aa1903e0 	mov	x0, x25
    5384:	97ffefdf 	bl	1300 <memcpy@plt>
    5388:	f94013e0 	ldr	x0, [sp, #32]
    538c:	3900231f 	strb	wzr, [x24, #8]
    5390:	97fff074 	bl	1560 <free@plt>
    5394:	91140282 	add	x2, x20, #0x500
    5398:	f949ec43 	ldr	x3, [x2, #5080]
    539c:	f949d841 	ldr	x1, [x2, #5040]
    53a0:	d370bc63 	lsl	x3, x3, #16
    53a4:	cb0102e4 	sub	x4, x23, x1
    53a8:	eb03009f 	cmp	x4, x3
    53ac:	540003a2 	b.cs	5420 <fwp_hof0.constprop.0+0x75c>  // b.hs, b.nlast
    53b0:	d350fc80 	lsr	x0, x4, #16
    53b4:	f949fc45 	ldr	x5, [x2, #5112]
    53b8:	8b000800 	add	x0, x0, x0, lsl #2
    53bc:	d37df002 	lsl	x2, x0, #3
    53c0:	8b0200a0 	add	x0, x5, x2
    53c4:	f9401018 	ldr	x24, [x0, #32]
    53c8:	b40002d8 	cbz	x24, 5420 <fwp_hof0.constprop.0+0x75c>
    53cc:	386268a2 	ldrb	w2, [x5, x2]
    53d0:	7100085f 	cmp	w2, #0x2
    53d4:	54001f00 	b.eq	57b4 <fwp_hof0.constprop.0+0xaf0>  // b.none
    53d8:	7100045f 	cmp	w2, #0x1
    53dc:	54000221 	b.ne	5420 <fwp_hof0.constprop.0+0x75c>  // b.any
    53e0:	29430005 	ldp	w5, w0, [x0, #24]
    53e4:	92403c82 	and	x2, x4, #0xffff
    53e8:	9b057c42 	mul	x2, x2, x5
    53ec:	d360fc42 	lsr	x2, x2, #32
    53f0:	eb00005f 	cmp	x2, x0
    53f4:	54000162 	b.cs	5420 <fwp_hof0.constprop.0+0x75c>  // b.hs, b.nlast
    53f8:	8b020318 	add	x24, x24, x2
    53fc:	39400300 	ldrb	w0, [x24]
    5400:	7103fc1f 	cmp	w0, #0xff
    5404:	54001e20 	b.eq	57c8 <fwp_hof0.constprop.0+0xb04>  // b.none
    5408:	91140280 	add	x0, x20, #0x500
    540c:	52800021 	mov	w1, #0x1                   	// #1
    5410:	39000301 	strb	w1, [x24]
    5414:	f949ec03 	ldr	x3, [x0, #5080]
    5418:	f949d801 	ldr	x1, [x0, #5040]
    541c:	d370bc63 	lsl	x3, x3, #16
    5420:	cb010261 	sub	x1, x19, x1
    5424:	9114029a 	add	x26, x20, #0x500
    5428:	eb03003f 	cmp	x1, x3
    542c:	540003a2 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    5430:	d350fc20 	lsr	x0, x1, #16
    5434:	f949ff43 	ldr	x3, [x26, #5112]
    5438:	8b000800 	add	x0, x0, x0, lsl #2
    543c:	d37df002 	lsl	x2, x0, #3
    5440:	8b020060 	add	x0, x3, x2
    5444:	f9401018 	ldr	x24, [x0, #32]
    5448:	b40002d8 	cbz	x24, 54a0 <fwp_hof0.constprop.0+0x7dc>
    544c:	38626862 	ldrb	w2, [x3, x2]
    5450:	7100085f 	cmp	w2, #0x2
    5454:	540013a0 	b.eq	56c8 <fwp_hof0.constprop.0+0xa04>  // b.none
    5458:	7100045f 	cmp	w2, #0x1
    545c:	54000221 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5460:	29430002 	ldp	w2, w0, [x0, #24]
    5464:	92403c21 	and	x1, x1, #0xffff
    5468:	9b027c21 	mul	x1, x1, x2
    546c:	d360fc21 	lsr	x1, x1, #32
    5470:	eb00003f 	cmp	x1, x0
    5474:	54000162 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    5478:	8b010318 	add	x24, x24, x1
    547c:	39400300 	ldrb	w0, [x24]
    5480:	34000100 	cbz	w0, 54a0 <fwp_hof0.constprop.0+0x7dc>
    5484:	7100041f 	cmp	w0, #0x1
    5488:	54000d80 	b.eq	5638 <fwp_hof0.constprop.0+0x974>  // b.none
    548c:	7103fc1f 	cmp	w0, #0xff
    5490:	54001ba0 	b.eq	5804 <fwp_hof0.constprop.0+0xb40>  // b.none
    5494:	51000400 	sub	w0, w0, #0x1
    5498:	39000300 	strb	w0, [x24]
    549c:	d503201f 	nop
    54a0:	f00000d3 	adrp	x19, 20000 <__data_start>
    54a4:	d2800021 	mov	x1, #0x1                   	// #1
    54a8:	f94002e2 	ldr	x2, [x23]
    54ac:	aa1903e0 	mov	x0, x25
    54b0:	f9403263 	ldr	x3, [x19, #96]
    54b4:	97fff03b 	bl	15a0 <fwrite@plt>
    54b8:	f9403261 	ldr	x1, [x19, #96]
    54bc:	52800140 	mov	w0, #0xa                   	// #10
    54c0:	97ffefc0 	bl	13c0 <fputc@plt>
    54c4:	91140282 	add	x2, x20, #0x500
    54c8:	f949d841 	ldr	x1, [x2, #5040]
    54cc:	f949ec40 	ldr	x0, [x2, #5080]
    54d0:	cb0102e1 	sub	x1, x23, x1
    54d4:	eb00403f 	cmp	x1, x0, lsl #16
    54d8:	54000382 	b.cs	5548 <fwp_hof0.constprop.0+0x884>  // b.hs, b.nlast
    54dc:	d350fc20 	lsr	x0, x1, #16
    54e0:	f949fc43 	ldr	x3, [x2, #5112]
    54e4:	8b000800 	add	x0, x0, x0, lsl #2
    54e8:	d37df002 	lsl	x2, x0, #3
    54ec:	8b020060 	add	x0, x3, x2
    54f0:	f9401013 	ldr	x19, [x0, #32]
    54f4:	b40002b3 	cbz	x19, 5548 <fwp_hof0.constprop.0+0x884>
    54f8:	38626862 	ldrb	w2, [x3, x2]
    54fc:	7100085f 	cmp	w2, #0x2
    5500:	540016a0 	b.eq	57d4 <fwp_hof0.constprop.0+0xb10>  // b.none
    5504:	7100045f 	cmp	w2, #0x1
    5508:	54000201 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    550c:	29430002 	ldp	w2, w0, [x0, #24]
    5510:	92403c21 	and	x1, x1, #0xffff
    5514:	9b027c21 	mul	x1, x1, x2
    5518:	d360fc21 	lsr	x1, x1, #32
    551c:	eb00003f 	cmp	x1, x0
    5520:	54000142 	b.cs	5548 <fwp_hof0.constprop.0+0x884>  // b.hs, b.nlast
    5524:	8b010273 	add	x19, x19, x1
    5528:	39400260 	ldrb	w0, [x19]
    552c:	340000e0 	cbz	w0, 5548 <fwp_hof0.constprop.0+0x884>
    5530:	7100041f 	cmp	w0, #0x1
    5534:	540015c0 	b.eq	57ec <fwp_hof0.constprop.0+0xb28>  // b.none
    5538:	7103fc1f 	cmp	w0, #0xff
    553c:	54001c40 	b.eq	58c4 <fwp_hof0.constprop.0+0xc00>  // b.none
    5540:	51000400 	sub	w0, w0, #0x1
    5544:	39000260 	strb	w0, [x19]
    5548:	f94007e0 	ldr	x0, [sp, #8]
    554c:	f9400800 	ldr	x0, [x0, #16]
    5550:	f90007e0 	str	x0, [sp, #8]
    5554:	b5ffbe60 	cbnz	x0, 4d20 <fwp_hof0.constprop.0+0x5c>
    5558:	a94553f3 	ldp	x19, x20, [sp, #80]
    555c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5560:	a9486bf9 	ldp	x25, x26, [sp, #128]
    5564:	a94973fb 	ldp	x27, x28, [sp, #144]
    5568:	6d4a27e8 	ldp	d8, d9, [sp, #160]
    556c:	fd405bea 	ldr	d10, [sp, #176]
    5570:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    5574:	f947f400 	ldr	x0, [x0, #4072]
    5578:	f9401fe2 	ldr	x2, [sp, #56]
    557c:	f9400001 	ldr	x1, [x0]
    5580:	eb010042 	subs	x2, x2, x1
    5584:	d2800001 	mov	x1, #0x0                   	// #0
    5588:	54002221 	b.ne	59cc <fwp_hof0.constprop.0+0xd08>  // b.any
    558c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5590:	d2800000 	mov	x0, #0x0                   	// #0
    5594:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5598:	910303ff 	add	sp, sp, #0xc0
    559c:	d65f03c0 	ret
    55a0:	f9400ae0 	ldr	x0, [x23, #16]
    55a4:	17fffec7 	b	50c0 <fwp_hof0.constprop.0+0x3fc>
    55a8:	f9400ae4 	ldr	x4, [x23, #16]
    55ac:	fc636880 	ldr	d0, [x4, x3]
    55b0:	1e600800 	fmul	d0, d0, d0
    55b4:	eb02003f 	cmp	x1, x2
    55b8:	54ffdac3 	b.cc	5110 <fwp_hof0.constprop.0+0x44c>  // b.lo, b.ul, b.last
    55bc:	17fffee0 	b	513c <fwp_hof0.constprop.0+0x478>
    55c0:	f9400ae0 	ldr	x0, [x23, #16]
    55c4:	1e6e1003 	fmov	d3, #1.000000000000000000e+00
    55c8:	fc636802 	ldr	d2, [x0, x3]
    55cc:	1e623863 	fsub	d3, d3, d2
    55d0:	17fffeae 	b	5088 <fwp_hof0.constprop.0+0x3c4>
    55d4:	72003c3f 	tst	w1, #0xffff
    55d8:	54ffe041 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    55dc:	17fffef9 	b	51c0 <fwp_hof0.constprop.0+0x4fc>
    55e0:	f94006f8 	ldr	x24, [x23, #8]
    55e4:	aa1703e0 	mov	x0, x23
    55e8:	97fff75e 	bl	3360 <fwp_rc_free_arr>
    55ec:	91140280 	add	x0, x20, #0x500
    55f0:	f949d801 	ldr	x1, [x0, #5040]
    55f4:	f949ec00 	ldr	x0, [x0, #5080]
    55f8:	cb010301 	sub	x1, x24, x1
    55fc:	eb00403f 	cmp	x1, x0, lsl #16
    5600:	54ffdf02 	b.cs	51e0 <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    5604:	aa1803f7 	mov	x23, x24
    5608:	17fffedb 	b	5174 <fwp_hof0.constprop.0+0x4b0>
    560c:	72003c3f 	tst	w1, #0xffff
    5610:	54ffd181 	b.ne	5040 <fwp_hof0.constprop.0+0x37c>  // b.any
    5614:	39400340 	ldrb	w0, [x26]
    5618:	7103fc1f 	cmp	w0, #0xff
    561c:	54ffd0e1 	b.ne	5038 <fwp_hof0.constprop.0+0x374>  // b.any
    5620:	aa1a03e0 	mov	x0, x26
    5624:	97fff560 	bl	2ba4 <fwp_rc_forget_slot>
    5628:	17fffe84 	b	5038 <fwp_hof0.constprop.0+0x374>
    562c:	72003c1f 	tst	w0, #0xffff
    5630:	54ffdd81 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    5634:	17ffff0a 	b	525c <fwp_hof0.constprop.0+0x598>
    5638:	f9400260 	ldr	x0, [x19]
    563c:	b7f804c0 	tbnz	x0, #63, 56d4 <fwp_hof0.constprop.0+0xa10>
    5640:	91140281 	add	x1, x20, #0x500
    5644:	f949d820 	ldr	x0, [x1, #5040]
    5648:	f949ec21 	ldr	x1, [x1, #5080]
    564c:	cb000260 	sub	x0, x19, x0
    5650:	eb01401f 	cmp	x0, x1, lsl #16
    5654:	54fff262 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    5658:	d350fc01 	lsr	x1, x0, #16
    565c:	8b010821 	add	x1, x1, x1, lsl #2
    5660:	d37df021 	lsl	x1, x1, #3
    5664:	8b010064 	add	x4, x3, x1
    5668:	f9401082 	ldr	x2, [x4, #32]
    566c:	b4fff1a2 	cbz	x2, 54a0 <fwp_hof0.constprop.0+0x7dc>
    5670:	38616861 	ldrb	w1, [x3, x1]
    5674:	7100083f 	cmp	w1, #0x2
    5678:	54000c00 	b.eq	57f8 <fwp_hof0.constprop.0+0xb34>  // b.none
    567c:	7100043f 	cmp	w1, #0x1
    5680:	54fff101 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5684:	29430483 	ldp	w3, w1, [x4, #24]
    5688:	92403c00 	and	x0, x0, #0xffff
    568c:	9b037c00 	mul	x0, x0, x3
    5690:	d360fc00 	lsr	x0, x0, #32
    5694:	eb01001f 	cmp	x0, x1
    5698:	54fff042 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    569c:	8b000042 	add	x2, x2, x0
    56a0:	39400040 	ldrb	w0, [x2]
    56a4:	7100041f 	cmp	w0, #0x1
    56a8:	54ffefc1 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    56ac:	aa1303e0 	mov	x0, x19
    56b0:	97fff5dc 	bl	2e20 <fwp_mem_free>
    56b4:	17ffff7b 	b	54a0 <fwp_hof0.constprop.0+0x7dc>
    56b8:	72003c7f 	tst	w3, #0xffff
    56bc:	54ffc600 	b.eq	4f7c <fwp_hof0.constprop.0+0x2b8>  // b.none
    56c0:	aa1303e0 	mov	x0, x19
    56c4:	17fffe32 	b	4f8c <fwp_hof0.constprop.0+0x2c8>
    56c8:	72003c3f 	tst	w1, #0xffff
    56cc:	54ffeea1 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    56d0:	17ffff6b 	b	547c <fwp_hof0.constprop.0+0x7b8>
    56d4:	f9400678 	ldr	x24, [x19, #8]
    56d8:	aa1303e0 	mov	x0, x19
    56dc:	97fff721 	bl	3360 <fwp_rc_free_arr>
    56e0:	91140280 	add	x0, x20, #0x500
    56e4:	f949d801 	ldr	x1, [x0, #5040]
    56e8:	f949ec00 	ldr	x0, [x0, #5080]
    56ec:	cb010301 	sub	x1, x24, x1
    56f0:	eb00403f 	cmp	x1, x0, lsl #16
    56f4:	54ffed62 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    56f8:	aa1803f3 	mov	x19, x24
    56fc:	17ffff4d 	b	5430 <fwp_hof0.constprop.0+0x76c>
    5700:	72003c1f 	tst	w0, #0xffff
    5704:	54ffb400 	b.eq	4d84 <fwp_hof0.constprop.0+0xc0>  // b.none
    5708:	b5ffb4d5 	cbnz	x21, 4da0 <fwp_hof0.constprop.0+0xdc>
    570c:	d2800000 	mov	x0, #0x0                   	// #0
    5710:	97fff7c5 	bl	3624 <fwp_array_new_packed.constprop.0>
    5714:	91140281 	add	x1, x20, #0x500
    5718:	aa0003f7 	mov	x23, x0
    571c:	aa0103e0 	mov	x0, x1
    5720:	f949d821 	ldr	x1, [x1, #5040]
    5724:	f949ec00 	ldr	x0, [x0, #5080]
    5728:	cb0102e1 	sub	x1, x23, x1
    572c:	eb00403f 	cmp	x1, x0, lsl #16
    5730:	54ffb5a3 	b.cc	4de4 <fwp_hof0.constprop.0+0x120>  // b.lo, b.ul, b.last
    5734:	d2800000 	mov	x0, #0x0                   	// #0
    5738:	17fffe18 	b	4f98 <fwp_hof0.constprop.0+0x2d4>
    573c:	72003c3f 	tst	w1, #0xffff
    5740:	54ffb841 	b.ne	4e48 <fwp_hof0.constprop.0+0x184>  // b.any
    5744:	39400260 	ldrb	w0, [x19]
    5748:	7103fc1f 	cmp	w0, #0xff
    574c:	54ffb7a1 	b.ne	4e40 <fwp_hof0.constprop.0+0x17c>  // b.any
    5750:	aa1303e0 	mov	x0, x19
    5754:	97fff514 	bl	2ba4 <fwp_rc_forget_slot>
    5758:	17fffdba 	b	4e40 <fwp_hof0.constprop.0+0x17c>
    575c:	ca584700 	eor	x0, x24, x24, lsr #17
    5760:	91140281 	add	x1, x20, #0x500
    5764:	ca402400 	eor	x0, x0, x0, lsr #9
    5768:	8b200c20 	add	x0, x1, w0, uxtb #3
    576c:	f94a2400 	ldr	x0, [x0, #5192]
    5770:	b5000080 	cbnz	x0, 5780 <fwp_hof0.constprop.0+0xabc>
    5774:	1400006f 	b	5930 <fwp_hof0.constprop.0+0xc6c>
    5778:	f9400800 	ldr	x0, [x0, #16]
    577c:	b4000da0 	cbz	x0, 5930 <fwp_hof0.constprop.0+0xc6c>
    5780:	f9400001 	ldr	x1, [x0]
    5784:	eb01031f 	cmp	x24, x1
    5788:	54ffff81 	b.ne	5778 <fwp_hof0.constprop.0+0xab4>  // b.any
    578c:	f9400401 	ldr	x1, [x0, #8]
    5790:	d1000421 	sub	x1, x1, #0x1
    5794:	f9000401 	str	x1, [x0, #8]
    5798:	f103f83f 	cmp	x1, #0xfe
    579c:	54ffd221 	b.ne	51e0 <fwp_hof0.constprop.0+0x51c>  // b.any
    57a0:	aa1803e0 	mov	x0, x24
    57a4:	97fff500 	bl	2ba4 <fwp_rc_forget_slot>
    57a8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    57ac:	39000300 	strb	w0, [x24]
    57b0:	17fffe8c 	b	51e0 <fwp_hof0.constprop.0+0x51c>
    57b4:	72003c9f 	tst	w4, #0xffff
    57b8:	54ffe341 	b.ne	5420 <fwp_hof0.constprop.0+0x75c>  // b.any
    57bc:	39400300 	ldrb	w0, [x24]
    57c0:	7103fc1f 	cmp	w0, #0xff
    57c4:	54ffe221 	b.ne	5408 <fwp_hof0.constprop.0+0x744>  // b.any
    57c8:	aa1803e0 	mov	x0, x24
    57cc:	97fff4f6 	bl	2ba4 <fwp_rc_forget_slot>
    57d0:	17ffff0e 	b	5408 <fwp_hof0.constprop.0+0x744>
    57d4:	72003c3f 	tst	w1, #0xffff
    57d8:	54ffeb81 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    57dc:	39400260 	ldrb	w0, [x19]
    57e0:	34ffeb40 	cbz	w0, 5548 <fwp_hof0.constprop.0+0x884>
    57e4:	7100041f 	cmp	w0, #0x1
    57e8:	54ffea81 	b.ne	5538 <fwp_hof0.constprop.0+0x874>  // b.any
    57ec:	aa1703e0 	mov	x0, x23
    57f0:	97fff58c 	bl	2e20 <fwp_mem_free>
    57f4:	17ffff55 	b	5548 <fwp_hof0.constprop.0+0x884>
    57f8:	72003c1f 	tst	w0, #0xffff
    57fc:	54ffe521 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5800:	17ffffa8 	b	56a0 <fwp_hof0.constprop.0+0x9dc>
    5804:	ca584700 	eor	x0, x24, x24, lsr #17
    5808:	91140281 	add	x1, x20, #0x500
    580c:	ca402400 	eor	x0, x0, x0, lsr #9
    5810:	8b200c20 	add	x0, x1, w0, uxtb #3
    5814:	f94a2400 	ldr	x0, [x0, #5192]
    5818:	b5000080 	cbnz	x0, 5828 <fwp_hof0.constprop.0+0xb64>
    581c:	14000045 	b	5930 <fwp_hof0.constprop.0+0xc6c>
    5820:	f9400800 	ldr	x0, [x0, #16]
    5824:	b4000860 	cbz	x0, 5930 <fwp_hof0.constprop.0+0xc6c>
    5828:	f9400001 	ldr	x1, [x0]
    582c:	eb01031f 	cmp	x24, x1
    5830:	54ffff81 	b.ne	5820 <fwp_hof0.constprop.0+0xb5c>  // b.any
    5834:	f9400401 	ldr	x1, [x0, #8]
    5838:	d1000421 	sub	x1, x1, #0x1
    583c:	f9000401 	str	x1, [x0, #8]
    5840:	f103f83f 	cmp	x1, #0xfe
    5844:	54ffe2e1 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5848:	aa1803e0 	mov	x0, x24
    584c:	97fff4d6 	bl	2ba4 <fwp_rc_forget_slot>
    5850:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5854:	39000300 	strb	w0, [x24]
    5858:	17ffff12 	b	54a0 <fwp_hof0.constprop.0+0x7dc>
    585c:	ca534661 	eor	x1, x19, x19, lsr #17
    5860:	91140282 	add	x2, x20, #0x500
    5864:	ca412421 	eor	x1, x1, x1, lsr #9
    5868:	92401c21 	and	x1, x1, #0xff
    586c:	910a2423 	add	x3, x1, #0x289
    5870:	8b010c41 	add	x1, x2, x1, lsl #3
    5874:	8b030c57 	add	x23, x2, x3, lsl #3
    5878:	f94a2421 	ldr	x1, [x1, #5192]
    587c:	b50000a1 	cbnz	x1, 5890 <fwp_hof0.constprop.0+0xbcc>
    5880:	1400004b 	b	59ac <fwp_hof0.constprop.0+0xce8>
    5884:	91004037 	add	x23, x1, #0x10
    5888:	f9400821 	ldr	x1, [x1, #16]
    588c:	b40004e1 	cbz	x1, 5928 <fwp_hof0.constprop.0+0xc64>
    5890:	f9400022 	ldr	x2, [x1]
    5894:	eb13005f 	cmp	x2, x19
    5898:	54ffff61 	b.ne	5884 <fwp_hof0.constprop.0+0xbc0>  // b.any
    589c:	f94002e1 	ldr	x1, [x23]
    58a0:	7103f81f 	cmp	w0, #0xfe
    58a4:	54000680 	b.eq	5974 <fwp_hof0.constprop.0+0xcb0>  // b.none
    58a8:	b4000441 	cbz	x1, 5930 <fwp_hof0.constprop.0+0xc6c>
    58ac:	f9400420 	ldr	x0, [x1, #8]
    58b0:	b100041f 	cmn	x0, #0x1
    58b4:	54000760 	b.eq	59a0 <fwp_hof0.constprop.0+0xcdc>  // b.none
    58b8:	91000400 	add	x0, x0, #0x1
    58bc:	f9000420 	str	x0, [x1, #8]
    58c0:	17fffd37 	b	4d9c <fwp_hof0.constprop.0+0xd8>
    58c4:	ca534660 	eor	x0, x19, x19, lsr #17
    58c8:	91140281 	add	x1, x20, #0x500
    58cc:	ca402400 	eor	x0, x0, x0, lsr #9
    58d0:	8b200c20 	add	x0, x1, w0, uxtb #3
    58d4:	f94a2400 	ldr	x0, [x0, #5192]
    58d8:	b5000080 	cbnz	x0, 58e8 <fwp_hof0.constprop.0+0xc24>
    58dc:	14000015 	b	5930 <fwp_hof0.constprop.0+0xc6c>
    58e0:	f9400800 	ldr	x0, [x0, #16]
    58e4:	b4000260 	cbz	x0, 5930 <fwp_hof0.constprop.0+0xc6c>
    58e8:	f9400001 	ldr	x1, [x0]
    58ec:	eb01027f 	cmp	x19, x1
    58f0:	54ffff81 	b.ne	58e0 <fwp_hof0.constprop.0+0xc1c>  // b.any
    58f4:	f9400401 	ldr	x1, [x0, #8]
    58f8:	d1000421 	sub	x1, x1, #0x1
    58fc:	f9000401 	str	x1, [x0, #8]
    5900:	f103f83f 	cmp	x1, #0xfe
    5904:	54ffe221 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    5908:	aa1303e0 	mov	x0, x19
    590c:	97fff4a6 	bl	2ba4 <fwp_rc_forget_slot>
    5910:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5914:	39000260 	strb	w0, [x19]
    5918:	17ffff0c 	b	5548 <fwp_hof0.constprop.0+0x884>
    591c:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5920:	91382000 	add	x0, x0, #0xe08
    5924:	97fff1df 	bl	20a0 <fwp_trap>
    5928:	7103f81f 	cmp	w0, #0xfe
    592c:	54000080 	b.eq	593c <fwp_hof0.constprop.0+0xc78>  // b.none
    5930:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5934:	91322000 	add	x0, x0, #0xc88
    5938:	97fff1da 	bl	20a0 <fwp_trap>
    593c:	d2800300 	mov	x0, #0x18                  	// #24
    5940:	97ffeec0 	bl	1440 <malloc@plt>
    5944:	b40002c0 	cbz	x0, 599c <fwp_hof0.constprop.0+0xcd8>
    5948:	d2801fe1 	mov	x1, #0xff                  	// #255
    594c:	a9000413 	stp	x19, x1, [x0]
    5950:	91140281 	add	x1, x20, #0x500
    5954:	f900081f 	str	xzr, [x0, #16]
    5958:	12800002 	mov	w2, #0xffffffff            	// #-1
    595c:	f90002e0 	str	x0, [x23]
    5960:	39000262 	strb	w2, [x19]
    5964:	f94e2420 	ldr	x0, [x1, #7240]
    5968:	91000400 	add	x0, x0, #0x1
    596c:	f90e2420 	str	x0, [x1, #7240]
    5970:	17fffd0b 	b	4d9c <fwp_hof0.constprop.0+0xd8>
    5974:	b4fffe41 	cbz	x1, 593c <fwp_hof0.constprop.0+0xc78>
    5978:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    597c:	91370000 	add	x0, x0, #0xdc0
    5980:	97fff1c8 	bl	20a0 <fwp_trap>
    5984:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5988:	9132c000 	add	x0, x0, #0xcb0
    598c:	97fff1c5 	bl	20a0 <fwp_trap>
    5990:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5994:	9138c000 	add	x0, x0, #0xe30
    5998:	97fff1c2 	bl	20a0 <fwp_trap>
    599c:	97fff07d 	bl	1b90 <fwp_heap_oom>
    59a0:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    59a4:	9137a000 	add	x0, x0, #0xde8
    59a8:	97fff1be 	bl	20a0 <fwp_trap>
    59ac:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    59b0:	17ffffbc 	b	58a0 <fwp_hof0.constprop.0+0xbdc>
    59b4:	2f00e402 	movi	d2, #0x0
    59b8:	90000020 	adrp	x0, 9000 <msg.3+0x50>
    59bc:	fd400000 	ldr	d0, [x0]
    59c0:	1e622821 	fadd	d1, d1, d2
    59c4:	1e600820 	fmul	d0, d1, d0
    59c8:	17fffdbc 	b	50b8 <fwp_hof0.constprop.0+0x3f4>
    59cc:	a90553f3 	stp	x19, x20, [sp, #80]
    59d0:	a90763f7 	stp	x23, x24, [sp, #112]
    59d4:	a9086bf9 	stp	x25, x26, [sp, #128]
    59d8:	a90973fb 	stp	x27, x28, [sp, #144]
    59dc:	6d0a27e8 	stp	d8, d9, [sp, #160]
    59e0:	fd005bea 	str	d10, [sp, #176]
    59e4:	97ffeeaf 	bl	14a0 <__stack_chk_fail@plt>
    59e8:	97ffef26 	bl	1680 <fwp_trap_overflow.constprop.0>
    59ec:	d503201f 	nop

00000000000059f0 <f0>:
    59f0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    59f4:	910003fd 	mov	x29, sp
    59f8:	a90153f3 	stp	x19, x20, [sp, #16]
    59fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    5a00:	a90363f7 	stp	x23, x24, [sp, #48]
    5a04:	a9046bf9 	stp	x25, x26, [sp, #64]
    5a08:	a90573fb 	stp	x27, x28, [sp, #80]
    5a0c:	d12183ff 	sub	sp, sp, #0x860
    5a10:	f90203ff 	str	xzr, [sp, #1024]
    5a14:	f00000c0 	adrp	x0, 20000 <__data_start>
    5a18:	91018005 	add	x5, x0, #0x60
    5a1c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    5a20:	f947f400 	ldr	x0, [x0, #4072]
    5a24:	90000174 	adrp	x20, 31000 <fwp_root_context+0xce0>
    5a28:	f94130a6 	ldr	x6, [x5, #608]
    5a2c:	f9400001 	ldr	x1, [x0]
    5a30:	f9042fe1 	str	x1, [sp, #2136]
    5a34:	d2800001 	mov	x1, #0x0                   	// #0
    5a38:	91140298 	add	x24, x20, #0x500
    5a3c:	912123f6 	add	x22, sp, #0x848
    5a40:	910023e0 	add	x0, sp, #0x8
    5a44:	910083e2 	add	x2, sp, #0x20
    5a48:	d0ffffe1 	adrp	x1, 3000 <fwp_mem_free+0x1e0>
    5a4c:	90ffffe4 	adrp	x4, 1000 <__abi_tag+0xd88>
    5a50:	911f0021 	add	x1, x1, #0x7c0
    5a54:	912c4084 	add	x4, x4, #0xb10
    5a58:	d2800013 	mov	x19, #0x0                   	// #0
    5a5c:	d2800119 	mov	x25, #0x8                   	// #8
    5a60:	d2800015 	mov	x21, #0x0                   	// #0
    5a64:	52800037 	mov	w23, #0x1                   	// #1
    5a68:	a90093e6 	stp	x6, x4, [sp, #8]
    5a6c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    5a70:	a90307ff 	stp	xzr, x1, [sp, #48]
    5a74:	f90130a0 	str	x0, [x5, #608]
    5a78:	f100073a 	subs	x26, x25, #0x1
    5a7c:	aa1603e0 	mov	x0, x22
    5a80:	da1f02bc 	sbc	x28, x21, xzr
    5a84:	f90017fa 	str	x26, [sp, #40]
    5a88:	f90427fa 	str	x26, [sp, #2120]
    5a8c:	aa1a03f9 	mov	x25, x26
    5a90:	f9042bf3 	str	x19, [sp, #2128]
    5a94:	97fff69b 	bl	3500 <fwp_data.part.0.constprop.0>
    5a98:	f949db02 	ldr	x2, [x24, #5040]
    5a9c:	aa0003f3 	mov	x19, x0
    5aa0:	f949ef00 	ldr	x0, [x24, #5080]
    5aa4:	cb020262 	sub	x2, x19, x2
    5aa8:	aa1c03f5 	mov	x21, x28
    5aac:	eb00405f 	cmp	x2, x0, lsl #16
    5ab0:	54000302 	b.cs	5b10 <f0+0x120>  // b.hs, b.nlast
    5ab4:	d350fc40 	lsr	x0, x2, #16
    5ab8:	f949ff04 	ldr	x4, [x24, #5112]
    5abc:	8b000800 	add	x0, x0, x0, lsl #2
    5ac0:	d37df001 	lsl	x1, x0, #3
    5ac4:	8b010080 	add	x0, x4, x1
    5ac8:	f940101b 	ldr	x27, [x0, #32]
    5acc:	b400023b 	cbz	x27, 5b10 <f0+0x120>
    5ad0:	38616881 	ldrb	w1, [x4, x1]
    5ad4:	7100083f 	cmp	w1, #0x2
    5ad8:	5400fe60 	b.eq	7aa4 <f0+0x20b4>  // b.none
    5adc:	7100043f 	cmp	w1, #0x1
    5ae0:	54000181 	b.ne	5b10 <f0+0x120>  // b.any
    5ae4:	29430001 	ldp	w1, w0, [x0, #24]
    5ae8:	92403c42 	and	x2, x2, #0xffff
    5aec:	9b017c42 	mul	x2, x2, x1
    5af0:	d360fc42 	lsr	x2, x2, #32
    5af4:	eb00005f 	cmp	x2, x0
    5af8:	540000c2 	b.cs	5b10 <f0+0x120>  // b.hs, b.nlast
    5afc:	8b02037b 	add	x27, x27, x2
    5b00:	39400360 	ldrb	w0, [x27]
    5b04:	7103fc1f 	cmp	w0, #0xff
    5b08:	5400fc80 	b.eq	7a98 <f0+0x20a8>  // b.none
    5b0c:	39000377 	strb	w23, [x27]
    5b10:	f90013f3 	str	x19, [sp, #32]
    5b14:	aa1c035a 	orr	x26, x26, x28
    5b18:	b5fffb1a 	cbnz	x26, 5a78 <f0+0x88>
    5b1c:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    5b20:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    5b24:	f94007e1 	ldr	x1, [sp, #8]
    5b28:	3dc3fc00 	ldr	q0, [x0, #4080]
    5b2c:	f00000c0 	adrp	x0, 20000 <__data_start>
    5b30:	91018018 	add	x24, x0, #0x60
    5b34:	910103e0 	add	x0, sp, #0x40
    5b38:	3d8013e0 	str	q0, [sp, #64]
    5b3c:	f9013301 	str	x1, [x24, #608]
    5b40:	97fff670 	bl	3500 <fwp_data.part.0.constprop.0>
    5b44:	97fff5d7 	bl	32a0 <fwp_rc_fresh>
    5b48:	aa0003e1 	mov	x1, x0
    5b4c:	910163e0 	add	x0, sp, #0x58
    5b50:	a90587f5 	stp	x21, x1, [sp, #88]
    5b54:	97fff66b 	bl	3500 <fwp_data.part.0.constprop.0>
    5b58:	97fff5d2 	bl	32a0 <fwp_rc_fresh>
    5b5c:	aa0003e1 	mov	x1, x0
    5b60:	f0000002 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    5b64:	9101a3e0 	add	x0, sp, #0x68
    5b68:	f9003be1 	str	x1, [sp, #112]
    5b6c:	3dc3fc40 	ldr	q0, [x2, #4080]
    5b70:	fd0037e0 	str	d0, [sp, #104]
    5b74:	97fff663 	bl	3500 <fwp_data.part.0.constprop.0>
    5b78:	97fff5ca 	bl	32a0 <fwp_rc_fresh>
    5b7c:	aa0003e1 	mov	x1, x0
    5b80:	9101e3e0 	add	x0, sp, #0x78
    5b84:	a90787f5 	stp	x21, x1, [sp, #120]
    5b88:	97fff65e 	bl	3500 <fwp_data.part.0.constprop.0>
    5b8c:	97fff5c5 	bl	32a0 <fwp_rc_fresh>
    5b90:	aa0003e1 	mov	x1, x0
    5b94:	f0000002 	adrp	x2, 8000 <fwp_main_thread+0x1a0>
    5b98:	910223e0 	add	x0, sp, #0x88
    5b9c:	f9004be1 	str	x1, [sp, #144]
    5ba0:	3dc3fc40 	ldr	q0, [x2, #4080]
    5ba4:	fd0047e0 	str	d0, [sp, #136]
    5ba8:	97fff656 	bl	3500 <fwp_data.part.0.constprop.0>
    5bac:	91140283 	add	x3, x20, #0x500
    5bb0:	aa0003f5 	mov	x21, x0
    5bb4:	f949d861 	ldr	x1, [x3, #5040]
    5bb8:	f949ec60 	ldr	x0, [x3, #5080]
    5bbc:	cb0102a1 	sub	x1, x21, x1
    5bc0:	eb00403f 	cmp	x1, x0, lsl #16
    5bc4:	54000322 	b.cs	5c28 <f0+0x238>  // b.hs, b.nlast
    5bc8:	d350fc22 	lsr	x2, x1, #16
    5bcc:	f949fc63 	ldr	x3, [x3, #5112]
    5bd0:	8b020842 	add	x2, x2, x2, lsl #2
    5bd4:	d37df042 	lsl	x2, x2, #3
    5bd8:	8b020060 	add	x0, x3, x2
    5bdc:	f9401017 	ldr	x23, [x0, #32]
    5be0:	b4000257 	cbz	x23, 5c28 <f0+0x238>
    5be4:	38626862 	ldrb	w2, [x3, x2]
    5be8:	7100085f 	cmp	w2, #0x2
    5bec:	5400f9e0 	b.eq	7b28 <f0+0x2138>  // b.none
    5bf0:	7100045f 	cmp	w2, #0x1
    5bf4:	540001a1 	b.ne	5c28 <f0+0x238>  // b.any
    5bf8:	29430002 	ldp	w2, w0, [x0, #24]
    5bfc:	92403c21 	and	x1, x1, #0xffff
    5c00:	9b027c21 	mul	x1, x1, x2
    5c04:	d360fc21 	lsr	x1, x1, #32
    5c08:	eb00003f 	cmp	x1, x0
    5c0c:	540000e2 	b.cs	5c28 <f0+0x238>  // b.hs, b.nlast
    5c10:	8b0102f7 	add	x23, x23, x1
    5c14:	394002e0 	ldrb	w0, [x23]
    5c18:	7103fc1f 	cmp	w0, #0xff
    5c1c:	540103a0 	b.eq	7c90 <f0+0x22a0>  // b.none
    5c20:	52800020 	mov	w0, #0x1                   	// #1
    5c24:	390002e0 	strb	w0, [x23]
    5c28:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    5c2c:	910263e0 	add	x0, sp, #0x98
    5c30:	a909d7f7 	stp	x23, x21, [sp, #152]
    5c34:	97fff633 	bl	3500 <fwp_data.part.0.constprop.0>
    5c38:	97fff59a 	bl	32a0 <fwp_rc_fresh>
    5c3c:	aa0003e1 	mov	x1, x0
    5c40:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    5c44:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    5c48:	9102a3e0 	add	x0, sp, #0xa8
    5c4c:	a90a87f5 	stp	x21, x1, [sp, #168]
    5c50:	97fff62c 	bl	3500 <fwp_data.part.0.constprop.0>
    5c54:	97fff593 	bl	32a0 <fwp_rc_fresh>
    5c58:	aa0003e1 	mov	x1, x0
    5c5c:	9102e3e0 	add	x0, sp, #0xb8
    5c60:	a90b87f7 	stp	x23, x1, [sp, #184]
    5c64:	97fff627 	bl	3500 <fwp_data.part.0.constprop.0>
    5c68:	97fff58e 	bl	32a0 <fwp_rc_fresh>
    5c6c:	aa0003e1 	mov	x1, x0
    5c70:	910323e0 	add	x0, sp, #0xc8
    5c74:	a90c87f5 	stp	x21, x1, [sp, #200]
    5c78:	97fff622 	bl	3500 <fwp_data.part.0.constprop.0>
    5c7c:	97fff589 	bl	32a0 <fwp_rc_fresh>
    5c80:	aa0003e1 	mov	x1, x0
    5c84:	910363e0 	add	x0, sp, #0xd8
    5c88:	a90d87f7 	stp	x23, x1, [sp, #216]
    5c8c:	97fff61d 	bl	3500 <fwp_data.part.0.constprop.0>
    5c90:	97fff584 	bl	32a0 <fwp_rc_fresh>
    5c94:	aa0003e1 	mov	x1, x0
    5c98:	9103a3e0 	add	x0, sp, #0xe8
    5c9c:	a90e87f5 	stp	x21, x1, [sp, #232]
    5ca0:	97fff618 	bl	3500 <fwp_data.part.0.constprop.0>
    5ca4:	97fff57f 	bl	32a0 <fwp_rc_fresh>
    5ca8:	aa0003e1 	mov	x1, x0
    5cac:	9103e3e0 	add	x0, sp, #0xf8
    5cb0:	a90f87f7 	stp	x23, x1, [sp, #248]
    5cb4:	97fff613 	bl	3500 <fwp_data.part.0.constprop.0>
    5cb8:	97fff57a 	bl	32a0 <fwp_rc_fresh>
    5cbc:	aa0003e1 	mov	x1, x0
    5cc0:	910423e0 	add	x0, sp, #0x108
    5cc4:	a91087f5 	stp	x21, x1, [sp, #264]
    5cc8:	97fff60e 	bl	3500 <fwp_data.part.0.constprop.0>
    5ccc:	97fff575 	bl	32a0 <fwp_rc_fresh>
    5cd0:	aa0003e1 	mov	x1, x0
    5cd4:	910463e0 	add	x0, sp, #0x118
    5cd8:	a91187f7 	stp	x23, x1, [sp, #280]
    5cdc:	97fff609 	bl	3500 <fwp_data.part.0.constprop.0>
    5ce0:	97fff570 	bl	32a0 <fwp_rc_fresh>
    5ce4:	aa0003e1 	mov	x1, x0
    5ce8:	9104a3e0 	add	x0, sp, #0x128
    5cec:	a91287f5 	stp	x21, x1, [sp, #296]
    5cf0:	97fff604 	bl	3500 <fwp_data.part.0.constprop.0>
    5cf4:	97fff56b 	bl	32a0 <fwp_rc_fresh>
    5cf8:	aa0003e1 	mov	x1, x0
    5cfc:	9104e3e0 	add	x0, sp, #0x138
    5d00:	a91387f7 	stp	x23, x1, [sp, #312]
    5d04:	97fff5ff 	bl	3500 <fwp_data.part.0.constprop.0>
    5d08:	97fff566 	bl	32a0 <fwp_rc_fresh>
    5d0c:	aa0003e1 	mov	x1, x0
    5d10:	910523e0 	add	x0, sp, #0x148
    5d14:	a91487f5 	stp	x21, x1, [sp, #328]
    5d18:	97fff5fa 	bl	3500 <fwp_data.part.0.constprop.0>
    5d1c:	97fff561 	bl	32a0 <fwp_rc_fresh>
    5d20:	aa0003e1 	mov	x1, x0
    5d24:	910563e0 	add	x0, sp, #0x158
    5d28:	a91587f7 	stp	x23, x1, [sp, #344]
    5d2c:	97fff5f5 	bl	3500 <fwp_data.part.0.constprop.0>
    5d30:	97fff55c 	bl	32a0 <fwp_rc_fresh>
    5d34:	aa0003e1 	mov	x1, x0
    5d38:	9105a3e0 	add	x0, sp, #0x168
    5d3c:	a91687f5 	stp	x21, x1, [sp, #360]
    5d40:	97fff5f0 	bl	3500 <fwp_data.part.0.constprop.0>
    5d44:	aa0003f5 	mov	x21, x0
    5d48:	91140283 	add	x3, x20, #0x500
    5d4c:	f949d861 	ldr	x1, [x3, #5040]
    5d50:	f949ec60 	ldr	x0, [x3, #5080]
    5d54:	cb0102a1 	sub	x1, x21, x1
    5d58:	eb00403f 	cmp	x1, x0, lsl #16
    5d5c:	54000322 	b.cs	5dc0 <f0+0x3d0>  // b.hs, b.nlast
    5d60:	d350fc22 	lsr	x2, x1, #16
    5d64:	f949fc63 	ldr	x3, [x3, #5112]
    5d68:	8b020842 	add	x2, x2, x2, lsl #2
    5d6c:	d37df042 	lsl	x2, x2, #3
    5d70:	8b020060 	add	x0, x3, x2
    5d74:	f9401017 	ldr	x23, [x0, #32]
    5d78:	b4000257 	cbz	x23, 5dc0 <f0+0x3d0>
    5d7c:	38626862 	ldrb	w2, [x3, x2]
    5d80:	7100085f 	cmp	w2, #0x2
    5d84:	5400ecc0 	b.eq	7b1c <f0+0x212c>  // b.none
    5d88:	7100045f 	cmp	w2, #0x1
    5d8c:	540001a1 	b.ne	5dc0 <f0+0x3d0>  // b.any
    5d90:	29430002 	ldp	w2, w0, [x0, #24]
    5d94:	92403c21 	and	x1, x1, #0xffff
    5d98:	9b027c21 	mul	x1, x1, x2
    5d9c:	d360fc21 	lsr	x1, x1, #32
    5da0:	eb00003f 	cmp	x1, x0
    5da4:	540000e2 	b.cs	5dc0 <f0+0x3d0>  // b.hs, b.nlast
    5da8:	8b0102f7 	add	x23, x23, x1
    5dac:	394002e0 	ldrb	w0, [x23]
    5db0:	7103fc1f 	cmp	w0, #0xff
    5db4:	5400f740 	b.eq	7c9c <f0+0x22ac>  // b.none
    5db8:	52800020 	mov	w0, #0x1                   	// #1
    5dbc:	390002e0 	strb	w0, [x23]
    5dc0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5dc4:	9105e3e0 	add	x0, sp, #0x178
    5dc8:	a917d7e1 	stp	x1, x21, [sp, #376]
    5dcc:	97fff5cd 	bl	3500 <fwp_data.part.0.constprop.0>
    5dd0:	91140283 	add	x3, x20, #0x500
    5dd4:	aa0003f5 	mov	x21, x0
    5dd8:	f949d861 	ldr	x1, [x3, #5040]
    5ddc:	f949ec60 	ldr	x0, [x3, #5080]
    5de0:	cb0102a1 	sub	x1, x21, x1
    5de4:	eb00403f 	cmp	x1, x0, lsl #16
    5de8:	54000322 	b.cs	5e4c <f0+0x45c>  // b.hs, b.nlast
    5dec:	d350fc22 	lsr	x2, x1, #16
    5df0:	f949fc63 	ldr	x3, [x3, #5112]
    5df4:	8b020842 	add	x2, x2, x2, lsl #2
    5df8:	d37df042 	lsl	x2, x2, #3
    5dfc:	8b020060 	add	x0, x3, x2
    5e00:	f9401017 	ldr	x23, [x0, #32]
    5e04:	b4000257 	cbz	x23, 5e4c <f0+0x45c>
    5e08:	38626862 	ldrb	w2, [x3, x2]
    5e0c:	7100085f 	cmp	w2, #0x2
    5e10:	5400e800 	b.eq	7b10 <f0+0x2120>  // b.none
    5e14:	7100045f 	cmp	w2, #0x1
    5e18:	540001a1 	b.ne	5e4c <f0+0x45c>  // b.any
    5e1c:	29430002 	ldp	w2, w0, [x0, #24]
    5e20:	92403c21 	and	x1, x1, #0xffff
    5e24:	9b027c21 	mul	x1, x1, x2
    5e28:	d360fc21 	lsr	x1, x1, #32
    5e2c:	eb00003f 	cmp	x1, x0
    5e30:	540000e2 	b.cs	5e4c <f0+0x45c>  // b.hs, b.nlast
    5e34:	8b0102f7 	add	x23, x23, x1
    5e38:	394002e0 	ldrb	w0, [x23]
    5e3c:	7103fc1f 	cmp	w0, #0xff
    5e40:	5400f340 	b.eq	7ca8 <f0+0x22b8>  // b.none
    5e44:	52800020 	mov	w0, #0x1                   	// #1
    5e48:	390002e0 	strb	w0, [x23]
    5e4c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    5e50:	910623e0 	add	x0, sp, #0x188
    5e54:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    5e58:	a918d7e1 	stp	x1, x21, [sp, #392]
    5e5c:	97fff5a9 	bl	3500 <fwp_data.part.0.constprop.0>
    5e60:	aa0003f5 	mov	x21, x0
    5e64:	91140283 	add	x3, x20, #0x500
    5e68:	f949d861 	ldr	x1, [x3, #5040]
    5e6c:	f949ec60 	ldr	x0, [x3, #5080]
    5e70:	cb0102a1 	sub	x1, x21, x1
    5e74:	eb00403f 	cmp	x1, x0, lsl #16
    5e78:	54000322 	b.cs	5edc <f0+0x4ec>  // b.hs, b.nlast
    5e7c:	d350fc22 	lsr	x2, x1, #16
    5e80:	f949fc63 	ldr	x3, [x3, #5112]
    5e84:	8b020842 	add	x2, x2, x2, lsl #2
    5e88:	d37df042 	lsl	x2, x2, #3
    5e8c:	8b020060 	add	x0, x3, x2
    5e90:	f9401017 	ldr	x23, [x0, #32]
    5e94:	b4000257 	cbz	x23, 5edc <f0+0x4ec>
    5e98:	38626862 	ldrb	w2, [x3, x2]
    5e9c:	7100085f 	cmp	w2, #0x2
    5ea0:	5400e5c0 	b.eq	7b58 <f0+0x2168>  // b.none
    5ea4:	7100045f 	cmp	w2, #0x1
    5ea8:	540001a1 	b.ne	5edc <f0+0x4ec>  // b.any
    5eac:	29430002 	ldp	w2, w0, [x0, #24]
    5eb0:	92403c21 	and	x1, x1, #0xffff
    5eb4:	9b027c21 	mul	x1, x1, x2
    5eb8:	d360fc21 	lsr	x1, x1, #32
    5ebc:	eb00003f 	cmp	x1, x0
    5ec0:	540000e2 	b.cs	5edc <f0+0x4ec>  // b.hs, b.nlast
    5ec4:	8b0102f7 	add	x23, x23, x1
    5ec8:	394002e0 	ldrb	w0, [x23]
    5ecc:	7103fc1f 	cmp	w0, #0xff
    5ed0:	5400ef20 	b.eq	7cb4 <f0+0x22c4>  // b.none
    5ed4:	52800020 	mov	w0, #0x1                   	// #1
    5ed8:	390002e0 	strb	w0, [x23]
    5edc:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5ee0:	910663e0 	add	x0, sp, #0x198
    5ee4:	a919d7e1 	stp	x1, x21, [sp, #408]
    5ee8:	97fff586 	bl	3500 <fwp_data.part.0.constprop.0>
    5eec:	97fff4ed 	bl	32a0 <fwp_rc_fresh>
    5ef0:	aa0003e1 	mov	x1, x0
    5ef4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5ef8:	9106a3e0 	add	x0, sp, #0x1a8
    5efc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5f00:	a91a87e2 	stp	x2, x1, [sp, #424]
    5f04:	97fff57f 	bl	3500 <fwp_data.part.0.constprop.0>
    5f08:	aa0003f5 	mov	x21, x0
    5f0c:	91140283 	add	x3, x20, #0x500
    5f10:	f949d861 	ldr	x1, [x3, #5040]
    5f14:	f949ec60 	ldr	x0, [x3, #5080]
    5f18:	cb0102a1 	sub	x1, x21, x1
    5f1c:	eb00403f 	cmp	x1, x0, lsl #16
    5f20:	54000322 	b.cs	5f84 <f0+0x594>  // b.hs, b.nlast
    5f24:	d350fc22 	lsr	x2, x1, #16
    5f28:	f949fc63 	ldr	x3, [x3, #5112]
    5f2c:	8b020842 	add	x2, x2, x2, lsl #2
    5f30:	d37df042 	lsl	x2, x2, #3
    5f34:	8b020060 	add	x0, x3, x2
    5f38:	f9401017 	ldr	x23, [x0, #32]
    5f3c:	b4000257 	cbz	x23, 5f84 <f0+0x594>
    5f40:	38626862 	ldrb	w2, [x3, x2]
    5f44:	7100085f 	cmp	w2, #0x2
    5f48:	5400e020 	b.eq	7b4c <f0+0x215c>  // b.none
    5f4c:	7100045f 	cmp	w2, #0x1
    5f50:	540001a1 	b.ne	5f84 <f0+0x594>  // b.any
    5f54:	29430002 	ldp	w2, w0, [x0, #24]
    5f58:	92403c21 	and	x1, x1, #0xffff
    5f5c:	9b027c21 	mul	x1, x1, x2
    5f60:	d360fc21 	lsr	x1, x1, #32
    5f64:	eb00003f 	cmp	x1, x0
    5f68:	540000e2 	b.cs	5f84 <f0+0x594>  // b.hs, b.nlast
    5f6c:	8b0102f7 	add	x23, x23, x1
    5f70:	394002e0 	ldrb	w0, [x23]
    5f74:	7103fc1f 	cmp	w0, #0xff
    5f78:	5400ea40 	b.eq	7cc0 <f0+0x22d0>  // b.none
    5f7c:	52800020 	mov	w0, #0x1                   	// #1
    5f80:	390002e0 	strb	w0, [x23]
    5f84:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5f88:	9106e3e0 	add	x0, sp, #0x1b8
    5f8c:	a91bd7e1 	stp	x1, x21, [sp, #440]
    5f90:	97fff55c 	bl	3500 <fwp_data.part.0.constprop.0>
    5f94:	97fff4c3 	bl	32a0 <fwp_rc_fresh>
    5f98:	aa0003e1 	mov	x1, x0
    5f9c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5fa0:	910723e0 	add	x0, sp, #0x1c8
    5fa4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5fa8:	a91c87e2 	stp	x2, x1, [sp, #456]
    5fac:	97fff555 	bl	3500 <fwp_data.part.0.constprop.0>
    5fb0:	aa0003f5 	mov	x21, x0
    5fb4:	91140283 	add	x3, x20, #0x500
    5fb8:	f949d861 	ldr	x1, [x3, #5040]
    5fbc:	f949ec60 	ldr	x0, [x3, #5080]
    5fc0:	cb0102a1 	sub	x1, x21, x1
    5fc4:	eb00403f 	cmp	x1, x0, lsl #16
    5fc8:	54000322 	b.cs	602c <f0+0x63c>  // b.hs, b.nlast
    5fcc:	d350fc22 	lsr	x2, x1, #16
    5fd0:	f949fc63 	ldr	x3, [x3, #5112]
    5fd4:	8b020842 	add	x2, x2, x2, lsl #2
    5fd8:	d37df042 	lsl	x2, x2, #3
    5fdc:	8b020060 	add	x0, x3, x2
    5fe0:	f9401017 	ldr	x23, [x0, #32]
    5fe4:	b4000257 	cbz	x23, 602c <f0+0x63c>
    5fe8:	38626862 	ldrb	w2, [x3, x2]
    5fec:	7100085f 	cmp	w2, #0x2
    5ff0:	5400da80 	b.eq	7b40 <f0+0x2150>  // b.none
    5ff4:	7100045f 	cmp	w2, #0x1
    5ff8:	540001a1 	b.ne	602c <f0+0x63c>  // b.any
    5ffc:	29430002 	ldp	w2, w0, [x0, #24]
    6000:	92403c21 	and	x1, x1, #0xffff
    6004:	9b027c21 	mul	x1, x1, x2
    6008:	d360fc21 	lsr	x1, x1, #32
    600c:	eb00003f 	cmp	x1, x0
    6010:	540000e2 	b.cs	602c <f0+0x63c>  // b.hs, b.nlast
    6014:	8b0102f7 	add	x23, x23, x1
    6018:	394002e0 	ldrb	w0, [x23]
    601c:	7103fc1f 	cmp	w0, #0xff
    6020:	5400e560 	b.eq	7ccc <f0+0x22dc>  // b.none
    6024:	52800020 	mov	w0, #0x1                   	// #1
    6028:	390002e0 	strb	w0, [x23]
    602c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6030:	910763e0 	add	x0, sp, #0x1d8
    6034:	a91dd7e1 	stp	x1, x21, [sp, #472]
    6038:	97fff532 	bl	3500 <fwp_data.part.0.constprop.0>
    603c:	97fff499 	bl	32a0 <fwp_rc_fresh>
    6040:	aa0003e1 	mov	x1, x0
    6044:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6048:	9107a3e0 	add	x0, sp, #0x1e8
    604c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6050:	a91e87e2 	stp	x2, x1, [sp, #488]
    6054:	97fff52b 	bl	3500 <fwp_data.part.0.constprop.0>
    6058:	aa0003f5 	mov	x21, x0
    605c:	91140283 	add	x3, x20, #0x500
    6060:	f949d861 	ldr	x1, [x3, #5040]
    6064:	f949ec60 	ldr	x0, [x3, #5080]
    6068:	cb0102a1 	sub	x1, x21, x1
    606c:	eb00403f 	cmp	x1, x0, lsl #16
    6070:	54000322 	b.cs	60d4 <f0+0x6e4>  // b.hs, b.nlast
    6074:	d350fc22 	lsr	x2, x1, #16
    6078:	f949fc63 	ldr	x3, [x3, #5112]
    607c:	8b020842 	add	x2, x2, x2, lsl #2
    6080:	d37df042 	lsl	x2, x2, #3
    6084:	8b020060 	add	x0, x3, x2
    6088:	f9401017 	ldr	x23, [x0, #32]
    608c:	b4000257 	cbz	x23, 60d4 <f0+0x6e4>
    6090:	38626862 	ldrb	w2, [x3, x2]
    6094:	7100085f 	cmp	w2, #0x2
    6098:	5400d4e0 	b.eq	7b34 <f0+0x2144>  // b.none
    609c:	7100045f 	cmp	w2, #0x1
    60a0:	540001a1 	b.ne	60d4 <f0+0x6e4>  // b.any
    60a4:	29430002 	ldp	w2, w0, [x0, #24]
    60a8:	92403c21 	and	x1, x1, #0xffff
    60ac:	9b027c21 	mul	x1, x1, x2
    60b0:	d360fc21 	lsr	x1, x1, #32
    60b4:	eb00003f 	cmp	x1, x0
    60b8:	540000e2 	b.cs	60d4 <f0+0x6e4>  // b.hs, b.nlast
    60bc:	8b0102f7 	add	x23, x23, x1
    60c0:	394002e0 	ldrb	w0, [x23]
    60c4:	7103fc1f 	cmp	w0, #0xff
    60c8:	5400e080 	b.eq	7cd8 <f0+0x22e8>  // b.none
    60cc:	52800020 	mov	w0, #0x1                   	// #1
    60d0:	390002e0 	strb	w0, [x23]
    60d4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    60d8:	9107e3e0 	add	x0, sp, #0x1f8
    60dc:	a91fd7e1 	stp	x1, x21, [sp, #504]
    60e0:	97fff508 	bl	3500 <fwp_data.part.0.constprop.0>
    60e4:	97fff46f 	bl	32a0 <fwp_rc_fresh>
    60e8:	aa0003e1 	mov	x1, x0
    60ec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    60f0:	910823e0 	add	x0, sp, #0x208
    60f4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    60f8:	f90107e2 	str	x2, [sp, #520]
    60fc:	f9010be1 	str	x1, [sp, #528]
    6100:	97fff500 	bl	3500 <fwp_data.part.0.constprop.0>
    6104:	aa0003f5 	mov	x21, x0
    6108:	91140283 	add	x3, x20, #0x500
    610c:	f949d861 	ldr	x1, [x3, #5040]
    6110:	f949ec60 	ldr	x0, [x3, #5080]
    6114:	cb0102a1 	sub	x1, x21, x1
    6118:	eb00403f 	cmp	x1, x0, lsl #16
    611c:	54000322 	b.cs	6180 <f0+0x790>  // b.hs, b.nlast
    6120:	d350fc22 	lsr	x2, x1, #16
    6124:	f949fc63 	ldr	x3, [x3, #5112]
    6128:	8b020842 	add	x2, x2, x2, lsl #2
    612c:	d37df042 	lsl	x2, x2, #3
    6130:	8b020060 	add	x0, x3, x2
    6134:	f9401017 	ldr	x23, [x0, #32]
    6138:	b4000257 	cbz	x23, 6180 <f0+0x790>
    613c:	38626862 	ldrb	w2, [x3, x2]
    6140:	7100085f 	cmp	w2, #0x2
    6144:	5400d3a0 	b.eq	7bb8 <f0+0x21c8>  // b.none
    6148:	7100045f 	cmp	w2, #0x1
    614c:	540001a1 	b.ne	6180 <f0+0x790>  // b.any
    6150:	29430002 	ldp	w2, w0, [x0, #24]
    6154:	92403c21 	and	x1, x1, #0xffff
    6158:	9b027c21 	mul	x1, x1, x2
    615c:	d360fc21 	lsr	x1, x1, #32
    6160:	eb00003f 	cmp	x1, x0
    6164:	540000e2 	b.cs	6180 <f0+0x790>  // b.hs, b.nlast
    6168:	8b0102f7 	add	x23, x23, x1
    616c:	394002e0 	ldrb	w0, [x23]
    6170:	7103fc1f 	cmp	w0, #0xff
    6174:	5400db80 	b.eq	7ce4 <f0+0x22f4>  // b.none
    6178:	52800020 	mov	w0, #0x1                   	// #1
    617c:	390002e0 	strb	w0, [x23]
    6180:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6184:	910863e0 	add	x0, sp, #0x218
    6188:	f9010fe1 	str	x1, [sp, #536]
    618c:	f90113f5 	str	x21, [sp, #544]
    6190:	97fff4dc 	bl	3500 <fwp_data.part.0.constprop.0>
    6194:	97fff443 	bl	32a0 <fwp_rc_fresh>
    6198:	aa0003e1 	mov	x1, x0
    619c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    61a0:	9108a3e0 	add	x0, sp, #0x228
    61a4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    61a8:	f90117e2 	str	x2, [sp, #552]
    61ac:	f9011be1 	str	x1, [sp, #560]
    61b0:	97fff4d4 	bl	3500 <fwp_data.part.0.constprop.0>
    61b4:	aa0003f5 	mov	x21, x0
    61b8:	91140283 	add	x3, x20, #0x500
    61bc:	f949d861 	ldr	x1, [x3, #5040]
    61c0:	f949ec60 	ldr	x0, [x3, #5080]
    61c4:	cb0102a1 	sub	x1, x21, x1
    61c8:	eb00403f 	cmp	x1, x0, lsl #16
    61cc:	54000322 	b.cs	6230 <f0+0x840>  // b.hs, b.nlast
    61d0:	d350fc22 	lsr	x2, x1, #16
    61d4:	f949fc63 	ldr	x3, [x3, #5112]
    61d8:	8b020842 	add	x2, x2, x2, lsl #2
    61dc:	d37df042 	lsl	x2, x2, #3
    61e0:	8b020060 	add	x0, x3, x2
    61e4:	f9401017 	ldr	x23, [x0, #32]
    61e8:	b4000257 	cbz	x23, 6230 <f0+0x840>
    61ec:	38626862 	ldrb	w2, [x3, x2]
    61f0:	7100085f 	cmp	w2, #0x2
    61f4:	5400cdc0 	b.eq	7bac <f0+0x21bc>  // b.none
    61f8:	7100045f 	cmp	w2, #0x1
    61fc:	540001a1 	b.ne	6230 <f0+0x840>  // b.any
    6200:	29430002 	ldp	w2, w0, [x0, #24]
    6204:	92403c21 	and	x1, x1, #0xffff
    6208:	9b027c21 	mul	x1, x1, x2
    620c:	d360fc21 	lsr	x1, x1, #32
    6210:	eb00003f 	cmp	x1, x0
    6214:	540000e2 	b.cs	6230 <f0+0x840>  // b.hs, b.nlast
    6218:	8b0102f7 	add	x23, x23, x1
    621c:	394002e0 	ldrb	w0, [x23]
    6220:	7103fc1f 	cmp	w0, #0xff
    6224:	5400d660 	b.eq	7cf0 <f0+0x2300>  // b.none
    6228:	52800020 	mov	w0, #0x1                   	// #1
    622c:	390002e0 	strb	w0, [x23]
    6230:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6234:	9108e3e0 	add	x0, sp, #0x238
    6238:	f9011fe1 	str	x1, [sp, #568]
    623c:	f90123f5 	str	x21, [sp, #576]
    6240:	97fff4b0 	bl	3500 <fwp_data.part.0.constprop.0>
    6244:	97fff417 	bl	32a0 <fwp_rc_fresh>
    6248:	aa0003e1 	mov	x1, x0
    624c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6250:	910923e0 	add	x0, sp, #0x248
    6254:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6258:	f90127e2 	str	x2, [sp, #584]
    625c:	f9012be1 	str	x1, [sp, #592]
    6260:	97fff4a8 	bl	3500 <fwp_data.part.0.constprop.0>
    6264:	aa0003f5 	mov	x21, x0
    6268:	91140283 	add	x3, x20, #0x500
    626c:	f949d861 	ldr	x1, [x3, #5040]
    6270:	f949ec60 	ldr	x0, [x3, #5080]
    6274:	cb0102a1 	sub	x1, x21, x1
    6278:	eb00403f 	cmp	x1, x0, lsl #16
    627c:	54000322 	b.cs	62e0 <f0+0x8f0>  // b.hs, b.nlast
    6280:	d350fc22 	lsr	x2, x1, #16
    6284:	f949fc63 	ldr	x3, [x3, #5112]
    6288:	8b020842 	add	x2, x2, x2, lsl #2
    628c:	d37df042 	lsl	x2, x2, #3
    6290:	8b020060 	add	x0, x3, x2
    6294:	f9401017 	ldr	x23, [x0, #32]
    6298:	b4000257 	cbz	x23, 62e0 <f0+0x8f0>
    629c:	38626862 	ldrb	w2, [x3, x2]
    62a0:	7100085f 	cmp	w2, #0x2
    62a4:	5400c7e0 	b.eq	7ba0 <f0+0x21b0>  // b.none
    62a8:	7100045f 	cmp	w2, #0x1
    62ac:	540001a1 	b.ne	62e0 <f0+0x8f0>  // b.any
    62b0:	29430002 	ldp	w2, w0, [x0, #24]
    62b4:	92403c21 	and	x1, x1, #0xffff
    62b8:	9b027c21 	mul	x1, x1, x2
    62bc:	d360fc21 	lsr	x1, x1, #32
    62c0:	eb00003f 	cmp	x1, x0
    62c4:	540000e2 	b.cs	62e0 <f0+0x8f0>  // b.hs, b.nlast
    62c8:	8b0102f7 	add	x23, x23, x1
    62cc:	394002e0 	ldrb	w0, [x23]
    62d0:	7103fc1f 	cmp	w0, #0xff
    62d4:	5400d140 	b.eq	7cfc <f0+0x230c>  // b.none
    62d8:	52800020 	mov	w0, #0x1                   	// #1
    62dc:	390002e0 	strb	w0, [x23]
    62e0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    62e4:	910963e0 	add	x0, sp, #0x258
    62e8:	f9012ff7 	str	x23, [sp, #600]
    62ec:	f90133f5 	str	x21, [sp, #608]
    62f0:	97fff484 	bl	3500 <fwp_data.part.0.constprop.0>
    62f4:	97fff3eb 	bl	32a0 <fwp_rc_fresh>
    62f8:	aa0003e1 	mov	x1, x0
    62fc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6300:	9109a3e0 	add	x0, sp, #0x268
    6304:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6308:	f90137f5 	str	x21, [sp, #616]
    630c:	f9013be1 	str	x1, [sp, #624]
    6310:	97fff47c 	bl	3500 <fwp_data.part.0.constprop.0>
    6314:	97fff3e3 	bl	32a0 <fwp_rc_fresh>
    6318:	aa0003e1 	mov	x1, x0
    631c:	9109e3e0 	add	x0, sp, #0x278
    6320:	f9013ff7 	str	x23, [sp, #632]
    6324:	f90143e1 	str	x1, [sp, #640]
    6328:	97fff476 	bl	3500 <fwp_data.part.0.constprop.0>
    632c:	97fff3dd 	bl	32a0 <fwp_rc_fresh>
    6330:	aa0003e1 	mov	x1, x0
    6334:	910a23e0 	add	x0, sp, #0x288
    6338:	f90147f5 	str	x21, [sp, #648]
    633c:	f9014be1 	str	x1, [sp, #656]
    6340:	97fff470 	bl	3500 <fwp_data.part.0.constprop.0>
    6344:	aa0003f5 	mov	x21, x0
    6348:	91140283 	add	x3, x20, #0x500
    634c:	f949d861 	ldr	x1, [x3, #5040]
    6350:	f949ec60 	ldr	x0, [x3, #5080]
    6354:	cb0102a1 	sub	x1, x21, x1
    6358:	eb00403f 	cmp	x1, x0, lsl #16
    635c:	54000322 	b.cs	63c0 <f0+0x9d0>  // b.hs, b.nlast
    6360:	d350fc22 	lsr	x2, x1, #16
    6364:	f949fc63 	ldr	x3, [x3, #5112]
    6368:	8b020842 	add	x2, x2, x2, lsl #2
    636c:	d37df042 	lsl	x2, x2, #3
    6370:	8b020060 	add	x0, x3, x2
    6374:	f9401017 	ldr	x23, [x0, #32]
    6378:	b4000257 	cbz	x23, 63c0 <f0+0x9d0>
    637c:	38626862 	ldrb	w2, [x3, x2]
    6380:	7100085f 	cmp	w2, #0x2
    6384:	5400c080 	b.eq	7b94 <f0+0x21a4>  // b.none
    6388:	7100045f 	cmp	w2, #0x1
    638c:	540001a1 	b.ne	63c0 <f0+0x9d0>  // b.any
    6390:	29430002 	ldp	w2, w0, [x0, #24]
    6394:	92403c21 	and	x1, x1, #0xffff
    6398:	9b027c21 	mul	x1, x1, x2
    639c:	d360fc21 	lsr	x1, x1, #32
    63a0:	eb00003f 	cmp	x1, x0
    63a4:	540000e2 	b.cs	63c0 <f0+0x9d0>  // b.hs, b.nlast
    63a8:	8b0102f7 	add	x23, x23, x1
    63ac:	394002e0 	ldrb	w0, [x23]
    63b0:	7103fc1f 	cmp	w0, #0xff
    63b4:	5400caa0 	b.eq	7d08 <f0+0x2318>  // b.none
    63b8:	52800020 	mov	w0, #0x1                   	// #1
    63bc:	390002e0 	strb	w0, [x23]
    63c0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    63c4:	910a63e0 	add	x0, sp, #0x298
    63c8:	f9014fe1 	str	x1, [sp, #664]
    63cc:	f90153f5 	str	x21, [sp, #672]
    63d0:	97fff44c 	bl	3500 <fwp_data.part.0.constprop.0>
    63d4:	97fff3b3 	bl	32a0 <fwp_rc_fresh>
    63d8:	aa0003e1 	mov	x1, x0
    63dc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    63e0:	910aa3e0 	add	x0, sp, #0x2a8
    63e4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    63e8:	f90157e2 	str	x2, [sp, #680]
    63ec:	f9015be1 	str	x1, [sp, #688]
    63f0:	97fff444 	bl	3500 <fwp_data.part.0.constprop.0>
    63f4:	aa0003f5 	mov	x21, x0
    63f8:	91140283 	add	x3, x20, #0x500
    63fc:	f949d861 	ldr	x1, [x3, #5040]
    6400:	f949ec60 	ldr	x0, [x3, #5080]
    6404:	cb0102a1 	sub	x1, x21, x1
    6408:	eb00403f 	cmp	x1, x0, lsl #16
    640c:	54000322 	b.cs	6470 <f0+0xa80>  // b.hs, b.nlast
    6410:	d350fc22 	lsr	x2, x1, #16
    6414:	f949fc63 	ldr	x3, [x3, #5112]
    6418:	8b020842 	add	x2, x2, x2, lsl #2
    641c:	d37df042 	lsl	x2, x2, #3
    6420:	8b020060 	add	x0, x3, x2
    6424:	f9401017 	ldr	x23, [x0, #32]
    6428:	b4000257 	cbz	x23, 6470 <f0+0xa80>
    642c:	38626862 	ldrb	w2, [x3, x2]
    6430:	7100085f 	cmp	w2, #0x2
    6434:	5400baa0 	b.eq	7b88 <f0+0x2198>  // b.none
    6438:	7100045f 	cmp	w2, #0x1
    643c:	540001a1 	b.ne	6470 <f0+0xa80>  // b.any
    6440:	29430002 	ldp	w2, w0, [x0, #24]
    6444:	92403c21 	and	x1, x1, #0xffff
    6448:	9b027c21 	mul	x1, x1, x2
    644c:	d360fc21 	lsr	x1, x1, #32
    6450:	eb00003f 	cmp	x1, x0
    6454:	540000e2 	b.cs	6470 <f0+0xa80>  // b.hs, b.nlast
    6458:	8b0102f7 	add	x23, x23, x1
    645c:	394002e0 	ldrb	w0, [x23]
    6460:	7103fc1f 	cmp	w0, #0xff
    6464:	5400c580 	b.eq	7d14 <f0+0x2324>  // b.none
    6468:	52800020 	mov	w0, #0x1                   	// #1
    646c:	390002e0 	strb	w0, [x23]
    6470:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6474:	910ae3e0 	add	x0, sp, #0x2b8
    6478:	f9015fe1 	str	x1, [sp, #696]
    647c:	f90163f5 	str	x21, [sp, #704]
    6480:	97fff420 	bl	3500 <fwp_data.part.0.constprop.0>
    6484:	91140283 	add	x3, x20, #0x500
    6488:	aa0003f5 	mov	x21, x0
    648c:	f949d861 	ldr	x1, [x3, #5040]
    6490:	f949ec60 	ldr	x0, [x3, #5080]
    6494:	cb0102a1 	sub	x1, x21, x1
    6498:	eb00403f 	cmp	x1, x0, lsl #16
    649c:	54000322 	b.cs	6500 <f0+0xb10>  // b.hs, b.nlast
    64a0:	d350fc22 	lsr	x2, x1, #16
    64a4:	f949fc63 	ldr	x3, [x3, #5112]
    64a8:	8b020842 	add	x2, x2, x2, lsl #2
    64ac:	d37df042 	lsl	x2, x2, #3
    64b0:	8b020060 	add	x0, x3, x2
    64b4:	f9401017 	ldr	x23, [x0, #32]
    64b8:	b4000257 	cbz	x23, 6500 <f0+0xb10>
    64bc:	38626862 	ldrb	w2, [x3, x2]
    64c0:	7100085f 	cmp	w2, #0x2
    64c4:	5400b5c0 	b.eq	7b7c <f0+0x218c>  // b.none
    64c8:	7100045f 	cmp	w2, #0x1
    64cc:	540001a1 	b.ne	6500 <f0+0xb10>  // b.any
    64d0:	29430002 	ldp	w2, w0, [x0, #24]
    64d4:	92403c21 	and	x1, x1, #0xffff
    64d8:	9b027c21 	mul	x1, x1, x2
    64dc:	d360fc21 	lsr	x1, x1, #32
    64e0:	eb00003f 	cmp	x1, x0
    64e4:	540000e2 	b.cs	6500 <f0+0xb10>  // b.hs, b.nlast
    64e8:	8b0102f7 	add	x23, x23, x1
    64ec:	394002e0 	ldrb	w0, [x23]
    64f0:	7103fc1f 	cmp	w0, #0xff
    64f4:	5400c160 	b.eq	7d20 <f0+0x2330>  // b.none
    64f8:	52800020 	mov	w0, #0x1                   	// #1
    64fc:	390002e0 	strb	w0, [x23]
    6500:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6504:	910b23e0 	add	x0, sp, #0x2c8
    6508:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    650c:	f90167e1 	str	x1, [sp, #712]
    6510:	f9016bf5 	str	x21, [sp, #720]
    6514:	97fff3fb 	bl	3500 <fwp_data.part.0.constprop.0>
    6518:	aa0003f5 	mov	x21, x0
    651c:	91140283 	add	x3, x20, #0x500
    6520:	f949d861 	ldr	x1, [x3, #5040]
    6524:	f949ec60 	ldr	x0, [x3, #5080]
    6528:	cb0102a1 	sub	x1, x21, x1
    652c:	eb00403f 	cmp	x1, x0, lsl #16
    6530:	54000322 	b.cs	6594 <f0+0xba4>  // b.hs, b.nlast
    6534:	d350fc22 	lsr	x2, x1, #16
    6538:	f949fc63 	ldr	x3, [x3, #5112]
    653c:	8b020842 	add	x2, x2, x2, lsl #2
    6540:	d37df042 	lsl	x2, x2, #3
    6544:	8b020060 	add	x0, x3, x2
    6548:	f9401017 	ldr	x23, [x0, #32]
    654c:	b4000257 	cbz	x23, 6594 <f0+0xba4>
    6550:	38626862 	ldrb	w2, [x3, x2]
    6554:	7100085f 	cmp	w2, #0x2
    6558:	5400b0c0 	b.eq	7b70 <f0+0x2180>  // b.none
    655c:	7100045f 	cmp	w2, #0x1
    6560:	540001a1 	b.ne	6594 <f0+0xba4>  // b.any
    6564:	29430002 	ldp	w2, w0, [x0, #24]
    6568:	92403c21 	and	x1, x1, #0xffff
    656c:	9b027c21 	mul	x1, x1, x2
    6570:	d360fc21 	lsr	x1, x1, #32
    6574:	eb00003f 	cmp	x1, x0
    6578:	540000e2 	b.cs	6594 <f0+0xba4>  // b.hs, b.nlast
    657c:	8b0102f7 	add	x23, x23, x1
    6580:	394002e0 	ldrb	w0, [x23]
    6584:	7103fc1f 	cmp	w0, #0xff
    6588:	5400bd20 	b.eq	7d2c <f0+0x233c>  // b.none
    658c:	52800020 	mov	w0, #0x1                   	// #1
    6590:	390002e0 	strb	w0, [x23]
    6594:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6598:	910b63e0 	add	x0, sp, #0x2d8
    659c:	f9016ff7 	str	x23, [sp, #728]
    65a0:	f90173f5 	str	x21, [sp, #736]
    65a4:	97fff3d7 	bl	3500 <fwp_data.part.0.constprop.0>
    65a8:	97fff33e 	bl	32a0 <fwp_rc_fresh>
    65ac:	aa0003e1 	mov	x1, x0
    65b0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    65b4:	910ba3e0 	add	x0, sp, #0x2e8
    65b8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    65bc:	f90177e2 	str	x2, [sp, #744]
    65c0:	f9017be1 	str	x1, [sp, #752]
    65c4:	97fff3cf 	bl	3500 <fwp_data.part.0.constprop.0>
    65c8:	97fff336 	bl	32a0 <fwp_rc_fresh>
    65cc:	aa0003e1 	mov	x1, x0
    65d0:	910be3e0 	add	x0, sp, #0x2f8
    65d4:	f9017ff7 	str	x23, [sp, #760]
    65d8:	f90183e1 	str	x1, [sp, #768]
    65dc:	97fff3c9 	bl	3500 <fwp_data.part.0.constprop.0>
    65e0:	aa0003f5 	mov	x21, x0
    65e4:	91140283 	add	x3, x20, #0x500
    65e8:	f949d861 	ldr	x1, [x3, #5040]
    65ec:	f949ec60 	ldr	x0, [x3, #5080]
    65f0:	cb0102a1 	sub	x1, x21, x1
    65f4:	eb00403f 	cmp	x1, x0, lsl #16
    65f8:	54000322 	b.cs	665c <f0+0xc6c>  // b.hs, b.nlast
    65fc:	d350fc22 	lsr	x2, x1, #16
    6600:	f949fc63 	ldr	x3, [x3, #5112]
    6604:	8b020842 	add	x2, x2, x2, lsl #2
    6608:	d37df042 	lsl	x2, x2, #3
    660c:	8b020060 	add	x0, x3, x2
    6610:	f9401017 	ldr	x23, [x0, #32]
    6614:	b4000257 	cbz	x23, 665c <f0+0xc6c>
    6618:	38626862 	ldrb	w2, [x3, x2]
    661c:	7100085f 	cmp	w2, #0x2
    6620:	5400aa20 	b.eq	7b64 <f0+0x2174>  // b.none
    6624:	7100045f 	cmp	w2, #0x1
    6628:	540001a1 	b.ne	665c <f0+0xc6c>  // b.any
    662c:	29430002 	ldp	w2, w0, [x0, #24]
    6630:	92403c21 	and	x1, x1, #0xffff
    6634:	9b027c21 	mul	x1, x1, x2
    6638:	d360fc21 	lsr	x1, x1, #32
    663c:	eb00003f 	cmp	x1, x0
    6640:	540000e2 	b.cs	665c <f0+0xc6c>  // b.hs, b.nlast
    6644:	8b0102f7 	add	x23, x23, x1
    6648:	394002e0 	ldrb	w0, [x23]
    664c:	7103fc1f 	cmp	w0, #0xff
    6650:	5400b740 	b.eq	7d38 <f0+0x2348>  // b.none
    6654:	52800020 	mov	w0, #0x1                   	// #1
    6658:	390002e0 	strb	w0, [x23]
    665c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6660:	910c23e0 	add	x0, sp, #0x308
    6664:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6668:	f90187e1 	str	x1, [sp, #776]
    666c:	f9018bf5 	str	x21, [sp, #784]
    6670:	97fff3a4 	bl	3500 <fwp_data.part.0.constprop.0>
    6674:	aa0003f5 	mov	x21, x0
    6678:	91140283 	add	x3, x20, #0x500
    667c:	f949d861 	ldr	x1, [x3, #5040]
    6680:	f949ec60 	ldr	x0, [x3, #5080]
    6684:	cb0102a1 	sub	x1, x21, x1
    6688:	eb00403f 	cmp	x1, x0, lsl #16
    668c:	54000322 	b.cs	66f0 <f0+0xd00>  // b.hs, b.nlast
    6690:	d350fc22 	lsr	x2, x1, #16
    6694:	f949fc63 	ldr	x3, [x3, #5112]
    6698:	8b020842 	add	x2, x2, x2, lsl #2
    669c:	d37df042 	lsl	x2, x2, #3
    66a0:	8b020060 	add	x0, x3, x2
    66a4:	f9401017 	ldr	x23, [x0, #32]
    66a8:	b4000257 	cbz	x23, 66f0 <f0+0xd00>
    66ac:	38626862 	ldrb	w2, [x3, x2]
    66b0:	7100085f 	cmp	w2, #0x2
    66b4:	5400a280 	b.eq	7b04 <f0+0x2114>  // b.none
    66b8:	7100045f 	cmp	w2, #0x1
    66bc:	540001a1 	b.ne	66f0 <f0+0xd00>  // b.any
    66c0:	29430002 	ldp	w2, w0, [x0, #24]
    66c4:	92403c21 	and	x1, x1, #0xffff
    66c8:	9b027c21 	mul	x1, x1, x2
    66cc:	d360fc21 	lsr	x1, x1, #32
    66d0:	eb00003f 	cmp	x1, x0
    66d4:	540000e2 	b.cs	66f0 <f0+0xd00>  // b.hs, b.nlast
    66d8:	8b0102f7 	add	x23, x23, x1
    66dc:	394002e0 	ldrb	w0, [x23]
    66e0:	7103fc1f 	cmp	w0, #0xff
    66e4:	5400b300 	b.eq	7d44 <f0+0x2354>  // b.none
    66e8:	52800020 	mov	w0, #0x1                   	// #1
    66ec:	390002e0 	strb	w0, [x23]
    66f0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    66f4:	910c63e0 	add	x0, sp, #0x318
    66f8:	f9018ff7 	str	x23, [sp, #792]
    66fc:	f90193f5 	str	x21, [sp, #800]
    6700:	97fff380 	bl	3500 <fwp_data.part.0.constprop.0>
    6704:	97fff2e7 	bl	32a0 <fwp_rc_fresh>
    6708:	aa0003e1 	mov	x1, x0
    670c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6710:	910ca3e0 	add	x0, sp, #0x328
    6714:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6718:	f90197f5 	str	x21, [sp, #808]
    671c:	f9019be1 	str	x1, [sp, #816]
    6720:	97fff378 	bl	3500 <fwp_data.part.0.constprop.0>
    6724:	97fff2df 	bl	32a0 <fwp_rc_fresh>
    6728:	aa0003e1 	mov	x1, x0
    672c:	910ce3e0 	add	x0, sp, #0x338
    6730:	f9019ff7 	str	x23, [sp, #824]
    6734:	f901a3e1 	str	x1, [sp, #832]
    6738:	97fff372 	bl	3500 <fwp_data.part.0.constprop.0>
    673c:	97fff2d9 	bl	32a0 <fwp_rc_fresh>
    6740:	aa0003e1 	mov	x1, x0
    6744:	910d23e0 	add	x0, sp, #0x348
    6748:	f901a7f5 	str	x21, [sp, #840]
    674c:	f901abe1 	str	x1, [sp, #848]
    6750:	97fff36c 	bl	3500 <fwp_data.part.0.constprop.0>
    6754:	aa0003f5 	mov	x21, x0
    6758:	91140283 	add	x3, x20, #0x500
    675c:	f949d861 	ldr	x1, [x3, #5040]
    6760:	f949ec60 	ldr	x0, [x3, #5080]
    6764:	cb0102a1 	sub	x1, x21, x1
    6768:	eb00403f 	cmp	x1, x0, lsl #16
    676c:	54000322 	b.cs	67d0 <f0+0xde0>  // b.hs, b.nlast
    6770:	d350fc22 	lsr	x2, x1, #16
    6774:	f949fc63 	ldr	x3, [x3, #5112]
    6778:	8b020842 	add	x2, x2, x2, lsl #2
    677c:	d37df042 	lsl	x2, x2, #3
    6780:	8b020060 	add	x0, x3, x2
    6784:	f9401017 	ldr	x23, [x0, #32]
    6788:	b4000257 	cbz	x23, 67d0 <f0+0xde0>
    678c:	38626862 	ldrb	w2, [x3, x2]
    6790:	7100085f 	cmp	w2, #0x2
    6794:	54009b20 	b.eq	7af8 <f0+0x2108>  // b.none
    6798:	7100045f 	cmp	w2, #0x1
    679c:	540001a1 	b.ne	67d0 <f0+0xde0>  // b.any
    67a0:	29430002 	ldp	w2, w0, [x0, #24]
    67a4:	92403c21 	and	x1, x1, #0xffff
    67a8:	9b027c21 	mul	x1, x1, x2
    67ac:	d360fc21 	lsr	x1, x1, #32
    67b0:	eb00003f 	cmp	x1, x0
    67b4:	540000e2 	b.cs	67d0 <f0+0xde0>  // b.hs, b.nlast
    67b8:	8b0102f7 	add	x23, x23, x1
    67bc:	394002e0 	ldrb	w0, [x23]
    67c0:	7103fc1f 	cmp	w0, #0xff
    67c4:	5400ac60 	b.eq	7d50 <f0+0x2360>  // b.none
    67c8:	52800020 	mov	w0, #0x1                   	// #1
    67cc:	390002e0 	strb	w0, [x23]
    67d0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    67d4:	910d63e0 	add	x0, sp, #0x358
    67d8:	f901aff7 	str	x23, [sp, #856]
    67dc:	f901b3f5 	str	x21, [sp, #864]
    67e0:	97fff348 	bl	3500 <fwp_data.part.0.constprop.0>
    67e4:	97fff2af 	bl	32a0 <fwp_rc_fresh>
    67e8:	aa0003e1 	mov	x1, x0
    67ec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    67f0:	910da3e0 	add	x0, sp, #0x368
    67f4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    67f8:	f901b7e2 	str	x2, [sp, #872]
    67fc:	f901bbe1 	str	x1, [sp, #880]
    6800:	97fff340 	bl	3500 <fwp_data.part.0.constprop.0>
    6804:	97fff2a7 	bl	32a0 <fwp_rc_fresh>
    6808:	aa0003e1 	mov	x1, x0
    680c:	910de3e0 	add	x0, sp, #0x378
    6810:	f901bff7 	str	x23, [sp, #888]
    6814:	f901c3e1 	str	x1, [sp, #896]
    6818:	97fff33a 	bl	3500 <fwp_data.part.0.constprop.0>
    681c:	aa0003f5 	mov	x21, x0
    6820:	91140283 	add	x3, x20, #0x500
    6824:	f949d861 	ldr	x1, [x3, #5040]
    6828:	f949ec60 	ldr	x0, [x3, #5080]
    682c:	cb0102a1 	sub	x1, x21, x1
    6830:	eb00403f 	cmp	x1, x0, lsl #16
    6834:	54000322 	b.cs	6898 <f0+0xea8>  // b.hs, b.nlast
    6838:	d350fc22 	lsr	x2, x1, #16
    683c:	f949fc63 	ldr	x3, [x3, #5112]
    6840:	8b020842 	add	x2, x2, x2, lsl #2
    6844:	d37df042 	lsl	x2, x2, #3
    6848:	8b020060 	add	x0, x3, x2
    684c:	f9401017 	ldr	x23, [x0, #32]
    6850:	b4000257 	cbz	x23, 6898 <f0+0xea8>
    6854:	38626862 	ldrb	w2, [x3, x2]
    6858:	7100085f 	cmp	w2, #0x2
    685c:	54009480 	b.eq	7aec <f0+0x20fc>  // b.none
    6860:	7100045f 	cmp	w2, #0x1
    6864:	540001a1 	b.ne	6898 <f0+0xea8>  // b.any
    6868:	29430002 	ldp	w2, w0, [x0, #24]
    686c:	92403c21 	and	x1, x1, #0xffff
    6870:	9b027c21 	mul	x1, x1, x2
    6874:	d360fc21 	lsr	x1, x1, #32
    6878:	eb00003f 	cmp	x1, x0
    687c:	540000e2 	b.cs	6898 <f0+0xea8>  // b.hs, b.nlast
    6880:	8b0102f7 	add	x23, x23, x1
    6884:	394002e0 	ldrb	w0, [x23]
    6888:	7103fc1f 	cmp	w0, #0xff
    688c:	5400a680 	b.eq	7d5c <f0+0x236c>  // b.none
    6890:	52800020 	mov	w0, #0x1                   	// #1
    6894:	390002e0 	strb	w0, [x23]
    6898:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    689c:	910e23e0 	add	x0, sp, #0x388
    68a0:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    68a4:	f901c7e1 	str	x1, [sp, #904]
    68a8:	f901cbf5 	str	x21, [sp, #912]
    68ac:	97fff315 	bl	3500 <fwp_data.part.0.constprop.0>
    68b0:	aa0003f5 	mov	x21, x0
    68b4:	91140283 	add	x3, x20, #0x500
    68b8:	f949d861 	ldr	x1, [x3, #5040]
    68bc:	f949ec60 	ldr	x0, [x3, #5080]
    68c0:	cb0102a1 	sub	x1, x21, x1
    68c4:	eb00403f 	cmp	x1, x0, lsl #16
    68c8:	54000322 	b.cs	692c <f0+0xf3c>  // b.hs, b.nlast
    68cc:	d350fc22 	lsr	x2, x1, #16
    68d0:	f949fc63 	ldr	x3, [x3, #5112]
    68d4:	8b020842 	add	x2, x2, x2, lsl #2
    68d8:	d37df042 	lsl	x2, x2, #3
    68dc:	8b020060 	add	x0, x3, x2
    68e0:	f9401017 	ldr	x23, [x0, #32]
    68e4:	b4000257 	cbz	x23, 692c <f0+0xf3c>
    68e8:	38626862 	ldrb	w2, [x3, x2]
    68ec:	7100085f 	cmp	w2, #0x2
    68f0:	54008f80 	b.eq	7ae0 <f0+0x20f0>  // b.none
    68f4:	7100045f 	cmp	w2, #0x1
    68f8:	540001a1 	b.ne	692c <f0+0xf3c>  // b.any
    68fc:	29430002 	ldp	w2, w0, [x0, #24]
    6900:	92403c21 	and	x1, x1, #0xffff
    6904:	9b027c21 	mul	x1, x1, x2
    6908:	d360fc21 	lsr	x1, x1, #32
    690c:	eb00003f 	cmp	x1, x0
    6910:	540000e2 	b.cs	692c <f0+0xf3c>  // b.hs, b.nlast
    6914:	8b0102f7 	add	x23, x23, x1
    6918:	394002e0 	ldrb	w0, [x23]
    691c:	7103fc1f 	cmp	w0, #0xff
    6920:	5400a240 	b.eq	7d68 <f0+0x2378>  // b.none
    6924:	52800020 	mov	w0, #0x1                   	// #1
    6928:	390002e0 	strb	w0, [x23]
    692c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6930:	910e63e0 	add	x0, sp, #0x398
    6934:	f901cfe1 	str	x1, [sp, #920]
    6938:	f901d3f5 	str	x21, [sp, #928]
    693c:	97fff2f1 	bl	3500 <fwp_data.part.0.constprop.0>
    6940:	91140283 	add	x3, x20, #0x500
    6944:	aa0003f7 	mov	x23, x0
    6948:	f949d861 	ldr	x1, [x3, #5040]
    694c:	f949ec60 	ldr	x0, [x3, #5080]
    6950:	cb0102e1 	sub	x1, x23, x1
    6954:	eb00403f 	cmp	x1, x0, lsl #16
    6958:	54000322 	b.cs	69bc <f0+0xfcc>  // b.hs, b.nlast
    695c:	d350fc22 	lsr	x2, x1, #16
    6960:	f949fc63 	ldr	x3, [x3, #5112]
    6964:	8b020842 	add	x2, x2, x2, lsl #2
    6968:	d37df042 	lsl	x2, x2, #3
    696c:	8b020060 	add	x0, x3, x2
    6970:	f9401015 	ldr	x21, [x0, #32]
    6974:	b4000255 	cbz	x21, 69bc <f0+0xfcc>
    6978:	38626862 	ldrb	w2, [x3, x2]
    697c:	7100085f 	cmp	w2, #0x2
    6980:	54008aa0 	b.eq	7ad4 <f0+0x20e4>  // b.none
    6984:	7100045f 	cmp	w2, #0x1
    6988:	540001a1 	b.ne	69bc <f0+0xfcc>  // b.any
    698c:	29430002 	ldp	w2, w0, [x0, #24]
    6990:	92403c21 	and	x1, x1, #0xffff
    6994:	9b027c21 	mul	x1, x1, x2
    6998:	d360fc21 	lsr	x1, x1, #32
    699c:	eb00003f 	cmp	x1, x0
    69a0:	540000e2 	b.cs	69bc <f0+0xfcc>  // b.hs, b.nlast
    69a4:	8b0102b5 	add	x21, x21, x1
    69a8:	394002a0 	ldrb	w0, [x21]
    69ac:	7103fc1f 	cmp	w0, #0xff
    69b0:	54009e20 	b.eq	7d74 <f0+0x2384>  // b.none
    69b4:	52800020 	mov	w0, #0x1                   	// #1
    69b8:	390002a0 	strb	w0, [x21]
    69bc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    69c0:	910ea3e0 	add	x0, sp, #0x3a8
    69c4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    69c8:	f901d7f5 	str	x21, [sp, #936]
    69cc:	f901dbf7 	str	x23, [sp, #944]
    69d0:	97fff2cc 	bl	3500 <fwp_data.part.0.constprop.0>
    69d4:	97fff233 	bl	32a0 <fwp_rc_fresh>
    69d8:	aa0003e1 	mov	x1, x0
    69dc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    69e0:	910ee3e0 	add	x0, sp, #0x3b8
    69e4:	f901dff7 	str	x23, [sp, #952]
    69e8:	f901e3e1 	str	x1, [sp, #960]
    69ec:	97fff2c5 	bl	3500 <fwp_data.part.0.constprop.0>
    69f0:	97fff22c 	bl	32a0 <fwp_rc_fresh>
    69f4:	aa0003e1 	mov	x1, x0
    69f8:	910f23e0 	add	x0, sp, #0x3c8
    69fc:	f901e7f5 	str	x21, [sp, #968]
    6a00:	f901ebe1 	str	x1, [sp, #976]
    6a04:	97fff2bf 	bl	3500 <fwp_data.part.0.constprop.0>
    6a08:	97fff226 	bl	32a0 <fwp_rc_fresh>
    6a0c:	aa0003e1 	mov	x1, x0
    6a10:	910f63e0 	add	x0, sp, #0x3d8
    6a14:	f901eff7 	str	x23, [sp, #984]
    6a18:	f901f3e1 	str	x1, [sp, #992]
    6a1c:	97fff2b9 	bl	3500 <fwp_data.part.0.constprop.0>
    6a20:	97fff220 	bl	32a0 <fwp_rc_fresh>
    6a24:	aa0003e1 	mov	x1, x0
    6a28:	910fa3e0 	add	x0, sp, #0x3e8
    6a2c:	f901f7f5 	str	x21, [sp, #1000]
    6a30:	f901fbe1 	str	x1, [sp, #1008]
    6a34:	97fff2b3 	bl	3500 <fwp_data.part.0.constprop.0>
    6a38:	97fff21a 	bl	32a0 <fwp_rc_fresh>
    6a3c:	aa0003e1 	mov	x1, x0
    6a40:	910fe3e0 	add	x0, sp, #0x3f8
    6a44:	f901fff7 	str	x23, [sp, #1016]
    6a48:	f90203e1 	str	x1, [sp, #1024]
    6a4c:	97fff2ad 	bl	3500 <fwp_data.part.0.constprop.0>
    6a50:	97fff214 	bl	32a0 <fwp_rc_fresh>
    6a54:	aa0003e1 	mov	x1, x0
    6a58:	911023e0 	add	x0, sp, #0x408
    6a5c:	f90207f5 	str	x21, [sp, #1032]
    6a60:	f9020be1 	str	x1, [sp, #1040]
    6a64:	97fff2a7 	bl	3500 <fwp_data.part.0.constprop.0>
    6a68:	aa0003f5 	mov	x21, x0
    6a6c:	91140283 	add	x3, x20, #0x500
    6a70:	f949d861 	ldr	x1, [x3, #5040]
    6a74:	f949ec60 	ldr	x0, [x3, #5080]
    6a78:	cb0102a1 	sub	x1, x21, x1
    6a7c:	eb00403f 	cmp	x1, x0, lsl #16
    6a80:	54000322 	b.cs	6ae4 <f0+0x10f4>  // b.hs, b.nlast
    6a84:	d350fc22 	lsr	x2, x1, #16
    6a88:	f949fc63 	ldr	x3, [x3, #5112]
    6a8c:	8b020842 	add	x2, x2, x2, lsl #2
    6a90:	d37df042 	lsl	x2, x2, #3
    6a94:	8b020060 	add	x0, x3, x2
    6a98:	f9401017 	ldr	x23, [x0, #32]
    6a9c:	b4000257 	cbz	x23, 6ae4 <f0+0x10f4>
    6aa0:	38626862 	ldrb	w2, [x3, x2]
    6aa4:	7100085f 	cmp	w2, #0x2
    6aa8:	54008100 	b.eq	7ac8 <f0+0x20d8>  // b.none
    6aac:	7100045f 	cmp	w2, #0x1
    6ab0:	540001a1 	b.ne	6ae4 <f0+0x10f4>  // b.any
    6ab4:	29430002 	ldp	w2, w0, [x0, #24]
    6ab8:	92403c21 	and	x1, x1, #0xffff
    6abc:	9b027c21 	mul	x1, x1, x2
    6ac0:	d360fc21 	lsr	x1, x1, #32
    6ac4:	eb00003f 	cmp	x1, x0
    6ac8:	540000e2 	b.cs	6ae4 <f0+0x10f4>  // b.hs, b.nlast
    6acc:	8b0102f7 	add	x23, x23, x1
    6ad0:	394002e0 	ldrb	w0, [x23]
    6ad4:	7103fc1f 	cmp	w0, #0xff
    6ad8:	54009540 	b.eq	7d80 <f0+0x2390>  // b.none
    6adc:	52800020 	mov	w0, #0x1                   	// #1
    6ae0:	390002e0 	strb	w0, [x23]
    6ae4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6ae8:	911063e0 	add	x0, sp, #0x418
    6aec:	f9020ff7 	str	x23, [sp, #1048]
    6af0:	f90213f5 	str	x21, [sp, #1056]
    6af4:	97fff283 	bl	3500 <fwp_data.part.0.constprop.0>
    6af8:	97fff1ea 	bl	32a0 <fwp_rc_fresh>
    6afc:	aa0003e1 	mov	x1, x0
    6b00:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6b04:	9110a3e0 	add	x0, sp, #0x428
    6b08:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6b0c:	f90217f5 	str	x21, [sp, #1064]
    6b10:	f9021be1 	str	x1, [sp, #1072]
    6b14:	97fff27b 	bl	3500 <fwp_data.part.0.constprop.0>
    6b18:	97fff1e2 	bl	32a0 <fwp_rc_fresh>
    6b1c:	aa0003e1 	mov	x1, x0
    6b20:	9110e3e0 	add	x0, sp, #0x438
    6b24:	f9021ff7 	str	x23, [sp, #1080]
    6b28:	f90223e1 	str	x1, [sp, #1088]
    6b2c:	97fff275 	bl	3500 <fwp_data.part.0.constprop.0>
    6b30:	97fff1dc 	bl	32a0 <fwp_rc_fresh>
    6b34:	aa0003e1 	mov	x1, x0
    6b38:	911123e0 	add	x0, sp, #0x448
    6b3c:	f90227f5 	str	x21, [sp, #1096]
    6b40:	f9022be1 	str	x1, [sp, #1104]
    6b44:	97fff26f 	bl	3500 <fwp_data.part.0.constprop.0>
    6b48:	aa0003f5 	mov	x21, x0
    6b4c:	91140283 	add	x3, x20, #0x500
    6b50:	f949d861 	ldr	x1, [x3, #5040]
    6b54:	f949ec60 	ldr	x0, [x3, #5080]
    6b58:	cb0102a1 	sub	x1, x21, x1
    6b5c:	eb00403f 	cmp	x1, x0, lsl #16
    6b60:	54000322 	b.cs	6bc4 <f0+0x11d4>  // b.hs, b.nlast
    6b64:	d350fc22 	lsr	x2, x1, #16
    6b68:	f949fc63 	ldr	x3, [x3, #5112]
    6b6c:	8b020842 	add	x2, x2, x2, lsl #2
    6b70:	d37df042 	lsl	x2, x2, #3
    6b74:	8b020060 	add	x0, x3, x2
    6b78:	f9401017 	ldr	x23, [x0, #32]
    6b7c:	b4000257 	cbz	x23, 6bc4 <f0+0x11d4>
    6b80:	38626862 	ldrb	w2, [x3, x2]
    6b84:	7100085f 	cmp	w2, #0x2
    6b88:	540079a0 	b.eq	7abc <f0+0x20cc>  // b.none
    6b8c:	7100045f 	cmp	w2, #0x1
    6b90:	540001a1 	b.ne	6bc4 <f0+0x11d4>  // b.any
    6b94:	29430002 	ldp	w2, w0, [x0, #24]
    6b98:	92403c21 	and	x1, x1, #0xffff
    6b9c:	9b027c21 	mul	x1, x1, x2
    6ba0:	d360fc21 	lsr	x1, x1, #32
    6ba4:	eb00003f 	cmp	x1, x0
    6ba8:	540000e2 	b.cs	6bc4 <f0+0x11d4>  // b.hs, b.nlast
    6bac:	8b0102f7 	add	x23, x23, x1
    6bb0:	394002e0 	ldrb	w0, [x23]
    6bb4:	7103fc1f 	cmp	w0, #0xff
    6bb8:	54008ea0 	b.eq	7d8c <f0+0x239c>  // b.none
    6bbc:	52800020 	mov	w0, #0x1                   	// #1
    6bc0:	390002e0 	strb	w0, [x23]
    6bc4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6bc8:	911163e0 	add	x0, sp, #0x458
    6bcc:	f9022ff7 	str	x23, [sp, #1112]
    6bd0:	f90233f5 	str	x21, [sp, #1120]
    6bd4:	97fff24b 	bl	3500 <fwp_data.part.0.constprop.0>
    6bd8:	97fff1b2 	bl	32a0 <fwp_rc_fresh>
    6bdc:	aa0003e1 	mov	x1, x0
    6be0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6be4:	9111a3e0 	add	x0, sp, #0x468
    6be8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6bec:	f90237e2 	str	x2, [sp, #1128]
    6bf0:	f9023be1 	str	x1, [sp, #1136]
    6bf4:	97fff243 	bl	3500 <fwp_data.part.0.constprop.0>
    6bf8:	97fff1aa 	bl	32a0 <fwp_rc_fresh>
    6bfc:	aa0003e1 	mov	x1, x0
    6c00:	9111e3e0 	add	x0, sp, #0x478
    6c04:	f9023ff7 	str	x23, [sp, #1144]
    6c08:	f90243e1 	str	x1, [sp, #1152]
    6c0c:	97fff23d 	bl	3500 <fwp_data.part.0.constprop.0>
    6c10:	aa0003f5 	mov	x21, x0
    6c14:	91140283 	add	x3, x20, #0x500
    6c18:	f949d861 	ldr	x1, [x3, #5040]
    6c1c:	f949ec60 	ldr	x0, [x3, #5080]
    6c20:	cb0102a1 	sub	x1, x21, x1
    6c24:	eb00403f 	cmp	x1, x0, lsl #16
    6c28:	54000322 	b.cs	6c8c <f0+0x129c>  // b.hs, b.nlast
    6c2c:	d350fc22 	lsr	x2, x1, #16
    6c30:	f949fc63 	ldr	x3, [x3, #5112]
    6c34:	8b020842 	add	x2, x2, x2, lsl #2
    6c38:	d37df042 	lsl	x2, x2, #3
    6c3c:	8b020060 	add	x0, x3, x2
    6c40:	f9401017 	ldr	x23, [x0, #32]
    6c44:	b4000257 	cbz	x23, 6c8c <f0+0x129c>
    6c48:	38626862 	ldrb	w2, [x3, x2]
    6c4c:	7100085f 	cmp	w2, #0x2
    6c50:	54007300 	b.eq	7ab0 <f0+0x20c0>  // b.none
    6c54:	7100045f 	cmp	w2, #0x1
    6c58:	540001a1 	b.ne	6c8c <f0+0x129c>  // b.any
    6c5c:	29430002 	ldp	w2, w0, [x0, #24]
    6c60:	92403c21 	and	x1, x1, #0xffff
    6c64:	9b027c21 	mul	x1, x1, x2
    6c68:	d360fc21 	lsr	x1, x1, #32
    6c6c:	eb00003f 	cmp	x1, x0
    6c70:	540000e2 	b.cs	6c8c <f0+0x129c>  // b.hs, b.nlast
    6c74:	8b0102f7 	add	x23, x23, x1
    6c78:	394002e0 	ldrb	w0, [x23]
    6c7c:	7103fc1f 	cmp	w0, #0xff
    6c80:	540088c0 	b.eq	7d98 <f0+0x23a8>  // b.none
    6c84:	52800020 	mov	w0, #0x1                   	// #1
    6c88:	390002e0 	strb	w0, [x23]
    6c8c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6c90:	911223e0 	add	x0, sp, #0x488
    6c94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6c98:	f90247f7 	str	x23, [sp, #1160]
    6c9c:	f9024bf5 	str	x21, [sp, #1168]
    6ca0:	97fff218 	bl	3500 <fwp_data.part.0.constprop.0>
    6ca4:	97fff17f 	bl	32a0 <fwp_rc_fresh>
    6ca8:	aa0003e1 	mov	x1, x0
    6cac:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6cb0:	911263e0 	add	x0, sp, #0x498
    6cb4:	f9024ff5 	str	x21, [sp, #1176]
    6cb8:	f90253e1 	str	x1, [sp, #1184]
    6cbc:	97fff211 	bl	3500 <fwp_data.part.0.constprop.0>
    6cc0:	97fff178 	bl	32a0 <fwp_rc_fresh>
    6cc4:	aa0003e1 	mov	x1, x0
    6cc8:	9112a3e0 	add	x0, sp, #0x4a8
    6ccc:	f90257f7 	str	x23, [sp, #1192]
    6cd0:	f9025be1 	str	x1, [sp, #1200]
    6cd4:	97fff20b 	bl	3500 <fwp_data.part.0.constprop.0>
    6cd8:	97fff172 	bl	32a0 <fwp_rc_fresh>
    6cdc:	aa0003e1 	mov	x1, x0
    6ce0:	9112e3e0 	add	x0, sp, #0x4b8
    6ce4:	f9025ff5 	str	x21, [sp, #1208]
    6ce8:	f90263e1 	str	x1, [sp, #1216]
    6cec:	97fff205 	bl	3500 <fwp_data.part.0.constprop.0>
    6cf0:	97fff16c 	bl	32a0 <fwp_rc_fresh>
    6cf4:	aa0003e1 	mov	x1, x0
    6cf8:	911323e0 	add	x0, sp, #0x4c8
    6cfc:	f90267f7 	str	x23, [sp, #1224]
    6d00:	f9026be1 	str	x1, [sp, #1232]
    6d04:	97fff1ff 	bl	3500 <fwp_data.part.0.constprop.0>
    6d08:	aa0003f5 	mov	x21, x0
    6d0c:	91140283 	add	x3, x20, #0x500
    6d10:	f949d861 	ldr	x1, [x3, #5040]
    6d14:	f949ec60 	ldr	x0, [x3, #5080]
    6d18:	cb0102a1 	sub	x1, x21, x1
    6d1c:	eb00403f 	cmp	x1, x0, lsl #16
    6d20:	54000322 	b.cs	6d84 <f0+0x1394>  // b.hs, b.nlast
    6d24:	d350fc22 	lsr	x2, x1, #16
    6d28:	f949fc63 	ldr	x3, [x3, #5112]
    6d2c:	8b020842 	add	x2, x2, x2, lsl #2
    6d30:	d37df042 	lsl	x2, x2, #3
    6d34:	8b020060 	add	x0, x3, x2
    6d38:	f9401017 	ldr	x23, [x0, #32]
    6d3c:	b4000257 	cbz	x23, 6d84 <f0+0x1394>
    6d40:	38626862 	ldrb	w2, [x3, x2]
    6d44:	7100085f 	cmp	w2, #0x2
    6d48:	54007980 	b.eq	7c78 <f0+0x2288>  // b.none
    6d4c:	7100045f 	cmp	w2, #0x1
    6d50:	540001a1 	b.ne	6d84 <f0+0x1394>  // b.any
    6d54:	29430002 	ldp	w2, w0, [x0, #24]
    6d58:	92403c21 	and	x1, x1, #0xffff
    6d5c:	9b027c21 	mul	x1, x1, x2
    6d60:	d360fc21 	lsr	x1, x1, #32
    6d64:	eb00003f 	cmp	x1, x0
    6d68:	540000e2 	b.cs	6d84 <f0+0x1394>  // b.hs, b.nlast
    6d6c:	8b0102f7 	add	x23, x23, x1
    6d70:	394002e0 	ldrb	w0, [x23]
    6d74:	7103fc1f 	cmp	w0, #0xff
    6d78:	54008160 	b.eq	7da4 <f0+0x23b4>  // b.none
    6d7c:	52800020 	mov	w0, #0x1                   	// #1
    6d80:	390002e0 	strb	w0, [x23]
    6d84:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6d88:	911363e0 	add	x0, sp, #0x4d8
    6d8c:	f9026ff7 	str	x23, [sp, #1240]
    6d90:	f90273f5 	str	x21, [sp, #1248]
    6d94:	97fff1db 	bl	3500 <fwp_data.part.0.constprop.0>
    6d98:	97fff142 	bl	32a0 <fwp_rc_fresh>
    6d9c:	aa0003e1 	mov	x1, x0
    6da0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6da4:	9113a3e0 	add	x0, sp, #0x4e8
    6da8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6dac:	f90277e2 	str	x2, [sp, #1256]
    6db0:	f9027be1 	str	x1, [sp, #1264]
    6db4:	97fff1d3 	bl	3500 <fwp_data.part.0.constprop.0>
    6db8:	97fff13a 	bl	32a0 <fwp_rc_fresh>
    6dbc:	aa0003e1 	mov	x1, x0
    6dc0:	9113e3e0 	add	x0, sp, #0x4f8
    6dc4:	f9027ff7 	str	x23, [sp, #1272]
    6dc8:	f90283e1 	str	x1, [sp, #1280]
    6dcc:	97fff1cd 	bl	3500 <fwp_data.part.0.constprop.0>
    6dd0:	aa0003f5 	mov	x21, x0
    6dd4:	91140283 	add	x3, x20, #0x500
    6dd8:	f949d861 	ldr	x1, [x3, #5040]
    6ddc:	f949ec60 	ldr	x0, [x3, #5080]
    6de0:	cb0102a1 	sub	x1, x21, x1
    6de4:	eb00403f 	cmp	x1, x0, lsl #16
    6de8:	54000322 	b.cs	6e4c <f0+0x145c>  // b.hs, b.nlast
    6dec:	d350fc22 	lsr	x2, x1, #16
    6df0:	f949fc63 	ldr	x3, [x3, #5112]
    6df4:	8b020842 	add	x2, x2, x2, lsl #2
    6df8:	d37df042 	lsl	x2, x2, #3
    6dfc:	8b020060 	add	x0, x3, x2
    6e00:	f9401017 	ldr	x23, [x0, #32]
    6e04:	b4000257 	cbz	x23, 6e4c <f0+0x145c>
    6e08:	38626862 	ldrb	w2, [x3, x2]
    6e0c:	7100085f 	cmp	w2, #0x2
    6e10:	540072e0 	b.eq	7c6c <f0+0x227c>  // b.none
    6e14:	7100045f 	cmp	w2, #0x1
    6e18:	540001a1 	b.ne	6e4c <f0+0x145c>  // b.any
    6e1c:	29430002 	ldp	w2, w0, [x0, #24]
    6e20:	92403c21 	and	x1, x1, #0xffff
    6e24:	9b027c21 	mul	x1, x1, x2
    6e28:	d360fc21 	lsr	x1, x1, #32
    6e2c:	eb00003f 	cmp	x1, x0
    6e30:	540000e2 	b.cs	6e4c <f0+0x145c>  // b.hs, b.nlast
    6e34:	8b0102f7 	add	x23, x23, x1
    6e38:	394002e0 	ldrb	w0, [x23]
    6e3c:	7103fc1f 	cmp	w0, #0xff
    6e40:	54007b80 	b.eq	7db0 <f0+0x23c0>  // b.none
    6e44:	52800020 	mov	w0, #0x1                   	// #1
    6e48:	390002e0 	strb	w0, [x23]
    6e4c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6e50:	911423e0 	add	x0, sp, #0x508
    6e54:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6e58:	f90287f7 	str	x23, [sp, #1288]
    6e5c:	f9028bf5 	str	x21, [sp, #1296]
    6e60:	97fff1a8 	bl	3500 <fwp_data.part.0.constprop.0>
    6e64:	97fff10f 	bl	32a0 <fwp_rc_fresh>
    6e68:	aa0003e1 	mov	x1, x0
    6e6c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6e70:	911463e0 	add	x0, sp, #0x518
    6e74:	f9028ff5 	str	x21, [sp, #1304]
    6e78:	f90293e1 	str	x1, [sp, #1312]
    6e7c:	97fff1a1 	bl	3500 <fwp_data.part.0.constprop.0>
    6e80:	97fff108 	bl	32a0 <fwp_rc_fresh>
    6e84:	aa0003e1 	mov	x1, x0
    6e88:	9114a3e0 	add	x0, sp, #0x528
    6e8c:	f90297f7 	str	x23, [sp, #1320]
    6e90:	f9029be1 	str	x1, [sp, #1328]
    6e94:	97fff19b 	bl	3500 <fwp_data.part.0.constprop.0>
    6e98:	97fff102 	bl	32a0 <fwp_rc_fresh>
    6e9c:	aa0003e1 	mov	x1, x0
    6ea0:	9114e3e0 	add	x0, sp, #0x538
    6ea4:	f9029ff5 	str	x21, [sp, #1336]
    6ea8:	f902a3e1 	str	x1, [sp, #1344]
    6eac:	97fff195 	bl	3500 <fwp_data.part.0.constprop.0>
    6eb0:	97fff0fc 	bl	32a0 <fwp_rc_fresh>
    6eb4:	aa0003e1 	mov	x1, x0
    6eb8:	911523e0 	add	x0, sp, #0x548
    6ebc:	f902a7f7 	str	x23, [sp, #1352]
    6ec0:	f902abe1 	str	x1, [sp, #1360]
    6ec4:	97fff18f 	bl	3500 <fwp_data.part.0.constprop.0>
    6ec8:	aa0003f5 	mov	x21, x0
    6ecc:	91140283 	add	x3, x20, #0x500
    6ed0:	f949d861 	ldr	x1, [x3, #5040]
    6ed4:	f949ec60 	ldr	x0, [x3, #5080]
    6ed8:	cb0102a1 	sub	x1, x21, x1
    6edc:	eb00403f 	cmp	x1, x0, lsl #16
    6ee0:	54000322 	b.cs	6f44 <f0+0x1554>  // b.hs, b.nlast
    6ee4:	d350fc22 	lsr	x2, x1, #16
    6ee8:	f949fc63 	ldr	x3, [x3, #5112]
    6eec:	8b020842 	add	x2, x2, x2, lsl #2
    6ef0:	d37df042 	lsl	x2, x2, #3
    6ef4:	8b020060 	add	x0, x3, x2
    6ef8:	f9401017 	ldr	x23, [x0, #32]
    6efc:	b4000257 	cbz	x23, 6f44 <f0+0x1554>
    6f00:	38626862 	ldrb	w2, [x3, x2]
    6f04:	7100085f 	cmp	w2, #0x2
    6f08:	54006ac0 	b.eq	7c60 <f0+0x2270>  // b.none
    6f0c:	7100045f 	cmp	w2, #0x1
    6f10:	540001a1 	b.ne	6f44 <f0+0x1554>  // b.any
    6f14:	29430002 	ldp	w2, w0, [x0, #24]
    6f18:	92403c21 	and	x1, x1, #0xffff
    6f1c:	9b027c21 	mul	x1, x1, x2
    6f20:	d360fc21 	lsr	x1, x1, #32
    6f24:	eb00003f 	cmp	x1, x0
    6f28:	540000e2 	b.cs	6f44 <f0+0x1554>  // b.hs, b.nlast
    6f2c:	8b0102f7 	add	x23, x23, x1
    6f30:	394002e0 	ldrb	w0, [x23]
    6f34:	7103fc1f 	cmp	w0, #0xff
    6f38:	54007420 	b.eq	7dbc <f0+0x23cc>  // b.none
    6f3c:	52800020 	mov	w0, #0x1                   	// #1
    6f40:	390002e0 	strb	w0, [x23]
    6f44:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6f48:	911563e0 	add	x0, sp, #0x558
    6f4c:	f902aff7 	str	x23, [sp, #1368]
    6f50:	f902b3f5 	str	x21, [sp, #1376]
    6f54:	97fff16b 	bl	3500 <fwp_data.part.0.constprop.0>
    6f58:	97fff0d2 	bl	32a0 <fwp_rc_fresh>
    6f5c:	aa0003e1 	mov	x1, x0
    6f60:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6f64:	9115a3e0 	add	x0, sp, #0x568
    6f68:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6f6c:	f902b7e2 	str	x2, [sp, #1384]
    6f70:	f902bbe1 	str	x1, [sp, #1392]
    6f74:	97fff163 	bl	3500 <fwp_data.part.0.constprop.0>
    6f78:	97fff0ca 	bl	32a0 <fwp_rc_fresh>
    6f7c:	aa0003e1 	mov	x1, x0
    6f80:	9115e3e0 	add	x0, sp, #0x578
    6f84:	f902bff7 	str	x23, [sp, #1400]
    6f88:	f902c3e1 	str	x1, [sp, #1408]
    6f8c:	97fff15d 	bl	3500 <fwp_data.part.0.constprop.0>
    6f90:	aa0003f5 	mov	x21, x0
    6f94:	91140283 	add	x3, x20, #0x500
    6f98:	f949d861 	ldr	x1, [x3, #5040]
    6f9c:	f949ec60 	ldr	x0, [x3, #5080]
    6fa0:	cb0102a1 	sub	x1, x21, x1
    6fa4:	eb00403f 	cmp	x1, x0, lsl #16
    6fa8:	54000322 	b.cs	700c <f0+0x161c>  // b.hs, b.nlast
    6fac:	d350fc22 	lsr	x2, x1, #16
    6fb0:	f949fc63 	ldr	x3, [x3, #5112]
    6fb4:	8b020842 	add	x2, x2, x2, lsl #2
    6fb8:	d37df042 	lsl	x2, x2, #3
    6fbc:	8b020060 	add	x0, x3, x2
    6fc0:	f9401017 	ldr	x23, [x0, #32]
    6fc4:	b4000257 	cbz	x23, 700c <f0+0x161c>
    6fc8:	38626862 	ldrb	w2, [x3, x2]
    6fcc:	7100085f 	cmp	w2, #0x2
    6fd0:	54006420 	b.eq	7c54 <f0+0x2264>  // b.none
    6fd4:	7100045f 	cmp	w2, #0x1
    6fd8:	540001a1 	b.ne	700c <f0+0x161c>  // b.any
    6fdc:	29430002 	ldp	w2, w0, [x0, #24]
    6fe0:	92403c21 	and	x1, x1, #0xffff
    6fe4:	9b027c21 	mul	x1, x1, x2
    6fe8:	d360fc21 	lsr	x1, x1, #32
    6fec:	eb00003f 	cmp	x1, x0
    6ff0:	540000e2 	b.cs	700c <f0+0x161c>  // b.hs, b.nlast
    6ff4:	8b0102f7 	add	x23, x23, x1
    6ff8:	394002e0 	ldrb	w0, [x23]
    6ffc:	7103fc1f 	cmp	w0, #0xff
    7000:	54006e40 	b.eq	7dc8 <f0+0x23d8>  // b.none
    7004:	52800020 	mov	w0, #0x1                   	// #1
    7008:	390002e0 	strb	w0, [x23]
    700c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7010:	911623e0 	add	x0, sp, #0x588
    7014:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7018:	f902c7f7 	str	x23, [sp, #1416]
    701c:	f902cbf5 	str	x21, [sp, #1424]
    7020:	97fff138 	bl	3500 <fwp_data.part.0.constprop.0>
    7024:	97fff09f 	bl	32a0 <fwp_rc_fresh>
    7028:	aa0003e1 	mov	x1, x0
    702c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7030:	911663e0 	add	x0, sp, #0x598
    7034:	f902cff5 	str	x21, [sp, #1432]
    7038:	f902d3e1 	str	x1, [sp, #1440]
    703c:	97fff131 	bl	3500 <fwp_data.part.0.constprop.0>
    7040:	97fff098 	bl	32a0 <fwp_rc_fresh>
    7044:	aa0003e1 	mov	x1, x0
    7048:	9116a3e0 	add	x0, sp, #0x5a8
    704c:	f902d7f7 	str	x23, [sp, #1448]
    7050:	f902dbe1 	str	x1, [sp, #1456]
    7054:	97fff12b 	bl	3500 <fwp_data.part.0.constprop.0>
    7058:	97fff092 	bl	32a0 <fwp_rc_fresh>
    705c:	aa0003e1 	mov	x1, x0
    7060:	9116e3e0 	add	x0, sp, #0x5b8
    7064:	f902dff5 	str	x21, [sp, #1464]
    7068:	f902e3e1 	str	x1, [sp, #1472]
    706c:	97fff125 	bl	3500 <fwp_data.part.0.constprop.0>
    7070:	97fff08c 	bl	32a0 <fwp_rc_fresh>
    7074:	aa0003e1 	mov	x1, x0
    7078:	911723e0 	add	x0, sp, #0x5c8
    707c:	f902e7f7 	str	x23, [sp, #1480]
    7080:	f902ebe1 	str	x1, [sp, #1488]
    7084:	97fff11f 	bl	3500 <fwp_data.part.0.constprop.0>
    7088:	97fff086 	bl	32a0 <fwp_rc_fresh>
    708c:	aa0003e1 	mov	x1, x0
    7090:	911763e0 	add	x0, sp, #0x5d8
    7094:	f902eff5 	str	x21, [sp, #1496]
    7098:	f902f3e1 	str	x1, [sp, #1504]
    709c:	97fff119 	bl	3500 <fwp_data.part.0.constprop.0>
    70a0:	97fff080 	bl	32a0 <fwp_rc_fresh>
    70a4:	aa0003e1 	mov	x1, x0
    70a8:	9117a3e0 	add	x0, sp, #0x5e8
    70ac:	f902f7f7 	str	x23, [sp, #1512]
    70b0:	f902fbe1 	str	x1, [sp, #1520]
    70b4:	97fff113 	bl	3500 <fwp_data.part.0.constprop.0>
    70b8:	97fff07a 	bl	32a0 <fwp_rc_fresh>
    70bc:	aa0003e1 	mov	x1, x0
    70c0:	9117e3e0 	add	x0, sp, #0x5f8
    70c4:	f902fff5 	str	x21, [sp, #1528]
    70c8:	f90303e1 	str	x1, [sp, #1536]
    70cc:	97fff10d 	bl	3500 <fwp_data.part.0.constprop.0>
    70d0:	aa0003f5 	mov	x21, x0
    70d4:	91140283 	add	x3, x20, #0x500
    70d8:	f949d861 	ldr	x1, [x3, #5040]
    70dc:	f949ec60 	ldr	x0, [x3, #5080]
    70e0:	cb0102a1 	sub	x1, x21, x1
    70e4:	eb00403f 	cmp	x1, x0, lsl #16
    70e8:	54000322 	b.cs	714c <f0+0x175c>  // b.hs, b.nlast
    70ec:	d350fc22 	lsr	x2, x1, #16
    70f0:	f949fc63 	ldr	x3, [x3, #5112]
    70f4:	8b020842 	add	x2, x2, x2, lsl #2
    70f8:	d37df042 	lsl	x2, x2, #3
    70fc:	8b020060 	add	x0, x3, x2
    7100:	f9401017 	ldr	x23, [x0, #32]
    7104:	b4000257 	cbz	x23, 714c <f0+0x175c>
    7108:	38626862 	ldrb	w2, [x3, x2]
    710c:	7100085f 	cmp	w2, #0x2
    7110:	540059c0 	b.eq	7c48 <f0+0x2258>  // b.none
    7114:	7100045f 	cmp	w2, #0x1
    7118:	540001a1 	b.ne	714c <f0+0x175c>  // b.any
    711c:	29430002 	ldp	w2, w0, [x0, #24]
    7120:	92403c21 	and	x1, x1, #0xffff
    7124:	9b027c21 	mul	x1, x1, x2
    7128:	d360fc21 	lsr	x1, x1, #32
    712c:	eb00003f 	cmp	x1, x0
    7130:	540000e2 	b.cs	714c <f0+0x175c>  // b.hs, b.nlast
    7134:	8b0102f7 	add	x23, x23, x1
    7138:	394002e0 	ldrb	w0, [x23]
    713c:	7103fc1f 	cmp	w0, #0xff
    7140:	540064a0 	b.eq	7dd4 <f0+0x23e4>  // b.none
    7144:	52800020 	mov	w0, #0x1                   	// #1
    7148:	390002e0 	strb	w0, [x23]
    714c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7150:	911823e0 	add	x0, sp, #0x608
    7154:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7158:	f90307e1 	str	x1, [sp, #1544]
    715c:	f9030bf5 	str	x21, [sp, #1552]
    7160:	97fff0e8 	bl	3500 <fwp_data.part.0.constprop.0>
    7164:	aa0003f7 	mov	x23, x0
    7168:	91140283 	add	x3, x20, #0x500
    716c:	f949d861 	ldr	x1, [x3, #5040]
    7170:	f949ec60 	ldr	x0, [x3, #5080]
    7174:	cb0102e1 	sub	x1, x23, x1
    7178:	eb00403f 	cmp	x1, x0, lsl #16
    717c:	54000322 	b.cs	71e0 <f0+0x17f0>  // b.hs, b.nlast
    7180:	d350fc22 	lsr	x2, x1, #16
    7184:	f949fc63 	ldr	x3, [x3, #5112]
    7188:	8b020842 	add	x2, x2, x2, lsl #2
    718c:	d37df042 	lsl	x2, x2, #3
    7190:	8b020060 	add	x0, x3, x2
    7194:	f9401015 	ldr	x21, [x0, #32]
    7198:	b4000255 	cbz	x21, 71e0 <f0+0x17f0>
    719c:	38626862 	ldrb	w2, [x3, x2]
    71a0:	7100085f 	cmp	w2, #0x2
    71a4:	540054c0 	b.eq	7c3c <f0+0x224c>  // b.none
    71a8:	7100045f 	cmp	w2, #0x1
    71ac:	540001a1 	b.ne	71e0 <f0+0x17f0>  // b.any
    71b0:	29430002 	ldp	w2, w0, [x0, #24]
    71b4:	92403c21 	and	x1, x1, #0xffff
    71b8:	9b027c21 	mul	x1, x1, x2
    71bc:	d360fc21 	lsr	x1, x1, #32
    71c0:	eb00003f 	cmp	x1, x0
    71c4:	540000e2 	b.cs	71e0 <f0+0x17f0>  // b.hs, b.nlast
    71c8:	8b0102b5 	add	x21, x21, x1
    71cc:	394002a0 	ldrb	w0, [x21]
    71d0:	7103fc1f 	cmp	w0, #0xff
    71d4:	54006060 	b.eq	7de0 <f0+0x23f0>  // b.none
    71d8:	52800020 	mov	w0, #0x1                   	// #1
    71dc:	390002a0 	strb	w0, [x21]
    71e0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    71e4:	911863e0 	add	x0, sp, #0x618
    71e8:	f9030ff5 	str	x21, [sp, #1560]
    71ec:	f90313f7 	str	x23, [sp, #1568]
    71f0:	97fff0c4 	bl	3500 <fwp_data.part.0.constprop.0>
    71f4:	97fff02b 	bl	32a0 <fwp_rc_fresh>
    71f8:	aa0003e1 	mov	x1, x0
    71fc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7200:	9118a3e0 	add	x0, sp, #0x628
    7204:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7208:	f90317f7 	str	x23, [sp, #1576]
    720c:	f9031be1 	str	x1, [sp, #1584]
    7210:	97fff0bc 	bl	3500 <fwp_data.part.0.constprop.0>
    7214:	97fff023 	bl	32a0 <fwp_rc_fresh>
    7218:	aa0003e1 	mov	x1, x0
    721c:	9118e3e0 	add	x0, sp, #0x638
    7220:	f9031ff5 	str	x21, [sp, #1592]
    7224:	f90323e1 	str	x1, [sp, #1600]
    7228:	97fff0b6 	bl	3500 <fwp_data.part.0.constprop.0>
    722c:	97fff01d 	bl	32a0 <fwp_rc_fresh>
    7230:	aa0003e1 	mov	x1, x0
    7234:	911923e0 	add	x0, sp, #0x648
    7238:	f90327f7 	str	x23, [sp, #1608]
    723c:	f9032be1 	str	x1, [sp, #1616]
    7240:	97fff0b0 	bl	3500 <fwp_data.part.0.constprop.0>
    7244:	97fff017 	bl	32a0 <fwp_rc_fresh>
    7248:	aa0003e1 	mov	x1, x0
    724c:	911963e0 	add	x0, sp, #0x658
    7250:	f9032ff5 	str	x21, [sp, #1624]
    7254:	f90333e1 	str	x1, [sp, #1632]
    7258:	97fff0aa 	bl	3500 <fwp_data.part.0.constprop.0>
    725c:	97fff011 	bl	32a0 <fwp_rc_fresh>
    7260:	aa0003e1 	mov	x1, x0
    7264:	9119a3e0 	add	x0, sp, #0x668
    7268:	f90337f7 	str	x23, [sp, #1640]
    726c:	f9033be1 	str	x1, [sp, #1648]
    7270:	97fff0a4 	bl	3500 <fwp_data.part.0.constprop.0>
    7274:	97fff00b 	bl	32a0 <fwp_rc_fresh>
    7278:	aa0003e1 	mov	x1, x0
    727c:	9119e3e0 	add	x0, sp, #0x678
    7280:	f9033ff5 	str	x21, [sp, #1656]
    7284:	f90343e1 	str	x1, [sp, #1664]
    7288:	97fff09e 	bl	3500 <fwp_data.part.0.constprop.0>
    728c:	aa0003f5 	mov	x21, x0
    7290:	91140283 	add	x3, x20, #0x500
    7294:	f949d861 	ldr	x1, [x3, #5040]
    7298:	f949ec60 	ldr	x0, [x3, #5080]
    729c:	cb0102a1 	sub	x1, x21, x1
    72a0:	eb00403f 	cmp	x1, x0, lsl #16
    72a4:	54000322 	b.cs	7308 <f0+0x1918>  // b.hs, b.nlast
    72a8:	d350fc22 	lsr	x2, x1, #16
    72ac:	f949fc63 	ldr	x3, [x3, #5112]
    72b0:	8b020842 	add	x2, x2, x2, lsl #2
    72b4:	d37df042 	lsl	x2, x2, #3
    72b8:	8b020060 	add	x0, x3, x2
    72bc:	f9401017 	ldr	x23, [x0, #32]
    72c0:	b4000257 	cbz	x23, 7308 <f0+0x1918>
    72c4:	38626862 	ldrb	w2, [x3, x2]
    72c8:	7100085f 	cmp	w2, #0x2
    72cc:	54004b20 	b.eq	7c30 <f0+0x2240>  // b.none
    72d0:	7100045f 	cmp	w2, #0x1
    72d4:	540001a1 	b.ne	7308 <f0+0x1918>  // b.any
    72d8:	29430002 	ldp	w2, w0, [x0, #24]
    72dc:	92403c21 	and	x1, x1, #0xffff
    72e0:	9b027c21 	mul	x1, x1, x2
    72e4:	d360fc21 	lsr	x1, x1, #32
    72e8:	eb00003f 	cmp	x1, x0
    72ec:	540000e2 	b.cs	7308 <f0+0x1918>  // b.hs, b.nlast
    72f0:	8b0102f7 	add	x23, x23, x1
    72f4:	394002e0 	ldrb	w0, [x23]
    72f8:	7103fc1f 	cmp	w0, #0xff
    72fc:	54005780 	b.eq	7dec <f0+0x23fc>  // b.none
    7300:	52800020 	mov	w0, #0x1                   	// #1
    7304:	390002e0 	strb	w0, [x23]
    7308:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    730c:	911a23e0 	add	x0, sp, #0x688
    7310:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7314:	f90347e1 	str	x1, [sp, #1672]
    7318:	f9034bf5 	str	x21, [sp, #1680]
    731c:	97fff079 	bl	3500 <fwp_data.part.0.constprop.0>
    7320:	aa0003f5 	mov	x21, x0
    7324:	91140283 	add	x3, x20, #0x500
    7328:	f949d861 	ldr	x1, [x3, #5040]
    732c:	f949ec60 	ldr	x0, [x3, #5080]
    7330:	cb0102a1 	sub	x1, x21, x1
    7334:	eb00403f 	cmp	x1, x0, lsl #16
    7338:	54000322 	b.cs	739c <f0+0x19ac>  // b.hs, b.nlast
    733c:	d350fc22 	lsr	x2, x1, #16
    7340:	f949fc63 	ldr	x3, [x3, #5112]
    7344:	8b020842 	add	x2, x2, x2, lsl #2
    7348:	d37df042 	lsl	x2, x2, #3
    734c:	8b020060 	add	x0, x3, x2
    7350:	f9401017 	ldr	x23, [x0, #32]
    7354:	b4000257 	cbz	x23, 739c <f0+0x19ac>
    7358:	38626862 	ldrb	w2, [x3, x2]
    735c:	7100085f 	cmp	w2, #0x2
    7360:	54004620 	b.eq	7c24 <f0+0x2234>  // b.none
    7364:	7100045f 	cmp	w2, #0x1
    7368:	540001a1 	b.ne	739c <f0+0x19ac>  // b.any
    736c:	29430002 	ldp	w2, w0, [x0, #24]
    7370:	92403c21 	and	x1, x1, #0xffff
    7374:	9b027c21 	mul	x1, x1, x2
    7378:	d360fc21 	lsr	x1, x1, #32
    737c:	eb00003f 	cmp	x1, x0
    7380:	540000e2 	b.cs	739c <f0+0x19ac>  // b.hs, b.nlast
    7384:	8b0102f7 	add	x23, x23, x1
    7388:	394002e0 	ldrb	w0, [x23]
    738c:	7103fc1f 	cmp	w0, #0xff
    7390:	54005340 	b.eq	7df8 <f0+0x2408>  // b.none
    7394:	52800020 	mov	w0, #0x1                   	// #1
    7398:	390002e0 	strb	w0, [x23]
    739c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    73a0:	911a63e0 	add	x0, sp, #0x698
    73a4:	f9034ff7 	str	x23, [sp, #1688]
    73a8:	f90353f5 	str	x21, [sp, #1696]
    73ac:	97fff055 	bl	3500 <fwp_data.part.0.constprop.0>
    73b0:	97ffefbc 	bl	32a0 <fwp_rc_fresh>
    73b4:	aa0003e1 	mov	x1, x0
    73b8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    73bc:	911aa3e0 	add	x0, sp, #0x6a8
    73c0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    73c4:	f90357f5 	str	x21, [sp, #1704]
    73c8:	f9035be1 	str	x1, [sp, #1712]
    73cc:	97fff04d 	bl	3500 <fwp_data.part.0.constprop.0>
    73d0:	97ffefb4 	bl	32a0 <fwp_rc_fresh>
    73d4:	aa0003e1 	mov	x1, x0
    73d8:	911ae3e0 	add	x0, sp, #0x6b8
    73dc:	f9035ff7 	str	x23, [sp, #1720]
    73e0:	f90363e1 	str	x1, [sp, #1728]
    73e4:	97fff047 	bl	3500 <fwp_data.part.0.constprop.0>
    73e8:	97ffefae 	bl	32a0 <fwp_rc_fresh>
    73ec:	aa0003e1 	mov	x1, x0
    73f0:	911b23e0 	add	x0, sp, #0x6c8
    73f4:	f90367f5 	str	x21, [sp, #1736]
    73f8:	f9036be1 	str	x1, [sp, #1744]
    73fc:	97fff041 	bl	3500 <fwp_data.part.0.constprop.0>
    7400:	aa0003f5 	mov	x21, x0
    7404:	91140283 	add	x3, x20, #0x500
    7408:	f949d861 	ldr	x1, [x3, #5040]
    740c:	f949ec60 	ldr	x0, [x3, #5080]
    7410:	cb0102a1 	sub	x1, x21, x1
    7414:	eb00403f 	cmp	x1, x0, lsl #16
    7418:	54000322 	b.cs	747c <f0+0x1a8c>  // b.hs, b.nlast
    741c:	d350fc22 	lsr	x2, x1, #16
    7420:	f949fc63 	ldr	x3, [x3, #5112]
    7424:	8b020842 	add	x2, x2, x2, lsl #2
    7428:	d37df042 	lsl	x2, x2, #3
    742c:	8b020060 	add	x0, x3, x2
    7430:	f9401017 	ldr	x23, [x0, #32]
    7434:	b4000257 	cbz	x23, 747c <f0+0x1a8c>
    7438:	38626862 	ldrb	w2, [x3, x2]
    743c:	7100085f 	cmp	w2, #0x2
    7440:	54003ec0 	b.eq	7c18 <f0+0x2228>  // b.none
    7444:	7100045f 	cmp	w2, #0x1
    7448:	540001a1 	b.ne	747c <f0+0x1a8c>  // b.any
    744c:	29430002 	ldp	w2, w0, [x0, #24]
    7450:	92403c21 	and	x1, x1, #0xffff
    7454:	9b027c21 	mul	x1, x1, x2
    7458:	d360fc21 	lsr	x1, x1, #32
    745c:	eb00003f 	cmp	x1, x0
    7460:	540000e2 	b.cs	747c <f0+0x1a8c>  // b.hs, b.nlast
    7464:	8b0102f7 	add	x23, x23, x1
    7468:	394002e0 	ldrb	w0, [x23]
    746c:	7103fc1f 	cmp	w0, #0xff
    7470:	54004ca0 	b.eq	7e04 <f0+0x2414>  // b.none
    7474:	52800020 	mov	w0, #0x1                   	// #1
    7478:	390002e0 	strb	w0, [x23]
    747c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7480:	911b63e0 	add	x0, sp, #0x6d8
    7484:	f9036ff7 	str	x23, [sp, #1752]
    7488:	f90373f5 	str	x21, [sp, #1760]
    748c:	97fff01d 	bl	3500 <fwp_data.part.0.constprop.0>
    7490:	97ffef84 	bl	32a0 <fwp_rc_fresh>
    7494:	aa0003e1 	mov	x1, x0
    7498:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    749c:	911ba3e0 	add	x0, sp, #0x6e8
    74a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    74a4:	f90377e2 	str	x2, [sp, #1768]
    74a8:	f9037be1 	str	x1, [sp, #1776]
    74ac:	97fff015 	bl	3500 <fwp_data.part.0.constprop.0>
    74b0:	97ffef7c 	bl	32a0 <fwp_rc_fresh>
    74b4:	aa0003e1 	mov	x1, x0
    74b8:	911be3e0 	add	x0, sp, #0x6f8
    74bc:	f9037ff7 	str	x23, [sp, #1784]
    74c0:	f90383e1 	str	x1, [sp, #1792]
    74c4:	97fff00f 	bl	3500 <fwp_data.part.0.constprop.0>
    74c8:	aa0003f5 	mov	x21, x0
    74cc:	91140283 	add	x3, x20, #0x500
    74d0:	f949d861 	ldr	x1, [x3, #5040]
    74d4:	f949ec60 	ldr	x0, [x3, #5080]
    74d8:	cb0102a1 	sub	x1, x21, x1
    74dc:	eb00403f 	cmp	x1, x0, lsl #16
    74e0:	54000322 	b.cs	7544 <f0+0x1b54>  // b.hs, b.nlast
    74e4:	d350fc22 	lsr	x2, x1, #16
    74e8:	f949fc63 	ldr	x3, [x3, #5112]
    74ec:	8b020842 	add	x2, x2, x2, lsl #2
    74f0:	d37df042 	lsl	x2, x2, #3
    74f4:	8b020060 	add	x0, x3, x2
    74f8:	f9401017 	ldr	x23, [x0, #32]
    74fc:	b4000257 	cbz	x23, 7544 <f0+0x1b54>
    7500:	38626862 	ldrb	w2, [x3, x2]
    7504:	7100085f 	cmp	w2, #0x2
    7508:	54003820 	b.eq	7c0c <f0+0x221c>  // b.none
    750c:	7100045f 	cmp	w2, #0x1
    7510:	540001a1 	b.ne	7544 <f0+0x1b54>  // b.any
    7514:	29430002 	ldp	w2, w0, [x0, #24]
    7518:	92403c21 	and	x1, x1, #0xffff
    751c:	9b027c21 	mul	x1, x1, x2
    7520:	d360fc21 	lsr	x1, x1, #32
    7524:	eb00003f 	cmp	x1, x0
    7528:	540000e2 	b.cs	7544 <f0+0x1b54>  // b.hs, b.nlast
    752c:	8b0102f7 	add	x23, x23, x1
    7530:	394002e0 	ldrb	w0, [x23]
    7534:	7103fc1f 	cmp	w0, #0xff
    7538:	540046c0 	b.eq	7e10 <f0+0x2420>  // b.none
    753c:	52800020 	mov	w0, #0x1                   	// #1
    7540:	390002e0 	strb	w0, [x23]
    7544:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7548:	911c23e0 	add	x0, sp, #0x708
    754c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7550:	f90387f7 	str	x23, [sp, #1800]
    7554:	f9038bf5 	str	x21, [sp, #1808]
    7558:	97ffefea 	bl	3500 <fwp_data.part.0.constprop.0>
    755c:	97ffef51 	bl	32a0 <fwp_rc_fresh>
    7560:	aa0003e1 	mov	x1, x0
    7564:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7568:	911c63e0 	add	x0, sp, #0x718
    756c:	f9038ff5 	str	x21, [sp, #1816]
    7570:	f90393e1 	str	x1, [sp, #1824]
    7574:	97ffefe3 	bl	3500 <fwp_data.part.0.constprop.0>
    7578:	97ffef4a 	bl	32a0 <fwp_rc_fresh>
    757c:	aa0003e1 	mov	x1, x0
    7580:	911ca3e0 	add	x0, sp, #0x728
    7584:	f90397f7 	str	x23, [sp, #1832]
    7588:	f9039be1 	str	x1, [sp, #1840]
    758c:	97ffefdd 	bl	3500 <fwp_data.part.0.constprop.0>
    7590:	97ffef44 	bl	32a0 <fwp_rc_fresh>
    7594:	aa0003e1 	mov	x1, x0
    7598:	911ce3e0 	add	x0, sp, #0x738
    759c:	f9039ff5 	str	x21, [sp, #1848]
    75a0:	f903a3e1 	str	x1, [sp, #1856]
    75a4:	97ffefd7 	bl	3500 <fwp_data.part.0.constprop.0>
    75a8:	97ffef3e 	bl	32a0 <fwp_rc_fresh>
    75ac:	aa0003e1 	mov	x1, x0
    75b0:	911d23e0 	add	x0, sp, #0x748
    75b4:	f903a7f7 	str	x23, [sp, #1864]
    75b8:	f903abe1 	str	x1, [sp, #1872]
    75bc:	97ffefd1 	bl	3500 <fwp_data.part.0.constprop.0>
    75c0:	aa0003f5 	mov	x21, x0
    75c4:	91140283 	add	x3, x20, #0x500
    75c8:	f949d861 	ldr	x1, [x3, #5040]
    75cc:	f949ec60 	ldr	x0, [x3, #5080]
    75d0:	cb0102a1 	sub	x1, x21, x1
    75d4:	eb00403f 	cmp	x1, x0, lsl #16
    75d8:	54000322 	b.cs	763c <f0+0x1c4c>  // b.hs, b.nlast
    75dc:	d350fc22 	lsr	x2, x1, #16
    75e0:	f949fc63 	ldr	x3, [x3, #5112]
    75e4:	8b020842 	add	x2, x2, x2, lsl #2
    75e8:	d37df042 	lsl	x2, x2, #3
    75ec:	8b020060 	add	x0, x3, x2
    75f0:	f9401017 	ldr	x23, [x0, #32]
    75f4:	b4000257 	cbz	x23, 763c <f0+0x1c4c>
    75f8:	38626862 	ldrb	w2, [x3, x2]
    75fc:	7100085f 	cmp	w2, #0x2
    7600:	54003000 	b.eq	7c00 <f0+0x2210>  // b.none
    7604:	7100045f 	cmp	w2, #0x1
    7608:	540001a1 	b.ne	763c <f0+0x1c4c>  // b.any
    760c:	29430002 	ldp	w2, w0, [x0, #24]
    7610:	92403c21 	and	x1, x1, #0xffff
    7614:	9b027c21 	mul	x1, x1, x2
    7618:	d360fc21 	lsr	x1, x1, #32
    761c:	eb00003f 	cmp	x1, x0
    7620:	540000e2 	b.cs	763c <f0+0x1c4c>  // b.hs, b.nlast
    7624:	8b0102f7 	add	x23, x23, x1
    7628:	394002e0 	ldrb	w0, [x23]
    762c:	7103fc1f 	cmp	w0, #0xff
    7630:	54003f60 	b.eq	7e1c <f0+0x242c>  // b.none
    7634:	52800020 	mov	w0, #0x1                   	// #1
    7638:	390002e0 	strb	w0, [x23]
    763c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7640:	911d63e0 	add	x0, sp, #0x758
    7644:	f903aff7 	str	x23, [sp, #1880]
    7648:	f903b3f5 	str	x21, [sp, #1888]
    764c:	97ffefad 	bl	3500 <fwp_data.part.0.constprop.0>
    7650:	97ffef14 	bl	32a0 <fwp_rc_fresh>
    7654:	aa0003e1 	mov	x1, x0
    7658:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    765c:	911da3e0 	add	x0, sp, #0x768
    7660:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7664:	f903b7f5 	str	x21, [sp, #1896]
    7668:	f903bbe1 	str	x1, [sp, #1904]
    766c:	97ffefa5 	bl	3500 <fwp_data.part.0.constprop.0>
    7670:	97ffef0c 	bl	32a0 <fwp_rc_fresh>
    7674:	aa0003e1 	mov	x1, x0
    7678:	911de3e0 	add	x0, sp, #0x778
    767c:	f903bff7 	str	x23, [sp, #1912]
    7680:	f903c3e1 	str	x1, [sp, #1920]
    7684:	97ffef9f 	bl	3500 <fwp_data.part.0.constprop.0>
    7688:	97ffef06 	bl	32a0 <fwp_rc_fresh>
    768c:	aa0003e1 	mov	x1, x0
    7690:	911e23e0 	add	x0, sp, #0x788
    7694:	f903c7f5 	str	x21, [sp, #1928]
    7698:	f903cbe1 	str	x1, [sp, #1936]
    769c:	97ffef99 	bl	3500 <fwp_data.part.0.constprop.0>
    76a0:	aa0003f5 	mov	x21, x0
    76a4:	91140283 	add	x3, x20, #0x500
    76a8:	f949d861 	ldr	x1, [x3, #5040]
    76ac:	f949ec60 	ldr	x0, [x3, #5080]
    76b0:	cb0102a1 	sub	x1, x21, x1
    76b4:	eb00403f 	cmp	x1, x0, lsl #16
    76b8:	54000322 	b.cs	771c <f0+0x1d2c>  // b.hs, b.nlast
    76bc:	d350fc22 	lsr	x2, x1, #16
    76c0:	f949fc63 	ldr	x3, [x3, #5112]
    76c4:	8b020842 	add	x2, x2, x2, lsl #2
    76c8:	d37df042 	lsl	x2, x2, #3
    76cc:	8b020060 	add	x0, x3, x2
    76d0:	f9401017 	ldr	x23, [x0, #32]
    76d4:	b4000257 	cbz	x23, 771c <f0+0x1d2c>
    76d8:	38626862 	ldrb	w2, [x3, x2]
    76dc:	7100085f 	cmp	w2, #0x2
    76e0:	540028a0 	b.eq	7bf4 <f0+0x2204>  // b.none
    76e4:	7100045f 	cmp	w2, #0x1
    76e8:	540001a1 	b.ne	771c <f0+0x1d2c>  // b.any
    76ec:	29430002 	ldp	w2, w0, [x0, #24]
    76f0:	92403c21 	and	x1, x1, #0xffff
    76f4:	9b027c21 	mul	x1, x1, x2
    76f8:	d360fc21 	lsr	x1, x1, #32
    76fc:	eb00003f 	cmp	x1, x0
    7700:	540000e2 	b.cs	771c <f0+0x1d2c>  // b.hs, b.nlast
    7704:	8b0102f7 	add	x23, x23, x1
    7708:	394002e0 	ldrb	w0, [x23]
    770c:	7103fc1f 	cmp	w0, #0xff
    7710:	540038c0 	b.eq	7e28 <f0+0x2438>  // b.none
    7714:	52800020 	mov	w0, #0x1                   	// #1
    7718:	390002e0 	strb	w0, [x23]
    771c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7720:	911e63e0 	add	x0, sp, #0x798
    7724:	f903cff7 	str	x23, [sp, #1944]
    7728:	f903d3f5 	str	x21, [sp, #1952]
    772c:	97ffef75 	bl	3500 <fwp_data.part.0.constprop.0>
    7730:	97ffeedc 	bl	32a0 <fwp_rc_fresh>
    7734:	aa0003e1 	mov	x1, x0
    7738:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    773c:	911ea3e0 	add	x0, sp, #0x7a8
    7740:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7744:	f903d7f5 	str	x21, [sp, #1960]
    7748:	f903dbe1 	str	x1, [sp, #1968]
    774c:	97ffef6d 	bl	3500 <fwp_data.part.0.constprop.0>
    7750:	97ffeed4 	bl	32a0 <fwp_rc_fresh>
    7754:	aa0003e1 	mov	x1, x0
    7758:	911ee3e0 	add	x0, sp, #0x7b8
    775c:	f903dff7 	str	x23, [sp, #1976]
    7760:	f903e3e1 	str	x1, [sp, #1984]
    7764:	97ffef67 	bl	3500 <fwp_data.part.0.constprop.0>
    7768:	97ffeece 	bl	32a0 <fwp_rc_fresh>
    776c:	aa0003e1 	mov	x1, x0
    7770:	911f23e0 	add	x0, sp, #0x7c8
    7774:	f903e7f5 	str	x21, [sp, #1992]
    7778:	f903ebe1 	str	x1, [sp, #2000]
    777c:	97ffef61 	bl	3500 <fwp_data.part.0.constprop.0>
    7780:	aa0003f5 	mov	x21, x0
    7784:	91140283 	add	x3, x20, #0x500
    7788:	f949d861 	ldr	x1, [x3, #5040]
    778c:	f949ec60 	ldr	x0, [x3, #5080]
    7790:	cb0102a1 	sub	x1, x21, x1
    7794:	eb00403f 	cmp	x1, x0, lsl #16
    7798:	54000322 	b.cs	77fc <f0+0x1e0c>  // b.hs, b.nlast
    779c:	d350fc22 	lsr	x2, x1, #16
    77a0:	f949fc63 	ldr	x3, [x3, #5112]
    77a4:	8b020842 	add	x2, x2, x2, lsl #2
    77a8:	d37df042 	lsl	x2, x2, #3
    77ac:	8b020060 	add	x0, x3, x2
    77b0:	f9401017 	ldr	x23, [x0, #32]
    77b4:	b4000257 	cbz	x23, 77fc <f0+0x1e0c>
    77b8:	38626862 	ldrb	w2, [x3, x2]
    77bc:	7100085f 	cmp	w2, #0x2
    77c0:	54002140 	b.eq	7be8 <f0+0x21f8>  // b.none
    77c4:	7100045f 	cmp	w2, #0x1
    77c8:	540001a1 	b.ne	77fc <f0+0x1e0c>  // b.any
    77cc:	29430002 	ldp	w2, w0, [x0, #24]
    77d0:	92403c21 	and	x1, x1, #0xffff
    77d4:	9b027c21 	mul	x1, x1, x2
    77d8:	d360fc21 	lsr	x1, x1, #32
    77dc:	eb00003f 	cmp	x1, x0
    77e0:	540000e2 	b.cs	77fc <f0+0x1e0c>  // b.hs, b.nlast
    77e4:	8b0102f7 	add	x23, x23, x1
    77e8:	394002e0 	ldrb	w0, [x23]
    77ec:	7103fc1f 	cmp	w0, #0xff
    77f0:	54003220 	b.eq	7e34 <f0+0x2444>  // b.none
    77f4:	52800020 	mov	w0, #0x1                   	// #1
    77f8:	390002e0 	strb	w0, [x23]
    77fc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7800:	911f63e0 	add	x0, sp, #0x7d8
    7804:	f903eff7 	str	x23, [sp, #2008]
    7808:	f903f3f5 	str	x21, [sp, #2016]
    780c:	97ffef3d 	bl	3500 <fwp_data.part.0.constprop.0>
    7810:	97ffeea4 	bl	32a0 <fwp_rc_fresh>
    7814:	aa0003e1 	mov	x1, x0
    7818:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    781c:	911fa3e0 	add	x0, sp, #0x7e8
    7820:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7824:	f903f7f5 	str	x21, [sp, #2024]
    7828:	f903fbe1 	str	x1, [sp, #2032]
    782c:	97ffef35 	bl	3500 <fwp_data.part.0.constprop.0>
    7830:	97ffee9c 	bl	32a0 <fwp_rc_fresh>
    7834:	aa0003e1 	mov	x1, x0
    7838:	911fe3e0 	add	x0, sp, #0x7f8
    783c:	f903fff7 	str	x23, [sp, #2040]
    7840:	f90403e1 	str	x1, [sp, #2048]
    7844:	97ffef2f 	bl	3500 <fwp_data.part.0.constprop.0>
    7848:	97ffee96 	bl	32a0 <fwp_rc_fresh>
    784c:	aa0003e1 	mov	x1, x0
    7850:	912023e0 	add	x0, sp, #0x808
    7854:	f90407f5 	str	x21, [sp, #2056]
    7858:	f9040be1 	str	x1, [sp, #2064]
    785c:	97ffef29 	bl	3500 <fwp_data.part.0.constprop.0>
    7860:	aa0003f5 	mov	x21, x0
    7864:	91140283 	add	x3, x20, #0x500
    7868:	f949d861 	ldr	x1, [x3, #5040]
    786c:	f949ec60 	ldr	x0, [x3, #5080]
    7870:	cb0102a1 	sub	x1, x21, x1
    7874:	eb00403f 	cmp	x1, x0, lsl #16
    7878:	54000322 	b.cs	78dc <f0+0x1eec>  // b.hs, b.nlast
    787c:	d350fc22 	lsr	x2, x1, #16
    7880:	f949fc63 	ldr	x3, [x3, #5112]
    7884:	8b020842 	add	x2, x2, x2, lsl #2
    7888:	d37df042 	lsl	x2, x2, #3
    788c:	8b020060 	add	x0, x3, x2
    7890:	f9401017 	ldr	x23, [x0, #32]
    7894:	b4000257 	cbz	x23, 78dc <f0+0x1eec>
    7898:	38626862 	ldrb	w2, [x3, x2]
    789c:	7100085f 	cmp	w2, #0x2
    78a0:	540019e0 	b.eq	7bdc <f0+0x21ec>  // b.none
    78a4:	7100045f 	cmp	w2, #0x1
    78a8:	540001a1 	b.ne	78dc <f0+0x1eec>  // b.any
    78ac:	29430002 	ldp	w2, w0, [x0, #24]
    78b0:	92403c21 	and	x1, x1, #0xffff
    78b4:	9b027c21 	mul	x1, x1, x2
    78b8:	d360fc21 	lsr	x1, x1, #32
    78bc:	eb00003f 	cmp	x1, x0
    78c0:	540000e2 	b.cs	78dc <f0+0x1eec>  // b.hs, b.nlast
    78c4:	8b0102f7 	add	x23, x23, x1
    78c8:	394002e0 	ldrb	w0, [x23]
    78cc:	7103fc1f 	cmp	w0, #0xff
    78d0:	54002b80 	b.eq	7e40 <f0+0x2450>  // b.none
    78d4:	52800020 	mov	w0, #0x1                   	// #1
    78d8:	390002e0 	strb	w0, [x23]
    78dc:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    78e0:	912063e0 	add	x0, sp, #0x818
    78e4:	f9040fe1 	str	x1, [sp, #2072]
    78e8:	f90413f5 	str	x21, [sp, #2080]
    78ec:	97ffef05 	bl	3500 <fwp_data.part.0.constprop.0>
    78f0:	91140283 	add	x3, x20, #0x500
    78f4:	aa0003f5 	mov	x21, x0
    78f8:	f949d861 	ldr	x1, [x3, #5040]
    78fc:	f949ec60 	ldr	x0, [x3, #5080]
    7900:	cb0102a1 	sub	x1, x21, x1
    7904:	eb00403f 	cmp	x1, x0, lsl #16
    7908:	54000322 	b.cs	796c <f0+0x1f7c>  // b.hs, b.nlast
    790c:	d350fc22 	lsr	x2, x1, #16
    7910:	f949fc63 	ldr	x3, [x3, #5112]
    7914:	8b020842 	add	x2, x2, x2, lsl #2
    7918:	d37df042 	lsl	x2, x2, #3
    791c:	8b020060 	add	x0, x3, x2
    7920:	f9401017 	ldr	x23, [x0, #32]
    7924:	b4000257 	cbz	x23, 796c <f0+0x1f7c>
    7928:	38626862 	ldrb	w2, [x3, x2]
    792c:	7100085f 	cmp	w2, #0x2
    7930:	54001500 	b.eq	7bd0 <f0+0x21e0>  // b.none
    7934:	7100045f 	cmp	w2, #0x1
    7938:	540001a1 	b.ne	796c <f0+0x1f7c>  // b.any
    793c:	29430002 	ldp	w2, w0, [x0, #24]
    7940:	92403c21 	and	x1, x1, #0xffff
    7944:	9b027c21 	mul	x1, x1, x2
    7948:	d360fc21 	lsr	x1, x1, #32
    794c:	eb00003f 	cmp	x1, x0
    7950:	540000e2 	b.cs	796c <f0+0x1f7c>  // b.hs, b.nlast
    7954:	8b0102f7 	add	x23, x23, x1
    7958:	394002e0 	ldrb	w0, [x23]
    795c:	7103fc1f 	cmp	w0, #0xff
    7960:	54002760 	b.eq	7e4c <f0+0x245c>  // b.none
    7964:	52800020 	mov	w0, #0x1                   	// #1
    7968:	390002e0 	strb	w0, [x23]
    796c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7970:	9120a3e0 	add	x0, sp, #0x828
    7974:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7978:	f90417e1 	str	x1, [sp, #2088]
    797c:	f9041bf5 	str	x21, [sp, #2096]
    7980:	91140294 	add	x20, x20, #0x500
    7984:	97ffeedf 	bl	3500 <fwp_data.part.0.constprop.0>
    7988:	97ffee46 	bl	32a0 <fwp_rc_fresh>
    798c:	aa0003e1 	mov	x1, x0
    7990:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7994:	9120e3e0 	add	x0, sp, #0x838
    7998:	f9041fe2 	str	x2, [sp, #2104]
    799c:	f90423e1 	str	x1, [sp, #2112]
    79a0:	97ffeed8 	bl	3500 <fwp_data.part.0.constprop.0>
    79a4:	f949da81 	ldr	x1, [x20, #5040]
    79a8:	aa0003f5 	mov	x21, x0
    79ac:	f949ee80 	ldr	x0, [x20, #5080]
    79b0:	cb0102a1 	sub	x1, x21, x1
    79b4:	eb00403f 	cmp	x1, x0, lsl #16
    79b8:	54000322 	b.cs	7a1c <f0+0x202c>  // b.hs, b.nlast
    79bc:	d350fc22 	lsr	x2, x1, #16
    79c0:	f949fe83 	ldr	x3, [x20, #5112]
    79c4:	8b020842 	add	x2, x2, x2, lsl #2
    79c8:	d37df042 	lsl	x2, x2, #3
    79cc:	8b020060 	add	x0, x3, x2
    79d0:	f9401014 	ldr	x20, [x0, #32]
    79d4:	b4000254 	cbz	x20, 7a1c <f0+0x202c>
    79d8:	38626862 	ldrb	w2, [x3, x2]
    79dc:	7100085f 	cmp	w2, #0x2
    79e0:	54000f20 	b.eq	7bc4 <f0+0x21d4>  // b.none
    79e4:	7100045f 	cmp	w2, #0x1
    79e8:	540001a1 	b.ne	7a1c <f0+0x202c>  // b.any
    79ec:	29430002 	ldp	w2, w0, [x0, #24]
    79f0:	92403c21 	and	x1, x1, #0xffff
    79f4:	9b027c21 	mul	x1, x1, x2
    79f8:	d360fc21 	lsr	x1, x1, #32
    79fc:	eb00003f 	cmp	x1, x0
    7a00:	540000e2 	b.cs	7a1c <f0+0x202c>  // b.hs, b.nlast
    7a04:	8b010294 	add	x20, x20, x1
    7a08:	39400280 	ldrb	w0, [x20]
    7a0c:	7103fc1f 	cmp	w0, #0xff
    7a10:	540013a0 	b.eq	7c84 <f0+0x2294>  // b.none
    7a14:	52800020 	mov	w0, #0x1                   	// #1
    7a18:	39000280 	strb	w0, [x20]
    7a1c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7a20:	aa1603e0 	mov	x0, x22
    7a24:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7a28:	f90427e1 	str	x1, [sp, #2120]
    7a2c:	f9042bf5 	str	x21, [sp, #2128]
    7a30:	97ffeeb4 	bl	3500 <fwp_data.part.0.constprop.0>
    7a34:	97ffee1b 	bl	32a0 <fwp_rc_fresh>
    7a38:	aa0003f5 	mov	x21, x0
    7a3c:	aa1303e1 	mov	x1, x19
    7a40:	97fff4a1 	bl	4cc4 <fwp_hof0.constprop.0>
    7a44:	aa0003f4 	mov	x20, x0
    7a48:	aa1503e0 	mov	x0, x21
    7a4c:	97ffef09 	bl	3670 <fwp_drop0>
    7a50:	aa1303e0 	mov	x0, x19
    7a54:	97ffef07 	bl	3670 <fwp_drop0>
    7a58:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    7a5c:	f947f400 	ldr	x0, [x0, #4072]
    7a60:	f9442fe2 	ldr	x2, [sp, #2136]
    7a64:	f9400001 	ldr	x1, [x0]
    7a68:	eb010042 	subs	x2, x2, x1
    7a6c:	d2800001 	mov	x1, #0x0                   	// #0
    7a70:	54001f41 	b.ne	7e58 <f0+0x2468>  // b.any
    7a74:	912183ff 	add	sp, sp, #0x860
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7a80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7a84:	a94363f7 	ldp	x23, x24, [sp, #48]
    7a88:	a9446bf9 	ldp	x25, x26, [sp, #64]
    7a8c:	a94573fb 	ldp	x27, x28, [sp, #80]
    7a90:	a8c67bfd 	ldp	x29, x30, [sp], #96
    7a94:	d65f03c0 	ret
    7a98:	aa1b03e0 	mov	x0, x27
    7a9c:	97ffec42 	bl	2ba4 <fwp_rc_forget_slot>
    7aa0:	17fff81b 	b	5b0c <f0+0x11c>
    7aa4:	72003c5f 	tst	w2, #0xffff
    7aa8:	54ff0341 	b.ne	5b10 <f0+0x120>  // b.any
    7aac:	17fff815 	b	5b00 <f0+0x110>
    7ab0:	72003c3f 	tst	w1, #0xffff
    7ab4:	54ff8ec1 	b.ne	6c8c <f0+0x129c>  // b.any
    7ab8:	17fffc70 	b	6c78 <f0+0x1288>
    7abc:	72003c3f 	tst	w1, #0xffff
    7ac0:	54ff8821 	b.ne	6bc4 <f0+0x11d4>  // b.any
    7ac4:	17fffc3b 	b	6bb0 <f0+0x11c0>
    7ac8:	72003c3f 	tst	w1, #0xffff
    7acc:	54ff80c1 	b.ne	6ae4 <f0+0x10f4>  // b.any
    7ad0:	17fffc00 	b	6ad0 <f0+0x10e0>
    7ad4:	72003c3f 	tst	w1, #0xffff
    7ad8:	54ff7721 	b.ne	69bc <f0+0xfcc>  // b.any
    7adc:	17fffbb3 	b	69a8 <f0+0xfb8>
    7ae0:	72003c3f 	tst	w1, #0xffff
    7ae4:	54ff7241 	b.ne	692c <f0+0xf3c>  // b.any
    7ae8:	17fffb8c 	b	6918 <f0+0xf28>
    7aec:	72003c3f 	tst	w1, #0xffff
    7af0:	54ff6d41 	b.ne	6898 <f0+0xea8>  // b.any
    7af4:	17fffb64 	b	6884 <f0+0xe94>
    7af8:	72003c3f 	tst	w1, #0xffff
    7afc:	54ff66a1 	b.ne	67d0 <f0+0xde0>  // b.any
    7b00:	17fffb2f 	b	67bc <f0+0xdcc>
    7b04:	72003c3f 	tst	w1, #0xffff
    7b08:	54ff5f41 	b.ne	66f0 <f0+0xd00>  // b.any
    7b0c:	17fffaf4 	b	66dc <f0+0xcec>
    7b10:	72003c3f 	tst	w1, #0xffff
    7b14:	54ff19c1 	b.ne	5e4c <f0+0x45c>  // b.any
    7b18:	17fff8c8 	b	5e38 <f0+0x448>
    7b1c:	72003c3f 	tst	w1, #0xffff
    7b20:	54ff1501 	b.ne	5dc0 <f0+0x3d0>  // b.any
    7b24:	17fff8a2 	b	5dac <f0+0x3bc>
    7b28:	72003c3f 	tst	w1, #0xffff
    7b2c:	54ff07e1 	b.ne	5c28 <f0+0x238>  // b.any
    7b30:	17fff839 	b	5c14 <f0+0x224>
    7b34:	72003c3f 	tst	w1, #0xffff
    7b38:	54ff2ce1 	b.ne	60d4 <f0+0x6e4>  // b.any
    7b3c:	17fff961 	b	60c0 <f0+0x6d0>
    7b40:	72003c3f 	tst	w1, #0xffff
    7b44:	54ff2741 	b.ne	602c <f0+0x63c>  // b.any
    7b48:	17fff934 	b	6018 <f0+0x628>
    7b4c:	72003c3f 	tst	w1, #0xffff
    7b50:	54ff21a1 	b.ne	5f84 <f0+0x594>  // b.any
    7b54:	17fff907 	b	5f70 <f0+0x580>
    7b58:	72003c3f 	tst	w1, #0xffff
    7b5c:	54ff1c01 	b.ne	5edc <f0+0x4ec>  // b.any
    7b60:	17fff8da 	b	5ec8 <f0+0x4d8>
    7b64:	72003c3f 	tst	w1, #0xffff
    7b68:	54ff57a1 	b.ne	665c <f0+0xc6c>  // b.any
    7b6c:	17fffab7 	b	6648 <f0+0xc58>
    7b70:	72003c3f 	tst	w1, #0xffff
    7b74:	54ff5101 	b.ne	6594 <f0+0xba4>  // b.any
    7b78:	17fffa82 	b	6580 <f0+0xb90>
    7b7c:	72003c3f 	tst	w1, #0xffff
    7b80:	54ff4c01 	b.ne	6500 <f0+0xb10>  // b.any
    7b84:	17fffa5a 	b	64ec <f0+0xafc>
    7b88:	72003c3f 	tst	w1, #0xffff
    7b8c:	54ff4721 	b.ne	6470 <f0+0xa80>  // b.any
    7b90:	17fffa33 	b	645c <f0+0xa6c>
    7b94:	72003c3f 	tst	w1, #0xffff
    7b98:	54ff4141 	b.ne	63c0 <f0+0x9d0>  // b.any
    7b9c:	17fffa04 	b	63ac <f0+0x9bc>
    7ba0:	72003c3f 	tst	w1, #0xffff
    7ba4:	54ff39e1 	b.ne	62e0 <f0+0x8f0>  // b.any
    7ba8:	17fff9c9 	b	62cc <f0+0x8dc>
    7bac:	72003c3f 	tst	w1, #0xffff
    7bb0:	54ff3401 	b.ne	6230 <f0+0x840>  // b.any
    7bb4:	17fff99a 	b	621c <f0+0x82c>
    7bb8:	72003c3f 	tst	w1, #0xffff
    7bbc:	54ff2e21 	b.ne	6180 <f0+0x790>  // b.any
    7bc0:	17fff96b 	b	616c <f0+0x77c>
    7bc4:	72003c3f 	tst	w1, #0xffff
    7bc8:	54fff2a1 	b.ne	7a1c <f0+0x202c>  // b.any
    7bcc:	17ffff8f 	b	7a08 <f0+0x2018>
    7bd0:	72003c3f 	tst	w1, #0xffff
    7bd4:	54ffecc1 	b.ne	796c <f0+0x1f7c>  // b.any
    7bd8:	17ffff60 	b	7958 <f0+0x1f68>
    7bdc:	72003c3f 	tst	w1, #0xffff
    7be0:	54ffe7e1 	b.ne	78dc <f0+0x1eec>  // b.any
    7be4:	17ffff39 	b	78c8 <f0+0x1ed8>
    7be8:	72003c3f 	tst	w1, #0xffff
    7bec:	54ffe081 	b.ne	77fc <f0+0x1e0c>  // b.any
    7bf0:	17fffefe 	b	77e8 <f0+0x1df8>
    7bf4:	72003c3f 	tst	w1, #0xffff
    7bf8:	54ffd921 	b.ne	771c <f0+0x1d2c>  // b.any
    7bfc:	17fffec3 	b	7708 <f0+0x1d18>
    7c00:	72003c3f 	tst	w1, #0xffff
    7c04:	54ffd1c1 	b.ne	763c <f0+0x1c4c>  // b.any
    7c08:	17fffe88 	b	7628 <f0+0x1c38>
    7c0c:	72003c3f 	tst	w1, #0xffff
    7c10:	54ffc9a1 	b.ne	7544 <f0+0x1b54>  // b.any
    7c14:	17fffe47 	b	7530 <f0+0x1b40>
    7c18:	72003c3f 	tst	w1, #0xffff
    7c1c:	54ffc301 	b.ne	747c <f0+0x1a8c>  // b.any
    7c20:	17fffe12 	b	7468 <f0+0x1a78>
    7c24:	72003c3f 	tst	w1, #0xffff
    7c28:	54ffbba1 	b.ne	739c <f0+0x19ac>  // b.any
    7c2c:	17fffdd7 	b	7388 <f0+0x1998>
    7c30:	72003c3f 	tst	w1, #0xffff
    7c34:	54ffb6a1 	b.ne	7308 <f0+0x1918>  // b.any
    7c38:	17fffdaf 	b	72f4 <f0+0x1904>
    7c3c:	72003c3f 	tst	w1, #0xffff
    7c40:	54ffad01 	b.ne	71e0 <f0+0x17f0>  // b.any
    7c44:	17fffd62 	b	71cc <f0+0x17dc>
    7c48:	72003c3f 	tst	w1, #0xffff
    7c4c:	54ffa801 	b.ne	714c <f0+0x175c>  // b.any
    7c50:	17fffd3a 	b	7138 <f0+0x1748>
    7c54:	72003c3f 	tst	w1, #0xffff
    7c58:	54ff9da1 	b.ne	700c <f0+0x161c>  // b.any
    7c5c:	17fffce7 	b	6ff8 <f0+0x1608>
    7c60:	72003c3f 	tst	w1, #0xffff
    7c64:	54ff9701 	b.ne	6f44 <f0+0x1554>  // b.any
    7c68:	17fffcb2 	b	6f30 <f0+0x1540>
    7c6c:	72003c3f 	tst	w1, #0xffff
    7c70:	54ff8ee1 	b.ne	6e4c <f0+0x145c>  // b.any
    7c74:	17fffc71 	b	6e38 <f0+0x1448>
    7c78:	72003c3f 	tst	w1, #0xffff
    7c7c:	54ff8841 	b.ne	6d84 <f0+0x1394>  // b.any
    7c80:	17fffc3c 	b	6d70 <f0+0x1380>
    7c84:	aa1403e0 	mov	x0, x20
    7c88:	97ffebc7 	bl	2ba4 <fwp_rc_forget_slot>
    7c8c:	17ffff62 	b	7a14 <f0+0x2024>
    7c90:	aa1703e0 	mov	x0, x23
    7c94:	97ffebc4 	bl	2ba4 <fwp_rc_forget_slot>
    7c98:	17fff7e2 	b	5c20 <f0+0x230>
    7c9c:	aa1703e0 	mov	x0, x23
    7ca0:	97ffebc1 	bl	2ba4 <fwp_rc_forget_slot>
    7ca4:	17fff845 	b	5db8 <f0+0x3c8>
    7ca8:	aa1703e0 	mov	x0, x23
    7cac:	97ffebbe 	bl	2ba4 <fwp_rc_forget_slot>
    7cb0:	17fff865 	b	5e44 <f0+0x454>
    7cb4:	aa1703e0 	mov	x0, x23
    7cb8:	97ffebbb 	bl	2ba4 <fwp_rc_forget_slot>
    7cbc:	17fff886 	b	5ed4 <f0+0x4e4>
    7cc0:	aa1703e0 	mov	x0, x23
    7cc4:	97ffebb8 	bl	2ba4 <fwp_rc_forget_slot>
    7cc8:	17fff8ad 	b	5f7c <f0+0x58c>
    7ccc:	aa1703e0 	mov	x0, x23
    7cd0:	97ffebb5 	bl	2ba4 <fwp_rc_forget_slot>
    7cd4:	17fff8d4 	b	6024 <f0+0x634>
    7cd8:	aa1703e0 	mov	x0, x23
    7cdc:	97ffebb2 	bl	2ba4 <fwp_rc_forget_slot>
    7ce0:	17fff8fb 	b	60cc <f0+0x6dc>
    7ce4:	aa1703e0 	mov	x0, x23
    7ce8:	97ffebaf 	bl	2ba4 <fwp_rc_forget_slot>
    7cec:	17fff923 	b	6178 <f0+0x788>
    7cf0:	aa1703e0 	mov	x0, x23
    7cf4:	97ffebac 	bl	2ba4 <fwp_rc_forget_slot>
    7cf8:	17fff94c 	b	6228 <f0+0x838>
    7cfc:	aa1703e0 	mov	x0, x23
    7d00:	97ffeba9 	bl	2ba4 <fwp_rc_forget_slot>
    7d04:	17fff975 	b	62d8 <f0+0x8e8>
    7d08:	aa1703e0 	mov	x0, x23
    7d0c:	97ffeba6 	bl	2ba4 <fwp_rc_forget_slot>
    7d10:	17fff9aa 	b	63b8 <f0+0x9c8>
    7d14:	aa1703e0 	mov	x0, x23
    7d18:	97ffeba3 	bl	2ba4 <fwp_rc_forget_slot>
    7d1c:	17fff9d3 	b	6468 <f0+0xa78>
    7d20:	aa1703e0 	mov	x0, x23
    7d24:	97ffeba0 	bl	2ba4 <fwp_rc_forget_slot>
    7d28:	17fff9f4 	b	64f8 <f0+0xb08>
    7d2c:	aa1703e0 	mov	x0, x23
    7d30:	97ffeb9d 	bl	2ba4 <fwp_rc_forget_slot>
    7d34:	17fffa16 	b	658c <f0+0xb9c>
    7d38:	aa1703e0 	mov	x0, x23
    7d3c:	97ffeb9a 	bl	2ba4 <fwp_rc_forget_slot>
    7d40:	17fffa45 	b	6654 <f0+0xc64>
    7d44:	aa1703e0 	mov	x0, x23
    7d48:	97ffeb97 	bl	2ba4 <fwp_rc_forget_slot>
    7d4c:	17fffa67 	b	66e8 <f0+0xcf8>
    7d50:	aa1703e0 	mov	x0, x23
    7d54:	97ffeb94 	bl	2ba4 <fwp_rc_forget_slot>
    7d58:	17fffa9c 	b	67c8 <f0+0xdd8>
    7d5c:	aa1703e0 	mov	x0, x23
    7d60:	97ffeb91 	bl	2ba4 <fwp_rc_forget_slot>
    7d64:	17fffacb 	b	6890 <f0+0xea0>
    7d68:	aa1703e0 	mov	x0, x23
    7d6c:	97ffeb8e 	bl	2ba4 <fwp_rc_forget_slot>
    7d70:	17fffaed 	b	6924 <f0+0xf34>
    7d74:	aa1503e0 	mov	x0, x21
    7d78:	97ffeb8b 	bl	2ba4 <fwp_rc_forget_slot>
    7d7c:	17fffb0e 	b	69b4 <f0+0xfc4>
    7d80:	aa1703e0 	mov	x0, x23
    7d84:	97ffeb88 	bl	2ba4 <fwp_rc_forget_slot>
    7d88:	17fffb55 	b	6adc <f0+0x10ec>
    7d8c:	aa1703e0 	mov	x0, x23
    7d90:	97ffeb85 	bl	2ba4 <fwp_rc_forget_slot>
    7d94:	17fffb8a 	b	6bbc <f0+0x11cc>
    7d98:	aa1703e0 	mov	x0, x23
    7d9c:	97ffeb82 	bl	2ba4 <fwp_rc_forget_slot>
    7da0:	17fffbb9 	b	6c84 <f0+0x1294>
    7da4:	aa1703e0 	mov	x0, x23
    7da8:	97ffeb7f 	bl	2ba4 <fwp_rc_forget_slot>
    7dac:	17fffbf4 	b	6d7c <f0+0x138c>
    7db0:	aa1703e0 	mov	x0, x23
    7db4:	97ffeb7c 	bl	2ba4 <fwp_rc_forget_slot>
    7db8:	17fffc23 	b	6e44 <f0+0x1454>
    7dbc:	aa1703e0 	mov	x0, x23
    7dc0:	97ffeb79 	bl	2ba4 <fwp_rc_forget_slot>
    7dc4:	17fffc5e 	b	6f3c <f0+0x154c>
    7dc8:	aa1703e0 	mov	x0, x23
    7dcc:	97ffeb76 	bl	2ba4 <fwp_rc_forget_slot>
    7dd0:	17fffc8d 	b	7004 <f0+0x1614>
    7dd4:	aa1703e0 	mov	x0, x23
    7dd8:	97ffeb73 	bl	2ba4 <fwp_rc_forget_slot>
    7ddc:	17fffcda 	b	7144 <f0+0x1754>
    7de0:	aa1503e0 	mov	x0, x21
    7de4:	97ffeb70 	bl	2ba4 <fwp_rc_forget_slot>
    7de8:	17fffcfc 	b	71d8 <f0+0x17e8>
    7dec:	aa1703e0 	mov	x0, x23
    7df0:	97ffeb6d 	bl	2ba4 <fwp_rc_forget_slot>
    7df4:	17fffd43 	b	7300 <f0+0x1910>
    7df8:	aa1703e0 	mov	x0, x23
    7dfc:	97ffeb6a 	bl	2ba4 <fwp_rc_forget_slot>
    7e00:	17fffd65 	b	7394 <f0+0x19a4>
    7e04:	aa1703e0 	mov	x0, x23
    7e08:	97ffeb67 	bl	2ba4 <fwp_rc_forget_slot>
    7e0c:	17fffd9a 	b	7474 <f0+0x1a84>
    7e10:	aa1703e0 	mov	x0, x23
    7e14:	97ffeb64 	bl	2ba4 <fwp_rc_forget_slot>
    7e18:	17fffdc9 	b	753c <f0+0x1b4c>
    7e1c:	aa1703e0 	mov	x0, x23
    7e20:	97ffeb61 	bl	2ba4 <fwp_rc_forget_slot>
    7e24:	17fffe04 	b	7634 <f0+0x1c44>
    7e28:	aa1703e0 	mov	x0, x23
    7e2c:	97ffeb5e 	bl	2ba4 <fwp_rc_forget_slot>
    7e30:	17fffe39 	b	7714 <f0+0x1d24>
    7e34:	aa1703e0 	mov	x0, x23
    7e38:	97ffeb5b 	bl	2ba4 <fwp_rc_forget_slot>
    7e3c:	17fffe6e 	b	77f4 <f0+0x1e04>
    7e40:	aa1703e0 	mov	x0, x23
    7e44:	97ffeb58 	bl	2ba4 <fwp_rc_forget_slot>
    7e48:	17fffea3 	b	78d4 <f0+0x1ee4>
    7e4c:	aa1703e0 	mov	x0, x23
    7e50:	97ffeb55 	bl	2ba4 <fwp_rc_forget_slot>
    7e54:	17fffec4 	b	7964 <f0+0x1f74>
    7e58:	97ffe592 	bl	14a0 <__stack_chk_fail@plt>
    7e5c:	d503201f 	nop

0000000000007e60 <fwp_main_thread>:
    7e60:	d10443ff 	sub	sp, sp, #0x110
    7e64:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    7e68:	f947f400 	ldr	x0, [x0, #4072]
    7e6c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7e70:	910303fd 	add	x29, sp, #0xc0
    7e74:	a90d53f3 	stp	x19, x20, [sp, #208]
    7e78:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xce0>
    7e7c:	91140261 	add	x1, x19, #0x500
    7e80:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7e84:	b953a421 	ldr	w1, [x1, #5028]
    7e88:	f9400002 	ldr	x2, [x0]
    7e8c:	f9005fe2 	str	x2, [sp, #184]
    7e90:	d2800002 	mov	x2, #0x0                   	// #0
    7e94:	340025c1 	cbz	w1, 834c <fwp_main_thread+0x4ec>
    7e98:	91140273 	add	x19, x19, #0x500
    7e9c:	b953aa60 	ldr	w0, [x19, #5032]
    7ea0:	350024e0 	cbnz	w0, 833c <fwp_main_thread+0x4dc>
    7ea4:	91001fe2 	add	x2, sp, #0x7
    7ea8:	b00000d5 	adrp	x21, 20000 <__data_start>
    7eac:	b00000c3 	adrp	x3, 20000 <__data_start>
    7eb0:	910182b3 	add	x19, x21, #0x60
    7eb4:	910c8063 	add	x3, x3, #0x320
    7eb8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    7ebc:	d2a00025 	mov	x5, #0x10000               	// #65536
    7ec0:	910023e0 	add	x0, sp, #0x8
    7ec4:	d2800001 	mov	x1, #0x0                   	// #0
    7ec8:	f90007e3 	str	x3, [sp, #8]
    7ecc:	a9011262 	stp	x2, x4, [x19, #16]
    7ed0:	b90013ff 	str	wzr, [sp, #16]
    7ed4:	f9000fe5 	str	x5, [sp, #24]
    7ed8:	97ffe50e 	bl	1310 <sigaltstack@plt>
    7edc:	35002520 	cbnz	w0, 8380 <fwp_main_thread+0x520>
    7ee0:	4f000400 	movi	v0.4s, #0x0
    7ee4:	9100a3e0 	add	x0, sp, #0x28
    7ee8:	d0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    7eec:	52800082 	mov	w2, #0x4                   	// #4
    7ef0:	912f4021 	add	x1, x1, #0xbd0
    7ef4:	72a10002 	movk	w2, #0x800, lsl #16
    7ef8:	910083f4 	add	x20, sp, #0x20
    7efc:	f90013e1 	str	x1, [sp, #32]
    7f00:	3d802000 	str	q0, [x0, #128]
    7f04:	b900abe2 	str	w2, [sp, #168]
    7f08:	ad000000 	stp	q0, q0, [x0]
    7f0c:	ad010000 	stp	q0, q0, [x0, #32]
    7f10:	ad020000 	stp	q0, q0, [x0, #64]
    7f14:	ad030000 	stp	q0, q0, [x0, #96]
    7f18:	97ffe552 	bl	1460 <sigemptyset@plt>
    7f1c:	35002320 	cbnz	w0, 8380 <fwp_main_thread+0x520>
    7f20:	aa1403e1 	mov	x1, x20
    7f24:	d2800002 	mov	x2, #0x0                   	// #0
    7f28:	52800160 	mov	w0, #0xb                   	// #11
    7f2c:	97ffe565 	bl	14c0 <sigaction@plt>
    7f30:	35002280 	cbnz	w0, 8380 <fwp_main_thread+0x520>
    7f34:	aa1403e1 	mov	x1, x20
    7f38:	d2800002 	mov	x2, #0x0                   	// #0
    7f3c:	528000e0 	mov	w0, #0x7                   	// #7
    7f40:	97ffe560 	bl	14c0 <sigaction@plt>
    7f44:	350021e0 	cbnz	w0, 8380 <fwp_main_thread+0x520>
    7f48:	b9429660 	ldr	w0, [x19, #660]
    7f4c:	a90f63f7 	stp	x23, x24, [sp, #240]
    7f50:	34002020 	cbz	w0, 8354 <fwp_main_thread+0x4f4>
    7f54:	910182b6 	add	x22, x21, #0x60
    7f58:	f94006d4 	ldr	x20, [x22, #8]
    7f5c:	b40010d4 	cbz	x20, 8174 <fwp_main_thread+0x314>
    7f60:	aa1403f3 	mov	x19, x20
    7f64:	91010297 	add	x23, x20, #0x40
    7f68:	f90083f9 	str	x25, [sp, #256]
    7f6c:	52800038 	mov	w24, #0x1                   	// #1
    7f70:	39414a99 	ldrb	w25, [x20, #82]
    7f74:	39014a98 	strb	w24, [x20, #82]
    7f78:	f9401680 	ldr	x0, [x20, #40]
    7f7c:	b4000620 	cbz	x0, 8040 <fwp_main_thread+0x1e0>
    7f80:	f9403281 	ldr	x1, [x20, #96]
    7f84:	39414680 	ldrb	w0, [x20, #81]
    7f88:	b4000b41 	cbz	x1, 80f0 <fwp_main_thread+0x290>
    7f8c:	36000a80 	tbz	w0, #0, 80dc <fwp_main_thread+0x27c>
    7f90:	39414a62 	ldrb	w2, [x19, #82]
    7f94:	f9402280 	ldr	x0, [x20, #64]
    7f98:	37000d62 	tbnz	w2, #0, 8144 <fwp_main_thread+0x2e4>
    7f9c:	f9403261 	ldr	x1, [x19, #96]
    7fa0:	a911fe77 	stp	x23, xzr, [x19, #280]
    7fa4:	f9009660 	str	x0, [x19, #296]
    7fa8:	b4000040 	cbz	x0, 7fb0 <fwp_main_thread+0x150>
    7fac:	f9009013 	str	x19, [x0, #288]
    7fb0:	f9002293 	str	x19, [x20, #64]
    7fb4:	b4000101 	cbz	x1, 7fd4 <fwp_main_thread+0x174>
    7fb8:	f9401ac0 	ldr	x0, [x22, #48]
    7fbc:	39015678 	strb	w24, [x19, #85]
    7fc0:	f9003661 	str	x1, [x19, #104]
    7fc4:	a910827f 	stp	xzr, x0, [x19, #264]
    7fc8:	b4000040 	cbz	x0, 7fd0 <fwp_main_thread+0x170>
    7fcc:	f9008413 	str	x19, [x0, #264]
    7fd0:	f9001ad3 	str	x19, [x22, #48]
    7fd4:	39015a7f 	strb	wzr, [x19, #86]
    7fd8:	97ffeefb 	bl	3bc4 <fwp_block>
    7fdc:	f9408e62 	ldr	x2, [x19, #280]
    7fe0:	b4000142 	cbz	x2, 8008 <fwp_main_thread+0x1a8>
    7fe4:	a9520261 	ldp	x1, x0, [x19, #288]
    7fe8:	b4000ba1 	cbz	x1, 815c <fwp_main_thread+0x2fc>
    7fec:	f9009420 	str	x0, [x1, #296]
    7ff0:	f9409660 	ldr	x0, [x19, #296]
    7ff4:	b4000040 	cbz	x0, 7ffc <fwp_main_thread+0x19c>
    7ff8:	f9009001 	str	x1, [x0, #288]
    7ffc:	91080260 	add	x0, x19, #0x200
    8000:	f900967f 	str	xzr, [x19, #296]
    8004:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8008:	39415660 	ldrb	w0, [x19, #85]
    800c:	f94006c2 	ldr	x2, [x22, #8]
    8010:	36000960 	tbz	w0, #0, 813c <fwp_main_thread+0x2dc>
    8014:	a9508261 	ldp	x1, x0, [x19, #264]
    8018:	b4000a61 	cbz	x1, 8164 <fwp_main_thread+0x304>
    801c:	f9008820 	str	x0, [x1, #272]
    8020:	b4000040 	cbz	x0, 8028 <fwp_main_thread+0x1c8>
    8024:	f9008401 	str	x1, [x0, #264]
    8028:	91080260 	add	x0, x19, #0x200
    802c:	3901567f 	strb	wzr, [x19, #85]
    8030:	aa0203f3 	mov	x19, x2
    8034:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8038:	f9401680 	ldr	x0, [x20, #40]
    803c:	b5fffa20 	cbnz	x0, 7f80 <fwp_main_thread+0x120>
    8040:	910182a0 	add	x0, x21, #0x60
    8044:	39014a99 	strb	w25, [x20, #82]
    8048:	f94083f9 	ldr	x25, [sp, #256]
    804c:	f9413c00 	ldr	x0, [x0, #632]
    8050:	b4001560 	cbz	x0, 82fc <fwp_main_thread+0x49c>
    8054:	910182a0 	add	x0, x21, #0x60
    8058:	f9415401 	ldr	x1, [x0, #680]
    805c:	b902a01f 	str	wzr, [x0, #672]
    8060:	eb13003f 	cmp	x1, x19
    8064:	54001681 	b.ne	8334 <fwp_main_thread+0x4d4>  // b.any
    8068:	b4000913 	cbz	x19, 8188 <fwp_main_thread+0x328>
    806c:	910182a0 	add	x0, x21, #0x60
    8070:	52800021 	mov	w1, #0x1                   	// #1
    8074:	39014a61 	strb	w1, [x19, #82]
    8078:	f9412805 	ldr	x5, [x0, #592]
    807c:	b4000865 	cbz	x5, 8188 <fwp_main_thread+0x328>
    8080:	394140a0 	ldrb	w0, [x5, #80]
    8084:	37000060 	tbnz	w0, #0, 8090 <fwp_main_thread+0x230>
    8088:	aa0503e0 	mov	x0, x5
    808c:	97ffe7c1 	bl	1f90 <fwp_cancel_tree.part.0>
    8090:	f9409ca5 	ldr	x5, [x5, #312]
    8094:	b5ffff65 	cbnz	x5, 8080 <fwp_main_thread+0x220>
    8098:	910182b4 	add	x20, x21, #0x60
    809c:	52800036 	mov	w22, #0x1                   	// #1
    80a0:	f9402a60 	ldr	x0, [x19, #80]
    80a4:	f2001c1f 	tst	x0, #0xff000000ff
    80a8:	540000e1 	b.ne	80c4 <fwp_main_thread+0x264>  // b.any
    80ac:	f9401280 	ldr	x0, [x20, #32]
    80b0:	39015276 	strb	w22, [x19, #84]
    80b4:	f900827f 	str	xzr, [x19, #256]
    80b8:	b40005a0 	cbz	x0, 816c <fwp_main_thread+0x30c>
    80bc:	f9008013 	str	x19, [x0, #256]
    80c0:	f9001293 	str	x19, [x20, #32]
    80c4:	97ffeec0 	bl	3bc4 <fwp_block>
    80c8:	97ffee52 	bl	3a10 <fwp_free_zombie>
    80cc:	f9412a80 	ldr	x0, [x20, #592]
    80d0:	b40005c0 	cbz	x0, 8188 <fwp_main_thread+0x328>
    80d4:	f9415693 	ldr	x19, [x20, #680]
    80d8:	17fffff2 	b	80a0 <fwp_main_thread+0x240>
    80dc:	97ffe801 	bl	20e0 <fwp_now_ns>
    80e0:	f9403281 	ldr	x1, [x20, #96]
    80e4:	eb01001f 	cmp	x0, x1
    80e8:	54000fca 	b.ge	82e0 <fwp_main_thread+0x480>  // b.tcont
    80ec:	39414680 	ldrb	w0, [x20, #81]
    80f0:	39414a62 	ldrb	w2, [x19, #82]
    80f4:	3707f500 	tbnz	w0, #0, 7f94 <fwp_main_thread+0x134>
    80f8:	f9403281 	ldr	x1, [x20, #96]
    80fc:	370001c2 	tbnz	w2, #0, 8134 <fwp_main_thread+0x2d4>
    8100:	f9403260 	ldr	x0, [x19, #96]
    8104:	b4000180 	cbz	x0, 8134 <fwp_main_thread+0x2d4>
    8108:	b4000061 	cbz	x1, 8114 <fwp_main_thread+0x2b4>
    810c:	eb01001f 	cmp	x0, x1
    8110:	9a81d000 	csel	x0, x0, x1, le
    8114:	f9402281 	ldr	x1, [x20, #64]
    8118:	a911fe77 	stp	x23, xzr, [x19, #280]
    811c:	f9009661 	str	x1, [x19, #296]
    8120:	b4001241 	cbz	x1, 8368 <fwp_main_thread+0x508>
    8124:	f9009033 	str	x19, [x1, #288]
    8128:	aa0003e1 	mov	x1, x0
    812c:	f9002293 	str	x19, [x20, #64]
    8130:	17ffffa2 	b	7fb8 <fwp_main_thread+0x158>
    8134:	f9402280 	ldr	x0, [x20, #64]
    8138:	17ffff9a 	b	7fa0 <fwp_main_thread+0x140>
    813c:	aa0203f3 	mov	x19, x2
    8140:	17ffff8e 	b	7f78 <fwp_main_thread+0x118>
    8144:	a911fe77 	stp	x23, xzr, [x19, #280]
    8148:	f9009660 	str	x0, [x19, #296]
    814c:	b4000040 	cbz	x0, 8154 <fwp_main_thread+0x2f4>
    8150:	f9009013 	str	x19, [x0, #288]
    8154:	f9002293 	str	x19, [x20, #64]
    8158:	17ffff9f 	b	7fd4 <fwp_main_thread+0x174>
    815c:	f9000040 	str	x0, [x2]
    8160:	17ffffa5 	b	7ff4 <fwp_main_thread+0x194>
    8164:	f9001ac0 	str	x0, [x22, #48]
    8168:	17ffffae 	b	8020 <fwp_main_thread+0x1c0>
    816c:	f9001693 	str	x19, [x20, #40]
    8170:	17ffffd4 	b	80c0 <fwp_main_thread+0x260>
    8174:	f9413ec0 	ldr	x0, [x22, #632]
    8178:	b4000c00 	cbz	x0, 82f8 <fwp_main_thread+0x498>
    817c:	f94156c0 	ldr	x0, [x22, #680]
    8180:	b902a2df 	str	wzr, [x22, #672]
    8184:	b5000d80 	cbnz	x0, 8334 <fwp_main_thread+0x4d4>
    8188:	910182b4 	add	x20, x21, #0x60
    818c:	97ffee21 	bl	3a10 <fwp_free_zombie>
    8190:	f9401680 	ldr	x0, [x20, #40]
    8194:	b5000d00 	cbnz	x0, 8334 <fwp_main_thread+0x4d4>
    8198:	f9401a80 	ldr	x0, [x20, #48]
    819c:	b5000cc0 	cbnz	x0, 8334 <fwp_main_thread+0x4d4>
    81a0:	b9404293 	ldr	w19, [x20, #64]
    81a4:	340001d3 	cbz	w19, 81dc <fwp_main_thread+0x37c>
    81a8:	93407e76 	sxtw	x22, w19
    81ac:	51000673 	sub	w19, w19, #0x1
    81b0:	d1000ad6 	sub	x22, x22, #0x2
    81b4:	91014297 	add	x23, x20, #0x50
    81b8:	cb3342d6 	sub	x22, x22, w19, uxtw
    81bc:	93407e73 	sxtw	x19, w19
    81c0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    81c4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    81c8:	b9004293 	str	w19, [x20, #64]
    81cc:	d1000673 	sub	x19, x19, #0x1
    81d0:	97ffe4fc 	bl	15c0 <munmap@plt>
    81d4:	eb16027f 	cmp	x19, x22
    81d8:	54ffff41 	b.ne	81c0 <fwp_main_thread+0x360>  // b.any
    81dc:	900000d3 	adrp	x19, 20000 <__data_start>
    81e0:	91004260 	add	x0, x19, #0x10
    81e4:	b9403000 	ldr	w0, [x0, #48]
    81e8:	37f80040 	tbnz	w0, #31, 81f0 <fwp_main_thread+0x390>
    81ec:	97ffe4b1 	bl	14b0 <close@plt>
    81f0:	910182a0 	add	x0, x21, #0x60
    81f4:	91004261 	add	x1, x19, #0x10
    81f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    81fc:	d2800013 	mov	x19, #0x0                   	// #0
    8200:	f9415816 	ldr	x22, [x0, #688]
    8204:	b9003022 	str	w2, [x1, #48]
    8208:	f9415c14 	ldr	x20, [x0, #696]
    820c:	b4000176 	cbz	x22, 8238 <fwp_main_thread+0x3d8>
    8210:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8214:	b40000c0 	cbz	x0, 822c <fwp_main_thread+0x3cc>
    8218:	f9400001 	ldr	x1, [x0]
    821c:	b50008c1 	cbnz	x1, 8334 <fwp_main_thread+0x4d4>
    8220:	f9400401 	ldr	x1, [x0, #8]
    8224:	b5000881 	cbnz	x1, 8334 <fwp_main_thread+0x4d4>
    8228:	97ffeafe 	bl	2e20 <fwp_mem_free>
    822c:	91000673 	add	x19, x19, #0x1
    8230:	eb16027f 	cmp	x19, x22
    8234:	54fffee1 	b.ne	8210 <fwp_main_thread+0x3b0>  // b.any
    8238:	aa1403e0 	mov	x0, x20
    823c:	97ffeaf9 	bl	2e20 <fwp_mem_free>
    8240:	910182a0 	add	x0, x21, #0x60
    8244:	f9415413 	ldr	x19, [x0, #680]
    8248:	f901581f 	str	xzr, [x0, #688]
    824c:	f9015c1f 	str	xzr, [x0, #696]
    8250:	b40001f3 	cbz	x19, 828c <fwp_main_thread+0x42c>
    8254:	f9401661 	ldr	x1, [x19, #40]
    8258:	b50006e1 	cbnz	x1, 8334 <fwp_main_thread+0x4d4>
    825c:	f9405661 	ldr	x1, [x19, #168]
    8260:	b50006a1 	cbnz	x1, 8334 <fwp_main_thread+0x4d4>
    8264:	f9413c01 	ldr	x1, [x0, #632]
    8268:	b5000661 	cbnz	x1, 8334 <fwp_main_thread+0x4d4>
    826c:	f9414400 	ldr	x0, [x0, #648]
    8270:	b5000620 	cbnz	x0, 8334 <fwp_main_thread+0x4d4>
    8274:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8278:	90000140 	adrp	x0, 30000 <alt.4+0xfce0>
    827c:	910c8000 	add	x0, x0, #0x320
    8280:	97ffe47c 	bl	1470 <memset@plt>
    8284:	aa1303e0 	mov	x0, x19
    8288:	97ffeae6 	bl	2e20 <fwp_mem_free>
    828c:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    8290:	f947ec00 	ldr	x0, [x0, #4056]
    8294:	910182b5 	add	x21, x21, #0x60
    8298:	f9400000 	ldr	x0, [x0]
    829c:	f90006bf 	str	xzr, [x21, #8]
    82a0:	f90156bf 	str	xzr, [x21, #680]
    82a4:	97ffe4cb 	bl	15d0 <fflush@plt>
    82a8:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x152d8>
    82ac:	f947f400 	ldr	x0, [x0, #4072]
    82b0:	f9405fe2 	ldr	x2, [sp, #184]
    82b4:	f9400001 	ldr	x1, [x0]
    82b8:	eb010042 	subs	x2, x2, x1
    82bc:	d2800001 	mov	x1, #0x0                   	// #0
    82c0:	540006a1 	b.ne	8394 <fwp_main_thread+0x534>  // b.any
    82c4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    82c8:	d2800000 	mov	x0, #0x0                   	// #0
    82cc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    82d0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    82d4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    82d8:	910443ff 	add	sp, sp, #0x110
    82dc:	d65f03c0 	ret
    82e0:	39414280 	ldrb	w0, [x20, #80]
    82e4:	3707f040 	tbnz	w0, #0, 80ec <fwp_main_thread+0x28c>
    82e8:	aa1403e0 	mov	x0, x20
    82ec:	97ffe729 	bl	1f90 <fwp_cancel_tree.part.0>
    82f0:	39414680 	ldrb	w0, [x20, #81]
    82f4:	17ffff7f 	b	80f0 <fwp_main_thread+0x290>
    82f8:	d2800013 	mov	x19, #0x0                   	// #0
    82fc:	910182b4 	add	x20, x21, #0x60
    8300:	f9414680 	ldr	x0, [x20, #648]
    8304:	b5ffea80 	cbnz	x0, 8054 <fwp_main_thread+0x1f4>
    8308:	f9413a80 	ldr	x0, [x20, #624]
    830c:	97ffeac5 	bl	2e20 <fwp_mem_free>
    8310:	f9013a9f 	str	xzr, [x20, #624]
    8314:	f901429f 	str	xzr, [x20, #640]
    8318:	f9415680 	ldr	x0, [x20, #680]
    831c:	b40002d3 	cbz	x19, 8374 <fwp_main_thread+0x514>
    8320:	f900567f 	str	xzr, [x19, #168]
    8324:	f9005e7f 	str	xzr, [x19, #184]
    8328:	b902a29f 	str	wzr, [x20, #672]
    832c:	eb00027f 	cmp	x19, x0
    8330:	54ffe9e0 	b.eq	806c <fwp_main_thread+0x20c>  // b.none
    8334:	f90083f9 	str	x25, [sp, #256]
    8338:	97ffe46e 	bl	14f0 <abort@plt>
    833c:	d0ffffc0 	adrp	x0, 2000 <fwp_cancel_tree.part.0+0x70>
    8340:	91161000 	add	x0, x0, #0x584
    8344:	940001d3 	bl	8a90 <atexit>
    8348:	17fffed7 	b	7ea4 <fwp_main_thread+0x44>
    834c:	97ffe8e9 	bl	26f0 <fwp_heap_init>
    8350:	17fffed2 	b	7e98 <fwp_main_thread+0x38>
    8354:	97fff5a7 	bl	59f0 <f0>
    8358:	f9014e60 	str	x0, [x19, #664]
    835c:	52800021 	mov	w1, #0x1                   	// #1
    8360:	b9029661 	str	w1, [x19, #660]
    8364:	17fffefc 	b	7f54 <fwp_main_thread+0xf4>
    8368:	aa0003e1 	mov	x1, x0
    836c:	f9002293 	str	x19, [x20, #64]
    8370:	17ffff12 	b	7fb8 <fwp_main_thread+0x158>
    8374:	b902a29f 	str	wzr, [x20, #672]
    8378:	b4fff080 	cbz	x0, 8188 <fwp_main_thread+0x328>
    837c:	17ffffee 	b	8334 <fwp_main_thread+0x4d4>
    8380:	90000000 	adrp	x0, 8000 <fwp_main_thread+0x1a0>
    8384:	91392000 	add	x0, x0, #0xe48
    8388:	a90f63f7 	stp	x23, x24, [sp, #240]
    838c:	f90083f9 	str	x25, [sp, #256]
    8390:	97ffe744 	bl	20a0 <fwp_trap>
    8394:	f90083f9 	str	x25, [sp, #256]
    8398:	97ffe442 	bl	14a0 <__stack_chk_fail@plt>
    839c:	d503201f 	nop

00000000000083a0 <__divti3>:
    83a0:	d503245f 	bti	c
    83a4:	d2800004 	mov	x4, #0x0                   	// #0
    83a8:	b7f80721 	tbnz	x1, #63, 848c <__divti3+0xec>
    83ac:	b6f80083 	tbz	x3, #63, 83bc <__divti3+0x1c>
    83b0:	eb0203e2 	negs	x2, x2
    83b4:	aa2403e4 	mvn	x4, x4
    83b8:	da0303e3 	ngc	x3, x3
    83bc:	aa0203e6 	mov	x6, x2
    83c0:	aa0003e7 	mov	x7, x0
    83c4:	aa0103e5 	mov	x5, x1
    83c8:	b5000583 	cbnz	x3, 8478 <__divti3+0xd8>
    83cc:	eb01005f 	cmp	x2, x1
    83d0:	54000e69 	b.ls	859c <__divti3+0x1fc>  // b.plast
    83d4:	dac01040 	clz	x0, x2
    83d8:	b40000e0 	cbz	x0, 83f4 <__divti3+0x54>
    83dc:	4b0003e1 	neg	w1, w0
    83e0:	9ac020a5 	lsl	x5, x5, x0
    83e4:	9ac02046 	lsl	x6, x2, x0
    83e8:	9ac124e1 	lsr	x1, x7, x1
    83ec:	aa050025 	orr	x5, x1, x5
    83f0:	9ac020e7 	lsl	x7, x7, x0
    83f4:	d360fcc8 	lsr	x8, x6, #32
    83f8:	92407cc2 	and	x2, x6, #0xffffffff
    83fc:	9ac808a3 	udiv	x3, x5, x8
    8400:	9b089465 	msub	x5, x3, x8, x5
    8404:	aa0303e0 	mov	x0, x3
    8408:	9b037c41 	mul	x1, x2, x3
    840c:	93c780a5 	extr	x5, x5, x7, #32
    8410:	eb05003f 	cmp	x1, x5
    8414:	540000a9 	b.ls	8428 <__divti3+0x88>  // b.plast
    8418:	ab0500c5 	adds	x5, x6, x5
    841c:	d1000460 	sub	x0, x3, #0x1
    8420:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8424:	540015a8 	b.hi	86d8 <__divti3+0x338>  // b.pmore
    8428:	cb0100a5 	sub	x5, x5, x1
    842c:	9ac808a3 	udiv	x3, x5, x8
    8430:	9b089465 	msub	x5, x3, x8, x5
    8434:	aa0303e1 	mov	x1, x3
    8438:	9b037c42 	mul	x2, x2, x3
    843c:	aa0703e3 	mov	x3, x7
    8440:	b3607ca3 	bfi	x3, x5, #32, #32
    8444:	eb03005f 	cmp	x2, x3
    8448:	540000c9 	b.ls	8460 <__divti3+0xc0>  // b.plast
    844c:	ab0300c3 	adds	x3, x6, x3
    8450:	d1000425 	sub	x5, x1, #0x1
    8454:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8458:	d1000821 	sub	x1, x1, #0x2
    845c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8460:	aa008020 	orr	x0, x1, x0, lsl #32
    8464:	d2800001 	mov	x1, #0x0                   	// #0
    8468:	b4000064 	cbz	x4, 8474 <__divti3+0xd4>
    846c:	eb0003e0 	negs	x0, x0
    8470:	da0103e1 	ngc	x1, x1
    8474:	d65f03c0 	ret
    8478:	eb01007f 	cmp	x3, x1
    847c:	54000109 	b.ls	849c <__divti3+0xfc>  // b.plast
    8480:	d2800001 	mov	x1, #0x0                   	// #0
    8484:	d2800000 	mov	x0, #0x0                   	// #0
    8488:	17fffff8 	b	8468 <__divti3+0xc8>
    848c:	eb0003e0 	negs	x0, x0
    8490:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8494:	da0103e1 	ngc	x1, x1
    8498:	17ffffc5 	b	83ac <__divti3+0xc>
    849c:	dac01067 	clz	x7, x3
    84a0:	b40010e7 	cbz	x7, 86bc <__divti3+0x31c>
    84a4:	d2800805 	mov	x5, #0x40                  	// #64
    84a8:	cb0700a5 	sub	x5, x5, x7
    84ac:	9ac72063 	lsl	x3, x3, x7
    84b0:	9ac52448 	lsr	x8, x2, x5
    84b4:	aa030108 	orr	x8, x8, x3
    84b8:	9ac52426 	lsr	x6, x1, x5
    84bc:	92407d0a 	and	x10, x8, #0xffffffff
    84c0:	d360fd09 	lsr	x9, x8, #32
    84c4:	9ac52403 	lsr	x3, x0, x5
    84c8:	9ac72021 	lsl	x1, x1, x7
    84cc:	aa010063 	orr	x3, x3, x1
    84d0:	9ac72042 	lsl	x2, x2, x7
    84d4:	9ac908cb 	udiv	x11, x6, x9
    84d8:	9b099965 	msub	x5, x11, x9, x6
    84dc:	aa0b03e1 	mov	x1, x11
    84e0:	9b0b7d46 	mul	x6, x10, x11
    84e4:	93c380a5 	extr	x5, x5, x3, #32
    84e8:	eb0500df 	cmp	x6, x5
    84ec:	540000a9 	b.ls	8500 <__divti3+0x160>  // b.plast
    84f0:	ab050105 	adds	x5, x8, x5
    84f4:	d1000561 	sub	x1, x11, #0x1
    84f8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    84fc:	54000f48 	b.hi	86e4 <__divti3+0x344>  // b.pmore
    8500:	cb0600a6 	sub	x6, x5, x6
    8504:	9ac908cb 	udiv	x11, x6, x9
    8508:	9b099969 	msub	x9, x11, x9, x6
    850c:	aa0b03e5 	mov	x5, x11
    8510:	9b0b7d4a 	mul	x10, x10, x11
    8514:	b3607d23 	bfi	x3, x9, #32, #32
    8518:	eb03015f 	cmp	x10, x3
    851c:	540000a9 	b.ls	8530 <__divti3+0x190>  // b.plast
    8520:	ab030103 	adds	x3, x8, x3
    8524:	d1000565 	sub	x5, x11, #0x1
    8528:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    852c:	54000e28 	b.hi	86f0 <__divti3+0x350>  // b.pmore
    8530:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8534:	92407c48 	and	x8, x2, #0xffffffff
    8538:	2a0503e5 	mov	w5, w5
    853c:	d360fc42 	lsr	x2, x2, #32
    8540:	d360fc26 	lsr	x6, x1, #32
    8544:	cb0a0063 	sub	x3, x3, x10
    8548:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    854c:	9b087caa 	mul	x10, x5, x8
    8550:	9b087cc8 	mul	x8, x6, x8
    8554:	9b0220a5 	madd	x5, x5, x2, x8
    8558:	9b027cc6 	mul	x6, x6, x2
    855c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8560:	8b0900c5 	add	x5, x6, x9
    8564:	eb02011f 	cmp	x8, x2
    8568:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    856c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8570:	eb06007f 	cmp	x3, x6
    8574:	540000e3 	b.cc	8590 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8578:	92407d4a 	and	x10, x10, #0xffffffff
    857c:	9ac72000 	lsl	x0, x0, x7
    8580:	8b028142 	add	x2, x10, x2, lsl #32
    8584:	eb02001f 	cmp	x0, x2
    8588:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    858c:	54000a01 	b.ne	86cc <__divti3+0x32c>  // b.any
    8590:	d1000420 	sub	x0, x1, #0x1
    8594:	d2800001 	mov	x1, #0x0                   	// #0
    8598:	17ffffb4 	b	8468 <__divti3+0xc8>
    859c:	b5000062 	cbnz	x2, 85a8 <__divti3+0x208>
    85a0:	d2800022 	mov	x2, #0x1                   	// #1
    85a4:	9ac30846 	udiv	x6, x2, x3
    85a8:	dac010c8 	clz	x8, x6
    85ac:	b5000408 	cbnz	x8, 862c <__divti3+0x28c>
    85b0:	d360fcc9 	lsr	x9, x6, #32
    85b4:	92407cc5 	and	x5, x6, #0xffffffff
    85b8:	cb060023 	sub	x3, x1, x6
    85bc:	d2800021 	mov	x1, #0x1                   	// #1
    85c0:	9ac90868 	udiv	x8, x3, x9
    85c4:	9b098d03 	msub	x3, x8, x9, x3
    85c8:	aa0803e0 	mov	x0, x8
    85cc:	9b057d02 	mul	x2, x8, x5
    85d0:	93c78063 	extr	x3, x3, x7, #32
    85d4:	eb03005f 	cmp	x2, x3
    85d8:	540000a9 	b.ls	85ec <__divti3+0x24c>  // b.plast
    85dc:	ab0300c3 	adds	x3, x6, x3
    85e0:	d1000500 	sub	x0, x8, #0x1
    85e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    85e8:	54000968 	b.hi	8714 <__divti3+0x374>  // b.pmore
    85ec:	cb020063 	sub	x3, x3, x2
    85f0:	9ac90862 	udiv	x2, x3, x9
    85f4:	aa0203e8 	mov	x8, x2
    85f8:	9b098c42 	msub	x2, x2, x9, x3
    85fc:	aa0703e3 	mov	x3, x7
    8600:	9b057d05 	mul	x5, x8, x5
    8604:	b3607c43 	bfi	x3, x2, #32, #32
    8608:	eb0300bf 	cmp	x5, x3
    860c:	540000c9 	b.ls	8624 <__divti3+0x284>  // b.plast
    8610:	ab0300c2 	adds	x2, x6, x3
    8614:	d1000503 	sub	x3, x8, #0x1
    8618:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    861c:	d1000908 	sub	x8, x8, #0x2
    8620:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8624:	aa008100 	orr	x0, x8, x0, lsl #32
    8628:	17ffff90 	b	8468 <__divti3+0xc8>
    862c:	9ac820c6 	lsl	x6, x6, x8
    8630:	d2800803 	mov	x3, #0x40                  	// #64
    8634:	cb080063 	sub	x3, x3, x8
    8638:	d360fcc9 	lsr	x9, x6, #32
    863c:	9ac82027 	lsl	x7, x1, x8
    8640:	92407cc5 	and	x5, x6, #0xffffffff
    8644:	9ac32422 	lsr	x2, x1, x3
    8648:	9ac32403 	lsr	x3, x0, x3
    864c:	aa070063 	orr	x3, x3, x7
    8650:	9ac9084a 	udiv	x10, x2, x9
    8654:	9ac82007 	lsl	x7, x0, x8
    8658:	9b098940 	msub	x0, x10, x9, x2
    865c:	aa0a03e1 	mov	x1, x10
    8660:	9b0a7ca2 	mul	x2, x5, x10
    8664:	93c38000 	extr	x0, x0, x3, #32
    8668:	eb00005f 	cmp	x2, x0
    866c:	540000a9 	b.ls	8680 <__divti3+0x2e0>  // b.plast
    8670:	ab0000c0 	adds	x0, x6, x0
    8674:	d1000541 	sub	x1, x10, #0x1
    8678:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    867c:	54000468 	b.hi	8708 <__divti3+0x368>  // b.pmore
    8680:	cb020000 	sub	x0, x0, x2
    8684:	9ac9080a 	udiv	x10, x0, x9
    8688:	9b098140 	msub	x0, x10, x9, x0
    868c:	aa0a03e2 	mov	x2, x10
    8690:	9b0a7ca8 	mul	x8, x5, x10
    8694:	b3607c03 	bfi	x3, x0, #32, #32
    8698:	eb03011f 	cmp	x8, x3
    869c:	540000a9 	b.ls	86b0 <__divti3+0x310>  // b.plast
    86a0:	ab0300c3 	adds	x3, x6, x3
    86a4:	d1000542 	sub	x2, x10, #0x1
    86a8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    86ac:	54000288 	b.hi	86fc <__divti3+0x35c>  // b.pmore
    86b0:	cb080063 	sub	x3, x3, x8
    86b4:	aa018041 	orr	x1, x2, x1, lsl #32
    86b8:	17ffffc2 	b	85c0 <__divti3+0x220>
    86bc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    86c0:	d2800001 	mov	x1, #0x0                   	// #0
    86c4:	9a9f87e0 	cset	x0, ls	// ls = plast
    86c8:	17ffff68 	b	8468 <__divti3+0xc8>
    86cc:	aa0103e0 	mov	x0, x1
    86d0:	d2800001 	mov	x1, #0x0                   	// #0
    86d4:	17ffff65 	b	8468 <__divti3+0xc8>
    86d8:	d1000860 	sub	x0, x3, #0x2
    86dc:	8b0600a5 	add	x5, x5, x6
    86e0:	17ffff52 	b	8428 <__divti3+0x88>
    86e4:	d1000961 	sub	x1, x11, #0x2
    86e8:	8b0800a5 	add	x5, x5, x8
    86ec:	17ffff85 	b	8500 <__divti3+0x160>
    86f0:	d1000965 	sub	x5, x11, #0x2
    86f4:	8b080063 	add	x3, x3, x8
    86f8:	17ffff8e 	b	8530 <__divti3+0x190>
    86fc:	d1000942 	sub	x2, x10, #0x2
    8700:	8b060063 	add	x3, x3, x6
    8704:	17ffffeb 	b	86b0 <__divti3+0x310>
    8708:	d1000941 	sub	x1, x10, #0x2
    870c:	8b060000 	add	x0, x0, x6
    8710:	17ffffdc 	b	8680 <__divti3+0x2e0>
    8714:	d1000900 	sub	x0, x8, #0x2
    8718:	8b060063 	add	x3, x3, x6
    871c:	17ffffb4 	b	85ec <__divti3+0x24c>

0000000000008720 <__modti3>:
    8720:	d503245f 	bti	c
    8724:	d2800004 	mov	x4, #0x0                   	// #0
    8728:	b6f80081 	tbz	x1, #63, 8738 <__modti3+0x18>
    872c:	eb0003e0 	negs	x0, x0
    8730:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8734:	da0103e1 	ngc	x1, x1
    8738:	f100007f 	cmp	x3, #0x0
    873c:	5400128b 	b.lt	898c <__modti3+0x26c>  // b.tstop
    8740:	aa0003e7 	mov	x7, x0
    8744:	aa0103e6 	mov	x6, x1
    8748:	540004e1 	b.ne	87e4 <__modti3+0xc4>  // b.any
    874c:	eb02003f 	cmp	x1, x2
    8750:	54000dc2 	b.cs	8908 <__modti3+0x1e8>  // b.hs, b.nlast
    8754:	dac01043 	clz	x3, x2
    8758:	aa0303e5 	mov	x5, x3
    875c:	b40000e3 	cbz	x3, 8778 <__modti3+0x58>
    8760:	4b0303e6 	neg	w6, w3
    8764:	9ac32021 	lsl	x1, x1, x3
    8768:	9ac32042 	lsl	x2, x2, x3
    876c:	9ac62406 	lsr	x6, x0, x6
    8770:	aa0100c6 	orr	x6, x6, x1
    8774:	9ac32007 	lsl	x7, x0, x3
    8778:	d360fc40 	lsr	x0, x2, #32
    877c:	92407c43 	and	x3, x2, #0xffffffff
    8780:	9ac008c1 	udiv	x1, x6, x0
    8784:	9b009826 	msub	x6, x1, x0, x6
    8788:	9b017c61 	mul	x1, x3, x1
    878c:	93c780c6 	extr	x6, x6, x7, #32
    8790:	eb06003f 	cmp	x1, x6
    8794:	540000a9 	b.ls	87a8 <__modti3+0x88>  // b.plast
    8798:	ab060046 	adds	x6, x2, x6
    879c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    87a0:	8b0200c8 	add	x8, x6, x2
    87a4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    87a8:	cb0100c6 	sub	x6, x6, x1
    87ac:	9ac008c8 	udiv	x8, x6, x0
    87b0:	9b009901 	msub	x1, x8, x0, x6
    87b4:	aa0703e0 	mov	x0, x7
    87b8:	9b087c63 	mul	x3, x3, x8
    87bc:	b3607c20 	bfi	x0, x1, #32, #32
    87c0:	eb00007f 	cmp	x3, x0
    87c4:	54001088 	b.hi	89d4 <__modti3+0x2b4>  // b.pmore
    87c8:	cb030000 	sub	x0, x0, x3
    87cc:	9ac52400 	lsr	x0, x0, x5
    87d0:	d2800001 	mov	x1, #0x0                   	// #0
    87d4:	b4000064 	cbz	x4, 87e0 <__modti3+0xc0>
    87d8:	eb0003e0 	negs	x0, x0
    87dc:	da0103e1 	ngc	x1, x1
    87e0:	d65f03c0 	ret
    87e4:	dac01066 	clz	x6, x3
    87e8:	eb03003f 	cmp	x1, x3
    87ec:	54ffff43 	b.cc	87d4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    87f0:	93407cc5 	sxtw	x5, w6
    87f4:	d2800808 	mov	x8, #0x40                  	// #64
    87f8:	cb050108 	sub	x8, x8, x5
    87fc:	9ac62063 	lsl	x3, x3, x6
    8800:	9ac62025 	lsl	x5, x1, x6
    8804:	9ac82447 	lsr	x7, x2, x8
    8808:	aa0300e7 	orr	x7, x7, x3
    880c:	9ac82423 	lsr	x3, x1, x8
    8810:	92407cec 	and	x12, x7, #0xffffffff
    8814:	d360fcea 	lsr	x10, x7, #32
    8818:	9ac82401 	lsr	x1, x0, x8
    881c:	aa050021 	orr	x1, x1, x5
    8820:	9ac62042 	lsl	x2, x2, x6
    8824:	9ac62000 	lsl	x0, x0, x6
    8828:	9aca086b 	udiv	x11, x3, x10
    882c:	9b0a8d63 	msub	x3, x11, x10, x3
    8830:	aa0b03e5 	mov	x5, x11
    8834:	9b0b7d89 	mul	x9, x12, x11
    8838:	93c18063 	extr	x3, x3, x1, #32
    883c:	eb03013f 	cmp	x9, x3
    8840:	540000a9 	b.ls	8854 <__modti3+0x134>  // b.plast
    8844:	ab0300e3 	adds	x3, x7, x3
    8848:	d1000565 	sub	x5, x11, #0x1
    884c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8850:	54001168 	b.hi	8a7c <__modti3+0x35c>  // b.pmore
    8854:	cb090063 	sub	x3, x3, x9
    8858:	9aca086b 	udiv	x11, x3, x10
    885c:	9b0a8d6a 	msub	x10, x11, x10, x3
    8860:	aa0b03e9 	mov	x9, x11
    8864:	9b0b7d8c 	mul	x12, x12, x11
    8868:	b3607d41 	bfi	x1, x10, #32, #32
    886c:	eb01019f 	cmp	x12, x1
    8870:	540000a9 	b.ls	8884 <__modti3+0x164>  // b.plast
    8874:	ab0100e1 	adds	x1, x7, x1
    8878:	d1000569 	sub	x9, x11, #0x1
    887c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8880:	54000f88 	b.hi	8a70 <__modti3+0x350>  // b.pmore
    8884:	aa058123 	orr	x3, x9, x5, lsl #32
    8888:	92407c4b 	and	x11, x2, #0xffffffff
    888c:	2a0903e9 	mov	w9, w9
    8890:	d360fc4a 	lsr	x10, x2, #32
    8894:	d360fc63 	lsr	x3, x3, #32
    8898:	cb0c0021 	sub	x1, x1, x12
    889c:	aa0a03ec 	mov	x12, x10
    88a0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    88a4:	9b0b7d25 	mul	x5, x9, x11
    88a8:	9b0b7c6b 	mul	x11, x3, x11
    88ac:	9b0a2d29 	madd	x9, x9, x10, x11
    88b0:	92407caa 	and	x10, x5, #0xffffffff
    88b4:	9b0c7c63 	mul	x3, x3, x12
    88b8:	8b458125 	add	x5, x9, x5, lsr #32
    88bc:	8b0d0069 	add	x9, x3, x13
    88c0:	eb05017f 	cmp	x11, x5
    88c4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    88c8:	8b058149 	add	x9, x10, x5, lsl #32
    88cc:	8b458063 	add	x3, x3, x5, lsr #32
    88d0:	eb03003f 	cmp	x1, x3
    88d4:	54000063 	b.cc	88e0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    88d8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    88dc:	54000082 	b.cs	88ec <__modti3+0x1cc>  // b.hs, b.nlast
    88e0:	eb020129 	subs	x9, x9, x2
    88e4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    88e8:	cb070063 	sub	x3, x3, x7
    88ec:	eb090000 	subs	x0, x0, x9
    88f0:	da030021 	sbc	x1, x1, x3
    88f4:	9ac62400 	lsr	x0, x0, x6
    88f8:	9ac82028 	lsl	x8, x1, x8
    88fc:	aa000100 	orr	x0, x8, x0
    8900:	9ac62421 	lsr	x1, x1, x6
    8904:	17ffffb4 	b	87d4 <__modti3+0xb4>
    8908:	b5000062 	cbnz	x2, 8914 <__modti3+0x1f4>
    890c:	d2800023 	mov	x3, #0x1                   	// #1
    8910:	9ac20862 	udiv	x2, x3, x2
    8914:	dac01048 	clz	x8, x2
    8918:	aa0803e5 	mov	x5, x8
    891c:	b5000668 	cbnz	x8, 89e8 <__modti3+0x2c8>
    8920:	cb020020 	sub	x0, x1, x2
    8924:	d360fc49 	lsr	x9, x2, #32
    8928:	92407c4a 	and	x10, x2, #0xffffffff
    892c:	9ac90801 	udiv	x1, x0, x9
    8930:	9b098020 	msub	x0, x1, x9, x0
    8934:	9b0a7c21 	mul	x1, x1, x10
    8938:	93c78000 	extr	x0, x0, x7, #32
    893c:	eb00003f 	cmp	x1, x0
    8940:	540000a9 	b.ls	8954 <__modti3+0x234>  // b.plast
    8944:	ab000040 	adds	x0, x2, x0
    8948:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    894c:	8b020003 	add	x3, x0, x2
    8950:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8954:	cb010001 	sub	x1, x0, x1
    8958:	9ac90820 	udiv	x0, x1, x9
    895c:	9b098403 	msub	x3, x0, x9, x1
    8960:	aa0703e1 	mov	x1, x7
    8964:	9b0a7c00 	mul	x0, x0, x10
    8968:	b3607c61 	bfi	x1, x3, #32, #32
    896c:	eb01001f 	cmp	x0, x1
    8970:	540000a9 	b.ls	8984 <__modti3+0x264>  // b.plast
    8974:	ab010041 	adds	x1, x2, x1
    8978:	8b020022 	add	x2, x1, x2
    897c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    8980:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    8984:	cb000020 	sub	x0, x1, x0
    8988:	17ffff91 	b	87cc <__modti3+0xac>
    898c:	eb0203e5 	negs	x5, x2
    8990:	aa0003e7 	mov	x7, x0
    8994:	da0303e8 	ngc	x8, x3
    8998:	aa0503e2 	mov	x2, x5
    899c:	aa0803e3 	mov	x3, x8
    89a0:	aa0103e6 	mov	x6, x1
    89a4:	b4ffed48 	cbz	x8, 874c <__modti3+0x2c>
    89a8:	eb01011f 	cmp	x8, x1
    89ac:	54fff148 	b.hi	87d4 <__modti3+0xb4>  // b.pmore
    89b0:	dac01109 	clz	x9, x8
    89b4:	2a0903e6 	mov	w6, w9
    89b8:	b5fff1c9 	cbnz	x9, 87f0 <__modti3+0xd0>
    89bc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    89c0:	54000068 	b.hi	89cc <__modti3+0x2ac>  // b.pmore
    89c4:	eb050007 	subs	x7, x0, x5
    89c8:	da080021 	sbc	x1, x1, x8
    89cc:	aa0703e0 	mov	x0, x7
    89d0:	17ffff81 	b	87d4 <__modti3+0xb4>
    89d4:	ab000040 	adds	x0, x2, x0
    89d8:	8b020002 	add	x2, x0, x2
    89dc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    89e0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    89e4:	17ffff79 	b	87c8 <__modti3+0xa8>
    89e8:	9ac82042 	lsl	x2, x2, x8
    89ec:	d2800803 	mov	x3, #0x40                  	// #64
    89f0:	cb080063 	sub	x3, x3, x8
    89f4:	d360fc49 	lsr	x9, x2, #32
    89f8:	9ac82027 	lsl	x7, x1, x8
    89fc:	92407c4a 	and	x10, x2, #0xffffffff
    8a00:	9ac32426 	lsr	x6, x1, x3
    8a04:	9ac32403 	lsr	x3, x0, x3
    8a08:	aa070063 	orr	x3, x3, x7
    8a0c:	9ac908c1 	udiv	x1, x6, x9
    8a10:	9ac82007 	lsl	x7, x0, x8
    8a14:	9b099820 	msub	x0, x1, x9, x6
    8a18:	9b017d41 	mul	x1, x10, x1
    8a1c:	93c38000 	extr	x0, x0, x3, #32
    8a20:	eb00003f 	cmp	x1, x0
    8a24:	540000a9 	b.ls	8a38 <__modti3+0x318>  // b.plast
    8a28:	ab000040 	adds	x0, x2, x0
    8a2c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8a30:	8b020006 	add	x6, x0, x2
    8a34:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8a38:	cb010000 	sub	x0, x0, x1
    8a3c:	9ac90801 	udiv	x1, x0, x9
    8a40:	9b098026 	msub	x6, x1, x9, x0
    8a44:	aa0303e0 	mov	x0, x3
    8a48:	9b017d41 	mul	x1, x10, x1
    8a4c:	b3607cc0 	bfi	x0, x6, #32, #32
    8a50:	eb00003f 	cmp	x1, x0
    8a54:	540000a9 	b.ls	8a68 <__modti3+0x348>  // b.plast
    8a58:	ab000040 	adds	x0, x2, x0
    8a5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8a60:	8b020003 	add	x3, x0, x2
    8a64:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8a68:	cb010000 	sub	x0, x0, x1
    8a6c:	17ffffb0 	b	892c <__modti3+0x20c>
    8a70:	d1000969 	sub	x9, x11, #0x2
    8a74:	8b070021 	add	x1, x1, x7
    8a78:	17ffff83 	b	8884 <__modti3+0x164>
    8a7c:	d1000965 	sub	x5, x11, #0x2
    8a80:	8b070063 	add	x3, x3, x7
    8a84:	17ffff74 	b	8854 <__modti3+0x134>
    8a88:	d503201f 	nop
    8a8c:	d503201f 	nop

0000000000008a90 <atexit>:
    8a90:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8a94:	900000c2 	adrp	x2, 20000 <__data_start>
    8a98:	d2800001 	mov	x1, #0x0                   	// #0
    8a9c:	910003fd 	mov	x29, sp
    8aa0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8aa4:	f9400442 	ldr	x2, [x2, #8]
    8aa8:	17ffe23e 	b	13a0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008aac <_fini>:
    8aac:	d503201f 	nop
    8ab0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8ab4:	910003fd 	mov	x29, sp
    8ab8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8abc:	d65f03c0 	ret
